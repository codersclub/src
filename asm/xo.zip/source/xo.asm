
.386
.model flat, stdcall

include		C:\TASM\INCLUDE\win32.inc
include		xo.inc
includelib	import32.lib


.data

newhwnd          dd 0
msg             MSGSTRUCT   <?>
wc              WNDCLASS    <?>
point		POINT	<?>
PaintStruct	PAINTSTRUCT <?>
Rect		RECT <?>
WindowRect	RECT <?>
DesktopRect     RECT <?>
Bitmap		BITMAP <?>

hDC		dd ?
hCompatibleDC	dd ?
hBitmap		dd ?
hBitmap0	dd ?
hBitmap1	dd ?
hBitmap2	dd ?
WinWidth	dd ?
WinHeight	dd ?

MouseClick	dd 0
_x		dd 0
_y		dd 0
__x		dd 0
__y		dd 0
hInstance	dd 0
mouse_button	db 0
count		dd 9

szTitleName	db '�������� - ������', 0
szClassName	db 'BABEK_CLASS32',0
szMenuName	db 'MENU_1',0
szError		db '�������� ���!',0
szYouWin	db '�� ��������!!! ������ ��� ���?',0
szCompWin	db '������� ���������!!! ������ ��� ���?',0
szNoWin		db '�����. ������ ��� ���?',0
szAbout		db '   Copyright ',0A9h,' BabekCom 2000',10,13,'    http://babekcom.chat.ru/'
		db 10,13,'This programm compiled in TASM 5.0',0

who		db 0	; ��� �������� ����
xo		db 2	; ���� 1 �� X, ���� 2 �� O
ox		db 1	; ��� ������ ���������
man		dd 0	; ���� 1 � ��������� ���� 0 � �����������
addr_map	dd ?	; ������� ����� ����� ���� A_A-I_I
A_A		db 0
B_B		db 0
C_C		db 0
D_D		db 0
E_E		db 0
F_F		db 0
G_G		db 0
H_H		db 0
I_I		db 0
		db 0

.code
;----------------------------------------------------------------------

start:
        call    GetModuleHandleA, 0
        mov     [hInstance], eax

; initialize the WndClass structure
        mov     [wc.clsStyle], CS_HREDRAW + CS_VREDRAW
        mov     [wc.clsLpfnWndProc], offset DCDemoWndProc
        mov     [wc.clsCbClsExtra], 0
        mov     [wc.clsCbWndExtra], 0

        mov     eax, [hInstance]
        mov     [wc.clsHInstance], eax

        call    LoadIconA, 0, ICON_1
        mov     [wc.clsHIcon], eax

        call    LoadCursorA, 0 ,IDC_ARROW
        mov     [wc.clsHCursor], eax

        call    GetStockObject, WHITE_BRUSH
        mov     [wc.clsHbrBackground], eax

        mov     [wc.clsLpszMenuName], offset szMenuName
        mov     [wc.clsLpszClassName], offset szClassName

        call    RegisterClassA, offset wc

        call    CreateWindowExA, 0, \
				offset szClassName, \
				offset szTitleName, \
				WS_DLGFRAME OR \
				WS_SYSMENU OR \
				WS_MINIMIZEBOX, \
				0, 0, 306, 344, \
				0,0, [hInstance], 0

        mov     [newhwnd], eax

        call    ShowWindow, [newhwnd], SW_SHOWNORMAL
        call    UpdateWindow, [newhwnd]
;---------------------------------------------------------------------

msg_loop:
        call    GetMessageA, offset msg, 0, 0, 0
        .if     eax != 0
                call    TranslateMessage, offset msg
                call    DispatchMessageA, offset msg
                jmp     msg_loop
        .endif

	call    ExitProcess, [msg.msWPARAM]


;----------------------------------------------------------------------
DCDemoWndProc    proc uses ebx edi esi, hwnd:DWORD, wmsg:DWORD,\
                 wparam:DWORD, lparam:DWORD

        cmp     [wmsg], WM_CREATE
        je      wmcreate
        cmp     [wmsg], WM_PAINT
        je      wmpaint
	cmp	[wmsg], WM_LBUTTONDOWN
	je	wmLButton
	cmp	[wmsg], WM_RBUTTONDOWN
	je	wmRButton
	cmp	[wmsg], WM_COMMAND
	je	wmcommand

        cmp     [wmsg], WM_DESTROY
        je      wmdestroy

        call    DefWindowProcA, [hwnd],[wmsg],[wparam],[lparam]
        jmp     finish
;--------------------------------------------------------------
; ��������� Bitmap �� �������� � �������� ����� ������
wmcreate:
        call    LoadBitmapA, hInstance, 100
        mov     [hBitmap0], eax
        call    LoadBitmapA, hInstance, 101
        mov     [hBitmap1], eax
        call    LoadBitmapA, hInstance, 102
        mov     [hBitmap2], eax
	call    GetObjectA, [hBitmap0], size BITMAP, offset Bitmap
; �������� ���� ����
center:	call    GetClientRect, [hwnd], offset Rect
	call    GetDesktopWindow
	call    GetWindowRect, eax, offset DesktopRect
	call	GetWindowRect, hwnd, offset WindowRect

	mov     eax, WindowRect.rcBottom
	sub     eax, WindowRect.rcTop
	mov     WinHeight, eax
	mov     eax, WindowRect.rcRight
	sub     eax, WindowRect.rcLeft
	mov     WinWidth, eax
	mov     ebx, DesktopRect.rcBottom
	sub     ebx, WinHeight
	shr     ebx, 1
	mov     ecx, DesktopRect.rcRight
	sub     ecx, WinWidth
	shr     ecx, 1
	call    MoveWindow, hwnd, ecx, ebx, WinWidth, WinHeight, 0

	xor     eax, eax
        jmp     newgame
;--------------------------------------------------------------

wmpaint:
	lea	eax,A_A
	mov	[addr_map],eax
	mov	[_x],0
	mov	[_y],0
	mov	[count],9

        call    BeginPaint, [hwnd], offset PaintStruct
        mov     [hDC], eax

        call    CreateCompatibleDC, [hDC]
        mov     [hCompatibleDC], eax

; ������ ��� �������� Bitmap � ������������ � ����������
; ���������� A_A...I_I � ������� _x, _y 
lb_loop:
	mov	ecx,[addr_map]
	mov	al,[ecx]
	inc	[addr_map]

; ���������� ����� �� Bitmap'�� ����� ����������
; � ������� ������� [_x][_y] ����
	.if	al == 1
		push [hBitmap1]
		pop	[hBitmap]
	.elseif	al == 2
		push [hBitmap2]
		pop	[hBitmap]
	.else
		push [hBitmap0]
		pop	[hBitmap]
	.endif

        call    SelectObject, [hCompatibleDC], [hBitmap]

        call    BitBlt, [hDC], [_x], [_y],[Rect.rcRight],[Rect.rcBottom], \
                [hCompatibleDC], 0, 0, SRCAND

        call    DeleteObject, [hBitmap]

	add	[_x],100
	.if	[_x] == 300
		mov	[_x],0
		add	[_y],100
	.endif

	dec	[count]
	jnz	lb_loop

        call    DeleteDC, [hCompatibleDC]
        call    EndPaint, [hwnd], offset PaintStruct

        mov     eax, 0
        jmp     finish
;----------------------------------------------------------------------

wmcommand:
	cmp	wparam, IDM_ABOUT
	je	about
	cmp	wparam, IDM_MAN
	je	manual
	cmp	wparam, IDM_COMP
	je	computer
	cmp	wparam, IDM_EXIT
	je	wmdestroy
	jmp	finish
;----------------------------------------------------------------------

wmRButton:
	.if	[man] == 0
		ret
	.endif
	mov	al,[ox]
	mov	[mouse_button],al
	jmp short wmMouseClick

wmLButton:
	mov	al,[xo]
	mov	[mouse_button],al

wmMouseClick:
	mov	eax, [lparam]
	and	eax,0ffffh
	mov	[point.ptX],eax
	mov	eax,[lparam]
	shr	eax,16
	mov	[point.ptY],eax
	mov	[MouseClick],TRUE
	call	InvalidateRect, [hwnd], 0, TRUE
	mov	eax,[point.ptX]
	.if	eax > 200
		mov	[__x], 2
	.elseif eax > 100
		mov	[__x], 1
	.else
		mov	[__x], 0
	.endif

	mov	eax,[point.ptY]
	.if	eax > 200
		mov	[__y], 2
	.elseif eax > 100
		mov	[__y], 1
	.else
		mov	[__y], 0
	.endif

	lea	edx,A_A
	mov	eax,[__x]
	mov	ecx,[__y]
	imul	ecx,3
	add	eax,ecx
	add	edx,eax
	mov	al,[edx]
	.if	al != 0
		jmp	error
	.endif
	mov	al,[mouse_button]
	mov	[edx],al

        jmp     logic_1

;----------------------------------------------------------------------
wmdestroy:
        call    PostQuitMessage, 0
        mov     eax, 0
finish:
        ret
;----------------------------------------------------------------------
about:
	mov	eax,offset szAbout
	mov	ecx, offset szTitleName
	call	MessageBoxA,hwnd,eax,ecx,MB_OK
	xor	eax,eax
	ret
error:
	mov	eax,offset szError
	mov	ecx, offset szTitleName
	call	MessageBoxA,hwnd,eax,ecx,MB_OK+MB_ICONEXCLAMATION
	ret

no_win:
	mov	eax,offset szNoWin
	jmp short message
loss:
	mov	eax,offset szCompWin
	jmp short message
win:
	mov	eax,offset szYouWin
message:
	mov	ecx, offset szTitleName
	call	MessageBoxA,hwnd,eax,ecx,MB_OK+MB_ICONEXCLAMATION
	jmp	newgame

manual:
	mov	[man],1
	jmp short newgame
computer:
	mov	[man],0
newgame:
	; �������� ����� A_A...I_I
	mov	ecx,9
	mov	al,0
	push	ds
	pop	es
	lea	edi,A_A
	rep	stosb
	mov	[mouse_button],0
	call	InvalidateRect, [hwnd], 0, TRUE
	mov	al,xo
	mov	bl,ox
	mov	xo,bl
	mov	ox,al
	; �������� ���������� ����
	.if	who == 1
		mov	[who],0
		jmp	logic_1
	.endif
	mov	[who],1
	jmp	wmpaint

;**********************************************************************
;*
;*        ������ ����������� ��������
;*
;**********************************************************************
db '********',0
logic_1:

;---- �������� �� ������� ---------------------------------------------
	mov	al,xo
.if A_A == al
	.if B_B == al
		.if C_C == al
			jmp win
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == al
			jmp win
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == al
			jmp win
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == al
			jmp win
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == al
			jmp win
		.endif
	.endif
.endif
;---- �������� �� �������� --------------------------------------------
	mov	al,ox
.if A_A == al
	.if B_B == al
		.if C_C == al
			jmp loss
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == al
			jmp loss
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == al
			jmp loss
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == al
			jmp loss
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == al
			jmp loss
		.endif
	.endif
.endif

;---- �������� �� ����� -----------------------------------------------
.if	A_A != 0
.if	B_B != 0
.if	C_C != 0
.if	D_D != 0
.if	E_E != 0
.if	F_F != 0
.if	G_G != 0
.if	H_H != 0
.if	I_I != 0
	jmp	no_win
.endif
.endif
.endif
.endif
.endif
.endif
.endif
.endif
.endif
; ���� ���� � ��������� ���������� ��������
; � ������ ������ ��������� ��� ����������
.if	man == 1
	jmp	wmpaint
.endif

;**********************************************************************
;	������ ���� ����������
;**********************************************************************

logic_2:


;---- �������� �� ��������� ������� -----------------------------------

	mov	al,ox
.if A_A == al
	.if B_B == al
		.if C_C == 0
			mov	C_C,al
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if C_C == al
		.if B_B == 0
			mov	B_B,al
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if C_C == al
		.if A_A == 0
			mov	A_A,al
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == 0
			mov	F_F,al
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if F_F == al
		.if E_E == 0
			mov	E_E,al
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if F_F == al
		.if D_D == 0
			mov	D_D,al
			jmp	end_log
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == 0
			mov	I_I,al
			jmp	end_log
		.endif
	.endif
.endif
.if G_G == al
	.if I_I == al
		.if H_H == 0
			mov	H_H,al
			jmp	end_log
		.endif
	.endif
.endif
.if H_H == al
	.if I_I == al
		.if G_G == 0
			mov	G_G,al
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == 0
			mov	G_G,al
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if G_G == al
		.if D_D == 0
			mov	D_D,al
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if G_G == al
		.if A_A == 0
			mov	A_A,al
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == 0
			mov	H_H,al
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if H_H == al
		.if E_E == 0
			mov	E_E,al
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if H_H == al
		.if B_B == 0
			mov	B_B,al
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == 0
			mov	I_I,al
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if I_I == al
		.if F_F == 0
			mov	F_F,al
			jmp	end_log
		.endif
	.endif
.endif
.if F_F == al
	.if I_I == al
		.if C_C == 0
			mov	C_C,al
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == 0
			mov	I_I,al
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if I_I == al
		.if E_E == 0
			mov	E_E,al
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if I_I == al
		.if A_A == 0
			mov	A_A,al
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == 0
			mov	G_G,al
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if G_G == al
		.if E_E == 0
			mov	E_E,al
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if G_G == al
		.if C_C == 0
			mov	C_C,al
			jmp	end_log
		.endif
	.endif
.endif

;---- ������ ������� �������� -----------------------------------------

	mov	al,xo
.if A_A == al
	.if B_B == al
		.if C_C == 0
			mov	bl,ox
			mov	C_C,bl
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if C_C == al
		.if B_B == 0
			mov	bl,ox
			mov	B_B,bl
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if C_C == al
		.if A_A == 0
			mov	bl,ox
			mov	A_A,bl
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == 0
			mov	bl,ox
			mov	F_F,bl
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if F_F == al
		.if E_E == 0
			mov	bl,ox
			mov	E_E,bl
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if F_F == al
		.if D_D == 0
			mov	bl,ox
			mov	D_D,bl
			jmp	end_log
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == 0
			mov	bl,ox
			mov	I_I,bl
			jmp	end_log
		.endif
	.endif
.endif
.if G_G == al
	.if I_I == al
		.if H_H == 0
			mov	bl,ox
			mov	H_H,bl
			jmp	end_log
		.endif
	.endif
.endif
.if H_H == al
	.if I_I == al
		.if G_G == 0
			mov	bl,ox
			mov	G_G,bl
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == 0
			mov	bl,ox
			mov	G_G,bl
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if G_G == al
		.if D_D == 0
			mov	bl,ox
			mov	D_D,bl
			jmp	end_log
		.endif
	.endif
.endif
.if D_D == al
	.if G_G == al
		.if A_A == 0
			mov	bl,ox
			mov	A_A,bl
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == 0
			mov	bl,ox
			mov	H_H,bl
			jmp	end_log
		.endif
	.endif
.endif
.if B_B == al
	.if H_H == al
		.if E_E == 0
			mov	bl,ox
			mov	E_E,bl
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if H_H == al
		.if B_B == 0
			mov	bl,ox
			mov	B_B,bl
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == 0
			mov	bl,ox
			mov	I_I,bl
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if I_I == al
		.if F_F == 0
			mov	bl,ox
			mov	F_F,bl
			jmp	end_log
		.endif
	.endif
.endif
.if F_F == al
	.if I_I == al
		.if C_C == 0
			mov	bl,ox
			mov	C_C,bl
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == 0
			mov	bl,ox
			mov	I_I,bl
			jmp	end_log
		.endif
	.endif
.endif
.if A_A == al
	.if I_I == al
		.if E_E == 0
			mov	bl,ox
			mov	E_E,bl
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if I_I == al
		.if A_A == 0
			mov	bl,ox
			mov	A_A,bl
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == 0
			mov	bl,ox
			mov	G_G,bl
			jmp	end_log
		.endif
	.endif
.endif
.if C_C == al
	.if G_G == al
		.if E_E == 0
			mov	bl,ox
			mov	E_E,bl
			jmp	end_log
		.endif
	.endif
.endif
.if E_E == al
	.if G_G == al
		.if C_C == 0
			mov	bl,ox
			mov	C_C,bl
			jmp	end_log
		.endif
	.endif
.endif

;---- ������ ��� ���������� -------------------------------------------


	.if A_A == 0
		mov	al,ox
		mov	A_A,al
		jmp	end_log
	.endif


	.if I_I == 0
		mov	al,ox
		mov	I_I,al
		jmp	end_log
	.endif


;---- ���� ������ �������� ���� ����� ---------------------------------
;---- � ��� �������� ���������, �� ������� ����� ----------------------
	mov	al,ox
.if A_A == al
	.if E_E == 0
		.if I_I == 0
		mov	E_E,al
		jmp	end_log
		.endif
	.endif
.endif
.if C_C == 0
	mov	C_C,al
	jmp	end_log
.endif
.if G_G == 0
	mov	G_G,al
	jmp	end_log
.endif

;---- ��� ��� �������� �� ������� ---------------------------------------------

end_log:

	mov	al,xo
.if A_A == al
	.if B_B == al
		.if C_C == al
			jmp win
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == al
			jmp win
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == al
			jmp win
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == al
			jmp win
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == al
			jmp win
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == al
			jmp win
		.endif
	.endif
.endif
;---- �������� �� �������� --------------------------------------------
	mov	al,ox
.if A_A == al
	.if B_B == al
		.if C_C == al
			jmp loss
		.endif
	.endif
.endif
.if D_D == al
	.if E_E == al
		.if F_F == al
			jmp loss
		.endif
	.endif
.endif
.if G_G == al
	.if H_H == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if A_A == al
	.if D_D == al
		.if G_G == al
			jmp loss
		.endif
	.endif
.endif
.if B_B == al
	.if E_E == al
		.if H_H == al
			jmp loss
		.endif
	.endif
.endif
.if C_C == al
	.if F_F == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if A_A == al
	.if E_E == al
		.if I_I == al
			jmp loss
		.endif
	.endif
.endif
.if C_C == al
	.if E_E == al
		.if G_G == al
			jmp loss
		.endif
	.endif
.endif
;---- �������� �� ����� -----------------------------------------------
.if	A_A != 0
.if	B_B != 0
.if	C_C != 0
.if	D_D != 0
.if	E_E != 0
.if	F_F != 0
.if	G_G != 0
.if	H_H != 0
.if	I_I != 0
	jmp	no_win
.endif
.endif
.endif
.endif
.endif
.endif
.endif
.endif
.endif



 

;---- ����� ���������� ����� ------------------------------------------

	mov	al,ox
	mov	[mouse_button],al
	jmp	wmpaint

db '********'
DCDemoWndProc          endp
ends
end start