brcc32 xo.rc
tasm32 /m /ml xo.asm
tlink32 /Tpe /aa /c xo.obj,,,,,xo.res

