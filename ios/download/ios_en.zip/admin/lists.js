
function add(box1,box2) {

  var boxLength = box1.length;
  var selectedItem = box2.selectedIndex;
  var selectedText = box2.options[selectedItem].text;
  var selectedValue = box2.options[selectedItem].value;
  var i;
  var isNew = true;
  if (boxLength != 0) {
    for (i = 0; i < boxLength; i++) {
      thisitem = box1.options[i].text;
      if (thisitem == selectedText) {
        isNew = false;
        break;
      }
    }
  } 
  if (isNew) {
    newoption = new Option(selectedText, selectedValue, false, false);
    box1.options[boxLength] = newoption;
  }
  box2.selectedIndex=-1;
  SortD(box1);

}


function add_interval(box1,box2,box3,box4,box5) {

  var boxLength = box5.length;
  var selectedItem = box1.selectedIndex;
  var selectedText1 = box1.options[selectedItem].text;
  var selectedValue1 = box1.options[selectedItem].value;
  selectedItem = box2.selectedIndex;
  var selectedText2 = box2.options[selectedItem].text;
  var selectedValue2 = box2.options[selectedItem].value;
  selectedItem = box3.selectedIndex;
  var selectedText3 = box3.options[selectedItem].text;
  var selectedValue3 = box3.options[selectedItem].value;
  selectedItem = box4.selectedIndex;
  var selectedText4 = box4.options[selectedItem].text;
  var selectedValue4 = box4.options[selectedItem].value;
  var selectedText = selectedText1 + ':' + selectedText2 + ' - ' + selectedText3 + ':' + selectedText4;
  var selectedValue = selectedValue1 + ':' + selectedValue2 + ' - ' + selectedValue3 + ':' + selectedValue4;
  var i;
  var isNew = true;
  if (boxLength != 0) {
    for (i = 0; i < boxLength; i++) {
      thisitem = box5.options[i].text;
      if (thisitem == selectedText) {
        isNew = false;
        break;
      }
    }
  } 
  if (isNew) {
    newoption = new Option(selectedText, selectedValue, false, false);
    box5.options[boxLength] = newoption;
  }
  box5.selectedIndex=-1;
  SortD(box5);

}

function del(box1) {

  maxi=box1.options.length-1
  for(var i=maxi; i>=0; i--) {
    if(box1.options[i].selected) {
      box1.options[i]=null;
    }
  }
}


function SortD(box)  {
  var temp_opts = new Array();
  var temptxt = new Object();
  var tempval = new Object();
  // Load temp array
  for(var i=0; i<box.options.length; i++)  {
    temp_opts[i] = box.options[i];
  }

  for(var x=0; x<temp_opts.length-1; x++)  {
    for(var y=(x+1); y<temp_opts.length; y++)  {
      if(temp_opts[x].text > temp_opts[y].text)  {
        temptxt = temp_opts[x].text;
        temp_opts[x].text = temp_opts[y].text;
        temp_opts[y].text = temptxt;
  
        tempval = temp_opts[x].value;
        temp_opts[x].value = temp_opts[y].value;
        temp_opts[y].value = tempval;
      }
    }
  }

  for(var i=0; i<box.options.length; i++)  {
    box.options[i].value = temp_opts[i].value;
    box.options[i].text = temp_opts[i].text;
  }
}




function find(what,box2) {
  for (i=0; i<=box2.length-1; i++) {
    if(box2.options[i].text.toUpperCase().indexOf(what.value.toUpperCase())==0) {
      box2.selectedIndex=i;
      return;
    }
  }
}



function Select(box)  {
  for(var i=0; i<box.options.length; i++)  {
    box.options[i].selected = true;
  }
}

