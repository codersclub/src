//---------------------------------------------------------------------------

#ifndef mainH
#define mainH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include <ComCtrls.hpp>
#include <ExtCtrls.hpp>
#include <ToolWin.hpp>
#include <Dialogs.hpp>
#include <Graphics.hpp>
#include <ExtDlgs.hpp>
#include "size.h"
#include "SHDocVw_OCX.h"
#include <OleCtrls.hpp>
#include <jpeg.hpp>
#include "gifimage.hpp"
//---------------------------------------------------------------------------
class TMainForm : public TForm
{
__published:	// IDE-managed Components
  TColorDialog *ColorDialog1;
  TSavePictureDialog *SavePictureDialog1;
  TPageControl *PageControl1;
  TTabSheet *TabSheet1;
  TTabSheet *TabSheet2;
  TCppWebBrowser *Browser;
  TPaintBox *PaintBox1;
  TMemo *Memo1;
  TColorDialog *ColorDialog2;
  TTrackBar *ContrastBar;
  TBitBtn *GenerateBtn;
  TBitBtn *SaveBtn;
  TBitBtn *SizeBtn;
  TBitBtn *ColorBtn;
  TBitBtn *AboutBtn;
  TPanel *Panel1;
  TSpeedButton *SmoothBtn;
  TPanel *Panel2;
  TSpeedButton *TileBtn;
  TBitBtn *ColorFontBtn;
  TTabSheet *TabSheet3;
  TCppWebBrowser *TestBrowser;
  TBitBtn *SeHTMLBtn;
  TSavePictureDialog *SelBG;
  TOpenDialog *SelHTML;
  TBitBtn *SelBGBtn;
  void __fastcall GenerateBtnClick(TObject *Sender);
  void __fastcall ColorBtnClick(TObject *Sender);
  void __fastcall SaveBtnClick(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall SizeBtnClick(TObject *Sender);
  void __fastcall AboutBtnClick(TObject *Sender);
  void __fastcall ChangeCanvas(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
  void __fastcall PageControl1Change(TObject *Sender);
  void __fastcall ColorFontBtnClick(TObject *Sender);
  void __fastcall UpdateTexture(TObject *Sender);
  void __fastcall SeHTMLBtnClick(TObject *Sender);
  void __fastcall SelBGBtnClick(TObject *Sender);
  void __fastcall FormResize(TObject *Sender);
private:	// User declarations
  float r1, r2, r3;
  AnsiString TempDir;
  Graphics::TBitmap *pBmp8;
  Graphics::TBitmap *pBmp24;
  TJPEGImage *pJpeg;
  TGIFImage *pGif;
  void __fastcall Generate();
  void __fastcall UpdateCanvas();
  void __fastcall TestBrowserReload();
  bool __fastcall SaveTexture(TSavePictureDialog *SPD, bool CheckOnExists);
public:		// User declarations
  int X;
  int Y;
  __fastcall TMainForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TMainForm *MainForm;
//---------------------------------------------------------------------------
#endif
