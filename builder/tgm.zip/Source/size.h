//---------------------------------------------------------------------------

#ifndef sizeH
#define sizeH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Buttons.hpp>
#include "CSPIN.h"
//---------------------------------------------------------------------------
class TSizeForm : public TForm
{
__published:	// IDE-managed Components
  TCSpinEdit *EditHeight;
  TCSpinEdit *EditWidth;
  TBitBtn *BitBtn1;
  TBitBtn *BitBtn2;
  TLabel *Label1;
  TLabel *Label2;
  void __fastcall FormCreate(TObject *Sender);
  void __fastcall BitBtn1Click(TObject *Sender);
  void __fastcall FormClose(TObject *Sender, TCloseAction &Action);
private:	// User declarations
public:		// User declarations
  __fastcall TSizeForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TSizeForm *SizeForm;
//---------------------------------------------------------------------------
#endif
