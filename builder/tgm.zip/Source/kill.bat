del *.tds
del *.obj
del *.dcu
del *.~cpp
del *.~dfm
del *.~bpr
del *.~h
del *.cgl