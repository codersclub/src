object SizeForm: TSizeForm
  Left = 323
  Top = 231
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Texture Size'
  ClientHeight = 128
  ClientWidth = 163
  Color = clTeal
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  OnClose = FormClose
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 23
    Top = 16
    Width = 50
    Height = 16
    Alignment = taRightJustify
    Caption = 'Width   ='
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object Label2: TLabel
    Left = 19
    Top = 48
    Width = 55
    Height = 16
    Alignment = taRightJustify
    Caption = 'Height   ='
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -13
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    ParentFont = False
  end
  object EditHeight: TCSpinEdit
    Left = 80
    Top = 48
    Width = 66
    Height = 22
    TabStop = True
    Increment = 5
    MaxValue = 10000
    MinValue = 5
    ParentColor = False
    TabOrder = 1
    Value = 5
  end
  object EditWidth: TCSpinEdit
    Left = 80
    Top = 16
    Width = 66
    Height = 22
    TabStop = True
    Increment = 5
    MaxValue = 10000
    MinValue = 5
    ParentColor = False
    TabOrder = 0
    Value = 5
  end
  object BitBtn1: TBitBtn
    Left = 16
    Top = 88
    Width = 43
    Height = 25
    Caption = 'OK'
    ModalResult = 1
    TabOrder = 2
    OnClick = BitBtn1Click
  end
  object BitBtn2: TBitBtn
    Left = 80
    Top = 88
    Width = 65
    Height = 25
    Caption = 'Cancel'
    ModalResult = 2
    TabOrder = 3
  end
end
