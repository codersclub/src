//---------------------------------------------------------------------------

#ifndef aboutH
#define aboutH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>
#include <Buttons.hpp>
//---------------------------------------------------------------------------
class TAboutForm : public TForm
{
__published:	// IDE-managed Components
  TImage *ImageLogoOn;
  TImage *ImageLogoOff;
  TLabel *Label1;
  TLabel *Label_VERSION;
  TTimer *Timer1;
  TLabel *Label3;
  TImage *Image1;
  TImage *Image2;
  TImage *Image3;
  TImage *Image4;
  TButton *Button1;
  void __fastcall SendMail(TObject *Sender);
  void __fastcall ImageLogoOffMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
  void __fastcall Timer1Timer(TObject *Sender);
  void __fastcall ImageLogoOnMouseMove(TObject *Sender, TShiftState Shift,
          int X, int Y);
  void __fastcall FormShow(TObject *Sender);
  void __fastcall FormDestroy(TObject *Sender);
  void __fastcall FormCreate(TObject *Sender);
private:	// User declarations
  Graphics::TBitmap *pBmp;
public:		// User declarations
  __fastcall TAboutForm(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TAboutForm *AboutForm;
//---------------------------------------------------------------------------
#endif
