//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "about.h"
#include "generate.h"
#include "palette.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TAboutForm *AboutForm;

#define VERSION "Version 1.0"

//---------------------------------------------------------------------------
__fastcall TAboutForm::TAboutForm(TComponent* Owner)
  : TForm(Owner)
{
  pBmp = new Graphics::TBitmap();
}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::FormCreate(TObject *Sender)
{
  pBmp->PixelFormat = pf8bit;
  pBmp->Height = 100;
  pBmp->Width = 100;
  pBmp->Palette = ColorPalette(clLime);

  Label_VERSION->Caption = VERSION;
}

//---------------------------------------------------------------------------
// ������������� ��� ���� About
void __fastcall TAboutForm::FormShow(TObject *Sender)
{

  float r1  = (rand()+1)/(float)RAND_MAX;
  float r2  = (rand()+1)/(float)RAND_MAX;
  float r3  = (rand()+1)/(float)RAND_MAX;

  CreateTexture(pBmp, true, r1, r2, r3, 0.5);

  Image1->Picture->Bitmap->Assign(pBmp);
  Image2->Picture->Bitmap->Assign(pBmp);
  Image3->Picture->Bitmap->Assign(pBmp);
  Image4->Picture->Bitmap->Assign(pBmp);
}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::FormDestroy(TObject *Sender)
{
  delete pBmp;
}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::SendMail(TObject *Sender)
{
  // ��������� ��������� �������� ����������� �����
  ShellExecute(Handle,"open","mailto:tgm80@mail.ru",0,0,SW_SHOW);
}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::ImageLogoOffMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  ImageLogoOff->Visible = false;
  ImageLogoOn->Visible = true;
  Timer1->Enabled = true;

}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::Timer1Timer(TObject *Sender)
{
  ImageLogoOn->Visible = false;
  ImageLogoOff->Visible = true;

}
//---------------------------------------------------------------------------

void __fastcall TAboutForm::ImageLogoOnMouseMove(TObject *Sender,
      TShiftState Shift, int X, int Y)
{
  Timer1->Enabled = false;
  Timer1->Enabled = true;
}
//---------------------------------------------------------------------------

