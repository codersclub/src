//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop

#include "size.h"
#include "main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma link "CSPIN"
#pragma resource "*.dfm"
TSizeForm *SizeForm;
//---------------------------------------------------------------------------
__fastcall TSizeForm::TSizeForm(TComponent* Owner)
  : TForm(Owner)
{
}
//---------------------------------------------------------------------------
void __fastcall TSizeForm::FormCreate(TObject *Sender)
{
  EditWidth->Value = MainForm->X;
  EditHeight->Value = MainForm->Y;
}
//---------------------------------------------------------------------------
void __fastcall TSizeForm::BitBtn1Click(TObject *Sender)
{
  MainForm->X = EditWidth->Value;
  MainForm->Y = EditHeight->Value;

}
//---------------------------------------------------------------------------
void __fastcall TSizeForm::FormClose(TObject *Sender, TCloseAction &Action)
{
  EditWidth->Value = MainForm->X;
  EditHeight->Value = MainForm->Y;

}
//---------------------------------------------------------------------------
