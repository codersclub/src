//---------------------------------------------------------------------------

#include <vcl.h>
#pragma hdrstop
USERES("tgm.res");
USEFORM("main.cpp", MainForm);
USEUNIT("generate.cpp");
USEFORM("size.cpp", SizeForm);
USEFORM("about.cpp", AboutForm);
USEUNIT("gifimage.pas");
USEUNIT("palette.cpp");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
  try
  {
     Application->Initialize();
     Application->Title = "TGM";
     Application->CreateForm(__classid(TMainForm), &MainForm);
     Application->CreateForm(__classid(TSizeForm), &SizeForm);
     Application->CreateForm(__classid(TAboutForm), &AboutForm);
     Application->Run();
  }
  catch (Exception &exception)
  {
     Application->ShowException(&exception);
  }
  return 0;
}
//---------------------------------------------------------------------------
