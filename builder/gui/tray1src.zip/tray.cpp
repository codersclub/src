//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
USERES("tray.res");
USEFORM("mainform.cpp", Form1);
USERES("TRAYICON.res");
//---------------------------------------------------------------------------
WINAPI WinMain(HINSTANCE, HINSTANCE, LPSTR, int)
{
    try
    {
        Application->Initialize();
        Application->CreateForm(__classid(TForm1), &Form1);
        ShowWindow(Application->Handle,SW_HIDE);
        Application->MainForm->Visible = false;
        Application->ShowMainForm = false;

        Application->Run();
    }
    catch (Exception &exception)
    {
         Application->ShowException(&exception);
    }
    return 0;
}
//---------------------------------------------------------------------------
