//---------------------------------------------------------------------------
#ifndef mainformH
#define mainformH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <Menus.hpp>
//---------------------------------------------------------------------------
#define WM_TRAYNOTIFY  (WM_USER + 1001)


class TForm1 : public TForm
{
__published:	// IDE-managed Components
    TPopupMenu *PopupMenu1;
    TMenuItem *Unload1;
    TButton *UnloadBtn;
    void __fastcall UnloadBtnClick(TObject *Sender);
    
private:	// User declarations
    Graphics::TIcon *TrayIcon;
    void __fastcall WMTrayNotify(TMessage &Msg);
    void __fastcall RemoveIcon();
    void __fastcall AddIcon();
    void __fastcall AppOnMinimize(TObject *Sender);
    void __fastcall AppOnRestore(TObject *Sender);

public:		// User declarations
    __fastcall TForm1(TComponent* Owner);
    __fastcall ~TForm1();

BEGIN_MESSAGE_MAP
    MESSAGE_HANDLER(WM_TRAYNOTIFY,TMessage,WMTrayNotify)
END_MESSAGE_MAP(TForm)
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
