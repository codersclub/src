//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop

// The first constant is the ID of the trayicon. The value
// is arbitrary. If your program displays more than one tray
// icon at a time, choose a unique ID for each icon.
// The char * constant is the hint text for the tray icon.
// The last constant is a user defined message that the tray
// will send to our window handle for tray mouse events.
const int IDC_TRAY1      = 1005;
const char *HINT_MESSAGE = "Tray Hint Message";

#include <shellapi.h>
#include "mainform.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
    : TForm(Owner)
{
    // Load the icon from the EXE's resources
    TrayIcon = new Graphics::TIcon;
    TrayIcon->Handle=LoadImage(HInstance,
                              "LITTLEICON",
                              IMAGE_ICON,
                              0,0,
                              0);

    // Add the icon to the taskbar
    AddIcon();

    Application->OnMinimize = AppOnMinimize;
    Application->OnRestore  = AppOnRestore;
}
//---------------------------------------------------------------------------
__fastcall TForm1::~TForm1()
{
    // Remove the icon from the tray, and delete
    // the TIcon pointer that we initially created.
    RemoveIcon();
    delete TrayIcon;
}

void __fastcall TForm1::WMTrayNotify(TMessage &Msg)
{
    // The LPARAM of the message identifies the type of mouse message.
    // When they right click, show the popup menu. When they double
    // click with the left mouse, show the form.
    switch(Msg.LParam)
    {
        case WM_RBUTTONUP:
            POINT WinPoint;           // find the mouse cursor
            GetCursorPos(&WinPoint);  // using api function, store
            SetForegroundWindow(Handle);
            PopupMenu1->Popup(WinPoint.x,WinPoint.y);
            PostMessage(Handle, WM_NULL, 0,0);
            break;
        case WM_LBUTTONDBLCLK:
            Application->Restore();
            break;
    }
}

//---------------------------------------------------------------------------
void __fastcall TForm1::UnloadBtnClick(TObject *Sender)
{
    // Terminate the app when they choose the upload option
    Application->Terminate();
}

void __fastcall TForm1::AddIcon()
{
    // Use the Shell_NotifyIcon API function to
    // add the icon to the tray.
    NOTIFYICONDATA IconData;
    IconData.cbSize = sizeof(NOTIFYICONDATA);
    IconData.uID    = IDC_TRAY1;
    IconData.hWnd   = Handle;
    IconData.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
    IconData.uCallbackMessage = WM_TRAYNOTIFY;
    lstrcpy(IconData.szTip, HINT_MESSAGE);
    IconData.hIcon  = TrayIcon->Handle;

    Shell_NotifyIcon(NIM_ADD,&IconData);
}

void __fastcall TForm1::RemoveIcon()
{
    NOTIFYICONDATA IconData;
    IconData.cbSize = sizeof(NOTIFYICONDATA);
    IconData.uID    = IDC_TRAY1;
    IconData.hWnd   = Handle;
    IconData.hIcon  = TrayIcon->Handle;

    Shell_NotifyIcon(NIM_DELETE,&IconData);
}

//---------------------------------------------------------------------------
void __fastcall TForm1::AppOnMinimize(TObject *Sender)
{
    ShowWindow(Application->Handle, SW_HIDE);
    Visible = false;
}

void __fastcall TForm1::AppOnRestore(TObject *Sender)
{
    ShowWindow(Application->Handle, SW_SHOW);
    Visible = true;

    SetForegroundWindow(Handle);
}

//---------------------------------------------------------------------------
