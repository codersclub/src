<html>

<head>
<meta http-equiv="Content-Type" content="text/html; charset=windows-1251">
<meta name="keywords"
content="������������, ���������, delphi, pascal, cpp, hardware, web, ���-������, ������, ��������, ����, manual, Java, C, C++, ��������, ���������, odbc, jdbc, programm, protocols, ���������, �������, �����applet, java, design, ������, ������, ���, Free, counters, Trackers, Guestbooks, Access Logs, Banners, Graphics, Banner ads, Fonts, Form Mailer, form mailers, graphics, icons, games, freeware, shareware, forms, guestbooks, Java, Javascript, contests, puzzles, fonts, font resources, E-mail programs, reminder services, product samples, samples, Email services, E-mail services, advertising, graphics, free banner ads, free World Wide Web resources, counters, Trackers, Guestbooks, Access Logs, Banners, Graphics, Banner ads, Fonts, Form Mailer, form mailers, graphics, icons, games, freeware, shareware, forms, guestbooks, Java, Javascript, contests, puzzles, fonts, font resources, E-mail programs, reminder services, product samples, samples, Email services, E-mail services, advertising, graphics, free banner ads, free World Wide Web resources">
<meta name="description" content="���������">
<meta NAME="RESOURCE-TYPE"
CONTENT="pop hypertext sources hypermedia server scripting shtml phtml html developer code base tools open source web site browser free software webmaster cgi dhtml dynamic content netscape explorer shareware download website construction free tutorial news design maintenance page hit cvs mailing list projects httpd mod_perl mod www htdig xml perl scripts script server-side-include apache database MySQL mysql msql postres postresql module linux online cpp Visual Basic JavaScript delphi wap job informer java opengl directx">
<title>����� ����������� - ���������.RU</title>
<style type="text/css">
A.black:link {COLOR: #000000; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.black:visited {COLOR: #000000; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.black:hover {COLOR: #FFFFFF; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.blue:link {COLOR: #0441A6; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.blue:visited {COLOR: #0441A6; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.blue:hover {COLOR: #2776FA; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.red:link {COLOR: #FF0000; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.red:visited {COLOR: #FF0000; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.red:hover {COLOR: #FF0000; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.white:link {COLOR: #FFFFFF; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.white:visited {COLOR: #FFFFFF; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
A.white:hover {COLOR: #FFFFFF; TEXT-DECORATION: none;FONT-FAMILY: Arial,Verdana,Tahoma,sans-serif; FONT-SIZE: 9pt}
.b {text-decoration: none; color:#FF0000;} 
.b:hover {color:#7785FF;}
.c {text-decoration: none; color:#000000;} 
.c:hover {color:#FFFFFF;}
TD.colon {COLOR: #000000; FONT-FAMILY: "MS Sans Serif", sans-serif; FONT-SIZE: 9pt}
</style>
</head>

<body topmargin="0" leftmargin="0" , marginwidth="0" marginheigth="0" bgcolor="white">

<form method="get" action="/cgi-bin/sources/search/search.cgi">
  <input type="hidden" name="stpos" value="0"><div align="center"><center><table border="0"
  cellpadding="0" cellspacing="0" width="99%">
    <tr>
      <td valign="bottom" width="300"><table border="0" cellpadding="0" cellspacing="0"
      width="287">
        <tr>
          <td colspan="2" bgcolor="#A5E4A7" valign="middle" align="center"><b>WWW.���������.��</b></td>
          <td bgcolor="#000080" valign="middle" align="center"><b><font face="Tahoma"
          style="font-size: 8pt" size="-1" color="#FFFFFF">cpp.sources.ru</font></b></td>
        </tr>
        <tr>
          <td bgcolor="#000080" valign="middle" align="center"><b><font face="Tahoma"
          style="font-size: 8pt" size="-1" color="#FFFFFF">java.sources.ru</font></b></td>
          <td bgcolor="#C0C0C0" valign="middle" align="center"><font face="Tahoma"
          style="font-size: 8pt" size="-1"><b>web.sources.ru</b></font></td>
          <td bgcolor="#A5E4A7" valign="middle" align="center"><font face="Tahoma"
          style="font-size: 8pt" size="-1"><b>soft.sources.ru</b></font></td>
        </tr>
        <tr>
          <td bgcolor="#C0C0C0" valign="middle" align="center"><font face="Tahoma"
          style="font-size: 8pt" size="-1"><b>jdbc.sources.ru</b></font></td>
          <td bgcolor="#A5E4A7" valign="middle" align="center"><font face="Tahoma"
          style="font-size: 8pt" size="-1"><b>asp.sources.ru</b></font></td>
          <td bgcolor="#000080" valign="middle" align="center"><b><font face="Tahoma"
          style="font-size: 8pt" size="-1" color="#FFFFFF">api.sources.ru</font></b></td>
        </tr>
      </table>
      </td>
      <td align="right"><table border="0" cellpadding="2" width="468" height="60">
        <tr>
          <td align="center">
        <a class=blue href="http://pascal.sources.ru/cd/index.htm"><img border=0 height=14 width=14 src="/img/cd0.gif">
        <b>��� ��������� � ����� �� �������-�����!</b>
          </td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td valign="top" colspan="2"><table border="0" cellpadding="0" cellspacing="0"
      width="100%">
        <tr>
          <td align="center" valign="bottom" width="100"><a class="blue" href="cpp/mfc/index.htm"><img
          src="/img/down.gif" width="22" height="22" border="0"></a></td>
          <td align="center"><font face="Tahoma" style="font-size: 8pt" size="-1">&nbsp; </font><input
          type="text" size="38" name="query" value> <input type="submit" value="�����"><input
          TYPE="Radio" NAME="stype" VALUE="AND" checked>&quot;AND&quot; <input TYPE="Radio"
          NAME="stype" VALUE="OR">&quot;OR&quot;</td>
          <td align="center"></td>
        </tr>
      </table>
      </td>
    </tr>
    <tr>
      <td colspan="2"><table border="0" cellpadding="0" cellspacing="1" width="100%">
        <tr>
          <td align="center" width="11%" bgcolor="#E0E0C6"><a
          href="/"><font color="#000000" size="2">�� �������</font></a></td>
          <td align="center" width="20%" bgcolor="#E0E0C6"><a
          href="/subscribe.shtml"><font color="#000000" size="2">����������� �� �������</font></a></td>
          <td align="center" width="11%" bgcolor="#E0E0C6"><a href="http://forum.sources.ru/"><font color="#000000" size="2">�����</font></a></td>
          <td align="center" width="9%" bgcolor="#E0E0C6"><a href="/books/index.html"><font color="#000000" size="2">�����</font></a></td>
          <td align="center" width="13%" bgcolor="#E0E0C6"><a href="http://www.countries.ru/"><font color="#000000" size="2">������ ����</font></a></td>
          <td align="center" width="29%" bgcolor="#E0E0C6"><!--#include virtual="/cgi-bin/sources/times/numberuser.cgi"--></td>
        </tr>
      </table>
      </td>
    </tr>
  </table>
  </center></div>
</form>
<div align="center"><center>

<table border="0" cellpadding="0" cellspacing="7" width="100%">
  <tr>
    <td valign="top" width="150"><table bgcolor="#000080" cellspacing="0" border="0">
      <tr>
        <td><p align="center"><b><font color="#FFFFFF" face="Tahoma"><small>�������:</small></font></b></td>
      </tr>
      <tr align="center">
        <td align="center"><table bgcolor="#ffffff" cellspacing="0" border="0">
          <tr>
            <td height="60" valign="top"><table border="0" cellpadding="0" cellspacing="0">
              <tr>
                <td width="180" bgcolor="#A5E4A7" colspan="2">&nbsp;<b><font face="Tahoma"><small>�������������:</small></font></b></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/java/index.html"><b>Java</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/jscript/index.html"><b>Java Scripts</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/delphi/index.html"><b>Delphi</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="http://pascal.sources.ru/"><b>Pascal</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/kylix/index.html"><b>Kylix</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/cpp/index.html"><b>C / C++ / Visual C++</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/builder/index.html"><b>�++ Builder</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/vb/index.html"><b>Visual Basic</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/asm/index.html"><b>ASM</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="http://palmos.sources.ru/"><b>PalmOS</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/www/index.html"><b>WWW �������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/wap/index.html"><b>WAP</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="http://forum.sources.ru/"><b>�����</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><b><a class="blue" href="/books/index.html">�����</a></b></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><b><a class="blue" href="/catalog/index.html">������� ������</a></b></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/authors/index.html"><b>������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="red" href="/informer.shtml"><b>��������� �� ����� �����!</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center"><img src="/img/t1.gif" width="8" height="6"></td>
                <td></td>
              </tr>
              <tr>
                <td bgcolor="#A5E4A7" colspan="2" valign="middle">&nbsp;<a href="/protocols/index.html"><b><font
                face="Tahoma" color="black" style="text-decoration: none"><small>���������</small></font></b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/protocols/http_learning.shtml"><b>HTTP</b></a>, <a class="blue"
                href="/protocols/ftp_learning.shtml"><b>FTP</b></a>, <a class="blue"
                href="/protocols/rpc_learning.shtml"><b>RPC</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/protocols/smtp_learning.shtml"><b>SMTP</b></a> <a class="blue"
                href="/protocols/pop3_learning.shtml"><b>POP3</b></a> <a class="blue"
                href="/protocols/imap4_learning.shtml"><b>IMAP4</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/protocols/snmp_learning.shtml"><b>SNMP</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/protocols/bsp08/index.html"><b>IPX/SPX</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center"><img src="/img/t1.gif" width="12" height="10"></td>
                <td></td>
              </tr>
              <tr>
                <td bgcolor="#A5E4A7" colspan="2" valign="middle">&nbsp;<b><font face="Tahoma"><small>������</small></font></b></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/hardware/index.html"><b>������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/win/index.html"><b>Windows</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center"><img src="/img/t1.gif" width="12" height="10"></td>
                <td></td>
              </tr>
              <tr>
                <td bgcolor="#A5E4A7" colspan="2" valign="middle">&nbsp;<b><font face="Tahoma"><small>������</small></font></b></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/news/20010609.shtml"><b>������������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/cgi-bin/sources/pic.cgi"><b>������ ��������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="/anekdot/index.html"><b>�������� � �������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center">�</td>
                <td><a class="blue" href="http://www.etenders.ru/digcameras.shtml"><b>�������� ������</b></a></td>
              </tr>
              <tr>
                <td valign="middle" align="center"><img src="/img/t1.gif" width="12" height="10"></td>
                <td></td>
              </tr>
            </table>
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    <div align="center"><center><table border="0" cellpadding="0" cellspacing="0">
      <tr>
        <td height="70"><font face="Tahoma" style="font-size: 8pt" size="-1"><br>
        <form TARGET="_top" ACTION="http://subscribe.ru/member/quick" METHOD="POST">
          <input type="hidden" name="action" value="quick"><input type="hidden" name="grp"
          value="comp.soft.prog.sources"><table BORDER="1" CELLSPACING="0" CELLPADDING="2">
            <tr>
              <td BGCOLOR="#FFFFFF" ALIGN="CENTER" VALIGN="middle"><font SIZE="-1" color="black">�����
              ��������� �� WWW.���������.RU<font><br>
              <font SIZE="2"><input TYPE="text" NAME="email" SIZE="20" MAXLEN="100"
              VALUE="��� e-mail" style="font-size: 9pt"> <input TYPE="submit" VALUE="OK"
              style="font-size: 9pt"> </font></font></font></td>
            </tr>
          </table>
        </form>
        <p></font>E-mail:&nbsp;<br><a href="mailto:purpe@pisem.net">�������������</a><br></font>
        <br>
        ��������: <br>
        <a href="http://allbest.ru/libraries.htm" target="_blank"><img
        src="http://allbest.ru/lib883.gif" width="88" height="31"
        alt="���������� ���������� ����" border="0"></a><br>
        <br>
        <a href="http://alexeenko.prima.susu.ac.ru" target="_blank"><img
        src="http://alexeenko.prima.susu.ac.ru/img/ecrypt.gif" width="88" height="31"
        alt="������������, ������������, ����������, ������, ������������,
  ������, PGP. ��������� �������� ������������� ���������� ����������
  (RSA, IDEA, ����, Blowfish). ��������� ��� ������ ����������" border="0"></a><br>
        <br>
        <a href="http://yusoft.pp.ru/" target="_blank"><img
        src="http://yusoft.kulichki.com/images/ban88x31_1.gif" border="0" width="88" height="31"
        alt="��� � ���������������� ������ � �����������������"></a><br>
        <br>
<!--TopList COUNTER-->        <a target="_top" href="http://top.list.ru/jump?from=89876"><script language="JavaScript"><!--
d=document;a='';a+=';r='+escape(d.referrer)
js=10//--></script><script
        language="JavaScript1.1"><!--
a+=';j='+navigator.javaEnabled()
js=11//--></script><script language="JavaScript1.2"><!--
s=screen;a+=';s='+s.width+'*'+s.height
a+=';d='+(s.colorDepth?s.colorDepth:s.pixelDepth)
js=12//--></script><script
        language="JavaScript1.3"><!--
js=13//--></script><script language="JavaScript"><!--
d.write('<img src="http://top.list.ru/counter'+
'?id=89876;t=57;js='+js+a+';rand='+Math.random()+
'" alt="TopList" '+ 'border=0 height=31 width=88>')
if(js>11)d.write('<'+'!-- ')//--></script><noscript><img
        src="http://top.list.ru/counter?js=na;id=89876;t=57" border="0" height="31" width="88"
        alt="TopList"></noscript><script language="JavaScript"><!--
if(js>11)d.write('--'+'>')//--></script></a><!--TopList COUNTER--><a
        href="http://counter.rambler.ru/top100/"><img
        src="http://counter.rambler.ru/top100.cnt?163871" alt="Rambler's Top100" width="1"
        height="1" border="0"></a> <!-- SpyLOG f:0211 --> <script language="javascript"> 
u="u1624.10.spylog.com";d=document;nv=navigator;na=nv.appName;p=0;j="N"; 
d.cookie="b=b";c=0;bv=Math.round(parseFloat(nv.appVersion)*100); 
if (d.cookie) c=1;n=(na.substring(0,2)=="Mi")?0:1;rn=Math.random(); 
z="p="+p+"&rn="+rn+"&c="+c;if (self!=top) {fr=1;} else {fr=0;} 
sl="1.0";</script><script
        language="javascript1.1"> 
pl="";sl="1.1";j = (navigator.javaEnabled()?"Y":"N");</script> <script language="javascript1.2"> 
sl="1.2";s=screen;px=(n==0)?s.colorDepth:s.pixelDepth; 
z+="&wh="+s.width+'x'+s.height+"&px="+px; 
</script><script
        language="javascript1.3"> 
sl="1.3"</script><script language="javascript"> 
y="";y+="<a href='http://"+u+"/cnt?f=3&p="+p+"&rn="+rn+"' target=_blank>"; 
y+="<img src='http://"+u+"/cnt?"+z+"&j="+j+"&sl="+sl+ 
"&r="+escape(d.referrer)+"&fr="+fr+"&pg="+escape(window.location.href); 
y+="' border=0 width=88 height=31 alt='SpyLOG'>"; 
y+="</a>"; d.write(y);if(!n) { d.write("<"+"!--"); }//--></script><noscript> <a
        href="http://u1624.10.spylog.com/cnt?f=3&amp;p=0" target="_blank"><img
        src="http://u1624.10.spylog.com/cnt?p=0" alt="SpyLOG" border="0" width="88" height="31"> </a></noscript><script
        language="javascript1.2"><!-- 
if(!n) { d.write("--"+">"); }//--></script> <!-- SpyLOG --> <!-- HotLog --> <script language="javascript">
hotlog_js="1.0";hotlog_d=document; hotlog_n=navigator;hotlog_rn=Math.random();
hotlog_n_n=(hotlog_n.appName.substring(0,3)=="Mic")?0:1;
hotlog_r=""+hotlog_rn+"&s=14399&r="+escape(hotlog_d.referrer)+"&pg="+
escape(window.location.href);
hotlog_d.cookie="hotlog=1"; hotlog_r+="&c="+(hotlog_d.cookie?"Y":"N");
hotlog_d.cookie="hotlog=1; expires=Thu, 01-Jan-70 00:00:01 GMT"</script> <script
        language="javascript1.1">
hotlog_js="1.1";hotlog_r+="&j="+(navigator.javaEnabled()?"Y":"N")</script> <script language="javascript1.2">
hotlog_js="1.2";hotlog_s=screen;
hotlog_r+="&wh="+hotlog_s.width+'x'+hotlog_s.height+"&px="+((hotlog_n_n==0)?
hotlog_s.colorDepth:hotlog_s.pixelDepth)</script> <script
        language="javascript1.3">hotlog_js="1.3"</script> <script language="javascript">hotlog_r+="&js="+hotlog_js;
hotlog_d.write("<img src=\"http://hit2.hotlog.ru/cgi-bin/hotlog/count?"+
hotlog_r+"&\" border=0 width=1 height=1>")</script> <noscript><img
        src="http://hit2.hotlog.ru/cgi-bin/hotlog/count?s=14399" border="0" width="1" height="1"></noscript> <!-- /HotLog -->
        </td>
      </tr>
    </table>
    </center></div></td>
    <td valign="top" align="center">
    <table bgcolor="#000080" cellspacing="0" border="0" width="100%">
      <tr>
        <td><p align="left" width="100%"><font color="#FFFFFF" face="Tahoma"><b><small>&nbsp;
        ����� ����� �����������:</small></b></font></td>
      </tr>
    </table>



<!-- NEWS BAND -->
    <table cellspacing="0" border="0" width="100%">


<!--#include virtual="/cgi-bin/news/news.cgi?start=15"-->


    </table>
<!-- //NEWS BAND -->


    </td>


    <td valign="top" align="center" width="150">
<!--
    <table bgcolor="#000080" width="150" cellspacing="0" border="0">
      <tr>
        <td align="center"><strong><font color="#FFFFFF" face="Tahoma"><small>��������� �� CD</small></font></strong></td>
      </tr>
      <tr align="center">
        <td align="right">
	  <table bgcolor="#FFFFFF" cellspacing="1" border="0" cellpadding="2">
          <tr>
            <td width="180" bgcolor="#A5E4A7" colspan="2">&nbsp;<b><font face="Tahoma"><small>������ �������!</small></font></b></td>
          </tr>
          <tr>
            <td valign="middle" class="colon">
	      <A class="blue" href="http://pascal.sources.ru/cd/index.htm" target=_top><img border=0 width=60 height=60 vspace=4 hspace=4 align="left" src="http://pascal.sources.ru/img/cd_60.gif" alt="���������">
              <center>��������� ������<br>�� �������-����
	      <br><br><b>���������.Ru&nbsp;��&nbsp;CD</b></a>.</center>
            <br>
            </td>
          </tr>
          </table>
        </td>
      </tr>
    </table>

    <table>
      <tr><td></td></tr></table>
-->

    <table bgcolor="#000080" width="150" cellspacing="0" border="0">
      <tr>
        <td align="center"><strong><font color="#FFFFFF" face="Tahoma"><small>��������</small></font></strong></td>
      </tr>
      <tr align="center">
        <td align="right"><table bgcolor="#FFFFFF" cellspacing="0" border="0" cellpadding="2">
          <tr>
            <td valign="middle" class="colon">
            <br>
            ��� �������� ���������� � ������� �����������: <a
            href="mailto:leprecon@sources.ru">leprecon@sources.ru</a> <br>
            <br>
            <br>
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table>


    <table>
      <tr>
        <td></td>
      </tr>
    </table>
    <div align="center"><center><table>
      <tr>
        <td></td>
      </tr>
    </table>
    </center></div><div align="center"><div align="center"><center><table bgcolor="#000080"
    width="150" cellspacing="0" border="0">
      <tr>
        <td align="center"><strong><font color="#FFFFFF" face="Tahoma"><small>�������
        (English)</small></font></strong></td>
      </tr>
      <tr align="center">
        <td align="center"><table bgcolor="#ffffff" cellspacing="0" border="0">
          <tr>
            <td valign="middle" class="colon"><font color="#FF0000">17.05.2002</font><br>
            �������� TMT Development Corporation �������� ������� �
            ������ ����������� <b>TMT Pascal 4.0 Multi-target</b> <a
            href="http://pascal.sources.ru/tmt/purchase.htm"><b>��&nbsp;����������
            �����</b></a>.<br>
            <br>
            <font color="#FF0000">27.11.2001</font><br>
            �������� ����� ������ <br>
            32-������� ����������� <br>
            ��� DOS, Win32 � OS/2<br>
            <a href="http://pascal.sources.ru/tmt/index.htm"><b>TMT Pascal 4.0</b></a>. <br>
            <br>
            <font color="#FF0000">08.05.2001</font><br>
            Borland ������������� Delphi 6, ������� � ��� <a
            href="http://www.borland.com/about/press/2001/del6released.html" target="_blank">RAD Web
            Services Development Platform</a>, �������������� XML, SOAP, WSDL and XSL.
            Delphi 6 �������� ��������� <a
            href="http://www.borland.com/delphi/del6/whatsnew.html" target="_blank">�����
            ������������</a> ����� ��� <a
            href="http://www.borland.com/delphi/del6/featurematrix/database.html" target="_blank">dbExpress/DataCLX</a>,
            <a href="http://www.borland.com/delphi/del6/featurematrix/datasnap.html" target="_blank">DataSnap</a>,
            <a href="http://www.borland.com/delphi/del6/featurematrix/websnap.html" target="_blank">WebSnap</a>
            � <a href="http://www.borland.com/delphi/del6/featurematrix/bizsnap.html" target="_blank">BizSnap</a>
            (�������� ��� �� <a href="http://www.borland.com/delphi/del6/datasheet.pdf">datasheet</a>
            � <a href="http://www.borland.com/delphi/del6/featurematrix/featurematrix.pdf">feature
            matrix</a>). Delphi 6 �������� � ������� (8 ����) �
            ��������� ���������: Enterprise, Professional � Personal. <br>
            <br>
            <font color="#FF0000">19.04.2001</font><br>
            ������ ����������, ��� �������������� �����
            ������� ������, ��� ADO XML ��� ADTG (Advanced Data TableGram) �
            ClientDataSet binary ��� XML ������. ��������� ��������
            ��������� ��� C++Builder 5 Enterprise � Delphi 5 Enterprise.<br>
            <a href="http://www.drbob42.com/Delphi5/examin16.htm">���������</a><br>
            <br>
            <a class="blue" href="/news_arch.shtml"><b>����� �����������</b></a><br>
            <br>
            </td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </center></div><table>
      <tr>
        <td></td>
      </tr>
    </table>
    </div></div></td>
  </tr>
</table>
</center></div><div align="center"><center>

<table border="0" cellpadding="0" cellspacing="3" width="468">
  <tr>
    <td width="154"><!-- LBE_LITE --> <script>
// <!--
rand = Math.round((Math.random() * (10000 - 1)));
document.write("<a href=http://lite.lbe.ru/cgi-bin/href/castle?" + rand + " target=_blank><img src=http://lite.lbe.ru/cgi-bin/banner/castle?" + rand + " width=468 height=60 border=0 alt=LBE_LITE ismap></a><br>");
// -->
</script> <noscript> <br>
</noscript><!-- LBE_LITE -->    </td>
  </tr>
</table>
</center></div>

<p align="center"><a href="/cit.html"><font color="#FFFFFF">&nbsp;1</font></a></p>
</body>
</html>
