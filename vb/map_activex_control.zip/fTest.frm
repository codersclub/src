VERSION 5.00
Object = "*\A..\BREGION.vbp"
Begin VB.Form fDemo 
   Caption         =   "Demo"
   ClientHeight    =   5250
   ClientLeft      =   2505
   ClientTop       =   1515
   ClientWidth     =   7335
   FillColor       =   &H0080FFFF&
   BeginProperty Font 
      Name            =   "Tahoma"
      Size            =   8.25
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   Icon            =   "fTest.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   5250
   ScaleWidth      =   7335
   Begin BoneRegionControl.BRGN BRGN1 
      Height          =   1575
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3675
      _ExtentX        =   6482
      _ExtentY        =   2778
      BackgroundPicture=   "fTest.frx":14A2
      BackgroundPictureHeight=   335
      BackgroundPictureWidth=   1765
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Tahoma"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BorderStyle     =   2
      EditMode        =   -1  'True
      ZoomFactor      =   2.5
      ShowTool        =   -1  'True
      EnableEdit      =   -1  'True
      Redraw          =   -1  'True
   End
   Begin VB.Menu m_demo 
      Caption         =   "Demo"
      Begin VB.Menu m_edit 
         Caption         =   "Edit"
         Checked         =   -1  'True
      End
      Begin VB.Menu m3 
         Caption         =   "-"
      End
      Begin VB.Menu m_add 
         Caption         =   "Add Rectangle"
         Index           =   1
      End
      Begin VB.Menu m_add 
         Caption         =   "Add Oval"
         Index           =   2
      End
      Begin VB.Menu m_add 
         Caption         =   "Add Round Rectangle"
         Index           =   3
      End
      Begin VB.Menu m_add 
         Caption         =   "Add Free"
         Index           =   4
      End
      Begin VB.Menu m1 
         Caption         =   "-"
      End
      Begin VB.Menu m_open 
         Caption         =   "Open File"
      End
      Begin VB.Menu m2 
         Caption         =   "-"
      End
      Begin VB.Menu m_show 
         Caption         =   "Show elements "
         Index           =   0
      End
      Begin VB.Menu m_show 
         Caption         =   "Show elements (animation)"
         Index           =   1
      End
      Begin VB.Menu m10 
         Caption         =   "-"
      End
      Begin VB.Menu m_hide 
         Caption         =   "Hide"
      End
      Begin VB.Menu m4 
         Caption         =   "-"
      End
      Begin VB.Menu m_exit 
         Caption         =   "Exit"
      End
   End
End
Attribute VB_Name = "fDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)






Private Sub BRGN1_ChangeSmth(Value As Variant, Index As Long)
  'Debug.Print Value, Index
End Sub

Private Sub BRGN1_SelectedChange(OldIndex As Long, NewIndex As Long)
  Debug.Print "SelectedChange " & OldIndex & " " & NewIndex
End Sub


Private Sub Form_Load()

  BRGN1.FileName = App.Path & "\Test2.rgn"
  BRGN1.FileRead
    
End Sub

Private Sub Form_Resize()
On Error Resume Next
   BRGN1.Move BRGN1.Left, BRGN1.Top, Me.ScaleWidth - BRGN1.Left - 30, Me.ScaleHeight - BRGN1.Top - 30
End Sub

Private Sub m_add_Click(Index As Integer)
  Select Case Index
    Case 1: BRGN1.AddElement plgRectangle, "Rectangle", 1, &H80FFFF, &HFF&, 50
    Case 2: BRGN1.AddElement plgElliptic, "Oval", 1, &H80FF80, &HFF&, 100
    Case 3: BRGN1.AddElement plgRoundRectangle, "Round Rectangle", 1, &HFF0000, &HFFFFFF, &H80FFFF
    Case 4: BRGN1.AddElement plgNormal, "Free", 1, &HFF0000, &HFFFFFF, &H80FFFF
  End Select
  BRGN1.SelectElement BRGN1.ElementsCount
End Sub

Private Sub m_edit_Click()
Dim i As Integer

  m_edit.Checked = Not (m_edit.Checked)
  BRGN1.EnableEdit = m_edit.Checked
  BRGN1.EditMode = m_edit.Checked
  For i = 1 To m_add.Count
    m_add(i).Enabled = m_edit.Checked
  Next

End Sub

Private Sub m_exit_Click()
  Unload Me
End Sub


Private Sub m_hide_Click()
  BRGN1.Visible = m_hide.Checked
  m_hide.Checked = Not (m_hide.Checked)
End Sub

Private Sub m_open_Click()
Dim sFile As String
  sFile = BRGN1.FileName
  If sFile = App.Path & "\Test1.rgn" Then
    sFile = App.Path & "\Test2.rgn"
  Else
    sFile = App.Path & "\Test1.rgn"
  End If
  BRGN1.FileName = sFile
  BRGN1.FileRead

End Sub


Private Sub m_show_Click(Index As Integer)
Dim l As Long
Dim bAnimation As Boolean

  bAnimation = CBool(Index)
  
  For l = 1 To BRGN1.ElementsCount
    BRGN1.EnsureVisible l, bAnimation
    DoEvents
    BRGN1.SelectElement l
    Sleep 400
  Next
  
End Sub


