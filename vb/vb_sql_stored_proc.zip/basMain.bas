Attribute VB_Name = "basMain"
Option Explicit

Public g_objCn As New ADODB.Connection
Public Const g_strConnectionString = "Northwind"

Sub main()
    g_objCn.Open g_strConnectionString

    frmTest.Show
End Sub



