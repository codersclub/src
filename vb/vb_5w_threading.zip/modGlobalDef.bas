Attribute VB_Name = "modGlobalDef"
Option Explicit
Public FullPathName As String
Public FinalWait As Boolean
Public hMutex As Long
Public ThreadComlete As Boolean
Public CountWindows As Integer
Public FullPath As String
Public constName As String

