Hi!
Finally it is here: The first multithreading example on PSC.
You can use my class for free, I dont want any credits, but be careful!
Multithreading in VB is very tempramental. Save your work every time you start your project
because VB might crash.
Thank you for using this code, and if you like it, vote for me please!
Philipp Weidmann