Attribute VB_Name = "MainMod"
Private Declare Function StrFormatByteSize Lib "shlwapi" Alias "StrFormatByteSizeA" (ByVal dw As Long, ByVal pszBuf As String, ByRef cchBuf As Long) As String
Public Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpString As Any, ByVal lpFileName As String) As Long
Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Public CompressionLevel As Integer
Public ObJClsCms As ClsCms
Public lnglngResult As Long
Public ChkWarningMsg As Boolean
Public ExtractPath As String
Public sString As String
Public lLength As Long
Public dFileName As String
Public LastDrive As String
Public ChkIfLoad As Boolean
Public LoadArchive As Boolean
Public ArchiveName As String
Public MoveMe As Boolean
Public ChkFastLoad As Boolean
Public CyTFile As String
Public FileListStart As Long
Public Header As String
Public TmpFile As String
Public FileList As String

'This function checks the compression level that wants
'to be used on your archives.
Public Function ChkCompressLvl(Level As Long) As Long
    If Level = 0 Then CompressionLevel = -1
    If Level = 1 Then CompressionLevel = 9
    If Level = 2 Then CompressionLevel = 6
    If Level = 3 Then CompressionLevel = 3
    If Level = 4 Then CompressionLevel = 1
    If Level = 5 Then CompressionLevel = 8
    If Level = 6 Then CompressionLevel = 7
    If Level = 7 Then CompressionLevel = 5
    If Level = 8 Then CompressionLevel = 4
    If Level = 9 Then CompressionLevel = 2
    ChkCompressLvl = CompressionLevel
End Function

Public Function KillFileActive(Filen As String) As Boolean
    On Error GoTo FinaliseError
    Kill Filen
    KillFileActive = True
    Exit Function
FinaliseError:
    KillFileActive = False
End Function

'shlwapi.dll is used to get the format of converting bytes
'into KB and MB
Public Function FormatKB(ByVal Amount As Long) As String
    Dim Buffer As String
    Dim Result As String
    Buffer = Space$(255)
    Result = StrFormatByteSize(Amount, Buffer, Len(Buffer))
    If InStr(Result, vbNullChar) > 1 Then FormatKB = Left$(Result, InStr(Result, vbNullChar) - 1)
End Function

Public Function RemoveBackSlash(FileName As String) As String
    For M = 1 To Len(FileName)
        GetChr1 = Right(FileName, M)
        GetChr2 = Left(GetChr1, 1)
        If GetChr2 = "\" Or GetChr2 = "/" Then
            RemoveBackSlash = Right(GetChr1, Len(GetChr1) - 1)
            Exit Function
        End If
    Next M
End Function

'This sub is designed to centre a picture to a fixed set ratio
'of the oraginal size (In other words sets the ratio of the picture
'so it fits perfectly into the picture box returned by the target value
'without off setting the ratio size.
Public Sub CentrePic(Target As PictureBox, Source As StdPicture)
    On Error Resume Next
    Dim PicWidth As Integer
    Dim PicHeight As Integer
    Dim NewWidth As Integer
    Dim NewHeight As Integer
    Dim CenterX As Integer
    Dim CenterY As Integer
    PicWidth = Source.Width / 16.763
    PicHeight = Source.Height / 16.763
    Aspect = PicWidth / PicHeight
    If PicWidth > PicHeight Then
        NewWidth = Target.Width - 240
        NewHeight = Target.Width / Aspect
    Else
        NewWidth = Target.Height * Aspect
        NewHeight = Target.Height - 240
    End If
    CenterX = Target.Width / 2 - NewWidth / 2
    CenterY = Target.Height / 2 - NewHeight / 2
    Target.PaintPicture Source, CenterX, CenterY, NewWidth, NewHeight
End Sub
