To register the file type first compile the program then place it somewere
on your hard drive. Then open the "CreateType.reg" file and change both
<Location>'s to the shortcut to CyberCrypt.exe

Must do...

	<Location>'s For example:

	NOT
		C:\CyberCrypt\CyberCrypt.exe
	DO
		C:\\CyberCrypt\\CyberCrypt.exe

About...

What does the program do?

It encrypts files into a CyT file BUT! NOW COMPRESSION!!!.
It also decrypts files out of a CyT file.

******************************

View program simple information.

*********Version 3.0**********

What I have added:

**Advances!**
'Added compression & compression leveling

**Disadvantages!**
Can't delete out of file, need to create a new archive. - But now working on it!
Can't use archives created in older versions of CyberCrypt - But now working on it!

*********Version 2.0**********

What I have added:

**Advances!**
'Better coding
'More file features
'Better unit
'Better dialogs
'Bug fixes
'Lot's of added code
'Settings now can be used
'Better buttons
'File sizes-Updated shows KB / MB as well as 11'bytes
'Help button
'File types
'File numbers
'Offsets
'New status bar!

**Disadvantages!**
Can't delete out of file, need to create a new archive.

*********Version 1.0**********

**Advances!**

Very fast and easy coding.
Works like winzip but without the compression.
Takes about 6 seconds for a 4 Meg file to be encrypted into archive.
Takes about 6 seconds / 12 to extract from CyT file.
Such simple code, you really can't find a bug.
Re-enter archive and add more files.
See shaded icons in the file lists.
Good dialogs (Main form and Versions form)

**Disadvantages!**
Can't delete out of file, need to create a new archive.

******************************
		

			HELP EMAIL TO...
			
			NeoBPI@Yahoo.com

		Please read the License agreement (License.txt)