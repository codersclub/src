VERSION 5.00
Begin VB.Form FrmSplash 
   BorderStyle     =   1  'Fixed Single
   ClientHeight    =   3240
   ClientLeft      =   15
   ClientTop       =   15
   ClientWidth     =   5040
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   Icon            =   "FrmSplash.frx":0000
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "FrmSplash.frx":030A
   ScaleHeight     =   3240
   ScaleWidth      =   5040
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer 
      Interval        =   3000
      Left            =   0
      Top             =   0
   End
End
Attribute VB_Name = "FrmSplash"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
    'If the program is running already then don't show the splash screen
    If App.PrevInstance = True Then Timer.Enabled = False: Unload Me: frmMain.Show
End Sub

Private Sub Timer_Timer()
    Timer.Enabled = False
    Unload Me
    frmMain.Show
End Sub
