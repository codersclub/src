VERSION 5.00
Begin VB.Form frmTest 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Test of CWinInetConnection Class"
   ClientHeight    =   5850
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7695
   Icon            =   "frmTest.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5850
   ScaleWidth      =   7695
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton cmdExit 
      Caption         =   "E&xit"
      Height          =   375
      Left            =   5160
      TabIndex        =   26
      Top             =   5400
      Width           =   2415
   End
   Begin VB.Frame Frame3 
      Caption         =   "Dial"
      Height          =   2415
      Left            =   120
      TabIndex        =   17
      Top             =   3360
      Width           =   2415
      Begin VB.CheckBox chkShow 
         Caption         =   "Show Offline Button"
         Height          =   255
         Left            =   120
         TabIndex        =   24
         Top             =   1800
         Width           =   2055
      End
      Begin VB.OptionButton optDial 
         Caption         =   "Dial Unattended"
         Height          =   195
         Index           =   3
         Left            =   120
         TabIndex        =   22
         Top             =   1440
         Width           =   1575
      End
      Begin VB.OptionButton optDial 
         Caption         =   "Force Promt"
         Height          =   195
         Index           =   2
         Left            =   120
         TabIndex        =   21
         Top             =   1080
         Width           =   1215
      End
      Begin VB.OptionButton optDial 
         Caption         =   "Force Unattended"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   20
         Top             =   720
         Width           =   1695
      End
      Begin VB.OptionButton optDial 
         Caption         =   "Force Online"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   19
         Top             =   360
         Value           =   -1  'True
         Width           =   1215
      End
      Begin VB.CommandButton cmdDial 
         Caption         =   "Dial..."
         Height          =   375
         Left            =   1440
         TabIndex        =   18
         Top             =   240
         Width           =   855
      End
   End
   Begin VB.Frame Frame2 
      Caption         =   "AutoDial"
      Height          =   2415
      Left            =   2640
      TabIndex        =   13
      Top             =   3360
      Width           =   2415
      Begin VB.CheckBox Check2 
         Caption         =   "Fail If Security Check"
         Height          =   255
         Left            =   120
         TabIndex        =   23
         Top             =   1800
         Width           =   2175
      End
      Begin VB.OptionButton optAutoDial 
         Caption         =   "Force Unattended"
         Height          =   195
         Index           =   1
         Left            =   120
         TabIndex        =   16
         Top             =   720
         Width           =   1695
      End
      Begin VB.OptionButton optAutoDial 
         Caption         =   "Force Online"
         Height          =   195
         Index           =   0
         Left            =   120
         TabIndex        =   15
         Top             =   360
         Value           =   -1  'True
         Width           =   1215
      End
      Begin VB.CommandButton cmdAutoDial 
         Caption         =   "Dial..."
         Height          =   375
         Left            =   1440
         TabIndex        =   14
         Top             =   240
         Width           =   855
      End
   End
   Begin VB.CommandButton cmdSetOfflineMode 
      Caption         =   "Set Global O&ffline Mode"
      Height          =   375
      Left            =   5160
      TabIndex        =   12
      Top             =   3960
      Width           =   2415
   End
   Begin VB.CommandButton cmdSetOnline 
      Caption         =   "Set Global O&nline Mode"
      Height          =   375
      Left            =   5160
      TabIndex        =   11
      Top             =   4440
      Width           =   2415
   End
   Begin VB.CommandButton cmdGoOnline 
      Caption         =   "Go &Online..."
      Height          =   375
      Left            =   5160
      TabIndex        =   10
      Top             =   4920
      Width           =   2415
   End
   Begin VB.PictureBox Picture1 
      BorderStyle     =   0  'None
      Height          =   495
      Left            =   120
      ScaleHeight     =   495
      ScaleWidth      =   615
      TabIndex        =   9
      Top             =   0
      Width           =   615
   End
   Begin VB.Frame Frame1 
      Caption         =   "Connection State Info"
      Enabled         =   0   'False
      Height          =   2775
      Left            =   120
      TabIndex        =   1
      Top             =   480
      Width           =   7455
      Begin VB.CheckBox Check1 
         Caption         =   "Local system has RAS installed."
         Height          =   375
         Index           =   5
         Left            =   120
         TabIndex        =   7
         Top             =   2040
         Width           =   5175
      End
      Begin VB.CheckBox Check1 
         Caption         =   "Local system uses a proxy server to connect to the Internet."
         Height          =   375
         Index           =   4
         Left            =   120
         TabIndex        =   6
         Top             =   1680
         Width           =   5175
      End
      Begin VB.CheckBox Check1 
         Caption         =   "Local system is in offline mode."
         Height          =   375
         Index           =   3
         Left            =   120
         TabIndex        =   5
         Top             =   1320
         Width           =   5175
      End
      Begin VB.CheckBox Check1 
         Caption         =   "Local system uses a modem to connect to the Internet."
         Height          =   375
         Index           =   2
         Left            =   120
         TabIndex        =   4
         Top             =   960
         Width           =   5175
      End
      Begin VB.CheckBox Check1 
         Caption         =   "Local system uses a local area network to connect to the Internet."
         Height          =   375
         Index           =   1
         Left            =   120
         TabIndex        =   3
         Top             =   600
         Width           =   5175
      End
      Begin VB.CheckBox Check1 
         Caption         =   "Local system has a valid connection to the Internet, but it may or may not be currently connected."
         Height          =   375
         Index           =   0
         Left            =   120
         TabIndex        =   2
         Top             =   240
         Width           =   7215
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         Caption         =   "Active Connection Name:"
         Height          =   195
         Left            =   120
         TabIndex        =   25
         Top             =   2400
         Width           =   1815
      End
   End
   Begin VB.CommandButton cmdGet 
      Caption         =   "&Get Connection State"
      Height          =   375
      Left            =   5160
      TabIndex        =   0
      Top             =   3480
      Width           =   2415
   End
   Begin VB.Label Label2 
      AutoSize        =   -1  'True
      Caption         =   "Label2"
      Height          =   195
      Left            =   840
      TabIndex        =   8
      Top             =   165
      Width           =   480
   End
End
Attribute VB_Name = "frmTest"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private oConnectionState As New CWinInetConnection

Private Sub RefreshData()

Dim i As Integer

On Error GoTo ERROR_HANDLER

With oConnectionState
    .Refresh
    If .IsConnected Then
        Label2 = "Local system is connected to the Internet"
        Set Picture1.Picture = LoadResPicture(101, vbResIcon)
    Else
        Label2 = "Local system is not connected to the Internet"
        Set Picture1.Picture = LoadResPicture(102, vbResIcon)
    End If
    Check1(0).Value = IIf(.IsConnectionConfigured, vbChecked, vbUnchecked)
    Check1(1).Value = IIf(.UseLAN, vbChecked, vbUnchecked)
    Check1(2).Value = IIf(.UseModem, vbChecked, vbUnchecked)
    Check1(3).Value = IIf(.IsOffline, vbChecked, vbUnchecked)
    Check1(4).Value = IIf(.UseProxy, vbChecked, vbUnchecked)
    Check1(5).Value = IIf(.IsRasInstalled, vbChecked, vbUnchecked)
    If Len(.ConnectionName) > 0 Then
        Label1.Caption = "Active Connection Name: '" & .ConnectionName & "'"
    End If
End With

For i = 0 To 5
    Check1(i).ForeColor = IIf(Check1(i).Value, vbButtonText, vbApplicationWorkspace)
Next i
        

Exit_Label:
    Exit Sub

ERROR_HANDLER:
    MsgBox "Error Number: " & Err.Number & vbCrLf & _
       "Description: " & Err.Description & vbCrLf & _
       "Module: " & "frmTest" & vbCrLf & _
       "Procedure: " & "RefreshData"
       GoTo Exit_Label


End Sub

Private Sub cmdAutoDial_Click()

    oConnectionState.Autodial Me.hWnd, ADF_FORCE_UNATTENDED

End Sub

Private Sub cmdDial_Click()

Dim lOption As DialsFlags

    If optDial(0).Value Then
        lOption = DF_FORCE_ONLINE
    ElseIf optDial(1).Value Then
        lOption = DF_FORCE_UNATTENDED
    ElseIf optDial(2).Value Then
        lOption = DF_DIAL_FORCE_PROMPT
    ElseIf optDial(3).Value Then
        lOption = DF_DIAL_UNATTENDED
    End If
    
    oConnectionState.Dial Me.hWnd, "Comset", lOption, CBool(chkShow.Value)
    
End Sub

Private Sub cmdExit_Click()
    Unload Me
End Sub

Private Sub cmdGet_Click()

    Call RefreshData

End Sub

Private Sub cmdGoOffline_Click()
    oConnectionState.GoOffline
End Sub

Private Sub cmdGoOnline_Click()

Dim strURL As String

strURL = InputBox("Enter URL, please.", "Go Online")

If Len(strURL) > 0 Then
    oConnectionState.GoOnline strURL, Me.hWnd
End If

End Sub

Private Sub cmdSetOfflineMode_Click()

    oConnectionState.SetGlobalOffline
    Call RefreshData
    
End Sub

Private Sub cmdSetOnline_Click()

    oConnectionState.SetGlobalOnline
    Call RefreshData
    
End Sub

Private Sub Command1_Click()

End Sub

Private Sub Form_Load()

    Call RefreshData

End Sub
