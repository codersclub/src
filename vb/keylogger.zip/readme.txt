WITNESS v5.2.0 - November 21, 2000
----------------------------------
Program By: zULuGriD


Table of Contents:

I......Getting Started
II.....Setting Up
III....Registering
IV.....Uninstalling



I - GETTING STARTED:
--------------------
To get started using WITNESS, run the SETUP.EXE file.
This will install WITNESS unto the system. You will
be asked to restart your computer. This must be done
to activate WITNESS and to start the logging. Please
note that once WITNESS is activated, it will auto-
matically run every time Windows starts, and will log
all keystrokes!!! Every 25 seconds, WITNESS checks
it's log file to see if it has logged 4KB of data.
Once it has, it automatically sends the log file to
the e-mail address specified in the options (default
is zulugrid@hotmail.com) and restarts the log file.
If you are using an unregistered version of WITNESS,
the WITNESS program will automatically turn itself
off once it has sent one log file. Once you register
WITNESS, it will run at all times unless closed by
the user.


II - SETTING UP:
----------------
WITNESS was designed to be invisible to the user. To
bring up WITNESS so you can change options, hold down
SHIFT and then press F12. You may have to minimize
other windows to see WITNESS. From here, you can see
what has been logged but not yet appended to the log
file, the status of the last sent e-mail, and the
contents that were included in the last e-mail. You
may also change the e-mail address that the log file
is sent to, and the e-mail server that is used to send
the e-mail. It is recommended that you use an e-mail
account from Hotmail.com and mail.hotmail.com as your
server. To continue WITNESS's logging, hit the Hide
button. If you want WITNESS to stop logging, simply
hit Exit. Please note that WITNESS will automatically
restart next time Window's is started.


III - REGISTERING:
------------------
WITNESS IS NOT FREE. It is shareware. Shareware is
designed so that people can try a program before they
pay for it. Shareware programs often have limitations.
In the case of WITNESS, its shareware limitation is
that only one log file will be sent each time WITNESS
is ran. Once you register, WITNESS will send unlimited
log files without closing itself. Registration is $10.
Please send check or money order paid to Jacob Allred
along with your name, address, and e-mail address to:

	Jacob Allred
	144 Bloomfield Way
	Folsom, CA 95630

The e-mail address is required for product update info
and to recieve your registration code. If you do not
include your e-mail address, you will *NOT* recieve a
registration code. Once you recieve your registration
code, hit SHIFT-F12 to enter the program options. Enter
your name and serial number AS SENT TO YOU IN E-MAIL!
Both name and serial are case sensitive!!!


IV - UNINSTALLING:
------------------
Simply run the uninstall program in the Start menu,
Programs, zULuGriD directory.