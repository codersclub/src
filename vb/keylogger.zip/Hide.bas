Attribute VB_Name = "Hide"
Option Explicit
Public Declare Function GetCurrentProcessId Lib "kernel32" _
    () As Long
Public Declare Function RegisterServiceProcess Lib "kernel32" _
    (ByVal dwProcessID As Long, ByVal dwType As Long) As Long
    
Sub HideMe()
    Dim ret As Long
    ret = RegisterServiceProcess(GetCurrentProcessId, 1)
End Sub
