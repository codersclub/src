VERSION 5.00
Begin VB.Form frmAbout 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "� ���������"
   ClientHeight    =   2685
   ClientLeft      =   2340
   ClientTop       =   1935
   ClientWidth     =   5625
   ClipControls    =   0   'False
   Icon            =   "frmAbout.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1853.235
   ScaleMode       =   0  'User
   ScaleWidth      =   5282.166
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picIcon 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000004&
      ClipControls    =   0   'False
      DrawMode        =   1  'Blackness
      ForeColor       =   &H80000008&
      Height          =   510
      Left            =   240
      Picture         =   "frmAbout.frx":000C
      ScaleHeight     =   32
      ScaleMode       =   0  'User
      ScaleWidth      =   32
      TabIndex        =   1
      TabStop         =   0   'False
      Top             =   120
      Width           =   510
   End
   Begin VB.CommandButton cmdOK 
      Cancel          =   -1  'True
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   345
      Left            =   3885
      TabIndex        =   0
      Top             =   2265
      Width           =   1260
   End
   Begin VB.Label Label1 
      Caption         =   "The Idler`s Company"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   -1  'True
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   240
      TabIndex        =   5
      Top             =   2280
      Width           =   2175
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      BorderStyle     =   6  'Inside Solid
      Index           =   1
      X1              =   112.686
      X2              =   5197.651
      Y1              =   1439.104
      Y2              =   1439.104
   End
   Begin VB.Label lblDescription 
      ForeColor       =   &H00000000&
      Height          =   1170
      Left            =   1080
      TabIndex        =   2
      Top             =   765
      Width           =   3885
      WordWrap        =   -1  'True
   End
   Begin VB.Label lblTitle 
      Caption         =   "������� LG"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   9.75
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   240
      Left            =   1050
      TabIndex        =   3
      Top             =   120
      Width           =   3885
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      BorderWidth     =   2
      Index           =   0
      X1              =   112.686
      X2              =   5197.651
      Y1              =   1449.458
      Y2              =   1449.458
   End
   Begin VB.Label lblVersion 
      Caption         =   "Version"
      Height          =   225
      Left            =   1050
      TabIndex        =   4
      Top             =   420
      Width           =   3885
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit


Private Sub cmdOK_Click()
  Unload Me
End Sub

Private Sub Form_Load()
    Me.Caption = "� ���������"
    lblVersion.Caption = "������: " & App.Major & "." & App.Minor & "." & App.Revision
    lblTitle.Caption = "������� LG"
    lblDescription.Caption = "��������� ������������� ��� ���������������� ������ ����-���." & vbCrLf
    lblDescription.Caption = lblDescription.Caption & "������������: ����� �.�, ������ �.�., ������� �.�." & vbCrLf
    lblDescription.Caption = lblDescription.Caption & "e-mail: Idlers-Corp@yandex.ru" & vbCrLf
    lblDescription.Caption = lblDescription.Caption & "2000-2001 ��."
    
    
End Sub

