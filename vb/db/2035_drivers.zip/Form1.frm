VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Installed Drivers And DSN's"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form1"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox lstDrivers 
      Height          =   1035
      Left            =   195
      TabIndex        =   2
      Top             =   1815
      Width           =   4065
   End
   Begin VB.ListBox lstDSN 
      Height          =   1035
      Left            =   195
      TabIndex        =   0
      Top             =   375
      Width           =   4065
   End
   Begin VB.Label Label1 
      Caption         =   "Installed Drivers"
      Height          =   255
      Index           =   1
      Left            =   195
      TabIndex        =   3
      Top             =   1500
      Width           =   4110
   End
   Begin VB.Label Label1 
      Caption         =   "Installed DSNs"
      Height          =   255
      Index           =   0
      Left            =   195
      TabIndex        =   1
      Top             =   45
      Width           =   4110
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'Email  johnny101@mindless.com <mailto:johnny101@mindless.com>
'Name   John Pirkey

'This Is some code that I use To Get a list of DSNs And also a list of drivers...

Private Declare Function SQLDataSources Lib "ODBC32.DLL" (ByVal henv&, ByVal fDirection%, ByVal szDSN$, ByVal cbDSNMax%, pcbDSN%, ByVal szDescription$, ByVal cbDescriptionMax%, pcbDescription%) As Integer

Private Declare Function SQLAllocEnv% Lib "ODBC32.DLL" (env&)

Const SQL_SUCCESS As Long = 0
Const SQL_FETCH_NEXT As Long = 1

Sub GetDSNsAndDrivers()
    Dim i As Integer
    Dim sDSNItem As String * 1024
    Dim sDRVItem As String * 1024
    Dim sDSN As String
    Dim sDRV As String
    Dim iDSNLen As Integer
    Dim iDRVLen As Integer
    Dim lHenv As Long         'handle to the environment

    On Error Resume Next
    lstDSN.AddItem "(None)"

    'get the DSNs
    If SQLAllocEnv(lHenv) <> -1 Then
        Do Until i <> SQL_SUCCESS
            sDSNItem = Space$(1024)
            sDRVItem = Space$(1024)
            i = SQLDataSources(lHenv, SQL_FETCH_NEXT, sDSNItem, 1024, iDSNLen, sDRVItem, 1024, iDRVLen)
            sDSN = Left$(sDSNItem, iDSNLen)
            sDRV = Left$(sDRVItem, iDRVLen)
                
            If sDSN <> Space(iDSNLen) Then
                lstDSN.AddItem sDSN
                lstDrivers.AddItem sDRV   '---optional - driver value returned
            End If
        Loop
    End If
    'remove the dups
    If lstDSN.ListCount > 0 Then
        With lstDrivers
            If .ListCount > 1 Then
                i = 0
                While i < .ListCount
                    If .List(i) = .List(i + 1) Then
                        .RemoveItem (i)
                    Else
                        i = i + 1
                    End If
                Wend
            End If
        End With
    End If
    lstDSN.ListIndex = 0
End Sub


'If you don't want the drivers list, then just don't do anything with the data that 'comes back.

'Hope this helps,
'John


'John Pirkey
'MCSD
'www.ShallowWaterSystems.com


Private Sub Form_Load()
    GetDSNsAndDrivers
    On Error Resume Next
    lstDSN.ListIndex = 0
    lstDrivers.ListIndex = 0
    
End Sub
