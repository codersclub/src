Attribute VB_Name = "ExportStuff"
Public Sub GetData()
 tb = vbTab
 message = message + "File name" + tb + ":" + tb + Form1.Load.Tag + vbNewLine
 message = message + Space(60) + vbNewLine
 message = message + "Brushes       " + tb + ":" + tb + Str(Form1.Names.ListCount) + vbNewLine
 message = message + "Estimated Brushes" + tb + ":" + tb + Str(Form1.Names.ListCount * 6) + vbNewLine
 message = message + "Estimated vertices" + tb + ":" + tb + Str(Form1.Names.ListCount * 8) + vbNewLine

 message = message + vbNewLine
 message = message + vbNewLine
 
' message = message + "Do you want to check the model for the exact" + vbNewLine
' message = message + "number of faces and vertcies? This could take" + vbNewLine
' message = message + "a few minutes on a large model, or slow computer?"
 X = MsgBox(message, 48, "Model info...")
 
' If X = 7 Then Exit Sub
 
' MsgBox "Ya, ya, I can't be arsed to do this bit.."
 
End Sub
