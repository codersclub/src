Thanks for like downloading this, and stuff...
	
	      -----------------------------	
		MODEL GENERATOR VERSION 1
	      -----------------------------

This program allows you to create 3D models and look at them, and
stuff. The reason I wrote it is because I have made a few 3D games,
but I have nothing to make 3D models with, and making them in notepad
is really hard. So here is my model editor, which you can use if your
making games and the like.

This version has no export function, but it it only a test. What
I really what is for you to think of stuff its missing, and tell me,
so I can try and put it all in the next version.

I have included some example models to inspire you. They are -
	Forklift truck 
	Aeroplane - needs smooth front and back, but looks good so far
	MechaBug - sort of 2 leged walking robot thing.
	Legs - The robot legs by themselves.

Heres a list of the bugs I know of, so don't tell me about them...
  1) On the forklift truck, the spikes don't draw right when 
     hidden face mode is on. This is becase the spikes are boxs where
     all the corners at one end are on the same spot, and things get
     messed up abit.
  2) If you try to load a model, and click cancel, it trys to load
     somthing anyway, and crashed. Its the comon diologs fault. I
     don't know how to make it figure out you pressed cancel. Please
     help me on this one.
  3) If part of your model dosn't show up in the 3D window, it may be
     becase all the faces on the missing boxes are invisible. Check
     in RemoveHiddenFace mode. Don't know why this happens.	


And here is how to use the program.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

To make a box, make sure that the 'Add Box' button is selected, and
then drag on the main window (the white bit the the cross in it).
You'll see a doted line while you drag, and then a box when you
let go. You'll also see the boxes name appear in the list at the
top right. Change the writing in the text box below the list, and
press F12 or 'Set Name' to change the name of the box.

Each box in your model will have a name, and you select the name from
the list to edit that box. You'll have to give all the boxes decent
names so you can remember which is which later on.

Make another two boxes, so that you have three altogether. You'll
see that one box is darker, and has circles at each corner. This is
the selected box. Click the names if the other boxes in the list,
and the different boxes will become highlighted. Still with me?

Now click on 'Move Box' and drag the mouse a few centimeters on the
main window. The highlighted box will move that distance across the
window. You don't have to have touched the shape. Just drag anywhere,
and the box will move that distance. Try it to see what I mean.

Now click on 'Move Vertex'. Move your mouse over the selected box, and
click on one of the corners. The circle will get darker. Now draw it
around the main window and release the mouse. The corner will have 
moved, changing the shape of the square! Wow! 

See that tool bar thing at the top of the screen. Click on the
differnt buttons to change the view position. You can also use
F1 - F3, or select the view from the views menu. You probebly guesed,
but it lets you look at your model from the top, front or side. You
can edit your model in any mode in the same way.

If you want to spin a shape, use the spin function. If you click on
a corner of the selected shape, you'll spin it around that corner,
else it spins around 0,0. Drag the mouse down first, and you'll see
a little box with a number in (Thats the angle it'll spin throught)
move the mouse around to change the angle to spin it throught.

To remove a box, press delete, or chose delete from the edit menu.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

The file options should be prety obvious. Merge loads a new model
on top of the previous one. Save, Save as, New, all obvoius.

You have got a copy and paste function in the edit menu, but it
dosn't use the windows clipboard, so if your running two copies
of MAKER at the same time, you can't copy between them. Sorry.

In the tools menu, Set name is just the F12 shortcut, to change the
name of boxes . Hide me minimised the window, and info counts the
number of boxes, corners and faces there are.

3D Viewer shows your model in 3D. You can't edit it, just move it
around the screen, by left draging, or spin it by right draging. 
Try it to get used to it. It only displays in wire frame, but its
only to give you an idea what it'll look like.

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

Remove Faces is a complicated bit, so its got a whole section for it.

What you do, is go throught your model one box at a time, and select
which faces are hidden and which arn't.

You can see which brush you are working on on the left, and each face 
in the box is numbered. On the right are two list boxes, each containing 
a tick box for each face. The top list box changes visibility, and the
bottom changes normals. Explinations of both follow --->

If you want a face to appear in the final model, make sure it has a tick
next to its number. If the face is going to be hidden, because another
box will be totaly covering it, remoe the tick from that face, and it will
be ignored when you compile the model.

If you now anything about 3D stuff, you should know about face normals, and
that you can remove all the faces that face away from you by checking the
face normal. The lower list box is for changing the face normals around.
Select the 'Remove hidden face' check box, and have a good look at your box
in the left window. If it looks wiard, try pressing 'Reverse visibility'
to swap the face normals around. You'll probebly use this button alot, cos
if you create a box by draging left to right, instead of right to left, the
box will end up inside out, and you'll need to reverse the normals to make
it look right. You can also reverse the normals of an individual face in a box
but I can't really see this being of any use to you. But you can still do it..

+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

If you want a handy hint, make your model first, and look at it in 3D mode.
If parts don't look right, go throught the Remove Hidden Faces bit, and
swap the normals around on the boxes that don't look right. Once it looks
right, you can go around and remove hidden faces.

Hope that made sence to you all. If you find bugs, or are trying to do somthing
and can't let me know, so the next version can be better.



