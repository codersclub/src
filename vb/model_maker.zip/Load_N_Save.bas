Attribute VB_Name = "Load_N_Save"
Public Sub LoadNew(FileName)

Open FileName For Input As #1

Input #1, totall

For n = 1 To totall
Add = FindBox
 Shape(Add).Used = True
  Input #1, Shape(Add).Name
  
  For X = 1 To 6
   For Y = 1 To 4
    Input #1, Shape(Add).Face(X).Edge(Y)
   Next Y
   Input #1, usedorn
   
  ' MsgBox usedorn
   Shape(Add).Face(X).Used = usedorn
   
  Next X

  For X = 1 To 8
   Input #1, Shape(Add).Corners(X).X
   Input #1, Shape(Add).Corners(X).Y
   Input #1, Shape(Add).Corners(X).Z
  Next X


Next n
Close
Form1.Draw
End Sub


Public Sub SaveAll(FileName, FileCheck)

If FileIsThere(FileName) = True And FileCheck = 1 Then
 X = MsgBox("File already exits. do you want to over-write it?", vbYesNo, "Wait...")
 If X = 7 Then Exit Sub
End If

Open FileName For Output As #1

totall = ShapeCount
Print #1, totall
For n = 1 To 100
 If Shape(n).Used = True Then
  Print #1, Shape(n).Name
  For X = 1 To 6
   For Y = 1 To 4
    Print #1, Shape(n).Face(X).Edge(Y)
   Next Y
   Print #1, Shape(n).Face(X).Used
  Next X
 
  For X = 1 To 8
   Print #1, Shape(n).Corners(X).X
   Print #1, Shape(n).Corners(X).Y
   Print #1, Shape(n).Corners(X).Z
  Next X

End If

Next n
Close
End Sub


Public Function ShapeCount()
ShapeCount = 0
For n = 1 To 100
 If Shape(n).Used = True Then
  ShapeCount = ShapeCount + 1
 End If
 Next n
End Function

Public Function FileIsThere(FileName) As Boolean
FileIsThere = False
On Error GoTo NotThere
Open FileName For Input As #1
Close
FileIsThere = True
NotThere:
End Function

