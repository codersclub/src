VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H80000007&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "::������::"
   ClientHeight    =   1695
   ClientLeft      =   4425
   ClientTop       =   2940
   ClientWidth     =   3285
   ControlBox      =   0   'False
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "Form1.frx":0442
   ScaleHeight     =   1695
   ScaleWidth      =   3285
   Begin VB.CommandButton Command1 
      Caption         =   "���������"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   375
      Left            =   240
      TabIndex        =   2
      Top             =   1080
      Width           =   1215
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   0
      Top             =   0
   End
   Begin VB.Label data 
      BackColor       =   &H80000012&
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H8000000E&
      Height          =   255
      Left            =   2040
      TabIndex        =   1
      Top             =   1200
      Width           =   975
   End
   Begin VB.Label tim 
      BackColor       =   &H80000007&
      BackStyle       =   0  'Transparent
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   18
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FF00&
      Height          =   495
      Left            =   840
      TabIndex        =   0
      Top             =   480
      Width           =   1695
   End
   Begin VB.Image Image1 
      Height          =   1695
      Left            =   0
      Picture         =   "Form1.frx":3E18
      Top             =   0
      Width           =   3285
   End
   Begin VB.Menu file 
      Caption         =   "����"
      Begin VB.Menu ex 
         Caption         =   "�����"
      End
   End
   Begin VB.Menu con 
      Caption         =   "���������"
   End
   Begin VB.Menu about 
      Caption         =   "� ���������"
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False


Private Sub about_Click()
about1.Show vbModal
End Sub



Private Sub Command1_Click()
wer.Show vbModal
End Sub

Private Sub con_Click()
Form2.Show vbNormal
End Sub

Private Sub ex_Click()
End
End Sub

Private Sub Timer1_Timer()
'������� �������
tim.Caption = Time
data.Caption = Date
'������ �������
a = Hour(Time)
b = Minute(Time)
c = Second(Time)
End Sub

