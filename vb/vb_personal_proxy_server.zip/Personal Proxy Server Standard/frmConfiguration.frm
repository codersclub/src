VERSION 5.00
Begin VB.Form frmConfiguration 
   BorderStyle     =   4  'Fixed ToolWindow
   Caption         =   "Proxy Configuration"
   ClientHeight    =   3795
   ClientLeft      =   45
   ClientTop       =   285
   ClientWidth     =   5910
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3795
   ScaleWidth      =   5910
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.Frame fraConfiguration 
      Caption         =   "Proxy Configuration"
      Height          =   2205
      Left            =   0
      TabIndex        =   6
      Top             =   1080
      Width           =   5895
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   6
         Left            =   2130
         TabIndex        =   18
         Top             =   1680
         Width           =   3615
      End
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   5
         Left            =   2130
         TabIndex        =   16
         Top             =   1320
         Width           =   3615
      End
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   4
         Left            =   2130
         TabIndex        =   14
         Top             =   960
         Width           =   3615
      End
      Begin VB.CheckBox chkConfig 
         Caption         =   "Replace User Agent"
         Height          =   285
         Index           =   4
         Left            =   150
         TabIndex        =   17
         Top             =   1710
         Width           =   2055
      End
      Begin VB.CheckBox chkConfig 
         Caption         =   "Hide Actual Server"
         Height          =   285
         Index           =   2
         Left            =   150
         TabIndex        =   13
         Top             =   990
         Width           =   2055
      End
      Begin VB.CheckBox chkConfig 
         Caption         =   "Hide Actual Proxy"
         Height          =   285
         Index           =   3
         Left            =   150
         TabIndex        =   15
         Top             =   1350
         Width           =   2055
      End
      Begin VB.CheckBox chkConfig 
         Alignment       =   1  'Right Justify
         Caption         =   "Disable Cookie"
         Height          =   285
         Index           =   1
         Left            =   4290
         TabIndex        =   12
         Top             =   630
         Width           =   1455
      End
      Begin VB.CheckBox chkConfig 
         Alignment       =   1  'Right Justify
         Caption         =   "Force Reload"
         Height          =   285
         Index           =   0
         Left            =   4290
         TabIndex        =   9
         Top             =   240
         Width           =   1455
      End
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   3
         Left            =   2130
         TabIndex        =   11
         Top             =   600
         Width           =   1755
      End
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   2
         Left            =   2130
         TabIndex        =   8
         Top             =   240
         Width           =   1755
      End
      Begin VB.Label Label7 
         Caption         =   "Local Port"
         Height          =   285
         Left            =   150
         TabIndex        =   10
         Top             =   660
         Width           =   1905
      End
      Begin VB.Label Label6 
         Caption         =   "Maximum Connection"
         Height          =   285
         Left            =   150
         TabIndex        =   7
         Top             =   300
         Width           =   1905
      End
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Cancel"
      Height          =   375
      Left            =   4830
      TabIndex        =   20
      Top             =   3360
      Width           =   1005
   End
   Begin VB.CheckBox chkUseProxy 
      Caption         =   "Use Proxy Server"
      Height          =   165
      Left            =   150
      TabIndex        =   1
      Top             =   60
      Width           =   1575
   End
   Begin VB.Frame fraProxy 
      Height          =   1035
      Left            =   0
      TabIndex        =   0
      Top             =   30
      Width           =   5895
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   1
         Left            =   2130
         TabIndex        =   5
         Top             =   600
         Width           =   3615
      End
      Begin VB.TextBox txtProxySetting 
         Height          =   345
         Index           =   0
         Left            =   2130
         TabIndex        =   3
         Top             =   240
         Width           =   3615
      End
      Begin VB.Label Label2 
         Caption         =   "Proxy Port"
         Height          =   285
         Left            =   150
         TabIndex        =   4
         Top             =   660
         Width           =   1035
      End
      Begin VB.Label Label1 
         Caption         =   "Proxy Server"
         Height          =   285
         Left            =   150
         TabIndex        =   2
         Top             =   300
         Width           =   1035
      End
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "&OK"
      Height          =   375
      Left            =   3780
      TabIndex        =   19
      Top             =   3360
      Width           =   1005
   End
End
Attribute VB_Name = "frmConfiguration"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Public Sub OpenCommunication(ParentForm As Form, commtype As Byte, ParamArray x())
    Select Case commtype
    Case 0
        chkUseProxy.Value = x(0)
        txtProxySetting(0).Text = x(1)
        txtProxySetting(1).Text = x(2)
        txtProxySetting(2).Text = x(3)
        txtProxySetting(3).Text = x(4)
        txtProxySetting(3).Tag = x(4)
        chkConfig(0).Value = x(5)
        chkConfig(1).Value = x(6)
        chkConfig(2).Value = x(7)
        chkConfig(3).Value = x(8)
        chkConfig(4).Value = x(9)
        txtProxySetting(4).Text = x(10)
        txtProxySetting(5).Text = x(11)
        txtProxySetting(6).Text = x(12)
        chkConfig_Click 2
        chkConfig_Click 3
        chkConfig_Click 4
        Me.Show vbModal, ParentForm
    End Select
End Sub

Private Sub SetFrame(objForm As Form, objFrame As Frame, Flag As Boolean)
Dim objControl As Control

    objFrame.Enabled = Flag
    For Each objControl In objForm
        If objControl.Container.Name = objFrame.Name Then
            objControl.Enabled = Flag
            Select Case LCase(TypeName(objControl))
            Case "label"
            Case "textbox"
                If Flag Then
                    objControl.BackColor = vbWhite
                Else
                    objControl.BackColor = vbTransparant
                End If
            Case "frame"
                If Not Flag Then SetFrame Me, objControl, Flag
            Case "commandbutton"
            Case "combobox"
            Case "listbox"
            Case "checkbox"
            End Select
        End If
    Next objControl
End Sub

Private Sub chkConfig_Click(Index As Integer)
    If Index > 1 And Index < 5 Then
        If chkConfig(Index) = vbChecked Then
            txtProxySetting(Index + 2).Enabled = True
            txtProxySetting(Index + 2).BackColor = vbWhite
        Else
            txtProxySetting(Index + 2).Enabled = False
            txtProxySetting(Index + 2).BackColor = vbTransparant
        End If
    End If
End Sub

Private Sub chkUseProxy_Click()
    If chkUseProxy.Value = vbChecked Then
        SetFrame Me, fraProxy, True
    Else
        SetFrame Me, fraProxy, False
    End If
End Sub

Private Sub cmdCancel_Click()
    ProxySet = False
    ChildOpen = False
    Me.Hide
End Sub

Private Sub cmdOk_Click()
    If Val(txtProxySetting(3).Text) <> Val(txtProxySetting(3).Tag) Then MsgBox "Changing Listening Port required proxy server to restart", vbExclamation
    ProxySet = True
    ChildOpen = False
    Me.Hide
End Sub

Private Sub Form_KeyPress(KeyAscii As Integer)
    If KeyAscii = vbKeyReturn Then
        SendKeys "{Tab}"
    ElseIf KeyAscii = vbKeyEscape Then
        ProxySet = False
        ChildOpen = False
        Me.Hide
    End If
End Sub

Private Sub Form_Load()
    SetFrame Me, fraProxy, False
End Sub

Private Sub Form_Unload(Cancel As Integer)
    ProxySet = False
    ChildOpen = False
End Sub

