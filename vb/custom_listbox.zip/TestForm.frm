VERSION 5.00
Object = "*\AListBoxOcx.vbp"
Begin VB.Form Form1 
   Caption         =   "Example"
   ClientHeight    =   1575
   ClientLeft      =   2325
   ClientTop       =   3045
   ClientWidth     =   4095
   LinkTopic       =   "Form1"
   ScaleHeight     =   105
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   273
   Begin Project2.CustomListBox CustomListBox1 
      Height          =   1335
      Left            =   1440
      TabIndex        =   5
      Top             =   120
      Width           =   2535
      _ExtentX        =   4471
      _ExtentY        =   2355
      BackColor       =   16777215
      BeginProperty FontInfo {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Verdana"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   16777215
      Graphical       =   -1  'True
      Picture         =   "TestForm.frx":0000
      ScrollBarBackColor=   12632256
      ScrollBarBorderColor=   8421504
      SelBoxColor     =   12632064
      Sorted          =   0   'False
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Down"
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   1200
      Width           =   1215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Up"
      Height          =   255
      Left            =   120
      TabIndex        =   3
      Top             =   960
      Width           =   1215
   End
   Begin VB.CommandButton remove 
      Caption         =   "Remove"
      Height          =   255
      Left            =   120
      TabIndex        =   2
      Top             =   720
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Text            =   "Some Text"
      Top             =   420
      Width           =   1215
   End
   Begin VB.CommandButton add 
      Caption         =   "Add"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' This is just the test form.

Option Explicit

Private Sub Command1_Click()
    CustomListBox1.MoveUp
End Sub

Private Sub add_Click()
    If Text1.Text = "" Then
        MsgBox "Please enter some text.", vbInformation, "Alert"
        Exit Sub
    End If
    CustomListBox1.AddItem Text1.Text
    Text1.Text = ""
End Sub

Private Sub Command2_Click()
    CustomListBox1.Movedown
End Sub

Private Sub Command3_Click()
    CustomListBox1.ForeColor = RGB(255 * Rnd, 255 * Rnd, 255 * Rnd)
End Sub

Private Sub CustomListBox1_DblClick()
    MsgBox "You clicked: " & CustomListBox1.List(CustomListBox1.ListIndex)
End Sub

Private Sub Form_Load()

End Sub

Private Sub remove_Click()
    If CustomListBox1.ListIndex = -1 Then Exit Sub
    CustomListBox1.RemoveItem CustomListBox1.ListIndex
End Sub
