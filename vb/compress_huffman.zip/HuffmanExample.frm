VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Huffman Encoding/Decoding Example Project"
   ClientHeight    =   3975
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4455
   LinkTopic       =   "Form1"
   ScaleHeight     =   3975
   ScaleWidth      =   4455
   StartUpPosition =   1  'CenterOwner
   Begin VB.Frame Frame1 
      Caption         =   "Information"
      Height          =   1575
      Left            =   120
      TabIndex        =   6
      Top             =   1680
      Width           =   4215
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "<unknown>"
         Height          =   195
         Index           =   3
         Left            =   1920
         TabIndex        =   14
         Top             =   1200
         Width           =   840
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "<unknown>"
         Height          =   195
         Index           =   2
         Left            =   1920
         TabIndex        =   13
         Top             =   900
         Width           =   840
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "<unknown>"
         Height          =   195
         Index           =   1
         Left            =   1920
         TabIndex        =   12
         Top             =   615
         Width           =   840
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "<unknown>"
         Height          =   195
         Index           =   0
         Left            =   1920
         TabIndex        =   11
         Top             =   315
         Width           =   840
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Time spent:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   5
         Left            =   240
         TabIndex        =   10
         Top             =   1200
         Width           =   1005
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Ratio:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   4
         Left            =   240
         TabIndex        =   9
         Top             =   900
         Width           =   525
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Destination size:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   3
         Left            =   240
         TabIndex        =   8
         Top             =   615
         Width           =   1425
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Source size:"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Index           =   2
         Left            =   240
         TabIndex        =   7
         Top             =   315
         Width           =   1065
      End
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Decompress"
      Height          =   375
      Left            =   2280
      TabIndex        =   3
      Top             =   3480
      Width           =   1335
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Index           =   1
      Left            =   120
      TabIndex        =   2
      Text            =   "C:\Saol.huf"
      Top             =   1080
      Width           =   4215
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Text            =   "C:\Saol.txt"
      Top             =   360
      Width           =   4215
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Compress"
      Height          =   375
      Left            =   840
      TabIndex        =   0
      Top             =   3480
      Width           =   1335
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Destination file:"
      Height          =   195
      Index           =   1
      Left            =   120
      TabIndex        =   5
      Top             =   840
      Width           =   1080
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Source file:"
      Height          =   195
      Index           =   0
      Left            =   120
      TabIndex        =   4
      Top             =   120
      Width           =   795
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub Command1_Click()

  Dim Filenr As Integer
  Dim oldtimer As Single
  Dim ByteArray() As Byte
  Dim Huffman As New clsHuffman

  On Error GoTo ErrorHandler

  'Read the data from the file
  Filenr = FreeFile
  Open Text1(0).Text For Binary As #Filenr
Label2(0).Caption = LOF(1) & " bytes"
  ReDim ByteArray(LOF(1) - 1)
  Get #Filenr, , ByteArray()
  Close #Filenr

  'Compress the data
oldtimer = Timer
  Call Huffman.EncodeByte(ByteArray(), UBound(ByteArray) + 1)
Label2(3).Caption = Timer - oldtimer & " s"
Label2(1).Caption = UBound(ByteArray) + 1 & " bytes"
Label2(2).Caption = Int(Val(Label2(1).Caption) / Val(Label2(0).Caption) * 100) & "%"

  'Store the file into the destination string
  If (Len(Dir$(Text1(1).Text)) > 0) Then Kill Text1(1).Text
  Filenr = FreeFile
  Open Text1(1).Text For Binary As #Filenr
  Put #Filenr, , ByteArray()
  Close #Filenr

  'Show a nice dialog to the user
  Call MsgBox("Compression successful.", vbInformation)
  
  Exit Sub
  
ErrorHandler:
  Call MsgBox("The compression was not successful. Something went terribly wrong." & vbCrLf & vbCrLf & Err.Description, vbExclamation)

End Sub
Private Sub Command2_Click()

  Dim Filenr As Integer
  Dim ByteArray() As Byte
  Dim Huffman As New clsHuffman
Dim oldtimer As Single

  On Error GoTo ErrorHandler
  
  'Read the data from the compressed file
  Filenr = FreeFile
  Open Text1(1).Text For Binary As #Filenr
  ReDim ByteArray(LOF(Filenr) - 1)
Label2(0).Caption = LOF(Filenr) & " bytes"
  Get #Filenr, , ByteArray()
  Close Filenr
  
  'Uncompress the data
oldtimer = Timer
  Call Huffman.DecodeByte(ByteArray, UBound(ByteArray) + 1)
Label2(3).Caption = Timer - oldtimer & " s"
Label2(1).Caption = UBound(ByteArray) + 1 & " bytes"
Label2(2).Caption = Int(Val(Label2(1).Caption) / Val(Label2(0).Caption) * 100) & "%"

  'Save the data to the destination file
  If (Len(Dir$(Text1(0).Text & ".bak")) > 0) Then Kill Text1(0).Text & ".bak"
  Filenr = FreeFile
  Open Text1(0).Text & ".bak" For Binary As #Filenr
  Put #Filenr, , ByteArray()
  Close #Filenr

  'Show a nice dialog to the user
  Call MsgBox("Compression successful.", vbInformation)
  
  Exit Sub
  
ErrorHandler:
  Call MsgBox("The compression was not successful. Something went terribly wrong." & vbCrLf & vbCrLf & Err.Description, vbExclamation)

End Sub
