Attribute VB_Name = "Module1"
Option Explicit

Private Const SWP_NOACTIVATE = &H10
Private Const SWP_SHOWWINDOW = &H40
Private Const HWND_TOPMOST = -1
Private Const HWND_NOTOPMOST = -2

Private Declare Function SetWindowPos Lib "user32" (ByVal hwnd As Long, ByVal hWndInsertAfter As Long, ByVal X As Long, ByVal Y As Long, ByVal cx As Long, ByVal cy As Long, ByVal wFlags As Long) As Long
Public Declare Function GetParent Lib "user32" (ByVal hwnd As Long) As Long
Public Declare Function GetFocus Lib "user32" () As Long

Global mParent&
Sub LoadMenu(parent As Form, stuff As Variant, Optional X As Single, Optional Y As Single, Optional width = 1950)
Dim i%
Dim sep%
sep = 1
On Error Resume Next
mParent = parent.hwnd
With Form1
    
    .Hide
    
    .Height = (UBound(stuff) + 3) * 225
    .Top = Y
    .Left = X
    .width = width
    
    .mTop.Top = 0
    .mTop.Left = 0
    .mTop.width = .width
    .mTop.Height = 225
    
    .mBot.Top = .Height - .mBot.Height
    .mBot.Left = 0
    .mBot.width = .width
    .mBot.Height = 225
    
    .mSide.Top = .mTop.Height
    .mSide.Left = 0
    .mSide.width = 150
    .mSide.Height = (UBound(stuff) + 1) * 225
    
    .mBody.Top = .mTop.Height
    .mBody.Left = .mSide.width
    .mBody.width = .width - 150
    .mBody.Height = .mSide.Height
    
    If stuff(0) = "-" Then
        Load .separator(sep)
        .separator(sep).Y1 = 122
        .separator(sep).Y2 = 122
        .separator(sep).X1 = 150
        .separator(sep).X2 = .mBody.width
        .separator(sep).Visible = True
        sep = sep + 1
    Else
        .menu(0).Top = 0
        .menu(0).Left = 150
        .menu(0).width = .mBody.width - 150
        .menu(0).Height = 225
        .menu(0).Caption = stuff(0)
        .menu(0).ForeColor = vbBlack
        .menu(0).BackStyle = 0
        .menu(0).Visible = True
    End If
    For i = 1 To UBound(stuff)
        If stuff(i) = "-" Then
            Load .separator(sep)
            .separator(sep).Y1 = i * 225 + 122
            .separator(sep).Y2 = i * 225 + 122
            .separator(sep).X1 = 150
            .separator(sep).X2 = .mBody.width
            .separator(sep).Visible = True
            sep = sep + 1
        Else
            Load .menu(i)
            .menu(i).Top = i * 225
            .menu(i).Left = 150
            .menu(i).width = .mBody.width - 150
            .menu(i).Height = 225
            .menu(i).Caption = stuff(i)
            .menu(i).ForeColor = vbBlack
            .menu(i).BackStyle = 0
            .menu(i).Visible = True
        End If
    Next i
    Call StayOnTop(Form1, True)
    .Show
    .Timer1.Enabled = True
End With
End Sub
Private Sub StayOnTop(myfrm As Form, SetOnTop As Boolean)
'make setontop true to make from topmost
'make it false to make form nontopmost
Dim lFlag As Long
If SetOnTop Then
    lFlag = HWND_TOPMOST
Else
    lFlag = HWND_NOTOPMOST
End If
Call SetWindowPos(myfrm.hwnd, lFlag, myfrm.Left / Screen.TwipsPerPixelX, myfrm.Top / Screen.TwipsPerPixelY, myfrm.width / Screen.TwipsPerPixelX, myfrm.Height / Screen.TwipsPerPixelY, SWP_NOACTIVATE Or SWP_SHOWWINDOW)
End Sub
Sub MenuClicked(Index As Integer)
Dim i%
On Error Resume Next
Form1.Timer1.Enabled = False
For i = 1 To Form1.menu.UBound
    Form1.menu(i).Caption = ""
    Form1.menu(i).ForeColor = vbBlack
    Form1.menu(i).BackStyle = 0
    Form1.menu(i).Visible = False
    Unload Form1.menu(i)
Next i

For i = 1 To Form1.separator.UBound
    Form1.separator(i).Visible = False
    Unload Form1.separator(i)
Next i
Form1.menu(0).Visible = False
Form1.menu(0).Caption = ""
Form1.menu(0).ForeColor = vbBlack
Form1.menu(0).BackStyle = 0
Form1.menu(0).Visible = True

Form1.Hide

MsgBox "You clicked menu " & Index
End Sub
