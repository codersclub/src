VERSION 5.00
Begin VB.Form Form2 
   Caption         =   "Right click ANYWHERE"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   LinkTopic       =   "Form2"
   ScaleHeight     =   3195
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub Form_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
Dim stuff(0 To 10) As String
Dim focushwnd&, i%
For i = 0 To 10
    If i Mod 2 = 0 Then
        stuff(i) = "Entry " & i
    Else
        stuff(i) = "-"
    End If
Next i
If Button = 2 Then
    Do: DoEvents
        focushwnd& = GetFocus()
        Me.SetFocus
    Loop Until focushwnd = Me.hwnd

    Call LoadMenu(Form2, stuff, Form2.Left + X, Form2.Top + Y + 240)
End If
End Sub
