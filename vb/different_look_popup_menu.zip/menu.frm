VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H000000FF&
   BorderStyle     =   0  'None
   Caption         =   "Form1"
   ClientHeight    =   3825
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   2250
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3825
   ScaleWidth      =   2250
   ShowInTaskbar   =   0   'False
   Begin VB.Timer Timer1 
      Interval        =   5
      Left            =   480
      Top             =   1680
   End
   Begin VB.PictureBox mSide 
      BackColor       =   &H00000000&
      BorderStyle     =   0  'None
      Height          =   3375
      Left            =   0
      ScaleHeight     =   3375
      ScaleWidth      =   150
      TabIndex        =   3
      Top             =   225
      Width           =   150
   End
   Begin VB.PictureBox mBody 
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  'None
      Height          =   3375
      Left            =   150
      ScaleHeight     =   3375
      ScaleWidth      =   2100
      TabIndex        =   2
      Top             =   225
      Width           =   2100
      Begin VB.Line separator 
         Index           =   0
         Visible         =   0   'False
         X1              =   240
         X2              =   1800
         Y1              =   1200
         Y2              =   1200
      End
      Begin VB.Label menu 
         BackColor       =   &H00800000&
         BackStyle       =   0  'Transparent
         Height          =   225
         Index           =   0
         Left            =   150
         TabIndex        =   4
         Top             =   0
         Width           =   1950
      End
   End
   Begin VB.PictureBox mTop 
      AutoSize        =   -1  'True
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   0
      Picture         =   "menu.frx":0000
      ScaleHeight     =   240
      ScaleWidth      =   2250
      TabIndex        =   1
      Top             =   0
      Width           =   2250
   End
   Begin VB.PictureBox mBot 
      AutoSize        =   -1  'True
      BackColor       =   &H000000FF&
      BorderStyle     =   0  'None
      Height          =   225
      Left            =   0
      Picture         =   "menu.frx":1C82
      ScaleHeight     =   225
      ScaleWidth      =   2250
      TabIndex        =   0
      Top             =   3600
      Width           =   2250
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private Sub menu_MouseMove(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
Dim i%
On Error Resume Next
For i = Form1.menu.LBound To Form1.menu.UBound
    menu(i).BackStyle = 0
    menu(i).ForeColor = vbBlack
Next i
menu(Index).BackStyle = 1
menu(Index).ForeColor = vbWhite
End Sub
Private Sub menu_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
Call MenuClicked(Index)
End Sub
Private Sub Timer1_Timer()
Dim focushwnd As Long
focushwnd& = GetFocus()
Do While GetParent(focushwnd&) <> 0
    focushwnd& = GetParent(focushwnd&): DoEvents
Loop
If focushwnd& <> mParent And focushwnd& <> Form1.hwnd Then
    Call MenuClicked(-1)
End If
End Sub
