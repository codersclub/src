Attribute VB_Name = "aeMWinsock"
Option Explicit

'AzUrE
'Copyright (C) 2000 Sam Smith All Rights Reserved
'
'Contact: <samuel.smith@nme.com>
'Version: 1.0.0.0
'
Public Const WSABASEERR As Integer = 10000
Public Const WSAEINTR As Integer = (WSABASEERR + 4)
Public Const WSAEBADF As Integer = (WSABASEERR + 9)
Public Const WSAEACCES As Integer = (WSABASEERR + 13)
Public Const WSAEFAULT As Integer = (WSABASEERR + 14)
Public Const WSAEINVAL As Integer = (WSABASEERR + 22)
Public Const WSAEMFILE As Integer = (WSABASEERR + 24)
Public Const WSAEWOULDBLOCK As Integer = (WSABASEERR + 35)
Public Const WSAEINPROGRESS As Integer = (WSABASEERR + 36)
Public Const WSAEALREADY As Integer = (WSABASEERR + 37)
Public Const WSAENOTSOCK As Integer = (WSABASEERR + 38)
Public Const WSAEDESTADDRREQ As Integer = (WSABASEERR + 39)
Public Const WSAEMSGSIZE As Integer = (WSABASEERR + 40)
Public Const WSAEPROTOTYPE As Integer = (WSABASEERR + 41)
Public Const WSAENOPROTOOPT As Integer = (WSABASEERR + 42)
Public Const WSAEPROTONOSUPPORT As Integer = (WSABASEERR + 43)
Public Const WSAESOCKTNOSUPPORT As Integer = (WSABASEERR + 44)
Public Const WSAEOPNOTSUPP As Integer = (WSABASEERR + 45)
Public Const WSAEPFNOSUPPORT As Integer = (WSABASEERR + 46)
Public Const WSAEAFNOSUPPORT As Integer = (WSABASEERR + 47)
Public Const WSAEADDRINUSE As Integer = (WSABASEERR + 48)
Public Const WSAEADDRNOTAVAIL As Integer = (WSABASEERR + 49)
Public Const WSAENETDOWN As Integer = (WSABASEERR + 50)
Public Const WSAENETUNREACH As Integer = (WSABASEERR + 51)
Public Const WSAENETRESET As Integer = (WSABASEERR + 52)
Public Const WSAECONNABORTED As Integer = (WSABASEERR + 53)
Public Const WSAECONNRESET As Integer = (WSABASEERR + 54)
Public Const WSAENOBUFS As Integer = (WSABASEERR + 55)
Public Const WSAEISCONN As Integer = (WSABASEERR + 56)
Public Const WSAENOTCONN As Integer = (WSABASEERR + 57)
Public Const WSAESHUTDOWN As Integer = (WSABASEERR + 58)
Public Const WSAETOOMANYREFS As Integer = (WSABASEERR + 59)
Public Const WSAETIMEDOUT As Integer = (WSABASEERR + 60)
Public Const WSAECONNREFUSED As Integer = (WSABASEERR + 61)
Public Const WSAELOOP As Integer = (WSABASEERR + 62)
Public Const WSAENAMETOOLONG As Integer = (WSABASEERR + 63)
Public Const WSAEHOSTDOWN As Integer = (WSABASEERR + 64)
Public Const WSAEHOSTUNREACH As Integer = (WSABASEERR + 65)
Public Const WSAENOTEMPTY As Integer = (WSABASEERR + 66)
Public Const WSAEPROCLIM As Integer = (WSABASEERR + 67)
Public Const WSAEUSERS As Integer = (WSABASEERR + 68)
Public Const WSAEDQUOT As Integer = (WSABASEERR + 69)
Public Const WSAESTALE As Integer = (WSABASEERR + 70)
Public Const WSAEREMOTE As Integer = (WSABASEERR + 71)
Public Const WSASYSNOTREADY As Integer = (WSABASEERR + 91)
Public Const WSAVERNOTSUPPORTED As Integer = (WSABASEERR + 92)
Public Const WSANOTINITIALISED As Integer = (WSABASEERR + 93)
Public Const WSAEDISCON As Integer = (WSABASEERR + 101)
Public Const WSAENOMORE As Integer = (WSABASEERR + 102)
Public Const WSAECANCELLED As Integer = (WSABASEERR + 103)
Public Const WSAEINVALIDPROCTABLE As Integer = (WSABASEERR + 104)
Public Const WSAEINVALIDPROVIDER As Integer = (WSABASEERR + 105)
Public Const WSAEPROVIDERFAILEDINIT As Integer = (WSABASEERR + 106)
Public Const WSASYSCALLFAILURE As Integer = (WSABASEERR + 107)
Public Const WSASERVICE_NOT_FOUND As Integer = (WSABASEERR + 108)
Public Const WSATYPE_NOT_FOUND As Integer = (WSABASEERR + 109)
Public Const WSA_E_NO_MORE As Integer = (WSABASEERR + 110)
Public Const WSA_E_CANCELLED As Integer = (WSABASEERR + 111)
Public Const WSAEREFUSED As Integer = (WSABASEERR + 112)
Public Const WSAHOST_NOT_FOUND As Integer = (WSABASEERR + 1001)
Public Const WSATRY_AGAIN As Integer = (WSABASEERR + 1002)
Public Const WSANO_RECOVERY As Integer = (WSABASEERR + 1003)
Public Const WSANO_DATA As Integer = (WSABASEERR + 1004)
Public Const WSA_NOT_ENOUGH_MEMORY As Integer = 8
Public Const WSA_OPERATION_ABORTED As Integer = 995
Public Const WSA_IO_INCOMPLETE As Integer = 996
Public Const WSA_IO_PENDING As Integer = 997

Public Const WSADESCRIPTION_LEN As Integer = 256
Public Const WSASYS_STATUS_LEN  As Integer = 128

Public Type WSAData
    Version As Integer
    HighVersion As Integer
    Description(0 To WSADESCRIPTION_LEN) As Byte
    SystemStatus(0 To WSASYS_STATUS_LEN) As Byte
    MaxSockets As Integer
    MaxUDPdg As Integer
End Type

#If WSVERSION = 1 Then
  Public Declare Function WSAStartup Lib "wsock32" (ByVal lNeededVersion As Long, lpWSAData As WSAData) As Long
  Public Declare Function WSACleanup Lib "wsock32" () As Long
#Else
  Public Declare Function WSAStartup Lib "ws2_32" (ByVal lNeededVersion As Long, lpWSAData As WSAData) As Long
  Public Declare Function WSACleanup Lib "ws2_32" () As Long
#End If

Public Type sockaddr_in
    sin_family As Integer
    sin_port As Integer
    sin_addr As Long
    sin_padding(0 To 7) As Byte
End Type

#If WSVERSION = 1 Then
  Public Declare Function bind Lib "wsock32" (ByVal socket As Long, Addr As sockaddr_in, ByVal namelen As Long) As Long
  Public Declare Function accept Lib "wsock32" (ByVal socket As Long, Addr As sockaddr_in, addrlen As Long) As Long
  Public Declare Function socketconnect Lib "wsock32" Alias "connect" (ByVal socket As Long, Addr As sockaddr_in, ByVal namelen As Long) As Long
  Public Declare Function getpeername Lib "wsock32" (ByVal socket As Long, sname As sockaddr_in, namelen As Long) As Long
  Public Declare Function getsockname Lib "wsock32" (ByVal socket As Long, sname As sockaddr_in, namelen As Long) As Long
#Else
  Public Declare Function bind Lib "ws2_32" (ByVal socket As Long, Addr As sockaddr_in, ByVal namelen As Long) As Long
  Public Declare Function accept Lib "ws2_32" (ByVal socket As Long, Addr As sockaddr_in, addrlen As Long) As Long
  Public Declare Function socketconnect Lib "ws2_32" Alias "connect" (ByVal socket As Long, Addr As sockaddr_in, ByVal namelen As Long) As Long
  Public Declare Function getpeername Lib "ws2_32" (ByVal socket As Long, sname As sockaddr_in, namelen As Long) As Long
  Public Declare Function getsockname Lib "ws2_32" (ByVal socket As Long, sname As sockaddr_in, namelen As Long) As Long
#End If

Public Type hostent
    h_name As Long
    h_aliases As Long
    h_addr_type As Integer
    h_len As Integer
    h_addr_list As Long
End Type

#If WSVERSION = 1 Then
  Public Declare Function gethostbyname Lib "wsock32" (ByVal hName As String) As Long
  Public Declare Function gethostbyaddr Lib "wsock32" _
  (ByVal Addr As Long, ByVal addrlen As Long, _
  ByVal addrtype As Long) As Long
#Else
  Public Declare Function gethostbyname Lib "ws2_32" (ByVal hName As String) As Long
  Public Declare Function gethostbyaddr Lib "ws2_32" _
  (ByVal Addr As Long, ByVal addrlen As Long, _
  ByVal addrtype As Long) As Long
#End If

Public Const MaxGetHostStruct As Integer = 1024
Public Const hostentA_size As Integer = 1040

Public Type hostentA
    h_name As Long
    h_aliases As Long
    h_addr_type As Integer
    h_len As Integer
    h_addr_list As Long
    h_async_buffer(MaxGetHostStruct) As Byte
End Type

#If WSVERSION = 1 Then
  Public Declare Function WSACancelAsyncRequest Lib "wsock32" _
  (ByVal hAsyncTaskHandle As Long) As Long
  Public Declare Function WSAAsyncGetHostByAddr Lib "wsock32" _
  (ByVal hwnd As Long, ByVal iMsg As Long, Addr As Long, _
  ByVal addr_len As Long, _
  ByVal addr_type As Long, buf As Any, _
  ByVal buflen As Long) As Long
  Public Declare Function WSAAsyncGetHostByName Lib "wsock32" _
  (ByVal hwnd As Long, ByVal iMsg As Long, _
  ByVal HostName As String, buf As Any, _
  ByVal buflen As Long) As Long
#Else
  Public Declare Function WSACancelAsyncRequest Lib "ws2_32" _
  (ByVal hAsyncTaskHandle As Long) As Long
  Public Declare Function WSAAsyncGetHostByAddr Lib "ws2_32" _
  (ByVal hwnd As Long, ByVal iMsg As Long, Addr As Long, _
  ByVal addr_len As Long, _
  ByVal addr_type As Long, buf As Any, _
  ByVal buflen As Long) As Long
  Public Declare Function WSAAsyncGetHostByName Lib "ws2_32" _
  (ByVal hwnd As Long, ByVal iMsg As Long, _
  ByVal HostName As String, buf As Any, _
  ByVal buflen As Long) As Long
#End If

Public Const SOCKET_ERROR  As Integer = -1
Public Const AF_INET  As Byte = 2
Public Const IPPROTO_TCP As Byte = 6
Public Const IPPROTO_UDP As Byte = 17
Public Const SOCK_STREAM As Byte = 1
Public Const SOCK_DGRAM  As Byte = 2

#If WSVERSION = 1 Then
  Public Declare Function socket Lib "wsock32" _
  (ByVal af As Long, ByVal socket_type As Long, ByVal protocol_type As Long) As Long
  Public Declare Function closesocket Lib "wsock32" (ByVal socket As Long) As Long
#Else
  Public Declare Function socket Lib "ws2_32" _
  (ByVal af As Long, ByVal socket_type As Long, ByVal protocol_type As Long) As Long
  Public Declare Function closesocket Lib "ws2_32" (ByVal socket As Long) As Long
#End If

Public Const SO_BROADCAST As Integer = &H20
Public Const SO_DEBUG As Integer = &H1
Public Const SO_ACCEPTCONN As Integer = &H2
Public Const SO_REUSEADDR As Integer = &H4
Public Const SO_KEEPALIVE As Integer = &H8
Public Const SO_DONTROUTE As Integer = &H10
Public Const SO_USELOOPBACK As Integer = &H40
Public Const SO_LINGER As Integer = &H80
Public Const SO_OOBINLINE As Integer = &H100
Public Const SO_DONTLINGER As Integer = &HFF7F
Public Const SO_SNDBUF As Integer = &H1001
Public Const SO_RCVBUF As Integer = &H1002
Public Const SO_SNDLOWAT As Integer = &H1003
Public Const SO_RCVLOWAT As Integer = &H1004
Public Const SO_SNDTIMEO As Integer = &H1005
Public Const SO_RCVTIMEO As Integer = &H1006
Public Const SO_ERROR  As Integer = &H1007
Public Const SO_TYPE As Integer = &H1008
Public Const TCP_NODELAY = &H1
Public Const SOL_SOCKET As Long = &HFFFF&

Public Type LingerOptions
  l_OnOff As Integer
  l_Linger As Integer
End Type

#If WSVERSION = 1 Then
  Public Declare Function setsocketoption Lib "wsock32" _
  Alias "setsockopt" (ByVal socket As Long, _
  ByVal protocol_level As Long, _
  ByVal optname As Long, _
  optval As Any, ByVal optlen As Long) As Long
  Public Declare Function getsocketoption Lib "wsock32" _
  Alias "getsockopt" (ByVal socket As Long, _
  ByVal sp_level As Long, _
  ByVal optname As Long, _
  optval As Any, optlen As Long) As Long
#Else
  Public Declare Function setsocketoption Lib "ws2_32" _
  Alias "setsockopt" (ByVal socket As Long, _
  ByVal protocol_level As Long, _
  ByVal optname As Long, _
  optval As Any, ByVal optlen As Long) As Long
  Public Declare Function getsocketoption Lib "ws2_32" _
  Alias "getsockopt" (ByVal socket As Long, _
  ByVal sp_level As Long, _
  ByVal optname As Long, _
  optval As Any, optlen As Long) As Long
#End If

Public Const FIONREAD As Long = &H4004667F

#If WSVERSION = 1 Then
  Public Declare Function listen Lib "wsock32" _
  (ByVal socket As Long, _
  ByVal backlog As Long) As Long
  
  Public Declare Function ioctlsocket Lib "wsock32" _
  (ByVal socket As Long, ByVal cmd As Long, _
  lpArg As Long) As Long
  
  Public Declare Function socket_shutdown Lib _
  "wsock32" Alias "shutdown" _
  (ByVal socket As Long, ByVal how As Long) As Long
#Else
  Public Declare Function listen Lib "ws2_32" _
  (ByVal socket As Long, _
  ByVal backlog As Long) As Long
  
  Public Declare Function ioctlsocket Lib "ws2_32" _
  (ByVal socket As Long, ByVal cmd As Long, _
  lpArg As Long) As Long
  
  Public Declare Function socket_shutdown Lib _
  "ws2_32" Alias "shutdown" _
  (ByVal socket As Long, ByVal how As Long) As Long
#End If

Public Const MSG_NORMAL As Byte = 0
Public Const MSG_OOB As Byte = &H1
Public Const MSG_DONTROUTE As Byte = &H4

#If WSVERSION = 1 Then
  Public Declare Function recv Lib "wsock32" _
  (ByVal socket As Long, buf As Any, _
  ByVal buflen As Long, ByVal flags As Long) As Long
  Public Declare Function recvfrom Lib "wsock32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long, from As sockaddr_in, fromLen As Long) As Long
  Public Declare Function send Lib "wsock32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long) As Long
  Public Declare Function sendto Lib "wsock32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long, to_addr As sockaddr_in, ByVal toLen As Long) As Long
#Else
  Public Declare Function recv Lib "ws2_32" _
  (ByVal socket As Long, buf As Any, _
  ByVal buflen As Long, ByVal flags As Long) As Long
  Public Declare Function recvfrom Lib "ws2_32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long, from As sockaddr_in, fromLen As Long) As Long
  Public Declare Function send Lib "ws2_32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long) As Long
  Public Declare Function sendto Lib "ws2_32" (ByVal socket As Long, buf As Any, ByVal buflen As Long, ByVal flags As Long, to_addr As sockaddr_in, ByVal toLen As Long) As Long
#End If

Public Type Inetaddress
  Byte4 As Byte
  Byte3 As Byte
  Byte2 As Byte
  Byte1 As Byte
End Type

#If WSVERSION = 1 Then
  Public Declare Function inet_addr Lib "wsock32" (ByVal cp As String) As Long
  Public Declare Function inet_ntoa Lib "wsock32" (ByVal Inn As Long) As Long
  Public Declare Function htonl Lib "wsock32" (ByVal hostlong As Long) As Long
  Public Declare Function htons Lib "wsock32" (ByVal hostshort As Long) As Integer
  Public Declare Function WSAGetLastError Lib "wsock32" () As Long
  Public Declare Function gethostname Lib "wsock32" (ByVal hostnamebuffer As String, ByVal namelen As Long) As Long
#Else
  Public Declare Function inet_addr Lib "ws2_32" (ByVal cp As String) As Long
  Public Declare Function inet_ntoa Lib "ws2_32" (ByVal Inn As Long) As Long
  Public Declare Function htonl Lib "ws2_32" (ByVal hostlong As Long) As Long
  Public Declare Function htons Lib "ws2_32" (ByVal hostshort As Long) As Integer
  Public Declare Function WSAGetLastError Lib "ws2_32" () As Long
  Public Declare Function gethostname Lib "ws2_32" (ByVal hostnamebuffer As String, ByVal namelen As Long) As Long
#End If

Public Const FD_READ As Integer = &H1
Public Const FD_WRITE As Integer = &H2
Public Const FD_OOB As Integer = &H4
Public Const FD_ACCEPT As Integer = &H8
Public Const FD_CONNECT  As Integer = &H10
Public Const FD_CLOSE As Integer = &H20
'Not part of winsock
Public Const FD_ALL = FD_READ Or FD_WRITE Or FD_OOB Or FD_ACCEPT Or FD_CONNECT Or FD_CLOSE
Public Const FD_ALLEX = FD_READ Or FD_WRITE Or FD_ACCEPT Or FD_CONNECT Or FD_CLOSE
'Used for connection from a listening socket (fake)
Public Const FD_CONNECTEX As Integer = &H15

#If WSVERSION = 1 Then
  Public Declare Function WSAAsyncSelect Lib "wsock32" _
  (ByVal socket As Long, ByVal hwnd As Long, _
  ByVal iMsg As Long, ByVal lEvent As Long) As Long
#Else
  Public Declare Function WSAAsyncSelect Lib "ws2_32" _
  (ByVal socket As Long, ByVal hwnd As Long, _
  ByVal iMsg As Long, ByVal lEvent As Long) As Long
#End If

Public Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" ( _
    lpDest As Any, lpSource As Any, ByVal cbCopy As Long)
'
Public Declare Function CreateWindowEx Lib _
"user32" Alias "CreateWindowExA" ( _
ByVal dwExStyle As Long, _
ByVal lpClassName As String, _
ByVal lpWindowName As String, _
ByVal dwStyle As Long, _
ByVal x As Long, _
ByVal y As Long, _
ByVal nWidth As Long, _
ByVal nHeight As Long, _
ByVal hWndParent As Long, _
ByVal hMenu As Long, _
ByVal hInstance As Long, _
lpParam As Any) As Long

Public Declare Function _
  DefWindowProc Lib "user32" _
  Alias "DefWindowProcA" _
  (ByVal hwnd As Long, _
  ByVal wMsg As Long, _
  ByVal wParam As Long, _
  ByVal lParam As Long) As Long

Public Declare Function DestroyWindow _
Lib "user32" (ByVal hwnd As Long) As Long
    
Public Const SOCKET_TIMER = &H113 'WM_TIMER

Public Declare Function SetTimer Lib "user32" _
(ByVal hwnd As Long, ByVal nIDEvent As Long, _
ByVal uElapse As Long, ByVal lpTimerFunc As Long) As Long

Public Declare Function KillTimer Lib "user32" _
(ByVal hwnd As Long, ByVal nIDEvent As Long) As Long

Public Declare Function GetTickCount Lib "kernel32" () As Long

Public Declare Function SendMessage Lib "user32" _
Alias "SendMessageA" (ByVal hwnd As Long, _
ByVal wMsg As Long, ByVal wParam As Long, _
lParam As Any) As Long

Public Declare Function PostMessage Lib "user32" _
  Alias "PostMessageA" (ByVal hwnd As Long, _
  ByVal wMsg As Long, ByVal wParam As Long, _
  lParam As Long) As Long
  
Public Declare Function GetProp Lib "user32" _
  Alias "GetPropA" (ByVal hwnd As Long, _
  ByVal lpString As String) As Long
  
Public Declare Function SetProp Lib "user32" _
  Alias "SetPropA" (ByVal hwnd As Long, _
  ByVal lpString As String, ByVal hData As Long) As Long
  
Public Declare Function RemoveProp Lib "user32" _
  Alias "RemovePropA" (ByVal hwnd As Long, _
  ByVal lpString As String) As Long

Public Const WM_USER = &H400
Public Const DNS_REPLY = (WM_USER + 10)
Public Const SCK_REPLY = (WM_USER + 12)
Public Const SOCKS_REPLY = (WM_USER + 14)

Declare Function GlobalLock Lib "kernel32" _
(ByVal hMem As Long) As Long

Declare Function GlobalUnlock Lib "kernel32" _
(ByVal hMem As Long) As Long

Declare Function GlobalSize Lib "kernel32" _
(ByVal hMem As Long) As Long

Declare Function GlobalAlloc Lib "kernel32" _
  (ByVal wFlags As Long, ByVal dwBytes As Long) As Long

Declare Function GlobalReAlloc Lib "kernel32" _
(ByVal hMem As Long, ByVal dwBytes As Long, _
ByVal wFlags As Long) As Long

Declare Function GlobalFree Lib _
"kernel32" (ByVal hMem As Long) As Long

Public Const GMEM_MODIFY = &H80
Public Const GMEM_MOVEABLE = &H2

Public Type WNDCLASS
  style As Long
  lpfnwndproc As Long
  cbClsextra As Long
  cbWndExtra2 As Long
  hInstance As Long
  hIcon As Long
  hCursor As Long
  hbrBackground As Long
  lpszMenuName As String
  lpszClassName As String
End Type

Public Declare Function RegisterClass _
Lib "user32" Alias "RegisterClassA" ( _
Class As WNDCLASS) As Long

Public Declare Function UnregisterClass _
Lib "user32" Alias "UnregisterClassA" _
(ByVal lpClassName As String, _
ByVal hInstance As Long) As Long

Public Const GENERIC_WRITE = &H40000000
Public Const CREATE_ALWAYS = 2
Public Const CREATE_NEW = 1
Public Const FILE_ATTRIBUTE_ARCHIVE = &H20
Public Const FILE_ATTRIBUTE_NORMAL = &H80

Public Declare Function CreateFile Lib "kernel32" _
  Alias "CreateFileA" _
  (ByVal lpFileName As String, _
  ByVal dwDesiredAccess As Long, _
  ByVal dwShareMode As Long, _
  lpSecurityAttributes As Any, _
  ByVal dwCreationDisposition As Long, _
  ByVal dwFlagsAndAttributes As Long, _
  ByVal hTemplateFile As Long) As Long
  
Public Declare Function WriteFile Lib _
  "kernel32" (ByVal hFile As Long, lpBuffer As Any, _
  ByVal nNumberOfBytesToWrite As Long, _
  lpNumberOfBytesWritten As Long, _
  lpOverlapped As Any) As Long
  
Public Declare Function CloseHandle Lib "kernel32" _
  (ByVal hObject As Long) As Long
  
'Only public [r/w] access variable, the rest can only be read
Public ws_hwnd As Long
'
Private ws_init As Boolean
Private ws_timer As Long
Private ws_description As String
Private ws_system As String
Private ws_version_maj  As Long
Private ws_version_min As Long
Private ws_max_sockets As Long
Private ws_max_UDPd As Long

'Type to allow IP (long) port and object pointer to be packed
Public Type HostPortData
  host_in As Long
  host_port As Long
  host_inv As Long
End Type

Public Property Get WinsockStarted() As Boolean
  WinsockStarted = ws_init
End Property
Public Property Get WinsockDescription() As String
  WinsockDescription = ws_description
End Property
Public Property Get WinsockSystemStatus() As String
  WinsockSystemStatus = ws_system
End Property
Public Property Get WinsockLibrary() As String
  #If WSVERSION = 1 Then
    WinsockLibrary = "ws2_32.dll"
  #Else
    WinsockLibrary = "wsock32.dll"
  #End If
End Property
Public Property Get MessageHandle() As Long
  MessageHandle = ws_hwnd
End Property
Public Property Get VersionMajor() As Long
    VersionMajor = ws_version_maj
End Property
Public Property Get VersionMinor() As Long
    VersionMinor = ws_version_min
End Property
Public Property Get MaximumSockets() As Long
    MaximumSockets = ws_max_sockets
End Property
Public Property Get MaximumUDPData() As Long
    MaximumUDPData = ws_max_UDPd
End Property

Public Sub Main()
  'Class must be kept in memory as long as the dll is
  Static ALo As aeInit
  Set ALo = New aeInit
End Sub

'Returns error description from an error code if listed
Public Function WSAGetLastErrorMessage( _
    ByVal ErrorCode As Long) As String
    
    Select Case ErrorCode
        Case 0
            WSAGetLastErrorMessage = "No error"
        Case WSAEINTR
            WSAGetLastErrorMessage = "Interrupted system call"
        Case WSAEBADF
            WSAGetLastErrorMessage = "Bad file number"
        Case WSAEACCES
            WSAGetLastErrorMessage = "Permission denied"
        Case WSAEFAULT
            WSAGetLastErrorMessage = "Bad address"
        Case WSAEINVAL
            WSAGetLastErrorMessage = "Invalid argument"
        Case WSAEMFILE
            WSAGetLastErrorMessage = "Too many open sockets"
        Case WSAEWOULDBLOCK
            WSAGetLastErrorMessage = "Operation would block"
        Case WSAEINPROGRESS
            WSAGetLastErrorMessage = "Operation now in progress"
        Case WSAEALREADY
            WSAGetLastErrorMessage = "Operation already in progress"
        Case WSAENOTSOCK
            WSAGetLastErrorMessage = "Socket operation on non-socket"
        Case WSAEDESTADDRREQ
            WSAGetLastErrorMessage = "Destination address required"
        Case WSAEMSGSIZE
            WSAGetLastErrorMessage = "Message too long"
        Case WSAEPROTOTYPE
            WSAGetLastErrorMessage = "Protocol wrong type for socket"
        Case WSAENOPROTOOPT
            WSAGetLastErrorMessage = "Bad protocol option"
        Case WSAEPROTONOSUPPORT
            WSAGetLastErrorMessage = "Protocol not supported"
        Case WSAESOCKTNOSUPPORT
            WSAGetLastErrorMessage = "Socket type not supported"
        Case WSAEOPNOTSUPP
            WSAGetLastErrorMessage = "Operation not supported on socket"
        Case WSAEPFNOSUPPORT
            WSAGetLastErrorMessage = "Protocol family not supported"
        Case WSAEAFNOSUPPORT
            WSAGetLastErrorMessage = "Address family not supported"
        Case WSAEADDRINUSE
            WSAGetLastErrorMessage = "Address already in use"
        Case WSAEADDRNOTAVAIL
            WSAGetLastErrorMessage = "Can't assign requested address"
        Case WSAENETDOWN
            WSAGetLastErrorMessage = "Network is down"
        Case WSAENETUNREACH
            WSAGetLastErrorMessage = "Network is unreachable"
        Case WSAENETRESET
            WSAGetLastErrorMessage = "Net connection reset"
        Case WSAECONNABORTED
            WSAGetLastErrorMessage = "Software caused connection abort"
        Case WSAECONNRESET
            WSAGetLastErrorMessage = "Connection reset by peer"
        Case WSAENOBUFS
            WSAGetLastErrorMessage = "No buffer space available"
        Case WSAEISCONN
            WSAGetLastErrorMessage = "Socket is already connected"
        Case WSAENOTCONN
            WSAGetLastErrorMessage = "Socket is not connected"
        Case WSAESHUTDOWN
            WSAGetLastErrorMessage = "Can't send after socket shutdown"
        Case WSAETOOMANYREFS
            WSAGetLastErrorMessage = "Too many references can't splice"
        Case WSAETIMEDOUT
            WSAGetLastErrorMessage = "Connection timed out"
        Case WSAECONNREFUSED
            WSAGetLastErrorMessage = "Connection refused"
        Case WSAELOOP
            WSAGetLastErrorMessage = "Too many levels of symbolic links"
        Case WSAENAMETOOLONG
            WSAGetLastErrorMessage = "File name too long"
        Case WSAEHOSTDOWN
            WSAGetLastErrorMessage = "Host is down"
        Case WSAEHOSTUNREACH
            WSAGetLastErrorMessage = "No route to host"
        Case WSAENOTEMPTY
            WSAGetLastErrorMessage = "Directory not empty"
        Case WSAEPROCLIM
            WSAGetLastErrorMessage = "Too many processes"
        Case WSAEUSERS
            WSAGetLastErrorMessage = "Too many users"
        Case WSAEDQUOT
            WSAGetLastErrorMessage = "Disc quota exceeded"
        Case WSAESTALE
            WSAGetLastErrorMessage = "Stale NFS file handle"
        Case WSAEREMOTE
            WSAGetLastErrorMessage = "Too many levels of remote in path"
        Case WSASYSNOTREADY
            WSAGetLastErrorMessage = "Network subsystem is unavailable"
        Case WSAVERNOTSUPPORTED
            WSAGetLastErrorMessage = "Winsock version not supported"
        Case WSANOTINITIALISED
            WSAGetLastErrorMessage = "Winsock not yet initialized"
        Case WSAHOST_NOT_FOUND
            WSAGetLastErrorMessage = "Host not found"
        Case WSATRY_AGAIN
            WSAGetLastErrorMessage = "Non-authoritative host not found"
        Case WSANO_RECOVERY
            WSAGetLastErrorMessage = "Non-recoverable errors"
        Case WSANO_DATA
            WSAGetLastErrorMessage = "Valid name, no data record of requested type"
        Case WSAEDISCON
            WSAGetLastErrorMessage = "Graceful disconnect in progress"
        Case WSASYSCALLFAILURE
            WSAGetLastErrorMessage = "System call failure"
        Case WSA_NOT_ENOUGH_MEMORY
            WSAGetLastErrorMessage = "Insufficient memory available"
        Case WSA_OPERATION_ABORTED
            WSAGetLastErrorMessage = "Overlapped operation aborted"
        Case WSA_IO_INCOMPLETE
            WSAGetLastErrorMessage = "Overlapped I/O object not signalled"
        Case WSA_IO_PENDING
            WSAGetLastErrorMessage = "Overlapped I/O will complete later"
        Case Else
            WSAGetLastErrorMessage = "Unknown error"
    End Select
    
End Function

'Returns WSAERR* code from an lparam value
Public Function GetAsyncError(ByVal lParam As Long) As Long
    On Error GoTo gErr:

    '#define WSAGETASYNCERROR(lParam)  HIWORD(lParam)
    
    'Get the first 2 bytes of the lParam value (hiword)
    CopyMemory GetAsyncError, ByVal VarPtr(lParam) + 2, 2
    
    Exit Function
gErr:
    Err.Clear
End Function

'Returns a FD_* event from an lparam value
Public Function GetSelectEvent(ByVal lParam As Long) As Long
    On Error GoTo gErr:
    
    '#define WSAGETSELECTEVENT(lParam) LOWORD(lParam)
    
    'get last two bytes (loword)
    CopyMemory GetSelectEvent, lParam, 2
   
    Exit Function
gErr:
    Err.Clear
End Function

'Makes a lparam value from event and error (if any)
Public Function WSAMakeSelectReply( _
  lEvent As Long, lError As Long) As Long
    On Error Resume Next
    WSAMakeSelectReply = (lError * &H10000) + (lEvent And &HFFFF&)
End Function

'Returns a noted IP address from a long IP address, 1.2.3.4
'Returns an empty string on error.
'*Refined function*
Public Function GetNotedIP(ByVal InAddr As Long) As String
   On Error GoTo gErr:
  If InAddr = 0 Then Exit Function
  Dim INet As Inetaddress
  CopyMemory INet, InAddr, Len(INet)
  With INet
    GetNotedIP = CStr(.Byte4 & "." & .Byte3 & "." & .Byte2 & "." & .Byte1)
  End With
  
  Exit Function
gErr:
  Err.Clear
End Function

'Returns local machine name, or an empty string on error
Public Function GetLocalMachineName() As String
  On Error GoTo gErr:
  
    Dim APIVal As Long
    Dim lpStrBuf As String
    
    lpStrBuf = String(256, Chr(0))
    APIVal = gethostname(lpStrBuf, 256)
    If APIVal <> 0 Then Exit Function
    Dim ICur As Integer
    ICur = InStr(1, lpStrBuf, Chr(0))
    If ICur > 0 Then
      GetLocalMachineName = Mid(lpStrBuf, 1, ICur - 1)
    End If
    
  Exit Function
gErr:
  Err.Clear
End Function

'Returns local IP address or loopback IP address
Public Function GetLocalIP() As String
    On Error GoTo gErr:
       
    Dim lPtr As Long
    lPtr = gethostbyname(GetLocalMachineName)
    If lPtr = 0 Then Exit Function
    
    Dim IP_Data As hostent
    Dim IP_Addr_List As Long
    Dim IP_Addr As Long
    
    'Copy by pointer to a hostent struct
    CopyMemory IP_Data, ByVal lPtr, Len(IP_Data)
    'Get IP address list
    CopyMemory IP_Addr_List, ByVal IP_Data.h_addr_list, 4
    'Get first IP out of list
    CopyMemory IP_Addr, ByVal IP_Addr_List, 4
        
    GetLocalIP = GetNotedIP(IP_Addr)
    
Exit Function
gErr:
    Debug.Print "GetLocalIP Err: " & Err.Description
    Err.Clear
End Function

'Helper function used to get version info
Public Function LoByte(ByVal Param As Integer) As Long
  On Error Resume Next
  LoByte = Param And &HFF&
End Function

'Helper function used to get version info
Public Function HiByte(ByVal Param As Integer) As Long
  On Error Resume Next
  HiByte = Param \ &H100 And &HFF&
End Function

'Returns true/false if passed string is a host
'reverse logic, if it's not an IP4 address it must be a host
'To use this vice versa, Ret = Not IsHost("127.0.0.1")
Public Function IsHost(ByVal HostAsAny As String) As Boolean
  
    Select Case inet_addr(HostAsAny)
      Case -1
        If HostAsAny = "255.255.255.255" Then
          Exit Function
        End If
        IsHost = True
    End Select
    
End Function

Public Function EvtFace(ByVal lPtr As Long) As aeSocketEvent
  'Do no checking if "lPtr" is NOT zero
  'It's upto the caller to make sure it's not.
  'I know it would save on alot of 'if' statements
  'but what if lPtr *was* zero.. the caller
  'would have to check that the returned class
  'was *not* Nothing
  'Same difference
  Dim f, fT As aeSocketEvent
  '
  CopyMemory fT, lPtr, 4
  '
  Set f = fT
  '
  CopyMemory fT, 0&, 4
  '
  Set EvtFace = f
 
End Function

Public Function IsArrayEmpty(va As Variant) As Boolean
    Dim I As Long
    On Error Resume Next
    I = LBound(va, 1)
    IsArrayEmpty = (Err <> 0)
    Err = 0
End Function

Public Sub SetInterface( _
  ByVal iMsg As Long, idx As aeSubclass, _
  ByVal ClassName As String)
  SetProp ws_hwnd, CStr(ClassName & "#" & iMsg), ObjPtr(idx)
End Sub

Public Sub DeleteInterface(ByVal iMsg As Long, _
  ByVal ClassName As String)
  RemoveProp ws_hwnd, CStr(ClassName & "#" & iMsg)
End Sub

Public Function GetSubclassInterface( _
  ids As aeSubclass) As Long
  GetSubclassInterface = ObjPtr(ids)
End Function

Public Function GetAddrOf(lpAddr As Long) As Long
  GetAddrOf = lpAddr
End Function

Public Sub azure_InitEngine()
  '
  DoEvents
  'Register a window class
  Dim WND As WNDCLASS
  With WND
    'Don't fill parts of the struct that are already zero
    .lpfnwndproc = GetAddrOf(AddressOf WindowProcEx)
    .hInstance = App.hInstance
    .lpszMenuName = vbNullChar
    .lpszClassName = CStr("azure_" & App.Major)
  End With

  'Register class
  RegisterClass WND

  'Create a window from the class
  ws_hwnd = CreateWindowEx(0, WND.lpszClassName, "", 0, 1, 1, 2, 2, 0, 0, App.hInstance, ByVal 0)

  Dim APIVal As Long
  Dim WSAFo As WSAData
  'Start up winsock
  APIVal = WSAStartup(&H101, WSAFo)
  If APIVal <> 0 Then Exit Sub

  Dim ICur As Integer
  'Convert the filled byte array into a string and store
  ws_description = StrConv(WSAFo.Description, vbUnicode)
  'Find the first null char and only save behind that position
  ICur = InStr(1, ws_description, Chr(0))
  If ICur > 0 Then
    ws_description = Mid(ws_description, 1, ICur - 1)
  End If

  'Same as above but for the system status
  ws_system = StrConv(WSAFo.SystemStatus, vbUnicode)
  ICur = InStr(1, ws_system, Chr(0))
  If ICur > 0 Then
    ws_system = Mid(ws_system, 1, ICur - 1)
  End If

  'Work out version information from winsock udt
  ws_version_maj = CLng(Trim(Str(HiByte(WSAFo.HighVersion))))
  ws_version_min = CLng(Trim(Str(LoByte(WSAFo.HighVersion))))

  'Work out the maximum supported sockets
  ws_max_sockets = WSAFo.MaxSockets
  If ws_max_sockets < 0 Then ws_max_sockets = 65536 + ws_max_sockets

  'Work out the maximum udp data gram
  ws_max_UDPd = WSAFo.MaxUDPdg
  If ws_max_UDPd < 0 Then ws_max_UDPd = 65536 + ws_max_UDPd

  'Create a timer,
  'We don't have a call back function for a timer here
  'Windows will post messages on our window
  'Any class that wants timer feedback will get it
  'by calling HookTimer, UnHookTimer
  ws_timer = SetTimer(ws_hwnd, 100, 1000, 0&)
  '
  ws_init = True
End Sub

Public Sub azure_DeInitEngine()
   '
   DoEvents
   'Shutdown winsock, any Winsock API calls made now
   'will fail
   WSACleanup
   'Kill timer
   If ws_timer <> 0 Then
    KillTimer ws_hwnd, ws_timer
    'Set timer ID to nil
    ws_timer = 0
   End If
   '
   ws_init = False
   'Free the window
   DestroyWindow ws_hwnd: ws_hwnd = 0
   ws_description = ""
   ws_system = ""
   ws_max_UDPd = 0
   ws_max_sockets = 0
   UnregisterClass "azure_" & App.Major, App.hInstance
End Sub

Public Sub wsOpenAsync( _
  ByVal hwnd As Long, _
  ByVal iMsg As Long, _
  ByVal idEvent As Long, _
  ByVal dwTime As Long)
  
  If idEvent Then
    Dim hPD As HostPortData
    Dim f, fT As aeSocket
    'Copy from pointer to struct
    CopyMemory hPD, ByVal idEvent, Len(hPD)
    With hPD
      'Check if data is present
      If (.host_in <> 0) And (.host_inv <> 0) And (.host_port <> 0) Then
        CopyMemory fT, .host_inv, 4
        Set f = fT
        CopyMemory fT, 0&, 4
        f.wsOpen GetNotedIP(.host_in), .host_port
      End If
      End With
  End If
  
  'Kill timer
  KillTimer hwnd, idEvent

End Sub

Public Function WindowProcEx( _
  ByVal hwnd As Long, ByVal iMsg As Long, _
  ByVal wParam As Long, ByVal lParam As Long) As Long
          
    Dim iwp As aeSubclass, iwpT As aeSubclass
    Dim lObj As Long
    
    Select Case iMsg
      Case DNS_REPLY
        lObj = GetProp(hwnd, CStr("DNS#" & wParam))
      Case SCK_REPLY
        lObj = GetProp(hwnd, CStr("SCK#" & wParam))
      Case SOCKS_REPLY
        lObj = GetProp(hwnd, CStr("SOCKS#" & wParam))
      Case SOCKET_TIMER
        '
        Dim I As Long
        Dim IPc As Long
        Dim lPtr As Long
        '
        IPc = GetProp(hwnd, "#c#timer")
        'No classes want this message
        If IPc = 0 Then GoTo NormalProc
        '
        For IPc = 1 To IPc
          lPtr = GetProp(ws_hwnd, CStr("obj#" & IPc))
          If lPtr <> 0 Then
            '
            CopyMemory iwpT, lPtr, 4
            Set iwp = iwpT
            CopyMemory iwpT, 0&, 4
            iwp.WindowProc hwnd, iMsg, wParam, lParam
            '
            GoTo NormalProc
          End If
        Next
        
    End Select
  
    Select Case lObj
    Case 0
NormalProc:
      WindowProcEx = DefWindowProc(hwnd, iMsg, wParam, lParam)
      Exit Function
    Case Else
      CopyMemory iwpT, lObj, 4
      Set iwp = iwpT
      CopyMemory iwpT, 0&, 4
      WindowProcEx = iwp.WindowProc(hwnd, iMsg, wParam, ByVal lParam)
      Exit Function
    End Select

End Function

Public Sub HookTimer(ids As aeSubclass)
  'If the window doesn't exist
  If ws_hwnd = 0 Then Exit Sub
  Dim lPtr As Long
  Dim c As Long
  'Get the count
  c = GetProp(ws_hwnd, "#c#timer")
  'Save the count
  c = c + 1
  'Get the object pointer Of the subclass interface
  lPtr = ObjPtr(ids)
  'save the count to match the object pointer
  SetProp ws_hwnd, CStr(lPtr & "#"), c
  'Save the pointer
  SetProp ws_hwnd, CStr("obj#" & c), lPtr
  'Save the global count
  SetProp ws_hwnd, CStr("#c#timer"), c
End Sub

Public Sub UnHookTimer(ids As aeSubclass)
  'If the window doesn't exist, exit
  If ws_hwnd = 0 Then Exit Sub
  '
  Dim c As Long
  Dim lPtr As Long
  Dim cPtr As Long
  
  'Get the object pointer
  lPtr = ObjPtr(ids)
  'Get the count
  cPtr = GetProp(ws_hwnd, CStr(lPtr & "#"))
  'Remove the count
  RemoveProp ws_hwnd, CStr(lPtr & "#")
  'Remove the object
  RemoveProp ws_hwnd, CStr("#obj#" & cPtr)
  'Get the global count
  c = GetProp(ws_hwnd, CStr("#c#timer"))
  '
  If c = 0 Then Exit Sub
  '
  If c = 1 Then
    'Remove the count
    RemoveProp ws_hwnd, CStr("#c#timer")
    Exit Sub
  End If
  'Dec count
  c = c - 1
  'Save count
  SetProp ws_hwnd, CStr("#c#timer"), c

End Sub
