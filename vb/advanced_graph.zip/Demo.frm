VERSION 5.00
Begin VB.Form frmDemo 
   Caption         =   "Form1"
   ClientHeight    =   7590
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   5895
   Icon            =   "Demo.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   506
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   393
   StartUpPosition =   3  'Windows-Standard
   Begin VB.OptionButton optMenu 
      Caption         =   "Rotate"
      Height          =   375
      Index           =   2
      Left            =   3000
      Style           =   1  'Grafisch
      TabIndex        =   15
      Top             =   120
      Width           =   1335
   End
   Begin VB.OptionButton optMenu 
      Caption         =   "AlphaBlend"
      Height          =   375
      Index           =   1
      Left            =   1560
      Style           =   1  'Grafisch
      TabIndex        =   7
      Top             =   120
      Width           =   1335
   End
   Begin VB.OptionButton optMenu 
      Caption         =   "Brightness"
      Height          =   375
      Index           =   0
      Left            =   120
      Style           =   1  'Grafisch
      TabIndex        =   5
      Top             =   120
      Value           =   -1  'True
      Width           =   1335
   End
   Begin VB.Frame fraScreen 
      Caption         =   "Brightness"
      Height          =   6615
      Index           =   0
      Left            =   120
      TabIndex        =   0
      Top             =   720
      Width           =   5655
      Begin VB.PictureBox picBrightness 
         AutoRedraw      =   -1  'True
         AutoSize        =   -1  'True
         Height          =   3660
         Left            =   240
         Picture         =   "Demo.frx":1FF2
         ScaleHeight     =   240
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   320
         TabIndex        =   3
         Top             =   360
         Width           =   4860
      End
      Begin VB.HScrollBar HScroll1 
         Height          =   255
         LargeChange     =   32
         Left            =   240
         Max             =   255
         Min             =   -255
         TabIndex        =   2
         Top             =   4320
         Width           =   4815
      End
      Begin VB.Label Label1 
         Caption         =   "Adjust the slider to change the Brightness of the picture."
         Height          =   1215
         Left            =   240
         TabIndex        =   10
         Top             =   5040
         Width           =   4815
      End
      Begin VB.Label labBrightness 
         Caption         =   "Brightness-level: 0"
         Height          =   255
         Left            =   240
         TabIndex        =   4
         Top             =   4080
         Width           =   4815
      End
   End
   Begin VB.Frame fraScreen 
      Caption         =   "Rotate"
      Height          =   6615
      Index           =   2
      Left            =   120
      TabIndex        =   14
      Top             =   720
      Width           =   5655
      Begin VB.PictureBox picRot 
         AutoRedraw      =   -1  'True
         AutoSize        =   -1  'True
         Height          =   1860
         Left            =   3120
         Picture         =   "Demo.frx":60EC
         ScaleHeight     =   120
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   160
         TabIndex        =   20
         Top             =   4680
         Visible         =   0   'False
         Width           =   2460
      End
      Begin VB.CheckBox chkRotMask 
         Caption         =   "Mask Color"
         Height          =   255
         Left            =   240
         TabIndex        =   19
         Top             =   4680
         Width           =   1215
      End
      Begin VB.CheckBox chkRotSmooth 
         Caption         =   "Smooth rotate"
         Height          =   255
         Left            =   1560
         TabIndex        =   18
         Top             =   4680
         Width           =   1575
      End
      Begin VB.HScrollBar HScroll3 
         Height          =   255
         LargeChange     =   500
         Left            =   240
         Max             =   3600
         Min             =   -3600
         TabIndex        =   17
         Top             =   4320
         Width           =   4815
      End
      Begin VB.PictureBox picRotate 
         AutoRedraw      =   -1  'True
         Height          =   3660
         Left            =   240
         ScaleHeight     =   240
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   320
         TabIndex        =   16
         Top             =   360
         Width           =   4860
      End
      Begin VB.Label labAngle 
         Caption         =   "Angle: 0�"
         Height          =   255
         Left            =   240
         TabIndex        =   21
         Top             =   4080
         Width           =   4815
      End
   End
   Begin VB.Frame fraScreen 
      Caption         =   "AlphaBlend"
      Height          =   6615
      Index           =   1
      Left            =   120
      TabIndex        =   1
      Top             =   720
      Width           =   5655
      Begin VB.CheckBox Check1 
         Caption         =   "Use MaskColor"
         Height          =   255
         Left            =   240
         TabIndex        =   13
         Top             =   4680
         Value           =   1  'Aktiviert
         Width           =   1575
      End
      Begin VB.PictureBox picSchwan 
         AutoRedraw      =   -1  'True
         AutoSize        =   -1  'True
         Height          =   1860
         Left            =   2880
         Picture         =   "Demo.frx":1422E
         ScaleHeight     =   120
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   174
         TabIndex        =   12
         Top             =   4680
         Visible         =   0   'False
         Width           =   2670
      End
      Begin VB.HScrollBar HScroll2 
         Height          =   255
         LargeChange     =   16
         Left            =   240
         Max             =   255
         TabIndex        =   8
         Top             =   4320
         Value           =   128
         Width           =   4815
      End
      Begin VB.PictureBox picBlend 
         AutoRedraw      =   -1  'True
         AutoSize        =   -1  'True
         Height          =   3660
         Left            =   240
         ScaleHeight     =   240
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   320
         TabIndex        =   6
         Top             =   360
         Width           =   4860
      End
      Begin VB.Label Label2 
         Caption         =   $"Demo.frx":23810
         Height          =   1215
         Left            =   240
         TabIndex        =   11
         Top             =   5040
         Width           =   4695
      End
      Begin VB.Label labAlpha 
         Caption         =   "Alpha-Value: 0"
         Height          =   255
         Left            =   240
         TabIndex        =   9
         Top             =   4080
         Width           =   4815
      End
   End
End
Attribute VB_Name = "frmDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Declare Function FoxBrightness Lib "FoxCBmp.dll" (ByVal DstDC As Long, ByVal DstBmp As Long, ByVal SrcDC As Long, ByVal SrcBmp As Long, ByVal TransColor As Long, ByVal Brightness As Long, ByVal Flags As Long) As Long
Private Declare Function FoxBlendIn Lib "FoxCBmp.dll" (ByVal DstDC As Long, ByVal DstX As Long, ByVal DstY As Long, ByVal SrcDC As Long, ByVal SrcBmp As Long, ByVal TransColor As Long, ByVal Alpha As Byte, ByVal Flags As Long) As Long
Private Declare Function FoxRotate Lib "FoxCBmp.dll" (ByVal DstDC As Long, ByVal DstX As Long, ByVal DstY As Long, ByVal SrcDC As Long, ByVal SrcBmp As Long, ByVal TransColor As Long, ByVal Alpha As Double, ByVal Flags As Long) As Long
Private Declare Function GetTickCount Lib "kernel32" () As Long

Dim CurX As Long, CurY As Long
Dim OldTime As Long

Private Sub Check1_Click()
    DrawSwane
End Sub

Private Sub chkRotMask_Click()
    HScroll3_Change
End Sub

Private Sub chkRotSmooth_Click()
    HScroll3_Change
End Sub

Private Sub Form_Load()
    picBlend.Picture = picBrightness.Picture
    picRotate.Picture = picBrightness.Picture
    optMenu(0).Value = True
    optMenu_Click 0
    CurX = picBlend.ScaleWidth \ 2
    CurY = picBlend.ScaleHeight \ 2
    HScroll3_Change
    DrawSwane
End Sub

Private Sub HScroll1_Change()
    OldTime = GetTickCount
    FoxBrightness picBrightness.hDC, picBrightness.Image.Handle, picBrightness.hDC, picBrightness.Picture.Handle, 0, HScroll1, 0
    Caption = GetTickCount - OldTime & " ms"
    picBrightness.Refresh
    labBrightness = "Brightness-level: " & HScroll1
    labBrightness.Refresh
End Sub

Private Sub HScroll1_Scroll()
    HScroll1_Change
End Sub

Private Sub HScroll2_Change()
    DrawSwane
    labAlpha = "Alpha-Value: " & HScroll2
    labAlpha.Refresh
End Sub

Private Sub HScroll2_Scroll()
    HScroll2_Change
End Sub

Private Sub HScroll3_Change()
    picRotate.Cls
    OldTime = GetTickCount
    FoxRotate picRotate.hDC, picRotate.ScaleWidth \ 2, picRotate.ScaleHeight \ 2, picRot.hDC, picRot.Image.Handle, &HFF00FF, HScroll3 / 10, chkRotMask + chkRotSmooth * 2
    Caption = GetTickCount - OldTime
    picRotate.Refresh
    labAngle = "Angle: " & HScroll3 / 10 & "�"
    labAngle.Refresh
End Sub

Private Sub HScroll3_Scroll()
    HScroll3_Change
End Sub

Private Sub optMenu_Click(Index As Integer)
    fraScreen(Index).ZOrder 0
End Sub

Private Sub picBlend_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    CurX = x
    CurY = y
    DrawSwane
End Sub

Private Sub DrawSwane()
    picBlend.Cls
    OldTime = GetTickCount
    FoxBlendIn picBlend.hDC, CurX - picSchwan.ScaleWidth \ 2, CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, (Picture2.ScaleWidth - picSchwan.ScaleWidth) \ 2, CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, Picture2.ScaleWidth - CurX - picSchwan.ScaleWidth \ 2, CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, CurX - picSchwan.ScaleWidth \ 2, (Picture2.ScaleHeight - picSchwan.ScaleHeight) \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, (Picture2.ScaleWidth - picSchwan.ScaleWidth) \ 2, (Picture2.ScaleHeight - picSchwan.ScaleHeight) \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, Picture2.ScaleWidth - CurX - picSchwan.ScaleWidth \ 2, (Picture2.ScaleHeight - picSchwan.ScaleHeight) \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, CurX - picSchwan.ScaleWidth \ 2, Picture2.ScaleHeight - CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, (Picture2.ScaleWidth - picSchwan.ScaleWidth) \ 2, Picture2.ScaleHeight - CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    'FoxBlendIn Picture2.hDC, Picture2.ScaleWidth - CurX - picSchwan.ScaleWidth \ 2, Picture2.ScaleHeight - CurY - picSchwan.ScaleHeight \ 2, picSchwan.hDC, picSchwan.Picture.Handle, &HFF00FF, HScroll2, -CBool(Check1)
    Caption = GetTickCount - OldTime & " ms"
    picBlend.Refresh
End Sub

