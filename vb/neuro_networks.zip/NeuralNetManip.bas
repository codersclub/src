Attribute VB_Name = "NeuralNetManip"
Option Explicit
'the primary objective of this program is to show
'the propagation of a set of input signals.
'and, to attempt the formation of a least resistant
'path from that set of inputs to a set of correct outputs.

'to test it, use the toggle buttons to modify the behaviour
'of the network...
'green means true and red means false

'a 2d/1d neural network model was used instead of 3d or xd

'limits of the neural net
Global Const maxinputs = 3
Global Const maxoutputs = 3
Global Const maxArrayX = 35             'maximum x size of neural net
Global Const maxArrayY = 35             'maximum y size of neural net
Global Const maxInputConnections = 6    'maximum input connections per node
Global Const maxOutputConnections = 6   'maximum output connections per node
Global Const maxThreshold = maxInputConnections         'maximum resistence
Global Const maxConnections = 6 * maxArrayX * maxArrayY    'is proportional to the size of the network

'parameters of the neural net
Global rgbmode As Integer
Global drawingmode As Integer
Global usepunish As Boolean
Global usedimension As Integer
Global usepropagationmethod As Integer
Global usesignalboost As Boolean
Global executionmethod As Integer

'modifiers of the neural net
Global Const feedrate = 5          'rate a which the inputs are incremented
Global Const curvature = 7
Global Const lastActivatedCeiling = 2                'Threshold increment rate (every rIncRate that neuralNet has not been used increase the r)
Global Const ThresholdInc = 10 'Threshold increment (increase neuralNet r by ri for rir
Global randcount As Integer
Global numberOfConnections As Integer

'miscellaneous variables
Global Const pi = 3.1415926535
Global Const e = 2.718281828
Global Const rads = pi / 180
Global Const topOfForm = 73         'top of the form
Global lastmousex As Integer
Global lastmousey As Integer
Global preend As Boolean
Global rgb2(255) As Double          'stores the colors of the palette
Global randomation(10000) As pt

'structures
Type pt
    x As Integer
    y As Integer
End Type
Type connection
    fromX As Integer
    fromY As Integer
    toX As Integer
    toY As Integer
    
    result As Integer    'either 1 or 0
    multiplier As Double 'will multiply the result by the value (between 0 and 1)
End Type
Type inputNeuron
    x As Integer
    y As Integer
    active As Boolean
End Type
Type outputNeuron
    x As Integer
    y As Integer
    active As Boolean
    isSolution As Boolean
    punishTemplate(maxArrayX, maxArrayY) As Double
End Type

'the neuron
Type neuron
    Threshold As Double
    lastActivated As Integer   'last activated (reaches maximum)
    tempCharge As Integer      'to keep track of the activity of the neuron
    'connections
    inputConnections(maxInputConnections) As Integer   'index of a connection
    outputConnections(maxOutputConnections) As Integer 'index of a connection
    numberOfOutputs As Integer 'maximum output connections for the node
    numberOfInputs As Integer 'maximum input connections for the node
End Type

Global inputs(maxinputs) As inputNeuron
Global outputs(maxoutputs) As outputNeuron
'the connections are external from the neural net
Global connections(maxConnections) As connection
'the neural network (just a 2d array of nodes)
Global neuralNet(maxArrayX, maxArrayY) As neuron


Public Sub InitializeNeuralNet()
    'initialize neural net
    Dim xx, yy, cc, xx2, yy2
    Dim maxdist, curdist
    'nullify all the connections (-1)
    For cc = 0 To maxConnections
        connections(cc).fromX = -1
        connections(cc).fromY = -1
        connections(cc).toX = -1
        connections(cc).toY = -1
        connections(cc).multiplier = 1
        connections(cc).result = 0
    Next
    'build the neural net
    For xx = 0 To maxArrayX
        For yy = 0 To maxArrayY
            'set initial values
            neuralNet(xx, yy).Threshold = 0
            neuralNet(xx, yy).lastActivated = lastActivatedCeiling + 1       'set last activated
            neuralNet(xx, yy).numberOfInputs = 0       'initialize maximum input connection index
            neuralNet(xx, yy).numberOfOutputs = 0       'initialize maximum output connection index
            neuralNet(xx, yy).tempCharge = 0
            'nullify all connections
            For cc = 0 To maxInputConnections
                neuralNet(xx, yy).inputConnections(cc) = -1
            Next
            For cc = 0 To maxInputConnections
                neuralNet(xx, yy).outputConnections(cc) = -1
            Next
            
        Next
    Next
    For xx = 0 To maxArrayX
        For yy = 0 To maxArrayY
            'build output connections between the nodes
            'depending on the number of dimensions (1d or 2d)
            If usedimension = 1 Then
                'only assign connections to the first row of nodes
                'to form the 1dimensional neural net
                If yy = 0 Then
                    Call assignConnectionFromTo((xx), (yy), (xx + 1), (yy))
                    Call assignConnectionFromTo((xx), (yy), (xx - 1), (yy))
                End If
            Else
                'connect all nodes to three neighbors on the right
                
                'Call assignConnectionFromTo((xx - 1), (yy - 1), (xx), (yy))
                'Call assignConnectionFromTo((xx - 1), (yy), (xx), (yy))
                'Call assignConnectionFromTo((xx - 1), (yy + 1), (xx), (yy))
                
                Call assignConnectionFromTo((xx), (yy), (xx + 1), (yy - 1))
                Call assignConnectionFromTo((xx), (yy), (xx + 1), (yy))
                Call assignConnectionFromTo((xx), (yy), (xx + 1), (yy + 1))
            End If
            'the output connection counter is too big (reduce by 1)
            'If neuralNet(xx, yy).numberOfOutputs - 1 >= 0 Then
             '   neuralNet(xx, yy).numberOfOutputs = neuralNet(xx, yy).numberOfOutputs - 1
            'End If
            'same for inputs
            'If neuralNet(xx, yy).numberOfInputs - 1 >= 0 Then
            '    neuralNet(xx, yy).numberOfInputs = neuralNet(xx, yy).numberOfInputs - 1
            'End If
        Next
    Next
    'the Threshold of the outputs should be small
    For xx = 0 To maxoutputs
        neuralNet(inputs(xx).x, inputs(xx).y).Threshold = 0
        Call createOutputPunishTemplate((xx))
    Next
    Randomize
End Sub
Private Sub assignConnectionFromTo(fromX As Integer, fromY As Integer, toX As Integer, toY As Integer)
    'connect two nodes
    'connect the node(fromx,fromy) to the node(tox,toy)
    
    'to connect two nodes save the outputs for the source node
    'and the inputs for destination node
    Dim aa, found
    'error-check the supplied (x,y)s are valid
    If inbounds((fromX), (fromY)) And inbounds((toX), (toY)) Then
        'save the outputs for the source node
        found = False
        'error-check that the connection does not already exist
        'For aa = 0 To numberOfConnections
        '    If connections(aa).fromX = fromX And connections(aa).fromY = fromY And connections(aa).toX = toX And connections(aa).toY = toY Then
        '        found = True
        '    End If
        'Next
        'error-check that the we have enough unassigned connections
        If numberOfConnections < maxConnections And neuralNet(fromX, fromY).numberOfInputs < maxInputConnections And neuralNet(fromX, fromY).numberOfOutputs < maxOutputConnections Then
            If found = False Then
                connections(numberOfConnections).fromX = fromX
                connections(numberOfConnections).fromY = fromY
                connections(numberOfConnections).toX = toX
                connections(numberOfConnections).toY = toY
                
                neuralNet(fromX, fromY).outputConnections(neuralNet(fromX, fromY).numberOfOutputs) = numberOfConnections
                neuralNet(toX, toY).inputConnections(neuralNet(toX, toY).numberOfInputs) = numberOfConnections
                
                neuralNet(fromX, fromY).numberOfOutputs = neuralNet(fromX, fromY).numberOfOutputs + 1
                neuralNet(toX, toY).numberOfInputs = neuralNet(toX, toY).numberOfInputs + 1
                
                numberOfConnections = numberOfConnections + 1
            End If
        End If
    End If
End Sub
Public Sub propagateNeuralNet()
    'main propagation routine
    'objective: to form an identifiable path of
    'least Threshold between a set of inputs and a
    'set of correct outputs avoiding the incorrect outputs
    'by trial and error
    
    Dim xx, yy, xx2, yy2, sum
    Dim retpt As pt
    Randomize
    'preend used to break out of the infinit loop
    preend = False
    randcount = 0
    'loop until prompted otherwise
    While (Not preend)
        'fire the inputs
        Call fireInputs
        'if any outputs have been reached, train the interneurons
        Call trainFromOutputValues
        'select the node to process
        retpt = getnextPT((xx), (yy))
        xx = retpt.x
        yy = retpt.y
        'check if we should propagate the signal
        sum = sumOfInputs((xx), (yy))
        If SumGreaterThanThreshold((xx), (yy), (sum)) Then
            Call propagateFrom((xx), (yy), (sum))
            Call drawnode((xx), (yy))
        Else
            'record the no-change
            Call increaseLastActivated((xx), (yy))
        End If
        DoEvents
    Wend
End Sub

Private Function SumGreaterThanThreshold(xx As Integer, yy As Integer, sum As Integer) As Boolean
    'is the sum of the inputs values greater than the threshold of the neuron
    SumGreaterThanThreshold = (sum > neuralNet(xx, yy).Threshold)
End Function

Public Function inbounds(xx As Integer, yy As Integer) As Boolean
    'validate the xx and yy for error checking
    inbounds = (xx >= 0 And xx <= maxArrayX And yy >= 0 And yy <= maxArrayY)
End Function

Public Sub fireInputs()
    Dim i, cc, xx, yy
    'increment the inputs
    For i = 0 To maxinputs
        If inputs(i).active Then
            xx = inputs(i).x
            yy = inputs(i).y
            neuralNet(xx, yy).Threshold = 0
            For cc = 0 To neuralNet(xx, yy).numberOfOutputs - 1
                connections(getConnectionIndex((xx), (yy), (False), (cc))).result = 1
            Next
            Call drawnode((xx), (yy))
        End If
    Next

End Sub

Private Sub trainFromOutputValues()
    Dim i, xx, yy
    'based on when the outputs were last activated
    'reward or punish the entire network
    For i = 0 To maxoutputs
        If outputs(i).active Then
            xx = outputs(i).x
            yy = outputs(i).y
            If neuralNet(xx, yy).lastActivated = 0 Then
                If Not outputs(i).isSolution Then
                    Call punishfrom((xx), (yy))
                Else
                    Call rewardall
                    neuralNet(xx, yy).Threshold = 0
                End If
                neuralNet(xx, yy).lastActivated = 1
            End If
        End If
    Next
End Sub

Public Sub rewardall()
    'globally increase the Threshold of each node by a small percent of its current value
    Dim xx, yy, cb, newvalue
    'For xx = 0 To maxArrayX
    '    For yy = 0 To maxArrayY
    '        cb = (100 - neuralNet(xx, yy).lastActivated) / maxThreshold
    '        newvalue = neuralNet(xx, yy).Threshold * 1.1
    '        Call NeuralNetManip.modifyThreshold((xx), (yy), (-10000), (newvalue))
    '        Call drawnode((xx), (yy))
    '    Next
    'Next
End Sub

Public Sub punishfrom(xxf As Integer, yyf As Integer)
    Dim xx, yy, cb, newvalue, maxdist, curdist
    Dim cb2, newvalue2, maxlastActivated, curlastActivated
    Dim distancequotient, lastActivatedquotient, avgrule
    Dim outputx
    'If isoutput((xxf), (yyf)) Then
    '    outputx = getoutput((xxf), (yyf))
    '    'use a very exhaustive method to train the nodes
    '    'create a mole hill around the output site
    '    'doesnt work too well
    '    For xx = 0 To maxArrayX
    '        For yy = 0 To maxArrayY
    '            curdist = outputs(outputx).punishTemplate(xx, yy)
    '            'increase Threshold
    '            If curdist > 0 Then
    '                'make sure the Threshold is atleast 1
    '                If neuralNet(xx, yy).Threshold < 0.01 Then
    '                    neuralNet(xx, yy).Threshold = 1
    '                End If
    '                newvalue = (curdist * maxThreshold) + neuralNet(xx, yy).Threshold
    '            Else
    '                newvalue = -10000
    '            End If
    '            Call NeuralNetManip.modifyThreshold((xx), (yy), (-10000), (newvalue))
    '            Call drawnode((xx), (yy))
    '        Next
    '    Next
    'End If
End Sub

Private Function getnextPT(xx As Integer, yy As Integer) As pt
    'used to return the x,y of the node to process next
    'based on which processing mode is being used
    getnextPT.x = xx
    getnextPT.y = yy
    If usedimension = 0 Then
        'use the full two dimensional model
        If usepropagationmethod = 0 Then
            'totally randomly select some x,y
            getnextPT.x = Int(Rnd * maxArrayX)
            getnextPT.y = Int(Rnd * maxArrayY)
        ElseIf usepropagationmethod = 1 Then
            'select the next preassembled random set of x,y
            If randcount + 1 > 10000 Then
                randcount = 0
            Else
                randcount = randcount + 1
            End If
            getnextPT.x = randomation(randcount).x
            getnextPT.y = randomation(randcount).y
        ElseIf usepropagationmethod = 2 Then
            'increase y based on x
            'once x reaches maxArrayX increase it by 1
            'once y reaches maxArrayX reset both
            'same as using one while loop in another
            getnextPT.x = xx + 1
            If getnextPT.x > maxArrayX Then
                getnextPT.x = 0
                getnextPT.y = yy + 1
                If getnextPT.y > maxArrayY Then
                    getnextPT.y = 0
                End If
            End If
        End If
    Else
        'use the reduced (simpler) one dimensional model
        If usepropagationmethod = 2 Then
            'y is always 0
            'x loops once it reaches maxArrayX
            getnextPT.y = 0
            getnextPT.x = xx + 1
            If getnextPT.x > maxArrayX Then
                getnextPT.x = 0
            End If
        ElseIf usepropagationmethod = 1 Then
            'y is always 0
            'use the preassembled random x's only
            If randcount + 1 > 10000 Then
                randcount = 0
            Else
                randcount = randcount + 1
            End If
            getnextPT.x = randomation(randcount).x
            getnextPT.y = 0
        ElseIf usepropagationmethod = 0 Then
            'y is always 0
            'x is totally random
            getnextPT.x = Int(Rnd * maxArrayX)
            getnextPT.y = 0
        End If
    End If
End Function

Private Sub increaseLastActivated(xx As Integer, yy As Integer)
    If neuralNet(xx, yy).lastActivated + 1 = lastActivatedCeiling Then
        'the counter has just reached its maximum
        neuralNet(xx, yy).lastActivated = lastActivatedCeiling + 1
    ElseIf neuralNet(xx, yy).lastActivated + 1 < lastActivatedCeiling Then
        neuralNet(xx, yy).lastActivated = neuralNet(xx, yy).lastActivated + 1
    End If
End Sub
Private Sub modifyThreshold(xx As Integer, yy As Integer, changeby As Double, newThreshold As Double)
    Dim newval
    If xx >= 0 And yy >= 0 And xx <= maxArrayX And yy <= maxArrayY Then
        newval = -1
        If changeby <> -10000 Then
            newval = neuralNet(xx, yy).Threshold + changeby
        ElseIf newThreshold <> -10000 Then
            newval = newThreshold
        End If
        
        If newval >= 0 And newval <= maxThreshold Then
            neuralNet(xx, yy).Threshold = newval
            Call Form1.updateLabel((lastmousex), (lastmousey))
        ElseIf newval > maxThreshold Then
            neuralNet(xx, yy).Threshold = maxThreshold
        ElseIf newval < 0 Then
            neuralNet(xx, yy).Threshold = 0
        End If
    End If
End Sub


Public Function dist(xx As Double, yy As Double, xx2 As Double, yy2 As Double)
    'just return the distance from the first point to the second point
    dist = Sqr((xx - xx2) ^ 2 + (yy - yy2) ^ 2)
End Function

Public Function propagateFrom(xx As Integer, yy As Integer, sum As Integer) As Boolean
    'the propagation will fire a 1 into the result value of the output connections
    Dim i, tempx, tempy, cc
    Randomize
    'error check (somewhat redundant for confident code)
    If inbounds((xx), (yy)) Then
        'clear the input values
        For i = 0 To neuralNet(xx, yy).numberOfInputs - 1
            cc = getConnectionIndex((xx), (yy), (True), (i))
            If cc <> -1 Then
                connections(cc).result = 0
            End If
        Next
        'set the output values
        For i = 0 To neuralNet(xx, yy).numberOfOutputs - 1
            cc = getConnectionIndex((xx), (yy), (False), (i))
            If cc <> -1 Then
                connections(cc).result = 1
            End If
        Next
        neuralNet(xx, yy).lastActivated = 0
        'Call NeuralNetManip.modifyThreshold((xx), (yy), (-(sc / neuralNet(xx, yy).Charge)), (-10000))
        neuralNet(xx, yy).tempCharge = sum
    End If
End Function


Public Sub define2DInputLocations()
    Dim row, col, xx, yy
    'put the inputs in the same column
    col = 1
    row = Int(maxArrayY / maxinputs)
    For xx = 0 To maxinputs
        'define input locations
        inputs(xx).x = col
        inputs(xx).y = row * xx
        'activate the inputs
        If inputs(xx).active = False Then
            'Call runcommand((xx))
        End If
        Call Form1.setToolTipText((xx), (inputs(xx).x), (inputs(xx).y))
    Next
End Sub
Public Sub define2DOutputLocations()
    Dim row, col, xx, yy
    'put the inputs in the same column
    col = maxArrayX - 1
    row = Int(maxArrayY / maxoutputs)
    For xx = 0 To maxoutputs
        'define input locations
        outputs(xx).x = col
        outputs(xx).y = row * xx
        'activate the inputs
        If outputs(xx).active = False Then
            Call Form1.runcommand((xx))
        End If
        Call Form1.setToolTipText((xx), (outputs(xx).x), (outputs(xx).y))
    Next
End Sub

Public Sub define1DInputLocations()
    Dim row, col, xx, yy
    'define input locations
    'use only the first input
    inputs(0).x = Int(maxArrayX / 2)
    inputs(0).y = 0
    'deactivate other inputs
    'put the inputs in the same column
    For xx = 0 To maxinputs
        'define input locations
        inputs(xx).x = col
        inputs(xx).y = row * xx
        'activate the inputs
        If xx > 0 And inputs(xx).active = True Then
            inputs(xx).active = True
            Call Form1.runcommand((xx))
        End If
        Call Form1.setToolTipText((xx), (inputs(xx).x), (inputs(xx).y))
    Next
End Sub
Public Sub define1DOutputLocations()
    Dim row, col, xx, yy
    'define output locations
    'use only the first two outputs
    outputs(0).x = Int(maxArrayX / 2)
    outputs(0).y = 0
    oututs(1).x = Int(maxArrayX / 2)
    outputs(1).y = 0
    'deactivate other outputs
    'put the outputs in the same column
    For xx = 0 To maxinputs
        'define input locations
        outputs(xx).x = col
        outputs(xx).y = row * xx
        'deactivate other outputs
        If xx > 1 And outputs(xx).active = True Then
            outputs(xx).active = False
            Call Form1.runcommand((3 + xx))
        End If
        Call Form1.setToolTipText((3 + xx), (outputs(xx).x), (outputs(xx).y))
    Next
End Sub

Public Function isinput(xx As Integer, yy As Integer) As Integer
    isinput = -1
    'return the number of the corresponding input
    Dim i
    For i = 0 To maxinputs
        If xx = inputs(i).x And yy = inputs(i).y Then
            isinput = i
            Exit Function
        End If
    Next
End Function
Public Function isoutput(xx As Integer, yy As Integer) As Integer
    isoutput = -1
    'return the number of the corresponding output
    Dim i
    For i = 0 To maxoutputs
        If xx = outputs(i).x And yy = outputs(i).y Then
            isoutput = i
            Exit Function
        End If
    Next
End Function

Public Sub drawnode(xx2 As Integer, yy2 As Integer)
    Dim ch, rh
    Dim fh, fw
    Dim sw, sh
    Dim fromX, fromY, toX, toY, fromx2, fromy2, tox2, toy2
    Dim color
    fromX = 0
    fromY = 0
    toX = 0
    toY = 0
    fromx2 = 0
    fromy2 = 0
    tox2 = 0
    toy2 = 0
    If usedimension = 1 Then
        'If maxCharge > maxThreshold Then
        '    fw = Form1.ScaleWidth / maxArrayX
        '    fh = (Form1.ScaleHeight - topOfForm) / maxCharge
        'Else
        '    fw = Form1.ScaleWidth / maxArrayX
        '    fh = (Form1.ScaleHeight - topOfForm) / maxThreshold
        'End If
    Else
        fw = Form1.ScaleWidth / maxArrayX
        fh = (Form1.ScaleHeight - topOfForm) / maxArrayY
    End If
    
    sw = Form1.ScaleWidth
    sh = (Form1.ScaleHeight - topOfForm)
    If usedimension Then
        'Form1.Cls
        'ch = neuralNet(xx2, yy2).Charge * fh
        'rh = neuralNet(xx2, yy2).Threshold * fh
                
        'fromx = xx2 * fw
        'fromy = sh - ch + topOfForm - 10
        'tox = xx2 * fw + fw - (fw / 2)
        'toy = sh + topOfForm - 10
                
        'fromx2 = xx2 * fw + fw - (fw / 2)
        'fromy2 = sh - rh + topOfForm - 10
        'tox2 = xx2 * fw + fw
        'toy2 = sh + topOfForm - 10
 
        'Form1.Line (fromx, fromy)-(tox, toy), rgb2(neuralNet(xx2, yy2).Threshold), BF
        'Form1.Line (fromx2, fromy2)-(tox2, toy2), rgb2(neuralNet(xx2, yy2).Charge), BF
        
    Else
        If drawingmode = 0 Then
            color = rgb2(((neuralNet(xx2, yy2).tempCharge / maxThreshold) * 255))
        ElseIf drawingmode = 1 Then
            color = rgb2(((neuralNet(xx2, yy2).Threshold / maxThreshold) * 255))
        ElseIf drawingmode = 1 Then
            color = rgb2(((neuralNet(xx2, yy2).lastActivated / lastActivatedCeiling) * 255))
        End If
        Form1.Line (xx2 * fw, yy2 * fh + topOfForm)-(xx2 * fw + fw, yy2 * fh + fh + topOfForm), color, BF
    End If

End Sub



Public Sub createOutputPunishTemplate(i As Integer)
    Dim maxdist, curdist, xx, yy
    'find the greatest distance from input1 and some outter edge of the array
    maxdist = 0
    For xx = 0 To maxArrayX
        For yy = 0 To maxArrayY
            curdist = dist((outputs(i).x), (outputs(i).y), (xx), (yy))
            If curdist > maxdist Then
                maxdist = curdist
            End If
        Next
    Next
    'create a punishment template for later
    For xx = 0 To maxArrayX
        For yy = 0 To maxArrayY
            'get the distance from the current node to the index node
            curdist = dist((xx), (yy), (outputs(i).x), (outputs(i).y))
            outputs(i).punishTemplate(xx, yy) = ((maxdist - curdist) / maxdist) ^ curvature
        Next
    Next
End Sub



Public Function getConnectionIndex(xx As Integer, yy As Integer, isinput As Boolean, branch As Integer) As Integer
    If isinput Then
        getConnectionIndex = neuralNet(xx, yy).inputConnections(branch)
    Else
        getConnectionIndex = neuralNet(xx, yy).outputConnections(branch)
    End If
End Function

Public Function sumOfInputs(xx As Integer, yy As Integer) As Integer
    Dim sum, i, cc
    sum = 0
    'calculate the sum of the values
    For i = 0 To neuralNet(xx, yy).numberOfInputs
        'get the location of the connection in the connections array
        cc = getConnectionIndex((xx), (yy), (True), (i))
        If cc <> -1 Then
            sum = sum + connections(cc).result * connections(cc).multiplier
        End If
    Next
    sumOfInputs = sum
End Function
