VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "use input"
   ClientHeight    =   3195
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   9480
   LinkTopic       =   "Form1"
   ScaleHeight     =   213
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   632
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin VB.CommandButton cmdSolutions 
      BackColor       =   &H0000FF00&
      Caption         =   "1"
      Height          =   285
      Index           =   0
      Left            =   900
      Style           =   1  'Graphical
      TabIndex        =   13
      Top             =   540
      Width           =   315
   End
   Begin VB.CommandButton cmdOutputs 
      BackColor       =   &H0000FF00&
      Caption         =   "1"
      Height          =   285
      Index           =   0
      Left            =   900
      Style           =   1  'Graphical
      TabIndex        =   11
      Top             =   270
      Width           =   315
   End
   Begin VB.CommandButton cmdInputs 
      BackColor       =   &H0000FF00&
      Caption         =   "1"
      Height          =   285
      Index           =   0
      Left            =   900
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   0
      Width           =   315
   End
   Begin VB.CommandButton Command1 
      Caption         =   "use grey rgb"
      Height          =   285
      Index           =   12
      Left            =   5730
      TabIndex        =   6
      ToolTipText     =   "use mixed colors/use grayscale"
      Top             =   0
      Width           =   1425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "draw charge"
      Height          =   285
      Index           =   13
      Left            =   7140
      TabIndex        =   5
      ToolTipText     =   "draw charge/draw resistance/draw lastactivated"
      Top             =   0
      Width           =   1425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "use 2d model"
      Height          =   285
      Index           =   15
      Left            =   5730
      TabIndex        =   4
      ToolTipText     =   "use 2d model/ use 1d model"
      Top             =   270
      Width           =   1425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "use rand. prop."
      Height          =   285
      Index           =   16
      Left            =   7140
      TabIndex        =   3
      ToolTipText     =   "use seqential propagation/use semi-random propagation/use random propagation"
      Top             =   270
      Width           =   1425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "run"
      Height          =   285
      Index           =   18
      Left            =   8550
      TabIndex        =   2
      ToolTipText     =   "run/pause"
      Top             =   0
      Width           =   675
   End
   Begin VB.CommandButton Command1 
      Caption         =   "use punish (F)"
      Height          =   285
      Index           =   14
      Left            =   5730
      TabIndex        =   1
      ToolTipText     =   "continuously punish nodes (T/F)"
      Top             =   540
      Width           =   1425
   End
   Begin VB.CommandButton Command1 
      Caption         =   "use boost (F)"
      Height          =   285
      Index           =   17
      Left            =   7140
      TabIndex        =   0
      ToolTipText     =   "continously boost the signals of the most activated nodes (T/F)"
      Top             =   540
      Width           =   1425
   End
   Begin VB.Label Label4 
      Caption         =   "use solution"
      Height          =   285
      Left            =   0
      TabIndex        =   12
      Top             =   540
      Width           =   885
   End
   Begin VB.Label Label3 
      Caption         =   "use output"
      Height          =   255
      Left            =   0
      TabIndex        =   9
      Top             =   270
      Width           =   885
   End
   Begin VB.Label Label2 
      Caption         =   "use input"
      Height          =   255
      Left            =   0
      TabIndex        =   8
      Top             =   0
      Width           =   885
   End
   Begin VB.Label Label1 
      Height          =   255
      Left            =   0
      TabIndex        =   7
      Top             =   840
      Width           =   9435
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdInputs_Click(index As Integer)
    inputs(index).active = Not inputs(index).active
    If cmdInputs(index).BackColor = &HFF00& Then
        cmdInputs(index).BackColor = &HFF&   'red
    Else
        cmdInputs(index).BackColor = &HFF00& 'green
    End If
End Sub
Private Sub cmdOutputs_Click(index As Integer)
    outputs(index).active = Not outputs(index).active
    If cmdOutputs(index).BackColor = &HFF00& Then
        cmdOutputs(index).BackColor = &HFF&   'red
    Else
        cmdOutputs(index).BackColor = &HFF00& 'green
    End If
End Sub
Private Sub cmdSolutions_Click(index As Integer)
    outputs(index).isSolution = Not outputs(index).isSolution
    If cmdSolutions(index).BackColor = &HFF00& Then
        cmdSolutions(index).BackColor = &HFF&   'red
    Else
        cmdSolutions(index).BackColor = &HFF00& 'green
    End If
End Sub


Private Sub Command1_Click(index As Integer)
    Call runcommand((index))
End Sub
Private Sub Form_Load()
    Dim xx
    For xx = 0 To maxinputs
        inputs(xx).active = True
    Next
    For xx = 0 To maxoutputs
        outputs(xx).active = True
        outputs(xx).isSolution = True
    Next
    
    rgbmode = 0
    drawingmode = 0
    usepunish = False
    usedimension = 0
    usepropagationmethod = 0
    usesignalboost = False
    executionmethod = 0
    Call createbuttons
    Call NeuralNetManip.define2DInputLocations
    Call NeuralNetManip.define2DOutputLocations
    Call creategrayscalergb2
    Form1.Show
    Call InitializeNeuralNet
    Call propagateNeuralNet
End Sub

Public Sub runcommand(index As Integer)
    Select Case index
    Case 12:
        Form1.Cls
        If rgbmode + 1 = 1 Then
            rgbmode = 1
            Command1(index).Caption = "use mixed scale"
            Call createmixed2scale
        Else
            rgbmode = 0
            Command1(index).Caption = "use grey rgb"
            Call creategrayscalergb2
        End If
    Case 13:
        Form1.Cls
        If drawingmode + 1 = 1 Then
            drawingmode = 1
            Command1(index).Caption = "draw R"
        ElseIf drawingmode + 1 = 2 Then
            drawingmode = 2
            Command1(index).Caption = "draw L.A."
        Else
            drawingmode = 0
            Command1(index).Caption = "draw charge"
        End If
    Case 14:
        usepunish = Not usepunish
        Command1(index).Caption = "use punish (" + tf((usepunish)) + ")"
    Case 15:
        Form1.Cls
        If usedimension + 1 = 1 Then
            Call define1DInputLocations
            Call define1DOutputLocations
            usedimension = 1
            Call InitializeNeuralNet
            Command1(index).Caption = "use 1d model"
        Else
            Call define2DInputLocations
            Call define2DOutputLocations
            usedimension = 0
            Call InitializeNeuralNet
            Command1(index).Caption = "use 2d model"
        End If
    Case 16:
        If usepropagationmethod + 1 = 2 Then
            usepropagationmethod = 2
            Command1(index).Caption = "use seq. prop."
        ElseIf usepropagationmethod + 1 = 1 Then
            usepropagationmethod = 1
            Command1(index).Caption = "use s.rand prop."
        Else
            usepropagationmethod = 0
            Command1(index).Caption = "use rand. prop."
        End If
    Case 17:
        usesignalboost = Not usesignalboost
        Command1(index).Caption = "use boost (" + tf((usesignalboost)) + ")"
    Case 18:
        If executionmethod + 1 = 1 Then
            executionmethod = 1
            Command1(index).Caption = "pause"
            preend = True
        Else
            executionmethod = 0
            Command1(index).Caption = "run"
            preend = False
            Call propagateNeuralNet
        End If
    End Select
End Sub
Public Function tf(value As Boolean) As String
    'just return "T" or "F"
    If value Then
        tf = "T"
    Else
        tf = "F"
    End If
    
End Function

Public Sub createmixed2scale()
    'create a rgb scale using red, green and blue
    'with a smooth gradient from one to the other
    Dim c, cm, count, maxcount, countstep
    cm = 0
    count = -pi
    maxcount = pi
    countstep = 2 * pi / (256 / 3)
    For c = 0 To 255 / 3
        cm = (Abs(Cos(count)) * 255)
        rgb2(c) = RGB(255 - cm, 0, 0)
        count = count + countstep
    Next
    count = -pi
    For c = 255 / 3 To 255 / 3 * 2
        cm = (Abs(Cos(count)) * 255)
        rgb2(c) = RGB(0, 255 - cm, 0)
        count = count + countstep
    Next
    count = -pi
    For c = 255 / 3 * 2 To 255
        cm = (Abs(Cos(count)) * 255)
        rgb2(c) = RGB(0, 0, 255 - cm)
        count = count + countstep
    Next
End Sub
Public Sub creategrayscalergb2()
    'create a simple grey scale
    Dim c, cm, count, maxcount, countstep
    For c = 0 To 255
        rgb2(c) = RGB(c, c, c)
    Next
End Sub
Public Sub updateLabel(x As Integer, y As Integer)
    'update label1 when ever the mouse moves or there is a propagation
    
    'including:
    'the x,y coordinate of the relative neuron
    'the charge of the relative neuron
    'the resistence of the relative neuron
    'the output connections of the neuron -> cons:(x,y)(x2,y2)...

    'NOTE:
    'since there are maxArrayX and maxArrayY neurons, the screen
    'it is divided into maxArrayX*maxArrayY blocks representing
    'the neurons.
    
    
    Dim fw, fh
    Dim xx, yy, xx2
    Dim strg, IO, inputvalues
    strg = ""
    IO = ""
    fw = Form1.ScaleWidth / maxArrayX
    fh = (Form1.ScaleHeight - topOfForm) / maxArrayY
    
    Form1.Label1.Visible = True
    If fw > 0 Then
        xx = Int(x / fw)
        yy = Int((y - topOfForm) / fh)
        If xx >= 0 And xx <= maxArrayX And yy >= 0 And yy <= maxArrayY Then
            If isinput((xx), (yy)) <> -1 Then
                IO = "INPUT " + Str(isinput((xx), (yy))) + ": "
            End If
            If isoutput((xx), (yy)) <> -1 Then
                IO = "OUTPUT " + Str(isoutput((xx), (yy))) + ": "
            End If
            strg = strg + " output cons: "
            For xx2 = 0 To neuralNet(xx, yy).numberOfOutputs - 1
                strg = strg + "(" + Trim(Str(connections(getConnectionIndex((xx), (yy), (False), (xx2))).toX)) + "," + Trim(Str(connections(getConnectionIndex((xx), (yy), (False), (xx2))).toY)) + ")"
            Next
            inputvalues = " input values:("
            For xx2 = 0 To neuralNet(xx, yy).numberOfInputs - 1
                inputvalues = inputvalues + Trim(Str(connections(getConnectionIndex((xx), (yy), (True), (xx2))).result)) + "+"
            Next
            inputvalues = Mid(inputvalues, 1, Len(inputvalues) - 1) + ")"
            Form1.Label1.Caption = IO + "(" + Str(xx) + "," + Str(yy) + ")  r:(" + Str(Int(neuralNet(xx, yy).Threshold)) + ") la(" + Str(Int(neuralNet(xx, yy).lastActivated)) + ")" + " " + strg + inputvalues
        End If
    End If
End Sub

Private Sub Form_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Form1.Cls
End Sub

Private Sub Form_Terminate()
    End
End Sub
Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)
    lastmousex = x
    lastmousey = y
    Call Form1.updateLabel((x), (y))
End Sub

Private Sub Form_Unload(Cancel As Integer)
    End
End Sub

Private Sub Timer1_Timer()
    If preend = False Then
        Form1.Cls
    End If
End Sub
Public Sub setToolTipText(index As Integer, xx As Integer, yy As Integer)
End Sub



Public Sub createbuttons()
    Dim xx
    For xx = 1 To maxinputs
        Load cmdInputs(xx)
        cmdInputs(xx).Left = cmdInputs(xx - 1).Left + cmdInputs(xx - 1).Width
        cmdInputs(xx).Visible = True
        cmdInputs(xx).Enabled = True
        cmdInputs(xx).Caption = Str(xx + 1)
    Next
    For xx = 1 To maxoutputs
        Load cmdOutputs(xx)
        cmdOutputs(xx).Left = cmdOutputs(xx - 1).Left + cmdOutputs(xx - 1).Width
        cmdOutputs(xx).Visible = True
        cmdOutputs(xx).Enabled = True
        cmdOutputs(xx).Caption = Str(xx + 1)
    Next
    For xx = 1 To maxoutputs
        Load cmdSolutions(xx)
        cmdSolutions(xx).Left = cmdSolutions(xx - 1).Left + cmdSolutions(xx - 1).Width
        cmdSolutions(xx).Visible = True
        cmdSolutions(xx).Enabled = True
        cmdSolutions(xx).Caption = Str(xx + 1)
    Next
End Sub

