Attribute VB_Name = "StartUp"
Option Explicit

Sub Main()

On Local Error Resume Next

'Local INI...
If Dir$(App.Path & "\Local.Ini") <> "" Then
    QuickRef.UserINIFileName = App.Path & "\Local.Ini"
End If

'Get Database Connection Information...
If Trim(ReadINI("Database", "DatabaseLocation", QuickRef.UserINIFileName)) <> "" Then
    QuickRef.DBFileName = ReadINI("Database", "DatabaseLocation", QuickRef.UserINIFileName) & "HRN.MDB"
Else
    QuickRef.DBFileName = App.Path & "\HRN.MDB"
End If
If Dir$(QuickRef.DBFileName) = "" Then
    'MsgBox "Unable to establish a connection to the Database or to the Server. Contact your system administrator for help.", vbCritical, "No Connection..."
    'End
End If

'Load the last skin scheme...
Skins.UseSkins = ReadINI("Skins", "UseSkins", QuickRef.UserINIFileName)
Skins.SkinScheme = ReadINI("Skins", "SkinScheme", QuickRef.UserINIFileName)
If Trim$(Skins.SkinScheme) = "" Or Dir$(App.Path & "\Skins\" & Skins.SkinScheme, vbDirectory) = "" Then
    MsgBox "Unable to use the Skin " & Chr$(34) & Skins.SkinScheme & Chr$(34) & ". The skin folder doesn't exist. You can go to the " & Chr$(34) & "Colors Screen" & Chr$(34) & " and specify another " & Chr$(34) & "Color Scheme" & Chr$(34) & " and " & Chr$(34) & "Skin Scheme" & Chr$(34) & " from there.", vbInformation, "Skin Folder..."
    Skins.SkinScheme = ""
    Skins.UseSkins = False
End If

'Load Colors...
Call LoadColors

'Main Menu...
mdiMainMenu.Show

End Sub
