VERSION 5.00
Begin VB.Form frmLogin 
   AutoRedraw      =   -1  'True
   BorderStyle     =   0  'None
   Caption         =   "Login"
   ClientHeight    =   5580
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   10410
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5580
   ScaleWidth      =   10410
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Tag             =   "FormSmall"
   Begin VB.TextBox txtPassWord 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   1200
      PasswordChar    =   "*"
      TabIndex        =   1
      ToolTipText     =   "Enter your Password here"
      Top             =   1020
      Width           =   2805
   End
   Begin VB.TextBox txtLoginName 
      Height          =   285
      Left            =   1200
      TabIndex        =   0
      ToolTipText     =   "Enter your User ID here"
      Top             =   570
      Width           =   2805
   End
   Begin VB.Image imgRememberMyLoginName 
      Height          =   225
      Left            =   1200
      ToolTipText     =   "Click here to have the Login window remember your User ID"
      Top             =   1500
      Width           =   225
   End
   Begin VB.Image imgClose 
      Height          =   195
      Left            =   4290
      Tag             =   "Close"
      ToolTipText     =   "Close"
      Top             =   90
      Width           =   270
   End
   Begin VB.Label lblCancel 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Exit"
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   3630
      TabIndex        =   6
      Tag             =   "ButtonLabel"
      ToolTipText     =   "Click here to close this window or cancel logging in"
      Top             =   2250
      Width           =   285
   End
   Begin VB.Label lblLogin 
      Alignment       =   2  'Center
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Login"
      ForeColor       =   &H00FFFFFF&
      Height          =   195
      Left            =   2160
      TabIndex        =   5
      Tag             =   "ButtonLabel"
      ToolTipText     =   "Click here to Login into the system"
      Top             =   2250
      Width           =   405
   End
   Begin VB.Label lblRememberMyLoginName 
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Remember my login name"
      Height          =   195
      Left            =   1470
      TabIndex        =   4
      Tag             =   "Label"
      ToolTipText     =   "Click here to have the Login window remember your User ID"
      Top             =   1500
      Width           =   1875
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "Password"
      Height          =   195
      Index           =   1
      Left            =   390
      TabIndex        =   3
      Tag             =   "Label"
      ToolTipText     =   "Enter your Password here"
      Top             =   1050
      Width           =   705
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      AutoSize        =   -1  'True
      BackStyle       =   0  'Transparent
      Caption         =   "User ID"
      Height          =   195
      Index           =   0
      Left            =   555
      TabIndex        =   2
      Tag             =   "Label"
      ToolTipText     =   "Enter your User ID here"
      Top             =   600
      Width           =   540
   End
   Begin VB.Image imgCancel 
      Height          =   345
      Left            =   3060
      Stretch         =   -1  'True
      Tag             =   "Button"
      ToolTipText     =   "Click here to close this window or cancel logging in"
      Top             =   2190
      Width           =   1365
   End
   Begin VB.Image imgLogin 
      Height          =   345
      Left            =   1650
      Stretch         =   -1  'True
      Tag             =   "Button"
      ToolTipText     =   "Click here to Login into the system"
      Top             =   2190
      Width           =   1365
   End
End
Attribute VB_Name = "frmLogin"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private m_Tag2 As String
Function LogUserIn() As Boolean

On Local Error GoTo LogUserInError

'Query the database and see if user exists...
If OpenDB(DB, QuickRef.DBPassWord) = False Then Exit Function
Set RS = DB.OpenRecordset("SELECT * FROM tblLogin WHERE LoginName = '" & txtLoginName & "' AND PassWord = '" & txtPassWord & "'", dbOpenSnapshot)

'No info found for contact ???...
If RS.RecordCount = 0 Then
    MsgBox "Your login name or password is incorrect. If you can not log in, contact your system administrator and have them set up an account for you on the system.", vbInformation, "Login..."
    RS.Close
    DB.Close
    txtPassWord.SelStart = 0
    txtPassWord.SelLength = Len(txtPassWord)
    Exit Function
End If

'Login Date and Time...
Login.LoginDateAndTime = Format(Now, "H:MM AMPM")

'Administrator...
Login.Administrator = RS!Administrator

'Main Menu Panel...
'mdiMainMenu.lblLoginTime.Caption = Format$(Now, "H:MM AMPM")
'mdiMainMenu.lblUser.Caption = Login.FullName

'Close the database...
RS.Close
DB.Close

LogUserIn = True
Exit Function



LogUserInError:
    DB.Close
    Call WriteToErrorLog(Me.Name, "LogUserIn", Err.Description, Err.Number, True)
    Exit Function

End Function

Public Property Let Tag2(sValue As String)

m_Tag2 = sValue

End Property
Public Property Get Tag2() As String

Tag2 = m_Tag2

End Property

Private Sub Form_Activate()

'Set focus to the password textbox if there is already a login name entered...
If Trim$(txtLoginName) <> "" Then
    txtPassWord.SetFocus
End If

End Sub
Private Sub Form_Load()

On Local Error Resume Next

Call LoadINISettings
Call LoadSkins(Me, True)
Call SetColors(Me)

'Form Coordinates...
Me.Width = 4590
Me.Height = 2760

End Sub
Sub LoadINISettings()

'Set the custom Tag2 property (for skins)...
Me.Tag2 = "FormSmall"

'Form Coordinates...
Me.Left = Val(ReadINI(Me.Name, "Left", QuickRef.UserINIFileName))
Me.Top = Val(ReadINI(Me.Name, "Top", QuickRef.UserINIFileName))

'Remember my login name...
If ReadINI(Me.Name, "RememberMyLoginName", QuickRef.UserINIFileName) = True Then
    imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture
Else
    imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckOFFID).Picture
End If
If imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture Then
    txtLoginName = ReadINI(Me.Name, "MyLoginName", QuickRef.UserINIFileName)
End If

End Sub
Private Sub Form_MouseMove(Button As Integer, Shift As Integer, x As Single, y As Single)

'Move the form if the user is pressing and holding the mouse button...
If Button = vbLeftButton Then
    Call DragForm(Me)
End If

End Sub
Private Sub Form_Unload(Cancel As Integer)

'Save this form's settings...
Call SaveINISettings

End Sub
Sub SaveINISettings()

On Local Error Resume Next

'Form coordinates...
Call WriteINI(Me.Name, "Left", Me.Left, QuickRef.UserINIFileName)
Call WriteINI(Me.Name, "Top", Me.Top, QuickRef.UserINIFileName)

'Remember my login name...
Call WriteINI(Me.Name, "RememberMyLoginName", (imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture), QuickRef.UserINIFileName)
If imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture Then
    Call WriteINI(Me.Name, "MyLoginName", txtLoginName, QuickRef.UserINIFileName)
Else
    Call WriteINI(Me.Name, "MyLoginName", "", QuickRef.UserINIFileName)
End If

End Sub

Private Sub imgCancel_Click()

lblCancel_Click

End Sub

Private Sub imgClose_Click()

lblCancel_Click

End Sub
Private Sub imgClose_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgClose.Picture = mdiMainMenu.imgSkins(CloseDNID).Picture
End If

End Sub
Private Sub imgClose_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgClose.Picture = mdiMainMenu.imgSkins(CloseUPID).Picture
End If

End Sub
Private Sub imgLogin_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgLogin.Picture = mdiMainMenu.imgSkins(ButtonDNID).Picture
    lblLogin.ForeColor = QBColor(Colors.ButtonDownForeColor)
End If

End Sub
Private Sub imgCancel_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgCancel.Picture = mdiMainMenu.imgSkins(ButtonDNID).Picture
    lblCancel.ForeColor = QBColor(Colors.ButtonDownForeColor)
End If

End Sub
Private Sub imgCancel_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)

imgCancel.Picture = mdiMainMenu.imgSkins(ButtonUPID).Picture
lblCancel.ForeColor = Colors.ButtonForeColor

End Sub
Private Sub imgLogin_Click()

lblLogin_Click

End Sub
Private Sub imgLogin_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)

imgLogin.Picture = mdiMainMenu.imgSkins(ButtonUPID).Picture
lblLogin.ForeColor = Colors.ButtonForeColor

End Sub
Private Sub imgRememberMyLoginName_Click()

lblRememberMyLoginName_Click

End Sub

Private Sub lblCancel_Click()

'End or go back to the program...
If Login.ReLoggingIn Then
    Unload Me
Else
    Call SaveINISettings
    End
End If

End Sub
Private Sub lblCancel_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgCancel.Picture = mdiMainMenu.imgSkins(ButtonDNID).Picture
    lblCancel.ForeColor = QBColor(Colors.ButtonDownForeColor)
End If

End Sub
Private Sub lblCancel_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)

imgCancel.Picture = mdiMainMenu.imgSkins(ButtonUPID).Picture
lblCancel.ForeColor = Colors.ButtonForeColor

End Sub

Private Sub lblLogin_Click()

Unload Me
Exit Sub

'Log user in...
If LogUserIn() = True Then
    Unload Me
    Exit Sub
Else
    Exit Sub
End If

End Sub
Private Sub lblLogin_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)

If Button = vbLeftButton Then
    imgLogin.Picture = mdiMainMenu.imgSkins(ButtonDNID).Picture
    lblLogin.ForeColor = QBColor(Colors.ButtonDownForeColor)
End If

End Sub
Private Sub lblLogin_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)

imgLogin.Picture = mdiMainMenu.imgSkins(ButtonUPID).Picture
lblLogin.ForeColor = Colors.ButtonForeColor

End Sub
Private Sub lblRememberMyLoginName_Click()

'Swap values...
If imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture Then
    imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckOFFID).Picture
Else
    imgRememberMyLoginName.Picture = mdiMainMenu.imgSkins(CheckONID).Picture
End If

End Sub
Private Sub txtLoginName_GotFocus()

txtLoginName.SelStart = 0
txtLoginName.SelLength = Len(txtLoginName)

End Sub
Private Sub txtLoginName_KeyDown(KeyCode As Integer, Shift As Integer)

On Local Error Resume Next

'Down key...
If KeyCode = vbKeyDown Then
    SendKeys "{TAB}", False
End If

End Sub
Private Sub txtLoginName_KeyPress(KeyAscii As Integer)

On Local Error Resume Next

'Enter key...
If KeyAscii = vbKeyReturn Then
    KeyAscii = 0
    If txtPassWord = "" Then
        SendKeys "{TAB}", False
    Else
        Call lblLogin_Click
    End If
End If

End Sub
Private Sub txtPassWord_GotFocus()

txtPassWord.SelStart = 0
txtPassWord.SelLength = Len(txtPassWord)

End Sub
Private Sub txtPassWord_KeyDown(KeyCode As Integer, Shift As Integer)

On Local Error Resume Next

'Up key...
If KeyCode = vbKeyUp Then
    SendKeys "+{TAB}", False
End If

End Sub
Private Sub txtPassWord_KeyPress(KeyAscii As Integer)

On Local Error Resume Next

'Enter key...
If KeyAscii = vbKeyReturn Then
    KeyAscii = 0
    If txtLoginName <> "" Then
        Call lblLogin_Click
    Else
        SendKeys "+{TAB}", False
    End If
End If

End Sub
