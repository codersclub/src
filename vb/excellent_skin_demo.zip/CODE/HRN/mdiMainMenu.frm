VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.MDIForm mdiMainMenu 
   AutoShowChildren=   0   'False
   BackColor       =   &H8000000C&
   Caption         =   "HRN"
   ClientHeight    =   8265
   ClientLeft      =   165
   ClientTop       =   765
   ClientWidth     =   14385
   Icon            =   "mdiMainMenu.frx":0000
   LockControls    =   -1  'True
   Picture         =   "mdiMainMenu.frx":08CA
   ScrollBars      =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox picControls 
      Align           =   1  'Align Top
      BackColor       =   &H00C0E0FF&
      Height          =   825
      Left            =   0
      ScaleHeight     =   765
      ScaleWidth      =   14325
      TabIndex        =   2
      Top             =   630
      Visible         =   0   'False
      Width           =   14385
      Begin VB.Timer Timer1 
         Interval        =   1000
         Left            =   4470
         Top             =   180
      End
      Begin MSComctlLib.ImageList ImageList 
         Left            =   3300
         Top             =   105
         _ExtentX        =   1005
         _ExtentY        =   1005
         BackColor       =   -2147483643
         ImageWidth      =   32
         ImageHeight     =   32
         MaskColor       =   12632256
         _Version        =   393216
         BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
            NumListImages   =   1
            BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
               Picture         =   "mdiMainMenu.frx":16020C
               Key             =   "Exit"
            EndProperty
         EndProperty
      End
      Begin MSComDlg.CommonDialog Dialog 
         Left            =   3930
         Top             =   150
         _ExtentX        =   847
         _ExtentY        =   847
         _Version        =   393216
         CancelError     =   -1  'True
      End
      Begin VB.Image imgSkins 
         Height          =   180
         Index           =   11
         Left            =   2970
         Picture         =   "mdiMainMenu.frx":160B04
         Top             =   465
         Width           =   240
      End
      Begin VB.Image imgSkins 
         Height          =   180
         Index           =   10
         Left            =   2970
         Picture         =   "mdiMainMenu.frx":160D86
         Top             =   90
         Width           =   240
      End
      Begin VB.Image imgSkins 
         Height          =   225
         Index           =   9
         Left            =   2625
         Picture         =   "mdiMainMenu.frx":161008
         Top             =   450
         Width           =   225
      End
      Begin VB.Image imgSkins 
         Height          =   225
         Index           =   8
         Left            =   2625
         Picture         =   "mdiMainMenu.frx":16131A
         Top             =   75
         Width           =   225
      End
      Begin VB.Image imgSkins 
         Height          =   180
         Index           =   7
         Left            =   2235
         Picture         =   "mdiMainMenu.frx":16162C
         Top             =   480
         Width           =   270
      End
      Begin VB.Image imgSkins 
         Height          =   180
         Index           =   6
         Left            =   2250
         Picture         =   "mdiMainMenu.frx":16190E
         Top             =   105
         Width           =   270
      End
      Begin VB.Image imgSkins 
         Height          =   195
         Index           =   5
         Left            =   1860
         Picture         =   "mdiMainMenu.frx":161BF0
         Top             =   465
         Width           =   270
      End
      Begin VB.Image imgSkins 
         Height          =   195
         Index           =   4
         Left            =   1860
         Picture         =   "mdiMainMenu.frx":161F0A
         Top             =   90
         Width           =   270
      End
      Begin VB.Image imgSkins 
         Height          =   225
         Index           =   3
         Left            =   1515
         Picture         =   "mdiMainMenu.frx":162224
         Top             =   450
         Width           =   225
      End
      Begin VB.Image imgSkins 
         Height          =   225
         Index           =   2
         Left            =   1530
         Picture         =   "mdiMainMenu.frx":162536
         Top             =   75
         Width           =   225
      End
      Begin VB.Image imgSkins 
         Height          =   345
         Index           =   1
         Left            =   30
         Picture         =   "mdiMainMenu.frx":162848
         Top             =   390
         Width           =   1425
      End
      Begin VB.Image imgSkins 
         Height          =   345
         Index           =   0
         Left            =   30
         Picture         =   "mdiMainMenu.frx":16426A
         Top             =   15
         Width           =   1425
      End
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   630
      Left            =   0
      TabIndex        =   1
      Top             =   0
      Width           =   14385
      _ExtentX        =   25374
      _ExtentY        =   1111
      ButtonWidth     =   1402
      ButtonHeight    =   953
      Appearance      =   1
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   8
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Employee"
            Key             =   "Employee"
            Object.ToolTipText     =   "Employee Screen..."
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Clients"
            Key             =   "Clients"
            Object.ToolTipText     =   "Clients Screen..."
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Sign-In"
            Key             =   "SignIn"
            Object.ToolTipText     =   "Sign-In Screen..."
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Payroll"
            Key             =   "Payroll"
            Object.ToolTipText     =   "Payroll Screen..."
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Billing"
            Key             =   "Billing"
            Object.ToolTipText     =   "Billing Screen..."
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Colors..."
            Key             =   "Colors"
            Object.ToolTipText     =   "Set Program Colors..."
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Exit"
            Key             =   "Exit"
            Object.ToolTipText     =   "Exit The Program"
         EndProperty
      EndProperty
      BorderStyle     =   1
   End
   Begin MSComctlLib.StatusBar StatusBar 
      Align           =   2  'Align Bottom
      Height          =   285
      Left            =   0
      TabIndex        =   0
      Top             =   7980
      Width           =   14385
      _ExtentX        =   25374
      _ExtentY        =   503
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   5
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   19156
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   2
            Alignment       =   1
            Object.Width           =   988
            MinWidth        =   988
            TextSave        =   "NUM"
         EndProperty
         BeginProperty Panel3 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   1
            Alignment       =   1
            Enabled         =   0   'False
            Object.Width           =   988
            MinWidth        =   988
            TextSave        =   "CAPS"
         EndProperty
         BeginProperty Panel4 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   5
            Alignment       =   1
            Object.Width           =   1764
            MinWidth        =   1764
            TextSave        =   "3:09 PM"
         EndProperty
         BeginProperty Panel5 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            Style           =   6
            Alignment       =   1
            Object.Width           =   1764
            MinWidth        =   1764
            TextSave        =   "10/5/00"
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuReLogin 
         Caption         =   "&Re-Login"
      End
      Begin VB.Menu H827653 
         Caption         =   "-"
      End
      Begin VB.Menu mnuPrintSetup 
         Caption         =   "Print Setup..."
      End
      Begin VB.Menu H999827 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "E&xit"
      End
   End
   Begin VB.Menu mnuOptions 
      Caption         =   "&Options"
      Begin VB.Menu mnuAccounts 
         Caption         =   "&Accounts..."
      End
      Begin VB.Menu mnuColors 
         Caption         =   "&Colors..."
      End
   End
   Begin VB.Menu mnuEmployee 
      Caption         =   "&Employee"
      Begin VB.Menu mnuMaintainEmployee 
         Caption         =   "&Maintain Employee..."
      End
      Begin VB.Menu mnuAdjustments 
         Caption         =   "&Adjustments..."
      End
      Begin VB.Menu mnuGarnishments 
         Caption         =   "&Garnishments..."
         Begin VB.Menu mnuCalculate 
            Caption         =   "&Calculate"
            Begin VB.Menu mnuTempPayroll 
               Caption         =   "&Temp Payroll..."
            End
            Begin VB.Menu mnuAssignment 
               Caption         =   "&Assignment..."
            End
            Begin VB.Menu mnuLocalTraveler 
               Caption         =   "&Local Traveler..."
            End
         End
         Begin VB.Menu mnuDefine 
            Caption         =   "&Define..."
         End
      End
      Begin VB.Menu mnuClassification 
         Caption         =   "&Classification..."
      End
      Begin VB.Menu mnuInternalEmployees 
         Caption         =   "&Internal Employees..."
      End
      Begin VB.Menu mnuEMailAddressExport 
         Caption         =   "&E-Mail Address Export..."
      End
      Begin VB.Menu mnuReports 
         Caption         =   "&Reports"
         Begin VB.Menu mnuRoster 
            Caption         =   "Roster..."
         End
         Begin VB.Menu mnuSpecializedRoster 
            Caption         =   "Specialized Roster..."
         End
         Begin VB.Menu mnuOutstandingAdjustments 
            Caption         =   "Outstanding Ad&justments..."
         End
         Begin VB.Menu mnuWorkRequirementsGroup 
            Caption         =   "&Work Requirements Group"
            Begin VB.Menu mnuAllRequirementsReport 
               Caption         =   "&All Requirements Report..."
            End
            Begin VB.Menu H888276 
               Caption         =   "-"
            End
            Begin VB.Menu mnuLicenseExpiration 
               Caption         =   "&License Expiration..."
            End
            Begin VB.Menu mnuLifeSupport 
               Caption         =   "Life &Support..."
            End
            Begin VB.Menu mnuHealthClearanceExpire 
               Caption         =   "Health Clearance &Expire..."
            End
            Begin VB.Menu mnuInserviceAnnual 
               Caption         =   "&Inservice Annual..."
            End
            Begin VB.Menu H8726537 
               Caption         =   "-"
            End
            Begin VB.Menu mnuMissingRequirementsSummary 
               Caption         =   "Missing Requirements Summary..."
            End
         End
         Begin VB.Menu mnuRetentionReport 
            Caption         =   "&Retention Report..."
         End
         Begin VB.Menu mnuEEOC 
            Caption         =   "&EEOC..."
         End
         Begin VB.Menu mnuWorkBonusHistory 
            Caption         =   "Work &Bonus History..."
         End
         Begin VB.Menu mnuReferralBonusHistory 
            Caption         =   "Re&ferral Bonus History..."
         End
         Begin VB.Menu mnuInsurancePremiumHistory 
            Caption         =   "&Insurance Premium History..."
         End
         Begin VB.Menu mnuRosterModificationReport 
            Caption         =   "R&oster Modification Report..."
         End
         Begin VB.Menu mnuNewEmployeeReport 
            Caption         =   "New Employee Report..."
            Enabled         =   0   'False
         End
         Begin VB.Menu mnuBirthdayList 
            Caption         =   "Birthday List..."
            Enabled         =   0   'False
         End
         Begin VB.Menu mnuMailingLabels 
            Caption         =   "&Mailing Labels..."
         End
         Begin VB.Menu mnu30DayNoAssignmentReport 
            Caption         =   "&30-Day No-Assignment Report..."
         End
         Begin VB.Menu mnuInactiveButEligible 
            Caption         =   "Ina&ctive, But Eligible..."
         End
         Begin VB.Menu mnuActiveButNeverWorked 
            Caption         =   "&Active, But Never Worked..."
         End
         Begin VB.Menu mnuNewHireSummary 
            Caption         =   "&New Hire Summary..."
         End
         Begin VB.Menu mnuAssignmentHistory 
            Caption         =   "A&ssignment History..."
         End
         Begin VB.Menu mnuTravelNurseClientList 
            Caption         =   "&Travel Nurse && Client List..."
         End
         Begin VB.Menu mnuCurrentAssignments 
            Caption         =   "C&urrent Assignments..."
         End
         Begin VB.Menu mnuAssignmentWeeklyHours 
            Caption         =   "Assignment Weekly &Hours..."
         End
         Begin VB.Menu mnuTravelPlacementLog 
            Caption         =   "Travel Placement &Log..."
         End
      End
      Begin VB.Menu mnuTravelAssignments 
         Caption         =   "&Travel Assignments..."
      End
   End
   Begin VB.Menu mnuClients 
      Caption         =   "&Clients"
   End
   Begin VB.Menu mnuSignIn 
      Caption         =   "&Sign-In"
   End
   Begin VB.Menu mnuPayroll 
      Caption         =   "&Payroll"
   End
   Begin VB.Menu mnuBilling 
      Caption         =   "&Billing"
   End
   Begin VB.Menu mnuMisc 
      Caption         =   "&Misc"
   End
   Begin VB.Menu mnuWindow 
      Caption         =   "&Window"
      WindowList      =   -1  'True
      Begin VB.Menu mnuArrangeIcons 
         Caption         =   "&Arrange Icons"
      End
      Begin VB.Menu mnuCascade 
         Caption         =   "&Cascade"
      End
      Begin VB.Menu mnuTileHorizontally 
         Caption         =   "Tile &Horizontally"
      End
      Begin VB.Menu mnuTileVertically 
         Caption         =   "Tile &Vertically"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuIndex 
         Caption         =   "&Index..."
      End
      Begin VB.Menu mnuSearchForHelpOn 
         Caption         =   "&Search for help on..."
      End
      Begin VB.Menu h9287653 
         Caption         =   "-"
      End
      Begin VB.Menu mnuAbout 
         Caption         =   "&About..."
      End
   End
End
Attribute VB_Name = "mdiMainMenu"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub imgPanel_Click(Index As Integer)

End Sub

Private Sub MDIForm_Load()

On Local Error Resume Next

Call LoadINISettings
Call LoadSkins(Me, True)
Call SetColors(Me)

'Set visible to true so that the main menu will be visible with the login dialog box in front of it...
Me.Visible = True
DoEvents

'Show the login screen...
Login.ReLoggingIn = False
frmLogin.Show vbModal

Timer1.Enabled = True

End Sub
Sub LoadINISettings()

'Form properties...
If Trim$(ReadINI(Me.Name, "Caption", QuickRef.GlobalINIFileName)) <> "" Then
    Me.Caption = ReadINI(Me.Name, "Caption", QuickRef.GlobalINIFileName)
End If

'Form Coordinates...
Me.WindowState = Val(ReadINI(Me.Name, "WindowState", QuickRef.UserINIFileName))
If Me.WindowState = vbMaximized Then Exit Sub
Me.Left = Val(ReadINI(Me.Name, "Left", QuickRef.UserINIFileName))
Me.Top = Val(ReadINI(Me.Name, "Top", QuickRef.UserINIFileName))
Me.Height = Val(ReadINI(Me.Name, "Height", QuickRef.UserINIFileName))
Me.Width = Val(ReadINI(Me.Name, "Width", QuickRef.UserINIFileName))

End Sub
Private Sub MDIForm_Resize()

On Local Error Resume Next

'MainMenu PictureBox...
'picMainMenu.Height = Me.Height - 1640

'Panels...
'picMainMenuPanel.Top = ((Me.Height / 2 - picMainMenuPanel.Height / 2) - Toolbar1.Height - 200)
'picMainMenuPanel.Left = (Me.Width / 2 - picMainMenuPanel.Width / 2) - 55

End Sub
Private Sub MDIForm_Unload(Cancel As Integer)

'Save this form's settings...
Call SaveINISettings

End Sub
Sub SaveINISettings()

'WindowState...
Call WriteINI(Me.Name, "WindowState", Me.WindowState, QuickRef.UserINIFileName)

'If Window State = vbNormal Then...
If Me.WindowState = vbNormal Then
    Call WriteINI(Me.Name, "Left", Me.Left, QuickRef.UserINIFileName)
    Call WriteINI(Me.Name, "Top", Me.Top, QuickRef.UserINIFileName)
    Call WriteINI(Me.Name, "Height", Me.Height, QuickRef.UserINIFileName)
    Call WriteINI(Me.Name, "Width", Me.Width, QuickRef.UserINIFileName)
End If

End Sub

Private Sub mnuArrangeIcons_Click()

Call ArrangeIcons(vbArrangeIcons)

End Sub
Private Sub mnuCascade_Click()

Call ArrangeIcons(vbCascade)

End Sub
Private Sub mnuPrintSetup_Click()

On Local Error Resume Next

Dialog.ShowPrinter

End Sub
Private Sub mnuColors_Click()

frmColors.Show
frmColors.WindowState = vbNormal
frmColors.ZOrder

End Sub

Private Sub mnuExit_Click()

'Confirm...
If MsgBox("Are you sure you want to exit the system?", vbYesNo + vbQuestion, "Exit System...") = vbNo Then
    Exit Sub
End If

Unload Me

End Sub
Private Sub mnuReLogin_Click()

On Local Error Resume Next

'Confirm Re-Login...
If Forms.Count > 1 Then
    If MsgBox("Note: This will close all open windows. Do you want to continue?", vbYesNo + vbQuestion, "Re-Login...") = vbNo Then
        Exit Sub
    End If
End If

'Close all open windows...
Call CloseAllOpenWindows

'User clicked cancel on one of the open forms, so exit...
If Forms.Count > 1 Then Exit Sub

'Show the login window...
Login.ReLoggingIn = True
frmLogin.Show vbModal
Login.ReLoggingIn = False

End Sub
Private Sub mnuTileHorizontally_Click()

Call ArrangeIcons(vbHorizontal)

End Sub
Private Sub mnuTileVertically_Click()

Call ArrangeIcons(vbVertical)

End Sub
Private Sub Timer1_Timer()

On Local Error Resume Next

Dim x As Byte
Dim iAutoApply As Boolean
Dim iShowHideSolidColors As Boolean
Dim iWindowState As Byte

'Update Colors...
If Colors.UpdateColors = True Then
    Call LoadColors
    For x = 0 To Forms.Count - 1
        Call SetColors(Forms(x))
    Next x
    Colors.UpdateColors = False
End If

'Change Skin...
If Skins.UpdateSkins = True Then
    iAutoApply = (frmColors.imgAutoApply.Picture = mdiMainMenu.imgSkins(CheckONID).Picture)
    iShowHideSolidColors = (frmColors.imgShowHideSolidColors.Picture = mdiMainMenu.imgSkins(CheckONID).Picture)
    iWindowState = mdiMainMenu.WindowState
    For x = 0 To Forms.Count - 1
        Call LoadSkins(Forms(x), True)
        Call SetColors(Forms(x))
    Next x
    mdiMainMenu.WindowState = vbMinimized
    mdiMainMenu.WindowState = iWindowState
    Skins.UpdateSkins = False
    Unload frmColors
    DoEvents
    frmColors.Show
    frmColors.ZOrder
    'Auto Apply...
    If iAutoApply Then
        frmColors.imgAutoApply.Picture = mdiMainMenu.imgSkins(CheckONID).Picture
    Else
        frmColors.imgAutoApply.Picture = mdiMainMenu.imgSkins(CheckOFFID).Picture
    End If
    'Show / Hide Solid Colors...
    If iShowHideSolidColors Then
        frmColors.imgShowHideSolidColors.Picture = mdiMainMenu.imgSkins(CheckONID).Picture
        frmColors.picColorsSquare.Visible = True
    Else
        frmColors.imgShowHideSolidColors.Picture = mdiMainMenu.imgSkins(CheckOFFID).Picture
        frmColors.picColorsSquare.Visible = False
    End If
End If

End Sub
Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)

On Local Error GoTo ToolBar1_ButtonClickError

'Toolbar Buttons...
Select Case LCase$(Button.Key)
    'Employee...
    Case "employee"
    'Clients...
    Case "clients"
    'Sign-In...
    Case "signin"
    'Payroll...
    Case "payroll"
    'Billing...
    Case "billing"
    'Colors...
    Case "colors"
        frmColors.Show
        frmColors.WindowState = vbNormal
        frmColors.ZOrder
    'Exit...
    Case "exit"
        Unload Me
End Select

Exit Sub



ToolBar1_ButtonClickError:
    Call WriteToErrorLog(Me.Name, "ToolBar1_ButtonClickError", Err.Description, Err.Number, False)
    Exit Sub

End Sub
