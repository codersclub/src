                 -----------------------------------
	         Joystick Sample Project Readme File
		            February l998
	         -----------------------------------
                   (c) Microsoft Corporation, 1998

SUMMARY
=======

Joystick.exe is a self-extracting compressed file that contains a sample
project that demonstrates how to use the Joystick API functions in Visual
Basic. You can use this sample as a starting point for a game program that
uses a joystick for an input device.


MORE INFORMATION
================

When you run the self-extracting compressed file, the following files are
expanded in the Joystick Sample Project directory:

 - Form1.frm (7Kb)-the main form of the project
 - Joystick.vbp (1Kb)-the project file
 - Joystick.vbw (1Kb)-the workspace file
 - Module1.bas (7Kb)-the module containing the function, user-defined type
                     and constants declarations.
 - Readme.txt (2Kb)-you are currently reading this file.

How The Sample Works
--------------------

The joyGetDevCaps function is used in the form load event to determine if a
joystick is connected to the system. If the function is successful, the
form is redrawn with new controls to display the capabilities of the
joystick. These capabilities are stored in the members of the JOYCAPS 
user-defined type variable. A timer control is used to query the joystick's
position. The current position is determined by the successful results of 
the joyGetPosEx function. The members of the JOYINFOEX user-defined 
variable type contain the joystick position information. This information 
is displayed in text boxes in the form.