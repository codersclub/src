VERSION 5.00
Begin VB.Form Form1 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "joystick data"
   ClientHeight    =   855
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   2820
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   855
   ScaleWidth      =   2820
   StartUpPosition =   3  'Windows Default
   Begin VB.CheckBox button 
      Caption         =   "button 1"
      Height          =   255
      Index           =   0
      Left            =   1800
      TabIndex        =   2
      Top             =   240
      Width           =   1095
   End
   Begin VB.Timer Timer1 
      Enabled         =   0   'False
      Interval        =   100
      Left            =   2400
      Top             =   600
   End
   Begin VB.Label status 
      Caption         =   "status"
      Height          =   255
      Left            =   0
      TabIndex        =   3
      Top             =   600
      Width           =   2415
   End
   Begin VB.Label label 
      Caption         =   "X"
      Height          =   255
      Index           =   0
      Left            =   120
      TabIndex        =   1
      Top             =   240
      Width           =   375
   End
   Begin VB.Label axis 
      BorderStyle     =   1  'Fixed Single
      Caption         =   " "
      Height          =   255
      Index           =   0
      Left            =   600
      TabIndex        =   0
      Top             =   240
      Width           =   975
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Dim ji As JOYINFOEX     ' joystick state buffer
Dim caps As JOYCAPS     ' joystick capabilities
Dim rc As Long          ' return code
Dim i As Long           ' index
Dim mask As Long        ' bitmask
Dim xaxis As label      ' x-axis control
Dim yaxis As label      ' y-axis control
Dim zaxis As label      ' z-axis control
Dim raxis As label      ' r-axis control
Dim uaxis As label      ' u-axis control
Dim vaxis As label      ' v-axis control
Dim pov As label        ' pov-axis control
Dim numAxes As Long     ' number of axes added to form
Dim axisY As Long       ' Y value for current axis control being added
Const ySpacingFactor = 1.4  ' spacing between controls

Private Sub Form_Load()
   ' Start with timer disabled
   Timer1.Enabled = False

   ' Get capabilities of joystick1
   rc = joyGetDevCaps(JOYSTICKID1, caps, Len(caps))
   If (rc <> 0) Then
       MsgBox "Couldn't detect the joystick"
       End
   End If
   
   ' Add axis controls
   numAxes = 1
   axisY = axis(0).Top
   Set xaxis = axis(0)
   AddAxisControl "Y", yaxis
   If (caps.wCaps And JOYCAPS_HASZ) Then AddAxisControl "Z", zaxis
   If (caps.wCaps And JOYCAPS_HASR) Then AddAxisControl "R", raxis
   If (caps.wCaps And JOYCAPS_HASU) Then AddAxisControl "U", uaxis
   If (caps.wCaps And JOYCAPS_HASV) Then AddAxisControl "V", vaxis
   If (caps.wCaps And JOYCAPS_HASPOV) Then AddAxisControl "POV", pov
   
   ' Create checkboxes for the buttons
   LoadButtonCheckBoxes (caps.wNumButtons)
   
   ' Position the status box
   status.Left = 0
   status.Top = Form1.Height - (status.Height * 2.5)
   
   ' Start the timer
   Timer1.Enabled = True
End Sub

'Add label controls for a supported axis
Private Sub AddAxisControl(name As String, ctrl As label)

   axisY = axisY + (axis(0).Height * ySpacingFactor)
   
   If (Form1.Height < (axisY + axis(0).Height * 3)) Then
      Form1.Height = Form1.Height + (axis(0).Height * ySpacingFactor)
   End If
   
   Load axis(numAxes)
   Load label(numAxes)
   
   Set ctrl = axis(numAxes)
   ctrl.Width = axis(0).Width
   ctrl.Height = axis(0).Height
   ctrl.Left = axis(0).Left
   ctrl.Top = axisY
   ctrl.Visible = True
   label(numAxes).Width = label(0).Width
   label(numAxes).Height = label(0).Height
   label(numAxes).Left = label(0).Left
   label(numAxes).Top = axisY
   label(numAxes).Visible = True
   label(numAxes).Caption = name
   numAxes = numAxes + 1
End Sub
' Add a checkbox for each of the buttons on the joystick
Private Sub LoadButtonCheckBoxes(numButtons As Long)
   If (numButtons = 0) Then
      button(0).Visible = False
      Form1.Width = button(0).Left
   Else
      If (numButtons > 1) Then
   
         Dim curX As Long
         Dim curY As Long
         Dim i As Long
      
         curX = button(0).Left
         curY = button(0).Top
         
         For i = 1 To (numButtons - 1)
            ' move down for the next control
            curY = curY + (button(0).Height * ySpacingFactor)
            
            'start new column if necessary
            If (Form1.Height < (curY + 3 * button(0).Height)) Then
                curY = button(0).Top
                curX = curX + button(0).Width
            End If
            
            'expand form if necessary
            If (Form1.Width < (curX + button(0).Width)) Then
                Form1.Width = curX + button(0).Width
            End If
            
            ' load checkbox and set properties
            Load button(i)
            button(i).Top = curY
            button(i).Left = curX
            button(i).Width = button(0).Width
            button(i).Height = button(0).Height
            button(i).Visible = True
            button(i).Caption = "button " & i + 1
         Next
      End If
   End If
End Sub

' Poll the joystick
Private Sub Timer1_Timer()

   ' Initialize struct
   ji.dwSize = Len(ji)
   ji.dwFlags = JOY_RETURNALL
   
   ' Get the current joystick data
   rc = joyGetPosEx(JOYSTICKID1, ji)
   
   ' Display the status
   If (rc = 0) Then
      status.Caption = "status: joystick connected"
   Else
      If (rc = JOYERR_UNPLUGGED) Then
         status.Caption = "status: joystick unplugged"
      Else
         status.Caption = "status: joyGetPosEx error, rc = " & rc
      End If
   End If
   
   ' Display the data on the form
   xaxis.Caption = ji.dwXpos
   yaxis.Caption = ji.dwYpos
   If (caps.wCaps And JOYCAPS_HASZ) Then zaxis.Caption = ji.dwZpos
   If (caps.wCaps And JOYCAPS_HASR) Then raxis.Caption = ji.dwRpos
   If (caps.wCaps And JOYCAPS_HASU) Then uaxis.Caption = ji.dwUpos
   If (caps.wCaps And JOYCAPS_HASV) Then vaxis.Caption = ji.dwVpos
   If (caps.wCaps And JOYCAPS_HASPOV) Then pov.Caption = ji.dwPOV
   mask = 1
   For i = 0 To (caps.wNumButtons - 1)
      If (ji.dwButtons And mask) Then button(i).Value = 1 Else button(i).Value = 0
      mask = mask * 2
   Next
End Sub
