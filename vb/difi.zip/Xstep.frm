VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   6615
   ClientLeft      =   165
   ClientTop       =   450
   ClientWidth     =   7710
   LinkTopic       =   "Form1"
   ScaleHeight     =   6615
   ScaleWidth      =   7710
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command3 
      Caption         =   "Command3"
      Height          =   1275
      Left            =   1020
      TabIndex        =   174
      ToolTipText     =   "Exit Game"
      Top             =   4800
      Visible         =   0   'False
      Width           =   1335
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Command2"
      Height          =   315
      Left            =   120
      TabIndex        =   173
      Top             =   3000
      Width           =   555
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Command1"
      Height          =   975
      Left            =   4800
      TabIndex        =   172
      ToolTipText     =   "Next Step of Game"
      Top             =   4860
      Width           =   1215
   End
   Begin VB.Image Image2 
      Height          =   1335
      Left            =   2520
      ToolTipText     =   "Help System"
      Top             =   4920
      Width           =   1815
   End
   Begin VB.Label Label172 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Unique Game"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   171
      Top             =   1200
      Width           =   1695
   End
   Begin VB.Label Label171 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0,0"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5040
      TabIndex        =   170
      Top             =   2640
      Width           =   435
   End
   Begin VB.Label Label170 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Rate"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5040
      TabIndex        =   169
      Top             =   2400
      Width           =   435
   End
   Begin VB.Label Label169 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "http://bestlink.ru"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   168
      Top             =   3120
      Width           =   3135
   End
   Begin VB.Label Label168 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "JAVA & VB developer"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   167
      Top             =   2880
      Width           =   3135
   End
   Begin VB.Label Label167 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "vshv@bestlink.ru   vshv@usa.net"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   166
      Top             =   2640
      Width           =   3135
   End
   Begin VB.Label Label166 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "1996-2001"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   165
      Top             =   2400
      Width           =   3135
   End
   Begin VB.Label Label165 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "Moscow, Russia"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   164
      Top             =   2160
      Width           =   3135
   End
   Begin VB.Label Label164 
      Alignment       =   2  'Center
      BackColor       =   &H00400000&
      BackStyle       =   0  'Transparent
      Caption         =   "(c) by Valery SHmeleff"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   163
      Top             =   1920
      Width           =   3135
   End
   Begin VB.Label Label163 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Cellular Phones version 1.00"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   162
      Top             =   1680
      Width           =   3135
   End
   Begin VB.Label Label162 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "X-Digital Field"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000C000&
      Height          =   255
      Left            =   1920
      TabIndex        =   161
      Top             =   1440
      Width           =   3135
   End
   Begin VB.Label Label161 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "000"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5040
      TabIndex        =   160
      Top             =   3360
      Width           =   435
   End
   Begin VB.Label Label160 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Hidd"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5040
      TabIndex        =   159
      Top             =   3120
      Width           =   435
   End
   Begin VB.Label Label159 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Account"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   158
      Top             =   1200
      Width           =   735
   End
   Begin VB.Label Label158 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0000"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   157
      Top             =   1200
      Width           =   735
   End
   Begin VB.Label Label157 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Y"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   5040
      TabIndex        =   156
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label156 
      Caption         =   "Label156"
      Height          =   255
      Left            =   60
      TabIndex        =   155
      Top             =   3660
      Width           =   735
   End
   Begin VB.Label Label155 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   154
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label154 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   153
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label153 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   152
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label152 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   151
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label151 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   150
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label150 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   149
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label149 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   148
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label148 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   147
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label147 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   146
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label146 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   145
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label145 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   144
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label144 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   143
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label143 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   142
      Top             =   1440
      Width           =   255
   End
   Begin VB.Label Label142 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   141
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label141 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   140
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label140 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   139
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label139 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   138
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label138 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   137
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label137 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   136
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label136 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   135
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label135 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   134
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label134 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   133
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label133 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   132
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label132 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   131
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label131 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   130
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label130 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   129
      Top             =   1680
      Width           =   255
   End
   Begin VB.Label Label129 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   128
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label128 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   127
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label127 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   126
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label126 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   125
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label125 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   124
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label124 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   123
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label123 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   122
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label122 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   121
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label121 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   120
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label120 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   119
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label119 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   118
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label118 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   117
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label117 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   116
      Top             =   1920
      Width           =   255
   End
   Begin VB.Label Label116 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   115
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label115 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   114
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label114 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   113
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label113 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   112
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label112 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   111
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label111 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   110
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label110 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   109
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label109 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   108
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label108 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   107
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label107 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   106
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label106 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   105
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label105 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   104
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label104 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   103
      Top             =   2160
      Width           =   255
   End
   Begin VB.Label Label103 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   102
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label102 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   101
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label101 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   100
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label100 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   99
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label99 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   98
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label98 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   97
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label97 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   96
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label96 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   95
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label95 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   94
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label94 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   93
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label93 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   92
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label92 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   91
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label91 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   90
      Top             =   2400
      Width           =   255
   End
   Begin VB.Label Label90 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   89
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label89 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   88
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label88 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   87
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label87 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   86
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label86 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   85
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label85 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   84
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label84 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   83
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label83 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   82
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label82 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   81
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label81 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   80
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label80 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   79
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label79 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   78
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label78 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "8"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   77
      Top             =   2640
      Width           =   255
   End
   Begin VB.Label Label77 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   76
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label76 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   75
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label75 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   74
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label74 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   73
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label73 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   72
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label72 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   71
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label71 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   70
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label70 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   69
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label69 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   68
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label68 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   67
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label67 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   66
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label66 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   65
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label65 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "7"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   64
      Top             =   2880
      Width           =   255
   End
   Begin VB.Label Label64 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   63
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label63 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   62
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label62 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   61
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label61 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   60
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label60 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   59
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label59 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   58
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label58 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   57
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label57 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   56
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label56 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   55
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label55 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   54
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label54 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   53
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label53 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   52
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label52 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "6"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   51
      Top             =   3120
      Width           =   255
   End
   Begin VB.Label Label51 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   50
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label50 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   49
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label49 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   48
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label48 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   47
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label47 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   46
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label46 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   45
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label45 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   44
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label44 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   43
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label43 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   42
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label42 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   41
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label41 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   40
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label40 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   39
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label39 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "5"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   38
      Top             =   3360
      Width           =   255
   End
   Begin VB.Label Label38 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   37
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label37 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   36
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label36 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   35
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label35 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   34
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label34 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   33
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label33 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   32
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label32 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   31
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label31 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   30
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label30 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   29
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label29 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   28
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label28 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   27
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label27 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   26
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label26 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "4"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   25
      Top             =   3600
      Width           =   255
   End
   Begin VB.Label Label25 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4800
      TabIndex        =   24
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label24 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4560
      TabIndex        =   23
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label23 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4320
      TabIndex        =   22
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label22 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   4080
      TabIndex        =   21
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label21 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3840
      TabIndex        =   20
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label20 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3600
      TabIndex        =   19
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label19 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3360
      TabIndex        =   18
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label18 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   3120
      TabIndex        =   17
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label17 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2880
      TabIndex        =   16
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label16 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2640
      TabIndex        =   15
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label15 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2400
      TabIndex        =   14
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label14 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   13
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label13 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "3"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1920
      TabIndex        =   12
      Top             =   3840
      Width           =   255
   End
   Begin VB.Label Label12 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   11
      Top             =   3840
      Width           =   615
   End
   Begin VB.Label Label11 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   10
      Top             =   3600
      Width           =   615
   End
   Begin VB.Label Label10 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   9
      Top             =   3360
      Width           =   615
   End
   Begin VB.Label Label9 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   8
      Top             =   3120
      Width           =   615
   End
   Begin VB.Label Label8 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   7
      Top             =   2880
      Width           =   615
   End
   Begin VB.Label Label7 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   6
      Top             =   2640
      Width           =   615
   End
   Begin VB.Label Label6 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   5
      Top             =   2400
      Width           =   615
   End
   Begin VB.Label Label5 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   4
      Top             =   2160
      Width           =   615
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   3
      Top             =   1920
      Width           =   615
   End
   Begin VB.Label Label3 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "10"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   1320
      TabIndex        =   2
      Top             =   1680
      Width           =   615
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "Level"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   1320
      TabIndex        =   1
      Top             =   1200
      Width           =   615
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BorderStyle     =   1  'Fixed Single
      Caption         =   "11"
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   1320
      TabIndex        =   0
      Top             =   1440
      Width           =   615
   End
   Begin VB.Image Image1 
      Height          =   6210
      Left            =   960
      Picture         =   "Xstep.frx":0000
      Top             =   120
      Width           =   5055
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim ii, ELEMENT_NUM, YOU, YTL
Dim L13, CT13, F13, FONT13, BCL13
Dim L14, CT14, F14, FONT14, BCL14
Dim L15, CT15, F15, FONT15, BCL15
Dim L16, CT16, F16, FONT16, BCL16
Dim L17, CT17, F17, FONT17, BCL17
Dim L18, CT18, F18, FONT18, BCL18
Dim L19, CT19, F19, FONT19, BCL19
Dim L20, CT20, F20, FONT20, BCL20
Dim L21, CT21, F21, FONT21, BCL21
Dim L22, CT22, F22, FONT22, BCL22
Dim L23, CT23, F23, FONT23, BCL23
Dim L24, CT24, F24, FONT24, BCL24
Dim L25, CT25, F25, FONT25, BCL25
Dim counter, TM, TTM, TTMS, TTL, ol, MINUSRND, NextStepTrig
Dim NexStepHorisontal(13)
Dim GeneralTrig
Dim ThreeTrigger                 '������� ��� 3-� ����������� "Y"
Dim BombCount                    '����������, ��� ����� � ���������
Dim Rate                         '������� �������
Dim Rates                        '��� �������� �������
Dim CreditON                     '������ ����� =1, �� ����� =0
Dim KeyPressNum                  '���������� ������� ������ Next Step
Dim credit                       '�������� �������
Dim CTREE                        '�������� ��� ������� �������  =3 ��� 0.3
Private Sub NextStepCounter13()
If Label26.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label26.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label26.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label26.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label26.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label26.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label26.Caption = "Z" Then Label158.Caption = 0
If Label26.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label26.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label26.Caption = "Y"
End Sub
Private Sub NextStepCounter14()
If Label27.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label27.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label27.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label27.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label27.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label27.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label27.Caption = "Z" Then Label158.Caption = 0
If Label27.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label27.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label27.Caption = "Y"
End Sub
Private Sub NextStepCounter15()
If Label28.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label28.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label28.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label28.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label28.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label28.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label28.Caption = "Z" Then Label158.Caption = 0
If Label28.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label28.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label28.Caption = "Y"
End Sub
Private Sub NextStepCounter16()
If Label29.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label29.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label29.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label29.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label29.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label29.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label29.Caption = "Z" Then Label158.Caption = 0
If Label29.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label29.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label29.Caption = "Y"
End Sub
Private Sub NextStepCounter17()
If Label30.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label30.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label30.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label30.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label30.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label30.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label30.Caption = "Z" Then Label158.Caption = 0
If Label30.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label30.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label30.Caption = "Y"
End Sub
Private Sub NextStepCounter18()
If Label31.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label31.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label31.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label31.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label31.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label31.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label31.Caption = "Z" Then Label158.Caption = 0
If Label31.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label31.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label31.Caption = "Y"
End Sub
Private Sub NextStepCounter19()
If Label32.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label32.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label32.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label32.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label32.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label32.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label32.Caption = "Z" Then Label158.Caption = 0
If Label32.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label32.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label32.Caption = "Y"
End Sub
Private Sub NextStepCounter20()
If Label33.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label33.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label33.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label33.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label33.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label33.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label33.Caption = "Z" Then Label158.Caption = 0
If Label33.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label33.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label33.Caption = "Y"
End Sub
Private Sub NextStepCounter21()
If Label34.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label34.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label34.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label34.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label34.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label34.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label34.Caption = "Z" Then Label158.Caption = 0
If Label34.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label34.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label34.Caption = "Y"
End Sub
Private Sub NextStepCounter22()
If Label35.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label35.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label35.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label35.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label35.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label35.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label35.Caption = "Z" Then Label158.Caption = 0
If Label35.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label35.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label35.Caption = "Y"
End Sub
Private Sub NextStepCounter23()
If Label36.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label36.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label36.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label36.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label36.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label36.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label36.Caption = "Z" Then Label158.Caption = 0
If Label36.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label36.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label36.Caption = "Y"
End Sub
Private Sub NextStepCounter24()
If Label37.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label37.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label37.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label37.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label37.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label37.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label37.Caption = "Z" Then Label158.Caption = 0
If Label37.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label37.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label37.Caption = "Y"
End Sub
Private Sub NextStepCounter25()
If Label38.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label38.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label38.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label38.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label38.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label38.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label38.Caption = "Z" Then Label158.Caption = 0
If Label38.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If Label38.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
Label38.Caption = "Y"
End Sub
Private Sub BombCounter()
BombCount = Int((2 * Rnd) + 1)
If BombCount = 1 Then GoTo 17775
If BombCount = 2 Then GoTo 17776
GoTo 17777
17775:
BombCount = Int((100 * Rnd) + 1)
GoTo 17777
17776:
BombCount = (Int((100 * Rnd) + 1) * (-1))
17777:
End Sub
Private Sub Premium()     '���������� ������
If KeyPressNum = 10 Then Label158.Caption = Label158.Caption + 100
If KeyPressNum = 10 Then Label172.Caption = "Premium: 100$"

If KeyPressNum = 30 Then Label158.Caption = Label158.Caption + 100
If KeyPressNum = 30 Then Label172.Caption = "Premium: Next 100$"

If KeyPressNum = 50 Then Label158.Caption = Label158.Caption + 200
If KeyPressNum = 50 Then Label172.Caption = "Premium: 200$"

If KeyPressNum = 70 Then Label158.Caption = Label158.Caption + 200
If KeyPressNum = 70 Then Label172.Caption = "Premium: Next 200$"

If KeyPressNum = 100 Then Label158.Caption = Label158.Caption + 1000
If KeyPressNum = 100 Then Label172.Caption = "Premium: 1000$"

If KeyPressNum = 150 Then Label158.Caption = Label158.Caption + 1000
If KeyPressNum = 150 Then Label172.Caption = "Premium: Next 1000$"

If KeyPressNum = 180 Then Label158.Caption = Label158.Caption + 100
If KeyPressNum = 180 Then Label172.Caption = "Premium: 100$"

If KeyPressNum = 190 Then Label158.Caption = Label158.Caption + 100
If KeyPressNum = 190 Then Label172.Caption = "Premium: Next 100$"

If KeyPressNum = 200 Then Label158.Caption = Label158.Caption + 200
If KeyPressNum = 200 Then Label172.Caption = "Premium: 200$"

If KeyPressNum = 210 Then Label158.Caption = Label158.Caption + 200
If KeyPressNum = 210 Then Label172.Caption = "Premium: Next 200$"

KeyPressNum = KeyPressNum + 1
End Sub
Private Sub Command1_Click()
Label172.Caption = "Make MONEY !!!"
Form1.Caption = "http://members.xoom.com/ksiod/resume.htm"
BombCounter                    '������� �������� ��� BombCount
ThreeTrigger = 6
Label157.Caption = "ThreeTrigger"                  '������� ����������� ���������

If GeneralTrig = 1 Then GoTo 1234

VisibleLabel                   '������� ���������� ������

'---------- ���������� ������ --------------
Premium
                '------------- ���������� ������� ------------
                Rate = Int((CTREE * Rnd) + 1)    '��������� �������
                Rates = Label158.Caption
                Rates = Int(Rates / 100)
                Rates = Rates * Rate / 10
                Label158.Caption = Label158.Caption - Rates
                Label170.Caption = Rate / 10
                '------------------ �������� -----------------
                credit = 850                    '������ �������
                Algorythm
                '---------------------------------------------
Label161.Caption = Int((8 * Rnd) + 1)           '���������� ���������� �������
LabelHid                       '�������� ������� ������

NextStepTrig = 1             '��������� ���������� "Y" ������ �� 1 �������
If Label13.Caption = "Y" Then L13 = Label26.Caption
If Label13.Caption = "Y" Then CT13 = Label26.ToolTipText
If Label14.Caption = "Y" Then L14 = Label27.Caption
If Label14.Caption = "Y" Then CT14 = Label27.ToolTipText
If Label15.Caption = "Y" Then L15 = Label28.Caption
If Label15.Caption = "Y" Then CT15 = Label28.ToolTipText
If Label16.Caption = "Y" Then L16 = Label29.Caption
If Label16.Caption = "Y" Then CT16 = Label29.ToolTipText
If Label17.Caption = "Y" Then L17 = Label30.Caption
If Label17.Caption = "Y" Then CT17 = Label30.ToolTipText
If Label18.Caption = "Y" Then L18 = Label31.Caption
If Label18.Caption = "Y" Then CT18 = Label31.ToolTipText
If Label19.Caption = "Y" Then L19 = Label32.Caption
If Label19.Caption = "Y" Then CT19 = Label32.ToolTipText
If Label20.Caption = "Y" Then L20 = Label33.Caption
If Label20.Caption = "Y" Then CT20 = Label33.ToolTipText
If Label21.Caption = "Y" Then L21 = Label34.Caption
If Label21.Caption = "Y" Then CT21 = Label34.ToolTipText
If Label22.Caption = "Y" Then L22 = Label35.Caption
If Label22.Caption = "Y" Then CT22 = Label35.ToolTipText
If Label23.Caption = "Y" Then L23 = Label36.Caption
If Label23.Caption = "Y" Then CT23 = Label36.ToolTipText
If Label24.Caption = "Y" Then L24 = Label37.Caption
If Label24.Caption = "Y" Then CT24 = Label37.ToolTipText
If Label25.Caption = "Y" Then L25 = Label38.Caption
If Label25.Caption = "Y" Then CT25 = Label38.ToolTipText
If Label13.Caption = "Y" Then NextStepCounter13

Label12.Caption = Label11.Caption        '���������� LEVEL
Label11.Caption = Label10.Caption
Label10.Caption = Label9.Caption
Label9.Caption = Label8.Caption
Label8.Caption = Label7.Caption
Label7.Caption = Label6.Caption
Label6.Caption = Label5.Caption
Label5.Caption = Label4.Caption
Label4.Caption = Label3.Caption
Label3.Caption = Label2.Caption

NUM1 = Label2.Caption                           '�������� ��������� ������� �� 1
NUM1 = NUM1 + 1
Label2.Caption = NUM1

' ���������� ������ LEVEL �� ������ LEVEL
Label13.Caption = Label26.Caption               '�������� ����� ������� ����
Label13.ToolTipText = Label26.ToolTipText
Label26.Caption = Label39.Caption
Label26.ToolTipText = Label39.ToolTipText
Label39.Caption = Label52.Caption
Label39.ToolTipText = Label52.ToolTipText
Label52.Caption = Label65.Caption
Label52.ToolTipText = Label65.ToolTipText
Label65.Caption = Label78.Caption
Label65.ToolTipText = Label78.ToolTipText
Label78.Caption = Label91.Caption
Label78.ToolTipText = Label91.ToolTipText
Label91.Caption = Label104.Caption
Label91.ToolTipText = Label104.ToolTipText
Label104.Caption = Label117.Caption
Label104.ToolTipText = Label117.ToolTipText
Label117.Caption = Label130.Caption
Label117.ToolTipText = Label130.ToolTipText
Label130.Caption = Label143.Caption
Label130.ToolTipText = Label143.ToolTipText


RND_NEXT
If ii = 1 Then Label143.Caption = "-5"
If ii = 2 Then Label143.Caption = "+5"
If ii = 3 Then Label143.Caption = "-10"
If ii = 4 Then Label143.Caption = "+15"
If ii = 5 Then Label143.Caption = "Z"
If ii = 6 Then Label143.Caption = "+1"
If ii = 7 Then Label143.Caption = "B"
If ii = 8 Then Label143.Caption = "Z"
If ii = 9 Then Label143.Caption = "-1"
If ii = 10 Then Label143.Caption = "(-)"
If ii = 1 Then Label143.ToolTipText = "Decrease 5$"
If ii = 2 Then Label143.ToolTipText = "Increase 5$"
If ii = 3 Then Label143.ToolTipText = "Decrease 10$"
If ii = 4 Then Label143.ToolTipText = "Increase 15$"
If ii = 5 Then Label143.ToolTipText = "Zero Counter"
If ii = 6 Then Label143.ToolTipText = "Increase 1$"
If ii = 7 Then Label143.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label143.ToolTipText = "Zero Counter"
If ii = 9 Then Label143.ToolTipText = "Decrease 1$"
If ii = 10 Then Label143.ToolTipText = "Randomize Decrease"
'------------------------------
If Label14.Caption = "Y" Then NextStepCounter14

Label14.Caption = Label27.Caption
Label14.ToolTipText = Label27.ToolTipText
Label27.Caption = Label40.Caption
Label27.ToolTipText = Label40.ToolTipText
Label40.Caption = Label53.Caption
Label40.ToolTipText = Label53.ToolTipText
Label53.Caption = Label66.Caption
Label53.ToolTipText = Label66.ToolTipText
Label66.Caption = Label79.Caption
Label66.ToolTipText = Label79.ToolTipText
Label79.Caption = Label92.Caption
Label79.ToolTipText = Label92.ToolTipText
Label92.Caption = Label105.Caption
Label92.ToolTipText = Label105.ToolTipText
Label105.Caption = Label118.Caption
Label105.ToolTipText = Label118.ToolTipText
Label118.Caption = Label131.Caption
Label118.ToolTipText = Label131.ToolTipText
Label131.Caption = Label144.Caption
Label131.ToolTipText = Label144.ToolTipText

RND_NEXT
If ii = 1 Then Label144.Caption = "-5"
If ii = 2 Then Label144.Caption = "+5"
If ii = 3 Then Label144.Caption = "-10"
If ii = 4 Then Label144.Caption = "+15"
If ii = 5 Then Label144.Caption = "Z"
If ii = 6 Then Label144.Caption = "+1"
If ii = 7 Then Label144.Caption = "B"
If ii = 8 Then Label144.Caption = "Z"
If ii = 9 Then Label144.Caption = "-1"
If ii = 10 Then Label144.Caption = "(-)"
If ii = 1 Then Label144.ToolTipText = "Decrease 5$"
If ii = 2 Then Label144.ToolTipText = "Increase 5$"
If ii = 3 Then Label144.ToolTipText = "Decrease 10$"
If ii = 4 Then Label144.ToolTipText = "Increase 15$"
If ii = 5 Then Label144.ToolTipText = "Zero Counter"
If ii = 6 Then Label144.ToolTipText = "Increase 1$"
If ii = 7 Then Label144.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label144.ToolTipText = "Zero Counter"
If ii = 9 Then Label144.ToolTipText = "Decrease 1$"
If ii = 10 Then Label144.ToolTipText = "Randomize Decrease"
'------------------------------
If Label15.Caption = "Y" Then NextStepCounter15

Label15.Caption = Label28.Caption
Label15.ToolTipText = Label28.ToolTipText
Label28.Caption = Label41.Caption
Label28.ToolTipText = Label41.ToolTipText
Label41.Caption = Label54.Caption
Label41.ToolTipText = Label54.ToolTipText
Label54.Caption = Label67.Caption
Label54.ToolTipText = Label67.ToolTipText
Label67.Caption = Label80.Caption
Label67.ToolTipText = Label80.ToolTipText
Label80.Caption = Label93.Caption
Label80.ToolTipText = Label93.ToolTipText
Label93.Caption = Label106.Caption
Label93.ToolTipText = Label106.ToolTipText
Label106.Caption = Label119.Caption
Label106.ToolTipText = Label119.ToolTipText
Label119.Caption = Label132.Caption
Label119.ToolTipText = Label132.ToolTipText
Label132.Caption = Label145.Caption
Label132.ToolTipText = Label145.ToolTipText

RND_NEXT
If ii = 1 Then Label145.Caption = "-5"
If ii = 2 Then Label145.Caption = "+5"
If ii = 3 Then Label145.Caption = "-10"
If ii = 4 Then Label145.Caption = "+15"
If ii = 5 Then Label145.Caption = "Z"
If ii = 6 Then Label145.Caption = "+1"
If ii = 7 Then Label145.Caption = "B"
If ii = 8 Then Label145.Caption = "Z"
If ii = 9 Then Label145.Caption = "-1"
If ii = 10 Then Label145.Caption = "(-)"
If ii = 1 Then Label145.ToolTipText = "Decrease 5$"
If ii = 2 Then Label145.ToolTipText = "Increase 5$"
If ii = 3 Then Label145.ToolTipText = "Decrease 10$"
If ii = 4 Then Label145.ToolTipText = "Increase 15$"
If ii = 5 Then Label145.ToolTipText = "Zero Counter"
If ii = 6 Then Label145.ToolTipText = "Increase 1$"
If ii = 7 Then Label145.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label145.ToolTipText = "Zero Counter"
If ii = 9 Then Label145.ToolTipText = "Decrease 1$"
If ii = 10 Then Label145.ToolTipText = "Randomize Decrease"
'------------------------------
If Label16.Caption = "Y" Then NextStepCounter16

Label16.Caption = Label29.Caption
Label16.ToolTipText = Label29.ToolTipText
Label29.Caption = Label42.Caption
Label29.ToolTipText = Label42.ToolTipText
Label42.Caption = Label55.Caption
Label42.ToolTipText = Label55.ToolTipText
Label55.Caption = Label68.Caption
Label55.ToolTipText = Label68.ToolTipText
Label68.Caption = Label81.Caption
Label68.ToolTipText = Label81.ToolTipText
Label81.Caption = Label94.Caption
Label81.ToolTipText = Label94.ToolTipText
Label94.Caption = Label107.Caption
Label94.ToolTipText = Label107.ToolTipText
Label107.Caption = Label120.Caption
Label107.ToolTipText = Label120.ToolTipText
Label120.Caption = Label133.Caption
Label120.ToolTipText = Label133.ToolTipText
Label133.Caption = Label146.Caption
Label133.ToolTipText = Label146.ToolTipText

RND_NEXT
If ii = 1 Then Label146.Caption = "-5"
If ii = 2 Then Label146.Caption = "+5"
If ii = 3 Then Label146.Caption = "-10"
If ii = 4 Then Label146.Caption = "+15"
If ii = 5 Then Label146.Caption = "Z"
If ii = 6 Then Label146.Caption = "+1"
If ii = 7 Then Label146.Caption = "B"
If ii = 8 Then Label146.Caption = "Z"
If ii = 9 Then Label146.Caption = "-1"
If ii = 10 Then Label146.Caption = "(-)"
If ii = 1 Then Label146.ToolTipText = "Decrease 5$"
If ii = 2 Then Label146.ToolTipText = "Increase 5$"
If ii = 3 Then Label146.ToolTipText = "Decrease 10$"
If ii = 4 Then Label146.ToolTipText = "Increase 15$"
If ii = 5 Then Label146.ToolTipText = "Zero Counter"
If ii = 6 Then Label146.ToolTipText = "Increase 1$"
If ii = 7 Then Label146.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label146.ToolTipText = "Zero Counter"
If ii = 9 Then Label146.ToolTipText = "Decrease 1$"
If ii = 10 Then Label146.ToolTipText = "Randomize Decrease"
'------------------------------
If Label17.Caption = "Y" Then NextStepCounter17

Label17.Caption = Label30.Caption
Label17.ToolTipText = Label30.ToolTipText
Label30.Caption = Label43.Caption
Label30.ToolTipText = Label43.ToolTipText
Label43.Caption = Label56.Caption
Label43.ToolTipText = Label56.ToolTipText
Label56.Caption = Label69.Caption
Label56.ToolTipText = Label69.ToolTipText
Label69.Caption = Label82.Caption
Label69.ToolTipText = Label82.ToolTipText
Label82.Caption = Label95.Caption
Label82.ToolTipText = Label95.ToolTipText
Label95.Caption = Label108.Caption
Label95.ToolTipText = Label108.ToolTipText
Label108.Caption = Label121.Caption
Label108.ToolTipText = Label121.ToolTipText
Label121.Caption = Label134.Caption
Label121.ToolTipText = Label134.ToolTipText
Label134.Caption = Label147.Caption
Label134.ToolTipText = Label147.ToolTipText

RND_NEXT
If ii = 1 Then Label147.Caption = "-5"
If ii = 2 Then Label147.Caption = "+5"
If ii = 3 Then Label147.Caption = "-10"
If ii = 4 Then Label147.Caption = "+15"
If ii = 5 Then Label147.Caption = "Z"
If ii = 6 Then Label147.Caption = "+1"
If ii = 7 Then Label147.Caption = "B"
If ii = 8 Then Label147.Caption = "Z"
If ii = 9 Then Label147.Caption = "-1"
If ii = 10 Then Label147.Caption = "(-)"
If ii = 1 Then Label147.ToolTipText = "Decrease 5$"
If ii = 2 Then Label147.ToolTipText = "Increase 5$"
If ii = 3 Then Label147.ToolTipText = "Decrease 10$"
If ii = 4 Then Label147.ToolTipText = "Increase 15$"
If ii = 5 Then Label147.ToolTipText = "Zero Counter"
If ii = 6 Then Label147.ToolTipText = "Increase 1$"
If ii = 7 Then Label147.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label147.ToolTipText = "Zero Counter"
If ii = 9 Then Label147.ToolTipText = "Decrease 1$"
If ii = 10 Then Label147.ToolTipText = "Randomize Decrease"
'------------------------------
If Label18.Caption = "Y" Then NextStepCounter18

Label18.Caption = Label31.Caption
Label18.ToolTipText = Label31.ToolTipText
Label31.Caption = Label44.Caption
Label31.ToolTipText = Label44.ToolTipText
Label44.Caption = Label57.Caption
Label44.ToolTipText = Label57.ToolTipText
Label57.Caption = Label70.Caption
Label57.ToolTipText = Label70.ToolTipText
Label70.Caption = Label83.Caption
Label70.ToolTipText = Label83.ToolTipText
Label83.Caption = Label96.Caption
Label83.ToolTipText = Label96.ToolTipText
Label96.Caption = Label109.Caption
Label96.ToolTipText = Label109.ToolTipText
Label109.Caption = Label122.Caption
Label109.ToolTipText = Label122.ToolTipText
Label122.Caption = Label135.Caption
Label122.ToolTipText = Label135.ToolTipText
Label135.Caption = Label148.Caption
Label135.ToolTipText = Label148.ToolTipText

RND_NEXT
If ii = 1 Then Label148.Caption = "-5"
If ii = 2 Then Label148.Caption = "+5"
If ii = 3 Then Label148.Caption = "-10"
If ii = 4 Then Label148.Caption = "+15"
If ii = 5 Then Label148.Caption = "Z"
If ii = 6 Then Label148.Caption = "+1"
If ii = 7 Then Label148.Caption = "B"
If ii = 8 Then Label148.Caption = "Z"
If ii = 9 Then Label148.Caption = "-1"
If ii = 10 Then Label148.Caption = "(-)"
If ii = 1 Then Label148.ToolTipText = "Decrease 5$"
If ii = 2 Then Label148.ToolTipText = "Increase 5$"
If ii = 3 Then Label148.ToolTipText = "Decrease 10$"
If ii = 4 Then Label148.ToolTipText = "Increase 15$"
If ii = 5 Then Label148.ToolTipText = "Zero Counter"
If ii = 6 Then Label148.ToolTipText = "Increase 1$"
If ii = 7 Then Label148.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label148.ToolTipText = "Zero Counter"
If ii = 9 Then Label148.ToolTipText = "Decrease 1$"
If ii = 10 Then Label148.ToolTipText = "Randomize Decrease"
'------------------------------
If Label19.Caption = "Y" Then NextStepCounter19

Label19.Caption = Label32.Caption
Label19.ToolTipText = Label32.ToolTipText
Label32.Caption = Label45.Caption
Label32.ToolTipText = Label45.ToolTipText
Label45.Caption = Label58.Caption
Label45.ToolTipText = Label58.ToolTipText
Label58.Caption = Label71.Caption
Label58.ToolTipText = Label71.ToolTipText
Label71.Caption = Label84.Caption
Label71.ToolTipText = Label84.ToolTipText
Label84.Caption = Label97.Caption
Label84.ToolTipText = Label97.ToolTipText
Label97.Caption = Label110.Caption
Label97.ToolTipText = Label110.ToolTipText
Label110.Caption = Label123.Caption
Label110.ToolTipText = Label123.ToolTipText
Label123.Caption = Label136.Caption
Label123.ToolTipText = Label136.ToolTipText
Label136.Caption = Label149.Caption
Label136.ToolTipText = Label149.ToolTipText

RND_NEXT
If ii = 1 Then Label149.Caption = "-5"
If ii = 2 Then Label149.Caption = "+5"
If ii = 3 Then Label149.Caption = "-10"
If ii = 4 Then Label149.Caption = "+15"
If ii = 5 Then Label149.Caption = "Z"
If ii = 6 Then Label149.Caption = "+1"
If ii = 7 Then Label149.Caption = "B"
If ii = 8 Then Label149.Caption = "Z"
If ii = 9 Then Label149.Caption = "-1"
If ii = 10 Then Label149.Caption = "(-)"
If ii = 1 Then Label149.ToolTipText = "Decrease 5$"
If ii = 2 Then Label149.ToolTipText = "Increase 5$"
If ii = 3 Then Label149.ToolTipText = "Decrease 10$"
If ii = 4 Then Label149.ToolTipText = "Increase 15$"
If ii = 5 Then Label149.ToolTipText = "Zero Counter"
If ii = 6 Then Label149.ToolTipText = "Increase 1$"
If ii = 7 Then Label149.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label149.ToolTipText = "Zero Counter"
If ii = 9 Then Label149.ToolTipText = "Decrease 1$"
If ii = 10 Then Label149.ToolTipText = "Randomize Decrease"
'------------------------------
If Label20.Caption = "Y" Then NextStepCounter20

Label20.Caption = Label33.Caption
Label20.ToolTipText = Label33.ToolTipText
Label33.Caption = Label46.Caption
Label33.ToolTipText = Label46.ToolTipText
Label46.Caption = Label59.Caption
Label46.ToolTipText = Label59.ToolTipText
Label59.Caption = Label72.Caption
Label59.ToolTipText = Label72.ToolTipText
Label72.Caption = Label85.Caption
Label72.ToolTipText = Label85.ToolTipText
Label85.Caption = Label98.Caption
Label85.ToolTipText = Label98.ToolTipText
Label98.Caption = Label111.Caption
Label98.ToolTipText = Label111.ToolTipText
Label111.Caption = Label124.Caption
Label111.ToolTipText = Label124.ToolTipText
Label124.Caption = Label137.Caption
Label124.ToolTipText = Label137.ToolTipText
Label137.Caption = Label150.Caption
Label137.ToolTipText = Label150.ToolTipText

RND_NEXT
If ii = 1 Then Label150.Caption = "-5"
If ii = 2 Then Label150.Caption = "+5"
If ii = 3 Then Label150.Caption = "-10"
If ii = 4 Then Label150.Caption = "+15"
If ii = 5 Then Label150.Caption = "Z"
If ii = 6 Then Label150.Caption = "+1"
If ii = 7 Then Label150.Caption = "B"
If ii = 8 Then Label150.Caption = "Z"
If ii = 9 Then Label150.Caption = "-1"
If ii = 10 Then Label150.Caption = "(-)"
If ii = 1 Then Label150.ToolTipText = "Decrease 5$"
If ii = 2 Then Label150.ToolTipText = "Increase 5$"
If ii = 3 Then Label150.ToolTipText = "Decrease 10$"
If ii = 4 Then Label150.ToolTipText = "Increase 15$"
If ii = 5 Then Label150.ToolTipText = "Zero Counter"
If ii = 6 Then Label150.ToolTipText = "Increase 1$"
If ii = 7 Then Label150.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label150.ToolTipText = "Zero Counter"
If ii = 9 Then Label150.ToolTipText = "Decrease 1$"
If ii = 10 Then Label150.ToolTipText = "Randomize Decrease"
'------------------------------
If Label21.Caption = "Y" Then NextStepCounter21

Label21.Caption = Label34.Caption
Label21.ToolTipText = Label34.ToolTipText
Label34.Caption = Label47.Caption
Label34.ToolTipText = Label47.ToolTipText
Label47.Caption = Label60.Caption
Label47.ToolTipText = Label60.ToolTipText
Label60.Caption = Label73.Caption
Label60.ToolTipText = Label73.ToolTipText
Label73.Caption = Label86.Caption
Label73.ToolTipText = Label86.ToolTipText
Label86.Caption = Label99.Caption
Label86.ToolTipText = Label99.ToolTipText
Label99.Caption = Label112.Caption
Label99.ToolTipText = Label112.ToolTipText
Label112.Caption = Label125.Caption
Label112.ToolTipText = Label125.ToolTipText
Label125.Caption = Label138.Caption
Label125.ToolTipText = Label138.ToolTipText
Label138.Caption = Label151.Caption
Label138.ToolTipText = Label151.ToolTipText

RND_NEXT
If ii = 1 Then Label151.Caption = "-5"
If ii = 2 Then Label151.Caption = "+5"
If ii = 3 Then Label151.Caption = "-10"
If ii = 4 Then Label151.Caption = "+15"
If ii = 5 Then Label151.Caption = "Z"
If ii = 6 Then Label151.Caption = "+1"
If ii = 7 Then Label151.Caption = "B"
If ii = 8 Then Label151.Caption = "Z"
If ii = 9 Then Label151.Caption = "-1"
If ii = 10 Then Label151.Caption = "(-)"
If ii = 1 Then Label151.ToolTipText = "Decrease 5$"
If ii = 2 Then Label151.ToolTipText = "Increase 5$"
If ii = 3 Then Label151.ToolTipText = "Decrease 10$"
If ii = 4 Then Label151.ToolTipText = "Increase 15$"
If ii = 5 Then Label151.ToolTipText = "Zero Counter"
If ii = 6 Then Label151.ToolTipText = "Increase 1$"
If ii = 7 Then Label151.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label151.ToolTipText = "Zero Counter"
If ii = 9 Then Label151.ToolTipText = "Decrease 1$"
If ii = 10 Then Label151.ToolTipText = "Randomize Decrease"
'------------------------------
If Label22.Caption = "Y" Then NextStepCounter22

Label22.Caption = Label35.Caption
Label22.ToolTipText = Label35.ToolTipText
Label35.Caption = Label48.Caption
Label35.ToolTipText = Label48.ToolTipText
Label48.Caption = Label61.Caption
Label48.ToolTipText = Label61.ToolTipText
Label61.Caption = Label74.Caption
Label61.ToolTipText = Label74.ToolTipText
Label74.Caption = Label87.Caption
Label74.ToolTipText = Label87.ToolTipText
Label87.Caption = Label100.Caption
Label87.ToolTipText = Label100.ToolTipText
Label100.Caption = Label113.Caption
Label100.ToolTipText = Label113.ToolTipText
Label113.Caption = Label126.Caption
Label113.ToolTipText = Label126.ToolTipText
Label126.Caption = Label139.Caption
Label126.ToolTipText = Label139.ToolTipText
Label139.Caption = Label152.Caption
Label139.ToolTipText = Label152.ToolTipText

RND_NEXT
If ii = 1 Then Label152.Caption = "-5"
If ii = 2 Then Label152.Caption = "+5"
If ii = 3 Then Label152.Caption = "-10"
If ii = 4 Then Label152.Caption = "+15"
If ii = 5 Then Label152.Caption = "Z"
If ii = 6 Then Label152.Caption = "+1"
If ii = 7 Then Label152.Caption = "B"
If ii = 8 Then Label152.Caption = "Z"
If ii = 9 Then Label152.Caption = "-1"
If ii = 10 Then Label152.Caption = "(-)"
If ii = 1 Then Label152.ToolTipText = "Decrease 5$"
If ii = 2 Then Label152.ToolTipText = "Increase 5$"
If ii = 3 Then Label152.ToolTipText = "Decrease 10$"
If ii = 4 Then Label152.ToolTipText = "Increase 15$"
If ii = 5 Then Label152.ToolTipText = "Zero Counter"
If ii = 6 Then Label152.ToolTipText = "Increase 1$"
If ii = 7 Then Label152.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label152.ToolTipText = "Zero Counter"
If ii = 9 Then Label152.ToolTipText = "Decrease 1$"
If ii = 10 Then Label152.ToolTipText = "Randomize Decrease"
'------------------------------
If Label23.Caption = "Y" Then NextStepCounter23

Label23.Caption = Label36.Caption
Label23.ToolTipText = Label36.ToolTipText
Label36.Caption = Label49.Caption
Label36.ToolTipText = Label49.ToolTipText
Label49.Caption = Label62.Caption
Label49.ToolTipText = Label62.ToolTipText
Label62.Caption = Label75.Caption
Label62.ToolTipText = Label75.ToolTipText
Label75.Caption = Label88.Caption
Label75.ToolTipText = Label88.ToolTipText
Label88.Caption = Label101.Caption
Label88.ToolTipText = Label101.ToolTipText
Label101.Caption = Label114.Caption
Label101.ToolTipText = Label114.ToolTipText
Label114.Caption = Label127.Caption
Label114.ToolTipText = Label127.ToolTipText
Label127.Caption = Label140.Caption
Label127.ToolTipText = Label140.ToolTipText
Label140.Caption = Label153.Caption
Label140.ToolTipText = Label153.ToolTipText

RND_NEXT
If ii = 1 Then Label153.Caption = "-5"
If ii = 2 Then Label153.Caption = "+5"
If ii = 3 Then Label153.Caption = "-10"
If ii = 4 Then Label153.Caption = "+15"
If ii = 5 Then Label153.Caption = "Z"
If ii = 6 Then Label153.Caption = "+1"
If ii = 7 Then Label153.Caption = "B"
If ii = 8 Then Label153.Caption = "Z"
If ii = 9 Then Label153.Caption = "-1"
If ii = 10 Then Label153.Caption = "(-)"
If ii = 1 Then Label153.ToolTipText = "Decrease 5$"
If ii = 2 Then Label153.ToolTipText = "Increase 5$"
If ii = 3 Then Label153.ToolTipText = "Decrease 10$"
If ii = 4 Then Label153.ToolTipText = "Increase 15$"
If ii = 5 Then Label153.ToolTipText = "Zero Counter"
If ii = 6 Then Label153.ToolTipText = "Increase 1$"
If ii = 7 Then Label153.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label153.ToolTipText = "Zero Counter"
If ii = 9 Then Label153.ToolTipText = "Decrease 1$"
If ii = 10 Then Label153.ToolTipText = "Randomize Decrease"
'------------------------------
If Label24.Caption = "Y" Then NextStepCounter24

Label24.Caption = Label37.Caption
Label24.ToolTipText = Label37.ToolTipText
Label37.Caption = Label50.Caption
Label37.ToolTipText = Label50.ToolTipText
Label50.Caption = Label63.Caption
Label50.ToolTipText = Label63.ToolTipText
Label63.Caption = Label76.Caption
Label63.ToolTipText = Label76.ToolTipText
Label76.Caption = Label89.Caption
Label76.ToolTipText = Label89.ToolTipText
Label89.Caption = Label102.Caption
Label89.ToolTipText = Label102.ToolTipText
Label102.Caption = Label115.Caption
Label102.ToolTipText = Label115.ToolTipText
Label115.Caption = Label128.Caption
Label115.ToolTipText = Label128.ToolTipText
Label128.Caption = Label141.Caption
Label128.ToolTipText = Label141.ToolTipText
Label141.Caption = Label154.Caption
Label141.ToolTipText = Label154.ToolTipText

RND_NEXT
If ii = 1 Then Label154.Caption = "-5"
If ii = 2 Then Label154.Caption = "+5"
If ii = 3 Then Label154.Caption = "-10"
If ii = 4 Then Label154.Caption = "+15"
If ii = 5 Then Label154.Caption = "Z"
If ii = 6 Then Label154.Caption = "+1"
If ii = 7 Then Label154.Caption = "B"
If ii = 8 Then Label154.Caption = "Z"
If ii = 9 Then Label154.Caption = "-1"
If ii = 10 Then Label154.Caption = "(-)"
If ii = 1 Then Label154.ToolTipText = "Decrease 5$"
If ii = 2 Then Label154.ToolTipText = "Increase 5$"
If ii = 3 Then Label154.ToolTipText = "Decrease 10$"
If ii = 4 Then Label154.ToolTipText = "Increase 15$"
If ii = 5 Then Label154.ToolTipText = "Zero Counter"
If ii = 6 Then Label154.ToolTipText = "Increase 1$"
If ii = 7 Then Label154.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label154.ToolTipText = "Zero Counter"
If ii = 9 Then Label154.ToolTipText = "Decrease 1$"
If ii = 10 Then Label154.ToolTipText = "Randomize Decrease"
'------------------------------
If Label25.Caption = "Y" Then NextStepCounter25

Label25.Caption = Label38.Caption
Label25.ToolTipText = Label38.ToolTipText
Label38.Caption = Label51.Caption
Label38.ToolTipText = Label51.ToolTipText
Label51.Caption = Label64.Caption
Label51.ToolTipText = Label64.ToolTipText
Label64.Caption = Label77.Caption
Label64.ToolTipText = Label77.ToolTipText
Label77.Caption = Label90.Caption
Label77.ToolTipText = Label90.ToolTipText
Label90.Caption = Label103.Caption
Label90.ToolTipText = Label103.ToolTipText
Label103.Caption = Label116.Caption
Label103.ToolTipText = Label116.ToolTipText
Label116.Caption = Label129.Caption
Label116.ToolTipText = Label129.ToolTipText
Label129.Caption = Label142.Caption
Label129.ToolTipText = Label142.ToolTipText
Label142.Caption = Label155.Caption
Label142.ToolTipText = Label155.ToolTipText

RND_NEXT
If ii = 1 Then Label155.Caption = "-5"
If ii = 2 Then Label155.Caption = "+5"
If ii = 3 Then Label155.Caption = "-10"
If ii = 4 Then Label155.Caption = "+15"
If ii = 5 Then Label155.Caption = "Z"
If ii = 6 Then Label155.Caption = "+1"
If ii = 7 Then Label155.Caption = "B"
If ii = 8 Then Label155.Caption = "Z"
If ii = 9 Then Label155.Caption = "-1"
If ii = 10 Then Label155.Caption = "(-)"
If ii = 1 Then Label155.ToolTipText = "Decrease 5$"
If ii = 2 Then Label155.ToolTipText = "Increase 5$"
If ii = 3 Then Label155.ToolTipText = "Decrease 10$"
If ii = 4 Then Label155.ToolTipText = "Increase 15$"
If ii = 5 Then Label155.ToolTipText = "Zero Counter"
If ii = 6 Then Label155.ToolTipText = "Increase 1$"
If ii = 7 Then Label155.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label155.ToolTipText = "Zero Counter"
If ii = 9 Then Label155.ToolTipText = "Decrease 1$"
If ii = 10 Then Label155.ToolTipText = "Randomize Decrease"
'------------------------------

1234:
'''''Form1.Caption = L13

End Sub
Private Sub CountMinus()
MINUSRND = Int((500 * Rnd) + 1)
Label158.Caption = Label158.Caption - MINUSRND
End Sub

Private Sub CommandButton2_Click()
End Sub

Private Sub CommandButton3_Click()
End
End Sub

Private Sub Image2_Click()
Form2.Show
End
End Sub

Private Sub Label13_Click()
If YTL = 0 Then GoTo 3000                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3000               '������� �� ��� ����������� "Y"?
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
''''''''''Form1.Caption = ThreeTrigger
If YOU = "" Then GoTo 2999               '���� YOU="", �� "Y" ����������� � �����
'       == ���������� "Y" ==
If YOU <> "" Then L13 = Label13.Caption          '��������� �������� ���������
If YOU <> "" Then CT13 = Label13.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F13 = Label13.ForeColor        '��������� ���������
If YOU <> "" Then FONT13 = Label13.Font.Size     '��������� ���������
If YOU <> "" Then BCL13 = Label13.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 14000         '����� �������� ���������� "Y"
If NexStepHorisontal(2) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(2) = 0 Then GoTo 3000
14000:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label13.BackColor = 65280        '��������� ������
    Label14.BackColor = 65280        '��������� �������� ������
    Label14.BorderStyle = fmBorderStyleNone
    Label14.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 1
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label13.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label13.Caption = "Z" Then Label158.Caption = 0
If Label13.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label13.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label13.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label13.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label13.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label13.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label13.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If YOU <> "" Then Label13.Caption = YOU
If YOU <> "" Then Label13.Font.Size = 16
If YOU <> "" Then Label13.ForeColor = 255
If YOU <> "" Then Label13.BackColor = 12648447
If YOU <> "" Then Label13.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3000
2999:             ' == ������ "Y" �� Label ==
GeneralTrig = 1   '��������� �������� ������ �������
    Label13.BackColor = -2147483642        '��������� ������
    Label14.BackColor = -2147483642        '��������� �������� ������
    Label14.BorderStyle = fmBorderStyleNone
    Label14.BorderStyle = fmBorderStyleSingle
If Label13.Caption = "Y" Then YOU = "Y"
If Label13.Caption = "Y" Then Label13.ToolTipText = CT13
If Label13.Caption = "Y" Then Label13.ForeColor = F13
If Label13.Caption = "Y" Then Label13.Font.Size = FONT13
If Label13.Caption = "Y" Then Label13.BackColor = BCL13
If Label13.Caption = "Y" Then Label13.Caption = L13

3000:
'''''Form1.Caption = L13

End Sub

Private Sub Label14_Click()
If YTL = 0 Then GoTo 3001                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3001
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2998
If YOU <> "" Then L14 = Label14.Caption          '��������� �������� ���������
If YOU <> "" Then CT14 = Label14.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F14 = Label14.ForeColor        '��������� ���������
If YOU <> "" Then FONT14 = Label14.Font.Size     '��������� ���������
If YOU <> "" Then BCL14 = Label14.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3501         '����� �������� ���������� "Y"
If NexStepHorisontal(1) = 1 Then GoTo 3501
If NexStepHorisontal(3) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(3) = 0 Then GoTo 3001
3501:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label13.BackColor = 65280        '��������� ������
    Label14.BackColor = 65280        '��������� ������
    Label15.BackColor = 65280        '��������� ������
    Label13.BorderStyle = fmBorderStyleNone
    Label13.BorderStyle = fmBorderStyleSingle
    Label15.BorderStyle = fmBorderStyleNone
    Label15.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 1
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label14.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label14.Caption = "Z" Then Label158.Caption = 0
If Label14.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label14.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label14.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label14.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label14.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label14.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label14.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label14.Caption = YOU
If YOU <> "" Then Label14.Font.Size = 16
If YOU <> "" Then Label14.ForeColor = 255
If YOU <> "" Then Label14.BackColor = 12648447
If YOU <> "" Then Label14.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3001
2998:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label13.BackColor = -2147483642        '��������� ������
    Label14.BackColor = -2147483642        '��������� ������
    Label15.BackColor = -2147483642        '��������� ������
    Label13.BorderStyle = fmBorderStyleNone
    Label13.BorderStyle = fmBorderStyleSingle
    Label15.BorderStyle = fmBorderStyleNone
    Label15.BorderStyle = fmBorderStyleSingle
If Label14.Caption = "Y" Then YOU = "Y"
If Label14.Caption = "Y" Then Label14.ToolTipText = CT14
If Label14.Caption = "Y" Then Label14.ForeColor = F14
If Label14.Caption = "Y" Then Label14.Font.Size = FONT14
If Label14.Caption = "Y" Then Label14.BackColor = BCL14
If Label14.Caption = "Y" Then Label14.Caption = L14

3001:
End Sub
Private Sub Label15_Click()
If YTL = 0 Then GoTo 3002                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3002
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2997
If YOU <> "" Then L15 = Label15.Caption          '��������� �������� ���������
If YOU <> "" Then CT15 = Label15.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F15 = Label15.ForeColor        '��������� ���������
If YOU <> "" Then FONT15 = Label15.Font.Size     '��������� ���������
If YOU <> "" Then BCL15 = Label15.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3502         '����� �������� ���������� "Y"
If NexStepHorisontal(2) = 1 Then GoTo 3502
If NexStepHorisontal(4) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(4) = 0 Then GoTo 3002
3502:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label14.BackColor = 65280        '��������� ������
    Label15.BackColor = 65280        '��������� ������
    Label16.BackColor = 65280        '��������� ������
    Label14.BorderStyle = fmBorderStyleNone
    Label14.BorderStyle = fmBorderStyleSingle
    Label16.BorderStyle = fmBorderStyleNone
    Label16.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 1
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label15.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label15.Caption = "Z" Then Label158.Caption = 0
If Label15.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label15.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label15.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label15.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label15.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label15.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label15.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount



If YOU <> "" Then Label15.Caption = YOU
If YOU <> "" Then Label15.Font.Size = 16
If YOU <> "" Then Label15.ForeColor = 255
If YOU <> "" Then Label15.BackColor = 12648447
If YOU <> "" Then Label15.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3002
2997:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label14.BackColor = -2147483642        '��������� ������
    Label15.BackColor = -2147483642        '��������� ������
    Label16.BackColor = -2147483642        '��������� ������
    Label14.BorderStyle = fmBorderStyleNone
    Label14.BorderStyle = fmBorderStyleSingle
    Label16.BorderStyle = fmBorderStyleNone
    Label16.BorderStyle = fmBorderStyleSingle
If Label15.Caption = "Y" Then YOU = "Y"
If Label15.Caption = "Y" Then Label15.ToolTipText = CT15
If Label15.Caption = "Y" Then Label15.ForeColor = F15
If Label15.Caption = "Y" Then Label15.Font.Size = FONT15
If Label15.Caption = "Y" Then Label15.BackColor = BCL15
If Label15.Caption = "Y" Then Label15.Caption = L15

3002:
End Sub

Private Sub Label16_Click()
If YTL = 0 Then GoTo 3003                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3003
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2996
If YOU <> "" Then L16 = Label16.Caption          '��������� �������� ���������
If YOU <> "" Then CT16 = Label16.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F16 = Label16.ForeColor        '��������� ���������
If YOU <> "" Then FONT16 = Label16.Font.Size     '��������� ���������
If YOU <> "" Then BCL16 = Label16.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3503         '����� �������� ���������� "Y"
If NexStepHorisontal(3) = 1 Then GoTo 3503
If NexStepHorisontal(5) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(5) = 0 Then GoTo 3003
3503:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label15.BackColor = 65280        '��������� ������
    Label16.BackColor = 65280        '��������� ������
    Label17.BackColor = 65280        '��������� ������
    Label15.BorderStyle = fmBorderStyleNone
    Label15.BorderStyle = fmBorderStyleSingle
    Label17.BorderStyle = fmBorderStyleNone
    Label17.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 1
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label16.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label16.Caption = "Z" Then Label158.Caption = 0
If Label16.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label16.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label16.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label16.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label16.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label16.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label16.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label16.Caption = YOU
If YOU <> "" Then Label16.Font.Size = 16
If YOU <> "" Then Label16.ForeColor = 255
If YOU <> "" Then Label16.BackColor = 12648447
If YOU <> "" Then Label16.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3003
2996:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label15.BackColor = -2147483642        '��������� ������
    Label16.BackColor = -2147483642        '��������� ������
    Label17.BackColor = -2147483642        '��������� ������
    Label15.BorderStyle = fmBorderStyleNone
    Label15.BorderStyle = fmBorderStyleSingle
    Label17.BorderStyle = fmBorderStyleNone
    Label17.BorderStyle = fmBorderStyleSingle
If Label16.Caption = "Y" Then YOU = "Y"
If Label16.Caption = "Y" Then Label16.ToolTipText = CT16
If Label16.Caption = "Y" Then Label16.ForeColor = F16
If Label16.Caption = "Y" Then Label16.Font.Size = FONT16
If Label16.Caption = "Y" Then Label16.BackColor = BCL16
If Label16.Caption = "Y" Then Label16.Caption = L16

3003:
End Sub
Private Sub Label17_Click()
If YTL = 0 Then GoTo 3004                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3004
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2995
If YOU <> "" Then L17 = Label17.Caption          '��������� �������� ���������
If YOU <> "" Then CT17 = Label17.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F17 = Label17.ForeColor        '��������� ���������
If YOU <> "" Then FONT17 = Label17.Font.Size     '��������� ���������
If YOU <> "" Then BCL17 = Label17.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3504         '����� �������� ���������� "Y"
If NexStepHorisontal(4) = 1 Then GoTo 3504
If NexStepHorisontal(6) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(6) = 0 Then GoTo 3004
3504:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label16.BackColor = 65280        '��������� ������
    Label17.BackColor = 65280        '��������� ������
    Label18.BackColor = 65280        '��������� ������
    Label16.BorderStyle = fmBorderStyleNone
    Label16.BorderStyle = fmBorderStyleSingle
    Label18.BorderStyle = fmBorderStyleNone
    Label18.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 1
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label17.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label17.Caption = "Z" Then Label158.Caption = 0
If Label17.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label17.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label17.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label17.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label17.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label17.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label17.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label17.Caption = YOU
If YOU <> "" Then Label17.Font.Size = 16
If YOU <> "" Then Label17.ForeColor = 255
If YOU <> "" Then Label17.BackColor = 12648447
If YOU <> "" Then Label17.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3004
2995:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label16.BackColor = -2147483642        '��������� ������
    Label17.BackColor = -2147483642        '��������� ������
    Label18.BackColor = -2147483642        '��������� ������
    Label16.BorderStyle = fmBorderStyleNone
    Label16.BorderStyle = fmBorderStyleSingle
    Label18.BorderStyle = fmBorderStyleNone
    Label18.BorderStyle = fmBorderStyleSingle
If Label17.Caption = "Y" Then YOU = "Y"
If Label17.Caption = "Y" Then Label17.ToolTipText = CT17
If Label17.Caption = "Y" Then Label17.ForeColor = F17
If Label17.Caption = "Y" Then Label17.Font.Size = FONT17
If Label17.Caption = "Y" Then Label17.BackColor = BCL17
If Label17.Caption = "Y" Then Label17.Caption = L17

3004:
End Sub

Private Sub Label18_Click()
If YTL = 0 Then GoTo 3005                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3005
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2994
If YOU <> "" Then L18 = Label18.Caption          '��������� �������� ���������
If YOU <> "" Then CT18 = Label18.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F18 = Label18.ForeColor        '��������� ���������
If YOU <> "" Then FONT18 = Label18.Font.Size     '��������� ���������
If YOU <> "" Then BCL18 = Label18.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3505         '����� �������� ���������� "Y"
If NexStepHorisontal(5) = 1 Then GoTo 3505
If NexStepHorisontal(7) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(7) = 0 Then GoTo 3005
3505:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label17.BackColor = 65280        '��������� ������
    Label18.BackColor = 65280        '��������� ������
    Label19.BackColor = 65280        '��������� ������
    Label17.BorderStyle = fmBorderStyleNone
    Label17.BorderStyle = fmBorderStyleSingle
    Label19.BorderStyle = fmBorderStyleNone
    Label19.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 1
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label18.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label18.Caption = "Z" Then Label158.Caption = 0
If Label18.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label18.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label18.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label18.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label18.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label18.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label18.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label18.Caption = YOU
If YOU <> "" Then Label18.Font.Size = 16
If YOU <> "" Then Label18.ForeColor = 255
If YOU <> "" Then Label18.BackColor = 12648447
If YOU <> "" Then Label18.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3005
2994:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label17.BackColor = -2147483642        '��������� ������
    Label18.BackColor = -2147483642        '��������� ������
    Label19.BackColor = -2147483642        '��������� ������
    Label17.BorderStyle = fmBorderStyleNone
    Label17.BorderStyle = fmBorderStyleSingle
    Label19.BorderStyle = fmBorderStyleNone
    Label19.BorderStyle = fmBorderStyleSingle
If Label18.Caption = "Y" Then YOU = "Y"
If Label18.Caption = "Y" Then Label18.ToolTipText = CT18
If Label18.Caption = "Y" Then Label18.ForeColor = F18
If Label18.Caption = "Y" Then Label18.Font.Size = FONT18
If Label18.Caption = "Y" Then Label18.BackColor = BCL18
If Label18.Caption = "Y" Then Label18.Caption = L18

3005:
End Sub
Private Sub Label19_Click()
If YTL = 0 Then GoTo 3006                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3006
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2993
If YOU <> "" Then L19 = Label19.Caption          '��������� �������� ���������
If YOU <> "" Then CT19 = Label19.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F19 = Label19.ForeColor        '��������� ���������
If YOU <> "" Then FONT19 = Label19.Font.Size     '��������� ���������
If YOU <> "" Then BCL19 = Label19.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3506         '����� �������� ���������� "Y"
If NexStepHorisontal(6) = 1 Then GoTo 3506
If NexStepHorisontal(8) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(8) = 0 Then GoTo 3006
3506:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label18.BackColor = 65280        '��������� ������
    Label19.BackColor = 65280        '��������� ������
    Label20.BackColor = 65280        '��������� ������
    Label18.BorderStyle = fmBorderStyleNone
    Label18.BorderStyle = fmBorderStyleSingle
    Label20.BorderStyle = fmBorderStyleNone
    Label20.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 1
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label19.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label19.Caption = "Z" Then Label158.Caption = 0
If Label19.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label19.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label19.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label19.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label19.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label19.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label19.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label19.Caption = YOU
If YOU <> "" Then Label19.Font.Size = 16
If YOU <> "" Then Label19.ForeColor = 255
If YOU <> "" Then Label19.BackColor = 12648447
If YOU <> "" Then Label19.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3006
2993:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label18.BackColor = -2147483642        '��������� ������
    Label19.BackColor = -2147483642        '��������� ������
    Label20.BackColor = -2147483642        '��������� ������
    Label18.BorderStyle = fmBorderStyleNone
    Label18.BorderStyle = fmBorderStyleSingle
    Label20.BorderStyle = fmBorderStyleNone
    Label20.BorderStyle = fmBorderStyleSingle
If Label19.Caption = "Y" Then YOU = "Y"
If Label19.Caption = "Y" Then Label19.ToolTipText = CT19
If Label19.Caption = "Y" Then Label19.ForeColor = F19
If Label19.Caption = "Y" Then Label19.Font.Size = FONT19
If Label19.Caption = "Y" Then Label19.BackColor = BCL19
If Label19.Caption = "Y" Then Label19.Caption = L19

3006:
End Sub

Private Sub Label20_Click()
If YTL = 0 Then GoTo 3007                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3007
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2992
If YOU <> "" Then L20 = Label20.Caption          '��������� �������� ���������
If YOU <> "" Then CT20 = Label20.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F20 = Label20.ForeColor        '��������� ���������
If YOU <> "" Then FONT20 = Label20.Font.Size     '��������� ���������
If YOU <> "" Then BCL20 = Label20.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3507         '����� �������� ���������� "Y"
If NexStepHorisontal(7) = 1 Then GoTo 3507
If NexStepHorisontal(9) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(9) = 0 Then GoTo 3007
3507:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label19.BackColor = 65280        '��������� ������
    Label20.BackColor = 65280        '��������� ������
    Label21.BackColor = 65280        '��������� ������
    Label19.BorderStyle = fmBorderStyleNone
    Label19.BorderStyle = fmBorderStyleSingle
    Label21.BorderStyle = fmBorderStyleNone
    Label21.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 1
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label20.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label20.Caption = "Z" Then Label158.Caption = 0
If Label20.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label20.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label20.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label20.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label20.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label20.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label20.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label20.Caption = YOU
If YOU <> "" Then Label20.Font.Size = 16
If YOU <> "" Then Label20.ForeColor = 255
If YOU <> "" Then Label20.BackColor = 12648447
If YOU <> "" Then Label20.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3007
2992:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label19.BackColor = -2147483642        '��������� ������
    Label20.BackColor = -2147483642        '��������� ������
    Label21.BackColor = -2147483642        '��������� ������
    Label19.BorderStyle = fmBorderStyleNone
    Label19.BorderStyle = fmBorderStyleSingle
    Label21.BorderStyle = fmBorderStyleNone
    Label21.BorderStyle = fmBorderStyleSingle
If Label20.Caption = "Y" Then YOU = "Y"
If Label20.Caption = "Y" Then Label20.ToolTipText = CT20
If Label20.Caption = "Y" Then Label20.ForeColor = F20
If Label20.Caption = "Y" Then Label20.Font.Size = FONT20
If Label20.Caption = "Y" Then Label20.BackColor = BCL20
If Label20.Caption = "Y" Then Label20.Caption = L20

3007:
End Sub
Private Sub Label21_Click()
If YTL = 0 Then GoTo 3008                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3008
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2991
If YOU <> "" Then L21 = Label21.Caption          '��������� �������� ���������
If YOU <> "" Then CT21 = Label21.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F21 = Label21.ForeColor        '��������� ���������
If YOU <> "" Then FONT21 = Label21.Font.Size     '��������� ���������
If YOU <> "" Then BCL21 = Label21.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3508         '����� �������� ���������� "Y"
If NexStepHorisontal(8) = 1 Then GoTo 3508
If NexStepHorisontal(10) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(10) = 0 Then GoTo 3008
3508:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label20.BackColor = 65280        '��������� ������
    Label21.BackColor = 65280        '��������� ������
    Label22.BackColor = 65280        '��������� ������
    Label20.BorderStyle = fmBorderStyleNone
    Label20.BorderStyle = fmBorderStyleSingle
    Label22.BorderStyle = fmBorderStyleNone
    Label22.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 1
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label21.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label21.Caption = "Z" Then Label158.Caption = 0
If Label21.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label21.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label21.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label21.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label21.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label21.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label21.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label21.Caption = YOU
If YOU <> "" Then Label21.Font.Size = 16
If YOU <> "" Then Label21.ForeColor = 255
If YOU <> "" Then Label21.BackColor = 12648447
If YOU <> "" Then Label21.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3008
2991:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label20.BackColor = -2147483642        '��������� ������
    Label21.BackColor = -2147483642        '��������� ������
    Label22.BackColor = -2147483642        '��������� ������
    Label20.BorderStyle = fmBorderStyleNone
    Label20.BorderStyle = fmBorderStyleSingle
    Label22.BorderStyle = fmBorderStyleNone
    Label22.BorderStyle = fmBorderStyleSingle
If Label21.Caption = "Y" Then YOU = "Y"
If Label21.Caption = "Y" Then Label21.ToolTipText = CT21
If Label21.Caption = "Y" Then Label21.ForeColor = F21
If Label21.Caption = "Y" Then Label21.Font.Size = FONT21
If Label21.Caption = "Y" Then Label21.BackColor = BCL21
If Label21.Caption = "Y" Then Label21.Caption = L21

3008:
End Sub
Private Sub Label22_Click()
If YTL = 0 Then GoTo 3009                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3009
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2990
If YOU <> "" Then L22 = Label22.Caption          '��������� �������� ���������
If YOU <> "" Then CT22 = Label22.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F22 = Label22.ForeColor        '��������� ���������
If YOU <> "" Then FONT22 = Label22.Font.Size     '��������� ���������
If YOU <> "" Then BCL22 = Label22.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3509         '����� �������� ���������� "Y"
If NexStepHorisontal(9) = 1 Then GoTo 3509
If NexStepHorisontal(11) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(11) = 0 Then GoTo 3009
3509:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label21.BackColor = 65280        '��������� ������
    Label22.BackColor = 65280        '��������� ������
    Label23.BackColor = 65280        '��������� ������
    Label21.BorderStyle = fmBorderStyleNone
    Label21.BorderStyle = fmBorderStyleSingle
    Label23.BorderStyle = fmBorderStyleNone
    Label23.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 1
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label22.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label22.Caption = "Z" Then Label158.Caption = 0
If Label22.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label22.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label22.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label22.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label22.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label22.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label22.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount

If YOU <> "" Then Label22.Caption = YOU
If YOU <> "" Then Label22.Font.Size = 16
If YOU <> "" Then Label22.ForeColor = 255
If YOU <> "" Then Label22.BackColor = 12648447
If YOU <> "" Then Label22.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3009
2990:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label21.BackColor = -2147483642        '��������� ������
    Label22.BackColor = -2147483642        '��������� ������
    Label23.BackColor = -2147483642        '��������� ������
    Label21.BorderStyle = fmBorderStyleNone
    Label21.BorderStyle = fmBorderStyleSingle
    Label23.BorderStyle = fmBorderStyleNone
    Label23.BorderStyle = fmBorderStyleSingle
If Label22.Caption = "Y" Then YOU = "Y"
If Label22.Caption = "Y" Then Label22.ToolTipText = CT22
If Label22.Caption = "Y" Then Label22.ForeColor = F22
If Label22.Caption = "Y" Then Label22.Font.Size = FONT22
If Label22.Caption = "Y" Then Label22.BackColor = BCL22
If Label22.Caption = "Y" Then Label22.Caption = L22

3009:
End Sub
Private Sub Label23_Click()
If YTL = 0 Then GoTo 3010                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3010
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2989
If YOU <> "" Then L23 = Label23.Caption          '��������� �������� ���������
If YOU <> "" Then CT23 = Label23.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F23 = Label23.ForeColor        '��������� ���������
If YOU <> "" Then FONT23 = Label23.Font.Size     '��������� ���������
If YOU <> "" Then BCL23 = Label23.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3510         '����� �������� ���������� "Y"
If NexStepHorisontal(10) = 1 Then GoTo 3510
If NexStepHorisontal(12) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(12) = 0 Then GoTo 3010
3510:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label22.BackColor = 65280        '��������� ������
    Label23.BackColor = 65280        '��������� ������
    Label24.BackColor = 65280        '��������� ������
    Label22.BorderStyle = fmBorderStyleNone
    Label22.BorderStyle = fmBorderStyleSingle
    Label24.BorderStyle = fmBorderStyleNone
    Label24.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 1
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label23.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label23.Caption = "Z" Then Label158.Caption = 0
If Label23.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label23.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label23.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label23.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label23.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label23.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label23.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label23.Caption = YOU
If YOU <> "" Then Label23.Font.Size = 16
If YOU <> "" Then Label23.ForeColor = 255
If YOU <> "" Then Label23.BackColor = 12648447
If YOU <> "" Then Label23.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3010
2989:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label22.BackColor = -2147483642        '��������� ������
    Label23.BackColor = -2147483642        '��������� ������
    Label24.BackColor = -2147483642        '��������� ������
    Label22.BorderStyle = fmBorderStyleNone
    Label22.BorderStyle = fmBorderStyleSingle
    Label24.BorderStyle = fmBorderStyleNone
    Label24.BorderStyle = fmBorderStyleSingle
If Label23.Caption = "Y" Then YOU = "Y"
If Label23.Caption = "Y" Then Label23.ToolTipText = CT23
If Label23.Caption = "Y" Then Label23.ForeColor = F23
If Label23.Caption = "Y" Then Label23.Font.Size = FONT23
If Label23.Caption = "Y" Then Label23.BackColor = BCL23
If Label23.Caption = "Y" Then Label23.Caption = L23

3010:
End Sub
Private Sub Label24_Click()
If YTL = 0 Then GoTo 3011                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3011
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2988
If YOU <> "" Then L24 = Label24.Caption          '��������� �������� ���������
If YOU <> "" Then CT24 = Label24.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F24 = Label24.ForeColor        '��������� ���������
If YOU <> "" Then FONT24 = Label24.Font.Size     '��������� ���������
If YOU <> "" Then BCL24 = Label24.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 3511         '����� �������� ���������� "Y"
If NexStepHorisontal(11) = 1 Then GoTo 3511
If NexStepHorisontal(13) = 0 Then Beep       '���� ������� "Y" �� � ��������� �������
If NexStepHorisontal(13) = 0 Then GoTo 3011
3511:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label23.BackColor = 65280        '��������� ������
    Label24.BackColor = 65280        '��������� ������
    Label25.BackColor = 65280        '��������� ������
    Label23.BorderStyle = fmBorderStyleNone
    Label23.BorderStyle = fmBorderStyleSingle
    Label25.BorderStyle = fmBorderStyleNone
    Label25.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 1
NexStepHorisontal(13) = 0
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label24.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label24.Caption = "Z" Then Label158.Caption = 0
If Label24.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label24.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label24.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label24.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label24.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label24.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label24.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label24.Caption = YOU
If YOU <> "" Then Label24.Font.Size = 16
If YOU <> "" Then Label24.ForeColor = 255
If YOU <> "" Then Label24.BackColor = 12648447
If YOU <> "" Then Label24.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3011
2988:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label23.BackColor = -2147483642        '��������� ������
    Label24.BackColor = -2147483642        '��������� ������
    Label25.BackColor = -2147483642        '��������� ������
    Label23.BorderStyle = fmBorderStyleNone
    Label23.BorderStyle = fmBorderStyleSingle
    Label25.BorderStyle = fmBorderStyleNone
    Label25.BorderStyle = fmBorderStyleSingle
If Label24.Caption = "Y" Then YOU = "Y"
If Label24.Caption = "Y" Then Label24.ToolTipText = CT24
If Label24.Caption = "Y" Then Label24.ForeColor = F24
If Label24.Caption = "Y" Then Label24.Font.Size = FONT24
If Label24.Caption = "Y" Then Label24.BackColor = BCL24
If Label24.Caption = "Y" Then Label24.Caption = L24

3011:
End Sub
Private Sub Label25_Click()
If YTL = 0 Then GoTo 3012                        ' "Y" - ��� �����?
If ThreeTrigger = 0 Then GoTo 3012
ThreeTrigger = ThreeTrigger - 1
Label157.Caption = ThreeTrigger                  '������� ����������� ���������
'''''Form1.Caption = ThreeTrigger

If YOU = "" Then GoTo 2987
If YOU <> "" Then L25 = Label25.Caption          '��������� �������� ���������
If YOU <> "" Then CT25 = Label25.ToolTipText  '��������� �������� ���������
If YOU <> "" Then F25 = Label25.ForeColor        '��������� ���������
If YOU <> "" Then FONT25 = Label25.Font.Size     '��������� ���������
If YOU <> "" Then BCL25 = Label25.BackColor      '��������� ���������

'�������� ����� ��������� (�������� "Y")
If NextStepTrig = 0 Then GoTo 14001         '����� �������� ���������� "Y"
If NexStepHorisontal(12) = 0 Then GoTo 3012  '���� ������� "Y" �� � ��������� �������
14001:
GeneralTrig = 0                  ' "Y" ������, ����� �������� ��������� �������
    Label24.BackColor = 65280        '��������� ������
    Label25.BackColor = 65280        '��������� ������
    Label24.BorderStyle = fmBorderStyleNone
    Label24.BorderStyle = fmBorderStyleSingle
NexStepHorisontal(1) = 0
NexStepHorisontal(2) = 0
NexStepHorisontal(3) = 0
NexStepHorisontal(4) = 0
NexStepHorisontal(5) = 0
NexStepHorisontal(6) = 0
NexStepHorisontal(7) = 0
NexStepHorisontal(8) = 0
NexStepHorisontal(9) = 0
NexStepHorisontal(10) = 0
NexStepHorisontal(11) = 0
NexStepHorisontal(12) = 0
NexStepHorisontal(13) = 1
NextStepTrig = 1             '������ �������� ���������� "Y"
If Label25.Caption = "(-)" Then Label158.Caption = Label158.Caption - Int((500 * Rnd) + 1)
If Label25.Caption = "Z" Then Label158.Caption = 0
If Label25.Caption = "-1" Then Label158.Caption = Label158.Caption - 1
If Label25.Caption = "-10" Then Label158.Caption = Label158.Caption - 10
If Label25.Caption = "+15" Then Label158.Caption = Label158.Caption + 15
If Label25.Caption = "+1" Then Label158.Caption = Label158.Caption + 1
If Label25.Caption = "-5" Then Label158.Caption = Label158.Caption - 5
If Label25.Caption = "+5" Then Label158.Caption = Label158.Caption + 5
If Label25.Caption = "B" Then Label158.Caption = Label158.Caption + BombCount


If YOU <> "" Then Label25.Caption = YOU
If YOU <> "" Then Label25.Font.Size = 16
If YOU <> "" Then Label25.ForeColor = 255
If YOU <> "" Then Label25.BackColor = 12648447
If YOU <> "" Then Label25.ToolTipText = Label157.ToolTipText
If YOU <> "" Then YOU = ""
GoTo 3012
2987:             '������ "Y" �� Label
GeneralTrig = 1   '��������� �������� ������ �������
    Label24.BackColor = -2147483642        '��������� ������
    Label25.BackColor = -2147483642        '��������� ������
    Label24.BorderStyle = fmBorderStyleNone
    Label24.BorderStyle = fmBorderStyleSingle
If Label25.Caption = "Y" Then YOU = "Y"
If Label25.Caption = "Y" Then Label25.ToolTipText = CT25
If Label25.Caption = "Y" Then Label25.ForeColor = F25
If Label25.Caption = "Y" Then Label25.Font.Size = FONT25
If Label25.Caption = "Y" Then Label25.BackColor = BCL25
If Label25.Caption = "Y" Then Label25.Caption = L25

3012:
End Sub

Private Sub Label157_Click()

If YTL = 1 Then GoTo 4000
YOU = Label157.Caption
Label157.Caption = ""
YTL = 1
4000:
End Sub
Private Sub LabelHid()
'�������� ������� ������
If Label161.Caption >= 1 Then Label143.Visible = False
If Label161.Caption >= 1 Then Label144.Visible = False
If Label161.Caption >= 1 Then Label145.Visible = False
If Label161.Caption >= 1 Then Label146.Visible = False
If Label161.Caption >= 1 Then Label147.Visible = False
If Label161.Caption >= 1 Then Label148.Visible = False
If Label161.Caption >= 1 Then Label149.Visible = False
If Label161.Caption >= 1 Then Label150.Visible = False
If Label161.Caption >= 1 Then Label151.Visible = False
If Label161.Caption >= 1 Then Label152.Visible = False
If Label161.Caption >= 1 Then Label153.Visible = False
If Label161.Caption >= 1 Then Label154.Visible = False
If Label161.Caption >= 1 Then Label155.Visible = False

If Label161.Caption >= 2 Then Label130.Visible = False
If Label161.Caption >= 2 Then Label131.Visible = False
If Label161.Caption >= 2 Then Label132.Visible = False
If Label161.Caption >= 2 Then Label133.Visible = False
If Label161.Caption >= 2 Then Label134.Visible = False
If Label161.Caption >= 2 Then Label135.Visible = False
If Label161.Caption >= 2 Then Label136.Visible = False
If Label161.Caption >= 2 Then Label137.Visible = False
If Label161.Caption >= 2 Then Label138.Visible = False
If Label161.Caption >= 2 Then Label139.Visible = False
If Label161.Caption >= 2 Then Label140.Visible = False
If Label161.Caption >= 2 Then Label141.Visible = False
If Label161.Caption >= 2 Then Label142.Visible = False

If Label161.Caption >= 3 Then Label117.Visible = False
If Label161.Caption >= 3 Then Label118.Visible = False
If Label161.Caption >= 3 Then Label119.Visible = False
If Label161.Caption >= 3 Then Label120.Visible = False
If Label161.Caption >= 3 Then Label121.Visible = False
If Label161.Caption >= 3 Then Label122.Visible = False
If Label161.Caption >= 3 Then Label123.Visible = False
If Label161.Caption >= 3 Then Label124.Visible = False
If Label161.Caption >= 3 Then Label125.Visible = False
If Label161.Caption >= 3 Then Label126.Visible = False
If Label161.Caption >= 3 Then Label127.Visible = False
If Label161.Caption >= 3 Then Label128.Visible = False
If Label161.Caption >= 3 Then Label129.Visible = False

If Label161.Caption >= 4 Then Label104.Visible = False
If Label161.Caption >= 4 Then Label105.Visible = False
If Label161.Caption >= 4 Then Label106.Visible = False
If Label161.Caption >= 4 Then Label107.Visible = False
If Label161.Caption >= 4 Then Label108.Visible = False
If Label161.Caption >= 4 Then Label109.Visible = False
If Label161.Caption >= 4 Then Label110.Visible = False
If Label161.Caption >= 4 Then Label111.Visible = False
If Label161.Caption >= 4 Then Label112.Visible = False
If Label161.Caption >= 4 Then Label113.Visible = False
If Label161.Caption >= 4 Then Label114.Visible = False
If Label161.Caption >= 4 Then Label115.Visible = False
If Label161.Caption >= 4 Then Label116.Visible = False

If Label161.Caption >= 5 Then Label91.Visible = False
If Label161.Caption >= 5 Then Label92.Visible = False
If Label161.Caption >= 5 Then Label93.Visible = False
If Label161.Caption >= 5 Then Label94.Visible = False
If Label161.Caption >= 5 Then Label95.Visible = False
If Label161.Caption >= 5 Then Label96.Visible = False
If Label161.Caption >= 5 Then Label97.Visible = False
If Label161.Caption >= 5 Then Label98.Visible = False
If Label161.Caption >= 5 Then Label99.Visible = False
If Label161.Caption >= 5 Then Label100.Visible = False
If Label161.Caption >= 5 Then Label101.Visible = False
If Label161.Caption >= 5 Then Label102.Visible = False
If Label161.Caption >= 5 Then Label103.Visible = False

If Label161.Caption >= 6 Then Label78.Visible = False
If Label161.Caption >= 6 Then Label79.Visible = False
If Label161.Caption >= 6 Then Label80.Visible = False
If Label161.Caption >= 6 Then Label81.Visible = False
If Label161.Caption >= 6 Then Label82.Visible = False
If Label161.Caption >= 6 Then Label83.Visible = False
If Label161.Caption >= 6 Then Label84.Visible = False
If Label161.Caption >= 6 Then Label85.Visible = False
If Label161.Caption >= 6 Then Label86.Visible = False
If Label161.Caption >= 6 Then Label87.Visible = False
If Label161.Caption >= 6 Then Label88.Visible = False
If Label161.Caption >= 6 Then Label89.Visible = False
If Label161.Caption >= 6 Then Label90.Visible = False

If Label161.Caption >= 7 Then Label65.Visible = False
If Label161.Caption >= 7 Then Label66.Visible = False
If Label161.Caption >= 7 Then Label67.Visible = False
If Label161.Caption >= 7 Then Label68.Visible = False
If Label161.Caption >= 7 Then Label69.Visible = False
If Label161.Caption >= 7 Then Label70.Visible = False
If Label161.Caption >= 7 Then Label71.Visible = False
If Label161.Caption >= 7 Then Label72.Visible = False
If Label161.Caption >= 7 Then Label73.Visible = False
If Label161.Caption >= 7 Then Label74.Visible = False
If Label161.Caption >= 7 Then Label75.Visible = False
If Label161.Caption >= 7 Then Label76.Visible = False
If Label161.Caption >= 7 Then Label77.Visible = False

If Label161.Caption >= 8 Then Label52.Visible = False
If Label161.Caption >= 8 Then Label53.Visible = False
If Label161.Caption >= 8 Then Label54.Visible = False
If Label161.Caption >= 8 Then Label55.Visible = False
If Label161.Caption >= 8 Then Label56.Visible = False
If Label161.Caption >= 8 Then Label57.Visible = False
If Label161.Caption >= 8 Then Label58.Visible = False
If Label161.Caption >= 8 Then Label59.Visible = False
If Label161.Caption >= 8 Then Label60.Visible = False
If Label161.Caption >= 8 Then Label61.Visible = False
If Label161.Caption >= 8 Then Label62.Visible = False
If Label161.Caption >= 8 Then Label63.Visible = False
If Label161.Caption >= 8 Then Label64.Visible = False


End Sub
Private Sub VisibleLabel()
Label52.Visible = True
Label53.Visible = True
Label54.Visible = True
Label55.Visible = True
Label56.Visible = True
Label57.Visible = True
Label58.Visible = True
Label59.Visible = True
Label60.Visible = True
Label61.Visible = True
Label62.Visible = True
Label63.Visible = True
Label64.Visible = True
Label65.Visible = True
Label66.Visible = True
Label67.Visible = True
Label68.Visible = True
Label69.Visible = True
Label70.Visible = True
Label71.Visible = True
Label72.Visible = True
Label73.Visible = True
Label74.Visible = True
Label75.Visible = True
Label76.Visible = True
Label77.Visible = True
Label78.Visible = True
Label79.Visible = True
Label80.Visible = True
Label81.Visible = True
Label82.Visible = True
Label83.Visible = True
Label84.Visible = True
Label85.Visible = True
Label86.Visible = True
Label87.Visible = True
Label88.Visible = True
Label89.Visible = True
Label90.Visible = True
Label91.Visible = True
Label92.Visible = True
Label93.Visible = True
Label94.Visible = True
Label95.Visible = True
Label96.Visible = True
Label97.Visible = True
Label98.Visible = True
Label99.Visible = True
Label100.Visible = True
Label101.Visible = True
Label102.Visible = True
Label103.Visible = True
Label104.Visible = True
Label105.Visible = True
Label106.Visible = True
Label107.Visible = True
Label108.Visible = True
Label109.Visible = True
Label110.Visible = True
Label111.Visible = True
Label112.Visible = True
Label113.Visible = True
Label114.Visible = True
Label115.Visible = True
Label116.Visible = True
Label117.Visible = True
Label118.Visible = True
Label119.Visible = True
Label120.Visible = True
Label121.Visible = True
Label122.Visible = True
Label123.Visible = True
Label124.Visible = True
Label125.Visible = True
Label126.Visible = True
Label127.Visible = True
Label128.Visible = True
Label129.Visible = True
Label130.Visible = True
Label131.Visible = True
Label132.Visible = True
Label133.Visible = True
Label134.Visible = True
Label135.Visible = True
Label136.Visible = True
Label137.Visible = True
Label138.Visible = True
Label139.Visible = True
Label140.Visible = True
Label141.Visible = True
Label142.Visible = True
Label143.Visible = True
Label144.Visible = True
Label145.Visible = True
Label146.Visible = True
Label147.Visible = True
Label148.Visible = True
Label149.Visible = True
Label150.Visible = True
Label151.Visible = True
Label152.Visible = True
Label153.Visible = True
Label154.Visible = True
Label155.Visible = True

End Sub
Private Sub Algorythm()
'��������������� ����
'����������� �������� ������

'���� Account ����������� �� �������� ����� -800, �� ���� ������ (credit) � ��������� Rate �� 0,05
If Label158.Caption <= -800 Then Label158.Caption = Label158.Caption + credit
If Label158.Caption <= -800 Then CreditON = 1  '���� ������
If CreditON = 1 Then Rate = Rate + 0.05     '���� ������ �����, ��������� ������
If CreditON = 1 Then CreditON = 0           '�������� ������� ������� ����� ���������� ������
If Label158.Caption <= -800 Then Label170.Caption = Label170.Caption + 0.05
If Label158.Caption <= -800 Then Label172.Caption = "You have a credit"

'���� Account ��������� 3000, �� ��������� RND-Rate
If Label158.Caption > 3000 Then CTREE = 4   '�������� ��� ����������/���������� ������
If Label158.Caption < 3000 Then CTREE = 3   '�������� ��� ����������/���������� ������

End Sub
Private Sub Form_Activate()
CTREE = 3                            '�������� ��� ������ �������
ThreeTrigger = 5                     '������� ��� 3-� ����������� "Y"
GeneralTrig = 1                      '�������� �������, ������ ����� ������ "Y"
CreditON = 0                         '������ �� �����
TM = Time
TTM = Mid$(TM, 7, 1)
TTMS = Mid$(TM, 8, 1)
On Error GoTo 6500
TLL = Asc(TTM) * 10 + Asc(TTMS) - 528
GoTo 6505
6500:
TLL = Asc(TTM) * 10 - 528
6505:
For mk = 0 To TLL
    ol = Rnd(256)
Next




Label161.Caption = Int((8 * Rnd) + 1)           '���������� ���������� �������
LabelHid                       '�������� ������� ������
NextStepTrig = 0               '��������� �������� ���������� "Y"
Label2.Caption = 11
YTL = 0                        '������� - ���� �� "Y"
ELEMENT_NUM = 10 '���������� ��������� RND ���������



counter = Int((7700 * Rnd) + 1)
Label158.Caption = counter       '���������� ����� �� �����
Form_Click
End Sub
Private Sub RND_NEXT()
ii = Int((ELEMENT_NUM * Rnd) + 1)
End Sub
Private Sub Form_Click()
FNT_SIZE

RND_NEXT
If ii = 1 Then Label13.Caption = "-5"
If ii = 2 Then Label13.Caption = "+5"
If ii = 3 Then Label13.Caption = "-10"
If ii = 4 Then Label13.Caption = "+15"
If ii = 5 Then Label13.Caption = "Z"
If ii = 6 Then Label13.Caption = "+1"
If ii = 7 Then Label13.Caption = "B"
If ii = 8 Then Label13.Caption = "Z"
If ii = 9 Then Label13.Caption = "-1"
If ii = 10 Then Label13.Caption = "(-)"
If ii = 1 Then Label13.ToolTipText = "Decrease 5$"
If ii = 2 Then Label13.ToolTipText = "Increase 5$"
If ii = 3 Then Label13.ToolTipText = "Decrease 10$"
If ii = 4 Then Label13.ToolTipText = "Increase 15$"
If ii = 5 Then Label13.ToolTipText = "Zero Counter"
If ii = 6 Then Label13.ToolTipText = "Increase 1$"
If ii = 7 Then Label13.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label13.ToolTipText = "Zero Counter"
If ii = 9 Then Label13.ToolTipText = "Decrease 1$"
If ii = 10 Then Label13.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label14.Caption = "-5"
If ii = 2 Then Label14.Caption = "+5"
If ii = 3 Then Label14.Caption = "-10"
If ii = 4 Then Label14.Caption = "+15"
If ii = 5 Then Label14.Caption = "Z"
If ii = 6 Then Label14.Caption = "+1"
If ii = 7 Then Label14.Caption = "B"
If ii = 8 Then Label14.Caption = "Z"
If ii = 9 Then Label14.Caption = "-1"
If ii = 10 Then Label14.Caption = "(-)"
If ii = 1 Then Label14.ToolTipText = "Decrease 5$"
If ii = 2 Then Label14.ToolTipText = "Increase 5$"
If ii = 3 Then Label14.ToolTipText = "Decrease 10$"
If ii = 4 Then Label14.ToolTipText = "Increase 15$"
If ii = 5 Then Label14.ToolTipText = "Zero Counter"
If ii = 6 Then Label14.ToolTipText = "Increase 1$"
If ii = 7 Then Label14.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label14.ToolTipText = "Zero Counter"
If ii = 9 Then Label14.ToolTipText = "Decrease 1$"
If ii = 10 Then Label14.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label15.Caption = "-5"
If ii = 2 Then Label15.Caption = "+5"
If ii = 3 Then Label15.Caption = "-10"
If ii = 4 Then Label15.Caption = "+15"
If ii = 5 Then Label15.Caption = "Z"
If ii = 6 Then Label15.Caption = "+1"
If ii = 7 Then Label15.Caption = "B"
If ii = 8 Then Label15.Caption = "Z"
If ii = 9 Then Label15.Caption = "-1"
If ii = 10 Then Label15.Caption = "(-)"
If ii = 1 Then Label15.ToolTipText = "Decrease 5$"
If ii = 2 Then Label15.ToolTipText = "Increase 5$"
If ii = 3 Then Label15.ToolTipText = "Decrease 10$"
If ii = 4 Then Label15.ToolTipText = "Increase 15$"
If ii = 5 Then Label15.ToolTipText = "Zero Counter"
If ii = 6 Then Label15.ToolTipText = "Increase 1$"
If ii = 7 Then Label15.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label15.ToolTipText = "Zero Counter"
If ii = 9 Then Label15.ToolTipText = "Decrease 1$"
If ii = 10 Then Label15.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label16.Caption = "-5"
If ii = 2 Then Label16.Caption = "+5"
If ii = 3 Then Label16.Caption = "-10"
If ii = 4 Then Label16.Caption = "+15"
If ii = 5 Then Label16.Caption = "Z"
If ii = 6 Then Label16.Caption = "+1"
If ii = 7 Then Label16.Caption = "B"
If ii = 8 Then Label16.Caption = "Z"
If ii = 9 Then Label16.Caption = "-1"
If ii = 10 Then Label16.Caption = "(-)"
If ii = 1 Then Label16.ToolTipText = "Decrease 5$"
If ii = 2 Then Label16.ToolTipText = "Increase 5$"
If ii = 3 Then Label16.ToolTipText = "Decrease 10$"
If ii = 4 Then Label16.ToolTipText = "Increase 15$"
If ii = 5 Then Label16.ToolTipText = "Zero Counter"
If ii = 6 Then Label16.ToolTipText = "Increase 1$"
If ii = 7 Then Label16.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label16.ToolTipText = "Zero Counter"
If ii = 9 Then Label16.ToolTipText = "Decrease 1$"
If ii = 10 Then Label16.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label17.Caption = "-5"
If ii = 2 Then Label17.Caption = "+5"
If ii = 3 Then Label17.Caption = "-10"
If ii = 4 Then Label17.Caption = "+15"
If ii = 5 Then Label17.Caption = "Z"
If ii = 6 Then Label17.Caption = "+1"
If ii = 7 Then Label17.Caption = "B"
If ii = 8 Then Label17.Caption = "Z"
If ii = 9 Then Label17.Caption = "-1"
If ii = 10 Then Label17.Caption = "(-)"
If ii = 1 Then Label17.ToolTipText = "Decrease 5$"
If ii = 2 Then Label17.ToolTipText = "Increase 5$"
If ii = 3 Then Label17.ToolTipText = "Decrease 10$"
If ii = 4 Then Label17.ToolTipText = "Increase 15$"
If ii = 5 Then Label17.ToolTipText = "Zero Counter"
If ii = 6 Then Label17.ToolTipText = "Increase 1$"
If ii = 7 Then Label17.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label17.ToolTipText = "Zero Counter"
If ii = 9 Then Label17.ToolTipText = "Decrease 1$"
If ii = 10 Then Label17.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label18.Caption = "-5"
If ii = 2 Then Label18.Caption = "+5"
If ii = 3 Then Label18.Caption = "-10"
If ii = 4 Then Label18.Caption = "+15"
If ii = 5 Then Label18.Caption = "Z"
If ii = 6 Then Label18.Caption = "+1"
If ii = 7 Then Label18.Caption = "B"
If ii = 8 Then Label18.Caption = "Z"
If ii = 9 Then Label18.Caption = "-1"
If ii = 10 Then Label18.Caption = "(-)"
If ii = 1 Then Label18.ToolTipText = "Decrease 5$"
If ii = 2 Then Label18.ToolTipText = "Increase 5$"
If ii = 3 Then Label18.ToolTipText = "Decrease 10$"
If ii = 4 Then Label18.ToolTipText = "Increase 15$"
If ii = 5 Then Label18.ToolTipText = "Zero Counter"
If ii = 6 Then Label18.ToolTipText = "Increase 1$"
If ii = 7 Then Label18.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label18.ToolTipText = "Zero Counter"
If ii = 9 Then Label18.ToolTipText = "Decrease 1$"
If ii = 10 Then Label18.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label19.Caption = "-5"
If ii = 2 Then Label19.Caption = "+5"
If ii = 3 Then Label19.Caption = "-10"
If ii = 4 Then Label19.Caption = "+15"
If ii = 5 Then Label19.Caption = "Z"
If ii = 6 Then Label19.Caption = "+1"
If ii = 7 Then Label19.Caption = "B"
If ii = 8 Then Label19.Caption = "Z"
If ii = 9 Then Label19.Caption = "-1"
If ii = 10 Then Label19.Caption = "(-)"
If ii = 1 Then Label19.ToolTipText = "Decrease 5$"
If ii = 2 Then Label19.ToolTipText = "Increase 5$"
If ii = 3 Then Label19.ToolTipText = "Decrease 10$"
If ii = 4 Then Label19.ToolTipText = "Increase 15$"
If ii = 5 Then Label19.ToolTipText = "Zero Counter"
If ii = 6 Then Label19.ToolTipText = "Increase 1$"
If ii = 7 Then Label19.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label19.ToolTipText = "Zero Counter"
If ii = 9 Then Label19.ToolTipText = "Decrease 1$"
If ii = 10 Then Label19.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label20.Caption = "-5"
If ii = 2 Then Label20.Caption = "+5"
If ii = 3 Then Label20.Caption = "-10"
If ii = 4 Then Label20.Caption = "+15"
If ii = 5 Then Label20.Caption = "Z"
If ii = 6 Then Label20.Caption = "+1"
If ii = 7 Then Label20.Caption = "B"
If ii = 8 Then Label20.Caption = "Z"
If ii = 9 Then Label20.Caption = "-1"
If ii = 10 Then Label20.Caption = "(-)"
If ii = 1 Then Label20.ToolTipText = "Decrease 5$"
If ii = 2 Then Label20.ToolTipText = "Increase 5$"
If ii = 3 Then Label20.ToolTipText = "Decrease 10$"
If ii = 4 Then Label20.ToolTipText = "Increase 15$"
If ii = 5 Then Label20.ToolTipText = "Zero Counter"
If ii = 6 Then Label20.ToolTipText = "Increase 1$"
If ii = 7 Then Label20.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label20.ToolTipText = "Zero Counter"
If ii = 9 Then Label20.ToolTipText = "Decrease 1$"
If ii = 10 Then Label20.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label21.Caption = "-5"
If ii = 2 Then Label21.Caption = "+5"
If ii = 3 Then Label21.Caption = "-10"
If ii = 4 Then Label21.Caption = "+15"
If ii = 5 Then Label21.Caption = "Z"
If ii = 6 Then Label21.Caption = "+1"
If ii = 7 Then Label21.Caption = "B"
If ii = 8 Then Label21.Caption = "Z"
If ii = 9 Then Label21.Caption = "-1"
If ii = 10 Then Label21.Caption = "(-)"
If ii = 1 Then Label21.ToolTipText = "Decrease 5$"
If ii = 2 Then Label21.ToolTipText = "Increase 5$"
If ii = 3 Then Label21.ToolTipText = "Decrease 10$"
If ii = 4 Then Label21.ToolTipText = "Increase 15$"
If ii = 5 Then Label21.ToolTipText = "Zero Counter"
If ii = 6 Then Label21.ToolTipText = "Increase 1$"
If ii = 7 Then Label21.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label21.ToolTipText = "Zero Counter"
If ii = 9 Then Label21.ToolTipText = "Decrease 1$"
If ii = 10 Then Label21.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label22.Caption = "-5"
If ii = 2 Then Label22.Caption = "+5"
If ii = 3 Then Label22.Caption = "-10"
If ii = 4 Then Label22.Caption = "+15"
If ii = 5 Then Label22.Caption = "Z"
If ii = 6 Then Label22.Caption = "+1"
If ii = 7 Then Label22.Caption = "B"
If ii = 8 Then Label22.Caption = "Z"
If ii = 9 Then Label22.Caption = "-1"
If ii = 10 Then Label22.Caption = "(-)"
If ii = 1 Then Label22.ToolTipText = "Decrease 5$"
If ii = 2 Then Label22.ToolTipText = "Increase 5$"
If ii = 3 Then Label22.ToolTipText = "Decrease 10$"
If ii = 4 Then Label22.ToolTipText = "Increase 15$"
If ii = 5 Then Label22.ToolTipText = "Zero Counter"
If ii = 6 Then Label22.ToolTipText = "Increase 1$"
If ii = 7 Then Label22.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label22.ToolTipText = "Zero Counter"
If ii = 9 Then Label22.ToolTipText = "Decrease 1$"
If ii = 10 Then Label22.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label23.Caption = "-5"
If ii = 2 Then Label23.Caption = "+5"
If ii = 3 Then Label23.Caption = "-10"
If ii = 4 Then Label23.Caption = "+15"
If ii = 5 Then Label23.Caption = "Z"
If ii = 6 Then Label23.Caption = "+1"
If ii = 7 Then Label23.Caption = "B"
If ii = 8 Then Label23.Caption = "Z"
If ii = 9 Then Label23.Caption = "-1"
If ii = 10 Then Label23.Caption = "(-)"
If ii = 1 Then Label23.ToolTipText = "Decrease 5$"
If ii = 2 Then Label23.ToolTipText = "Increase 5$"
If ii = 3 Then Label23.ToolTipText = "Decrease 10$"
If ii = 4 Then Label23.ToolTipText = "Increase 15$"
If ii = 5 Then Label23.ToolTipText = "Zero Counter"
If ii = 6 Then Label23.ToolTipText = "Increase 1$"
If ii = 7 Then Label23.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label23.ToolTipText = "Zero Counter"
If ii = 9 Then Label23.ToolTipText = "Decrease 1$"
If ii = 10 Then Label23.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label24.Caption = "-5"
If ii = 2 Then Label24.Caption = "+5"
If ii = 3 Then Label24.Caption = "-10"
If ii = 4 Then Label24.Caption = "+15"
If ii = 5 Then Label24.Caption = "Z"
If ii = 6 Then Label24.Caption = "+1"
If ii = 7 Then Label24.Caption = "B"
If ii = 8 Then Label24.Caption = "Z"
If ii = 9 Then Label24.Caption = "-1"
If ii = 10 Then Label24.Caption = "(-)"
If ii = 1 Then Label24.ToolTipText = "Decrease 5$"
If ii = 2 Then Label24.ToolTipText = "Increase 5$"
If ii = 3 Then Label24.ToolTipText = "Decrease 10$"
If ii = 4 Then Label24.ToolTipText = "Increase 15$"
If ii = 5 Then Label24.ToolTipText = "Zero Counter"
If ii = 6 Then Label24.ToolTipText = "Increase 1$"
If ii = 7 Then Label24.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label24.ToolTipText = "Zero Counter"
If ii = 9 Then Label24.ToolTipText = "Decrease 1$"
If ii = 10 Then Label24.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label25.Caption = "-5"
If ii = 2 Then Label25.Caption = "+5"
If ii = 3 Then Label25.Caption = "-10"
If ii = 4 Then Label25.Caption = "+15"
If ii = 5 Then Label25.Caption = "Z"
If ii = 6 Then Label25.Caption = "+1"
If ii = 7 Then Label25.Caption = "B"
If ii = 8 Then Label25.Caption = "Z"
If ii = 9 Then Label25.Caption = "-1"
If ii = 10 Then Label25.Caption = "(-)"
If ii = 1 Then Label25.ToolTipText = "Decrease 5$"
If ii = 2 Then Label25.ToolTipText = "Increase 5$"
If ii = 3 Then Label25.ToolTipText = "Decrease 10$"
If ii = 4 Then Label25.ToolTipText = "Increase 15$"
If ii = 5 Then Label25.ToolTipText = "Zero Counter"
If ii = 6 Then Label25.ToolTipText = "Increase 1$"
If ii = 7 Then Label25.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label25.ToolTipText = "Zero Counter"
If ii = 9 Then Label25.ToolTipText = "Decrease 1$"
If ii = 10 Then Label25.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label26.Caption = "-5"
If ii = 2 Then Label26.Caption = "+5"
If ii = 3 Then Label26.Caption = "-10"
If ii = 4 Then Label26.Caption = "+15"
If ii = 5 Then Label26.Caption = "Z"
If ii = 6 Then Label26.Caption = "+1"
If ii = 7 Then Label26.Caption = "B"
If ii = 8 Then Label26.Caption = "Z"
If ii = 9 Then Label26.Caption = "-1"
If ii = 10 Then Label26.Caption = "(-)"
If ii = 1 Then Label26.ToolTipText = "Decrease 5$"
If ii = 2 Then Label26.ToolTipText = "Increase 5$"
If ii = 3 Then Label26.ToolTipText = "Decrease 10$"
If ii = 4 Then Label26.ToolTipText = "Increase 15$"
If ii = 5 Then Label26.ToolTipText = "Zero Counter"
If ii = 6 Then Label26.ToolTipText = "Increase 1$"
If ii = 7 Then Label26.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label26.ToolTipText = "Zero Counter"
If ii = 9 Then Label26.ToolTipText = "Decrease 1$"
If ii = 10 Then Label26.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label27.Caption = "-5"
If ii = 2 Then Label27.Caption = "+5"
If ii = 3 Then Label27.Caption = "-10"
If ii = 4 Then Label27.Caption = "+15"
If ii = 5 Then Label27.Caption = "Z"
If ii = 6 Then Label27.Caption = "+1"
If ii = 7 Then Label27.Caption = "B"
If ii = 8 Then Label27.Caption = "Z"
If ii = 9 Then Label27.Caption = "-1"
If ii = 10 Then Label27.Caption = "(-)"
If ii = 1 Then Label27.ToolTipText = "Decrease 5$"
If ii = 2 Then Label27.ToolTipText = "Increase 5$"
If ii = 3 Then Label27.ToolTipText = "Decrease 10$"
If ii = 4 Then Label27.ToolTipText = "Increase 15$"
If ii = 5 Then Label27.ToolTipText = "Zero Counter"
If ii = 6 Then Label27.ToolTipText = "Increase 1$"
If ii = 7 Then Label27.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label27.ToolTipText = "Zero Counter"
If ii = 9 Then Label27.ToolTipText = "Decrease 1$"
If ii = 10 Then Label27.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label28.Caption = "-5"
If ii = 2 Then Label28.Caption = "+5"
If ii = 3 Then Label28.Caption = "-10"
If ii = 4 Then Label28.Caption = "+15"
If ii = 5 Then Label28.Caption = "Z"
If ii = 6 Then Label28.Caption = "+1"
If ii = 7 Then Label28.Caption = "B"
If ii = 8 Then Label28.Caption = "Z"
If ii = 9 Then Label28.Caption = "-1"
If ii = 10 Then Label28.Caption = "(-)"
If ii = 1 Then Label28.ToolTipText = "Decrease 5$"
If ii = 2 Then Label28.ToolTipText = "Increase 5$"
If ii = 3 Then Label28.ToolTipText = "Decrease 10$"
If ii = 4 Then Label28.ToolTipText = "Increase 15$"
If ii = 5 Then Label28.ToolTipText = "Zero Counter"
If ii = 6 Then Label28.ToolTipText = "Increase 1$"
If ii = 7 Then Label28.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label28.ToolTipText = "Zero Counter"
If ii = 9 Then Label28.ToolTipText = "Decrease 1$"
If ii = 10 Then Label28.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label29.Caption = "-5"
If ii = 2 Then Label29.Caption = "+5"
If ii = 3 Then Label29.Caption = "-10"
If ii = 4 Then Label29.Caption = "+15"
If ii = 5 Then Label29.Caption = "Z"
If ii = 6 Then Label29.Caption = "+1"
If ii = 7 Then Label29.Caption = "B"
If ii = 8 Then Label29.Caption = "Z"
If ii = 9 Then Label29.Caption = "-1"
If ii = 10 Then Label29.Caption = "(-)"
If ii = 1 Then Label29.ToolTipText = "Decrease 5$"
If ii = 2 Then Label29.ToolTipText = "Increase 5$"
If ii = 3 Then Label29.ToolTipText = "Decrease 10$"
If ii = 4 Then Label29.ToolTipText = "Increase 15$"
If ii = 5 Then Label29.ToolTipText = "Zero Counter"
If ii = 6 Then Label29.ToolTipText = "Increase 1$"
If ii = 7 Then Label29.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label29.ToolTipText = "Zero Counter"
If ii = 9 Then Label29.ToolTipText = "Decrease 1$"
If ii = 10 Then Label29.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label30.Caption = "-5"
If ii = 2 Then Label30.Caption = "+5"
If ii = 3 Then Label30.Caption = "-10"
If ii = 4 Then Label30.Caption = "+15"
If ii = 5 Then Label30.Caption = "Z"
If ii = 6 Then Label30.Caption = "+1"
If ii = 7 Then Label30.Caption = "B"
If ii = 8 Then Label30.Caption = "Z"
If ii = 9 Then Label30.Caption = "-1"
If ii = 10 Then Label30.Caption = "(-)"
If ii = 1 Then Label30.ToolTipText = "Decrease 5$"
If ii = 2 Then Label30.ToolTipText = "Increase 5$"
If ii = 3 Then Label30.ToolTipText = "Decrease 10$"
If ii = 4 Then Label30.ToolTipText = "Increase 15$"
If ii = 5 Then Label30.ToolTipText = "Zero Counter"
If ii = 6 Then Label30.ToolTipText = "Increase 1$"
If ii = 7 Then Label30.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label30.ToolTipText = "Zero Counter"
If ii = 9 Then Label30.ToolTipText = "Decrease 1$"
If ii = 10 Then Label30.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label31.Caption = "-5"
If ii = 2 Then Label31.Caption = "+5"
If ii = 3 Then Label31.Caption = "-10"
If ii = 4 Then Label31.Caption = "+15"
If ii = 5 Then Label31.Caption = "Z"
If ii = 6 Then Label31.Caption = "+1"
If ii = 7 Then Label31.Caption = "B"
If ii = 8 Then Label31.Caption = "Z"
If ii = 9 Then Label31.Caption = "-1"
If ii = 10 Then Label31.Caption = "(-)"
If ii = 1 Then Label31.ToolTipText = "Decrease 5$"
If ii = 2 Then Label31.ToolTipText = "Increase 5$"
If ii = 3 Then Label31.ToolTipText = "Decrease 10$"
If ii = 4 Then Label31.ToolTipText = "Increase 15$"
If ii = 5 Then Label31.ToolTipText = "Zero Counter"
If ii = 6 Then Label31.ToolTipText = "Increase 1$"
If ii = 7 Then Label31.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label31.ToolTipText = "Zero Counter"
If ii = 9 Then Label31.ToolTipText = "Decrease 1$"
If ii = 10 Then Label31.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label32.Caption = "-5"
If ii = 2 Then Label32.Caption = "+5"
If ii = 3 Then Label32.Caption = "-10"
If ii = 4 Then Label32.Caption = "+15"
If ii = 5 Then Label32.Caption = "Z"
If ii = 6 Then Label32.Caption = "+1"
If ii = 7 Then Label32.Caption = "B"
If ii = 8 Then Label32.Caption = "Z"
If ii = 9 Then Label32.Caption = "-1"
If ii = 10 Then Label32.Caption = "(-)"
If ii = 1 Then Label32.ToolTipText = "Decrease 5$"
If ii = 2 Then Label32.ToolTipText = "Increase 5$"
If ii = 3 Then Label32.ToolTipText = "Decrease 10$"
If ii = 4 Then Label32.ToolTipText = "Increase 15$"
If ii = 5 Then Label32.ToolTipText = "Zero Counter"
If ii = 6 Then Label32.ToolTipText = "Increase 1$"
If ii = 7 Then Label32.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label32.ToolTipText = "Zero Counter"
If ii = 9 Then Label32.ToolTipText = "Decrease 1$"
If ii = 10 Then Label32.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label33.Caption = "-5"
If ii = 2 Then Label33.Caption = "+5"
If ii = 3 Then Label33.Caption = "-10"
If ii = 4 Then Label33.Caption = "+15"
If ii = 5 Then Label33.Caption = "Z"
If ii = 6 Then Label33.Caption = "+1"
If ii = 7 Then Label33.Caption = "B"
If ii = 8 Then Label33.Caption = "Z"
If ii = 9 Then Label33.Caption = "-1"
If ii = 10 Then Label33.Caption = "(-)"
If ii = 1 Then Label33.ToolTipText = "Decrease 5$"
If ii = 2 Then Label33.ToolTipText = "Increase 5$"
If ii = 3 Then Label33.ToolTipText = "Decrease 10$"
If ii = 4 Then Label33.ToolTipText = "Increase 15$"
If ii = 5 Then Label33.ToolTipText = "Zero Counter"
If ii = 6 Then Label33.ToolTipText = "Increase 1$"
If ii = 7 Then Label33.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label33.ToolTipText = "Zero Counter"
If ii = 9 Then Label33.ToolTipText = "Decrease 1$"
If ii = 10 Then Label33.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label34.Caption = "-5"
If ii = 2 Then Label34.Caption = "+5"
If ii = 3 Then Label34.Caption = "-10"
If ii = 4 Then Label34.Caption = "+15"
If ii = 5 Then Label34.Caption = "Z"
If ii = 6 Then Label34.Caption = "+1"
If ii = 7 Then Label34.Caption = "B"
If ii = 8 Then Label34.Caption = "Z"
If ii = 9 Then Label34.Caption = "-1"
If ii = 10 Then Label34.Caption = "(-)"
If ii = 1 Then Label34.ToolTipText = "Decrease 5$"
If ii = 2 Then Label34.ToolTipText = "Increase 5$"
If ii = 3 Then Label34.ToolTipText = "Decrease 10$"
If ii = 4 Then Label34.ToolTipText = "Increase 15$"
If ii = 5 Then Label34.ToolTipText = "Zero Counter"
If ii = 6 Then Label34.ToolTipText = "Increase 1$"
If ii = 7 Then Label34.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label34.ToolTipText = "Zero Counter"
If ii = 9 Then Label34.ToolTipText = "Decrease 1$"
If ii = 10 Then Label34.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label35.Caption = "-5"
If ii = 2 Then Label35.Caption = "+5"
If ii = 3 Then Label35.Caption = "-10"
If ii = 4 Then Label35.Caption = "+15"
If ii = 5 Then Label35.Caption = "Z"
If ii = 6 Then Label35.Caption = "+1"
If ii = 7 Then Label35.Caption = "B"
If ii = 8 Then Label35.Caption = "Z"
If ii = 9 Then Label35.Caption = "-1"
If ii = 10 Then Label35.Caption = "(-)"
If ii = 1 Then Label35.ToolTipText = "Decrease 5$"
If ii = 2 Then Label35.ToolTipText = "Increase 5$"
If ii = 3 Then Label35.ToolTipText = "Decrease 10$"
If ii = 4 Then Label35.ToolTipText = "Increase 15$"
If ii = 5 Then Label35.ToolTipText = "Zero Counter"
If ii = 6 Then Label35.ToolTipText = "Increase 1$"
If ii = 7 Then Label35.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label35.ToolTipText = "Zero Counter"
If ii = 9 Then Label35.ToolTipText = "Decrease 1$"
If ii = 10 Then Label35.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label36.Caption = "-5"
If ii = 2 Then Label36.Caption = "+5"
If ii = 3 Then Label36.Caption = "-10"
If ii = 4 Then Label36.Caption = "+15"
If ii = 5 Then Label36.Caption = "Z"
If ii = 6 Then Label36.Caption = "+1"
If ii = 7 Then Label36.Caption = "B"
If ii = 8 Then Label36.Caption = "Z"
If ii = 9 Then Label36.Caption = "-1"
If ii = 10 Then Label36.Caption = "(-)"
If ii = 1 Then Label36.ToolTipText = "Decrease 5$"
If ii = 2 Then Label36.ToolTipText = "Increase 5$"
If ii = 3 Then Label36.ToolTipText = "Decrease 10$"
If ii = 4 Then Label36.ToolTipText = "Increase 15$"
If ii = 5 Then Label36.ToolTipText = "Zero Counter"
If ii = 6 Then Label36.ToolTipText = "Increase 1$"
If ii = 7 Then Label36.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label36.ToolTipText = "Zero Counter"
If ii = 9 Then Label36.ToolTipText = "Decrease 1$"
If ii = 10 Then Label36.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label37.Caption = "-5"
If ii = 2 Then Label37.Caption = "+5"
If ii = 3 Then Label37.Caption = "-10"
If ii = 4 Then Label37.Caption = "+15"
If ii = 5 Then Label37.Caption = "Z"
If ii = 6 Then Label37.Caption = "+1"
If ii = 7 Then Label37.Caption = "B"
If ii = 8 Then Label37.Caption = "Z"
If ii = 9 Then Label37.Caption = "-1"
If ii = 10 Then Label37.Caption = "(-)"
If ii = 1 Then Label37.ToolTipText = "Decrease 5$"
If ii = 2 Then Label37.ToolTipText = "Increase 5$"
If ii = 3 Then Label37.ToolTipText = "Decrease 10$"
If ii = 4 Then Label37.ToolTipText = "Increase 15$"
If ii = 5 Then Label37.ToolTipText = "Zero Counter"
If ii = 6 Then Label37.ToolTipText = "Increase 1$"
If ii = 7 Then Label37.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label37.ToolTipText = "Zero Counter"
If ii = 9 Then Label37.ToolTipText = "Decrease 1$"
If ii = 10 Then Label37.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label38.Caption = "-5"
If ii = 2 Then Label38.Caption = "+5"
If ii = 3 Then Label38.Caption = "-10"
If ii = 4 Then Label38.Caption = "+15"
If ii = 5 Then Label38.Caption = "Z"
If ii = 6 Then Label38.Caption = "+1"
If ii = 7 Then Label38.Caption = "B"
If ii = 8 Then Label38.Caption = "Z"
If ii = 9 Then Label38.Caption = "-1"
If ii = 10 Then Label38.Caption = "(-)"
If ii = 1 Then Label38.ToolTipText = "Decrease 5$"
If ii = 2 Then Label38.ToolTipText = "Increase 5$"
If ii = 3 Then Label38.ToolTipText = "Decrease 10$"
If ii = 4 Then Label38.ToolTipText = "Increase 15$"
If ii = 5 Then Label38.ToolTipText = "Zero Counter"
If ii = 6 Then Label38.ToolTipText = "Increase 1$"
If ii = 7 Then Label38.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label38.ToolTipText = "Zero Counter"
If ii = 9 Then Label38.ToolTipText = "Decrease 1$"
If ii = 10 Then Label38.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label39.Caption = "-5"
If ii = 2 Then Label39.Caption = "+5"
If ii = 3 Then Label39.Caption = "-10"
If ii = 4 Then Label39.Caption = "+15"
If ii = 5 Then Label39.Caption = "Z"
If ii = 6 Then Label39.Caption = "+1"
If ii = 7 Then Label39.Caption = "B"
If ii = 8 Then Label39.Caption = "Z"
If ii = 9 Then Label39.Caption = "-1"
If ii = 10 Then Label39.Caption = "(-)"
If ii = 1 Then Label39.ToolTipText = "Decrease 5$"
If ii = 2 Then Label39.ToolTipText = "Increase 5$"
If ii = 3 Then Label39.ToolTipText = "Decrease 10$"
If ii = 4 Then Label39.ToolTipText = "Increase 15$"
If ii = 5 Then Label39.ToolTipText = "Zero Counter"
If ii = 6 Then Label39.ToolTipText = "Increase 1$"
If ii = 7 Then Label39.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label39.ToolTipText = "Zero Counter"
If ii = 9 Then Label39.ToolTipText = "Decrease 1$"
If ii = 10 Then Label39.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label40.Caption = "-5"
If ii = 2 Then Label40.Caption = "+5"
If ii = 3 Then Label40.Caption = "-10"
If ii = 4 Then Label40.Caption = "+15"
If ii = 5 Then Label40.Caption = "Z"
If ii = 6 Then Label40.Caption = "+1"
If ii = 7 Then Label40.Caption = "B"
If ii = 8 Then Label40.Caption = "Z"
If ii = 9 Then Label40.Caption = "-1"
If ii = 10 Then Label40.Caption = "(-)"
If ii = 1 Then Label40.ToolTipText = "Decrease 5$"
If ii = 2 Then Label40.ToolTipText = "Increase 5$"
If ii = 3 Then Label40.ToolTipText = "Decrease 10$"
If ii = 4 Then Label40.ToolTipText = "Increase 15$"
If ii = 5 Then Label40.ToolTipText = "Zero Counter"
If ii = 6 Then Label40.ToolTipText = "Increase 1$"
If ii = 7 Then Label40.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label40.ToolTipText = "Zero Counter"
If ii = 9 Then Label40.ToolTipText = "Decrease 1$"
If ii = 10 Then Label40.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label41.Caption = "-5"
If ii = 2 Then Label41.Caption = "+5"
If ii = 3 Then Label41.Caption = "-10"
If ii = 4 Then Label41.Caption = "+15"
If ii = 5 Then Label41.Caption = "Z"
If ii = 6 Then Label41.Caption = "+1"
If ii = 7 Then Label41.Caption = "B"
If ii = 8 Then Label41.Caption = "Z"
If ii = 9 Then Label41.Caption = "-1"
If ii = 10 Then Label41.Caption = "(-)"
If ii = 1 Then Label41.ToolTipText = "Decrease 5$"
If ii = 2 Then Label41.ToolTipText = "Increase 5$"
If ii = 3 Then Label41.ToolTipText = "Decrease 10$"
If ii = 4 Then Label41.ToolTipText = "Increase 15$"
If ii = 5 Then Label41.ToolTipText = "Zero Counter"
If ii = 6 Then Label41.ToolTipText = "Increase 1$"
If ii = 7 Then Label41.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label41.ToolTipText = "Zero Counter"
If ii = 9 Then Label41.ToolTipText = "Decrease 1$"
If ii = 10 Then Label41.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label42.Caption = "-5"
If ii = 2 Then Label42.Caption = "+5"
If ii = 3 Then Label42.Caption = "-10"
If ii = 4 Then Label42.Caption = "+15"
If ii = 5 Then Label42.Caption = "Z"
If ii = 6 Then Label42.Caption = "+1"
If ii = 7 Then Label42.Caption = "B"
If ii = 8 Then Label42.Caption = "Z"
If ii = 9 Then Label42.Caption = "-1"
If ii = 10 Then Label42.Caption = "(-)"
If ii = 1 Then Label42.ToolTipText = "Decrease 5$"
If ii = 2 Then Label42.ToolTipText = "Increase 5$"
If ii = 3 Then Label42.ToolTipText = "Decrease 10$"
If ii = 4 Then Label42.ToolTipText = "Increase 15$"
If ii = 5 Then Label42.ToolTipText = "Zero Counter"
If ii = 6 Then Label42.ToolTipText = "Increase 1$"
If ii = 7 Then Label42.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label42.ToolTipText = "Zero Counter"
If ii = 9 Then Label42.ToolTipText = "Decrease 1$"
If ii = 10 Then Label42.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label43.Caption = "-5"
If ii = 2 Then Label43.Caption = "+5"
If ii = 3 Then Label43.Caption = "-10"
If ii = 4 Then Label43.Caption = "+15"
If ii = 5 Then Label43.Caption = "Z"
If ii = 6 Then Label43.Caption = "+1"
If ii = 7 Then Label43.Caption = "B"
If ii = 8 Then Label43.Caption = "Z"
If ii = 9 Then Label43.Caption = "-1"
If ii = 10 Then Label43.Caption = "(-)"
If ii = 1 Then Label43.ToolTipText = "Decrease 5$"
If ii = 2 Then Label43.ToolTipText = "Increase 5$"
If ii = 3 Then Label43.ToolTipText = "Decrease 10$"
If ii = 4 Then Label43.ToolTipText = "Increase 15$"
If ii = 5 Then Label43.ToolTipText = "Zero Counter"
If ii = 6 Then Label43.ToolTipText = "Increase 1$"
If ii = 7 Then Label43.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label43.ToolTipText = "Zero Counter"
If ii = 9 Then Label43.ToolTipText = "Decrease 1$"
If ii = 10 Then Label43.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label44.Caption = "-5"
If ii = 2 Then Label44.Caption = "+5"
If ii = 3 Then Label44.Caption = "-10"
If ii = 4 Then Label44.Caption = "+15"
If ii = 5 Then Label44.Caption = "Z"
If ii = 6 Then Label44.Caption = "+1"
If ii = 7 Then Label44.Caption = "B"
If ii = 8 Then Label44.Caption = "Z"
If ii = 9 Then Label44.Caption = "-1"
If ii = 10 Then Label44.Caption = "(-)"
If ii = 1 Then Label44.ToolTipText = "Decrease 5$"
If ii = 2 Then Label44.ToolTipText = "Increase 5$"
If ii = 3 Then Label44.ToolTipText = "Decrease 10$"
If ii = 4 Then Label44.ToolTipText = "Increase 15$"
If ii = 5 Then Label44.ToolTipText = "Zero Counter"
If ii = 6 Then Label44.ToolTipText = "Increase 1$"
If ii = 7 Then Label44.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label44.ToolTipText = "Zero Counter"
If ii = 9 Then Label44.ToolTipText = "Decrease 1$"
If ii = 10 Then Label44.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label45.Caption = "-5"
If ii = 2 Then Label45.Caption = "+5"
If ii = 3 Then Label45.Caption = "-10"
If ii = 4 Then Label45.Caption = "+15"
If ii = 5 Then Label45.Caption = "Z"
If ii = 6 Then Label45.Caption = "+1"
If ii = 7 Then Label45.Caption = "B"
If ii = 8 Then Label45.Caption = "Z"
If ii = 9 Then Label45.Caption = "-1"
If ii = 10 Then Label45.Caption = "(-)"
If ii = 1 Then Label45.ToolTipText = "Decrease 5$"
If ii = 2 Then Label45.ToolTipText = "Increase 5$"
If ii = 3 Then Label45.ToolTipText = "Decrease 10$"
If ii = 4 Then Label45.ToolTipText = "Increase 15$"
If ii = 5 Then Label45.ToolTipText = "Zero Counter"
If ii = 6 Then Label45.ToolTipText = "Increase 1$"
If ii = 7 Then Label45.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label45.ToolTipText = "Zero Counter"
If ii = 9 Then Label45.ToolTipText = "Decrease 1$"
If ii = 10 Then Label45.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label46.Caption = "-5"
If ii = 2 Then Label46.Caption = "+5"
If ii = 3 Then Label46.Caption = "-10"
If ii = 4 Then Label46.Caption = "+15"
If ii = 5 Then Label46.Caption = "Z"
If ii = 6 Then Label46.Caption = "+1"
If ii = 7 Then Label46.Caption = "B"
If ii = 8 Then Label46.Caption = "Z"
If ii = 9 Then Label46.Caption = "-1"
If ii = 10 Then Label46.Caption = "(-)"
If ii = 1 Then Label46.ToolTipText = "Decrease 5$"
If ii = 2 Then Label46.ToolTipText = "Increase 5$"
If ii = 3 Then Label46.ToolTipText = "Decrease 10$"
If ii = 4 Then Label46.ToolTipText = "Increase 15$"
If ii = 5 Then Label46.ToolTipText = "Zero Counter"
If ii = 6 Then Label46.ToolTipText = "Increase 1$"
If ii = 7 Then Label46.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label46.ToolTipText = "Zero Counter"
If ii = 9 Then Label46.ToolTipText = "Decrease 1$"
If ii = 10 Then Label46.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label47.Caption = "-5"
If ii = 2 Then Label47.Caption = "+5"
If ii = 3 Then Label47.Caption = "-10"
If ii = 4 Then Label47.Caption = "+15"
If ii = 5 Then Label47.Caption = "Z"
If ii = 6 Then Label47.Caption = "+1"
If ii = 7 Then Label47.Caption = "B"
If ii = 8 Then Label47.Caption = "Z"
If ii = 9 Then Label47.Caption = "-1"
If ii = 10 Then Label47.Caption = "(-)"
If ii = 1 Then Label47.ToolTipText = "Decrease 5$"
If ii = 2 Then Label47.ToolTipText = "Increase 5$"
If ii = 3 Then Label47.ToolTipText = "Decrease 10$"
If ii = 4 Then Label47.ToolTipText = "Increase 15$"
If ii = 5 Then Label47.ToolTipText = "Zero Counter"
If ii = 6 Then Label47.ToolTipText = "Increase 1$"
If ii = 7 Then Label47.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label47.ToolTipText = "Zero Counter"
If ii = 9 Then Label47.ToolTipText = "Decrease 1$"
If ii = 10 Then Label47.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label48.Caption = "-5"
If ii = 2 Then Label48.Caption = "+5"
If ii = 3 Then Label48.Caption = "-10"
If ii = 4 Then Label48.Caption = "+15"
If ii = 5 Then Label48.Caption = "Z"
If ii = 6 Then Label48.Caption = "+1"
If ii = 7 Then Label48.Caption = "B"
If ii = 8 Then Label48.Caption = "Z"
If ii = 9 Then Label48.Caption = "-1"
If ii = 10 Then Label48.Caption = "(-)"
If ii = 1 Then Label48.ToolTipText = "Decrease 5$"
If ii = 2 Then Label48.ToolTipText = "Increase 5$"
If ii = 3 Then Label48.ToolTipText = "Decrease 10$"
If ii = 4 Then Label48.ToolTipText = "Increase 15$"
If ii = 5 Then Label48.ToolTipText = "Zero Counter"
If ii = 6 Then Label48.ToolTipText = "Increase 1$"
If ii = 7 Then Label48.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label48.ToolTipText = "Zero Counter"
If ii = 9 Then Label48.ToolTipText = "Decrease 1$"
If ii = 10 Then Label48.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label49.Caption = "-5"
If ii = 2 Then Label49.Caption = "+5"
If ii = 3 Then Label49.Caption = "-10"
If ii = 4 Then Label49.Caption = "+15"
If ii = 5 Then Label49.Caption = "Z"
If ii = 6 Then Label49.Caption = "+1"
If ii = 7 Then Label49.Caption = "B"
If ii = 8 Then Label49.Caption = "Z"
If ii = 9 Then Label49.Caption = "-1"
If ii = 10 Then Label49.Caption = "(-)"
If ii = 1 Then Label49.ToolTipText = "Decrease 5$"
If ii = 2 Then Label49.ToolTipText = "Increase 5$"
If ii = 3 Then Label49.ToolTipText = "Decrease 10$"
If ii = 4 Then Label49.ToolTipText = "Increase 15$"
If ii = 5 Then Label49.ToolTipText = "Zero Counter"
If ii = 6 Then Label49.ToolTipText = "Increase 1$"
If ii = 7 Then Label49.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label49.ToolTipText = "Zero Counter"
If ii = 9 Then Label49.ToolTipText = "Decrease 1$"
If ii = 10 Then Label49.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label50.Caption = "-5"
If ii = 2 Then Label50.Caption = "+5"
If ii = 3 Then Label50.Caption = "-10"
If ii = 4 Then Label50.Caption = "+15"
If ii = 5 Then Label50.Caption = "Z"
If ii = 6 Then Label50.Caption = "+1"
If ii = 7 Then Label50.Caption = "B"
If ii = 8 Then Label50.Caption = "Z"
If ii = 9 Then Label50.Caption = "-1"
If ii = 10 Then Label50.Caption = "(-)"
If ii = 1 Then Label50.ToolTipText = "Decrease 5$"
If ii = 2 Then Label50.ToolTipText = "Increase 5$"
If ii = 3 Then Label50.ToolTipText = "Decrease 10$"
If ii = 4 Then Label50.ToolTipText = "Increase 15$"
If ii = 5 Then Label50.ToolTipText = "Zero Counter"
If ii = 6 Then Label50.ToolTipText = "Increase 1$"
If ii = 7 Then Label50.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label50.ToolTipText = "Zero Counter"
If ii = 9 Then Label50.ToolTipText = "Decrease 1$"
If ii = 10 Then Label50.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label51.Caption = "-5"
If ii = 2 Then Label51.Caption = "+5"
If ii = 3 Then Label51.Caption = "-10"
If ii = 4 Then Label51.Caption = "+15"
If ii = 5 Then Label51.Caption = "Z"
If ii = 6 Then Label51.Caption = "+1"
If ii = 7 Then Label51.Caption = "B"
If ii = 8 Then Label51.Caption = "Z"
If ii = 9 Then Label51.Caption = "-1"
If ii = 10 Then Label51.Caption = "(-)"
If ii = 1 Then Label51.ToolTipText = "Decrease 5$"
If ii = 2 Then Label51.ToolTipText = "Increase 5$"
If ii = 3 Then Label51.ToolTipText = "Decrease 10$"
If ii = 4 Then Label51.ToolTipText = "Increase 15$"
If ii = 5 Then Label51.ToolTipText = "Zero Counter"
If ii = 6 Then Label51.ToolTipText = "Increase 1$"
If ii = 7 Then Label51.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label51.ToolTipText = "Zero Counter"
If ii = 9 Then Label51.ToolTipText = "Decrease 1$"
If ii = 10 Then Label51.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label52.Caption = "-5"
If ii = 2 Then Label52.Caption = "+5"
If ii = 3 Then Label52.Caption = "-10"
If ii = 4 Then Label52.Caption = "+15"
If ii = 5 Then Label52.Caption = "Z"
If ii = 6 Then Label52.Caption = "+1"
If ii = 7 Then Label52.Caption = "B"
If ii = 8 Then Label52.Caption = "Z"
If ii = 9 Then Label52.Caption = "-1"
If ii = 10 Then Label52.Caption = "(-)"
If ii = 1 Then Label52.ToolTipText = "Decrease 5$"
If ii = 2 Then Label52.ToolTipText = "Increase 5$"
If ii = 3 Then Label52.ToolTipText = "Decrease 10$"
If ii = 4 Then Label52.ToolTipText = "Increase 15$"
If ii = 5 Then Label52.ToolTipText = "Zero Counter"
If ii = 6 Then Label52.ToolTipText = "Increase 1$"
If ii = 7 Then Label52.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label52.ToolTipText = "Zero Counter"
If ii = 9 Then Label52.ToolTipText = "Decrease 1$"
If ii = 10 Then Label52.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label53.Caption = "-5"
If ii = 2 Then Label53.Caption = "+5"
If ii = 3 Then Label53.Caption = "-10"
If ii = 4 Then Label53.Caption = "+15"
If ii = 5 Then Label53.Caption = "Z"
If ii = 6 Then Label53.Caption = "+1"
If ii = 7 Then Label53.Caption = "B"
If ii = 8 Then Label53.Caption = "Z"
If ii = 9 Then Label53.Caption = "-1"
If ii = 10 Then Label53.Caption = "(-)"
If ii = 1 Then Label53.ToolTipText = "Decrease 5$"
If ii = 2 Then Label53.ToolTipText = "Increase 5$"
If ii = 3 Then Label53.ToolTipText = "Decrease 10$"
If ii = 4 Then Label53.ToolTipText = "Increase 15$"
If ii = 5 Then Label53.ToolTipText = "Zero Counter"
If ii = 6 Then Label53.ToolTipText = "Increase 1$"
If ii = 7 Then Label53.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label53.ToolTipText = "Zero Counter"
If ii = 9 Then Label53.ToolTipText = "Decrease 1$"
If ii = 10 Then Label53.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label54.Caption = "-5"
If ii = 2 Then Label54.Caption = "+5"
If ii = 3 Then Label54.Caption = "-10"
If ii = 4 Then Label54.Caption = "+15"
If ii = 5 Then Label54.Caption = "Z"
If ii = 6 Then Label54.Caption = "+1"
If ii = 7 Then Label54.Caption = "B"
If ii = 8 Then Label54.Caption = "Z"
If ii = 9 Then Label54.Caption = "-1"
If ii = 10 Then Label54.Caption = "(-)"
If ii = 1 Then Label54.ToolTipText = "Decrease 5$"
If ii = 2 Then Label54.ToolTipText = "Increase 5$"
If ii = 3 Then Label54.ToolTipText = "Decrease 10$"
If ii = 4 Then Label54.ToolTipText = "Increase 15$"
If ii = 5 Then Label54.ToolTipText = "Zero Counter"
If ii = 6 Then Label54.ToolTipText = "Increase 1$"
If ii = 7 Then Label54.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label54.ToolTipText = "Zero Counter"
If ii = 9 Then Label54.ToolTipText = "Decrease 1$"
If ii = 10 Then Label54.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label55.Caption = "-5"
If ii = 2 Then Label55.Caption = "+5"
If ii = 3 Then Label55.Caption = "-10"
If ii = 4 Then Label55.Caption = "+15"
If ii = 5 Then Label55.Caption = "Z"
If ii = 6 Then Label55.Caption = "+1"
If ii = 7 Then Label55.Caption = "B"
If ii = 8 Then Label55.Caption = "Z"
If ii = 9 Then Label55.Caption = "-1"
If ii = 10 Then Label55.Caption = "(-)"
If ii = 1 Then Label55.ToolTipText = "Decrease 5$"
If ii = 2 Then Label55.ToolTipText = "Increase 5$"
If ii = 3 Then Label55.ToolTipText = "Decrease 10$"
If ii = 4 Then Label55.ToolTipText = "Increase 15$"
If ii = 5 Then Label55.ToolTipText = "Zero Counter"
If ii = 6 Then Label55.ToolTipText = "Increase 1$"
If ii = 7 Then Label55.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label55.ToolTipText = "Zero Counter"
If ii = 9 Then Label55.ToolTipText = "Decrease 1$"
If ii = 10 Then Label55.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label56.Caption = "-5"
If ii = 2 Then Label56.Caption = "+5"
If ii = 3 Then Label56.Caption = "-10"
If ii = 4 Then Label56.Caption = "+15"
If ii = 5 Then Label56.Caption = "Z"
If ii = 6 Then Label56.Caption = "+1"
If ii = 7 Then Label56.Caption = "B"
If ii = 8 Then Label56.Caption = "Z"
If ii = 9 Then Label56.Caption = "-1"
If ii = 10 Then Label56.Caption = "(-)"
If ii = 1 Then Label56.ToolTipText = "Decrease 5$"
If ii = 2 Then Label56.ToolTipText = "Increase 5$"
If ii = 3 Then Label56.ToolTipText = "Decrease 10$"
If ii = 4 Then Label56.ToolTipText = "Increase 15$"
If ii = 5 Then Label56.ToolTipText = "Zero Counter"
If ii = 6 Then Label56.ToolTipText = "Increase 1$"
If ii = 7 Then Label56.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label56.ToolTipText = "Zero Counter"
If ii = 9 Then Label56.ToolTipText = "Decrease 1$"
If ii = 10 Then Label56.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label57.Caption = "-5"
If ii = 2 Then Label57.Caption = "+5"
If ii = 3 Then Label57.Caption = "-10"
If ii = 4 Then Label57.Caption = "+15"
If ii = 5 Then Label57.Caption = "Z"
If ii = 6 Then Label57.Caption = "+1"
If ii = 7 Then Label57.Caption = "B"
If ii = 8 Then Label57.Caption = "Z"
If ii = 9 Then Label57.Caption = "-1"
If ii = 10 Then Label57.Caption = "(-)"
If ii = 1 Then Label57.ToolTipText = "Decrease 5$"
If ii = 2 Then Label57.ToolTipText = "Increase 5$"
If ii = 3 Then Label57.ToolTipText = "Decrease 10$"
If ii = 4 Then Label57.ToolTipText = "Increase 15$"
If ii = 5 Then Label57.ToolTipText = "Zero Counter"
If ii = 6 Then Label57.ToolTipText = "Increase 1$"
If ii = 7 Then Label57.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label57.ToolTipText = "Zero Counter"
If ii = 9 Then Label57.ToolTipText = "Decrease 1$"
If ii = 10 Then Label57.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label58.Caption = "-5"
If ii = 2 Then Label58.Caption = "+5"
If ii = 3 Then Label58.Caption = "-10"
If ii = 4 Then Label58.Caption = "+15"
If ii = 5 Then Label58.Caption = "Z"
If ii = 6 Then Label58.Caption = "+1"
If ii = 7 Then Label58.Caption = "B"
If ii = 8 Then Label58.Caption = "Z"
If ii = 9 Then Label58.Caption = "-1"
If ii = 10 Then Label58.Caption = "(-)"
If ii = 1 Then Label58.ToolTipText = "Decrease 5$"
If ii = 2 Then Label58.ToolTipText = "Increase 5$"
If ii = 3 Then Label58.ToolTipText = "Decrease 10$"
If ii = 4 Then Label58.ToolTipText = "Increase 15$"
If ii = 5 Then Label58.ToolTipText = "Zero Counter"
If ii = 6 Then Label58.ToolTipText = "Increase 1$"
If ii = 7 Then Label58.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label58.ToolTipText = "Zero Counter"
If ii = 9 Then Label58.ToolTipText = "Decrease 1$"
If ii = 10 Then Label58.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label59.Caption = "-5"
If ii = 2 Then Label59.Caption = "+5"
If ii = 3 Then Label59.Caption = "-10"
If ii = 4 Then Label59.Caption = "+15"
If ii = 5 Then Label59.Caption = "Z"
If ii = 6 Then Label59.Caption = "+1"
If ii = 7 Then Label59.Caption = "B"
If ii = 8 Then Label59.Caption = "Z"
If ii = 9 Then Label59.Caption = "-1"
If ii = 10 Then Label59.Caption = "(-)"
If ii = 1 Then Label59.ToolTipText = "Decrease 5$"
If ii = 2 Then Label59.ToolTipText = "Increase 5$"
If ii = 3 Then Label59.ToolTipText = "Decrease 10$"
If ii = 4 Then Label59.ToolTipText = "Increase 15$"
If ii = 5 Then Label59.ToolTipText = "Zero Counter"
If ii = 6 Then Label59.ToolTipText = "Increase 1$"
If ii = 7 Then Label59.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label59.ToolTipText = "Zero Counter"
If ii = 9 Then Label59.ToolTipText = "Decrease 1$"
If ii = 10 Then Label59.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label60.Caption = "-5"
If ii = 2 Then Label60.Caption = "+5"
If ii = 3 Then Label60.Caption = "-10"
If ii = 4 Then Label60.Caption = "+15"
If ii = 5 Then Label60.Caption = "Z"
If ii = 6 Then Label60.Caption = "+1"
If ii = 7 Then Label60.Caption = "B"
If ii = 8 Then Label60.Caption = "Z"
If ii = 9 Then Label60.Caption = "-1"
If ii = 10 Then Label60.Caption = "(-)"
If ii = 1 Then Label60.ToolTipText = "Decrease 5$"
If ii = 2 Then Label60.ToolTipText = "Increase 5$"
If ii = 3 Then Label60.ToolTipText = "Decrease 10$"
If ii = 4 Then Label60.ToolTipText = "Increase 15$"
If ii = 5 Then Label60.ToolTipText = "Zero Counter"
If ii = 6 Then Label60.ToolTipText = "Increase 1$"
If ii = 7 Then Label60.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label60.ToolTipText = "Zero Counter"
If ii = 9 Then Label60.ToolTipText = "Decrease 1$"
If ii = 10 Then Label60.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label61.Caption = "-5"
If ii = 2 Then Label61.Caption = "+5"
If ii = 3 Then Label61.Caption = "-10"
If ii = 4 Then Label61.Caption = "+15"
If ii = 5 Then Label61.Caption = "Z"
If ii = 6 Then Label61.Caption = "+1"
If ii = 7 Then Label61.Caption = "B"
If ii = 8 Then Label61.Caption = "Z"
If ii = 9 Then Label61.Caption = "-1"
If ii = 10 Then Label61.Caption = "(-)"
If ii = 1 Then Label61.ToolTipText = "Decrease 5$"
If ii = 2 Then Label61.ToolTipText = "Increase 5$"
If ii = 3 Then Label61.ToolTipText = "Decrease 10$"
If ii = 4 Then Label61.ToolTipText = "Increase 15$"
If ii = 5 Then Label61.ToolTipText = "Zero Counter"
If ii = 6 Then Label61.ToolTipText = "Increase 1$"
If ii = 7 Then Label61.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label61.ToolTipText = "Zero Counter"
If ii = 9 Then Label61.ToolTipText = "Decrease 1$"
If ii = 10 Then Label61.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label62.Caption = "-5"
If ii = 2 Then Label62.Caption = "+5"
If ii = 3 Then Label62.Caption = "-10"
If ii = 4 Then Label62.Caption = "+15"
If ii = 5 Then Label62.Caption = "Z"
If ii = 6 Then Label62.Caption = "+1"
If ii = 7 Then Label62.Caption = "B"
If ii = 8 Then Label62.Caption = "Z"
If ii = 9 Then Label62.Caption = "-1"
If ii = 10 Then Label62.Caption = "(-)"
If ii = 1 Then Label62.ToolTipText = "Decrease 5$"
If ii = 2 Then Label62.ToolTipText = "Increase 5$"
If ii = 3 Then Label62.ToolTipText = "Decrease 10$"
If ii = 4 Then Label62.ToolTipText = "Increase 15$"
If ii = 5 Then Label62.ToolTipText = "Zero Counter"
If ii = 6 Then Label62.ToolTipText = "Increase 1$"
If ii = 7 Then Label62.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label62.ToolTipText = "Zero Counter"
If ii = 9 Then Label62.ToolTipText = "Decrease 1$"
If ii = 10 Then Label62.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label63.Caption = "-5"
If ii = 2 Then Label63.Caption = "+5"
If ii = 3 Then Label63.Caption = "-10"
If ii = 4 Then Label63.Caption = "+15"
If ii = 5 Then Label63.Caption = "Z"
If ii = 6 Then Label63.Caption = "+1"
If ii = 7 Then Label63.Caption = "B"
If ii = 8 Then Label63.Caption = "Z"
If ii = 9 Then Label63.Caption = "-1"
If ii = 10 Then Label63.Caption = "(-)"
If ii = 1 Then Label63.ToolTipText = "Decrease 5$"
If ii = 2 Then Label63.ToolTipText = "Increase 5$"
If ii = 3 Then Label63.ToolTipText = "Decrease 10$"
If ii = 4 Then Label63.ToolTipText = "Increase 15$"
If ii = 5 Then Label63.ToolTipText = "Zero Counter"
If ii = 6 Then Label63.ToolTipText = "Increase 1$"
If ii = 7 Then Label63.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label63.ToolTipText = "Zero Counter"
If ii = 9 Then Label63.ToolTipText = "Decrease 1$"
If ii = 10 Then Label63.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label64.Caption = "-5"
If ii = 2 Then Label64.Caption = "+5"
If ii = 3 Then Label64.Caption = "-10"
If ii = 4 Then Label64.Caption = "+15"
If ii = 5 Then Label64.Caption = "Z"
If ii = 6 Then Label64.Caption = "+1"
If ii = 7 Then Label64.Caption = "B"
If ii = 8 Then Label64.Caption = "Z"
If ii = 9 Then Label64.Caption = "-1"
If ii = 10 Then Label64.Caption = "(-)"
If ii = 1 Then Label64.ToolTipText = "Decrease 5$"
If ii = 2 Then Label64.ToolTipText = "Increase 5$"
If ii = 3 Then Label64.ToolTipText = "Decrease 10$"
If ii = 4 Then Label64.ToolTipText = "Increase 15$"
If ii = 5 Then Label64.ToolTipText = "Zero Counter"
If ii = 6 Then Label64.ToolTipText = "Increase 1$"
If ii = 7 Then Label64.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label64.ToolTipText = "Zero Counter"
If ii = 9 Then Label64.ToolTipText = "Decrease 1$"
If ii = 10 Then Label64.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label65.Caption = "-5"
If ii = 2 Then Label65.Caption = "+5"
If ii = 3 Then Label65.Caption = "-10"
If ii = 4 Then Label65.Caption = "+15"
If ii = 5 Then Label65.Caption = "Z"
If ii = 6 Then Label65.Caption = "+1"
If ii = 7 Then Label65.Caption = "B"
If ii = 8 Then Label65.Caption = "Z"
If ii = 9 Then Label65.Caption = "-1"
If ii = 10 Then Label65.Caption = "(-)"
If ii = 1 Then Label65.ToolTipText = "Decrease 5$"
If ii = 2 Then Label65.ToolTipText = "Increase 5$"
If ii = 3 Then Label65.ToolTipText = "Decrease 10$"
If ii = 4 Then Label65.ToolTipText = "Increase 15$"
If ii = 5 Then Label65.ToolTipText = "Zero Counter"
If ii = 6 Then Label65.ToolTipText = "Increase 1$"
If ii = 7 Then Label65.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label65.ToolTipText = "Zero Counter"
If ii = 9 Then Label65.ToolTipText = "Decrease 1$"
If ii = 10 Then Label65.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label66.Caption = "-5"
If ii = 2 Then Label66.Caption = "+5"
If ii = 3 Then Label66.Caption = "-10"
If ii = 4 Then Label66.Caption = "+15"
If ii = 5 Then Label66.Caption = "Z"
If ii = 6 Then Label66.Caption = "+1"
If ii = 7 Then Label66.Caption = "B"
If ii = 8 Then Label66.Caption = "Z"
If ii = 9 Then Label66.Caption = "-1"
If ii = 10 Then Label66.Caption = "(-)"
If ii = 1 Then Label66.ToolTipText = "Decrease 5$"
If ii = 2 Then Label66.ToolTipText = "Increase 5$"
If ii = 3 Then Label66.ToolTipText = "Decrease 10$"
If ii = 4 Then Label66.ToolTipText = "Increase 15$"
If ii = 5 Then Label66.ToolTipText = "Zero Counter"
If ii = 6 Then Label66.ToolTipText = "Increase 1$"
If ii = 7 Then Label66.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label66.ToolTipText = "Zero Counter"
If ii = 9 Then Label66.ToolTipText = "Decrease 1$"
If ii = 10 Then Label66.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label67.Caption = "-5"
If ii = 2 Then Label67.Caption = "+5"
If ii = 3 Then Label67.Caption = "-10"
If ii = 4 Then Label67.Caption = "+15"
If ii = 5 Then Label67.Caption = "Z"
If ii = 6 Then Label67.Caption = "+1"
If ii = 7 Then Label67.Caption = "B"
If ii = 8 Then Label67.Caption = "Z"
If ii = 9 Then Label67.Caption = "-1"
If ii = 10 Then Label67.Caption = "(-)"
If ii = 1 Then Label67.ToolTipText = "Decrease 5$"
If ii = 2 Then Label67.ToolTipText = "Increase 5$"
If ii = 3 Then Label67.ToolTipText = "Decrease 10$"
If ii = 4 Then Label67.ToolTipText = "Increase 15$"
If ii = 5 Then Label67.ToolTipText = "Zero Counter"
If ii = 6 Then Label67.ToolTipText = "Increase 1$"
If ii = 7 Then Label67.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label67.ToolTipText = "Zero Counter"
If ii = 9 Then Label67.ToolTipText = "Decrease 1$"
If ii = 10 Then Label67.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label68.Caption = "-5"
If ii = 2 Then Label68.Caption = "+5"
If ii = 3 Then Label68.Caption = "-10"
If ii = 4 Then Label68.Caption = "+15"
If ii = 5 Then Label68.Caption = "Z"
If ii = 6 Then Label68.Caption = "+1"
If ii = 7 Then Label68.Caption = "B"
If ii = 8 Then Label68.Caption = "Z"
If ii = 9 Then Label68.Caption = "-1"
If ii = 10 Then Label68.Caption = "(-)"
If ii = 1 Then Label68.ToolTipText = "Decrease 5$"
If ii = 2 Then Label68.ToolTipText = "Increase 5$"
If ii = 3 Then Label68.ToolTipText = "Decrease 10$"
If ii = 4 Then Label68.ToolTipText = "Increase 15$"
If ii = 5 Then Label68.ToolTipText = "Zero Counter"
If ii = 6 Then Label68.ToolTipText = "Increase 1$"
If ii = 7 Then Label68.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label68.ToolTipText = "Zero Counter"
If ii = 9 Then Label68.ToolTipText = "Decrease 1$"
If ii = 10 Then Label68.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label69.Caption = "-5"
If ii = 2 Then Label69.Caption = "+5"
If ii = 3 Then Label69.Caption = "-10"
If ii = 4 Then Label69.Caption = "+15"
If ii = 5 Then Label69.Caption = "Z"
If ii = 6 Then Label69.Caption = "+1"
If ii = 7 Then Label69.Caption = "B"
If ii = 8 Then Label69.Caption = "Z"
If ii = 9 Then Label69.Caption = "-1"
If ii = 10 Then Label69.Caption = "(-)"
If ii = 1 Then Label69.ToolTipText = "Decrease 5$"
If ii = 2 Then Label69.ToolTipText = "Increase 5$"
If ii = 3 Then Label69.ToolTipText = "Decrease 10$"
If ii = 4 Then Label69.ToolTipText = "Increase 15$"
If ii = 5 Then Label69.ToolTipText = "Zero Counter"
If ii = 6 Then Label69.ToolTipText = "Increase 1$"
If ii = 7 Then Label69.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label69.ToolTipText = "Zero Counter"
If ii = 9 Then Label69.ToolTipText = "Decrease 1$"
If ii = 10 Then Label69.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label70.Caption = "-5"
If ii = 2 Then Label70.Caption = "+5"
If ii = 3 Then Label70.Caption = "-10"
If ii = 4 Then Label70.Caption = "+15"
If ii = 5 Then Label70.Caption = "Z"
If ii = 6 Then Label70.Caption = "+1"
If ii = 7 Then Label70.Caption = "B"
If ii = 8 Then Label70.Caption = "Z"
If ii = 9 Then Label70.Caption = "-1"
If ii = 10 Then Label70.Caption = "(-)"
If ii = 1 Then Label70.ToolTipText = "Decrease 5$"
If ii = 2 Then Label70.ToolTipText = "Increase 5$"
If ii = 3 Then Label70.ToolTipText = "Decrease 10$"
If ii = 4 Then Label70.ToolTipText = "Increase 15$"
If ii = 5 Then Label70.ToolTipText = "Zero Counter"
If ii = 6 Then Label70.ToolTipText = "Increase 1$"
If ii = 7 Then Label70.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label70.ToolTipText = "Zero Counter"
If ii = 9 Then Label70.ToolTipText = "Decrease 1$"
If ii = 10 Then Label70.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label71.Caption = "-5"
If ii = 2 Then Label71.Caption = "+5"
If ii = 3 Then Label71.Caption = "-10"
If ii = 4 Then Label71.Caption = "+15"
If ii = 5 Then Label71.Caption = "Z"
If ii = 6 Then Label71.Caption = "+1"
If ii = 7 Then Label71.Caption = "B"
If ii = 8 Then Label71.Caption = "Z"
If ii = 9 Then Label71.Caption = "-1"
If ii = 10 Then Label71.Caption = "(-)"
If ii = 1 Then Label71.ToolTipText = "Decrease 5$"
If ii = 2 Then Label71.ToolTipText = "Increase 5$"
If ii = 3 Then Label71.ToolTipText = "Decrease 10$"
If ii = 4 Then Label71.ToolTipText = "Increase 15$"
If ii = 5 Then Label71.ToolTipText = "Zero Counter"
If ii = 6 Then Label71.ToolTipText = "Increase 1$"
If ii = 7 Then Label71.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label71.ToolTipText = "Zero Counter"
If ii = 9 Then Label71.ToolTipText = "Decrease 1$"
If ii = 10 Then Label71.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label72.Caption = "-5"
If ii = 2 Then Label72.Caption = "+5"
If ii = 3 Then Label72.Caption = "-10"
If ii = 4 Then Label72.Caption = "+15"
If ii = 5 Then Label72.Caption = "Z"
If ii = 6 Then Label72.Caption = "+1"
If ii = 7 Then Label72.Caption = "B"
If ii = 8 Then Label72.Caption = "Z"
If ii = 9 Then Label72.Caption = "-1"
If ii = 10 Then Label72.Caption = "(-)"
If ii = 1 Then Label72.ToolTipText = "Decrease 5$"
If ii = 2 Then Label72.ToolTipText = "Increase 5$"
If ii = 3 Then Label72.ToolTipText = "Decrease 10$"
If ii = 4 Then Label72.ToolTipText = "Increase 15$"
If ii = 5 Then Label72.ToolTipText = "Zero Counter"
If ii = 6 Then Label72.ToolTipText = "Increase 1$"
If ii = 7 Then Label72.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label72.ToolTipText = "Zero Counter"
If ii = 9 Then Label72.ToolTipText = "Decrease 1$"
If ii = 10 Then Label72.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label73.Caption = "-5"
If ii = 2 Then Label73.Caption = "+5"
If ii = 3 Then Label73.Caption = "-10"
If ii = 4 Then Label73.Caption = "+15"
If ii = 5 Then Label73.Caption = "Z"
If ii = 6 Then Label73.Caption = "+1"
If ii = 7 Then Label73.Caption = "B"
If ii = 8 Then Label73.Caption = "Z"
If ii = 9 Then Label73.Caption = "-1"
If ii = 10 Then Label73.Caption = "(-)"
If ii = 1 Then Label73.ToolTipText = "Decrease 5$"
If ii = 2 Then Label73.ToolTipText = "Increase 5$"
If ii = 3 Then Label73.ToolTipText = "Decrease 10$"
If ii = 4 Then Label73.ToolTipText = "Increase 15$"
If ii = 5 Then Label73.ToolTipText = "Zero Counter"
If ii = 6 Then Label73.ToolTipText = "Increase 1$"
If ii = 7 Then Label73.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label73.ToolTipText = "Zero Counter"
If ii = 9 Then Label73.ToolTipText = "Decrease 1$"
If ii = 10 Then Label73.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label74.Caption = "-5"
If ii = 2 Then Label74.Caption = "+5"
If ii = 3 Then Label74.Caption = "-10"
If ii = 4 Then Label74.Caption = "+15"
If ii = 5 Then Label74.Caption = "Z"
If ii = 6 Then Label74.Caption = "+1"
If ii = 7 Then Label74.Caption = "B"
If ii = 8 Then Label74.Caption = "Z"
If ii = 9 Then Label74.Caption = "-1"
If ii = 10 Then Label74.Caption = "(-)"
If ii = 1 Then Label74.ToolTipText = "Decrease 5$"
If ii = 2 Then Label74.ToolTipText = "Increase 5$"
If ii = 3 Then Label74.ToolTipText = "Decrease 10$"
If ii = 4 Then Label74.ToolTipText = "Increase 15$"
If ii = 5 Then Label74.ToolTipText = "Zero Counter"
If ii = 6 Then Label74.ToolTipText = "Increase 1$"
If ii = 7 Then Label74.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label74.ToolTipText = "Zero Counter"
If ii = 9 Then Label74.ToolTipText = "Decrease 1$"
If ii = 10 Then Label74.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label75.Caption = "-5"
If ii = 2 Then Label75.Caption = "+5"
If ii = 3 Then Label75.Caption = "-10"
If ii = 4 Then Label75.Caption = "+15"
If ii = 5 Then Label75.Caption = "Z"
If ii = 6 Then Label75.Caption = "+1"
If ii = 7 Then Label75.Caption = "B"
If ii = 8 Then Label75.Caption = "Z"
If ii = 9 Then Label75.Caption = "-1"
If ii = 10 Then Label75.Caption = "(-)"
If ii = 1 Then Label75.ToolTipText = "Decrease 5$"
If ii = 2 Then Label75.ToolTipText = "Increase 5$"
If ii = 3 Then Label75.ToolTipText = "Decrease 10$"
If ii = 4 Then Label75.ToolTipText = "Increase 15$"
If ii = 5 Then Label75.ToolTipText = "Zero Counter"
If ii = 6 Then Label75.ToolTipText = "Increase 1$"
If ii = 7 Then Label75.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label75.ToolTipText = "Zero Counter"
If ii = 9 Then Label75.ToolTipText = "Decrease 1$"
If ii = 10 Then Label75.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label76.Caption = "-5"
If ii = 2 Then Label76.Caption = "+5"
If ii = 3 Then Label76.Caption = "-10"
If ii = 4 Then Label76.Caption = "+15"
If ii = 5 Then Label76.Caption = "Z"
If ii = 6 Then Label76.Caption = "+1"
If ii = 7 Then Label76.Caption = "B"
If ii = 8 Then Label76.Caption = "Z"
If ii = 9 Then Label76.Caption = "-1"
If ii = 10 Then Label76.Caption = "(-)"
If ii = 1 Then Label76.ToolTipText = "Decrease 5$"
If ii = 2 Then Label76.ToolTipText = "Increase 5$"
If ii = 3 Then Label76.ToolTipText = "Decrease 10$"
If ii = 4 Then Label76.ToolTipText = "Increase 15$"
If ii = 5 Then Label76.ToolTipText = "Zero Counter"
If ii = 6 Then Label76.ToolTipText = "Increase 1$"
If ii = 7 Then Label76.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label76.ToolTipText = "Zero Counter"
If ii = 9 Then Label76.ToolTipText = "Decrease 1$"
If ii = 10 Then Label76.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label77.Caption = "-5"
If ii = 2 Then Label77.Caption = "+5"
If ii = 3 Then Label77.Caption = "-10"
If ii = 4 Then Label77.Caption = "+15"
If ii = 5 Then Label77.Caption = "Z"
If ii = 6 Then Label77.Caption = "+1"
If ii = 7 Then Label77.Caption = "B"
If ii = 8 Then Label77.Caption = "Z"
If ii = 9 Then Label77.Caption = "-1"
If ii = 10 Then Label77.Caption = "(-)"
If ii = 1 Then Label77.ToolTipText = "Decrease 5$"
If ii = 2 Then Label77.ToolTipText = "Increase 5$"
If ii = 3 Then Label77.ToolTipText = "Decrease 10$"
If ii = 4 Then Label77.ToolTipText = "Increase 15$"
If ii = 5 Then Label77.ToolTipText = "Zero Counter"
If ii = 6 Then Label77.ToolTipText = "Increase 1$"
If ii = 7 Then Label77.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label77.ToolTipText = "Zero Counter"
If ii = 9 Then Label77.ToolTipText = "Decrease 1$"
If ii = 10 Then Label77.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label78.Caption = "-5"
If ii = 2 Then Label78.Caption = "+5"
If ii = 3 Then Label78.Caption = "-10"
If ii = 4 Then Label78.Caption = "+15"
If ii = 5 Then Label78.Caption = "Z"
If ii = 6 Then Label78.Caption = "+1"
If ii = 7 Then Label78.Caption = "B"
If ii = 8 Then Label78.Caption = "Z"
If ii = 9 Then Label78.Caption = "-1"
If ii = 10 Then Label78.Caption = "(-)"
If ii = 1 Then Label78.ToolTipText = "Decrease 5$"
If ii = 2 Then Label78.ToolTipText = "Increase 5$"
If ii = 3 Then Label78.ToolTipText = "Decrease 10$"
If ii = 4 Then Label78.ToolTipText = "Increase 15$"
If ii = 5 Then Label78.ToolTipText = "Zero Counter"
If ii = 6 Then Label78.ToolTipText = "Increase 1$"
If ii = 7 Then Label78.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label78.ToolTipText = "Zero Counter"
If ii = 9 Then Label78.ToolTipText = "Decrease 1$"
If ii = 10 Then Label78.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label79.Caption = "-5"
If ii = 2 Then Label79.Caption = "+5"
If ii = 3 Then Label79.Caption = "-10"
If ii = 4 Then Label79.Caption = "+15"
If ii = 5 Then Label79.Caption = "Z"
If ii = 6 Then Label79.Caption = "+1"
If ii = 7 Then Label79.Caption = "B"
If ii = 8 Then Label79.Caption = "Z"
If ii = 9 Then Label79.Caption = "-1"
If ii = 10 Then Label79.Caption = "(-)"
If ii = 1 Then Label79.ToolTipText = "Decrease 5$"
If ii = 2 Then Label79.ToolTipText = "Increase 5$"
If ii = 3 Then Label79.ToolTipText = "Decrease 10$"
If ii = 4 Then Label79.ToolTipText = "Increase 15$"
If ii = 5 Then Label79.ToolTipText = "Zero Counter"
If ii = 6 Then Label79.ToolTipText = "Increase 1$"
If ii = 7 Then Label79.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label79.ToolTipText = "Zero Counter"
If ii = 9 Then Label79.ToolTipText = "Decrease 1$"
If ii = 10 Then Label79.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label80.Caption = "-5"
If ii = 2 Then Label80.Caption = "+5"
If ii = 3 Then Label80.Caption = "-10"
If ii = 4 Then Label80.Caption = "+15"
If ii = 5 Then Label80.Caption = "Z"
If ii = 6 Then Label80.Caption = "+1"
If ii = 7 Then Label80.Caption = "B"
If ii = 8 Then Label80.Caption = "Z"
If ii = 9 Then Label80.Caption = "-1"
If ii = 10 Then Label80.Caption = "(-)"
If ii = 1 Then Label80.ToolTipText = "Decrease 5$"
If ii = 2 Then Label80.ToolTipText = "Increase 5$"
If ii = 3 Then Label80.ToolTipText = "Decrease 10$"
If ii = 4 Then Label80.ToolTipText = "Increase 15$"
If ii = 5 Then Label80.ToolTipText = "Zero Counter"
If ii = 6 Then Label80.ToolTipText = "Increase 1$"
If ii = 7 Then Label80.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label80.ToolTipText = "Zero Counter"
If ii = 9 Then Label80.ToolTipText = "Decrease 1$"
If ii = 10 Then Label80.ToolTipText = "Randomize Decrease"
FormClick2
End Sub
Private Sub FormClick2()
RND_NEXT
If ii = 1 Then Label81.Caption = "-5"
If ii = 2 Then Label81.Caption = "+5"
If ii = 3 Then Label81.Caption = "-10"
If ii = 4 Then Label81.Caption = "+15"
If ii = 5 Then Label81.Caption = "Z"
If ii = 6 Then Label81.Caption = "+1"
If ii = 7 Then Label81.Caption = "B"
If ii = 8 Then Label81.Caption = "Z"
If ii = 9 Then Label81.Caption = "-1"
If ii = 10 Then Label81.Caption = "(-)"
If ii = 1 Then Label81.ToolTipText = "Decrease 5$"
If ii = 2 Then Label81.ToolTipText = "Increase 5$"
If ii = 3 Then Label81.ToolTipText = "Decrease 10$"
If ii = 4 Then Label81.ToolTipText = "Increase 15$"
If ii = 5 Then Label81.ToolTipText = "Zero Counter"
If ii = 6 Then Label81.ToolTipText = "Increase 1$"
If ii = 7 Then Label81.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label81.ToolTipText = "Zero Counter"
If ii = 9 Then Label81.ToolTipText = "Decrease 1$"
If ii = 10 Then Label81.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label82.Caption = "-5"
If ii = 2 Then Label82.Caption = "+5"
If ii = 3 Then Label82.Caption = "-10"
If ii = 4 Then Label82.Caption = "+15"
If ii = 5 Then Label82.Caption = "Z"
If ii = 6 Then Label82.Caption = "+1"
If ii = 7 Then Label82.Caption = "B"
If ii = 8 Then Label82.Caption = "Z"
If ii = 9 Then Label82.Caption = "-1"
If ii = 10 Then Label82.Caption = "(-)"
If ii = 1 Then Label82.ToolTipText = "Decrease 5$"
If ii = 2 Then Label82.ToolTipText = "Increase 5$"
If ii = 3 Then Label82.ToolTipText = "Decrease 10$"
If ii = 4 Then Label82.ToolTipText = "Increase 15$"
If ii = 5 Then Label82.ToolTipText = "Zero Counter"
If ii = 6 Then Label82.ToolTipText = "Increase 1$"
If ii = 7 Then Label82.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label82.ToolTipText = "Zero Counter"
If ii = 9 Then Label82.ToolTipText = "Decrease 1$"
If ii = 10 Then Label82.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label83.Caption = "-5"
If ii = 2 Then Label83.Caption = "+5"
If ii = 3 Then Label83.Caption = "-10"
If ii = 4 Then Label83.Caption = "+15"
If ii = 5 Then Label83.Caption = "Z"
If ii = 6 Then Label83.Caption = "+1"
If ii = 7 Then Label83.Caption = "B"
If ii = 8 Then Label83.Caption = "Z"
If ii = 9 Then Label83.Caption = "-1"
If ii = 10 Then Label83.Caption = "(-)"
If ii = 1 Then Label83.ToolTipText = "Decrease 5$"
If ii = 2 Then Label83.ToolTipText = "Increase 5$"
If ii = 3 Then Label83.ToolTipText = "Decrease 10$"
If ii = 4 Then Label83.ToolTipText = "Increase 15$"
If ii = 5 Then Label83.ToolTipText = "Zero Counter"
If ii = 6 Then Label83.ToolTipText = "Increase 1$"
If ii = 7 Then Label83.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label83.ToolTipText = "Zero Counter"
If ii = 9 Then Label83.ToolTipText = "Decrease 1$"
If ii = 10 Then Label83.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label84.Caption = "-5"
If ii = 2 Then Label84.Caption = "+5"
If ii = 3 Then Label84.Caption = "-10"
If ii = 4 Then Label84.Caption = "+15"
If ii = 5 Then Label84.Caption = "Z"
If ii = 6 Then Label84.Caption = "+1"
If ii = 7 Then Label84.Caption = "B"
If ii = 8 Then Label84.Caption = "Z"
If ii = 9 Then Label84.Caption = "-1"
If ii = 10 Then Label84.Caption = "(-)"
If ii = 1 Then Label84.ToolTipText = "Decrease 5$"
If ii = 2 Then Label84.ToolTipText = "Increase 5$"
If ii = 3 Then Label84.ToolTipText = "Decrease 10$"
If ii = 4 Then Label84.ToolTipText = "Increase 15$"
If ii = 5 Then Label84.ToolTipText = "Zero Counter"
If ii = 6 Then Label84.ToolTipText = "Increase 1$"
If ii = 7 Then Label84.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label84.ToolTipText = "Zero Counter"
If ii = 9 Then Label84.ToolTipText = "Decrease 1$"
If ii = 10 Then Label84.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label85.Caption = "-5"
If ii = 2 Then Label85.Caption = "+5"
If ii = 3 Then Label85.Caption = "-10"
If ii = 4 Then Label85.Caption = "+15"
If ii = 5 Then Label85.Caption = "Z"
If ii = 6 Then Label85.Caption = "+1"
If ii = 7 Then Label85.Caption = "B"
If ii = 8 Then Label85.Caption = "Z"
If ii = 9 Then Label85.Caption = "-1"
If ii = 10 Then Label85.Caption = "(-)"
If ii = 1 Then Label85.ToolTipText = "Decrease 5$"
If ii = 2 Then Label85.ToolTipText = "Increase 5$"
If ii = 3 Then Label85.ToolTipText = "Decrease 10$"
If ii = 4 Then Label85.ToolTipText = "Increase 15$"
If ii = 5 Then Label85.ToolTipText = "Zero Counter"
If ii = 6 Then Label85.ToolTipText = "Increase 1$"
If ii = 7 Then Label85.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label85.ToolTipText = "Zero Counter"
If ii = 9 Then Label85.ToolTipText = "Decrease 1$"
If ii = 10 Then Label85.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label86.Caption = "-5"
If ii = 2 Then Label86.Caption = "+5"
If ii = 3 Then Label86.Caption = "-10"
If ii = 4 Then Label86.Caption = "+15"
If ii = 5 Then Label86.Caption = "Z"
If ii = 6 Then Label86.Caption = "+1"
If ii = 7 Then Label86.Caption = "B"
If ii = 8 Then Label86.Caption = "Z"
If ii = 9 Then Label86.Caption = "-1"
If ii = 10 Then Label86.Caption = "(-)"
If ii = 1 Then Label86.ToolTipText = "Decrease 5$"
If ii = 2 Then Label86.ToolTipText = "Increase 5$"
If ii = 3 Then Label86.ToolTipText = "Decrease 10$"
If ii = 4 Then Label86.ToolTipText = "Increase 15$"
If ii = 5 Then Label86.ToolTipText = "Zero Counter"
If ii = 6 Then Label86.ToolTipText = "Increase 1$"
If ii = 7 Then Label86.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label86.ToolTipText = "Zero Counter"
If ii = 9 Then Label86.ToolTipText = "Decrease 1$"
If ii = 10 Then Label86.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label87.Caption = "-5"
If ii = 2 Then Label87.Caption = "+5"
If ii = 3 Then Label87.Caption = "-10"
If ii = 4 Then Label87.Caption = "+15"
If ii = 5 Then Label87.Caption = "Z"
If ii = 6 Then Label87.Caption = "+1"
If ii = 7 Then Label87.Caption = "B"
If ii = 8 Then Label87.Caption = "Z"
If ii = 9 Then Label87.Caption = "-1"
If ii = 10 Then Label87.Caption = "(-)"
If ii = 1 Then Label87.ToolTipText = "Decrease 5$"
If ii = 2 Then Label87.ToolTipText = "Increase 5$"
If ii = 3 Then Label87.ToolTipText = "Decrease 10$"
If ii = 4 Then Label87.ToolTipText = "Increase 15$"
If ii = 5 Then Label87.ToolTipText = "Zero Counter"
If ii = 6 Then Label87.ToolTipText = "Increase 1$"
If ii = 7 Then Label87.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label87.ToolTipText = "Zero Counter"
If ii = 9 Then Label87.ToolTipText = "Decrease 1$"
If ii = 10 Then Label87.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label88.Caption = "-5"
If ii = 2 Then Label88.Caption = "+5"
If ii = 3 Then Label88.Caption = "-10"
If ii = 4 Then Label88.Caption = "+15"
If ii = 5 Then Label88.Caption = "Z"
If ii = 6 Then Label88.Caption = "+1"
If ii = 7 Then Label88.Caption = "B"
If ii = 8 Then Label88.Caption = "Z"
If ii = 9 Then Label88.Caption = "-1"
If ii = 10 Then Label88.Caption = "(-)"
If ii = 1 Then Label88.ToolTipText = "Decrease 5$"
If ii = 2 Then Label88.ToolTipText = "Increase 5$"
If ii = 3 Then Label88.ToolTipText = "Decrease 10$"
If ii = 4 Then Label88.ToolTipText = "Increase 15$"
If ii = 5 Then Label88.ToolTipText = "Zero Counter"
If ii = 6 Then Label88.ToolTipText = "Increase 1$"
If ii = 7 Then Label88.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label88.ToolTipText = "Zero Counter"
If ii = 9 Then Label88.ToolTipText = "Decrease 1$"
If ii = 10 Then Label88.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label89.Caption = "-5"
If ii = 2 Then Label89.Caption = "+5"
If ii = 3 Then Label89.Caption = "-10"
If ii = 4 Then Label89.Caption = "+15"
If ii = 5 Then Label89.Caption = "Z"
If ii = 6 Then Label89.Caption = "+1"
If ii = 7 Then Label89.Caption = "B"
If ii = 8 Then Label89.Caption = "Z"
If ii = 9 Then Label89.Caption = "-1"
If ii = 10 Then Label89.Caption = "(-)"
If ii = 1 Then Label89.ToolTipText = "Decrease 5$"
If ii = 2 Then Label89.ToolTipText = "Increase 5$"
If ii = 3 Then Label89.ToolTipText = "Decrease 10$"
If ii = 4 Then Label89.ToolTipText = "Increase 15$"
If ii = 5 Then Label89.ToolTipText = "Zero Counter"
If ii = 6 Then Label89.ToolTipText = "Increase 1$"
If ii = 7 Then Label89.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label89.ToolTipText = "Zero Counter"
If ii = 9 Then Label89.ToolTipText = "Decrease 1$"
If ii = 10 Then Label89.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label90.Caption = "-5"
If ii = 2 Then Label90.Caption = "+5"
If ii = 3 Then Label90.Caption = "-10"
If ii = 4 Then Label90.Caption = "+15"
If ii = 5 Then Label90.Caption = "Z"
If ii = 6 Then Label90.Caption = "+1"
If ii = 7 Then Label90.Caption = "B"
If ii = 8 Then Label90.Caption = "Z"
If ii = 9 Then Label90.Caption = "-1"
If ii = 10 Then Label90.Caption = "(-)"
If ii = 1 Then Label90.ToolTipText = "Decrease 5$"
If ii = 2 Then Label90.ToolTipText = "Increase 5$"
If ii = 3 Then Label90.ToolTipText = "Decrease 10$"
If ii = 4 Then Label90.ToolTipText = "Increase 15$"
If ii = 5 Then Label90.ToolTipText = "Zero Counter"
If ii = 6 Then Label90.ToolTipText = "Increase 1$"
If ii = 7 Then Label90.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label90.ToolTipText = "Zero Counter"
If ii = 9 Then Label90.ToolTipText = "Decrease 1$"
If ii = 10 Then Label90.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label91.Caption = "-5"
If ii = 2 Then Label91.Caption = "+5"
If ii = 3 Then Label91.Caption = "-10"
If ii = 4 Then Label91.Caption = "+15"
If ii = 5 Then Label91.Caption = "Z"
If ii = 6 Then Label91.Caption = "+1"
If ii = 7 Then Label91.Caption = "B"
If ii = 8 Then Label91.Caption = "Z"
If ii = 9 Then Label91.Caption = "-1"
If ii = 10 Then Label91.Caption = "(-)"
If ii = 1 Then Label91.ToolTipText = "Decrease 5$"
If ii = 2 Then Label91.ToolTipText = "Increase 5$"
If ii = 3 Then Label91.ToolTipText = "Decrease 10$"
If ii = 4 Then Label91.ToolTipText = "Increase 15$"
If ii = 5 Then Label91.ToolTipText = "Zero Counter"
If ii = 6 Then Label91.ToolTipText = "Increase 1$"
If ii = 7 Then Label91.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label91.ToolTipText = "Zero Counter"
If ii = 9 Then Label91.ToolTipText = "Decrease 1$"
If ii = 10 Then Label91.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label92.Caption = "-5"
If ii = 2 Then Label92.Caption = "+5"
If ii = 3 Then Label92.Caption = "-10"
If ii = 4 Then Label92.Caption = "+15"
If ii = 5 Then Label92.Caption = "Z"
If ii = 6 Then Label92.Caption = "+1"
If ii = 7 Then Label92.Caption = "B"
If ii = 8 Then Label92.Caption = "Z"
If ii = 9 Then Label92.Caption = "-1"
If ii = 10 Then Label92.Caption = "(-)"
If ii = 1 Then Label92.ToolTipText = "Decrease 5$"
If ii = 2 Then Label92.ToolTipText = "Increase 5$"
If ii = 3 Then Label92.ToolTipText = "Decrease 10$"
If ii = 4 Then Label92.ToolTipText = "Increase 15$"
If ii = 5 Then Label92.ToolTipText = "Zero Counter"
If ii = 6 Then Label92.ToolTipText = "Increase 1$"
If ii = 7 Then Label92.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label92.ToolTipText = "Zero Counter"
If ii = 9 Then Label92.ToolTipText = "Decrease 1$"
If ii = 10 Then Label92.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label93.Caption = "-5"
If ii = 2 Then Label93.Caption = "+5"
If ii = 3 Then Label93.Caption = "-10"
If ii = 4 Then Label93.Caption = "+15"
If ii = 5 Then Label93.Caption = "Z"
If ii = 6 Then Label93.Caption = "+1"
If ii = 7 Then Label93.Caption = "B"
If ii = 8 Then Label93.Caption = "Z"
If ii = 9 Then Label93.Caption = "-1"
If ii = 10 Then Label93.Caption = "(-)"
If ii = 1 Then Label93.ToolTipText = "Decrease 5$"
If ii = 2 Then Label93.ToolTipText = "Increase 5$"
If ii = 3 Then Label93.ToolTipText = "Decrease 10$"
If ii = 4 Then Label93.ToolTipText = "Increase 15$"
If ii = 5 Then Label93.ToolTipText = "Zero Counter"
If ii = 6 Then Label93.ToolTipText = "Increase 1$"
If ii = 7 Then Label93.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label93.ToolTipText = "Zero Counter"
If ii = 9 Then Label93.ToolTipText = "Decrease 1$"
If ii = 10 Then Label93.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label94.Caption = "-5"
If ii = 2 Then Label94.Caption = "+5"
If ii = 3 Then Label94.Caption = "-10"
If ii = 4 Then Label94.Caption = "+15"
If ii = 5 Then Label94.Caption = "Z"
If ii = 6 Then Label94.Caption = "+1"
If ii = 7 Then Label94.Caption = "B"
If ii = 8 Then Label94.Caption = "Z"
If ii = 9 Then Label94.Caption = "-1"
If ii = 10 Then Label94.Caption = "(-)"
If ii = 1 Then Label94.ToolTipText = "Decrease 5$"
If ii = 2 Then Label94.ToolTipText = "Increase 5$"
If ii = 3 Then Label94.ToolTipText = "Decrease 10$"
If ii = 4 Then Label94.ToolTipText = "Increase 15$"
If ii = 5 Then Label94.ToolTipText = "Zero Counter"
If ii = 6 Then Label94.ToolTipText = "Increase 1$"
If ii = 7 Then Label94.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label94.ToolTipText = "Zero Counter"
If ii = 9 Then Label94.ToolTipText = "Decrease 1$"
If ii = 10 Then Label94.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label95.Caption = "-5"
If ii = 2 Then Label95.Caption = "+5"
If ii = 3 Then Label95.Caption = "-10"
If ii = 4 Then Label95.Caption = "+15"
If ii = 5 Then Label95.Caption = "Z"
If ii = 6 Then Label95.Caption = "+1"
If ii = 7 Then Label95.Caption = "B"
If ii = 8 Then Label95.Caption = "Z"
If ii = 9 Then Label95.Caption = "-1"
If ii = 10 Then Label95.Caption = "(-)"
If ii = 1 Then Label95.ToolTipText = "Decrease 5$"
If ii = 2 Then Label95.ToolTipText = "Increase 5$"
If ii = 3 Then Label95.ToolTipText = "Decrease 10$"
If ii = 4 Then Label95.ToolTipText = "Increase 15$"
If ii = 5 Then Label95.ToolTipText = "Zero Counter"
If ii = 6 Then Label95.ToolTipText = "Increase 1$"
If ii = 7 Then Label95.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label95.ToolTipText = "Zero Counter"
If ii = 9 Then Label95.ToolTipText = "Decrease 1$"
If ii = 10 Then Label95.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label96.Caption = "-5"
If ii = 2 Then Label96.Caption = "+5"
If ii = 3 Then Label96.Caption = "-10"
If ii = 4 Then Label96.Caption = "+15"
If ii = 5 Then Label96.Caption = "Z"
If ii = 6 Then Label96.Caption = "+1"
If ii = 7 Then Label96.Caption = "B"
If ii = 8 Then Label96.Caption = "Z"
If ii = 9 Then Label96.Caption = "-1"
If ii = 10 Then Label96.Caption = "(-)"
If ii = 1 Then Label96.ToolTipText = "Decrease 5$"
If ii = 2 Then Label96.ToolTipText = "Increase 5$"
If ii = 3 Then Label96.ToolTipText = "Decrease 10$"
If ii = 4 Then Label96.ToolTipText = "Increase 15$"
If ii = 5 Then Label96.ToolTipText = "Zero Counter"
If ii = 6 Then Label96.ToolTipText = "Increase 1$"
If ii = 7 Then Label96.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label96.ToolTipText = "Zero Counter"
If ii = 9 Then Label96.ToolTipText = "Decrease 1$"
If ii = 10 Then Label96.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label97.Caption = "-5"
If ii = 2 Then Label97.Caption = "+5"
If ii = 3 Then Label97.Caption = "-10"
If ii = 4 Then Label97.Caption = "+15"
If ii = 5 Then Label97.Caption = "Z"
If ii = 6 Then Label97.Caption = "+1"
If ii = 7 Then Label97.Caption = "B"
If ii = 8 Then Label97.Caption = "Z"
If ii = 9 Then Label97.Caption = "-1"
If ii = 10 Then Label97.Caption = "(-)"
If ii = 1 Then Label97.ToolTipText = "Decrease 5$"
If ii = 2 Then Label97.ToolTipText = "Increase 5$"
If ii = 3 Then Label97.ToolTipText = "Decrease 10$"
If ii = 4 Then Label97.ToolTipText = "Increase 15$"
If ii = 5 Then Label97.ToolTipText = "Zero Counter"
If ii = 6 Then Label97.ToolTipText = "Increase 1$"
If ii = 7 Then Label97.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label97.ToolTipText = "Zero Counter"
If ii = 9 Then Label97.ToolTipText = "Decrease 1$"
If ii = 10 Then Label97.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label98.Caption = "-5"
If ii = 2 Then Label98.Caption = "+5"
If ii = 3 Then Label98.Caption = "-10"
If ii = 4 Then Label98.Caption = "+15"
If ii = 5 Then Label98.Caption = "Z"
If ii = 6 Then Label98.Caption = "+1"
If ii = 7 Then Label98.Caption = "B"
If ii = 8 Then Label98.Caption = "Z"
If ii = 9 Then Label98.Caption = "-1"
If ii = 10 Then Label98.Caption = "(-)"
If ii = 1 Then Label98.ToolTipText = "Decrease 5$"
If ii = 2 Then Label98.ToolTipText = "Increase 5$"
If ii = 3 Then Label98.ToolTipText = "Decrease 10$"
If ii = 4 Then Label98.ToolTipText = "Increase 15$"
If ii = 5 Then Label98.ToolTipText = "Zero Counter"
If ii = 6 Then Label98.ToolTipText = "Increase 1$"
If ii = 7 Then Label98.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label98.ToolTipText = "Zero Counter"
If ii = 9 Then Label98.ToolTipText = "Decrease 1$"
If ii = 10 Then Label98.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label99.Caption = "-5"
If ii = 2 Then Label99.Caption = "+5"
If ii = 3 Then Label99.Caption = "-10"
If ii = 4 Then Label99.Caption = "+15"
If ii = 5 Then Label99.Caption = "Z"
If ii = 6 Then Label99.Caption = "+1"
If ii = 7 Then Label99.Caption = "B"
If ii = 8 Then Label99.Caption = "Z"
If ii = 9 Then Label99.Caption = "-1"
If ii = 10 Then Label99.Caption = "(-)"
If ii = 1 Then Label99.ToolTipText = "Decrease 5$"
If ii = 2 Then Label99.ToolTipText = "Increase 5$"
If ii = 3 Then Label99.ToolTipText = "Decrease 10$"
If ii = 4 Then Label99.ToolTipText = "Increase 15$"
If ii = 5 Then Label99.ToolTipText = "Zero Counter"
If ii = 6 Then Label99.ToolTipText = "Increase 1$"
If ii = 7 Then Label99.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label99.ToolTipText = "Zero Counter"
If ii = 9 Then Label99.ToolTipText = "Decrease 1$"
If ii = 10 Then Label99.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label100.Caption = "-5"
If ii = 2 Then Label100.Caption = "+5"
If ii = 3 Then Label100.Caption = "-10"
If ii = 4 Then Label100.Caption = "+15"
If ii = 5 Then Label100.Caption = "Z"
If ii = 6 Then Label100.Caption = "+1"
If ii = 7 Then Label100.Caption = "B"
If ii = 8 Then Label100.Caption = "Z"
If ii = 9 Then Label100.Caption = "-1"
If ii = 10 Then Label100.Caption = "(-)"
If ii = 1 Then Label100.ToolTipText = "Decrease 5$"
If ii = 2 Then Label100.ToolTipText = "Increase 5$"
If ii = 3 Then Label100.ToolTipText = "Decrease 10$"
If ii = 4 Then Label100.ToolTipText = "Increase 15$"
If ii = 5 Then Label100.ToolTipText = "Zero Counter"
If ii = 6 Then Label100.ToolTipText = "Increase 1$"
If ii = 7 Then Label100.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label100.ToolTipText = "Zero Counter"
If ii = 9 Then Label100.ToolTipText = "Decrease 1$"
If ii = 10 Then Label100.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label101.Caption = "-5"
If ii = 2 Then Label101.Caption = "+5"
If ii = 3 Then Label101.Caption = "-10"
If ii = 4 Then Label101.Caption = "+15"
If ii = 5 Then Label101.Caption = "Z"
If ii = 6 Then Label101.Caption = "+1"
If ii = 7 Then Label101.Caption = "B"
If ii = 8 Then Label101.Caption = "Z"
If ii = 9 Then Label101.Caption = "-1"
If ii = 10 Then Label101.Caption = "(-)"
If ii = 1 Then Label101.ToolTipText = "Decrease 5$"
If ii = 2 Then Label101.ToolTipText = "Increase 5$"
If ii = 3 Then Label101.ToolTipText = "Decrease 10$"
If ii = 4 Then Label101.ToolTipText = "Increase 15$"
If ii = 5 Then Label101.ToolTipText = "Zero Counter"
If ii = 6 Then Label101.ToolTipText = "Increase 1$"
If ii = 7 Then Label101.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label101.ToolTipText = "Zero Counter"
If ii = 9 Then Label101.ToolTipText = "Decrease 1$"
If ii = 10 Then Label101.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label102.Caption = "-5"
If ii = 2 Then Label102.Caption = "+5"
If ii = 3 Then Label102.Caption = "-10"
If ii = 4 Then Label102.Caption = "+15"
If ii = 5 Then Label102.Caption = "Z"
If ii = 6 Then Label102.Caption = "+1"
If ii = 7 Then Label102.Caption = "B"
If ii = 8 Then Label102.Caption = "Z"
If ii = 9 Then Label102.Caption = "-1"
If ii = 10 Then Label102.Caption = "(-)"
If ii = 1 Then Label102.ToolTipText = "Decrease 5$"
If ii = 2 Then Label102.ToolTipText = "Increase 5$"
If ii = 3 Then Label102.ToolTipText = "Decrease 10$"
If ii = 4 Then Label102.ToolTipText = "Increase 15$"
If ii = 5 Then Label102.ToolTipText = "Zero Counter"
If ii = 6 Then Label102.ToolTipText = "Increase 1$"
If ii = 7 Then Label102.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label102.ToolTipText = "Zero Counter"
If ii = 9 Then Label102.ToolTipText = "Decrease 1$"
If ii = 10 Then Label102.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label103.Caption = "-5"
If ii = 2 Then Label103.Caption = "+5"
If ii = 3 Then Label103.Caption = "-10"
If ii = 4 Then Label103.Caption = "+15"
If ii = 5 Then Label103.Caption = "Z"
If ii = 6 Then Label103.Caption = "+1"
If ii = 7 Then Label103.Caption = "B"
If ii = 8 Then Label103.Caption = "Z"
If ii = 9 Then Label103.Caption = "-1"
If ii = 10 Then Label103.Caption = "(-)"
If ii = 1 Then Label103.ToolTipText = "Decrease 5$"
If ii = 2 Then Label103.ToolTipText = "Increase 5$"
If ii = 3 Then Label103.ToolTipText = "Decrease 10$"
If ii = 4 Then Label103.ToolTipText = "Increase 15$"
If ii = 5 Then Label103.ToolTipText = "Zero Counter"
If ii = 6 Then Label103.ToolTipText = "Increase 1$"
If ii = 7 Then Label103.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label103.ToolTipText = "Zero Counter"
If ii = 9 Then Label103.ToolTipText = "Decrease 1$"
If ii = 10 Then Label103.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label104.Caption = "-5"
If ii = 2 Then Label104.Caption = "+5"
If ii = 3 Then Label104.Caption = "-10"
If ii = 4 Then Label104.Caption = "+15"
If ii = 5 Then Label104.Caption = "Z"
If ii = 6 Then Label104.Caption = "+1"
If ii = 7 Then Label104.Caption = "B"
If ii = 8 Then Label104.Caption = "Z"
If ii = 9 Then Label104.Caption = "-1"
If ii = 10 Then Label104.Caption = "(-)"
If ii = 1 Then Label104.ToolTipText = "Decrease 5$"
If ii = 2 Then Label104.ToolTipText = "Increase 5$"
If ii = 3 Then Label104.ToolTipText = "Decrease 10$"
If ii = 4 Then Label104.ToolTipText = "Increase 15$"
If ii = 5 Then Label104.ToolTipText = "Zero Counter"
If ii = 6 Then Label104.ToolTipText = "Increase 1$"
If ii = 7 Then Label104.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label104.ToolTipText = "Zero Counter"
If ii = 9 Then Label104.ToolTipText = "Decrease 1$"
If ii = 10 Then Label104.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label105.Caption = "-5"
If ii = 2 Then Label105.Caption = "+5"
If ii = 3 Then Label105.Caption = "-10"
If ii = 4 Then Label105.Caption = "+15"
If ii = 5 Then Label105.Caption = "Z"
If ii = 6 Then Label105.Caption = "+1"
If ii = 7 Then Label105.Caption = "B"
If ii = 8 Then Label105.Caption = "Z"
If ii = 9 Then Label105.Caption = "-1"
If ii = 10 Then Label105.Caption = "(-)"
If ii = 1 Then Label105.ToolTipText = "Decrease 5$"
If ii = 2 Then Label105.ToolTipText = "Increase 5$"
If ii = 3 Then Label105.ToolTipText = "Decrease 10$"
If ii = 4 Then Label105.ToolTipText = "Increase 15$"
If ii = 5 Then Label105.ToolTipText = "Zero Counter"
If ii = 6 Then Label105.ToolTipText = "Increase 1$"
If ii = 7 Then Label105.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label105.ToolTipText = "Zero Counter"
If ii = 9 Then Label105.ToolTipText = "Decrease 1$"
If ii = 10 Then Label105.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label106.Caption = "-5"
If ii = 2 Then Label106.Caption = "+5"
If ii = 3 Then Label106.Caption = "-10"
If ii = 4 Then Label106.Caption = "+15"
If ii = 5 Then Label106.Caption = "Z"
If ii = 6 Then Label106.Caption = "+1"
If ii = 7 Then Label106.Caption = "B"
If ii = 8 Then Label106.Caption = "Z"
If ii = 9 Then Label106.Caption = "-1"
If ii = 10 Then Label106.Caption = "(-)"
If ii = 1 Then Label106.ToolTipText = "Decrease 5$"
If ii = 2 Then Label106.ToolTipText = "Increase 5$"
If ii = 3 Then Label106.ToolTipText = "Decrease 10$"
If ii = 4 Then Label106.ToolTipText = "Increase 15$"
If ii = 5 Then Label106.ToolTipText = "Zero Counter"
If ii = 6 Then Label106.ToolTipText = "Increase 1$"
If ii = 7 Then Label106.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label106.ToolTipText = "Zero Counter"
If ii = 9 Then Label106.ToolTipText = "Decrease 1$"
If ii = 10 Then Label106.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label107.Caption = "-5"
If ii = 2 Then Label107.Caption = "+5"
If ii = 3 Then Label107.Caption = "-10"
If ii = 4 Then Label107.Caption = "+15"
If ii = 5 Then Label107.Caption = "Z"
If ii = 6 Then Label107.Caption = "+1"
If ii = 7 Then Label107.Caption = "B"
If ii = 8 Then Label107.Caption = "Z"
If ii = 9 Then Label107.Caption = "-1"
If ii = 10 Then Label107.Caption = "(-)"
If ii = 1 Then Label107.ToolTipText = "Decrease 5$"
If ii = 2 Then Label107.ToolTipText = "Increase 5$"
If ii = 3 Then Label107.ToolTipText = "Decrease 10$"
If ii = 4 Then Label107.ToolTipText = "Increase 15$"
If ii = 5 Then Label107.ToolTipText = "Zero Counter"
If ii = 6 Then Label107.ToolTipText = "Increase 1$"
If ii = 7 Then Label107.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label107.ToolTipText = "Zero Counter"
If ii = 9 Then Label107.ToolTipText = "Decrease 1$"
If ii = 10 Then Label107.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label108.Caption = "-5"
If ii = 2 Then Label108.Caption = "+5"
If ii = 3 Then Label108.Caption = "-10"
If ii = 4 Then Label108.Caption = "+15"
If ii = 5 Then Label108.Caption = "Z"
If ii = 6 Then Label108.Caption = "+1"
If ii = 7 Then Label108.Caption = "B"
If ii = 8 Then Label108.Caption = "Z"
If ii = 9 Then Label108.Caption = "-1"
If ii = 10 Then Label108.Caption = "(-)"
If ii = 1 Then Label108.ToolTipText = "Decrease 5$"
If ii = 2 Then Label108.ToolTipText = "Increase 5$"
If ii = 3 Then Label108.ToolTipText = "Decrease 10$"
If ii = 4 Then Label108.ToolTipText = "Increase 15$"
If ii = 5 Then Label108.ToolTipText = "Zero Counter"
If ii = 6 Then Label108.ToolTipText = "Increase 1$"
If ii = 7 Then Label108.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label108.ToolTipText = "Zero Counter"
If ii = 9 Then Label108.ToolTipText = "Decrease 1$"
If ii = 10 Then Label108.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label109.Caption = "-5"
If ii = 2 Then Label109.Caption = "+5"
If ii = 3 Then Label109.Caption = "-10"
If ii = 4 Then Label109.Caption = "+15"
If ii = 5 Then Label109.Caption = "Z"
If ii = 6 Then Label109.Caption = "+1"
If ii = 7 Then Label109.Caption = "B"
If ii = 8 Then Label109.Caption = "Z"
If ii = 9 Then Label109.Caption = "-1"
If ii = 10 Then Label109.Caption = "(-)"
If ii = 1 Then Label109.ToolTipText = "Decrease 5$"
If ii = 2 Then Label109.ToolTipText = "Increase 5$"
If ii = 3 Then Label109.ToolTipText = "Decrease 10$"
If ii = 4 Then Label109.ToolTipText = "Increase 15$"
If ii = 5 Then Label109.ToolTipText = "Zero Counter"
If ii = 6 Then Label109.ToolTipText = "Increase 1$"
If ii = 7 Then Label109.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label109.ToolTipText = "Zero Counter"
If ii = 9 Then Label109.ToolTipText = "Decrease 1$"
If ii = 10 Then Label109.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label110.Caption = "-5"
If ii = 2 Then Label110.Caption = "+5"
If ii = 3 Then Label110.Caption = "-10"
If ii = 4 Then Label110.Caption = "+15"
If ii = 5 Then Label110.Caption = "Z"
If ii = 6 Then Label110.Caption = "+1"
If ii = 7 Then Label110.Caption = "B"
If ii = 8 Then Label110.Caption = "Z"
If ii = 9 Then Label110.Caption = "-1"
If ii = 10 Then Label110.Caption = "(-)"
If ii = 1 Then Label110.ToolTipText = "Decrease 5$"
If ii = 2 Then Label110.ToolTipText = "Increase 5$"
If ii = 3 Then Label110.ToolTipText = "Decrease 10$"
If ii = 4 Then Label110.ToolTipText = "Increase 15$"
If ii = 5 Then Label110.ToolTipText = "Zero Counter"
If ii = 6 Then Label110.ToolTipText = "Increase 1$"
If ii = 7 Then Label110.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label110.ToolTipText = "Zero Counter"
If ii = 9 Then Label110.ToolTipText = "Decrease 1$"
If ii = 10 Then Label110.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label111.Caption = "-5"
If ii = 2 Then Label111.Caption = "+5"
If ii = 3 Then Label111.Caption = "-10"
If ii = 4 Then Label111.Caption = "+15"
If ii = 5 Then Label111.Caption = "Z"
If ii = 6 Then Label111.Caption = "+1"
If ii = 7 Then Label111.Caption = "B"
If ii = 8 Then Label111.Caption = "Z"
If ii = 9 Then Label111.Caption = "-1"
If ii = 10 Then Label111.Caption = "(-)"
If ii = 1 Then Label111.ToolTipText = "Decrease 5$"
If ii = 2 Then Label111.ToolTipText = "Increase 5$"
If ii = 3 Then Label111.ToolTipText = "Decrease 10$"
If ii = 4 Then Label111.ToolTipText = "Increase 15$"
If ii = 5 Then Label111.ToolTipText = "Zero Counter"
If ii = 6 Then Label111.ToolTipText = "Increase 1$"
If ii = 7 Then Label111.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label111.ToolTipText = "Zero Counter"
If ii = 9 Then Label111.ToolTipText = "Decrease 1$"
If ii = 10 Then Label111.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label112.Caption = "-5"
If ii = 2 Then Label112.Caption = "+5"
If ii = 3 Then Label112.Caption = "-10"
If ii = 4 Then Label112.Caption = "+15"
If ii = 5 Then Label112.Caption = "Z"
If ii = 6 Then Label112.Caption = "+1"
If ii = 7 Then Label112.Caption = "B"
If ii = 8 Then Label112.Caption = "Z"
If ii = 9 Then Label112.Caption = "-1"
If ii = 10 Then Label112.Caption = "(-)"
If ii = 1 Then Label112.ToolTipText = "Decrease 5$"
If ii = 2 Then Label112.ToolTipText = "Increase 5$"
If ii = 3 Then Label112.ToolTipText = "Decrease 10$"
If ii = 4 Then Label112.ToolTipText = "Increase 15$"
If ii = 5 Then Label112.ToolTipText = "Zero Counter"
If ii = 6 Then Label112.ToolTipText = "Increase 1$"
If ii = 7 Then Label112.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label112.ToolTipText = "Zero Counter"
If ii = 9 Then Label112.ToolTipText = "Decrease 1$"
If ii = 10 Then Label112.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label113.Caption = "-5"
If ii = 2 Then Label113.Caption = "+5"
If ii = 3 Then Label113.Caption = "-10"
If ii = 4 Then Label113.Caption = "+15"
If ii = 5 Then Label113.Caption = "Z"
If ii = 6 Then Label113.Caption = "+1"
If ii = 7 Then Label113.Caption = "B"
If ii = 8 Then Label113.Caption = "Z"
If ii = 9 Then Label113.Caption = "-1"
If ii = 10 Then Label113.Caption = "(-)"
If ii = 1 Then Label113.ToolTipText = "Decrease 5$"
If ii = 2 Then Label113.ToolTipText = "Increase 5$"
If ii = 3 Then Label113.ToolTipText = "Decrease 10$"
If ii = 4 Then Label113.ToolTipText = "Increase 15$"
If ii = 5 Then Label113.ToolTipText = "Zero Counter"
If ii = 6 Then Label113.ToolTipText = "Increase 1$"
If ii = 7 Then Label113.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label113.ToolTipText = "Zero Counter"
If ii = 9 Then Label113.ToolTipText = "Decrease 1$"
If ii = 10 Then Label113.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label114.Caption = "-5"
If ii = 2 Then Label114.Caption = "+5"
If ii = 3 Then Label114.Caption = "-10"
If ii = 4 Then Label114.Caption = "+15"
If ii = 5 Then Label114.Caption = "Z"
If ii = 6 Then Label114.Caption = "+1"
If ii = 7 Then Label114.Caption = "B"
If ii = 8 Then Label114.Caption = "Z"
If ii = 9 Then Label114.Caption = "-1"
If ii = 10 Then Label114.Caption = "(-)"
If ii = 1 Then Label114.ToolTipText = "Decrease 5$"
If ii = 2 Then Label114.ToolTipText = "Increase 5$"
If ii = 3 Then Label114.ToolTipText = "Decrease 10$"
If ii = 4 Then Label114.ToolTipText = "Increase 15$"
If ii = 5 Then Label114.ToolTipText = "Zero Counter"
If ii = 6 Then Label114.ToolTipText = "Increase 1$"
If ii = 7 Then Label114.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label114.ToolTipText = "Zero Counter"
If ii = 9 Then Label114.ToolTipText = "Decrease 1$"
If ii = 10 Then Label114.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label115.Caption = "-5"
If ii = 2 Then Label115.Caption = "+5"
If ii = 3 Then Label115.Caption = "-10"
If ii = 4 Then Label115.Caption = "+15"
If ii = 5 Then Label115.Caption = "Z"
If ii = 6 Then Label115.Caption = "+1"
If ii = 7 Then Label115.Caption = "B"
If ii = 8 Then Label115.Caption = "Z"
If ii = 9 Then Label115.Caption = "-1"
If ii = 10 Then Label115.Caption = "(-)"
If ii = 1 Then Label115.ToolTipText = "Decrease 5$"
If ii = 2 Then Label115.ToolTipText = "Increase 5$"
If ii = 3 Then Label115.ToolTipText = "Decrease 10$"
If ii = 4 Then Label115.ToolTipText = "Increase 15$"
If ii = 5 Then Label115.ToolTipText = "Zero Counter"
If ii = 6 Then Label115.ToolTipText = "Increase 1$"
If ii = 7 Then Label115.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label115.ToolTipText = "Zero Counter"
If ii = 9 Then Label115.ToolTipText = "Decrease 1$"
If ii = 10 Then Label115.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label116.Caption = "-5"
If ii = 2 Then Label116.Caption = "+5"
If ii = 3 Then Label116.Caption = "-10"
If ii = 4 Then Label116.Caption = "+15"
If ii = 5 Then Label116.Caption = "Z"
If ii = 6 Then Label116.Caption = "+1"
If ii = 7 Then Label116.Caption = "B"
If ii = 8 Then Label116.Caption = "Z"
If ii = 9 Then Label116.Caption = "-1"
If ii = 10 Then Label116.Caption = "(-)"
If ii = 1 Then Label116.ToolTipText = "Decrease 5$"
If ii = 2 Then Label116.ToolTipText = "Increase 5$"
If ii = 3 Then Label116.ToolTipText = "Decrease 10$"
If ii = 4 Then Label116.ToolTipText = "Increase 15$"
If ii = 5 Then Label116.ToolTipText = "Zero Counter"
If ii = 6 Then Label116.ToolTipText = "Increase 1$"
If ii = 7 Then Label116.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label116.ToolTipText = "Zero Counter"
If ii = 9 Then Label116.ToolTipText = "Decrease 1$"
If ii = 10 Then Label116.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label117.Caption = "-5"
If ii = 2 Then Label117.Caption = "+5"
If ii = 3 Then Label117.Caption = "-10"
If ii = 4 Then Label117.Caption = "+15"
If ii = 5 Then Label117.Caption = "Z"
If ii = 6 Then Label117.Caption = "+1"
If ii = 7 Then Label117.Caption = "B"
If ii = 8 Then Label117.Caption = "Z"
If ii = 9 Then Label117.Caption = "-1"
If ii = 10 Then Label117.Caption = "(-)"
If ii = 1 Then Label117.ToolTipText = "Decrease 5$"
If ii = 2 Then Label117.ToolTipText = "Increase 5$"
If ii = 3 Then Label117.ToolTipText = "Decrease 10$"
If ii = 4 Then Label117.ToolTipText = "Increase 15$"
If ii = 5 Then Label117.ToolTipText = "Zero Counter"
If ii = 6 Then Label117.ToolTipText = "Increase 1$"
If ii = 7 Then Label117.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label117.ToolTipText = "Zero Counter"
If ii = 9 Then Label117.ToolTipText = "Decrease 1$"
If ii = 10 Then Label117.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label118.Caption = "-5"
If ii = 2 Then Label118.Caption = "+5"
If ii = 3 Then Label118.Caption = "-10"
If ii = 4 Then Label118.Caption = "+15"
If ii = 5 Then Label118.Caption = "Z"
If ii = 6 Then Label118.Caption = "+1"
If ii = 7 Then Label118.Caption = "B"
If ii = 8 Then Label118.Caption = "Z"
If ii = 9 Then Label118.Caption = "-1"
If ii = 10 Then Label118.Caption = "(-)"
If ii = 1 Then Label118.ToolTipText = "Decrease 5$"
If ii = 2 Then Label118.ToolTipText = "Increase 5$"
If ii = 3 Then Label118.ToolTipText = "Decrease 10$"
If ii = 4 Then Label118.ToolTipText = "Increase 15$"
If ii = 5 Then Label118.ToolTipText = "Zero Counter"
If ii = 6 Then Label118.ToolTipText = "Increase 1$"
If ii = 7 Then Label118.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label118.ToolTipText = "Zero Counter"
If ii = 9 Then Label118.ToolTipText = "Decrease 1$"
If ii = 10 Then Label118.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label119.Caption = "-5"
If ii = 2 Then Label119.Caption = "+5"
If ii = 3 Then Label119.Caption = "-10"
If ii = 4 Then Label119.Caption = "+15"
If ii = 5 Then Label119.Caption = "Z"
If ii = 6 Then Label119.Caption = "+1"
If ii = 7 Then Label119.Caption = "B"
If ii = 8 Then Label119.Caption = "Z"
If ii = 9 Then Label119.Caption = "-1"
If ii = 10 Then Label119.Caption = "(-)"
If ii = 1 Then Label119.ToolTipText = "Decrease 5$"
If ii = 2 Then Label119.ToolTipText = "Increase 5$"
If ii = 3 Then Label119.ToolTipText = "Decrease 10$"
If ii = 4 Then Label119.ToolTipText = "Increase 15$"
If ii = 5 Then Label119.ToolTipText = "Zero Counter"
If ii = 6 Then Label119.ToolTipText = "Increase 1$"
If ii = 7 Then Label119.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label119.ToolTipText = "Zero Counter"
If ii = 9 Then Label119.ToolTipText = "Decrease 1$"
If ii = 10 Then Label119.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label120.Caption = "-5"
If ii = 2 Then Label120.Caption = "+5"
If ii = 3 Then Label120.Caption = "-10"
If ii = 4 Then Label120.Caption = "+15"
If ii = 5 Then Label120.Caption = "Z"
If ii = 6 Then Label120.Caption = "+1"
If ii = 7 Then Label120.Caption = "B"
If ii = 8 Then Label120.Caption = "Z"
If ii = 9 Then Label120.Caption = "-1"
If ii = 10 Then Label120.Caption = "(-)"
If ii = 1 Then Label120.ToolTipText = "Decrease 5$"
If ii = 2 Then Label120.ToolTipText = "Increase 5$"
If ii = 3 Then Label120.ToolTipText = "Decrease 10$"
If ii = 4 Then Label120.ToolTipText = "Increase 15$"
If ii = 5 Then Label120.ToolTipText = "Zero Counter"
If ii = 6 Then Label120.ToolTipText = "Increase 1$"
If ii = 7 Then Label120.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label120.ToolTipText = "Zero Counter"
If ii = 9 Then Label120.ToolTipText = "Decrease 1$"
If ii = 10 Then Label120.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label121.Caption = "-5"
If ii = 2 Then Label121.Caption = "+5"
If ii = 3 Then Label121.Caption = "-10"
If ii = 4 Then Label121.Caption = "+15"
If ii = 5 Then Label121.Caption = "Z"
If ii = 6 Then Label121.Caption = "+1"
If ii = 7 Then Label121.Caption = "B"
If ii = 8 Then Label121.Caption = "Z"
If ii = 9 Then Label121.Caption = "-1"
If ii = 10 Then Label121.Caption = "(-)"
If ii = 1 Then Label121.ToolTipText = "Decrease 5$"
If ii = 2 Then Label121.ToolTipText = "Increase 5$"
If ii = 3 Then Label121.ToolTipText = "Decrease 10$"
If ii = 4 Then Label121.ToolTipText = "Increase 15$"
If ii = 5 Then Label121.ToolTipText = "Zero Counter"
If ii = 6 Then Label121.ToolTipText = "Increase 1$"
If ii = 7 Then Label121.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label121.ToolTipText = "Zero Counter"
If ii = 9 Then Label121.ToolTipText = "Decrease 1$"
If ii = 10 Then Label121.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label122.Caption = "-5"
If ii = 2 Then Label122.Caption = "+5"
If ii = 3 Then Label122.Caption = "-10"
If ii = 4 Then Label122.Caption = "+15"
If ii = 5 Then Label122.Caption = "Z"
If ii = 6 Then Label122.Caption = "+1"
If ii = 7 Then Label122.Caption = "B"
If ii = 8 Then Label122.Caption = "Z"
If ii = 9 Then Label122.Caption = "-1"
If ii = 10 Then Label122.Caption = "(-)"
If ii = 1 Then Label122.ToolTipText = "Decrease 5$"
If ii = 2 Then Label122.ToolTipText = "Increase 5$"
If ii = 3 Then Label122.ToolTipText = "Decrease 10$"
If ii = 4 Then Label122.ToolTipText = "Increase 15$"
If ii = 5 Then Label122.ToolTipText = "Zero Counter"
If ii = 6 Then Label122.ToolTipText = "Increase 1$"
If ii = 7 Then Label122.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label122.ToolTipText = "Zero Counter"
If ii = 9 Then Label122.ToolTipText = "Decrease 1$"
If ii = 10 Then Label122.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label123.Caption = "-5"
If ii = 2 Then Label123.Caption = "+5"
If ii = 3 Then Label123.Caption = "-10"
If ii = 4 Then Label123.Caption = "+15"
If ii = 5 Then Label123.Caption = "Z"
If ii = 6 Then Label123.Caption = "+1"
If ii = 7 Then Label123.Caption = "B"
If ii = 8 Then Label123.Caption = "Z"
If ii = 9 Then Label123.Caption = "-1"
If ii = 10 Then Label123.Caption = "(-)"
If ii = 1 Then Label123.ToolTipText = "Decrease 5$"
If ii = 2 Then Label123.ToolTipText = "Increase 5$"
If ii = 3 Then Label123.ToolTipText = "Decrease 10$"
If ii = 4 Then Label123.ToolTipText = "Increase 15$"
If ii = 5 Then Label123.ToolTipText = "Zero Counter"
If ii = 6 Then Label123.ToolTipText = "Increase 1$"
If ii = 7 Then Label123.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label123.ToolTipText = "Zero Counter"
If ii = 9 Then Label123.ToolTipText = "Decrease 1$"
If ii = 10 Then Label123.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label124.Caption = "-5"
If ii = 2 Then Label124.Caption = "+5"
If ii = 3 Then Label124.Caption = "-10"
If ii = 4 Then Label124.Caption = "+15"
If ii = 5 Then Label124.Caption = "Z"
If ii = 6 Then Label124.Caption = "+1"
If ii = 7 Then Label124.Caption = "B"
If ii = 8 Then Label124.Caption = "Z"
If ii = 9 Then Label124.Caption = "-1"
If ii = 10 Then Label124.Caption = "(-)"
If ii = 1 Then Label124.ToolTipText = "Decrease 5$"
If ii = 2 Then Label124.ToolTipText = "Increase 5$"
If ii = 3 Then Label124.ToolTipText = "Decrease 10$"
If ii = 4 Then Label124.ToolTipText = "Increase 15$"
If ii = 5 Then Label124.ToolTipText = "Zero Counter"
If ii = 6 Then Label124.ToolTipText = "Increase 1$"
If ii = 7 Then Label124.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label124.ToolTipText = "Zero Counter"
If ii = 9 Then Label124.ToolTipText = "Decrease 1$"
If ii = 10 Then Label124.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label125.Caption = "-5"
If ii = 2 Then Label125.Caption = "+5"
If ii = 3 Then Label125.Caption = "-10"
If ii = 4 Then Label125.Caption = "+15"
If ii = 5 Then Label125.Caption = "Z"
If ii = 6 Then Label125.Caption = "+1"
If ii = 7 Then Label125.Caption = "B"
If ii = 8 Then Label125.Caption = "Z"
If ii = 9 Then Label125.Caption = "-1"
If ii = 10 Then Label125.Caption = "(-)"
If ii = 1 Then Label125.ToolTipText = "Decrease 5$"
If ii = 2 Then Label125.ToolTipText = "Increase 5$"
If ii = 3 Then Label125.ToolTipText = "Decrease 10$"
If ii = 4 Then Label125.ToolTipText = "Increase 15$"
If ii = 5 Then Label125.ToolTipText = "Zero Counter"
If ii = 6 Then Label125.ToolTipText = "Increase 1$"
If ii = 7 Then Label125.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label125.ToolTipText = "Zero Counter"
If ii = 9 Then Label125.ToolTipText = "Decrease 1$"
If ii = 10 Then Label125.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label126.Caption = "-5"
If ii = 2 Then Label126.Caption = "+5"
If ii = 3 Then Label126.Caption = "-10"
If ii = 4 Then Label126.Caption = "+15"
If ii = 5 Then Label126.Caption = "Z"
If ii = 6 Then Label126.Caption = "+1"
If ii = 7 Then Label126.Caption = "B"
If ii = 8 Then Label126.Caption = "Z"
If ii = 9 Then Label126.Caption = "-1"
If ii = 10 Then Label126.Caption = "(-)"
If ii = 1 Then Label126.ToolTipText = "Decrease 5$"
If ii = 2 Then Label126.ToolTipText = "Increase 5$"
If ii = 3 Then Label126.ToolTipText = "Decrease 10$"
If ii = 4 Then Label126.ToolTipText = "Increase 15$"
If ii = 5 Then Label126.ToolTipText = "Zero Counter"
If ii = 6 Then Label126.ToolTipText = "Increase 1$"
If ii = 7 Then Label126.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label126.ToolTipText = "Zero Counter"
If ii = 9 Then Label126.ToolTipText = "Decrease 1$"
If ii = 10 Then Label126.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label127.Caption = "-5"
If ii = 2 Then Label127.Caption = "+5"
If ii = 3 Then Label127.Caption = "-10"
If ii = 4 Then Label127.Caption = "+15"
If ii = 5 Then Label127.Caption = "Z"
If ii = 6 Then Label127.Caption = "+1"
If ii = 7 Then Label127.Caption = "B"
If ii = 8 Then Label127.Caption = "Z"
If ii = 9 Then Label127.Caption = "-1"
If ii = 10 Then Label127.Caption = "(-)"
If ii = 1 Then Label127.ToolTipText = "Decrease 5$"
If ii = 2 Then Label127.ToolTipText = "Increase 5$"
If ii = 3 Then Label127.ToolTipText = "Decrease 10$"
If ii = 4 Then Label127.ToolTipText = "Increase 15$"
If ii = 5 Then Label127.ToolTipText = "Zero Counter"
If ii = 6 Then Label127.ToolTipText = "Increase 1$"
If ii = 7 Then Label127.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label127.ToolTipText = "Zero Counter"
If ii = 9 Then Label127.ToolTipText = "Decrease 1$"
If ii = 10 Then Label127.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label128.Caption = "-5"
If ii = 2 Then Label128.Caption = "+5"
If ii = 3 Then Label128.Caption = "-10"
If ii = 4 Then Label128.Caption = "+15"
If ii = 5 Then Label128.Caption = "Z"
If ii = 6 Then Label128.Caption = "+1"
If ii = 7 Then Label128.Caption = "B"
If ii = 8 Then Label128.Caption = "Z"
If ii = 9 Then Label128.Caption = "-1"
If ii = 10 Then Label128.Caption = "(-)"
If ii = 1 Then Label128.ToolTipText = "Decrease 5$"
If ii = 2 Then Label128.ToolTipText = "Increase 5$"
If ii = 3 Then Label128.ToolTipText = "Decrease 10$"
If ii = 4 Then Label128.ToolTipText = "Increase 15$"
If ii = 5 Then Label128.ToolTipText = "Zero Counter"
If ii = 6 Then Label128.ToolTipText = "Increase 1$"
If ii = 7 Then Label128.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label128.ToolTipText = "Zero Counter"
If ii = 9 Then Label128.ToolTipText = "Decrease 1$"
If ii = 10 Then Label128.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label129.Caption = "-5"
If ii = 2 Then Label129.Caption = "+5"
If ii = 3 Then Label129.Caption = "-10"
If ii = 4 Then Label129.Caption = "+15"
If ii = 5 Then Label129.Caption = "Z"
If ii = 6 Then Label129.Caption = "+1"
If ii = 7 Then Label129.Caption = "B"
If ii = 8 Then Label129.Caption = "Z"
If ii = 9 Then Label129.Caption = "-1"
If ii = 10 Then Label129.Caption = "(-)"
If ii = 1 Then Label129.ToolTipText = "Decrease 5$"
If ii = 2 Then Label129.ToolTipText = "Increase 5$"
If ii = 3 Then Label129.ToolTipText = "Decrease 10$"
If ii = 4 Then Label129.ToolTipText = "Increase 15$"
If ii = 5 Then Label129.ToolTipText = "Zero Counter"
If ii = 6 Then Label129.ToolTipText = "Increase 1$"
If ii = 7 Then Label129.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label129.ToolTipText = "Zero Counter"
If ii = 9 Then Label129.ToolTipText = "Decrease 1$"
If ii = 10 Then Label129.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label130.Caption = "-5"
If ii = 2 Then Label130.Caption = "+5"
If ii = 3 Then Label130.Caption = "-10"
If ii = 4 Then Label130.Caption = "+15"
If ii = 5 Then Label130.Caption = "Z"
If ii = 6 Then Label130.Caption = "+1"
If ii = 7 Then Label130.Caption = "B"
If ii = 8 Then Label130.Caption = "Z"
If ii = 9 Then Label130.Caption = "-1"
If ii = 10 Then Label130.Caption = "(-)"
If ii = 1 Then Label130.ToolTipText = "Decrease 5$"
If ii = 2 Then Label130.ToolTipText = "Increase 5$"
If ii = 3 Then Label130.ToolTipText = "Decrease 10$"
If ii = 4 Then Label130.ToolTipText = "Increase 15$"
If ii = 5 Then Label130.ToolTipText = "Zero Counter"
If ii = 6 Then Label130.ToolTipText = "Increase 1$"
If ii = 7 Then Label130.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label130.ToolTipText = "Zero Counter"
If ii = 9 Then Label130.ToolTipText = "Decrease 1$"
If ii = 10 Then Label130.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label131.Caption = "-5"
If ii = 2 Then Label131.Caption = "+5"
If ii = 3 Then Label131.Caption = "-10"
If ii = 4 Then Label131.Caption = "+15"
If ii = 5 Then Label131.Caption = "Z"
If ii = 6 Then Label131.Caption = "+1"
If ii = 7 Then Label131.Caption = "B"
If ii = 8 Then Label131.Caption = "Z"
If ii = 9 Then Label131.Caption = "-1"
If ii = 10 Then Label131.Caption = "(-)"
If ii = 1 Then Label131.ToolTipText = "Decrease 5$"
If ii = 2 Then Label131.ToolTipText = "Increase 5$"
If ii = 3 Then Label131.ToolTipText = "Decrease 10$"
If ii = 4 Then Label131.ToolTipText = "Increase 15$"
If ii = 5 Then Label131.ToolTipText = "Zero Counter"
If ii = 6 Then Label131.ToolTipText = "Increase 1$"
If ii = 7 Then Label131.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label131.ToolTipText = "Zero Counter"
If ii = 9 Then Label131.ToolTipText = "Decrease 1$"
If ii = 10 Then Label131.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label132.Caption = "-5"
If ii = 2 Then Label132.Caption = "+5"
If ii = 3 Then Label132.Caption = "-10"
If ii = 4 Then Label132.Caption = "+15"
If ii = 5 Then Label132.Caption = "Z"
If ii = 6 Then Label132.Caption = "+1"
If ii = 7 Then Label132.Caption = "B"
If ii = 8 Then Label132.Caption = "Z"
If ii = 9 Then Label132.Caption = "-1"
If ii = 10 Then Label132.Caption = "(-)"
If ii = 1 Then Label132.ToolTipText = "Decrease 5$"
If ii = 2 Then Label132.ToolTipText = "Increase 5$"
If ii = 3 Then Label132.ToolTipText = "Decrease 10$"
If ii = 4 Then Label132.ToolTipText = "Increase 15$"
If ii = 5 Then Label132.ToolTipText = "Zero Counter"
If ii = 6 Then Label132.ToolTipText = "Increase 1$"
If ii = 7 Then Label132.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label132.ToolTipText = "Zero Counter"
If ii = 9 Then Label132.ToolTipText = "Decrease 1$"
If ii = 10 Then Label132.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label133.Caption = "-5"
If ii = 2 Then Label133.Caption = "+5"
If ii = 3 Then Label133.Caption = "-10"
If ii = 4 Then Label133.Caption = "+15"
If ii = 5 Then Label133.Caption = "Z"
If ii = 6 Then Label133.Caption = "+1"
If ii = 7 Then Label133.Caption = "B"
If ii = 8 Then Label133.Caption = "Z"
If ii = 9 Then Label133.Caption = "-1"
If ii = 10 Then Label133.Caption = "(-)"
If ii = 1 Then Label133.ToolTipText = "Decrease 5$"
If ii = 2 Then Label133.ToolTipText = "Increase 5$"
If ii = 3 Then Label133.ToolTipText = "Decrease 10$"
If ii = 4 Then Label133.ToolTipText = "Increase 15$"
If ii = 5 Then Label133.ToolTipText = "Zero Counter"
If ii = 6 Then Label133.ToolTipText = "Increase 1$"
If ii = 7 Then Label133.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label133.ToolTipText = "Zero Counter"
If ii = 9 Then Label133.ToolTipText = "Decrease 1$"
If ii = 10 Then Label133.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label134.Caption = "-5"
If ii = 2 Then Label134.Caption = "+5"
If ii = 3 Then Label134.Caption = "-10"
If ii = 4 Then Label134.Caption = "+15"
If ii = 5 Then Label134.Caption = "Z"
If ii = 6 Then Label134.Caption = "+1"
If ii = 7 Then Label134.Caption = "B"
If ii = 8 Then Label134.Caption = "Z"
If ii = 9 Then Label134.Caption = "-1"
If ii = 10 Then Label134.Caption = "(-)"
If ii = 1 Then Label134.ToolTipText = "Decrease 5$"
If ii = 2 Then Label134.ToolTipText = "Increase 5$"
If ii = 3 Then Label134.ToolTipText = "Decrease 10$"
If ii = 4 Then Label134.ToolTipText = "Increase 15$"
If ii = 5 Then Label134.ToolTipText = "Zero Counter"
If ii = 6 Then Label134.ToolTipText = "Increase 1$"
If ii = 7 Then Label134.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label134.ToolTipText = "Zero Counter"
If ii = 9 Then Label134.ToolTipText = "Decrease 1$"
If ii = 10 Then Label134.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label135.Caption = "-5"
If ii = 2 Then Label135.Caption = "+5"
If ii = 3 Then Label135.Caption = "-10"
If ii = 4 Then Label135.Caption = "+15"
If ii = 5 Then Label135.Caption = "Z"
If ii = 6 Then Label135.Caption = "+1"
If ii = 7 Then Label135.Caption = "B"
If ii = 8 Then Label135.Caption = "Z"
If ii = 9 Then Label135.Caption = "-1"
If ii = 10 Then Label135.Caption = "(-)"
If ii = 1 Then Label135.ToolTipText = "Decrease 5$"
If ii = 2 Then Label135.ToolTipText = "Increase 5$"
If ii = 3 Then Label135.ToolTipText = "Decrease 10$"
If ii = 4 Then Label135.ToolTipText = "Increase 15$"
If ii = 5 Then Label135.ToolTipText = "Zero Counter"
If ii = 6 Then Label135.ToolTipText = "Increase 1$"
If ii = 7 Then Label135.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label135.ToolTipText = "Zero Counter"
If ii = 9 Then Label135.ToolTipText = "Decrease 1$"
If ii = 10 Then Label135.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label136.Caption = "-5"
If ii = 2 Then Label136.Caption = "+5"
If ii = 3 Then Label136.Caption = "-10"
If ii = 4 Then Label136.Caption = "+15"
If ii = 5 Then Label136.Caption = "Z"
If ii = 6 Then Label136.Caption = "+1"
If ii = 7 Then Label136.Caption = "B"
If ii = 8 Then Label136.Caption = "Z"
If ii = 9 Then Label136.Caption = "-1"
If ii = 10 Then Label136.Caption = "(-)"
If ii = 1 Then Label136.ToolTipText = "Decrease 5$"
If ii = 2 Then Label136.ToolTipText = "Increase 5$"
If ii = 3 Then Label136.ToolTipText = "Decrease 10$"
If ii = 4 Then Label136.ToolTipText = "Increase 15$"
If ii = 5 Then Label136.ToolTipText = "Zero Counter"
If ii = 6 Then Label136.ToolTipText = "Increase 1$"
If ii = 7 Then Label136.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label136.ToolTipText = "Zero Counter"
If ii = 9 Then Label136.ToolTipText = "Decrease 1$"
If ii = 10 Then Label136.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label137.Caption = "-5"
If ii = 2 Then Label137.Caption = "+5"
If ii = 3 Then Label137.Caption = "-10"
If ii = 4 Then Label137.Caption = "+15"
If ii = 5 Then Label137.Caption = "Z"
If ii = 6 Then Label137.Caption = "+1"
If ii = 7 Then Label137.Caption = "B"
If ii = 8 Then Label137.Caption = "Z"
If ii = 9 Then Label137.Caption = "-1"
If ii = 10 Then Label137.Caption = "(-)"
If ii = 1 Then Label137.ToolTipText = "Decrease 5$"
If ii = 2 Then Label137.ToolTipText = "Increase 5$"
If ii = 3 Then Label137.ToolTipText = "Decrease 10$"
If ii = 4 Then Label137.ToolTipText = "Increase 15$"
If ii = 5 Then Label137.ToolTipText = "Zero Counter"
If ii = 6 Then Label137.ToolTipText = "Increase 1$"
If ii = 7 Then Label137.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label137.ToolTipText = "Zero Counter"
If ii = 9 Then Label137.ToolTipText = "Decrease 1$"
If ii = 10 Then Label137.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label138.Caption = "-5"
If ii = 2 Then Label138.Caption = "+5"
If ii = 3 Then Label138.Caption = "-10"
If ii = 4 Then Label138.Caption = "+15"
If ii = 5 Then Label138.Caption = "Z"
If ii = 6 Then Label138.Caption = "+1"
If ii = 7 Then Label138.Caption = "B"
If ii = 8 Then Label138.Caption = "Z"
If ii = 9 Then Label138.Caption = "-1"
If ii = 10 Then Label138.Caption = "(-)"
If ii = 1 Then Label138.ToolTipText = "Decrease 5$"
If ii = 2 Then Label138.ToolTipText = "Increase 5$"
If ii = 3 Then Label138.ToolTipText = "Decrease 10$"
If ii = 4 Then Label138.ToolTipText = "Increase 15$"
If ii = 5 Then Label138.ToolTipText = "Zero Counter"
If ii = 6 Then Label138.ToolTipText = "Increase 1$"
If ii = 7 Then Label138.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label138.ToolTipText = "Zero Counter"
If ii = 9 Then Label138.ToolTipText = "Decrease 1$"
If ii = 10 Then Label138.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label139.Caption = "-5"
If ii = 2 Then Label139.Caption = "+5"
If ii = 3 Then Label139.Caption = "-10"
If ii = 4 Then Label139.Caption = "+15"
If ii = 5 Then Label139.Caption = "Z"
If ii = 6 Then Label139.Caption = "+1"
If ii = 7 Then Label139.Caption = "B"
If ii = 8 Then Label139.Caption = "Z"
If ii = 9 Then Label139.Caption = "-1"
If ii = 10 Then Label139.Caption = "(-)"
If ii = 1 Then Label139.ToolTipText = "Decrease 5$"
If ii = 2 Then Label139.ToolTipText = "Increase 5$"
If ii = 3 Then Label139.ToolTipText = "Decrease 10$"
If ii = 4 Then Label139.ToolTipText = "Increase 15$"
If ii = 5 Then Label139.ToolTipText = "Zero Counter"
If ii = 6 Then Label139.ToolTipText = "Increase 1$"
If ii = 7 Then Label139.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label139.ToolTipText = "Zero Counter"
If ii = 9 Then Label139.ToolTipText = "Decrease 1$"
If ii = 10 Then Label139.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label140.Caption = "-5"
If ii = 2 Then Label140.Caption = "+5"
If ii = 3 Then Label140.Caption = "-10"
If ii = 4 Then Label140.Caption = "+15"
If ii = 5 Then Label140.Caption = "Z"
If ii = 6 Then Label140.Caption = "+1"
If ii = 7 Then Label140.Caption = "B"
If ii = 8 Then Label140.Caption = "Z"
If ii = 9 Then Label140.Caption = "-1"
If ii = 10 Then Label140.Caption = "(-)"
If ii = 1 Then Label140.ToolTipText = "Decrease 5$"
If ii = 2 Then Label140.ToolTipText = "Increase 5$"
If ii = 3 Then Label140.ToolTipText = "Decrease 10$"
If ii = 4 Then Label140.ToolTipText = "Increase 15$"
If ii = 5 Then Label140.ToolTipText = "Zero Counter"
If ii = 6 Then Label140.ToolTipText = "Increase 1$"
If ii = 7 Then Label140.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label140.ToolTipText = "Zero Counter"
If ii = 9 Then Label140.ToolTipText = "Decrease 1$"
If ii = 10 Then Label140.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label141.Caption = "-5"
If ii = 2 Then Label141.Caption = "+5"
If ii = 3 Then Label141.Caption = "-10"
If ii = 4 Then Label141.Caption = "+15"
If ii = 5 Then Label141.Caption = "Z"
If ii = 6 Then Label141.Caption = "+1"
If ii = 7 Then Label141.Caption = "B"
If ii = 8 Then Label141.Caption = "Z"
If ii = 9 Then Label141.Caption = "-1"
If ii = 10 Then Label141.Caption = "(-)"
If ii = 1 Then Label141.ToolTipText = "Decrease 5$"
If ii = 2 Then Label141.ToolTipText = "Increase 5$"
If ii = 3 Then Label141.ToolTipText = "Decrease 10$"
If ii = 4 Then Label141.ToolTipText = "Increase 15$"
If ii = 5 Then Label141.ToolTipText = "Zero Counter"
If ii = 6 Then Label141.ToolTipText = "Increase 1$"
If ii = 7 Then Label141.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label141.ToolTipText = "Zero Counter"
If ii = 9 Then Label141.ToolTipText = "Decrease 1$"
If ii = 10 Then Label141.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label142.Caption = "-5"
If ii = 2 Then Label142.Caption = "+5"
If ii = 3 Then Label142.Caption = "-10"
If ii = 4 Then Label142.Caption = "+15"
If ii = 5 Then Label142.Caption = "Z"
If ii = 6 Then Label142.Caption = "+1"
If ii = 7 Then Label142.Caption = "B"
If ii = 8 Then Label142.Caption = "Z"
If ii = 9 Then Label142.Caption = "-1"
If ii = 10 Then Label142.Caption = "(-)"
If ii = 1 Then Label142.ToolTipText = "Decrease 5$"
If ii = 2 Then Label142.ToolTipText = "Increase 5$"
If ii = 3 Then Label142.ToolTipText = "Decrease 10$"
If ii = 4 Then Label142.ToolTipText = "Increase 15$"
If ii = 5 Then Label142.ToolTipText = "Zero Counter"
If ii = 6 Then Label142.ToolTipText = "Increase 1$"
If ii = 7 Then Label142.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label142.ToolTipText = "Zero Counter"
If ii = 9 Then Label142.ToolTipText = "Decrease 1$"
If ii = 10 Then Label142.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label143.Caption = "-5"
If ii = 2 Then Label143.Caption = "+5"
If ii = 3 Then Label143.Caption = "-10"
If ii = 4 Then Label143.Caption = "+15"
If ii = 5 Then Label143.Caption = "Z"
If ii = 6 Then Label143.Caption = "+1"
If ii = 7 Then Label143.Caption = "B"
If ii = 8 Then Label143.Caption = "Z"
If ii = 9 Then Label143.Caption = "-1"
If ii = 10 Then Label143.Caption = "(-)"
If ii = 1 Then Label143.ToolTipText = "Decrease 5$"
If ii = 2 Then Label143.ToolTipText = "Increase 5$"
If ii = 3 Then Label143.ToolTipText = "Decrease 10$"
If ii = 4 Then Label143.ToolTipText = "Increase 15$"
If ii = 5 Then Label143.ToolTipText = "Zero Counter"
If ii = 6 Then Label143.ToolTipText = "Increase 1$"
If ii = 7 Then Label143.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label143.ToolTipText = "Zero Counter"
If ii = 9 Then Label143.ToolTipText = "Decrease 1$"
If ii = 10 Then Label143.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label144.Caption = "-5"
If ii = 2 Then Label144.Caption = "+5"
If ii = 3 Then Label144.Caption = "-10"
If ii = 4 Then Label144.Caption = "+15"
If ii = 5 Then Label144.Caption = "Z"
If ii = 6 Then Label144.Caption = "+1"
If ii = 7 Then Label144.Caption = "B"
If ii = 8 Then Label144.Caption = "Z"
If ii = 9 Then Label144.Caption = "-1"
If ii = 10 Then Label144.Caption = "(-)"
If ii = 1 Then Label144.ToolTipText = "Decrease 5$"
If ii = 2 Then Label144.ToolTipText = "Increase 5$"
If ii = 3 Then Label144.ToolTipText = "Decrease 10$"
If ii = 4 Then Label144.ToolTipText = "Increase 15$"
If ii = 5 Then Label144.ToolTipText = "Zero Counter"
If ii = 6 Then Label144.ToolTipText = "Increase 1$"
If ii = 7 Then Label144.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label144.ToolTipText = "Zero Counter"
If ii = 9 Then Label144.ToolTipText = "Decrease 1$"
If ii = 10 Then Label144.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label145.Caption = "-5"
If ii = 2 Then Label145.Caption = "+5"
If ii = 3 Then Label145.Caption = "-10"
If ii = 4 Then Label145.Caption = "+15"
If ii = 5 Then Label145.Caption = "Z"
If ii = 6 Then Label145.Caption = "+1"
If ii = 7 Then Label145.Caption = "B"
If ii = 8 Then Label145.Caption = "Z"
If ii = 9 Then Label145.Caption = "-1"
If ii = 10 Then Label145.Caption = "(-)"
If ii = 1 Then Label145.ToolTipText = "Decrease 5$"
If ii = 2 Then Label145.ToolTipText = "Increase 5$"
If ii = 3 Then Label145.ToolTipText = "Decrease 10$"
If ii = 4 Then Label145.ToolTipText = "Increase 15$"
If ii = 5 Then Label145.ToolTipText = "Zero Counter"
If ii = 6 Then Label145.ToolTipText = "Increase 1$"
If ii = 7 Then Label145.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label145.ToolTipText = "Zero Counter"
If ii = 9 Then Label145.ToolTipText = "Decrease 1$"
If ii = 10 Then Label145.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label146.Caption = "-5"
If ii = 2 Then Label146.Caption = "+5"
If ii = 3 Then Label146.Caption = "-10"
If ii = 4 Then Label146.Caption = "+15"
If ii = 5 Then Label146.Caption = "Z"
If ii = 6 Then Label146.Caption = "+1"
If ii = 7 Then Label146.Caption = "B"
If ii = 8 Then Label146.Caption = "Z"
If ii = 9 Then Label146.Caption = "-1"
If ii = 10 Then Label146.Caption = "(-)"
If ii = 1 Then Label146.ToolTipText = "Decrease 5$"
If ii = 2 Then Label146.ToolTipText = "Increase 5$"
If ii = 3 Then Label146.ToolTipText = "Decrease 10$"
If ii = 4 Then Label146.ToolTipText = "Increase 15$"
If ii = 5 Then Label146.ToolTipText = "Zero Counter"
If ii = 6 Then Label146.ToolTipText = "Increase 1$"
If ii = 7 Then Label146.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label146.ToolTipText = "Zero Counter"
If ii = 9 Then Label146.ToolTipText = "Decrease 1$"
If ii = 10 Then Label146.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label147.Caption = "-5"
If ii = 2 Then Label147.Caption = "+5"
If ii = 3 Then Label147.Caption = "-10"
If ii = 4 Then Label147.Caption = "+15"
If ii = 5 Then Label147.Caption = "Z"
If ii = 6 Then Label147.Caption = "+1"
If ii = 7 Then Label147.Caption = "B"
If ii = 8 Then Label147.Caption = "Z"
If ii = 9 Then Label147.Caption = "-1"
If ii = 10 Then Label147.Caption = "(-)"
If ii = 1 Then Label147.ToolTipText = "Decrease 5$"
If ii = 2 Then Label147.ToolTipText = "Increase 5$"
If ii = 3 Then Label147.ToolTipText = "Decrease 10$"
If ii = 4 Then Label147.ToolTipText = "Increase 15$"
If ii = 5 Then Label147.ToolTipText = "Zero Counter"
If ii = 6 Then Label147.ToolTipText = "Increase 1$"
If ii = 7 Then Label147.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label147.ToolTipText = "Zero Counter"
If ii = 9 Then Label147.ToolTipText = "Decrease 1$"
If ii = 10 Then Label147.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label148.Caption = "-5"
If ii = 2 Then Label148.Caption = "+5"
If ii = 3 Then Label148.Caption = "-10"
If ii = 4 Then Label148.Caption = "+15"
If ii = 5 Then Label148.Caption = "Z"
If ii = 6 Then Label148.Caption = "+1"
If ii = 7 Then Label148.Caption = "B"
If ii = 8 Then Label148.Caption = "Z"
If ii = 9 Then Label148.Caption = "-1"
If ii = 10 Then Label148.Caption = "(-)"
If ii = 1 Then Label148.ToolTipText = "Decrease 5$"
If ii = 2 Then Label148.ToolTipText = "Increase 5$"
If ii = 3 Then Label148.ToolTipText = "Decrease 10$"
If ii = 4 Then Label148.ToolTipText = "Increase 15$"
If ii = 5 Then Label148.ToolTipText = "Zero Counter"
If ii = 6 Then Label148.ToolTipText = "Increase 1$"
If ii = 7 Then Label148.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label148.ToolTipText = "Zero Counter"
If ii = 9 Then Label148.ToolTipText = "Decrease 1$"
If ii = 10 Then Label148.ToolTipText = "Randomize Decrease"
Next_Label
End Sub
Private Sub Next_Label()
RND_NEXT
If ii = 1 Then Label149.Caption = "-5"
If ii = 2 Then Label149.Caption = "+5"
If ii = 3 Then Label149.Caption = "-10"
If ii = 4 Then Label149.Caption = "+15"
If ii = 5 Then Label149.Caption = "Z"
If ii = 6 Then Label149.Caption = "+1"
If ii = 7 Then Label149.Caption = "B"
If ii = 8 Then Label149.Caption = "Z"
If ii = 9 Then Label149.Caption = "-1"
If ii = 10 Then Label149.Caption = "(-)"
If ii = 1 Then Label149.ToolTipText = "Decrease 5$"
If ii = 2 Then Label149.ToolTipText = "Increase 5$"
If ii = 3 Then Label149.ToolTipText = "Decrease 10$"
If ii = 4 Then Label149.ToolTipText = "Increase 15$"
If ii = 5 Then Label149.ToolTipText = "Zero Counter"
If ii = 6 Then Label149.ToolTipText = "Increase 1$"
If ii = 7 Then Label149.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label149.ToolTipText = "Zero Counter"
If ii = 9 Then Label149.ToolTipText = "Decrease 1$"
If ii = 10 Then Label149.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label150.Caption = "-5"
If ii = 2 Then Label150.Caption = "+5"
If ii = 3 Then Label150.Caption = "-10"
If ii = 4 Then Label150.Caption = "+15"
If ii = 5 Then Label150.Caption = "Z"
If ii = 6 Then Label150.Caption = "+1"
If ii = 7 Then Label150.Caption = "B"
If ii = 8 Then Label150.Caption = "Z"
If ii = 9 Then Label150.Caption = "-1"
If ii = 10 Then Label150.Caption = "(-)"
If ii = 1 Then Label150.ToolTipText = "Decrease 5$"
If ii = 2 Then Label150.ToolTipText = "Increase 5$"
If ii = 3 Then Label150.ToolTipText = "Decrease 10$"
If ii = 4 Then Label150.ToolTipText = "Increase 15$"
If ii = 5 Then Label150.ToolTipText = "Zero Counter"
If ii = 6 Then Label150.ToolTipText = "Increase 1$"
If ii = 7 Then Label150.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label150.ToolTipText = "Zero Counter"
If ii = 9 Then Label150.ToolTipText = "Decrease 1$"
If ii = 10 Then Label150.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label151.Caption = "-5"
If ii = 2 Then Label151.Caption = "+5"
If ii = 3 Then Label151.Caption = "-10"
If ii = 4 Then Label151.Caption = "+15"
If ii = 5 Then Label151.Caption = "Z"
If ii = 6 Then Label151.Caption = "+1"
If ii = 7 Then Label151.Caption = "B"
If ii = 8 Then Label151.Caption = "Z"
If ii = 9 Then Label151.Caption = "-1"
If ii = 10 Then Label151.Caption = "(-)"
If ii = 1 Then Label151.ToolTipText = "Decrease 5$"
If ii = 2 Then Label151.ToolTipText = "Increase 5$"
If ii = 3 Then Label151.ToolTipText = "Decrease 10$"
If ii = 4 Then Label151.ToolTipText = "Increase 15$"
If ii = 5 Then Label151.ToolTipText = "Zero Counter"
If ii = 6 Then Label151.ToolTipText = "Increase 1$"
If ii = 7 Then Label151.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label151.ToolTipText = "Zero Counter"
If ii = 9 Then Label151.ToolTipText = "Decrease 1$"
If ii = 10 Then Label151.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label152.Caption = "-5"
If ii = 2 Then Label152.Caption = "+5"
If ii = 3 Then Label152.Caption = "-10"
If ii = 4 Then Label152.Caption = "+15"
If ii = 5 Then Label152.Caption = "Z"
If ii = 6 Then Label152.Caption = "+1"
If ii = 7 Then Label152.Caption = "B"
If ii = 8 Then Label152.Caption = "Z"
If ii = 9 Then Label152.Caption = "-1"
If ii = 10 Then Label152.Caption = "(-)"
If ii = 1 Then Label152.ToolTipText = "Decrease 5$"
If ii = 2 Then Label152.ToolTipText = "Increase 5$"
If ii = 3 Then Label152.ToolTipText = "Decrease 10$"
If ii = 4 Then Label152.ToolTipText = "Increase 15$"
If ii = 5 Then Label152.ToolTipText = "Zero Counter"
If ii = 6 Then Label152.ToolTipText = "Increase 1$"
If ii = 7 Then Label152.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label152.ToolTipText = "Zero Counter"
If ii = 9 Then Label152.ToolTipText = "Decrease 1$"
If ii = 10 Then Label152.ToolTipText = "Randomize Decrease"
Next_RND
End Sub
Private Sub Next_RND()
RND_NEXT
If ii = 1 Then Label153.Caption = "-5"
If ii = 2 Then Label153.Caption = "+5"
If ii = 3 Then Label153.Caption = "-10"
If ii = 4 Then Label153.Caption = "+15"
If ii = 5 Then Label153.Caption = "Z"
If ii = 6 Then Label153.Caption = "+1"
If ii = 7 Then Label153.Caption = "B"
If ii = 8 Then Label153.Caption = "Z"
If ii = 9 Then Label153.Caption = "-1"
If ii = 10 Then Label153.Caption = "(-)"
If ii = 1 Then Label153.ToolTipText = "Decrease 5$"
If ii = 2 Then Label153.ToolTipText = "Increase 5$"
If ii = 3 Then Label153.ToolTipText = "Decrease 10$"
If ii = 4 Then Label153.ToolTipText = "Increase 15$"
If ii = 5 Then Label153.ToolTipText = "Zero Counter"
If ii = 6 Then Label153.ToolTipText = "Increase 1$"
If ii = 7 Then Label153.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label153.ToolTipText = "Zero Counter"
If ii = 9 Then Label153.ToolTipText = "Decrease 1$"
If ii = 10 Then Label153.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label154.Caption = "-5"
If ii = 2 Then Label154.Caption = "+5"
If ii = 3 Then Label154.Caption = "-10"
If ii = 4 Then Label154.Caption = "+15"
If ii = 5 Then Label154.Caption = "Z"
If ii = 6 Then Label154.Caption = "+1"
If ii = 7 Then Label154.Caption = "B"
If ii = 8 Then Label154.Caption = "Z"
If ii = 9 Then Label154.Caption = "-1"
If ii = 10 Then Label154.Caption = "(-)"
If ii = 1 Then Label154.ToolTipText = "Decrease 5$"
If ii = 2 Then Label154.ToolTipText = "Increase 5$"
If ii = 3 Then Label154.ToolTipText = "Decrease 10$"
If ii = 4 Then Label154.ToolTipText = "Increase 15$"
If ii = 5 Then Label154.ToolTipText = "Zero Counter"
If ii = 6 Then Label154.ToolTipText = "Increase 1$"
If ii = 7 Then Label154.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label154.ToolTipText = "Zero Counter"
If ii = 9 Then Label154.ToolTipText = "Decrease 1$"
If ii = 10 Then Label154.ToolTipText = "Randomize Decrease"
RND_NEXT
If ii = 1 Then Label155.Caption = "-5"
If ii = 2 Then Label155.Caption = "+5"
If ii = 3 Then Label155.Caption = "-10"
If ii = 4 Then Label155.Caption = "+15"
If ii = 5 Then Label155.Caption = "Z"
If ii = 6 Then Label155.Caption = "+1"
If ii = 7 Then Label155.Caption = "B"
If ii = 8 Then Label155.Caption = "Z"
If ii = 9 Then Label155.Caption = "-1"
If ii = 10 Then Label155.Caption = "(-)"
If ii = 1 Then Label155.ToolTipText = "Decrease 5$"
If ii = 2 Then Label155.ToolTipText = "Increase 5$"
If ii = 3 Then Label155.ToolTipText = "Decrease 10$"
If ii = 4 Then Label155.ToolTipText = "Increase 15$"
If ii = 5 Then Label155.ToolTipText = "Zero Counter"
If ii = 6 Then Label155.ToolTipText = "Increase 1$"
If ii = 7 Then Label155.ToolTipText = "Bomb. Decrease 98%"
If ii = 8 Then Label155.ToolTipText = "Zero Counter"
If ii = 9 Then Label155.ToolTipText = "Decrease 1$"
If ii = 10 Then Label155.ToolTipText = "Randomize Decrease"

End Sub
Private Sub FNT_SIZE()
Label13.Font.Size = 8
Label14.Font.Size = 8
Label15.Font.Size = 8
Label16.Font.Size = 8
Label17.Font.Size = 8
Label18.Font.Size = 8
Label19.Font.Size = 8
Label20.Font.Size = 8
Label21.Font.Size = 8
Label22.Font.Size = 8
Label23.Font.Size = 8
Label24.Font.Size = 8
Label25.Font.Size = 8
Label26.Font.Size = 8
Label27.Font.Size = 8
Label28.Font.Size = 8
Label29.Font.Size = 8
Label30.Font.Size = 8
Label31.Font.Size = 8
Label32.Font.Size = 8
Label33.Font.Size = 8
Label34.Font.Size = 8
Label35.Font.Size = 8
Label36.Font.Size = 8
Label37.Font.Size = 8
Label38.Font.Size = 8
Label39.Font.Size = 8
Label40.Font.Size = 8
Label41.Font.Size = 8
Label42.Font.Size = 8
Label43.Font.Size = 8
Label44.Font.Size = 8
Label45.Font.Size = 8
Label46.Font.Size = 8
Label47.Font.Size = 8
Label48.Font.Size = 8
Label49.Font.Size = 8
Label50.Font.Size = 8
Label51.Font.Size = 8
Label52.Font.Size = 8
Label53.Font.Size = 8
Label54.Font.Size = 8
Label55.Font.Size = 8
Label56.Font.Size = 8
Label57.Font.Size = 8
Label58.Font.Size = 8
Label59.Font.Size = 8
Label60.Font.Size = 8
Label61.Font.Size = 8
Label62.Font.Size = 8
Label63.Font.Size = 8
Label64.Font.Size = 8
Label65.Font.Size = 8
Label66.Font.Size = 8
Label67.Font.Size = 8
Label68.Font.Size = 8
Label69.Font.Size = 8
Label70.Font.Size = 8
Label71.Font.Size = 8
Label72.Font.Size = 8
Label73.Font.Size = 8
Label74.Font.Size = 8
Label75.Font.Size = 8
Label76.Font.Size = 8
Label77.Font.Size = 8
Label78.Font.Size = 8
Label79.Font.Size = 8
Label80.Font.Size = 8
Label81.Font.Size = 8
Label82.Font.Size = 8
Label83.Font.Size = 8
Label84.Font.Size = 8
Label85.Font.Size = 8
Label86.Font.Size = 8
Label87.Font.Size = 8
Label88.Font.Size = 8
Label89.Font.Size = 8
Label90.Font.Size = 8
Label91.Font.Size = 8
Label92.Font.Size = 8
Label93.Font.Size = 8
Label94.Font.Size = 8
Label95.Font.Size = 8
Label96.Font.Size = 8
Label97.Font.Size = 8
Label98.Font.Size = 8
Label99.Font.Size = 8
Label100.Font.Size = 8
Label101.Font.Size = 8
Label102.Font.Size = 8
Label103.Font.Size = 8
Label104.Font.Size = 8
Label105.Font.Size = 8
Label106.Font.Size = 8
Label107.Font.Size = 8
Label108.Font.Size = 8
Label109.Font.Size = 8
Label110.Font.Size = 8
Label111.Font.Size = 8
Label112.Font.Size = 8
Label113.Font.Size = 8
Label114.Font.Size = 8
Label115.Font.Size = 8
Label116.Font.Size = 8
Label117.Font.Size = 8
Label118.Font.Size = 8
Label119.Font.Size = 8
Label120.Font.Size = 8
Label121.Font.Size = 8
Label122.Font.Size = 8
Label123.Font.Size = 8
Label124.Font.Size = 8
Label125.Font.Size = 8
Label126.Font.Size = 8
Label127.Font.Size = 8
Label128.Font.Size = 8
Label129.Font.Size = 8
Label130.Font.Size = 8
Label131.Font.Size = 8
Label132.Font.Size = 8
Label133.Font.Size = 8
Label134.Font.Size = 8
Label135.Font.Size = 8
Label136.Font.Size = 8
Label137.Font.Size = 8
Label138.Font.Size = 8
Label139.Font.Size = 8
Label140.Font.Size = 8
Label141.Font.Size = 8
Label142.Font.Size = 8
Label143.Font.Size = 8
Label144.Font.Size = 8
Label145.Font.Size = 8
Label146.Font.Size = 8
Label147.Font.Size = 8
Label148.Font.Size = 8
Label149.Font.Size = 8
Label150.Font.Size = 8
Label151.Font.Size = 8
Label152.Font.Size = 8
Label153.Font.Size = 8
Label154.Font.Size = 8
Label155.Font.Size = 8
End Sub

