Attribute VB_Name = "Module1"
'MOVE FORM
'Declare Sub ReleaseCapture Lib "user32" ()
'Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Integer, ByVal lParam As Long) As Long
Public Declare Function ReleaseCapture Lib "user32" () As Long
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hwnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
'Private Const WM_NCLBUTTONDOWN = &HA1
'Private Const HTCAPTION = 2




'DC BITMAP
Public Const API_NULL_HANDLE = 0

Public Const IMAGE_BITMAP = 0

Public Const LR_DEFAULTCOLOR = &H0
Public Const LR_LOADFROMFILE = &H10
Public Const SRCCOPY = &HCC0020
Public Const WM_NCLBUTTONDOWN = &HA1
Public Const HTCAPTION = 2

Declare Function LoadImage Lib "user32" Alias "LoadImageA" (ByVal hInst As Long, ByVal lpsz As Any, ByVal un1 As Long, ByVal n1 As Long, ByVal n2 As Long, ByVal un2 As Long) As Long
Declare Function GetDC Lib "user32" (ByVal hwnd As Long) As Long
Declare Function ReleaseDC Lib "user32" (ByVal hwnd As Long, ByVal hdc As Long) As Long
Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, ByVal hObject As Long) As Long
Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Declare Function GDIGetObject Lib "gdi32" Alias "GetObjectA" (ByVal hObject As Long, ByVal nCount As Long, lpObject As Any) As Long
Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, _
    ByVal x As Long, ByVal y As Long, _
    ByVal nWidth As Long, ByVal nHeight As Long, _
    ByVal hSrcDC As Long, _
    ByVal xSrc As Long, ByVal ySrc As Long, _
    ByVal dwRop As Long) As Long

Type BITMAP
    bmType As Long
    bmWidth As Long
    bmHeight As Long
    bmWidthBytes As Long
    bMYPlanes As Integer
    bmBitsPixel As Integer
    bmBits As Long
End Type


Declare Function GetCapture Lib "user32" () As Long
Declare Function SetCapture Lib "user32" (ByVal hwnd As Long) As Long




Declare Function GetCursorPos Lib "user32" (lpPoint As POINTAPI) As Long


Type POINTAPI
  x As Long
  y As Long
End Type


Public JS_RESIZE  As Boolean



Public Const HTBOTTOM = 15

Public Const HTBOTTOMLEFT = 16

Public Const HTBOTTOMRIGHT = 17

Public Const HTLEFT = 10

Public Const HTRIGHT = 11


