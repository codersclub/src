VERSION 5.00
Object = "*\AJSSKIN.vbp"
Begin VB.Form TestOCX 
   BackColor       =   &H00D67563&
   BorderStyle     =   0  'None
   Caption         =   "JSSKIN TEST APP"
   ClientHeight    =   5820
   ClientLeft      =   0
   ClientTop       =   0
   ClientWidth     =   6975
   Icon            =   "test.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   5820
   ScaleWidth      =   6975
   StartUpPosition =   3  'Windows Default
   Begin JSSKIN.JSBORDER JSBORDER3 
      Align           =   2  'Align Bottom
      Height          =   105
      Left            =   0
      TabIndex        =   3
      Top             =   5715
      Width           =   6975
      _ExtentX        =   12303
      _ExtentY        =   185
      BORDERTYPE      =   3
   End
   Begin JSSKIN.JSBORDER JSBORDER2 
      Align           =   4  'Align Right
      Height          =   5310
      Left            =   6870
      TabIndex        =   2
      Top             =   405
      Width           =   105
      _ExtentX        =   185
      _ExtentY        =   9366
      BORDERTYPE      =   2
   End
   Begin JSSKIN.JSBORDER JSBORDER1 
      Align           =   3  'Align Left
      Height          =   5310
      Left            =   0
      TabIndex        =   1
      Top             =   405
      Width           =   105
      _ExtentX        =   185
      _ExtentY        =   9366
      BORDERTYPE      =   1
   End
   Begin JSSKIN.JSCAPTION JSCAPTION1 
      Align           =   1  'Align Top
      Height          =   405
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   6975
      _ExtentX        =   12303
      _ExtentY        =   714
      SHOWONTOP       =   -1  'True
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "Arial"
         Size            =   9.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
   End
End
Attribute VB_Name = "TestOCX"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Form_Load()
Me.JSCAPTION1.Path = App.Path & "\luna.jss"
Me.JSBORDER1.Path = App.Path & "\luna.jss"
Me.JSBORDER2.Path = App.Path & "\luna.jss"
Me.JSBORDER3.Path = App.Path & "\luna.jss"

End Sub


