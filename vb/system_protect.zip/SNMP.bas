Attribute VB_Name = "SNMP"
Option Explicit

Const HOSTNAMELEN = 256
Const PORTNAMELEN = 256
Const ADDRESSLEN = HOSTNAMELEN + PORTNAMELEN

Const ASN_UNIVERSAL = &H0
Const ASN_APPLICATION = &H40
Const ASN_CONTEXTSPECIFIC = &H80
Const ASN_PRIVATE = &HC0
Const ASN_PRIMATIVE = &H0
Const ASN_CONSTRUCTOR = &H20

Const ASN_RFC1157_GETREQUEST = ASN_CONTEXTSPECIFIC Or ASN_CONSTRUCTOR Or 0
Const ASN_RFC1157_GETNEXTREQUEST = ASN_CONTEXTSPECIFIC Or ASN_CONSTRUCTOR Or 1

Public AsnInteger As Long   'long
Public AsnCounter As Long   'DWORD
Public AsnGauge As Long     'DWORD
Public AsnTimeticks As Long 'DWORD

Public AsnSequence As AsnOctetString
Public AsnImplicitSequence As AsnOctetString
Public AsnIPAddress As AsnOctetString
Public AsnDisplayString As AsnOctetString
Public AsnOpaque As AsnOctetString
Public AsnObjectName As AsnObjectIdentifier
Public AsnNetworkAddress As AsnIPAddress
