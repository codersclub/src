VERSION 5.00
Begin VB.Form Port_Watch 
   Caption         =   "Port Watch"
   ClientHeight    =   1275
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4680
   ClipControls    =   0   'False
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Moveable        =   0   'False
   NegotiateMenus  =   0   'False
   ScaleHeight     =   1275
   ScaleWidth      =   4680
   ShowInTaskbar   =   0   'False
   StartUpPosition =   1  'CenterOwner
   WindowState     =   1  'Minimized
End
Attribute VB_Name = "Port_watch"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
  


Private Sub Form_Load()
Dim P As Integer
  Init_Psw
  OldPwProc = SetWindowLong(hWnd, GWL_WNDPROC, AddressOf PWatch_Proc)
  vbWSAStartup
  
  'begins watch mode on ports
  For P = 1 To PSW.Cnt
    PSW.No(P).WPort = ListenForConnect(PSW.No(P).Port, hWnd)
  Next
End Sub
