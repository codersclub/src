VERSION 5.00
Begin VB.Form PortSetup 
   Caption         =   "Port Setup"
   ClientHeight    =   1965
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3165
   LinkTopic       =   "Form1"
   ScaleHeight     =   1965
   ScaleWidth      =   3165
   StartUpPosition =   3  'Windows Default
   Begin VB.Frame PortSetup 
      Caption         =   "Port Setup"
      Height          =   1935
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   3135
      Begin VB.CommandButton PortAdd 
         Caption         =   "Add New"
         Height          =   375
         Left            =   120
         TabIndex        =   5
         Top             =   1440
         Width           =   855
      End
      Begin VB.CommandButton PortRmv 
         Caption         =   "Remove"
         Height          =   375
         Left            =   1200
         TabIndex        =   4
         Top             =   1440
         Width           =   855
      End
      Begin VB.TextBox PortNum 
         Alignment       =   2  'Center
         Height          =   285
         Left            =   960
         MaxLength       =   5
         TabIndex        =   3
         Top             =   600
         Width           =   1455
      End
      Begin VB.TextBox PortName 
         Alignment       =   2  'Center
         Height          =   285
         Left            =   960
         TabIndex        =   2
         Top             =   960
         Width           =   1455
      End
      Begin VB.CommandButton PortUpdt 
         Caption         =   "Update"
         Height          =   375
         Left            =   2280
         TabIndex        =   1
         Top             =   1440
         Width           =   735
      End
      Begin VB.Label Label1 
         Caption         =   "Port#"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   240
         TabIndex        =   7
         Top             =   600
         Width           =   615
      End
      Begin VB.Label Label2 
         Caption         =   "Name"
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   255
         Left            =   240
         TabIndex        =   6
         Top             =   960
         Width           =   615
      End
   End
End
Attribute VB_Name = "PortSetup"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Sub edit_portEntry()
  If ClickedItem = 1 Then
    PortNum.Enabled = True
    PortName.Enabled = True
    PortAdd.Enabled = True
  Else
    If ClickedItem > 9 Then
      PortNum.Enabled = True
      PortName.Enabled = True
      PortRmv.Enabled = True
      PortUpdt.Enabled = True
    End If
  End If
End Sub

Private Sub Form_Load()
      PortNum.Enabled = False
      PortName.Enabled = False
      PortAdd.Enabled = False
      PortRmv.Enabled = False
      PortUpdt.Enabled = False
End Sub

Private Sub PortAdd_Click()
  Dim Item As ListItem, y As Integer
  y = PSW.Cnt
  PSW.Cnt = y + 1
  PSW.No(y).Port = Val(PortNum.Text)
  PSW.No(y).Name = PortName.Text
  Set Item = PSWView.ListItems.Add()
  Item.Text = PSW.No(y).Port
  Item.Tag = y + 1
  Item.SubItems(1) = PSW.No(y).Name
  Item.SubItems(2) = PSW.No(y).Hits
  PortAdd.Enabled = False
  PortName.Text = ""
  PortNum.Text = ""
  ClickedItem = 0
End Sub

Private Sub PortRmv_Click()
  Dim Item As ListItem, y As Integer, x As Integer
  y = ClickedItem
  PSW.Cnt = PSW.Cnt - 1
  PSWView.ListItems.Remove y
  y = y - 1
  For x = y To PSW.Cnt
    PSW.No(x) = PSW.No(x + 1)
  Next
  PortRmv.Enabled = False
  PortUpdt.Enabled = False
  PortName.Text = ""
  PortNum.Text = ""
  ClickedItem = 0
End Sub

Private Sub PortUpdt_Click()
  Dim Item As ListItem, y As Integer
  y = ClickedItem - 1
  If PortNum.Text <> "" Then
    PSW.No(y).Port = Val(PortNum.Text)
    PSWView.ListItems(y + 1).Text = Val(PortNum.Text)
  End If
  If PortName.Text <> "" Then
    PSW.No(y).Name = PortName.Text
    PSWView.ListItems(y + 1).SubItems(1) = PortName.Text
  End If
  PortRmv.Enabled = False
  PortUpdt.Enabled = False
  PortName.Text = ""
  PortNum.Text = ""
  ClickedItem = 0
End Sub

Private Sub PSWView_Click()
Debug.Print ">"; ClickedItem, Mouse_Btn
  If ClickedItem <> 0 Then
    If Mouse_Btn = 2 Then
      edit_portEntry
    Else
      PortNum.Enabled = False
      PortName.Enabled = False
      PortAdd.Enabled = False
      PortRmv.Enabled = False
      PortUpdt.Enabled = False
      PSWView.Enabled = True
      ClickedItem = 0
    End If
  End If
End Sub


