Attribute VB_Name = "PortWatch"

Type PSW_Data
  WPort As Long
  Port As Long
  Name As String
  Hits As Long
  Check As Boolean
End Type

Type PSW
  Cnt As Integer
  No(50) As PSW_Data
End Type

Public PSW As PSW

Sub Init_Psw()
  PSW.No(1).Port = 31337
  PSW.No(1).Name = "B.O"
  PSW.No(2).Port = 54320
  PSW.No(2).Name = "B.O2k"
  PSW.No(3).Port = 31666
  PSW.No(3).Name = "B.O Whack"
  PSW.No(4).Port = 12345
  PSW.No(4).Name = "Netbus"
  PSW.No(5).Port = 12346
  PSW.No(5).Name = "Netbus"
  PSW.No(6).Port = 20034
  PSW.No(6).Name = "Netbus"
  PSW.No(7).Port = 1243
  PSW.No(7).Name = "SubSeven"
  PSW.No(8).Port = 27374
  PSW.No(8).Name = "SubSeven 21"
  PSW.No(9).Port = 21554
  PSW.No(9).Name = "GirlFriend"
  PSW.No(10).Port = 21
  PSW.No(10).Name = "FTP"
  PSW.No(11).Port = 23
  PSW.No(11).Name = "Telnet"
  PSW.No(12).Port = 80
  PSW.No(12).Name = "Http:"
  PSW.Cnt = 12
End Sub
