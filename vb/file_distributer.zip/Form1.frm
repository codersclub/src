VERSION 5.00
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{CDE57A40-8B86-11D0-B3C6-00A0C90AEA82}#1.0#0"; "MSDATGRD.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "File Update Util"
   ClientHeight    =   6030
   ClientLeft      =   150
   ClientTop       =   720
   ClientWidth     =   8790
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   6030
   ScaleWidth      =   8790
   StartUpPosition =   3  'Windows Default
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   375
      Left            =   0
      Top             =   1920
      Visible         =   0   'False
      Width           =   4455
      _ExtentX        =   7858
      _ExtentY        =   661
      ConnectMode     =   16
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   2
      LockType        =   3
      CommandType     =   8
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   1
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   0
      Connect         =   ""
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   ""
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   ""
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin MSDataGridLib.DataGrid DataList1 
      Bindings        =   "Form1.frx":0000
      Height          =   2280
      Left            =   90
      TabIndex        =   11
      Top             =   105
      Width           =   7080
      _ExtentX        =   12488
      _ExtentY        =   4022
      _Version        =   393216
      Enabled         =   -1  'True
      HeadLines       =   1
      RowHeight       =   15
      FormatLocked    =   -1  'True
      BeginProperty HeadFont {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ColumnCount     =   3
      BeginProperty Column00 
         DataField       =   "Machine Path"
         Caption         =   "Machine Path"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column01 
         DataField       =   "MachineName"
         Caption         =   "MachineName"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   0
            Format          =   ""
            HaveTrueFalseNull=   0
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   0
         EndProperty
      EndProperty
      BeginProperty Column02 
         DataField       =   "SendTo"
         Caption         =   "SendTo"
         BeginProperty DataFormat {6D835690-900B-11D0-9484-00A0C91110ED} 
            Type            =   5
            Format          =   ""
            HaveTrueFalseNull=   1
            TrueValue       =   "True"
            FalseValue      =   "False"
            NullValue       =   ""
            FirstDayOfWeek  =   0
            FirstWeekOfYear =   0
            LCID            =   1033
            SubFormatType   =   7
         EndProperty
      EndProperty
      SplitCount      =   1
      BeginProperty Split0 
         BeginProperty Column00 
            Button          =   -1  'True
            WrapText        =   -1  'True
            ColumnWidth     =   1739.906
         EndProperty
         BeginProperty Column01 
            ColumnWidth     =   1739.906
         EndProperty
         BeginProperty Column02 
            Button          =   -1  'True
            ColumnWidth     =   764.787
         EndProperty
      EndProperty
   End
   Begin VB.TextBox txtResponses 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3210
      Left            =   5460
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   9
      Top             =   2790
      Width           =   3225
   End
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "Arial"
         Size            =   6.75
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   270
      Left            =   120
      TabIndex        =   8
      Top             =   5730
      Width           =   5235
   End
   Begin VB.FileListBox File1 
      Height          =   2625
      Left            =   2640
      TabIndex        =   7
      Top             =   3105
      Width           =   2730
   End
   Begin VB.DriveListBox Drive1 
      Height          =   315
      Left            =   105
      TabIndex        =   6
      Top             =   2790
      Width           =   5235
   End
   Begin VB.DirListBox Dir1 
      Height          =   2565
      Left            =   120
      TabIndex        =   5
      Top             =   3120
      Width           =   2535
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Check Selected"
      Height          =   375
      Index           =   2
      Left            =   7320
      TabIndex        =   2
      Top             =   1065
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Send Selected"
      Height          =   375
      Index           =   1
      Left            =   7320
      TabIndex        =   1
      Top             =   555
      Width           =   1335
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Send All"
      Height          =   375
      Index           =   0
      Left            =   7305
      TabIndex        =   0
      Top             =   120
      Width           =   1335
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "Cancel"
      Default         =   -1  'True
      Enabled         =   0   'False
      Height          =   375
      Left            =   7305
      TabIndex        =   4
      Top             =   1560
      Width           =   1350
   End
   Begin VB.Label Label2 
      Caption         =   "Responses"
      Height          =   270
      Left            =   5460
      TabIndex        =   10
      Top             =   2490
      Width           =   1305
   End
   Begin VB.Label Label1 
      Caption         =   "Select File"
      Height          =   255
      Left            =   105
      TabIndex        =   3
      Top             =   2475
      Width           =   2100
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuExit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu mnuTools 
      Caption         =   "&Tools"
      Begin VB.Menu mnuTools_AddNewLoc 
         Caption         =   "&Add New Location"
      End
      Begin VB.Menu mnuTools_DelLoc 
         Caption         =   "&Delete Location"
      End
      Begin VB.Menu mnuSep 
         Caption         =   "-"
         Index           =   0
      End
      Begin VB.Menu mnuTools_BatchSend 
         Caption         =   "&Include In Batch Send"
         Visible         =   0   'False
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
Private lButton As Long
Private Sub Cancel_Click()
    CopyCancel = True

End Sub

Private Sub Adodc1_Error(ByVal ErrorNumber As Long, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, fCancelDisplay As Boolean)
    If ErrorNumber = 16389 Then fCancelDisplay = True
End Sub

Private Sub cmdCancel_Click()
    CopyCancel = True
End Sub

Private Sub Command1_Click(Index As Integer)
Dim x As Boolean, RS As ADODB.Recordset, y As Integer
On Error Resume Next
    txtResponses = ""
    ProdVer = ""
    For y = 0 To 2
        Command1(y).Enabled = Not Command1(y).Enabled
    Next
    cmdCancel.Enabled = True
    CopyCancel = False
    
    SourcePath = Dir1.Path
    pFileName = File1.Filename
    If pFileName = "" Then
        MsgBox "No file is selected.  Select a file to distribute, then try again.", vbInformation, "File error"
        For y = 0 To 2
            Command1(y).Enabled = Not Command1(y).Enabled
        Next
        cmdCancel.Enabled = False
        CopyCancel = False

        Exit Sub
    End If
    SourcePath = SourcePath + "\" & pFileName
    DisplayVerInfo SourcePath, 0
    VFile1 = ProdVer    'Format$(pFileInfo(0).dwProductVersionMSh) & "." & Format$(pFileInfo(0).dwProductVersionMSl) & "." & Format$(pFileInfo(0).dwProductVersionLSh) & "." & Format$(pFileInfo(0).dwProductVersionLSl)
    frmMain.Caption = "Current Version = " & VFile1
    Select Case Index
        Case 0
            Set RS = Adodc1.Recordset.Clone
            RS.MoveFirst
            Do While RS.EOF = False
                'DataList1.Text = RS.Fields(1)
                frmMain.Refresh
                If RS.Fields(3) = True Then
                    x = CheckFileCopied(SourcePath, RS.Fields(1) & "\" & pFileName)
                    If Not x Then
                        x = CopyFile(SourcePath, RS.Fields(1) & "\" & pFileName, 0)
                        x = CheckFileCopied(SourcePath, RS.Fields(1) & "\" & pFileName)
                    End If
                    txtResponses = vbTab + GetFileDates(DataList1.Columns(0).Text & "\" & pFileName) + vbCrLf + txtResponses
                    
                    If Not x Then
                        txtResponses = RS.Fields(1) & ":" & vbCrLf & vbTab & "COPY FAILED!!" & vbCrLf & vbTab & SourcePath & vbCrLf + txtResponses
                    Else
                        txtResponses = RS.Fields(1) & ":" & vbCrLf & vbTab & "Version Up To Date" & vbCrLf & vbTab & SourcePath & vbCrLf + txtResponses
                    End If
                End If
                DoEvents
                If CopyCancel Then Exit Do
                RS.MoveNext
            Loop
            RS.Close
        Case 1
            x = CheckFileCopied(SourcePath, DataList1.Columns(0).Text & "\" & pFileName)
            If Not x Then
                x = CopyFile(SourcePath, DataList1.Columns(0).Text & "\" & pFileName, 0)
                x = CheckFileCopied(SourcePath, DataList1.Text & "\" & pFileName)
            End If
            txtResponses = vbTab + GetFileDates(DataList1.Columns(0).Text & "\" & pFileName) + vbCrLf + txtResponses
            
            If Not x Then
                txtResponses = DataList1.Columns(0).Text & ":" & vbCrLf & vbTab & "COPY FAILED!" & vbCrLf & vbTab & SourcePath & vbCrLf + txtResponses
            Else
                txtResponses = DataList1.Columns(0).Text & ":" & vbCrLf & vbTab & "Version Up To Date" & vbCrLf & vbTab & SourcePath & vbCrLf + txtResponses
            End If
            
        Case 2
            x = CheckFileCopied(SourcePath, DataList1.Columns(0).Text & "\" & pFileName)
            txtResponses = vbTab + GetFileDates(DataList1.Columns(0).Text & "\" & pFileName) + vbCrLf + txtResponses
            If x Then
                txtResponses = DataList1.Columns(0).Text & ":" & vbCrLf & vbTab & "File is up to date." & vbCrLf & vbTab & "Source Version: " & VFile1 & vbCrLf & vbTab & "Destination Version: " & VFile2 & vbCrLf + txtResponses
            Else
                txtResponses = DataList1.Columns(0).Text & ":" & vbCrLf & vbTab & "File is NOT up to date." & vbCrLf & vbTab & "Source Version: " & VFile1 & vbCrLf & vbTab & "Destination Version: " & VFile2 & vbCrLf + txtResponses
            End If
            
    End Select
    For y = 0 To 2
        Command1(y).Enabled = Not Command1(y).Enabled
    Next
    cmdCancel.Enabled = False
txtResponses = "OPERATION COMPLETED" + vbCrLf + txtResponses
On Error GoTo 0
End Sub


Private Sub DataList1_ButtonClick(ByVal ColIndex As Integer)
    Dim Temp$
    On Error GoTo Err_ButtonClick
    Select Case ColIndex
        Case 2
            'DataList1.EditActive = True
            DataList1.Columns(2).Value = Trim$(Not DataList1.Columns(2).Value)    'True Then)
            DataList1.EditActive = False
        Case 0
            Temp = GetFolderPath
            If Temp <> DataList1.Columns(0).Value And Temp <> "" Then
                DataList1.Columns(0).Value = Temp
            End If
    End Select
    
Err_ButtonClick_Exit:
    On Error GoTo 0
    Exit Sub
Err_ButtonClick:
    Select Case Err
        Case 6160
            MsgBox "You need to add a new record first.", vbOKOnly, "No Record To Edit"
        Case Err
            MsgBox Error, 0, Err & " - Form1_Datalist1_ButtonClick()"
    End Select
    Resume Err_ButtonClick_Exit
End Sub

Private Sub DataList1_Error(ByVal DataError As Integer, Response As Integer)
    Debug.Print DataError
    If DataError = 7007 Then Response = 0
    Response = 0
End Sub

Private Sub DataList1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
lButton = Button
End Sub

Private Sub DataList1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    
    If Button = 2 Then
        If DataList1.RowContaining(y) = DataList1.Row Then
            mnuTools_BatchSend.Visible = True
            mnuTools_BatchSend.Checked = DataList1.Columns(2).Value
            PopupMenu mnuTools
            mnuTools_BatchSend.Visible = False
        End If
    End If


End Sub

Private Sub Dir1_Change()
    File1.Path = Dir1.Path
End Sub

Private Sub Drive1_Change()
    Dir1.Path = Drive1
    
End Sub

Private Sub File1_Click()
    Text1.Text = File1.Path & "\" & File1.Filename

End Sub

Private Sub File1_PathChange()
    Text1.Text = File1.Path
End Sub


Private Sub Form_Load()
    Dim Temp$
    
    Temp = "Provider=Microsoft.Jet.OLEDB.3.51;Persist Security Info=False;Data Source=xxx.mdb"
    Temp = ReplaceInString(Temp, "xxx.mdb", App.Path & "\distlist.mdb")
    Adodc1.ConnectionString = Temp
    Adodc1.CommandType = adCmdTable
    Adodc1.RecordSource = "MachinePaths"
    Adodc1.Enabled = True
    Adodc1.Refresh
    Drive1.Drive = Left$(SourcePath, 3)
    DoEvents
    If SHFileExists(SourcePath) Then
        Dir1.Path = SourcePath
    End If
    DataList1.Columns(0).Width = 3909.906
    
End Sub

Private Sub Form_Unload(Cancel As Integer)
    RgTl.ValueKey = "InitPath"
    SourcePath = Dir1.Path
    RgTl.Value = SourcePath
    Adodc1.Enabled = False
    Set RgTl = Nothing
End Sub


Private Sub mnuExit_Click()
    Unload Me
End Sub


Private Sub mnuTools_AddNewLoc_Click()
    Dim Temp$
    Temp = GetFolderPath
    
    If Temp <> "" Then
        With frmMain.Adodc1.Recordset
            .AddNew
                .Fields(1) = Temp
                .Fields(2) = InputBox("Enter the machines name", "Enter Name", "MachineName")
                .Fields(3) = True
            .Update
        End With
    End If
    Adodc1.Recordset.Requery
    DataList1.Refresh
End Sub

Private Sub mnuTools_BatchSend_Click()
    DataList1.Columns(2).Value = Not DataList1.Columns(2).Value
    mnuTools_BatchSend.Checked = DataList1.Columns(2).Value
End Sub


Private Sub mnuTools_DelLoc_Click()
    Dim x&
    x = MsgBox("Are you sure?", vbYesNo + vbQuestion, "This Is Your Final Answer!")
    If x = vbYes Then
        Adodc1.Recordset.Delete
    End If
End Sub


