VERSION 5.00
Begin VB.Form Signon 
   AutoRedraw      =   -1  'True
   BorderStyle     =   0  'None
   Caption         =   "Mo's PC Security"
   ClientHeight    =   2160
   ClientLeft      =   0
   ClientTop       =   75
   ClientWidth     =   9510
   Icon            =   "SignIn.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   Picture         =   "SignIn.frx":0442
   ScaleHeight     =   2160
   ScaleWidth      =   9510
   ShowInTaskbar   =   0   'False
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox PicEnd 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   6600
      ScaleHeight     =   240
      ScaleWidth      =   1440
      TabIndex        =   12
      Top             =   1560
      Width           =   1440
      Begin VB.Label exiter 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Exit"
         ForeColor       =   &H00FFFFFF&
         Height          =   315
         Left            =   0
         TabIndex        =   13
         Top             =   0
         Width           =   1455
      End
   End
   Begin VB.PictureBox PicAbout 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   4200
      ScaleHeight     =   240
      ScaleWidth      =   1440
      TabIndex        =   10
      Top             =   1560
      Width           =   1440
      Begin VB.Label pichelp 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Help And About"
         ForeColor       =   &H00FFFFFF&
         Height          =   255
         Left            =   0
         TabIndex        =   11
         Top             =   0
         Width           =   1455
      End
   End
   Begin VB.PictureBox buttup 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   3480
      Picture         =   "SignIn.frx":5611
      ScaleHeight     =   240
      ScaleWidth      =   1440
      TabIndex        =   9
      Top             =   720
      Visible         =   0   'False
      Width           =   1440
   End
   Begin VB.PictureBox buttdown 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   1800
      Picture         =   "SignIn.frx":59FB
      ScaleHeight     =   240
      ScaleWidth      =   1440
      TabIndex        =   8
      Top             =   720
      Visible         =   0   'False
      Width           =   1440
   End
   Begin VB.PictureBox picSignIn 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BorderStyle     =   0  'None
      Height          =   240
      Left            =   1680
      ScaleHeight     =   240
      ScaleWidth      =   1440
      TabIndex        =   6
      Top             =   1560
      Width           =   1440
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         Caption         =   "Sign - In"
         ForeColor       =   &H00FFFFFF&
         Height          =   255
         Left            =   0
         TabIndex        =   7
         Top             =   0
         Width           =   1455
      End
   End
   Begin VB.Timer tmrset 
      Interval        =   1
      Left            =   1800
      Top             =   120
   End
   Begin VB.TextBox Text1 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      ForeColor       =   &H000000FF&
      Height          =   285
      Left            =   1560
      TabIndex        =   0
      Text            =   "Enter Name Here"
      Top             =   1200
      Width           =   1695
   End
   Begin VB.Label Label6 
      BackStyle       =   0  'Transparent
      Caption         =   "Http://Dictator.50Megs.Com"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   255
      Left            =   7080
      TabIndex        =   15
      Top             =   1920
      Width           =   2415
   End
   Begin VB.Label Label5 
      BackStyle       =   0  'Transparent
      Caption         =   "Dictator@MyPlace.com"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   178
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      ForeColor       =   &H0000FFFF&
      Height          =   255
      Left            =   0
      TabIndex        =   14
      Top             =   1920
      Width           =   2415
   End
   Begin VB.Label Label4 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Date:"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   4080
      TabIndex        =   5
      Top             =   960
      Width           =   1575
   End
   Begin VB.Label lblDate 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H00C000C0&
      Height          =   255
      Left            =   4080
      TabIndex        =   4
      Top             =   1200
      Width           =   1695
   End
   Begin VB.Label Label2 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Sign-In Name:"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   1560
      TabIndex        =   3
      Top             =   960
      Width           =   1695
   End
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      BackStyle       =   0  'Transparent
      Caption         =   "Time:"
      ForeColor       =   &H00FFFFFF&
      Height          =   255
      Left            =   6600
      TabIndex        =   2
      Top             =   960
      Width           =   1575
   End
   Begin VB.Label lblDisplay 
      Alignment       =   2  'Center
      BackColor       =   &H00000000&
      BorderStyle     =   1  'Fixed Single
      ForeColor       =   &H0000FF00&
      Height          =   255
      Left            =   6480
      TabIndex        =   1
      Top             =   1200
      Width           =   1695
   End
End
Attribute VB_Name = "Signon"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub exiter_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    exiter.ForeColor = vbYellow
End Sub

Private Sub exiter_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    PicEnd.Picture = buttup.Picture
End Sub

Private Sub Form_Load()
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
    picSignIn.Picture = buttup.Picture
    PicAbout.Picture = buttup.Picture
    PicEnd.Picture = buttup.Picture
End Sub

Private Sub Form_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
End Sub

Private Sub Label1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
End Sub

Private Sub Label2_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
End Sub

Private Sub Label3_Click()
   If Text1.Text = "" Or Text1.Text = " " Or Text1.Text = "Enter Name Here" Then
    MsgBox "You must fill in valid information!"
    Exit Sub
   Else
    Open "C:\Windows\System\curty.dat" For Append As #1
    Print #1, "- - - - - - - - - - - - - - - - - -"
    Print #1, Text1.Text; " is logged in at:"; Date; ", "; Time; " ."
    Print #1, "-"
    Print #1, Text1.Text
    Print #1, Date
    Print #1, Time
    Close #1
    End
    Close
   End If
End Sub

Private Sub Label3_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    picSignIn.Picture = buttdown.Picture
End Sub

Private Sub Label3_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbYellow
End Sub

Private Sub Label3_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    picSignIn.Picture = buttup.Picture
End Sub

Private Sub exiter_Click()
    End
    Close
End Sub

Private Sub exiter_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    PicEnd.Picture = buttdown.Picture
End Sub

Private Sub Label4_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
End Sub

Private Sub pichelp_Click()
    frmAbout.Show
    tmrset.Enabled = False
    frmAbout.TmrOn.Enabled = True
End Sub

Private Sub pichelp_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    PicAbout.Picture = buttdown.Picture
End Sub

Private Sub pichelp_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    pichelp.ForeColor = vbYellow
End Sub

Private Sub pichelp_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    PicAbout.Picture = buttup.Picture
End Sub

Private Sub Text1_Change()
 If Text1.Text = " " Then Text1.Text = ""
 If Text1.Text = "Enter Name Here" Then Text1.Text = ""
End Sub

Private Sub Text1_Click()
 Text1.Text = ""
End Sub

Private Sub Text1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Label3.ForeColor = vbWhite
    pichelp.ForeColor = vbWhite
    exiter.ForeColor = vbWhite
End Sub

Private Sub tmrset_Timer()
     Signon.Show
     lblDisplay.Caption = Time
     lblDate.Caption = Date
End Sub
