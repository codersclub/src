VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Form1"
   ClientHeight    =   4620
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4800
   LinkTopic       =   "Form1"
   ScaleHeight     =   4620
   ScaleWidth      =   4800
   StartUpPosition =   3  'Windows Default
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

' Draw the curve on the form.
Private Sub DrawCurve(ByVal start_t As Single, ByVal stop_t As Single, ByVal dt As Single)
Dim cx As Single
Dim cy As Single
Dim t As Single

    cx = ScaleLeft + ScaleWidth / 2
    cy = ScaleTop + ScaleHeight / 2

    Cls
    CurrentX = cx + X(start_t)
    CurrentY = cy + Y(start_t)

    t = start_t + dt
    Do While t < stop_t
        Line -(cx + X(t), cy + Y(t))
        t = t + dt
    Loop

    Line -(cx + X(stop_t), cy + Y(stop_t))
End Sub
' The parametric function X(t).
Private Function X(ByVal t As Single) As Single
    X = 2000 * (27 * Cos(t) + 15 * Cos(t * 20 / 7)) / 42
End Function
' The parametric function Y(t).
Private Function Y(ByVal t As Single) As Single
    Y = 2000 * (27 * Sin(t) + 15 * Sin(t * 20 / 7)) / 42
End Function

Private Sub Form_Paint()
Const PI = 3.14159265

    DrawCurve 0, 14 * PI, 0.1
End Sub


