VERSION 5.00
Object = "*\A..\..\SKRIVB~1\DOCKIN~1\dockingform.vbp"
Begin VB.MDIForm frmMain 
   BackColor       =   &H00808080&
   Caption         =   "DockingForms"
   ClientHeight    =   5055
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7020
   Icon            =   "MDIForm1.frx":0000
   LinkTopic       =   "MDIForm1"
   StartUpPosition =   3  'Windows Default
   WindowState     =   2  'Maximized
   Begin rgrDockingForm.DockingForm DockingForm2 
      Align           =   3  'Align Left
      Height          =   3405
      Left            =   0
      TabIndex        =   1
      Top             =   1650
      Width           =   2000
      _ExtentX        =   3519
      _ExtentY        =   6006
   End
   Begin rgrDockingForm.DockingForm DockingForm1 
      Align           =   1  'Align Top
      Height          =   1650
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   7020
      _ExtentX        =   12383
      _ExtentY        =   2910
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Sub MDIForm_Load()
    Dim i As Long
    DockingForm2.Bind frmToc
    
    DockingForm1.Bind frmAbout
    For i = 0 To 20
        frmToc.tvExplorer.Nodes.Add , , , "khkjhkjhjk", 2
    Next
    For i = 0 To 20
        frmToc.tvExplorer.Nodes.Add 1, tvwChild, , "khkjhkjhjk", 2
    Next
    frmCode.Show
End Sub

Private Sub MDIForm_QueryUnload(Cancel As Integer, UnloadMode As Integer)
    DockingForm2.Unload
'    End
End Sub
