VERSION 5.00
Begin VB.Form frmCode 
   Caption         =   "CodeWindow"
   ClientHeight    =   2685
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   3720
   Icon            =   "frmCode.frx":0000
   LinkTopic       =   "Form1"
   MDIChild        =   -1  'True
   ScaleHeight     =   2685
   ScaleWidth      =   3720
   Begin VB.TextBox Text1 
      Height          =   2520
      Left            =   -15
      TabIndex        =   0
      Text            =   "poke 53280,0"
      Top             =   0
      Width           =   3570
   End
End
Attribute VB_Name = "frmCode"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit






Private Sub Form_Resize()
    Text1.Width = Me.Width - 120
    Text1.Height = Me.Height - 400
End Sub
