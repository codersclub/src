VERSION 5.00
Begin VB.Form frmAbout 
   Caption         =   "About MyApp"
   ClientHeight    =   2565
   ClientLeft      =   2355
   ClientTop       =   1950
   ClientWidth     =   5730
   ClipControls    =   0   'False
   LinkTopic       =   "Form2"
   ScaleHeight     =   2565
   ScaleWidth      =   5730
   Begin VB.FileListBox File1 
      Height          =   2040
      Left            =   0
      TabIndex        =   0
      Top             =   -15
      Width           =   2115
   End
End
Attribute VB_Name = "frmAbout"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub lblTitle_Click()
End Sub

Private Sub Form_Resize()
    On Error Resume Next
    File1.Width = Me.Width - 210
    File1.Height = Me.Height - 450
End Sub
