VERSION 5.00
Object = "{C1A8AF28-1257-101B-8FB0-0020AF039CA3}#1.1#0"; "MCI32.OCX"
Begin VB.Form Form4 
   Caption         =   "CD Player 2000"
   ClientHeight    =   7440
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6840
   Icon            =   "frmCD.frx":0000
   LinkTopic       =   "Form4"
   ScaleHeight     =   7440
   ScaleWidth      =   6840
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command8 
      Height          =   735
      Left            =   5040
      Picture         =   "frmCD.frx":0442
      Style           =   1  'Graphical
      TabIndex        =   12
      Top             =   5400
      Width           =   735
   End
   Begin VB.CommandButton Play 
      Height          =   735
      Left            =   840
      Picture         =   "frmCD.frx":0CB8
      Style           =   1  'Graphical
      TabIndex        =   11
      Top             =   5400
      Width           =   735
   End
   Begin VB.CommandButton Pause 
      Height          =   735
      Left            =   1680
      Picture         =   "frmCD.frx":152E
      Style           =   1  'Graphical
      TabIndex        =   10
      Top             =   5400
      Width           =   735
   End
   Begin VB.CommandButton Stop 
      Height          =   735
      Left            =   2520
      Picture         =   "frmCD.frx":1DA4
      Style           =   1  'Graphical
      TabIndex        =   9
      Top             =   5400
      Width           =   735
   End
   Begin VB.CommandButton Previous 
      Height          =   735
      Left            =   3360
      Picture         =   "frmCD.frx":261A
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   5400
      Width           =   735
   End
   Begin VB.CommandButton Next 
      Height          =   735
      Left            =   4200
      Picture         =   "frmCD.frx":2E90
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   5400
      Width           =   735
   End
   Begin VB.Timer Timer1 
      Left            =   240
      Top             =   7920
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   5145
      Left            =   120
      Picture         =   "frmCD.frx":3706
      ScaleHeight     =   5145
      ScaleWidth      =   6615
      TabIndex        =   0
      Top             =   120
      Width           =   6615
   End
   Begin VB.CommandButton cmdLoad 
      Caption         =   "Load Compact Disc"
      BeginProperty Font 
         Name            =   "Aladdin"
         Size            =   21.75
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   765
      Left            =   840
      MaskColor       =   &H00000000&
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   6240
      Width           =   4935
   End
   Begin MCI.MMControl CD 
      Height          =   375
      Left            =   1440
      TabIndex        =   5
      Top             =   7680
      Visible         =   0   'False
      Width           =   3540
      _ExtentX        =   6244
      _ExtentY        =   661
      _Version        =   393216
      DeviceType      =   ""
      FileName        =   ""
   End
   Begin VB.Label Label4 
      Height          =   255
      Left            =   5160
      TabIndex        =   1
      Top             =   7080
      Width           =   735
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      Caption         =   "Currently Playing Track:"
      Height          =   255
      Left            =   3240
      TabIndex        =   2
      Top             =   7080
      Width           =   1815
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "Number of Tracks:"
      Height          =   255
      Left            =   720
      TabIndex        =   3
      Top             =   7080
      Width           =   1695
   End
   Begin VB.Label Label1 
      Height          =   255
      Left            =   2520
      TabIndex        =   4
      Top             =   7080
      Width           =   735
   End
End
Attribute VB_Name = "Form4"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdLoad_Click()
CD.Command = "Open"
Label1.Caption = Str(CD.Tracks)

End Sub

Private Sub Eject_Click()
CD.Command = "Eject"
CD.Command = "Close"
Label1.Caption = "0"
Label4.Caption = "0"
Timer1.Enabled = False

End Sub

Private Sub Command8_Click()
frmAudioRecorder.Show
frmSettings.Show

End Sub

Private Sub Form_Load()
CD.Wait = True
CD.UpdateInterval = 0
CD.DeviceType = "CDAudio"
Label1.Caption = "0"
Label4.Caption = "0"
End Sub

Private Sub Form_Unload(Cancel As Integer)
cmdLoad_Click
CD.Command = "Stop"
CD.Command = "Close"
Form2.Show

End Sub

Private Sub Next_Click()
CD.Command = "Next"
Label4.Caption = Str(CD.Track)

End Sub

Private Sub Pause_Click()
CD.Command = "Pause"
CD.UpdateInterval = 0
Timer1.Enabled = False

End Sub

Private Sub Play_Click()
CD.Command = "Play"
CD.UpdateInterval = 1000
Label4.Caption = Str(CD.Track)
Timer1.Enabled = True

End Sub

Private Sub Previous_Click()
CD.Command = "Prev"
Label4.Caption = Str(CD.Track)

End Sub
Private Sub Stop_Click()
CD.Command = "Stop"
CD.UpdateInterval = 0
CD.To = CD.Start
CD.Track = 1
Label4.Caption = "1"
Timer1.Enabled = False

End Sub
