VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Object = "{CFCDAA00-8BE4-11CF-B84B-0020AFBBCCFA}#1.0#0"; "RMOC3260.DLL"
Object = "{22D6F304-B0F6-11D0-94AB-0080C74C7E95}#1.0#0"; "MSDXM.OCX"
Object = "{D27CDB6B-AE6D-11CF-96B8-444553540000}#1.0#0"; "SWFLASH.OCX"
Begin VB.Form Form2 
   Caption         =   "Media Player 2000"
   ClientHeight    =   7095
   ClientLeft      =   165
   ClientTop       =   930
   ClientWidth     =   6855
   Icon            =   "Form2.frx":0000
   LinkTopic       =   "Form2"
   ScaleHeight     =   7095
   ScaleWidth      =   6855
   StartUpPosition =   2  'CenterScreen
   Begin MSComctlLib.ProgressBar Status 
      Height          =   255
      Left            =   1200
      TabIndex        =   16
      Top             =   5880
      Width           =   3855
      _ExtentX        =   6800
      _ExtentY        =   450
      _Version        =   393216
      Appearance      =   1
      Scrolling       =   1
   End
   Begin VB.CommandButton Command6 
      Height          =   495
      Left            =   5160
      Picture         =   "Form2.frx":0442
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   6480
      Width           =   1695
   End
   Begin VB.Timer Timer4 
      Interval        =   1
      Left            =   4200
      Top             =   8160
   End
   Begin MSComctlLib.Slider Volume 
      Height          =   495
      Left            =   5160
      TabIndex        =   13
      ToolTipText     =   "Volume"
      Top             =   5880
      Width           =   1575
      _ExtentX        =   2778
      _ExtentY        =   873
      _Version        =   393216
      SelStart        =   10
      Value           =   10
   End
   Begin VB.HScrollBar HScroll1 
      Height          =   255
      Left            =   240
      TabIndex        =   12
      Top             =   7440
      Visible         =   0   'False
      Width           =   4935
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   420
      Left            =   0
      TabIndex        =   10
      Top             =   0
      Width           =   6855
      _ExtentX        =   12091
      _ExtentY        =   741
      ButtonWidth     =   609
      ButtonHeight    =   582
      Appearance      =   1
      ImageList       =   "ImageList"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   16
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "CD"
            Object.ToolTipText     =   "Open A CD"
            ImageIndex      =   5
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Standard"
            Object.ToolTipText     =   "Open Standard Windows Media File"
            ImageIndex      =   6
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button6 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Windows"
            Object.ToolTipText     =   "Open Windows Media Player File"
            ImageIndex      =   7
         EndProperty
         BeginProperty Button7 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button8 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Video"
            Object.ToolTipText     =   "Open Video File"
            ImageIndex      =   8
         EndProperty
         BeginProperty Button9 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button10 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Real"
            Object.ToolTipText     =   "Open Realplayer File"
            ImageIndex      =   13
         EndProperty
         BeginProperty Button11 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button12 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Internet"
            Object.ToolTipText     =   "Open Streaming Media"
            ImageIndex      =   9
         EndProperty
         BeginProperty Button13 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button14 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Shock"
            Object.ToolTipText     =   "Open Shockwave Flash File"
            ImageIndex      =   12
         EndProperty
         BeginProperty Button15 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button16 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Key             =   "Exit"
            Object.ToolTipText     =   "Exit Multimedia Suite"
            ImageIndex      =   2
         EndProperty
      EndProperty
   End
   Begin VB.CommandButton Command8 
      Height          =   735
      Left            =   4320
      Picture         =   "Form2.frx":18C4
      Style           =   1  'Graphical
      TabIndex        =   8
      Top             =   6240
      Width           =   735
   End
   Begin VB.CommandButton Command5 
      Height          =   735
      Left            =   3480
      Picture         =   "Form2.frx":213A
      Style           =   1  'Graphical
      TabIndex        =   7
      Top             =   6240
      Width           =   735
   End
   Begin VB.CommandButton Command4 
      Height          =   735
      Left            =   2640
      Picture         =   "Form2.frx":29B0
      Style           =   1  'Graphical
      TabIndex        =   6
      Top             =   6240
      Width           =   735
   End
   Begin VB.CommandButton Command3 
      Height          =   735
      Left            =   1800
      Picture         =   "Form2.frx":3226
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   6240
      Width           =   735
   End
   Begin VB.CommandButton Command2 
      Height          =   735
      Left            =   960
      Picture         =   "Form2.frx":3A9C
      Style           =   1  'Graphical
      TabIndex        =   4
      Top             =   6240
      Width           =   735
   End
   Begin VB.CommandButton Command1 
      Height          =   735
      Left            =   120
      Picture         =   "Form2.frx":4312
      Style           =   1  'Graphical
      TabIndex        =   3
      Top             =   6240
      Width           =   735
   End
   Begin VB.PictureBox Picture1 
      Height          =   5175
      Left            =   120
      Picture         =   "Form2.frx":4B88
      ScaleHeight     =   5115
      ScaleWidth      =   6615
      TabIndex        =   1
      Top             =   600
      Width           =   6680
      Begin VB.Timer Timer5 
         Interval        =   1
         Left            =   6000
         Top             =   720
      End
      Begin RealAudioObjectsCtl.RealAudio RealVideo 
         Height          =   2175
         Left            =   1920
         TabIndex        =   14
         Top             =   1440
         Visible         =   0   'False
         Width           =   2895
         _ExtentX        =   5106
         _ExtentY        =   3836
         AUTOSTART       =   0   'False
         SHUFFLE         =   0   'False
         PREFETCH        =   0   'False
         NOLABELS        =   0   'False
         CONTROLS        =   "ImageWindow"
         CONSOLE         =   "Real"
         LOOP            =   0   'False
         NUMLOOP         =   0
         CENTER          =   0   'False
         MAINTAINASPECT  =   0   'False
         BACKGROUNDCOLOR =   "#000000"
      End
      Begin VB.Timer Timer3 
         Interval        =   1
         Left            =   360
         Top             =   360
      End
      Begin VB.Timer Timer2 
         Interval        =   1
         Left            =   240
         Top             =   1080
      End
      Begin ShockwaveFlashObjectsCtl.ShockwaveFlash Flash 
         Height          =   2895
         Left            =   6360
         TabIndex        =   9
         Top             =   1080
         Visible         =   0   'False
         Width           =   2895
         _cx             =   4199410
         _cy             =   4199410
         Movie           =   ""
         Src             =   ""
         WMode           =   "Window"
         Play            =   -1  'True
         Loop            =   -1  'True
         Quality         =   "High"
         SAlign          =   ""
         Menu            =   -1  'True
         Base            =   ""
         Scale           =   "ShowAll"
         DeviceFont      =   0   'False
         EmbedMovie      =   0   'False
         BGColor         =   ""
         SWRemote        =   ""
      End
      Begin MediaPlayerCtl.MediaPlayer Media 
         Height          =   3015
         Left            =   3480
         TabIndex        =   2
         ToolTipText     =   "System Software's Multimedia Suite 2000"
         Top             =   4080
         Visible         =   0   'False
         Width           =   3585
         AudioStream     =   -1
         AutoSize        =   -1  'True
         AutoStart       =   -1  'True
         AnimationAtStart=   0   'False
         AllowScan       =   -1  'True
         AllowChangeDisplaySize=   0   'False
         AutoRewind      =   -1  'True
         Balance         =   0
         BaseURL         =   ""
         BufferingTime   =   3
         CaptioningID    =   ""
         ClickToPlay     =   -1  'True
         CursorType      =   0
         CurrentPosition =   -1
         CurrentMarker   =   0
         DefaultFrame    =   ""
         DisplayBackColor=   0
         DisplayForeColor=   16777215
         DisplayMode     =   0
         DisplaySize     =   4
         Enabled         =   -1  'True
         EnableContextMenu=   0   'False
         EnablePositionControls=   0   'False
         EnableFullScreenControls=   0   'False
         EnableTracker   =   0   'False
         Filename        =   ""
         InvokeURLs      =   -1  'True
         Language        =   -1
         Mute            =   0   'False
         PlayCount       =   1
         PreviewMode     =   0   'False
         Rate            =   1
         SAMILang        =   ""
         SAMIStyle       =   ""
         SAMIFileName    =   ""
         SelectionStart  =   -1
         SelectionEnd    =   -1
         SendOpenStateChangeEvents=   -1  'True
         SendWarningEvents=   -1  'True
         SendErrorEvents =   0   'False
         SendKeyboardEvents=   0   'False
         SendMouseClickEvents=   0   'False
         SendMouseMoveEvents=   0   'False
         SendPlayStateChangeEvents=   -1  'True
         ShowCaptioning  =   0   'False
         ShowControls    =   0   'False
         ShowAudioControls=   -1  'True
         ShowDisplay     =   0   'False
         ShowGotoBar     =   0   'False
         ShowPositionControls=   -1  'True
         ShowStatusBar   =   0   'False
         ShowTracker     =   -1  'True
         TransparentAtStart=   0   'False
         VideoBorderWidth=   10
         VideoBorderColor=   0
         VideoBorder3D   =   -1  'True
         Volume          =   0
         WindowlessVideo =   0   'False
      End
   End
   Begin MSComctlLib.ImageList ImageList 
      Left            =   5040
      Top             =   8040
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   14
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":72F66
            Key             =   ""
            Object.Tag             =   "&Open"
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":734AA
            Key             =   ""
            Object.Tag             =   "&Exit"
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":7364A
            Key             =   ""
            Object.Tag             =   "&Graphics Editor"
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":73AD6
            Key             =   ""
            Object.Tag             =   "&Audio or Video"
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":741EA
            Key             =   ""
            Object.Tag             =   "Open A CD"
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":74E3E
            Key             =   ""
            Object.Tag             =   "Standard File Formats"
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":75972
            Key             =   ""
            Object.Tag             =   "Windows Media Player Formats"
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":75CC6
            Key             =   ""
            Object.Tag             =   "Video Files"
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":76652
            Key             =   ""
            Object.Tag             =   "Internet Based Music"
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":772A6
            Key             =   ""
            Object.Tag             =   "&About"
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":774C2
            Key             =   ""
            Object.Tag             =   "&Help File"
         EndProperty
         BeginProperty ListImage12 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":77A06
            Key             =   ""
            Object.Tag             =   "Shockwave Flash"
         EndProperty
         BeginProperty ListImage13 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":77D2A
            Key             =   ""
            Object.Tag             =   "Real Player Files"
         EndProperty
         BeginProperty ListImage14 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "Form2.frx":77FEE
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   5640
      Top             =   8040
   End
   Begin RealAudioObjectsCtl.RealAudio RealPlayer 
      Height          =   1335
      Left            =   1560
      TabIndex        =   0
      Top             =   8040
      Visible         =   0   'False
      Width           =   2175
      _ExtentX        =   3836
      _ExtentY        =   2355
      AUTOSTART       =   -1  'True
      SHUFFLE         =   0   'False
      PREFETCH        =   0   'False
      NOLABELS        =   0   'False
      CONTROLS        =   "All"
      CONSOLE         =   "Real"
      LOOP            =   0   'False
      NUMLOOP         =   0
      CENTER          =   0   'False
      MAINTAINASPECT  =   0   'False
      BACKGROUNDCOLOR =   "#000000"
   End
   Begin MSComDlg.CommonDialog CMDialog1 
      Left            =   6120
      Top             =   8040
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label Label2 
      Caption         =   "Track Position:"
      Height          =   255
      Left            =   120
      TabIndex        =   17
      Top             =   5880
      Width           =   1095
   End
   Begin VB.Label info 
      Height          =   255
      Left            =   240
      TabIndex        =   11
      Top             =   8400
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.Shape Shape8 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   4320
      Top             =   6300
      Width           =   735
   End
   Begin VB.Shape Shape5 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   3480
      Top             =   6300
      Width           =   735
   End
   Begin VB.Shape Shape4 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   2640
      Top             =   6300
      Width           =   735
   End
   Begin VB.Shape Shape3 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   1800
      Top             =   6300
      Width           =   735
   End
   Begin VB.Shape Shape2 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   960
      Top             =   6300
      Width           =   735
   End
   Begin VB.Shape Shape1 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H00808080&
      FillStyle       =   0  'Solid
      Height          =   735
      Left            =   180
      Top             =   6300
      Width           =   735
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&File"
      Begin VB.Menu mnuFileOpen 
         Caption         =   "&Open"
         Begin VB.Menu mnuFileOpenMed 
            Caption         =   "&Media Player"
         End
         Begin VB.Menu mnuFileLiner 
            Caption         =   "-"
         End
         Begin VB.Menu mnuAudio 
            Caption         =   "&Audio or Video"
            Begin VB.Menu mnuFileOpenCD 
               Caption         =   "Open A CD"
            End
            Begin VB.Menu mnuFileOpenStandard 
               Caption         =   "Standard File Formats"
            End
            Begin VB.Menu mnuFileOpenWindows 
               Caption         =   "Windows Media Player Formats"
            End
            Begin VB.Menu mnuFileOpenVideos 
               Caption         =   "Video Files"
            End
            Begin VB.Menu mnuFileOpenReal 
               Caption         =   "Real Player Files"
            End
            Begin VB.Menu mnuFileOpenInternet 
               Caption         =   "Internet Based Music"
            End
            Begin VB.Menu mnuFileOpenFlash 
               Caption         =   "Shockwave Flash"
            End
         End
      End
      Begin VB.Menu mnuFileLine 
         Caption         =   "-"
      End
      Begin VB.Menu mnuFileExit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu mnuHelp 
      Caption         =   "&Help"
      Begin VB.Menu mnuHelpAbout 
         Caption         =   "&About"
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub RealVol()
If Volume.Value = 0 Then RealPlayer.SetVolume 0
If Volume.Value = 1 Then RealPlayer.SetVolume 10
If Volume.Value = 2 Then RealPlayer.SetVolume 20
If Volume.Value = 3 Then RealPlayer.SetVolume 30
If Volume.Value = 4 Then RealPlayer.SetVolume 40
If Volume.Value = 5 Then RealPlayer.SetVolume 50
If Volume.Value = 6 Then RealPlayer.SetVolume 60
If Volume.Value = 7 Then RealPlayer.SetVolume 70
If Volume.Value = 8 Then RealPlayer.SetVolume 80
If Volume.Value = 9 Then RealPlayer.SetVolume 90
If Volume.Value = 10 Then RealPlayer.SetVolume 99
End Sub
Private Sub MediaVol()
If Volume.Value = 0 Then Media.Volume = -9640
If Volume.Value = 1 Then Media.Volume = -2000
If Volume.Value = 2 Then Media.Volume = -1390
If Volume.Value = 3 Then Media.Volume = -1040
If Volume.Value = 4 Then Media.Volume = -790
If Volume.Value = 5 Then Media.Volume = -600
If Volume.Value = 6 Then Media.Volume = -440
If Volume.Value = 7 Then Media.Volume = -300
If Volume.Value = 8 Then Media.Volume = -190
If Volume.Value = 9 Then Media.Volume = -90
If Volume.Value = 10 Then Media.Volume = 0

End Sub
Private Sub Real()
If HScroll1.Value = HScroll1.Max Then
RealPlayer.SetPosition 0
RealPlayer.DoPlay
Else
RealPlayer.DoPlay
End If
End Sub
Private Sub Command1_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command1.Left = Command1.Left + 60
    Command1.Top = Command1.Top + 60

End Sub

Private Sub Command1_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command1.Left = Command1.Left - 60
    Command1.Top = Command1.Top - 60

End Sub

Private Sub Command6_Click()
MsgBox "Media Player 2000, Copyright Matthew Kingshott. All Rights Reserved.", vbInformation, Me.Caption

End Sub

Private Sub Form_Load()
Shape2.Left = Shape2.Left + 60
Shape3.Left = Shape3.Left + 60
Shape4.Left = Shape4.Left + 60
Shape5.Left = Shape5.Left + 60
Shape8.Left = Shape8.Left + 60

RealVideo.Top = (Picture1.Height - RealVideo.Height) / 2
RealVideo.Left = (Picture1.Width - RealVideo.Width) / 2

End Sub

Private Sub Form_Unload(Cancel As Integer)
  End

End Sub

Private Sub HScroll1_Change()
If info.Caption = "Media" Then
Media.CurrentPosition = HScroll1.Value
Else
RealPlayer.SetPositon = HScroll1.Value
End If
End Sub

Private Sub mnuFileExit_Click()
Unload Me
End

End Sub

Private Sub mnuFileOpen_Click()
CMDialog1.FileName = ""
End Sub

Private Sub mnuFileOpenCD_Click()
Form4.Show
Me.Hide

End Sub

Private Sub mnuFileOpenFlash_Click()
    Dim msec As Double
RealPlayer.DoStop
RealVideo.DoStop
Media.Stop
info.Caption = "Flash"

' Set the number of milliseconds between successive
    ' Display the File Open dialog box.
    CMDialog1.Filter = "Shockwave Flash Files (*.swf*)|*.swf*"
    CMDialog1.FilterIndex = 1
    CMDialog1.InitDir = "C:\MRK Sounds\Wwf\"
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1

    If Err <> 0 Then
        ' No file selected from the Open File dialog box.
        Exit Sub
    End If
    On Error Resume Next
    Flash.Visible = True
    Flash.Movie = CMDialog1.FileName
    Flash.Play
    Media.Visible = False
    RealVideo.Visible = False
Status.Max = Flash.TotalFrames
End Sub

Private Sub mnuFileOpenInternet_Click()
Dim msec As Double
RealPlayer.DoStop
RealVideo.DoStop
Flash.Visible = False
info.Caption = "Media"

' Set the number of milliseconds between successive
    ' Display the File Open dialog box.
    Select Case MsgBox("Warning: These are internet based connections, you must be connected to the internet to view them." & vbCr & vbCr & _
            "Do you wish to proceed?", _
            vbExclamation + vbYesNo, Me.Caption)
    
    Case vbNo
    
    Exit Sub
    
    Case vbYes
    CMDialog1.Filter = "ASF Files (*.asf*)|*.asf*|ASX Files (*.asx*)|*.asx*"
    CMDialog1.FilterIndex = 1
    
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1

    If Err <> 0 Then
        ' No file selected from the Open File dialog box.
        Exit Sub
    End If
    On Error Resume Next
    Media.FileName = CMDialog1.FileName
    Media.Play
    Media.Visible = False
        Progress.Max = Media.Duration
    RealVideo.Visible = False
Status.Max = Media.Duration
    ' If the device is open close it.
    ' Open the device with the new filename.
    On Error Resume Next
    On Error GoTo 0
End Select
End Sub
Private Sub mnuFileOpenReal_Click()
Dim msec As Double
Flash.Visible = False
info.Caption = "Real"

    Media.Stop
    CMDialog1.Filter = "Real Audio Files (*.ra*)|*.ra|Real Movies (*.rm*)|*.rm*|Real Audio Media (*.ram*)|*.ram*|Real Musix JukeBox Files (*.rmj*)|*.rmj*|Real Media Movies (*.rmm*)|*.rmm*|Real Jukebox Secure Files (*.rmx*)|*.rmx*|Real Pix Files (*.rp*)|*.rp*"
    CMDialog1.FilterIndex = 1
    CMDialog1.InitDir = "C:\MRK Sounds\Wwf\"
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1

    If Err <> 0 Then
        Exit Sub
    End If
    On Error Resume Next
    
    RealPlayer.Source = "File:" & CMDialog1.FileName
    RealVideo.Visible = True
    Media.FileName = ""
    Media.Stop
    Media.Visible = False
    HScroll1.Max = RealPlayer.GetLength
    MsgBox "RealPlayer File selected. Track Position disabled.", vbInformation, Me.Caption
    On Error Resume Next
    On Error GoTo 0
End Sub

Private Sub mnuFileOpenStandard_Click()
    Dim msec As Double
RealPlayer.DoStop
RealVideo.DoStop

Flash.Visible = False
info.Caption = "Media"
' Set the number of milliseconds between successive
    ' Display the File Open dialog box.
    CMDialog1.Filter = "Wave Files (*.wav*)|*.wav*|MP3 Files (*.mp3*)|*.mp3*|MP1 Files (*.mp1*)|*.mp1*|Midi Files (*.mid*)|*.mid*|AU Files (*.au*)|*.au*|AIFF Files (*.aiff*)|*.aiff*"
    CMDialog1.FilterIndex = 1
    CMDialog1.InitDir = "C:\MRK Sounds\Wwf\"
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1
    If Err <> 0 Then
        ' No file selected from the Open File dialog box.
        Exit Sub
    End If
    On Error Resume Next
    Media.FileName = CMDialog1.FileName
    Media.Play
    Media.Visible = False
    RealVideo.Visible = False
    Status.Max = Media.Duration
    ' If the device is open close it.
    ' Open the device with the new filename.
    On Error Resume Next
    On Error GoTo 0
    
    ' Set the timing labels on the form.

End Sub

Private Sub mnuFileOpenVideos_Click()
Dim msec As Double
    RealPlayer.DoStop
RealVideo.DoStop
Flash.Visible = False
info.Caption = "Media"

' Set the number of milliseconds between successive
    ' Display the File Open dialog box.
    CMDialog1.Filter = "Windows Video Files (*.avi*)|*.avi*|Indeo Video Files (*.ivf*)|*.ivf*|M1V Files (*.m1v*)|*.m1v*|MP2V Files (*.mp2v*)|*.mp2v*|MPA Files (*.mpa*)|*.mpa*|MPE Movies Files (*.mpe*)|*.mpe*|MPEG Movie Files (*.mpeg*)|*.mpeg*|MPG Movies Files (*.mpg*)|*.mpg*"
    CMDialog1.FilterIndex = 1
    CMDialog1.InitDir = "C:\MRK Sounds\Wwf\"
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1

    If Err <> 0 Then
        ' No file selected from the Open File dialog box.
        Exit Sub
    End If
    On Error Resume Next
    Media.FileName = CMDialog1.FileName
    Media.Play
    Media.Visible = True
    Progress.Max = Media.Duration
    RealVideo.Visible = False
Status.Max = Media.Duration
    ' If the device is open close it.
    ' Open the device with the new filename.
    On Error Resume Next
    On Error GoTo 0
    
    ' Set the timing labels on the form.



End Sub

Private Sub mnuFileOpenWindows_Click()
    Dim msec As Double
RealVideo.DoStop
RealPlayer.DoStop
Flash.Visible = False
info.Caption = "Media"

' Set the number of milliseconds between successive
    ' Display the File Open dialog box.
    CMDialog1.Filter = "Windows Audio X Files (*.wax*)|*.wax*|Windows Media Audio Files (*.wma*)|*.wma*|Windows Media Videos Files (*.wmv*)|*.wmv*|Windows Video X Files (*.wvx*)|*.wvx*"
    CMDialog1.FilterIndex = 1
    CMDialog1.InitDir = "C:\MRK Sounds\Wwf\"
    CMDialog1.Flags = vbOFNReadOnly Or vbOFNFileMustExist
    CMDialog1.CancelError = True
    On Error Resume Next
    CMDialog1.Action = 1

    If Err <> 0 Then
        ' No file selected from the Open File dialog box.
        Exit Sub
    End If
    On Error Resume Next
    Media.FileName = CMDialog1.FileName
    Media.Play
    Media.Visible = False
        RealVideo.Visible = False
Status.Max = Media.Duration
    ' If the device is open close it.
    ' Open the device with the new filename.
    On Error Resume Next
    On Error GoTo 0
    
    ' Set the timing labels on the form.
End Sub

Private Sub mnuHelpAbout_Click()
MsgBox "Media Player 2000, Copyright Matthew Kingshott.", vbInformation, Me.Caption

End Sub

Private Sub Timer1_Timer()
Flash.Top = (Picture1.Height - Flash.Height) / 2
Flash.Left = (Picture1.Width - Flash.Width) / 2

End Sub

Private Sub Timer2_Timer()
Media.ShowControls = False
End Sub

Private Sub Timer3_Timer()
Media.Top = (Picture1.Height - Media.Height) / 2
Media.Left = (Picture1.Width - Media.Width) / 2
End Sub


Private Sub Command1_Click()
If info.Caption = "Media" Then
Media.Play
Else
Call Real
End If
End Sub

Private Sub Command2_Click()
If info.Caption = "Media" Then
Media.Pause
Else
RealPlayer.DoPause
End If
End Sub

Private Sub Command3_Click()
If info.Caption = "Media" Then
Media.Stop
Else
RealPlayer.DoStop
End If
End Sub

Private Sub Command4_Click()
If info.Caption = "Media" Then
Media.CurrentPosition = 0
Else
RealPlayer.SetPosition 0
End If
End Sub

Private Sub Command5_Click()
If info.Caption = "Media" Then
Media.CurrentPosition = Media.CurrentPosition + 1
Else
Exit Sub
End If
End Sub

Private Sub Command8_Click()
frmAudioRecorder.Show
frmSettings.Show

End Sub

Private Sub Command2_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command2.Left = Command2.Left + 60
    Command2.Top = Command2.Top + 60

End Sub

Private Sub Command2_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command2.Left = Command2.Left - 60
    Command2.Top = Command2.Top - 60

End Sub

Private Sub Command3_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command3.Left = Command3.Left + 60
    Command3.Top = Command3.Top + 60

End Sub

Private Sub Command3_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command3.Left = Command3.Left - 60
    Command3.Top = Command3.Top - 60

End Sub

Private Sub Command4_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command4.Left = Command4.Left + 60
    Command4.Top = Command4.Top + 60

End Sub

Private Sub Command4_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command4.Left = Command4.Left - 60
    Command4.Top = Command4.Top - 60
End Sub


Private Sub Command5_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command5.Left = Command5.Left + 60
    Command5.Top = Command5.Top + 60

End Sub

Private Sub Command5_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command5.Left = Command5.Left - 60
    Command5.Top = Command5.Top - 60

End Sub

Private Sub Command8_MouseDown(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command8.Left = Command8.Left + 60
    Command8.Top = Command8.Top + 60

End Sub

Private Sub Command8_MouseUp(Button As Integer, Shift As Integer, x As Single, y As Single)
    Command8.Left = Command8.Left - 60
    Command8.Top = Command8.Top - 60

End Sub

Private Sub Timer4_Timer()
If info.Caption = "Media" Then
Call MediaVol
Else
Call RealVol
End If
End Sub

Private Sub Timer5_Timer()
If info.Caption = "Media" Then
Status.Value = Media.CurrentPosition
ElseIf info.Caption = "Flash" Then
Status.Value = Flash.CurrentFrame
End If
End Sub

Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
On Error Resume Next
    ' Just tells the toolbar buttons what to do...
    Select Case Button.Key
        
        Case "CD"
            mnuFileOpenCD_Click
        
        Case "Standard"
            mnuFileOpenStandard_Click
        
        Case "Windows"
           mnuFileOpenWindows_Click
        
        Case "Video"
            mnuFileOpenVideos_Click
        
        Case "Real"
mnuFileOpenReal_Click

        
        
                Case "Internet"
            mnuFileOpenInternet_Click
        
                        Case "Shock"
            mnuFileOpenFlash_Click

        
                Case "Exit"
            
            mnuFileExit_Click
        
                
End Select

End Sub

Private Sub Toolbar1_Click()
CMDialog1.FileName = ""
End Sub

Private Sub Volume_Click()
If info.Caption = "Media" Then
Call MediaVol
Else
Call Real
End If

End Sub
