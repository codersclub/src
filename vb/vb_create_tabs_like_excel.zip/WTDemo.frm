VERSION 5.00
Object = "{D1558013-91A7-11D4-AA5B-00A0CC334D72}#2.0#0"; "WWTabs.ocx"
Begin VB.Form WTDemo 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "WhiteTabs Demo"
   ClientHeight    =   3255
   ClientLeft      =   3330
   ClientTop       =   2370
   ClientWidth     =   5475
   Icon            =   "WTDemo.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3255
   ScaleWidth      =   5475
   Begin VB.CommandButton Command1 
      Caption         =   "&Yes I like it!"
      Height          =   390
      Left            =   3090
      TabIndex        =   10
      Top             =   2835
      Width           =   2355
   End
   Begin VB.CommandButton Command2 
      Caption         =   "No, I want &Real Example"
      Height          =   390
      Left            =   -15
      TabIndex        =   12
      Top             =   2835
      Width           =   3075
   End
   Begin WWTabs.WTabs WT 
      Height          =   300
      Left            =   15
      TabIndex        =   0
      Top             =   2175
      Width           =   5430
      _ExtentX        =   9578
      _ExtentY        =   529
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CaptionTips     =   "Tool Tip One|...and Two|cmon, it's disabled!|ListBox Control|Sinus World|Try different Views"
      Captions        =   "&One|Tw&o|(&disabled)|ListBox|&Graphic|&Appearance"
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   1065
      Left            =   525
      ScaleHeight     =   69
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   141
      TabIndex        =   5
      Top             =   690
      Visible         =   0   'False
      Width           =   2145
      Begin VB.OptionButton optView 
         BackColor       =   &H80000005&
         Caption         =   "Tab's Fake3D"
         Height          =   225
         Index           =   2
         Left            =   615
         TabIndex        =   9
         Top             =   720
         Width           =   1395
      End
      Begin VB.OptionButton optView 
         BackColor       =   &H80000005&
         Caption         =   "I like 3D!"
         Height          =   225
         Index           =   1
         Left            =   615
         TabIndex        =   8
         Top             =   495
         Width           =   1395
      End
      Begin VB.OptionButton optView 
         BackColor       =   &H80000005&
         Caption         =   "Flat"
         Height          =   225
         Index           =   0
         Left            =   615
         TabIndex        =   6
         Top             =   270
         Value           =   -1  'True
         Width           =   870
      End
      Begin VB.Label Label1 
         AutoSize        =   -1  'True
         BackStyle       =   0  'Transparent
         Caption         =   "Try some..."
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   8.25
            Charset         =   0
            Weight          =   400
            Underline       =   -1  'True
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         Height          =   195
         Left            =   0
         TabIndex        =   7
         Top             =   0
         Width           =   780
      End
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      ForeColor       =   &H80000008&
      Height          =   540
      Left            =   300
      ScaleHeight     =   34
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   97
      TabIndex        =   4
      Top             =   540
      Visible         =   0   'False
      Width           =   1485
   End
   Begin VB.ListBox List1 
      Appearance      =   0  'Flat
      Height          =   450
      IntegralHeight  =   0   'False
      ItemData        =   "WTDemo.frx":014A
      Left            =   120
      List            =   "WTDemo.frx":015D
      TabIndex        =   3
      Top             =   360
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.TextBox Text2 
      Appearance      =   0  'Flat
      BorderStyle     =   0  'None
      Enabled         =   0   'False
      Height          =   600
      Left            =   60
      MultiLine       =   -1  'True
      TabIndex        =   2
      Text            =   "WTDemo.frx":018A
      Top             =   1455
      Width           =   5280
   End
   Begin VB.TextBox Text1 
      Height          =   1845
      Left            =   15
      MultiLine       =   -1  'True
      TabIndex        =   1
      Text            =   "WTDemo.frx":020A
      Top             =   255
      Width           =   5430
   End
   Begin VB.Label Label2 
      BackStyle       =   0  'Transparent
      Caption         =   "Some useless exercises with very useful WTabs control"
      Height          =   195
      Left            =   15
      TabIndex        =   11
      Top             =   30
      Width           =   4440
   End
End
Attribute VB_Name = "WTDemo"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'
' WTabs Demo Project - general
' (c) 2000, Dmitry Apukhtin
'

'
' here goes code related to WTab itself
'
Private Sub Form_Load()
    ' disable third tab - just for demonstration purpose
    WT.TabEnabled(2) = False
    
    ' make form look right - call WTab's Click event handler
    ' False tells event handler that it's not really
    ' click - so don't bother about focus stuff
    wt_Click False
    
    ' just more preparations
    List1.ListIndex = 3
    Text1.Appearance = 0
End Sub

Private Sub Form_Resize()
    On Error Resume Next ' for case of minimizing form
    
    ' stick WTabs to bottom of Text1 control - with little overlap.
    ' note that wt control on form is on top (made "Bring to Front")
    WT.Move Text1.Left, Text1.Top + Text1.Height - 30, Text1.Width ', Text1.Height
    
    ' make other dependent controls same size
    List1.Move Text1.Left, Text1.Top, Text1.Width, Text1.Height
    Picture1.Move Text1.Left, Text1.Top, Text1.Width, Text1.Height
    Picture2.Move Text1.Left, Text1.Top, Text1.Width, Text1.Height
End Sub

Private Sub wt_Click(ByVal RealClick As Boolean)
    ' ok, this is "main" and only event of WTabs
    ' here we show and hide appropriate controls
    ' depending on which tab is active
    ' and, of course, do whatever you have to do upon WTabs' switch

    ' just some activity - make Text1 control contain ActiveTab's caption
    Text1 = WT.TabCaption(WT)
    
    ' the only one control will be visible - depending on ActiveTab
    Text1.Visible = WT <= 2
    List1.Visible = WT = 3
    Picture1.Visible = WT = 4
    Picture2.Visible = WT = 5
    
    ' if it was "real" click - ie, user's mouseclick - we have to
    ' forward focus to appropriate control. since WTabs control has
    ' TabIndex property set to 0 and all dependent controls TabIndexes are
    ' sequent (ie Text1 is 1, List1 is 2 etc), all we need to do is
    ' shift focus to next control in VB Tabs sequence - VB will take care
    ' about hidden controls.
    ' will do that by emulating TAB key press
    If RealClick Then SendKeys "{TAB}"
End Sub

Private Sub Picture2_GotFocus()
    ' we need this to activate Option group because
    ' after wt_Click's event we will have focus on
    ' Picture2 itself - not exactly what we need
    SendKeys "{TAB}"
End Sub

'
' here goes just misc code - not related to WTabs
' just to make Demo more fun
Private Sub List1_Click()
    WT.TabCaption(3) = List1
End Sub

Private Sub optView_Click(Index As Integer)
    Dim ctl As Control, a As Long
    If Index > 0 Then a = 1
    On Error Resume Next
    Text1.BorderStyle = 0
    For Each ctl In Controls
        ctl.Appearance = a
        ctl.BackColor = vbWindowBackground
    Next
    WT.Fake3D = Index > 1
    Text1.BorderStyle = 1
End Sub

Private Sub Picture1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Picture1.CurrentX = X
    Picture1.CurrentY = Y
End Sub

Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    If Button Then Picture1.Line -(X, Y)
End Sub

Private Sub Picture1_Paint()
    With Picture1
        .CurrentY = 0
        .CurrentX = 0
        Picture1.Print "Draw here by Mouse"
        Dim Y As Long
        Y = (.ScaleHeight - 2) \ 2
        Picture1.Line (0, Y)-Step(.ScaleWidth, 0), vbBlue
        Picture1.Line (.ScaleWidth \ 2, 0)-Step(0, Y * 2), vbBlue
        Dim X As Long
        For X = 0 To .ScaleWidth
            Picture1.PSet (X, Y + Y * Sin(X / .ScaleWidth * 3.1415 * 4)), vbRed
        Next
    End With
End Sub

Private Sub Text1_Change()
    WT.TabCaption(WT) = Text1
End Sub

Private Sub Command1_Click()
    WT.Ad
End Sub

Private Sub Command2_Click()
    WTDemoFG.Show vbModal
End Sub

