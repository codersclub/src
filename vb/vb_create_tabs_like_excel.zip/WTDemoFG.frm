VERSION 5.00
Object = "{5E9E78A0-531B-11CF-91F6-C2863C385E30}#1.0#0"; "msflxgrd.ocx"
Object = "{D1558013-91A7-11D4-AA5B-00A0CC334D72}#2.0#0"; "WWTabs.ocx"
Begin VB.Form WTDemoFG 
   Caption         =   "WTabs with FlexGrid"
   ClientHeight    =   3030
   ClientLeft      =   2835
   ClientTop       =   3420
   ClientWidth     =   7830
   Icon            =   "WTDemoFG.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   ScaleHeight     =   3030
   ScaleWidth      =   7830
   Begin WWTabs.WTabs WT 
      Height          =   810
      Left            =   30
      TabIndex        =   0
      Top             =   2175
      Width           =   7755
      _ExtentX        =   13679
      _ExtentY        =   1429
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      CaptionTips     =   ""
      Captions        =   "(Tabs are populated in code as well as ToolTips)"
      Fake3D          =   -1  'True
      xLeft           =   40
      Begin VB.CommandButton bClose 
         Caption         =   "&Close"
         Height          =   345
         Left            =   6615
         TabIndex        =   8
         Top             =   330
         Width           =   1020
      End
      Begin VB.CheckBox chkTB 
         Height          =   225
         Left            =   45
         Picture         =   "WTDemoFG.frx":014A
         Style           =   1  'Graphical
         TabIndex        =   7
         ToolTipText     =   "Show/Hide ToolBar"
         Top             =   30
         Width           =   660
      End
      Begin VB.CommandButton bTB 
         Height          =   330
         Index           =   2
         Left            =   825
         Picture         =   "WTDemoFG.frx":0294
         Style           =   1  'Graphical
         TabIndex        =   4
         Tag             =   "DEL"
         Top             =   360
         Width           =   345
      End
      Begin VB.CommandButton bTB 
         Height          =   330
         Index           =   1
         Left            =   495
         Picture         =   "WTDemoFG.frx":03DE
         Style           =   1  'Graphical
         TabIndex        =   3
         Tag             =   "EDIT"
         Top             =   360
         Width           =   345
      End
      Begin VB.CommandButton bTB 
         Height          =   330
         Index           =   0
         Left            =   165
         Picture         =   "WTDemoFG.frx":0528
         Style           =   1  'Graphical
         TabIndex        =   2
         Tag             =   "NEW"
         Top             =   360
         Width           =   345
      End
      Begin VB.Label Label2 
         AutoSize        =   -1  'True
         Caption         =   "<- Place your controls on WTabs as well - it is Control's Container"
         Height          =   195
         Left            =   1245
         TabIndex        =   5
         Top             =   420
         Width           =   4575
      End
   End
   Begin MSFlexGridLib.MSFlexGrid fg 
      Height          =   2025
      Left            =   15
      TabIndex        =   6
      Top             =   225
      Width           =   7785
      _ExtentX        =   13732
      _ExtentY        =   3572
      _Version        =   393216
      BackColorBkg    =   -2147483643
      ScrollTrack     =   -1  'True
      FocusRect       =   0
      SelectionMode   =   1
      AllowUserResizing=   3
   End
   Begin VB.Label Label1 
      AutoSize        =   -1  'True
      Caption         =   "..."
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   0
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   195
      Left            =   45
      TabIndex        =   1
      Top             =   15
      Width           =   195
   End
End
Attribute VB_Name = "WTDemoFG"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'
' WTabs Demo Project - FlexGrid part
' (c) 2000, Dmitry Apukhtin
'
Const TIPSTART = "Results for "

Private Sub Form_Load()
    fg.FormatString = "             |Some    |Of     |Your        |Data        |Would Be |Here                                                  "
    WT.TabsOffset = fg.ColWidth(1)
    
    WT.Captions = getMonths("", 3) & "|Summary"
    WT.CaptionTips = getMonths(TIPSTART) & "|" & TIPSTART & "Year"
    
    wt_Click False
    chkTB_Click
End Sub

Private Function getMonths(sMsg As String, Optional MaxLen)
    Dim i As Long, v As Variant
    ReDim v(1 To 12)
    For i = 1 To 12
        v(i) = MonthName(i)
        If Not IsMissing(MaxLen) Then v(i) = Left$(v(i), MaxLen)
        v(i) = sMsg & v(i)
    Next
    getMonths = Join$(v, "|")
End Function

Private Sub Form_Resize()
    On Error Resume Next
    fg.Move 0, fg.Top, ScaleWidth, ScaleHeight - WT.Height - 210
    fg.ColWidth(6) = fg.Width - fg.ColPos(6) - 345
    WT.Move fg.Left + 15, fg.Top + fg.Height - 45, fg.Width - 30
End Sub

Private Sub bClose_Click()
    Unload Me
End Sub

Private Sub wt_Click(ByVal ActualClick As Boolean)
    Label1 = WT.TabToolTip(WT)
    fillFG WT.ActiveTab + 1, Mid$(Label1, Len(TIPSTART) + 1)
    If ActualClick Then fg.SetFocus
End Sub

Private Sub WT_GotFocus()
    fg.SetFocus
End Sub

Private Sub bTB_Click(Index As Integer)
    fg.SetFocus
    Select Case bTB(Index).Tag
        Case "NEW"
            MsgBox "Hehe, what did you expect?", vbQuestion, "New Button"
        Case "EDIT"
            MsgBox "Nope, too. Surprized?", vbExclamation, "Properties Button"
        Case "DEL"
            MsgBox "Come on, there's NOTHING!", vbCritical, "Delete Button"
    End Select
End Sub

Private Sub chkTB_Click()
    On Error Resume Next
    If chkTB Then WT.Height = 810 Else WT.Height = 300
    Form_Resize
    fg.SetFocus
End Sub

Private Sub fillFG(ByVal Month As Long, MonthName As String)
    fg.Redraw = False
    fg.Rows = 2
    If Month = 13 Then ' Summary
        fg.AddItem Replace$("He-he|Prepare|Your|Annual|Report|Here", "|", vbTab)
    Else
        Dim i As Long, ts As String
        For i = 1 To Rnd * 30 + 1
            ts = Chr(64 + Month)
            fg.AddItem "Row " & i & vbTab & Month & vbTab & ts & vbTab & "Bla" & vbTab & "Bla-Bla" & vbTab & vbTab & MonthName
        Next
    End If
    fg.RemoveItem 1
    fg.Redraw = True
End Sub

