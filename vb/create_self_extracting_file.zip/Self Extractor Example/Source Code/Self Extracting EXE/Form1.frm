VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "Self Extractor"
   ClientHeight    =   1365
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4965
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   1365
   ScaleWidth      =   4965
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox Coll 
      Height          =   450
      Left            =   1920
      TabIndex        =   6
      Top             =   1200
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3720
      TabIndex        =   3
      Top             =   600
      Width           =   1215
   End
   Begin VB.TextBox Text1 
      Height          =   405
      Left            =   840
      TabIndex        =   1
      Top             =   600
      Width           =   2775
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Extract"
      Height          =   375
      Left            =   3720
      TabIndex        =   0
      Top             =   120
      Width           =   1215
   End
   Begin VB.ListBox List1 
      Height          =   1620
      Left            =   0
      TabIndex        =   5
      Top             =   1080
      Visible         =   0   'False
      Width           =   4935
   End
   Begin VB.Label Status 
      Caption         =   "Idle"
      Height          =   255
      Left            =   0
      TabIndex        =   4
      Top             =   1080
      Width           =   4935
   End
   Begin VB.Image Image1 
      Height          =   480
      Left            =   120
      Picture         =   "Form1.frx":1272
      Top             =   240
      Width           =   480
   End
   Begin VB.Label Label1 
      Caption         =   "Please select the directory you wish to extract the file to, and click ""Extract"""
      Height          =   615
      Left            =   840
      TabIndex        =   2
      Top             =   120
      Width           =   2775
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim FFilename As String

Private Sub Command1_Click()
Dim MyString, Direc
On Error GoTo ErrHandler

Direc = Dir(Text1.Text, vbDirectory)
If Direc = "" Then
    MkDir Text1.Text
End If

Open App.Path & "\" & App.EXEName & ".exe" For Binary As #1

Status.Caption = "Finding key..."
Do While Not MyString = "-=#SELFEXTRACT#=-"
    Line Input #1, MyString
Loop

For i = 0 To List1.ListCount - 1
    
    If Right(Text1.Text, 1) = "\" Then
        FFilename = Text1.Text & List1.List(i)
    Else
        FFilename = Text1.Text & "\" & List1.List(i)
    End If
    
    Open FFilename For Binary As #2

    Status.Caption = "Extracting " & List1.List(i) & "..."
    dat$ = Coll.List(i)
    dat$ = Input(dat$, #1)
    Put #2, , dat$

    Close #2
    Status.Caption = "Extracted " & List1.List(i)
    DoEvents
Next i
Close #1
Status.Caption = "Extraction Complete!"
Exit Sub

ErrHandler:
If Err.Number = 62 Then
    MsgBox "No data was found in this file"
Else
    MsgBox "An error has occured!" & vbNewLine & Err.Number & ": " & Err.Description, vbCritical, "ERROR"
End If
Status.Caption = "Extraction failed!"
Close #1
Close #2
Kill FFilename
End Sub

Private Sub Command2_Click()
On Error Resume Next
End
Kill Text1.Text
End Sub

Private Sub Form_Load()
Dim MyString, MyString2
On Error GoTo ErrHandler
Open App.Path & "\" & App.EXEName & ".exe" For Binary As #1

Do While Not MyString = "-=#NOOFFILES#=-"
    Line Input #1, MyString
Loop
Line Input #1, MyString
Do While Not MyString2 = "-=#FILNAME#=-"
    Line Input #1, MyString2
Loop
For i = 1 To MyString
    Line Input #1, MyString2
    List1.AddItem MyString2
Next i
Do While Not MyString2 = "-=#LOFS#=-"
    Line Input #1, MyString2
Loop
For i = 1 To MyString
    Line Input #1, MyString2
    Coll.AddItem MyString2
Next i

If List1.ListCount > 1 Then
    Height = 3390
    List1.Visible = True
    Status.Top = 2760
    Caption = "Multiple Files"
Else
    Caption = List1.List(0)
End If

Close #1
Text1.Text = App.Path & "\" & App.EXEName & "\"
Exit Sub

ErrHandler:
MsgBox "This is not a valid Self Extractor file!", vbCritical, "ERROR"
Close #1
End
End Sub
