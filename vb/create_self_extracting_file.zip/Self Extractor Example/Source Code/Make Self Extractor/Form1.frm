VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form1 
   Caption         =   "Self Extractor Example"
   ClientHeight    =   5865
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6000
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   5865
   ScaleWidth      =   6000
   StartUpPosition =   3  'Windows Default
   Begin VB.ListBox Coll 
      Height          =   450
      Left            =   2400
      TabIndex        =   13
      Top             =   2640
      Visible         =   0   'False
      Width           =   1215
   End
   Begin VB.CommandButton Command7 
      Caption         =   "Remove all"
      Height          =   375
      Left            =   4133
      TabIndex        =   12
      Top             =   600
      Width           =   1215
   End
   Begin VB.CommandButton Command6 
      Caption         =   "Remove"
      Height          =   375
      Left            =   2393
      TabIndex        =   11
      Top             =   600
      Width           =   1215
   End
   Begin VB.CommandButton Command5 
      Caption         =   "Add"
      Height          =   375
      Left            =   653
      TabIndex        =   10
      Top             =   600
      Width           =   1215
   End
   Begin VB.ListBox List1 
      Height          =   3180
      Left            =   120
      TabIndex        =   9
      Top             =   1080
      Width           =   5775
   End
   Begin MSComDlg.CommonDialog CD1 
      Left            =   4800
      Top             =   5040
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton Command4 
      Caption         =   "..."
      Height          =   375
      Left            =   5520
      TabIndex        =   7
      Top             =   4560
      Width           =   375
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3600
      TabIndex        =   6
      Top             =   5040
      Width           =   1215
   End
   Begin VB.TextBox Text3 
      Height          =   405
      Left            =   1320
      TabIndex        =   4
      Top             =   4560
      Width           =   4095
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Make EXE"
      Height          =   375
      Left            =   1440
      TabIndex        =   2
      Top             =   5040
      Width           =   1095
   End
   Begin VB.CommandButton Command1 
      Caption         =   "..."
      Height          =   375
      Left            =   5520
      TabIndex        =   1
      Top             =   120
      Width           =   375
   End
   Begin VB.TextBox Text1 
      Height          =   375
      Left            =   1320
      TabIndex        =   0
      Top             =   120
      Width           =   4095
   End
   Begin MSComDlg.CommonDialog CD 
      Left            =   3480
      Top             =   3840
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label Status 
      Caption         =   "Idle"
      Height          =   495
      Left            =   120
      TabIndex        =   8
      Top             =   5640
      Width           =   6015
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      Caption         =   "Destination File:"
      Height          =   375
      Left            =   0
      TabIndex        =   5
      Top             =   4680
      Width           =   1215
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "Original File(s):"
      Height          =   255
      Left            =   0
      TabIndex        =   3
      Top             =   240
      Width           =   1215
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' Sorry there isn't any compression in here yet.
' Vote for me if you like the code

Private Sub Command1_Click()
CD.ShowOpen
If CD.filename = "" Then Exit Sub
Text1.Text = CD.filename
End Sub

Private Sub Command2_Click()
Dim MyString As String, Dat As String
Command3.Enabled = False
If List1.ListCount >= 1 Then
    MyString$ = vbNewLine & "-=#NOOFFILES#=-" & vbNewLine & List1.ListCount & _
                vbNewLine & "-=#FILNAME#=-" & vbNewLine
    For i = 0 To List1.ListCount - 1
        MyString$ = MyString & Coll.List(i) & vbNewLine
    Next i
    MyString$ = MyString$ & "-=#LOFS#=-" & vbNewLine
    For i = 0 To List1.ListCount - 1
        MyString$ = MyString & FileLen(List1.List(i)) & vbNewLine
    Next i
     MyString = MyString & "-=#SELFEXTRACT#=-" & _
                vbNewLine
Else
    MsgBox "Please select a file(s)!"
    Exit Sub
End If

DoEvents
Status.Caption = "Reading " & Text1.Text & "..."
FileCopy App.Path & "\dat\SE.dat", Text3.Text

For i = 0 To List1.ListCount - 1
    Open List1.List(i) For Binary As #1
        Dat$ = Input(LOF(1), #1)
        DoEvents
        If i = 0 Then
            MyString$ = MyString$ & Dat$
        Else
            MyString$ = Dat$
        End If
    Close #1
    Status.Caption = "Adding " & List1.List(i) & "..."
    DoEvents
    Open Text3.Text For Binary As #1
        Put #1, LOF(1) + 1, MyString$
        DoEvents
    Close #1
Next i
Command3.Enabled = True
Status.Caption = Text3.Text & " was created successfully!"
End Sub

Private Sub Command3_Click()
End
End Sub

Private Sub Command4_Click()
CD1.ShowOpen
If CD1.filename = "" Then Exit Sub
Text3.Text = CD1.filename
End Sub

Private Sub Command5_Click()
List1.AddItem Text1.Text
Coll.AddItem CD.FileTitle
End Sub

Private Sub Command6_Click()
For i = 0 To List1.ListCount - 1
    If List1.Selected(i) Then
        List1.RemoveItem i
        Coll.RemoveItem i
        Exit Sub
    End If
Next i
End Sub

Private Sub Command7_Click()
For i = 0 To List1.ListCount - 1
    Coll.RemoveItem 0
Next i
List1.Clear
End Sub
