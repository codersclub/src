VERSION 5.00
Object = "{2C1EC115-F1BA-11D3-BF43-00A0CC32BE58}#5.0#0"; "DMC2.OCX"
Begin VB.Form Main 
   BorderStyle     =   0  '������
   Caption         =   "3D Sokoban"
   ClientHeight    =   7185
   ClientLeft      =   1110
   ClientTop       =   660
   ClientWidth     =   9375
   Icon            =   "Main.frx":0000
   LinkTopic       =   "�����1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   PaletteMode     =   1  '������������ Z��������
   ScaleHeight     =   479
   ScaleMode       =   3  '�������
   ScaleWidth      =   625
   Begin VB.Timer KeyTimer 
      Enabled         =   0   'False
      Interval        =   20
      Left            =   1920
      Top             =   6540
   End
   Begin VB.PictureBox PlayScreen 
      AutoRedraw      =   -1  'True
      BackColor       =   &H00000000&
      BorderStyle     =   0  '������
      ClipControls    =   0   'False
      Height          =   6315
      Left            =   6900
      ScaleHeight     =   421
      ScaleMode       =   3  '�������
      ScaleWidth      =   613
      TabIndex        =   4
      Top             =   240
      Visible         =   0   'False
      Width           =   9195
      Begin VB.Timer BoxTimer 
         Enabled         =   0   'False
         Interval        =   100
         Left            =   780
         Top             =   5460
      End
      Begin VB.Timer IdleTimer 
         Enabled         =   0   'False
         Interval        =   2000
         Left            =   1500
         Top             =   4140
      End
      Begin VB.PictureBox preview1 
         AutoRedraw      =   -1  'True
         BorderStyle     =   0  '������
         Height          =   1005
         Left            =   8100
         ScaleHeight     =   67
         ScaleMode       =   3  '�������
         ScaleWidth      =   64
         TabIndex        =   5
         Top             =   5220
         Visible         =   0   'False
         Width           =   960
      End
   End
   Begin VB.PictureBox intro 
      BackColor       =   &H00000000&
      BorderStyle     =   0  '������
      Height          =   6735
      Left            =   0
      ScaleHeight     =   449
      ScaleMode       =   3  '�������
      ScaleWidth      =   609
      TabIndex        =   1
      Top             =   60
      Width           =   9135
      Begin VB.PictureBox loadingProgressBar 
         BackColor       =   &H0036BFF3&
         BorderStyle     =   0  '������
         FillStyle       =   5  '��������� ����
         Height          =   180
         Left            =   2640
         Picture         =   "Main.frx":0E42
         ScaleHeight     =   12
         ScaleMode       =   3  '�������
         ScaleWidth      =   256
         TabIndex        =   7
         Top             =   5100
         Visible         =   0   'False
         Width           =   3840
      End
      Begin VB.Timer timer 
         Enabled         =   0   'False
         Index           =   5
         Left            =   1020
         Top             =   2400
      End
      Begin VB.Timer timer 
         Enabled         =   0   'False
         Index           =   4
         Left            =   960
         Top             =   4080
      End
      Begin VB.Timer timer 
         Enabled         =   0   'False
         Index           =   3
         Left            =   1020
         Top             =   3660
      End
      Begin VB.Timer timer 
         Enabled         =   0   'False
         Index           =   2
         Left            =   1020
         Top             =   3240
      End
      Begin VB.Timer timer 
         Enabled         =   0   'False
         Index           =   1
         Left            =   1020
         Top             =   2820
      End
      Begin VB.Label MainMenuClose 
         Alignment       =   2  '������������ �� ������
         BackStyle       =   0  '�������
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   204
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   435
         Index           =   1
         Left            =   2580
         TabIndex        =   8
         Top             =   6000
         Width           =   3870
      End
      Begin VB.Label MainMenuButton 
         Alignment       =   2  '������������ �� ������
         BackStyle       =   0  '�������
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   204
            Weight          =   700
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   435
         Index           =   0
         Left            =   2640
         TabIndex        =   6
         Top             =   5400
         Width           =   3870
      End
      Begin VB.Label version 
         Alignment       =   1  '������������ �� ������� ����
         AutoSize        =   -1  'True
         BackStyle       =   0  '�������
         Caption         =   "Version: unknown"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   204
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   7800
         TabIndex        =   3
         Top             =   0
         Width           =   1275
      End
      Begin VB.Label �����1 
         AutoSize        =   -1  'True
         BackStyle       =   0  '�������
         Caption         =   "3D Sokoban, Copyright (c) Eremin Mikhail (aka Sen), 2001. WebSite: www.ishodniki.narod.ru (only rus)"
         BeginProperty Font 
            Name            =   "Tahoma"
            Size            =   8.25
            Charset         =   204
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H00FFFFFF&
         Height          =   195
         Left            =   60
         TabIndex        =   2
         Top             =   6540
         Width           =   7395
      End
   End
   Begin DMC2.DMC DMC 
      Left            =   5280
      Top             =   6840
      _ExtentX        =   476
      _ExtentY        =   556
   End
   Begin VB.Image MinWin 
      Height          =   195
      Left            =   8940
      Top             =   60
      Width           =   195
   End
   Begin VB.Image CloseWIn 
      Height          =   195
      Left            =   9120
      Top             =   60
      Width           =   195
   End
   Begin VB.Label Label_DvigatFormu 
      BackStyle       =   0  '�������
      Height          =   255
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   9555
   End
End
Attribute VB_Name = "Main"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
' SOKOBAN 3D
' Copyright (c) Eremin Mikhail (aka Sen)
' Russia, Ufa, 05.05.2001
'
'
' E-mail: ded_mazay@rambler.ru
' WWW. http://ishodniki.narod.ru (english pages absent)
'
'
' DO NOT RUN THIS PROGRAM UNDER VISUAL BASIC MORE THAN 2-3 TIMES!!!!!
' IT USE GDI MEMORY SO CLOSE OTHER GRAPHICAL PROGRAMS.
'

' IF DMC2.OCX WAS NOT LOADED
' RUN REGSRV32.EXE


Private barMax As Integer
Dim FrameCount As Long
Private card1 As Byte

Private Sub CloseWIn_Click()
CloseProgram

End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
PlayScreen.SetFocus
End Sub

Private Sub Form_Load()
DoEvents
If App.PrevInstance = True Then Exit Sub
SkinPath = App.Path & "\Games\" & ReadINI("GAMES", "current_game", App.Path & "\sokoban3d.dat") & "\"
Main.Picture = LoadPicture(SkinPath & ReadINI("SCREEN", "form", SkinPath & "game.dat"))
MainMenuButton(0).ForeColor = tiles.colorshape.BackColor
loadingProgressBar.FillColor = tiles.colorshape.FillColor
tiles.box.Picture = LoadPicture(SkinPath & ReadINI("FILES", "box", SkinPath & "game.dat"))
tiles.terran.Picture = LoadPicture(SkinPath & ReadINI("FILES", "terran", SkinPath & "game.dat"))
tiles.walls.Picture = LoadPicture(SkinPath & ReadINI("FILES", "walls", SkinPath & "game.dat"))
DMC.InitBASS Main.hWnd, 44000, False, False
DMC.OpenModule SkinPath & ReadINI("MUSIC_TRACKS", "menu", SkinPath & "game.dat"), True
DMC.PlayModule
DMC.SampleChanToModify = 31
Call DMC.OpenSample(SkinPath & ReadINI("SCREEN", "click1_sound", SkinPath & "game.dat"))
DMC.SampleChanToModify = 32
Call DMC.OpenSample(SkinPath & ReadINI("SCREEN", "click2_sound", SkinPath & "game.dat"))
barMax = 256
barCreateNewBar
CenterForm Main
version.Caption = "Version: " & App.Major & "." & App.Minor & App.Revision
intro.Picture = LoadPicture("games\sen\graphics\screen\screen.jpg")
intro.Left = 8
intro.Top = 20
intro.Height = 611
PlayScreen.Left = intro.Left
PlayScreen.Width = intro.Width
PlayScreen.Top = intro.Top
End Sub
Private Sub Form_Unload(Cancel As Integer)
End
End Sub

Private Sub IdleTimer_Timer()
DrawManThenStay
End Sub

Private Sub KeyTimer_Timer()
IdleTimer.Interval = 2000
If AKey = 0 Then Exit Sub
IdleStay = False
a2 = AKey
AKey = 0
TryMove a2
IdleTimer.Interval = 100
KeyTimer.Interval = 20
End Sub

Private Sub Label_DvigatFormu_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
Call ReleaseCapture
Call SendMessage(Me.hWnd, WM_NCLBUTTONDOWN, HTCAPTION, 0&)
End Sub
Private Sub MainMenuButton_MouseUp(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
DoEvents
MainMenuButton(Index).enabled = False
loadingProgressBar.Visible = True
LoadMap
End Sub
Private Sub newgameBack_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
DoEvents
intro.Visible = True
boxNewPlayer.Visible = False
End Sub

Private Sub MainMenuClose_Click(Index As Integer)
CloseProgram
End Sub

Private Sub MinWin_Click()
Main.WindowState = 1
End Sub
Private Sub PlayScreen_KeyDown(KeyCode As Integer, Shift As Integer)
Dim vop As Boolean
tuda = GotLine(ManPosition)
vop = False
If KeyCode = 73 Then
MsgBox "GDI memory used: " & MemoryCut & " bytes (" & (MemoryCut \ 1024) & " Kb)", vbInformation, "Resurses"
End If
If KeyCode = 187 Then
PlayerSpeed = PlayerSpeed + 20
If PlayerSpeed > 100 Then PlayerSpeed = 100
Exit Sub
End If
If KeyCode = 189 Then
If PlayerSpeed < 20 Then
  PlayerSpeed = 0
Else
  PlayerSpeed = PlayerSpeed - 20
End If
Exit Sub
End If
If KeyCode = vbKeyHome Then AKey = 1
If KeyCode = vbKeyPageUp Then AKey = 2
If KeyCode = vbKeyEnd Then AKey = 3
If KeyCode = vbKeyPageDown Then AKey = 4
End Sub
Private Sub PlayScreen_KeyUp(KeyCode As Integer, Shift As Integer)
IdleStay = True
End Sub

Private Sub timer_Timer(Index As Integer)
Main.DMC.SampleChanToModify = Index
Main.DMC.PlaySample False
End Sub
Private Sub ��������1_Click()
r = 0
For i = 1 To 7
  For j = 1 To 10
BitBlt p1a.hdc, 64 * (j - 1), 64 * (i - 1), 64, 64, Gra_Player(r), 0, 0, vbSrcCopy
r = r + 1
  Next j
  r = r + 1
Next i
p1a.Refresh
End Sub
Public Sub barCreateNewBar()
Main.loadingProgressBar.Width = 0
End Sub

Public Sub barSetProgress()
barmin = barMax \ 200
Main.loadingProgressBar.Width = loadingProgressBar.Width + barmin
Main.loadingProgressBar.Refresh
End Sub

Public Sub barAbsoluteBar()
Main.loadingProgressBar.Width = barMax - 1
Main.loadingProgressBar.Refresh
End Sub
