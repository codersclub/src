VERSION 5.00
Object = "{27395F88-0C0C-101B-A3C9-08002B2F49FB}#1.1#0"; "PICCLP32.OCX"
Begin VB.Form tiles 
   Caption         =   "�����1"
   ClientHeight    =   5955
   ClientLeft      =   2535
   ClientTop       =   3000
   ClientWidth     =   8160
   LinkTopic       =   "�����1"
   ScaleHeight     =   397
   ScaleMode       =   3  '�������
   ScaleWidth      =   544
   Begin VB.PictureBox pusto 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   1005
      Left            =   1620
      Picture         =   "tiles.frx":0000
      ScaleHeight     =   67
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   10
      Top             =   1380
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox PaintPreviewMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H001001FF&
      BorderStyle     =   0  '������
      Height          =   1005
      Left            =   1500
      Picture         =   "tiles.frx":3282
      ScaleHeight     =   67
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   9
      Top             =   360
      Width           =   960
   End
   Begin PicClip.PictureClip man_mask 
      Left            =   4200
      Top             =   1380
      _ExtentX        =   6773
      _ExtentY        =   6773
      _Version        =   393216
      Rows            =   4
      Cols            =   4
      Picture         =   "tiles.frx":6504
   End
   Begin VB.PictureBox sprite3 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   480
      Left            =   180
      ScaleHeight     =   32
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   8
      Top             =   4680
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox PlayerMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   1005
      Left            =   3660
      Picture         =   "tiles.frx":36556
      ScaleHeight     =   67
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   7
      Top             =   360
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox sprite2 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   480
      Left            =   60
      ScaleHeight     =   32
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   6
      Top             =   2940
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox boxmask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   1005
      Left            =   -60
      Picture         =   "tiles.frx":397D8
      ScaleHeight     =   67
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   5
      Top             =   3660
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox wallmask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   1005
      Left            =   0
      Picture         =   "tiles.frx":3CA5A
      ScaleHeight     =   67
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   4
      Top             =   1680
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox sprite1 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   480
      Left            =   60
      ScaleHeight     =   32
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   3
      Top             =   1140
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox sprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   480
      Left            =   0
      ScaleHeight     =   32
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   2
      Top             =   540
      Visible         =   0   'False
      Width           =   960
   End
   Begin VB.PictureBox playmask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00FFFFFF&
      BorderStyle     =   0  '������
      Height          =   480
      Left            =   0
      Picture         =   "tiles.frx":3FCDC
      ScaleHeight     =   32
      ScaleMode       =   3  '�������
      ScaleWidth      =   64
      TabIndex        =   1
      Top             =   0
      Visible         =   0   'False
      Width           =   960
   End
   Begin PicClip.PictureClip walls 
      Left            =   4020
      Top             =   3960
      _ExtentX        =   8467
      _ExtentY        =   7091
      _Version        =   393216
      Rows            =   4
      Cols            =   5
   End
   Begin PicClip.PictureClip terran 
      Left            =   6300
      Top             =   1980
      _ExtentX        =   6773
      _ExtentY        =   8467
      _Version        =   393216
      Rows            =   10
      Cols            =   4
   End
   Begin VB.PictureBox fon 
      AutoRedraw      =   -1  'True
      BorderStyle     =   0  '������
      Height          =   7200
      Left            =   3600
      ScaleHeight     =   480
      ScaleMode       =   3  '�������
      ScaleWidth      =   640
      TabIndex        =   0
      Top             =   4680
      Width           =   9600
   End
   Begin PicClip.PictureClip box 
      Left            =   1740
      Top             =   3720
      _ExtentX        =   8467
      _ExtentY        =   3545
      _Version        =   393216
      Rows            =   2
      Cols            =   5
   End
   Begin PicClip.PictureClip man 
      Left            =   300
      Top             =   1380
      _ExtentX        =   6773
      _ExtentY        =   6773
      _Version        =   393216
      Rows            =   4
      Cols            =   4
      Picture         =   "tiles.frx":4151E
   End
   Begin VB.Shape colorshape 
      Height          =   195
      Left            =   6060
      Top             =   2940
      Width           =   555
   End
End
Attribute VB_Name = "tiles"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
