Attribute VB_Name = "MapModule"
Public PlayerSpeed As Byte
Public Otstup As Boolean
Public map_back As Byte
Public Map(8, 26) As String
Public Map_box(242) As String
Public Map_terran(242) As String
Public Map_wall(242) As String

Public Sub LoadMap()
DoEvents
Dim fon As Byte
back% = Val(ReadINI("MAP0", "back", SkinPath & "\maps.dat"))

Main.barSetProgress
CreateVirtualPictures
ClearMap back%
map_back = back%
LoadMapsToMemory
LoadFloorToScreen
LoadWallsToScreen
Main.DMC.StopModule
Main.DMC.OpenModule SkinPath & ReadINI("MAP0", "music", SkinPath & "\maps.dat"), True
Main.DMC.PlayModule
For i = 1 To Val(ReadINI("MAP0", "sounds", SkinPath & "\maps.dat"))
Main.DMC.SampleChanToModify = i
Call Main.DMC.OpenSample(SkinPath & ReadINI("MAP0", "sound" & i & "_file", SkinPath & "\maps.dat"))
If Val(ReadINI("MAP0", "sound" & i & "_playtime", SkinPath & "\maps.dat")) = 0 Then
Main.DMC.SampleChanToModify = i
Main.DMC.PlaySample True
Else
Main.timer(i).Interval = 1000 * Val(ReadINI("MAP0", "sound" & i & "_playtime", SkinPath & "\maps.dat"))
Main.timer(i).enabled = True
End If
Next i
Main.DMC.SampleChanToModify = 16
Call Main.DMC.OpenSample(SkinPath & ReadINI("PLAYER_SOUNDS", "crash", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 17
Call Main.DMC.OpenSample(SkinPath & ReadINI("PLAYER_SOUNDS", "move", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 18
Call Main.DMC.OpenSample(SkinPath & ReadINI("PLAYER_SOUNDS", "idle1", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 19
Call Main.DMC.OpenSample(SkinPath & ReadINI("PLAYER_SOUNDS", "idle2", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 21
Call Main.DMC.OpenSample(SkinPath & ReadINI("BOX_SOUNDS", "sound1", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 22
Call Main.DMC.OpenSample(SkinPath & ReadINI("BOX_SOUNDS", "sound2", SkinPath & "\game.dat"))
Main.DMC.SampleChanToModify = 23
Call Main.DMC.OpenSample(SkinPath & ReadINI("BOX_SOUNDS", "sound3", SkinPath & "\game.dat"))
Main.barAbsoluteBar
Main.PlayScreen.Refresh
Main.PlayScreen.Visible = True
ManSide = 1
Main.IdleTimer.enabled = True
Main.BoxTimer.enabled = True
PlayerSpeed = 20
CanPressButton = True
Main.intro.Visible = False
MsgBox "Controls:" & vbCrLf & "Change game speed: +/-" & vbCrLf & "Move: PageUp, PageDown, Home, End" & vbCrLf & vbCrLf & "Note: turn off NumLock", vbInformation, "Sokoban3D"
Main.PlayScreen.SetFocus
Main.KeyTimer.enabled = True
End Sub

Public Sub LoadMapsToMemory()
bd = 0
sa = 0
For i = 0 To 26
section_floor = ReadINI("MAP0", "floor_y" & (i), SkinPath + "\maps.dat")
section_wall = ReadINI("MAP0", "wall_y" & (i), SkinPath + "\maps.dat")
section_box = ReadINI("MAP0", "box_y" & (i), SkinPath + "\maps.dat")


     For j = 0 To 8

      tmp1 = Mid(section_floor, j + 1, 1)
      tmp2 = Mid(section_wall, j + 1, 1)
    tmp3 = Mid(section_box, j + 1, 1)
        tmp1 = ReturnTexNumber(tmp1)
      
    tmp2 = ReturnTexNumber(tmp2)
    tmp3 = ReturnTexNumber(tmp3)
    
      Map_terran(GotSector(j, i)) = tmp1
      Map_wall(GotSector(j, i)) = tmp2
      Map_box(GotSector(j, i)) = tmp3
      

        If Not tmp3 = "-" Then
            bd = bd + 1
            box(bd).Position = GotSector(j, i)
            box(bd).Present = True
            box(bd).Texture = tmp3
            
        End If
     
If tmp1 = 17 Then
    sa = sa + 1
    TargetSectors(sa) = "1"
End If
     
     If tmp2 = "*" Then ManPosition = GotSector(j, i) ' '78
     Next j
Main.barSetProgress
Next i



For i = 0 To 39
 Gra_Floor_sound(i) = Val(ReadINI("TERRAN", "tex" & i & "_box", SkinPath & "\game.dat"))
Next i



End Sub

Public Sub LoadFloorToScreen()

DoEvents

Otstup = False
Dim Sz As Byte

For i = 0 To 26
  If Otstup = False Then
    Sz = 0
    Otstup = True
  Else
    Sz = 32
    Otstup = False
  End If
    
  For j = 0 To 8

    tmp2% = i * 16
    tmp2% = tmp2% - i


    tmp1$ = Map_terran(GotSector(j, i))
     If Not tmp1$ = "-" Then
          Paint_floor (j * 64) + Sz, tmp2%, Val(tmp1$)
     End If
  Next j
  
Main.barSetProgress
222
Next i



End Sub

Public Sub LoadWallsToScreen()
DoEvents

Otstup = False
Dim Sz As Byte

For i = 0 To 26
  If Otstup = False Then
    Sz = 0
    
    Otstup = True
  Else
    
    Sz = 32
    Otstup = False
  End If
    
  For j = 0 To 8
    tmp2% = (i * 16) - 34
    tmp2% = tmp2% - i
    
    tmp1$ = Map_wall(GotSector(j, i))
     tmp3$ = Map_box(GotSector(j, i))
     
     If Not tmp3$ = "-" Then
        tiles.sprite2.Picture = tiles.box.GraphicCell(Val(tmp3$))
        Paint_box (j * 64) + Sz, tmp2%
     Else
       If tmp1$ = "*" Then
       BitBlt Gra_Man, 0, 0, 64, 67, Gra_Player(4), 0, 0, vbSrcCopy
       BitBlt Gra_Man_Mask, 0, 0, 64, 67, Gra_Player_Mask(4), 0, 0, vbSrcCopy
       ManSide = 1
       Paint_Man (j * 64) + Sz, (tmp2% + 2)
       
       GoTo 234
       End If
       If Not tmp1$ = "-" Then
       Paint_Wall (j * 64) + Sz, tmp2%, Val(tmp1$)
       End If
     End If
  
234
  Next j
  

222
Main.barSetProgress
Next i



End Sub
Public Function ReturnTexNumber(a1 As Variant) As Variant
Select Case a1
        Case "A"
          tmp1 = "10"
        Case "B"
          tmp1 = "11"
        Case "C"
          tmp1 = "12"
        Case "D"
          tmp1 = "13"
        Case "E"
          tmp1 = "14"
        Case "F"
          tmp1 = "15"
        Case "G"
          tmp1 = "16"
        Case "H"
          tmp1 = "17"
        Case "I"
          tmp1 = "18"
        Case "J"
          tmp1 = "19"
        Case "K"
          tmp1 = "20"
        Case "L"
          tmp1 = "21"
        Case "M"
          tmp1 = "22"
        Case "N"
          tmp1 = "23"
        Case "O"
          tmp1 = "24"
        Case "P"
          tmp1 = "25"
        Case "Q"
          tmp1 = "26"
        Case "R"
          tmp1 = "27"
        Case "S"
          tmp1 = "28"
        Case "T"
          tmp1 = "29"
        Case "U"
          tmp1 = "30"
        Case "V"
          tmp1 = "31"
        Case "W"
          tmp1 = "32"
        Case "X"
          tmp1 = "33"
        Case "Y"
          tmp1 = "34"
        Case "Z"
          tmp1 = "35"
        Case "@"
          tmp1 = "36"
        Case "&"
            tmp1 = "37"
        Case "%"
            tmp1 = "38"
        Case "$"
          tmp1 = "39"
        Case Else
          tmp1 = a1
End Select
ReturnTexNumber = tmp1

End Function


Public Function WhatInThisSector(sector) As Byte
If Not Map_wall(sector) = "-" Then
  If Map_wall(sector) = "*" Then
    WhatInThisSector = 1
    Exit Function
  Else
    WhatInThisSector = 3
    Exit Function
  End If
End If

If Not Map_box(sector) = "-" Then
    WhatInThisSector = 2
    Exit Function
End If

WhatInThisSector = 0


End Function

Public Function CanIgoThere(sector, side, Optional BoxMove As Boolean = False) As Boolean
If BoxMove = False Then
    Figa = GotLine(ManPosition)
Else
    Figa = GotLine(side_sector)
End If


If tmp = 3 Or tmp = 1 Or sector < 0 Or sector > 242 Then
  CanIgoThere = False
  Exit Function
Else
  CanIgoThere = True
End If

tmp = WhatInThisSector(sector)
If tmp = 3 Or tmp = 1 Then
  CanIgoThere = False
End If


If GotX(ManPosition) = 8 And side = 4 And Figa = True Then CanIgoThere = False
If GotX(ManPosition) = 8 And side = 2 And Figa = True Then CanIgoThere = False
If GotX(ManPosition) = 0 And side = 1 And Figa = False Then CanIgoThere = False
If GotX(ManPosition) = 0 And side = 3 And Figa = False Then CanIgoThere = False
If GotY(ManPosition) = 0 And side = 1 Then CanIgoThere = False
If GotY(ManPosition) = 0 And side = 2 Then CanIgoThere = False
If GotY(ManPosition) = 26 And side = 3 Then CanIgoThere = False
If GotY(ManPosition) = 26 And side = 4 Then CanIgoThere = False





End Function

Public Sub TryMove(side)

DoEvents
Dim vop As Boolean
vop = False


Figa = GotLine(ManPosition)
If Figa = True Then Sz = 32 Else Sz = 0


If Figa = True Then
  Select Case side
    Case 1
        side_sector = ManPosition - 9
        box_sector = side_sector - 10
        spr = 4
    Case 2
        side_sector = ManPosition - 8
        box_sector = side_sector - 9
        spr = 0
    Case 3
        side_sector = ManPosition + 9
        box_sector = side_sector + 8
        spr = 8
    Case 4
        side_sector = ManPosition + 10
        box_sector = side_sector + 9
        spr = 12
  End Select
Else
  Select Case side
    Case 1
        side_sector = ManPosition - 10
        box_sector = side_sector - 9
        spr = 4
    Case 2
        side_sector = ManPosition - 9
        box_sector = side_sector - 8
        spr = 0
     Case 3
        side_sector = ManPosition + 8
        box_sector = side_sector + 9
        spr = 8
     Case 4
        side_sector = ManPosition + 9
        box_sector = side_sector + 10
        spr = 12
  End Select
End If


    BitBlt Gra_Man, 0, 0, 64, 67, Gra_Player(spr), 0, 0, vbSrcCopy
    BitBlt Gra_Man_Mask, 0, 0, 64, 67, Gra_Player_Mask(spr), 0, 0, vbSrcCopy
    
If Not Map_box(side_sector) = "-" Then
    f = CanIgoThere(box_sector, side, True)
Else
    f = CanIgoThere(side_sector, side)
End If


If f = False Then
Main.DMC.SampleChanToModify = 16
Main.DMC.PlaySample False
Main.IdleTimer.Interval = 2001
ManSide = side
IdleStay = True
IdleFrame = 6
DrawManThenStay
Exit Sub
End If

If Not Map_box(side_sector) = "-" Then
MovingBox = True
Else
MovingBox = False
End If

If MovingBox = True Then
b = CanIgoThere(box_sector, side)
If b = False Or Not Map_box(box_sector) = "-" Then
Main.DMC.SampleChanToModify = 16
Main.DMC.PlaySample False
Main.IdleTimer.Interval = 2001
ManSide = side
IdleStay = True
IdleFrame = 6
DrawManThenStay
Exit Sub
End If

End If


f = GotLine(side_sector)
If f = True Then bz = 32 Else bz = 0
b = GotLine(box_sector)
If b = True Then rz = 32 Else rz = 0

CanPressButton = False

 
Temp_XP = (GotX(ManPosition) * 64) + Sz
Temp_YP = ((GotY(ManPosition) * 16) - GotY(ManPosition)) - 29
Temp_XS = (GotX(side_sector) * 64) + bz
Temp_YS = ((GotY(side_sector) * 16) - GotY(side_sector)) - 29


Main.DMC.SampleChanToModify = 17
Main.DMC.PlaySample False


If Map_box(side_sector) = "-" Then

    For i = 0 To 8

    If side = 1 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 1, (i * 4), (i * 2) '- tmp2p
    If side = 2 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 2, (i * 4), (i * 2)
    If side = 3 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 3, (i * 4), (i * 2), True
    If side = 4 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 4, (i * 4), (i * 2), True


      
      BitBlt Main.PlayScreen.hdc, Temp_XP, Temp_YP, 64, 67, preview_mask, 0, 0, vbSrcAnd
      BitBlt Main.PlayScreen.hdc, Temp_XP, Temp_YP, 64, 67, Preview, 0, 0, vbSrcPaint

  If side = 1 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 1, (i * 4), (i * 2)         '+ tmp2s
  If side = 2 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 2, (i * 4), (i * 2)
  If side = 3 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 3, (i * 4), (i * 2), True
  If side = 4 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 4, (i * 4), (i * 2), True
      BitBlt Main.PlayScreen.hdc, Temp_XS, Temp_YS, 64, 67, preview_mask, 0, 0, vbSrcAnd
      BitBlt Main.PlayScreen.hdc, Temp_XS, Temp_YS, 64, 67, Preview, 0, 0, vbSrcPaint

    Main.PlayScreen.Refresh
  Sleep PlayerSpeed
  Next i

    Map_wall(ManPosition) = "-"
    Map_wall(side_sector) = "*"
    ManPosition = side_sector
    ManSide = side
Main.DMC.StopSample


Else
Temp_YB = ((GotY(box_sector) * 16) - GotY(box_sector)) - 29
Temp_XB = (GotX(box_sector) * 64) + Sz


MovingBox = True




For i = 0 To 20
If side_sector = box(i).Position Then GoTo 898
Next i
If i = 21 Then i = 0
898
MovingBoxTex = i


Map_box(side_sector) = "-"


Main.DMC.SampleChanToModify = 20 + Gra_Floor_sound(Map_terran(side_sector))
Main.DMC.PlaySample False


    For i = 0 To 8

    If side = 1 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 1, (i * 4), (i * 2) '- tmp2p
    If side = 2 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 2, (i * 4), (i * 2)
    If side = 3 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 3, (i * 4), (i * 2), True
    If side = 4 Then PaintPlayerZoneToPreviewBox True, True, True, True, ManPosition, 4, (i * 4), (i * 2), True


      
      BitBlt Main.PlayScreen.hdc, Temp_XP, Temp_YP, 64, 67, preview_mask, 0, 0, vbSrcAnd
      BitBlt Main.PlayScreen.hdc, Temp_XP, Temp_YP, 64, 67, Preview, 0, 0, vbSrcPaint
      

  If side = 1 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 1, (i * 4), (i * 2)         '+ tmp2s
  If side = 2 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 2, (i * 4), (i * 2)
  If side = 3 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 3, (i * 4), (i * 2), True
  If side = 4 Then PaintPlayerZoneToPreviewBox True, True, True, True, side_sector, 4, (i * 4), (i * 2), True
      BitBlt Main.PlayScreen.hdc, Temp_XS, Temp_YS, 64, 67, preview_mask, 0, 0, vbSrcAnd
      BitBlt Main.PlayScreen.hdc, Temp_XS, Temp_YS, 64, 67, Preview, 0, 0, vbSrcPaint
    
  If side = 1 Then PaintPlayerZoneToPreviewBox True, True, True, True, box_sector, 1, (i * 4), (i * 2)         '+ tmp2s
  If side = 2 Then PaintPlayerZoneToPreviewBox True, True, True, True, box_sector, 2, (i * 4), (i * 2)
  If side = 3 Then PaintPlayerZoneToPreviewBox True, True, True, True, box_sector, 3, (i * 4), (i * 2), True
  If side = 4 Then PaintPlayerZoneToPreviewBox True, True, True, True, box_sector, 4, (i * 4), (i * 2), True
      BitBlt Main.PlayScreen.hdc, Temp_XB, Temp_YB, 64, 67, preview_mask, 0, 0, vbSrcAnd
      BitBlt Main.PlayScreen.hdc, Temp_XB, Temp_YB, 64, 67, Preview, 0, 0, vbSrcPaint
    
    
    Main.PlayScreen.Refresh
  Sleep PlayerSpeed
  Next i


    Map_wall(ManPosition) = "-"
    Map_wall(side_sector) = "*"
    ManPosition = side_sector
    ManSide = side
  
    Map_box(box_sector) = box(MovingBoxTex).Texture
    box(MovingBoxTex).Position = box_sector

Main.DMC.SampleChanToModify = 17
Main.DMC.StopSample

End If










IdleFrame = 6
Main.KeyTimer.Interval = 1




MovingBox = False

CheckForWin

End Sub


Public Sub CreateVirtualPictures()
    
    On Local Error Resume Next
    
    Dim FileNo As Integer
    Dim ScreenDC As Long
    Dim PicBytes() As Byte
    Dim RetVal As Long
    Dim i As Long, j As Long, PicOffset As Long, PicLen As Long
    Dim PicPalette As Long


    ScreenDC = GetDC(0)
    
    picWidth = 64
    picHeight = 32


For i = 0 To 39
    Main.barSetProgress
    MemoryCut = MemoryCut + 12918
    Gra_Floor(i) = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, picWidth, picHeight)
    PicPrevBmp = SelectObject(Gra_Floor(i), PicBmp)
    PicPalette = SelectPalette(Gra_Floor(i), hPal, True)
    RealizePalette Gra_Floor(i)

    tiles.sprite.Picture = tiles.terran.GraphicCell(i)

    BitBlt Gra_Floor(i), 0, 0, picWidth, picHeight, tiles.sprite.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette

Next i


    MemoryCut = MemoryCut + 12918
    Gra_Floor_Mask = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, picWidth, picHeight)
    PicPrevBmp = SelectObject(Gra_Floor_Mask, PicBmp)
    PicPalette = SelectPalette(Gra_Floor_Mask, hPal, True)
    RealizePalette Gra_Floor_Mask
    BitBlt Gra_Floor_Mask, 0, 0, picWidth, picHeight, tiles.playmask.hdc, 0, 0, vbSrcCopy
    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


For i = 0 To 19
    Main.barSetProgress
    MemoryCut = MemoryCut + 12918
    Gra_Walls(i) = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(Gra_Walls(i), PicBmp)
    PicPalette = SelectPalette(Gra_Walls(i), hPal, True)
    RealizePalette Gra_Walls(i)

    tiles.sprite1.Picture = tiles.walls.GraphicCell(i)

    BitBlt Gra_Walls(i), 0, 0, 64, 67, tiles.sprite1.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette

Next i



    MemoryCut = MemoryCut + 12918
    Gra_Walls_Mask = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(Gra_Walls_Mask, PicBmp)
    PicPalette = SelectPalette(Gra_Walls_Mask, hPal, True)
    RealizePalette Gra_Walls_Mask
    BitBlt Gra_Walls_Mask, 0, 0, 64, 67, tiles.wallmask.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


    MemoryCut = MemoryCut + 12918
    Preview = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(Preview, PicBmp)
    PicPalette = SelectPalette(Preview, hPal, True)
    RealizePalette Preview
    
    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


    MemoryCut = MemoryCut + 12918
    preview_mask = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(preview_mask, PicBmp)
    PicPalette = SelectPalette(preview_mask, hPal, True)
    RealizePalette preview_mask
    BitBlt preview_mask, 0, 0, 64, 67, tiles.PaintPreviewMask.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


    MemoryCut = MemoryCut + 12342
    Gra_Man = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 64)
    PicPrevBmp = SelectObject(Gra_Man, PicBmp)
    PicPalette = SelectPalette(Gra_Man, hPal, True)
    RealizePalette Gra_Man
    
    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette
    
    Gra_Man_Mask = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 64)
    PicPrevBmp = SelectObject(Gra_Man_Mask, PicBmp)
    PicPalette = SelectPalette(Gra_Man_Mask, hPal, True)
    RealizePalette Gra_Man_Mask

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


For i = 0 To 15
    Main.barSetProgress
    MemoryCut = MemoryCut + 12342
    tiles.sprite3.Picture = tiles.man.GraphicCell(i)
    Gra_Player(i) = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 64)
    PicPrevBmp = SelectObject(Gra_Player(i), PicBmp)
    PicPalette = SelectPalette(Gra_Player(i), hPal, True)
    RealizePalette Gra_Player(i)
    BitBlt Gra_Player(i), 0, 0, 64, 64, tiles.sprite3.hdc, 0, 0, vbSrcCopy
    
    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette
   
    
    tiles.sprite3.Picture = tiles.man_mask.GraphicCell(i)
    Gra_Player_Mask(i) = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 64)
    PicPrevBmp = SelectObject(Gra_Player_Mask(i), PicBmp)
    PicPalette = SelectPalette(Gra_Player_Mask(i), hPal, True)
    RealizePalette Gra_Player_Mask(i)
    BitBlt Gra_Player_Mask(i), 0, 0, 64, 64, tiles.sprite3.hdc, 0, 0, vbSrcCopy
    
    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette
    
Next i



For i = 0 To 9
    Main.barSetProgress
    MemoryCut = MemoryCut + 12918
    Gra_Box(i) = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(Gra_Box(i), PicBmp)
    PicPalette = SelectPalette(Gra_Box(i), hPal, True)
    RealizePalette Gra_Box(i)

    tiles.sprite1.Picture = tiles.box.GraphicCell(i)

    BitBlt Gra_Box(i), 0, 0, 64, 67, tiles.sprite1.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette
Next i



    MemoryCut = MemoryCut + 12918
    Gra_Box_Mask = CreateCompatibleDC(ScreenDC)
    PicBmp = CreateCompatibleBitmap(ScreenDC, 64, 67)
    PicPrevBmp = SelectObject(Gra_Box_Mask, PicBmp)
    PicPalette = SelectPalette(Gra_Box_Mask, hPal, True)
    RealizePalette Gra_Box_Mask
    BitBlt Gra_Box_Mask, 0, 0, 64, 67, tiles.boxmask.hdc, 0, 0, vbSrcCopy

    DeleteObject PicBmp
    DeleteDC PicBmp
    DeleteObject PicPrevBmp
    DeleteDC PicPrevBmp
    DeleteObject PicPalette
    DeleteDC PicPalette


End Sub

Public Sub CheckForWin()
parkovka = 0
boxes = 0


    For j = 0 To 242
       If Map_terran(j) = "17" Then
        parkovka = parkovka + 1
        If Not Map_box(j) = "-" Then boxes = boxes + 1
       End If
    Next j

If boxes = parkovka Then
    Main.DMC.StopModule
    MsgBox "You WIN!!!", vbInformation, "Sokoban3D"
    CloseProgram
End If


End Sub
