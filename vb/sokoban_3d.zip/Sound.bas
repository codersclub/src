Attribute VB_Name = "Sound"
Public Sub PlayMenuClickSound()

tmp = CInt(Rnd * 1) + 1
Main.DMC.SampleChanToModify = 30 + tmp
Main.DMC.PlaySample False


End Sub
