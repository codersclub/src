Attribute VB_Name = "Graphics"
Public Gra_Walls(19) As Long
Public Gra_Floor(39) As Long
Public Gra_Floor_sound(39) As Long
Public Gra_Box(9) As Long
Public Preview As Long
Public preview_mask As Long
Public Gra_Man As Long
Public Gra_Man_Mask As Long
Public Gra_Player(15) As Long
Public Gra_Player_Mask(15) As Long
Public Gra_Box_Mask As Long
Public Gra_Walls_Mask As Long
Public Gra_Floor_Mask As Long
Public IdlePlayer(1) As Long
Public Declare Function RealizePalette Lib "gdi32" (ByVal hdc As Long) As Long
Public Declare Function GetDC Lib "user32" (ByVal hWnd As Long) As Long
Public Declare Function ReleaseDC Lib "user32" (ByVal hWnd As Long, ByVal hdc As Long) As Long
Public Declare Function DeleteDC Lib "gdi32" (ByVal hdc As Long) As Long
Public Declare Function CreateCompatibleDC Lib "gdi32" (ByVal hdc As Long) As Long
Public Declare Function CreateCompatibleBitmap Lib "gdi32" (ByVal hdc As Long, _
  ByVal nWidth As Long, ByVal nHeight As Long) As Long
Public Declare Function SelectObject Lib "gdi32" (ByVal hdc As Long, _
  ByVal hObject As Long) As Long
Public Declare Function DeleteObject Lib "gdi32" (ByVal hObject As Long) As Long
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, _
  ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, _
  ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, _
  ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function CreateBitmap Lib "gdi32" (ByVal nWidth As Long, ByVal nHeight As Long, ByVal nPlanes As Long, ByVal nBitCount As Long, lpBits As Any) As Long
Public Declare Function SetBkColor Lib "gdi32" (ByVal hdc As Long, ByVal crColor As Long) As Long
Public Declare Function timeGetTime Lib "winmm.dll" () As Long
Public Declare Function SelectPalette Lib "gdi32" (ByVal hdc As Long, ByVal hPalette As Long, ByVal bForceBackground As Long) As Long
Public Sub Paint_Wall_to_preview(X, Y, sprite1)
    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Walls_Mask, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Walls(sprite1), 0, 0, vbSrcPaint)
End Sub

Public Sub Paint_Wall(X As Integer, Y As Integer, sprite1)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            Gra_Walls_Mask, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            Gra_Walls(sprite1), 0, 0, vbSrcPaint)
End Sub
Public Sub Paint_Man_to_preview(X, Y)
    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Man_Mask, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Man, 0, 0, vbSrcPaint)
End Sub


Public Sub ClearMap(tex1 As Integer)
Otstup = True
Dim Sz As Byte
For i = -1 To 29
  If Otstup = False Then
    Sz = 0
    Otstup = True
  Else
    Sz = 32
    Otstup = False
  End If
  For j = -1 To 9
    tmp2% = i * 16
    tmp2% = tmp2% - i
          Paint_floor (j * 64) + Sz, tmp2%, tex1
  Next j
Main.barSetProgress
221
Next i
End Sub

Public Sub Paint_floor(X As Integer, Y As Integer, sprite1 As Integer)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 32, _
            Gra_Floor_Mask, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 32, _
            Gra_Floor(sprite1), 0, 0, vbSrcPaint)
End Sub
Public Sub Paint_box(X As Integer, Y As Integer)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            tiles.boxmask.hdc, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            tiles.sprite2.hdc, 0, 0, vbSrcPaint)
End Sub

Public Sub Paint_Man(X As Integer, Y As Integer)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            Gra_Man_Mask, 0, 0, vbSrcAnd)
    lRtn = BitBlt(Main.PlayScreen.hdc, X, Y, 64, 67, _
            Gra_Man, 0, 0, vbSrcPaint)
End Sub
Public Sub PaintPlayerZoneToPreviewBox(floor As Boolean, man As Boolean, box As Boolean, wall1 As Boolean, sector, Optional Moving As Byte = 0, Optional MovingX As Integer = 0, Optional MovingY As Integer = 0, Optional FirstSector As Boolean = False)
Dim Figa As Boolean
If GotLine(sector) = True Then Figa = True
If Figa = True Then
s1 = 1
    b1 = 0
s2 = 1
    b2 = 0
s4 = 1
    b4 = 2
s5 = 0
    b5 = 1
s7 = 1
    b7 = 0
s8 = 0
    b8 = 1
Else
s1 = 0
    b1 = 1
s2 = 0
    b2 = 1
s4 = 2
    b4 = 1
s5 = 1
    b5 = 0
s7 = 0
    b7 = 1
s8 = 1
    b8 = 2
End If

If GotY(sector) < 3 Or GotX(sector) = 0 And Figa = False Or sector < 27 And Figa = True Or sector < 28 And Figa = False Then
Paint_floor_to_preview -32, -16, map_back
Else
If Not Moving = 0 Then
  If Moving = 3 Or Moving = 4 Then
    WritePoligonInPreview Map_terran(sector - 28 + s1), Map_wall(sector - 28 + s1), Map_box(sector - 28 + s1), -32, -16, sector, False, box, wall1, floor
  Else
             WritePoligonInPreview Map_terran(sector - 28 + s1), Map_wall(sector - 28 + s1), Map_box(sector - 28 + s1), -32, -16, sector, True, box, wall1, floor, Moving, MovingX, MovingY
  End If
Else
  WritePoligonInPreview Map_terran(sector - 28 + s1), Map_wall(sector - 28 + s1), Map_box(sector - 28 + s1), -32, -16, sector, man, box, wall1, floor
End If


End If



If GotY(sector) < 3 Or GotX(sector) = 8 And Figa = True Or sector < 27 And Figa = True Or sector < 26 And Figa = True Then
Paint_floor_to_preview 32, -16, map_back
Else
If Not Moving = 0 Then
  If Moving = 3 Or Moving = 4 Then
  WritePoligonInPreview Map_terran(sector - 27 + s2), Map_wall(sector - 27 + s2), Map_box(sector - 27 + s2), 32, -16, sector, False, box, wall1, floor
  Else
         WritePoligonInPreview Map_terran(sector - 27 + s2), Map_wall(sector - 27 + s2), Map_box(sector - 27 + s2), 32, -16, sector, True, box, wall1, floor, Moving, MovingX, MovingY
    End If
Else
  WritePoligonInPreview Map_terran(sector - 27 + s2), Map_wall(sector - 27 + s2), Map_box(sector - 27 + s2), 32, -16, sector, man, box, wall1, floor
End If
End If

If sector < 18 Then
Paint_floor_to_preview 0, -1, map_back
Else

If Not Moving = 0 Then
  If Moving = 3 Or Moving = 4 Then
  WritePoligonInPreview Map_terran(sector - 18), Map_wall(sector - 18), Map_box(sector - 18), 0, -1, sector, False, box, wall1, floor
  Else
 WritePoligonInPreview Map_terran(sector - 18), Map_wall(sector - 18), Map_box(sector - 18), 0, -1, sector, True, box, wall1, floor, Moving, MovingX, MovingY
  End If
Else
  WritePoligonInPreview Map_terran(sector - 18), Map_wall(sector - 18), Map_box(sector - 18), 0, -1, sector, man, box, wall1, floor
End If

End If






If GotY(sector) < 1 Or GotX(sector) = 0 And Figa = False Or sector < 9 And Figa = True Or sector < 10 And Figa = False Then
Paint_floor_to_preview -32, 14, map_back
Else

If Not Moving = 0 Then
    If Moving = 3 Or Moving = 4 Then
      WritePoligonInPreview Map_terran(sector - 8 - s4), Map_wall(sector - 8 - s4), Map_box(sector - 8 - s4), -32, 14, sector, False, box, wall1, floor
    Else
 WritePoligonInPreview Map_terran(sector - 8 - s4), Map_wall(sector - 8 - s4), Map_box(sector - 8 - s4), -32, 14, sector, True, box, wall1, floor, Moving, MovingX, MovingY
    End If
Else
    WritePoligonInPreview Map_terran(sector - 8 - s4), Map_wall(sector - 8 - s4), Map_box(sector - 8 - s4), -32, 14, sector, man, box, wall1, floor
End If
End If


If GotY(sector) < 1 Or GotX(sector) = 8 And Figa = True Or sector < 8 And Figa = True Or sector < 9 And Figa = False Then
Paint_floor_to_preview 32, 14, map_back
Else
  
If Not Moving = 0 Then
   If Moving = 3 Or Moving = 4 Then
    WritePoligonInPreview Map_terran(sector - 8 - s5), Map_wall(sector - 8 - s5), Map_box(sector - 8 - s5), 32, 14, sector, False, box, wall1, floor
    Else



            WritePoligonInPreview Map_terran(sector - 8 - s5), Map_wall(sector - 8 - s5), Map_box(sector - 8 - s5), 32, 14, sector, True, box, wall1, floor, Moving, MovingX, MovingY


   End If
  Else
    WritePoligonInPreview Map_terran(sector - 8 - s5), Map_wall(sector - 8 - s5), Map_box(sector - 8 - s5), 32, 14, sector, man, box, wall1, floor
  End If


End If





  If Not Moving = 0 Then
    If Moving = 3 Or Moving = 4 Then
      WritePoligonInPreview Map_terran(sector), Map_wall(sector), Map_box(sector), 0, 29, sector, False, box, wall1, floor
    Else



            WritePoligonInPreview Map_terran(sector), Map_wall(sector), Map_box(sector), 0, 29, sector, True, box, wall1, floor, Moving, MovingX, MovingY


    End If
  Else
    WritePoligonInPreview Map_terran(sector), Map_wall(sector), Map_box(sector), 0, 29, sector, man, box, wall1, floor
  End If



If Moving = 3 Or Moving = 4 Then
  

   
If Not sector = box_sector Then
   If ManPosition = (sector - 28 + s1) Then
     nmx = -32
     nmy = 16
   End If
   If ManPosition = (sector - 27 + s2) Then
     nmx = 32
     nmy = 16
   End If
   If ManPosition = sector - 18 Then
     nmx = 0
     nmy = -1
   End If
   If ManPosition = sector - 8 - s4 Then
     nmx = -32
     nmy = 14
   End If
   If ManPosition = sector - 8 - s5 Then
     nmx = 32
     nmy = 14
   End If
   If ManPosition = sector Then
     nmx = 0
     nmy = 29
   End If
   
  WritePoligonInPreview Map_terran(ManPosition), Map_wall(ManPosition), Map_box(ManPosition), nmx, nmy, ManPosition, man, box, wall1, floor, Moving, MovingX, MovingY
Else

   If ManPosition = (sector - 36 + s1 + b1) Then
     nmx = -64
     nmy = 1
   End If
   If ManPosition = (sector - 35 + s2 + b2) Then
     nmx = 64
     nmy = 1
   End If
   If ManPosition = sector - 26 Then
     nmx = 32
     nmy = -16
   End If
   If ManPosition = sector - 16 - s4 - b4 Then
     nmx = -64
     nmy = -1
   End If
   If ManPosition = sector - 16 - s5 - b5 Then
     nmx = 64
     nmy = -1
   End If
   If ManPosition = sector Then
     nmx = 32
     nmy = 14
   End If

  WritePoligonInPreview Map_terran(ManPosition), Map_wall(ManPosition), Map_box(ManPosition), nmx, nmy, ManPosition, True, box, wall1, floor, Moving, MovingX, MovingY
End If
End If



If GotY(sector) = 26 Or GotX(sector) = 0 And Figa = False Or sector > 233 And Figa = True Or sector > 234 And Figa = False Then
Paint_floor_to_preview -32, 44, map_back
Else

  If Not Moving = 0 Then
    If Moving = 3 Or Moving = 4 Then
WritePoligonInPreview Map_terran(sector + 8 + s7), Map_wall(sector + 8 + s7), Map_box(sector + 8 + s7), -32, 44, sector, False, box, wall1, floor
    Else

        If Not sector = box_sector Then
    WritePoligonInPreview Map_terran(sector + 8 + s7), Map_wall(sector + 8 + s7), Map_box(sector + 8 + s7), -32, 44, sector, True, True, wall1, floor, Moving, MovingX, MovingY
    Else
        If Moving = 1 Or Moving = 2 Then
          WritePoligonInPreview Map_terran(sector + 8 + s7), Map_wall(sector + 8 + s7), Map_box(sector + 8 + s7), -32, 44, sector, False, False, False, True
          WritePoligonInPreview Map_terran(sector + 16 + s7 + b7), Map_wall(sector + 16 + s7 + b7), Map_box(sector + 16 + s7 + b7), -64, 59, box_sector, True, box, wall1, True, Moving, MovingX, MovingY
          
        End If
End If

    End If
  Else
    WritePoligonInPreview Map_terran(sector + 8 + s7), Map_wall(sector + 8 + s7), Map_box(sector + 8 + s7), -32, 44, sector, man, box, wall1, floor
  End If

End If



If GotY(sector) = 26 Or GotX(sector) = 8 And Figa = True Or sector > 232 And Figa = True Or sector > 233 And Figa = True Then
        Paint_floor_to_preview 32, 44, map_back
Else


            If Not Moving = 0 Then
                        If Moving = 3 Or Moving = 4 Then
                                WritePoligonInPreview Map_terran(sector + 10 - s8), Map_wall(sector + 10 - s8), Map_box(sector + 10 - s8), 32, 44, sector, False, box, wall1, floor
                        Else
                                If Moving = 1 Then
                                        
                                        
                                        If sector = box_sector Then
                                                WritePoligonInPreview Map_terran(sector + 10 - s8), Map_wall(sector + 10 - s8), Map_box(sector + 10 - s8), 32, 44, sector, False, False, False, True
                                                WritePoligonInPreview Map_terran(sector + 18 - s8 + b8), Map_wall(sector + 18 - s8 + b8), Map_box(sector + 18 - s8 + b8), 64, 59, box_sector, True, box, wall1, True, Moving, MovingX, MovingY
                                        Else
                                                WritePoligonInPreview Map_terran(sector + 10 - s8), Map_wall(sector + 10 - s8), Map_box(sector + 10 - s8), 32, 44, sector, True, box, wall1, floor, Moving, MovingX, MovingY
                                        End If
                                                    
                                                    
                                                    If GotY(sector) = 26 Or GotX(sector) = 0 And Figa = False Or sector > 233 And Figa = True Or sector > 234 And Figa = False Then
                                                    Else
                                                            WritePoligonInPreview Map_terran(sector + 8 + s7), Map_wall(sector + 8 + s7), Map_box(sector + 8 + s7), -32, 44, sector, man, box, wall1, floor
                                                    End If

                                Else
                                        WritePoligonInPreview Map_terran(sector + 10 - s8), Map_wall(sector + 10 - s8), Map_box(sector + 10 - s8), 32, 44, sector, True, box, wall1, floor, Moving, MovingX, MovingY
                                End If
                        End If
  
              Else
                        WritePoligonInPreview Map_terran(sector + 10 - s8), Map_wall(sector + 10 - s8), Map_box(sector + 10 - s8), 32, 44, sector, man, box, wall1, floor
              End If
  
End If










If sector > 224 Then
Paint_floor_to_preview 0, 59, map_back
Else

If Not Moving = 0 Then
  WritePoligonInPreview Map_terran(sector + 18), Map_wall(sector + 18), Map_box(sector + 18), 0, 59, sector, False, box, wall1, floor, ManSprite
Else
  WritePoligonInPreview Map_terran(sector + 18), Map_wall(sector + 18), Map_box(sector + 18), 0, 59, sector, man, box, wall1, floor, ManSprite
End If


End If


If Figa = True Then s1 = 1 Else s1 = 2
If GotY(sector) = 26 Or GotX(sector) = 0 And Figa = False Or sector > 213 And Figa = True Or sector > 214 And Figa = False Then

Paint_floor_to_preview -32, 74, map_back
Else

If Not Moving = 0 Then
   WritePoligonInPreview Map_terran(sector + 28 - s1), Map_wall(sector + 28 - s1), Map_box(sector + 28 - s1), -32, 74, sector, False, box, wall1, floor
Else
   WritePoligonInPreview Map_terran(sector + 28 - s1), Map_wall(sector + 28 - s1), Map_box(sector + 28 - s1), -32, 74, sector, man, box, wall1, floor
End If

End If




If Figa = True Then s1 = 28 Else s1 = 27
If GotY(sector) = 26 Or GotX(sector) = 8 And Figa = True Or sector > 213 And Figa = True Or sector > 214 And Figa = False Then
Paint_floor_to_preview 32, 74, map_back
Else


If Not Moving = 0 Then
   WritePoligonInPreview Map_terran(sector + s1), Map_wall(sector + s1), Map_box(sector + s1), 32, 74, sector, False, box, wall1, floor
Else
   WritePoligonInPreview Map_terran(sector + s1), Map_wall(sector + s1), Map_box(sector + s1), 32, 74, sector, man, box, wall1, floor
End If

End If


If sector > 206 Then
tiles.sprite.Picture = tiles.terran.GraphicCell(map_back)
Paint_floor_to_preview 0, 89, map_back
Else


If Not Moving = 0 Then
   WritePoligonInPreview Map_terran(sector + 36), Map_wall(sector + 36), Map_box(sector + 36), 0, 89, sector, False, box, wall1, floor
Else
   WritePoligonInPreview Map_terran(sector + 36), Map_wall(sector + 36), Map_box(sector + 36), 0, 89, sector, man, box, wall1, floor
End If

End If

End Sub

Public Sub Paint_floor_to_preview(X, Y, sprite1)

    lRtn = BitBlt(Preview, X, Y, 64, 32, _
            Gra_Floor_Mask, 0, 0, vbSrcAnd)

    lRtn = BitBlt(Preview, X, Y, 64, 32, _
            Gra_Floor(sprite1), 0, 0, vbSrcPaint)

End Sub

Public Sub Paint_box_to_preview(X, Y, sprite1)
    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Box_Mask, 0, 0, vbSrcAnd)

    lRtn = BitBlt(Preview, X, Y, 64, 67, _
            Gra_Box(sprite1), 0, 0, vbSrcPaint)
End Sub
Public Sub WritePoligonInPreview(tmp_terran, tmp_wall, tmp_box, Xpos, Ypos, sector, man As Boolean, box As Boolean, wall1 As Boolean, floor As Boolean, Optional Moving = 0, Optional MovingX As Integer = 0, Optional MovingY As Integer = 0, Optional WallShow As Boolean = False)
Dim manpaint As Boolean

If Not tmp_wall = "-" And wall1 = True Then
  If Not tmp_wall = "*" Then

      If WallShow = False Then Paint_Wall_to_preview Xpos, Ypos - 34, tmp_wall
      
  Else
    If floor = True Then
      
      Paint_floor_to_preview Xpos, Ypos, tmp_terran
    End If
    If man = True Then
      If Moving = 0 Then
          If ManSide = 1 Then Xen2 = 35
          If ManSide = 2 Then Xen2 = 35
          If ManSide = 3 Then Xen2 = 33
          If ManSide = 4 Then Xen2 = 33
        Paint_Man_to_preview Xpos, Ypos - Xen2
      Else
        
        If Moving = 1 Then
        
        If MovingBox = True And box = True Then Paint_box_to_preview ((Xpos) - MovingX) - 32, ((Ypos - 34) - MovingY) - 14, Declares.box(MovingBoxTex).Texture
        Paint_Man_to_preview (Xpos) - MovingX, (Ypos - 34) - MovingY
        End If
        
        If Moving = 2 Then
        If MovingBox = True And box = True Then Paint_box_to_preview ((Xpos) + MovingX) + 32, ((Ypos - 34) - MovingY) - 14, Declares.box(MovingBoxTex).Texture
        Paint_Man_to_preview (Xpos) + MovingX, (Ypos - 34) - MovingY
        End If
        
        If Moving = 3 Then
        Paint_Man_to_preview (Xpos) - MovingX, (Ypos - 34) + MovingY
        If MovingBox = True And box = True Then Paint_box_to_preview ((Xpos) - MovingX) - 32, ((Ypos - 34) + MovingY) + 14, Declares.box(MovingBoxTex).Texture
        End If
         
        If Moving = 4 Then
        Paint_Man_to_preview (Xpos) + MovingX, (Ypos - 34) + MovingY
        If MovingBox = True And box = True Then Paint_box_to_preview ((Xpos) + MovingX) + 32, ((Ypos - 34) + MovingY) + 14, Declares.box(MovingBoxTex).Texture
        End If
        
      
      End If
    End If
    
  End If
Else
  If Not tmp_box = "-" Then
    If box = True Then

    Paint_box_to_preview Xpos, Ypos - 34, tmp_box
    
    
    Else
      If floor = True Then
      
      Paint_floor_to_preview Xpos, Ypos, tmp_terran
      End If
    End If
    
  Else
    If floor = True Then
    
    Paint_floor_to_preview Xpos, Ypos, tmp_terran
    End If
    
  End If
End If







End Sub


Public Sub RedrawPlayerPosition(sector)
PaintPlayerZoneToPreviewBox True, True, True, True, sector

If GotLine(sector) = True Then Sz = 32 Else Sz = 0



    lRtn = BitBlt(Main.PlayScreen.hdc, ((GotX(ManPosition) * 64)) + Sz, ((GotY(ManPosition) * 16) - GotY(ManPosition)) - 29, 64, 67, preview_mask, 0, 0, vbSrcAnd)
    

    lRtn = BitBlt(Main.PlayScreen.hdc, ((GotX(ManPosition) * 64)) + Sz, ((GotY(ManPosition) * 16) - GotY(ManPosition)) - 29, 64, 67, Preview, 0, 0, vbSrcPaint)
    

Main.PlayScreen.Refresh

End Sub


Public Sub DrawManThenStay()
If IdleStay = False Then Exit Sub

If Main.IdleTimer.Interval = 2000 Then Main.IdleTimer.Interval = 100

Select Case ManSide
    Case 1
        spr = 4
        chn = 18
    Case 2
        spr = 0
        chn = 19
    Case 3
        spr = 8
        chn = 19
    Case 4
        spr = 12
        chn = 18
End Select

Select Case IdleFrame
Case 0
    cadr = 0
    IdleFrame = 1
    Main.IdleTimer.Interval = 100
    Main.DMC.SampleChanToModify = chn
    Main.DMC.PlaySample False
    GoTo 7777
Case 1
    cadr = 1
    IdleFrame = 2
    GoTo 7777
Case 2
    cadr = 2
    IdleFrame = 3
    GoTo 7777
Case 3
    cadr = 3
    IdleFrame = 4
    GoTo 7777
Case 4
    cadr = 2
    IdleFrame = 5
    GoTo 7777
Case 5
    cadr = 1
    IdleFrame = 6
    GoTo 7777
Case 6
    cadr = 0
    IdleFrame = 0
Main.IdleTimer.Interval = 4900
    GoTo 7777
End Select

7777
               
               BitBlt Gra_Man, 0, 0, 64, 64, Gra_Player(spr + cadr), 0, 0, vbSrcCopy
               BitBlt Gra_Man_Mask, 0, 0, 64, 64, Gra_Player_Mask(spr + cadr), 0, 0, vbSrcCopy


RedrawPlayerPosition ManPosition


End Sub
