Attribute VB_Name = "SimpleSubs"
Public Sub CenterForm(X As Form)

X.Left = (Screen.Width - X.Width) \ 2
X.Top = (Screen.Height - X.Height) \ 2

End Sub

Function WriteINI(sSection As String, sKeyName As String, sNewString As String, sINIFileName As String) As Boolean

On Local Error Resume Next

Call WritePrivateProfileString(sSection, sKeyName, sNewString, sINIFileName)

WriteINI = (Err.Number = 0)

End Function

Function ReadINI(sSection As String, sKeyName As String, sINIFileName As String) As String

On Local Error Resume Next

Dim sRet As String

sRet = String(255, Chr(0))


ReadINI = Left(sRet, GetPrivateProfileString(sSection, ByVal sKeyName, "", sRet, Len(sRet), sINIFileName))

End Function


Public Function GotSector(X, Y) As Byte


GotSector = (X + (9 * Y))

End Function

Public Function GotY(sector) As Byte

 If sector < 9 Then
   GotY = 0
   Exit Function
 End If
 
 If sector > (242 - 9) Then
   GotY = 26
   Exit Function
 End If
 
 GotY = sector \ 9
 
End Function

Public Function GotX(sector) As Byte


GotX = (sector - (GotY(sector) * 9))


End Function


Public Function GotLine(sector) As Boolean

r = GotY(sector)
If r = 0 Or r = 2 Or r = 4 Or r = 6 Or r = 8 Or r = 10 Or r = 12 Or r = 14 Or r = 16 Or r = 18 Or r = 20 Or r = 22 Or r = 24 Or r = 26 Then
GotLine = False
Else
GotLine = True
End If
End Function




Public Sub CloseProgram()
   DoEvents
   Main.DMC.StopModule





For i = 0 To 39
DeleteObject Gra_Floor(i)
DeleteDC Gra_Floor(i)
Next i
For i = 0 To 19
DeleteObject Gra_Walls(i)
DeleteDC Gra_Walls(i)
Next i
DeleteObject Gra_Floor_Mask
DeleteDC Gra_Floor_Mask
DeleteObject Gra_Walls_Mask
DeleteDC Gra_Walls_Mask
DeleteObject Gra_Man
DeleteDC Gra_Man
DeleteObject Gra_Man_Mask
DeleteDC Gra_Man_Mask

For i = 0 To 15
DeleteObject Gra_Player(i)
DeleteDC Gra_Player(i)
DeleteObject Gra_Player_Mask(i)
DeleteDC Gra_Player_Mask(i)
Next i
   
   
End


End Sub
