Attribute VB_Name = "Declares"
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal X As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function SendMessage Lib "user32" Alias "SendMessageA" (ByVal hWnd As Long, ByVal wMsg As Long, ByVal wParam As Long, lParam As Any) As Long
Public Declare Function ReleaseCapture Lib "user32" () As Long
Global Const WM_NCLBUTTONDOWN = &HA1
Global Const HTCAPTION = 2
Public Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpString As Any, ByVal lpFileName As String) As Long
Public Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
Public ManPosition As Byte
Public SkinPath As String
Public ManSide As Byte
Public Declare Sub Sleep Lib "kernel32" (ByVal dwMilliseconds As Long)
Public CanPressButton As Boolean
Public Type box_data
    Present As Boolean
    Texture As Byte
    Position As Byte
End Type
Global box(20) As box_data
Public TargetSectors(20) As Byte
Public IdleFrame As Byte
Public box_sector As Integer
Public side_sector As Integer
Public MemoryCut As Long
Public AKey As Byte
Public IdleStay As Boolean
Public MovingBox As Boolean
Public MovingBoxTex As Byte
Public Type megasound
  enabled As Boolean
  Interval As Byte
  file As String
End Type
Global Sound(5) As megasound

