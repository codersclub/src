VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form Form1 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00C0C0C0&
   BorderStyle     =   1  'Fixed Single
   Caption         =   " Icon Extractor"
   ClientHeight    =   7185
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   10575
   BeginProperty Font 
      Name            =   "Comic Sans MS"
      Size            =   6.75
      Charset         =   0
      Weight          =   400
      Underline       =   0   'False
      Italic          =   0   'False
      Strikethrough   =   0   'False
   EndProperty
   ForeColor       =   &H00000000&
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   LockControls    =   -1  'True
   MaxButton       =   0   'False
   ScaleHeight     =   7185
   ScaleWidth      =   10575
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      BackColor       =   &H00FFFFFF&
      ForeColor       =   &H80000008&
      Height          =   240
      Left            =   5460
      ScaleHeight     =   210
      ScaleWidth      =   4920
      TabIndex        =   16
      Top             =   6885
      Width           =   4950
      Begin VB.Shape Progress 
         BackColor       =   &H00000000&
         BackStyle       =   1  'Opaque
         BorderColor     =   &H00000000&
         Height          =   300
         Left            =   0
         Top             =   0
         Width           =   240
      End
   End
   Begin VB.PictureBox IconShower 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00000000&
      Height          =   600
      Left            =   10800
      ScaleHeight     =   540
      ScaleWidth      =   540
      TabIndex        =   14
      ToolTipText     =   "Use the scroll bar to view the images"
      Top             =   1365
      Visible         =   0   'False
      Width           =   600
   End
   Begin VB.ListBox IconSelect 
      Appearance      =   0  'Flat
      Height          =   420
      ItemData        =   "frmMain.frx":030A
      Left            =   10800
      List            =   "frmMain.frx":030C
      TabIndex        =   13
      Top             =   1965
      Visible         =   0   'False
      Width           =   600
   End
   Begin VB.FileListBox HiddenFiles 
      Appearance      =   0  'Flat
      Height          =   420
      Left            =   10800
      TabIndex        =   12
      Top             =   945
      Visible         =   0   'False
      Width           =   600
   End
   Begin VB.Frame Frame2 
      BackColor       =   &H00C0C0C0&
      Height          =   6165
      Left            =   3075
      TabIndex        =   6
      Top             =   555
      Width           =   7410
      Begin VB.VScrollBar VScroll1 
         Height          =   5775
         Left            =   7050
         Max             =   0
         TabIndex        =   11
         Top             =   225
         Width           =   210
      End
      Begin VB.PictureBox Picture10 
         BackColor       =   &H00000000&
         BorderStyle     =   0  'None
         Height          =   5775
         Left            =   135
         ScaleHeight     =   5775
         ScaleWidth      =   6915
         TabIndex        =   7
         Top             =   225
         Width           =   6915
         Begin VB.PictureBox Picture1 
            Appearance      =   0  'Flat
            BackColor       =   &H00000000&
            ForeColor       =   &H80000008&
            Height          =   5865
            Left            =   210
            ScaleHeight     =   5835
            ScaleWidth      =   6495
            TabIndex        =   8
            Top             =   195
            Width           =   6525
            Begin VB.PictureBox Scene 
               BackColor       =   &H00000000&
               BorderStyle     =   0  'None
               ForeColor       =   &H00000000&
               Height          =   5535
               Left            =   0
               ScaleHeight     =   5535
               ScaleWidth      =   6750
               TabIndex        =   9
               Top             =   15
               Width           =   6750
               Begin VB.PictureBox Thumbnail 
                  AutoSize        =   -1  'True
                  BackColor       =   &H00000000&
                  BorderStyle     =   0  'None
                  Height          =   600
                  Index           =   0
                  Left            =   210
                  MousePointer    =   10  'Up Arrow
                  ScaleHeight     =   600
                  ScaleWidth      =   600
                  TabIndex        =   10
                  Top             =   195
                  Visible         =   0   'False
                  Width           =   600
               End
            End
         End
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00C0C0C0&
      Height          =   6165
      Left            =   75
      TabIndex        =   1
      Top             =   555
      Width           =   2925
      Begin VB.CommandButton Command2 
         BackColor       =   &H00C0C0C0&
         Caption         =   "Extract Icons For Viewing"
         Height          =   285
         Left            =   135
         TabIndex        =   5
         Top             =   5760
         Width           =   2640
      End
      Begin VB.FileListBox Files 
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H00000000&
         Height          =   2820
         Left            =   135
         TabIndex        =   4
         Top             =   2835
         Width           =   2640
      End
      Begin VB.DirListBox Folders 
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H00000000&
         Height          =   2115
         Left            =   135
         TabIndex        =   3
         Top             =   630
         Width           =   2640
      End
      Begin VB.DriveListBox Drives 
         BackColor       =   &H00FFFFFF&
         ForeColor       =   &H00000000&
         Height          =   315
         Left            =   135
         TabIndex        =   2
         Top             =   225
         Width           =   2640
      End
   End
   Begin MSComctlLib.ImageList ImageList1 
      Left            =   10815
      Top             =   2385
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   16
      ImageHeight     =   16
      MaskColor       =   12632256
      _Version        =   393216
      BeginProperty Images {2C247F25-8591-11D1-B16A-00C0F0283628} 
         NumListImages   =   11
         BeginProperty ListImage1 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":030E
            Key             =   ""
         EndProperty
         BeginProperty ListImage2 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0662
            Key             =   ""
         EndProperty
         BeginProperty ListImage3 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":09B6
            Key             =   ""
         EndProperty
         BeginProperty ListImage4 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":0D0A
            Key             =   ""
         EndProperty
         BeginProperty ListImage5 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":105E
            Key             =   ""
         EndProperty
         BeginProperty ListImage6 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":13B2
            Key             =   ""
         EndProperty
         BeginProperty ListImage7 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1706
            Key             =   ""
         EndProperty
         BeginProperty ListImage8 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1A22
            Key             =   ""
         EndProperty
         BeginProperty ListImage9 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":1D3E
            Key             =   ""
         EndProperty
         BeginProperty ListImage10 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":205A
            Key             =   ""
         EndProperty
         BeginProperty ListImage11 {2C247F27-8591-11D1-B16A-00C0F0283628} 
            Picture         =   "frmMain.frx":2376
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.Toolbar Toolbar1 
      Align           =   1  'Align Top
      Height          =   540
      Left            =   0
      TabIndex        =   15
      Top             =   0
      Width           =   10575
      _ExtentX        =   18653
      _ExtentY        =   953
      ButtonWidth     =   1058
      ButtonHeight    =   953
      Style           =   1
      ImageList       =   "ImageList1"
      _Version        =   393216
      BeginProperty Buttons {66833FE8-8583-11D1-B16A-00C0F0283628} 
         NumButtons      =   5
         BeginProperty Button1 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Extract"
            Key             =   "Extract"
            Object.ToolTipText     =   "Extract"
            ImageIndex      =   4
         EndProperty
         BeginProperty Button2 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Style           =   3
         EndProperty
         BeginProperty Button3 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "About"
            Key             =   "About"
            Object.ToolTipText     =   "About"
            ImageIndex      =   9
         EndProperty
         BeginProperty Button4 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Pages"
            Key             =   "Pages"
            ImageIndex      =   7
            Style           =   5
            BeginProperty ButtonMenus {66833FEC-8583-11D1-B16A-00C0F0283628} 
               NumButtonMenus  =   13
               BeginProperty ButtonMenu1 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "dash"
                  Text            =   "-"
               EndProperty
               BeginProperty ButtonMenu2 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Island"
                  Text            =   "Yoshi's Island"
               EndProperty
               BeginProperty ButtonMenu3 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Yahoo"
                  Text            =   "Yahoo!"
               EndProperty
               BeginProperty ButtonMenu4 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Microsoft"
                  Text            =   "Microsoft"
               EndProperty
               BeginProperty ButtonMenu5 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Webcrawler"
                  Text            =   "Webcrawler"
               EndProperty
               BeginProperty ButtonMenu6 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Lycos"
                  Text            =   "Lycos"
               EndProperty
               BeginProperty ButtonMenu7 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "Download"
                  Text            =   "Downloads"
               EndProperty
               BeginProperty ButtonMenu8 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "AOL"
                  Text            =   "America Online"
               EndProperty
               BeginProperty ButtonMenu9 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "AltaVista"
                  Text            =   "AltaVista"
               EndProperty
               BeginProperty ButtonMenu10 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "AudioFind"
                  Text            =   "AudioFind"
               EndProperty
               BeginProperty ButtonMenu11 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "ActiveX"
                  Text            =   "Active X"
               EndProperty
               BeginProperty ButtonMenu12 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "3dCafe"
                  Text            =   "3D Cafe"
               EndProperty
               BeginProperty ButtonMenu13 {66833FEE-8583-11D1-B16A-00C0F0283628} 
                  Key             =   "DasHaz"
                  Text            =   "-"
               EndProperty
            EndProperty
         EndProperty
         BeginProperty Button5 {66833FEA-8583-11D1-B16A-00C0F0283628} 
            Caption         =   "Exit"
            Key             =   "Exit"
            ImageIndex      =   11
         EndProperty
      EndProperty
   End
   Begin MSComctlLib.StatusBar Status 
      Align           =   2  'Align Bottom
      Height          =   405
      Left            =   0
      TabIndex        =   0
      Top             =   6780
      Width           =   10575
      _ExtentX        =   18653
      _ExtentY        =   714
      _Version        =   393216
      BeginProperty Panels {8E3867A5-8586-11D1-B16A-00C0F0283628} 
         NumPanels       =   2
         BeginProperty Panel1 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   9287
         EndProperty
         BeginProperty Panel2 {8E3867AB-8586-11D1-B16A-00C0F0283628} 
            AutoSize        =   1
            Object.Width           =   9287
         EndProperty
      EndProperty
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Special for using variables without formally declaring them...
Option Explicit
'For extracting the icon info from a file...
Private Declare Function ExtractIcon Lib "shell32.dll" Alias "ExtractIconA" (ByVal hInst As Long, ByVal lpszExeFileName As String, ByVal nIconIndex As Long) As Long
'For removing (closing) the icon from access with the program...
Private Declare Function DestroyIcon Lib "user32" (ByVal hIcon As Long) As Long
'For drawing the icon into the picture box...
Private Declare Function DrawIconEx Lib "user32" (ByVal hDC As Long, ByVal xLeft As Long, ByVal yTop As Long, ByVal hIcon As Long, ByVal cxWidth As Long, ByVal cyWidth As Long, ByVal istepIfAniCur As Long, ByVal hbrFlickerFreeDraw As Long, ByVal diFlags As Long) As Long
'Also for drawing icons in to the picture box...
Private Declare Function DrawIcon Lib "user32" (ByVal hDC As Long, ByVal X As Long, ByVal Y As Long, ByVal hIcon As Long) As Long
'A flag for running the DrawIconEx API normally without any options...
Private Const DI_NORMAL = &H3

Private Sub Command2_Click()
'This sub generates all the thumbnails...
'Declare variables...
Dim Columns, Rows, Tot, MaxWidth, Counter As Integer, Killer, Math
'Set variable information...
Math = 0: Counter = 0: Killer = 0: Columns = 0: Rows = 0: Tot = 0
'Kill thumbnails...
KillThumbNails
'Set the scroll bar value...
VScroll1.Value = 0
'Set the scroll bar max...
VScroll1.Max = 0
'If there are no icons in the file the user selected then...
If IconSelect.ListCount < 1 Then
    'Message the user...
    MsgBox "No icons to view...", vbInformation, "Icon Extractor 1.0"
    'Exit since there is nothing to do...
    Exit Sub
'End the If statement...
End If
'Make the Counter variable equal zero to the amount of icons in the file...
For Counter = 0 To IconSelect.ListCount - 1
    'Make sure we are updating the picture as we update the file...
    IconSelect.ListIndex = Counter
    'Make sure we don't load the first command button since it is already
    'loaded...
    If Counter = 0 Then GoTo SkipNextProcedure
    'Load the command button for the current icon...
    Load Thumbnail(Counter)
'Skipping point...
SkipNextProcedure:
    'Make sure it's visible...
    Thumbnail(Counter).Visible = True
    'Call the DecorateThumbs function for the current icon...
    DecorateThumbs Counter
    'Make the MaxWidth variable equal to the picture boxes width divided by
    '1350, giving us an approxiamte width for how big each button should be..
    MaxWidth = Scene.Width / (1085)
    'If the button width is a decimal, and it ends with .5 or higher, then...
    If Right(Round(MaxWidth, 1), 1) >= 5 Then
        'Round up...
        MaxWidth = Round(MaxWidth, 0) - 1
    'If it equals .4 or lower...
    Else
        'Round down...
        MaxWidth = Round(MaxWidth, 0)
    End If
    'Make the position of the command button 1350 times Rows, which is
    'currently zero. This leads it so that each button is aligned next
    'to eachother and isn't just in any random spot...
    Thumbnail(Counter).Left = (600 * Rows) + (60 * Rows)
    'If there is not enough room for another button on the same row...
    If Scene.Width - (Thumbnail(Counter).Left + 600) < MaxWidth Then
        'Make a new column...
        Columns = Columns + 1
        'Fix the position to align to the very left again...
        Thumbnail(Counter).Left = 0
        'Make the picture box bigger...
        Scene.Height = Scene.Height + 600 + 50
        'Set it to row 0...
        Rows = 0
    'End the If statement...
    End If
    'Add another row...
    Rows = Rows + 1
    'Set the length top property of the command buttons by multiplying
    'the amount of columns by their height...
    Thumbnail(Counter).Top = (610 * Columns) + (60 * Columns)
    'Make sure it is a visible button..
    Thumbnail(Counter).Visible = True
    'Set the progress bar visible...
    Progress.Visible = True
    'Do the math...
    Math = 4950 / IconSelect.ListCount
    'If this is the first thumbnail being loaded...
    If Counter = 0 Then
        'Start the progress bar from the beggining...
        Progress.Width = 0
        'Make the progress bar status equal the math...
        Progress.Width = Math
        'Skip the next sub...
        GoTo SkipThat
    'End the If statement...
    End If
    'Make the width match up with the thumbnail the program is loading...
    Progress.Width = Math * Counter
'The skipping point...
SkipThat:
    'Tell user how many icons have been loaded and how much are left...
    Form1.Status.Panels(1).Text = Thumbnail.Count & " of " & IconSelect.ListCount & " Loaded..."
    'Make sure the program does all these steps before repeating...
    DoEvents
'Do this for the next button...
Next Counter
'After all the processing has been done... make the progress bar invisible...
Progress.Visible = False
'Set the value...
VScroll1.Value = 0
'We don't need to worry if there are only 5 columns...
If Columns <= 5 Then Exit Sub
'Make it's maximum height equal the approxiamate height needed to encompass
'all of icons...
VScroll1.Max = (Columns * 600) - (Picture2.Height / 600)
'Set the small change...
VScroll1.SmallChange = Thumbnail(0).Height
'Set the large change...
VScroll1.LargeChange = Picture1.ScaleHeight
End Sub

Private Sub Drives_Change()
'The sub for when you change the drive letter...
'Skip errors...
On Error Resume Next
'When then the drive letter is changed, update the folder list...
Folders.Path = Drives.Drive
End Sub

Private Sub Files_Click()
'The sub for when you select a file from the files list...
'Declare variables...
Dim Count, Path, Procedure
'Clear the list...
IconSelect.Clear
'Make the Path variale equal the full path name (ex. C:\Hey\Sup.ico)...
Path = Folders.Path & "\" & Files.FileName
'Make the Count variable equal the amount of icons in the specified file
'using the ExtractIcon...
Count = ExtractIcon(App.hInstance, Path, -1)
'If there are less than 1 (0) icons then...
If Count < 1 Then
    'Tell the user...
    Status.Panels.Item(1).Text = "0 Icons in " & Path
    'Exit the sub...
    Exit Sub
'End the If statement...
End If
'Make the Procedure variable equal the amount of icons in the file...
For Procedure = 0 To Count - 1
     'Add that file to a listbox...
     IconSelect.AddItem Procedure
'Keep doing this until all icons are added...
Next Procedure
'If there was only 1 icon in the file t hen...
If Count = 1 Then
    'Tell the user...
    Status.Panels.Item(1).Text = "1 Icon in " & Path
    'Exit the sub...
    Exit Sub
'End the If statement...
End If
'Tell the user how many icons and in what file...
Status.Panels.Item(1).Text = Count & " Icons in " & Path
End Sub

Private Sub Folders_Change()
'The sub for when the user selects a different folder...
'Update the files to the folders...
Files.Path = Folders.Path
End Sub

Private Sub Form_Load()
'The form load...
'Make the file list's pattern set so that the user can only select
'files that are exe's, dll's, and icl's...
Files.Pattern = "*.exe;*.dll;*.icl"
'Make the progress equal nothing...
Progress.Width = 0
'Make the progress invisible...
Progress.Visible = False
Status.Panels.Item(1).Text = "Ready... Waiting For Orders..."
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
'This sub makes user the user wants to exit when he clicks
'Declare variables...
Dim Positive As String
'Message the user and put his response in the Positive variable...
Positive$ = MsgBox("Are you sure you wish to exit Icon Extractor? All unsaved data will be deleted...", vbInformation + vbYesNo, " Icon Extractor 1.5")
'If he clicked no then...
If Positive$ = vbNo Then
    'Cancel the operation...
    Cancel% = 1
    'Exit the sub...
    Exit Sub
'If he clicked yes then...
Else
    'Unload the form...
    Unload Me
    'End the program...
    End
'End the If statement...
End If
End Sub

Private Sub Thumbnail_MouseDown(Index As Integer, Button As Integer, Shift As Integer, X As Single, Y As Single)
'Set the label...
Form2.Label1.Caption = Index
'Open the popupmenu if they right clicked...
If Button = 2 Then PopupMenu Form2.File
End Sub

Private Sub Toolbar1_ButtonClick(ByVal Button As MSComctlLib.Button)
'This sub is for button clicks...
'If they clicked exit then...
If Button.Key = "Exit" Then
    'This sub exits the program...
    'Declare variable...
    Dim Certain As String
    'Make the Certain variable equal the output that the user gives in response
    'to a message box asking if he wishes to exit...
    Certain$ = MsgBox("Are you sure you wish to exit Icon Extractor? All unsaved data will be deleted...", vbInformation + vbYesNo, " Icon Extractor 1.5")
    'If the use clicked no, then...
    If Certain$ = vbNo Then
        'Don't bother doing anything, but don't quit...
        Exit Sub
    'If he clicked yes, then...
    Else
        'Kill lag..
        DoEvents
        'End the program..
        End
        'Unload the form...
        Unload Me
    'End this If statement...
    End If
'End this If statement..
End If
'If they clicked about then...
If Button.Key = "About" Then
    'Message the user...
    MsgBox "Icon Extractor 1.5 was made by Yoshi in Visual Basic 6. Please mail any bugs or comments to yoshiii@aol.com. Please visit Yoshi's site at yiz0.cjb.net. Thanks.", vbInformation, " Icon Extractor 1.5"
'End the If statement...
End If
'If they clicked extract then...
If Button.Key = "Extract" Then
    'Message the user...
    MsgBox "If you wish to extract a compressed icon as a bitmap, icon, or text file, please right click the file and select the option you want.", vbInformation, " Icon Extract 1.5"
'End the If statement...
End If
End Sub

Private Sub Toolbar1_ButtonMenuClick(ByVal ButtonMenu As MSComctlLib.ButtonMenu)
'This sub is for the menu clicks...
'Declare variables...
Dim ToPrint As String
'If they want my website...
If ButtonMenu.Key = "Island" Then Shell ("Start http://yiz0.cjb.net")
'If they want Yahoo...
If ButtonMenu.Key = "Yahoo" Then Shell ("Start http://www.yahoo.com")
'If they want Microsoft...
If ButtonMenu.Key = "Microsoft" Then Shell ("Start http://www.microsoft.com")
'If they want Webcrawler...
If ButtonMenu.Key = "Webcrawler" Then Shell ("Start http://www.webcrawler.com")
'If they want Lycos...
If ButtonMenu.Key = "Lycos" Then Shell ("Start http://www.lycos.com")
'If they want Downloads...
If ButtonMenu.Key = "Download" Then Shell ("Start http://www.download.com")
'If they want AOL...
If ButtonMenu.Key = "AOL" Then Shell ("Start http://www.aol.com")
'If they want AltaVista...
If ButtonMenu.Key = "AltaVista" Then Shell ("Start http://www.altavista.com")
'If they want AudioFind...
If ButtonMenu.Key = "AudioFind" Then Shell ("Start http://www.audiofind.com")
'If they want Active X...
If ButtonMenu.Key = "ActiveX" Then Shell ("Start http://www.activex.com")
'If they want 3d Cafe...
If ButtonMenu.Key = "3dCafe" Then Shell ("Start www.3dcafe.com")
End Sub

Private Sub VScroll1_Change()
'This sub scrolls the picture...
'Make the height of the scene equal the negation of the scrollbar value,
'so that as the scrollbar scrolls down, the picture goes up...
Scene.Top = -VScroll1.Value
'Set the focus to the main picture, not necessary so that the picture doesn't
'mess up by accidently aligning with the Scene picturebox..
Picture1.SetFocus
End Sub
