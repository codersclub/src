VERSION 5.00
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form Form2 
   Caption         =   "Form2"
   ClientHeight    =   3615
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   6540
   LinkTopic       =   "Form2"
   ScaleHeight     =   3615
   ScaleWidth      =   6540
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text1 
      BeginProperty Font 
         Name            =   "Terminal"
         Size            =   9
         Charset         =   255
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   3120
      Left            =   150
      MultiLine       =   -1  'True
      ScrollBars      =   3  'Both
      TabIndex        =   2
      Top             =   270
      Width           =   6270
   End
   Begin VB.PictureBox Picture1 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H00000000&
      Height          =   705
      Left            =   1980
      ScaleHeight     =   43
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   45
      TabIndex        =   1
      Top             =   3300
      Width           =   735
   End
   Begin MSComDlg.CommonDialog CommonDialog1 
      Left            =   3165
      Top             =   -30
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.Label Label1 
      Height          =   765
      Left            =   4455
      TabIndex        =   0
      Top             =   165
      Width           =   2415
   End
   Begin VB.Menu File 
      Caption         =   "File"
      Begin VB.Menu Dash 
         Caption         =   "-"
      End
      Begin VB.Menu ico 
         Caption         =   "Extract As *.ico"
      End
      Begin VB.Menu bmp 
         Caption         =   "Extract As *.bmp"
      End
      Begin VB.Menu txt 
         Caption         =   "Extract As *.txt"
      End
      Begin VB.Menu DashA 
         Caption         =   "-"
      End
   End
End
Attribute VB_Name = "Form2"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
'Makes it so that you don't have to put the variable symbol
'after a variable you declared...
Option Explicit

Private Sub bmp_Click()
'This sub is for saving the file as a bitmap...
'Skip errors...
On Error Resume Next
'Use Form1 as the identifier...
With Form1
'Set the title...
CommonDialog1.DialogTitle = "Select A Filename..."
'Set the filter...
CommonDialog1.Filter = "Bitmaps (*.bmp) | *.bmp"
'Show the dialog box...
CommonDialog1.ShowSave
'If no file, then exit...
If CommonDialog1.FileName = "" Then Exit Sub
'Lower case it all...
CommonDialog1.FileName = LCase(CommonDialog1.FileName)
'If it isn't a bitmap file, don't save it...
If Right(CommonDialog1.FileName, 4) <> ".bmp" Then
    'Message the user...
    MsgBox "Please choose a valid bitmap file...", vbInformation, "Icon Extractor 1.5"
    'Exit...
    Exit Sub
'End the if statement...
End If
'Save the picture...
Call SavePicture(.Thumbnail(Label1.Caption).Picture, CommonDialog1.FileName)
'End the identification by Form1
End With
End Sub

Private Sub ico_Click()
'This sub is for saving the file as an icon...
'Skip errors...
On Error Resume Next
'Use Form1 as the identifier...
With Form1
'Set the title...
CommonDialog1.DialogTitle = "Select A Filename..."
'Set the filter...
CommonDialog1.Filter = "Icon Files (*.ico) | *.ico"
'Show the dialog box...
CommonDialog1.ShowSave
'If no file, then exit...
If CommonDialog1.FileName = "" Then Exit Sub
'Lower case it all...
CommonDialog1.FileName = LCase(CommonDialog1.FileName)
'If it isn't an icon file, don't save it...
If Right(CommonDialog1.FileName, 4) <> ".ico" Then
    'Message the user...
    MsgBox "Please choose a valid icon file...", vbInformation, "Icon Extractor 1.5"
    'Exit...
    Exit Sub
'End the if statement...
End If
'Save the picture...
Call SavePicture(.Thumbnail(Label1.Caption).Picture, CommonDialog1.FileName)
'End the identification by Form1
End With
End Sub

Private Sub txt_Click()
'This sub is for saving the file as a text macro...
'Skip errors...
On Error Resume Next
'Declare variables...
Dim xCoordinate, yCoordinate As Integer
'Declare more variables...
Dim xCounter, yCounter As Integer
'Declare variables...
Dim PointColor As Long, Conversion As String
'Use Form1 as the identifier...
With Form1
'Load the picture..
Picture1.Picture = .Thumbnail(Label1.Caption).Picture
'Set the title...
CommonDialog1.DialogTitle = "Select A Filename..."
'Set the filter...
CommonDialog1.Filter = "Text Files (*.txt) | *.txt"
'Show the dialog box...
CommonDialog1.ShowSave
'If no file, then exit...
If CommonDialog1.FileName = "" Then Exit Sub
'Lower case it all...
CommonDialog1.FileName = LCase(CommonDialog1.FileName)
'If it isn't a text file, don't save it...
If Right(CommonDialog1.FileName, 4) <> ".txt" Then
    'Message the user...
    MsgBox "Please choose a valid text file...", vbInformation, "Icon Extractor 1.5"
    'Exit...
    Exit Sub
'End the if statement...
End If
'Get the values...
xCoordinate = Picture1.ScaleWidth - 1: yCoordinate = Picture1.ScaleHeight - 1
'Start a for next loop...
For xCounter = 1 To xCoordinate Step 1
    'Start another for next loop...
    For yCounter = 1 To yCoordinate Step 1
        'Let the program catchup...
        DoEvents
        'Get the point...
        PointColor = Picture1.Point(yCounter, xCounter)
        'If the color is of a dark or black value then...
        If PointColor <= RGB(0, 0, 0) Then
            'Draw the character...
            Conversion = Conversion & "#"
        'If it is a dark but not black character then...
        ElseIf PointColor <= RGB(180, 180, 180) Then
            'Draw the character...
            Conversion = Conversion & "."
        'If it was a white or light point then...
        ElseIf PointColor <= RGB(250, 250, 250) Then
            'Draw the character...
            Conversion = Conversion & "."
        'If it was anything else then...
        Else
            'Draw a clear space...
            Conversion = Conversion & " "
        'End the If statement...
        End If
     'Repeat this loop...
    Next
    'Set to the next line of the function...
    Conversion = Conversion & vbNewLine
    'Let the program catch up...
    DoEvents
    'Refresh the textbox...
    Text1.Text = Text1.Text & Conversion
    'Clear the variable..
    Conversion = ""
'Keep the loop...
Next
'Open the selected file for input...
Open CommonDialog1.FileName For Output As #1
'Write the info...
Print #1, Text1.Text;
'Close the file...
Close #1
'End the identification by Form1
End With
End Sub
