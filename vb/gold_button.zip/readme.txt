====================
== Gold Button by Night Wolf==
====================
Well, here it is. The new version of Gold Button.

What's new in v1.1?
 * Skin Support (Pretty cool. :) 
    * There's a Photoshop(.PSD) file within the zip file, so you can create your own button skin :). The picture formats should be  82(W) x 115(H).
 * Picture Property (as requested :)
    Note: picture can only be on the left side of the button
 * Fixed Enabled Property (False was not working right)

ENJOY :)


Night Wolf
night_wolf_god@hotmail.com
