Attribute VB_Name = "�������������"

Public Function TryMove(side, zone As Byte) As Boolean

Dim Answer As Boolean
Dim Region As Byte
Dim TamBox As Boolean
Dim RegionForBox As Byte



Select Case side
  
  Case 1
    
     If zone < 17 Then
       Answer = False
       GoTo 9898
     End If
    Region = zone - 18
    If (zone - 36) < 0 Then
      RegionForBox = 0
    Else
      RegionForBox = zone - 36
    End If
  
  
  Case 2
    
     If zone > 197 - 17 Then
       Answer = False
       GoTo 9898
     End If
    Region = zone + 18
    If zone + 36 > 197 Then
      RegionForBox = 0
    Else
      RegionForBox = zone + 36
    End If
    
  Case 3
    
     If GotX(zone) = 0 Then
       Answer = False
       GoTo 9898
     End If
    Region = zone - 1
    If (zone - 2) < 0 Then
    RegionForBox = 0
    Else
    RegionForBox = zone - 2
    End If

  Case 4
    
     If GotX(zone) = 16 Then
       Answer = False
       GoTo 9898
     End If
    Region = zone + 1
    If (zone + 2) > 197 Then
      RegionForBox = 0
    Else
      RegionForBox = zone + 2
    End If
End Select



If Map(GotX(Region), GotY(Region)) = "A" Then Answer = False

If Map(GotX(Region), GotY(Region)) = "B" Then

  tmp$ = Map(GotX(RegionForBox), GotY(RegionForBox))
  If tmp$ = "-" Or tmp$ = "P" Then
    Answer = True
  Else
    Answer = False
  End If
  TamBox = True
End If

If Map(GotX(Region), GotY(Region)) = "-" Then Answer = True
If Map(GotX(Region), GotY(Region)) = "P" Then Answer = True '������ �� ��������



   If side = 1 Then tmp5 = SpriteMan_up1
   If side = 2 Then tmp5 = SpriteMan_down1
   If side = 3 Then tmp5 = SpriteMan_left1
   If side = 4 Then tmp5 = SpriteMan_right1




If Answer = True Then
  If TamBox = True Then
    
    
  
  
  
  

Call Main.PlayMoveBox
Call Main.PlayPlayerSteps

cadr = 0
  
If side = 3 Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_left1
If cadr = 1 Then tmp5 = SpriteMan_left2
If cadr = 2 Then tmp5 = SpriteMan_left3
If cadr = 3 Then tmp5 = SpriteMan_left2
If OriginalMap((GotX(RegionForBox) + 1), GotY(RegionForBox)) = "P" Then
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) + 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
  Else
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) + 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
   
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
If OriginalMap((GotX(RegionForBox) + 2), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) + 64), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) + 64), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
    
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) + 64) - i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) + 32) - i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBox).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If


If side = 4 Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_right1
If cadr = 1 Then tmp5 = SpriteMan_right2
If cadr = 2 Then tmp5 = SpriteMan_right3
If cadr = 3 Then tmp5 = SpriteMan_right2
If OriginalMap((GotX(RegionForBox) - 1), GotY(RegionForBox)) = "P" Then
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) - 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
  Else
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) - 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
   
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
If OriginalMap((GotX(RegionForBox) - 2), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) - 64), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) - 64), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
    
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) - 64) + i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) - 32) + i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBox).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If
  
If side = 1 Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_up1
If cadr = 1 Then tmp5 = SpriteMan_up2
If cadr = 2 Then tmp5 = SpriteMan_up3
If cadr = 3 Then tmp5 = SpriteMan_up2

If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) + 1) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) + 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) + 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
   
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) + 2) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64) - i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 32) - i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBox).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If
  
If side = 2 Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_down1
If cadr = 1 Then tmp5 = SpriteMan_down2
If cadr = 2 Then tmp5 = SpriteMan_down3
If cadr = 3 Then tmp5 = SpriteMan_down2
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) - 1) = "P" Then
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) - 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
  Else
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) - 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
   
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox)) = "P" Then
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
    Else
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
    
      If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) - 2) = "P" Then
      FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
      Else
      FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
      End If

    
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64) + i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
    FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 32) + i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBox).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If
  
  
  
    Map(GotX(RegionForBox), GotY(RegionForBox)) = "B"
  




  
  End If
8787
If side = 1 And TamBox = False Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_up1
If cadr = 1 Then tmp5 = SpriteMan_up2
If cadr = 2 Then tmp5 = SpriteMan_up3
If cadr = 3 Then tmp5 = SpriteMan_up2

If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) + 1) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) + 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) + 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
     
If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) + 2) = "P" Then
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) + 64) - i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If

If side = 2 And TamBox = False Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_down1
If cadr = 1 Then tmp5 = SpriteMan_down2
If cadr = 2 Then tmp5 = SpriteMan_down3
If cadr = 3 Then tmp5 = SpriteMan_down2

If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) - 1) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) - 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox)) * 32), (GotY(RegionForBox) - 1) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If

If OriginalMap((GotX(RegionForBox)), GotY(RegionForBox) - 2) = "P" Then
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
     End If
     
     
     FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32), ((GotY(RegionForBox) * 32) - 64) + i * 2, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
  Sleep 5
  Next i
End If

If side = 4 And TamBox = False Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_right1
If cadr = 1 Then tmp5 = SpriteMan_right2
If cadr = 2 Then tmp5 = SpriteMan_right3
If cadr = 3 Then tmp5 = SpriteMan_right2

If OriginalMap((GotX(RegionForBox) - 1), GotY(RegionForBox)) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) - 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) - 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If
   
If OriginalMap((GotX(RegionForBox) - 2), GotY(RegionForBox)) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32) - 64, ((GotY(RegionForBox) * 32)), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
Else
   FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32) - 64, ((GotY(RegionForBox) * 32)), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
    End If
    
    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) - 64) + i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh
Sleep 5
  Next i
End If

If side = 3 And TamBox = False Then
For i = 1 To 16
cadr = Int(i / 4)
If cadr = 0 Then tmp5 = SpriteMan_left1
If cadr = 1 Then tmp5 = SpriteMan_left2
If cadr = 2 Then tmp5 = SpriteMan_left3
If cadr = 3 Then tmp5 = SpriteMan_left2

If OriginalMap((GotX(RegionForBox) + 1), GotY(RegionForBox)) = "P" Then
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) + 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)

Else
  FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) + 1) * 32), GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)
End If


If OriginalMap(GotX(RegionForBox + 2), GotY(RegionForBox)) = "P" Then
  FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32) + 64, ((GotY(RegionForBox) * 32)), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)

  Else
  FoxBlendIn Main.PlayScreen.hDC, (GotX(RegionForBox) * 32) + 64, ((GotY(RegionForBox) * 32)), tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)

End If


    FoxBlendIn Main.PlayScreen.hDC, ((GotX(RegionForBox) * 32) + 64) - i * 2, GotY(RegionForBox) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(tmp5).Handle, &HFF00&, 255, -CBool(True)
  Main.PlayScreen.Refresh

Sleep 5
  Next i
End If
 
 
 

 Map(GotX(Region), GotY(Region)) = "I"
 

 If TamBox = False And Answer = True Then
 Call Main.PlayPlayerSteps
 End If
 

 If OriginalMap(GotX(MyPos), GotY(MyPos)) = "P" Then
FoxBlendIn Main.PlayScreen.hDC, GotX(MyPos) * 32, GotY(MyPos) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteBoxParkovka).Handle, &HFF00&, 255, -CBool(True)
   Map(GotX(MyPos), GotY(MyPos)) = "P"
 Else
FoxBlendIn Main.PlayScreen.hDC, GotX(MyPos) * 32, GotY(MyPos) * 32, tiles.hDC, tiles.test_tiles.GraphicCell(SpriteNothing).Handle, &HFF00&, 255, -CBool(True)

   Map(GotX(MyPos), GotY(MyPos)) = "-"

 End If
 

 MyPos = GotSector(GotX(Region), GotY(Region))
 
End If


Main.PlayScreen.Refresh



9898 CheckCanMove = Answer
CanPress = True

End Function

Public Sub ScanForWin()
Dim parkova As Byte
Dim box As Byte
Parkovka = 0

For i = 0 To 10
  For j = 0 To 16
    If OriginalMap(j, i) = "P" Then
       Parkovka = Parkovka + 1
       If Map(j, i) = "B" Then box = box + 1
    End If
  Next j
Next i


If box = Parkovka Then
Main.PlayScreen.Enabled = False
  MsgBox "�� ��������!"
 Main.keytimer.Enabled = False
 End
Else
  Exit Sub
End If



End Sub
