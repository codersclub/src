Attribute VB_Name = "������������������"

Public Function GotSector(X, Y) As Byte



GotSector = (X + (18 * Y)) + 1
End Function

Public Function GotY(Sector) As Byte

 If Sector < 18 Then
   GotY = 0
   Exit Function
 End If
 
 If Sector > (197 - 18) Then
   GotY = 10
   Exit Function
 End If
 
 GotY = Sector \ 18
 
End Function

Public Function GotX(Sector) As Byte


GotX = (Sector - (GotY(Sector) * 18)) - 1


End Function
