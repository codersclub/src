Attribute VB_Name = "�������������������"
Public Declare Function FoxBlendIn Lib "FoxCBmp.dll" (ByVal DstDC As Long, ByVal DstX As Long, ByVal DstY As Long, ByVal SrcDC As Long, ByVal SrcBmp As Long, ByVal TransColor As Long, ByVal Alpha As Byte, ByVal Flags As Long) As Long

Dim CurX As Long, CurY As Long
Dim OldTime As Long

Public Sub DrawSector(tip, X, Y)
If tip = 1 Then sprite = SpriteNothing
If tip = 3 Then sprite = SpriteBox
If tip = 4 Then sprite = SpriteMan_up1
If tip = 5 Then sprite = SpriteBoxParkovka
If tip = 2 Then
  Dim sector_up As Boolean
  Dim sector_right As Boolean
  Dim sector_left As Boolean
  Dim sector_down As Boolean
If Y > 0 Then
tmp1 = Map(X, Y - 1)
  If tmp1 = "A" Then
   sector_up = True
  Else
    sector_up = False
  End If
    Else
sector_up = False
End If



If X > 0 Then
tmp1 = Map(X - 1, Y)
  If tmp1 = "A" Then
    sector_left = True
  Else
    sector_left = False
  End If

Else
sector_left = False
End If


If Y < 10 Then
tmp1 = Map(X, Y + 1)
  If tmp1 = "A" Then
    sector_down = True
  Else
  sector_down = False
  End If
Else
 sector_down = False
 End If


If X < 16 Then
tmp1 = Map(X + 1, Y)
  If tmp1 = "A" Then
    sector_right = True
  Else
    sector_right = False
  End If
Else
sector_right = False

End If


sprite = 6


If sector_up = True And sector_left = False And sector_right = False And sector_down = True Then sprite = 0
If sector_up = True And sector_left = False And sector_right = True And sector_down = True Then sprite = 1
If sector_up = True And sector_left = True And sector_right = True And sector_down = False Then sprite = 2
If sector_up = False And sector_left = True And sector_right = True And sector_down = True Then sprite = 3
If sector_up = True And sector_left = True And sector_right = False And sector_down = True Then sprite = 5
If sector_up = True And sector_left = True And sector_right = True And sector_down = True Then sprite = 6
If sector_up = True And sector_left = False And sector_right = True And sector_down = False Then sprite = 7
If sector_up = True And sector_left = True And sector_right = False And sector_down = False Then sprite = 9
If sector_up = False And sector_left = True And sector_right = False And sector_down = True Then sprite = 10
If sector_up = False And sector_left = False And sector_right = True And sector_down = True Then sprite = 11
If sector_up = True And sector_left = False And sector_right = False And sector_down = False Then sprite = 23
If sector_up = False And sector_left = False And sector_right = False And sector_down = True Then sprite = 27


If sector_up = False And sector_left = False And sector_right = True And sector_down = False Then sprite = 4
If sector_up = False And sector_left = True And sector_right = False And sector_down = False Then sprite = 4
If sector_up = False And sector_left = True And sector_right = True And sector_down = False Then sprite = 4

End If
FoxBlendIn Main.PlayScreen.hDC, X * 32, Y * 32, tiles.hDC, tiles.test_tiles.GraphicCell(sprite).Handle, &HFF00&, 255, -CBool(True)

  
  
End Sub
Public Function TransparentBlt(ByVal destHDC As Long, ByVal XDest As Long, ByVal YDest As Long, ByVal destWidth As Long, ByVal destHeight As Long, ByVal srcHDC As Long, ByVal XSrc As Long, ByVal YSrc As Long, ByVal srcWidth As Long, ByVal srcHeight As Long, ByVal TransparentColor As Long) As Long
  DrawTransparent destHDC, XDest, YDest, destWidth, destHeight, srcHDC, XSrc, ycrc, srcWidth, srcHeight, TransparentColor
End Function


Public Sub CreateFonForScreen()
tiles.picSchwan.Picture = tiles.test_tiles.GraphicCell(SpriteNothing)

Dim wid As Single
Dim hgt As Single
Dim X As Single
Dim Y As Single

    wid = tiles.picSchwan.ScaleWidth
    hgt = tiles.picSchwan.ScaleHeight
    Y = 0
    Do While Y < Main.PlayScreen.ScaleHeight
        X = 0
        Do While X < Main.PlayScreen.ScaleWidth
            Main.PlayScreen.PaintPicture tiles.test_tiles.GraphicCell(SpriteNothing), _
                X, Y, wid, hgt
            X = X + wid
        Loop
        Y = Y + hgt
    Loop


End Sub
