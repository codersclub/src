Attribute VB_Name = "�������"

Global Const SpriteBox = 15
Global Const SpriteBoxParkovka = 19


Global Const SpriteMan_up1 = 12
Global Const SpriteMan_up2 = 13
Global Const SpriteMan_up3 = 14

Global Const SpriteMan_right1 = 16
Global Const SpriteMan_right2 = 17
Global Const SpriteMan_right3 = 18

Global Const SpriteMan_down1 = 20
Global Const SpriteMan_down2 = 21
Global Const SpriteMan_down3 = 22

Global Const SpriteMan_left1 = 24
Global Const SpriteMan_left2 = 25
Global Const SpriteMan_left3 = 26

Global Const SpriteNothing = 8
