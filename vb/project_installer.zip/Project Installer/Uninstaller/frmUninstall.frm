VERSION 5.00
Begin VB.Form frmUninstall 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "<AppName> Uninstall"
   ClientHeight    =   3135
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5910
   Icon            =   "frmUninstall.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3135
   ScaleWidth      =   5910
   StartUpPosition =   2  'CenterScreen
   Begin VB.DirListBox dirListBox 
      Height          =   315
      Left            =   4680
      TabIndex        =   5
      Top             =   480
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.FileListBox fileListBox 
      Height          =   285
      Left            =   4680
      TabIndex        =   4
      Top             =   120
      Visible         =   0   'False
      Width           =   1095
   End
   Begin VB.Label UIStatus2 
      Height          =   1455
      Left            =   240
      TabIndex        =   3
      Top             =   960
      Width           =   5415
   End
   Begin VB.Label UIStatus 
      Caption         =   "Preparing to uninstall <AppName>..."
      Height          =   255
      Left            =   240
      TabIndex        =   2
      Top             =   360
      Width           =   5415
   End
   Begin VB.Label lblCopyright 
      Alignment       =   1  'Right Justify
      Caption         =   "Copyright � 2001 PCSCT Software. All rights reserved. "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   1800
      TabIndex        =   1
      Top             =   2880
      Width           =   4095
   End
   Begin VB.Label lblUninstaller 
      Alignment       =   1  'Right Justify
      Caption         =   "<AppName> <AppVersion> Uninstall  "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   2640
      Width           =   5775
   End
End
Attribute VB_Name = "frmUninstall"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private currentFrame As Integer
Private shellLink As New cShellLink
Private unInstalling As Boolean
Private appName As String
Private appVersion As String
Private appPath As String
Private execBeforeUninst As String

Private Sub Form_Activate()
If unInstalling = True Then Exit Sub
DoUninstall
End Sub

Private Sub Form_Load()
If Command = "" Then MsgBox "No command line parameters were specified. Uninstall can not continue.", vbOKOnly + vbExclamation, "Uninstall": End
If InStr(1, Command, ",,") <= 0 Then MsgBox "The program data syntax is incorrect. Uninstall can not continue.", vbOKOnly + vbExclamation, "Uninstall": End
cLP = Split(Command, ",,")
appName = cLP(0)
appVersion = cLP(1)
appPath = GetSettingString(HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion, "InstallDir")
execBeforeUninst = GetSettingString(HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion, "RunBeforeUninst")
If appPath = "" Or appPath = "ERROR" Then MsgBox "The program specified could not be found in the uninstall program database. Uninstall can not continue.", vbOKOnly + vbExclamation, "Uninstall": End
If mFolderExists(appPath) = False Then MsgBox "The program directory specified in the uninstall database could not be found. Uninstall can not continue.", vbOKOnly + vbExclamation, "Uninstall": End
If MsgBox("Do you want to uninstall " & appName & " " & appVersion & "?", vbYesNo + vbQuestion, "Uninstall " & appName) = vbNo Then End
Me.Caption = Replace(Me.Caption, "<AppName>", appName)
UIStatus.Caption = Replace(UIStatus.Caption, "<AppName>", appName)
lblUninstaller.Caption = Replace(lblUninstaller.Caption, "<AppName>", appName)
lblUninstaller.Caption = Replace(lblUninstaller.Caption, "<AppVersion>", appVersion)
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

Private Sub DoUninstall()
On Error Resume Next
Dim X As Integer
unInstalling = True
timedPause 1
If execBeforeUninst <> "" Then
    If mFileExists(execBeforeUninst) = True Then
        UIStatus.Caption = "Executing Program..."
        timedPause 1
        ShellAndWait execBeforeUninst, 0
    End If
End If
UIStatus.Caption = "Loading Resource Information..."
timedPause 1
UIStatus2.Caption = "Loading file resource information..."
fList = ReadDataFile(appPath & "\Un_Files.dat")
timedPause 1
UIStatus2.Caption = "Loading registry resource information..."
rList = ReadDataFile(appPath & "\Un_Reg.dat")
timedPause 1
UIStatus2.Caption = "Loading icon resource information..."
iList = ReadDataFile(appPath & "\Un_Icon.dat")
timedPause 1
UIStatus2.Caption = "Resources loaded."
timedPause 1
UIStatus2.Caption = ""
UIStatus.Caption = "Removing files..."
For X = LBound(fList) To UBound(fList)
    fI = Split(fList(X), "||")
    fI(1) = Replace(fI(1), "<AppPath>", appPath)
    fI(1) = Replace(fI(1), "<SysDir>", SysDir(False))
    fI(1) = Replace(fI(1), "<WinDir>", WinDir(False))
    UIStatus2.Caption = "Removing file " & UCase(fI(1) & "\" & fI(0)) & "..."
    mKillFile fI(1) & "\" & fI(0)
Next X
UIStatus2.Caption = ""
timedPause 1
UIStatus.Caption = "Removing program directory..."
mEmptyFolder appPath
mDeleteFolder appPath
timedPause 1
UIStatus.Caption = "Removing registry entries..."
For X = LBound(rList) To UBound(rList)
    rD = Split(rList(X), "||")
    If rD(0) = "HKEY_CLASSES_ROOT" Then
        HKEYString = HKEY_CLASSES_ROOT
    ElseIf rD(0) = "HKEY_CURRENT_USER" Then
        HKEYString = HKEY_CURRENT_USER
    ElseIf rD(0) = "HKEY_LOCAL_MACHINE" Then
        HKEYString = HKEY_LOCAL_MACHINE
    ElseIf rD(0) = "HKEY_USERS" Then
        HKEYString = HKEY_USERS
    ElseIf rD(0) = "HKEY_PERFORMANCE_DATA" Then
        HKEYString = HKEY_PERFORMANCE_DATA
    ElseIf rD(0) = "HKEY_CURRENT_CONFIG" Then
        HKEYString = HKEY_CURRENT_CONFIG
    ElseIf rD(0) = "HKEY_DYN_DATA" Then
        HKEYString = HKEY_DYN_DATA
    End If
    UIStatus2.Caption = "Removing registry entry " & UCase(rD(0) & "\" & rD(1) & "\" & rD(2)) & "..."
    DeleteSettingString CLng(HKEYString), CStr(rD(1)), CStr(rD(2))
    DeleteEmptyKeys CLng(HKEYString), CStr(rD(1))
Next X
UIStatus2.Caption = ""
timedPause 1
UIStatus.Caption = "Registry entries removed."
timedPause 1
UIStatus.Caption = "Removing icons..."
For X = LBound(iList) To UBound(iList)
    iD = Split(iList(X), "||")
    UIStatus2.Caption = "Removing icon " & UCase(iD(0) & "\" & iD(1) & "\" & iD(2))
    If iD(0) = "Desktop" Then
        Dim dFolder As String
        dFolder = GetSettingString(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Desktop")
        dFolder = TrimSlash(dFolder)
        mKillFile dFolder & "\" & iD(2) & ".lnk"
    Else
        Dim sFolder As String
        sFolder = GetSettingString(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Programs")
        sFolder = TrimSlash(sFolder)
        If iD(1) <> "" Then sFolder = sFolder & "\" & iD(1)
        mKillFile sFolder & "\" & iD(2) & ".lnk"
        If iD(1) <> "" Then
            fileListBox.Path = sFolder
            dirListBox.Path = sFolder
            If dirListBox.ListCount = 0 And fileListBox.ListCount = 0 Then
                mDeleteFolder sFolder
            End If
        End If
    End If
Next X
UIStatus2.Caption = ""
timedPause 1
UIStatus.Caption = "Icons removed."
timedPause 1
UIStatus.Caption = "Removing program information from uninstall database..."
RegDeleteKey HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion
DeleteEmptyKeys HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName
timedPause 1
UIStatus.Caption = "Removing uninstall information from Windows Uninstall Registry..."
RegDeleteKey HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion\Uninstall\" & appName
timedPause 1
UIStatus.Caption = "Uninstall complete."
timedPause 1
MsgBox appName & " " & appVersion & " has been successfully removed.", vbOKOnly + vbInformation, "Uninstall"
End
End Sub

