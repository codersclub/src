Attribute VB_Name = "supportData"
Public exitPause As Boolean

Public Function ReadDataFile(fileName As String) As Variant
On Error GoTo handleError
Dim fileData() As String
Dim ln As Integer
ln = -1
Open fileName For Input As #5
Do Until (EOF(5))
ln = ln + 1
ReDim Preserve fileData(ln) As String
Input #5, fileData(ln)
Loop
Close #5
ReadDataFile = fileData
Exit Function

handleError:
ReDim Preserve fileData(0) As String
ReDim Preserve fileData(1) As String
ReDim Preserve fileData(2) As String
Close #5
fileData(0) = "ERROR"
fileData(1) = Err.Description
fileData(2) = Err.Number
ReadDataFile = fileData
End Function

Public Function timedPause(secs As Long)
    Dim secStart As Variant
    Dim secNow As Variant
    Dim secDiff As Variant
    Dim temp%
    exitPause = False
    secStart = Format(Now(), "mm/dd/yyyy hh:nn:ss AM/PM")
    
    Do While secDiff < secs
        If exitPause = True Then Exit Do
         secNow = Format(Now(), "mm/dd/yyyy hh:nn:ss AM/PM")
        secDiff = DateDiff("s", secStart, secNow)
        temp% = DoEvents
    Loop
End Function

Public Function ShellAndWait(fileName As String, iWindowState As Integer)
On Error GoTo ERR_OpenForEdit
    
Dim objScript
Dim shellapp

Set objScript = CreateObject("WScript.Shell")

shellapp = objScript.Run(fileName, iWindowState, True)
ShellAndWait = True

EXIT_OpenForEdit:
    Exit Function

ERR_OpenForEdit:
    MsgBox Err.Description
        
End Function


Public Function TrimSlash(strTrim As String) As String
If Right(strTrim, 1) = "\" Then
    TrimSlash = Mid(strTrim, 1, Len(strTrim) - 1)
Else
    TrimSlash = strTrim
End If
End Function

