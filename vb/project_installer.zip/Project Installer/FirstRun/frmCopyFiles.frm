VERSION 5.00
Begin VB.Form frmCopyFiles 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Copying Files..."
   ClientHeight    =   720
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5175
   Icon            =   "frmCopyFiles.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   720
   ScaleWidth      =   5175
   StartUpPosition =   2  'CenterScreen
   Begin VB.Label Label1 
      Alignment       =   2  'Center
      Caption         =   "Copying Project Installer Resource Files... Please wait..."
      Height          =   255
      Left            =   0
      TabIndex        =   0
      Top             =   240
      Width           =   5175
   End
End
Attribute VB_Name = "frmCopyFiles"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Copying As Boolean

Private Sub Form_Activate()
On Error Resume Next
If Copying = True Then Exit Sub
Copying = True
timedPause 3
appPath = TrimSlash(App.Path)
appPath = Mid(appPath, 1, InStrRev(appPath, "\") - 1)
mCopyFile appPath & "\Install Creator\Setup Files\ShellLnk.dl_", SysDir & "\shelllnk.dll", True
mCopyFile appPath & "\Install Creator\Setup Files\ShellLnk.ex_", SysDir & "\shelllnk.exp", True
mCopyFile appPath & "\Install Creator\Setup Files\ShellLnk.tl_", SysDir & "\shelllnk.tlb", True
mCopyFile appPath & "\Install Creator\Setup Files\ShellLnk.li_", SysDir & "\shelllnk.lib", True
mCopyFile appPath & "\Install Creator\Setup Files\zLib.dl_", SysDir & "\zlib.dll", True
mRenameFile appPath & "\Install Creator\Setup Files\installCreator.ex_", "installCreator.exe"
MsgBox "The resource files have been copied. To run the install creator, go to the 'Project Installer\Install Creator\Setup Files' directory and run 'installCreator.exe'.", vbOKOnly + vbInformation, "Success"
Unload Me
End
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub
