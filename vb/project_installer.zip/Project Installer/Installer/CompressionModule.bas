Attribute VB_Name = "CompressionModule"
'######################ATTENTION!######################
'This mod was designed by Doug Gaede you can contact him at
'dgaede@home.com for more information on compression and other
'projects - PLEASE LOOK AT HIS UPLOADS AT PLANET-SOURCE-CODE.COM
'######################ATTENTION!######################

Option Explicit

'the following are for compression/decompression
Private Declare Sub CopyMemory Lib "kernel32" Alias "RtlMoveMemory" (hpvDest As Any, hpvSource As Any, ByVal cbCopy As Long)
Private Declare Function Compress Lib "zlib.dll" Alias "compress" (dest As Any, destLen As Any, src As Any, ByVal srcLen As Long) As Long
Private Declare Function compress2 Lib "zlib.dll" (dest As Any, destLen As Any, src As Any, ByVal srcLen As Long, ByVal level As Long) As Long
Private Declare Function uncompress Lib "zlib.dll" (dest As Any, destLen As Any, src As Any, ByVal srcLen As Long) As Long

'the following are for compression/decompression
Dim lngCompressedSize As Long
Dim lngDecompressedSize As Long

Enum CZErrors 'for compression/decompression
    Z_OK = 0
    Z_STREAM_END = 1
    Z_NEED_DICT = 2
    Z_ERRNO = -1
    Z_STREAM_ERROR = -2
    Z_DATA_ERROR = -3
    Z_MEM_ERROR = -4
    Z_BUF_ERROR = -5
    Z_VERSION_ERROR = -6
End Enum

Enum CompressionLevels 'for compression/decompression
    Z_NO_COMPRESSION = 0
    Z_BEST_SPEED = 1
    'note that levels 2-8 exist, too
    Z_BEST_COMPRESSION = 9
    Z_DEFAULT_COMPRESSION = -1
End Enum

Public Property Get ValueCompressedSize() As Long
    'size of an object after compression
    ValueCompressedSize = lngCompressedSize
End Property

Private Property Let ValueCompressedSize(ByVal New_ValueCompressedSize As Long)
    lngCompressedSize = New_ValueCompressedSize
End Property

Public Property Get ValueDecompressedSize() As Long
    'size of an object after decompression
    ValueDecompressedSize = lngDecompressedSize
End Property

Private Property Let ValueDecompressedSize(ByVal New_ValueDecompressedSize As Long)
    lngDecompressedSize = New_ValueDecompressedSize
End Property

Public Function CompressByteArray(TheData() As Byte, compressionLevel As Integer) As Long
    'compress a byte array
    Dim lngResult As Long
    Dim lngBufferSize As Long
    Dim arrByteArray() As Byte
    
    lngDecompressedSize = UBound(TheData) + 1
    
    'Allocate memory for byte array
    lngBufferSize = UBound(TheData) + 1
    lngBufferSize = lngBufferSize + (lngBufferSize * 0.01) + 12
    ReDim arrByteArray(lngBufferSize)
    
    'Compress byte array (data)
    lngResult = compress2(arrByteArray(0), lngBufferSize, TheData(0), UBound(TheData) + 1, compressionLevel)
    
    'Truncate to compressed size
    ReDim Preserve TheData(lngBufferSize - 1)
    CopyMemory TheData(0), arrByteArray(0), lngBufferSize
    
    'Set property
    lngCompressedSize = UBound(TheData) + 1
    
    'return error code (if any)
    CompressByteArray = lngResult
    
End Function

Public Function CompressString(Text As String, compressionLevel As Integer) As Long
    'compress a string
    Dim lngOrgSize As Long
    Dim lngReturnValue As Long
    Dim lngCmpSize As Long
    Dim strTBuff As String
    
    ValueDecompressedSize = Len(Text)
    
    'Allocate string space for the buffers
    lngOrgSize = Len(Text)
    strTBuff = String(lngOrgSize + (lngOrgSize * 0.01) + 12, 0)
    lngCmpSize = Len(strTBuff)
    
    'Compress string (temporary string buffer) data
    lngReturnValue = compress2(ByVal strTBuff, lngCmpSize, ByVal Text, Len(Text), compressionLevel)
    
    'Crop the string and set it to the actual string.
    Text = Left$(strTBuff, lngCmpSize)
    
    'Set compressed size of string.
    ValueCompressedSize = lngCmpSize
    
    'Cleanup
    strTBuff = ""
    
    'return error code (if any)
    CompressString = lngReturnValue

End Function

Public Function DecompressByteArray(TheData() As Byte, OriginalSize As Long) As Long
    'decompress a byte array
    Dim lngResult As Long
    Dim lngBufferSize As Long
    Dim arrByteArray() As Byte
    
    lngDecompressedSize = OriginalSize
    lngCompressedSize = UBound(TheData) + 1
    
    'Allocate memory for byte array
    lngBufferSize = OriginalSize
    lngBufferSize = lngBufferSize + (lngBufferSize * 0.01) + 12
    ReDim arrByteArray(lngBufferSize)
    
    'Decompress data
    lngResult = uncompress(arrByteArray(0), lngBufferSize, TheData(0), UBound(TheData) + 1)
    
    'Truncate buffer to compressed size
    ReDim Preserve TheData(lngBufferSize - 1)
    CopyMemory TheData(0), arrByteArray(0), lngBufferSize
    
    'return error code (if any)
    DecompressByteArray = lngResult
    
End Function

Public Function DecompressString(Text As String, OriginalSize As Long) As Long
    'decompress a string
    Dim lngResult As Long
    Dim lngCmpSize As Long
    Dim strTBuff As String
    
    'Allocate string space
    strTBuff = String(ValueDecompressedSize + (ValueDecompressedSize * 0.01) + 12, 0)
    lngCmpSize = Len(strTBuff)
    
    ValueDecompressedSize = OriginalSize
    
    'Decompress
    lngResult = uncompress(ByVal strTBuff, lngCmpSize, ByVal Text, Len(Text))
    
    'Make string the size of the uncompressed string
    Text = Left$(strTBuff, lngCmpSize)
    
    ValueCompressedSize = lngCmpSize
    
    'return error code (if any)
    DecompressString = lngResult
    
End Function
Public Function CompressFile(FilePathIn As String, FilePathOut As String, compressionLevel As Integer) As Long
    'compress a file
    Dim intNextFreeFile As Integer
    Dim TheBytes() As Byte
    Dim lngResult As Long
    Dim lngFileLen As Long
    
    lngFileLen = FileLen(FilePathIn)
    
    'allocate byte array
    ReDim TheBytes(lngFileLen - 1)
    
    'read byte array from file
    Close #10
    intNextFreeFile = FreeFile '10 'FreeFile
    Open FilePathIn For Binary Access Read As #intNextFreeFile
        Get #intNextFreeFile, , TheBytes()
    Close #intNextFreeFile
    
    'compress byte array
    lngResult = CompressByteArray(TheBytes(), compressionLevel)
    
    'kill any file in place
    On Error Resume Next
    Kill FilePathOut
    On Error GoTo 0
    
    'Write it out
    intNextFreeFile = FreeFile
    Open FilePathOut For Binary Access Write As #intNextFreeFile
        Put #intNextFreeFile, , lngFileLen 'must store the length of the original file
        Put #intNextFreeFile, , TheBytes()
    Close #intNextFreeFile
    
    Erase TheBytes
    CompressFile = lngResult
    
End Function

Public Function DecompressFile(FilePathIn As String, FilePathOut As String) As Long
    'decompress a file
    Dim intNextFreeFile As Integer
    Dim TheBytes() As Byte
    Dim lngResult As Long
    Dim lngFileLen As Long
    
    'allocate byte array
    ReDim TheBytes(FileLen(FilePathIn) - 1)
    
    'read byte array from file
    intNextFreeFile = FreeFile
    Open FilePathIn For Binary Access Read As #intNextFreeFile
        Get #intNextFreeFile, , lngFileLen 'the original (uncompressed) file's length
        Get #intNextFreeFile, , TheBytes()
    Close #intNextFreeFile
    
    'decompress
    lngResult = DecompressByteArray(TheBytes(), lngFileLen)
    'kill any file already there
    On Error Resume Next
    Kill FilePathOut
    On Error GoTo 0
    
    'Write it out
    intNextFreeFile = FreeFile
    Open FilePathOut For Binary Access Write As #intNextFreeFile
        Put #intNextFreeFile, , TheBytes()
    Close #intNextFreeFile
    
    Erase TheBytes
    DecompressFile = lngResult

End Function

' --------------------------------------------------------
' The following functions were written by:
'
' Sean Ferguson
' PCSCT Software
' http://www.pcsct.com
' Copyright � 2001 PCSCT Software. All rights reserved.


' This function compresses all the files in a listbox and combines them into one file

Public Function CompressFiles(fileList As ListBox, baseTempDir As String, destFile As String, compressionLevel As CompressionLevels, Optional baseDir As String)
Dim FileNum As Integer
Dim tempDir As String
On Error Resume Next
tempDir = TrimSlash(baseTempDir) & "\TMP" & Format(Time(), "hhmmss")
MkDir tempDir
For FileNum = 0 To fileList.ListCount - 1
CompressFile fileList.List(FileNum), tempDir & "\" & getFileName(fileList.List(FileNum)), CInt(compressionLevel)
AddFileToArchive destFile, tempDir & "\" & getFileName(fileList.List(FileNum)), getFilePath(fileList.List(FileNum), baseDir)
Kill tempDir & "\" & getFileName(fileList.List(FileNum))
Next FileNum
RmDir tempDir
End Function

' This function removes the base directory from the file name

Private Function getFilePath(fullFileName As String, baseDir As String) As String
If baseDir = "" Then
    getFilePath = getFileName(fullFileName)
Else
    baseDir = TrimSlash(baseDir)
    Dim X As Integer
    For X = 1 To Len(fullFileName)
        If Mid$(LCase(fullFileName), CLng(X), Len(baseDir)) = LCase(baseDir) Then
            baseDir = Mid(fullFileName, X, Len(baseDir))
            getFilePath = Replace(fullFileName, baseDir & "\", "")
            Exit Function
        End If
    Next X
    getFilePath = getFileName(fullFileName)
End If
End Function

' This function decompresses all files in a compressed file that were compressed using the CompressFiles function

Public Function DeCompressFiles(czFile As String, destDir As String, baseTempDir As String)
On Error Resume Next
Dim tempDir As String
tempDir = TrimSlash(baseTempDir) & "\TMPX" & Format(Time(), "hhmmss")
MkDir tempDir
ExtractFilesFromArchive czFile, destDir, , False, True, tempDir
RmDir tempDir
End Function

' This functions trims the back-slash of the end of a path

Private Function TrimSlash(strTrim As String) As String
If Right(strTrim, 1) = "\" Then
    TrimSlash = Mid(strTrim, 1, Len(strTrim) - 1)
Else
    TrimSlash = strTrim
End If
End Function

' This function extracts the filename from a full path name

Private Function getFileName(strFilePath As String) As String
getFileName = Mid(strFilePath, InStrRev(strFilePath, "\") + 1)
End Function

' This function adds a file to a single archive of files
' --------------------------------------------------------
' Main Coding taken from CyberCrypt 6.0 by Pre-Instinct Software
' Copyright � 2001 Pre-Instinct Software. All rights reserved.

Public Function AddFileToArchive(destFile As String, fileName As String, cFN As String)
    Dim BytesADD As String
    Dim OffSetADD As Long
    Dim SizeADD As Long
    Dim fileNumber As Variant
    Dim fileList As String
    Dim fileListStart As Long
    Dim FileNumberADD As Variant
    Dim Position As Variant
    Dim FileBytes() As Byte
    
    cFN = cFN & Chr$(0)
    
    CreateArchive destFile
    If FileExists(fileName) = False Then Exit Function
    
    Close #1
            
    fileNumber = 1
    Open destFile For Binary As #fileNumber

    Get fileNumber, 7, fileListStart
    
    If fileListStart = 0 Then
        fileListStart = LOF(fileNumber) + 1
        fileList = ""
    Else
        fileList = String(LOF(fileNumber) - fileListStart + 1, Chr$(0))
        Get fileNumber, fileListStart, fileList
    End If
    
    OffSetADD = fileListStart
    SizeADD = FileLen(fileName)
    Close #2
    
    FileNumberADD = 2
    
    Open fileName For Binary As #FileNumberADD
        If LOF(FileNumberADD) > 1000000 Then
        Position = -999999
            Do
                Position = Position + 1000000
                If Position + 999999 > LOF(FileNumberADD) Then
                    BytesADD = String(LOF(FileNumberADD) - Position + 1, Chr$(0))
                Else
                    BytesADD = String(1000000, Chr$(0))
                End If
                Get FileNumberADD, Position, BytesADD
                Put fileNumber, fileListStart, BytesADD
                fileListStart = fileListStart + Len(BytesADD)
            Loop Until Position + 999999 > LOF(FileNumberADD)
        Else
            BytesADD = String(LOF(FileNumberADD), Chr$(0))
            Get FileNumberADD, 1, BytesADD
            Put fileNumber, fileListStart, BytesADD
            fileListStart = fileListStart + Len(BytesADD)
        End If
    Close FileNumberADD

    Put fileNumber, 7, fileListStart
    Put fileNumber, fileListStart, fileList
    Put fileNumber, fileListStart + Len(fileList), OffSetADD
    Put fileNumber, fileListStart + Len(fileList) + 4, SizeADD
    Put fileNumber, fileListStart + Len(fileList) + 8, cFN
    Close fileNumber
    Close FileNumberADD
End Function

' This function creates a new archive file
' --------------------------------------------------------
' Main Coding taken from CyberCrypt 6.0 by Pre-Instinct Software
' Copyright � 2001 Pre-Instinct Software. All rights reserved.

Public Function CreateArchive(fileName As String)
On Error GoTo createFile
If FileExists(fileName) = True Then Exit Function

createFile:
Dim fileListStart As Long
Dim fileNumber As Variant
Dim Header As String
fileListStart = 0
Header = "CZP_A"
fileNumber = FreeFile
Close #fileNumber
Open fileName For Binary As #fileNumber
    Put #fileNumber, 1, Header
    Put #fileNumber, 7, fileListStart
Close #fileNumber
End Function

' This function extracts one or all files from a file archive
' --------------------------------------------------------
' Main Coding taken from CyberCrypt 6.0 by Pre-Instinct Software
' Copyright � 2001 Pre-Instinct Software. All rights reserved.

Public Function ExtractFilesFromArchive(czFile As String, DestinationFileDir As String, Optional FileToExtract As String = "", Optional Overwrite As Boolean, Optional Decompress As Boolean, Optional tmpDecompressDir As String)
    
    On Error GoTo handleError
    
    If FileExists(czFile) = False Then Exit Function
    If Overwrite = True And FileToExtract <> "" And FileExists(DestinationFileDir) = True Then Exit Function
    
    Dim fileName As String
    Dim FileNum As Integer
    Dim fileNumber As Integer
    Dim FileBytes() As Byte
    Dim BytesExtract As String
    Dim Offset As Long
    Dim Size As Long
    Dim Name As String
    Dim DestinationNumber As Integer
    Dim DestinationFile As String
    Dim fileListStart As Long
    Dim Position As Long
    
            Close #4
            fileNumber = 4
            Open czFile For Binary As #fileNumber
                
                Get fileNumber, 7, fileListStart
            
                If fileListStart = 0 Then
                    Close fileNumber
                    Exit Function
                Else
                    
    
                    Do
                        Get fileNumber, fileListStart, Offset
                        fileListStart = fileListStart + 4
                    
                        Get fileNumber, fileListStart, Size
                        fileListStart = fileListStart + 4
                                       
                        Name = String$(255, Chr$(0))
                        Get fileNumber, fileListStart, Name
                        Name = Mid(Name, 1, InStr(1, Name, Chr$(0)) - 1)
                        fileListStart = fileListStart + Len(Name) + 1
                        
                        frmMain.lblStatus.Caption = "Extracting " & UCase(Name) & "..."
                    
                        If Name = "" Or Offset = 0 Or Size = 0 Then
                            Close fileNumber
                            Exit Function
                        ElseIf (LCase(Name) = LCase(FileToExtract)) Or (FileToExtract = "") Then
                            Close #5
                            DestinationNumber = 5
                            If FileToExtract <> "" Then
                                DestinationFile = DestinationFileDir
                            Else
                                DestinationFile = TrimSlash(DestinationFileDir & "\" & Name)
                                CheckPath DestinationFile
                            End If
                            If Decompress = True Then
                                DestinationFile = TrimSlash(tmpDecompressDir) & "\" & getFileName(Name)
                            End If
                            Open DestinationFile For Binary As #DestinationNumber
                                If Size > 100000 Then
                                    
                                    Position = -1000000
                                    Do
                                        
                                        Position = Position + 1000000
                                        If Position + 999999 > Size Then
                                            BytesExtract = String(Size - Position, Chr$(0))
                                        Else
                                            BytesExtract = String(1000000, Chr$(0))
                                        End If
                                        Get fileNumber, Position + Offset, BytesExtract
                                        Put DestinationNumber, Position + 1, BytesExtract
                                    Loop Until Position + 999999 >= Size
                                Else
                                    BytesExtract = String(Size, Chr$(0))
                                    Get fileNumber, Offset, BytesExtract
                                    Put DestinationNumber, 1, BytesExtract
                                End If
                            Close DestinationNumber
                            If Decompress = True Then
                                DecompressFile DestinationFile, TrimSlash(DestinationFileDir & "\" & Name)
                                Kill DestinationFile
                            End If
                            If FileToExtract <> "" Then Exit Function
                        End If
                    Loop Until fileListStart > LOF(fileNumber)
                End If
            Close fileNumber
    Exit Function

handleError:
On Error GoTo exitFunction
If Decompress = True Then Kill DestinationFile

exitFunction:
Exit Function
End Function

' This function checks whether a file exists or not
' --------------------------------------------------------
' Main Coding taken from CyberCrypt 6.0 by Pre-Instinct Software
' Copyright � 2001 Pre-Instinct Software. All rights reserved.

Private Function FileExists(fileName As String) As Boolean
On Error GoTo handleError
If FileLen(fileName) > 0 Then
    FileExists = True
Else
    FileExists = False
End If
Exit Function

handleError:
FileExists = False
Exit Function
End Function

' This function checks whether each folder in a file path
' exists or not and creates the non-existing ones

Private Function CheckPath(pathCheck As String)
On Error Resume Next
Dim X As Integer
Dim pathName As String
Dim pathVars
pathVars = Split(pathCheck, "\")
pathName = pathVars(0)
For X = (LBound(pathVars) + 1) To (UBound(pathVars) - 1)
pathName = pathName & "\" & pathVars(X)
If Dir(pathName, vbDirectory) = "" Then
    MkDir pathName
End If
Next X
End Function

