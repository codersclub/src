Attribute VB_Name = "supportData"
Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Declare Function WritePrivateProfileString& Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal appName$, ByVal KeyName$, ByVal keydefault$, ByVal fileName$)

Public extractionDirectory As String
Public iniFile As String
Public splashScreen As Boolean
Public tmrAction As Integer
Public timerExecute As Boolean
Public appName As String
Public appVersion As String
Public appPassword As String
Public pEC As String
Public passCorrect As Boolean
Public extractionProgress As PGBar
Public exitPause As Boolean

Public Function ReadDataFile(fileName As String) As Variant
On Error GoTo handleError
Dim fileData() As String
Dim ln As Integer
ln = -1
Open fileName For Input As #5
Do Until (EOF(5))
ln = ln + 1
ReDim Preserve fileData(ln) As String
Input #5, fileData(ln)
Loop
Close #5
ReadDataFile = fileData
Exit Function

handleError:
ReDim Preserve fileData(0) As String
ReDim Preserve fileData(1) As String
ReDim Preserve fileData(2) As String
Close #5
fileData(0) = "ERROR"
fileData(1) = Err.Description
fileData(2) = Err.Number
ReadDataFile = fileData
End Function

Public Function Pause(ByVal Interval As Integer)
frmMain.tmrWait.Interval = Interval * 1000
tmrAction = 0
timerExecute = False
frmMain.tmrWait.Enabled = True
Do Until timerExecute = True
    DoEvents
Loop
End Function

Public Function GetINIString(ByVal fileName As String, ByVal Section As String, ByVal Key As String)
    Dim ReturnValue As String
    Dim Successful As Integer
    ReturnValue = String$(255, 0)
    Successful = GetPrivateProfileString(Section, Key, "", ReturnValue, Len(ReturnValue), fileName)
    If Successful = 0 Then
        GetINIString = ""
    Else
        GetINIString = Left(ReturnValue, InStr(ReturnValue, Chr(0)) - 1)
    End If
End Function

Public Function WriteINIString(ByVal fileName As String, ByVal Section As String, ByVal Key As String, ByVal Value As String)
WritePrivateProfileString Section, Key, Value, fileName
End Function

Public Function GetPass(iPass As String, iPEC As String)
appPassword = iPass
pEC = iPEC
frmGetPass.Show
Do Until (frmGetPass.Visible = False)
    DoEvents
Loop
If passCorrect = False Then
    mDeleteFolder extractionDirectory
    End
End If
End Function

Public Function timedPause(secs As Long)
    Dim secStart As Variant
    Dim secNow As Variant
    Dim secDiff As Variant
    Dim temp%
    exitPause = False
    secStart = Format(Now(), "mm/dd/yyyy hh:nn:ss AM/PM")
    
    Do While secDiff < secs
        If exitPause = True Then Exit Do
         secNow = Format(Now(), "mm/dd/yyyy hh:nn:ss AM/PM")
        secDiff = DateDiff("s", secStart, secNow)
        temp% = DoEvents
    Loop
End Function

Public Function ShellAndWait(fileName As String, iWindowState As Integer)
On Error GoTo ERR_OpenForEdit
    
Dim objScript
Dim shellapp

Set objScript = CreateObject("WScript.Shell")

shellapp = objScript.Run(fileName, iWindowState, True)
ShellAndWait = True

EXIT_OpenForEdit:
    Exit Function

ERR_OpenForEdit:
    MsgBox Err.Description
        
End Function
