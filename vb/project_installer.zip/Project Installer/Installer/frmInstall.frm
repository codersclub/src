VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Begin VB.Form frmInstall 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "<AppName> Setup"
   ClientHeight    =   4470
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7350
   Icon            =   "frmInstall.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   4470
   ScaleWidth      =   7350
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdExit 
      Caption         =   "E&xit Setup"
      Height          =   425
      Left            =   120
      TabIndex        =   22
      Top             =   3360
      Width           =   1455
   End
   Begin VB.Frame Install 
      Caption         =   "Installing <AppName>"
      Height          =   3135
      Index           =   3
      Left            =   120
      TabIndex        =   14
      Top             =   120
      Visible         =   0   'False
      Width           =   7095
      Begin VB.FileListBox fileCopyList 
         Height          =   285
         Hidden          =   -1  'True
         Left            =   480
         System          =   -1  'True
         TabIndex        =   21
         Top             =   2640
         Visible         =   0   'False
         Width           =   2415
      End
      Begin MSComctlLib.ProgressBar Install4_copyProgress 
         Height          =   325
         Left            =   480
         TabIndex        =   20
         Top             =   1680
         Width           =   6135
         _ExtentX        =   10821
         _ExtentY        =   582
         _Version        =   393216
         Appearance      =   1
         Scrolling       =   1
      End
      Begin VB.Label Install4_DestinationFile 
         Height          =   255
         Left            =   1800
         TabIndex        =   19
         Top             =   1200
         Width           =   4935
      End
      Begin VB.Label Install4_SourceFile 
         Height          =   255
         Left            =   1800
         TabIndex        =   18
         Top             =   840
         Width           =   4935
      End
      Begin VB.Label Install4_lblDestination 
         Alignment       =   1  'Right Justify
         Caption         =   "Destination File:"
         Height          =   255
         Left            =   360
         TabIndex        =   17
         Top             =   1200
         Width           =   1215
      End
      Begin VB.Label Install4_lblSource 
         Alignment       =   1  'Right Justify
         Caption         =   "Source File:"
         Height          =   255
         Left            =   360
         TabIndex        =   16
         Top             =   840
         Width           =   1215
      End
      Begin VB.Label Install4_UserMessage 
         Caption         =   "Please wait while <AppName> Setup copies files...."
         Height          =   255
         Left            =   240
         TabIndex        =   15
         Top             =   360
         Width           =   6495
      End
   End
   Begin VB.Frame Install 
      Caption         =   "Ready to Install"
      Height          =   3135
      Index           =   2
      Left            =   120
      TabIndex        =   12
      Top             =   120
      Visible         =   0   'False
      Width           =   7095
      Begin VB.Label Install3_ReadyToInstall 
         Caption         =   $"frmInstall.frx":1272
         Height          =   615
         Left            =   240
         TabIndex        =   13
         Top             =   360
         Width           =   6615
      End
   End
   Begin VB.Frame Install 
      Caption         =   "Choose Installation Directory"
      Height          =   3135
      Index           =   1
      Left            =   120
      TabIndex        =   6
      Top             =   120
      Visible         =   0   'False
      Width           =   7095
      Begin VB.Frame Frame1 
         Height          =   615
         Left            =   240
         TabIndex        =   7
         Top             =   1150
         Width           =   6615
         Begin VB.CommandButton Install1_Browse 
            Caption         =   "&Browse..."
            Height          =   375
            Left            =   5280
            TabIndex        =   8
            Top             =   170
            Width           =   1215
         End
         Begin VB.Label Install1_InstallDir 
            Caption         =   "INSTALL_DIR"
            Height          =   255
            Left            =   120
            TabIndex        =   9
            Top             =   240
            Width           =   5055
         End
      End
      Begin VB.Label Install1_ChooseDir 
         Caption         =   "Please choose the directory in which <AppName> is to be installed to, or use the current setting."
         Height          =   495
         Left            =   240
         TabIndex        =   11
         Top             =   360
         Width           =   6615
      End
      Begin VB.Label Label1 
         Caption         =   "  Installation Directory:"
         Height          =   255
         Left            =   240
         TabIndex        =   10
         Top             =   960
         Width           =   3255
      End
   End
   Begin VB.Frame Install 
      Caption         =   "<AppName> Installer"
      Height          =   3135
      Index           =   0
      Left            =   120
      TabIndex        =   4
      Top             =   120
      Width           =   7095
      Begin VB.Label Install0_Welcome 
         Caption         =   "Welcome to <AppName> Setup! This program will install <AppName> on your computer. Click Next to begin the installation process."
         Height          =   735
         Left            =   240
         TabIndex        =   5
         Top             =   480
         Width           =   6615
      End
   End
   Begin VB.CommandButton cmdNext 
      Caption         =   "&Next"
      Default         =   -1  'True
      Height          =   425
      Left            =   6000
      TabIndex        =   3
      Top             =   3360
      Width           =   1215
   End
   Begin VB.CommandButton cmdBack 
      Caption         =   "&Back"
      Enabled         =   0   'False
      Height          =   425
      Left            =   4800
      TabIndex        =   2
      Top             =   3360
      Width           =   1215
   End
   Begin VB.Label lblCopyright 
      Alignment       =   1  'Right Justify
      Caption         =   "Copyright � 2001 PCSCT Software. All rights reserved. "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   3240
      TabIndex        =   1
      Top             =   4200
      Width           =   4095
   End
   Begin VB.Label lblInstaller 
      Alignment       =   1  'Right Justify
      Caption         =   "<AppName> <AppVersion> Setup  "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   3960
      Width           =   7095
   End
End
Attribute VB_Name = "frmInstall"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private currentFrame As Integer
Private shellLink As New cShellLink

Private Sub cmdBack_Click()
FrameNavigate -1
End Sub

Private Sub cmdExit_Click()
If MsgBox("Are you sure you want to cancel Setup?", vbYesNo + vbQuestion, "Exit") = vbYes Then
    RemoveTemporaryFiles
    Unload Me
    End
End If
End Sub

Private Sub cmdNext_Click()
FrameNavigate 1
End Sub

Private Sub Form_Load()

frmMain.Hide
If splashScreen = True Then Unload frmSplashImage

appVersion = GetINIString(iniFile, "Install", "AppVersion")
Me.Caption = Replace(Me.Caption, "<AppName>", appName)
lblInstaller.Caption = Replace(lblInstaller.Caption, "<AppName>", appName)
lblInstaller.Caption = Replace(lblInstaller.Caption, "<AppVersion>", appVersion)
Install(0).Caption = Replace(Install(0).Caption, "<AppName>", appName)
Install0_Welcome.Caption = Replace(Install0_Welcome.Caption, "<AppName>", appName)
Install1_ChooseDir.Caption = Replace(Install1_ChooseDir.Caption, "<AppName>", appName)
Install1_InstallDir.Caption = GetSettingString(HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion", "ProgramFilesDir") & "\" & appName
Load frmBrowse
frmBrowse.folderList.Path = GetSettingString(HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion", "ProgramFilesDir")
frmBrowse.installDir.Text = frmBrowse.folderList.Path & "\" & appName
Install3_ReadyToInstall.Caption = Replace(Install3_ReadyToInstall.Caption, "<AppName>", appName)
Install(3).Caption = Replace(Install(3).Caption, "<AppName>", appName)
Install4_UserMessage.Caption = Replace(Install4_UserMessage.Caption, "<AppName>", appName)
currentFrame = 0

regRtn = GetSettingString(HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion, "InstallDir")
If regRtn <> "ERROR" And regRtn <> "" Then
    If MsgBox(appName & " Setup has detected a previous installation of " & appName & ". Do you wish to continue?", vbYesNo + vbInformation, "Previous Installation") = vbNo Then
        RemoveTemporaryFiles
        Unload Me
        End
    End If
End If
End Sub

Private Sub FrameNavigate(direction As Integer)
If CheckValues(currentFrame) = False Then Exit Sub
Install(currentFrame).Visible = False
Install(currentFrame + direction).Visible = True
currentFrame = currentFrame + direction
If currentFrame = 0 Then cmdBack.Enabled = False Else cmdBack.Enabled = True
If currentFrame >= 2 Then cmdNext.Caption = "&Install" Else cmdNext.Caption = "&Next"
If currentFrame = 3 Then BeginInstallation
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

Private Sub Install1_Browse_Click()
frmBrowse.Show , Me
End Sub

Private Function CheckValues(frameNum As Integer) As Boolean
If frameNum = 1 Then
    If Install1_InstallDir.Caption = "" Then
        MsgBox "You must select a directory to install the program to."
        CheckValues = False
        Exit Function
    End If
End If
CheckValues = True
End Function

Private Sub BeginInstallation()
On Error Resume Next
cmdExit.Enabled = False
cmdBack.Enabled = False
cmdNext.Enabled = False
Dim X As Integer
Dim sFile As String
Dim dFile As String
cmdExit.Enabled = False
mCheckPathFolders Install1_InstallDir.Caption
filesToCopy = ReadDataFile(extractionDirectory & "\flist.dat")
Install4_copyProgress.Max = UBound(filesToCopy) + 1
For X = LBound(filesToCopy) To UBound(filesToCopy)
Install4_copyProgress.Value = X + 1
fileInfo = Split(filesToCopy(X), "||")
sFile = extractionDirectory & "\files\" & fileInfo(0)
dFile = fileInfo(1) & "\" & fileInfo(0)
dFile = Replace(dFile, "<AppPath>", Install1_InstallDir.Caption)
dFile = Replace(dFile, "<SysDir>", SysDir(False))
dFile = Replace(dFile, "<WinDir>", WinDir(False))
Install4_SourceFile.Caption = sFile
Install4_DestinationFile.Caption = dFile
mCopyFile sFile, Mid(dFile, 1, InStrRev(dFile, "\") - 1), True
Next X
mCopyFile extractionDirectory & "\flist.dat", Install1_InstallDir.Caption & "\Un_Files.dat", True
mCopyFile extractionDirectory & "\regentries.dat", Install1_InstallDir.Caption & "\Un_Reg.dat", True
mCopyFile extractionDirectory & "\iconlist.dat", Install1_InstallDir.Caption & "\Un_Icon.dat", True
Install4_SourceFile.Visible = False
Install4_DestinationFile.Visible = False
Install4_lblSource.Visible = False
Install4_lblDestination.Visible = False
timedPause 1
Install4_UserMessage.Caption = "File copy process complete."
timedPause 1
Install4_UserMessage.Caption = "Registering libraries..."
Install4_SourceFile.Caption = ""
Install4_lblSource.Caption = "Registering File:"
Install4_SourceFile.Visible = True
Install4_lblSource.Visible = True
fileCopyList.Pattern = "*.ocx;*.dll;*.ole"
fileCopyList.Path = extractionDirectory & "\files"
Install4_copyProgress.Value = 0
Install4_copyProgress.Max = fileCopyList.ListCount
For X = 0 To fileCopyList.ListCount
Install4_copyProgress.Max = X + 1
Install4_SourceFile.Caption = SysDir(True) & fileCopyList.List(X)
RegUnReg SysDir(True) & fileCopyList.List(X)
Next X
Install4_SourceFile.Visible = False
Install4_lblSource.Visible = False
timedPause 1
Install4_UserMessage.Caption = "Libraries registered."
timedPause 1
Install4_UserMessage.Caption = "Creating registry entries..."
Install4_copyProgress.Value = 0
regEntries = ReadDataFile(extractionDirectory & "\regentries.dat")
Install4_copyProgress.Max = UBound(regEntries) + 1
For X = LBound(regEntries) To UBound(regEntries)
Install4_copyProgress.Value = X + 1
entryData = Split(regEntries(X), "||")
If entryData(0) = "HKEY_CLASSES_ROOT" Then
    HKEYString = HKEY_CLASSES_ROOT
ElseIf entryData(0) = "HKEY_CURRENT_USER" Then
    HKEYString = HKEY_CURRENT_USER
ElseIf entryData(0) = "HKEY_LOCAL_MACHINE" Then
    HKEYString = HKEY_LOCAL_MACHINE
ElseIf entryData(0) = "HKEY_USERS" Then
    HKEYString = HKEY_USERS
ElseIf entryData(0) = "HKEY_PERFORMANCE_DATA" Then
    HKEYString = HKEY_PERFORMANCE_DATA
ElseIf entryData(0) = "HKEY_CURRENT_CONFIG" Then
    HKEYString = HKEY_CURRENT_CONFIG
ElseIf entryData(0) = "HKEY_DYN_DATA" Then
    HKEYString = HKEY_DYN_DATA
End If
SaveSettingString CLng(HKEYString), CStr(entryData(1)), CStr(entryData(2)), CStr(entryData(3))
Next X
Install4_UserMessage.Caption = "Registry entries created."
timedPause 1
Install4_UserMessage.Caption = "Creating Program Icons..."
Install4_copyProgress.Value = 0
iconList = ReadDataFile(extractionDirectory & "\iconlist.dat")
Install4_copyProgress.Max = UBound(iconList) + 1
For X = LBound(iconList) To UBound(iconList)
Install4_copyProgress.Value = X + 1
iconInfo = Split(iconList(X), "||")
iconInfo(3) = Replace(iconInfo(3), "<AppPath>", Install1_InstallDir.Caption)
iconInfo(3) = Replace(iconInfo(3), "<SysDir>", SysDir(False))
iconInfo(3) = Replace(iconInfo(3), "<WinDir>", WinDir(False))
If iconInfo(0) = "Desktop" Then
    Dim dFolder As String
    dFolder = GetSettingString(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Desktop")
    shellLink.CreateShellLink dFolder & "\" & iconInfo(2) & ".lnk", CStr(iconInfo(3)), mGetDir(iconInfo(3)), vbNullString, CStr(iconInfo(3)), 0, SHOWNORMAL
Else
    Dim sFolder As String
    sFolder = GetSettingString(HKEY_CURRENT_USER, "Software\Microsoft\Windows\CurrentVersion\Explorer\Shell Folders", "Programs")
    If iconInfo(1) <> "" Then sFolder = sFolder & "\" & iconInfo(1)
    fExists = mFolderExists(sFolder)
    fExists = CBool(fExists)
    If fExists = False Then mCreateFolder sFolder
    shellLink.CreateShellLink sFolder & "\" & iconInfo(2) & ".lnk", CStr(iconInfo(3)), mGetDir(iconInfo(3)), vbNullString, CStr(iconInfo(3)), 0, SHOWNORMAL
End If
Next X
timedPause 1
Install4_UserMessage.Caption = "Copying Uninstaller..."
mCopyFile extractionDirectory & "\files\PCSUNINS.EXE", WinDir(False) & "\PCSUNINS.EXE", True
timedPause 1
Install4_UserMessage.Caption = "Writing Uninstall Data to Registry..."
Dim runBeforeUninst As String
runBeforeUninst = GetINIString(iniFile, "Install", "RunBeforeUninst")
If execBeforeUninst <> "" Then
    execBeforeUninst = Replace(execBeforeUninst, "<AppPath>", Install1_InstallDir.Caption)
    execBeforeUninst = Replace(execBeforeUninst, "<SysDir>", SysDir(False))
    execBeforeUninst = Replace(execBeforeUninst, "<WinDir>", WinDir(False))
End If
SaveSettingString HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion, "InstallDir", Install1_InstallDir.Caption
SaveSettingString HKEY_LOCAL_MACHINE, "Software\PCSCT Software\ProjectUninstaller\Apps\" & appName & "\" & appVersion, "RunBeforeUninst", CStr(runBeforeUninst)
SaveSettingString HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion\Uninstall\" & appName, "DisplayName", appName
SaveSettingString HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion\Uninstall\" & appName, "UninstallString", WinDir(False) & "\PCSUNINS.EXE " & appName & ",," & appVersion
timedPause 1
Install4_UserMessage.Caption = "Removing Temporary Files..."
Dim aIEFile As String
aIEFile = GetINIString(iniFile, "Install", "RunAfterInstall")
RemoveTemporaryFiles
timedPause 1
Install4_UserMessage.Caption = "Installation complete!"
timedPause 1
MsgBox appName & " Setup has completed installation. Click OK to exit the installer.", vbOKOnly + vbInformation, "Complete"
If aIEFile <> "" Then
    aIEFile = Replace(aIEFile, "<AppPath>", Install1_InstallDir.Caption)
    aIEFile = Replace(aIEFile, "<SysDir>", SysDir(False))
    aIEFile = Replace(aIEFile, "<WinDir>", WinDir(False))
    Shell aIEFile, vbNormalFocus
End If
End
End Sub

Private Sub RemoveTemporaryFiles()
mEmptyFolder extractionDirectory & "\files"
mDeleteFolder extractionDirectory & "\files"
mEmptyFolder extractionDirectory
mDeleteFolder extractionDirectory
End Sub
