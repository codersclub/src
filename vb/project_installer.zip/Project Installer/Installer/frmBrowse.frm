VERSION 5.00
Begin VB.Form frmBrowse 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Installation Directory - Browse"
   ClientHeight    =   5100
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5655
   Icon            =   "frmBrowse.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5100
   ScaleWidth      =   5655
   StartUpPosition =   2  'CenterScreen
   Visible         =   0   'False
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2880
      TabIndex        =   4
      Top             =   4680
      Width           =   2535
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   240
      TabIndex        =   3
      Top             =   4680
      Width           =   2535
   End
   Begin VB.CommandButton cmdNewFolder 
      Caption         =   "&Create New Folder"
      Height          =   375
      Left            =   240
      TabIndex        =   2
      Top             =   4200
      Width           =   5175
   End
   Begin VB.DirListBox folderList 
      Height          =   3690
      Left            =   240
      TabIndex        =   1
      Top             =   480
      Width           =   5175
   End
   Begin VB.DriveListBox driveList 
      Height          =   315
      Left            =   240
      TabIndex        =   0
      Top             =   120
      Width           =   5175
   End
   Begin VB.TextBox installDir 
      Height          =   375
      Left            =   240
      Locked          =   -1  'True
      TabIndex        =   5
      Top             =   4200
      Width           =   5175
   End
End
Attribute VB_Name = "frmBrowse"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
Me.Hide
End Sub

Private Sub cmdNewFolder_Click()
newFolderName = InputBox("Please enter a name for the new folder:", "New Folder")
If newFolderName = "" Then Exit Sub
mCreateFolder folderList.Path & "\" & newFolderName
folderList.Refresh
folderList.Path = folderList.Path & "\" & newFolderName
End Sub

Private Sub cmdOK_Click()
frmInstall.Install1_InstallDir.Caption = installDir.Text
Unload Me
End Sub

Private Sub driveList_Change()
folderList.Path = driveList.Drive
folderList.Refresh
End Sub

Private Sub folderList_Change()
installDir.Text = folderList.Path
End Sub

Private Sub Form_Load()
On Error Resume Next
folderList.Path = GetSettingString(HKEY_LOCAL_MACHINE, "Software\Microsoft\Windows\CurrentVersion", "ProgramFilesDir")
folderList.Path = frmInstall.Install1_InstallDir.Caption
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

Private Sub installDir_Change()
installDir.SelStart = Len(installDir.Text)
End Sub

Private Function GetItemIndex(listBox As FileListBox, itemName As String) As Integer
For X = 0 To listBox.ListCount - 1
    If LCase(listBox.List(X)) = LCase(itemName) Then GetItemIndex = X: Exit Function
Next X
GetItemIndex = -1
End Function
