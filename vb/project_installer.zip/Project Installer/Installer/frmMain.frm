VERSION 5.00
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Setup"
   ClientHeight    =   1665
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5715
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   111
   ScaleMode       =   3  'Pixel
   ScaleWidth      =   381
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer tmrWait 
      Enabled         =   0   'False
      Interval        =   2000
      Left            =   6960
      Top             =   120
   End
   Begin VB.Shape pgBarForeground 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H80000002&
      FillStyle       =   0  'Solid
      Height          =   255
      Left            =   1395
      Top             =   900
      Visible         =   0   'False
      Width           =   15
   End
   Begin VB.Shape pgBarBackground 
      BorderStyle     =   0  'Transparent
      FillColor       =   &H8000000F&
      Height          =   255
      Left            =   1395
      Top             =   900
      Width           =   4095
   End
   Begin VB.Label lblStatus 
      Alignment       =   2  'Center
      Caption         =   "Preparing to extract files..."
      ForeColor       =   &H00000000&
      Height          =   255
      Left            =   1320
      TabIndex        =   1
      Top             =   1320
      Width           =   4215
   End
   Begin VB.Image Image1 
      Height          =   840
      Left            =   120
      Picture         =   "frmMain.frx":1272
      Stretch         =   -1  'True
      Top             =   360
      Width           =   840
   End
   Begin VB.Label lblMessage 
      Caption         =   "Please wait while Setup prepares files for installation..."
      Height          =   555
      Left            =   1320
      TabIndex        =   0
      Top             =   240
      Width           =   4305
   End
   Begin VB.Label Label1 
      BorderStyle     =   1  'Fixed Single
      Height          =   360
      Left            =   1320
      TabIndex        =   2
      Top             =   840
      Width           =   4245
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub InitializeInstall()
iniFile = extractionDirectory & "\Setup.ini"
appName = GetINIString(iniFile, "Install", "AppName")
Me.Caption = Replace(Me.Caption, "Setup", appName & " Setup")
lblMessage.Caption = Replace(lblMessage.Caption, "Setup", appName & " Setup")
If GetINIString(iniFile, "Install", "ShowSplash") = "1" Then
    splashScreen = True
    Load frmSplashImage
    picFile = GetINIString(iniFile, "Install", "SplashFile")
    frmSplashImage.splashImage.Picture = LoadPicture(extractionDirectory & "\" & picFile)
    frmSplashImage.splashImage.Refresh
    frmSplashImage.Height = frmSplashImage.splashImage.Height
    frmSplashImage.Width = frmSplashImage.splashImage.Width
    frmSplashImage.Show
    Me.Top = Screen.Height - Me.Height - 100
    Me.Left = Screen.Width - Me.Width - 100
    Me.SetFocus
End If
ExtractZIP
End Sub

Private Sub ExtractFiles()
mCreateFolder extractionDirectory
lblStatus.Caption = "Copying Installer..."
mCopyFile selfExtractEXE, extractionDirectory & "\InstallEXE.exe", True
selfExtractEXE = extractionDirectory & "\InstallEXE.exe"
On Error GoTo handleError
Dim rPass As String
Dim rEC As String
Dim iFiles As String
Dim iName As String
Dim Size As String
iFreeFile = FreeFile
curPOS = 0
i = 0
Open selfExtractEXE For Input As iFreeFile
Close iFreeFile
iFreeFile = FreeFile
Open selfExtractEXE For Binary As iFreeFile
    
    Seek #iFreeFile, LOF(iFreeFile) - 6 - (256 * 2)
    iFiles = String(5, Chr(0))
    Get iFreeFile, , iFiles
    
    Seek #iFreeFile, LOF(iFreeFile) - (256 * 2)
    rPass = String(255, Chr(0))
    Get iFreeFile, , rPass
    
    Close iFreeFile
    
    iFiles = Replace$(iFiles, vbCr, "")
    iFilez = Val(iFiles)
    rPass = Replace(rPass, vbTab, "")
    
    If rPass <> "" Then
        rPassData = Split(rPass, "/|::|\")
        GetPass CStr(rPassData(0)), CStr(rPassData(1))
    End If

    Do
    i = i + 1
    Open selfExtractEXE For Binary As iFreeFile

    Seek #iFreeFile, LOF(iFreeFile) - (256 * 2) - 5 - 41 - 10 + curPOS
    iName = String(40, Chr(0))
    Get iFreeFile, , iName
    
    
    Seek #iFreeFile, LOF(iFreeFile) - (256 * 2) - 5 - 11 + curPOS
    Size = String(10, Chr(0))
    Get iFreeFile, , Size
        
    Size = CCur(Size)
    
    Close iFreeFile
    FFile = FreeFile
    iName = Replace$(iName, vbCr, "")
    
    curPOS = curPOS - Size - 50

Loop Until i >= iFilez

extractionProgress.Max = iFilez
SelfExtract extractionDirectory
extractionProgress.Value = 0
lblStatus.Caption = "Self Extraction Complete"
tmrAction = 2
tmrWait.Enabled = True
Exit Sub

handleError:
MsgBox "This setup program is damaged or does not contain any files to extract. Please contact the author of the software you are trying to install.", vbOKOnly + vbExclamation, "Error"
End
End Sub

Private Sub Form_Load()
Set extractionProgress = New PGBar
extractionProgress.Max = 100
tmrAction = 1
tmrWait.Enabled = True
extractionDirectory = GetTempPathName
If Right(extractionDirectory, 1) = "\" Then extractionDirectory = Mid(extractionDirectory, 1, Len(extractionDirectory) - 1)
extractionDirectory = extractionDirectory & "\TmpIns" & Format(Time(), "hhmmss")
If Command <> "" Then
    cLA = Split(Command, " ", 2)
    If cLA(0) = "-insfile" Then selfExtractEXE = cLA(1) Else selfExtractEXE = App.Path & "\" & App.EXEName & ".exe"
Else
    selfExtractEXE = TrimSlash(App.Path) & "\" & App.EXEName & ".exe"
End If
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

Private Sub tmrWait_Timer()
If tmrAction <> 3 Then tmrWait.Enabled = False
If tmrAction = 0 Then timerExecute = True: Exit Sub
If tmrAction = 1 Then ExtractFiles: Exit Sub
If tmrAction = 2 Then InitializeInstall: Exit Sub
If tmrAction = 3 Then
    If extractionProgress.Value = 100 Then
        tmrWait.Enabled = False
        lblStatus.Caption = "Done"
        frmInstall.Show
        Unload Me
        Exit Sub
    End If
    extractionProgress.Value = extractionProgress.Value + 1
End If
End Sub

Private Sub ExtractZIP()
On Error Resume Next
lblStatus.Caption = "Preparing to copy resource file..."
timedPause 1
lblStatus.Caption = "Copying ZLIB.DLL..."
mCopyFile extractionDirectory & "\zlib.dll", SysDir, True
extractionProgress.Value = 0
extractionProgress.Max = 5
lblStatus.Caption = "Preparting to extract files in SETUP.CZF..."
timedPause 1
lblStatus.Caption = "Extracting files..."
mCreateFolder extractionDirectory & "\files"
DeCompressFiles extractionDirectory & "\setup.czf", extractionDirectory & "\files", GetTempPathName
lblStatus.Caption = "Extracting files..."
timedPause 1
lblStatus.Caption = "Copying MSCOMCTL.OCX..."
mCopyFile extractionDirectory & "\files\mscomctl.ocx", SysDir, True
extractionProgress.Value = 1
timedPause 1
lblStatus.Caption = "Copying SHELLLNK.DLL..."
mCopyFile extractionDirectory & "\files\shelllnk.dll", SysDir, True
extractionProgress.Value = 2
timedPause 1
lblStatus.Caption = "Copying SHELLLNK.EXP..."
mCopyFile extractionDirectory & "\files\shelllnk.exp", SysDir, True
extractionProgress.Value = 3
timedPause 1
lblStatus.Caption = "Copying SHELLLNK.LIB..."
mCopyFile extractionDirectory & "\files\shelllnk.lib", SysDir, True
extractionProgress.Value = 4
timedPause 1
lblStatus.Caption = "Copying SHELLLNK.TLB..."
mCopyFile extractionDirectory & "\files\shelllnk.tlb", SysDir, True
extractionProgress.Value = 5
timedPause 1
lblStatus.Caption = "Initializing..."
extractionProgress.Value = 0
extractionProgress.Max = 100
tmrAction = 3
tmrWait.Interval = 10
tmrWait.Enabled = True
End Sub

Private Function TrimSlash(strTrim As String) As String
If Right(strTrim, 1) = "\" Then
    TrimSlash = Mid(strTrim, 1, Len(strTrim) - 1)
Else
    TrimSlash = strTrim
End If
End Function
