Attribute VB_Name = "modSelfExtract"
Public iFilez As Integer
Public selfExtractEXE As String
Private Declare Function GetTempPath Lib "kernel32" Alias "GetTempPathA" (ByVal nBufferLength As Long, ByVal lpBuffer As String) As Long

Sub SelfExtract(Optional extractDir As String)

On Error Resume Next

Dim Size As String
Dim iFreeFile As Integer
Dim iName As String
Dim rPath As String
Dim TheFile As String
Dim rWelcome As String
Dim rAbout As String

iFreeFile = FreeFile

curPOS = 0
i = 0
frmMain.pgBarForeground.Visible = True
Do
i = i + 1
    Open selfExtractEXE For Binary As iFreeFile
    Seek #iFreeFile, LOF(iFreeFile) - (256 * 2) - 5 - 41 - 10 + curPOS
    iName = String(40, Chr(0))
    Get iFreeFile, , iName
    
    DoEvents
    iName = Replace$(iName, vbCr, "")
    frmMain.lblStatus.Caption = "Extracting " & UCase(iName) & "..."
    extractionProgress.Value = i
    
    Seek #iFreeFile, LOF(iFreeFile) - (256 * 2) - 5 - 11 + curPOS
    Size = String(10, Chr(0))
    Get iFreeFile, , Size
    DoEvents
    Size = CCur(Size)
   DoEvents
    Seek #iFreeFile, LOF(iFreeFile) - 51 - Size - (256 * 2) - 5 + curPOS
    TheFile = String(Size, Chr(0))
    Get iFreeFile, , TheFile
    DoEvents
    Close iFreeFile
    FFile = FreeFile
    Open extractDir & "\" & iName For Binary Access Write As #FFile
        Put #FFile, , TheFile
    DoEvents
    Close #FFile
    DoEvents
    curPOS = curPOS - Size - 50
DoEvents
Loop Until i >= iFilez
Exit Sub

Err:
Result = MsgBox("An error occured. Header may be damaged." _
    & vbCrLf & "Do you want to abort/retry?", _
    vbAbortRetryIgnore + vbExclamation, "Error")

If Result = vbRetry Then
    Resume
ElseIf Result = vbIgnore Then
    Resume Next
ElseIf Result = vbAbort Then
    End
End If

End Sub

Public Function GetTempPathName() As String
    Dim sBuffer As String
    Dim lRet As Long
    
    sBuffer = String$(255, vbNullChar)
    
    lRet = GetTempPath(255, sBuffer)
    
    If lRet > 0 Then
        sBuffer = Left$(sBuffer, lRet)
    End If
    GetTempPathName = sBuffer
    
End Function


