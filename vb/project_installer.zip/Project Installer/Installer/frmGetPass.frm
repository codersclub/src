VERSION 5.00
Begin VB.Form frmGetPass 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Password Required"
   ClientHeight    =   1830
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4800
   Icon            =   "frmGetPass.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1830
   ScaleWidth      =   4800
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdExit 
      Caption         =   "E&xit Setup"
      Height          =   375
      Left            =   2640
      TabIndex        =   4
      Top             =   1320
      Width           =   1815
   End
   Begin VB.CommandButton cmdInstall 
      Caption         =   "&Install"
      Default         =   -1  'True
      Height          =   375
      Left            =   360
      TabIndex        =   3
      Top             =   1320
      Width           =   1815
   End
   Begin VB.TextBox txtPassword 
      Height          =   325
      IMEMode         =   3  'DISABLE
      Left            =   960
      PasswordChar    =   "*"
      TabIndex        =   2
      Top             =   802
      Width           =   3735
   End
   Begin VB.Label Label2 
      Caption         =   "Password:"
      Height          =   255
      Left            =   120
      TabIndex        =   1
      Top             =   840
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "The program you are attempting to install is password-protected. Please enter the password."
      Height          =   495
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4575
   End
End
Attribute VB_Name = "frmGetPass"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdExit_Click()
passCorrect = False
Me.Hide
End Sub

Private Sub cmdInstall_Click()
If LCase(DoDecrypt(appPassword, pEC)) <> LCase(txtPassword.Text) Then
    MsgBox "The password you have entered is incorrect.", vbOKOnly + vbExclamation, "Password Incorrect"
    txtPassword.Text = ""
    txtPassword.SetFocus
Else
    passCorrect = True
    Me.Hide
End If
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub
