VERSION 5.00
Begin VB.Form frmConfirmPassword 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Confirm Password"
   ClientHeight    =   1575
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4440
   Icon            =   "frmConfirmPassword.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1575
   ScaleWidth      =   4440
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   2520
      TabIndex        =   3
      Top             =   1080
      Width           =   1455
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   480
      TabIndex        =   2
      Top             =   1080
      Width           =   1455
   End
   Begin VB.TextBox txtConfirmPassword 
      Height          =   315
      IMEMode         =   3  'DISABLE
      Left            =   1560
      PasswordChar    =   "*"
      TabIndex        =   1
      Top             =   553
      Width           =   2655
   End
   Begin VB.Label Label2 
      Caption         =   "Confirm Password:"
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   600
      Width           =   1335
   End
   Begin VB.Label Label1 
      Caption         =   "Please re-enter the installation password for confirmation:"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   4095
   End
End
Attribute VB_Name = "frmConfirmPassword"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
cPass_OK = False
Me.Hide
End Sub

Private Sub cmdOK_Click()
If LCase(txtConfirmPassword.Text) <> LCase(frmMain.CreateInstall2_AppPassword.Text) Then
    MsgBox "The password and password confirmation do not match! Please re-enter the password.", vbOKOnly + vbExclamation, "Password"
    frmMain.CreateInstall2_AppPassword.Text = ""
    cPass_OK = False
    Me.Hide
Else
    cPass_OK = True
    Me.Hide
End If
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

