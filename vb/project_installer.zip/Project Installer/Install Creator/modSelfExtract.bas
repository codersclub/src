Attribute VB_Name = "modSelfExtract"
Private Declare Function GetTempPath Lib "kernel32" Alias "GetTempPathA" (ByVal nBufferLength As Long, ByVal lpBuffer As String) As Long

Function AddToSelfExtract(SelfExtract As String, WhatFile As ListBox, SaveAs As String, Optional Password As String) As Boolean
On Error GoTo Er

Dim iFreeFile As Integer
Dim iFreeFile2 As Integer
Dim sBuffer As String
Dim sBefore As String
Dim iFile As String

iFreeFile = FreeFile

Open SelfExtract For Binary As iFreeFile
    sBefore = String(LOF(iFreeFile), Chr(0))
    Get iFreeFile, , sBefore
Close iFreeFile

Open SaveAs For Output As iFreeFile
    wholePrint = sBefore
    For iTMP = 0 To WhatFile.ListCount - 1
        iName = getFileName(WhatFile.List(iTMP))
        iFreeFile2 = FreeFile
        frmMain.CIStatus2.Caption = "Adding " & getFileName(WhatFile.List(iTMP)) & "..."
        DoEvents
        Open WhatFile.List(iTMP) For Binary As iFreeFile2
        DoEvents
            sBuffer = String(LOF(iFreeFile2), Chr(0))
            Get iFreeFile2, , sBuffer
            Size = LOF(iFreeFile2)
            iName = String(40 - Len(iName), vbCr) & iName
            Size = String(10 - Len(Size), "0") & Size
            wholePrint = wholePrint & sBuffer & iName & Size
        DoEvents
        Close iFreeFile2
    Next iTMP
    
    encCode = CStr(Format(Time(), "hhmmss"))
    rBlank = ""
    rBlank = String(256 - Len(rPEC), vbTab) & rPEC
    If Password <> "" Then
        rPass = DoEncrypt(Password, CStr(encCode))
        rPass = rPass & "/|::|\"
        rPass = rPass & encCode
    Else
        rPass = ""
    End If
    rPass = String(256 - Len(rPass), vbTab) & rPass
    iFiles = WhatFile.ListCount
    iFilez = String(5 - Len(iFiles), vbCr) & iFiles
    frmMain.CIStatus2.Caption = "Writing Executable..."
    Print #iFreeFile, wholePrint & iFilez & rPass & rBlank
Close iFreeFile
AddToSelfExtract = True
Exit Function
Er:
MsgBox "An error occured while creating self extractor. Aborting...", vbCritical, "Error"
AddToSelfExtract = False
Exit Function
End Function


Public Function GetTempPathName() As String
    Dim sBuffer As String
    Dim lRet As Long
    
    sBuffer = String$(255, vbNullChar)
    
    lRet = GetTempPath(255, sBuffer)
    
    If lRet > 0 Then
        sBuffer = Left$(sBuffer, lRet)
    End If
    GetTempPathName = sBuffer
    
End Function


