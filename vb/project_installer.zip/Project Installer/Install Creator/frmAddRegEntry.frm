VERSION 5.00
Begin VB.Form frmAddRegEntry 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add Registry Entry"
   ClientHeight    =   2790
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7185
   Icon            =   "frmAddRegEntry.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2790
   ScaleWidth      =   7185
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   4560
      TabIndex        =   6
      Top             =   2280
      Width           =   1455
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   1200
      TabIndex        =   5
      Top             =   2280
      Width           =   1455
   End
   Begin VB.TextBox txtSettingValue 
      Height          =   315
      Left            =   1320
      TabIndex        =   4
      Top             =   1635
      Width           =   5655
   End
   Begin VB.TextBox txtSettingName 
      Height          =   315
      Left            =   1320
      TabIndex        =   3
      Top             =   1153
      Width           =   5655
   End
   Begin VB.TextBox txtKeyPath 
      Height          =   315
      Left            =   1320
      TabIndex        =   2
      Top             =   673
      Width           =   5655
   End
   Begin VB.ComboBox lstRegRoot 
      Height          =   315
      ItemData        =   "frmAddRegEntry.frx":1272
      Left            =   1320
      List            =   "frmAddRegEntry.frx":128B
      Sorted          =   -1  'True
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   193
      Width           =   5655
   End
   Begin VB.Label Label4 
      Caption         =   "Setting Value:"
      Height          =   255
      Left            =   240
      TabIndex        =   9
      Top             =   1680
      Width           =   1095
   End
   Begin VB.Label Label3 
      Caption         =   "Setting Name:"
      Height          =   255
      Left            =   240
      TabIndex        =   8
      Top             =   1200
      Width           =   1095
   End
   Begin VB.Label Label2 
      Caption         =   "Key Path:"
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   720
      Width           =   975
   End
   Begin VB.Label Label1 
      Caption         =   "HKEY Path:"
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   975
   End
End
Attribute VB_Name = "frmAddRegEntry"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdOK_Click()
Dim fLI As ListItem
If txtKeyPath.Text = "" Then MsgBox "You must enter the path to the key you want the registry entry stored in.", vbOKOnly + vbExclamation, "Path Name": Exit Sub
If txtSettingName.Text = "" Then MsgBox "You must enter the name you want to save the setting as.", vbOKOnly + vbExclamation, "Setting Name": Exit Sub
If txtSettingValue.Text = "" Then MsgBox "You must enter the value you want to save in the setting.", vbOKOnly + vbExclamation, "Setting Value": Exit Sub
If GetItemIndex(frmMain.CreateInstall5_RegEntries, lstRegRoot.List(lstRegRoot.ListIndex) & "\" & TrimSlash(txtKeyPath.Text) & "\" & txtSettingName.Text) > -1 Then MsgBox "The registry entry you entered already exists.", vbOKOnly + vbExclamation, "Add Entry": Exit Sub
Set fLI = frmMain.CreateInstall5_RegEntries.ListItems.Add(, , lstRegRoot.List(lstRegRoot.ListIndex) & "\" & TrimSlash(txtKeyPath) & "\" & txtSettingName.Text)
fLI.ListSubItems.Add , , txtSettingValue.Text
Unload Me
End Sub

Private Sub Form_Load()
lstRegRoot.ListIndex = 0
End Sub
