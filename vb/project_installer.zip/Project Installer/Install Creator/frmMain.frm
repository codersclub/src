VERSION 5.00
Object = "{831FDD16-0C5C-11D2-A9FC-0000F8754DA1}#2.0#0"; "MSCOMCTL.OCX"
Object = "{F9043C88-F6F2-101A-A3C9-08002B2F49FB}#1.2#0"; "COMDLG32.OCX"
Begin VB.Form frmMain 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Install Creator"
   ClientHeight    =   5550
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7695
   Icon            =   "frmMain.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5550
   ScaleWidth      =   7695
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer tmrPause 
      Enabled         =   0   'False
      Left            =   600
      Top             =   5040
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Create Installer"
      Height          =   4215
      Index           =   10
      Left            =   120
      TabIndex        =   66
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.ListBox resourceLst 
         Height          =   255
         Left            =   6240
         TabIndex        =   71
         Top             =   600
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.FileListBox fileList 
         Height          =   285
         Left            =   6240
         TabIndex        =   70
         Top             =   240
         Visible         =   0   'False
         Width           =   1095
      End
      Begin VB.Label CIStatus2 
         Height          =   495
         Left            =   360
         TabIndex        =   68
         Top             =   960
         Width           =   6735
      End
      Begin VB.Label CIStatus 
         Caption         =   "Preparing to create installer...."
         Height          =   255
         Left            =   360
         TabIndex        =   67
         Top             =   480
         Width           =   3855
      End
      Begin VB.Label CIStatus3 
         Height          =   495
         Left            =   360
         TabIndex        =   69
         Top             =   1560
         Width           =   6735
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Ready to Install"
      Height          =   4215
      Index           =   9
      Left            =   120
      TabIndex        =   64
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.Label Label30 
         Caption         =   "Install Creator is now ready to create the self-extractable installer for your program. Click Create to begin."
         Height          =   495
         Left            =   240
         TabIndex        =   65
         Top             =   360
         Width           =   6975
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Installer Destination"
      Height          =   4215
      Index           =   8
      Left            =   120
      TabIndex        =   59
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall8_SaveTo 
         Caption         =   "&Save As..."
         Height          =   315
         Left            =   5880
         TabIndex        =   62
         Top             =   913
         Width           =   1215
      End
      Begin VB.TextBox CreateInstall8_InstallerDest 
         Height          =   315
         Left            =   1080
         Locked          =   -1  'True
         TabIndex        =   61
         Top             =   913
         Width           =   4695
      End
      Begin VB.Label Label29 
         Alignment       =   1  'Right Justify
         Caption         =   "Save To:"
         Height          =   255
         Left            =   240
         TabIndex        =   63
         Top             =   960
         Width           =   735
      End
      Begin VB.Label Label28 
         Caption         =   "Please click Save As to select a location to save your self-extractable installer."
         Height          =   495
         Left            =   240
         TabIndex        =   60
         Top             =   360
         Width           =   6855
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Programs"
      Height          =   4215
      Index           =   7
      Left            =   120
      TabIndex        =   46
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.TextBox CreateInstall7_RunBeforeUninstall 
         Height          =   315
         Left            =   1920
         TabIndex        =   22
         Top             =   1503
         Width           =   5175
      End
      Begin VB.TextBox CreateInstall7_RunAfterInstall 
         Height          =   315
         Left            =   1920
         TabIndex        =   21
         Top             =   1023
         Width           =   5175
      End
      Begin VB.Label Label27 
         Caption         =   "User's Windows System directory"
         Height          =   255
         Left            =   1920
         TabIndex        =   58
         Top             =   3240
         Width           =   3975
      End
      Begin VB.Label Label26 
         Caption         =   "="
         Height          =   255
         Left            =   1560
         TabIndex        =   57
         Top             =   3240
         Width           =   135
      End
      Begin VB.Label Label25 
         Caption         =   "<SysDir>"
         Height          =   255
         Left            =   240
         TabIndex        =   56
         Top             =   3240
         Width           =   855
      End
      Begin VB.Label Label24 
         Caption         =   "User's Windows directory"
         Height          =   255
         Left            =   1920
         TabIndex        =   55
         Top             =   2880
         Width           =   2655
      End
      Begin VB.Label Label23 
         Caption         =   "="
         Height          =   255
         Left            =   1560
         TabIndex        =   54
         Top             =   2880
         Width           =   135
      End
      Begin VB.Label Label22 
         Caption         =   "<WinDir>"
         Height          =   255
         Left            =   240
         TabIndex        =   53
         Top             =   2880
         Width           =   975
      End
      Begin VB.Label Label21 
         Caption         =   "Installation directory of application"
         Height          =   255
         Left            =   1920
         TabIndex        =   52
         Top             =   2520
         Width           =   3375
      End
      Begin VB.Label Label20 
         Caption         =   "="
         Height          =   255
         Left            =   1560
         TabIndex        =   51
         Top             =   2520
         Width           =   255
      End
      Begin VB.Label Label19 
         Caption         =   "<AppPath>"
         Height          =   255
         Left            =   240
         TabIndex        =   50
         Top             =   2520
         Width           =   1695
      End
      Begin VB.Label Label18 
         Caption         =   "Run Before Uninstall:"
         Height          =   255
         Left            =   240
         TabIndex        =   49
         Top             =   1560
         Width           =   1575
      End
      Begin VB.Label Label17 
         Caption         =   "Run After Install:"
         Height          =   255
         Left            =   240
         TabIndex        =   48
         Top             =   1080
         Width           =   1215
      End
      Begin VB.Label Label16 
         Caption         =   $"frmMain.frx":1272
         Height          =   495
         Left            =   240
         TabIndex        =   47
         Top             =   360
         Width           =   6975
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Icons"
      Height          =   4215
      Index           =   6
      Left            =   120
      TabIndex        =   18
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall6_RemoveIcon 
         Caption         =   "&Remove Icon"
         Enabled         =   0   'False
         Height          =   375
         Left            =   4440
         TabIndex        =   20
         Top             =   3720
         Width           =   1815
      End
      Begin VB.CommandButton CreateInstall6_AddIcon 
         Caption         =   "&Add Icon"
         Height          =   375
         Left            =   1200
         TabIndex        =   19
         Top             =   3720
         Width           =   1935
      End
      Begin MSComctlLib.ListView CreateInstall6_IconList 
         Height          =   3015
         Left            =   240
         TabIndex        =   44
         Top             =   720
         Width           =   6975
         _ExtentX        =   12303
         _ExtentY        =   5318
         View            =   3
         Sorted          =   -1  'True
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   2
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Icon Name"
            Object.Width           =   6085
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Text            =   "Path"
            Object.Width           =   6085
         EndProperty
      End
      Begin VB.Label Label15 
         Caption         =   "If you would like any icons created during install, please add them to the list below."
         Height          =   375
         Left            =   240
         TabIndex        =   45
         Top             =   360
         Width           =   6975
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Registry Entries"
      Height          =   4215
      Index           =   5
      Left            =   120
      TabIndex        =   42
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin MSComctlLib.ListView CreateInstall5_RegEntries 
         Height          =   3015
         Left            =   240
         TabIndex        =   15
         Top             =   720
         Width           =   6975
         _ExtentX        =   12303
         _ExtentY        =   5318
         View            =   3
         Sorted          =   -1  'True
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   2
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "Setting Path"
            Object.Width           =   8643
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Text            =   "Setting Value"
            Object.Width           =   3528
         EndProperty
      End
      Begin VB.CommandButton CreateInstall5_RemoveEntry 
         Caption         =   "&Remove Entry"
         Enabled         =   0   'False
         Height          =   375
         Left            =   4440
         TabIndex        =   17
         Top             =   3720
         Width           =   1815
      End
      Begin VB.CommandButton CreateInstall5_AddEntry 
         Caption         =   "&Add Entry"
         Height          =   375
         Left            =   1200
         TabIndex        =   16
         Top             =   3720
         Width           =   1935
      End
      Begin VB.Label Label14 
         Caption         =   "If you would like any registry entries created during install, please add them to the list below."
         Height          =   375
         Left            =   240
         TabIndex        =   43
         Top             =   360
         Width           =   6975
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Files"
      Height          =   4215
      Index           =   4
      Left            =   120
      TabIndex        =   40
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall4_RemoveFile 
         Caption         =   "&Remove File"
         Enabled         =   0   'False
         Height          =   375
         Left            =   4320
         TabIndex        =   14
         Top             =   3720
         Width           =   2415
      End
      Begin VB.CommandButton CreateInstall4_AddFile 
         Caption         =   "&Add File"
         Height          =   375
         Left            =   720
         TabIndex        =   13
         Top             =   3720
         Width           =   2415
      End
      Begin MSComctlLib.ListView CreateInstall4_FileList 
         Height          =   2655
         Left            =   240
         TabIndex        =   12
         Top             =   960
         Width           =   6975
         _ExtentX        =   12303
         _ExtentY        =   4683
         View            =   3
         Sorted          =   -1  'True
         LabelWrap       =   -1  'True
         HideSelection   =   -1  'True
         FullRowSelect   =   -1  'True
         GridLines       =   -1  'True
         _Version        =   393217
         ForeColor       =   -2147483640
         BackColor       =   -2147483643
         BorderStyle     =   1
         Appearance      =   1
         NumItems        =   3
         BeginProperty ColumnHeader(1) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            Text            =   "File Name"
            Object.Width           =   4410
         EndProperty
         BeginProperty ColumnHeader(2) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   1
            Text            =   "Source"
            Object.Width           =   5644
         EndProperty
         BeginProperty ColumnHeader(3) {BDD1F052-858B-11D1-B16A-00C0F0283628} 
            SubItemIndex    =   2
            Text            =   "Install Destination"
            Object.Width           =   2046
         EndProperty
      End
      Begin VB.Label Label13 
         Caption         =   "Listed below are all the files that the program requires. If you would like to add any files, click Add File."
         Height          =   375
         Left            =   240
         TabIndex        =   41
         Top             =   360
         Width           =   6855
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Application Executable"
      Height          =   4215
      Index           =   3
      Left            =   120
      TabIndex        =   37
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall3_EXEBrowse 
         Caption         =   "Browse..."
         Height          =   315
         Left            =   6120
         TabIndex        =   11
         Top             =   1153
         Width           =   1095
      End
      Begin VB.TextBox CreateInstall3_AppEXE 
         Height          =   315
         Left            =   1560
         TabIndex        =   10
         Top             =   1153
         Width           =   4455
      End
      Begin VB.Label Label12 
         Caption         =   "Executable Path:"
         Height          =   255
         Left            =   240
         TabIndex        =   39
         Top             =   1200
         Width           =   1215
      End
      Begin VB.Label CreateInstall3_UserMsg 
         Caption         =   "Please locate the compiled executable for <AppName>. If you do not have not compiled an executable, please do so now."
         Height          =   495
         Left            =   240
         TabIndex        =   38
         Top             =   480
         Width           =   6975
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Project Information"
      Height          =   4215
      Index           =   2
      Left            =   120
      TabIndex        =   28
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall2_cmdBrowse 
         Caption         =   "&Browse..."
         Height          =   315
         Left            =   5880
         TabIndex        =   8
         Top             =   2233
         Width           =   1095
      End
      Begin VB.TextBox CreateInstall2_SplashScreenImage 
         Height          =   315
         Left            =   2160
         TabIndex        =   7
         Top             =   2233
         Width           =   3615
      End
      Begin VB.TextBox CreateInstall2_AppVersion 
         Height          =   315
         Left            =   2160
         MaxLength       =   5
         TabIndex        =   6
         Top             =   1273
         Width           =   4815
      End
      Begin VB.TextBox CreateInstall2_AppName 
         Height          =   315
         Left            =   2160
         MaxLength       =   30
         TabIndex        =   5
         Top             =   793
         Width           =   4815
      End
      Begin VB.TextBox CreateInstall2_AppPassword 
         Height          =   315
         IMEMode         =   3  'DISABLE
         Left            =   2160
         MaxLength       =   30
         PasswordChar    =   "*"
         TabIndex        =   9
         Top             =   3553
         Width           =   4815
      End
      Begin VB.Label Label11 
         Caption         =   "Application Password:"
         Height          =   255
         Left            =   480
         TabIndex        =   35
         Top             =   3600
         Width           =   1695
      End
      Begin VB.Label Label10 
         Caption         =   $"frmMain.frx":131A
         Height          =   615
         Left            =   240
         TabIndex        =   34
         Top             =   2760
         Width           =   6855
      End
      Begin VB.Label Label9 
         Caption         =   "Splash Screen Image:"
         Height          =   255
         Left            =   480
         TabIndex        =   33
         Top             =   2280
         Width           =   1575
      End
      Begin VB.Label Label8 
         Caption         =   "If you want a splash screen picture, please select one now. If not, leave the box blank."
         Height          =   255
         Left            =   240
         TabIndex        =   32
         Top             =   1800
         Width           =   6135
      End
      Begin VB.Label Label7 
         Caption         =   "Please specify the name and version of the VB project."
         Height          =   255
         Left            =   240
         TabIndex        =   31
         Top             =   360
         Width           =   6975
      End
      Begin VB.Label Label6 
         Caption         =   "Application Version:"
         Height          =   255
         Left            =   480
         TabIndex        =   30
         Top             =   1320
         Width           =   1455
      End
      Begin VB.Label Label5 
         Caption         =   "Application Name:"
         Height          =   255
         Left            =   480
         TabIndex        =   29
         Top             =   840
         Width           =   1335
      End
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Select Visual Basic Project"
      Height          =   4215
      Index           =   1
      Left            =   120
      TabIndex        =   26
      Top             =   120
      Visible         =   0   'False
      Width           =   7455
      Begin VB.CommandButton CreateInstall1_Browse 
         Caption         =   "Browse..."
         Height          =   325
         Left            =   5400
         TabIndex        =   4
         Top             =   960
         Width           =   975
      End
      Begin VB.TextBox CreateInstall1_ProjectFile 
         Height          =   325
         Left            =   240
         Locked          =   -1  'True
         TabIndex        =   3
         Top             =   960
         Width           =   5055
      End
      Begin VB.Label Label4 
         Caption         =   "Please select the Visual Basic project file for the program you wish to create an installer for."
         Height          =   255
         Left            =   240
         TabIndex        =   27
         Top             =   480
         Width           =   6855
      End
   End
   Begin MSComDlg.CommonDialog commonDialog 
      Left            =   120
      Top             =   5040
      _ExtentX        =   847
      _ExtentY        =   847
      _Version        =   393216
   End
   Begin VB.CommandButton cmdBack 
      Caption         =   "&Back"
      Enabled         =   0   'False
      Height          =   425
      Left            =   5160
      TabIndex        =   2
      Top             =   4440
      Width           =   1215
   End
   Begin VB.CommandButton cmdNext 
      Caption         =   "&Next"
      Default         =   -1  'True
      Height          =   425
      Left            =   6360
      TabIndex        =   1
      Top             =   4440
      Width           =   1215
   End
   Begin VB.CommandButton cmdExit 
      Caption         =   "E&xit Install Creator"
      Height          =   425
      Left            =   120
      TabIndex        =   36
      Top             =   4440
      Width           =   1695
   End
   Begin VB.Frame CreateInstall 
      Caption         =   "Welcome to Install Creator"
      Height          =   4215
      Index           =   0
      Left            =   120
      TabIndex        =   24
      Top             =   120
      Width           =   7455
      Begin VB.Label Label3 
         Caption         =   $"frmMain.frx":13E3
         Height          =   495
         Left            =   240
         TabIndex        =   25
         Top             =   480
         Width           =   6975
      End
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "Copyright � 2001 PCSCT Software. All rights reserved. "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   3720
      TabIndex        =   23
      Top             =   5280
      Width           =   3975
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "Install Creator 1.8 by PCSCT Software  "
      ForeColor       =   &H00808080&
      Height          =   255
      Left            =   3840
      TabIndex        =   0
      Top             =   5040
      Width           =   3855
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private currentFrame As Integer
Private fLI As ListItem
Private fLD As String
Private tmpStr As String
Private pauseExec As Boolean

Private Sub cmdBack_Click()
NavigateFrame -1
End Sub

Private Sub CreateInstall1_Browse_Click()
Dim fileName As String
commonDialog.Filter = "Visual Basic Projects (*.vbp)|*.vbp"
commonDialog.Flags = &H400 + &H4 + &H8 + &H2 + &H800
commonDialog.DialogTitle = "Select Visual Basic Project"
commonDialog.ShowOpen
If commonDialog.fileName = "" Then Exit Sub
If Right(commonDialog.fileName, 4) <> ".vbp" Then MsgBox "The file you have selected is not a Visual Basic project file.", vbOKOnly + vbExclamation, "Browse": Exit Sub
If mFileExists(commonDialog.fileName) = False Then MsgBox "The file you have selected can not be accessed. Please select another file.", vbOKOnly + vbExclamation, "Browse": Exit Sub
CreateInstall1_ProjectFile.Text = commonDialog.fileName
fileName = Mid(commonDialog.fileName, 1, InStrRev(commonDialog.fileName, ".") - 1)
vbpDir = GetTrueDirName(commonDialog.fileName, True, False)
Dim inputData As String
vbpFile = fileName & ".tpr"
Open vbpFile For Output As #1
Open commonDialog.fileName For Input As #2
Print #1, "[VBProjectCode]"
Do Until (EOF(2))
    Input #2, inputData
    Print #1, inputData
Loop
Close #2
Close #1
commonDialog.fileName = ""
End Sub

Private Sub cmdExit_Click()
If MsgBox("Are you sure you want to exit the install creator?", vbYesNo + vbQuestion, "Exit") = vbYes Then
    Unload Me
    End
End If
End Sub

Private Sub cmdNext_Click()
NavigateFrame 1
End Sub

Private Sub NavigateFrame(navigationOperation As Integer)
If navigationOperation = 1 Then If checkValues(currentFrame) = False Then Exit Sub
If navigationOperation = -1 Then setBackValues currentFrame
CreateInstall(currentFrame).Visible = False
CreateInstall(currentFrame + navigationOperation).Visible = True
currentFrame = currentFrame + navigationOperation
SetItemFocus currentFrame
If currentFrame = 0 Then cmdBack.Enabled = False Else cmdBack.Enabled = True
If currentFrame >= 9 Then cmdNext.Caption = "&Create" Else cmdNext.Caption = "&Next"
If currentFrame = 10 Then createInstaller
End Sub

Private Sub CreateInstall2_cmdBrowse_Click()
commonDialog.DialogTitle = "Browse for Splash Screen Image"
commonDialog.Filter = "All Picture Files|*.bmp;*.dib;*.gif;*.jpg;*.wmf;*.emf;*.ico;*.cur|Windows Bitmap (*.bmp;*.dib)|*.bmp;*.dib|Compuserve GIF (*.gif)|*.gif|Compressed JPEG (*.jpg)|*.jpg|Metafiles (*.wmf;*.emf)|*.wmf;*.emf|Icons (*.ico;*.cur)|*.ico;*.cur"
commonDialog.InitDir = vbpDir
commonDialog.fileName = ""
commonDialog.ShowOpen
If commonDialog.fileName = "" Then Exit Sub
CreateInstall2_SplashScreenImage.Text = commonDialog.fileName
End Sub

Private Sub SetItemFocus(frameNum As Integer)
If frameNum = 1 Then
    CreateInstall1_ProjectFile.SetFocus
ElseIf frameNum = 2 Then
    CreateInstall2_AppName.SetFocus
ElseIf frameNum = 3 Then
    CreateInstall3_AppEXE.SetFocus
ElseIf frameNum = 4 Then
    CreateInstall4_FileList.SetFocus
ElseIf frameNum = 5 Then
    CreateInstall5_RegEntries.SetFocus
ElseIf frameNum = 6 Then
    CreateInstall6_IconList.SetFocus
ElseIf frameNum = 7 Then
    CreateInstall7_RunAfterInstall.SetFocus
ElseIf frameNum = 8 Then
    CreateInstall8_SaveTo.SetFocus
ElseIf frameNum = 9 Then
    cmdNext.SetFocus
End If
End Sub

Private Sub CreateInstall3_EXEBrowse_Click()
commonDialog.fileName = ""
commonDialog.DialogTitle = "Browse for Compiled Executable"
commonDialog.InitDir = vbpDir
commonDialog.Filter = "Compiled Executables (*.exe)|*.exe"
commonDialog.ShowOpen
If commonDialog.fileName = "" Then Exit Sub
CreateInstall3_AppEXE.Text = commonDialog.fileName
End Sub

Private Sub CreateInstall4_AddFile_Click()
frmAddFile.Show , frmMain
End Sub

Private Sub CreateInstall4_FileList_BeforeLabelEdit(Cancel As Integer)
Cancel = 1
End Sub

Private Sub CreateInstall4_FileList_ItemClick(ByVal Item As MSComctlLib.ListItem)
If CreateInstall4_FileList.ListItems(GetItemIndex(frmMain.CreateInstall4_FileList, CStr(Item))).Tag <> "REQUIRED" Then
    CreateInstall4_RemoveFile.Enabled = True
Else
    CreateInstall4_RemoveFile.Enabled = False
End If
End Sub

Private Sub CreateInstall4_RemoveFile_Click()
If MsgBox("Do you want to remove the file " & UCase(CreateInstall4_FileList.SelectedItem) & "?", vbYesNo + vbQuestion, "Remove File") = vbYes Then
    CreateInstall4_FileList.ListItems.Remove GetItemIndex(frmMain.CreateInstall4_FileList, CreateInstall4_FileList.SelectedItem)
End If
End Sub

Private Sub CreateInstall5_AddEntry_Click()
frmAddRegEntry.Show , frmMain
End Sub

Private Sub CreateInstall5_RegEntries_BeforeLabelEdit(Cancel As Integer)
Cancel = 1
End Sub

Private Sub CreateInstall5_RegEntries_ItemClick(ByVal Item As MSComctlLib.ListItem)
CreateInstall5_RemoveEntry.Enabled = True
End Sub

Private Sub CreateInstall5_RemoveEntry_Click()
If CreateInstall5_RegEntries.ListItems.Count <= 0 Then Exit Sub
If MsgBox("Do you want to remove the entry " & UCase(CreateInstall5_RegEntries.SelectedItem) & "?", vbYesNo + vbQuestion, "Remove Entry") = vbYes Then
    CreateInstall5_RegEntries.ListItems.Remove GetItemIndex(CreateInstall5_RegEntries, CreateInstall5_RegEntries.SelectedItem)
End If
If CreateInstall5_RegEntries.ListItems.Count <= 0 Then CreateInstall5_RemoveEntry.Enabled = False
End Sub

Private Sub CreateInstall6_AddIcon_Click()
frmAddIcon.Show , frmMain
End Sub

Private Sub CreateInstall6_IconList_BeforeLabelEdit(Cancel As Integer)
Cancel = 1
End Sub

Private Sub CreateInstall6_IconList_ItemClick(ByVal Item As MSComctlLib.ListItem)
CreateInstall6_RemoveIcon.Enabled = True
End Sub

Private Sub CreateInstall6_RemoveIcon_Click()
If CreateInstall6_IconList.ListItems.Count <= 0 Then Exit Sub
If MsgBox("Do you want to remove the icon " & UCase(CreateInstall6_IconList.SelectedItem) & "?", vbYesNo + vbQuestion, "Remove Entry") = vbYes Then
    CreateInstall6_IconList.ListItems.Remove GetItemIndex(CreateInstall6_IconList, CreateInstall6_IconList.SelectedItem)
End If
If CreateInstall6_IconList.ListItems.Count <= 0 Then CreateInstall6_RemoveIcon.Enabled = False
End Sub

Private Sub CreateInstall8_SaveTo_Click()
commonDialog.DialogTitle = "Save Installer As"
commonDialog.fileName = ""
commonDialog.Filter = "Executable Files (*.exe)|*.exe"
commonDialog.ShowSave
If commonDialog.fileName = "" Then Exit Sub
CreateInstall8_InstallerDest.Text = commonDialog.fileName
End Sub

Private Sub Form_Load()
currentFrame = 0
End Sub

Private Sub Form_QueryUnload(Cancel As Integer, UnloadMode As Integer)
If UnloadMode <> 1 Then Cancel = 1
End Sub

Private Function checkValues(frameNum As Integer) As Boolean
If frameNum = 1 Then
    If CreateInstall1_ProjectFile.Text = "" Then MsgBox "You must select the Visual Basic project file which you are creating the installer for.", vbOKOnly + vbExclamation, "VB Project File": checkValues = False: Exit Function
    If mFileExists(CreateInstall1_ProjectFile.Text) = False Then MsgBox "The Visual Basic project file you have selected does not exist.", vbOKOnly + vbExclamation, "VB Project File": checkValues = False: Exit Function
    CreateInstall2_AppName.Text = GetINIString(vbpFile, "VBProjectCode", "Title")
    CreateInstall2_AppVersion.Text = GetINIString(vbpFile, "VBProjectCode", "MajorVer") & "." & GetINIString(vbpFile, "VBProjectCode", "MinorVer") & GetINIString(vbpFile, "VBProjectCode", "RevisionVer")
ElseIf frameNum = 2 Then
    If CreateInstall2_AppName.Text = "" Then MsgBox "You must enter the title of your application.", vbOKOnly + vbExclamation, "Application Name": checkValues = False: Exit Function
    If CreateInstall2_AppVersion.Text = "" Then MsgBox "You must enter the version of your application.", vbOKOnly + vbExclamation, "Application Version": checkValues = False: Exit Function
    If TrimZeros(CreateInstall2_AppVersion.Text) <> CStr(Val(CreateInstall2_AppVersion.Text)) Then MsgBox "The version number can only be numbers and a decimal (ex 1.00).", vbOKOnly + vbExclamation, "Application Version": checkValues = False: Exit Function
    If CreateInstall2_SplashScreenImage.Text <> "" Then If mFileExists(CreateInstall2_SplashScreenImage.Text) = False Then MsgBox "The splash screen image you entered could not be accessed.", vbOKOnly + vbExclamation, "Splash Screen Image": checkValues = False: Exit Function
    If CreateInstall2_AppPassword.Text <> "" Then
        frmConfirmPassword.Show vbModal, Me
        Do Until frmConfirmPassword.Visible = False: DoEvents: Loop
        Unload frmConfirmPassword
        If cPass_OK = False Then checkValues = False: Exit Function
    End If
    CreateInstall3_UserMsg.Caption = Replace(CreateInstall3_UserMsg.Caption, "<AppName>", CreateInstall2_AppName.Text)
    CreateInstall3_AppEXE.Text = vbpDir & "\" & GetINIString(vbpFile, "VBProjectCode", "ExeName32")
    If CreateInstall3_AppEXE.Text = vbpDir & "\" Then CreateInstall3_AppEXE.Text = ""
    If CreateInstall3_AppEXE.Text <> "" Then If mFileExists(CreateInstall3_AppEXE.Text) = False Then CreateInstall3_AppEXE.Text = ""
ElseIf frameNum = 3 Then
    If CreateInstall3_AppEXE.Text = "" Then MsgBox "You must enter the path to the compiled executable of " & CreateInstall2_AppName.Text & ".", vbOKOnly + vbExclamation, "Compiled Executable Location": checkValues = False: Exit Function
    If mFileExists(CreateInstall3_AppEXE.Text) = False Then MsgBox "The compiled executable path you entered could not be accessed.", vbOKOnly + vbExclamation, "Compiled Executable Location": checkValues = False: Exit Function
    PopulateFileList
ElseIf frameNum = 8 Then
    If CreateInstall8_InstallerDest.Text = "" Then MsgBox "You must select a destination file for the installer.", vbOKOnly + vbExclamation, "Destination": Exit Function
End If
checkValues = True
End Function

Private Function setBackValues(frameNum As Integer)
If frameNum = 3 Then
    CreateInstall3_UserMsg.Caption = Replace(CreateInstall3_UserMsg.Caption, CreateInstall2_AppName.Text, "<AppName>")
End If
End Function

Private Sub PopulateFileList()
On Error Resume Next
CreateInstall4_FileList.ListItems.Clear
Set fLI = CreateInstall4_FileList.ListItems.Add(, , getFileName(CreateInstall3_AppEXE.Text))
fLI.Tag = "REQUIRED"
fLI.ListSubItems.Add , , GetTrueDirName(CreateInstall3_AppEXE.Text, True, False)
fLI.ListSubItems.Add , , "<AppPath>"
Open vbpFile For Input As #1
Do Until (EOF(1))
    Input #1, fLD
    If LCase(Mid(fLD, 1, 7)) = "object=" Then
        tmpStr = Mid(fLD, InStrRev(fLD, ";") + 2)
        Set fLI = CreateInstall4_FileList.ListItems.Add(, , getFileName(tmpStr))
        fLI.Tag = "REQUIRED"
        If InStr(1, tmpStr, "\") > 0 Then
            fLI.ListSubItems.Add , , GetTrueDirName(vbpDir & "\" & tmpStr, True, False)
        Else
            fLI.ListSubItems.Add , , SysDir(False)
        End If
        fLI.ListSubItems.Add , , "<SysDir>"
    End If
Loop
Close #1
End Sub

Private Sub createInstaller()
On Error Resume Next
Dim tempPath As String
Dim X As Integer
cmdExit.Enabled = False
cmdBack.Enabled = False
cmdNext.Enabled = False
Pause 1
CIStatus.Caption = "Preparing Temporary Directory..."
tempPath = TrimSlash(GetTempPathName) & "\CIns" & Format(Time(), "hhmmss")
mCreateFolder tempPath & "\files"
Pause 1
CIStatus.Caption = "Copying Files..."
For X = 1 To CreateInstall4_FileList.ListItems.Count
    CIStatus2.Caption = "Source File:     " & CreateInstall4_FileList.ListItems(X).ListSubItems(1).Text & "\" & CreateInstall4_FileList.ListItems(X).Text
    CIStatus3.Caption = "Destination:     " & tempPath & "\files\" & CreateInstall4_FileList.ListItems(X).Text
    mCopyFile CreateInstall4_FileList.ListItems(X).ListSubItems(1).Text & "\" & CreateInstall4_FileList.ListItems(X).Text, tempPath & "\files\" & CreateInstall4_FileList.ListItems(X).Text, True
Next X
CIStatus2.Caption = ""
CIStatus3.Caption = ""
Pause 1
If CreateInstall2_SplashScreenImage.Text <> "" Then
    CIStatus.Caption = "Copying Slash Screen Image..."
    mCopyFile CreateInstall2_SplashScreenImage.Text, tempPath & "\Setup." & Mid(CreateInstall2_SplashScreenImage.Text, InStrRev(CreateInstall2_SplashScreenImage.Text, ".") + 1), True
    Pause 1
End If
CIStatus.Caption = "Copying MSCOMCTL.OCX..."
mCopyFile SysDir & "\mscomctl.ocx", tempPath & "\files\mscomctl.ocx", True
Pause 1
CIStatus.Caption = "Copying SHELLLNK.DLL..."
mCopyFile App.Path & "\shelllnk.dl_", tempPath & "\files\shelllnk.dll", True
Pause 1
CIStatus.Caption = "Copying SHELLLNK.EXP..."
mCopyFile App.Path & "\shelllnk.ex_", tempPath & "\files\shelllnk.exp", True
Pause 1
CIStatus.Caption = "Copying SHELLLNK.LIB..."
mCopyFile App.Path & "\shelllnk.li", tempPath & "\files\shelllnk.lib", True
Pause 1
CIStatus.Caption = "Copying SHELLLNK.TLB..."
mCopyFile App.Path & "\shelllnk.tl_", tempPath & "\files\shelllnk.tlb", True
Pause 1
CIStatus.Caption = "Copying ZLIB.DLL..."
mCopyFile App.Path & "\zlib.dl_", tempPath & "\zlib.dll", True
Pause 1
CIStatus.Caption = "Copying PCSUNINS.EXE..."
mCopyFile App.Path & "\pcsunins.ex_", tempPath & "\files\pcsunins.exe", True
Pause 1
CIStatus.Caption = "Preparing to create compression file..."
resourceLst.Clear
fileList.Path = tempPath & "\files"
For X = 0 To fileList.ListCount - 1
    resourceLst.AddItem tempPath & "\files\" & fileList.List(X)
Next X
Pause 1
CIStatus.Caption = "Creating compression file..."
CompressFiles resourceLst, GetTempPathName, tempPath & "\setup.czf", Z_BEST_COMPRESSION
CIStatus2.Caption = ""
Pause 1
CIStatus.Caption = "Creating file resource list..."
Open tempPath & "\flist.dat" For Output As #1
    For X = 1 To CreateInstall4_FileList.ListItems.Count
        CIStatus2.Caption = "Writing file information for " & UCase(CreateInstall4_FileList.ListItems(X).Text) & "..."
        Print #1, CreateInstall4_FileList.ListItems(X).Text & "||" & CreateInstall4_FileList.ListItems(X).ListSubItems(2).Text
    Next X
Close #1
CIStatus2.Caption = ""
Pause 1
CIStatus.Caption = "Creating registry resource list..."
Open tempPath & "\regentries.dat" For Output As #1
    If CreateInstall5_RegEntries.ListItems.Count > 0 Then
        For X = 1 To CreateInstall5_RegEntries.ListItems.Count
            CIStatus2.Caption = "Writing registry data for " & UCase(CreateInstall5_RegEntries.ListItems(X)) & "..."
            entryName = CreateInstall5_RegEntries.ListItems(X).Text
            slashPosF = InStr(1, entryName, "\")
            slashPosL = InStrRev(entryName, "\")
            keyRoot = Mid(entryName, 1, slashPosF - 1)
            keyKey = Mid(entryName, slashPosF + 1, slashPosL - slashPosF - 1)
            keySNm = Mid(entryName, slashPosL + 1)
            keySVl = CreateInstall5_RegEntries.ListItems(X).ListSubItems(1).Text
            Print #1, keyRoot & "||" & keyKey & "||" & keySNm & "||" & keySVl
        Next X
    End If
Close #1
CIStatus2.Caption = ""
Pause 1
CIStatus.Caption = "Creating icon resource list..."
Open tempPath & "\iconlist.dat" For Output As #1
    If CreateInstall6_IconList.ListItems.Count > 0 Then
        For X = 1 To CreateInstall6_IconList.ListItems.Count
            CIStatus2.Caption = "Creating Icon " & UCase(CreateInstall6_IconList.ListItems(X).Text) & "..."
            iconName = CreateInstall6_IconList.ListItems(X).Text
            slashPosF = InStr(1, iconName, "\")
            slashPosL = InStrRev(iconName, "\")
            iconRoot = Mid(iconName, 1, slashPosF - 1)
            iconFolder = Mid(iconName, slashPosF + 1, slashPosL - slashPosF - 1)
            iconDspName = Mid(iconName, slashPosL + 1)
            iconPath = CreateInstall6_IconList.ListItems(X).ListSubItems(1).Text
            If iconFolder = "" Then iconFolder = "."
            Print #1, iconRoot & "||" & iconFolder & "||" & iconDspName & "||" & iconPath
        Next X
    End If
Close #1
CIStatus2.Caption = ""
Pause 1
CIStatus.Caption = "Creating Setup resource file..."
Open tempPath & "\Setup.ini" For Output As #1
    Dim splashShow As Integer
    If CreateInstall2_SplashScreenImage.Text = "" Then splashShow = 0 Else splashShow = 1
    Print #1, "[Install]"
    Print #1, "AppName=" & CreateInstall2_AppName.Text
    Print #1, "AppVersion=" & CreateInstall2_AppVersion.Text
    Print #1, "ShowSplash=" & splashShow
    Print #1, "SplashFile=Setup." & Mid(CreateInstall2_SplashScreenImage.Text, InStrRev(CreateInstall2_SplashScreenImage.Text, ".") + 1)
    Print #1, "RunAfterInstall=" & CreateInstall7_RunAfterInstall.Text
    Print #1, "RunBeforeUninst=" & CreateInstall7_RunBeforeUninstall.Text
Close #1
Pause 1
CIStatus.Caption = "Preparing to create self-extractor..."
resourceLst.Clear
fileList.Path = tempPath
For X = 0 To fileList.ListCount - 1
    resourceLst.AddItem tempPath & "\" & fileList.List(X)
Next X
If mFileExists(CreateInstall8_InstallerDest.Text) = True Then mKillFile CreateInstall8_InstallerDest.Text
CIStatus.Caption = "Creating self-extractor..."
AddToSelfExtract App.Path & "\insTemplate.ex_", resourceLst, CreateInstall8_InstallerDest.Text, CreateInstall2_AppPassword.Text
CIStatus2.Caption = ""
Pause 1
CIStatus.Caption = "Deleting temporary files..."
mEmptyFolder tempPath & "\files"
mDeleteFolder tempPath * "\files"
mEmptyFolder tempPath
mDeleteFolder tempPath
Pause 1
CIStatus.Caption = "Installer created successfully."
Pause 1
MsgBox "Your self-extracting installer has been successfully created. This file is located at:" & vbCrLf & vbCrLf & CreateInstall8_InstallerDest.Text & vbCrLf & vbCrLf & "Thank you for using PCSCT Software's Install Creator! Click OK to exit Install Creator.", vbOKOnly + vbInformation, "Success"
Unload Me
End
End Sub

Private Function Pause(interVal As Integer)
pauseExec = False
tmrPause.interVal = interVal * 1000
tmrPause.Enabled = True
Do Until pauseExec = True
    DoEvents
Loop
tmrPause.Enabled = False
End Function

Private Sub tmrPause_Timer()
pauseExec = True
End Sub
