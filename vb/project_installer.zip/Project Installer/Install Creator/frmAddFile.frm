VERSION 5.00
Begin VB.Form frmAddFile 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add File"
   ClientHeight    =   2880
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6495
   Icon            =   "frmAddFile.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2880
   ScaleWidth      =   6495
   StartUpPosition =   2  'CenterScreen
   Begin VB.TextBox txtDestDir 
      Height          =   285
      Left            =   120
      Locked          =   -1  'True
      TabIndex        =   11
      Text            =   "<AppPath>"
      Top             =   1800
      Visible         =   0   'False
      Width           =   255
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   375
      Left            =   3840
      TabIndex        =   10
      Top             =   2400
      Width           =   1695
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   375
      Left            =   960
      TabIndex        =   9
      Top             =   2400
      Width           =   1695
   End
   Begin VB.TextBox txtOther 
      Enabled         =   0   'False
      Height          =   315
      Left            =   2160
      TabIndex        =   8
      Top             =   1873
      Width           =   4095
   End
   Begin VB.OptionButton optDest 
      Caption         =   "Other:"
      Height          =   255
      Index           =   3
      Left            =   1320
      TabIndex        =   6
      Top             =   1920
      Width           =   4815
   End
   Begin VB.OptionButton optDest 
      Caption         =   "System Directory           <SysDir>"
      Height          =   255
      Index           =   2
      Left            =   1320
      TabIndex        =   5
      Tag             =   "<SysDir>"
      Top             =   1560
      Width           =   5055
   End
   Begin VB.OptionButton optDest 
      Caption         =   "Windows Directory        <WinDir>"
      Height          =   255
      Index           =   1
      Left            =   1320
      TabIndex        =   4
      Tag             =   "<WinDir>"
      Top             =   1200
      Width           =   5055
   End
   Begin VB.OptionButton optDest 
      Caption         =   "Application Directory     <AppPath>"
      Height          =   255
      Index           =   0
      Left            =   1320
      TabIndex        =   3
      Tag             =   "<AppPath>"
      Top             =   840
      Value           =   -1  'True
      Width           =   5055
   End
   Begin VB.CommandButton cmdBrowse 
      Caption         =   "&Browse..."
      Height          =   315
      Left            =   5400
      TabIndex        =   2
      Top             =   193
      Width           =   975
   End
   Begin VB.TextBox txtSourceFile 
      Height          =   315
      Left            =   1320
      TabIndex        =   1
      Top             =   193
      Width           =   3975
   End
   Begin VB.Label Label2 
      Caption         =   "Destination:"
      Height          =   255
      Left            =   240
      TabIndex        =   7
      Top             =   840
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "File Source:"
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   240
      Width           =   975
   End
End
Attribute VB_Name = "frmAddFile"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdBrowse_Click()
frmMain.CommonDialog.DialogTitle = "Browse for File"
frmMain.CommonDialog.Filter = "All Files (*.*)|*.*"
frmMain.CommonDialog.fileName = ""
frmMain.CommonDialog.ShowOpen
If frmMain.CommonDialog.fileName = "" Then Exit Sub
txtSourceFile.Text = frmMain.CommonDialog.fileName
End Sub

Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdOK_Click()
Dim fLI As ListItem
If txtSourceFile.Text = "" Then MsgBox "You must enter the location of the source file.", vbOKOnly + vbExclamation, "Source File": Exit Sub
If mFileExists(txtSourceFile.Text) = False Then MsgBox "The source file entered could not be accessed.", vbOKOnly + vbExclamation, "Source File": Exit Sub
If optDest(3).Value = True Then If txtOther.Text = "" Then MsgBox "You must enter the location to save the file to.", vbOKOnly + vbExclamation, "Destination": Exit Sub
If optDest(3).Value = True Then txtDestDir.Text = TrimSlash(txtDestDir.Text)
If GetItemIndex(frmMain.CreateInstall4_FileList, getFileName(txtSourceFile.Text)) > -1 Then MsgBox "The selected file has already been added to the file list. You can not add it again.", vbOKOnly + vbExclamation, "Add File": Exit Sub
Set fLI = frmMain.CreateInstall4_FileList.ListItems.Add(, , getFileName(txtSourceFile.Text))
fLI.ListSubItems.Add , , GetTrueDirName(txtSourceFile.Text, True, False)
fLI.ListSubItems.Add , , txtDestDir.Text
Unload Me
End Sub

Private Sub optDest_Click(Index As Integer)
txtOther.Enabled = optDest(3).Value
If Index <> 3 Then txtDestDir.Text = optDest(Index).Tag Else txtDestDir.Text = txtOther.Text
End Sub

Private Sub txtOther_Change()
txtDestDir.Text = txtOther.Text
End Sub

Private Sub txtSourceFile_Change()
If Right(txtSourceFile.Text, 4) = ".ocx" Or Right(txtSourceFile.Text, 4) = ".dll" Then
    optDest(2).Value = True
Else
    optDest(0).Value = True
End If
End Sub
