Attribute VB_Name = "supportData"
Public vbpFile As String
Public vbpDir As String
Public cPass_OK As Boolean

Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As Any, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Declare Function WritePrivateProfileString& Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal appName$, ByVal KeyName$, ByVal keydefault$, ByVal fileName$)

Public Function ReadDataFile(fileName As String) As Variant
On Error GoTo HandleError
Dim fileData() As String
Dim ln As Integer
ln = -1
Open fileName For Input As #1
Do Until (EOF(1))
ln = ln + 1
ReDim Preserve fileData(ln) As String
Input #1, fileData(ln)
Loop
ReadDataFile = fileData
Exit Function

HandleError:
ReDim Preserve fileData(0) As String
ReDim Preserve fileData(1) As String
ReDim Preserve fileData(2) As String
fileData(0) = "ERROR"
fileData(1) = Err.Description
fileData(2) = Err.Number
ReadDataFile = fileData
End Function

Sub Main()
frmMain.Show
End Sub

Public Function GetINIString(ByVal fileName As String, ByVal Section As String, ByVal Key As String)
    Dim ReturnValue As String
    Dim Successful As Integer
    ReturnValue = String$(255, 0)
    Successful = GetPrivateProfileString(Section, Key, "", ReturnValue, Len(ReturnValue), fileName)
    If Successful = 0 Then
        GetINIString = ""
    Else
        GetINIString = Left(ReturnValue, InStr(ReturnValue, Chr(0)) - 1)
    End If
End Function

Public Function WriteINIString(ByVal fileName As String, ByVal Section As String, ByVal Key As String, ByVal Value As String)
WritePrivateProfileString Section, Key, Value, fileName
End Function

Public Function TrimZeros(strTrim As String) As String
Do
    If Right(strTrim, 1) = "0" Then
        strTrim = Mid(strTrim, 1, Len(strTrim) - 1)
    ElseIf Right(strTrim, 1) = "." Then
        strTrim = Mid(strTrim, 1, Len(strTrim) - 1)
        If InStr(1, strTrim, ".") <= 0 Then Exit Do
    Else
        Exit Do
    End If
Loop
TrimZeros = strTrim
End Function

Public Function GetTrueDirName(fullDirName As String, Optional fNIncluded As Boolean, Optional includeFN As Boolean) As String
Dim trueDirName As String
Dim X As Integer
fullDirName = TrimSlash(fullDirName)
dirVars = Split(fullDirName, "\")
trueDirName = dirVars(0)
For X = 1 To (UBound(dirVars) - CInt(IIf(fNIncluded, 1, 0)))
If dirVars(X) = ".." Then
    trueDirName = Mid(trueDirName, 1, InStrRev(trueDirName, "\") - 1)
Else
    trueDirName = trueDirName & "\" & dirVars(X)
End If
Next X
If fNIncluded = True Then If includeFN = True Then trueDirName = trueDirName & "\" & dirVars(UBound(dirVars))
GetTrueDirName = trueDirName
End Function

Public Function TrimSlash(strTrim As String) As String
If Right(strTrim, 1) = "\" Then
    TrimSlash = Mid(strTrim, 1, Len(strTrim) - 1)
Else
    TrimSlash = strTrim
End If
End Function

Public Function getFileName(strFilePath As String) As String
getFileName = Mid(strFilePath, InStrRev(strFilePath, "\") + 1)
End Function

Public Function GetItemIndex(msList As MSComctlLib.ListView, itemName As String) As Integer
Dim X As Integer
For X = 1 To msList.ListItems.Count
If LCase(itemName) = LCase(msList.ListItems.Item(X).Text) Then GetItemIndex = X: Exit Function
Next X
GetItemIndex = -1
End Function
