VERSION 5.00
Begin VB.Form frmAddIcon 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Add Icon"
   ClientHeight    =   3225
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6615
   Icon            =   "frmAddIcon.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3225
   ScaleWidth      =   6615
   StartUpPosition =   1  'CenterOwner
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "Cancel"
      Height          =   495
      Left            =   3960
      TabIndex        =   8
      Top             =   2640
      Width           =   1695
   End
   Begin VB.CommandButton cmdOK 
      Caption         =   "OK"
      Default         =   -1  'True
      Height          =   495
      Left            =   960
      TabIndex        =   7
      Top             =   2640
      Width           =   1695
   End
   Begin VB.OptionButton exePathOther 
      Caption         =   "Other:"
      Height          =   255
      Left            =   1320
      TabIndex        =   5
      Top             =   2040
      Width           =   735
   End
   Begin VB.OptionButton exePathApp 
      Caption         =   "Application"
      Height          =   255
      Left            =   1320
      TabIndex        =   4
      Top             =   1670
      Value           =   -1  'True
      Width           =   5175
   End
   Begin VB.TextBox txtStartMenuGroup 
      Height          =   315
      Left            =   2760
      TabIndex        =   2
      Top             =   618
      Width           =   3735
   End
   Begin VB.ComboBox lstIconPath 
      Height          =   315
      ItemData        =   "frmAddIcon.frx":1272
      Left            =   1320
      List            =   "frmAddIcon.frx":127C
      Style           =   2  'Dropdown List
      TabIndex        =   1
      Top             =   193
      Width           =   5175
   End
   Begin VB.TextBox txtIconName 
      Height          =   315
      Left            =   1320
      TabIndex        =   3
      Top             =   1200
      Width           =   5175
   End
   Begin VB.TextBox txtIconPathOther 
      Enabled         =   0   'False
      Height          =   315
      Left            =   2080
      TabIndex        =   6
      Top             =   2003
      Width           =   4335
   End
   Begin VB.Label Label4 
      Caption         =   "Start Menu Group:"
      Height          =   255
      Left            =   1420
      TabIndex        =   11
      Top             =   675
      Width           =   1335
   End
   Begin VB.Label Label3 
      Caption         =   "Icon Path:"
      Height          =   255
      Left            =   240
      TabIndex        =   10
      Top             =   240
      Width           =   855
   End
   Begin VB.Label Label2 
      Caption         =   "Icon Name:"
      Height          =   255
      Left            =   240
      TabIndex        =   9
      Top             =   1245
      Width           =   855
   End
   Begin VB.Label Label1 
      Caption         =   "Executable:"
      Height          =   255
      Left            =   240
      TabIndex        =   0
      Top             =   1680
      Width           =   855
   End
End
Attribute VB_Name = "frmAddIcon"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub cmdCancel_Click()
Unload Me
End Sub

Private Sub cmdOK_Click()
If txtIconName.Text = "" Then MsgBox "You must enter the name of the icon.", vbOKOnly + vbExclamation, "Icon Name": Exit Sub
If exePathOther.Value = True Then If txtIconPathOther.Text = "" Then MsgBox "You must enter the path to the executable the icon is being created for.", vbOKOnly + vbExclamation, "Executable File": Exit Sub
If GetItemIndex(frmMain.CreateInstall5_RegEntries, lstIconPath.List(lstIconPath.ListIndex) & "\" & IIf(CBool(lstIconPath.ListIndex), "", txtStartMenuGroup.Text & "\") & "\" & txtIconName.Text) > -1 Then MsgBox "The icon has already been added. You may not add it again.", vbOKOnly + vbExclamation, "Add Icon": Exit Sub
Dim fLI As ListItem
Set fLI = frmMain.CreateInstall6_IconList.ListItems.Add(, , lstIconPath.List(lstIconPath.ListIndex) & "\" & IIf(CBool(lstIconPath.ListIndex), "", txtStartMenuGroup.Text & "\") & txtIconName.Text)
fLI.ListSubItems.Add , , IIf(exePathApp, "<AppPath>\" & getFileName(frmMain.CreateInstall3_AppEXE.Text), txtIconPathOther.Text)
Unload Me
End Sub

Private Sub exePathApp_Click()
txtIconPathOther.Enabled = False
End Sub

Private Sub exePathOther_Click()
txtIconPathOther.Enabled = True
End Sub

Private Sub Form_Load()
lstIconPath.ListIndex = 0
End Sub

Private Sub lstIconPath_Click()
If lstIconPath.ListIndex = 0 Then
    Label4.Visible = True
    txtStartMenuGroup.Visible = True
Else
    Label4.Visible = False
    txtStartMenuGroup.Visible = False
End If
End Sub
