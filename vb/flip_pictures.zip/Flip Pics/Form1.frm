VERSION 5.00
Begin VB.Form Form1 
   BackColor       =   &H00C0C0C0&
   Caption         =   "Picture Flipping"
   ClientHeight    =   4050
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   7440
   LinkTopic       =   "Form1"
   ScaleHeight     =   4050
   ScaleWidth      =   7440
   StartUpPosition =   1  'CenterOwner
   Begin VB.PictureBox Picture5 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   6360
      ScaleHeight     =   33
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   33
      TabIndex        =   9
      Top             =   3600
      Visible         =   0   'False
      Width           =   495
   End
   Begin VB.PictureBox Picture4 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   6360
      ScaleHeight     =   33
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   33
      TabIndex        =   8
      Top             =   3600
      Visible         =   0   'False
      Width           =   495
   End
   Begin VB.PictureBox Picture3 
      Appearance      =   0  'Flat
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   495
      Left            =   6240
      ScaleHeight     =   495
      ScaleWidth      =   615
      TabIndex        =   7
      Top             =   3600
      Visible         =   0   'False
      Width           =   615
   End
   Begin VB.CommandButton Command2 
      Caption         =   "Flip Vertical"
      Height          =   375
      Left            =   4200
      TabIndex        =   4
      Top             =   3600
      Width           =   2055
   End
   Begin VB.CommandButton Command3 
      Caption         =   "Flip Horizontal"
      Height          =   375
      Left            =   2160
      TabIndex        =   5
      Top             =   3600
      Width           =   2055
   End
   Begin VB.CommandButton Command1 
      Caption         =   "Resume Normal"
      Height          =   375
      Left            =   120
      TabIndex        =   6
      Top             =   3600
      Width           =   2055
   End
   Begin VB.ListBox YList 
      Height          =   255
      Left            =   6000
      TabIndex        =   3
      Top             =   3600
      Visible         =   0   'False
      Width           =   1935
   End
   Begin VB.ListBox XList 
      Height          =   255
      Left            =   6000
      TabIndex        =   2
      Top             =   3600
      Visible         =   0   'False
      Width           =   1935
   End
   Begin VB.PictureBox Picture2 
      Appearance      =   0  'Flat
      AutoRedraw      =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   555
      Left            =   6120
      ScaleHeight     =   37
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   39
      TabIndex        =   1
      Top             =   3600
      Visible         =   0   'False
      Width           =   585
   End
   Begin VB.PictureBox Picture1 
      Appearance      =   0  'Flat
      AutoSize        =   -1  'True
      BackColor       =   &H80000005&
      BorderStyle     =   0  'None
      ForeColor       =   &H80000008&
      Height          =   3405
      Left            =   120
      Picture         =   "Form1.frx":0000
      ScaleHeight     =   227
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   483
      TabIndex        =   0
      Top             =   120
      Width           =   7245
      Begin VB.Shape SelectBox 
         BorderStyle     =   3  'Dot
         DrawMode        =   6  'Mask Pen Not
         Height          =   375
         Left            =   120
         Top             =   120
         Visible         =   0   'False
         Width           =   495
      End
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim MD As Boolean
Dim XX, YY As Integer
Dim EndX, EndY As Integer
Dim X, Y As Long
Dim i As Integer

Private Sub Command1_Click()
Picture1.Picture = Picture3.Picture
End Sub

Private Sub Command2_Click()
Picture4.Cls
Call BitBlt(Picture4.hdc, 0, 0, SelectBox.Width - 2, SelectBox.Height - 2, Picture1.hdc, XX + 1, YY + 1, SRCAND)
Call BitBlt(Picture4.hdc, 0, 0, SelectBox.Width - 2, SelectBox.Height - 2, Picture1.hdc, XX + 1, YY + 1, SRCPAINT)
Picture4.Refresh

YList.Clear
For Y = 0 To EndY
    YList.AddItem Y
Next Y

Picture2.Cls
SelectBox.Visible = False
SelectBox.Refresh
Picture1.Refresh
For i = 0 To YList.ListCount - 1
    YList.ListIndex = i
    Call BitBlt(Picture2.hdc, 0, YList.Text, EndX, 1, Picture4.hdc, 0, EndY - i - 3, SRCAND)
    Call BitBlt(Picture2.hdc, 0, YList.Text, EndX, 1, Picture4.hdc, 0, EndY - i - 3, SRCPAINT)
Next i
Picture2.Refresh
Call BitBlt(Picture1.hdc, XX + 1, YY + 1, EndX - 2, EndY - 2, Picture2.hdc, 0, 0, SRCAND)
Call BitBlt(Picture1.hdc, XX + 1, YY + 1, EndX - 2, EndY - 2, Picture2.hdc, 0, 0, SRCPAINT)

Call BitBlt(Picture5.hdc, 0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, Picture1.hdc, 0, 0, SRCAND)
Call BitBlt(Picture5.hdc, 0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, Picture1.hdc, 0, 0, SRCPAINT)
Picture5.Refresh

Picture1.Picture = Picture5.Image

SelectBox.Visible = True
End Sub

Private Sub Command3_Click()
Picture4.Cls
Call BitBlt(Picture4.hdc, 0, 0, SelectBox.Width - 2, SelectBox.Height - 2, Picture1.hdc, XX + 1, YY + 1, SRCAND)
Call BitBlt(Picture4.hdc, 0, 0, SelectBox.Width - 2, SelectBox.Height - 2, Picture1.hdc, XX + 1, YY + 1, SRCPAINT)
Picture4.Refresh

XList.Clear
For X = 0 To EndX
    XList.AddItem X
Next X

Picture2.Cls
SelectBox.Visible = False
SelectBox.Refresh
Picture1.Refresh
For i = 0 To XList.ListCount - 1
    XList.ListIndex = i
    Call BitBlt(Picture2.hdc, XList.Text, 0, 1, EndY, Picture4.hdc, EndX - i - 3, 0, SRCAND)
    Call BitBlt(Picture2.hdc, XList.Text, 0, 1, EndY, Picture4.hdc, EndX - i - 3, 0, SRCPAINT)
Next i

Call BitBlt(Picture1.hdc, XX + 1, YY + 1, EndX - 2, EndY - 2, Picture2.hdc, 0, 0, SRCAND)
Call BitBlt(Picture1.hdc, XX + 1, YY + 1, EndX - 2, EndY - 2, Picture2.hdc, 0, 0, SRCPAINT)

Call BitBlt(Picture5.hdc, 0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, Picture1.hdc, 0, 0, SRCAND)
Call BitBlt(Picture5.hdc, 0, 0, Picture1.ScaleWidth, Picture1.ScaleHeight, Picture1.hdc, 0, 0, SRCPAINT)
Picture5.Refresh

Picture1.Picture = Picture5.Image

SelectBox.Visible = True
End Sub

Private Sub Form_Load()
Picture2.Width = Picture1.Width
Picture2.Height = Picture1.Height
Picture5.Width = Picture1.Width
Picture5.Height = Picture1.Height
Picture4.Width = Picture1.Width
Picture4.Height = Picture1.Height
Picture3.Picture = Picture1.Picture
End Sub

Private Sub Picture1_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
MD = True
SelectBox.Left = X
XX = X
SelectBox.Top = Y
YY = Y
SelectBox.Width = 0
SelectBox.Height = 0
SelectBox.Visible = True
End Sub

Private Sub Picture1_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
If MD = True Then
    If X <= XX Then
        SelectBox.Width = 5
    Else
        SelectBox.Width = X - SelectBox.Left
    End If
    If Y <= YY Then
        SelectBox.Height = 5
    Else
        SelectBox.Height = Y - SelectBox.Top
    End If
    Dim WW As Integer
    EndX = X - XX
    EndY = Y - YY
    End If
End Sub

Private Sub Picture1_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
MD = False
End Sub
