VERSION 5.00
Begin VB.Form frmHow 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "How To Play"
   ClientHeight    =   5340
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4755
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   5340
   ScaleWidth      =   4755
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdOK 
      Caption         =   "&Ok"
      Default         =   -1  'True
      Height          =   375
      Left            =   3360
      TabIndex        =   9
      Top             =   4800
      Width           =   1215
   End
   Begin VB.TextBox txtBonuses 
      Height          =   735
      Index           =   1
      Left            =   2520
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   8
      Text            =   "frmHow.frx":0000
      Top             =   3840
      Width           =   2055
   End
   Begin VB.PictureBox Picture3 
      AutoSize        =   -1  'True
      Height          =   510
      Left            =   120
      Picture         =   "frmHow.frx":008B
      ScaleHeight     =   450
      ScaleWidth      =   2250
      TabIndex        =   7
      Top             =   3840
      Width           =   2310
   End
   Begin VB.PictureBox Picture2 
      AutoSize        =   -1  'True
      Height          =   540
      Left            =   120
      Picture         =   "frmHow.frx":35C5
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   5
      Top             =   2400
      Width           =   540
   End
   Begin VB.TextBox txtOptions 
      Height          =   735
      Index           =   0
      Left            =   960
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   4
      Text            =   "frmHow.frx":3847
      Top             =   2400
      Width           =   3615
   End
   Begin VB.TextBox txtControl 
      Height          =   975
      Left            =   960
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   2
      Text            =   "frmHow.frx":39BB
      Top             =   600
      Width           =   3615
   End
   Begin VB.PictureBox Picture1 
      AutoSize        =   -1  'True
      Height          =   540
      Left            =   120
      Picture         =   "frmHow.frx":3A89
      ScaleHeight     =   480
      ScaleWidth      =   480
      TabIndex        =   1
      Top             =   600
      Width           =   540
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   11
      X1              =   135
      X2              =   4560
      Y1              =   4710
      Y2              =   4710
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   10
      X1              =   120
      X2              =   4560
      Y1              =   4680
      Y2              =   4680
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   9
      X1              =   135
      X2              =   4560
      Y1              =   3750
      Y2              =   3750
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   8
      X1              =   120
      X2              =   4560
      Y1              =   3720
      Y2              =   3720
   End
   Begin VB.Label Label3 
      Caption         =   "Bonuses"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   3480
      Width           =   1815
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   7
      X1              =   135
      X2              =   4560
      Y1              =   3390
      Y2              =   3390
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   6
      X1              =   120
      X2              =   4560
      Y1              =   3360
      Y2              =   3360
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   5
      X1              =   135
      X2              =   4560
      Y1              =   2190
      Y2              =   2190
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   4
      X1              =   120
      X2              =   4560
      Y1              =   2160
      Y2              =   2160
   End
   Begin VB.Label Label2 
      Caption         =   "Options:"
      Height          =   375
      Left            =   120
      TabIndex        =   3
      Top             =   1920
      Width           =   2175
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   3
      X1              =   135
      X2              =   4560
      Y1              =   1830
      Y2              =   1830
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   2
      X1              =   120
      X2              =   4560
      Y1              =   1800
      Y2              =   1800
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   1
      X1              =   135
      X2              =   4560
      Y1              =   390
      Y2              =   390
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   0
      X1              =   120
      X2              =   4560
      Y1              =   360
      Y2              =   360
   End
   Begin VB.Label Label1 
      Caption         =   "Controls"
      Height          =   255
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   2415
   End
End
Attribute VB_Name = "frmHow"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdOK_Click()
  Unload Me
End Sub

