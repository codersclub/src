VERSION 5.00
Begin VB.Form frmOptions 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Options"
   ClientHeight    =   2490
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   3420
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2490
   ScaleWidth      =   3420
   StartUpPosition =   3  'Windows Default
   Begin VB.CheckBox chkPlayer 
      Caption         =   "Player - Enemy Collisions"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   840
      Value           =   1  'Checked
      Width           =   2775
   End
   Begin VB.HScrollBar lvlScroll 
      Height          =   210
      Left            =   135
      Max             =   20
      Min             =   1
      TabIndex        =   5
      Top             =   1515
      Value           =   1
      Width           =   3210
   End
   Begin VB.CommandButton Command1 
      Cancel          =   -1  'True
      Caption         =   "&Cancel"
      Height          =   390
      Left            =   2475
      TabIndex        =   3
      Top             =   1950
      Width           =   870
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "&Ok"
      Default         =   -1  'True
      Height          =   390
      Left            =   1545
      TabIndex        =   2
      Top             =   1950
      Width           =   870
   End
   Begin VB.CheckBox chkEnemy 
      Caption         =   "Enemy Collisions (Not Recomended)"
      Height          =   270
      Left            =   120
      TabIndex        =   1
      Top             =   540
      Width           =   3165
   End
   Begin VB.CheckBox chkSound 
      Caption         =   "Play Sounds"
      Height          =   270
      Left            =   120
      TabIndex        =   0
      Top             =   225
      Value           =   1  'Checked
      Width           =   2940
   End
   Begin VB.Label lblLevel 
      Caption         =   "Starting Level"
      Height          =   315
      Left            =   135
      TabIndex        =   4
      Top             =   1245
      Width           =   3150
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   1
      X1              =   90
      X2              =   3345
      Y1              =   1830
      Y2              =   1830
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   0
      X1              =   75
      X2              =   3330
      Y1              =   1800
      Y2              =   1800
   End
End
Attribute VB_Name = "frmOptions"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim OptionsPause As Boolean
Private Sub cmdOK_Click()
  Sound = chkSound.Value
  EnemyCollisions = chkEnemy.Value
  StartingLevel = lvlScroll.Value
  PECollisions = chkPlayer.Value
  writeini "options", "sound", chkSound.Value, App.Path & "/vbspace.ini"
  writeini "options", "enemy", chkEnemy.Value, App.Path & "/vbspace.ini"
  writeini "options", "player", chkPlayer.Value, App.Path & "/vbspace.ini"
  writeini "Level", "level", lvlScroll.Value, App.Path & "/vbspace.ini"
  Unload Me
End Sub

Private Sub HScroll1_Change()
  
End Sub

Private Sub Command1_Click()
  Unload Me
End Sub

Private Sub Form_Load()
  If IsPaused = False Then
    If frmMain.tmrGame.Enabled = True Then
      IsPaused = True
      OptionsPause = True
      frmMain.tmrGame.Enabled = False
    End If
  End If
End Sub

Private Sub Form_Unload(Cancel As Integer)
  If OptionsPause = True Then
    frmMain.tmrGame.Enabled = True
    IsPaused = False
    OptionsPause = False
  End If
End Sub

Private Sub lvlScroll_Change()
  lblLevel.Caption = "Starting Level: " & lvlScroll.Value
End Sub

Private Sub lvlScroll_Scroll()
  lblLevel.Caption = "Starting Level: " & lvlScroll.Value
End Sub
