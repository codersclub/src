VERSION 5.00
Begin VB.Form frmShip 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Choose Your Ship"
   ClientHeight    =   3585
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6285
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3585
   ScaleWidth      =   6285
   StartUpPosition =   2  'CenterScreen
   Begin VB.OptionButton optShip 
      Caption         =   "Ship 1"
      Height          =   1455
      Index           =   2
      Left            =   120
      Picture         =   "frmShip.frx":0000
      Style           =   1  'Graphical
      TabIndex        =   5
      Top             =   105
      Width           =   1935
   End
   Begin VB.CommandButton Command1 
      Caption         =   "&Ok"
      Default         =   -1  'True
      Height          =   450
      Left            =   4185
      TabIndex        =   4
      Top             =   3015
      Width           =   930
   End
   Begin VB.CommandButton cmdCancel 
      Caption         =   "&Cancel"
      Height          =   450
      Left            =   5205
      TabIndex        =   3
      Top             =   3015
      Width           =   930
   End
   Begin VB.TextBox lblInfo 
      Height          =   1095
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   2
      Top             =   1680
      Width           =   6015
   End
   Begin VB.OptionButton optShip 
      Caption         =   "Ship 3"
      Height          =   1455
      Index           =   1
      Left            =   4185
      Picture         =   "frmShip.frx":08F2
      Style           =   1  'Graphical
      TabIndex        =   1
      Top             =   105
      Width           =   1935
   End
   Begin VB.OptionButton optShip 
      Caption         =   "Ship 2"
      Height          =   1455
      Index           =   0
      Left            =   2160
      Picture         =   "frmShip.frx":2734
      Style           =   1  'Graphical
      TabIndex        =   0
      Top             =   105
      Width           =   1935
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   1
      X1              =   135
      X2              =   6075
      Y1              =   2910
      Y2              =   2910
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   0
      X1              =   120
      X2              =   6015
      Y1              =   2880
      Y2              =   2880
   End
End
Attribute VB_Name = "frmShip"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
  Unload Me
End Sub

Private Sub Command1_Click()
  If optShip(0).Value = True Then
    CurrShip = 0
  ElseIf optShip(1).Value = True Then
    CurrShip = 1
  Else
    CurrShip = 2
  End If
  
  Unload Me
  frmMain.StartGame
End Sub

Private Sub Form_Load()
  lblInfo.Text = "Ship Name: " & vbCrLf & "Speed: " & vbCrLf & "Hull: " & vbCrLf & "Shields: " & vbCrLf & "Shots: "
End Sub

Private Sub optShip_Click(Index As Integer)
  Select Case Index
    Case 0
      lblInfo.Text = "Ship Name: Executioner" & vbCrLf & "Speed: 10" & vbCrLf & "Hull: 2500" & vbCrLf & "Shields: 500" & vbCrLf & "Shots: 20" & vbCrLf & vbCrLf & "Details: This is a good ship. It is basicly in the middle of two extremes. It has a descent ammount of shielding and speed."
    Case 1
      lblInfo.Text = "Ship Name: Dreadnaut" & vbCrLf & "Speed: 3" & vbCrLf & "Hull: 5000" & vbCrLf & "Shields: 1000" & vbCrLf & "Shots: 40" & vbCrLf & vbCrLf & "Details: This is a dreadnaught class ship. It is extremly slow but heavily armed and it can take a beating."
    Case 2
      lblInfo.Text = "Ship Name: Speeder" & vbCrLf & "Speed: 12" & vbCrLf & "Hull: 1500" & vbCrLf & "Shields: 250" & vbCrLf & "Shots: 10" & vbCrLf & vbCrLf & "Details: This is a small extremly fast ship. It's lightly armed and armored though so it's pilot must be quick and rely on the ships small size to avoid enemies"
  End Select
End Sub
