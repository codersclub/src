VERSION 5.00
Begin VB.Form frmSplash 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "VB Space Shooter"
   ClientHeight    =   2100
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   5190
   ControlBox      =   0   'False
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2100
   ScaleWidth      =   5190
   StartUpPosition =   2  'CenterScreen
   Begin VB.Timer Timer1 
      Interval        =   1
      Left            =   75
      Top             =   915
   End
   Begin VB.CommandButton cmdCancel 
      Cancel          =   -1  'True
      Caption         =   "&Exit"
      Enabled         =   0   'False
      Height          =   375
      Left            =   4065
      TabIndex        =   2
      Top             =   1605
      Width           =   960
   End
   Begin VB.CommandButton cmdOk 
      Caption         =   "&OK"
      Default         =   -1  'True
      Enabled         =   0   'False
      Height          =   375
      Left            =   2955
      TabIndex        =   1
      Top             =   1605
      Width           =   960
   End
   Begin VB.PictureBox Picture1 
      Height          =   1290
      Left            =   180
      Picture         =   "frmSplash.frx":0000
      ScaleHeight     =   1230
      ScaleWidth      =   4845
      TabIndex        =   0
      Top             =   105
      Width           =   4905
      Begin VB.Image Image1 
         Height          =   945
         Left            =   375
         Picture         =   "frmSplash.frx":91D82
         Top             =   180
         Width           =   4125
      End
   End
   Begin VB.Label lblInfo 
      Height          =   330
      Left            =   120
      TabIndex        =   3
      Top             =   1620
      Width           =   2730
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00808080&
      Index           =   0
      X1              =   300
      X2              =   4935
      Y1              =   1500
      Y2              =   1500
   End
   Begin VB.Line Line1 
      BorderColor     =   &H00FFFFFF&
      Index           =   1
      X1              =   315
      X2              =   4935
      Y1              =   1530
      Y2              =   1530
   End
End
Attribute VB_Name = "frmSplash"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False

Private Sub cmdCancel_Click()
  Unload Me
  End
End Sub

Private Sub cmdOK_Click()
  Unload Me
  frmMain.Show
End Sub

Private Sub Timer1_Timer()
  On Error Resume Next
  DoEvents
  lblInfo.Caption = "Loading Forms"

  Load frmMain
  Load frmOptions
  Load frmShip
  Load frmHow
  Load frmAbout
  DoEvents
  lblInfo.Caption = "Reading Ini"
  EnemyCollisions = ReadINI("options", "enemy", App.Path & "\vbspace.ini")
  Sound = ReadINI("options", "sound", App.Path & "\vbspace.ini")
  PECollisions = ReadINI("options", "player", App.Path & "\vbspace.ini")
  StartingLevel = ReadINI("level", "level", App.Path & "\vbspace.ini")
  If EnemyCollisions = True Then
    frmOptions.chkEnemy.Value = 1
  Else
    frmOptions.chkEnemy.Value = 0
  End If
  If Sound = True Then
    frmOptions.chkSound.Value = 1
  Else
    frmOptions.chkSound.Value = 0
  End If
  If PECollisions = True Then
    frmOptions.chkPlayer.Value = 1
  Else
    frmOptions.chkPlayer.Value = 0
  End If
  frmOptions.lblLevel = "Starting Level: " & StartingLevel
  frmOptions.lvlScroll.Value = StartingLevel
  DoEvents
  lblInfo.Caption = "Reading Top Scores"
  ReadTopScores
  DoEvents
  lblInfo.Caption = "Complete"
  cmdOk.Enabled = True
  cmdCancel.Enabled = True
  Timer1.Enabled = False
  If Err Then MsgBox "Error: " & Err.Number & Chr(10) & Err.Description, vbOKOnly + vbCritical, "Error: " & Err.Number
End Sub
