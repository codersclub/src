VERSION 5.00
Begin VB.Form frmMain 
   AutoRedraw      =   -1  'True
   BackColor       =   &H00000000&
   BorderStyle     =   1  'Fixed Single
   Caption         =   "VB Space Invaders"
   ClientHeight    =   7605
   ClientLeft      =   150
   ClientTop       =   435
   ClientWidth     =   8430
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7605
   ScaleWidth      =   8430
   StartUpPosition =   2  'CenterScreen
   Begin VB.PictureBox picSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   510
      Index           =   2
      Left            =   2535
      Picture         =   "frmMain.frx":0000
      ScaleHeight     =   30
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   148
      TabIndex        =   30
      Top             =   1080
      Visible         =   0   'False
      Width           =   2280
   End
   Begin VB.PictureBox picMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   510
      Index           =   2
      Left            =   300
      Picture         =   "frmMain.frx":344A
      ScaleHeight     =   30
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   148
      TabIndex        =   29
      Top             =   1110
      Visible         =   0   'False
      Width           =   2280
   End
   Begin VB.PictureBox picMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   1020
      Index           =   1
      Left            =   -180
      Picture         =   "frmMain.frx":6894
      ScaleHeight     =   64
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   408
      TabIndex        =   26
      Top             =   1650
      Visible         =   0   'False
      Width           =   6180
   End
   Begin VB.PictureBox picSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   1020
      Index           =   1
      Left            =   -495
      Picture         =   "frmMain.frx":19AD6
      ScaleHeight     =   64
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   408
      TabIndex        =   25
      Top             =   540
      Visible         =   0   'False
      Width           =   6180
   End
   Begin VB.Frame Frame4 
      BackColor       =   &H00000000&
      Caption         =   "Current Level"
      ForeColor       =   &H00FFC0C0&
      Height          =   900
      Left            =   6375
      TabIndex        =   23
      Top             =   5475
      Width           =   2025
      Begin VB.Label lblLevel 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   405
         Left            =   105
         TabIndex        =   24
         Top             =   300
         Width           =   1845
      End
   End
   Begin VB.PictureBox shieldMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   510
      Left            =   45
      Picture         =   "frmMain.frx":2CD18
      ScaleHeight     =   30
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   150
      TabIndex        =   22
      Top             =   2130
      Visible         =   0   'False
      Width           =   2310
   End
   Begin VB.PictureBox shieldSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   510
      Left            =   30
      Picture         =   "frmMain.frx":30252
      ScaleHeight     =   30
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   150
      TabIndex        =   21
      Top             =   1590
      Visible         =   0   'False
      Width           =   2310
   End
   Begin VB.Frame Frame3 
      BackColor       =   &H00000000&
      Caption         =   "Score"
      ForeColor       =   &H00FFC0C0&
      Height          =   900
      Left            =   6375
      TabIndex        =   19
      Top             =   4485
      Width           =   2025
      Begin VB.Label Label4 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   18
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   405
         Left            =   120
         TabIndex        =   20
         Top             =   285
         Width           =   1845
      End
   End
   Begin VB.PictureBox ExplodeSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   855
      Left            =   75
      Picture         =   "frmMain.frx":3378C
      ScaleHeight     =   53
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   398
      TabIndex        =   16
      Top             =   5220
      Visible         =   0   'False
      Width           =   6030
   End
   Begin VB.PictureBox ExplodeMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   855
      Left            =   60
      Picture         =   "frmMain.frx":42F6A
      ScaleHeight     =   53
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   398
      TabIndex        =   15
      Top             =   4140
      Visible         =   0   'False
      Width           =   6030
   End
   Begin VB.PictureBox EnemySprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   2340
      Left            =   1470
      Picture         =   "frmMain.frx":52748
      ScaleHeight     =   152
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   62
      TabIndex        =   14
      Top             =   1170
      Visible         =   0   'False
      Width           =   990
   End
   Begin VB.PictureBox EnemyMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   2340
      Left            =   345
      Picture         =   "frmMain.frx":5972A
      ScaleHeight     =   152
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   62
      TabIndex        =   13
      Top             =   1155
      Visible         =   0   'False
      Width           =   990
   End
   Begin VB.Frame Frame2 
      BackColor       =   &H00000000&
      Caption         =   "Shots"
      ForeColor       =   &H00FFC0C0&
      Height          =   990
      Left            =   6360
      TabIndex        =   10
      Top             =   3420
      Width           =   2025
      Begin VB.PictureBox PicShots 
         AutoRedraw      =   -1  'True
         BackColor       =   &H00000000&
         BorderStyle     =   0  'None
         Height          =   660
         Left            =   225
         ScaleHeight     =   44
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   111
         TabIndex        =   11
         Top             =   240
         Width           =   1665
      End
      Begin VB.Label Label1 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   315
         Left            =   300
         TabIndex        =   12
         Top             =   1950
         Width           =   1485
      End
   End
   Begin VB.Frame Frame1 
      BackColor       =   &H00000000&
      Caption         =   "Shields"
      ForeColor       =   &H00FFC0C0&
      Height          =   3225
      Left            =   6345
      TabIndex        =   7
      Top             =   105
      Width           =   2040
      Begin VB.PictureBox picShields 
         AutoSize        =   -1  'True
         BackColor       =   &H00000000&
         BorderStyle     =   0  'None
         Height          =   450
         Left            =   750
         ScaleHeight     =   30
         ScaleMode       =   3  'Pixel
         ScaleWidth      =   37
         TabIndex        =   8
         Top             =   1290
         Width           =   555
      End
      Begin VB.Label Label3 
         Alignment       =   2  'Center
         BackColor       =   &H0000FF00&
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   375
         Left            =   120
         TabIndex        =   18
         Top             =   2760
         Width           =   1875
      End
      Begin VB.Label Label2 
         BackStyle       =   0  'Transparent
         Caption         =   "Hull:"
         ForeColor       =   &H00FFC0C0&
         Height          =   240
         Left            =   150
         TabIndex        =   17
         Top             =   2520
         Width           =   1590
      End
      Begin VB.Label lblShields 
         Alignment       =   2  'Center
         BackStyle       =   0  'Transparent
         BeginProperty Font 
            Name            =   "MS Sans Serif"
            Size            =   13.5
            Charset         =   0
            Weight          =   400
            Underline       =   0   'False
            Italic          =   0   'False
            Strikethrough   =   0   'False
         EndProperty
         ForeColor       =   &H0000FF00&
         Height          =   315
         Left            =   300
         TabIndex        =   9
         Top             =   1950
         Width           =   1485
      End
      Begin VB.Shape ShpShield 
         BorderColor     =   &H0000FF00&
         Height          =   1980
         Left            =   90
         Shape           =   2  'Oval
         Top             =   495
         Width           =   1875
      End
   End
   Begin VB.PictureBox ShotMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   210
      Left            =   435
      Picture         =   "frmMain.frx":6070C
      ScaleHeight     =   10
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   10
      TabIndex        =   6
      Top             =   0
      Visible         =   0   'False
      Width           =   210
   End
   Begin VB.PictureBox ShotSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   210
      Left            =   0
      Picture         =   "frmMain.frx":6088E
      ScaleHeight     =   10
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   10
      TabIndex        =   5
      Top             =   15
      Visible         =   0   'False
      Width           =   210
   End
   Begin VB.PictureBox picBuf 
      AutoRedraw      =   -1  'True
      Height          =   4110
      Left            =   6420
      ScaleHeight     =   270
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   453
      TabIndex        =   4
      Top             =   90
      Visible         =   0   'False
      Width           =   6855
   End
   Begin VB.PictureBox picMask 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   945
      Index           =   0
      Left            =   2280
      Picture         =   "frmMain.frx":60A10
      ScaleHeight     =   59
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   216
      TabIndex        =   3
      Top             =   600
      Visible         =   0   'False
      Width           =   3300
   End
   Begin VB.PictureBox picSprite 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   945
      Index           =   0
      Left            =   2640
      Picture         =   "frmMain.frx":69FAA
      ScaleHeight     =   59
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   216
      TabIndex        =   2
      Top             =   1560
      Visible         =   0   'False
      Width           =   3300
   End
   Begin VB.PictureBox picBack 
      AutoRedraw      =   -1  'True
      AutoSize        =   -1  'True
      Height          =   7380
      Left            =   6555
      Picture         =   "frmMain.frx":73544
      ScaleHeight     =   488
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   407
      TabIndex        =   1
      Top             =   4425
      Visible         =   0   'False
      Width           =   6165
   End
   Begin VB.PictureBox picField 
      Height          =   7380
      Left            =   120
      ScaleHeight     =   488
      ScaleMode       =   3  'Pixel
      ScaleWidth      =   407
      TabIndex        =   0
      Top             =   105
      Width           =   6165
      Begin VB.PictureBox clrPic 
         Height          =   855
         Left            =   2880
         ScaleHeight     =   795
         ScaleWidth      =   795
         TabIndex        =   28
         Top             =   2880
         Visible         =   0   'False
         Width           =   855
      End
      Begin VB.PictureBox TempShip2 
         AutoSize        =   -1  'True
         Height          =   1020
         Left            =   3720
         Picture         =   "frmMain.frx":1052C6
         ScaleHeight     =   960
         ScaleWidth      =   1530
         TabIndex        =   27
         Top             =   3000
         Visible         =   0   'False
         Width           =   1590
      End
      Begin VB.Timer tmrGame 
         Enabled         =   0   'False
         Interval        =   20
         Left            =   4110
         Top             =   5145
      End
   End
   Begin VB.Menu File 
      Caption         =   "&File"
      Begin VB.Menu new 
         Caption         =   "&New Game"
         Shortcut        =   ^N
      End
      Begin VB.Menu options 
         Caption         =   "&Options"
         Shortcut        =   ^O
      End
      Begin VB.Menu bar0 
         Caption         =   "-"
      End
      Begin VB.Menu pause 
         Caption         =   "&Pause"
         Shortcut        =   {F3}
      End
      Begin VB.Menu bar3 
         Caption         =   "-"
      End
      Begin VB.Menu high 
         Caption         =   "&High Scores"
      End
      Begin VB.Menu bar1 
         Caption         =   "-"
      End
      Begin VB.Menu exit 
         Caption         =   "&Exit"
      End
   End
   Begin VB.Menu help 
      Caption         =   "Help"
      Begin VB.Menu readme 
         Caption         =   "&Readme"
         Shortcut        =   ^R
      End
      Begin VB.Menu how 
         Caption         =   "&How To Play"
      End
      Begin VB.Menu bar5 
         Caption         =   "-"
      End
      Begin VB.Menu about 
         Caption         =   "&About"
         Shortcut        =   ^A
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Dim IsPlaying As Boolean


Private Sub exit_Click()
  Unload Me
End Sub

Private Sub Form_Load()
  picBuf.Width = picBack.Width
  picBuf.Height = picBack.Height
  IsPlaying = False
  TileBitmap Me, picBack
End Sub

Private Sub Form_Unload(Cancel As Integer)
  Unload Me
  End
End Sub

Private Sub high_Click()
  frmHigh.Show
End Sub

Private Sub how_Click()
  frmHow.Show
End Sub

Private Sub new_Click()
  frmShip.Show
End Sub

Private Sub options_Click()
  frmOptions.Show
End Sub

Private Sub pause_Click()
  If IsPaused = False Then
    IsPaused = True
    tmrGame.Enabled = False
  Else
    IsPaused = False
    tmrGame.Enabled = True
  End If
End Sub

Private Sub Picture1_Click()

End Sub

Private Sub start_Click()

  If start.Caption = "Start" Then
    start.Caption = "Stop"
    StartGame
  Else
    start.Caption = "Start"
    tmrGame.Enabled = False
    AnimNum(0) = 0
  End If
End Sub

Public Function GameLoop()

End Function

Private Sub Timer1_Timer()

End Sub


Private Sub tmrGame_Timer()
  AnimTick(0) = GetTickCount()
'  If CurrShot(0) < 0 Then
'    CurrShot(0) = 0
'  End If
  Ship(0).right = (Ship(0).Left + ShipWidth(CurrShip))
  If AnimTick(0) - LastTick(0) > AnimaTick Then
    AnimNum(0) = (AnimNum(0) Mod AnimMax) + 1
    LastTick(0) = GetTickCount()
  End If
  If GetAsyncKeyState(GoLeft) Then
  If Ship(0).Left - MoveSpeed >= 0 Then
    Ship(0).Left = Ship(0).Left - MoveSpeed
  End If
  End If
  If GetAsyncKeyState(GoRight) Then
  If ((Ship(0).Left + ShipWidth(CurrShip)) + MoveSpeed) <= picBuf.ScaleWidth Then
    Ship(0).Left = Ship(0).Left + MoveSpeed
  End If
  End If
  If GetAsyncKeyState(GoForward) Then
  If ((Ship(0).Top > (picBuf.ScaleHeight - (ShipHeight(CurrShip) * 3)))) Then
    Ship(0).Top = Ship(0).Top - MoveSpeed
  End If
  End If
  If GetAsyncKeyState(GoBack) Then
  If ((Ship(0).Top + ShipHeight(CurrShip) + MoveSpeed) < (picBuf.ScaleHeight)) Then
    Ship(0).Top = Ship(0).Top + MoveSpeed
  End If
  End If

  If GetAsyncKeyState(CheatKeys) Then
    cheatString = InputBox("What cheat do you wish to use?", "Cheater!!!")
  End If
  If GetAsyncKeyState(DoShoot) Then
  If AnimTick(0) - FireTick(0) > ShotTick Then
   If CurrShot(0) < MaxShot Then
    FireTick(0) = GetTickCount()
    YouFire
    PlayWav "fire.wav"
   End If
  End If
  End If
  DrawBack
  DrawYou
  Randomize Timer
  If Int(Rnd * 100) > CurrLevel * 4 Then
   DrawPickUps
  End If
  UpdatePickUps
  LightEnemyUpdate
  DrawLightEnemy
  UpdateYourShots
  Collide
  UpdateExplosions
  BackBufToFront
  ShieldCheck
  DisplayRounds
End Sub

Public Function StartGame()
    tmrGame.Enabled = True
    Ship(0).Top = picField.Top + picField.ScaleHeight - 180
    Ship(0).Left = (picBuf.ScaleWidth - ShipWidth(CurrShip)) \ 2
    AnimNum(0) = 1
    CurrShot(0) = 0
    LastShot(0) = GetTickCount()
    LastTick(0) = GetTickCount()
    FireTick(0) = GetTickCount()
    ShipWidth(0) = 54
    ShipHeight(0) = 59
    ShipWidth(1) = 102
    ShipHeight(1) = 64
    ShipWidth(2) = 37
    ShipHeight(2) = 30
    BackScrollY1 = 0
    CurrEnemies = 0
    If CurrShip = 0 Then
      MaxShot = 20
      MoveSpeed = 10
      Ship(0).shield = 500
      Ship(0).hit = 2500
      Ship(0).max_hit = 2500
      Ship(0).max_shield = 500
      picShields.Width = 960
      picShields.Height = 915
      picShields.Left = 630
      picShields.Top = 1050
      
    ElseIf CurrShip = 1 Then
      MaxShot = 40
      MoveSpeed = 3
      Ship(0).max_hit = 5000
      Ship(0).hit = 5000
      Ship(0).max_shield = 1000
      Ship(0).shield = 1000
      picShields.Left = 270
      picShields.Top = 990
      picShields.Width = 1530
      picShields.Height = 960
    ElseIf CurrShip = 2 Then
      MaxShot = 10
      MoveSpeed = 12
      Ship(0).max_hit = 1500
      Ship(0).hit = 1500
      Ship(0).shield = 250
      Ship(0).max_shield = 250
      picShields.Left = 750
      picShields.Top = 1290
      picShields.Width = 555
      picShields.Height = 450
    
    End If
    BackScrollY2 = 0 - picBuf.ScaleHeight
    Enemy(0).Velocity = MaxVelocity

    Score = 0
    PickUp.isMoving = False
    LastTick(1) = GetTickCount()
    CurrEnemies = 1
    For x = 0 To MaxEnemy
      Enemy(x).isMoving = False
    Next
    IsPaused = False
End Function

Public Function ShieldCheck()
  If Ship(0).shield > 475 Then
    ShpShield.BorderColor = &HFF00&
  ElseIf Ship(0).shield <= 475 And Ship(0).shield > 400 Then
    ShpShield.BorderColor = &HFFFF&
    lblShields.ForeColor = &HFFFF&
  ElseIf Ship(0).shield <= 400 And Ship(0).shield > 300 Then
    ShpShield.BorderColor = &H80FF&
    lblShields.ForeColor = &H80FF&
  ElseIf Ship(0).shield <= 300 And Ship(0).shield > 200 Then
    ShpShield.BorderColor = &HFF&
    lblShields.ForeColor = &HFF&
  ElseIf Ship(0).shield <= 200 And Ship(0).shield > 100 Then
    ShpShield.BorderColor = &H80&
    lblShields.ForeColor = &H80&
  ElseIf Ship(0).shield <= 100 And Ship(0).shield > 1 Then
    ShpShield.BorderColor = &H808080
    lblShields.ForeColor = &H808080
  Else
    ShpShield.BorderColor = vbBlack
    lblShields.ForeColor = vbRed
  End If
  x = ((Ship(0).shield / Ship(0).max_shield) * 100)
  If x < 0 Then
    x = 0
  End If
  CurrLevel = StartingLevel
  lblShields.Caption = x & "%"
  Label3.Caption = Ship(0).hit & "/" & Ship(0).max_hit
  Label4.Caption = Score
  
  If Score >= (CurrLevel * 1000) Then
    CurrLevel = CurrLevel + 1
  End If
  lblLevel.Caption = CurrLevel
  
End Function
