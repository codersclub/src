Attribute VB_Name = "modMain"
Option Explicit
Public Declare Function sndPlaySound Lib "winmm.dll" Alias "sndPlaySoundA" (ByVal lpszSoundName As String, ByVal uFlags As Long) As Long
Public Declare Function BitBlt Lib "gdi32" (ByVal hDestDC As Long, ByVal x As Long, ByVal Y As Long, ByVal nWidth As Long, ByVal nHeight As Long, ByVal hSrcDC As Long, ByVal xSrc As Long, ByVal ySrc As Long, ByVal dwRop As Long) As Long
Public Declare Function GetAsyncKeyState Lib "user32" (ByVal vKey As Long) As Integer
Public Declare Function GetTickCount Lib "kernel32" () As Long
Declare Function GetPrivateProfileString Lib "kernel32" Alias "GetPrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpDefault As String, ByVal lpReturnedString As String, ByVal nSize As Long, ByVal lpFileName As String) As Long
Declare Function WritePrivateProfileString Lib "kernel32" Alias "WritePrivateProfileStringA" (ByVal lpApplicationName As String, ByVal lpKeyName As String, ByVal lpString As Any, ByVal lpFileName As String) As Long


Type Ship_Data
  Left As Long
  right As Long
  Top As Long
  bottom As Long
  hit As Double
  shield As Double
  max_shield As Double
  max_hit As Double
  Velocity As Long
  isMoving As Boolean
  CurrFrame As Integer
End Type

Type Pickup_Data
  Left As Integer
  Top As Integer
  Type As Integer
  isMoving As Boolean
End Type

Type Explosion_Data
  x As Long
  Y As Long
  CurrFrame As Integer
  IsExploding As Boolean
End Type

Type Shot_Data
  Left As Long
  Top As Long
  isMoving As Boolean
End Type

Type TopScore_Data
  Name As String
  Score As Long
  Level As Integer
End Type

'Constants
Public Const AnimaTick = 200
Public Const EnimAnimTick = 150
Public Const ShotTick = 100
Public Const AnimMax = 3
Public Const MaxExpFrame = 6
Public Const GoLeft = &H25
Public Const GoRight = &H27
Public Const GoForward = &H26
Public Const GoBack = &H28
Public Const DoShoot = &H20

Public Const Velocity = 20
Public Const PickUpWidth = 30
Public Const PickupHeight = 30
Public Const CheatKeys = &H11 + &H10
Public Const MaxLevel = 50
Public Const MaxEnemy = 4
Public Const MaxVelocity = 10
Public Const MinVelocity = 5
Public Const SpriteWidth = 62
Public Const EnemyHeight = 38
Public Const ExplodeHeight = 53
Public Const ExplodeWidth = 51
Public Const ExplodeFrames = 6
Public Const ExplodeTick = 25
Public Const MaxExplosions = 10
Public Const MaxEnemyShots = 100


'Global Variables
Public AnimNum(4) As Integer
Public Ship(4) As Ship_Data
Public Enemy(8) As Ship_Data
Public AnimTick(4) As Long
Public LastTick(4) As Long
Public FireTick(4) As Long
Public LastShot(4) As Long
Public CurrTick(4) As Long
Public CurrShot(4) As Integer
Public Shot(40) As Shot_Data
Public BackScrollY1 As Integer
Public BackScrollY2 As Integer
Public CurrEnemies As Integer
Public ExplodeTicks As Long
Public LastExplode As Long
Public Explosion(10) As Explosion_Data
Public Score As Long
Public eShot(100) As Shot_Data
Public NumExplosions As Integer
Public PickUp As Pickup_Data
Public PickUps As Integer
Public Sound As Boolean
Public EnemyCollisions As Boolean
Public IsPaused As Boolean
Public StartingLevel As Integer
Public CurrLevel As Integer
Public TopScores(9) As TopScore_Data
Public PECollisions As Boolean
Public ShipWidth(2) As Integer
Public ShipHeight(2) As Integer
Public CurrShip As Integer
Public MaxShot As Integer
Public MoveSpeed As Integer


Public Function DrawYou()
  Dim ua As Long
  ua = BitBlt(frmMain.picBuf.hDC, Ship(0).Left, Ship(0).Top, ShipWidth(CurrShip), 59, frmMain.picMask(CurrShip).hDC, AnimNum(0) * ShipWidth(CurrShip), 0, vbSrcAnd)
  ua = BitBlt(frmMain.picBuf.hDC, Ship(0).Left, Ship(0).Top, ShipWidth(CurrShip), ShipHeight(CurrShip), frmMain.picSprite(CurrShip).hDC, AnimNum(0) * ShipWidth(CurrShip), 0, vbSrcPaint)
  ua = BitBlt(frmMain.picShields.hDC, 0, 0, ShipWidth(CurrShip), ShipHeight(CurrShip), frmMain.picMask(CurrShip).hDC, AnimNum(0) * ShipWidth(CurrShip), 0, vbSrcAnd)
  ua = BitBlt(frmMain.picShields.hDC, 0, 0, ShipWidth(CurrShip), ShipHeight(CurrShip), frmMain.picSprite(CurrShip).hDC, AnimNum(0) * ShipWidth(CurrShip), 0, vbSrcPaint)
End Function


Public Function DrawBack()
  Dim ua As Long
  BackScrollY1 = BackScrollY1 + 5
  BackScrollY2 = BackScrollY2 + 5
  ua = BitBlt(frmMain.picBuf.hDC, 0, BackScrollY1, frmMain.picBack.ScaleWidth, frmMain.picBack.ScaleHeight, frmMain.picBack.hDC, 0, 0, vbSrcCopy)
  ua = BitBlt(frmMain.picBuf.hDC, 0, BackScrollY2, frmMain.picBack.ScaleWidth, frmMain.picBack.ScaleHeight, frmMain.picBack.hDC, 0, 0, vbSrcCopy)
  If BackScrollY1 >= frmMain.picBuf.ScaleHeight Then
    BackScrollY1 = BackScrollY2 - frmMain.picBuf.ScaleHeight
  End If
  If BackScrollY2 >= frmMain.picBuf.ScaleHeight Then
    BackScrollY2 = BackScrollY1 - frmMain.picBuf.ScaleHeight
  End If
End Function


Public Function BackBufToFront()
  Dim ua As Long
  ua = BitBlt(frmMain.picField.hDC, 0, 0, frmMain.picBuf.ScaleWidth, frmMain.picBuf.ScaleHeight, frmMain.picBuf.hDC, 0, 0, vbSrcCopy)
End Function
Public Function DrawLightEnemy()
 Dim x As Integer, ua As Long, RndToDraw As Integer, FoundFree As Boolean
      'Decide weather or not to draw an enemy partially on random
      'partially on how many are currently out.
     RndToDraw = Int(Rnd * 25)
     x = CurrEnemies
     For x = 0 To MaxEnemy - 1
       If Enemy(x).isMoving = False Then Exit For
     Next
     If Enemy(x).isMoving = False Then
ReDraw:
      Enemy(x).Left = Int(Rnd * (frmMain.picBuf.ScaleWidth - SpriteWidth))
       If Enemy(x).Left < 0 Then
         GoTo ReDraw
       End If
      Enemy(x).hit = CurrLevel * 5
      Enemy(x).max_hit = CurrLevel * 5
      Enemy(x).shield = CurrLevel * 5
      Enemy(x).Velocity = Shuffle(7, 10)
      Enemy(x).max_shield = CurrLevel * 10
      Enemy(x).isMoving = True
      Enemy(x).Top = -25
      Enemy(x).CurrFrame = 1
      ua = BitBlt(frmMain.picBuf.hDC, Enemy(x).Left, Enemy(x).Top, SpriteWidth, EnemyHeight, frmMain.EnemyMask.hDC, 0, 39, vbSrcAnd)
      ua = BitBlt(frmMain.picBuf.hDC, Enemy(x).Left, Enemy(x).Top, SpriteWidth, EnemyHeight, frmMain.EnemySprite.hDC, 0, 39, vbSrcPaint)
    
    End If
End Function

Public Function LightEnemyUpdate()
      Dim x As Integer, ua As Long, RndShoot As Integer
     AnimTick(1) = GetTickCount()
     For x = 0 To MaxEnemy
       If Enemy(x).isMoving = True Then
        Enemy(x).Top = Enemy(x).Top + Enemy(x).Velocity
        If AnimTick(1) - LastTick(1) > EnimAnimTick Then
            Enemy(x).CurrFrame = (Enemy(x).CurrFrame Mod AnimMax) + 1
            LastTick(1) = GetTickCount()
        End If
        
        If Enemy(x).Top >= frmMain.picBuf.ScaleHeight Then
           Enemy(x).isMoving = False
           Score = Score - 25
           CurrEnemies = CurrEnemies - 1
        End If
        
        ua = BitBlt(frmMain.picBuf.hDC, Enemy(x).Left, Enemy(x).Top, SpriteWidth, EnemyHeight, frmMain.EnemyMask.hDC, 0, Enemy(x).CurrFrame * 39, vbSrcAnd)
        ua = BitBlt(frmMain.picBuf.hDC, Enemy(x).Left, Enemy(x).Top, SpriteWidth, EnemyHeight, frmMain.EnemySprite.hDC, 0, Enemy(x).CurrFrame * 39, vbSrcPaint)
       End If
     Next
End Function



Public Function YouFire()
  Dim ua As Long
 If CurrShip = 0 Or CurrShip = 1 Then
  Shot(CurrShot(0)).Left = (Ship(0).Left + 24)
 Else
  Shot(CurrShot(0)).Left = (Ship(0).Left + 25)
 End If
  Shot(CurrShot(0)).Top = (Ship(0).Top)
  Shot(CurrShot(0)).isMoving = True
  ua = BitBlt(frmMain.picBuf.hDC, Shot(CurrShot(0)).Left, Shot(CurrShot(0)).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotMask.hDC, 0, 0, vbSrcAnd)
  ua = BitBlt(frmMain.picBuf.hDC, Shot(CurrShot(0)).Left, Shot(CurrShot(0)).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotSprite.hDC, 0, 0, vbSrcPaint)
  CurrShot(0) = (CurrShot(0) Mod MaxShot) + 1
If CurrShip = 1 Or CurrShip = 2 Then
  Shot(CurrShot(0)).Top = Ship(0).Top
 If CurrShip = 1 Then
  Shot(CurrShot(0)).Left = (Ship(0).Left + 68)
 ElseIf CurrShip = 2 Then
  Shot(CurrShot(0)).Left = (Ship(0).Left + 3)
 End If
  Shot(CurrShot(0)).isMoving = True
  ua = BitBlt(frmMain.picBuf.hDC, Shot(CurrShot(0)).Left, Shot(CurrShot(0)).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotMask.hDC, 0, 0, vbSrcAnd)
  ua = BitBlt(frmMain.picBuf.hDC, Shot(CurrShot(0)).Left, Shot(CurrShot(0)).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotSprite.hDC, 0, 0, vbSrcPaint)
  CurrShot(0) = (CurrShot(0) Mod MaxShot) + 1
End If


End Function

Public Function UpdateYourShots()
  Dim x As Integer, ua As Long, B As Integer, d As Integer

  For x = 1 To CurrShot(0)
  'If the shot is above x then free up a shot
  'If Shot(x).top < 0 Then CurrShot(0) = CurrShot(0) - 1
  'If CurrShot(0) >= MaxShot Then CurrShot(0) = 0
    Shot(x).Top = Shot(x).Top - Velocity
  'If Shot(x).top <= 0 Then
  '  CurrShot(0) = CurrShot(0) - 1
  'End If
  If Shot(x).Top < 0 Then Shot(x).isMoving = False
  If Shot(x).isMoving = True Then
    ua = BitBlt(frmMain.picBuf.hDC, Shot(x).Left, Shot(x).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotMask.hDC, 0, 0, vbSrcAnd)
    ua = BitBlt(frmMain.picBuf.hDC, Shot(x).Left, Shot(x).Top, frmMain.ShotSprite.ScaleWidth, frmMain.ShotSprite.ScaleHeight, frmMain.ShotSprite.hDC, 0, 0, vbSrcPaint)
  End If
  Next
  d = 0
  For x = 1 To CurrShot(0)
    If Shot(x).isMoving = False Then
      d = d + 1
    End If
  Next
 
  If d = MaxShot Then
    CurrShot(0) = 0
  End If
End Function

Public Function DisplayRounds()
  Dim x As Integer, ua As Long, l As Integer, CurrY As Integer
  l = 0
  CurrY = 0
  frmMain.PicShots.Cls
  For x = 1 To (MaxShot - CurrShot(0))
    If l = 10 Then
      l = 0
      CurrY = CurrY + frmMain.ShotMask.ScaleHeight + 2
    End If
    ua = BitBlt(frmMain.PicShots.hDC, l * frmMain.ShotMask.ScaleWidth + 2, CurrY, frmMain.ShotMask.ScaleWidth, frmMain.ShotMask.ScaleHeight, frmMain.ShotMask.hDC, 0, 0, vbSrcAnd)
    ua = BitBlt(frmMain.PicShots.hDC, l * frmMain.ShotMask.ScaleWidth + 2, CurrY, frmMain.ShotMask.ScaleWidth, frmMain.ShotMask.ScaleHeight, frmMain.ShotSprite.hDC, 0, 0, vbSrcPaint)
    l = l + 1
  Next
End Function

Static Function Shuffle(Lower As Integer, Upper As Integer) As Integer
Static PrimeFactor(10) As Integer, t As Boolean
Static a As Integer, c As Integer, B As Integer
Static s As Long, n As Integer, n1 As Integer
Dim i As Integer, J As Integer, k As Integer
Dim m As Integer


If (n <> Upper - Lower + 1) Then
    n = Upper - Lower + 1
    i = 0
    n1 = n
    k = 2


    Do While k <= n1


        If (n1 Mod k = 0) Then


            If (i = 0 Or PrimeFactor(i) <> k) Then
                i = i + 1
                PrimeFactor(i) = k
            End If
            n1 = n1 / k
        Else
            k = k + 1
        End If
    Loop
    B = 1


    For J = 1 To i
        B = B * PrimeFactor(J)
    Next J
    If n Mod 4 = 0 Then B = B * 2
    a = B + 1
    c = Int(n * 0.66)
    t = True


    Do While t
        t = False


        For J = 1 To i
            If ((c Mod PrimeFactor(J) = 0) Or (c Mod a = 0)) Then t = True
        Next J
        If t Then c = c - 1
    Loop
    Randomize
    s = Rnd(n)
End If
s = (a * s + c) Mod n
Shuffle = s + Lower
End Function

Public Function Collide()
  Dim x As Integer, Y As Integer
  If PECollisions = True Then
    For x = 0 To MaxEnemy
      If (Ship(0).Left + (ShipWidth(CurrShip))) > Enemy(x).Left And Ship(0).Left < (Enemy(x).Left + SpriteWidth) And Ship(0).Top < (Enemy(x).Top + EnemyHeight) And (Ship(0).Top + 59) > Enemy(x).Top And Enemy(x).isMoving = True Then
        EnemyExplode (x)
        CurrEnemies = CurrEnemies - 1
        If Ship(0).shield > 0 Then
          Ship(0).shield = Ship(0).shield - 265
        Else
          Ship(0).hit = Ship(0).hit - 600
        End If
      If Ship(0).hit <= 0 Then
        YouExplode
        CurrEnemies = CurrEnemies - 1
      End If
    End If
   Next
  End If
  For x = 1 To CurrShot(0)
   For Y = 0 To MaxEnemy
    If Shot(x).Left > Enemy(Y).Left And Shot(x).Left < (Enemy(Y).Left + SpriteWidth) And Shot(x).Top < (Enemy(Y).Top + EnemyHeight) And Shot(x).Top > Enemy(Y).Top And Shot(x).isMoving = True Then
      Shot(x).isMoving = False
      
      If Enemy(Y).shield > 0 Then
        Enemy(Y).shield = Enemy(Y).shield - 120
      Else
        Enemy(Y).hit = Enemy(Y).hit - 75
      End If
      If Enemy(Y).hit <= 0 Then
        EnemyExplode (Y)
        CurrEnemies = CurrEnemies - 1
      End If
    End If
  Next
  Next
  If (Ship(0).Left + (ShipWidth(CurrShip))) > PickUp.Left And Ship(0).Left < (PickUp.Left + PickUpWidth) And Ship(0).Top < (PickUp.Top + PickupHeight) And (Ship(0).Top + 59) > PickUp.Top And PickUp.isMoving = True Then
    PickUp.isMoving = False
    PlayWav "intro.wav"
   If PickUps = 1 Then
     Ship(0).shield = Ship(0).max_shield
   ElseIf PickUps = 0 Then
     For x = 0 To MaxEnemy
        EnemyExplode x
        CurrEnemies = 0
     Next
   ElseIf PickUps = 2 Then
     Ship(0).hit = Ship(0).max_hit
   ElseIf PickUps = 3 Then
     Ship(0).hit = Ship(0).hit - 1000
     Ship(0).shield = 0
   ElseIf PickUps = 4 Then
     Ship(0).hit = Ship(0).hit + 200
     Ship(0).shield = Ship(0).shield + 200
   End If
    
  End If
  If EnemyCollisions = True Then
    For x = 0 To MaxEnemy
      For Y = 0 To MaxEnemy
        If x <> Y Then
          If (Enemy(x).Left + (SpriteWidth)) > Enemy(Y).Left And Enemy(x).Left < (Enemy(Y).Left + SpriteWidth) And Enemy(x).Top < (Enemy(Y).Top + EnemyHeight) And (Enemy(x).Top + EnemyHeight) > Enemy(Y).Top And Enemy(Y).isMoving = True Then
            EnemyExplode x
            EnemyExplode Y
          End If
        End If
      Next
    Next
  End If
End Function

Public Function EnemyExplode(en As Integer)
  Dim x As Integer, ua As Long
  PlayWav "explode.wav"
  If NumExplosions = 10 Then
    x = 0
  Else
    x = NumExplosions + 1
  End If
  Explosion(x).CurrFrame = 0
  Explosion(x).x = Enemy(en).Left
  Explosion(x).Y = Enemy(en).Top
  Explosion(x).IsExploding = True
  Enemy(en).isMoving = False
  Enemy(en).Top = frmMain.picBuf.ScaleWidth + 5000
  Score = Score + 350
End Function

Public Function YouExplode()
  Dim x As Integer, ua As Long
  PlayWav "explode.wav"
  If NumExplosions = 10 Then
    x = 0
  Else
    x = NumExplosions + 1
  End If
  Explosion(x).CurrFrame = 0
  Explosion(x).x = Ship(0).Left
  Explosion(x).Y = Ship(0).Top
  Explosion(x).IsExploding = True
  MsgBox "Game Over - Your Score Was: " & Score & Chr(10) & "Thank you for playing."
  frmMain.tmrGame.Enabled = False
  AddHighScore
  ReadTopScores
  frmHigh.Show
End Function

Public Function PlayWav(wav As String)
  Dim ua As Long
 If Sound = True Then
   ua = sndPlaySound(App.Path & "\snds\" & wav, 1)
 End If
End Function

Public Function UpdateExplosions()
  Dim x As Integer, ua As Long
  For x = 1 To MaxExplosions
      Explosion(x).CurrFrame = Explosion(x).CurrFrame + 1
        If Explosion(x).CurrFrame > 6 Then
          Explosion(x).IsExploding = False
        End If
      If Explosion(x).IsExploding = True Then
        ua = BitBlt(frmMain.picBuf.hDC, Explosion(x).x, Explosion(x).Y, ExplodeWidth, ExplodeHeight, frmMain.ExplodeMask.hDC, Explosion(x).CurrFrame * ExplodeWidth, 0, vbSrcAnd)
        ua = BitBlt(frmMain.picBuf.hDC, Explosion(x).x, Explosion(x).Y, ExplodeWidth, ExplodeHeight, frmMain.ExplodeSprite.hDC, Explosion(x).CurrFrame * ExplodeWidth, 0, vbSrcPaint)
      End If
  Next
End Function

Public Function DrawPickUps()
Dim ua As Long
ReDraw:
 If PickUp.isMoving = True Then Exit Function
 If Int(Rnd * 100) < 99 Then Exit Function
      PickUp.Left = Int(Rnd * (frmMain.picBuf.ScaleWidth - PickUpWidth))
       If PickUp.Left < 0 Then
         GoTo ReDraw
       End If
       PickUp.Top = -25
       PickUp.Type = 0
       PickUp.isMoving = True
       Randomize Timer
       PickUps = Int(Rnd * 5)
       ua = BitBlt(frmMain.picBuf.hDC, PickUp.Left, PickUp.Top, PickUpWidth, PickupHeight, frmMain.shieldMask.hDC, PickUps * 30, 0, vbSrcAnd)
       ua = BitBlt(frmMain.picBuf.hDC, PickUp.Left, PickUp.Top, PickUpWidth, PickupHeight, frmMain.shieldSprite.hDC, PickUps * 30, 0, vbSrcPaint)
End Function

Public Function UpdatePickUps()
Dim ua As Long
  If PickUp.isMoving = True Then
       PickUp.Top = PickUp.Top + 2
       ua = BitBlt(frmMain.picBuf.hDC, PickUp.Left, PickUp.Top, PickUpWidth, PickupHeight, frmMain.shieldMask.hDC, PickUps * 30, 0, vbSrcAnd)
       ua = BitBlt(frmMain.picBuf.hDC, PickUp.Left, PickUp.Top, PickUpWidth, PickupHeight, frmMain.shieldSprite.hDC, PickUps * 30, 0, vbSrcPaint)
       If PickUp.Top > frmMain.picBuf.ScaleHeight Then
          PickUp.isMoving = False
       End If
    End If
End Function



Function ReadINI(Section, KeyName, FileName As String) As String
    Dim sRet As String
    sRet = String(255, Chr(0))
    ReadINI = Left(sRet, GetPrivateProfileString(Section, ByVal KeyName, "", sRet, Len(sRet), FileName))
End Function

Function writeini(sSection As String, sKeyName As String, sNewString As String, sFileName) As Integer
    Dim r
    r = WritePrivateProfileString(sSection, sKeyName, sNewString, sFileName)
End Function


Public Function AddHighScore()
  Dim x As Integer, IsTop As Boolean, Y As Integer, d As Integer, StartPlace
  For x = 0 To 9
    If Score > TopScores(x).Score Then
      StartPlace = x
      Exit For
    End If
  Next
  For Y = 9 To (StartPlace + 1) Step -1
       TopScores(Y).Level = (TopScores(Y - 1).Level)
       TopScores(Y).Score = (TopScores(Y - 1).Score)
       TopScores(Y).Name = (TopScores(Y - 1).Name)
  Next
  TopScores(StartPlace).Level = CurrLevel
  TopScores(StartPlace).Score = Score
  TopScores(StartPlace).Name = InputBox("You have achieved a high score. Please enter your name", "High Score!! :)")
  d = FreeFile()
  Open App.Path & "\TopScores.dat" For Output As #d
  For x = 0 To 9
    If TopScores(x).Name = "" Or TopScores(x).Name = " " Then TopScores(x).Name = "None"
    Print #d, TrimSpaceOfEnd(TopScores(x).Name) & " " & TopScores(x).Level & " " & TopScores(x).Score
  Next
  Close #d
End Function

Public Function ReadTopScores()
  Dim d As Integer, st As String, arg1 As String, arg2 As Integer, arg3 As Long, m As Integer, x As Integer, argument As String
  'On Error Resume Next
  d = FreeFile()
  m = 0
  Open App.Path & "\TopScores.dat" For Input As #d
    Do Until EOF(d)
      Line Input #d, st
      argument = one_argument(st, arg1)
      argument = one_argument(argument, arg2)
      argument = one_argument(argument, arg3)
      TopScores(m).Name = arg1
      TopScores(m).Level = arg2
      TopScores(m).Score = arg3
      'MsgBox TopScores(m).Name & "   " & TopScores(m).Level & "    " & TopScores(m).Score
      m = m + 1
    Loop
  Close #d
  For x = 0 To 9
    frmHigh.lblName(x).Caption = TopScores(x).Name
    frmHigh.lblLevel(x).Caption = TopScores(x).Level
    frmHigh.lblScore(x).Caption = TopScores(x).Score
  Next
End Function

Public Function one_argument(arg1, arg2) As String
    Dim x As Integer
    On Error Resume Next

    If Mid(arg1, 1, 1) = "'" Then
        x = InStr(2, arg1, "'")
        arg2 = Mid(arg1, 2, x - 2)
        arg1 = Mid(arg1, x + 1, Len(arg1) - x)
        one_argument = arg1
        Exit Function
    End If
    x = InStr(1, arg1, " ")


    If x = 0 Then
        arg2 = arg1
        one_argument = arg1
        Exit Function
    End If
    arg2 = Mid(arg1, 1, x)
    arg1 = Mid(arg1, x + 1, Len(arg1) - x)
    one_argument = arg1
End Function


Public Function TileBitmap(ByVal theForm As Form, ByVal theBitmap As PictureBox)
    Dim iAcross As Integer
    Dim iDown As Integer
    theBitmap.AutoSize = True


    For iDown = 0 To (theForm.Width \ theBitmap.Width) + 1


        For iAcross = 0 To (theForm.Height \ theBitmap.Height) + 1
            theForm.PaintPicture theBitmap.Picture, iDown * theBitmap.Width, iAcross * theBitmap.Height, theBitmap.Width, theBitmap.Height
        Next iAcross, iDown
End Function

Public Function TrimSpaceOfEnd(src As String) As String
  If right(src, 1) = " " Then
    TrimSpaceOfEnd = Left(src, Len(src) - 1)
  Else
    TrimSpaceOfEnd = src
  End If
End Function
