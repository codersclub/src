VERSION 5.00
Object = "{248DD890-BB45-11CF-9ABC-0080C7E7B78D}#1.0#0"; "MSWINSCK.OCX"
Begin VB.Form frmMail 
   BorderStyle     =   3  'Fixed Dialog
   Caption         =   "HMTL Mailer"
   ClientHeight    =   7440
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   7320
   Icon            =   "frmEmail.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   7440
   ScaleWidth      =   7320
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton cmdFile 
      Caption         =   "..."
      Height          =   255
      Left            =   6720
      TabIndex        =   16
      Top             =   1920
      Width           =   375
   End
   Begin VB.CommandButton cmdAbout 
      Caption         =   "&About / Updates"
      Height          =   495
      Left            =   4920
      Picture         =   "frmEmail.frx":058A
      Style           =   1  'Graphical
      TabIndex        =   15
      Top             =   6840
      Width           =   2295
   End
   Begin VB.CommandButton cmdQuit 
      Cancel          =   -1  'True
      Caption         =   "&Quit"
      Height          =   495
      Left            =   2520
      TabIndex        =   14
      Top             =   6840
      Width           =   2295
   End
   Begin VB.CommandButton cmdSend 
      Caption         =   "&Send mail"
      Default         =   -1  'True
      Height          =   495
      Left            =   120
      TabIndex        =   13
      Top             =   6840
      Width           =   2295
   End
   Begin MSWinsockLib.Winsock Winsock1 
      Left            =   120
      Top             =   6000
      _ExtentX        =   741
      _ExtentY        =   741
      _Version        =   393216
   End
   Begin VB.TextBox txtEMailTo 
      Appearance      =   0  'Flat
      Height          =   300
      Left            =   1200
      TabIndex        =   3
      Top             =   840
      Width           =   2655
   End
   Begin VB.TextBox txtSubject 
      Appearance      =   0  'Flat
      Height          =   300
      Left            =   1200
      TabIndex        =   4
      Top             =   1200
      Width           =   6015
   End
   Begin VB.TextBox txtAttachment 
      Appearance      =   0  'Flat
      Height          =   300
      Left            =   1080
      TabIndex        =   6
      Top             =   1920
      Width           =   5655
   End
   Begin VB.TextBox txtEMailFrom 
      Appearance      =   0  'Flat
      Height          =   300
      Left            =   1200
      TabIndex        =   2
      Top             =   480
      Width           =   2655
   End
   Begin VB.TextBox txtSMTP 
      Appearance      =   0  'Flat
      Height          =   300
      Left            =   1200
      TabIndex        =   1
      Top             =   120
      Width           =   2655
   End
   Begin VB.Frame Frame2 
      Height          =   735
      Left            =   120
      TabIndex        =   7
      Top             =   6000
      Width           =   7095
      Begin VB.TextBox txtLog 
         Appearance      =   0  'Flat
         Height          =   375
         Left            =   120
         Locked          =   -1  'True
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   12
         TabStop         =   0   'False
         Top             =   240
         Width           =   6855
      End
   End
   Begin VB.Frame Frame1 
      Caption         =   "Contents"
      Height          =   4455
      Left            =   120
      TabIndex        =   0
      Top             =   1560
      Width           =   7095
      Begin VB.TextBox txtMessage 
         Appearance      =   0  'Flat
         Height          =   3255
         Left            =   120
         MultiLine       =   -1  'True
         ScrollBars      =   2  'Vertical
         TabIndex        =   5
         Text            =   "frmEmail.frx":0B14
         Top             =   720
         Width           =   6855
      End
      Begin VB.Label Label6 
         Caption         =   "Note : Press CTRL+Enter to go to next line in the message area."
         Height          =   255
         Left            =   120
         TabIndex        =   18
         Top             =   4080
         Width           =   6855
      End
      Begin VB.Label Label5 
         Caption         =   "Attachment"
         Height          =   255
         Left            =   120
         TabIndex        =   17
         Top             =   360
         Width           =   855
      End
   End
   Begin VB.Label Label4 
      Caption         =   "Subject"
      Height          =   195
      Left            =   120
      TabIndex        =   11
      Top             =   1200
      Width           =   1005
   End
   Begin VB.Label Label3 
      Caption         =   "Email to"
      Height          =   195
      Left            =   120
      TabIndex        =   10
      Top             =   840
      Width           =   1005
   End
   Begin VB.Label Label2 
      Caption         =   "Email from"
      Height          =   195
      Left            =   120
      TabIndex        =   9
      Top             =   480
      Width           =   1005
   End
   Begin VB.Label Label1 
      Caption         =   "SMTP server"
      Height          =   195
      Left            =   120
      TabIndex        =   8
      Top             =   120
      Width           =   1005
   End
End
Attribute VB_Name = "frmMail"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

'---- API
Private Type OPENFILENAME
    lStructSize As Long
    hWndOwner As Long
    hInstance As Long
    lpstrFilter As String
    lpstrCustomFilter As String
    nMaxCustFilter As Long
    nFilterIndex As Long
    lpstrFile As String
    nMaxFile As Long
    lpstrFileTitle As String
    nMaxFileTitle As Long
    lpstrInitialDir As String
    lpstrTitle As String
    flags As Long
    nFileOffset As Integer
    nFileExtension As Integer
    lpstrDefExt As String
    lCustData As Long
    lpfnHook As Long
    lpTemplateName As String
End Type

Private Declare Function GetOpenFileName Lib "comdlg32.dll" Alias "GetOpenFileNameA" (pOpenfilename As OPENFILENAME) As Long


'---- Const
Const err_SMTP = "No SMTP server"
Const err_FROM = "No Email from"
Const err_TO = "No Email to"
Const err_SUBJECT = "No subject"

Dim response As String


'----

Function form_errors() As Boolean

    Dim temp As Boolean
    
    temp = False
    If Len(txtSubject.Text) = 0 Then
        txtLog.Text = "Error: " & err_SUBJECT & "." & vbCrLf & txtLog.Text & vbCrLf
        temp = True
    End If
    If Len(txtEMailTo.Text) = 0 Then
        txtLog.Text = "Error: " & err_TO & "." & vbCrLf & txtLog.Text & vbCrLf
        temp = True
    End If
    If Len(txtEMailFrom.Text) = 0 Then
        txtLog.Text = "Error: " & err_FROM & "." & vbCrLf & txtLog.Text & vbCrLf
        temp = True
    End If
    If Len(txtSMTP.Text) = 0 Then
        txtLog.Text = "Error: " & err_SMTP & "." & vbCrLf & txtLog.Text & vbCrLf
        temp = True
    End If
    form_errors = temp
    
End Function

'------------------------------------------------------------
'           Buttons management
'------------------------------------------------------------

Private Sub cmdAbout_Click()
    frmAbout.Show 1
End Sub

Private Sub cmdFile_Click()

    Dim strFile As String
    
    ' Get a file
    strFile = OpenDialog("Images Files(*.gif;*.jpg)|*.gif;*.jpg", "Choose an image ...", "")
    
    If (strFile <> "") Then
        txtAttachment.Text = strFile
    End If
    
End Sub

Private Function OpenDialog(Filter As String, DialogTitle As String, InitialFolder As String) As String
 
    Dim ofn As OPENFILENAME
    Dim a As Long
    
    ofn.lStructSize = Len(ofn)
    ofn.hWndOwner = Me.hWnd
    ofn.hInstance = App.hInstance
    If Right$(Filter, 1) <> "|" Then Filter = Filter + "|"
    
    For a = 1 To Len(Filter)
        If Mid$(Filter, a, 1) = "|" Then Mid$(Filter, a, 1) = Chr$(0)
    Next
    
    ofn.lpstrFilter = Filter
    ofn.lpstrFile = Space$(254)
    ofn.nMaxFile = 255
    ofn.lpstrFileTitle = Space$(254)
    ofn.nMaxFileTitle = 255
    ofn.lpstrInitialDir = InitialFolder
    ofn.lpstrTitle = DialogTitle
    ofn.flags = 0 'OFN_HIDEREADONLY Or OFN_FILEMUSTEXIST
    a = GetOpenFileName(ofn)

    If (a) Then
        OpenDialog = Trim$(ofn.lpstrFile)
    Else
        OpenDialog = ""
    End If

End Function

Private Sub cmdQuit_Click()
    Unload Me
End Sub

Private Sub cmdSend_Click()
    If form_errors = False Then
        connect_to_smtp_server txtSMTP
    End If
End Sub

'------------------------------------------------------------
'           Form managemement
'------------------------------------------------------------

Sub init_me()

    txtLog.Text = "Ready." & vbCrLf
    response = ""
    
    txtAttachment.Text = App.Path & "\DZLogo2.jpg"
    
End Sub


Private Sub Form_Load()
    init_me
End Sub

Private Sub Form_Unload(Cancel As Integer)
    Winsock1.Close
    Unload Me
End Sub

'------------------------------------------------------------
'           Mail managemement
'------------------------------------------------------------

Private Sub Winsock1_Connect()

    txtLog.Text = "Connected to: " & txtSMTP & "." & vbCrLf & txtLog.Text & vbCrLf
    
    ' Send the mail
    SendMail txtEMailTo, txtEMailFrom, txtSubject, txtMessage, txtAttachment
    
End Sub

Private Sub Winsock1_DataArrival(ByVal bytesTotal As Long)

    Winsock1.GetData response
    
End Sub

Private Sub Winsock1_Error(ByVal Number As Integer, Description As String, ByVal Scode As Long, ByVal Source As String, ByVal HelpFile As String, ByVal HelpContext As Long, CancelDisplay As Boolean)

    txtLog.Text = "Error: " & Description & "." & vbCrLf & txtLog.Text & vbCrLf
    
End Sub

Sub wait_for(winsock_answare As String)

    Do While Left(response, 3) <> winsock_answare
        DoEvents
    Loop
    response = ""
    
End Sub

Function find_date() As String

    Dim temp As String
    Dim fd_day As String
    Dim fd_month As String
    Dim fd_time As String
    
    fd_day = Format(Date, "Dddd")
    Select Case fd_day
        Case "��� �����": fd_day = "Sun, "
        Case "��� ���": fd_day = "Mon, "
        Case "��� �����": fd_day = "Tue, "
        Case "��� �����": fd_day = "Wed, "
        Case "��� �����": fd_day = "Thu, "
        Case "��� ����": fd_day = "Fri, "
        Case "��� ���": fd_day = "Sat, "
    End Select
    fd_month = Month(Date)
    Select Case fd_month
        Case 1: fd_month = "Jan "
        Case 2: fd_month = "Feb "
        Case 3: fd_month = "Mar "
        Case 4: fd_month = "Apr "
        Case 5: fd_month = "May "
        Case 6: fd_month = "Jun "
        Case 7: fd_month = "Jul "
        Case 8: fd_month = "Aug "
        Case 9: fd_month = "Sep "
        Case 10: fd_month = "Oct "
        Case 11: fd_month = "Nov "
        Case 12: fd_month = "Dec "
    End Select
    fd_time = Format(Time) & " +0200"
    temp = fd_day & Day(Format(Date)) & " " & fd_month & Year(Format(Date, "dd/mm/yyyy")) & " " & fd_time
    find_date = temp
    
End Function

Function attach_file(attach_str As String) As String
    Dim s As Integer
    Dim temp As String
    
    s = InStr(1, attach_str, "\")
    temp = attach_str
    Do While s > 0
        temp = Mid(temp, s + 1, Len(temp))
        s = InStr(1, temp, "\")
    Loop
    attach_file = temp
End Function

Function encode_the_file(attach_str As String) As String
    Dim blocksize As Long
    Dim buffer As String
    Dim s As String
    Dim i As Long
    Dim temp As String
    
    Open attach_str For Binary Access Read As #1
        blocksize = 3
        Do While Not EOF(1)
            buffer = Space(blocksize)
            Get 1, , buffer
            s = s & base64_encode_string(buffer)
            DoEvents
        Loop
    Close #1
    For i = 1 To Len(s) Step 76
        temp = temp & Mid(s, i, 76) & vbCrLf
    Next i
    temp = Mid(temp, 1, Len(temp) - 2)
    encode_the_file = temp
End Function

' Send the mail
Private Sub SendMail(aMailTo As String, aMailFrom As String, aSubject As String, aMessage As String, attach As String)
    
    Const boundary = "Hapoel_Tel_Aviv"
    
    Dim se_body As String
    Dim se_date As String
    Dim se_from As String
    Dim se_to As String
    Dim se_mime As String
    Dim se_content_type As String
    Dim se_content_type_message As String
    Dim se_content_type_attach As String
    Dim x_mailer As String
    Dim x_oem As String
     
    se_date = "Date: " & find_date
    se_from = "From: " & aMailFrom
    se_to = "To: " & aMailTo
    aSubject = "Subject: " & aSubject
    
    se_mime = "MIME-Version: 1.0"
    se_content_type = "Content-Type: multipart/related;" & vbCrLf _
        & vbTab & "boundary = " & """" & boundary & """"
    
    x_oem = "X-OEM: zubin"
    x_mailer = "X-Mailer: " & """" & "Mailer" & """" & " - by ag v1.0"
    
    se_content_type_message = "This is a multi-part message in MIME format." & vbCrLf _
        & "--" & boundary & vbCrLf _
        & "Content-Type: text/html;" & vbCrLf _
        & vbTab & "charset=" & """" & "iso-8859-1" & """" & vbCrLf _
        & "Content-Transfer-Encoding: 7bit"
        
    If Len(txtAttachment.Text) > 0 Then
        se_content_type_attach = "--" & boundary & vbCrLf _
            & "Content-Type: application/octet-stream;" & vbCrLf _
            & vbTab & "name=" & attach_file(txtAttachment.Text) & vbCrLf _
            & "Content-Transfer-Encoding: base64" & vbCrLf _
            & "Content-Disposition: attachment;" & vbCrLf _
            & vbTab & "filename=" & attach_file(txtAttachment.Text) & vbCrLf _
            & vbCrLf _
            & encode_the_file(txtAttachment.Text)
    End If
    
    se_body = se_from & vbCrLf _
        & se_to & vbCrLf _
        & aSubject & vbCrLf _
        & se_date & vbCrLf _
        & se_mime & vbCrLf _
        & x_oem & vbCrLf _
        & x_mailer & vbCrLf _
        & se_content_type & vbCrLf _
        & vbCrLf _
        & se_content_type_message & vbCrLf _
        & vbCrLf _
        & aMessage & vbCrLf _
        & vbCrLf _
        & se_content_type_attach & vbCrLf _
        & "." & vbCrLf
    
    txtLog.Text = "Sending message..." & vbCrLf & txtLog.Text & vbCrLf
    Winsock1.SendData "HELO " & Left(aMailFrom, InStr(1, aMailFrom, "@") - 1) & vbCrLf
    wait_for "250"
    Winsock1.SendData "MAIL FROM: " & aMailFrom & vbCrLf
    wait_for "250"
    Winsock1.SendData "RCPT TO: " & aMailTo & vbCrLf
    wait_for "250"
    Winsock1.SendData "DATA" & vbCrLf
    wait_for "354"
    Winsock1.SendData se_body
    wait_for "250"
    Winsock1.SendData "QUIT" & vbCrLf
    wait_for "221"
    txtLog.Text = "Message sent." & vbCrLf & txtLog.Text & vbCrLf
    Winsock1.Close
    
    DoEvents
    
End Sub

' Do the connection with the SMTP server
Sub connect_to_smtp_server(smtp_server As String)

    Winsock1.LocalPort = 0
    Winsock1.RemoteHost = txtSMTP
    Winsock1.RemotePort = 25
    Winsock1.Connect
    
End Sub

