program AppName;

uses
  Windows,
  Forms,
  Main in 'Main.pas' {MainForm},
  Tool in 'Tool.pas' {ObjectToolWindow},
  MapDat in 'MapDat.pas',
  MapPropUn in 'MapPropUn.pas' {MapPropDlg};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'DelphiX Sample';
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TObjectToolWindow, ObjectToolWindow);
  Application.CreateForm(TMapPropDlg, MapPropDlg);
  Application.Run;
end.
