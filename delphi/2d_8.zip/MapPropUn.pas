unit MapPropUn;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ExtCtrls;

type
  TMapPropDlg = class(TForm)
    WidthGroup: TRadioGroup;
    LandGroup: TRadioGroup;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  MapPropDlg: TMapPropDlg;

implementation

{$R *.DFM}

end.
