unit Tool;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  DXDraws, ComCtrls, StdCtrls;

type
  TObjectToolWindow = class(TForm)
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    GroundsDXDraw: TDXDraw;
    ObjectsDXDraw: TDXDraw;
    RandomCheck: TCheckBox;
    Label1: TLabel;
    Label2: TLabel;
    TabSheet3: TTabSheet;
    MapGenButton: TButton;
    procedure GroundsDXDrawMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure MapGenButtonClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure RefreshElements;
  end;

var
  ObjectToolWindow: TObjectToolWindow;

implementation

Uses Main;

{$R *.DFM}

procedure TObjectToolWindow.RefreshElements;
var
   I : Integer;
begin
     for I := 0 to 3 do
        begin
          with MainForm do
            begin
             if i<3 then
                ImageList.Items.Find(LandType).
                Draw(GroundsDXDraw.Surface,I*(MainForm.ElemWidth+2),1,i*16)
             else
                ImageList.Items.Find(LandType).
                Draw(GroundsDXDraw.Surface,I*(MainForm.ElemWidth+2),1,15);
            end;
        end;
end;

procedure TObjectToolWindow.GroundsDXDrawMouseUp(Sender: TObject;
  Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
var
   W,H : Integer;
begin
  W := MainForm.ElemWidth + 2;
  H := MainForm.ElemHeight + 2;

  MainForm.BrushIndex := X div W;

  GroundsDXDraw.Surface.Fill(0);

  RefreshElements;

  with GroundsDXDraw.Surface.Canvas do
   begin
    Pen.Color := clLime;
    Pen.Width := 2;
    Brush.Style := bsClear;
    Rectangle((X div W)*W + 1,
              (Y div H)*H + 2,
                 (X div W)*W + W - 2,
                 (Y div H)*H + H - 2);
    Release; {  Indispensability  }
  end;

  GroundsDxDraw.Flip;
end;

procedure TObjectToolWindow.MapGenButtonClick(Sender: TObject);
var i,j,k : Integer;
    RndIndex : Integer;
    RndX,RndY: Integer;
    RndW,RndH : Integer;
    RndNoiceY,
    RndNoiceX : Integer;
    RndIterations : Integer;
    W,H : Integer;
begin
  MainForm.DXTimer.Enabled := False;
  W := MainForm.WorldWidth;
  H := MainForm.WorldHeight;
  RndIterations := Random(100);

  for k := 0 to RndIterations do
    begin
      RndX := Random(W);RndY := Random(H);
      RndW := Random(W);RndH := Random(H);
      RndIndex := Random(4);

      for j := 0 to RndH - 1 do
       for i := 0 to RndW - 1 do
         begin
           RndNoiceX := Random(3);
           RndNoiceY := Random(3);

           if Random(100) > 20 Then
              MainForm.Matrix5.Draw(RndX + i - RndNoiceX,RndY + j - RndNoiceY,RndIndex);
         end;
    end;

  MainForm.DXTimer.Enabled := True;
end;

procedure TObjectToolWindow.FormCreate(Sender: TObject);
begin
 Randomize;
end;

end.
