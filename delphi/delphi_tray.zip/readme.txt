tray11.zip - Delphi 2.0 component for the Windows 95 systray

Drop this component on a form, and the application automatically
minimizes to the Windows 95 system tray. You can add a popup menu
to be invoked when the user right-clicks the icon. Event handlers
give you finer control over mouse events.  You probably will need
to modify it slightly to customize the component for your needs.

Freeware with source code. No help file. Delphi 2.0 specific.
