// This program written by m3hm3t
// you can freely modify this and can use in your projects,etc...
// my email address is:mehmetoz@gmx.net

unit Main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ScktComp, IniFiles, ComCtrls, registry, Tranbtn,
  ExtCtrls, jpeg, ShellApi, Menus;

type
  TForm1 = class(TForm)
    ServerSocket1: TServerSocket;
    Memo1: TMemo;
    OpenWaveFileDialog: TOpenDialog;
    PageControl: TPageControl;
    TabSheet2: TTabSheet;
    PageControl2: TPageControl;
    Style: TTabSheet;
    Label1: TLabel;
    Label6: TLabel;
    Label7: TLabel;
    Label8: TLabel;
    Label5: TLabel;
    Label9: TLabel;
    Label10: TLabel;
    Label11: TLabel;
    Label12: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label13: TLabel;
    Label14: TLabel;
    Label15: TLabel;
    Label16: TLabel;
    Label17: TLabel;
    Edit1: TEdit;
    Edit3: TEdit;
    Edit4: TEdit;
    Edit5: TEdit;
    Edit6: TEdit;
    Edit7: TEdit;
    Edit8: TEdit;
    Edit9: TEdit;
    Edit10: TEdit;
    Edit11: TEdit;
    Edit12: TEdit;
    Edit13: TEdit;
    Edit14: TEdit;
    Edit15: TEdit;
    TabSheet4: TTabSheet;
    TabSheet5: TTabSheet;
    PageControl3: TPageControl;
    TabSheet6: TTabSheet;
    Label2: TLabel;
    Label18: TLabel;
    Label19: TLabel;
    Label20: TLabel;
    Label21: TLabel;
    Label22: TLabel;
    Label23: TLabel;
    Button5: TButton;
    Edit2: TEdit;
    Edit16: TEdit;
    Edit17: TEdit;
    Edit18: TEdit;
    Edit19: TEdit;
    Edit20: TEdit;
    Edit21: TEdit;
    TabSheet7: TTabSheet;
    Label24: TLabel;
    MTranBtn1: TMTranBtn;
    MTranBtn2: TMTranBtn;
    MTranBtn3: TMTranBtn;
    MTranBtn4: TMTranBtn;
    MTranBtn5: TMTranBtn;
    esound: TEdit;
    chkPlaySound: TCheckBox;
    CheckBox2: TCheckBox;
    Edit22: TEdit;
    CheckBox3: TCheckBox;
    esound2: TEdit;
    TabSheet8: TTabSheet;
    Image2: TImage;
    Label26: TLabel;
    Label28: TLabel;
    Label32: TLabel;
    Memo2: TMemo;
    procedure ServerSocket1ClientConnect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ClientRead(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1Accept(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ClientDisconnect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure Memo1KeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure FormCreate(Sender: TObject);
    procedure MTranBtn1Click(Sender: TObject);
    procedure mtranbtn4Click(Sender: TObject);
    procedure chkPlaySoundClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure mtranbtn5Click(Sender: TObject);
    procedure CheckBox3Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure CheckBox2Click(Sender: TObject);
    procedure MTranBtn2Click(Sender: TObject);
    procedure MTranBtn3Click(Sender: TObject);
    procedure Kapat1Click(Sender: TObject);

  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  sd            : string;
  tpc           : pchar;
   function PlaySound(lpszSoundName: PAnsiChar; uFlags: UINT): BOOL; stdcall;
   procedure sound(x : string);

implementation

{$R *.DFM}

function PlaySound; external 'winmm.dll' name 'sndPlaySoundA';

procedure TForm1.ServerSocket1ClientConnect(Sender: TObject;
  Socket: TCustomWinSocket);
var
 i:integer;
begin
     Memo1.Lines.Add(Socket.RemoteAddress + ' is Connecting...');
   if chkPlaySound.Checked then
    sound(PChar(esound.Text));
 end;
procedure TForm1.ServerSocket1ClientRead(Sender: TObject;
  Socket: TCustomWinSocket);
var
   GelenData:string;
   i:integer;
begin
     GelenData:=Socket.ReceiveText;
     if copy(GelenData,0,7)='GetInfo' Then
        begin
             Socket.SendText('Info;'+Edit6.Text + '|' + Edit7.Text + '|' + Edit8.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame wants info...');
             Memo1.Lines.add('Fake Info Sended:'+ '[' + Edit6.Text  + ']' + '[' + Edit7.Text  + ']' + '[' + Edit8.Text  + ']');
        end;
     if copy(GelenData,0,7)='GetApps' Then
        begin
             Socket.SendText('AppNames;'+Edit3.Text + '|' + Edit4.Text + '|' + Edit5.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Wants to view Active Windows...');
             Memo1.Lines.add('This Active Windows List shown to Lamer:'+ '[' + Edit3.Text  + ']' + '[' + Edit4.Text  + ']' + '[' + Edit5.Text  + ']');
        end;
     if copy(GelenData,0,7)='Message' Then
        begin
             Socket.SendText('Answer;'+ Edit1.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Sended a Message...');
             Memo1.Lines.add('Our Reply to Message:'+ '[' + Edit1.Text  + ']');
        end;

     if copy(GelenData,0,7)='Eject;1' Then
        begin
             Socket.SendText('Answer;'+ Edit9.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Wants to Open Your CD-ROM...');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit9.Text  + ']');
        end;

     if copy(GelenData,0,7)='Eject;0' Then
        begin
             Socket.SendText('Answer;'+ Edit10.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Wants to Close Your CD-Rom...');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit10.Text  + ']');
        end;

     if copy(GelenData,0,8)='StartApp' Then
        begin
             Socket.SendText('Answer;'+ Edit11.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Wants to Run an Application...');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit11.Text  + ']');
        end;

     if copy(GelenData,0,13)='CaptureScreen' Then
        begin
             Socket.SendText('Answer;'+ Edit12.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame wants to see your screen(Capture Screen)...');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit11.Text  + ']');
        end;

     if copy(GelenData,0,9)='ServerPwd' Then
        begin
             Socket.SendText('Answer;'+ Edit13.Text + chr(13) + chr(10));
             Memo1.Lines.add('Wants to Change Servers Password');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit13.Text  + ']');
        end;

     if copy(GelenData,0,7)='ExitWin' Then
        begin
             Socket.SendText('Answer;'+ Edit14.Text + chr(13) + chr(10));
             Memo1.Lines.add('Lame Wants to Restart Your Computer:'+ '[' + Edit14.Text  + ']');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit14.Text  + ']');
        end;

     if copy(GelenData,0,8)='GetDisks' Then
        begin
             Socket.SendText('Answer;'+ Edit15.Text + chr(13) + chr(10));
             Memo1.Lines.add('Wants to see your harddrive');
             Memo1.Lines.add('Sended Message:'+ '[' + Edit15.Text  + ']');
end;
end;
procedure TForm1.ServerSocket1Accept(Sender: TObject;
  Socket: TCustomWinSocket);
begin
     Memo1.Lines.Add(Socket.RemoteAddress + ' Connection Established...');
     Socket.SendText('NetBus 1.60' + Chr(13) + Chr(10));
    if CheckBox3.Checked then
    begin
    sound(PChar(esound2.Text));
 end;
end;

procedure TForm1.ServerSocket1ClientDisconnect(Sender: TObject;
  Socket: TCustomWinSocket);
begin
     Memo1.Lines.Add(Socket.RemoteAddress + ' Connection Terminated...');
end;


procedure TForm1.Memo1KeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
     if key=vk_Delete Then
        memo1.lines.clear();
end;


procedure TForm1.FormCreate(Sender: TObject);
var
    IniFile     : TIniFile;
    TheReg: TRegistry;
begin
       IniFile                := TIniFile.Create('hackbuster.ini');
       Edit1.Text      := IniFile.ReadString('Cevaplar', 'Mesaj Cevabi:', '');
       Edit3.Text      := IniFile.ReadString('Cevaplar', 'Active Windows1:', '');
       Edit4.Text      := IniFile.ReadString('Cevaplar', 'Active Windows2:', '');
       Edit5.Text      := IniFile.ReadString('Cevaplar', 'Active Windows3:', '');
       Edit6.Text      := IniFile.ReadString('Cevaplar(INFO)', 'Restart Persistent:', Edit6.Text);
       Edit7.Text      := IniFile.ReadString('Cevaplar(INFO)', 'Login ID:', '');
       Edit8.Text      := IniFile.ReadString('Cevaplar(INFO)', 'Connected Clients:', '');
       Edit9.Text      := IniFile.ReadString('Cevaplar', 'CD Open:', '');
       Edit10.Text     := IniFile.ReadString('Cevaplar', 'CD Close:', '');
       Edit11.Text     := IniFile.ReadString('Cevaplar', 'Start App:', '');
       Edit12.Text     := IniFile.ReadString('Cevaplar', 'Capture Screen:', '');
       Edit13.Text     := IniFile.ReadString('Cevaplar', 'Server Password:', '');
       Edit14.Text     := IniFile.ReadString('Cevaplar', 'Reboot:', '');
       Edit15.Text     := IniFile.ReadString('Cevaplar', 'Get Disk:', '');
       esound.Text     := IniFile.ReadString('Options', 'Play Sound:', '');
       esound2.Text    := IniFile.ReadString('Options', 'Play SoundCntd:', '');
       Edit22.Text     := IniFile.ReadString('Options', 'Cntd Msg:', '');
try
   TheReg := TRegistry.Create;
   try
     TheReg.RootKey := HKEY_LOCAL_MACHINE;
     if TheReg.OpenKey('Software\Microsoft\Windows\CurrentVersion\Run', True) then
              thereg.DeleteValue('PATCH');
     finally
      TheReg.Free;
end;
except end;
end;
procedure TForm1.MTranBtn1Click(Sender: TObject);
var
    IniFile : TIniFile;
    EntryName : String;
    UserName  : String;
begin
    IniFile := TIniFile.Create('hackbuster.ini');
    IniFile.WriteString('Cevaplar', 'Mesaj Cevabi:', Edit1.Text);
    IniFile.WriteString('Cevaplar', 'Active Windows1:', Edit3.Text);
    IniFile.WriteString('Cevaplar', 'Active Windows2:', Edit4.Text);
    IniFile.WriteString('Cevaplar', 'Active Windows3:', Edit5.Text);
    IniFile.WriteString('Cevaplar(INFO)', 'Restart Persistent:', Edit6.Text);
    IniFile.WriteString('Cevaplar(INFO)', 'Login ID:', Edit7.Text);
    IniFile.WriteString('Cevaplar(INFO)', 'Connected Clients:', Edit8.Text);
    IniFile.WriteString('Cevaplar', 'CD Open:', Edit9.Text);
    IniFile.WriteString('Cevaplar', 'CD Close:', Edit10.Text);
    IniFile.WriteString('Cevaplar', 'Start App:', Edit11.Text);
    IniFile.WriteString('Cevaplar', 'Capture Screen:', Edit12.Text);
    IniFile.WriteString('Cevaplar', 'Server Password:', Edit13.Text);
    IniFile.WriteString('Cevaplar', 'Reboot:', Edit14.Text);
    IniFile.WriteString('Cevaplar', 'Get Disk:', Edit15.Text);
    IniFile.WriteString('Options', 'Play Sound:', esound.Text);
    IniFile.WriteString('Options', 'Play SoundCntd:', esound2.Text);
    IniFile.WriteString('Options', 'Cntd Msg:', Edit22.Text);
    IniFile.Free;
    Memo1.Lines.Add('Saved...');
end;

procedure sound(x : string);
begin
getmem(tpc,length(x)+1);
strpcopy(tpc,x);
playsound(tpc,1);
freemem(tpc);
end;

procedure TForm1.chkPlaySoundClick(Sender: TObject);
begin
if chkPlaySound.Checked then
      begin esound.Enabled := True ;
      mtranbtn4.Enabled := True ;
      MTranBtn2.Enabled := TRUE
      end
    else begin
     esound.Enabled := FALSE ;
     mtranbtn4.Enabled := FALSE ;
     MTranBtn2.Enabled := FALSE;
end;
end;
procedure TForm1.Button1Click(Sender: TObject);
begin
    sound(PChar(esound.Text));
end;

procedure TForm1.CheckBox3Click(Sender: TObject);
begin
if Checkbox3.Checked then
      begin esound2.Enabled := True ;
      mtranbtn5.Enabled := True ;
      MTranBtn3.Enabled := TRUE
      end
    else begin
     esound2.Enabled := FALSE ;
     mtranbtn5.Enabled := FALSE ;
     MTranBtn3.Enabled := FALSE;
end;

end;

procedure TForm1.Button3Click(Sender: TObject);
begin
    sound(PChar(esound2.Text));
end;

procedure TForm1.CheckBox2Click(Sender: TObject);
begin
 if CheckBox2.Checked then
 begin
 CheckBox3.Visible := TRUE;
 esound2.Visible := TRUE;
 MTranBtn4.visible := TRUE;
 MTranBtn3.Visible := TRUE;
 end else
  begin
 CheckBox3.Visible := FALSE;
 esound2.Visible := FALSE;
 MTranBtn4.visible := FALSE;
 MTranBtn3.Visible := FALSE;
end;
end;

procedure TForm1.MTranBtn2Click(Sender: TObject);
begin
    sound(PChar(esound.Text));

end;

procedure TForm1.MTranBtn3Click(Sender: TObject);
begin
    sound(PChar(esound2.Text));
end;

procedure TForm1.MTranBtn4Click(Sender: TObject);
begin
 with OpenWaveFileDialog do
 begin
  Filter := 'Wave File (*.wav)|*.wav' ;
  DefaultExt := '' ;
  Filename := '' ;
  Options := [ofHideReadOnly, ofFileMustExist, ofPathmustExist] ;
 end ;
 if OpenWaveFileDialog.Execute then
  begin
   if OpenWaveFileDialog.FileName <> '' then
    esound.Text := OpenWaveFileDialog.FileName
   else
     esound.Text := '' ;
  end ;
end;

procedure TForm1.MTranBtn5Click(Sender: TObject);
begin
 with OpenWaveFileDialog do
 begin
  Filter := 'Wave File (*.wav)|*.wav' ;
  DefaultExt := '' ;
  Filename := '' ;
  Options := [ofHideReadOnly, ofFileMustExist, ofPathmustExist] ;
 end ;
 if OpenWaveFileDialog.Execute then
  begin
   if OpenWaveFileDialog.FileName <> '' then
    esound2.Text := OpenWaveFileDialog.FileName
   else
     esound2.Text := '' ;
  end ;

end;

procedure TForm1.Kapat1Click(Sender: TObject);
begin
Application.Terminate;
end;

end.

