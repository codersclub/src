program lamebus;

uses
  Forms,
  Main in '..\Main.pas' {Form1};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'LameBus';
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

