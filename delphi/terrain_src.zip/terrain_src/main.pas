unit main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  terrain, ExtCtrls, opengl, glex, ScreenGrab;

type
  TForm1 = class(TForm)
    Timer1: TTimer;
    Timer2: TTimer;
    Timer3: TTimer;
    OpenDialog1: TOpenDialog;
    SaveDialog1: TSaveDialog;
    OpenDialog2: TOpenDialog;
    sGrab: tScreenGrab;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure FormResize(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormMouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseUp(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure FormMouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
    procedure Timer1Timer(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
    procedure Timer2Timer(Sender: TObject);
    procedure Timer3Timer(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;


const
{     leftX =-24;
     rightX= 23;
     topZ  =-24;
     bottomZ=23;}
     sealvl=1.5;
     r_x: integer = 128;
     mapDisplay: boolean = false;
     mouse_button: boolean = false;

var
  Form1: TForm1;
  dc: HDC; HRC: HGLRC;
  t1:tterrain;
  sin_t,cos_t: array [0..255] of real;
  sinus:array[0..359] of real;
  map: tvoidtextureRGBA;
  mapX, mapZ, lookx, looky, lookz, speed, delf, alti, aton: real;
  o_mx, o_my, delta: integer;
  loop, foggy: boolean;
  vendor,renderer,dims:string;
  count,excount, fps, maxfps:longint;
  leftX,rightX,topZ,bottomZ,rmx,rmz:integer;

//  b:word;

implementation

{$R *.DFM}


function checkHeight:real;
var x0, x1, lx, lz, midpoint:real;
    fx, fz: integer;
begin
fx:= trunc(mapX);
fz:= trunc(mapZ);
lx:= frac(mapx); lz:=frac(mapz);

x0:= t1.hf[INDEX(fx,fz)] + (t1.hf[INDEX(fx,fz+1)] - t1.hf[INDEX(fx,fz)])*lz;
x1:= t1.hf[INDEX(fx+1,fz)] + (t1.hf[INDEX(fx+1,fz+1)] - t1.hf[INDEX(fx+1,fz)])*lz;
midpoint:= x0 + (x1 - x0)*lx;
if midpoint<sealvl then midpoint:=sealvl;
result:=midpoint + 4.0;
end;

procedure DrawMap;
var r, g, b:byte;
    i: integer;
begin
map:=tvoidtextureRGBA.create(tex_map,256,256);
for i:=0 to MAPSIZE*MAPSIZE-1 do
 begin
 if t1.hf[i]>(64 + random(32768) mod 8) then
  begin
  r:= 255;
  g:= 255;
  b:= 255;
  end
 else
  if t1.hf[i]>(8 + random(32768) mod 8) then
   begin
   r:= 0;
   g:= 128;
   b:= 0;
   end
  else
   if t1.hf[i]>0 then
    begin
    r:= 255;
    g:= 230;
    b:= 50;
    end
   else
    begin
    r:= 50;
    g:= 50;
    b:= 200;
    end;
 map.pixels^[i].r := round(r * (t1.cm[i]-0.5));
 map.pixels^[i].g := round(g * (t1.cm[i]-0.5));
 map.pixels^[i].b := round(b * (t1.cm[i]-0.5));
 map.pixels^[i].a :=100;
 end;

glBindTexture(GL_TEXTURE_2D, map.ID);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);

glTexImage2D(GL_TEXTURE_2D, 0, 4, map.width, map.height, 0,
                             GL_RGBA, GL_UNSIGNED_BYTE, map.pixels);
map.Free;
end;

procedure TForm1.FormCreate(Sender: TObject);
const fogcolor: tvec4f= (0.6, 0.6, 0.9, 0.0);
var i: word;
begin

loop:=true;
mapX:=128.1; mapZ:=128.1;
lookx:=100; looky:=0; lookz:=100;
aton:=0;
speed:=0;
alti:=0;
delta:=0;
for i:= 0 to 255 do
 begin
 sin_t[i]:= sin((i/128) * PI);
 cos_t[i]:= cos((i/128) * PI);
 end;
for i:=0 to 359 do sinus[i]:=sin(i*0.0174)/10;

if not InitOpenGL then halt(1);
DC := GetDC(handle);
hrc:=CreateRenderingContext(dc,[opDoubleBuffered],32,0);
ActivateRenderingContext(dc,hrc);
initGL(Width, Height);

dims:=inttostr(clientwidth)+'/'+inttostr(clientheight);
renderer:=StrPas(PChar(glGetString(GL_renderer)));
vendor:=StrPas(PChar(glGetString(GL_vendor)));
excount:=0;count:=0;
maxfps:=0;

t1:=tTerrain.Create;
t1.loadera('carpat.era');
drawmap;

leftX :=-24;
rightX:= 23;
topZ  :=-24;
bottomZ:=23;
glEnable(GL_TEXTURE_2D);

glFogi(GL_FOG_MODE, GL_linear);
glFogfv(GL_FOG_COLOR, @fogcolor);
glFogf(GL_FOG_DENSITY, 1);
glFogf(GL_FOG_START, 200.0);
glFogf(GL_FOG_END, 230.0);
glHint(GL_FOG_HINT, GL_fastest);
glenable(gl_fog);
 //glrotatef(30,0,0,1);
timer1.Enabled:=true;
end;
 {$i protex.pas}
procedure SetColor(x:single);
begin
glColor3f(x, x, x)
end;
procedure SetColor2(x,a:single);
begin
glColor4f(x, x, x,a)
end;

procedure Drawscene;
var x, z: integer;
    x1, z1, texsup, ql, x1t,z1t,
      ixz,ix1z,ixz1,ix1z1: integer;
    lx, lz, tc1,tc2,tc3,tc4,xt,zt,delft,selt,tmp: real;
{        1
       8---2
      7|   |3
       6---4
         5                }
begin
glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT);
glenable(gl_depth_test);
resizeviewport(form1.width, form1.Height);

glPushMatrix;

lx:=mapX - round(mapX); lz:=mapZ - round(mapZ);
tmp:=checkHeight;
if alti<tmp then alti:=tmp;
gluLookAt(0, alti, 0, lookx, alti+looky, lookz, 0, 1, 0);
//glrotatef(aton,lookx,looky,lookz);
glScalef(8.001, 1.001, 8.001);
glTranslatef(-lx, 0, -lz);



glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_modulate);
rmx:=round(mapX); rmz:=round(mapZ);

if (lookx>-0.7072) and (lookx<0.707) and (lookz<0) then  //V
 begin
 leftX := -31;
 topZ := -31;
 rightX := 32;
 bottomZ := 2;
 end
else
 if (lookx<0) and (lookz<0.707) and (lookz>-0.707) then  //>
  begin
  leftX := -31;
  topZ := -31;
  rightX := 2;
  bottomZ := 32;
  end
 else
  if (lookx>0) and (lookz<0.707) and (lookz>-0.7072) then
   begin
   leftX := -2;
   topZ := -31;
   rightX := 32;
   bottomZ := 32;
   end
  else
   begin
   leftX := -31;
   topZ := -2;
   rightX := 32;
   bottomZ := 32;
   end;

for x:=leftX to rightX do
 begin
 x1:=rmx + x;
 x1t:=x1+1;
 tc1:=x1/TEXRES;
 tc2:=x1t/TEXRES;
 xt:=x+1;
 for z:=topZ to bottomZ do
  begin
  z1:=rmz + z;
  z1t:=z1+1;
  tc3:=z1/TEXRES;
  tc4:=z1t/TEXRES;
  zt:=z+1;
  ixz:=INDEX(x1,z1);
  ix1z:=INDEX(x1t,z1);
  ixz1:=INDEX(x1,z1t);
  ix1z1:=INDEX(x1t,z1t);
  ql:=t1.tt[ixz];

 // gldisable(gl_texture_2d);

  if ql>tex_snow then     //patch
   begin
   glBindTexture(GL_TEXTURE_2D, ql);
   glBegin(GL_quads);
   tmp:=t1.cm[ixz];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(0.25, 0.25);
//glTexCoord2f(0, 0);
   glVertex3f(x, t1.hf[ixz], z);

   tmp:=t1.cm[ix1z];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(0.75, 0.25);
//glTexCoord2f(1, 0);
   glVertex3f(xt, t1.hf[ix1z], z );

   tmp:=t1.cm[ix1z1];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(0.75, 0.75);
//glTexCoord2f(1, 1);
   glVertex3f(xt, t1.hf[ix1z1], zt );

   tmp:=t1.cm[ixz1];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(0.25, 0.75);
//glTexCoord2f(0, 1);
   glVertex3f(x, t1.hf[ixz1], zt);
   glEnd;
   end
  else
   begin
   glBindTexture(GL_TEXTURE_2D, ql);
   glBegin(GL_quads);
   tmp:=t1.cm[ixz];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(tc1, tc3);
   glVertex3f(x, t1.hf[ixz], z);

   tmp:=t1.cm[ix1z];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(tc2, tc3);
   glVertex3f(xt, t1.hf[ix1z], z );

   tmp:=t1.cm[ix1z1];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(tc2, tc4);
   glVertex3f(xt, t1.hf[ix1z1], zt );

   tmp:=t1.cm[ixz1];
   glColor3f(tmp,tmp,tmp);
   glTexCoord2f(tc1, tc4);
   glVertex3f(x, t1.hf[ixz1], zt);
   glEnd;
   end;
  if t1.ob[ixz]=1 then tree(x,z,t1.hf[ixz]);
  end;
 end;

glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
delf:=sinus[delta];
selt:=sealvl+delf;
delft:=delf+1;
glBindTexture(GL_TEXTURE_2D, tex_sea);
for x:=leftx to rightx do
 begin
 x1:=rmx + x;
 xt:=x+1;
 x1t:=x1+1;
 tc1:=x1/4+delf;
 tc2:=x1t/4+delf;
 for z:=topz to bottomz do
  begin
  z1:=rmz + z;
  zt:=z+1;
  z1t:=z1+1;
  tc3:=z1/4+delf;
  tc4:=z1t/4+delf;
  ql:=t1.hf[index(x1,z1)];
  if (ql<6) or (t1.hf[index(x1t,z1)]<6) or
     (t1.hf[index(x1,z1t)]<6) or (t1.hf[index(x1t,z1t)]<6) then
   begin
   glBegin(gl_quads);
   glTexCoord2f(tc1, tc3);
//   glTexCoord2f(delf, delf);
   glVertex3f(x,selt,z);
   glTexCoord2f(tc2, tc3);
//   glTexCoord2f(delft, delf);
   glVertex3f(xt, selt, z);
   glTexCoord2f(tc2, tc4);
//   glTexCoord2f(delft, delft);
   glVertex3f(xt, selt, zt);
   glTexCoord2f(tc1, tc4);
//   glTexCoord2f(delf, delft);
   glVertex3f(x, selt, zt);
   glEnd;
   end;
  end;
 end;

glPopMatrix;


if mapDisplay then
 begin
 glBindTexture(GL_TEXTURE_2D, tex_map);
 glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
 glDisable(GL_DEPTH_TEST);

 glMatrixMode(GL_PROJECTION);
 glLoadIdentity;
 gluOrtho2D(0, form1.Width, form1.Height, 0); // Set up a 2D screen.
 glTranslatef(0.0, 20.0, 0.0);

 SetColor(1.0);
 glBegin(GL_QUADS);
  glTexCoord2f(0.0, 0.0);
  glVertex2f(0.0, 0.0);
  glTexCoord2f(1.0, 0.0);
  glVertex2f(256.0, 0.0);
  glTexCoord2f(1.0, 1.0);
  glVertex2f(256.0, 256.0);
  glTexCoord2f(0.0, 1.0);
  glVertex2f(0.0, 256.0);
 glEnd;

 glDisable(GL_TEXTURE_2D);
 glRectf(mapX - 2.0, mapZ - 2.0, mapX + 2.0, mapZ + 2.0);

 glBegin(GL_LINES);
  glVertex2f(mapX, mapZ);
  glVertex2f(mapX + (lookx * 16), mapZ + (lookz * 16));
 glEnd;
 glEnable(GL_TEXTURE_2D);
 glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_modulate);
 end;
glFinish;
SwapBuffers(DC);
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
DestroyRenderingContext(hrc);
closeOpenGL;
t1.Deinit;
end;

procedure TForm1.FormResize(Sender: TObject);
begin
resizeviewport(Width, Height);
dims:=inttostr(clientwidth)+'/'+inttostr(clientheight);
maxfps:=0;
end;

procedure mainloop;
begin
repeat
 r_x:=r_x and 255;
 mapX:= mapX+ lookx * speed;
 mapZ:= mapZ+ lookz * speed;
 alti:=alti+ looky *speed*10;
 if mapX<0 then mapX:= mapX + MAPSIZE
 else if mapX > MAPSIZE then mapX:= mapX-MAPSIZE;
 if mapZ<0 then mapZ:= mapZ + MAPSIZE
 else if mapZ > MAPSIZE then mapZ:= mapZ-MAPSIZE;
 lookx:= sin_t[r_x];
 lookz:= cos_t[r_x];
 if looky<-2 then looky:=-2;
 if looky>2 then looky:=2;
 drawScene;
 inc(count,1);
 application.ProcessMessages;
until not loop;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
loop:=false;
end;

procedure TForm1.FormMouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
mouse_button:= TRUE;
end;

procedure TForm1.FormMouseUp(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
mouse_button:= false;
aton:=0;
end;

procedure TForm1.FormMouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
begin
if mouse_button=TRUE then
 begin
 r_x:= r_x+ (o_mx - x);
 aton:=aton+ (o_mx - x)/5.01;
 if aton>45 then aton:=45
  else if aton<-45 then aton:=-45;
 looky:=looky+ (o_my - y)/100.01;
 end;
 o_mx:=x;
 o_my:=y;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
timer1.Enabled:=false;
mainloop;
end;

procedure TForm1.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
begin
//showmessage(inttostr(key));
case key of
 38: speed:=speed+0.03;
 40: speed:=speed-0.03;
 33: alti:=alti+0.4;
 34: alti:=alti-0.4;

 13: if(glIsEnabled(GL_FOG)=gl_FALSE) then glEnable(GL_FOG)
                                   else glDisable(GL_FOG);
 32: begin
     t1.Deinit;count:=0;
     t1:=tTerrain.Create;
     t1.NewFractal;
     repeat inc(count); until t1.Smoothen;
     t1.wcorner;
     t1.gentrantex;
     t1.puttrees;
     drawmap;
     //showmessage(inttostr(count));
     end;
 77: if mapdisplay then mapdisplay:=false else mapdisplay:=true;
112: showmessage('Space: generate new terrain'+#13+
                 'F3 : load a .era file'+#13+
                 'F2 : save a .era file'+#13+
                 'F4 : load a Lon/Lat text mesh'+#13+
                 'F5 : screen capture'+#13+
                 'Enter: fog on/off'+#13+
                 'm: show/hide map'+#13+
                 'PGUP/PGDN: altitude'+#13+#13+
                 'Version 1.0 (c)Vlad Parcalabior - ArrowSoft 2000');
113: if savedialog1.Execute then
         t1.saveera(savedialog1.FileName);
114: if opendialog1.Execute then
         begin
         t1.Deinit;
         t1:=tterrain.Create;
         t1.loadera(opendialog1.FileName);
         drawmap;
         end;
115: if opendialog2.Execute then
         begin
         t1.Deinit;
         t1:=tterrain.Create;
         t1.loadtxt(opendialog2.FileName);
         drawmap;
         end;
116:  begin
      sgrab.StartX:=form1.Left;
      sgrab.StartY:=form1.Top;
      sgrab.width:=form1.Width;
      sgrab.height:=form1.Height;
      sgrab.GetBMP;
      sgrab.SaveAsBMP;
      end;
 end;
end;

procedure TForm1.Timer2Timer(Sender: TObject);
begin
inc(delta,5);if delta>=360 then delta:=0;
end;

procedure TForm1.Timer3Timer(Sender: TObject);
begin
fps:=count-excount;
//if maxfps<fps then maxfps:=fps;
form1.Caption:='Renderer: '+vendor+' '+renderer+' '+dims+' fps: '+inttostr(fps);
//+' x:'+inttostr(rmx)+' z:'+inttostr(rmz)+' bb:'+inttostr(t1.bb[index(rmx,rmz)]);

//+' x:'+ floattostrf(lookx,fffixed,5,4)+' z:'+floattostrf(lookz,fffixed,5,4);
excount:=count;
end;

end.
