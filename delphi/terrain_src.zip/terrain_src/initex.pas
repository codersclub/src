procedure tterrain.inittex;
begin
sform.mylabel3d1.caption:='Loading textures, please wait...';
tex[tex_sand]:=ttexture.Load(tex_sand,'sand.jpg');
glgentextures(1, @tex[tex_sand].ID);
glBindTexture(GL_TEXTURE_2D, tex[tex_sand].ID);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_Linear_MIPMAP_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_modulate);
//glTexImage2D(GL_TEXTURE_2D, 0, 3, tex[tex_sand].width, tex[tex_sand].height,
//                            0, GL_RGB, GL_UNSIGNED_BYTE, tex[tex_sand].pixels^);
gluBuild2DMipmaps(GL_TEXTURE_2D, 3, tex[tex_sand].width, tex[tex_sand].height,
                  GL_RGB, GL_UNSIGNED_BYTE, tex[tex_sand].pixels);

tex[tex_grass]:=ttexture.Load(tex_grass,'grass.jpg');
glgentextures(1, @tex[tex_grass].ID);
glBindTexture(GL_TEXTURE_2D, tex[tex_grass].ID);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_modulate);
//glTexImage2D(GL_TEXTURE_2D, 0, 3, tex[tex_grass].width, tex[tex_grass].height,
//                            0, GL_RGB, GL_UNSIGNED_BYTE, tex[tex_grass].pixels);
gluBuild2DMipmaps(GL_TEXTURE_2D, 3, tex[tex_grass].width, tex[tex_grass].height,
                  GL_RGB, GL_UNSIGNED_BYTE, tex[tex_grass].pixels);

tex[tex_dirt]:=ttexture.Load(tex_dirt,'dirt.jpg');
glgentextures(1, @tex[tex_dirt].ID);
glBindTexture(GL_TEXTURE_2D, tex[tex_dirt].ID);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
//glTexImage2D(GL_TEXTURE_2D, 0, 3, tex[tex_dirt].width, tex[tex_dirt].height,
//                            0, GL_RGB, GL_UNSIGNED_BYTE, tex[tex_dirt].pixels^);
gluBuild2DMipmaps(GL_TEXTURE_2D, 3, tex[tex_dirt].width, tex[tex_dirt].height,
                  GL_RGB, GL_UNSIGNED_BYTE, tex[tex_dirt].pixels);

tex[tex_snow]:=ttexture.Load(tex_snow,'snow.jpg');
glgentextures(1, @tex[tex_snow].ID);
glBindTexture(GL_TEXTURE_2D, tex[tex_snow].ID);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_decal);
//glTexImage2D(GL_TEXTURE_2D, 0, 3, tex[tex_snow].width, tex[tex_snow].height,
//                            0, GL_RGB, GL_UNSIGNED_BYTE, tex[tex_snow].pixels^);
gluBuild2DMipmaps(GL_TEXTURE_2D, 3, tex[tex_snow].width, tex[tex_snow].height,
                  GL_RGB, GL_UNSIGNED_BYTE, tex[tex_snow].pixels);

tex[tex_sea]:=ttexture.Load(tex_sea,'sea.rgba');
glgentextures(1, @tex[tex_sea].ID);
glBindTexture(GL_TEXTURE_2D, tex_sea);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_NEAREST);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
//glTexImage2D(GL_TEXTURE_2D, 0, 4, tex[tex_sea].width, tex[tex_sea].height,
//                            0, GL_RGBA, GL_UNSIGNED_BYTE, tex[tex_sea].pixels^);
gluBuild2DMipmaps(GL_TEXTURE_2D, 4, tex[tex_sea].width, tex[tex_sea].height,
                  GL_RGBA, GL_UNSIGNED_BYTE, tex[tex_sea].pixels);


{texsky:=ttexture.Load(tex_sky0,'sky00.jpg');
glBindTexture(GL_TEXTURE_2D, tex_sky0);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
glTexImage2D(GL_TEXTURE_2D, 0, 3, texsky.width, texsky.height,
                            0, GL_RGB, GL_UNSIGNED_BYTE, texsky.pixels^);
texsky.Free;

texsky:=ttexture.Load(tex_sky1,'sky01.jpg');
glBindTexture(GL_TEXTURE_2D, tex_sky1);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
glTexImage2D(GL_TEXTURE_2D, 0, 3, texsky.width, texsky.height,
                            0, GL_RGB, GL_UNSIGNED_BYTE, texsky.pixels^);
texsky.Free;

texsky:=ttexture.Load(tex_sky2,'sky02.jpg');
glBindTexture(GL_TEXTURE_2D, tex_sky2);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
glTexImage2D(GL_TEXTURE_2D, 0, 3, texsky.width, texsky.height,
                            0, GL_RGB, GL_UNSIGNED_BYTE, texsky.pixels^);
texsky.Free;

texsky:=ttexture.Load(tex_sky3,'sky03.jpg');
glBindTexture(GL_TEXTURE_2D, tex_sky3);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_clamp);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
glTexImage2D(GL_TEXTURE_2D, 0, 3, texsky.width, texsky.height,
                            0, GL_RGB, GL_UNSIGNED_BYTE, texsky.pixels^);
texsky.Free;

texsky:=ttexture.Load(tex_skytop,'skytop0.jpg');
glBindTexture(GL_TEXTURE_2D, tex_skytop);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_repeat);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_nearest);
glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_replace);
glTexImage2D(GL_TEXTURE_2D, 0, 3, texsky.width, texsky.height,
                            0, GL_RGB, GL_UNSIGNED_BYTE, texsky.pixels^);
texsky.Free;  }

glTexEnvi(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_modulate);
end;