{GLex v0.2 25.05.99 by ArrowSoft-VMP}

unit glex;

interface
uses Windows, dialogs, sysutils, forms, graphics, jpeg, opengl;

type Tvec3f=array[0..2] of GLfloat;
     pTvec3f=^Tvec3f;
     Tvec4f=array[0..3] of GLfloat;
     pTvec4f=^Tvec4f;

     TColorRGB = packed record
               r, g, b	: BYTE;
               end;
     PColorRGB = ^TColorRGB;

     TRGBList = packed array[0..0] of TColorRGB;
     PRGBList = ^TRGBList;

     TColorRGBA = packed record
               r, g, b, a : BYTE;
               end;
     PColorRGBA = ^TColorRGBA;

     TRGBAList = packed array[0..0] of TColorRGBA;
     PRGBAList = ^TRGBAList;


type TTexture=class(tobject)
      ID, width, height:integer;
      pixels: pRGBlist;
      constructor Load(tID:integer;filename:string);
      destructor destroy; override;
     end;

     TVoidTexture=class(tobject)
      ID, width, height:integer;
      pixels: pRGBlist;
      constructor create(tid, twidth, theight:integer);
      destructor destroy; override;
     end;

     TTextureRGBA= class(TTexture)
      pixels: pRGBAlist;
     end;

     TVoidTextureRGBA=class(tobject)
      ID, width, height:integer;
      pixels: pRGBAlist;
      constructor create(tid, twidth, theight:integer);
      destructor destroy; override;
     end;

const use_frustum = true;
      fovX = 60.0;

var   //dc: HDC;
      //HRC: HGLRC;
      texID: integer;

procedure ResizeViewport(width,height:longint);
//Procedure InitRC(hnd:tHandle);
//Procedure ReleaseRC(hnd:thandle);
Procedure InitGL(width,height:longint);
procedure Normalize(var v: tvec3f);
function NormVecProd(v1,v2: tvec3f):tvec3f;

implementation

constructor tTexture.Load(tID:integer; filename:string);
var f:file;
    dims: array[0..3] of byte;
    actread:integer;
    fext:string;
    bmp:tbitmap; jpg:tjpegimage;
    i,j:integer;
    pixline: pRGBlist;
    r,g,b:byte;

begin
inherited create;
if not fileexists(filename) then begin messagedlg(filename+' not found',mterror,[mbabort],0); halt(1);end;
fExt:=uppercase(ExtractFileExt(filename));
ID:=tID;
if fext='.RGBA' then
 begin
 assign(f,filename);
 {$i-}
 reset(f,4);
 blockread(f,dims,1);
 {$i+}
 if ioresult<>0 then begin messagedlg(filename+' not found',mterror,[mbabort],0); halt(1);end;
 Width:=dims[0]+dims[1]*256; Height:=dims[2]+dims[3]*256;
 getmem(pixels,(filesize(f)-1)*4);
 blockread(f,pixels^,width*height,actread);
 closefile(f);
 end
else
if fext='.RGB' then
 begin
 assign(f,filename);
 {$i-}
 reset(f,1);
 blockread(f,dims,4);
 {$i+}
 if ioresult<>0 then begin messagedlg(filename+' not found',mterror,[mbabort],0); halt(1);end;
 Width:=dims[0]+dims[1]*256; Height:=dims[2]+dims[3]*256;
 getmem(pixels,filesize(f)-4);
 blockread(f,pixels^,width*height*3,actread);
 closefile(f);
 end
else
if fext='.BMP' then
 begin
 bmp:=TBitmap.Create;
 bmp.HandleType:=bmDIB;
 bmp.PixelFormat:=pf24bit;
 bmp.LoadFromFile(filename);
 Width:=bmp.Width;
 Height:=bmp.Height;
 getmem(pixels,width*height*3);
 for i:=0 to height-1 do
  begin
  pixline:=bmp.ScanLine[i];
  for j:=0 to width-1 do
   begin
   r:=pixline[j].b;
   g:=pixline[j].g;
   b:=pixline[j].r;
   pixels[i*width+j].r:=r;
   pixels[i*width+j].g:=g;
   pixels[i*width+j].b:=b;
   end;
  end;
 bmp.Free;
 end
else
if fext='.JPG' then
 begin
 jpg:=tjpegimage.Create;
 jpg.LoadFromFile(filename);
 bmp:=TBitmap.Create;
 bmp.HandleType:=bmDIB;
 bmp.PixelFormat:=pf24bit;
 Width:=jpg.Width;
 Height:=jpg.Height;
 bmp.Width:=Width;
 bmp.Height:=Height;
 bmp.Assign(jpg);
 getmem(pixels,width*height*3);
 for i:=0 to height-1 do
  begin
  pixline:=bmp.ScanLine[i];
  for j:=0 to width-1 do
   begin
   r:=pixline[j].b;
   g:=pixline[j].g;
   b:=pixline[j].r;
   pixels[i*width+j].r:=r;
   pixels[i*width+j].g:=g;
   pixels[i*width+j].b:=b;
   end;
  end;
 bmp.Free;
 jpg.Free;
 end;
end;

destructor TTexture.destroy;
begin
freemem(pixels);
inherited destroy;
end;

constructor tvoidtexture.create(tid, twidth, theight:integer);
begin
inherited create;
id:=tid;
width:=twidth; height:=theight;
getmem(pixels,width*height*3);
end;

destructor tvoidtexture.destroy;
begin
freemem(pixels);
inherited destroy;
end;

constructor tvoidtextureRGBA.create(tid, twidth, theight:integer);
begin
inherited create;
id:=tid;
width:=twidth; height:=theight;
getmem(pixels,width*height*4);
end;

destructor tvoidtextureRGBA.destroy;
begin
freemem(pixels);
inherited destroy;
end;

procedure normalize(var v: tvec3f);
var d: glfloat;
begin
d:=sqrt(v[0]*v[0]+v[1]*v[1]+v[2]*v[2]);
if d<>0 then
 begin
 v[0]:=v[0]/d;
 v[1]:=v[1]/d;
 v[2]:=v[2]/d;
 end;
end;

function NormVecProd(v1,v2: tvec3f):tvec3f;
var r:tvec3f;
begin
r[0]:= v1[1]*v2[2] - v1[2]*v2[1];
r[1]:= v1[2]*v2[0] - v1[0]*v2[2];
r[2]:= v1[0]*v2[1] - v1[1]*v2[0];
normalize(r);
result:=r;
end;

function tan(x:extended):extended;
begin
result:=sin(x)/cos(x);
end;


procedure ResizeViewport(width,height:longint);
var znear, zfar, aspect: double;
    left, right, bottom, top: double;

begin
znear := 1;
zfar  := 600;
glViewport(0, 0, width, height);

aspect := width/height;

glMatrixMode(GL_PROJECTION);
glLoadIdentity();

if USE_FRUSTUM then
 begin
 right := znear * tan(fovX/2.0 * PI/180.0);
 top := right / aspect;
 bottom := -top;
 left := -right;
 glFrustum(left, right, bottom, top, znear, zfar);
 end
else
 gluPerspective(fovX/aspect, aspect, znear, zfar);
glMatrixMode(GL_MODELVIEW);
end;

{Procedure SetDCPixelFormat;
var
  nPixelFormat: Integer;
  pfd: tPixelFormatDescriptor;
begin
  FillChar(pfd, SizeOf(pfd),0);
  with pfd do begin
    nSize     := sizeof(pfd);                               // Size of this structure
    nVersion  := 1;                                         // Version number
    dwFlags   := PFD_DRAW_TO_window or
                 PFD_SUPPORT_OPENGL or
                 PFD_DOUBLEBUFFER;                          // Flags
    iPixelType:= PFD_TYPE_RGBA;                             // RGBA pixel values
    cColorBits:= 32;                                        // 24-bit color
    cDepthBits:= 32;                                        // 32-bit depth buffer
    iLayerType:= PFD_MAIN_PLANE;                            // Layer type
  end;
  nPixelFormat := ChoosePixelFormat(DC, @pfd);
  SetPixelFormat(DC, nPixelFormat, @pfd);
  DescribePixelFormat(DC, nPixelFormat, sizeof(TPixelFormatDescriptor), @pfd);
end;

Procedure InitRC(hnd:tHandle);
begin
DC := GetDC(hnd);
SetDCPixelFormat;
HRC := wglCreateContext(DC);
wglMakeCurrent(DC, HRC);
end;

Procedure ReleaseRC(hnd:thandle);
begin
wglMakeCurrent(0, 0);
wglDeleteContext(HRC);
ReleaseDC(hnd, DC);
end;}

Procedure InitGL(width,height:longint);
begin
glClearColor(0.6, 0.6, 0.9, 0.0);
glClearDepth(1.0);
glClear(GL_COLOR_BUFFER_BIT or GL_DEPTH_BUFFER_BIT);
glShadeModel(GL_SMOOTH);
glDepthFunc(GL_lequal);
glFrontFace(GL_CW);
glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
glBlendFunc(GL_src_alpha, GL_ONE_MINUS_SRC_ALPHA);
glAlphaFunc(GL_GEQUAL, 0.05);

gldisable(gl_color_material);
glenable(GL_DEPTH_TEST);
glenable(GL_CULL_FACE);
glenable(GL_BLEND);
gldisable(GL_ALPHA_TEST);
gldisable(GL_LIGHTING);

glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_fastest);

ResizeViewport(width, height);
end;


end.
