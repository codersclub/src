unit terrain;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs, glex,
  StdCtrls, Mylabel;

type
  Tsform = class(TForm)
    myLabel3d1: TmyLabel3d;
    Label1: TLabel;

    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
    sfclose:boolean;
  end;

const texsize=64;      // textures must be squares 64x64
      texres=8;        // 1 texture on 8x8 land tiles.
      transize=texsize div texres; //8x8 pixels
      patchsize=transize*2; //16x16 pixels

const
  MAPSHIFT= 8;
  MAPSIZE= 256;
  tex_map=100;
  tex_sand=1;
  tex_grass=2;
  tex_dirt=3;
  tex_snow=4;
  tex_sea=5;
  tex_temp=99;
//     tex_sky0=6; tex_sky1=7; tex_sky2=8; tex_sky3=9;tex_skytop=10;

type
     ttempstruc=array[0..patchsize-1, 0..patchsize-1] of tcolorRGB;
     tstencil=array[0..patchsize-1, 0..patchsize-1] of byte;
     tstencilindex=array[0..3104] of byte;
     tstencilarray=array[1..48] of tstencil;
{$i stencils.pas}

type
    TLIntArray = packed array [0..0] of longint;
    TfloatArray = packed array [0..0] of real;
    TByteArray = packed array [0..0] of byte;
    TWordArray = packed array [0..0] of word;
    TsmintArray = packed array [0..0] of smallint;
    tTerrain=class
              hf: ^TsmintArray; //heightfield
              cm: ^tfloatarray; //colormap
              bb: ^twordarray; //stenciltype
              ob: ^tbytearray; //objects
              tt: ^tlintarray; //texture type
              texlist: array[1..10000] of longint;
              count:word;
              stencilindex: tstencilindex;
              tex: array [1..5] of ttexture;
              tempstruc: ttempstruc;
              sform: Tsform;
              constructor Create;
              procedure NewFractal;
              procedure inittex;
              function quadlevel(x1,z1:integer):integer;
              function Smoothen:boolean;
              procedure Shade;
              procedure loadtxt(name:string);
              procedure saveera(name:string);
              procedure loadera(name:string);
              procedure make_stencilindex;
              procedure puttrees;
              procedure wcorner;
              procedure gentrantex;
              procedure makepatch(level_tex,next_tex:byte;x1,z1:integer; stencil_index:byte);
              destructor Deinit;
              end;



function index(x,y:integer):integer;





implementation {\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\/\}
uses opengl;
{$R *.DFM}

function index;
begin
result:=(x and 255) + (y and 255) shl mapshift;
end;

constructor tTerrain.Create;
var i:longint;
begin
try
 getmem(hf, mapsize*mapsize*sizeof(smallint));
 getmem(cm, mapsize*mapsize*sizeof(real));
 getmem(bb, mapsize*mapsize*sizeof(word));
 getmem(ob, mapsize*mapsize*sizeof(byte));
 getmem(tt, mapsize*mapsize*sizeof(longint));
except
 halt(1);
end;
for i:=0 to mapsize*mapsize-1 do
 begin
 hf^[i]:=0;
 cm^[i]:=0;
 bb^[i]:=0;
 ob^[i]:=0;
 tt^[i]:=100;
 end;
make_stencilindex;
sform:=tsform.Create(application);
sform.sfclose:=false;
inittex;
end;

destructor tTerrain.Deinit;
var i:byte;
begin
if hf<>nil then freemem(hf);
if cm<>nil then freemem(cm);
if bb<>nil then freemem(bb);
if ob<>nil then freemem(ob);
if tt<>nil then freemem(tt);
for i:=tex_sand to tex_sea do tex[i].free;
end;

{$i initex.pas}

procedure tterrain.make_stencilindex;
begin
fillchar(stencilindex, 3104, 0);
stencilindex[131]:=1;
stencilindex[3]:=2;
stencilindex[129]:=3;
stencilindex[1]:=4;
stencilindex[14]:=5;
stencilindex[12]:=6;
stencilindex[6]:=7;
stencilindex[4]:=8;
stencilindex[56]:=9;
stencilindex[48]:=10;
stencilindex[24]:=11;
stencilindex[16]:=12;
stencilindex[224]:=13;
stencilindex[192]:=14;
stencilindex[96]:=15;
stencilindex[64]:=16;
stencilindex[143]:=17;
stencilindex[15]:=18;
stencilindex[135]:=19;
stencilindex[7]:=20;
stencilindex[62]:=21;
stencilindex[60]:=22;
stencilindex[30]:=23;
stencilindex[28]:=24;
stencilindex[248]:=25;
stencilindex[240]:=26;
stencilindex[120]:=27;
stencilindex[112]:=28;
stencilindex[227]:=29;
stencilindex[195]:=30;
stencilindex[225]:=31;
stencilindex[193]:=32;
stencilindex[128]:=33;
stencilindex[384]:=34;
stencilindex[2176]:=35;
stencilindex[2432]:=36;
stencilindex[2]:=37;
stencilindex[258]:=38;
stencilindex[514]:=39;
stencilindex[770]:=40;
stencilindex[8]:=41;
stencilindex[520]:=42;
stencilindex[1032]:=43;
stencilindex[1544]:=44;
stencilindex[32]:=45;
stencilindex[1056]:=46;
stencilindex[2080]:=47;
stencilindex[3104]:=48;
end;

function tTerrain.quadlevel(x1,z1:integer):integer;
var max,v: integer;
begin
{max:=(t1.hf[INDEX(x1,z1)]+t1.hf[INDEX(x1+1,z1)]+
       t1.hf[INDEX(x1,z1+1)]+t1.hf[INDEX(x1+1,z1+1)]) div 4;}
v:=hf[INDEX(x1,z1)];
max:=v;
v:=hf[INDEX(x1+1,z1)];
if max<v then max:=v;
v:=hf[INDEX(x1,z1+1)];
if max<v then max:=v;
v:=hf[INDEX(x1+1,z1+1)];
if max<v then max:=v;

case max of
 -200..5: result:=tex_sand;
   6..30: result:=tex_grass;
  31..60: result:=tex_dirt;
     else result:=tex_snow;
     end;
end;

procedure tTerrain.puttrees;
var x,z:integer;
begin
fillchar(ob^,mapsize*mapsize,0);
for x:=0 to mapsize-1 do
 for z:=0 to mapsize-1 do
  if (quadlevel(x,z)=tex_dirt) and (random(25)=5) then
  //if (z+x) mod 9 = 0 then
   ob[index(x,z)]:=1;
end;

procedure tTerrain.NewFractal;
var
 x, z, bsize, csize, i, r: longint;

begin
for i:=0 to MAPSIZE*MAPSIZE-1 do
 begin
 hf^[i] := 0;
 cm^[i] := 0;
 end;
r:= 64;
bsize:= MAPSIZE;
randomize;
for i:=0 to 8 do
 begin
 x:=0;
 while x<MAPSIZE do
  begin
  z:=0;
  while z<MAPSIZE do
   begin
   hf[INDEX(x, z)]:= hf[INDEX(x, z)]+ (random(32768) mod (r+1)) - r div 2;
   inc(z,bsize);
   end;
  inc(x,bsize);
  end;

 if i>2 then r:= r div 2;
 csize:= bsize div 2;
 if csize > 0 then
  begin
  x:=0;
  while x<MAPSIZE do
   begin
   z:=0;
   while z<MAPSIZE do
    begin
    hf[INDEX(x+csize, z)]:=(hf[INDEX(x, z)] + hf[INDEX(x+bsize, z)]) div 2;
    hf[INDEX(x, z+csize)]:=(hf[INDEX(x, z)] + hf[INDEX(x, z+bsize)]) div 2;
    hf[INDEX(x+csize, z+csize)]:=(hf[INDEX(x, z)] +
                                  hf[INDEX(x+bsize, z)] +
                                  hf[INDEX(x+bsize, z+bsize)] +
                                  hf[INDEX(x, z+bsize)]) div 4;
    inc(z,bsize);
    end;
   inc(x,bsize);
   end;
  end;
  bsize:=bsize div 2;
 end;

	if true then
	for x:=0 to MAPSIZE-1 do
		for z:=0 to MAPSIZE-1 do
                 hf[INDEX(x, z)]:= (hf[INDEX(x-1, z-1)] + hf[INDEX(x-1, z)] +
                 hf[INDEX(x-1, z+1)] +
                 hf[INDEX(x, z-1)] +
                 hf[INDEX(x, z)] +
                 hf[INDEX(x, z+1)] +
                 hf[INDEX(x+1, z-1)] +
                 hf[INDEX(x+1, z)] +
                 hf[INDEX(x+1, z+1)]) div 9;

 Shade;
end;


function tTerrain.Smoothen:boolean;
var x,z:longint;
    ql,ql1,ql2,ql3,ql4,ql5,ql6,ql7,ql8,max,v,a,c:integer;
    b:word;
    re:boolean;
begin
re:=true;
for x:=0 to mapsize-1 do
 for z:=0 to mapsize-1 do
  begin
  application.ProcessMessages;
  ql:=quadlevel(x,z);

  if ql < tex_snow then
   begin
   ql1:=quadlevel(x,z-1);
   ql2:=quadlevel(x+1,z-1);
   ql3:=quadlevel(x+1,z);
   ql4:=quadlevel(x+1,z+1);
   ql5:=quadlevel(x,z+1);
   ql6:=quadlevel(x-1,z+1);
   ql7:=quadlevel(x-1,z);
   ql8:=quadlevel(x-1,z-1);

   b:=0;
   if ql1>ql then b:=1;
   if ql2>ql then b:=b or 2;
   if ql3>ql then b:=b or 4;
   if ql4>ql then b:=b or 8;
   if ql5>ql then b:=b or 16;
   if ql6>ql then b:=b or 32;
   if ql7>ql then b:=b or 64;
   if ql8>ql then b:=b or 128;

   bb[INDEX(x,z)]:=b;

   if (not (b in  [0,131,3,1,129,14,12,6,4,56,48,24,16,224,192,96,64,
                 143,15,135,7,62,60,30,28,248,240,120,112,227,195,
                 225,193,128,2,8,32]))
    {    and(b<>384) and (b<>2432) and (b<>258) and (b<>770)
        and (b<>520) and (b<>1544) and (b<>1056) and (b<>3104)}
        then
    begin
    bb[INDEX(x,z)]:=0;
    re:=false;
    v:=hf[INDEX(x,z)];
    max:=v; a:=0;c:=0;
    v:=hf[INDEX(x+1,z)];
    if max<v then begin max:=v;a:=1;end;
    v:=hf[INDEX(x,z+1)];
    if max<v then begin max:=v;a:=0;c:=1;end;
    v:=hf[INDEX(x+1,z+1)];
    if max<v then begin max:=v;a:=1;c:=1;end;
    case max of
     -200..5: hf[INDEX(x+a,z+c)]:=6;
       6..30: hf[INDEX(x+a,z+c)]:=31;
      31..60: hf[INDEX(x+a,z+c)]:=61;
     end;
    end;
   end;
  end;
result:=re;
end;

procedure tTerrain.wcorner;
var x,z:longint;
    ql,ql9,ql10,ql11,ql12:integer;
    b:word;
begin
for x:=0 to mapsize-1 do
 for z:=0 to mapsize-1 do
  begin
  ql:=quadlevel(x,z);
  ql9:=quadlevel(x,z-2);
  ql10:=quadlevel(x+2,z);
  ql11:=quadlevel(x,z+2);
  ql12:=quadlevel(x-2,z);
  b:=bb[INDEX(x,z)];
   if b=2 then
    begin
    if ql9>ql then b:=b or 256;
    if ql10>ql then b:=b or 512;
    end
   else
    if b=8 then
     begin
     if ql10>ql then b:=b or 512;
     if ql11>ql then b:=b or 1024;
     end
    else
     if b=32 then
      begin
      if ql11>ql then b:=b or 1024;
      if ql12>ql then b:=b or 2048;
      end
     else
      if b=128 then
       begin
       if ql12>ql then b:=b or 2048;
       if ql9>ql then b:=b or 256;
       end;
  bb[INDEX(x,z)]:=b;
  end;
end;

procedure tTerrain.Shade;
var
   i, c: longint;
begin
for i:=0 to MAPSIZE*MAPSIZE-1 do
 begin
 c:= (128 + (hf[i] - hf[i+1])*16);
 if c<0 then c:= 0
 else
  if c>255 then c:= 255;
 cm[i]:= c/255.0+0.5;
 end;
end;

procedure tTerrain.loadtxt(name:string);
var t:text; s:string;
     x,z:integer;
begin
assignfile(t,name);
reset(t);
for x:=0 to 256-1 do
for z:=0 to 256-1 do
begin
readln(t,s);
s:=copy(s,pos(' ',s)+1,length(s));
s:=copy(s,pos(' ',s)+1,length(s));
hf[index(z,255-x)]:=StrToInt(s);
end;
closefile(t);
repeat until Smoothen;
smoothen;
wcorner;
shade;
gentrantex;
puttrees;
end;

procedure tterrain.saveera(name:string);
var f:file of smallint; i:longint;
begin
assignfile(f,name);
rewrite(f);
for i:=0 to mapsize*mapsize-1 do
 write(f,hf[i]);
closefile(f);
end;

procedure tterrain.loadera(name:string);
var f:file of smallint; i:longint;
begin
assignfile(f,name);
if not fileexists(name) then
 begin
 showmessage(name+' not found');
 sform.sfclose:=true;
 sform.close;
 end
else
 begin
 reset(f);
 for i:=0 to mapsize*mapsize-1 do
  read(f,hf[i]);
 closefile(f);
 repeat until Smoothen;
// showmessage(inttostr(v));
 shade;
 wcorner;
 gentrantex;
 puttrees;
 end;
end;

function cpltexsize(n:integer):integer;
begin
if n<0 then result:=texsize+n
else
 if n>=texsize then result:=n-texsize
 else result:=n;
end;

procedure tterrain.makepatch(level_tex,next_tex:byte;x1,z1:integer;stencil_index:byte);
var row, col, cx, cz, tmp1,tmp2,tmp3:integer;

begin
cx:=(x1 mod texres)*transize-transize div 2;
cz:=(z1 mod texres)*transize-transize div 2;
for row:=0 to patchsize-1 do
 begin
 tmp3:=cpltexsize(cz+row)*texsize;
 for col:=0 to patchsize-1 do
  begin
  tmp1:=tmp3+cpltexsize(cx+col);
  tmp2:=255-stencilarray[stencil_index,row,col];
  tempstruc[row,col].r:=
   (tex[next_tex].pixels^[tmp1].r * tmp2 +
   tex[level_tex].pixels^[tmp1].r * stencilarray[stencil_index,row,col]) div 255;
  tempstruc[row,col].g:=
   (tex[next_tex].pixels^[tmp1].g * tmp2 +
   tex[level_tex].pixels^[tmp1].g * stencilarray[stencil_index,row,col]) div 255;
  tempstruc[row,col].b:=
   (tex[next_tex].pixels^[tmp1].b * tmp2 +
   tex[level_tex].pixels^[tmp1].b * stencilarray[stencil_index,row,col]) div 255;
   end;
  end;
end;

procedure tTerrain.gentrantex;
var x,z:integer; w,i:longint;
    este:boolean;

begin
sform.mylabel3d1.caption:='Generating textures, please wait...';
count:=0;

for z:=0 to mapsize-1 do
 for x:=0 to mapsize-1 do
  begin
  application.ProcessMessages;
  if bb[index(x,z)]=0 then tt[index(x,z)]:=quadlevel(x,z)
  else
   begin
   w:=x mod texres;
   w:=w or ((z mod texres) shl 3);
   w:=w or (stencilindex[bb[index(x,z)]] shl 6);
   w:=w or (quadlevel(x,z) shl 12);
   w:=w or ((quadlevel(x,z)+1) shl 15);
   tt[index(x,z)]:=w;
   este:=false;
   for i:=1 to Count do
    if texlist[i]=w then begin este:=true;break;end;
   if not este then
    begin
    inc(count);
    texlist[count]:=w;
    sform.Label1.Caption:=inttostr(Count);
    makepatch(quadlevel(x,z),quadlevel(x,z)+1,x,z,stencilindex[bb[index(x,z)]]);
    glBindTexture(GL_TEXTURE_2D, w);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_clamp);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_clamp);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_linear);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_linear);
    glTexImage2D(GL_TEXTURE_2D, 0, 3, patchsize, patchsize,
                 0, GL_RGB, GL_UNSIGNED_BYTE, @tempstruc);
    end;
   end;
  end;
 //showmessage(inttostr(c));
  sform.sfclose:=true;
sform.close;
end;

procedure Tsform.FormClose(Sender: TObject; var Action: TCloseAction);
begin
if not sfclose then action:=canone;
end;

end.

