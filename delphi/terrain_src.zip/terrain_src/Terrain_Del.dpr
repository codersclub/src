program Terrain_Del;

uses
  Forms,
  main in 'main.pas' {Form1},
  OpenGL in 'OpenGL.pas',
  terrain in 'terrain.pas' {sform},
  glex in 'glex.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
