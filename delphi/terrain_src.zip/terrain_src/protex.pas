


procedure tree(x1,z1:integer;y1:real);
begin
glDisable(GL_TEXTURE_2D);
gldisable(GL_CULL_FACE);
glBegin(GL_QUADS);
glColor3f(0.6, 0.4, 0.0);
        glVertex3f(x1-0.05, y1+1, z1);
        glVertex3f(x1+0.05, y1+1, z1);
        glVertex3f(x1+0.05, y1, z1);
        glVertex3f(x1-0.05, y1, z1);

        glVertex3f(x1, y1+1, z1-0.05);
        glVertex3f(x1, y1+1, z1+0.05);
        glVertex3f(x1, y1, z1+0.05);
        glVertex3f(x1, y1, z1-0.05);
glEnd;
glenable(GL_TEXTURE_2D);
glbindtexture(GL_TEXTURE_2D, tex_grass);
glBegin(GL_TRIANGLES);
glColor3f(0.35, 0.7, 0.0);
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1-0.3, y1+1, z1);
        glTexCoord2f(0.5, 1.0);
        glVertex3f(x1, y1+5, z1);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1+0.3, y1+1, z1);

glColor3f(0.4, 0.8, 0.0);
        glTexCoord2f(1.0, 0.0);
        glVertex3f(x1, y1+1, z1+0.3);
        glTexCoord2f(0.0, 0.0);
        glVertex3f(x1, y1+1, z1-0.3);
        glTexCoord2f(0.5, 1.0);
        glVertex3f(x1, y1+5, z1);
glEnd;

glenable(GL_CULL_FACE);
end;
