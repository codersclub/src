program Project1;

uses
  Forms,
  Unit1 in 'Unit1.pas' {Shuffler};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TShuffler, Shuffler);
  Application.Run;
end.
