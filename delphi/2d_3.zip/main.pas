unit main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    Button3: TButton;
    Edit1: TEdit;
    OpenDialog1: TOpenDialog;
    Button4: TButton;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
  private
    { Private declarations }
  public
  procedure DeskTopPaint(Sender:Tobject);

    { Public declarations }
  end;

var
  Form1: TForm1;
  DeskTop:TCanvas;

implementation

{$R *.DFM}

procedure TForm1.DeskTopPaint(Sender:Tobject);
var
DeskTop:TCanvas;
begin
DeskTop:=TCanvas.Create;
try
   DeskTop.Handle:=GetDC(0);// ������� Handle �������� �����
   DeskTop.Brush.Style:=bsClear; // ������������� ��� �����
   With DeskTop.Font do // ��������� �����
             Begin
             Color:=clwhite;
             Size:=13;
             Name:='Times New Roman';
             Style:=[fsBold];
             end;
   DeskTop.TextOut(70,10,'������� : '+DateToStr(Now));
   ReleaseDC(0, DeskTop.handle);
finally
   DeskTop.Free; // ������ �� �����
end;

end;

procedure TForm1.Button1Click(Sender: TObject);
begin
DeskTopPaint(Sender);
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
// ������ �����
SystemParametersInfo(SPI_SETDESKWALLPAPER,
                       1,
                       PChar(Edit1.text),
                       SPIF_SENDWININICHANGE);
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
// ������� ����
SendMessage(FindWindow('Progman', 'Program Manager'),
              WM_COMMAND,
              $A065,
              0);
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
with Opendialog1 do
     begin
     FileName:='';
     if Execute=True then Edit1.text:=OpenDialog1.FileName;
end;
end;

end.
