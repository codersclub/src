unit Unit_Form_Data_Viewer;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, DBCtrls,  ComCtrls, ComObj, AXCtrls, ADODB_TLB;

type
  TForm_Data_Viewer = class(TForm)
    btnUpdateData: TButton;
    pcDataViewer: TPageControl;
    tsDisplayText: TTabSheet;
    tsDisplayBinary: TTabSheet;
    tsBinaryOptions: TTabSheet;
    Memo_Data: TMemo;
    OpenDialogBinary: TOpenDialog;
    btnSaveBinary: TButton;
    btnLoadBinary: TButton;
    sbDataViewer: TScrollBox;
    Image_Data: TImage;
    gbViewImage: TGroupBox;
    rbPreviewImage: TRadioButton;
    rbActualImage: TRadioButton;
    btnViewBinary: TButton;
    gbBinaryTypes: TGroupBox;
    gbImageTypes: TGroupBox;
    rbJpegImage: TRadioButton;
    rbBitmapImage: TRadioButton;
    rbIconImage: TRadioButton;
    rbEnhMetafile: TRadioButton;
    rbMetafile: TRadioButton;
    gbFileTypes: TGroupBox;
    rbWordDoc: TRadioButton;
    rbTextDoc: TRadioButton;
    rbExelDoc: TRadioButton;
    rbOtherDoc: TRadioButton;
    rbFileTypes: TRadioButton;
    rbImageTypes: TRadioButton;
    SaveDialogBinary: TSaveDialog;
    cbUpdateFieldOnLoad: TCheckBox;
    cbTrueFalse: TCheckBox;
    procedure btnSaveBinaryClick(Sender: TObject);
    procedure btnViewBinaryClick(Sender: TObject);
    procedure btnLoadBinaryClick(Sender: TObject);
    procedure btnUpdateDataClick(Sender: TObject);
    procedure FormHide(Sender: TObject);
    procedure Image_DataClick(Sender: TObject);
    procedure rbPreviewImageClick(Sender: TObject);
    procedure rbActualImageClick(Sender: TObject);
  private
    { Private declarations }
    CurrentRecordIndex : Integer;
    CurrentFieldIndex  : Integer;
    CurrentData        : OLEVariant;
  public
    { Public declarations }
    procedure ViewData(X, Y : Integer);
  end;

var
  Form_Data_Viewer   : TForm_Data_Viewer;

implementation

uses Unit_Shared, Unit_Form_Main;

{$R *.DFM}

procedure TForm_Data_Viewer.ViewData(X, Y : Integer);
begin
  Form_Data_Viewer.Show;
  CurrentFieldIndex := X;
  CurrentRecordIndex := Y;
  with ado21RecNWind2 do
  begin
    CurrentData := Null;
    Memo_Data.Text := '';
    Memo_Data.Enabled := True;
    Memo_Data.Visible := True;
    btnUpdateData.Enabled := True;
    tsDisplayBinary.Enabled := False;
    pcDataViewer.ActivePageIndex := 0;    
    try
      if (not VarIsNull(Fields[X].Value)) then
        case Fields[X].Type_ of
          adEmpty            : Memo_Data.Text := '<Error: Could not display>';
          adTinyInt          : Memo_Data.Text := Fields[X].Value;
          adSmallInt         : Memo_Data.Text := Fields[X].Value;
          adInteger          : Memo_Data.Text := Fields[X].Value;
          adBigInt           : Memo_Data.Text := Fields[X].Value;
          adUnsignedTinyInt  : Memo_Data.Text := Fields[X].Value;
          adUnsignedSmallInt : Memo_Data.Text := Fields[X].Value;
          adUnsignedInt      : Memo_Data.Text := Fields[X].Value;
          adUnsignedBigInt   : Memo_Data.Text := Fields[X].Value;
          adSingle           : Memo_Data.Text := Fields[X].Value;
          adDouble           : Memo_Data.Text := Fields[X].Value;
          adCurrency         : Memo_Data.Text := Fields[X].Value;
          adDecimal          : Memo_Data.Text := Fields[X].Value;
          adNumeric          : Memo_Data.Text := Fields[X].Value;
          adBoolean          : begin
                                if (Fields[X].Value) then
                                  cbTrueFalse.Checked := True
                                else
                                  cbTrueFalse.Checked := False;
                                Memo_Data.Visible := False;
                               end;
          adError            : Memo_Data.Text := '<Error: Could not display>';
          adUserDefined      : Memo_Data.Text := '<Error: Could not display>';
          adVariant          : Memo_Data.Text := '<Error: Could not display>';
          adIDispatch        : Memo_Data.Text := '<Error: Could not display>';
          adIUnknown         : Memo_Data.Text := '<Error: Could not display>';
          adGUID             : Memo_Data.Text := GUIDToString(TGUID(Fields[X].Value));
          adDate             : Memo_Data.Text := DateTimeToStr(Fields[X].Value);
          adDBDate           : Memo_Data.Text := DateTimeToStr(Fields[X].Value);
          adDBTime           : Memo_Data.Text := TimeToStr(Fields[X].Value);
          adDBTimeStamp      : Memo_Data.Text := '<Error: Could not display>';
          adBSTR             : Memo_Data.Text := Fields[X].Value;
          adChar             : Memo_Data.Text := Fields[X].Value;
          adVarChar          : Memo_Data.Text := Fields[X].Value;
          adLongVarChar      : Memo_Data.Text := Fields[X].Value;
          adWChar            : Memo_Data.Text := Fields[X].Value;
          adVarWChar         : Memo_Data.Text := Fields[X].Value;
          adLongVarWChar     : Memo_Data.Text := Fields[X].Value;
          adBinary           : begin
                                 CurrentData := Fields[X].Value;
                                 Memo_Data.Enabled := False;
                                 Memo_Data.Text := '< adBinary >';
                                 btnUpdateData.Enabled := False;
                                 tsDisplayBinary.Enabled := True;
                                 pcDataViewer.ActivePageIndex := 1;
                               end;
          adVarBinary        : begin
                                 CurrentData := Fields[X].Value;
                                 Memo_Data.Enabled := False;
                                 Memo_Data.Text := '< adVarBinary >';
                                 btnUpdateData.Enabled := False;
                                 tsDisplayBinary.Enabled := True;
                                 pcDataViewer.ActivePageIndex := 1;
                               end;
          adLongVarBinary    : begin
                                 CurrentData := Fields[X].Value;
                                 Memo_Data.Enabled := False;
                                 Memo_Data.Text := '< adLongVarBinary >';
                                 btnUpdateData.Enabled := False;
                                 tsDisplayBinary.Enabled := True;
                                 pcDataViewer.ActivePageIndex := 1;
                               end;
          adChapter          : Memo_Data.Text := '<Error: Could not display>';
          adFileTime         : Memo_Data.Text := '<Error: Could not display>';
          adPropVariant      : Memo_Data.Text := '<Error: Could not display>';
          adVarNumeric       : Memo_Data.Text := Fields[X].Value;
        else
          Memo_Data.Text := '<Error: Could not display> Type = ' + GetDataTypeEnumDesc(Fields[X].Type_);
        end
      else
        begin
          case Fields[X].Type_ of
            adBinary           : begin
                                   CurrentData := Fields[X].Value;
                                   Memo_Data.Enabled := False;
                                   Memo_Data.Text := '< adBinary >';
                                   btnUpdateData.Enabled := False;
                                   tsDisplayBinary.Enabled := True;
                                   pcDataViewer.ActivePageIndex := 1;
                                 end;
            adVarBinary        : begin
                                   CurrentData := Fields[X].Value;
                                   Memo_Data.Enabled := False;
                                   Memo_Data.Text := '< adVarBinary >';
                                   btnUpdateData.Enabled := False;
                                   tsDisplayBinary.Enabled := True;
                                   pcDataViewer.ActivePageIndex := 1;
                                 end;
            adLongVarBinary    : begin
                                   CurrentData := Fields[X].Value;
                                   Memo_Data.Enabled := False;
                                   Memo_Data.Text := '< adLongVarBinary >';
                                   btnUpdateData.Enabled := False;
                                   tsDisplayBinary.Enabled := True;
                                   pcDataViewer.ActivePageIndex := 1;
                                 end;
          else
            Memo_Data.Text := ''; //<NULL>
          end;
        end;
    except
        on E: Exception do ShowMessage('Error: ' + E.Message);
    end; //end try
  end; //end with ado21RecNWind2
end;

procedure TForm_Data_Viewer.btnViewBinaryClick(Sender: TObject);
var
  strmFile : ADODB_TLB.Stream;
  FileExt  : string;
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  FileExt := '';
  strmFile := CoStream.Create;
  strmFile.Type_ := adTypeBinary;
  strmFile.Open(Emptyparam, adModeUnknown, adOpenStreamUnspecified, WideString(''), WideString(''));
  strmFile.Write(CurrentData);
  if (rbFileTypes.Checked) then
    begin
      if (rbTextDoc.Checked) then FileExt := '' //txt
      else if (rbWordDoc.Checked) then FileExt := '' //doc
      else if (rbExelDoc.Checked) then FileExt := ''; //xls
    end
  else if (rbImageTypes.Checked) then
    begin
      if (rbJpegImage.Checked) then FileExt := 'jpg'
      else if (rbBitmapImage.Checked) then FileExt := 'bmp'
      else if (rbIconImage.Checked) then FileExt := 'ico'
      else if (rbEnhMetafile.Checked) then FileExt := 'emf'
      else if (rbMetafile.Checked) then FileExt := 'wmf';
    end;
  if (FileExt <> '') then
    //if txt open notepad
    //if doc open word
    //if xls open exel
    //else open image
    strmFile.SaveToFile('TempImage.' + FileExt, adSaveCreateOverWrite)
    //else open in specific program
  else;
  strmFile.Close;
  Image_Data.Picture.LoadFromFile('TempImage.' + FileExt);
  Screen.Cursor := PrevCursor;
end;

procedure TForm_Data_Viewer.btnLoadBinaryClick(Sender: TObject);
var
  strmFile : ADODB_TLB.Stream;
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  btnUpdateData.Enabled := True;
  ForceCurrentDirectory := True;
  if (OpenDialogBinary.Execute) then
    begin
      Image_Data.Picture := nil;
      strmFile := CoStream.Create;
      strmFile.Type_ := adTypeBinary;
      strmFile.Open(Emptyparam, adModeUnknown, adOpenStreamUnspecified, WideString(''), WideString(''));
      strmFile.LoadFromFile(OpenDialogBinary.FileName);
      CurrentData := strmFile.Read(adReadAll);
      strmFile.Close;
      if (cbUpdateFieldOnLoad.Checked) then
          btnUpdateDataClick(Self);
    end
  else
    CurrentData := ado21RecNWind2.Fields[CurrentFieldIndex].Value;
  Screen.Cursor := PrevCursor;    
end;

procedure TForm_Data_Viewer.btnSaveBinaryClick(Sender: TObject);
var
  strmFile : ADODB_TLB.Stream;
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  strmFile := CoStream.Create;
  strmFile.Type_ := adTypeBinary;
  strmFile.Open(Emptyparam, adModeUnknown, adOpenStreamUnspecified, WideString(''), WideString(''));
  strmFile.Write(CurrentData);
  ForceCurrentDirectory := True;
  SaveDialogBinary.Filter := 'Binary files (*.bin)|*.BIN';
  SaveDialogBinary.DefaultExt := '*.bin';
  if (SaveDialogBinary.Execute) then
    strmFile.SaveToFile(SaveDialogBinary.FileName, adSaveCreateOverWrite);
  strmFile.Close;
  Screen.Cursor := PrevCursor;  
end;

procedure TForm_Data_Viewer.btnUpdateDataClick(Sender: TObject);
var
  SkipUpdate   : Boolean;
  DisplayValue : Boolean;
var
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;

  DisplayValue := True;
  if (not Memo_Data.Enabled) then
    btnUpdateData.Enabled := False;
  SkipUpdate := False;
  with ado21RecNWind2 do
  begin
    try
      case Fields[CurrentFieldIndex].Type_ of
        adEmpty            : SkipUpdate := True;
        adTinyInt          : CurrentData := Memo_Data.Text;
        adSmallInt         : CurrentData := Memo_Data.Text;
        adInteger          : CurrentData := Memo_Data.Text;
        adBigInt           : CurrentData := Memo_Data.Text;
        adUnsignedTinyInt  : CurrentData := Memo_Data.Text;
        adUnsignedSmallInt : CurrentData := Memo_Data.Text;
        adUnsignedInt      : CurrentData := Memo_Data.Text;
        adUnsignedBigInt   : CurrentData := Memo_Data.Text;
        adSingle           : CurrentData := Memo_Data.Text;
        adDouble           : CurrentData := Memo_Data.Text;
        adCurrency         : CurrentData := Memo_Data.Text;
        adDecimal          : CurrentData := Memo_Data.Text;
        adNumeric          : CurrentData := Memo_Data.Text;
        adBoolean          : begin
                               if (cbTrueFalse.Checked) then
                                 CurrentData := True
                               else
                                 CurrentData := False;
                             end;
        adError            : SkipUpdate := True;
        adUserDefined      : SkipUpdate := True;
        adVariant          : SkipUpdate := True; //Sorry I didn't implement this yet
        adIDispatch        : SkipUpdate := True;
        adIUnknown         : SkipUpdate := True;
        adGUID             : SkipUpdate := True; //Sorry I didn't implement this yet
        adDate             : SkipUpdate := True; //Sorry I didn't implement this yet
        adDBDate           : SkipUpdate := True; //Sorry I didn't implement this yet
        adDBTime           : SkipUpdate := True; //Sorry I didn't implement this yet
        adDBTimeStamp      : SkipUpdate := True; //Sorry I didn't implement this yet
        adBSTR             : CurrentData := Memo_Data.Text;
        adChar             : CurrentData := Memo_Data.Text;
        adVarChar          : CurrentData := Memo_Data.Text;
        adLongVarChar      : CurrentData := Memo_Data.Text;
        adWChar            : CurrentData := Memo_Data.Text;
        adVarWChar         : CurrentData := Memo_Data.Text;
        adLongVarWChar     : CurrentData := Memo_Data.Text;
        adBinary           : DisplayValue := False;
        adVarBinary        : DisplayValue := False;
        adLongVarBinary    : DisplayValue := False;
        adChapter          : SkipUpdate := True;
        adFileTime         : SkipUpdate := True; //Sorry I didn't implement this yet
        adPropVariant      : SkipUpdate := True;
        adVarNumeric       : CurrentData := Memo_Data.Text;
      else
        CurrentData := Null;
      end;
      if (not SkipUpdate) then
        begin
          try
            Fields[CurrentFieldIndex].Value := CurrentData;
            ado21RecNWind2.Update(EmptyParam, EmptyParam);
          except
            on E: Exception do
              begin
                ShowMessage('Error: ' + E.Message);
                ado21RecNWind2.CancelUpdate;
              end;
          end;
            if (DisplayValue) then
              Form_Main.StringGrid1.Cells[CurrentFieldIndex,
                                        CurrentRecordIndex] :=
                                        Fields[CurrentFieldIndex].Value
            else
              Form_Main.StringGrid1.Cells[CurrentFieldIndex,
                                        CurrentRecordIndex] := '<New Value>';
        end
      else
        ShowMessage('Update not allowed yet');
    except
        on E: Exception do ShowMessage('Error: ' + E.Message);
    end; //end try
  end; //end with ado21RecNWind2
  Screen.Cursor := PrevCursor;
end;

procedure TForm_Data_Viewer.FormHide(Sender: TObject);
begin
  Image_Data.Picture := nil;
  Memo_Data.Text := '';
end;

procedure TForm_Data_Viewer.Image_DataClick(Sender: TObject);
begin
  if (Image_Data.Stretch) then
    rbActualImage.Checked := True
  else
    rbPreviewImage.Checked := True;
end;

procedure TForm_Data_Viewer.rbPreviewImageClick(Sender: TObject);
begin
  Image_Data.Stretch := True;
  Image_Data.Align := alClient;
end;

procedure TForm_Data_Viewer.rbActualImageClick(Sender: TObject);
begin
  Image_Data.Stretch := False;
  Image_Data.Align := alNone;
  Image_Data.Height := Image_Data.Picture.Height;
  Image_Data.Width := Image_Data.Picture.Width;
end;

end.
