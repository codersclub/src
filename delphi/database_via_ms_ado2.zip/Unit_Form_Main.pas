unit Unit_Form_Main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ComCtrls, Grids, DBGrids, StdCtrls, OleCtrls, OleServer, ComObj,

  ADODB_TLB, ADOX_TLB, MSDATASRC_TLB, ExtCtrls, //Db, ADODB,
  CheckLst;

type
  TForm_Main = class(TForm)
    pcADOX: TPageControl;
    tsODBC: TTabSheet;
    gbODBCConnectionInfo: TGroupBox;
    Label1: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    edConnectString: TEdit;
    edODBCUserName: TEdit;
    edODBCPassword: TEdit;
    tsADOXCatalog: TTabSheet;
    pcADOX_TVPGU: TPageControl;
    tsTables: TTabSheet;
    gbTables: TGroupBox;
    pcTableStuff: TPageControl;
    tsTableColumns: TTabSheet;
    lblFieldNames: TLabel;
    lvTableColumns: TListView;
    tsTableIndexes: TTabSheet;
    lblIndexes: TLabel;
    lvTableIndexes: TListView;
    tsTableKeys: TTabSheet;
    lblKeys: TLabel;
    lvTableKeys: TListView;
    tsTableProperties: TTabSheet;
    lblTableProperties: TLabel;
    lvTableProperties: TListView;
    lvCatalogTables: TListView;
    tsViews: TTabSheet;
    gbViews: TGroupBox;
    tsProcedures: TTabSheet;
    gbProcedures: TGroupBox;
    tsGroups: TTabSheet;
    gbGroups: TGroupBox;
    lstGroups: TListBox;
    gbGroupUsers: TGroupBox;
    lstGroupUsers: TListBox;
    tsUsers: TTabSheet;
    gbUsers: TGroupBox;
    lstUsers: TListBox;
    gbUserGroups: TGroupBox;
    lstUserGroups: TListBox;
    tsDisplayTableData: TTabSheet;
    tsSQL: TTabSheet;
    memSQL: TMemo;
    lblViewSQLErrors: TLabel;
    lstErrors: TListBox;
    btnClearErrors: TButton;
    lvCatalogViews: TListView;
    lvCatalogProcedures: TListView;
    btnConnectADO: TButton;
    btnDisconnectADO: TButton;
    lblSQL: TLabel;
    gbSaveDataToFile: TGroupBox;
    btnSaveDataToFile: TButton;
    rbADTG: TRadioButton;
    rbXML: TRadioButton;
    OpenDialog1: TOpenDialog;
    btnFetchCatalogInfo: TButton;
    StringGrid1: TStringGrid;
    tsConfig: TTabSheet;
    lbConnectStringList: TListBox;
    Label6: TLabel;
    GroupBox1: TGroupBox;
    btnFillDataGrid: TButton;
    btnLoad: TButton;
    btnUpdateBatch: TButton;
    cbLoadDisconnected: TCheckBox;
    SaveDialogADO: TSaveDialog;
    gbFilterSettings: TGroupBox;
    GroupBox14: TGroupBox;
    cbFilterByName: TCheckBox;
    GroupBox13: TGroupBox;
    cbFilterByPrefix: TCheckBox;
    GroupBox12: TGroupBox;
    cbFilterByType: TCheckBox;
    rbFilterByType: TRadioButton;
    rbFilterByPrefix: TRadioButton;
    rbFilterByName: TRadioButton;
    sgFilterData: TStringGrid;
    btnUpdateFilterData: TButton;
    btnAddNewFilterData: TButton;
    btnDeleteFilterData: TButton;
    cbClearItemsOnDisconect: TCheckBox;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure btnFillDataGridClick(Sender: TObject);
    procedure btnClearErrorsClick(Sender: TObject);
    procedure pcADOXResize(Sender: TObject);
    procedure lvCatalogTablesClick(Sender: TObject);
    procedure pcADOXChange(Sender: TObject);
    procedure btnConnectADOClick(Sender: TObject);
    procedure btnDisconnectADOClick(Sender: TObject);
    procedure btnSaveDataToFileClick(Sender: TObject);
    procedure btnLoadClick(Sender: TObject);
    procedure lstErrorsDblClick(Sender: TObject);
    procedure btnFetchCatalogInfoClick(Sender: TObject);
    procedure lvCatalogViewsClick(Sender: TObject);
    procedure lvCatalogProceduresClick(Sender: TObject);
    procedure lstGroupsClick(Sender: TObject);
    procedure lstUsersClick(Sender: TObject);
    procedure StringGrid1DblClick(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure lbConnectStringListDblClick(Sender: TObject);
    procedure lbConnectStringListKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    procedure btnUpdateBatchClick(Sender: TObject);
    procedure cbLoadDisconnectedClick(Sender: TObject);
    procedure SelectFilter(Sender: TObject);
    procedure btnAddNewFilterDataClick(Sender: TObject);
    procedure btnDeleteFilterDataClick(Sender: TObject);
    procedure btnUpdateFilterDataClick(Sender: TObject);
    //Additional Program Functions and Procedures
    procedure GetConnectionStrings;
    procedure GetTables;
    procedure GetTableColumnInfo(const TableName : WideString);
    procedure GetTableIndexInfo(const TableName : WideString);
    procedure GetTableKeyInfo(const TableName : WideString);
    procedure GetTablePropertyInfo(const TableName : WideString);
    procedure GetViews;
    procedure GetProcedures;
    procedure GetGroups;
    procedure GetUsers;
    procedure FillListView;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form_Main             : TForm_Main;
  ado21Conn             : Connection;
  adox21Catalog         : Catalog;
  ado21RecNWind2        : Recordset;
  adocD5_ADODB          : Connection;
  adorTableTypeFilter   : Recordset;
  adorTablePrefixFilter : Recordset;
  adorTableNameFilter   : Recordset;
  adorConnectionStrings : Recordset;
  BreakLoop : Boolean;

implementation

{$R *.DFM}

uses Unit_Shared, Unit_Form_Data_Viewer;

procedure TForm_Main.FormClose(Sender: TObject; var Action: TCloseAction);
begin
//  msdgTableData.DataSource := nil;
  if (ado21RecNWind2.State <> adStateClosed) then ado21RecNWind2.Close;
  if (ado21Conn.State <> adStateClosed) then ado21Conn.Close;
  adox21Catalog := nil;
  ado21RecNWind2 := nil;
  ado21Conn := nil;
  //Program Recordsets and Connections
  if (adorConnectionStrings.State <> adStateClosed) then adorConnectionStrings.Close;
  adorConnectionStrings := nil;
  if (adorTableNameFilter.State <> adStateClosed) then adorTableNameFilter.Close;
  adorTableNameFilter := nil;
  if (adorTablePrefixFilter.State <> adStateClosed) then adorTablePrefixFilter.Close;
  adorTablePrefixFilter := nil;
  if (adorTableTypeFilter.State <> adStateClosed) then adorTableTypeFilter.Close;
  adorTableTypeFilter := nil;
  if (adocD5_ADODB.State <> adStateClosed) then adocD5_ADODB.Close;
  adocD5_ADODB := nil;

  Action := caFree;
end;

procedure TForm_Main.FormCreate(Sender: TObject);
begin
  BreakLoop := FALSE;
  //Create Objects
  ado21Conn := CoConnection.Create;
  ado21Conn.CursorLocation := adUseClient;
  adox21Catalog := CoCatalog.Create;
  ado21RecNWind2 := CoRecordset.Create;
  //Program Recordsets and Connections
  adocD5_ADODB := CoConnection.Create;
  adocD5_ADODB.CursorLocation := adUseClient;
  adocD5_ADODB.Open('Provider=Microsoft.Jet.OLEDB.4.0;Data Source=D5_ADO.mdb', 'Admin', '', -1);
  adorTableTypeFilter := CoRecordset.Create;
  adorTableTypeFilter.Open('Select * From Filter_Table_Types', adocD5_ADODB, adOpenDynamic, adLockOptimistic, 0);
  adorTablePrefixFilter := CoRecordset.Create;
  adorTablePrefixFilter.Open('Select * From Filter_Table_Prefixes', adocD5_ADODB, adOpenDynamic, adLockOptimistic, 0);
  adorTableNameFilter := CoRecordset.Create;
  adorTableNameFilter.Open('Select * From Filter_Table_Names', adocD5_ADODB, adOpenDynamic, adLockOptimistic, 0);
  adorConnectionStrings := CoRecordset.Create;
  adorConnectionStrings.Open('Select * From Connection_Strings', adocD5_ADODB, adOpenDynamic, adLockOptimistic, 0);

  GetConnectionStrings;

end;

procedure TForm_Main.GetConnectionStrings;
var I: Integer;
begin
  lbConnectStringList.Clear;
  with adorConnectionStrings do
  begin
    if (RecordCount > 0) then
      begin
        MoveFirst;
        for I := 1 to RecordCount do
          begin
           lbConnectStringList.Items.Add(Fields['Description'].Value);
           MoveNext;
          end;
      end;
  end;
end;

procedure TForm_Main.btnFillDataGridClick(Sender: TObject);
var
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  if (ado21RecNWind2.State <> adStateClosed) then ado21RecNWind2.Close;
  try
    ado21RecNWind2.Open(memSQL.Text, ado21Conn, adOpenDynamic, adLockOptimistic, 0);

    FillListView;
    //Use this code for a Microsoft DataGrid
//    msdgTableData.Caption := 'Records: ' + IntToStr(ado21RecNWind2.RecordCount);
//    msdgTableData.DataSource := ado21RecNWind2 as DataSource;
//    msdgTableData.ReBind;

  except
    on E: Exception do
      begin
        lstErrors.Items.Add('Error (on fill datagrid): ' + E.Message);
        lblViewSQLErrors.Visible := True;
      end;
  end;
  Screen.Cursor := PrevCursor;
end;

procedure TForm_Main.btnClearErrorsClick(Sender: TObject);
begin
  lstErrors.Clear;
  lblViewSQLErrors.Visible := False;
end;

procedure TForm_Main.pcADOXResize(Sender: TObject);
begin
//  msdgTableData.Height := tsDisplayTableData.Height;
//  msdgTableData.Width := tsDisplayTableData.Width;
end;

procedure TForm_Main.lvCatalogTablesClick(Sender: TObject);
var
  TblName : WideString;
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  if (lvCatalogTables.Selected = nil) then
    begin
      btnFetchCatalogInfoClick(Self);
      Screen.Cursor := PrevCursor;
      Exit;
    end;
  TblName := lvCatalogTables.Selected.Caption;

  GetTableColumnInfo(TblName);
  GetTableIndexInfo(TblName);
  GetTableKeyInfo(TblName);
  GetTablePropertyInfo(TblName);

  Screen.Cursor := PrevCursor;
end;

procedure TForm_Main.pcADOXChange(Sender: TObject);
begin
//  msdgTableData.Height := tsDisplayTableData.Height;
//  msdgTableData.Width := tsDisplayTableData.Width;
end;

procedure TForm_Main.btnConnectADOClick(Sender: TObject);
var  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  if (ado21Conn.State <> adStateClosed) then ado21Conn.Close;
    if (edConnectString.Text <> '') then
      begin
        try
          btnConnectADO.Enabled := False;
          ado21Conn.Open(edConnectString.Text, edODBCUserName.Text, edODBCPassword.Text, -1);
          adox21Catalog.Set_ActiveConnection(ado21Conn as IDispatch);
          btnDisconnectADO.Enabled := True;
          pcADOX_TVPGU.Visible := True;
        except
          on E: Exception do
            begin
              btnDisconnectADO.Enabled := False;
              pcADOX_TVPGU.Visible := False;
              if (ado21Conn.State <> adStateClosed) then ado21Conn.Close;
              Screen.Cursor := PrevCursor;
              ShowMessage('Open ADO Connection Error: ' + E.Message);
              btnConnectADO.Enabled := True;
            end;
        end;
      end
    else
      begin
        pcADOX_TVPGU.Visible := False;
        if (ado21Conn.State <> adStateClosed) then ado21Conn.Close;
        ShowMessage('ODBC Connection Information Required.');
      end;
  Screen.Cursor := PrevCursor;
end;

procedure TForm_Main.btnDisconnectADOClick(Sender: TObject);
begin
  if (cbClearItemsOnDisconect.Checked) then
    if (ado21RecNWind2.State <> adStateClosed) then ado21RecNWind2.Close;

  if (ado21Conn.State <> adStateClosed) then ado21Conn.Close;

  if (cbClearItemsOnDisconect.Checked) then
    begin
      gbTables.Caption := 'Tables: ?';
      lvCatalogTables.Items.Clear;
      lblFieldNames.Caption := 'Columns: ?';
      lvTableColumns.Items.Clear;
      lblIndexes.Caption := 'Indexes: ?';
      lvTableIndexes.Items.Clear;
      lblKeys.Caption := 'Keys: ?';
      lvTableKeys.Items.Clear;
      lblTableProperties.Caption := 'Properties: ?';
      lvTableProperties.Items.Clear;
      gbViews.Caption := 'Views: ?';
      lvCatalogViews.Items.Clear;
      gbProcedures.Caption := 'Procedures: ?';
      lvCatalogProcedures.Items.Clear;
      gbGroups.Caption := 'Groups: ?';
      lstGroups.Clear;
      gbUsers.Caption := 'Users: ?';
      lstUsers.Clear;
      StringGrid1.RowCount := 1;
    end;

  btnConnectADO.Enabled := True;
  btnDisconnectADO.Enabled := False;
end;

procedure TForm_Main.btnSaveDataToFileClick(Sender: TObject);
var
  s : string;
  PrevCursor : TCursor;
begin
  if (ado21RecNWind2.RecordCount <= 0) then
    begin
      ShowMessage('Cannot save. The recordset is empty!');
      Exit;
    end;
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  DateTimeToString(s, 'mmddhhnnss', Now);
  ForceCurrentDirectory := True;
  if (rbADTG.Checked) then
    begin
      SaveDialogADO.FileName := 'ADTG_' + s + '.ado';
      if (SaveDialogADO.Execute) then
        ado21RecNWind2.Save(SaveDialogADO.FileName, adPersistADTG);
    end
  else if (rbXML.Checked) then
    begin
      SaveDialogADO.FileName := 'XML_' + s + '.ado';
      if (SaveDialogADO.Execute) then
        ado21RecNWind2.Save(SaveDialogADO.FileName, adPersistXML);
    end;
  Screen.Cursor := PrevCursor;
end;

procedure TForm_Main.btnLoadClick(Sender: TObject);
var
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  if (ado21RecNWind2.State <> adStateClosed) then ado21RecNWind2.Close;
  OpenDialog1.FileName := '*.ado';
  OpenDialog1.Execute;
  try
    if (cbLoadDisconnected.Checked) then
      begin //Load recordset disconnected
        ado21RecNWind2.Open(OpenDialog1.FileName, EmptyParam, adOpenDynamic, adLockOptimistic, adCmdFile);
        btnUpdateBatch.Enabled := False;
      end
    else
      begin //Connected - click update batch to post changes
        ado21RecNWind2.Open(OpenDialog1.FileName, ado21Conn, adOpenDynamic, adLockOptimistic, adCmdFile);
        btnUpdateBatch.Enabled := True;
      end;

    FillListView;
//    msdgTableData.Caption := 'Records: ' + IntToStr(ado21RecNWind2.RecordCount);
//    msdgTableData.DataSource := ado21RecNWind2 as DataSource;
//    msdgTableData.ReBind;

  except
    on E: Exception do
      begin
        lstErrors.Items.Add('Error (on load file): ' + E.Message);
        lblViewSQLErrors.Visible := True;
      end;
  end;
  Screen.Cursor := PrevCursor;  
end;

procedure TForm_Main.lstErrorsDblClick(Sender: TObject);
begin
  ShowMessage(lstErrors.Items[lstErrors.ItemIndex]);
end;

procedure TForm_Main.btnFetchCatalogInfoClick(Sender: TObject);
var
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;
  if (btnFetchCatalogInfo.Caption = 'Fetch Catalog Info') then
    begin
      btnFetchCatalogInfo.Caption := 'Cancel Fetch Info';
      if (pcADOX_TVPGU.ActivePage.Caption = 'Tables') then
        begin
          lblFieldNames.Caption := 'Columns: ?';
          lvTableColumns.Items.Clear;
          lblIndexes.Caption := 'Indexes: ?';
          lvTableIndexes.Items.Clear;
          lblKeys.Caption := 'Keys: ?';
          lvTableKeys.Items.Clear;
          lblTableProperties.Caption := 'Properties: ?';
          lvTableProperties.Items.Clear;
          GetTables;
        end
      else if (pcADOX_TVPGU.ActivePage.Caption = 'Views') then
        GetViews
      else if (pcADOX_TVPGU.ActivePage.Caption = 'Procedures') then
        GetProcedures
      else if (pcADOX_TVPGU.ActivePage.Caption = 'Groups') then
        GetGroups
      else if (pcADOX_TVPGU.ActivePage.Caption = 'Users') then
        GetUsers
      else {Empty Statement} ;
      btnFetchCatalogInfo.Caption := 'Fetch Catalog Info';
    end
  else
    begin
      btnFetchCatalogInfo.Caption := 'Fetch Catalog Info';
      BreakLoop := TRUE;
    end;
  Screen.Cursor := PrevCursor;
end;


procedure TForm_Main.lvCatalogViewsClick(Sender: TObject);
begin
  if (lvCatalogViews.Selected = nil) then
    btnFetchCatalogInfoClick(Self);
end;

procedure TForm_Main.lvCatalogProceduresClick(Sender: TObject);
begin
  if (lvCatalogProcedures.Selected = nil) then
    btnFetchCatalogInfoClick(Self);
end;

procedure TForm_Main.lstGroupsClick(Sender: TObject);
begin
    btnFetchCatalogInfoClick(Self);
end;

procedure TForm_Main.lstUsersClick(Sender: TObject);
begin
    btnFetchCatalogInfoClick(Self);
end;

procedure TForm_Main.StringGrid1DblClick(Sender: TObject);
var
  PrevCursor : TCursor;
begin
  PrevCursor := Screen.Cursor;
  Screen.Cursor := crHourglass;

  if (StringGrid1.Row <> 0) then
  begin
    ado21RecNWind2.AbsolutePosition := StringGrid1.Row;
    Form_Data_Viewer.ViewData(StringGrid1.Col ,StringGrid1.Row);
  end;

  Screen.Cursor := PrevCursor;
end;

procedure TForm_Main.Button1Click(Sender: TObject);
begin
  BreakLoop := TRUE;
end;

procedure TForm_Main.GetUsers;
var
  I : Integer;
begin
  gbUsers.Caption := 'Users: ?';
  with adox21Catalog do
  begin
    try
      lstUsers.Clear;
      gbUsers.Caption := 'Users: ' + IntToStr(Users.Count);
        for I := 0 to (Users.Count - 1) do
        begin
          lstUsers.Items.Add(Users[I].Name);
        end;
    except
      on E: Exception do lstUsers.Items.Add('Error: Get Users: ' + E.Message);
    end;
  end;
end;

procedure TForm_Main.GetGroups;
var
  I : Integer;
begin
  gbGroups.Caption := 'Groups: ?';
  with adox21Catalog do
  begin
    try
      lstGroups.Clear;
      gbGroups.Caption := 'Groups: ' + IntToStr(Groups.Count);
      for I := 0 to (Groups.Count - 1) do
        begin
          lstGroups.Items.Add(Groups[I].Name);
        end;
    except
      on E: Exception do lstGroups.Items.Add('Error: Get Groups: ' + E.Message);
    end;
  end;
end;

procedure TForm_Main.GetProcedures;
var
  I, Count : Integer;
begin
  gbProcedures.Caption := 'Procedures: ?';
  with lvCatalogProcedures do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Procedures.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    gbProcedures.Caption := 'Procedures: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    for I := 0 to (Count - 1) do
      begin
        Application.ProcessMessages;
        //Allow a way of stoping this process
        if (BreakLoop) then
          begin
            BreakLoop := FALSE;
            Break;
          end;

        gbProcedures.Caption := 'Procedures: ' + IntToStr(I+1) + ' of ' + IntToStr(Count);

        Items.Add;
        with adox21Catalog.Procedures[I] do
        begin
          try
            Items[I].Caption := Trim(Get_Name);
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(DateTimeToStr(Get_DateCreated));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(DateTimeToStr(Get_DateModified));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end;
      end;
  end;
end;

procedure TForm_Main.GetViews;
var
  I, Count : Integer;
begin
  gbViews.Caption := 'Views: ?';
  with lvCatalogViews do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Views.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    gbViews.Caption := 'Views: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    for I := 0 to (Count - 1) do
      begin
        Application.ProcessMessages;
        //Allow a way of stoping this process
        if (BreakLoop) then
          begin
            BreakLoop := FALSE;
            Break;
          end;

        gbViews.Caption := 'Views: ' + IntToStr(I+1) + ' of ' + IntToStr(Count);

        Items.Add;
        with adox21Catalog.Views[I] do
        begin
          try
            Items[I].Caption := Trim(Get_Name);
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(DateTimeToStr(Get_DateCreated));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(DateTimeToStr(Get_DateModified));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end;
      end;
  end;
end;

procedure TForm_Main.GetTablePropertyInfo(const TableName : WideString);
var
  I, Count : Integer;
begin
  lblTableProperties.Caption := 'Table Properties: ?';
  with lvTableProperties do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Tables[TableName].Properties.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    lblTableProperties.Caption := 'Table Properties: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    with adox21Catalog.Tables[TableName] do
    begin
      for I := 0 to Pred(Count) do
        begin
          Items.Add;
          try
            Items[I].Caption := Properties[I].Name;
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetDataTypeEnumDesc(Properties[I].Type_));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(Properties[I].Value);
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end; //end for
    end; //end with adox21Catalog
  end; //end with lvTableProperties
end;

procedure TForm_Main.GetTableKeyInfo(const TableName : WideString);
var
  I, Count : Integer;
begin
  lblKeys.Caption := 'Keys: ?';
  with lvTableKeys do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Tables[TableName].Keys.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    lblKeys.Caption := 'Keys: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    with adox21Catalog.Tables[TableName] do
    begin
      for I := 0 to Pred(Count) do
        begin
          Items.Add;
          try;
            Items[I].Caption := Keys[I].Name;
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetKeyTypeEnumDesc(Keys[I].Type_));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetRuleEnumDesc(Keys[I].UpdateRule));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetRuleEnumDesc(Keys[I].DeleteRule));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(Keys[I].RelatedTable);
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end; //end for
    end; //end with adox21Catalog
  end; //end with lvTableIndexes
end;

procedure TForm_Main.GetTableIndexInfo(const TableName : WideString);
var
  I, Count : Integer;
begin
  lblIndexes.Caption := 'Indexes: ?';
  with lvTableIndexes do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Tables[TableName].Indexes.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    lblIndexes.Caption := 'Indexes: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    with adox21Catalog.Tables[TableName] do
    begin
      for I := 0 to Pred(Count) do
        begin
          Items.Add;
          try
            Items[I].Caption := Indexes[I].Name;
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;            
          try
            if (Indexes[I].PrimaryKey) then
              Items[I].SubItems.Add('Yes')
            else
              Items[I].SubItems.Add('No');
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            if (Indexes[I].Unique) then
              Items[I].SubItems.Add('Yes')
            else
              Items[I].SubItems.Add('No');
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetAllowNullsEnumDesc(Indexes[I].IndexNulls));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            if (Indexes[I].Clustered) then
              Items[I].SubItems.Add('Yes')
            else
              Items[I].SubItems.Add('No');
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end; //end for
    end; //end with adox21Catalog
  end; //end with lvTableIndexes
end;

procedure TForm_Main.GetTableColumnInfo(const TableName : WideString);
var
  I, Count : Integer;
begin
  lblFieldNames.Caption := 'Columns: ?';
  with lvTableColumns do
  begin
    Items.Clear;
    try
      Count := adox21Catalog.Tables[TableName].Columns.Count;
    except
      on E: Exception do
        begin
          Items.Add;
          Items[0].Caption := 'Error: ' + E.Message;
          Count := 0;
        end;
    end;
    lblFieldNames.Caption := 'Columns: ' + IntToStr(Count);

    if (Count <= 0) then Exit;

    with adox21Catalog.Tables[TableName] do
    begin
      for I := 0 to (Count - 1) do
        begin
          Items.Add;
          try
            Items[I].Caption := Columns[I].Name;
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(GetDataTypeEnumDesc(Columns[I].Type_));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(IntToStr(Columns[I].DefinedSize));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(IntToStr(Columns[I].Precision));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
          try
            Items[I].SubItems.Add(IntToStr(Columns[I].NumericScale));
          except
            on E: Exception do Items[I].SubItems.Add('Error: ' + E.Message);
          end;
        end; //end for
    end; //end with adox21Catalog
  end; //end with lvTableColumns
end;

function IncludeFilterTableType(const TableType : WideString) : Boolean;
var J : Integer;
begin
  Result := True; //Any table type is included by default
  with adorTableTypeFilter do
  begin
    if (RecordCount <= 0) then Exit;
    MoveFirst;
    for J := 0 to (RecordCount - 1) do
      begin
        if (Fields['Table_Type'].Value = TableType) then
          begin
            if (Fields['Filter'].Value = -1) then Result := False;
            Break;
          end;
        MoveNext;
      end;
  end;
end;

function IncludeFilterTablePrefix(const TableName : WideString) : Boolean;
var J : Integer;
begin
  Result := True;
  with adorTablePrefixFilter do
  begin
    if (RecordCount <= 0) then Exit;
    MoveFirst;
    for J := 0 to (RecordCount - 1) do
      begin
        if (Fields['Table_Prefix'].Value = Copy(TableName, 1 ,Length(Fields['Table_Prefix'].Value))) then
          begin
            if (Fields['Filter'].Value = -1) then Result := False;
            Break;
          end;
        MoveNext;
      end;
  end;
end;

procedure IncludeFilterTableName(const TableName : WideString; var ACondition : Boolean);
var J : Integer;
begin
  with adorTableNameFilter do
  begin
    if (RecordCount <= 0) then Exit;
    MoveFirst;
    for J := 0 to (RecordCount - 1) do
      begin
        if (Fields['Table_Name'].Value = TableName) then
          begin
            if (Fields['Filter'].Value = 0) then //Include Table Name (Explicit)
              ACondition := True
            else if (Fields['Filter'].Value = -1) then //Exclude Table Name (Explicit)
              ACondition := False
            else
              {Don't modify ACondition};
            Break;
          end;
        MoveNext;
      end;
    //If the table name is not found then ACondition is not modified
  end;
end;

procedure TForm_Main.GetTables;
var
  I, TableCount : Integer;
  DisplayTable : Boolean;
begin
  TableCount := 0;
  gbTables.Caption := 'Tables: ?';
  lvCatalogTables.Items.Clear;

  if (adox21Catalog.Tables.Count <= 0) then Exit;

  for I := 0 to (adox21Catalog.Tables.Count - 1) do
    begin
      Application.ProcessMessages;
      //Allow a way of stoping this process
      if (BreakLoop) then
        begin
          BreakLoop := FALSE;
          Break;
        end;
//    if (I mod 10 = 0) then
      gbTables.Caption := 'Tables: ' + IntToStr(I) + ' of ' + IntToStr(adox21Catalog.Tables.Count);

      with adox21Catalog.Tables[I] do
      begin
        DisplayTable := True;

        if (cbFilterByType.Checked) then
          //Filter Table Types
          DisplayTable := IncludeFilterTableType(Type_);

        if (cbFilterByPrefix.Checked) then
          if (DisplayTable) then //Filter Table Prefixes
            DisplayTable := IncludeFilterTablePrefix(Name);

        if (cbFilterByName.Checked) then
          //Filter Table Names
          IncludeFilterTableName(Name, DisplayTable);

        if (DisplayTable) then
          begin
            with lvCatalogTables do
            begin
              Inc(TableCount);
              Items.Add;
              try
                //Use Get_Name so the Name property doesn't conflict with lvCatalogTables.Name
                Items[TableCount - 1].Caption := Trim(Get_Name);
              except
                on E: Exception do lvCatalogTables.Items[TableCount - 1].SubItems.Add('Error: ' + E.Message);
              end;
              try
                Items[TableCount - 1].SubItems.Add(Type_);
              except
                on E: Exception do Items[TableCount - 1].SubItems.Add('Error: ' + E.Message);
              end;
              try
                Items[TableCount - 1].SubItems.Add(DateTimeToStr(Get_DateCreated));
              except
                on E: Exception do Items[TableCount - 1].SubItems.Add('Error: ' + E.Message);
              end;
              try
                Items[TableCount - 1].SubItems.Add(DateTimeToStr(Get_DateModified));
              except
                on E: Exception do Items[TableCount - 1].SubItems.Add('Error: ' + E.Message);
              end;
            end; //end with lvCatalogTables
          end; //end if
      end; //end for
    end; //end with adox21Catalog.Tables[I]

    gbTables.Caption := 'Tables: ' + IntToStr(TableCount) + ' of ' + IntToStr(adox21Catalog.Tables.Count);
end;

procedure TForm_Main.lbConnectStringListDblClick(Sender: TObject);
begin
  if (lbConnectStringList.ItemIndex <> -1) then
  begin
    adorConnectionStrings.AbsolutePosition := lbConnectStringList.ItemIndex + 1;
    edConnectString.Text := adorConnectionStrings.Fields['Connection_String'].Value;
  end;
end;

procedure TForm_Main.lbConnectStringListKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
begin
  if (Key = VK_Delete) then
    begin
      if (lbConnectStringList.ItemIndex <> -1) then
      begin
        adorConnectionStrings.AbsolutePosition := lbConnectStringList.ItemIndex + 1;
        adorConnectionStrings.Delete(adAffectCurrent);
        adorConnectionStrings.Requery(adCmdUnspecified);
        GetConnectionStrings;
      end;
    end;
end;

procedure TForm_Main.btnUpdateBatchClick(Sender: TObject);
begin
  try
    ado21RecNWind2.UpdateBatch(EmptyParam);
  except
    on E: Exception do
      begin
        ShowMessage('Error: ' + E.Message);
        ado21RecNWind2.CancelBatch(EmptyParam);
      end;
  end;
end;

procedure TForm_Main.cbLoadDisconnectedClick(Sender: TObject);
begin
  btnUpdateBatch.Enabled := not cbLoadDisconnected.Checked;
end;

procedure TForm_Main.SelectFilter(Sender: TObject);
var
  I, X, FldCount : Integer;
begin
  sgFilterData.ColCount := 0;
  sgFilterData.RowCount := 5;
  sgFilterData.FixedRows := 1;
  if (rbFilterByType.Checked) then
    begin
      with adorTableTypeFilter do
      begin
        FldCount := Fields.Count;
        sgFilterData.ColCount := FldCount - 1;
        for I := 0 to (FldCount - 2) do
          sgFilterData.Cols[I].Text := Fields[I+1].Name;

        sgFilterData.RowCount := RecordCount + 1;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              sgFilterData.Cells[X-1,I] := Fields[X].Value;
            MoveNext;
          end;
        end;
      end;
    end
  else if (rbFilterByPrefix.Checked) then
    begin
      with adorTablePrefixFilter do
      begin
        FldCount := Fields.Count;
        sgFilterData.ColCount := FldCount - 1;
        for I := 0 to (FldCount - 2) do
          sgFilterData.Cols[I].Text := Fields[I+1].Name;

        sgFilterData.RowCount := RecordCount + 1;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              sgFilterData.Cells[X-1,I] := Fields[X].Value;
            MoveNext;
          end;
        end;
      end;
    end
  else if (rbFilterByName.Checked) then
    begin
      with adorTableNameFilter do
      begin
        FldCount := Fields.Count;
        sgFilterData.ColCount := FldCount - 1;
        for I := 0 to (FldCount - 2) do
          sgFilterData.Cols[I].Text := Fields[I+1].Name;

        sgFilterData.RowCount := RecordCount + 1;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              sgFilterData.Cells[X-1,I] := Fields[X].Value;
            MoveNext;
          end;
        end;
      end;
    end;
end;

procedure TForm_Main.btnAddNewFilterDataClick(Sender: TObject);
begin
  if (rbFilterByType.Checked) then
    begin
      adorTableTypeFilter.AddNew(EmptyParam, EmptyParam);
      adorTableTypeFilter.Fields['Table_Type'].Value := '< NEW ITEM >';
      adorTableTypeFilter.Fields['Filter'].Value := 0;
      adorTableTypeFilter.Update(EmptyParam, EmptyParam);
      adorTableTypeFilter.Requery(adOptionUnspecified);
    end
  else if (rbFilterByPrefix.Checked) then
    begin
      adorTablePrefixFilter.AddNew(EmptyParam, EmptyParam);
      adorTablePrefixFilter.Fields['Table_Prefix'].Value := '< NEW ITEM >';
      adorTablePrefixFilter.Fields['Filter'].Value := 0;
      adorTablePrefixFilter.Update(EmptyParam, EmptyParam);
      adorTablePrefixFilter.Requery(adOptionUnspecified);
    end
  else if (rbFilterByName.Checked) then
    begin
      adorTableNameFilter.AddNew(EmptyParam, EmptyParam);
      adorTableNameFilter.Fields['Table_Name'].Value := '< NEW ITEM >';
      adorTableNameFilter.Fields['Filter'].Value := 0;
      adorTableNameFilter.Update(EmptyParam, EmptyParam);
      adorTableNameFilter.Requery(adOptionUnspecified);
    end;
  Form_Main.SelectFilter(Self);
end;

procedure TForm_Main.btnDeleteFilterDataClick(Sender: TObject);
begin
  if (rbFilterByType.Checked) then
    begin
      adorTableTypeFilter.AbsolutePosition := sgFilterData.Row;
      adorTableTypeFilter.Delete(adAffectCurrent);
    end
  else if (rbFilterByPrefix.Checked) then
    begin
      adorTablePrefixFilter.AbsolutePosition := sgFilterData.Row;
      adorTablePrefixFilter.Delete(adAffectCurrent);
    end
  else if (rbFilterByName.Checked) then
    begin
      adorTableNameFilter.AbsolutePosition := sgFilterData.Row;
      adorTableNameFilter.Delete(adAffectCurrent);
    end;
  Form_Main.SelectFilter(Self);
end;

procedure TForm_Main.btnUpdateFilterDataClick(Sender: TObject);
var
  I, X, FldCount : Integer;
begin
  if (rbFilterByType.Checked) then
    begin
      with adorTableTypeFilter do
      begin
        Requery(adOptionUnspecified);
        FldCount := Fields.Count;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              Fields[X].Value := sgFilterData.Cells[X-1,I];
            MoveNext;
          end;
        end;
      end;
    end
  else if (rbFilterByPrefix.Checked) then
    begin
      with adorTablePrefixFilter do
      begin
        Requery(adOptionUnspecified);
        FldCount := Fields.Count;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              Fields[X].Value := sgFilterData.Cells[X-1,I];
            MoveNext;
          end;
        end;
      end;
    end
  else if (rbFilterByName.Checked) then
    begin
      with adorTableNameFilter do
      begin
        Requery(adOptionUnspecified);      
        FldCount := Fields.Count;
        if (RecordCount > 0) then
        begin
          MoveFirst;
          for I := 1 to (RecordCount) do
          begin
            for X := 1 to (FldCount - 1) do
              Fields[X].Value := sgFilterData.Cells[X-1,I];
            MoveNext;
          end;
        end;
      end;
    end;
end;

procedure TForm_Main.FillListView;
var
  I, X, FldCount : Integer;
begin
  //setup columns
  StringGrid1.ColCount := 0;
  StringGrid1.RowCount := 5;
  StringGrid1.FixedRows := 1;
  FldCount := ado21RecNWind2.Fields.Count;
  StringGrid1.ColCount := FldCount;
  for I := 0 to (FldCount - 1) do
    begin
      StringGrid1.Cols[I].Text := ado21RecNWind2.Fields[I].Name;
    end;
  //show data
  StringGrid1.RowCount := ado21RecNWind2.RecordCount + 1;
  ado21RecNWind2.MoveFirst;
  for I := 1 to (ado21RecNWind2.RecordCount) do
    begin
      for X := 0 to (FldCount - 1) do
        with ado21RecNWind2 do
        begin
          try
            if (not VarIsNull(Fields[X].Value)) then
              case Fields[X].Type_ of
                adEmpty            : StringGrid1.Cells[X,I] := '<EMPTY>';
                adTinyInt          : StringGrid1.Cells[X,I] := Fields[X].Value;
                adSmallInt         : StringGrid1.Cells[X,I] := Fields[X].Value;
                adInteger          : StringGrid1.Cells[X,I] := Fields[X].Value;
                adBigInt           : StringGrid1.Cells[X,I] := Fields[X].Value;
                adUnsignedTinyInt  : StringGrid1.Cells[X,I] := Fields[X].Value;
                adUnsignedSmallInt : StringGrid1.Cells[X,I] := Fields[X].Value;
                adUnsignedInt      : StringGrid1.Cells[X,I] := Fields[X].Value;
                adUnsignedBigInt   : StringGrid1.Cells[X,I] := Fields[X].Value;
                adSingle           : StringGrid1.Cells[X,I] := Fields[X].Value;
                adDouble           : StringGrid1.Cells[X,I] := Fields[X].Value;
                adCurrency         : StringGrid1.Cells[X,I] := Fields[X].Value;
                adDecimal          : StringGrid1.Cells[X,I] := Fields[X].Value;
                adNumeric          : StringGrid1.Cells[X,I] := Fields[X].Value;
                adBoolean          : begin
                                       if (Fields[X].Value) then
                                         StringGrid1.Cells[X,I] := 'Yes'
                                       else
                                         StringGrid1.Cells[X,I] := 'No';
                                     end;
                adError            : StringGrid1.Cells[X,I] := '<ERROR>';
                adUserDefined      : StringGrid1.Cells[X,I] := '<USERDEFINED>';
                adVariant          : StringGrid1.Cells[X,I] := '<VARIANT>';
                adIDispatch        : StringGrid1.Cells[X,I] := '<IDISPATCH>';
                adIUnknown         : StringGrid1.Cells[X,I] := '<IUNKNOWN>';
                adGUID             : StringGrid1.Cells[X,I] := GUIDToString(TGUID(Fields[X].Value));
                adDate             : StringGrid1.Cells[X,I] := DateTimeToStr(Fields[X].Value);
                adDBDate           : StringGrid1.Cells[X,I] := DateTimeToStr(Fields[X].Value);
                adDBTime           : StringGrid1.Cells[X,I] := TimeToStr(Fields[X].Value);
                adDBTimeStamp      : StringGrid1.Cells[X,I] := '<DBTIMESTAMP>';
                adBSTR             : StringGrid1.Cells[X,I] := Fields[X].Value;
                adChar             : StringGrid1.Cells[X,I] := Fields[X].Value;
                adVarChar          : StringGrid1.Cells[X,I] := Fields[X].Value;
                adLongVarChar      : StringGrid1.Cells[X,I] := Fields[X].Value;
                adWChar            : StringGrid1.Cells[X,I] := Fields[X].Value;
                adVarWChar         : StringGrid1.Cells[X,I] := Fields[X].Value;
                adLongVarWChar     : StringGrid1.Cells[X,I] := Fields[X].Value;
                adBinary           : StringGrid1.Cells[X,I] := '<BINARY>';
                adVarBinary        : StringGrid1.Cells[X,I] := '<VARBINARY>';
                adLongVarBinary    : StringGrid1.Cells[X,I] := '<LONGVARBINARY>';
                adChapter          : StringGrid1.Cells[X,I] := '<CHAPTER>';
                adFileTime         : StringGrid1.Cells[X,I] := '<FILETIME>';
                adPropVariant      : StringGrid1.Cells[X,I] := '<PROPVARIANT>';
                adVarNumeric       : StringGrid1.Cells[X,I] := Fields[X].Value;
              else
                StringGrid1.Cells[X,I] := '<UNKNOWN>';
              end
            else
              StringGrid1.Cells[X,I] := ''; //<NULL>
          except
              on E: Exception do
                begin
                  StringGrid1.Cells[X,I] := 'Error! ' + GetDataTypeEnumDesc(Fields[X].Type_);
                  //ShowMessage('Error: ' + E.Message);
                end;
          end; //end try
        end; //end with ado21RecNWind2 and for X
      ado21RecNWind2.MoveNext;
    end;
end;



end.
