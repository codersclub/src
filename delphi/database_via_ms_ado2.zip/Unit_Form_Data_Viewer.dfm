object Form_Data_Viewer: TForm_Data_Viewer
  Left = 491
  Top = 394
  Width = 346
  Height = 244
  Caption = 'Data Viewer'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  OnHide = FormHide
  PixelsPerInch = 96
  TextHeight = 13
  object pcDataViewer: TPageControl
    Left = 4
    Top = 12
    Width = 332
    Height = 205
    ActivePage = tsDisplayText
    Anchors = [akLeft, akTop, akRight, akBottom]
    TabOrder = 1
    object tsDisplayText: TTabSheet
      Caption = 'Text'
      object cbTrueFalse: TCheckBox
        Left = 12
        Top = 8
        Width = 97
        Height = 17
        Caption = 'True / False'
        TabOrder = 1
      end
      object Memo_Data: TMemo
        Left = 0
        Top = 0
        Width = 324
        Height = 177
        Anchors = [akLeft, akTop, akRight, akBottom]
        BiDiMode = bdLeftToRight
        ParentBiDiMode = False
        TabOrder = 0
      end
    end
    object tsDisplayBinary: TTabSheet
      Caption = 'Binary'
      ImageIndex = 1
      object btnSaveBinary: TButton
        Left = 0
        Top = 0
        Width = 117
        Height = 25
        Caption = 'Save Binary to File'
        TabOrder = 0
        OnClick = btnSaveBinaryClick
      end
      object btnLoadBinary: TButton
        Left = 120
        Top = 0
        Width = 117
        Height = 25
        Caption = 'Load Binary from File'
        TabOrder = 1
        OnClick = btnLoadBinaryClick
      end
      object sbDataViewer: TScrollBox
        Left = 0
        Top = 28
        Width = 324
        Height = 149
        HorzScrollBar.Tracking = True
        VertScrollBar.Tracking = True
        Anchors = [akLeft, akTop, akRight, akBottom]
        TabOrder = 2
        object Image_Data: TImage
          Left = 0
          Top = 0
          Width = 401
          Height = 169
          Stretch = True
          OnClick = Image_DataClick
        end
      end
      object btnViewBinary: TButton
        Left = 240
        Top = 0
        Width = 81
        Height = 25
        Caption = 'View as Image'
        TabOrder = 3
        OnClick = btnViewBinaryClick
      end
    end
    object tsBinaryOptions: TTabSheet
      Caption = 'Binary Data Options'
      ImageIndex = 2
      object gbViewImage: TGroupBox
        Left = 156
        Top = 0
        Width = 161
        Height = 37
        Caption = 'View Image'
        TabOrder = 0
        object rbPreviewImage: TRadioButton
          Left = 4
          Top = 16
          Width = 61
          Height = 17
          Caption = 'Preview'
          Checked = True
          TabOrder = 0
          TabStop = True
          OnClick = rbPreviewImageClick
        end
        object rbActualImage: TRadioButton
          Left = 84
          Top = 16
          Width = 53
          Height = 17
          Caption = 'Actual'
          TabOrder = 1
          OnClick = rbActualImageClick
        end
      end
      object gbBinaryTypes: TGroupBox
        Left = 0
        Top = 40
        Width = 317
        Height = 137
        Caption = 'Binary Types'
        TabOrder = 1
        object gbImageTypes: TGroupBox
          Left = 156
          Top = 16
          Width = 157
          Height = 117
          TabOrder = 0
          object rbJpegImage: TRadioButton
            Left = 8
            Top = 16
            Width = 113
            Height = 17
            Caption = 'JPEG (*.jpg, *.jpeg)'
            Enabled = False
            TabOrder = 0
          end
          object rbBitmapImage: TRadioButton
            Left = 8
            Top = 36
            Width = 93
            Height = 17
            Caption = 'Bitmap (*.bmp)'
            Checked = True
            TabOrder = 1
            TabStop = True
          end
          object rbIconImage: TRadioButton
            Left = 8
            Top = 56
            Width = 73
            Height = 17
            Caption = 'Icon (*.ico)'
            TabOrder = 2
          end
          object rbEnhMetafile: TRadioButton
            Left = 8
            Top = 76
            Width = 145
            Height = 17
            Caption = 'Enhanced Metafile (*.emf)'
            TabOrder = 3
          end
          object rbMetafile: TRadioButton
            Left = 8
            Top = 96
            Width = 97
            Height = 17
            Caption = 'Metafile (*.wmf)'
            TabOrder = 4
          end
        end
        object gbFileTypes: TGroupBox
          Left = 4
          Top = 16
          Width = 149
          Height = 117
          Enabled = False
          TabOrder = 1
          object rbWordDoc: TRadioButton
            Left = 8
            Top = 36
            Width = 137
            Height = 17
            Caption = 'Word Document (*.doc)'
            TabOrder = 0
          end
          object rbTextDoc: TRadioButton
            Left = 8
            Top = 16
            Width = 121
            Height = 17
            Caption = 'Text Document (*.txt)'
            Checked = True
            TabOrder = 1
            TabStop = True
          end
          object rbExelDoc: TRadioButton
            Left = 8
            Top = 56
            Width = 137
            Height = 17
            Caption = 'Exel Spreadsheet (*.xls)'
            TabOrder = 2
          end
          object rbOtherDoc: TRadioButton
            Left = 8
            Top = 96
            Width = 49
            Height = 17
            Caption = 'Other'
            TabOrder = 3
          end
        end
        object rbFileTypes: TRadioButton
          Left = 8
          Top = 15
          Width = 69
          Height = 17
          Caption = 'File Types'
          Enabled = False
          TabOrder = 2
        end
        object rbImageTypes: TRadioButton
          Left = 160
          Top = 15
          Width = 81
          Height = 17
          Caption = 'Image Types'
          Checked = True
          TabOrder = 3
          TabStop = True
        end
      end
      object cbUpdateFieldOnLoad: TCheckBox
        Left = 20
        Top = 12
        Width = 121
        Height = 17
        Caption = 'Update field on load'
        TabOrder = 2
      end
    end
  end
  object btnUpdateData: TButton
    Left = 263
    Top = 4
    Width = 75
    Height = 25
    Anchors = [akTop, akRight]
    Caption = 'Update'
    TabOrder = 0
    OnClick = btnUpdateDataClick
  end
  object OpenDialogBinary: TOpenDialog
    Left = 344
    Top = 164
  end
  object SaveDialogBinary: TSaveDialog
    Left = 354
    Top = 106
  end
end
