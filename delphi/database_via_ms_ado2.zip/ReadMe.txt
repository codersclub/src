
Updated 9/16/2000
===General Notes===
This program was created to provide examples on using ADO in Delphi 5 for those who might not have the Borland ADO Express Components and possibly can be used as a general purpose database tool.

===Dependency Notes===

The following must be installed
    Microsoft ActiveX Data Objects 2.5 (Download from Microsoft if necessary)
    Microsoft ActiveX Data Objects 2.51 Update (Download from Microsoft if necessary)

---Import Type Libraries---
Microsoft ActiveX Data Objects 2.5 Library (Version 2.5)
    Class Names: TmsadoConnection, TmsadoCommand, TmsadoRecordset, 
                 TmsadoParameter, TmsadoStream
    Creates Files: ADODB_TLB(pas, dcu, dcr)
Microsoft ADO Ext. 2.1 for DDL and Security (Version 2.1)
    Class Names: TmsadoTable, TmsadoColumn, TmsadoIndex, TmsadoKey, 
                 TmsadoGroup, TmsadoUser, TmsadoCatalog
    Creates Files: ADOX_TLB(pas, dcu, dcr)
Microsoft Data Source Interfaces (Version 1.0)
    Note:  This item may or may not be required
    Creates Files: MSDATASRC_TLB(pas, dcu, dcr)

===Whats New===

1.) In this version I use ADO 2.5
2.) Delphi string grid is used instead of the Microsoft Data Grid
    a) Can double click on fields and view text or image data.
    b) Can load/save bolb data. (Tested with MS Access Database)
3.) Load/Save blob data to a file
4.) Improved loading/saving recordsets from/to a file
    a) Can load/save disconnected recordsets
    b) Can modify data on disconnected recordsets
    c) Can update batch
5.) Filter added for the tables section 
    a) Can filter out table types, names (include/exclude), and 
       tables with certain prefixes (mainly used for Oracle because 
       I found out that thousands of table type entries can exist which 
       would take a long time to load in the table list).
6.) Improved error handling
7.) Improved program interface
    a) Can load/save connection strings
    b) Can cancel catalog information loading for tables, views, and procedures
8.) Misc stuff here and there

Additional Notes: Works with Access 97/2000, Oracle 8i (ODBC drivers required), and SQL Server 6.5/7.0 (Not tested)

===Whats Unfinished===

Viewing Jpeg Pictures
Viewing Doc, Xls, and Text files
Interface for edit/save/delete connection strings
Some error checking
Loading and/or Saving of certain data types:
  adEmpty
  adError
  adUserDefined
  adVariant
  adIDispatch
  adIUnknown
  adGUID
  adDate
  adDBDate
  adDBTime
  adDBTimeStamp
  adChapter
  adFileTime
  adPropVariant
Adding and Deleting records

===Testing===

Tested with:
  Microsoft Access 97/2000 Database (Local)
  Oracle 8i (ODBC Drivers Required)
    Intranet
    Internet

===Special Notes===

The original sample NorthWind database contains images that are wrapped in special headers which make them unviewable.  If you try to view them you will receive an error.  I have modified the nothwind database (NWind2.mdb) pictures so they can be saved to a file and/or viewed.
You will find pictures (of type bitmap) in the "Employees" and "Categories" tables.

You can click on a list view to fetch or cancel(sometimes) the info related to that category instead of using the button.

You can double click on an data grid field to edit its data.

You can click on the image box to switch its display mode between preview and actual size.

You can edit data of loaded disconnected recordsets.

Filter Settings:

    Click on a radio button to display filter settings for that category.  In the filter field -1 means include and 0 means exclude that item from the filter, however "Filter by Name" is a special case where -1 means explicitly include and 0 means explicitly exclude.  An entry in this category overrides the previous filters.  Don't forget to update if you make changes.

Remember to update the binary field if you load a file for it because the save on load is not defaulted to save! (Assuming you want to save the data of course.)








