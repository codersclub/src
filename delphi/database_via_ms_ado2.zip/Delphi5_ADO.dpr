program Delphi5_ADO;

uses
  Forms,
  Unit_Shared in 'Unit_Shared.pas',
  Unit_Form_Main in 'Unit_Form_Main.pas' {Form_Main},
  Unit_Form_Data_Viewer in 'Unit_Form_Data_Viewer.pas' {Form_Data_Viewer};

{$E exe}

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'Delphi 5 ADO';
  Application.CreateForm(TForm_Main, Form_Main);
  Application.CreateForm(TForm_Data_Viewer, Form_Data_Viewer);
  Application.Run;
end.
