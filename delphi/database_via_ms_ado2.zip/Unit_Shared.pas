unit Unit_Shared;

interface

uses SysUtils, Dialogs, Forms, ComCtrls, Unit_Form_Main, ADODB_TLB, ADOX_TLB, MSDATASRC_TLB;

function  GetDataTypeEnumDesc(Value : Integer) : PChar;
function  GetSortOrderEnumDesc(Value : Integer) : PChar;
function  GetAllowNullsEnumDesc(Value : Integer) : PChar;
function  GetKeyTypeEnumDesc(Value : Integer) : PChar;
function  GetRuleEnumDesc(Value : Integer) : PChar;
function  GetObjectTypeEnumDesc(Value : Cardinal) : PChar;

implementation

function GetObjectTypeEnumDesc(Value : Cardinal) : PChar;
begin
  case Value of
    adPermObjProviderSpecific : Result := 'adPermObjProviderSpecific';
    adPermObjTable            : Result := 'adPermObjTable';
    adPermObjColumn           : Result := 'adPermObjColumn';
    adPermObjDatabase         : Result := 'adPermObjDatabase';
    adPermObjProcedure        : Result := 'adPermObjProcedure';
    adPermObjView             : Result := 'adPermObjView';
  else
    Result := PChar(Value);
  end;
end;

function GetRuleEnumDesc(Value : Integer) : PChar;
begin
  case Value of
    adRINone       : Result := 'adRINone';
    adRICascade    : Result := 'adRICascade';
    adRISetNull    : Result := 'adRISetNull';
    adRISetDefault : Result := 'adRISetDefault';
  else
    Result := PChar(Value);
  end;
end;

function GetKeyTypeEnumDesc(Value : Integer) : PChar;
begin
  case Value of
    adKeyPrimary : Result := 'adKeyPrimary';
    adKeyForeign : Result := 'adKeyForeign';
    adKeyUnique  : Result := 'adKeyUnique';
  else
    Result := PChar(Value);
  end;
end;

function GetAllowNullsEnumDesc(Value : Integer) : PChar;
begin
  case Value of
    adIndexNullsAllow     : Result := 'adIndexNullsAllow';
    adIndexNullsDisallow  : Result := 'adIndexNullsDisallow';
    adIndexNullsIgnore    : Result := 'adIndexNullsIgnore';
    adIndexNullsIgnoreAny : Result := 'adIndexNullsIgnoreAny';
  else
    Result := PChar(Value);
  end;
end;

function GetSortOrderEnumDesc(Value : Integer) : PChar;
begin
  case Value of
    adSortAscending  : Result := 'adSortAscending';
    adSortDescending : Result := 'adSortDescending';
  else
    Result := PChar(Value);
  end;
end;

function GetDataTypeEnumDesc(Value : Integer) : PChar;
begin
  case Value of
    adEmpty            : Result := 'adEmpty';
    adTinyInt          : Result := 'adTinyInt';
    adSmallInt         : Result := 'adSmallInt';
    adInteger          : Result := 'adInteger';
    adBigInt           : Result := 'adBigInt';
    adUnsignedTinyInt  : Result := 'adUnsignedTinyInt';
    adUnsignedSmallInt : Result := 'adUnsignedSmallInt';
    adUnsignedInt      : Result := 'adUnsignedInt';
    adUnsignedBigInt   : Result := 'adUnsignedBigInt';
    adSingle           : Result := 'adSingle';
    adDouble           : Result := 'adDouble';
    adCurrency         : Result := 'adCurrency';
    adDecimal          : Result := 'adDecimal';
    adNumeric          : Result := 'adNumeric';
    adBoolean          : Result := 'adBoolean';
    adError            : Result := 'adError';
    adUserDefined      : Result := 'adUserDefined';
    adVariant          : Result := 'adVariant';
    adIDispatch        : Result := 'adIDispatch';
    adIUnknown         : Result := 'adIUnknown';
    adGUID             : Result := 'adGUID';
    adDate             : Result := 'adDate';
    adDBDate           : Result := 'adDBDate';
    adDBTime           : Result := 'adDBTime';
    adDBTimeStamp      : Result := 'adDBTimeStamp';
    adBSTR             : Result := 'adBSTR';
    adChar             : Result := 'adChar';
    adVarChar          : Result := 'adVarChar';
    adLongVarChar      : Result := 'adLongVarChar';
    adWChar            : Result := 'adWChar';
    adVarWChar         : Result := 'adVarWChar';
    adLongVarWChar     : Result := 'adLongVarWChar';
    adBinary           : Result := 'adBinary';
    adVarBinary        : Result := 'adVarBinary';
    adLongVarBinary    : Result := 'adLongVarBinary';
    adChapter          : Result := 'adChapter';
    adFileTime         : Result := 'adFileTime';
    adPropVariant      : Result := 'adPropVariant';
    adVarNumeric       : Result := 'adVarNumeric';
  else
    Result := PChar(Value);
  end;
end;

end.
