unit Net;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ComCtrls, StdCtrls, Buttons, ImgList;

type
  TNetForm = class(TForm)
    ListView1: TListView;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    ImageList1: TImageList;
    procedure FormShow(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure ListView1DblClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    Function FillNetLevel(xxx: PNetResource; list: TListItems) : Word;
    function GetComputer:String;
  end;

var
  NetForm: TNetForm;

implementation

{$R *.DFM}

function TNetForm.FillNetLevel(xxx: PNetResource; List:TListItems): Word;
Type
    PNRArr = ^TNRArr;
    TNRArr = array[0..59] of TNetResource;
Var
   x: PNRArr;
   tnr: TNetResource;
   I : integer;
   EntrReq,
   SizeReq,
   twx: THandle;
   WSName: string;
   LI:TListItem;
begin
     Result :=WNetOpenEnum(RESOURCE_GLOBALNET, RESOURCETYPE_ANY,RESOURCEUSAGE_CONTAINER, xxx, twx);
     If Result = ERROR_NO_NETWORK Then Exit;
     if Result = NO_ERROR then
     begin
            New(x);
            EntrReq := 1;
            SizeReq := SizeOf(TNetResource)*59;
            while (twx <> 0) and
                  (WNetEnumResource(twx, EntrReq, x, SizeReq) <> ERROR_NO_MORE_ITEMS) do
            begin
                  For i := 0 To EntrReq - 1 do
                  begin
                   Move(x^[i], tnr, SizeOf(tnr));
                   case tnr.dwDisplayType of
                    RESOURCEDISPLAYTYPE_SERVER:
                    begin
                       if tnr.lpRemoteName <> '' then
                           WSName:= tnr.lpRemoteName
                           else WSName:= tnr.lpComment;
                       LI:=list.Add;
                       LI.Caption:=copy(WSName,3,length(WSName)-2);
                       //list.Add(WSName);
                    end;
                    else FillNetLevel(@tnr, list);
                   end;
                  end;
            end;
            Dispose(x);
            WNetCloseEnum(twx);
     end;
end;


procedure TNetForm.FormShow(Sender: TObject);
begin
  ListView1.Items.Clear;
  FillNetLevel(nil,ListView1.Items);
end;

function TNetForm.GetComputer: String;
begin
  result:='';
  if (ShowModal=mrok)and(ListView1.Selected<>nil) then result:=ListView1.Selected.Caption;
end;

procedure TNetForm.BitBtn2Click(Sender: TObject);
begin
  ModalResult:=mrcancel;
end;

procedure TNetForm.BitBtn1Click(Sender: TObject);
begin
  modalresult:=mrok;
end;

procedure TNetForm.ListView1DblClick(Sender: TObject);
begin
  modalresult:=mrok;
end;

end.
