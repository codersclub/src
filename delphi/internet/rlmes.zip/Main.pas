unit Main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, Trayicon, ScktComp, ComCtrls, Buttons, Db, DBClient,
  MConnect, SConnect, Menus, ImgList;

type
  TMessage=class(TComponent)
  private
    FRemoteHost              :string;
    FDate                    :TDate;
    FTime                    :TTime;
    FMessage                 :string;
  published
    property RemoteHost:String read FremoteHost write FremoteHost;
    property Date:TDate read Fdate write Fdate;
    property Time:TTime read Ftime write FTime;
    property Message:string read FMessage write FMessage;
  end;

  TMessages=class
  Private
    FMessages    :TList;
    function GetMessage(Index: integer): TMessage;
  Public
    constructor Create;
    destructor Destroy;
    procedure Delete(Index:Integer);
    Procedure Clear;
    Function Count:integer;
    function Add:TMessage;overload;
    function Add(RemoteHost,Mes:String;Date:TDate;Time:TTime):integer;overload;
    property Messages[Index:integer]:TMessage read GetMessage;
    function WriteToStream:TMemoryStream;
    procedure LoadFromStream(Stream:TMemoryStream);
    function GetIndex(Mes:Tmessage):integer;
  end;

  TMainForm = class(TForm)
    TrayIcon1: TTrayIcon;
    GroupBox1: TGroupBox;
    GroupBox2: TGroupBox;
    Splitter1: TSplitter;
    ServerSocket1: TServerSocket;
    ClientSocket1: TClientSocket;
    Panel1: TPanel;
    Edit1: TEdit;
    Label1: TLabel;
    Memo1: TMemo;
    SpeedButton1: TSpeedButton;
    BitBtn1: TBitBtn;
    Splitter2: TSplitter;
    Memo2: TMemo;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TreeView1: TTreeView;
    ListView1: TListView;
    PopupMenu1: TPopupMenu;
    N1: TMenuItem;
    N2: TMenuItem;
    ImageList1: TImageList;
    PopupMenu2: TPopupMenu;
    N3: TMenuItem;
    procedure TrayIcon1Click(Sender: TObject);
    procedure FormCloseQuery(Sender: TObject; var CanClose: Boolean);
    procedure FormCreate(Sender: TObject);
    procedure SpeedButton1Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure ServerSocket1ClientRead(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Connect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Error(Sender: TObject; Socket: TCustomWinSocket;
      ErrorEvent: TErrorEvent; var ErrorCode: Integer);
    procedure FormDestroy(Sender: TObject);
    procedure ListView1Click(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure TreeView1Click(Sender: TObject);
    procedure N3Click(Sender: TObject);
    procedure N1Click(Sender: TObject);
  private
    { Private declarations }
    procedure WMSysCommand(var Message: TWMSysCommand); message WM_SYSCOMMAND;
  public
    { Public declarations }
    ForSend               :string;
    SoundFileName         :string;
    FMessages             :TMessages;
    procedure LoadIniFile;
    procedure WriteIniFile;
    Procedure PlaySound(Filename:string);
    Procedure LoadListView(Mes:TMessages);
    Procedure LoadTreeView(Mes:TMessages);
    Procedure AddInTree(Mes:TMessage);
  end;

var
  MainForm: TMainForm;

implementation
uses inifiles, Net,MMSystem;
{$R *.DFM}

procedure TMainForm.TrayIcon1Click(Sender: TObject);
begin
  show;
end;

procedure TMainForm.FormCloseQuery(Sender: TObject; var CanClose: Boolean);
begin
  if MessageDlg('�� ������������� ������ ������� ������ �������� ���������?',mtConfirmation,[mbyes,mbno],0)=mryes
    then
    begin
     CanClose:=true;
     WriteIniFile;
    end
    else canclose:=false;
end;

procedure TMainForm.WMSysCommand(var Message: TWMSysCommand);
begin
  inherited;
  if (Message.CmdType and $FFF0 = SC_MINIMIZE) then hide;
end;

procedure TMainForm.LoadIniFile;
var I:TIniFile;
begin
  I:=TIniFile.Create(ExtractFilePath(Application.ExeName)+'\RLMes.ini');
  ClientSocket1.Port:=StrToInt(i.ReadString('Device','Port','277'));
  ServerSocket1.Port:=StrToInt(i.ReadString('Device','Port','277'));
  Edit1.text:=i.ReadString('Connect','Last','LocalHost');
  SoundFileName:=i.ReadString('Sound','OnMessage','Mes.wav');
  Top:=strtoint(i.ReadString('Position','Top','0'));
  Left:=strtoint(i.ReadString('Position','Left','0'));
  Width:=strtoint(i.ReadString('Position','Width','600'));
  Height:=strtoint(i.ReadString('Position','Height','360'));
  if AnsiUpperCase(i.ReadString('Position','Client','False'))='FALSE'
     then WindowState:=wsNormal
     else WindowState:=wsMaximized;
  PageControl1.Width:=strtoint(i.ReadString('Position','PC1','200'));
  GroupBox1.Height:=strtoint(i.ReadString('Position','GB1','145'));
  I.free;
end;

procedure TMainForm.FormCreate(Sender: TObject);
var Str:TMemoryStream;
begin
  LoadIniFile;
  FMessages:=TMessages.Create;
  Str:=TMemoryStream.Create;
  str.LoadFromFile('Message.Data');
  FMessages.LoadFromStream(Str);
  str.free;
  LoadListView(FMessages);
  LoadTreeView(FMessages);
  ServerSocket1.Open;
end;

procedure TMainForm.WriteIniFile;
var I:TIniFile;
begin
 try
  I:=TIniFile.Create(ExtractFilePath(Application.ExeName)+'\RLMes.ini');
  i.WriteString('Device','Port',inttostr(ClientSocket1.port));
  i.WriteString('Connect','Last',Edit1.text);
  i.WriteString('Sound','OnMessage',SoundFileName);
  if WindowState=wsNormal then
  Begin
    i.WriteString('Position','Top',inttostr(top));
    i.WriteString('Position','Left',inttostr(Left));
    i.WriteString('Position','Width',inttostr(Width));
    i.WriteString('Position','Height',inttostr(Height));
    i.WriteString('Position','Client','False');
  end else i.WriteString('Position','Client','True');
  i.WriteString('Position','GB1',inttostr(GroupBox1.Height));
  i.WriteString('Position','PC1',inttostr(PageControl1.Width));
  I.free;
 except end;
end;

procedure TMainForm.SpeedButton1Click(Sender: TObject);
begin
  edit1.Text:=NetForm.GetComputer;
end;

procedure TMainForm.BitBtn1Click(Sender: TObject);
begin
  ForSend:=Memo1.Lines.Text;
  ClientSocket1.Close;
  ClientSocket1.Host:=edit1.Text;
  ClientSocket1.Open;
  memo1.Clear;
end;

procedure TMainForm.ServerSocket1ClientRead(Sender: TObject;
  Socket: TCustomWinSocket);
var LI:TListItem;
begin
  memo2.Lines.Clear;
  memo2.Lines.Add(socket.ReceiveText);
  LI:=ListView1.Items.Add;
  LI.Caption:=Socket.RemoteHost+' '+datetostr(date)+' '+timetostr(time);
  LI.Data:=FMessages.Messages[FMessages.Add(Socket.RemoteHost,memo2.Lines.Text,date,time)];
  li.ImageIndex:=2;
  AddInTree(TMessage(LI.Data));
  show;
  SetFocus;
  PlaySound(SoundFileName);
end;

procedure TMainForm.ClientSocket1Connect(Sender: TObject;
  Socket: TCustomWinSocket);
begin
  socket.SendText(ForSend);
  ForSend:='';
end;

procedure TMainForm.ClientSocket1Error(Sender: TObject;
  Socket: TCustomWinSocket; ErrorEvent: TErrorEvent;
  var ErrorCode: Integer);
begin
  ErrorCode:=0;
  showmessage('���������� ��������� ���������!');
end;

procedure TMainForm.PlaySound(Filename: string);
var
   f: file;
   p: pointer;
   fs: integer;
begin
  try
  AssignFile(f, FileName);
  Reset(f,1);
  fs := FileSize(f);
  GetMem(p, fs);
  BlockRead(f, p^, fs);
  CloseFile(f);
  sndPlaySound(p, SND_MEMORY or SND_SYNC);
  FreeMem(p, fs);
  except end;
end;

{ TMessages }

function TMessages.Add: TMessage;
begin
  result:=TMessage.Create(nil);
  FMessages.Add(result);
end;

function TMessages.Add(RemoteHost, Mes: String; Date: TDate;
  Time: TTime): integer;
var T:TMessage;
begin
  T:=TMessage.Create(nil);
  t.FRemoteHost:=RemoteHost;
  t.FDate:=date;
  t.FTime:=time;
  t.FMessage:=Mes;
  result:=FMessages.Add(t);
end;

procedure TMessages.Clear;
begin
  while Count>0 do Delete(0);
end;

function TMessages.Count: integer;
begin
  Result:=FMessages.Count;
end;

constructor TMessages.Create;
begin
  inherited;
  FMessages:=TList.Create;
end;

procedure TMessages.Delete(Index: Integer);
begin
  TMessage(FMessages[index]).Free;
  FMessages.Delete(Index);
end;

destructor TMessages.Destroy;
begin
  inherited;
  Clear;
  FMessages.Free;
end;

procedure TMainForm.FormDestroy(Sender: TObject);
var d:TMemoryStream;
begin
  d:=FMessages.WriteToStream;
  d.SaveToFile('Message.Data');
  d.free;
  FMessages.Free;
end;

function TMessages.GetIndex(Mes: Tmessage): integer;
var i:integer;
begin
  result:=-1;
  for i:=0 to count-1 do
    if Pointer(messages[i])=pointer(mes) then
    begin
      result:=i;
      break;
    end;
end;

function TMessages.GetMessage(Index: integer): TMessage;
begin
  result:=TMessage(FMessages[index]);
end;

procedure TMessages.LoadFromStream(Stream: TMemoryStream);
var Pos:integer;
    w:word;
    H,M:String;
    D:TDate;
    T:TTime;
    P:PChar;
    Mes:TMessage;
begin
  clear;
  Stream.Position:=0;
  while Stream.Position<Stream.Size do
  begin
    Mes:=add;
    Stream.ReadComponent(mes);
{    Stream.Read(w,sizeof(w));
    GetMem(P,w);
    Stream.Read(P^,w);
    H:=P;
    FreeMem(P);
    Stream.Read(w,sizeof(w));
    Stream.Read(d,w);
    Stream.Read(w,sizeof(w));
    Stream.Read(t,w);
    Stream.Read(w,sizeof(w));
    GetMem(P,w);
    Stream.Read(P^,w);
    M:=P;
    FreeMem(P);
    add(h,m,d,t);}
  end;

end;

function TMessages.WriteToStream: TMemoryStream;
var i:integer;
  Procedure WriteMessage(Index:integer);
  var W:^Word;
  Begin
{    new(w);
    w^:=length(Messages[index].FRemoteHost);
    result.Write(w^,sizeof(w^));
    result.Write(pchar(Messages[index].FRemoteHost)^,length(Messages[index].FRemoteHost));
    w^:=sizeof(Messages[index].FDate);
    result.Write(w^,sizeof(w^));
    result.Write(Messages[index].FDate,sizeof(Messages[index].FDate));
    w^:=sizeof(Messages[index].FTime);
    result.Write(w^,sizeof(w^));
    result.Write(Messages[index].FTime,sizeof(Messages[index].FTime));
    w^:=length(Messages[index].FMessage);
    result.Write(w^,sizeof(w^));
    result.Write(Pointer(Messages[index].FMessage)^,length(Messages[index].FMessage));
    dispose(w);}
    Result.WriteComponent(Messages[index]);
  end;
begin
  result:=TMemoryStream.Create;
  for i:=0 to count-1 do WriteMessage(i);
end;

procedure TMainForm.ListView1Click(Sender: TObject);
begin
  Memo2.Lines.Text:=TMessage(ListView1.Selected.Data).FMessage;
end;

procedure TMainForm.N2Click(Sender: TObject);
begin
  FMessages.Clear;
  TreeView1.Items.Clear;
  ListView1.Items.Clear;
end;

procedure TMainForm.LoadListView(Mes: TMessages);
var i:integer;
    LI:TListItem;
begin
  for i:=0 to mes.Count-1 do
  begin
    LI:=ListView1.Items.Add;
    LI.Caption:=mes.Messages[i].FRemoteHost+' '+DateToStr(mes.Messages[i].FDate)+' '+TimeToStr(mes.Messages[i].FTime);
    li.Data:=mes.Messages[i];
    li.ImageIndex:=2;
  end;
end;

procedure TMainForm.AddInTree(Mes: TMessage);
var i:integer;
    f:boolean;
    TN:TTreeNode;
begin
  f:=true;
  for i:=0 to TreeView1.Items.Count-1 do
    if TreeView1.Items[i].Text=AnsiUpperCase(mes.FRemoteHost) then
    Begin
      TN:=TreeView1.Items.AddChildObject(TreeView1.Items[i],(datetostr(mes.FDate)+' '+timetostr(mes.FTime)),mes);
      TN.ImageIndex:=2;
      tn.SelectedIndex:=2;
      f:=false;
      break;
    end;
  if f then
  begin
    tn:=TreeView1.Items.Add(nil,AnsiUpperCase(mes.FRemoteHost));
    TN.ImageIndex:=0;
    tn.SelectedIndex:=0;
    tn:=TreeView1.Items.AddChildObject(TN,(datetostr(mes.FDate)+' '+timetostr(mes.FTime)),mes);
    TN.ImageIndex:=2;
    tn.SelectedIndex:=2;
  end;
end;

procedure TMainForm.LoadTreeView(Mes: TMessages);
var i:integer;
begin
  for i:=0 to mes.Count-1 do
    AddInTree(mes.Messages[i]);
end;

procedure TMainForm.TreeView1Click(Sender: TObject);
begin
  if TreeView1.Selected.Data<>nil then
    memo2.Text:=TMessage(TreeView1.Selected.Data).FMessage;
end;

procedure TMainForm.N3Click(Sender: TObject);
begin
  close;
end;

procedure TMainForm.N1Click(Sender: TObject);
var i:integer;
begin
  if PageControl1.ActivePageIndex=0 then
  begin
    if TreeView1.Selected.data<>nil then
    begin
      for i:=0 to ListView1.Items.Count-1 do
        if Pointer(ListView1.Items[i].Data)=pointer(TreeView1.Selected.Data) then
        begin
          ListView1.Items[i].Delete;
          break;
        end;
      FMessages.Delete(FMessages.GetIndex(TMessage(TreeView1.Selected.Data)));
      TreeView1.Selected.Delete;
    end;
  end else
  begin
   if ListView1.Selected<>nil then
   begin
    for i:=0 to TreeView1.Items.Count-1 do
      if Pointer(TreeView1.Items[i].Data)=pointer(ListView1.Selected.Data) then
      begin
        TreeView1.Items[i].Delete;
        break;
      end;
    FMessages.Delete(FMessages.GetIndex(TMessage(ListView1.Selected.Data)));
    ListView1.Selected.Delete;
   end;
  end;
end;

end.

