program RLMes;

uses
  Forms,
  Main in 'Main.pas' {MainForm},
  Net in 'Net.pas' {NetForm};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'RL �������';
  Application.CreateForm(TMainForm, MainForm);
  Application.CreateForm(TNetForm, NetForm);
  Application.ShowMainForm:=false;
  Application.Run;
end.
