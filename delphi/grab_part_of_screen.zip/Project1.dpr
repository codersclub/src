program Project1;

uses
  Forms,
  Unit1 in 'Unit1.pas' {FrmMain},
  Unit2 in 'Unit2.pas' {FrmImage};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'ScreenShot';
  Application.CreateForm(TFrmMain, FrmMain);
  Application.CreateForm(TFrmImage, FrmImage);
  Application.Run;
end.
