object FrmMain: TFrmMain
  Left = 448
  Top = 205
  BorderIcons = [biSystemMenu]
  BorderStyle = bsSingle
  Caption = 'Get Screen'#39's Piece'
  ClientHeight = 117
  ClientWidth = 192
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Icon.Data = {
    0000010002002020100000000000E80200002600000010101000000000002801
    00000E0300002800000020000000400000000100040000000000800200000000
    0000000000000000000000000000000000000000800000800000008080008000
    0000800080008080000080808000C0C0C0000000FF0000FF000000FFFF00FF00
    0000FF00FF00FFFF0000FFFFFF00077777770007777000000000000000000000
    00077700007770000000000000000FBFBFB000BFBF0077700000000000000BFB
    FBFBFBFBFBF000777000000000000FBFBFBFB0000FBFBF007700000000000BFB
    FBFB777780FBFBF00770000000000FBFBFB7BFBF780FBFBF0070000000000BFB
    FB7BFBFBF780FBFBF077000000000FBFB70FBFBFBF70BFBFB007777770000BFB
    F70B7777777077777700000077000FBFB70FBFBFBF70BFBFBFBFBFB007700BFB
    F70BFBFBFB70FBFBFBFBFBFB00700FBFB70FBFBFBF70BFBFBFBFBFBFB0700BFB
    F70BFBFBFB70FBFBFBFBFBFBF0770FBFB70FBFBFBF70BFBFBFBFBFBFB0070BFB
    F70BFBFBFB70FBFBFBFBFBFBFB070FBFB70FBFBFBF70BFBFBFBFBFBFBF070BFB
    F70B7777777077777777777777070FBFB70FBFBFBF70BFBFBFBFBFBFBF070BFB
    F70BFBFBFB70FBFBFBFBFBFBFB070FBFB70FBFBFBF70BFBFBFBFBFBFBF070BFB
    F70BFBFBFB70FBFBFBFBFBFBFB070FBFB70FBFBFBF70BFBFBFBFBFBFBF070BFB
    F70BFBFBFB70FBFBFBFBFBFBFB070FBFB70FBFBFBF7FBFBFBFBFBFBFBF070BFB
    F70BFBFBFBFBFBFBFBFBFBFBFB07000007000000000000000000000000000000
    0700000070000000000000000000000007000000700000000000000000000000
    0780000070000000000000000000000000780007000000000000000000000000
    000777700000000000000000000080E1FFFF00007FFF00001FFF000007FF0000
    03FF000001FF000001FF000000FF000000070000000300000001000000010000
    0001000000000000000000000000000000000000000000000000000000000000
    0000000000000000000000000000000000000000000000000001F9F3FFFFF9F3
    FFFFF8F7FFFFFC0FFFFFFE1FFFFF280000001000000020000000010004000000
    0000C00000000000000000000000000000000000000000000000000080000080
    00000080800080000000800080008080000080808000C0C0C0000000FF0000FF
    000000FFFF00FF000000FF00FF00FFFF0000FFFFFF0000000000770000000FBF
    BFB0007000000BFB000BF00700000FB70700BF0070000B70F770770007700F70
    BF70BFBFB0070B70FB70FBFBFB070F70BF70BFBFBF070B70F770777777070F70
    BF70BFBFBF070B70FBF0FBFBFB070F70BFBFBFBFBF0700700000000000000070
    07000000000000700000000000000007770000000000003F0000001F0000000F
    0000000700000001000000000000000000000000000000000000000000000000
    00000000000000010000C9FF0000C3FF0000E3FF0000}
  OldCreateOrder = False
  Position = poScreenCenter
  OnHide = FormHide
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 8
    Top = 8
    Width = 177
    Height = 17
    Alignment = taCenter
    AutoSize = False
    Caption = 'Set Your Preferences:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clBlue
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold, fsUnderline]
    ParentFont = False
  end
  object Label2: TLabel
    Left = 8
    Top = 40
    Width = 10
    Height = 14
    Alignment = taCenter
    Caption = 'X:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label3: TLabel
    Left = 8
    Top = 64
    Width = 34
    Height = 14
    Alignment = taCenter
    Caption = 'Width:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label4: TLabel
    Left = 104
    Top = 40
    Width = 10
    Height = 14
    Alignment = taCenter
    Caption = 'Y:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Label5: TLabel
    Left = 104
    Top = 64
    Width = 38
    Height = 14
    Alignment = taCenter
    Caption = 'Height:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object TxtX: TEdit
    Left = 24
    Top = 40
    Width = 65
    Height = 17
    AutoSize = False
    BorderStyle = bsNone
    Color = clMenu
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clActiveCaption
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 0
    Text = '100'
  end
  object TxtY: TEdit
    Left = 120
    Top = 40
    Width = 65
    Height = 17
    AutoSize = False
    BorderStyle = bsNone
    Color = clMenu
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clActiveCaption
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 1
    Text = '100'
  end
  object TxtW: TEdit
    Left = 56
    Top = 64
    Width = 33
    Height = 17
    AutoSize = False
    BorderStyle = bsNone
    Color = clMenu
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clActiveCaption
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 2
    Text = '100'
  end
  object TxtH: TEdit
    Left = 144
    Top = 64
    Width = 41
    Height = 17
    AutoSize = False
    BorderStyle = bsNone
    Color = clMenu
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clActiveCaption
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 3
    Text = '100'
  end
  object CmdGet: TButton
    Left = 64
    Top = 88
    Width = 65
    Height = 25
    Caption = 'Get It!'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = []
    ParentFont = False
    TabOrder = 4
    OnClick = CmdGetClick
  end
end
