unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls;

type
  TFrmImage = class(TForm)
    SB: TScrollBox;
    Img: TImage;
    procedure FormCreate(Sender: TObject);
    procedure FormShow(Sender: TObject);
    procedure FormHide(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmImage: TFrmImage;

implementation

uses Unit1;

{$R *.DFM}

procedure TFrmImage.FormCreate(Sender: TObject);
begin
frmimage.icon:=frmmain.icon;
end;

procedure TFrmImage.FormShow(Sender: TObject);
Var DeskHw,DeskHdC : Longint;
begin
DeskHw:=getdesktopwindow;
DeskHdc:=getdc(deskHw);
img.height:=strtoint(frmmain.txtH.text);
img.width:=strtoint(frmmain.txtw.text);
BitBlt(img.Canvas.Handle,0,0,strtoint(frmmain.txtW.text),
strtoint(frmmain.txtH.text),DeskHdc,strtoint(frmmain.txtx.text),
strtoint(frmmain.txty.text),SRCCOPY);
sb.Repaint;
end;

procedure TFrmImage.FormHide(Sender: TObject);
begin
frmmain.enabled:=true;
end;

end.
