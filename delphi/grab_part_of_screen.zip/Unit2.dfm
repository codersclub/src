object FrmImage: TFrmImage
  Left = 276
  Top = 113
  Width = 448
  Height = 412
  BorderIcons = [biSystemMenu]
  Caption = 'Your Image:'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnHide = FormHide
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object SB: TScrollBox
    Left = 8
    Top = 16
    Width = 425
    Height = 361
    HorzScrollBar.Smooth = True
    TabOrder = 0
    object Img: TImage
      Left = 0
      Top = 0
      Width = 369
      Height = 297
    end
  end
end
