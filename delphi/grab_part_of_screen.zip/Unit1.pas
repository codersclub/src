unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TFrmMain = class(TForm)
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Label4: TLabel;
    Label5: TLabel;
    TxtX: TEdit;
    TxtY: TEdit;
    TxtW: TEdit;
    TxtH: TEdit;
    CmdGet: TButton;
    procedure CmdGetClick(Sender: TObject);
    procedure FormHide(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  FrmMain: TFrmMain;

implementation

uses Unit2;

{$R *.DFM}

procedure TFrmMain.CmdGetClick(Sender: TObject);
begin
frmimage.FormCreate (frmmain) ;
frmimage.Visible :=true;
frmmain.Enabled :=false;
end;

procedure TFrmMain.FormHide(Sender: TObject);
begin
application.messagebox ('Get Screen Piece Example'+chr(13)+'by Andrea Fontana'+chr(13)+'(www.andreafontana.com)','Info',MB_OK ) ;
end;

end.
