program WebGui;

uses
  Forms,
  Unit1 in 'Unit1.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TWebHammer, WebHammer);
  Application.Run;
end.
