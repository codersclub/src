This program is a mini web brute force hacker. The purpose is not to hack websites but for educational purposes only. I Do not encourage hacking of site!!! so if u got caught dont blame me. To use this program you should load first a dictionary file. An example dict. file is included then type the page that you want to test. Ex. is

http://www.cindy.com/members/index.html

then press start

Sorry for my bad english

