object Form1: TForm1
  Left = 291
  Top = 141
  Width = 688
  Height = 448
  Caption = 'News & Forums Crowler ver.1.0.0.2'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object Label3: TLabel
    Left = 8
    Top = 112
    Width = 46
    Height = 13
    Caption = 'Groupes :'
  end
  object Label4: TLabel
    Left = 8
    Top = 224
    Width = 40
    Height = 13
    Caption = 'Articles :'
  end
  object Panel1: TPanel
    Left = 8
    Top = 8
    Width = 233
    Height = 97
    TabOrder = 0
    object Label1: TLabel
      Left = 8
      Top = 8
      Width = 43
      Height = 13
      Caption = 'Serveur :'
    end
    object Label5: TLabel
      Left = 8
      Top = 72
      Width = 169
      Height = 13
      Caption = 'Nombres des fichiers cr�er au total :'
    end
    object Label6: TLabel
      Left = 184
      Top = 72
      Width = 42
      Height = 13
      Alignment = taCenter
      Caption = '0000000'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clRed
      Font.Height = -11
      Font.Name = 'MS Sans Serif'
      Font.Style = []
      ParentFont = False
    end
    object Label7: TLabel
      Left = 8
      Top = 48
      Width = 142
      Height = 13
      Caption = 'Nombre des groupes au total :'
    end
    object Label8: TLabel
      Left = 152
      Top = 48
      Width = 42
      Height = 13
      Alignment = taCenter
      Caption = '0000000'
    end
    object Serveur: TComboBox
      Left = 72
      Top = 8
      Width = 153
      Height = 21
      ItemHeight = 13
      TabOrder = 0
      Text = 'forums.borland.com'
      Items.Strings = (
        'forums.borland.com'
        'msnews.microsoft.com')
    end
  end
  object ListBox1: TListBox
    Left = 8
    Top = 128
    Width = 233
    Height = 89
    ItemHeight = 13
    TabOrder = 1
    OnClick = ListBox1Click
  end
  object ListBox2: TListBox
    Left = 8
    Top = 240
    Width = 233
    Height = 105
    ItemHeight = 13
    TabOrder = 2
  end
  object StatusBar1: TStatusBar
    Left = 0
    Top = 396
    Width = 680
    Height = 25
    Panels = <>
    SimplePanel = False
    SimpleText = '(C) 2000 Onecor. Tous droits r�serv�s.'
  end
  object Memo1: TMemo
    Left = 248
    Top = 8
    Width = 425
    Height = 337
    Lines.Strings = (
      'Memo1')
    TabOrder = 4
  end
  object Button1: TButton
    Left = 600
    Top = 360
    Width = 73
    Height = 25
    Caption = '&Quitter'
    TabOrder = 5
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 456
    Top = 360
    Width = 137
    Height = 25
    Caption = '&D�marrer'
    TabOrder = 6
    OnClick = Button2Click
  end
  object Button3: TButton
    Left = 376
    Top = 360
    Width = 73
    Height = 25
    Caption = '&Info'
    TabOrder = 7
    OnClick = Button3Click
  end
  object NMNNTP1: TNMNNTP
    Port = 119
    ReportLevel = 0
    OnConnect = NMNNTP1Connect
    OnInvalidHost = NMNNTP1InvalidHost
    OnHostResolved = NMNNTP1HostResolved
    OnStatus = NMNNTP1Status
    OnConnectionFailed = NMNNTP1ConnectionFailed
    CacheMode = cmMixed
    ParseAttachments = False
    OnConnectionRequired = NMNNTP1ConnectionRequired
    OnGroupListUpdate = NMNNTP1GroupListUpdate
    OnGroupListCacheUpdate = NMNNTP1GroupListCacheUpdate
    OnHeaderList = NMNNTP1HeaderList
    OnHeaderListCacheUpdate = NMNNTP1HeaderListCacheUpdate
    OnArticle = NMNNTP1Article
    OnArticleCacheUpdate = NMNNTP1ArticleCacheUpdate
    OnAbort = NMNNTP1Abort
    OnInvalidArticle = NMNNTP1InvalidArticle
    Left = 256
    Top = 40
  end
  object Timer1: TTimer
    Interval = 80000
    OnTimer = Timer1Timer
    Left = 256
    Top = 128
  end
  object Timer2: TTimer
    Interval = 500
    OnTimer = Timer2Timer
    Left = 256
    Top = 264
  end
end
