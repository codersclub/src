unit FmSpawnProcess;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls;

type
  TSpawnDlg = class(TForm)
    rgpBlockType: TRadioGroup;
    memoVars: TMemo;
    lblVars: TLabel;
    btnSpawn: TButton;
    Close: TButton;
    procedure rgpBlockTypeClick(Sender: TObject);
    procedure btnSpawnClick(Sender: TObject);
  private
    function BuildEnvBlock(IncludeCurrent: Boolean): PChar;
  end;

var
  SpawnDlg: TSpawnDlg;

implementation

uses
  PJEnvVars;

{$R *.DFM}

procedure ExecAppWithEnvBlock;
var
  SI: TStartupInfo;         // start up info
  PI: TProcessInformation;  // process info
  NewEnv: TStringList;      // new env strings
  BufSize: Integer;         // env block size
  Buffer: PChar;            // env block
begin
  // Create new env block
  NewEnv := TStringList.Create;
  NewEnv.Add('FOO=Bar');
  BufSize :=  CreateEnvBlock(NewEnv, False, nil, 0);
  Buffer := StrAlloc(BufSize);
  CreateEnvBlock(NewEnv, False, Buffer, BufSize);
  // Exec child process 
  FillChar(SI, SizeOf(SI), 0);
  SI.cb := SizeOf(SI);
  // Execute the program
  CreateProcess(nil, PChar(ParamStr(0)), nil, nil, True, 
    0, Buffer, nil, SI, PI);
  // Free the block
  StrDispose(Buffer);
end;

{ Helper routines }

procedure ExecProg(ProgName: string; EnvBlock: Pointer);
  {Creates a new process for given program passing any given environment block}
var
  SI: TStartupInfo;         // start up info
  PI: TProcessInformation;  // process info
begin
  // Set up startup info record: all default values
  FillChar(SI, SizeOf(SI), 0);
  SI.cb := SizeOf(SI);
  // Execute the program
  CreateProcess(nil, PChar(ProgName), nil, nil, True, 0, EnvBlock, nil, SI, PI);
end;


{ TSpawnDlg }

procedure TSpawnDlg.btnSpawnClick(Sender: TObject);
  // create a new process with an environment block per radio buttons
var
  Block: PChar;
begin
  case rgpBlockType.ItemIndex of
    0:  // create process with copy of current environment
      ExecProg(ParamStr(0), nil);
    1:  // create process whose environment is per memo control
    begin
      Block := BuildEnvBlock(False);
      try
        ExecProg(ParamStr(0), Block);
      finally
        StrDispose(Block);
      end;
    end;
    2:  // create process with copy of current environment + entries in memo box
    begin
      Block := BuildEnvBlock(True);
      try
        ExecProg(ParamStr(0), Block);
      finally
        StrDispose(Block);
      end;
    end;
  end;
end;

function TSpawnDlg.BuildEnvBlock(IncludeCurrent: Boolean): PChar;
  // create a new environment block including vars listed in memo + optionally
  // a copy of current process's environment: returns pointer to env block
var
  BlockSize: Integer;   // size of env block
begin
  // get block size
  BlockSize := CreateEnvBlock(memoVars.Lines, IncludeCurrent, nil, 0);
  // create buffer for block and store environment in it
  Result := StrAlloc(BlockSize);
  CreateEnvBlock(memoVars.Lines, IncludeCurrent, Result, BlockSize);
end;

procedure TSpawnDlg.rgpBlockTypeClick(Sender: TObject);
  // enables / disables memo according to if custom env vars to be included
begin
  memoVars.Enabled := rgpBlockType.ItemIndex <> 0;
end;

end.
