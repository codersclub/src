unit tweak;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Menus, Registry;

type
  TForm1 = class(TForm)
    GroupBox1: TGroupBox;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
    CheckBox3: TCheckBox;
    CheckBox4: TCheckBox;
    CheckBox5: TCheckBox;
    CheckBox6: TCheckBox;
    GroupBox2: TGroupBox;
    CheckBox7: TCheckBox;
    CheckBox8: TCheckBox;
    CheckBox9: TCheckBox;
    CheckBox10: TCheckBox;
    CheckBox11: TCheckBox;
    CheckBox12: TCheckBox;
    CheckBox13: TCheckBox;
    MainMenu1: TMainMenu;
    N1: TMenuItem;
    N3: TMenuItem;
    N5: TMenuItem;
    procedure N5Click(Sender: TObject);
    procedure N2Click(Sender: TObject);
    procedure N3Click(Sender: TObject);
    procedure Activ(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;
  R:Tregistry;
implementation

{$R *.DFM}

procedure TForm1.N5Click(Sender: TObject);
begin
Close;
end;

procedure TForm1.N2Click(Sender: TObject);
begin
Showmessage('');
end;

procedure TForm1.N3Click(Sender: TObject);
var buf:DWord;


begin
r:=TRegistry.Create;
R.RootKey:=HKEY_LOCAL_MACHINE;
R.OpenKey('Software\Microsoft\Windows\CurrentVersion\Policies\explorer',true);

if (Checkbox3.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoLogoff',buf,sizeof(buf));

if (Checkbox12.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoDrives',buf,sizeof(buf));

if (Checkbox13.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoNetConnectDisconnect',buf,sizeof(buf));

if (Checkbox1.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoFavoritesMenu',buf,sizeof(buf));

if (Checkbox2.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoFind',buf,sizeof(buf));

if (Checkbox5.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoRun',buf,sizeof(buf));

if (Checkbox8.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoActiveDesktop',buf,sizeof(buf));

if (Checkbox4.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoRecentDocsMenu',buf,sizeof(buf));

if (Checkbox7.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('ClearRecentDocsOnExit',buf,sizeof(buf));

if (Checkbox6.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoSetFolders',buf,sizeof(buf));

r.CloseKey;
r.OpenKey('Software\Microsoft\Windows\CurrentVersion\policies\WinOldApp',true);

if (Checkbox9.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('NoRealMode',buf,sizeof(buf));

if (Checkbox10.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('Disabled',buf,sizeof(buf));

r.CloseKey;
r.OpenKey('Software\Microsoft\Windows\CurrentVersion\policies\System',true);

if (Checkbox11.Checked) then
buf:=1 else buf:=0;
R.WriteBinaryData('DisableRegistryTools',buf,sizeof(buf));

r.Free;

if MessageDlg('����� ��������� ������� � �������� ������ ����� ������������ �������.������������� ��������� ������?',
mtWarning,[mbYes,mbNo],0)=mrYes then ExitWindowsEx(EWX_REBOOT,0) else Close;

end;

procedure TForm1.Activ(Sender: TObject);
var buf:Dword;

begin
r:=TRegistry.Create;
R.RootKey:=HKEY_LOCAL_MACHINE;
r.OpenKey('Software\Microsoft\Windows\CurrentVersion\policies\System',true);

if R.ValueExists('DisableRegistryTools') then
begin
r.ReadBinaryData('DisableRegistryTools',buf,sizeof(buf));
if buf=1 then
Checkbox11.Checked:=true
else Checkbox11.Checked:=false;
end;

r.CloseKey;
r.OpenKey('Software\Microsoft\Windows\CurrentVersion\policies\WinOldApp',true);

if R.ValueExists('NoRealMode') then
begin
r.ReadBinaryData('NoRealMode',buf,sizeof(buf));
if buf=1 then
Checkbox10.Checked:=true
else Checkbox10.Checked:=false;
end;

if R.ValueExists('Disabled') then
begin
r.ReadBinaryData('Disabled',buf,sizeof(buf));
if buf=1 then
Checkbox9.Checked:=true
else Checkbox9.Checked:=false;
end;

r.CloseKey;
R.OpenKey('Software\Microsoft\Windows\CurrentVersion\Policies\explorer',true);

if R.ValueExists('NoFavoritesMenu') then
begin
r.ReadBinaryData('NoFavoritesMenu',buf,sizeof(buf));
if buf=1 then
Checkbox1.Checked:=true
else Checkbox1.Checked:=false;
end;

if R.ValueExists('NoFind') then
begin
r.ReadBinaryData('NoFind',buf,sizeof(buf));
if buf=1 then
Checkbox2.Checked:=true
else Checkbox2.Checked:=false;
end;

if R.ValueExists('NoLogoff') then
begin
r.ReadBinaryData('NoLogoff',buf,sizeof(buf));
if buf=1 then
Checkbox3.Checked:=true
else Checkbox3.Checked:=false;
end;

if R.ValueExists('NoRecentDocsMenu') then
begin
r.ReadBinaryData('NoRecentDocsMenu',buf,sizeof(buf));
if buf=1 then
Checkbox4.Checked:=true
else Checkbox4.Checked:=false;
end;

if R.ValueExists('NoRun') then
begin
r.ReadBinaryData('NoRun',buf,sizeof(buf));
if buf=1 then
Checkbox5.Checked:=true
else Checkbox5.Checked:=false;
end;

if R.ValueExists('NoSetFolders') then
begin
r.ReadBinaryData('NoSetFolders',buf,sizeof(buf));
if buf=1 then
Checkbox6.Checked:=true
else Checkbox6.Checked:=false;
end;

if R.ValueExists('ClearRecentDocsOnExit') then
begin
r.ReadBinaryData('ClearRecentDocsOnExit',buf,sizeof(buf));
if buf=1 then
Checkbox7.Checked:=true
else Checkbox7.Checked:=false;
end;

if R.ValueExists('NoActiveDesktop') then
begin
r.ReadBinaryData('NoActiveDesktop',buf,sizeof(buf));
if buf=1 then
Checkbox8.Checked:=true
else Checkbox8.Checked:=false;
end;

if R.ValueExists('NoDrives') then
begin
r.ReadBinaryData('NoDrives',buf,sizeof(buf));
if buf=1 then
Checkbox12.Checked:=true
else Checkbox12.Checked:=false;
end;

if R.ValueExists('NoNetConnectDisconnect') then
begin
r.ReadBinaryData('NoNetConnectDisconnect',buf,sizeof(buf));
if buf=1 then
Checkbox13.Checked:=true
else Checkbox13.Checked:=false;
end;

r.Free;
end;

end.
