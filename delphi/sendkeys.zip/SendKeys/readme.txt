***SendKeys Component README File***
____________________________________


I developed this component for two reasons:

- Visual Basic has it...and Delphi doesn't.

- To start developing components!

So, this is a freeware component. If you want the source
you'll have to pay $5.00. This is a symbolic price, which really
means "You have to make a little effort if you want the source".

I'll explain how the component works now:

PROPERTIES

WindowHandle
____________
	
The handle of the window you want to send the keystrokes
to. If you don't know it (or don't even know what this is) don't worry:
Scroll down a bit, and you'll see a function that provides you this
handle if you've got (at least) part of the title of the window.


FUNCTIONS AND PROCEDURES


GetWindowHandle
_______________

Use this function to get the Handle of the Window you want to send
the keystrokes to. You won't need it if you already know its handle.
In case you don't, use it by sending (at least) part of its title.

The return value of this function is 0 if the window was not found,
or 1 if the Window was found.

If the return value is 1, TSendKeys property WindowHandle is 
automatically set to the Handle of the window which will receive the
keystrokes.

SendKeys
________

This is it! the Procedure we've all been waiting for. Use it by sending
the string you want to send to the other application.

Note: You cannot send specific symbols, that normally have to do with
the specific country you're in.

Note2: The SendKeys method brings the window that receives the keystrokes
to the foreground. If you don't want this, simply put you app back
to the background (eg. SetForegroundWindow(Form1.Handle)).


That's all folks!

my email is
gardete@mail.telepac.pt