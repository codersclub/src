object Form_Main: TForm_Main
  Left = 268
  Top = 180
  Width = 395
  Height = 355
  Caption = 'Learn Sockets'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object pcLearnSockets: TPageControl
    Left = 0
    Top = 0
    Width = 381
    Height = 322
    ActivePage = tsServer
    Anchors = [akLeft, akTop, akRight, akBottom]
    TabOrder = 0
    object tsServer: TTabSheet
      Caption = 'Server'
      ImageIndex = 1
      object gbServerSettings: TGroupBox
        Left = 0
        Top = 0
        Width = 161
        Height = 293
        Anchors = [akLeft, akTop, akBottom]
        Caption = 'Server Settings'
        TabOrder = 0
        object lblServerPort: TLabel
          Left = 4
          Top = 44
          Width = 19
          Height = 13
          Caption = 'Port'
        end
        object Label2: TLabel
          Left = 36
          Top = 44
          Width = 36
          Height = 13
          Caption = 'Service'
        end
        object lblServerThreadCacheSize: TLabel
          Left = 4
          Top = 80
          Width = 91
          Height = 13
          Caption = 'Thread Cache Size'
        end
        object btnSeverOpen: TButton
          Left = 4
          Top = 16
          Width = 75
          Height = 25
          Caption = 'Open'
          TabOrder = 0
          OnClick = btnSeverOpenClick
        end
        object btnServerClose: TButton
          Left = 80
          Top = 16
          Width = 75
          Height = 25
          Caption = 'Close'
          TabOrder = 1
          OnClick = btnServerCloseClick
        end
        object edServerPort: TEdit
          Left = 4
          Top = 56
          Width = 29
          Height = 21
          TabOrder = 2
          Text = '90'
        end
        object edServerService: TEdit
          Left = 36
          Top = 56
          Width = 121
          Height = 21
          TabOrder = 3
        end
        object edServerThreadCacheSize: TEdit
          Left = 100
          Top = 80
          Width = 33
          Height = 21
          TabOrder = 4
          Text = '10'
        end
        object gbServerSocketType: TGroupBox
          Left = 4
          Top = 104
          Width = 153
          Height = 57
          Caption = 'Server Type'
          TabOrder = 5
          object rbtnServerNonBlocking: TRadioButton
            Left = 4
            Top = 16
            Width = 89
            Height = 17
            Caption = 'Non-Blocking'
            Checked = True
            TabOrder = 0
            TabStop = True
          end
          object rdbtnServerThreadBlocking: TRadioButton
            Left = 4
            Top = 36
            Width = 101
            Height = 17
            Caption = 'Thread Blocking'
            TabOrder = 1
          end
        end
        object gbUserDefinedServerSettings: TGroupBox
          Left = 4
          Top = 164
          Width = 153
          Height = 123
          Anchors = [akLeft, akTop, akBottom]
          Caption = 'User Defined Server Settings'
          TabOrder = 6
        end
      end
      object lstServerActivity: TListBox
        Left = 164
        Top = 4
        Width = 207
        Height = 261
        Anchors = [akLeft, akTop, akRight, akBottom]
        ItemHeight = 13
        TabOrder = 1
      end
      object btnClearServerSocketLog: TButton
        Left = 164
        Top = 268
        Width = 207
        Height = 25
        Anchors = [akLeft, akRight, akBottom]
        Caption = 'Clear Log'
        TabOrder = 2
        OnClick = btnClearServerSocketLogClick
      end
    end
    object tsClient: TTabSheet
      Caption = 'Client'
      ImageIndex = 2
      object gbBasicClientSettings: TGroupBox
        Left = 0
        Top = 0
        Width = 161
        Height = 292
        Anchors = [akLeft, akTop, akBottom]
        Caption = 'Client Settings'
        TabOrder = 0
        object btnClientClose: TButton
          Left = 80
          Top = 16
          Width = 75
          Height = 25
          Caption = 'Close'
          TabOrder = 0
          OnClick = btnClientCloseClick
        end
        object btnClientOpen: TButton
          Left = 4
          Top = 16
          Width = 75
          Height = 25
          Caption = 'Open'
          TabOrder = 1
          OnClick = btnClientOpenClick
        end
        object gbConnectionAddressOrHost: TGroupBox
          Left = 4
          Top = 128
          Width = 149
          Height = 97
          Caption = 'Connection Address or Host'
          TabOrder = 2
          object rbtnConnectionAddress: TRadioButton
            Left = 4
            Top = 16
            Width = 121
            Height = 17
            Caption = 'Connection Address'
            Checked = True
            TabOrder = 3
            TabStop = True
          end
          object rbtnConnectionHost: TRadioButton
            Left = 4
            Top = 56
            Width = 105
            Height = 17
            Caption = 'Connection Host'
            TabOrder = 2
          end
          object edConnectionAddress: TEdit
            Left = 4
            Top = 32
            Width = 141
            Height = 21
            TabOrder = 0
            Text = '192.168.0.1'
          end
          object edConnectionHost: TEdit
            Left = 4
            Top = 72
            Width = 141
            Height = 21
            TabOrder = 1
          end
        end
        object gbConnectionportOrService: TGroupBox
          Left = 4
          Top = 44
          Width = 149
          Height = 81
          Caption = 'Connection Port or Service'
          TabOrder = 3
          object rbtnConnectionService: TRadioButton
            Left = 4
            Top = 40
            Width = 113
            Height = 17
            Caption = 'Connection Service'
            TabOrder = 3
          end
          object edConnectionPort: TEdit
            Left = 108
            Top = 16
            Width = 37
            Height = 21
            BiDiMode = bdLeftToRight
            ParentBiDiMode = False
            TabOrder = 0
            Text = '90'
          end
          object edConnectionService: TEdit
            Left = 4
            Top = 56
            Width = 141
            Height = 21
            TabOrder = 1
          end
          object rbtnConnectionPort: TRadioButton
            Left = 4
            Top = 16
            Width = 101
            Height = 21
            Caption = 'Connection Port'
            Checked = True
            TabOrder = 2
            TabStop = True
          end
        end
        object gbClientType: TGroupBox
          Left = 4
          Top = 228
          Width = 149
          Height = 57
          Caption = 'Client Type'
          TabOrder = 4
          object rbtnClientNonBlocking: TRadioButton
            Left = 4
            Top = 16
            Width = 89
            Height = 17
            Caption = 'Non-Blocking'
            Checked = True
            TabOrder = 0
            TabStop = True
          end
          object rbtnClientThreadBlocking: TRadioButton
            Left = 4
            Top = 36
            Width = 101
            Height = 17
            Caption = 'Thread Blocking'
            TabOrder = 1
          end
        end
      end
      object lstClientActivity: TListBox
        Left = 164
        Top = 4
        Width = 207
        Height = 261
        Anchors = [akLeft, akTop, akRight, akBottom]
        ItemHeight = 13
        TabOrder = 1
      end
      object btnClearClientSocketLog: TButton
        Left = 164
        Top = 268
        Width = 207
        Height = 25
        Anchors = [akLeft, akRight, akBottom]
        Caption = 'Clear Log'
        TabOrder = 2
        OnClick = btnClearClientSocketLogClick
      end
    end
    object tsTextChat: TTabSheet
      Caption = 'Text Chat'
      ImageIndex = 3
      object memReceive: TMemo
        Left = 0
        Top = 0
        Width = 368
        Height = 196
        Anchors = [akLeft, akTop, akRight, akBottom]
        Color = clMenu
        Enabled = False
        TabOrder = 0
      end
      object memSend: TMemo
        Left = 0
        Top = 200
        Width = 295
        Height = 93
        Anchors = [akLeft, akRight, akBottom]
        TabOrder = 1
      end
      object btnSend: TButton
        Left = 298
        Top = 268
        Width = 75
        Height = 25
        Anchors = [akRight, akBottom]
        Caption = 'Send'
        TabOrder = 2
        OnClick = btnSendClick
      end
    end
  end
  object ServerSocket1: TServerSocket
    Active = False
    Port = 1024
    ServerType = stNonBlocking
    OnListen = ServerSocket1Listen
    OnAccept = ServerSocket1Accept
    OnGetThread = ServerSocket1GetThread
    OnGetSocket = ServerSocket1GetSocket
    OnThreadStart = ServerSocket1ThreadStart
    OnThreadEnd = ServerSocket1ThreadEnd
    OnClientConnect = ServerSocket1ClientConnect
    OnClientDisconnect = ServerSocket1ClientDisconnect
    OnClientRead = ServerSocket1ClientRead
    OnClientWrite = ServerSocket1ClientWrite
    OnClientError = ServerSocket1ClientError
    Left = 500
    Top = 28
  end
  object ClientSocket1: TClientSocket
    Active = False
    ClientType = ctNonBlocking
    Port = 1024
    OnLookup = ClientSocket1Lookup
    OnConnecting = ClientSocket1Connecting
    OnConnect = ClientSocket1Connect
    OnDisconnect = ClientSocket1Disconnect
    OnRead = ClientSocket1Read
    OnWrite = ClientSocket1Write
    OnError = ClientSocket1Error
    Left = 500
    Top = 76
  end
end
