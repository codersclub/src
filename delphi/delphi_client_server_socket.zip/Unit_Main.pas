unit Unit_Main;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ScktComp, Grids, ComCtrls, StdCtrls;

type
  TForm_Main = class(TForm)
    pcLearnSockets: TPageControl;
    tsServer: TTabSheet;
    tsClient: TTabSheet;
    ServerSocket1: TServerSocket;
    ClientSocket1: TClientSocket;
    gbServerSettings: TGroupBox;
    btnSeverOpen: TButton;
    btnServerClose: TButton;
    lblServerPort: TLabel;
    edServerPort: TEdit;
    edServerService: TEdit;
    Label2: TLabel;
    edServerThreadCacheSize: TEdit;
    lblServerThreadCacheSize: TLabel;
    gbBasicClientSettings: TGroupBox;
    btnClientClose: TButton;
    btnClientOpen: TButton;
    gbConnectionAddressOrHost: TGroupBox;
    gbConnectionportOrService: TGroupBox;
    edConnectionPort: TEdit;
    edConnectionService: TEdit;
    rbtnConnectionPort: TRadioButton;
    rbtnConnectionService: TRadioButton;
    edConnectionAddress: TEdit;
    edConnectionHost: TEdit;
    rbtnConnectionHost: TRadioButton;
    rbtnConnectionAddress: TRadioButton;
    lstServerActivity: TListBox;
    btnClearServerSocketLog: TButton;
    gbServerSocketType: TGroupBox;
    rbtnServerNonBlocking: TRadioButton;
    rdbtnServerThreadBlocking: TRadioButton;
    gbClientType: TGroupBox;
    rbtnClientNonBlocking: TRadioButton;
    rbtnClientThreadBlocking: TRadioButton;
    lstClientActivity: TListBox;
    btnClearClientSocketLog: TButton;
    tsTextChat: TTabSheet;
    memReceive: TMemo;
    memSend: TMemo;
    btnSend: TButton;
    gbUserDefinedServerSettings: TGroupBox;
    procedure btnSeverOpenClick(Sender: TObject);
    procedure btnServerCloseClick(Sender: TObject);
    procedure ServerSocket1Accept(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ClientConnect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ClientDisconnect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1Listen(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ThreadEnd(Sender: TObject;
      Thread: TServerClientThread);
    procedure ServerSocket1ThreadStart(Sender: TObject;
      Thread: TServerClientThread);
    procedure btnClientOpenClick(Sender: TObject);
    procedure btnClientCloseClick(Sender: TObject);
    procedure ServerSocket1ClientError(Sender: TObject;
      Socket: TCustomWinSocket; ErrorEvent: TErrorEvent;
      var ErrorCode: Integer);
    procedure ServerSocket1ClientRead(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1ClientWrite(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ServerSocket1GetSocket(Sender: TObject; Socket: Integer;
      var ClientSocket: TServerClientWinSocket);
    procedure ServerSocket1GetThread(Sender: TObject;
      ClientSocket: TServerClientWinSocket;
      var SocketThread: TServerClientThread);
    procedure ClientSocket1Write(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure btnClearServerSocketLogClick(Sender: TObject);
    procedure btnClearClientSocketLogClick(Sender: TObject);
    procedure ClientSocket1Connect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Connecting(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Disconnect(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Error(Sender: TObject; Socket: TCustomWinSocket;
      ErrorEvent: TErrorEvent; var ErrorCode: Integer);
    procedure ClientSocket1Lookup(Sender: TObject;
      Socket: TCustomWinSocket);
    procedure ClientSocket1Read(Sender: TObject; Socket: TCustomWinSocket);
    procedure btnSendClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form_Main: TForm_Main;

implementation

{$R *.DFM}

procedure TForm_Main.btnSeverOpenClick(Sender: TObject);
begin
  ServerSocket1.ThreadCacheSize := StrToInt(edServerThreadCacheSize.Text);
  ServerSocket1.Port := StrToInt(edServerPort.Text);
  if (rbtnServerNonBlocking.Checked) then
    ServerSocket1.ServerType := stNonBlocking;
  if (rdbtnServerThreadBlocking.Checked) then
    ServerSocket1.ServerType := stThreadBlocking;

  lstServerActivity.Items.Add('Server: Opening...');
  ServerSocket1.Open;
  lstServerActivity.Items.Add('Server: Open');

  lstServerActivity.Items.Add('Local Host: ' + ServerSocket1.Socket.LocalHost);
  lstServerActivity.Items.Add('Local Address: ' + ServerSocket1.Socket.LocalAddress);
  lstServerActivity.Items.Add('Local Port: ' + IntToStr(ServerSocket1.Socket.LocalPort));
end;

procedure TForm_Main.btnServerCloseClick(Sender: TObject);
begin
  lstServerActivity.Items.Add('Server: Closing...');
  ServerSocket1.Close;
  lstServerActivity.Items.Add('Server: Closed');
end;

procedure TForm_Main.ServerSocket1Accept(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Accepting Connection...');
  //DoSomething
  lstServerActivity.Items.Add('Server: Accepted Connection');
end;

procedure TForm_Main.ServerSocket1ClientConnect(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Client Connecting...');
  //DoSomething
  lstServerActivity.Items.Add('Server: Client Connected');
end;

procedure TForm_Main.ServerSocket1ClientDisconnect(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Client Disconnecting...');
  //DoSomething
  lstServerActivity.Items.Add('Server: Client Disconnected');
end;

procedure TForm_Main.ServerSocket1ClientError(Sender: TObject; Socket: TCustomWinSocket; ErrorEvent: TErrorEvent;
  var ErrorCode: Integer);
begin
  ShowMessage('Server: Client Error');
end;

procedure TForm_Main.ServerSocket1ClientRead(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Client Read');
  memReceive.Text := memReceive.Text + char(13) + char(10) + Socket.ReceiveText;
end;

procedure TForm_Main.ServerSocket1ClientWrite(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Client Write');
end;

procedure TForm_Main.ServerSocket1GetSocket(Sender: TObject; Socket: Integer; var ClientSocket: TServerClientWinSocket);
begin
  lstServerActivity.Items.Add('Server: Get Socket');
end;

procedure TForm_Main.ServerSocket1GetThread(Sender: TObject; ClientSocket: TServerClientWinSocket; var SocketThread: TServerClientThread);
begin
  lstServerActivity.Items.Add('Server: Get Thread');
end;

procedure TForm_Main.ServerSocket1Listen(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstServerActivity.Items.Add('Server: Listening...');


  lstClientActivity.Items.Add('Local Host: ' + ClientSocket1.Socket.LocalHost);
  lstClientActivity.Items.Add('Local Address: ' + ClientSocket1.Socket.LocalAddress);
  lstClientActivity.Items.Add('Local Port: ' + IntToStr(ClientSocket1.Socket.LocalPort));
end;

procedure TForm_Main.ServerSocket1ThreadEnd(Sender: TObject;
  Thread: TServerClientThread);
begin
  ShowMessage('Server: Thread Ending');
end;

procedure TForm_Main.ServerSocket1ThreadStart(Sender: TObject;
  Thread: TServerClientThread);
begin
  ShowMessage('Server: Thread Starting');
end;





// Client Socket Procedures and Functions

procedure TForm_Main.btnClientOpenClick(Sender: TObject);
begin
  //Set Connection Port or Service
  if (rbtnConnectionPort.Checked) then
    ClientSocket1.Port := StrToInt(edConnectionPort.Text)
  else if (rbtnConnectionService.Checked) then
    ClientSocket1.Service := edConnectionPort.Text;
  //Set Connection Address or Host
  if (rbtnConnectionAddress.Checked) then
    ClientSocket1.Address := edConnectionAddress.Text
  else if (rbtnConnectionHost.Checked) then
    ClientSocket1.Host := edConnectionHost.Text;
  //Set Client Connection Type
  if (rbtnServerNonBlocking.Checked) then
    ServerSocket1.ServerType := stNonBlocking;
  if (rdbtnServerThreadBlocking.Checked) then
    ServerSocket1.ServerType := stThreadBlocking;
  //Open Connection
  lstClientActivity.Items.Add('Client: Opening...');
  ClientSocket1.Open;
  lstClientActivity.Items.Add('Client: Open');

  lstClientActivity.Items.Add('Local Host: ' + ClientSocket1.Socket.LocalHost);
  lstClientActivity.Items.Add('Local Address: ' + ClientSocket1.Socket.LocalAddress);
  lstClientActivity.Items.Add('Local Port: ' + IntToStr(ClientSocket1.Socket.LocalPort));
end;

procedure TForm_Main.btnClientCloseClick(Sender: TObject);
begin
  lstClientActivity.Items.Add('Client: Closing...');
  ClientSocket1.Close;
  lstClientActivity.Items.Add('Client: Closed');
end;

procedure TForm_Main.ClientSocket1Connect(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Connected');
end;

procedure TForm_Main.ClientSocket1Connecting(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Connecting...');
end;

procedure TForm_Main.ClientSocket1Disconnect(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Disconnecting...');
  //DoSomething
  lstClientActivity.Items.Add('Client: Disconnected');
end;

procedure TForm_Main.ClientSocket1Error(Sender: TObject; Socket: TCustomWinSocket; ErrorEvent: TErrorEvent; var ErrorCode: Integer);
begin
  lstClientActivity.Items.Add('Client: Error');
end;

procedure TForm_Main.ClientSocket1Lookup(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Lookup');
end;

procedure TForm_Main.ClientSocket1Read(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Read');
  memReceive.Text := memReceive.Text + char(13) + char(10) + Socket.ReceiveText;
end;

procedure TForm_Main.ClientSocket1Write(Sender: TObject; Socket: TCustomWinSocket);
begin
  lstClientActivity.Items.Add('Client: Write');
end;

//Other

procedure TForm_Main.btnClearServerSocketLogClick(Sender: TObject);
begin
  lstServerActivity.Items.Clear;
end;

procedure TForm_Main.btnClearClientSocketLogClick(Sender: TObject);
begin
  lstClientActivity.Items.Clear;
end;

procedure TForm_Main.btnSendClick(Sender: TObject);
begin
  if (ServerSocket1.Active) then
    ServerSocket1.Socket.Connections[0].SendText(memSend.Text)
  else if (ClientSocket1.Active) then
    ClientSocket1.Socket.SendText(memSend.Text);
end;

end.
