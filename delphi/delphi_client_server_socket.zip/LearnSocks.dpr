program LearnSocks;

uses
  Forms,
  Unit_Main in 'Unit_Main.pas' {Form_Main};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'Learn Sockets';
  Application.CreateForm(TForm_Main, Form_Main);
  Application.Run;
end.
