object frMain: TfrMain
  Left = 198
  Top = 139
  Width = 232
  Height = 118
  Caption = 'frMain'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 8
    Top = 20
    Width = 36
    Height = 13
    Caption = 'Stick at'
  end
  object edStickAt: TEdit
    Left = 8
    Top = 36
    Width = 65
    Height = 21
    TabOrder = 0
    Text = '20'
    OnKeyPress = edStickAtKeyPress
  end
  object chkTop: TCheckBox
    Left = 116
    Top = 12
    Width = 61
    Height = 17
    Caption = 'chkTop'
    Checked = True
    State = cbChecked
    TabOrder = 1
  end
  object chkBottom: TCheckBox
    Left = 116
    Top = 64
    Width = 73
    Height = 17
    Caption = 'chkBottom'
    Checked = True
    State = cbChecked
    TabOrder = 2
  end
  object chkRight: TCheckBox
    Left = 148
    Top = 36
    Width = 65
    Height = 17
    Caption = 'chkRight'
    Checked = True
    State = cbChecked
    TabOrder = 3
  end
  object chkLeft: TCheckBox
    Left = 84
    Top = 36
    Width = 61
    Height = 17
    Caption = 'chkLeft'
    Checked = True
    State = cbChecked
    TabOrder = 4
  end
end
