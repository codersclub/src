program Project1;

uses
  Forms,
  Unit1 in 'Unit1.pas' {frMain};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TfrMain, frMain);
  Application.Run;
end.
