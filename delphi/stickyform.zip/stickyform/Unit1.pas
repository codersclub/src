{
Article:

Sticky Windows
http://delphi.about.com/library/weekly/aa070301a.htm
This article shows how to dock your Delphi forms to 
the edges of your desktop screen.


********************************************
Zarko Gajic, BSCS
About Guide to Delphi Programming
http://delphi.about.com
email: delphi.guide@about.com
free newsletter: http://delphi.about.com/library/blnewsletter.htm
forum: http://forums.about.com/ab-delphi/start/
advertising: http://delphi.about.com/library/bladvertise.htm
********************************************
}

unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TfrMain = class(TForm)
    edStickAt: TEdit;
    Label1: TLabel;
    chkTop: TCheckBox;
    chkBottom: TCheckBox;
    chkRight: TCheckBox;
    chkLeft: TCheckBox;
    procedure edStickAtKeyPress(Sender: TObject; var Key: Char);
  private
   procedure WMWINDOWPOSCHANGING (Var Msg: TWMWINDOWPOSCHANGING); message WM_WINDOWPOSCHANGING;
  public
    { Public declarations }
  end;

var
  frMain: TfrMain;

implementation
{$R *.DFM}


procedure TfrMain.WMWINDOWPOSCHANGING (var Msg: TWMWINDOWPOSCHANGING);
const
  Docked: Boolean = FALSE;
var
  rWorkArea: TRect;
  StickAt : Word;
begin
  StickAt := StrToInt(edStickAt.Text);

  SystemParametersInfo (SPI_GETWORKAREA, 0, @rWorkArea, 0);

  with Msg.WindowPos^ do begin
    if chkLeft.Checked then
     if x <= rWorkArea.Left + StickAt then begin
      x := rWorkArea.Left;
      Docked := TRUE;
     end;

    if chkRight.Checked then
     if x + cx >= rWorkArea.Right - StickAt then begin
      x := rWorkArea.Right - cx;
      Docked := TRUE;
     end;

    if chkTop.Checked then
     if y <= rWorkArea.Top + StickAt then begin
      y := rWorkArea.Top;
      Docked := TRUE;
     end;

    if chkBottom.Checked then
     if y + cy >= rWorkArea.Bottom - StickAt then begin
      y := rWorkArea.Bottom - cy;
      Docked := TRUE;
     end;

    if Docked then begin
      with rWorkArea do begin
      // no moving out of the screen
      if x < Left then x := Left;
      if x + cx > Right then x := Right - cx;
      if y < Top then y := Top;
      if y + cy > Bottom then y := Bottom - cy;
      end; {with rWorkArea}
    end; {if Docked}
  end; {with  Msg.WindowPos^}

  inherited;
end;

procedure TfrMain.edStickAtKeyPress(Sender: TObject; var Key: Char);
begin
 if not (key in ['0'..'9']) then Abort;
end;

end.
