unit uWatcherInterface;

interface

type
  TWatchTo = (wtFilenameChange,wtDirNameChange,wtAttributesChange,
              wtFilesizeChange,wtLastwriteChange,wtSecurityChange);

implementation

end.
