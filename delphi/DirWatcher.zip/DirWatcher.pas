//////////////////////////////////////////////////////////////////////////////
//Component Name:        TDirWatcher
//Version:               1.0
//Platform:              Delphi 2 & 3
//Sources:               for FREE (just mail me)
//Example:               included
//Documentation:         You read it :)
//Author:                Bernhard Angerer
//Organization:          University of Technology Vienna
//Contact E-mail:        angerer@mail.ift.tuwien.ac.at
//Description:           This is a Thread-component sends an event when a change in the
//                       file system occurs
//Improvements(future)   -DirToWatch property: check if dir is exsisting
//                       -New WatchSubTree property
//                       -OnChange event: parameter that shows the changings
//////////////////////////////////////////////////////////////////////////////
unit DirWatcher;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  uWatcherInterface,
  uWatcherThread;

type
  TDirWatcher = class(TComponent)
  private
    FActive: boolean;
    FDirToWatch: string;
    WatcherThread: TWatcherThread;
    FOnChange: TNotifyEvent;
    FWatchTo: TWatchTo;

  protected
    procedure SetDirToWatch(aValue: string);
    procedure SetActive(aBool: boolean);
    procedure SetWatchTo(aValue: TWatchTo);
  public
    procedure NotifyEvent;
    constructor Create(aOwner: TComponent); override;
    // Active does not work when it is published ??
    property Active: boolean read FActive write SetActive default false;
  published
    property DirToWatch: string read FDirToWatch write SetDirToWatch;
    property WatchTo: TWatchTo read FWatchTo write SetWatchTo default wtFilenameChange;
    // Events
    property OnChange: TNotifyEvent read FOnChange write FOnChange;
  end;

procedure Register;

implementation

procedure TDirWatcher.SetDirToWatch(aValue: string);
begin
  if WatcherThread <> NIL then WatcherThread.Terminate;
  FActive := false;
  FDirToWatch := aValue;
end;

procedure TDirWatcher.SetActive(aBool: boolean);
begin
  if aBool = FActive then
    EXIT;
  if aBool then
  begin
    if WatcherThread <> NIL then WatcherThread.Terminate;
    WatcherThread := TWatcherThread.Create(Self,FDirToWatch,FWatchTo);
  end
  else
    if WatcherThread <> NIL then WatcherThread.Terminate;

  FActive := aBool;
end;

procedure TDirWatcher.SetWatchTo(aValue: TWatchTo);
begin
  if WatcherThread <> NIL then WatcherThread.Terminate;
  FWatchTo := aValue;
end;

procedure TDirWatcher.NotifyEvent;
begin
  if Assigned(OnChange) then OnChange(Self);
end;

constructor TDirWatcher.Create(aOwner: TComponent);
begin
  inherited;
  DirToWatch := 'C:\TEMP';  // actual dir would be better - but how ?
end;

procedure Register;
begin
  RegisterComponents('Additional', [TDirWatcher]);
end;

end.
