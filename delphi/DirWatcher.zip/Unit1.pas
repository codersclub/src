unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, DirWatcher;

type
  TForm1 = class(TForm)
    Button1: TButton;
    Button2: TButton;
    StaticText1: TStaticText;
    DirWatcher1: TDirWatcher;
    Edit1: TEdit;
    Button3: TButton;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure DirWatcher1Change(Sender: TObject);
    procedure Button3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.DFM}

procedure TForm1.Button1Click(Sender: TObject);
begin
  DirWatcher1.Active := true;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
  StaticText1.Caption := 'cleared label';
end;

procedure TForm1.DirWatcher1Change(Sender: TObject);
begin
  StaticText1.Caption := 'ChangeNotifyEvent';
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  DirWatcher1.DirToWatch := Edit1.Text;
end;

end.
