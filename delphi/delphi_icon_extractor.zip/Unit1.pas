unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, Spin;

type
  TFrmMain = class(TForm)
    Img: TImage;
    GroupBox1: TGroupBox;
    Label3: TLabel;
    Label2: TLabel;
    TxtFile: TEdit;
    TxtIndex: TEdit;
    CmdShow: TButton;
    Label1: TLabel;
    ChkTrans: TCheckBox;
    procedure CmdShowClick(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure TxtFileChange(Sender: TObject);
    procedure TxtIndexChange(Sender: TObject);
    procedure ChkTransClick(Sender: TObject);
    procedure FormHide(Sender: TObject);
  private
    { Private declarations }
  public

    { Public declarations }
  end;

var
  FrmMain: TFrmMain;
 Function ExtractIcon(hInst : LongInt; lpszExeFileName :String;nIconIndex : LongInt): LongInt;
 stdcall; external 'shell32.dll' name 'ExtractIconA';
 Function DestroyIcon (hIcon : Longint) : Longint;
 StdCall; external 'user32';
 implementation

{$R *.DFM}

procedure TFrmMain.CmdShowClick(Sender: TObject);
Var iHwnd : LongInt;
begin

img.picture:=nil;
iHwnd:=extracticon(frmmain.Handle,txtfile.text,strtoint(TxtIndex.text));
if ihwnd=0 then
application.messagebox('Index Not Valid.','No Icon Found',MB_ICONINFORMATION);
drawicon(img.Canvas.Handle ,0,0,ihwnd);
img.Refresh ;
img.repaint;
destroyicon(ihwnd);
end;

procedure TFrmMain.FormCreate(Sender: TObject);
begin
TxtFile.text:=application.GetNamePath + application.ExeName;
TxtFile.text:=lowercase(string(txtfile.text));
end;
procedure TFrmMain.TxtFileChange(Sender: TObject);
begin
img.picture:=nil;
end;

procedure TFrmMain.TxtIndexChange(Sender: TObject);
begin
img.picture:=nil;
end;

procedure TFrmMain.ChkTransClick(Sender: TObject);
begin
img.transparent:=ChkTrans.checked;
end;

procedure TFrmMain.FormHide(Sender: TObject);
begin
application.messagebox('Coded by Andrea Fontana'+chr(13)+
'HomePage: www.andreafontana.com'+chr(13)+'Mail: andreafontana@mail.com','Informations!',MB_ICONINFORMATION);

end;

end.
