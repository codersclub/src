program Project1;

uses
  Forms,
  Unit1 in 'Unit1.pas' {FrmMain};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'Icon Extractor';
  Application.CreateForm(TFrmMain, FrmMain);
  Application.Run;
end.
