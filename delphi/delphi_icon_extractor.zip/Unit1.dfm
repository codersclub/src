object FrmMain: TFrmMain
  Left = 204
  Top = 140
  BorderIcons = [biSystemMenu, biMinimize]
  BorderStyle = bsSingle
  Caption = 'Icon Extractor'
  ClientHeight = 145
  ClientWidth = 211
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnCreate = FormCreate
  OnHide = FormHide
  PixelsPerInch = 96
  TextHeight = 13
  object Img: TImage
    Left = 168
    Top = 108
    Width = 32
    Height = 32
    Transparent = True
  end
  object Label1: TLabel
    Left = 128
    Top = 117
    Width = 30
    Height = 13
    Caption = 'Icon:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = []
    ParentFont = False
  end
  object GroupBox1: TGroupBox
    Left = 8
    Top = 8
    Width = 193
    Height = 97
    Caption = 'Options: '
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Verdana'
    Font.Style = []
    ParentFont = False
    TabOrder = 0
    object Label3: TLabel
      Left = 8
      Top = 23
      Width = 24
      Height = 13
      Caption = 'File:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Verdana'
      Font.Style = []
      ParentFont = False
    end
    object Label2: TLabel
      Left = 8
      Top = 48
      Width = 67
      Height = 13
      Caption = 'Icon Index:'
      Font.Charset = DEFAULT_CHARSET
      Font.Color = clWindowText
      Font.Height = -11
      Font.Name = 'Verdana'
      Font.Style = []
      ParentFont = False
    end
    object TxtFile: TEdit
      Left = 40
      Top = 23
      Width = 145
      Height = 21
      BorderStyle = bsNone
      Color = clMenu
      Font.Charset = ANSI_CHARSET
      Font.Color = clActiveCaption
      Font.Height = -11
      Font.Name = 'Arial'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 0
      Text = 'TXT'
      OnChange = TxtFileChange
    end
    object TxtIndex: TEdit
      Left = 80
      Top = 48
      Width = 33
      Height = 11
      BorderStyle = bsNone
      Color = clMenu
      Font.Charset = ANSI_CHARSET
      Font.Color = clActiveCaption
      Font.Height = -11
      Font.Name = 'Arial'
      Font.Style = [fsBold]
      ParentFont = False
      TabOrder = 1
      Text = '0'
      OnChange = TxtIndexChange
    end
    object ChkTrans: TCheckBox
      Left = 8
      Top = 72
      Width = 177
      Height = 17
      Caption = 'Transparent BackGround'
      Checked = True
      State = cbChecked
      TabOrder = 2
      OnClick = ChkTransClick
    end
  end
  object CmdShow: TButton
    Left = 8
    Top = 112
    Width = 73
    Height = 25
    Caption = 'Show Icon'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'Arial'
    Font.Style = [fsBold]
    ParentFont = False
    TabOrder = 1
    OnClick = CmdShowClick
  end
end
