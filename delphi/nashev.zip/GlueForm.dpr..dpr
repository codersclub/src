program GlueForm;

uses
  Forms,
  uCustomGlueForm in 'uCustomGlueForm.pas' {CustomGlueForm},
  uGlueForm3 in 'uGlueForm3.pas' {GlueForm3},
  uGlueForm1 in 'uGlueForm1.pas' {GlueForm1},
  uGlueForm2 in 'uGlueForm2.pas' {GlueForm2};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TGlueForm1, GlueForm1);
  Application.CreateForm(TGlueForm2, GlueForm2);
  Application.CreateForm(TGlueForm3, GlueForm3);
  Application.Run;
end.
