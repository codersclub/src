unit uCustomGlueForm;
interface
uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls;

type
  TCustomGlueForm = class(TForm)
  private
    DockedTo:TCustomGlueForm; // � ���� �����������
    Delta:TPoint; // ��������� ������������� ����� DockedTo;
    CanUndock:boolean;
    MovingLeft,MovingRight,MovingTop,MovingBottom:Boolean;
    procedure WMWindowPosChanged(var Msg: TWMWindowPosChanged);message WM_WINDOWPOSCHANGED;
    procedure WMWindowPosChanging(var Msg: TWMWindowPosChanging);message WM_WINDOWPOSCHANGING;
    procedure WMMoving(var Msg: TMessage);message WM_Moving;
    procedure WMSizing(var Msg: TMessage);message WM_Sizing;
    procedure DecryptSizingParam(Param:Integer);
  public
    constructor Create(AOwner: TComponent); override;
  end;
var
  StickAt :Word = 10;

implementation
{$R *.DFM}

constructor TCustomGlueForm.Create(AOwner: TComponent);
begin
  inherited;
  DockedTo:=nil;
  CanUndock:=True;
end;

procedure TCustomGlueForm.DecryptSizingParam(Param: Integer);
begin
  MovingLeft  :=Param in [WMSZ_LEFT,   WMSZ_TOPLEFT,    WMSZ_BOTTOMLEFT,  WMSZ_BOTTOMRIGHT or WMSZ_LEFT];
  MovingRight :=Param in [WMSZ_RIGHT,  WMSZ_TOPRIGHT,   WMSZ_BOTTOMRIGHT, WMSZ_BOTTOMRIGHT or WMSZ_LEFT];
  MovingTop   :=Param in [WMSZ_TOP,    WMSZ_TOPLEFT,    WMSZ_TOPRIGHT,    WMSZ_BOTTOMRIGHT or WMSZ_LEFT];
  MovingBottom:=Param in [WMSZ_BOTTOM, WMSZ_BOTTOMLEFT, WMSZ_BOTTOMRIGHT, WMSZ_BOTTOMRIGHT or WMSZ_LEFT];
end;

procedure TCustomGlueForm.WMMoving(var Msg: TMessage);
begin
  DecryptSizingParam(Msg.WParam);
end;

procedure TCustomGlueForm.WMSizing(var Msg: TMessage);
begin
  DecryptSizingParam(Msg.WParam);
end;

procedure TCustomGlueForm.WMWindowPosChanged(var Msg: TWMWindowPosChanged);
var
  i:Integer;
  c:TComponent;
  gf:TCustomGlueForm;
begin
  with Msg.WindowPos^ do begin
    if (x+y=0) then Exit;
    for i:=0 to Application.ComponentCount-1 do begin
      c:=Application.Components[i];
      if c is TCustomGlueForm
        then gf:=c as TCustomGlueForm
        else Continue;
      with gf do begin
        if gf=Self then Continue;
        if gf.DockedTo=Self then begin
          CanUndock:=False;
          SetBounds(x+gf.Delta.x, y+gf.Delta.y, Width, Height);
          CanUndock:=True;
        end;
      end;
    end;
  end;
  inherited;
end;

procedure TCustomGlueForm.WMWindowPosChanging (var Msg: TWMWindowPosChanged);
var
  WorkArea: TRect;
  i:Integer;
  DockedByX,DockedByY:boolean;
  NewDockedTo:TCustomGlueForm;
  c:TComponent;
  gf:TCustomGlueForm;
begin
  if not CanUndock then Exit;
  with WorkArea, Msg.WindowPos^ do begin
    if (x*y=0) then Exit;

    NewDockedTo:=nil;
    SystemParametersInfo(SPI_GETWORKAREA, 0, @WorkArea, 0);
    // �������� ������� ��� ��������� � ����� � ������� ���������
    Right:=Right-cx;
    Bottom:=Bottom-cy;
    if abs(Left   - x) <= StickAt then x := Left;
    if abs(Right  - x) <= StickAt then x := Right;
    if abs(Top    - y) <= StickAt then y := Top;
    if abs(Bottom - y) <= StickAt then y := Bottom;

    // ���� ������...
    for i:=0 to Application.ComponentCount-1 do begin
      c:=Application.Components[i];
      if c=Self then Continue;
      if c is TCustomGlueForm then gf:=c as TCustomGlueForm else Continue;
      if gf.DockedTo=Self then Continue;

      WorkArea:=gf.BoundsRect;
      DockedByX:=False;
      DockedByY:=False;

      if (y+cy>Top) and (y<Bottom) then begin
        if MovingRight and (abs(Left-cx- x) <= StickAt)then begin
          if not MovingLeft then cx := Left-x;
          x := Left-cx;
          DockedByY:=True;
        end;
        if MovingLeft and (abs(Right  - x) <= StickAt) then begin
          if not MovingRight then cx := x-Right+cx;
          x := Right;
          DockedByY:=True;
        end;
        if DockedByY then begin
          if MovingTop    and (abs(Bottom-cy - y) <= StickAt) then y := Bottom-cy;
          if MovingBottom and (abs(Top       - y) <= StickAt) then y := Top;
        end;
      end;

      if (x+cx>Left) and (x<Right) then begin
        if MovingBottom and (abs(Top    - y-cy) <= StickAt) then begin
          if not MovingTop then cy := Top-y;
          y := Top-cy;
          DockedByX:=True;
        end;
        if MovingTop and (abs(Bottom - y   ) <= StickAt) then begin
          if not MovingBottom then cy := y-Bottom+cy;
          y := Bottom;
          DockedByX:=True;
        end;
        if DockedByX then begin
          if MovingLeft and (abs(Left  - x   ) <= StickAt) then x := Left;
          if MovingRight and (abs(Right - x-cx) <= StickAt) then x := Right-cx;
        end;
      end;

      if (DockedByY or DockedByX) and not Assigned(NewDockedTo) then NewDockedTo:=gf;
    end;
  end;
  if NewDockedTo<>nil then Delta:=Point(Left-NewDockedTo.Left,Top-NewDockedTo.Top);
  DockedTo:=NewDockedTo;
  inherited;
end;

end.
