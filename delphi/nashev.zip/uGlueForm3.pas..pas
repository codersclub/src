unit uGlueForm3;
interface
uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  uCustomGlueForm, StdCtrls;

type
  TGlueForm3 = class(TCustomGlueForm)
    Label1: TLabel;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  GlueForm3: TGlueForm3;

implementation

{$R *.DFM}

end.
