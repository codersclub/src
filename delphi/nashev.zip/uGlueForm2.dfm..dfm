inherited GlueForm2: TGlueForm2
  Left = 219
  Top = 535
  Width = 284
  Height = 219
  Caption = 'GlueForm2'
  OldCreateOrder = True
  Visible = True
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel [0]
    Left = 0
    Top = 0
    Width = 276
    Height = 192
    Align = alClient
    Alignment = taCenter
    Caption = '2'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -107
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
    Layout = tlCenter
  end
end
