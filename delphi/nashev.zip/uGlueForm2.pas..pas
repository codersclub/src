unit uGlueForm2;
interface
uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  uCustomGlueForm, StdCtrls;

type
  TGlueForm2 = class(TCustomGlueForm)
    Label1: TLabel;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  GlueForm2: TGlueForm2;

implementation

{$R *.DFM}

end.
