unit uGlueForm1;
interface
uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  uCustomGlueForm, StdCtrls;

type
  TGlueForm1 = class(TCustomGlueForm)
    Label1: TLabel;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  GlueForm1: TGlueForm1;

implementation

{$R *.DFM}

end.
