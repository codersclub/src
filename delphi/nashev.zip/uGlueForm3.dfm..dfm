inherited GlueForm3: TGlueForm3
  Left = 530
  Top = 531
  Width = 373
  Height = 145
  Caption = 'GlueForm3'
  OldCreateOrder = True
  Visible = True
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel [0]
    Left = 0
    Top = 0
    Width = 365
    Height = 118
    Align = alClient
    Alignment = taCenter
    Caption = '3'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -107
    Font.Name = 'Arial'
    Font.Style = []
    ParentFont = False
    Layout = tlCenter
  end
  inherited Memo1: TMemo
    Left = 50
    Top = 5
  end
end
