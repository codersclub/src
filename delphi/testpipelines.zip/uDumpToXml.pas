unit uDumpToXml;

interface

uses
  Windows, ActiveX, Classes, ComObj, TestPipelines_TLB, StdVcl,
  PIPELINELib_TLB, MSCSAspHelpLib_TLB, MSCSCoreLib_TLB;

type
  TDumpOrderToXml = class(TAutoObject, IDumpOrderToXml, IPipelineComponent,
    ISpecifyPropertyPages, IPersistStreamInit)
  private
    FXmlFileName: WideString;
  protected
    function GetXmlFileName(out XmlFileName: WideString): HResult; stdcall;
    function SetXmlFilename(const XmlFileName: WideString): HResult; stdcall;
    function EnableDesign(fEnable: Integer): HResult; stdcall;
    function Execute(const pdispOrder, pdispContext: IDispatch;
      lFlags: Integer; out plErrorLevel: Integer): HResult; stdcall;
    function ExportDictionaryToXml(const Dict: IDictionary;
      out XmlStr: WideString): HResult; stdcall;
    function ExportSimpleListToXml(const List: ISimpleList;
      out XmlStr: WideString): HResult; stdcall;
    function GetPages(out pages: TCAGUID): HResult; stdcall;
    function GetClassID(out classID: TCLSID): HResult; stdcall;
    function IsDirty: HResult; stdcall;
    function Load(const stm: IStream): HResult; stdcall;
    function Save(const stm: IStream; fClearDirty: BOOL): HResult; stdcall;
    function GetSizeMax(out cbSize: Largeint): HResult; stdcall;
    function InitNew: HResult; stdcall;
    {Declare IDumpOrderToXml methods here}
  end;

implementation

uses SysUtils, ComServ, AxCtrls, fDumpToXmlProps, ComPUtil;

function TDumpOrderToXml.GetXmlFileName(
  out XmlFileName: WideString): HResult;
begin
  try
    XmlFileName := FXmlFileName;
    Result := S_OK;
  except
    Result := E_FAIL;
  end;
end;

function TDumpOrderToXml.SetXmlFilename(
  const XmlFileName: WideString): HResult;
begin
  try
    FXmlFileName := XmlFileName;
    Result := S_OK;
  except
    Result := E_FAIL;
  end;
end;

function TDumpOrderToXml.EnableDesign(fEnable: Integer): HResult;
begin
  Result := S_OK; // default
end;

function TDumpOrderToXml.Execute(const pdispOrder, pdispContext: IDispatch;
  lFlags: Integer; out plErrorLevel: Integer): HResult;
var
  hFile: Integer;
  tmpXML: WideString;
  Order: IDictionary;
  tmpOutXml: string;
begin
  try
    tmpXML := '';
    if GetDictFromDispatch(pdispOrder, Order) = S_OK then begin
      ExportDictionaryToXML(Order, tmpXML);
      tmpXML := '<SO>' + tmpXML + '</SO>';
    end;

    tmpOutXml := tmpXML;
    hFile := FileCreate(string(FXmlFileName));
    FileWrite(hFile, tmpOutXml[1], Length(tmpOutXML));
    FileClose(hFile);

  finally
    Result := S_OK;
    Order := nil;
  end;
end;

function TDumpOrderToXml.ExportDictionaryToXml(const Dict: IDictionary;
  out XmlStr: WideString): HResult;
var
  hr: HRESULT;
  Enum: IEnumVARIANT;
  NewDict: IDictionary;
  NewList: ISimpleList;
  Key: WideString;
  ItemValue: OleVariant;
  Res, NewXml: WideString;
begin
  Res := '';
  Result := E_FAIL;
  hr := InitKeyEnumInDict(Dict, Enum);
  if hr = S_OK then begin

    repeat
      hr := GetNextKeyInDict(Enum, Key);
      if hr <> S_OK then Break;
      hr := GetDictValueVariant(Dict, LPCWSTR(Key), ItemValue);
      if hr <> S_OK then Break;

      case VarType(ItemValue) of
        varDispatch: begin
          if GetDictFromDispatch(ItemValue, NewDict) = S_OK then begin
            if ExportDictionaryToXML(NewDict, NewXml) = S_OK then begin
              Res := Res + Format('<%s type="Dictionary">%s</%s>',
                [string(Key), string(NewXml), string(Key)]);
            end else begin
              Exit;
            end;
          end else if GetSimpleListFromDispatch(ItemValue, NewList) = S_OK then begin
            if ExportSimpleListToXML(NewList, NewXml) = S_OK then begin
              Res := Res + Format('<%s type="SimpleList">%s</%s>',
                [string(Key), string(NewXml), string(Key)]);
            end else begin
              Exit;
            end;
          end else begin
            Res := Res + Format('<%s>IDispatch</%s>',
              [string(Key), string(Key)]);
          end;
        end;
        varUnknown: begin
          Res := Res + Format('<%s>IUnknown</%s>',
            [string(Key), string(Key)]);
        end;
        varSmallint,
        varInteger,
        varSingle,
        varDouble,
        varCurrency,
        varDate,
        varOleStr,
        varBoolean,
        varByte,
        varString: begin
          Res := Res + Format('<%s>%s</%s>',
            [string(Key), string(ItemValue), string(Key)]);
        end;
      else
        Break;
      end;

    until hr <> S_OK;
  end;
  
  XmlStr := Res;
  Result := S_OK;
end;

function TDumpOrderToXml.ExportSimpleListToXml(const List: ISimpleList;
  out XmlStr: WideString): HResult;
var
  hr: HRESULT;
  NewDict: IDictionary;
  I, Count: Integer;
  Res, NewXml: WideString;
begin
  Result := E_FAIL;
  hr := GetNumItems(List, Count);
  if hr <> S_OK then Exit;

  for I := 0 to Count - 1 do begin
    if GetNthItem(List, I, NewDict) = S_OK then begin
      if ExportDictionaryToXML(NewDict, NewXml) = S_OK then begin
        Res := Res + Format('<LISTITEM%d>'#13#10'%s</LISTITEM%d>'#13#10,
          [I, string(NewXml), I]);
      end else begin
        Exit;
      end;
    end;
  end;
  
  XmlStr := Res;
  Result := S_OK;
end;

function TDumpOrderToXml.GetPages(out pages: TCAGUID): HResult;
begin
  pages.cElems := 1;
  pages.pElems := CoTaskMemAlloc(sizeof(TGUID));
  if pages.pElems = nil then begin
    Result := E_OUTOFMEMORY;
  end else begin
    pages.pElems^[0] := Class_DumpToXMLPropertyPage;
    Result := S_OK;
  end;
end;

function TDumpOrderToXml.GetClassID(out classID: TCLSID): HResult;
begin
  classID := Factory.ClassID;
  Result := S_OK;
end;

function TDumpOrderToXml.GetSizeMax(out cbSize: Largeint): HResult;
begin
  cbSize := 255 * sizeof(WideChar) + 1; // max 200 widechars + size;
  Result := S_OK;
end;

function TDumpOrderToXml.InitNew: HResult;
begin
  Result := S_OK;  // default - everything ok
end;

function TDumpOrderToXml.IsDirty: HResult;
begin
  Result := S_OK; // default - always say that dirty
end;

function TDumpOrderToXml.Load(const stm: IStream): HResult;
var OleStream: TOleStream;
  FileNameLen: Byte;
begin
  OleStream := TOleStream.Create(stm);
  try
    OleStream.Read(FileNameLen, 1);
    SetLength(FXmlFileName, FileNameLen);
    OleStream.Read(FXmlFileName[1], FileNameLen * Sizeof(WideChar));
  finally
    OleStream.Free;
  end; { try }
  Result := S_OK;
end;

function TDumpOrderToXml.Save(const stm: IStream;
  fClearDirty: BOOL): HResult;
var OleStream: TOleStream;
  FileNameLen: Byte;
begin
  OleStream := TOleStream.Create(stm);
  try
    FileNameLen := Length(FXmlFileName);
    OleStream.Write(FileNameLen, 1);
    OleStream.Write(FXmlFileName[1], FileNameLen * Sizeof(WideChar));
  finally
    OleStream.Free;
  end; { try }
  Result := S_OK;
end;

initialization
  TAutoObjectFactory.Create(ComServer, TDumpOrderToXml, Class_DumpOrderToXml,
    ciMultiInstance, tmApartment);
end.
