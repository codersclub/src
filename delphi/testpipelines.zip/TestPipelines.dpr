library TestPipelines;

uses
  ComServ,
  Windows,
  ComPUtil,
  PipeConsts,
  TestPipelines_TLB in 'TestPipelines_TLB.pas',
  uDumpToXml in 'uDumpToXml.pas' {DumpOrderToXml: CoClass},
  fDumpToXmlProps in 'fDumpToXmlProps.pas' {DumpToXMLPropertyPage: TPropertyPage};

function DllRegisterServer: HResult;
begin
  Result := ComServ.DllRegisterServer;
  if Result = S_OK then begin

    { Register DumpOrderToXml class }
    Result := RegisterCATID(CLASS_DumpOrderToXml, CATID_MSCSPIPELINE_COMPONENT);
    if Result >= 0 then begin
      Result := RegisterCATID(CLASS_DumpOrderToXml, CATID_MSCSPIPELINE_ANYSTAGE);
    end;

    {}
  end;
end;

exports
  DllGetClassObject,
  DllCanUnloadNow,
  DllRegisterServer,
  DllUnregisterServer;

{$R *.TLB}

{$R *.RES}

begin
end.
