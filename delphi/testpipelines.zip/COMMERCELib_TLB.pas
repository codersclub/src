unit COMMERCELib_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/21/99 5:29:36 PM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Microsoft Site Server\Bin\Commerce.dll (1)
// IID\LCID: {B5BD5C31-9988-11D0-BB7F-00A0C9083358}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
// Parent TypeLibrary:
//   (0) v1.0 TestPipelines, (E:\Sel\d5\PipeLines\TestPipelines.tlb)
// Errors:
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
//   Hint: Member 'type' of 'tagSTATSTG' changed to 'type_'
//   Hint: Member 'Class' of 'IADs' changed to 'Class_'
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  COMMERCELibMajorVersion = 1;
  COMMERCELibMinorVersion = 0;

  LIBID_COMMERCELib: TGUID = '{B5BD5C31-9988-11D0-BB7F-00A0C9083358}';

  IID_IMSCSLogSink: TGUID = '{937F89AA-758F-11D0-AE84-00A0C90543B8}';
  CLASS_CMSCSLogSink: TGUID = '{937F89BB-758F-11D0-AE84-00A0C90543B8}';
  IID_IContent: TGUID = '{59430C02-59F4-11D0-B214-00805F74836B}';
  CLASS_CContent: TGUID = '{1DE4A62B-58A3-11D0-B211-00805F74836B}';
  IID_IDatasource: TGUID = '{59430C06-59F4-11D0-B214-00805F74836B}';
  CLASS_CDatasource: TGUID = '{EA4C8DDA-5927-11D0-B211-00805F74836B}';
  IID_IMSCSDBStorage_3_0: TGUID = '{CF489F54-3521-11D1-A71A-00C04FD7A105}';
  CLASS_MSCSDBStorage_3_0: TGUID = '{CF489F5D-3521-11D1-A71A-00C04FD7A105}';
  IID_IMSCSStandardSManager_3_0: TGUID = '{CF489F55-3521-11D1-A71A-00C04FD7A105}';
  CLASS_MSCSStandardSManager_3_0: TGUID = '{CF489F5E-3521-11D1-A71A-00C04FD7A105}';
  IID_ISequentialStream: TGUID = '{0C733A30-2A1C-11CE-ADE5-00AA0044773D}';
  IID_IStream: TGUID = '{0000000C-0000-0000-C000-000000000046}';
  CLASS_CNullStream: TGUID = '{435BC650-6E6C-11D0-8D56-00C04FD7A111}';
  IID_IParseDisplayName: TGUID = '{0000011A-0000-0000-C000-000000000046}';
  CLASS_CSimpleDBDS: TGUID = '{6AD2F030-20AE-11D1-9C05-00C04FC3093E}';
  IID_IBindCtx: TGUID = '{0000000E-0000-0000-C000-000000000046}';
  IID_IRunningObjectTable: TGUID = '{00000010-0000-0000-C000-000000000046}';
  IID_IPersist: TGUID = '{0000010C-0000-0000-C000-000000000046}';
  IID_IPersistStream: TGUID = '{00000109-0000-0000-C000-000000000046}';
  IID_IMoniker: TGUID = '{0000000F-0000-0000-C000-000000000046}';
  IID_IEnumMoniker: TGUID = '{00000102-0000-0000-C000-000000000046}';
  IID_IEnumString: TGUID = '{00000101-0000-0000-C000-000000000046}';
  IID_IADs: TGUID = '{FD8256D0-FD15-11CE-ABC4-02608C9E7553}';
  IID_IADsContainer: TGUID = '{001677D0-FD16-11CE-ABC4-02608C9E7553}';
  IID_IADsOpenDSObject: TGUID = '{DDF2891E-0F9C-11D0-8AD4-00C04FD8D503}';
  CLASS_CSimpleDBDSNamespace: TGUID = '{6AD2F000-20AE-11D1-9C05-00C04FC3093E}';
  CLASS_CSimpleDBDSReadOnly: TGUID = '{6AD2F020-20AE-11D1-9C05-00C04FC3093E}';
  CLASS_CSimpleDBDSReadWrite: TGUID = '{6AD2F010-20AE-11D1-9C05-00C04FC3093E}';
  IID_ITrafficLogFile_3_0: TGUID = '{CF489F56-3521-11D1-A71A-00C04FD7A105}';
  CLASS_TrafficLogFile_3_0: TGUID = '{CF489F5B-3521-11D1-A71A-00C04FD7A105}';
  IID_ITrafficTable_3_0: TGUID = '{CF489F57-3521-11D1-A71A-00C04FD7A105}';
  CLASS_TrafficTable_3_0: TGUID = '{CF489F5C-3521-11D1-A71A-00C04FD7A105}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IMSCSLogSink = interface;
  IMSCSLogSinkDisp = dispinterface;
  IContent = interface;
  IContentDisp = dispinterface;
  IDatasource = interface;
  IDatasourceDisp = dispinterface;
  IMSCSDBStorage_3_0 = interface;
  IMSCSDBStorage_3_0Disp = dispinterface;
  IMSCSStandardSManager_3_0 = interface;
  IMSCSStandardSManager_3_0Disp = dispinterface;
  ISequentialStream = interface;
  IStream = interface;
  IParseDisplayName = interface;
  IBindCtx = interface;
  IRunningObjectTable = interface;
  IPersist = interface;
  IPersistStream = interface;
  IMoniker = interface;
  IEnumMoniker = interface;
  IEnumString = interface;
  IADs = interface;
  IADsDisp = dispinterface;
  IADsContainer = interface;
  IADsContainerDisp = dispinterface;
  IADsOpenDSObject = interface;
  IADsOpenDSObjectDisp = dispinterface;
  ITrafficLogFile_3_0 = interface;
  ITrafficLogFile_3_0Disp = dispinterface;
  ITrafficTable_3_0 = interface;
  ITrafficTable_3_0Disp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  CMSCSLogSink = IMSCSLogSink;
  CContent = IContent;
  CDatasource = IDatasource;
  MSCSDBStorage_3_0 = IMSCSDBStorage_3_0;
  MSCSStandardSManager_3_0 = IMSCSStandardSManager_3_0;
  CNullStream = IStream;
  CSimpleDBDS = IParseDisplayName;
  CSimpleDBDSNamespace = IADs;
  CSimpleDBDSReadOnly = IADs;
  CSimpleDBDSReadWrite = IADs;
  TrafficLogFile_3_0 = ITrafficLogFile_3_0;
  TrafficTable_3_0 = ITrafficTable_3_0;


// *********************************************************************//
// Declaration of structures, unions and aliases.                         
// *********************************************************************//
  POleVariant1 = ^OleVariant; {*}
  PShortint1 = ^Shortint; {*}
  PUserType1 = ^TGUID; {*}
  PUserType2 = ^TGUID; {*}
  PUserType3 = ^TGUID; {*}

  _LARGE_INTEGER = packed record
    QuadPart: Int64;
  end;

  _ULARGE_INTEGER = packed record
    QuadPart: Largeuint;
  end;

  _FILETIME = packed record
    dwLowDateTime: LongWord;
    dwHighDateTime: LongWord;
  end;

  tagSTATSTG = packed record
    pwcsName: PWideChar;
    type_: LongWord;
    cbSize: TGUID;
    mtime: TGUID;
    ctime: TGUID;
    atime: TGUID;
    grfMode: LongWord;
    grfLocksSupported: LongWord;
    clsid: TGUID;
    grfStateBits: LongWord;
    reserved: LongWord;
  end;

  _COAUTHIDENTITY = packed record
    User: ^Word;
    UserLength: LongWord;
    Domain: ^Word;
    DomainLength: LongWord;
    Password: ^Word;
    PasswordLength: LongWord;
    Flags: LongWord;
  end;

  _COAUTHINFO = packed record
    dwAuthnSvc: LongWord;
    dwAuthzSvc: LongWord;
    pwszServerPrincName: PWideChar;
    dwAuthnLevel: LongWord;
    dwImpersonationLevel: LongWord;
    pAuthIdentityData: ^TGUID;
    dwCapabilities: LongWord;
  end;

  _COSERVERINFO = packed record
    dwReserved1: LongWord;
    pwszName: PWideChar;
    pAuthInfo: ^TGUID;
    dwReserved2: LongWord;
  end;

  tagBIND_OPTS2 = packed record
    cbStruct: LongWord;
    grfFlags: LongWord;
    grfMode: LongWord;
    dwTickCountDeadline: LongWord;
    dwTrackFlags: LongWord;
    dwClassContext: LongWord;
    locale: LongWord;
    pServerInfo: ^TGUID;
  end;


// *********************************************************************//
// Interface: IMSCSLogSink
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {937F89AA-758F-11D0-AE84-00A0C90543B8}
// *********************************************************************//
  IMSCSLogSink = interface(IDispatch)
    ['{937F89AA-758F-11D0-AE84-00A0C90543B8}']
    procedure InitSink(const bstrLogFileName: WideString); safecall;
    procedure DeInitSink; safecall;
    procedure AddString(const bstrItemName: WideString; const bstrLogString: WideString); safecall;
    procedure BeginLogItem(const bstrItemName: WideString); safecall;
    procedure AppendLogItem(const bstrLogString: WideString); safecall;
    procedure EndLogItem; safecall;
  end;

// *********************************************************************//
// DispIntf:  IMSCSLogSinkDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {937F89AA-758F-11D0-AE84-00A0C90543B8}
// *********************************************************************//
  IMSCSLogSinkDisp = dispinterface
    ['{937F89AA-758F-11D0-AE84-00A0C90543B8}']
    procedure InitSink(const bstrLogFileName: WideString); dispid 1610743808;
    procedure DeInitSink; dispid 1610743809;
    procedure AddString(const bstrItemName: WideString; const bstrLogString: WideString); dispid 1610743810;
    procedure BeginLogItem(const bstrItemName: WideString); dispid 1610743811;
    procedure AppendLogItem(const bstrLogString: WideString); dispid 1610743812;
    procedure EndLogItem; dispid 1610743813;
  end;

// *********************************************************************//
// Interface: IContent
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {59430C02-59F4-11D0-B214-00805F74836B}
// *********************************************************************//
  IContent = interface(IDispatch)
    ['{59430C02-59F4-11D0-B214-00805F74836B}']
    function  Datasource(const bstrName: WideString): OleVariant; safecall;
    procedure AddDatasource(const bstrDSNName: WideString; const bstrDSN: WideString); safecall;
    procedure AddQuery(const bstrQueryName: WideString; const bstrSQLQuery: WideString; 
                       lTimeout: Integer; lCommandType: Integer; lMaxRows: Integer; 
                       lCursorType: Integer; lCursorSize: Integer; lRetrieval: Integer); safecall;
  end;

// *********************************************************************//
// DispIntf:  IContentDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {59430C02-59F4-11D0-B214-00805F74836B}
// *********************************************************************//
  IContentDisp = dispinterface
    ['{59430C02-59F4-11D0-B214-00805F74836B}']
    function  Datasource(const bstrName: WideString): OleVariant; dispid 0;
    procedure AddDatasource(const bstrDSNName: WideString; const bstrDSN: WideString); dispid 1;
    procedure AddQuery(const bstrQueryName: WideString; const bstrSQLQuery: WideString; 
                       lTimeout: Integer; lCommandType: Integer; lMaxRows: Integer; 
                       lCursorType: Integer; lCursorSize: Integer; lRetrieval: Integer); dispid 2;
  end;

// *********************************************************************//
// Interface: IDatasource
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {59430C06-59F4-11D0-B214-00805F74836B}
// *********************************************************************//
  IDatasource = interface(IDispatch)
    ['{59430C06-59F4-11D0-B214-00805F74836B}']
    function  Execute(const bstrSQLQuery: WideString; nArgs: SYSINT; var pvarArgs: OleVariant; 
                      const bstrParamOrder: WideString; lTimeout: Integer; lCommandType: Integer; 
                      lMaxRows: Integer; lCursorType: Integer; lCursorSize: Integer; 
                      lRetrieval: Integer): OleVariant; safecall;
    function  ExecuteADO(const pdispConnection: IDispatch; const bstrSQLQuery: WideString; 
                         nArgs: SYSINT; var pvarArgs: OleVariant; const bstrParamOrder: WideString; 
                         lTimeout: Integer; lCommandType: Integer; lMaxRows: Integer; 
                         lCursorType: Integer; lCursorSize: Integer): OleVariant; safecall;
    function  Describe(const bstrSQLQuery: WideString; nArgs: SYSINT; var pvarArgs: OleVariant; 
                       const bstrParamOrder: WideString): OleVariant; safecall;
    function  CreateADOConnection: IDispatch; safecall;
    procedure _Initialize(const pdispQuery: IDispatch; const bstrDSN: WideString); safecall;
  end;

// *********************************************************************//
// DispIntf:  IDatasourceDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {59430C06-59F4-11D0-B214-00805F74836B}
// *********************************************************************//
  IDatasourceDisp = dispinterface
    ['{59430C06-59F4-11D0-B214-00805F74836B}']
    function  Execute(const bstrSQLQuery: WideString; nArgs: SYSINT; var pvarArgs: OleVariant; 
                      const bstrParamOrder: WideString; lTimeout: Integer; lCommandType: Integer; 
                      lMaxRows: Integer; lCursorType: Integer; lCursorSize: Integer; 
                      lRetrieval: Integer): OleVariant; dispid 1;
    function  ExecuteADO(const pdispConnection: IDispatch; const bstrSQLQuery: WideString; 
                         nArgs: SYSINT; var pvarArgs: OleVariant; const bstrParamOrder: WideString; 
                         lTimeout: Integer; lCommandType: Integer; lMaxRows: Integer; 
                         lCursorType: Integer; lCursorSize: Integer): OleVariant; dispid 2;
    function  Describe(const bstrSQLQuery: WideString; nArgs: SYSINT; var pvarArgs: OleVariant; 
                       const bstrParamOrder: WideString): OleVariant; dispid 3;
    function  CreateADOConnection: IDispatch; dispid 1610743811;
    procedure _Initialize(const pdispQuery: IDispatch; const bstrDSN: WideString); dispid 1610743812;
  end;

// *********************************************************************//
// Interface: IMSCSDBStorage_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F54-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSDBStorage_3_0 = interface(IDispatch)
    ['{CF489F54-3521-11D1-A71A-00C04FD7A105}']
    procedure InitStorage(vtDataSourceOrDSN: OleVariant; const Table: WideString; 
                          const bstrKey: WideString; vtProgID: OleVariant; vtMarshal: OleVariant; 
                          vtChanged: OleVariant); safecall;
    function  ProcessData(const pdispData: IDispatch): IDispatch; safecall;
    procedure DeleteData(vtReserved: OleVariant; const pdispData: IDispatch); safecall;
    procedure InsertData(vtReserved: OleVariant; const pdispData: IDispatch); safecall;
    procedure CommitData(vtReserved: OleVariant; const pdispData: IDispatch); safecall;
    procedure DeleteDataKey(vtReserved: OleVariant; vtKey: OleVariant); safecall;
    function  LookupData(vtReserved: OleVariant; var pvtKeys: OleVariant; var pvtValues: OleVariant): OleVariant; safecall;
    function  LookupMultipleData(vtReserved: OleVariant; var pvtKeys: OleVariant; 
                                 var pvtValues: OleVariant): OleVariant; safecall;
    function  GetData(vtReserved: OleVariant; vtKey: OleVariant): OleVariant; safecall;
    function  Get_Mapping: IDispatch; safecall;
    procedure Set_Mapping(const ppdispMapping: IDispatch); safecall;
    property Mapping: IDispatch read Get_Mapping write Set_Mapping;
  end;

// *********************************************************************//
// DispIntf:  IMSCSDBStorage_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F54-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSDBStorage_3_0Disp = dispinterface
    ['{CF489F54-3521-11D1-A71A-00C04FD7A105}']
    procedure InitStorage(vtDataSourceOrDSN: OleVariant; const Table: WideString; 
                          const bstrKey: WideString; vtProgID: OleVariant; vtMarshal: OleVariant; 
                          vtChanged: OleVariant); dispid 0;
    function  ProcessData(const pdispData: IDispatch): IDispatch; dispid 1;
    procedure DeleteData(vtReserved: OleVariant; const pdispData: IDispatch); dispid 2;
    procedure InsertData(vtReserved: OleVariant; const pdispData: IDispatch); dispid 3;
    procedure CommitData(vtReserved: OleVariant; const pdispData: IDispatch); dispid 4;
    procedure DeleteDataKey(vtReserved: OleVariant; vtKey: OleVariant); dispid 5;
    function  LookupData(vtReserved: OleVariant; var pvtKeys: OleVariant; var pvtValues: OleVariant): OleVariant; dispid 6;
    function  LookupMultipleData(vtReserved: OleVariant; var pvtKeys: OleVariant; 
                                 var pvtValues: OleVariant): OleVariant; dispid 7;
    function  GetData(vtReserved: OleVariant; vtKey: OleVariant): OleVariant; dispid 8;
    property Mapping: IDispatch dispid 9;
  end;

// *********************************************************************//
// Interface: IMSCSStandardSManager_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F55-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSStandardSManager_3_0 = interface(IDispatch)
    ['{CF489F55-3521-11D1-A71A-00C04FD7A105}']
    function  Get_Heading: WideString; safecall;
    procedure Set_Heading(const pbstrHeading: WideString); safecall;
    function  Get_Expires: TDateTime; safecall;
    procedure Set_Expires(pvtExpires: OleVariant); safecall;
    function  Get_StoreKey: WideString; safecall;
    procedure Set_StoreKey(const pbstrStoreKey: WideString); safecall;
    function  Get_Mode: SYSINT; safecall;
    procedure Set_Mode(piMode: SYSINT); safecall;
    procedure InitManager(const bstrStoreKey: WideString; const bstrMode: WideString); safecall;
    function  GetShopperId(const pdispContext: IDispatch): OleVariant; safecall;
    procedure PutShopperId(const pdispContext: IDispatch; const bstrShopperID: WideString); safecall;
    procedure DeleteShopperId(const pdispContext: IDispatch; const bstrShopperID: WideString); safecall;
    function  CreateShopperId: WideString; safecall;
    property Heading: WideString read Get_Heading write Set_Heading;
    property StoreKey: WideString read Get_StoreKey write Set_StoreKey;
    property Mode: SYSINT read Get_Mode write Set_Mode;
  end;

// *********************************************************************//
// DispIntf:  IMSCSStandardSManager_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F55-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSStandardSManager_3_0Disp = dispinterface
    ['{CF489F55-3521-11D1-A71A-00C04FD7A105}']
    property Heading: WideString dispid 0;
    function  Expires: TDateTime; dispid 1;
    property StoreKey: WideString dispid 2;
    property Mode: SYSINT dispid 3;
    procedure InitManager(const bstrStoreKey: WideString; const bstrMode: WideString); dispid 1610743816;
    function  GetShopperId(const pdispContext: IDispatch): OleVariant; dispid 1610743817;
    procedure PutShopperId(const pdispContext: IDispatch; const bstrShopperID: WideString); dispid 1610743818;
    procedure DeleteShopperId(const pdispContext: IDispatch; const bstrShopperID: WideString); dispid 1610743819;
    function  CreateShopperId: WideString; dispid 1610743820;
  end;

// *********************************************************************//
// Interface: ISequentialStream
// Flags:     (0)
// GUID:      {0C733A30-2A1C-11CE-ADE5-00AA0044773D}
// *********************************************************************//
  ISequentialStream = interface(IUnknown)
    ['{0C733A30-2A1C-11CE-ADE5-00AA0044773D}']
    function  RemoteRead(out pv: Shortint; cb: LongWord; out pcbRead: LongWord): HResult; stdcall;
    function  RemoteWrite(var pv: Shortint; cb: LongWord; out pcbWritten: LongWord): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IStream
// Flags:     (0)
// GUID:      {0000000C-0000-0000-C000-000000000046}
// *********************************************************************//
  IStream = interface(ISequentialStream)
    ['{0000000C-0000-0000-C000-000000000046}']
    function  RemoteSeek(dlibMove: TGUID; dwOrigin: LongWord; out plibNewPosition: TGUID): HResult; stdcall;
    function  SetSize(libNewSize: TGUID): HResult; stdcall;
    function  RemoteCopyTo(const pstm: IStream; cb: TGUID; out pcbRead: TGUID; out pcbWritten: TGUID): HResult; stdcall;
    function  Commit(grfCommitFlags: LongWord): HResult; stdcall;
    function  Revert: HResult; stdcall;
    function  LockRegion(libOffset: TGUID; cb: TGUID; dwLockType: LongWord): HResult; stdcall;
    function  UnlockRegion(libOffset: TGUID; cb: _ULARGE_INTEGER; dwLockType: LongWord): HResult; stdcall;
    function  Stat(out pstatstg: TGUID; grfStatFlag: LongWord): HResult; stdcall;
    function  Clone(out ppstm: IStream): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IParseDisplayName
// Flags:     (0)
// GUID:      {0000011A-0000-0000-C000-000000000046}
// *********************************************************************//
  IParseDisplayName = interface(IUnknown)
    ['{0000011A-0000-0000-C000-000000000046}']
    function  ParseDisplayName(const pbc: IBindCtx; pszDisplayName: PWideChar; 
                               out pchEaten: LongWord; out ppmkOut: IMoniker): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IBindCtx
// Flags:     (0)
// GUID:      {0000000E-0000-0000-C000-000000000046}
// *********************************************************************//
  IBindCtx = interface(IUnknown)
    ['{0000000E-0000-0000-C000-000000000046}']
    function  RegisterObjectBound(const punk: IUnknown): HResult; stdcall;
    function  RevokeObjectBound(const punk: IUnknown): HResult; stdcall;
    function  ReleaseBoundObjects: HResult; stdcall;
    function  RemoteSetBindOptions(var pbindopts: TGUID): HResult; stdcall;
    function  RemoteGetBindOptions(var pbindopts: TGUID): HResult; stdcall;
    function  GetRunningObjectTable(out pprot: IRunningObjectTable): HResult; stdcall;
    function  RegisterObjectParam(pszKey: PWideChar; const punk: IUnknown): HResult; stdcall;
    function  GetObjectParam(pszKey: PWideChar; out ppunk: IUnknown): HResult; stdcall;
    function  EnumObjectParam(out ppenum: IEnumString): HResult; stdcall;
    function  RevokeObjectParam(pszKey: PWideChar): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IRunningObjectTable
// Flags:     (0)
// GUID:      {00000010-0000-0000-C000-000000000046}
// *********************************************************************//
  IRunningObjectTable = interface(IUnknown)
    ['{00000010-0000-0000-C000-000000000046}']
    function  Register(grfFlags: LongWord; const punkObject: IUnknown; 
                       const pmkObjectName: IMoniker; out pdwRegister: LongWord): HResult; stdcall;
    function  Revoke(dwRegister: LongWord): HResult; stdcall;
    function  IsRunning(const pmkObjectName: IMoniker): HResult; stdcall;
    function  GetObject(const pmkObjectName: IMoniker; out ppunkObject: IUnknown): HResult; stdcall;
    function  NoteChangeTime(dwRegister: LongWord; var pFileTime: TGUID): HResult; stdcall;
    function  GetTimeOfLastChange(const pmkObjectName: IMoniker; out pFileTime: TGUID): HResult; stdcall;
    function  EnumRunning(out ppenumMoniker: IEnumMoniker): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IPersist
// Flags:     (0)
// GUID:      {0000010C-0000-0000-C000-000000000046}
// *********************************************************************//
  IPersist = interface(IUnknown)
    ['{0000010C-0000-0000-C000-000000000046}']
    function  GetClassID(out pClassID: TGUID): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IPersistStream
// Flags:     (0)
// GUID:      {00000109-0000-0000-C000-000000000046}
// *********************************************************************//
  IPersistStream = interface(IPersist)
    ['{00000109-0000-0000-C000-000000000046}']
    function  IsDirty: HResult; stdcall;
    function  Load(const pstm: IStream): HResult; stdcall;
    function  Save(const pstm: IStream; fClearDirty: Integer): HResult; stdcall;
    function  GetSizeMax(out pcbSize: TGUID): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IMoniker
// Flags:     (0)
// GUID:      {0000000F-0000-0000-C000-000000000046}
// *********************************************************************//
  IMoniker = interface(IPersistStream)
    ['{0000000F-0000-0000-C000-000000000046}']
    function  RemoteBindToObject(const pbc: IBindCtx; const pmkToLeft: IMoniker; 
                                 var riidResult: TGUID; out ppvResult: IUnknown): HResult; stdcall;
    function  RemoteBindToStorage(const pbc: IBindCtx; const pmkToLeft: IMoniker; var riid: TGUID; 
                                  out ppvObj: IUnknown): HResult; stdcall;
    function  Reduce(const pbc: IBindCtx; dwReduceHowFar: LongWord; var ppmkToLeft: IMoniker; 
                     out ppmkReduced: IMoniker): HResult; stdcall;
    function  ComposeWith(const pmkRight: IMoniker; fOnlyIfNotGeneric: Integer; 
                          out ppmkComposite: IMoniker): HResult; stdcall;
    function  Enum(fForward: Integer; out ppenumMoniker: IEnumMoniker): HResult; stdcall;
    function  IsEqual(const pmkOtherMoniker: IMoniker): HResult; stdcall;
    function  Hash(out pdwHash: LongWord): HResult; stdcall;
    function  IsRunning(const pbc: IBindCtx; const pmkToLeft: IMoniker; 
                        const pmkNewlyRunning: IMoniker): HResult; stdcall;
    function  GetTimeOfLastChange(const pbc: IBindCtx; const pmkToLeft: IMoniker; 
                                  out pFileTime: TGUID): HResult; stdcall;
    function  Inverse(out ppmk: IMoniker): HResult; stdcall;
    function  CommonPrefixWith(const pmkOther: IMoniker; out ppmkPrefix: IMoniker): HResult; stdcall;
    function  RelativePathTo(const pmkOther: IMoniker; out ppmkRelPath: IMoniker): HResult; stdcall;
    function  GetDisplayName(const pbc: IBindCtx; const pmkToLeft: IMoniker; 
                             out ppszDisplayName: PWideChar): HResult; stdcall;
    function  ParseDisplayName(const pbc: IBindCtx; const pmkToLeft: IMoniker; 
                               pszDisplayName: PWideChar; out pchEaten: LongWord; 
                               out ppmkOut: IMoniker): HResult; stdcall;
    function  IsSystemMoniker(out pdwMksys: LongWord): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IEnumMoniker
// Flags:     (0)
// GUID:      {00000102-0000-0000-C000-000000000046}
// *********************************************************************//
  IEnumMoniker = interface(IUnknown)
    ['{00000102-0000-0000-C000-000000000046}']
    function  RemoteNext(celt: LongWord; out rgelt: IMoniker; out pceltFetched: LongWord): HResult; stdcall;
    function  Skip(celt: LongWord): HResult; stdcall;
    function  Reset: HResult; stdcall;
    function  Clone(out ppenum: IEnumMoniker): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IEnumString
// Flags:     (0)
// GUID:      {00000101-0000-0000-C000-000000000046}
// *********************************************************************//
  IEnumString = interface(IUnknown)
    ['{00000101-0000-0000-C000-000000000046}']
    function  RemoteNext(celt: LongWord; out rgelt: PWideChar; out pceltFetched: LongWord): HResult; stdcall;
    function  Skip(celt: LongWord): HResult; stdcall;
    function  Reset: HResult; stdcall;
    function  Clone(out ppenum: IEnumString): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IADs
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {FD8256D0-FD15-11CE-ABC4-02608C9E7553}
// *********************************************************************//
  IADs = interface(IDispatch)
    ['{FD8256D0-FD15-11CE-ABC4-02608C9E7553}']
    function  Get_Name: WideString; safecall;
    function  Get_Class_: WideString; safecall;
    function  Get_GUID: WideString; safecall;
    function  Get_ADsPath: WideString; safecall;
    function  Get_Parent: WideString; safecall;
    function  Get_Schema: WideString; safecall;
    procedure GetInfo; safecall;
    procedure SetInfo; safecall;
    function  Get(const bstrName: WideString): OleVariant; safecall;
    procedure Put(const bstrName: WideString; vProp: OleVariant); safecall;
    function  GetEx(const bstrName: WideString): OleVariant; safecall;
    procedure PutEx(lnControlCode: Integer; const bstrName: WideString; vProp: OleVariant); safecall;
    procedure GetInfoEx(vProperties: OleVariant; lnReserved: Integer); safecall;
    property Name: WideString read Get_Name;
    property Class_: WideString read Get_Class_;
    property GUID: WideString read Get_GUID;
    property ADsPath: WideString read Get_ADsPath;
    property Parent: WideString read Get_Parent;
    property Schema: WideString read Get_Schema;
  end;

// *********************************************************************//
// DispIntf:  IADsDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {FD8256D0-FD15-11CE-ABC4-02608C9E7553}
// *********************************************************************//
  IADsDisp = dispinterface
    ['{FD8256D0-FD15-11CE-ABC4-02608C9E7553}']
    property Name: WideString readonly dispid 2;
    property Class_: WideString readonly dispid 3;
    property GUID: WideString readonly dispid 4;
    property ADsPath: WideString readonly dispid 5;
    property Parent: WideString readonly dispid 6;
    property Schema: WideString readonly dispid 7;
    procedure GetInfo; dispid 8;
    procedure SetInfo; dispid 9;
    function  Get(const bstrName: WideString): OleVariant; dispid 10;
    procedure Put(const bstrName: WideString; vProp: OleVariant); dispid 11;
    function  GetEx(const bstrName: WideString): OleVariant; dispid 12;
    procedure PutEx(lnControlCode: Integer; const bstrName: WideString; vProp: OleVariant); dispid 13;
    procedure GetInfoEx(vProperties: OleVariant; lnReserved: Integer); dispid 14;
  end;

// *********************************************************************//
// Interface: IADsContainer
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {001677D0-FD16-11CE-ABC4-02608C9E7553}
// *********************************************************************//
  IADsContainer = interface(IDispatch)
    ['{001677D0-FD16-11CE-ABC4-02608C9E7553}']
    function  Get_Count: Integer; safecall;
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Filter: OleVariant; safecall;
    procedure Set_Filter(pVar: OleVariant); safecall;
    function  Get_Hints: OleVariant; safecall;
    procedure Set_Hints(pvFilter: OleVariant); safecall;
    function  GetObject(const ClassName: WideString; const RelativeName: WideString): IDispatch; safecall;
    function  Create(const ClassName: WideString; const RelativeName: WideString): IDispatch; safecall;
    procedure Delete(const bstrClassName: WideString; const bstrRelativeName: WideString); safecall;
    function  CopyHere(const SourceName: WideString; const NewName: WideString): IDispatch; safecall;
    function  MoveHere(const SourceName: WideString; const NewName: WideString): IDispatch; safecall;
    property Count: Integer read Get_Count;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Filter: OleVariant read Get_Filter write Set_Filter;
    property Hints: OleVariant read Get_Hints write Set_Hints;
  end;

// *********************************************************************//
// DispIntf:  IADsContainerDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {001677D0-FD16-11CE-ABC4-02608C9E7553}
// *********************************************************************//
  IADsContainerDisp = dispinterface
    ['{001677D0-FD16-11CE-ABC4-02608C9E7553}']
    property Count: Integer readonly dispid 2;
    property _NewEnum: IUnknown readonly dispid -4;
    property Filter: OleVariant dispid 3;
    property Hints: OleVariant dispid 4;
    function  GetObject(const ClassName: WideString; const RelativeName: WideString): IDispatch; dispid 5;
    function  Create(const ClassName: WideString; const RelativeName: WideString): IDispatch; dispid 6;
    procedure Delete(const bstrClassName: WideString; const bstrRelativeName: WideString); dispid 7;
    function  CopyHere(const SourceName: WideString; const NewName: WideString): IDispatch; dispid 8;
    function  MoveHere(const SourceName: WideString; const NewName: WideString): IDispatch; dispid 9;
  end;

// *********************************************************************//
// Interface: IADsOpenDSObject
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {DDF2891E-0F9C-11D0-8AD4-00C04FD8D503}
// *********************************************************************//
  IADsOpenDSObject = interface(IDispatch)
    ['{DDF2891E-0F9C-11D0-8AD4-00C04FD8D503}']
    function  OpenDSObject(const lpszDNName: WideString; const lpszUserName: WideString; 
                           const lpszPassword: WideString; lnReserved: Integer): IDispatch; safecall;
  end;

// *********************************************************************//
// DispIntf:  IADsOpenDSObjectDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {DDF2891E-0F9C-11D0-8AD4-00C04FD8D503}
// *********************************************************************//
  IADsOpenDSObjectDisp = dispinterface
    ['{DDF2891E-0F9C-11D0-8AD4-00C04FD8D503}']
    function  OpenDSObject(const lpszDNName: WideString; const lpszUserName: WideString; 
                           const lpszPassword: WideString; lnReserved: Integer): IDispatch; dispid 1;
  end;

// *********************************************************************//
// Interface: ITrafficLogFile_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F56-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  ITrafficLogFile_3_0 = interface(IDispatch)
    ['{CF489F56-3521-11D1-A71A-00C04FD7A105}']
    procedure InitTraffic(const StoreName: WideString; const FileName: WideString; Args: OleVariant); safecall;
    procedure LogTraffic(ShopperID: OleVariant; Event: OleVariant; ItemRequested: OleVariant; 
                         Context: OleVariant); safecall;
    function  Get_LocaleDate: OleVariant; safecall;
    procedure Set_LocaleDate(pvtValue: OleVariant); safecall;
    function  Get_LocaleTime: OleVariant; safecall;
    procedure Set_LocaleTime(pvtValue: OleVariant); safecall;
    function  Get_ColumnDelimiter: OleVariant; safecall;
    procedure Set_ColumnDelimiter(pvtValue: OleVariant); safecall;
    function  Get_ColumnSubstitution: OleVariant; safecall;
    procedure Set_ColumnSubstitution(pvtValue: OleVariant); safecall;
    function  Get_RowDelimiter: OleVariant; safecall;
    procedure Set_RowDelimiter(pvtValue: OleVariant); safecall;
    function  Get_RowSubstitution: OleVariant; safecall;
    procedure Set_RowSubstitution(pvtValue: OleVariant); safecall;
    function  Get_BlankSubstitution: OleVariant; safecall;
    procedure Set_BlankSubstitution(pvtValue: OleVariant); safecall;
    property LocaleDate: OleVariant read Get_LocaleDate write Set_LocaleDate;
    property LocaleTime: OleVariant read Get_LocaleTime write Set_LocaleTime;
    property ColumnDelimiter: OleVariant read Get_ColumnDelimiter write Set_ColumnDelimiter;
    property ColumnSubstitution: OleVariant read Get_ColumnSubstitution write Set_ColumnSubstitution;
    property RowDelimiter: OleVariant read Get_RowDelimiter write Set_RowDelimiter;
    property RowSubstitution: OleVariant read Get_RowSubstitution write Set_RowSubstitution;
    property BlankSubstitution: OleVariant read Get_BlankSubstitution write Set_BlankSubstitution;
  end;

// *********************************************************************//
// DispIntf:  ITrafficLogFile_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F56-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  ITrafficLogFile_3_0Disp = dispinterface
    ['{CF489F56-3521-11D1-A71A-00C04FD7A105}']
    procedure InitTraffic(const StoreName: WideString; const FileName: WideString; Args: OleVariant); dispid 0;
    procedure LogTraffic(ShopperID: OleVariant; Event: OleVariant; ItemRequested: OleVariant; 
                         Context: OleVariant); dispid 1;
    property LocaleDate: OleVariant dispid 2;
    property LocaleTime: OleVariant dispid 3;
    property ColumnDelimiter: OleVariant dispid 4;
    property ColumnSubstitution: OleVariant dispid 5;
    property RowDelimiter: OleVariant dispid 6;
    property RowSubstitution: OleVariant dispid 7;
    property BlankSubstitution: OleVariant dispid 8;
  end;

// *********************************************************************//
// Interface: ITrafficTable_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F57-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  ITrafficTable_3_0 = interface(IDispatch)
    ['{CF489F57-3521-11D1-A71A-00C04FD7A105}']
    procedure InitTraffic(DatasourceOrDSN: OleVariant; const StoreName: WideString; 
                          const TableName: WideString); safecall;
    procedure LogTraffic(ShopperID: OleVariant; Event: OleVariant; ItemRequested: OleVariant; 
                         Context: OleVariant); safecall;
  end;

// *********************************************************************//
// DispIntf:  ITrafficTable_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F57-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  ITrafficTable_3_0Disp = dispinterface
    ['{CF489F57-3521-11D1-A71A-00C04FD7A105}']
    procedure InitTraffic(DatasourceOrDSN: OleVariant; const StoreName: WideString; 
                          const TableName: WideString); dispid 0;
    procedure LogTraffic(ShopperID: OleVariant; Event: OleVariant; ItemRequested: OleVariant; 
                         Context: OleVariant); dispid 1;
  end;

// *********************************************************************//
// The Class CoCMSCSLogSink provides a Create and CreateRemote method to          
// create instances of the default interface IMSCSLogSink exposed by              
// the CoClass CMSCSLogSink. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCMSCSLogSink = class
    class function Create: IMSCSLogSink;
    class function CreateRemote(const MachineName: string): IMSCSLogSink;
  end;

// *********************************************************************//
// The Class CoCContent provides a Create and CreateRemote method to          
// create instances of the default interface IContent exposed by              
// the CoClass CContent. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCContent = class
    class function Create: IContent;
    class function CreateRemote(const MachineName: string): IContent;
  end;

// *********************************************************************//
// The Class CoCDatasource provides a Create and CreateRemote method to          
// create instances of the default interface IDatasource exposed by              
// the CoClass CDatasource. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCDatasource = class
    class function Create: IDatasource;
    class function CreateRemote(const MachineName: string): IDatasource;
  end;

// *********************************************************************//
// The Class CoMSCSDBStorage_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface IMSCSDBStorage_3_0 exposed by              
// the CoClass MSCSDBStorage_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoMSCSDBStorage_3_0 = class
    class function Create: IMSCSDBStorage_3_0;
    class function CreateRemote(const MachineName: string): IMSCSDBStorage_3_0;
  end;

// *********************************************************************//
// The Class CoMSCSStandardSManager_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface IMSCSStandardSManager_3_0 exposed by              
// the CoClass MSCSStandardSManager_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoMSCSStandardSManager_3_0 = class
    class function Create: IMSCSStandardSManager_3_0;
    class function CreateRemote(const MachineName: string): IMSCSStandardSManager_3_0;
  end;

// *********************************************************************//
// The Class CoCNullStream provides a Create and CreateRemote method to          
// create instances of the default interface IStream exposed by              
// the CoClass CNullStream. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCNullStream = class
    class function Create: IStream;
    class function CreateRemote(const MachineName: string): IStream;
  end;

// *********************************************************************//
// The Class CoCSimpleDBDS provides a Create and CreateRemote method to          
// create instances of the default interface IParseDisplayName exposed by              
// the CoClass CSimpleDBDS. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCSimpleDBDS = class
    class function Create: IParseDisplayName;
    class function CreateRemote(const MachineName: string): IParseDisplayName;
  end;

// *********************************************************************//
// The Class CoCSimpleDBDSNamespace provides a Create and CreateRemote method to          
// create instances of the default interface IADs exposed by              
// the CoClass CSimpleDBDSNamespace. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCSimpleDBDSNamespace = class
    class function Create: IADs;
    class function CreateRemote(const MachineName: string): IADs;
  end;

// *********************************************************************//
// The Class CoCSimpleDBDSReadOnly provides a Create and CreateRemote method to          
// create instances of the default interface IADs exposed by              
// the CoClass CSimpleDBDSReadOnly. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCSimpleDBDSReadOnly = class
    class function Create: IADs;
    class function CreateRemote(const MachineName: string): IADs;
  end;

// *********************************************************************//
// The Class CoCSimpleDBDSReadWrite provides a Create and CreateRemote method to          
// create instances of the default interface IADs exposed by              
// the CoClass CSimpleDBDSReadWrite. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCSimpleDBDSReadWrite = class
    class function Create: IADs;
    class function CreateRemote(const MachineName: string): IADs;
  end;

// *********************************************************************//
// The Class CoTrafficLogFile_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface ITrafficLogFile_3_0 exposed by              
// the CoClass TrafficLogFile_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoTrafficLogFile_3_0 = class
    class function Create: ITrafficLogFile_3_0;
    class function CreateRemote(const MachineName: string): ITrafficLogFile_3_0;
  end;

// *********************************************************************//
// The Class CoTrafficTable_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface ITrafficTable_3_0 exposed by              
// the CoClass TrafficTable_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoTrafficTable_3_0 = class
    class function Create: ITrafficTable_3_0;
    class function CreateRemote(const MachineName: string): ITrafficTable_3_0;
  end;

implementation

uses ComObj;

class function CoCMSCSLogSink.Create: IMSCSLogSink;
begin
  Result := CreateComObject(CLASS_CMSCSLogSink) as IMSCSLogSink;
end;

class function CoCMSCSLogSink.CreateRemote(const MachineName: string): IMSCSLogSink;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CMSCSLogSink) as IMSCSLogSink;
end;

class function CoCContent.Create: IContent;
begin
  Result := CreateComObject(CLASS_CContent) as IContent;
end;

class function CoCContent.CreateRemote(const MachineName: string): IContent;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CContent) as IContent;
end;

class function CoCDatasource.Create: IDatasource;
begin
  Result := CreateComObject(CLASS_CDatasource) as IDatasource;
end;

class function CoCDatasource.CreateRemote(const MachineName: string): IDatasource;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CDatasource) as IDatasource;
end;

class function CoMSCSDBStorage_3_0.Create: IMSCSDBStorage_3_0;
begin
  Result := CreateComObject(CLASS_MSCSDBStorage_3_0) as IMSCSDBStorage_3_0;
end;

class function CoMSCSDBStorage_3_0.CreateRemote(const MachineName: string): IMSCSDBStorage_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_MSCSDBStorage_3_0) as IMSCSDBStorage_3_0;
end;

class function CoMSCSStandardSManager_3_0.Create: IMSCSStandardSManager_3_0;
begin
  Result := CreateComObject(CLASS_MSCSStandardSManager_3_0) as IMSCSStandardSManager_3_0;
end;

class function CoMSCSStandardSManager_3_0.CreateRemote(const MachineName: string): IMSCSStandardSManager_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_MSCSStandardSManager_3_0) as IMSCSStandardSManager_3_0;
end;

class function CoCNullStream.Create: IStream;
begin
  Result := CreateComObject(CLASS_CNullStream) as IStream;
end;

class function CoCNullStream.CreateRemote(const MachineName: string): IStream;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CNullStream) as IStream;
end;

class function CoCSimpleDBDS.Create: IParseDisplayName;
begin
  Result := CreateComObject(CLASS_CSimpleDBDS) as IParseDisplayName;
end;

class function CoCSimpleDBDS.CreateRemote(const MachineName: string): IParseDisplayName;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CSimpleDBDS) as IParseDisplayName;
end;

class function CoCSimpleDBDSNamespace.Create: IADs;
begin
  Result := CreateComObject(CLASS_CSimpleDBDSNamespace) as IADs;
end;

class function CoCSimpleDBDSNamespace.CreateRemote(const MachineName: string): IADs;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CSimpleDBDSNamespace) as IADs;
end;

class function CoCSimpleDBDSReadOnly.Create: IADs;
begin
  Result := CreateComObject(CLASS_CSimpleDBDSReadOnly) as IADs;
end;

class function CoCSimpleDBDSReadOnly.CreateRemote(const MachineName: string): IADs;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CSimpleDBDSReadOnly) as IADs;
end;

class function CoCSimpleDBDSReadWrite.Create: IADs;
begin
  Result := CreateComObject(CLASS_CSimpleDBDSReadWrite) as IADs;
end;

class function CoCSimpleDBDSReadWrite.CreateRemote(const MachineName: string): IADs;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CSimpleDBDSReadWrite) as IADs;
end;

class function CoTrafficLogFile_3_0.Create: ITrafficLogFile_3_0;
begin
  Result := CreateComObject(CLASS_TrafficLogFile_3_0) as ITrafficLogFile_3_0;
end;

class function CoTrafficLogFile_3_0.CreateRemote(const MachineName: string): ITrafficLogFile_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_TrafficLogFile_3_0) as ITrafficLogFile_3_0;
end;

class function CoTrafficTable_3_0.Create: ITrafficTable_3_0;
begin
  Result := CreateComObject(CLASS_TrafficTable_3_0) as ITrafficTable_3_0;
end;

class function CoTrafficTable_3_0.CreateRemote(const MachineName: string): ITrafficTable_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_TrafficTable_3_0) as ITrafficTable_3_0;
end;

end.
