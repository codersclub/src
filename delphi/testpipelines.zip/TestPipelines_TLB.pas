unit TestPipelines_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/22/99 10:31:52 AM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Sel\d5\PipeLines\TestPipelines.tlb (1)
// IID\LCID: {FDE385B0-87E8-11D3-9460-00A0C9786542}\0
// Helpfile: 
// DepndLst: 
//   (1) v1.0 PIPELINELib, (E:\Microsoft Site Server\Bin\pipeline.dll)
//   (2) v1.0 MSCSCoreLib, (E:\Microsoft Site Server\Bin\MscsCore.dll)
//   (3) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
//   (4) v4.0 StdVCL, (D:\WINDOWS\System32\STDVCL40.DLL)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL, 
  PIPELINELib_TLB, MSCSCoreLib_TLB;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  TestPipelinesMajorVersion = 1;
  TestPipelinesMinorVersion = 0;

  LIBID_TestPipelines: TGUID = '{FDE385B0-87E8-11D3-9460-00A0C9786542}';

  IID_IDumpOrderToXml: TGUID = '{FDE385B1-87E8-11D3-9460-00A0C9786542}';
  CLASS_DumpOrderToXml: TGUID = '{FDE385B3-87E8-11D3-9460-00A0C9786542}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IDumpOrderToXml = interface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  DumpOrderToXml = IDumpOrderToXml;


// *********************************************************************//
// Interface: IDumpOrderToXml
// Flags:     (256) OleAutomation
// GUID:      {FDE385B1-87E8-11D3-9460-00A0C9786542}
// *********************************************************************//
  IDumpOrderToXml = interface(IPipelineComponent)
    ['{FDE385B1-87E8-11D3-9460-00A0C9786542}']
    function  SetXmlFilename(const XmlFileName: WideString): HResult; stdcall;
    function  GetXmlFileName(out XmlFileName: WideString): HResult; stdcall;
    function  ExportDictionaryToXml(const Dict: IDictionary; out XmlStr: WideString): HResult; stdcall;
    function  ExportSimpleListToXml(const List: ISimpleList; out XmlStr: WideString): HResult; stdcall;
  end;

// *********************************************************************//
// The Class CoDumpOrderToXml provides a Create and CreateRemote method to          
// create instances of the default interface IDumpOrderToXml exposed by              
// the CoClass DumpOrderToXml. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoDumpOrderToXml = class
    class function Create: IDumpOrderToXml;
    class function CreateRemote(const MachineName: string): IDumpOrderToXml;
  end;


// *********************************************************************//
// OLE Server Proxy class declaration
// Server Object    : TDumpOrderToXml
// Help String      : DumpOrderToXml Object
// Default Interface: IDumpOrderToXml
// Def. Intf. DISP? : No
// Event   Interface: 
// TypeFlags        : (2) CanCreate
// *********************************************************************//
{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
  TDumpOrderToXmlProperties= class;
{$ENDIF}
  TDumpOrderToXml = class(TOleServer)
  private
    FIntf:        IDumpOrderToXml;
{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
    FProps:       TDumpOrderToXmlProperties;
    function      GetServerProperties: TDumpOrderToXmlProperties;
{$ENDIF}
    function      GetDefaultInterface: IDumpOrderToXml;
  protected
    procedure InitServerData; override;
  public
    constructor Create(AOwner: TComponent); override;
    destructor  Destroy; override;
    procedure Connect; override;
    procedure ConnectTo(svrIntf: IDumpOrderToXml);
    procedure Disconnect; override;
    function  Execute(const pdispOrder: IDispatch; const pdispContext: IDispatch; lFlags: Integer; 
                      out plErrorLevel: Integer): HResult;
    function  EnableDesign(fEnable: Integer): HResult;
    function  SetXmlFilename(const XmlFileName: WideString): HResult;
    function  GetXmlFileName(out XmlFileName: WideString): HResult;
    function  ExportDictionaryToXml(const Dict: IDictionary; out XmlStr: WideString): HResult;
    function  ExportSimpleListToXml(const List: ISimpleList; out XmlStr: WideString): HResult;
    property  DefaultInterface: IDumpOrderToXml read GetDefaultInterface;
  published
{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
    property Server: TDumpOrderToXmlProperties read GetServerProperties;
{$ENDIF}
  end;

{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
// *********************************************************************//
// OLE Server Properties Proxy Class
// Server Object    : TDumpOrderToXml
// (This object is used by the IDE's Property Inspector to allow editing
//  of the properties of this server)
// *********************************************************************//
 TDumpOrderToXmlProperties = class(TPersistent)
  private
    FServer:    TDumpOrderToXml;
    function    GetDefaultInterface: IDumpOrderToXml;
    constructor Create(AServer: TDumpOrderToXml);
  protected
  public
    property DefaultInterface: IDumpOrderToXml read GetDefaultInterface;
  published
  end;
{$ENDIF}


procedure Register;

implementation

uses ComObj;

class function CoDumpOrderToXml.Create: IDumpOrderToXml;
begin
  Result := CreateComObject(CLASS_DumpOrderToXml) as IDumpOrderToXml;
end;

class function CoDumpOrderToXml.CreateRemote(const MachineName: string): IDumpOrderToXml;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_DumpOrderToXml) as IDumpOrderToXml;
end;

procedure TDumpOrderToXml.InitServerData;
const
  CServerData: TServerData = (
    ClassID:   '{FDE385B3-87E8-11D3-9460-00A0C9786542}';
    IntfIID:   '{FDE385B1-87E8-11D3-9460-00A0C9786542}';
    EventIID:  '';
    LicenseKey: nil;
    Version: 500);
begin
  ServerData := @CServerData;
end;

procedure TDumpOrderToXml.Connect;
var
  punk: IUnknown;
begin
  if FIntf = nil then
  begin
    punk := GetServer;
    Fintf:= punk as IDumpOrderToXml;
  end;
end;

procedure TDumpOrderToXml.ConnectTo(svrIntf: IDumpOrderToXml);
begin
  Disconnect;
  FIntf := svrIntf;
end;

procedure TDumpOrderToXml.DisConnect;
begin
  if Fintf <> nil then
  begin
    FIntf := nil;
  end;
end;

function TDumpOrderToXml.GetDefaultInterface: IDumpOrderToXml;
begin
  if FIntf = nil then
    Connect;
  Assert(FIntf <> nil, 'DefaultInterface is NULL. Component is not connected to Server. You must call ''Connect'' or ''ConnectTo'' before this operation');
  Result := FIntf;
end;

constructor TDumpOrderToXml.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
  FProps := TDumpOrderToXmlProperties.Create(Self);
{$ENDIF}
end;

destructor TDumpOrderToXml.Destroy;
begin
{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
  FProps.Free;
{$ENDIF}
  inherited Destroy;
end;

{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
function TDumpOrderToXml.GetServerProperties: TDumpOrderToXmlProperties;
begin
  Result := FProps;
end;
{$ENDIF}

function  TDumpOrderToXml.Execute(const pdispOrder: IDispatch; const pdispContext: IDispatch; 
                                  lFlags: Integer; out plErrorLevel: Integer): HResult;
begin
  Result := DefaultInterface.Execute(pdispOrder, pdispContext, lFlags, plErrorLevel);
end;

function  TDumpOrderToXml.EnableDesign(fEnable: Integer): HResult;
begin
  Result := DefaultInterface.EnableDesign(fEnable);
end;

function  TDumpOrderToXml.SetXmlFilename(const XmlFileName: WideString): HResult;
begin
  Result := DefaultInterface.SetXmlFilename(XmlFileName);
end;

function  TDumpOrderToXml.GetXmlFileName(out XmlFileName: WideString): HResult;
begin
  Result := DefaultInterface.GetXmlFileName(XmlFileName);
end;

function  TDumpOrderToXml.ExportDictionaryToXml(const Dict: IDictionary; out XmlStr: WideString): HResult;
begin
  Result := DefaultInterface.ExportDictionaryToXml(Dict, XmlStr);
end;

function  TDumpOrderToXml.ExportSimpleListToXml(const List: ISimpleList; out XmlStr: WideString): HResult;
begin
  Result := DefaultInterface.ExportSimpleListToXml(List, XmlStr);
end;

{$IFDEF LIVE_SERVER_AT_DESIGN_TIME}
constructor TDumpOrderToXmlProperties.Create(AServer: TDumpOrderToXml);
begin
  inherited Create;
  FServer := AServer;
end;

function TDumpOrderToXmlProperties.GetDefaultInterface: IDumpOrderToXml;
begin
  Result := FServer.DefaultInterface;
end;

{$ENDIF}

procedure Register;
begin
  RegisterComponents('Servers',[TDumpOrderToXml]);
end;

end.
