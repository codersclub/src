unit PIPELINELib_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/22/99 10:31:52 AM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Microsoft Site Server\Bin\pipeline.dll (1)
// IID\LCID: {4D193C12-23AF-11D0-B855-00C04FD7A0F9}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
// Parent TypeLibrary:
//   (0) v1.0 TestPipelines, (E:\Sel\d5\PipeLines\TestPipelines.tlb)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  PIPELINELibMajorVersion = 1;
  PIPELINELibMinorVersion = 0;

  LIBID_PIPELINELib: TGUID = '{4D193C12-23AF-11D0-B855-00C04FD7A0F9}';

  IID_IOrderPipeline: TGUID = '{6703A0B0-9A2F-11D0-B86C-00C04FD7A0F9}';
  IID_IConfigurationCache: TGUID = '{070C1180-0615-11D1-894F-00A0C90543B8}';
  CLASS_COrderPipeline: TGUID = '{4D193C18-23AF-11D0-B855-00C04FD7A0F9}';
  IID_IPipeline: TGUID = '{07D62D90-1E56-11D1-B888-00C04FD7A0F9}';
  CLASS_CTxPipeline: TGUID = '{410FA6BC-E5A5-11D0-893D-00A0C90543B8}';
  CLASS_CMtsPipeline: TGUID = '{ED1BCB00-0778-11D1-894F-00A0C90543B8}';
  IID_IConfigurationCacheHelper: TGUID = '{3B469C81-4BDD-11D1-9072-00A0C90543B8}';
  CLASS_CConfigurationCacheHelper: TGUID = '{3B469C80-4BDD-11D1-9072-00A0C90543B8}';
  IID_IPipelineComponent: TGUID = '{CA215520-9A2F-11D0-B86C-00C04FD7A0F9}';
  IID_IPipelineComponentUI: TGUID = '{1E903F41-9CA8-11D0-BE9D-00A0C90DC855}';
  IID_ISpecifyPipelineComponentUI: TGUID = '{3B6D3961-91C6-11D0-BE9C-00A0C90DC855}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IOrderPipeline = interface;
  IOrderPipelineDisp = dispinterface;
  IConfigurationCache = interface;
  IConfigurationCacheDisp = dispinterface;
  IPipeline = interface;
  IPipelineDisp = dispinterface;
  IConfigurationCacheHelper = interface;
  IConfigurationCacheHelperDisp = dispinterface;
  IPipelineComponent = interface;
  IPipelineComponentUI = interface;
  IPipelineComponentUIDisp = dispinterface;
  ISpecifyPipelineComponentUI = interface;
  ISpecifyPipelineComponentUIDisp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  COrderPipeline = IOrderPipeline;
  CTxPipeline = IPipeline;
  CMtsPipeline = IPipeline;
  CConfigurationCacheHelper = IConfigurationCacheHelper;


// *********************************************************************//
// Interface: IOrderPipeline
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {6703A0B0-9A2F-11D0-B86C-00C04FD7A0F9}
// *********************************************************************//
  IOrderPipeline = interface(IDispatch)
    ['{6703A0B0-9A2F-11D0-B86C-00C04FD7A0F9}']
    function  OrderExecute(lMode: Integer; const pdispOrder: IDispatch; 
                           const pdispContext: IDispatch; lFlags: Integer): Integer; safecall;
    procedure EnableDesign(fEnable: Integer); safecall;
    procedure LoadPipe(const pszFileName: WideString); safecall;
    procedure SetLogFile(const pszFileName: WideString); safecall;
  end;

// *********************************************************************//
// DispIntf:  IOrderPipelineDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {6703A0B0-9A2F-11D0-B86C-00C04FD7A0F9}
// *********************************************************************//
  IOrderPipelineDisp = dispinterface
    ['{6703A0B0-9A2F-11D0-B86C-00C04FD7A0F9}']
    function  OrderExecute(lMode: Integer; const pdispOrder: IDispatch; 
                           const pdispContext: IDispatch; lFlags: Integer): Integer; dispid 1610743808;
    procedure EnableDesign(fEnable: Integer); dispid 1610743809;
    procedure LoadPipe(const pszFileName: WideString); dispid 1610743810;
    procedure SetLogFile(const pszFileName: WideString); dispid 1610743811;
  end;

// *********************************************************************//
// Interface: IConfigurationCache
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {070C1180-0615-11D1-894F-00A0C90543B8}
// *********************************************************************//
  IConfigurationCache = interface(IDispatch)
    ['{070C1180-0615-11D1-894F-00A0C90543B8}']
    function  SaveToCache: WideString; safecall;
    procedure LoadFromCache(const bstrToken: WideString); safecall;
    procedure DeleteCacheEntry(const bstrToken: WideString); safecall;
  end;

// *********************************************************************//
// DispIntf:  IConfigurationCacheDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {070C1180-0615-11D1-894F-00A0C90543B8}
// *********************************************************************//
  IConfigurationCacheDisp = dispinterface
    ['{070C1180-0615-11D1-894F-00A0C90543B8}']
    function  SaveToCache: WideString; dispid 1610743808;
    procedure LoadFromCache(const bstrToken: WideString); dispid 1610743809;
    procedure DeleteCacheEntry(const bstrToken: WideString); dispid 1610743810;
  end;

// *********************************************************************//
// Interface: IPipeline
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {07D62D90-1E56-11D1-B888-00C04FD7A0F9}
// *********************************************************************//
  IPipeline = interface(IDispatch)
    ['{07D62D90-1E56-11D1-B888-00C04FD7A0F9}']
    function  Execute(lMode: Integer; const pdispOrder: IDispatch; const pdispContext: IDispatch; 
                      lFlags: Integer): Integer; safecall;
    procedure EnableDesign(fEnable: Integer); safecall;
    procedure LoadPipe(const pszFileName: WideString); safecall;
    procedure SetLogFile(const pszFileName: WideString); safecall;
  end;

// *********************************************************************//
// DispIntf:  IPipelineDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {07D62D90-1E56-11D1-B888-00C04FD7A0F9}
// *********************************************************************//
  IPipelineDisp = dispinterface
    ['{07D62D90-1E56-11D1-B888-00C04FD7A0F9}']
    function  Execute(lMode: Integer; const pdispOrder: IDispatch; const pdispContext: IDispatch; 
                      lFlags: Integer): Integer; dispid 1610743808;
    procedure EnableDesign(fEnable: Integer); dispid 1610743809;
    procedure LoadPipe(const pszFileName: WideString); dispid 1610743810;
    procedure SetLogFile(const pszFileName: WideString); dispid 1610743811;
  end;

// *********************************************************************//
// Interface: IConfigurationCacheHelper
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3B469C81-4BDD-11D1-9072-00A0C90543B8}
// *********************************************************************//
  IConfigurationCacheHelper = interface(IDispatch)
    ['{3B469C81-4BDD-11D1-9072-00A0C90543B8}']
    function  SaveToCache(const pdispPipeline: IDispatch): WideString; safecall;
    procedure LoadFromCache(const pdispPipeline: IDispatch; const bstrToken: WideString); safecall;
    procedure DeleteCacheEntry(const pdispPipeline: IDispatch; const bstrToken: WideString); safecall;
  end;

// *********************************************************************//
// DispIntf:  IConfigurationCacheHelperDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3B469C81-4BDD-11D1-9072-00A0C90543B8}
// *********************************************************************//
  IConfigurationCacheHelperDisp = dispinterface
    ['{3B469C81-4BDD-11D1-9072-00A0C90543B8}']
    function  SaveToCache(const pdispPipeline: IDispatch): WideString; dispid 1610743808;
    procedure LoadFromCache(const pdispPipeline: IDispatch; const bstrToken: WideString); dispid 1610743809;
    procedure DeleteCacheEntry(const pdispPipeline: IDispatch; const bstrToken: WideString); dispid 1610743810;
  end;

// *********************************************************************//
// Interface: IPipelineComponent
// Flags:     (0)
// GUID:      {CA215520-9A2F-11D0-B86C-00C04FD7A0F9}
// *********************************************************************//
  IPipelineComponent = interface(IUnknown)
    ['{CA215520-9A2F-11D0-B86C-00C04FD7A0F9}']
    function  Execute(const pdispOrder: IDispatch; const pdispContext: IDispatch; lFlags: Integer; 
                      out plErrorLevel: Integer): HResult; stdcall;
    function  EnableDesign(fEnable: Integer): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IPipelineComponentUI
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {1E903F41-9CA8-11D0-BE9D-00A0C90DC855}
// *********************************************************************//
  IPipelineComponentUI = interface(IDispatch)
    ['{1E903F41-9CA8-11D0-BE9D-00A0C90DC855}']
    procedure ShowProperties(const pdispComponent: IDispatch); safecall;
  end;

// *********************************************************************//
// DispIntf:  IPipelineComponentUIDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {1E903F41-9CA8-11D0-BE9D-00A0C90DC855}
// *********************************************************************//
  IPipelineComponentUIDisp = dispinterface
    ['{1E903F41-9CA8-11D0-BE9D-00A0C90DC855}']
    procedure ShowProperties(const pdispComponent: IDispatch); dispid 1610743808;
  end;

// *********************************************************************//
// Interface: ISpecifyPipelineComponentUI
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3B6D3961-91C6-11D0-BE9C-00A0C90DC855}
// *********************************************************************//
  ISpecifyPipelineComponentUI = interface(IDispatch)
    ['{3B6D3961-91C6-11D0-BE9C-00A0C90DC855}']
    function  GetPipelineComponentUIProgID: WideString; safecall;
  end;

// *********************************************************************//
// DispIntf:  ISpecifyPipelineComponentUIDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3B6D3961-91C6-11D0-BE9C-00A0C90DC855}
// *********************************************************************//
  ISpecifyPipelineComponentUIDisp = dispinterface
    ['{3B6D3961-91C6-11D0-BE9C-00A0C90DC855}']
    function  GetPipelineComponentUIProgID: WideString; dispid 1610743808;
  end;

// *********************************************************************//
// The Class CoCOrderPipeline provides a Create and CreateRemote method to          
// create instances of the default interface IOrderPipeline exposed by              
// the CoClass COrderPipeline. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCOrderPipeline = class
    class function Create: IOrderPipeline;
    class function CreateRemote(const MachineName: string): IOrderPipeline;
  end;

// *********************************************************************//
// The Class CoCTxPipeline provides a Create and CreateRemote method to          
// create instances of the default interface IPipeline exposed by              
// the CoClass CTxPipeline. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCTxPipeline = class
    class function Create: IPipeline;
    class function CreateRemote(const MachineName: string): IPipeline;
  end;

// *********************************************************************//
// The Class CoCMtsPipeline provides a Create and CreateRemote method to          
// create instances of the default interface IPipeline exposed by              
// the CoClass CMtsPipeline. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCMtsPipeline = class
    class function Create: IPipeline;
    class function CreateRemote(const MachineName: string): IPipeline;
  end;

// *********************************************************************//
// The Class CoCConfigurationCacheHelper provides a Create and CreateRemote method to          
// create instances of the default interface IConfigurationCacheHelper exposed by              
// the CoClass CConfigurationCacheHelper. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCConfigurationCacheHelper = class
    class function Create: IConfigurationCacheHelper;
    class function CreateRemote(const MachineName: string): IConfigurationCacheHelper;
  end;

implementation

uses ComObj;

class function CoCOrderPipeline.Create: IOrderPipeline;
begin
  Result := CreateComObject(CLASS_COrderPipeline) as IOrderPipeline;
end;

class function CoCOrderPipeline.CreateRemote(const MachineName: string): IOrderPipeline;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_COrderPipeline) as IOrderPipeline;
end;

class function CoCTxPipeline.Create: IPipeline;
begin
  Result := CreateComObject(CLASS_CTxPipeline) as IPipeline;
end;

class function CoCTxPipeline.CreateRemote(const MachineName: string): IPipeline;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CTxPipeline) as IPipeline;
end;

class function CoCMtsPipeline.Create: IPipeline;
begin
  Result := CreateComObject(CLASS_CMtsPipeline) as IPipeline;
end;

class function CoCMtsPipeline.CreateRemote(const MachineName: string): IPipeline;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CMtsPipeline) as IPipeline;
end;

class function CoCConfigurationCacheHelper.Create: IConfigurationCacheHelper;
begin
  Result := CreateComObject(CLASS_CConfigurationCacheHelper) as IConfigurationCacheHelper;
end;

class function CoCConfigurationCacheHelper.CreateRemote(const MachineName: string): IConfigurationCacheHelper;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CConfigurationCacheHelper) as IConfigurationCacheHelper;
end;

end.
