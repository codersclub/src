unit fDumpToXmlProps;

interface

uses SysUtils, Windows, Messages, Classes, Graphics, Controls, StdCtrls,
  ExtCtrls, Forms, ComServ, ComObj, StdVcl, AxCtrls, Dialogs;

type
  TDumpToXMLPropertyPage = class(TPropertyPage)
    Edit1: TEdit;
    Label1: TLabel;
    Button1: TButton;
    SaveDialog1: TSaveDialog;
    procedure Button1Click(Sender: TObject);
  private
    { Private declarations }
  protected
    { Protected declarations }
  public
    { Public declarations }
    procedure UpdatePropertyPage; override;
    procedure UpdateObject; override;
  end;

const
  Class_DumpToXMLPropertyPage: TGUID = '{FDE385BA-87E8-11D3-9460-00A0C9786542}';

implementation

uses uDumpToXml, TestPipelines_TLB;

{$R *.DFM}

procedure TDumpToXMLPropertyPage.UpdatePropertyPage;
var StrXmlFilename: WideString;
begin
  { Update your controls from OleObject }
  (OleObjects.First as IDumpOrderToXml).GetXmlFileName(StrXmlFilename);
  Edit1.Text := StrXmlFilename;
end;

procedure TDumpToXMLPropertyPage.UpdateObject;
var StrXmlFilename: WideString;
begin
  { Update OleObject from your controls }
  StrXmlFilename := Edit1.Text;
  (OleObjects.First as IDumpOrderToXml).SetXmlFileName(StrXmlFilename);
end;

procedure TDumpToXMLPropertyPage.Button1Click(Sender: TObject);
begin
  if SaveDialog1.Execute then begin
    Edit1.Text := SaveDialog1.FileName;
  end;
end;

initialization
  TActiveXPropertyPageFactory.Create(
    ComServer,
    TDumpToXMLPropertyPage,
    Class_DumpToXMLPropertyPage);
end.
