unit MSCSCoreLib_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/22/99 10:31:52 AM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Microsoft Site Server\Bin\MscsCore.dll (1)
// IID\LCID: {B22B5821-2AF3-11D1-A714-00C04FD7A105}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
// Parent TypeLibrary:
//   (0) v1.0 TestPipelines, (E:\Sel\d5\PipeLines\TestPipelines.tlb)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  MSCSCoreLibMajorVersion = 1;
  MSCSCoreLibMinorVersion = 0;

  LIBID_MSCSCoreLib: TGUID = '{B22B5821-2AF3-11D1-A714-00C04FD7A105}';

  IID_IDictionary: TGUID = '{B7990D05-45FD-11D0-8176-00A0C90A90C7}';
  IID_ICloneable: TGUID = '{318CFBF0-68E5-11D0-82CC-00C04FD658E9}';
  IID_IMSCSLogSource: TGUID = '{937F89A8-758F-11D0-AE84-00A0C90543B8}';
  IID_IPersist: TGUID = '{0000010C-0000-0000-C000-000000000046}';
  IID_IPersistXML: TGUID = '{6E48C370-E820-11D0-A373-00C04FD7A104}';
  CLASS_CDictionary: TGUID = '{B7990D09-45FD-11D0-8176-00A0C90A90C7}';
  IID_IOrderForm: TGUID = '{713DD5B2-747C-11D0-BE8A-00A0C90DC855}';
  CLASS_COrderForm: TGUID = '{713DD5B1-747C-11D0-BE8A-00A0C90DC855}';
  IID_ISimpleList: TGUID = '{B7990D0A-45FD-11D0-8176-00A0C90A90C7}';
  CLASS_CSimpleList: TGUID = '{B7990D0E-45FD-11D0-8176-00A0C90A90C7}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IDictionary = interface;
  IDictionaryDisp = dispinterface;
  ICloneable = interface;
  ICloneableDisp = dispinterface;
  IMSCSLogSource = interface;
  IMSCSLogSourceDisp = dispinterface;
  IPersist = interface;
  IPersistXML = interface;
  IPersistXMLDisp = dispinterface;
  IOrderForm = interface;
  IOrderFormDisp = dispinterface;
  ISimpleList = interface;
  ISimpleListDisp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  CDictionary = IDictionary;
  COrderForm = IOrderForm;
  CSimpleList = ISimpleList;


// *********************************************************************//
// Declaration of structures, unions and aliases.                         
// *********************************************************************//
  PPWideChar1 = ^PWideChar; {*}
  POleVariant1 = ^OleVariant; {*}


// *********************************************************************//
// Interface: IDictionary
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionary = interface(IDispatch)
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Value(const bstrName: WideString): OleVariant; safecall;
    procedure _Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    procedure Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    function  Get_Count: Integer; safecall;
    function  Get_Prefix: WideString; safecall;
    procedure Set_Prefix(const pstr: WideString); safecall;
    procedure GetMultiple(cb: Integer; var rgolestr: PWideChar; out rgvar: OleVariant); safecall;
    procedure PutMultiple(cb: Integer; var rgolestr: PWideChar; var rgvar: OleVariant); safecall;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Value[const bstrName: WideString]: OleVariant read Get_Value write _Set_Value; default;
    property Count: Integer read Get_Count;
    property Prefix: WideString read Get_Prefix write Set_Prefix;
  end;

// *********************************************************************//
// DispIntf:  IDictionaryDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionaryDisp = dispinterface
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    property _NewEnum: IUnknown readonly dispid -4;
    property Value[const bstrName: WideString]: OleVariant dispid 0; default;
    property Count: Integer readonly dispid 1;
    property Prefix: WideString dispid 2;
    procedure GetMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; out rgvar: OleVariant); dispid 1610743815;
    procedure PutMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; var rgvar: OleVariant); dispid 1610743816;
  end;

// *********************************************************************//
// Interface: ICloneable
// Flags:     (320) Dual OleAutomation
// GUID:      {318CFBF0-68E5-11D0-82CC-00C04FD658E9}
// *********************************************************************//
  ICloneable = interface(IUnknown)
    ['{318CFBF0-68E5-11D0-82CC-00C04FD658E9}']
    procedure Clone(out doppleganger: ICloneable); safecall;
  end;

// *********************************************************************//
// DispIntf:  ICloneableDisp
// Flags:     (320) Dual OleAutomation
// GUID:      {318CFBF0-68E5-11D0-82CC-00C04FD658E9}
// *********************************************************************//
  ICloneableDisp = dispinterface
    ['{318CFBF0-68E5-11D0-82CC-00C04FD658E9}']
    procedure Clone(out doppleganger: ICloneable); dispid 2;
  end;

// *********************************************************************//
// Interface: IMSCSLogSource
// Flags:     (320) Dual OleAutomation
// GUID:      {937F89A8-758F-11D0-AE84-00A0C90543B8}
// *********************************************************************//
  IMSCSLogSource = interface(IUnknown)
    ['{937F89A8-758F-11D0-AE84-00A0C90543B8}']
    procedure StartLog(const pDispMSCSLogSink: IDispatch; const bstrGivenName: WideString; 
                       lFlags: Integer); safecall;
    procedure StopLog(const pDispMSCSLogSink: IDispatch); safecall;
  end;

// *********************************************************************//
// DispIntf:  IMSCSLogSourceDisp
// Flags:     (320) Dual OleAutomation
// GUID:      {937F89A8-758F-11D0-AE84-00A0C90543B8}
// *********************************************************************//
  IMSCSLogSourceDisp = dispinterface
    ['{937F89A8-758F-11D0-AE84-00A0C90543B8}']
    procedure StartLog(const pDispMSCSLogSink: IDispatch; const bstrGivenName: WideString; 
                       lFlags: Integer); dispid 1610678272;
    procedure StopLog(const pDispMSCSLogSink: IDispatch); dispid 1610678273;
  end;

// *********************************************************************//
// Interface: IPersist
// Flags:     (0)
// GUID:      {0000010C-0000-0000-C000-000000000046}
// *********************************************************************//
  IPersist = interface(IUnknown)
    ['{0000010C-0000-0000-C000-000000000046}']
    function  GetClassID(out pClassID: TGUID): HResult; stdcall;
  end;

// *********************************************************************//
// Interface: IPersistXML
// Flags:     (320) Dual OleAutomation
// GUID:      {6E48C370-E820-11D0-A373-00C04FD7A104}
// *********************************************************************//
  IPersistXML = interface(IPersist)
    ['{6E48C370-E820-11D0-A373-00C04FD7A104}']
    procedure LoadXMLElement(locale: Integer; const pDispXMLElement: IUnknown); safecall;
    procedure LoadXML(locale: Integer; const bstrXML: WideString); safecall;
    function  SaveXML(locale: Integer): WideString; safecall;
  end;

// *********************************************************************//
// DispIntf:  IPersistXMLDisp
// Flags:     (320) Dual OleAutomation
// GUID:      {6E48C370-E820-11D0-A373-00C04FD7A104}
// *********************************************************************//
  IPersistXMLDisp = dispinterface
    ['{6E48C370-E820-11D0-A373-00C04FD7A104}']
    procedure LoadXMLElement(locale: Integer; const pDispXMLElement: IUnknown); dispid 1610743808;
    procedure LoadXML(locale: Integer; const bstrXML: WideString); dispid 1610743809;
    function  SaveXML(locale: Integer): WideString; dispid 1610743810;
    procedure GetClassID(out pClassID: {??TGUID} OleVariant); dispid 1610678272;
  end;

// *********************************************************************//
// Interface: IOrderForm
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {713DD5B2-747C-11D0-BE8A-00A0C90DC855}
// *********************************************************************//
  IOrderForm = interface(IDictionary)
    ['{713DD5B2-747C-11D0-BE8A-00A0C90DC855}']
    function  AddItem(varSKU: OleVariant; lCount: Integer; lPlacedPrice: Integer): IDispatch; safecall;
    procedure ClearOrderForm; safecall;
    procedure ClearItems; safecall;
  end;

// *********************************************************************//
// DispIntf:  IOrderFormDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {713DD5B2-747C-11D0-BE8A-00A0C90DC855}
// *********************************************************************//
  IOrderFormDisp = dispinterface
    ['{713DD5B2-747C-11D0-BE8A-00A0C90DC855}']
    function  AddItem(varSKU: OleVariant; lCount: Integer; lPlacedPrice: Integer): IDispatch; dispid 1610809344;
    procedure ClearOrderForm; dispid 1610809345;
    procedure ClearItems; dispid 1610809346;
    property _NewEnum: IUnknown readonly dispid -4;
    property Value[const bstrName: WideString]: OleVariant dispid 0; default;
    property Count: Integer readonly dispid 1;
    property Prefix: WideString dispid 2;
    procedure GetMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; out rgvar: OleVariant); dispid 1610743815;
    procedure PutMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; var rgvar: OleVariant); dispid 1610743816;
  end;

// *********************************************************************//
// Interface: ISimpleList
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D0A-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  ISimpleList = interface(IDispatch)
    ['{B7990D0A-45FD-11D0-8176-00A0C90A90C7}']
    function  Get_Item(Index: Integer): OleVariant; safecall;
    procedure _Set_Item(Index: Integer; pretval: OleVariant); safecall;
    procedure Set_Item(Index: Integer; pretval: OleVariant); safecall;
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Count: Integer; safecall;
    procedure Add(var pVar: OleVariant); safecall;
    procedure Delete(Index: Integer); safecall;
    property Item[Index: Integer]: OleVariant read Get_Item write _Set_Item; default;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Count: Integer read Get_Count;
  end;

// *********************************************************************//
// DispIntf:  ISimpleListDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D0A-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  ISimpleListDisp = dispinterface
    ['{B7990D0A-45FD-11D0-8176-00A0C90A90C7}']
    property Item[Index: Integer]: OleVariant dispid 0; default;
    property _NewEnum: IUnknown readonly dispid -4;
    property Count: Integer readonly dispid 1;
    procedure Add(var pVar: OleVariant); dispid 2;
    procedure Delete(Index: Integer); dispid 3;
  end;

// *********************************************************************//
// The Class CoCDictionary provides a Create and CreateRemote method to          
// create instances of the default interface IDictionary exposed by              
// the CoClass CDictionary. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCDictionary = class
    class function Create: IDictionary;
    class function CreateRemote(const MachineName: string): IDictionary;
  end;

// *********************************************************************//
// The Class CoCOrderForm provides a Create and CreateRemote method to          
// create instances of the default interface IOrderForm exposed by              
// the CoClass COrderForm. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCOrderForm = class
    class function Create: IOrderForm;
    class function CreateRemote(const MachineName: string): IOrderForm;
  end;

// *********************************************************************//
// The Class CoCSimpleList provides a Create and CreateRemote method to          
// create instances of the default interface ISimpleList exposed by              
// the CoClass CSimpleList. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCSimpleList = class
    class function Create: ISimpleList;
    class function CreateRemote(const MachineName: string): ISimpleList;
  end;

implementation

uses ComObj;

class function CoCDictionary.Create: IDictionary;
begin
  Result := CreateComObject(CLASS_CDictionary) as IDictionary;
end;

class function CoCDictionary.CreateRemote(const MachineName: string): IDictionary;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CDictionary) as IDictionary;
end;

class function CoCOrderForm.Create: IOrderForm;
begin
  Result := CreateComObject(CLASS_COrderForm) as IOrderForm;
end;

class function CoCOrderForm.CreateRemote(const MachineName: string): IOrderForm;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_COrderForm) as IOrderForm;
end;

class function CoCSimpleList.Create: ISimpleList;
begin
  Result := CreateComObject(CLASS_CSimpleList) as ISimpleList;
end;

class function CoCSimpleList.CreateRemote(const MachineName: string): ISimpleList;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CSimpleList) as ISimpleList;
end;

end.
