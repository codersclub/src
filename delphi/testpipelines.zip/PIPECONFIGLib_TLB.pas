unit PIPECONFIGLib_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/19/99 12:56:33 PM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Microsoft Site Server\Bin\PipeConfig.dll (1)
// IID\LCID: {E18DAC23-ECC0-11D0-A18F-00C04FD658FF}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
// Parent TypeLibrary:
//   (0) v1.0 SOPipelines, (E:\Sel\d5\7\SOPipelines.tlb)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  PIPECONFIGLibMajorVersion = 1;
  PIPECONFIGLibMinorVersion = 0;

  LIBID_PIPECONFIGLib: TGUID = '{E18DAC23-ECC0-11D0-A18F-00C04FD658FF}';

  IID_IPipeManager: TGUID = '{E18DAC39-ECC0-11D0-A18F-00C04FD658FF}';
  CLASS_PipeManager: TGUID = '{E18DAC3A-ECC0-11D0-A18F-00C04FD658FF}';
  IID_IDictionary: TGUID = '{B7990D05-45FD-11D0-8176-00A0C90A90C7}';
  IID_ISimpleList: TGUID = '{B7990D0A-45FD-11D0-8176-00A0C90A90C7}';
  IID_IPipelineConfig: TGUID = '{3D851259-F0EC-11D0-9945-00AA00C09443}';
  CLASS_PipelineConfig: TGUID = '{3D85125A-F0EC-11D0-9945-00AA00C09443}';
  IID_IDictDataObject: TGUID = '{6B79E47E-FE18-11D0-9EA3-00805F74836B}';
  CLASS_DictDataObject: TGUID = '{6B79E47F-FE18-11D0-9EA3-00805F74836B}';
  CLASS_CompStdPPG: TGUID = '{D2787283-052E-11D1-BB95-00A0C9083358}';
  CLASS_CompInOutPPG: TGUID = '{D2787284-052E-11D1-BB95-00A0C9083358}';
  CLASS_CompErrorPPG: TGUID = '{CCEF3CD1-1E56-11D1-9EC9-00805F74836B}';
  CLASS_CompCustomPPG: TGUID = '{CCEF3CD2-1E56-11D1-9EC9-00805F74836B}';
  CLASS_PipePPG: TGUID = '{9A176280-289B-11D1-9ED2-00805F74836B}';
  CLASS_StagePPG: TGUID = '{9A176281-289B-11D1-9ED2-00805F74836B}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IPipeManager = interface;
  IPipeManagerDisp = dispinterface;
  IDictionary = interface;
  IDictionaryDisp = dispinterface;
  ISimpleList = interface;
  ISimpleListDisp = dispinterface;
  IPipelineConfig = interface;
  IPipelineConfigDisp = dispinterface;
  IDictDataObject = interface;
  IDictDataObjectDisp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  PipeManager = IPipeManager;
  PipelineConfig = IPipelineConfig;
  DictDataObject = IDictDataObject;
  CompStdPPG = IUnknown;
  CompInOutPPG = IUnknown;
  CompErrorPPG = IUnknown;
  CompCustomPPG = IUnknown;
  PipePPG = IUnknown;
  StagePPG = IUnknown;


// *********************************************************************//
// Declaration of structures, unions and aliases.                         
// *********************************************************************//
  PPWideChar1 = ^PWideChar; {*}
  POleVariant1 = ^OleVariant; {*}


// *********************************************************************//
// Interface: IPipeManager
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {E18DAC39-ECC0-11D0-A18F-00C04FD658FF}
// *********************************************************************//
  IPipeManager = interface(IDispatch)
    ['{E18DAC39-ECC0-11D0-A18F-00C04FD658FF}']
    procedure Save(const bstrFilename: WideString; bOverwrite: Integer); safecall;
    procedure Load(const bstrFilename: WideString); safecall;
    function  GetPipe: IDictionary; safecall;
    function  GetComponent(lStageIndex: Integer; lComponentIndex: Integer): IDictionary; safecall;
    procedure DeleteComponent(lStageIndex: Integer; lComponentIndex: Integer); safecall;
    procedure MoveComponent(lStageIndex: Integer; lCurrentIndex: Integer; lNewIndex: Integer; 
                            bAdvanced: Integer); safecall;
    procedure CreateComponent(const bstrComponentClsid: WideString; const bstrName: WideString; 
                              lStageIndex: Integer; lComponentIndex: Integer); safecall;
    function  CreateStreamFromComponent(lStageIndex: Integer; lComponentIndex: Integer): IUnknown; safecall;
    procedure CreateComponentFromStream(const punkStream: IUnknown; lStageIndex: Integer; 
                                        lComponentIndex: Integer); safecall;
    function  GetComponentsByStageAffinity(const bstrCatGUID: WideString; bAdvanced: Integer): ISimpleList; safecall;
    function  GetStage(lIndex: Integer): IDictionary; safecall;
    procedure DeleteStage(lIndex: Integer); safecall;
    procedure MoveStage(lCurrentIndex: Integer; lNewIndex: Integer); safecall;
    procedure CreateStage(const bstrStageGuid: WideString; const bstrName: WideString; 
                          lIndex: Integer); safecall;
    function  CreateStreamFromStage(lStageIndex: Integer): IUnknown; safecall;
    procedure CreateStageFromStream(const punkStream: IUnknown; lStageIndex: Integer); safecall;
    function  GetComponentPage(const bstrCLSID: WideString): WideString; safecall;
    function  GetComponentName(const bstrCLSID: WideString): WideString; safecall;
  end;

// *********************************************************************//
// DispIntf:  IPipeManagerDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {E18DAC39-ECC0-11D0-A18F-00C04FD658FF}
// *********************************************************************//
  IPipeManagerDisp = dispinterface
    ['{E18DAC39-ECC0-11D0-A18F-00C04FD658FF}']
    procedure Save(const bstrFilename: WideString; bOverwrite: Integer); dispid 1;
    procedure Load(const bstrFilename: WideString); dispid 2;
    function  GetPipe: IDictionary; dispid 5;
    function  GetComponent(lStageIndex: Integer; lComponentIndex: Integer): IDictionary; dispid 6;
    procedure DeleteComponent(lStageIndex: Integer; lComponentIndex: Integer); dispid 7;
    procedure MoveComponent(lStageIndex: Integer; lCurrentIndex: Integer; lNewIndex: Integer; 
                            bAdvanced: Integer); dispid 8;
    procedure CreateComponent(const bstrComponentClsid: WideString; const bstrName: WideString; 
                              lStageIndex: Integer; lComponentIndex: Integer); dispid 9;
    function  CreateStreamFromComponent(lStageIndex: Integer; lComponentIndex: Integer): IUnknown; dispid 10;
    procedure CreateComponentFromStream(const punkStream: IUnknown; lStageIndex: Integer; 
                                        lComponentIndex: Integer); dispid 11;
    function  GetComponentsByStageAffinity(const bstrCatGUID: WideString; bAdvanced: Integer): ISimpleList; dispid 12;
    function  GetStage(lIndex: Integer): IDictionary; dispid 15;
    procedure DeleteStage(lIndex: Integer); dispid 17;
    procedure MoveStage(lCurrentIndex: Integer; lNewIndex: Integer); dispid 18;
    procedure CreateStage(const bstrStageGuid: WideString; const bstrName: WideString; 
                          lIndex: Integer); dispid 19;
    function  CreateStreamFromStage(lStageIndex: Integer): IUnknown; dispid 20;
    procedure CreateStageFromStream(const punkStream: IUnknown; lStageIndex: Integer); dispid 21;
    function  GetComponentPage(const bstrCLSID: WideString): WideString; dispid 22;
    function  GetComponentName(const bstrCLSID: WideString): WideString; dispid 23;
  end;

// *********************************************************************//
// Interface: IDictionary
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionary = interface(IDispatch)
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Value(const bstrName: WideString): OleVariant; safecall;
    procedure _Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    procedure Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    function  Get_Count: Integer; safecall;
    function  Get_Prefix: WideString; safecall;
    procedure Set_Prefix(const pstr: WideString); safecall;
    procedure GetMultiple(cb: Integer; var rgolestr: PWideChar; out rgvar: OleVariant); safecall;
    procedure PutMultiple(cb: Integer; var rgolestr: PWideChar; var rgvar: OleVariant); safecall;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Value[const bstrName: WideString]: OleVariant read Get_Value write _Set_Value; default;
    property Count: Integer read Get_Count;
    property Prefix: WideString read Get_Prefix write Set_Prefix;
  end;

// *********************************************************************//
// DispIntf:  IDictionaryDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionaryDisp = dispinterface
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    property _NewEnum: IUnknown readonly dispid -4;
    property Value[const bstrName: WideString]: OleVariant dispid 0; default;
    property Count: Integer readonly dispid 1;
    property Prefix: WideString dispid 2;
    procedure GetMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; out rgvar: OleVariant); dispid 1610743815;
    procedure PutMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; var rgvar: OleVariant); dispid 1610743816;
  end;

// *********************************************************************//
// Interface: ISimpleList
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D0A-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  ISimpleList = interface(IDispatch)
    ['{B7990D0A-45FD-11D0-8176-00A0C90A90C7}']
    function  Get_Item(Index: Integer): OleVariant; safecall;
    procedure _Set_Item(Index: Integer; pretval: OleVariant); safecall;
    procedure Set_Item(Index: Integer; pretval: OleVariant); safecall;
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Count: Integer; safecall;
    procedure Add(var pVar: OleVariant); safecall;
    procedure Delete(Index: Integer); safecall;
    property Item[Index: Integer]: OleVariant read Get_Item write _Set_Item; default;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Count: Integer read Get_Count;
  end;

// *********************************************************************//
// DispIntf:  ISimpleListDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D0A-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  ISimpleListDisp = dispinterface
    ['{B7990D0A-45FD-11D0-8176-00A0C90A90C7}']
    property Item[Index: Integer]: OleVariant dispid 0; default;
    property _NewEnum: IUnknown readonly dispid -4;
    property Count: Integer readonly dispid 1;
    procedure Add(var pVar: OleVariant); dispid 2;
    procedure Delete(Index: Integer); dispid 3;
  end;

// *********************************************************************//
// Interface: IPipelineConfig
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3D851259-F0EC-11D0-9945-00AA00C09443}
// *********************************************************************//
  IPipelineConfig = interface(IDispatch)
    ['{3D851259-F0EC-11D0-9945-00AA00C09443}']
    function  PipeReadFromStorage(const pIUnkIStorage: IUnknown): IDictionary; safecall;
    procedure PipeWriteToStorage(const pIUnkIStorage: IUnknown; const pIDictionary: IDictionary); safecall;
    function  PipeReadFromFile(const bstrFilename: WideString): IDictionary; safecall;
    procedure PipeWriteToFile(const bstrFilename: WideString; const pIDictionary: IDictionary); safecall;
  end;

// *********************************************************************//
// DispIntf:  IPipelineConfigDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {3D851259-F0EC-11D0-9945-00AA00C09443}
// *********************************************************************//
  IPipelineConfigDisp = dispinterface
    ['{3D851259-F0EC-11D0-9945-00AA00C09443}']
    function  PipeReadFromStorage(const pIUnkIStorage: IUnknown): IDictionary; dispid 1;
    procedure PipeWriteToStorage(const pIUnkIStorage: IUnknown; const pIDictionary: IDictionary); dispid 2;
    function  PipeReadFromFile(const bstrFilename: WideString): IDictionary; dispid 3;
    procedure PipeWriteToFile(const bstrFilename: WideString; const pIDictionary: IDictionary); dispid 4;
  end;

// *********************************************************************//
// Interface: IDictDataObject
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {6B79E47E-FE18-11D0-9EA3-00805F74836B}
// *********************************************************************//
  IDictDataObject = interface(IDispatch)
    ['{6B79E47E-FE18-11D0-9EA3-00805F74836B}']
  end;

// *********************************************************************//
// DispIntf:  IDictDataObjectDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {6B79E47E-FE18-11D0-9EA3-00805F74836B}
// *********************************************************************//
  IDictDataObjectDisp = dispinterface
    ['{6B79E47E-FE18-11D0-9EA3-00805F74836B}']
  end;

// *********************************************************************//
// The Class CoPipeManager provides a Create and CreateRemote method to          
// create instances of the default interface IPipeManager exposed by              
// the CoClass PipeManager. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoPipeManager = class
    class function Create: IPipeManager;
    class function CreateRemote(const MachineName: string): IPipeManager;
  end;

// *********************************************************************//
// The Class CoPipelineConfig provides a Create and CreateRemote method to          
// create instances of the default interface IPipelineConfig exposed by              
// the CoClass PipelineConfig. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoPipelineConfig = class
    class function Create: IPipelineConfig;
    class function CreateRemote(const MachineName: string): IPipelineConfig;
  end;

// *********************************************************************//
// The Class CoDictDataObject provides a Create and CreateRemote method to          
// create instances of the default interface IDictDataObject exposed by              
// the CoClass DictDataObject. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoDictDataObject = class
    class function Create: IDictDataObject;
    class function CreateRemote(const MachineName: string): IDictDataObject;
  end;

// *********************************************************************//
// The Class CoCompStdPPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass CompStdPPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCompStdPPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

// *********************************************************************//
// The Class CoCompInOutPPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass CompInOutPPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCompInOutPPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

// *********************************************************************//
// The Class CoCompErrorPPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass CompErrorPPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCompErrorPPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

// *********************************************************************//
// The Class CoCompCustomPPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass CompCustomPPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCompCustomPPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

// *********************************************************************//
// The Class CoPipePPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass PipePPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoPipePPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

// *********************************************************************//
// The Class CoStagePPG provides a Create and CreateRemote method to          
// create instances of the default interface IUnknown exposed by              
// the CoClass StagePPG. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoStagePPG = class
    class function Create: IUnknown;
    class function CreateRemote(const MachineName: string): IUnknown;
  end;

implementation

uses ComObj;

class function CoPipeManager.Create: IPipeManager;
begin
  Result := CreateComObject(CLASS_PipeManager) as IPipeManager;
end;

class function CoPipeManager.CreateRemote(const MachineName: string): IPipeManager;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_PipeManager) as IPipeManager;
end;

class function CoPipelineConfig.Create: IPipelineConfig;
begin
  Result := CreateComObject(CLASS_PipelineConfig) as IPipelineConfig;
end;

class function CoPipelineConfig.CreateRemote(const MachineName: string): IPipelineConfig;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_PipelineConfig) as IPipelineConfig;
end;

class function CoDictDataObject.Create: IDictDataObject;
begin
  Result := CreateComObject(CLASS_DictDataObject) as IDictDataObject;
end;

class function CoDictDataObject.CreateRemote(const MachineName: string): IDictDataObject;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_DictDataObject) as IDictDataObject;
end;

class function CoCompStdPPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_CompStdPPG) as IUnknown;
end;

class function CoCompStdPPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CompStdPPG) as IUnknown;
end;

class function CoCompInOutPPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_CompInOutPPG) as IUnknown;
end;

class function CoCompInOutPPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CompInOutPPG) as IUnknown;
end;

class function CoCompErrorPPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_CompErrorPPG) as IUnknown;
end;

class function CoCompErrorPPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CompErrorPPG) as IUnknown;
end;

class function CoCompCustomPPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_CompCustomPPG) as IUnknown;
end;

class function CoCompCustomPPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CompCustomPPG) as IUnknown;
end;

class function CoPipePPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_PipePPG) as IUnknown;
end;

class function CoPipePPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_PipePPG) as IUnknown;
end;

class function CoStagePPG.Create: IUnknown;
begin
  Result := CreateComObject(CLASS_StagePPG) as IUnknown;
end;

class function CoStagePPG.CreateRemote(const MachineName: string): IUnknown;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_StagePPG) as IUnknown;
end;

end.
