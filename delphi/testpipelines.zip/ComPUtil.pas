unit ComPUtil;

interface

uses
  Windows, ActiveX, Classes, ComObj, MSCSAspHelpLib_TLB, MSCSCoreLib_TLB;

function GetDictFromDispatch(Disp: IDispatch; var Dict: IDictionary): HRESULT;
function GetSimpleListFromDispatch(Disp: IDispatch; var List: ISimpleList): HRESULT;

function GetNumValueOfVariant(VVar: OleVariant; var Value: Integer): HRESULT;
function GetStringValueOfVariant(VVar: OleVariant; var Value: WideString): HRESULT;

function PutDictValueVariant(Dict: IDictionary; const Name: LPCWSTR; VVar: OleVariant): HRESULT; overload;
function PutDictValue(Dict: IDictionary; const Name: LPCWSTR; Value: Integer): HRESULT; overload;
function PutDictValue(Dict: IDictionary; const Name: LPCWSTR; Value: LPCWSTR): HRESULT; overload;

function GetDictValueVariant(Dict: IDictionary; const Name: LPCWSTR; var VVar: OleVariant): HRESULT; 
function GetDictValue(Dict: IDictionary; const Name: LPCWSTR; var Value: Integer): HRESULT; overload;
function GetDictValue(Dict: IDictionary; const Name: LPCWSTR; var Value: WideString): HRESULT; overload;

function GetListItems(DictOrder: IDictionary; var ListItems: ISimpleList): HRESULT;
function GetNumItems(ListItems: ISimpleList; var Items: Longint): HRESULT;
function GetNthItem(ListItems: ISimpleList; Item: Longint; var DictItem: IDictionary): HRESULT;
function GetListFromDict(DictOrder: IDictionary; const Name: LPCWSTR; var List: ISimpleList): HRESULT;

function DeleteNthItem(List: ISimpleList; Item: Integer): HRESULT;

function AddErrToList(DictOrder: IDictionary; const ErrListName: LPCWSTR;
		      DispContext: IDispatch; const ErrMsgName: LPCWSTR): HRESULT;

function GenUniqueID(var Buf; AddRandom: BOOL): HRESULT; //buffer of length 33
function InitKeyEnumInDict(Dict: IDictionary; var Enum: IEnumVARIANT): HRESULT;
function GetNextKeyInDict(Enum: IEnumVARIANT; var Key: WideString): HRESULT;
function DeInitKeyEnumInDict(var Enum: IEnumVARIANT): HRESULT;

function RegisterCATID(const clsid: TCLSID; newCATID: TIID): HRESULT;
function RegisterName(const clsid: TCLSID; const Name: LPCWSTR): HRESULT;
function RegisterThreadingModel(const clsid: TCLSID; const ThreadingModel: LPCWSTR): HRESULT;

function HResultFromWin32(Win32Err: Integer): HRESULT;

{==============================================================================}

implementation

uses SysUtils;

function GetDictFromDispatch(Disp: IDispatch; var Dict: IDictionary): HRESULT;
begin
  Result := E_INVALIDARG;		// start pessimistic
  if Disp <> nil then begin
    Result := Disp.QueryInterface(IID_IDictionary, Dict);
  end;
end;

function GetSimpleListFromDispatch(Disp: IDispatch; var List: ISimpleList): HRESULT;
begin
  Result := E_INVALIDARG;		// start pessimistic
  if Disp <> nil then begin
    Result := Disp.QueryInterface(IID_ISimpleList, List);
  end;
end;


function GetNumValueOfVariant(VVar: OleVariant; var Value: Integer): HRESULT;
begin
  Value := VVar;
  Result := S_OK;
end;

function GetStringValueOfVariant(VVar: OleVariant; var Value: WideString): HRESULT;
begin
  Value := VVar;
  Result := S_OK;
end;


function PutDictValueVariant(Dict: IDictionary; const Name: LPCWSTR; VVar: OleVariant): HRESULT; overload;
var bstrName: PWideChar;
begin
  Result := S_OK;
  bstrName := SysAllocString(Name);
  if bstrName <> nil then begin
    try
      Dict.Set_Value(bstrName, VVar);
    finally
      SysFreeString(bstrName);
    end;
  end else begin
    Result := E_OUTOFMEMORY;
  end;
end;

function PutDictValue(Dict: IDictionary; const Name: LPCWSTR; Value: Integer): HRESULT; overload;
var bstrName: PWideChar;
begin
  Result := S_OK;
  bstrName := SysAllocString(Name);
  if bstrName <> nil then begin
    try
      Dict.Set_Value(bstrName, Value);
    finally
      SysFreeString(bstrName);
    end;
  end else begin
    Result := E_OUTOFMEMORY;
  end;
end;

function PutDictValue(Dict: IDictionary; const Name: LPCWSTR; Value: LPCWSTR): HRESULT; overload;
var bstrName: PWideChar;
  bstrValue: WideString;
begin
  Result := S_OK;
  bstrName := SysAllocString(Name);
  if bstrName <> nil then begin
    try
      bstrValue := Value;
      Dict.Set_Value(bstrName, bstrValue);
    finally
      SysFreeString(bstrName);
    end;
  end else begin
    Result := E_OUTOFMEMORY;
  end;
end;

function GetDictValueVariant(Dict: IDictionary; const Name: LPCWSTR; var VVar: OleVariant): HRESULT; overload;
var bstrName: PWideChar;
begin
  Result := S_OK;
  bstrName := SysAllocString(Name);
  if bstrName <> nil then begin
    try
      VVar := Dict.Get_Value(bstrName);
    finally
      SysFreeString(bstrName);
    end;
  end else begin
    Result := E_OUTOFMEMORY;
  end;
end;

function GetDictValue(Dict: IDictionary; const Name: LPCWSTR; var Value: Integer): HRESULT; overload;
var VVar: OleVariant;
begin
  Result := GetDictValueVariant(Dict, Name, VVar);
  if Succeeded(Result) then begin
    Value := VVar;
  end;
end;

function GetDictValue(Dict: IDictionary; const Name: LPCWSTR; var Value: WideString): HRESULT; overload;
var VVar: OleVariant;
begin
  Result := GetDictValueVariant(Dict, Name, VVar);
  if Succeeded(Result) then begin
    Value := VVar;
  end;
end;

function GetListItems(DictOrder: IDictionary; var ListItems: ISimpleList): HRESULT;
begin
  Result := GetListFromDict(DictOrder, 'Items', ListItems);
end;

function GetNumItems(ListItems: ISimpleList; var Items: Longint): HRESULT;
begin
  Items := ListItems.Get_Count;
  Result := S_OK;
end;

function GetNthItem(ListItems: ISimpleList; Item: Longint; var DictItem: IDictionary): HRESULT;
var VarItem: OleVariant;
  tVar: Integer;
begin
  VarItem := ListItems.Get_Item(Item);
  if VarIsNull(VarItem) then begin
    Result := E_FAIL;
  end else begin
    tVar := VarType(VarItem);
    if (tVar = varDispatch) or (tVar = varUnknown) then begin
      Result := IDispatch(VarItem).QueryInterface(IID_IDictionary, DictItem);
    end else begin
      Result := E_UNEXPECTED;
    end;
  end;
end;

function GetListFromDict(DictOrder: IDictionary; const Name: LPCWSTR; var List: ISimpleList): HRESULT;
var VarItem: OleVariant;
  tVar: Integer;
begin
  if List = nil then begin
    Result := S_OK;
  end else begin
    Result := GetDictValueVariant(DictOrder, Name, VarItem);
    if Succeeded(Result) then begin
      tVar := VarType(VarItem);
      if (tVar = varDispatch) or (tVar = varUnknown) then begin
        Result := IDispatch(VarItem).QueryInterface(IID_ISimpleList, List);
      end else begin
        Result := E_UNEXPECTED;
      end;
    end;
  end;
end;

function DeleteNthItem(List: ISimpleList; Item: Integer): HRESULT;
begin
  (*plist ? plist->Delete(iItem) : E_INVALIDARG;*)
  if List = nil then begin
    Result := E_INVALIDARG;
  end else begin
    List.Delete(Item);
    Result := S_OK;
  end;
end;

function GetMsgFromMsgMan(DispMsgMan: IDispatch; ErrMsgName: WideString; Language: OleVariant; bstrMessage: WideString): HRESULT;
var MessageMgr: IMSCSMessageManager_3_0;
begin
  Result := DispMsgMan.QueryInterface(IID_IMSCSMessageManager_3_0, MessageMgr);
  try
    if Succeeded(Result) then begin
      bstrMessage := MessageMgr.GetMessage(ErrMsgName, Language);
      Result := S_OK;
    end;
  finally
    MessageMgr := nil;
  end; { try }
end;

function AddErrToList(DictOrder: IDictionary; const ErrListName: LPCWSTR;
		      DispContext: IDispatch; const ErrMsgName: LPCWSTR): HRESULT;
var
  ListErrors: ISimpleList;
  DictContext: IDictionary;
  VarMsgMan, VarLanguage, tmpVar: OleVariant;
  MsgName, MsgValue: PWideChar;
begin
  if (DictOrder = nil) or (ErrListName = nil) or (DispContext = nil) or (ErrMsgName = nil) then begin
    Result := E_INVALIDARG;
  end else begin
    MsgName := SysAllocString(ErrMsgName);
    MsgValue := nil;
    try
      ListErrors := nil;
      DictContext := nil;
      Result := GetListFromDict(DictOrder, ErrListName, ListErrors);
      if Result < 0 then Abort;
      Result := GetDictFromDispatch(DispContext, DictContext);
      if Result < 0 then Abort;
      Result := GetDictValueVariant(DictContext, LPCWSTR(WideString('MessageManager')), VarMsgMan);
      if Result < 0 then Abort;
      if IDispatch(VarMsgMan) <> nil then begin
        Result := GetDictValueVariant(DictContext, LPCWSTR(WideString('Language')), VarLanguage);
        if Result < 0 then Abort;
        Result := GetMsgFromMsgMan(IDispatch(VarMsgMan), MsgName, VarLanguage, MsgValue);
        if Result < 0 then Abort;
        tmpVar := WideString(MsgValue);
        ListErrors.Add(tmpVar);
      end else begin
        Result := E_FAIL;
      end;
    except
      if MsgName <> nil then SysFreeString(MsgName);
      if MsgValue <> nil then SysFreeString(MsgValue);
      DispContext := nil;
      ListErrors := nil;
      Result := E_FAIL;
    end;
  end;
end;

function GenUniqueID(var Buf; AddRandom: BOOL): HRESULT; //buffer of length 33
const _Table = '0123456789ABCDEFGHJKLMNPQRSTUVWX';
var
  Guid: TGUID;
  Data: array[0..19] of Byte;
  R: Word;
  I: Integer;
begin
  Result := CoCreateGuid(Guid);
  if Result <> S_OK then Exit;

  Move(Guid, Data[0], 16);

  if AddRandom then begin
    RandSeed := GetTickCount;
    R := Random(MAXWORD);
    Move(R, Data[16], 2);
    R := Random(MAXWORD);
    Move(R, Data[18], 2);
  end else begin
    FillChar(Data[16], 0, 4);
  end;

  for I := 0 to 3 do begin
    TByteArray(Buf)[I * 8]     := Byte(_Table[Data[I * 5] shr 3]);
    TByteArray(Buf)[I * 8 + 1] := Byte(_Table[(Data[I * 5] and $07) or ((Data[I * 5 + 1] and $03) shl 3)]);
    TByteArray(Buf)[I * 8 + 2] := Byte(_Table[Data[I * 5 + 1] shr 3]);
    TByteArray(Buf)[I * 8 + 3] := Byte(_Table[((Data[I * 5 + 1] and $04) shl 1) or (Data[I * 5 + 2] and $07) or ((Data[I * 5 + 4] and $04) shl 2)]);
    TByteArray(Buf)[I * 8 + 4] := Byte(_Table[Data[I * 5 + 2] shr 3]);
    TByteArray(Buf)[I * 8 + 5] := Byte(_Table[Data[I * 5 + 3] shr 3]);
    TByteArray(Buf)[I * 8 + 6] := Byte(_Table[(Data[I * 5 + 3] and $07) or ((Data[I * 5 + 4] and $03) shl 3)]);
    TByteArray(Buf)[I * 8 + 7] := Byte(_Table[Data[I * 5 + 3] shr 4]);
  end;

  if AddRandom then begin
    TByteArray(Buf)[32] := 0;
  end else begin
    TByteArray(Buf)[26] := 0;
  end;

  Result := S_OK;
end;

function InitKeyEnumInDict(Dict: IDictionary; var Enum: IEnumVARIANT): HRESULT;
var Unk: IUnknown;
begin
  if (Dict = nil) {or (Enum = nil) }then begin
    Result := E_INVALIDARG;
  end else begin
    Unk := Dict._NewEnum;
    try
      if Unk <> nil then begin
        Result := Unk.QueryInterface(IEnumVARIANT, Enum);
      end else begin
        Result := E_NOINTERFACE;
      end;
    finally
      Unk := nil;
    end; { try }
  end;
end;

function GetNextKeyInDict(Enum: IEnumVARIANT; var Key: WideString): HRESULT;
var VarItem: OleVariant;
  OutCard: Cardinal;
begin
  if Enum = nil then begin
    Result := E_INVALIDARG;
  end else begin
    OutCard := 0;
    Result := Enum.Next(1, VarItem, OutCard);
    if Result = S_OK then begin
      Key := VarItem;
      VarItem := NULL;
    end;
  end;
end;

function DeInitKeyEnumInDict(var Enum: IEnumVARIANT): HRESULT;
begin
  if Enum = nil then begin
    Result := E_INVALIDARG;
  end else begin
    Enum := nil;
    Result := S_OK;
  end;
end;

function HResultFromWin32(Win32Err: Integer): HRESULT;
begin
//  HRESULT_FROM_WIN32(x) (x ? ((HRESULT) (((x) & 0x0000FFFF) | (FACILITY_WIN32 << 16) | 0x80000000)) : 0 )
  if (-32768 <= Win32Err) and (Win32Err <= 32767) then begin
    if Win32Err = 0 then begin
      Result := HRESULT(0);
    end else begin
      Result := HRESULT((Win32Err and $0000FFFF) or (FACILITY_WIN32 shl 16) or $80000000);
    end
  end else begin
    Result := E_INVALIDARG;
  end;
end;

function RegisterCATID(const clsid: TCLSID; newCATID: TIID): HRESULT;
var NewKey: WideString;
  strCLSID, strCATID: string;
  lRes: Longint;
  kClass: HKEY;
begin
  strCLSID := GUIDToString(clsid);
  strCATID := GUIDToString(newCATID);

  NewKey := WideString(Format('CLSID\%s\Implemented Categories\%s', [strCLSID, strCATID]));

  Result := S_OK;
  lRes := RegCreateKeyExW(HKEY_CLASSES_ROOT, PWideChar(NewKey), 0, nil, 0,
    KEY_ALL_ACCESS, nil, kClass, nil);
  RegCloseKey( kClass );

  if lRes <> ERROR_SUCCESS then begin
    Result := HResultFromWin32(lRes);
  end;
end;

function RegisterName(const clsid: TCLSID; const Name: LPCWSTR): HRESULT;
var NewKey: WideString;
  strCLSID: string;
  lRes: Longint;
  hK: HKEY;
begin
  strCLSID := GUIDToString(clsid);
  NewKey := WideString(Format('CLSID\%s\AuxUserType\2\', [strCLSID]));

  Result := S_OK;
  lRes := RegCreateKeyExW(HKEY_CLASSES_ROOT, PWideChar(NewKey), 0, nil, 0,
    KEY_ALL_ACCESS, nil, hK, nil);
  if lRes = ERROR_SUCCESS then begin
    lRes := RegSetValueW(hK, nil, REG_SZ, PWideChar(Name),
      Length(Name) * Sizeof(WideChar));
  end;
  RegCloseKey(hK);

  if lRes <> ERROR_SUCCESS then begin
    Result := HResultFromWin32(lRes);
  end;
end;

function RegisterThreadingModel(const clsid: TCLSID; const ThreadingModel: LPCWSTR): HRESULT;
var NewKey: WideString;
  strCLSID: string;
  hK: HKEY;
  lRes: Longint;
begin
  strCLSID := GUIDToString(clsid);
  NewKey := WideString(Format('CLSID\%s\InProcServer32\', [strCLSID]));

  Result := S_OK;
  lRes := RegCreateKeyExW(HKEY_CLASSES_ROOT, PWideChar(NewKey), 0, nil, 0,
    KEY_ALL_ACCESS, nil, hK, nil);
  if lRes = ERROR_SUCCESS then begin
    lRes := RegSetValueExW(hK, PWideChar(ThreadingModel), 0, REG_SZ,
      ThreadingModel, (Length(ThreadingModel)+1) * Sizeof(WideChar));
  end;
  RegCloseKey(hK);

  if lRes <> ERROR_SUCCESS then begin
    Result := HResultFromWin32(lRes);
  end;
end;

end.
