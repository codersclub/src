object DumpToXMLPropertyPage: TDumpToXMLPropertyPage
  Left = 320
  Top = 198
  Width = 511
  Height = 180
  ActiveControl = Edit1
  Caption = 'DumpToXMLPropertyPage'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 16
    Top = 16
    Width = 70
    Height = 13
    Caption = 'XML Filename:'
    FocusControl = Edit1
  end
  object Edit1: TEdit
    Left = 16
    Top = 40
    Width = 281
    Height = 21
    TabOrder = 0
  end
  object Button1: TButton
    Left = 304
    Top = 40
    Width = 75
    Height = 25
    Caption = 'Browse...'
    TabOrder = 1
    OnClick = Button1Click
  end
  object SaveDialog1: TSaveDialog
    Filter = 'XML Files (*.xml)|*.xml|All Files (*.*)|*.*'
    Title = 'Save to XML file'
    Left = 160
    Top = 8
  end
end
