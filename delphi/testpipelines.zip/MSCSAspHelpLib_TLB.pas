unit MSCSAspHelpLib_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88  $
// File generated on 10/21/99 5:29:36 PM from Type Library described below.

// *************************************************************************//
// NOTE:                                                                      
// Items guarded by $IFDEF_LIVE_SERVER_AT_DESIGN_TIME are used by properties  
// which return objects that may need to be explicitly created via a function 
// call prior to any access via the property. These items have been disabled  
// in order to prevent accidental use from within the object inspector. You   
// may enable them by defining LIVE_SERVER_AT_DESIGN_TIME or by selectively   
// removing them from the $IFDEF blocks. However, such items must still be    
// programmatically created via a method of the appropriate CoClass before    
// they can be used.                                                          
// ************************************************************************ //
// Type Lib: E:\Microsoft Site Server\Bin\MSCSAspHelp.dll (1)
// IID\LCID: {23D6A131-2AF5-11D1-A714-00C04FD7A105}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (D:\WINDOWS\System32\STDOLE2.TLB)
// Parent TypeLibrary:
//   (0) v1.0 TestPipelines, (E:\Sel\d5\PipeLines\TestPipelines.tlb)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  MSCSAspHelpLibMajorVersion = 1;
  MSCSAspHelpLibMinorVersion = 0;

  LIBID_MSCSAspHelpLib: TGUID = '{23D6A131-2AF5-11D1-A714-00C04FD7A105}';

  IID_IFileStream: TGUID = '{D55E6A71-556C-11D0-BB6C-00A0C9083358}';
  CLASS_CFileStream: TGUID = '{D55E6A72-556C-11D0-BB6C-00A0C9083358}';
  IID_IDataFunctions_3_0: TGUID = '{CF489F51-3521-11D1-A71A-00C04FD7A105}';
  CLASS_DataFunctions_3_0: TGUID = '{CF489F58-3521-11D1-A71A-00C04FD7A105}';
  IID_IMSCSPage_3_0: TGUID = '{CF489F52-3521-11D1-A71A-00C04FD7A105}';
  CLASS_MSCSPage_3_0: TGUID = '{CF489F59-3521-11D1-A71A-00C04FD7A105}';
  IID_IFileDocument: TGUID = '{00DD0B24-FBB5-11D0-9946-00AA00C09443}';
  CLASS_FileDocument: TGUID = '{00DD0B25-FBB5-11D0-9946-00AA00C09443}';
  IID_IDictionary: TGUID = '{B7990D05-45FD-11D0-8176-00A0C90A90C7}';
  IID_IMSCSMessageManager_3_0: TGUID = '{CF489F53-3521-11D1-A71A-00C04FD7A105}';
  CLASS_MSCSMessageManager_3_0: TGUID = '{CF489F5A-3521-11D1-A71A-00C04FD7A105}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IFileStream = interface;
  IFileStreamDisp = dispinterface;
  IDataFunctions_3_0 = interface;
  IDataFunctions_3_0Disp = dispinterface;
  IMSCSPage_3_0 = interface;
  IMSCSPage_3_0Disp = dispinterface;
  IFileDocument = interface;
  IFileDocumentDisp = dispinterface;
  IDictionary = interface;
  IDictionaryDisp = dispinterface;
  IMSCSMessageManager_3_0 = interface;
  IMSCSMessageManager_3_0Disp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  CFileStream = IFileStream;
  DataFunctions_3_0 = IDataFunctions_3_0;
  MSCSPage_3_0 = IMSCSPage_3_0;
  FileDocument = IFileDocument;
  MSCSMessageManager_3_0 = IMSCSMessageManager_3_0;


// *********************************************************************//
// Declaration of structures, unions and aliases.                         
// *********************************************************************//
  POleVariant1 = ^OleVariant; {*}
  PPWideChar1 = ^PWideChar; {*}


// *********************************************************************//
// Interface: IFileStream
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {D55E6A71-556C-11D0-BB6C-00A0C9083358}
// *********************************************************************//
  IFileStream = interface(IDispatch)
    ['{D55E6A71-556C-11D0-BB6C-00A0C9083358}']
    function  ReadFromFile(const strFilename: WideString): OleVariant; safecall;
    procedure WriteToFile(const strFilename: WideString; var pVar: OleVariant); safecall;
  end;

// *********************************************************************//
// DispIntf:  IFileStreamDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {D55E6A71-556C-11D0-BB6C-00A0C9083358}
// *********************************************************************//
  IFileStreamDisp = dispinterface
    ['{D55E6A71-556C-11D0-BB6C-00A0C9083358}']
    function  ReadFromFile(const strFilename: WideString): OleVariant; dispid 1610743808;
    procedure WriteToFile(const strFilename: WideString; var pVar: OleVariant); dispid 1610743809;
  end;

// *********************************************************************//
// Interface: IDataFunctions_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F51-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IDataFunctions_3_0 = interface(IDispatch)
    ['{CF489F51-3521-11D1-A71A-00C04FD7A105}']
    function  Get_Locale: Integer; safecall;
    procedure Set_Locale(pLocale: Integer); safecall;
    function  ConvertDateString(vtDate: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  ConvertTimeString(vtDate: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  ConvertDateTimeString(vtDateTime: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  ConvertNumberString(vtNum: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  ConvertFloatString(vtNum: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  ConvertMoneyStringToNumber(vtMoney: OleVariant; vtLocale: OleVariant): OleVariant; safecall;
    function  Date(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; safecall;
    function  Time(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; safecall;
    function  DateTime(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; safecall;
    function  Number(lNumber: Integer; vtLocale: OleVariant): OleVariant; safecall;
    function  Float(fNumber: Double; vtLocale: OleVariant): OleVariant; safecall;
    function  Money(lMoney: Integer; vtLocale: OleVariant): OleVariant; safecall;
    function  ValidateNumber(vtNumber: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; safecall;
    function  ValidateFloat(vtNumber: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; safecall;
    function  ValidateDateTime(vtDate: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; safecall;
    function  CleanString(vtInput: OleVariant; vtMinLen: OleVariant; vtMaxLen: OleVariant; 
                          vtStripWhite: OleVariant; vtStripReturn: OleVariant; vtCase: OleVariant; 
                          vtLocale: OleVariant): OleVariant; safecall;
    function  GetLocaleList: OleVariant; safecall;
    function  GetLocaleInfo(vtInfo: Integer; vtLocale: OleVariant): OleVariant; safecall;
    property Locale: Integer read Get_Locale write Set_Locale;
  end;

// *********************************************************************//
// DispIntf:  IDataFunctions_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F51-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IDataFunctions_3_0Disp = dispinterface
    ['{CF489F51-3521-11D1-A71A-00C04FD7A105}']
    property Locale: Integer dispid 1;
    function  ConvertDateString(vtDate: OleVariant; vtLocale: OleVariant): OleVariant; dispid 2;
    function  ConvertTimeString(vtDate: OleVariant; vtLocale: OleVariant): OleVariant; dispid 3;
    function  ConvertDateTimeString(vtDateTime: OleVariant; vtLocale: OleVariant): OleVariant; dispid 4;
    function  ConvertNumberString(vtNum: OleVariant; vtLocale: OleVariant): OleVariant; dispid 5;
    function  ConvertFloatString(vtNum: OleVariant; vtLocale: OleVariant): OleVariant; dispid 6;
    function  ConvertMoneyStringToNumber(vtMoney: OleVariant; vtLocale: OleVariant): OleVariant; dispid 7;
    function  Date(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; dispid 8;
    function  Time(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; dispid 9;
    function  DateTime(dtDate: TDateTime; vtLocale: OleVariant): OleVariant; dispid 10;
    function  Number(lNumber: Integer; vtLocale: OleVariant): OleVariant; dispid 11;
    function  Float(fNumber: Double; vtLocale: OleVariant): OleVariant; dispid 12;
    function  Money(lMoney: Integer; vtLocale: OleVariant): OleVariant; dispid 13;
    function  ValidateNumber(vtNumber: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; dispid 14;
    function  ValidateFloat(vtNumber: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; dispid 15;
    function  ValidateDateTime(vtDate: OleVariant; vtMin: OleVariant; vtMax: OleVariant): OleVariant; dispid 16;
    function  CleanString(vtInput: OleVariant; vtMinLen: OleVariant; vtMaxLen: OleVariant; 
                          vtStripWhite: OleVariant; vtStripReturn: OleVariant; vtCase: OleVariant; 
                          vtLocale: OleVariant): OleVariant; dispid 17;
    function  GetLocaleList: OleVariant; dispid 18;
    function  GetLocaleInfo(vtInfo: Integer; vtLocale: OleVariant): OleVariant; dispid 19;
  end;

// *********************************************************************//
// Interface: IMSCSPage_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F52-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSPage_3_0 = interface(IDispatch)
    ['{CF489F52-3521-11D1-A71A-00C04FD7A105}']
    procedure OnStartPage(const punnk: IUnknown); safecall;
    procedure OnEndPage; safecall;
    function  SURL(const bstrPath: WideString): WideString; safecall;
    function  URL(const bstrPath: WideString): WideString; safecall;
    function  Check(vtCheck: OleVariant): WideString; safecall;
    function  Option(vtVal1: OleVariant; vtVal2: OleVariant): WideString; safecall;
    function  RequestDefault(const bstrName: WideString; vtDefault: OleVariant): OleVariant; safecall;
    function  RequestFloat(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                           vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestDate(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                          vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestTime(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                          vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestDateTime(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                              vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestMoneyAsNumber(const bstrName: WideString; vtDefault: OleVariant; 
                                   vtMin: OleVariant; vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestNumber(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                            vtMax: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  RequestString(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                            vtMax: OleVariant; vtStripWhite: OleVariant; vtStripReturn: OleVariant; 
                            vtCase: OleVariant; vtLocal: OleVariant): OleVariant; safecall;
    function  Encode(vtValue: OleVariant): WideString; safecall;
    function  Decode(vtValue: OleVariant): WideString; safecall;
    function  VerifyWith(const pdispOrder: IDispatch): WideString; safecall;
    procedure ProcessVerifyWith(const pdispOrder: IDispatch); safecall;
    function  GetShopperId: OleVariant; safecall;
    procedure PutShopperId(const bstrShopperID: WideString); safecall;
    function  GetOrderForm: IDispatch; safecall;
    function  RunPlan(const pdispOrder: IDispatch): Integer; safecall;
    function  RunPurchase(const pdispOrder: IDispatch): Integer; safecall;
    function  RunProduct(const pdispOrder: IDispatch): Integer; safecall;
    procedure IncrShopperPerfCtrs; safecall;
    function  Get_Messages: OleVariant; safecall;
    procedure Set_Messages(pvtMessages: OleVariant); safecall;
    function  Get_Context: IDispatch; safecall;
    function  URLPrefix: WideString; safecall;
    function  SURLPrefix: WideString; safecall;
    function  URLArgs: WideString; safecall;
    function  HTMLEncode(vtValue: OleVariant): WideString; safecall;
    function  URLEncode(vtValue: OleVariant): WideString; safecall;
    function  URLShopperArgs: WideString; safecall;
    function  SiteRoot: WideString; safecall;
    function  VirtualDirectory: WideString; safecall;
    property Messages: OleVariant read Get_Messages write Set_Messages;
    property Context: IDispatch read Get_Context;
  end;

// *********************************************************************//
// DispIntf:  IMSCSPage_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F52-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSPage_3_0Disp = dispinterface
    ['{CF489F52-3521-11D1-A71A-00C04FD7A105}']
    procedure OnStartPage(const punnk: IUnknown); dispid 0;
    procedure OnEndPage; dispid 1;
    function  SURL(const bstrPath: WideString): WideString; dispid 2;
    function  URL(const bstrPath: WideString): WideString; dispid 3;
    function  Check(vtCheck: OleVariant): WideString; dispid 4;
    function  Option(vtVal1: OleVariant; vtVal2: OleVariant): WideString; dispid 5;
    function  RequestDefault(const bstrName: WideString; vtDefault: OleVariant): OleVariant; dispid 6;
    function  RequestFloat(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                           vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 7;
    function  RequestDate(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                          vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 8;
    function  RequestTime(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                          vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 9;
    function  RequestDateTime(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                              vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 10;
    function  RequestMoneyAsNumber(const bstrName: WideString; vtDefault: OleVariant; 
                                   vtMin: OleVariant; vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 11;
    function  RequestNumber(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                            vtMax: OleVariant; vtLocal: OleVariant): OleVariant; dispid 12;
    function  RequestString(const bstrName: WideString; vtDefault: OleVariant; vtMin: OleVariant; 
                            vtMax: OleVariant; vtStripWhite: OleVariant; vtStripReturn: OleVariant; 
                            vtCase: OleVariant; vtLocal: OleVariant): OleVariant; dispid 13;
    function  Encode(vtValue: OleVariant): WideString; dispid 14;
    function  Decode(vtValue: OleVariant): WideString; dispid 15;
    function  VerifyWith(const pdispOrder: IDispatch): WideString; dispid 16;
    procedure ProcessVerifyWith(const pdispOrder: IDispatch); dispid 17;
    function  GetShopperId: OleVariant; dispid 18;
    procedure PutShopperId(const bstrShopperID: WideString); dispid 19;
    function  GetOrderForm: IDispatch; dispid 20;
    function  RunPlan(const pdispOrder: IDispatch): Integer; dispid 21;
    function  RunPurchase(const pdispOrder: IDispatch): Integer; dispid 22;
    function  RunProduct(const pdispOrder: IDispatch): Integer; dispid 23;
    procedure IncrShopperPerfCtrs; dispid 24;
    property Messages: OleVariant dispid 25;
    property Context: IDispatch readonly dispid 26;
    function  URLPrefix: WideString; dispid 27;
    function  SURLPrefix: WideString; dispid 28;
    function  URLArgs: WideString; dispid 29;
    function  HTMLEncode(vtValue: OleVariant): WideString; dispid 30;
    function  URLEncode(vtValue: OleVariant): WideString; dispid 31;
    function  URLShopperArgs: WideString; dispid 32;
    function  SiteRoot: WideString; dispid 33;
    function  VirtualDirectory: WideString; dispid 34;
  end;

// *********************************************************************//
// Interface: IFileDocument
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {00DD0B24-FBB5-11D0-9946-00AA00C09443}
// *********************************************************************//
  IFileDocument = interface(IDispatch)
    ['{00DD0B24-FBB5-11D0-9946-00AA00C09443}']
    function  ReadFromFile(const bstrFileName: WideString; const bstrStream: WideString): OleVariant; safecall;
    procedure WriteToFile(const bstrFileName: WideString; const bstrStream: WideString; 
                          var pVar: OleVariant); safecall;
    procedure ReadDictionaryFromFile(const bstrFileName: WideString; const bstrStream: WideString; 
                                     var pIDictInOut: IDictionary); safecall;
    procedure DeleteFromFile(const bstrFileName: WideString; const bstrName: WideString); safecall;
    procedure Rename(const bstrFileName: WideString; const bstrOldName: WideString; 
                     const bstrNewName: WideString); safecall;
    procedure EnumerateStreams(const bstrFileName: WideString; 
                               const bstrStorageToEnumerate: WideString; 
                               out psabstrStreamNames: OleVariant); safecall;
    procedure EnumerateStorages(const bstrFileName: WideString; 
                                const bstrStorageToEnumerate: WideString; 
                                out psabstrStreamNames: OleVariant); safecall;
    procedure CreateEmptyStorage(const bstrFileName: WideString; const bstrStorageName: WideString); safecall;
    procedure Copy(const bstrFileName: WideString; const bstrOldName: WideString; 
                   const bstrNewName: WideString); safecall;
    function  StreamExists(const bstrFileName: WideString; const bstrStreamName: WideString): WordBool; safecall;
    function  StorageExists(const bstrFileName: WideString; const bstrStorageName: WideString): WordBool; safecall;
  end;

// *********************************************************************//
// DispIntf:  IFileDocumentDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {00DD0B24-FBB5-11D0-9946-00AA00C09443}
// *********************************************************************//
  IFileDocumentDisp = dispinterface
    ['{00DD0B24-FBB5-11D0-9946-00AA00C09443}']
    function  ReadFromFile(const bstrFileName: WideString; const bstrStream: WideString): OleVariant; dispid 1;
    procedure WriteToFile(const bstrFileName: WideString; const bstrStream: WideString; 
                          var pVar: OleVariant); dispid 2;
    procedure ReadDictionaryFromFile(const bstrFileName: WideString; const bstrStream: WideString; 
                                     var pIDictInOut: IDictionary); dispid 3;
    procedure DeleteFromFile(const bstrFileName: WideString; const bstrName: WideString); dispid 4;
    procedure Rename(const bstrFileName: WideString; const bstrOldName: WideString; 
                     const bstrNewName: WideString); dispid 5;
    procedure EnumerateStreams(const bstrFileName: WideString; 
                               const bstrStorageToEnumerate: WideString; 
                               out psabstrStreamNames: OleVariant); dispid 6;
    procedure EnumerateStorages(const bstrFileName: WideString; 
                                const bstrStorageToEnumerate: WideString; 
                                out psabstrStreamNames: OleVariant); dispid 7;
    procedure CreateEmptyStorage(const bstrFileName: WideString; const bstrStorageName: WideString); dispid 8;
    procedure Copy(const bstrFileName: WideString; const bstrOldName: WideString; 
                   const bstrNewName: WideString); dispid 9;
    function  StreamExists(const bstrFileName: WideString; const bstrStreamName: WideString): WordBool; dispid 10;
    function  StorageExists(const bstrFileName: WideString; const bstrStorageName: WideString): WordBool; dispid 11;
  end;

// *********************************************************************//
// Interface: IDictionary
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionary = interface(IDispatch)
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    function  Get__NewEnum: IUnknown; safecall;
    function  Get_Value(const bstrName: WideString): OleVariant; safecall;
    procedure _Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    procedure Set_Value(const bstrName: WideString; newVal: OleVariant); safecall;
    function  Get_Count: Integer; safecall;
    function  Get_Prefix: WideString; safecall;
    procedure Set_Prefix(const pstr: WideString); safecall;
    procedure GetMultiple(cb: Integer; var rgolestr: PWideChar; out rgvar: OleVariant); safecall;
    procedure PutMultiple(cb: Integer; var rgolestr: PWideChar; var rgvar: OleVariant); safecall;
    property _NewEnum: IUnknown read Get__NewEnum;
    property Value[const bstrName: WideString]: OleVariant read Get_Value write _Set_Value; default;
    property Count: Integer read Get_Count;
    property Prefix: WideString read Get_Prefix write Set_Prefix;
  end;

// *********************************************************************//
// DispIntf:  IDictionaryDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B7990D05-45FD-11D0-8176-00A0C90A90C7}
// *********************************************************************//
  IDictionaryDisp = dispinterface
    ['{B7990D05-45FD-11D0-8176-00A0C90A90C7}']
    property _NewEnum: IUnknown readonly dispid -4;
    property Value[const bstrName: WideString]: OleVariant dispid 0; default;
    property Count: Integer readonly dispid 1;
    property Prefix: WideString dispid 2;
    procedure GetMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; out rgvar: OleVariant); dispid 1610743815;
    procedure PutMultiple(cb: Integer; var rgolestr: {??PWideChar} OleVariant; var rgvar: OleVariant); dispid 1610743816;
  end;

// *********************************************************************//
// Interface: IMSCSMessageManager_3_0
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F53-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSMessageManager_3_0 = interface(IDispatch)
    ['{CF489F53-3521-11D1-A71A-00C04FD7A105}']
    function  Get_defaultLanguage: WideString; safecall;
    procedure Set_defaultLanguage(const pstr: WideString); safecall;
    procedure AddLanguage(const bstrLanguage: WideString; Locale: Integer); safecall;
    procedure AddMessage(const bstrName: WideString; const bstrMessage: WideString; 
                         vtLanguage: OleVariant); safecall;
    function  GetMessage(const bstrName: WideString; vtLanguage: OleVariant): WideString; safecall;
    function  GetLocale(vtLanguage: OleVariant): Integer; safecall;
    property defaultLanguage: WideString read Get_defaultLanguage;
  end;

// *********************************************************************//
// DispIntf:  IMSCSMessageManager_3_0Disp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {CF489F53-3521-11D1-A71A-00C04FD7A105}
// *********************************************************************//
  IMSCSMessageManager_3_0Disp = dispinterface
    ['{CF489F53-3521-11D1-A71A-00C04FD7A105}']
    property defaultLanguage: WideString readonly dispid 1610743808;
    procedure AddLanguage(const bstrLanguage: WideString; Locale: Integer); dispid 42;
    procedure AddMessage(const bstrName: WideString; const bstrMessage: WideString; 
                         vtLanguage: OleVariant); dispid 43;
    function  GetMessage(const bstrName: WideString; vtLanguage: OleVariant): WideString; dispid 44;
    function  GetLocale(vtLanguage: OleVariant): Integer; dispid 45;
  end;

// *********************************************************************//
// The Class CoCFileStream provides a Create and CreateRemote method to          
// create instances of the default interface IFileStream exposed by              
// the CoClass CFileStream. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoCFileStream = class
    class function Create: IFileStream;
    class function CreateRemote(const MachineName: string): IFileStream;
  end;

// *********************************************************************//
// The Class CoDataFunctions_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface IDataFunctions_3_0 exposed by              
// the CoClass DataFunctions_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoDataFunctions_3_0 = class
    class function Create: IDataFunctions_3_0;
    class function CreateRemote(const MachineName: string): IDataFunctions_3_0;
  end;

// *********************************************************************//
// The Class CoMSCSPage_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface IMSCSPage_3_0 exposed by              
// the CoClass MSCSPage_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoMSCSPage_3_0 = class
    class function Create: IMSCSPage_3_0;
    class function CreateRemote(const MachineName: string): IMSCSPage_3_0;
  end;

// *********************************************************************//
// The Class CoFileDocument provides a Create and CreateRemote method to          
// create instances of the default interface IFileDocument exposed by              
// the CoClass FileDocument. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoFileDocument = class
    class function Create: IFileDocument;
    class function CreateRemote(const MachineName: string): IFileDocument;
  end;

// *********************************************************************//
// The Class CoMSCSMessageManager_3_0 provides a Create and CreateRemote method to          
// create instances of the default interface IMSCSMessageManager_3_0 exposed by              
// the CoClass MSCSMessageManager_3_0. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoMSCSMessageManager_3_0 = class
    class function Create: IMSCSMessageManager_3_0;
    class function CreateRemote(const MachineName: string): IMSCSMessageManager_3_0;
  end;

implementation

uses ComObj;

class function CoCFileStream.Create: IFileStream;
begin
  Result := CreateComObject(CLASS_CFileStream) as IFileStream;
end;

class function CoCFileStream.CreateRemote(const MachineName: string): IFileStream;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_CFileStream) as IFileStream;
end;

class function CoDataFunctions_3_0.Create: IDataFunctions_3_0;
begin
  Result := CreateComObject(CLASS_DataFunctions_3_0) as IDataFunctions_3_0;
end;

class function CoDataFunctions_3_0.CreateRemote(const MachineName: string): IDataFunctions_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_DataFunctions_3_0) as IDataFunctions_3_0;
end;

class function CoMSCSPage_3_0.Create: IMSCSPage_3_0;
begin
  Result := CreateComObject(CLASS_MSCSPage_3_0) as IMSCSPage_3_0;
end;

class function CoMSCSPage_3_0.CreateRemote(const MachineName: string): IMSCSPage_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_MSCSPage_3_0) as IMSCSPage_3_0;
end;

class function CoFileDocument.Create: IFileDocument;
begin
  Result := CreateComObject(CLASS_FileDocument) as IFileDocument;
end;

class function CoFileDocument.CreateRemote(const MachineName: string): IFileDocument;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_FileDocument) as IFileDocument;
end;

class function CoMSCSMessageManager_3_0.Create: IMSCSMessageManager_3_0;
begin
  Result := CreateComObject(CLASS_MSCSMessageManager_3_0) as IMSCSMessageManager_3_0;
end;

class function CoMSCSMessageManager_3_0.CreateRemote(const MachineName: string): IMSCSMessageManager_3_0;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_MSCSMessageManager_3_0) as IMSCSMessageManager_3_0;
end;

end.
