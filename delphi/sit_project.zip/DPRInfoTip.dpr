library DPRInfoTip;

uses
  ComServ,
  DPRInfoTip_TLB in 'DPRInfoTip_TLB.pas',
  UDPRInfoTip in 'UDPRInfoTip.pas' {DPRInfoTip: CoClass};

exports
  DllGetClassObject,
  DllCanUnloadNow,
  DllRegisterServer,
  DllUnregisterServer;

{$R *.TLB}

{$R *.RES}

begin
end.
