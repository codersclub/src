unit DPRInfoTip_TLB;

// ************************************************************************ //
// WARNING                                                                    
// -------                                                                    
// The types declared in this file were generated from data read from a       
// Type Library. If this type library is explicitly or indirectly (via        
// another type library referring to this type library) re-imported, or the   
// 'Refresh' command of the Type Library Editor activated while editing the   
// Type Library, the contents of this file will be regenerated and all        
// manual modifications will be lost.                                         
// ************************************************************************ //

// PASTLWTR : $Revision:   1.88.1.0.1.0  $
// File generated on 12/12/00 11:30:16 PM from Type Library described below.

// ************************************************************************ //
// Type Lib: C:\Program Files\Borland\Delphi5\Projects\DPR InfoTip\DPRInfoTip.tlb (1)
// IID\LCID: {B20433A5-D083-11D4-993A-00D00912C440}\0
// Helpfile: 
// DepndLst: 
//   (1) v2.0 stdole, (C:\DEV_PC\SYSTEM\stdole2.tlb)
//   (2) v4.0 StdVCL, (C:\DEV_PC\SYSTEM\STDVCL40.DLL)
// ************************************************************************ //
{$TYPEDADDRESS OFF} // Unit must be compiled without type-checked pointers. 
interface

uses Windows, ActiveX, Classes, Graphics, OleServer, OleCtrls, StdVCL;

// *********************************************************************//
// GUIDS declared in the TypeLibrary. Following prefixes are used:        
//   Type Libraries     : LIBID_xxxx                                      
//   CoClasses          : CLASS_xxxx                                      
//   DISPInterfaces     : DIID_xxxx                                       
//   Non-DISP interfaces: IID_xxxx                                        
// *********************************************************************//
const
  // TypeLibrary Major and minor versions
  DPRInfoTipMajorVersion = 1;
  DPRInfoTipMinorVersion = 0;

  LIBID_DPRInfoTip: TGUID = '{B20433A5-D083-11D4-993A-00D00912C440}';

  IID_IDPRInfoTip: TGUID = '{B20433A6-D083-11D4-993A-00D00912C440}';
  CLASS_DPRInfoTip: TGUID = '{B20433A8-D083-11D4-993A-00D00912C440}';
type

// *********************************************************************//
// Forward declaration of types defined in TypeLibrary                    
// *********************************************************************//
  IDPRInfoTip = interface;
  IDPRInfoTipDisp = dispinterface;

// *********************************************************************//
// Declaration of CoClasses defined in Type Library                       
// (NOTE: Here we map each CoClass to its Default Interface)              
// *********************************************************************//
  DPRInfoTip = IDPRInfoTip;


// *********************************************************************//
// Interface: IDPRInfoTip
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B20433A6-D083-11D4-993A-00D00912C440}
// *********************************************************************//
  IDPRInfoTip = interface(IDispatch)
    ['{B20433A6-D083-11D4-993A-00D00912C440}']
  end;

// *********************************************************************//
// DispIntf:  IDPRInfoTipDisp
// Flags:     (4416) Dual OleAutomation Dispatchable
// GUID:      {B20433A6-D083-11D4-993A-00D00912C440}
// *********************************************************************//
  IDPRInfoTipDisp = dispinterface
    ['{B20433A6-D083-11D4-993A-00D00912C440}']
  end;

// *********************************************************************//
// The Class CoDPRInfoTip provides a Create and CreateRemote method to          
// create instances of the default interface IDPRInfoTip exposed by              
// the CoClass DPRInfoTip. The functions are intended to be used by             
// clients wishing to automate the CoClass objects exposed by the         
// server of this typelibrary.                                            
// *********************************************************************//
  CoDPRInfoTip = class
    class function Create: IDPRInfoTip;
    class function CreateRemote(const MachineName: string): IDPRInfoTip;
  end;

implementation

uses ComObj;

class function CoDPRInfoTip.Create: IDPRInfoTip;
begin
  Result := CreateComObject(CLASS_DPRInfoTip) as IDPRInfoTip;
end;

class function CoDPRInfoTip.CreateRemote(const MachineName: string): IDPRInfoTip;
begin
  Result := CreateRemoteComObject(MachineName, CLASS_DPRInfoTip) as IDPRInfoTip;
end;

end.
