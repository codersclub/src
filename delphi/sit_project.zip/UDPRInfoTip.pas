unit UDPRInfoTip;

interface

uses
  ComObj, ActiveX, DPRInfoTip_TLB, StdVcl, ShlObj, Windows, SysUtils;

const
  gc_FileExt = '.dpr';

type
  TDPRInfoTip = class(TAutoObject, IDPRInfoTip, IQueryInfo, IPersistFile, IPersist)
  protected
    pMalloc: IMalloc;
    FFile:   string;

    {IQueryInfo}
    function GetInfoTip(dwFlags: DWORD; var ppwszTip: PWideChar): HResult; stdcall;
    function GetInfoFlags(out pdwFlags: DWORD): HResult; stdcall;

    {IPersistFile}
    function IsDirty: HResult; stdcall;
    function Load(pszFileName: POleStr; dwMode: Longint): HResult; stdcall;
    function Save(pszFileName: POleStr; fRemember: BOOL): HResult; stdcall;
    function SaveCompleted(pszFileName: POleStr): HResult; stdcall;
    function GetCurFile(out pszFileName: POleStr): HResult; stdcall;

    {IPersist} // need to implement, since IPersistFile is derived from IPersist
    function GetClassID(out classID: TCLSID): HResult; stdcall;

    //function to read DPR
    function GetDPRInfo : string;
  public
    procedure  Initialize; override;
    destructor Destroy; override;
  end;

  TDFMInfoTipFactory = class(TAutoObjectFactory)
  protected
    procedure ApproveShellExtension(Register: Boolean; const ClsID: string);
    function  GetProgID: string; override;
  public
    procedure UpdateRegistry(Register: Boolean); override;
  end;

implementation

uses
  ComServ, Classes, Registry;

{ TDPRInfoTip }

procedure TDPRInfoTip.Initialize;
begin
  inherited;

  if Failed(ShGetMalloc(pMalloc)) then
    pMalloc := nil;
end;

destructor TDPRInfoTip.Destroy;
begin
  inherited;
  pMalloc := nil;
end;

function TDPRInfoTip.GetInfoTip(dwFlags: DWORD;
  var ppwszTip: PWideChar): HResult;
var
  szTip: string;

begin
  Result := S_OK;

  // The current file name is in FFile through IPersistFile
  szTip    := GetDPRInfo;
  ppwszTip := pMalloc.Alloc(SizeOf(WideChar) * (Length(szTip) + 1));

  if (ppwszTip <> nil) then
    ppwszTip := StringToWideChar(szTip, ppwszTip, SizeOf(WideChar) *
      Length(szTip) + 1);
end;

function TDPRInfoTip.GetInfoFlags(out pdwFlags: DWORD): HResult;
begin
  pdwFlags := 0;
  Result   := E_NOTIMPL;
end;

function TDPRInfoTip.IsDirty: HResult;
begin
  Result := E_NOTIMPL;
end;

function TDPRInfoTip.Load(pszFileName: POleStr; dwMode: Integer): HResult;
begin
  FFile  := pszFileName;
  Result := S_OK;
end;

function TDPRInfoTip.Save(pszFileName: POleStr; fRemember: BOOL): HResult;
begin
  Result := E_NOTIMPL;
end;

function TDPRInfoTip.SaveCompleted(pszFileName: POleStr): HResult;
begin
  Result := E_NOTIMPL;
end;

function TDPRInfoTip.GetCurFile(out pszFileName: POleStr): HResult;
begin
  Result := E_NOTIMPL;
end;

function TDPRInfoTip.GetClassID(out classID: TCLSID): HResult;
begin
  Result := E_NOTIMPL;
end;

function TDPRInfoTip.GetDPRInfo: string;

  function TitleCase(Value: string): string;
  begin
    Result := UpperCase(Copy(Value, 1, 1)) +
      LowerCase(Copy(Value, 2, Length(Value)));
  end;

var
  FStream: TMemoryStream;
  Data:    PChar;
  WorkStr: string;

begin
  if FFile = '' then Exit;

  FStream := TMemoryStream.Create;
  try
    FStream.LoadFromFile(FFile);

    Data    := PChar(FStream.Memory);
    WorkStr := StrPas(Data);

    Result := 'File: ' + ExtractFileName(FFile) + #13#10;
    Result := Result + 'Type: ' + TitleCase(Copy(WorkStr, 1, 7)) + #13#10;
    Result := Result + 'Name: ' + Copy(WorkStr, 9, Pos(';', WorkStr) - 9) + #13#10;
    Result := Result + 'Size: ' + IntToStr(Length(WorkStr)) + ' bytes';
  finally
    FStream.Free;
  end;
end;

{ TDFMInfoTipFactory }

procedure TDFMInfoTipFactory.ApproveShellExtension(Register: Boolean;
  const ClsID: string);
// This registry entry is required in order for the extension to
// operate correctly under Windows NT.
const
  SApproveKey = 'SOFTWARE\Microsoft\Windows\CurrentVersion\Shell Extensions\Approved';

begin
  with TRegistry.Create do
  try
    RootKey := HKEY_LOCAL_MACHINE;

    if not OpenKey(SApproveKey, True) then Exit;
    if Register then
      WriteString(ClsID, Description)
    else
      DeleteValue(ClsID);
  finally
    Free;
  end;
end;

function TDFMInfoTipFactory.GetProgID: string;
begin
  // ProgID not needed for shell extension
  Result := '';
end;

procedure TDFMInfoTipFactory.UpdateRegistry(Register: Boolean);
var
  ClsID: string;

begin
  ClsID := GUIDToString(ClassID);
  inherited UpdateRegistry(Register);

  ApproveShellExtension(Register, ClsID);
  if Register then
    CreateRegKey(gc_FileExt + '\shellex\' + SID_IQueryInfo, '', ClsID)
  else
    DeleteRegKey(gc_FileExt + '\shellex\' + SID_IQueryInfo);
end;

initialization
  TAutoObjectFactory.Create(ComServer, TDPRInfoTip, Class_DPRInfoTip,
    ciMultiInstance, tmApartment);
end.
