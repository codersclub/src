unit NewUser;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, FileCtrl, ImgList, ComCtrls, ExtCtrls;

type
  TfrmNewUser = class(TForm)
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    TabSheet3: TTabSheet;
    Label1: TLabel;
    txtUser: TEdit;
    Label2: TLabel;
    txtPassword: TEdit;
    ImageList1: TImageList;
    DriveComboBox1: TDriveComboBox;
    DirectoryListBox1: TDirectoryListBox;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    chkUpload: TCheckBox;
    chkDownload: TCheckBox;
    chkRename: TCheckBox;
    chkDelete: TCheckBox;
    Bevel1: TBevel;
    Bevel2: TBevel;
    Bevel3: TBevel;
    procedure FormShow(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    Execute : Boolean;
  end;

var
  frmNewUser: TfrmNewUser;

implementation

{$R *.DFM}

procedure TfrmNewUser.FormShow(Sender: TObject);
begin
PageControl1.ActivePage := tabsheet1;
Execute := false;
end;

procedure TfrmNewUser.BitBtn2Click(Sender: TObject);
begin
Execute := false;
end;

procedure TfrmNewUser.BitBtn1Click(Sender: TObject);
begin
Execute := true;
end;

end.
