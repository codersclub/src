program ftpServer;

uses
  Forms,
  Main in 'Main.pas' {frmMain},
  NewUser in 'NewUser.pas' {frmNewUser},
  Dir in 'Dir.pas' {frmDir},
  About in 'About.pas' {frmAbout};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'FTP Server';
  Application.CreateForm(TfrmMain, frmMain);
  Application.CreateForm(TfrmNewUser, frmNewUser);
  Application.CreateForm(TfrmDir, frmDir);
  Application.CreateForm(TfrmAbout, frmAbout);
  Application.Run;
end.
