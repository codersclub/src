FTP Server

By: Bryan Cairns

This is an ecapsulation of the ICS - Internet Component Suite.
ICS can be found at : http://users.swing.be/francois.piette/indexuk.htm
Please take the time to look at the code and learn something.
If you're a Dephi Pro, you can probably give me some tips as I am still
new to Delphi programming.

Bryan Cairns
cairnsb@ameritech.net