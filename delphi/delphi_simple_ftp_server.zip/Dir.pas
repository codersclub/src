unit Dir;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, Buttons, FileCtrl;

type
  TfrmDir = class(TForm)
    DriveComboBox1: TDriveComboBox;
    DirectoryListBox1: TDirectoryListBox;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    procedure BitBtn2Click(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    Execute : Boolean;
  end;

var
  frmDir: TfrmDir;

implementation

{$R *.DFM}

procedure TfrmDir.BitBtn2Click(Sender: TObject);
begin
Execute := true;
close;
end;

procedure TfrmDir.BitBtn1Click(Sender: TObject);
begin
Execute := false;
close;
end;

end.
