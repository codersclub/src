unit CounterUnit;

interface

uses
  Windows, Messages, SysUtils, Classes, HTTPApp;

type
  TWebModule1 = class(TWebModule)
    procedure WebModule1WebActionItem1Action(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WebModule1: TWebModule1;

implementation

{$R *.DFM}

uses
  ExtCtrls, StdCtrls, Controls, Forms, Graphics, JPEG;

procedure GetPaths(Request: TWebRequest; var ScriptPath, LocalPath : String);
var
  ScriptFileName : String;
begin
  ScriptPath := Request.ScriptName;
  ScriptFileName := ExtractFileName(ParamStr(0));
  // Chop off the EXE/DLL name so that we get the path
  Delete(ScriptPath,Pos(ScriptFileName,ScriptPath)-1,Length(ScriptFileName)+1);
  // Chop off leading '/'
  Delete(ScriptPath,1,1);

  LocalPath := ExtractFilePath(ParamStr(0));
  // Chopping off the ScriptPath gives us the root path
  Delete(LocalPath,Pos(ScriptPath,LocalPath)-1,Length(ScriptPath)+1);
end;

procedure SetVariable(var S : String; const Value, Default : String);
begin
  S := Value;
  if S = '' then
    S := Default;
end;

procedure TWebModule1.WebModule1WebActionItem1Action(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
var
  ScriptPath,
  LocalPath,
  FileName,
  Txt, FontColor,
  BackgroundColor,
  FontName,
  FontSize        : String;
  Today, LastEver,
  Ever, LastToday : Integer;
  LastDate        : TDate;
  MS              : TMemoryStream;
  Panel           : TPanel;
  Memo            : TMemo;
  Bitmap          : TBitmap;
  Form            : TForm;
  fp              : TextFile;
begin
  GetPaths(Request,ScriptPath,LocalPath);
  LocalPath := LocalPath+'counters\';

  with Request.QueryFields do begin
    FileName := LocalPath+Values['FileName']+'.txt';
    SetVariable(Txt,Values['Txt'],'You are visitor %d today, and %d ever.');
    SetVariable(FontName,Values['FontName'],'Arial');
    SetVariable(FontSize,Values['FontSize'],'10');
    SetVariable(FontColor,Values['FontColor'],'clWhite');
    SetVariable(BackgroundColor,Values['BackgroundColor'],'clBlack');
  end;
  try
    // Write a new empty counter file if it doesn't exist
    if not FileExists(FileName) then begin
      AssignFile(fp,FileName);
      Rewrite(fp);
      WriteLn(fp,0);
      WriteLn(fp,Date);
      WriteLn(fp,0);
      CloseFile(fp);
    end;

    // Read the old counter values
    AssignFile(fp,FileName);
    Reset(fp);
    ReadLn(fp,LastEver);
    Ever := LastEver+1;
    ReadLn(fp,LastDate);
    ReadLn(fp,LastToday);
    if Date = LastDate then
      Today := LastToday+1
    else
      Today := 1;
    CloseFile(fp);

    // Write the new counter values
    AssignFile(fp,FileName);
    Rewrite(fp);
    WriteLn(fp,Ever);
    WriteLn(fp,Date);
    WriteLn(fp,Today);
    CloseFile(fp);

    Form := TForm.Create(nil);
    with Form.Font do begin
      Name := FontName;
      Size := StrToInt(FontSize);
    end;
    Txt := Format(Txt,[Today,Ever]);
    Panel := TPanel.Create(nil);
    with Panel do begin
      BevelInner := bvRaised;
      BevelOuter := bvLowered;
      Parent := Form;
      Width := Form.Canvas.TextWidth(Txt)+9;
      Height := Form.Canvas.TextHeight(Txt)+9;
    end;
    Memo := TMemo.Create(nil);
    with Memo do begin
      Top := 2;
      Left := 2;
      Width := Panel.Width-5;
      Height := Panel.Height-5;
      Alignment := taCenter;
      Color := StringToColor(BackgroundColor);
      BorderStyle := bsNone;
      Parent := Panel;
    end;
    Bitmap := TBitmap.Create;
    with Bitmap do begin
      Width := Panel.Width-1;
      Height := Panel.Height-1;
      Canvas.Lock;
      Panel.PaintTo(Canvas.Handle,0,0);
      Canvas.Unlock;
      Canvas.Brush.Style := bsClear;
      with Canvas.Font do begin
        Name := FontName;
        Size := StrToInt(FontSize);
        Color := StringToColor(FontColor);
      end;
      Canvas.TextOut(4,3,Txt);
    end;
    with Response do begin
      MS := TMemoryStream.Create;
      with TJPEGImage.Create do begin
        CompressionQuality := 75;
        Assign(Bitmap);
        SaveToStream(MS);
        Free;
      end;
      ContentType := 'image/jpeg';
      MS.Position := 0;
      SendResponse;
      SendStream(MS);
    end;
    Panel.Free;
    Bitmap.Free;
    Form.Free;
  except
    on E: Exception do
      Response.Content := E.Message;
  end;
  Handled := True;
end;

end.

