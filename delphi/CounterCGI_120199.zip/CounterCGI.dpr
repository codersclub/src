program CounterCGI;

{$APPTYPE CONSOLE}

uses
  WebBroker,
  CGIApp,
  CounterUnit in 'CounterUnit.pas' {WebModule1: TWebModule};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TWebModule1, WebModule1);
  Application.Run;
end.
