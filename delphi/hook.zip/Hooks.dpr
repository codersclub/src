program Hooks;

uses
  Forms,
  MainFormUnit in 'MainFormUnit.pas' {MainForm},
  Local in 'Local.pas',
  Global in 'Global.pas';

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TMainForm, MainForm);
  Application.Run;
end.
