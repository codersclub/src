{
   Sample application of the XOR algorithm for a simple
   Crypt program

   Author: Colin Laplace (webmaster@bloodshed.nu)

   Public domain. Use this program at your own risk, and don't use
   it if you are not allowed in your country/state
}
program Crypt;
{$APPTYPE CONSOLE}
uses Windows;

var key, text, longkey, result : string;
    i : integer;
    toto, c : char;
    F : TextFile;
begin
  writeln('Enter the key:');
  readln(key);
  writeln('Enter the text:');
  readln(text);

  for i := 0 to (length(text) div length(key)) do
      longkey := longkey + key;

  for i := 1 to length(text) do begin
      toto := chr((ord(text[i]) XOR ord(longkey[i]))); // XOR algorithm
      result := result + toto;
  end;
  writeln('The crypted text is:');
  writeln(result);
  write('Should i save it to result.txt ?');
  read(c);
  if c in ['Y','y'] then begin
     AssignFile(F,'result.txt');
     Rewrite(F);
     Writeln(F,result);
     CloseFile(F);
  end;
end.
