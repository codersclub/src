Simple crypt/decrypt programs which demonstrate the use of the 
XOR algorithm.
Sources compile under Delphi (binaries compiled with 3.0)

Author: Colin Laplace (webmaster@bloodshed.nu)

Public domain and for educational purpose.
Use this program at your own risk, and don't use
it if you are not allowed in your country

Greetings,
Colin
www.bloodshed.nu