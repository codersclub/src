{
   Sample application of the XOR algorithm for a simple
   Decrypt program

   Author: Colin Laplace (webmaster@bloodshed.nu)

   Public domain. Use this program at your own risk, and don't use
   it if you are not allowed in your country
}
program Decrypt;
{$APPTYPE CONSOLE}
uses Windows;

var key, c_text, longkey, result : string;
    i : integer;
    toto : char;
    F : TextFile;
begin
  writeln('Enter the key:');
  readln(key);
  writeln('Please make sure you have the file "result.txt" in the current directory');
  // it takes the output file from Crypt.exe
  AssignFile(F,'result.txt');
  Reset(F);
  Readln(F,c_text);
  CloseFile(F);

  for i := 0 to (length(c_text) div length(key)) do
      longkey := longkey + key;

  for i := 1 to length(c_text) do begin
      toto := chr((ord(c_text[i]) XOR ord(longkey[i]))); // XOR algorithm
      result := result + toto;
  end;
  writeln('The decrypted text is:');
  writeln(result);
  readln;
end.
