object Form1: TForm1
  Left = 206
  Top = 137
  Width = 211
  Height = 99
  Caption = 'Example2/Process1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Button1: TButton
    Left = 16
    Top = 8
    Width = 169
    Height = 25
    Caption = 'Load DLL and set hook'
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 16
    Top = 40
    Width = 169
    Height = 25
    Caption = 'TurnOff the hook'
    Enabled = False
    TabOrder = 1
    OnClick = Button2Click
  end
end
