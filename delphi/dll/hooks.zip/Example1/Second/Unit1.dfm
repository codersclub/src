object Form1: TForm1
  Left = 192
  Top = 103
  Width = 209
  Height = 103
  Caption = 'Example1/Process2'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnClose = FormClose
  PixelsPerInch = 96
  TextHeight = 13
  object Button1: TButton
    Left = 16
    Top = 8
    Width = 169
    Height = 25
    Caption = 'Load DLL and set hook'
    TabOrder = 0
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 16
    Top = 40
    Width = 169
    Height = 25
    Caption = 'TurnOff the hook'
    Enabled = False
    TabOrder = 1
    OnClick = Button2Click
  end
end
