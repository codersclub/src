program prZoom;

uses
  Forms,
  uZoom in 'uZoom.pas' {Form1},
  uAbout in 'uAbout.pas' {AboutBox};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'gZoom';
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
