unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls;

type
  TAbout = class(TForm)
    Image1: TImage;
    Okay: TImage;
    procedure Image1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure OkayClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  About: TAbout;

implementation

uses Unit1;

{$R *.DFM}

procedure TAbout.Image1MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
begin
  ReleaseCapture;
  If Shift = [ssLeft] Then Perform(WM_SysCommand, $F012, 0);
end;

procedure TAbout.OkayClick(Sender: TObject);
begin
  Close;
end;

end.
