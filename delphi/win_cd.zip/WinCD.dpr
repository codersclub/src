program WinCD;

uses
  Forms,
  Unit1 in 'Unit1.pas' {Win_CD},
  Unit2 in 'Unit2.pas' {About};

{$R *.RES}

begin
  Application.Initialize;
  Application.Title := 'Compact Disc Player';
  Application.CreateForm(TWin_CD, Win_CD);
  Application.CreateForm(TAbout, About);
  Application.Run;
end.
