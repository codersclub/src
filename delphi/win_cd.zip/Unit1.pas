unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ExtCtrls, StdCtrls, MPlayer, Menus, ShellAPI, Registry;

type
  TWin_CD = class(TForm)
    Images: TImage;
    Previous: TImage;
    Rewind: TImage;
    Play: TImage;
    Pause: TImage;
    Stop: TImage;
    FastForward: TImage;
    Next: TImage;
    Eject: TImage;
    Title: TImage;
    UpdateTimer: TTimer;
    Minimize: TImage;
    Toggle: TImage;
    Close: TImage;
    Panel1: TPanel;
    Progress: TImage;
    Label1: TLabel;
    Time: TLabel;
    Label2: TLabel;
    Track: TLabel;
    Back: TImage;
    Slider: TImage;
    Media: TMediaPlayer;
    Tracks: TListBox;
    PopupMenu1: TPopupMenu;
    AlwaysonTop1: TMenuItem;
    N1: TMenuItem;
    Play1: TMenuItem;
    Pause1: TMenuItem;
    Stop1: TMenuItem;
    Rewind1: TMenuItem;
    Forward1: TMenuItem;
    PreviousTrack1: TMenuItem;
    N2: TMenuItem;
    LastTrack1: TMenuItem;
    N3: TMenuItem;
    About1: TMenuItem;
    Quit1: TMenuItem;
    N4: TMenuItem;
    Eject1: TMenuItem;
    PopupMenu2: TPopupMenu;
    Minimize1: TMenuItem;
    ToggleSmallWindow1: TMenuItem;
    Close1: TMenuItem;
    PopupMenu3: TPopupMenu;
    AlwaysonTop2: TMenuItem;
    N5: TMenuItem;
    Play2: TMenuItem;
    Pause2: TMenuItem;
    Stop2: TMenuItem;
    Rewind10Secs1: TMenuItem;
    Forward10Secs1: TMenuItem;
    N6: TMenuItem;
    PreviousTrack2: TMenuItem;
    NextTrack1: TMenuItem;
    N7: TMenuItem;
    Eject2: TMenuItem;
    N8: TMenuItem;
    About2: TMenuItem;
    Quit2: TMenuItem;
    N9: TMenuItem;
    Minimize2: TMenuItem;
    ToggleSmallWindow2: TMenuItem;
    N10: TMenuItem;
    SmallStatus: TLabel;
    Scanning: TLabel;
    procedure PaintImage(Sender: TObject);
    procedure DownImage(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure UpImage(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure FormCreate(Sender: TObject);
    procedure FormMove(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
    procedure Update(Sender: TObject);
    procedure CloseClick(Sender: TObject);
    procedure PlayClick(Sender: TObject);
    procedure PauseClick(Sender: TObject);
    procedure StopClick(Sender: TObject);
    procedure PreviousClick(Sender: TObject);
    procedure NextClick(Sender: TObject);
    procedure EjectClick(Sender: TObject);
    procedure TimeClick(Sender: TObject);
    procedure MinimizeClick(Sender: TObject);
    procedure TracksClick(Sender: TObject);
    procedure Rewind1Click(Sender: TObject);
    procedure Forward1Click(Sender: TObject);
    procedure AlwaysonTop1Click(Sender: TObject);
    procedure About1Click(Sender: TObject);
    procedure ToggleClick(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormActivate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure WndProc(var msg : TMessage);
  end;

Type CDStates = (cdOffline,cdPlaying,cdStopped,cdNotReady,cdPaused);
     TrackDetail = Record
                     TrackStart: longint;
                     TrackLength: longint;
                   end;
     CDDetail = record
                  CDTitle: string[80];
                  Artist: string[80];
                  TotalTracks: integer;
                  CDLength: longint;
                  TrackDetail: array[1..99] of TrackDetail;
                end;

var
  Win_CD: TWin_CD;
  PlayerStatus: CDStates;
  CurrentTrack: Integer;
  CurrentCD: CDDetail;
  CDPosition: Integer;
  TrackPosition: Integer;
  CDRemaining: Integer;
  CurRemaining: Integer;
  FF: Boolean;
  RW: Boolean;
  TimeDetail: Integer;
  IconData: TNOTIFYICONDATA;
  FWindowHandle: HWND;
  DoOnce: Boolean;
  Path: String;

implementation

uses Unit2;

{$R *.DFM}

function ZeroFill(Size: Integer; S: String): String;
begin
  While Length(S) < Size do S := '0'+S;
  Result := S;
end;

Function MilliToTime(T: LongInt): String;
begin
  Result := ZeroFill(2,Inttostr((T Div 1000) Div 60)) + ':' +
            ZeroFill(2,Inttostr((T Div 1000) mod 60));
end;

procedure SetupNewCD;
var X: integer;
begin
  Win_CD.Tracks.Items.Clear;
  Win_CD.Media.Timeformat := tfMilliseconds;
  CurrentCD.TotalTracks:=Win_CD.Media.Tracks;
  CurrentCD.CDLength:=Win_CD.Media.Length;
  for X := 1 to CurrentCD.TotalTracks do
  begin
    CurrentCD.TrackDetail[X].TrackStart := Win_CD.Media.TrackPosition[X];
    CurrentCD.TrackDetail[X].TrackLength := Win_CD.Media.TrackLength[X];
    Win_CD.Tracks.Items.Add(ZeroFill(2,Inttostr(X))+' : '+MilliToTime(Win_CD.Media.TrackLength[X]));
  end;
  CurrentTrack := 1;
  FF := False;
  RW := False;
  PlayerStatus := cdStopped;
end;

procedure GotoPosition(pos: longint);
begin
  Win_CD.Media.Position:=pos;
end;

procedure GotoTrack(tracknum: integer);
begin
  If PlayerStatus = cdPlaying Then
  Begin
    PlayerStatus := cdPaused;
    Win_CD.Media.Pause;
  End;
  if (tracknum<=CurrentCD.TotalTracks) and (tracknum>0) then
    GotoPosition(CurrentCD.TrackDetail[tracknum].TrackStart);
  If PlayerStatus = cdPaused Then
  Begin
    PlayerStatus := cdPlaying;
    Win_CD.Media.Resume;
  End;
end;

procedure GetPositions;
Var Old, X: integer;
begin
  CDPosition := Win_CD.Media.Position;
  Old := CurrentTrack;
  for X := 1 to CurrentCD.TotalTracks do
    If CDPosition >= CurrentCD.TrackDetail[X].TrackStart then CurrentTrack := X;

  If CurrentTrack <> Old Then Win_CD.Tracks.ItemIndex := CurrentTrack - 1;
  TrackPosition := CDPosition - CurrentCD.TrackDetail[CurrentTrack].TrackStart;
  CDRemaining := CurrentCD.CDLength - CDPosition;
  CurRemaining := CurrentCD.TrackDetail[CurrentTrack].TrackLength - TrackPosition;
end;

procedure TWin_CD.PaintImage(Sender: TObject);
Var Index: Integer;
    UpDown: Integer;
    W, H: Integer;
begin
  Index := Strtoint((Sender as TImage).Hint);
  UpDown := (Sender as TImage).Tag;
  W := (Sender as TImage).Width; H := (Sender as TImage).Height;
  Case Index of
    // Buttons
    0..1 : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(Index*23,30+(UpDown*18),W,H));
    2    : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(46,30+(UpDown*18),W,H));
    3..7 : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(46+(Index*23),30+(UpDown*18),W,H));
    // Title Bar
    8    : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(0,UpDown*15,W,H));
    // Minimize
    9    : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(243,UpDown*15,W,H));
    // Toggle
    10   : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(254,UpDown*15,W,H));
    // Close
    11   : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(264,UpDown*15,W,H));
    // Progress Bar
    12   : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(0,66,W,H));
    // Slider
    13   : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(257,66,W,H));
    // Background
    14   : (Sender as TImage).Canvas.CopyRect(Bounds(0,0,W,H), Images.Canvas, Bounds(0,82,W,H));
  End;
end;

procedure TWin_CD.DownImage(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  If Shift <> [ssLeft] Then Exit;
  If (Sender as TImage).Hint = '1' Then
  Begin
    If PlayerStatus = cdPlaying Then
    Begin
      Media.Pause;
      PlayerStatus := cdPaused;
    End;
    RW := True;
    UpdateTimer.Interval := 10;
  End;
  If (Sender as TImage).Hint = '5' Then
  Begin
    If PlayerStatus = cdPlaying Then
    Begin
      Media.Pause;
      PlayerStatus := cdPaused;
    End;
    FF := True;
    UpdateTimer.Interval := 10;
  End;
  If Shift = [ssLeft] Then (Sender as TImage).Tag := 1;
  PaintImage(Sender);
end;

procedure TWin_CD.UpImage(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  If (Sender as TImage).Hint = '1' Then
  Begin
    If PlayerStatus = cdPaused Then
    Begin
      Media.Play;
      PlayerStatus := cdPlaying;
    End;
    RW := False;
    UpdateTimer.Interval := 970;
  End;
  If (Sender as TImage).Hint = '5' Then
  Begin
    If PlayerStatus = cdPaused Then
    Begin
      Media.Play;
      PlayerStatus := cdPlaying;
    End;
    FF := False;
    UpdateTimer.Interval := 970;
  End;
  (Sender as TImage).Tag := 0;
  PaintImage(Sender);
end;

procedure TWin_CD.FormCreate(Sender: TObject);
Var L: Integer;
    Drive: String;
    Reg: TRegistry;
begin
  WindowState := wsNormal; // No Maximize !!
  Color := clBlack;
  Reg := TRegistry.Create;
  Reg.RootKey := HKEY_LOCAL_MACHINE;
  TimeDetail := 1;
  If Reg.OpenKey('Software\Twilight Software',False) Then
  Begin
    Path := Reg.ReadString('FileLocation');
    Left := Reg.ReadInteger('LeftPos');
    Top := Reg.ReadInteger('TopPos');
    TimeDetail := Reg.ReadInteger('TimeDetail');
    If Reg.ReadBool('StayOnTop') Then Alwaysontop1.Click;
    If Reg.ReadInteger('WindowState') = 1 Then ToggleClick(Self);;
  End;
  Reg.Free;
  If Not FileExists('Graphics.BMP') Then
  Begin
    MessageDlg('Error! Graphics Theme file not found.'+#13+#13+'Filename "Graphics.BMP"',mtError,[mbOK],0);
    Application.Terminate;
    Exit;
  End;
  FWindowHandle := AllocateHWnd(WndProc);
  IconData.cbSize := SizeOf(TNOTIFYICONDATA);
  IconData.wnd := FWindowHandle;
  IconData.uID := 0;
  IconData.uFlags := NIF_MESSAGE + NIF_ICON + NIF_TIP;
  IconData.hIcon := Application.Icon.Handle;
  StrPCopy(IconData.szTip,'WinCD - By Scottie G');
  IconData.uCallbackMessage := WM_USER+1;
  DoOnce := False;
  For L := Ord('C') to Ord('Z') do
  begin
    drive := Chr(L)+':\'+#0;
    if GetDriveType(Pchar(drive)) = DRIVE_CDROM then
    begin
      Media.FileName:=Chr(L)+':\Track01.cda';
      Exit;
    end;
  end;
  MessageDlg('Error! CD-Rom Drive Not Found!',mtError,[mbOK],0);
  Application.Terminate;
end;

procedure TWin_CD.FormMove(Sender: TObject; Button: TMouseButton; Shift: TShiftState; X, Y: Integer);
begin
  If (Sender is TLabel) and (Shift = [ssLeft])Then TimeClick(Sender);
  ReleaseCapture;
  If Shift = [ssLeft] Then Win_CD.Perform(WM_SysCommand, $F012, 0);
end;

procedure TWin_CD.Update(Sender: TObject);
Var TrackLength: Integer;
begin
  If (Active) and (Title.Tag <> 0) Then
  Begin
    Title.Tag := 0;
    PaintImage(Title);
  End
  Else
  If (Not Active) and (Title.Tag <> 1) Then
  Begin
    Title.Tag := 1;
    PaintImage(Title);
  End;
  GetPositions;
  If TrackPosition = 0 Then
  Begin
    If PlayerStatus = cdOffline Then SetupnewCD;
  End;
  GetPositions;
  If (Tracks.Items.Count = 0) or (TrackPosition < 0) Then
  Begin
    Tracks.Items.Clear;
    CurrentTrack := 0;
    TrackPosition := 0;
    CDPosition := 0;
    CurRemaining := 0;
    CDRemaining := 0;
    PlayerStatus := cdOffline;
  End;

  Track.Caption := ZeroFill(2,Inttostr(CurrentTrack));
  Case TimeDetail of
    1: Begin
         Label2.Caption := 'Elapsed:';
         Time.Caption := MilliToTime(TrackPosition);
         SmallStatus.Caption := 'Track '+Inttostr(CurrentTrack)+' - '+MilliToTime(TrackPosition);
       End;
    2: Begin
         Label2.Caption := 'Remaining:';
         Time.Caption := MilliToTime(CurRemaining);
         SmallStatus.Caption := 'Track '+Inttostr(CurrentTrack)+' - '+MilliToTime(CurRemaining);
       End;
    3: Begin
         Label2.Caption := 'CD Elapsed:';
         Time.Caption := MilliToTime(CDPosition-2000);
         SmallStatus.Caption := 'Track '+Inttostr(CurrentTrack)+' - '+MilliToTime(CDPosition-2000);
       End;
    4: Begin
         Label2.Caption := 'CD Remaining:';
         Time.Caption := MilliToTime(CDRemaining);
         SmallStatus.Caption := 'Track '+Inttostr(CurrentTrack)+' - '+MilliToTime(CDRemaining);
       End;
  End;

  StrPCopy(IconData.szTip,SmallStatus.Caption);
  Shell_NotifyIcon(NIM_MODIFY,@IconData);

  If RW Then GotoPosition(Media.Position-1000);
  If FF Then GotoPosition(Media.Position+1000);

  TrackLength := CurrentCD.TrackDetail[CurrentTrack].TrackLength;
  Slider.Left := 9 + Round((238 / (TrackLength+1)) * TrackPosition);
end;

procedure TWin_CD.CloseClick(Sender: TObject);
Var Reg: TRegistry;
begin
  Reg := TRegistry.Create;
  Reg.RootKey := HKEY_LOCAL_MACHINE;
  Reg.OpenKey('Software\Twilight Software',True);
  Reg.WriteInteger('LeftPos',Left);
  Reg.WriteInteger('TopPos',Top);
  Reg.WriteInteger('TimeDetail',TimeDetail);
  Reg.WriteBool('StayOnTop',Alwaysontop1.Checked);
  If Height = 15 Then Reg.WriteInteger('WindowState',1) Else Reg.WriteInteger('WindowState',0);
  Reg.Free;
  Shell_NotifyIcon(NIM_DELETE,@IconData);
  Application.Terminate;
end;

procedure TWin_CD.PlayClick(Sender: TObject);
begin
  If PlayerStatus = cdOffline Then
  Begin
    SetupNewCD;
  End;
  PlayerStatus := cdPlaying;
  Media.Play;
end;

procedure TWin_CD.PauseClick(Sender: TObject);
begin
  PlayerStatus := cdStopped;
  Media.Pause;
end;

procedure TWin_CD.StopClick(Sender: TObject);
begin
  PlayerStatus := cdStopped;
  Media.Stop;
  GotoTrack(CurrentTrack);
end;

procedure TWin_CD.PreviousClick(Sender: TObject);
begin
  Dec(CurrentTrack);
  GotoTrack(CurrentTrack);
end;

procedure TWin_CD.NextClick(Sender: TObject);
begin
  Inc(CurrentTrack);
  GotoTrack(CurrentTrack);
end;

procedure TWin_CD.EjectClick(Sender: TObject);
begin
  Media.Stop;
  Media.Eject;
end;

procedure TWin_CD.TimeClick(Sender: TObject);
begin
  If PlayerStatus = cdOffline Then Exit;
  Inc(TimeDetail);
  If TimeDetail > 4 Then TimeDetail := 1;
  Update(Sender);
end;

procedure TWin_CD.MinimizeClick(Sender: TObject);
begin
  WindowState := wsMinimized;
end;

procedure TWin_CD.TracksClick(Sender: TObject);
Var A: Integer;
begin
  For A := 0 to Tracks.Items.Count - 1 do
    If Tracks.Selected[A] Then CurrentTrack := A + 1;
  GotoTrack(CurrentTrack);
end;

procedure TWin_CD.Rewind1Click(Sender: TObject);
begin
  Media.Pause;
  GotoPosition(Media.Position-10000);
  Media.Resume;
end;

procedure TWin_CD.Forward1Click(Sender: TObject);
begin
  Media.Pause;
  GotoPosition(Media.Position+10000);
  Media.Resume;
end;

procedure TWin_CD.AlwaysonTop1Click(Sender: TObject);
begin
  Alwaysontop1.Checked := Not Alwaysontop1.Checked;
  If Alwaysontop1.Checked Then
    FormStyle := fsStayontop
  Else
    FormStyle := fsNormal;
  Alwaysontop2.Checked := Alwaysontop1.Checked;
end;

procedure TWin_CD.About1Click(Sender: TObject);
begin
  About.Show;
end;

procedure TWin_CD.ToggleClick(Sender: TObject);
begin
  If Height <> 15 Then Height := 15 Else Height := 121;
  If Title.Popupmenu = Popupmenu3 Then
    Title.Popupmenu := Popupmenu2
  Else
    Title.Popupmenu := Popupmenu3;
  Case Height of
    15: SmallStatus.Show;
    121: SmallStatus.Hide;
  End;
  If Top+Height > Screen.Height Then Top := Screen.Height-Height;
end;

procedure TWin_CD.WndProc(Var Msg : TMessage);
begin
  if (Msg.Msg = WM_USER+1) then
  begin
    case Msg.lParam of
      WM_LBUTTONDBLCLK : ToggleClick(Self);
      WM_RBUTTONUP     : PopupMenu3.Popup(Mouse.CursorPos.X,Mouse.CursorPos.Y);
    end;
  end
  else
    DefWindowProc(FWindowHandle, Msg.Msg, Msg.wParam, Msg.lParam);
end;

procedure TWin_CD.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  CloseClick(Sender);
end;

procedure TWin_CD.FormActivate(Sender: TObject);
Var Param: String;
begin
  If DoOnce = True Then Exit;
  DoOnce := True;
  Images.Picture.Loadfromfile('Graphics.Bmp');
  PaintImage(Previous); PaintImage(Rewind); PaintImage(Play);
  PaintImage(Stop); PaintImage(Pause); PaintImage(FastForward);
  PaintImage(Next); PaintImage(Eject); PaintImage(Minimize);
  PaintImage(Toggle); PaintImage(Close); PaintImage(Progress);
  PaintImage(Slider); PaintImage(Back); PaintImage(Title);
  Scanning.Caption := 'Scanning CD Rom';
  Application.Processmessages;
  Media.Open;
  SetupNewCD;
  GetPositions;
  If cdPosition <> 0 Then PlayerStatus := cdPlaying Else PlayerStatus := cdStopped;
  Tracks.ItemIndex := CurrentTrack - 1;
  Scanning.Free;
  Tracks.Show;
  UpdateTimer.Enabled := True;
  Shell_NotifyIcon(NIM_ADD,@IconData);
  Param := UpperCase(Paramstr(1));
  If Param = '/PLAY' Then
  Begin
    Param := Paramstr(2)[9]+Paramstr(2)[10];
    GotoTrack(Strtoint(Param));
    PlayerStatus := cdPlaying;
    Media.Play;
  End;
end;

end.

