*** Latest Updates: ***

- Bugs!

 Bug#3 : Rewind + Forward in Popupmenu were wrong way around - Fixed! - 22 Jan 01
 Bug#2 : Floating Point Error on No CD in Drive -------------- Fixed! - 21 Jan 01
 Bug#1 : Dosen't Autodetect a new CD ------------------------- Fixed! - 21 Jan 01

- Histroy

 22 Jan 01 : Added Registry Support --------------------------------- Version 1.2
 22 Jan 01 : Added Autodetect CD-Rom Drive -------------------------- Version 1.2
 22 Jan 01 : Made WinCD appear before it scanned for a CD Status ---- Version 1.2
 22 Jan 01 : Added Taskbar Tray Support ----------------------------- Version 1.2
 19 Jan 01 : Added Graphics Theme Support --------------------------- Version 1.1
 18 Jan 01 : Started the WinCD Project ------------------------------ Version 1.0


If you find any more bugs or errors please EMail me at:
  ScottieG_100@Hotmail.com