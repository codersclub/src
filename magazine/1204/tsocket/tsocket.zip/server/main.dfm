object Form1: TForm1
  Left = 433
  Top = 279
  Width = 411
  Height = 289
  Caption = 'Server'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  OnDestroy = FormDestroy
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 40
    Top = 8
    Width = 30
    Height = 13
    Caption = 'LOG:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Memo1: TMemo
    Left = 40
    Top = 24
    Width = 185
    Height = 177
    TabOrder = 0
  end
  object Button1: TButton
    Left = 40
    Top = 208
    Width = 75
    Height = 25
    Caption = 'Start server'
    TabOrder = 1
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 120
    Top = 208
    Width = 75
    Height = 25
    Caption = 'Send file'
    TabOrder = 2
    OnClick = Button2Click
  end
  object Server: TServerSocket
    Active = False
    Port = 1001
    ServerType = stNonBlocking
    OnAccept = ServerAccept
    OnClientRead = ServerClientRead
    OnClientError = ServerClientError
    Left = 8
    Top = 24
  end
  object OpenDialog1: TOpenDialog
    Left = 8
    Top = 56
  end
end
