object Form1: TForm1
  Left = 391
  Top = 318
  Width = 342
  Height = 285
  Caption = 'Client'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 24
    Top = 8
    Width = 30
    Height = 13
    Caption = 'LOG:'
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = [fsBold]
    ParentFont = False
  end
  object Memo1: TMemo
    Left = 24
    Top = 24
    Width = 185
    Height = 169
    TabOrder = 0
  end
  object Button1: TButton
    Left = 24
    Top = 200
    Width = 75
    Height = 25
    Caption = 'Connect'
    TabOrder = 1
    OnClick = Button1Click
  end
  object Client: TClientSocket
    Active = False
    Address = '127.0.0.1'
    ClientType = ctNonBlocking
    Host = '127.0.0.1'
    Port = 1001
    OnConnect = ClientConnect
    OnRead = ClientRead
    OnError = ClientError
    Left = 216
    Top = 24
  end
  object SaveDialog1: TSaveDialog
    Left = 248
    Top = 24
  end
end
