; ------------------------------------------------------------------------------
; ml /c /coff /Cp defend.asm
; link /subsystem:windows /LIBPATH:c:\masm32\lib /section:.text,rwe defend.obj
; del defend.obj
; ------------------------------------------------------------------------------
option casemap:none

.486
.model flat, stdcall

include c:\masm32\include\windows.inc
include c:\masm32\include\kernel32.inc
include c:\masm32\include\user32.inc
includelib c:\masm32\lib\user32.lib
includelib c:\masm32\lib\kernel32.lib

.data

password_key equ 13h
encoded_size equ 3Fh

.code

; ����� �����
start:
  call encode
  call message
  invoke ExitProcess, NULL

; ���������� ������� message
encode:
  mov eax, offset message
  xor ebx, ebx
 xor_loop:
  xor byte ptr [eax], password_key
  inc eax
  inc ebx
  cmp ebx, encoded_size
  jne xor_loop 
  ret

; ����������� ������
message:
  jmp show_msg
  msg_text db "Hello, World!", 0
  msg_title db "Thank you for registration", 0
 show_msg:
  invoke MessageBox, NULL, offset msg_title, offset msg_text, MB_OK
  ret

end start