using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;

namespace rssnews
{
	/// <summary>
	/// Summary description for rss.
	/// </summary>
	public class rss : Page
	{
		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here
			SqlConnection scConn = new SqlConnection(ConfigurationSettings.AppSettings["connectionString"]);
			SqlCommand scComd = scConn.CreateCommand();
			scComd.CommandText = "select news_theme title, news_text description, news_link link from news item ORDER BY news_date DESC FOR XML  AUTO,ELEMENTS";
			scComd.CommandType = CommandType.Text;
			scConn.Open();
			scComd.ExecuteNonQuery();

			SqlDataAdapter sda = new SqlDataAdapter();
			sda.SelectCommand = scComd;
			DataSet ds = new DataSet();
			sda.Fill(ds, "xml");
			DataTable dt = ds.Tables["xml"];
			string strRss = "<?xml version='1.0' encoding='windows-1251'?><rss version='2.0'><channel>";
			strRss += "<title>������� �����</title><link>http://site.ru/News.aspx</link><description>���� ��������� �������</description><language>en-us</language>";
			strRss += dt.Rows[0][0].ToString();
			strRss += "</channel></rss>";
			Response.ContentType = "text/xml";
			Response.Write(strRss);		
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{    
			this.Load += new EventHandler(this.Page_Load);
		}
		#endregion
	}
}
