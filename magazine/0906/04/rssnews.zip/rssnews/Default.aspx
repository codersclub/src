<%@ Page language="c#" Codebehind="Default.aspx.cs" AutoEventWireup="false" Inherits="rssnews.WebForm1" %>
<%@ Register TagPrefix="uc1" TagName="news" Src="news.ascx" %>
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.0 Transitional//EN" >
<HTML>
	<HEAD>
		<title>WebForm1</title>
		<meta name="GENERATOR" Content="Microsoft Visual Studio .NET 7.1">
		<meta name="CODE_LANGUAGE" Content="C#">
		<meta name="vs_defaultClientScript" content="JavaScript">
		<meta name="vs_targetSchema" content="http://schemas.microsoft.com/intellisense/ie5">
	</HEAD>
	<body>
		<form id="Form1" method="post" runat="server">
			<uc1:news id="News1" runat="server"></uc1:news>
		</form>
	</body>
</HTML>
