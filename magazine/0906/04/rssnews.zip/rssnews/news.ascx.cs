using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace rssnews
{
	/// <summary>
	///		Summary description for news.
	/// </summary>
	public class news : UserControl
	{
		protected Repeater Repeater1;

		private void Page_Load(object sender, EventArgs e)
		{
			// Put user code to initialize the page here
			ArrayList alNews = new ArrayList();
			SqlConnection sqlConn = new SqlConnection(ConfigurationSettings.AppSettings["connectionString"]);
			SqlCommand sqlComd = sqlConn.CreateCommand();
			sqlComd.CommandText = "GetNews";
			sqlComd.CommandType = CommandType.StoredProcedure;
			sqlConn.Open();
			sqlComd.ExecuteNonQuery();
			
			SqlDataAdapter sqlAdap = new SqlDataAdapter();
			sqlAdap.SelectCommand = sqlComd;
			
			DataSet ds = new DataSet();
			sqlAdap.Fill(ds, "news");
			DataTable dt = ds.Tables["news"];
			foreach(DataRow dr in dt.Rows)
			{
				News n = new News();
				n.date = dr["news_date"].ToString().Substring(0, 10);
				n.text = dr["news_text"].ToString();
				n.link = "<a href=" + dr["news_link"].ToString() + ">���������...</a>";
				alNews.Add(n);
			}
			Repeater1.DataSource = alNews;
			Repeater1.DataBind();
		}
		#region Web Form Designer generated code
		override protected void OnInit(EventArgs e)
		{
			//
			// CODEGEN: This call is required by the ASP.NET Web Form Designer.
			//
			InitializeComponent();
			base.OnInit(e);
		}
		
		/// <summary>
		///		Required method for Designer support - do not modify
		///		the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.Load += new EventHandler(this.Page_Load);

		}
		#endregion
	}
	public class News
	{
		private string Text;
		private string Link;
		private string Date;
		public string text
		{
			get
			{
				return Text;
			}
			set
			{
				Text = value;
			}
		}
		public string date
		{
			get
			{
				return Date;
			}
			set
			{
				Date = value;
			}
		}
		public string link
		{
			get
			{
				return Link;
			}
			set
			{
				Link = value;
			}
		}

	}
}
