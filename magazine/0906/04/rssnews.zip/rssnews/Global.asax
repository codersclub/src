<%@ Application Codebehind="Global.asax.cs" Inherits="rssnews.Global" %>
