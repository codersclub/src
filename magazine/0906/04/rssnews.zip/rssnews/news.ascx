<%@ Control Language="c#" AutoEventWireup="false" Codebehind="news.ascx.cs" Inherits="rssnews.news" TargetSchema="http://schemas.microsoft.com/intellisense/ie5"%>
<asp:Repeater id="Repeater1" runat="server">
	<HeaderTemplate>
		<h4>�������</h4>
		<table>
	</HeaderTemplate>
	<ItemTemplate>
		<tr>
			<td colspan="2"><br>
				<%# DataBinder.Eval(Container.DataItem, "text") %>
			</td>
		</tr>
		<tr>
			<td><%# DataBinder.Eval(Container.DataItem, "date") %></td>
			<td><%# DataBinder.Eval(Container.DataItem, "link") %></td>
		</tr>
	</ItemTemplate>
	<FooterTemplate>
		</table>
	</FooterTemplate>
</asp:Repeater>
