#!/usr/bin/perl
#######################################
## Perl Uploader v1.0                ##
## http://www.secone.com/            ##
## info@secone.com                   ##
##                                   ###########################################
## You should carefully read all of the following terms and conditions        ##
## before using this program.  Your use of  this software indicates your      ##
## acceptance of this license agreement and warranty.                         ##
## This program is being distributed as freeware.  It may be used             ##
## free of charge, but not modified below the line specified.  This copyright ## 
## must remain intact.							      ##
##                                                                            ##
## By using this program you agree to indemnify Perl Services from any        ##
## liability. 								      ##
##                                                                            ##
## Selling the code for this program without prior written consent is         ##
## expressly forbidden.  Obtain permission before redistributing this         ##
## program over the Internet or in any other medium.  In all cases the        ##
## copyright must remain intact.        			              ##
##                                                                            ##
## There are security hazards involved with this script.Read the readme file  ##
## before using the script.                                                   ##
################################################################################

##
## Start setting up options here:

## Your path to where you want your files uploaded.
## Note: NO trailing slash
$basedir = "/home/bleh/public_html/cgi/upload";

## Do you wish to allow all file types?  yes/no (no capital letters)
$allowall = "yes";

## If the above = "no"; then which is the only extention to allow?
## Remember to have the LAST 4 characters i.e. .ext
$theext = ".gif";

## The page you wish it to forward to when done:
## I.E. http://www.mydomainname.com/thankyou.html
$donepage = "done.html";



################################################
################################################
## DO NOT EDIT OR COPY BELOW THIS LINE        ##
################################################
################################################












use CGI; 
$onnum = 1;

while ($onnum != 11) {
my $req = new CGI; 
my $file = $req->param("FILE$onnum"); 
if ($file ne "") {
my $fileName = $file; 
$fileName =~ s!^.*(\\|\/)!!; 
$newmain = $fileName;
if ($allowall ne "yes") {
if (lc(substr($newmain,length($newmain) - 4,4)) ne $theext){
$filenotgood = "yes";
}
}
if ($filenotgood ne "yes") { 
open (OUTFILE, ">$basedir/$fileName"); 
print "$basedir/$fileName<br>";
while (my $bytesread = read($file, my $buffer, 1024)) { 
print OUTFILE $buffer; 
} 
close (OUTFILE); 
}
}
$onnum++;
}

print "Content-type: text/html\n";
print "Location:$donepage\n\n";
