#######################################
## Perl Uploader v1.0                ##
## http://www.secone.com/            ##
## info@secone.com                   ##
##                                   ###########################################
## You should carefully read all of the following terms and conditions        ##
## before using this program.  Your use of  this software indicates your      ##
## acceptance of this license agreement and warranty.                         ##
## This program is being distributed as freeware.  It may be used             ##
## free of charge, but not modified below the line specified.  This copyright ## 
## must remain intact.							      ##
##                                                                            ##
## By using this program you agree to indemnify Perl Services from any        ##
## liability. 								      ##
##                                                                            ##
## Selling the code for this program without prior written consent is         ##
## expressly forbidden.  Obtain permission before redistributing this         ##
## program over the Internet or in any other medium.  In all cases the        ##
## copyright must remain intact.        			              ##
##                                                                            ##
## There are security hazards involved with this script.Read the readme file  ##
## before using the script.                                                   ##
################################################################################


This script will allow you to upload up to 10 files to your server at a time,
using a newer browser that allows file uploads.

I would suggest you keep it in a password-protected directory, in order that
people cannot upload to your server against your will.  

You will have to chmod this upload-to directory 777 which will is a security
hazard.


INSTALLATION INSTRUCTIONS:
1. Upload psupload.cgi to any directory that allows CGI scripts to be run in it.
(CGI-Bin or otherwise)

2. Chmod psupload.cgi with 755 permissons.  You can do this easily with an FTP
program, or by telneting into your server.

3. Chmod the directory which you would be the files to be uploaded to with 777
permissons.

4. Edit psupload.cgi, and change:
 A. The first line to reflect where Perl is on your server.
 B. Scroll down for further instructions as to what more to edit.

5. Either use the included psupload.htm to upload your scripts, or make your
own.  The HTML file has a couple vital parts.  The following will outline it:

<html><body>
These tags must be in place for all documents.

<form method="POST" action="psupload.cgi" ENCTYPE="multipart/form-data">
This line calls the CGI.  Must have that ENCTYPE tag.

<input type="file" name="FILE1">
This brings up the text box and the browse button so you can choose the file
to upload.  Name can be FILE1, FILE2, FILE3, etc, all the way up to 10.

<input type="submit" value="Upload!">
This will make the button that actually makes it upload the files, and redirects
to the page as chosen on psupload.cgi when editting it.

</form></body></html>
Close off the form, body, and HTML page.


That should be all!  If you have any questions, contact us on irc:
viper.venomx.com #system33


