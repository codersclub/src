(*
   This is an Apache Module Demo convertr unit file.
   This file is a part of Apache Module Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The Apache Module Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The Apache Module Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

unit convertr;

interface

uses
  SysUtils, Classes;
type
  TFAState = -32768..32767;

const
  asInDelim = TFAState(0);
  asInToken = TFAState(1);
  asInQuote = TFAState(2);
  asStrComm = TFAState(3);
  asMulComm = TFAState(4);
  tsAlpha = 1;
  tsNumeric = 2;
  Numeric = ['0'..'9', '$'];
  Alpha = ['A'..'Z', 'a'..'z', '_', '^'];
  Delimeters = [' ', '.',',', ';', '(', ')', '<', '>', '[', ']', '=', ':', '-', '+', '*', #13, #10, #9];

var
  Reserved : TStringList;

procedure Convert(const Pas : String; var HTML : String);

implementation

procedure Convert;
var
  i, l, l1, TokStart, HTMLPos : Integer;
  State : TFAState;
  TokenState : Integer;
  Tmp : String;

procedure AddElem(const Elem : String);
begin
  if (HTMLPos+Length(Elem)) > l1 then
  begin
    l1 := l1+Length(Elem);
    SetLength(HTML, l1);
  end;
  Move(Elem[1], HTML[HTMLPos], Length(Elem));
  HTMLPos := HTMLPos+Length(Elem);
end;

procedure AddDelim (Delim : Char);
var
  Tmp : String;
begin
  if Delim = '<' then Tmp := '&lt;'
  else if Delim = '>' then Tmp := '&gt;'
  else Tmp := Pas[i];
  AddElem(Tmp);
end;

procedure RepSyms(var Tmp : String);
var
  abp : Integer;
begin
  abp := Pos('<', Tmp);
  while abp<>0 do
  begin
    System.Delete(Tmp, abp, 1);
    System.Insert('&lt;', Tmp, abp);
    abp := Pos('<', Tmp);
  end;
  abp := Pos('>', Tmp);
  while abp<>0 do
  begin
    System.Delete(Tmp, abp, 1);
    System.Insert('&gt;', Tmp, abp);
    abp := Pos('>', Tmp);
  end;
end;

begin
  l := Length(Pas);
  l1 := l*2;
  SetLength(HTML, l1);
  State := asInDelim;
  TokenState := 0;
  HTMLPos := 1;
  for i:=1 to l do
  begin
    case State of
      asInDelim :
      begin
        if (Pas[i] in Delimeters)=False then
        begin
          TokStart := i;
          case Pas[i] of
            '/' :
            if Pas[i+1]<> '/' then AddElem('/')
            else State := asStrComm;
            '{' : State := asMulComm;
            '''' : State := asInQuote;
            else
            begin
              State := asInToken;
              if (Pas[i] in Alpha)=True then TokenState:=tsAlpha
              else TokenState:=tsNumeric;
            end;
          end;
        end else
        if Pas[i]= '(' then
        begin
          if Pas[i+1]<> '*' then AddElem('(')
          else begin
            State := asMulComm;
            TokStart := i;
          end;
        end else
        AddDelim(Pas[i]);
      end;
      asInToken :
      begin
        if (Pas[i] in Alpha) = True then TokenState:=TokenState or tsAlpha
        else if (Pas[i] in Numeric) = True then TokenState:=TokenState or tsNumeric
        else begin
          SetLength(Tmp, i-TokStart);
          Move(Pas[TokStart], Tmp[1], i-TokStart);
          if (TokenState and tsNumeric) = 0 then
          begin
            if Reserved.IndexOf(Tmp) >= 0 then
            Tmp := '<B>'+Tmp+'</B>';
          end else
          if ((TokenState and tsAlpha) = 0) or (Tmp[1]='$') then
          Tmp := '<FONT COLOR=#0000ff>'+Tmp+'</FONT>';
          AddElem(Tmp);
          TokenState := 0;
          State := asInDelim;
          AddDelim(Pas[i]);
        end;
      end;
      asInQuote:
      if Pas[i] = '''' then
      begin
        SetLength(Tmp, i-TokStart+1);
        Move(Pas[TokStart], Tmp[1], i-TokStart+1);
        RepSyms( Tmp );
        Tmp := '<FONT COLOR=#0000ff>' + Tmp + '</FONT>';
        AddElem(Tmp);
        State := asInDelim;
      end;
      asStrComm:
      if (Pas[i] = #10) or (Pas[i] = #13) then
      begin
        SetLength(Tmp, i-TokStart);
        Move(Pas[TokStart], Tmp[1], i-TokStart);
        RepSyms( Tmp );
        Tmp := '<FONT COLOR=#0000ff><I>' + Tmp + '</I></FONT>';
        AddElem(Tmp);
        State := asInDelim;
        AddDelim(Pas[i]);
      end;
      asMulComm:
      if (Pas[i] = '}') or ((Pas[i] = ')') and (Pas[i-1] = '*')) then
      begin
        SetLength(Tmp, i-TokStart+1);
        Move(Pas[TokStart], Tmp[1], i-TokStart+1);
        RepSyms( Tmp );
        Tmp := '<FONT COLOR=#0000ff><I>' + Tmp + '</I></FONT>';
        AddElem(Tmp);
        State := asInDelim;
      end;
    end;
  end;
  SetLength(HTML, HTMLPos-1);
end;

end.
