(*
   This is an Apache Module Demo project file.
   This file is a part of Apache Module Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The Apache Module Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The Apache Module Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

library pas2html;

uses
  WebBroker,
  HTTPD,
  ApacheApp,
  main in 'main.pas' {WebModule1: TWebModule};

exports
  apache_module name 'pas2html_module';

begin
  ModuleName := 'Pas2html_Module';
  ContentType := 'pas2html-handler';
  Application.Initialize;
  Application.CreateForm(TWebModule1, WebModule1);
  Application.Run;
end.