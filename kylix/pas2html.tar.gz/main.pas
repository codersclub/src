(*
   This is an Apache Module Demo main unit file.
   This file is a part of Apache Module Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The Apache Module Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The Apache Module Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

unit main;

interface

uses
  Variants, SysUtils, Classes, HTTPApp, convertr;

const
  AddPath = '/usr/local/apache/libexec/reserved';
  HTMLFooter = '<HR><P>pas2html module (c) 2001 Andrei Borovsky</P></BODY></HTML>';

type
  TWebModule1 = class(TWebModule)
    procedure WebModule1WebActionItem1Action(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure WebModuleCreate(Sender: TObject);
    procedure WebModuleDestroy(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WebModule1: TWebModule1;

implementation

uses WebReq;

{$R *.xfm}

procedure TWebModule1.WebModule1WebActionItem1Action(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
var
  PAS, HTML : String;
  HTMLStream : TFileStream;
begin
  if not FileExists(Request.PathTranslated) then
  begin
    Response.Content:='<HTML><HEAD><TITLE>Resource Not Found</TITLE></HEAD><BODY><H2>Error 404</H2><P>Resource '+
    Request.URL+ ' is not found on this server</P>'+HTMLFooter;
    Response.StatusCode := 404;
    Exit;
  end;
  HTMLStream := TFileStream.Create(Request.PathTranslated, fmOpenRead);
  SetLength(Pas, HTMLStream.Size);
  HTMLStream.Read(Pas[1], HTMLStream.Size);
  HTMLStream.Free;
  //Pas := 'begin end.';
  Convert(PAS, HTML);
  HTML:='<HTML><HEAD><TITLE>View Source - ' + ExtractFileName(Request.PathTranslated) +
  '</TITLE></HEAD><BODY><H2>'+ ExtractFileName(Request.PathTranslated)+'</H2><P><FONT FACE="Courier" SIZE=4><PRE>'+
  HTML+'</FONT></PRE></P>' + HTMLFooter;
  Response.Content := HTML;
end;

procedure TWebModule1.WebModuleCreate(Sender: TObject);
begin
  Reserved := TStringList.Create;
  Reserved.LoadFromFile(AddPath);
  Reserved.Sorted:=True;
end;

procedure TWebModule1.WebModuleDestroy(Sender: TObject);
begin
  Reserved.Free;
end;

initialization
  WebRequestHandler.WebModuleClass := TWebModule1;

end.