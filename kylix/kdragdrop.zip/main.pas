//
//  This is a CLXDisplay API Drag and Drop demo main unit
//  (c) Andrei Borovsky, 2001. < borovsky@yandex.ru >
//  You may do with this file whatever you want, but remember that
//  I'm not responcible for any consequences
//

unit main;

interface

uses
  SysUtils, Types, Classes, Variants, QGraphics, QControls, QForms, QDialogs,
  QStdCtrls, Qt;

type
  TForm1 = class(TForm)
    Label1: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure Label1MouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
  private
    { Private declarations }
  public
    { Public declarations }
    procedure AppEventHandler (Sender: QObjectH; Event: QEventH; var Handled: Boolean);
  end;

var
  Form1: TForm1;

implementation

{$R *.xfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
  Application.OnEvent:=AppEventHandler;
end;

procedure TForm1.AppEventHandler;
var
  QMS : QMimeSourceH;
  S : WideString;
begin
  Handled:=False;
  if Sender=Label1.Handle then
  begin
    if QEvent_isQDropEventEvent(Event) then
    begin
      if QEvent_isQDragEnterEvent(Event) then
      begin
        if QDropEvent_source(QDropEventH(Event))=Label1.Handle then Exit;
        QMS:=QDropEvent_to_QMimeSource(QDropEventH(Event));
        QDropEvent_acceptAction(QDropEventH(Event), QTextDrag_canDecode(QMS));
      end else
      if QEvent_isQDragMoveEvent(Event) then
      begin
        if QDropEvent_source(QDropEventH(Event))=Label1.Handle then Exit;
        QMS:=QDropEvent_to_QMimeSource(QDropEventH(Event));
        QDropEvent_acceptAction(QDropEventH(Event), QTextDrag_canDecode(QMS))
      end else
      begin
        QMS:=QDropEvent_to_QMimeSource(QDropEventH(Event));
        if QTextDrag_canDecode(QMS) then
        QTextDrag_decode(QMS, @S);
        Label1.Caption:=S;
      end;
    end;
  end;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  Application.OnEvent:=nil;
end;

procedure TForm1.Label1MouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var
  TextDragObject : QTextDragH;
  S : WideString;
  name : PChar;
begin
  if ssLeft in Shift then
  begin
    S:=Label1.Caption;
    name:='textdrag';
    TextDragObject:=QTextDrag_create(@S, Label1.Handle, name);
    if QDragObject_drag(TextDragObject) then Label1.Caption:='';
  end;
end;

end.
