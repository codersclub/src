(*
   This is the Simple CGI Application Demo project file
   This file is a part of Simple CGI Application Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The Simple CGI Application Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The Simple CGI Application Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

program simplecgi;

{$APPTYPE CONSOLE}

uses
  Libc;

var
  Method : PChar;
  Query : String;

begin
  Method := getenv( 'REQUEST_METHOD' );
  if Method = nil then
  begin
    WriteLn( 'Error : no request method' );
    Halt(0);
  end;
  WriteLn( 'Content-Type: text/html' );
  WriteLn;
  Write( '<HTML><HEAD><TITLE>Simple CGI Application</TITLE><BODY>' );
  Write( '<H2>This page was generated on the fly by the CGI application</H2>' );
  Write( '<P>You have sent data by ', String(Method), ' method</P>' );
  Write( '<P>The user agent is "', String(getenv('HTTP_USER_AGENT')), '"</P>' );
  Write( '<P>The HTTP_REFERER variable is "', String(getenv('HTTP_REFERER')), '"</P>' );
  if Method = 'GET' then
  Write( '<P>The query string is "', String(getenv('QUERY_STRING')), '"</P>' )
  else
  begin
    Write( '<P>The content length is ', String(getenv('CONTENT_LENGTH')), '</P>' );
    Read( Query );
    Write( '<P>The query string is "', Query, '"</P>' )
  end;
  Write( '</BODY></HTML>' );
end.
