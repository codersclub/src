(*
  This is a CLXDisplay API Drag'n'Drop hooks demo main unit.
  (c) Andrei Borovsky, 2001. < borovsky@yandex.ru >
  You may do with this file whatever you want, but remember that
  I'm not responcible for any consequences.
*)

unit main;

interface

uses
  SysUtils, Types, Classes, QGraphics, QControls, QForms, QDialogs,
  QStdCtrls, Qt;

type

  EventFunc = function(Handle : QObjectH; e : QEventH) : Boolean of object; cdecl;

  TForm1 = class(TForm)
    Label1: TLabel;
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormCreate(Sender: TObject);
    procedure Label1MouseMove(Sender: TObject; Shift: TShiftState; X,
      Y: Integer);
  private
    { Private declarations }
  public
    { Public declarations }
    DropHook : QEvent_hookH;
    function EventHandler(Handle : QObjectH; e : QEventH) : Boolean; cdecl;
  end;

var
  Form1: TForm1;

implementation

{$R *.xfm}

function TForm1.EventHandler;
var
  QMS : QMimeSourceH;
  S : WideString;
begin
  Result:=False;
  if QEvent_isQDropEventEvent(e) then
  begin
    if QEvent_isQDragEnterEvent(e) then
    begin
      if QDropEvent_source(QDropEventH(e))=Label1.Handle then Exit;
      QMS:=QDropEvent_to_QMimeSource(QDropEventH(e));
      QDropEvent_acceptAction(QDropEventH(e), QTextDrag_canDecode(QMS));
    end else
    if QEvent_isQDragMoveEvent(e) then
    begin
      if QDropEvent_source(QDropEventH(e))=Label1.Handle then Exit;
      QMS:=QDropEvent_to_QMimeSource(QDropEventH(e));
      QDropEvent_acceptAction(QDropEventH(e), QTextDrag_canDecode(QMS))
    end else
    begin
      QMS:=QDropEvent_to_QMimeSource(QDropEventH(e));
      if QTextDrag_canDecode(QMS) then
      QTextDrag_decode(QMS, @S);
      Label1.Caption:=S;
    end;
  end;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  QEvent_hook_destroy(DropHook);
end;

procedure TForm1.FormCreate(Sender: TObject);
var
  M : TMethod;
begin
  DropHook:=QEvent_hook_create(Label1.Handle);
  EventFunc(M):=EventHandler;
  Qt_hook_hook_events(DropHook, M);
end;

procedure TForm1.Label1MouseMove(Sender: TObject; Shift: TShiftState; X,
  Y: Integer);
var
  TextDragObject : QTextDragH;
  S : WideString;
  name : PChar;
begin
  if ssLeft in Shift then
  begin
    S:=Label1.Caption;
    name:='textdrag';
    TextDragObject:=QTextDrag_create(@S, Label1.Handle, name);
    if QDragObject_drag(TextDragObject) then Label1.Caption:='';
  end;
end;

end.
