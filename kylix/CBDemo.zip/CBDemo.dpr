(*
  This is a CLXDisplay API Clipboard monitoring and hooks demo
  main project file.
  (c) Andrei Borovsky, 2001. < borovsky@yandex.ru >
  You may do with this file whatever you want, but remember that
  I'm not responcible for any consequences.
*)

program CBDemo;

uses
  QForms,
  main in 'main.pas' {Form1};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.
