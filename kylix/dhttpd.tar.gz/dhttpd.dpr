(*
   This is the HTTP daemon project file
   This file is a part of HTTP Daemon Demo,
   (c) by Andrei Borovsky, 2001.

   The HTTP Daemon Demo is free software; you can
   redistribute it and/or modify it under the terms of the GNU General
   Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
   The CustomQDial Library Demo Application is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
   See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with the package; see the file COPYING.  If not,
   write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*)

program dhttpd;

{$APPTYPE CONSOLE}

uses
  Libc, SysUtils, WebServ;

var
  F : Text;
  SigSet : __sigset_t;
  SigNum : Integer;
  pid : Integer;

// Signal handler function

procedure TranslateSig( sig : Integer ); cdecl;
begin
  SigNum := sig;
end;

begin

// Processing command line arguments

  if ParamCount > 0 then
  begin
    if ParamCount = 1 then
    begin
      SigNum := 0;
      if ParamStr(1) = '-stop' then SigNum := SIGTERM else
      if ParamStr(1) = '-restart' then SigNum := SIGHUP;
      if SigNum <> 0 then
      begin
        if FileExists( '/var/run/dhttpd.pid' ) then
        begin
          AssignFile(F, '/var/run/dhttpd.pid' );
          Reset( F );
          Read( F, pid );
          CloseFile( F );
          if kill( pid, SigNum ) = 0 then
          Halt( 0 );
        end;
        WriteLn( 'dhttpd : cannot do ' + ParamStr( 1 ) + '. Maybe the daemon is not running?' );
        Halt( 0 );
      end;
    end;
    WriteLn( 'Use dhttpd -stop to stop the daemon or dhttpd -restart to restart it.' );
    Halt( 0 );
  end;

// Daemon initialization code

  pid := fork;
  if pid = -1 then            // fork failed
  begin
    perror( PChar('fork 1: ') );
    Halt( 1 );
  end else
  if pid <> 0 then Halt( 0 ); // parent process exits
  pid := setsid;
  if pid = -1  then  // setsid failed
  begin
    perror( PChar('setsid: ') );
    Halt( 1 );
  end;
  Close( Input );    // closing stdin
  AssignFile( Output, '/dev/null' );
  Rewrite( Output );
  AssignFile( ErrOutput, '/dev/null' );
  Rewrite( ErrOutput );

// Now process runs in the daemon mode

  WebServer := TWebServer.Create;  // Creating server object
  AssignFile( F, '/var/run/dhttpd.pid' );
  Rewrite( F );
  pid := getpid;
  WriteLn( F, pid );
  CloseFile( F );
  signal( SIGTERM, @TranslateSig );
  signal( SIGHUP, @TranslateSig );
  sigfillset( SigSet );
  sigdelset( SigSet, SIGTERM );
  sigdelset( SigSet, SIGHUP );
  SigNum := 0;
  while SigNum <> SIGTERM do
  begin
    sigsuspend( SigSet );
    WebServer.Free;
    if SigNum = SIGHUP then         // Restarting
    begin
      pid := fork;
      if pid = -1 then Halt(1);
      if pid <> 0 then Break;  // old process exits
      // Now we are in the new child process
      WebServer := TWebServer.Create;
      AssignFile( F, '/var/run/dhttpd.pid' );
      Rewrite(F);
      pid := getpid;
      WriteLn( F, pid );
      CloseFile(F);
    end;
  end;  
end.
