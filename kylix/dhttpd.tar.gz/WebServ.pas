(*
   This is the HTTP daemon WebServ unit file
   This file is a part of HTTP Daemon Demo,
   (c) by Andrei Borovsky, 2001.

   The HTTP Daemon Demo is free software; you can
   redistribute it and/or modify it under the terms of the GNU General
   Public License as published by the Free Software Foundation;
   either version 2 of the License, or (at your option) any later version.
   The CustomQDial Library Demo Application is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
   See the GNU General Public License for more details.

   You should have received a copy of the GNU General Public License along
   with the package; see the file COPYING.  If not,
   write to the Free Software Foundation, Inc., 59 Temple Place - Suite 330,
   Boston, MA 02111-1307, USA.
*)


unit WebServ;

interface

uses

  IdBaseComponent, IdComponent,
  IdTCPServer, IdHTTPServer, SysUtils;

type

  TWebServer = class( TObject )
    IndyHTTP : TIdHTTPServer;
  private
    procedure HTTPCommandGet( AThread : TIdPeerThread;
    RequestInfo : TIdHTTPRequestInfo; ResponseInfo : TIdHTTPResponseInfo);
  public
    constructor Create;
    destructor  Destroy; override;
  end;

const
  HTTPDocsDir = '/var/www/html';

var
  WebServer : TWebServer;

implementation

// TWebServer methods

constructor TWebServer.Create;
begin
  inherited Create;
  IndyHTTP := TIDHTTPServer.Create( nil );
  with IndyHTTP do
  begin
    ServerSoftware := 'DAEMONstration Web server. (c) 2001 Andrei Borovsky';
    OnCommandGet := HTTPCommandGet;
    TerminateWaitTime := 5000;
    DefaultPort := 8800;
    // Activate the Server
    Active  := True;
  end;
end;

destructor TWebServer.Destroy;
begin
  IndyHTTP.Free;
  inherited Destroy;
end;

procedure TWebServer.HTTPCommandGet;
var
  FName : String;
begin
  FName := HTTPDocsDir + RequestInfo.Document;
  if FName[ Length(FName) ] = '/' then FName := FName + 'index.html' else
  if DirectoryExists( FName + '/' ) then
  begin
    // Redirecting directory without a trailing slash
    ResponseInfo.Redirect( RequestInfo.Document + '/' );
    Exit;
  end;
  if FileExists( FName ) then
  begin
    // Serving content
    IndyHTTP.ServeFile( AThread, ResponseInfo, FName );
    Exit;
  end;
  // Requested URL not found
  ResponseInfo.ResponseNo := 404;
  ResponseInfo.ResponseText := 'Requested URL not found';
  ResponseInfo.ContentText := 'Error 404 - ' + ResponseInfo.ResponseText;
  ResponseInfo.WriteHeader;
  ResponseInfo.WriteContent;
end;

end.
