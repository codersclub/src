(*
   This is the CGI Application Demo project file
   This file is a part of CGI Application Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The CGI Application Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The CGI Application Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

program frenchwines;

{$APPTYPE CONSOLE}

uses
  WebBroker,
  CGIApp,
  main in 'main.pas' {WebModule1: TWebModule};

{$R *.res}

begin
  Application.Initialize;
  Application.CreateForm(TWebModule1, WebModule1);
  Application.Run;
end.