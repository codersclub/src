(*
   This is the CGI Application Demo main unit file
   This file is a part of CGI Application Demo,
   (c) by Andrei Borovsky, 2001.
   You can contact me at borovsky@yandex.ru
   The CGI Application Demo is free software; you can
   redistribute it and/or modify it anyway you want
   The CGI Application Demo is distributed in the hope that it
   will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty
   of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
*)

unit main;

interface

uses
  Variants, SysUtils, Classes, HTTPApp, DBXpress, FMTBcd, HTTPProd, DB,
  DBClient, Provider, SqlExpr, DBWeb, DBXpressWeb;

type
  TWebModule1 = class(TWebModule)
    SQLConnection1: TSQLConnection;
    SQLQuery1: TSQLQuery;
    PageProducer1: TPageProducer;
    DataSetTableProducer1: TDataSetTableProducer;
    SQLQueryTableProducer1: TSQLQueryTableProducer;
    procedure WebModule1WebActionItem2Action(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure WebModule1WebActionItem4Action(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure PageProducer1HTMLTag(Sender: TObject; Tag: TTag;
      const TagString: String; TagParams: TStrings;
      var ReplaceText: String);
    procedure WebModuleCreate(Sender: TObject);
    procedure WebModule1WebActionItem6Action(Sender: TObject;
      Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
    procedure DataSetTableProducer1FormatCell(Sender: TObject; CellRow,
      CellColumn: Integer; var BgColor: THTMLBgColor;
      var Align: THTMLAlign; var VAlign: THTMLVAlign; var CustomAttrs,
      CellData: String);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  WebModule1: TWebModule1;

implementation

uses WebReq;

{$R *.xfm}

procedure TWebModule1.WebModule1WebActionItem2Action(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
begin
// redirecting the request
  Response.Location := Request.InternalScriptName+'/welcome';
  Response.StatusCode := 301;
  Response.Content := '<HTML><BODY><H2>This page is redirected to <A HREF='+Request.InternalScriptName+'/'+'>'+Request.Host+Request.InternalScriptName+'/'+'</A></H2></BODY></HTML>';
end;

procedure TWebModule1.WebModule1WebActionItem4Action(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
begin
// default action called for all undefined requests
  Response.StatusCode := 404;
  Response.Content := '<HTML><HEAD><TITLE>Resource Not Found</TITLE><BODY><H2>Error 404</H2><P>Requested resource "'+Request.InternalScriptName+Request.PathInfo+'" is not found on this server.</BODY></HTML>';
end;

procedure TWebModule1.PageProducer1HTMLTag(Sender: TObject; Tag: TTag;
  const TagString: String; TagParams: TStrings; var ReplaceText: String);
begin
  if TagString = 'localtime' then ReplaceText := TimeToStr(Time) else
  if TagString = 'winescount' then ReplaceText := IntToStr(SQLQuery1.RecordCount)  else
  if TagString = 'host' then ReplaceText := Request.Host;
end;

procedure TWebModule1.WebModuleCreate(Sender: TObject);
begin
  LongTimeFormat := 'hh:mm AM/PM';
end;

procedure TWebModule1.WebModule1WebActionItem6Action(Sender: TObject;
  Request: TWebRequest; Response: TWebResponse; var Handled: Boolean);
var
  i : Integer;
begin
  if Request.ContentFields.Count = 0 then
  begin
    Response.Content:='<HTML><HEAD><TITLE>Error - no request</TITLE></HEAD><BODY><H1>No request is specified!</H1></BODY></HTML>';
    Exit;
  end;
  i:=0;
(*  removing empty-named parameters Mozilla browser adds,
    also removing parameters whose values are empty or "any"
*)
  while i < Request.ContentFields.Count do
  begin
    if Request.ContentFields.Names[i] = '' then
    Request.ContentFields.Delete(i) else
    if (Request.ContentFields.Values[Request.ContentFields.Names[i]] = '' ) or
    (Request.ContentFields.Values[Request.ContentFields.Names[i]] = 'any' ) then
    Request.ContentFields.Delete(i)
    else Inc(i);
  end;
(*  if there are no parameters in the list now, then both values
    were either empty or "any" and we are serving the whole database
*)
  if Request.ContentFields.Count = 0 then
  begin
    SQLQuery1.SQL.Strings[0] := SQLQuery1.SQL.Strings[0] + ' ORDER BY wine_id';
    DataSetTableProducer1.DataSet.Open;
    Response.Content := DataSetTableProducer1.Content;
    DataSetTableProducer1.DataSet.Close;
    Exit;
  end;
// serving query
  SQLQueryTableProducer1.Query.Params.Add;
  SQLQueryTableProducer1.Query.Params[0].Name := Request.ContentFields.Names[0];
  SQLQueryTableProducer1.Query.Params[0].Value :=
  Request.ContentFields.Values[Request.ContentFields.Names[0]];
  if Request.ContentFields.Count = 2 then
  begin
    SQLQueryTableProducer1.Query.Params.Add;
    SQLQueryTableProducer1.Query.Params[1].Name := Request.ContentFields.Names[1];
    SQLQueryTableProducer1.Query.Params[1].Value :=
    Request.ContentFields.Values[Request.ContentFields.Names[1]];
    SQLQueryTableProducer1.Query.SQL.Add('WHERE (WINES.wine_region = :Region) AND (WINES.wine_sort = :Wine_Sort)');
    SQLQueryTableProducer1.Caption:='Wines selected by origin "'+Request.ContentFields.Values['Region']+
    '" and by category "'+Request.ContentFields.Values['Wine_Sort']+'":';
  end else
  begin
    if SQLQueryTableProducer1.Query.Params[0].Name = 'Region' then
    begin
      SQLQueryTableProducer1.Query.SQL.Add('WHERE WINES.wine_region = :Region');
      SQLQueryTableProducer1.Caption:='Wines selected by origin "'+SQLQueryTableProducer1.Query.Params[0].Value+'":';
    end else
    begin
      SQLQueryTableProducer1.Query.SQL.Add('WHERE WINES.wine_sort = :Wine_Sort ORDER BY wine_region');
      SQLQueryTableProducer1.Caption:='Wines selected by category "'+SQLQueryTableProducer1.Query.Params[0].Value+'":';
    end;
  end;
  SQLQueryTableProducer1.Query.Open;
  Response.Content := SQLQueryTableProducer1.Content;
  SQLQueryTableProducer1.Query.Close;
end;

procedure TWebModule1.DataSetTableProducer1FormatCell(Sender: TObject;
  CellRow, CellColumn: Integer; var BgColor: THTMLBgColor;
  var Align: THTMLAlign; var VAlign: THTMLVAlign; var CustomAttrs,
  CellData: String);
begin
  if CellData = 'red' then BgColor := '#dd2222' else
  if CellData = 'white' then BgColor := '#ffffff' else
  if CellData = 'rose' then BgColor := '#ffaaaa';
end;

initialization
  WebRequestHandler.WebModuleClass := TWebModule1;
end.
