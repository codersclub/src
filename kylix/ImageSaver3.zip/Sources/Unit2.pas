unit Unit2;

interface

uses
  SysUtils, Types, Classes, Variants, QGraphics, QControls, QForms, QDialogs,
  QStdCtrls, QExtCtrls;

type
  TForm2 = class(TForm)
    Button2: TButton;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    Image1: TImage;
    Label1: TLabel;
    Edit1: TEdit;
    procedure Button2Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure Button5Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form2: TForm2;
  num:integer;
implementation

uses Unit1;

{$R *.xfm}

procedure TForm2.Button2Click(Sender: TObject);
begin
form2.Hide;
end;

procedure TForm2.Button4Click(Sender: TObject);
Var path:string;
begin
Edit1.Text:=IntToStr(num);
path:=Form1.Edit4.text;
image1.Picture.LoadFromFile(path+'/'+Edit1.text+'.bmp');
num:=num+1;
end;

procedure TForm2.FormCreate(Sender: TObject);
begin
num:=StrToInt(Form1.Edit2.Text);
Edit1.text:=IntToStr(num);
end;

procedure TForm2.Button5Click(Sender: TObject);
var path:string;
begin
num:=num-1;
path:=Form1.Edit4.text;
image1.Picture.LoadFromFile(path+'/'+IntToStr(StrToInt(Edit1.text)-1)+'.bmp');
Edit1.Text:=IntToStr(num);

end;

procedure TForm2.Button3Click(Sender: TObject);
var path:string;
begin
path:=Form1.Edit4.text;
deletefile(path+'/'+IntToStr(num-1)+'.bmp');
application.MessageBox('Picture deleted','Delete');
end;

end.
