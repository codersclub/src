unit Unit1;

interface

uses
  SysUtils, Types, Classes, Variants, QGraphics, QControls, QForms, QDialogs,
  QExtCtrls, IdBaseComponent, IdComponent, IdTCPConnection, IdTCPClient,
  IdHTTP, QStdCtrls, QImgList, QComCtrls;

type
  TForm1 = class(TForm)
    IdHTTP1: TIdHTTP;
    Label1: TLabel;
    Edit1: TEdit;
    Label2: TLabel;
    Edit2: TEdit;
    Label3: TLabel;
    Edit3: TEdit;
    Edit4: TEdit;
    Button2: TButton;
    StatusBar1: TStatusBar;
    Label4: TLabel;
    Label5: TLabel;
    GroupBox1: TGroupBox;
    Label6: TLabel;
    GroupBox2: TGroupBox;
    Button3: TButton;
    Button4: TButton;
    Button5: TButton;
    procedure FormCreate(Sender: TObject);

    procedure Button5Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

uses Unit2;

{$R *.xfm}

procedure TForm1.FormCreate(Sender: TObject);
begin
Statusbar1.Panels.Items[0].Text:='[OK]';
end;


procedure TForm1.Button5Click(Sender: TObject);
begin
close;
end;

procedure TForm1.Button2Click(Sender: TObject);
var urls,urle:string;
    num,count:integer;
    body:TStringList;
begin
button2.Enabled:=false;
button4.Enabled:=false;
button5.Enabled:=false;
num:=Pos('*',Edit1.Text);
if num=0 then application.MessageBox('������� ������ *','error');
urls:=copy(Edit1.text,0,num-1);
urle:=copy(Edit1.text,num+1,length(Edit1.text));
{edit4.Text:=urle;}
for count:=StrToInt(Edit2.text) to StrToInt(Edit3.text) do
begin
body:=TStringList.Create;
if (button3.Down) then
begin
Break;
Application.MessageBox('�������� �������������','Stop');
end;
Statusbar1.Panels.Items[0].Text:='Getting image ...'+IntToStr(count);
if body.Add(idhttp1.Get(urls+IntToStr(count)+urle))<>0 then
begin
break;
Application.MessageBox('Connect error' , 'Error');
end;
body.SaveToFile(Edit4.text+'/'+IntToStr(count)+'.bmp');
Statusbar1.Panels.Items[0].Text:='Save image ...';
body.Free;
end;
Statusbar1.Panels.Items[0].Text:='[OK]';
button2.Enabled:=true;
button4.Enabled:=true;
button5.Enabled:=true;
end;




procedure TForm1.Button3Click(Sender: TObject);
begin
button2.Enabled:=true;
button4.Enabled:=true;
button5.Enabled:=true;
Statusbar1.Panels.Items[0].Text:='[OK]';
end;

procedure TForm1.Button4Click(Sender: TObject);
begin
form2.show;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
Application.MessageBox('Visit my h0me PaGe www.lynxpage.dax.ru','h0me PaGe');
end;

end.









