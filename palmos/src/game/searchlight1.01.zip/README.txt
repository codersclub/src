Searchlight is based on a handheld LCD game that I got from a
friend visiting Japan back in about 1983.  It was from Gakken
and was titled "Search Light".  I've always been a big fan of
simple games with excellent playability, and I always considered
this one to be one of the best of that genre.

I hope I've captured its essence in this PalmOS version.  I've
done my best to replicate the look and the gameplay.

I never had instructions for the game.  So I never really knew
exactly what "Game A" and "Game B" were.  From what I could gather
empirically, I've been able to make my versions of A and B play
in a similar fashion to the original.

I've included the source for Searchlight.  I used Code Warrior
to build the program.  I actually used Code Warrior Lite.  You
might notice that I don't have the "nagware" splash screen that
CW Lite builds into all apps.  That's because when I installed
the Palm OS 3.5 SDK for Code Warrior, that nag screen went away.
Shhh!  Don't tell Metrowerks!  :-)

Please feel free to look at and modify the source.  If you've
got good ideas, contact me, and maybe I can incorporate them
into a future release.

Jason Priebe <priebe@wral-tv.com>
June, 2000