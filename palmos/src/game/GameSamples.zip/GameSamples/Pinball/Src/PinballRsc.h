//***************************************************************
// *
// * Project:
// *    Pinball 
// *
// * Copyright info:
// *    This is free software; you can redistribute it and/or modify
// *    it as you like.
// *
// *    This program is distributed in the hope that it will be useful,
// *    but WITHOUT ANY WARRANTY; without even the implied warranty of
// *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
// *
// * FileName:
// *    PinballRsc.h
// * 
// * Description:
// *    Resource equates for the .rcp
// *
// * ToDo:
// *
// * History:
// *    06-Sept-2000	  jem		  InitialVersion
// *
// ****************************************************************/

//Menus
#define rscMenuID								1000

//Menu commands
#define rscMenuNewGameCmd				100
#define rscMenuInstructionsCmd			101
#define rscMenuHighScoresCmd			103
#define rscMenuAboutCmd					105

//Main game form
#define rscGameFormID						1000
#define rscGameScoreFieldID					1001
#define rscGameGadgetID						1002
#define rscGameStartLabelID					1003
#define rscGameResumeLabelID				1004

//Display the final score
#define rscFinalScoreFormID						1100
#define rscFinalScoreScoreLabelID				1101
#define rscFinalScoreScoreFieldID				1102
#define rscFinalScoreHighScoreLabelID			1103
#define rscFinalScoreHighScoreNameFieldID		1104
#define rscFinalScoreOKButtonID					1105

//show the high scores
#define rscHighScoreFormID						1200
#define rscHighScoreTableID						1201
#define rscHighScoreOKButtonID					1202
#define rscHighScoreClearButtonID				1203
#define rscHighScoreRankLabelID					1204
#define rscHighScorePlayerNameLabelID			1205
#define rscHighScoreScoreLabelID				1206

#define rscClearHighScoresAlertID				2000

#define rscAboutBoxCopyrightYearStr				3000
#define rscAboutBoxExtraCreditStr				3001
#define rscInstructionsStr						3002

#define rscGameBallBmpID						7000
#define rscGreyGameBallBmpID					8000
