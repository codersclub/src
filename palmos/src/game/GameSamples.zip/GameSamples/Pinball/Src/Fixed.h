/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Fixed.h
 * 
 * Description:
 *    Header for the fixed point library
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  Initial Version
 *
 ****************************************************************/

//Allow the inline keyword to compile under VC
#if defined(_MSC_VER)
  #define INLINE
#else
  #define INLINE inline
#endif

#ifndef _FIXED_H_
#define _FIXED_H_

//Format is S.23.8
typedef Int32 Fixed32;

#define SHIFT		  8
#define kTotalShift	  256.0


#define HALF		  0x00000080
#define NEG_ONE		  0xFFFFFF00
#define NEG_TWO		  0xFFFFFE00
#define ONE			  0x00000100
#define TWO			  0x00000200
#define ZERO		  0x00000000

#define Sqrt(num)				  (DoubleToFixed(sqrt(FixedToDouble(num))))

#define Fixed2(a)				  (MultFixed(a, a))
#define FixedDist2(a, b)		  (Fixed2(a.x - b.x) + Fixed2(a.y - b.y))

#define DistanceFixed(a, b)		  (Sqrt(FixedDist2(a, b)))

#define FixedMag(v)				  (Sqrt(Fixed2(v.x) + Fixed2(v.y)))

INLINE Fixed32 IntToFixed(Int32 num);
INLINE Fixed32 DoubleToFixed(double num);
INLINE Int32 FixedToInt(Fixed32 num);
INLINE double FixedToDouble(Fixed32 num);

INLINE Fixed32 AddFixed(Fixed32 a, Fixed32 b);
INLINE Fixed32 SubFixed(Fixed32 a, Fixed32 b);
INLINE Fixed32 MultFixed(Fixed32 a, Fixed32 b);
INLINE Fixed32 DivFixed(Fixed32 a, Fixed32 b);

INLINE Fixed32 AbsFixed(Fixed32 num);

#endif //_FIXED_H_