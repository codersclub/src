/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Model.h
 * 
 * Description:
 *    Equates for the model and model function exports
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  InitialVersion
 *
 ****************************************************************/

#ifndef _MODEL_H_
#define _MODEL_H_

#include "Pinball.h"
#include "ModelActions.h"

#define kMaxNoMoves					5

#define kGravConst					0x00000130	  //1.125

#define kFrictionCoeff				0x000000F3	  //0.95
#define kWallFrictionCoeff			0.95		  //must stay double
#define kMinVelocity				0x00000019	  //0.1
#define kMaxVelocity				0x00001400	  //25

#define kMinX						0x00002800	  //40
#define	kMaxX						0x00009E00	  //160
#define kMinY						0x00001400	  //20
#define kMaxY						0x00009E00	  //160

#define kMaxFlipperDist				0x00001500	  //21

#define kBallMaxVelocity			kMaxVelocity
#define kFlipperVelocityStep		0.75

#define kTiltMult					0x00000500	  //5

//partitioning information
#define kMaxPartitionRows			4
#define kMaxPartitionCols			3

#define kPartitionX					0x00002800	  //40
#define kPartitionY					0x00001400	  //20
#define kPartitionWidth				0x00002800	  //40
#define kPartitionHeight			0x00002800	  //40


typedef void (*clientDrawFnT)(UInt8 ulx, UInt8 uly);
typedef void (*clientPollingFnT)(void);
typedef void (*callbackFnT)(UInt16 num);

void ModelInit(UInt16 numObjects, UInt16 numFlippers, clientDrawFnT drawBall, clientPollingFnT checkFlippers);
void ModelFree(void);
void ModelCollide(void);
void ModelTilt(void);

UInt16 ModelEnterBounceWall(UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, 
		double bx, double by, double rollCoeff, double absorbPct, callbackFnT action, UInt16 num);
UInt16 ModelEnterFullWall(UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, double bx, double by, 
			double rollCoeff, double absorbPct, UInt32 points, callbackFnT action, UInt16 num);
UInt16 ModelEnterWall(UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, callbackFnT action, UInt16 num);
void ModelEditWall(UInt16 objNumber, UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, double bx, double by, 
		  double rollCoeff, double absorbPct, UInt32 points, Boolean usable, UInt16 num);

UInt16 ModelEnterCircle(double cx, double cy, double radius, double bounce, UInt32 points, callbackFnT action, UInt16 num);
void ModelEditCircle(UInt16 objNumber, double cx, double cy, double radius, double bounce, UInt32 points, Boolean usable, UInt16 num);

void ModelEditBall(UInt8 ulx, UInt8 uly, double radius, double velocity, Int16 angle);

void ModelEnterFlipper(UInt8 flipNum, UInt8 pivotX, UInt8 pivotY, UInt8 ends[kFlipperNumFrames][2], double rollCoeff, double absorbPct, callbackFnT action, UInt16 num);
void ModelFlipFlipper(UInt8 flipNum, Boolean up);

Boolean ModelObjBeenHit (UInt16 objNumber);
void ModelEnableObj (UInt16 objNumber);
void ModelDisableObj (UInt16 objNumber);

#endif //_MODEL_H_