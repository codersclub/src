/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    ModelActions.h
 * 
 * Description:
 *    General equates for the pinball game and model
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  InitialVersion
 *
 ****************************************************************/

#ifndef _MODELACTIONS_H_
#define _MODELACTIONS_H_

#include "Pinball.h"

#define kScoreBufferSize	64

#define kMaxFlippers		2
#define kMaxBalls			1

#define kDefaultBalls		3

#define kPeriodLength		1

#define	kMaxScreenWidth			160
#define kMaxScreenHeight		160

#define	kPinballBorder			4
#define kPinballTopLeftX		kPinballBorder
#define kPinballTopLeftY		20

#define kPinballTableWidth	(kMaxScreenWidth - (2 * kPinballBorder))
#define kPinballTableHeight (kMaxScreenHeight - kPinballTopLeftY - kPinballBorder)

#define kFlipperNumFrames			5
#define kFlipperHeight				15
#define kFlipperWidth				21
#define kFlipperMult				4
#define kLeftFlipperLeft			68
#define kLeftFlipperTop				140
#define kRightFlipperLeft			100
#define kRightFlipperTop			140

#define kFlipperInsetX				0
#define kFlipperInsetY				6

#define kBallX						148
#define kBallY						125
#define kBallNumFrames					1
#define kBallHeight						9
#define kBallWidth						9
#define kBallRadius						4.5

#define kMaxBumpers						3
#define	kBumperWidth					15
#define kBumperHeight					15
#define kBumperRadius					7.5
#define kBumperNumFrames				3 

#define kBorderTopX						0
#define kBorderTopY						20
#define kBorderWidth					160
#define kBorderHeight					140
#define kBorderNumFrames				1

#define kMaxLights						2
#define kLeftFlipperLightX				42
#define kLeftFlipperLightY				145
#define kRightFlipperLightX				133
#define kRightFlipperLightY				145
#define kLightNumFrames					3

#define kTrackX							5
#define kTrackY							84
#define kTrackWidth						31
#define kTrackHeight					70
#define kNumTrackFrames					8

#define kTrafficX						138
#define kTrafficY						76
#define kTrafficNumFrames				4
#define kTrafficHeight					21
#define kTrafficWidth					7

#define kLeftTriBumpX					59
#define kLeftTriBumpY					116
#define kRightTriBumpX					117
#define kRightTriBumpY					116
#define kTriBumpWidth					12
#define kTriBumpHeight					10
#define kTriBumpNumFrames				2
#define kLeftTriBump					0
#define kRightTriBump					1
#define kMaxTriBumps					2

#define kStarX							43
#define kStarY							50
#define kStarRadius						2.5
#define kStarNumFrames					3

#define kBallIndicatorX					100
#define kBallIndicatorY					2
#define kBallIndicatorDeltaX			10
#define kBallIndicatorWidth				60
#define kBallIndicatorHeight			9

#define kSpecialX					3
#define kSpecialY					23

#define kLeftTurnL			0
#define kLeftTurnR			1
#define kRightTurn			2
#define kStraight			3

#define kTiltPauseTime				10

#define		LeftFlipper				keyBitHard1
#define		LeftFlipperAlt			keyBitHard2
#define		RightFlipper			keyBitHard3
#define		RightFlipperAlt			keyBitHard4
#define		Launcher				keyBitPageUp
#define		Tilt					keyBitPageDown

#define		kLeftFlipper			1
#define		kRightFlipper			0

#define		Ball					0
#define		RF1						1
#define		RF2						2
#define		RF3						3
#define		RF4						4
#define		RF5						5
#define		LF1						6
#define		LF2						7
#define		LF3					  	8
#define		LF4					  	9
#define		LF5						10
#define		Border1				  	11
#define		Bumper1					12
#define		Bumper2					13
#define		Bumper3					14
#define		Light1					15
#define		Light2				    16
#define		Light3					17
#define		Track	  				18
#define		Car1					19
#define		Car2					20
#define		Car3					21
#define		Car4					22
#define		Car5					23
#define		Car6					24
#define		Car7					25
#define		Car8					26
#define		Traffic1				27
#define		Traffic2				28
#define		Traffic3				29
#define		Traffic4				30
#define		TriBumpL1				31
#define		TriBumpL2				32
#define		TriBumpR1				33
#define		TriBumpR2				34
#define		Star1					35
#define		Star2					36
#define		Star3					37

//specials
#define		CheckeredFlag			38
#define		GreenFlag				39
#define		Flip1					40
#define		Flip2					41
#define		Flip3					42
#define		Flip4					43
#define		BitmapTypeCount			44


#define		FirstFlipper			RF1
#define		FirstBall				Ball
#define		FirstBackground			Border1
#define		FirstBumper				Bumper1
#define		FirstLight				Light1
#define		FirstTrack				Track
#define		FirstCar				Car1
#define		FirstTraffic			Traffic1
#define		FirstTriBump			TriBumpL1
#define		FirstStar				Star1

#define		kFirst16BitBitmapID		rscGameBallBmpID
#define		kFirst2BitBitmapID		rscGreyGameBallBmpID

#define pauseTime					(2 * SysTicksPerSecond())

//Macros

#define GetFlipperBitmap(flipper, frame)		(FirstFlipper + (flipper * kFlipperNumFrames) + frame)

#define GetBallBitmap(frame)					(FirstBall + frame)

#define GetBackgroundBitmap(frame)				(FirstBackground + frame)

#define GetBumperBitmap(frame)					(FirstBumper + frame)

#define GetLightBitmap(frame)					(FirstLight + frame)

#define GetTrackBitmap							(FirstTrack)

#define GetCarBitmap(frame)						(FirstCar + frame)

#define GetTrafficBitmap(frame)					(FirstTraffic + frame)

#define GetTriBumpBitmap(side, frame)			(FirstTriBump + (side * kTriBumpNumFrames) + frame)

#define GetStarBitmap(frame)					(FirstStar + frame)

/********************************************************
 *
 *	  Externals
 *
 ******************************************************/

typedef struct
{
	UInt8 top, left;
	UInt8 frameNumber;
	UInt8 numFrames;
	UInt16 objNumber;
	Boolean changed;
}
objectInfoT;

typedef struct
{
	UInt16 numFlippers, numBumpers, numTriBumps, numLights;
	objectInfoT flipperInfo[kMaxFlippers];
	objectInfoT ballInfo;
	objectInfoT bumperInfo[kMaxBumpers];
	objectInfoT light[kMaxLights];
	objectInfoT triBumpInfo[kMaxTriBumps];
	objectInfoT	border, traffic, star;
	UInt16 stopperNum, enterBoard, bottomWall, tunnelL, tunnelR, straightAway;
}
gameStateT;

typedef struct
{
	UInt16 status;
	UInt16 ballsLeft;

	UInt32 score;
	Char scoreBuffer[kScoreBufferSize];
	FieldPtr scoreField;

	UInt32 pausedTime, nextPeriodTime, periodLength, startTime, tiltTime;
	UInt16 trackFrame;
	Boolean paused, tilt;

	WinHandle windowHandles[BitmapTypeCount];
	WinHandle backWindowH;

	gameStateT next, last;
}
gameInfoT;

extern void GameStateModelInit(gameInfoT * gameInfoP);

extern void GameInit(gameInfoT * gameInfoP);

#endif	// _MODELACTIONS_H_