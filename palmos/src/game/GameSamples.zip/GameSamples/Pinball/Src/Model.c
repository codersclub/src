/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Model.c
 * 
 * Description:
 *    Implementation of the physics model for the pinball game
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  Initial Version
 *
 ****************************************************************/

#include <PalmOS.h>
#include "Fixed.h"
#include "Model.h"
#include "Pinball.h"
#include "PinballRsc.h"

// this is so that the math library will work
typedef UInt16  UInt;
typedef Int16   Int;
typedef UInt16* UIntPtr;
typedef UInt32  ULong;

#include "MathLib.h"

// ---------------------------------------
// Macros
// ---------------------------------------

#define PI											3.1415
#define DegToRad(angle)								((angle) * (PI / 180.0))
#define Power2(num)									((num) * (num))

// for the flipper information in an array
#define X				0
#define Y				1

//a half circle is 180 degrees
#define kHalfCircle		180

//how many increments to do the ball drawing in
#define kBallSteps		4

/********************************
*
*	Enums and structs
*
*********************************/

// An enumeration of the types of object available
// in the model
enum
  {
	Wall, Circle, Flipper
  };

// A simple vector type to build on
typedef struct
  {
	Fixed32         x, y;
  }
vectorT;

// A 2D matrix to use for rotations and transformations

typedef struct
  {
	Fixed32         m[2][2];
  }
matrixT;

// A type that represents a wall (a line) in the game
// It holds information for the start and end points, the size
// of the wall, and the bouncing information along with the amount of
// points given for each hit.

typedef struct
  {
	vectorT         p0, p1, V, n, bounce;
	matrixT         trans;
	UInt32          points;
	Fixed32         rollCoeff, absorbPct;
  }
wallT;

// A type that holds information for a circlular object
// This holds the circle's center and it's radius, and point value
typedef struct
  {
	vectorT         p0;
	Fixed32         radius, bounce;
	UInt32          points;
  }
circleT;

// A data type for the ball, which stores its velocity, start and finish
// position
// radius and activity

typedef struct
  {
	vectorT         C0, C1, V;
	Fixed32         radius;
  }
ballT;

//bitfield for the different sectors we have in the game
//so that the collision checking can be _much_ faster. :)
typedef UInt16		partitionT;


// A data type that represents a flipper
// A flipper is composed of kFlipperNumFrames discrete walls which are 
// alternatly selected depending on the current position

typedef struct
  {
	wallT           pos[kFlipperNumFrames];
	vectorT         pivot;
	UInt8           curPos, lastPos;
	Boolean         moved;
	Fixed32         staticMult;
	callbackFnT		action;
	UInt16			num;
	partitionT		sectors;
  }
flipperT;

// A container tagged union that holds all of the information for all of the
// different types and information about whether it is active or has been 
// recently "hit"

typedef struct
  {
	Char            type;
	Boolean         active, hit;
	UInt16			num;
	callbackFnT		action;
	partitionT		sectors;
	union
	  {
		circleT         circle;
		wallT           wall;
	  }
	data;
  }
objectT;

//a container for the closest object information
//we hold the type of object, it's index, and it's distance
//if the ball is not near anything, objNum should have -1
typedef struct
{
  UInt8 type;
  UInt16 objNum;
  Fixed32 objDist;
}
closestInfoT;

// The main data structure that holds all the model information
// We hold a dynamic array of objects, a static array of balls
// and some callback functions to draw and check the flipper states

typedef struct
  {
	objectT*        objects;
	flipperT *		flippers;
	ballT           ball;
	UInt16          numObjects, numFlippers;
	clientDrawFnT   drawBall;
	clientPollingFnT checkFlippers;
	closestInfoT	  lastHit;
	Boolean			initialized;
  }
modelInfoT;

//----------------------------------
//
//		 globals
//
//----------------------------------

static modelInfoT modelInfo;

#pragma mark
#pragma mark -- Function prototypes --

/****************************************
 *
 *	  Function prototypes
 *
 ****************************************/

static void     PrvModelCollideBall (ballT * ballP);

static void		PrvModelFindClosestObj(closestInfoT * closestP,
					closestInfoT * lastHitP, Fixed32 longestDist);
static Fixed32  PrvModelBallIntersectsWall (ballT * ballP, wallT * wallP);
static Fixed32  PrvModelBallIntersectsCircle (ballT * ballP, circleT * circleP);
static Fixed32  PrvModelBallIntersectsFlipper (ballT * ballP, flipperT * flipperP);
static Boolean  PrvModelBallInWallBounds (vectorT ballPos, wallT * wallP,
										  Fixed32 ballRadius);

static void     PrvModelMoveBall (ballT * ballP, Fixed32 distFract);

static void		PrvModelBounceBallOffClosest (closestInfoT * closestP, Fixed32 * distFractP);
static void     PrvModelBounceBallOffWall (ballT * ballP, wallT * wallP);
static void     PrvModelBounceBallOffCircle (ballT * ballP, circleT * circleP);
static void     PrvModelBounceBallOffFlipper (ballT * ballP, flipperT * flipper);

static void     PrvModelAddGravity (ballT * ballP);
static void     PrvModelAddFriction (ballT * ballP);
static Boolean  PrvModelCorrectVelocity (ballT * ballP);
static vectorT  PrvCreateFlipperVelocity (flipperT * flipperP, ballT * ballP);
static vectorT  PrvCreateRollVector (vectorT p0, vectorT p1, Fixed32 rollConstant);
static void		PrvModelEditWallHelper(wallT * wallp, vectorT c1, vectorT c2, vectorT bY, 
						  Fixed32 rollCoeff, Fixed32 absorbPct, UInt32 points);
static void		PrvModelStillAgainstObj(closestInfoT * lastHitP);

static void		PrvPartitionObject(objectT * objectP);
static Boolean	PrvPartitionWallHelper(wallT * wallP, UInt8 row, UInt8 col);
static Boolean	PrvPartitionCircleHelper(circleT * circleP, UInt8 row, UInt8 col);
//static Boolean	PrvPartitionFlipperHelper(flipperT * flipperP, UInt8 row, UInt8 col);
static Boolean	PrvPartitionVectorHelper(vectorT p0, vectorT p1, UInt8 row, UInt8 col);
static Boolean	PrvPointInBox(vectorT p0, vectorT b0, vectorT b1); 
static Boolean	PrvBoxIntersectsBox(vectorT p0, vectorT p1, 
									vectorT q0, vectorT q1, Fixed32 radius);

INLINE static vectorT PrvVectorRotate90 (vectorT vP);
INLINE static vectorT PrvVectorNormalize (vectorT vP);

INLINE static vectorT PrvVectorAdd (vectorT v1, vectorT v2);
INLINE static vectorT PrvVectorSub (vectorT v1, vectorT v2);
INLINE static vectorT PrvVectorMultConst (vectorT v1, Fixed32 constant);
INLINE static vectorT PrvVectorMultMatrix (vectorT v1, matrixT mat);
INLINE static Fixed32 PrvVectorDot (vectorT v1, vectorT v2);

INLINE static vectorT PrvIntToVector (UInt8 x, UInt8 y);
INLINE static vectorT PrvDoubleToVector (double x, double y);
INLINE static vectorT PrvFixedToVector (Fixed32 x, Fixed32 y);

static Boolean  PrvModelSolveQuad (Fixed32 a, Fixed32 b, Fixed32 c,
								   Fixed32 * r0, Fixed32 * r1);
static matrixT  PrvModelCreateBounceTransform (vectorT v);

#pragma mark
#pragma mark -- Exported functions --

/***************************************************************
 *  Function:     ModelInit
 *
 *
 *  Summary:      Initializes the physics model and allocates 
 *	  space on the heap for the objects
 *
 *  Parameters:
 *	  numObjects	IN	  The number of objects to allocate storage for
 *	  drawBall		IN	  A function pointer to a function to draw the ball
 *	  checkFlippers	IN	  A function pointer to a function that checks the status
 *						  of the flipper controls
 *  Returns:
 *    Nothing
 *  
 *  Called By: 
 *    GameModelInit
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelInit (UInt16 numObjects, UInt16 numFlippers, clientDrawFnT drawBall, clientPollingFnT checkFlippers)
{
  UInt16          error;

  modelInfo.numObjects = 0;
  modelInfo.numFlippers = numFlippers;
  modelInfo.objects = MemPtrNew (numObjects * sizeof (objectT));
  modelInfo.flippers = MemPtrNew (numFlippers * sizeof (flipperT));
  modelInfo.drawBall = drawBall;
  modelInfo.checkFlippers = checkFlippers;
  modelInfo.initialized = true;

  // load the math library
  error = SysLibFind (MathLibName, &MathLibRef);	// if it's already
													// loaded, find it
  if (error)
	error = SysLibLoad (LibType, MathLibCreator, &MathLibRef);	// if not,
																// load it
  if (!error)
	{
	  error = MathLibOpen (MathLibRef, MathLibVersion);		// open it
	}

  modelInfo.lastHit.objNum = -1;		// for the purposes of the collisions, we
								// haven't hit anything
}

/***************************************************************
 *  Function:     ModelFree
 *
 *  Summary:      Frees the physics model
 *    
 *  Parameters:	  None
 *
 *  Returns:	  Nothing
 *  
 *  Called By:	  GameStateElapse
 *    
 *  Notes:
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelFree (void)
{
  if (modelInfo.initialized)
  {
	MemPtrFree (modelInfo.objects);
	MemPtrFree (modelInfo.flippers);
	MathLibClose (MathLibRef, NULL);
	modelInfo.initialized = false;
  }
}

/***************************************************************
 *  Function:     ModelCollide
 *
 *
 *  Summary:      Runs the model through one round of collisions, ball by ball
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameStateElapse
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelCollide (void)
{
  PrvModelCollideBall (&(modelInfo.ball));
}

/***************************************************************
 *  Function:     ModelTilt
 *
 *
 *  Summary:      Implements a tilt to all the balls by adding
 *	  an upward vector to their velocity
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameStateElapse
 *    
 *
 *  Notes:
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelTilt (void)
{
  vectorT         grav;

  grav.x = 0;
  grav.y = MultFixed (kTiltMult, MultFixed (NEG_ONE, kGravConst));

  modelInfo.ball.V = PrvVectorAdd (modelInfo.ball.V, grav);
}

/***************************************************************
 *  Function:     PrvModelEnterObject
 *
 *
 *  Summary:      Enters an object into the global array
 *    
 *
 *  Parameters:	  
 *	  number	  IN	  The index of the object in the array
 *	  type		  IN	  The type of object to enter
 *	  action	  IN	  The callback functions to store.
 *
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    ModelEditWall, ModelEditCircle
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelEnterObject (UInt16 number, UInt8 type, callbackFnT action)
{
  modelInfo.objects[number].type = type;
  modelInfo.objects[number].hit = false;
  modelInfo.objects[number].action = action;
  modelInfo.objects[number].active = true;
}

/***************************************************************
 *  Function:     ModelEnterBounceWall
 *
 *
 *  Summary:      Enters a wall with just bounce characteristics
 *	  into the model
 *    
 *
 *  Parameters:
 *	  x1, y1	IN		Starting coordinate pair
 *	  x2, y2	IN		Ending coordinate pair
 *	  bx, by	IN		doubles for the bounce amount (in pixels)
 *	  rollCoeff	IN		The rolling coeffecient (how much the ball will roll)
 *	  absorbPct	IN		How much the wall absorbs ball velocity
 *	  action	IN		The callback function for the wall
 *    
 *  Returns:
 *    The index of the object in the array
 *  
 *  Called By: 
 *    GameStateModelInit
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

UInt16
ModelEnterBounceWall (UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, double bx, double
					  by, double rollCoeff, double absorbPct, callbackFnT action,
					  UInt16 num)
{
  UInt16           number = modelInfo.numObjects;
  ModelEditWall (number, x1, y1, x2, y2, bx, by,
				 rollCoeff, absorbPct, 0, true, num);
  PrvModelEnterObject(number, Wall, action);
  modelInfo.numObjects++;
  return number;
}

/***************************************************************
 *  Function:     ModelEnterFullWall
 *
 *
 *  Summary:      Enters a wall with all characteristics
 *    
 *  Parameters:
 *	  x1, y1	IN		Starting coordinate pair
 *	  x2, y2	IN		Ending coordinate pair
 *	  bx, by	IN		doubles for the bounce amount (in pixels)
 *	  rollCoeff	IN		The rolling coeffecient (how much the ball will roll)
 *	  absorbPct	IN		How much the wall absorbs ball velocity
 *	  points	IN		The number of points given for hitting the wall
 *	  action	IN		The callback function for the wall
 *    
 *  Returns:
 *    The index of the object in the array
 *  
 *  Called By: 
 *    GameStateModelInit
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

UInt16
ModelEnterFullWall (UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, double bx,
					double by, double rollCoeff, double absorbPct, 
					UInt32 points, callbackFnT action, UInt16 num)
{
  UInt16           number = modelInfo.numObjects;
  ModelEditWall ((modelInfo.numObjects)++, x1, y1, x2, y2, bx, by,
				 rollCoeff, absorbPct, points, true, num);
  PrvModelEnterObject(number, Wall, action);
  modelInfo.numObjects++;
  return number;
}

/***************************************************************
 *  Function:     ModelEnterWall
 *
 *
 *  Summary:      Enters a wall with only coordinates
 *    
 *
 *  Parameters:
 *	  x1, y1	IN	  Starting coordinate pair
 *	  x2, y2	IN	  Ending coordinate pair
 *	  action	IN	  The callback function for the wall
 *
 *    
 *  Returns:
 *    The index of the object in the array
 *  
 *  Called By: 
 *    GameStateModelInit
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

UInt16
ModelEnterWall (UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2, callbackFnT action, UInt16 num)
{
  UInt16           number = modelInfo.numObjects;
  ModelEditWall ((modelInfo.numObjects)++, x1, y1, x2, y2, 0, 0, 0,
				 kWallFrictionCoeff, 0, true, num);
  PrvModelEnterObject(number, Wall, action);
  modelInfo.numObjects++;
  return number;
}

/***************************************************************
 *  Function:     ModelEditWall
 *
 *
 *  Summary:      Allows editing of a wall in place
 *    
 *
 *  Parameters:
 *	  objNumber		IN		The index of the object within the array
 *	  x1, y1	IN		Starting coordinate pair
 *	  x2, y2	IN		Ending coordinate pair
 *	  bx, by	IN		doubles for the bounce amount (in pixels)
 *	  rollCoeff	IN		The rolling coeffecient (how much the ball will roll)
 *	  absorbPct	IN		How much the wall absorbs ball velocity
 *	  points	IN		The number of points given for hitting the wall
 *	  action	IN		The callback function for the wall
 *	  usable	IN		Whether the wall is usable or not
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    ModelEnterWall, ModelEnterFullWall, ModelEnterBounceWall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelEditWall (UInt16 objNumber, UInt8 x1, UInt8 y1, UInt8 x2, UInt8 y2,
			   double bx, double by, double rollCoeff, double absorbPct,
			   UInt32 points, Boolean usable, UInt16 num)
{
  modelInfo.objects[objNumber].active = usable;
  modelInfo.objects[objNumber].num = num;
  PrvModelEditWallHelper (&(modelInfo.objects[objNumber].data.wall),
						  PrvIntToVector (x1, y1),
						  PrvIntToVector (x2, y2), PrvDoubleToVector (bx, by),
						  DoubleToFixed (rollCoeff), DoubleToFixed
						  (absorbPct), points);
  PrvPartitionObject(&(modelInfo.objects[objNumber]));
}

/***************************************************************
 *  Function:     ModelEnterFlipper
 *
 *
 *  Summary:      Enters a flipper into the physics model
 *    
 *
 *  Parameters:
 *	  flipNum	  IN	  The number of the flipper
 *	  pivotX, pivotY	IN	  The coordinates of the flipper's pivot point
 *	  ends		  IN	  An array of points that are the endpoints for each
 *						  frame of flipper movement
 *	  rollCoeff	  IN	  How much the flipper allows a roll
 *	  absorbPct	  IN	  How much the flipper absorbs momentum
 *	  action	  IN	  A callback function for the flipper
 *
 *  Returns:	  nothing
 *    
 *  
 *  Called By:	  GameStateModelInit
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelEnterFlipper (UInt8 flipNum, UInt8 pivotX, UInt8 pivotY, UInt8
				   ends[kFlipperNumFrames][2], double rollCoeff, double absorbPct,
				   callbackFnT action, UInt16 num)
{
  UInt8           i;
  vectorT         v;

  modelInfo.flippers[flipNum].action = action;
  modelInfo.flippers[flipNum].curPos = 0;
  modelInfo.flippers[flipNum].lastPos = 0;
  modelInfo.flippers[flipNum].moved = false;
  modelInfo.flippers[flipNum].staticMult = kFlipperMult;
  modelInfo.flippers[flipNum].num = num;

  modelInfo.flippers[flipNum].pivot = PrvIntToVector(pivotX, pivotY);

  for (i = 0; i < kFlipperNumFrames; i++)
	{
	  if (pivotX < ends[i][X])
		{
		  modelInfo.flippers[flipNum].pos[i].p0 = PrvIntToVector(pivotX, pivotY);
		  modelInfo.flippers[flipNum].pos[i].p1 = PrvIntToVector(ends[i][X], ends[i][Y]);
		}
	  else
		{
		  modelInfo.flippers[flipNum].pos[i].p1 = PrvIntToVector(pivotX, pivotY);
		  modelInfo.flippers[flipNum].pos[i].p0 = PrvIntToVector(ends[i][X], ends[i][Y]);
		}

		modelInfo.flippers[flipNum].pos[i].V = PrvVectorSub(modelInfo.flippers[flipNum].pos[i].p1, 
															modelInfo.flippers[flipNum].pos[i].p0);

	  v = PrvVectorNormalize (modelInfo.flippers[flipNum].pos[i].V);
	  modelInfo.flippers[flipNum].pos[i].n = PrvVectorRotate90 (v);
	  modelInfo.flippers[flipNum].pos[i].trans = PrvModelCreateBounceTransform (v);
	  modelInfo.flippers[flipNum].pos[i].rollCoeff = DoubleToFixed (rollCoeff);
	  modelInfo.flippers[flipNum].pos[i].absorbPct = DoubleToFixed (absorbPct);
	}
  //PrvPartitionFlipper(&(modelInfo.flippers[flipNum]));
}

/***************************************************************
 *  Function:     ModelFlipFlipper
 *
 *
 *  Summary:      Moves the flipper up or down
 *    
 *
 *  Parameters:
 *		flipNum		IN	  The index of the flipper to move
 *		up			IN	  true to move up, false to move down
 *
 *    
 *  Returns:
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelFlipFlipper (UInt8 flipNum, Boolean up)
{
  if (up)
	{
	  //move up if possible
	  if (modelInfo.flippers[flipNum].curPos < (kFlipperNumFrames - 1))
		{
		  modelInfo.flippers[flipNum].lastPos = (modelInfo.flippers[flipNum].curPos++);
		  modelInfo.flippers[flipNum].moved = true;
		}
	  else
		{
		  modelInfo.flippers[flipNum].lastPos =	modelInfo.flippers[flipNum].curPos;
		  modelInfo.flippers[flipNum].moved = false;
		}
	}
  else
	{
	  //move down if possible
	  if (modelInfo.flippers[flipNum].curPos > 0)
		{
		  modelInfo.flippers[flipNum].lastPos =	 (modelInfo.flippers[flipNum].curPos--);
		  modelInfo.flippers[flipNum].moved = true;
		}
	  else
		{
		  modelInfo.flippers[flipNum].lastPos =	modelInfo.flippers[flipNum].curPos;
		  modelInfo.flippers[flipNum].moved = false;
		}
	}
}

/***************************************************************
 *  Function:     ModelEnterCircle
 *
 *
 *  Summary:      Enters a circle into the physics model
 *    
 *
 *  Parameters:
 *	  cx, cy	  IN	  The coordinates of the circle's center
 *	  radius	  IN	  The circle's radius
 *	  bounce	  IN	  The magnitude of push back from the circle
 *	  points	  IN	  The points awarded for hitting the circle
 *	  action	  IN	  The circle's callback function
 *
 *    
 *  Returns:
 *    The circle's index for later use
 *  
 *  Called By: 
 *    GameStateModelInit
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

UInt16
ModelEnterCircle (double cx, double cy, double radius, double bounce,
				  UInt32 points, callbackFnT action, UInt16 num)
{
  UInt16           number = modelInfo.numObjects;
  ModelEditCircle ((modelInfo.numObjects)++, cx, cy, radius, bounce,
				   points, true, num);
  PrvModelEnterObject(number, Circle, action);
  modelInfo.numObjects++;
  return number;
}

/***************************************************************
 *  Function:     ModelEditCircle
 *
 *
 *  Summary:      Allows editing of a circle's parameters
 *    
 *
 *  Parameters:
 *	  objNumber		IN		The index of the circle to edit
 *	  cx, cy	  IN	  The coordinates of the circle's center
 *	  radius	  IN	  The circle's radius
 *	  bounce	  IN	  The magnitude of push back from the circle
 *	  points	  IN	  The points awarded for hitting the circle
 *	  usable	  IN	  true if the circle bounces things, false if it doesn't
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelEditCircle (UInt16 objNumber, double cx, double cy, double radius, double
				 bounce, UInt32 points, Boolean usable, UInt16 num)
{
  modelInfo.objects[objNumber].active = usable;
  modelInfo.objects[objNumber].data.circle.p0 = PrvDoubleToVector(cx, cy);
  modelInfo.objects[objNumber].data.circle.bounce = DoubleToFixed (bounce);
  modelInfo.objects[objNumber].data.circle.radius = DoubleToFixed (radius);
  modelInfo.objects[objNumber].data.circle.points = points;
  modelInfo.objects[objNumber].num = num;
  PrvPartitionObject(&(modelInfo.objects[objNumber]));
}

/***************************************************************
 *  Function:     ModelEditBall
 *
 *
 *  Summary:      Changes the ball's characteristics
 *    
 *
 *  Parameters:
 *	  ulx, uly		IN		The upper-left coordinates of the ball
 *	  radius		IN		The ball's radius
 *	  velocity		IN		The ball's velocity (in pixels)
 *	  angle			IN		The ball's initial angle
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    GameModelInit, GameLostBall, GameStateElapse
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
ModelEditBall (UInt8 ulx, UInt8 uly, double radius, double
			   velocity, Int16 angle)
{
  double          a;
  vectorT         V;

  a = DegToRad (angle + kHalfCircle);
  V.x = DoubleToFixed (velocity * cos (a));
  V.y = DoubleToFixed (velocity * sin (a));

  modelInfo.ball.radius = DoubleToFixed (radius);
  modelInfo.ball.C0 = PrvIntToVector(ulx, uly);

  modelInfo.ball.C0.x += modelInfo.ball.radius;
  modelInfo.ball.C0.y += modelInfo.ball.radius;

  modelInfo.ball.V = V;
  modelInfo.ball.C1 = PrvVectorAdd (V, modelInfo.ball.C0);
}

/***************************************************************
 *  Function:     ModelObjBeenHit
 *
 *
 *  Summary:      Predicate if the given object has been hit.  If it
 *		has, we reset our indicator.
 *    
 *
 *  Parameters:		objNumber	  IN	The index of the object to check
 *
 *  Returns:
 *    true if the object has been hit since last checked, false otherwise
 *  
 *  Called By: 
 *    GameStateElapse, GameStateDrawChanges
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE          Boolean
ModelObjBeenHit (UInt16 objNumber)
{
  if (modelInfo.objects[objNumber].hit)
	{
	  modelInfo.objects[objNumber].hit = false;
	  return true;
	}
  return false;
}

/***************************************************************
 *  Function:     ModelEnableObj
 *
 *
 *  Summary:      Enables an object
 *    
 *
 *  Parameters:	  objNumber		IN	  The object's index.
 *
 *    
 *  Returns:	nothing
 *    
 *  
 *  Called By: 
 *    GameStateElapse
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE void
ModelEnableObj (UInt16 objNumber)
{
  modelInfo.objects[objNumber].active = true;
}

/***************************************************************
 *  Function:     ModelDisableObj
 *
 *
 *  Summary:      Disables an object
 *    
 *
 *  Parameters:	  objNumber	  IN	The object's index
 *
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    GameStateElapse
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE void
ModelDisableObj (UInt16 objNumber)
{
  modelInfo.objects[objNumber].active = false;
}

#pragma mark
#pragma mark -- Partitioning functions --

/*********************************************
 *
 *	Function:	PrvPartitionObject
 *
 *	Description:	Runs through all the sectors in the
 *	  game and determines where a given object lies,
 *	  updating its bitfield of sectors.
 *
 *	Parameters:
 *	  objectP	  IN/OUT	  The object to "sectorize"
 *
 *	Returns:	nothing
 *
 *	Called by:	  ModelEditWall, ModelEditCircle
 *
 *	Notes:	  There are 12 sectors in the model right now (40x40)
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static void
PrvPartitionObject(objectT * objectP)
{
  UInt8 row, col;
  Boolean inSector;

  objectP->sectors = 0;
  for (row = 1; row <= kMaxPartitionRows; row++)
  {
	for (col = 1; col <= kMaxPartitionCols; col++)
	{
	  switch (objectP->type)
	  {
		case Wall: 
		  inSector = PrvPartitionWallHelper(&(objectP->data.wall), row, col);
		  break;
		case Circle:
		  inSector = PrvPartitionCircleHelper(&(objectP->data.circle), row, col);
		  break;
		default:
		  inSector = false;
		  break;
	  }
	  if (inSector)
	  {
		objectP->sectors = objectP->sectors | (0x0001 << ((row * kMaxPartitionCols) + col));
	  }
	}
  }
}

/*********************************************
 *
 *	Function:	  PrvPartitionWallHelper
 *
 *	Description:	Determines whether a wall is in
 *	  a given sector
 *
 *	Parameters:
 *	  wallP		  IN		A pointer to information on a wall
 *	  row, col	  IN		The row and col of the sector
 *
 *	Returns:	true if the wall is in the sector, false if
 *		it isn't
 *
 *	Called by:	  PrvPartitionObject
 *
 *	Notes:
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static Boolean
PrvPartitionWallHelper(wallT * wallP, UInt8 row, UInt8 col)
{
  return PrvPartitionVectorHelper(wallP->p0, wallP->p1, row, col);
}

/*********************************************
 *
 *	Function:	  PrvPartitionCircleHelper
 *
 *	Description:	Determines whether a circle is in
 *	  a given sector
 *
 *	Parameters:
 *	  wallP		  IN		A pointer to information on a circle
 *	  row, col	  IN		The row and col of the sector
 *
 *	Returns:	true if the circle is in the sector, false if
 *		it isn't
 *
 *	Called by:	  PrvPartitionObject
 *
 *	Notes:	  We use a bounding box to sectorize the circle - it's not as
 *	  accurate, but as long as we overestimate the sectors, it's fine
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static Boolean
PrvPartitionCircleHelper(circleT * circleP, UInt8 row, UInt8 col)
{
  vectorT ul, ur, ll, lr;

  //the four corners of the circle's bounding box
  ul = PrvFixedToVector(circleP->p0.x - circleP->radius, circleP->p0.y - circleP->radius);
  ur = PrvFixedToVector(circleP->p0.x + circleP->radius, circleP->p0.y - circleP->radius);
  ll = PrvFixedToVector(circleP->p0.x - circleP->radius, circleP->p0.y + circleP->radius);
  lr = PrvFixedToVector(circleP->p0.x + circleP->radius, circleP->p0.y + circleP->radius);

  return (PrvPartitionVectorHelper(ul, ur, row, col) ||
		  PrvPartitionVectorHelper(ul, ll, row, col) ||
		  PrvPartitionVectorHelper(ll, lr, row, col) ||
		  PrvPartitionVectorHelper(ur, lr, row, col));
}

/*********************************************
 *
 *	Function:		PrvPartitionBall
 *
 *	Description:	Finds the sectors that the ball is
 *	  in by treating it like a circle.
 *
 *	Parameters:
 *	  ballP		IN		A pointer to the ball's information
 *
 *	Returns:	A partitionT with the sectors that the
 *	  ball is currently in
 *
 *	Called by:
 *	  PrvModelCollideBall
 *
 *	Notes:
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static partitionT
PrvPartitionBall(ballT * ballP)
{
  partitionT ballSectors;
  UInt8 row, col;
  circleT circle;

  ballSectors = 0;
  circle.p0 = ballP->C0;
  circle.radius = ballP->radius;

  for(row = 1; row <= kMaxPartitionRows; row++)
  {
	for(col = 1; col <= kMaxPartitionCols; col++)
	{
	  if (PrvPartitionCircleHelper(&circle, row, col))
	  {
		ballSectors = ballSectors | (0x0001 << ((row * kMaxPartitionCols) + col));
	  }
	}
  }
  return ballSectors;
}

/*********************************************
 *
 *	Function:	  PrvPartitionVectorHelper
 *
 *	Description:	This is the workhorse function of the
 *	  partitioning . . . we determine the bounding box for the
 *	  given sector, and from there have two criteria for determinig
 *	  if the vector crosses the sector.
 *	  1) If either vector endpoint is in the sector, then it is in the
 *		sector
 *	  2) If the box of the sector intersects a box defined by the start
 *		and endpoints of the vector, then it is in the sector (overestimates)
 *
 *	Parameters:
 *	  p0, p1		IN		  The endpoints of the given vector
 *	  row, col		IN		  The row and column for the given sector
 *
 *	Returns:	true if the vector is in the sector, false if it isn't
 *
 *	Called by:	PrvPartitionWallHelper, PrvPartitionCircleHelper
 *
 *	Notes:	  I'm not sure that this always works . . . .
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static Boolean
PrvPartitionVectorHelper(vectorT p0, vectorT p1, UInt8 row, UInt8 col)
{
  Fixed32 startX, startY, endX, endY;
  vectorT start, end;

  startX = MultFixed(IntToFixed(col - 1), kPartitionWidth) + kPartitionX;
  endX = MultFixed(IntToFixed(col), kPartitionWidth) + kPartitionX;

  startY = MultFixed(IntToFixed(row - 1), kPartitionHeight) + kPartitionY;
  endY = MultFixed(IntToFixed(row), kPartitionHeight) + kPartitionY;
  start = PrvFixedToVector(startX, startY);
  end = PrvFixedToVector(endX, endY);

  if (PrvPointInBox(p0, start, end) ||
	  PrvPointInBox(p1, start, end))
	{
	  //if the sector contains an endpoint, then
	  // it's in the sector
	  return true;
	}

  if (PrvBoxIntersectsBox(p0, p1, start, end, modelInfo.ball.radius))
	{
	  return true;
	}

  return false;
}

/*********************************************
 *
 *	Function:	PrvBoxIntersectsBox
 *
 *	Description:	Determines if a two boxes (defined by upper-left
 *	  and lower-right points) overlap
 *
 *	Parameters:
 *	  p0, p1		IN		The upper left and lower right corners of one box
 *	  q0, q1		IN		The upper left and lower right corners of one box
 *	  radius		IN		The radius of the ball (for added security)
 *
 *	Returns:	true if the boxes overlap, false otherwise
 *
 *	Called by:	  PrvPartitionVectorHelper
 *
 *	Notes:	  http://www.gamasutra.com
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static Boolean
PrvBoxIntersectsBox (vectorT p0, vectorT p1, vectorT q0, vectorT q1, Fixed32 radius)
{
  vectorT pMiddle, qMiddle;
  vectorT pExtents, qExtents;
  vectorT tVector;

  //AABB test

  pMiddle = PrvVectorMultConst(PrvVectorAdd(p0, p1), HALF);
  qMiddle = PrvVectorMultConst(PrvVectorAdd(q0, q1), HALF);

  pExtents.x = MultFixed(AbsFixed(p0.x - p1.x), HALF) + radius;
  pExtents.y = MultFixed(AbsFixed(p0.y - p1.y), HALF) + radius;
  qExtents.x = MultFixed(AbsFixed(q0.x - q1.x), HALF) + radius;
  qExtents.y = MultFixed(AbsFixed(q0.y - q1.y), HALF) + radius;

  tVector = PrvVectorSub(pMiddle, qMiddle);

  return ((AbsFixed(tVector.x) <= (pExtents.x + qExtents.y)) &&
		  (AbsFixed(tVector.y) <= (pExtents.y + qExtents.y)));
}

/*********************************************
 *
 *	Function:	  PrvPointInBox
 *
 *	Description:  Determines if a point is contained
 *	  in a box defined by the upper left and lower right
 *	  corners
 *
 *	Parameters:	  
 *		p0		  IN	  The point to test
 *		ul		  IN	  The upper left corner of the box
 *		lr		  IN	  The lower right corner of the box
 *
 *	Returns:	true if the point is contained in the box,
 *	  false if it isn't
 *
 *	Called by:	PrvPartitionVectorHelper
 *
 *	Notes:	  
 *
 *	Revision History:
 *	  jem			14-Sept-2000		  Created.
 *
 ****************************************************/

static Boolean
PrvPointInBox(vectorT p0, vectorT ul, vectorT lr)
{
  return ((p0.x <= lr.x) && (p0.x >= ul.x) &&
		  (p0.y <= lr.y) && (p0.x >= ul.y));
}

#pragma mark
#pragma mark -- Local --

/***************************************************************
 *  Function:     StillAgainstObj
 *
 *
 *  Summary:      Tells us if we are still resting against an object
 *	  the last round of the model.
 *    
 *
 *  Parameters:
 *	  lastHitP		IN/OUT	  A structure with all the information about
 *		the last object hit.
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    PrvModelCollideBall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelStillAgainstObj (closestInfoT * lastHitP)
{
  Fixed32         dist;
  if (lastHitP->objNum == -1)
  {
	return;
  }

  switch (lastHitP->type)
	{
	case Wall:
	  dist = PrvModelBallIntersectsWall (&(modelInfo.ball),
					   &(modelInfo.objects[lastHitP->objNum].data.wall));
	  break;
	case Circle:
	  dist = PrvModelBallIntersectsCircle (&(modelInfo.ball),
					 &(modelInfo.objects[lastHitP->objNum].data.circle));
	  break;
	case Flipper:
	  dist = PrvModelBallIntersectsFlipper (&(modelInfo.ball),
				   &(modelInfo.flippers[lastHitP->objNum]));
	  break;
	default:
	  dist = NEG_ONE;
	  break;
	}

  if (dist < ZERO)
  {
	lastHitP->objNum = -1;
  }
}

/***************************************************************
 *  Function:     PrvModelCollideBall
 *
 *
 *  Summary:      Runs the ball through one iteration of collisions
 *	  with the model.  We add in gravity, friction and then run
 *	  a loop until the ball's velocity for this round is gone.
 *    
 *
 *  Parameters:
 *	  ballP		  IN/OUT	  A pointer to the ball information
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    ModelCollide
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelCollideBall (ballT * ballP)
{
  closestInfoT		closest, lastHit;
  Fixed32         distFract = ONE;

  //checking and model adjustments
  PrvModelStillAgainstObj (&(modelInfo.lastHit));
  PrvModelAddGravity (ballP);
  PrvModelAddFriction (ballP);
  if (PrvModelCorrectVelocity (ballP))
	return;

  closest.objNum = -1;
  closest.type = Wall;

  ballP->C1 = PrvVectorAdd (ballP->C0, ballP->V);

  while (distFract > ZERO)
	{
	  PrvModelFindClosestObj(&closest, &lastHit, distFract);
	  
	  if (closest.objNum == -1)
		{
		  // Nothing found, so move forward all the way to the end of the
		  // movement
		  PrvModelMoveBall (ballP, distFract);
		  lastHit = closest;
		  break;
		}
	  else
		{
		  lastHit = closest;
		  PrvModelBounceBallOffClosest(&closest, &distFract);
		}
	}
  modelInfo.lastHit = lastHit;
}

/***************************************************************
 *  Function:     PrvModelAddGravity
 *
 *
 *  Summary:      Adds a gravity vector to the ball's motion vector.
 *
 *  Parameters:
 *		  ballP		IN/OUT		A pointer to the ball information
 *
 *    
 *  Returns:
 *    Nothing
 *  
 *  Called By: 
 *    PrvModelCollideBall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelAddGravity (ballT * ballP)
{
  vectorT         grav;

  grav.x = 0;
  grav.y = kGravConst;

  ballP->V = PrvVectorAdd (ballP->V, grav);
}

/***************************************************************
 *  Function:     PrvModelAddFriction
 *
 *
 *  Summary:      Scales the ball's motion by a friction constant.
 *
 *  Parameters:
 *		  ballP		IN		A pointer to the ball information
 *
 *    
 *  Returns:
 *    Nothing
 *  
 *  Called By: 
 *    PrvModelCollideBall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelAddFriction (ballT * ballP)
{
  ballP->V = PrvVectorMultConst (ballP->V, kFrictionCoeff);
}

/***************************************************************
 *  Function:     PrvModelCorrectVelocity
 *
 *
 *  Summary:      Scales the ball's velocity to an acceptable range.
 *	  If the ball is too slow, we tell the system to stop colliding the ball,
 *	  and if it is too fast, we slow it to the max speed possible
 *    
 *
 *  Parameters:
 *	  ballP		  IN/OUT	  A pointer to the ball information
 *    
 *  Returns:
 *    true if the ball is "stopped", false if the ball is still moving
 *  
 *  Called By: 
 *    PrvModelCollideBall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static          Boolean
PrvModelCorrectVelocity (ballT * ballP)
{

  if ((Fixed2 (ballP->V.x) + Fixed2 (ballP->V.y)) < (Fixed2 (kMinVelocity)))
	{
	  //if it's too slow stop
	  return true;
	}
  if ((Fixed2 (ballP->V.x) + Fixed2 (ballP->V.y)) > (Fixed2 (kMaxVelocity)))
	{
	  vectorT         n = PrvVectorNormalize (ballP->V);
	  ballP->V = PrvVectorMultConst (n, kMaxVelocity);
	}
  return false;
}

/***************************************************************
 *  Function:     PrvModelMoveBall
 *
 *
 *  Summary:      Moves the ball forward graphically by a percentage
 *	  of it's velocity vector.  We also do a bounds check for the ball and draw 
 *	  it on the screen
 *    
 *
 *  Parameters:
 *	  ballP		  IN/OUT	A pointer to the ball information
 *	  distFract	  IN	How far the ball should move as a fraction
 *		of its total velocity vector
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    PrvModelCollideBall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelMoveBall (ballT * ballP, Fixed32 distFract)
{
  UInt8           i;
  distFract = DivFixed (distFract, IntToFixed (kBallSteps));

  for (i = 0; i < kBallSteps; i++)
	{
	  //calc the ball's position along the line and draw it.
	  ballP->C0 = PrvVectorAdd (ballP->C0, PrvVectorMultConst (ballP->V, distFract));
	  modelInfo.drawBall (FixedToInt (ballP->C0.x -
						  ballP->radius), FixedToInt (ballP->C0.y - ballP->radius));
	}

  //if the ball is out of bounds, fix it.
  if (ballP->C0.x < kMinX)
	ballP->C0.x = kMinX;
  if (ballP->C0.x > kMaxX)
	ballP->C0.x = kMaxX;
  if (ballP->C0.y < kMinY)
	ballP->C0.y = kMinY;
  if (ballP->C0.y > kMaxY)
	ballP->C0.y = kMaxY;

  if ((ballP->C0.x <= kMinX) || (ballP->C0.x >= kMaxX))
	{
	  MultFixed (ballP->V.x, NEG_ONE);
	}

  if ((ballP->C0.y <= kMinY) || (ballP->C0.y >= kMaxY))
	{
	  MultFixed (ballP->V.y, NEG_ONE);
	}

  ballP->C1 = PrvVectorAdd (ballP->C0, ballP->V);
  modelInfo.checkFlippers ();
}

/***************************************************************
 *  Function:     PrvModelEditWallHelper
 *
 *
 *  Summary:      Helper function for editing a wall.  Enters
 *		data into specific places.
 *    
 *
 *  Parameters:
 *	  wallP		  IN/OUT	  A pointer to the wall information
 *	  c1, c2	  IN		  The endpoints of the wall
 *	  bV		  IN		  The wall's bounce vector
 *	  rollCoeff	  IN		  The wall's roll coeffecient - how much balls move on it
 *	  absorbPct	  IN		  How much (%) of ball energy the ball absorbs
 *	  points	  IN		  The number of points awarded for a hit
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    PrvModelEditWall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelEditWallHelper (wallT * wallP, vectorT c1, vectorT c2, vectorT bV,
						Fixed32 rollCoeff,
						Fixed32 absorbPct, UInt32 points)
{
  vectorT         n, v;

  if (c1.x < c2.x)
	{
	  wallP->p0 = c1;
	  wallP->p1 = c2;
	}
  else
	{
	  wallP->p0 = c2;
	  wallP->p1 = c1;
	}

  wallP->bounce = bV;
  wallP->V = PrvVectorSub (wallP->p1, wallP->p0);

  v = PrvVectorNormalize (wallP->V);
  n = PrvVectorRotate90 (v);
  wallP->n = n;
  wallP->rollCoeff = rollCoeff;
  wallP->absorbPct = absorbPct;
  wallP->trans = PrvModelCreateBounceTransform (v);
  wallP->points = points;
}

#pragma mark --

/***********************************************
 *
 *	Function:	PrvModelFindClosestObj
 *
 *	Description:	Finds the closest object within 
 *	  the ball's current range of motion, or tells us
 *	  that nothing is close enough
 *
 *	Parameters:	
 *	  closestP	  OUT	  The container for the information about 
 *									the closest object
 *	  lastHitP	  IN	  The container with information about the
 *							last object hit
 *	  longestDist IN	  The ball's fractional range of motion for
 *							the turn
 *
 *	Returns:	nothing
 *
 *	Called by:	  PrvModelCollideBall
 *
 *	Notes:
 *
 *	Revision history: 
 *	  09/13/2000		  jem		Created.
 *
 *******************************************************/

static void
PrvModelFindClosestObj(closestInfoT * closestP, closestInfoT * lastHitP, Fixed32 longestDist)
{
  partitionT ballSectors;
  Fixed32 tempClosest;
  UInt16 i;
  
  closestP->objNum = -1;
  closestP->objDist = longestDist;
  ballSectors = PrvPartitionBall(&(modelInfo.ball));

  //do walls and circles
  for (i = 0; i < modelInfo.numObjects; i++)
  {
	if ((lastHitP->objNum == i) && ((lastHitP->type == Circle) || (lastHitP->type == Wall)))
	{
	  //skip it if it was the last thing we hit
	}
	else
	{
	  if (modelInfo.objects[i].sectors & ballSectors)
	  {
		switch (modelInfo.objects[i].type)
		{
		case Wall:
		  tempClosest = PrvModelBallIntersectsWall(&(modelInfo.ball), &(modelInfo.objects[i].data.wall));
		  break;
		case Circle:
		  tempClosest = PrvModelBallIntersectsCircle(&(modelInfo.ball), &(modelInfo.objects[i].data.circle));
		  break;
		default:
		  tempClosest = NEG_ONE;
		  break;
		}
	  }
	  else
	  {
		tempClosest = NEG_ONE;
	  }

	  if ((tempClosest >= ZERO) && (tempClosest <= closestP->objDist))
	  {
		//if it is close, store it.
		closestP->objNum = i;
		closestP->objDist = tempClosest;
		closestP->type = modelInfo.objects[i].type;
	  }
	}
  }

  //do flippers
  for (i = 0; i < modelInfo.numFlippers; i++)
  {
	if ((lastHitP->objNum == i) && (lastHitP->type == Flipper))
	{
	  //skip it if it was the last thing we hit
	}
	else
	{
	  tempClosest = PrvModelBallIntersectsFlipper(&(modelInfo.ball), &(modelInfo.flippers[i]));
	  if ((tempClosest >= ZERO) && (tempClosest <= closestP->objDist))
	  {
		//if it is close, store it.
		closestP->objDist = tempClosest;
		closestP->objNum = i;
		closestP->type = Flipper;
	  }
	}
  }
}

/****************************************************
 *
 *	Function:	PrvModelBounceBallOffClosest
 *
 *	Description:  Performs actions associated with
 *	  the ball bouncing of an active or inactive object
 *
 *	Parameters:
 *	  closestP		IN		A structure with the closest 
 *							object information
 *	  distFractP	IN		A pointer to the distance
 *								remaining in the turn.
 *
 *	Returns:	  nothing
 *
 *	Called by:	  PrvModelCollideBall
 *
 *	Notes:
 *
 *	Revision history:
 *	  09/13/2000	  jem		Created.
 *
 ********************************************************/

static void
PrvModelBounceBallOffClosest(closestInfoT * closestP, Fixed32 * distFractP)
{
  UInt16 closestObj;

  closestObj = closestP->objNum;
  switch (closestP->type)
  {
  case Wall:
	modelInfo.objects[closestObj].hit = true;
	if (modelInfo.objects[closestObj].active)
	{
	  if (modelInfo.objects[closestObj].action)
	  {
		modelInfo.objects[closestObj].action (modelInfo.objects[closestObj].num);
	  }
	  //move it if it's active, do sound, and bounce it
	  PrvModelMoveBall(&(modelInfo.ball), closestP->objDist);
	  SndPlaySystemSound(sndClick);	  //move this to the callback?
	  PrvModelBounceBallOffWall(&(modelInfo.ball), &(modelInfo.objects[closestObj].data.wall));
	}
	else
	{
	  modelInfo.ball.C0 = PrvVectorAdd(modelInfo.ball.C0, PrvVectorMultConst(modelInfo.ball.V, closestP->objDist));
	}
	break;
  case Circle:
	modelInfo.objects[closestObj].hit = true;
	if (modelInfo.objects[closestObj].active)
	{
	  if (modelInfo.objects[closestObj].action)
	  {
		modelInfo.objects[closestObj].action (modelInfo.objects[closestObj].num);
	  }
	  //move it if it's active, do sound, and bounce it
	  PrvModelMoveBall(&(modelInfo.ball), closestP->objDist);
	  SndPlaySystemSound(sndClick);	  //move this to the callback?
	  PrvModelBounceBallOffCircle(&(modelInfo.ball), &(modelInfo.objects[closestObj].data.circle));
	}
	else
	{
	  modelInfo.ball.C0 = PrvVectorAdd(modelInfo.ball.C0, PrvVectorMultConst(modelInfo.ball.V, closestP->objDist));
	}
	break;
  case Flipper:
	if (modelInfo.flippers[closestObj].action)
	{
	  modelInfo.flippers[closestObj].action (modelInfo.flippers[closestObj].num);
	}
	//move, play sound and bounce
	PrvModelMoveBall(&(modelInfo.ball), closestP->objDist);
	SndPlaySystemSound(sndClick);
	PrvModelBounceBallOffFlipper(&(modelInfo.ball), &(modelInfo.flippers[closestObj]));
	break;
  default:
	break;
  }

  //tidy up and update information about destination.
  PrvModelCorrectVelocity(&(modelInfo.ball));
  modelInfo.ball.C1 = PrvVectorAdd (modelInfo.ball.C0, modelInfo.ball.V);
  (*distFractP) -= closestP->objDist;
}

#pragma mark --

/***************************************************************
 *  Function:     PrvModelBallIntersectsWall
 *
 *  Summary:      Determines whether the ball intersects this wall
 *	  by calculating when in scaled time the ball will cross it.
 *    
 *
 *  Parameters:
 *	  ballP		IN		A pointer to the ball information
 *	  wallP		IN		A pointer to the wall information
 *
 *    
 *  Returns:
 *    The distance in scaled time to the wall or NEG_ONE if they 
 *	  won't intersect.
 *  
 *  Called By: 
 *    PrvModelFindClosestObj
 *
 *  Notes:
 *    http://www.gamasutra.com
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

Fixed32
PrvModelBallIntersectsWall (ballT * ballP, wallT * wallP)
{
  vectorT         n;
  Fixed32         d0, d1, ui;

  n = wallP->n;
  d0 = PrvVectorDot (PrvVectorSub (ballP->C0, wallP->p0), n);
  if (d0 < 0)
	{
	  d0 = MultFixed (d0, NEG_ONE);
	  n = PrvVectorMultConst (n, NEG_ONE);
	}
  d1 = PrvVectorDot (PrvVectorSub (ballP->C1, wallP->p0), n);

  if (d0 == d1)
	{
	  return NEG_ONE;
	}

  if (d0 <= ballP->radius)
	{
	  if (d0 > d1)
		{
		  // If the ball is approaching, it should intersect @ ui = 0
		  if (PrvModelBallInWallBounds (ballP->C0, wallP, ballP->radius))
			{
			  return ZERO;
			}
		}
	  return NEG_ONE;
	}

  ui = DivFixed ((d0 - ballP->radius), (d0 - d1));

  if ((ui >= 0) && (ui <= ONE))
	{
	  vectorT         Ci = PrvVectorAdd (PrvVectorMultConst (ballP->C0,
															 ONE - ui),
										 PrvVectorMultConst (ballP->C1, ui));
	  if (PrvModelBallInWallBounds (Ci, wallP, ballP->radius))
		{
		  return ui;
		}
	  else
		{
		  return NEG_ONE;
		}
	}
  else
	{
	  return NEG_ONE;
	}
}

/***************************************************************
 *  Function:     PrvModelBallInWallBounds
 *
 *
 *  Summary:      Checks to see if the ball is within the boundaries
 *				  of the wall.
 *    
 *
 *  Parameters:	
 *		ballPos		IN		The ball's current position
 *		wallP		IN		A pointer to the wall information
 *		ballRadius	IN		The radius of the ball
 *    
 *  Returns:
 *    true if the ball is within the ends of the wall (it will hit), 
 *	  and false otherwise
 *  
 *  Called By: 
 *    PrvModelBallIntersectsWall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static          Boolean
PrvModelBallInWallBounds (vectorT ballPos, wallT * wallP, Fixed32 ballRadius)
{
  Fixed32         d02, d12, total2;
  d02 = FixedDist2 (ballPos, wallP->p0);
  d12 = FixedDist2 (ballPos, wallP->p1);
  // make sure the ball is within the wall boundaries
  total2 = Fixed2 (wallP->V.x) + Fixed2 (wallP->V.y) + Fixed2 (ballRadius);
  if ((d02 <= total2) && (d12 <= total2))
	{
	  return true;
	}
  else
	{
	  return false;
	}
}

/***************************************************************
 *  Function:     PrvModelBallIntersectsFlipper
 *
 *
 *  Summary:      Determines whether the ball intersects this flipper
 *	  by calculating when in scaled time the ball will cross it.
 *    
 *
 *  Parameters:
 *	  ballP		IN		A pointer to the ball information
 *	  wallP		IN		A pointer to the flipper information
 *
 *    
 *  Returns:
 *    The distance in scaled time to the wall or NEG_ONE if they 
 *	  won't intersect.
 *  
 *  Called By: 
 *    PrvModelFindClosestObj
 *
 *  Notes:
 *    http://www.gamasutra.com
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Fixed32
PrvModelBallIntersectsFlipper (ballT * ballP, flipperT * flipperP)
{
  if (flipperP->moved)
	{
	  //if we are in motion, interpolate
	  Fixed32         u0, u1;
	  u0 = PrvModelBallIntersectsWall (ballP, &(flipperP->pos[flipperP->curPos]));
	  u1 = PrvModelBallIntersectsWall (ballP, &(flipperP->pos[flipperP->lastPos]));

	  if (u0 < 0)
		{
		  return u1;
		}
	  if (u1 < 0)
		{
		  return u0;
		}
	  return ((u0 < u1) ? (u0) : (u1));
	}
  else
	{
	  //if it is static, treat it like a wall
	  return PrvModelBallIntersectsWall (ballP, &(flipperP->pos[flipperP->curPos]));
	}
}

/***************************************************************
 *  Function:     PrvModelBallIntersectsCircle
 *
 *
 *  Summary:      Determines whether the ball intersects this circle
 *	  by calculating when in scaled time the ball will cross it.
 *    
 *
 *  Parameters:
 *	  ballP		IN		A pointer to the ball information
 *	  wallP		IN		A pointer to the circle information
 *
 *    
 *  Returns:
 *    The distance in scaled time to the wall or NEG_ONE if they 
 *	  won't intersect.
 *  
 *  Called By: 
 *    PrvModelFindClosestObj
 *
 *  Notes:
 *    http://www.gamasutra.com
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Fixed32
PrvModelBallIntersectsCircle (ballT * ballP, circleT * circleP)
{
  Fixed32         u0, u1, rab, a, b, c;
  vectorT         Vab, Va, Vb, ab;

  Va = ballP->V;
  Vb.x = Vb.y = 0;
  ab = PrvVectorSub (circleP->p0, ballP->C0);
  Vab = PrvVectorSub (Vb, Va);
  rab = ballP->radius + circleP->radius;

  a = PrvVectorDot (Vab, Vab);
  b = MultFixed (IntToFixed (2), PrvVectorDot (Vab, ab));
  c = PrvVectorDot (ab, ab) - Fixed2 (rab);

  if (PrvVectorDot (ab, ab) <= Fixed2 (rab))
	{
	  return NEG_ONE;
	}
  else
	{
	  if (PrvModelSolveQuad (a, b, c, &u0, &u1))
		{
		  if (u0 < u1)
			{
			  return u0;
			}
		  else
			{
			  return u1;
			}
		}
	  else
		{
		  return NEG_ONE;
		}
	}
}

/***************************************************************
 *  Function:     PrvModelBounceBallOffWall
 *
 *
 *  Summary:      Bounces the ball of a wall by applying the 
 *	  bounce transformation, adding the wall's bounce vector, 
 *	  absorbing the ball's incoming energy
 *    
 *
 *  Parameters:
 *	  ballP		  IN/OUT	  A pointer to the ball's information
 *	  wallP		  IN		  A pointer to the wall's information
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    PrvModelBounceBallOffClosest
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelBounceBallOffWall (ballT * ballP, wallT * wallP)
{
  Fixed32         dot;

  ballP->V = PrvVectorMultMatrix (ballP->V, wallP->trans);
  dot = PrvVectorDot (ballP->V, wallP->n);
  if (dot < 0)
	{
	  ballP->V = PrvVectorAdd (ballP->V, wallP->bounce);
	}
  else
	{
	  ballP->V = PrvVectorAdd (ballP->V, PrvVectorMultConst
							   (wallP->bounce, NEG_ONE));
	}
  ballP->V = PrvVectorMultConst (ballP->V, wallP->absorbPct);
  UpdateScore (wallP->points);
}

/***************************************************************
 *  Function:     PrvModelBounceBallOffFlipper
 *
 *
 *  Summary:      Bounces the ball off the flipper by determining
 *	  whether it is in motion or not.  If it is, then we interpolate
 *	  and give the flipper an extra velocity to add.  If it is static,
 *	  it acts just like another wall.
 *    
 *
 *  Parameters:
 *	  ballP		  IN/OUT	  A pointer to the ball information
 *	  flipperP	  IN		  A pointer to the flipper information
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    PrvModelBounceBallOffClosest
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelBounceBallOffFlipper (ballT * ballP, flipperT * flipperP)
{
  if (flipperP->moved)
	{
	  UInt8           bounceWall;
	  Fixed32         dL, dC;

	  dL = PrvModelBallIntersectsWall (ballP, &(flipperP->pos[flipperP->lastPos]));
	  dC = PrvModelBallIntersectsWall (ballP, &(flipperP->pos[flipperP->curPos]));

	  if (dL < 0)
		{
		  bounceWall = flipperP->curPos;
		}
	  else
		{
		  if (dC < 0)
			{
			  bounceWall = flipperP->lastPos;
			}
		  else
			{
			  bounceWall = ((dC < dL) ? (flipperP->curPos) : (flipperP->lastPos));
			}
		}
	  ballP->V = PrvVectorMultMatrix (ballP->V, flipperP->pos[bounceWall].trans);
	  ballP->V = PrvVectorAdd (ballP->V, PrvCreateFlipperVelocity
							   (flipperP, ballP));
	}
  else
	{
	  //static flipper
	  ballP->V = PrvVectorMultMatrix (ballP->V,
									  flipperP->pos[flipperP->curPos].trans);
	  ballP->V = PrvVectorMultConst (ballP->V,
									 flipperP->pos[flipperP->curPos].absorbPct);
	  ballP->V = PrvVectorAdd (ballP->V, PrvCreateRollVector
							   (flipperP->pos[flipperP->curPos].p0,
								flipperP->pos[flipperP->curPos].p1,
								flipperP->pos[flipperP->curPos].rollCoeff));
	}
}

/***************************************************************
 *  Function:     PrvModelBounceBallOffCircle
 *
 *
 *  Summary:      Bounces the ball off a circle by finding the outward
 *		vector, normalizing it, and using a scaled version to "kick"
 *		the ball back away.
 *    
 *  Parameters:
 *	  ballP		  IN/OUT	  A pointer to the ball information
 *	  circleP	  IN		  A pointer to the circle information
 *
 *  Returns:
 *	  nothing    
 *  
 *  Called By: 
 *    PrvModelBounceBallOffClosest
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvModelBounceBallOffCircle (ballT * ballP, circleT * circleP)
{
  vectorT         Vp;

  Vp = PrvVectorSub (ballP->C0, circleP->p0);	// get the outgoing vector
  //Vp = PrvVectorNormalize(Vp);					//normalize it
  Vp = PrvVectorMultConst (Vp, circleP->bounce);	// bounce it & add it
  ballP->V = PrvVectorAdd (Vp, ballP->V);
  UpdateScore (circleP->points);
}

/***************************************************************
 *  Function:     PrvCreateRollVector
 *
 *
 *  Summary:      Creates a vector to simulate a ball rolling on
 *	  a surface.
 *    
 *
 *  Parameters:
 *	  p0, p1	  IN	  The endpoints of the wall to create the
 *						  roll vector for
 *	  rollConstant	IN	  The amount to multiply the roll vector by
 *
 *    
 *  Returns:
 *    A vector that when added to the ball's velocity simulates rolling
 *  
 *  Called By: 
 *    PrvModelBounceBallOffWall
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static          vectorT
PrvCreateRollVector (vectorT p0, vectorT p1, Fixed32 rollConstant)
{
  vectorT         result;
  if (p0.y <= p1.y)
	{
	  result = PrvVectorSub (p1, p0);
	}
  else
	{
	  result = PrvVectorSub (p0, p1);
	}
  return PrvVectorMultConst (PrvVectorNormalize (result), rollConstant);
}

/***************************************************************
 *  Function:     PrvCreateFlipperVelocity
 *
 *  Summary:      Creates a vector that when added to the ball's
 *	  velocity will simulate a flipper hit.  We use the flipper
 *	  motion to give some velocity differentiation and then
 *	  use the distance from the ball to the pivot point to scale again.
 *
 *  Parameters:
 *	  flipperP		IN		A pointer to the flipper information
 *	  ballP			IN/OUT	A pointer to the ball information
 *    
 *  Returns:
 *    a vector that simulates a flipper hit
 *  
 *  Called By: 
 *    PrvModelBounceBallOffFlipper
 *
 *  Notes:
 *    This could be more accurate
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static          vectorT
PrvCreateFlipperVelocity (flipperT * flipperP, ballT * ballP)
{
  Fixed32 dist, scale;
  
  dist = DistanceFixed(flipperP->pivot, ballP->C0);

  scale = kBallMaxVelocity - MultFixed(DoubleToFixed(kFlipperVelocityStep), IntToFixed(flipperP->lastPos));
  scale = MultFixed(scale, DivFixed(dist, kMaxFlipperDist));

  if (flipperP->lastPos < flipperP->curPos)
  {
	scale = MultFixed(scale, NEG_ONE);
  }
  
  return PrvVectorMultConst (flipperP->pos[flipperP->curPos].n, scale);
}

#pragma mark
#pragma mark -- Vector functions --

/***************************************************************
 *  Function:     PrvVectorNormalize
 *
 *
 *  Summary:      Normalizes a vector
 *    
 *
 *  Parameters:
 *	  V			IN		A vector to normalize
 *    
 *  Returns:
 *    A vector in the same direction as V, but with length 1
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorNormalize (vectorT V)
{
  Fixed32         mag = Sqrt (Fixed2 (V.x) + Fixed2 (V.y));
  V.x = DivFixed (V.x, mag);
  V.y = DivFixed (V.y, mag);
  return V;
}

/***************************************************************
 *  Function:     PrvVectorRotate90
 *
 *
 *  Summary:      Rotates a vector 90 degrees
 *    
 *
 *  Parameters:
 *		V		  IN	  A vector to rotate
 *    
 *  Returns:
 *    V, rotated by 90 degrees
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorRotate90 (vectorT V)
{
  vectorT         n;
  n.x = MultFixed (NEG_ONE, V.y);
  n.y = V.x;
  return n;
}

/***************************************************************
 *  Function:     PrvVectorAdd
 *
 *
 *  Summary:      Adds two vectors
 *    
 *
 *  Parameters:	  v1, v2	  IN	  Two vectors
 *
 *    
 *  Returns:	  The vector sum of v1 and v2
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorAdd (vectorT v1, vectorT v2)
{
  vectorT         result;
  result.x = v1.x + v2.x;
  result.y = v1.y + v2.y;
  return result;
}

/***************************************************************
 *  Function:     PrvVectorSub
 *
 *
 *  Summary:      Subtracts two vectors v1-v2
 *    
 *
 *  Parameters:	  v1, v2	  IN	  Two vectors
 *
 *    
 *  Returns:	  v1 - v2 in vector math
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorSub (vectorT v1, vectorT v2)
{
  vectorT         result;
  result.x = v1.x - v2.x;
  result.y = v1.y - v2.y;
  return result;
}

/***************************************************************
 *  Function:     PrvVectorMultConst
 *
 *
 *  Summary:      Multiplies a vector by a constant
 *    
 *
 *  Parameters:
 *	  v1		IN		A vector
 *	  constant	IN		A constant to multiply by
 *
 *    
 *  Returns:
 *    v1 * constant
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorMultConst (vectorT v1, Fixed32 constant)
{
  v1.x = MultFixed (v1.x, constant);
  v1.y = MultFixed (v1.y, constant);
  return v1;
}

/***************************************************************
 *  Function:     PrvVectorMultMatrix
 *
 *
 *  Summary:      Multiplies a vector by a matrix - useful for bouncing
 *    
 *
 *  Parameters:
 *	  v1	  IN	  A vector	[vx]
 *								[vy]
 *	  mat	  IN	  A matrix  [a  b]
 *								[c  d]
 *    
 *  Returns:
 *    [a  b][vx]	[a * vx + b * vy]
 *	  [c  d][vy] =  [c * vx + d * vy]
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvVectorMultMatrix (vectorT v1, matrixT mat)
{
  vectorT         res;
  res.x = MultFixed (mat.m[0][0], v1.x) + MultFixed (mat.m[0][1], v1.y);
  res.y = MultFixed (mat.m[1][0], v1.x) + MultFixed (mat.m[1][1], v1.y);
  return res;
}

/***************************************************************
 *  Function:     PrvVectorDot
 *
 *
 *  Summary:      Calculates the dot product of two vectors
 *    
 *
 *  Parameters:	v1, v2		IN		Two vectors
 *
 *    
 *  Returns:	v1 dot v2 = a scalar
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   Fixed32
PrvVectorDot (vectorT v1, vectorT v2)
{
  return (MultFixed (v1.x, v2.x) + MultFixed (v1.y, v2.y));
}

/***************************************************************
 *  Function:     PrvIntToVector
 *
 *
 *  Summary:      Wrapper to turn two ints into a vector
 *    
 *
 *  Parameters:	x, y	  IN	  A coordinate pair (ints) to make a vector
 *
 *    
 *  Returns:	(x, y) as a vector
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvIntToVector (UInt8 x, UInt8 y)
{
  vectorT         v;
  v.x = IntToFixed (x);
  v.y = IntToFixed (y);
  return v;
}

/***************************************************************
 *  Function:     PrvDoubleToVector
 *
 *
 *  Summary:      Wrapper to turn two doubles into a vector
 *    
 *
 *  Parameters:	x, y	  IN	  A coordinate pair (doubles) to make a vector
 *
 *    
 *  Returns:	(x, y) as a vector
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvDoubleToVector (double x, double y)
{
  vectorT         v;
  v.x = DoubleToFixed (x);
  v.y = DoubleToFixed (y);
  return v;
}

/***************************************************************
 *  Function:     PrvFixedToVector
 *
 *
 *  Summary:      Wrapper to turn two fixed point numbers into a vector
 *    
 *
 *  Parameters:	x, y	  IN	  A coordinate pair (fixed point numbers) to make a vector
 *
 *    
 *  Returns:	(x, y) as a vector
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

INLINE static   vectorT
PrvFixedToVector (Fixed32 x, Fixed32 y)
{
  vectorT         v;
  v.x = x;
  v.y = y;
  return v;
}

/***************************************************************
 *  Function:     PrvModelSolveQuad
 *
 *
 *  Summary:      Solves the equation: 0= ax^2 + bx + c if possible
 *    
 *
 *  Parameters:
 *	  a, b, c		IN		Coeffecients in the polynomial function (x^2, x, 1)
 *	  r0, r1		OUT		Pointers to places to store the roots if the
 *							function is solvable
 *    
 *  Returns:
 *    true if the roots are real, false if they are imaginary (discriminant is < 0)
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

Boolean
PrvModelSolveQuad (Fixed32 a, Fixed32 b, Fixed32 c, Fixed32 * r0,
				   Fixed32 * r1)
{
  double          na, nb, nc, disc;
  na = FixedToDouble (a);
  nb = FixedToDouble (b);
  nc = FixedToDouble (c);
  disc = Power2 (nb) - (4 * na * nc);

  if (disc < 0)
	return false;

  (*r0) = DoubleToFixed (((-1 * nb) + sqrt (disc)) / (2 * na));
  (*r1) = DoubleToFixed (((-1 * nb) - sqrt (disc)) / (2 * na));
  return true;
}

/***************************************************************
 *  Function:     PrvModelCreateBounceTransform
 *
 *
 *  Summary:      Creates a matrix transformation that models
 *	  bouncing an object off a vector (a line) in terms of entering
 *	  and exiting vectors.  We find the basis vectors of the vector
 *	  so that the bounce happens correctly and then devlop the matrix
 *	  from those basis vectors 
 *    
 *
 *  Parameters:
 *	  v		  IN	  The vector to create a bounce transformation for
 *    
 *  Returns:
 *    a 2x2 matrix with a bouncing transformation
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static matrixT
PrvModelCreateBounceTransform (vectorT v)
{
  double          m[2][2];
  matrixT         final;
  double          thetaI, thetaJ;

  if (v.x == 0)
	{
	  //special case of vertical line
	  m[0][0] = -1;
	  m[1][1] = 1;
	  m[0][1] = m[1][0] = 0;
	}
  else
	{
	  if (v.y == 0)
		{
		  //special case of horizontal line
		  m[0][0] = 1;
		  m[1][1] = -1;
		  m[0][1] = m[1][0] = 0;
		}
	  else
		{
		  //find the rotation of the basis vectors
		  thetaI = acos (FixedToDouble (v.x));
		  thetaJ = acos (FixedToDouble (v.y));

		  if (v.y > 0)
			{
			  thetaI = PI - (2 * thetaI);
			  thetaJ = PI + (2 * thetaJ);
			}
		  if (v.y < 0)
			{
			  thetaI = PI + (2 * thetaI);
			  thetaJ = (2 * thetaJ) - PI;
			}
		  
		  //make it into a rotation transformation
		  m[0][0] = cos (thetaI);
		  m[1][0] = sin (thetaI);
		  m[0][1] = -1 * sin (thetaJ);
		  m[1][1] = -1 * cos (thetaJ);
		}
	}

  final.m[0][0] = DoubleToFixed (m[0][0]);
  final.m[0][1] = DoubleToFixed (m[0][1]);
  final.m[1][0] = DoubleToFixed (m[1][0]);
  final.m[1][1] = DoubleToFixed (m[1][1]);

  return final;
}