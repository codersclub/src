/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    ModelActions.c
 * 
 * Description:
 *    Callback functions for the physics model
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  Initial Version
 *
 ****************************************************************/

#include "Pinball.h"
#include "Model.h"
#include "PinballRsc.h"

/******************************
 *
 *	Function prototypes
 *
 *********************************/

static void PrvBumperAction (UInt16 num);
static void PrvTriBumperAction (UInt16 num);
static void PrvTrafficLightAction (UInt16 num);
static void PrvStarAction (UInt16 num);
static void PrvTrackAction (UInt16 num);

static void Flip(void);
static void AnimateRaceTrack(void);

/***************************************************************
 *  Function:     PrvGetObjectPtr
 *
 *
 *  Summary:      Gets a pointer to an object given a resource ID
 *    
 *
 *  Parameters:	  objID	  IN	The resource ID of the object to get
 *	  the pointer for.
 *    
 *  Returns:	  A pointer to the object with that resourceID
 *    
 *  
 *  Called By:	  Everything
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void *
PrvGetObjectPtr(UInt16 objID)
{
  FormPtr formP = FrmGetActiveForm();
  return FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, objID));
}

/***************************************************************
 *  Function:     GameInit
 *
 *
 *  Summary:      Initializes the game structures
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameHandleEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
GameInit(gameInfoT * gameInfoP)
{
	UInt8 i;

	gameInfoP->trackFrame = 0;
	gameInfoP->tilt = false;
	gameInfoP->tiltTime = 0;

	gameInfoP->next.flipperInfo[kLeftFlipper].changed = false;
	gameInfoP->next.flipperInfo[kLeftFlipper].numFrames = kFlipperNumFrames;
	gameInfoP->next.flipperInfo[kLeftFlipper].frameNumber = 0;
	gameInfoP->next.flipperInfo[kLeftFlipper].left = kLeftFlipperLeft;
	gameInfoP->next.flipperInfo[kLeftFlipper].top = kLeftFlipperTop;
	
	gameInfoP->next.flipperInfo[kRightFlipper].changed = false;
	gameInfoP->next.flipperInfo[kRightFlipper].numFrames = kFlipperNumFrames;
	gameInfoP->next.flipperInfo[kRightFlipper].frameNumber = 0;
	gameInfoP->next.flipperInfo[kRightFlipper].left = kRightFlipperLeft;
	gameInfoP->next.flipperInfo[kRightFlipper].top = kRightFlipperTop;
	gameInfoP->next.numFlippers = kMaxFlippers;

	gameInfoP->next.ballInfo.frameNumber = 0;
	gameInfoP->next.ballInfo.numFrames = kBallNumFrames;	
	gameInfoP->next.ballInfo.changed = false;
	gameInfoP->next.ballInfo.left = kBallX;
	gameInfoP->next.ballInfo.top = kBallY;
	gameInfoP->next.ballInfo.changed = true;

	gameInfoP->next.numBumpers = kMaxBumpers;
	gameInfoP->next.bumperInfo[0].left = 42;
	gameInfoP->next.bumperInfo[0].top = 23;
	gameInfoP->next.bumperInfo[1].left = 50;
	gameInfoP->next.bumperInfo[1].top = 49;
	gameInfoP->next.bumperInfo[2].left = 71;
	gameInfoP->next.bumperInfo[2].top = 30;

	for (i = 0; i< gameInfoP->next.numBumpers; i++)
	{
		gameInfoP->next.bumperInfo[i].frameNumber = 0;
		gameInfoP->next.bumperInfo[i].numFrames = kBumperNumFrames;
		gameInfoP->next.bumperInfo[i].changed = false;
	}

	gameInfoP->next.border.top = kBorderTopY;
	gameInfoP->next.border.left = kBorderTopX;
	gameInfoP->next.border.frameNumber = 0;
	gameInfoP->next.border.numFrames = kBorderNumFrames;
	gameInfoP->next.border.changed = false;

	gameInfoP->next.light[kLeftFlipper].left = kLeftFlipperLightX;
	gameInfoP->next.light[kLeftFlipper].top = kLeftFlipperLightY;
	gameInfoP->next.light[kRightFlipper].left = kRightFlipperLightX;
	gameInfoP->next.light[kRightFlipper].top = kRightFlipperLightY;
	gameInfoP->next.light[kLeftFlipper].numFrames = kLightNumFrames;
	gameInfoP->next.light[kLeftFlipper].frameNumber = 0;
	gameInfoP->next.light[kRightFlipper].numFrames = kLightNumFrames;
	gameInfoP->next.light[kRightFlipper].frameNumber = 0;
	gameInfoP->next.numLights = kMaxLights;

	gameInfoP->next.traffic.left = kTrafficX;
	gameInfoP->next.traffic.top = kTrafficY;
	gameInfoP->next.traffic.numFrames = kTrafficNumFrames;
	gameInfoP->next.traffic.frameNumber = 0;

	gameInfoP->next.star.frameNumber = 0;
	gameInfoP->next.star.changed = false;
	gameInfoP->next.star.numFrames = kStarNumFrames;
	gameInfoP->next.star.left = kStarX;
	gameInfoP->next.star.top = kStarY;

	for(i = 0; i < kMaxTriBumps; i++)
	{
	  gameInfoP->next.triBumpInfo[i].frameNumber = 0;
	  gameInfoP->next.triBumpInfo[i].numFrames = kTriBumpNumFrames;
	  gameInfoP->next.triBumpInfo[i].changed = false;
	}
	gameInfoP->next.numTriBumps = kMaxTriBumps;
	gameInfoP->next.triBumpInfo[kLeftTriBump].left = kLeftTriBumpX;
	gameInfoP->next.triBumpInfo[kLeftTriBump].top = kLeftTriBumpY;
	gameInfoP->next.triBumpInfo[kRightTriBump].left = kRightTriBumpX;
	gameInfoP->next.triBumpInfo[kRightTriBump].top = kRightTriBumpY;

	gameInfoP->ballsLeft = kDefaultBalls;

	gameInfoP->score = 0;
	gameInfoP->scoreField = PrvGetObjectPtr(rscGameScoreFieldID);
	StrPrintF(gameInfoP->scoreBuffer, "%ld", gameInfoP->score);
	FldSetTextPtr(gameInfoP->scoreField, gameInfoP->scoreBuffer);
	FldDrawField(gameInfoP->scoreField);
}

/***************************************************************
 *  Function:     GameStateModelInit
 *
 *
 *  Summary:      Initializes the physics model for the pinball table
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameStart
 *    
 *
 *  Notes:		  This needs a lot of cleanup and explanation
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
GameStateModelInit(gameInfoT * gameInfoP)
{
	UInt8 leftStops[kFlipperNumFrames][2], rightStops[kFlipperNumFrames][2];

	ModelInit(100, kMaxFlippers, DrawBall, CheckFlippers);
	
	ModelEditBall(gameInfoP->next.ballInfo.left, gameInfoP->next.ballInfo.top, kBallRadius, 20, 90);
	
	//4 bounding walls
/*1*/	ModelEnterFullWall(40,	0,	40,	  160,	0,	0,	0,	0.3,  0, NULL, 0);
/*2*/	ModelEnterFullWall(158,	0,	158,  160,	0,	0,	0,	0.3,  0, NULL, 0);
/*3*/	ModelEnterFullWall(0,	22,	160,  22,	0,	0,	0,	1,	  0, NULL, 0);
/*4*/	gameInfoP->next.bottomWall = ModelEnterFullWall(0, 158, 160, 158, 0, 0, 0, 0.1, 0, NULL, 0);
	
	//launch chute
/*5*/	ModelEnterFullWall(146, 50, 146, 160, 0, 0, 0.2, 0, 0, NULL, 0);
/*6*/	ModelEnterBounceWall(146, 134, 160, 134, 0, -15, 0, 1, NULL, 0);
	
	//ball return ramps
/*7*/	ModelEnterBounceWall(116, 148, 145, 135, 0, 0, 8, 1, NULL, 0);
/*8*/	ModelEnterBounceWall(70, 147, 38, 136, 0, 0, 8, 1, NULL, 0);

	//triangle bumpers
	//2500 pts each
/*9*/	gameInfoP->next.triBumpInfo[kLeftTriBump].objNumber = ModelEnterFullWall(59, 116, 70, 124, 5, -15, 0, 1, 2500, PrvTriBumperAction, kLeftTriBump);
/*10*/	ModelEnterBounceWall(70, 124, 61, 122, 0, 0, 0, 0.3, NULL, 0);
/*11*/	ModelEnterBounceWall(61, 122, 59, 116, 0, 0, 0, 0.3, NULL, 0);
/*12*/	ModelEnterCircle(59, 116, 0.25, 4, 2500, PrvTriBumperAction, kLeftTriBump);
/*13*/	ModelEnterCircle(70, 124, 0.25, 4, 2500, PrvTriBumperAction, kLeftTriBump);
/*14*/	ModelEnterCircle(61, 122, 0.25, 0.5, 0, NULL, 0);

/*15*/	gameInfoP->next.triBumpInfo[kRightTriBump].objNumber = ModelEnterFullWall(128, 116, 117, 124, -5, -15, 0, 1, 2500, PrvTriBumperAction, kRightTriBump);
/*16*/	ModelEnterBounceWall(117, 124, 126, 122, 0, 0, 0, 0.3, NULL, 0);
/*17*/	ModelEnterBounceWall(126, 122, 128, 116, 0, 0, 0, 0.3, NULL, 0);
/*18*/	ModelEnterCircle(128, 116, 0.25, 4, 2500, PrvTriBumperAction, kRightTriBump);
/*19*/	ModelEnterCircle(117, 124, 0.25, 4, 2500, PrvTriBumperAction, kRightTriBump);
/*20*/	ModelEnterCircle(126, 122, 0.25, 0.5, 0, NULL, 0);
	
	//entry ramp
/*21*/ 	ModelEnterBounceWall(157, 37, 152, 30, 3, 1, 0, 1, NULL, 0);
/*22*/	ModelEnterBounceWall(154, 30, 146, 27, 0, 0, 0, 1, NULL, 0);
/*23*/	ModelEnterBounceWall(148, 28, 136, 28, 0, 0, 0, 1, NULL, 0);
/*24*/	ModelEnterBounceWall(138, 28, 121, 42, 0, 0, 0, 1, NULL, 0);
/*25*/	ModelEnterCircle(121, 42, 0.5, 0.5, 0, NULL, 0);
/*26*/	ModelEnterCircle(142, 48, 2.5, 1, 0, NULL, 00);

	//straight road
/*27*/	ModelEnterWall(121, 48, 121, 20, NULL, 0);
/*28*/	ModelEnterWall(100, 48, 100, 20, NULL, 0);
/*29*/	ModelEnterCircle(100, 48, 0.5, 1, 0, NULL, 0);
/*30*/	ModelEnterFullWall(100, 32, 121, 32, 0, 0, 0, 1, 75000, PrvTrackAction, kStraight);

	//curved road on the left
/*31*/	ModelEnterWall(39, 70, 48, 67, NULL, 0);
/*32*/	ModelEnterWall(39, 67, 55, 67, NULL, 0);
/*33*/	ModelEnterWall(54, 67, 64, 76, NULL, 0);
/*34*/	ModelEnterCircle(54, 67, 0.25, 1, 0, NULL, 0);

/*35*/	ModelEnterWall(39, 86, 46, 83, NULL, 0);
/*36*/	ModelEnterWall(46, 83, 50, 83, NULL, 0);
/*37*/	ModelEnterWall(50, 83, 53, 86, NULL, 0);
/*38*/	ModelEnterCircle(50, 83, 0.25, 1, 0, NULL, 0);
/*39*/	ModelEnterCircle(46, 83, 0.25, 1, 0, NULL, 0);

/*40*/	ModelEnterFullWall(42, 85, 42, 68, 0, 0, 0, 0.3, 50000, PrvTrackAction, kLeftTurnL);

	//Small road on right
/*41*/	ModelEnterWall(135, 58, 146, 51, NULL, 0);
/*42*/	ModelEnterFullWall(146, 51, 146, 68, 0, 0, 0, 0.3, 50000, PrvTrackAction, kLeftTurnR);
/*43*/	ModelEnterWall(146, 68, 137, 74, NULL, 0);
/*44*/	ModelEnterWall(137, 74, 138, 76, NULL, 0);

	//stopper
/*45*/ 	gameInfoP->next.stopperNum = ModelEnterFullWall(146, 51, 157, 44, 1, -2, 0, 1, 150000, PrvTrackAction, kRightTurn);
		ModelDisableObj(gameInfoP->next.stopperNum);

/*46*/	gameInfoP->next.enterBoard = ModelEnterWall(100, 48, 138, 48, NULL, 0);
		ModelDisableObj(gameInfoP->next.enterBoard);

	//bumpers
/*47*/	gameInfoP->next.bumperInfo[0].objNumber = ModelEnterCircle(49.5, 31.5, kBumperRadius, 1, 5000, PrvBumperAction, 0);
/*48*/	gameInfoP->next.bumperInfo[1].objNumber = ModelEnterCircle(57.5, 56.5, kBumperRadius, 1, 5000, PrvBumperAction, 1);
/*49*/	gameInfoP->next.bumperInfo[2].objNumber = ModelEnterCircle(78.5, 37.5, kBumperRadius, 1, 5000, PrvBumperAction, 2);

	//traffic light bumper
/*50*/	ModelEnterFullWall(kTrafficX, kTrafficY, kTrafficX, kTrafficY + kTrafficHeight, 0, 0, 0, 1, 30000, PrvTrafficLightAction, 0);
/*51*/	ModelEnterWall(kTrafficX, kTrafficY + kTrafficHeight, kTrafficX + kTrafficWidth + 2, kTrafficY + kTrafficHeight, NULL, 0);
/*52*/	ModelEnterCircle(kTrafficX, kTrafficY + kTrafficHeight, 0.5, 1, 0, NULL, 0);
/*53*/	ModelEnterCircle(kTrafficX, kTrafficY, 0.5, 1, 0, NULL, 0);
/*54*/	ModelEnterCircle(kTrafficX + kTrafficWidth, kTrafficY + kTrafficHeight, 0.5, 1, 0, NULL, 0);

	//star
/*55*/	gameInfoP->next.star.objNumber = ModelEnterCircle(45, 52, kStarRadius, 3, 10000, PrvStarAction, 0);

	leftStops[0][0] = gameInfoP->next.flipperInfo[kLeftFlipper].left + 20;
	leftStops[1][0] = gameInfoP->next.flipperInfo[kLeftFlipper].left + 21;
	leftStops[2][0] = gameInfoP->next.flipperInfo[kLeftFlipper].left + 21;
	leftStops[3][0] = gameInfoP->next.flipperInfo[kLeftFlipper].left + 20;
	leftStops[4][0] = gameInfoP->next.flipperInfo[kLeftFlipper].left + 19;
	leftStops[0][1] = gameInfoP->next.flipperInfo[kLeftFlipper].top + 13;
	leftStops[1][1] = gameInfoP->next.flipperInfo[kLeftFlipper].top + 10;
	leftStops[2][1] = gameInfoP->next.flipperInfo[kLeftFlipper].top + 7;
	leftStops[3][1] = gameInfoP->next.flipperInfo[kLeftFlipper].top + 4;
	leftStops[4][1] = gameInfoP->next.flipperInfo[kLeftFlipper].top + 0;

	rightStops[0][0] = gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - 20;
	rightStops[1][0] = gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - 21;
	rightStops[2][0] = gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - 21;
	rightStops[3][0] = gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - 20;
	rightStops[4][0] = gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - 19;
	rightStops[0][1] = gameInfoP->next.flipperInfo[kRightFlipper].top + 13;
 	rightStops[1][1] = gameInfoP->next.flipperInfo[kRightFlipper].top + 10;
	rightStops[2][1] = gameInfoP->next.flipperInfo[kRightFlipper].top + 7;
	rightStops[3][1] = gameInfoP->next.flipperInfo[kRightFlipper].top + 4;
	rightStops[4][1] = gameInfoP->next.flipperInfo[kRightFlipper].top + 0;

	ModelEnterFlipper(kLeftFlipper, gameInfoP->next.flipperInfo[kLeftFlipper].left + kFlipperInsetX,
				gameInfoP->next.flipperInfo[kLeftFlipper].top + kFlipperInsetY, leftStops, 3, 0.4, NULL, 0);

	ModelEnterFlipper(kRightFlipper, gameInfoP->next.flipperInfo[kRightFlipper].left + kFlipperWidth - kFlipperInsetX,
				gameInfoP->next.flipperInfo[kRightFlipper].top + kFlipperInsetY, rightStops, 3, 0.4, NULL, 0);
}

/**************************************
 *
 *	  Function: PrvBumperAction, PrvTrafficLightAction,
 *		PrvStarAction, PrvTriBumperAction, PrvTrackAction
 *
 *	  Description: These functions perform specific actions for objects
 *		when they are "hit", from drawing to doing other score stuff.
 *
 *	  Parameters:	  num		IN		A number defined when the object
 *		  is entered.
 *
 *	  Returns:		nothing
 *
 *	  Notes:	These are all used as function pointers within the model
 *
 *	  Revision History:
 *		  jem		  15-Sept-2000		  Created.
 *
 ****************************************************/

void
PrvBumperAction(UInt16 num)
{
  GameInfo.next.bumperInfo[num].frameNumber = (GameInfo.next.bumperInfo[num].frameNumber + 1) % kBumperNumFrames;
  DrawObject(GetBumperBitmap(GameInfo.next.bumperInfo[num].frameNumber), 
		  GameInfo.next.bumperInfo[num].left, GameInfo.next.bumperInfo[num].top, winPaint);
}

void
PrvTrafficLightAction(UInt16 num)
{
  GameInfo.next.traffic.frameNumber = (GameInfo.next.traffic.frameNumber + 1) % (GameInfo.next.traffic.numFrames);
  DrawObject(GetTrafficBitmap(GameInfo.next.traffic.frameNumber), GameInfo.next.traffic.left,
				  GameInfo.next.traffic.top, winPaint);
}

void
PrvStarAction(UInt16 num)
{
  GameInfo.next.star.frameNumber = (GameInfo.next.star.frameNumber + 1) % (GameInfo.next.star.numFrames);
  DrawObject(GetStarBitmap(GameInfo.next.star.frameNumber), GameInfo.next.star.left,
				  GameInfo.next.star.top, winPaint);	
}

void
PrvTriBumperAction(UInt16 num)
{
  GameInfo.next.triBumpInfo[num].frameNumber = (GameInfo.next.triBumpInfo[num].frameNumber + 1) % (GameInfo.next.triBumpInfo[num].numFrames);
  DrawObject(GetTriBumpBitmap(num, GameInfo.next.triBumpInfo[num].frameNumber),
				  GameInfo.next.triBumpInfo[num].left, GameInfo.next.triBumpInfo[num].top, winPaint);
}

void
PrvTrackAction(UInt16 num)
{
  switch (num)
  {
  case kLeftTurnL:
	//left tunnel
	ModelEditBall(135, 60, kBallRadius, 10, -45);
	break;
  case kLeftTurnR:
	//right tunnel
	ModelEditBall(44, 72, kBallRadius, 10, 180);
	break;
  case kRightTurn:
	break;
  case kStraight:
	break;
  default:
	break;
  }
  //do the animations
  Flip();
  AnimateRaceTrack();
}

/************************************
 *
 *	Function: Flip
 *
 *	Description: Displays an animation of Flip
 *
 *	Parameters: none
 *
 *	Returns:	nothing
 *
 *	Revision History:
 *		jem		  15-Sept-2000		Created.
 *
 **************************************/
 

static void
Flip(void)
{
  SndPlaySystemSound (sndConfirmation);
  DrawSpecial(Flip1);
  SysTaskDelay(6);
  DrawSpecial(Flip2);
  SysTaskDelay(6);
  DrawSpecial(Flip3);
  SysTaskDelay(6);
  DrawSpecial(Flip4);
  SysTaskDelay(30);
  DrawSpecial(GreenFlag);
}

/***************************************************************
 *  Function:     AnimateRaceTrack
 *
 *
 *  Summary:      Moves the car around the racetrack at the 
 *	  side of the display
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By: GameStateElapse
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
AnimateRaceTrack(void)
{
  RectangleType carBounds, trackBounds;
  Coord carX = 0, carY = 0;
  int frame = GameInfo.trackFrame;

  carBounds.topLeft.x = carBounds.topLeft.y = 0;
  trackBounds.topLeft.x = trackBounds.topLeft.y = 0;
  trackBounds.extent.x = kTrackWidth;
  trackBounds.extent.y = kTrackHeight;

  //decide on the car's offset depending on frame
  switch(frame)
  {
	case 0:
	  carBounds.extent.x = 6;
	  carBounds.extent.y = 10;
	  carX = 25;
	  carY = 29;
	  break;
	case 1:
	  carBounds.extent.x = 11;
	  carBounds.extent.y = 11;
	  carX = 20;
	  carY = 9;
	  break;
	case 2:
	  carBounds.extent.x = 10;
	  carBounds.extent.y = 6;
	  carX = 13;
	  carY = 1;
	  break;
	case 3:
	  carBounds.extent.x = 11;
	  carBounds.extent.y = 11;
	  carX = 3;
	  carY = 8;
	  break;
	case 4:
	  carBounds.extent.x = 6;
	  carBounds.extent.y = 10;
	  carX = 2;
	  carY = 30;
	  break;
	case 5:
	  carBounds.extent.x = 11;
	  carBounds.extent.y = 11;
	  carX = 3;
	  carY = 52;
	  break;
	case 6:
	  carBounds.extent.x = 10;
	  carBounds.extent.y = 6;
	  carX = 13;
	  carY = 64;
	  break;
	case 7:
	  carBounds.extent.x = 11;
	  carBounds.extent.y = 11;
	  carX = 21;
	  carY = 52;
	  break;
	default:
	  break;
  }

  //draw the track
  WinCopyRectangle(GameInfo.windowHandles[GetTrackBitmap], 0, &trackBounds, kTrackX, kTrackY, winPaint);
  WinCopyRectangle(GameInfo.windowHandles[GetCarBitmap(frame)], 0, &carBounds, carX + kTrackX, carY + kTrackY, winOverlay);

  GameInfo.trackFrame  = (GameInfo.trackFrame + 1) % kNumTrackFrames;
}