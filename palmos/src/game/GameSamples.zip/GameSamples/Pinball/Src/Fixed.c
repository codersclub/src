/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Fixed.c
 * 
 * Description:
 *    Implementation of the fixed point library
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  Initial Version
 *
 ****************************************************************/

#include <PalmOS.h>
#include "Fixed.h"

/********************************************************
 *
 *	Notes:	  The fixed point functions below are fairly self-explanatory
 *	  in what they are supposed to do (i.e. AddFixed adds two fixed point numbers, 
 *	  returning their sum as a fixed point number), but the fixed point format should
 *	  be explained.
 *	  The numbers are stored with 8 bits of precision in the fixed
 *	  point - this allows us to reliably store and multiply numbers from approx. -256 to 256.
 *
 *	  The least significant 8 bits of the 32 bit integer are used to store the decimal
 *	  info, so that means that an integer becomes a fixed point with a right shift of 8 bits,
 *	  and a double becomes a fixed point when we multiply by 256.0.
 *
 *	  Math: Adding and subtracting fixed numbers is identical to integers.  When we multiply, 
 *	  we need to shift the result back by 8 bits to get the correct range (this is why you can
 *	  only use 8 bits to store the fixed point in this case).  Finally, division shifts the numerator
 *	  before doing an integer divide so that the precision is retained in the result.
 *
 *
 *******************************************************/

INLINE Fixed32
IntToFixed(Int32 num)
{
  Fixed32 result = num;
  return (result << 8);
}

INLINE Fixed32
DoubleToFixed(double num)
{
  Int32 result = ((double)num * kTotalShift);
  return result;
}

INLINE Int32
FixedToInt(Fixed32 num)
{
  return (num >> 8);
}

INLINE double
FixedToDouble(Fixed32 num)
{
  double result = num;
  result = result / kTotalShift;
  return result;
}

INLINE Fixed32
AddFixed(Fixed32 a, Fixed32 b)
{
  return (a + b);
}

INLINE Fixed32
SubFixed(Fixed32 a, Fixed32 b)
{
  return (a - b);
}

INLINE Fixed32
MultFixed(Fixed32 a, Fixed32 b)
{
  return ((a * b) >> 8);
}

INLINE Fixed32
DivFixed(Fixed32 a, Fixed32 b)
{
  Int32 result;
  result = a << 8;
  result = (Int32) result / (Int32) b;
  return result;
}

INLINE Fixed32
AbsFixed(Fixed32 num)
{
  if (num >= ZERO)
  {
	return num;
  }
  else
  {
	return MultFixed(num, NEG_ONE);
  }
}
