 /***********************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Pinball.c
 * 
 * Description:
 *    Main file for all the application level stuff, including scoring and
 *	  drawing
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  Initial Version
 *
 ****************************************************************/

#include <PalmOS.h>
#include <HsExt.h>
#include "HsCreators.h"
#include "Pinball.h"
#include "PinballRsc.h"
#include "Model.h"

#define numberCol		0
#define nameCol			1
#define scoreCol		2

#define ABS(num1, num2)							((num1 < num2) ? (num2 - num1) : (num1 - num2))

//-----------------------------------------------
//
//	  Globals
//
//-----------------------------------------------

gameInfoT GameInfo;

static highScoreTableType HighScores;
static UInt16 highlightScoreNum = -1;


#pragma mark ----- Function Prototypes -----

static UInt32 StartApplication (void);
static UInt32 StopApplication (void);
static void EventLoop (void);
static Boolean ApplicationHandleEvent (EventType * event);
static UInt32	TimeUntilNextPeriod(void);
static Boolean PinballKeyHandleEvent(EventType * event);

static Boolean GameHandleEvent(EventType * event);
static Boolean HighScoreDisplayHandleEvent(EventType * event);
static Boolean FinalScoreHandleEvent (EventType * event);

static void GameStateDraw(void);
static void DrawFlipper(UInt8 whichFlipper, objectInfoT * flipperP);
void DrawScore(void * tP, Int16 row, Int16 column, RectangleType * bounds);
void DrawSpecial(UInt16 bmpIndex);

static void	GameStateElapse(void);
static void GameStateAdvance(void);
static void GamePlaySounds(void);

static void GameStart(void);
static void GameLostBall(void);
static void GameMaskKeys(void);
static void GameUnmaskKeys(void);

static void ChangeFlipperUp(objectInfoT * flipperP, objectInfoT * lightP, UInt8 whichFlipper);
static void ChangeFlipperDown(objectInfoT * flipperP, UInt8 whichFlipper);

static void DoAboutBox(void);
static void HighScoreDisplayInit(void);
static void InitializeHighScores(void);
static UInt32 LowestHighScore(void);
static void	AddHighScore(Char * playerNameP);
void UpdateScore(UInt32 pointAddition);

static void PrvPinballLoadPrefs(void);
static void PrvPinballSavePrefs(void);

#pragma mark ---- Function definitions -----

/***************************************************************
 *  Function:     PrvGetObjectPtr
 *
 *
 *  Summary:      Gets a pointer to an object given a resource ID
 *    
 *
 *  Parameters:	  objID	  IN	The resource ID of the object to get
 *	  the pointer for.
 *    
 *  Returns:	  A pointer to the object with that resourceID
 *    
 *  
 *  Called By:	  Everything
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void *
PrvGetObjectPtr(UInt16 objID)
{
  FormPtr formP = FrmGetActiveForm();
  return FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, objID));
}

/***************************************************************
 *  Function:     TimeUntilNextPeriod
 *
 *
 *  Summary:      Allows us to change the event polling 
 *	  structure so that we can poll often if the ball is 
 *	  moving, and less often if the game is paused (etc.)
 *	  A period is one set of movements through GameStateDrawChanges,
 *	  GameStateElapse, etc.
 *
 *  Parameters:	  None
 *
 *  Returns:	  The number of ticks until the next period
 *    
 *  Called By: EventLoop
 *    
 *  Notes:
 *    
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static UInt32
TimeUntilNextPeriod (void)
{
	if (GameInfo.status == gamePlaying)
	{
	  Int32 timeRemaining;

	  timeRemaining = GameInfo.nextPeriodTime - TimGetTicks();
	  if (timeRemaining < 0)
	  {
		timeRemaining = 0;
	  }
	  return timeRemaining;
	}
	else
	{
	  //if we arent' playing the game, there is an infinite
	  //amount of time until the next period
	  return evtWaitForever;
	}
}

/***************************************************************
 *  Function:     StartApplication
 *
 *
 *  Summary:      Completes application initialization for the Pinball
 *	  game.  We load all the bitmaps into windows depending on the color
 *	  depth of the machine (>= 16 bit, < 16 bit) and load the game prefs.
 *    
 *  Parameters:	  None
 *
 *    
 *  Returns:	  An error code - 0.
 *    
 *  
 *  Called By:	  PilotMain
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static UInt32
StartApplication(void)
{
  UInt16 i, error;
  WinHandle oldDrawWinH;	
  UInt32 depths, firstBitmapID;
  Err	err;
  MemHandle bitmapHandle;
  BitmapPtr bitmapPtr;


	 // Set screen to maximum allowed depth
  err = WinScreenMode (winScreenModeGetSupportedDepths, 0 /*width*/, 
		  0 /*height*/, &depths, 0 /*color*/);

  // Scan for max depth and set it
  if (!err)
	{
	  UInt32	maxDepth;

	  maxDepth = 1;
	  for (i=0; i<32; i++)
		{
		  if (depths & (1 << i))
				maxDepth = i+1;
		}

	  WinScreenMode (winScreenModeSet, 0 /*width*/, 0 /*height*/, &maxDepth, 
					  0 /*color*/);
	}

	if (depths & (0x8000))
	{
	  //If we have 16-bit color, display the game in color
	  firstBitmapID = kFirst16BitBitmapID;
	}
	else
	{
	  //otherwise, display it in 2-bit greyscale
	  firstBitmapID = kFirst2BitBitmapID;
	}

	//load all the bitmaps
	oldDrawWinH = WinGetDrawWindow();
	for(i = 0; i < BitmapTypeCount; i++)
	{
		bitmapHandle = DmGetResource(bitmapRsc, firstBitmapID + i);
		bitmapPtr = MemHandleLock(bitmapHandle);

		GameInfo.windowHandles[i] = WinCreateOffscreenWindow(bitmapPtr->width, bitmapPtr->height,
				screenFormat, &error);
		ErrFatalDisplayIf(error, "Error loading images.");
		WinSetDrawWindow(GameInfo.windowHandles[i]);
		WinDrawBitmap(bitmapPtr, 0, 0);

		MemHandleUnlock(bitmapHandle);
		DmReleaseResource(bitmapHandle);
	}
	WinSetDrawWindow(oldDrawWinH);

	FrmGotoForm(rscGameFormID);

	//load the prefs and get ready to start the game.
	GameInfo.nextPeriodTime = TimGetTicks();
	GameInfo.status = gameWaitingForBall;
	PrvPinballLoadPrefs();

	return 0;
}

/***************************************************************
 *  Function:     StopApplication
 *
 *
 *  Summary:      Performs application cleanup.
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  0
 *    
 *  
 *  Called By:	  PilotMain
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static UInt32
StopApplication (void)
{
	UInt16 i;

	PrvPinballSavePrefs();

	for (i = 0; i < BitmapTypeCount; i++)
	{
	  if (GameInfo.windowHandles[i])
	  {
	    WinDeleteWindow(GameInfo.windowHandles[i], false);
	  }
	}

	ModelFree();
	GameUnmaskKeys();

	return 0;
}

/***************************************************************
 *  Function:     ApplicationHandleEvent
 *
 *
 *  Summary:      Loads the appropriate form event handlers.
 *    
 *
 *  Parameters:	  event IN	  the event pointer
 *
 *    
 *  Returns:	  True if the event was handled, false otherwise
 *    
 *  
 *  Called By:	  EventLoop
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Boolean
ApplicationHandleEvent(EventType * event)
{
  UInt16          formId;
  FormPtr         frm;

  if (event->eType == frmLoadEvent)
	{

	  // Load the form resource.
	  formId = event->data.frmLoad.formID;
	  frm = FrmInitForm (formId);
	  FrmSetActiveForm (frm);

	  // Set the event handler for the form.  The handler of the currently
	  // active form is called by FrmHandleEvent each time is receives an
	  // event.
	  switch (formId)
		{
		case rscGameFormID:
		  FrmSetEventHandler (frm, GameHandleEvent);
		  break;

		case rscFinalScoreFormID:
		  FrmSetEventHandler (frm, FinalScoreHandleEvent);
		  break;

		case rscHighScoreFormID:
		  FrmSetEventHandler (frm, HighScoreDisplayHandleEvent);
		  break;

		default:
		  ErrNonFatalDisplay ("Invalid Form Load Event");
		  break;
		}

	  return (true);
	}
  return (false);
}

/***************************************************************
 *  Function:     EventLoop
 *
 *
 *  Summary:      Runs the event polling and dispatch for the app
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  PilotMain
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/
 
static void
EventLoop (void)
{
	UInt16 err;
	EventType event;

	do
	{
		EvtGetEvent(&event, TimeUntilNextPeriod());

		if (event.eType == winExitEvent)
		{
			//pause the game when we exit the form
			if (event.data.winExit.exitWindow == (WinHandle) FrmGetFormPtr(rscGameFormID))
			{
				GameInfo.paused = true;
				GameInfo.pausedTime = TimGetTicks();
			}
		}
		else
		{
			if (event.eType == winEnterEvent)
			{
			  //when we enter the form for the game, set up the pause stuff
				if ((event.data.winEnter.enterWindow == (WinHandle) FrmGetFormPtr(rscGameFormID))
						&& (event.data.winEnter.enterWindow == (WinHandle) FrmGetFirstForm()))
				{
					if (!(GameInfo.paused))
					{
						GameInfo.nextPeriodTime = TimGetTicks() + GameInfo.periodLength + pauseTime;
					}
					else
					{
					  //if we've been paused, turn it off and start the ball after a few secs
						GameInfo.paused = false;
						GameInfo.nextPeriodTime += TimGetTicks() - GameInfo.pausedTime + pauseTime;
						GameInfo.startTime += TimGetTicks() - GameInfo.pausedTime;
					}
				}
			}
		}


		if (TimeUntilNextPeriod() == 0)
			{
			  //run all of the important parts of the game
				GameStateAdvance();
				GameStateElapse();
				GamePlaySounds();
			}

		if (PinballKeyHandleEvent(&event))
		{
			FrmDispatchEvent(&event);
		}
		else
		{
			if (! SysHandleEvent (&event))
			{
				if (! MenuHandleEvent (0, &event, &err))
				{
					if (! ApplicationHandleEvent (&event))
					{ 
						FrmDispatchEvent (&event); 
					}
				}
			}
		}
  } while (event.eType != appStopEvent);
}
		
/***************************************************************
 *  Function:     PilotMain
 *
 *
 *  Summary:      Main function for the app
 *    
 *
 *  Parameters:	  
 *	  cmd		IN		The command sent to the app
 *	  cmdPBP	IN		Not used
 *	  launchFlags IN	Flags for the application launch
 *    
 *  Returns:	An error code or 0 if everything worked
 *    
 *  Called By: System
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/
 
UInt32          
PilotMain (UInt16 cmd, void* cmdPBP, UInt16 launchFlags)
{
  UInt32 error;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{

	  error = StartApplication();	// Application start code
	  if (error) return error;

	  EventLoop();					// Event loop

	  StopApplication ();			// Application stop code
	}
  return 0;
}

/***************************************************************
 *  Function:     PinballKeyHandleEvent
 *
 *
 *  Summary:      Decides whether the system can look at the event,
 *	  or whether the form handler (for the game) should get it first
 *    
 *  Parameters:	  event	  IN	The event pointer
 *
 *    
 *  Returns:	  True if the event is a hard key press when the game is 
 *		up and running, false otherwise
 *  
 *  Called By:	  EventLoop
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Boolean
PinballKeyHandleEvent(EventType * event)
{
	if ((FrmGetActiveFormID() == rscGameFormID) && (event->eType == keyDownEvent) &&
				((GameInfo.status == gamePlaying) || (GameInfo.status == gameWaitingForBall)))
	{
		WChar chr = event->data.keyDown.chr;
		UInt16 mod = event->data.keyDown.modifiers;

		return ((!(mod & poweredOnKeyMask)) && ((chr == vchrHard1) || (chr == vchrHard2) ||
							(chr == vchrHard3) || (chr == vchrHard4) || (chr == vchrPageUp) || (chr == vchrPageDown)));
	}
	
	return false;
}

#pragma mark
#pragma mark -- Drawing --

/***************************************************************
 *  Function:     DrawObject
 *
 *
 *  Summary:      Draws an object on screen and to the screen buffer
 *	  given the number of the objects bitmap and where and how to draw
 *
 *  Parameters:
 *	  bitmapNumber		IN	  The number of the bitmap to draw
 *	  x, y				IN	  The (x, y) coordinates of the upper left corner
 *							  to draw the object
 *	  mode				IN	  How to draw the object
 *
 *    
 *  Returns:
 *	  Nothin
 *  
 *  Called By: 
 *    Everything
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
DrawObject (UInt16 bitmapNumber, UInt16 x, UInt16 y, WinDrawOperation mode)
{
	ErrFatalDisplayIf(GameInfo.windowHandles[bitmapNumber] == NULL,"Unhandled object image.");

	WinCopyRectangle(GameInfo.windowHandles[bitmapNumber], 0, &((GameInfo.windowHandles[bitmapNumber])->windowBounds), x, y, mode);
	WinCopyRectangle(GameInfo.windowHandles[bitmapNumber], GameInfo.backWindowH, &((GameInfo.windowHandles[bitmapNumber])->windowBounds), x, y, mode);
}

/***************************************************************
 *  Function:   GameStateDraw  
 *
 *
 *  Summary:      Draws the initial state of the game.
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameStart
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameStateDraw (void)
{
	UInt16 i, err;

	//set up the screen buffer
	GameInfo.backWindowH = WinCreateOffscreenWindow(kMaxScreenWidth, kMaxScreenHeight, screenFormat, &err);
	ErrFatalDisplayIf(GameInfo.backWindowH == NULL, "Invalid window.");
	
	//draw all the dynamic onscreen objects

	DrawObject(GetBackgroundBitmap(GameInfo.next.border.frameNumber),
						GameInfo.next.border.left, GameInfo.next.border.top, winPaint);

	for (i = 0; i < GameInfo.next.numFlippers; i++)
	{
		DrawObject(GetFlipperBitmap(i, GameInfo.next.flipperInfo[i].frameNumber),
								GameInfo.next.flipperInfo[i].left,
								GameInfo.next.flipperInfo[i].top, winPaint);

	}

	for (i = 0; i < GameInfo.next.numBumpers; i++)
	{
		DrawObject(GetBumperBitmap(GameInfo.next.bumperInfo[i].frameNumber), GameInfo.next.bumperInfo[i].left,
							GameInfo.next.bumperInfo[i].top, winPaint);
	}

	DrawObject(GetTrafficBitmap(GameInfo.next.traffic.frameNumber), GameInfo.next.traffic.left,
				  GameInfo.next.traffic.top, winPaint);
	
	DrawObject(GetStarBitmap(GameInfo.next.star.frameNumber), GameInfo.next.star.left, GameInfo.next.star.top, winPaint);
	
	for (i = 0; i < GameInfo.next.numTriBumps; i++)
	{
	  DrawObject(GetTriBumpBitmap(i, GameInfo.next.triBumpInfo[i].frameNumber), GameInfo.next.triBumpInfo[i].left,
			GameInfo.next.triBumpInfo[i].top, winPaint);
	}

	for (i = 0; i < GameInfo.next.numLights; i++)
	{
	  DrawObject(GetLightBitmap(GameInfo.next.light[i].frameNumber), GameInfo.next.light[i].left, 
				GameInfo.next.light[i].top, winPaint);
	}
}

/***************************************************************
 *  Function:     DrawBall
 *
 *
 *  Summary:      A callback function provided for the model to draw
 *	  the ball more than once during each period of the model.
 *    
 *  Parameters:
 *	  ballNumber	IN		The number of the ball to draw
 *	  ulx, uly		IN		The coords of the upper left corner
 *								  to draw the ball.
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By:	  Callback
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
DrawBall(UInt8 ulx, UInt8 uly)
{
	WinHandle tempDrawH;
	UInt16 err;
	RectangleType bounds, ballBounds;
	Boolean lastXBigger, lastYBigger;
	Coord destX, destY;

	GameInfo.last.ballInfo.left = GameInfo.next.ballInfo.left;
	GameInfo.last.ballInfo.top = GameInfo.next.ballInfo.top;
	GameInfo.next.ballInfo.left = ulx;
	GameInfo.next.ballInfo.top = uly;

	lastXBigger = (GameInfo.last.ballInfo.left > GameInfo.next.ballInfo.left);
	lastYBigger = (GameInfo.last.ballInfo.top > GameInfo.next.ballInfo.top);

	bounds.extent.x = ABS(GameInfo.last.ballInfo.left, GameInfo.next.ballInfo.left) + kBallWidth;
	bounds.extent.y = ABS(GameInfo.last.ballInfo.top, GameInfo.next.ballInfo.top) + kBallHeight;

	tempDrawH = WinCreateOffscreenWindow(bounds.extent.x, bounds.extent.y, screenFormat, &err);
	bounds.topLeft.x = (lastXBigger) ? (GameInfo.next.ballInfo.left) : (GameInfo.last.ballInfo.left);		
	bounds.topLeft.y = (lastYBigger) ? (GameInfo.next.ballInfo.top) : (GameInfo.last.ballInfo.top);		
	WinCopyRectangle(GameInfo.backWindowH, tempDrawH, &bounds, 0, 0, winPaint);

	ballBounds.topLeft.x = ballBounds.topLeft.y = 0;
	ballBounds.extent.x = kBallWidth;
	ballBounds.extent.y = kBallHeight;

	WinCopyRectangle(GameInfo.windowHandles[GetBallBitmap(GameInfo.next.ballInfo.frameNumber)], tempDrawH,
			&ballBounds, 
			((lastXBigger) ? (0) : (GameInfo.next.ballInfo.left - GameInfo.last.ballInfo.left)),
			((lastYBigger) ? (0) : (GameInfo.next.ballInfo.top - GameInfo.last.ballInfo.top)) , 
			winOverlay);
	
	destX = bounds.topLeft.x;
	destY = bounds.topLeft.y;
	bounds.topLeft.x = bounds.topLeft.y = 0;
	WinCopyRectangle(tempDrawH, NULL, &bounds, destX, destY, winPaint);
	WinDeleteWindow(tempDrawH, false);
}

/***************************************************************
 *  Function:     PrvDrawBallIndicator
 *
 *
 *  Summary:      Draws the balls left at the top of the screen
 *	  and draws a ball in the launch chute if appropriate
 *
 *  Parameters:	  ballsLeft		IN	  The number of balls left for the player
 *
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By:	  GameStateResume, GameLostBall
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
PrvDrawBallIndicator(UInt8 ballsLeft)
{
  UInt8 i;
  RectangleType rect;

  //draw one less ball, b/c one should be ready to play
  ballsLeft--;
  
  rect.topLeft.x = kBallIndicatorX;
  rect.topLeft.y = kBallIndicatorY;
  rect.extent.x = kBallIndicatorWidth;
  rect.extent.y = kBallIndicatorHeight;
  WinEraseRectangle(&rect, 0);
  
  for (i = 0; i < ballsLeft; i++)
  {
	//draw all the balls in place
	DrawObject(GetBallBitmap(0), kBallIndicatorX + (i * kBallIndicatorDeltaX), kBallIndicatorY, winPaint);
  }

  if (GameInfo.status == gameWaitingForBall)
  {
	//if we are ready to launch, draw the ball in the chute
	DrawBall(GameInfo.next.ballInfo.left, GameInfo.next.ballInfo.top);
  }
}

/***************************************************************
 *  Function:     PrvDrawSpecial
 *
 *
 *  Summary:      Draws a special graphic on the screen
 *    
 *
 *  Parameters:	  bmpIndex	  IN	The index of the special bitmap to draw
 *
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By: 
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
DrawSpecial(UInt16 bmpIndex)
{
  WinCopyRectangle(GameInfo.windowHandles[bmpIndex], NULL, &((GameInfo.windowHandles[bmpIndex])->windowBounds), 
		  kSpecialX, kSpecialY, winPaint);
}

#pragma mark
#pragma mark -- Initialization --

/***************************************************************
 *  Function:     GameStart
 *
 *
 *  Summary:      Starts the game and launches the ball
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameHandleEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameStart (void)
{
	GameMaskKeys();

	GameInfo.paused = false;
	GameInfo.pausedTime = 0;

	GameInfo.status = gamePlaying;

	GameInfo.periodLength = kPeriodLength;

	GameInfo.nextPeriodTime = TimGetTicks();
		
	GameStateAdvance();
	PrvDrawBallIndicator(GameInfo.ballsLeft);

	DrawSpecial(GreenFlag);
}

/***************************************************************
 *  Function:     GameMaskKeys
 *
 *
 *  Summary:      Masks off the hard keys used to play the game
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  StartApplication
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameMaskKeys(void)
{
	KeySetMask(~ (LeftFlipper | LeftFlipperAlt | RightFlipper | RightFlipperAlt));
}

/***************************************************************
 *  Function:     GameUnmaskKeys
 *
 *
 *  Summary:      Unmasks the game keys
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  StopApplication
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameUnmaskKeys(void)
{
	KeySetMask(keyBitsAll);
}

#pragma mark
#pragma mark -- During game --

/***************************************************************
 *  Function:     GameStateAdvance
 *
 *
 *  Summary:      Advances the game by compying new to old
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  EventLoop
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameStateAdvance (void)
{
	MemMove(&(GameInfo.last), &(GameInfo.next), sizeof(gameStateT));
}

/***************************************************************
 *  Function:     GameResume
 *
 *
 *  Summary:      Resumes the game from a pause by redrawing the screen
 *		and setting up the pause information.
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  GameHandleEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameResume(void)
{
  RectangleType bounds;

  GameMaskKeys();

  GameInfo.paused = false;
  GameInfo.status = gamePlaying;
  GameInfo.nextPeriodTime += TimGetTicks() - GameInfo.pausedTime + pauseTime;
  GameInfo.startTime += TimGetTicks() - GameInfo.pausedTime;

  bounds.topLeft.x = 0;
  bounds.topLeft.y = kPinballTopLeftY;
  bounds.extent.x = kMaxScreenWidth;
  bounds.extent.y = kMaxScreenHeight - kPinballTopLeftY;

  WinCopyRectangle(GameInfo.backWindowH, NULL, &bounds, 0, kPinballTopLeftY, winPaint);
}

/***************************************************************
 *  Function:     GameStateElapse
 *
 *
 *  Summary:      Checks to see if objects have been hit and then
 *	  performs actions as necessary
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  EventLoop
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameStateElapse (void)
{
	UInt32 keys;
	GameInfo.nextPeriodTime = GameInfo.nextPeriodTime + GameInfo.periodLength;

	keys = KeyCurrentState();

	if (keys & Tilt)
	{
	  //Tilting
	  if (!(GameInfo.tilt))
	  {
		if ((TimGetTicks() - GameInfo.tiltTime) > kTiltPauseTime)
		{
		  //has been long enough
		  GameInfo.tiltTime = TimGetTicks();
		  ModelTilt();
		  GameInfo.tilt = true;
		}
	  }
	}
	else
	{
	  GameInfo.tilt = false;
	}

	ModelCollide();

	if (ModelObjBeenHit(GameInfo.last.enterBoard))
	{
	  //enable the stopper chute
	  ModelEnableObj(GameInfo.last.stopperNum);
	}

	/*if (ModelObjBeenHit(GameInfo.last.tunnelL))
	{
	  ModelEditBall(135, 60, kBallRadius, 10, -45);
	  AnimateRaceTrack();
	}
	if (ModelObjBeenHit(GameInfo.last.tunnelR))
	{
	  ModelEditBall(44, 72, kBallRadius, 10, 180);
	  AnimateRaceTrack();
	}

	if (ModelObjBeenHit(GameInfo.last.straightAway))
	{
	  AnimateRaceTrack();
	}*/

	if (ModelObjBeenHit(GameInfo.last.bottomWall))
	{
	  GameLostBall();
	}

}

/***************************************************************
 *  Function:     GameLostBall
 *
 *
 *  Summary:      Deals with redrawing and game setup when a ball 
 *	  has been lost  - if there are still balls to play with, then
 *	  we draw everything again, and allow them to launch again.
 *	  If there are no balls left, then take them to the final
 *    score screen
 *	  
 *  Parameters:	  none
 *
 *    
 *  Returns:	  nothing
 *    
 *  
 *  Called By:	  GameStateElapse
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GameLostBall(void)
{
  UInt8 i;

  ModelDisableObj(GameInfo.last.stopperNum);
  DrawObject(GetBallBitmap(GameInfo.next.ballInfo.frameNumber), GameInfo.next.ballInfo.left,
		GameInfo.next.ballInfo.top, winMask);
  GameInfo.next.ballInfo.left = kBallX;
  GameInfo.next.ballInfo.top = kBallY;
  ModelEditBall(kBallX, kBallY, kBallRadius, 20, 90);
  GameInfo.ballsLeft--;
  GameInfo.status = gameWaitingForBall;
  for (i = 0; i < GameInfo.next.flipperInfo[kRightFlipper].numFrames; i++)
  {
	ChangeFlipperDown(&(GameInfo.next.flipperInfo[kRightFlipper]), kRightFlipper);
	ChangeFlipperDown(&(GameInfo.next.flipperInfo[kLeftFlipper]), kLeftFlipper);
	SysTaskDelay(3);
  }
  DrawFlipper(kRightFlipper, &(GameInfo.next.flipperInfo[kRightFlipper]));
  DrawFlipper(kLeftFlipper, &(GameInfo.next.flipperInfo[kLeftFlipper]));
  if (GameInfo.ballsLeft <= 0)
  {
	//game is over
	FrmGotoForm(rscFinalScoreFormID);
	ModelFree();
	WinDeleteWindow(GameInfo.backWindowH, true);
  }
  else
  {
	PrvDrawBallIndicator(GameInfo.ballsLeft);
  }
}

/***************************************************************
 *  Function:     GamePlaySounds
 *
 *
 *  Summary:      Plays the appropriate game sounds each time
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  EventLoop
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
GamePlaySounds(void)
{
}

#pragma mark
#pragma mark -- Flipper controls --

/***************************************************************
 *  Function:     CheckFlippers
 *
 *
 *  Summary:      Checks the status of the keys that control the
 *	  flippers - if they are pressed, we swing the appropriate
 *	  flipper up, otherwise, the flipper swings down if possible
 *
 *  Parameters:	  none
 *    
 *  Returns:	  nothing
 *    
 *  
 *  Called By:	  Callback
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
CheckFlippers(void)
{
  UInt32 keyState = KeyCurrentState();

  //check the left flipper
  if (keyState & (LeftFlipper | LeftFlipperAlt))
  {
	ChangeFlipperUp(&(GameInfo.next.flipperInfo[kLeftFlipper]), &(GameInfo.next.light[kLeftFlipper]), kLeftFlipper);
  }
  else
  {
	ChangeFlipperDown(&(GameInfo.next.flipperInfo[kLeftFlipper]), kLeftFlipper);
  }

  //check the right flipper
  if (keyState & (RightFlipper | RightFlipperAlt))
  {
	ChangeFlipperUp(&(GameInfo.next.flipperInfo[kRightFlipper]), &(GameInfo.next.light[kRightFlipper]), kRightFlipper);
  }
  else
  {
	ChangeFlipperDown(&(GameInfo.next.flipperInfo[kRightFlipper]), kRightFlipper);
  }
}

/***************************************************************
 *  Function:     ChangeFlipperUp
 *
 *
 *  Summary:      Moves the flipper up if possible by showing the next
 *	  frame of the graphic and flipping it in the model.  Also if the flipper
 *	  is just starting to go up, we toggle the light
 *    
 *
 *  Parameters:
 *	  flipperP		IN	  The object containing the flipper information
 *	  lightP		IN	  The object containing the light for that particular flipper
 *	  whichFlipper	IN	  A number telling us which flipper we're flipping
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By: CheckFlippers
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
ChangeFlipperUp(objectInfoT * flipperP, objectInfoT * lightP, UInt8 whichFlipper)
{
  if (flipperP->frameNumber < (flipperP->numFrames - 1))
  {
	(flipperP->frameNumber)++;
	flipperP->changed = true;
	ModelFlipFlipper(whichFlipper, true);
	if (flipperP->frameNumber == 1)
	{
	  lightP->frameNumber = (lightP->frameNumber + 1) % (lightP->numFrames);
	  DrawObject(GetLightBitmap(lightP->frameNumber), lightP->left, lightP->top, winPaint);
	}
	DrawFlipper(whichFlipper, flipperP);
  }
  else
  {
	ModelFlipFlipper(whichFlipper, true);
	flipperP->changed = false;
  }
}

/***************************************************************
 *  Function:     ChangeFlipperDown
 *
 *
 *  Summary:      Moves the flipper down if possible and updates
 *		the graphics.
 *
 *  Parameters:
 *	  flipperP		IN		The object with the flipper's information
 *	  whichFlipper	IN		A number that tells us which flipper to work on
 *    
 *  Returns:  
 *	  Nothing
 *    
 *  
 *  Called By: 
 *    CheckFlippers
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
ChangeFlipperDown(objectInfoT * flipperP, UInt8 whichFlipper)
{
  if (flipperP->frameNumber > 0)
  {
	(flipperP->frameNumber)--;
	flipperP->changed = true;
	ModelFlipFlipper(whichFlipper, false);
	DrawFlipper(whichFlipper, flipperP);
  }
  else
  {
	flipperP->changed = false;
	ModelFlipFlipper(whichFlipper, false);
  }
}

/***************************************************************
 *  Function:     DrawFlipper
 *
 *
 *  Summary:      Draws the flipper correctly so that a ball colliding
 *		with a flipper will not cause flickering.
 *
 *  Parameters:	
 *	  whichFlipper	  IN	A number telling us which flipper to flip.
 *	  flipperP		  IN	The object with the flipper's information
 *    
 *  Returns:	Nothing
 *    
 *  
 *  Called By: ChangeFlipperUp, ChangeFlipperDown
 *    
 *
 *  Notes:
 *    This should be expanded to work for all objects so that they
 *	  don't flicker on the redraw.
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
DrawFlipper(UInt8 whichFlipper, objectInfoT * flipperP)
{
	WinHandle flipperH = GameInfo.windowHandles[GetFlipperBitmap(whichFlipper, flipperP->frameNumber)];

	WinCopyRectangle(flipperH, GameInfo.backWindowH, &(flipperH->windowBounds), flipperP->left, flipperP->top, winPaint);
	if ((GameInfo.next.ballInfo.left >= flipperP->left - kBallWidth)
		&& (GameInfo.next.ballInfo.left <= flipperP->left + kBallWidth + kFlipperWidth)
		&& (GameInfo.next.ballInfo.top >= flipperP->top - kBallHeight)
		&& (GameInfo.next.ballInfo.top <= flipperP->top + kFlipperHeight + kBallHeight))
	{
	  //collides 
	  Boolean ballXBigger, ballYBigger;
	  WinHandle tempDrawH;
	  UInt16 err;
	  RectangleType bounds, totalBounds;
	  Coord destX, destY;

	  ballXBigger = (GameInfo.next.ballInfo.left > flipperP->left);
	  ballYBigger = (GameInfo.next.ballInfo.top > flipperP->top);

	  bounds.extent.x = ABS(GameInfo.next.ballInfo.left, flipperP->left) + kFlipperWidth;
	  bounds.extent.y = ABS(GameInfo.next.ballInfo.top, flipperP->top) + kFlipperHeight;

	  tempDrawH = WinCreateOffscreenWindow(bounds.extent.x, bounds.extent.y, screenFormat, &err);
	  bounds.topLeft.x = (ballXBigger) ? (flipperP->left) : (GameInfo.next.ballInfo.left);
	  bounds.topLeft.y = (ballYBigger) ? (flipperP->top) : (GameInfo.next.ballInfo.top);
	  WinCopyRectangle(GameInfo.backWindowH, tempDrawH, &bounds, 0, 0, winPaint);

	  totalBounds.topLeft.x = totalBounds.topLeft.y = 0;
	  totalBounds.extent.x = kBallWidth;
	  totalBounds.extent.y = kBallHeight;

	  WinCopyRectangle(GameInfo.windowHandles[GetBallBitmap(GameInfo.next.ballInfo.frameNumber)], tempDrawH,
			  &totalBounds,
			  ((ballXBigger) ? (GameInfo.next.ballInfo.left - flipperP->left) : (0)),
			  ((ballYBigger) ? (GameInfo.next.ballInfo.top - flipperP->top) : (0)),
			  winOverlay);

	  destX = bounds.topLeft.x;
	  destY = bounds.topLeft.y;
	  bounds.topLeft.x = bounds.topLeft.y = 0;
	  WinCopyRectangle(tempDrawH, NULL, &bounds, destX, destY, winPaint);
	  WinDeleteWindow(tempDrawH, false);
	}
	else
	{
	  WinCopyRectangle(flipperH, NULL, &(flipperH->windowBounds), flipperP->left, flipperP->top, winPaint);
	}
}

/***************************************************************
 *  Function:     UpdateScore
 *
 *
 *  Summary:      Updates the score display for the game
 *    
 *
 *  Parameters:	  pointAddition		IN		How much to add to the score
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  Callback
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
UpdateScore(UInt32 pointAddition)
{
  GameInfo.score += pointAddition;
  StrPrintF(GameInfo.scoreBuffer, "%ld", GameInfo.score);
  FldSetTextPtr(GameInfo.scoreField, GameInfo.scoreBuffer);
  FldSetFont(GameInfo.scoreField, boldFont);
  FldDrawField(GameInfo.scoreField);
}

#pragma mark
#pragma mark -- Event Handlers --

/***************************************************************
 *  Function:     GameHandleEvent
 *
 *
 *  Summary:      Event handler for the main game
 *    
 *
 *  Parameters:	  event	  IN	The event to deal with
 *
 *    
 *  Returns:	  true if the event was handled, false otherwise
 *    
 *  
 *  Called By:	  FrmDispatchEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Boolean
GameHandleEvent(EventType * event)
{
	Boolean handled = false;

	switch (event->eType)
	{
	case frmOpenEvent:
	  {
		FormPtr formP = FrmGetActiveForm();
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameResumeLabelID));
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameStartLabelID));
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameScoreFieldID));
		FrmDrawForm(formP);
		if (GameInfo.status == gameWaitingForBall)
		{
		  //if we are waiting to launch, redo the model
		  GameInit(&GameInfo);
		  GameStateModelInit(&GameInfo);
		  GameStateDraw ();
		  FrmShowObject(formP, FrmGetObjectIndex(formP, rscGameStartLabelID));
		}
		else
		{
		  //resume the game
		  GameResume();
		}
		
		handled = true;
		break;
	  }
	case menuOpenEvent:
	  {
		//pause the game
		FormPtr formP = FrmGetActiveForm();
		GameInfo.paused = true;
		GameInfo.pausedTime = TimGetTicks();
		GameInfo.status = gamePaused;
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameScoreFieldID));
		FrmShowObject(formP, FrmGetObjectIndex(formP, rscGameResumeLabelID));
	  }
	  break;
	case keyDownEvent:
		switch (event->data.keyDown.chr)
		{
		  case vchrPageUp:
		  {
			//launch the ball
			FormPtr formP = FrmGetActiveForm();
			FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameResumeLabelID));
			FrmHideObject(formP, FrmGetObjectIndex(formP, rscGameStartLabelID));
			FrmShowObject(formP, FrmGetObjectIndex(formP, rscGameScoreFieldID));
			GameStart();
			handled = true;
			break;
		  }
		  default:
			break;
		}
		break;
	case menuEvent:
	  GameInfo.status = gamePaused;
	  switch (event->data.menu.itemID)
	  {
		case rscMenuNewGameCmd:
		  //if they want a new game
		  ModelFree();
		  GameInfo.status = gameWaitingForBall;
		  WinDeleteWindow(GameInfo.backWindowH, true);
		  FrmGotoForm(rscGameFormID);
		  handled = true;
		  break;
		case rscMenuInstructionsCmd:
		  FrmHelp(rscInstructionsStr);
		  handled = true;
		  break;
		case rscMenuHighScoresCmd:
		  FrmGotoForm(rscHighScoreFormID);
		  handled = true;
		  break;
		case rscMenuAboutCmd:
		  DoAboutBox();
		  handled = true;
		  break;
		default:
		  break;
	  }
	  break;
	default:
		handled = false;
		break;
	}
	return handled;
}

/***************************************************************
 *  Function:     HighScoreDisplayHandleEvent
 *
 *
 *  Summary:      Event handler for high score form
 *    
 *
 *  Parameters:	  event		IN		the event to handle
 *
 *    
 *  Returns:	  true if the event was handled, false otherwise
 *    
 *  
 *  Called By:	  FrmDispatchEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Boolean
HighScoreDisplayHandleEvent (EventType * eventP)
{
  Boolean handled = false;

  switch (eventP->eType)
  {
	case frmOpenEvent:
	  FrmDrawForm(FrmGetActiveForm());
	  HighScoreDisplayInit();
	  handled = true;
	  break;
	case tblEnterEvent:
	  handled = true;
	  break;
	case ctlSelectEvent:
	  switch (eventP->data.ctlSelect.controlID)
	  {
		case rscHighScoreOKButtonID:
		  FrmGotoForm(rscGameFormID);
		  handled = true;
		  break;
		case rscHighScoreClearButtonID:
		  if (FrmAlert(rscClearHighScoresAlertID) == 0)
		  {
			InitializeHighScores();
			HighScoreDisplayInit();
		  }
		  handled = true;
		  break;
		default:
		  break;
	  }
	  break;
	case keyDownEvent:
	  switch (eventP->data.keyDown.chr)
	  {
		case vchrPageUp:
		  FrmGotoForm(rscGameFormID);
		  handled = true;
		  break;
		default:
		  break;
	  }
	  break;
	default:
	  break;
  }
  return handled;
}

/***************************************************************
 *  Function:     FinalScoreHandleEvent
 *
 *
 *  Summary:      The event handler for the final score (game over) screen
 *    
 *
 *  Parameters:	  eventP	IN	  The event pointer
 *
 *    
 *  Returns:	  true if we handled the event, false otherwise
 *    
 *  
 *  Called By:	  Callback
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static Boolean
FinalScoreHandleEvent(EventType * eventP)
{
  Boolean handled = false;
  FormPtr formP = FrmGetActiveForm();
  FieldPtr fieldP = PrvGetObjectPtr(rscFinalScoreHighScoreNameFieldID);

  switch (eventP->eType)
  {
	case frmOpenEvent:
	  if (GameInfo.score < LowestHighScore())
	  {
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscFinalScoreHighScoreLabelID));
		FrmHideObject(formP, FrmGetObjectIndex(formP, rscFinalScoreHighScoreNameFieldID));
	  }
	  else
	  {
		FrmSetFocus(formP, FrmGetObjectIndex(formP, rscFinalScoreHighScoreNameFieldID));
		FldInsert(fieldP, HighScores.lastNameEntered, StrLen(HighScores.lastNameEntered));
		FldSetSelection(fieldP, 0, StrLen(HighScores.lastNameEntered));
	  }
	  FrmDrawForm(formP);
	  fieldP = PrvGetObjectPtr(rscFinalScoreScoreFieldID);
	  StrPrintF(GameInfo.scoreBuffer, "%ld", GameInfo.score);
	  FldSetTextPtr(fieldP, GameInfo.scoreBuffer);
	  FldDrawField(fieldP);
	  break;
	case frmCloseEvent:
	  if (GameInfo.score >= LowestHighScore())
	  {
		AddHighScore(FldGetTextPtr(fieldP));
	  }
	  break;
	case ctlSelectEvent:
	  switch (eventP->data.ctlSelect.controlID)
	  {
		case rscFinalScoreOKButtonID:
		  FrmGotoForm(rscHighScoreFormID);
		  handled = true;
		  break;
		default:
		  break;
	  }
	  break;
	case keyDownEvent:
	  switch (eventP->data.keyDown.chr)
	  {	
		case vchrPageUp:
		  FrmGotoForm(rscHighScoreFormID);
		  handled = true;
		  break;
		default:
		  break;
	  }	
	  break;
	default:
	  break;
  }
  return handled;
}

#pragma mark
#pragma mark -- Misc. --

/***************************************************************
 *  Function:     HighScoreDisplayInit
 *
 *
 *  Summary:      Initializes the high score table with the
 *	  callback functions and reads the data out of the global
 *	  high scores array.
 *
 *  Parameters:
 *	  none
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    HighScoreHandleEvent
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
HighScoreDisplayInit(void)
{
  TablePtr tableP;
  UInt8 row;

  tableP = PrvGetObjectPtr(rscHighScoreTableID);

  //set up the table format
  for(row = 0; row < TblGetNumberOfRows(tableP); row++)
  {
	TblSetItemStyle(tableP, row, numberCol, numericTableItem);
	TblSetItemStyle(tableP, row, nameCol, labelTableItem);
	TblSetItemStyle(tableP, row, scoreCol, customTableItem);
	TblSetRowUsable(tableP, row, false);
  }

  TblSetCustomDrawProcedure(tableP, scoreCol, DrawScore);

  TblSetColumnUsable(tableP, numberCol, true);
  TblSetColumnUsable(tableP, nameCol, true);
  TblSetColumnUsable(tableP, scoreCol, true);

  //set the table data
  for (row = 0; row < HighScores.numScores; row++)
  {
	TblSetItemInt(tableP, row, numberCol, row + 1);
	TblSetItemPtr(tableP, row, nameCol, HighScores.scores[row].name);
	TblSetItemPtr(tableP, row, scoreCol, &(HighScores.scores[row].score));
	TblSetRowUsable(tableP, row, true);
	TblMarkRowInvalid(tableP, row);
  }
  while (row < TblGetNumberOfRows(tableP))
  {
	TblSetRowUsable(tableP, row, false);
	row++;
  }

  TblDrawTable(tableP);
  
  //if we just entered a score, highlight it
  if ((highlightScoreNum >= 0) && (highlightScoreNum < TblGetNumberOfRows(tableP)))
  {
	TblSelectItem(tableP, highlightScoreNum, scoreCol);
  }  
}

/***************************************************************
 *  Function:     InitializeHighScores
 *
 *
 *  Summary:      Resets the global high scores array.
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  Nothing
 *    
 *  
 *  Called By:	  HighScoreHandleEvent, PrvPinballLoadPrefs
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
InitializeHighScores(void)
{
  HighScores.numScores = 1;
  StrCopy(HighScores.scores[0].name, "Flip");
  HighScores.scores[0].score = 10000000;
  StrCopy(HighScores.lastNameEntered, "");
  highlightScoreNum = -1;

  PrefSetAppPreferences(hsFileCPinballGame, 0, kAppVersion, &HighScores, sizeof(highScoreTableType), true);
}

/***************************************************************
 *  Function:     PrvDrawScore
 *
 *
 *  Summary:      Draws the score (which is too big for the 
 *	  default int drawing function) on the table.
 *    
 *
 *  Parameters:
 *		tP		IN		The table pointer
 *		row		IN		The row to write
 *		column	IN		The column to write
 *		bounds	IN		The bounds of the cell
 *    
 *  Returns:
 *	  nothing
 *  
 *  Called By:	  Callback
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

void
DrawScore (void * tP, Int16 row, Int16 column, RectangleType * bounds)
{
  Char buffer[128];
  FontID prevFont;

  //hack b/c 3.1 doesn't have TblGetItemPtr
  TablePtr tableP = tP;
  UInt32 * numP = (UInt32*) tableP->items[row * tableP->numColumns + column].ptr;

  prevFont = FntSetFont(boldFont);
  StrPrintF(buffer, "%ld", *numP);
  WinDrawChars(buffer, StrLen(buffer), bounds->topLeft.x, bounds->topLeft.y);
  FntSetFont(prevFont);
}



/***************************************************************
 *  Function:     LowestHighScore
 *
 *
 *  Summary:      Returns the lowest high score from the global array
 *    
 *
 *  Parameters:	  None
 *
 *    
 *  Returns:	  The lowest current high score
 *    
 *  
 *  Called By:	  FinalScoreHandleEvent
 *    
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static UInt32
LowestHighScore(void)
{
  if (HighScores.numScores < kMaxHighScores)
  {
	//if there are still places on the board, allow them on.
	return 0;
  }
  else
  {
	//the actual lowest high score
	return (HighScores.scores[(HighScores.numScores - 1)].score);
  }
}

/***************************************************************
 *  Function:     AddHighScore
 *
 *
 *  Summary:      Adds a high score to the high scores array 
 *	  in the correct place
 *    
 *
 *  Parameters:	
 *		playerNameP		IN		The name of the player
 *    
 *  Returns:
 *    nothing
 *  
 *  Called By: 
 *    FinalScoreHandleEvent
 *
 *  Notes:
 *    
 *
 *  History:
 *    06-Sept-2000	  jem		Created.
 ****************************************************************/

static void
AddHighScore(Char * playerNameP)
{
  UInt16 i;

  if (HighScores.numScores >= kMaxHighScores)
  {
	//Chop one score off the end
	HighScores.numScores = kMaxHighScores - 1;
  }

  for (i = HighScores.numScores; i > 0; i--)
  {
	if (GameInfo.score >= HighScores.scores[i-1].score)
	{
	  HighScores.scores[i] = HighScores.scores[i-1];
	}
	else
	{
	  //this is the correct index, so stop shuffling
	  break;
	}
  }
  //if we exit the loop naturally, i == 0, so it works out
  if (playerNameP == NULL)
  {
	StrCopy(HighScores.scores[i].name, "Unnamed");
  }
  else
  {
	StrCopy(HighScores.scores[i].name, playerNameP);
  }
  HighScores.scores[i].score = GameInfo.score;
  HighScores.numScores++;
  StrCopy(HighScores.lastNameEntered, HighScores.scores[i].name);
  highlightScoreNum = i;
}

/************************************
 *
 *	Function:	PrvPinballLoadPrefs
 *
 *	Description: Loads scores and other prefs from the prefs
 *	  database
 *
 *	Parameters:	  none
 *
 *	Returns:	nothing
 *
 *	Called By:		AppStart
 *
 *	Revision History: 
 *	  jem		  06-Sept-2000		Created.
 *
 *****************************************/


static void
PrvPinballLoadPrefs(void)
{
  Int16 prefsVersion;
  UInt16 highScoresSize;

  highScoresSize = sizeof(highScoreTableType);
  prefsVersion = PrefGetAppPreferences(hsFileCPinballGame, kGamePrefsID, &HighScores, &highScoresSize, true);
  if (prefsVersion == noPreferenceFound)
  {
	InitializeHighScores();
  }
}

/************************************
 *
 *	Function:	PrvPinballSavePrefs
 *
 *	Description: Saves prefs and scores to the prefs
 *	  database
 *
 *	Parameters:	  none
 *
 *	Returns:	nothing
 *
 *	Called By:		AppStop
 *
 *	Revision History: 
 *	  jem		  06-Sept-2000		Created.
 *
 *****************************************/

static void
PrvPinballSavePrefs(void)
{
  PrefSetAppPreferences(hsFileCPinballGame, kGamePrefsID, kAppVersion, &HighScores, sizeof(highScoreTableType), true);
}

/***********************************************************************
 *
 * FUNCTION:    DoAboutBox
 *
 * DESCRIPTION: Shows the about box for the application.  Separated out
 *              because it uses a lot of marcros that take up a bunch
 *              of code space (and it's called three times).
 *
 * PARAMETERS:  none
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *         Name   Date      Description
 *         ----   ----      -----------
 *         dia	  04/10/00  Initial Revision
 *
 ***********************************************************************/

static void
DoAboutBox (void)
{
  if (KeyCurrentState() & keyBitPageDown)
    {
      UInt16 appCardNo;
      LocalID appDbId;

      SysCurAppDatabase(&appCardNo, &appDbId);		
 	  HsAboutHandspringApp (appCardNo, appDbId, NULL, NULL);		
    }
  else
    {
      HsAboutHandspringAppWithYearCredId (rscAboutBoxCopyrightYearStr, rscAboutBoxExtraCreditStr);
    }
}  