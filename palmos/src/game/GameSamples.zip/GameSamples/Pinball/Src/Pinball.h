/***************************************************************
 *
 * Project:
 *    Pinball 
 *
 * Copyright info:
 *    This is free software; you can redistribute it and/or modify
 *    it as you like.
 *
 *    This program is distributed in the hope that it will be useful,
 *    but WITHOUT ANY WARRANTY; without even the implied warranty of
 *    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. 
 *
 * FileName:
 *    Pinball.h
 * 
 * Description:
 *    General equates for the pinball game
 *
 * ToDo:
 *
 * History:
 *    06-Sept-2000	  jem		  InitialVersion
 *
 ****************************************************************/

#ifndef _PINBALL_H_
#define _PINBALL_H_

#include <PalmOS.h>
#include "ModelActions.h"

#define kAppVersion			1
#define kGamePrefsID		0x00

/************************************************
 *
 *	  Structures, Typedefs, and Enums
 *
 **********************************************/

#define kMaxNameLength		64
#define kMaxHighScores		9

enum
{
	gamePaused, gamePlaying, gameWaitingForBall
};

typedef struct
{
  Char name[kMaxNameLength];
  UInt32 score;
}
highScoreEntryType;

typedef struct
{
  highScoreEntryType scores[kMaxHighScores];
  UInt8 numScores;
  Char lastNameEntered[kMaxNameLength];
}
highScoreTableType;

/**********************************************
 *
 *	  Exports
 *
 **********************************************/

extern gameInfoT GameInfo;

extern void UpdateScore(UInt32 pointAddition);
extern void DrawBall(UInt8 ulx, UInt8 uly);
extern void DrawObject(UInt16 bitmapNumber, UInt16 x, UInt16 y, WinDrawOperation mode);
extern void DrawScore(void * tP, Int16 row, Int16 column, RectangleType * bounds);
extern void DrawSpecial(UInt16 bmpIndex);

extern void CheckFlippers(void);

#endif //_PINBALL_H_