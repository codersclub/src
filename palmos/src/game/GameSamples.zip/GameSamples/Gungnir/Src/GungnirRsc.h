/***************************************************************
 *
 *  Project:
 *	  Gungnir - Header file for the game Gungnir
 *
 * Perpetual Royalty Free License:
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like as long as any changes or improvements you make 
 *	  are provided free of charge to the public domain in source code format. 
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED WARRANTY OF
 *	  MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *  FileName:
 *	  GungnirRsc.h
 * 
 *  Description:
 *	  General equates for the application. 
 *
 * History:
 ****************************************************************/

//Menus
#define rscMenuID								1000

//Menu Items
#define rscMenuItemNewGame						100
#define rscMenuItemInstructions					102
#define rscMenuItemControls						103
#define rscMenuItemSettings						104
#define rscMenuItemHighScores					105
#define rscMenuItemAbout						107

//Death alert
#define rscDeathAlertID							1100

//16Bit Not Supprted alert
#define rscColorErrorAlert						1200

//Main game form
#define rscGameFormID							1000

//Instructions form
#define rscInstructionsFormID					1100

//Settings form
#define rscSettingsFormID						1200

//High scores form
#define rscHighScoresFormID						1300

//About form
#define rscAboutFormID							1400

//Startup form
#define rscStartupFormID						1500
#define rscStartButtonID						1550

//Controls form
#define rscControlsFormID						1600

//Score form
#define rscScoreFormID							1700

///Buttons
#define rscOKButtonID							2000
#define rscRestartButtonID						2001
#define rscQuitButtonID							2002

//Changing text labels
#define rscScoreLabelID							3000
#define rscLevelLabelID							3001

//Bitmaps
#define rscPlayerBaseBmpID						1000
#define rscSmileyBaseBmpID						1008
#define rscBulletBaseBmpID						1056
#define rscFlipBaseBmpID						1104
#define rscRingBaseBmpID						1152
#define rscGetReadyBmpID						1500

