/****************************************************
*	Gungnir.c
*
*	  Main file for the game Gungnir.
*
* Perpetual Royalty Free License:
*	  This is free software; you can redistribute it and/or modify
*	  it as you like as long as any changes or improvements you make 
*	  are provided free of charge to the public domain in source code format. 
*
*	  This program is distributed in the hope that it will be useful,
*	  but WITHOUT ANY WARRANTY; WITHOUT EVEN THE IMPLIED WARRANTY OF
*	  MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE.  
*
*	Notes:
*	  The graphics:
*		For speed purposes, almost all of the drawing is done
*	  using custom functions.  All of the screens are first
*	  drawn to an off-screen buffer in RAM, since there
*	  isn't anough VRAM to support 2 full-screen 16-bit
*	  images (in which case we could double-buffer....maybe
*	  some day).  The buffer always starts with just the
*	  tunnel, which is drawn so that incrementing every
*	  pixel makes the tunnel appear to move forward.  After
*	  the increment all of the sprites are copied onto the
*	  buffer, the buffer is copied to the screen, and then
*	  the sprites are removed, restoring what was behind them
*	  and leaving the buffer an empty tunnel again.
*
*	  The keys:
*		The key handling is not done with events, but instead
*	  by polling the key state.  This technique was adapted
*	  from the code for HardBall.
*	
*	  Sprite positions:
*		The sprites are all stored in the spriteList array.
*	  Adding and deleting sprites just marks various entries
*	  into this array as used or not.  Note that no assumptions
*	  may be made as to the ordering of the sprites in this list.
*	  The spritePositions array holds an index into the 
*	  spriteList array for the sprite currently at the depth and
*	  track, or -1 if no sprite is at that position.  Therefore 
*	  only one sprite can be at a given position at one time.  
*	  This means that when moving all of the sprites outward you
*	  have to go from the outside in so that you never move a 
*	  sprite on top of another.  The player sprite is the 
*	  exception.  It is stored in its own global and is not in 
*	  the spritePositions array.
*
*	  Sprite placement:
*		When placing a sprite, the coordinates of the top-left
*	  corner of the sprite's square for that position and depth
*	  are stored in the const static TrackPositions array.  This
*	  array was calculated assuming the current sprite dimensions
*	  for each depth.
*
*	  Scoring and levels:
*		The current scoring system is as follows:
*		  +1 for shooting a Smiley or hitting a Flip
*		  -1 for letting a Smiley pass
*		  -2 for shooting a Flip
*	  While your score can decrease, your level depends only
*	  on the total number of positive points you've accumulated.
*	  The level increases when you have gained 2 + current level
*	  positive points.  Increasing the level can increase how often
*	  the sprites come, or how many come at once (both stored in
*	  const static arrays).
*
*	TODO:
*	  - reduce the number of globals
*	  - separate some of the functions to separate files
*	  - clean the initialize and cleanup species code
*
*	History:
*	  05-Sep-2000	PGM	  Created by Patrick Mullen
*
******************************************************/


#pragma warning ( disable : 4068) //unkown pragma

#pragma mark ---- includes ----

#include <PalmOS.h>
#include <PalmTypes.h>
#include <TextMgr.h>
#include <Chars.h>
#include <KeyMgr.h>

#include "GungnirRsc.h"


#pragma mark ---- defines ----

//Allow the inline keyword to compile under VC
#if defined(_MSC_VER)
  #define INLINE
#else
  #define INLINE inline
#endif

//Required color depth
#define ColorDepth 16

//Control speed of tunnel
#define OneWordTunnelIncrement 0x0004
#define TwoWordTunnelIncrement 0x00040004

//Control speed of game
#define GameTimeInterval 5

//Game layout
#define NumSpriteSizes 6
#define NumTracks 16
#define HalfNumTracks 8 //NumTracks/2
#define ModNumTracksMask 0x000F
#define ModHalfNumTracksMask 0x0007
#define TrackDepth 17
#define MaxNumSprites 64
#define ModMaxNumSpritesMask 0x003F

//Point and level system
#define NumLevels 50
#define MaxLevel (NumLevels - 1)
#define BasePointsPerLevel 2
#define MinNumPoints  -10

//Keys
#define MoveLeftKey		keyBitHard1
#define MoveRightKey	keyBitHard2
#define ScoreKey		keyBitHard3
#define ShootKey		keyBitHard4
#define AllowedKeys		(MoveLeftKey | MoveRightKey | ScoreKey | ShootKey)

//Species
#define NumSpecies	5
#define Player	0
#define Bullet	1
#define Smiley	2
#define Flip	3
#define Ring	4


#pragma mark ---- tables ----

//SpriteDimensions - # of pixels on one side of the sprite 
const static UInt8	   SpriteDimensions[NumSpriteSizes] = 
  {
	6,	//0
	8,	//1
	10,	//2
	12,	//3
	14,	//4
	16	//5
  };

//DepthToSize = maps a depth to an index into SpriteDimensions
const static UInt8	  DepthToSize[TrackDepth] = 
  {
	0,  //0
	0,  //1
	0,  //2
	0,  //3
	0,  //4
	0,  //5
	1,  //6
	1,  //7
	1,  //8
	1,  //9
	2,  //10
	2,  //11
	3,  //12
	3,  //13
	4,  //14
	4,  //15
	5,  //16
//	5,  //17
  };

//TrackPositions - maps a depth and track number to the upper-left
//  corner point for a sprite at that position
const static PointType TrackPositions[TrackDepth][NumTracks] = 
  {
	{//0 r=18, -3
	  {77, 94},  //0 
	  {83, 93},  //1
	  {89, 89},  //2 
	  {93, 83},  //3
	  {94, 77},  //4 
	  {93, 70},  //5
	  {89, 64},  //6 
	  {83, 60},  //7
	  {77, 59},  //8 
	  {70, 60},  //9
	  {64, 64},  //10
	  {60, 70},  //11
	  {59, 77},  //12
	  {60, 83},  //13
	  {64, 89},  //14
	  {70, 93}  //15
	},
	{//1 r=19, -3
	  {77, 95},  //0
	  {84, 94},  //1
	  {90, 90},  //2
	  {94, 84},  //3
	  {95, 77},  //4
	  {94, 69},  //5
	  {90, 63},  //6
	  {84, 59},  //7
	  {77, 58},  //8
	  {69, 59},  //9
	  {63, 63},  //10
	  {59, 69},  //11
	  {58, 77},  //12
	  {59, 84},  //13
	  {63, 90},  //14
	  {69, 94}  //15
	},
	{//2 r=20, -3
	  {77, 96},  //0
	  {84, 95},  //1
	  {91, 91},  //2
	  {95, 84},  //3
	  {96, 77},  //4
	  {95, 69},  //5
	  {91, 62},  //6
	  {84, 58},  //7
	  {77, 57},  //8
	  {69, 58},  //9
	  {62, 62},  //10
	  {58, 69},  //11
	  {57, 77},  //12
	  {58, 84},  //13
	  {62, 91},  //14
	  {69, 95}  //15
	},
	{//3 r=21, -3
	  {77, 97},  //0
	  {85, 96},  //1
	  {91, 91},  //2
	  {96, 85},  //3
	  {97, 77},  //4
	  {96, 68},  //5
	  {91, 62},  //6
	  {85, 57},  //7
	  {77, 56},  //8
	  {68, 57},  //9
	  {62, 62},  //10
	  {57, 68},  //11
	  {56, 77},  //12
	  {57, 85},  //13
	  {62, 91},  //14
	  {68, 96}  //15
	},
	{//4 r=22, -3
	  {77, 98},  //0
	  {85, 97},  //1
	  {92, 92},  //2
	  {97, 85},  //3
	  {98, 77},  //4
	  {97, 68},  //5
	  {92, 61},  //6
	  {85, 56},  //7
	  {77, 55},  //8
	  {68, 56},  //9
	  {61, 61},  //10
	  {56, 68},  //11
	  {55, 77},  //12
	  {56, 85},  //13
	  {61, 92},  //14
	  {68, 97}  //15
	},
	{//5 r=23, -3
	  {77, 99},  //0
	  {85, 98},  //1
	  {93, 93},  //2
	  {98, 85},  //3
	  {99, 77},  //4
	  {98, 68},  //5
	  {93, 60},  //6
	  {85, 55},  //7
	  {77, 54},  //8
	  {68, 55},  //9
	  {60, 60},  //10
	  {55, 68},  //11
	  {54, 77},  //12
	  {55, 85},  //13
	  {60, 93},  //14
	  {68, 98}  //15
	},
	{//6 r=25, -4
	  {76, 100},  //0
	  {85, 99},  //1
	  {93, 93},  //2
	  {99, 85},  //3
	  {100, 76},  //4
	  {99, 66},  //5
	  {93, 58},  //6
	  {85, 52},  //7
	  {76, 51},  //8
	  {66, 52},  //9
	  {58, 58},  //10
	  {52, 66},  //11
	  {51, 76},  //12
	  {52, 85},  //13
	  {58, 93},  //14
	  {66, 99}  //15
	},
	{//7 r=26, -4
	  {76, 101},  //0
	  {85, 100},  //1
	  {94, 94},  //2
	  {100, 85},  //3
	  {101, 76},  //4
	  {100, 66},  //5
	  {94, 57},  //6
	  {85, 51},  //7
	  {76, 50},  //8
	  {66, 51},  //9
	  {57, 57},  //10
	  {51, 66},  //11
	  {50, 76},  //12
	  {51, 85},  //13
	  {57, 94},  //14
	  {66, 100}  //15
	},
	{//8 r=28, -4
	  {76, 103},  //0
	  {86, 101},  //1
	  {95, 95},  //2
	  {101, 86},  //3
	  {103, 76},  //4
	  {101, 65},  //5
	  {95, 56},  //6
	  {86, 50},  //7
	  {76, 48},  //8
	  {65, 50},  //9
	  {56, 56},  //10
	  {50, 65},  //11
	  {48, 76},  //12
	  {50, 86},  //13
	  {56, 95},  //14
	  {65, 101}  //15
	},
	{//9 r=30, -4
	  {76, 105},  //0
	  {87, 103},  //1
	  {97, 97},  //2
	  {103, 87},  //3
	  {105, 76},  //4
	  {103, 64},  //5
	  {97, 54},  //6
	  {87, 48},  //7
	  {76, 46},  //8
	  {64, 48},  //9
	  {54, 54},  //10
	  {48, 64},  //11
	  {46, 76},  //12
	  {48, 87},  //13
	  {54, 97},  //14
	  {64, 103}  //15
	},
	{//10 r=33, -5
	  {75, 107},  //0
	  {87, 105},  //1
	  {98, 98},  //2
	  {105, 87},  //3
	  {107, 75},  //4
	  {105, 62},  //5
	  {98, 51},  //6
	  {87, 44},  //7
	  {75, 42},  //8
	  {62, 44},  //9
	  {51, 51},  //10
	  {44, 62},  //11
	  {42, 75},  //12
	  {44, 87},  //13
	  {51, 98},  //14
	  {62, 105}  //15
	},
	{//11 r=36, -5
	  {75, 110},  //0
	  {88, 108},  //1
	  {100, 100},  //2
	  {108, 88},  //3
	  {110, 75},  //4
	  {108, 61},  //5
	  {100, 49},  //6
	  {88, 41},  //7
	  {75, 39},  //8
	  {61, 41},  //9
	  {49, 49},  //10
	  {41, 61},  //11
	  {39, 75},  //12
	  {41, 88},  //13
	  {49, 100},  //14
	  {61, 108}  //15
	},
	{//12 r=40, -6
	  {74, 113},  //0
	  {89, 110},  //1
	  {101, 101},  //2
	  {110, 89},  //3
	  {113, 74},  //4
	  {110, 58},  //5
	  {101, 45},  //6
	  {89, 37},  //7
	  {74, 34},  //8
	  {58, 37},  //9
	  {45, 45},  //10
	  {37, 58},  //11
	  {34, 74},  //12
	  {37, 89},  //13
	  {45, 101},  //14
	  {58, 110}  //15
	},
	{//13 r=44, -6
	  {74, 117},  //0
	  {90, 114},  //1
	  {105, 105},  //2
	  {114, 90},  //3
	  {117, 74},  //4
	  {114, 57},  //5
	  {105, 42},  //6
	  {90, 33},  //7
	  {74, 30},  //8
	  {57, 33},  //9
	  {42, 42},  //10
	  {33, 57},  //11
	  {30, 74},  //12
	  {33, 90},  //13
	  {42, 105},  //14
	  {57, 114}  //15
	},
	{//14 r=50, -7
	  {73, 122},  //0
	  {91, 119},  //1
	  {107, 107},  //2
	  {119, 91},  //3
	  {122, 73},  //4
	  {119, 53},  //5
	  {107, 37},  //6
	  {91, 26},  //7
	  {73, 23},  //8
	  {53, 26},  //9
	  {37, 37},  //10
	  {26, 53},  //11
	  {23, 73},  //12
	  {26, 91},  //13
	  {37, 107},  //14
	  {53, 119}  //15
	},
	{//15 r=58, -7
	  {73, 130},  //0
	  {95, 126},  //1
	  {113, 113},  //2
	  {126, 95},  //3
	  {130, 73},  //4
	  {126, 50},  //5
	  {113, 31},  //6
	  {95, 19},  //7
	  {73, 15},  //8
	  {50, 19},  //9
	  {31, 31},  //10
	  {19, 50},  //11
	  {15, 73},  //12
	  {19, 95},  //13
	  {31, 113},  //14
	  {50, 126}  //15
	},
	{//16 r=71, -8
	  {72, 142},  //0
	  {99, 137},  //1
	  {122, 122},  //2
	  {137, 99},  //3
	  {142, 72},  //4
	  {137, 44},  //5
	  {122, 21},  //6
	  {99, 6},  //7
	  {72, 1},  //8
	  {44, 6},  //9
	  {21, 21},  //10
	  {6, 44},  //11
	  {1,72},  //12
	  {6, 99},  //13
	  {21, 122},  //14
	  {44, 137}  //15
	},
/*	{//17 r=85, -8
	  {72, 156},  //0
	  {104, 150},  //1
	  {131, 131},  //2
	  {150, 104},  //3
	  {156, 72},  //4
	  {150, 39},  //5
	  {131, 11},  //6
	  {104, -7},  //7
	  {72, -13},  //8
	  {39, -7},  //9
	  {11, 11},  //10
	  {-7, 39},  //11
	  {-13, 72},  //12
	  {-7, 104},  //13
	  {11, 131},  //14
	  {39, 150}  //15
	}*/
  };

//ShootableSpecies - Maps a species to whether or not it is shootable
const static Boolean ShootableSpecies[NumSpecies] = 
  {
	false, //Player
	false, //Bullet
	true, //Smiley
	true, //Flip
	false //Ring
  };

//screenRect - Rectangle that holds the size of the 160x160 screen
const static RectangleType screenRect = 
  {
	{0, 0},
	{160, 160}
  };

//LevelSteps - Number of tunnel movements between sprite waves
//	  for each level
const static UInt32 LevelSteps[NumLevels] = 
  {
	16,	//0
	15,	//1
	14,	//2
	13,	//3
	12,	//4
	12,	//5
	11,	//6
	10,	//7
	9,	//8
	8,	//9
	12,	//10
	11,	//11
	10,	//12
	9,	//13
	8,	//14
	12,	//15
	11,	//16
	10,	//17
	9,	//18
	8,	//19
	12,	//20
	11,	//21
	10,	//22
	9,	//23
	8,	//24
	12,	//25
	11,	//26
	10,	//27
	9,	//28
	8,	//29
	12,	//30
	11,	//31
	10,	//32
	9,	//33
	8,	//34
	12,	//35
	11,	//36
	10,	//37
	9,	//38
	8,	//39
	12,	//40
	11,	//41
	10,	//42
	9,	//43
	8,	//44
	12,	//45
	11,	//46
	10,	//47
	9,	//48
	8	//49
  };

//LevelSprites - Number of sprites released per wave for
//		each level
const static UInt32 LevelSprites[NumLevels] =
  {
	1,	//0
	1,	//1
	1,	//2
	1,	//3
	1,	//4
	2,	//5
	2,	//6
	2,	//7
	2,	//8
	2,	//9
	3,	//10
	3,	//11
	3,	//12
	3,	//13
	3,	//14
	4,	//15
	4,	//16
	4,	//17
	4,	//18
	4,	//19
	5,	//20
	5,	//21
	5,	//22
	5,	//23
	5,	//24
	6,	//25
	6,	//26
	6,	//27
	6,	//28
	6,	//29
	7,	//30
	7,	//31
	7,	//32
	7,	//33
	7,	//34
	8,	//35
	8,	//36
	8,	//37
	8,	//38
	8,	//39
	9,	//40
	9,	//41
	9,	//42
	9,	//43
	9,	//44
	10,	//45
	10,	//46
	10,	//47
	10,	//48
	10	//49
  };


#pragma mark ---- structs ----

typedef struct{
  UInt16* baseAddress;
  WinHandle drawWindow;
  BitmapType* drawBitmap;
}	FrameInfoType;

typedef struct{
  WinHandle background;
  UInt8		depth;
  UInt8		track;
  UInt8		species;
  UInt16	index;
  Boolean	moveForward;
  Boolean	shootable;
  Boolean	exists;
}	SpriteType;


#pragma mark ---- globals ----

static SpriteType		playerSprite;
static SpriteType		spriteList[MaxNumSprites];
static Int16			spritePositions[TrackDepth][NumTracks];
static UInt32			nextIntervalTime;
static BitmapPtr		speciesBitmapArray[NumSpecies][HalfNumTracks][NumSpriteSizes];
static FrameInfoType	buffer;
static FrameInfoType	screenInfo;
static Int32			score;
static Boolean			gameRunning;
static UInt16			level;
static UInt16			levelPoints;
static Boolean			exitApp;
static Boolean			forward;
static Boolean			gameStarted;
static Boolean			newGame;


#pragma mark ---- macros ----


#pragma mark ---- function declarations ----

static UInt32 AppStart (void);

static UInt32 AppStop (void);

static void AppEventLoop (void);

INLINE static Boolean AppHandleEvent (EventType* event);

INLINE static Boolean AppHandleMenuEvent (UInt16 menuID);

INLINE static Boolean AppMaskKeysHandler (EventType* event);

static Boolean StartupFormEventHandler (EventType* event);

static Boolean GameFormEventHandler (EventType* event);

static Boolean ScoreFormEventHandler (EventType* event);

static Boolean DefaultFormEventHandler (EventType* event);

static UInt16 InitializeScreen (void);

static void CleanupScreen (void);

static void DrawBackground (void);

static UInt16 InitializeSprites (void);

static void CleanupSprites (void);

static UInt16 InitializePositions(void);

static UInt16 InitializeSpecies (void);

static void CleanupSpecies (void);

INLINE static SpriteType* CreateSprite (UInt8 species, UInt8 track, UInt8 depth);

INLINE static void DeleteSprite (UInt16 index);

INLINE static void DeleteAllSprites (void);

INLINE static void PlaceSprite (SpriteType* toPlace);

INLINE static void PlaceAllSprites (void);

INLINE static void RemoveSprite (SpriteType* toRemove);

INLINE static void RemoveAllSprites (void);

INLINE static void MoveSprites (void);

INLINE static void HandleKeys (void);

INLINE static void CheckForCollisions (void);

INLINE static void PlayerHit (Int16 index);

INLINE static void CheckForShots (void);

INLINE static void SpriteShot (UInt16 index);

INLINE static UInt32 GetTimeUntilNextInterval (void);

INLINE static void DisplayScreen (void);

INLINE static void CopyBitmapToWindow(UInt16* winBaseAddress,
							   UInt16* bmpBaseAddress,
							   RectangleType* position,
							   Boolean rotate);

static void Restart (void);

static void UnleashSprites (void);

INLINE static void CheckScore (void);

INLINE static void Death (void);

static void IncrementBuffer (UInt32* baseAddress);

static void DecrementBuffer (UInt32* baseAddress);


#pragma mark ---- function definitions ----

/*****************************************************
/ UInt32 PilotMain (UInt16 cmd, void* cmdPBP, UInt16 launchFlags)
/
/	Standard PilotMain function called to load program.
******************************************************/
UInt32          
PilotMain (UInt16 cmd, void* cmdPBP, UInt16 launchFlags)
{
  UInt32 error = 0;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{
	  error = AppStart();	// Application start code
	  if (error)
		return error;

	  AppEventLoop();					// Event loop

	  error = AppStop ();			// Application stop code
	}
  return error;
}


/*****************************************************
/  static UInt16 AppStart (void)
/
/	Initialization of the program.
/
/  Returns	0 if no error
******************************************************/
static UInt32
AppStart (void)
{
  UInt32	depths;
  UInt32	error;
  UInt16	i;

 // Set screen to maximum allowed depth
  error = WinScreenMode (winScreenModeGetSupportedDepths, 0 /*width*/, 
		  0 /*height*/, &depths, 0 /*color*/);

   // Scan for max depth and set it
  if (!error)
	{
	  UInt32	maxDepth;

	  maxDepth = 1;
	  for (i=0; i<32; i++)
		{
		  if (depths & (1 << i))
			maxDepth = i+1;
		}
	
	  //The game only works at one color depth - 16 bit
	  if (maxDepth != ColorDepth)
		{
		  FrmAlert (rscColorErrorAlert);
		  return 1;
		}
		
	  WinScreenMode (winScreenModeSet, 0 /*width*/, 0 /*height*/, &maxDepth, 
					  0 /*color*/);
	}
  else
	{
	  return error;
	}

  //goto main form
  FrmGotoForm (rscStartupFormID);

  //Remove keys that we check from generating events
  KeySetMask(~AllowedKeys);

  //Seed the random number generator
  SysRandom(TimGetSeconds());

  error = InitializeSprites();
  if(error)
	return error;

  error = InitializePositions();
  if(error)
	return error;

  error = InitializeSpecies();
  if(error)
	return error;

  error = InitializeScreen();
  if(error)
	return error;
  
  //initialize a few globals
  forward = true;

  gameRunning = false;

  gameStarted = false;

  newGame = true;

  //made it!
  return 0;
}


/*****************************************************
/  static void AppEventLoop (void)
/
/	Main event loop of the program.  Does all event
/  sorting and exits on a stop event or when the 
/  global exitApp is set.
/
/  Returns	None
******************************************************/
static void
AppEventLoop (void)
{
  UInt16 error;
  EventType event;

  nextIntervalTime = TimGetTicks() + GameTimeInterval;
  do
	{
	  EvtGetEvent (&event, GetTimeUntilNextInterval());
	  
	  if(!AppMaskKeysHandler (&event))
		if(!SysHandleEvent (&event))
		  if(!MenuHandleEvent (0, &event, &error))
			if(!AppHandleEvent (&event))
			  FrmDispatchEvent (&event);		
	} while(event.eType != appStopEvent && !exitApp);
}


/*****************************************************
/  static Boolean AppHandleEvent (EventType* event)
/
/	 Does all the basic event handling for the program,
/  mostly loading the forms.
/
/  Returns	0 if no error
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
INLINE static Boolean 
AppHandleEvent (EventType* event)
{
  Boolean handled = false;
  Int32 formId;
  FormPtr frm;

  switch (event->eType)
	{
	case frmLoadEvent:	  
	  gameRunning = false;
	  formId = event->data.frmLoad.formID;
	  frm = FrmInitForm (formId);
	  FrmSetActiveForm(frm);
	  switch (formId)
		{
		case rscGameFormID:
		  FrmSetEventHandler(frm, GameFormEventHandler);
		  gameRunning = true;
		  break;

		case rscStartupFormID:
		  FrmSetEventHandler(frm, StartupFormEventHandler);
		  break;

		case rscScoreFormID:
		  FrmSetEventHandler(frm, ScoreFormEventHandler);
		  break;

		default:
		  FrmSetEventHandler(frm, DefaultFormEventHandler);
		  break;
		}	  
	  handled = true;
	  break;

	case menuEvent:
	  handled = AppHandleMenuEvent(event->data.menu.itemID);
	  break;

	default:
	  break;
	}
  return handled;
}


/*****************************************************
/  static Boolean AppHandleMenuEvent (EventType* event)
/
/	 Handles menu selections.
/
/  Returns	0 if no error
/
/  Word	  menuID  IN	ID of item selected
******************************************************/
INLINE static Boolean 
AppHandleMenuEvent (UInt16 menuID)
{
  Boolean handled = false;

  switch (menuID)
	{
	case rscMenuItemNewGame:
	  newGame = true;
	  FrmGotoForm (rscGameFormID);
	  handled = true;
	  break;

	case rscMenuItemInstructions:
	  FrmGotoForm (rscInstructionsFormID);
	  handled = true;
	  break;

	case rscMenuItemSettings:
	  FrmGotoForm (rscSettingsFormID);
	  handled = true;
	  break;
	  
	case rscMenuItemHighScores:
	  FrmGotoForm (rscHighScoresFormID);
	  handled = true;
	  break;

	case rscMenuItemAbout:
	  FrmGotoForm (rscAboutFormID);
	  handled = true;
	  break;

	case rscMenuItemControls:
	  FrmGotoForm (rscControlsFormID);
	  handled = true;
	  break;

	default:
	  break;
	}
  return handled;
}


/*****************************************************
/  static Boolean AppMaskKeysHandler (EventType* event)
/
/	 Handles any keyDownEvents that should never be
/  generated (but sometimes are due to glitches).
/
/  Returns	0 if no error
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
INLINE static Boolean
AppMaskKeysHandler (EventType* event)
{
  if (event->eType == keyDownEvent)
	{
	  WChar chr = event->data.keyDown.chr;
	  UInt16 mod = event->data.keyDown.modifiers;
	  return ((!(mod & poweredOnKeyMask)) && ((chr == vchrHard1) || (chr == vchrHard2) ||
			  (chr == vchrHard3) || (chr == vchrHard4) || (chr == vchrPageUp) || (chr == vchrPageDown)));
	}
  return 0;
}


/*****************************************************
/  static Boolean StartupFormEventHandler (EventType* event)
/
/	 Handles events for startup form.
/
/  Returns	true if handled
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
static Boolean
StartupFormEventHandler (EventType* event)
{
  Boolean handled = false;

  switch (event->eType)
	{
	case frmOpenEvent:
	  FrmDrawForm (FrmGetActiveForm ());
	  handled = true;
	  break;
	  
	case ctlSelectEvent:
	  if (event->data.ctlSelect.controlID == rscStartButtonID)
		{
		  gameStarted = true;
		  newGame = true;
		  FrmGotoForm (rscGameFormID);
		  handled = true;
		}
	  break;

	default:
	  break;
	}
  return handled;
}


/*****************************************************
/  static Boolean GameFormEventHandler (EventType* event)
/
/	 Handles events for the game, including doing all
/  of the game stuff on nilEvents.
/
/  Returns	true if handled
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
static Boolean 
GameFormEventHandler (EventType* event)
{
  Boolean handled = false;

  switch (event->eType)
	{
	case frmOpenEvent:
	  if (newGame)
		{
		  Restart ();
		}
	case winEnterEvent:
	  if (event->data.winEnter.enterWindow == (WinHandle) FrmGetFormPtr (rscGameFormID) &&
		  event->data.winEnter.enterWindow == (WinHandle) FrmGetFirstForm ())
		{
		  gameRunning = true;
		  handled = true;
		}
	  break;

	case winExitEvent:
	  if (event->data.winExit.exitWindow == (WinHandle) FrmGetFormPtr (rscGameFormID))
		{
		  gameRunning = false;
		  handled = true;
		}
	  break;

	case nilEvent:
	  //move ahead one game state if we're running
	  if (gameRunning)
		{
		  nextIntervalTime = TimGetTicks() + GameTimeInterval;
		  
		  //this order is very important for smoother play (and to work correctly)
		  HandleKeys();
		  CheckForCollisions();
		  UnleashSprites();
		  DisplayScreen();
		  CheckScore ();
		  CheckForShots();
		  MoveSprites();
		}
	  break;

	default:
	  break;
	}

  
  return handled;
}


/*****************************************************
/  static Boolean ScoreFormEventHandler (EventType* event)
/
/	 Handles events for score forms
/
/  Returns	true if handled
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
static Boolean 
ScoreFormEventHandler (EventType* event)
{
  static UInt8 buttonPressed = 0;
  Boolean handled = false;
  Char scratch[32];

  switch (event->eType)
	{
	case frmOpenEvent:
	  //update the score and level labels
	  FrmCopyLabel(FrmGetActiveForm(), rscScoreLabelID, StrIToA(scratch, score));
	  FrmCopyLabel(FrmGetActiveForm(), rscLevelLabelID, StrIToA(scratch, level));
	  FrmDrawForm (FrmGetActiveForm ());
	  handled = true;
	  break;
	  
	case ctlSelectEvent:
	  switch (event->data.ctlSelect.controlID )
	  {
	  case rscOKButtonID:
		FrmGotoForm (rscGameFormID);
		handled = true;
		break;

	  case rscRestartButtonID:
		newGame = true;
		FrmGotoForm (rscGameFormID);
		handled = true;
		break;

	  case rscQuitButtonID:
		exitApp = true;
		FrmGotoForm (rscScoreFormID);
		handled = true;
		break;

	  
	  default:
		break;
	  }
	  break;

	//This stuff allows pressing the score key again to return
	//to the game.  Since we aren't generating key events we 
	//have to make sure that the key comes up, goes back down,
	//and then comes back up to avoid jumping straight back
	//into the score form on exit.  buttonPressed is used as a
	//3-state machine.
	case nilEvent:
	  if (KeyCurrentState() & ScoreKey)
		{
		  if(buttonPressed == 1)
			buttonPressed = 2;
		}
	  else
		{
		  if(buttonPressed == 0)
			buttonPressed = 1;
		  else if(buttonPressed == 2)
			{
			  buttonPressed = 0;
			  FrmGotoForm (rscGameFormID);
			}
		}
	  handled = true;
	  break;

	default:
	  break;
	}

  return handled;
}


/*****************************************************
/  static Boolean DefaultFormEventHandler (EventType* event)
/
/	 Handles events for default forms (menu forms with
/  just an OK button).
/
/  Returns	true if handled
/
/  EventType* event	  IN	pointer to event to handle
******************************************************/
static Boolean 
DefaultFormEventHandler (EventType* event)
{
  Boolean handled = false;

  switch (event->eType)
	{
	case frmOpenEvent:
	  FrmDrawForm (FrmGetActiveForm ());
	  handled = true;
	  break;
	  
	case ctlSelectEvent:
	  if (event->data.ctlSelect.controlID == rscOKButtonID)
		{
		  if (gameStarted)
			FrmGotoForm (rscGameFormID);
		  else
			FrmGotoForm (rscStartupFormID);
		  handled = true;
		}
	  break;

	default:
	  break;
	}
  return handled;
}


/*****************************************************
/  static UInt32 AppStop (void)
/
/	 Cleans up in preparing to exit the program.
/
/  Returns	0 if no error
******************************************************/
static UInt32
AppStop (void)
{
  //Allow all keys to generate events again
  KeySetMask(keyBitsAll);

  //Close all forms
  FrmCloseAllForms();

  //Cleanup dynamically allocated memory
  CleanupSprites();
  CleanupSpecies();
  CleanupScreen();

  return 0;
}


/*****************************************************
/ static UInt16 InitializeScreen (void)
/
/	Prepares the screen and buffer to start the game.
/
/ Returns	0 if no error
******************************************************/
static UInt16
InitializeScreen (void)
{
  UInt16 error;

  //get screen info
  screenInfo.drawWindow = WinGetDisplayWindow();
  screenInfo.drawBitmap = WinGetBitmap(screenInfo.drawWindow);
  screenInfo.baseAddress = (UInt16*) BmpGetBits(screenInfo.drawBitmap);

  //create the buffer
  buffer.drawWindow = WinCreateOffscreenWindow(160, 160, screenFormat, &error);
  if(error)
	return error;
  buffer.drawBitmap = WinGetBitmap(buffer.drawWindow);
  buffer.baseAddress = (UInt16*) BmpGetBits(buffer.drawBitmap);
  
  //from now on always draw to the buffer
  WinSetDrawWindow(buffer.drawWindow);
  
  return 0;
}


/*****************************************************
/ static void CleanupScreen (void)
/
/	Clears and deletes the buffer
/
/ Returns	None
******************************************************/
static void
CleanupScreen (void)
{

  WinSetDrawWindow(screenInfo.drawWindow);
  WinDeleteWindow(buffer.drawWindow, false);
}

/*****************************************************
/ static void DrawBackground (void)
/
/	Displays the "Get Ready" message and draws the initial
/ tunnel to the screen when the game starts.
/
/ Returns	None
******************************************************/
static void
DrawBackground (void)
{
  double i,j,k;
  UInt16 color;
  WinHandle oldDrawWindow;
  MemHandle getReadyHandle;
  BitmapPtr getReadyPtr;

  //save current draw Window
  oldDrawWindow= WinGetDrawWindow();

  //draw the "get ready message"
  WinSetDrawWindow(screenInfo.drawWindow);
  getReadyHandle = DmGetResource(bitmapRsc, rscGetReadyBmpID);
  getReadyPtr = MemHandleLock(getReadyHandle);
  WinDrawBitmap(getReadyPtr, 32, 67);
  MemPtrUnlock(getReadyPtr);
  DmReleaseResource(getReadyHandle);

  //restore current old Window
  WinSetDrawWindow(oldDrawWindow);

  //The tunnel is drawn in a rather strange way.  First the color for
  //the current position is calculated by taking 0x8000 and dividing
  //it by the square of the distace from the center (0x8000 was picked
  //from trial and error, and I use the square of the distance so I
  //didn't have to use the math library for square roots and it looked
  //fine anyways.)  Then the symmetry of the tunnel is taken
  //advantage of by using this color for all 8 octants of the screen.
  k=0;
  for(i=0; i<80; i++)
	{
	  for(j=k; j<80; j++)
		{
		  color = 0x8000/((79.5 - j) * (79.5 - j) + (79.5 - i) * (79.5 - i));
		  *(screenInfo.baseAddress + 160 * (UInt16)i + (UInt16)j) = color;
		  *(screenInfo.baseAddress + 160 * (UInt16)i + (159 - (UInt16)j)) = color;
		  *(screenInfo.baseAddress + (25440 - 160 * (UInt16)i) + (UInt16)j) = color;
		  *(screenInfo.baseAddress + (25440 - 160 * (UInt16)i) + (159 - (UInt16)j)) = color;
		  *(screenInfo.baseAddress + 160 * (UInt16)j + (UInt16)i) = color;
		  *(screenInfo.baseAddress + 160 * (UInt16)j + (159 - (UInt16)i)) = color;
		  *(screenInfo.baseAddress + (25440 - 160 * (UInt16)j) + (UInt16)i) = color;
		  *(screenInfo.baseAddress + (25440 - 160 * (UInt16)j) + (159 - (UInt16)i)) = color;
		}
	  k++;
	}

  //Since we drew the tunnel to the screen (so the player can watch the
  //nifty effect) we have to copy it into the buffer.
  WinCopyRectangle(screenInfo.drawWindow, buffer.drawWindow, &screenRect, 0, 0, winPaint);
}


/*****************************************************
/ static UInt16 InitializeSprites (void)
/
/	Creates all the sprites and their background
/ windows.
/
/ Returns	0 if no error
******************************************************/
static UInt16
InitializeSprites(void)
{

  UInt16 error;
  Int16 i;

  //set up playerSprite  
  playerSprite.depth = 16;
  playerSprite.track = 0;
  playerSprite.background = WinCreateOffscreenWindow(SpriteDimensions[NumSpriteSizes - 1], 
												   SpriteDimensions[NumSpriteSizes - 1], 
												   screenFormat, &error);
  if(error)
	return error;

  //Initialize Sprites
  for(i=0; i<MaxNumSprites; i++)
	{
	  spriteList[i].exists = false;
	  spriteList[i].background = WinCreateOffscreenWindow(SpriteDimensions[NumSpriteSizes - 1], 
												   SpriteDimensions[NumSpriteSizes - 1], 
												   screenFormat, &error);
	  if(error)
		return error;
	}
  return 0;
}


/*****************************************************
/ static void CleanupSprites (void)
/
/	Removes all the sprites and frees their background
/ windows.
/
/ Returns	None
******************************************************/
static void
CleanupSprites(void)
{
  Int16 i;

  WinDeleteWindow(playerSprite.background, false);
  for(i=0; i<MaxNumSprites; i++)
	{
	  WinDeleteWindow(spriteList[i].background, false);
	}
}


/*****************************************************
/ static UInt16 InitializePositions (void)
/
/	Clears all the spritePositions
/
/ Returns	0 if no error
******************************************************/
static UInt16
InitializePositions(void)
{
  Int16 i,j;

  //Initialize spritePositions
  for(i=0; i<TrackDepth; i++)
	for(j=0; j<NumTracks; j++)
	  spritePositions[i][j] = -1;

  return 0;
}


/*****************************************************
/ static UInt16 InitializeSpecies (void)
/
/	Opens and prepares all the bitmaps for the sprites
/ in the speciesBitmapArray
/
/ Returns	0 if no error
******************************************************/
static UInt16
InitializeSpecies (void)
{
  Int16 i, j;
  MemHandle tempHandle;
  BitmapPtr tempBitmapPtr;

  for(i=0; i<NumSpriteSizes; i++)
	{
	  for(j=0; j<HalfNumTracks; j++)
		{
		  if (i == NumSpriteSizes - 1)
			{
			  tempHandle = DmGetResource(bitmapRsc, rscPlayerBaseBmpID + j);
			  if (tempHandle == NULL)
				return DmGetLastErr();
			  tempBitmapPtr = MemHandleLock(tempHandle);
			  if (tempBitmapPtr == NULL)
				return 1;
			  speciesBitmapArray[Player][j][i] = tempBitmapPtr;
			}
		  else
			speciesBitmapArray[Player][j][i] = NULL;
		}
	}

  for(i=0; i<NumSpriteSizes; i++)
	{
	  for(j=0; j<HalfNumTracks; j++)
		{
		  tempHandle = DmGetResource(bitmapRsc, rscSmileyBaseBmpID + i*HalfNumTracks + j);
		  if (tempHandle == NULL)
			return DmGetLastErr();
		  tempBitmapPtr = MemHandleLock(tempHandle);
		  if (tempBitmapPtr == NULL)
			return 1;
		  speciesBitmapArray[Smiley][j][i] = tempBitmapPtr;
		}
	}

  for(i=0; i<NumSpriteSizes; i++)
	{
	  for(j=0; j<HalfNumTracks; j++)
		{
		  tempHandle = DmGetResource(bitmapRsc, rscBulletBaseBmpID + i*HalfNumTracks + j);
		  if (tempHandle == NULL)
			return DmGetLastErr();
		  tempBitmapPtr = MemHandleLock(tempHandle);
		  if (tempBitmapPtr == NULL)
			return 1;
		  speciesBitmapArray[Bullet][j][i] = tempBitmapPtr;
		}
	}

  for(i=0; i<NumSpriteSizes; i++)
	{
	  for(j=0; j<HalfNumTracks; j++)
		{
		  tempHandle = DmGetResource(bitmapRsc, rscFlipBaseBmpID + i*HalfNumTracks + j);
		  if (tempHandle == NULL)
			return DmGetLastErr();
		  tempBitmapPtr = MemHandleLock(tempHandle);
		  if (tempBitmapPtr == NULL)
			return 1;
		  speciesBitmapArray[Flip][j][i] = tempBitmapPtr;
		}
	}

  for(i=0; i<NumSpriteSizes; i++)
	{
	  for(j=0; j<HalfNumTracks; j++)
		{
		  tempHandle = DmGetResource(bitmapRsc, rscRingBaseBmpID + i*HalfNumTracks + j);
		  if (tempHandle == NULL)
			return DmGetLastErr();
		  tempBitmapPtr = MemHandleLock(tempHandle);
		  if (tempBitmapPtr == NULL)
			return 1;
		  speciesBitmapArray[Ring][j][i] = tempBitmapPtr;
		}
	}
  return 0;
}


/*****************************************************
/ static void CleanupSpecies (void)
/
/	Unlocks all the handles handles and frees the
/ resources used by speciesBitmapArray.
/
/ Returns	None
******************************************************/
static void
CleanupSpecies(void)
{
  MemHandle tempHandle;
  Int16 i,j;

  for(i=0; i<NumSpriteSizes; i++)
	{
	  

	  for(j=0; j<HalfNumTracks; j++)
		{
		  if (i == NumSpriteSizes - 1)
			{
			  tempHandle = MemPtrRecoverHandle(speciesBitmapArray[Player][j][i]);
			  MemPtrUnlock(speciesBitmapArray[Player][j][i]);
			  DmReleaseResource(tempHandle);
			}
		  tempHandle = MemPtrRecoverHandle(speciesBitmapArray[Smiley][j][i]);
		  MemPtrUnlock(speciesBitmapArray[Smiley][j][i]);
		  DmReleaseResource(tempHandle);

		  tempHandle = MemPtrRecoverHandle(speciesBitmapArray[Bullet][j][i]);
		  MemPtrUnlock(speciesBitmapArray[Bullet][j][i]);
		  DmReleaseResource(tempHandle);

		  tempHandle = MemPtrRecoverHandle(speciesBitmapArray[Flip][j][i]);
		  MemPtrUnlock(speciesBitmapArray[Flip][j][i]);
		  DmReleaseResource(tempHandle);

		  tempHandle = MemPtrRecoverHandle(speciesBitmapArray[Flip][j][i]);
		  MemPtrUnlock(speciesBitmapArray[Ring][j][i]);
		  DmReleaseResource(tempHandle);
		}
	}
}


/*****************************************************
/ static SpriteType* CreateSprite (UInt8 species, UInt8 track, UInt8 depth)
/
/	Creates a new sprite of the given species at the
/ given location and puts it in the spriteList.
/
/ Returns	pointer to the new sprite or NULL if that
/			position is already full
/
/ UInt8	species		IN	  species of new sprite
/ UInt8 track		IN	  initial track of new sprite
/ UInt8 depth		IN	  initial depth of new sprite
******************************************************/
INLINE static SpriteType*
CreateSprite(UInt8 species, UInt8 track, UInt8 depth)
{
  static UInt16 nextIndex = 0;
  UInt16 thisIndex;
  UInt16 count = MaxNumSprites;

  thisIndex = nextIndex;
  if(spritePositions[depth][track] == -1)
	{
	  spriteList[nextIndex].species = species;
	  spriteList[nextIndex].track = track;
	  spriteList[nextIndex].depth = depth;
	  spriteList[nextIndex].exists = true;
	  spriteList[nextIndex].shootable = ShootableSpecies[species];
	  spritePositions[depth][track] = nextIndex;
	  nextIndex ++;
	  nextIndex &= ModMaxNumSpritesMask;
	  //try to find an open spot in the spriteList
	  while(spriteList[nextIndex].exists && count)
		{
		  nextIndex++;
		  nextIndex &= ModMaxNumSpritesMask;
		  count--;
		}
	  if(!count)
		return NULL;
	  return &spriteList[thisIndex];
	}
  else
	return NULL;
}


/*****************************************************
/ static void DeleteSprite (UInt16 index)
/
/	Deletes the sprite at the given position in spriteList
/ and that pointer is set to NULL.
/
/ Returns	None
/
/ UInt16  index	IN	 index in spriteList of sprite to delete
******************************************************/
INLINE static void
DeleteSprite(UInt16 index)
{
  if(spriteList[index].exists)
	{
	  spritePositions[spriteList[index].depth][spriteList[index].track] = -1;
	  spriteList[index].exists = false;
	}
}


/*****************************************************
/ static void DeleteAllSprites (void)
/
/	Deletes all the sprites in spriteList
/
/ Returns	None
******************************************************/
INLINE static void
DeleteAllSprites(void)
{
  UInt16 i;

  for(i=0; i<MaxNumSprites; i++)
	{
	  if(spriteList[i].exists)
		{
		  DeleteSprite(i);
		}
	}
}


/*****************************************************
/ static void PlaceSprite (SpriteType* toPlace)
/
/	Places the sprite into the buffer at the location given
/ by the sprite's positionRect.  Stores the background it
/ is being put over in the sprite's background member.
/
/ Returns	None
/
/ SpriteType*		toPlace	IN/OUT	pointer to sprite to place
******************************************************/
INLINE static void 
PlaceSprite(SpriteType* toPlace)
{
  RectangleType sizeRect, positionRect;

  sizeRect.topLeft.x = sizeRect.topLeft.y = 0;
  positionRect.topLeft.x = TrackPositions[toPlace->depth][toPlace->track].x;
  positionRect.topLeft.y = TrackPositions[toPlace->depth][toPlace->track].y;
  positionRect.extent.x = 
	positionRect.extent.y = 
	  sizeRect.extent.x = 
		sizeRect.extent.y = 
		  SpriteDimensions[DepthToSize[toPlace->depth]];

  WinCopyRectangle(buffer.drawWindow, toPlace->background, &positionRect, 0, 0, winPaint);
  
  CopyBitmapToWindow(buffer.baseAddress,
	  BmpGetBits(speciesBitmapArray[toPlace->species][toPlace->track & ModHalfNumTracksMask][DepthToSize[toPlace->depth]]),
	  &positionRect, toPlace->track & (~ModHalfNumTracksMask));  
}


/*****************************************************
/ static void PlaceAllSprites (void)
/
/	Places all the sprites in spriteList onto the buffer
/
/ Returns	None
******************************************************/
INLINE static void
PlaceAllSprites(void)
{
  UInt16 i,j;
  for(i=0; i<TrackDepth; i++)
	{
	  for(j=0; j<NumTracks; j++)
		{
		  if(spritePositions[i][j] != -1)
			{
			  PlaceSprite(&spriteList[spritePositions[i][j]]);
			}
		}
	}
}


/*****************************************************
/ static void RemoveSprite (SpriteType* toRemove)
/
/	Places the sprite into the buffer at the location given
/ by the sprite's positionRect.  Stores the background it
/ is being put over in the sprite's backgroung member.
/
/ Returns	None
/
/ SpriteType*		toPlace	IN/OUT	pointer to sprite to place
******************************************************/
INLINE static void 
RemoveSprite(SpriteType* toRemove)
{
  RectangleType sizeRect;
  sizeRect.topLeft.x = sizeRect.topLeft.y = 0;
  sizeRect.extent.x = sizeRect.extent.y = SpriteDimensions[DepthToSize[toRemove->depth]];

  WinCopyRectangle(toRemove->background, buffer.drawWindow, &sizeRect,
			  TrackPositions[toRemove->depth][toRemove->track].x, 
			  TrackPositions[toRemove->depth][toRemove->track].y, winPaint);
}


/*****************************************************
/ static void RemoveAllSprites (void)
/
/	Removes all the sprites from the target buffer.
/
/ Returns	None
******************************************************/
INLINE static void
RemoveAllSprites(void)
{
  Int16 i,j;

  for(i=TrackDepth - 1; i>=0; i--)
	{
	  for(j=NumTracks - 1; j>=0; j--)
		{
		  if(spritePositions[i][j] != -1)
			{
			  RemoveSprite(&spriteList[spritePositions[i][j]]);
			}
		}
	}
}


/*****************************************************
/ static void MoveSprites (void)
/
/	Moves all the sprites except playerSprite in or out
/ by one and deletes those that run off the depths.
/
/ Notes: Assumes CheckForShots has already been called
/
/ Returns	None
******************************************************/
INLINE static void
MoveSprites (void)
{
  Int16 i = TrackDepth - 1;
  Int16 j;

  //Handle sprites moving out
  for(i=TrackDepth-1; i>=0; i--)
	{
	  for(j=0; j<NumTracks; j++)
		{
		  if(spritePositions[i][j] != -1 && spriteList[spritePositions[i][j]].species != Bullet)
			{
			  if(i != TrackDepth - 1)
				{
				  //move sprite out by one
				  spritePositions[i+1][j] = spritePositions[i][j];
				  spriteList[spritePositions[i][j]].depth++;
				  spritePositions[i][j] = -1;
				}
			  else
				{
				  if(spriteList[spritePositions[i][j]].species == Smiley)
					{
					  score--;
					  SndPlaySystemSound(sndStartUp);
					}
				  //delete if at outside depth
				  DeleteSprite(spritePositions[i][j]);
				}
			}
		}
	}
  for(i=0; i<TrackDepth; i++)
	{
	  for(j=0; j<NumTracks; j++)
		{
		  if(spritePositions[i][j] != -1 && spriteList[spritePositions[i][j]].species == Bullet)
			{
			  if(i)
				{
				  //move sprite in by one
				  spritePositions[i-1][j] = spritePositions[i][j];
				  spriteList[spritePositions[i][j]].depth--;
				  spritePositions[i][j] = -1;
				}
			  else
				{
				  //delete if at inside depth
				  DeleteSprite(spritePositions[i][j]);
				}
			}
		}
	}
}



/*****************************************************
/ static void HandleKeys (void)
/
/	Does key polling and handles necessary actions for
/ any AllowedKeys.
/
/ Returns	None
******************************************************/
INLINE static void
HandleKeys(void)
{
  UInt16 hardKeyState;

  hardKeyState = KeyCurrentState();
  if(hardKeyState & ScoreKey)
	{
	  FrmGotoForm (rscScoreFormID);
	}

  if(hardKeyState & ShootKey)
	{
	  if(spritePositions[TrackDepth - 1][playerSprite.track] == -1)
		CreateSprite(Bullet, playerSprite.track, TrackDepth - 1);
	  else
		{
		  SpriteShot(spritePositions[TrackDepth - 1][playerSprite.track]);
		}
	}
  if(!((hardKeyState & (AllowedKeys | keyBitPageUp | keyBitPageDown))
	   ^ (AllowedKeys | keyBitPageUp | keyBitPageDown)))
	forward = !forward;
  if((hardKeyState & MoveLeftKey) && !(hardKeyState & MoveRightKey))
	{
	  playerSprite.track += NumTracks - 1;
	  playerSprite.track &= ModNumTracksMask;
	}
  else
	{
	  if((hardKeyState & MoveRightKey) && !(hardKeyState & MoveLeftKey))
		{
		  playerSprite.track++;
		  playerSprite.track &= ModNumTracksMask;
		}
	}
}


/*****************************************************
/ static void CheckForCollisions (void)
/
/	Checks for and handles any collisions with the 
/ playerSprite.
/
/ Returns	None
******************************************************/
INLINE static void
CheckForCollisions(void)
{
  if(spritePositions[TrackDepth-1][playerSprite.track] != -1)
	{
	  PlayerHit(spritePositions[TrackDepth-1][playerSprite.track]);
	}
}


/*****************************************************
/ static void CheckForShots (void)
/
/	Checks for and handles any shots hitting a sprite. 
/
/ Returns	None
******************************************************/
INLINE static void
CheckForShots(void)
{
  UInt16 i;
  UInt16 tDepth;
  UInt16 tTrack;

  //check all sprites
  for(i=0; i<MaxNumSprites; i++)
	{

	  //if the sprite doesn't exist or is a bullet then keep going
	  if(!spriteList[i].exists || spriteList[i].species == Bullet)
		continue;

	  tDepth = spriteList[i].depth;
	  tTrack = spriteList[i].track;

	  //Check for bullet immediately above sprite
	  if(tDepth < TrackDepth - 1 && spritePositions[tDepth+1][tTrack] != -1)
		{
		  if(spriteList[spritePositions[tDepth+1][tTrack]].species == Bullet)
			{
			  //delete the bullet
			  DeleteSprite(spritePositions[tDepth+1][tTrack]);
			  SpriteShot(i);
			  if(spriteList[i].shootable)
				continue;
			}
		  else
			//can't die if another sprite is in front
			continue;
		}
	  //check for bullets two above sprite
	  if(tDepth < TrackDepth - 2 && spritePositions[tDepth+2][tTrack] != -1)
		{
		  if(spriteList[spritePositions[tDepth+2][tTrack]].species == Bullet)
			{
			  //delete the bullet
			  DeleteSprite(spritePositions[tDepth+2][tTrack]);
			  SpriteShot(i);
			}
		}
	}
}


/*****************************************************
/ static void SpriteShot (UInt16 index)
/
/	Handles what happens when a sprite is hit by a bullet.
/
/ Returns	None
/
/ Int16  index	IN	Index of sprite the bullet hit
******************************************************/
INLINE static void
SpriteShot(UInt16 index)
{
  if(spriteList[index].shootable)
	{
	  if(spriteList[index].species == Flip)
		{
		  SndPlaySystemSound(sndStartUp);
		  score -= 2;
		}
	  else if(spriteList[index].species == Smiley)
		{
		  SndPlaySystemSound(sndClick);
		  score++;
		  levelPoints++;
		}
	  DeleteSprite(index);
	}
}


/*****************************************************
/ static void PlayerHit (UInt16 species)
/
/	Handles what happens when the player is hit by
/ another object.	
/
/ Returns	None
/
/ Int16  index	IN	Index of sprite the playerSprite hit
******************************************************/
INLINE static void
PlayerHit (Int16 index)
{
  if(spriteList[index].species == Bullet)
	return;

  if(spriteList[index].species == Flip)
	{
	  SndPlaySystemSound(sndClick);
	  score++;
	  levelPoints++;
	  DeleteSprite(index);
	}
  else
	{
	  DisplayScreen();
	  Death();
	} 
}


/*****************************************************
/ static UInt32 GetTimeUntilNextInterval (void)
/
/	Calculates the time in ticks until the next game
/ interval
/
/ Returns	Time in ticks until the next interval
******************************************************/
INLINE static UInt32
GetTimeUntilNextInterval(void)
{
  Int32 time;
  time = nextIntervalTime - TimGetTicks();
  if(time < 0)
	time = 0;
  return (UInt32)time;
}


/*****************************************************
/ static void DisplayScreen (void)
/
/	Draws the sprites, copies the buffer to the screen,
/ removes the sprites, and then moves one step down
/ the tunnel.
/
/ Returns	Time in ticks until the next interval
******************************************************/
INLINE static void
DisplayScreen (void)
{
  PlaceAllSprites();
  PlaceSprite(&playerSprite);
  WinCopyRectangle(buffer.drawWindow, screenInfo.drawWindow, &screenRect, 0, 0, winPaint);
  RemoveSprite(&playerSprite);
  RemoveAllSprites();

  if(forward)
	IncrementBuffer((UInt32*) buffer.baseAddress);
  else
	DecrementBuffer((UInt32*) buffer.baseAddress);
	
}


/*****************************************************
/ static void CopyBitmapToWindow(UInt16* winBaseAddress,
/								 UInt16* bmpBaseAddress,
/								 RectangleType* position,
/								 Boolean rotate)
/
/	Copies a bitmap to a window at the given position.
/ It can also rotate the image 180 degrees as it copies
/ it (no loss in speed).
/
/ Notes:  This function assumes a lot in order to make
/ this run fast:
/ 1. The screen is 160 by 160.
/ 2. The entire rectangle is inside of the window.
/ 3. The bitmaps are uncompressed.
/ 4. Everything is 16-bit color.
/ 5. Black (0x0000) is transparent.
/
/ Returns	None
/
/ UInt16* winBaseAddress  -	Address of window's data
/ UInt16* bmpBaseAddress  -	Address of bitmap's data	
/ RectangleType* position -	Position in window to put bitmap
/ Boolean rotate		  -	True to rotate image 180 degrees
/
******************************************************/
INLINE static void
CopyBitmapToWindow(UInt16* winBaseAddress,
				   UInt16* bmpBaseAddress,
				   RectangleType* position,
				   Boolean rotate)
{
  UInt16 winAdd = 160 - position->extent.x;
  UInt16* endAddress = bmpBaseAddress + position->extent.x * position->extent.y - 1;
  UInt16* i;
  
  winBaseAddress += position->topLeft.x + 160 * position->topLeft.y;

  if(rotate)
	{
	  for(;endAddress>=bmpBaseAddress; winBaseAddress += winAdd)
		{
		  i = endAddress - position->extent.x;
		  for(;endAddress > i; endAddress--)
			{
			  if(*endAddress)
				*winBaseAddress = *endAddress;
			  winBaseAddress++;
			}
		}
	}
  else
	{	  
	  for(;bmpBaseAddress<=endAddress; winBaseAddress += winAdd)
		{
		  i = bmpBaseAddress + position->extent.x;
		  for(;bmpBaseAddress < i; bmpBaseAddress++)
			{
			  if(*bmpBaseAddress)
				*winBaseAddress = *bmpBaseAddress;
			  winBaseAddress++;
			}
		}
	}
}


/*****************************************************
/ static void Restart (void)
/
/	Resets the game state and starts over
/
/ Returns	None
******************************************************/
static void Restart (void)
{
  newGame = false;
  score = 0;
  DeleteAllSprites();
  InitializePositions();
  playerSprite.track = 0;
  score = 0;
  level = 0;
  levelPoints = 0;
  DrawBackground();
  gameRunning = true;
  forward = true;
}


/*****************************************************
/ static void UnleashSprites (void)
/
/	Creates the next group of sprites based on the
/ current level, and updates the level when necessary.
/
/ Returns	None
******************************************************/
static void 
UnleashSprites (void)
{
  static UInt16 stepsCounter = 0;
  static UInt16 stepsPerRelease = 16;
  static UInt16 spritesPerDepth = 1;
  Int16 i;
  
  if (!level)
	{
	  stepsPerRelease = LevelSteps[level];
	  spritesPerDepth = LevelSprites[level];
	}
  if (levelPoints >= BasePointsPerLevel + level && level < MaxLevel)
	{
	  //increase the level
	  level++;
	  if (level == 30)
		forward = false;
	  stepsPerRelease = LevelSteps[level];
	  spritesPerDepth = LevelSprites[level];
	  levelPoints = 0;
	}

  stepsCounter++;
  stepsCounter %= stepsPerRelease;

  if (!stepsCounter)
	for (i=0; i<spritesPerDepth;)
	  if (CreateSprite((SysRandom(0) % 3) + 2,SysRandom(0) & ModNumTracksMask,0))
		i++;

}


/*****************************************************
/ static void CheckScore (void)
/
/	Handles any score-specific events.  Right now
/ just kills you if you have less than MinNumPoints
/
/ Returns	None
******************************************************/
INLINE static void
CheckScore (void)
{
  if (score < MinNumPoints)
	Death();
}


/*****************************************************
/ static void Death (void)
/
/	Throws up the death alert box and handles the
/ button pressed (restarts or exits).
/
/ Returns	None
******************************************************/
INLINE static void 
Death (void)
{  
  Char scoreStr[32];
  Char levelStr[32];
  
  gameRunning = false;
  StrIToA(scoreStr, score);
  StrIToA(levelStr, level);
  if (FrmCustomAlert(rscDeathAlertID, scoreStr, levelStr, NULL) != 0)
	exitApp = true;
  else
	{
	  newGame = true;
	  FrmGotoForm (rscGameFormID);
	}
}


/*****************************************************
/ static void IncrementBuffer (UInt32* baseAddress)
/
/	Increments each pair of pixels in the buffer by
/ TwoWordTunnelIncrement
/
/ Assumes the buffer is 16 bit, 160x160
/
/ Returns	None
/
/ UInt32*	baseAddress	IN	pointer to the buffer's data
******************************************************/
static void
IncrementBuffer(UInt32* baseAddress)
{
  UInt32* temp;
  temp = baseAddress + 12700;
  for(;baseAddress < temp; baseAddress += 160)
	{
	  (*(baseAddress)) += TwoWordTunnelIncrement;
	  (*(baseAddress+1)) += TwoWordTunnelIncrement;
	  (*(baseAddress+2)) += TwoWordTunnelIncrement;
	  (*(baseAddress+3)) += TwoWordTunnelIncrement;
	  (*(baseAddress+4)) += TwoWordTunnelIncrement;
	  (*(baseAddress+5)) += TwoWordTunnelIncrement;
	  (*(baseAddress+6)) += TwoWordTunnelIncrement;
	  (*(baseAddress+7)) += TwoWordTunnelIncrement;
	  (*(baseAddress+8)) += TwoWordTunnelIncrement;
	  (*(baseAddress+9)) += TwoWordTunnelIncrement;
	  (*(baseAddress+10)) += TwoWordTunnelIncrement;
	  (*(baseAddress+11)) += TwoWordTunnelIncrement;
	  (*(baseAddress+12)) += TwoWordTunnelIncrement;
	  (*(baseAddress+13)) += TwoWordTunnelIncrement;
	  (*(baseAddress+14)) += TwoWordTunnelIncrement;
	  (*(baseAddress+15)) += TwoWordTunnelIncrement;
	  (*(baseAddress+16)) += TwoWordTunnelIncrement;
	  (*(baseAddress+17)) += TwoWordTunnelIncrement;
	  (*(baseAddress+18)) += TwoWordTunnelIncrement;
	  (*(baseAddress+19)) += TwoWordTunnelIncrement;
	  (*(baseAddress+20)) += TwoWordTunnelIncrement;
	  (*(baseAddress+21)) += TwoWordTunnelIncrement;
	  (*(baseAddress+22)) += TwoWordTunnelIncrement;
	  (*(baseAddress+23)) += TwoWordTunnelIncrement;
	  (*(baseAddress+24)) += TwoWordTunnelIncrement;
	  (*(baseAddress+25)) += TwoWordTunnelIncrement;
	  (*(baseAddress+26)) += TwoWordTunnelIncrement;
	  (*(baseAddress+27)) += TwoWordTunnelIncrement;
	  (*(baseAddress+28)) += TwoWordTunnelIncrement;
	  (*(baseAddress+29)) += TwoWordTunnelIncrement;
	  (*(baseAddress+30)) += TwoWordTunnelIncrement;
	  (*(baseAddress+31)) += TwoWordTunnelIncrement;
	  (*(baseAddress+32)) += TwoWordTunnelIncrement;
	  (*(baseAddress+33)) += TwoWordTunnelIncrement;
	  (*(baseAddress+34)) += TwoWordTunnelIncrement;
	  (*(baseAddress+35)) += TwoWordTunnelIncrement;
	  (*(baseAddress+36)) += TwoWordTunnelIncrement;
	  (*(baseAddress+37)) += TwoWordTunnelIncrement;
	  (*(baseAddress+38)) += TwoWordTunnelIncrement;
	  (*(baseAddress+39)) += TwoWordTunnelIncrement;
	  (*(baseAddress+40)) += TwoWordTunnelIncrement;
	  (*(baseAddress+41)) += TwoWordTunnelIncrement;
	  (*(baseAddress+42)) += TwoWordTunnelIncrement;
	  (*(baseAddress+43)) += TwoWordTunnelIncrement;
	  (*(baseAddress+44)) += TwoWordTunnelIncrement;
	  (*(baseAddress+45)) += TwoWordTunnelIncrement;
	  (*(baseAddress+46)) += TwoWordTunnelIncrement;
	  (*(baseAddress+47)) += TwoWordTunnelIncrement;
	  (*(baseAddress+48)) += TwoWordTunnelIncrement;
	  (*(baseAddress+49)) += TwoWordTunnelIncrement;
	  (*(baseAddress+50)) += TwoWordTunnelIncrement;
	  (*(baseAddress+51)) += TwoWordTunnelIncrement;
	  (*(baseAddress+52)) += TwoWordTunnelIncrement;
	  (*(baseAddress+53)) += TwoWordTunnelIncrement;
	  (*(baseAddress+54)) += TwoWordTunnelIncrement;
	  (*(baseAddress+55)) += TwoWordTunnelIncrement;
	  (*(baseAddress+56)) += TwoWordTunnelIncrement;
	  (*(baseAddress+57)) += TwoWordTunnelIncrement;
	  (*(baseAddress+58)) += TwoWordTunnelIncrement;
	  (*(baseAddress+59)) += TwoWordTunnelIncrement;
	  (*(baseAddress+60)) += TwoWordTunnelIncrement;
	  (*(baseAddress+61)) += TwoWordTunnelIncrement;
	  (*(baseAddress+62)) += TwoWordTunnelIncrement;
	  (*(baseAddress+63)) += TwoWordTunnelIncrement;
	  (*(baseAddress+64)) += TwoWordTunnelIncrement;
	  (*(baseAddress+65)) += TwoWordTunnelIncrement;
	  (*(baseAddress+66)) += TwoWordTunnelIncrement;
	  (*(baseAddress+67)) += TwoWordTunnelIncrement;
	  (*(baseAddress+68)) += TwoWordTunnelIncrement;
	  (*(baseAddress+69)) += TwoWordTunnelIncrement;
	  (*(baseAddress+70)) += TwoWordTunnelIncrement;
	  (*(baseAddress+71)) += TwoWordTunnelIncrement;
	  (*(baseAddress+72)) += TwoWordTunnelIncrement;
	  (*(baseAddress+73)) += TwoWordTunnelIncrement;
	  (*(baseAddress+74)) += TwoWordTunnelIncrement;
	  (*(baseAddress+75)) += TwoWordTunnelIncrement;
	  (*(baseAddress+76)) += TwoWordTunnelIncrement;
	  (*(baseAddress+77)) += TwoWordTunnelIncrement;
	  (*(baseAddress+78)) += TwoWordTunnelIncrement;
	  (*(baseAddress+79)) += TwoWordTunnelIncrement;
	  (*(baseAddress+80)) += TwoWordTunnelIncrement;
	  (*(baseAddress+81)) += TwoWordTunnelIncrement;
	  (*(baseAddress+82)) += TwoWordTunnelIncrement;
	  (*(baseAddress+83)) += TwoWordTunnelIncrement;
	  (*(baseAddress+84)) += TwoWordTunnelIncrement;
	  (*(baseAddress+85)) += TwoWordTunnelIncrement;
	  (*(baseAddress+86)) += TwoWordTunnelIncrement;
	  (*(baseAddress+87)) += TwoWordTunnelIncrement;
	  (*(baseAddress+88)) += TwoWordTunnelIncrement;
	  (*(baseAddress+89)) += TwoWordTunnelIncrement;
	  (*(baseAddress+90)) += TwoWordTunnelIncrement;
	  (*(baseAddress+91)) += TwoWordTunnelIncrement;
	  (*(baseAddress+92)) += TwoWordTunnelIncrement;
	  (*(baseAddress+93)) += TwoWordTunnelIncrement;
	  (*(baseAddress+94)) += TwoWordTunnelIncrement;
	  (*(baseAddress+95)) += TwoWordTunnelIncrement;
	  (*(baseAddress+96)) += TwoWordTunnelIncrement;
	  (*(baseAddress+97)) += TwoWordTunnelIncrement;
	  (*(baseAddress+98)) += TwoWordTunnelIncrement;
	  (*(baseAddress+99)) += TwoWordTunnelIncrement;
	  (*(baseAddress+100)) += TwoWordTunnelIncrement;
	  (*(baseAddress+101)) += TwoWordTunnelIncrement;
	  (*(baseAddress+102)) += TwoWordTunnelIncrement;
	  (*(baseAddress+103)) += TwoWordTunnelIncrement;
	  (*(baseAddress+104)) += TwoWordTunnelIncrement;
	  (*(baseAddress+105)) += TwoWordTunnelIncrement;
	  (*(baseAddress+106)) += TwoWordTunnelIncrement;
	  (*(baseAddress+107)) += TwoWordTunnelIncrement;
	  (*(baseAddress+108)) += TwoWordTunnelIncrement;
	  (*(baseAddress+109)) += TwoWordTunnelIncrement;
	  (*(baseAddress+110)) += TwoWordTunnelIncrement;
	  (*(baseAddress+111)) += TwoWordTunnelIncrement;
	  (*(baseAddress+112)) += TwoWordTunnelIncrement;
	  (*(baseAddress+113)) += TwoWordTunnelIncrement;
	  (*(baseAddress+114)) += TwoWordTunnelIncrement;
	  (*(baseAddress+115)) += TwoWordTunnelIncrement;
	  (*(baseAddress+116)) += TwoWordTunnelIncrement;
	  (*(baseAddress+117)) += TwoWordTunnelIncrement;
	  (*(baseAddress+118)) += TwoWordTunnelIncrement;
	  (*(baseAddress+119)) += TwoWordTunnelIncrement;
	  (*(baseAddress+120)) += TwoWordTunnelIncrement;
	  (*(baseAddress+121)) += TwoWordTunnelIncrement;
	  (*(baseAddress+122)) += TwoWordTunnelIncrement;
	  (*(baseAddress+123)) += TwoWordTunnelIncrement;
	  (*(baseAddress+124)) += TwoWordTunnelIncrement;
	  (*(baseAddress+125)) += TwoWordTunnelIncrement;
	  (*(baseAddress+126)) += TwoWordTunnelIncrement;
	  (*(baseAddress+127)) += TwoWordTunnelIncrement;
	  (*(baseAddress+128)) += TwoWordTunnelIncrement;
	  (*(baseAddress+129)) += TwoWordTunnelIncrement;
	  (*(baseAddress+130)) += TwoWordTunnelIncrement;
	  (*(baseAddress+131)) += TwoWordTunnelIncrement;
	  (*(baseAddress+132)) += TwoWordTunnelIncrement;
	  (*(baseAddress+133)) += TwoWordTunnelIncrement;
	  (*(baseAddress+134)) += TwoWordTunnelIncrement;
	  (*(baseAddress+135)) += TwoWordTunnelIncrement;
	  (*(baseAddress+136)) += TwoWordTunnelIncrement;
	  (*(baseAddress+137)) += TwoWordTunnelIncrement;
	  (*(baseAddress+138)) += TwoWordTunnelIncrement;
	  (*(baseAddress+139)) += TwoWordTunnelIncrement;
	  (*(baseAddress+140)) += TwoWordTunnelIncrement;
	  (*(baseAddress+141)) += TwoWordTunnelIncrement;
	  (*(baseAddress+142)) += TwoWordTunnelIncrement;
	  (*(baseAddress+143)) += TwoWordTunnelIncrement;
	  (*(baseAddress+144)) += TwoWordTunnelIncrement;
	  (*(baseAddress+145)) += TwoWordTunnelIncrement;
	  (*(baseAddress+146)) += TwoWordTunnelIncrement;
	  (*(baseAddress+147)) += TwoWordTunnelIncrement;
	  (*(baseAddress+148)) += TwoWordTunnelIncrement;
	  (*(baseAddress+149)) += TwoWordTunnelIncrement;
	  (*(baseAddress+150)) += TwoWordTunnelIncrement;
	  (*(baseAddress+151)) += TwoWordTunnelIncrement;
	  (*(baseAddress+152)) += TwoWordTunnelIncrement;
	  (*(baseAddress+153)) += TwoWordTunnelIncrement;
	  (*(baseAddress+154)) += TwoWordTunnelIncrement;
	  (*(baseAddress+155)) += TwoWordTunnelIncrement;
	  (*(baseAddress+156)) += TwoWordTunnelIncrement;
	  (*(baseAddress+157)) += TwoWordTunnelIncrement;
	  (*(baseAddress+158)) += TwoWordTunnelIncrement;
	  (*(baseAddress+159)) += TwoWordTunnelIncrement;
	}
}


/*****************************************************
/ static void DecrementBuffer (UInt32* baseAddress)
/
/	Decrements each pair of pixels in the buffer by
/ TwoWordTunnelIncrement
/
/ Assumes the buffer is 16 bit, 160x160
/
/ Returns	None
/
/ UInt32*	baseAddress	IN	pointer to the buffer's data
******************************************************/
static void
DecrementBuffer(UInt32* baseAddress)
{
  UInt32* temp;
  temp = baseAddress + 12700;
  for(;baseAddress < temp; baseAddress += 160)
	{
	  (*(baseAddress)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+1)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+2)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+3)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+4)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+5)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+6)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+7)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+8)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+9)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+10)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+11)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+12)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+13)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+14)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+15)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+16)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+17)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+18)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+19)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+20)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+21)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+22)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+23)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+24)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+25)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+26)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+27)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+28)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+29)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+30)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+31)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+32)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+33)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+34)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+35)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+36)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+37)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+38)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+39)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+40)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+41)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+42)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+43)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+44)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+45)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+46)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+47)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+48)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+49)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+50)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+51)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+52)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+53)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+54)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+55)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+56)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+57)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+58)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+59)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+60)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+61)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+62)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+63)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+64)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+65)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+66)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+67)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+68)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+69)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+70)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+71)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+72)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+73)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+74)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+75)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+76)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+77)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+78)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+79)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+80)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+81)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+82)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+83)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+84)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+85)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+86)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+87)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+88)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+89)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+90)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+91)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+92)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+93)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+94)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+95)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+96)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+97)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+98)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+99)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+100)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+101)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+102)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+103)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+104)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+105)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+106)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+107)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+108)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+109)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+110)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+111)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+112)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+113)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+114)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+115)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+116)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+117)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+118)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+119)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+120)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+121)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+122)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+123)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+124)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+125)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+126)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+127)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+128)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+129)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+130)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+131)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+132)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+133)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+134)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+135)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+136)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+137)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+138)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+139)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+140)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+141)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+142)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+143)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+144)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+145)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+146)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+147)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+148)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+149)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+150)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+151)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+152)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+153)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+154)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+155)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+156)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+157)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+158)) -= TwoWordTunnelIncrement;
	  (*(baseAddress+159)) -= TwoWordTunnelIncrement;
	}
}
