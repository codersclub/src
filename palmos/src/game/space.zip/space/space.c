/*
 * space.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <KeyMgr.h>
#include <System/SysEvtMgr.h>

#include "win2.h"

#include "rsc.h"
#include "space.h"
#include "3d.h"
#include "2d.h"
#include "objects.h"
#include "world.h"
#include "instr.h"
#include "graphics.h"
#include "gui.h"

FormPtr pfrmMain;

#define noHLINETEST
#define noPOLYGONTEST

char game_state=STATE_MAIN;

MAPPED_OBJECT me;  /* player position in 3d game */
MOVEMENT me_move;  /* player movement */

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
  short err;
  EventType e;
  FormType *pfrm;
  Boolean fMainWindowActive;
  Word  ticks_wait;
  long  last_ticks=0;
  DWord hardKeyState;

  if (!cmd) {

    /* do startup stuff */
    if(!open_graphics_db()) {
      FrmCustomAlert(alt_err, "Graphics.pdb not installed!",0,0);
      return 0;
    }

    /* switch to greyscale */
    if (Win2SetGreyscale() != 0) {
      FrmCustomAlert(alt_err, "Out of memory!",0,0);
      return 0;
    }

    /* show main menu */
    gui_show_main_menu();

    /* Mask hardware keys */
    KeySetMask(~(keyBitHard1 | keyBitHard2 | keyBitHard3 | keyBitHard4 | keyBitPageUp | keyBitPageDown));

    /* initialize Timer */
    ticks_wait = SysTicksPerSecond()/50;  /* 20ms/frame */

    while(1) {
      EvtGetEvent(&e, ticks_wait);

      if (Win2PreFilterEvent(&e))
	continue;

      if (SysHandleEvent(&e)) 
	continue;

      if (MenuHandleEvent((void *)0, &e, &err)) 
	continue;
	
      /* formerly in winEnterEvent: */

      /* left greyscale mode? (may happen due to alarm etc) */
      if(!Win2DispGrey()) {
	if (Win2SetGreyscale() != 0) {
	  FrmCustomAlert(alt_err, "Out of memory!",0,0);
	  return 0;
	} else {
	  /* remove alert or whatever (redraw everything) */
	  ;
	}
      }

      switch (e.eType) {

      case penDownEvent:
	gui_handle_pen_down(e.screenX, e.screenY);
	break;

      case penUpEvent:
	gui_handle_pen_up(e.screenX, e.screenY);
	break;

      case appStopEvent:

	Win2SetMono();
	
	close_graphics_db();

	KeySetMask(   keyBitsAll );
	
	return 0;
	
      }

//    start_game();
    
      if(game_state == STATE_3D) {
	/* do some kind of 50Hz timer event */
	//     if(TimGetTicks()>last_ticks) 
	{
	  if(game_state==STATE_3D) {

	    EvtResetAutoOffTimer();   /* don't use auto off */

	    hardKeyState = KeyCurrentState();

	    /* hard key 1 switches between rotation and acceleration */
	    //	  if(hardKeyState&keyBitHard1) {
	    //	    /* acceleration mode */

            if(hardKeyState&keyBitHard1) me_move.forward-=128;
	    if(hardKeyState&keyBitHard2) me_move.forward+=64;

	    if(me_move.forward<0)    me_move.forward=0;
	    if(me_move.forward>6400) me_move.forward=6400;
	    if(me_move.forward!=0)   move_object_me(&me, me_move.forward);

	    //	  } else {
	    /* nod */
	    if(hardKeyState&keyBitPageUp)   me_move.roll_x+=32;
	    else if(me_move.roll_x>0) me_move.roll_x -= 32;
	    if(hardKeyState&keyBitPageDown) me_move.roll_x-=32;
	    else if(me_move.roll_x<0) me_move.roll_x += 32;
	  
	    if(me_move.roll_x> 512) me_move.roll_x =  512;
	    if(me_move.roll_x<-512) me_move.roll_x = -512;
	    if(me_move.roll_x!=0) rotate_object_axis_me(&me, OB_X, me_move.roll_x);

	    /* roll */
	    if(hardKeyState&keyBitHard3) me_move.roll_z+=32;
	    else if(me_move.roll_z>0) me_move.roll_z -= 32;
	    if(hardKeyState&keyBitHard4) me_move.roll_z-=32;
	    else if(me_move.roll_z<0) me_move.roll_z += 32;

	    if(me_move.roll_z> 512) me_move.roll_z =  512;
	    if(me_move.roll_z<-512) me_move.roll_z = -512;
	    if(me_move.roll_z!=0) rotate_object_axis_me(&me, OB_Z, me_move.roll_z);
	    
	    //	  }

	    //       DEBUGF("%d %d %d", 
            //	      (int)(me.pos[OB_X]>>8), (int)(me.pos[OB_Y]>>8), (int)(me.pos[OB_Z]>>8));

	    world_display(&me);
	  }
	  last_ticks=TimGetTicks()+ticks_wait;
	}
      }
    }
  }
  return 0;
}





