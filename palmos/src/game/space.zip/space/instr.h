/*
 * instr.h - drawing of instruments
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __INSTR_H__
#define __INSTR_H__

extern void instr_radar_save(void);
extern void instr_radar_restore(void);
extern void instr_radar_add(int x, int y, int z);

extern void instr_put_int(int x, int y, unsigned int max, unsigned int num, int color);
extern void instr_put_speedometer(int x, int y, int value);

#endif

