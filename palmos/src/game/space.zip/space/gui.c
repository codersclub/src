/*
 * gui.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include <Pilot.h>

#include "space.h"
#include "objects.h"
#include "world.h"
#include "instr.h"
#include "graphics.h"
#include "2d.h"
#include "win2.h"
#include "gui.h"

#define BUT_DISABLED 1
#define BUT_FAT      2

struct gui_button {
  unsigned char x, y, width, flags, id;
  char *text;
};

/* main menu */
char main_menu_title[]="Main Menu";
char main_menu_button_0[]="Cockpit";
char main_menu_button_1[]="Navigation";
char main_menu_button_2[]="Trading";
char main_menu_button_3[]="Equipment";
char main_menu_button_4[]="Status";
char main_menu_button_5[]="Game Control";

#define BUTTON_COCKPIT 1

struct gui_button main_menu[]={ 
  {30,  30, 100, 0, BUTTON_COCKPIT, main_menu_button_0},
  {30,  50, 100, 2, 2, main_menu_button_1},
  {30,  70, 100, 0, 3, main_menu_button_2},
  {30,  90, 100, 0, 4, main_menu_button_3},
  {30, 110, 100, 1, 5, main_menu_button_4},
  {30, 130, 100, 0, 6, main_menu_button_5}
};

#define BUTTON_HEIGHT 17

void gui_draw_box(int x1, int y1, int x2, int y2, int thick) {
  int i;

  for(i=0;i<thick;i++) {
    Win2SetColor(clrWhite);
    Win2DrawLine(x1+i, y1+i, x1+i, y2-i );
    Win2DrawLine(x1+i, y1+i, x2-i, y1+i );

    Win2SetColor(clrDkGrey);
    Win2DrawLine(x1+i, y2-i, x2-i+1, y2-i );
    Win2DrawLine(x2-i, y1+i, x2-i, y2-i );
  }
}

void gui_draw_button(struct gui_button *but, int sel) {
  RectangleType rect;
  int i;

  Win2SetBackgroundColor(clrLtGrey);
#if 0
  /* erase button area */
  rect.topLeft.x = but->x; rect.topLeft.y = but->y; 
  rect.extent.x  = but->width+3; rect.extent.y  = BUTTON_HEIGHT+3;
  Win2SetColor(clrLtGrey);
  Win2FillRectangle(&rect, 0);

  /* draw shadow */
  rect.topLeft.x = but->x+3-sel; rect.topLeft.y = but->y+3-sel; 
  rect.extent.x  = but->width; rect.extent.y  = BUTTON_HEIGHT;
  Win2SetColor(clrDkGrey);
  Win2FillRectangle(&rect, 0);

  /* draw black box */
  rect.topLeft.x = but->x+sel; rect.topLeft.y = but->y+sel; 
  Win2SetColor(clrBlack);
  Win2FillRectangle(&rect, 0);

  /* draw white box */
  rect.topLeft.x = but->x+1+sel; rect.topLeft.y = but->y+1+sel; 
  rect.extent.x  = but->width-2; rect.extent.y  = BUTTON_HEIGHT-2;
  Win2EraseRectangle(&rect, 0);
#endif

  /* erase button area */
  rect.topLeft.x = but->x; rect.topLeft.y = but->y; 
  rect.extent.x  = but->width; rect.extent.y  = BUTTON_HEIGHT;
  Win2SetColor(clrLtGrey);
  Win2FillRectangle(&rect, 0);

  if(!sel) gui_draw_box(but->x, but->y, but->x+but->width-1, but->y+BUTTON_HEIGHT-1, 2);
  else     gui_draw_box(but->x+1, but->y+1, but->x+but->width-3, but->y+BUTTON_HEIGHT-3, 1);

  if(but->flags & BUT_DISABLED) Win2SetColor(clrDkGrey);
  else                          Win2SetColor(clrBlack);

  if(but->flags & BUT_FAT)      FntSetFont(1);
  else                          FntSetFont(0);
  
  /* draw text */
  i=StrLen(but->text);
  Win2DrawChars(but->text, i, but->x + but->width/2 - FntLineWidth(but->text,i)/2, but->y + 2);
}

struct gui_button *current_menu, *current_pressed;
unsigned char current_menu_len=0;

void gui_show_menu(char *title, struct gui_button *but, int no) {
  int i;

  current_menu_len = no;
  current_menu     = but;
  current_pressed  = NULL;

  if(no>0) {
    init_screen_from_db(GR_MENU);

    Win2SetColor(clrBlack);
    Win2SetBackgroundColor(clrLtGrey);
    FntSetFont(1);
    i=StrLen(title);
    Win2DrawChars(title, i, 80-FntLineWidth(title,i)/2, 6);

    for(i=0; i<no; i++) gui_draw_button(&but[i], 0);
    Win2SetBackgroundColor(clrWhite);
    Win2SetColor(clrBlack);
    FntSetFont(0);
  }
}

void gui_show_main_menu(void) {
  gui_show_menu(main_menu_title, main_menu, 6);
}

struct gui_button *gui_find_button(int x, int y) {
  int i;

  if(current_menu_len==0) return NULL;

  for(i=0;i<current_menu_len;i++) {
    if((current_menu[i].x <= x)&&
       (current_menu[i].x + current_menu[i].width >= x)&&
       (current_menu[i].y <= y)&&
       (current_menu[i].y + BUTTON_HEIGHT >= y)&&
       (!(current_menu[i].flags & BUT_DISABLED)))
      return &current_menu[i];
  }
  return NULL;
}

void gui_handle_pen_down(int x, int y) {
  /* find button to press */
  if((current_pressed = gui_find_button(x, y))!=NULL)
    gui_draw_button(current_pressed, 1);
}

void gui_handle_pen_up(int x, int y) {
  if(current_pressed!=NULL) {

    /* release button */
    gui_draw_button(current_pressed, 0);

    if(gui_find_button(x, y)!=current_pressed) {
      current_pressed = NULL;
      return; 
    }

    switch(current_pressed->id) {
    case BUTTON_COCKPIT:
      gui_show_menu(NULL, NULL, 0);  /* remove menu */
      start_game(); /* start 3d action */
      break;
    }
    current_pressed = NULL;
  }
}
  
