/*
 * objects.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __OBJECTS_H__
#define __OBJECTS_H__

typedef struct {
  char name[16];
  int radius;

  int data[0];
} OBJECT;

extern OBJECT *objects[];
extern OBJECT cube, station1, cobra, fox;

#define OBJECT_CUBE   0
#define OBJECT_STATN1 1
#define OBJECT_COBRA  2
#define OBJECT_FOX    3

#define OBJECT_NUMBER 4

#endif
