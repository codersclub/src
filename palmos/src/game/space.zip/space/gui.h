/*
 * gui.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __GUI_H__
#define __GUI_H__

extern void gui_main_menu(void);
extern void gui_handle_pen_down(int x, int y);
extern void gui_handle_pen_up(int x, int y);

#endif
