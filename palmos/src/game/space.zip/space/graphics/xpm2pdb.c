/*
 * xpm2pdb.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include <stdio.h>
#include <time.h>
#include <math.h>

#include "pdb.h"
#include "../space.h"
#include "../sinus.h"

#define  DB_VERSION_MAJOR  '2'
#define  DB_VERSION_MINOR  '0'

/* Palm<->Unix Time conversion */
#define PALM2UNIX(a)  (a - 2082844800)
#define UNIX2PALM(a)  (a + 2082844800)

#define STR_SIZE 1024
#define PICLEN   6400

int coltab[256];

#define SINREZ     (1<<SINUS_BITS)
#define SINTABLEN  (2.5*SINREZ)

#define MAX_PIC 8

unsigned char picture_buffer[6400];
unsigned char picture_data[MAX_PIC][6400];
int  picture_len[MAX_PIC];

void 
WriteWord(void *addr, uword data) {
  ubyte *to = (ubyte*)addr;
  ubyte *from = (ubyte*)&data;

  to[0] = from[1]; to[1] = from[0];
}

void 
WriteDWord(void *addr, udword data) {
  ubyte *to = (ubyte*)addr;
  ubyte *from = (ubyte*)&data;

  to[0] = from[3]; to[1] = from[2];
  to[2] = from[1]; to[3] = from[0];
}


int main(int argc, char *argv[]) {
  FILE *fin, *fout;
  char buffer[STR_SIZE];
  int state;
  int width, height, colors, bytes;
  PdbHeader pdb_header;
  RecHeader rec_header;
  int i,r,g,b,c,k,colcnt;
  time_t tim;
  int pics, offset, lines,pic;
  unsigned long pix_data,f,*pi;
  short w1,w2;

  for(i=0;i<256;i++) coltab[i]=-1;

  if(argc<3) { printf("usage xpm2pdb infiles ... outfile\n"); exit(1); }

  fout=fopen(argv[argc-1],"w");

  if(fout==NULL) {
    printf("output file open error\n");
    exit(1);
  }

  /* read pictures in buffers */
  pics = argc-2;

  printf("record 0: sintab[%d]\n", SINREZ);

  for(pic=0;pic<pics;pic++) {
    state=0;
    pi = (unsigned long*)picture_buffer;

    fin=fopen(argv[1+pic],"r");

    while(fgets(buffer, STR_SIZE, fin) != NULL) {

      /* convert file */
      if(state==2) {
	if(lines<height) {
	  r=0;
	  while(buffer[r]!='\"') r++;
	  r++;
	  
	  //	printf("%s\n", &buffer[r]);
	  
	  for(c=0;c<(width/16);c++) {
	    
	    pix_data = 0;
	    for(i=0;i<16;i++) {
	      pix_data<<=2;
	      pix_data|=coltab[buffer[r++]];
	    }
	    /* write long word */
	    WriteDWord(&f, pix_data);
	    *pi++=f;
//	    fwrite(&f,sizeof(unsigned long),1,fout);

	  }
	  lines++;
	}
      }
      
      /* read colors */
      if(state==1) {
	/* picture must contain four colors: black, white and a color < midgrey and */
	/* one >midgrey, these will be mapped to black, white, lightgrey and darkgrey */
	
	if(colors>0) {
	  /* " 	c #FFFF FFFF FFFF", */
	  if((i=sscanf(buffer, "\"%c c #%4x%4x%4x\"", &c, &r, &g, &b))!=4)
	    i=sscanf(buffer, "\"%c c #%2x%2x%2x\"", &c, &r, &g, &b);
	  else {
	    r >>= 8;
	    g >>= 8;
	    b >>= 8;
	  }
	  
	  r&=0xff; g&=0xff; b&=0xff;
	  
	  if(i==4) {
	    if(r+g+b==3*0xff)   k=0; /* white */
	    else if (r+g+b==0)  k=3; /* black */
	    else if (r+g+b<384) k=2; /* dark grey */
	    else if (r+g+b>384) k=1; /* light grey */
	    
	    //	  printf("got color %d(%c) = %x/%x/%x (%d)\n",c,c,r,g,b,k);
	    
	    coltab[c]=k;
	    
	    if(++colcnt==colors)
	      state=2;
	  }
	}
      }
      
      /* find picture header */
      if(state==0) {
	if(sscanf(buffer, "\"%d %d %d %d\"", &width, &height, &colors, &bytes)==4) {
	  printf("record %d: picture size = %d x %d, %d colors\n", pic+1, width, height, colors);
	  
	  if(((width&7)!=0)||(colors>4)||(bytes!=1)) {
	    printf("image width must be multiple of 8 and the number of colors must not exceed 4\n");
	    exit(1);
	  }
	  colcnt=0;
	  lines=0;
	  state=1;
	}
	
      }
    }
    fclose(fin);

    /* copy into output buffer */
    /* simple rle compression */
    //    memcpy(picture_data[pic], picture_buffer, 6400);
    //    picture_len[pic]=6400;

    {
      unsigned char last,lcnt;
      int cnt=0, t=0, pk=0;

      do {
	last = picture_buffer[t++];
	lcnt=1;

	while((picture_buffer[t]==last)&&(cnt<6400)&&(lcnt<255)) { t++; lcnt++; cnt++; }

	picture_data[pic][pk++] = lcnt;
	picture_data[pic][pk++] = last;

      } while(cnt<6400);

      picture_len[pic] = pk;

      printf("   compression: 6400 -> %d (%d%%)\n", pk, 100*pk/6400); 
    }
  }

  /* write pdb header */
  /* this is more a joke, since palmos overwrites this value anyway */
  tim=UNIX2PALM(time(0));
  
  /* create/write pdb header */
  memset(&pdb_header,0,sizeof(PdbHeader));
  strcpy(pdb_header.name, "Graphics Data");
  WriteWord(&(pdb_header.version),0x0001);
  WriteDWord(&(pdb_header.creationDate),tim);
  WriteDWord(&(pdb_header.modificationDate),tim);
  WriteDWord(&(pdb_header.databaseType),DB_TYPE);
  WriteDWord(&(pdb_header.creatorID),CREATOR);
  WriteWord(&(pdb_header.numberOfRecords), 1+pics);
  fwrite(&pdb_header,sizeof(PdbHeader),1,fout);
  
  /* offset to data inside db */
  offset = sizeof(PdbHeader) + (1+pics)*sizeof(RecHeader);
  
  /* write sintab record header */
  WriteDWord(&(rec_header.recordDataOffset), offset);
  rec_header.recordAttributes = 0x60;
  rec_header.uniqueID[0] = rec_header.uniqueID[1] = rec_header.uniqueID[2] = 0x00;
  fwrite(&rec_header,sizeof(RecHeader),1,fout);
  offset+=SINTABLEN;

  /* write BLOCKS record headers */
  for(i=0;i<pics;i++) {
    WriteDWord(&(rec_header.recordDataOffset), offset);
    
    rec_header.recordAttributes = 0x60;
    rec_header.uniqueID[0] = rec_header.uniqueID[1] = rec_header.uniqueID[2] = 0x00;
    fwrite(&rec_header,sizeof(RecHeader),1,fout);

    /* offset to next block */
    offset+=picture_len[i];
  }

  k=0;
  /* generate sintab */
  for(i=0;i<SINTABLEN/2;i++) {
    w1 = 32767.0 * sin( ((float)i * 2*M_PI ) / (float)SINREZ);
    WriteWord(&w2, w1);
    fwrite(&w2, 2, 1, fout);
  }

  /* write picture data */
  for(i=0;i<pics;i++)
    fwrite(picture_data[i], picture_len[i], 1, fout);

  fclose(fout);

  return 0;
}
