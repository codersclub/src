/*
 * graphics.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#define GR_COCKPIT 1
#define GR_MENU    2
