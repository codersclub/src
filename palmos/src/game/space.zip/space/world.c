/*
 * world.c - routines to calculate the whole world
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

/* improvents: */
/* - better object-is-out-of-view mapping */

#include <Pilot.h>
#include "space.h"
#include "world.h"
#include "objects.h"
#include "3d.h"
#include "2d.h"
#include "instr.h"
#include "graphics.h"

MAPPED_OBJECT world[MAX_MAPPED];
int mapped_objects;

#define noUSE_QSORT

int start_game(void) {
  MAPPED_OBJECT obj;

  Win2SetBackgroundColor(clrWhite);
  game_state = STATE_3D;

  /* init 3d cockpits graphics */
  init_screen_from_db(GR_COCKPIT);
    
  /* init vector engine */
  init_3d();
    
  /* set up test world */
  world_clear();

  /* set up player */
  world_init_object(&me, OBJECT_ME, 0,0,0);
  me_move.forward = 0;
  me_move.roll_z = 0;
  me_move.roll_x = 0;
    
  /* set up one object */
  world_init_object(&obj, OBJECT_FOX, 0,0,250);
  rotate_object_axis(&obj, OB_Z, 8000);
  rotate_object_axis(&obj, OB_X, 8000);
  rotate_object_axis(&obj, OB_Z, -8000);
  world_add(&obj);
  
  /* set up a second object */
  world_init_object(&obj, OBJECT_COBRA, 0,0,-5000);
  world_add(&obj);

  /* set up a third object */
  world_init_object(&obj, OBJECT_STATN1, 5000,0,0);
  world_add(&obj);
  
  draw_msg("Cobra MK III", clrBlack);
}


void world_clear(void) {
  int i;

  mapped_objects=0;

  for(i=0;i<MAX_MAPPED;i++)
    world[i].type = OBJ_NONE;
}

void world_init_object(MAPPED_OBJECT *obj,
		       unsigned int type, 
		       long x, long y, long z) {

  if(type!=OBJECT_ME) {
    obj->type = OBJECT2TYPE(type);
    obj->misc.object = objects[type];

    /* calculate radius (obj radius << scale factor) */
    obj->radius = (objects[type]->radius) << (objects[type]->data[0]);
  }

  obj->pos[OB_X] = x<<8;
  obj->pos[OB_Y] = y<<8;
  obj->pos[OB_Z] = z<<8;

  obj->x_vec[OB_X] = VEC_MAX; obj->x_vec[OB_Y] = 0;       obj->x_vec[OB_Z] = 0; 
  obj->y_vec[OB_X] = 0;       obj->y_vec[OB_Y] = VEC_MAX; obj->y_vec[OB_Z] = 0; 
  obj->z_vec[OB_X] = 0;       obj->z_vec[OB_Y] = 0;       obj->z_vec[OB_Z] = VEC_MAX;
}

void world_add(MAPPED_OBJECT *new) {
  int i;
  
  /* world is full? */
  if(mapped_objects==MAX_MAPPED)
    return;

  MemMove(&world[mapped_objects], new, sizeof(MAPPED_OBJECT));      
  mapped_objects++;
}

/* used for systems sort function to depth-sort objects */
Int world_compare_objects(VoidPtr object1, VoidPtr object2, Long other) {
  long diff = (long)((MAPPED_OBJECT*)object1)->distance - (long)((MAPPED_OBJECT*)object2)->distance;
  return( (diff==0)?0:(diff<0)?1:-1 );
}

void world_display(MAPPED_OBJECT *me) {
  unsigned int  i;
  int  edge_buffer[256], *data;
  long x,y,z, tmp;
  long sin, cos;

  clear_3d_area(1);
  instr_radar_restore();
  
  for(i=0;i<mapped_objects;i++) {

    /* get coordinates of object relative to viewer */
    x = (world[i].pos[OB_X] - me->pos[OB_X])>>8;
    y = (world[i].pos[OB_Y] - me->pos[OB_Y])>>8;
    z = (world[i].pos[OB_Z] - me->pos[OB_Z])>>8;

    /* determine whether object is visible at all */

    /* object within viewability square? */
    if((x> WORLD_VIS_RADIUS)||
       (x<-WORLD_VIS_RADIUS)||
       (y> WORLD_VIS_RADIUS)||
       (y<-WORLD_VIS_RADIUS)||
       (z> WORLD_VIS_RADIUS)||
       (z<-WORLD_VIS_RADIUS)) {
      world[i].distance = 0;
      continue;
    }

    /* calculate exact distance from viewer to object (d=square of distance) */
    world[i].distance = x*x + y*y + z*z;

    if(world[i].distance > ((long)WORLD_VIS_RADIUS*(long)WORLD_VIS_RADIUS)) {
      world[i].distance = 0;
      continue;
    }

    /* ok, the object is within visibility range */
    
    /* fine, save coordinates */
    world[i].tpos[OB_X]=x;
    world[i].tpos[OB_Y]=y;
    world[i].tpos[OB_Z]=z;
  }

  /* calculate position of center of objects, store this in tpos[...] */
  /* this is not used for 3d display but for visibility tests and radar display */

  for(i=0;i<mapped_objects;i++) {
    /* only work with things in range */
    if(world[i].distance != 0) {
      x = (world[i].tpos[OB_X] * (long)me->x_vec[OB_X] +  
	   world[i].tpos[OB_Y] * (long)me->y_vec[OB_X] + 
	   world[i].tpos[OB_Z] * (long)me->z_vec[OB_X]) >> VEC_BITS;
      y = (world[i].tpos[OB_X] * (long)me->x_vec[OB_Y] +  
	   world[i].tpos[OB_Y] * (long)me->y_vec[OB_Y] + 
	   world[i].tpos[OB_Z] * (long)me->z_vec[OB_Y]) >> VEC_BITS;
      z = (world[i].tpos[OB_X] * (long)me->x_vec[OB_Z] +  
	   world[i].tpos[OB_Y] * (long)me->y_vec[OB_Z] + 
	   world[i].tpos[OB_Z] * (long)me->z_vec[OB_Z]) >> VEC_BITS;

      world[i].tpos[OB_X] = x;
      world[i].tpos[OB_Y] = y;
      world[i].tpos[OB_Z] = z;

      instr_radar_add(x,y,z);

      /* is the object too near? */
      /* of course objects are not perfect spheres, but we might */
      /* imagine some spherical shields surrounding the real hull */

      if(world[i].distance < ((long)world[i].radius*(long)world[i].radius)) {
	/* crash detected ... */
	world[i].distance = 0;
      }
    }
  }

  /* sort all objects for drawing */
  if(mapped_objects>1) {
#ifndef USE_QSORT
    SysInsertionSort( (Byte*)world, mapped_objects, sizeof(MAPPED_OBJECT), world_compare_objects, 0);
#else
    SysQSort( (Byte*)world, mapped_objects, sizeof(MAPPED_OBJECT), world_compare_objects, 0);
#endif
  }

  /* now work on real object coordinates */

  for(i=0;i<mapped_objects;i++) {

    /* only work with things in range */
    if(world[i].distance != 0) {

      /* object is only visible if all points are in front */
      if(world[i].tpos[OB_Z]<world[i].radius)
	continue;

      /* here is still space for improvements ... */

      data=world[i].misc.object->data;
      scale_n_copy_object(edge_buffer, &data[2], data[1], data[0]);

      /* rotate object around its own axis */
      rotate_object_edges(data[1], edge_buffer, 
			  world[i].x_vec, world[i].y_vec, world[i].z_vec);

      /* now move it to the right position (relative to viewer) */
      translate_object_edges(world[i].misc.object->data[1], edge_buffer, 
			     (world[i].pos[OB_X] - me->pos[OB_X])>>8,
			     (world[i].pos[OB_Y] - me->pos[OB_Y])>>8,
			     (world[i].pos[OB_Z] - me->pos[OB_Z])>>8);

      /* and again rotate, this time around viewers axis */
      rotate_object_edges(data[1], edge_buffer, 
			  me->x_vec, me->y_vec, me->z_vec);

      project_object_edges(data[1], edge_buffer);
      disp_object(&(data[2+3*data[1]]), edge_buffer);
	
    }
  }

  /* draw additional things on 3d screen (numbers, lasers ...) */
  

  /* some very important numbers ... */
  instr_put_int(0,  117-6,  10000, me->z_vec[0], 1);
  instr_put_int(0,  117,    10000, me->z_vec[1], 1);
  instr_put_int(75, 117,    10000, me->z_vec[2], 1);

  instr_put_speedometer(15,132, me_move.forward/(6400/32));
  instr_put_speedometer(15,140, 16-(me_move.roll_z/(512/16)));
  instr_put_speedometer(15,148, 16-(me_move.roll_x/(512/16)));

  /* do some animations */
  for(i=0;i<mapped_objects;i++) {

    if(world[i].type == OBJECT2TYPE(OBJECT_FOX)) {
      rotate_object_axis(&world[i], OB_X, 1000);
      move_object(&world[i], 2000);
    }

    if(world[i].type == OBJECT2TYPE(OBJECT_STATN1))
      rotate_object_axis(&world[i], OB_Z, 500);

  }

  flip_screen();
}








