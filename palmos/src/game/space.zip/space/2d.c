/*
 * 2d.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include <Pilot.h>

#include "win2.h"
#include "space.h"
#include "sinus.h"

/* database stuff */
LocalID dbid;
UInt card;
DmOpenRef dbref;

short *sintab, *costab;

int open_graphics_db(void) {
  DmSearchStateType stateInfo;
  Err err;

  VoidHand record;

  /* find OS database */
  err=DmGetNextDatabaseByTypeCreator(true, &stateInfo, DB_TYPE, CREATOR, true, &card, &dbid);

  if(!err) {
    /* open db */
    dbref = DmOpenDatabase(card, dbid, dmModeReadOnly);

    /* lock record 0 (sinus table) */
    record = DmGetRecord(dbref, 0);
    sintab = MemHandleLock(record);
    costab = sintab+COSINUS_OFFSET;
  }

  return !err;
}

void close_graphics_db(void) {
  /* unlock sinus table */
  MemPtrUnlock(sintab);
  DmReleaseRecord(dbref, 0, false);

  DmCloseDatabase(dbref);
}

void init_screen_from_db(int rec) {
  VoidHand record;
  unsigned char *p, *d1,*d2,*s;
  int i, run, data, j;

  d1=(d2=(unsigned char*)vwin2.pbGreyScreenBase)+6400;

  record = DmGetRecord(dbref, rec);
  s = p = MemHandleLock(record);

  _Win2ScreenAccess(1);

  /* unpack runlength compression */
  i=0;
  do {
    run  = *s++;
    data = *s++;

    for(j=0;j<run;j++)
      *d1++ = *d2++ = data;

    i+=run;
  } while(i<6400);

  _Win2ScreenAccess(0);
 
  MemPtrUnlock(p);
  DmReleaseRecord(dbref, rec, false);
}

#define MSG_Y  10

void draw_msg(char *msg, Win2Color color) {
  int i,j;
  unsigned long *d,*p;

  Win2SetColor(color);

  /* erase text area */
  p=(unsigned long*)vwin2.pbGreyScreenBase+MSG_Y*10+3;
  _Win2ScreenAccess(1);
  for(i=0;i<11;i++,p+=6)
    for(j=0;j<4;j++)
      *p++=0;
  _Win2ScreenAccess(0);

  i = StrLen(msg);  
  Win2DrawChars(msg,i,80-FntLineWidth(msg,i)/2,MSG_Y);

  /* copy text area */
  d=(p=(unsigned long*)vwin2.pbGreyScreenBase+MSG_Y*10+3)+1600;
  _Win2ScreenAccess(1);
  for(i=0;i<11;i++,d+=6,p+=6)
    for(j=0;j<4;j++)
      *d++=*p++;
  _Win2ScreenAccess(0);
}

#ifdef DEBUG
void debug_draw_msg(char *msg) {
  int i,j;
  unsigned long *d,*p;

  Win2SetColor(clrBlack);

  /* erase text area */
  p=(unsigned long*)vwin2.pbGreyScreenBase;
  _Win2ScreenAccess(1);
  for(i=0;i<11*10;i++) *p++=0;
  _Win2ScreenAccess(0);

  i = StrLen(msg);  
  Win2DrawChars(msg,i,0,0);

  /* copy text area */
  d=(p=(unsigned long*)vwin2.pbGreyScreenBase)+1600;
  _Win2ScreenAccess(1);
  for(i=0;i<11*10;i++)
    *d++=*p++;
  _Win2ScreenAccess(0);
}
#endif
