/*
 * 3d.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

/* todo: min/max waehrend projektion */

#define noDO_STARFIELD

#define NON_PORTABLE
#include <Pilot.h>
#include "win2.h"
#include "space.h"
#include "world.h"
#include "objects.h"
#include "3d.h"
#include "2d.h"
#include "instr.h"

#ifdef NO_ASM
unsigned long hline_mask0[]={
  0xffffffff, 0x3fffffff, 0x0fffffff, 0x03ffffff,
  0x00ffffff, 0x003fffff, 0x000fffff, 0x0003ffff,
  0x0000ffff, 0x00003fff, 0x00000fff, 0x000003ff,
  0x000000ff, 0x0000003f, 0x0000000f, 0x00000003
};

unsigned long hline_mask1[]={
  0xc0000000, 0xf0000000, 0xfc000000, 0xff000000, 
  0xffc00000, 0xfff00000, 0xfffc0000, 0xffff0000, 
  0xffffc000, 0xfffff000, 0xfffffc00, 0xffffff00, 
  0xffffffc0, 0xfffffff0, 0xfffffffc, 0xffffffff
};
#endif

unsigned long hline_shade[2][8]={
  {
    0x00000000, 0x11111111, 
    0x55555555, 0x66666666,
    0xaaaaaaaa, 0xbbbbbbbb,
    0xffffffff, 0xffffffff
  }, {
    0x00000000, 0x44444444, 
    0x55555555, 0x99999999,
    0xaaaaaaaa, 0xeeeeeeee,
    0xffffffff, 0xffffffff
  }
};

#define LSSA ((unsigned long *)0xFFFFFA00)

int current_screen;
unsigned char *screen_base;

#ifdef DO_STARFIELD
#define STARS 32

unsigned char star_bits[]={0x3f,0xcf,0xf3,0xfc};

unsigned int stars[STARS][2];
int stars_add[STARS][2];

void create_star(int no) {
  int j;

  stars[no][0] = SysRandom(0)%(160u*256u);  /* x */
  stars[no][1] = SysRandom(0)%(100u*256u);  /* y */

  stars_add[no][0]= ((signed)stars[no][0]-(80*256))/20;
  stars_add[no][1]= ((signed)stars[no][1]-(50*256))/20;
}

void init_starfield(void) {
  int i,j;

  for(i=0;i<STARS;i++)
    create_star(i);
}

void draw_starfield(void) {
  int i;

  for(i=0;i<STARS;i++) {
    *(screen_base + 40*(24+(stars[i][1]>>8)) + (stars[i][0]>>10)) |= ~star_bits[(stars[i][0]>>8)&0x3];

    stars[i][0]+=stars_add[i][0];
    stars[i][1]+=stars_add[i][1];

    if((stars[i][0]>(159u*256u))||(stars[i][0]<0)||(stars[i][1]>(99u*256u))||(stars[i][1]<0)) {
      create_star(i);
    }
  }
}
#endif

void init_3d(void) {
  current_screen = 0;
  screen_base = vwin2.pbGreyScreenBase;
#ifdef DO_STARFIELD
  init_starfield();
#endif

  instr_radar_save();
}

void flip_screen(void) {
  if(current_screen==0) {
    *LSSA = (long)screen_base;
    screen_base += 6400;
    
    current_screen = 1;
  } else {
    *LSSA = (long)screen_base;
    screen_base -= 6400;

    current_screen = 0;
  }
}

void clear_3d_area(int do_starfield) {
  _Win2ScreenAccess(1);
  MemSet(screen_base+24*40, 100*40, 0x00);
#ifdef DO_STARFIELD
  if(do_starfield) draw_starfield();
#endif
  _Win2ScreenAccess(0);
}

#ifdef NO_ASM
/* draw a horizontal line clipped in 3d view area */
inline void draw_hline_int(int y, int start, int end, int color) {
  unsigned long shade, mask, *ptr=(unsigned long*)screen_base;
  int i;

  /* y in range of 0..159? */
  if(((unsigned int)y<100)&&(start<=159)&&(end>=0)) {

    /* vertical offset into 3d window */
    ptr += y*10 + 24*10;  /* start 32th row */

    /* x clipping */
    if(start<0) start=0;
    if(end>159) end=159;

    //    if(start>end) { i=end; end=start; start=i; }
    if(start>=end) return;

    ptr += (start>>4);
    
    if((start&0xf0)!=(end&0xf0)) {
      /* draw first word */
      shade = hline_shade[y&1][color];
      mask  = hline_mask0[start&0x0f];
      *ptr++ = (*ptr & ~mask) | (shade & mask);
      for(i=1;i<( (end>>4) - (start>>4) );i++) *ptr++ = shade;
      mask = hline_mask1[end&0x0f];
      *ptr   = (*ptr & ~mask) | (shade & mask);
    } else {
      mask  = (hline_mask0[start&0x0f] & hline_mask1[end&0x0f]);
      *ptr = (*ptr & ~mask) | (hline_shade[y&1][color] & mask);
    }
  }
}
#else
extern void draw_hline_int(int y, int start, int end, unsigned long color);
extern void draw_hline_aray(int *lines, int start, int end, int color);
#endif

/* wrapper to call above function externally */
void draw_hline(int y, int start, int end, int color) {
  _Win2ScreenAccess(1);
  draw_hline_int(y, start, end, hline_shade[y&1][color]);
  _Win2ScreenAccess(0);
}

/* draw _konvex_ polygon in 3d area */
int edge_table[16]={0,0,0,1,1,1,2,2,2,3,3,3,4,4,4,5};
int bresen_buffer[100][2];

void draw_polygon_int(int *edges, int *coo, int edgenum, int color) {

  int from,to,add,m,x,y;
  int e1,e2,i,dx,dy;
  int polygon[16][2];  /* buffer to save polygon */

#ifdef NO_ASM
  unsigned long colors[2];
#endif
  
  /* copy edges */
  for(i=0;i<edgenum;i++) {
    polygon[i][0] = edges[4*coo[i]+0];
    polygon[i][1] = edges[4*coo[i]+1];
  }

  /* check if polygon is visible */
  dy = 2 * (dx = edge_table[edgenum]);

  /* only draw if visible */
  e1 = polygon[dx][0] - polygon[0][0];  /* e1 == x-offset X1->X2 */
  e2 = polygon[dx][1] - polygon[0][1];  /* e2 == y-offset Y1->Y2 */

  if(e1==0) {
    if(((e2<0)&&(polygon[dy][0] <= polygon[0][0]))||
       ((e2>0)&&(polygon[dy][0] >= polygon[0][0])))
      return;

  } else {
    i= polygon[0][1] +
      (polygon[dy][0] - polygon[0][0])*e2/e1;

    if(((e1>0)&&(polygon[dy][1]<=i))||
       ((e1<0)&&(polygon[dy][1]>=i)))
      return;
  }

  /* find lowest/highest y coordinate */
  e2 = e1 = 0; 
  dy = dx = polygon[0][1];  /* first y coordinate */
  for(i=1;i<edgenum;i++) {
    if(polygon[i][1]<dx) { e1=i; dx=polygon[i][1]; }
    if(polygon[i][1]>dy) { e2=i; dy=polygon[i][1]; }
  }

  /* e1/e2 now contains number of edge with lowest/highest y coordinate */

  /* now do two times bresenham from e1 to e2 */
  to=e1;
  y=polygon[e1][1];

  do {
    from = to;
    to = (to==0)?edgenum-1:to-1;
    dy = polygon[to][1] - polygon[from][1];
    if(polygon[to][0] > polygon[from][0]) {
      add = 1;
      dx = polygon[to][0] - polygon[from][0];
    } else {
      add = -1;
      dx = polygon[from][0] - polygon[to][0];
    }

    m = dx/2;
    x = polygon[from][0];

    while(y<polygon[to][1]) {
      while(m>dy) { m-=dy; x+=add; }
      if( (unsigned int)y < 100)
	bresen_buffer[y++][0]=x;
      else
	y++;
      m+=dx;
    }

  } while(to!=e2);

  to=e1;
  y=polygon[e1][1];

  do {
    from = to;
    to = (to==edgenum-1)?0:to+1;
    dy = polygon[to][1] - polygon[from][1];
    if(polygon[to][0] > polygon[from][0]) {
      add = 1;
      dx = polygon[to][0] - polygon[from][0];
    } else {
      add = -1;
      dx = polygon[from][0] - polygon[to][0];
    }

    m = dx/2;
    x = polygon[from][0];

    while(y<polygon[to][1]) {
      while(m>dy) { m-=dy; x+=add; }
      if( (unsigned int)y < 100)
	bresen_buffer[y++][1]=x;
      else 
	y++;
      m+=dx;
    }
  } while(to!=e2);

#ifdef NO_ASM
  colors[0]=hline_shade[0][color];
  colors[1]=hline_shade[1][color];

  /* und malen */
  for(y=polygon[e1][1];y<polygon[e2][1];y++)
    draw_hline_int(y, bresen_buffer[y][0], bresen_buffer[y][1], colors[y&1]);
#else
  draw_hline_array(bresen_buffer, polygon[e1][1], polygon[e2][1], color );
#endif
}

void draw_polygon(int *edges, int *coo, int edgenum, int color) {
  _Win2ScreenAccess(1);
  draw_polygon_int(edges, coo, edgenum, color);
  _Win2ScreenAccess(0);
}

void scale_n_copy_object(int *dest, int *src, int num, int scale) {
  int i;

  for(i=0;i<num;i++) {
    *dest++ = *src++ << scale; /* x */
    *dest++ = *src++ << scale; /* y */
    *dest++ = *src++ << scale; /* z */
    *dest++ = 0;  /* filler for faster logic */
  }
}

#define EDGE_X(a) (edge_data[4*a+0])
#define EDGE_Y(a) (edge_data[4*a+1])
#define EDGE_Z(a) (edge_data[4*a+2])

/* rotate coordinates */
void rotate_object_edges(int edges, int *edge_data, 
			 short vx[3], short vy[3], short vz[3]) {
  int i, px, py, pz;

  for(i=0; i<edges; i++) {
    px = (EDGE_X(i) * (long)vx[OB_X] +  EDGE_Y(i) * (long)vy[OB_X] + EDGE_Z(i) * (long)vz[OB_X]) >> VEC_BITS;
    py = (EDGE_X(i) * (long)vx[OB_Y] +  EDGE_Y(i) * (long)vy[OB_Y] + EDGE_Z(i) * (long)vz[OB_Y]) >> VEC_BITS;
    pz = (EDGE_X(i) * (long)vx[OB_Z] +  EDGE_Y(i) * (long)vy[OB_Z] + EDGE_Z(i) * (long)vz[OB_Z]) >> VEC_BITS;

    EDGE_X(i) =  px;
    EDGE_Y(i) =  py;
    EDGE_Z(i) =  pz;
  }
}

/* translate coordinates */
void translate_object_edges(int edges, int *edge_data, int off_x, int off_y, int off_z) {
  int i;

  /* just add the offset ... */
  for(i=0;i<edges;i++) {
    EDGE_X(i) += off_x;
    EDGE_Y(i) += off_y;
    EDGE_Z(i) += off_z;
  }
}

#define VIEW_Z 100

/* projection of corrdinates */
void project_object_edges(int edges, int *edge_data) {
  int i;
  
  /* just add the offset ... */
  for(i=0;i<edges;i++) {
    if(EDGE_Z(i)!=0) {
      EDGE_X(i) = 80 - ( VIEW_Z * (long)EDGE_X(i)) / EDGE_Z(i);
      EDGE_Y(i) = 50 - ( VIEW_Z * (long)EDGE_Y(i)) / EDGE_Z(i);
      EDGE_Z(i) = 0;
    } else {
      EDGE_X(i) = 80;
      EDGE_Y(i) = 50;
      EDGE_Z(i) = 0;
    }
  }
}

/* rotate object around objects axis */
void rotate_object_axis(MAPPED_OBJECT *obj, int axis, unsigned short rot) {
  short  x,y,z, dcos, dsin;
  long   l;

  dsin = sintab[rot>>SIN_SHIFT];
  dcos = costab[rot>>SIN_SHIFT];

  if(axis==OB_X) {
    x=((long)obj->y_vec[OB_Y]*dsin +(long)obj->z_vec[OB_Y]*dcos)>>VEC_BITS;
    y=((long)obj->y_vec[OB_X]*dsin +(long)obj->z_vec[OB_X]*dcos)>>VEC_BITS;
    z=((long)obj->y_vec[OB_Z]*dsin +(long)obj->z_vec[OB_Z]*dcos)>>VEC_BITS;

    l=((long)x*x + (long)y*y + (long)z*z)>>VEC_BITS;
    l=(VEC_MAX-1-l)/2;
    obj->z_vec[OB_Y]=x+((x*l)>>VEC_BITS);
    obj->z_vec[OB_X]=y+((y*l)>>VEC_BITS);
    obj->z_vec[OB_Z]=z+((z*l)>>VEC_BITS);
    obj->y_vec[OB_Y]=((long)obj->x_vec[OB_X]*obj->z_vec[OB_Z] - (long)obj->x_vec[OB_Z]*obj->z_vec[OB_X] ) >> VEC_BITS;
    obj->y_vec[OB_X]=((long)obj->x_vec[OB_Z]*obj->z_vec[OB_Y] - (long)obj->x_vec[OB_Y]*obj->z_vec[OB_Z] ) >> VEC_BITS;
    obj->y_vec[OB_Z]=((long)obj->x_vec[OB_Y]*obj->z_vec[OB_X] - (long)obj->x_vec[OB_X]*obj->z_vec[OB_Y] ) >> VEC_BITS;
  } else {

    x=((long)obj->x_vec[OB_Y]*dsin +(long)obj->y_vec[OB_Y]*dcos)>>VEC_BITS;
    y=((long)obj->x_vec[OB_X]*dsin +(long)obj->y_vec[OB_X]*dcos)>>VEC_BITS;
    z=((long)obj->x_vec[OB_Z]*dsin +(long)obj->y_vec[OB_Z]*dcos)>>VEC_BITS;

    l=((long)x*x + (long)y*y + (long)z*z)>>VEC_BITS;
    l=(VEC_MAX-1-l)/2;
    obj->y_vec[OB_Y]=x+((x*l)>>VEC_BITS);
    obj->y_vec[OB_X]=y+((y*l)>>VEC_BITS);
    obj->y_vec[OB_Z]=z+((z*l)>>VEC_BITS);
    obj->x_vec[OB_Y]=((long)obj->z_vec[OB_X]*obj->y_vec[OB_Z] - (long)obj->z_vec[OB_Z]*obj->y_vec[OB_X] ) >> VEC_BITS;
    obj->x_vec[OB_X]=((long)obj->z_vec[OB_Z]*obj->y_vec[OB_Y] - (long)obj->z_vec[OB_Y]*obj->y_vec[OB_Z] ) >> VEC_BITS;
    obj->x_vec[OB_Z]=((long)obj->z_vec[OB_Y]*obj->y_vec[OB_X] - (long)obj->z_vec[OB_X]*obj->y_vec[OB_Y] ) >> VEC_BITS;
  }
}

/* rotate object around objects axis */
void rotate_object_axis_me(MAPPED_OBJECT *obj, int axis, unsigned short rot) {
  short  tmp, dcos, dsin;

  dsin = sintab[rot>>SIN_SHIFT];
  dcos = costab[rot>>SIN_SHIFT];

  if(axis==OB_X) {

    tmp              = (dcos * (long)obj->x_vec[OB_Z] - dsin * (long)obj->x_vec[OB_Y]) >> VEC_BITS;
    obj->x_vec[OB_Y] = (dsin * (long)obj->x_vec[OB_Z] + dcos * (long)obj->x_vec[OB_Y]) >> VEC_BITS;
    obj->x_vec[OB_Z] = tmp;

    tmp              = (dcos * (long)obj->y_vec[OB_Z] - dsin * (long)obj->y_vec[OB_Y]) >> VEC_BITS;
    obj->y_vec[OB_Y] = (dsin * (long)obj->y_vec[OB_Z] + dcos * (long)obj->y_vec[OB_Y]) >> VEC_BITS;
    obj->y_vec[OB_Z] = tmp;

    tmp              = (dcos * (long)obj->z_vec[OB_Z] - dsin * (long)obj->z_vec[OB_Y]) >> VEC_BITS;
    obj->z_vec[OB_Y] = (dsin * (long)obj->z_vec[OB_Z] + dcos * (long)obj->z_vec[OB_Y]) >> VEC_BITS;
    obj->z_vec[OB_Z] = tmp;

  } else {

    tmp              = (dcos * (long)obj->x_vec[OB_X] - dsin * (long)obj->x_vec[OB_Y]) >> VEC_BITS;
    obj->x_vec[OB_Y] = (dsin * (long)obj->x_vec[OB_X] + dcos * (long)obj->x_vec[OB_Y]) >> VEC_BITS;
    obj->x_vec[OB_X] = tmp;

    tmp              = (dcos * (long)obj->y_vec[OB_X] - dsin * (long)obj->y_vec[OB_Y]) >> VEC_BITS;
    obj->y_vec[OB_Y] = (dsin * (long)obj->y_vec[OB_X] + dcos * (long)obj->y_vec[OB_Y]) >> VEC_BITS;
    obj->y_vec[OB_X] = tmp;

    tmp              = (dcos * (long)obj->z_vec[OB_X] - dsin * (long)obj->z_vec[OB_Y]) >> VEC_BITS;
    obj->z_vec[OB_Y] = (dsin * (long)obj->z_vec[OB_X] + dcos * (long)obj->z_vec[OB_Y]) >> VEC_BITS;
    obj->z_vec[OB_X] = tmp;
  }
}

/* move object forward */
void move_object(MAPPED_OBJECT *obj, int offset) {
  obj->pos[OB_X] += (offset * (long)obj->z_vec[OB_X])>>VEC_BITS;
  obj->pos[OB_Y] += (offset * (long)obj->z_vec[OB_Y])>>VEC_BITS;
  obj->pos[OB_Z] += (offset * (long)obj->z_vec[OB_Z])>>VEC_BITS;
}

/* move object forward */
void move_object_me(MAPPED_OBJECT *obj, int offset) {
  obj->pos[OB_X] += (offset * (long)obj->x_vec[OB_Z])>>VEC_BITS;
  obj->pos[OB_Y] += (offset * (long)obj->y_vec[OB_Z])>>VEC_BITS;
  obj->pos[OB_Z] += (offset * (long)obj->z_vec[OB_Z])>>VEC_BITS;
}

/* display object in 3d window */
void disp_object(int *polygon, int *edges) {
  int i,poly = *polygon++;
  int edgenum;
  
  _Win2ScreenAccess(1);

  for(i=0;i<poly;i++) {
    edgenum = *polygon++;
    draw_polygon_int(edges, polygon+1, edgenum, *polygon);

    polygon += edgenum+1;
  }
  _Win2ScreenAccess(0);
}

