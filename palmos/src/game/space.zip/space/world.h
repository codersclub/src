/*
 * world.h - routines to calculate the whole world
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __WORLD_H__
#define __WORLD_H__

#include "space.h"
#include "objects.h"

#define WORLD_VIS_RADIUS 10000


#define OBJ_NONE     0
#define OBJECT_ME   1024

#define MAX_MAPPED  32   /* max. objects in world */

#define OBJECT2TYPE(a) (a+1)

#define OB_X    0
#define OB_Y    1
#define OB_Z    2

typedef struct {
  unsigned int  type;                 /* type of object */

  unsigned long  distance;             /* tmp var. distance to viewer */
  long           tpos[3];              /* tmp relative position to viewer */

  long           pos[3];               /* absolute position in world */
  long           radius;
  short          x_vec[3], y_vec[3], z_vec[3];  

  union {
    OBJECT *object;                   /* three D vector object */

    long misc1;
    int  misc2;
  } misc;
} MAPPED_OBJECT;

/* init stuff */
extern int start_game(void);

extern void world_clear(void);
extern void world_init_object(MAPPED_OBJECT *, unsigned int, long, long, long);
extern void world_add(MAPPED_OBJECT *new);
extern void world_display(MAPPED_OBJECT *me);

#endif
