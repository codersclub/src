/* star name generator */

#include <stdio.h>
#include <stdlib.h>

char vchars[]="aaaeeeeiiiooouuu";
char kchars[]="bcdfghklmnprstvw";

char *numbers[]={ "I","II","III","IV" };

int main(int argc, char *argv[]) {
  int i,j;
  unsigned long r;

  for(i=0;i<500;i++) {
    srand(i+100);

    for(j=0;j<2;j++) {
      r = rand();
      putchar(((j==0)?'A'-'a':0)+kchars[r&0xf]);

      putchar(vchars[(r&0xf0)>>4]);
      if(r&0x1000)
	putchar(kchars[(r&0xf00)>>8]);
    }

    if((r&0xe000) == 0xe000)
      printf(" %s", numbers[(r&0x30000)>>16]);

    puts("");
    
  }

  return 0;
}


