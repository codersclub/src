/*
 * objects.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include "objects.h"

OBJECT cube={
  "Cube",
  11,  /* this is the 'shield' radius */
 
  {
    /* scale factor */
    5,

    /* ---- edges ---- */

    /* number of edges */
     8,

    -6,-6,-6,
     6,-6,-6,
     6, 6,-6,
    -6, 6,-6,
    -6,-6, 6,
     6,-6, 6,
     6, 6, 6,
    -6, 6, 6,

    /* ---- polygons ---- */

    /* no of polygons */
    6,

    /* no of edges, color, edges */
    4, 1, 0,1,2,3,
    4, 2, 1,5,6,2,
    4, 3, 5,4,7,6,
    4, 4, 4,0,3,7,
    4, 5, 2,6,7,3,
    4, 6, 4,5,1,0
  }
}; 

OBJECT station1={
  "Coriolis",
  12,

  {
    /* ---- scale factor ---- */
    6,

    /* ---- edges ---- */
    
    /* number of edges */
    16,

    /* edge data */

    -8, 0, 8,
     0, 8, 8,
     8, 0, 8,
     0,-8, 8,

    -8,-8, 0,
    -8, 8, 0,
     8, 8, 0,
     8,-8, 0,

    -8, 0,-8,
     0, 8,-8,
     8, 0,-8,
     0,-8,-8,

    -4, 1, 8,
     4, 1, 8,
     4,-1, 8,
    -4,-1, 8,

    /* ---- polygons ---- */

    /* no of polygons */
    15,
    /* no of edges, color, edges */
    /* square sides */
    4, 3,  0, 1, 2, 3,
    4, 3,  6,10, 7, 2,
    4, 3, 11,10, 9, 8,
    4, 3,  8, 5, 0, 4,
    4, 3,  3, 7,11, 4,
    4, 3,  9, 6, 1, 5,

    /* triangle sides */
    3, 4,  2, 1, 6,
    3, 4,  0, 5, 1,
    3, 4,  4, 0, 3, 
    3, 4,  3, 2, 7,
    3, 4, 10,11, 7, 
    3, 4, 11, 8, 4,
    3, 4,  8, 9, 5,
    3, 4,  9,10, 6,

    /* docking duct */
    4, 6, 12,13,14,15
  }
}; 

OBJECT cobra={
  "Cobra Mk III",
  9,

  {
    /* scale factor */
    4,

    /* number of edges */
    20,

    /* hull top */
    -3, 0,-6,
     3, 0,-6,
    -8, 0, 0,
     0, 2,-1,
     8, 0, 0,
    -8, 0, 4,
    -6, 1, 4,
     0, 2, 4,
     6, 1, 4,

    /* hull (additional for bottom) */
     8, 0, 4,
     0,-2,-1,
    -6,-1, 4,
     0,-2, 4,
     6,-1, 4,
  
    /* engines */
    -3, 0, 4,
    -1, 1, 4,
    -1,-1, 4,

     1,-1, 4,
     1, 1, 4,
     3, 0, 4,

    /* ---- polygons ---- */

    /* polygons */
    21,

    /* top half */
    3, 1,   0, 1, 3,
    3, 2,   0, 3, 6,
    3, 2,   1, 8, 3,
    3, 3,   3, 8, 7,
    3, 3,   3, 7, 6,
    3, 1,   0, 6, 2,
    3, 1,   1, 4, 8,
    3, 3,   2, 6, 5,
    3, 3,   4, 9, 8,
    
    /* bottom half (darker) */
    3, 2,   1, 0,10,
    3, 3,  10, 0,11,
    3, 3,  13, 1,10,
    3, 4,  13,10,12,
    3, 4,  12,10,11,
    3, 2,  11, 0, 2,
    3, 2,   4, 1,13,
    3, 4,  11, 2, 5,
    3, 4,   9, 4,13,

    /* rear with engines */
    8, 5,   5, 6, 7, 8, 9,13,12,11,
    3, 3,  14,15,16,
    3, 3,  17,18,19
  }
};

OBJECT fox={
  "Fox Fighter",
  7,

  {
    /* scale factor */
    4,

    /* number of edges */
    28,

    /* hull middle plane */
    -3, 0,-2,
    -1, 0,-4,
     1, 0,-4,
     3, 0,-2,

     3, 0, 2,
     1, 0, 6,
    -1, 0, 6,
    -3, 0, 2,

    /* hull top plane */
    -1, 2,-2,
     1, 2,-2,
     1, 2, 0,
    -1, 2, 0,

    /* hull bottom plane */
    -1,-2,-2,
     1,-2,-2,
     1,-2, 0,
    -1,-2, 0,
  
    /* left stabilizer */
    -5,-2, 2,
    -5,-2,-2,
    -5, 0,-4,
    -5, 2,-2,
    -5, 2, 2,
    -5, 0, 4,

    /* right stabilizer */
     5,-2, 2,
     5,-2,-2,
     5, 0,-4,
     5, 2,-2,
     5, 2, 2,
     5, 0, 4,

    /* ---- polygons ---- */

    /* polygons */
    24,

    /* left stabilizer from left */
    6, 6,21,20,19,18,17,16,
    /* right stabilizer from right */
    6, 6,22,23,24,25,26,27,

    /* top half */
    4, 4, 1, 2, 9, 8,
    3, 3, 2, 3, 9,
    4, 4, 3, 4,10, 9,
    3, 1, 4, 5,10,
    4, 2, 5, 6,11,10,
    3, 1,11, 6, 7,
    4, 4, 7, 0, 8,11,
    3, 3, 0, 1, 8,
    4, 3, 8, 9,10,11,

    /* bottom half */
    4, 5,12,13, 2, 1,
    3, 4,13, 3, 2,
    4, 5,13,14, 4, 3,
    3, 4,14, 5, 4,
    4, 5,14,15, 6, 5,
    3, 4, 7, 6,15,
    4, 5,15,12, 0, 7,
    3, 4,12, 1, 0,
    4, 4,15,14,13,12,

    /* left stabilizer from right */
    6, 6,16,17,18,19,20,21,
    /* right stabilizer from left */
    6, 6,27,26,25,24,23,22,

    /* patterns on stabilizer */
    3, 3,21,17,19,
    3, 3,27,25,23
  }
};

OBJECT *objects[]={&cube, &station1, &cobra, &fox};


