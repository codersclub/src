/*
 * 2d.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __2D_H__
#define __2D_H__

#include "win2.h"
#include "sinus.h"
#include "space.h"

extern short *sintab, *costab;

extern int open_graphics_db(void);
extern void close_graphics_db(void);
extern void init_screen_from_db(int record);
extern void draw_msg(char *msg, Win2Color color);

#ifdef DEBUG
extern void debug_draw_msg(char *msg);
#endif

#endif
