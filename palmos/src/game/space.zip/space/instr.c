/*
 * instr.c - drawing of instruments
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#include <Pilot.h>

#include "win2.h"
#include "space.h"

#include "2d.h"
#include "3d.h"
#include "world.h"
#include "instr.h"

extern unsigned long hline_mask[];

void instr_put_speedometer(int x, int y, int value) {
  unsigned long  fill[2];
  unsigned long  *p=(unsigned long*)(screen_base + 40*y + 2*x);
  int i;

  for(i=0;i<2;i++) {
    if(value<1) fill[i]=0;
    else if(value>16) fill[i]=0xffffffff;
    else fill[i]=hline_mask[15+value];
    value -= 16;
  }

  for(i=0;i<4;i++) {
    *p++ = fill[0];
    *p++ = fill[1];
    p += 8;
  }
}

char small_numbers[10][5]={
  { 0x30,0xcc,0xcc,0xcc,0x30 },  /* 0 */
  { 0x0c,0x3c,0x0c,0x0c,0x0c },  /* 1 */
  { 0x30,0xcc,0x0c,0x30,0xfc },  /* 2 */
  { 0xf0,0x0c,0x30,0x0c,0xf0 },  /* 3 */
  { 0x0c,0x3c,0xcc,0xfc,0x0c },  /* 4 */
  { 0xfc,0xc0,0xf0,0x0c,0xf0 },  /* 5 */
  { 0x3c,0xc0,0xf0,0xcc,0x30 },  /* 6 */
  { 0xfc,0x0c,0x30,0x30,0x30 },  /* 7 */
  { 0x30,0xcc,0x30,0xcc,0x30 },  /* 8 */
  { 0x30,0xcc,0x3c,0x0c,0xf0 }   /* 9 */
};

char colors[]={0x00,0x55,0xaa,0xff};

void instr_put_int(int x, int y, unsigned int max, unsigned int num, int color) {
  unsigned char *p=screen_base + 40*y + x;
  int i,n;

  while(max>0) {
    i=num/max;
    for(n=0;n<5;n++) 
      *(p+40*n) = 
	(*(p+40*n) & ~small_numbers[i][n]) | 
	(small_numbers[i][n] & colors[color]);
    p++;

    num = num%max;
    max/=10;
  }
}

unsigned long radar_buffer[32*4];

#define RADAR_Y 125

/* save radar display */
void instr_radar_save(void) {
  int y;
  unsigned long *d=radar_buffer, *s = (unsigned long*)screen_base + 10*RADAR_Y + 3;

  for(y=0;y<32;y++) { *d++=*s++; *d++=*s++; *d++=*s++; *d++=*s++; s+=6; }
}

/* restore radar display */
void instr_radar_restore(void) {
  int y;
  unsigned long *s=radar_buffer, *d = (unsigned long*)screen_base + 10*RADAR_Y + 3;

  for(y=0;y<32;y++) { *d++=*s++; *d++=*s++; *d++=*s++; *d++=*s++; d+=6; }
}

char radar_bits[]={0xc0,0x30,0x0c,0x03};
char radar_head_bits[]={0xf0,0xfc,0x3f,0x0f};

/* add one object to the radar display */
void instr_radar_add(int x, int y, int z) {
  unsigned char *p=screen_base + 40*RADAR_Y + 40*16;
  int i;

  y /= (WORLD_VIS_RADIUS/14);
  z /= (WORLD_VIS_RADIUS/14);

  if((z+y > 15)||(z+y <-16)) return;
  
  x = 79 - x/(WORLD_VIS_RADIUS/18);

  if((x<79-16)||(x>80+16)) return;

  p += -40*z + x/4;
  x &= 3;

  /* draw vertical line */
  if(y>0) {
    for(i=0;i<y;i++) {
      *p |= radar_bits[x];
      p -= 40;
    }
  } else {
    for(i=0;i<-y;i++) {
      *p |= radar_bits[x];
      p += 40;
    }
  }

  /* draw head on top of line */
  *p |= radar_head_bits[x];
  if(x==0) *(p-1) |= 0x03;
  if(x==3) *(p+1) |= 0xc0;

}


