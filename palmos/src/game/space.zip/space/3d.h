/*
 * 3d.c
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __3D_H__
#define __3D_H__

#define VEC_MAX  (32767)
#define VEC_BITS (15)

#include "world.h"

/* 2d support stuff */
extern void init_3d(void);
extern void clear_3d_area(int starfield);
extern void draw_hline(int y, int start, int end, int color);
extern void draw_polygon(int *coo, int *edges, int num, int color);
extern void flip_screen(void);

/* the 3d stuff */
extern void scale_n_copy_object(int *dest, int *src, int num, int scale);
extern void rotate_object_edges(int edges, int *edge_data, short x[3], short y[3], short z[3]);
extern void translate_object_edges(int edges, int *edge_data, int off_x, int off_y, int off_z);
extern void project_object_edges(int edges, int *edge_data);
extern void disp_object(int *polygon, int *edges);
extern void rotate_object_axis(MAPPED_OBJECT *obj, int axis, unsigned short rot);
extern void rotate_object_axis_me(MAPPED_OBJECT *obj, int axis, unsigned short rot);
extern void move_object(MAPPED_OBJECT *obj, int offset);
extern void move_object_me(MAPPED_OBJECT *obj, int offset);

extern unsigned char *screen_base;

#endif
