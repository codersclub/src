/*
 * sinus.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#define SINUS_BITS 11
#define COSINUS_OFFSET (1<<(SINUS_BITS-2))
#define SIN_SHIFT (16-SINUS_BITS)
