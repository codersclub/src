/*
 * space.h
 *
 * August 31, 1999
 *
 * Written and copyright 1999 by Till Harbaum
 * Distributed under the GNU General Public License; see the README file.
 * This code comes with NO WARRANTY.
 */

#ifndef __ELITE_H__
#define __ELITE_H__
#define CREATOR     'SPac'
#define DB_TYPE     'GRFX'

#ifndef NO_PALM
#define DEBUG

#ifdef DEBUG
#include "2d.h"
#include "world.h"

typedef struct {
  int forward;
  int roll_x;
  int roll_z;
} MOVEMENT;

/* game states */
#define STATE_MAIN 0
#define STATE_3D   1
extern char game_state;

extern MAPPED_OBJECT me;  /* player position in 3d game */
extern MOVEMENT me_move;  /* player movement */

extern MOVEMENT me_move;  /* player movement */
extern int start_game(void);

/* sorry you CW guys, i really don't know, how to do this for your compiler */
#define DEBUGF(format, args...) { char tmp[80]; StrPrintF(tmp, format, ## args); debug_draw_msg(tmp); }
#endif

#endif
#endif
