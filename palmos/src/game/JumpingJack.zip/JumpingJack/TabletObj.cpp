#include <Pilot.h>
#include "TabletObj.h"
#include "DrawSurface.h"

CTabletObject::CTabletObject()
{
	m_pChar=0;
}

CTabletObject::~CTabletObject()
{
	if(m_pChar!=0) delete[] m_pChar;
}

void CTabletObject::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow || !m_pChar) return;
	
	WinHandle oldDrawWinH = WinGetDrawWindow();
	WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());
	
	FontID oldFontID = FntSetFont(tabletFontID);
	
	int textLen=StrLen(m_pChar);
	int textHeight = FntLineHeight();
	int textWidth = FntCharsWidth((char *)m_pChar, textLen);

	CArea TabletArea((160-textWidth-2 * PaddingHoriz) / 2, (160-PaddingVert-2 * textHeight) / 2 + 1, textWidth + 2 * PaddingHoriz, textHeight + 2 * PaddingVert-1);

	RectangleType r0={{TabletArea.pos.x,TabletArea.pos.y},{TabletArea.size.cx,TabletArea.size.cy}};
	WinEraseRectangle(&r0,0);	
	
	RectangleType r1={{TabletArea.pos.x+1,TabletArea.pos.y+1},{TabletArea.size.cx-2,TabletArea.size.cy-2}};
	WinDrawRectangleFrame(rectangleFrame,&r1);
	WinDrawChars(m_pChar, textLen, TabletArea.pos.x+PaddingHoriz, TabletArea.pos.y+PaddingVert);
	
	FntSetFont(oldFontID);	
	WinSetDrawWindow (oldDrawWinH);	
	
	if(InvalidateArea) m_pDstSurf->addFreshArea(TabletArea);
}

void CTabletObject::show(bool bShow)
{
	m_bShow=bShow;
}
	
void CTabletObject::create(const char *str, bool bShow)
{
	setText(str);
	show(bShow);
}

void CTabletObject::setText(const char *str)
{
	if(m_pChar!=0) 
	{
		delete[] m_pChar;
		m_pChar=0;
	}
	
	if(str==0) return;
	
	m_pChar=new char[StrLen(str)+1];
	
	StrCopy(m_pChar,str);
}
