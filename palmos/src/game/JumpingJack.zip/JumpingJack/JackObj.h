#ifndef _INCLUDE_JACKOBJ_H_
#define _INCLUDE_JACKOBJ_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "Animation.h"
#include "Sound.h"
#include "Timer.h"
#include "State.h"

const int InitialXPos=72;
const int InitialYPos=144;

class CGame;
class CAPGame;

class CJackObject: public CScreenObject 
{
private:

	bool m_bShow;
	int n_NKnockDownCycles;
	
private:

	enum EState {stateStanding,stateRunningLeft,stateRunningRight,stateJump,stateFalling,stateFly,stateFlyDown,stateKnockDown,stateChampion,stateDying};
	EState m_CurrentState;
	
private: // animations

	CAnimation m_AnimStanding;
	CAnimation m_AnimRunningLeft;
	CAnimation m_AnimRunningRight;
	CAnimation m_AnimJump;
	CAnimation m_AnimFall;
	CAnimation m_AnimFly;	
	CAnimation m_AnimFlyDown;
	CAnimation m_AnimKnockDown;
	CAnimation m_AnimChampion;
	CAnimation m_AnimDying;	
	
	CAnimation *m_pCurrentAnimation;
	
	void setAnimation(CAnimation *pNewAnimation);
	
	int m_NKnockDownInsensCounter;
	
public:

	void create(bool bShow=true);
	void create(CState &State, bool bShow=true);
	
	void resetObject(void);
	
	enum EActionResult {arNone,arNewHole,arLevelFinished,arLifeLost,arGameOver};
	EActionResult action(CAPGame *pApGame);
	
	int getCurrentLevel(int ypos);
	EState getState() {return m_CurrentState;}
	void getCurrentAnmationState(int &NFrame, int &NDraw);
	
public: // overloaded virtuals

	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	virtual void setPos(int x, int y);	
	virtual CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);		
	
private:

	void setStanding();
	void setRunningLeft();
	void setRunningRight();
	void setJump();	
	void setFalling();
	void setFly();
	void setFlyDown();	
	void setKnockDown();
	void setChampion();	
	void setDying();		

	void processStanding(CAPGame *pApGame);
	void processRunningLeft(CAPGame *pApGame);
	void processRunningRight(CAPGame *pApGame);
	bool processJump(CAPGame *pApGame);	
	bool processFalling(CAPGame *pApGame);
	void processFly(CAPGame *pApGame);
	bool processFlyDown(CAPGame *pApGame);
	bool processKnockDown(CAPGame *pApGame);
	bool processChampion(CAPGame *pApGame);
	bool processDying(CAPGame *pApGame);
	
	bool checkNastyHit(CAPGame *pApGame);

public: // construction/destruction

	CJackObject();
};

#endif // _INCLUDE_JACKOBJ_H_