#ifndef _INCLUDE_APGAME_H_
#define _INCLUDE_APGAME_H_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "AP_Part.h"
#include "JackObj.h"
#include "Platform.h"
#include "Creature.h"
#include "LifeIndic.h"
#include "LevelIndic.h"
#include "TabletObj.h"
#include "State.h"

class CAPGame: public CApplicationPart
{
private:

	enum ECurState {gsPlaying,gsPause,gsGameOver};
	
	ECurState m_CurrentState;
	bool m_StateChanged;
	bool m_bWaitRelease;
	
	CTimer m_GameOverTimer;
	CTimer m_GameOverInsensTimer;

public:

	int m_CurrentLevel;
	int m_LivesLeft;
	
public:

	int m_CreatureIndex[MaxCreaturesNumber];
	int m_NCurrentCreatures;

public:

	CJackObject m_Jack;
	CPlatformObj m_Platform;
	CCreature m_Creature[MaxCreaturesNumber];
	CLifeIndicator m_LifeIndicator;
	CLevelIndicator m_LevelIndicator;
	CTabletObject m_InfoTablet;

public:

	bool action(CApplicationPart::ECurrentPart &CurrentPart);	
	void draw(bool InvalidateArea=true);	
	CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
public:

	void create(int NLevel, int NLivesLeft);

	void create(CState &State);
	void saveState(CState &State);
		
	void startLevel(int NLevel);
	void createCreatureHeap(int NCreatures);
};

#endif // _INCLUDE_APGAME_H_