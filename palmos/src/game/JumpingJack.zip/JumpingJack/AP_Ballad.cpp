#include <Pilot.h>
#include "AP_Ballad.h"
#include "DrawSurface.h"
#include "Input.h"

char *balladString[]=
{
	"A daring explorer named Jack",
	"Once found a peculiar track",
	"There were dangers galore",
	"Even holes in the floor",
	"So he kept falling flat on his back",	
	"Quite soon he got used to the place",
	"He could jump to escape from the chase",
	"But without careful thought",
	"His leaps came to nought",
	"And he left with a much wider face",
	"Things seemed just as bad as could be",
	"Hostile faces were all Jack could see",
	"He tried to stay calm",
	"And to come to no harm",
	"But more often got squashed like a flea",
	"By now Jack was in a great flap",
	"He felt like a rat in a trap",
	"If only he'd guessed",
	"That he could soon rest",
	"After jumping the very last gap"
};

void CLevelTablet::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow || !m_pChar) return;
	
	WinHandle oldDrawWinH = WinGetDrawWindow();
	WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());
	
	FontID oldFontID = FntSetFont(tabletFontID);
	
	int textLen=StrLen(m_pChar);
	int textHeight = FntLineHeight();
	int textWidth = FntCharsWidth((char *)m_pChar, textLen);

	CArea TabletArea((160-textWidth-2 * PaddingHoriz) / 2, 10, textWidth + 2 * PaddingHoriz, textHeight + 2 * PaddingVert);

	RectangleType r0={{TabletArea.pos.x,TabletArea.pos.y},{TabletArea.size.cx,TabletArea.size.cy}};
	WinEraseRectangle(&r0,0);	
	
	RectangleType r1={{TabletArea.pos.x+1,TabletArea.pos.y+1},{TabletArea.size.cx-2,TabletArea.size.cy-2}};
	WinDrawRectangleFrame(rectangleFrame,&r1);
	WinDrawChars(m_pChar, textLen, TabletArea.pos.x+PaddingHoriz, TabletArea.pos.y+PaddingVert);

	FntSetFont(largeBoldFont);
	
	WinDrawChars("The Ballad of Jumping Jack", sizeof("The Ballad of Jumping Jack")-1, 10, 40);	
	WinDrawLine(12,57,145,57);
	
	FntSetFont(oldFontID);	
	WinSetDrawWindow (oldDrawWinH);	
	
	if(InvalidateArea) m_pDstSurf->addFreshArea(TabletArea);
}

CDrawSurface *CAPBallad::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
	m_LevelTablet.setDrawSurface(pNewSurface);
	m_BalladObj.setDrawSurface(pNewSurface);
	
	drawStatic();

	return pRetVal;
}

void CAPBallad::draw(bool InvalidateArea)
{
	m_BalladObj.draw(InvalidateArea);
}

bool CAPBallad::action(CApplicationPart::ECurrentPart &CurrentPart)
{
	m_BalladObj.action();
		   
	if(Input.isKeyPressed(CInput::KeyLeft) || Input.isKeyPressed(CInput::KeyRight) || Input.isKeyPressed(CInput::KeyPause) || Input.isKeyPressed(CInput::KeyPause2))
	{
		if(m_Level<20)
		{
			CurrentPart=partGame;
		}
		else
		{
			CurrentPart=partIntro;		
		}
			
		return true;
	}

	m_GPTimer.setTimer(100);	
	m_GPTimer.sleep();
			
	return false;
}

void CAPBallad::create(int NLevel, bool bShow)
{
	m_Level=min(max(NLevel,1),20);	

	if(m_Level==20)
	{
		m_LevelTablet.create("WELL DONE!!!");	
	}
	else
	{
		char text[]="LEVEL 00 COMPLETED";
		if(m_Level >= 10)
		{
			StrIToA(text + sizeof("LEVEL ") - 1, m_Level);
		}
		else
		{
			StrIToA(text + sizeof("LEVEL 0") - 1, m_Level);	
		}	
		
		*(text + sizeof("LEVEL 00") - 1)=' ';
		m_LevelTablet.create(text);
	}
	
	m_BalladObj.create(m_Level,false);
	
	show(bShow);
}

void CAPBallad::drawStatic()
{
	m_LevelTablet.draw(false);
}

void CAPBallad::createWhole(int NLevel, bool bShow)
{
	m_Level=min(max(NLevel,1),20);	

	if(m_Level==20)
	{
		m_LevelTablet.create("WELL DONE!!!");	
	}
	else
	{
		char text[]="LEVEL 00 COMPLETED";
		if(m_Level >= 10)
		{
			StrIToA(text + sizeof("LEVEL ") - 1, m_Level);
		}
		else
		{
			StrIToA(text + sizeof("LEVEL 0") - 1, m_Level);	
		}	
		
		*(text + sizeof("LEVEL 00") - 1)=' ';
		m_LevelTablet.create(text);
	}
	
	m_BalladObj.create(m_Level,true);
	
	show(bShow);
}