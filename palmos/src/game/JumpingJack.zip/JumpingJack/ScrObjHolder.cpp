#include "ScrObjHolder.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CScreenObjectHolder::CScreenObjectHolder()
{
	buidAllUnused();
}

void CScreenObjectHolder::buidAllUnused()
{
	m_pUsedLinks=m_pCurrentUsedLink=0;
	m_pUnusedLinks=m_Links;
	
	for(int i=0;i<MaxScrObjUsed-1;i++)
	{
		m_Links[i].m_pNextLink=&m_Links[i+1];
	}
	
	m_Links[MaxScrObjUsed-1].m_pNextLink=0;
}

CScreenObject* CScreenObjectHolder::getFirstObject(void)
{
	m_pCurrentUsedLink=m_pUsedLinks;

	if(m_pCurrentUsedLink)
	{
		return m_pCurrentUsedLink->m_pScreenObject;
	}
	else
		return 0;
	
}

CScreenObject* CScreenObjectHolder::getNextObject(void)
{
	if(m_pCurrentUsedLink)
	{
		m_pCurrentUsedLink=m_pCurrentUsedLink->m_pNextLink;
		
		if(m_pCurrentUsedLink)
		{
			return m_pCurrentUsedLink->m_pScreenObject;
		}
		else
			return 0;
	}
	else
		return 0;
}

CScreenObjectHolder::TLink *CScreenObjectHolder::getUnused(void)
{
	if(!m_pUnusedLinks) return 0; // ��� ��������� ����� ������������
	
	TLink *pTempLink=m_pUnusedLinks;	
	m_pUnusedLinks=m_pUnusedLinks->m_pNextLink;
	
	pTempLink->m_pNextLink=m_pUsedLinks;
	m_pUsedLinks=pTempLink;
	
	return m_pUsedLinks;
}

void CScreenObjectHolder::addObject(CScreenObject *pNewObject)
{
	TLink *pNewLink=getUnused();
	pNewLink->m_pScreenObject=pNewObject;
}

void CScreenObjectHolder::deleteObject(CScreenObject *pDelObject)
{
	CScreenObjectHolder::TLink *pCurrLink=m_pUsedLinks;
	CScreenObjectHolder::TLink *pPrevLink=0;
	
	while(pCurrLink)
	{
		if(pCurrLink->m_pScreenObject==pDelObject)
		{
			freeUsed(pCurrLink,pPrevLink);
			break;
		}
		
		pPrevLink=pCurrLink;
		pCurrLink=pCurrLink->m_pNextLink;
	}
}

void CScreenObjectHolder::freeUsed(TLink *pUsedLink, TLink *pPrevLink)
{
	if(pPrevLink)
	{
		pPrevLink->m_pNextLink=pUsedLink->m_pNextLink;
	}
	else
	{
		m_pUsedLinks=pUsedLink->m_pNextLink;
	}
	
	pUsedLink->m_pNextLink=m_pUnusedLinks;
	m_pUnusedLinks=pUsedLink;
}



