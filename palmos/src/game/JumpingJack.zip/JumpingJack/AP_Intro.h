#ifndef _INCLUDE_APINTRO_H_
#define _INCLUDE_APINTRO_H_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "Sprite.h"
#include "Animation.h"
#include "AP_Part.h"
#include "Timer.h"

const int NLettersNumber=11;
const int NFramesNumber=11;
const int TrackPosY=122;
const int StopPosX=74;

class CAPIntro: public CApplicationPart
{
private:

	enum EState {stateRunRight,stateRunLeft,stateStanding};
	EState m_CurrentState;
	bool m_bRunToStop;	
	bool m_firstDrawLetters;
	int m_Note;

private:

	CAnimation m_Letters[NLettersNumber];	
	CSprite m_BottomSprite[2];
	int m_CurrentBottomLineIndex;
	CTimer m_ShowTimer;
	
	CAnimation m_RunLeftAnim;
	CAnimation m_RunRightAnim;	
	CAnimation m_StandingAnim;
				
private:

	void makePath(TAnimFrame *pFrames, int NFrames, int m_FrameID, int xend, int yend, int xstart=68, int ystart=122);

public:

	bool action(CApplicationPart::ECurrentPart &CurrentPart);	
	void draw(bool InvalidateArea=true);	
	CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
public:

	void create();
		
public:
	
	CAPIntro();
	virtual ~CAPIntro();	
};

#endif // _INCLUDE_APINTRO_H_