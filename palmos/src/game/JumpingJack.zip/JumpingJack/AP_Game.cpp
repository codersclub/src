#include <Pilot.h>
#include "AP_Game.h"
#include "Input.h"
#include "Game.h"

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/
	
CDrawSurface *CAPGame::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);	
	
	m_Jack.setDrawSurface(pNewSurface);
	m_Platform.setDrawSurface(pNewSurface);

	
	for(int i=0;i<MaxCreaturesNumber;i++)
	{
		m_Creature[i].setDrawSurface(pNewSurface);
	}
	
	m_LifeIndicator.setDrawSurface(pNewSurface);
	m_LevelIndicator.setDrawSurface(pNewSurface);
	
	m_LifeIndicator.draw(false); 	
	m_LevelIndicator.draw(false);
	m_InfoTablet.setDrawSurface(pNewSurface);	
	
	return pRetVal;
}

bool CAPGame::action(CApplicationPart::ECurrentPart &CurrentPart)
{
	switch(m_CurrentState)
	{
		case gsPlaying:
		{
			if(m_StateChanged)
			{
				m_StateChanged=false;
			}
			
			if(m_bWaitRelease)
			{
				if(!Input.isKeyPressed(CInput::KeyPause) && !Input.isKeyPressed(CInput::KeyPause2))
				{			
					m_bWaitRelease=false;
					m_InfoTablet.show(false);
					
					CAnimation::setPauseMode(false);										
				}				
			}	
			else
			{
				if(Input.isKeyPressed(CInput::KeyPause) || Input.isKeyPressed(CInput::KeyPause2))
				{			
					m_CurrentState=gsPause;
					m_StateChanged=true;
					m_bWaitRelease=true;
					m_InfoTablet.show(true);
					
					CAnimation::setPauseMode(true);						
				}							
			}					

			if(!m_bWaitRelease)
			{				
				m_Platform.action();
			
				switch(m_Jack.action(this))
				{
					case CJackObject::arNewHole:
					
						m_Platform.addHoleRandom();
						
					break;		
					
					case CJackObject::arLevelFinished:
					{
						CurrentPart=partBallad;
					}
					return true;					
			
					case CJackObject::arLifeLost:
					
						if(m_LivesLeft > 0) 
						{
							m_LifeIndicator.setNLives(--m_LivesLeft);
							pGame->m_State.m_LivesLeft=m_LivesLeft;
						}
					
					break;				
					
					case CJackObject::arGameOver:
						
						m_CurrentState=gsGameOver;
						m_StateChanged=true;						
								
					break;				
				}
				
				for(int i=0;i<m_NCurrentCreatures;i++) 
				{
			    	m_Creature[m_CreatureIndex[i]].action();
			    }		    
			}
		}
		break;
		
		case gsPause:
		{
			if(m_StateChanged)
			{
				m_InfoTablet.setText("PAUSED");
				m_InfoTablet.show(true);
				m_StateChanged=false;
			}
			
			if(m_bWaitRelease)
			{
				if(!Input.isKeyPressed(CInput::KeyPause) && !Input.isKeyPressed(CInput::KeyPause2))
				{
					m_bWaitRelease=false;				
				}
			}
			else
			{
				if(Input.isKeyPressed(CInput::KeyPause) || Input.isKeyPressed(CInput::KeyPause2))
				{						
					m_CurrentState=gsPlaying;
					m_bWaitRelease=true;
					m_StateChanged=true;
				}			
			}
		}				
		
		break;
		
		case gsGameOver:
		{
			if(m_StateChanged)
			{
				m_InfoTablet.setText("GAME OVER");
				m_InfoTablet.show(true);
				m_GameOverTimer.setTimer(5000);
				m_GameOverInsensTimer.setTimer(1000);
				m_StateChanged=false;				
			}		
			
			if(m_GameOverTimer.isFinished() || (m_GameOverInsensTimer.isFinished() && Input.isKeyPressed(CInput::KeyAny)))
			{
				CurrentPart=partIntro;
				return true;
			}
			
			m_Platform.action();		
			
			for(int i=0;i<m_NCurrentCreatures;i++) 
			{
		    	m_Creature[m_CreatureIndex[i]].action();
		    }		    				
		}
		break;
	}

	return false;
}

void CAPGame::draw(bool InvalidateArea)
{
	m_Platform.draw(InvalidateArea);
	m_Jack.draw(InvalidateArea);
	
	for(int i=0;i<m_NCurrentCreatures;i++) 
	{
    	m_Creature[m_CreatureIndex[i]].draw(InvalidateArea);
    }
    
	m_InfoTablet.draw(InvalidateArea);    
}

void CAPGame::startLevel(int NLevel)
{
	m_Jack.resetObject();	
	m_Platform.resetObject();	
		
	createCreatureHeap(max(min(NLevel-1,5),0));
}

void CAPGame::createCreatureHeap(int NCreatures)
{
	m_NCurrentCreatures=NCreatures;
	
	bool bUsed[MaxCreaturesNumber];
	MemSet(bUsed,sizeof(bUsed),0);
	
	for(int i=0;i<NCreatures;i++)
	{
		int NNewCreature=((SysRandom(0) * (long)(MaxCreaturesNumber)) / sysRandomMax) % MaxCreaturesNumber;
		
		while(bUsed[NNewCreature])
		{
			NNewCreature=(NNewCreature+1) % MaxCreaturesNumber;
		}
		
		bUsed[NNewCreature]=true;
		
		m_CreatureIndex[i]=NNewCreature;
		
		int NStartPos=((SysRandom(0) * (long)3) / sysRandomMax) % 3;
		m_Creature[m_CreatureIndex[i]].setPlatform(NNewCreature,NStartPos);
	}
}

void CAPGame::create(CState &State)
{
	m_Jack.create(State);
	m_Platform.create(State.m_HolesCompensation,State.m_NHoles,State.m_Holes);		
	
	for(int i=0;i<MaxCreaturesNumber;i++) 
	{
		m_Creature[i].create(i);
	}

	m_NCurrentCreatures=State.m_NCreatures;
	for(int i=0;i<m_NCurrentCreatures;i++)
	{
		m_CreatureIndex[i]=State.m_Creatures[i].m_CreatureIndex;
		m_Creature[m_CreatureIndex[i]].setPos(State.m_Creatures[i].m_CreatureXPos,State.m_Creatures[i].m_CreatureYPos);
		m_Creature[m_CreatureIndex[i]].setPlatformByPos();
		m_Creature[m_CreatureIndex[i]].setDrawCycles(State.m_Creatures[i].m_CreatureNCycles);
	}
	
	m_InfoTablet.create();
	m_InfoTablet.show(false);	
	
	m_LifeIndicator.create(State.m_LivesLeft,3,4);
	m_LevelIndicator.create(State.m_Level,111,2);
	
	m_CurrentState=(CAPGame::ECurState)State.m_GameState;
	m_StateChanged=true;
	
	CAnimation::setPauseMode(State.m_GameState==CAPGame::gsPause);

	m_LivesLeft=State.m_LivesLeft;	
	m_CurrentLevel=State.m_Level;
		
	m_bWaitRelease=false;	
}

void CAPGame::create(int NLevel, int NLivesLeft)
{
	m_Jack.create();
	m_Platform.create();	
	
	for(int i=0;i<MaxCreaturesNumber;i++) 
	{
		m_Creature[i].create(i);
	}

	m_InfoTablet.create();
	m_InfoTablet.show(false);
	
	m_LifeIndicator.create(NLivesLeft,3,4);
	m_LevelIndicator.create(NLevel,111,2);	
	
	startLevel(NLevel);
	
	m_CurrentLevel=NLevel;
	m_LivesLeft=NLivesLeft;
	
	m_CurrentState=gsPlaying;
	m_StateChanged=true;
	m_bWaitRelease=false;	
}

void CAPGame::saveState(CState &State)
{
	TCreatureDescriptor m_Creatures[5];	
	for(int i=0;i<m_NCurrentCreatures;i++)
	{
		m_Creatures[i].m_CreatureIndex=m_CreatureIndex[i];
		m_Creatures[i].m_CreatureXPos=m_Creature[m_CreatureIndex[i]].pos.x;
		m_Creatures[i].m_CreatureYPos=m_Creature[m_CreatureIndex[i]].pos.y;
		m_Creatures[i].m_CreatureNCycles=m_Creature[m_CreatureIndex[i]].getDrawCycles();
	}
	
	THoleDescriptor Holes[6];
	int Compensation, NHoles;
	m_Platform.getState(Compensation, NHoles, Holes);	
			
	int NFrame,NDraw;
	m_Jack.getCurrentAnmationState(NFrame, NDraw);
	State.save(savedStateGame,m_CurrentLevel,m_LivesLeft,m_CurrentState,m_Jack.pos.x,m_Jack.pos.y,m_Jack.getState(),NFrame,NDraw,m_NCurrentCreatures,m_Creatures,Compensation, NHoles,Holes);
}


