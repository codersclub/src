#ifndef _INCLUDE_TABLETOBJ_H_
#define _INCLUDE_TABLETOBJ_H_

#include "ScrObject.h"

const int PaddingHoriz = 9;
const int PaddingVert  = 5;

#define tabletFontID boldFont

class CTabletObject: public CScreenObject
{
protected:

	bool m_bShow;
	char *m_pChar;

public:

	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	
public:

	void create(const char *str=NULL, bool bShow=true);
	void setText(const char *str=NULL);
	
public:

	CTabletObject();
	virtual ~CTabletObject();
};

#endif