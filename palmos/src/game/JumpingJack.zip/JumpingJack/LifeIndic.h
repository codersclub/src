#ifndef _INCLUDE_LIFEINDIC_H_
#define _INCLUDE_LIFEINDIC_H_

#include "Sprite.h"

const int NMaxLives=6;
const int ShiftStep=8;

class CLifeIndicator: public CScreenObject
{
private:

	bool m_bShow;	
	CSprite m_Sprite[NMaxLives];
	int m_NLives;
	
public:
	
	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	virtual void setPos(int x, int y);
	virtual CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
public:

	void create(int NLives, int x, int y, bool bShow=true);
	void setNLives(int NLives);
};

#endif