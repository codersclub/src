#ifndef _INCLUDE_SOUNDPLAYER_H_
#define _INCLUDE_SOUNDPLAYER_H_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

class CSoundPlayer
{
private:

	bool m_bInitialized;
	int m_Volume;

public:	

	CSoundPlayer();
	
	void init(int InitVolume);
	void playSound(int Freq, int Duration);
	void playNote(int Note, int Duration);
	void playBoom(int Duration);
	void playNasty(int Duration);	
	void setVolume(int Volume);
};

#endif // _INCLUDE_SOUNDPLAYER_H_