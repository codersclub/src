#include <Pilot.h>
#include "Input.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CInput Input;

bool CInput::isKeyPressed(EKey Key)
{
	switch(Key)
	{
		case KeyLeft:
		return KeyCurrentState() & keyBitHard2;
		
		case KeyRight:
		return KeyCurrentState() & keyBitHard3;
		
		case KeyUp:
		return KeyCurrentState() & keyBitPageUp;
		
		case KeyDown:
		return KeyCurrentState() & keyBitPageDown;
		
		case KeyPause:
		return KeyCurrentState() & keyBitHard4;
		
		case KeyPause2:
		return KeyCurrentState() & keyBitHard1;		
		
		case KeyAny:
		return KeyCurrentState() & (keyBitHard1 | keyBitHard2 | keyBitHard3 | keyBitHard4 | keyBitPageUp | keyBitPageDown);
	}
	
	return false;
}