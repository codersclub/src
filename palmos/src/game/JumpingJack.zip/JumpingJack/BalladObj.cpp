#include <Pilot.h>
#include "BalladObj.h"
#include "AP_Ballad.h"
#include "DrawSurface.h"
#include "Input.h"
#include "Game.h"

const int LineHeight=14;
const int ScrollStep=7;

void CBalladObject::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow) return;
	
	WinHandle oldDrawWinH=WinGetDrawWindow();
	WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());
	
	FontID oldFontID = FntSetFont(stdFont);

	RectangleType r={{0,75},{160,5*LineHeight}};
	WinSetClip(&r);
	if(InvalidateArea) m_pDstSurf->addFreshArea(r);
	
	if(m_bPolzet)	
	{
		int NLines=(m_NLevel-1) % 5;   // ����� ����� ���������� ��������, �� ������ ����� �����������
		int NFirstLine=m_NLimeric * 5; // ����� ������ ������ �������� ��������
	
		for(int i=0;i<NLines;i++)
		{
			int LinePosX=(160-FntCharsWidth(balladString[NFirstLine + i], StrLen(balladString[NFirstLine + i]))) / 2 + 1;
			WinDrawChars(balladString[NFirstLine + i],StrLen(balladString[NFirstLine + i]),r.topLeft.x+LinePosX,r.topLeft.y + i * LineHeight);
		}
		
		if(m_NLettersShown < StrLen(balladString[NFirstLine+NLines])) 
		{		
			m_NLettersShown++;			
		}
		else
		{
			m_bPolzet=false;
		}		
		
		int LinePosX=(160-FntCharsWidth(balladString[NFirstLine+NLines], StrLen(balladString[NFirstLine+NLines]))) / 2 + 1;
		WinDrawChars(balladString[NFirstLine+NLines],m_NLettersShown,r.topLeft.x+LinePosX,r.topLeft.y + NLines * LineHeight);				
	}
	else
	{
		int NLines=(m_NLevel-1) % 5 + 1;   // ����� ����� ���������� ��������, ������ ����� �����������
		int NFirstLine=m_NLimeric * 5;     // ����� ������ ������ �������� ��������					
		int NCurrentLimericLines = m_NLimeric==(m_NLevel-1) / 5 ? NLines : 5;
		
		for(int i=0;i<NCurrentLimericLines;i++)
		{
			int LinePosX=(160-FntCharsWidth(balladString[NFirstLine + i], StrLen(balladString[NFirstLine + i]))) / 2 + 1;
			WinDrawChars(balladString[NFirstLine + i],StrLen(balladString[NFirstLine + i]),r.topLeft.x+LinePosX,r.topLeft.y + i * LineHeight);
		}		
	}
		
	WinResetClip();
	
	if(m_NLimeric > 0)
	{
		RectangleType r2={{72,67},{3,3}};	
		RectangleType r3={{72,67},{1,1}};	
		for(int i=0;i<3;i++)
		{
			if(InvalidateArea) m_pDstSurf->addFreshArea(r2);
			
			WinDrawRectangle(&r2,1);
			r3.topLeft=r2.topLeft;
			r2.topLeft.x+=6;
			
			WinEraseRectangle(&r3,1);
			
			r3.topLeft.x+=2;			
			WinEraseRectangle(&r3,1);
			
			r3.topLeft.x-=1;
			r3.topLeft.y+=3;			
			WinDrawRectangle(&r3,1);			
			
			if(InvalidateArea) m_pDstSurf->addFreshArea(r3);			
		}
	}
	
	if(m_NLimeric!=(m_NLevel-1) / 5)
	{
		RectangleType r2={{72,150},{3,3}};	
		RectangleType r3={{72,150},{1,1}};	
		for(int i=0;i<3;i++)
		{
			if(InvalidateArea) m_pDstSurf->addFreshArea(r2);
			
			WinDrawRectangle(&r2,1);
			r3.topLeft=r2.topLeft;
			r2.topLeft.x+=6;
			
			WinEraseRectangle(&r3,1);
			
			r3.topLeft.x+=2;			
			WinEraseRectangle(&r3,1);
			
			r3.topLeft.x-=1;
			r3.topLeft.y+=3;			
			WinDrawRectangle(&r3,1);			
			
			if(InvalidateArea) m_pDstSurf->addFreshArea(r3);			
		}
	}
	else if(m_NLevel!=20)
	{
		int LinePosX=(160-FntCharsWidth("(to be continued...)", sizeof("(to be continued...)")-1)) / 2 + 1;
		WinDrawChars("(to be continued...)",sizeof("(to be continued...)")-1,r.topLeft.x+LinePosX,145);
		if(InvalidateArea) m_pDstSurf->addFreshArea(CArea(0,145,160,14));
	}

		
	FntSetFont(oldFontID);	
	WinSetDrawWindow (oldDrawWinH);	
}

void CBalladObject::show(bool bShow)
{
	m_bShow=bShow;
}

CDrawSurface *CBalladObject::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
		
	return pRetVal;
}

void CBalladObject::create(int NLevel, bool bCreateWhole, bool bShow)
{
	NLevel=max(min(NLevel,20),1);
	
	m_NLevel=NLevel;
	
	if(!bCreateWhole)
	{
		m_NLettersShown=0;		
	}
	else
	{
		m_NLettersShown=StrLen(balladString[NLevel-1]);
	}
	
	m_NLimeric=(NLevel - 1) / 5; // �� ����
	m_bPolzet=true;
	m_RepeatTimer.reset();

	show(bShow);
}

void CBalladObject::action(void)
{	
	if(!Input.isKeyPressed(CInput::KeyUp) && !Input.isKeyPressed(CInput::KeyDown))
	{
		m_RepeatTimer.reset();
	}
	else
	{
		if(m_RepeatTimer.isFinished()) 
		{			
			if(Input.isKeyPressed(CInput::KeyUp))
			{
				if(m_NLimeric > 0)
				{
					m_NLimeric--;
					m_bPolzet=false;
					m_RepeatTimer.setTimer(300);
				}
				else
				{
					pGame->m_SoundPlayer.playSound(808,50);
				}
			}
			else if(Input.isKeyPressed(CInput::KeyDown) )
			{
				if(m_NLimeric < (m_NLevel - 1) / 5)
				{
					m_NLimeric++;
					m_RepeatTimer.setTimer(300);				
				}
				else
				{
					pGame->m_SoundPlayer.playSound(808,50);
				}
			}		
		}
	}
}