#ifndef _INCLUDE_APBALLAD_H_
#define _INCLUDE_APBALLAD_H_

#include "AP_Part.h"
#include "TabletObj.h"
#include "BalladObj.h"

extern char *balladString[];

const int NBalladLines=20;

class CLevelTablet: public CTabletObject
{
public:
	virtual void draw(bool InvalidateArea=true);	
};

class CAPBallad: public CApplicationPart
{
private:

	int m_Level;
	CLevelTablet m_LevelTablet;
	CBalladObject m_BalladObj;
	CTimer m_GPTimer;

public:

	bool action(CApplicationPart::ECurrentPart &CurrentPart);	
	void draw(bool InvalidateArea=true);	
	CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
public:

	void create(int NLevel, bool bShow=true);
	void createWhole(int NLevel, bool bShow=true);	
	
	void drawStatic();
	int getLevel() {return m_Level;}
};

#endif