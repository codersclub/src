#ifndef _INCLUDE_CREATURE_H_
#define _INCLUDE_CREATURE_H_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "ScrObject.h"
#include "Animation.h"

const int MaxCreaturesNumber=5;
const int InitialCreatureXPos=188;

class CCreature: public CScreenObject
{
private:
	
	bool m_bShow;
	CAnimation m_Animation;	
	int m_NDrawCycles;
	int m_CurrentPlatform;
	
public:

	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	virtual void setPos(int x, int y);		
	
public:

	void create(int NCreature, bool bShow=true);
	void action(void);	
	void setPlatform(int NPlatform, int Offset);
	void setPlatformByPos();
	void setDrawCycles(int NCycles) {m_NDrawCycles=NCycles;}
	int getDrawCycles() {return m_NDrawCycles;}	
	
	virtual CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);
};

#endif // _INCLUDE_CREATURE_H_