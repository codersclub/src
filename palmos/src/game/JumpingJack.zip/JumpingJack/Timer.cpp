#include <Pilot.h>
#include "Timer.h"

int CyclesLeft;

CTimer::CTimer(unsigned long ms)
{
	setTimer(ms);
}

void CTimer::setTimer(unsigned long ms)
{
	m_TargetTicks=TimGetTicks()+(ms * SysTicksPerSecond()) / 1000;
}

bool CTimer::isFinished(void)
{
	return TimGetTicks() >= m_TargetTicks;
}

void CTimer::sleep(void)
{
	unsigned long currTick=TimGetTicks();
	
	CyclesLeft=m_TargetTicks-currTick;	
		
	if(CyclesLeft > 0)
	{
		SysTaskDelay(CyclesLeft);
	}	
}
