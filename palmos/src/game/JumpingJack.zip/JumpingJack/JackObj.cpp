/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include <Pilot.h>
#include "JackObj.h"
#include "Input.h"
#include "AP_Game.h"
#include "Game.h"

static TAnimSoundFrame AnimFramesStanding[]={{1000,0,0,428,10},{1100,0,0,365,10},{1000,1,0,428,10},{1200,-1,0,365,10}};
static TAnimSoundFrame AnimFramesRunRight[]={{1300,3,0,428,10},{1400,3,0,0,0},{1500,3,0,507,10},{1600,3,0,0,0}};
static TAnimSoundFrame AnimFramesRunLeft[]={{1700,-3,0,428,10},{1701,-3,0,0,0},{1702,-3,0,507,10},{1703,-3,0,0,0}};
static TAnimSoundFrame AnimFramesJump[]={{1800,0,-6,359,10},{1000,0,-6,428,10}};
static TAnimSoundFrame AnimFramesFall[]={{1001,0,6,-1,60},/*{1001,0,6,361,10},*/{1900,0,6,304,10},{1901,0,0,258,10}};
static TAnimSoundFrame AnimFramesFly[]={{1000,0,-7,513,10},{1000,0,-5,613,10},{1000,0,0,711,10}};
static TAnimSoundFrame AnimFramesFlyDown[]={{1000,0,6,816,10},{2100,0,6,700,10},{2100,0,12,604,10}};
static TAnimSoundFrame AnimFramesKnockDown[]={{1903,3,0,1003,10},{1902,-3,0,848,10},{1904,0,0,788,10}};
static TAnimSoundFrame AnimFramesChampion[]={{1000,0,0,788,10},{2100,0,0,788,10},{1000,0,0,1003,10},{2100,0,0,1003,10},{1000,0,0,788,10},{2100,0,0,788,10},{1000,0,0,1003,10},{2100,0,0,1003,10}};
static TAnimSoundFrame AnimFramesDying[]={{1903,3,0,1003,10},{1902,-3,0,848,10},{1904,0,0,788,10},{1903,3,0,1003,10},{1902,-3,0,848,10},{1904,0,0,788,10},{1903,3,0,1003,10},{1902,-3,0,848,10},{1904,0,0,788,10},{1903,3,0,1003,10},{1902,-3,0,848,10},{1904,0,0,788,10}};

void CJackObject::resetObject(void)
{
	setStanding();
	setPos(InitialXPos,InitialYPos);
}

void CJackObject::draw(bool InvalidateArea)
{
	if(m_pCurrentAnimation)
	{
		m_pCurrentAnimation->draw(InvalidateArea);
		CScreenObject::setPos(m_pCurrentAnimation->pos);
	}
}

void CJackObject::show(bool bShow)
{
	m_bShow=bShow;
}

void CJackObject::setPos(int x, int y)
{
	CScreenObject::setPos(x,y);
	if(m_pCurrentAnimation)
	{
		m_pCurrentAnimation->setPos(x,y);
	}	
}

CJackObject::CJackObject()
{
	m_pCurrentAnimation=NULL;
}

CJackObject::EActionResult CJackObject::action(CAPGame *pApGame)
{
	// ������������ ��������� �� �����.
	switch(m_CurrentState)
	{
		case stateStanding:
		
			processStanding(pApGame);
		
		break;
		
		case stateRunningLeft:

			processRunningLeft(pApGame);
		
		break;
		
		case stateRunningRight:
		
			processRunningRight(pApGame);
		
		break;				
		
		case stateJump:
		
			 if(processJump(pApGame))
			 {
			 	return arNewHole;
			 }
			 
		break;
		
		case stateFalling:

			 if(processFalling(pApGame))
			 {
 		 	     return arLifeLost;
			 }
		
		break;
		
		case stateFly:

 			 processFly(pApGame);
		
		break;		

		case stateFlyDown:

			 if(processFlyDown(pApGame))
			 {
	 			 return arLifeLost;			 
			 }
			 		
		break;				
		
		case stateKnockDown:

			 processKnockDown(pApGame);
		
		break;						
		
		case stateChampion:
		
			if(processChampion(pApGame))
			{
				return arLevelFinished;
			}
		
		break;
		
		case stateDying:
		
			if(processDying(pApGame))
			{
				return arGameOver;
			}
		
		break;		
	}
	
	return arNone;
}

void CJackObject::setStanding()
{
	m_CurrentState=stateStanding;
	setAnimation(&m_AnimStanding);
}

void CJackObject::processStanding(CAPGame *pApGame)
{		
	int CurrentLevel=Level0Height-16-this->pos.y;
	if(CurrentLevel >= 0 && pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
	{
		setFlyDown();
	} 
	else if(checkNastyHit(pApGame))
	{
		pGame->m_SoundPlayer.playNasty(60);
		setKnockDown();
	}
	else if(Input.isKeyPressed(CInput::KeyRight))
	{
		setRunningRight();	
	}
	else if(Input.isKeyPressed(CInput::KeyLeft))
	{
		setRunningLeft();	
	}			
	else if(Input.isKeyPressed(CInput::KeyUp))
	{
		setJump();	
	}		
}

void CJackObject::setRunningLeft()
{
	m_CurrentState=stateRunningLeft;
	setAnimation(&m_AnimRunningLeft);
}

void CJackObject::processRunningLeft(CAPGame *pApGame)
{
	if(pos.x<-6) setPos(160-6,pos.y);
	
	int CurrentLevel=Level0Height-16-this->pos.y;
	if(CurrentLevel >= 0 && pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
	{
		setFlyDown();
	}
	else if(checkNastyHit(pApGame))
	{
		pGame->m_SoundPlayer.playNasty(60);	
		setKnockDown();
	}	
	else if(Input.isKeyPressed(CInput::KeyUp))
	{
		setJump();	
	}
	else if(!Input.isKeyPressed(CInput::KeyLeft))
	{
		setStanding();
	}	
}		

void CJackObject::setRunningRight()
{
	m_CurrentState=stateRunningRight;
	setAnimation(&m_AnimRunningRight);
}

void CJackObject::processRunningRight(CAPGame *pApGame)
{
	if(pos.x>=160-6) setPos(-6,pos.y);	
	
	int CurrentLevel=Level0Height-16-this->pos.y;
	if(CurrentLevel >= 0 && pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
	{
		setFlyDown();
	}
	else if(checkNastyHit(pApGame))
	{
		pGame->m_SoundPlayer.playNasty(60);	
		setKnockDown();
	}	
	else if(Input.isKeyPressed(CInput::KeyUp))
	{
		setJump();	
	}		
	else if(!Input.isKeyPressed(CInput::KeyRight))
	{
		setStanding();
	}
}

void CJackObject::setJump()
{
	m_CurrentState=stateJump;
	setAnimation(&m_AnimJump);	
}

bool CJackObject::processJump(CAPGame *pApGame)
{
	if(m_AnimJump.isFinished())
	{
		if(pApGame->m_Platform.isPassable((Level0Height+2-this->pos.y) / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
		{
			setFly();
			return true;
		}
		else
		{
			setFalling();
		}
	}
	
	return false;
}

void CJackObject::setFalling()
{
	m_CurrentState=stateFalling;
	setAnimation(&m_AnimFall);	
}

bool CJackObject::processFalling(CAPGame *pApGame)
{
	if(m_AnimFall.isFinished())
	{
		int CurrentLevel=Level0Height-16-this->pos.y;
		
		if(CurrentLevel >=0) 
		{
			if(pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
			{
				setFlyDown();
			}
			else
			{
				setKnockDown();
			}
		}
		else
		{		
			if(pApGame->m_LivesLeft > 1)
			{
				setKnockDown();			
			}
			else
			{
				setDying();
			}
			
			return true;
		}
	}
	
	return false;
}

void CJackObject::setFly()
{
	m_CurrentState=stateFly;
	setAnimation(&m_AnimFly);
}

void CJackObject::processFly(CAPGame *pApGame)
{	
	if(m_AnimFly.isFinished())
	{
		if(getCurrentLevel(pos.y)==5)
		{
			setChampion();
		}
		else
		{
			setStanding();
		}
	}
}

void CJackObject::create(bool bShow)
{
	show(bShow);
	
	m_AnimStanding.create(AnimFramesStanding,4,74,144,12,true);
	m_AnimRunningLeft.create(AnimFramesRunLeft,4,74,144,1,true);		
	m_AnimRunningRight.create(AnimFramesRunRight,4,74,144,1,true);
	m_AnimJump.create(AnimFramesJump,sizeof(AnimFramesJump)/sizeof(AnimFramesJump[0]),74,144,2,false);
	m_AnimFall.create(AnimFramesFall,sizeof(AnimFramesFall)/sizeof(AnimFramesFall[0]),74,144,2,false);	
	m_AnimFly.create(AnimFramesFly,sizeof(AnimFramesFly)/sizeof(AnimFramesFly[0]),74,144,2,false);
	m_AnimFlyDown.create(AnimFramesFlyDown,sizeof(AnimFramesFlyDown)/sizeof(AnimFramesFlyDown[0]),74,144,2,false);
	m_AnimKnockDown.create(AnimFramesKnockDown,sizeof(AnimFramesKnockDown)/sizeof(AnimFramesKnockDown[0]),74,144,2,false);
	m_AnimChampion.create(AnimFramesChampion,sizeof(AnimFramesChampion)/sizeof(AnimFramesChampion[0]),74,144,3,false);	
	m_AnimDying.create(AnimFramesDying,sizeof(AnimFramesDying)/sizeof(AnimFramesDying[0]),74,144,2,false);

	resetObject();
}

void CJackObject::create(CState &State, bool bShow)
{
	show(bShow);
	
	m_AnimStanding.create(AnimFramesStanding,4,74,144,12,true);
	m_AnimRunningLeft.create(AnimFramesRunLeft,4,74,144,1,true);		
	m_AnimRunningRight.create(AnimFramesRunRight,4,74,144,1,true);
	m_AnimJump.create(AnimFramesJump,sizeof(AnimFramesJump)/sizeof(AnimFramesJump[0]),74,144,2,false);
	m_AnimFall.create(AnimFramesFall,sizeof(AnimFramesFall)/sizeof(AnimFramesFall[0]),74,144,2,false);	
	m_AnimFly.create(AnimFramesFly,sizeof(AnimFramesFly)/sizeof(AnimFramesFly[0]),74,144,2,false);
	m_AnimFlyDown.create(AnimFramesFlyDown,sizeof(AnimFramesFlyDown)/sizeof(AnimFramesFlyDown[0]),74,144,2,false);
	m_AnimKnockDown.create(AnimFramesKnockDown,sizeof(AnimFramesKnockDown)/sizeof(AnimFramesKnockDown[0]),74,144,2,false);
	m_AnimChampion.create(AnimFramesChampion,sizeof(AnimFramesChampion)/sizeof(AnimFramesChampion[0]),74,144,3,false);	
	m_AnimDying.create(AnimFramesDying,sizeof(AnimFramesDying)/sizeof(AnimFramesDying[0]),74,144,2,false);
	
	switch(State.m_JackState)
	{
		case stateStanding:
			setStanding();
		break;
		
		case stateRunningLeft:
			setRunningLeft();
		break;
				
		case stateRunningRight:
			setRunningRight();
		break;
				
		case stateJump:
			setJump();
		break;
		
		case stateFalling:
			setFalling();
		break;
		
		case stateFly:
			setFly();
		break;
				
		case stateFlyDown:
			setFlyDown();
		break;
		
		case stateKnockDown:
			setKnockDown();
		break;
						
		case stateChampion:
			setChampion();
		break;
				
		case stateDying:
			setDying();
		break;		
	}
	
	if(m_pCurrentAnimation)
	{	
		m_pCurrentAnimation->m_CurrentFrameIndex=State.m_NAnimationFrame;
		m_pCurrentAnimation->m_CurrentDraw=State.m_NCurrentDraw;
	}		
	
	setPos(State.m_JackXPos,State.m_JackYPos);			
}

CDrawSurface *CJackObject::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
	m_AnimStanding.setDrawSurface(pNewSurface);
	m_AnimRunningLeft.setDrawSurface(pNewSurface);
	m_AnimRunningRight.setDrawSurface(pNewSurface);
	m_AnimJump.setDrawSurface(pNewSurface);
	m_AnimFall.setDrawSurface(pNewSurface);
	m_AnimFly.setDrawSurface(pNewSurface);
	m_AnimFlyDown.setDrawSurface(pNewSurface);
	m_AnimKnockDown.setDrawSurface(pNewSurface);
	m_AnimChampion.setDrawSurface(pNewSurface);
	m_AnimDying.setDrawSurface(pNewSurface);
		
	return pRetVal;	
}

void CJackObject::setAnimation(CAnimation *pNewAnimation)
{
	m_pCurrentAnimation=pNewAnimation;
	
	if(pNewAnimation!=NULL)
	{
		if(pNewAnimation->isFinished())
		{
			pNewAnimation->reset();
		}
		
		pNewAnimation->setPos(pos.x,pos.y);		
	}
}

void CJackObject::setFlyDown()
{
	m_CurrentState=stateFlyDown;
	setAnimation(&m_AnimFlyDown);
}

bool CJackObject::processFlyDown(CAPGame *pApGame)
{
	if(m_AnimFlyDown.isFinished())
	{
		int CurrentLevel=Level0Height-16-this->pos.y;
		
		if(CurrentLevel >= 0)
		{
			if(pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
			{
				setFlyDown();				
			}			
			else
			{
				setKnockDown();
			}
		}
		else
		{
			if(pApGame->m_LivesLeft > 1)
			{
				setKnockDown();			
			}
			else
			{
				setDying();
			}
			
			return true;
		}		
	}
	
	return false;
}

void CJackObject::setKnockDown()
{
	m_CurrentState=stateKnockDown;
	setAnimation(&m_AnimKnockDown);
		
	m_NKnockDownInsensCounter=0;
	n_NKnockDownCycles=((SysRandom(0) * (long)7) / sysRandomMax) + 2;
}

bool CJackObject::processKnockDown(CAPGame *pApGame)
{
	int CurrentLevel=Level0Height-16-this->pos.y;
	
	m_NKnockDownInsensCounter++;
			
	if(CurrentLevel >= 0 && pApGame->m_Platform.isPassable(CurrentLevel / LevelStep, CArea(this->pos.x,this->pos.y,11,16)))
	{
		setFlyDown();
		m_AnimKnockDown.reset();
	} 
	else if(m_NKnockDownInsensCounter > 11 && checkNastyHit(pApGame))
	{
		pGame->m_SoundPlayer.playNasty(60);	
		setKnockDown();
	}
	else if(m_AnimKnockDown.isFinished())
	{		
		if(--n_NKnockDownCycles==0)
		{		
			setStanding();		
		}
		else
		{
			m_AnimKnockDown.reset();
		}
	}
	
	return false;
}

int CJackObject::getCurrentLevel(int ypos)
{
	int Level=Level0Height-ypos;
	if(Level <= 0) return -1;
	
	return Level/LevelStep;
}

bool CJackObject::checkNastyHit(CAPGame *pApGame)
{
	if(getCurrentLevel(this->pos.y)==-1) return false;
	
	for(int i=0;i<pApGame->m_NCurrentCreatures;i++)
	{
		if(getCurrentLevel(pApGame->m_Creature[pApGame->m_CreatureIndex[i]].pos.y)==getCurrentLevel(this->pos.y) && (max(pApGame->m_Creature[pApGame->m_CreatureIndex[i]].pos.x+3,this->pos.x)-min(pApGame->m_Creature[pApGame->m_CreatureIndex[i]].pos.x+3,this->pos.x)) < 15) return true;
	}

	return false;
}

void CJackObject::setChampion()
{
	m_CurrentState=stateChampion;
	setAnimation(&m_AnimChampion);
}

bool CJackObject::processChampion(CAPGame *pApGame)
{
	if(m_AnimChampion.isFinished())
	{
		return true;
	}
	
	return false;
}

void CJackObject::setDying()
{
	m_CurrentState=stateDying;
	setAnimation(&m_AnimDying);
}

bool CJackObject::processDying(CAPGame *pApGame)
{
	if(m_AnimDying.isFinished())
	{
		return true;
	}

	return false;
}

void CJackObject::getCurrentAnmationState(int &NFrame, int &NDraw)
{
	if(!m_pCurrentAnimation) return;
		
	NFrame=m_pCurrentAnimation->m_CurrentFrameIndex;
	NDraw=m_pCurrentAnimation->m_CurrentDraw;
}