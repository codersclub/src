#ifndef _INCLUDE_LEVELS_H_
#define _INCLUDE_LEVELS_H_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

struct TLevelDescr
{
	int m_NMonsters;
};

class CLevel
{
};

#endif // _INCLUDE_LEVELS_H_