#ifndef _INCLUDE_SPRITE_H_
#define _INCLUDE_SPRITE_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "ScrObject.h"

class CSprite: public CScreenObject
{
	bool m_bShow;
	
	BitmapPtr m_pBitmap;
	WinHandle m_hWnd;
	Handle m_hBmp;

public:

	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	
	void create(int resID, int x, int y, bool bShow=true);
	virtual ~CSprite();
};

#endif