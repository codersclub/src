#ifndef _INCLUDE_TIMER_H_
#define _INCLUDE_TIMER_H_

/*  	
	Copyright (c) by Stanislav Tihohod, 2002. 
*/

extern int CyclesLeft;

class CTimer
{
	unsigned long m_TargetTicks;
	
public:	

	CTimer(unsigned long ms=0);

	void setTimer(unsigned long ms);
	void reset(void) {setTimer(0);}
	bool isFinished(void);
	void sleep(void);
};

#endif