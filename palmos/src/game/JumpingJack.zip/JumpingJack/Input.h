#ifndef _INCLUDE_INPUT_H_
#define _INCLUDE_INPUT_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "KeyMgr.h"

class CInput
{
public:

	enum EKey {KeyLeft,KeyRight,KeyUp,KeyDown,KeyPause,KeyPause2,KeyAny};
	
public:	

	bool isKeyPressed(EKey Key);
};

extern CInput Input;

#endif