/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include <Pilot.h>
#include "LevelIndic.h"
#include "DrawSurface.h"
#include "Timer.h"

void CLevelIndicator::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow) return;
	
	char text[]="LEVEL: 0000";
	
	WinHandle oldDrawWinH = WinGetDrawWindow();
	WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());
	
	FontID oldFontID = FntSetFont(levelFontID);
	
//	m_NLevel=CyclesLeft;

	if(m_NLevel >= 10)
	{
		StrIToA(text + sizeof("LEVEL: ") - 1, m_NLevel);
	}
	else
	{
		StrIToA(text + sizeof("LEVEL: 0") - 1, m_NLevel);	
	}
	
	int textLen=StrLen(text);
	int textHeight = FntLineHeight();
	int textWidth = FntCharsWidth(text, textLen);

	WinDrawChars(text, textLen, pos.x, pos.y);
	FntSetFont(oldFontID);	
	WinSetDrawWindow (oldDrawWinH);	
	
	if(InvalidateArea) m_pDstSurf->addFreshArea(CArea(pos.x,pos.y,textWidth,textHeight));
}

void CLevelIndicator::show(bool bShow)
{
	m_bShow=bShow;
}

CDrawSurface *CLevelIndicator::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
		
	return pRetVal;
}

void CLevelIndicator::create(int NLevel, int x, int y, bool bShow)
{
	setLevel(NLevel);
	setPos(x,y);
	show(bShow);
}

void CLevelIndicator::setLevel(int NLevel)
{
	m_NLevel=NLevel;
}