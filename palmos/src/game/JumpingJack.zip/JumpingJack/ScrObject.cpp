#include "Pilot.h"
#include "DrawSurface.h"
#include "ScrObject.h"

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CScreenObject::CScreenObject()
{
	m_pDstSurf=0;
}

CDrawSurface *CScreenObject::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	m_pDstSurf=pNewSurface;
		
	return pRetVal;
}

CScreenObject::~CScreenObject()
{
	if(m_pDstSurf)
	{
		m_pDstSurf->detachObject(this);	
	}
}
