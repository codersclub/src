#include <Pilot.h>
#include "Area.h"
#include "LifeIndic.h"
#include "DrawSurface.h"

void CLifeIndicator::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow) return;
	
	for(int i=0;i<m_NLives; i++)
	{
		m_Sprite[i].draw(InvalidateArea);
	}	
}

void CLifeIndicator::show(bool bShow) 
{
	m_bShow=bShow;
}

void CLifeIndicator::setPos(int x, int y)
{
	CArea::setPos(x,y);
	
	for(int i=0; i<NMaxLives; i++)
	{
		m_Sprite[i].setPos(x + i * ShiftStep, y);
	}
}

CDrawSurface *CLifeIndicator::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
	
	for(int i=0;i<NMaxLives;i++)
	{
		m_Sprite[i].setDrawSurface(pNewSurface);
	}	
	
	return pRetVal;
}

void CLifeIndicator::create(int NLives, int x, int y, bool bShow)
{
	for(int i=0;i<NMaxLives;i++)
	{
		m_Sprite[i].create(6000,0,0);
	}
		
	setPos(x,y);			
	setNLives(NLives);
	show(bShow);
}

void CLifeIndicator::setNLives(int NLives)
{
	m_NLives=NLives;

	if(m_pDstSurf!=NULL)
	{
		WinHandle oldDrawWinH=WinGetDrawWindow();
		WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());	
		RectangleType bounds={{3,4},{50,8}};
		WinEraseRectangle(&bounds, 0);	
		WinSetDrawWindow(oldDrawWinH);		
	
		draw(false);
	}
}

