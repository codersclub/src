#ifndef _INCLUDE_GAME_H_
#define _INCLUDE_GAME_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "DrawSurface.h"
#include "Animation.h"
#include "JackObj.h"
#include "Platform.h"
#include "Creature.h"
#include "AP_Part.h"
#include "Sound.h"
#include "State.h"

class CSprite;

class CGame
{
private:

	CDrawSurface m_Screen;
	CDrawSurface m_Offscreen;
	bool m_bSuspended;
		
public:

	CSoundPlayer m_SoundPlayer;
	CApplicationPart* m_pCurrentPart;
	CState m_State;
	CApplicationPart::ECurrentPart m_CurrentPart;
	static bool m_bReset;

public:
	
	bool InitApplication(void);
	bool StopApplication(void);	
	DWord Run(void);
	
	void startNewLevel(int NLevel);
	
	bool HandleEvent(EventPtr evt);	
	bool TranslateEvents(void);	
	
private:
	
	static unsigned char MainFormHandleEvent(EventPtr eventP);
	static void DisplayAbout(void);
};

extern CGame *pGame;

#endif //_INCLUDE_GAME_H_