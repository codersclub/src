#ifndef _INCLUDE_LEVELINDIC_H_
#define _INCLUDE_LEVELINDIC_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "ScrObject.h"

#define levelFontID	boldFont

class CLevelIndicator: public CScreenObject
{
	int m_NLevel;
	bool m_bShow;
	
public:
	
	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	virtual CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
public:

	void create(int NLevel, int x, int y, bool bShow=true);
	void setLevel(int NLevel);
};

#endif 