#ifndef _INCLUDE_APPLICATION_PART_
#define _INCLUDE_APPLICATION_PART_

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "ScrObject.h"

class CApplicationPart: public CScreenObject
{
public:

	enum ECurrentPart {partIntro,partGame,partBallad};
	
protected:	
	
	bool m_bShow;
		
public:
	
	virtual bool action(CApplicationPart::ECurrentPart &CurrentPart)=0;	
	virtual void show(bool bShow=true) {m_bShow=bShow;}
	
	CApplicationPart() {m_bShow=true;}
	virtual ~CApplicationPart() {};
};

#endif // _INCLUDE_APPLICATION_PART_