#include <Pilot.h>
#include "Platform.h"
#include "DrawSurface.h"
#include "State.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

THole::THole(EDir Direction, int Level, int XPos)
{
	m_Direction=Direction;
	m_Level=Level;
	m_XPos=XPos;
}

THole::THole()
{
}

void CPlatformObj::show(bool bShow)
{
	m_bShow=bShow;
}

void CPlatformObj::draw(bool InvalidateArea)
{
	if(!m_bShow || m_pDstSurf==NULL) return;
	
	RectangleType r={{0,0},{160,2}};

	WinHandle oldDrawWinH = WinGetDrawWindow();
	WinSetDrawWindow(m_pDstSurf->getSurfaceHandle());
	
	for(int i=0;i<LevelsNumber;i++)
	{				
		r.topLeft.y=Level0Height - i * LevelStep;
		WinDrawRectangle(&r,0);	
	}
		
	for(int i=0;i<m_NHoles;i++)
	{		
		RectangleType hr=m_Hole[i];
		WinEraseRectangle(&hr,0);
	}
	
	WinSetDrawWindow(oldDrawWinH);	
}

void CPlatformObj::create(bool bShow)
{
	m_Compensation=0;
	show(bShow);
	resetObject();
}

void CPlatformObj::resetObject(void)
{
	removeHoles();
	
	int StartHolesLevel=(SysRandom(0) * (long)(LevelsNumber) - 1) / sysRandomMax;
	if(StartHolesLevel<0) StartHolesLevel=0;		
	ErrFatalDisplayIf(StartHolesLevel >= LevelsNumber, "Internal error");		
	
	int StartXPos=(HoleWidth / 2) * (((SysRandom(0) * (long)(9)) / sysRandomMax) % 9);
	addHole(THole(THole::RightDown,StartHolesLevel,StartXPos));
	addHole(THole(THole::LeftUp,StartHolesLevel,StartXPos));
}

void CPlatformObj::addHole(const THole& Hole)
{
	if(m_NHoles >= MaxHolesNumber) return;
	m_Hole[m_NHoles]=Hole;
	m_NHoles++;
}

void CPlatformObj::removeHoles(void)
{
	m_NHoles=0;
}

void CPlatformObj::action(void)
{	
	for(int i=0;i<m_NHoles;i++)
	{
		THole& Hole=m_Hole[i];
		
		switch(Hole.m_Direction)
		{
			case THole::RightDown:
			{			
				Hole.m_XPos+=HoleStep;
				if(Hole.m_XPos >= 160+10)
				{
					Hole.m_XPos=-HoleWidth-10;
					
					if(--Hole.m_Level < 0)
					{
						Hole.m_Level=LevelsNumber-1;
					}
				}
			}			
			break;
			
			case THole::LeftUp:
			{
				Hole.m_XPos-=HoleStep;
				if(Hole.m_XPos <= -HoleWidth-10)
				{
					Hole.m_XPos=160+10;
					
					if(++Hole.m_Level > LevelsNumber-1)
					{
						Hole.m_Level=0;
					}
				}
			}
			break;
		}
	}
	
	m_Compensation++;
}

bool CPlatformObj::isPassable(int NLevel, const CArea& TestArea)
{
	static CArea areas[MaxHolesNumber];
	static bool bSkip[MaxHolesNumber];
	
	if(NLevel>=LevelsNumber) return false;	
	
	MemSet(bSkip,sizeof(bSkip),0);
	
	int nar=0, xmin, index;
	
	while(true)
	{
		xmin=1975;
		
		for(int i=0;i<m_NHoles;i++)
		{				
			if(m_Hole[i].m_Level != NLevel || bSkip[i]) continue;
			
			if(m_Hole[i].m_XPos < xmin)
			{
				xmin=m_Hole[i].m_XPos;
				index=i;
			}
		}	
		
		if(xmin==1975) break;
		
		bSkip[index]=true;
		
		if(nar==0 || !areas[nar-1].isCrossed(m_Hole[index]))
		{
			areas[nar++]=m_Hole[index];
		}
		else
		{
			areas[nar-1]=areas[nar-1]+m_Hole[index];
		}		
	}
	
	for(int i=0;i<nar;i++)
	{	
		if(areas[i].pos.x <= TestArea.pos.x && areas[i].MaxX() >= TestArea.MaxX()) return true;
	}
	
	return false;
}

void CPlatformObj::addHoleRandom()
{
	THole::EDir Dir=m_NHoles % 2 ? THole::RightDown : THole::LeftUp;	
	int Level=((SysRandom(0) * (long)(LevelsNumber)) / sysRandomMax) % LevelsNumber;
	int XPos=(HoleWidth / 2) * (((SysRandom(0) * (long)(9)) / sysRandomMax) % 9);
	
	if(Dir==THole::RightDown)
	{
		XPos+=(m_Compensation % 5) * 3;
	}
	else
	{
		XPos-=(m_Compensation % 5) * 3;	
	}
	
	THole NewHole(Dir,Level,XPos);
			
	while(!checkMinimalDistance(NewHole))
	{
		NewHole.m_XPos+=15;

		if(NewHole.m_XPos >= 160+10)
		{
			NewHole.m_XPos-=(160+10);
					
			if(--NewHole.m_Level < 0)
			{
				NewHole.m_Level=LevelsNumber-1;
			}
		}
	}
	
	addHole(NewHole);
}

bool CPlatformObj::checkMinimalDistance(const THole& Hole)
{
	for(int i=0;i<m_NHoles;i++)
	{
		if(m_Hole[i].m_Direction==Hole.m_Direction && m_Hole[i].m_Level==Hole.m_Level && (max(m_Hole[i].m_XPos,Hole.m_XPos)-min(m_Hole[i].m_XPos,Hole.m_XPos)) < 45) return false;
	}

	return true;
}

void CPlatformObj::create(int HolesCompensation, int NHoles, THoleDescriptor* pHoleDescr, bool bShow)
{
	m_Compensation=HolesCompensation;
	m_NHoles=0;
	
	for(int i=0;i<NHoles;i++)
	{
		addHole(THole(pHoleDescr[i].m_Direction ? THole::RightDown : THole::LeftUp, pHoleDescr[i].m_Level, pHoleDescr[i].m_XPos));
	}
	
	show(bShow);
}

void CPlatformObj::getState(int &Compensation, int &NHoles, THoleDescriptor *Holes)
{
	Compensation=m_Compensation;
	NHoles=m_NHoles;
	
	for(int i=0;i<NHoles;i++)
	{
		Holes[i].m_Direction=m_Hole[i].m_Direction==THole::RightDown ? 1 : 0;
		Holes[i].m_Level=m_Hole[i].m_Level;
		Holes[i].m_XPos=m_Hole[i].m_XPos;
	}
}


