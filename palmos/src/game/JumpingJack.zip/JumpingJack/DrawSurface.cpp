#include "Pilot.h"
#include "DrawSurface.h"

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CDrawSurface::CDrawSurface()
{
	m_NFreshAreas=0;
	m_hSurfHandle=NULL;
}

void CDrawSurface::create(int cx, int cy, bool bOffscreen)
{
	Word error;
	
	if(bOffscreen)
	{
		m_Bounds.topLeft.x=0;
		m_Bounds.topLeft.y=0;
		m_Bounds.extent.x=cx;
		m_Bounds.extent.y=cy;
		
		m_hSurfHandle=WinCreateOffscreenWindow(cx,cy,screenFormat,&error);
	}
	else
	{
		m_Bounds.topLeft.x=0;
		m_Bounds.topLeft.y=0;
		m_Bounds.extent.x=cx;
		m_Bounds.extent.y=cy;
		
		m_hSurfHandle=0;
	}	
	
	addFreshArea(CArea(0,0,cx,cy));
	eraseFreshAreas();
	clearFreshList();	
}

void CDrawSurface::eraseFreshAreas()
{
	if(!m_hSurfHandle) return;
	
	WinHandle oldDrawWinH=WinGetDrawWindow();
	WinSetDrawWindow(m_hSurfHandle);
	
	RectangleType bounds;
	for(int i=0; i<m_NFreshAreas; i++)
	{
		bounds.topLeft.x=m_FreshArea[i].pos.x;
		bounds.topLeft.y=m_FreshArea[i].pos.y;
		bounds.extent.x=m_FreshArea[i].size.cx;
		bounds.extent.y=m_FreshArea[i].size.cy;
		
		WinEraseRectangle(&bounds, 0);
	}	
	
	WinSetDrawWindow(oldDrawWinH);		
	
	clearFreshList();
}

void CDrawSurface::clear(void)
{
	if(!m_hSurfHandle) return;
	
	WinHandle oldDrawWinH=WinGetDrawWindow();
	WinSetDrawWindow(m_hSurfHandle);	
	WinEraseRectangle(&m_Bounds, 0);	
	WinSetDrawWindow(oldDrawWinH);		
}

void CDrawSurface::clearFreshList()
{
	m_NFreshAreas=0;
}

void CDrawSurface::addFreshArea(const CArea& NewArea)
{
	// � JumpingJack-� ������� �� ������������. ��������� �� ���������� (�� ������ ��������)

/*	
	int i;
	for(i=0; i<m_NFreshAreas && m_FreshArea[i]!=NewArea; i++);
	
	if(i==m_NFreshAreas)
	{
		m_FreshArea[m_NFreshAreas]=NewArea;
		m_NFreshAreas++;
	}
*/

	m_FreshArea[m_NFreshAreas]=NewArea;
	m_NFreshAreas++;	
}

void CDrawSurface::addFreshArea(const RectangleType& NewRect)
{
	addFreshArea(CArea(NewRect.topLeft.x,NewRect.topLeft.y,NewRect.extent.x,NewRect.extent.y));
}

void CDrawSurface::flip(CDrawSurface &dstSurf, int xpos, int ypos)
{
	WinCopyRectangle(m_hSurfHandle, dstSurf.getSurfaceHandle(),&m_Bounds, xpos, ypos, scrCopy);
}

void CDrawSurface::drawObjects(void)
{
	CScreenObject *pScreenObject=m_GraphObjectsAttached.getFirstObject();
	
	while(pScreenObject)
	{
		pScreenObject->draw(true);
		pScreenObject=m_GraphObjectsAttached.getNextObject();
	}
}

void CDrawSurface::attachObject(CScreenObject *pScreenObject)
{	
	m_GraphObjectsAttached.addObject(pScreenObject);
	pScreenObject->setDrawSurface(this);
}

void CDrawSurface::detachObject(CScreenObject *pScreenObject)
{
	m_GraphObjectsAttached.deleteObject(pScreenObject);
	pScreenObject->setDrawSurface(this);	
}








