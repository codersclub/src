#include <Pilot.h>
#include "Creature.h"

static TAnimFrame AnimFramesCreature0[]={{3200,-11,0},{3201,-3,0},{3202,5,0},{3203,-3,0}};
static TAnimFrame AnimFramesCreature1[]={{3500,-2,0},{3500,-3,0},{3500,-4,0},{3501,-2,0},{3501,-3,0},{3501,-4,0}};
static TAnimFrame AnimFramesCreature2[]={{2300,-4,0},{2301,-4,0},{2302,-1,0}};
static TAnimFrame AnimFramesCreature3[]={{3600,-3,0},{3600,-3,0},{3601,-3,0},{3601,-3,0}};
static TAnimFrame AnimFramesCreature4[]={{2600,-2,1},{2600,-3,0},{2600,-4,0},{2600,-3,0},{2700,-2,-1},{2700,-3,0},{2700,-4,0},{2700,-3,0}};

static TAnimDescriptor AnimDescr[]=
{
	{AnimFramesCreature0,sizeof(AnimFramesCreature0)/sizeof(AnimFramesCreature0[0]),1},
	{AnimFramesCreature1,sizeof(AnimFramesCreature1)/sizeof(AnimFramesCreature1[0]),1},
	{AnimFramesCreature2,sizeof(AnimFramesCreature2)/sizeof(AnimFramesCreature2[0]),1},
	{AnimFramesCreature3,sizeof(AnimFramesCreature3)/sizeof(AnimFramesCreature3[0]),1},
	{AnimFramesCreature4,sizeof(AnimFramesCreature4)/sizeof(AnimFramesCreature4[0]),1}
};

void CCreature::draw(bool InvalidateArea)
{
	if(!m_bShow) return;
	
	m_Animation.draw(InvalidateArea);
	CScreenObject::setPos(m_Animation.pos);
}

void CCreature::show(bool bShow)
{
	m_bShow=bShow;
}
	
void CCreature::create(int NCreature, bool bShow)
{
	if(NCreature>=MaxCreaturesNumber) return;
	
	show(bShow);	
	m_Animation.create(AnimDescr[NCreature].m_pFrames, AnimDescr[NCreature].m_NFrames,74,144,AnimDescr[NCreature].m_Speed,true);
	m_NDrawCycles=72;
}

void CCreature::action(void)
{
	if(m_NDrawCycles--==0)
	{
		setPlatform(m_CurrentPlatform > 3 ? 0 : m_CurrentPlatform + 1,0);
		m_NDrawCycles=72;
	}	
}
	
CDrawSurface *CCreature::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
	m_Animation.setDrawSurface(pNewSurface);

	return pRetVal;
}

void CCreature::setPos(int x, int y)
{
	CScreenObject::setPos(x,y);
	m_Animation.setPos(x,y);
}

void CCreature::setPlatformByPos()
{
//	pos.y=117-NPlatform * 24;
	m_CurrentPlatform=(117 - pos.y) / 24;
}

void CCreature::setPlatform(int NPlatform, int Offset)
{
	 m_NDrawCycles=72-Offset*24;	 
	 setPos(InitialCreatureXPos - 72 * Offset,117-NPlatform * 24);	 
	 m_CurrentPlatform=NPlatform;
}



