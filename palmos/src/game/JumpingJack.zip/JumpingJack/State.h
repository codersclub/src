#ifndef _INCLUDE_STATE_H_
#define _INCLUDE_STATE_H_

const int NStartLevel=1;
const int NInitialLives=6;

#define puzzleAppCreator 'JUJA'

const int StateFeatureNum      		   = 0;
const int LevelFeatureNum      		   = 1;
const int LivesLeftFeatureNum 		   = 2;
const int NCreaturesFeatureNum 		   = 3;
const int JackXPosFeatureNum		   = 4;		
const int JackYPosFeatureNum		   = 5;
const int JackStateFeatureNum		   = 6;
const int JackNFrameFeatureNum		   = 7;
const int JackNDrawFeatureNum		   = 8;
const int NHolesFeatureNum  		   = 9;
const int HoleCompensationFeatureNum   = 10;
const int GameStateFeatureNum   	   = 11;
const int CreaturesDescrFeatureBaseNum = 20;
const int HolesDescrFeatureBaseNum 	   = 50;

const int savedStateIntro    		   = 0;
const int savedStateGame      		   = 1;
const int savedStateBallad     		   = 2;

const DWord DefaultState	           = savedStateIntro;
const DWord DefaultLevel     		   = NStartLevel;
const DWord DefaultLivesLeft  		   = NInitialLives;
const DWord DefaultNCreatures 		   = 0;

struct TCreatureDescriptor
{
	DWord m_CreatureIndex;
	DWord m_CreatureXPos;
	DWord m_CreatureYPos;	
	DWord m_CreatureNCycles;
};

struct THoleDescriptor
{
	DWord m_Direction;
	DWord m_Level;
	DWord m_XPos;		
};

class CState
{
public:

	DWord m_State;
	DWord m_Level;
	DWord m_LivesLeft;	
	DWord m_GameState;
	DWord m_JackXPos;
	DWord m_JackYPos;			
	
	DWord m_JackState;
	DWord m_NAnimationFrame;
	DWord m_NCurrentDraw;	
	
	DWord m_NCreatures;
	TCreatureDescriptor m_Creatures[5];

	DWord m_HolesCompensation;		
	DWord m_NHoles;	
	THoleDescriptor m_Holes[6];
	
public:
		
	DWord getSavedState() {return m_State;}	
	DWord getSavedLevel() {return m_Level;}
	DWord getSavedLivesLeft() {return m_LivesLeft;}
	
	void save(DWord State, DWord Level, DWord LivesLeft, DWord GameState, int JackXPos, int JackYPos, int JackState, int JackNFrame, int JackNDraw, int NCreatures, TCreatureDescriptor *pCreatureDescr, int HolesCompensation, int NHoles, THoleDescriptor* pHoleDescr);
	
	void load();
	
public:

	CState(): m_State(DefaultState) {};
};

#endif