#include <Pilot.h>
#include "Jack_res.h"
#include "Area.h"
#include "Game.h"
#include "ScrObject.h"
#include "Sprite.h"
#include "Timer.h"
#include "Animation.h"
#include "Creature.h"
#include "Sound.h"
#include "AP_Intro.h"
#include "AP_Game.h"
#include "AP_Ballad.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CGame *pGame;

bool CGame::m_bReset=false;

bool CGame::InitApplication(void)
{
	pGame=this;
	
	m_SoundPlayer.init(PrefGetPreference(prefGameSoundVolume));
	m_Screen.create(160,160,false);
	m_Offscreen.create(160,160,true);
	
	CAnimation::setPauseMode(false);

	m_State.load();
	
	switch(m_State.getSavedState())
	{
		case savedStateIntro:
		{					
			CAPIntro *pIntroPart=new CAPIntro;
			pIntroPart->create();
			
			m_State.m_Level=DefaultLevel;
			m_State.m_LivesLeft=DefaultLivesLeft;
			
			m_pCurrentPart=pIntroPart;
			m_CurrentPart=CApplicationPart::partIntro;			
		}			
		break;
		
		case savedStateGame:
		{
			CAPGame *pGamePart=new CAPGame;	
			pGamePart->create(m_State);
									
			m_pCurrentPart=pGamePart;
			m_CurrentPart=CApplicationPart::partGame;			
		}
		break;
		
		case savedStateBallad:
		{
			CAPBallad *pBalladPart=new CAPBallad;
			pBalladPart->createWhole(m_State.m_Level);
									
			m_pCurrentPart=pBalladPart;
			m_CurrentPart=CApplicationPart::partBallad;
			
			m_State.m_Level++;			
		}
		break;		
		
		default:		
			ErrDisplay("Internal error");		
		break;
	}
			
	m_Offscreen.attachObject(m_pCurrentPart);
	
	FrmGotoForm(MainForm);
	m_bSuspended=false;
	m_bReset=false;

	return true;
}

bool CGame::StopApplication(void)
{
	switch(m_CurrentPart)
	{
		case CApplicationPart::partIntro:
		{										
			m_State.save(savedStateIntro,0,0,0,0,0,0,0,0,0,0,0,0,0);
		}			
		break;
		
		case CApplicationPart::partGame:
		{
			((CAPGame *)m_pCurrentPart)->saveState(m_State);
		}
		break;
		
		case CApplicationPart::partBallad:
		{			
			m_State.save(savedStateBallad,m_State.m_Level-1,m_State.m_LivesLeft,0,0,0,0,0,0,0,0,0,0,0);		
		}
		break;
	}

	delete m_pCurrentPart;
	
//	FrmAlert(UnregisteredVersionAlert);	

	return true;
}

DWord CGame::Run(void)
{
	CTimer MainTimer;	
		
	while(TranslateEvents())
	{					
		if(!m_bSuspended)
		{
			if(m_pCurrentPart->action(m_CurrentPart) || m_bReset)
			{
				delete m_pCurrentPart;
				m_pCurrentPart=0;
				
				if(m_bReset)
				{
					m_bReset=false;
					m_CurrentPart=CApplicationPart::partIntro;
				}				
					
				switch(m_CurrentPart)
				{
					case CApplicationPart::partIntro:
					{				
						CAPIntro *pIntroPart=new CAPIntro;
						pIntroPart->create();					
						m_pCurrentPart=pIntroPart;
						
						m_State.m_Level=DefaultLevel;
						m_State.m_LivesLeft=DefaultLivesLeft;
					}					
					break;
					
					case CApplicationPart::partGame:
					{
						CAPGame *pGamePart=new CAPGame;	
						pGamePart->create(m_State.m_Level,m_State.m_LivesLeft);											
						m_pCurrentPart=pGamePart;
					}
					break;
					
					case CApplicationPart::partBallad:
					{
						CAPBallad *pBalladPart=new CAPBallad;	
						pBalladPart->create(m_State.m_Level);											
						m_pCurrentPart=pBalladPart;					
						m_State.m_Level++;
					}
					break;				
				}
				
				m_Offscreen.clear();
				if(!m_bReset) m_Offscreen.attachObject(m_pCurrentPart);
			};
				
			m_Offscreen.drawObjects();
			m_Offscreen.flip(m_Screen,0,0);
			m_Offscreen.eraseFreshAreas();
			
			MainTimer.sleep();
			MainTimer.setTimer(50);
		}
	}		
	
	return 0;	
}

bool CGame::TranslateEvents(void)
{
	Word error;
	EventType event;
	
	EvtGetEvent(&event,0);
	
	while(event.eType != nilEvent && event.eType != appStopEvent)
	{	
		if (event.eType == keyDownEvent) // �������� ���������� ������, ����� ��� �� ����������� ����������
		{
			if((event.data.keyDown.chr >= hard1Chr && event.data.keyDown.chr <= hard4Chr) || event.data.keyDown.chr == chrPageUp || event.data.keyDown.chr == chrPageDown || event.data.keyDown.chr==vchrCommand)
			{
				EvtGetEvent(&event,0);
				continue;
			}
		}
		
		if (event.eType == winExitEvent)
		{
			if (event.data.winExit.exitWindow==(WinHandle)FrmGetFormPtr(MainForm))
			{
				m_bSuspended=true;
			}
		}

		else if (event.eType == winEnterEvent)
		{
			if (event.data.winEnter.enterWindow==(WinHandle)FrmGetFormPtr(MainForm) && event.data.winEnter.enterWindow==(WinHandle)FrmGetFirstForm())
			{
				m_bSuspended=false;
			}
		}
		
	
		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! HandleEvent(&event))
					FrmDispatchEvent(&event);
					
		EvtGetEvent(&event,0);					
	}
	
	return (event.eType != appStopEvent);
}

bool CGame::HandleEvent(EventPtr eventP)
{
	Word formId;
	FormPtr frmP;
	
	switch(eventP->eType)
	{
		case frmLoadEvent:
		{
			formId = eventP->data.frmLoad.formID;
			frmP = FrmInitForm(formId);
			FrmSetActiveForm(frmP);		
			
			FrmSetEventHandler(frmP, MainFormHandleEvent);
		}
		return true;
	}
		
	return false;	
}

unsigned char CGame::MainFormHandleEvent(EventPtr eventP)
{
	switch(eventP->eType)
	{
		case frmOpenEvent:
		{
			FormPtr frmP = FrmGetActiveForm();
			FrmDrawForm(frmP);
		}
		return true;
			
		case ctlSelectEvent:
		{
			EventType newEvent;
		   	MemSet(&newEvent, sizeof(EventType), 0);
		   	newEvent.eType = appStopEvent;
		   	EvtAddEventToQueue(&newEvent);
		}
		return true;		
				
		case menuEvent:
		{
			switch(eventP->data.menu.itemID)
			{
				case OptionsAbout:
					DisplayAbout();
				break;
				
				case OptionsInstructions:
					FrmHelp(InstructionsString);
				break;
				
				case OptionsRestartGame:
				
					m_bReset=true;
					CAnimation::setPauseMode(false);
					
				break;
			}
		}
		break;		
	}
	
	return false;
}

void CGame::DisplayAbout(void)
{
	FormPtr curFormP = FrmGetActiveForm();
	FormPtr formP = FrmInitForm(AboutForm);
	FrmSetActiveForm(formP);
	FrmDoDialog(formP);
	FrmDeleteForm(formP);
	FrmSetActiveForm(curFormP);
}