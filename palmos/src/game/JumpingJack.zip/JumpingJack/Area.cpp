#include "Area.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CArea CArea::operator+(const CArea& Area)
{
	int maxmaxx,maxmaxy;
	
	maxmaxx=MAX(MaxX(),Area.MaxX());
	maxmaxy=MAX(MaxY(),Area.MaxY());
		
	pos.x=MIN(pos.x,Area.pos.x); 
	pos.y=MIN(pos.y,Area.pos.y); 				
	
	size.cx=maxmaxx-pos.x;
	size.cy=maxmaxy-pos.y;
	
	return *this;
}