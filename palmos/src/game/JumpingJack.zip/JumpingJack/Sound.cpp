#include <Pilot.h>
#include "Sound.h"
#include "Timer.h"

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

CSoundPlayer::CSoundPlayer()
{
	m_bInitialized=false;
}

void CSoundPlayer::init(int InitVolume)
{
	// check OS!!!
	m_bInitialized=true;	
	m_Volume=InitVolume;
}

void CSoundPlayer::playSound(int Freq, int Duration)
{
	if(!m_bInitialized || !m_Volume) return;
	
	SndCommandType sndCmd;
	
	sndCmd.cmd = sndCmdFrqOn;
	//sndCmd.cmd = sndCmdFreqDurationAmp;
	sndCmd.param1 = Freq;
	sndCmd.param2 = Duration;
	sndCmd.param3 = m_Volume;
	
	SndDoCmd(0,&sndCmd,true);
}

void CSoundPlayer::playNote(int Note, int Duration)
{
	if(!m_bInitialized || !m_Volume) return;
	
	SndCommandType sndCmd;
	
	sndCmd.cmd = sndCmdNoteOn;
	sndCmd.param1 = Note; // MIDI 0..127
	sndCmd.param2 = Duration;
	sndCmd.param3 = m_Volume;
	
	SndDoCmd(0,&sndCmd,true);	
}

void CSoundPlayer::setVolume(int Volume)
{
	m_Volume=Volume;
}

void CSoundPlayer::playBoom(int Duration)
{
	if(!m_bInitialized) return;
	
	SndCommandType sndCmd;
	
	sndCmd.cmd = sndCmdFrqOn;
	sndCmd.param2 = 1;
	sndCmd.param3 = m_Volume;
	
	for(int i=0;i<Duration;i++)
	{
		sndCmd.param1=i+(500*(long)SysRandom(0))/sysRandomMax;
		SndDoCmd(0,&sndCmd,true);
	}	
}

void CSoundPlayer::playNasty(int Duration)
{
	if(!m_bInitialized) return;
	
	SndCommandType sndCmd;
	
	sndCmd.param2 = 1;
	sndCmd.param3 = m_Volume;
	
	sndCmd.cmd = sndCmdFrqOn;	
	for(int i=0;i<10;i++)
	{
		sndCmd.param1=i+(500*(long)SysRandom(0))/sysRandomMax;
		SndDoCmd(0,&sndCmd,true);
	}	

	sndCmd.cmd = sndCmdFreqDurationAmp;
		
	sndCmd.param1=262;
	sndCmd.param2 = 2+(2*(long)SysRandom(0))/sysRandomMax;
	SndDoCmd(0,&sndCmd,true);
				
	sndCmd.param1=1048;
	sndCmd.param2 = 2+(2*(long)SysRandom(0))/sysRandomMax;
	SndDoCmd(0,&sndCmd,true);		
}





