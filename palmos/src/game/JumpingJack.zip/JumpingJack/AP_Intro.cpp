#include <Pilot.h>
#include "AP_Intro.h"
#include "Sound.h"
#include "Game.h"
#include "Input.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

static TAnimFrame AnimFramesRunRight[]={{1300,3,0},{1400,3,0},{1500,3,0},{1600,3,0}};
static TAnimFrame AnimFramesRunLeft[]={{1700,-3,0},{1701,-3,0},{1702,-3,0},{1703,-3,0}};
static TAnimFrame AnimFramesStanding[]={{1000,0,0},{1100,0,0},{1000,1,0},{1200,-1,0}};

static TAnimFrame J[NFramesNumber];
static TAnimFrame U[NFramesNumber];
static TAnimFrame M[NFramesNumber];
static TAnimFrame P[NFramesNumber];
static TAnimFrame I[NFramesNumber];
static TAnimFrame N[NFramesNumber];
static TAnimFrame G[NFramesNumber];
static TAnimFrame J1[NFramesNumber];
static TAnimFrame A[NFramesNumber];
static TAnimFrame C[NFramesNumber];
static TAnimFrame K[NFramesNumber];

static int ID[NLettersNumber]={5000,5001,5002,5003,5004,5005,5006,5000,5007,5008,5009};

struct TEndPos 
{
	int x;
	int y;
};

static TEndPos EndPos[NLettersNumber]={{0,0},{15,29},{41,16},{71,16},{95,7},{109,17},{139,25},{32,52},{59,68},{83,68},{107,60}};

static TAnimDescriptor AnimFrames[]=
{
	{J,NFramesNumber,1},
	{U,NFramesNumber,1},	
	{M,NFramesNumber,1},
	{P,NFramesNumber,1},	
	{I,NFramesNumber,1},
	{N,NFramesNumber,1},	
	{G,NFramesNumber,1},
	{J1,NFramesNumber,1},	
	{A,NFramesNumber,1},
	{C,NFramesNumber,1},	
	{K,NFramesNumber,1},
};


bool CAPIntro::action(CApplicationPart::ECurrentPart &CurrentPart)
{
	if(Input.isKeyPressed(CInput::KeyAny))
	{
		CurrentPart=partGame;
		return true;
	}
	
	return false;
}

void CAPIntro::create()
{	
	for(int i=0;i<NLettersNumber;i++)
	{
		makePath(AnimFrames[i].m_pFrames, NFramesNumber, ID[i], EndPos[i].x, EndPos[i].y);	
		m_Letters[i].create(AnimFrames[i].m_pFrames, AnimFrames[i].m_NFrames,68,122,AnimFrames[i].m_Speed,false);
	}
	
	m_BottomSprite[0].create(10002,0,144);	
	m_BottomSprite[1].create(10000,0,144);	
	
	m_CurrentBottomLineIndex=0;
	
	m_RunLeftAnim.create(AnimFramesRunLeft, sizeof(AnimFramesRunLeft)/sizeof(AnimFramesRunLeft[0]),-16,TrackPosY,1,true);
	m_RunRightAnim.create(AnimFramesRunRight, sizeof(AnimFramesRunRight)/sizeof(AnimFramesRunRight[0]),-16,TrackPosY,1,true);
	m_StandingAnim.create(AnimFramesStanding, sizeof(AnimFramesStanding)/sizeof(AnimFramesStanding[0]),72,TrackPosY,12,false);
	
	m_CurrentState=stateRunRight;
	m_bRunToStop=true;
	m_firstDrawLetters=true;
	
	m_ShowTimer.setTimer(4000);
}

void CAPIntro::draw(bool InvalidateArea)
{
	if(!m_bShow && !m_pDstSurf) return;
	
	static int fr[]={256,304,361,424,507,596,700,832};
		
	int NLevShift=m_Note-4;

	if(NLevShift < (int)(sizeof(fr)/sizeof(fr[0])))
	{
		if(NLevShift >= 0) pGame->m_SoundPlayer.playSound(fr[NLevShift],10);
		m_Note++;	
	}
			
	if(!m_Letters[0].isFinished())
	{
		for(int i=0;i<NLettersNumber;i++)
		{
			m_Letters[i].draw(InvalidateArea);
		}
	}
	else
	{			
		if(m_firstDrawLetters)
		{
			for(int i=0;i<NLettersNumber;i++)
			{
				m_Letters[i].getFrame(0)->draw(false);
			}
		
			m_firstDrawLetters=false;
		}
		
		if(m_ShowTimer.isFinished())
		{
			m_CurrentBottomLineIndex=(m_CurrentBottomLineIndex+1) % 2;
			m_ShowTimer.setTimer(4000);
		}

		m_BottomSprite[m_CurrentBottomLineIndex].draw();
		
		switch(m_CurrentState)
		{
			case stateRunRight:
			{
				m_RunRightAnim.draw();
				
				if(m_bRunToStop)
				{
					if(m_RunRightAnim.pos.x >= StopPosX)
					{
						m_CurrentState=stateStanding;
						m_StandingAnim.setPos(StopPosX,TrackPosY);
						m_StandingAnim.reset();						
					}
				}
				else
				{
					if(m_RunRightAnim.pos.x >= 160+48)
					{
						m_CurrentState=stateRunLeft;
						m_RunLeftAnim.setPos(160+48,TrackPosY);
						m_bRunToStop=true;						
					}				
				}
			}
			break;
			
			case stateRunLeft:
			{
				m_RunLeftAnim.draw();
							
				if(m_bRunToStop)
				{
					if(m_RunLeftAnim.pos.x <= StopPosX)
					{
						m_CurrentState=stateStanding;
						m_StandingAnim.setPos(StopPosX,TrackPosY);
						m_StandingAnim.reset();
					}
				}
				else
				{
					if(m_RunLeftAnim.pos.x <= -48)
					{
						m_CurrentState=stateRunRight;
						m_RunRightAnim.setPos(-48,TrackPosY);
						m_bRunToStop=true;						
					}				
				}
			}			
			break;
			
			case stateStanding:
			{
				m_StandingAnim.draw();
				
				if(m_StandingAnim.isFinished())
				{
					if((SysRandom(0) * (long)1000) / sysRandomMax > 500)
					{
						m_CurrentState=stateRunRight;
						m_RunRightAnim.setPos(StopPosX,TrackPosY);
					}
					else
					{
						m_CurrentState=stateRunLeft;
						m_RunLeftAnim.setPos(StopPosX,TrackPosY);					
					}
					
					m_bRunToStop=false;
				}				
			}			
			break;
		}
	}
}

	
CDrawSurface *CAPIntro::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);	
	
	for(int i=0;i<NLettersNumber;i++)
	{
		m_Letters[i].setDrawSurface(pNewSurface);
	}
	
	for(int i=0;i<2;i++)
	{
		m_BottomSprite[i].setDrawSurface(pNewSurface);
	}
	
	m_RunLeftAnim.setDrawSurface(pNewSurface);
	m_RunRightAnim.setDrawSurface(pNewSurface);
	m_StandingAnim.setDrawSurface(pNewSurface);	
	
	return pRetVal;
}

CAPIntro::CAPIntro()
{
	m_Note=0;
}

CAPIntro::~CAPIntro()
{
}

void CAPIntro::makePath(TAnimFrame *pFrames, int NFrames, int m_FrameID, int xend, int yend, int xstart, int ystart)
{
	if(!NFrames) return;
	
	int ddx=xend-xstart;
	int ddy=yend-ystart;
	
	int divx=MAX(NFrames-1,1);	
	
	int lastx=xstart;
	int lasty=ystart;	
	
	for(int i=0; i<NFrames; i++)
	{
		pFrames[i].m_FrameID=m_FrameID;
		pFrames[i].dx=xstart + (ddx * (i + 1)) / divx - lastx;
		pFrames[i].dy=ystart + (ddy * (i + 1)) / divx - lasty;
		
		lastx+=pFrames[i].dx;
		lasty+=pFrames[i].dy;
	}
}