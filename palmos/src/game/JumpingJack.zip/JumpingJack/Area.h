#ifndef _INCLUDE_AREA_H_
#define _INCLUDE_AREA_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

/* Thank you Roman, you are cool! */

#define MIN(a,b) ((a)<(b)?(a):(b))
#define MAX(a,b) ((a)>(b)?(a):(b))

struct CPos
{
    int x,y;
    
	inline CPos operator+(const CPos& p) const {CPos pos; pos.x=x+p.x; pos.y=y+p.y; return pos;}
	inline CPos operator-(const CPos& p) const {CPos pos; pos.x=x-p.x; pos.y=y-p.y; return pos;}	
	
	CPos(){}
	CPos(int xx, int yy): x(xx), y(yy) {}
	CPos(const CPos& Pos): x(Pos.x), y(Pos.y) {}
	
	inline bool operator==(const CPos& pos) const {return x==pos.x && y==pos.y;}
	inline bool operator!=(const CPos& pos) const {return !(pos==*this);}		
};

struct CSize
{
	int cx,cy;
	
	CSize(){};
	CSize(int cxx, int cyy) {cx=cxx; cy=cyy;}
	
	inline bool operator==(const CSize& size) const {return cx==size.cx && cy==size.cy;}
	inline bool operator!=(const CSize& size) const {return !(size==*this);}	
};

struct CArea
{
	CPos pos;
	CSize size;
	
	CArea(){}
	CArea(int x, int y, int cx, int cy) {pos.x=x; pos.y=y; size.cx=cx; size.cy=cy;}
		
	virtual long MaxX() const {return pos.x+size.cx;}	
	virtual long MaxY() const {return pos.y+size.cy;}
	
	virtual void move(int dx,int dy) {pos.x+=dx; pos.y+=dy;}
	virtual void move(const CPos& Pos) {pos=pos+Pos;}
	
	virtual void setPos(int x, int y) {pos.x=x; pos.y=y;}
	virtual void setPos(const CPos& Pos) {setPos(Pos.x,Pos.y);}
	
	virtual void setSize(int cx, int cy) {size.cx=cx; size.cy=cy;}
	virtual void setSize(const CSize& Size) {setSize(Size.cx,Size.cy);}
	
	virtual void setArea(int x, int y, int cx, int cy) {setPos(x,y); setSize(cx,cy);}
	virtual void setArea(const CArea& srcArea) {setArea(srcArea.pos.x,srcArea.pos.y,srcArea.size.cx,srcArea.size.cy);}
	
	virtual bool isPtIn(int x,int y) const {return (x >= pos.x && y >=pos.y && x <= MaxX() && y <= MaxY());}
	virtual bool isPtIn(const CPos& TestPos) const {return isPtIn(TestPos.x,TestPos.y);}	
	
	virtual bool isCrossed(const CArea& TestArea) const {return TestArea.pos.x < MaxX() && TestArea.pos.y < MaxY() && pos.x < TestArea.MaxX() && pos.y < TestArea.MaxY();} /* thanx again. � ��� ����������, ������������-�� ��� ����������� ������������� � ������������ ����������������? :-) */
	
	virtual bool operator==(const CArea& Area) const {return pos==Area.pos && size==Area.size;}
	virtual bool operator!=(const CArea& Area) const {return !(Area==*this);}
	virtual CArea operator+(const CArea& Area);
};

#endif