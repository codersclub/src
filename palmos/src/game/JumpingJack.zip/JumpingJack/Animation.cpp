#include <Pilot.h>
#include "Animation.h"
#include "Game.h"

/* 
Jumping Jack by Stanislav Tihohod.
Copyright (c) 2002 by Stanislav Tihohod. 
*/

bool CAnimation::m_bPauseMode;

CAnimation::CAnimation()
{
	m_NSprites=0;
	m_pSprite=NULL;	
	
	m_NFrames=0;
	m_pFrameSpriteIndex=NULL;
	
	m_pPos=NULL;
	
	m_bCycled=false;
}

CAnimation::~CAnimation()
{
	if(m_pFrameSpriteIndex)
		delete[] m_pFrameSpriteIndex;
		
	if(m_pPos)
		delete[] m_pPos;
		
	for(int i=0;i<m_NSprites;i++)
		delete m_pSprite[i];
		
	if(m_pSprite)
		delete[] m_pSprite;
		
	if(m_pSound)
		delete[] m_pSound;
}

void CAnimation::create(TAnimFrame *pFrameDescr, int NFrames, int x, int y,  int speed, bool bCycled ,bool bShow)
{
	ErrFatalDisplayIf(pFrameDescr==NULL || NFrames==0, "Zero frames of animation passed to CAnimation::create");
	
	m_NFrames=NFrames;
	m_pFrameSpriteIndex=new int[NFrames];
	m_pPos=new CPos[NFrames];
	
	m_NSprites=getUniqeFrameIDNumber(pFrameDescr, NFrames);	
	m_pSprite=new CSprite*[m_NSprites];
	
	int i,j,CurSpriteIndex=0;
	
	for(i=0;i<NFrames;i++)
	{
		for(j=0;j<i;j++)
		{
			if(pFrameDescr[j].m_FrameID==pFrameDescr[i].m_FrameID) break;			
		}
		
		if(j==i)
		{
			m_pSprite[CurSpriteIndex]=new CSprite;
			m_pSprite[CurSpriteIndex]->create(pFrameDescr[i].m_FrameID,x,y,true);
			
			m_pFrameSpriteIndex[i]=CurSpriteIndex;
			CurSpriteIndex++;
		}
		else
		{
			m_pFrameSpriteIndex[i]=m_pFrameSpriteIndex[j];
		}
		
		m_pPos[i]=CPos(pFrameDescr[i].dx,pFrameDescr[i].dy);
	}
	
	ErrFatalDisplayIf(CurSpriteIndex!=m_NSprites, "Fuckup during aimation creating.");
			
	m_PlaySpeed=speed;
	m_bCycled=bCycled;

	reset();
	setArea(x,y,0,0);
	show(bShow);
	
	m_pSound=NULL;
}

void CAnimation::create(TAnimSoundFrame *pFrameDescr, int NFrames, int x, int y,  int speed, bool bCycled, bool bShow)
{
	ErrFatalDisplayIf(pFrameDescr==NULL || NFrames==0, "Zero frames of animation passed to CAnimation::create");
	
	m_NFrames=NFrames;
	m_pFrameSpriteIndex=new int[NFrames];
	m_pPos=new CPos[NFrames];
	
	m_NSprites=getUniqeFrameIDNumber(pFrameDescr, NFrames);	
	m_pSprite=new CSprite*[m_NSprites];
	
	int i,j,CurSpriteIndex=0;
	
	for(i=0;i<NFrames;i++)
	{
		for(j=0;j<i;j++)
		{
			if(pFrameDescr[j].m_FrameID==pFrameDescr[i].m_FrameID) break;			
		}
		
		if(j==i)
		{
			m_pSprite[CurSpriteIndex]=new CSprite;
			m_pSprite[CurSpriteIndex]->create(pFrameDescr[i].m_FrameID,x,y,true);
			
			m_pFrameSpriteIndex[i]=CurSpriteIndex;
			CurSpriteIndex++;
		}
		else
		{
			m_pFrameSpriteIndex[i]=m_pFrameSpriteIndex[j];
		}
		
		m_pPos[i]=CPos(pFrameDescr[i].dx,pFrameDescr[i].dy);
	}
	
	ErrFatalDisplayIf(CurSpriteIndex!=m_NSprites, "Fuckup during aimation creating.");
			
	m_PlaySpeed=speed;
	m_bCycled=bCycled;

	reset();
	setArea(x,y,0,0);
	show(bShow);
	
	m_pSound=new TSoundDescriptor[m_NFrames];
	
	for(int i=0;i<m_NFrames;i++)
	{
		m_pSound[i].m_Freq=pFrameDescr[i].Freq;
		m_pSound[i].m_Duration=pFrameDescr[i].Duration;
	}
}

int CAnimation::getUniqeFrameIDNumber(TAnimFrame *pFrameDescr, int NFrames)
{
	int i,j,NUID=0;
	for(i=0;i<NFrames;i++)
	{
		for(j=0;j<i;j++)
		{
			if(pFrameDescr[i].m_FrameID==pFrameDescr[j].m_FrameID) break;
		}
		
		if(j==i)
		{
			NUID++;
		}
	}
	
	return NUID;
}

int CAnimation::getUniqeFrameIDNumber(TAnimSoundFrame *pFrameDescr, int NFrames)
{
	int i,j,NUID=0;
	for(i=0;i<NFrames;i++)
	{
		for(j=0;j<i;j++)
		{
			if(pFrameDescr[i].m_FrameID==pFrameDescr[j].m_FrameID) break;
		}
		
		if(j==i)
		{
			NUID++;
		}
	}
	
	return NUID;

}

void CAnimation::draw(bool InvalidateArea)
{
	if(!m_pDstSurf || !m_bShow || (isFinished() && !m_bPauseMode)) return;
	
	if(!m_bPauseMode)
	{	
		m_pSprite[m_pFrameSpriteIndex[m_CurrentFrameIndex]]->draw(InvalidateArea);
				
		if(m_pSound && m_CurrentDraw==0)
		{
			if(m_pSound[m_CurrentFrameIndex].m_Freq >= 0)
			{
				pGame->m_SoundPlayer.playSound(m_pSound[m_CurrentFrameIndex].m_Freq,m_pSound[m_CurrentFrameIndex].m_Duration);
			}
			else
			{
				pGame->m_SoundPlayer.playBoom(m_pSound[m_CurrentFrameIndex].m_Duration);
			}
		}
	
		m_CurrentDraw++;
		
		if(m_CurrentDraw >= m_PlaySpeed)
		{	
			int dx=m_pPos[m_CurrentFrameIndex].x;
			int dy=m_pPos[m_CurrentFrameIndex].y;
		
			m_CurrentFrameIndex++;
			
			if(isFinished() && m_bCycled)
			{
				reset();			
			}
			else
			{
				m_CurrentDraw=0;
			}
		
			setPos(pos.x+dx,pos.y+dy);
		}
	}
	else if(isFinished())
	{
		int dx=m_pPos[m_CurrentFrameIndex-1].x;
		int dy=m_pPos[m_CurrentFrameIndex-1].y;	
		
		setPos(pos.x-dx,pos.y-dy);
		
		m_pSprite[m_pFrameSpriteIndex[m_CurrentFrameIndex-1]]->draw(InvalidateArea);
		
		setPos(pos.x+dx,pos.y+dy);		
	}	
	else // pauseMode() && !isFinished()
	{
		m_pSprite[m_pFrameSpriteIndex[m_CurrentFrameIndex]]->draw(InvalidateArea);	
	}
}

CDrawSurface *CAnimation::setDrawSurface(CDrawSurface *pNewSurface)
{
	CDrawSurface *pRetVal=m_pDstSurf;
	
	CScreenObject::setDrawSurface(pNewSurface);
	
	for(int i=0;i<m_NSprites;i++)
	{
		m_pSprite[i]->setDrawSurface(pNewSurface);
	}	
	
	return pRetVal;
}

void CAnimation::reset(void)
{
	m_CurrentFrameIndex=0;
	m_CurrentDraw=0;
}

void CAnimation::show(bool bShow)
{
	m_bShow=bShow;
}

void CAnimation::setPos(int x, int y)
{
	CArea::setPos(x,y);
	
	if(!isFinished())
	{
		m_pSprite[m_pFrameSpriteIndex[m_CurrentFrameIndex]]->setPos(x,y);
	}
}

bool CAnimation::isFinished(void)
{
	return m_CurrentFrameIndex>=m_NFrames;
}

void CAnimation::restart(void)
{
	for(int i=0;i<m_NFrames;i++)
	{
		pos.x-=m_pPos[i].x;
		pos.y-=m_pPos[i].y;
	}
	
	setPos(pos.x,pos.y);
	reset();
}

CSprite *CAnimation::getFrame(int index)
{
	if(index >= m_NFrames) return NULL;

	return m_pSprite[m_pFrameSpriteIndex[index]];
}

bool CAnimation::setPauseMode(bool bMode)
{
	m_bPauseMode=bMode;
	
	return bMode;
}
