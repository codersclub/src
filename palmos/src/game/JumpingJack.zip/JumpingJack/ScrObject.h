#ifndef _INCLUDE_SCROBJECT_H_
#define _INCLUDE_SCROBJECT_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "Area.h"

class CDrawSurface;

class CScreenObject: public CArea
{
protected:

	CDrawSurface *m_pDstSurf;
	
public:

	virtual void draw(bool bInvalidateArea=true)=0;
	virtual void show(bool bShow=true)=0;		
	
	virtual CDrawSurface *setDrawSurface(CDrawSurface *pNewSurface);	
	
	CScreenObject();
	virtual ~CScreenObject();
};

#endif