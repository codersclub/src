#include <Pilot.h>
#include "State.h"
#include "JackObj.h"

void CState::save(DWord State, DWord Level, DWord LivesLeft, DWord GameState, int JackXPos, int JackYPos, int JackState, int JackNFrame, int JackNDraw, int NCreatures, TCreatureDescriptor *pCreatureDescr, int HolesCompensation, int NHoles, THoleDescriptor* pHoleDescr)
{
	m_State=State;	
	m_Level=Level;
	m_LivesLeft=LivesLeft;
	m_GameState=GameState;	
	m_JackXPos=JackXPos;
	m_JackYPos=JackYPos;
	
	m_JackState=JackState;
	m_NAnimationFrame=JackNFrame;
	m_NCurrentDraw=JackNDraw;
		
	m_NCreatures=NCreatures;	
	m_HolesCompensation=HolesCompensation;
	m_NHoles=NHoles;
			
	FtrSet(puzzleAppCreator,StateFeatureNum,State);
	FtrSet(puzzleAppCreator,LevelFeatureNum,Level);		
	FtrSet(puzzleAppCreator,LivesLeftFeatureNum,LivesLeft);
	FtrSet(puzzleAppCreator,GameStateFeatureNum,GameState);	
	FtrSet(puzzleAppCreator,JackXPosFeatureNum,JackXPos);
	FtrSet(puzzleAppCreator,JackYPosFeatureNum,JackYPos);
	FtrSet(puzzleAppCreator,JackStateFeatureNum,JackState);
	FtrSet(puzzleAppCreator,JackNFrameFeatureNum,JackNFrame);
	FtrSet(puzzleAppCreator,JackNDrawFeatureNum,JackNDraw);

	FtrSet(puzzleAppCreator,NCreaturesFeatureNum,NCreatures);		
	for(int i=0;i<NCreatures;i++)
	{
		m_Creatures[i]=pCreatureDescr[i];	
		
		FtrSet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4, pCreatureDescr[i].m_CreatureIndex);
		FtrSet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 1, pCreatureDescr[i].m_CreatureXPos);
		FtrSet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 2, pCreatureDescr[i].m_CreatureYPos);
		FtrSet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 3, pCreatureDescr[i].m_CreatureNCycles);
	}
	
	FtrSet(puzzleAppCreator,NHolesFeatureNum,m_NHoles);
	FtrSet(puzzleAppCreator,HoleCompensationFeatureNum,m_HolesCompensation);

	for(int i=0;i<NHoles;i++)
	{
		m_Holes[i]=pHoleDescr[i];
		
		FtrSet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3, pHoleDescr[i].m_Direction);
		FtrSet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3 + 1, pHoleDescr[i].m_Level);
		FtrSet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3 + 2, pHoleDescr[i].m_XPos);
	}
}

void CState::load()
{
	if(FtrGet(puzzleAppCreator,StateFeatureNum,&m_State))
	{
		save(savedStateIntro,0,0,0,0,0,0,0,0,0,0,0,0,0);
	}
	else
	{
		FtrGet(puzzleAppCreator,LevelFeatureNum,&m_Level);
		FtrGet(puzzleAppCreator,LivesLeftFeatureNum,&m_LivesLeft);			
		FtrGet(puzzleAppCreator,JackXPosFeatureNum,&m_JackXPos);
		FtrGet(puzzleAppCreator,JackYPosFeatureNum,&m_JackYPos);		
		FtrGet(puzzleAppCreator,JackStateFeatureNum,&m_JackState);
		FtrGet(puzzleAppCreator,JackNFrameFeatureNum,&m_NAnimationFrame);
		FtrGet(puzzleAppCreator,JackNDrawFeatureNum,&m_NCurrentDraw);			
		FtrGet(puzzleAppCreator,NCreaturesFeatureNum,&m_NCreatures);	
		FtrGet(puzzleAppCreator,GameStateFeatureNum,&m_GameState);				
		
		for(int i=0;i<m_NCreatures;i++)
		{
			FtrGet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4, &m_Creatures[i].m_CreatureIndex);
			FtrGet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 1, &m_Creatures[i].m_CreatureXPos);
			FtrGet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 2, &m_Creatures[i].m_CreatureYPos);
			FtrGet(puzzleAppCreator,CreaturesDescrFeatureBaseNum + i * 4 + 3, &m_Creatures[i].m_CreatureNCycles);
		}

		FtrGet(puzzleAppCreator,HoleCompensationFeatureNum,&m_HolesCompensation);
		FtrGet(puzzleAppCreator,NHolesFeatureNum,&m_NHoles);

		for(int i=0;i<m_NHoles;i++)
		{	
			FtrGet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3, &m_Holes[i].m_Direction);
			FtrGet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3 + 1, &m_Holes[i].m_Level);
			FtrGet(puzzleAppCreator,HolesDescrFeatureBaseNum + i * 3 + 2, &m_Holes[i].m_XPos);
		}			
	}
}