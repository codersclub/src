/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "Pilot.h"
#include "Jack_res.h"
#include "Game.h"

static Err RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
	{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==	(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		{
			FrmAlert(RomIncompatibleAlert);
		
			if (romVersion < requiredVersion)
			{
				Err err;				
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		}
		
		return (sysErrRomIncompatible);
	}

	return (0);
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{	
	if(cmd!=sysAppLaunchCmdNormalLaunch) return 0;
		
	if(RomVersionCompatible(0x03003000,launchFlags)) return 0;

	static CGame Game;	
	
	Game.InitApplication();		
	Game.Run();				
	Game.StopApplication();
	
	return 0;
}

