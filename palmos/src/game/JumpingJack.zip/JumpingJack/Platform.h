#ifndef _INCLUDE_PLATFORM_H_
#define _INCLUDE_PLATFORM_H_

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

#include "Area.h"
#include "ScrObject.h"
#include "State.h"

const int LevelsNumber=6;
const int MaxHolesNumber=6;

const Level0Height=136;
const LevelStep=24;

const int HoleWidth=30;
const int HoleHeight=2;
const int HoleStep=3;

struct THole
{
	enum EDir {RightDown, LeftUp};

	EDir m_Direction;	
	int m_Level; // 0..LevelsNumber-1
	int m_XPos;	

	operator CArea() {return CArea(m_XPos,Level0Height-m_Level * LevelStep,HoleWidth,HoleHeight);}
	operator RectangleType() {RectangleType r={m_XPos,Level0Height-m_Level * LevelStep,HoleWidth,HoleHeight}; return r;}

	THole();	
	THole(EDir Direction, int Level, int XPos);
};

class CPlatformObj: public CScreenObject
{
private:
	
	bool m_bShow;
	int m_Compensation;
	int m_NHoles;
	THole m_Hole[MaxHolesNumber];
	
public:

	virtual void draw(bool InvalidateArea=true);
	virtual void show(bool bShow=true);
	
public:

	void create(bool bShow=true);
	void create(int HolesCompensation, int NHoles, THoleDescriptor* pHoleDescr, bool bShow=true);
	void action(void);	
	void resetObject(void);
	void addHole(const THole& Hole);
	void addHoleRandom();
	void removeHoles(void);
	bool isPassable(int NLevel, const CArea& TestArea);
	bool checkMinimalDistance(const THole& Hole);
	void getState(int &Compensation, int &NHoles, THoleDescriptor *Holes);
};

#endif //_INCLUDE_PLATFORM_H_


