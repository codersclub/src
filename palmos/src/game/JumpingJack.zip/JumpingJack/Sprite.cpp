#include "Pilot.h"
#include "Sprite.h"
#include "DrawSurface.h"

/* 
Jumping Jack by Stanislav Tihohod 
Copyright (c) 2002 by Stanislav Tihohod. 
*/

void CSprite::create(int resID, int x, int y, bool bShow)
{
	Word error;
	
	WinHandle oldDrawWinH = WinGetDrawWindow();
	
	m_hBmp=(Handle)DmGetResource(bitmapRsc, resID);
	m_pBitmap=(BitmapPtr)MemHandleLock(m_hBmp);		
	m_hWnd = WinCreateOffscreenWindow(m_pBitmap->width, m_pBitmap->height, screenFormat, &error);
	ErrFatalDisplayIf(error, "Error loading images");
	WinSetDrawWindow(m_hWnd);
	WinDrawBitmap(m_pBitmap, 0, 0);
		
	WinSetDrawWindow(oldDrawWinH);
	
	MemPtrUnlock(m_pBitmap);
	DmReleaseResource(m_hBmp);
		
	setArea(x,y,m_pBitmap->width,m_pBitmap->height);
	show(bShow);
	setDrawSurface(NULL);
}

void CSprite::draw(bool InvalidateArea)
{	
	if(!m_pDstSurf || !m_bShow) return;

	RectangleType srcR={{0,0},{size.cx,size.cy}};		
	WinCopyRectangle(m_hWnd, m_pDstSurf->getSurfaceHandle(), &srcR, pos.x, pos.y, scrOR);
	
	if(InvalidateArea) m_pDstSurf->addFreshArea(*this);
}

void CSprite::show(bool bShow)
{
	m_bShow=bShow;
}

CSprite::~CSprite()
{
	WinDeleteWindow(m_hWnd,false);
}