Patterns for Pocket Life - Conway's life game in your shirt pocket

How to use?

1. create 'Life' category in Memo Pad.
2. import pattern file in Pilot Desktop.
3. HotSync.
4. launch Pocket Life.
5. tap on 'load' button, select a pattern, ok.
6. go.

Patterns (from glossary.doc, compiled by Al Hensel, et al.)

blinker ship - an object which travels while growing larger by
  leaving an increasing trail of blinkers, but which leaves no
  permanent exhaust.

glider gun - any pattern that grows forever by emitting gliders.

pi-heptomino - a common pattern in life.

puffer, puffer train - any pattern that moves, leaving a trail.

r-pentomino - stop with `Period: 2 (from 1103), with 6 glider(s)'.

rabbits - another small but vigorously growing population.
  (If you look closely you can see a male and female rabbit!)

switch engine - the smallest forever-growing pattern.
