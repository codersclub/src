Pocket Life ver 0.7 - Conway's life game in your shirt pocket


Features

In this release, you can:
- import life patterns from `Life' category in Memo Pad.
  (by `Load...' command in `Life' menu.)
- generate random pattern with rectangular or circular shape.
- go, stop, step forward, step backward, go until, and reset.
- scroll by dragging the central area or tapping on the edge.
- magnify or demagnify life patterns from 1/64 to x16.
- preserve life pattern when you switch to another application.

and you can't:
- edit life patterns: import *.life files, or type in Memo Pad.
- no online documentation, etc...


Revision History

ver 0.7 (2002/05/13)
- load pattern file from "/PALM/Programs/Life" directory on VFS.
- support high-res screen of Sony CLIE series and HandEra 330.
- source code is under the terms of the GNU GPL.

ver 0.6 (2001/09/26)
- preserve life pattern when you switch to another application.
- generate random pattern with rectangular or circular shape.
- scroll by dragging, etc.

ver 0.5 (2001/09/12)
- implement magnifying (both zoom up to x16 and down to 1/64).
- integrate fast forward/backward and step forward/backward buttons.
- fix some bugs.

ver 0.4 (1999/08/31)
- improve performance and decrease flicker.
- extend the universe from 8192 x 8192 to 32768 x 32768.
- add fast forward and fast backward buttons.
- add `Out of...' dialog and fix a nasty bug which merely happen.
- add `Loop Detected' dialog, and detect gliders flying away.
  (e.g. r-pentomino stops with `Period: 2 (from 1103), with 6 glider(s)').

ver 0.3 (1999/08/23)
- compatible with Palm IIIx/V (maybe...).
- support step backward command without losing performance.
- support go until command with time option.

ver 0.2 (1998/07/08)
- compiled with prc-tools 0.5.0.
- increase the maximum number of life cells, especially on Pilot
  1000, 5000, and PalmPilot Personal.
- support page up and page down keys in load dialog.

ver 0.1 (1997/09/12)
- initial release


See also

Newest release of this software may be found at:
    http://www.sra.co.jp/people/hoshi/palmos/pocket-life.html

You can learn about the life game at:
    http://www.reed.edu/alife/classes/gameoflife.html

You can find a lot of interesting life patterns at:
    http://www.radicaleye.com/lifepage/

Pocket Life's algorithm is inspired by Paul Callahan's Java applet,
described at:
    http://www.radicaleye.com/lifepage/patterns/javalife.html#algorithm


Hoshi Takanori (hoshi@sra.co.jp, http://www.sra.co.jp/people/hoshi/)
