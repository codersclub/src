/*
 * $Id: patience.c,v 1.16 1999/10/24 21:54:15 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "patience.h"
#include "patienceRsc.h"
#include <System/SysEvtMgr.h>
#include <stdio.h>

static RulesType  *games[] = {
    &klondikeGame,
    &montanaGame,
    &towersGame,
    &spiderGame,
    &tabbyGame,
    &golfGame,
    &acesGame,
    &calcGame,
    &yukonGame,
    &spideretteGame,
    &eightGame,
    &canfieldGame,
    &vegasGame,
    &freecellGame,
    &wishGame,
};

#define NUM_GAMES   (sizeof (games) / sizeof (games[0]))

GameType	game;
DmOpenRef	undoDB;

PatS	cardWidth;	/* displayed width of cards */
PatS	cardHeight;	/* displayed height of cards */
PatS	cardSpace;	/* space between stacks of cards */
PatS	cardLabel;	/* offset of label in card */
PatS	cardRadius;	/* corner radius of card */
PatS	cardXOffset;	/* distance to next stack */
PatS	cardYOffset;
PatS	cardOriginX;	/* offset of all stacks */
PatS	cardOriginY;
PatS	cardLabelWidth;	/* max width of card label element */
PatS	cardLabelHeight;/* max height of card label element */

PatS	xOffset;	/* distance to next card in same stack */
PatS	yOffset;	

CustomPatternType   backPattern = {
    0xeebb, 0xdd77, 0xeebb, 0xdd77,
};

CustomPatternType   tablePattern = {
    0x1100, 0x4400, 0x1100, 0x4400,
};

CustomPatternType   emptyPattern = {
    0, 0, 0, 0,
};

CustomPatternType   myBlackPattern = {
    0xffff, 0xffff, 0xffff, 0xffff,
};

#define TRACK_TIMEOUT	(sysTicksPerSecond / 5)
#define TRACK_BOX	3
#define HINT_TIMEOUT	(sysTicksPerSecond / 2)

static void StartApplication(void);
static Boolean MainFormHandleEvent(EventPtr event);
static void EventLoop(void);
FormPtr mainFrm;
FormPtr rulesFrm;
Boolean needRedisplay;
CardBool    tracking;
Boolean	    pressed;
Boolean	    awaitingTracking;
PatS	    downX, downY;
PatS	    downTime;

static void
SetSizes (void)
{
    PatS    	    maxx, maxy;
    CardStackIndex  stack;
    CardStackType   *sp;
    RectangleType   r;
    Boolean	    hasArbX, hasArbY;
    
    maxx = 0; maxy = 0;
    hasArbX = false;
    hasArbY = false;
    for (stack = 0; stack < game.nstacks; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->pos.x > maxx)
	    maxx = sp->pos.x;
	if (sp->pos.y > maxy)
	    maxy = sp->pos.y;
	switch (sp->display) {
	case CardDisplayAll:
	case CardDisplaySome:
	case CardDisplayPack:
	    if (sp->horizontal)
		hasArbX = true;
	    else
		hasArbY = true;
	    break;
	default:
	}
    }
    maxx = maxx + 1;
    maxy = maxy + 1;
    FrmGetFormBounds (mainFrm, &r);
    cardWidth = r.extent.x / maxx;
    if (cardWidth > CARD_WIDTH)
	cardWidth = CARD_WIDTH;
    cardHeight = r.extent.y / maxy;
    if (cardHeight > CARD_HEIGHT)
	cardHeight = CARD_HEIGHT;
    if (cardWidth < CARD_WIDTH)
    {
	cardSpace = 4 - (CARD_WIDTH - cardWidth);
	if (cardSpace < 1)
	    cardSpace = 1;
	cardRadius = 0;
	if (cardSpace >= 2)
	    cardLabel = 2;
	else
	    cardLabel = 1;
    }
    else
    {
	cardSpace = 4;
	cardRadius = 1;
	cardLabel = 3;
    }
    xOffset = cardLabelWidth + cardLabel + 1;
    yOffset = cardLabelHeight + cardLabel + 1;
    cardOriginX = 0;
    if (!hasArbX)
	cardOriginX = (r.extent.x - cardWidth * maxx) >> 1;
    cardOriginY = 0;
    if (!hasArbY)
	cardOriginY = (r.extent.y - cardHeight * maxy) >> 1;
}

PatL
Random (PatL max)
{
    PatL    v;

    v = game.randomSeed;
    if (!v)
	v = 1;
    game.randomSeed = SysRandom (v);
    v = game.randomSeed;
    if (max)
    {
	if (v < 0)
	    v = -v;
        v %= max;
    }
    return v;
}

void
SRandom (PatL seed)
{
    game.randomSeed = seed;
}

static void
Redisplay (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    RectangleType   r;
    
    FrmEraseForm (mainFrm);
    FntSetFont (stdFont);
    FrmGetFormBounds (mainFrm, &r);
    WinSetPattern (tablePattern);
    WinFillRectangle (&r, 0);
    WinSetPattern (emptyPattern);
    if (game.playing)
    {
	game.queryDirty = True;
	game.alwaysDirty = True;
	for (stack = 0; stack < game.nstacks; stack++)
	{
	    sp = CardStackPtr (stack);
	    if (sp->display != CardDisplayNone)
		sp->dirty = True;
	}
	CardRedisplay ();
    }
}

static void
SetQueryMode (CardBool queryMode)
{
    game.queryMode = queryMode;
    game.queryDirty = True;
    CardRedisplay ();
}

static void
SetAutoMode (CardBool autoMode)
{
    game.alwaysAuto = autoMode;
    game.alwaysDirty = True;
    if (game.alwaysAuto)
	CardAutoPlay (games[game.gameKind]);
    CardRedisplay ();
}

static void
SetHanded (CardBool leftHanded)
{
    CardSetHanded (games[game.gameKind], leftHanded);
    if (game.playing)
        Redisplay ();
}

CardBool 
(*CurrentPackFunction (void)) (CardIndex, CardIndex)
{
    return games[game.gameKind]->Pack;
}

FormPtr	dialogFrm;
Boolean	(*DoDialogHandleEvent)(EventPtr);
void	(*DialogIdleFunc)(void);
Boolean	bitsSaved;

Boolean
DialogHandleEvent (EventPtr event)
{
    Boolean ret;
    
    if (dialogFrm->bitsBehindForm)
        bitsSaved = true;
    if (DoDialogHandleEvent)
	ret = (*DoDialogHandleEvent) (event);
    else
	ret = false;
    if (DialogIdleFunc)
    {
	/*
	 * When the form comes up, queue a magic
	 * update event so that when the queue is
	 * mostly empty, we'll get it.  The singing
	 * function will eat any non pen-down events
	 * so we don't want to lose anything important.
	 */
	switch (event->eType) {
	case winEnterEvent:
	    FrmUpdateForm (dialogFrm->formId, 1);
	    break;
	case frmUpdateEvent:
	    if (event->data.frmUpdate.updateCode)
	    {
		ret = true;
		(*DialogIdleFunc) ();
		DialogIdleFunc = 0;
	    }
	    break;
	default:
	}
    }
    return ret;
}

Int
DoDialog (FormPtr   frm,
	  Boolean   (*HandleEvent)(EventPtr))
{
    Int	    r;

    DoDialogHandleEvent = HandleEvent;
    dialogFrm = frm;
    bitsSaved = false;
    FrmSetEventHandler (frm, DialogHandleEvent);
    r = FrmDoDialog (frm);
    if (!bitsSaved)
	needRedisplay = true;
    return r;
}

void
Help (Int   id)
{
    FormPtr	frm;

    frm = FrmInitForm (id);
    if (frm)
    {
	(void) DoDialog (frm, 0);
	FrmDeleteForm (frm);
    }
}

static void
RulesSetScrolling (void)
{
    FieldPtr	    field;

    field = FrmGetObjectPtr (rulesFrm, FrmGetObjectIndex (rulesFrm, rulesText));
    FrmUpdateScrollers (rulesFrm,
			FrmGetObjectIndex (rulesFrm, rulesScrollUp),
			FrmGetObjectIndex (rulesFrm, rulesScrollDown),
			FldScrollable (field, up),
			FldScrollable (field, down));
}

static void
RulesScroll (DirectionType dir, CardBool screen)
{
    FieldPtr	    field;
    Word	    fieldIndex;
    Word	    lines;

    fieldIndex = FrmGetObjectIndex (rulesFrm, rulesText);
    field = FrmGetObjectPtr (rulesFrm, fieldIndex);
    if (screen)
    {
	lines = FldGetVisibleLines (field) - 2;
	if (lines < 1)
	    lines = 1;
    }
    else
	lines = 1;
    FldScrollField (field, lines, dir);
    RulesSetScrolling ();
}

static Boolean RulesFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    
    switch (event->eType) {
    case ctlRepeatEvent:
	switch (event->data.ctlRepeat.controlID) {
	case rulesScrollUp:
	    RulesScroll (up, False);
	    break;
	case rulesScrollDown:
	    RulesScroll (down, False);
	    break;
	}
	break;
    case ctlSelectEvent:
	switch (event->data.ctlSelect.controlID) {
	case rulesScrollUp:
	    RulesScroll (up, False);
	    break;
	case rulesScrollDown:
	    RulesScroll (down, False);
	    break;
	}
	break;
    case keyDownEvent:
	switch (event->data.keyDown.chr) {
	case pageDownChr:
	    RulesScroll (down, True);
	    handled = true;
	    break;
	case pageUpChr:
	    RulesScroll (up, True);
	    handled = true;
	    break;
	}
	break;
    default:
    }
    return handled;
}

void
Rules (Int id)
{
    FieldPtr	field;
    VoidHand	rulesH;
    
    rulesH = DmGetResource ('tSTR', id);
    if (rulesH)
    {
	rulesFrm = FrmInitForm (rulesForm);
	field = FrmGetObjectPtr (rulesFrm, 
				 FrmGetObjectIndex (rulesFrm, rulesText));
	FldSetInsPtPosition (field, 0);
	FldSetTextHandle (field, (Handle) rulesH);
	RulesSetScrolling ();
	DoDialog (rulesFrm, RulesFormHandleEvent);
	FldSetTextHandle (field, 0);
	DmReleaseResource (rulesH);
	FrmDeleteForm (rulesFrm);
    }
}

static void
RestartGame (void)
{
    if (!game.playing)
	return;
    CardInit (games[game.gameKind]);
    SetSizes ();
    needRedisplay = True;
}

static SWord
WhichGame (FormPtr newFrm)
{
    Word	cur;
    ControlPtr	gameBtn;

    for (cur = 0; cur < NUM_GAMES; cur++)
    {
	gameBtn = FrmGetObjectPtr (newFrm,
				   FrmGetObjectIndex (newFrm,
						      newFormFirstGame + cur));
	if (CtlGetValue (gameBtn))
	    return cur;
    }
    return -1;
}

static void
SelectGameEntertain (void)
{
    PlayRandomSong (True);
}

static void
SelectGame (Boolean entertain)
{
    FormPtr	newFrm;
    ControlPtr	gameBtn;
    ControlPtr	cancelBtn;
    Word	cur;
    Word	gameKind = -1;
    Word	btn;

    newFrm = FrmInitForm (newForm);
    /*
     * Set game selection buttons appropriately
     */
    for (cur = 0; cur < NUM_GAMES; cur++)
    {
	gameBtn = FrmGetObjectPtr (newFrm, 
				   FrmGetObjectIndex (newFrm, 
						      newFormFirstGame + cur));
	if (game.gameKind == cur)
	    CtlSetValue (gameBtn, 1);
	else
	    CtlSetValue (gameBtn, 0);
    }
    
    /*
     * Only enable the cancel button if a game is in progress
     */
    cancelBtn = FrmGetObjectPtr (newFrm, FrmGetObjectIndex (newFrm, newFormCancelBtn));
    CtlSetUsable (cancelBtn, game.playing);
    
    if (entertain)
	DialogIdleFunc = SelectGameEntertain;
    
    for (;;)
    {
	btn = DoDialog (newFrm, 0);
	switch (btn)
	{
	case newFormNewBtn:
	    gameKind = WhichGame (newFrm);
	    break;
	case newFormRulesBtn:
	    gameKind = WhichGame (newFrm);
	    if (0 <= gameKind && gameKind < NUM_GAMES)
		Rules (rulesFirst + gameKind);
	    continue;
	case newFormCancelBtn:
	    gameKind = -1;
	    break;
	default:
	    break;
	}
	break;
    }
    FrmDeleteForm (newFrm);
    if (0 <= gameKind && gameKind < NUM_GAMES)
    {
	game.gameKind = gameKind;
	game.gameSeed = TimGetTicks ();
	game.playing = True;
	game.queryMode = False;
	RestartGame ();
    }
}

static void
Save (void)
{
    PrefSetAppPreferencesV10 (PatienceFileCreator, PatienceVersionNum,
			      &game, sizeof (GameType));
}

static void
Restore (void)
{
    if (!PrefGetAppPreferencesV10 (PatienceFileCreator, PatienceVersionNum,
				   &game, sizeof (GameType)))
    {
	game.playing = False;
	game.leftHanded = False;
	game.gameKind = 0;
    }
}

void
DeleteUndoDB (void)
{
    Err	    err;
    LocalID dbID;
    UInt    cardNo;
    
    if (undoDB)
    {
	err = DmOpenDatabaseInfo (undoDB, &dbID, NULL, NULL, &cardNo, NULL);
	DmCloseDatabase (undoDB);
	undoDB = 0;
	if (!err)
	    DmDeleteDatabase (cardNo, dbID);
    }
    game.historyTop = 0;
    game.historyChunk.historyTop = 0;
}
static void
OpenUndoDB (void)
{
    Err	err;
    
    undoDB = DmOpenDatabaseByTypeCreator (PatienceDBType, PatienceDBCreator,
					  dmModeReadWrite);
    if (!undoDB)
    {
	err = DmCreateDatabase (0, "Patience History", PatienceDBCreator, PatienceDBType, false);
	if (err)
	    return;
	undoDB = DmOpenDatabaseByTypeCreator (PatienceDBType, PatienceDBCreator,
					      dmModeReadWrite);
    }
}

static void
StartApplication (void)
{
    mainFrm = 0;
    MemSet (&game, sizeof (GameType), '\0');
    OpenUndoDB ();
    Restore ();
    CardLabelInit ();
    game.nhint = 0;
    game.queryMode = False;
    game.srcStack = NullIndex;
    game.srcCard = NullIndex;
}

static PatI
abs (PatI x)
{
    return x >= 0 ? x : -x;
}

static void CheckTracking (PatI x, PatI y)
{
    if (game.srcStack != NullIndex && 
	game.srcCard != NullIndex)
    {
	if (TimGetTicks() >= downTime + TRACK_TIMEOUT ||
	    abs (x - downX) > TRACK_BOX || abs (y - downY) > TRACK_BOX)
	{
	    tracking = CardStartAnimate (x, y,
					 game.srcStack, 
					 game.srcCard);
	    awaitingTracking = false;
	}
    }
}

static void CheckQuery (PatI x, PatI y)
{
    CardStackIndex  stack;
    CardIndex	    card;
    PatI	    c_x, c_y;
    
    stack = NullIndex;
    if (!CardHit (x, y, &stack, &card, &c_x, &c_y))
	return;
    
    if (card == NullIndex)
	return;
    
    if (stack == game.srcStack && card == game.srcCard)
	return;
    
    game.srcStack = stack;
    game.srcCard = card;
    tracking = CardStartAnimate (c_x, c_y, stack, card);
}

static Boolean MainFormHandleEvent(EventPtr event)
{
    Boolean	    wasPlaying;
    Boolean	    handled = false;
    Boolean	    shouldTrack = false;
    CardStackIndex  dstStack;
    CardIndex	    dstCard;

    wasPlaying = game.playing;
    switch (event->eType) {
    case penDownEvent:
	if (0 <= event->screenX && event->screenX < 160 &&
	    0 <= event->screenY && event->screenY < 160 &&
	    game.playing)
	{
	    pressed = true;
	    handled = true;
	    game.srcStack = NullIndex;
	    downX = event->screenX;
	    downY = event->screenY;
	    downTime = TimGetTicks ();
	    if (game.queryMode)
	    {
		CheckQuery (event->screenX, event->screenY);
		shouldTrack = tracking;
	    }
	    else
	    {
		(void) CardHit (event->screenX, event->screenY, 
				&game.srcStack, &game.srcCard,
				0, 0);
		awaitingTracking = true;
	    }
	}
	break;
    case penMoveEvent:
	handled = pressed;
	if (game.playing)
	{
	    if (game.queryMode)
	    {
		downX = event->screenX;
		downY = event->screenY;
		CheckQuery (event->screenX, event->screenY);
	    }
	    else
	    {
		if (tracking)
		    CardMoveAnimate (event->screenX, event->screenY);
		else
		    CheckTracking (event->screenX, event->screenY);
	    }
	    shouldTrack = tracking;
	}
	break;
    case penUpEvent:
	handled = pressed;
	pressed = false;
	awaitingTracking = false;
	if (tracking)
	{
	    CardStopAnimate ();
	    tracking = False;
	}
	if (game.playing && !game.queryMode)
	{
	    if (game.srcStack != NullIndex &&
		CardHit (
			 event->data.penUp.end.x, event->data.penUp.end.y,
			 &dstStack, &dstCard,
			 0, 0))
	    {
		CardPlay (games[game.gameKind], 
			  game.srcStack, dstStack, game.srcCard);
	    }
	}
	game.srcStack = NullIndex;
	break;
    case frmUpdateEvent:
	if (event->data.frmUpdate.formID == mainForm)
	{
	    Redisplay ();
	    handled = true;
	    needRedisplay = false;
	}
	break;
    case frmOpenEvent:
	if (event->data.frmOpen.formID == mainForm)
	{
	    FrmDrawForm (mainFrm);
	    if (game.playing)
	    {
		SetSizes ();
		needRedisplay = true;
	    }
	    else
	    {
		Redisplay ();
		SelectGame (false);
	    }
	}
	break;
    case menuEvent:
	switch (event->data.menu.itemID) {
	case menuPatienceHint:
	    if (game.playing)
		CardHint (games[game.gameKind]);
	    break;
	case menuPatienceAuto:
	    if (game.playing)
	    {
		CardAutoPlay (games[game.gameKind]);
		CardRedisplay ();
	    }
	    break;
	case menuPatienceUndo:
	    if (game.playing)
		CardUndo ();
	    break;
	case menuPatienceRestart:
	    if (game.playing)
		RestartGame ();
	    break;
	case menuPatienceNew:
	    SelectGame (false);
	    break;
	    
	case menuPatienceAlwaysAuto:
	    if (game.playing)
		SetAutoMode (!game.alwaysAuto);
	    break;
	case menuPatienceExamine:
	    if (game.playing)
		SetQueryMode (!game.queryMode);
	    break;
	case menuPatienceLeftHanded:
	    SetHanded (!game.leftHanded);
	    break;
	    
	case menuHelpControls:
	    Help (controlForm);
	    break;
	case menuHelpRules:
	    Rules (game.gameKind + rulesFirst);
	    break;
	case menuHelpGetInfo:
	    Help (infoForm);
	    break;
	}
	handled = true;
	break;
    case keyDownEvent:
	switch (event->data.keyDown.chr) {
	case 'c':
	case 'C':
	    Help (controlForm);
	    handled = true;
	    break;
	case 'r':
	case 'R':
	    Rules (game.gameKind + rulesFirst);
	    handled = true;
	    break;
	case 'i':
	case 'I':
	    Help (infoForm);
	    handled = true;
	    break;
	case 'h':
	case 'H':
	    if (game.playing)
		CardHint (games[game.gameKind]);
	    handled = true;
	    break;
	case 'a':
	case 'A':
	    if (game.playing)
	    {
		CardAutoPlay (games[game.gameKind]);
		CardRedisplay ();
	    }
	    handled = true;
	    break;
	case pageUpChr:
	case 'u':
	case 'U':
	    if (game.playing)
		CardUndo ();
	    handled = true;
	    break;
	case 's':
	case 'S':
	    RestartGame ();
	    handled = true;
	    break;
	case 'n':
	case 'N':
	    SelectGame (false);
	    handled = true;
	    break;
	    
	case pageDownChr:
	case 'e':
	case 'E':
	    SetQueryMode (!game.queryMode);
	    if (tracking && !game.queryMode)
	    {
		CheckTracking (downX, downY);
		shouldTrack = tracking;
		break;
	    }
	    handled = true;
	    break;
	case 'l':
	case 'L':
	    SetHanded (!game.leftHanded);
	    handled = true;
	    break;
	case 'p':
	case 'P':
	    PlayRandomSong (True);
	    handled = true;
	    break;
	}
	break;
    default:
    }
    if (tracking && !shouldTrack)
    {
	CardStopAnimate ();
	tracking = False;
    }

    if (wasPlaying && !game.playing)
    {
    	SelectGame (true);
    }
    return(handled);
}

static Boolean ApplicationHandleEvent (EventPtr event)
{
    Word formId;
    FormPtr frm;

    if (event->eType == frmLoadEvent)
    {
	// Load the form resource.
	formId = event->data.frmLoad.formID;
	frm = FrmInitForm (formId);
	if (frm)
	{
	    switch (formId) {
	    case mainForm:
		mainFrm = frm;
		FrmSetEventHandler (frm, MainFormHandleEvent);
		break;
	    }
	    FrmSetActiveForm (frm);
	}

	// Set the event handler for the form.  The handler of the currently
	// active form is called by FrmHandleEvent each time is receives an
	// event.
	return (true);
    }
    return (false);
}

static void 
EventLoop(void)
{
    EventType	event;
    SDWord	timeout, now;
    Word	error;

    do
    {
	if (needRedisplay)
	    timeout = 0;
	else if (awaitingTracking && !tracking)
	{
	    now = TimGetTicks();
	    timeout = downTime + TRACK_TIMEOUT;
	    if (timeout < now)
		timeout = 0;
	    else
		timeout = timeout - now;
	}
	else if (game.nhint > 0)
	    timeout = HINT_TIMEOUT;
	else
	    timeout = evtWaitForever;
	// Get the next available event.
	EvtGetEvent(&event, timeout);

	if (needRedisplay && event.eType == nilEvent)
	    FrmUpdateForm (mainForm, frmRedrawUpdateCode);
	
	if (awaitingTracking && !tracking)
	    CheckTracking (downX, downY);
	
	if (game.nhint > 0 && event.eType != penUpEvent)
	    CardUnshowHint ();

	if (event.eType == nilEvent)
	    continue;
	    
	/* Give the system a chance to handle the event. */
	if (! SysHandleEvent (&event))
	{
	    if (!MenuHandleEvent (0, &event, &error))
	    {
		/* Give the application a chance to handle the event. */
		if (!ApplicationHandleEvent (&event))
		{
		    /* Let the form object provide default handling of the event. */
		    FrmDispatchEvent (&event);
		}
	    }
	}
    } 
    while (event.eType != appStopEvent);
    // ** SPECIAL NOTE **
    // In order for the Emulator to exit
    // cleanly when the File|Quit menu option is
    // selected, the running application
    // must exit.  The emulator will generate an 
    // �appStopEvent� when Quit is selected.
}

static void 
StopApplication(void)
{	
    if (tracking)
    {
	CardStopAnimate ();
	tracking = False;
    }
    Save ();
    CardLabelFini ();
    
    // P11. Close all open forms to allow their frmCloseEvent handlers
    // to execute.  An appStopEvent doesn't send frmCloseEvents.
    // FrmCloseAllForms will send all opened forms a frmCloseEvent.
    FrmCloseAllForms ();
    if (undoDB)
    {
	DmCloseDatabase (undoDB);
	undoDB = 0;
    }
}

#if 0
#define DIAG(s)	printf(s); SysTaskDelay (sysTicksPerSecond/4);
#else
#define DIAG(s)
#endif

DWord 
PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
    if (cmd == sysAppLaunchCmdNormalLaunch)
    {
	DIAG ("StartApplication\n");
	// Set up initial form.
	StartApplication();

	DIAG ("FrmGotoForm\n");
	FrmGotoForm (mainForm);

	// Start up the event loop.
	DIAG ("EventLoop\n");
	EventLoop();

	// Clean up before exiting
	DIAG ("StopApplication\n");
	StopApplication();
	DIAG ("Patience done\n");
    }

    return(0);
}
