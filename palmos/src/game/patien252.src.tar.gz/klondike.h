/*
 * $Id: klondike.h,v 1.2 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#define KlondikeDeck	0
#define KlondikeDiscard	1
#define KlondikePile	2
#define KlondikeNpile	4
#define KlondikeLpile	(KlondikePile + KlondikeNpile - 1)
#define KlondikeTable	6
#define KlondikeNtable	7
#define KlondikeLtable	(KlondikeTable + KlondikeNtable - 1)
#define KlondikeNstack	13

CardSetupType	KlondikeSetup[];
CardSetupType	KlondikeSetupLeft[];

CardBool
KlondikeSelectStack (CardStackIndex stack,
		     CardIndex	    *first,
		     CardIndex	    *last);

CardProgressType
KlondikeCheckTable (CardStackIndex  src, 
		    CardStackIndex  dst,
		    CardIndex	    card);

CardProgressType
KlondikeCheckPile (CardStackIndex   src, 
		   CardStackIndex   dst,
		   CardIndex	    card);

CardBool
KlondikeSelectDeck (CardStackIndex  stack,
		    CardIndex	    *first, 
		    CardIndex	    *last);

void
KlondikeMoveDeal (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last);

void
KlondikeMoveReset(CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last);

CardBool
KlondikeSelectResetDeck (CardStackIndex stack,
			 CardIndex	*first,
			 CardIndex	*last);

CardBool
KlondikeNormalize (void);
