/*
 * $Id: wish.c,v 1.1 1999/05/11 07:08:54 keithp Exp $
 *
 * Copyright � 1999 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define WishDeck    0
#define WishTable   1
#define WishNtable  8
#define WishLtable  (WishTable + WishNtable - 1)
#define WishNstack  9

CardSetupType	WishSetup[] = {
    { { 2, 2 }, { 2, 2 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },

    { { 1, 0 }, { 1, 0 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    { { 3, 0 }, { 3, 0 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    
    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    
    { { 0, 3 }, { 0, 3 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    { { 4, 3 }, { 4, 3 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    
    { { 1, 4 }, { 1, 4 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    { { 3, 4 }, { 3, 4 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
};

static CardProgressType
WishCheckMatch (CardStackIndex	src,
		CardStackIndex	dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);
    CardType	    *s, *d;

    if (src == dst)
	return CardProgressCant;
    
    if (dp->last == NullIndex)
	return CardProgressCant;

    d = CardPtr (dp->last);
    s = CardPtr (card);
    if (Rank (d->card) != Rank (s->card))
	return CardProgressCant;
    return CardProgressSome;
}

void
WishMoveMatch (CardStackIndex	src,
	       CardStackIndex	dst,
	       CardIndex	s)
{
    CardIndex	d;

    d = CardStackPtr (dst)->last;
    CardMove (src, s, WishDeck, True);
    CardMove (dst, d, WishDeck, True);
}

CardMoveType WishMoves[] = {
    /* 0    Move matching cards to deck */
    {	"match to deck",
	{ WishTable, WishLtable },
	{ WishTable, WishLtable },
	{ WishTable, WishLtable },
	CardMoveHelpful,
	0,
	WishCheckMatch,
	WishMoveMatch,
    },
};

#define NMOVES	(sizeof (WishMoves) / sizeof (WishMoves[0]))

CardBool
WishNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;
    CardBool	    done = True;

    for (stack = WishTable; stack <= WishLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    done = False;
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    return done;
}
    
RulesType   wishGame = {
    MakeCard (0, CLUB, 7), MakeCard (0, SPADE, ACE), 1, WishNstack,
    WishNormalize,
    0,
    0,
    WishSetup,
    NMOVES,
    WishMoves
};
