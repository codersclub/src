/*
 * $Id: calc.c,v 1.6 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define CalcDeck    0
#define CalcTable   1
#define CalcNtable  4
#define CalcLtable  (CalcTable + CalcNtable - 1)
#define CalcPile    (CalcTable + CalcNtable)
#define CalcNpile   4
#define CalcLpile   (CalcPile + CalcNpile - 1)
#define CalcNstack  (CalcPile + CalcNpile)

CardSetupType	CalcSetup[] = {
    { { 4, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },

    { { 0, 0 }, { 1, 0 }, CardEmpty, CardDisplayAll, False, False, 0, CardStartUp },
    { { 1, 0 }, { 2, 0 }, CardEmpty, CardDisplayAll, False, False, 0, CardStartUp },
    { { 2, 0 }, { 3, 0 }, CardEmpty, CardDisplayAll, False, False, 0, CardStartUp },
    { { 3, 0 }, { 4, 0 }, CardEmpty, CardDisplayAll, False, False, 0, CardStartUp },
    
    { { 4, 1 }, { 0, 1 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
    { { 4, 2 }, { 0, 2 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
    { { 4, 3 }, { 0, 3 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
    { { 4, 4 }, { 0, 4 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
};

static void
CalcInitialize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;
    Card	    rank;

    sp = CardStackPtr (CalcDeck);
    for (card = sp->last; card != NullIndex; card = cp->prev)
    {
	cp = CardPtr (card);
	CardTurn (CalcDeck, card, True, False);
    }
    for (stack = CalcPile, rank = 1; stack <= CalcLpile; stack++, rank++)
    {
	for (card = sp->last; card != NullIndex; card = cp->prev)
	{
	    cp = CardPtr (card);
	    if (Rank (cp->card) == rank)
	    {
		CardMoveCard (CalcDeck,
			      card, card,
			      stack, NullIndex, False);
		break;
	    }
	}
    }
}

static CardProgressType
CalcCheckPile (CardStackIndex	src,
	       CardStackIndex	dst,
	       CardIndex	card)
{
    Card	    rank, rankoff;
    CardStackType   *sp = CardStackPtr (src);
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    rankoff = (dst - CalcPile) + 1;
    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == rankoff)
	    return CardProgressSome;
    }
    else
    {
	rank = Rank (CardPtr (dp->last)->card);
	if (rank == KING)
	    return CardProgressCant;
	rank = rank + rankoff;
	if (rank > KING)
	    rank = rank - KING;
	if (Rank (CardPtr (sp->last)->card) == rank)
	    return CardProgressSome;
    }
    return CardProgressCant;
}

CardMoveType	CalcMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ CalcTable, CalcLtable },
	{ CalcTable, CalcLtable },
	{ CalcPile, CalcLpile },
	CardMoveHelpful,
	0,
	CalcCheckPile,
	0
    },
    /* 1    Move card from deck to pile */
    {	"deck to pile",
	{ CalcDeck, CalcDeck },
	{ CalcDeck, CalcDeck },
	{ CalcPile, CalcLpile },
	CardMoveHelpful,
	0,
	CalcCheckPile,
	0
    },
    /* 2    Move card from deck to table */
    {	"deck to table",
	{CalcDeck, CalcDeck },
	{CalcDeck, CalcDeck },
	{CalcTable, CalcLtable },
	CardMoveHelpful,
	0,
	0,
	0
    },
};

#define NMOVES (sizeof (CalcMoves) / sizeof (CalcMoves[0]))

static CardBool
CalcNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    
    for (stack = CalcPile; stack <= CalcLpile; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    return False;
	if (Rank (CardPtr (sp->last)->card) != KING)
	    return False;
    }
    return True;
}

RulesType   calcGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, CalcNstack,
    CalcNormalize,
    CalcInitialize,
    0,
    CalcSetup,
    NMOVES,
    CalcMoves
};
