/*
 * $Id: spiderette.c,v 1.5 1998/08/07 17:12:38 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"
#include "spider.h"

#define SpideretteDeck	0
#define SpiderettePile	(SpideretteDeck + 1)
#define SpideretteNpile	4
#define SpideretteLpile	(SpiderettePile + SpideretteNpile - 1)
#define SpideretteTable	(SpideretteLpile + 1)
#define SpideretteNtable	7
#define SpideretteLtable	(SpideretteTable + SpideretteNtable - 1)
#define SpideretteNstack	(SpideretteLtable + 1)

CardSetupType	SpideretteSetup[] =  {
    { { 6, 0 }, { 6, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },
    
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 1, 0 }, { 1, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 2, 0 }, { 2, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 3, 0 }, { 3, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    
    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayPack, False, False, 1, CardStartLastUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayPack, False, False, 2, CardStartLastUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayPack, False, False, 3, CardStartLastUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayPack, False, False, 4, CardStartLastUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayPack, False, False, 6, CardStartLastUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayPack, False, False, 7, CardStartLastUp },
};

static void
SpideretteMoveDeal (CardStackIndex  src,
		    CardStackIndex  dst,
		    CardIndex	    last)
{
    CardStackIndex  t;

    for (t = SpideretteTable; t <= SpideretteLtable; t++)
    {
	if (CardStackPtr (SpideretteDeck)->last == NullIndex)
	    return;
	CardMove (SpideretteDeck, CardStackPtr (SpideretteDeck)->last,
		  t, True);
	CardTurn (t, CardStackPtr (t)->last, True, True);
    }
}

CardMoveType SpideretteMoves[] = {
    /* 0    Move card from table to table same suit */
    {	"table to table in suit",
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckSuitTable,
	0,
    },
    /* 1    Move card from table to table */
    {	"table to table",
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckTable,
	0,
    },
    /* 2    Move card from table to empty */
    {	"table to empty",
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckEmpty,
	0,
    },
    /* 3    Move card from table to pile */
    {	"table to pile",
	{ SpideretteTable, SpideretteLtable },
	{ SpideretteTable, SpideretteLtable },
	{ SpiderettePile, SpideretteLpile },
	CardMoveAuto,
	SpiderSelectTable,
	SpiderCheckPile,
	0,
    },
    /* 4    deal */
    {	"deal",
	{ SpideretteDeck, SpideretteDeck },
	{ SpideretteDeck, SpideretteDeck },
	{ SpideretteTable, SpideretteLtable },
	CardMoveHelpful,
	0,
	0,
	SpideretteMoveDeal,
    },
};

#define NMOVES	(sizeof (SpideretteMoves) / sizeof (SpideretteMoves[0]))

static CardBool
SpideretteNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = SpideretteTable; stack <= SpideretteLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    for (stack = SpiderettePile; stack <= SpideretteLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
    }
    return True;
}

RulesType   spideretteGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, SpideretteNstack,
    SpideretteNormalize,
    0,
    CardIsInSuitOrder,
    SpideretteSetup,
    NMOVES,
    SpideretteMoves
};
