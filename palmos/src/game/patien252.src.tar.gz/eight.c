/*
 * $Id: eight.c,v 1.5 1998/08/08 06:17:38 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define EightDeck	0
#define EightTemp	1
#define EightNtemp	8
#define EightLtemp	(EightTemp + EightNtemp - 1)
#define EightPile	(EightLtemp + 1)
#define EightNpile	4
#define EightLpile	(EightPile + EightNpile - 1)
#define EightTable	(EightLpile + 1)
#define EightNtable	8
#define EightLtable	(EightTable + EightNtable - 1)
#define EightNstack	(EightLtable + 1)

CardSetupType	EightSetup[] =  {
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayNone, False, False, 0, CardStartDown },

    { { 0, 1 }, { 0, 1 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 2, 1 }, { 2, 1 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 3, 1 }, { 3, 1 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 4, 1 }, { 4, 1 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 5, 1 }, { 5, 1 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 6, 1 }, { 6, 1 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 7, 1 }, { 7, 1 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },

    { { 2, 0 }, { 2, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 3, 0 }, { 3, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 4, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 0 }, { 5, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 2 }, { 0, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 1, 2 }, { 1, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 2, 2 }, { 2, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 3, 2 }, { 3, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 4, 2 }, { 4, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 5, 2 }, { 5, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 6, 2 }, { 6, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
    { { 7, 2 }, { 7, 2 }, CardNone, CardDisplayPack, False, True, 6, CardStartUp },
};

static int
EightCountTemp (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    int		    nempty = 0;

    for (stack = EightTemp; stack <= EightLtemp; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    nempty++;
    }
    return nempty;
}

static CardBool
EightSelectTable (CardStackIndex   stack,
		   CardIndex	    *first,
		   CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    CardType	    *cp;
    int		    nempty = EightCountTemp ();
    int		    nstack = 0;

    card = sp->last;
    *first = card;
    while (card != NullIndex)
    {
	nstack++;
	if (nstack > nempty)
	    break;
	cp = CardPtr (card);
	if (cp->prev == NullIndex)
	    break;
	if (!CardIsInSuitOrder (card, cp->prev))
	    break;
	card = cp->prev;
    }
    *last = card;
    return True;
}

static CardProgressType
EightCheckTable (CardStackIndex	src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (CardIsInSuitOrder (card, dp->last))
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
EightCheckEmptyTable (CardStackIndex	src,
		      CardStackIndex	dst,
		      CardIndex		card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
EightCheckPile (CardStackIndex	src, 
		CardStackIndex	dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == 1)
	    return CardProgressSome;
    }
    else
    {
	if (CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
EightCheckTemp (CardStackIndex	src, 
		CardStackIndex	dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressNone;
    return CardProgressCant;
}

CardMoveType EightMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	{ EightPile, EightLpile },
	CardMoveAuto,
	0,
	EightCheckPile,
	0,
    },
    /* 1    Move card from temp to pile */
    {	"temp to pile",
	{ EightTemp, EightLtemp },
	{ EightTemp, EightLtemp },
	{ EightPile, EightLpile },
	CardMoveAuto,
	0,
	EightCheckPile,
	0,
    },
    /* 2    Move card from table to table */
    {	"table to table",
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	CardMoveHelpful,
	EightSelectTable,
	EightCheckTable,
	0,
    },
    /* 3    Move card from table to empty table */
    {	"table to empty table",
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	CardMoveHelpful,
	EightSelectTable,
	EightCheckEmptyTable,
	0,
    },
    /* 4    Move card from temp to table */
    {	"temp to table",
	{ EightTemp, EightLtemp },
	{ EightTemp, EightLtemp },
	{ EightTable, EightLtable },
	CardMoveHelpful,
	0,
	EightCheckTable,
	0,
    },
    /* 5    Move card from temp to table */
    {	"temp to empty table",
	{ EightTemp, EightLtemp },
	{ EightTemp, EightLtemp },
	{ EightTable, EightLtable },
	CardMoveHelpful,
	0,
	EightCheckEmptyTable,
	0,
    },
    /* 6    Move card from table to temp */
    {	"table to temp",
	{ EightTable, EightLtable },
	{ EightTable, EightLtable },
	{ EightTemp, EightLtemp },
	CardMoveHelpful,
	0,
	EightCheckTemp,
	0,
    },
    /* 7    Move card from pile to table */
    {	"pile to table",
	{ EightPile, EightLpile },
	{ EightPile, EightLpile },
	{ EightTable, EightLtable },
	CardMoveNoHelp,
	0,
	EightCheckTable,
	0,
    },
    /* 8    Move card from pile to empty table */
    {	"pile to empty table",
	{ EightPile, EightLpile },
	{ EightPile, EightLpile },
	{ EightTable, EightLtable },
	CardMoveNoHelp,
	0,
	EightCheckEmptyTable,
	0,
    },
};

#define NMOVES	(sizeof (EightMoves) / sizeof (EightMoves[0]))

static CardBool
EightNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = EightPile; stack <= EightLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != KING)
	    return False;
    }
    return True;
}

RulesType   eightGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, EightNstack,
    EightNormalize,
    0,
    CardIsInSuitOrder,
    EightSetup,
    NMOVES,
    EightMoves
};
