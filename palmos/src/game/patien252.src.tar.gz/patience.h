/*
 * $Id: patience.h,v 1.10 1999/10/24 21:15:12 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

extern PatS    cardWidth;
extern PatS    cardHeight;
extern PatS    cardSpace;
extern PatS    cardLabel;
extern PatS    cardRadius;
extern PatS    cardOriginX;
extern PatS    cardOriginY;
extern PatS    cardLabelWidth;
extern PatS    cardLabelHeight;
extern PatS    xOffset;
extern PatS    yOffset;

extern CustomPatternType    backPattern;
extern CustomPatternType    emptyPattern;
extern CustomPatternType    tablePattern;
extern CustomPatternType    myBlackPattern;

#define CARD_RADIUS 1
#define CARD_WIDTH  22
#define CARD_HEIGHT 30
#define CARD_XOFFSET	10
#define CARD_YOFFSET	13
#define CARD_BOFFSET	3
#define CARD_POFFSET	2
#define CARD_LABEL	1

#define CARD_MAX    160

extern CardStackIndex	hint_src;

extern void Help (Int id);

extern void Rules (Int id);

extern void DebugS (CharPtr);
extern void DebugSI (CharPtr, PatI);

extern void PlayRandomSong (Int win);

/* Increment this every time the GameType structure changes */
#define PatienceVersionNum	6
#define PatienceFileCreator	'Pati'
#define PatienceDBCreator	PatienceFileCreator
#define PatienceDBType		'undo'
