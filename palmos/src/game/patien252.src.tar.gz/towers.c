/*
 * $Id: towers.c,v 1.5 1998/08/08 06:17:38 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define TowersDeck	0
#define TowersTemp	1
#define TowersNtemp	4
#define TowersLtemp	(TowersTemp + TowersNtemp - 1)
#define TowersPile	(TowersLtemp + 1)
#define TowersNpile	4
#define TowersLpile	(TowersPile + TowersNpile - 1)
#define TowersTable	(TowersLpile + 1)
#define TowersNtable	10
#define TowersLtable	(TowersTable + TowersNtable - 1)
#define TowersNstack	(TowersLtable + 1)

CardSetupType	TowersSetup[] =  {
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayNone, False, False, 0, CardStartDown },

    { { 3, 0 }, { 3, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 4, 0 }, { 4, 0 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 5, 0 }, { 5, 0 }, CardBlank, CardDisplayTop, False, False, 1, CardStartUp },
    { { 6, 0 }, { 6, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },

    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 1, 0 }, { 1, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 8, 0 }, { 8, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 9, 0 }, { 9, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 7, 1 }, { 7, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 8, 1 }, { 8, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
    { { 9, 1 }, { 9, 1 }, CardNone, CardDisplayPack, False, True, 5, CardStartUp },
};

static int
TowersCountTemp (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    int		    nempty = 0;

    for (stack = TowersTemp; stack <= TowersLtemp; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    nempty++;
    }
    return nempty;
}

static CardBool
TowersSelectTable (CardStackIndex   stack,
		   CardIndex	    *first,
		   CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    CardType	    *cp;
    int		    nempty = TowersCountTemp ();
    int		    nstack = 0;

    card = sp->last;
    *first = card;
    while (card != NullIndex)
    {
	nstack++;
	if (nstack > nempty)
	    break;
	cp = CardPtr (card);
	if (cp->prev == NullIndex)
	    break;
	if (!CardIsInSuitOrder (card, cp->prev))
	    break;
	card = cp->prev;
    }
    *last = card;
    return True;
}

static CardProgressType
TowersCheckTable (CardStackIndex    src, 
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (CardIsInSuitOrder (card, dp->last))
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
TowersCheckEmptyTable (CardStackIndex	src,
		       CardStackIndex	dst,
		       CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex && Rank (CardPtr (card)->card) == KING)
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
TowersCheckPile (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == 1)
	    return CardProgressSome;
    }
    else
    {
	if (CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
TowersCheckTemp (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressNone;
    return CardProgressCant;
}

CardMoveType TowersMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	{ TowersPile, TowersLpile },
	CardMoveAuto,
	0,
	TowersCheckPile,
	0,
    },
    /* 1    Move card from temp to pile */
    {	"temp to pile",
	{ TowersTemp, TowersLtemp },
	{ TowersTemp, TowersLtemp },
	{ TowersPile, TowersLpile },
	CardMoveAuto,
	0,
	TowersCheckPile,
	0,
    },
    /* 2    Move card from table to table */
    {	"table to table",
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	CardMoveHelpful,
	TowersSelectTable,
	TowersCheckTable,
	0,
    },
    /* 3    Move card from table to empty table */
    {	"table to empty table",
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	CardMoveHelpful,
	TowersSelectTable,
	TowersCheckEmptyTable,
	0,
    },
    /* 4    Move card from temp to table */
    {	"temp to table",
	{ TowersTemp, TowersLtemp },
	{ TowersTemp, TowersLtemp },
	{ TowersTable, TowersLtable },
	CardMoveHelpful,
	0,
	TowersCheckTable,
	0,
    },
    /* 5    Move card from temp to table */
    {	"temp to empty table",
	{ TowersTemp, TowersLtemp },
	{ TowersTemp, TowersLtemp },
	{ TowersTable, TowersLtable },
	CardMoveHelpful,
	0,
	TowersCheckEmptyTable,
	0,
    },
    /* 6    Move card from table to temp */
    {	"table to temp",
	{ TowersTable, TowersLtable },
	{ TowersTable, TowersLtable },
	{ TowersTemp, TowersLtemp },
	CardMoveHelpful,
	0,
	TowersCheckTemp,
	0,
    },
    /* 7    Move card from pile to table */
    {	"pile to table",
	{ TowersPile, TowersLpile },
	{ TowersPile, TowersLpile },
	{ TowersTable, TowersLtable },
	CardMoveNoHelp,
	0,
	TowersCheckTable,
	0,
    },
    /* 8    Move card from pile to empty table */
    {	"pile to empty table",
	{ TowersPile, TowersLpile },
	{ TowersPile, TowersLpile },
	{ TowersTable, TowersLtable },
	CardMoveNoHelp,
	0,
	TowersCheckEmptyTable,
	0,
    },
};

#define NMOVES	(sizeof (TowersMoves) / sizeof (TowersMoves[0]))

static CardBool
TowersNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = TowersPile; stack <= TowersLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != KING)
	    return False;
    }
    return True;
}

RulesType   towersGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, TowersNstack,
    TowersNormalize,
    0,
    CardIsInSuitOrder,
    TowersSetup,
    NMOVES,
    TowersMoves
};
