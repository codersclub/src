/*
 * $Id: montana.c,v 1.5 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define MontanaDeck	0
#define MontanaTable	(MontanaDeck + 1)
#define MontanaNtable	52
#define MontanaLtable	(MontanaTable + MontanaNtable - 1)
#define MontanaNstack	(MontanaLtable + 1)

CardSetupType	MontanaSetup[] =  {
    { { 0, 4 }, { 0, 4 }, CardEmpty, CardDisplayTop, True, False, 0, CardStartDown },

    { { 0, 0 }, { 0, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 1, 0 }, { 1, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 2, 0 }, { 2, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 3, 0 }, { 3, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 4, 0 }, { 4, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 5, 0 }, { 5, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 6, 0 }, { 6, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 7, 0 }, { 7, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 8, 0 }, { 8, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 9, 0 }, { 9, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {10, 0 }, {10, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {11, 0 }, {11, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {12, 0 }, {12, 0 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    
    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 7, 1 }, { 7, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 8, 1 }, { 8, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 9, 1 }, { 9, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {10, 1 }, {10, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {11, 1 }, {11, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {12, 1 }, {12, 1 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    
    { { 0, 2 }, { 0, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 1, 2 }, { 1, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 2, 2 }, { 2, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 3, 2 }, { 3, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 4, 2 }, { 4, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 5, 2 }, { 5, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 6, 2 }, { 6, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 7, 2 }, { 7, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 8, 2 }, { 8, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 9, 2 }, { 9, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {10, 2 }, {10, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {11, 2 }, {11, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {12, 2 }, {12, 2 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    
    { { 0, 3 }, { 0, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 1, 3 }, { 1, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 2, 3 }, { 2, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 3, 3 }, { 3, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 4, 3 }, { 4, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 5, 3 }, { 5, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 6, 3 }, { 6, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 7, 3 }, { 7, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 8, 3 }, { 8, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { { 9, 3 }, { 9, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {10, 3 }, {10, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {11, 3 }, {11, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
    { {12, 3 }, {12, 3 }, CardNone, CardDisplayTop, True, False, 1, CardStartUp },
};

PatI MontanaDeal	= 0;

static void
MontanaCleanAces (CardBool remember)
{
    CardStackIndex  stack;
    CardIndex	    card;
    CardStackType   *sp;

    for (stack = MontanaTable; stack <= MontanaLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (Rank (CardPtr (card)->card) == 1)
	{
	    CardTurn (stack, card, False, remember);
	    CardMove (stack, card, MontanaDeck, remember);
	}
    }
}

static void
MontanaInitialize (void)
{
    MontanaCleanAces (False);
    MontanaDeal = 0;
}

static CardProgressType
MontanaCheckTable (CardStackIndex   src, 
		   CardStackIndex   dst,
		   CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last != NullIndex)
	return CardProgressCant;
    if ((dst - MontanaTable) % 13 == 0)
    {
	if (Rank (CardPtr (card)->card) == 2)
	{
	    if ((src - MontanaTable) % 13 == 0)
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    else
    {
	dp = CardStackPtr (dst - 1);
	if (dp->last != NullIndex &&
	    CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
MontanaCheckDeal (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    card)
{
#if 0
    if (MontanaDeal >= 3)
	return CardProgressCant;
#endif
    return CardProgressSome;
}

static void
MontanaMoveDeal (CardStackIndex	src,
		 CardStackIndex dst,
		 CardIndex	last)
{
    CardStackIndex  row, stack;
    CardIndex	    card, prev;

    for (row = MontanaTable; row <= MontanaLtable; row += 13)
    {
	stack = row;
	card = CardStackPtr (row)->last;
	if (card != NullIndex && Rank (CardPtr (card)->card) == 2)
	{
	    for (stack++; stack < row + 13; stack++)
	    {
		prev = card;
		card = CardStackPtr (stack)->last;
		if (card == NullIndex || !CardIsInSuitOrder (prev, card))
		    break;
	    }
	}
	for (; stack < row + 13; stack++)
	{
	    card = CardStackPtr (stack)->last;
	    if (card != NullIndex)
		CardMove (stack, card, MontanaDeck, True);
	}
    }
    CardShuffle (MontanaDeck, True);
    for (stack = MontanaTable; stack <= MontanaLtable; stack++)
    {
	if (CardStackPtr (stack)->last == NullIndex)
	{
	    CardMove (MontanaDeck, 
		      CardStackPtr (MontanaDeck)->last,
		      stack, True);
	}
    }
    MontanaCleanAces (True);
}

static CardProgressType
MontanaCheckHint (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackType   *dp;

    if (CardStackPtr (src)->last == NullIndex)
    {
	CardStackIndex	t;

	card = CardStackPtr (dst)->last;
	if (card == NullIndex)
	    return CardProgressCant;
	t = src;
	src = dst;
	dst = t;
    }
    dp = CardStackPtr (dst);
    if ((dst - MontanaTable) % 13 == 0)
    {
	if (Rank (CardPtr (card)->card) == 2)
	{
	    if ((src - MontanaTable) % 13 == 0)
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    else
    {
	dp = CardStackPtr (dst - 1);
	if (dp->last != NullIndex &&
	    CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static void
MontanaMoveHint (CardStackIndex	    src,
		 CardStackIndex	    dst,
		 CardIndex	    card)
{
    CardStackType   *sp;
    
    if ((src - MontanaTable) % 13 == 0 &&
	CardStackPtr (src)->last == NullIndex)
    {
	CardShowHint (src, 0);
	for (src = MontanaTable; src <= MontanaLtable; src++)
	    if ((src - MontanaTable) % 13 != 0)
	    {
		sp = CardStackPtr (src);
		if (sp->last != NullIndex &&
		    Rank (CardPtr (sp->last)->card) == 2)
		{
		    CardShowHint (src, 0);
		}
	    }
    }
    else
    {
	CardShowHint (dst, 0);
	CardShowHint (src, 0);
    }
}

CardMoveType MontanaMoves[] = {
    /* 0    Move card from table to table */
    {	"table to table",
	{ MontanaTable, MontanaLtable },
	{ MontanaTable, MontanaLtable },
	{ MontanaTable, MontanaLtable },
	CardMoveHelpful,
	0,
	MontanaCheckTable,
	0,
    },
    /* 1    Deal */
    {	"deal",
	{ MontanaDeck, MontanaDeck },
	{ MontanaDeck, MontanaDeck },
	{ MontanaDeck, MontanaDeck },
	CardMoveHelpful,
	0,
	MontanaCheckDeal,
	MontanaMoveDeal,
    },
    /* 2    Hint */
    {	"hint",
	{ MontanaTable, MontanaLtable },
	{ MontanaTable, MontanaLtable },
	{ MontanaTable, MontanaLtable },
	CardMoveHint,
	0,
	MontanaCheckHint,
	MontanaMoveHint,
    },
};

#define NMOVES	(sizeof (MontanaMoves) / sizeof (MontanaMoves[0]))

static CardBool
MontanaNormalize (void)
{
    CardStackIndex  stack;
    CardIndex	    card, prev;
    CardStackIndex  row;

    for (row = MontanaTable; row <= MontanaLtable; row += 13)
    {
	card = CardStackPtr (row)->last;
	if (card == NullIndex || Rank (CardPtr (card)->card) != 2)
	    return False;
	for (stack = row + 1; stack < row + 12; stack++)
	{
	    prev = card;
	    card = CardStackPtr (stack)->last;
	    if (card == NullIndex || !CardIsInSuitOrder (prev, card))
		return False;
	}
    }
    return True;
}

RulesType   montanaGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, MontanaNstack,
    MontanaNormalize,
    MontanaInitialize,
    0,
    MontanaSetup,
    NMOVES,
    MontanaMoves
};
