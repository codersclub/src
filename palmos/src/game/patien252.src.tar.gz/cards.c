/*
 * $Id: cards.c,v 1.9 1998/08/08 06:17:38 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

void
CardSetShoulds (CardStackIndex stack)
{
    CardStackType   *sp;
    CardIndex	    card, prev, next;
    CardType	    *cp;
    PatI	    face_up;
    PatI	    back_up;
    PatI	    pack_up;
    PatI	    up;

    sp = CardStackPtr (stack);
    face_up = 0;
    pack_up = 0;
    back_up = 0;
    up = 0;
    if (sp->first != NullIndex)
    {
	switch (sp->display) {
	case CardDisplayTop:
	case CardDisplayTopCount:
	    card = sp->last;
	    cp = CardPtr (card);
	    if (cp->face)
		cp->show = CardShowFace;
	    else
		cp->show = CardShowBack;
	    while ((card = cp->prev) != NullIndex)
	    {
		cp = CardPtr (card);
		cp->show = CardShowNone;
	    }
	    break;
	case CardDisplayBottom:
	    card = sp->first;
	    cp = CardPtr (card);
	    if (cp->face)
		cp->show = CardShowFace;
	    else
		cp->show = CardShowBack;
	    while ((card = cp->next) != NullIndex)
	    {
		cp = CardPtr (card);
		cp->show = CardShowNone;
	    }
	    break;
	case CardDisplayAll:
	    for (card = sp->last; card != NullIndex; card = cp->prev)
	    {
		cp = CardPtr (card);
		if (cp->face)
		    cp->show = CardShowFace;
		else
		    cp->show = CardShowBack;
		if (up)
		{
		    if (cp->face)
			face_up++;
		    else
			back_up++;
		}
		up++;
	    }
	    break;
	case CardDisplayNone:
	    for (card = sp->first; card != NullIndex; card = cp->next)
	    {
		cp = CardPtr (card);
		cp->show = CardShowNone;
	    }
	    break;
	case CardDisplaySome:
	    for (card = sp->last; card != NullIndex; card = cp->prev)
	    {
		cp = CardPtr (card);
		if (cp->show != CardShowNone)
		{
		    if (up)
		    {
			switch (cp->show) {
			case CardShowBack:
			    back_up++;
			    break;
			case CardShowPack:
			    pack_up++;
			    break;
			case CardShowFace:
			    face_up++;
			    break;
			}
		    }
		    up++;
		}
	    }
	    break;
	case CardDisplayPack:
	    for (card = sp->last; card != NullIndex; card = cp->prev)
	    {
		cp = CardPtr (card);
		if (cp->face)
		{
		    prev = cp->prev;
		    next = cp->next;
		    if ((*CurrentPackFunction ()) (next, card) &&
			(*CurrentPackFunction ()) (card, prev))
		    {
			cp->show = CardShowPack;
			if (up)
			    pack_up++;
		    }
		    else
		    {
			cp->show = CardShowFace;
			if (up)
			    face_up++;
		    }
		}
		else
		{
		    cp->show = CardShowBack;
		    if (up)
			back_up++;
		}
		up++;
	    }
	    break;
	}
    }
    sp->face_up = face_up;
    sp->back_up = back_up;
    sp->pack_up = pack_up;
}

void
CardMakeDeck (Card first, Card last, PatI ndecks)
{
    PatI	    n;
    Card	    r, s, c;
    CardType	    *cp = 0;
    CardIndex	    card;
    CardStackType   *sp;

    card = 0;
    for (n = 0; n < ndecks; n++)
    {
	for (s = Suit (first); s <= Suit (last); s = NextSuit (s))
	{
	    for (r = Rank (first); r <= Rank (last); r++)
	    {
		c = MakeCard (0, s, r);
		cp = CardPtr (card);
		if (card)
		    cp->prev = card - 1;
		else
		    cp->prev = NullIndex;
		cp->next = card + 1;
		cp->card = c;
		cp->face = 0;
		cp->show = CardShowNone;
		card++;
	    }
	}
    }
    sp = CardStackPtr (CardStackDeck);
    if (cp)
    {
	cp->next = NullIndex;
	sp->first = 0;
	sp->last = card - 1;
    }
    else
    {
	sp->first = NullIndex;
	sp->last = NullIndex;
    }
    sp->dirty = True;
}

void
CardInitStack (CardStackIndex stack,
	       PatS	x,
	       PatS	y,
	       Card	empty,
	       PatS	display,
	       CardBool	horizontal,
	       CardBool	select_card)
{
    CardStackType   *sp = CardStackPtr (stack);

    sp->pos.x = x;
    sp->pos.y = y;
    sp->first = NullIndex;
    sp->last = NullIndex;
    sp->empty = empty;
    sp->dirty = True;
    sp->face_up = 0;
    sp->back_up = 0;
    sp->pack_up = 0;
    sp->display = display;
    sp->horizontal = horizontal;
    sp->select_card = select_card;
}

CardBool
CardIsInOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    {
	CardType	*ap = CardPtr (a), *bp = CardPtr (b);
	
	return ap->face == bp->face &&
	       Rank (ap->card) + 1 == Rank (bp->card);
    }
}

CardBool
CardIsInSuitOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    {
	CardType	*ap = CardPtr (a), *bp = CardPtr (b);
	
	return ap->face == bp->face &&
	       Suit (ap->card) == Suit(bp->card) && 
	       CardIsInOrder (a, b);
    }
}

CardIndex
CardInSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->next != NullIndex && 
	   CardIsInSuitOrder (cp->next, card))
	card = cp->next;
    return card;
}

CardIndex
CardInOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->next != NullIndex && 
	   CardIsInOrder (cp->next, card))
	card = cp->next;
    return card;
}
    
CardIndex
CardInReverseSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->prev != NullIndex && 
	   CardIsInSuitOrder (card, cp->prev))
	card = cp->prev;
    return card;
}

CardIndex
CardInReverseOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->prev != NullIndex && 
	   CardIsInOrder (card, cp->prev))
	card = cp->prev;
    return card;
}

CardBool
IsAlternateSuit (Card a, Card b)
{
    return (Suit (a) == SPADE || Suit (a) == CLUB) ^ 
	   (Suit (b) == SPADE || Suit (b) == CLUB);
}

CardBool
CardIsInAlternatingSuitOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    return CardIsInOrder (a, b) && 
	       IsAlternateSuit (CardPtr (a)->card, 
				CardPtr (b)->card);
}

CardIndex
CardInAlternatingSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->next != NullIndex && 
	   CardIsInAlternatingSuitOrder (cp->next, card))
	card = cp->next;
    return card;
}

CardIndex
CardInReverseAlternatingSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->prev != NullIndex && 
	   CardIsInAlternatingSuitOrder (card, cp->prev))
	card = cp->prev;
    return card;
}

Boolean
ReleaseFirstUndoChunk (void)
{
    Err			err;
    UInt		at;
    VoidHand		undoHandle;
    HistoryChunkType	*undoChunk, chunk;
    PatL		serial;
    PatI		i, historyTop;

    err = DmFindRecordByID (undoDB, game.historyID[0], &at);
    if (err)
	return false;
    undoHandle = DmQueryRecord (undoDB, at);
    if (!undoHandle)
	return false;
    if (MemHandleSize (undoHandle) != sizeof (HistoryChunkType))
	return false;
    undoChunk = MemHandleLock (undoHandle);
    serial = undoChunk->history[undoChunk->historyTop-1].serial;
    MemHandleUnlock (undoHandle);
    for (;;)
    {
	DmRemoveRecord (undoDB, at);
	MemMove (&game.historyID[0],
		 &game.historyID[1],
		 sizeof (ULong) * (HISTORY_CHUNKS - 1));
	game.historyTop--;
	if (!game.historyTop)
	    return true;
	err = DmFindRecordByID (undoDB, game.historyID[0], &at);
	if (err)
	    return false;
	undoHandle = DmGetRecord (undoDB, at);
	if (!undoHandle)
	    return false;
	undoChunk = MemHandleLock (undoHandle);
	historyTop = undoChunk->historyTop;
	for (i = 0; i < historyTop; i++)
	{
	    if (undoChunk->history[i].serial != serial)
		break;
	}
	if (i != historyTop)
	    break;
	MemHandleUnlock (undoHandle);
	DmReleaseRecord (undoDB, at, false);
    }
    if (i != 0)
    {
	MemMove (&chunk.history[0], 
		 &undoChunk->history[i], 
		 (undoChunk->historyTop - i) * sizeof (CardHistoryType));
	chunk.historyTop = undoChunk->historyTop - i;
	DmWrite (undoChunk, 0, &chunk,
		 sizeof (HistoryChunkType));
    }
    MemHandleUnlock (undoHandle);
    DmReleaseRecord (undoDB, at, true);
    return true;
}

Boolean
PushUndoChunk (void)
{
    Err		err;
    VoidHand	undoHandle;
    VoidPtr	undoPtr;
    UInt	at;

    if (game.historyChunk.historyTop == 0)
	return true;
    if (!undoDB)
	return false;
    if (game.historyTop == HISTORY_CHUNKS)
    {
	if (!ReleaseFirstUndoChunk ())
	    return false;
    }
    
    at = DmNumRecords (undoDB);
    undoHandle = DmNewRecord (undoDB, &at, sizeof (HistoryChunkType));
    if (!undoHandle)
	return false;
    err = DmRecordInfo (undoDB,
			at,
			0,
			&game.historyID[game.historyTop],
			0);
    if (err)
    {
	DmReleaseRecord (undoDB, at, false);
	DmRemoveRecord (undoDB, at);
	return false;
    }
    
    game.historyTop++;
    undoPtr = MemHandleLock (undoHandle);
    err = DmWrite (undoPtr, 0, &game.historyChunk,
		   sizeof (HistoryChunkType));
    MemHandleUnlock (undoHandle);
    DmReleaseRecord (undoDB, at, true);

    game.historyChunk.historyTop = 0;


    return true;
}

Boolean
PopUndoChunk (void)
{
    Err			err;
    UInt		r;
    VoidHand		undoHandle;
    HistoryChunkType	*undoChunk;
    
    game.historyChunk.historyTop = 0;
    if (game.historyTop == 0)
	return false;
    if (!undoDB)
	return false;
    err = DmFindRecordByID (undoDB, game.historyID[game.historyTop-1], &r);
    if (err)
	return false;
    undoHandle = DmQueryRecord (undoDB, r);
    if (undoHandle == 0)
	return false;
    if (MemHandleSize (undoHandle) != sizeof (HistoryChunkType))
	return false;
    undoChunk = MemHandleLock (undoHandle);
    MemMove (&game.historyChunk, 
	     undoChunk,
	     sizeof (HistoryChunkType));
    MemHandleUnlock (undoHandle);
    DmRemoveRecord (undoDB, r);
    game.historyTop--;
    return true;
}

static CardHistoryType *
PushHistory (CardHistoryKind kind)
{
    CardHistoryType	*hp;
    
    if (game.historyChunk.historyTop == HISTORY_CHUNK)
    {
	if (!PushUndoChunk ())
	{
	    DeleteUndoDB ();
	    return 0;
	}
    }
    hp = &game.historyChunk.history[game.historyChunk.historyTop++];
    hp->serial = game.historySerial;
    hp->kind = kind;
    return hp;
}

static CardHistoryType *
TopHistory (void)
{
    while (game.historyChunk.historyTop == 0)
    {
	if (!PopUndoChunk ())
	    return 0;
    }
    return &game.historyChunk.history[game.historyChunk.historyTop-1];
}

static void
PopHistory (void)
{
    while (game.historyChunk.historyTop == 0)
    {
	if (!PopUndoChunk ())
	    return;
    }
    --game.historyChunk.historyTop;
}

void
CardShuffle (CardStackIndex stack, CardBool remember)
{
    CardIndex	    deck[MAX_CARDS];
    PatI	    n;
    PatI	    i, j;
    CardStackType   *sp;
    Card	    card;
    CardType	    *cp;

    if (remember)
    {
	CardHistoryType	*hp = PushHistory (CardHistoryShuffle);

	hp->u.shuffle.stack = stack;
	hp->u.shuffle.seed = game.randomSeed;
    }
    sp = CardStackPtr (stack);
    for (n = 0, card = sp->first; card != NullIndex; n++, card = cp->next)
    {
	cp = CardPtr (card);
	deck[n] = card;
    }
    for (i = 0; i < n; i++)
    {
	j = Random (n - i) + i;
	card = deck[i];
	deck[i] = deck[j];
	deck[j] = card;
    }
    sp->first = deck[0];
    for (i = 0; i < n; i++)
    {
	cp = CardPtr (deck[i]);
	if (i)
	    cp->prev = deck[i-1];
	else
	    cp->prev = NullIndex;
	if (i != n-1)
	    cp->next = deck[i+1];
	else
	    cp->next = NullIndex;
    }
    sp->last = deck[n-1];
    sp->dirty = True;
}

static void
CardUnshuffle (CardStackIndex stack, PatL seed)
{
    CardIndex	    deck[MAX_CARDS];
    PatL    	    r[MAX_CARDS];
    PatI    	    n;
    PatI	    i, j;
    CardStackType   *sp;
    Card	    card;
    CardType	    *cp;

    sp = CardStackPtr (stack);
    for (n = 0, card = sp->first; card != NullIndex; n++, card = cp->next)
    {
	cp = CardPtr (card);
	deck[n] = card;
    }
    /*
     * Regenerate the sequence of random numbers used to shuffle the
     * deck
     */
    SRandom (seed);
    for (i = 0; i < n; i++)
    {
	r[i] = Random (n - i) + i;
    }
    /*
     * Reorder the deck
     */
    for (i = n - 1; i >= 0; i--)
    {
	j = r[i];
	card = deck[j];
	deck[j] = deck[i];
	deck[i] = card;
    }
    sp->first = deck[0];
    for (i = 0; i < n; i++)
    {
	cp = CardPtr (deck[i]);
	if (i)
	    cp->prev = deck[i-1];
	else
	    cp->prev = NullIndex;
	if (i != n-1)
	    cp->next = deck[i+1];
	else
	    cp->next = NullIndex;
    }
    sp->last = deck[n-1];
    sp->dirty = True;
}

void
CardTurn (CardStackIndex stack, CardIndex card, CardBool face, CardBool remember)
{
    CardType	*cp;

    cp = CardPtr (card);
    if (remember)
    {
	CardHistoryType	*hp = PushHistory (CardHistoryTurn);
	hp->u.turn.stack = stack;
	hp->u.turn.card = card;
	hp->u.turn.face = cp->face;
    }
    cp->face = face;
    CardStackPtr (stack)->dirty = True;
}

static void
RemoveStack (CardStackIndex stack, 
	     CardIndex first, CardIndex last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardType	    *fp = CardPtr (first), *lp = CardPtr (last);
    
    if (fp->prev != NullIndex)
	CardPtr (fp->prev)->next = lp->next;
    else
	sp->first = lp->next;
    if (lp->next != NullIndex)
	CardPtr (lp->next)->prev = fp->prev;
    else
	sp->last = fp->prev;
    sp->dirty = True;
    fp->prev = NullIndex;
    lp->next = NullIndex;
}

static void
AddStack (CardStackIndex stack, 
	  CardIndex first, CardIndex last, CardIndex before)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardType	    *fp = CardPtr (first), *lp = CardPtr (last);
    CardType	    *bp;
    
    fp->prev = before;
    if (before != NullIndex)
    {
	bp = CardPtr (before);
	lp->next = bp->next;
	bp->next = first;
    }
    else
    {
	lp->next = sp->first;
	sp->first = first;
    }
    if (lp->next != NullIndex)
	CardPtr (lp->next)->prev = last;
    else
	sp->last = last;
    sp->dirty = True;
}

#ifndef NDEBUG
void CardVerifyStack (CardStackIndex);
void CardVerifyStacks (void);

void
CardVerifyStack (CardStackIndex stack)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card, prev;
    CardType	    *cp;

    if (sp->first == NullIndex)
    {
	ErrFatalDisplayIf (sp->last != NullIndex, "Card Verify Stack 1");
    }
    else
    {
	prev = NullIndex;
	for (card = sp->first; card != NullIndex; card = cp->next)
	{
	    cp = CardPtr (card);
	    ErrFatalDisplayIf (cp->prev != prev, "Card Verify Stack 2");
	    if (cp->next == NullIndex)
	    {
		ErrFatalDisplayIf (sp->last != card, "Card Verify Stack 2");
	    }
	    prev = card;
	}
    }
}

void
CardVerifyStacks (void)
{
    CardStackIndex  stack;

    for (stack = 0; stack < game.nstacks; stack++)
	CardVerifyStack (stack);
}
#endif

void
CardMoveCard (CardStackIndex	from_stack, 
	      CardIndex		first_card, 
	      CardIndex		last_card, 
	      CardStackIndex	to_stack, 
	      CardIndex		to_card,
	      CardBool		remember)
{
    ErrFatalDisplayIf (from_stack == NullIndex, "Null from stack");
    ErrFatalDisplayIf (to_stack == NullIndex, "Null to stack");
    ErrFatalDisplayIf (first_card == NullIndex, "Null first card");
    ErrFatalDisplayIf (last_card == NullIndex, "Null last card");
    
#ifndef NDEBUG
    CardVerifyStacks ();
#endif
    if (remember)
    {
	CardHistoryType	*hp = PushHistory (CardHistoryMove);

	hp->u.move.source = from_stack;
	hp->u.move.dest = to_stack;
	hp->u.move.before = CardPtr (first_card)->prev;
	hp->u.move.first = first_card;
	hp->u.move.last = last_card;
    }
    RemoveStack (from_stack, first_card, last_card);
    AddStack (to_stack, first_card, last_card, to_card);
#ifndef NDEBUG
    CardVerifyStacks ();
#endif
}

void 
CardMove (CardStackIndex    from_stack,
	  CardIndex	    from_card, 
	  CardStackIndex    to_stack, 
	  CardBool	    remember)
{
    CardMoveCard (from_stack, from_card, 
		   CardStackPtr (from_stack)->last, 
		   to_stack, 
		   CardStackPtr (to_stack)->last, remember);
}

void
CardInitHistory (void)
{
    if (undoDB)
    {
	int num;

	num = (int) DmNumRecords (undoDB);
	while (--num >= 0)
	    if (DmQueryRecord (undoDB, (UInt) num))
		DmRemoveRecord (undoDB, (UInt) num);
    }
    game.historyTop = 0;
    game.historyChunk.historyTop = 0;
    game.historySerial = 0;
}

#if 0
void
CardRecordHistoryCallback (void		(*func) (PatL closure),
			   PatL		closure)
{
    CardHistoryType	*hp = PushHistory (CardHistoryCallback);
    
    hp->u.callback.func = func;
    hp->u.callback.closure = closure;
}
#endif

CardBool
CardUndo (void)
{
    CardHistoryType	*hp;
    PatL    		serial;

    hp = TopHistory ();
    if (!hp)
	return False;
    serial = hp->serial; 
    while ((hp = TopHistory ()) && hp->serial == serial)
    {
	switch (hp->kind)
	{
	case CardHistoryMove:
	    CardMoveCard (hp->u.move.dest, hp->u.move.first, hp->u.move.last,
			   hp->u.move.source, hp->u.move.before, False);
	    break;
	case CardHistoryTurn:
	    CardTurn (hp->u.turn.stack, hp->u.turn.card, 
		      hp->u.turn.face, False);
	    break;
	case CardHistoryShuffle:
	    CardUnshuffle (hp->u.shuffle.stack, hp->u.shuffle.seed);
	    break;
#if 0
	case CardHistoryCallback:
	    (*hp->u.callback.func) (hp->u.callback.closure);
	    break;
#endif
	}
	PopHistory ();
    }
    CardRedisplay ();
    return True;
}

PatL
CardNextHistory (void)
{
    return game.historySerial++;
}

void
CardInit (RulesType *rule)
{
    CardStackIndex  stack;
    CardSetupType   *setup;
    PatI    	    n;
    PatS	    x, y;

    SRandom (game.gameSeed);
    game.nhint = 0;
    game.nstacks = rule->nstacks;
    CardInitHistory ();
    setup = rule->setup;
    for (stack = 0; stack < rule->nstacks; stack++)
    {
	if (game.leftHanded)
	{
	    x = setup->left.x;
	    y = setup->left.y;
	}
	else
	{
	    x = setup->right.x;
	    y = setup->right.y;
	}
	CardInitStack (stack,
		       x, y, setup->empty,
		       setup->display, setup->horizontal,
		       setup->select_card);
	setup++;
    }
    CardMakeDeck (rule->first, rule->last, rule->ndecks);
    CardShuffle (CardStackDeck, False);
    setup = rule->setup;
    for (stack = 0; stack < rule->nstacks; stack++)
    {
	for (n = 0; n < setup->ndeal; n++)
	{
	    CardMove (CardStackDeck,
		      CardStackPtr (CardStackDeck)->last,
		      stack, False);
	    switch (setup->start) {
	    case CardStartDown:
		break;
	    case CardStartLastUp:
		if (n != setup->ndeal - 1)
		    break;
	    case CardStartUp:
		CardTurn (stack,
			  CardStackPtr (stack)->last, 
			  True, False);
		break;
	    }
	}
	setup++;
    }
    if (rule->Initialize)
	(*rule->Initialize) ();
    if (game.alwaysAuto)
    	CardAutoPlay (rule);
}

void
CardSetHanded (RulesType    *rule,
	       CardBool	    leftHanded)
{
    CardStackIndex  stack;
    CardSetupType   *setup;
    
    if (leftHanded == game.leftHanded)
	return;
    game.leftHanded = leftHanded;
    if (game.playing)
    {
	setup = rule->setup;
	for (stack = 0; stack < rule->nstacks; stack++)
	{
	    CardStackType   *sp;
	    
	    sp = CardStackPtr (stack);
	    
	    if (game.leftHanded)
	    {
		sp->pos.x = setup->left.x;
		sp->pos.y = setup->left.y;
	    }
	    else
	    {
		sp->pos.x = setup->right.x;
		sp->pos.y = setup->right.y;
	    }
	    sp->dirty = True;
	    setup++;
	}
    }
}

void
CardHint (RulesType	    *rules)
{
    PatI	    m;
    CardMoveType    *move;
    CardIndex	    first, last;
    CardIndex	    acard;
    CardStackIndex  asrc, adst, adst_t;
    CardStackType   *sp;
    CardProgressType	best, progress;

    for (m = 0; m < rules->nmoves; m++)
    {
	move = &rules->moves[m];
	if (move->kind == CardMoveNoHelp || move->kind == CardMoveHint)
	    continue;
	for (asrc = move->source.first; asrc <= move->source.last; asrc++)
	{
	    sp = CardStackPtr (asrc);
	    if (sp->last == NullIndex)
		continue;
	    if (!move->SelectStack)
	    {
		first = last = sp->last;
	    }
	    else
	    {
		if (!(*move->SelectStack) (asrc, &first, &last))
		    continue;
		if (!sp->select_card)
		    first = last;
	    }
	    for (acard = first; 
		 acard != NullIndex;
		 acard = ((acard == last) ? NullIndex : 
			  CardPtr (acard)->prev))
	    {
		best = CardProgressCant;
		if (move->CheckStack)
		{
		    adst = NullIndex;
		    for (adst_t = move->dest.first; adst_t <= move->dest.last; adst_t++)
		    {
			progress = (*move->CheckStack) (asrc, 
							adst_t, acard);
			if (progress > best)
			{
			    adst = adst_t;
			    best = progress;
			}
		    }
		    if (best < CardProgressSome)
			continue;
		}
		else
		    adst = move->dest.first;
		CardShowMoveHint (asrc, adst, acard, NullIndex);
		return;
	    }
	}
    }
}

static void
CardDoMove (RulesType	    *rules,
	    CardMoveType    *move,
	    CardStackIndex  asrc,
	    CardStackIndex  adst,
	    CardIndex	    acard)
{
    if (move->MoveStack)
	(*move->MoveStack) (asrc, adst, acard);
    else
	CardMove (asrc, acard, adst, True);
    if (rules->Normalize)
    {
	if ((*rules->Normalize) ())
	    game.playing = False;
    }
    CardNextHistory ();
}

void
CardPlay (RulesType	    *rules,
	  CardStackIndex    src,
	  CardStackIndex    dst,
	  CardIndex	    card)
{
    PatI    	    m;
    CardMoveType    *move;
    CardIndex	    first, last, c;
    CardIndex	    acard;
    CardType	    *cp;
    CardStackIndex  asrc, adst, adst_t;
    CardStackType   *sp;
    CardProgressType	progress, best;

    for (m = 0; m < rules->nmoves; m++)
    {
	move = &rules->moves[m];
//	printf ("check move %s %d %d\n", move->name,
//		move->hit.first, move->hit.last);
	if (src < move->hit.first || move->hit.last < src)
	{
//	    printf ("no hit\n");
	    continue;
	}
	asrc = src - move->hit.first + move->source.first;
	sp = CardStackPtr (asrc);
	if (sp->last == NullIndex && move->kind != CardMoveHint)
	{
//	    printf ("empty source\n");
	    continue;
	}
	if (!move->SelectStack)
	{
	    first = last = sp->last;
	}
	else
	{
	    if (!(*move->SelectStack) (asrc, &first, &last))
	    {
//		printf ("select stack failed\n");
		continue;
	    }
	}
	acard = card;
	/*
	 * Use the top card in the stack if none indicated or
	 * if the source and dest ard the same and the stack 
	 * doesn't specify selection by card
	 */
	if (card == NullIndex || (!sp->select_card && src == dst))
	    acard = last;
	if (move->kind == CardMoveHint)
	{
	    best = CardProgressCant;
	    adst = NullIndex;
    	    for (adst_t = move->dest.first; adst_t <= move->dest.last; adst_t++)
    	    {
		progress = (*move->CheckStack) (asrc, adst_t, acard);
    		if (progress > best)
		{
		    adst = adst_t;
		    best = progress;
		}
	    }
	    if (adst == NullIndex)
		continue;
	    (*move->MoveStack) (asrc, adst, acard);
	}
	else
	{
	    if (src == dst)
	    {
		if (move->CheckStack)
		{
		    best = CardProgressCant;
		    adst = NullIndex;
		    for (adst_t = move->dest.first; 
			 adst_t <= move->dest.last; 
			 adst_t++)
		    {
			progress = (*move->CheckStack) (asrc, 
							adst_t, acard);
			if (progress > best)
			{
			    adst = adst_t;
			    best = progress;
			}
		    }
		    if (adst == NullIndex)
		    {
//			printf ("check stack failed\n");
			continue;
		    }
		}
		else
		    adst = move->dest.first;
	    }
	    else
	    {
		adst = dst;
		if (adst < move->dest.first || move->dest.last < adst)
		    continue;
	    }
	    if (card != NullIndex)
	    {
		for (c = first; c != last; c = cp->prev)
		{
		    if (c == acard)
			break;
		    cp = CardPtr (c);
		}
		if (c != acard)
		{
		    continue;
		}
		if (move->CheckStack &&
		    (*move->CheckStack) (asrc, adst, acard) == CardProgressCant)
		{
		    continue;
		}
	    }
	    CardDoMove (rules, move, asrc, adst, acard);
	    if (game.alwaysAuto)
		CardAutoPlay (rules);
	    CardRedisplay ();
	    break;
	}
    }
}

void
CardAutoPlay (RulesType	    *rules)
{
    PatI    	    m;
    CardMoveType    *move = 0;
    CardIndex	    first, last;
    CardIndex	    acard = 0;
    CardStackIndex  asrc = 0, adst = 0;
    CardStackType   *sp;

    for (;;)
    {
	for (m = 0; m < rules->nmoves; m++)
	{
	    move = &rules->moves[m];
	    if (move->kind != CardMoveAuto)
		continue;
	    for (asrc = move->source.first; asrc <= move->source.last; asrc++)
	    {
		sp = CardStackPtr (asrc);
		if (sp->last == NullIndex)
		    continue;
		if (!move->SelectStack)
		{
		    first = last = sp->last;
		}
		else
		{
		    if (!(*move->SelectStack) (asrc, &first, &last))
			continue;
		}
		acard = last;
		if (move->CheckStack)
		{
		    for (adst = move->dest.first; adst <= move->dest.last; adst++)
		    {
			if ((*move->CheckStack) (asrc, adst, acard) == CardProgressSome)
			    break;
		    }
		    if (adst > move->dest.last)
			continue;
		}
		else
		    adst = move->dest.first;
		break;
	    }
	    if (asrc <= move->source.last)
		break;
	}
	if (m == rules->nmoves)
	    break;
	CardDoMove (rules, move, asrc, adst, acard);
    }
}
	    
void
CardShowHint (CardStackIndex stack, PatI pos)
{
    CardHintType    *hp;

    hp = CardHintPtr (game.nhint);
    game.nhint++;
    if (game.nhint > MAX_HINT)
	return;
    hp->stack = stack;
    hp->pos = pos;
    CardDrawHighlight (stack, pos);
}

static PatI
_countOffset (CardStackIndex stack,
	      CardIndex card)
{
    CardStackType   *sp;
    PatI	    i;
    CardType	    *cp;

    sp = CardStackPtr (stack);
    i = -1;
    while (card != NullIndex)
    {
	cp = CardPtr (card);
	card = cp->prev;
	if (cp->show != CardShowNone)
	    i++;
    }
    if (i == -1)
	i = 0;
    return i;
}

void
CardShowMoveHint (CardStackIndex src, 
		  CardStackIndex dst,
		  CardIndex scard,
		  CardIndex dcard)
{
    if (dcard == NullIndex)
	dcard = CardStackPtr (dst)->last;
    CardShowHint (src, _countOffset (src, scard));
    CardShowHint (dst, _countOffset (dst, dcard));
}

void
CardUnshowHint (void)
{
    CardHintType    *hp;
    
    while (game.nhint)
    {
	--game.nhint;
	if (game.nhint < MAX_HINT)
	{
	    hp = CardHintPtr (game.nhint);
	    CardUndrawHighlight (hp->stack, hp->pos);
	}
    }
}
