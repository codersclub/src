/*
 * $Id: klondike.c,v 1.6 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#include "klondike.h"

CardSetupType	KlondikeSetup[] =  {
    { { 6, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },

    { { 5, 0 }, { 1, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 0 }, { 3, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 1, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 2, 0 }, { 5, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 3, 0 }, { 6, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayAll, False, False, 1, CardStartLastUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayAll, False, False, 2, CardStartLastUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayAll, False, False, 3, CardStartLastUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartLastUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, False, 5, CardStartLastUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayAll, False, False, 6, CardStartLastUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayAll, False, False, 7, CardStartLastUp },
};

CardBool
KlondikeSelectStack (CardStackIndex stack,
		     CardIndex	    *first,
		     CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);

    *first = sp->last;
    *last = CardInReverseAlternatingSuitOrder (sp->last);
    return True;
}

CardProgressType
KlondikeCheckTable (CardStackIndex  src, 
		    CardStackIndex  dst,
		    CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == KING)
	{
	    if (KlondikePile <= src && src <= KlondikeLpile)
		return CardProgressBack;
	    if (CardPtr (card)->prev == NullIndex)
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    else
    {
	if (CardIsInAlternatingSuitOrder (card, dp->last))
	{
	    if (KlondikePile <= src && src <= KlondikeLpile)
		return CardProgressBack;
	    if (CardIsInAlternatingSuitOrder (card,
					      CardPtr (card)->prev))
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    return CardProgressCant;
}

CardProgressType
KlondikeCheckPile (CardStackIndex src, 
		   CardStackIndex dst,
		   CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == 1)
	    return CardProgressSome;
    }
    else
    {
	if (CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

CardBool
KlondikeSelectDeck (CardStackIndex  stack,
		    CardIndex	    *first, 
		    CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    PatI    	    i;
    CardType	    *cp;

    card = sp->last;
    for (i = 0; i < 2; i++)
    {
	cp = CardPtr (card);
	if (cp->prev == NullIndex)
	    break;
	card = cp->prev;
    }
    *first = *last = card;
    return True;
}

void
KlondikeMoveDeal (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last)
{
    CardIndex	card, next;

    card = CardStackPtr (src)->last;
    for (;;)
    {
	next = CardPtr (card)->prev;
	CardMove (src, card, dst, True);
	CardTurn (dst, card, True, True);
	if (card == last)
	    break;
	card = next;
    }
}

void
KlondikeMoveReset(CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last)
{
    CardIndex	card, next;

    card = CardStackPtr (src)->last;
    for (;;)
    {
	next = CardPtr (card)->prev;
	CardMove (src, card, dst, True);
	CardTurn (dst, card, False, True);
	if (card == last)
	    break;
	card = next;
    }
}

CardBool
KlondikeSelectResetDeck (CardStackIndex stack,
			 CardIndex	*first,
			 CardIndex	*last)
{
    if (CardStackPtr (KlondikeDeck)->last != NullIndex)
	return False;
    *first = *last = CardStackPtr (stack)->first;
    return True;
}

CardMoveType KlondikeMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	{ KlondikePile, KlondikeLpile },
	CardMoveAuto,
	0,
	KlondikeCheckPile,
	0,
    },
    /* 1    Move card from discard to pile */
    {	"discard to pile",
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikePile, KlondikeLpile },
	CardMoveAuto,
	0,
	KlondikeCheckPile,
	0,
    },
    /* 2    Move card from table to table */
    {	"table to table",
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	CardMoveHelpful,
	KlondikeSelectStack,
	KlondikeCheckTable,
	0,
    },
    /* 3    Move card from discard to table */
    {	"discard to table",
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeTable, KlondikeLtable },
	CardMoveHelpful,
	0,
	KlondikeCheckTable,
	0,
    },
    /* 4    Deal next three cards */
    {	"deal",
	{ KlondikeDeck, KlondikeDeck },
	{ KlondikeDeck, KlondikeDeck },
	{ KlondikeDiscard, KlondikeDiscard },
	CardMoveHelpful,
	KlondikeSelectDeck,
	0,
	KlondikeMoveDeal,
    },
    /* 5    Reset deck */
    {	"reset",
	{ KlondikeDeck, KlondikeDeck },
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeDeck, KlondikeDeck },
	CardMoveHelpful,
	KlondikeSelectResetDeck,
	0,
	KlondikeMoveReset,
    },
    /* 6    Move card from pile to table */
    {	"pile to table",
	{ KlondikePile, KlondikeLpile },
	{ KlondikePile, KlondikeLpile },
	{ KlondikeTable, KlondikeLtable },
	CardMoveNoHelp,
	0,
	KlondikeCheckTable,
	0,
    },
};


#define NMOVES	(sizeof (KlondikeMoves) / sizeof (KlondikeMoves[0]))

CardBool
KlondikeNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = KlondikeTable; stack <= KlondikeLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    for (stack = KlondikePile; stack <= KlondikeLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != KING)
	    return False;
    }
    return True;
}

RulesType   klondikeGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, KlondikeNstack,
    KlondikeNormalize,
    0,
    0,
    KlondikeSetup,
    NMOVES,
    KlondikeMoves
};
