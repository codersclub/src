/*
 * $Id: song.c,v 1.2 1999/05/21 23:05:49 keithp Exp $
 *
 * Copyright � 1999 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "patience.h"

typedef struct _NoteType {
    unsigned char    note;
    unsigned char    duration;
} NoteType;

typedef struct _SongType {
    NoteType	    *notes;
    int		    nnotes;
    int		    tempo_num;
    int		    tempo_den;
} SongType;

#define ThirtysecondTriplet 2
#define Thirtysecond	    3
#define SixteenthTriplet    4
#define Sixteenth	    6
#define EighthTriplet	    8
#define Eighth		    12
#define QuarterTriplet	    16
#define Quarter		    24
#define Half		    48
#define Whole		    96

#define	A	0
#define Bb	1
#define B	2
#define C	3
#define Cs	4
#define D	5
#define Eb	6
#define E	7
#define F	8
#define Fs	9
#define G	10
#define Gs	11

#define O0	0x60
#define O1	0x50
#define O2	0x40
#define O3	0x30
#define O4	0x20
#define O5	0x10
#define O6	0x00

#define A0	(A + O0)
#define As0	(Bb + O0)
#define Bb0	(Bb + O0)
#define B0	(B + O0)
#define C0	(C + O0)
#define Cs0	(Cs + O0)
#define Db0	(Cs + O0)
#define D0	(D + O0)
#define Ds0	(Eb + O0)
#define Eb0	(Eb + O0)
#define E0	(E + O0)
#define F0	(F + O0)
#define Fs0	(Fs + O0)
#define Gb0	(Fs + O0)
#define G0	(G + O0)
#define Gs0	(Gs + O0)
#define Ab0	(Gs + O0)

#define A1	(A + O1)
#define As1	(Bb + O1)
#define Bb1	(Bb + O1)
#define B1	(B + O1)
#define C1	(C + O1)
#define Cs1	(Cs + O1)
#define Db1	(Cs + O1)
#define D1	(D + O1)
#define Ds1	(Eb + O1)
#define Eb1	(Eb + O1)
#define E1	(E + O1)
#define F1	(F + O1)
#define Fs1	(Fs + O1)
#define Gb1	(Fs + O1)
#define G1	(G + O1)
#define Gs1	(Gs + O1)
#define Ab1	(Gs + O1)

#define A2	(A + O2)
#define As2	(Bb + O2)
#define Bb2	(Bb + O2)
#define B2	(B + O2)
#define C2	(C + O2)
#define Cs2	(Cs + O2)
#define Db2	(Cs + O2)
#define D2	(D + O2)
#define Ds2	(Eb + O2)
#define Eb2	(Eb + O2)
#define E2	(E + O2)
#define F2	(F + O2)
#define Fs2	(Fs + O2)
#define Gb2	(Fs + O2)
#define G2	(G + O2)
#define Gs2	(Gs + O2)
#define Ab2	(Gs + O2)

#define A3	(A + O3)
#define As3	(Bb + O3)
#define Bb3	(Bb + O3)
#define B3	(B + O3)
#define C3	(C + O3)
#define Cs3	(Cs + O3)
#define Db3	(Cs + O3)
#define D3	(D + O3)
#define Ds3	(Eb + O3)
#define Eb3	(Eb + O3)
#define E3	(E + O3)
#define F3	(F + O3)
#define Fs3	(Fs + O3)
#define Gb3	(Fs + O3)
#define G3	(G + O3)
#define Gs3	(Gs + O3)
#define Ab3	(Gs + O3)

#define A4	(A + O4)
#define As4	(Bb + O4)
#define Bb4	(Bb + O4)
#define B4	(B + O4)
#define C4	(C + O4)
#define Cs4	(Cs + O4)
#define Db4	(Cs + O4)
#define D4	(D + O4)
#define Ds4	(Eb + O4)
#define Eb4	(Eb + O4)
#define E4	(E + O4)
#define F4	(F + O4)
#define Fs4	(Fs + O4)
#define Gb4	(Fs + O4)
#define G4	(G + O4)
#define Gs4	(Gs + O4)
#define Ab4	(Gs + O4)

#define A5	(A + O5)
#define As5	(Bb + O5)
#define Bb5	(Bb + O5)
#define B5	(B + O5)
#define C5	(C + O5)
#define Cs5	(Cs + O5)
#define Db5	(Cs + O5)
#define D5	(D + O5)
#define Ds5	(Eb + O5)
#define Eb5	(Eb + O5)
#define E5	(E + O5)
#define F5	(F + O5)
#define Fs5	(Fs + O5)
#define Gb5	(Fs + O5)
#define G5	(G + O5)
#define Gs5	(Gs + O5)
#define Ab5	(Gs + O5)

#define A6	(A + O6)
#define As6	(Bb + O6)
#define Bb6	(Bb + O6)
#define B6	(B + O6)
#define C6	(C + O6)
#define Cs6	(Cs + O6)
#define Db6	(Cs + O6)
#define D6	(D + O6)
#define Ds6	(Eb + O6)
#define Eb6	(Eb + O6)
#define E6	(E + O6)
#define F6	(F + O6)
#define Fs6	(Fs + O6)
#define Gb6	(Fs + O6)
#define G6	(G + O6)
#define Gs6	(Gs + O6)
#define Ab6	(Gs + O6)

#define RepeatEnd	0xff
#define RepeatStart	0xfe
#define Rest		0xfd

UInt	SongFreq[] = {
(UInt) ( 440.00000000000 * 16.0),   /* A	*/
(UInt) ( 466.16376151809 * 16.0),   /* B flat	*/
(UInt) ( 493.88330125612 * 16.0),   /* B	*/
(UInt) ( 523.25113060119 * 16.0),   /* C	*/
(UInt) ( 554.36526195374 * 16.0),   /* C sharp */
(UInt) ( 587.32953583481 * 16.0),   /* D	*/
(UInt) ( 622.25396744416 * 16.0),   /* E flat	*/
(UInt) ( 659.25511382574 * 16.0),   /* E	*/
(UInt) ( 698.45646286600 * 16.0),   /* F	*/
(UInt) ( 739.98884542326 * 16.0),   /* F sharp  */
(UInt) ( 783.99087196349 * 16.0),   /* G	*/
(UInt) ( 830.60939515989 * 16.0),   /* G sharp	*/
};

#define Freq(note)  (SongFreq[(note)&0xf] >> (((note) & 0xf0) >> 4))

void
PlaySong (SongType  *song)
{
    SndCommandType  cmd;
    int		    n;
    int		    repeating;
    NoteType	    *note;
    UInt	    vol;
    EventType	    evt;
    
    SndGetDefaultVolume (0, 0, &vol);
    n = 0;
    repeating = 0;
    while (n != song->nnotes)
    {
	EvtGetEvent (&evt, 0);
	if (evt.eType == penDownEvent)
	{
	    EvtAddEventToQueue (&evt);
	    break;
	}
	note = song->notes + n;
	switch (note->note) {
	case RepeatEnd:
	    if (!repeating)
	    {
		while (n >= 0)
		{
		    if (song->notes[n].note == RepeatStart)
			break;
		    n--;
		}
		repeating = 1;
	    }
	    else
	    {
		repeating = 0;
		n++;
	    }
	    break;
	case RepeatStart:
	    n++;
	    break;
	default:
	    cmd.param2 = note->duration * song->tempo_num / song->tempo_den;
	    if (note->note == Rest)
	    {
		SysTaskDelay (cmd.param2 * sysTicksPerSecond / 1000);
	    }
	    else
	    {
		cmd.cmd = sndCmdFreqDurationAmp;
		cmd.param1 = Freq(note->note);
		cmd.param3 = vol;
		SndDoCmd (0, &cmd, False);
	    }
	    n++;
	    break;
	}
    }
}

static NoteType    oldMacNotes[] = {
    { F2, Eighth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { C2, Eighth, },
    { D2, Eighth, },
    { D2, Eighth, },
    { C2, Quarter, },
    
    { A3, Eighth, },
    { A3, Eighth, },
    { G2, Eighth, },
    { G2, Eighth, },
    { F2, Quarter + Eighth, },
    
    { C2, Eighth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { C2, Eighth, },
    { D2, Eighth, },
    { D2, Eighth, },
    { C2, Quarter, },
    { A3, Eighth, },
    { A3, Eighth, },
    { G2, Eighth, },
    { G2, Eighth, },
    { F2, Quarter + Eighth, },
    
    { C2, Sixteenth, },
    { C2, Sixteenth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { F2, Eighth + Sixteenth, },

    { C2, Sixteenth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { F2, Quarter },

    { F2, Sixteenth },
    { F2, Sixteenth },
    { F2, Eighth },

    { F2, Sixteenth },
    { F2, Sixteenth },
    { F2, Eighth },

    { F2, Sixteenth },
    { F2, Sixteenth },
    { F2, Sixteenth },
    { F2, Sixteenth },
    { F2, Eighth },
    { F2, Eighth },

    { F2, Eighth, },
    { F2, Eighth, },
    { F2, Eighth, },
    { C2, Eighth, },
    { D2, Eighth, },
    { D2, Eighth, },
    { C2, Quarter, },
    
    { A3, Eighth, },
    { A3, Eighth, },
    { G2, Eighth, },
    { G2, Eighth, },
    { F2, Quarter, },
};

static SongType OldMacDonald = {
    oldMacNotes,
    sizeof (oldMacNotes) / sizeof (oldMacNotes[0]),
    20, 1
};

static NoteType tomorrowNotes[] = {
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },
    
    { D2, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { Fs1, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { D2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },
    
    { E2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { A2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { Fs2, Eighth+Thirtysecond },
    { A3, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },
    { B2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { Cs2, Quarter },
    { A2, Quarter },
    { A2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { D2, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { Fs1, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { D2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },

    { E2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { A2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { Fs2, Eighth+Thirtysecond },
    { A3, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },
    { B2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },

    { D2, Quarter },
    { D2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { D2, Quarter },

    { Fs2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },

    { A3, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { D2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { A3, Quarter },
    { G2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    
    { G2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },
    { Cs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },
    { G2, Quarter },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },
    
    { Fs2, Eighth+Thirtysecond },
    { A3, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },
    { B2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },

    { Cs2, Quarter },
    { A2, Quarter },
    { A2, Quarter },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { D2, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { Fs1, Eighth+Thirtysecond },
    { A2, Eighth-Thirtysecond },
    { D2, Eighth+Thirtysecond },
    { Fs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },

    { E2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { A2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { E2, Eighth-Thirtysecond },

    { Fs2, Eighth+Thirtysecond },
    { A3, Eighth-Thirtysecond },
    { Fs2, Eighth+Thirtysecond },
    { D2, Eighth-Thirtysecond },
    { B2, Eighth+Thirtysecond },
    { G2, Eighth-Thirtysecond },
    { E2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },

    { D2, Quarter },
    { D2, Eighth+Thirtysecond },
    { Cs2, Eighth-Thirtysecond },
    { D2, Quarter },

};

static SongType    TomorrowMorning = {
    tomorrowNotes,
    sizeof (tomorrowNotes) / sizeof (tomorrowNotes[0]),
    10, 1
};

static NoteType menuetNotes[] = {
    { G0, Eighth },
    { D1, Eighth },
    { B2, Quarter },
    { A2, Eighth },
    { B2, Sixteenth },
    { C2, Sixteenth },

    { B2, Eighth },
    { A2, Eighth },
    { G1, Eighth },
    { Fs1, Eighth },
    { G1, Eighth },
    { D1, Eighth },

    { E1, Eighth },
    { G1, Eighth },
    { C2, Eighth },
    { A2, Eighth },
    { Fs1, Eighth },
    { D2, Eighth },

    { G0, Sixteenth },
    { D1, Sixteenth },
    { C2, Thirtysecond },
    { B2, Thirtysecond },
    { C2, Thirtysecond },
    { B2, Thirtysecond },
    { C2, Thirtysecond },
    { B2, Half - Eighth - 5 * Thirtysecond },
    { A2, Quarter },

    { A1, Eighth },
    { Fs1, Eighth },
    { C2, Quarter },
    { B2, Eighth },
    { C2, Sixteenth },
    { D2, Sixteenth },

    { C2, Eighth },
    { B2, Eighth },
    { A2, Eighth },
    { G1, Eighth },
    { Fs1, Eighth },
    { E1, Eighth },
    
    { Fs1, Eighth },
    { G1, Sixteenth },
    { A2, Sixteenth },
    { G1, Eighth },
    { Fs1, Eighth },
    { E1, Eighth },
    { Fs1, Eighth },

    { D1, Quarter },
    { A1, Quarter },
    { D0, Quarter },

    { D1, Eighth },
    { Fs1, Eighth },
    { A2, Quarter },
    { G1, Eighth },
    { A2, Sixteenth },
    { B2, Sixteenth },

    { A2, Eighth },
    { G1, Eighth },
    { Fs1, Eighth },
    { E1, Eighth },
    { D1, Eighth },
    { Fs1, Eighth },
    
    { B1, Eighth },
    { D1, Eighth },
    { Gs1, Eighth },
    { A2, Eighth },
    { B2, Eighth },
    { D2, Eighth },

    { A1, Eighth },
    { D2, Eighth },
    { C2, Eighth },
    { B2, Eighth },
    { C2, Quarter },
    
    { Eb1, Eighth },
    { Fs1, Eighth },
    { A2, Eighth },
    { C2, Eighth },
    { B2, Eighth },
    { A2, Eighth },
    
    { B2, Eighth },
    { E1, Eighth },
    { G0, Eighth },
    { A2, Eighth },
    { C2, Eighth },
    { B2, Eighth },
    
    { A2, Eighth },
    { G1, Eighth },
    { Fs1, Eighth },
    { E1, Eighth },
    { B1, Eighth },
    { Eb1, Eighth },

    { E0, Quarter + Eighth },
    { E1, Eighth },
    { D1, Eighth },
    { C1, Eighth },
    
    { B1, Eighth },
    { D1, Eighth },
    { G1, Quarter },
    { D1, Eighth },
    { E1, Sixteenth },
    { F1, Sixteenth },

    { F1, Eighth },
    { D1, Eighth },
    { E1, Eighth },
    { C1, Eighth },
    { C0, Eighth },
    { B1, Eighth },
    
    { Cs1, Eighth },
    { E1, Eighth },
    { A2, Quarter },
    { E1, Eighth },
    { Fs1, Sixteenth },
    { G1, Sixteenth },
    
    { G1, Eighth },
    { E1, Eighth },
    { Fs1, Eighth },
    { D1, Eighth },
    { D0, Eighth },
    { A1, Eighth },
    
    { D1, Eighth },
    { Fs1, Eighth },
    { A2, Eighth },
    { C2, Eighth },
    { B2, Eighth },
    { D2, Eighth },
    
    { E1, Eighth },
    { G1, Eighth },
    { B2, Eighth },
    { D2, Eighth },
    { C2, Eighth },
    { E2, Eighth },
    
    { D2, Eighth },
    { Fs1, Eighth },
    { G1, Eighth },
    { B1, Eighth },
    { D0, Eighth },
    { Fs1, Eighth },
    
    { G0, Sixteenth },
    { G1, Half + Quarter - Sixteenth },

};

SongType    Menuet = {
    menuetNotes,
    sizeof (menuetNotes) / sizeof (menuetNotes[0]),
    20, 1
};

#if 0
static NoteType    duffyNotes {
    { 
    }
};

SongType    Duffy = {
    duffyNotes,
    sizeof (duffyNotes) / sizeof (duffyNotes[0]),
    10, 1
};
#endif
static NoteType    catNotes[] = {
    { A2, Eighth },
    
    { D2, Quarter, },
    { D2, Quarter, },
    { D2, Quarter + Eighth, },
    { Cs2, Eighth },

    { B2, EighthTriplet * 2 },
    { D2, EighthTriplet },
    { Cs2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { A2, Quarter + Eighth },
    { Fs1, Eighth },

    { Fs1, Quarter },
    { Fs1, Quarter },
    { Fs1, Quarter + Eighth },
    { Fs1, Eighth },

    { G1, EighthTriplet * 2 },
    { Fs1, EighthTriplet },
    { G1, EighthTriplet * 2 },
    { A2, EighthTriplet },
    { Fs1, Quarter + Sixteenth },
    { Rest, Quarter - Sixteenth },

    { D2, Quarter },
    { D2, EighthTriplet * 2 },
    { D2, EighthTriplet },
    { D2, Quarter + Eighth },
    { Cs2, Eighth },
    
    { B2, EighthTriplet * 2 },
    { D2, EighthTriplet },
    { Cs2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { A2, Quarter + Eighth },
    { Fs1, Eighth },

    { Fs1, Quarter },
    { B2, Quarter },
    { E1, EighthTriplet * 2 },
    { E1, EighthTriplet },
    { A2, EighthTriplet * 2 },
    { Cs2, EighthTriplet },

    { B2, Quarter + Eighth },
    { B2, Eighth },
    { A2, Half },

    { Fs2, Half },
    { Fs2, Quarter + Eighth },
    { E2, Eighth },

    { E2, Quarter },
    { D2, Quarter },
    { A2, Half },

    { A2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { Cs2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { B2, Quarter },
    { A2, Quarter },

    { A2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { Cs2, EighthTriplet * 2 },
    { B2, EighthTriplet },
    { B2, Quarter },
    { A2, Quarter },

    { Fs2, Half },
    { Fs2, Quarter + Eighth },
    { E2, Eighth },

    { E2, Quarter },
    { D2, Quarter },
    { Cs2, Quarter },
    { B2, Quarter },

    { A2, EighthTriplet * 2 },
    { A2, EighthTriplet },
    { D2, EighthTriplet * 2 },
    { Fs2, EighthTriplet },
    { A3, Quarter },
    { Cs2, Quarter },
    
    { D2, Half },
};

static SongType Cat = {
    catNotes,
    sizeof (catNotes) / sizeof (catNotes[0]),
    20, 1
};
    

NoteType odeNotes[] = {
    { Fs1, Quarter },
    { Fs1, Quarter },
    { G1, Quarter },
    { A2, Quarter },

    { A2, Quarter },
    { G1, Quarter },
    { Fs1, Quarter },
    { E1, Quarter },

    { D1, Quarter },
    { D1, Quarter },
    { E1, Quarter },
    { Fs1, Quarter },

    { Fs1, Quarter + Eighth },
    { E1, Eighth },
    { E1, Half },

    
    { Fs1, Quarter },
    { Fs1, Quarter },
    { G1, Quarter },
    { A2, Quarter },

    { A2, Quarter },
    { G1, Quarter },
    { Fs1, Quarter },
    { E1, Quarter },

    { D1, Quarter },
    { D1, Quarter },
    { E1, Quarter },
    { Fs1, Quarter },

    { E1, Quarter + Eighth },
    { D1, Eighth },
    { D1, Half },

    { RepeatStart, 0 },

    { E1, Quarter },
    { E1, Quarter },
    { Fs1, Quarter },
    { D1, Quarter },
    
    { E1, Quarter },
    { Fs1, Eighth },
    { G1, Eighth },
    { Fs1, Quarter },
    { D1, Quarter },
    
    { E1, Quarter },
    { Fs1, Eighth },
    { G1, Eighth },
    { Fs1, Quarter },
    { E1, Quarter },

    { D1, Quarter },
    { E1, Quarter },
    { A1, Quarter },
    { Fs1, Half },

    { Fs1, Quarter },
    { G1, Quarter },
    { A2, Quarter },
    
    { A2, Quarter },
    { G1, Quarter },
    { Fs1, Quarter },
    { E1, Quarter },
    
    { D1, Quarter },
    { D1, Quarter },
    { E1, Quarter },
    { Fs1, Quarter },

    { E1, Quarter + Eighth },
    { D1, Eighth },
    { D1, Half },

    { RepeatEnd, 0 },
};

SongType Ode = {
    odeNotes,
    sizeof (odeNotes) / sizeof (odeNotes[0]),
    15, 1
};

SongType    *songs[] = {
    &OldMacDonald,
    &TomorrowMorning,
    &Menuet,
/*    &Duffy,*/
    &Cat,
    &Ode,
};

#define NSONGS	(sizeof (songs) / sizeof (songs[0]))

void
PlayRandomSong (Int win)
{
    int		s;
    Boolean	sing;
    SystemPreferencesTypeV10	*pref10;
    SystemPreferencesType	pref;

    pref.version = preferenceDataVersion;
    PrefGetPreferences (&pref);
    if (pref.version >= preferenceDataVersion)
	sing = pref.gameSoundLevel != slOff;
    else
    {
	pref10 = (SystemPreferencesTypeV10 *) &pref;
	sing = pref10->sysSoundLevel != slOff;
    }
    if (sing)
    {
	s = SysRandom(0) % NSONGS;
	PlaySong (songs[s]);
    }
}
