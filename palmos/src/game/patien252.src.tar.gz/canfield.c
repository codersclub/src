/*
 * $Id: canfield.c,v 1.7 1998/08/08 07:03:29 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define CanfieldDeck	0
#define CanfieldDiscard	1
#define CanfieldPile	2
#define CanfieldNpile	4
#define CanfieldLpile	(CanfieldPile + CanfieldNpile - 1)
#define CanfieldTable	(CanfieldLpile + 1)
#define CanfieldNtable	4
#define CanfieldLtable	(CanfieldTable + CanfieldNtable - 1)
#define CanfieldStock	(CanfieldLtable + 1)
#define CanfieldNstock	1
#define CanfieldLstock	(CanfieldStock + CanfieldNstock - 1)
#define CanfieldNstack	(CanfieldLstock + 1)

CardSetupType	CanfieldSetup[] =  {
    { { 5, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },

    { { 4, 0 }, { 1, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },

    { { 0, 0 }, { 2, 0 }, CardEmpty, CardDisplayTop, False, False, 1, CardStartUp },
    { { 1, 0 }, { 3, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
    { { 2, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },
    { { 3, 0 }, { 5, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },

    { { 0, 1 }, { 2, 1 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 1, 1 }, { 3, 1 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 2, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 3, 1 }, { 5, 1 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    
    { { 5, 1 }, { 0, 1 }, CardEmpty, CardDisplayTop, False, False, 13, CardStartUp },
};

static Card
CanfieldBase (void)
{
    CardStackType   *sp = CardStackPtr (CanfieldPile);

    if (sp->first != NullIndex)
	return Rank (CardPtr (sp->first)->card);
    return 0;
}

static Card
CanfieldTop (void)
{
    Card    base = CanfieldBase ();

    if (base == 1) return KING;
    return base - 1;
}

static CardBool
CanfieldCardIsInOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    {
	CardType	*ap = CardPtr (a), *bp = CardPtr (b);
	
	return ap->face == bp->face &&
	       (Rank (ap->card) + 1 == Rank (bp->card) ||
		(Rank (ap->card) == KING && Rank (bp->card) == 1 &&
		 CanfieldBase() != 1));
    }
}

static CardBool
CanfieldCardIsInSuitOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    if (Suit (CardPtr(a)->card) != Suit (CardPtr (b)->card))
	return False;
    return CanfieldCardIsInOrder (a,b);
}

static CardBool
CanfieldCardIsInAlternatingSuitOrder (CardIndex a, CardIndex b)
{
    if (a == NullIndex || b == NullIndex) return False;
    return CanfieldCardIsInOrder (a, b) &&
	       IsAlternateSuit (CardPtr (a)->card, 
				CardPtr (b)->card);
}

#if 0
static CardIndex
CanfieldCardInSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->next != NullIndex && 
	   CanfieldCardIsInSuitOrder (cp->next, card))
	card = cp->next;
    return card;
}

static CardIndex
CanfieldCardInAlternatingSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->next != NullIndex && 
	   CanfieldCardIsInAlternatingSuitOrder (cp->next, card))
	card = cp->next;
    return card;
}
#endif

static CardIndex
CanfieldCardInReverseAlternatingSuitOrder (CardIndex card)
{
    CardType	*cp;
    
    while ((cp = CardPtr (card))->prev != NullIndex && 
	   CanfieldCardIsInAlternatingSuitOrder (card, cp->prev))
	card = cp->prev;
    return card;
}

static CardBool
CanfieldSelectStack (CardStackIndex stack,
		     CardIndex	    *first,
		     CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);

    *first = sp->last;
    *last = CanfieldCardInReverseAlternatingSuitOrder (sp->last);
    return True;
}

static CardProgressType
CanfieldCheckTable (CardStackIndex  src, 
		    CardStackIndex  dst,
		    CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	/*
	 * Can only fill blank spaces from stock until that
	 * is exhausted
	 */
	if (src != CanfieldStock && 
	    CardStackPtr (CanfieldStock)->last != NullIndex)
	{
	    return CardProgressCant;
	}
	if (CanfieldPile <= src && src <= CanfieldLpile)
	    return CardProgressBack;
	if (CardPtr (card)->prev == NullIndex)
	    return CardProgressNone;
	return CardProgressSome;
    }
    else
    {
	if (CanfieldCardIsInAlternatingSuitOrder (card, dp->last))
	{
	    if (CanfieldPile <= src && src <= CanfieldLpile)
		return CardProgressBack;
	    if (CanfieldCardIsInAlternatingSuitOrder (card,
					      CardPtr (card)->prev))
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    return CardProgressCant;
}

static CardProgressType
CanfieldCheckPile (CardStackIndex src, 
		   CardStackIndex dst,
		   CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == CanfieldBase())
	    return CardProgressSome;
    }
    else
    {
	if (CanfieldCardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardBool
CanfieldSelectDeck (CardStackIndex stack,
		    CardIndex *first, CardIndex *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    PatS    	    i;
    CardType	    *cp;

    card = sp->last;
    for (i = 0; i < 2; i++)
    {
	cp = CardPtr (card);
	if (cp->prev == NullIndex)
	    break;
	card = cp->prev;
    }
    *first = *last = card;
    return True;
}

static void
CanfieldMoveDeal (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last)
{
    CardIndex	card, next;

    card = CardStackPtr (src)->last;
    for (;;)
    {
	next = CardPtr (card)->prev;
	CardMove (src, card, dst, True);
	CardTurn (dst, card, True, True);
	if (card == last)
	    break;
	card = next;
    }
}

static void
CanfieldMoveReset(CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    last)
{
    CardIndex	card, next;

    card = CardStackPtr (src)->last;
    for (;;)
    {
	next = CardPtr (card)->prev;
	CardMove (src, card, dst, True);
	CardTurn (dst, card, False, True);
	if (card == last)
	    break;
	card = next;
    }
}

static CardBool
CanfieldSelectResetDeck (CardStackIndex stack,
			 CardIndex	*first,
			 CardIndex	*last)
{
    if (CardStackPtr (CanfieldDeck)->last != NullIndex)
	return False;
    *first = *last = CardStackPtr (stack)->first;
    return True;
}

CardMoveType CanfieldMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ CanfieldTable, CanfieldLtable },
	{ CanfieldTable, CanfieldLtable },
	{ CanfieldPile, CanfieldLpile },
	CardMoveAuto,
	0,
	CanfieldCheckPile,
	0,
    },
    /* 1    Move card from stock to pile */
    {	"stock to pile",
	{ CanfieldStock, CanfieldStock },
	{ CanfieldStock, CanfieldStock },
	{ CanfieldPile, CanfieldLpile },
	CardMoveAuto,
	0,
	CanfieldCheckPile,
	0,
    },
    /* 2    Move card from discard to pile */
    {	"discard to pile",
	{ CanfieldDiscard, CanfieldDiscard },
	{ CanfieldDiscard, CanfieldDiscard },
	{ CanfieldPile, CanfieldLpile },
	CardMoveAuto,
	0,
	CanfieldCheckPile,
	0,
    },
    /* 3    Move card from table to table */
    {	"table to table",
	{ CanfieldTable, CanfieldLtable },
	{ CanfieldTable, CanfieldLtable },
	{ CanfieldTable, CanfieldLtable },
	CardMoveHelpful,
	CanfieldSelectStack,
	CanfieldCheckTable,
	0,
    },
    /* 4    Move card from stock to table */
    {	"stock to table",
	{ CanfieldStock, CanfieldStock },
	{ CanfieldStock, CanfieldStock },
	{ CanfieldTable, CanfieldLtable },
	CardMoveAuto,
	0,
	CanfieldCheckTable,
	0,
    },
    /* 5    Move card from discard to table */
    {	"discard to table",
	{ CanfieldDiscard, CanfieldDiscard },
	{ CanfieldDiscard, CanfieldDiscard },
	{ CanfieldTable, CanfieldLtable },
	CardMoveHelpful,
	0,
	CanfieldCheckTable,
	0,
    },
    /* 6    Deal next three cards */
    {	"deal",
	{ CanfieldDeck, CanfieldDeck },
	{ CanfieldDeck, CanfieldDeck },
	{ CanfieldDiscard, CanfieldDiscard },
	CardMoveHelpful,
	CanfieldSelectDeck,
	0,
	CanfieldMoveDeal,
    },
    /* 7    Reset deck */
    {	"reset",
	{ CanfieldDeck, CanfieldDeck },
	{ CanfieldDiscard, CanfieldDiscard },
	{ CanfieldDeck, CanfieldDeck },
	CardMoveHelpful,
	CanfieldSelectResetDeck,
	0,
	CanfieldMoveReset,
    },
    /* 8    Move card from pile to table */
    {	"pile to table",
	{ CanfieldPile, CanfieldLpile },
	{ CanfieldPile, CanfieldLpile },
	{ CanfieldTable, CanfieldLtable },
	CardMoveNoHelp,
	0,
	CanfieldCheckTable,
	0,
    },
};


#define NMOVES	(sizeof (CanfieldMoves) / sizeof (CanfieldMoves[0]))

static CardBool
CanfieldNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp, *stockp;
    CardIndex	    card;
    CardType	    *cp;

    stockp = CardStackPtr (CanfieldStock);
    for (stack = CanfieldTable; stack <= CanfieldLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    for (stack = CanfieldPile; stack <= CanfieldLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != CanfieldTop ())
	    return False;
    }
    return True;
}

RulesType   canfieldGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, CanfieldNstack,
    CanfieldNormalize,
    0,
    0,
    CanfieldSetup,
    NMOVES,
    CanfieldMoves
};
