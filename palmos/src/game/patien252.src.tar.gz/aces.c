/*
 * $Id: aces.c,v 1.5 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define AcesDeck    0
#define AcesDiscard 1
#define AcesTable   2
#define AcesNtable  4
#define AcesLtable  (AcesTable + AcesNtable - 1)
#define AcesNstack  6

CardSetupType	AcesSetup[] = {
    { { 4, 1 }, { 0, 1 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },
    { { 4, 0 }, { 0, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartUp },

    { { 0, 0 }, { 1, 0 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 1, 0 }, { 2, 0 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 2, 0 }, { 3, 0 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
    { { 3, 0 }, { 4, 0 }, CardNone, CardDisplayAll, False, False, 1, CardStartUp },
};

static CardProgressType
AcesCheckDiscard (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackIndex  s;
    CardStackType   *sp = CardStackPtr (src);
    CardStackType   *dp;

    for (s = AcesTable; s <= AcesLtable; s++)
    {
	dp = CardStackPtr (s);
	if (dp->last != NullIndex &&
	    Suit (CardPtr (dp->last)->card) ==
	    Suit (CardPtr (sp->last)->card) &&
	    Rank (CardPtr (dp->last)->card) >
	    Rank (CardPtr (sp->last)->card))
	return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
AcesCheckEmpty (CardStackIndex	src,
		CardStackIndex	dst,
		CardIndex	last)
{
    if (CardStackPtr (dst)->last != NullIndex)
	return CardProgressCant;
    return CardProgressSome;
}

static CardProgressType
AcesCheckDeal (CardStackIndex	src,
	       CardStackIndex	dst,
	       CardIndex	last)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardBool	    anyEmpty = False;
    CardBool	    anyAvail = False;

    for (stack = AcesTable; stack <= AcesLtable; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    anyEmpty = True;
	else
	    if (sp->last != sp->first)
		anyAvail = True;
    }
    if (anyEmpty && anyAvail)
	return CardProgressCant;
    return CardProgressSome;
}

static void
AcesMoveDeal (CardStackIndex	src,
	      CardStackIndex	dst,
	      CardIndex		last)
{
    CardStackIndex  stack;

    for (stack = AcesTable; stack <= AcesLtable; stack++)
    {
	if (CardStackPtr (AcesDeck)->last == NullIndex)
	    return;
	CardMove (AcesDeck, CardStackPtr (AcesDeck)->last,
		  stack, True);
	CardTurn (stack, CardStackPtr (stack)->last, True, True);
    }
}

CardMoveType	AcesMoves[] = {
    /* 0    Move card from table to discard */
    {	"table to discard",
	{ AcesTable, AcesLtable },
	{ AcesTable, AcesLtable },
	{ AcesDiscard, AcesDiscard },
	CardMoveHelpful,
	0,
	AcesCheckDiscard,
	0
    },
    /* 1    Move card from table to empty table */
    {	"table to empty",
	{ AcesTable, AcesLtable },
	{ AcesTable, AcesLtable },
	{ AcesTable, AcesLtable },
	CardMoveHelpful,
	0,
	AcesCheckEmpty,
	0
    },
    /* 2    Deal */
    {	"deal",
	{AcesDeck, AcesDeck },
	{AcesDeck, AcesDeck },
	{AcesTable, AcesLtable },
	CardMoveHelpful,
	0,
	AcesCheckDeal,
	AcesMoveDeal
    },
};

#define NMOVES (sizeof (AcesMoves) / sizeof (AcesMoves[0]))

static CardBool
AcesNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;

    for (stack = AcesTable; stack <= AcesLtable; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    return False;
	if (sp->last != sp->first)
	    return False;
	if (Rank (CardPtr (sp->last)->card) != ACE)
	    return False;
    }
    if (CardStackPtr (AcesDeck)->last != NullIndex)
	return False;
    return True;
}

RulesType   acesGame = {
    MakeCard (0, CLUB, 2), MakeCard (0, SPADE, ACE), 1, AcesNstack,
    AcesNormalize,
    0,
    0,
    AcesSetup,
    NMOVES,
    AcesMoves
};
