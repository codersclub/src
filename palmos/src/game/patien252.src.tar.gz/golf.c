/*
 * $Id: golf.c,v 1.6 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define GolfDeck	0
#define GolfDiscard	1
#define GolfTable	2
#define GolfNtable	7
#define GolfLtable	(GolfTable + GolfNtable - 1)
#define GolfNstack	9

CardSetupType	GolfSetup[] = {
    { { 6, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },
    { { 5, 0 }, { 1, 0 }, CardEmpty, CardDisplayTop, False, False, 1, CardStartUp },

    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayAll, False, False, 4, CardStartUp },
};

static CardProgressType
GolfCheckDiscard (CardStackIndex    src,
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressSome;
    if (Rank (CardPtr (dp->last)->card) != KING &&
	(CardIsInOrder (card, dp->last) ||
	 CardIsInOrder (dp->last, card)))
	return CardProgressSome;
    return CardProgressCant;
}

static void
GolfMoveDeal (CardStackIndex	src,
	      CardStackIndex	dst,
	      CardIndex		last)
{
    CardIndex	card;

    card = CardStackPtr (src)->last;
    CardMove (src, card, dst, True);
    CardTurn (dst, card, True, True);
}

CardMoveType	GolfMoves[] = {
    /* 0    Move card from table to discard */
    {	"table to discard",
	{ GolfTable, GolfLtable },
	{ GolfTable, GolfLtable },
	{ GolfDiscard, GolfDiscard },
	CardMoveHelpful,
	0,
	GolfCheckDiscard,
	0,
    },
    /* 1    Deal */
    {	"deal",
	{ GolfDeck, GolfDeck },
	{ GolfDeck, GolfDeck },
	{ GolfDiscard, GolfDiscard },
	CardMoveHelpful,
	0,
	0,
	GolfMoveDeal,
    },
};

#define NMOVES	(sizeof (GolfMoves) / sizeof (GolfMoves[0]))

static CardBool
GolfNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;

    for (stack = GolfTable; stack <= GolfLtable; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last != NullIndex)
	    return False;
    }
    return True;
}
    
RulesType   golfGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, GolfNstack,
    GolfNormalize,
    0,
    0,
    GolfSetup,
    NMOVES,
    GolfMoves
};
