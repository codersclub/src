#define height	12
#define width	50

#define col0	2
#define col1	53
#define col2	104

#define label0	20
#define row0	35
#define row1	48

#define label1	73
#define row2	88
#define row3	101
#define row4	114

#define bottom  140

