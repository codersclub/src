/*
 * $Id: pdisp.c,v 1.12 1999/10/24 21:15:12 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "patience.h"
#include "patienceRsc.h"

static void
CardExtent (PatI x, PatI y, RectangleType *r)
{
    r->topLeft.x = x;
    r->topLeft.y = y;
    r->extent.x = cardWidth;
    r->extent.y = cardHeight;
}

static void
CardRect (PatI x, PatI y, RectangleType *r)
{
    PatI	    off;

    off = cardSpace >> 1;
    r->topLeft.x = x + off;
    r->topLeft.y = y + off;
    r->extent.x = cardWidth - cardSpace;
    r->extent.y = cardHeight - cardSpace;
}

static PatI
StackOff (CardStackIndex stack, PatI pos)
{
    CardStackType   *sp = CardStackPtr (stack);
    PatI	    off;
    CardIndex	    card;
    CardType	    *cp;

    off = 0;
    for (card = sp->first; pos && card != NullIndex; card = cp->next)
    {
	cp = CardPtr (card);
	if (cp->show != CardShowNone)
	{
	    switch (cp->show)
	    {
	    case CardShowBack:
		off += sp->back_off;
		break;
	    case CardShowPack:
		off += sp->pack_off;
		break;
	    case CardShowFace:
		off += sp->face_off;
		break;
	    }
	    pos--;
	}
    }
    return off;
}

static void
StackExtent (CardStackIndex stack, RectangleType *r)
{
    CardStackType   *sp = CardStackPtr (stack);
    PatI	    off;

    r->topLeft.x = sp->pos.x * cardWidth + cardOriginX;
    r->topLeft.y = sp->pos.y * cardHeight + cardOriginY;
    r->extent.x = cardWidth;
    r->extent.y = cardHeight;
    off = sp->face_up * sp->face_off + sp->pack_up * sp->pack_off + 
	  sp->back_up * sp->back_off;
    if (sp->horizontal)
        r->extent.x += off;
    else
        r->extent.y += off;
}

static void
CardOutlineDraw (PatI x, PatI y, CardBool empty)
{
    RectangleType   r;

    if (cardSpace >= 2 || empty)
    {
	PatI	    off, space;

	space = cardSpace;
	if (cardSpace < 2)
	    space = 2;
	off = space >> 1;
	r.topLeft.x = x + off;
	r.topLeft.y = y + off;
	r.extent.x = cardWidth - space;
	r.extent.y = cardHeight - space;
	
	WinDrawRectangleFrame ((cardRadius << 8) | 1, &r);
    }
}

static void
CardErase (PatI x, PatI y, Boolean table)
{
    RectangleType   r;
    
    CardExtent (x, y, &r);
    if (table)
	WinSetPattern (tablePattern);
    else
	WinSetPattern (emptyPattern);
    WinFillRectangle (&r, 0);
    WinSetPattern (emptyPattern);
}

#define card_to_suit_id(card)	(bitmapSuitBase + (Suit(card) >> 4))
#define card_to_rank_id(card)	(bitmapRankBase + (Rank(card) == ACE ? \
						   1 : Rank(card)))
typedef struct _CardImage {
    VoidHand	hand;
    BitmapPtr	bitmap;
} CardImage;

static CardImage    CardRankBitmaps[14];
static CardImage    CardSuitBitmaps[4];

void
CardImageInit (CardImage *image, Int res)
{
    if ((image->hand = DmGetResource (bitmapRsc, res)))
    {
	image->bitmap = MemHandleLock (image->hand);
	if (image->bitmap)
	{
	    if (image->bitmap->width > cardLabelWidth)
		cardLabelWidth = image->bitmap->width;
	    if (image->bitmap->height > cardLabelHeight)
		cardLabelHeight = image->bitmap->height;
	}
    }
}

void
CardImageFini (CardImage *image)
{
    if (image->hand)
    {
	if (image->bitmap)
	{
	    MemHandleUnlock (image->hand);
	    image->bitmap = 0;
	}
	DmReleaseResource (image->hand);
	image->hand = 0;
    }
}

void
CardLabelInit (void)
{
    int	    rank, suit;

    for (rank = 1; rank <= KING; rank++)
	CardImageInit (&CardRankBitmaps[rank], bitmapRankBase + rank);
    for (suit = 0; suit < 4; suit++)
	CardImageInit (&CardSuitBitmaps[suit], bitmapSuitBase + suit);
}

void
CardLabelFini (void)
{
    int	    rank, suit;

    for (rank = 1; rank <= KING; rank++)
	CardImageFini (&CardRankBitmaps[rank]);
    for (suit = 0; suit < 4; suit++)
	CardImageFini (&CardSuitBitmaps[suit]);
    cardLabelWidth = 0;
    cardLabelHeight = 0;
}

static void
CardLabel (PatI x, PatI y, Card card, CardBool horizontal)
{
    BitmapPtr	rank_bitmap = 0;
    BitmapPtr	suit_bitmap = 0;

    short	rank_width = 0;
    short	suit_width = 0;

    short	rank_offset_x = 0;
    short	rank_offset_y = 0;
    short	suit_offset_x = 0;
    short	suit_offset_y = 0;

    x = x + cardLabel;
    y = y + cardLabel;

    rank_bitmap = CardRankBitmaps[Rank(card) == ACE ? 1 : Rank(card)].bitmap;
    suit_bitmap = CardSuitBitmaps[Suit(card) >> 4].bitmap;
    
    if (rank_bitmap != 0)
	rank_width = rank_bitmap->width;
    if (suit_bitmap != 0)
	suit_width = suit_bitmap->width;

    if (horizontal)
    {
	/* rank_offset_x = 0; */
	/* rank_offset_y = 0; */
	suit_offset_x = rank_width + 1;
	/* suit_offset_y = 0; */
    }
    else
    {
	if (rank_width > suit_width)
	{
	    /* rank_offset_x = 0; */
	    suit_offset_x = (rank_width - suit_width) / 2;
	}
	else
	{
	    rank_offset_x = (suit_width - rank_width) / 2;
	    /* suit_offset_x = 0; */
	}
	/* rank_offset_y = 0; */
	suit_offset_y = yOffset;
    }

    if (rank_bitmap != 0)
	WinDrawBitmap (rank_bitmap, x + rank_offset_x, y + rank_offset_y);
    
    if (suit_bitmap != 0)
	WinDrawBitmap (suit_bitmap, x + suit_offset_x, y + suit_offset_y);
}

static void
CardBack (PatI x, PatI y)
{
    RectangleType   r;

    CardRect (x, y, &r);
    WinSetPattern (backPattern);
    WinFillRectangle (&r, cardRadius);
}

static void
CardDrawPos (PatI x, PatI y, Card card, CardBool horizontal)
{
    switch (Suit (card)) {
    case CLUB: case DIAMOND: case HEART: case SPADE:
	CardErase (x, y, false);
	CardOutlineDraw (x, y, false);
	CardLabel (x, y, card, !horizontal);
	break;
    case BACK:
	CardErase (x, y, false);
	CardBack (x, y);
	CardOutlineDraw (x, y, false);
	break;
    case EMPTY:
	CardErase (x, y, true);
	CardOutlineDraw (x, y, true);
	break;
    case NONE:
	CardErase (x, y, true);
	break;
    case BLANK:
	CardErase (x, y, false);
	CardOutlineDraw (x, y, false);
	break;
    }
}

static void
CardDraw (CardStackIndex stack, PatI pos, Card card)
{
    CardStackType   *sp = CardStackPtr (stack);
    PatI    	    x, y;

    x = sp->pos.x * cardWidth + cardOriginX;
    y = sp->pos.y * cardHeight + cardOriginY;
    if (sp->horizontal)
	x += StackOff (stack, pos);
    else
	y += StackOff (stack, pos);
    CardDrawPos (x, y, card, sp->horizontal);
}

static void
CardEraseStack (CardStackIndex stack)
{
    RectangleType   r;

    StackExtent (stack, &r);
    WinSetPattern (tablePattern);
    WinFillRectangle (&r, 0);
    WinSetPattern (emptyPattern);
}

static void
CardDisplayStack (CardStackIndex stack)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardType	    *cp;
    PatI	    pos;
    PatI	    avail;
    PatI	    off, face_off, pack_off, back_off;
    PatI	    base;
    CardIndex	    card;
    Card	    suit;
    RectangleType   clip, oldClip;
    int		    count, face;
    
    sp->dirty = False;
    if (sp->display != CardDisplayNone)
    {
	CardEraseStack (stack);
 	CardSetShoulds (stack);
	clip.topLeft.x = sp->pos.x * cardWidth + cardOriginX;
	clip.topLeft.y = sp->pos.y * cardHeight + cardOriginY;
	if (sp->horizontal)
	{
	    sp->face_off = xOffset;
	    base = sp->pos.x * cardWidth + cardOriginX;
	    clip.extent.x = 1024;
	    clip.extent.y = cardHeight;
	}
	else
	{
	    sp->face_off = yOffset;
	    base = sp->pos.y * cardHeight + cardOriginY;
	    clip.extent.x = cardWidth;
	    clip.extent.y = 1024;
	}
        sp->pack_off = sp->face_off;
	sp->back_off = CARD_BOFFSET;
	WinGetClip (&oldClip);
	WinSetClip (&clip);
	avail = CARD_MAX - base;
	/*
	 * Try to get the cards to fit on the screen
	 */
	/*
	 * First see if they all fit with the default spacing
	 */
	face_off = (sp->face_up + 1) * sp->face_off;
	pack_off = sp->pack_up * sp->pack_off;
	back_off = sp->back_up * sp->back_off;
	off = face_off + pack_off + back_off;
        if (off > avail)
	{
	    /*
	     * Second try to pack the 'packable' cards together
	     */
	    if (sp->pack_up)
		sp->pack_off = (avail - face_off - back_off) / sp->pack_up;
	    if (sp->pack_off < CARD_POFFSET)
		sp->pack_off = CARD_POFFSET;
	    pack_off = sp->pack_up * sp->pack_off;
	    off = face_off + pack_off + back_off;
	    if (off > avail)
	    {
		/*
		 * Third, set the pack spacing to a constant and
		 * try packing the face up cards a bit
		 */
		sp->pack_off = CARD_POFFSET;
		pack_off = sp->pack_up * sp->pack_off;
		sp->back_off = CARD_POFFSET;
		back_off = sp->back_up * sp->back_off;
		sp->face_off = (avail - pack_off - back_off) / (sp->face_up + 1);
		/*
		 * If this would pack the face up cards closer together
		 * than the face down cards, space them all the same
		 */
		if (sp->face_off < sp->back_off)
		{
		    sp->face_off = (avail - pack_off) / (sp->face_up + 1 + sp->back_up);
		    if (sp->face_off < sp->pack_off)
			sp->face_off = sp->pack_off;
		    sp->back_off = sp->face_off;
		}
		face_off = (sp->face_up + 1) * sp->face_off;
		back_off = sp->back_up * sp->back_off;
		off = face_off + pack_off + back_off;
		if (off > avail)
		{
		    /*
		     * Fourth, set the pack spacing to 0 and use
		     * all available space for the remaining cards
		     */
		    sp->pack_off = 0;
		    sp->back_off = CARD_POFFSET;
		    back_off = sp->back_up * sp->back_off;
		    sp->face_off = (avail - back_off) / (sp->face_up + 1);
		    if (sp->face_off < sp->back_off)
		    {
			sp->face_off = avail / (sp->face_up + 1 + sp->back_up);
			sp->back_off = sp->face_off;
		    }
		}
	    }
	}
	pos = 0;
	count = 0;
	face = 0;
	if (sp->first == NullIndex)
	{
	    CardDraw (stack, pos, sp->empty);
	    pos++;
	}
	else
	{
	    for (card = sp->first; card != NullIndex; card = cp->next)
	    {
		cp = CardPtr (card);
		if (cp->face)
		{
		    suit = Suit(cp->card);
		    face++;
		}
		else
		    suit = BACK;
		if (cp->show != CardShowNone)
		{
		    CardDraw (stack, pos, MakeCard (0, suit, Rank (cp->card)));
		    pos++;
		}
		count++;
	    }
	}
	if (sp->display == CardDisplayTopCount && count)
	{
	    char	    buf[3];
	    char	    *b;
	    int		    w, h, n;
	    int		    x, y;
	    RectangleType   r;

	    b = buf;
	    if (count >= 100)
	    {
		*b++ = '0' + count / 100;
		buf[0] = 
		count = count % 100;
	    }
	    if (count >= 10)
	    {
		*b++ = '0' + count / 10;
		count = count % 10;
	    }
	    *b++ = '0' + count;
	    n = b - buf;
	    w = FntLineWidth (buf, n);
	    h = FntLineHeight ();
	    if (face == 0)
	    {
		x = clip.topLeft.x + (cardWidth - w) / 2;
		y = clip.topLeft.y + (cardHeight - h) / 2;
	    }
	    else
	    {
		x = clip.topLeft.x + cardWidth - w - 2 - (cardSpace / 2);
		y = clip.topLeft.y + cardHeight - h - (cardSpace / 2);
	    }
	    r.topLeft.x = x - 1;
	    r.topLeft.y = y;
	    r.extent.x = w + 2;
	    r.extent.y = h;
	    WinSetPattern (emptyPattern);
	    WinFillRectangle (&r, 0);
	    WinDrawChars (buf, n, x, y);
	}
	WinSetClip (&oldClip);
    }
}

#define HIT(_r,_x,_y)  (_r.topLeft.x <= _x && _x < _r.topLeft.x+_r.extent.x && \
			_r.topLeft.y <= _y && _y < _r.topLeft.y+_r.extent.y)

CardBool
CardHit (PatI u_x, PatI u_y, 
	 CardStackIndex *stackp, CardIndex *cardp,
	 PatI *c_x, PatI *c_y)
{
    CardStackType   *sp;
    CardType	    *cp;
    PatI    	    pos;
    CardStackIndex  stack;
    CardIndex	    card;
    RectangleType   r;
    PatI	    x, y, s_x, s_y;
    
    for (stack = 0; stack < game.nstacks; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->display != CardDisplayNone)
	{
	    pos = 0;
	    StackExtent (stack, &r);
	    if (HIT (r, u_x, u_y))
	    {
		s_x = r.topLeft.x;
		s_y = r.topLeft.y;
		*stackp = stack;
		*cardp = NullIndex;
		pos = 0;
		for (card = sp->first; card != NullIndex; card = cp->next)
		{
		    cp = CardPtr (card);
		    if (cp->show != CardShowNone)
		    {
			x = s_x;
			y = s_y;
			if (sp->horizontal)
			    x += StackOff (stack, pos);
			else
			    y += StackOff (stack, pos);
			CardExtent (x, y, &r);
			if (HIT (r, u_x, u_y))
			{
			    if (c_x)
				*c_x = x + cardWidth / 2;
			    if (c_y)
				*c_y = y + cardHeight / 2;
			    *cardp = card;
			}
			pos++;
		    }
		}
		return True;
	    }
	}
    }
    return False;
}

PatI
CardPos (CardStackIndex stack, CardIndex card)
{
    CardStackType   *sp;
    PatI	    pos;
    CardType	    *cp;
    CardIndex	    c;

    sp = CardStackPtr (stack);
    if (sp->display == CardDisplayNone)
	return -1;
    pos = 0;
    for (c = sp->first; c != NullIndex; c = cp->next)
    {
	cp = CardPtr (c);
	if (cp->show != CardShowNone)
	{
	    if (c == card)
		return pos;
	    pos++;
	}
    }
    return -1;
}

void
CardDisplayQuery (void)
{
    RectangleType   r;
    if (game.queryMode)
	WinSetPattern (myBlackPattern);
    else
	WinSetPattern (tablePattern);
    r.topLeft.x = 156;
    r.topLeft.y = 156;
    r.extent.x = 4;
    r.extent.y = 4;
    WinFillRectangle (&r, 0);
    game.queryDirty = False;
}

void
CardDisplayAlways (void)
{
    RectangleType   r;
    if (game.alwaysAuto)
	WinSetPattern (myBlackPattern);
    else
	WinSetPattern (tablePattern);
    r.topLeft.x = 0;
    r.topLeft.y = 156;
    r.extent.x = 4;
    r.extent.y = 4;
    WinFillRectangle (&r, 0);
    game.alwaysDirty = False;
}    
void
CardRedisplay (void)
{
    CardStackIndex  stack;

    if (game.queryDirty)
	CardDisplayQuery ();
    if (game.alwaysDirty)
	CardDisplayAlways ();
    for (stack = 0; stack < game.nstacks; stack++)
	if (CardStackPtr (stack)->dirty)
	    CardDisplayStack (stack);
}

void
CardDrawHighlight (CardStackIndex stack, PatI pos)
{
    CardStackType   *sp;
    RectangleType   r;
    PatI	    x, y;
    
    sp = CardStackPtr (stack);
    x = sp->pos.x * cardWidth + cardOriginX;
    y = sp->pos.y * cardHeight + cardOriginY;
    if (sp->horizontal)
	x += StackOff (stack, pos);
    else
	y += StackOff (stack, pos);
    CardRect (x, y, &r);
    WinInvertRectangle (&r, cardRadius);
}

void
CardUndrawHighlight (CardStackIndex stack, PatI pos)
{
    CardDrawHighlight (stack, pos);
}

WinHandle   animateBuffer, saveBuffer, cardBuffer;
PatS	    animateDx, animateDy;
PatS	    animateX, animateY;
PatS	    animateOX, animateOY;
Card	    animateCard;
CardBool    animateHorizontal;

static void
CardSaveAnimate (void)
{
    RectangleType   r;

    r.topLeft.x = animateX;
    r.topLeft.y = animateY;
    r.extent.x = cardWidth;
    r.extent.y = cardHeight;
    WinCopyRectangle (WinGetDrawWindow (),
		      saveBuffer,
		      &r, 0, 0, scrCopy);
}

static void
CardPutAnimate (void)
{
    RectangleType   r;
    
    r.topLeft.x = 0;
    r.topLeft.y = 0;
    r.extent.x = cardWidth;
    r.extent.y = cardHeight;
    WinCopyRectangle (cardBuffer,
		      WinGetDrawWindow(),
		      &r, animateX, animateY, scrCopy);
}

static void
CardRestoreAnimate (void)
{
    RectangleType   r;

    r.topLeft.x = 0;
    r.topLeft.y = 0;
    r.extent.x = cardWidth;
    r.extent.y = cardHeight;
    WinCopyRectangle (saveBuffer,
		      WinGetDrawWindow (),
		      &r, animateOX, animateOY, scrCopy);
}

static void
CardDrawAnimate (void)
{
    PatI	    x, y, xcard, ycard, xsave, ysave;
    RectangleType   r;
    Boolean	    simple;

    simple = false;
    if (animateX > animateOX)
    {
	x = animateOX;
	xsave = 0;
	xcard = animateX - animateOX;
	if (xcard > cardWidth)
	    simple = true;
    }
    else
    {
	x = animateX;
	xsave = animateOX - animateX;
	xcard = 0;
	if (xsave > cardWidth)
	    simple = true;
    }
    if (animateY > animateOY)
    {
	y = animateOY;
	ysave = 0;
	ycard = animateY - animateOY;
	if (ycard > cardHeight)
	    simple = true;
    }
    else
    {
	y = animateY;
	ysave = animateOY - animateY;
	ycard = 0;
	if (ysave > cardHeight)
	    simple = true;
    }
    if (simple)
    {
	CardRestoreAnimate ();
	CardSaveAnimate ();
	CardPutAnimate ();
    }
    else
    {
	/*
	 * Get bits from screen
	 */
	r.topLeft.x = x;
	r.topLeft.y = y;
	r.extent.x = cardWidth * 2;
	r.extent.y = cardHeight * 2;
	WinCopyRectangle (WinGetDrawWindow (),
			  animateBuffer,
			  &r, 0, 0, scrCopy);
	/*
	 * Merge in saved bits
	 */
	r.topLeft.x = 0;
	r.topLeft.y = 0;
	r.extent.x = cardWidth;
	r.extent.y = cardHeight;
	WinCopyRectangle (saveBuffer,
			  animateBuffer,
			  &r, xsave, ysave, scrCopy);
	/*
	 * Create new saved bits
	 */
	r.topLeft.x = xcard;
	r.topLeft.y = ycard;
	r.extent.x = cardWidth;
	r.extent.y = cardHeight;
	WinCopyRectangle (animateBuffer,
			  saveBuffer,
			  &r, 0, 0, scrCopy);
	/*
	 * Add in card image
	 */
	r.topLeft.x = 0;
	r.topLeft.y = 0;
	r.extent.x = cardWidth;
	r.extent.y = cardHeight;
	WinCopyRectangle (cardBuffer,
			  animateBuffer,
			  &r, xcard, ycard, scrCopy);
	/*
	 * stick the result on the screen
	 */
	r.topLeft.x = 0;
	r.topLeft.y = 0;
	r.extent.x = cardWidth * 2;
	r.extent.y = cardHeight * 2;
	WinCopyRectangle (animateBuffer,
			  WinGetDrawWindow (),
			  &r, x, y, scrCopy);
    }
}

CardBool
CardStartAnimate (PatI x, PatI y,
		  CardStackIndex stack, 
		  CardIndex card)
{
    Word	    error;
    CardStackType   *sp = CardStackPtr (stack);
    CardType	    *cp = CardPtr (card);
    Card	    suit;
    PatI	    pos;
    WinHandle	    draw;
    
    if (animateBuffer)
	CardStopAnimate ();
    pos = CardPos (stack, card);
    if (pos == -1)
	return False;
    animateBuffer = WinCreateOffscreenWindow (cardWidth * 2, cardHeight * 2,
					      screenFormat, &error);
    if (!animateBuffer)
	return False;
    saveBuffer = WinCreateOffscreenWindow (cardWidth, cardHeight,
					   screenFormat, &error);
    if (!saveBuffer)
    {
	WinDeleteWindow (animateBuffer, false);
	animateBuffer = 0;
	return False;
    }
    cardBuffer = WinCreateOffscreenWindow (cardWidth, cardHeight,
					   screenFormat, &error);
    if (!cardBuffer)
    {
	WinDeleteWindow (animateBuffer, false);
	animateBuffer = 0;
	WinDeleteWindow (saveBuffer, false);
	saveBuffer = 0;
	return False;
    }
    animateDx = -cardWidth / 2;
    animateDy = -cardHeight / 2;
    animateX = x + animateDx;
    animateY = y + animateDy;
    animateHorizontal = sp->horizontal;
    if (cp->face)
	suit = Suit(cp->card);
    else
	suit = BACK;
    animateCard = MakeCard (0, suit, Rank (cp->card));
    draw = WinGetDrawWindow ();
    WinSetDrawWindow (cardBuffer);
    CardDrawPos (0, 0, animateCard, animateHorizontal);
    WinSetDrawWindow (draw);
    CardSaveAnimate ();
    CardPutAnimate ();
    return True;
}

void
CardStopAnimate (void)
{
    if (animateBuffer)
    {
	animateOX = animateX;
	animateOY = animateY;
	CardRestoreAnimate ();
	WinDeleteWindow (animateBuffer, false);
	WinDeleteWindow (saveBuffer, false);
	WinDeleteWindow (cardBuffer, false);
	animateBuffer = 0;
	saveBuffer = 0;
	cardBuffer = 0;
    }
}


void
CardMoveAnimate (PatI x, PatI y)
{
    if (animateBuffer)
    {
	animateOX = animateX;
	animateOY = animateY;
	animateX = x + animateDx;
	animateY = y + animateDy;
	CardDrawAnimate ();
    }
}
