/*
 * $Id: spider.c,v 1.5 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"
#include "spider.h"

#define SpiderDeck	0
#define SpiderPile	(SpiderDeck + 1)
#define SpiderNpile	8
#define SpiderLpile	(SpiderPile + SpiderNpile - 1)
#define SpiderTable	(SpiderLpile + 1)
#define SpiderNtable	10
#define SpiderLtable	(SpiderTable + SpiderNtable - 1)
#define SpiderNstack	(SpiderLtable + 1)

CardSetupType	SpiderSetup[] =  {
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },
    
    { { 2, 0 }, { 2, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 3, 0 }, { 3, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 4, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 0 }, { 5, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 6, 0 }, { 6, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 7, 0 }, { 7, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 8, 0 }, { 8, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 9, 0 }, { 9, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    
    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayPack, False, False, 6, CardStartLastUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayPack, False, False, 6, CardStartLastUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayPack, False, False, 6, CardStartLastUp },
    { { 7, 1 }, { 7, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 8, 1 }, { 8, 1 }, CardNone, CardDisplayPack, False, False, 5, CardStartLastUp },
    { { 9, 1 }, { 9, 1 }, CardNone, CardDisplayPack, False, False, 6, CardStartLastUp },
};

CardBool
SpiderSelectTable (CardStackIndex   stack,
		   CardIndex	    *first,
		   CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);

    *first = sp->last;
    *last = CardInReverseSuitOrder (sp->last);
    return True;
}

CardProgressType
SpiderCheckTable (CardStackIndex    src, 
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardIndex	    prev;
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last != NullIndex)
    {
	if (CardIsInOrder (card, dp->last))
	{
	    prev = CardPtr (card)->prev;
	    if (prev != NullIndex)
	    {
		if (CardIsInSuitOrder (card, prev))
		    return CardProgressBack;
		if (CardIsInOrder (card, prev))
		    return CardProgressNone;
	    }
	    return CardProgressSome;
	}
    }
    return CardProgressCant;
}

CardProgressType
SpiderCheckEmpty (CardStackIndex    src, 
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (CardPtr (card)->prev == NullIndex)
	    return CardProgressNone;
	return CardProgressSome;
    }
    return CardProgressCant;
}

CardProgressType
SpiderCheckSuitTable  (CardStackIndex	src, 
		       CardStackIndex	dst,
		       CardIndex	card)
{
    CardIndex	    prev;
    CardStackType   *dp = CardStackPtr (dst);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last != NullIndex)
    {
	if (CardIsInSuitOrder (card, dp->last))
	{
	    prev = CardPtr (card)->prev;
	    if (prev != NullIndex)
	    {
		if (CardIsInSuitOrder (card, prev))
		    return CardProgressNone;
	    }
	    return CardProgressSome;
	}
    }
    return CardProgressCant;    /* let CheckTable see this one */
}

CardProgressType
SpiderCheckPile (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);
    CardStackType   *sp = CardStackPtr (src);

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last != NullIndex)
	return CardProgressCant;
    if (Rank (CardPtr (card)->card) != KING)
	return CardProgressCant;
    if (Rank (CardPtr (sp->last)->card) != 1)
	return CardProgressCant;
    return CardProgressSome;
}
    		
static void
SpiderMoveDeal (CardStackIndex  src,
		CardStackIndex  dst,
		CardIndex	last)
{
    CardStackIndex  t;

    for (t = SpiderTable; t <= SpiderLtable; t++)
    {
	if (CardStackPtr (SpiderDeck)->last == NullIndex)
	    return;
	CardMove (SpiderDeck, CardStackPtr (SpiderDeck)->last,
		  t, True);
	CardTurn (t, CardStackPtr (t)->last, True, True);
    }
}

CardMoveType SpiderMoves[] = {
    /* 0    Move card from table to table same suit */
    {	"table to table in suit",
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckSuitTable,
	0,
    },
    /* 1    Move card from table to table */
    {	"table to table",
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckTable,
	0,
    },
    /* 2    Move card from table to empty */
    {	"table to empty",
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	CardMoveHelpful,
	SpiderSelectTable,
	SpiderCheckEmpty,
	0,
    },
    /* 3    Move card from table to pile */
    {	"table to pile",
	{ SpiderTable, SpiderLtable },
	{ SpiderTable, SpiderLtable },
	{ SpiderPile, SpiderLpile },
	CardMoveAuto,
	SpiderSelectTable,
	SpiderCheckPile,
	0,
    },
    /* 4    deal */
    {	"deal",
	{ SpiderDeck, SpiderDeck },
	{ SpiderDeck, SpiderDeck },
	{ SpiderTable, SpiderLtable },
	CardMoveHelpful,
	0,
	0,
	SpiderMoveDeal,
    },
};

#define NMOVES	(sizeof (SpiderMoves) / sizeof (SpiderMoves[0]))

static CardBool
SpiderNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = SpiderTable; stack <= SpiderLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    for (stack = SpiderPile; stack <= SpiderLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
    }
    return True;
}

RulesType   spiderGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 2, SpiderNstack,
    SpiderNormalize,
    0,
    CardIsInSuitOrder,
    SpiderSetup,
    NMOVES,
    SpiderMoves
};
