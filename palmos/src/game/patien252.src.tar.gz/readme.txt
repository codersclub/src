			Patience Version 2.5.2
			   Keith Packard
			keithp@clueserver.org

Patience is a collection of solitaire card games for the Palm Pilot.

Version 2.5.2
	+ Fixed (at least one) problem causing 2.5 not to start on
	  OS 3.3
	+ Removed diagnostics from 2.5.1

Version 2.5.1
	+ Simplify custom characters for readability on Palm screen
	+ Add debugging to figure out where Patience fails on
	  OS 3.3 for some users

Version 2.5
	+ Add a few new games
	+ A few minor UI changes
	+ Changed cards to use custom characters instead of
	  built in characters (thanks to Imoto Takashi)
	+ Runs on PalmOS 3.3

Version 2.4.1 �
	+ shrink data structure sizes
	+ Make global game datastructure static rather than allocated
	+ Add card count to deck in some games

Version 2.5.1 adds some diagnostics to figure out where Patience fails
on some OS 3.3 boxes and also simplifies the characters displayed on
the cards.

Version 2.5 adds a few more games (Vegas-rules klondike, Freecell and Wish)
plus a few UI fixes.  Mostly, it works on OS 3.3 and includes custom
labels for the cards instead of using the built-in characters.  This
makes the cards more readable, plus makes it possible to port Patience
to the Shift-JIS encoded Japanese Palm.  A Japanese version should
be released soon.

Version 2.4 modifies the UI by making the table have a unique color, and
also adds two new games, Canfield and Eight Off.  Eight Off is similar to
Towers, except has more stocks and fewer tableaus.  As a result, it
plays a bit easier on the tiny screen.  I've changed the UI for Yukon;
tapping a card now moves that card rather than attempting to move some
random subset of the stack.  Yukon now has hints as well.  

I've added a 'examine' mode where tapping a card shows the whole card;
dragging shows other cards.  Hitting the next-page button while holding the
pen on a card switches back to play mode so you can play the selected card.
While in examine mode, a small black square is displayed in the lower right
corner of the screen.

I've added 'always auto-play' mode.  In this mode, each time a card
is played, any auto-play moves are made afterwards.

I've added left-handed layouts for games where it matters.

I've discovered a problem when hackmaster is running and using some
of the application heap space -- patience was using too much for
undo history.  I've moved the undo history to global memory, increasing
the maximum undo count to 1024 and reducing local heap usage by a lot.

Version 2.3 improves the UI by animating cards to track the pen.  It's
also the first release built with the prc tools provided by Jeff Dionne
for Linux.  A vast improvement over the Metrowerks environment on the
Macintosh.  I also added attribution for Tabby Cat and the rules
of the game to Rick Holzgrafe, the author of Solitaire Till Dawn
for the Macintosh.

The Games

*	Aces High
This is a very simple solitaire, infrequently winnable and
pretty much determined by the deal rather than the play.

*	Calculation
Keeps your mind working with modulo 13 arithmetic

*	Canfield
Another classic, much like Klondike except foundations start
at an arbitrary rank and empty tableaus are filled from a stock.

*	Eight Off
Similar to Towers, but with eight tableaus and eight stocks. Seems
to be about as winnable.

*	FreeCell
Another classic.

*	Golf
Count up and down, try to end with fewer than four cards showing.

*	Klondike
The classic; in draw-three style

*	Montana
Line up all four suits from 2 to King.  Tap empty spaces to highlight
the card which goes there.  Tap cards to highlight where they go.

*	Spider
My favorite double-deck solitaire; more playable in version 2.0, but still
cramped.

*	Spiderette
A single-deck version of Spider.  It seems to be less affected by skill than
spider.

*	Tabby Cat
Similar to Spiderette, but suits don't matter, and you get this fine
tail to play with.

*	Towers
Similar to FreeCell, but a bit easier to play.

*	Vegas
Klondike solitaire using Vegas rules (draw one card).

*	Wish
A very easy game, pairs of cards matching in rank are discarded until
no cards are left.  Approximately 25% of deals are winnable.

*	Yukon
Looks like Klondike, but is more complicated.

The Play

All of the games have the same controls; most of the time tapping
on a column will move some cards in a useful manner.  When that doesn't
work, drag a card where you want it to go.  Hints and 1024-level undo
are always available.

Copyright � 1996, 1997, 1998, 1999 Keith Packard

Patience is made available without fee.  If you have a favorite solitaire
that you think will work well on the Pilot, send along a description of the
game and I'll see about incorporating it into the next release.

Keith Packard
keithp@clueserver.org
http://clueserver.org/keithp

