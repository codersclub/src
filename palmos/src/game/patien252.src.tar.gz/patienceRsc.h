#define	mainForm	1010
    
#define newForm		1100
#define newFormTitle	1101

#define newFormShortLabel    	    1110

#define newFormLongLabel	    1120

#define newFormNewBtn		    1140
#define newFormRulesBtn		    1141
#define newFormCancelBtn	    1142
#define newFormInfo		    1143

#define newFormFirstGame	    1150
#define klondikeButton		    1150
#define montanaButton		    1151
#define towersButton		    1152
#define spiderButton		    1153
#define tabbyButton		    1154
#define golfButton		    1155
#define acesButton		    1156
#define calcButton		    1157
#define yukonButton		    1158
#define spideretteButton	    1159
#define eightButton		    1160
#define canfieldButton		    1161
#define vegasButton		    1162
#define freecellButton		    1163
#define wishButton		    1164

#define menuBar		1200
#define menuPatience	1210
#define menuPatienceHint    menuPatience + 0
#define menuPatienceAuto    menuPatience + 1
#define menuPatienceUndo    menuPatience + 3
#define menuPatienceRestart menuPatience + 4
#define menuPatienceNew	    menuPatience + 6

#define menuSettings	1220
#define menuPatienceExamine menuSettings + 1
#define menuPatienceAlwaysAuto	menuSettings + 2
#define menuPatienceLeftHanded	menuSettings + 3

#define menuHelp	1230
#define menuHelpControls    menuHelp + 0
#define menuHelpRules	    menuHelp + 1
#define menuHelpGetInfo	    menuHelp + 3

#define infoForm	1300
#define infoTitle	1301
#define infoText	1302
#define infoOk		1303
#define infoFormHelp	1310

#define controlForm	1400
#define controlTitle	1401
#define controlText	1402
#define controlOk	1403

#define rulesForm	1500
#define rulesTitle	1501
#define rulesText	1502
#define rulesOk		1503
#define rulesScrollUp	1504
#define rulesScrollDown	1505

#define rulesFirst	1600
#define rulesKlondike	1600
#define rulesMontana	1601
#define rulesTowers	1602
#define rulesSpider	1603
#define rulesTabby	1604
#define rulesGolf	1605
#define rulesAces	1606
#define rulesCalc	1607
#define rulesYukon	1608
#define rulesSpiderette	1609
#define rulesEight	1610
#define rulesCanfield	1611
#define rulesVegas	1612
#define rulesFreecell	1613
#define rulesWish	1614

#define statsForm	1700
#define statsTitle	1701
#define statsOk		1702
#define statsClear	1703

#define statTop		15
#define statHeight	8

#define statsFirst	1800
#define statsKlondike	1800
#define statsMontana	1801
#define statsTowers	1802
#define statsSpider	1803
#define statsTabby	1804
#define statsGolf	1805
#define statsAces	1806
#define statsCalc	1807
#define statsYukon	1808
#define statsSpiderette	1809
#define statsEight	1810
#define statsCanfield	1811
#define statsVegas	1812
#define statsFreecell	1813
#define statsWish	1814

#define bitmapSuitBase		5000
#define bitmapClubSuit		5000
#define bitmapDiamondSuit	5001
#define bitmapHeartSuit		5002
#define bitmapSpadeSuit		5003

#define bitmapRankBase		5100
#define bitmapRankA		5101
#define bitmapRank2		5102
#define bitmapRank3		5103
#define bitmapRank4		5104
#define bitmapRank5		5105
#define bitmapRank6		5106
#define bitmapRank7		5107
#define bitmapRank8		5108
#define bitmapRank9		5109
#define bitmapRank10		5110
#define bitmapRankJ		5111
#define bitmapRankQ		5112
#define bitmapRankK		5113
