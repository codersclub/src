/*
 * $Id: freecell.c,v 1.1 1999/05/11 07:08:21 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define FreecellDeck	0
#define FreecellTemp	1
#define FreecellNtemp	4
#define FreecellLtemp	(FreecellTemp + FreecellNtemp - 1)
#define FreecellPile	(FreecellLtemp + 1)
#define FreecellNpile	4
#define FreecellLpile	(FreecellPile + FreecellNpile - 1)
#define FreecellTable	(FreecellLpile + 1)
#define FreecellNtable	8
#define FreecellLtable	(FreecellTable + FreecellNtable - 1)
#define FreecellNstack	(FreecellLtable + 1)

CardSetupType	FreecellSetup[] =  {
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayNone, False, False, 0, CardStartDown },

    { { 0, 0 }, { 0, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 1, 0 }, { 1, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 2, 0 }, { 2, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },
    { { 3, 0 }, { 3, 0 }, CardBlank, CardDisplayTop, False, False, 0, CardStartUp },

    { { 4, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 0 }, { 5, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 6, 0 }, { 6, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 7, 0 }, { 7, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayAll, False, True, 7, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayAll, False, True, 7, CardStartUp },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayAll, False, True, 7, CardStartUp },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayAll, False, True, 7, CardStartUp },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, True, 6, CardStartUp },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayAll, False, True, 6, CardStartUp },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayAll, False, True, 6, CardStartUp },
    { { 7, 1 }, { 7, 1 }, CardNone, CardDisplayAll, False, True, 6, CardStartUp },
};

static int
FreecellCountTemp (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    int		    nempty = 0;

    for (stack = FreecellTemp; stack <= FreecellLtemp; stack++)
    {
	sp = CardStackPtr (stack);
	if (sp->last == NullIndex)
	    nempty++;
    }
    return nempty;
}

static CardBool
FreecellSelectTable (CardStackIndex stack,
		     CardIndex	    *first,
		     CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    CardType	    *cp;
    int		    nempty = FreecellCountTemp ();
    int		    nstack = 0;

    card = sp->last;
    *first = card;
    while (card != NullIndex)
    {
	nstack++;
	if (nstack > nempty)
	    break;
	cp = CardPtr (card);
	if (cp->prev == NullIndex)
	    break;
	if (!CardIsInAlternatingSuitOrder (card, cp->prev))
	    break;
	card = cp->prev;
    }
    *last = card;
    return True;
}

static CardProgressType
FreecellCheckTable (CardStackIndex    src, 
		  CardStackIndex    dst,
		  CardIndex	    card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (CardIsInAlternatingSuitOrder (card, dp->last))
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
FreecellCheckEmptyTable (CardStackIndex	src,
		       CardStackIndex	dst,
		       CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressSome;
    return CardProgressCant;
}

static CardProgressType
FreecellCheckPile (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == 1)
	    return CardProgressSome;
    }
    else
    {
	if (CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
FreecellCheckTemp (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
	return CardProgressNone;
    return CardProgressCant;
}

CardMoveType FreecellMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	{ FreecellPile, FreecellLpile },
	CardMoveAuto,
	0,
	FreecellCheckPile,
	0,
    },
    /* 1    Move card from temp to pile */
    {	"temp to pile",
	{ FreecellTemp, FreecellLtemp },
	{ FreecellTemp, FreecellLtemp },
	{ FreecellPile, FreecellLpile },
	CardMoveAuto,
	0,
	FreecellCheckPile,
	0,
    },
    /* 2    Move card from table to table */
    {	"table to table",
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	CardMoveHelpful,
	FreecellSelectTable,
	FreecellCheckTable,
	0,
    },
    /* 3    Move card from table to empty table */
    {	"table to empty table",
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	CardMoveHelpful,
	FreecellSelectTable,
	FreecellCheckEmptyTable,
	0,
    },
    /* 4    Move card from temp to table */
    {	"temp to table",
	{ FreecellTemp, FreecellLtemp },
	{ FreecellTemp, FreecellLtemp },
	{ FreecellTable, FreecellLtable },
	CardMoveHelpful,
	0,
	FreecellCheckTable,
	0,
    },
    /* 5    Move card from temp to table */
    {	"temp to empty table",
	{ FreecellTemp, FreecellLtemp },
	{ FreecellTemp, FreecellLtemp },
	{ FreecellTable, FreecellLtable },
	CardMoveHelpful,
	0,
	FreecellCheckEmptyTable,
	0,
    },
    /* 6    Move card from table to temp */
    {	"table to temp",
	{ FreecellTable, FreecellLtable },
	{ FreecellTable, FreecellLtable },
	{ FreecellTemp, FreecellLtemp },
	CardMoveHelpful,
	0,
	FreecellCheckTemp,
	0,
    },
    /* 7    Move card from pile to table */
    {	"pile to table",
	{ FreecellPile, FreecellLpile },
	{ FreecellPile, FreecellLpile },
	{ FreecellTable, FreecellLtable },
	CardMoveNoHelp,
	0,
	FreecellCheckTable,
	0,
    },
    /* 8    Move card from pile to empty table */
    {	"pile to empty table",
	{ FreecellPile, FreecellLpile },
	{ FreecellPile, FreecellLpile },
	{ FreecellTable, FreecellLtable },
	CardMoveNoHelp,
	0,
	FreecellCheckEmptyTable,
	0,
    },
};

#define NMOVES	(sizeof (FreecellMoves) / sizeof (FreecellMoves[0]))

static CardBool
FreecellNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = FreecellPile; stack <= FreecellLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != KING)
	    return False;
    }
    return True;
}

RulesType   freecellGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, FreecellNstack,
    FreecellNormalize,
    0,
    0,
    FreecellSetup,
    NMOVES,
    FreecellMoves
};
