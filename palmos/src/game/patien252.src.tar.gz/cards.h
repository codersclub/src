/*
 * $Id: cards.h,v 1.14 1999/10/24 21:15:12 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#define CMD_LINE_BUILD
#define EMULATION_LEVEL	    EMULATION_NONE
#define MEMORY_FORCE_LOCK   MEMORY_FORCE_LOCK_OFF

#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <stdio.h>

typedef int		PatI;
typedef unsigned int	PatUI;
typedef long		PatL;
typedef unsigned long	PatUL;
typedef short		PatS;
typedef unsigned short	PatUS;

#define MAX_GAMES   32

#define JACK	11
#define QUEEN	12
#define KING	13
#define ACE	14

#define CLUB	    0x00
#define DIAMOND	    0x10
#define HEART	    0x20
#define SPADE	    0x30
#define BACK	    0x40
#define EMPTY	    0x50
#define NONE	    0x60
#define BLANK	    0x70
#define TRUMP	    0x80
#define NextSuit(s) ((s) + 0x10)

#define Suit(c)	    ((c) & 0x70)
#define Trump(c)    ((c) & TRUMP)
#define Rank(c)	    ((c) & 0x0f)
#define MakeCard(t,s,r)	((t) | (s) | (r))

typedef unsigned char	Card;
typedef unsigned char	CardIndex;
typedef unsigned char	CardStackIndex;
typedef unsigned char	CardDisplay;
typedef unsigned char	CardHistoryKind;
typedef unsigned char	CardBool;

#ifndef True
#define True 1
#define False 0
#endif

#define	CardDisplayTop	    0
#define CardDisplayBottom   1
#define CardDisplayAll	    2
#define CardDisplaySome	    3
#define CardDisplayNone	    4
#define CardDisplayPack	    5
#define CardDisplayTopCount 6

#define NullIndex	0xff

#define CardFaceUp	1
#define CardFaceDown	0

#define CardStackDeck	0

#define CardShowNone	0
#define CardShowBack	1
#define CardShowPack	2
#define CardShowFace	3

typedef struct {
    CardIndex	    next, prev;
    Card	    card;
    unsigned int    face : 1;
    unsigned int    show : 2;
} CardType;

typedef struct {
    PatS	    x, y;
} PatCoord;

typedef struct {
    PatCoord	    pos;
    CardIndex	    first, last;
    Card	    empty;
    unsigned char   face_up;
    unsigned char   back_up;
    unsigned char   pack_up;
    unsigned int    display : 3;
    unsigned int    dirty : 1;
    unsigned int    horizontal : 1;
    unsigned int    select_card : 1;
    signed char	    face_off;
    signed char	    back_off;
    signed char	    pack_off;
} CardStackType;

extern CardBool (*CurrentPackFunction(void)) (CardIndex, CardIndex);

#define CardHistoryNone	    0
#define CardHistoryMove	    1
#define CardHistoryTurn	    2
#define CardHistoryShuffle  3
#define CardHistoryCallback 4

typedef struct _history {
    PatL    	    serial;
    CardHistoryKind kind;
    union {
	struct {
	    CardStackIndex  stack;
	    CardIndex	    card;
	    unsigned int    face : 1;
	} turn;
	struct {
	    CardStackIndex  source;
	    CardStackIndex  dest;
	    CardIndex	    before;
	    CardIndex	    first;
	    CardIndex	    last;
	} move;
	struct {
	    CardStackIndex  stack;
	    PatL    	    seed;
	} shuffle;
#if 0
    /* doesn't work through application restart */
	struct {
	    void    	    (*func)(PatL closure);
	    PatL    	    closure;
	} callback;
#endif
    } u;
} CardHistoryType;

typedef struct _hint {
    CardStackIndex  stack;
    PatS	    pos;
} CardHintType;

#define MAX_CARDS	104
#define MAX_STACKS	53
#define MAX_HISTORY	1024
#define MAX_HINT	5
#define HISTORY_CHUNK	32
#define HISTORY_CHUNKS	(MAX_HISTORY / HISTORY_CHUNK)

typedef struct _historyChunk {
    CardHistoryType history[HISTORY_CHUNK];
    PatI	    historyTop;
} HistoryChunkType;

typedef struct _gameStat {
    PatUL	    won;
    PatUL	    lost;
} GameStatType;

typedef struct _game {
    CardType	    deck[MAX_CARDS];
    CardStackType   stacks[MAX_STACKS];
    CardHintType    hints[MAX_HINT];
    PatS	    nhint;
    CardIndex	    ncards;
    CardStackIndex  nstacks;
    PatL    	    historySerial;
    PatS	    historyTop;
    CardBool	    playing;
    CardBool	    queryMode;
    CardBool	    queryDirty;
    CardBool	    alwaysAuto;
    CardBool	    alwaysDirty;
    CardBool	    leftHanded;
    PatS	    gameKind;
    PatS	    gameSeed;
    PatS	    randomSeed;
    CardStackIndex  srcStack;
    CardIndex	    srcCard;
    HistoryChunkType	historyChunk;
    ULong	    historyID[HISTORY_CHUNKS];
    GameStatType    stats[MAX_GAMES];
} GameType;

extern GameType	    game;

#ifdef DEBUG
#define CardPtr(i)	    ((i) == NullIndex ? (ErrDisplay ("CardPtr"), \
						 (CardType *) 0) : &(game.deck[i]))
#define CardStackPtr(i)  ((i) == NullIndex ? (ErrDisplay ("CardStackPtr"), \
						 (CardStackType *) 0) : &(game.stacks[i]))
#define CardHintPtr(i)   ((i) == NullIndex ? (ErrDisplay ("CardHintPtr"), \
						 (CardHintType *) 0) : &(game.hints[i]))
#else
#define CardPtr(i)	    ((i) == NullIndex ? (CardType *) 0 : &(game.deck[i]))
#define CardStackPtr(i)  ((i) == NullIndex ? (CardStackType *) 0 : (&game.stacks[i]))
#define CardHintPtr(i)   ((i) == NullIndex ? (CardHintType *) 0 : &(game.hints[i]))
#endif

typedef struct {
    CardStackIndex  first, last;
} CardStackRangeType;

typedef enum { 
    CardProgressCant, 
    CardProgressBack, 
    CardProgressNone, 
    CardProgressSome 
} CardProgressType;

typedef CardBool	(*CardSelectStackType) (CardStackIndex stack,
					CardIndex *first, CardIndex *last);
typedef CardProgressType (*CardCheckStackType) (CardStackIndex src, 
				       CardStackIndex dst, CardIndex card);

typedef void	(*CardMoveStackType) (CardStackIndex src,
				      CardStackIndex dst, CardIndex card);

typedef enum { CardMoveNoHelp, CardMoveHelpful, CardMoveAuto, CardMoveHint } CardMoveKind;

typedef struct {
    char		*name;
    CardStackRangeType	hit;
    CardStackRangeType	source;
    CardStackRangeType	dest;
    CardMoveKind	kind;
    CardSelectStackType	SelectStack;
    CardCheckStackType	CheckStack;
    CardMoveStackType	MoveStack;
} CardMoveType;

typedef enum { CardStartDown, CardStartUp, CardStartLastUp } CardStartType;

typedef struct {
    PatCoord		right, left;
    Card		empty;
    PatS    		display;
    CardBool		horizontal;
    CardBool		select_card;
    PatS    		ndeal;
    CardStartType	start;
} CardSetupType;

#define CardEmpty   MakeCard(0, EMPTY, 0)
#define CardNone    MakeCard(0, NONE, 0)
#define CardBlank   MakeCard(0, BLANK, 0)

typedef struct {
    Card		first, last;
    PatS    		ndecks;
    PatS    		nstacks;
    CardBool		(*Normalize) (void);
    void		(*Initialize) (void);
    CardBool		(*Pack) (CardIndex, CardIndex);
    CardSetupType	*setup;
    PatS    		nmoves;
    CardMoveType	*moves;
} RulesType;

extern void Watch (char *);
extern void WatchI (char *, PatL);

void	CardSetShoulds (CardStackIndex stack);
void	CardRedisplay (void);
void	CardDrawHighlight (CardStackIndex stack, PatI pos);
void	CardUndrawHighlight (CardStackIndex stack, PatI pos);
void	CardShowHint (CardStackIndex stack, PatI pos);
void	CardShowMoveHint (CardStackIndex, 
			  CardStackIndex, CardIndex, CardIndex);
void	CardUnshowHint (void);
CardBool	CardHit (PatI, PatI, 
			 CardStackIndex *, CardIndex *,
			 PatI *,
			 PatI *);
CardBool	CardStartAnimate (PatI x, PatI y, CardStackIndex, CardIndex);
void	CardStopAnimate (void);
void	CardMoveAnimate (PatI x, PatI y);
void	CardShuffle (CardStackIndex stack, CardBool remember);
void	CardMakeDeck (Card first, Card last, PatI ndecks);
void	CardInitStack (CardStackIndex stack,
		       PatS	x,
		       PatS	y,
		       Card	empty,
		       PatS	display,
		       CardBool	horizontal,
		       CardBool	select_card);
CardBool	CardIsInOrder (CardIndex a, CardIndex b);
CardBool	CardIsInSuitOrder (CardIndex a, CardIndex b);
CardBool	IsAlternateSuit (Card a, Card b);
CardIndex   CardInSuitOrder (CardIndex card);
CardIndex   CardInOrder (CardIndex card);
CardIndex   CardInReverseSuitOrder (CardIndex card);
CardIndex   CardInReverseOrder (CardIndex card);
CardBool	    CardIsInAlternatingSuitOrder (CardIndex a, CardIndex b);
CardIndex   CardInAlternatingSuitOrder (CardIndex card);
CardIndex   CardInReverseAlternatingSuitOrder (CardIndex card);
void	    CardTurn (CardStackIndex stack, CardIndex card, CardBool face, CardBool remember);
void	    CardPlay (RulesType		*rules, 
		      CardStackIndex	src,
		      CardStackIndex	dst,
		      CardIndex		card);
void	    CardAutoPlay (RulesType *rules);
void	    CardHint (RulesType		*rules);
void	    CardMoveCard (CardStackIndex    from_stack, 
			  CardIndex	    first_card, 
			  CardIndex	    last_card, 
			  CardStackIndex    to_stack, 
			  CardIndex	    to_card,
			  CardBool	    remember);
void	    CardMove (CardStackIndex    from_stack,
		      CardIndex		from_card, 
		      CardStackIndex    to_stack, 
		      CardBool		remember);
void	    CardInitHistory (void);
#if 0
/* Can't work through application restart */
void	    CardRecordHistoryCallback (void	(*func) (PatL closure),
				       PatL	closure);
#endif
CardBool	    CardUndo (void);
PatL	    CardNextHistory (void);
void	    CardInit (RulesType *rules);
void
CardSetHanded (RulesType    *rule,
	       CardBool	    leftHanded);
void	    CardFreezeHistory (void);

void
DeleteUndoDB (void);
    
void
CardLabelInit (void);
    
void
CardLabelFini (void);

PatL	    Random (PatL);
void	    SRandom (PatL);

extern RulesType    golfGame;
extern RulesType    klondikeGame;
extern RulesType    towersGame;
extern RulesType    tabbyGame;
extern RulesType    spiderGame;
extern RulesType    montanaGame;
extern RulesType    acesGame;
extern RulesType    calcGame;
extern RulesType    yukonGame;
extern RulesType    spideretteGame;
extern RulesType    eightGame;
extern RulesType    canfieldGame;
extern RulesType    vegasGame;
extern RulesType    freecellGame;
extern RulesType    wishGame;

extern DmOpenRef    undoDB;
