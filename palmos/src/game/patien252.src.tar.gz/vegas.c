/*
 * $Id: vegas.c,v 1.2 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#include "klondike.h"

CardBool
VegasSelectDeck (CardStackIndex stack,
		 CardIndex	*first,
		 CardIndex	*last)
{
    CardStackType   *sp = CardStackPtr (stack);
    *first = *last = sp->last;
    return True;
}

CardMoveType VegasMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	{ KlondikePile, KlondikeLpile },
	CardMoveAuto,
	0,
	KlondikeCheckPile,
	0,
    },
    /* 1    Move card from discard to pile */
    {	"discard to pile",
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikePile, KlondikeLpile },
	CardMoveAuto,
	0,
	KlondikeCheckPile,
	0,
    },
    /* 2    Move card from table to table */
    {	"table to table",
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	{ KlondikeTable, KlondikeLtable },
	CardMoveHelpful,
	KlondikeSelectStack,
	KlondikeCheckTable,
	0,
    },
    /* 3    Move card from discard to table */
    {	"discard to table",
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeDiscard, KlondikeDiscard },
	{ KlondikeTable, KlondikeLtable },
	CardMoveHelpful,
	0,
	KlondikeCheckTable,
	0,
    },
    /* 4    Deal next card */
    {	"deal",
	{ KlondikeDeck, KlondikeDeck },
	{ KlondikeDeck, KlondikeDeck },
	{ KlondikeDiscard, KlondikeDiscard },
	CardMoveHelpful,
	VegasSelectDeck,
	0,
	KlondikeMoveDeal,
    },
    /* 5    Move card from pile to table */
    {	"pile to table",
	{ KlondikePile, KlondikeLpile },
	{ KlondikePile, KlondikeLpile },
	{ KlondikeTable, KlondikeLtable },
	CardMoveNoHelp,
	0,
	KlondikeCheckTable,
	0,
    },
};

#define NMOVES	(sizeof (VegasMoves) / sizeof (VegasMoves[0]))

RulesType   vegasGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, KlondikeNstack,
    KlondikeNormalize,
    0,
    0,
    KlondikeSetup,
    NMOVES,
    VegasMoves
};
