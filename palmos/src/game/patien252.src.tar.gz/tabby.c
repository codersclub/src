/*
 * $Id: tabby.c,v 1.6 1998/08/08 06:17:38 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define TabbyDeck	0
#define TabbyPile	(TabbyDeck + 1)
#define TabbyNpile	4
#define TabbyLpile	(TabbyPile + TabbyNpile - 1)
#define TabbyTable	(TabbyLpile + 1)
#define TabbyNtable	4
#define TabbyLtable	(TabbyTable + TabbyNtable - 1)
#define TabbyTail	(TabbyLtable + 1)
#define TabbyNstack	(TabbyTail + 1)

CardSetupType	TabbySetup[] =  {
    { { 5, 0 }, { 0, 0 }, CardEmpty, CardDisplayTopCount, False, False, 0, CardStartDown },
    
    { { 5, 1 }, { 0, 1 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 2 }, { 0, 2 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 3 }, { 0, 3 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 5, 4 }, { 0, 4 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    
    { { 0, 0 }, { 2, 0 }, CardNone, CardDisplayPack, False, False, 1, CardStartUp },
    { { 1, 0 }, { 3, 0 }, CardNone, CardDisplayPack, False, False, 1, CardStartUp },
    { { 2, 0 }, { 4, 0 }, CardNone, CardDisplayPack, False, False, 1, CardStartUp },
    { { 3, 0 }, { 5, 0 }, CardNone, CardDisplayPack, False, False, 1, CardStartUp },

    { { 4, 0 }, { 1, 0 }, CardBlank, CardDisplayPack, False, False, 0, CardStartDown },
};
    
static CardBool
TabbySelectStack (CardStackIndex    stack,
		  CardIndex	    *first,
		  CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    
    *first = sp->last;
    *last = CardInReverseOrder (sp->last);
    return True;
}

static CardProgressType
TabbyCheckTable (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last != NullIndex)
    {
	if (CardIsInOrder (card, dp->last))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
TabbyCheckEmptyTable (CardStackIndex	src, 
		      CardStackIndex	dst,
		      CardIndex		card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last == NullIndex)
    {
	if (CardPtr (card)->prev == NullIndex)
	    return CardProgressNone;
        return CardProgressSome;
    }
    return CardProgressCant;
}

static CardProgressType
TabbyCheckPile (CardStackIndex	src, 
		CardStackIndex	dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);
    CardStackType   *sp = CardStackPtr (src);

    if (dp->last != NullIndex)
	return CardProgressCant;
    if (Rank (CardPtr (card)->card) != KING)
	return CardProgressCant;
    if (Rank (CardPtr (sp->last)->card) != 1)
	return CardProgressCant;
    return CardProgressSome;
}
			
static CardBool
TabbySelectDeck (CardStackIndex	stack,
		 CardIndex	*first,
		 CardIndex	*last)
{
    CardStackType   *sp = CardStackPtr (stack);
    
    *first = *last = sp->last;
    return True;
}

static CardBool
TabbySelectTail (CardStackIndex stack,
		 CardIndex	*first,
		 CardIndex	*last)
{
    CardStackType   *sp = CardStackPtr (stack);
    
    *first = *last = sp->first;
    return True;
}

static CardProgressType
TabbyCheckTail (CardStackIndex  src, 
		CardStackIndex  dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (dp->last != NullIndex)
	return CardProgressCant;
    return CardProgressSome;
}

static void
TabbyMoveDeal (CardStackIndex   src,
	       CardStackIndex   dst,
	       CardIndex	last)
{
    CardStackIndex  t;
    
    for (t = TabbyTable; t <= TabbyLtable; t++)
    {
	if (CardStackPtr (TabbyDeck)->last == NullIndex)
	    return;
	CardMove (TabbyDeck, CardStackPtr (TabbyDeck)->last,
		  t, True);
	CardTurn (t,
	    	  CardStackPtr (t)->last, 
	    	  True, True);
    }
}

CardMoveType TabbyMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	{ TabbyPile, TabbyLpile },
	CardMoveAuto,
	TabbySelectStack,
	TabbyCheckPile,
	0,
    },
    /* 1    Move card from tail to pile */
    {	"tail to pile",
	{ TabbyTail, TabbyTail },
	{ TabbyTail, TabbyTail },
	{ TabbyPile, TabbyLpile },
	CardMoveAuto,
	TabbySelectTail,
	TabbyCheckPile,
	0,
    },
    /* 2    Move card from tail to table */
    {	"tail to table",
	{ TabbyTail, TabbyTail },
	{ TabbyTail, TabbyTail },
	{ TabbyTable, TabbyLtable },
	CardMoveHelpful,
	TabbySelectTail,
	TabbyCheckTable,
	0,
    },
    /* 3    Move card from tail to empty table */
    {	"tail to empty table",
	{ TabbyTail, TabbyTail },
	{ TabbyTail, TabbyTail },
	{ TabbyTable, TabbyLtable },
	CardMoveHelpful,
	TabbySelectTail,
	TabbyCheckEmptyTable,
	0,
    },
    /* 4    Move card from table to table */
    {	"table to table",
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	CardMoveHelpful,
	TabbySelectStack,
	TabbyCheckTable,
	0,
    },
    /* 5    Move card from table to empty table */
    {	"table to empty table",
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	CardMoveHelpful,
	TabbySelectStack,
	TabbyCheckEmptyTable,
	0,
    },
    /* 6    Move card from table to tail */
    {	"table to tail",
	{ TabbyTable, TabbyLtable },
	{ TabbyTable, TabbyLtable },
	{ TabbyTail, TabbyTail,},
	CardMoveHelpful,
	TabbySelectStack,
	TabbyCheckTail,
	0,
    },
    /* 7    Deal next four cards */
    {	"deal",
	{ TabbyDeck, TabbyDeck },
	{ TabbyDeck, TabbyDeck },
	{ TabbyTable, TabbyLtable },
	CardMoveHelpful,
	TabbySelectDeck,
	0,
	TabbyMoveDeal,
    },
};

#define NMOVES	(sizeof (TabbyMoves) / sizeof (TabbyMoves[0]))

static CardBool
TabbyNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;

    for (stack = TabbyPile; stack <= TabbyLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
    }
    return True;
}

RulesType   tabbyGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, TabbyNstack,
    TabbyNormalize,
    0,
    CardIsInOrder,
    TabbySetup,
    NMOVES,
    TabbyMoves
};
