/*
 * $Id: yukon.c,v 1.5 1998/08/07 17:12:20 keithp Exp $
 *
 * Copyright � 1998 Keith Packard
 *
 * Permission to use, copy, modify, distribute, and sell this software and its
 * documentation for any purpose is hereby granted without fee, provided that
 * the above copyright notice appear in all copies and that both that
 * copyright notice and this permission notice appear in supporting
 * documentation, and that the name of Keith Packard not be used in
 * advertising or publicity pertaining to distribution of the software without
 * specific, written prior permission.  Keith Packard makes no
 * representations about the suitability of this software for any purpose.  It
 * is provided "as is" without express or implied warranty.
 *
 * KEITH PACKARD DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
 * INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN NO
 * EVENT SHALL KEITH PACKARD BE LIABLE FOR ANY SPECIAL, INDIRECT OR
 * CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE,
 * DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER
 * TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
 * PERFORMANCE OF THIS SOFTWARE.
 */

#include "cards.h"

#define YukonDeck	0
#define YukonPile	(YukonDeck + 1)
#define YukonNpile	4
#define YukonLpile	(YukonPile + YukonNpile - 1)
#define YukonTable	(YukonPile + YukonNpile)
#define YukonNtable	7
#define YukonLtable	(YukonTable + YukonNtable - 1)
#define YukonNstack	(YukonTable + YukonNtable)

CardSetupType	YukonSetup[] =  {
    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayNone, False, False, 0, CardStartDown },

    { { 0, 0 }, { 0, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 2, 0 }, { 2, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 4, 0 }, { 4, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },
    { { 6, 0 }, { 6, 0 }, CardEmpty, CardDisplayTop, False, False, 0, CardStartDown },

    { { 0, 1 }, { 0, 1 }, CardNone, CardDisplayAll, False, True, 1, CardStartUp },
    { { 1, 1 }, { 1, 1 }, CardNone, CardDisplayAll, False, True, 6, CardStartDown },
    { { 2, 1 }, { 2, 1 }, CardNone, CardDisplayAll, False, True, 7, CardStartDown },
    { { 3, 1 }, { 3, 1 }, CardNone, CardDisplayAll, False, True, 8, CardStartDown },
    { { 4, 1 }, { 4, 1 }, CardNone, CardDisplayAll, False, True, 9, CardStartDown },
    { { 5, 1 }, { 5, 1 }, CardNone, CardDisplayAll, False, True, 10, CardStartDown },
    { { 6, 1 }, { 6, 1 }, CardNone, CardDisplayAll, False, True, 11, CardStartDown },
};

static void
YukonInitialize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardType	    *cp;
    CardIndex	    card;
    int		    i;

    for (stack = YukonTable + 1; stack <= YukonLtable; stack++)
    {
	sp = CardStackPtr (stack);
	for (i = 0, card = sp->last; i < 5; i++, card = cp->prev)
	{
	    cp = CardPtr (card);
	    CardTurn (stack, card, True, False);
	}
    }
}

static CardBool
YukonSelectStack (CardStackIndex    stack,
		  CardIndex	    *first,
		  CardIndex	    *last)
{
    CardStackType   *sp = CardStackPtr (stack);
    CardIndex	    card;
    CardType	    *cp;

    *first = sp->last;
    for (card = sp->last; card != NullIndex; card = cp->prev)
    {
	cp = CardPtr (card);
	if (cp->face)
	    *last = card;
	else
	    break;
    }
    return True;
}

static CardProgressType
YukonCheckTable (CardStackIndex src, 
		 CardStackIndex dst,
		 CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);

    if (src == dst)
	return CardProgressCant;
    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (Rank (CardPtr (card)->card) == KING)
	{
	    if (YukonPile <= src && src <= YukonLpile)
		return CardProgressBack;
	    if (CardPtr (card)->prev == NullIndex)
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    else
    {
	if (CardIsInAlternatingSuitOrder (card, dp->last))
	{
	    if (YukonPile <= src && src <= YukonLpile)
		return CardProgressBack;
	    if (CardIsInAlternatingSuitOrder (card,
					      CardPtr (card)->prev))
		return CardProgressNone;
	    return CardProgressSome;
	}
    }
    return CardProgressCant;
}

static CardProgressType
YukonCheckPile (CardStackIndex	src, 
		CardStackIndex	dst,
		CardIndex	card)
{
    CardStackType   *dp = CardStackPtr (dst);
    CardType	    *cp = CardPtr (card);

    if (!cp->face)
	return CardProgressCant;
    if (cp->next != NullIndex)
	return CardProgressCant;
    if (dp->last == NullIndex)
    {
	if (Rank (cp->card) == 1)
	    return CardProgressSome;
    }
    else
    {
	if (CardIsInSuitOrder (dp->last, card))
	    return CardProgressSome;
    }
    return CardProgressCant;
}

/*
 * Find a card that the indicated card can stack on top of
 */

static CardBool
YukonHintCard (CardStackIndex   card,
	       CardStackIndex   dst,
	       CardIndex	*dcardp)
{
    CardStackType   *dp = CardStackPtr (dst);
    CardIndex	    dcard;
    CardType	    *dc;
    CardType	    *sc;

    if (card == NullIndex)
	return NullIndex;
    sc = CardPtr (card);
    if (Rank (sc->card) == KING)
    {
	if (dp->last == NullIndex)
	{
	    *dcardp = NullIndex;
	    return True;
	}
    }
    else
    {
	for (dcard = dp->last; dcard != NullIndex; dcard = dc->prev)
	{
	    dc = CardPtr (dcard);
	    if (CardIsInAlternatingSuitOrder (card, dcard))
	    {
		*dcardp = dcard;
		return True;
	    }
	}
    }
    return False;
}

static CardProgressType
YukonCheckHint (CardStackIndex  src,
		CardStackIndex  dst,
		CardIndex	card)
{
    CardIndex	    dcard;

    if (!CardPtr (card)->face)
	return CardProgressCant;
    if (src != dst && YukonHintCard (card, dst, &dcard))
    {
	if (dcard == NullIndex)
	{
	    CardType	*sc = CardPtr (card);

	    if (sc->prev == NullIndex)
		return CardProgressNone;
	    else
		return CardProgressSome;
	}
	else
	{
	    CardType	*dc = CardPtr (dcard);
	    
	    if (dc->prev != NullIndex &&
		CardIsInAlternatingSuitOrder (dcard, dc->prev))
	    {
		return CardProgressNone;
	    }
	    else
		return CardProgressSome;
	}
    }
    return CardProgressCant;
}

static void
YukonMoveHint (CardStackIndex	    src,
	       CardStackIndex	    dst,
	       CardIndex	    card)
{
    CardIndex	    dcard;
    
    if (src != dst && YukonHintCard (card, dst, &dcard))
	CardShowMoveHint (src, dst, card, dcard);
}

CardMoveType YukonMoves[] = {
    /* 0    Move card from table to pile */
    {	"table to pile",
	{ YukonTable, YukonLtable },
	{ YukonTable, YukonLtable },
	{ YukonPile, YukonLpile },
	CardMoveAuto,
	0,
	YukonCheckPile,
	0,
    },
    /* 1    Move card from table to table */
    {	"table to table",
	{ YukonTable, YukonLtable },
	{ YukonTable, YukonLtable },
	{ YukonTable, YukonLtable },
	CardMoveHelpful,
	YukonSelectStack,
	YukonCheckTable,
	0,
    },
    /* 2    Move card from pile to table */
    {	"pile to table",
	{ YukonPile, YukonLpile },
	{ YukonPile, YukonLpile },
	{ YukonTable, YukonLtable },
	CardMoveNoHelp,
	0,
	YukonCheckTable,
	0,
    },
    /* 3    Hint */
    {	"hint",
	{ YukonTable, YukonLtable },
	{ YukonTable, YukonLtable },
	{ YukonTable, YukonLtable },
	CardMoveHint,
	0,
	YukonCheckHint,
	YukonMoveHint,
    },
};

#define NMOVES	(sizeof (YukonMoves) / sizeof (YukonMoves[0]))

static CardBool
YukonNormalize (void)
{
    CardStackIndex  stack;
    CardStackType   *sp;
    CardIndex	    card;
    CardType	    *cp;

    for (stack = YukonTable; stack <= YukonLtable; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card != NullIndex)
	{
	    cp = CardPtr (card);
	    if (!cp->face)
		CardTurn (stack, card, True, True);
	}
    }
    for (stack = YukonPile; stack <= YukonLpile; stack++)
    {
	sp = CardStackPtr (stack);
	card = sp->last;
	if (card == NullIndex)
	    return False;
	cp = CardPtr (card);
	if (Rank (cp->card) != KING)
	    return False;
    }
    return True;
}

RulesType   yukonGame = {
    MakeCard (0, CLUB, 1), MakeCard (0, SPADE, KING), 1, YukonNstack,
    YukonNormalize,
    YukonInitialize,
    0,
    YukonSetup,
    NMOVES,
    YukonMoves
};
