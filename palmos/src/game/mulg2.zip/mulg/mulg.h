#include "level.h"

/*

*/

#define MAX_SPRITES 1  /* only players marble */
#define MARBLE 0

#define CREATOR     0x4d756c67 // 'Mulg'
#define DB_TYPE     0x4c65766c // 'Levl'
#define DB_TYPE_F   0x4c657646 // 'LevF' level databases for version IIf and up
#define DB_TYPE_N   0x4c65764e // 'LevN' level databases for version IIn and up
#define DB_SCORE    0x53636f72 // 'Scor'

#define MAX_WIDTH  37
#define MAX_HEIGHT 33

#ifndef IN_MAKELEVEL
#define ERROR(a) 

#define ABS(a)  ((a>0)?a:-a)
#define SGN(a)  ((a>0)?1:-1)

typedef struct {
  int   width;
  int   height;
  short *data;
} LEVEL;

#define DEBUG

#ifdef DEBUG
#define DEBUG_PORT 0x30000000
#define DEBUG_MSG(format, args...) { char tmp[128]; int xyz; StrPrintF(tmp, format, ## args); for(xyz=0;xyz<StrLen(tmp);xyz++) *((char*)DEBUG_PORT)=tmp[xyz]; }
#else
#define DEBUG_MSG(format, args...)
#endif

#endif
