/* $Id: evolution.h,v 1.2 2000/06/22 02:03:36 bodo Exp $ */
/*
 * This file is part of PalmK�mon.
 *
 * Copyright (C) 2000 Bodo Bellut
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Authors:  Bodo Bellut (bodo@bellut.net)
 */

UShort evolutions[] = {
    0,			/* index 0 not used */
    3, 0, 0,		/*   1,   2,   3 */
    3, 0, 0,		/*   4,   5,   6 */
    3, 0, 0,		/*   7,   8,   9 */
    3, 0, 0,		/*  10,  11,  12 */
    3, 0, 0,		/*  13,  14,  15 */
    3, 0, 0,		/*  16,  17,  18 */
    2, 0,		/*  19,  20 */
    2, 0,		/*  21,  22 */
    2, 0,		/*  23,  24 */
    2, 0,		/*  25,  26 */
    2, 0,		/*  27,  28 */
    3, 0, 0,		/*  29,  30,  31 */
    3, 0, 0,		/*  32,  33,  34 */
    2, 0,		/*  35,  36 */
    2, 0,		/*  37,  38 */
    2, 0,		/*  39,  40 */
    2, 0,		/*  41,  42 */
    3, 0, 0,		/*  43,  44,  45 */
    2, 0,		/*  46,  47 */
    2, 0,		/*  48,  49 */
    2, 0,		/*  50,  51 */
    2, 0,		/*  52,  53 */
    2, 0,		/*  54,  55 */
    2, 0,		/*  56,  57 */
    2, 0,		/*  58,  59 */
    3, 0, 0,		/*  60,  61,  62 */
    3, 0, 0,		/*  63,  64,  65 */
    3, 0, 0,		/*  66,  67,  68 */
    3, 0, 0,		/*  69,  70,  71 */
    2, 0,		/*  72,  73 */
    3, 0, 0,		/*  74,  75,  76 */
    2, 0,		/*  77,  78 */
    2, 0,		/*  79,  80 */
    2, 0,		/*  81,  82 */
    1,			/*  83 */
    2, 0,		/*  84,  85 */
    2, 0,		/*  86,  87 */
    2, 0,		/*  88,  89 */
    2, 0,		/*  90,  91 */
    3, 0, 0,		/*  92,  93,  94 */
    1,			/*  95 */
    2, 0,		/*  96,  97 */
    2, 0,		/*  98,  99 */
    2, 0,		/* 100, 101 */
    2, 0,		/* 102, 103 */
    2, 0,		/* 104, 105 */
    1,			/* 106 */
    1,			/* 107 */
    1,			/* 108 */
    2, 0,		/* 109, 110 */
    2, 0,		/* 111, 112 */
    1,			/* 113 */
    1,			/* 114 */
    1,			/* 115 */
    2, 0,		/* 116, 117 */
    2, 0,		/* 118, 119 */
    2, 0,		/* 120, 121 */
    1,			/* 122 */
    1,			/* 123 */
    1,			/* 124 */
    1,			/* 125 */
    1,			/* 126 */
    1,			/* 127 */
    1,			/* 128 */
    2, 0,		/* 129, 130 */
    1,			/* 131 */
    1,			/* 132 */
    4, 0, 0, 0,		/* 133, 134, 135, 136 */
    1,			/* 137 */
    2, 0, 		/* 138, 139 */
    2, 0,		/* 140, 141 */
    1,			/* 142 */
    1,			/* 143 */
    1,			/* 144 */
    1,			/* 145 */
    1,			/* 146 */
    3, 0, 0,		/* 147, 148, 149 */
    1,			/* 150 */
    1			/* 151 */
};
