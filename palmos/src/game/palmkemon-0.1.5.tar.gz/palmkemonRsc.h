//
// $Id: palmkemonRsc.h,v 1.9 2000/06/29 19:46:44 bodo Exp $
//
// This file is part of PalmK�mon.
//
// Copyright (C) 2000 Bodo Bellut
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//   Authors:  Bodo Bellut (bodo@bellut.net)


#define MainForm 1000

#define lbName1 1000
#define lbName2 1001
#define lbNum   1002
#define pbStep1 2000
#define pbStep2 2001
#define pbStep3 2002
#define btHelp  3000
//#define btNote  3001
#define rpUp    4000
#define rpDown  4001
// -----------------------------
#define SearchForm 1001

#define flGoto   1000
#define flSearch 1001
#define btGoto   2000
#define btSearch 2001
#define btCancel 2002
//------------------------------
#define OptionsForm 1002

#define btOK    1000
#define ptLang1 2000
#define ptLang2 2001
#define liLang1 3000
#define liLang2 3001
//------------------------------
#define RangeAlert    1000
#define NotFoundAlert 1001
#define AboutAlert    1002
// #define DebugAlert    1003
//------------------------------
#define MainHelp    1000
#define OptionsHelp 1001

#define MainMenu    1000

#define mnAbout     1000
#define mnHelp      1001
#define mnOptions   1002
