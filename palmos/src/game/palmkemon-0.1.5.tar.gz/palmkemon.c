/* Main code for PalmKemon */

/* $Id: palmkemon.c,v 1.13 2000/06/29 19:44:13 bodo Exp $ */
/*
 * Copyright (C) 2000 Bodo Bellut
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 *   Authors:  Bodo Bellut (bodo@bellut.net)
 */

#include <Pilot.h>
#include "callback.h"

#include "palmkemonRsc.h"

#define GRAPHIC

#undef NOTEVIEW

#include "namesDE.h"
#include "namesEN.h"
#include "namesFR.h"
#include "namesJP.h"

#include "evolution.h"

#define BMPX 10
#define BMPY 45

typedef struct {
	Short version;
	Short lang1;
	Short lang2;
} PreferenceType;

/* globals */

Int currentNum = 1;
Char lastSearch[25];
Boolean SearchFormOpen = false;

PreferenceType prefs = { 1, 3, 1 };
PreferenceType newprefs;

Char **pokeNames1 = pokeNamesJP;
Char **pokeNames2 = pokeNamesEN;

#ifdef NOTEVIEW
DmOpenRef ExtraDB;
Boolean noteInverted = false;
FontID NoteFont = stdFont;
#endif

static void *GetObjectPtr(FormPtr frm, Word objID)
{
  return FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID));
}

#ifdef NOTEVIEW
static void *GetObjectPtr2(Word objID)
{
  FormPtr frm = FrmGetActiveForm();
  return GetObjectPtr(frm, objID);
}

static FrameType ButtonFrameToFrameType (ControlPtr pControl)
{
    switch (pControl->attr.frame)
    {
	case standardButtonFrame:
	    return roundFrame;
	case boldButtonFrame:
	    return boldRoundFrame;
	case rectangleButtonFrame:
	    return simpleFrame;
    }
    return noFrame;
}
#endif

static void SetPokeNames(void)
{
    switch(prefs.lang1) {
    case 0:
	pokeNames1 = pokeNamesDE;
	break;
    case 1:
	pokeNames1 = pokeNamesEN;
	break;
    case 2:
	pokeNames1 = pokeNamesFR;
	break;
    case 3:
	pokeNames1 = pokeNamesJP;
	break;
    default:
	pokeNames1 = NULL; /* shut up GCC */
	ErrFatalDisplay("lang1 index out of range");
    }

    switch(prefs.lang2) {
    case 0:
	pokeNames2 = pokeNamesDE;
	break;
    case 1:
	pokeNames2 = pokeNamesEN;
	break;
    case 2:
	pokeNames2 = pokeNamesFR;
	break;
    case 3:
	pokeNames2 = pokeNamesJP;
	break;
    default:
	pokeNames2 = NULL; /* shut up GCC */
	ErrFatalDisplay("lang2 index out of range");
    }
}

static void DrawHelpButton(FormPtr frm, UInt id)
{
    RectangleType r;
    FontID font;
    Char ch;
    
    FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, id), &r);
    WinEraseRectangle(&r, 4);
    font = FntSetFont(symbolFont);
    ch = symbolHelp;
    WinDrawChars(&ch, 1, r.topLeft.x + 3, 2);
    FntSetFont(font);
}

static void HideButton(FormPtr frm, Word objID, Boolean hide, Boolean activate)
{
    ControlPtr ctl;

    ctl = GetObjectPtr(frm, objID);
    if (hide) {
	CtlSetEnabled(ctl, false); /* disable */
	CtlHideControl(ctl);
    } else {
	CtlSetEnabled(ctl, true);  /* enable */
	CtlShowControl(ctl);
    }
    if (activate) {
	CtlSetValue(ctl, true);
    } else {
	CtlSetValue(ctl, false);
    }
}

static void DrawInfo(Int index, FormPtr frm)
{
    VoidHand t;
    BitmapPtr bitmapP;
    Char buf[30];
    RectangleType rect;
    UShort ev = 0;
    Int i;
#ifdef NOTEVIEW
    ControlPtr ctl;
    Boolean invertNote;
    FrameBitsType frame;
#endif
    
    RctSetRectangle(&rect, BMPX, BMPY, 90, 90);
    WinEraseRectangle(&rect, 0);

#ifdef GRAPHIC
    t = DmGetResource('Tbmp', index);
#else
    t = DmGetResource('Tbmp', 0);
#endif
    if (t) {
	bitmapP = MemHandleLock(t);
	WinDrawBitmap(bitmapP, BMPX, BMPY);
	MemHandleUnlock(t);
	DmReleaseResource(t);
    }
    
    StrIToA(buf, index);
    FrmHideObject(frm, FrmGetObjectIndex(frm, lbNum));
    FrmCopyLabel(frm, lbNum, buf);
    FrmShowObject(frm, FrmGetObjectIndex(frm, lbNum));

    FrmHideObject(frm, FrmGetObjectIndex(frm, lbName1));
    FrmCopyLabel(frm, lbName1, pokeNames1[index]);
    FrmShowObject(frm, FrmGetObjectIndex(frm, lbName1));

    FrmHideObject(frm, FrmGetObjectIndex(frm, lbName2));
    FrmCopyLabel(frm, lbName2, pokeNames2[index]);
    FrmShowObject(frm, FrmGetObjectIndex(frm, lbName2));

    for (i=0; i < 4; i++) {
	if ((ev = evolutions[index-i]) != 0)
	    break;
    }

    ErrFatalDisplayIf(ev <= 0, "evolutions[] corrupt");

    HideButton(frm, pbStep3, ev < 3 || (ev >= 4 && i > 0), i == 2 || (ev >= 4 && i > 0));
    HideButton(frm, pbStep2, ev < 2, i == 1 || (ev >= 4 && i > 0));
    HideButton(frm, pbStep1, ev < 1, i == 0 && ev < 4);
    
#ifdef NOTEVIEW
    if (ExtraDB) {
	invertNote = (DmQueryRecord(ExtraDB, currentNum) != NULL);
	ctl = GetObjectPtr(frm, btNote);
	frame.word = ButtonFrameToFrameType(ctl);
	if ((invertNote && !noteInverted) || (!invertNote && noteInverted)) {
	    WinInvertRectangle(&ctl->bounds, frame.bits.cornerDiam);
	    noteInverted = !noteInverted;
	}
    }
#endif
}


Int getEvolution(Int index, UShort step)
{
    UShort i;
    UShort ev = 0;
    
    for (i=0; i < 4; i++) {
	if ((ev = evolutions[index-i]) != 0)
	    break;
    }
    
    ErrFatalDisplayIf(ev <= 0, "evolutions[] corrupt");
    
    if (ev == 4 && i == 0) {
	return (index + step);
    } else if (ev == 4 && step == 2) {
	return 0;
    } else {
	if ((ev - step) >= 0)
	    return (index - i + step - 1);
	return 0;
    }
}

#ifdef NOTEVIEW
static void NoteViewDrawTitle (void)
{
    SWord x, y;
/*
    Err error;
    UInt fieldSeparatorWidth;
    UInt shortenedFieldWidth;
    CharPtr name1, name2;
    Int name1Length;
    Int name2Length;
    Int name1Width;
    Int name2Width;
*/
    UInt nameExtent;
    short winWidth;
    short winHeight;
    FontID curFont;
    RectangleType r;

    curFont = FntSetFont (boldFont);
    WinGetWindowExtent (&winWidth, &winHeight);
    x = 2;
    y = 1;
    nameExtent = winWidth - 4;


/*
    error = AddrGetRecord(AddrDB, CurrentRecord, &record, &recordH);
    ErrNonFatalDisplayIf ((error), "Record not found");
    if (error) return;   
*/

/*
    DrawRecordName(name1, name1Length, name1Width, name2, name2Length, name2Widt
       nameExtent, &x, y, shortenedFieldWidth, fieldSeparatorWidth, true,
       name1HasPriority || !SortByCompany);
*/

    RctSetRectangle (&r, 0, 0, winWidth, FntLineHeight()+2 );
    WinInvertRectangle (&r, 3);

/*
    MemHandleUnlock(recordH);
*/
    FntSetFont (curFont);
}

static void NoteViewUpdateScrollBar (void)
{
   Word scrollPos;
   Word textHeight;
   Word fieldHeight;
   Short maxValue;
   FieldPtr fld;
   ScrollBarPtr bar;

   fld = GetObjectPtr2 (NoteField);
   bar = GetObjectPtr2 (NoteScrollBar);

   FldGetScrollValues (fld, &scrollPos, &textHeight,  &fieldHeight);

   if (textHeight > fieldHeight)
      maxValue = textHeight - fieldHeight;
   else if (scrollPos)
      maxValue = scrollPos;
   else
      maxValue = 0;

   SclSetScrollBar (bar, scrollPos, 0, maxValue, fieldHeight-1);
}

/*
static void NoteViewChangeFont (UInt controlID)
{
        FontID fontID;
   FieldPtr fld;


   fld = GetObjectPtr2 (NoteField);
        fontID = FldGetFont (fld);
   if (controlID == NoteSmallFontButton)
      NoteFont = stdFont;
   else
      NoteFont = largeBoldFont;

   // FldSetFont will redraw the field if it is visible.
   FldSetFont (fld, NoteFont);

   NoteViewUpdateScrollBar ();
}
*/

static void NoteViewLoadRecord (void)
{
   FieldPtr fld;
/*
   Word offset;
   CharPtr ptr;
*/


   // Get a pointer to the memo field.
   fld = GetObjectPtr2 (NoteField);

   // Set the font used in the memo field.
   FldSetFont (fld, NoteFont);


/*
   AddrGetRecord (AddrDB, CurrentRecord, &record, &recordH);
*/

   // CreateNote will have been called before the NoteView was switched
   // to.  It will have insured that a note field exists.

/*
   // Find out where the note field is to edit it
   ptr = MemDeref (recordH);
   offset = record.fields[note] - ptr;
   FldSetText (fld, recordH, offset, StrLen(record.fields[note])+1);

   MemHandleUnlock(recordH);
*/
}

static void DeleteNote (void);

static void NoteViewSave (void)
{
   FieldPtr fld;
   int textLength;


   fld = GetObjectPtr2 (NoteField);


   // If the field wasn't modified then don't do anything
   if (FldDirty (fld))
      {
      // Release any free space in the note field.
      FldCompactText (fld);

/*
      DirtyRecord (CurrentRecord);
*/
      }


   textLength = FldGetTextLength(fld);

   // Clear the handle value in the field, otherwise the handle
   // will be free when the form is disposed of,  this call also unlocks
   // the handle that contains the note string.
   FldSetTextHandle (fld, 0);


   // Empty fields are not allowed because they cause problems
   if (textLength == 0)
      DeleteNote();
}

static void DeleteNote (void)
{
/*
   Err err;
*/

/*
   AddrGetRecord (AddrDB, CurrentRecord, &record, &recordH);
   record.fields[note] = NULL;
   changedField.allBits = (ULong)1 << note;
   err = AddrChangeRecord(AddrDB, &CurrentRecord, &record, changedField);
   if (err)
      {
      MemHandleUnlock(recordH);
      FrmAlert(DeviceFullAlert);
      return;
      }


   // Mark the record dirty.
   DirtyRecord (CurrentRecord);
*/
}

/*
static Boolean NoteViewDeleteNote (void)
{
   FieldPtr fld;

   if (FrmAlert(DeleteNoteAlert) != DeleteNoteYes)
      return (false);

   // Unlock the handle that contains the text of the memo.
   fld = GetObjectPtr2 (NoteField);
   ErrFatalDisplayIf ((! fld), "Bad field");

   // Clear the handle value in the field, otherwise the handle
   // will be free when the form is disposed of. this call also
   // unlocks the handle the contains the note string.
   FldCompactText (fld);
   FldSetTextHandle (fld, 0);


   DeleteNote();

   return (true);
}
*/

/*
static Boolean NoteViewDoCommand (Word command)
{
   FieldPtr fld;
   Boolean handled = true;

   switch (command)
      {
                case noteFontCmd:
                        NoteFont = SelectFont (NoteFont);
                        break;

      case noteTopOfPageCmd:
         fld = GetObjectPtr2 (NoteField);
         FldSetScrollPosition (fld, 0);
         NoteViewUpdateScrollBar ();
         break;

      case noteBottomOfPageCmd:
         fld = GetObjectPtr2 (NoteField);
         FldSetScrollPosition (fld, FldGetTextLength (fld));
         NoteViewUpdateScrollBar ();
         break;

                case notePhoneLookupCmd:
                        fld = GetObjectPtr2 (NoteField);
                        PhoneNumberLookup (fld);
                        break;

      default:
         handled = false;
      }
   return (handled);
}
*/

static void NoteViewScroll (Short linesToScroll)
{
   Word            blankLines;
   Short            min;
   Short            max;
   Short            value;
   Short            pageSize;
   FieldPtr         fld;
   ScrollBarPtr   bar;

   fld = GetObjectPtr2 (NoteField);

   if (linesToScroll < 0)
      {
      blankLines = FldGetNumberOfBlankLines (fld);
      FldScrollField (fld, -linesToScroll, up);

      // If there were blank lines visible at the end of the field
      // then we need to update the scroll bar.
      if (blankLines)
         {
         // Update the scroll bar.
         bar = GetObjectPtr2 (NoteScrollBar);
        SclGetScrollBar (bar, &value, &min, &max, &pageSize);
         if (blankLines > -linesToScroll)
            max += linesToScroll;
         else
            max -= blankLines;
         SclSetScrollBar (bar, value, min, max, pageSize);
         }
      }

   else if (linesToScroll > 0)
      FldScrollField (fld, linesToScroll, down);
}

static void NoteViewPageScroll (DirectionType direction)
{
   Short value;
   Short min;
   Short max;
   Short pageSize;
   Word linesToScroll;
   FieldPtr fld;
   ScrollBarPtr bar;

   fld = GetObjectPtr2 (NoteField);

   if (FldScrollable (fld, direction))
      {
      linesToScroll = FldGetVisibleLines (fld) - 1;
      FldScrollField (fld, linesToScroll, direction);

      // Update the scroll bar.
      bar = GetObjectPtr2 (NoteScrollBar);
      SclGetScrollBar (bar, &value, &min, &max, &pageSize);

      if (direction == up)
         value -= linesToScroll;
      else
         value += linesToScroll;

      SclSetScrollBar (bar, value, min, max, pageSize);
      return;
      }
}

static void NoteViewInit (FormPtr frm)
{
   FieldPtr       fld;
   FieldAttrType   attr;

   NoteViewLoadRecord ();


        // Hide the font controls that are used in version 1.0 and 2.0 .
        FrmHideObject (frm, FrmGetObjectIndex (frm, NoteSmallFontButton));
        FrmHideObject (frm, FrmGetObjectIndex (frm, NoteLargeFontButton));


   // Have the field send events to maintain the scroll bar.
   fld = GetObjectPtr2 (NoteField);
   FldGetAttributes (fld, &attr);
   attr.hasScrollBar = true;
   FldSetAttributes (fld, &attr);
}

static Boolean NoteViewHandleEvent (EventPtr event)
{
   FormPtr frm;
   Boolean handled = false;
   FieldPtr fldP;

   CALLBACK_PROLOGUE

   switch (event->eType)
        {
      case keyDownEvent:
         if (event->data.keyDown.chr == pageUpChr)
                {
            NoteViewPageScroll (up);
            handled = true;
                }
         else if (event->data.keyDown.chr == pageDownChr)
                        {
            NoteViewPageScroll (down);
            handled = true;
                }
         break;


      case ctlSelectEvent:
         switch (event->data.ctlSelect.controlID)
                {
            case NoteDoneButton:
               NoteViewSave ();

               FrmGotoForm(MainForm);
               handled = true;
               break;

/*
            case NoteDeleteButton:
               if (NoteViewDeleteNote ())
                  FrmGotoForm (MainForm);

               handled = true;
               break;
*/

            default:
               break;
                }
         break;

      case fldChangedEvent:
         frm = FrmGetActiveForm ();
         NoteViewUpdateScrollBar ();
         handled = true;
         break;

/*
      case menuEvent:
         return NoteViewDoCommand (event->data.menu.itemID);
*/

      case frmOpenEvent:
         frm = FrmGetActiveForm ();
         NoteViewInit (frm);
         NoteViewDrawTitle ();
         FrmDrawForm (frm);
         NoteViewUpdateScrollBar ();
         FrmSetFocus (frm, FrmGetObjectIndex (frm, NoteField));
         handled = true;
         break;

      case frmGotoEvent:
         frm = FrmGetActiveForm ();
/*         CurrentRecord = event->data.frmGoto.recordNum; */
         NoteViewInit (frm);
         fldP = GetObjectPtr2 (NoteField);
         FldSetScrollPosition(fldP, event->data.frmGoto.matchPos);
         FldSetSelection(fldP, event->data.frmGoto.matchPos,
               event->data.frmGoto.matchPos + event->data.frmGoto.matchLen);
         NoteViewDrawTitle ();
         FrmDrawForm (frm);
         NoteViewUpdateScrollBar ();
         FrmSetFocus (frm, FrmGetObjectIndex (frm, NoteField));
         handled = true;
         break;


/*
      case frmUpdateEvent:
                if (event->data.frmUpdate.updateCode & updateFontChanged)
                        {
                        fldP = GetObjectPtr2 (NoteField);
                        FldSetFont (fldP, NoteFont);
                        NoteViewUpdateScrollBar ();
                        handled = true;
                        }
                else
                        {
                        frm = FrmGetActiveForm ();
                        NoteViewDrawTitle ();
                        FrmDrawForm (frm);
                        handled = true;
                        }
                break;
*/

      case frmCloseEvent:
/*
         if (UnnamedRecordStringPtr)
                {
            MemPtrUnlock(UnnamedRecordStringPtr);
            UnnamedRecordStringPtr = NULL;
                }
*/
         if ( FldGetTextHandle (GetObjectPtr2 (NoteField)))
            NoteViewSave ();
         break;


      case sclRepeatEvent:
         NoteViewScroll (event->data.sclRepeat.newValue -
            event->data.sclRepeat.value);
         break;

      default:
        break;
        }

   CALLBACK_EPILOGUE

   return (handled);
}
#endif

static Boolean MainFormHandleEvent (EventPtr e)
{
    Boolean handled = false;
    FormPtr frm;
    UShort step;
    Int newNum;
    
    CALLBACK_PROLOGUE

    switch (e->eType) {
    case frmOpenEvent:
	frm = FrmGetActiveForm();
	FrmDrawForm(frm);
	
	DrawHelpButton(frm, btHelp);
	
	DrawInfo(currentNum, frm);
	handled = true;
	break;

    case menuEvent:
	MenuEraseStatus(NULL);

	switch(e->data.menu.itemID) {
	case mnAbout:
	    FrmAlert(AboutAlert);
	    break;
	case mnHelp:
	    FrmHelp(MainHelp);
	    break;
	case mnOptions:
	    FrmPopupForm(OptionsForm);
	    break;
	}

    	handled = true;
	break;

    case ctlSelectEvent:
	switch(e->data.ctlSelect.controlID) {
	case pbStep1:
	case pbStep2:
	case pbStep3:
	    if (e->data.ctlSelect.controlID == pbStep1)
		step = 1;
	    else if (e->data.ctlSelect.controlID == pbStep2)
		step = 2;
	    else
	        step = 3;
	    newNum = getEvolution(currentNum, step);
	    if (newNum != currentNum && newNum > 0) {
		frm = FrmGetActiveForm();
		currentNum = newNum;
		DrawInfo(currentNum, frm);
	    }
	    handled = true;
	    break;

	case btHelp:
	    FrmHelp(MainHelp);
	    break;
	    
#ifdef NOTEVIEW
	case btNote:
	    if (CreateNote())
		noteInverted = false;
		FrmGotoForm(NoteView);
	    handled = true;
	    break;
#endif
	}
	break;
	
    case keyDownEvent:
	frm = FrmGetActiveForm();
	switch(e->data.keyDown.chr) {
	    case pageUpChr:
		currentNum++;
		if (currentNum > 151)
		    currentNum = 1;
		DrawInfo(currentNum, frm);
		handled = true;
		break;
	    case pageDownChr:
		currentNum--;
		if (currentNum < 1)
		    currentNum = 151;
		DrawInfo(currentNum, frm);
		handled = true;
		break;
	}
	break;

    case frmUpdateEvent:
	frm = FrmGetActiveForm();
	DrawInfo(currentNum, frm);
	handled = true;
	break;

    case ctlRepeatEvent:
	frm = FrmGetActiveForm();
	switch(e->data.ctlRepeat.controlID) {
	    case rpUp:
		currentNum++;
		if (currentNum > 151)
		    currentNum = 1;
		DrawInfo(currentNum, frm);
		/* leave unhandled so the button can repeat */
		break;
	    case rpDown:
		currentNum--;
		if (currentNum < 1)
		    currentNum = 151;
		DrawInfo(currentNum, frm);
		/* leave unhandled so the button can repeat */
		break;
	}
	break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

Int SearchRecord(Char *str)
{
    Int i;
    Int start;
    
    if (currentNum == 151)
	start = 1;
    else
	start = currentNum + 1;



    for (i=start; i <= 151; i++) {
	if (StrStr(pokeNames1[i], str) || StrStr(pokeNames2[i], str))
	    return i;
    }
    for (i=1; i <= start; i++) {
	if (StrStr(pokeNames1[i], str) || StrStr(pokeNames2[i], str))
	    return i;
    }

    return 0;
}

static Boolean SearchFormHandleEvent (EventPtr e)
{
    Boolean handled = false;
    FormPtr frm;
    Int num;
    Char *str;
    FieldPtr fld;
    
    CALLBACK_PROLOGUE

    switch (e->eType) {
    case frmOpenEvent:
	frm = FrmGetActiveForm();

	fld = GetObjectPtr(frm, flSearch);
	FldInsert(fld, lastSearch, StrLen(lastSearch));
	FldSetSelection(fld, 0, FldGetTextLength(fld));

/*	FldSetInsertionPoint(fld, FldGetTextLength(fld)); */

	FrmDrawForm(frm);
	
	FrmSetFocus(frm, FrmGetObjectIndex(frm, flSearch));
	
	handled = true;
	break;

    case menuEvent:
	MenuEraseStatus(NULL);

	switch(e->data.menu.itemID) {
	}

    	handled = true;
	break;

    case ctlSelectEvent:
	switch(e->data.ctlSelect.controlID) {
	    case btCancel:
		FrmReturnToForm(MainForm);
		SearchFormOpen = false;
		handled = true;
		break;
	    case btSearch:
		str = FldGetTextPtr(GetObjectPtr(FrmGetActiveForm(), flSearch));
		if (str) {
		    StrNCopy(lastSearch, str, sizeof(lastSearch));
		    num = SearchRecord(str);
		    if (num == 0) {
			FrmAlert(NotFoundAlert);
		    } else {
			currentNum = num;
			FrmUpdateForm(MainForm, num);
			FrmReturnToForm(MainForm);
			SearchFormOpen = false;
		    }
		}
		handled = true;
		break;
	    case btGoto:
		str = FldGetTextPtr(GetObjectPtr(FrmGetActiveForm(), flGoto));
		if (str) {
		    num = StrAToI(str);
		    if (num < 1 || num > 151) {
			FrmAlert(RangeAlert);
		    } else {
			currentNum = num;
			FrmUpdateForm(MainForm, num);
			FrmReturnToForm(MainForm);
			SearchFormOpen = false;
		    }
		}
		handled = true;
		break;
	}
	break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean OptionsFormHandleEvent (EventPtr e)
{
    Boolean handled = false;
    FormPtr frm;

    
    CALLBACK_PROLOGUE

    switch (e->eType) {
    case frmOpenEvent:
	frm = FrmGetActiveForm();    
        newprefs.lang1 = prefs.lang1;
        newprefs.lang2 = prefs.lang2;
        LstSetSelection(GetObjectPtr(frm, liLang1), newprefs.lang1);
        LstSetSelection(GetObjectPtr(frm, liLang2), newprefs.lang2);

        CtlSetLabel(GetObjectPtr(frm, ptLang1), LstGetSelectionText(GetObjectPtr(frm, liLang1), newprefs.lang1));
        CtlSetLabel(GetObjectPtr(frm, ptLang2), LstGetSelectionText(GetObjectPtr(frm, liLang2), newprefs.lang2));

	FrmDrawForm(frm);
	handled = true;
	break;

    case menuEvent:
	MenuEraseStatus(NULL);

	switch(e->data.menu.itemID) {
	}

    	handled = true;
	break;

    case ctlSelectEvent:
	switch(e->data.ctlSelect.controlID) {
	    case btCancel:
		FrmReturnToForm(MainForm);
		handled = true;
		break;
	    case btOK:
		if (prefs.lang1 != newprefs.lang1 || prefs.lang2 != newprefs.lang2) {
		    FrmUpdateForm(MainForm, 0);
		    prefs.lang1 = newprefs.lang1;
		    prefs.lang2 = newprefs.lang2;
		    SetPokeNames();
		}

		FrmReturnToForm(MainForm);
		handled = true;
		break;
	}
	break;

    case popSelectEvent:
	frm = FrmGetActiveForm();
	switch(e->data.popSelect.listID) {
	case liLang1:
	    newprefs.lang1 = LstGetSelection(GetObjectPtr(frm, liLang1));
	    break;
	case liLang2:
	    newprefs.lang2 = LstGetSelection(GetObjectPtr(frm, liLang2));
	    break;
	default:
	    ErrFatalDisplay("bad listID received by OptionsFormHandleEvent");
	    break;
	}

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean SpecialHandleEvent(EventPtr e)
{
    Boolean handled = false;

    switch (e->eType) {
    case keyDownEvent:
	switch(e->data.keyDown.chr) {
	case findChr:
	    if (!SearchFormOpen) {
		FrmPopupForm(SearchForm);
		SearchFormOpen = true;
	    } else {
		CtlHitControl(GetObjectPtr(FrmGetActiveForm(), btSearch));
	    }
	    handled = true;
	    break;
	}
	break;
    default:
	break;
    }
    
    return handled;
}

static Boolean ApplicationHandleEvent(EventPtr e)
{
    FormPtr frm;
    Word    formId;
    Boolean handled = false;

    if (e->eType == frmLoadEvent) {
	formId = e->data.frmLoad.formID;
	frm = FrmInitForm(formId);
	FrmSetActiveForm(frm);

	switch(formId) {
	case MainForm:
	    FrmSetEventHandler(frm, MainFormHandleEvent);
	    break;
	case SearchForm:
	    FrmSetEventHandler(frm, SearchFormHandleEvent);
	    break;
	case OptionsForm:
	    FrmSetEventHandler(frm, OptionsFormHandleEvent);
	    break;
#ifdef NOTEVIEW
	case NoteView:
	    FrmSetEventHandler(frm, NoteViewHandleEvent);
	    break;
#endif
	}
	handled = true;
    }

    return handled;
}

/* Get preferences, open (or create) app database */
static Word StartApplication(void)
{
#ifdef NOTEVIEW
    ExtraDB = DmOpenDatabaseByTypeCreator('DATA', APPID, dmModeReadOnly);
#endif

    if (PrefGetAppPreferencesV10(APPID, 0, &newprefs, sizeof(newprefs))) {
	if (newprefs.version == 1) {
	    prefs.lang1 = newprefs.lang1;
	    prefs.lang2 = newprefs.lang2;
	    SetPokeNames();
	} else {
	    ErrNonFatalDisplay("wrong preference version");
	}
    }

    FrmGotoForm(MainForm);
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void)
{
    PrefSetAppPreferencesV10(APPID, 0, &prefs, sizeof(prefs));

    FrmSaveAllForms();
    FrmCloseAllForms();
#ifdef NOTEVIEW
    if (ExtraDB)
	DmCloseDatabase(ExtraDB);
#endif
}

/* The main event loop */
static void EventLoop(void)
{
    Word err;
    EventType e;

    do {
	EvtGetEvent(&e, evtWaitForever);
	if (! SpecialHandleEvent (&e))
	    if (! SysHandleEvent (&e))
		if (! MenuHandleEvent (NULL, &e, &err))
		    if (! ApplicationHandleEvent (&e))
			FrmDispatchEvent (&e);
    } while (e.eType != appStopEvent);
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
    Word err;

    if (cmd == sysAppLaunchCmdNormalLaunch) {

	err = StartApplication();
	if (err) return err;

	EventLoop();
	StopApplication();

    } else {
	return sysErrParamErr;
    }

    return 0;
}
