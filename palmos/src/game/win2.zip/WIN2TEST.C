
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#include "win2.h"
#include "win2test.h"
#define kfcCreator 'Win2'

void DoPaint();
FormPtr pfrmMain;

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
	{
	short err;
	EventType e;
	FormType *pfrm;
	Boolean fMainWindowActive;

	if (!cmd) 
		{
		FrmGotoForm(kidForm1);
		while(1) 
			{
			EvtGetEvent(&e, 1000);
			if (Win2PreFilterEvent(&e))
				continue;
			if (SysHandleEvent(&e)) 
				continue;
			if (MenuHandleEvent((void *)0, &e, &err)) 
				continue;
	
			switch (e.eType) 
				{
			case frmLoadEvent:	
				pfrm = FrmInitForm(e.data.frmLoad.formID);
				if (e.data.frmLoad.formID == kidForm1)
					pfrmMain = pfrm;
				FrmSetActiveForm(pfrm);
				break;
			case frmUpdateEvent:
				DoPaint();
				break;
			case winEnterEvent:
				// Hack!  sometimes palmos eats update events (or proceses them itself)
				// this causes us to not draw when going to applications and back
				fMainWindowActive = e.data.winEnter.enterWindow == (WinHandle) pfrmMain; 
				if (pfrmMain != NULL && fMainWindowActive)
					{
					DoPaint();
					}
				break;
				
			case frmOpenEvent:
				pfrm = FrmGetActiveForm();
				FrmDrawForm(pfrm);
				DoPaint();
				break;

			case appStopEvent:
				Win2SetMono();
				return 0;

			default:
Dft:
				FrmHandleEvent(FrmGetActiveForm(), &e);
				}
			}
		}
	return 0;
	}


typedef struct _rsctx
	{
	DmOpenRef db;
	VoidHand h;
	Boolean fLocked;
	} RSCTX;

void UnloadResource(RSCTX *prsctx)
	{
	if (prsctx->fLocked)
		MemHandleUnlock(prsctx->h);
	if (prsctx->h != NULL)
		DmReleaseResource(prsctx->h);
	if (prsctx->db != 0)
		DmCloseDatabase(prsctx->db);
	}

BytePtr PbLoadResource(ULong type, int kid, RSCTX *prsctx)
	{
	BytePtr pb;

	prsctx->h = 0;
	prsctx->fLocked = 0;
	prsctx->db = DmOpenDatabaseByTypeCreator(sysFileTApplication, kfcCreator, dmModeReadOnly);
	if (prsctx->db == 0)
		{
Error:
		UnloadResource(prsctx);
		return (BytePtr) NULL;
		}
	prsctx->h = DmGet1Resource(type, kid);
	if (prsctx->h == NULL)
		goto Error;
	pb = (BytePtr) MemHandleLock(prsctx->h);
	if (pb == NULL)
		goto Error;
	prsctx->fLocked = true;
	return pb;
	}

int TestColor(Win2Color clrFore, Win2Color clrBack, char *szClr, int yOut)
	{
	RectangleType rc;

	Win2SetColor(clrFore);
	Win2SetBackgroundColor(clrBack);
	Win2DrawChars(szClr, StrLen(szClr), 10, yOut);
	rc.topLeft.x = 80;
	rc.topLeft.y = yOut;
	rc.extent.x = 40;
	rc.extent.y = 10;
	Win2FillRectangle(&rc, 0);
	Win2DrawLine(120, yOut, 159, yOut+12);
	Win2DrawLine(120, yOut+12, 159, yOut);
	return yOut+12;
	}

void DoPaint()
	{
	RSCTX rsctx;
	BitmapPtr pbm;
	int yOut;
	
	if (Win2SetGreyscale() != 0)
		{
		FrmAlert(kidOOM);
		return;
		}
	pbm = (BitmapPtr) PbLoadResource('Tbmp', kidBitmap, &rsctx);
	if (pbm != NULL)
		Win2DrawBitmap(pbm, 20, 18);
	UnloadResource(&rsctx);		
	yOut = 18+pbm->height+5;
	yOut = TestColor(clrLtGrey, clrWhite, "LtGrey", yOut);
	yOut = TestColor(clrDkGrey, clrWhite, "DkGrey", yOut);
	yOut = TestColor(clrBlack, clrWhite, "Black", yOut);
	yOut = TestColor(clrLtGrey, clrDkGrey, "LtGrey", yOut);
	yOut = TestColor(clrDkGrey, clrLtGrey, "DkGrey", yOut);
	yOut = TestColor(clrWhite, clrBlack, "Black", yOut);
	Win2CopyMonoToGrey(true);
	}
