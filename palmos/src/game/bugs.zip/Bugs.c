#include <PalmOS.h>

#include "bugs.h"

void Initializing(void) {
  int i, j;

  // Load images
  for (i = 0; i < bmpID_Count; i++) {
    BugHandle[i]   = DmGetResource(bitmapRsc, bmpID_Start + i);
    BugPtr[i]      = MemHandleLock(BugHandle[i]);
  }
  
  // Initialize BUGs
  for (i = 0; i < BoardXSize; i++)
    for (j = 0; j < BoardYSize; j++) {
      Cell[i][j].livetime     = 0;
      Cell[i][j].state        = BStateNone;
    }
  
  // Initialize game status
  Killed    = 0;
  Leaved    = 0;
  Speed     = 10;
  MaxLeaved = 10;
}

void ShowSplashScreen(void) {
  EventType event;

  MemHandle				SplashHandle;
  BitmapPtr				SplashPtr;

  SplashHandle  = DmGetResource(bitmapRsc, bmpID_SplashBug);
  SplashPtr     = MemHandleLock(SplashHandle);

  WinDrawBitmap(SplashPtr, 0, 0);
  WinDrawChars("(c) 2002, by", 12, 0, 100);
  WinDrawChars(" Petr V.", 8, 0, 110);
  WinDrawChars(" Gorodnichev", 12, 0, 120);

  MemHandleUnlock(SplashHandle);
  DmReleaseResource(SplashHandle);

  do {
    EvtGetEvent(&event, SysTicksPerSecond() / 10);
    SysHandleEvent(&event);
  } while ((event.eType != appStopEvent) && (event.eType != penDownEvent));
}

void ShowCountDown(void) {
  int       i;
  WChar     c;
  
  WinEraseWindow();
  
  for (i=4; i>=0; i--) {
    c = i + 48 + 1;
    WinDrawChar(c, 80, 80);
    SysTaskDelay(SysTicksPerSecond());
  }
  WinDrawChars("Go!!!", 5, 70, 80);
}

/*******************************************************
*   This function show game status bar with killed
* and leaved bugs
*******************************************************/
void ShowGameStatus(char FullBar) {
  int   cnt;
  
  if (FullBar == 1) {
    WinDrawLine(0, 17, 159, 17);
    WinDrawLine(0, 19, 159, 19);
  }

  // Show KILLED
  cnt = StrVPrintF(StatusStr, "Killed: %d", &Killed);
  WinDrawChars(StatusStr, cnt, 0, 0);

  // Show MISSED
  cnt = StrVPrintF(StatusStr, "Missed: %d", &Leaved);
  WinDrawChars(StatusStr, cnt, 70, 0);
}

/*******************************************************
*   This function show bug in selected position
*******************************************************/
void ShowBug(int xPos, int yPos, char State) {
  static int    x, y;
  
  x = xPos * BugXSize + 10;
  y = yPos * BugYSize + 20;
  
  if      (State == 0)
    WinDrawBitmap(BugPtr[0], x, y);
  else if (State == 1)
    WinDrawBitmap(BugPtr[1], x, y);
  else if (State == 2)
    WinDrawBitmap(BugPtr[2], x, y);
  else if (State == 3)
    WinDrawBitmap(BugPtr[3], x, y);
  else if (State == 4)
    WinDrawBitmap(BugPtr[4], x, y);
}

/*******************************************************
*   This function create new bug
*******************************************************/
void CreateNewBug(void) {
  static int       i, x, y;
  
  // Search for empty cell
  for (i = 0; i < MaxEmptySearch; i++) {
    // Get random cell
    x = SysRandom(0) % BoardXSize;
    y = SysRandom(0) % BoardYSize;
    
    if (Cell[x][y].state == BStateNone) {
      Cell[x][y].state      = BStateAlive;
      Cell[x][y].livetime   = DefaultLiveTime;

      ShowBug(x, y, Cell[x][y].state);

      return;
    }
  }
}

/*******************************************************
*   This function proceed all cells: decrease SQUASHED
* bugs, push away leaved bugs, etc.
*******************************************************/
void ProceedBoard(void) {
  static int            i, x, y;
  static RGBColorType   cl;
  static RectangleType  r;

  for (x = 0; x < BoardXSize; x++)
    for (y = 0; y < BoardYSize; y++) {
      // Decrease LiveTime for each bug
      if(Cell[x][y].state == BStateAlive) {
        Cell[x][y].livetime--;
      }

      // Push away LiveTimed bugs
      if((Cell[x][y].state == BStateAlive) && Cell[x][y].livetime < 1) {
        Cell[x][y].livetime = 0;
        Cell[x][y].state    = BStateNone;
        Leaved++;
        ShowBug(x, y, BStateKilled4);
        ShowGameStatus(0);
      }
      
      // If bug is cleared
      if(Cell[x][y].state == BStateKilled4) {
        Cell[x][y].state = BStateNone;
        ShowBug(x, y, Cell[x][y].state);
      }

      // If bug is squashed
      if((Cell[x][y].state >= BStateKilled1) && (Cell[x][y].state <= BStateKilled3)) {
        Cell[x][y].state++;
        ShowBug(x, y, Cell[x][y].state);
      }
    }
  // Check Leaved qty
  if (Leaved >= MaxLeaved) {
    r.topLeft.x  = 5;
    r.topLeft.y  = 50;
    r.extent.x   = 150;
    r.extent.y   = 40;
    
    cl.r = cl.g = cl.b = 255;
    WinSetForeColor(WinRGBToIndex(&cl));
    WinDrawRectangle(&r, 0);

    cl.r = cl.g = cl.b = 0;
    WinSetForeColor(WinRGBToIndex(&cl));
    WinDrawRectangleFrame(rectangleFrame, &r);
    
    // Show Message
    i = StrVPrintF(StatusStr, "You are missed %d bugs.", &Leaved);
    WinDrawChars(StatusStr, i, 35, 60);
    WinDrawChars("GAME OVER", 9, 60, 70);
  }
}

/*******************************************************
*   This function calculate, when we can generate
* new game event
*******************************************************/
int AllowNewGameEvent() {
  static UInt32         prevticks = 0;
  static UInt32         newticks;
  
  newticks = TimGetTicks();
  if (((newticks - prevticks) / (SysTicksPerSecond() * 5 / Speed))  > 1)
    {
      prevticks = newticks;
      return 1;
    }
  else
    return 0;
}


/*******************************************************
*   This function proceed users clicks
*******************************************************/
void ProceedUserClick(Int16 x, Int16 y) {
  int   cx, cy;
  
  if ((x < 10) || (x > 150) || (y < 20) || (y > 160))
    return;
    
  // Calculate cell co-ordinates
  cx = (x - 10) / BugXSize;
  cy = (y - 20) / BugYSize;
  
  // Check this cell
  if (Cell[cx][cy].state == BStateAlive) {
    Cell[cx][cy].state = BStateKilled1;
    Killed++;
    ShowBug(cx, cy, BStateKilled1);
    ShowGameStatus(0);
    
    if (((Killed % 50) == 0) && (Speed < 10))
      Speed++;
  }
  
  return;
}

/*******************************************************
*   This function contain main game cycle
*******************************************************/
void PlayGame(void) {
  EventType event;

  WinEraseWindow();
  
  ShowGameStatus(1);

  do {
    EvtGetEvent(&event, SysTicksPerSecond() / 10);
    SysHandleEvent(&event);
    
    // User touch screen
    if (event.eType == penDownEvent)
      ProceedUserClick(event.screenX, event.screenY);
    
    if (AllowNewGameEvent()) {
      if (Leaved < MaxLeaved)
        {
          CreateNewBug();
          ProceedBoard();
        }
      else
        {
          SysTaskDelay(SysTicksPerSecond()*3);
          break;
        }
    }
    
  } while (event.eType != appStopEvent);

}


UInt32 PilotMain (UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags) {
  // Variable declarations
  int       i;

  // Check the launch code
  if (cmd == sysAppLaunchCmdNormalLaunch) {
  
    // Load resources
    Initializing();
    
    ShowSplashScreen();
    
    PlayGame();
    
//    WinDrawBitmap(BugPtr, SysRandom(0) % 160, SysRandom(0) % 160);
//    WinDrawChars("The BUGS!", 8, SysRandom(0) % 160, SysRandom(0) % 160);

  }
  
  return 0;
}