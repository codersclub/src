#include <PalmOS.h>

#include "Bugs.rcp.h"

//// Define constants
#define MaxBugsCount            20

#define BugXSize                28
#define BugYSize                28

#define BoardXSize              5
#define BoardYSize              5

#define BStateNone              99
#define BStateAlive             0
#define BStateKilled1           1
#define BStateKilled2           2
#define BStateKilled3           3
#define BStateKilled4           4

// How many times, we will try to search empty place on board before nuw bug creating
#define MaxEmptySearch          20

//// Define data types
// CELL structure, contain information about bugs on each cell
typedef struct
  {
    char    state;
    int     livetime;
  }
TCell;

//// Define variables
// Arrays with sprites and bitmaps
static MemHandle				BugHandle[bmpID_Count];
static BitmapPtr				BugPtr[bmpID_Count];

// Array with bugs information
static TCell                    Cell[BoardXSize][BoardYSize];

// Game status variables
static int                      Killed;
static int                      Leaved;
static int                      Speed;
static int                      DefaultLiveTime         = 10;
static int                      MaxLeaved               = 10;
// Array for output formatted info about killed and leaved bugs
static char                     StatusStr[30];
