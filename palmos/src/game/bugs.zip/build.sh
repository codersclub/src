#!/bin.sh
rm bugs.prc

pilrc Bugs.rcp
m68k-palmos-gcc -O2 bugs.c -o bugs.o
m68k-palmos-obj-res bugs.o
build-prc bugs.prc "Bugs" Bugs *.bugs.o.grc *.bin

rm bugs.o
rm *.bugs.o.grc
rm *.bin

