#define bmpID_SplashBug                 1100

#define bmpID_Start                     1000
#define bmpID_Count                     5

#define bmpID_AliveBug                  1000
#define bmpID_KilledBug1                1001
#define bmpID_KilledBug2                1002
#define bmpID_KilledBug3                1003
#define bmpID_KilledBug4                1004
