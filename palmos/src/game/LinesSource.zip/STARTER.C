#undef NEWHIGHSCORE

#include <Pilot.h>		
#include <FeatureMgr.h>		
#include <Graffiti.h>
#include <SystemMgr.rh>
#include <DLServer.h>
#include "LinesRes.h"		

//--------------------------------------- COLOR
#include "color.h"


#define POPbutton(x,y) \
	WinDrawBitmap(imageBoard,2+x*16,15+y*16); \
	PushState[x][y] = 0
					
#define PUSHbutton(x,y) \
	WinDrawBitmap(imageReverseBoard,2+x*16,15+y*16); \
	PushState[x][y] = 1
//---------------------------------------

#define version20		0x02000000	/* PalmOS 2.0 version number */

#define appFileCreator		'Line'
#define appSavedGameID		0
#define appSavedGameVersion 	0

#define HighScoreNameLen	(20 + 1)
#define NHighScores		9

#define MenuSize		14
#define LabelSize   		32

#define NColors     		7
#define Rows			9
#define Columns			9
#define RemoveMin   		5
#define NThrow      		3

#define MaxScoreDigits 		5
#define MaxScoreDisplayed	100000

#define BallXSize		13
#define BallYSize   		13
#define TopBallSize 		11
#define CellXSize		(BallXSize + 2 + 1)
#define CellYSize   		(BallYSize + 2 + 1)

#define NCells			(Rows * Columns)
#define Width			(Columns * CellXSize + 1)
#define Height			(Rows * CellYSize + 1)

#define LeftOffset		1 /* ((160 - Width) / 2) */
#define TopOffset		(MenuSize + (160 - MenuSize - Height) / 2)

static char Color[NColors][8] = {
	{ 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00}, /* White	      */
	{ 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff}, /* Black 	      */
	{ 0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa, 0x55, 0xaa}, /* Gray  	      */
	{ 0xee, 0x77, 0xbb, 0xdd, 0xee, 0x77, 0xbb, 0xdd}, /* Black&diagonals */
	{ 0x11, 0x88, 0x44, 0x22, 0x11, 0x88, 0x44, 0x22}, /* White&diagonals */
	{ 0xbf, 0xff, 0xfb, 0xff, 0xbf, 0xff, 0xfb, 0xff}, /* Black w/ dots   */
	{ 0x40, 0x00, 0x04, 0x00, 0x40, 0x00, 0x04, 0x00}  /* White w/ dots   */
};

//------------------------------------------ COLOR
BitmapType 	*imageBoard = NULL;
UChar		*imageBoardBits = NULL;
BitmapType 	*imageReverseBoard = NULL;
UChar		*imageReverseBoardBits = NULL;
UInt16		err;
DWord 		NewDepth = 8;
UChar 		color = 1;
UChar		PushState[Columns][Rows];
VoidHand	vh[7];
VoidPtr		vp[7];
//----------------------------------------


static DWord romVersion;

static int ScoreX;
static char Selected = -1;

struct HScore {
	short score;
	char name[HighScoreNameLen];
};

static struct {
	int score;
	char lastHighScore;
	char status;
	char board[NCells];
	char nfree;
	char nextcolor[NThrow];
	struct HScore hscores[NHighScores];
	int	 remain;			//	you have  30 remained.
} Prefs;

#define Board			Prefs.board
#define NFree			Prefs.nfree
#define Status			Prefs.status
#define StatusShowNext  0x01
#define Score   		Prefs.score
#define LastHighScore 	Prefs.lastHighScore
#define NextColor		Prefs.nextcolor
#define HScores         Prefs.hscores
#define	reg				Prefs.remain
static inline void SetBoard(int n, char c)
{
	Board[n] = c;
}

static inline void InitHighScores()
{
	MemSet(HScores, sizeof(HScores), 0);
	LastHighScore = -1;
}

#ifdef NEWHIGHSCORE
static void RemoveHighScore(int i)
{
	MemMove(HScores + i, HScores + i + 1, 
		sizeof(HScores[0]) * (NHighScores - i - 1));
	MemSet(HScores + NHighScores - 1, sizeof(HScores[0]), 0);
	if (LastHighScore == i)
		LastHighScore = -1;
	else if (LastHighScore < i)
		LastHighScore --;
}
#endif /* NEWHIGHSCORE */

static void AddHighScore(char * name, short score)
{
	int i;

#ifdef NEWHIGHSCORE
	int n;

	/* No more than 3 entries in HighScore table per player mode */
	for (n = i = 0; i < NHighScores; i++)  {
		if (!StrCompare(HScores[i].name, name)) {
			if (++n > 3) {
				RemoveHighScore(i);
				continue;
			} else if (n == 3) {
				if (score > HScores[i].score) {
					RemoveHighScore(i);
					continue;
				}
				score = 0;
			}
		}
	} 
#endif /* NEWHIGHSCORE */

	for (i = 0; i < NHighScores && score <= HScores[i].score ; i++) 
		;

	if (i < NHighScores) {
		MemMove(HScores + i + 1, HScores + i, 
			sizeof(HScores[0]) * (NHighScores - i - 1));
		HScores[i].score = score;
		MemMove(HScores[i].name, name, HighScoreNameLen - 1);
		HScores[i].name[HighScoreNameLen - 1] = 0;
		LastHighScore = i;
	}
}

static inline Boolean GotHighScore(short score)
{
	return (score > HScores[NHighScores - 1].score);
}

static void Delay(short msec)
{
	if (romVersion < version20)
		SysTaskDelay(msec * sysTicksPerSecond / 1000);
	else
		SysTaskDelay(msec * SysTicksPerSecond() / 1000);
}

static void InitColors()
{
	int i;

	SysRandom(TimGetSeconds());
		
	for (i = 0; i < NThrow; i++)
		NextColor[i] = SysRandom(0) % NColors;	
}

static int GetColor(void)
{
	int i, c;
	
	c = NextColor[0];

	for (i = 0; i < NThrow - 1; i++)
		NextColor[i] = NextColor[i + 1];
		
	NextColor[NThrow - 1] = SysRandom(0) % NColors;
	
	return c;
}

static char * GetString(int id)
{
        return MemHandleLock(DmGetResource(strRsc, id));
}

static inline void ReleaseString(char * str)
{
        MemPtrUnlock(str);
}

static void DrawScore()
{
	char * msg = GetString(ScoreStr);
	char text[MaxScoreDigits + 1];
	FontID currFont;
	int y;

	Score %= MaxScoreDisplayed;
	StrIToA(text, Score);
	currFont = FntSetFont(boldFont);
	ScoreX = LeftOffset + Width + 1 - FntCharsWidth(text, StrLen(text));
	y = MenuSize - 1 - FntCharHeight();
	WinDrawChars(text, StrLen(text), ScoreX, y);
	ScoreX -= FntCharsWidth(msg, StrLen(msg));
	WinDrawChars(msg, StrLen(msg), ScoreX, y); 
	FntSetFont(currFont);
        ReleaseString(msg);
}

static void DrawBall(char pos)
{
	if (romVersion >= 0x03501000) { // COLOR
		WinDrawBitmap(vp[Board[pos]],3+(pos%Columns)*16,16+(pos/Columns)*16); 

	} else {
		RectangleType rect;
		CustomPatternType oldPattern;
	
		rect.topLeft.x = LeftOffset + pos % Columns * CellXSize +
				 (CellXSize - BallXSize - 1) / 2 + 1;
		rect.topLeft.y = TopOffset  + pos / Columns * CellYSize +
				 (CellYSize - BallYSize - 1) / 2 + 1;
		rect.extent.x = BallXSize;
		rect.extent.y = BallYSize;
	
		WinGetPattern(oldPattern);
		WinSetPattern((unsigned short *)Color[Board[pos]]);
		WinDrawRectangle(&rect, (BallXSize + BallYSize) / 4);
		rect.topLeft.x++;
		rect.topLeft.y++;
		rect.extent.x -= 2;
		rect.extent.y -= 2;
		WinFillRectangle(&rect, (BallXSize + BallYSize) / 4 - 1);
		WinSetPattern(oldPattern);
	}
}

static void EraseBall(char pos)
{
	if (romVersion >= 0x03501000) { // COLOR
		POPbutton(pos % Columns,pos / Columns);
	} else {
	
		RectangleType rect;
	
		rect.topLeft.x = LeftOffset + pos % Columns * CellXSize + 1;
		rect.topLeft.y = TopOffset  + pos / Columns * CellYSize + 1;
		rect.extent.x = CellXSize - 1;
		rect.extent.y = CellYSize - 1;
	
		WinEraseRectangle(&rect, 0);
	}
}

static void InvertBall(char pos)
{
	if (romVersion >= 0x03501000) { // COLOR
		if (PushState[pos % Columns][pos / Columns]) {
			POPbutton(pos % Columns,pos / Columns);
		} else {
			PUSHbutton(pos % Columns,pos / Columns);
		}
	} else {
		RectangleType rect;
	
		rect.topLeft.x = LeftOffset + pos % Columns * CellXSize + 1;
		rect.topLeft.y = TopOffset  + pos / Columns * CellYSize + 1;
		rect.extent.x = CellXSize - 1;
		rect.extent.y = CellYSize - 1;
		WinInvertRectangle(&rect, 0);
	
		rect.topLeft.x++;
		rect.topLeft.y++;
		rect.extent.x -= 2;
		rect.extent.y -= 2;
		WinEraseRectangle(&rect, 0);
	}

	
	if (Board[pos] >= 0)
		DrawBall(pos);
}

static short GetBallPos(Short x, Short y)
{
	int cx, cy;
	
	cx = x - LeftOffset;
	if (cx < 0 || cx >= Width || cx % CellXSize == 0)
		return -1;
	cx /= CellXSize;
	
	cy = y - TopOffset;
	if (cy < 0 || cy >= Height || cy % CellYSize == 0)
		return -1;
	cy /=  CellYSize;

	return cy * Columns + cx;
}

static void DrawTopBall(Short color, Short x, Short y)
{
	if (romVersion >= 0x03501000) { // COLOR
		WinDrawBitmap(vp[color],x,y); 
	} else {
		RectangleType rect;
		CustomPatternType oldPattern;
	
		rect.topLeft.x = x;
		rect.topLeft.y = y;
		rect.extent.x = TopBallSize;
		rect.extent.y = TopBallSize;
	
		WinGetPattern(oldPattern);
		WinSetPattern((unsigned short *)Color[color]);
		WinDrawRectangle(&rect, TopBallSize / 2);
		rect.topLeft.x++;
		rect.topLeft.y++;
		rect.extent.x -= 2;
		rect.extent.y -= 2;
		WinFillRectangle(&rect, TopBallSize / 2 - 1);
		WinSetPattern(oldPattern);
	}
}


static void DrawFrame()
{
	int i, j;
	int x,y;
	RectangleType rect;
	
	rect.topLeft.x = LeftOffset;
	rect.topLeft.y = TopOffset;
	rect.extent.x = Width;
	rect.extent.y = Height;
	WinEraseRectangle(&rect, 0);
	
	WinDrawLine(LeftOffset - 1, TopOffset + Height, 
		    LeftOffset + Width, TopOffset + Height);
	WinDrawLine(LeftOffset - 1, TopOffset - 1,
		    LeftOffset + Width, TopOffset - 1);
	WinDrawLine(LeftOffset - 1, TopOffset,
		    LeftOffset - 1, TopOffset + Height);
	WinDrawLine(LeftOffset + Width, TopOffset,
		    LeftOffset + Width, TopOffset + Height);

	for (i = 0, j = LeftOffset; i <= Columns; i++, j+= CellXSize) 
		WinDrawLine(j, TopOffset, j, TopOffset + Height);
	for (i = 0, j = TopOffset; i <= Rows; i++, j+= CellYSize)
		WinDrawLine(LeftOffset, j, LeftOffset + Width, j);
		
#if LeftOffset == 1 
	WinEraseLine(LeftOffset + Width + 1, 13, 159, 13);
	WinEraseLine(LeftOffset + Width + 1, 14, 159, 14);
#endif

	if (romVersion >= 0x03501000) { // COLOR
		if (imageBoard == NULL) {
		
			err = WinScreenMode(scrDisplayModeSet,NULL,NULL,&NewDepth,&color);
///////			
			imageBoard = BmpCreate(15,15,8,NULL,&err);
			imageBoardBits = BmpGetBits(imageBoard);
			
			
			for (i=0;i<7;i++) {
				vh[i] = DmGet1Resource('tAIB',2000+i);	///////
				if (vh[i])
					vp[i] = MemHandleLock(vh[i]);
				else 
					vp[i]=NULL;
			}
			
			for (i=0;i<15*16;i++)
				imageBoardBits[i]=0xDD;
			for (i=0;i<14;i++) {
				imageBoardBits[i]=0;
				imageBoardBits[16*i]=0;
			}
			
			imageBoardBits[14]=imageBoardBits[14*16]=0xDF;
			imageBoardBits[15*16-2]=0xD9;
			for (i=0;i<13;i++) {
				imageBoardBits[30+16*i]=0xDA;
				imageBoardBits[14*16+1+i]=0xDA;
			}
			

			imageReverseBoard = BmpCreate(15,15,8,NULL,&err);
			imageReverseBoardBits = BmpGetBits(imageReverseBoard);
			for (i=0;i<15*16-1;i++) {
				imageReverseBoardBits[i]=imageBoardBits[15*16-2-i];
			}
		
		}
		for (x=0;x<9;x++) 
			for (y=0;y<9;y++) 
				POPbutton(x,y);
	}
}

static void DrawTopBalls()
{
	int i;
	
	int w = (TopBallSize + 1) * NThrow - 1;
	int x = (ScoreX - LabelSize - w) / 2 + LabelSize;
	
	
	if (romVersion >= 0x03501000) { // COLOR
		for (i = 0; i < NThrow; i++) {
			DrawTopBall(NextColor[i],  x + i * (TopBallSize + 4), 0);
		}
	} else {
		for (i = 0; i < NThrow; i++) {
			DrawTopBall(NextColor[i],  x + i * (TopBallSize + 1), 
				    MenuSize - TopBallSize - 1 - 1);
		}
	}
}

static void ReDrawStatus()
{
	RectangleType rect;
	
	rect.topLeft.x = LabelSize;
	rect.topLeft.y = 0;
	rect.extent.x = Width + 1;
	rect.extent.y = MenuSize - 1;
	WinEraseRectangle(&rect, 0);
	
	DrawScore();
	if (Status & StatusShowNext)
		DrawTopBalls();
}

#define MovesMax    127
static char Moves[NCells];

static void BuildMovesArray(short pos)
{
	int i, d, found = 1;
	
	for (i = 0; i < NCells; i++)
		Moves[i] = Board[i] >= 0 ? -1 : MovesMax;
	
	Moves[pos] = 0;
	
	for (d = 0; found; d++) {
		found = 0;
		for (i = 0; i < NCells; i++) {
			if (Moves[i] == d) {
				found = 1;
				if (i % Columns > 0 && Moves[i - 1] > d + 1)
					Moves[i - 1] = d + 1;
				if (i % Columns < Columns - 1 &&
				    Moves[i + 1] > d + 1)
					Moves[i + 1] = d + 1;
				if (i >= Columns && Moves[i - Columns] > d + 1)
					Moves[i - Columns] = d + 1;
				if (i < Columns * (Rows - 1) &&
				    Moves[i + Columns] > d + 1)
					Moves[i + Columns] = d + 1;
			}
		}
	}
}

static inline short SelectAllowed(short pos)
{
	if (Selected == pos)
		return 0;
		
	if (Board[pos] >= 0) /* You can select a ball anytime */
		return 1;
	
	if (Selected >= 0 && Moves[pos] < MovesMax)
		return 1;
		
	return 0;
} 

static void MoveBall(short pos)
{
	int d = Moves[pos] - 1;
	int c = Board[Selected];
	int i;

	BuildMovesArray(pos);
	i = Selected; 
	Selected = -1;	

	for (; i != pos; d--) {
		SetBoard(i, -1);	
		EraseBall(i);
		if (i >= Columns && Moves[i - Columns] == d) 
			i = i - Columns;
		else if (i < Columns * (Rows - 1) && Moves[i + Columns] == d)
			i = i + Columns;
		else if (i % Columns > 0 && Moves[i - 1] == d)
			i--;
		else if (i % Columns < Columns - 1 && Moves[i + 1] == d)
			i++;
		else 
			ErrFatalDisplayIf(1, "MoveBall: no moves");
			
		SetBoard(i, c);	
		if (romVersion >= 0x03501000) // COLOR
			PUSHbutton(i % Columns,i / Columns);
		DrawBall(i);
		Delay(120);
		if (romVersion >= 0x03501000) { // COLOR
			POPbutton(i % Columns,i / Columns);
			DrawBall(i);
		}
	}
}

static void RemoveBall(short pos)
{
	ErrFatalDisplayIf(Board[pos] < 0, "RemoveBall: no ball");
	SetBoard(pos, -1);
	EraseBall(pos);
	NFree++;
}

static int CheckBall(short cpos, short npos, short color)
{
	int deltaX, deltaY;
	
	if (npos >= 0 && npos < NCells) {
		deltaX = npos % Columns - cpos % Columns;
		deltaY = npos / Columns - cpos / Columns;
		if (deltaX * deltaX + deltaY * deltaY <= 2 &&
		    Board[npos] == color)
			return 1;
	}
	return 0;
}

static int CheckDirection(short pos, short delta, short remove)
{
	int i, n, c;
	
	c = Board[pos];
	n = 1;
	
	for (i = pos; CheckBall(i, i - delta, c); i -= delta, n++)
		if (remove) 
			RemoveBall(i - delta);
	
	for (i = pos; CheckBall(i, i + delta, c); i += delta, n++)
		if (remove) 
			RemoveBall(i + delta);
			
	return n;
}

static int CheckBalls(Short pos, Boolean addscore)
{

	static char direction[4] = {Columns, 1, Columns + 1, Columns - 1};
	int lines = 0;
	int total = 0;
	int i, n;
	
	for (i = 0; i < 4; i++) {
		n = CheckDirection(pos, direction[i], false);
		if (n >= RemoveMin) {
			total += n;
			lines++;
			CheckDirection(pos, direction[i], true);
		}
	}
	
	if (lines) {
		RemoveBall(pos);
		Delay(200);
		if (addscore) {
			n = lines + total - 1 - RemoveMin;
			Score += 10 + 2 * n * n;
		}
		ReDrawStatus();
	}
		
	return lines;
}

static int ThrowBalls(short  n)
{
	short i, j;
	
	for (; n-- && NFree; i++, NFree--) {
		j = SysRandom(0) % NFree;
		
		for (i = 0; i < NCells; i++) 
			if (Board[i] < 0 && --j < 0)
				break;

		SetBoard(i, GetColor());
		DrawBall(i);
		Delay(200);
		CheckBalls(i, false);
	}
	return NFree;	
}

static void DrawBoard()
{
	int i;
	
	DrawFrame();
		

	if (NFree == NCells) {
		ThrowBalls(5); /* New Game */
	} else {
		for (i = 0; i  < NCells; i++)
			if (Board[i] >= 0) 
				DrawBall(i);
	}
	ReDrawStatus();		
	if (Selected >= 0)
		InvertBall(Selected); /* Invariant */
						 }

static void InitBoard(void)
{
	int i;
	
	Selected = -1;
	
	for (i = 0; i < NCells; i++)
		SetBoard(i, -1);
	
	NFree = NCells;
	Score = 0;
	InitColors();
}

static void SelectBall(short pos)
{
	if (Board[pos] >= 0) { /* User selected a ball */
		
		if (Selected >= 0) {
			ErrFatalDisplayIf(Board[Selected] < 0,
					  "SelectBall: no ball");
			InvertBall(Selected);  /* Remove frame from old one */
		}	
		Selected = pos;
		BuildMovesArray(pos);
		return;
	}
	
	InvertBall(pos);
	InvertBall(Selected);

	MoveBall(pos);
	Selected = -1;

	if (!CheckBalls(pos, true))
		ThrowBalls(3);
		 
	while(NFree == NCells)
		ThrowBalls(3);
	
	ReDrawStatus();
	if (!NFree) {
		if (GotHighScore(Score))
			FrmPopupForm(NewScoreForm);
		else {
			FrmAlert(GameOverAlert);
			InitBoard();
			DrawBoard();
		}
	}		
}


#define HighScoreY  	24
#define HighScoreX     100
#define HighScoreWidth 156
#define HighScoreSpace 4

static void EraseScoreBoard(void)
{
	RectangleType rect;
	rect.topLeft.x = HighScoreSpace;
	rect.topLeft.y = HighScoreY + 1;
	rect.extent.x  = HighScoreWidth;
	rect.extent.y  = 114;
	
	WinEraseRectangle(&rect, 0);
}

static void DrawScoreBoard(void)
{
	FontID curf;
	int i, y;
	char * namel = GetString(NameTopStr);
	char * scorel = GetString(ScoreTopStr);
	char num[6];
	
	curf = FntSetFont(boldFont);

	WinDrawLine(HighScoreSpace, HighScoreY,
		    HighScoreWidth - 1 - HighScoreSpace,
		    HighScoreY);
				 
	WinDrawChars(namel, StrLen(namel), 
		     HighScoreSpace + 10, 
		     HighScoreY - FntCharHeight());
 
	WinDrawChars(scorel, StrLen(scorel), 
		     HighScoreWidth - HighScoreSpace - 1 - 
		     FntCharsWidth(scorel, StrLen(scorel)),
		     HighScoreY - FntCharHeight());
 	
	for (i = 0; i < NHighScores && HScores[i].score > 0; i++) {
		FntSetFont(stdFont);
		y = HighScoreY + 2 + FntCharHeight() * i;
		if (i == LastHighScore)
			FntSetFont(boldFont);
		StrIToA(num, i + 1);
		StrCat(num, ". ");
		WinDrawChars(num, StrLen(num), HighScoreSpace, y);
		WinDrawChars(HScores[i].name, 
			     StrLen(HScores[i].name), HighScoreSpace + 10, y);
		StrIToA(num, HScores[i].score);
		WinDrawChars(num, StrLen(num),
			     HighScoreWidth - 1 - HighScoreSpace -
			     FntCharsWidth(num, StrLen(num)), y);
	}
 	
	FntSetFont(curf);
	ReleaseString(namel);
	ReleaseString(scorel);
}

static Boolean ScoreFormHandleEvent(EventPtr event)
{
	if (event->eType == frmOpenEvent) {
		FormPtr frm = FrmGetActiveForm();
		FrmDrawForm(frm);
		DrawScoreBoard();
		return true;
	}
	if (event->eType == ctlSelectEvent) {
		if (event->data.ctlSelect.controlID == ScoreClearButton) {
			if (FrmAlert(ClearScoreAlert) == ClearScoreYesButton) {
				InitHighScores();
				EraseScoreBoard();
				return true;
			} 
			return false;
		}
		FrmReturnToForm(0);
		FrmUpdateForm(MainForm, 0);
		return true;
	}
	return false;
}

static Boolean NewScoreFormHandleEvent(EventPtr event)
{
	if (event->eType == frmOpenEvent) {

		VoidHand nameH =  MemHandleNew(dlkMaxUserNameLength + 1);	//40
		CharPtr nameP = (CharPtr) MemHandleLock(nameH);
		Word idx;
		FormPtr frm;
		short len;
		
		if (LastHighScore < 0) {
			char *s;
			*nameP = 0; 
			DlkGetSyncInfo(NULL, NULL, NULL, nameP, NULL, NULL);
			s = StrChr(nameP, ' ');
			if (s)
				*s = 0;
			nameP[HighScoreNameLen - 1] = 0;
		} else {
			StrCopy(nameP, HScores[LastHighScore].name);
		}
		len = StrLen(nameP);
		MemPtrUnlock(nameP);
		
		frm = FrmGetActiveForm();
		idx = FrmGetObjectIndex(frm, NewScoreNameField);
		FldSetTextHandle((FieldPtr)FrmGetObjectPtr(frm, idx),
				 (Handle) nameH);
		GrfSetState(false, false, true);
		FrmDrawForm(frm);
		FldSetSelection((FieldPtr)FrmGetObjectPtr(frm, idx), 0, len);
		FrmSetFocus(frm, idx);

		return true;
		
	} else if (event->eType == ctlSelectEvent) {

		if (event->data.ctlSelect.controlID == NewScoreOKButton) {
			FormPtr frm = FrmGetActiveForm();
			Word idx = FrmGetObjectIndex(frm, NewScoreNameField);
			CharPtr nameP = FldGetTextPtr((FieldPtr)FrmGetObjectPtr(frm, idx));
			if (*nameP) {
				AddHighScore(nameP, Score);
				FrmGotoForm(ScoreForm);
				return true;
			}	
		}
		FrmReturnToForm(0);
		FrmUpdateForm(MainForm, 0);
		return true;
	}
	return false;
}


static void MyColorForm(FormPtr old) {
	FormPtr frm;

	frm = FrmInitForm(ColorForm);
	FrmSetActiveForm(frm);
	FrmDoDialog(frm);
	FrmDeleteForm(frm);
	if (old)
		FrmSetActiveForm(old);
}


static void ShowAbout(FormPtr old)
{
	FormPtr frm;
	ULong romVersion;

	frm = FrmInitForm(AboutForm);
	FrmSetActiveForm(frm);
	FrmDoDialog(frm);
	FrmDeleteForm(frm);
	if (old)
		FrmSetActiveForm(old);
		
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if ( romVersion >= 0x03501000)	 // COLOR
		MyColorForm(old);
	
}
           
static Boolean MainFormHandleEvent(EventPtr event)
{
	FormPtr frm;
	short pos;
	static short last = -1;
	
	switch (event->eType) {
	
	case frmOpenEvent:
		frm = FrmGetActiveForm();
		FrmDrawForm(frm);
		DrawBoard();
		return true;
	
	case frmUpdateEvent:
		if (!NFree)
			InitBoard();
		DrawBoard();
		return true;
		
	case penDownEvent:
		if (last < 0) {
			pos = GetBallPos(event->screenX, event->screenY);
			if (pos >= 0) {
				if (SelectAllowed(pos)) {
					last = pos;
					InvertBall(last);
				}
			}
			return true;
		}
		break;
		
	case penUpEvent:
		if (last >= 0) {
			pos = GetBallPos(event->screenX, event->screenY);
			if (pos == last)
				SelectBall(pos);
			else 
				InvertBall(last);
			last = -1;
			return true;
		}	
		break;
		
	case menuEvent:
		switch (event->data.menu.itemID) {
		case GameNew:
			InitBoard();
			DrawBoard();
			break;
		case GameShowHideNext:
			Status ^= StatusShowNext;
			ReDrawStatus();
			break;
		case GameInstructions:
			FrmHelp(InstructionsStr);
			break;
		case GameHighScores:
			FrmPopupForm(ScoreForm);
			break;
		case GameAbout:
			ShowAbout(FrmGetActiveForm());
			break;
		}
		return true;
	default:
		break;
	}
	
	return false;
}


void SayBye() {
	FrmAlert(ColorAlert);				
}


static void StartApplication()
{
	Word prefSize;
	int doinit = 0;
	int i;
	
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	
	prefSize = sizeof(Prefs);
	
	if (romVersion < version20)
		doinit = PrefGetAppPreferencesV10(appFileCreator, 0,
						  &Prefs, prefSize) == false;
	else
	   	doinit = PrefGetAppPreferences(appFileCreator, appSavedGameID,
					       &Prefs, &prefSize, true) ==
                         noPreferenceFound || prefSize != sizeof(Prefs);
		
	
	
	if (doinit) {
		ShowAbout(0);
		InitBoard();
		InitHighScores();
		AddHighScore("Begemot", 960);
		AddHighScore("Lilka", 1128);
		AddHighScore("Jerome Ladhuie", 1872);
		LastHighScore = -1;
		Status |= StatusShowNext;
		reg = 50;						// only 30 launches;
	} else {
		if (romVersion >= 0x03501000) { // COLOR
			if (reg) {
				MyColorForm(NULL);
				reg--;
				if (!reg)
					SayBye();
			} else 
				if (!Registered()) {
					romVersion = version20;
				}
			
		}
	}
}

static void StopApplication()
{
	if (romVersion < version20)
		PrefSetAppPreferencesV10(appFileCreator, 0, &Prefs,
					 sizeof(Prefs));
	else 
		PrefSetAppPreferences(appFileCreator, appSavedGameID,
				      appSavedGameVersion, &Prefs, 
				      sizeof(Prefs), true);
	if (romVersion >= 0x03501000) { // COLOR
		int	i;
		for (i=0;i<7;i++) {
				if (vp[i]) {
					MemHandleUnlock(vh[i]);
					vp[i] = NULL;
				}
				if 	(vh[i]) {
					DmReleaseResource(vh[i]);
					vh[i] = NULL;
				}
			}
		BmpDelete(imageBoard);
		BmpDelete(imageReverseBoard);
		err = WinScreenMode(scrDisplayModeSetToDefaults, NULL, NULL, NULL, NULL);
	}
}

static Boolean ApplicationHandleEvent(EventPtr event)
{
	FormPtr	frm;
	Int		formId;
	Boolean	handled = false;

	if (event->eType == frmLoadEvent) {
		formId = event->data.frmLoad.formID;
		frm = FrmInitForm(formId);
		FrmSetActiveForm(frm);

		switch (formId) {
		case MainForm:
			FrmSetEventHandler(frm, MainFormHandleEvent);
			break;
		case ScoreForm:
			FrmSetEventHandler(frm, ScoreFormHandleEvent);
			break;
		case NewScoreForm:
			FrmSetEventHandler(frm, NewScoreFormHandleEvent);
			break;
		}
		handled = true;
	}
	return handled;
}


static void EventLoop(void)
{
	EventType	event;
	Word		error;
	
	do {
		EvtGetEvent(&event, evtWaitForever);
		if (! SysHandleEvent(&event))
			if (!MenuHandleEvent(0, &event, &error))
				if (!ApplicationHandleEvent(&event))
					FrmDispatchEvent(&event);
	} while (event.eType != appStopEvent);
}

//#define Temp 1

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {

#ifdef Temp
DmOpenRef dmRef;
#endif

	if (cmd == sysAppLaunchCmdNormalLaunch) {
#ifdef Temp
		dmRef = DmOpenDatabaseByTypeCreator('DATA',appFileCreator,dmModeReadOnly);
		if (dmRef) {
#endif
	    	StartApplication();
    	
			FrmGotoForm(MainForm);
			EventLoop();
			StopApplication();
#ifdef Temp
		    DmCloseDatabase(dmRef);
		}
#endif
	}
	return 0;
}


unsigned int Registered() {
//.............
}