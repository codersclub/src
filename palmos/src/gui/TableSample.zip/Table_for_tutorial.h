/*****************************************************************************
 *
 * Created with Falch.net DeveloperStudio
 * http://www.falch.net/
 * 
 * Created : 06.11.2000 00:44:36
 * Creator : Administrator
 *
 ****************************************************************************/
Int16 rows;

Boolean frmMain_HandleEvent(EventPtr event);
Boolean InitTable(Int16);
Boolean GetTextFromField();
Boolean DrawTable();