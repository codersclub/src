/*****************************************************************************
 *
 * Created with Falch.net DeveloperStudio
 * http://www.falch.net/
 * 
 * Created : 06.11.2000 00:44:36
 * Creator : Administrator
 *
 ****************************************************************************/
#include <PalmOS.h>
#include <SysEvtMgr.h>

#include "Table_for_tutorial.h"
#include "Table_for_tutorial_res.h"

/****************************************************************************/

static int StartApplication(void)
{
	FrmGotoForm(frmMain);
	return 0;
}

static Boolean ApplicationHandleEvent(EventPtr event)
{
	UInt16 formID;
	FormPtr form;
	Boolean handled = false;
	
	// Application event loop
	switch (event->eType)
	{
		case frmLoadEvent:
			// Handle form load events
			formID = event->data.frmLoad.formID;
			form = FrmInitForm(formID);
			FrmSetActiveForm(form);		

			switch (formID)
			{
				case frmMain:
					// Set event handler for frmMain
					FrmSetEventHandler(form, (FormEventHandlerPtr) frmMain_HandleEvent);
					break;
			}
			handled = true;
			break;
	}

	return handled;
}

static void EventLoop(void)
{
	UInt16 error;
	EventType event;

	// Main event loop
	do
	{
		// Get next event
		EvtGetEvent(&event, evtWaitForever);
	
		// Handle event
		if (!SysHandleEvent(&event))
		{
			if (!MenuHandleEvent(0, &event, &error))
			{
				if (!ApplicationHandleEvent(&event))
					FrmDispatchEvent(&event);	
			}
		}
	}
	while (event.eType != appStopEvent);
}

static void StopApplication(void)
{
	// Insert stop code here
	FrmCloseAllForms();
}

/****************************************************************************/

UInt32 PilotMain(UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
	int error;
	
	if (cmd == sysAppLaunchCmdNormalLaunch)
 	{
		// Application start code
		error = StartApplication();
		if (error)
			return error;
		
		// Maintain event loop
		EventLoop();

		// Stop application 
		StopApplication();
	}

	return 0;
}

/****************************************************************************/

