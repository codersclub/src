/*****************************************************************************
 *
 * Created with Falch.net DeveloperStudio
 * http://www.falch.net/
 * 
 * Created : 06.11.2000 00:44:36
 * Creator : Administrator
 *
 ****************************************************************************/
#define	frmMain	1000
#define	cmdClose	1000
#define	alAbout	1000
#define	tblTest	1002
#define	fldOutput	1004
#define	cmdView	1000
#define	trgRows	1004
#define	lstRows	1005
#define	trgCols	1006
#define	lstCols	1007
#define	pshbutton1	1004
#define	pshbutton2	1005
#define	pshbutton3	1006
#define	pshbutton4	1007
#define	pshbutton5	1008
#define	fldInsert	1010
#define	cmdInsert	1011
