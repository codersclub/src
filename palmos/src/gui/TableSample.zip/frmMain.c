/*****************************************************************************
 *
 * Created with Falch.net DeveloperStudio
 * http://www.falch.net/
 * 
 * Created : 06.11.2000 00:44:36
 * Creator : Administrator
 *
 ****************************************************************************/
#include <PalmOS.h>
#include <SysEvtMgr.h>

#include "Table_for_tutorial.h"
#include "Table_for_tutorial_res.h"   

/****************************************************************************/

static Boolean frmMain_cmdInsert_OnSelect(EventPtr event)
{
	// Insert code for cmdInsert
	GetTextFromField();
	return true;
}

static Boolean frmMain_fldInsert_OnSelect(EventPtr event)
{
	// Insert code for fldInsert
	return true;
}

static Boolean frmMain_pshbutton5_OnSelect(EventPtr event)
{
	// Insert code for pshbutton5
	rows = 5;
	InitTable(rows);
	DrawTable();

	return true;
}

static Boolean frmMain_pshbutton4_OnSelect(EventPtr event)
{
	// Insert code for pshbutton4
	rows = 4;
	InitTable(rows);
	DrawTable();

	return true;
}

static Boolean frmMain_pshbutton3_OnSelect(EventPtr event)
{
	// Insert code for pshbutton3
	rows = 3;
	InitTable(rows);
	DrawTable();
		
	return true;
}

static Boolean frmMain_pshbutton2_OnSelect(EventPtr event)
{
	// Insert code for pshbutton2
	rows = 2;
	InitTable(rows);
	DrawTable();
	
	return true;
}

static Boolean frmMain_pshbutton1_OnSelect(EventPtr event)
{
	// Insert code for pshbutton1
	rows = 1;
	InitTable(rows);
	DrawTable();
	
	return true;
}


static Boolean frmMain_tblTest_OnSelect(EventPtr event)
{
	// Insert code for tblTest
	return true;
}

/****************************************************************************/

Boolean frmMain_HandleEvent(EventPtr event)
{
	FormPtr form;
	Boolean handled = false;
	
	switch (event->eType)
	{
		case ctlSelectEvent:
			switch (event->data.ctlSelect.controlID)
			{
				// cmdInsert receives an event
				case cmdInsert:
					handled = frmMain_cmdInsert_OnSelect(event);
					break;
				// fldInsert receives an event
				case fldInsert:
					handled = frmMain_fldInsert_OnSelect(event);
					break;
				// pshbutton5 receives an event
				case pshbutton5:
					handled = frmMain_pshbutton5_OnSelect(event);
					break;
				// pshbutton4 receives an event
				case pshbutton4:
					handled = frmMain_pshbutton4_OnSelect(event);
					break;
				// pshbutton3 receives an event
				case pshbutton3:
					handled = frmMain_pshbutton3_OnSelect(event);
					break;
				// pshbutton2 receives an event
				case pshbutton2:
					handled = frmMain_pshbutton2_OnSelect(event);
					break;
				// pshbutton1 receives an event
				case pshbutton1:
					handled = frmMain_pshbutton1_OnSelect(event);
					break;
				case tblTest:
					handled = frmMain_tblTest_OnSelect(event);
					break;
			}
			break;
		case frmOpenEvent:
			// Repaint form on open
			form = FrmGetActiveForm();
			// Initialize the table before the form is drawn, since FrmDrawForm
			// also will draw the table.
			// Here it's initialized with 5 rows (which is the maximum).
			rows = 5;
			InitTable(rows);
			FrmDrawForm(form);
			handled = true;
			break;
	}

	return handled;
}
