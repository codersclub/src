/*****************************************************************************
 *
 * Created with Falch.net DeveloperStudio
 * http://www.falch.net/
 * 
 * Created : 06.11.2000 00:44:36
 * Creator : Finn Haukeboe
 *
 * DESCRIPTION: The table initialization procedure goes through one row at a
 * 				time. The table has three rows and three columns. A user can
 *				decrease or increase the number of rows with pushbuttons.
 *				NOTE: The table doesn't contain a database, so the user won't
 *				be able to save anything. Please take a look at the database
 *				sample (with tutorial) in the IDE's installation directory if
 *				you'd like to glue a database together with this table sample.
 *
 ****************************************************************************/
#include <PalmOS.h>
#include <SysEvtMgr.h>
#include <Rect.h>

#include "Table_for_tutorial.h"
#include "Table_for_tutorial_res.h"   

/****************************************************************************/

Boolean InitTable(Int16 rows)
{
	FormType *formP;
	TableType *tableP;
	static char *labels[] = {"", "Name", "Phone"};
	static char *numLabels[] = {"1", "2", "3", "4", "5"};
	FieldType *field;
	Int16 row, column, i, usable;
	
	// Get the form pointer
	formP = FrmGetActiveForm();
	
	// Get the table pointer
	tableP = FrmGetObjectPtr (formP, FrmGetObjectIndex(formP, tblTest));
	
	/****************/
	/* ROW NUMBER 0 */
	/****************/
	
	// Set the first cell (0,0) as a customTableItem.
	// We won't do anything with this cell in the further progress,
	// since nothing should be displayed in it.
	TblSetItemStyle (tableP, 0, 0, customTableItem);
	
	// Set the other cells style to static and uneditable labels,
	// since they'll only contain static text.
	for (column = 1; column < 3; column++)
	{
		// Set the cells that should be static as lableTableItem (static text)
		TblSetItemStyle (tableP, 0, column, labelTableItem);
		// Place the text (see above) inside the static label cells
		TblSetItemPtr (tableP, 0, column, labels[column]);
	}
	
	if (rows>1)
	{
		/****************/
		/* ROW NUMBER 1 */
		/****************/
		
		// The cell in the first column should be a static label
		TblSetItemStyle (tableP, 1, 0, labelTableItem);
		// The cells text should be a number (in this case number 1)	
		TblSetItemPtr (tableP, 1, 0, numLabels[0]);
	
		// For all columns (1 and 2)...
		for (column = 1; column < 3; column++)
		{
			// The cells should be editable text "fields"
			TblSetItemStyle (tableP, 1, column, textTableItem);
			// Set the integer value of the cells.
			// Note that the integer value (the last parameter)
			// is an arbitrary integer. Please see the API
			// documentation for more details.
			TblSetItemInt (tableP, 1, column, column);
		}
		
		if (rows>2)
		{
			/****************/
			/* ROW NUMBER 2 */
			/****************/
	
			// The cell in column 0 should be a static label (a number)
			TblSetItemStyle (tableP, 2, 0, labelTableItem);	
			// Set the cells text (number 2)
			TblSetItemPtr (tableP, 2, 0, numLabels[1]);
	
			// For all columns in this row...
			for (column = 1; column < 3; column++)
			{
				// The cells should be an editable text "field"
				TblSetItemStyle (tableP, 2, column, textTableItem);
				// Set the integer value to an arbitrary integer
				// (3 and 4 since 1 and 2 was used in the previous row)
				TblSetItemInt (tableP, 2, column, column+2);
			}
		
			if (rows>3)
			{
				/****************/
				/* ROW NUMBER 3 */
				/****************/
					
				// The cell in the first column should be a static label
				TblSetItemStyle (tableP, 3, 0, labelTableItem);
				// The cells text should be a number (in this case number 1)	
				TblSetItemPtr (tableP, 3, 0, numLabels[2]);
				
				// For all columns (1 and 2)...
				for (column = 1; column < 3; column++)
				{
					// The cells should be editable text "fields"
					TblSetItemStyle (tableP, 3, column, textTableItem);
					// Set the integer value of the cells.
					// Note that the integer value (the last parameter)
					// is an arbitrary integer. Please see the API
					// documentation for more details.
					TblSetItemInt (tableP, 3, column, column);
				}
				
				if(rows>4)
				{
					/****************/
					/* ROW NUMBER 4 */
					/****************/
						
					// The cell in the first column should be a static label
					TblSetItemStyle (tableP, 4, 0, labelTableItem);
					// The cells text should be a number (in this case number 1)	
					TblSetItemPtr (tableP, 4, 0, numLabels[3]);
					
					// For all columns (1 and 2)...
					for (column = 1; column < 3; column++)
					{
						// The cells should be editable text "fields"
						TblSetItemStyle (tableP, 4, column, textTableItem);
						// Set the integer value of the cells.
						// Note that the integer value (the last parameter)
						// is an arbitrary integer. Please see the API
						// documentation for more details.
						TblSetItemInt (tableP, 4, column, column);
					}					
				}
			}
		}
	}
	// The columns should be usable, in order to be able to view the table	
	for (i = 0; i < 3; i++)
		TblSetColumnUsable (tableP, i, true);
	
	// If the number of rows are smaller than the maximum, make the remaining
	// rows invisible.
	if (rows < 5)
	{
		for (i = rows; i<5; i++)
			TblSetRowUsable(tableP, i, false);
	}
	
	for (i=0; i<rows; i++)
	{	
		// Make the rows selectable, to make them highlight when touched
		TblSetRowSelectable (tableP, i, true);
		// Disable the opportunity to increase the rows height when writing more
		// text than the cell can view
		TblSetRowStaticHeight (tableP, i, true);
		// Make the rows display
		TblSetRowUsable(tableP, i, true);
	}
	
	return true;
}

/****************************************************************************/
// This function is only used when the user taps one of the pushbuttons. The
// reason we don't do this in the init function, is that the FrmDrawForm
// API call in frmMain.c also draws the table.
Boolean DrawTable()
{
	TableType 	*tableP;
	FormType 	*formP;
	
	formP	= FrmGetActiveForm();
	tableP 	= FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, tblTest));
	
	// Draw the table
	TblDrawTable(tableP);
}

/****************************************************************************/

Boolean GetTextFromField()
{
	TableType *tableP;
	FieldType *fieldP;
	FormType *formP;
	char *string, *string2;
	Int16 row, col;
	// This type can be found in the Rect.h file in the SDK
	RectangleType bounds; 
	
	formP  = FrmGetActiveForm();
	fieldP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, fldInsert));
	tableP = FrmGetObjectPtr(formP, FrmGetObjectIndex(formP, tblTest));
	
	// Get the text within the field.
	string = FldGetTextPtr(fieldP);
	if (string != NULL)
	{
		// Get the row and column numbers of the selected cell
		TblGetSelection(tableP, &row, &col);
		if (row > 0)
		{
			// Find the bounds of the selected cell
			TblGetItemBounds(tableP, row, col, &bounds);
			// Draw the string into the selected cell
			WinDrawChars(string, StrLen(string),bounds.topLeft.x, bounds.topLeft.y);
		}
	}
	return true;
}

/****************************************************************************/
