/**********************************************************************************************/
/* This program should only illustrate how to connect to the internet and download            */
/* a html file. We want to have the plain html source file to filter out information.         */
/* This sample opens a bank site to get stock information and stock quotes.                   */
/* The sample can be tested with the symbol TOI.FSE whixh graps the stock quote for           */
/* t-online (WKN 555770) from the market place Frankfurt.                                     */
/*                                                                                            */
/* Important:                                                                                 */
/* You need to have a moden configured, a network set up and the pilot itself must be able    */
/* to dial into your internet provider with your account.                                     */
/*                                                                                            */
/* You may configure an infrared modem (i.e. Nokia 7110) to be used as your modem.            */
/**********************************************************************************************/

#pragma	pack(2)
//#include	<Common.h>
//#include	<System/SysAll.h>
//#include	<System/MemoryMgr.h>
//#include	<UI/UIAll.h>
#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <NetMgr.h>

#include	"StockControl.h"
#include	"callbacks.h"

#define  SCAppID 'STCO' 
#define  HOSTNAME "informer2.comdirect.de"
#define  KURS_SITE1 "http://informer2.comdirect.de/de/detail/_pages/charts/main.html?sSymbol="
#define  AF_INET 2
#define  SOCK_STREAM 1

static void       EventLoop         (void);
static Boolean    frmSCEventHandler (EventPtr event);
static Boolean    frmPMEventHandler (EventPtr event);
static void       GetQuote          (void);
static Boolean    CmdOpen           (void);
static void       CmdClose          (void);
static Boolean    ConnectToHost     (char* hostname,int port);
static Boolean    GetHTML           (void);
static void       FormatResult      (void);

static Boolean Initialize = true;                  /* Do we need form initialization ? */
FormPtr        form;                               /* which is my current form ? */
UInt           AppNetRefnum;                       /* net lib reference number */
UInt           AppNetTimeout = 10000;              /* round about 10 seconds */
UInt           err;                                /* an error variable */
UInt           AppNeedNetLibClose;                 /* Do we need to close the net library ? */
int            sock = -1;                          /* a reference to an IP socket */
char           wrkbuf[15000];                      /* This is only a vage estimate of the html file size */
char           gSymbol[15] = "TOI.FSE";            /* We need to store the Symbol in a global */
char*          basep = NULL;                       /* some char pointers to scan the html result */
char*          OffPtr1 = NULL;
char*          OffPtr2 = NULL;
char*          ptr;
char           CRLF[3] = {13,10,0};                /* i need a line feed */
FieldPtr       pField;                             /* a pointer to a form's field */
int            formID;                             /* a form id */
EventType      event;                              /* an event structure */
Boolean        AnalyzeData = true;                 /* Do we want RAW HTML or analyzed data ? */

/**********************************************************************************************/
/* Main Entry point                                                                           */
/**********************************************************************************************/
DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{   
	if (cmd == sysAppLaunchCmdNormalLaunch)         /* program normaly launched ? */
	{

      /* we have to perform OS Version checking here and Net lib availability */
      /* still open */
      
      /* can we load the net library? not on 1.0, possibly on 2.0, always on 3.0 */	
      err = SysLibFind("Net.lib", &AppNetRefnum);
      if (err) 
         {
         if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) == (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
            {   
            ErrDisplay ("\nNet Library not found");
            }
         return err;
         }

		FrmGotoForm (frmStockControl);               /* load the form */
		EventLoop ();                                /* Start Event processing */

		}

	return 0;
}

/**********************************************************************************************/
/* Main Event Loop                                                                            */
/**********************************************************************************************/
static void EventLoop(void)
{
   do
   {
      EvtGetEvent(&event, evtWaitForever);
      if (SysHandleEvent(&event)) continue;
   	if (MenuHandleEvent (NULL, &event, &err)) continue;

      if (event.eType == frmLoadEvent)
      {
         formID = event.data.frmLoad.formID;
         form = FrmInitForm(formID);               /* initialize the form */
         FrmSetActiveForm(form);                   /* set form as active */
         
         switch (formID)
            {

            case frmStockControl:
               FrmSetEventHandler(form, (FormEventHandlerPtr) frmSCEventHandler);   /* set event routine */
               break;
               
            case frmProgress:
               FrmSetEventHandler(form, (FormEventHandlerPtr) frmPMEventHandler);   /* set event routine */
               break;

            }
            
      }
      FrmDispatchEvent(&event);                    /* dispatch the event to the active form */
   } while(event.eType != appStopEvent);           /* do we stop ? */
}

/**********************************************************************************************/
/* Main Form Event Handler                                                                    */
/**********************************************************************************************/
static Boolean frmSCEventHandler(EventPtr event)
{
   int	handled = 0;                              /* we assume the event to not beeing handled */

CALLBACK_PROLOGUE                                  /* little gcc 0.5.0 weakness workaround */
 
   switch (event->eType) 
      {
      case winEnterEvent:                          /* return from FrmPopupForm */
         if (basep)                                
            {
            form = FrmGetActiveForm();             /* get the active form here */
            pField = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldResult));
         	FldDelete (pField, 0, FldGetTextLength(pField)); 
            FldInsert(pField, basep, StrLen(basep));
            FldSetScrollPosition(pField,1);    
            MemPtrFree(basep);
            basep = NULL;
            }
         break;
         
      case frmOpenEvent:                           /* is it a form open event */
         form = FrmGetActiveForm();                /* get the active form here */
         FrmDrawForm(form);                        /* draw the form */
         FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldSymbol)), gSymbol, StrLen(gSymbol));/* default to something (t-online at Frankfurt)*/
         handled = 1;                              /* nothing else to do */
         break;
   
      case ctlSelectEvent:                         /* button pressed ? */
   
         if (event->data.ctlSelect.controlID == btnGetQuote) /* yes ... start actions */
            {
            pField = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldSymbol)); /* do we have a symbol entered ? */
            if ( pField->text != NULL)             /* yes we have */
               {
               StrCopy(gSymbol,pField->text);      /* We need to get the Symbol */
               FrmPopupForm(frmProgress);          /* Show Progress-meter */
               }
            else
               {
               FrmCustomAlert(altCustom,"No Symbol entered !!","","");  /* Warn the user */
               }  
            }

         if (event->data.ctlSelect.controlID == chkAnalyzedData)
            {
            AnalyzeData = true;                    /* we want the HTML data to be nicely formated */
            }
         if (event->data.ctlSelect.controlID == chkRawData)
            {
            AnalyzeData = false;                   /* we want RAW HTML Code */
            }

         handled = 1;
         break;
      
      }

CALLBACK_EPILOGUE                                  /* little gcc 0.5.0 weakness workaround */

   return handled;
}

/**********************************************************************************************/
/* Main Form Event Handler                                                                    */
/**********************************************************************************************/
static Boolean frmPMEventHandler(EventPtr event)
{
   int	handled = 0;                              /* we assume the event to not beeing handled */

CALLBACK_PROLOGUE                                  /* little gcc 0.5.0 weakness workaround */
 
   switch (event->eType) 
      {

      case frmOpenEvent:                           /* is it a form open event */
         form = FrmGetActiveForm();                /* get the active form here */
         FrmDrawForm(form);                        /* draw the form */
         GetQuote();
         FrmReturnToForm(frmStockControl);         /* Return to previous form */
         handled = 1;                              /* nothing else to do */
         break;
   
      
      }

CALLBACK_EPILOGUE                                  /* little gcc 0.5.0 weakness workaround */

   return handled;
}

/**********************************************************************************************/
/* Get Quote from the internet                                                                */
/**********************************************************************************************/
static void GetQuote(void)
   {

   FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), "Opening Connection", 18);
   FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), &CRLF[1],1);

   if (CmdOpen())                                  /* open the net library */
      {
      FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), "Connecting Host", 15);
      FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), &CRLF[1],1);
      if (ConnectToHost(HOSTNAME,80))              /* Net library successfuly opened! Connect to host */     
         {
         FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), "Getting HTML", 12);
         FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), &CRLF[1],1);
         GetHTML();                                /* Host found! Download HTML file */
         }
      FldInsert(FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldInfo)), "Closing Connection", 18);
      CmdClose();                                  /* Close the network connection */
      }
   }
   
/**********************************************************************************************/
/* Open the network connection (use modem to dial into the Internet Provider)                 */
/**********************************************************************************************/
static Boolean CmdOpen(void)
{
	UInt  ifErrs;
	long  ifCreator;
	UInt  ifInstance;
	
	/* If there are no network interfaces attached, inform the user */
	if (NetLibIFGet(AppNetRefnum, 0, &ifCreator, &ifInstance)) 
	   {
      FrmCustomAlert(altCustom,"NetLibInterface Error:","No Interfaces defined","");
	   return false;
      }
      
	err = NetLibOpen(AppNetRefnum, &ifErrs);        /* Now we can open the net library */

	if (err == netErrAlreadyOpen)                   /* Note: Net Lib was open, open count incremented */
	   { 
		err = 0;                                     /* this is not realy an error */
		}
		
	if (err) 
	   {
	   switch (err)
	      {
         case netErrOutOfMemory:
            FrmCustomAlert(altCustom,"NetLibOpen Error:","Out of Memory","");
            break;
            
         case netErrNoInterfaces:
            FrmCustomAlert(altCustom,"NetLibOpen Error:","NoInterfaces","");
            break;
            
         case netErrPrefNotFound:
            FrmCustomAlert(altCustom,"NetLibOpen Error:","Preferences not found","");
            break;
	      }
      
		return false;
		}
		
	AppNeedNetLibClose++;

	if (ifErrs)                                     /* Any errors bringing up the interfaces ?? */
	   {
      UInt  index;
      short up;
      UInt  settingSize;
      Char  ifName[32];
		
		if (ifErrs == netErrPrefNotFound) 
		   {
         FrmCustomAlert(altCustom,"Interface Error:","This most likely means that your internet setup is incomplete.","Switch to the Network preference panel and check your setup.");			}

		for (index = 0; 1; index++)                  /* scan interfaces if they come up */
         {
			if (NetLibIFGet(AppNetRefnum, index, &ifCreator, &ifInstance)) break;

			settingSize = sizeof(up);
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance, netIFSettingUp, &up, &settingSize);
			if (err || up) continue;
			
			settingSize = 32;
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance, netIFSettingName, ifName, &settingSize);
			if (err) continue;

         StrCopy (wrkbuf,"Interface ");
         StrCat  (wrkbuf,ifName);
         StrCat  (wrkbuf," did not come up.");
         FrmCustomAlert(altCustom,"Interface Error",wrkbuf,"");
			}
   	
   	NetLibClose(AppNetRefnum, true);             /* Due to interface errors close the net library */
   	return false;
		}
		
   return true;                                    /* Net library opened successfuly */
   
}
    
/**********************************************************************************************/
/* Close the network library                                                                  */
/**********************************************************************************************/
static void CmdClose(void)
{
	if (AppNeedNetLibClose) 
	   {
      NetLibSocketClose(AppNetRefnum,  sock, AppNetTimeout, &err); /* Important to free up memory */
   	NetLibClose(AppNetRefnum, true);             /* you may want to ask the user to keep the ... */
	                                                /* ... connection open fur further activities ... */
	                                                /* ... such like email synchronization. ... */
	                                                /* if YES pass false as argument 2 */

	   AppNeedNetLibClose--;
	   }

	return;
}

/**********************************************************************************************/
/* Now that we are connected to the Internet Provider we need to lookup the destination host  */
/**********************************************************************************************/
static Boolean ConnectToHost(char* hostname,int port)
{
   NetHostInfoPtr host = NULL;
   NetHostInfoBufType AppHostInfo;
   struct NetSocketAddrINType sain;
   int rc = 0;
      
   host = NetLibGetHostByName(AppNetRefnum, hostname, &AppHostInfo, AppNetTimeout, &err);

	if (!host)
      {
      FrmCustomAlert(altCustom,"Could not connect to host",HOSTNAME,"I'm sorry");
      return false;
      }
   
                                                   /* We have found the host. Great success.....*/
   
   MemSet(&sain,sizeof(sain),0);                   /* reset structure */
   
   if (AppHostInfo.address[0] != 0)                /* copy host IP address from AppHostInfo */
      {
      MemMove(&sain.addr,&AppHostInfo.address[0],sizeof(AppHostInfo.address[0])); /* in the POSE the first field (IP-Address) was 0.0.0.0 - at least in my system ?!?! */
      }
   else
      {
      MemMove(&sain.addr,&AppHostInfo.address[1],sizeof(AppHostInfo.address[1]));
      }
   sain.family = AF_INET;
   sain.port = port;

   sock = NetLibSocketOpen(AppNetRefnum,AF_INET,SOCK_STREAM,0,AppNetTimeout,&err); /* open a TCP/IP socket */

   if (sock < 0) return false;                     /* no socked could be opened */

   if (NetLibSocketConnect(AppNetRefnum, sock,(void*)&sain,sizeof(sain),AppNetTimeout,&err) < 0)
      {

      StrIToA(wrkbuf,err);
      
      switch (err)
         {
         case netErrTimeout:
            StrCat(wrkbuf," = netErrTimeout");
            break;
            
         case netErrNotOpen:
            StrCat(wrkbuf," = netErrNotOpen");
            break;
            
         case netErrParamErr:
            StrCat(wrkbuf," = netErrParamErr");
            break;
            
         case netErrSocketNotOpen:
            StrCat(wrkbuf," = netErrSocketNotOpen");
            break;
            
         case netErrSocketBusy:
            StrCat(wrkbuf," = netErrSocketBusy");
            break;
            
         case netErrNoInterfaces:
            StrCat(wrkbuf," = netErrNoInterfaces");
            break;
            
         case netErrPortInUse:
            StrCat(wrkbuf," = netErrPortInUse");
            break;
            
         case netErrQuietTimeNotElapsed:
            StrCat(wrkbuf," = netErrQuietTimeNotElapsed");
            break;
            
         case netErrInternal:
            StrCat(wrkbuf," = netErrInternal");
            break;
            
         case netErrTooManyTCPConnections:
            StrCat(wrkbuf," = netErrTooManyTCPConnections");
            break;
            
        }
      
      FrmCustomAlert(altCustom,"can't establish TCP/IP socket connection"," Error Code : ", wrkbuf);
      NetLibSocketClose(AppNetRefnum, sock, AppNetTimeout, &err);/* get rid of the socket if any */
      sock = -1;                                   /* none */
      return false;
      }  
      
   return true; /* TCP/IP socket connected. Great. Now I have a living connection to the host */
   
   }

/**********************************************************************************************/
/* Now we can start downloading the HTML file.                                                */
/**********************************************************************************************/
static Boolean GetHTML(void)
   {
   int bc = 0;                                     /* byte count */
   char b;                                         /* one char */
   int ret;
   int len;
   
   StrCopy(wrkbuf,"GET ");                         /* prepare the GET "bladibla" statement */
   StrCat (wrkbuf, KURS_SITE1);                    /* prepare the GET "bladibla" statement */
   StrCat(wrkbuf, gSymbol);
   StrCat (wrkbuf," HTTP/1.0");
   
   StrCat(wrkbuf,CRLF);
   StrCat(wrkbuf,"User-Agent: StockControl");
   StrCat(wrkbuf,CRLF);
   StrCat(wrkbuf,CRLF);

   do {
      int sent = NetLibSend(AppNetRefnum, sock, wrkbuf+bc, StrLen(wrkbuf)-bc, 0, 0, 0, AppNetTimeout, &err);  /* now we send the request */
      if (sent <= 0)
         {
         FrmCustomAlert(altCustom,"Error while sending request","","");
         return false;
         }
      bc += sent;
      } while (bc !=StrLen(wrkbuf));
   
   bc = 0;
   basep = ptr = MemPtrNew(32767);                 /* prepare my receive buffer (assumed memeory is avail!!) */
   MemSet(ptr,32767,0);                            /* initialize wit 0 so string is always terminated */
   do 
      {
      bc++;
      } while (ret=NetLibReceive(AppNetRefnum, sock, ptr++, 1, 0, 0, 0, AppNetTimeout,&err) && bc < 32767 );
   
   if (bc <= 1)
      {
      FrmCustomAlert(altCustom,"Sorry: can't receive any data.","","");
      *basep = 0;
      return;
      }
      
   ptr = OffPtr1 = basep;
   
   if (AnalyzeData)
      {
      OffPtr1 = StrStr(ptr,"<td align=left>Aktueller Kurs</td>");
      if (OffPtr1)
         {
         OffPtr2 = StrStr(OffPtr1,"</table>");
         if (OffPtr2) *OffPtr2 = 0;
      	FormatResult();
         }
      else
         {
         StrCopy(wrkbuf, "(not found)");
         }
         
      StrCopy(basep,wrkbuf);
      }   
   }

/**********************************************************************************************/
/* Format the HTML data. Strip HTML tags and extract valuable information                     */
/**********************************************************************************************/
static void FormatResult(void)
   {
   char* SrcPtr;
   char* DestPtr;
   
   MemSet(wrkbuf,sizeof(wrkbuf),0);
   
/* Aktueller Kurs */
   SrcPtr = StrStr(OffPtr1,"Aktueller Kurs");
   SrcPtr += 25;
   StrCopy (wrkbuf, "Aktueller Kurs = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* Kurszeit */
   SrcPtr = StrStr(SrcPtr,"Kurszeit");
   SrcPtr += 19;
   StrCat (wrkbuf, "Kurszeit = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;

/* Er�ffnungskurs */
   SrcPtr = StrStr(SrcPtr,"Er&ouml;ffnungskurs");
   SrcPtr += 30;
   StrCat (DestPtr,"Er�ffnungskurs = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* Tagesh�chstkurs */
   SrcPtr = StrStr(SrcPtr,"Tagesh&ouml;chstkurs");
   SrcPtr += 31;
   StrCat (DestPtr,"Tagesh�chstkurs = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* Tagestiefstkurs */
   SrcPtr = StrStr(SrcPtr,"Tagestiefstkurs");
   SrcPtr += 26;
   StrCat (DestPtr,"Tagestiefstkurs = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* 52W Hoch */
   SrcPtr = StrStr(SrcPtr,"52W Hoch");
   SrcPtr += 19;
   StrCat (DestPtr,"52W Hoch = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* 52W Tief */
   SrcPtr = StrStr(SrcPtr,"52W Tief");
   SrcPtr += 19;
   StrCat (DestPtr,"52W Tief = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* Jahreshoch */
   SrcPtr = StrStr(SrcPtr,"Jahreshoch");
   SrcPtr += 21;
   StrCat (DestPtr,"Jahreshoch = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   StrCat (wrkbuf, &CRLF[1]);
   DestPtr++;   

/* Jahrestief */
   SrcPtr = StrStr(SrcPtr,"Jahrestief");
   SrcPtr += 21;
   StrCat (DestPtr,"Jahrestief = ");
   DestPtr = &wrkbuf[StrLen(wrkbuf)];
   do
      {
      *DestPtr++ = *SrcPtr++;
      } while (*SrcPtr != '<');
   }