@echo off
@cls
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist StockControl.o del StockControl.o 
@if exist StockControl del StockControl 
@if exist StockControl.prc del StockControl.prc
echo compile the resource files
pilrc.exe StockControl.rcp 
ren Tbmp03e9.bin tAIB03e9.bin
cls 
echo Step 1 -----------------------------------------------------
m68k-palmos-gcc -g -DDEBUG -c StockControl.c -o StockControl.o
echo Step 2 -----------------------------------------------------
m68k-palmos-gcc -g -DDEBUG StockControl.o -o StockControl
echo Step 3 -----------------------------------------------------
m68k-palmos-obj-res StockControl
echo Step 4 -----------------------------------------------------
build-prc  StockControl.prc "StockControl" STCO *.grc *.bin
echo Step 5 -----------------------------------------------------
@del *.bin > nul
@del StockControl.o > nul
@del *.grc > nul
REM @del StockControl > nul
echo ------------------------------------------------------------
echo Compile done -----------------------------------------------
echo ------------------------------------------------------------
exit  