// C:\SC\StockControl.h
// Header File automaticaly generated from VFDIDE. Don't modify !!
// You will loose all manual modifications to this file!
// Generated: 01.09.2000 14:24:59
// (in case of errors please contact ogrossklaus@debitel.net)


#define frmStockControl 2000
#define frmProgress 2100
#define lblSymbolWKN 2005
#define lblResult 2006
#define fldSymbol 2003
#define fldResult 2004
#define fldInfo 2102
#define btnGetQuote 8928
#define chkAnalyzedData 2001
#define chkRawData 2002
#define altCustom 3000
#define altInfo 3001
#define SmallIcon 1001
#define VersionID 1
#define ApplNameID 1244
#define ApplID 1245
