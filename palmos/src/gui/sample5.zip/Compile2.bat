@echo off
@cls
@if exist error*.txt del error*.txt
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist ccs.o del ccs.o 
@if exist ccs del ccs 
@if exist ccs.prc del ccs.prc
echo compile the resource files
pilrc.exe ccs.rcp
echo Step 1-------------------------------------------------------------------
m68k-palmos-gcc -O1 -c ccs.c -o ccs.o
echo Step 2 ------------------------------------------------------------------
m68k-palmos-gcc -O1 ccs.o -o ccs 
echo Step 3 ------------------------------------------------------------------
m68k-palmos-obj-res ccs 
echo Step 4 ------------------------------------------------------------------
build-prc  ccs.prc "Contacts" CCSH *.grc *.bin
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist ccs.o del ccs.o 
@if exist ccs del ccs 
echo -------------------------------------------------------------------------
echo -------------------------------------- Compile done ---------------------
echo -------------------------------------------------------------------------
exit
