// Customer Contact Sheet CCSH
// Developed for Fred Golden
// by Ole Grossklaus with VFDIDE

//  Here are the steps that are required to add a field
// - Open the relevant page in form view
// - Add your control i.e. a Text box
// - Move all controls so that the screen looks good
// - open the css.c file
// - Goto the record definition starting with typedef struct
// - Add your field. Keep the overall size in mind Memo Overall Size = 3680 (max allowed = 4094)
// - Goto the section // Pointer to all the fields on the forms in order to access their data
// - Define a pointer to your new field
// - Goto the InitializeBlankRecord and initialize your new field (only required if it is different from "empty")
// - Goto XmitToMemopad and add your field's data so tzhat it gots transmitted at the end
// - goto InitializeFieldPointers and initialize the pointer you have declared above
// - goto SaveScreenDataToRecordPage and add your new field here (look at the others to see how)
// - goto LoadDataForPage and add your field here (look at the others to see how)
// - Run compilation
// - Install your application
// - (Never forget the maximum size of the memo of 4094 !)

#pragma	pack(2)
//#include	<Common.h>
//#include	<System/SysAll.h>
//#include	<UI/UIAll.h>
#include <PalmOS.h>
#include <PalmCompatibility.h>

// Include Resource File Definitions
#include	"ccs.h"

// Function Prototypes
static int	   StartApplication(void);
static void	   EventLoop(void);
static Boolean frmPageEventHandler(EventPtr event);
static void    SaveScreenDataToRecordPage(int Page);
static void    LoadDataForPage(int Page);
static void    InitializePointer(int formId);
static int     ButtonEvents(Word CtrlID);
static void    XmitToMemopad();

// Record Structure for an entire Data Record
typedef struct {
   // Overall Length must be less than 4094 (is now 3415 + length of lables=513 + NumOfFields=80 TOTAL = 4008)
   // If you want to add fields please reduce the size of other fields to ensure an absolute maximum of 4094 bytes
   // Page 1 Fields
   char P1ClientContact        [ 50];
   char P1Company              [ 50];   
   char P1ClientPhone          [ 30];   
   char P1ClientEmail          [ 50];   
   char P1ClientAddr1          [ 50];   
   char P1ClientAddr2          [ 50];   
   char P1ClientCity           [ 50];   
   char P1ClientState          [ 35];   
   Word ListIdxStates;                  
   char P1ClientZip            [ 10];   

   // Page 2 fields
   char P2ContactName          [ 50];   
   char P2ContactPhone         [ 30];   
   char P2ContactEmail         [ 50];   
   char P2ReferalName          [ 50];   
   char P2ReferalPhone         [ 30];   
   char P2ReferalEmail         [ 50];   

   // Page 3 Fields                     
   SWord P3eCommerce;                   
   SWord P3InformSite;                  
   SWord P3Manufacturer;                
   SWord P3Travel;                      
   SWord P3Finance;                     
   SWord P3NonProfit;                   
   SWord P3Retail;                      
   SWord P3Discount;                    
   SWord P3Other;                       
   char  P3OtherTxt            [ 50];   

   // Page 4 Fields
   char P4InetPresence         [  4];   
   Word ListIdxInetPresence;            
   char P4SiteSince            [  5];   
   Word ListIdxSiteSince;               
   char P4Unit                 [  9];   
   Word ListIdxUnit;                    
   char P4PrimeObjective       [1024];  
   char P4SecondaryObjective   [1024];  

   // Page 5 Fields
   char P5ClientIs             [ 11];   
   Word ListIdxClientIs;                
   char P5ClientSophistication [ 15];   
   Word ListIdxClientSophistication;    
   char P5PreviousOnlineAgency [255];   
   char P5OfflineAgency        [255];   
   char P5MktBudget_ty         [ 11];   
   char P5MktBudget_py         [ 11];   
   char P5OnlineBudget_ty      [ 11];   
   char P5OnlineBudget_py      [ 11];   

   // Page 6 Fields
   SWord P6Stat;                        
   SWord P6Branding;                    
   SWord P6Email;                       
   SWord P6Radio;                       
   SWord P6Print;                       
   SWord P6Optimization;                
   SWord P6TV;                          
   SWord P6Portal;                      
   SWord P6Bying;                       
   SWord P6Promotion;                   
   SWord P6Creative;                    
   SWord P6DrvTraffic;                  

}ClientRecType;

// Pointer to all the fields on the forms in order to access their data

// Page 1
FieldPtr	  fptrP1ClientContact;
FieldPtr	  fptrP1Company;
FieldPtr	  fptrP1ClientPhone;
FieldPtr	  fptrP1ClientEmail;
FieldPtr	  fptrP1ClientAddr1;
FieldPtr	  fptrP1ClientAddr2;
FieldPtr	  fptrP1ClientCity;
ControlPtr	  cptrP1ClientState;
ListPtr       lptrState;
FieldPtr	  fptrP1ClientZip;

// Page 2
FieldPtr	  fptrP2ContactName;
FieldPtr	  fptrP2ContactPhone;
FieldPtr	  fptrP2ContactEmail;
FieldPtr	  fptrP2ReferalName;
FieldPtr	  fptrP2ReferalPhone;
FieldPtr	  fptrP2ReferalEmail;

// Page 3
ControlPtr	  cptrP3eCommerce;
ControlPtr	  cptrP3InformSite;
ControlPtr	  cptrP3Manufacturer;
ControlPtr	  cptrP3Travel;
ControlPtr	  cptrP3Finance;
ControlPtr	  cptrP3NonProfit;
ControlPtr	  cptrP3Retail;
ControlPtr	  cptrP3Discount;
ControlPtr	  cptrP3Other;
FieldPtr      fptrP3OtherTxt;

// Page 4
ControlPtr	  cptrP4InetPresence;
ListPtr       lptrInetPresence;
ControlPtr	  cptrP4SiteSince;
ListPtr       lptrSiteSince;
ControlPtr	  cptrP4Unit;
ListPtr       lptrUnit;
FieldPtr	  fptrP4PrimeObjective;
FieldPtr	  fptrP4SecondaryObjective;

// Page 5
ControlPtr	  cptrP5ClientIs;
ListPtr       lptrClientIs;
ControlPtr	  cptrP5ClientSophistication;
ListPtr       lptrClientSophistication;
FieldPtr	  fptrP5PreviousOnlineAgency;
FieldPtr	  fptrP5OfflineAgency;
FieldPtr	  fptrP5MktBudget_ty;
FieldPtr	  fptrP5MktBudget_py;
FieldPtr	  fptrP5OnlineBudget_ty;
FieldPtr	  fptrP5OnlineBudget_py;

// Page 6
ControlPtr	  cptrP6Stat;
ControlPtr	  cptrP6Branding;
ControlPtr	  cptrP6Email;
ControlPtr	  cptrP6Radio;
ControlPtr	  cptrP6Print;
ControlPtr	  cptrP6Optimization;
ControlPtr	  cptrP6TV;
ControlPtr	  cptrP6Portal;
ControlPtr	  cptrP6Bying;
ControlPtr	  cptrP6Promotion;
ControlPtr	  cptrP6Creative;
ControlPtr	  cptrP6DrvTraffic;

// Some other variables

EventType     event;                   // To handle events that comes from the Pilot
ClientRecType ClientRec;               // The actual record holding the data until transfer
FormPtr       form;                    // a Pointer to the current form being displayed
int           currForm = frmPage1;     // Starting with Page1
char		  ClipText[4095];          // A work-buffer to combine the record to a memo


//#################################################################
// This routine initializes the record and deletes all entered data

static void InitializeBlankRecord(void)
{
   // this memset initializes all char fields to be empty
   MemSet(&ClientRec,sizeof(ClientRecType),0);   

   // listIdx = -1 is "nothing selected"
   ClientRec.ListIdxStates               = -1;
   ClientRec.ListIdxInetPresence         = -1;
   ClientRec.ListIdxSiteSince            = -1;
   ClientRec.ListIdxUnit                 = -1;
   ClientRec.ListIdxClientIs             = -1;
   ClientRec.ListIdxClientSophistication = -1;

   // other initialization code goes here

}

//#################################################################
// Main entry point of a pilot program

DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
   if (cmd == sysAppLaunchCmdNormalLaunch)
   { 
      FrmGotoForm(frmPage1);        // open Page one
      EventLoop();                  // Start event processing
   }
   return 0;
}

//#################################################################
// Main ecvent loop that deals with the incoming events

static void EventLoop(void)
{

   InitializeBlankRecord();        // Reset the record

   do
   {
      EvtGetEvent(&event, 500);    // look for a new event

                                   // Give the system a chance to handle the event
      if (SysHandleEvent(&event)) continue; 

                                   // If it is a form load event do the form init stuff
      if (event.eType == frmLoadEvent)
      {
         form = FrmInitForm(event.data.frmLoad.formID);
         FrmSetActiveForm(form);
         FrmSetEventHandler(form, (FormEventHandlerPtr) frmPageEventHandler);
      }

      FrmDispatchEvent(&event);
   } while(event.eType != appStopEvent);
}

//#################################################################
// This is the event handler for the form events

static Boolean frmPageEventHandler(EventPtr event)
{
   int       handled = 0;
   EventType eT;
 
   switch (event->eType) 
   {

   case frmOpenEvent:                // Is a form opened ??
      form = FrmGetActiveForm();     // Set the form pointer
      FrmDrawForm(form);             // Show the current form
      LoadDataForPage(currForm);     // Load the forms fields with the data stored in the record 
      handled = 1;                   // This event is processed !
      break;    

   case ctlSelectEvent:              // Click on a button ???
      handled = ButtonEvents (event->data.ctlEnter.controlID);
      break;

   }

   return handled;
}

//#################################################################
// if a button is pressed then process the actions

static int ButtonEvents(Word CtrlID)
{
   Word Response;

   switch(CtrlID)    
      {

       // It is the same logic for all screens:
       // Save the entered data to the underlying record
       // Goto the selected form
       // (A LoadRecord is done elsewhere !!)

       case cmdGotoPage12:
          SaveScreenDataToRecordPage(frmPage1);
          currForm = frmPage2;
          FrmGotoForm(frmPage2);
          return 1;
          break;

       case cmdGotoPage23:
          SaveScreenDataToRecordPage(frmPage2);
          currForm = frmPage3;
          FrmGotoForm(frmPage3);
          return 1;
          break;

       case cmdGotoPage34:
          SaveScreenDataToRecordPage(frmPage3);
          currForm = frmPage4;
          FrmGotoForm(frmPage4);
          return 1;
          break;

       case cmdGotoPage45:
          SaveScreenDataToRecordPage(frmPage4);
          currForm = frmPage5;
          FrmGotoForm(frmPage5);
          return 1;
          break;

       case cmdGotoPage56:
          SaveScreenDataToRecordPage(frmPage5);
          currForm = frmPage6;
          FrmGotoForm(frmPage6);
          return 1;
          break;

       case cmdGotoPage65:
          SaveScreenDataToRecordPage(frmPage6);
          currForm = frmPage5;
          FrmGotoForm(frmPage5);
          return 1;
          break;

       case cmdGotoPage54:
          SaveScreenDataToRecordPage(frmPage5);
          currForm = frmPage4;
          FrmGotoForm(frmPage4);
          return 1;
          break;

       case cmdGotoPage43:
          SaveScreenDataToRecordPage(frmPage4);
          currForm = frmPage3;
          FrmGotoForm(frmPage3);
          return 1;
          break;

       case cmdGotoPage32:
          SaveScreenDataToRecordPage(frmPage3);
          currForm = frmPage2;
          FrmGotoForm(frmPage2);
          return 1;
          break;

       case cmdGotoPage21:
          SaveScreenDataToRecordPage(frmPage2);
          FrmGotoForm(frmPage1);
          currForm = frmPage1;
          return 1;
          break;

       // Cancel always clears the entered data and jumps back to Page 1
       case cmdP1Cancel:
       case cmdP2Cancel:
       case cmdP3Cancel:
       case cmdP4Cancel:
       case cmdP5Cancel:
       case cmdP6Cancel:
         if (FrmAlert(alertRealyCancel) == 0) 
            {
            InitializeBlankRecord();
            currForm = frmPage1;
            FrmGotoForm(frmPage1);
            }
         return 1;
         break;

      // Save Record combines all fields to ONE memo and passes the memo to the memopad
      case cmdSave:
         if (FrmAlert(alertSaveRecord) == 0)       // Get a user confirmation first
            {
            SaveScreenDataToRecordPage(frmPage6);  // First save data of last screen
            XmitToMemopad();                       // transfer the data
            InitializeBlankRecord();               // Remove entered data from record
            currForm = frmPage1;                   // Jump back to page 1
            FrmGotoForm(frmPage1);
            }
         break;      
      }

   return 0;

}

//#################################################################
// This routine combines the fields to ONE memo

static void XmitToMemopad()
{

   DmOpenRef MemopadDB;             // Get a reference to the memopad DB
   VoidHand  lrecH;                 // Get a reference to ONE memopad record
   VoidPtr   lrecP;                 // Get a pointer to ONE record
   Int       idx;
   char      crlf[2] = {10,0};      // Just terminate each field with a LineFeed
   char      off [4] = "off";       // State unchecked of a checkbox
   char      on  [3] = "on";        // State checked of a checkbox
   
   ClipText[0] = 0;                 // Clear the memopad buffer


   // The transmission is done as follows:
   // Add the field lable. If this is changed please bare in mind the overall size of 4094
   // Add the record data of that particular field
   // Add a line break

   // Depending on the type of field slightly different methods needs to be used

   // Transmit all fields of page 1
   StrCat(ClipText,"Contact:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientContact);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Company:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1Company);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Phone:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientPhone);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Email:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientEmail);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Address1:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientAddr1);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Address2:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientAddr2);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"City:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientCity);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"State:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientState);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Zip:");
   StrCat(ClipText,(CharPtr)&ClientRec.P1ClientZip);
   StrCat(ClipText,crlf);


   // Transmit all fields of page 2
   StrCat(ClipText,"Organic Contact:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ContactName);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Phone:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ContactPhone);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Email:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ContactEmail);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Referal Name:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ReferalName);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Phone:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ReferalPhone);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Email:");
   StrCat(ClipText,(CharPtr)&ClientRec.P2ReferalEmail);
   StrCat(ClipText,crlf);

   // Transmit all fields of page 3
   StrCat(ClipText,"eCommerce:");
   if (ClientRec.P3eCommerce==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Information Site:");
   if (ClientRec.P3InformSite==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Travel:");
   if (ClientRec.P3Travel==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Manufacturer:");
   if (ClientRec.P3Manufacturer==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Finance:"); //167
   if (ClientRec.P3Finance==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"NonProfit:");
   if (ClientRec.P3NonProfit==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Retail:");
   if (ClientRec.P3Retail==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Discount:");
   if (ClientRec.P3Discount==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Other:");
   if (ClientRec.P3Other==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"OtherText:");
   StrCat(ClipText,(CharPtr)&ClientRec.P3OtherTxt);
   StrCat(ClipText,crlf);

   // Transmit all fields of page 4
   StrCat(ClipText,"InetPresence:"); //222
   StrCat(ClipText,(CharPtr)&ClientRec.P4InetPresence);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"HasSiteSince:");
   StrCat(ClipText,(CharPtr)&ClientRec.P4SiteSince);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Unit:");
   StrCat(ClipText,(CharPtr)&ClientRec.P4Unit);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"PrimeObjective:");
   StrCat(ClipText,(CharPtr)&ClientRec.P4PrimeObjective);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"SecondObjective:");
   StrCat(ClipText,(CharPtr)&ClientRec.P4SecondaryObjective);
   StrCat(ClipText,crlf);

   // Transmit all fields of page 5
   StrCat(ClipText,"ClientIs:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5ClientIs);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"ClientSophistication:"); //301
   StrCat(ClipText,(CharPtr)&ClientRec.P5ClientSophistication);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"PrevOnlineAgency:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5PreviousOnlineAgency);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"OfflineAgency:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5OfflineAgency);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"MarketingBudgetThisYear:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5MktBudget_ty);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"MarketingBudgetPrevYear:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5MktBudget_py);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"OnlineBudgetThisYear:");//401
   StrCat(ClipText,(CharPtr)&ClientRec.P5OnlineBudget_ty);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"OnlineBudgetPrevYear:");
   StrCat(ClipText,(CharPtr)&ClientRec.P5OnlineBudget_py);
   StrCat(ClipText,crlf);

   // Transmit all fields of page 6
   StrCat(ClipText,"Stat:");
   if (ClientRec.P6Stat==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Branding:");
   if (ClientRec.P6Branding==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Email:");
   if (ClientRec.P6Email==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Radio:");
   if (ClientRec.P6Radio==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Print:");
   if (ClientRec.P6Print==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Optimization:");
   if (ClientRec.P6Optimization==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"TV:");
   if (ClientRec.P6TV==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Portal:");
   if (ClientRec.P6Portal==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Bying:");
   if (ClientRec.P6Bying==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Promotion:");
   if (ClientRec.P6Promotion==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"Creative:");
   if (ClientRec.P6Creative==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);

   StrCat(ClipText,"DrvTraffic:");
   if (ClientRec.P6DrvTraffic==0) StrCat(ClipText,off); else StrCat(ClipText,on);
   StrCat(ClipText,crlf);
 
   // Save entire string to Memopad

   // Open Memopad DB
   MemopadDB = DmOpenDatabaseByTypeCreator('DATA','memo',dmModeReadWrite);
   
   // Create a new Record
   lrecH = DmNewRecord(MemopadDB,&idx,StrLen(ClipText)+1);

   // Get a pointer to the record and lock the record
   lrecP = MemHandleLock(lrecH);     

   // set the redcord to 0
   DmSet(lrecP,0,StrLen(ClipText)+1,0);

   // Move the ClipTextData to the Memopad Record
   DmWrite(lrecP,0,ClipText,StrLen(ClipText));

   // some tidy up and close stuff
   MemHandleUnlock(lrecH);
   DmReleaseRecord(MemopadDB,idx,true);
   DmCloseDatabase(MemopadDB);


   // Notify that record is saved
   FrmAlert(alertRecordSaved);

   return;
}

//#################################################################
// This routine initializes the field pointers so that I can access the 
// data that is in one field.
// This is to be able to move the field entries to my Record structure
// and to set data stored in my record to fields that are drawn upon form load

static void InitializeFieldPointers(int frmID)
{

   switch(frmID)
   { 
      case frmPage1:
         fptrP1ClientContact        = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldContact3));
         fptrP1Company              = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldCompany));
         fptrP1ClientPhone          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldPhone3));
         fptrP1ClientEmail          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldEmail3));
         fptrP1ClientAddr1          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldAddress1));
         fptrP1ClientAddr2          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldAddress2));
         fptrP1ClientCity           = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldCity));
         cptrP1ClientState          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popState));
         lptrState                  = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstStateList));
         fptrP1ClientZip            = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldZip));
         break;

      case frmPage2:
         fptrP2ContactName          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldName1));
         fptrP2ContactPhone         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldPhone1));
         fptrP2ContactEmail         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldEmail1));
         fptrP2ReferalName          = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldName2));
         fptrP2ReferalPhone         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldPhone2));
         fptrP2ReferalEmail         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldEmail2));
         break;

      case frmPage3:
         cptrP3eCommerce            = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkeCommerce));
         cptrP3InformSite           = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkInfoSite));
         cptrP3Manufacturer         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkManufacturer));
         cptrP3Travel               = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkTravel));
         cptrP3Finance              = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkFinance));
         cptrP3NonProfit            = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkNonProfit));
         cptrP3Retail               = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkRetail));
         cptrP3Discount             = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkDiscount));
         cptrP3Other                = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkOther));
         fptrP3OtherTxt             = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldOther));
         break;

      case frmPage4:
         cptrP4InetPresence         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popInetPresence));
         lptrInetPresence           = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstInetPresence));
         cptrP4SiteSince            = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popHasSiteSince));
         lptrSiteSince              = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstHasSiteSince));
         cptrP4Unit                 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popUnit));
         lptrUnit                   = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstUnit));
         fptrP4PrimeObjective       = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldPrimaryObjective));
         fptrP4SecondaryObjective   = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldSecondaryObjective));
         break;

      case frmPage5:
         cptrP5ClientIs             = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popClientIs));
         lptrClientIs               = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstClientIs));
         cptrP5ClientSophistication = FrmGetObjectPtr(form, FrmGetObjectIndex(form, popSophistication));
         lptrClientSophistication   = FrmGetObjectPtr(form, FrmGetObjectIndex(form, lstSophistication));
         fptrP5PreviousOnlineAgency = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldPrevOnline));
         fptrP5OfflineAgency        = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldOfflineAgency));
         fptrP5MktBudget_ty         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldMktBudget_ty));
         fptrP5MktBudget_py         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldMktBudget_py));
         fptrP5OnlineBudget_ty      = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldOnlineBudget_ty));
         fptrP5OnlineBudget_py      = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fldOnlineBudget_py));
         break;

      case frmPage6:
         cptrP6Stat                 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkStat));
         cptrP6Branding             = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkBranding));
         cptrP6Email                = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkEmail));
         cptrP6Radio                = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkRadio));
         cptrP6Print                = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkPrint));
         cptrP6Optimization         = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkOptimization));
         cptrP6TV                   = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkTV));
         cptrP6Portal               = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkPortal));
         cptrP6Bying                = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkBying));
         cptrP6Promotion            = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkPromotion));
         cptrP6Creative             = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkCreative));
         cptrP6DrvTraffic           = FrmGetObjectPtr(form, FrmGetObjectIndex(form, chkDrvTraffic));
         break;
   }
}

//#################################################################
// This routine moves all data that is entered in ONE screen into fields of 
// the underlying record. This is required in order to be able to navigate forms

static void SaveScreenDataToRecordPage(int frmID)
{

   InitializeFieldPointers(frmID);

   switch(frmID)
   { 
      case frmPage1:
         // Remove all previous entries
         ClientRec.P1ClientContact[0] = 0;
         ClientRec.P1Company      [0] = 0;
         ClientRec.P1ClientPhone  [0] = 0;
         ClientRec.P1ClientEmail  [0] = 0;
         ClientRec.P1ClientAddr1  [0] = 0;
         ClientRec.P1ClientAddr2  [0] = 0;
         ClientRec.P1ClientCity   [0] = 0;
         ClientRec.P1ClientState  [0] = 0;
         ClientRec.P1ClientZip    [0] = 0;

         // If data is entered move it to the record
         if (fptrP1ClientContact->text != NULL) StrCopy((CharPtr)&ClientRec.P1ClientContact, fptrP1ClientContact->text);
         if (fptrP1Company->text       != NULL) StrCopy((CharPtr)&ClientRec.P1Company,       fptrP1Company->text      );
         if (fptrP1ClientPhone->text   != NULL) StrCopy((CharPtr)&ClientRec.P1ClientPhone,   fptrP1ClientPhone->text  );
         if (fptrP1ClientEmail->text   != NULL) StrCopy((CharPtr)&ClientRec.P1ClientEmail,   fptrP1ClientEmail->text  );
         if (fptrP1ClientAddr1->text   != NULL) StrCopy((CharPtr)&ClientRec.P1ClientAddr1,   fptrP1ClientAddr1->text  );
         if (fptrP1ClientAddr2->text   != NULL) StrCopy((CharPtr)&ClientRec.P1ClientAddr2,   fptrP1ClientAddr2->text  );
         if (fptrP1ClientCity->text    != NULL) StrCopy((CharPtr)&ClientRec.P1ClientCity,    fptrP1ClientCity->text   );
         if (fptrP1ClientZip->text     != NULL) StrCopy((CharPtr)&ClientRec.P1ClientZip,     fptrP1ClientZip->text    );

         // for popup lists the following 2 lines are required
         if (LstGetSelectionText(lptrState,LstGetSelection(lptrState)) != NULL) StrCopy((CharPtr)&ClientRec.P1ClientState, LstGetSelectionText(lptrState,LstGetSelection(lptrState)));
         ClientRec.ListIdxStates = LstGetSelection(lptrState);

         break;

      case frmPage2:
         ClientRec.P2ContactName [0] = 0;
         ClientRec.P2ContactPhone[0] = 0;
         ClientRec.P2ContactEmail[0] = 0;
         ClientRec.P2ReferalName [0] = 0;
         ClientRec.P2ReferalPhone[0] = 0;
         ClientRec.P2ReferalEmail[0] = 0;

         if (fptrP2ContactName->text  != NULL) StrCopy((CharPtr)&ClientRec.P2ContactName,  fptrP2ContactName->text );
         if (fptrP2ContactPhone->text != NULL) StrCopy((CharPtr)&ClientRec.P2ContactPhone, fptrP2ContactPhone->text);
         if (fptrP2ContactEmail->text != NULL) StrCopy((CharPtr)&ClientRec.P2ContactEmail, fptrP2ContactEmail->text);
         if (fptrP2ReferalName->text  != NULL) StrCopy((CharPtr)&ClientRec.P2ReferalName,  fptrP2ReferalName->text );
         if (fptrP2ReferalPhone->text != NULL) StrCopy((CharPtr)&ClientRec.P2ReferalPhone, fptrP2ReferalPhone->text);
         if (fptrP2ReferalEmail->text != NULL) StrCopy((CharPtr)&ClientRec.P2ReferalEmail, fptrP2ReferalEmail->text);

         break;

      case frmPage3:
         ClientRec.P3OtherTxt[0] = 0;

         ClientRec.P3eCommerce    = CtlGetValue(cptrP3eCommerce   );
         ClientRec.P3InformSite   = CtlGetValue(cptrP3InformSite  );
         ClientRec.P3Manufacturer = CtlGetValue(cptrP3Manufacturer);
         ClientRec.P3Travel       = CtlGetValue(cptrP3Travel      );
         ClientRec.P3Finance      = CtlGetValue(cptrP3Finance     );
         ClientRec.P3NonProfit    = CtlGetValue(cptrP3NonProfit   );
         ClientRec.P3Retail       = CtlGetValue(cptrP3Retail      );
         ClientRec.P3Discount     = CtlGetValue(cptrP3Discount    );
         ClientRec.P3Other        = CtlGetValue(cptrP3Other       );

         if (fptrP3OtherTxt->text != NULL) StrCopy((CharPtr)&ClientRec.P3OtherTxt, fptrP3OtherTxt->text);

         break;

      case frmPage4:
         ClientRec.P4InetPresence       [0] = 0;
         ClientRec.P4SiteSince          [0] = 0;
         ClientRec.P4Unit               [0] = 0;
         ClientRec.P4PrimeObjective     [0] = 0;
         ClientRec.P4SecondaryObjective [0] = 0;

         if (LstGetSelectionText(lptrInetPresence,LstGetSelection(lptrInetPresence)) != NULL) StrCopy((CharPtr)&ClientRec.P4InetPresence, LstGetSelectionText(lptrInetPresence,LstGetSelection(lptrInetPresence)));
         ClientRec.ListIdxInetPresence = LstGetSelection(lptrInetPresence);

         if (LstGetSelectionText(lptrSiteSince,LstGetSelection(lptrSiteSince)) != NULL) StrCopy((CharPtr)&ClientRec.P4SiteSince, LstGetSelectionText(lptrSiteSince,LstGetSelection(lptrSiteSince)));
         ClientRec.ListIdxSiteSince = LstGetSelection(lptrSiteSince);

         if (LstGetSelectionText(lptrUnit,LstGetSelection(lptrUnit)) != NULL) StrCopy((CharPtr)&ClientRec.P4Unit, LstGetSelectionText(lptrUnit,LstGetSelection(lptrUnit)));
         ClientRec.ListIdxUnit = LstGetSelection(lptrUnit);

         if (fptrP4PrimeObjective->text != NULL) StrCopy((CharPtr)&ClientRec.P4PrimeObjective, fptrP4PrimeObjective->text);
         if (fptrP4SecondaryObjective->text != NULL) StrCopy((CharPtr)&ClientRec.P4SecondaryObjective, fptrP4SecondaryObjective->text);

         break;

      case frmPage5:
         ClientRec.P5ClientIs             [0] = 0;
         ClientRec.P5ClientSophistication [0] = 0;
         ClientRec.P5PreviousOnlineAgency [0] = 0;
         ClientRec.P5OfflineAgency        [0] = 0;
         ClientRec.P5MktBudget_ty         [0] = 0;
         ClientRec.P5MktBudget_py         [0] = 0;
         ClientRec.P5OnlineBudget_ty      [0] = 0;
         ClientRec.P5OnlineBudget_py      [0] = 0;

         if (LstGetSelectionText(lptrClientIs,LstGetSelection(lptrClientIs)) != NULL) StrCopy((CharPtr)&ClientRec.P5ClientIs, LstGetSelectionText(lptrClientIs,LstGetSelection(lptrClientIs)));
         ClientRec.ListIdxClientIs = LstGetSelection(lptrClientIs);

         if (LstGetSelectionText(lptrClientSophistication,LstGetSelection(lptrClientSophistication)) != NULL) StrCopy((CharPtr)&ClientRec.P5ClientSophistication, LstGetSelectionText(lptrClientSophistication,LstGetSelection(lptrClientSophistication)));
         ClientRec.ListIdxClientSophistication = LstGetSelection(lptrClientSophistication);

         if (fptrP5PreviousOnlineAgency->text != NULL) StrCopy((CharPtr)&ClientRec.P5PreviousOnlineAgency, fptrP5PreviousOnlineAgency->text);
         if (fptrP5OfflineAgency->text        != NULL) StrCopy((CharPtr)&ClientRec.P5OfflineAgency,        fptrP5OfflineAgency->text       );
         if (fptrP5MktBudget_ty->text         != NULL) StrCopy((CharPtr)&ClientRec.P5MktBudget_ty,         fptrP5MktBudget_ty->text        );
         if (fptrP5MktBudget_py->text         != NULL) StrCopy((CharPtr)&ClientRec.P5MktBudget_py,         fptrP5MktBudget_py->text        );
         if (fptrP5OnlineBudget_ty->text      != NULL) StrCopy((CharPtr)&ClientRec.P5OnlineBudget_ty,      fptrP5OnlineBudget_ty->text     );
         if (fptrP5OnlineBudget_py->text      != NULL) StrCopy((CharPtr)&ClientRec.P5OnlineBudget_py,      fptrP5OnlineBudget_py->text     );

         break;

      case frmPage6:
         // For checkboxes it's easy !!! :-))
         ClientRec.P6Stat         = CtlGetValue(cptrP6Stat        );
         ClientRec.P6Branding     = CtlGetValue(cptrP6Branding    );
         ClientRec.P6Email        = CtlGetValue(cptrP6Email       );
         ClientRec.P6Radio        = CtlGetValue(cptrP6Radio       );
         ClientRec.P6Print        = CtlGetValue(cptrP6Print       );
         ClientRec.P6Optimization = CtlGetValue(cptrP6Optimization);
         ClientRec.P6TV           = CtlGetValue(cptrP6TV          );
         ClientRec.P6Portal       = CtlGetValue(cptrP6Portal      );
         ClientRec.P6Bying        = CtlGetValue(cptrP6Bying       );
         ClientRec.P6Promotion    = CtlGetValue(cptrP6Promotion   );
         ClientRec.P6Creative     = CtlGetValue(cptrP6Creative    );
         ClientRec.P6DrvTraffic   = CtlGetValue(cptrP6DrvTraffic  );

         break;

   }

}

//#################################################################
// When navigatinfg from one page to another the record data 
// must be moved to the fields so that the user can edit them

static void LoadDataForPage(int frmID)
{

   InitializeFieldPointers(frmID);

   switch(frmID)
   { 

      case frmPage1:
         FldInsert(fptrP1ClientContact, ClientRec.P1ClientContact, StrLen(ClientRec.P1ClientContact));
         FldInsert(fptrP1Company,       ClientRec.P1Company,       StrLen(ClientRec.P1Company      ));
         FldInsert(fptrP1ClientPhone,   ClientRec.P1ClientPhone,   StrLen(ClientRec.P1ClientPhone  ));
         FldInsert(fptrP1ClientEmail,   ClientRec.P1ClientEmail,   StrLen(ClientRec.P1ClientEmail  ));
         FldInsert(fptrP1ClientAddr1,   ClientRec.P1ClientAddr1,   StrLen(ClientRec.P1ClientAddr1  ));
         FldInsert(fptrP1ClientAddr2,   ClientRec.P1ClientAddr2,   StrLen(ClientRec.P1ClientAddr2  ));
         FldInsert(fptrP1ClientCity,    ClientRec.P1ClientCity,    StrLen(ClientRec.P1ClientCity   ));

         LstSetSelection(lptrState,ClientRec.ListIdxStates);
         if (ClientRec.ListIdxStates != -1) CtlSetLabel (cptrP1ClientState, LstGetSelectionText(lptrState,ClientRec.ListIdxStates));

         FldInsert(fptrP1ClientZip, ClientRec.P1ClientZip, StrLen(ClientRec.P1ClientZip));

         // Once data is inserted the fields need to be re-drawn.
         FldDrawField  (fptrP1ClientContact);
         FldDrawField  (fptrP1Company      );
         FldDrawField  (fptrP1ClientContact);
         FldDrawField  (fptrP1ClientEmail  );
         FldDrawField  (fptrP1ClientAddr1  );
         FldDrawField  (fptrP1ClientAddr2  );
         FldDrawField  (fptrP1ClientCity   );
         CtlDrawControl(cptrP1ClientState  );
         FldDrawField  (fptrP1ClientZip    );

         break;

      case frmPage2:
         FldInsert(fptrP2ContactName,  ClientRec.P2ContactName,  StrLen(ClientRec.P2ContactName ));
         FldInsert(fptrP2ContactPhone, ClientRec.P2ContactPhone, StrLen(ClientRec.P2ContactPhone));
         FldInsert(fptrP2ContactEmail, ClientRec.P2ContactEmail, StrLen(ClientRec.P2ContactEmail));
         FldInsert(fptrP2ReferalName,  ClientRec.P2ReferalName,  StrLen(ClientRec.P2ReferalName ));
         FldInsert(fptrP2ReferalPhone, ClientRec.P2ReferalPhone, StrLen(ClientRec.P2ReferalPhone));
         FldInsert(fptrP2ReferalEmail, ClientRec.P2ReferalEmail, StrLen(ClientRec.P2ReferalEmail));

         FldDrawField(fptrP2ContactName );
         FldDrawField(fptrP2ContactPhone);
         FldDrawField(fptrP2ContactEmail);
         FldDrawField(fptrP2ReferalName );
         FldDrawField(fptrP2ReferalPhone);
         FldDrawField(fptrP2ReferalEmail);

         break;

      case frmPage3:
         CtlSetValue(cptrP3eCommerce,    ClientRec.P3eCommerce   );
         CtlSetValue(cptrP3InformSite,   ClientRec.P3InformSite  );
         CtlSetValue(cptrP3Manufacturer, ClientRec.P3Manufacturer);
         CtlSetValue(cptrP3Travel,       ClientRec.P3Travel      );
         CtlSetValue(cptrP3Finance,      ClientRec.P3Finance     );
         CtlSetValue(cptrP3NonProfit,    ClientRec.P3NonProfit   );
         CtlSetValue(cptrP3Retail,       ClientRec.P3Retail      );
         CtlSetValue(cptrP3Discount,     ClientRec.P3Discount    );
         CtlSetValue(cptrP3Other,        ClientRec.P3Other       );

         FldInsert(fptrP3OtherTxt, ClientRec.P3OtherTxt, StrLen(ClientRec.P3OtherTxt));
         FldDrawField(fptrP3OtherTxt);

         break;

      case frmPage4:
         LstSetSelection(lptrInetPresence,ClientRec.ListIdxInetPresence);
         if (ClientRec.ListIdxInetPresence != -1) CtlSetLabel (cptrP4InetPresence, LstGetSelectionText(lptrInetPresence,ClientRec.ListIdxInetPresence));

         LstSetSelection(lptrSiteSince,ClientRec.ListIdxSiteSince);
         if (ClientRec.ListIdxSiteSince != -1) CtlSetLabel (cptrP4SiteSince, LstGetSelectionText(lptrSiteSince,ClientRec.ListIdxSiteSince));

         LstSetSelection(lptrUnit,ClientRec.ListIdxUnit);
         if (ClientRec.ListIdxUnit != -1) CtlSetLabel (cptrP4Unit, LstGetSelectionText(lptrUnit,ClientRec.ListIdxUnit));

         FldInsert(fptrP4PrimeObjective, ClientRec.P4PrimeObjective, StrLen(ClientRec.P4PrimeObjective));
         FldInsert(fptrP4SecondaryObjective, ClientRec.P4SecondaryObjective, StrLen(ClientRec.P4SecondaryObjective));

         CtlDrawControl(cptrP4InetPresence);
         CtlDrawControl(cptrP4SiteSince   );
         CtlDrawControl(cptrP4Unit        );

         FldDrawField  (fptrP4PrimeObjective    );
         FldDrawField  (fptrP4SecondaryObjective);

         break;

      case frmPage5:
         LstSetSelection(lptrClientIs,ClientRec.ListIdxClientIs);
         if (ClientRec.ListIdxClientIs != -1) CtlSetLabel (cptrP5ClientIs, LstGetSelectionText(lptrClientIs,ClientRec.ListIdxClientIs));

         LstSetSelection(lptrClientSophistication,ClientRec.ListIdxClientSophistication);
         if (ClientRec.ListIdxClientSophistication != -1) CtlSetLabel (cptrP5ClientSophistication, LstGetSelectionText(lptrClientSophistication,ClientRec.ListIdxClientSophistication));

         FldInsert(fptrP5PreviousOnlineAgency, ClientRec.P5PreviousOnlineAgency, StrLen(ClientRec.P5PreviousOnlineAgency));
         FldInsert(fptrP5OfflineAgency,        ClientRec.P5OfflineAgency,        StrLen(ClientRec.P5OfflineAgency       ));
         FldInsert(fptrP5MktBudget_ty,         ClientRec.P5MktBudget_ty,         StrLen(ClientRec.P5MktBudget_ty        ));
         FldInsert(fptrP5MktBudget_py,         ClientRec.P5MktBudget_py,         StrLen(ClientRec.P5MktBudget_py        ));
         FldInsert(fptrP5OnlineBudget_ty,      ClientRec.P5OnlineBudget_ty,      StrLen(ClientRec.P5OnlineBudget_ty     ));
         FldInsert(fptrP5OnlineBudget_py,      ClientRec.P5OnlineBudget_py,      StrLen(ClientRec.P5OnlineBudget_py     ));

         CtlDrawControl(cptrP5ClientIs            );
         CtlDrawControl(cptrP5ClientSophistication);

         FldDrawField(fptrP5PreviousOnlineAgency);
         FldDrawField(fptrP5OfflineAgency       );
         FldDrawField(fptrP5MktBudget_ty        );
         FldDrawField(fptrP5MktBudget_py        );
         FldDrawField(fptrP5OnlineBudget_ty     );
         FldDrawField(fptrP5OnlineBudget_py     );

         break;

      case frmPage6:
         CtlSetValue(cptrP6Stat,ClientRec.P6Stat                );
         CtlSetValue(cptrP6Branding,ClientRec.P6Branding        );
         CtlSetValue(cptrP6Email,ClientRec.P6Email              );
         CtlSetValue(cptrP6Radio,ClientRec.P6Radio              );
         CtlSetValue(cptrP6Print,ClientRec.P6Print              );
         CtlSetValue(cptrP6Optimization,ClientRec.P6Optimization);
         CtlSetValue(cptrP6TV,ClientRec.P6TV                    );
         CtlSetValue(cptrP6Portal,ClientRec.P6Portal            );
         CtlSetValue(cptrP6Bying,ClientRec.P6Bying              );
         CtlSetValue(cptrP6Promotion,ClientRec.P6Promotion      );
         CtlSetValue(cptrP6Creative,ClientRec.P6Creative        );
         CtlSetValue(cptrP6DrvTraffic,ClientRec.P6DrvTraffic    );

         break;
   }
}

// That's all folks :-)