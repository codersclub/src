@echo off
@cls
@if exist error*.txt del error*.txt
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist kgv.o del kgv.o 
@if exist kgv del kgv 
@if exist kgv.prc del kgv.prc
echo compile the resource files
pilrc kgv.rcp
echo Step 1-------------------------------------------------------------------
m68k-palmos-gcc -O1 -c kgv.c -o kgv.o
echo Step 2 ------------------------------------------------------------------
m68k-palmos-gcc -O1 kgv.o -o kgv 
echo Step 3 ------------------------------------------------------------------
m68k-palmos-obj-res kgv 
echo Step 4 ------------------------------------------------------------------
build-prc  kgv.prc "KGV 432" K432 *.grc *.bin
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist kgv.o del kgv.o 
@if exist kgv del kgv 
echo -------------------------------------------------------------------------
echo -------------------------------------- Compile done ---------------------
echo -------------------------------------------------------------------------