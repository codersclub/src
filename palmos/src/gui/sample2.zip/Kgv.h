// C:\sample2\Kgv.h
// Header File automaticaly generated from VFDIDE. Don't modify !!
// You will loose all manual modifications to this file!
// Generated: 01.09.2000 12:30:29
// (in case of errors please contact ogrossklaus@debitel.net)


#define formID_KGV 1262
#define lblID1 1319
#define lblID2 1320
#define fieldID_Pz 1267
#define fieldID_Wasser 1268
#define fieldID_Strom 1269
#define buttonID_C1 1264
#define buttonID_C2 1265
#define buttonID_C3 1266
#define buttonID_1 1270
#define buttonID_2 1271
#define buttonID_3 1272
#define buttonID_4 1273
#define buttonID_5 1274
#define buttonID_6 1275
#define buttonID_7 1276
#define buttonID_8 1277
#define buttonID_9 1278
#define buttonID_0 1279
#define buttonID_Prev 1312
#define buttonID_Next 1313
#define buttonID_PZBitmap 1314
#define buttonID_WasserBitmap 1315
#define buttonID_StromBitmap 1316
#define buttonID_Del 1317
#define buttonID_XMit 1318
#define alertID_Startup 1321
#define alertID_About 1322
#define alertID_DeleteOne 1323
#define alertID_DeleteConfirm 1324
#define alertID_XMitDest 1325
#define alertID_DeleteAfterXmit 1326
#define alertID_Custom 1327
#define bmpClear 1247
#define bmpDArrow 1248
#define bmpDiv1 1249
#define bmpDiv2 1250
#define bmpDiv3 1251
#define bmpFooter 1252
#define bmpHeader 1253
#define bmpPZ 1254
#define bmpStat 1256
#define bmpStrom 1257
#define bmpUArrow 1259
#define bmpWasser 1260
#define VersionID 1
#define ApplNameID 1244
#define ApplID 1245
