// Dear Programmer. This Program is only to demonstrate how to work with VFDIDE. It is my first Pilot Application so ....
// Dont blame me for any "incorrect" use or any "coding style violations"
// But .. feel free to send any commends
// Thanks
// (No warranty is overtaken with this project)
//-----------------------------------------------------
#pragma	pack(2)
//#include	<Common.h>
//#include	<System/SysAll.h>
//#include	<UI/UIAll.h>
#include	<System/SerialMgr.h>
#include	<PalmOS.h>
#include	<PalmCompatibility.h>

#include	"kgv.h"

#define	KGVAppID 'K432' 
#define	KGVDBType 'Data' 
#define	CLICK() (SndPlaySystemSound(sndClick))
#define	ERROR() (SndPlaySystemSound(sndError))

static int	StartApplication(void);
static Int	OpenDatabase(void);
static void	EventLoop(void);
static void	StopApplication(void);

typedef struct {
   char Pz		[5 ];
   char Wasser	[10];
   char Strom	[10];
}PZEntryType;

PZEntryType	PZDataEntry;
VoidPtr	recP = 0;
VoidHand	recH = 0;

FieldPtr	fieldptr_Pz;
FieldPtr	fieldptr_Wasser;
FieldPtr	fieldptr_Strom;
FieldPtr	fieldptrCurrentField;
UInt		SilentMode	= 0;
UInt		RecCount	= 0;
UInt		RecPos	= 0;
UInt		UpdCount	= 0;
char		wrkBuf1[100 ];
char		wrkBuf2[100 ];
char		wrkBuf3[100 ];
char		wrkBuf4[100 ];
char		ClipText[4095];
Err		eError;

DmOpenRef	KGVDB;
char		KGVDBName[] = "KGVDB";
FormPtr	form;

/*###############################################*/

DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
   int error;

   if (cmd == sysAppLaunchCmdNormalLaunch)
   {
    
      error = StartApplication();
      if (error) return error;
      EventLoop();
      StopApplication ();
   }
   return 0;
}

/*###############################################*/

Int CreateEmptyRec(Int idx)
{
   Int i = idx - 1;

   recH = DmNewRecord(KGVDB, &i, sizeof(PZEntryType));
   recP = MemHandleLock(recH);

   DmSet(recP,0,sizeof(PZEntryType),0);

   MemHandleUnlock(recH);
   DmReleaseRecord(KGVDB, i, true);

   recH = 0;
   recP = NULL;

   RecCount++;
   
   return 0;

}

/*###############################################*/

Int PutRec(Int idx)
{
   recH = DmGetRecord(KGVDB, idx-1);
   recP = MemHandleLock (recH);
 
   if ( fieldptr_Pz->text	!= NULL) StrCopy((CharPtr)&PZDataEntry.Pz,	fieldptr_Pz->text		);
   if ( fieldptr_Wasser->text	!= NULL) StrCopy((CharPtr)&PZDataEntry.Wasser,	fieldptr_Wasser->text	);
   if ( fieldptr_Strom->text	!= NULL) StrCopy((CharPtr)&PZDataEntry.Strom,	fieldptr_Strom->text	);

   DmWrite(recP,0l,&PZDataEntry,sizeof(PZEntryType));

   MemHandleUnlock(recH);
   DmReleaseRecord(KGVDB, idx-1, true);

   recP = NULL;
   recH = 0;

   return 0;
}

/*###############################################*/

Int GetRec(Int idx)
{

   recH = DmQueryRecord(KGVDB, idx-1);
   recP = MemHandleLock (recH);

   MemSet(&PZDataEntry,sizeof(PZEntryType),0);
   MemMove(&PZDataEntry,recP,sizeof(PZEntryType));

   FldDelete (fieldptr_Pz,0,     FldGetTextLength(fieldptr_Pz)); 
   FldDelete (fieldptr_Wasser,0, FldGetTextLength(fieldptr_Wasser));   
   FldDelete (fieldptr_Strom, 0, FldGetTextLength(fieldptr_Strom));   

   FldInsert (fieldptr_Pz,	(CharPtr)&PZDataEntry.Pz,	StrLen(PZDataEntry.Pz)	  );
   FldInsert (fieldptr_Wasser,(CharPtr)&PZDataEntry.Wasser,	StrLen(PZDataEntry.Wasser));
   FldInsert (fieldptr_Strom,	(CharPtr)&PZDataEntry.Strom,	StrLen(PZDataEntry.Strom) );

   MemHandleUnlock(recH);
   DmReleaseRecord(KGVDB, idx-1, true);

   recP = NULL;
   recH = 0;

   return 0;

}

/*###############################################*/

static Int OpenDatabase(void)
{

   KGVDB = DmOpenDatabaseByTypeCreator(KGVDBType, KGVAppID, dmModeReadWrite);
   if (!KGVDB) 
   {
      if (DmCreateDatabase(0, KGVDBName, KGVAppID, KGVDBType, false)) 
         return 1;
      KGVDB = DmOpenDatabaseByTypeCreator(KGVDBType, KGVAppID, dmModeReadWrite);
   }

   return 0;

}

/*###############################################*/

static void UpdateRelPos()
{

   MemSet	(wrkBuf1,sizeof(wrkBuf1),0); 
   StrCat	(wrkBuf1, "Eintr�ge ");
   StrIToA	(&wrkBuf2[0],RecCount);
   StrCat	(wrkBuf1,wrkBuf2);
   StrCat	(wrkBuf1," aktueller Eintrag ");
   StrIToA	(&wrkBuf2[0],RecPos);
   StrCat	(wrkBuf1,wrkBuf2);
   StrCat	(wrkBuf1, "               ");
   FrmCopyLabel(form,lblID1,wrkBuf1);

}

/*###############################################*/

static int StartApplication(void)
{
   Int error;

   error = OpenDatabase();
   if (error) return error;

   RecPos = RecCount = DmNumRecords(KGVDB);

   if (RecCount == 0)
      CreateEmptyRec(1);

   FrmGotoForm(formID_KGV);
}

/*###############################################*/

static void UpdateStatusLine()
{
   DateTimeType  time;
   UInt          iVolts,iWarn;
   double        rVolts;

   if (UpdCount > 0)
   {
      UpdCount--;
      return;
   }

   UpdCount = 1;
   TimSecondsToDateTime(TimGetSeconds(), &time);
   MemSet(wrkBuf1,sizeof(wrkBuf1),0); 
   DateToAscii(time.month, time.day, time.year,dfDMYWithDots,wrkBuf2);
   StrCat(wrkBuf1,wrkBuf2);
   StrCat(wrkBuf1," ");
   TimeToAscii(time.hour, time.minute, tfColon24h, wrkBuf2);
   StrCat(wrkBuf1,wrkBuf2);
   StrCat(wrkBuf1," Batt. ");
   iVolts = SysBatteryInfoV20(false, &iWarn, 0, 0, 0, 0);
   StrIToA(&wrkBuf2[0],iVolts / 100);
   if (iVolts % 100 < 10)
      StrCat (wrkBuf2,".0");
   else
      StrCat (wrkBuf2,".");
   StrIToA(&(wrkBuf2[StrLen(wrkBuf2)]), iVolts % 100);   
   StrCat(wrkBuf1,wrkBuf2);
   StrCat(wrkBuf1," V (=");
   rVolts = ((double)(iVolts- iWarn) / (double)(300 - iWarn))*100;
   StrIToA(&wrkBuf2[0],(int)rVolts);
   StrCat(wrkBuf1,wrkBuf2);
   StrCat(wrkBuf1,"%)    ");
   FrmCopyLabel(FrmGetFormPtr(formID_KGV),lblID2,wrkBuf1);
}

/*###############################################*/

static void InitializeForm()
{
 
   form = FrmGetActiveForm();

   fieldptr_Pz     = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Pz));
   fieldptr_Wasser = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Wasser));
   fieldptr_Strom  = FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Strom));

   fieldptrCurrentField = fieldptr_Pz;

   RecPos = 1;
   GetRec(RecPos);

   FrmDrawForm(form);
   FrmAlert(alertID_Startup);

   FldGrabFocus(fieldptrCurrentField);
   FldDrawField(fieldptrCurrentField);

   UpdateRelPos();
   UpdateStatusLine();
}

/*###############################################*/

static int RecPrev()
{

   PutRec(RecPos);

   if (RecPos > 1)
   {
      RecPos--;
      GetRec(RecPos);
      UpdateRelPos();
   }
   else
      ERROR();

   fieldptrCurrentField = fieldptr_Pz;
   FldGrabFocus(fieldptrCurrentField);
   FldDrawField(fieldptrCurrentField);

   return 0;
}

/*###############################################*/

static int RecNext()
{

   PutRec(RecPos);

   if (RecPos == RecCount) 
   {
      if (StrLen(PZDataEntry.Pz) != 0)
      {
         CreateEmptyRec(RecPos + 1); 
         RecPos++;
      }
      else
      {
         ERROR();
      }
   }
   else
   {
      RecPos++;
   }

   GetRec(RecPos);

   fieldptrCurrentField = fieldptr_Pz;
   FldGrabFocus(fieldptrCurrentField);
   FldDrawField(fieldptrCurrentField);

   UpdateRelPos();

   return 0;
}

/*###############################################*/

static int DeleteAll()
{
   Int i;

   for (i=1 ; i <= RecCount; i++)
   {
      DmRemoveRecord(KGVDB,0);
   }

   CreateEmptyRec(1);
   RecCount = 1;
   RecPos = 1;
   GetRec(1);

   fieldptrCurrentField = fieldptr_Pz;
   FldGrabFocus(fieldptrCurrentField);
   FldDrawField(fieldptrCurrentField);

   UpdateRelPos();
}

/*###############################################*/

static int XMitMemo()
{

   DmOpenRef MemopadDB;
   Int idx = 0;
   Int i;
   VoidPtr lrecP;
   VoidHand lrecH;
   DateTimeType datetime;
   Int Block = 1;

   StrCopy(ClipText,"Ablesung (1) vom ");

   TimSecondsToDateTime(TimGetSeconds(), &datetime);
   DateToAscii(datetime.month, datetime.day, datetime.year, dfDMYWithDots, wrkBuf1);
   StrCat (ClipText,wrkBuf1);
   StrCat (ClipText,"\n");

   PutRec(RecPos);

   for (i=1 ; i <= RecCount; i++)
   {
           
      GetRec(i);

      if (StrLen(PZDataEntry.Pz) != 0)
      {

         StrCat(ClipText,(CharPtr)&PZDataEntry.Pz);
         StrCat(ClipText," "); 

         if (StrLen(PZDataEntry.Wasser) != 0)
            StrCat(ClipText,(CharPtr)&PZDataEntry.Wasser);
         else
            StrCat(ClipText,"?");

         StrCat(ClipText," "); 

         if (StrLen(PZDataEntry.Strom) != 0)
            StrCat(ClipText,(CharPtr)&PZDataEntry.Strom);
         else
            StrCat(ClipText,"?");

         StrCat(ClipText,"\n"); 
      }

      PutRec(i);

      if ( (StrLen(ClipText) > (4000 - sizeof(PZEntryType))) || ( i == RecCount) )
      {
         MemopadDB = DmOpenDatabaseByTypeCreator('DATA','memo',dmModeReadWrite);
         lrecH = DmNewRecord(MemopadDB,&idx,StrLen(ClipText)+1);
         lrecP = MemHandleLock(lrecH);    
 
         DmSet(lrecP,0,StrLen(ClipText)+1,0);
         DmWrite(lrecP,0,ClipText,StrLen(ClipText));
 
         MemHandleUnlock(lrecH);
         DmReleaseRecord(MemopadDB,idx,true);

         DmCloseDatabase(MemopadDB);

         Block++;

         StrCopy(ClipText,"Ablesung (");
         StrIToA(&wrkBuf2[0],Block);
         StrCat(ClipText,wrkBuf2);  
         StrCat(ClipText,") vom ");

         DateToAscii(datetime.month, datetime.day, datetime.year, dfDMYWithDots, wrkBuf1);
         StrCat (ClipText,wrkBuf1);
         StrCat (ClipText,"\n");

      }
   }

   RecPos = 1;
   GetRec(RecPos);

   StrCopy(wrkBuf1,"Gespeichert im Memopad");

   StrCopy(wrkBuf2,"Ablesung vom ");
   DateToAscii(datetime.month, datetime.day, datetime.year, dfDMYWithDots, wrkBuf3);
   StrCat(wrkBuf2,wrkBuf3);

   StrIToA(&wrkBuf4[0],(Block-1));
   StrCopy(wrkBuf3,"(1) bis (");
   StrCat(wrkBuf3,wrkBuf4);  
   StrCat(wrkBuf3,")");

   if (SilentMode == 0)
   {
      FrmCustomAlert(alertID_Custom,wrkBuf1,wrkBuf2,wrkBuf3);

      if (FrmAlert(alertID_DeleteAfterXmit) == 0)
         if (FrmAlert(alertID_DeleteConfirm) == 0)
            DeleteAll();
   }
   
   return true;
}

/*###############################################*/

static int XMitCom()
{
/* SORRY. With PRC-Tools 2.0 the Serial Manager has changed. I haven't found time to update this code... */

/*
   UInt SerialRef = 0;
   SerSettingsType SerialSettings;
   char SendStr[30];
   UInt i;

   SysLibFind("Serial Library",&SerialRef);	// Find Communications Library 

   SerOpen(SerialRef,0,19200);			// Open Port 0 with 9600       
                                                // Set Communication Parameter 
   SerialSettings.baudRate = 19200;
   SerialSettings.ctsTimeout = serDefaultCTSTimeout;
   SerialSettings.flags = serSettingsFlagStopBits1 | serSettingsFlagBitsPerChar8;

   SerSetSettings(SerialRef,&SerialSettings);

   StrCopy(SendStr,"BT");				// Send a Begin Transfer       
   StrIToA(&wrkBuf2[0],RecCount);			// together with the RecCount  
   StrCat(SendStr,wrkBuf2);
   StrCat(SendStr,"L");
   SerSend(SerialRef,SendStr,StrLen(SendStr),&eError);
   SerClearErr(SerialRef);				// Dont handle erros (gulp)    
   SerSendWait(SerialRef,-1l);			// Wait until Record is sent   

   PutRec(RecPos);					// Save current Pilots record  

								// Send all records            
   for (RecPos=1 ; RecPos <= RecCount; RecPos++)
   {
    
      GetRec(RecPos);					// Open current Record         

      if (StrLen(PZDataEntry.Pz) != 0)
         StrCopy(SendStr,(CharPtr)&PZDataEntry.Pz);
      else
         StrCopy(SendStr,"?");
      StrCat(SendStr," "); 

      if (StrLen(PZDataEntry.Wasser) != 0)
         StrCat(SendStr,(CharPtr)&PZDataEntry.Wasser);
      else
         StrCat(SendStr,"?");

      StrCat(SendStr," "); 

      if (StrLen(PZDataEntry.Strom) != 0)
         StrCat(SendStr,(CharPtr)&PZDataEntry.Strom);
      else
         StrCat(SendStr,"?");
      StrCat(SendStr,"L"); 

      PutRec(RecPos);					// Close Current Record        
								// Send record                 
	
      SerSend(SerialRef,SendStr,StrLen(SendStr),&eError);
      SerClearErr(SerialRef);
      SerSendWait(SerialRef,-1l);

      UpdateRelPos();					// Display some actions        
      UpdateStatusLine();
   }

   RecPos = 1;
   GetRec(RecPos);

   StrCopy(SendStr,"ETL");				// send End Transaction        
   SerSend(SerialRef,SendStr,StrLen(SendStr),&eError);
   SerClearErr(SerialRef);
   SerSendWait(SerialRef,-1l);

   SerClose(SerialRef); 				// Close COM1                  

   if (FrmAlert(alertID_DeleteAfterXmit) == 0)
      if (FrmAlert(alertID_DeleteConfirm) == 0)
      {
         SilentMode = 1;
         XMitMemo();
         SilentMode = 0;
         DeleteAll();
      }
*/

   return true;

}

/*###############################################*/

static int ButtonEvents(Word CtrlID)
{
   Word Response;

   switch(CtrlID)    
   {

   case buttonID_0:
      FldInsert(fieldptrCurrentField,"0",1);
      return 1;
      break;
 
    case buttonID_1:
      FldInsert(fieldptrCurrentField,"1",1);
      return 1;
      break;

    case buttonID_2:
      FldInsert(fieldptrCurrentField,"2",1);
      return 1;
      break;

    case buttonID_3:
      FldInsert(fieldptrCurrentField,"3",1);
      return 1;
      break;

    case buttonID_4:
      FldInsert(fieldptrCurrentField,"4",1);
      return 1;
      break;

    case buttonID_5:
      FldInsert(fieldptrCurrentField,"5",1);
      return 1;
      break;

    case buttonID_6:
      FldInsert(fieldptrCurrentField,"6",1);
      return 1;
      break;

    case buttonID_7:
      FldInsert(fieldptrCurrentField,"7",1);
      return 1;
      break;

    case buttonID_8:
      FldInsert(fieldptrCurrentField,"8",1);
      return 1;
      break;

    case buttonID_9:
      FldInsert(fieldptrCurrentField,"9",1);
      return 1;
      break;
      
    case buttonID_C1:
       FldDelete(fieldptr_Pz,0,FldGetTextLength(fieldptr_Pz));   
       fieldptrCurrentField = fieldptr_Pz;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

    case buttonID_C2:
       FldDelete(fieldptr_Wasser,0,FldGetTextLength(fieldptr_Wasser));   
       fieldptrCurrentField = fieldptr_Wasser;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

    case buttonID_C3:
       FldDelete(fieldptr_Strom,0,FldGetTextLength(fieldptr_Strom));   
       fieldptrCurrentField = fieldptr_Strom;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

    case buttonID_Prev:
      return RecPrev();
      break;

    case buttonID_Next:
      return RecNext();
      break;

    case buttonID_XMit:

       Response = FrmAlert(alertID_XMitDest);
       
       switch (Response)
       {
       case 0:
          XMitMemo();
          break;

       case 1:
          XMitCom();
          break;

       case 2:
         break;
       }

       break;

    case buttonID_Del:

      Response = FrmAlert(alertID_DeleteOne);

      switch (Response)
      {
      case 0: /*  current entry */

         FldDelete(fieldptr_Pz,0,FldGetTextLength(fieldptr_Pz));   
         FldDelete(fieldptr_Wasser,0,FldGetTextLength(fieldptr_Wasser));   
         FldDelete(fieldptr_Strom,0,FldGetTextLength(fieldptr_Strom));   

         fieldptrCurrentField = fieldptr_Pz;
         FldGrabFocus(fieldptrCurrentField);
         FldDrawField(fieldptrCurrentField);

         break;
   
      case 1: /* all entries */
         if (FrmAlert(alertID_DeleteConfirm) == 0)
            DeleteAll();
         break;  
 
      case 2: /* Nothing */
         break;
      }
      break;

    case buttonID_PZBitmap:
       fieldptrCurrentField = fieldptr_Pz;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

    case buttonID_WasserBitmap:
       fieldptrCurrentField = fieldptr_Wasser;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

    case buttonID_StromBitmap:
       fieldptrCurrentField = fieldptr_Strom;
       FldGrabFocus(fieldptrCurrentField);
       FldDrawField(fieldptrCurrentField);
       break;

   }

   return 0;

}

/*###############################################*/

static int KBDHandler(Word KeyChar)
{
   switch(KeyChar)    
   {

   case pageUpChr: 
      return RecPrev();
      fieldptrCurrentField = fieldptr_Pz;
      FldGrabFocus(fieldptrCurrentField);
      FldDrawField(fieldptrCurrentField);
      break;

   case pageDownChr: 
      return RecNext();
      fieldptrCurrentField = fieldptr_Pz;
      FldGrabFocus(fieldptrCurrentField);
      FldDrawField(fieldptrCurrentField);
      break;

   }

   if ((KeyChar < 48) || (KeyChar > 57)) return 1;

   return 0;

}

/*###############################################*/

static Boolean KGV(EventPtr event)
{
   int    handled = 0;
 
   switch (event->eType) 
   {

   case keyDownEvent:
      handled = KBDHandler(event->data.keyDown.chr);
      break;

   case frmOpenEvent:

      InitializeForm();
      handled = 1;
      break;
    
   case penUpEvent:

      if ((event->data.penUp.end.x >   6) && (event->data.penUp.end.x <  22) && (event->data.penUp.end.y < 15)) 
         FrmAlert(alertID_About);

      if ((event->data.penUp.end.x > 139) && (event->data.penUp.end.x < 155) && (event->data.penUp.end.y < 15))
         FrmAlert(alertID_About);
  
      break;

   case ctlSelectEvent:
      handled = ButtonEvents (event->data.ctlEnter.controlID);
      break;

   case fldEnterEvent:
      fieldptrCurrentField = (FieldPtr) event->data.fldEnter.pField;
      break;

   case nilEvent: 
      handled = 1;
      break; 

   }

   UpdateStatusLine();
   return handled;
}

/*###############################################*/

static void EventLoop(void)
{
   short err;
   int formID;
   FormPtr form;
   EventType event;
   do
   {
      EvtGetEvent(&event, 5000);
      if (SysHandleEvent(&event)) continue;

      if (event.eType == frmLoadEvent)
      {
         formID = event.data.frmLoad.formID;
         form = FrmInitForm(formID);
         FrmSetActiveForm(form);
         FrmSetEventHandler(form, (FormEventHandlerPtr) KGV);
      }
      FrmDispatchEvent(&event);
   } while(event.eType != appStopEvent);
}

/*###############################################*/

static void StopApplication(void)
{
   PutRec(RecPos);
   DmCloseDatabase(KGVDB);
}

