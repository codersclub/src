// C:\sample3\Mbi1.h
// Header File automaticaly generated from VFDIDE. Don't modify !!
// You will loose all manual modifications to this file!
// Generated: 01.09.2000 12:33:46
// (in case of errors please contact ogrossklaus@debitel.net)


#define Form001 1010
#define NormalButton001 1378
#define NormalButton002 1379
#define NormalButton003 1381
#define NormalButton004 1382
#define AlertSelection1 1414
#define AlertSelection2 1415
#define AlertSelection3 1416
#define AlertSelection4 1417
#define GlobalBitmap001 1418
#define GlobalBitmap002 1419
#define GlobalBitmap003 1420
#define VersionID 1
#define ApplNameID 1008
#define ApplID 1009
