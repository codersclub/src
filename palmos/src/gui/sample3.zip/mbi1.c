#pragma	pack(2)
//#include	<Common.h>
//#include	<SysAll.h>
//#include	<UIAll.h>
#include	<PalmOS.h>
#include	<PalmCompatibility.h>

#include	"mbi1.h"

static int	StartApplication(void);
static void	EventLoop(void);
static void	StopApplication(void);

FormPtr	form;

/*###############################################*/

DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
   int error;

   if (cmd == sysAppLaunchCmdNormalLaunch)
   {
    
      error = StartApplication();
      if (error) return error;
      EventLoop();
   }
   return 0;
}

/*###############################################*/

static int StartApplication(void)
{

   FrmGotoForm(Form001); 

}

/*###############################################*/

static void InitializeForm()
{
 
   form = FrmGetActiveForm();

   FrmDrawForm(form);

}

/*###############################################*/

static int ButtonEvents(Word CtrlID)
{
   Word Response;

   switch(CtrlID)    
   {

    case NormalButton001: 
      FrmAlert(AlertSelection1);
      break;
 
    case NormalButton002: 
      FrmAlert(AlertSelection2);
      break;

    case NormalButton003: 
      FrmAlert(AlertSelection3);
      break;

    case NormalButton004: 
      FrmAlert(AlertSelection4);
      break;

   }

   return 0;

}

/*############################*/

static Boolean KGV(EventPtr event)
{
   int    handled = 0;
 
   switch (event->eType) 
   {

   case frmOpenEvent:
      InitializeForm();
      handled = 1;
      break;
    

   case ctlSelectEvent:
      handled = ButtonEvents (event->data.ctlEnter.controlID);
      break;

   case fldEnterEvent:
      break;

   }

   return handled;
}

/*###############################################*/

static void EventLoop(void)
{
   short err;
   int formID;
   FormPtr form;
   EventType event;
   do
   {
      EvtGetEvent(&event, 5000);

      if (SysHandleEvent(&event)) continue; 

      if (event.eType == frmLoadEvent)
      {
         formID = event.data.frmLoad.formID;     
         form = FrmInitForm(formID);
         FrmSetActiveForm(form);
         FrmSetEventHandler(form, (FormEventHandlerPtr) KGV);
      }
      FrmDispatchEvent(&event);
   } while(event.eType != appStopEvent);
}

