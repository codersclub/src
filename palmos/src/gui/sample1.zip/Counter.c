// This program is for the following reason:
// Imagine to be around in restaurants (or somewhere else) with childreen (like my daughter)
// Imagine you have to WAIT for something (i.e. the meal)
// Also Imagine that childreen are always WANT TO PLAY A QUICK GAME
// We have a couple of these games such as "guess an animal - that I have in mind"
// The "3 Coins game" where the childreen have to guess the number of coins beeing on the table
// etc. etc. etc.
// For all of these games points are assigned to the winner of ONE round
// Adding up the points results in the WINNER
// The "AddingPointsUpToATotal" was done on paper (if avail) but usualy on a box of cigarettes with a ...
// ... borrowed pencil from the waiter bevore I bought a PILOT
//------------------------------------------------------------
// AND NOW IT IS DONE ON THE PILOT :-)))
//------------------------------------------------------------
// The usage is easy:
// Simply enter the name(s) of the people joining the game and tap on a particular person in order to add (or substract) points
// The points are defined in the lower right corner and are added / or substracted by pressing a certain button.
// As simple as that
// Enjoy: Its free
// -----------------------------------------------------------
// Sorry all perfectionists. I don't handle Overflows / underflows accurately :-(
//------------------------------------------------------------

#pragma	pack(2)
//#include	<Common.h>
//#include	<SysAll.h>
//#include	<UIAll.h>
#include	<PalmOS.h>
#include	<PalmCompatibility.h>

#include	"counter.h"

#define	CounterAppID 'COUN' 
#define	CLICK() (SndPlaySystemSound(sndClick))
#define	ERROR() (SndPlaySystemSound(sndError))

static int	StartApplication(void);
static Int	OpenDatabase(void);
static void	EventLoop(void);


FieldPtr	fieldptr_Name1;
FieldPtr	fieldptr_Name2;
FieldPtr	fieldptr_Name3;
FieldPtr	fieldptr_Name4;
FieldPtr	fieldptr_Name5;
FieldPtr	fieldptr_Name6;
FieldPtr	fieldptr_Name7;
FieldPtr	fieldptr_Name8;

FieldPtr	fieldptr_Punkte1;
FieldPtr	fieldptr_Punkte2;
FieldPtr	fieldptr_Punkte3;
FieldPtr	fieldptr_Punkte4;
FieldPtr	fieldptr_Punkte5;
FieldPtr	fieldptr_Punkte6;
FieldPtr	fieldptr_Punkte7;
FieldPtr	fieldptr_Punkte8;

FieldPtr	fieldptrCurrentField;

FieldPtr	fieldptr_CurrName;
FieldPtr	fieldptr_Points;

Err		eError;

FormPtr	form;

/*###############################################*/

DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
   int error;

   if (cmd == sysAppLaunchCmdNormalLaunch)
   {
      error = StartApplication();
      if (error) return error;
      EventLoop();
   }
   return 0;
}

/*###############################################*/

static int StartApplication(void)
{
   FrmGotoForm(formID_Counter);
}

/*###############################################*/

static void InitializeForm()
{ 
   form = FrmGetActiveForm();

   fieldptr_Name1 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name1));
   fieldptr_Name2 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name2));
   fieldptr_Name3 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name3));
   fieldptr_Name4 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name4));
   fieldptr_Name5 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name5));
   fieldptr_Name6 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name6));
   fieldptr_Name7 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name7));
   fieldptr_Name8 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Name8));

   fieldptr_Punkte1 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt1));
   fieldptr_Punkte2 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt2));
   fieldptr_Punkte3 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt3));
   fieldptr_Punkte4 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt4));
   fieldptr_Punkte5 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt5));
   fieldptr_Punkte6 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt6));
   fieldptr_Punkte7 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt7));
   fieldptr_Punkte8 =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Punkt8));

   fieldptr_CurrName =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_CurrName));
   fieldptr_Points =FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_Points));

   fieldptrCurrentField  = fieldptr_Name1;

   FrmDrawForm(form);

   FldSetUsable(fieldptr_Punkte1,false);
   FldSetUsable(fieldptr_Punkte2,false);
   FldSetUsable(fieldptr_Punkte3,false);
   FldSetUsable(fieldptr_Punkte4,false);
   FldSetUsable(fieldptr_Punkte5,false);
   FldSetUsable(fieldptr_Punkte6,false);
   FldSetUsable(fieldptr_Punkte7,false);
   FldSetUsable(fieldptr_Punkte8,false);

}

/*###############################################*/

static int ButtonEvents(Word CtrlID)
{
   UInt	OldVal;
   UInt	CurVal;
   UInt	NewVal;
   char	wrkBuf[20];
   FieldPtr	fieldptrCurrPoints;

   if (fieldptrCurrentField == fieldptr_Name1) fieldptrCurrPoints = fieldptr_Punkte1;
   if (fieldptrCurrentField == fieldptr_Name2) fieldptrCurrPoints = fieldptr_Punkte2;
   if (fieldptrCurrentField == fieldptr_Name3) fieldptrCurrPoints = fieldptr_Punkte3;
   if (fieldptrCurrentField == fieldptr_Name4) fieldptrCurrPoints = fieldptr_Punkte4;
   if (fieldptrCurrentField == fieldptr_Name5) fieldptrCurrPoints = fieldptr_Punkte5;
   if (fieldptrCurrentField == fieldptr_Name6) fieldptrCurrPoints = fieldptr_Punkte6;
   if (fieldptrCurrentField == fieldptr_Name7) fieldptrCurrPoints = fieldptr_Punkte7;
   if (fieldptrCurrentField == fieldptr_Name8) fieldptrCurrPoints = fieldptr_Punkte8;
   
   if (fieldptrCurrPoints->text != NULL)
      OldVal = StrAToI(fieldptrCurrPoints->text); 
   else
      OldVal = 0;

   if (fieldptr_Points->text != NULL)
      CurVal = StrAToI(fieldptr_Points->text); 
   else
      CurVal = 0;

   switch(CtrlID)    
   {
   case ButtonID_Plus:
      NewVal = OldVal + CurVal;
      break;

   case ButtonID_Minus:
      NewVal = OldVal - CurVal;
      break;

   }

   StrIToA((CharPtr)&wrkBuf,NewVal);

   FldSetUsable	(fieldptrCurrPoints, true);
   FldDelete	(fieldptrCurrPoints, 0, FldGetTextLength(fieldptrCurrPoints)); 
   FldInsert	(fieldptrCurrPoints, wrkBuf, StrLen(wrkBuf));
   FldDrawField	(fieldptrCurrPoints);
   FldSetUsable	(fieldptrCurrPoints, false);

   FldDelete(fieldptr_Points,  0, FldGetTextLength(fieldptr_Points)); 

   return 0;

}

/*###############################################*/

static Boolean Counter(EventPtr event)
{
   int	handled = 0;
   char	aStr[30];
 
   switch (event->eType) 
   {

   case frmOpenEvent:
      InitializeForm();
      handled = 1;
      break;
    
   case ctlSelectEvent:
      handled = ButtonEvents (event->data.ctlEnter.controlID);
      break;

   case fldEnterEvent:
      if ((FieldPtr) event->data.fldEnter.pField != fieldptr_Points)    
      {
     
         fieldptrCurrentField = (FieldPtr) event->data.fldEnter.pField;
  
         StrCopy((CharPtr)&aStr,"");
         if (fieldptrCurrentField->text != NULL) StrCopy((CharPtr)&aStr,fieldptrCurrentField->text);

         FldSetUsable(fieldptr_CurrName,true);
         FldDelete(fieldptr_CurrName,    0, FldGetTextLength(fieldptr_CurrName)); 
         FldInsert(fieldptr_CurrName, aStr, StrLen(aStr));
         FldDrawField(fieldptr_CurrName);
         FldSetUsable(fieldptr_CurrName,false);
  
         FldDelete(fieldptr_Points,  0, FldGetTextLength(fieldptr_Points)); 
      }
      break;
   }

   return handled;
}

/*###############################################*/

static void EventLoop(void)
{
   short		err;
   int		formID;
   FormPtr		form;
   EventType	event;
   do
   {
      EvtGetEvent(&event, 5000);
      if (SysHandleEvent(&event)) continue;

      if (event.eType == frmLoadEvent)
      {
         formID = event.data.frmLoad.formID;
         form = FrmInitForm(formID);
         FrmSetActiveForm(form);
         FrmSetEventHandler(form, (FormEventHandlerPtr) Counter);
      }
      FrmDispatchEvent(&event);
   } while(event.eType != appStopEvent);
}
