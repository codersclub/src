@echo off
@cls
@if exist *.bin del *.bin
@if exist *.grc del *.grc 
@if exist counter.o del counter.o 
@if exist counter del counter 
@if exist counter.prc del counter.prc
echo compile the resource files
pilrc counter.rcp 
cls 
echo Step 1 -----------------------------------------------------
m68k-palmos-gcc -O1 -c counter.c -o counter.o
echo Step 2 -----------------------------------------------------
m68k-palmos-gcc -O1 counter.o -o counter
echo Step 3 -----------------------------------------------------
m68k-palmos-obj-res counter
echo Step 4 -----------------------------------------------------
build-prc  counter.prc "Counter" COUN *.grc *.bin
echo Step 5 -----------------------------------------------------
@del *.bin > nul
@del counter.o > nul
@del *.grc > nul
@del counter > nul
echo ------------------------------------------------------------
echo Compile done -----------------------------------------------
echo ------------------------------------------------------------
exit  