// C:\sample1\Counter.h
// Header File automaticaly generated from VFDIDE. Don't modify !!
// You will loose all manual modifications to this file!
// Generated: 01.09.2000 12:23:10
// (in case of errors please contact ogrossklaus@debitel.net)


#define formID_Counter 1003
#define lblID1 1004
#define lblID2 1005
#define fieldID_Name1 1006
#define fieldID_Name2 1007
#define fieldID_Name3 1008
#define fieldID_Name4 1009
#define fieldID_Name5 1010
#define fieldID_Name6 1011
#define fieldID_Name7 1012
#define fieldID_Name8 1013
#define fieldID_Punkt1 1014
#define fieldID_Punkt2 1015
#define fieldID_Punkt3 1016
#define fieldID_Punkt4 1017
#define fieldID_Punkt5 1018
#define fieldID_Punkt6 1019
#define fieldID_Punkt7 1020
#define fieldID_Punkt8 1021
#define fieldID_CurrName 1023
#define fieldID_Points 1024
#define ButtonID_Plus 1025
#define ButtonID_Minus 1026
#define alertID_Custom 1027
#define GlobalBitmap001 1022
#define VersionID 1
#define ApplNameID 1244
#define ApplID 1245
