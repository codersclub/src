/*
 * alertnum.c by ZDOCm [ 0.5 ]
 * This program is distributed under the terms of the GPL v2.0 or later
 * Download the GNU Public License (GPL) from www.gnu.org
 *  Support the Free Software Foundation.
 * 
 * 2002/05/05 mizotec<mizotec@nifty.com>
 * http://member.nifty.ne.jp/mizotec/
 */

#pragma pack(2)
#include <Pilot.h>


#include "alertnum.h"

#define alertInfo  3801


void AlertNum(CharPtr str, int num)
{
   char buf[64];
   StrPrintF(buf, "%d", num);
   FrmCustomAlert(alertInfo, str, buf, " ");
}
