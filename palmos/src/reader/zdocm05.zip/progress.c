/* like Progress */
/*
 * progress.c by ZDOCm 
 * This program is distributed under the terms of the GPL v2.0 or later
 * Download the GNU Public License (GPL) from www.gnu.org
 *  Support the Free Software Foundation.
 * 
 * 2002/05/03 mizotec<mizotec@nifty.com>
 * http://member.nifty.ne.jp/mizotec/
 */

/* There is already Progress in PalmOS3.x. */

#pragma pack(2)
#include <Pilot.h>


#include "progress.h"


FormPtr ProgStart(Word rscID, CharPtr newTitle)
{
   FormPtr frm;
   frm = FrmInitForm(rscID);
   FrmSetTitle(frm, newTitle);
   FrmDrawForm(frm);
   return frm;
}

void ProgStop(FormPtr frm)
{
   FrmEraseForm(frm);
   FrmDeleteForm(frm);
}
