void AlertNum(CharPtr str, int num);
