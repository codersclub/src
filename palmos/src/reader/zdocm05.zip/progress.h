/* like Progress */


void AlertNum(CharPtr str, int num);
FormPtr ProgStart(Word rscID, CharPtr newTitle);
void ProgStop(FormPtr frm);
