/*
 * ZDOCm [ Ver 0.5 ]
 * The base of source is ZDOC [ Ver.5.0.1b3 ].
 *
 */

#pragma pack(2)
#if 1
#include <Pilot.h>
#else
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <SerialMgr.h>
#endif

#define DISP_BITS 11
#define COUNT_BITS 3

#include "docrec.h"
#include "alertnum.h"

typedef struct
{
   unsigned char *buf;
   int len;
   int bSpace;
} Buffer;



/* 99/05/05 delay is debug ? */
static void delay(int b)
{
   int a;
   char dspStr[6];
   StrIToA((CharPtr) & dspStr[0], b);
   // <-----------------------------------------Delay Loop
   for (a = 0; a < 1000; a++) {
      WinDrawChars((CharPtr) "-EHANDLR-", 9, 30, 30);
      WinDrawChars((CharPtr) & dspStr[0], 5, 30, 70);
   }
   // <-----------------------------------------End Delay Loop
}



/* read  db->raw, raw->field | raw->cook->field */
/*	Replace the given buffer with an uncompressed version of itself. */
static unsigned int uncompress(Buffer * b)
{				/* b->buf == DOC_Text.raw */
   unsigned char *in_buf;
   unsigned char *out_buf;
   int j = 0, i = 0;

   out_buf = DOC_Text.cook;
   in_buf = b->buf;

   for (i = j = 0; i < b->len;) {
      unsigned int c = in_buf[i++];

      if (c > 0 && c < 9) {
	 while (c--) {
	    out_buf[j++] = in_buf[i++];
	 }
      } else if (c < 0x80) {
	 out_buf[j++] = c;
      } else if (c >= 0xc0) {
	 out_buf[j++] = ' ';
	 out_buf[j++] = c ^ 0x80;
      } else {
	 int di, n;
	 c = (c << 8) + in_buf[i++];
	 di = (c & 0x3fff) >> COUNT_BITS;
	 n = (c & ((1 << COUNT_BITS) - 1)) + 3;
	 while (n--) {
	    out_buf[j] = out_buf[j - di];
	    j++;
	 }
      }
   }


   if (j > MAXTEXTSIZE) {
      j = MAXTEXTSIZE;
   }
   b->buf = out_buf;
   b->len = j;
   return j;
}

static void doc_uncompress(Buffer * b)
{
   unsigned char *buf;
   if (DOC_Values.version != 2) {
      MemMove(DOC_Text.cook, b->buf, b->len);
      b->buf = DOC_Text.cook;
      buf = b->buf;
   }
   if (DOC_Values.version == 2) {
      b->bSpace = 0;
      uncompress(b);
      //                b->buf = DOC_Text.cook;
      buf = b->buf;
   }

   if (DOC_Values.version == 3) {
      int a;

      key[KEYLEN] = 0;
      for (a = 0; a < b->len; a++) {
	 buf[a] = (256 - buf[a]) - key[key[KEYLEN]];
	 key[KEYLEN]++;
	 if (key[KEYLEN] >= KEYLEN) {
	    key[KEYLEN] = 0;
	 }
      }
   }
   /* if(len > MAXTEXTSIZE){len = MAXTEXTSIZE;} */
   *(b->buf + b->len) = '\0';
}


/* read  db->raw, raw->field | raw->cook->field */
/* load recode No.index */
/*   out: DOC_Text.len DOC_Text.text */
void loadrec(DmOpenRef dbR, UInt index)
{

   VoidPtr recPtr = NULL;
   VoidHand recHand = NULL;

   Buffer b;
   int len = MAXTEXTSIZE;

   if (DOC_Values.count < index) {
      DOC_Text.len = 0;
   }
//   if (DOC_Text.index == index) {
//      return;
//   }
   /*   WinDrawChars((CharPtr) "-",1,150,0); */
   DOC_Text.index = index;
   recHand = DmQueryRecord(dbR, index);
   recPtr = MemHandleLock(recHand);
   len = (int) MemPtrSize(recPtr);
   if (len > MAXTEXTSIZE) {
      len = MAXTEXTSIZE;
   }
   // scrambuf();
   //   MemMove(DOC_Text.raw, recPtr, len);
   DOC_Text.rawLen = len;
   //   MemHandleUnlock(recHand);
   //   b.buf = DOC_Text.raw;
   b.buf = recPtr;
   b.len = len;

   doc_uncompress(&b);
   //   MemHandleUnlock(recHand);
   MemPtrUnlock(recPtr);
   DmReleaseRecord(dbR, DOC_Text.index, (Boolean) false);
   len = b.len;

   if (b.len > DOC_Values.doc_size) {
      delay(101);
   }
   //           if (len > DOC_Values.rec_size) { delay(102); }
   if (b.len < 2) {
      delay(103);
   }
   // MemHandleFree(recHand);
   // MemPtrFree(recPtr);
   DOC_Text.orgLen = len;
   DOC_Text.len = len;
   DOC_Text.text = b.buf;
   /*   WinDrawChars((CharPtr) "",1,150,0); */
}

#if 0
static unsigned char *memfind(unsigned char *t, int t_len, unsigned char *m,
			      int m_len)
{
   int i;

   for (i = t_len - m_len + 1; i > 0; i--, t++)
      if (t[0] == m[0] && MemCmp(t, m, m_len) == 0)
	 return t;
   return 0;
}
#else
static unsigned char *memfind(unsigned char *t, int t_len, unsigned char *m,
			      int m_len)
{
   int i;
   if (m_len == 1) {
      for (i = t_len - m_len + 1; i > 0; i--, t++) {
	 if (t[0] == m[0]) {
	    return t;
	 }
      }
   } else if (m_len == 2) {
      for (i = t_len - m_len + 1; i > 0; i--, t++) {
	 if (t[0] == m[0] && t[1] == m[1]) {
	    return t;
	 }
      }
   } else if (m_len == 3) {
      for (i = t_len - m_len + 1; i > 0; i--, t++) {
	 if (t[0] == m[0] && t[1] == m[1] && t[2] == m[2]) {
	    return t;
	 }
      }
   } else if (m_len == 4) {
      for (i = t_len - m_len + 1; i > 0; i--, t++) {
	 if (t[0] == m[0] && t[1] == m[1] && t[2] == m[2] && t[3] == m[3]) {
	    return t;
	 }
      }
   } else {
      for (i = t_len - m_len + 1; i > 0; i--, t++) {
	 if (t[0] == m[0] && t[1] == m[1] && t[2] == m[2] && t[3] == m[3]) {
	    if (MemCmp(t, m, m_len) == 0) {
	       return t;
	    }
	 }
      }
   }
   return 0;
}

#endif

/* read  db->raw, raw->field | raw->cook->field */
static void issue(Buffer * b, unsigned char src)
{				/* b->buf == DOC_Text.cook. */
   int iDest = b->len;
   unsigned char *dest = b->buf;

   if (b->bSpace) {
      b->bSpace = 0;
      if (src >= 0x40 && src <= 0x7f) {
	 dest[iDest++] = src ^ 0x80;
	 b->len = iDest;
	 return;
      }
      dest[iDest++] = ' ';
   } else {
      if (src == ' ') {
	 b->bSpace = 1;
	 b->len = iDest;
	 return;
      }
   }
   if ((src >= 1 && src <= 8) || src >= 0x80) {
      dest[iDest++] = 1;
   }
   dest[iDest++] = src;
   b->len = iDest;
   return;
}


/* write fild->raw, raw->db | raw->cook->db */
/*	Replace the given buffer with a compressed version of itself. */
static unsigned int compress(Buffer * b)
{				/* b->buf == DOC_Text.raw. */
   int i;

   unsigned char *pBuffer;
   unsigned char *pHit;
   unsigned char *pPrevHit;
   unsigned char *pTestHead;
   unsigned char *pTestTail;
   unsigned char *pEnd;

   unsigned int dist, compound, k;
   unsigned int start_time, end_time;

#if TEST
   start_time = TimGetSeconds();
#endif

   pHit = pPrevHit = pTestHead = pBuffer = b->buf;
   pTestTail = pTestHead + 1;
   pEnd = b->buf + b->len;

   b->buf = DOC_Text.cook;
   b->len = 0;

   while (pTestHead != pEnd) {
      if (pTestHead - pPrevHit > ((1 << DISP_BITS) - 1))
	 pPrevHit = pTestHead - ((1 << DISP_BITS) - 1);

      pHit =
	 memfind(pPrevHit, pTestTail - pPrevHit, pTestHead,
		 pTestTail - pTestHead);
      if (pHit == 0)
	 delay(0);
      if (pHit == 0
	  || pHit == pTestHead
	  || pTestTail - pTestHead > (1 << COUNT_BITS) + 2
	  || pTestTail == pEnd) {
	 if (pTestTail - pTestHead < 4) {
	    issue(b, pTestHead[0]);
	    pTestHead++;
	 } else {
	    if (b->bSpace) {
	       b->buf[b->len++] = ' ';
	       b->bSpace = 0;
	    }
	    dist = pTestHead - pPrevHit;
	    compound = (dist << COUNT_BITS) + pTestTail - pTestHead - 4;
	    b->buf[b->len++] = 0x80 + (compound >> 8);
	    b->buf[b->len++] = compound & 0xff;
	    pTestHead = pTestTail - 1;
	 }
	 pPrevHit = pBuffer;
      } else {
	 pPrevHit = pHit;
      }
      if (pTestTail != pEnd)
	 pTestTail++;
   }


   if (b->bSpace)
      b->buf[b->len++] = ' ';

   for (i = k = 0; i < b->len; i++, k++) {
      b->buf[k] = b->buf[i];
      if (b->buf[k] >= 0x80 && b->buf[k] < 0xc0)
	 b->buf[++k] = b->buf[++i];
      else if (b->buf[k] == 1) {
	 b->buf[k + 1] = b->buf[i + 1];
	 while (i + 2 < b->len && b->buf[i + 2] == 1 && b->buf[k] < 8) {
	    b->buf[k]++;
	    b->buf[k + b->buf[k]] = b->buf[i + 3];
	    i += 2;
	 }
	 k += b->buf[k];
	 i++;
      }
   }

   b->len = k;
#if TEST
   AlertNum("Time diff:", TimGetSeconds() - start_time);
#endif
   return k;
}


void WriteValues(DmOpenRef dbRef, Boolean new)
{
   Err err;
   VoidHand recHand = NULL;
   VoidPtr recPtr = NULL;
   if (new) {
      UInt at = 0;
      recHand = (VoidHand) DmNewRecord(dbRef, &at, sizeof DOC_Values);
   } else {
      recHand = DmGetRecord(dbRef, 0);
   }
   ErrFatalDisplayIf(recHand == 0, "Error docInfo.");
   recPtr = MemHandleLock(recHand);
   ErrFatalDisplayIf(recPtr == 0, "Error docInfo.");
//   DmSet(recPtr, 0, sizeof DOC_Values, 0);
   err = DmWrite(recPtr, 0, &DOC_Values, sizeof DOC_Values);
   ErrFatalDisplayIf(err != 0, "Error docInfo.");
   //   MemHandleUnlock(recHand);
   err = MemPtrUnlock(recPtr);
   ErrFatalDisplayIf(err != 0, "Error docInfo.");
   err = DmReleaseRecord(dbRef, 0, true);
   ErrFatalDisplayIf(err != 0, "Error docInfo.");
}



/* write fild->raw, raw->db | raw->cook->db */
/* prepare raw for saverec */
/*  DOC_Text. raw, rawLen, orgLen */
void saverec(DmOpenRef dbRef, Boolean new, UInt index)
{
   VoidHand recHand = NULL;
   VoidPtr recPtr = NULL;
   long oldSize;
   int oldCount;
   Buffer c;
   Err err;

   oldSize = DOC_Values.doc_size;
   oldCount = DOC_Values.count;

   c.buf = DOC_Text.raw;
   c.len = DOC_Text.rawLen;
   if (DOC_Values.version == 2) {
      c.bSpace = 0;
      compress(&c);
      *(c.buf + c.len) = '\0';
   }
   if (DOC_Values.version == 3) {
      int a;
      key[KEYLEN] = 0;
      for (a = 0; a < c.len; a++) {
	 DOC_Text.raw[a] = 256 - (DOC_Text.raw[a] + key[key[KEYLEN]]);
	 key[KEYLEN]++;
	 if (key[KEYLEN] >= KEYLEN) {
	    key[KEYLEN] = 0;
	 }
      }
   }
   recHand = DmNewRecord(dbRef, &index, c.len);
   ErrFatalDisplayIf(recHand == 0, "Error NewRecord.");
   recPtr = MemHandleLock(recHand);
   ErrFatalDisplayIf(recPtr == 0, "Error NewRecord.");
   err = DmWrite(recPtr, 0, c.buf, c.len);
   ErrFatalDisplayIf(err != 0, "Error NewRecord.");
   //   MemHandleUnlock(recHand);
   err = MemPtrUnlock(recPtr);
   ErrFatalDisplayIf(err != 0, "Error NewRecord.");
   err = DmReleaseRecord(dbRef, index, true);
   ErrFatalDisplayIf(err != 0, "Error NewRecord.");
   if (!new) {
      DmRemoveRecord(dbRef, index + 1);
      DOC_Values.count--;
      DOC_Values.doc_size = DOC_Values.doc_size - DOC_Text.orgLen;
      DOC_Text.orgLen = DOC_Text.rawLen;
   }
   DOC_Values.count++;
   DOC_Values.doc_size = DOC_Values.doc_size + DOC_Text.rawLen;
   if (DOC_Values.doc_size != oldSize || DOC_Values.count != oldCount) {
      WriteValues(dbRef, false);
   }
   DOC_Text.index = 0;
}
