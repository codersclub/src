/*
 * doclist.c by ZDOCm [ Ver.5m0.4 ]
 * This program is distributed under the terms of the GPL v2.0 or later
 * Download the GNU Public License (GPL) from www.gnu.org
 *  Support the Free Software Foundation.
 * 
 * 2002/04/16 mizotec<mizotec@nifty.com>
 * http://member.nifty.ne.jp/mizotec/
 */

#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <SerialMgr.h>

#include "doclist.h"

#define DocTypeID	'TEXt'
#define DocCreator   'REAd'

/* doc list variable */
static UInt g_docNum;		/* number of DOC */
struct DOC_INFO
{
   char name[dmDBNameLength];
};
static struct DOC_INFO *g_infoArray;
static char **g_listItemP;

UInt getDocNum(void)
{
   return g_docNum;
}

char *getDocName(Word num)
{
   return g_infoArray[num].name;
}

Word getDocPos(CharPtr name)
{
   int i;
   for (i = 0; i < g_docNum; i++) {
      if (StrCompare(name, g_infoArray[i].name) == 0) {
	 return i;
      }
   }
   return -1;
}



void freeDoclist(void)
{
   if (g_listItemP != NULL) {
      MemPtrFree(g_listItemP);
      g_listItemP = NULL;
   }
   if (g_infoArray != NULL) {
      MemPtrFree(g_infoArray);
      g_infoArray = NULL;
   }
}

static void MakeListArray(void)
{
   char name[dmDBNameLength];
   int count;
   DmSearchStateType state;
   UInt cardNo;
   int err;
   LocalID lid;

   freeDoclist();
   count = 0;
   g_docNum = 0;

   err = DmGetNextDatabaseByTypeCreator(true, &state, DocTypeID, DocCreator,
					false, &cardNo, &lid);

   while (!err) {
      count = count + 1;
      err =
	 DmGetNextDatabaseByTypeCreator(false, &state, DocTypeID, DocCreator,
					false, &cardNo, &lid);
   }

   if (count != 0) {
      g_listItemP = MemPtrNew(count * sizeof(*g_listItemP));
      if (g_listItemP == 0) {
	 FrmCustomAlert(alertInfo, "alloc listItem error", " ", " ");
	 return;
      }
      g_infoArray = MemPtrNew(count * sizeof(*g_infoArray));
      if (g_infoArray == 0) {
	 FrmCustomAlert(alertInfo, "alloc infoArray error", " ", " ");
	 return;
      }

      count = 0;
      err =
	 DmGetNextDatabaseByTypeCreator(true, &state, DocTypeID, DocCreator,
					false, &cardNo, &lid);
      while (!err) {
	 DmDatabaseInfo(0, lid, name,
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
			NULL);
	 MemMove(g_infoArray[count].name, name, dmDBNameLength);
	 g_listItemP[count] = g_infoArray[count].name;
	 count = count + 1;
	 err = DmGetNextDatabaseByTypeCreator
	    (false, &state, DocTypeID, DocCreator, false, &cardNo, &lid);
      }
   }
   g_docNum = count;
}

char **getDoclist(Boolean newlist)
{
   if (newlist || g_listItemP == NULL) {
      MakeListArray();
   }
   return g_listItemP;
}
