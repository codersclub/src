/*
 * ZDOCm [ Ver 0.5 ]
 * The base of source is ZDOC [ Ver.5.0.1b3 ].
 *
 * This program is distributed under the terms of the GPL v2.0 or later
 * Download the GNU Public License (GPL) from www.gnu.org
 *      
 *  Support the Free Software Foundation.
 *
 * by Zurk Technology Inc.
 * zurk@geocities.com
 * http://www.geocities.com/Area51/7689/zdoc.html
 * June/July 1998
 * Patched: Dec 1998 (Field Handler Patch)
 * modeify  
 * 1999/05/05-08/09 mizotec<HGH01156@nifty.ne.jp>
 * http://member.nifty.ne.jp/mizotec/
 *  ,2002/05/05 mizotec<mizotec@nifty.com>
 * http://member.nifty.ne.jp/mizotec/
 */

#pragma pack(2)
#if 1
#include <Pilot.h>
#else
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <SerialMgr.h>
#endif

#include "zdocm.h"
#define ZdocAppID    'CLEe'
//#define DocTypeID     'TEXt'
//#define DocCreator   'REAd'
// #define MAXDOC 20


#define UPDATE_GOPOS 10
#define UPDATE_NAME 21
#define UPDATE_OPEN 30

#define INSPTOFFMAX 512
#define SCRLINEMAX  40		/* char/line + x */

#define MAIN
#include "doclist.h"
#include "docrec.h"
#include "progress.h"
#include "alertnum.h"


typedef struct
{				/* Display Doc Record  outside */
   FieldPtr field;
   UInt len;			/* original */
   UInt index;			/* rec no ; 0 is no open */
   UInt borderLen;		/* A record and a record are connected. */
   UInt borderLf;
   UInt lines;			/* VisibleLines */
}
DOCFieldType;


static DOCFieldType DOC_Field;



static ListPtr g_list;
static ControlPtr g_popup;

static char triggerLabel[dmDBNameLength];	/* CategoryTruncateName */


// static FormPtr g_form;


/*	DmOpenRef RAM; */
/*	LocalID   RAMID; */
/*	VoidPtr  romx;	*/
/*	VoidHand rom;	*/

static LocalID g_dbID;		/* not zero is that dababase is open */
static DmOpenRef g_dbR;		/* DmOpenRef to open database,0 no open */
/*	unsigned char *ram;	*/
static char newRecord[] = "New:";

static struct
{
//   Word CurrentIndex;
   Word index;
   UInt page;
   Word insPos;
   Word slen;
   Int scroll;
}
goInfo;
static Word g_curno = -1;



static char findStr[32 + 1] = "";
static char dspStr[40 + 1];	/* Work for Display String */

typedef struct
{
   int scrollH;			// = 1;
   int scrollS;			// = -1;
   int scrollF;			// = 0;
   Boolean join;		// = true;
   FontID font;			// = stdFont;
   int go_page;
   int go_pos;
   char name[dmDBNameLength];
} appPrefType;

static appPrefType appPref;	// = {1,10,0,true, stdFont};

static int StartApplication(void);
static void EventLoop(void);
static void StopApplication(void);

static Boolean MainFormHandleEvent(EventPtr event);
static Boolean InfoFormHandleEvent(EventPtr event);
static Boolean CreateFormHandleEvent(EventPtr event);
static Boolean FindFormHandleEvent(EventPtr event);
static Boolean EditMenuEvent(EventPtr event);

static void SaveDirtyField(void);
static void SetInsPt(Word pos, Word len, Int linesToScroll);
static Err DisplayRecord(void);
static void UndoField(UInt index);

static void OpenDoc(Word listxtem);
static void CloseDoc(void);
static void dspOpenDoc(Word listxtem);



static Err CreateDoc(CharPtr name);
static VoidPtr GetObjectPtr(Word objID);
static void SetListArray(Word num);




#ifndef	DEBUG
# define debuginfo( x, y )	((void)0)
#else
static void debuginfo(CharPtr str, Long x)
{
   int i;
   UInt len;
   static pos = 20;
   for (i = 0; i < 20; i++) {
      dspStr[i] = ' ';
   }
   StrIToA((CharPtr) & dspStr[0], x);
   for (i = 0; i < 20; i++) {
      if (dspStr[i] == '\0') {
	 dspStr[i] = ' ';
      }
   }

   pos = pos + 10;
   if (pos > 130) {
      pos = 20;
   }
   len = StrLen(str);
   WinDrawChars(str, len, 20, pos);
   WinDrawChars((CharPtr) & dspStr[0], 8, 90, pos);
}
#endif




DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
   Word error;
//   error = RomVersionCompatible(0x02000000, launchFlags);
//   if(error)return(error);
   if (cmd == sysAppLaunchCmdNormalLaunch) {
      error = StartApplication();	// Application start code
      if (error)
	 return error;
      FrmGotoForm(formID_zdoc);
      EventLoop();		// Event loop
      StopApplication();	// Application stop code
   }
   // sysAppLaunchCmdFind
   // sysAppLaunchCmdGoTo
   // sysAppLaunchCmdSyncNotify
   // sysAppLaunchCmdExgReceiveData
   // sysAppLaunchCmdInitDatabase
   return 0;
}




/* the event handler for the "fine" */
/* formID_null or formID_new */
static Boolean CreateFormHandleEvent(EventPtr event)
{
   FormPtr form;
   FieldPtr field;

   Boolean handled = false;

   switch (event->eType) {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      FrmDrawForm(form);
//    FrmCustomAlert(alertInfo, "DrawForm", " ", " ");
      handled = true;
      break;

    case ctlSelectEvent:	// A control button was pressed and released.
      if (event->data.ctlEnter.controlID == buttonID_cancel) {
	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      } else if (event->data.ctlEnter.controlID == buttonID_new) {
	 CharPtr name;
	 field = GetObjectPtr(fieldID_new);
	 if (FldGetTextLength(field) != 0) {
	    Word pos;
	    Err error;
	    name = FldGetTextPtr(field);
	    error = CreateDoc(name);
	    if (error != 0) {
	       AlertNum("Create Error:", error);
	    } else {
	       SetListArray(g_curno);
	       StrCopy(appPref.name, name);
	       goInfo.page = 0;
	       goInfo.insPos = 0;
	       FrmUpdateForm(formID_zdoc, UPDATE_OPEN);
	    }
	 }
	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      } else if (event->data.ctlEnter.controlID == buttonID_abc) {
	 FieldPtr abcfield;
	 abcfield = GetObjectPtr(fieldID_abc);
	 if (FldGetTextLength(abcfield) != 0) {
	    int i;
	    char temp[21];	/* 21 is abcfield max len +1 */
	    for (i = 0; i < KEYLEN; i++) {
	       key[i] = 0;
	       temp[i] = 0;
	    }
	    StrCopy(&temp[0], FldGetTextPtr(abcfield));
	    for (i = 0; i < KEYLEN; i++) {
	       key[i] = temp[i];
	    }
//          DOC_Text.index = 0;
	 }
	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      }
      break;
    case menuEvent:
      handled = EditMenuEvent(event);
      break;
    case nilEvent:
//      handled = true;
      break;
    default:
      ;
   }
   return handled;
}


/* Get position of DocField. */
static UInt GetDFPos(UInt scrollPos)
{
   if (DOC_Field.borderLen > 0) {
      if (scrollPos > DOC_Field.borderLen) {
	 return scrollPos - DOC_Field.borderLen;
      } else {
	 return DOC_Field.len + scrollPos - DOC_Field.borderLen;
      }
   } else {
      return scrollPos;
   }
}

/* Get Index of DocField. */
static UInt GetDFIndex(UInt scrollPos)
{
   if (DOC_Field.borderLen > 0) {
      if (scrollPos > DOC_Field.borderLen) {
	 return DOC_Field.index + 1;
      } else {
	 return DOC_Field.index;
      }
   } else {
      return DOC_Field.index;
   }
}




/* Draw pos information */
static void infoPos(void)
{
   static UInt index;
   static Word pos;
   Word curPos;
   UInt curIndex;
   UInt len;

   curPos = FldGetInsPtPosition(DOC_Field.field);
   curIndex = GetDFIndex(curPos);
   curPos = GetDFPos(curPos);

   if (curIndex == index && curPos == pos) {
      return;
   }
   index = curIndex;
   pos = curPos;
   MemSet(dspStr, sizeof(dspStr), ' ');
   StrIToA(dspStr, index);
   len = StrLen(dspStr);
   dspStr[len] = ',';
   StrIToA(dspStr + len + 1, pos);
   len = StrLen(dspStr);
   dspStr[len] = ' ';
   if (len < 7) {
      len = len + (7 - len) * 2;
      /* 4ng 3ng */
   }
   //   len = StrLen(dspStr);
   //   StrCopy(dspStr + len , "12");
   WinDrawChars(dspStr, len, pos_about + 1, 145);
}




static FieldPtr SetFieldTextFromHandle(FieldPtr fldP, Handle txtH)
{
   Handle oldTxtH;
   oldTxtH = FldGetTextHandle(fldP);
   FldSetTextHandle(fldP, txtH);
   //   FldDrawField(fldP);
   // free the handle AFTER we call FldSetTextHandle().
   if (oldTxtH) {
      MemHandleFree((VoidHand) oldTxtH);
   }
   return fldP;
}

static void ClearFieldText(FieldPtr fieldP)
{
   SetFieldTextFromHandle(fieldP, NULL);
}


static FieldPtr SetFieldTextFromStr(FieldPtr fieldP, CharPtr strP, ULong size)
{
   Handle txtH;
   VoidPtr textPtr;
   Err err;
   size = size + 1;		/* add '\0' size */
   txtH = (Handle) MemHandleNew(size);
   ErrFatalDisplayIf(txtH == 0, "Cannot get new memory.");
   if (!txtH)
      return NULL;
   textPtr = MemHandleLock((VoidHand) txtH);
   ErrFatalDisplayIf(textPtr == 0, "Cannot get HandleLock.");
   MemMove(textPtr, strP, size);
//    *(textPtr+size-1)= '\0';
   //   MemHandleUnlock((VoidHand) txtH);
   err = MemPtrUnlock(textPtr);
   ErrFatalDisplayIf(err != 0, "Cannot Handle UnLock.");
   ClearFieldText(fieldP);
   return SetFieldTextFromHandle(fieldP, txtH);
}


static void DrawMark(int s)
{
   if (s == 0) {
      WinDrawChars("  ", 2, 142, 0);	/* Normal */
   } else {
      WinDrawChars("/", 1, 142, 0);	/* Wait */
   }
}


static void CloseDoc(void)
{
   UInt scrollPos;
   UInt len;


   if (g_dbID != 0) {
      SaveDirtyField();

      scrollPos = FldGetScrollPosition(DOC_Field.field);
      appPref.go_page = GetDFIndex(scrollPos);
      appPref.go_pos = GetDFPos(scrollPos);

      StrCopy(appPref.name, getDocName(g_curno));

      DmCloseDatabase(g_dbR);
      DOC_Text.index = 0;
      DOC_Field.index = 0;
      DOC_Values.count = 0;
      g_dbR = 0;
      g_dbID = 0;

   }
   ClearFieldText(DOC_Field.field);
}


static int StartApplication(void)
{
   UInt size;
   SWord ver;
   Word index;
   size = sizeof(appPref);
//   MemSet(appPref, sizeof(appPref), 0);
   ver = PrefGetAppPreferences(ZdocAppID, 0, &appPref, &size, false);
   if (sizeof(appPref) != size || ver != 0) {
      // init Pref
      appPref.scrollH = 1;
      appPref.scrollS = -1;
//      appPref.scrollF = 0;
      appPref.join = true;
      appPref.font = stdFont;
//      appPref.go_page = 0;
//      appPref.go_pos = 0;
//      appPref.name[0] = '\0';
   }
   getDoclist(true);
   index = getDocPos(appPref.name);
   goInfo.index = index;
   if (index != -1) {
      goInfo.page = appPref.go_page;
      goInfo.insPos = appPref.go_pos;
   }
//   goInfo.CurrentIndex = -1;
   return 0;
}


static void StopApplication(void)
{

   CloseDoc();
   freeDoclist();
   //        FldFreeMemory(DOC_Field.field);
   //   FldEraseField(DOC_Field.field);
   FrmCloseAllForms();
   PrefSetAppPreferences(ZdocAppID, 0, 0, &appPref, sizeof(appPref), false);
}

static CharPtr StriStr(CharPtr s, CharPtr t)
{
   CharPtr t1;

   t1 = t;
   while (*s != '\0') {
      CharPtr s2;
      s2 = s;
      t1 = t;
      while (*t1 != '\0') {
	 Char c1, c2;
	 c1 = *t1;
	 c2 = *s2;
	 if (c1 != c2) {
	    if (c1 > c2) {
	       Char c3;
	       c3 = c2;
	       c2 = c1;
	       c1 = c3;
	    }
	    if (c1 < 'A' || c1 > 'Z') {
	       break;
	    }
	    c1 = c1 + 32;
	    if (c1 != c2) {
	       break;
	    }
	 }
	 s2++;
	 t1++;
      }
      if (*t1 == '\0') {
	 return s;
      }
      s++;
   }

   return NULL;
}


char findwork[sizeof(findStr) * 2];
/* Find string/rec Set page, pos */
static Boolean FindPos2(void)
{
   VoidHand textHand;
   VoidPtr textPtr;
   CharPtr p;
   int page;
   int len1;
   int len2;
   int find_len;
   int pos;

   p = NULL;
   find_len = StrLen(findStr);
   //   find_len = 0;
   if (find_len == 0) {
      return false;
   }
   /*   WinDrawChars((CharPtr) "$B!"(B",1,150,0); */
   DrawMark(1);

   len1 = FldGetTextLength(DOC_Field.field);
   pos = FldGetInsPtPosition(DOC_Field.field);
   page = DOC_Field.index;
   if (len1 > pos) {
      textHand = (VoidHand) FldGetTextHandle(DOC_Field.field);
      textPtr = MemHandleLock(textHand);
      len2 = len1 - pos;
      MemMove(DOC_Text.cook + pos, textPtr + pos, len2);
      //                MemHandleUnlock(textHand);
      MemPtrUnlock(textPtr);
      DOC_Text.len = len1;
      DOC_Text.text = DOC_Text.cook;
      DOC_Text.cook[len1] = '\0';
      p = StriStr(DOC_Text.cook + pos + 1, findStr);
      if (p != NULL) {
	 goInfo.page = page;
	 goInfo.insPos = p - DOC_Text.text;
	 goInfo.slen = find_len;
	 goInfo.scroll = appPref.scrollF;
	 DrawMark(0);
	 return true;
      }
      if (len2 > find_len) {
	 len2 = find_len - 1;
	 pos = len1 - len2;
      } else {
	 pos++;
	 len2--;
      }
   } else {
      len2 = 0;
   }

   page++;
   while (page <= DOC_Values.count) {
      //                debuginfo("find len2:", len2);
      MemMove(findwork, DOC_Text.text + pos, len2);
      loadrec(g_dbR, page);
#if 1
      MemMove(findwork + len2, DOC_Text.text, find_len - 1);
      findwork[len2 + find_len - 1] = '\0';
      p = StriStr(findwork, findStr);
      //                debuginfo("Frm", page);
      //                debuginfo("FrmGetObjectPtr(findfield)", 3);
#endif
      if (p != NULL) {
	 goInfo.page = page - 1;
	 goInfo.insPos = pos + (p - findwork);
	 goInfo.slen = find_len;
	 goInfo.scroll = appPref.scrollF;
	 DrawMark(0);
	 return true;
      }
      p = StriStr(DOC_Text.text, findStr);
      if (p != NULL) {
	 goInfo.page = page;
	 goInfo.insPos = p - DOC_Text.text;
	 goInfo.slen = find_len;
	 goInfo.scroll = appPref.scrollF;
	 DrawMark(0);
	 return true;
      }
      len1 = DOC_Text.len;
      len2 = len1;
      if (len2 > find_len) {
	 len2 = find_len - 1;
      } else {
      }
      pos = len1 - len2;
      page++;
   }
   DrawMark(0);
   return false;
}

static Boolean FindPos(void)
{
   Boolean bl;
   FormPtr frm;
   frm = ProgStart(formID_wait, "wait:find");
   DOC_Text.index = 0;
   bl = FindPos2();
   if (bl && DOC_Field.borderLen > 0 && DOC_Field.index == goInfo.page) {
      goInfo.page = GetDFIndex(goInfo.insPos);
      goInfo.insPos = GetDFPos(goInfo.insPos);
      DOC_Field.index = 0;
   }
   ProgStop(frm);
   return bl;
}


static VoidPtr GetObjectPtr(Word objID)
{
   FormPtr form;
   form = FrmGetActiveForm();
   return FrmGetObjectPtr(form, FrmGetObjectIndex(form, objID));
}



static Boolean EditMenuEvent(EventPtr event)
{
   void *control;
   Word objIndex;
   FormObjectKind kind;
   FormPtr form;
   Boolean handled = false;

   form = FrmGetActiveForm();

   if (menuitemID_undo > event->data.menu.itemID
       || event->data.menu.itemID > menuitemID_select) {
      return false;
   }

   objIndex = FrmGetFocus(form);
   if (objIndex == noFocus) {
      return false;
   }
   control = FrmGetObjectPtr(form, objIndex);
   kind = FrmGetObjectType(form, objIndex);
   if (frmFieldObj == kind || frmTableObj == kind) {
      switch (event->data.menu.itemID) {
       case menuitemID_undo:
	 FldUndo(control);
	 handled = true;
	 break;
       case menuitemID_cut:
	 FldCut(control);
	 handled = true;
	 break;
       case menuitemID_copy:
	 FldCopy(control);
	 handled = true;
	 break;
       case menuitemID_paste:
	 FldPaste(control);
	 handled = true;
	 break;
       case menuitemID_select:
	 FldSetSelection(control, 0, FldGetTextLength(control));
	 handled = true;
	 break;
       default:
	 handled = false;
      }
   }
   return handled;
}


static void FindFormInit(FormPtr form)
{
   FieldPtr findfield;
   findfield = GetObjectPtr(fieldID_find);
   findStr[sizeof(findStr)] = '\0';
   SetFieldTextFromStr(findfield, findStr, sizeof(findStr));
}

/* Find Form */
/* the event handler for the "fine" */
static Boolean FindFormHandleEvent(EventPtr event)
{
   Boolean handled = false;

   FieldPtr findfield;
   FormPtr form;


   switch (event->eType) {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      FindFormInit(form);
      FrmDrawForm(form);
      handled = true;
      break;
    case penDownEvent:
      if (event->screenY < 0 || event->screenY > 50) {
//       FrmReturnToForm(formID_zdoc);
	 FrmReturnToForm(0);
	 handled = true;
      }
      break;
    case ctlSelectEvent:
      findfield = GetObjectPtr(fieldID_find);
      if (event->data.ctlSelect.controlID == buttonID_cancel) {
	 //                     FrmGotoForm(formID_zdoc);
//       FrmReturnToForm(formID_zdoc);
	 FrmReturnToForm(0);
	 handled = true;
      } else if (event->data.ctlSelect.controlID == buttonID_find) {
	 int len;
	 debuginfo("FrmGetObjectPtr(findfield)", findfield);
	 len = FldGetTextLength(findfield);
	 if (len > 0) {
	    ListPtr list;
	    Word listxtem;
	    Boolean hit;
	    form = FrmGetActiveForm();

	    list =
	       FrmGetObjectPtr(form, FrmGetObjectIndex(form, listID_find));
	    listxtem = LstGetSelection(list);
	    debuginfo("listxtem", listxtem);
	    if (listxtem == 0) {
	       if (len > sizeof(findStr) + 1) {
		  len = sizeof(findStr) - 1;
	       }
	       StrNCopy(findStr, FldGetTextPtr(findfield), len);
	       findStr[len] = '\0';
	       hit = FindPos();
	    } else {
	       CharPtr p;
	       StrCopy(dspStr, FldGetTextPtr(findfield));
	       p = StrChr(dspStr, ',');
	       if (p == NULL) {
		  goInfo.insPos = 0;
	       } else {
		  *p = '\0';
		  goInfo.insPos = StrAToI(p + 1);
	       }
	       goInfo.page = StrAToI(dspStr);
	       goInfo.slen = 0;
	       goInfo.scroll = appPref.scrollF;
	       hit = true;
	    }
	    if (hit != false) {
	       /* frmUpdateEvent */
	       FrmUpdateForm(formID_zdoc, UPDATE_GOPOS);
	    }
	 }
//       FrmReturnToForm(formID_zdoc);
	 FrmReturnToForm(0);
	 handled = true;
      }
      break;
    case menuEvent:
      handled = EditMenuEvent(event);
      break;
    default:
      ;
   }
   return handled;
}



static short GetValue(Word objID)
{
   return CtlGetValue(GetObjectPtr(objID));
}
static void SetValue(Word objID, short value)
{
   CtlSetValue(GetObjectPtr(objID), value);
}


static LocalID InfoFormInit(FormPtr form)
{
   FieldPtr field;
   ControlPtr control;
   UInt len;

   UInt cardNo;
   LocalID sDbID = 0;

   UInt attributes;
   ULong numRecords;
   ULong totalBytes;
   ULong dataBytes;
   Word listxtem;


   StrIToA(dspStr, appPref.scrollH);
   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_scrollH);
   SetFieldTextFromStr(field, dspStr, len);

   StrIToA(dspStr, appPref.scrollS);
   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_scrollS);
   SetFieldTextFromStr(field, dspStr, len);

   StrIToA(dspStr, appPref.scrollF);
   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_scrollF);
   SetFieldTextFromStr(field, dspStr, len);

   StrIToA(dspStr, appPref.font);
   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_font);
   SetFieldTextFromStr(field, dspStr, len);


   if (appPref.join != false) {
      SetValue(checkID_join, true);
   } else {
      SetValue(checkID_join, false);
   }

   StrCopy(dspStr, " Version:");
   switch (DOC_Values.version) {
    case 1:
      StrCat(dspStr, "Uncompressed.");
      break;
    case 2:
      StrCat(dspStr, "Compressed.");
      break;
    case 3:
      StrCat(dspStr, "Encrypted.");
      break;
    default:
      StrCat(dspStr, "Unknown.");
   }
   len = StrLen(dspStr);


   StrCat(dspStr, " Size:");
   len = StrLen(dspStr);
   StrIToA(dspStr + len, DOC_Values.doc_size);

   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_Info1);
   SetFieldTextFromStr(field, dspStr, len);

   StrCopy(dspStr, " Rec Num:");
   len = StrLen(dspStr);
   StrIToA(dspStr + len, DOC_Values.count);
   len = StrLen(dspStr);
   StrCopy(dspStr + len, " current:");
   len = StrLen(dspStr);
   StrIToA(dspStr + len, DOC_Field.index);
   len = StrLen(dspStr);
   dspStr[len] = ',';
   StrIToA(dspStr + len + 1, FldGetInsPtPosition(DOC_Field.field));

   len = StrLen(dspStr);
   field = GetObjectPtr(fieldID_Info2);
   SetFieldTextFromStr(field, dspStr, len);

   //                len = StrLen(array[listxtem]);
   //                field=GetObjectPtr(fieldID_new);
   //                SetFieldTextFromStr(field, array[listxtem], len);
   cardNo = 0;
   listxtem = LstGetSelection(g_list);

   if (listxtem < getDocNum()) {
      sDbID = DmFindDatabase(0, getDocName(listxtem));
   }
   if (sDbID != 0) {

      char newName[dmDBNameLength];
      DmDatabaseSize(cardNo, sDbID, &numRecords, &totalBytes, &dataBytes);

      StrCopy(dspStr, " Rec:");
      len = StrLen(dspStr);
      StrIToA(dspStr + len, numRecords);
      len = StrLen(dspStr);
      StrCopy(dspStr + len, "  Total:");
      len = StrLen(dspStr);
      StrIToA(dspStr + len, totalBytes);
      len = StrLen(dspStr);
      StrCopy(dspStr + len, "  Data:");
      len = StrLen(dspStr);
      StrIToA(dspStr + len, dataBytes);

      len = StrLen(dspStr);
      field = GetObjectPtr(fieldID_Info3);
      SetFieldTextFromStr(field, dspStr, len);

      DmDatabaseInfo(cardNo, sDbID, newName, &attributes, NULL, NULL,
		     NULL, NULL, NULL, NULL, NULL, NULL, NULL);
      len = StrLen(newName);

      field = GetObjectPtr(fieldID_new);
      SetFieldTextFromStr(field, newName, len);
      if (attributes & dmHdrAttrBackup) {
	 SetValue(checkID_back, true);
      } else {
	 SetValue(checkID_back, false);
      }
      if (attributes & dmHdrAttrOpen) {
	 SetValue(checkID_open, true);
      } else {
	 SetValue(checkID_open, false);
      }

      if (g_dbID == sDbID) {
	 field = GetObjectPtr(fieldID_new);
	 //         FldSetUsable(field, false);
	 control = GetObjectPtr(checkID_back);
	 //         CtlSetUsable(control, false);
	 control = GetObjectPtr(buttonID_del);
	 CtlHideControl(control);
      }
   }
   return sDbID;
}



/* Info Form */
static Boolean InfoFormHandleEvent(EventPtr event)
{
   Boolean handled = false;
   FieldPtr field;
   UInt cardNo;
   static LocalID sDbID;
   UInt attributes;
   FormPtr form;
   Word listxtem;

   switch (event->eType) {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      sDbID = InfoFormInit(form);
      FrmDrawForm(form);
#if TEST
      WinDrawChars("Build: " __DATE__ " " __TIME__,
		   StrLen("Build: " __DATE__ " " __TIME__), 30, 1);
#endif

      handled = true;
      break;
    case ctlSelectEvent:
      if (event->data.ctlSelect.controlID == buttonID_cancel) {
	 //                     FrmGotoForm(formID_zdoc);
	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      } else if (event->data.ctlSelect.controlID == buttonID_ok) {
	 Boolean dmset;
	 CharPtr p;
	 char newName[dmDBNameLength];

	 field = GetObjectPtr(fieldID_scrollH);
	 StrCopy(dspStr, FldGetTextPtr(field));
	 appPref.scrollH = StrAToI(dspStr);
	 field = GetObjectPtr(fieldID_scrollS);
	 StrCopy(dspStr, FldGetTextPtr(field));
	 appPref.scrollS = StrAToI(dspStr);
	 field = GetObjectPtr(fieldID_scrollF);
	 StrCopy(dspStr, FldGetTextPtr(field));
	 appPref.scrollF = StrAToI(dspStr);
	 field = GetObjectPtr(fieldID_font);
	 StrCopy(dspStr, FldGetTextPtr(field));
	 appPref.font = StrAToI(dspStr);
#if 0
//       FldSetUsable(field, false);
	 FldSetFont(field, appPref.font);
#endif
#if 0
	 if (fs_font > ledFont) {
	    fs_font = stdFont;
	 }
#endif
	 appPref.join = GetValue(checkID_join);
	 listxtem = LstGetSelection(g_list);

	 if (sDbID != 0) {
	    cardNo = 0;
	    DmDatabaseInfo(cardNo, sDbID, newName, &attributes, NULL, NULL,
			   NULL, NULL, NULL, NULL, NULL, NULL, NULL);

	    dmset = false;
	    if ((GetValue(checkID_back) > 0) !=
		((attributes & dmHdrAttrBackup) > 0)) {
	       if (GetValue(checkID_back) == 1) {
		  attributes = attributes | (dmHdrAttrBackup);
	       } else {
		  attributes = attributes & (~dmHdrAttrBackup);
	       }
	       dmset = true;
	    }
	    field = GetObjectPtr(fieldID_new);
	    p = FldGetTextPtr(field);
	    if (StrCompare(p, newName) == 0) {
	       p = NULL;
	    }
	    if (p != NULL || dmset) {
	       Err error;
	       error = DmSetDatabaseInfo
		  (cardNo, sDbID, p, dmset ? &attributes : NULL, NULL, NULL,
		   NULL, NULL, NULL, NULL, NULL, NULL, NULL);
	       if (error == 0) {
		  FrmUpdateForm(formID_zdoc, UPDATE_NAME);
	       } else {
		  AlertNum("DmSetDatabase Error", error);
	       }
	    }
	 }

	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      } else if (event->data.ctlSelect.controlID == buttonID_del) {
	 if (g_dbID != sDbID) {
	    listxtem = LstGetSelection(g_list);

	    if (listxtem >= 0 && getDocNum() > 0) {
	       DmDeleteDatabase(0, sDbID);
	    }
	    FrmUpdateForm(formID_zdoc, UPDATE_NAME);
	 }
	 FrmReturnToForm(formID_zdoc);
	 handled = true;
      }
      break;
    case menuEvent:
      handled = EditMenuEvent(event);
      break;
    default:
      ;
   }
   return handled;
}

static void SetListArray(Word num)
{
   int count;
   CharPtr listItem;
   FormPtr form;
   char **listItemP;

   listItemP = getDoclist(true);
   form = FrmGetActiveForm();

   count = getDocNum();
   LstSetListChoices(g_list, listItemP, count);
   if (num >= count) {
      num = 0;
   }
   if (count > 0) {
      LstSetSelection(g_list, num);
      LstSetHeight(g_list, count);

      listItem = LstGetSelectionText(g_list, num);
   } else {
      listItem = "*";
   }
   StrCopy(triggerLabel, listItem);
   CategorySetTriggerLabel(g_popup, triggerLabel);
}

static Boolean ApplicationHandleEvent(EventPtr event)
{
   Word formID;
   FormPtr form;

   if (event->eType == frmLoadEvent) {
      formID = event->data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) {
       case alertID_new:
	 FrmSetEventHandler(form, CreateFormHandleEvent);
	 break;
       case formID_null:
	 FrmSetEventHandler(form, CreateFormHandleEvent);
	 break;
       case formID_find:
	 FrmSetEventHandler(form, FindFormHandleEvent);
	 break;
       case formID_info:
	 FrmSetEventHandler(form, InfoFormHandleEvent);
	 break;
       case formID_zdoc:
	 FrmSetEventHandler(form, MainFormHandleEvent);
	 break;
      }
      return true;
   }

   return false;
}



static void EventLoop(void)
{
   /*   ULong   guess=0;        */
   short err;
   EventType event;
   do {
      EvtGetEvent(&event, evtWaitForever);
      if (SysHandleEvent(&event))
	 continue;
      if (MenuHandleEvent((void *) 0, &event, &err))
	 continue;
      if (ApplicationHandleEvent(&event))
	 continue;
      FrmDispatchEvent(&event);
   } while (event.eType != appStopEvent);
}


static void SetNewRecord(void)
{
   CharPtr cPtr;
   SystemPreferencesType sysPrefs;	/* User's Pilot preferences. */
   DateTimeType dateTime;
   UInt len;

   cPtr = DOC_Text.raw;

   PrefGetPreferences(&sysPrefs);
#if 1
   MemMove(cPtr, newRecord, sizeof newRecord);
   len = StrLen(cPtr);
#else
   len = 0;
#endif
   TimSecondsToDateTime(TimGetSeconds(), &dateTime);
   DateToAscii(dateTime.month, dateTime.day, dateTime.year,
	       sysPrefs.dateFormat, cPtr + len);
   StrCat(cPtr, " ");
   len = StrLen(cPtr);
   TimeToAscii(dateTime.hour, dateTime.minute, sysPrefs.timeFormat,
	       cPtr + len);
   StrCat(cPtr, "\n");
   DOC_Text.orgLen = 0;
   DOC_Text.rawLen = StrLen(cPtr);
}


static Err CreateDoc(CharPtr name)
{
   DmOpenRef dbRef;
   LocalID lid;
   Err err;

   err =
      DmCreateDatabase(0, name,
		       'R' * 256 * 256 * 256 + 'E' * 256 * 256 + 'A' * 256 +
		       'd',
		       'T' * 256 * 256 * 256 + 'E' * 256 * 256 + 'X' * 256 +
		       't', false);
   if (err != 0) {
//      WinDrawChars("Error  ", 7, pos_about, 145);
      return err;
   }
   lid = DmFindDatabase(0, name);
   ErrFatalDisplayIf(lid == 0, "Cannot find database.");
   dbRef = DmOpenDatabase(0, lid, dmModeReadWrite);

   DOC_Values.reserved1 = 0;
   DOC_Values.doc_size = 0;
   DOC_Values.count = 0;
   DOC_Values.rec_size = MAXTEXTSIZE;
   DOC_Values.reserved2 = 0;
   if (GetValue(checkID_comp) == 1) {
      DOC_Values.version = 2;
   } else {
      DOC_Values.version = 1;
   }
   if (GetValue(checkID_enc) == 1) {
      DOC_Values.version = 3;
   }
   WriteValues(dbRef, true);
   SetNewRecord();
   saverec(dbRef, true, 1);
   DmCloseDatabase(dbRef);
   return err;
}


static void ReField(UInt index)
{
   if (DOC_Field.borderLen == 0) {
      UndoField(index);
      SetInsPt(0, 0, 0);
   }
}


static void delrec(void)
{
   if (g_dbID != 0) {
      if (DOC_Field.index <= DOC_Values.count && DOC_Values.count > 1
	  && DOC_Field.borderLen == 0) {
	 DmOpenRef dbW;
	 dbW = DmOpenDatabase(0, g_dbID, dmModeReadWrite);
	 DmRemoveRecord(dbW, DOC_Field.index);
	 DOC_Values.count--;
	 DOC_Values.doc_size = DOC_Values.doc_size - DOC_Field.len;
	 WriteValues(dbW, false);
	 DmCloseDatabase(dbW);
	 DOC_Text.index = -1;
	 if (DOC_Field.index > DOC_Values.count) {
	    DOC_Field.index = DOC_Values.count;
	 }
	 ReField(DOC_Field.index);
      } else {
	 AlertNum("Can't del:", DOC_Field.index);
      }
   }
}

static void SaveDirtyField(void)
{
   if (g_dbID != 0 && DOC_Field.index > 0
       && FldDirty(DOC_Field.field) != false) {
      if (DOC_Field.borderLen == 0) {
	 DmOpenRef dbW;
	 VoidHand textHand;
	 VoidPtr textPtr;
	 UInt len;
	 len = FldGetTextLength(DOC_Field.field);
	 if (len == 0) {
	    delrec();
	 } else {
	    FormPtr frm;
	    DrawMark(1);
	    frm = ProgStart(formID_wait, "wait:save");

	    dbW = DmOpenDatabase(0, g_dbID, dmModeReadWrite);
	    textHand = (VoidHand) FldGetTextHandle(DOC_Field.field);
	    textPtr = MemHandleLock(textHand);
	    MemMove(DOC_Text.raw, textPtr, len);

	    MemPtrUnlock(textPtr);
	    DOC_Text.rawLen = len;
	    DOC_Text.orgLen = DOC_Field.len;
	    saverec(dbW, false, DOC_Field.index);
	    DmCloseDatabase(dbW);

	    ProgStop(frm);
	    DrawMark(0);
	 }
      } else {
	 FrmCustomAlert(alertInfo, "can't save join", "", "");
      }
      FldSetDirty(DOC_Field.field, false);
   }
}

static void UndoField(UInt index)
{
   DrawMark(1);
//   FldSetUsable(DOC_Field.field, false);
   if (DOC_Field.borderLen != 0) {
      FrmCustomAlert(alertInfo, "join undo", "", "");
      DOC_Field.borderLen = 0;
      DOC_Field.index = 0;
   }
   loadrec(g_dbR, index);

   DOC_Field.len = DOC_Text.len;
   DOC_Field.index = DOC_Text.index;
   SetFieldTextFromStr(DOC_Field.field, DOC_Text.text, DOC_Field.len);
//   FldSetUsable(DOC_Field.field, true);
   DrawMark(0);
}


/* set InsPt,  set selections, and Scroll */
static void SetInsPt(Word pos, Word len, Int linesToScroll)
{
   Word scrollPos;
   Word textHeight;
   Word fieldHeight;
   FormPtr form;

   form = FrmGetActiveForm();
   if (linesToScroll != 0) {
      //
   }
   FrmHideObject(form, FrmGetObjectIndex(form, fieldID_zdoc));

   FldSetScrollPosition(DOC_Field.field, pos);
   FldGetScrollValues(DOC_Field.field, &scrollPos, &textHeight, &fieldHeight);
   if (textHeight > scrollPos + fieldHeight) {
      if (linesToScroll > 0) {
	 FldScrollField(DOC_Field.field, linesToScroll, up);
      } else if (linesToScroll < 0) {
	 FldScrollField(DOC_Field.field, fieldHeight + linesToScroll, up);
      }
   } else {
      /* The last portion is exception treatment. */ ;
   }

   if (linesToScroll != 0) {
//      FldDrawField(DOC_Field.field);
   }
   FrmShowObject(form, FrmGetObjectIndex(form, fieldID_zdoc));
   FldSetInsPtPosition(DOC_Field.field, pos);
//   FldSetInsertionPoint(DOC_Field.field, pos);
   FldSetSelection(DOC_Field.field, pos, pos + len);
   FldGrabFocus(DOC_Field.field);
   InsPtEnable(true);
   return;
}


static Err DisplayRecord(void)
{
   FormPtr form;
   UInt index;
   FieldAttrType attr;

   index = goInfo.page;
   if (index > 0 && index <= DOC_Values.count) {
//      FldSetUsable(DOC_Field.field, false);
      if (DOC_Field.borderLen == 0) {
	 SaveDirtyField();
      } else {
	 FldGetAttributes(DOC_Field.field, &attr);
	 attr.editable = 1;
	 attr.underlined = grayUnderline;
	 FldSetAttributes(DOC_Field.field, &attr);
	 DOC_Field.borderLen = 0;
	 DOC_Field.index = 0;
      }

      if (DOC_Field.index != index) {
	 UndoField(index);
      }

      SetInsPt(goInfo.insPos, goInfo.slen, goInfo.scroll);
//      FrmShowObject(form, FrmGetObjectIndex(form, fieldID_zdoc));
//      FldSetUsable(DOC_Field.field, true);
      return 0;
   }
   return 1;
}



static Err OpenReadDatabase(char *name)
{
   VoidHand recHand = NULL;
   VoidPtr recPtr = NULL;
   UInt maxrec;
   LocalID lid;
   lid = DmFindDatabase(0, name);
   if (lid == 0) {
      return 1;
   }
   g_dbR = DmOpenDatabase(0, lid, dmModeReadOnly);
   if (g_dbR == 0) {
      return 1;
   }
   g_dbID = lid;
   maxrec = DmNumRecords(g_dbR);
   recHand = DmQueryRecord(g_dbR, 0);
   if (recHand == 0) {
      CloseDoc();
      return 2;
   }
   recPtr = MemHandleLock(recHand);
   MemMove(&DOC_Values, recPtr, sizeof DOC_Values);
   //   MemHandleUnlock(recHand);
   MemPtrUnlock(recPtr);
   DmReleaseRecord(g_dbR, 0, (Boolean) false);
   if (maxrec <= DOC_Values.count) {
      WinDrawChars((CharPtr) " Disagreement of maxrec.", 12, 40, 3);
      DOC_Values.count = maxrec - 1;
   }
   if (DOC_Values.version == 0 || DOC_Values.version > 3) {
      AlertNum("DOC Varsion:", DOC_Values.version);
   }

   return 0;
}




static Boolean NextRecord(void)
{
   if (g_dbID != 0) {
      goInfo.page = DOC_Field.index + 1;
      goInfo.insPos = 0;
      goInfo.slen = 0;
      goInfo.scroll = 0;

      if (DisplayRecord() == 0) {
	 return true;
      }
   }
   return false;
}

static Boolean PrevRecord(Boolean last)
{
   if (g_dbID != 0) {
      goInfo.page = DOC_Field.index - 1;
      if (last) {
	 goInfo.insPos = 9999;
      } else {
	 goInfo.insPos = 0;
      }
      goInfo.slen = 0;
      goInfo.scroll = 0;

      if (DisplayRecord() == 0) {
	 return true;
      }
   }
   return false;
}




/* Go to Bottom of Page */
static Boolean GoBottom(void)
{
   Word endpos;
   Word scrollPos;
   Word textHeight;
   Word fieldHeight;

   endpos = FldGetTextLength(DOC_Field.field);
   FldGetScrollValues(DOC_Field.field, &scrollPos, &textHeight, &fieldHeight);
   if (textHeight <= scrollPos + fieldHeight) {
      if (endpos == FldGetInsPtPosition(DOC_Field.field)) {
	 return false;
      } else {
	 FldSetInsPtPosition(DOC_Field.field, endpos);
//       FldSetInsertionPoint(DOC_Field.field, endpos);
	 FldGrabFocus(DOC_Field.field);
	 return true;
      }
   }

   SetInsPt(endpos, 0, -1);
   return true;
}


/* Go to Top of Page */
static Boolean GoTop(void)
{
   UInt pos;
   pos = FldGetScrollPosition(DOC_Field.field);
   if (pos == 0) {
      pos = FldGetInsPtPosition(DOC_Field.field);
      if (pos == 0) {
	 return false;
      }
   }
   SetInsPt(0, 0, 0);
   return true;
}


#if 0
static Word strip_field(Word lines)
{
   UInt scrollPos;
   Boolean strip;


//   lines++;
//      FrmCustomAlert(alertInfo, "strip","","");
   strip = false;
   while (lines > 0 && strip == false) {
      scrollPos = FldGetScrollPosition(DOC_Field.field);
      if (scrollPos > DOC_Field.borderLen + DOC_Field.borderLf) {
	 /* It is truth if the new-line is included by borderLen from scrollPos. */
	 strip = true;
      } else {
	 FldScrollField(DOC_Field.field, 1, down);
	 lines--;
      }
   }
   if (strip) {
      UInt borderLen = DOC_Field.borderLen;
      goInfo.page = DOC_Field.index + 1;
      goInfo.insPos = scrollPos - borderLen;
      goInfo.slen = 0;
      goInfo.scroll = 0;
      DisplayRecord();
      FldSetScrollPosition(DOC_Field.field, scrollPos - borderLen);
      FldSetInsPtPosition(DOC_Field.field, scrollPos - borderLen);
   }
   return lines;
}
#endif

static void cut_field(void)
{
   UInt scrollPos;
   UInt cut;
   UInt postlen;
   UInt len;
   UInt size;
   Handle txtH;
   VoidPtr textPtr;
   VoidHand textFHand;
   VoidPtr textFPtr;
   FieldAttrType attr;
   Char *p;


   len = FldGetTextLength(DOC_Field.field);
   scrollPos = FldGetScrollPosition(DOC_Field.field);
   //   static char cutstr[4096];
   if (DOC_Field.index < DOC_Values.count) {
      SaveDirtyField();

      if (scrollPos < 210) {
	 cut = 0;
      } else {
	 cut = len - (scrollPos - 210);
      }
      cut = scrollPos;

      loadrec(g_dbR, DOC_Field.index + 1);
      if (DOC_Text.len < 1200) {
	 postlen = DOC_Text.len;
      } else {
	 postlen = 1200;
      }
      size = len - cut + postlen;
      ErrFatalDisplayIf(size >= 4096, " two page size error.");
      textFHand = (VoidHand) FldGetTextHandle(DOC_Field.field);
      textFPtr = MemHandleLock(textFHand);
      txtH = (Handle) MemHandleNew(size + 1);	/* add '\0' size */
      ErrFatalDisplayIf(txtH == 0, "Cannot get new memory.");
      textPtr = MemHandleLock((VoidHand) txtH);

      MemMove(textPtr, textFPtr + cut, len - cut);
      MemMove(textPtr + len - cut, DOC_Text.text, postlen);
      *(char *) (textPtr + size) = '\0';
      //   *(cutstr+size) = '\0';
      //   MemMove(cutstr, "1234567890", 11);
      MemPtrUnlock(textFPtr);
      MemPtrUnlock(textPtr);
      ClearFieldText(DOC_Field.field);
      SetFieldTextFromHandle(DOC_Field.field, txtH);


//      DOC_Field.len = size;
      DOC_Field.borderLen = len - cut;
      p = StrChr(DOC_Text.text, '\n');
      if (p == NULL || (p - DOC_Text.text) > postlen) {
	 DOC_Field.borderLf = SCRLINEMAX;
      } else {
	 DOC_Field.borderLf = p - DOC_Text.text;
      }

      FldSetScrollPosition(DOC_Field.field, scrollPos - cut);
      FldSetInsPtPosition(DOC_Field.field, scrollPos - cut);

      FldGetAttributes(DOC_Field.field, &attr);
      attr.editable = 0;
      //      attr.underlined=grayUnderline;
      attr.underlined = noUnderline;
      FldSetAttributes(DOC_Field.field, &attr);
   }
}



static void fld_scroll(int lines, DirectionType direction)
{
   UInt scrollPos;
   Word textHeight;
   Word fieldHeight;
   UInt len;
   Boolean draw;

   Word scrpos;
   Word inspos;
   draw = false;
   if (lines <= 0) {
      lines = DOC_Field.lines + lines;
   }
   if (lines <= 0) {
      lines = DOC_Field.lines;
   }
   if (g_dbID != 0) {
      if (direction == up) {	/* up */
	 if (lines > DOC_Field.lines) {
	    PrevRecord(false);
	 } else {
	    if (FldScrollable(DOC_Field.field, up)) {
	       FldScrollField(DOC_Field.field, lines, up);
	       if (!FldScrollable(DOC_Field.field, up)) {
		  GoTop();
	       }
	    } else {
	       if (DOC_Field.borderLen > 0) {
		  draw = true;
		  FldEraseField(DOC_Field.field);
		  goInfo.page = DOC_Field.index;
		  DOC_Field.index = 0;
		  goInfo.insPos = DOC_Field.len - DOC_Field.borderLen;
		  goInfo.slen = 0;
		  DisplayRecord();
	       } else {
		  PrevRecord(true);
	       }
	    }
	 }
      } else {			/* down */
	 if (lines > DOC_Field.lines) {
	    NextRecord();
	 } else {
	    if (DOC_Field.borderLen > 0) {
	    } else {
	       if (appPref.join) {
		  FldGetScrollValues(DOC_Field.field,
				     &scrollPos, &textHeight, &fieldHeight);
		  if (textHeight <= scrollPos + lines + fieldHeight) {
		     draw = true;
		     FldEraseField(DOC_Field.field);
		     cut_field();
		  }
	       }
	    }
	    if (lines > 0) {
	       if (FldScrollable(DOC_Field.field, down)) {
		  FldScrollField(DOC_Field.field, lines, down);
		  if (DOC_Field.borderLen > 0) {
		     scrollPos = FldGetScrollPosition(DOC_Field.field);
		     if (scrollPos > DOC_Field.borderLen + DOC_Field.borderLf) {
			UInt borderLen = DOC_Field.borderLen;
			draw = true;
			FldEraseField(DOC_Field.field);
			goInfo.page = DOC_Field.index + 1;
			goInfo.insPos = scrollPos - borderLen;
			goInfo.slen = 0;
			goInfo.scroll = 0;
			DisplayRecord();
			FldSetScrollPosition(DOC_Field.field,
					     scrollPos - borderLen);
			FldSetInsPtPosition(DOC_Field.field,
					    scrollPos - borderLen);
		     }
		  }
		  if (!FldScrollable(DOC_Field.field, down)) {
		     GoBottom();
		  }
	       } else {
		  if (NextRecord() != false) {
		     //                GoTop();
		  }
	       }
	    }
	 }
      }
      scrpos = FldGetScrollPosition(DOC_Field.field);
      inspos = FldGetInsPtPosition(DOC_Field.field);
      if (inspos < scrpos || inspos > scrpos + INSPTOFFMAX) {
	 FldSetInsPtPosition(DOC_Field.field, scrpos);
	 //       FldSetInsertionPoint(DOC_Field.field, scrpos);

      }
      infoPos();
   }
   if (draw) {
      FldDrawField(DOC_Field.field);
      if (DOC_Field.borderLen == 0) {
	 InsPtEnable(true);
      }
   }
}

static void OpenDoc(Word listxtem)
{
   CharPtr listItem;
   Err error;

   CloseDoc();
   if (listxtem < getDocNum()) {

//      FldSetUsable(DOC_Field.field, false);
      FldSetFont(DOC_Field.field, appPref.font);
      DOC_Field.lines = FldGetVisibleLines(DOC_Field.field);
      error = OpenReadDatabase(getDocName(listxtem));
      if (error == 0) {
	 g_curno = listxtem;
	 LstSetSelection(g_list, listxtem);
	 listItem = LstGetSelectionText(g_list, listxtem);
	 StrCopy(triggerLabel, listItem);
	 CategoryTruncateName(triggerLabel, 100);
	 CategorySetTriggerLabel(g_popup, triggerLabel);
      } else {
	 AlertNum("Open Error:", error);
      }
   } else {
      WinDrawChars(" No doc.", 8, 44, 1);
   }
}

static void dspOpenDoc(Word listxtem)
{
   OpenDoc(listxtem);
   goInfo.page = 1;
   goInfo.insPos = 0;
   goInfo.slen = 0;
   goInfo.scroll = 0;
   DisplayRecord();
}

static void MainFormInit(FormPtr form)
{
   g_list =
      (ListPtr) FrmGetObjectPtr(form, FrmGetObjectIndex(form, listID_dblist));
   g_popup =
      (ControlPtr) FrmGetObjectPtr(form,
				   FrmGetObjectIndex(form, listID_popuplist));
   SetListArray(g_curno);

   DOC_Field.field =
      (FieldPtr) FrmGetObjectPtr(form, FrmGetObjectIndex(form, fieldID_zdoc));
   FldDrawField(DOC_Field.field);
   if (goInfo.index != -1) {
      OpenDoc(goInfo.index);
      DisplayRecord();
      goInfo.index = -1;
   }
   if (g_dbID == 0) {
      FrmHideObject(form, FrmGetObjectIndex(form, fieldID_zdoc));
   } else {
      FrmSetFocus(form, FrmGetObjectIndex(form, fieldID_zdoc));
   }

}

static Boolean MainFormHandleEvent(EventPtr event)
{
   Boolean handled = false;
   /*   Handle    garbage;      */
   FormPtr form;
   Word listxtem;


   switch (event->eType) {
    case frmOpenEvent:
      form = FrmGetActiveForm();
      MainFormInit(form);
      FrmDrawForm(form);
      handled = true;
      break;
    case keyDownEvent:
      if (event->data.keyDown.chr == pageUpChr) {	/* Prev */
	 fld_scroll(appPref.scrollH, up);
	 handled = true;
      } else if (event->data.keyDown.chr == pageDownChr) {	/* next */
	 fld_scroll(appPref.scrollH, down);
	 handled = true;
      }
      break;
    case ctlSelectEvent:	// A control button was pressed and released.
      if (event->data.ctlEnter.controlID == buttonID_next) {
	 if (g_dbID == 0) {
	    FrmAlert(alertID_about);
	 } else {
	    fld_scroll(appPref.scrollS, down);
	 }
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == buttonID_open) {
	 if (g_dbID == 0) {
	    listxtem = LstGetSelection(g_list);
	    dspOpenDoc(listxtem);
	 } else {
	    FrmUpdateForm(formID_zdoc, UPDATE_OPEN);
	 }
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == buttonID_up) {
	 fld_scroll(appPref.scrollS, up);
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == buttonID_down) {
	 fld_scroll(appPref.scrollS, down);
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == buttonID_save) {
	 SaveDirtyField();
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == buttonID_find) {
	 FrmPopupForm(formID_find);
	 handled = true;
      } else if (event->data.ctlEnter.controlID == buttonID_again) {
	 if (FindPos() != false) {
	    /* frmUpdateEvent */
	    FrmUpdateForm(formID_zdoc, UPDATE_GOPOS);
	 }
	 handled = true;
      }
      if (event->data.ctlEnter.controlID == listID_popuplist) {
	 // SetListArray(fs_listxtem);
//       handled = true;
      }
      break;
    case menuEvent:
      handled = EditMenuEvent(event);
      if (handled == false) {
	 switch (event->data.menu.itemID) {
	  case menuitemID_about:
	    FrmAlert(alertID_about);
	    handled = true;
	    break;
	  case menuitemID_info:
	    FrmPopupForm(formID_info);
	    handled = true;
	    break;
	  case menuitemID_close:
	    CloseDoc();
	    FrmGotoForm(formID_zdoc);
	    handled = true;
	    break;
	  case menuitemID_new:
	    FrmPopupForm(alertID_new);
	    handled = true;
	    break;
	  case menuitemID_pass:
	    FrmPopupForm(formID_null);
	    handled = true;
	    break;
	  case menuitemID_Find:
	    FrmPopupForm(formID_find);
	    handled = true;
	    break;
	  case menuitemID_Again:
	    if (FindPos() != false) {
	       /* frmUpdateEvent */
	       FrmUpdateForm(formID_zdoc, UPDATE_GOPOS);
	    }
	    handled = true;
	    break;
	  case menuitemID_Save:
	    SaveDirtyField();
	    handled = true;
	    break;
	  case menuitemID_rec:
	    if (g_dbID != 0) {
	       DmOpenRef dbW;
	       dbW = DmOpenDatabase(0, g_dbID, dmModeReadWrite);
	       SetNewRecord();
	       saverec(dbW, true, DOC_Field.index + 1);
	       DmCloseDatabase(dbW);
	       goInfo.page = DOC_Field.index + 1;
	       goInfo.insPos = 0;
	       goInfo.slen = 0;
	       goInfo.scroll = appPref.scrollF;

	       DisplayRecord();
	    }
	    handled = true;
	    break;
#if 0
	  case menuitemID_delete:
	    if (1) {
	       Word listxtem;
	       LocalID dbID;
	       listxtem = LstGetSelection(g_list);
	       CloseDoc();
	       if (listxtem < getDocNum() && getDocNum() > 0) {
		  dbID = DmFindDatabase(0, getDocName(listxtem));
		  DmDeleteDatabase(0, dbID);
		  //                 FrmUpdateForm(formID_zdoc, UPDATE_NAME);
		  FrmGotoForm(formID_zdoc);
	       }
	    }
	    break;
#endif
	  case menuitemID_delrec:
	    delrec();
	    handled = true;
	    break;
	  case menuitemID_Bottom:	/* down */
	    if (GoBottom() == false) {
	       if (DOC_Field.index < DOC_Values.count) {
		  goInfo.page = DOC_Values.count;
		  goInfo.insPos = 9999;
		  goInfo.slen = 0;
		  goInfo.scroll = -1;

		  DisplayRecord();
//                GoBottom();
	       }
	    }
	    handled = true;
	    break;
	  case menuitemID_Top:
	    if (GoTop() == false) {
	       goInfo.page = 1;
	       goInfo.insPos = 0;
	       goInfo.slen = 0;
	       goInfo.scroll = 0;
	       DisplayRecord();
	    }
	    handled = true;
	    break;
	  case menuitemID_next:
	    NextRecord();
	    handled = true;
	    break;
	  case menuitemID_prev:
	    PrevRecord(false);
	    handled = true;
	    break;
	  case menuitemID_Reload:
	    ReField(DOC_Field.index);
	    handled = true;
	    break;
	  default:
	    ;
	 }
      }
      break;
    case frmUpdateEvent:
      /* event->data.frmUpdate.updateCode     */
      if (event->data.frmUpdate.updateCode == UPDATE_GOPOS) {
	 DisplayRecord();
	 handled = true;
      } else if (event->data.frmUpdate.updateCode == UPDATE_NAME) {
	 SetListArray(g_curno);
	 handled = true;
      } else if (event->data.frmUpdate.updateCode == UPDATE_OPEN) {
	 Word pos;
	 pos = getDocPos(appPref.name);
	 if (pos != -1) {
	    goInfo.page = appPref.go_page;
	    goInfo.insPos = appPref.go_pos;
	    goInfo.slen = 0;
	    goInfo.scroll = 0;
	    OpenDoc(pos);
	    DisplayRecord();
	 }
	 handled = true;
      }
      break;
    case popSelectEvent:
//      FrmCustomAlert(alertInfo, "popSelect", "dspStr", " ");
      if (event->data.popSelect.controlID == listID_popuplist) {
	 if (event->data.popSelect.selection != g_curno) {
	    dspOpenDoc(event->data.popSelect.selection);
	 }
      }
      break;

    case nilEvent:
      {
	 if (g_dbID != 0) {
	    void *control;
	    control = GetObjectPtr(buttonID_save);
	    if (FldDirty(DOC_Field.field)) {
	       CtlShowControl(control);
	    } else {
	       CtlHideControl(control);
	    }
	    infoPos();
	 };
	 handled = true;
	 break;
      }
    default:
#if 0
      if (ctlExitEvent < event->eType) {
	 StrPrintF(dspStr, "Event:%d ", event->eType);
	 FrmCustomAlert(alertInfo, "evnet ", dspStr, " ");
      }
#endif
      ;
   }
   return handled;
}
