#define KEYLEN 8
#define BUFSIZE 6000
#define MAXTEXTSIZE 4096




typedef struct
{
   int version;			// 2    1:plain, 2:compressed, 3:ext
   int reserved1;		// 2
   long doc_size;		// 4   in bytes, when uncompressed
   int count;			// 2   numRecords-1
   int rec_size;		// 2    /* usually MAXTEXTSIZE */
   long reserved2;		// 4
} DOCInfoType;			//         16 bytes

/* read  db->raw, raw->field | raw->cook->field */
/* write field->raw, raw->db | raw->cook->db */
typedef struct
{				/* DOC Record in inside */
   Char raw[MAXTEXTSIZE + 1];	/* Raw Text, compress */
   Char cook[BUFSIZE];		/* compress/uncompress Text */
   UInt rawLen;			/* rawLen */
   UInt len;			/* cooked len */
   UInt orgLen;			/* original len, uncompress */
   CharPtr text;		/* uncompress/compress text ptr */
   UInt index;			/* read rec no */
}
DOCTxtType;

#ifndef	MAIN
DOCInfoType DOC_Values;
DOCTxtType DOC_Text;
int key[KEYLEN + 1];
#else
DOCInfoType DOC_Values = { 0, 0, 0, 0, 0, 0 };
DOCTxtType DOC_Text;
int key[KEYLEN + 1] = { 0, 0, 0, 0, 0, 0, 0, 0, 0 };
#endif

void loadrec(DmOpenRef dbR, UInt index);
void saverec(DmOpenRef dbRef, Boolean new, UInt index);
void WriteValues(DmOpenRef dbRef, Boolean new);
