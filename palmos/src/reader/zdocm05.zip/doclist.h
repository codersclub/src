#define alertInfo  3801

void freeDoclist(void);
UInt getDocNum(void);
char *getDocName(Word num);
Word getDocPos(CharPtr name);
char **getDoclist(Boolean newlist);
