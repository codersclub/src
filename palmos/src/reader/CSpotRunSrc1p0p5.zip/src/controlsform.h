Boolean ControlsFormHandleEvent(EventType *e);
