Boolean SearchFormHandleEvent(EventType *e);
