Boolean PrefsFormHandleEvent(EventType *e);
