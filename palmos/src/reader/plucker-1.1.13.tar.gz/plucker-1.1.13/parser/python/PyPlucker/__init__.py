# Generated automatically from __init__.py.in by configure.
#
# $Id: __init__.py.in,v 1.2 2001/01/14 12:57:27 nordstrom Exp $
#

version = "@@VERSION@@"

lib_dir = "/usr/local/etc"

import sys
if sys.platform == 'win32' or sys.platform == 'os2':
    _SYS_CONFIGFILE_NAME = "plucker.ini"
    _USER_CONFIGFILE_NAME = "plucker.ini"
else:
    _SYS_CONFIGFILE_NAME = "pluckerrc"
    _USER_CONFIGFILE_NAME = ".pluckerrc"
    


# try to find the gettext package...
try:
    from PyPlucker.helper import gettext
except ImportError:
    try:
        from Pyrite import gettext
    except ImportError:
        try:
	    import gettext
        except ImportError:
            # We give up...
            gettext = None
if gettext is None:
    def _(text):
        return text
else:
    gettext.bindtextdomain('pyplucker', "/usr/local/share/locale")
    gettext.textdomain('pyplucker')
    _ = gettext.gettext

