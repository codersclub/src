/*
 * $Id: image.h,v 1.15 2001/07/18 20:01:36 nordstrom Exp $
 *
 * Viewer - a part of Plucker, the free off-line HTML viewer for PalmOS
 * Copyright (c) 1998-2001, Mark Ian Lillywhite and Michael Nordstr�m
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifndef __PLUCKER_IMAGE_H
#define __PLUCKER_IMAGE_H

#include "viewer.h"
#include "document.h"
#include "util.h"


void GetImageMetrics( const Int16 reference, Int16* width, Int16* height );
void DrawInlineImage( const Int16 reference, const TextContext* tContext,
        Int16* width );
void ShowImagesOn( Int16 reference );
void ShowImagesOff( Int16 reference );
void ResetImageData( void );
void DoImageMove( Int16 x, Int16 y );
void DeleteOffScreenWindow( void );
Boolean ShowImages( Int16 reference );
Boolean ShowNoImages( void );
Boolean NotSupportedImageCompression( BitmapType* imagePtr );
Boolean ViewTbmp( Header* record, const Boolean newPage );
Boolean LargeImage( void );

#endif
