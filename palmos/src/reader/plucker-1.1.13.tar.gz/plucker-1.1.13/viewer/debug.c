/*
 * $Id: debug.c,v 1.17 2001/09/16 15:07:38 nordstrom Exp $
 *
 * Viewer - a part of Plucker, the free off-line HTML viewer for PalmOS
 * Copyright (c) 1998-2001, Mark Ian Lillywhite and Michael Nordstr�m
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

#ifdef DEBUG

#include "debug.h"
#include <SerialMgrOld.h>
#include <unix_stdarg.h>


/***********************************************************************
 *
 *      Internal Constants
 *
 ***********************************************************************/
#define MAX_MSG_LEN     256
#define SERIAL_PORT     0
#define SERIAL_SPEED    38400
#define COUNT_TICKS     true



/* Create formatted debug message */
Char *_
    (
    Char* fmt,  /* format, see printf( 3 ) for details */
    ...         /* arguments */
    )
{
    static Char   msg[ MAX_MSG_LEN ];
    va_list       args;

    va_start( args, fmt );
    StrVPrintF( msg, fmt, args );
    va_end( args );

    return msg;
}



/* Send debug messages through the serial port */
void _DebugMsg
    (
    Char* fname,    /* file name */
    Int16 line,     /* line number */
    Char* title,    /* title */
    Char* function, /* function name */
    Char* msg       /* text message */
    )
{
    static Boolean  printFileLineTitle      = true;
    static UInt16   libraryId               = 0;
    static Char     logBuf[ MAX_MSG_LEN ];
    static Char     logMsg[ MAX_MSG_LEN ];

    Char*   s;
    Err     err;

    if ( libraryId == 0 )
        SysLibFind( "Serial Library", &libraryId );

    err = SerOpen( libraryId, SERIAL_PORT, SERIAL_SPEED );
    if ( err != errNone ) {
        if ( err == serErrAlreadyOpen ) {
            SerClose( libraryId );
            return;
        }
        else
            return;
    }
    if ( printFileLineTitle ) {
        StrPrintF( logBuf, "[ %s ] %s:%d:", title, fname, line );
        StrPrintF( logMsg, "%-25s", logBuf );
        SerSend( libraryId, logMsg, ( Int32 ) StrLen( logMsg ), &err );
        printFileLineTitle = false;
    }
    if ( COUNT_TICKS ) {
        StrPrintF( logMsg, " [ ticks: %ld ] ", TimGetTicks() );
        SerSend( libraryId, logMsg, ( Int32 ) StrLen( logMsg ), &err );
    }
    StrPrintF( logMsg, "%s: %s", function, msg );
    SerSend( libraryId, logMsg, ( Int32 ) StrLen( logMsg ), &err );
    SerSendWait( libraryId, -1 );
    SerClose( libraryId );

    s = msg;
    if ( *s != '\0' ) {
        while ( *s != '\0' ) {
            ++s;
        }
        printFileLineTitle = ( s[ -1 ] == '\n' );
    }
}

#endif
