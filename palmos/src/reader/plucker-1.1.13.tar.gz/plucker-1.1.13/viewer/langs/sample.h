//
// $Id: sample.h,v 1.15 2001/09/17 01:25:21 heiserd Exp $
//

// Width of pop-up list for control (tap) actions
#define CONTROL_ACTION 70

// Width of pop-up list for scrollbar location
#define PREF_SCROLLBAR 30

// Length of field for search pattern
#define SEARCH_FIELD_LENGTH 105

// Width of pop-up list for find in page or all pages
#define SEARCH_POPUP_WIDTH 60       /* MAX 60 */

// Width of pop-up list for image dialog
#define IMAGE_DIALOG 60

// Width of pop-up list for Document Library dialog
#define LIBRARY_POPUP_WIDTH 50

// Width of the Categories Button in Document Library dialog
#define LIBRARY_CATEGORIES_WIDTH 52

// Left position of the DATE button in the Document Library dialog
#define LIBRARY_FILTER_POS 136

// Width of the pop-up list of sort options in the Document Library dialog
#define LIBRARY_SORT_WIDTH 30

// Left position of the Help icon in the Document Library dialog
#define LIBRARY_HELP_ICON_POS 67

// Left position of the AND button in the categories dialog
#define CATEGORIES_AND_POS 134

// Width of the None Button in Categories dialog
#define CATEGORIES_NONE_WIDTH 27

// Width of pop-up list for categories dialog
#define CATEGORIES_POPUP_WIDTH 40

// Width of pop-up list for font selector
#define PREF_FONT 70

// Width of pop-up list for command toolbar button selector
#define PREF_CMD_BUTTON 70

// Width of pop-up list for hardkey/gestures actions dialog
#define BUTTON_ACTION 87

// Width of pop-up list for autoscroll mode selector
#define PREF_AUTOSCROLLMODE 36

// Width of pop-up list for autoscroll direction selector
#define PREF_AUTOSCROLLDIR 34

// Width of pop-up list for jump to percent of document selector
#define PREF_MAIN_PERCENT_WIDTH 38
