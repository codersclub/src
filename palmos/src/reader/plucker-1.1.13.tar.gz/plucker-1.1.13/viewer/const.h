/*
 * $Id: const.h,v 1.25 2001/07/18 20:01:35 nordstrom Exp $
 *
 * Viewer - a part of Plucker, the free off-line HTML viewer for PalmOS
 * Copyright (c) 1998-2001, Mark Ian Lillywhite and Michael Nordstr�m
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 */

/* Length (in pixels) to scroll for one page  */
#define SCROLL_ONE_PAGE             145

/* Default spacing between paragraphs */
#define DEFAULT_PARAGRAPH_SPACING   2

/* Default size of horizontal rules */
#define DEFAULT_HRULE_SIZE          2

/* Max length of search pattern */
#define MAX_PATTERN_LEN             15

/* Document version */
#define ViewerDocumentVersion       9

/* Meta Document version */
#define MetaDocumentVersion         2

/* Creator ID */
#define ViewerAppID                 'Plkr'

/* Type for Plucker documents */
#define ViewerDocumentType          'Data'

/* Type for meta documents */
#define MetaDocumentType            'Meta'

/* Type for Uncompress buffer */
#define UncompressType              'Ucmp'

/* Type for document list */
#define PlkrDocListType             'List'
