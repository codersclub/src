#!/usr/bin/env python

"""
pluck-comics.py  $Id: pluck-comics.py.in,v 1.2 2001/01/16 00:04:44 heiserd Exp $

Gathers comics from selected websites for Plucker

Copyright (C) 2001, Christopher R. Hawks <chrish@syscon-intl.com>

Distributable under the GNU General Public License Version 2 or newer.
"""

import sys
import os
import re
import urllib
import getopt
import time
import string


get_all = 0
make_home = 0
show_icons = 0
remove_all = 0
verbose = 0

# Where to put the comics
location = '/var/spool/netcomics'
# Where libraries are stored
libdir = '/usr/local/share/plucker/comics'

# URL shortening utility
def shorten_url(line, length = 30):
	sline = line
	while len(sline) > length:
		parts = string.split(sline, '/')
		if len(parts) < 5:
			return sline
		if parts.count('...'):
			parts.remove('...')
		parts[-2:-1] = ['...']
#		parts[(len(parts) / 3) * 2] = '...'
		sline = string.join(parts, '/')
	return sline

# Comic dictionaries example 
#comic_list.append({
#	'name': 'name of comic for filename and selection',
#	'page': 'URL of the comic page',
#	'expr': "regex for the picture name",
#	'suff': 'suffix of image (.gif, .jpg, .etc)',
#	'base': 'URL where the pictures are stored _or_ cgi script (see popeye)',
#	'refr': 'URL of referring page (some King Features comics need this'})

comic_list = []
for name in os.listdir(libdir):
	if name[-5:] == '.list':
		execfile(os.path.join(libdir,name))

now = time.localtime(time.time())
today = time.strftime("%Y%m%d", now)

(opts, args) = getopt.getopt(sys.argv[1:], "adhil:v")
for (opt, arg) in opts:
	if opt == "-a":
		get_all = 1
	if opt == "-d":
		remove_all = 1
	if opt == "-h":
		make_home = 1
	if opt == "-i":
		show_icons = 1
	if opt == "-l":
		location = arg
	if opt == "-v":
		verbose = 1

if remove_all:
	for name in os.listdir(location):
		os.remove(os.path.join(location,name))

if not args and not get_all and not make_home:
	print "Usage: comics.py [-a] [-d] [-h] [-l location] comic [comic] ..."
	print "\t-a collect All know comics"
	print "\t-d Delete _all_ files in \'location\' (%s) first" % location
	print "\t-h create a Home page (%s)" % os.path.join(location, 'index.html')
	print "\t-i put Icons on home page"
	print "\t-l is the Location to store the comics"
	print "\tAvailable comics are:"
	for list_me in comic_list:
		print '\t' + list_me['name']

for get_me in comic_list:
	if get_all or get_me['name'] in args:
		try:
			if verbose:
				print "Fetching Page  %s" % shorten_url(get_me['page'], 60)
			conn = urllib.urlopen(get_me['page'])
			page = conn.read()
			conn.close()

			name = re.search(get_me['expr'], page)
			if name is not None:
				if verbose:
					print "Fetching Comic %s" \
							% shorten_url(get_me['base'] + name.group(), 60)
				path = urllib.URLopener()
				if get_me.has_key('refr'):
					path.addheader('Referer', get_me['refr'])
				conn = path.open(get_me['base'] + name.group())
				comic = conn.read()
				conn.close()
				title = get_me['name'] + today
				output = open(os.path.join(location,title + get_me['suff']), 'wb')
				output.write(comic)
				output.close()
		except:
			if verbose:
				print "Comic %s failed!" % get_me['name']
			pass

if make_home:
	if verbose:
		print "Creating Home Page %s" % os.path.join(location, 'index.html')
	home = open(os.path.join(location, 'index.html'), 'w')
	home.write("<TITLE>Cartoons</TITLE>\n")
	home.write("<P>Comics from the Web.</P>\n")
	home.write("<P>\n")

	for name in os.listdir(location):
		if name != 'index.html':
			if show_icons:
				line = "%s<BR><IMG SRC=\"%s\"><P>\n" % (name, name)
			else:
				line = "<A HREF=\"%s\">%s</A><P>\n" % (name, name)
			home.write(line)

	home.close()
