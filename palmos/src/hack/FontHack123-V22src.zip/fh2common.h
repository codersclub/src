#define CRID 'sfh2'
#define DBNAME "AppFontData2"
#define DBTYPE 'ADAT'
#define MAXFONTS 8

typedef struct tagFontEntry{
	UInt16 cardNo;
	LocalID dbID;
	UInt16 index;
}FontEntry;

typedef struct tagAppData{
	UInt16 cardNo;
	LocalID dbID;
	FontEntry fonts[MAXFONTS];
}AppData;

