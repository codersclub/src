// Requirements:
// "All Apps" settings to work
// work upon reset
// comply to HackMaster hack protocol (form has no global data)
// check if font before offering as a choice
// be PalmOS version independent

#pragma     pack(2)
#include <PalmOS.h>
#include <System/DataMgr.h>
#include <System/MemoryMgr.h>
#include 	"fh2.h"
#include	"fh2common.h"

static int StartApplication(void);
static void EventLoop(void);
static void StopApplication(void);
static Boolean frmMainEH(EventPtr event);

Boolean DWord2A(UInt32 num,char *out);
MemPtr GetMem(MemPtr oldptr,UInt32 size);

typedef struct tagGlobalData{
	AppData *appData;
	FontEntry *fontData;
	char **fontList;
	char **appList;
	UInt16 fontCount, appCount, appCurrent;
}GlobalData;

void CreateAppList(GlobalData *gd);
void SaveAppList(GlobalData *gd);
void CreateFontList(GlobalData *gd);
void ReleaseFontList(GlobalData *gd);
void SetLists(GlobalData *gd,FormPtr form);
void UpdateTriggers(GlobalData *gd,FormPtr form);

GlobalData *CreateGD();
GlobalData *GetGD();
void *ReleaseGD(GlobalData* gd);

__asm("bra frmMainEH");

GlobalData *CreateGD()
{
	GlobalData *gd=GetMem(NULL,sizeof(GlobalData));
	MemSet((MemPtr)gd,sizeof(GlobalData),0);
	FtrSet(CRID,ftrGlobalData,(UInt32)gd);
	return gd;
}

GlobalData *GetGD()
{
	GlobalData *gd;
	if(FtrGet(CRID,ftrGlobalData,(UInt32 *)&gd)!=0)
		ErrFatalDisplay("Not enough memory");
	return gd;
}

void *ReleaseGD(GlobalData* gd)
{
	MemPtrFree(gd); // would complain by itself, no need to help =-))
	FtrUnregister(CRID,ftrGlobalData);
}

void CreateAppList(GlobalData *gd)
{
DmOpenRef dbref;
MemHandle vh;
AppData *oldAppData=NULL;
UInt16 oldAppCount=0;
//
DmSearchStateType dmss;
Err result;
UInt16 cardNo,i;
LocalID dbID;
char name[dmDBNameLength+1];
UInt16 *uiptr;
	dbref=DmOpenDatabaseByTypeCreator(DBTYPE,CRID,dmModeReadOnly);
	if(dbref){
		if(vh=DmQueryRecord(dbref,0)){
			uiptr=(UInt16 *)MemHandleLock(vh);
			if(uiptr){
				oldAppCount=*uiptr;
				oldAppData=(AppData*)&(uiptr[1]);
			}
		}
		DmCloseDatabase(dbref);
	}

	gd->appData=GetMem(NULL,sizeof(AppData));
	MemSet((MemPtr)&(gd->appData[0]),sizeof(AppData),0);
	if(oldAppData)
		MemMove((MemPtr)&(gd->appData[0]),(MemPtr)&(oldAppData[0]),sizeof(AppData));

	gd->appList=GetMem(NULL,sizeof(char*));
	gd->appList[0]=GetMem(NULL,StrLen("All apps")+1);
	StrCopy(gd->appList[0],"All apps");
	gd->appCount=1;

	
	for(result=DmGetNextDatabaseByTypeCreator(true,&dmss,'appl',0,false,&cardNo,&dbID);
		result==0;
		result=DmGetNextDatabaseByTypeCreator(false,&dmss,'appl',0,false,&cardNo,&dbID)){

		gd->appList=GetMem(gd->appList,sizeof(char*)*(gd->appCount+1));
		DmDatabaseInfo(cardNo,dbID,name,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
		gd->appList[gd->appCount]=GetMem(NULL,StrLen(name)+1);
		StrCopy(gd->appList[gd->appCount],name);

		gd->appData=GetMem(gd->appData,sizeof(AppData)*(gd->appCount+1));
		MemSet((MemPtr)&(gd->appData[gd->appCount]),sizeof(AppData),0);
		for(i=0;i<oldAppCount;i++){
			if((oldAppData[i].cardNo==cardNo) && (oldAppData[i].dbID==dbID)){
				MemMove((MemPtr)&(gd->appData[gd->appCount]),(MemPtr)&(oldAppData[i]),sizeof(AppData));
				break;
			}
		}
		gd->appData[gd->appCount].cardNo=cardNo;
		gd->appData[gd->appCount].dbID=dbID;
		gd->appCount++;
	}
	
	if(oldAppData)
		MemHandleUnlock(vh);
}

void SaveAppList(GlobalData *gd)
{
UInt16 i;
LocalID dbID;
DmOpenRef dbref;
MemHandle vh;
MemPtr ptr;
Boolean success=false;
	if(gd->appList!=NULL){
		for(i=0;i<gd->appCount;i++){
			MemPtrFree(gd->appList[i]);
		}
		MemPtrFree(gd->appList);
		gd->appList=NULL;
	}
	if(gd->appData!=NULL){
		if(dbID=DmFindDatabase(0,DBNAME)){
			DmDeleteDatabase(0,dbID);
		}
		DmCreateDatabase(0,DBNAME,CRID,DBTYPE,false);
		dbref=DmOpenDatabaseByTypeCreator(DBTYPE,CRID,dmModeWrite);
		if(dbref){
			i=0;
			vh=DmNewRecord(dbref,&i,sizeof(AppData)*gd->appCount+sizeof(UInt16));
			if(vh){
				ptr=MemHandleLock(vh);
				if(ptr){
					if(DmWrite(ptr,0,&(gd->appCount),sizeof(UInt16))==0 
						&& DmWrite(ptr,sizeof(UInt16),gd->appData,sizeof(AppData)*(gd->appCount))==0){
						success=true;
					}
					MemHandleUnlock(vh);
				}
				DmReleaseRecord(dbref,i,true);
			}
			DmCloseDatabase(dbref);
		}
		MemPtrFree(gd->appData);
		gd->appData=NULL;
	}
	gd->appCount=0;
	if(!success){
		FrmAlert(frmCouldNotSave);
	}
}

void CreateFontList(GlobalData *gd)
{
DmSearchStateType dmss;
Err result;
UInt16 cardNo,i,dbattr;
UInt32 numRec;
LocalID dbID;
char name[dmDBNameLength+1];
char buf1[50+dmDBNameLength+1],buf[10];
UInt16 *wchunk;
DmOpenRef dbref;
MemHandle vh;

	gd->fontData=GetMem(NULL,sizeof(FontEntry));
	MemSet((MemPtr)&(gd->fontData[0]),sizeof(FontEntry),0);
	gd->fontList=GetMem(NULL,sizeof(char*));
	gd->fontList[0]=GetMem(NULL,StrLen("none")+1);
	StrCopy(gd->fontList[0],"none");
	gd->fontCount=1;

	for(result=DmGetNextDatabaseByTypeCreator(true,&dmss,'Font',0,false,&cardNo,&dbID);
			result==0;
		result=DmGetNextDatabaseByTypeCreator(false,&dmss,'Font',0,false,&cardNo,&dbID)){

		DmDatabaseInfo(cardNo,dbID,name,&dbattr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
		if(dbattr&dmHdrAttrResDB)
			continue;
		dbref=DmOpenDatabase(cardNo,dbID,dmModeReadOnly);
		numRec=0;
		DmDatabaseSize(cardNo,dbID,&numRec,NULL,NULL);
		for(i=0;i<numRec;i++){
			vh=DmQueryRecord(dbref,i);
			if(!vh)continue;
			wchunk=MemHandleLock(vh);
			if(*wchunk==0x9000){
				StrCopy(buf1,name);
				StrIToA(buf,i);
				StrCat(buf1," ");
				StrCat(buf1,buf);
				StrIToA(buf,wchunk[7]);
				StrCat(buf1," h");
				StrCat(buf1,buf);
				StrIToA(buf,wchunk[6]);
				StrCat(buf1," w");
				StrCat(buf1,buf);
				
				gd->fontList=GetMem(gd->fontList,sizeof(char*)*(gd->fontCount+1));
				gd->fontList[gd->fontCount]=GetMem(NULL,StrLen(buf1)+1);
				StrCopy(gd->fontList[gd->fontCount],buf1);
				
				gd->fontData=GetMem(gd->fontData,sizeof(FontEntry)*(gd->fontCount+1));
				gd->fontData[gd->fontCount].cardNo=cardNo;
				gd->fontData[gd->fontCount].dbID=dbID;
				gd->fontData[gd->fontCount].index=i;
				
				gd->fontCount++;
			}
			MemHandleUnlock(vh);
		}
		DmCloseDatabase(dbref);
	}
}

void ReleaseFontList(GlobalData *gd)
{
UInt16 i;
	if(gd->fontList!=NULL){
		for(i=0;i<gd->fontCount;i++)
			MemPtrFree(gd->fontList[i]);
		MemPtrFree(gd->fontList);
		gd->fontList=NULL;
	}
	if(gd->fontData!=NULL){
		MemPtrFree(gd->fontData);
		gd->fontData=NULL;
	}
	gd->fontCount=0;
}

void SetLists(GlobalData *gd, FormPtr form)
{
UInt16 i;
	if(gd->appList!=NULL)
		LstSetListChoices(FrmGetObjectPtr(form,FrmGetObjectIndex(form,liApplication)),gd->appList,gd->appCount);
	if(gd->fontList!=NULL)
		for(i=0;i<MAXFONTS;i++)
			LstSetListChoices(FrmGetObjectPtr(form,FrmGetObjectIndex(form,liStandard+i)),gd->fontList,gd->fontCount);
	UpdateTriggers(gd,form);
}

void UpdateTriggers(GlobalData *gd, FormPtr form)
{
UInt16 i,j,index;
	if(gd->appData==NULL || gd->fontData==NULL || gd->fontList==NULL) return;
	for(i=0;i<MAXFONTS;i++){
		index=0;
		if(gd->appData[gd->appCurrent].fonts[i].dbID!=0){
			for(j=0;j<gd->fontCount;j++){
				if(gd->appData[gd->appCurrent].fonts[i].dbID==gd->fontData[j].dbID 
					&& gd->appData[gd->appCurrent].fonts[i].cardNo==gd->fontData[j].cardNo 
					&& gd->appData[gd->appCurrent].fonts[i].index==gd->fontData[j].index)
					index=j;
			}
		}
		LstSetSelection(FrmGetObjectPtr(form,FrmGetObjectIndex(form,liStandard+i)),index);
		CtlSetLabel(FrmGetObjectPtr(form,FrmGetObjectIndex(form,pStandard+i)),gd->fontList[index]);
	}
}

void ResetAppData(GlobalData *gd)
{
UInt16 i,j;
FormPtr form;
	if(gd->appData==NULL) return;
	if(FrmAlert(frmConfirmReset)!=0) return;
	for(i=0;i<gd->appCount;i++){
		for(j=0;j<MAXFONTS;j++){
			gd->appData[i].fonts[j].dbID=0;
			gd->appData[i].fonts[j].cardNo=0;
			gd->appData[i].fonts[j].index=0;
		}
	}
	form=FrmGetActiveForm();
	if(form)
		UpdateTriggers(gd,form);
}

Boolean DWord2A(UInt32 num,char *out)
{
UInt16 rem,i,max;
UInt32 n;
	n=num;
	if(n==0){out[0]='0';out[1]=0;return true;}
	for(i=0;n!=0;n=n/10,i++)
	max=i;
	out[max+1]=0;
	n=num;
	for(i=0;n!=0;n=n/10,i++){
		rem=n%10;
		out[max-i]=rem+'0';
	}
	return true;
}

static Boolean frmMainEH(EventPtr event)
{
	FormPtr   form;
	int       handled = 0;
	GlobalData *gd;
	UInt32 version;

	switch (event->eType)
	{
		case frmOpenEvent:
			form = FrmGetActiveForm();
			version=0;
			FtrGet(sysFtrCreator,sysFtrNumROMVersion,&version);
			if(version<0x03000000l)
				FrmHideObject(form,FrmGetObjectIndex(form,pLargeBold));
			if((version&0x0FF00000l) > 0x03500000l){
				FrmAlert(frmUnknownOS);
				FrmGotoForm(9000);
				return true;
			}
			gd=CreateGD();
			gd->appCurrent=0;
			CreateAppList(gd);
			CreateFontList(gd);
			SetLists(gd,form);
			FrmDrawForm(form);
//			FrmDoDialog(FrmInitForm(frmAbout));
			handled = 1;
		break;
		case ctlSelectEvent:  // A control button was pressed and released.
			switch (event->data.ctlEnter.controlID){
			case bReset:
				gd=GetGD();
				ResetAppData(gd);
				handled = 1;
				break;
			case bSave:
				gd=GetGD();
				SaveAppList(gd);
				ReleaseFontList(gd);
				ReleaseGD(gd);
				FrmAlert(frmFontSizeWarning);
				FrmGotoForm(9000);
				handled = 1;
				break;
			}
		break;
		case popSelectEvent:
			gd=GetGD();
			if(event->data.popSelect.listID==liApplication){
				form = FrmGetActiveForm();
				gd->appCurrent=event->data.popSelect.selection;
				UpdateTriggers(gd,form);
			}else{
				if(gd->appData!=NULL && gd->fontData!=NULL)
					MemMove((MemPtr)&(gd->appData[gd->appCurrent].fonts[event->data.popSelect.listID-liStandard]),
						(MemPtr)&(gd->fontData[event->data.popSelect.selection]),sizeof(FontEntry));
			}
		break;
		case nilEvent:
			handled = 1;
		break;
	}
	return handled;
}

MemPtr GetMem(MemPtr oldptr,UInt32 size)
{
MemPtr ptr;
	ptr=MemPtrNew(size);
	if(ptr!=NULL){
		if(oldptr!=NULL){
			MemMove(ptr,oldptr,MemPtrSize(oldptr));
			MemPtrFree(oldptr);
		}
		return ptr;
	}
	ErrFatalDisplay("Not enough memory");
	return NULL; // ??? Reset
}
