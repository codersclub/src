#pragma pack(2)
#include <PalmOS.h>
#include <System/DataMgr.h>
#include <System/MemoryMgr.h>
#include <System/SystemMgr.h>
#include "fh2.h"
#include "fh2common.h"

typedef struct appFontInfoTag{
	char appName[dmDBNameLength];
	MemHandle fontHand[8];
} appFontInfo;

Boolean SetStandardFont(UInt16 index);
Boolean SetCustomFont(UInt16 index, MemPtr ptr);
void SetResetLockFont(UInt16 index, FontEntry *rec);
Boolean IsHackMaster(UInt16 cardNo, LocalID dbID);
Err MySysAppStartup(SysAppInfoPtr* appInfoPP, MemPtr* prevGlobalsP, MemPtr* globalsPtrP);

__asm("bra MySysAppStartup"); // to skip constants definitions in text segment

Err MySysAppStartup(SysAppInfoPtr* appInfoPP, MemPtr* prevGlobalsP, MemPtr* globalsPtrP)
{
Err (*oldtrap) (SysAppInfoPtr* appInfoPP, MemPtr* prevGlobalsP, MemPtr* globalsPtrP);
Err retval;
UInt32 version;
MemHandle vh;
UInt16 i,numFonts,j;
UInt16 *uiptr;
//
DmOpenRef dbref;
AppData *appData=NULL;
UInt16 appCount=0;
//
LocalID dbID=0;
UInt16 cardNo=0;
FontEntry *rec;
Boolean HackMaster;

	// get oldtrap, check if normal launch, otherwise exit
	FtrGet(CRID,ftrTrapStart,(UInt32*)&oldtrap);
	retval=(*oldtrap)(appInfoPP,prevGlobalsP,globalsPtrP);
	if((*appInfoPP)->cmd!=sysAppLaunchCmdNormalLaunch)
		return retval;
	// if < PalmOS 3.0, disable BigBold font setting
	FtrGet(sysFtrCreator,sysFtrNumROMVersion,&version);
	numFonts=(version<0x03000000l)?7:8;
	// throw towel if OS > 3.5
	if((version&0x0FF00000l) > 0x03500000l)
		return retval;
	// unlock previous fonts, if any
	for(i=0;i<numFonts;i++){
		if(FtrGet(CRID,ftrLockedFonts+i,(UInt32 *)&vh)==0){
			MemHandleUnlock(vh);
			FtrUnregister(CRID,ftrLockedFonts+i);
		}	
	}
	// get current dbid
	SysCurAppDatabase(&cardNo, &dbID); // if unable to get, it would take "all"
	// check if HackMaster or EVPlugBase
	HackMaster=IsHackMaster(cardNo, dbID);
	// load appinfo
	dbref=DmOpenDatabaseByTypeCreator(DBTYPE,CRID,dmModeReadOnly);
	if(dbref){
		if(vh=DmQueryRecord(dbref,0)){
			uiptr=(UInt16 *)MemHandleLock(vh);
			if(uiptr){
				appCount=*uiptr;
				appData=(AppData*)&(uiptr[1]);
			}
		}
		DmCloseDatabase(dbref);
	}
	if(appData==NULL) return retval;
	// check for specific data
	for(j=0;j<numFonts;j++){
		rec=NULL;
		for(i=0;i<appCount;i++){
			if(appData[i].dbID==dbID && appData[i].cardNo==cardNo){
				rec=&(appData[i].fonts[j]);
				break;
			}
		}
		// combine with "all" data
		if((rec==NULL || rec->dbID==0) && appData[0].fonts[j].dbID!=0)
			rec=&(appData[0].fonts[j]);

		// if HackMaster - set standard fonts everywhere
		if(HackMaster) rec=NULL;
		// lock, set fonts, save them into ftrs		
		SetResetLockFont(j,rec);
	}
	MemHandleUnlock(vh);
	return retval;
}

Boolean IsHackMaster(UInt16 cardNo, LocalID dbID)
{
UInt32 crid=0;
char name[dmDBNameLength+1];
	DmDatabaseInfo(cardNo, dbID, name,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,&crid);
	if((crid=='dwHM' && StrCompare(name,"HackMaster")==0)
		||(crid=='evPB' && StrCompare(name,"EVPlugBase")==0))
	return true;
	return false;
}

void SetResetLockFont(UInt16 index, FontEntry *rec)
{
DmOpenRef dbref=0;
MemHandle vh;
MemPtr ptr;
	if(rec==NULL 
		|| rec->dbID==0 
		|| (dbref=DmOpenDatabase(rec->cardNo,rec->dbID,dmModeReadOnly))==NULL
		|| (vh=DmQueryRecord(dbref,rec->index))==NULL
		|| (ptr=MemHandleLock(vh))==NULL ){
		SetStandardFont(index);
	}else{
		SetCustomFont(index,ptr);
		FtrSet(CRID,ftrLockedFonts+index,(UInt32)vh);
	}
	if(dbref)
		DmCloseDatabase(dbref);
}

Boolean SetStandardFont(UInt16 index)
{
MemHandle fh;
MemPtr ptr;
	// this works everywhere up to OS 3.5
	// BUT DON"T TRY THAT AT HOME
	// THIS IS HACK, FOR ITSSAKE!
	if(fh=DmGetResource('NFNT',0x2328+index)){
		ptr=MemHandleLock(fh); // this is just paranoid dancing, because being in ROM fh==ptr
		SetCustomFont(index,ptr);
		MemHandleUnlock(fh); // same here
		DmReleaseResource(fh);
	}
	return true;
}

Boolean SetCustomFont(UInt16 index, MemPtr ptr)
{
UInt32 version;
	FtrGet(sysFtrCreator,sysFtrNumROMVersion,&version);
	// ptr=NULL or illegal font index for the particular OS. Should not happen =-)
	if(ptr==NULL || (version<0x03000000l&&index>6))
		return true;
	if(version<0x03000000l)
		*(((UInt32 *)0x1d2)+index)=(UInt32)ptr;
	else
		*((*((UInt32 **)0x1da))+index)=(UInt32)ptr;
	return true; // just in case I need to return something meaningful
}
