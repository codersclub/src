#define frmMain 2000
#define frmConfirmReset 2001
#define frmCouldNotSave 2002
#define frmFontSizeWarning 2003
#define frmUnknownOS 2004
#define frmAbout 3000

#define idTrap	1000
#define idForm	2000
#define idAbout	3000

#define lStandard 2001
#define lBold 2002
#define lLarge 2003
#define lSymbol 2004
#define lSymbol11 2005
#define lSymbol7 2006
#define lLED 2007
#define lLargeBold 2008

#define pStandard 2011
#define pBold 2012
#define pLarge 2013
#define pSymbol 2014
#define pSymbol11 2015
#define pSymbol7 2016
#define pLED 2017
#define pLargeBold 2018

#define liList 2019

#define liStandard 2031
#define liBold 2032
#define liLarge 2033
#define liSymbol 2034
#define liSymbol11 2035
#define liSymbol7 2036
#define liLED 2037
#define liLargeBold 2038

#define pApplication 2039
#define liApplication	2040
#define cLocked		2041
#define lAll		2042

#define bReset 2021
#define bSave 2022

#define ftrGlobalData 2100
#define ftrLockedFonts 2101

#define ftrTrapStart 1000