#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <System/SysEvtMgr.h>
#define NON_PORTABLE
#define asm
#include <Hardware/Hardware.h>

char *getstring1();

void myEvtGetEvent(EventPtr event, SDWord timeout)
{
  void (*last) ();

  FtrGet('TZDH', 1000, (DWord *) & last);
  last(event, timeout);

  if (event->eType == keyDownEvent && event->data.keyDown.chr == calcChr) {
    VoidHand t;
    short i;
    DmOpenRef dbR;

    if ((dbR = DmOpenDatabaseByTypeCreator('Data', 'rcDO', dmModeReadWrite)) == NULL) {
      if (DmCreateDatabase(0, getstring1(), 'rcDO', 'Data', false))
	return;
      dbR = DmOpenDatabaseByTypeCreator('Data', 'rcDO', dmModeReadWrite);
    }
    
    HwrBacklight(1, !HwrBacklight(0, 0));

    i = 32767;
    t = DmNewRecord(dbR, &i, 3200);
    DmWrite(MemHandleLock(t), 0, WinGetWindowPointer(FrmGetWindowHandle(FrmGetActiveForm()))->displayAddrV20, 3200);
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, i, true);
    DmCloseDatabase(dbR);

    HwrBacklight(1, !HwrBacklight(0, 0));
    event->eType = nilEvent;

  }
  return;
}

static char string1[] = "DoodleDB";

char *getstring1()
{
  return string1;
}
