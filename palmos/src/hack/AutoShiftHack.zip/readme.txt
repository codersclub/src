AutoShift Hack v0.1
-------------------
Copyright 2000 Justin R. Cutler (cthulhu48@hotmail.com)

About
-----
Disables Graffiti autoshift.

This was my second attempt at a hack (using OnBoardC).

It works on my Palm Vx (OS3.5) but may or may not work on yours.

Feel free to suggest improvements in the code.

Compiled with OnBoardC
http://www.individeo.net/OnBoardC.html
http://www.palmgear.com/software/showsoftware.cfm?prodID=8197


Files
-----
readme.txt             : This file.
AutoShiftHack.PRC      : AutoShift Hack
AutoShiftHack.c        : Source code (paste into a memo)
AutoShiftHack_Rsrc.PRC : Resources for AutoShift Hack


History
-------
v0.1 First working version
