/* AutoShiftHack.c */
/* � 2000 Justin R. Cutler */
/* cthulhu48@hotmail.com */

/*
from CoreTraps.h
#define sysTrapGrfSetState 0xA281
*/

/* From graffiti.h */
Err GrfGetState(Boolean *capsLockP, Boolean *numLockP, UInt16 *tempShiftP, Boolean *autoShiftedP) SYS_TRAP(sysTrapGrfGetState);
Err GrfSetState(Boolean capsLock, Boolean numLock, Boolean upperShift) SYS_TRAP(sysTrapGrfSetState);

#define mycreator 'ASHk'
#define myresourceID 1000

/*
Trap Handler for sysTrapGrfSetState
*/

Boolean mySysTrapGrfSetState (Boolean capsLock, Boolean numLock, Boolean upperShift)
{
/* procedure pointer to old trap */
	Boolean (*oldtrap)(Boolean, Boolean, Boolean);
/* for the feature manager call type checking */
	DWord temp;

	/* get old trap address from HackMaster */
	FtrGet(mycreator, myresourceID, &temp);

	/* set procedure pointer */
	oldtrap = (Boolean (*)(Boolean, Boolean, Boolean)) temp;

	Boolean newupperShift = upperShift;

	Boolean autoShifted;
	Boolean unusedB;
	UInt16 tempShift;

	GrfGetState(&unusedB, &unusedB, &tempShift, &autoShifted);
	if (!(autoShifted) && upperShift)
	{
		newupperShift = false;
	}

	return oldtrap(capsLock, numLock, newupperShift);
}
