#include <stdio.h>
#include <stdlib.h>

typedef unsigned char SDC;
#define sdcEnd 0 
#define sdcFreqDur 1
#define sdcEndLoop 2
#define sdcLoop 3
#define sdcDelay 4

#define sysTicksPerSecond 100

#define FreqDur(freq, dur) sdcFreqDur, (SDC) (((freq) & 0xff00) >> 8), (freq) & 0xff, (SDC) (((dur) & 0xff00)>>8), (dur) & 0xff
#define EndLoop() sdcEndLoop
#define Loop(c) sdcLoop, c
#define Delay(dur)  sdcDelay, (dur*sysTicksPerSecond/1000)
#define End() sdcEnd

typedef struct _sd
	{
	int wFreq;
	int ms;
	} SD;

//__declspec(allocate("_CODE")) 
SDC rgsdc[] =	// siren 0
	{
	Loop(3),
		FreqDur(1000, 200),
		FreqDur(2000, 200),
	EndLoop(),
	End(),
	Loop(3),	// loop 1
		FreqDur(3000, 200),	// sine wave
		FreqDur(4000, 200),
		FreqDur(5000, 200),
		FreqDur(4000, 200),
	EndLoop(),
	End(),
	Loop(3),	// ramp 2
		FreqDur(500, 75),	   // computer (ramp)
		FreqDur(1000, 75),
		FreqDur(2000,75),
		FreqDur(3000, 75),
		FreqDur(4000, 75),
		FreqDur(5000, 75),
	EndLoop(),
	End(),
//	Loop(3), // skipalong 3
		FreqDur(500, 800),
		FreqDur(1000, 50),
		FreqDur(1600, 350),
		FreqDur(1400, 50),
		FreqDur(1000, 500),
//	EndLoop(),
	End(),
	Loop(3),	// beethoven
		FreqDur(393*2, 200), // Beethoven's Fuenfste
		Delay(10),
	EndLoop(),
	FreqDur(311*2, 1450),
	Delay(100),
	Loop(3),
		FreqDur(349*2, 200),
		Delay(10),
	EndLoop(),
	FreqDur(294*2, 1450),
	End(),
	Loop(3),	// eurocop
		FreqDur(1000, 750),
		FreqDur(2000, 750),
	EndLoop(),
	End(),
	Loop(24),	// Cricket
		FreqDur(4950, 5),
		FreqDur(5000, 5),
	EndLoop(),
	Delay(500),
	Loop(24),	
		FreqDur(4950, 5),
		FreqDur(5000, 5),
	EndLoop(),
	Delay(500),
	Loop(24),	
		FreqDur(4950, 5),
		FreqDur(5000, 5),
	EndLoop(),
	End(),
//	Loop(5),	// chirp
		FreqDur(4000, 15),
//	EndLoop(),
	End(),
	FreqDur(500, 75),	   // random
	FreqDur(2000,75),
	FreqDur(3000, 75),
	FreqDur(5000, 75),
	FreqDur(500, 75),
	FreqDur(4000, 75),
	FreqDur(1000, 75),
	FreqDur(5000, 75),
	FreqDur(4000, 75),
	FreqDur(500, 75),
	FreqDur(4000, 75),
	FreqDur(3000, 75),
	FreqDur(1000, 75),
	FreqDur(2000,75),
	FreqDur(3000, 75),
	FreqDur(500, 75),
	FreqDur(5000, 75),
	FreqDur(4000, 75),
	FreqDur(1000, 75),
	FreqDur(5000, 75),
	FreqDur(4000, 75),
	FreqDur(500, 75),
	FreqDur(4000, 75),
	End()
	};
	
	
main()
	{
	FILE *fhOut;
	SDC *psdc;
	
	fhOut = fopen("res\\snd.bin", "wb");
	for (psdc = rgsdc; psdc < rgsdc+sizeof(rgsdc); psdc++)
		fputc(*psdc, fhOut);
	printf("res\\snd.bin emitted\n");
	fclose(fhOut);	
	}	

