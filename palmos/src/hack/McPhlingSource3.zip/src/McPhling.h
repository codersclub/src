///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  McPhling.h                                          //
//     Original Author:  Mitch Blevins <mblevin@debian.org> (� 1997-2000)    //
// Modification Author:  Mike McCollister (� 2000-2002)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8p8                                         //
//                       HandEra Header Files from SDK 1.04                  //
//               Notes:  Distributed under the GNU GPL.                      //
//                       Based on LinkHistoryHack by Ben Darnell             //
//                       <bgdarnel@unity.ncsu.edu> which was based on        //
//                       SampleHack by Roger Chaplin                         //
//                       <foursquaredev@att.net>.                            //
//         Description:  McPhling Header File                                //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#ifndef MCPHLING_H
#define	MCPHLING_H 1
 
/////////////
// Defines //
/////////////

// The Hack's creator ID -- make sure you reserve one at the PalmOS.com
#define APP_ID              'McPg'

// IDs of the different preference types
#define REFPREFS             0
#define IGNOREPREFS          1
#define PREFS                2
#define VFSLAST              3
#define VFSLAST2             4

#define DEFAULT_NUM_ITEMS    10
#define MAX_NUM_ITEMS        14
#define MIN_NUM_ITEMS        2

#define IS_A_FAV             0x0001
#define IS_IGNORED           0x0002
#define IS_A_VFS             0x0004

#define VFS_MAX_VOLUMES      2
#define VFS_MAX_PATH         255

// icon cache DB
#define DB_TYPE_CACHE        'Cach'
#define DB_NAME_CACHE        "McPhlingCache"
#define DB_VER_CACHE         "3.0"
#define DB_VER_LEN_CACHE     4
#define ICON_NAME            ainID // this is 1000
#define SMALL_ICON           1001
#define MEDIUM_ICON          2001
#define VFS_PATH             (ICON_NAME + 2000)

// features
#define FTR_PAPPLIST         0x115c // 4444
#define FTR_APPCOUNT         0x115d // 4445
#define FTR_DUPLICATE        0x115e // 4446
#define FTR_NEWNUMITEMS      0x115f // 4447
#define FTR_OLDWINRECT       0x1160 // 4448
#define FTR_FIELDNUMITEMS    0x1161 // 4449
#define FTR_VGASCREENMODE    0x1162 // 4450
#define FTR_VGAROTATEMODE    0x1163 // 4451
#define FTR_DRAWLISTDATA     0x1164 // 4452


//////////////////
// Enumerations //
//////////////////

typedef enum {
   stMRU = 0,
   stMRUFavTop,
   stMRUFavBottom,
   stAlpha,
   stAlphaFavTop,
   stAlphaFavBottom
} SortType;


////////////////
// Structures //
////////////////

typedef struct {
   UInt32 creator;
   Coord  width; // no longer used
   UInt16 flags;
} JumpRefPref;


typedef struct {
   UInt8    prefVersion;
   UInt8    numItems;
   Boolean  bShowIcons      : 1;
   Boolean  bClick          : 1;
   Boolean  bShowCurrentApp : 1;
   Boolean  bVFSSupport     : 1;
   SortType sortType;
} McPhlingPrefs;


typedef struct {
   UInt32 creator;
} VFSLast;


typedef struct {
   UInt16 volRefNum;
   Char   path[VFS_MAX_PATH + 1];
} VFSVolInfo;


typedef struct {
   Int16      numVFSVolumes;
   VFSVolInfo vfsVol[VFS_MAX_VOLUMES];
} VFSInfo;


#endif
