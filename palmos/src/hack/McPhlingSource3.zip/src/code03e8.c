///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  code03e8.c                                          //
//     Original Author:  Mitch Blevins <mblevin@debian.org> (� 1997-2000)    //
// Modification Author:  Mike McCollister (� 2000-2002)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8p8                                         //
//                       HandEra Header Files from SDK 1.04                  //
//               Notes:  Distributed under the GNU GPL.                      //
//                       Based on LinkHistoryHack by Ben Darnell             //
//                       <bgdarnel@unity.ncsu.edu> which was based on        //
//                       SampleHack by Roger Chaplin                         //
//                       <foursquaredev@att.net>.                            //
//         Description:  SoftKeyStroke trap handler for McPhling.            //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

//////////////////////
// Error Prevention //
//////////////////////

// Can't do this due to the ListType access that I am doing
// #define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS


///////////////////
// Include Files //
///////////////////

#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <HandEra/Silk.h>
#include <HandEra/Vga.h>

#include "common.h"
#include "McPhling.h"
#include "McPhling.rch"


////////////////
// Structures //
////////////////

typedef struct {
   JumpRefPref jumpRef;
   UInt16      cardNo;
   LocalID     dbID;
   Char        name[dmDBNameLength + 1];
   Boolean     bInVfs;
   Int16       vfsVolIndex;
   Char        vfsPath[VFS_MAX_PATH + 1];
} JumpRefPlus;

typedef struct {
   Boolean        bVgaExists;
   Boolean        bVgaLargeFont;
   FontID         McStdFont;
   FontID         McBoldFont;
   Int16          indexStart;
   Int16          xOffsetText;
   JumpRefPlus    jumpRefPlus[MAX_NUM_ITEMS + 1];
   VFSInfo        vfsInfo;
   McPhlingPrefs *pMpPrefs;
} DrawListData;

typedef struct {
   UInt32      creator;
   Int16       vfsVolIndex;
   Char        vfsPath[VFS_MAX_PATH + 1];
} VFSCreatorList;
   

/////////////////////////
// Function Prototypes //
/////////////////////////

static void DoAction(Boolean bUseList, Boolean bVgaExists);
static void DrawList(UInt16 itemnum, RectanglePtr bounds, Char **unused);
static Int16 JumpRefSortMRUFavTop(JumpRefPlus *a1, JumpRefPlus *a2,
                                  Int32 unused);
static Int16 JumpRefSortMRUFavBottom(JumpRefPlus *a1, JumpRefPlus *a2,
                                     Int32 unused);
static Int16 JumpRefSortAlpha(JumpRefPlus *a1, JumpRefPlus *a2, Int32 unused);
static Int16 JumpRefSortAlphaFavTop(JumpRefPlus *a1, JumpRefPlus *a2,
                                    Int32 unused);
static Int16 JumpRefSortAlphaFavBottom(JumpRefPlus *a1, JumpRefPlus *a2,
                                       Int32 unused);
static void GetVgaButtonCoords(RectangleType *appBounds,
                               RectangleType *menuBounds,
                               RectangleType *targetBounds);
static Boolean GetIconNameFromCache(UInt16 cardNo, LocalID dbID, UInt32 creator,
                                    Char *pIconChar);

// VFS Specific Code
static void VFSSetup(VFSInfo *vfsInfo);
static void VFSFindApps(DrawListData *drawListData);
static void VFSRunApp(VFSInfo *vfsInfo, Int16 vfsVolIndex, Char *vfsPath,
                      UInt16 *cardNoP, LocalID *dbIDP, UInt32 creator,
                      Boolean bVgaExists);
static void myWipe(void);


///////////////
// Functions //
///////////////

Err EvtProcessSoftKeyStroke(PointType* start, PointType* end)
{
   // This is the code that will be called whenever ANY app calls
   // EvtProcessSoftKeyStroke and this hack is enabled in HackMaster.
   // HackMaster is not smart about the content of this file; it will simply
   // jump to the first executable statement in this file. If you need helper
   // functions, prototype them above, and define them AFTER the trap patch.

   UInt32 temp;
   Err (*oldTrap)(PointType*, PointType*);
   Boolean bVgaExists = false;
   RectangleType appBounds    = {{ 0, 161}, { 24, 32}};
   RectangleType menuBounds   = {{ 0, 191}, { 24, 32}};
   RectangleType targetBounds = {{27, 161}, {120, 32}};
   Coord xMax;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&temp)) {
      bVgaExists = true;
      GetVgaButtonCoords(&appBounds, &menuBounds, &targetBounds);
   }

   xMax = menuBounds.topLeft.x + menuBounds.extent.x;

   // get the address of the old EvtProcessSoftKeyStroke() from HackMaster
   FtrGet(APP_ID, 0x3e8, &temp);

   // set the function pointer to the old trap
   oldTrap = (Err (*)(PointType*, PointType*))temp;

   if(start->x <= xMax) {
      if(RctPtInRectangle(start->x, start->y, &menuBounds)) {
         if(RctPtInRectangle(end->x, end->y, &appBounds)) {
            myWipe();
            DoAction(true, bVgaExists);
            myWipe();
            return -1;
         }
      }
      else if(RctPtInRectangle(start->x, start->y, &appBounds)) {
         if(RctPtInRectangle(end->x, end->y, &targetBounds)) {
            myWipe();
            DoAction(false, bVgaExists);
            myWipe();
            return -1;
         }
      }
   }

   return oldTrap(start, end);
}


static void DoAction(Boolean bUseList, Boolean bVgaExists)
{
   ListType list;
   Int16 first, sel;
   UInt16 i, cardNo, jumpNum;
   LocalID dbID;
   UInt32 currType, currCreator;
   UInt32 temp;
   JumpRefPref *jumpRefs = NULL;
   DmSearchStateType searchState;
   Err err;
   FontID oldFont, McStdFont = stdFont, McBoldFont = boldFont;
   McPhlingPrefs mpPrefs;
   DrawListData *drawListData = NULL;
   Coord width;
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   Boolean bVgaLargeFont = false;
   Boolean bInVfs;
   UInt8 numToCheck;
   Char *iconName = NULL;
   Char *nameList[MAX_NUM_ITEMS + 1];

   // set aside memory for iconName
   iconName = MemPtrNew(sizeof(Char) * (dmDBNameLength + 1));
   if(iconName == NULL)
      return;

   // get preferences
   GetPrefsAndNewIgnored(&mpPrefs);

   // Click to confirm to the user
   if(mpPrefs.bClick)
      SndPlaySystemSound(sndClick);

   // Clear list if list already up
   if(bUseList) {
      if(FtrGet(APP_ID, FTR_DUPLICATE, &temp) == 0) {
         EventType event;

         event.eType = lstExitEvent;
         EvtAddEventToQueue(&event);

         return;
      }
   }

   // Create large data structures
   jumpRefs     = MemPtrNew((MAX_NUM_ITEMS + 1) * sizeof(JumpRefPref));
   drawListData = MemPtrNew(sizeof(DrawListData));

   // set name list pointers
   for(i = 0; i <= MAX_NUM_ITEMS; i++)
      nameList[i] = drawListData->jumpRefPlus[i].name;

   // Get the list of cached apps
   GetMRUApps(&mpPrefs, jumpRefs);
   drawListData->pMpPrefs = &mpPrefs;

   // Put jumpRefs into jumpRef
   for(i = 0; i <= MAX_NUM_ITEMS; i++) {
      drawListData->jumpRefPlus[i].jumpRef = jumpRefs[i];
      drawListData->jumpRefPlus[i].bInVfs  = false;
   }

   // Setup VFS Structures
   if(mpPrefs.bVFSSupport) {
      VFSSetup(&drawListData->vfsInfo);
      VFSFindApps(drawListData);
   }

   // remove any deleted apps and update cardNo and dbID
   numToCheck = (bUseList ? mpPrefs.numItems : 1);
   for(i = 0; i <= mpPrefs.numItems; i++) {
      Boolean bGotName;
      UInt32 creator = drawListData->jumpRefPlus[i].jumpRef.creator;

      if(creator == 0)
         break;

      // see if application still exists
      err = 0;
      err = DmGetNextDatabaseByTypeCreator(true, &searchState,
                                           sysFileTApplication, creator,
                                           true, &cardNo, &dbID);
      bGotName = GetIconNameFromCache(cardNo, dbID, creator, iconName);

      // see if application is on a VFS volume
      if(err && bGotName) {
         bInVfs = drawListData->jumpRefPlus[i].bInVfs;
      }
      else {
         bInVfs = false;
         drawListData->jumpRefPlus[i].bInVfs = bInVfs;
      }
      
      if(err && !bInVfs) {
         // Remove the offending entry
         MemMove(&drawListData->jumpRefPlus[i],
                 &drawListData->jumpRefPlus[i + 1],
                 (mpPrefs.numItems - i) * sizeof(JumpRefPlus));
         MemSet(&drawListData->jumpRefPlus[mpPrefs.numItems],
                sizeof(JumpRefPlus), 0);
         i--;
         continue;
      }
      else {
         StrNCopy(drawListData->jumpRefPlus[i].name, iconName, dmDBNameLength);

         if(!bInVfs) {
            drawListData->jumpRefPlus[i].cardNo = cardNo;
            drawListData->jumpRefPlus[i].dbID   = dbID;
         }
      }
   }

   // Decide which action to take...
   if(bUseList) {
      // do some VGA stuff
      if(bVgaExists) {
         VgaGetScreenMode(&screenMode, &rotateMode);
         VgaSetScreenMode(screenMode1To1, rotateMode);
         if(rotateMode == rotateModeNone || rotateMode == rotateMode180) {
            bVgaLargeFont = true;
            McStdFont  = VgaBaseToVgaFont(stdFont);
            McBoldFont = VgaBaseToVgaFont(boldFont);
         }
      }
      drawListData->bVgaLargeFont = bVgaLargeFont;
      drawListData->bVgaExists    = bVgaExists;
      drawListData->McStdFont     = McStdFont;
      drawListData->McBoldFont    = McBoldFont;

      // determine which is the first application to show
      first = (mpPrefs.bShowCurrentApp ? 0 : 1);

      // Find the list height and width
      MemSet(&list, sizeof(ListType), 0);
      list.numItems = 0;
      oldFont = FntSetFont(McStdFont);
      for(i = first; i <= mpPrefs.numItems; i++) {
         if(!drawListData->jumpRefPlus[i].jumpRef.creator)
            break;

         if(drawListData->jumpRefPlus[i].jumpRef.flags & IS_A_FAV) {
            FntSetFont(McBoldFont);
            width = FntCharsWidth(drawListData->jumpRefPlus[i].name,
                                  StrLen(drawListData->jumpRefPlus[i].name))+1;
            FntSetFont(McStdFont);
         }
         else {
            width = FntCharsWidth(drawListData->jumpRefPlus[i].name,
                                  StrLen(drawListData->jumpRefPlus[i].name));
         }
         if(width > list.bounds.extent.x)
            list.bounds.extent.x = width;
         list.numItems++;
      }

      // goto cleanup if nothing on the list
      if(!list.numItems) {
         SndPlaySystemSound(sndWarning);
         goto cleanup;
      }

      // Sort entries
      switch(mpPrefs.sortType) {
         case stMRU:
            break;

         case stMRUFavTop:
            SysInsertionSort(&(drawListData->jumpRefPlus[first]),
                             list.numItems, sizeof(JumpRefPlus),
                             (CmpFuncPtr)JumpRefSortMRUFavTop, 0);
            break;

         case stMRUFavBottom:
            SysInsertionSort(&(drawListData->jumpRefPlus[first]),
                             list.numItems, sizeof(JumpRefPlus),
                             (CmpFuncPtr)JumpRefSortMRUFavBottom, 0);
            break;

         case stAlpha:
            SysInsertionSort(&(drawListData->jumpRefPlus[first]),
                             list.numItems, sizeof(JumpRefPlus),
                             (CmpFuncPtr)JumpRefSortAlpha, 0);
            break;

         case stAlphaFavTop:
            SysInsertionSort(&(drawListData->jumpRefPlus[first]),
                             list.numItems, sizeof(JumpRefPlus),
                             (CmpFuncPtr)JumpRefSortAlphaFavTop, 0);
            break;

         case stAlphaFavBottom:
            SysInsertionSort(&(drawListData->jumpRefPlus[first]),
                             list.numItems, sizeof(JumpRefPlus),
                             (CmpFuncPtr)JumpRefSortAlphaFavBottom, 0);
            break;
      }

      // add padding to the width
      if(mpPrefs.bShowIcons)
         list.bounds.extent.x += (bVgaLargeFont ? 28 : 20); // padding
      else
         list.bounds.extent.x += (bVgaLargeFont ? 1 : 3);  // padding

      // setup data to be passed
      drawListData->indexStart = list.numItems - (first ? 0 : 1);

      list.bounds.extent.y = list.numItems * FntCharHeight();
      list.bounds.topLeft.x = -240; // make sure list is all the way to the left
      list.bounds.topLeft.y = 320 - list.bounds.extent.y;
      list.attr.usable = true;
      list.font = McStdFont;
      list.topItem = 0;
      list.drawItemsCallback = (ListDrawDataFuncPtr)DrawList;
      list.itemsText = nameList;
      LstSetSelection(&list, -1);

      // set text position
      drawListData->xOffsetText =
         (mpPrefs.bShowIcons ? (bVgaLargeFont ? 26 : 17) : 0);

      // Popup the list
      FtrSet(APP_ID, FTR_DRAWLISTDATA, (UInt32)drawListData);
      FtrSet(APP_ID, FTR_DUPLICATE, i); // just a warning...
      if(bVgaExists) {
         WinHandle saveWindow = WinSetDrawWindow(WinGetDisplayWindow());

         sel = LstPopupList(&list);
         if(saveWindow != NULL)
            WinSetDrawWindow(saveWindow);
         VgaSetScreenMode(screenMode, rotateMode);
      }
      else
         sel = LstPopupList(&list);

      FtrUnregister(APP_ID, FTR_DUPLICATE); // OK, safe now.
      FtrUnregister(APP_ID, FTR_DRAWLISTDATA);
      FntSetFont(oldFont);
      if(sel >= 0)
         jumpNum = list.numItems - sel - (first ? 0 : 1);
      else
         goto cleanup;

   }
   else {
      jumpNum = 1;

      // if current app is not in position 0, then last app is in position 0
      if(!SysCurAppDatabase(&cardNo, &dbID)) {
         if(!DmDatabaseInfo(cardNo, dbID, NULL, NULL, NULL, NULL, NULL,
                            NULL, NULL, NULL, NULL, &currType, &currCreator)) {
            if(currType == sysFileTApplication)
               if(drawListData->jumpRefPlus[0].jumpRef.creator != currCreator)
                  jumpNum = 0;
            }
      }
   }

   // Jump to the app
   if(!drawListData->jumpRefPlus[jumpNum].jumpRef.creator) {
      // Must not be a real app
      SndPlaySystemSound(sndWarning);
      goto cleanup;
   }

   // launch application
   if(drawListData->jumpRefPlus[jumpNum].bInVfs)
      VFSRunApp(&drawListData->vfsInfo,
                drawListData->jumpRefPlus[jumpNum].vfsVolIndex,
                drawListData->jumpRefPlus[jumpNum].vfsPath,
                &drawListData->jumpRefPlus[jumpNum].cardNo,
                &drawListData->jumpRefPlus[jumpNum].dbID,
                drawListData->jumpRefPlus[jumpNum].jumpRef.creator,
                bVgaExists);
   else
      SysUIAppSwitch(drawListData->jumpRefPlus[jumpNum].cardNo,
                     drawListData->jumpRefPlus[jumpNum].dbID,
                     sysAppLaunchCmdNormalLaunch, NULL);

cleanup:
   if(jumpRefs)
      MemPtrFree(jumpRefs);
   if(drawListData)
      MemPtrFree(drawListData);
   if(iconName)
      MemPtrFree(iconName);
}


static void DrawList(UInt16 itemnum, RectanglePtr bounds,
                     Char **unused __attribute__ ((unused)))
{
   UInt16 cardNo;
   LocalID dbID;
   DmOpenRef dbR = NULL;
   Char *name;
   MemHandle hRes = NULL;
   BitmapPtr pRes;
   Int16 xOffset;
   JumpRefPlus *pCurrentRefPlus;
   JumpRefPref *pCurrentRef;
   UInt16 index;
   Boolean bIsAFav;
   Coord iconWidth;
   Boolean bExpand = false;
   Boolean bInVfs;
   VFSInfo *pVfsInfo;
   UInt32 creator;
   DrawListData *drawListData;
 
   // get drawListData pointer
   if(FtrGet(APP_ID, FTR_DRAWLISTDATA, &creator) != 0)
      return;
   drawListData = (DrawListData *)creator;

   index = drawListData->indexStart - itemnum;

   // get cardNo and dbID
   pCurrentRefPlus =  drawListData->jumpRefPlus + index;
   pCurrentRef     = &pCurrentRefPlus->jumpRef;
   cardNo          =  pCurrentRefPlus->cardNo;
   dbID            =  pCurrentRefPlus->dbID;
   name            =  pCurrentRefPlus->name;
   bInVfs          =  pCurrentRefPlus->bInVfs;
   bIsAFav         =  pCurrentRef->flags & IS_A_FAV;
   pVfsInfo        = &drawListData->vfsInfo;
   creator         =  pCurrentRef->creator;

   // Open database and read the info
   dbR = DmOpenDatabaseByTypeCreator(DB_TYPE_CACHE, APP_ID, dmModeReadOnly);

   if(drawListData->pMpPrefs->bShowIcons) {
      // get icon and draw
      if(drawListData->bVgaLargeFont) {
         // get medium icon
         hRes = DmGet1Resource(creator, MEDIUM_ICON);

         // get small icon if medium does not exist
         if(hRes == NULL) {
            bExpand = true;
            hRes = DmGet1Resource(creator, SMALL_ICON);
         }
      }
      else {
         // get small icon
         hRes = DmGet1Resource(creator, SMALL_ICON);
      }

      // get default icon if necessary
      if(hRes == NULL)
         hRes = DmGetResource(iconType, defaultAppSmallIconBitmap);

      if(hRes != NULL) {
         pRes = (BitmapPtr)MemHandleLock(hRes);
         iconWidth = pRes->width;
         // BmpGlueGetDimensions(pRes, &iconWidth, NULL, NULL);
         if(bExpand) {
            xOffset = (15 - iconWidth) / 2;
            VgaWinDrawBitmapExpanded(pRes, bounds->topLeft.x + xOffset,
                                           bounds->topLeft.y + 1);
         }
         else {
            xOffset = ((drawListData->bVgaLargeFont ? 23 : 15) - iconWidth) / 2;
            WinDrawBitmap(pRes, bounds->topLeft.x + xOffset,
                                bounds->topLeft.y + 1);
         }
         MemHandleUnlock(hRes);
         DmReleaseResource(hRes);
      }
   }

   // close the database
   if(dbR != NULL)
      DmCloseDatabase(dbR);

   // set the font
   if(bIsAFav)
      FntSetFont(drawListData->McBoldFont);

   // draw the characters
   if(bInVfs) {
      WinSetUnderlineMode(grayUnderline);
      WinDrawChars(name, StrLen(name),
                   bounds->topLeft.x + drawListData->xOffsetText,
                   bounds->topLeft.y);
      WinSetUnderlineMode(noUnderline);
   }
   else {
      WinDrawChars(name, StrLen(name),
                   bounds->topLeft.x + drawListData->xOffsetText,
                   bounds->topLeft.y);
   }

   // reset the font
   if(bIsAFav)
      FntSetFont(drawListData->McStdFont);
}


static Int16 JumpRefSortMRUFavTop(JumpRefPlus *a1, JumpRefPlus *a2,
                                  Int32 unused __attribute__ ((unused)))
{
   Int16 result;
   Boolean bA1Fav = a1->jumpRef.flags & IS_A_FAV;
   Boolean bA2Fav = a2->jumpRef.flags & IS_A_FAV;

   if((bA1Fav && bA2Fav) || (!bA1Fav && !bA2Fav))
      result =  0;
   else if(bA1Fav && !bA2Fav)
      result =  1;
   else
      result = -1;
   
   return result;
}


static Int16 JumpRefSortMRUFavBottom(JumpRefPlus *a1, JumpRefPlus *a2,
                                     Int32 unused __attribute__ ((unused)))
{
   Int16 result;
   Boolean bA1Fav = a1->jumpRef.flags & IS_A_FAV;
   Boolean bA2Fav = a2->jumpRef.flags & IS_A_FAV;

   if((bA1Fav && bA2Fav) || (!bA1Fav && !bA2Fav))
      result =  0;
   else if(bA1Fav && !bA2Fav)
      result = -1;
   else
      result =  1;
   
   return result;
}


static Int16 JumpRefSortAlpha(JumpRefPlus *a1, JumpRefPlus *a2,
                              Int32 unused __attribute__ ((unused)))
{
   return StrCaselessCompare(a2->name, a1->name);
}


static Int16 JumpRefSortAlphaFavTop(JumpRefPlus *a1, JumpRefPlus *a2,
                                    Int32 unused __attribute__ ((unused)))
{
   Int16 result;
   Boolean bA1Fav = a1->jumpRef.flags & IS_A_FAV;
   Boolean bA2Fav = a2->jumpRef.flags & IS_A_FAV;

   if((bA1Fav && bA2Fav) || (!bA1Fav && !bA2Fav))
      result = StrCaselessCompare(a2->name, a1->name);
   else if(bA1Fav && !bA2Fav)
      result =  1;
   else
      result = -1;
   
   return result;
}


static Int16 JumpRefSortAlphaFavBottom(JumpRefPlus *a1, JumpRefPlus *a2,
                                       Int32 unused __attribute__ ((unused)))
{
   Int16 result;
   Boolean bA1Fav = a1->jumpRef.flags & IS_A_FAV;
   Boolean bA2Fav = a2->jumpRef.flags & IS_A_FAV;

   if((bA1Fav && bA2Fav) || (!bA1Fav && !bA2Fav))
      result = StrCaselessCompare(a2->name, a1->name);
   else if(bA1Fav && !bA2Fav)
      result = -1;
   else
      result =  1;
   
   return result;
}


static void GetVgaButtonCoords(RectangleType *appBounds,
                               RectangleType *menuBounds,
                               RectangleType *targetBounds)
{
   UInt32 temp;
   Boolean bSilkMaximized;
   UInt16 i, buttonListSize;
   PenBtnListType *buttonList = NULL;
   // UInt32 screenHeight32;
   Coord screenHeight;

   if(_TRGSilkFeaturePresent(&temp) == false)
      return;

   bSilkMaximized = SilkWindowMaximized();
   buttonListSize = SilkGetButtonListSize(bSilkMaximized);

   buttonList = MemPtrNew(buttonListSize);
   if(buttonList == NULL)
      return;

   SilkGetButtonList(buttonList, bSilkMaximized);
   
   for(i = 0; i < buttonList->numButtons ; i++) {
      switch(buttonList->buttons[i].asciiCode) {
         case vchrMenu:
            *menuBounds = buttonList->buttons[i].boundsR;
            break;
         case vchrLaunch:
            *appBounds = buttonList->buttons[i].boundsR;
            break;
      }
   }
   if(bSilkMaximized)
      SilkGetAreas(targetBounds, NULL);
   else
      *targetBounds = *menuBounds;

   //WinScreenMode(winScreenModeGet, NULL, &screenHeight32, NULL, NULL);
   //screenHeight             = screenHeight32;
   screenHeight             = 320; // ??? kludge until I figure out a better way
   appBounds->topLeft.y    += screenHeight;
   menuBounds->topLeft.y   += screenHeight;
   targetBounds->topLeft.y += screenHeight;

   MemPtrFree(buttonList);
}


static Boolean GetIconNameFromCache(UInt16 cardNo, LocalID dbID, UInt32 creator,
                                    Char *pIconChar)
{
   DmOpenRef dbR;
   MemHandle hRes;
   Boolean bGotName = false;

   // Open database and read the info
   dbR = DmOpenDatabaseByTypeCreator(DB_TYPE_CACHE, APP_ID, dmModeReadOnly);
   if(dbR == NULL) {
      bGotName = GetIconName(cardNo, dbID, pIconChar);
      return bGotName;
   }

   hRes = DmGet1Resource(creator, ICON_NAME);
   if(hRes) {
      Char *pName = MemHandleLock(hRes);

      StrNCopy(pIconChar, pName, dmDBNameLength);
      MemHandleUnlock(hRes);
      bGotName = true;
   }
   else {
      bGotName = GetIconName(cardNo, dbID, pIconChar);
   }

   // close the database
   if(dbR)
      DmCloseDatabase(dbR);

   return bGotName;
}


static void myWipe(void)
{
   EvtFlushPenQueue();
   EvtFlushNextPenStroke();
}


/*********************/
/* VFS Specific Code */
/*********************/

static void VFSSetup(VFSInfo *vfsInfo)
{
   Err error;
   UInt32 vfsMgrVersion;
   Int16 i;
   UInt16 volRefNum;
   UInt32 volIterator = vfsIteratorStart;
   UInt16 bufLen = VFS_MAX_PATH;

   // Assume no VFS Volumes available
   vfsInfo->numVFSVolumes = 0;

   // Check if VFS features are available
   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &vfsMgrVersion);
   if(error)
      return;

   // get volume reference number
   for(i = 0; i < VFS_MAX_VOLUMES; i++) {
      error = VFSVolumeEnumerate(&volRefNum, &volIterator);
      if(!error) {
         vfsInfo->vfsVol[i].volRefNum = volRefNum;
         vfsInfo->numVFSVolumes++;
      }
   }

   // exit if no VFS volumes are available
   if(vfsInfo->numVFSVolumes == 0)
      return;

   // get default directory
   for(i = 0; i < vfsInfo->numVFSVolumes; i++) {
      error = VFSGetDefaultDirectory(vfsInfo->vfsVol[i].volRefNum,
                                     ".prc", vfsInfo->vfsVol[i].path, &bufLen);
   }
}


static void VFSFindApps(DrawListData *drawListData)
{
   Int16 i, j;
   Err error;
   UInt32 version;
   UInt32 creator;
   DmOpenRef dbR;
   MemHandle hRes;
   FileRef fileRef;

   // Check if VFS features are available
   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version);
   if(error)
      return;

   // Open database and read the info
   dbR = DmOpenDatabaseByTypeCreator(DB_TYPE_CACHE, APP_ID, dmModeReadOnly);
   if(dbR == NULL)
      return;

   for(i = 0; i < drawListData->vfsInfo.numVFSVolumes; i++) {
      VFSVolInfo *pVfsVol = drawListData->vfsInfo.vfsVol + i;

      for(j = 0; j <= drawListData->pMpPrefs->numItems; j++) {
         JumpRefPlus *pJumpRefPlus = drawListData->jumpRefPlus + j;

         creator = pJumpRefPlus->jumpRef.creator;

         if(creator == 0)
            break;

         hRes = DmGet1Resource(creator, VFS_PATH);
         if(hRes) {
            Char *vfsPath = MemHandleLock(hRes);

            error = VFSFileOpen(pVfsVol->volRefNum,
                                vfsPath, vfsModeRead, &fileRef);
            if(error == errNone) {
               pJumpRefPlus->bInVfs      = true;
               pJumpRefPlus->vfsVolIndex = i;
               StrNCopy(pJumpRefPlus->vfsPath, vfsPath, VFS_MAX_PATH);
               VFSFileClose(fileRef);
            }
            MemHandleUnlock(hRes);
            DmReleaseResource(hRes);
         }
      }
   }

   // close the database
   if(dbR)
      DmCloseDatabase(dbR);
}


static void VFSRunApp(VFSInfo *vfsInfo, Int16 vfsVolIndex, Char *vfsPath,
                      UInt16 *cardNoP, LocalID *dbIDP, UInt32 creator,
                      Boolean bVgaExists)
{
   Err err;
   VFSLast vfsLast;
   DmOpenRef dbHack;
   FormPtr pNewForm = NULL;
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   FormPtr pForm = FrmGetActiveForm();

   dbHack = DmOpenDatabaseByTypeCreator('HACK', APP_ID, dmModeReadOnly);

   DisplayWaitForm(bVgaExists, &screenMode, &rotateMode, &pNewForm);

   err = VFSImportDatabaseFromFile(vfsInfo->vfsVol[vfsVolIndex].volRefNum,
                                   vfsPath, cardNoP, dbIDP);
   DmCloseDatabase(dbHack);

   if(err == errNone) {
      SysAppLaunchCmdCardType sysAppLaunchCmdCardType;
      UInt32 result;

      sysAppLaunchCmdCardType.err = expErrUnsupportedOperation;
      sysAppLaunchCmdCardType.volRefNum =
         vfsInfo->vfsVol[vfsVolIndex].volRefNum;
      sysAppLaunchCmdCardType.path = vfsPath;
      sysAppLaunchCmdCardType.startFlags = sysAppLaunchStartFlagNoUISwitch;

      err = SysAppLaunch(*cardNoP, *dbIDP, 0, sysAppLaunchCmdCardLaunch,
                         &sysAppLaunchCmdCardType, &result);
      if(err == errNone)
         err = SysUIAppSwitch(*cardNoP, *dbIDP, sysAppLaunchCmdNormalLaunch,
                              NULL);

      // save preference so that McPhling knows which applicaiton to delete
      // when it has exited
      vfsLast.creator = creator;
      PrefSetAppPreferences(APP_ID, VFSLAST, 0, &vfsLast, sizeof(vfsLast),
                            true);
   }

   RemoveWaitForm(bVgaExists, screenMode, rotateMode, pNewForm, pForm);
}
