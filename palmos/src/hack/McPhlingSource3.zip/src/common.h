///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  common.h                                            //
//     Original Author:  Mike McCollister (� 2000-2002)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8p8                                         //
//                       HandEra Header Files from SDK 1.04                  //
//               Notes:  Distributed under the GNU GPL.                      //
//                       Based on LinkHistoryHack by Ben Darnell             //
//                       <bgdarnel@unity.ncsu.edu> which was based on        //
//                       SampleHack by Roger Chaplin                         //
//                       <foursquaredev@att.net>.                            //
//         Description:  Common code header file for McPhling.               //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#ifndef COMMON_H
#define	COMMON_H 1

///////////////////
// Include Files //
///////////////////

#include <PalmOS.h>
#include <HandEra/Vga.h>

#include "McPhling.h"


/////////////
// Defines //
/////////////

#define BEEP			SndPlaySystemSound(sndInfo)
#define CLICK			SndPlaySystemSound(sndClick)
#define DEBUG_BEEP		BEEP


/////////////////////////
// Function Prototypes //
/////////////////////////

Boolean GetIconName(UInt16 cardNo, LocalID dbID, Char *pIconChar);
void GetMRUApps(McPhlingPrefs *mpPrefs, JumpRefPref *jumpRefs);
void GetPrefsAndNewIgnored(McPhlingPrefs *pMpPrefs);
void *Id2Ptr(UInt16 wID);
void DisplayWaitForm(Boolean bVgaExists, VgaScreenModeType *pScreenMode,
                     VgaRotateModeType *pRotateMode, FormPtr *pNewForm);
void RemoveWaitForm(Boolean bVgaExists, VgaScreenModeType screenMode,
                    VgaRotateModeType rotateMode, FormPtr pNewForm,
                    FormPtr pForm);

#endif
