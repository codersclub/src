///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  common.c                                            //
//     Original Author:  Mike McCollister (� 2000-2002)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8p8                                         //
//                       HandEra Header Files from SDK 1.04                  //
//               Notes:  Distributed under the GNU GPL.                      //
//                       Based on LinkHistoryHack by Ben Darnell             //
//                       <bgdarnel@unity.ncsu.edu> which was based on        //
//                       SampleHack by Roger Chaplin                         //
//                       <foursquaredev@att.net>.                            //
//         Description:  Common code for McPhling.                           //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

//////////////////////
// Error Prevention //
//////////////////////

#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS


///////////////////
// Include Files //
///////////////////

#include "common.h"
#include "McPhling.rch"


///////////////
// Functions //
///////////////

Boolean GetIconName(UInt16 cardNo, LocalID dbID, Char *pIconChar)
{
   Char *pChar;
   DmOpenRef dbR  = NULL;
   MemHandle hRes = NULL;
   Boolean bGotName = false;

   if(dbID)
      dbR = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
   else {
      pIconChar[0] = '\0'; // just in case
      return false;
   }

   if(dbR)
      hRes = DmGet1Resource(ainRsc, ainID);

   if(hRes) {
      pChar = (Char *)MemHandleLock(hRes);

      // only change to icon name if tAIN is available
      if(pChar)
         StrNCopy(pIconChar, pChar, dmDBNameLength);

      MemHandleUnlock(hRes);
      DmReleaseResource(hRes);

      bGotName = true;
   }
   else {  // get the application name
      DmDatabaseInfo(cardNo, dbID, pIconChar, NULL,
                     NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                     NULL, NULL);

      bGotName = true;
   }

   DmCloseDatabase(dbR);

   return bGotName;
}


void GetMRUApps(McPhlingPrefs *mpPrefs, JumpRefPref *jumpRefs)
{
   UInt16 prefsSize;
   Int16 prefResult;

   prefsSize = (mpPrefs->numItems + 1) * sizeof(JumpRefPref);

   MemSet(jumpRefs, prefsSize, 0);
   prefResult = PrefGetAppPreferences(APP_ID, REFPREFS, jumpRefs, &prefsSize,
                                      true);
   if((prefResult == noPreferenceFound) ||
      (prefsSize < (mpPrefs->numItems + 1) * sizeof(JumpRefPref))) {
         MemSet(jumpRefs, (mpPrefs->numItems + 1) * sizeof(JumpRefPref), 0);
   }
}


void GetPrefsAndNewIgnored(McPhlingPrefs *pMpPrefs)
{
   UInt16 mpPrefsSize = 0;
   Int16 prefResult;
   UInt32 *ignoredapps = NULL;
   UInt16 ignPrefsSize = 0;
   UInt16 ignNumApps;

   prefResult = PrefGetAppPreferences(APP_ID, PREFS, NULL, &mpPrefsSize, true);
   if(prefResult == noPreferenceFound) {
      pMpPrefs->prefVersion     = 0x02;
      pMpPrefs->numItems        = DEFAULT_NUM_ITEMS;
      pMpPrefs->bShowIcons      = true;
      pMpPrefs->bClick          = true;
      pMpPrefs->bShowCurrentApp = false;
      pMpPrefs->bVFSSupport     = false;
      pMpPrefs->sortType        = stMRU;
      PrefSetAppPreferences(APP_ID, PREFS, 0, pMpPrefs, sizeof(McPhlingPrefs),
                            true);

      prefResult = PrefGetAppPreferences(APP_ID, IGNOREPREFS, NULL,
                                         &ignPrefsSize, true);
      if(prefResult == noPreferenceFound) {
         UInt16 i = 0;

         ignNumApps = 3; // this must match the number of apps below
         ignPrefsSize = ignNumApps * sizeof(UInt32);
         ignoredapps = MemPtrNew(ignPrefsSize);
         ignoredapps[i++] = 'lnch'; // built-in launcher
         ignoredapps[i++] = 'SSle'; // Launch 'Em
         ignoredapps[i++] = 'sync'; // HotSync
         PrefSetAppPreferences(APP_ID, IGNOREPREFS, 0, ignoredapps,
                               ignPrefsSize, true);
      }
   }
   else
      PrefGetAppPreferences(APP_ID, PREFS, pMpPrefs, &mpPrefsSize, true);

   // adjust preferences due to change
   if(pMpPrefs->prefVersion == 0x01) {
      pMpPrefs->prefVersion     = 0x02;
      pMpPrefs->bShowCurrentApp = false; // not implemented yet
      pMpPrefs->sortType        = stMRU;
      if(pMpPrefs->numItems > MAX_NUM_ITEMS)
         pMpPrefs->numItems = MAX_NUM_ITEMS;
   }
      
   if(ignoredapps)
      MemPtrFree(ignoredapps);
}


void *Id2Ptr(UInt16 wID)
{
   FormPtr pForm = FrmGetActiveForm();

   return(FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, wID)));
}


void DisplayWaitForm(Boolean bVgaExists, VgaScreenModeType *pScreenMode,
                     VgaRotateModeType *pRotateMode, FormPtr *pNewForm)
{
   *pNewForm = FrmInitForm(PleaseWaitForm);

   if(*pNewForm) {
      if(bVgaExists) {
         VgaGetScreenMode(pScreenMode, pRotateMode);
         VgaSetScreenMode(screenModeScaleToFit, *pRotateMode);
      }
      FrmSetActiveForm(*pNewForm);
      FrmDrawForm(*pNewForm);
   }
}


void RemoveWaitForm(Boolean bVgaExists, VgaScreenModeType screenMode,
                    VgaRotateModeType rotateMode, FormPtr pNewForm,
                    FormPtr pForm)
{
   if(pNewForm) {
      FrmEraseForm(pNewForm);
      FrmDeleteForm(pNewForm);
      if(bVgaExists)
         VgaSetScreenMode(screenMode, rotateMode);
   }

   if(pForm)
      FrmSetActiveForm(pForm);
}
