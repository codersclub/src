///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  code07d0.c                                          //
//     Original Author:  Mitch Blevins <mblevin@debian.org> (� 1997-2000)    //
// Modification Author:  Mike McCollister (� 2000-2002)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8p8                                         //
//                       HandEra Header Files from SDK 1.04                  //
//               Notes:  Distributed under the GNU GPL.                      //
//                       Based on LinkHistoryHack by Ben Darnell             //
//                       <bgdarnel@unity.ncsu.edu> which was based on        //
//                       SampleHack by Roger Chaplin                         //
//                       <foursquaredev@att.net>.                            //
//         Description:  McPhling Preferences Panel                          //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

//////////////////////
// Error Prevention //
//////////////////////

#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS


///////////////////
// Include Files //
///////////////////

#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <HandEra/Vga.h>

#include "common.h"
#include "McPhling.h"
#include "McPhling.rch"


/////////////
// Defines //
/////////////

#define LIST_PADDING            3


////////////////
// Structures //
////////////////

typedef struct {
   Char name[dmDBNameLength + 1];
   UInt32 creator;
   UInt16 flags;
   UInt16 vfsVolRefNum;
   Char vfsPath[VFS_MAX_PATH + 1];
} McPhlingAppList;


/////////////////////////
// Function Prototypes //
/////////////////////////

static void PrefsInit(FormPtr pForm);
static void PrefsOK(FormPtr pForm);
static void PrefsListDrawFunc(UInt16 index, RectanglePtr bounds, Char **data);
static void DoListSelect(Int16 selection);
static void ScrollList(FormPtr pForm, WinDirectionType direction);
static void AddFavorite(UInt32 creator, JumpRefPref* favApps,
                        McPhlingPrefs *pMpPrefs);
static void ChangeNumItems(FormPtr pForm, UInt16 keyDown);
static void UpdateForm(FormPtr pForm);
static void TruncateString(Char *pStr, Int16 width);
static void SizeForm(FormPtr pForm);
static void ResizeObject(FormPtr pForm, UInt16 objectIndex,
                         Coord xMove, Coord yMove,
                         Coord xExp, Coord yExp, Boolean bDraw);
static void DisplayString(Char *str, MemHandle hField, UInt16 fieldID,
                          Boolean bRefresh);
static void LstSetBestWidth(UInt16 listID);
static void CreateAppCache(Boolean bShowIcons, Boolean bVFSSupport,
                           JumpRefPref *pAppList, UInt8 numItems,
                           McPhlingAppList *pMcAppList, UInt16 numApps);
static Boolean CreateDatabaseList(Boolean bVFSSupport, UInt16 *pAppCount,
                                  McPhlingAppList **pMcAppList);
static void UpdateDatabaseList(FormPtr pForm);
static Int16 DatabaseSortAlpha(McPhlingAppList *a1, McPhlingAppList *a2,
                               Int32 unused);

// Registration Form Functions
static void DisplayRegistrationForm(UInt16 rscID);

// VFS Specific Code
static void VFSSetup(VFSInfo *vfsInfo);
static UInt16 VFSCountApps(VFSInfo *vfsInfo);
static void VFSGetDatabaseList(McPhlingAppList **pMcAppList, VFSInfo *vfsInfo,
                               UInt16 first);


///////////////
// Functions //
///////////////

Boolean PrefsHandler(EventPtr event)
{
   // This is the code that will be called whenever the user taps this 
   // hack's "+" button in the HackMaster list. HackMaster is not smart about
   // the content of this file; it will simply jump to the first executable
   // statement in this file. If you need helper functions, prototype them
   // above, and define them AFTER the trap patch.

   FormPtr pForm = FrmGetActiveForm();
   Boolean handled = true;
   UInt32 emptyCreator;
   McPhlingAppList *pAppList;
   MemHandle hNumItems;
   RectangleType *pOldWinRect = NULL;
   UInt32 version;

   switch(event->eType) {
      case frmOpenEvent:
         hNumItems = MemHandleNew(NUM_CHARS_NUM_ITEMS);
         FtrSet(APP_ID, FTR_FIELDNUMITEMS, (UInt32)hNumItems);
         PrefsInit(pForm);
         FrmDrawForm(pForm);
         UpdateForm(pForm);
         break;
      
      case displayExtentChangedEvent:
         SizeForm(pForm);
         break;

      case frmUpdateEvent:
         FrmDrawForm(pForm);
         UpdateForm(pForm);
         break;

      case ctlSelectEvent:
         switch(event->data.ctlEnter.controlID) {
            case PrefsVFSSupport:
               if(CtlGetValue(Id2Ptr(PrefsVFSSupport)))
                  FrmAlert(VFSAlert);
               UpdateDatabaseList(pForm);
               FrmDrawForm(pForm);
               break;

            case PrefsRegistrationButton:
               DisplayRegistrationForm(RegistrationForm);
               break;

            case PrefsCacheButton:
               if(!FrmAlert(CacheAlert))
                  PrefSetAppPreferences(APP_ID, REFPREFS, 0, &emptyCreator,
                                        0, true);
               break;

            case PrefsOKButton:
               PrefsOK(pForm);
               FrmGotoForm(9000);  // return to HackMaster control panel
               break;

            case PrefsCancelButton:
               FrmGotoForm(9000);  // return to HackMaster control panel
               break;
         }
         handled = false;
         break;

      case ctlRepeatEvent:
         pForm = FrmGetActiveForm();
         switch(event->data.ctlEnter.controlID) {
            case PrefsNumItemsUp:
               ChangeNumItems(pForm, pageUpChr);
               break;

            case PrefsNumItemsDown:
               ChangeNumItems(pForm, pageDownChr);
               break;

            default:
               handled = false;
               break;
         }
         handled = false;
         break;

/*
      case sysNotifyVolumeMountedEvent:
      case sysNotifyVolumeUnmountedEvent:
         PrefsOK();
         FrmGotoForm(9000);  // return to HackMaster control panel
         break;
*/

      case lstSelectEvent:
         DoListSelect(event->data.lstSelect.selection);
         break;

      case keyDownEvent:
         switch(event->data.keyDown.chr) {
            case pageUpChr:
               ScrollList(pForm, winUp);
               break;

            case pageDownChr:
               ScrollList(pForm, winDown);
               break;

            case chrCarriageReturn:
               PrefsOK(pForm);
               FrmGotoForm(9000);  // return to HackMaster control panel
               break;

         }
         handled = false;
         break;
      
      case fldEnterEvent:
         // prevent fields from being entered
         break;

      case frmCloseEvent:
         FrmEraseForm(pForm);
         FrmDeleteForm(pForm);

         if(FtrGet(APP_ID, FTR_PAPPLIST, (UInt32 *)&pAppList) == 0)
            if(pAppList != NULL)
               MemPtrFree(pAppList);
         FtrUnregister(APP_ID, FTR_PAPPLIST);
         FtrUnregister(APP_ID, FTR_APPCOUNT);
         FtrUnregister(APP_ID, FTR_NEWNUMITEMS);
         if(FtrGet(APP_ID, FTR_OLDWINRECT, (UInt32 *)&pOldWinRect) == 0)
            MemPtrFree(pOldWinRect);
         FtrUnregister(APP_ID, FTR_OLDWINRECT);
         if(_TRGVGAFeaturePresent(&version)) {
            UInt32 temp;
            VgaScreenModeType screenMode = screenMode1To1;
            VgaRotateModeType rotateMode = rotateModeNone;

            if(FtrGet(APP_ID, FTR_VGASCREENMODE, &temp) == 0)
               screenMode = (VgaScreenModeType)temp;
            FtrUnregister(APP_ID, FTR_VGASCREENMODE);

            if(FtrGet(APP_ID, FTR_VGAROTATEMODE, &temp) == 0)
               rotateMode = (VgaRotateModeType)temp;
            FtrUnregister(APP_ID, FTR_VGAROTATEMODE);

            VgaSetScreenMode(screenMode, rotateMode);
         }

         /* not needed since hNumItems is automatically freed
         if(FtrGet(APP_ID, FTR_FIELDNUMITEMS, (UInt32 *)&hNumItems) == 0)
            MemHandleFree(hNumItems);
         */
         break;

      default:
         handled = false;
         break;
   }
   
   return handled;
}


static void PrefsInit(FormPtr pForm)
{
   McPhlingAppList *pAppList = NULL;
   UInt16 appCount;
   ListPtr pList;
   UInt16 i, j;
   UInt16 ignPrefsSize, favPrefsSize, ignNumApps;
   UInt32 *ignoredApps;
   Int16 prefResult;
   McPhlingPrefs mpPrefs;
   JumpRefPref favApps[MAX_NUM_ITEMS + 1];
   UInt32 version;
   Boolean bVgaExists = false;
   Err error;
   FormPtr pNewForm = NULL;
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   Boolean bGotDatabaseList;

   if(_TRGVGAFeaturePresent(&version)) {
      RectangleType *pOldWinRect = NULL;

      bVgaExists = true;

      VgaGetScreenMode(&screenMode, &rotateMode);
      FtrSet(APP_ID, FTR_VGASCREENMODE, (UInt32)screenMode);
      FtrSet(APP_ID, FTR_VGAROTATEMODE, (UInt32)rotateMode);

      VgaSetScreenMode(screenMode1To1, rotateModeNone);
      VgaFormModify(pForm, vgaFormModify160To240);

      pOldWinRect = MemPtrNew(sizeof(RectangleType));
      if(pOldWinRect) {
         pOldWinRect->topLeft.x = 2;
         pOldWinRect->topLeft.y = 2;
         pOldWinRect->extent.x  = 236;
         pOldWinRect->extent.y  = 236;
         FtrSet(APP_ID, FTR_OLDWINRECT, (UInt32)pOldWinRect);
      }
      SizeForm(pForm); // size the form for the HandEra 330
   }

   // get PERFSPREFS and set checkboxes
   GetPrefsAndNewIgnored(&mpPrefs);
   CtlSetValue(Id2Ptr(PrefsShowIcons),      mpPrefs.bShowIcons);
   CtlSetValue(Id2Ptr(PrefsClick),          mpPrefs.bClick);
   CtlSetValue(Id2Ptr(PrefsShowCurrentApp), mpPrefs.bShowCurrentApp);

   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version);
   if(error == errNone) {
      FrmShowObject(pForm,
                    FrmGetObjectIndex(pForm, PrefsVFSSupport));
      CtlSetValue(Id2Ptr(PrefsVFSSupport), mpPrefs.bVFSSupport);
   }

   // set sort type
   LstSetSelection(Id2Ptr(PrefsListSort), mpPrefs.sortType);
   CtlSetLabel(Id2Ptr(PrefsPopupTriggerSort),
               LstGetSelectionText(Id2Ptr(PrefsListSort), mpPrefs.sortType));
   
   // put up "Please wait" form
   DisplayWaitForm(bVgaExists, &screenMode, &rotateMode, &pNewForm);

   // Get the favorites
   GetMRUApps(&mpPrefs, favApps);

   // adjust numItems due to show current app
   if(mpPrefs.bShowCurrentApp)
      mpPrefs.numItems++;

   // set number of items
   FtrSet(APP_ID, FTR_NEWNUMITEMS, (UInt32)mpPrefs.numItems);

   // Get the excluded app list
   ignoredApps  = 0;
   ignPrefsSize = 0;
   favPrefsSize = 0;
   prefResult = PrefGetAppPreferences(APP_ID, IGNOREPREFS, NULL, &ignPrefsSize,
                                      true);
   if((prefResult == noPreferenceFound) || (ignPrefsSize == 0)) {
      ignNumApps = 0;
   }
   else {
      ignNumApps = ignPrefsSize / sizeof(UInt32);
      ignoredApps = MemPtrNew(ignPrefsSize);
      if(ignoredApps) {
         MemSet(ignoredApps, ignPrefsSize, 0);
         prefResult = PrefGetAppPreferences(APP_ID, IGNOREPREFS, ignoredApps,
                                            &ignPrefsSize, true);
         if((prefResult == noPreferenceFound) || (ignPrefsSize == 0)) {
               ignNumApps = 0;
               MemPtrFree(ignoredApps);
               ignoredApps = 0;
         }
      }
      else {
         ignoredApps = 0;
         ignNumApps = 0;
      }
   }

   // Get every stinking little application
   bGotDatabaseList = CreateDatabaseList(mpPrefs.bVFSSupport, &appCount,
                                         &pAppList);

   // remove "Please wait" form
   RemoveWaitForm(bVgaExists, screenMode, rotateMode, pNewForm, pForm);

   // fill database list
   if(bGotDatabaseList) {
      // Publish the database list handle
      FtrSet(APP_ID, FTR_PAPPLIST, (UInt32)pAppList);
      FtrSet(APP_ID, FTR_APPCOUNT, (UInt32)appCount);
      // Cheat and use version to signify an excluded application
      for(i = 0; i < appCount; i++) {
         for(j = 0; j < ignNumApps; j++) {
            if(pAppList[i].creator == ignoredApps[j]) {
               pAppList[i].flags |= IS_IGNORED;
            }
         }
         for(j = 0; j <= mpPrefs.numItems; j++) {
            if(pAppList[i].creator == favApps[j].creator) {
               if(favApps[j].flags & IS_A_FAV) {
                  pAppList[i].flags |= IS_A_FAV;
               }
            }
         }
      }

      pList = FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, AppList));
      LstSetListChoices(pList, NULL, appCount);
      LstSetDrawFunction(pList, (ListDrawDataFuncPtr)PrefsListDrawFunc);
      LstSetSelection(pList, -1);
   }
   else {
      FtrUnregister(APP_ID, FTR_PAPPLIST);
      FtrUnregister(APP_ID, FTR_APPCOUNT);
   }

   // Set list width for sort list
   LstSetBestWidth(PrefsListSort);

   // Cleanup
   if(ignoredApps)
      MemPtrFree(ignoredApps);
}


static void PrefsOK(FormPtr pForm)
{
   McPhlingAppList *pAppList;
   UInt32 appCount;
   UInt16 i, j, k, m;
   UInt32 *ignoredApps;
   UInt32 emptyCreator;
   McPhlingPrefs mpPrefs;
   UInt32 NewNumItems32;
   JumpRefPref favApps[MAX_NUM_ITEMS + 1];
   UInt8 maxFavorites;
   FormPtr pNewForm = NULL;
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   UInt32 version;
   Boolean bVgaExists = false;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&version))
      bVgaExists = true;

   // Get the applist
   if(FtrGet(APP_ID, FTR_PAPPLIST, (UInt32 *)&pAppList))
      return;
   if(FtrGet(APP_ID, FTR_APPCOUNT, &appCount))
      return;
   if(FtrGet(APP_ID, FTR_NEWNUMITEMS, &NewNumItems32))
      return;

   // get the preferences
   GetPrefsAndNewIgnored(&mpPrefs);
   
   // Get the cache list
   GetMRUApps(&mpPrefs, favApps);

   // set the preferences
   mpPrefs.numItems        = (UInt8)NewNumItems32;
   mpPrefs.bShowIcons      = CtlGetValue(Id2Ptr(PrefsShowIcons));
   mpPrefs.bClick          = CtlGetValue(Id2Ptr(PrefsClick));
   mpPrefs.bShowCurrentApp = CtlGetValue(Id2Ptr(PrefsShowCurrentApp));
   mpPrefs.bVFSSupport     = CtlGetValue(Id2Ptr(PrefsVFSSupport));
   mpPrefs.sortType        = LstGetSelection(Id2Ptr(PrefsListSort));

   // put up "Please wait" form
   DisplayWaitForm(bVgaExists, &screenMode, &rotateMode, &pNewForm);

   // adjust numItems due to show current app
   if(mpPrefs.bShowCurrentApp)
      mpPrefs.numItems--;

   // Set the ignored apps
   j = 0;
   ignoredApps = 0;
   for(i = 0; i < appCount; i++) {
      if(pAppList[i].flags & IS_IGNORED) {
         j++; // Just counting...
      }
   }
   if(!j) { // Nothing to do...
      emptyCreator = 0;
      PrefSetAppPreferences(APP_ID, IGNOREPREFS, 0, &emptyCreator, 0, true);
   }
   else {
      ignoredApps = MemPtrNew(j * sizeof(UInt32));
      if(ignoredApps) {
         MemSet(ignoredApps, j * sizeof(UInt32), 0);
         j = 0;
         for(i = 0; i < appCount; i++) {
            if(pAppList[i].flags & IS_IGNORED) {
               ignoredApps[j] = pAppList[i].creator;
               for(k = 0; k <= mpPrefs.numItems; k++) {
                  if((favApps[k].creator) &&
                     (favApps[k].creator == ignoredApps[j])) {
                        // Remove from cache list
                        for(m = k + 1; m <= mpPrefs.numItems; m++) {
                           favApps[m - 1] = favApps[m];
                        }
                        MemSet(&favApps[mpPrefs.numItems],
                               sizeof(JumpRefPref), 0);
                  }
               }
               j++;
            }
         }
      }
      else {
         FrmCustomAlert(OutOfMemory, "1", NULL, NULL);
      }
      PrefSetAppPreferences(APP_ID, IGNOREPREFS, 0, ignoredApps,
                            j * sizeof(UInt32), true);
   }

   // Set the favorites
   for(k = 0; k <= mpPrefs.numItems; k++) {
      favApps[k].flags = 0;  // clear all
   }
   maxFavorites = mpPrefs.numItems + (mpPrefs.bShowCurrentApp ? 1U : 0U);
   for(i = 0; i < appCount; i++) {
      if(pAppList[i].flags & IS_A_FAV) {
         AddFavorite(pAppList[i].creator, &favApps[0], &mpPrefs);
      }
   }
   PrefSetAppPreferences(APP_ID, REFPREFS, 0, favApps,
                         (mpPrefs.numItems + 1) * sizeof(JumpRefPref), true);

   // save the preferences
   PrefSetAppPreferences(APP_ID, PREFS, 0, &mpPrefs, sizeof(McPhlingPrefs),
                         true);
   
   // create application cache
   CreateAppCache(mpPrefs.bShowIcons, mpPrefs.bVFSSupport, favApps,
                  mpPrefs.numItems + 1, pAppList, appCount);

   // Cleanup
   if(ignoredApps)
      MemPtrFree(ignoredApps);

   // remove "Please wait" form
   RemoveWaitForm(bVgaExists, screenMode, rotateMode, pNewForm, pForm);
}


static void AddFavorite(UInt32 creator, JumpRefPref* favApps,
                        McPhlingPrefs *pMpPrefs)
{
   Int16 i, k;
   Boolean gotIt = false;
   UInt8 numItems = pMpPrefs->numItems;

   k = 0;
   for(i = 0; i <= numItems; i++) {
      // favorite get first vacant slot or slot with its creator ID
      if((!favApps[i].creator) || (favApps[i].creator == creator)) {
         k = i;
         gotIt = true;
         break;
      }
   }

   if(!gotIt) {
      for(i = numItems; i >= 0; i--) {
         if(!(favApps[i].flags & IS_A_FAV)) {
            k = i;
            gotIt = true;
            break;
         }
      }
   }


   if(gotIt) {
      favApps[k].creator = creator;
      favApps[k].flags   = IS_A_FAV;
   }
}


static void PrefsListDrawFunc(UInt16 index, RectanglePtr bounds,
                              Char **data __attribute__ ((unused)))
{
   McPhlingAppList *pAppList;
   MemHandle symbolH;
   DmResID symbol;
   UInt32 version;
   Boolean bVgaExists = false;
   Coord textOffset;
   FontID font = stdFont;
   FontID oldFont;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&version))
      bVgaExists = true;

   // Get the applist
   if(FtrGet(APP_ID, FTR_PAPPLIST, (UInt32*)&pAppList)) {
      // WinDrawChars("Error", 5, bounds->topLeft.x, bounds->topLeft.y);
      return;
   }

   // Draw the application name
   symbol = 0;
   if(pAppList[index].flags & IS_IGNORED)
      symbol = IgnoreBitmap;
   if(pAppList[index].flags & IS_A_FAV)
      symbol = FavoriteBitmap;
   if(symbol) {
      symbolH = DmGetResource(bitmapRsc, symbol + (bVgaExists ? 0x1000 : 0));
      WinDrawBitmap((BitmapPtr)MemHandleLock(symbolH), bounds->topLeft.x - 2,
                    bounds->topLeft.y + 1);
      MemHandleUnlock(symbolH);
      DmReleaseResource(symbolH);
   }
   textOffset = (bVgaExists ? 22 : 13);

   if(bVgaExists)
      font = VgaBaseToVgaFont(font);
   oldFont = FntSetFont(font);

   TruncateString(pAppList[index].name, bounds->extent.x - textOffset - 1);
   TruncateString(pAppList[index].name, bounds->extent.x - textOffset - 1);
   if(pAppList[index].flags & IS_A_VFS) {
      WinSetUnderlineMode(grayUnderline);
      WinDrawChars(pAppList[index].name, StrLen(pAppList[index].name),
                   bounds->topLeft.x + textOffset, bounds->topLeft.y);
      WinSetUnderlineMode(noUnderline);
   }
   else {
      WinDrawChars(pAppList[index].name, StrLen(pAppList[index].name),
                   bounds->topLeft.x + textOffset, bounds->topLeft.y);
   }

   FntSetFont(oldFont);
}


static void DoListSelect(Int16 selection)
{
   FormPtr pForm;
   ListPtr pList;
   McPhlingAppList *pAppList;
   UInt8 NewNumItems, i, numFavorites = 0;
   UInt32 NewNumItems32, appCount;
   Boolean bTooManyFavorites = false;
   UInt16 flags;

   if(selection < 0)
      return;
   if(FtrGet(APP_ID, FTR_PAPPLIST, (UInt32*)&pAppList))
      return;
   if(FtrGet(APP_ID, FTR_APPCOUNT, &appCount))
      return;
   if(FtrGet(APP_ID, FTR_NEWNUMITEMS, &NewNumItems32))
      return;
   NewNumItems = (UInt8)NewNumItems32;

   flags = pAppList[selection].flags;

   if((flags & (IS_A_VFS ^ 0xFFFF)) == 0) {
      pAppList[selection].flags = (flags & IS_A_VFS) | IS_IGNORED;
   }
   else if(flags & IS_IGNORED) {
      for(i = 0; i < appCount; i++) {
         if(pAppList[i].flags & IS_A_FAV) {
            numFavorites++;
         }
      }
      if(numFavorites >= NewNumItems) {
         pAppList[selection].flags &= IS_A_VFS;
         bTooManyFavorites = true;
      }
      else {
         pAppList[selection].flags = (flags & IS_A_VFS) | IS_A_FAV;
      }
   }
   else {
      pAppList[selection].flags &= IS_A_VFS;
   }

   pForm = FrmGetActiveForm();
   pList = FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, AppList));
   LstEraseList(pList);
   LstSetSelection(pList, -1);
   LstDrawList(pList);

   if(bTooManyFavorites) {
      Char sTooManyFavs[4];

      FrmCustomAlert(TooManyFavorites, StrIToA(sTooManyFavs, NewNumItems),
                     NULL, NULL);
   }
}


static void ScrollList(FormPtr pForm, WinDirectionType direction)
{
   ListPtr pList = FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, AppList));

   LstScrollList(pList, direction, LstGetVisibleItems(pList) - 1);
}


static void ChangeNumItems(FormPtr pForm, UInt16 keyDown)
{
   UInt8 NewNumItems;
   UInt32 NewNumItems32;

   FtrGet(APP_ID, FTR_NEWNUMITEMS, &NewNumItems32);
   NewNumItems = (UInt8)NewNumItems32;

   switch(keyDown) {
      case pageUpChr:
         if(NewNumItems < MAX_NUM_ITEMS)
            NewNumItems++;
         break;

      case pageDownChr:
         if(NewNumItems > MIN_NUM_ITEMS)
            NewNumItems--;
         break;
   }

   FtrSet(APP_ID, FTR_NEWNUMITEMS, (UInt32)NewNumItems);
   UpdateForm(pForm);
}


static void UpdateForm(FormPtr pForm)
{
   UInt16 wUp      = FrmGetObjectIndex(pForm, PrefsNumItemsUp);
   UInt16 wDown    = FrmGetObjectIndex(pForm, PrefsNumItemsDown);
   Char sNumber[NUM_CHARS_NUM_ITEMS];
   UInt32 NewNumItems32;
   MemHandle hNumItems;

   FtrGet(APP_ID, FTR_NEWNUMITEMS, &NewNumItems32);
   FtrGet(APP_ID, FTR_FIELDNUMITEMS, (UInt32 *)&hNumItems);

   // update num items field
   StrIToA(sNumber, NewNumItems32);
   DisplayString(sNumber, hNumItems, PrefsFieldNumItems, true);

   FrmUpdateScrollers(pForm, wUp, wDown, NewNumItems32 < MAX_NUM_ITEMS,
                      NewNumItems32 > MIN_NUM_ITEMS);
}


static void TruncateString(Char *pStr, Int16 width)
{
   Int16 strLength = StrLen(pStr);
   Int16 strWidth = width;
   Boolean truncated;
   Char ChrEllipsis;

   // Get the max number of chars that can be displayed
   FntCharsInWidth(pStr, &strWidth, &strLength, &truncated);

   // Truncate the title and add trailing ellipsis.
   ChrHorizEllipsis(&ChrEllipsis);
   if(strLength < StrLen(pStr)) {
      pStr[strLength - 1] = ChrEllipsis; // ellipsis
      pStr[strLength]     = '\0'; // truncate
   }
}


static void SizeForm(FormPtr pForm)
{
   RectangleType winRect;
   Coord xDiff, yDiff;
   Boolean bDraw;
   UInt32 version;
   Boolean bVgaExists = false;
   RectangleType *pOldWinRect = NULL;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&version))
      bVgaExists = true;
   else
      return;

   if(FtrGet(APP_ID, FTR_OLDWINRECT, (UInt32 *)&pOldWinRect) != 0)
      return;

   bDraw = FrmVisible(pForm);

   // set new window bounds
   winRect.topLeft.x = pOldWinRect->topLeft.x;
   winRect.topLeft.y = pOldWinRect->topLeft.y;
   WinGetDisplayExtent(&winRect.extent.x, &winRect.extent.y);
   winRect.extent.x -= winRect.topLeft.x * 2;
   winRect.extent.y -= winRect.topLeft.y * 2;
   xDiff = winRect.extent.x - pOldWinRect->extent.x;
   yDiff = winRect.extent.y - pOldWinRect->extent.y;
   *pOldWinRect = winRect;

   WinSetWindowBounds(FrmGetWindowHandle(pForm), &winRect);

   ResizeObject(pForm, FrmGetObjectIndex(pForm, AppList),
                0, 0, 0, yDiff, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsLabelSort),
                0, yDiff, 0, 0, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsPopupTriggerSort),
                0, yDiff, 0, 0, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsListSort),
                0, yDiff, 0, 0, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsOKButton),
                0, yDiff, 0, 0, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsCancelButton),
                0, yDiff, 0, 0, false);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, PrefsCacheButton),
                0, yDiff, 0, 0, false);

   if(bDraw) {
      ListPtr pList = FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, AppList));
      Int16 pos = LstGlueGetTopItem(pList);
      Int16 numVisible = LstGetVisibleItems(pList);
      Int16 numItems = LstGetNumberOfItems(pList);

      // adjust position of application list
      if(pos + numVisible >= numItems)
         pos = numItems - numVisible;

      if(pos < 0)
         pos = 0;
      
      LstSetTopItem(pList, pos);

      // draw the form
      FrmDrawForm(pForm);
   }
}


static void ResizeObject(FormPtr pForm, UInt16 objectIndex,
                         Coord xMove, Coord yMove,
                         Coord xExp, Coord yExp, Boolean bDraw)
{
   RectangleType r;
    
   if((xMove == 0) && (yMove == 0) && (xExp == 0) && (yExp == 0))
      return;
    
   FrmGetObjectBounds(pForm, objectIndex, &r);
   if(bDraw)
      FrmHideObject(pForm, objectIndex);
   r.topLeft.x += xMove;
   r.topLeft.y += yMove;
   r.extent.x  += xExp;
   r.extent.y  += yExp;
   FrmSetObjectBounds(pForm, objectIndex, &r);
    
   if(FrmGetObjectType(pForm, objectIndex) == frmGraffitiStateObj)
      GsiSetLocation(r.topLeft.x, r.topLeft.y);
    
   if(bDraw)
      FrmShowObject(pForm, objectIndex);
}


static void DisplayString(Char *str, MemHandle hField, UInt16 fieldID,
                          Boolean bRefresh)
{
   FieldPtr pField = Id2Ptr(fieldID);

   StrCopy(MemHandleLock(hField), str);
   MemHandleUnlock(hField);
   FldSetTextHandle(pField, hField);

   if(bRefresh)
      FldDrawField(pField);
}


static void LstSetBestWidth(UInt16 listID)
{
   Int16 i;
   FormPtr pForm = FrmGetActiveForm();
   ListType *pList = Id2Ptr(listID);
   Int16 numItems = LstGetNumberOfItems(pList);
   UInt16 listIndex = FrmGetObjectIndex(pForm, listID);
   UInt16 width, maxWidth = 0;
   RectangleType listBounds;
   FontID oldFont, myStdFont;
   UInt32 version;
   Boolean bVgaExists = false;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&version))
      bVgaExists = true;

   if(bVgaExists)
      myStdFont = VgaBaseToVgaFont(stdFont);
   else
      myStdFont = stdFont;
   oldFont = FntSetFont(myStdFont);

   for(i = 0; i < numItems; i++) {
      width = StrLen(LstGetSelectionText(pList, i));
      width = FntCharsWidth(LstGetSelectionText(pList, i), width);
      if(width > maxWidth)
          maxWidth = width;
   }

   FrmGetObjectBounds(pForm, listIndex, &listBounds);
   listBounds.extent.x = maxWidth + LIST_PADDING;
   FrmSetObjectBounds(pForm, listIndex, &listBounds);

   FntSetFont(oldFont);
}


static void CreateAppCache(Boolean bShowIcons, Boolean bVFSSupport,
                           JumpRefPref *pAppList, UInt8 numItems,
                           McPhlingAppList *pMcAppList, UInt16 appCount)
{
   UInt16 cardNo = 0;
   UInt16 i, j;
   LocalID dbID;
   DmOpenRef dbCache = NULL;
   MemHandle hIcon, hIcon2, hIconName, hVersion, hVFSPath;
   BitmapPtr pIcon, pIcon2;
   UInt32 iconHandleSize;
   Char *pIconName, *pVersion, *pVFSPath;

   // delete cache
   dbID = DmFindDatabase(cardNo, DB_NAME_CACHE);
   if(dbID)
      DmDeleteDatabase(cardNo, dbID);

   // create new cache
   if(DmCreateDatabase(0, DB_NAME_CACHE, APP_ID, DB_TYPE_CACHE, true) == 0)
      dbCache = DmOpenDatabaseByTypeCreator(DB_TYPE_CACHE, APP_ID,
                                            dmModeReadWrite);

   if(dbCache == NULL)
      return;

   // put version into resource
   hVersion = DmNewResource(dbCache, verRsc, appVersionID, DB_VER_LEN_CACHE);
   if(hVersion) {
      pVersion = MemHandleLock(hVersion);
      if(pVersion) {
         DmWrite(pVersion, 0, DB_VER_CACHE, DB_VER_LEN_CACHE);
         MemHandleUnlock(hVersion);
      }
      DmReleaseResource(hVersion);
   }

   // put in icons and names
   for(i = 0; i < numItems; i++) {
      Err err;
      UInt32 creator = pAppList[i].creator;
      DmOpenRef dbApp;

      // skip if no creator
      if(creator == NULL)
         continue;

      dbApp = DmOpenDatabaseByTypeCreator(sysFileTApplication, creator,
                                          dmModeReadOnly);
      if(dbApp) {
         err = DmOpenDatabaseInfo(dbApp, &dbID, NULL, NULL, &cardNo, NULL);
      
         if(err == errNone) {
            if(bShowIcons) {
               // get small icon
               hIcon = DmGet1Resource(iconType, SMALL_ICON);
               if(hIcon) {
                  pIcon = MemHandleLock(hIcon);
                  iconHandleSize = MemHandleSize(hIcon);

                  hIcon2 = DmNewResource(dbCache, creator, SMALL_ICON,
                                         iconHandleSize);
                  pIcon2 = MemHandleLock(hIcon2);
                  DmWrite(pIcon2, 0, pIcon, iconHandleSize);

                  // clean up
                  MemHandleUnlock(hIcon);
                  MemHandleUnlock(hIcon2);
                  DmReleaseResource(hIcon);
                  DmReleaseResource(hIcon2);
               }

               // get medium icon
               hIcon = DmGet1Resource(iconType, MEDIUM_ICON);
               if(hIcon) {
                  pIcon = MemHandleLock(hIcon);
                  iconHandleSize = MemHandleSize(hIcon);
         
                  hIcon2 = DmNewResource(dbCache, creator, MEDIUM_ICON,
                                         iconHandleSize);
                  pIcon2 = MemHandleLock(hIcon2);
                  DmWrite(pIcon2, 0, pIcon, iconHandleSize);

                  // clean up
                  MemHandleUnlock(hIcon);
                  MemHandleUnlock(hIcon2);
                  DmReleaseResource(hIcon);
                  DmReleaseResource(hIcon2);
               }
            }

            // get icon name
            hIconName = DmNewResource(dbCache, creator, ICON_NAME,
                                      dmDBNameLength + 1);
            pIconName = MemHandleLock(hIconName);
            for(j = 0; j < appCount; j++) {
               if(pMcAppList[j].creator == creator) {
                  DmWrite(pIconName, 0, pMcAppList[j].name, dmDBNameLength + 1);
                  break;
               }
            }

            // clean up
            MemHandleUnlock(hIconName);
            DmReleaseResource(hIconName);
         }
         DmCloseDatabase(dbApp);
      }
      else if(bVFSSupport) {
         UInt32 type;
         UInt32 localCreator;

         for(j = 0; j < appCount; j++) {
            // assuming a VFS at this point
            if(pMcAppList[j].creator == creator) {
               FileRef fileRef;
               Err err;

               VFSFileOpen(pMcAppList[j].vfsVolRefNum, pMcAppList[j].vfsPath,
                           vfsModeRead, &fileRef);
               err = VFSFileDBInfo(fileRef, NULL, NULL, NULL, NULL, NULL,
                                   NULL, NULL, NULL, NULL, &type,
                                   &localCreator, NULL);
               if(err == errNone && type == sysFileTApplication &&
                     localCreator == creator) {

                  if(bShowIcons) {
                     // get small icon
                     err = VFSFileDBGetResource(fileRef, iconType, SMALL_ICON,
                                                &hIcon);
                     if(hIcon) {
                        pIcon = MemHandleLock(hIcon);
                        iconHandleSize = MemHandleSize(hIcon);

                        hIcon2 = DmNewResource(dbCache, creator, SMALL_ICON,
                                               iconHandleSize);
                        pIcon2 = MemHandleLock(hIcon2);
                        DmWrite(pIcon2, 0, pIcon, iconHandleSize);

                        // clean up
                        MemHandleUnlock(hIcon);
                        MemHandleUnlock(hIcon2);
                        DmReleaseResource(hIcon);
                        DmReleaseResource(hIcon2);
                     }

                     // get medium icon
                     err = VFSFileDBGetResource(fileRef, iconType, MEDIUM_ICON,
                                                &hIcon);
                     if(hIcon) {
                        pIcon = MemHandleLock(hIcon);
                        iconHandleSize = MemHandleSize(hIcon);

                        hIcon2 = DmNewResource(dbCache, creator, MEDIUM_ICON,
                                               iconHandleSize);
                        pIcon2 = MemHandleLock(hIcon2);
                        DmWrite(pIcon2, 0, pIcon, iconHandleSize);

                        // clean up
                        MemHandleUnlock(hIcon);
                        MemHandleUnlock(hIcon2);
                        DmReleaseResource(hIcon);
                        DmReleaseResource(hIcon2);
                     }
                  }
               }

               // close the file
               VFSFileClose(fileRef);

               // get icon name
               hIconName = DmNewResource(dbCache, creator, ICON_NAME,
                                         dmDBNameLength + 1);
               pIconName = MemHandleLock(hIconName);
               DmWrite(pIconName, 0, pMcAppList[j].name, dmDBNameLength + 1);
               MemHandleUnlock(hIconName);
               DmReleaseResource(hIconName);

               break;
            }
         }
      }
   }

   // put in VFS paths
   if(bVFSSupport) {
      for(i = 0; i < appCount; i++) {
         UInt32 creator = pMcAppList[i].creator;

         // skip if no creator
         if(creator == NULL)
            continue;

         // skip if not VFS
         if((pMcAppList[i].flags & IS_A_VFS) == 0)
            continue;

         hVFSPath = DmNewResource(dbCache, creator, VFS_PATH, VFS_MAX_PATH + 1);
         pVFSPath = MemHandleLock(hVFSPath);
         DmWrite(pVFSPath, 0, pMcAppList[i].vfsPath, VFS_MAX_PATH + 1);

         // clean up
         MemHandleUnlock(hVFSPath);
         DmReleaseResource(hVFSPath);
      }
   }

   // close cache database
   DmCloseDatabase(dbCache);
}


static Boolean CreateDatabaseList(Boolean bVFSSupport, UInt16 *pAppCount,
                                  McPhlingAppList **pMcAppList)
{
   MemHandle hAppList;
   SysDBListItemType *pAppList;
   UInt16 i, j, k;
   VFSInfo vfsInfo;
   UInt16 ramAppCount = 0, vfsAppCount = 0, totalAppCount;

   // get applications that reside in ram
   SysCreateDataBaseList(sysFileTApplication, 0, &ramAppCount, &hAppList,
                         true);

   // count number of applications on external cards
   if(bVFSSupport) {
      VFSSetup(&vfsInfo);
      vfsAppCount = VFSCountApps(&vfsInfo);
   }

   // create total count and allocate memory for pMcAppList
   totalAppCount  = ramAppCount + vfsAppCount;
   *pMcAppList = MemPtrNew(totalAppCount * sizeof(McPhlingAppList));
   if(*pMcAppList == NULL) {
      FrmCustomAlert(OutOfMemory, "2", NULL, NULL);
      totalAppCount = 0;
      return (Boolean)totalAppCount;
   }

   // put application data from ram into pMcAppList
   pAppList = MemHandleLock(hAppList);
      
   for(i = 0; i < ramAppCount; i++) {
      StrCopy((*pMcAppList)[i].name, pAppList[i].name);
      (*pMcAppList)[i].creator = pAppList[i].creator;
      (*pMcAppList)[i].flags = 0;
   }

   MemHandleUnlock(hAppList);
   MemHandleFree(hAppList);

   if(bVFSSupport) {
      // put application data from cards into pMcAppList
      VFSGetDatabaseList(pMcAppList, &vfsInfo, ramAppCount);

      // Remove VFS applications from list that resize in RAM
      for(i = totalAppCount - 1; i >= ramAppCount; i--) {
         UInt32 creator = (*pMcAppList)[i].creator;

         for(j = 0; j < ramAppCount; j++) {
            // check if duplicate and remove
            if((*pMcAppList)[j].creator == creator) {
               for(k = i + 1; k < totalAppCount; k++)
                  (*pMcAppList)[i]  = (*pMcAppList)[k];
               totalAppCount--;
            }
         }
      }

      // sort pMcAppList
      SysInsertionSort(*pMcAppList, totalAppCount, sizeof(McPhlingAppList),
                       (CmpFuncPtr)DatabaseSortAlpha, 0);
   }

   // set pAppCount
   *pAppCount = totalAppCount;

   // got it all
   return (Boolean)totalAppCount;
}


static void UpdateDatabaseList(FormPtr pForm)
{
   UInt16 i, j, ignoredCount, favoriteCount;
   FormPtr pNewForm = NULL;
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   Boolean bGotDatabaseList;
   Boolean bVFSSupport = CtlGetValue(Id2Ptr(PrefsVFSSupport));
   UInt32 temp;
   Boolean bVgaExists = false;
   McPhlingAppList *pAppList;
   UInt16 appCount;
   UInt32 *ignoredApps  = NULL;
   UInt32 *favoriteApps = NULL;
   ListPtr pList;

   // see if VGA screen exists
   if(_TRGVGAFeaturePresent(&temp))
      bVgaExists = true;

   // put up "Please wait" form
   DisplayWaitForm(bVgaExists, &screenMode, &rotateMode, &pNewForm);

   // Get the applist and appcount
   if(FtrGet(APP_ID, FTR_PAPPLIST, (UInt32 *)&pAppList))
      return;
   if(FtrGet(APP_ID, FTR_APPCOUNT, &temp))
      return;
   appCount = (UInt16)temp;

   // get the ignored and favorite apps from the list
   ignoredCount  = 0;
   favoriteCount = 0;
   for(i = 0; i < appCount; i++) {
      if(pAppList[i].flags & IS_IGNORED) {
         ignoredCount++; // Just counting...
      }
      if(pAppList[i].flags & IS_A_FAV) {
         favoriteCount++; // Just counting...
      }
   }
   ignoredApps  = MemPtrNew(ignoredCount  * sizeof(UInt32));
   favoriteApps = MemPtrNew(favoriteCount * sizeof(UInt32));

   ignoredCount  = 0;
   favoriteCount = 0;
   for(i = 0; i < appCount; i++) {
      if(pAppList[i].flags & IS_IGNORED) {
         ignoredApps[ignoredCount] = pAppList[i].creator;
         ignoredCount++;
      }
      if(pAppList[i].flags & IS_A_FAV) {
         favoriteApps[favoriteCount] = pAppList[i].creator;
         favoriteCount++;
      }
   }

   // remove old features and free pAppList
   FtrUnregister(APP_ID, FTR_PAPPLIST);
   FtrUnregister(APP_ID, FTR_APPCOUNT);
   if(pAppList)
      MemPtrFree(pAppList);

   // Get every stinking little application
   bGotDatabaseList = CreateDatabaseList(bVFSSupport, &appCount, &pAppList);

   // remove "Please wait" form
   RemoveWaitForm(bVgaExists, screenMode, rotateMode, pNewForm, pForm);

   // fill database list
   if(bGotDatabaseList) {
      // Publish the database list handle
      FtrSet(APP_ID, FTR_PAPPLIST, (UInt32)pAppList);
      FtrSet(APP_ID, FTR_APPCOUNT, (UInt32)appCount);

      // Publish the database list handle
      FtrSet(APP_ID, FTR_PAPPLIST, (UInt32)pAppList);
      FtrSet(APP_ID, FTR_APPCOUNT, (UInt32)appCount);
      // Cheat and use version to signify an excluded application
      for(i = 0; i < appCount; i++) {
         for(j = 0; j < ignoredCount; j++) {
            if(pAppList[i].creator == ignoredApps[j]) {
               pAppList[i].flags |= IS_IGNORED;
            }
         }
         for(j = 0; j < favoriteCount; j++) {
            if(pAppList[i].creator == favoriteApps[j]) {
               pAppList[i].flags |= IS_A_FAV;
            }
         }
      }

      pList = FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, AppList));
      LstSetListChoices(pList, NULL, appCount);
      LstSetDrawFunction(pList, (ListDrawDataFuncPtr)PrefsListDrawFunc);
      LstSetTopItem(pList, 0);
   }
   else {
      FtrUnregister(APP_ID, FTR_PAPPLIST);
      FtrUnregister(APP_ID, FTR_APPCOUNT);
   }

   // clean up
   if(ignoredApps)
      MemPtrFree(ignoredApps);
   if(favoriteApps)
      MemPtrFree(favoriteApps);
}


static Int16 DatabaseSortAlpha(McPhlingAppList *a1, McPhlingAppList *a2,
                               Int32 unused __attribute__ ((unused)))
{
   return StrCaselessCompare(a1->name, a2->name);
}


/////////////////////////////////
// Registration Form Functions //
/////////////////////////////////

static void DisplayRegistrationForm(UInt16 rscID)
{
   FormPtr pForm = FrmGetActiveForm();
   FormPtr pNewForm = FrmInitForm(rscID);
   VgaScreenModeType screenMode;
   VgaRotateModeType rotateMode;
   UInt32 version;
   Boolean bVgaExists = false;

   // see if vga exists
   if(_TRGVGAFeaturePresent(&version))
      bVgaExists = true;

   if(bVgaExists) {
      VgaGetScreenMode(&screenMode, &rotateMode);
      VgaSetScreenMode(screenModeScaleToFit, rotateMode);
   }

   // show the about form
   FrmDoDialog(pNewForm);

   if(bVgaExists)
      VgaSetScreenMode(screenMode, rotateMode);

   FrmDeleteForm(pNewForm);
   FrmSetActiveForm(pForm);
}


///////////////////////
// VFS Specific Code //
///////////////////////

static void VFSSetup(VFSInfo *vfsInfo)
{
   Err error;
   UInt32 version;
   Int16 i;
   UInt16 volRefNum;
   UInt32 volIterator = vfsIteratorStart;
   UInt16 bufLen = VFS_MAX_PATH;

   // Assume no VFS Volumes available
   vfsInfo->numVFSVolumes = 0;

   // Check if VFS features are available
   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version);
   if(error)
      return;

   // get volume reference number
   for(i = 0; i < VFS_MAX_VOLUMES; i++) {
      error = VFSVolumeEnumerate(&volRefNum, &volIterator);
      if(!error) {
         vfsInfo->vfsVol[i].volRefNum = volRefNum;
         vfsInfo->numVFSVolumes++;
      }
   }

   // exit if no VFS volumes are available
   if(vfsInfo->numVFSVolumes == 0)
      return;

   // get default directory
   for(i = 0; i < vfsInfo->numVFSVolumes; i++) {
      VFSGetDefaultDirectory(vfsInfo->vfsVol[i].volRefNum, ".prc",
                             vfsInfo->vfsVol[i].path, &bufLen);
   }
}


static UInt16 VFSCountApps(VFSInfo *vfsInfo)
{
   Int16 i;
   UInt32 version;
   UInt16 vfsAppCount = 0;
   Err error;
   FileInfoType fileInfo;
   Char *fileName = NULL;
   Char *vfsPath = NULL;
   UInt32 dirIterator;
   FileRef dirRef;
   FileRef fileRef;
   UInt32 type;

   // Check if VFS features are available
   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version);
   if(error)
      return vfsAppCount;

   // setup file name and path memory
   fileName = MemPtrNew(sizeof(Char) * (VFS_MAX_PATH + 1));
   if(fileName == NULL)
      return vfsAppCount;

   vfsPath = MemPtrNew(sizeof(Char) * (VFS_MAX_PATH + 1));
   if(vfsPath == NULL) {
      MemPtrFree(fileName);
      return vfsAppCount;
   }

   // get names and icons
   for(i = 0; i < vfsInfo->numVFSVolumes; i++) {
      VFSFileOpen(vfsInfo->vfsVol[i].volRefNum, vfsInfo->vfsVol[i].path,
                  vfsModeRead, &dirRef);
      dirIterator = vfsIteratorStart;
      fileInfo.nameP = fileName; // point to local buffer
      fileInfo.nameBufLen = VFS_MAX_PATH;
      dirIterator = vfsIteratorStart;
      while(dirIterator != vfsIteratorStop) {
         // Get the next file
         error = VFSDirEntryEnumerate(dirRef, &dirIterator, &fileInfo);
         if(error == errNone) {
            // open the file
            StrCopy(vfsPath, vfsInfo->vfsVol[i].path);
            StrCat(vfsPath, fileInfo.nameP);
            error = VFSFileOpen(vfsInfo->vfsVol[i].volRefNum, vfsPath,
                                vfsModeRead, &fileRef);
            if(error == errNone) {
               // get icon name

               error = VFSFileDBInfo(fileRef, NULL, NULL, NULL, NULL, NULL,
                                     NULL, NULL, NULL, NULL, &type, NULL,
                                     NULL);
               if(error == errNone && type == sysFileTApplication) {
                  vfsAppCount++;
               }
            }

            // close the file
            VFSFileClose(fileRef);
         }
      }
      VFSFileClose(dirRef);
   }

   // clean up
   MemPtrFree(fileName);
   MemPtrFree(vfsPath);

   return vfsAppCount;
}


static void VFSGetDatabaseList(McPhlingAppList **pMcAppList, VFSInfo *vfsInfo,
                               UInt16 first)
{
   Int16 i;
   Err error;
   FileInfoType fileInfo;
   Char *fileName = NULL;
   UInt32 version;
   UInt32 dirIterator;
   FileRef dirRef;
   FileRef fileRef;
   UInt32 type;
   Char *pIconName;
   Char iconName[dmDBNameLength + 1];
   MemHandle hres = NULL;
   Char vfsPath[VFS_MAX_PATH + 1];
   UInt16 count = first;
   UInt32 localCreator;

   // Check if VFS features are available
   error = FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version);
   if(error)
      return;

   // setup file name memory
   fileName = MemPtrNew(sizeof(Char) * (VFS_MAX_PATH + 1));
   if(fileName == NULL)
      return;

   // get names and icons
   for(i = 0; i < vfsInfo->numVFSVolumes; i++) {
      VFSFileOpen(vfsInfo->vfsVol[i].volRefNum, vfsInfo->vfsVol[i].path,
                  vfsModeRead, &dirRef);
      dirIterator = vfsIteratorStart;
      fileInfo.nameP = fileName; // point to local buffer
      fileInfo.nameBufLen = VFS_MAX_PATH;
      dirIterator = vfsIteratorStart;
      while(dirIterator != vfsIteratorStop) {
         // Get the next file
         error = VFSDirEntryEnumerate(dirRef, &dirIterator, &fileInfo);
         if(error == errNone) {
            // open the file
            StrCopy(vfsPath, vfsInfo->vfsVol[i].path);
            StrCat(vfsPath, fileInfo.nameP);
            error = VFSFileOpen(vfsInfo->vfsVol[i].volRefNum, vfsPath,
                                vfsModeRead, &fileRef);
            if(error == errNone) {
               // get icon name
               error = VFSFileDBInfo(fileRef, iconName,
                                     NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                                     NULL, &type, &localCreator, NULL);
               if(error == errNone && type == sysFileTApplication) {
                  error = VFSFileDBGetResource(fileRef, ainRsc, ainID, &hres);
                  if(error == errNone) {
                     pIconName = (Char *)MemHandleLock(hres);
                     StrCopy((*pMcAppList)[count].name, pIconName);

                     MemHandleUnlock(hres);
                     DmReleaseResource(hres);
                  }
                  else {
                     StrCopy((*pMcAppList)[count].name, iconName);
                  }
                  (*pMcAppList)[count].creator      = localCreator;
                  (*pMcAppList)[count].flags        = IS_A_VFS;
                  (*pMcAppList)[count].vfsVolRefNum =
                     vfsInfo->vfsVol[i].volRefNum;
                  StrCopy((*pMcAppList)[count].vfsPath, vfsPath);
                  count++;
               }
            }

            // close the file
            VFSFileClose(fileRef);
         }
      }
      VFSFileClose(dirRef);
   }

   // clean up
   MemPtrFree(fileName);
}
