/*
****************************************************************
$Source: e:\\work\\Src\\Pilot\\uptime/RCS/uptime-hack_A2EA.c,v $
$Author: hmueller $
$Date: 1998/05/20 13:30:18 $
$Revision: 1.1 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Hack for Uptime

* Uptime-Hack
* Holger M�ller <hmueller@bigfoot.com> <hmueller@mail.freepage.de>
* http://software.freepage.de/hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-hack_A2EA.c,v $
* Revision 1.1  1998/05/20 13:30:18  hmueller
* Initial revision
*
* 
****************************************************************
*/
#pragma pack(2)

/* Pilot header files. */
#include <Pilot.h>

/* Local header files. */
#include "uptime.rid"			// ID's of all resources
#include "uptime-hack.h"		// def's for Uptime Hack
#include "GetHackPrefs.h"		// def. of function "GetHackPrefs()"


/*
===============================================================
Function : HwrBacklight
---------------------------------------------------------------
Purpose  : New Trap for "HwrBacklight" at 0xA2EA
		   Saves time of Pilot backlight on time and calls old
		   "HwrBacklight"
Call     : ret=HwrBacklight(Boolean set, Boolean newState);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
set              I  Boolean 
newState         I  Boolean 
ret              O  Boolean 
===============================================================
*/
Boolean HwrBacklightHack(Boolean set, Boolean newState) {
  Boolean (*oldtrap)(Boolean, Boolean);	// procedure pointer to old trap
  DWord pfnOldProc;				// for the feature manager call type checking
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars
  
  if (set) {					// set a new state?
	GetHackPrefs(&hackPrefs);
	if (newState) {				// switch backlight on
	  hackPrefs.PowerOnBacklightStart = TimGetSeconds();
	} else {					// switch backlight off
	  if (hackPrefs.State.Backlight != 0) { 
		hackPrefs.OnBacklightTime += TimGetSeconds() - hackPrefs.PowerOnBacklightStart;
	  }
	}
	hackPrefs.State.Backlight = newState;
	PrefSetAppPreferencesV10(HACKCREATORID, HACKPREFVER, &hackPrefs, sizeof(HackPrefs));
  }

  /* get old trap address from HackMaster and execute it */
  FtrGet(HACKCREATORID, hackID_A2EA, &pfnOldProc);
  oldtrap = (Boolean (*)(Boolean, Boolean))pfnOldProc; // set procedure pointer
  return oldtrap(set, newState);
} /* HwrBacklightHack */


#include "GetHackPrefs.c"		// function "GetHackPrefs()"
