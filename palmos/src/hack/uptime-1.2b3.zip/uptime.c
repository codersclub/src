/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime.c,v $
$Author: hmueller $
$Date: 1998/05/20 13:47:23 $
$Revision: 1.7 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Thanks to Gabe Dalbec <dalbec@usa.net> for providing me
          the source code of uptime 0.9

* Uptime 1.2b3
* Holger M�ller <hmueller@bigfoot.com> <hmueller@mail.freepage.de>
* http://software.freepage.de/hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime.c,v $
* Revision 1.7  1998/05/20 13:47:23  hmueller
* Beta test version 1.2b3
* - UI rewritten once more, now using a table instead of single lines for
* displaying time information
* - Uptime is now able to track the backlight on time, new menu entry
* - New function "drawTime()"
*
* Revision 1.6  1998/05/14 18:01:36  hmueller
* Beta test version 1.2b1
* - Completely rewritten UI, using more res. forms now (s. "drawForm()")
* - Functions "drawLine()" and "drawHeader()" removed
* - Battery kind now changeable via popuplist (s. "eventLook()")
* - New function "WinInvertLabel()"
*
* Revision 1.5  1998/05/07 12:48:47  hmueller
* - Removed beta state and switched to 1.1
* - Fixed problem with menu popup and MenuHack (s. function "eventLook")
*
* Revision 1.4  1998/04/26 16:38:56  hmueller
* - Changed to 1.1b2
* - Added code for detecting if hack it active or not
*
* Revision 1.3  1998/04/13 20:23:38  hmueller
* Beta test version 1.1b1 with new Uptime Hack
* - Changed pilot header files (now just needs "Pilot.h")
* - Moved StartApplication and StopApplication into "uptime-tools" with new names
* - Added function "drawHeader"
* - Completely changed function "drawForm" (output style, new information
* mainly provided by the hack)
* - Removed bugs in function "eventLook" in conjunction with menus
* (new screen update concept)
* - Added update of Hack preferences for battery reset in function "eventLook"
* - Added update of Hack preferences while resetting the pilot in "PilotMain"
*
* Revision 1.2  1998/04/03 00:59:41  hmueller
* - Added comments and function headers
* - Changed C-layout to my style using "indent"
* - Replaced hard coded ID's with defines (see uptime.h)
* - Modified Pref[GS]etAppPreferences to Pref[GS]etAppPreferencesV10
* for OS2 compiler headers
* - Added some code for "on_batt_time", but still not displayed because
* wrong time if Pilot gets reseted
* - Added function "VoltageToStr"
* - Modified parameter in "secondsToString"
* - Added battery information in "drawForm" and positions of output
* - Modified event handler in "eventLook" for menus
*
* Revision 1.1  1998/03/27 19:07:38  hmueller
* Initial revision - revision by Gabe Dalbec (Uptime 0.9)
* 
****************************************************************
*/

/* Pilot header files. */
#include <Pilot.h>

/* Local header files. */
#include "uptime.rid"			// ID's of all resources
#include "uptime.h"				// def's for Uptime
#include "uptime-hack.h"		// def's for Uptime Hack
#include "uptime-tools.h"		// tools for Uptime


/*
===============================================================
Function : VoltageToStr
---------------------------------------------------------------
Purpose  : Returns a formatted voltage text string, in the 
           format "?.??v"
Call     : VoltageToStr(VoltStr, Volt);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
Volt             I  UInt    voltage as a number of thousandths of a volt
VoltStr          O  Ptr     pointer to the text string containing
                            the formatted voltage
===============================================================
*/
void VoltageToStr(Ptr VoltStr, UInt Volt)
{
  char wrk[10];

  StrIToA(wrk, Volt / 100);
  StrCopy(VoltStr, wrk);
  StrCat(VoltStr, ".");
  StrIToA(wrk, (Volt / 10) % 10);
  StrCat(VoltStr, wrk);
  StrIToA(wrk, Volt % 10);
  StrCat(VoltStr, wrk);
  StrCat(VoltStr, "v");
} /* VoltageToStr */


/*
===============================================================
Function : secondsToString
---------------------------------------------------------------
Purpose  : Returns a formatted time string, in the format 
           "? days ??:??"
Call     : secondsToString(SecStr, seconds);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
seconds          I  ULong   time in seconds
SecStr           O  Ptr     pointer to the text string containing
                            the formatted time
===============================================================
*/
void secondsToString(Ptr SecStr, ULong seconds)
{
  ULong minutes;
  char days[6];
  char hours[3];
  char min[3];

  minutes = seconds / 60L;
  StrIToA(days, minutes / (60L * 24L));
  StrIToA(hours, (minutes / 60L) % 24);
  StrIToA(min, minutes % 60);
  StrCopy(SecStr, days);
  if (StrLen(days) > 2)
	StrCat(SecStr, " d ");
  else
	StrCat(SecStr, " days ");
  if (((minutes / 60L) % 24) < 10)
    StrCat(SecStr, "0");
  StrCat(SecStr, hours);
  StrCat(SecStr, ":");
  if ((minutes % 60) < 10)
    StrCat(SecStr, "0");
  StrCat(SecStr, min);
} /* secondsToString */


/*
===============================================================
Function : drawTime
---------------------------------------------------------------
Purpose  : Print the given time as "d days hh:mm"
Call     : drawTime(seconds, form, labelID);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
seconds          I  ULong   time to print in seconds
form             I  FormPtr Form pointer
labelID          I  Word    ID of label where to print time
===============================================================
*/
void drawTime(ULong seconds, FormPtr form, Word labelID)
{
  char msg[32];					// help string
  Int stringWidth;				// string width in pixel
  Int stringLength;				// string length in character
  Boolean fitWithinWidth;		// TRUE if the string is considered truncated

  secondsToString(msg, seconds);

  stringWidth = COL2 - COL1 - 3;
  stringLength = StrLen(msg);
  fitWithinWidth = false;
  FntCharsInWidth(msg, &stringWidth, &stringLength, &fitWithinWidth);

  if (StrLen(msg) > stringLength) {
	if (((COL2 - COL1 - 3) - stringWidth) < 3)
	  stringLength--;
	msg[stringLength] = '\0';
	StrCat(msg, "..");
  }
  FrmCopyLabel(form, labelID, msg);
} /* DrawTime */


/*
===============================================================
Function : drawForm
---------------------------------------------------------------
Purpose  : Print the variable part of the uptime form
Call     : drawForm(appPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
appPrefs         I  AppPrefs application preference block
===============================================================
*/
void drawForm(AppPrefs *appPrefs)
{
  char msg[32];					// help string
  ULong seconds;
  UInt voltage,					// vars for SysBatteryInfo()
    warnlev,
    critlev;
  SysBatteryKind btype;
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars
  DWord pfnOldProc;				// for the feature manager call type checking
  Err FtrRet;					// 0 if feature call ok (means Hack is inst.)
  FormPtr form;					// pointer to memory block that contains the active form
  Word idx_trig,				// item number of trigger object
	idx_list;					// item number of list object
  DWord NumBacklight;			// backlight system feature

  form = FrmGetActiveForm();
  if (GetHackPrefs(&hackPrefs))
	SetHackPrefs(&hackPrefs);	// write Prefs, didn't exsist before!
  FtrRet = FtrGet(HACKCREATORID, hackID_A245, &pfnOldProc); // check if hack is activated (0 == no error)
  if (FtrRet) {					// if Hack deactivated (or not installed)
	hackPrefs.OnBacklightTime = 0;
	hackPrefs.State.Backlight = false;
	SetHackPrefs(&hackPrefs);
  }

  // total time since reset
  seconds = TimGetSeconds() - appPrefs->TotalResetTime;
  drawTime(seconds, form, lblID_reset_total);

  // running time since reset
  if (!FtrRet) {
	seconds = hackPrefs.OnResetTime + (TimGetSeconds() - hackPrefs.PowerOnResetStart);
  } else {						// if no Hack inst., use TimGetTicks()!
	seconds = TimGetTicks() / sysTicksPerSecond;
  }
  drawTime(seconds, form, lblID_reset_on);

  // total time since battery change
  seconds = TimGetSeconds() - appPrefs->TotalBatteryTime;
  drawTime(seconds, form, lblID_batt_total);

  // running time since battery change
  if (!FtrRet) {
	seconds = hackPrefs.OnBatteryTime + (TimGetSeconds() - hackPrefs.PowerOnBatteryStart);
	drawTime(seconds, form, lblID_batt_on);
  } else {						// if hack deactivated say "n/a"
	StrCopy(msg, "n/a");
	FrmCopyLabel(form, lblID_batt_on, msg);
  }

  // backlight on time
  FtrGet(sysFtrCreator, sysFtrNumBacklight, &NumBacklight); // system backlight feature
  if ((!FtrRet) && ((NumBacklight & 0x01) == 1)) {
	seconds = hackPrefs.OnBacklightTime;
	if (hackPrefs.State.Backlight)
	  seconds += TimGetSeconds() - hackPrefs.PowerOnBacklightStart;
	drawTime(seconds, form, lblID_backlight_on);
  } else {						// if hack deactivated say "n/a"
	StrCopy(msg, "n/a");
	FrmCopyLabel(form, lblID_backlight_on, msg);
  }

  // Battery information
  voltage = SysBatteryInfo(false, &warnlev, &critlev, NULL, &btype, NULL);

  idx_trig = FrmGetObjectIndex(form, trigID_bi_type);
  idx_list = FrmGetObjectIndex(form, listID_bi_type);
  LstSetSelection((ListPtr)FrmGetObjectPtr(form, idx_list), (Word)btype);
  CtlSetLabel((ControlPtr)FrmGetObjectPtr(form, idx_trig), 
			  LstGetSelectionText((ListPtr)FrmGetObjectPtr(form, idx_list),
								  (Word)btype));

  VoltageToStr(msg, voltage);
  FrmCopyLabel(form, lblID_bi_volt, msg);

  VoltageToStr(msg, warnlev);
  FrmCopyLabel(form, lblID_bi_warn, msg);

  VoltageToStr(msg, critlev);
  FrmCopyLabel(form, lblID_bi_crit, msg);
} /* drawForm */


/*
===============================================================
Function : WinInvertLabel
---------------------------------------------------------------
Purpose  : Invert the hole line of a label in font type 2
Call     : WinInvertLabel(objID);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
objID            I  Word    Object ID of the label to invert
===============================================================
*/
void WinInvertLabel(Word objID)
{
  FormPtr form;					// pointer to active form
  FormLabelType *lblPtr;		// pointer to object in the form
  Word lblIdx;					// item number of a object
  RectangleType r;				// rectangle to invert

  form = FrmGetActiveForm();
  lblIdx = FrmGetObjectIndex(form, objID);
  lblPtr = (FormLabelType*)FrmGetObjectPtr(form, lblIdx);

  r.topLeft.x = 0; r.topLeft.y = lblPtr->pos.y;
  r.extent.x = 160; r.extent.y = 14;
  WinInvertRectangle(&r, 3);	// invert the label
} /* WinInvertLabel */


/*
===============================================================
Function : eventLook
---------------------------------------------------------------
Purpose  : Main event lookup loop
Call     : ret=eventLook(appPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
appPrefs         I  AppPrefs application preference block
ret              O  int     always 0
===============================================================
*/
int eventLook(AppPrefs *appPrefs)
{
#undef BATT_TEST
  short err;
  Boolean formOpen = false;		// switch, if form already opened
  Boolean Update = true;		// switch, if form update
  Boolean Handled;				// switch, if event got fully handled
  EventType e;					// event structure
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars
  UInt warnlev,					// vars for SysBatteryInfo()
    critlev,
	maxTicks;
  SysBatteryKind btype;
  Boolean pluggedIn;
  FormPtr form;					// pointer to active form
  FormLabelType *lblPtr;		// pointer to object in the form
  Word lblIdx;					// item number of a object

  while (1) {
	EvtGetEvent(&e, Update ? 0 : 1000);
    if (SysHandleEvent(&e))
      continue;
	if (MenuHandleEvent((void *) 0, &e, &err))
	  continue;

    Handled = true;
	switch (e.eType) {
    case frmLoadEvent:
      FrmSetActiveForm(FrmInitForm(e.data.frmLoad.formID));
      break;

    case frmOpenEvent:
	  form = FrmGetActiveForm();
      FrmDrawForm(form);
	  WinInvertLabel(lblID_time); // invert time information
	  WinInvertLabel(lblID_bi);	// invert battery information

	  // draw table lines
	  lblIdx = FrmGetObjectIndex(form, lblID_total);
	  lblPtr = (FormLabelType*)FrmGetObjectPtr(form, lblIdx);
	  WinDrawLine(0, lblPtr->pos.y+NORM_FH, 160, lblPtr->pos.y+NORM_FH);
	  WinDrawLine(COL1-2, lblPtr->pos.y, 
				  COL1-2, lblPtr->pos.y+4*NORM_FH+GAP);
	  WinDrawLine(COL2-2, lblPtr->pos.y, 
				  COL2-2, lblPtr->pos.y+4*NORM_FH+GAP);
	  lblIdx = FrmGetObjectIndex(form, lblID_backlight);
	  lblPtr = (FormLabelType*)FrmGetObjectPtr(form, lblIdx);
	  WinDrawLine(0, lblPtr->pos.y+NORM_FH, 160, lblPtr->pos.y+NORM_FH);

      formOpen = true;
	  Update = true;
      break;

    case menuEvent:
      switch (e.data.menu.itemID) {
      case menuitemID_batt_reset:
        if (!FrmAlert(alertID_battery_confirm)) {
          appPrefs->TotalBatteryTime = TimGetSeconds();
		  SetAppPrefs(appPrefs);
		  GetHackPrefs(&hackPrefs);
		  hackPrefs.PowerOnBatteryStart = TimGetSeconds();
		  hackPrefs.OnBatteryTime = 0;
		  SetHackPrefs(&hackPrefs);
		  Update = true;
		}
        break;

      case menuitemID_light_reset:
        if (!FrmAlert(alertID_backlight_confirm)) {
		  GetHackPrefs(&hackPrefs);
		  hackPrefs.PowerOnBacklightStart = TimGetSeconds();
		  hackPrefs.OnBacklightTime = 0;
		  SetHackPrefs(&hackPrefs);
		  Update = true;
		}
        break;

      case menuitemID_about:
        FrmHelp(helpID_about);
		Update = true;
        break;
      }
      break;

	case penDownEvent:
#if defined(BATT_TEST)
	  if ((e.screenX < 20) && (e.screenY > 13) && (e.screenY < 30)) {
		/*
		if (GSysBatteryKind == sysBatteryKindAlkaline)
		  GSysBatteryKind = sysBatteryKindNiCad;
		else
		  GSysBatteryKind = sysBatteryKindAlkaline;
		  */
		SysBatteryInfo(false, &warnlev, &critlev, &maxTicks, &btype, &pluggedIn);
		if (btype == sysBatteryKindAlkaline)
		  btype = sysBatteryKindNiCad;
		else
		  btype = sysBatteryKindAlkaline;
		SysBatteryInfo(true, &warnlev, &critlev, &maxTicks, &btype, &pluggedIn);
	  }
#endif
	  Update = true;
	  Handled = false;
	  break;

	case popSelectEvent:
	  if (e.data.popSelect.controlID == trigID_bi_type) {
		if ((e.data.popSelect.selection >= 0) &&
			(e.data.popSelect.selection <= 2)) {
		  SysBatteryInfo(false, &warnlev, &critlev, &maxTicks, &btype, &pluggedIn);
		  btype = e.data.popSelect.selection;
		  SysBatteryInfo(true, &warnlev, &critlev, &maxTicks, &btype, &pluggedIn);
		}
	  } else		
		Handled = false;
	  break;

    case nilEvent:
	  if (formOpen) {
		drawForm(appPrefs);
		Update = false;
	  }
	  Handled = false;
      break;

    case appStopEvent:
      return 0;

    default:
	  Handled = false;
      break;
    }
	if ((!Handled) && (formOpen))
      FrmHandleEvent(FrmGetActiveForm(), &e);
  }
} /* eventLook */


DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  short error;
  AppPrefs appPrefs;			// storage of all global Uptime vars
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars

  if (cmd == sysAppLaunchCmdNormalLaunch) {
    error = GetAppPrefs(&appPrefs);
    if (error)
      return error;
    FrmGotoForm(formID_main);
    eventLook(&appPrefs);
    SetAppPrefs(&appPrefs);
  } else if (cmd == sysAppLaunchCmdSystemReset) {
    GetAppPrefs(&appPrefs);
    appPrefs.TotalResetTime = TimGetSeconds();
    SetAppPrefs(&appPrefs);
    GetHackPrefs(&hackPrefs);
    hackPrefs.PowerOnResetStart = TimGetSeconds();
    hackPrefs.OnResetTime = 0;
    SetHackPrefs(&hackPrefs);
  }

  return 0;
} /* PilotMain */
