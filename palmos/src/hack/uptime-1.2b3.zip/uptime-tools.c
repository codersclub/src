/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime-tools.c,v $
$Author: hmueller $
$Date: 1998/05/20 14:12:24 $
$Revision: 1.3 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Tools for Uptime and Hack

* Uptime-Tools
* Holger M�ller <hmueller@bigfoot.com>
* http://www.bigfoot.com/~hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-tools.c,v $
* Revision 1.3  1998/05/20 14:12:24  hmueller
* - moved "GetHackPrefs()" to "GetHackPrefs.c" for common use
*
* Revision 1.2  1998/04/26 15:56:00  hmueller
* Function GetHackPrefs: Set "OnResetTime" to "TimGetTicks" instead of 0
*
* Revision 1.1  1998/04/13 20:31:27  hmueller
* Initial revision
* 
****************************************************************
*/

#include "uptime.rid"			// ID's of all resources
#include "uptime.h"				// def's for Uptime
#include "uptime-hack.h"		// def's for Uptime Hack
#include "uptime-tools.h"		// tools for Uptime
#include "GetHackPrefs.h"		// def. of function "GetHackPrefs()"


/*
===============================================================
Function : GetAppPrefs
---------------------------------------------------------------
Purpose  : Get application preferences from Pilot database
Call     : ret=GetAppPrefs(&appPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
appPrefs         O  AppPrefs application preference block
ret              O  int     always 0
===============================================================
*/
int GetAppPrefs(AppPrefs *appPrefs)
{
  if (!PrefGetAppPreferencesV10(APPCREATORID, PREFVER, appPrefs, sizeof(AppPrefs))) {
    appPrefs->TotalBatteryTime = TimGetSeconds();
    appPrefs->TotalResetTime = TimGetSeconds();
  }
  return 0;
} /* GetAppPrefs */


/*
===============================================================
Function : SetAppPrefs
---------------------------------------------------------------
Purpose  : Write application preferences to Pilot database
Call     : SetAppPrefs(&appPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
appPrefs         I  AppPrefs application preference block
===============================================================
*/
void SetAppPrefs(AppPrefs *appPrefs)
{
  PrefSetAppPreferencesV10(APPCREATORID, PREFVER, appPrefs, sizeof(AppPrefs));
} /* SetAppPrefs */


#include "GetHackPrefs.c"		// function "GetHackPrefs()"


/*
===============================================================
Function : SetHackPrefs
---------------------------------------------------------------
Purpose  : Write hack preferences to Pilot database
Call     : SetHackPrefs(&hackPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
hackPrefs         I  HackPrefs Hack preference block
===============================================================
*/
void SetHackPrefs(HackPrefs *hackPrefs)
{
  PrefSetAppPreferencesV10(HACKCREATORID, HACKPREFVER, hackPrefs, sizeof(HackPrefs));
} /* SetHackPrefs */
