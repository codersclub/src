/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime-hack_A245.c,v $
$Author: hmueller $
$Date: 1998/05/20 13:29:17 $
$Revision: 1.3 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Hack for Uptime
          Thanks to Peter Strobel <http://home.t-online.de/home/PSpilot>
		  for his "How to" help!

* Uptime-Hack
* Holger M�ller <hmueller@bigfoot.com>
* http://www.bigfoot.com/~hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-hack_A245.c,v $
* Revision 1.3  1998/05/20 13:29:17  hmueller
* - Now using "GetHackPrefs()" instead of own code. Therefore included
* "GetHackPrefs.c". No need to check existing Prefs. and setting
* init. values
*
* Revision 1.2  1998/04/26 16:17:26  hmueller
* Set "OnResetTime" to "TimGetTicks()" instead of "0" for new ApplPrefs
*
* Revision 1.1  1998/04/13 21:35:31  hmueller
* Initial revision
*
****************************************************************
*/
#pragma pack(2)

/* Pilot header files. */
#include <Pilot.h>

/* Local header files. */
#include "uptime.rid"			// ID's of all resources
#include "uptime-hack.h"		// def's for Uptime Hack
#include "GetHackPrefs.h"		// def. of function "GetHackPrefs()"


/*
===============================================================
Function : HwrLCDSleepHack
---------------------------------------------------------------
Purpose  : New Trap for "HwrLCDSleep" at 0xA245
		   Calcs real power on time and calls old "HwrLCDSleep"
Call     : ret=HwrLCDSleepHack(&hackPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
untilReset       I  Boolean s. USR docs
emergency        I  Boolean s. USR docs
ret              O  Err     s. USR docs
===============================================================
*/
Err HwrLCDSleepHack(Boolean untilReset, Boolean emergency) {
  Err (*oldtrap)(Boolean, Boolean);	// procedure pointer to old trap
  DWord pfnOldProc;				// for the feature manager call type checking
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars
  
  GetHackPrefs(&hackPrefs);

  /* calc ON time */
  hackPrefs.OnBatteryTime += (TimGetSeconds() - hackPrefs.PowerOnBatteryStart);
  hackPrefs.OnResetTime += (TimGetSeconds() - hackPrefs.PowerOnResetStart);

  PrefSetAppPreferencesV10(HACKCREATORID, HACKPREFVER, &hackPrefs, sizeof(HackPrefs));

  /* get old trap address from HackMaster and execute it */
  FtrGet(HACKCREATORID, hackID_A245, &pfnOldProc);
  oldtrap = (Err (*)(Boolean, Boolean))pfnOldProc; // set procedure pointer
  return oldtrap(untilReset, emergency);
} /* HwrLCDSleepHack */


#include "GetHackPrefs.c"		// function "GetHackPrefs()"
