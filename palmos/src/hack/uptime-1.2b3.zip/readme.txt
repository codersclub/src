* Uptime 1.2
* Copyright 1998/05/19
* Holger M�ller <hmueller@mail.freepage.de> or <hmueller@bigfoot.com>
*	http://www.freepage.de/hmueller/pilot
* Gabe Dalbec <dalbec@usa.net>
*	http://www.pilotcreations.com/uptime.html
*
* You may use this code, and do whatever you want to it, but give me
* credit in whatever it turns into.

Keep track of how long since the last soft start of your pilot and the
battery change. Furthermore you get the actual power on time since both
events. Last but not lease you get advanced battery information.

NEW:
===
1.2:
---
You now may change the battery type via a popup list, which is much
easier than the grafitti shortcut. Uptime also keeps track of the
backlight on time.

1.1:
---
Uptime now knows the correct time your Pilot is running since the last
reset and battery change. This is done by an hack and the real time
clock. In contrast to all older versions of Uptime this methode is
independent of the system clock. The system clock is changeable using
e.g. "Eco Hack" by Peter Strobel <http://home.t-online.de/home/PSpilot>.

1.0:
---
Added advanced battery information.


Installation:
============

You now need the Hackmaster extension of Draggerware
<http://www.daggerware.com/> installed! Please register Hackmaster, if
you like to use Uptime. It is Shareware and NOT Freeware like
Uptime. Sorry for that, but it is really necessary.

Before you install a new version of Uptime you should remove the old one
from your Pilot memory to avoid conflicts. Form more infomation see
section "Deinstallation". After removing install both "uptime-hack.prc"
and "uptime.prc" via hotsync as usual. On your Pilot change to
"HackMaster" and activate "Uptime Hack". If you do not like the hack (for
what reason ever) you do not need to install "uptime-hack.prc".  See
limitations for more information.

Deinstallation:
==============

Do NOT delete the active "Uptime Hack" with the Memory application!
Uncheck "Uptime Hack" inside HackMaster first. After that you may remove
"Uptime" and "Uptime Hack" with the Memory application from the Pilot
memory.

Limitations:
===========

After the installation all times start with zero, because nobody knows
exactly how long your Pilot already run. ;-)

If you deactivate (or do not install) the hack the "Running time since
reset" is derivated by a system function and may be wrong! The entry
"Running time since battery change" and the "Backlight on time" is set to
"n/a" since there is no other way to get this informaton than the
hack. If you activate, deactivate and afterwards activate the hack you
may get wrong "Running"-times!!!

After a reset the battery type gets reseted to "Alkaline".

Hints:
=====

When you change the batteries, remember to run uptime and press "Reset
Battery Time" button in the "Options" menu to reset these timer. You may
change the battery type from "Alkaline" to "NiCad" and vice versa by
using the undocumented {.7 grafitti shortcut or the popup list. For some
unknown reason the undocumented shortcut gets out of sync if you change
it with the popup list. Nevertheless is the display battery type the
actual set battery type!

Uptime does not use any CPU time when it is not the active program. If it
is active it just updates the display every 10 seconds. In the meantime
the pilot is in doze mode (very low power consumption). The hack gets
only activated while pilot power on and off sequence. It should work with
any and all other pilot programs. It is tested with Pilot 5000, Pilot
Personal, Pilot Professional and Pilot III.

The USR application ID 'PLSu' is registered by Gabe Dalbec and the hack
ID 'PLSh' by Holger M�ller. Please note that Uptime is released as free
software, licensed under the GNU GPL. Be sure to read the file COPYING
for full details.

If you have any feedback or comments (or bugs) please feel free to
mail them to dalbec@usa.net or hmueller@bigfoot.com.

The latest version of Uptime will currently be available from:

        http://software.freepage.de/hmueller/pilot/uptime.html

If you are upgrading from an earlier version of Uptime you can find
out what has changed by reading the uptime.c changelog. 
Note: The revision numbers are RCS revisions, which currently do not
correspond with the Uptime version number!

Have fun.
Holger M�ller <hmueller@bigfoot.com>
