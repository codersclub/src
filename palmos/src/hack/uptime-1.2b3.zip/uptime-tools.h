/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime-tools.h,v $
$Author: hmueller $
$Date: 1998/05/20 13:14:39 $
$Revision: 1.2 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Tools for Uptime and Hack

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-tools.h,v $
* Revision 1.2  1998/05/20 13:14:39  hmueller
* - Moved GetHackPrefs() def. to "GetHackPrefs.h"
*
* Revision 1.1  1998/04/13 21:38:45  hmueller
* Initial revision
*
****************************************************************
*/

#ifndef UPTIME_TOOLS_H
#define UPTIME_TOOLS_H

#include "uptime.h"
#include "GetHackPrefs.h"

int GetAppPrefs(AppPrefs *appPrefs);
void SetAppPrefs(AppPrefs *appPrefs);
void SetHackPrefs(HackPrefs *hackPrefs);

#endif /* UPTIME_TOOLS_H */
