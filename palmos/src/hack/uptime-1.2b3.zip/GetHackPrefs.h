/*
****************************************************************
$Source: e:\\work\\Src\\Pilot\\uptime/RCS/GetHackPrefs.h,v $
$Author: hmueller $
$Date: 1998/05/20 11:47:36 $
$Revision: 1.1 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Header for common function "GetHackPrefs()" which is 
          better source included than using an object file.

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: GetHackPrefs.h,v $
* Revision 1.1  1998/05/20 11:47:36  hmueller
* Initial revision
*
*
****************************************************************
*/

int GetHackPrefs(HackPrefs *hackPrefs);
