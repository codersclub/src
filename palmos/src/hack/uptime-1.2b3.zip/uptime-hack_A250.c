/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime-hack_A250.c,v $
$Author: hmueller $
$Date: 1998/04/13 21:36:00 $
$Revision: 1.1 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Hack for Uptime
          Thanks to Peter Strobel <http://home.t-online.de/home/PSpilot>
		  for his "How to" help!

* Uptime-Hack
* Holger M�ller <hmueller@bigfoot.com>
* http://www.bigfoot.com/~hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-hack_A250.c,v $
* Revision 1.1  1998/04/13 21:36:00  hmueller
* Initial revision
*
* 
****************************************************************
*/
#pragma pack(2)

/* Pilot header files. */
#include <Pilot.h>

/* Local header files. */
#include "uptime.rid"			// ID's of all resources
#include "uptime-hack.h"		// def's for Uptime Hack


/*
===============================================================
Function : HwrLCDWakeHack
---------------------------------------------------------------
Purpose  : New Trap for "HwrLCDWake" at 0xA250
		   Saves time of Pilot power on and calls old "HwrLCDWake"
Call     : ret=HwrLCDWakeHack();
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
ret              O  Err     s. USR docs
===============================================================
*/
Err HwrLCDWakeHack(void) {
  Err (*oldtrap)(void);			// procedure pointer to old trap
  DWord pfnOldProc;				// for the feature manager call type checking
  HackPrefs hackPrefs;			// storage of all global Uptime Hack vars
  
  /* "hackPrefs" AppPreference exsists anyway, because
	 "HwrLCDSleep" runs befor "HwrLCDWake"!!! -> no retcode check */
  PrefGetAppPreferencesV10(HACKCREATORID, HACKPREFVER, &hackPrefs, sizeof(HackPrefs));
  hackPrefs.PowerOnBatteryStart = TimGetSeconds(); // save power on time
  hackPrefs.PowerOnResetStart = TimGetSeconds(); // save power on time
  PrefSetAppPreferencesV10(HACKCREATORID, HACKPREFVER, &hackPrefs, sizeof(HackPrefs));

  /* get old trap address from HackMaster and execute it */
  FtrGet(HACKCREATORID, hackID_A250, &pfnOldProc);
  oldtrap = (Err (*)(void))pfnOldProc; // set procedure pointer
  return oldtrap();
} /* HwrLCDWakeHack */
