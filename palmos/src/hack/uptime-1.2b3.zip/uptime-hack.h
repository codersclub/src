/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime-hack.h,v $
$Author: hmueller $
$Date: 1998/05/20 13:17:37 $
$Revision: 1.2 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Hack for Uptime

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This progra  
m is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime-hack.h,v $
* Revision 1.2  1998/05/20 13:17:37  hmueller
* - Added enties for backlight time at structure "HackPrefs"
*
* Revision 1.1  1998/04/13 20:26:13  hmueller
* Initial revision
*
*
****************************************************************
*/

#ifndef UPTIME_HACK_H
#define UPTIME_HACK_H

#define HACKCREATORID	'PLSh'	// USR application ID for hack (registered at USR on April 11, 1998 hmueller)
#define HACKPREFVER		0x0001	// version of hack application preferences

typedef struct {				// application preference block
  ULong PowerOnBatteryStart;	// time of pilot startup (on switch) for battery [sec]
  ULong PowerOnResetStart;		// time of pilot startup (on switch) for Reset [sec]
  ULong PowerOnBacklightStart;	// time when backlight was switched on [sec]
  ULong OnBatteryTime;			// pilot runtime [sec] since battery change
  ULong OnResetTime;			// pilot runtime [sec] since reset
  ULong OnBacklightTime;		// running time [sec] of backlight
  struct {
	Byte Backlight : 1;			// 0: backlight off, 1: backlight on
  } State;
} HackPrefs;

#endif /* UPTIME_HACK_H */
