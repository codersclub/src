/*
****************************************************************
$Source: e:\\work\\Src\\Pilot\\uptime/RCS/GetHackPrefs.c,v $
$Author: hmueller $
$Date: 1998/05/20 11:48:35 $
$Revision: 1.1 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Common function "GetHackPrefs()" which is better source 
          included than using an object file.

* Uptime
* Holger M�ller <hmueller@bigfoot.com> <hmueller@mail.freepage.de>
* http://software.freepage.de/hmueller/pilot

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: GetHackPrefs.c,v $
* Revision 1.1  1998/05/20 11:48:35  hmueller
* Initial revision
*
*
****************************************************************
*/


/*
===============================================================
Function : GetHackPrefs
---------------------------------------------------------------
Purpose  : Get hack preferences from Pilot database
Call     : ret=GetAppPrefs(&hackPrefs);
===============================================================
Parameter:
---------------------------------------------------------------
VAR             I/O TYPE    REMARK
---------------------------------------------------------------
hackPrefs        O  HackPrefs Hack preference block
ret              O  int     0: got database prefs
                            1: returned default values
===============================================================
*/
int GetHackPrefs(HackPrefs *hackPrefs)
{
  if (!PrefGetAppPreferencesV10(HACKCREATORID, HACKPREFVER, hackPrefs, sizeof(HackPrefs))) {
    hackPrefs->PowerOnBatteryStart = \
	  hackPrefs->PowerOnResetStart = TimGetSeconds();
	/* PowerOnBacklightStart must be 0, because HackPrefs could be
       initalized by Uptime while Hack wasn't activated yet */
	hackPrefs->PowerOnBacklightStart = 0;

	hackPrefs->OnBatteryTime = 0;
	hackPrefs->OnResetTime = TimGetTicks() / sysTicksPerSecond;
	hackPrefs->OnBacklightTime = 0;

	hackPrefs->State.Backlight = false;
	return 1;
  }
  return 0;
} /* GetHackPrefs */
