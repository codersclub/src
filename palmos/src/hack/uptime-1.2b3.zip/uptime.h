/*
****************************************************************
$Source: e:/work/Src/Pilot/uptime/RCS/uptime.h,v $
$Author: hmueller $
$Date: 1998/05/20 13:18:58 $
$Revision: 1.2 $
****************************************************************
OS      : Palm OS 1.0
Compiler: prc-tools Version 0.5.0 (GCC 2.7.2.2-kgpd-071097)
Notes   : Thanks to Gabe Dalbec <dalbec@usa.net> for providing me
          the source code of uptime 0.9

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the license, or (at your
option) any later version.
     
This program is distributed in the hope that it will be useful, but
WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General
Public License for more details.
     
You should have received a copy of the GNU General Public License along
with this program; if not, write to the Free Software Foundation, Inc.,
675 Mass Ave, Cambridge, MA 02139, USA.

ChangeLog: 
* $Log: uptime.h,v $
* Revision 1.2  1998/05/20 13:18:58  hmueller
* - Added defines for font height
*
* Revision 1.1  1998/04/13 20:26:37  hmueller
* Initial revision
*
****************************************************************
*/

#ifndef UPTIME_H
#define UPTIME_H

#include <Pilot.h>

#define APPCREATORID	'PLSu'	// USR application ID
#define PREFVER			0x0003	// version of application preferences

#define NORM_FH (9+3)			// normal font height
#define LARG_FH (12+3)			// large font height

typedef struct {				// application preference block
  ULong TotalBatteryTime;		// time of last battery change [sec]
  ULong TotalResetTime;			// time of last reset [sec]
} AppPrefs;

#endif /* UPTIME_H */
