/* $Id: code07d0.c,v 1.4 2001/01/26 00:00:33 docwhat Exp $

    PowerButton Hack - Allows customizing the Power button on Palms
    Copyright (C) 2000-2001 Christian H�ltje

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <PalmOS.h>
#include "powerbutton.h"
#include "hackuidef.h"

typedef struct
{
        Char	name[dmDBNameLength];
        UInt32	creator;
} MyListStruct;

static void GetPref(prefStruct *pref);
inline static void SetPref(prefStruct *pref);
static void DrawTime(prefStruct *pref);
static void PrefsInit(FormPtr frm);
static void PrefsFinish(FormPtr frm);
static void PrefsListDrawFunc( UInt16 index,
                               RectanglePtr bounds,
                               Char **itemsText);
static void DoListSelect(UInt16 selection);

static void *GetObjectPtr (UInt16 objID);

static Boolean
PrefsHandler(EventPtr event)
{
        FormPtr		form;
        prefStruct	pref;
        Boolean         handled = false;

        switch (event->eType) {
        case frmOpenEvent:
                form = FrmGetActiveForm();

                FrmDrawForm(form);
                PrefsInit(form);

                handled = true;
                break;
            
        case ctlRepeatEvent:
                switch( event->data.ctlRepeat.controlID) {
            
                case rbtID_MinUp:
                        GetPref(&pref);
                        if( pref.minutes < 59 ) {
                                pref.minutes++;
                        } else {
                                if( pref.hours < 99 ) {
                                        pref.minutes = 0;
                                        pref.hours++;
                                }
                        }
                        DrawTime(&pref);
                        break;
            
                case rbtID_MinDown:
                        GetPref(&pref);
                        if( pref.minutes > 0 ) {
                                pref.minutes--;
                        } else {
                                if( pref.hours > 0 ) {
                                        pref.minutes = 59;
                                        pref.hours--;
                                }
                        }
                        DrawTime(&pref);
                        break;
            
            
                case rbtID_HrUp:
                        GetPref(&pref);
                        if( pref.hours < 99 ) {
                                pref.hours++;
                                DrawTime(&pref);
                        }
                        break;
            
            
                case rbtID_HrDown:
                        GetPref(&pref);
                        if( pref.hours > 0 ) {
                                pref.hours--;
                                DrawTime(&pref);
                        }
                        break;
            
                default:
                        break;
                }
                break;

        case popSelectEvent:
                if( event->data.popSelect.listID == lstID_AppList )
                {
                        DoListSelect(event->data.popSelect.selection);
                }
                break;
        
        case ctlSelectEvent:
                switch (event->data.ctlEnter.controlID) {
                case btnID_prefOK:
                        form = FrmGetActiveForm();
                        PrefsFinish(form);
                        FrmGotoForm(9000);  // return to HackMaster control panel
                        handled = true;
                        break;
                }
                break;
        
        default:
                break;
        }

        return handled;
}

static void PrefsInit(FormPtr frm)
{
        prefStruct		pref;
        MemHandle		hAppList;
        SysDBListItemType 	*pAppList;
        ListPtr			pList;
        UInt16			uAppCount, i, found = -1;
        MyListStruct		*pStruct;
        Char			**pListPtrs;

        GetPref(&pref);

        DrawTime(&pref);
    
        CtlSetValue( GetObjectPtr( chkID_UpOff   ), pref.upoffhack);
        CtlSetValue( GetObjectPtr( chkID_TimeRun ), pref.timed);

        /* Fill in the razzenfrazzen App List */
        if( SysCreateDataBaseList( 'appl',
                                   0,
                                   &uAppCount,
                                   &hAppList,
                                   true) ) {

                pStruct   = MemPtrNew( uAppCount * sizeof(MyListStruct) );
                pListPtrs = MemPtrNew( uAppCount * sizeof(*pListPtrs) );
                ErrFatalDisplayIf( pStruct == 0 && pListPtrs == 0,
                                   "PrefsInit: Failed to Allocate Memory" );

                MemSet(pStruct,   uAppCount * sizeof(MyListStruct), 0 );
                MemSet(pListPtrs, uAppCount * sizeof(*pListPtrs),   0 );

                pAppList = MemHandleLock(hAppList);
                for( i = 0; i < uAppCount; i++ ) {
                        StrCopy( pStruct[i].name, pAppList[i].name );
                        pStruct[i].creator = pAppList[i].creator;
                        pListPtrs[i] = pStruct[i].name;
                        if( pStruct[i].creator == pref.creatorid ) {
                                found = i;
                        }
                }
                MemHandleUnlock(hAppList);

                // Save the database list handles for later
                FtrSet(CREATORID, FTR_pStruct,	 (UInt32)pStruct  );
                FtrSet(CREATORID, FTR_pListPtrs, (UInt32)pListPtrs);

                pList = GetObjectPtr( lstID_AppList );

                /* Setup the popup list */
                LstSetListChoices(pList, pListPtrs, uAppCount);
                LstSetDrawFunction(pList, (ListDrawDataFuncPtr)PrefsListDrawFunc);

                LstSetSelection(pList, found);
                if( found >= 0 )
                {
                        LstMakeItemVisible(pList, found);
                        CtlSetLabel( GetObjectPtr(popID_AppList), pListPtrs[found] );
                        /* LstDrawList(pList); */
                }
        } else {
                FtrUnregister(CREATORID, FTR_pStruct);
                FtrUnregister(CREATORID, FTR_pListPtrs);

        }

        if( found == -1 )
        {
                FrmShowObject( frm, FrmGetObjectIndex(frm, lblID_Warning1));
                FrmShowObject( frm, FrmGetObjectIndex(frm, lblID_Warning2));
        }
}

static void PrefsFinish(FormPtr frm)
{
        MyListStruct	*pStruct;
        Char		**pListPtrs;
        prefStruct	pref;

        GetPref(&pref);
            
        pref.upoffhack = CtlGetValue( GetObjectPtr( chkID_UpOff ) );
        pref.timed = CtlGetValue( GetObjectPtr( chkID_TimeRun ) );
        
        SetPref(&pref);            

        if( !FtrGet(CREATORID, FTR_pStruct,   (UInt32*)&pStruct) )
        {
                MemPtrFree( pStruct );
                FtrUnregister(CREATORID, FTR_pStruct);
        }
        if( !FtrGet(CREATORID, FTR_pListPtrs, (UInt32*)&pListPtrs) )
        {
                MemPtrFree( pListPtrs );
                FtrUnregister(CREATORID, FTR_pListPtrs);
        }
}

static void PrefsListDrawFunc( UInt16 index,
                               RectanglePtr bounds,
                               Char **itemsText) {
#if 0
        MyListStruct		*pStruct;

        if( FtrGet(CREATORID, FTR_pStruct,   (UInt32*)&pStruct) )
        {
                return;
        }

        WinDrawChars( pStruct[index].name,
                      StrLen(pStruct[index].name),
                      bounds->topLeft.x, bounds->topLeft.y);
#endif

        WinDrawChars( itemsText[index],
                      StrLen(itemsText[index]),
                      bounds->topLeft.x, bounds->topLeft.y);

}

static void DoListSelect(UInt16 selection) {
        prefStruct	pref;
        MyListStruct	*pStruct;
        FormPtr frm;
  
        if( selection < 0 ) return;

        if( FtrGet(CREATORID, FTR_pStruct,   (UInt32*)&pStruct) )
        {
                return;
        }
        
        GetPref(&pref);

        pref.creatorid = pStruct[selection].creator;

        /* Turn off the warning about not having selected an App */
        frm = FrmGetActiveForm();
        FrmHideObject( frm, FrmGetObjectIndex(frm, lblID_Warning1));
        FrmHideObject( frm, FrmGetObjectIndex(frm, lblID_Warning2));
                             
        SetPref(&pref);
}

static void DrawTime(prefStruct *ppref) {
        Char buff[6];
        UInt16 len;
        FontID currFont;

        len = StrPrintF(buff, "%02d:%02d", ppref->hours, ppref->minutes, NULL);
    
        currFont = FntSetFont(boldFont);
        WinDrawChars( buff, len, 35, 86);
        FntSetFont(currFont);

        SetPref(ppref);
}

static void GetPref(prefStruct *ppref) { 
        ErrFatalDisplayIf( ppref == NULL, "GetPref Error" );

        if ( ! PrefGetAppPreferencesV10( CREATORID,
                                         PrefVersion,
                                         (void *) ppref,
                                         sizeof(prefStruct))) {
                ppref->creatorid = 'lnch';
                ppref->minutes = 0;
                ppref->hours = 1;
                ppref->timed = 0;
                ppref->upoffhack = 0;

                SetPref(ppref);
        }

        return;
}

inline static void SetPref(prefStruct *ppref) {
        ErrFatalDisplayIf( ppref == NULL, "SetPref Error" );
        PrefSetAppPreferencesV10( CREATORID,
                                  PrefVersion,
                                  (void *) ppref,
                                  sizeof(prefStruct) );
}

/* GetObjectPtr -- Returns an object Pointer given an object's ID
 * Args:
 *    Word ObjID -- ID of the Object to return a pointer to
 * Returns:
 *    VoidPtr    -- Ptr to Object
 */
static void * GetObjectPtr (UInt16 objID) {
        FormPtr frm;
  
        frm = FrmGetActiveForm();
  
        return (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objID)));
}

