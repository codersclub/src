/* $Id: powerbutton.h,v 1.3 2001/01/26 00:00:33 docwhat Exp $

    PowerButton Hack - Allows customizing the Power button on Palms
    Copyright (C) 2000-2001 Christian H�ltje

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

// The struct that defines the app preferences for the hack.
#define PrefVersion   3
typedef struct
{
    UInt32	creatorid;
    UInt16	minutes;
    UInt16	hours;
    Boolean	timed;
    Boolean	upoffhack;
} prefStruct;

