PowerButton Hack README

Copyright 2000-2001 Christian H�ltje

This is free software, and you are welcome to redistribute
it under certain conditions; See the COPYING file that
should have come with this program.

Summary:

	PowerButton Hack lets you set your palm to run a specific
	program when the powerbutton is used to turn on your Palm.

Requirements:

	To use PowerButton Hack you need HackMaster, which is available at
	http://www.daggerware.com/

	PowerButton has only been tested with PalmOS3.0(handspring) but
	should work just as well with PalmOS 2.0 through PalmOS 3.5
	(inclusive).

Usage:
	When you configure PowerButton, you can select the application
	to be run, the time that the palm should be off before running it
	and optionally activating a PalmV fix for the annoying off button.

	To select an application to run, click on the drop down list and
	select the application you want.  If this application is later
	deleted, PowerButton will beep instead, to indicate that the
	application is missing.  The beep depends on your sound settings.

	Activate the "Only run if off for at least" check button to set an
	amount of time that the palm must be off before it can run your
	chosen appliacation.  Otherwise, it runs the application everytime
	you turn on your palm.

	Use the up and down arrows to change the hours and minutes.

	The PalmV UpOff Hack is similar to UpOffHack, but doesn't allow
	alarms to turn on.  This is due to trying to keep PowerButton
	compatible with PalmOs3.5

Tips and Suggestions:

	* Returning to the Previous Application:
	  PowerButton works extreamely well with McPhling (available at
	  http://MikeMcCollister.com/palm/ ).  You can use McPhling to
	  jump *back* to the application running before you turned off the
	  power (swipe from the Apps button to the Graffiti area).

	* Favorite PowerButton Application:
	  I use PowerButton to run BigClock (http://www.gacel.de/ ) an
	  excellent large digit clock that I can see through the cover of my
	  HandSpring Visor Deluxe.

Questions and Donations:

	You may contact me at <docwhat@gerf.org> or check out my website at
	http://docwhat.gerf.org/

	If you liked this software, may I suggest that you send me a
	donation.  I have a PayPal account (http://www.paypal.com/ ) and
	will happily accept donations.

	One good reason to donate some money is that I will not work on
	making an application Color without have a color palm myself, so if
	you're dying for it to work with PalmOS 3.5 or newer and have some
	of those nifty features, send money.

Ciao!
