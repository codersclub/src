/* $Id: code03e8.c,v 1.8 2001/01/26 18:25:23 docwhat Exp $

    PowerButton Hack - Allows customizing the Power button on Palms
    Copyright (C) 2000-2001 Christian H�ltje

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

#include <PalmOS.h>

#include "powerbutton.h"
#include "hackuidef.h"

static void NotFound(void);
static Boolean LaunchApp(UInt32 creatorid);

/* We're trapping sysTrapSysSleep normally caled as SysSleep */
void
sysTrapSysSleepPatch (Boolean untilReset, Boolean emergency) {
        UInt32 temp;
        UInt32 runtime;
        UInt32 keystate;
        void (*oldTrap)(Boolean, Boolean);
        prefStruct pref;

        /* Ask HackMaster nicely for the Original (or at least previous)
           sysTrapSysSleep and shove it into temp */
        FtrGet(CREATORID, trapIDSysSleep, &temp);

        /* Stow it */
        oldTrap = (void (*)(Boolean,Boolean)) temp;

        /* In either of these cases, we want to just do the normal thing */
        if ( untilReset || emergency ) {
                oldTrap(untilReset, emergency);
                return;
        }

        /* No prefs, then bail */
        if( !PrefGetAppPreferencesV10(CREATORID, PrefVersion,
                                      (void *) &pref,
                                      sizeof(prefStruct)) ) {
                oldTrap(untilReset, emergency);
                return;
        }        

        runtime = TimGetSeconds();
        if( pref.timed )
        {
                runtime += (60 * pref.minutes) + (60 * 60 * pref.hours);
        }

        /* Call the original */
        oldTrap(untilReset, emergency);

        /* If and ONLY IF the powerbutton is pressed */
        keystate = KeyCurrentState();

        if( !pref.upoffhack )
        {
                if( !(keystate & keyBitPower) )
                        return;
        }
        else
        {
                /* From Duncan Sargent's "Stay Off If Up Hack" */
        
                /* this loop ensures that if the up scroll key is pressed
                   down, then the pilot goes back to sleep.  The exception is
                   when an alarm is triggered (for obvious reasons). */
                while (keystate & ( keyBitPageUp | keyBitPageDown ) )
                {
                        /* && !((AlmGlobalsPtr) GAlmGlobalsP)->triggered) { */
                        oldTrap(untilReset, emergency);
                        keystate = KeyCurrentState();
                }
        }

        if( TimGetSeconds() >= runtime )
        {
                if( ! LaunchApp(pref.creatorid) )
                {
                        NotFound();
                        return;
                }
        }

}


static Boolean LaunchApp(UInt32 creatorid)
{
        Err			err;
        UInt16			cardNo;
        UInt32			currType;
        UInt32			currCreator;
        LocalID			dbID;
        DmSearchStateType	searchstate;
        
        /* Check to see if it's already running */
        if( 0 == SysCurAppDatabase(&cardNo, &dbID) )
        {
                if( 0 == DmDatabaseInfo(cardNo, dbID, NULL, NULL, NULL,
                                        NULL, NULL, NULL, NULL, NULL, NULL,
                                        &currType, &currCreator) )
                {
                        if( currCreator == creatorid  &&
                            currType == sysFileTApplication )
                        {
                                /* It is running, we succeeded by
                                   doing nothing */
                                return true;
                        }
                }
        }
                                        
        err = 0;
        err = DmGetNextDatabaseByTypeCreator(true, &searchstate,
                                             sysFileTApplication,
                                             creatorid,
                                             true,
                                             &cardNo, &dbID);
        if(!err) {
                SysUIAppSwitch( cardNo,
                                dbID,
                                sysAppLaunchCmdNormalLaunch,
                                NULL);
                return true;
        }
        
        return false;
}


static void NotFound(void)
{
        SndCommandType sndCmd;

        /* Call the original */ 
        sndCmd.cmd = sndCmdFreqDurationAmp;
        sndCmd.param2 = 300;	// Duration
        SndGetDefaultVolume(NULL, NULL, &sndCmd.param3);
    
        sndCmd.param1 = 440;
        SndDoCmd( 0, &sndCmd, 0/* No Wait */ );
        sndCmd.param1 = 220;
        SndDoCmd( 0, &sndCmd, 0/* No Wait */ );
}


