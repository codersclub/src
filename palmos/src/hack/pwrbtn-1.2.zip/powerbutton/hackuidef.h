// $Id: hackuidef.h,v 1.4 2001/01/26 00:00:33 docwhat Exp $
//
//  PowerButton Hack - Allows customizing the Power button on Palms
//  Copyright (C) 2000-2001 Christian H�ltje
//
//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

// This file is kept simple (comment-wise) so that Pilrc can
// handle it well when it is included by the .rcp

/* Trap */
#define trapIDSysSleep		1000
#define trapnumSysSleep		0xa0b2

/* Preferences */
#define frmID_Prefs		2000
#define btnID_prefOK       	2001
#define btnID_prefCancel   	2002
#define strID_Prefs_Info	2003
#define popID_AppList		2004
#define lstID_AppList		2005
#define chkID_TimeRun		2006
#define chkID_UpOff		2007
#define lblID_Warning1		2008
#define lblID_Warning2		2009

#define fldID_time		2010

#define rbtID_HrUp		2012
#define rbtID_HrDown		2013
#define rbtID_MinUp		2014
#define rbtID_MinDown		2015


/* About */
#define appIconID       	3000
#define frmID_About       	3000
#define strID_About_Info       	3000

#define FTR_pStruct		0x115c // 4444
#define FTR_pListPtrs		0x115d // 4445

