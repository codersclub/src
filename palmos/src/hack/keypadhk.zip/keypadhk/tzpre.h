#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <System/SysEvtMgr.h>

#define NON_PORTABLE
#include <Hardware/Hardware.h>
#include <System/Globals.h>

void myEvtGetEvent(EventPtr event, SDWord timeout)
{
  int x, y, ichr;
  unsigned long lchr = 0;

  void (*last) ();
