#include "tzpre.h"

  FtrGet('KPHK', 1000, (DWord *) & last);

#include "tzpost.h"
