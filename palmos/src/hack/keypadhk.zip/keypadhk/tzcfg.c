#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#define NON_PORTABLE
#define asm
#include <Hardware/Hardware.h>

Boolean eventhandle(EventPtr event)
{
  FormPtr form;
  unsigned long l;

  form = FrmGetActiveForm();

  switch (event->eType) {

  case frmOpenEvent:

    FrmDrawForm(form);

    FtrGet('KPHK',2000,&l);

    switch( l ) {
    default:
    case '.':
      CtlSetValue(FrmGetObjectPtr(form, FrmGetObjectIndex(form, 2001)), 1);
      break;
    case ',':
      CtlSetValue(FrmGetObjectPtr(form, FrmGetObjectIndex(form, 2002)), 1);
      break;
    case '-':
      CtlSetValue(FrmGetObjectPtr(form, FrmGetObjectIndex(form, 2003)), 1);
      break;
    case 8:
      CtlSetValue(FrmGetObjectPtr(form, FrmGetObjectIndex(form, 2004)), 1);
      break;
    }

    FtrGet('KPHK',3000,&l);
    CtlSetValue(FrmGetObjectPtr(form, FrmGetObjectIndex(form, 2005+l)), 1);

    return 1;

  default:
    FrmHandleEvent(form, event);
    return 1;

  case ctlSelectEvent:
    switch (event->data.ctlEnter.controlID) {
    case 2001:
      FtrSet('KPHK', 2000, '.');
      break;
    case 2002:
      FtrSet('KPHK', 2000, ',');
      break;
    case 2003:
      FtrSet('KPHK', 2000, '-');
      break;
    case 2004:
      FtrSet('KPHK', 2000, 8);
      break;
    case 2005:
      FtrSet('KPHK', 3000, 0);
      break;
    case 2006:
      FtrSet('KPHK', 3000, 1);
      break;
    case 3000:
      FrmGotoForm(9000);
      break;
    }
    break;

  }

  return 0;
}
