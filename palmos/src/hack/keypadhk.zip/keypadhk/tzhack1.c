#include "tzpre.h"

  FtrGet('KPHK', 1001, (DWord *) & last);

#include "tzpost.h"
