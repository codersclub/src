#if 0
main()
{
#endif
  last(event, timeout);

  x = event->screenX - hwrGraffitiSplit;
  y = event->screenY - hwrGraffitiTop;

  if ((event->eType == penUpEvent || event->eType == penDownEvent || event->eType == penMoveEvent)) {
    if (y >= 0 && x >= 0 && y <= hwrGraffitiHeight && x <= hwrGraffitiWidth + hwrGraffitiLeft - hwrGraffitiSplit) {
      ichr = 0;
      if (event->eType == penDownEvent)
        FtrSet('KPHK', 4000, 1);
      else if (event->eType == penUpEvent) {
        FtrGet('KPHK', 4000, (DWord *) & lchr);
        if (lchr) {
          lchr = 0;
          /* 44x56 */
          x /= 15;
          y /= 14;
          y = 2 - y;
          FtrGet('KPHK', 3000, (DWord *) & lchr);  /* phone style */
          if (y >= 0) {
            if (lchr)
              y = 2 - y;
            ichr = 3 * y + x + '1';
          } else {
            if (lchr)
              x ^= 1;
            switch (x) {
            case 0:
              ichr = '0';
              break;
            case 1:
              lchr = 0;
              FtrGet('KPHK', 2000, (DWord *) & lchr);
	      if( !lchr )
		lchr = '.';
              ichr = lchr;
              break;
            case 2:
            case 3:
              ichr = -1;
              break;
            }
          }
          if (ichr != -1)
            EvtEnqueueKey(ichr, 0, 0);
        }
	else
	  ichr = -1;
      }
      if (ichr != -1)
        event->eType = nilEvent;
    } else
      FtrSet('KPHK', 4000, 0);
  }
}
