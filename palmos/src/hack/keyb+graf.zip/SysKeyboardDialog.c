//
// Copyright � 1999 Rui Oliveira (rco@di.uminho.pt)
//
// This is free software, licensed under the GNU Public License V2.
// See the file COPYING for details. 
//

#pragma pack(2)
#include <Pilot.h>
#include <System/Keyboard.h>  
#include <System/FeatureMgr.h>

#define RCO6	0x72636f36

void SysKeyboardDialogTrap(KeyboardType kbdType)
{
  void (*oldTrap) (KeyboardType);
  DWord poldTrap;

  FtrGet(RCO6, 1001, &poldTrap);
  oldTrap = (void (*) (KeyboardType)) poldTrap;

  FtrSet(RCO6, 2000, (DWord) 1); 
  oldTrap(kbdType);  
  FtrSet(RCO6, 2000, (DWord) 0); 
}


