//
// Copyright � 1999 Rui Oliveira (rco@di.uminho.pt)
//
// This is free software, licensed under the GNU Public License V2.
// See the file COPYING for details. 
//

#pragma pack(2)
#include <Pilot.h>
#include <System/FeatureMgr.h>
#include <System/SysEvtMgr.h>

#define RCO6    0x72636f36 

void EvtEnableGraffitiTrap(Boolean enable)
{
  void (*oldTrap) (Boolean);
  DWord poldTrap;
  DWord inKeyb;

  FtrGet(RCO6, 1000, &poldTrap);
  oldTrap = (void (*) (Boolean)) poldTrap;

  FtrGet(RCO6, 2000, &inKeyb); 
  if (inKeyb)
    oldTrap(true);  
  else
    oldTrap(enable);
}


