App/DA Launcher ver 0.6 (Feb 1, 2001)

This is a Hack program to launch Palm OS Applications and
Desk Accessories (DA).  For more information about DAs,
please visit:
    http://member.nifty.ne.jp/yamakado/da/

To install, just HotSync it, and check it on HackMaster.
No need to reset.  If you have an older version installed,
don't forget to check it off on HackMaster before HotSync.

App/DA Launcher divides the Applications button into four
parts.  Default binding is:
- upper-left		Applications.
- lower-left		Desk accessories.
- upper-right		History list.
- lower-right		Default launcher.

You may drag down or down-right from the Applications button
to launch the application or DA which was launched via App/DA
Launcher most recently.

When the list is displayed, you can select the application
or DA to launch by the stylus, or with graffiti input.

- Input initial letters.  If it matches with only one name,
  it is launched.  If it matches more, input more letters.

- If the input doesn't match exactly with initial letters,
  partial match is performed.  For example, if you have
  Date Book and Datebk3, input "do" to launch Date Book,
  or "d3" to launch Datebk3.

- By default, input space to select next item, backspace
  to clear input and select the first item, page up/down
  to scroll up or down the list, and return to launch
  current selection.

- Input feedback can be turned off.

Other features include:

- List with both applications and DAs is also possible.

- Multiple invocation of DAs is possible.
  (Launching too many DAs at once may be dangerous.)

- The number of applications or DAs is not limited.
  (This is why it's slow to display the list.)

- When a DA is launched, a new stack with 3,000 bytes is
  assigned.  (Stack size can be changed, or turned off.)

- History list is implemented.

- Localizers for DAs are supported.

	***

Settings

Tap & Drag dialog:

* Applications button (* 4):
  - None		Default launcher.
  - Apps		Applications.
  - DAs			Desk accessories.
  - Both		Both applications and DAs.
  - History		History list.
  - Last App		Launch the last application.
  - Last DA		Launch the last DA.

* Drag Up, etc: (What happens when you drag from the
                 Applications button.)
  - None		Nothing.  (Or, maybe another hack...)
  - Others are same as above.

Graffiti Input dialog:

* Tap Again: (What to do when the same part of Applications
              button is tapped or dragged again.)
  - Do Nothing		Do nothing.
  - Clear Input		Clear input and select the first item.
  - Close Launcher	Close App/DA Launcher.
  - OS Launcher		Default Launcher.
  - App-DA-History	Rotate App -> DA -> History -> App.
  - DA-App-History	Rotate DA -> App -> History -> DA.
  - Both-History	Rotate Both -> History -> Both.
  - Last App or DA	Last App if Apps part, Last DA if DAs part.
			Do nothing otherwise.

* Space:
  - Next Item		Select next item.
  - Input Space		Input space.

* Backspace:
  - Previous Item	Select previous item.
  - Clear Char		Clear previous letter.
  - Clear Input		Clear input and select the first item.

* Page Up/Down:
  - Scroll Line		Scroll one line.
  - Scroll Page		Scroll one page.

* Input Feedback:
  - Off			Input feedback is off.
  - On			Input feedback is on.

History dialog:

* Record History:
  - Off			History list is not changed.
  - Apps + DAs		Record history of applications and DAs.
			(Only apps and DAs launched via App/DA Launcher.)
  - All Apps + DAs	Record history of applications and DAs.
			(Includes apps launched without App/DA Launcher.)
  - Apps		Record history of applications.
			(Only apps launched via App/DA Launcher.)
  - All Apps		Record history of applications.
			(Includes apps launched without App/DA Launcher.)
  - DAs			Record history of DAs.

* Sort by:
  - Alphabetically	History list sorted alphabetically.
  - Last Used		Most recent item is on top.
  - Reverse Used	Most recent item is on bottom.

* # of Items:
  - 6			6 history items are displayed.
  - 10			10 history items are displayed.
  - 14			14 history items are displayed.

* Check Existence:
  - Off			Display non-existing (deleted) items.
  - On			Don't display non-existing (deleted) items.

* Clear History button: Clear the history list.

Advanced dialog:

* App Name Lookup:
  - Off			Display application's DB name.
  - On			Display 'tAIN' resource.

* DA Name Lookup:
  - Off			Display DA's DB name.
  - On			Display 'tAIN' resource.

* DA Localizer:
  - Off			Disable DA localizers.
  - On			Enable DA localizers.

* Multiple Launch:
  - Off			Disable multiple launch of same DA.
  - On			Enable multiple launch of same DA.

* Replace Stack:
  - Off			Don't replace stack.
  - 1,000 Bytes		Replace stack with 1,000 bytes.
  - 2,000 Bytes		Replace stack with 2,000 bytes.
  - 3,000 Bytes		Replace stack with 3,000 bytes.
  - 4,000 Bytes		Replace stack with 4,000 bytes.

Common:

* OK button: Save the settings and close the dialog

* Cancel button: Close the dialog without saving the settings

* Default button: Default settings.
                  (It's saved only when OK button is pressed.)

	***

Revision History

ver 0.6 (Feb 1, 2001)
- Work around fatal error when launching an application from the
  Palm OS 3.5 built-in launcher while there is no history.
- Don't record the default launcher registered to Palm OS 2.0 or
  later, and stop special treatment of LauncherIII, etc.
- Still don't record OS built-in launcher, LaunchPad, CoLauncher,
  and Click LC, if launched without App/DA Launcher.
- Process up/down/left/right keys, scrolling one page or line.

ver 0.5.4 (Mar 29, 2000)
- Add "Apps", "All Apps", and "DAs" to "Record History" setting.
- Don't record history of LaunchPad, CoLauncher, Commander, Home,
  Launch 'Em, LauncherIII, and SilverScreen, if launched without
  App/DA Launcher.

ver 0.5.3 (Feb 2, 2000)
- Add "Last App or DA" to "Tap Again" setting.
- Rename "Record History" items, and change default to "All Apps + DAs".

ver 0.5.2 (Jan 13, 2000)
- Add "Check Existence" setting to the "History" dialog.

ver 0.5.1 (Jan 7, 2000)
- Add "App-DA-History", "DA-App-History", and "Both-History" to
  "Tap Again" setting.

ver 0.5 (Jun 15, 1999)
- Record history of applications launched without App/DA Launcher.
- Bug fix: history list honors "App Name Lookup" setting.

ver 0.4.9 (Jun 4, 1999)
- Add a lot of settings.

ver 0.4.4 (Feb 26, 1999)
- Switch back feature is implemented.

ver 0.4.3 (Jan 22, 1999)
- Bug fix: save and restore a4 register.

ver 0.4.2 (Jan 11, 1999)
- It can run on Palm OS 1.0, again.
- Decrease code size.

ver 0.4.1 (Jan 8, 1999)
- Clear graffiti shift state on launch.
- Clean up source code.

ver 0.4 (Jan 7, 1999)
- History list is implemented.
- Disable launcher when the device is locked.
- Fix current font and insertion point problems.
- Default stack size is increased to 3,000 bytes.

ver 0.3 (Dec 18, 1998)
- Settings panel is added.
- List with both applications and DAs is also possible.

ver 0.2 (Dec 10, 1998)
- Multiple invocation of DAs is possible.
- Implement page up/down keys and graffiti input.

ver 0.1 (Nov 30, 1998)
- The first release.

	***

App/DA Launcher is a free software.  You may re-distribute it
freely for non-commercial purposes.  For commercial purposes,
please contact the author.

If you have any comment, please e-mail to hoshi@sra.co.jp with:
- Your environment (type of device, OS version, and list of
  installed applications and DAs).
- Whether it works well or not.
- Any comment, suggestion, etc.

Hoshi Takanori (hoshi@sra.co.jp, http://www.sra.co.jp/people/hoshi/)
