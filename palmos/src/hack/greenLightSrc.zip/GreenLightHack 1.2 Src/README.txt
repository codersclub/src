  ____                     _     _       _     _   _   _            _    
 / ___|_ __ ___  ___ _ __ | |   (_) __ _| |__ | |_| | | | __ _  ___| | __
| |  _| '__/ _ \/ _ \ '_ \| |   | |/ _` | '_ \| __| |_| |/ _` |/ __| |/ /
| |_| | | |  __/  __/ | | | |___| | (_| | | | | |_|  _  | (_| | (__|   < 
 \____|_|  \___|\___|_| |_|_____|_|\__, |_| |_|\__|_| |_|\__,_|\___|_|\_\
-----------------------------------|___/----------------------------------                                
README.txt                                             version 1.2, 6/6/99

by Douglas I. Anderson


Description
===========
GreenLightHack is a HackMaster hack that reverses the polarity of the
screen when the backlight is turned on (all white pixels become black
and all black pixels become white).  This has the effect of making the
backlight on the old Palm models (Palm III and below) look like the
new ones, and the backlight on the new ones (Palm IIIx and above) look
like the old ones.

This hack is designed for the PalmPilot, the Palm III, the Palm IIIx,
the Palm V, and the Palm VII.  You should use it on other devices at your
own risk.

This hack comes in three flavors:
1.2a - Works like 1.0 (the only thing different is the version number).
       In other words, <a>lways does the inversion.
1.2u - <U>sually does the inversion.  However, if you enter a tap into
       the graffiti area before turning on the backlight (indicates that
       you're going to enter in a punctuation mark next), the inversion
       will not happen.
1.2s - <S>ometimes does the inversion.  Like the usually version except
       that inversion _only_ happens if you are in punctuation mode.


Why?
====
Why does this hack exist?  Well, the other day I was looking at LightHack
by Neal Bridges (http://www.interlog.com/~nbridges/).  Seemed like a cool
hack, but it didn't seem worth $5.00.  I decided to delete the hack
(since I don't like keeping shareware that I don't pay for).

However, soon after I was browsing through the DragonBall CPU manual
(honestly...I don't usually spend my time doing things like this) and
noticed that inverting the screen was as simple as flipping a single bit.
Having already played with hacks, I decided to write up this one.  :)

Why is it called "GreenLightHack"?  Well, it's a hack to invert the
backlight, but it's free (it saves you "green").

Note: this release is not intended to be a slam against shareware in
general or Neal Bridges in particular.  I think shareware is great and
advocate paying for it if you use it.  Looking at Neal Bridges page, he
has some other cool programs.  I invite you to visit there.


Requirements
============
* A PalmPilot (Personal/Pro), a Palm III, a Palm IIIx, a Palm V, or a
  Palm VII.
* Approximately 1K available memory (a bit less).
* The HackMaster extension from DaggerWare.  To get a copy, go to:
  <http://www.daggerware.com/hackmstr.htm>.  Note that HackMaster is
  shareware.  Please pay for it.


Installation
============
IMPORTANT: if you do not uninstall a previous version of GreenLightHack
before installing this one, your Palm will crash.  Nuff said.

If you haven't already installed HackMaster, do that first.  Follow
instructions from the HackMaster web page, which can be found at
<http://www.daggerware.com/hackmstr.htm>.  Remember to register HackMaster.

Now, simply install appropriate GreenLightHack ".prc" file as you would
any other ".prc" file (for help on choosing your version, see the
description above).  As a safety precaution, you should uninstall all
hacks through HackMaster first (actually, this is a good general procedure, 
since doing so means that HotSync can defragment memory if it needs to).

Go into HackMaster and click on the box to select GreenLightHack.


That's it.


Legal Junk & Distribution
=========================
This program and its source code are in the public domain.  Enjoy.  If
you're happy with this program, feel free to e-mail me.  Note: although I
don't anticipate any trouble I should say that I take no responsibility
for any actions this program takes.  


Contact Info
============
Probably the easiest way to contact me is via e-mail.  However, I always
appreciate getting real mail...
      e-mail:  dianders@cs.stanford.edu
      address: Doug Anderson
               1065 16th Ave.
               Redwood City, CA 94063
      web:     <http://www-cs-students.stanford.edu/~dianders/>
...hope to hear from you.


Known bugs
==========
* If your device resets when GreenLightHack is active with the 
  backlight, your screen will be inverted (doh!).  To fix this, turn the
  backlight on and off.


Version History
===============
1.2, 06/06/99 - The always and sometimes versions always turn inversion off
                when the backlight is shut off...even if the the graffiti state
                has changed.
1.1, 03/23/99 - Now comes in always, usually, and sometimes varieties
                based on a suggestion by Siegfried Runge.
1.0, 03/23/99 - Initial public release.