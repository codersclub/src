/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;
import java.io.*;
import java.util.*;

public final class TaltResource extends ResourceRecord implements RawIO
{
	public final static short INFORMATION  = 0;
	public final static short CONFIRMATION = 1;
	public final static short WARNING      = 2;
	public final static short ERROR        = 3;

    short  alertType;
    short  helpId;
    short  defaultButton;
    Vector buttonText;
    String alertTitle;
    String alertMessage;
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public TaltResource() 
    {
        this((short)0);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public TaltResource(int id) 
    {
        super(ResourceRecord.TALT,(short)id);
        buttonText = new Vector();
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void addButton(String s)
    {
        buttonText.addElement(s);
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setTitle(String s)
    {
        alertTitle = s;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setMessage(String s)
    {
        alertMessage = s;
    }
/*
00 02 warn
00 00 no help
00 01 one button
00 00 def. button number
4F 70 65 6E 20 4C 6F 67 6F                                          Open?Logo
20 48 61 63 6B 00 4B 61 6E 6E 20 4C 6F 67 6F 20                     ?Hack?Kann?Logo?
44 61 74 65 6E 62 61 6E 6B 20 6E 69 63 68 74 20                     Datenbank?nicht?
F6 66 66 6E 65 6E 00 4F 6B 00                                       ?ffnen?Ok?
*/
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void write(DataOutput out) throws IOException 
    {
        out.writeShort(alertType);                   
        out.writeShort(helpId);
        out.writeShort(buttonText.size());
        out.writeShort(defaultButton);

        out.writeBytes(alertTitle); 
        out.writeByte(0);
        out.writeBytes(alertMessage); 
        out.writeByte(0);

		// Write text for each button
        for (int i=0; i<buttonText.size(); i++)
        {
            out.writeBytes((String)buttonText.elementAt(i));
            out.writeByte(0);                   
        }
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
