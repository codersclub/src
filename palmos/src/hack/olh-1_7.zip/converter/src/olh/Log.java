/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;

import java.awt.*;
import javax.swing.*;
import java.io.*;
import olh.*;

public class Log
{
    private static boolean isEnabled = false;
    private static boolean hasGraphic = false;

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void enableGraphic()
    {
        hasGraphic = true;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void disableGraphic()
    {
        hasGraphic = false;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void enableLogging()
    {
        isEnabled = true;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void disableLogging()
    {
        isEnabled = false;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void println(String s)
    {
        if (isEnabled) 
        {
            System.out.println(s);
        }
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void println(Exception e)
    {
        if (isEnabled) 
        {
            System.out.println(e.toString());
            e.printStackTrace();
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void showMessageDialog(Component parentComponent, Object message, String title, int messageType)
    {
        showMessageDialog(parentComponent, message,title, messageType, null);
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public static void showMessageDialog(Component parentComponent, Object message, String title, int messageType, Icon icon)
    {
        if (hasGraphic)
        {
            JOptionPane.showMessageDialog(parentComponent, message, title,messageType,icon);
        }
        else
        {
            System.out.println(title);
            System.out.println(message);
        }                    
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
