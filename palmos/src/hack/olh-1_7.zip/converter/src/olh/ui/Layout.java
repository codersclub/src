/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.io.*;
import olh.*;

public class Layout   
{
    String layout;
    
    public Layout(String filename)
    {
        try
        {
            Log.println("Layout file="+filename);
            StringBuffer buffer = new StringBuffer();
            InputStream in = this.getClass().getResourceAsStream(filename);
            int data;
            do 
            {
                data = in.read();
                if (data != -1)
                {
                    buffer.append((char)data);
                }
            }
            while (data != -1);
            layout = buffer.toString();
            //Log.println(layout);
        }
        catch (IOException e)
        {
            System.out.println(e.toString());
        }
    }
        
    public static String getLayout(String filename)
    {
        Layout ll= new Layout(filename);
        return ll.layout;
    }
}
