/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.io.*;
import java.awt.*;
import java.awt.image.*;
import java.awt.color.*;
import java.util.zip.*;
import javax.swing.*;

import Acme.JPM.Filters.*;
import Acme.JPM.Decoders.PpmDecoder;
import Acme.JPM.Encoders.PpmEncoder;

import olh.Log;

public class Logo implements Serializable
{
    //-------------------------------------------------------------------------
    // chain of images 
    //   +-pixeldata            : the loaded image as compressed PPM file
    //     +-sourceimage        : the resized or centered image
    //       +-indexedimage     : the gamma corrected image mapped to colormap
    //         |                  index or direct color image
    //         +-previewimage   : add gray, backlight or color to indexedimage
    //         +-palmpixel      : array of pixel prepared for TbmpResource
    //-------------------------------------------------------------------------
    public static final int FORMAT_1BIT         = 0;
    public static final int FORMAT_2BIT         = 1;
    public static final int FORMAT_4BIT         = 2;
    public static final int FORMAT_8BITCOLOR    = 3;
    public static final int FORMAT_16BITCOLOR   = 4;

    public static final int COMPRESS_NONE       = 0;
    public static final int COMPRESS_SCANLINE   = 1;
    public static final int COMPRESS_RLE        = 2;
    
    public static final int DISPLAY_GREEN       = 0;
    public static final int DISPLAY_GREEN_BACKL = 1;
    public static final int DISPLAY_COLOR       = 2;

    private static final int PWIDTH             = GUI.screenWidth;  // was 160;
    private static final int PHEIGHT            = GUI.screenHeight; // was 160;
    
    String  name                                = "";
    String  filename                            = "";
    int     compression                         = COMPRESS_SCANLINE;
    int     format                              = FORMAT_1BIT;
    int     displayType                         = DISPLAY_GREEN;
    double  gamma                               = 1.0;
    boolean bResizeSourceImage                  = false;
    boolean bCenterSourceImage                  = false;
    byte[]  pixeldata                           = null; // The base image as PPM 

    transient Component component;      // To create Images
    transient Image  sourceImage;       // The base picture for display
    transient Image  indexedImage;      // The converted picture with index to color/gray scale or directcolor
    transient Image  previewImage;      // The preview picture
    transient boolean isActualPicture;
    transient boolean isActualIndexPicture;
    transient MediaTracker imageTracker = new MediaTracker(new JButton());
    
    //-------------------------------------------------------------------------
    // Constructors
    //-------------------------------------------------------------------------
    public Logo()
    {
        this("Unnamed");
    }

    public Logo(String s)
    {
        name = s;
        sourceImage = null;
        isActualPicture = false;
        isActualIndexPicture = false;
    }
    
    public Logo(String s, ImageProducer producer)
    {
        this(s);
        try 
        {
            // Write the image as PPM Image to a byte array as base image
            // See also Method "load"
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            GZIPOutputStream zos = new GZIPOutputStream(bos);
            PpmEncoder encoder = new PpmEncoder(producer, zos);
            encoder.encode();
            zos.close();
            pixeldata = bos.toByteArray();
        }
        catch (IOException e)
        {
            Log.println(e.toString());
        }
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setComponent(Component c)
    {
        component = c;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public String getName() 
    {
        return name; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setName (String s) 
    {
        name = s;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getCompression() 
    {
        return compression; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setCompression(int c) 
    {
        compression = c;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getFormat() 
    {
        return format; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setFormat(int f) 
    {
        format = f;
        isActualPicture = false;
        isActualIndexPicture = false;
        Log.println("Logo:setFormat="+f);
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getBitsPerPixel() 
    {
        return 1<<format; 
    }

    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public double getGamma () 
    {
        return gamma; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setGamma(double g) 
    {
        gamma = g;
        isActualPicture = false;
        isActualIndexPicture = false;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getDisplayType () 
    {
        return displayType; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setDisplayType(int d) 
    {
        displayType = d;
        isActualPicture = false;
        isActualIndexPicture = false;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public boolean getResizeSourceImage() 
    {
        return bResizeSourceImage; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setResizeSourceImage(boolean b) 
    {
        if (bResizeSourceImage != b)
        {
            bResizeSourceImage = b;
            makeSourceImageFromPixeldata();
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public boolean getCenterSourceImage() 
    {
        return bCenterSourceImage; 
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setCenterSourceImage(boolean b) 
    {
        if (bCenterSourceImage != b)
        {
            bCenterSourceImage = b;
            makeSourceImageFromPixeldata();
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public Image getPreviewImage () 
    {
        if (!isActualPicture)
        {
            makePreviewImage();
        }
        return previewImage;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public Image getSourceImage() 
    {
        if (sourceImage == null)
        {
            makeSourceImageFromPixeldata();
        }
        return sourceImage;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public String toString()
    {
        return name;
//      return name+":"+format+":"+compression+":"+gamma;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void load(String fileName)
    {
        this.filename = fileName;
        try 
        {
            if (pixeldata == null)
            {
                // Read in the file contents
                RandomAccessFile raf = new RandomAccessFile(filename, "r");
                byte[] filecontents = new byte[(int)raf.length()];
                raf.readFully(filecontents);
                raf.close();
                
                // Create a image. Available formats depend on installed Java VM
                Image image = Toolkit.getDefaultToolkit().createImage(filecontents);
                imageTracker.addImage(sourceImage, 0);
                imageTracker.waitForID(0);
                
                // Write the image as PPM Image to a byte array as base image
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                GZIPOutputStream zos = new GZIPOutputStream(bos);
                PpmEncoder encoder = new PpmEncoder(image, zos);
                encoder.encode();
                zos.close();
                pixeldata = bos.toByteArray();
                Log.println("Logo.load pixeldata size="+pixeldata.length);
            }

            if (pixeldata != null) 
            {
                makeSourceImageFromPixeldata();
            }

        } catch (IOException e) 
        {
            Log.showMessageDialog(component, 
                    GUI.eloadImage+" \n"+filename, GUI.lWarning,JOptionPane.WARNING_MESSAGE);
            Log.println(e); 
        } catch (Exception e) 
        {
            Log.showMessageDialog(component, 
                    GUI.ecreateImage+" \n"+filename, GUI.lWarning,JOptionPane.WARNING_MESSAGE);
            Log.println(e);
        }
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    private void makeSourceImageFromPixeldata()
    {
        try 
        {
            ByteArrayInputStream bis = new ByteArrayInputStream(pixeldata);
            GZIPInputStream zis = new GZIPInputStream(bis);
            ImageProducer producer = new PpmDecoder(zis);            

            sourceImage = Toolkit.getDefaultToolkit().createImage(producer);

            imageTracker.addImage(sourceImage, 1);
            imageTracker.waitForID(1);

            int iw = sourceImage.getWidth(null);
            int ih = sourceImage.getHeight(null);

            Log.println("Logo:makeSourceImageFromPixeldata sourcesize="+pixeldata.length+" w="+iw+" h="+ih);

            if (iw == -1 || ih == -1)
            {
                Log.showMessageDialog(component, 
                    GUI.ecreateImage+" \n"+filename, GUI.lWarning,JOptionPane.WARNING_MESSAGE);
            }
            else
            {
                if (iw != PWIDTH || ih != PHEIGHT)
                {
                    // loaded image has not the palm screenresolution
                    // make a new Image
                    Image newImage;
                    if (bResizeSourceImage)
                    {
                        // resize it to palm screenresolution
                        newImage = sourceImage.getScaledInstance(PWIDTH,PHEIGHT,Image.SCALE_AREA_AVERAGING);
                        imageTracker.addImage(newImage, 2);
                        imageTracker.waitForID(2);

                        sourceImage = newImage;
                    } 
                    else
                    { 
                        // Place the image
                        newImage = component.createImage(PWIDTH,PHEIGHT);
                        Graphics g = newImage.getGraphics();
                        g.clearRect(0,0,PWIDTH,PHEIGHT);
                        int x = (bCenterSourceImage && iw < PWIDTH)  ? (PWIDTH - iw)/2 : 0;
                        int y = (bCenterSourceImage && ih < PHEIGHT) ? (PHEIGHT - ih)/2: 0;

                        g.drawImage(sourceImage,x,y,Color.white,null);

                    }
                    sourceImage = newImage;
                }
            }

        } catch (Exception e) 
        {
            Log.showMessageDialog(component, 
                    GUI.ecreateImage, GUI.lWarning,JOptionPane.WARNING_MESSAGE);
            Log.println(e);
        }

        isActualPicture = false;
        isActualIndexPicture = false;
    }
    
    //-------------------------------------------------------------------------
    // Convert the source image to a indexed image by using some limits
    //-------------------------------------------------------------------------
    private void makeIndexedImage() 
    {
        Log.println("Logo:makeIndexedImage");
        if (sourceImage == null)
        {
            makeSourceImageFromPixeldata();
        }

        Image image = sourceImage;
        if (image != null)
        {   
            Log.println("Logo:makeIndexedImage1 source-w="+sourceImage.getWidth(null)+" h="+sourceImage.getHeight(null));
            FilteredImageSource filteredimagesource;

            // Do Gamma correction
            if (gamma != 1.0)
            {
                ImageProducer producer = sourceImage.getSource();            
                Gamma gammafilter = new Gamma(producer,gamma);
                filteredimagesource = new FilteredImageSource(producer, gammafilter);
                image = Toolkit.getDefaultToolkit().createImage(filteredimagesource);
            }
            Log.println("Logo:makeIndexedImage2 gamma done");

            // Convert to Index image
            int bitsPerPixel = getBitsPerPixel();
            ImageFilter g = (format == FORMAT_8BITCOLOR || format == FORMAT_16BITCOLOR)
                          ?  (ImageFilter)new PalmColorPixelFilter(image.getSource(), bitsPerPixel)
                          :  (ImageFilter)new PalmGrayPixelFilter(image.getSource(), bitsPerPixel);

            filteredimagesource = new FilteredImageSource(image.getSource(), g);
            image = Toolkit.getDefaultToolkit().createImage(filteredimagesource);
            try {
                imageTracker.addImage(image, 3);
                imageTracker.waitForID(3);
            } catch (InterruptedException e) {}

            Log.println("Logo:makeIndexedImage3 filtered Image done");
            indexedImage = image;
            isActualIndexPicture = true;
        }
    }

    //-------------------------------------------------------------------------
    // Convert the indexed image to a preview image by adding gray, green
    // or color
    //-------------------------------------------------------------------------
    private void makePreviewImage() 
    {
        Log.println("Logo:makePreviewImage");
        if (!isActualIndexPicture)
        {
            makeIndexedImage();
        }

        if (indexedImage != null)
        {   
            // Convert to Grayscale image
            ColorMapper cMapper = null;

            switch (displayType)
            {
                case DISPLAY_GREEN:
                    cMapper = new PalmGreenScale(getBitsPerPixel(),false);
                    break;
                case DISPLAY_GREEN_BACKL:
                    cMapper = new PalmGreenScale(getBitsPerPixel(),true);
                    break;
                case DISPLAY_COLOR:
                    cMapper = (format == FORMAT_8BITCOLOR||format == FORMAT_16BITCOLOR) 
                            ? (ColorMapper)new PalmColorScale(getBitsPerPixel())
                            : (ColorMapper)new PalmGrayScale(getBitsPerPixel());
                    break;
                default:
                    throw new RuntimeException("Unknown displayType");
            }
            ImageFilter g = new PalmPreviewFilter(indexedImage.getSource(), cMapper);
            FilteredImageSource filteredimagesource = new FilteredImageSource(indexedImage.getSource(), g);
            previewImage = Toolkit.getDefaultToolkit().createImage(filteredimagesource);
            try {
                imageTracker.addImage(previewImage, 4);
                imageTracker.waitForID(4);
            } catch (InterruptedException e) {}

            isActualPicture = true;
        }
    }

    //-------------------------------------------------------------------------
    // Convert the indexed image to an array of bytes for use as Bitmap resource
    //-------------------------------------------------------------------------
    public short[][] getPalmPixel() 
    {
        short[][] pixels = new short[PWIDTH][PHEIGHT];

        Log.println("Logo:getPalmPixel");
        if (!isActualIndexPicture)
        {
            makeIndexedImage();
        }

        if (indexedImage != null)
        {
            PixelGrabber p = new PixelGrabber(indexedImage,0,0,PWIDTH,PHEIGHT,true);
            try {
                if (p.grabPixels())
                {
                    int intPixels[] = (int[])p.getPixels();
                    int index=0;
                    for (int row=0;row<PHEIGHT;row++)
                    {
                        for (int col=0;col<PWIDTH;col++)
                        {
                            switch (format)
                            {
                                case FORMAT_8BITCOLOR: 
                                case FORMAT_16BITCOLOR: 
                                    pixels[row][col] = (short)intPixels[index];
                                    break;
                                default:
                                    // 1,2 and 4bits have to be inverted
                                    pixels[row][col] = (short)~intPixels[index];
                                    break;
                            }
    //                      Log.println("getPalmPixel i="+index+" p="+pixels[row][col] );
                            index++;
                        }
                    }
                }
            } catch (InterruptedException e)
            {
                e.printStackTrace();
                pixels = null;
            }
        }
        else
        {
            pixels = null;
        }
        return pixels;
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
