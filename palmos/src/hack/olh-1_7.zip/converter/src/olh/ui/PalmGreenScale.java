/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

public class PalmGreenScale implements ColorMapper
{
    private int[] greens;
    int[] redMax   = { 0x7B, 0x64};    // From POSE
    int[] greenMax = { 0x8C, 0xF0};
    int[] blueMax  = { 0x5A, 0xDC};
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public PalmGreenScale (int bitsPerPixel, boolean useBacklight)
    {
        int numGreens = 1<<bitsPerPixel;
        int backlight = (useBacklight) ? 1 : 0 ;
        greens = new int[numGreens];
        for (int i=0; i<numGreens;i++)
        {
            int red   = (redMax[backlight]   * (i+1)  / numGreens);
            int green = (greenMax[backlight] * (i+1)  / numGreens);
            int blue  = (blueMax[backlight]  * (i+1)  / numGreens);
            greens[i] = (red&0xFF)<<16 | (green&0xFF)<<8 | (blue&0xFF);
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getColor(int red, int green, int blue, int pixel)
    {
        int color = 0;
        int index = red;
        if (index < greens.length)
        {
            color = greens[index];
        }
        return color;
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
