/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.awt.image.*;
import Acme.*;
import Acme.JPM.Filters.*;

class PalmGrayPixelFilter extends RGBAllFilter
{
    private static final int[][] grayLimits =
    {
        { 0                },
        { 0, 128           },
        { 0,  64, 128, 196 },
        { 0                },
        { 0,  16, 32, 48, 64, 80, 96, 112, 128, 144, 160, 176, 192, 208, 224, 240 },
    };
    private int[] limits;
    private IntHashtable mappingCache;
    
    public PalmGrayPixelFilter(ImageProducer producer, int bitsPerPixel)
    {
        super(producer);
        limits = grayLimits[bitsPerPixel];
        mappingCache = new IntHashtable();
    }

    //-------------------------------------------------------------------------
    // Convert the colored image into a indexed image
    // the index can be used to create the corresponding preview image
    // or the real palm bitmap resource
    // for easy use, the index is mapped to red, green, and blue component
    //-------------------------------------------------------------------------
    public void filterRGBAll( int width, int height, int[][] rgbPixels )
    {
        int[][] newPixels = new int[height][width];
        for ( int row = 0; row < height; ++row )
        {
            for ( int col = 0; col < width; ++col )
            {
                int pixel = rgbPixels[row][col];
                int index = 0;

                Integer i = (Integer)mappingCache.get(pixel);
                if (i == null)
                {
                    int r = rgbModel.getRed( pixel );
                    int g = rgbModel.getGreen( pixel );
                    int b = rgbModel.getBlue( pixel );
                    int v = (int)((r*0.299999999D + g*0.5888888D + b*0.11D));
                    if(v < 0) v = 0;
                    if(v > 255) v = 255;

                    for (int k=0;k<limits.length;k++)
                    {
                        if (v > limits[k])
                        {
                            index = k;
                        }
                    }
                    mappingCache.put(pixel, new Integer(index));
                } 
                else
                {
                    index = i.intValue();
                }
                int newPixel = (index&0xFF)<<16 | (index&0xFF)<<8 | (index&0xFF);
                newPixels[row][col] = 0xFF000000 | newPixel;
            }
        }
        setPixels( width, height, newPixels );
     }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
