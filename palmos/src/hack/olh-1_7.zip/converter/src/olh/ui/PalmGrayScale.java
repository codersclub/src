/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

public class PalmGrayScale implements ColorMapper
{

    public static byte grays1[] = new byte[] { 
        (byte)0, (byte)255
    };

    public static byte grays2[] = new byte[] { 
        (byte)0,   (byte) 96, (byte)196, (byte)255
    };

    public static byte grays4[] = new byte[] { 
        (byte)0,   (byte)17,  (byte)34,  (byte)51,
        (byte)68,  (byte)85,  (byte)102, (byte)119,
        (byte)136, (byte)153, (byte)170, (byte)187,
        (byte)204, (byte)221, (byte)238, (byte)255
    };

    private byte[] grays = null;

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public PalmGrayScale (int bitsPerPixel)
    {
        switch (bitsPerPixel)
        {
            case 1:
                grays  = grays1;
                break;
            case 2:
                grays  = grays2;
                break;
            case 4:
                grays  = grays4;
                break;
            case 8:
                grays  = new byte[255];
                for (int i=0; i<grays.length;i++)
                {
                    grays[i] = (byte)i;
                }
                break;
            default:
                grays = null;
                break;
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public int getColor(int red, int green, int blue, int pixel)
    {
        int color = 0;
        int index = red;
        if (index < grays.length)
        {
            int gray = grays[index];
            color = (gray&0xFF)<<16 | (gray&0xFF)<<8 | (gray&0xFF);
        }
        return color;
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
