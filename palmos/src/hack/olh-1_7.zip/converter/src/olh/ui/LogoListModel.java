/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.util.*;
import javax.swing.*;

public class LogoListModel extends DefaultListModel
{
    String dbInfo;
    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public LogoListModel(String dbInfo) 
    {
        this.dbInfo = dbInfo;
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void fireContentsChanged(int index)
    {
        fireContentsChanged(this,index,index);        
    }
    
    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setDbInfo(String s)
    {
        dbInfo = s;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public String getDbInfo()
    {
        return dbInfo;
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void addAll(Vector v)
    {
        if (v != null)
        {
            Enumeration e = v.elements();
            while (e.hasMoreElements())
            {
                addElement(e.nextElement());
            }
        }
    }
    
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
