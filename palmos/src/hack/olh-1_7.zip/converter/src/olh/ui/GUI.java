/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import javax.swing.filechooser.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.io.*;
import java.net.*;
import htmllayout.*;

import olh.*;
import olh.importer.*;

public class GUI extends JFrame  
{
    public  static String   lWarning        = "Warning";
    public  static String   lInfo           = "Information";
    public  static String   eLoadFile       = "Cannot load File";
    public  static String   eSaveFile       = "Cannot save File";
    public  static String   eloadImage      = "Cannot load Image";
    public  static String   ecreateImage    = "Cannot create Image";
    public  static String   lGenerated      = "PDB generated"; 
    public  static int      screenWidth     = 160;
    public  static int      screenHeight    = 160;

    private static final String   version         = "Version 1.6";
    private static final String   nPlusName       = "plus.gif";
    private static final String   nCutName        = "cut.gif";
    private static final String   nPasteName      = "paste.gif";
    private static final String   nUpName         = "up.gif";
    private static final String   nDownName       = "down.gif";
    private static final String   nOpenName       = "open.gif";
    private static final String   nSaveName       = "save.gif";
    private static final String   nNewName        = "new.gif";
    private static final String   nExitName       = "exit.gif";
    private static final String   nGenerateName   = "generate.gif";
    private static final String   nIconName       = "olh.gif";
    private static final String   nEditName       = "edit.gif";
    private static final String   nHelpName       = "help.gif";
    private static final String   nAboutName      = "about.gif";
    private static final String   layoutName      = "l-top2.txt";

    private static String[] formatString    = { "1 Bit","2 Bit", "4 Bit", "8 Bit Color", "16 Bit Color" };
    private static String[] compressString  = { "None","Scanline","RLE" };
    private static String[] transformString = { "None","Dithering", "Error Diffusion" };
    private static String[] displayString   = { "Green", "Green Backlight", "Color"};

    private static String   lName           = "Name:";
    private static String   lTransform      = "Transform";
    private static String   lDisplay        = "Previewtype";
    private static String   lFormat         = "Format";
    private static String   lCompression    = "Compression";
    private static String   lGamma          = "Gamma";
    private static String   lResize         = "Resize";
    private static String   lCenter         = "Center";

    private static String   lFileM          = "File";
    private static String   lLogoM          = "Logo DB";
    private static String   lHelpM          = "Help";
    private static String   lLoadI          = "Load Images";
    private static String   lSaveI          = "Save Image";
    private static String   lCutI           = "Cut Image";
    private static String   lPasteI         = "Paste Image";
    private static String   lMoveUp         = "Move Up";
    private static String   lMoveDown       = "Move Down";
    private static String   lEditDbInfo     = "Edit DB Info";
    private static String   lLoad           = "Load";
    private static String   lSave           = "Save";
    private static String   lGenerate       = "Generate PDB";
    private static String   lQuit           = "Quit";
    private static String   lAbout          = "About";
    private static String   lNew            = "New";
    private static String   lAboutText      = "Open logo Hack Creator\n"
                                            + version+"\n" 
                                            + "http://olh.sourceforge.net\n"
                                            + "(C) 2001 by Frank Schnekenb�hl <f.sck@web.de>\n\n";

    private static String   lFilesize       = "Filesize";
    private static String   lBytes          = "Bytes";
    private static String   lLicence        = "GPL";
    private static String   lDefaultDbInfo  = "Made with OLH Creator";
    
    private static boolean  workaroundIBMLinuxBug = false;

    private JFrame              frame;
    private JList               logoList;
    private LogoListModel       logoListModel;
    private JComboBox           transformCB;
    private JComboBox           displayCB;
    private JComboBox           formatCB;
    private JComboBox           compressCB;
    private JTextField          nameTF;
    private JSlider             gammaS;
    private JLabel              origLabel;
    private JLabel              palmLabel;
    private JCheckBox           resizeC;
    private JCheckBox           centerC;
    private JButton             upB;
    private JButton             downB;
    private JButton             plusB;
    private JButton             cutB;
    private JButton             pasteB;
    private JButton             editB;
    private JMenuBar            menuBar;
    private JMenu               fileMenu;
    private JMenu               logoMenu;
    private JMenu               helpMenu;
    private String              lastLogoDirectory = ".";
    private String              lastDirectory     = ".";
    private Action              loadImageAction;
    private Action              saveImageAction;
    private Action              moveUpImageAction;
    private Action              moveDownImageAction ;
    private Action              cutImageAction;
    private Action              pasteImageAction;
    private Action              editDbInfoAction;
    private Action              loadFileAction;
    private Action              saveFileAction;
    private Action              exportFileAction;
    private Action              exitAction;
    private Action              aboutAction;
    private Action              newAction;
    private Logo                cutLogo = null;

    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public GUI() 
    {
        super("Open Logo Hack Creator");

        frame = this;

        addWindowListener( new WindowAdapter() {
            public void windowClosing(WindowEvent e) { System.exit(0); } } );

        logoListModel = new LogoListModel(lDefaultDbInfo);

        logoList = new JList(logoListModel);

        JScrollPane listScrollPane = new JScrollPane(logoList);
        listScrollPane.setMinimumSize(new Dimension(230,250));
        listScrollPane.setPreferredSize(new Dimension(230,250));

        Dimension imageDimension = new Dimension(screenWidth+5,screenHeight+5);
        origLabel = new JLabel();
        origLabel.setVerticalAlignment(SwingConstants.TOP);
        origLabel.setHorizontalAlignment(SwingConstants.LEFT);
        origLabel.setMinimumSize(imageDimension);
        origLabel.setPreferredSize(imageDimension);
        origLabel.setBorder(BorderFactory.createLoweredBevelBorder());

        palmLabel = new JLabel(/*palmPic*/);
        palmLabel.setVerticalAlignment(SwingConstants.TOP);
        palmLabel.setHorizontalAlignment(SwingConstants.LEFT);
        palmLabel.setMinimumSize(imageDimension);
        palmLabel.setPreferredSize(imageDimension);
        palmLabel.setBorder(BorderFactory.createLoweredBevelBorder());
        PalmImageAdapter palmImageAdapter = new PalmImageAdapter();
        logoList.addListSelectionListener(palmImageAdapter);
        
        LogoImageAdapter logoImageAdapter = new LogoImageAdapter();
        logoList.addListSelectionListener(logoImageAdapter);

        JLabel name      = new JLabel(lName);
        JLabel transform = new JLabel(lTransform);
        JLabel display   = new JLabel(lDisplay);
        JLabel format    = new JLabel(lFormat);
        JLabel compress  = new JLabel(lCompression);
        JLabel gammaL    = new JLabel(lGamma);

        ResizeAdapter resizeAdapter = new ResizeAdapter(); 
        resizeC = new JCheckBox(lResize);
        resizeC.addActionListener(logoImageAdapter);
        resizeC.addActionListener(palmImageAdapter);
        resizeC.addActionListener(resizeAdapter);
        logoList.addListSelectionListener(resizeAdapter);
        
        CenterAdapter centerAdapter = new CenterAdapter(); 
        centerC = new JCheckBox(lCenter);
        centerC.addActionListener(logoImageAdapter);
        centerC.addActionListener(palmImageAdapter);
        centerC.addActionListener(centerAdapter);
        logoList.addListSelectionListener(centerAdapter);

        DisplayAdapter displayAdapter = new DisplayAdapter();
        displayCB = new  JComboBox(displayString);        
        displayCB.setSelectedIndex(0);
        displayCB.addActionListener(palmImageAdapter);
        displayCB.addActionListener(displayAdapter);
        logoList.addListSelectionListener(displayAdapter);

        FormatAdapter formatAdapter = new FormatAdapter();
        formatCB = new JComboBox(formatString);
        formatCB.setSelectedIndex(0);
        formatCB.addActionListener(palmImageAdapter);
        formatCB.addActionListener(formatAdapter);
        logoList.addListSelectionListener(formatAdapter);

        CompressionAdapter compressionAdapter = new CompressionAdapter();
        compressCB = new JComboBox(compressString);
        compressCB.setSelectedIndex(0);
        compressCB.addActionListener(compressionAdapter);
        logoList.addListSelectionListener(compressionAdapter);

        NameAdapter nameAdapter = new NameAdapter();
        nameTF = new JTextField(20);
        nameTF.addActionListener(nameAdapter);
        nameTF.addFocusListener(nameAdapter);
        logoList.addListSelectionListener(nameAdapter);

        GammaSAdapter gammaSAdapter = new GammaSAdapter();
        gammaS = new JSlider(JSlider.HORIZONTAL, 0, 40, 10);
        gammaS.setMajorTickSpacing(10);
        gammaS.setMinorTickSpacing(1);
        gammaS.setPaintTicks(true);
        gammaS.addChangeListener(palmImageAdapter);
        gammaS.addChangeListener(gammaSAdapter);
        logoList.addListSelectionListener(gammaSAdapter);

        ButtonAdapter buttonAdapter = new ButtonAdapter();

        upB    = makeButton(lMoveUp,nUpName);
        downB  = makeButton(lMoveDown,nDownName);
        plusB  = makeButton(lLoadI,nPlusName);
        cutB   = makeButton(lCutI,nCutName);
        pasteB = makeButton(lPasteI,nPasteName);
        editB  = makeButton(lEditDbInfo,nEditName);
        logoList.addListSelectionListener(buttonAdapter);
        
        JPanel pane = new JPanel();
        
        HtmlLayout hl = new HtmlLayout(Layout.getLayout(layoutName));
        pane.setLayout(hl);
        
        pane.add(listScrollPane,"list");
        pane.add(origLabel,"orig");
        pane.add(palmLabel,"palm");

        pane.add(resizeC,"resize");
        pane.add(centerC,"center");

        pane.add(name,"nameL");
        pane.add(nameTF,"nameTB");

        pane.add(display,"displayL");
        pane.add(displayCB,"displayCB");

        pane.add(format,"formatL");
        pane.add(formatCB,"formatCB");

        pane.add(compress,"compressL");
        pane.add(compressCB,"compressCB");

        pane.add(gammaL,"gammaL");
        pane.add(gammaS,"gammaTB");
  
        pane.add(upB,"upB");
        pane.add(downB,"downB");
        pane.add(plusB,"plusB");
        pane.add(cutB,"cutB");
        pane.add(pasteB,"pasteB");
        pane.add(editB,"editB");
   
        setContentPane(pane);

        //Create the menu bar.
        menuBar = new JMenuBar();
        setJMenuBar(menuBar);

        //Build the first menu.
        fileMenu = new JMenu(lFileM);
        logoMenu = new JMenu(lLogoM);
        helpMenu = new JMenu(lHelpM);
        menuBar.add(fileMenu);
        menuBar.add(logoMenu);
        menuBar.add(helpMenu);

        loadImageAction = new AbstractAction(lLoadI,loadIcon(nPlusName)) {
             public void actionPerformed(ActionEvent e) {
                loadImages();
             }
        };
        plusB.addActionListener(loadImageAction);

        saveImageAction = new AbstractAction(lSaveI,null) {
             public void actionPerformed(ActionEvent e) {
             }
        };
        saveImageAction.setEnabled(false);

        cutImageAction = new AbstractAction(lCutI,loadIcon(nCutName)) {
             public void actionPerformed(ActionEvent e) {
                Log.println("cutImageAction");
                cutImage();
             }
        };
        cutB.addActionListener(buttonAdapter);
        cutB.addActionListener(cutImageAction);

        pasteImageAction = new AbstractAction(lPasteI,loadIcon(nPasteName)) {
             public void actionPerformed(ActionEvent e) {
                pasteImage();
             }
        };
        pasteB.addActionListener(buttonAdapter);
        pasteB.addActionListener(pasteImageAction);

        moveUpImageAction = new AbstractAction(lMoveUp,loadIcon(nUpName)) {
             public void actionPerformed(ActionEvent e) {
                moveItem(-1);
             }
        };
        upB.addActionListener(moveUpImageAction);

        moveDownImageAction = new AbstractAction(lMoveDown,loadIcon(nDownName)) {
             public void actionPerformed(ActionEvent e) {
                moveItem(+1);
             }
        };
        downB.addActionListener(moveDownImageAction);

        editDbInfoAction = new AbstractAction(lEditDbInfo,loadIcon(nEditName)) {
             public void actionPerformed(ActionEvent e) {
                editDbInfo();
             }
        };
        editB.addActionListener(editDbInfoAction);

        loadFileAction = new AbstractAction(lLoad,loadIcon(nOpenName)) {
             public void actionPerformed(ActionEvent e) {
                loadPictures();
             }
        };

        saveFileAction = new AbstractAction(lSave,loadIcon(nSaveName)) {
             public void actionPerformed(ActionEvent e) {
                savePictures();
             }
        };

        exportFileAction = new AbstractAction(lGenerate,loadIcon(nGenerateName)) {
             public void actionPerformed(ActionEvent e) {
                exportPictures();
             }
        };

        newAction = new AbstractAction(lNew,loadIcon(nNewName)) {
             public void actionPerformed(ActionEvent e) {
                logoList.clearSelection();
                logoListModel.removeAllElements();
                cutLogo = null;
                enableActions();
             }
        };

        exitAction = new AbstractAction(lQuit,loadIcon(nExitName)) {
             public void actionPerformed(ActionEvent e) {
                System.exit(0);
             }
        };

        aboutAction = new AbstractAction(lAbout,loadIcon(nAboutName)) {
             public void actionPerformed(ActionEvent e) {
                Log.showMessageDialog(frame, lAboutText+lLicence, lAbout,
                    JOptionPane.INFORMATION_MESSAGE,
                    new ImageIcon(frame.getIconImage()) );
             }
        };

        if (workaroundIBMLinuxBug) { fileMenu.add(new JMenuItem(" ")); }
        fileMenu.add(loadFileAction);
        fileMenu.add(saveFileAction);
        fileMenu.add(newAction);
        fileMenu.add(exportFileAction);
        fileMenu.addSeparator();
        fileMenu.add(exitAction);

        if (workaroundIBMLinuxBug) { logoMenu.add(new JMenuItem(" ")); }
        logoMenu.add(editDbInfoAction);
        logoMenu.add(loadImageAction);
        logoMenu.add(cutImageAction);
        logoMenu.add(pasteImageAction);
        logoMenu.add(moveUpImageAction);
        logoMenu.add(moveDownImageAction);
                         
        if (workaroundIBMLinuxBug) { helpMenu.add(new JMenuItem(" ")); }
        helpMenu.add(aboutAction);

        if (workaroundIBMLinuxBug) { setLocation(50,50); }

        enableActions();
        pack();


        setIconImage(Toolkit.getDefaultToolkit().createImage(getClass().getResource(nIconName)));
        setVisible(true);
    }

    //-------------------------------------------------------------------------
    // Helper for creating Buttons
    //-------------------------------------------------------------------------
    private JButton makeButton(String toolTip, String filename)
    {
        JButton result = new JButton(loadIcon(filename));
        result.setMargin(new Insets(0,0,0,0));
        result.setBorderPainted(false);
        result.setToolTipText(toolTip);
        return result;
    }

    //-------------------------------------------------------------------------
    // Helper for loading images from JAR file
    //-------------------------------------------------------------------------
    private Icon loadIcon(String filename)
    {
        Log.println("loadIcon "+filename);
        return new ImageIcon(getClass().getResource(filename));
    }
    //-------------------------------------------------------------------------
    // Listener of Name Text Field
    //-------------------------------------------------------------------------
    class NameAdapter extends FocusAdapter implements ActionListener, ListSelectionListener
    {
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) 
        {
            JTextField tf = (JTextField)e.getSource();
            Log.println("NameAdapter:actionPerformed");
            if (selectedLogo != null)
            {
                selectedLogo.setName(tf.getText());
                logoListModel.fireContentsChanged((int)logoList.getSelectedIndex());
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("NameAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                nameTF.setText( (selectedLogo == null) ? "" : selectedLogo.getName());
            }
        }

        public void focusLost(FocusEvent e) 
        {
            if (selectedLogo != null)
            {
                selectedLogo.setName(nameTF.getText());
                logoListModel.fireContentsChanged((int)logoList.getSelectedIndex());
            }
            Log.println("NameAdapter:focusLost");
        }
    }

    //-------------------------------------------------------------------------
    // Listener for Button Control
    //-------------------------------------------------------------------------
    class ButtonAdapter implements ListSelectionListener, ActionListener
    { 
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("ButtonAdapter.valueChanged");
            if (!e.getValueIsAdjusting())
            {
                enableActions();
            }
        }
        public void actionPerformed(ActionEvent e) {
            Log.println("ButtonAdapter.actionPerformed");
            enableActions();
        }
    }

    //-------------------------------------------------------------------------
    // Listener of Format ComboBox
    //-------------------------------------------------------------------------
    class FormatAdapter implements ActionListener , ListSelectionListener
    { 
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) 
        {
            JComboBox cb = (JComboBox)e.getSource();
            Log.println("FormatAdapter.actionPerformed");
            if (selectedLogo != null)
            {
                selectedLogo.setFormat(cb.getSelectedIndex());
                // If user select color format make sure the
                // display mode is also color
                if ((selectedLogo.getFormat()      == Logo.FORMAT_8BITCOLOR
                  || selectedLogo.getFormat()      == Logo.FORMAT_16BITCOLOR)
                 && selectedLogo.getDisplayType() != Logo.DISPLAY_COLOR)
                {
                    selectedLogo.setDisplayType(Logo.DISPLAY_COLOR); 
                    displayCB.setSelectedIndex(Logo.DISPLAY_COLOR);
                }
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                if (selectedLogo == null) 
                {
                    formatCB.setSelectedIndex(0);
                } 
                else 
                {
                Log.println("FormatAdapter.valueChanged format="+selectedLogo.getFormat());
                    formatCB.setSelectedIndex(selectedLogo.getFormat());
                }
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener of Compression ComboBox 
    //-------------------------------------------------------------------------
    class CompressionAdapter implements ActionListener, ListSelectionListener 
    { 
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) {
            JComboBox cb = (JComboBox)e.getSource();
            Log.println("CompressionAdapter");
            if (selectedLogo != null)
            {
                selectedLogo.setCompression(cb.getSelectedIndex());
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                compressCB.setSelectedIndex( (selectedLogo == null) ? 0 : selectedLogo.getCompression());
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener of Display ComboBox 
    //-------------------------------------------------------------------------
    class DisplayAdapter implements ActionListener, ListSelectionListener 
    { 
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) {
            JComboBox cb = (JComboBox)e.getSource();
            Log.println("DisplayAdapter:actionPerformed");
            if (selectedLogo != null)
            {
                selectedLogo.setDisplayType(cb.getSelectedIndex());
                // If user select grayscale format make sure the
                // display mode is also grayscale
                if ((selectedLogo.getFormat()      == Logo.FORMAT_8BITCOLOR
                 || selectedLogo.getFormat()      == Logo.FORMAT_16BITCOLOR)
                 && selectedLogo.getDisplayType() != Logo.DISPLAY_COLOR)
                {
                    selectedLogo.setFormat(Logo.FORMAT_4BIT); 
                    formatCB.setSelectedIndex(Logo.FORMAT_4BIT);
                }
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                displayCB.setSelectedIndex((selectedLogo == null) ? 0 : selectedLogo.getDisplayType());
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener for Palm Image
    //-------------------------------------------------------------------------
    class PalmImageAdapter implements ActionListener, ListSelectionListener,ChangeListener 
    {
        Logo selectedLogo;
        private void setImage(Image i)
        {
            palmLabel.setIcon((i == null) ? null : new ImageIcon(i));
        }
        private void setImage()
        {
            Cursor oldCursor = getCursor();
            setCursor(Cursor.WAIT_CURSOR);
            setImage((selectedLogo == null) ? null : selectedLogo.getPreviewImage());
            setCursor(oldCursor);
        }
        public void actionPerformed(ActionEvent e) 
        {
            Log.println("PalmImageAdapter:actionPerformed");
            setImage();
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("PalmImageAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                setImage();
            }
        }
        public void stateChanged(ChangeEvent e) 
        {
            Log.println("PalmImageAdapter:stateChanged");
            JSlider source = (JSlider)e.getSource();
            if (!source.getValueIsAdjusting()) 
            {
                setImage();
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener for Image
    //-------------------------------------------------------------------------
    class LogoImageAdapter implements ActionListener, ListSelectionListener 
    {
        Logo selectedLogo;
        private void setImage(Image i)
        {
            origLabel.setIcon((i == null) ? null : new ImageIcon(i));
        }
        private void setImage()
        {
            Cursor oldCursor = getCursor();
            setCursor(Cursor.WAIT_CURSOR);
            setImage((selectedLogo == null) ? null : selectedLogo.getSourceImage());
            setCursor(oldCursor);
        }
        public void actionPerformed(ActionEvent e) 
        {
            Log.println("LogoImageAdapter:actionPerformed");
            setImage();
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("LogoImageAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                setImage();
            }
        }
    }


    //-------------------------------------------------------------------------
    // Listener of Gamma Slider    
    //-------------------------------------------------------------------------
    class GammaSAdapter implements ChangeListener, ListSelectionListener 
    {
        Logo selectedLogo; 
        public void stateChanged(ChangeEvent e) 
        {
            Log.println("GammaSAdapter:stateChanged");
            JSlider source = (JSlider)e.getSource();
            if (!source.getValueIsAdjusting()) 
            {
                if (selectedLogo != null)
                {
                    double gamma = (double)source.getValue()/10.0D;
                    selectedLogo.setGamma(gamma);
                }
            }
        }

        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("GammaSAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                gammaS.setValue( (selectedLogo == null) ? 10 : (int)(selectedLogo.getGamma()*10.0D) );
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener for Resize CheckBox 
    //-------------------------------------------------------------------------
    class ResizeAdapter implements ActionListener, ListSelectionListener 
    { 
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) {
            JCheckBox rb = (JCheckBox)e.getSource();
            Log.println("ResizeAdapter:actionPerformed");
            if (selectedLogo != null)
            {
                selectedLogo.setResizeSourceImage(rb.isSelected());
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("ResizeAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                resizeC.setSelected((selectedLogo == null) ? false : selectedLogo.getResizeSourceImage());
            }
        }
    }

    //-------------------------------------------------------------------------
    // Listener for Center CheckBox 
    //-------------------------------------------------------------------------
    class CenterAdapter implements ActionListener, ListSelectionListener 
    { 
        Logo selectedLogo; 
        public void actionPerformed(ActionEvent e) {
            JCheckBox rb = (JCheckBox)e.getSource();
            Log.println("CenterAdapter:actionPerformed");
            if (selectedLogo != null)
            {
                selectedLogo.setCenterSourceImage(rb.isSelected());
            }
        }
        public void valueChanged(ListSelectionEvent e) 
        {
            Log.println("CenterAdapter:valueChanged");
            if (!e.getValueIsAdjusting())
            {
                selectedLogo = (Logo)logoList.getSelectedValue();
                centerC.setSelected((selectedLogo == null) ? false : selectedLogo.getCenterSourceImage());
            }
        }
    }

    //-------------------------------------------------------------------------
    // Enable or disable the Buttons or Menuactions
    //-------------------------------------------------------------------------
    private void enableActions()
    {
        boolean enable       = (logoList.getSelectedValue() != null);
        boolean enableUpDown = (enable && logoListModel.size() > 1);
        boolean enablePaste  = (cutLogo != null);
        
        Log.println("enableActions enable="+enable+ " enableUpDown="+enableUpDown+" enablePaste="+enablePaste);
        upB.setEnabled(enableUpDown);
        downB.setEnabled(enableUpDown);
        cutB.setEnabled(enable);
        pasteB.setEnabled(enablePaste);
    
        moveUpImageAction.setEnabled(enableUpDown);
        moveDownImageAction.setEnabled(enableUpDown);
        cutImageAction.setEnabled(enable);
        pasteImageAction.setEnabled(enablePaste);
        
        nameTF.setEnabled(enable);
        displayCB.setEnabled(enable);
        formatCB.setEnabled(enable);
        compressCB.setEnabled(enable);
        gammaS.setEnabled(enable);
        resizeC.setEnabled(enable);
        centerC.setEnabled(enable);
    }

    //-------------------------------------------------------------------------
    // Load images from a user supplied list (fileselection dialog) of filenames
    // PDB and PRC files are loaded with a special importer 
    //-------------------------------------------------------------------------
    private void loadImages()
    {
        File files[] = null;
        JFileChooser chooser = new JFileChooser(lastLogoDirectory);
        chooser.setDialogTitle(lLoadI);
        chooser.setMultiSelectionEnabled(true);
        int option = chooser.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION) 
        {
            Cursor oldCursor = getCursor();
            setCursor(Cursor.WAIT_CURSOR);

            files = chooser.getSelectedFiles();

		    // A bug?
		    if (files != null && files.length == 0)
		    {
			    if (chooser.getSelectedFile() != null)
			    {
				    files = new File[1];
				    files[0] = chooser.getSelectedFile();
			    }
		    }

            for (int i=0;i<files.length;i++)
            {
                String filename = files[i].getAbsolutePath();
                String name = files[i].getName();
                lastLogoDirectory  = files[i].getParent();

                try
                {
                    int dot = name.lastIndexOf('.');
                    if (dot > 1)
                    {
                        name = name.substring(0,dot);
                    }
                    // Bug#003: Uppercase extension of prc file is not recognized
                    // Fix: Convert extension to lowercase before comparison
                    String lowName = filename.toLowerCase();
                    if (lowName.endsWith(".pdb") || lowName.endsWith(".prc"))
                    {
                        Importer importer = new Importer(filename);
                        importer.readFile();
                        importer.setComponent(this);
                        logoListModel.addAll(importer.getLogoList());
                        logoListModel.setDbInfo(importer.getDbInfo());
                    }
                    else
                    {
                        Logo logo = new Logo(name);
                        logo.setComponent(this);
                        logo.load(filename);
                        logoListModel.addElement(logo);
                    }
                    logoList.setSelectedIndex(logoListModel.getSize()-1);
                } catch (Exception e)
                {
                    Log.showMessageDialog(frame, 
                        eLoadFile+" \n"+filename+"\n"+e.toString(), lWarning,JOptionPane.WARNING_MESSAGE);
                    Log.println(e);
                }
            }
            setCursor(oldCursor);
        }
    }

    //-------------------------------------------------------------------------
    // move a logo from the Vector of logos to the cut buffer
    //-------------------------------------------------------------------------
    private void cutImage()
    {
        int index = logoList.getSelectedIndex();
        Log.println("cutImage cutLogo="+cutLogo+" index="+index);
        if (index >= 0) 
        {
            cutLogo = (Logo)logoListModel.getElementAt(index);
            logoList.clearSelection();
            logoListModel.remove(index);

            int listSize = logoListModel.getSize();
            if (listSize > 0)
            {
                logoList.setSelectedIndex((index >= listSize) 
                                       ? listSize-1
                                       : index);
            }
        }
    }

    //-------------------------------------------------------------------------
    // move a logo from the cut buffer to the Vector of logos 
    //-------------------------------------------------------------------------
    private void pasteImage()
    {
        if (cutLogo != null)
        {
            logoListModel.addElement(cutLogo);
            cutLogo = null;
            logoList.setSelectedIndex(logoListModel.getSize()-1);
        }
    }

    //-------------------------------------------------------------------------
    // Move a logo within the Vector of logos
    //-------------------------------------------------------------------------
    private void moveItem(int direction)
    {
        int index = logoList.getSelectedIndex();
        if (index >= 0) 
        {
            int newIndex = index + direction;

            Log.println("moveItem d="+direction+" index="+index+" newIndex="+newIndex);
            if (newIndex >= 0)
            {
                Object o = logoListModel.remove(index);
                if (newIndex >= logoListModel.getSize())
                {
                    logoListModel.addElement(o);
                    logoList.setSelectedIndex(logoListModel.getSize()-1);
                }
                else
                {
                    logoListModel.add(newIndex,o);
                    logoList.setSelectedIndex(newIndex);
                }
            }
        }
    }

    //-------------------------------------------------------------------------
    // Load a serialized Vector of Logo Objects
    //-------------------------------------------------------------------------
    private void loadPictures()
    {
        String filename = null;
        JFileChooser chooser = new JFileChooser(lastDirectory);
        chooser.setDialogTitle(lLoad);
        int option = chooser.showOpenDialog(this);

        if (option == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) 
        {
            filename = chooser.getSelectedFile().getAbsolutePath();
            lastDirectory  = chooser.getSelectedFile().getParent();
        }

        if (filename != null && filename.length() != 0)
        {
            Cursor oldCursor = getCursor();
            setCursor(Cursor.WAIT_CURSOR);
            try
            {
                FileInputStream   fis = new FileInputStream(filename);
                ObjectInputStream ois = new ObjectInputStream(fis);
                logoListModel = (LogoListModel)ois.readObject();
                ois.close();
                
                logoList.setModel(logoListModel);
                Enumeration e = logoListModel.elements();
                while (e.hasMoreElements())
                {
                    Logo l = (Logo)e.nextElement();
                    l.setComponent(this);
                }
                Log.println("loadPictures:done");

            } catch (Exception e)
            {
                Log.showMessageDialog(frame, 
                    eLoadFile+" \n"+filename+"\n"+e.toString(), lWarning,JOptionPane.WARNING_MESSAGE);
                Log.println(e);
            }
            setCursor(oldCursor);
            // If we loaded some logos, select the first one
            if (logoListModel.size() > 0)
            {
                logoList.setSelectedIndex(0);
            }

        }
    }

    //-------------------------------------------------------------------------
    // Save a serialized Vector of Logo Objects
    //-------------------------------------------------------------------------
    private void savePictures()
    {
        String filename = null;
        JFileChooser chooser = new JFileChooser(lastDirectory);
        chooser.setDialogTitle(lSave);
        int option = chooser.showSaveDialog(this);

        if (option == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) 
        {
            filename = chooser.getSelectedFile().getAbsolutePath();
            lastDirectory  = chooser.getSelectedFile().getParent();
        }

        if (filename != null && filename.length() != 0)
        {
            Cursor oldCursor = getCursor();
            setCursor(Cursor.WAIT_CURSOR);
            try
            {
                FileOutputStream   fos = new FileOutputStream(filename);
                ObjectOutputStream oos = new ObjectOutputStream(fos);
                oos.writeObject(logoListModel);
                oos.flush();
                oos.close();
                Log.println("savePictures:done");
            } catch (IOException e)
            {
                Log.showMessageDialog(frame, 
                    eSaveFile+" \n"+filename+"\n"+e.toString(), lWarning,JOptionPane.WARNING_MESSAGE);
                Log.println(e);
            }
            setCursor(oldCursor);
        }
    }

    //-------------------------------------------------------------------------
    // Create a PDB file usable for Open Logo Hack
    //-------------------------------------------------------------------------
    private void exportPictures()
    {
        try
        {
            String filename = null;
            JFileChooser chooser = new JFileChooser(lastDirectory);
            chooser.setDialogTitle(lGenerate);
            int option = chooser.showSaveDialog(this);

            if (option == JFileChooser.APPROVE_OPTION && chooser.getSelectedFile() != null) 
            {
                filename = chooser.getSelectedFile().getAbsolutePath();
                lastDirectory  = chooser.getSelectedFile().getCanonicalPath();
            }

            if (filename != null && filename.length() != 0)
            {
                Cursor oldCursor = getCursor();
                setCursor(Cursor.WAIT_CURSOR);
                olHaDB db = new olHaDB();
                db.setDbInfo(logoListModel.getDbInfo());
                Enumeration e = logoListModel.elements();
                while (e.hasMoreElements())
                {
                    Logo logo = (Logo)e.nextElement();
                    TbmpResource bitmap = new TbmpResource();
                    int bitsPerPixel = logo.getBitsPerPixel();

                    bitmap.setPixel(logo.getPalmPixel());
                    bitmap.setName(logo.getName());
                    bitmap.setBitsPerPixel(bitsPerPixel);
                    bitmap.setCompression(logo.getCompression());

                    db.addLogo(bitmap);            
                }
                db.makeDB(filename);

                setCursor(oldCursor);
                long filesize = (new File(filename)).length();
                Log.showMessageDialog(frame, lGenerated+"\n"+lFilesize+" "+filesize+" "+lBytes,
                    lInfo,JOptionPane.INFORMATION_MESSAGE);

                Log.println("exportPictures:done");
            }
        } catch (IOException e)
        {
            Log.println(e);
        }

    }

    //-------------------------------------------------------------------------
    // Edit the additional Database info
    //-------------------------------------------------------------------------
    private void editDbInfo()
    {
        Log.println("editDbInfo");

        DBInfoDialog dialog = new DBInfoDialog(frame,logoListModel,"Open Logo Hack DB Info");
    }

    //-------------------------------------------------------------------------
    // get the label strings from the locale specific bundle
    //-------------------------------------------------------------------------
    private static void setLables( Locale currentLocale)
    {
        ResourceBundle labels = ResourceBundle.getBundle("labels",currentLocale);
        formatString[0]     = labels.getString("format1");
        formatString[1]     = labels.getString("format2");
        formatString[2]     = labels.getString("format3");
        formatString[3]     = labels.getString("format4");
        formatString[4]     = labels.getString("format5");
        compressString[0]   = labels.getString("compres1");
        compressString[1]   = labels.getString("compres2");
        compressString[2]   = labels.getString("compres3");
        displayString[0]    = labels.getString("display1");
        displayString[1]    = labels.getString("display2");
        displayString[2]    = labels.getString("display3");
        lName               = labels.getString("name");
        lDisplay            = labels.getString("display");
        lFormat             = labels.getString("format");
        lCompression        = labels.getString("compres");
        lGamma              = labels.getString("gamma");
        lResize             = labels.getString("resize");
        lCenter             = labels.getString("center");
        lFileM              = labels.getString("mfile");
        lLogoM              = labels.getString("mlogo");
        lHelpM              = labels.getString("mhelp");
        lLoadI              = labels.getString("mloadi");
        lSaveI              = labels.getString("msavei");
        lCutI               = labels.getString("mcut");
        lPasteI             = labels.getString("mpaste");
        lMoveUp             = labels.getString("mup");
        lMoveDown           = labels.getString("mdown");
        lLoad               = labels.getString("mload");
        lSave               = labels.getString("msave");
        lGenerate           = labels.getString("mgenerate");
        lQuit               = labels.getString("mquit");
        lAbout              = labels.getString("mabout");
        lNew                = labels.getString("mnew");
        lEditDbInfo         = labels.getString("meditdbinfo");
        lWarning            = labels.getString("warn");
        lInfo               = labels.getString("info");
        eLoadFile           = labels.getString("eload");
        eSaveFile           = labels.getString("esave");
        eloadImage          = labels.getString("eloadi");
        ecreateImage        = labels.getString("ecreatei");
        lGenerated          = labels.getString("generated");
        lFilesize           = labels.getString("fsize");
        lBytes              = labels.getString("bytes");
        lLicence            = labels.getString("licence");
    }
    
    //-------------------------------------------------------------------------
    // Main
    //-------------------------------------------------------------------------
    public static void main(String args[]) 
    {
        Locale locale = new Locale("","");

        for (int i=0; i<args.length; i++)
        {
            if ("-d".equals(args[i]))
            {
                Log.enableLogging();
            } 
            else if ("de".equals(args[i]))
            {
                locale = new Locale("de","DE");
            } 
            else if ("en".equals(args[i]))
            {
                // "en" is default locale
            }
            else if ("-N710".equals(args[i]))
            {
                // increase the screen resolution
                screenWidth = 320;
                screenHeight= 320;
            }
            else
            {
                System.out.println("Usage: java -jar olh.jar olh.ui.GUI [en|de]");
            }
        }  
        
        // I have some problems with the placement of windows and menus 
        // at my linux box. So i had to omplement a workaround.
        // Maybe it's a windowmanager problem
        workaroundIBMLinuxBug = "IBM Corporation".equals(System.getProperty("java.vendor"))
                             && "Linux".equals(System.getProperty("os.name"));

        setLables(locale);
        Log.enableGraphic();

        JFrame gui = new GUI();
    }
}


//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
