/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import olh.Log;
import java.awt.image.*;
import Acme.*;
import Acme.JPM.Filters.*;

public class PalmColorPixelFilter extends RGBAllFilter 
{
    private IntHashtable mappingCache;
    private static final int[][] palmPalette8bpp = PalmColorScale.getColorPalette();
    private int bitsPerPixel;
    
    public PalmColorPixelFilter(ImageProducer producer, int bPP)
    {
        super(producer);
        mappingCache = new IntHashtable();
        bitsPerPixel = bPP;
    }

    //-------------------------------------------------------------------------
    // Convert the colored image into a indexed image
    // the index can be used to create the corresponding preview image
    // or the real palm bitmap resource
    // for easy use, the index is mapped to red, green, and blue component
    //-------------------------------------------------------------------------
    public void filterRGBAll( int width, int height, int[][] rgbPixels )
    {
        if (bitsPerPixel == 8)
        {
            filterRGBAll8bPP(width,height,rgbPixels);
        }
        else
        {
            filterRGBAll16bPP(width,height,rgbPixels);
        }
    }
    
    //-------------------------------------------------------------------------
    // Convert the 8,8,8 bit image to the palm 5,6,5 bit image
    //-------------------------------------------------------------------------
    private void filterRGBAll16bPP( int width, int height, int[][] rgbPixels )
    {
        int[][] outPixels = new int[height][width];
        for ( int row = 0; row < height; ++row )
        {
            for ( int col = 0; col < width; ++col )
            {
                int pixel = rgbPixels[row][col];
                // Map pixel from 8,8,8 to 5,6,5 bits per Pixel
                int r = rgbModel.getRed( pixel )  / 8;
                int g = rgbModel.getGreen( pixel )/ 4;
                int b = rgbModel.getBlue( pixel ) / 8;

//Log.println("row="+row+" col="+col+" pixel="+pixel+" r="+rgbModel.getRed( pixel )+" g="+rgbModel.getGreen( pixel )+" b="+rgbModel.getBlue( pixel )  );

                int newPixel = (r&0x1F)<<11 | (g&0x3F)<<5 | (b&0x1F);
//Log.println( " r="+r+" g="+g+" b="+b+" new="+newPixel );

                outPixels[row][col] = 0xFF000000 | newPixel;
            }
        }
        setPixels( width, height, outPixels );
     }

    //-------------------------------------------------------------------------
    // Use the 8 bit Color map to calculate the index within the colormap
    // Store the index in red, green, and blue value of the pixel
    //-------------------------------------------------------------------------
    private void filterRGBAll8bPP( int width, int height, int[][] rgbPixels )
    {
        int[][] outPixels = new int[height][width];
        for ( int row = 0; row < height; ++row )
        {
            for ( int col = 0; col < width; ++col )
            {
                int pixel = rgbPixels[row][col];
                int index;
                
                Integer i = (Integer)mappingCache.get(pixel);
                if (i == null)
                {
                    int r = rgbModel.getRed( pixel );
                    int g = rgbModel.getGreen( pixel );
                    int b = rgbModel.getBlue( pixel );
                    // find nearest color index
                    index = RGBToColorIndex(r,g,b,palmPalette8bpp);
                    mappingCache.put(pixel, new Integer(index));
                } 
                else
                {
                    index = i.intValue();
                }

                int newPixel = (index&0xFF)<<16 | (index&0xFF)<<8 | (index&0xFF);
                outPixels[row][col] = 0xFF000000 | newPixel;
            }
        }
        setPixels( width, height, outPixels );
     }

    //-------------------------------------------------------------------------
    // Generate the color "differences" for all colors in the palette
    // return the lowest difference value for the color
    //-------------------------------------------------------------------------
    private int RGBToColorIndex(int r, int g, int b, int[][] palette)
    {
        int diffArray[] = new int[palette.length];
        for (int i=0;i<diffArray.length;i++)
        {
            diffArray[i] = (palette[i][0]-r)*(palette[i][0]-r) 
                         + (palette[i][1]-g)*(palette[i][1]-g)
                         + (palette[i][2]-b)*(palette[i][2]-b);
        }
        int index    = diffArray.length-1;
        int lowValue = diffArray[index];
        for (int i=index-1; i>=0; i--) 
        {
            if (diffArray[i] < lowValue) 
            {
              lowValue = diffArray[i];
              index    = i;
            }
        }
//        System.out.println("r="+r+" g="+g+" b="+b+" >> index="+index+" diff="+lowValue);
        return index;
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
