/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.awt.image.*;
import Acme.JPM.Filters.*;

class PalmPreviewFilter extends RGBAllFilter
{
    ColorMapper cMapper;
    public PalmPreviewFilter(ImageProducer producer, ColorMapper cMapper)
    {
        super(producer);
        this.cMapper = cMapper;
    }

    public void filterRGBAll( int width, int height, int[][] rgbPixels )
    {
        int[][] newPixels = new int[height][width];
        for ( int row = 0; row < height; ++row )
        {
            for ( int col = 0; col < width; ++col )
            {
                int pixel = rgbPixels[row][col];
                int index = rgbModel.getRed(pixel);
                int newPixel = cMapper.getColor(rgbModel.getRed(pixel),
                                                rgbModel.getGreen(pixel),
                                                rgbModel.getBlue(pixel),
                                                pixel);

//Log.println("x="+row+" y="+col+" index="+index+" pixel="+newPixel );

                newPixels[row][col] = 0xFF000000 | newPixel;

            }
        }
        setPixels( width, height, newPixels );
     }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
