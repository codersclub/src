/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import java.io.*;
import java.util.*;
import java.awt.*;
import olh.*;

public final class fromList
{
    private static String   lAboutText  = "\nOpen logo Hack Creator Version 1.3\n(c)Frank Schnekenb�hl <f.sck@web.de>\nhttp://olh.sourceforge.net\n";
    private static String   lLicence    = "This is free software under the GNU General Public License.\nIt comes with ABSOLUTELY NO WARRENTY.\nFor details see file LICENSE\n";
    static Vector v;

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private class LineReader 
    {
        BufferedReader br;

        public LineReader (String inputname) throws FileNotFoundException
        {
            br = new BufferedReader(new FileReader(inputname));
        }
        
        public String nextLine() throws IOException
        {
            String line;
            boolean validLine;
            do
            {
                line = br.readLine();
                validLine = (line != null && line.length() != 0 && line.charAt(0) != '#');
            } while (!validLine && line != null);
            
            return line;
        }
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public fromList(String args[])
    {
        Vector v = new Vector();
        olHaDB db = new olHaDB();
        String outputname = "logo.pdb";
        String inputname = "inlist.txt";
        
        System.err.println(lAboutText);
        System.err.println(lLicence);

        if (args.length == 2)
        {
            inputname = args[0];
            outputname = args[1];
        }
        else
        {
            System.out.println("Usage: java -classpath olh.jar olh.ui.fromList input.txt output.pdb");
        }

        //Log.enableLogging();
        try
        {
            LineReader b = new LineReader(inputname);
            String line = null;
            String dbInfo = "";
            System.out.println("Reading from "+inputname);

            //
            // Read Database info
            //
            StringBuffer buffer = new StringBuffer();
            line = b.nextLine();
            while (line != null && line.charAt(0) == '!')
            {
                buffer.append(line.substring(1));
                buffer.append("\n");
                line = b.nextLine();
            }
            dbInfo = buffer.toString();
            if (dbInfo.equals(""))
            {
                dbInfo = "Made with OLH fromlist";
            }

            do
            {
                String name = null;
                String filename = null;
                int    compression = TbmpResource.COMPESS_NONE;
                int    bitsPerPixel = 1;
                int    format = Logo.FORMAT_1BIT;
                
                for (int i=0;i<4;i++)
                {
                    if (line != null)
                    {
                        switch(i)
                        {
                            case 0: name = line; break;
                            case 1:
                                try
                                {
                                    bitsPerPixel = Integer.parseInt(line);
                                    switch (bitsPerPixel)
                                    {
                                        case 1: format = Logo.FORMAT_1BIT;
                                            break;
                                        case 2: format = Logo.FORMAT_2BIT;
                                            break;
                                        case 4: format = Logo.FORMAT_4BIT;
                                            break;
                                        case 8: format = Logo.FORMAT_8BITCOLOR;
                                            break;
                                        case 16: format = Logo.FORMAT_16BITCOLOR;
                                            break;
                                        default:
                                            System.out.println("Unsupported bitsPerPixel:"+bitsPerPixel);
                                            break;
                                    }
                                } catch (NumberFormatException e)
                                {
                                    System.out.println("Unsupported bitsPerPixel:"+line);
                                }
                                break;
                            case 2:
                                switch (line.charAt(0))
                                {
                                    case 'S': compression = TbmpResource.COMPESS_SCANLINE; break;
                                    case 'R': compression = TbmpResource.COMPESS_RLE; break;
                                }
                                break;
                            case 3: filename = line; break;
                            
                        }
                    }
                    line = b.nextLine();
                }
                if (name != null && filename!= null)
                {
                    Logo logo = new Logo();
                    logo.setResizeSourceImage(false);
                    logo.load(filename);
                    logo.setFormat(format);
                    
                    TbmpResource bitmap = new TbmpResource();
                    bitmap.setPixel(logo.getPalmPixel());
                    bitmap.setName(name);
                    bitmap.setBitsPerPixel(bitsPerPixel);
                    bitmap.setCompression(compression);

                    db.addLogo(bitmap);            
                }
            }
            while (line != null);

            System.out.println("Writing "+outputname);
            db.setDbInfo(dbInfo);
            db.makeDB(outputname);
        } 
        catch (FileNotFoundException e)
        {
            System.out.println("Cannot find file "+inputname);
        }
        catch (IOException e)
        {
            System.out.println("Cannot write file "+outputname);            
        }
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
	public static void main(String args[]) 
    {
        Log.disableGraphic();
        new fromList(args);
        System.exit(0);
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
