/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.ui;

import javax.swing.*;
import java.awt.Font;
import java.beans.*; //Property change stuff

public class DBInfoDialog extends JDialog  
{
    JDialog dialog = null;
    JOptionPane optionPane = null; 

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public DBInfoDialog(JFrame frame, LogoListModel model, String title)
    {
        super(frame,true);

        setTitle(title);
        dialog = this;

        final JTextArea textArea = new JTextArea();
        textArea.setFont(new Font("Monospaced",Font.BOLD,12));
        textArea.setRows(10);
        textArea.setColumns(7);
        textArea.setText(model.getDbInfo());

        JScrollPane textScroller = new JScrollPane();
        textScroller.getViewport().add(textArea,null);

        Object[] array = {textScroller};
        optionPane = new JOptionPane(array, 
                                    JOptionPane.PLAIN_MESSAGE,
                                    JOptionPane.OK_CANCEL_OPTION,
                                    null, null, null); 
        setContentPane(optionPane);
        setDefaultCloseOperation(DO_NOTHING_ON_CLOSE);

        optionPane.addPropertyChangeListener(
            new PropertyChangeListener() {
              public void propertyChange(PropertyChangeEvent e) {
                  String prop = e.getPropertyName();

                  if (dialog.isVisible() 
                   && (e.getSource() == optionPane)
                   && (prop.equals(JOptionPane.VALUE_PROPERTY) ||
                       prop.equals(JOptionPane.INPUT_VALUE_PROPERTY))) {
                      dialog.setVisible(false);
                  }
              }
            });
        
        pack();
        setLocationRelativeTo(frame);
        show();

        if (optionPane.getValue().toString().equals("0"))
        {
            // User pressed OK
            model.setDbInfo(textArea.getText()); 
        }
    }

}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
