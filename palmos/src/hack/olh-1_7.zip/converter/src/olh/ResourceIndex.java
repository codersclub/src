/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright Unknown                                                         */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/* Adopded from a MakeDocJ source                                            */
/*---------------------------------------------------------------------------*/
package olh;

import java.io.*;


public class ResourceIndex {
	/**
	 * the offset to the record
	 */
	public int fileOffset = -1;	// 4 DWord

    public int name;
    
    public int id;

	/**
	 * The size of the RecordIndex in bytes
	 */
	public static int getSize() 
    {
		return(10);// 8 bytes for Record Index
	}

	/**
	 * Reads the RecordIndex from the DataInput
	 * @param the DataInput to read from
	 */
	public void read(DataInput di) throws IOException 
    {
        name = di.readInt();
        id = di.readShort();
		fileOffset = di.readInt();
	}

	/**
	 * Writes the RecordIndex to the Dataoutput
	 * @param the DataInput to write to
	 */
	public void write(DataOutput out) throws IOException 
    {
		out.writeInt(name);
        out.writeShort(id);
		out.writeInt(fileOffset);
	}

	/**
	 * Dumps to standard error the contents of RecordIndex
	 */
	public void dump(int i) 
    {
	}

	/**
	 * override Object.toString()
	 */
	public String toString() 
    {
		return ">> Resource Index <<"
			+ "\nfileOffset = " + fileOffset
			+ "\nname= " + name
			+ "\nid = " + id;
	}

}

