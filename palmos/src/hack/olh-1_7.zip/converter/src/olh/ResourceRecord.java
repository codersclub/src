/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;
import java.io.*;

public class ResourceRecord 
{
    public static final int TVER = 0x74564552; // tVER
    public static final int TSTL = 0x7453544C; // tSTL
    public static final int TBMP = 0x54626d70; // Tbmp
    public static final int TALT = 0x54616c74; // Talt

    public int name;
    public short id;
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public ResourceRecord(int name, short id)
    {
        this.name = name;
        this.id = id;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setId(int id)
    {
        this.id = (short)id;
    }

}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
