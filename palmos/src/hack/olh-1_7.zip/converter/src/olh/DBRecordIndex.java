/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright Unknown                                                         */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/* Adopded from a MakeDocJ source                                            */
/*---------------------------------------------------------------------------*/
package olh;

import java.io.*;

/**
 * <code>RecordIndex</code> class is used to read/write Palm database record indexes
 * NOTE: Information about the various fields was taken from <a href="www.roadcoders.com/pdb.html">Road Coders</a>
 */
public class DBRecordIndex {
	/**
	 * the offset to the record
	 */
	public int fileOffset = -1;	// 4 DWord

	/**
	 * the attribute of the record
	 *  0x10 (16 decimal) Secret record bit.
	 *  0x20 (32 decimal) Record in use (busy bit).
	 *  0x40 (64 decimal) Dirty record bit.
	 *  0x80 (128, unsigned decimal) Delete record on next HotSync.
	 *  The least significant four bits are used to represent the category values.
	 */
	public byte attribute = 0;	// 1 Byte
	public final static int PRIVATE = 0x10;

	/**
	 * unique ID required for the RecordIndex
	 */
	public int uniqueID = 0;	// 3 Bytes
								


	/**
	 * The size of the RecordIndex in bytes
	 */
	public static int getSize() 
    {
		return(8);// 8 bytes for Record Index
	}

	/**
	 * Reads the RecordIndex from the DataInput
	 * @param the DataInput to read from
	 */
	public void read(DataInput di) throws IOException 
    {
		fileOffset = di.readInt();
		attribute = di.readByte();
		uniqueID = ((0xff & di.readByte()) << 16) + ((0xff & di.readByte()) << 8) + (di.readByte() & 0xff);
	}

	/**
	 * Writes the RecordIndex to the Dataoutput
	 * @param the DataInput to write to
	 */
	public void write(DataOutput out) throws IOException 
    {
		out.writeInt(fileOffset);
		out.write(attribute);
		out.write((byte)(uniqueID >> 16));
		out.write((byte)(uniqueID >> 8));
		out.write((byte) uniqueID);
	}

	/**
	 * Dumps to standard error the contents of RecordIndex
	 */
	public void dump(int i) 
    {
		System.err.println(">> Record Index " + i + " <<");
		System.err.println("fileOffset = " + fileOffset);
		System.err.println("attribute = " + attribute);
		System.err.println("uniqueID = " + uniqueID);
	}

	/**
	 * override Object.toString()
	 */
	public String toString() 
    {
		return ">> Record Index <<"
			+ "\nfileOffset = " + fileOffset
			+ "\nattribute = " + attribute
			+ "\nuniqueID = " + uniqueID;
	}

}

