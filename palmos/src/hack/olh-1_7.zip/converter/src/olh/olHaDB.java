/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;

import java.io.*;
import java.util.*;
import java.awt.*;
import olh.*;

public class olHaDB
{
	public final static int CreatorID = 0x6f6c4861;	// 'olHa'
	public final static int TypeID = 0x44415441 ;	// 'DATA'

    tSTLResource stringlist;
    TaltResource dbInfo;
    Vector records;

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public olHaDB()
    {
        stringlist = new tSTLResource(1000);
        stringlist.setPrefix("");
        dbInfo = new TaltResource(3000);
        dbInfo.setTitle("Logo DB Info");
        dbInfo.setMessage("");
        dbInfo.addButton("OK");
        
        
        // Daten erzeugen
        records = new Vector();

        records.addElement(new tVERResource("1.0",(short)1));
        records.addElement(stringlist);
        records.addElement(dbInfo);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void addLogo(TbmpResource bitmap)
    {
        bitmap.setId(3000+stringlist.size());
        stringlist.addString(bitmap.getName());
        records.addElement(bitmap);
//      Log.println("addLogo "+bitmap.getName());
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setDbInfo(String s)
    {
        dbInfo.setMessage(s);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void makeDB(String destinationPath)throws IOException
    {
		RandomAccessFile fout = null;

        new File(destinationPath).delete();
		fout = new RandomAccessFile(destinationPath, "rw");

        // create DB Header
		DBHeader dbHeader = new DBHeader();
        dbHeader.attribute = 0x01;
        dbHeader.version   = 0;
		dbHeader.setModificationDate();
		dbHeader.name      = "OlHaLogos";
		dbHeader.creatorID = CreatorID;
		dbHeader.typeID    = TypeID;
        
        // create DB Records
        dbHeader.numRecords = (short)records.size();
        dbHeader.write(fout);

        // create DB RecordIndex
		ResourceIndex[] ri = new ResourceIndex[dbHeader.numRecords];
		for(int i = 0; i < dbHeader.numRecords; i++) 
        {
			ri[i] = new ResourceIndex();
			ri[i].fileOffset = 0;
            ri[i].name = 0;
            ri[i].id = 0;
			ri[i].write(fout);
		}
        if (dbHeader.numRecords > 0) 
        {
    		ri[0].fileOffset = (int) fout.getFilePointer();
        }

        // write records
		for(int recNum = 0; recNum < dbHeader.numRecords; recNum++) 
        {
            Object o = records.elementAt(recNum);

			ri[recNum].fileOffset = (int)fout.getFilePointer();
            ri[recNum].name = ((ResourceRecord)o).name;
            ri[recNum].id   = ((ResourceRecord)o).id;
            ((RawIO)o).write(fout);
//          Log.println("writing "+o);
        }

		// re-write the record index array, now with the correct file offsets
		fout.seek(DBHeader.getSize());
		for(int i = 0; i < ri.length; i++) 
        {
			ri[i].write(fout);
		}

		fout.close();
    }

}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
