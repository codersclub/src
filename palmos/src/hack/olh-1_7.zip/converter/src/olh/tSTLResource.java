/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;
import java.io.*;
import java.util.*;

public final class tSTLResource extends ResourceRecord implements RawIO
{
    Vector   strings;
    String   prefix;
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public tSTLResource() 
    {
        this((short)0);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public tSTLResource(int id) 
    {
        super(ResourceRecord.TSTL,(short)id);
        strings = new Vector();
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public int size()
    {
       return strings.size();
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void addString(String s)
    {
        strings.addElement(s);
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setPrefix(String s)
    {
        prefix = s;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void write(DataOutput out) throws IOException 
    {
        out.writeBytes(prefix);
        out.writeByte(0);                   
        out.writeShort(strings.size());
        for (int i=0; i<strings.size(); i++)
        {
            out.writeBytes((String)strings.elementAt(i));
            out.writeByte(0);                   
        }
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
