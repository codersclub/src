/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;
import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;

/* Details see pilotsdk/PalmOS/Bitmap.html
-------------------------------------------------------------------------------

typedef struct BitmapType {
         Int16 width;
         Int16 height;
         UInt16 rowBytes;
         BitmapFlagsType flags;
         UInt8 pixelSize;
         UInt8 version;
         UInt16 nextDepthOffset;
         UInt8 transparentIndex;
         UInt8 compressionType;
         UInt16 reserved;
     } BitmapType;


 width 
              The width of the bitmap in pixels. You specify this value 
              when you create the bitmap. 
 height 
              The height of the bitmap in pixels. You specify this value 
              when you create the bitmap. 
 rowBytes 
              The number of bytes stored for each row of the bitmap where 
              height is the number of rows. 
 flags 
              The bitmap's attributes. See BitmapFlagsType. 
 pixelSize 
              The pixel depth. Currently supported pixel depths are 
              1, 2, 4, and 8-bit. You specify this value when you create 
              the bitmap. 
 version 
              The version of bitmap encoding used. See Bitmap Constants. 
 nextDepthOffset 
              For bitmap families, this field specifies the start of the 
              next bitmap in the family. The value it
              contains is the number of 4-byte words to the next BitmapType
               from the beginning of this
              one. If the bitmap is not part of a bitmap family or it is 
              the last bitmap in the family, the
              nextDepthOffset is 0. 
 transparentIndex 
              The color index for the transparent color. Only used for 
              version 2 bitmaps and only when the
              transparent flag is set in flags. You specify this value 
              when you create the bitmap using
              Constructor. 
 compressionType 
              The compression type used. Only used for version 2 bitmaps 
              and only when the compressed
              flag is set in flags. See BitmapCompressionType for possible 
              values. The
              BmpCompress function sets this field. 
 reserved 
              Reserved for future use. Must be set to 0. 
                  


-------------------------------------------------------------------------------
 BitmapFlagsType

 The BitmapFlagsType bit field defines the flags field of BitmapType. It specifies the bitmap's
 attributes. 

 typedef struct BitmapFlagsType { 
   UInt16 compressed:1; 
   UInt16 hasColorTable:1; 
   UInt16 hasTransparency:1; 
   UInt16 indirect:1; 
   UInt16 forScreen:1; 
   UInt16 directColor:1; 
   UInt16 reserved:10; 
 } BitmapFlagsType; 

 Field Descriptions 

  compressed 
              If true, the bitmap is compressed and the
              compressionType field specifies the compression used. If
              false, the bitmap is uncompressed. The BmpCompress
              function sets this field. 
  hasColorTable 
              If true, the bitmap has its own color table. If false, the
              bitmap uses the system color table. You specify whether
              the bitmap has its own color table when you create the
              bitmap. 
  hasTransparency 
              If true, the OS will not draw pixels that have a value
              equal to the transparentIndex. If false, the bitmap has no
              transparency value. You specify the transparent color
              when you create the bitmap using Constructor. 
  indirect 
              If true, the address to the bitmap's data is stored where
              the bitmap itself would normally be stored. The actual
              bitmap data is stored elsewhere. If false, the bitmap data
              is stored directly following the bitmap header or directly
              following the bitmap's color table if it has one. 

              Never set this flag. Only the display (screen) bitmap has
              the indirect bit set. 
  forScreen 
              If true, bitmap intended for the display (screen) window.
              Never set this flag. 
  directColor
              If true, bitmap is a direct color (RGB) bitmap.
  reserved 
              Reserved for future use. 

                 
-------------------------------------------------------------------------------
 Bitmap Constants

       Constant 
                   Value 
                                               Description 
 BitmapVersionZero 
               0 
                    Uses the version 0 encoding of a bitmap. Version 0 
                    encoding is supported in Palm
                    OS� 1.0 and later. 
 BitmapVersionOne 
               1 
                    Uses the version 1 encoding of a bitmap. Version 1 
                    encoding is supported in Palm OS
                    3.0 and later. 

                    PalmRez automatically creates version 1 bitmaps 
                    unless you've specified a
                    transparency index or a compressed type when 
                    creating the bitmap in Constructor. 

 BitmapVersionTwo 
               2 
                    Uses the version 2 encoding of a bitmap. Palm OS 3.5 
                    supports version 2 bitmaps.
                    Version 2 bitmaps either use the transparency 
                    index or are compressed. If you
                    programmatically create a bitmap using BmpCreate, 
                    a version 2 bitmap is created.                 
                 
-------------------------------------------------------------------------------
  BitmapCompressionType 

 The BitmapCompressionType enum specifies possible bitmap compression types. These are the
 possible values for the compressionType field of BitmapType. You can compress or uncompress a
 bitmap using a call to BmpCompress. 

 typedef enum { 
   BitmapCompressionTypeScanLine = 0, 
   BitmapCompressionTypeRLE, 
   BitmapCompressionTypePackBits, 
   BitmapCompressionTypeEnd, 
   BitmapCompressionTypeBest = 0x64, 
   BitmapCompressionTypeNone = 0xFF 
 } BitmapCompressionType; 

 Value Descriptions 

  BitmapCompressionTypeScanLine 
             Use scan line compression. Scan line
             compression is compatible with Palm
             OS� 2.0 and higher. 
  BitmapCompressionTypeRLE 
             Use RLE compression. RLE
             compression is supported in Palm OS
             3.5 and higher. 
  BitmapCompressionTypePackBits
             Use PackBits compression. PackBits
             compression is supported in Palm OS
             4.0 only.
  BitmapCompressionTypeEnd
             For internal use only.
  BitmapCompressionTypeBest
             For internal use only.
  BitmapCompressionTypeNone 
             No compression is used. 

             This value should only be used as an
             argument to BmpCompress.               

-------------------------------------------------------------------------------
 New BitmapDirectInfoType 

 For direct color bitmaps-each pixel is represented by an RGB triplet rather than a palette index-the
 BitmapDirectInfoType structure follows the color table if one is present, or immediately follows the
 BitmapType if a color table is not present. For direct color bitmaps, only 16 bits per pixel is supported,
 5 bits for red, 6 bits for green, and 5 bits for blue. 


 typedef struct BitmapDirectInfoType { 
   UInt8 redBits; 
   UInt8 greenBits; 
   UInt8 blueBits; 
   UInt8 reserved; 
   RGBColorType transparentColor; 
 } BitmapDirectInfoType; 

 Field Descriptions 

  redBits 
             Number of bits used by the red component in each pixel.
  greenBits
             Number of bits used by the green component in each pixel.
  blueBits
             Number of bits used by the blue component in each pixel.
  reserved
             Must be zero. Reserved for future use.
  transparentcolor
             Contains the red, green, and blue components of the
             transparent color.
-------------------------------------------------------------------------------

*/
public class TbmpResource extends ResourceRecord implements RawIO
{
    public static final int COMPESS_NONE        = 0;
    public static final int COMPESS_SCANLINE    = 1;
    public static final int COMPESS_RLE         = 2;

    short    width;
    short    height;
    short    rowBytes;
    short    flags;
    byte     pixelsize;
    byte     version;
    short    nextDepthOffset;
    byte     transparentIndex;
    byte     compressionType;
    short    reserved;


    byte[]    imageData;

    short[][] imagePixel;
    String    name;
    int       bitsPerPixel;
    int       compression;
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public TbmpResource() 
    {
        this((short)0);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public TbmpResource(int id) 
    {
        super(ResourceRecord.TBMP,(short)id);
    }
    

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void setPixel(short [][] pixel)
    {
        imagePixel = pixel;
    }

    public void setName(String s)
    {
        name = s;
    }
    public String getName()
    {
        return name;
    }

    public void setBitsPerPixel(int bpp)
    {
        bitsPerPixel = bpp;
    }

    public void setCompression(int c)
    {
        compression = c;
    }


    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] ByteVector2CompressedData(Vector compressedData)
    {
        int size = compressedData.size();
        byte result[] = new byte[2+size];

        result[0] = (byte)((size)    & 0xFF);
        result[1] = (byte)((size>>8) & 0xFF);
        for (int b=0;b<size;b++)
        {
            result[2+b] = ((Byte)compressedData.elementAt(b)).byteValue();
        }
        return result;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] scanLineCompression()
    {
	    Vector compressedData = new Vector();

	    for (int i = 0; i < height; ++i) 
        {
		    int flag = 0;
		    for (int j = 0; j < rowBytes; ++j) 
            {
		        if (i == 0 || imageData[rowBytes *      i  + j] !=  
                              imageData[rowBytes * (i - 1) + j]) 
                {
			        flag |= (0x80 >> (j & 7));
		        }
		        if ((j & 7) == 7 || j == rowBytes - 1) 
                {
			        compressedData.addElement( new Byte((byte) flag) );
			        for (int k = (j & ~7); k <= j; ++k) 
                    {
			            if (((flag <<= 1) & 0x100) != 0) 
                        {
				            compressedData.addElement( new Byte(imageData[rowBytes * i + k]));
			            }
			        }
			        flag = 0;
		        }
		    }
	    }

//      Log.println("scanLineCompression:orig size="+imageData.length+" compressed size="+compressedData.size());

        return ByteVector2CompressedData(compressedData);
    }
    

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] runLengthEncoding()
    {
	    Vector compressedData = new Vector();

	    for (int i = 0; i < height; ++i) 
        {
            for (int j = 0;j < rowBytes;j++ ) 
            {
                int count = 1;
                byte value = imageData[rowBytes*i+j];

                while (j < rowBytes-1 && value == imageData[rowBytes*i+j+1])
                {
                    count++;
                    j++;
                }
                compressedData.addElement( new Byte((byte)count) );                
                compressedData.addElement( new Byte(value) );
		    }
	    }

//      Log.println("runLengthEncoding:orig size="+imageData.length+" compressed size="+compressedData.size());

        return ByteVector2CompressedData(compressedData);
        
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private void makePalmImage()
    {
        width               = (short)olh.ui.GUI.screenWidth;  // was 160;
        height              = (short)olh.ui.GUI.screenHeight; // was 160;
        rowBytes            = (short)((width * bitsPerPixel) / 8);
        flags               = 0;
        pixelsize           = (byte)bitsPerPixel;
        version             = (byte)((bitsPerPixel == 1) ? 0 : 1);
        nextDepthOffset     = 0;
        transparentIndex    = 0;
        compressionType     = 0;
        reserved            = 0;

        imageData = new byte[height * rowBytes];

        byte masks[]  = new byte[]{0,0x01,0x03,0,0x0F};
        int  shifts[] = new int []{0,   7,   6,0,   4};

        byte mask = (bitsPerPixel<=4) ? masks[bitsPerPixel]  : (byte)0xFF;
        int  shift= (bitsPerPixel<=4) ? shifts[bitsPerPixel] : 0;

        int  byteNo = 0;
        int  bitNo = 0;

        if (imagePixel != null)
        {
            for (int row=0;row<height;row++)
            {
                for (int col=0;col<width;col++)
                {
                    short pixel = imagePixel[row][col];

                    for (int p=0;p<=(bitsPerPixel-1);p+=8)
                    {
                        byte byteVal;
                        if (bitsPerPixel <= 8)
                        {
                            byteVal = (byte)(pixel&0xFF);
                        }
                        else
                        {
                            int pixelShift = (bitsPerPixel-8-p);
                            byteVal = (byte)((pixel>>pixelShift)&0xFF);
//Log.println("row="+row+" col="+col+" pixel="+pixel+" p="+p+" val="+byteVal);
                        }

                        imageData[byteNo] |= (((byteVal & mask) << (shift-bitNo))) & 0xFF;

                        bitNo = (bitNo + bitsPerPixel) % 8;
                        if (bitNo == 0)
                        {
//Log.println("row="+row+" col="+col+" byteNo="+byteNo);
                            byteNo++;
                        }
                    }
                }
            }
        }

    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void write(DataOutput out) throws IOException 
    {
        byte compressedData[];

        makePalmImage();

        switch (compression)
        {
            case 1: // Scanline
                compressedData = scanLineCompression();
                if (compressedData.length < imageData.length)
                {
                    flags     = (short)0x8000;
                    version   = 1;
                    imageData = compressedData;
                }
                break;
            case 2:// Run Length Encoding
                compressedData = runLengthEncoding();
                if (compressedData.length < imageData.length)
                {
                    flags           = (short)0x8000;
                    version         = 2;
                    compressionType = 1;
                    imageData       = compressedData;
                }
            default:
                break;
        }
        // Direct Color support
        if (pixelsize == 16)
        {
            flags |= (short)0x0400;
            version = 2;
        }

        // Write Bitmap header
        out.writeShort(width);
        out.writeShort(height);
        out.writeShort(rowBytes);
        out.writeShort(flags);
        out.writeByte(pixelsize);
        out.writeByte(version);
        out.writeShort(nextDepthOffset);
        out.writeByte(transparentIndex);
        out.writeByte(compressionType);
        out.writeShort(reserved);

        // Direct Color support
        if (pixelsize == 16)
        {
            Log.println("Writing DirectColor Info");
            out.writeByte(5);out.writeByte(6);out.writeByte(5);out.writeByte(0);
            out.writeByte(0);out.writeByte(0);out.writeByte(0);out.writeByte(0);
        }
        // Write Bitmap data
        out.write(imageData);
    }

  }

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
