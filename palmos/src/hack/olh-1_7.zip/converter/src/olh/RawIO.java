/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright Unknown                                                         */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/* Adopded from a MakeDocJ source                                            */
/*---------------------------------------------------------------------------*/
package olh;
import java.io.*;

public interface RawIO
{
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
	// public void read(DataInput di) throws IOException ;

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    void write(DataOutput out) throws IOException ;
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
