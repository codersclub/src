/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.importer;

import java.io.*;
import java.util.*;
import Acme.JPM.Decoders.ImagerXDecoder;
import Acme.JPM.Encoders.PpmEncoder;
import olh.*;
import olh.ui.*;

public class ImagerXImporter extends SimpleImporter  implements ImportBitmaps
{
    private String name;
    protected DBRecordIndex[] ri;

    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public ImagerXImporter(String fn, DBHeader dbh,RandomAccessFile raf)
    {
        super(fn,dbh,raf);
        Log.println("new ImagerXImporter numrec="+dbHeader.numRecords);
        name = fn;
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public Vector readFile()
    {
        Log.println("ImagerXImporter.readFile");
        readHeader();
        importBitmaps();
        return logos;
    }
    
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public String getDbInfo()
    {
    	return dbInfo;
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void readHeader()
    {
        Log.println("ImagerXImporter.readHeader");
        try
        {
            // Read in resource index 
            ri = new DBRecordIndex[dbHeader.numRecords];
            for(int i = 0; i < dbHeader.numRecords; i++)
            {
                ri[i] = new DBRecordIndex();
                ri[i].read(fin);
            }

            // Read complete file into Byte array
            fin.seek(0);
            array =  new byte[(int)fin.length()];
            fin.readFully(array);

            // Get the name 
            ByteArrayInputStream bis = new ByteArrayInputStream(array);
            bis.skip(ri[0].fileOffset);
            DataInputStream di = new DataInputStream(bis);
            name = readString(di,32);
            Log.println("ImagerXImporter.readHeader name="+name);
        }
        catch (IOException ex)
        {
            Log.println("ImagerXImporter.readHeader ex="+ex);
        }
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void importBitmaps()
    {    
        Log.println("ImagerXImporter.importBitmaps len="+array.length+" off="+ri[0].fileOffset);

        // set file position
        ByteArrayInputStream bis = new ByteArrayInputStream(array);
        bis.skip(ri[0].fileOffset);
        ByteArrayOutputStream bos = new ByteArrayOutputStream();
        ImagerXDecoder decoder = new ImagerXDecoder(bis);
        Logo logo = new Logo(name,decoder);
        logo.setFormat(decoder.getFormat());
        logo.setCompression(decoder.getCompression());
        logos.addElement(logo);
    }
        
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected String readString(DataInputStream di, int max) throws IOException 
    {
        StringBuffer buffer = new StringBuffer();
        byte b;
        do
        {
            b = di.readByte();
            if (b != 0)
            {
                buffer.append((char)b);
            }
        } while ( b != 0 && --max > 0);
        return buffer.toString();
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
