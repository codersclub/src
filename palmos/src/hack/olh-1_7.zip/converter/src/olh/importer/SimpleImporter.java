/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.importer;

import java.io.*;
import java.util.*;
import olh.*;
import olh.ui.*;

import Acme.JPM.Decoders.PalmDecoder;
import Acme.JPM.Encoders.PpmEncoder;

public class SimpleImporter  implements ImportBitmaps
{
    protected RandomAccessFile fin;
    protected DBHeader dbHeader;
    protected String filename;
    protected String dbInfo;
    protected ResourceIndex[] ri;
    protected Vector logos;
    byte[] array;

    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public SimpleImporter(String fn, DBHeader dbh,RandomAccessFile raf)
    {
        filename = fn;
        dbInfo = fn;
        fin = raf;
        dbHeader = dbh;
        logos = new Vector();
        Log.println("new SimpleImporter numrec="+dbHeader.numRecords);
    }


    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public Vector readFile()
    {
        Log.println("SimpleImporter.readFile");
        readHeader();
        importBitmaps();
        return logos;
    }
    
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public String getDbInfo()
    {
    	return dbInfo;
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void readHeader()
    {
        Log.println("SimpleImporter.readHeader");
        try
        {
            // Read in resource index 
            ri = new ResourceIndex[dbHeader.numRecords];
            for(int i = 0; i < dbHeader.numRecords; i++)
            {
                ri[i] = new ResourceIndex();
                ri[i].read(fin);
            }

            // Read complete file into Byte array
            fin.seek(0);
            array =  new byte[(int)fin.length()];
            fin.readFully(array);
        }
        catch (IOException ex)
        {
            Log.println("SimpleImporter.readHeader ex="+ex);
        }
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void importBitmaps()
    {    
        Log.println("SimpleImporter.importBitmaps");
        String name = new File(filename).getName();
        int dot = name.lastIndexOf('.');
        if (dot > 1)
        {
            name = name.substring(0,dot) + ".";
        }

        // Read in all Bitmap resources
        for(int i = 0; i < dbHeader.numRecords; i++)
        {
            Log.println("ImporterBase.importBitmaps i="+i);
            if (ri[i].name == ResourceRecord.TBMP)
            {
                int id = (int)ri[i].id;

                // set file position
                ByteArrayInputStream bis = new ByteArrayInputStream(array);
                bis.skip(ri[i].fileOffset);
                ByteArrayOutputStream bos = new ByteArrayOutputStream();
                PalmDecoder decoder = new PalmDecoder(bis);
                Logo logo = new Logo(name+id,decoder);
                logo.setFormat(decoder.getFormat());
                logo.setCompression(decoder.getCompression());
                if (logo.getFormat() == Logo.FORMAT_8BITCOLOR
                  ||logo.getFormat() == Logo.FORMAT_16BITCOLOR)
                {
                    logo.setDisplayType(Logo.DISPLAY_COLOR);
                }
                logos.addElement(logo);
            }
        }
    }
        
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected String readString(DataInputStream di) throws IOException 
    {
        StringBuffer buffer = new StringBuffer();
        byte b;
        do
        {
            b = di.readByte();
            if (b != 0)
            {
                buffer.append((char)b);
            }
        } while ( b != 0);
        return buffer.toString();
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
