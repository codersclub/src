/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.importer;

import java.awt.*;
import java.io.*;
import java.util.*;

import olh.*;
import olh.ui.*;

public class Importer
{
    private String filename;
    private ImportBitmaps importer;
    private Vector logoList = new Vector();
	private String dbInfo = "";
    
    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public Importer(String filename)
    {
        this.filename = filename;
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public void readFile() 
    {
        try
        {
            // Open File
            RandomAccessFile fin = new RandomAccessFile(filename, "r");

            // Read PDB Header
            DBHeader dbHeader = new DBHeader();
            dbHeader.read(fin);

            // select specific Reader
            if (dbHeader.creatorID == olHaDB.CreatorID && dbHeader.typeID == olHaDB.TypeID)
            {
                // Take specific importer
                importer = new OLHImporter(filename,dbHeader,fin); 
            } 
            else if (dbHeader.creatorID == 0x496d6758 && dbHeader.typeID == 0x76494d47)
            {
                // Type:    vIMG 
                // Creator: ImgX
                importer = new ImagerXImporter(filename,dbHeader,fin); 
            }
            else
            {
                // Take simple importer
                importer = new SimpleImporter(filename,dbHeader,fin); 
            }
            
            logoList = importer.readFile();
            dbInfo =   importer.getDbInfo();
        } 
        catch (IOException e)
        {
            Log.println(e);
        }
    }

    //-------------------------------------------------------------------------
    // 
    //-------------------------------------------------------------------------
    public void setComponent(Component c)
    {
        Enumeration e = logoList.elements();
        while (e.hasMoreElements())
        {
            Logo l = (Logo)e.nextElement();
            l.setComponent(c);
        }
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public Vector getLogoList()
    {
        return logoList;
    }    
    
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public String getDbInfo()
    {
    	return dbInfo;
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
