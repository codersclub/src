/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh.importer;

import java.io.*;
import java.util.*;
import olh.*;
import olh.ui.*;

public class OLHImporter extends SimpleImporter  implements ImportBitmaps
{
    //-------------------------------------------------------------------------
    // Constructor
    //-------------------------------------------------------------------------
    public OLHImporter(String fn, DBHeader dbh,RandomAccessFile raf)
    {
        super(fn,dbh,raf);
        Log.println("new OLHImporter numrec="+dbHeader.numRecords);
    }


    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    public Vector readFile()
    {
        Log.println("OLHImporter.readFile");
        readHeader();
        importBitmaps();
        importStringlist();
        importDbInfo();
        return logos;
    }
    
    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void importDbInfo()
    {
        Log.println("OLHImporter.importDbInfo");
        // Read in a Alert resource
        for(int i = 0; i < dbHeader.numRecords; i++)
        {
            if (ri[i].name == ResourceRecord.TALT &&  ri[i].id == 3000)
            {
                try
                {
                    ByteArrayInputStream bis = new ByteArrayInputStream(array);
                    bis.skip(ri[i].fileOffset);
                    DataInputStream di = new DataInputStream(bis);
                    // Skip unwanted data
                    di.readShort(); // AlertType
                    di.readShort(); // helpId
                    di.readShort(); // numButtons
                    di.readShort(); // defaultButton
                    readString(di); // AlertTitle

                    dbInfo = readString(di); // Alert Message
                }
                catch (IOException ex) 
                {
                    Log.println("OLHImporter.importDbInfo ex="+ex);
                }
            }
        }
    }

    //-------------------------------------------------------------------------
    //
    //-------------------------------------------------------------------------
    protected void importStringlist()
    {    
        Log.println("OLHImporter.importStringlist");
        // Read in all Bitmap resources
        for(int i = 0; i < dbHeader.numRecords; i++)
        {
            if (ri[i].name == ResourceRecord.TSTL &&  ri[i].id == 1000)
            {
                try
                {
                    ByteArrayInputStream bis = new ByteArrayInputStream(array);
                    bis.skip(ri[i].fileOffset);
                    DataInputStream di = new DataInputStream(bis);
                    // Read Prefix
                    String prefix = readString(di);
                    short count = di.readShort();
                    if (count == logos.size())
                    {
                        // Read Strings
                        for (int j=0;j<count;j++)
                        {
                            Logo logo = (Logo)logos.elementAt(j);
                            logo.setName(readString(di));
                        }
                    }
                }
                catch (IOException ex) 
                {
                    Log.println("OLHImporter.importStringlist ex="+ex);
                }
            }
        }
    }
}

//-----------------------------------------------------------------------------
// EOF
//-----------------------------------------------------------------------------
