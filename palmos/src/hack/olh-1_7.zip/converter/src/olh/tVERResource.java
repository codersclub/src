/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package olh;

import java.io.*;


public final class tVERResource extends ResourceRecord implements RawIO
{
    String version = "";
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public tVERResource() 
    {
        this("",(short)0);
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public tVERResource(String v, short id) 
    {
        super(ResourceRecord.TVER,id);
        version = v;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public void write(DataOutput out) throws IOException 
    {
        out.writeBytes(version);
        out.writeByte(0);                   // padding
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
