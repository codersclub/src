/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package Acme.JPM.Decoders;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;

import olh.*;
import olh.ui.*;

/* Details see pilotsdk/PalmOS/Bitmap.html
-------------------------------------------------------------------------------

typedef struct BitmapType {
         Int16 width;
         Int16 height;
         UInt16 rowBytes;
         BitmapFlagsType flags;
         UInt8 pixelSize;
         UInt8 version;
         UInt16 nextDepthOffset;
         UInt8 transparentIndex;
         UInt8 compressionType;
         UInt16 reserved;
     } BitmapType;


 width 
              The width of the bitmap in pixels. You specify this value 
              when you create the bitmap. 
 height 
              The height of the bitmap in pixels. You specify this value 
              when you create the bitmap. 
 rowBytes 
              The number of bytes stored for each row of the bitmap where 
              height is the number of rows. 
 flags 
              The bitmap's attributes. See BitmapFlagsType. 
 pixelSize 
              The pixel depth. Currently supported pixel depths are 
              1, 2, 4, and 8-bit. You specify this value when you create 
              the bitmap. 
 version 
              The version of bitmap encoding used. See Bitmap Constants. 
 nextDepthOffset 
              For bitmap families, this field specifies the start of the 
              next bitmap in the family. The value it
              contains is the number of 4-byte words to the next BitmapType
               from the beginning of this
              one. If the bitmap is not part of a bitmap family or it is 
              the last bitmap in the family, the
              nextDepthOffset is 0. 
 transparentIndex 
              The color index for the transparent color. Only used for 
              version 2 bitmaps and only when the
              transparent flag is set in flags. You specify this value 
              when you create the bitmap using
              Constructor. 
 compressionType 
              The compression type used. Only used for version 2 bitmaps 
              and only when the compressed
              flag is set in flags. See BitmapCompressionType for possible 
              values. The
              BmpCompress function sets this field. 
 reserved 
              Reserved for future use. Must be set to 0. 
                  

-------------------------------------------------------------------------------
ColorTableType 

 The ColorTableType structure defines a color table. Bitmaps can have color tables attached to
 them; however, doing so is not recommended for performance reasons. 


 typedef struct ColorTableType { 
   UInt16            numEntries; 
   // RGBColorType   entry[]; 
 } ColorTableType; 

 Field Descriptions 

 numEntries 
          The number of entries in table. High bits (numEntries > 256)
          reserved.


 The color table entries themselves are of type RGBColorType, and there is one per numEntries. Use
 the macro ColorTableEntries to retrieve these entries. 

 Care should be taken not to confuse a full color table (which includes the count) with an array of
 RGB color values. Some routines operate on entire color tables; others operate on lists of color
 entries. 

-------------------------------------------------------------------------------
 BitmapFlagsType

 The BitmapFlagsType bit field defines the flags field of BitmapType. It specifies the bitmap's
 attributes. 

 typedef struct BitmapFlagsType { 
   UInt16 compressed:1; 
   UInt16 hasColorTable:1; 
   UInt16 hasTransparency:1; 
   UInt16 indirect:1; 
   UInt16 forScreen:1; 
   UInt16 directColor:1; 
   UInt16 reserved:10; 
 } BitmapFlagsType; 

 Field Descriptions 

  compressed 
              If true, the bitmap is compressed and the
              compressionType field specifies the compression used. If
              false, the bitmap is uncompressed. The BmpCompress
              function sets this field. 
  hasColorTable 
              If true, the bitmap has its own color table. If false, the
              bitmap uses the system color table. You specify whether
              the bitmap has its own color table when you create the
              bitmap. 
  hasTransparency 
              If true, the OS will not draw pixels that have a value
              equal to the transparentIndex. If false, the bitmap has no
              transparency value. You specify the transparent color
              when you create the bitmap using Constructor. 
  indirect 
              If true, the address to the bitmap's data is stored where
              the bitmap itself would normally be stored. The actual
              bitmap data is stored elsewhere. If false, the bitmap data
              is stored directly following the bitmap header or directly
              following the bitmap's color table if it has one. 

              Never set this flag. Only the display (screen) bitmap has
              the indirect bit set. 
  forScreen 
              If true, bitmap intended for the display (screen) window.
              Never set this flag. 
  directColor
              If true, bitmap is a direct color (RGB) bitmap.
  reserved 
              Reserved for future use. 

                 
-------------------------------------------------------------------------------
 Bitmap Constants

       Constant 
                   Value 
                                               Description 
 BitmapVersionZero 
               0 
                    Uses the version 0 encoding of a bitmap. Version 0 
                    encoding is supported in Palm
                    OS� 1.0 and later. 
 BitmapVersionOne 
               1 
                    Uses the version 1 encoding of a bitmap. Version 1 
                    encoding is supported in Palm OS
                    3.0 and later. 

                    PalmRez automatically creates version 1 bitmaps 
                    unless you've specified a
                    transparency index or a compressed type when 
                    creating the bitmap in Constructor. 

 BitmapVersionTwo 
               2 
                    Uses the version 2 encoding of a bitmap. Palm OS 3.5 
                    supports version 2 bitmaps.
                    Version 2 bitmaps either use the transparency 
                    index or are compressed. If you
                    programmatically create a bitmap using BmpCreate, 
                    a version 2 bitmap is created.                 
                 
-------------------------------------------------------------------------------
  BitmapCompressionType 

 The BitmapCompressionType enum specifies possible bitmap compression types. These are the
 possible values for the compressionType field of BitmapType. You can compress or uncompress a
 bitmap using a call to BmpCompress. 

 typedef enum { 
   BitmapCompressionTypeScanLine = 0, 
   BitmapCompressionTypeRLE, 
   BitmapCompressionTypePackBits, 
   BitmapCompressionTypeEnd, 
   BitmapCompressionTypeBest = 0x64, 
   BitmapCompressionTypeNone = 0xFF 
 } BitmapCompressionType; 

 Value Descriptions 

  BitmapCompressionTypeScanLine 
             Use scan line compression. Scan line
             compression is compatible with Palm
             OS� 2.0 and higher. 
  BitmapCompressionTypeRLE 
             Use RLE compression. RLE
             compression is supported in Palm OS
             3.5 and higher. 
  BitmapCompressionTypePackBits
             Use PackBits compression. PackBits
             compression is supported in Palm OS
             4.0 only.
  BitmapCompressionTypeEnd
             For internal use only.
  BitmapCompressionTypeBest
             For internal use only.
  BitmapCompressionTypeNone 
             No compression is used. 

             This value should only be used as an
             argument to BmpCompress.               

-------------------------------------------------------------------------------
 New BitmapDirectInfoType 

 For direct color bitmaps-each pixel is represented by an RGB triplet rather than a palette index-the
 BitmapDirectInfoType structure follows the color table if one is present, or immediately follows the
 BitmapType if a color table is not present. For direct color bitmaps, only 16 bits per pixel is supported,
 5 bits for red, 6 bits for green, and 5 bits for blue. 


 typedef struct BitmapDirectInfoType { 
   UInt8 redBits; 
   UInt8 greenBits; 
   UInt8 blueBits; 
   UInt8 reserved; 
   RGBColorType transparentColor; 
 } BitmapDirectInfoType; 

 Field Descriptions 

  redBits 
             Number of bits used by the red component in each pixel.
  greenBits
             Number of bits used by the green component in each pixel.
  blueBits
             Number of bits used by the blue component in each pixel.
  reserved
             Must be zero. Reserved for future use.
  transparentcolor
             Contains the red, green, and blue components of the
             transparent color.
-------------------------------------------------------------------------------

*/

public class PalmDecoder extends Acme.JPM.Decoders.ImageDecoder 
{
    short    width  = -1;
    short    height = -1;
    short    rowBytes;
    short    flags;
    byte     pixelsize;
    byte     version;
    short    nextDepthOffset;
    byte     transparentIndex;
    byte     compressionType;
    short    reserved;

    ColorMapper colormapper;

    byte[]   imageData;
    int      compression = Logo.COMPRESS_NONE;
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public PalmDecoder( InputStream in )
	{
    	super(in);
	}
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public int getFormat() 
    {
        int result = Logo.FORMAT_1BIT;
        switch (pixelsize)
        {
            case 1:  result = Logo.FORMAT_1BIT; break;
            case 2:  result = Logo.FORMAT_2BIT; break;
            case 4:  result = Logo.FORMAT_4BIT; break;
            case 8:  result = Logo.FORMAT_8BITCOLOR; break;
            case 16: result = Logo.FORMAT_16BITCOLOR; break;
            default: break;
        }
        return result;
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public int getCompression() 
    {
        return compression;
    }

    // Methods that subclasses implement.

    //--------------------------------------------------------------------------
    /// Subclasses implement this to read in enough of the image stream
    // to figure out the width and height.
    //--------------------------------------------------------------------------
    void readHeader( InputStream in ) throws IOException
    {

        DataInputStream di = new DataInputStream(in);

        // Read Bitmap header
        width               = di.readShort();
        height              = di.readShort();
        rowBytes            = di.readShort();
        flags               = di.readShort();
        pixelsize           = di.readByte();
        version             = di.readByte();
        nextDepthOffset     = di.readShort();
        transparentIndex    = di.readByte();
        compressionType     = di.readByte();
        reserved            = di.readShort();

        Log.println("PalmDecoder.readHeader width="+width+" height="+height+" rowbytes="+rowBytes);
        Log.println("PalmDecoder.readHeader version="+version+" pixelsize="+pixelsize);

        if (version == 0)
        {
            pixelsize = 1;
        }
        if (version == 2 && ((flags & 0x4000) != 0))
        {
            // Image has Own Color Map
            short numEntries = di.readShort();
            for (int i=0; i<numEntries;i++)
            {
                di.readByte(); di.readByte(); di.readByte(); di.readByte(); 
            }
            Log.println("PalmDecoder.readHeader colormap size="+numEntries);
        }
        if (version == 2 && ((flags & 0x0400) != 0))
        {
            // Direct color bitmap
            for (int i=0; i<8;i++)
            {
                di.readByte();
            }
            Log.println("PalmDecoder.readHeader Direct color bitmap=");
        }

        // Read Bitmap data
        if ((flags & 0x8000) != 0)
        {
            // compressed
            if (version <= 1 || (version == 2 && compressionType == 0)) 
            {
                // Scanline
                imageData = scanLineDecompression(di);
                compression = Logo.COMPRESS_SCANLINE;
            }
            if (version == 2 && compressionType == 1)
            {
                // RLE
                imageData = runLengthDecoding(di);
                compression = Logo.COMPRESS_RLE;
            }
            Log.println("PalmDecoder.readHeader compression="+compression);
        }
        else
        {
            // uncompressed
            imageData = new byte[rowBytes * height];
            di.readFully(imageData,0,imageData.length);
            compression = Logo.COMPRESS_NONE;
            Log.println("PalmDecoder.readHeader imageData.length="+imageData.length);
        }

        colormapper = (pixelsize == 8 || pixelsize == 16)
                        ? (ColorMapper)new PalmColorScale(pixelsize)
                        : (ColorMapper)new PalmGrayScale(pixelsize);

        Log.println("PalmDecoder.readHeader imageData="+imageData);
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to return the width, or -1 if not known.
    //--------------------------------------------------------------------------
    int getWidth()
    {
        return width;
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to return the height, or -1 if not known.
    //--------------------------------------------------------------------------
    int getHeight()
    {
        return height;
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to read pixel data into the rgbRow
    // array, an int[width].  One int per pixel, no offsets or padding,
    // RGBdefault (AARRGGBB) color model.
    //--------------------------------------------------------------------------
    void readRow( InputStream in, int row, int[] rgbRow ) throws IOException
    {
        //System.out.println("PalmDecoder.readRow row="+row+" rgbRow="+rgbRow.length);
        // Cannot decode color pictures with 8 bitsperpixel
        if (imageData != null && pixelsize <=16) 
        {
            byte masks[]  = new byte[]{0,0x01,0x03,0,0x0F};
            int  shifts[] = new int []{0,   7,   6,0,   4};
            int  offset = row*rowBytes;
            int  bitsPerPixel = pixelsize;

            byte mask = (bitsPerPixel<=4) ? masks[bitsPerPixel]  : (byte)0xFF;
            int  shift= (bitsPerPixel<=4) ? shifts[bitsPerPixel] : 0;
            int  byteNo = 0;
            int  bitNo  = 0;


            for (int i=0;i<rgbRow.length;i++)
            {
                int intVal=0;
                for (int p=0;p<=(bitsPerPixel-1);p+=8)
                {
                    byte data = imageData[offset+byteNo];
                    int  d1   = (bitsPerPixel >= 8)
                                ? (int)(data&0xFF)
                                : (~data >> (shift-bitNo));
                    intVal = (intVal << 8) | ((d1&mask)&0xFF);

                    // Move to next position
                    bitNo = (bitNo + bitsPerPixel) % 8;
                    if (bitNo == 0)
                    {
                        byteNo++;
                    }
                }

                //System.out.println("row="+row+" data="+data+" intVal="+intVal);
                int  color = colormapper.getColor(intVal,intVal,intVal,intVal);
    
                //System.out.println("row="+row+" intVal="+intVal+" color="+color);
                rgbRow[i] = 0xFF<<24 | color ;
            }
        }
        else
        {
            for (int i=0;i<rgbRow.length;i++)
            {
                rgbRow[i] = 0xFF<<24 | (i&0xFF)<<16 | (i&0xFF)<<8 | (i&0xFF);
            }
        }
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] scanLineDecompression(DataInputStream di) throws IOException
    {
        imageData = new byte[rowBytes * height];
        short length = di.readShort();
//      System.out.println("Scanline length="+length);
	    for (int i = 0; i < height; ++i) 
        {
            int flag = 0;
            for (int j=0; j<rowBytes; j++)
            {
		        if ((j & 0x07) == 0) 
                {
                    // All bits used read next flag bits
			        flag = di.readByte();
    		    }
	    	    if (((flag <<= 1) & 0x100) != 0) 
                {
                    // a new byte to read
		        	imageData[rowBytes*i+j] = di.readByte();
		        } else {
                    // Copy from previous row
                    imageData[rowBytes*i+j] = imageData[rowBytes*(i-1)+j];
                }
                
            }
	    }
        return imageData;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] runLengthDecoding(DataInputStream di) throws IOException
    {
        imageData = new byte[rowBytes * height];
        short length = di.readShort();
        
	    for (int i = 0; i < height; ++i) 
        {
            int j = 0;
            while (j < rowBytes)
            {
                int  count = di.readByte() & 0xFF;
                byte value = di.readByte();

                while (count-- > 0)
                {
                    imageData[rowBytes*i+j] = value;
                    j++;
                }
            }
	    }
        return imageData;
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
