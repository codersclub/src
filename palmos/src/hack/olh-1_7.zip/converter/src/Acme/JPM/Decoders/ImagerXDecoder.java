/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : Java(TM) 2 Runtime Environment, Standard Edition                */
/* Compiler: jikes Version 1.06 (17 Sep 99)                                  */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
package Acme.JPM.Decoders;

import java.io.*;
import java.util.*;
import java.awt.*;
import java.awt.image.*;
import java.util.zip.*;

import olh.*;
import olh.ui.*;


public class ImagerXDecoder extends Acme.JPM.Decoders.ImageDecoder 
{
    short       width  = -1;
    short       height = -1;
    short       rowBytes;
    byte        pixelsize;
    int         compression = Logo.COMPRESS_NONE;
    byte[]      imageData;
    ColorMapper colormapper;


    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public ImagerXDecoder( InputStream in)
	{
    	super(in);
	}
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public int getFormat() 
    {
        int result = Logo.FORMAT_1BIT;
        switch (pixelsize)
        {
            case 1:  result = Logo.FORMAT_1BIT; break;
            case 2:  result = Logo.FORMAT_2BIT; break;
            case 4:  result = Logo.FORMAT_4BIT; break;
            default: break;
        }
        return result;
    }
    
    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    public int getCompression() 
    {
        return compression;
    }

    // Methods that subclasses implement.

    //--------------------------------------------------------------------------
    /// Subclasses implement this to read in enough of the image stream
    // to figure out the width and height.
    //--------------------------------------------------------------------------
    void readHeader( InputStream in ) throws IOException
    {
        int i;
        DataInputStream di = new DataInputStream(in);

        // Skip image name
        for (i=0; i<32; i++)
        {
            di.readByte();
        }
        
        switch (di.readByte())
        {
            case 0:
                compression = Logo.COMPRESS_NONE;
                break;
            case 1:
                compression = Logo.COMPRESS_RLE;
                break;
            case 2: // LZ77
            default:
                compression = -1;
                Log.println("Unknown or unsupported compression type in ImagerX File");
                break;
        }

        switch (di.readByte())
        {   
            case (byte)0xFF:
                pixelsize = 1;
                break;
            case 0x0:
                pixelsize = 2;
                break;
            case 0x7F:
                pixelsize = 4;
                break;
            default:
                Log.println("ImagerXDecoder Unsupported pixelsize in ImagerX File");
                break;
        }
        colormapper = new PalmGrayScale(pixelsize);

        // Skip unknown data
        for (i=0; i<20; i++)
        {
            di.readByte();
        }
        
        width               = di.readShort();
        height              = di.readShort();
        rowBytes            = (short)(width * pixelsize / 8);

        Log.println("ImagerXDecoder.readHeader width="+width+" height="+height+" rowbytes="+rowBytes);
        Log.println("ImagerXDecoder.readHeader  pixelsize="+pixelsize+" compression="+compression);

        switch (compression)
        {
            case Logo.COMPRESS_NONE:
                imageData = new byte[rowBytes * height];
                di.readFully(imageData,0,imageData.length);
                break;
            case Logo.COMPRESS_RLE:
                imageData = runLengthDecoding(di);
                break;
            default:
                compression = Logo.COMPRESS_NONE;
                break;
        }
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to return the width, or -1 if not known.
    //--------------------------------------------------------------------------
    int getWidth()
    {
        return width;
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to return the height, or -1 if not known.
    //--------------------------------------------------------------------------
    int getHeight()
    {
        return height;
    }

    //--------------------------------------------------------------------------
    /// Subclasses implement this to read pixel data into the rgbRow
    // array, an int[width].  One int per pixel, no offsets or padding,
    // RGBdefault (AARRGGBB) color model.
    //--------------------------------------------------------------------------
    void readRow( InputStream in, int row, int[] rgbRow ) throws IOException
    {
        //System.out.println("PalmDecoder.readRow row="+row+" rgbRow="+rgbRow.length);
        // Cannot decode color pictures with 8 bitsperpixel
        if (imageData != null && pixelsize <=16) 
        {
            byte masks[]  = new byte[]{0,0x01,0x03,0,0x0F};
            int  shifts[] = new int []{0,   7,   6,0,   4};
            int  offset = row*rowBytes;
            int  bitsPerPixel = pixelsize;

            byte mask = (bitsPerPixel<=4) ? masks[bitsPerPixel]  : (byte)0xFF;
            int  shift= (bitsPerPixel<=4) ? shifts[bitsPerPixel] : 0;
            int  byteNo = 0;
            int  bitNo  = 0;


            for (int i=0;i<rgbRow.length;i++)
            {
                int intVal=0;
                for (int p=0;p<=(bitsPerPixel-1);p+=8)
                {
                    byte data = imageData[offset+byteNo];
                    int  d1   = (bitsPerPixel >= 8)
                                ? (int)(data&0xFF)
                                : (~data >> (shift-bitNo));
                    intVal = (intVal << 8) | ((d1&mask)&0xFF);

                    // Move to next position
                    bitNo = (bitNo + bitsPerPixel) % 8;
                    if (bitNo == 0)
                    {
                        byteNo++;
                    }
                }

                //System.out.println("row="+row+" data="+data+" intVal="+intVal);
                int  color = colormapper.getColor(intVal,intVal,intVal,intVal);
    
                //System.out.println("row="+row+" intVal="+intVal+" color="+color);
                rgbRow[i] = 0xFF<<24 | color ;
            }
        }
        else
        {
            for (int i=0;i<rgbRow.length;i++)
            {
                rgbRow[i] = 0xFF<<24 | (i&0xFF)<<16 | (i&0xFF)<<8 | (i&0xFF);
            }
        }
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] scanLineDecompression(DataInputStream di) throws IOException
    {
        imageData = new byte[rowBytes * height];

        return imageData;
    }

    //--------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------
    private byte[] runLengthDecoding(DataInputStream di) throws IOException
    {
        imageData = new byte[rowBytes * height];
        
        int i = 0; 
        while (i<imageData.length)
        {
            byte b = (byte)(di.readByte() & 0xFF);
            int  nbytes = (b & 0x7F) + 1;

            if ((b & 0x80) != 0)
            {
                // compressed data: "nbytes" same bytes
                byte value = di.readByte();
                for (int j=0;j<nbytes;j++)
                {
                    imageData[i++] = value;
                }
            }
            else
            {
                // plain data: "nbytes" to read and store
                for (int j=0;j<nbytes;j++)
                {
                    imageData[i++] = di.readByte();
                }
            }

	    }
        return imageData;
    }
}

//------------------------------------------------------------------------------
// EOF
//------------------------------------------------------------------------------
