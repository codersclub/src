java -classpath olh.jar olh.ui.GUI %1
