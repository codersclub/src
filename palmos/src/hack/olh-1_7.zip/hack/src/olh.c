//*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : PalmOS2.0 .. PalmOS3.5                                          */
/* Compiler: prc-tools Version 2.0 (gcc 2.95.2-kgpd)                         */
/* PilotSDK: 3.5                                                             */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
#include <PalmOS.h>

#include "util.h"

/*---------------------------------------------------------------------------*/
/* convenience pointer to function                                           */
/*---------------------------------------------------------------------------*/
typedef void (*SysSleepP)(Boolean untilReset, Boolean emergency);
extern void SysSleep(Boolean untilReset, Boolean emergency);


/*---------------------------------------------------------------------------*/
/* the function to patch must be the first global function                   */
/* n this source file and has the same declaration as the original           */
/*                                                                           */
/* our replacement to SysSleep function                                      */
/*---------------------------------------------------------------------------*/
void MySysSleep(Boolean untilReset, Boolean emergency)
{
    WinHandle hWindowSave;
    WinHandle hWindowDisplay;

    SysSleepP OriginalSysSleep;
    
    // get old trap address from HackMaster
    FtrGet(CREATOR,1000,(UInt32*)&OriginalSysSleep); 

    // Bug#004: Bitmap is not shown on upper left corner
    // Fix: Set draw window to display window
    hWindowDisplay = WinSetDrawWindow(WinGetDisplayWindow());

    // Bug# 002: OLH displays the last software used before it 
    //      shows the start up logo.
    // Fix: Save and clear the screen when going to sleep. Show the bitmap
    //      on a cleaned screen when waking up.
    hWindowSave = saveWindow(); 

    // call old trap
    OriginalSysSleep(untilReset,emergency);

    showLogo(false, hWindowSave,hWindowDisplay);

}

/*---------------------------------------------------------------------------*/
/* EOF                                                                       */
/*---------------------------------------------------------------------------*/
