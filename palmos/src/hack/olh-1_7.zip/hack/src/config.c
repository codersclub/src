/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : PalmOS2.0 .. PalmOS3.5                                          */
/* Compiler: prc-tools Version 2.0 (gcc 2.95.2-kgpd)                         */
/* PilotSDK: 3.5                                                             */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
#include <PalmOS.h>

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
#include "util.h"
#include "id.h"

void openForm(FormPtr pActiveForm);
Boolean setListValue(FormPtr pActiveForm, Boolean initList);
void setControlValue(FormPtr pForm, int id, int value);
void *getObjectPtr(FormPtr pForm, int id);

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
Boolean eventHandler(EventPtr event)
{
    FormPtr   pActiveForm = FrmGetActiveForm();
    Boolean   handled = false;
    DmOpenRef db;
    WinHandle hWindowSave;
    WinHandle hWindowDisplay;
    int i;

    switch (event->eType)   
    {
        case frmOpenEvent:
            openForm(pActiveForm);
            handled = true;
            break;

        case ctlSelectEvent:
            switch (event->data.ctlEnter.controlID)
            {
                case checkboxID_cyclic:
                    setFlag(event->data.ctlSelect.on,FLAG_CYCLIC);
                    break;

                case checkboxID_backlight:
                    setFlag(event->data.ctlSelect.on,FLAG_BACKLIGHT);
                    break;

                case buttonID_test:
                    hWindowDisplay = WinSetDrawWindow(WinGetDisplayWindow());
                    hWindowSave = saveWindow(); 
                    showLogo(true,hWindowSave,hWindowDisplay);
                    // Bug#005: Listselection is not updated in cyclic mode  
                    setListValue(pActiveForm, false);
                    break;

                case buttonID_db_info:
                    db = DmOpenDatabaseByTypeCreator (DBTYPE, CREATOR,dmModeReadOnly );
                    if (db != 0)
                    {
                        FrmAlert(alertID_base);
                        DmCloseDatabase(db);
                	}
                    break;

                case buttonID_ok:  // Done
                    FrmGotoForm(9000);  // Back to Hackmaster
                    break;

                default:    // Number 1 .. 9
                    i = event->data.ctlEnter.controlID-buttonID_timebase;
                    setNoOfSecs(i);
                    break; 
            }
            handled = true;
            break;

        case lstSelectEvent:
            i = event->data.lstSelect.selection;
            setNextBitmap(i);
            handled = true;
            break;

        default:
            break;

    }    
    return handled;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void listDrawFunc(Int16 itemNum,  RectangleType *bounds, Char **data)
{
    FormPtr pActiveForm = FrmGetActiveForm();
    DmOpenRef db = DmOpenDatabaseByTypeCreator (DBTYPE, CREATOR,dmModeReadOnly );
    if (db != 0)
    {
        MemHandle hStrings = DmGet1Resource (strListRscType, stringlistID_names);
        if (hStrings != 0)
        {
            ListPtr pList = getObjectPtr(pActiveForm,listID_names);
            if (pList != 0)
            {
                StrList *pStringList = MemHandleLock(hStrings);
                Char *s = pStringList->firstString;
                while (itemNum-- > 0)
                {
                    s += StrLen(s) + 1;
                }
                WinDrawChars(s,StrLen(s),bounds->topLeft.x,bounds->topLeft.y);
                MemHandleUnlock(hStrings);

            }
            DmReleaseResource(hStrings);
        }
        DmCloseDatabase(db);
    }
    else
    {
        FrmAlert(alertID_open_db);
    }
    
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
Boolean setListValue(FormPtr pActiveForm, Boolean initList)
{
    DmOpenRef db = DmOpenDatabaseByTypeCreator (DBTYPE, CREATOR,dmModeReadOnly );
    if (db != 0)
    {
        MemHandle hStrings = DmGet1Resource (strListRscType, stringlistID_names);
        if (hStrings != 0)
        {
            ListPtr pList = getObjectPtr(pActiveForm,listID_names);
            if (pList != 0)
            {
                StrList *pStringList = MemHandleLock(hStrings);
                int nextBitmap       = getNextBitmap();
                int numStrings       = pStringList->numStringsLoByte;
                if (initList)
                {
                    LstSetListChoices(pList,NULL,numStrings);
                    LstSetDrawFunction(pList,listDrawFunc);
                }
                MemHandleUnlock(hStrings);
                if (nextBitmap >= numStrings)
                {
                    nextBitmap = 0;
                }
                LstSetSelection (pList,nextBitmap); 
            }
            else
            {
                FrmAlert(alertID_dbgbase+6);
            }
            DmReleaseResource(hStrings);
        }
        else
        {
            FrmAlert(alertID_dbgbase+5);
        }
        // Bug#006: Using the testbuttons displays a FatalError when leaving program
        DmCloseDatabase(db);
    }
    return (db == 0);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void openForm(FormPtr pActiveForm)
{
    if (setListValue(pActiveForm,true))
    {
        FrmAlert(alertID_open_db);
    }

    // Seconds
    setControlValue(pActiveForm, buttonID_timebase+getNoOfSecs(),1); 
    
    // Cyclic
    setControlValue(pActiveForm, checkboxID_cyclic,isFlagSet(FLAG_CYCLIC)); 
    
    // Backlight
    setControlValue(pActiveForm, checkboxID_backlight,isFlagSet(FLAG_BACKLIGHT)); 

    FrmDrawForm(pActiveForm);

}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void setControlValue(FormPtr pForm, int id, int value)
{
    FrmSetControlValue(pForm, FrmGetObjectIndex(pForm, id),value); 
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void *getObjectPtr(FormPtr pForm, int id)
{
    return FrmGetObjectPtr(pForm,FrmGetObjectIndex(pForm,id));
}

/*---------------------------------------------------------------------------*/
/* EOF                                                                       */
/*---------------------------------------------------------------------------*/
