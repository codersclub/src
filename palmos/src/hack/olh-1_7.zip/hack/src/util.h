/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : PalmOS2.0 .. PalmOS3.5                                          */
/* Compiler: prc-tools Version 2.0 (gcc 2.95.2-kgpd)                         */
/* PilotSDK: 3.5                                                             */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

#define PREV_VERSION 1

typedef struct 
{
    int flags;
#define FLAG_CYCLIC     0x0001
#define FLAG_BACKLIGHT  0x0002
#define FLAG_1BIT       0x0004
#define FLAG_2BIT       0x0008
#define FLAG_4BIT       0x0010
#define FLAG_8BIT       0x0020
#define FLAG_24BIT      0x0040
#define FLAG_COLOR      0x0080
#define FLAG_RLE        0x0100
#define FLAG_16BIT      0x0200
    int count;
    int noOfSecs;
    int nextBitmap;
} Preferences;

typedef struct
{
    char prefixString;
    char numStringsHiByte;
    char numStringsLoByte;
    char firstString[1];
} StrList;

void showLogo(Boolean showAlert, WinHandle hSavedBitmap,WinHandle hWindowDisplay);
WinHandle saveWindow();

void getPrefs(Preferences *pPrefs);
void setPrefs(Preferences *pPrefs);

int getNoOfSecs();
int getNextBitmap();
void setNoOfSecs(int noOfSecs);
void setNextBitmap(int nextBitmap);

int isFlagSet(int flag);
void setFlag(Boolean on, int flag);

void step(int val1, int val2, int val3);

/*---------------------------------------------------------------------------*/
/* EOF                                                                       */
/*---------------------------------------------------------------------------*/
