/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : PalmOS2.0 .. PalmOS3.5                                          */
/* Compiler: prc-tools Version 2.0 (gcc 2.95.2-kgpd)                         */
/* PilotSDK: 3.5                                                             */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*/
/* Defines for hack and config                                               */
/*---------------------------------------------------------------------------*/
#define formID_config           2000
#define stringID_config         1001
#define buttonID_timebase       1000
#define checkboxID_cyclic       1200
#define checkboxID_backlight    1201
#define listID_names            1100
#define buttonID_ok             2001
#define buttonID_test           2000
#define buttonID_db_info        2002

#define formID_info             3000
#define stringID_info           1000

#define alertID_open_db         1000
#define alertID_bitmaptype      1002

#define alertID_dbgbase         1100

/*---------------------------------------------------------------------------*/
/* Defines for logodatabase                                                  */
/*---------------------------------------------------------------------------*/
#define stringlistID_names      1000
#define bitmapID_base           3000
#define alertID_base            3000

/*---------------------------------------------------------------------------*/
/* EOF                                                                       */
/*---------------------------------------------------------------------------*/
