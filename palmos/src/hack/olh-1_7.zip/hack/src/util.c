/*---------------------------------------------------------------------------*/
/* Project : Open Logo Hack http://olh.sourceforge.net                       */
/* Copyright (C) 2001 Frank Schnekenbuehl <f.sck@web.de>                     */
/*                                                                           */
/* Author  : Frank Schnekenbuehl <f.sck@web.de>                              */
/* OS      : PalmOS2.0 .. PalmOS3.5                                          */
/* Compiler: prc-tools Version 2.0 (gcc 2.95.2-kgpd)                         */
/* PilotSDK: 3.5                                                             */
/* License : GNU Public License. See file LICENSE                            */
/*                                                                           */
/*---------------------------------------------------------------------------*/
#include <PalmOS.h>

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
#include "util.h"
#include "id.h"

// Grr. Don't know a better way to turn on/off backlight
Boolean HwrBacklight(Boolean set, Boolean newState)  SYS_TRAP(sysTrapHwrBacklightV33);


static Boolean isHardwareCompatible(BitmapPtr pBitmap);
static void showBitmap(BitmapPtr pBitmap);

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void showLogo(Boolean showAlert, WinHandle hSavedWindow, WinHandle hWindowDisplay)
{
    MemHandle hBitmap = NULL;
    DmOpenRef db; 
    int bitmapNumber;

    db = DmOpenDatabaseByTypeCreator (DBTYPE, CREATOR,dmModeReadOnly );
    if (db != 0 && hSavedWindow != NULL && hWindowDisplay != NULL)
    {
        bitmapNumber = getNextBitmap();

        // Bug# 001: OLH uses LaucherIII Icons when using cyclic mode
        // Fix: use the topmost open database to get the bitmap 
        //      not all open databases
        // hBitmap = DmGetResource (bitmapRsc, bitmapID_base+bitmapNumber);
        hBitmap = DmGet1Resource (bitmapRsc, bitmapID_base+bitmapNumber);
        if (hBitmap == NULL)
        {
            // Next Bitmap not found. Try the first one
            bitmapNumber = 0;
            hBitmap = DmGet1Resource (bitmapRsc, bitmapID_base+bitmapNumber);
        }

        if (hBitmap != 0)
        {
            BitmapPtr pLogoBitmap = (BitmapPtr) MemHandleLock(hBitmap); 

            if (isFlagSet(FLAG_CYCLIC))
            {
                bitmapNumber++;
            }
            setNextBitmap(bitmapNumber);
            // Got a pointer to the Bitmap ?
            if (pLogoBitmap != 0)
            {
                if (isHardwareCompatible(pLogoBitmap))
                {
                    showBitmap(pLogoBitmap);
                }
                else
                {
                    if (showAlert) FrmAlert(alertID_bitmaptype);
                }
                MemHandleUnlock(hBitmap);
            }
            else
            {
                if (showAlert) FrmAlert(alertID_dbgbase+3);
            }
            DmReleaseResource (hBitmap);
        }
        else
        {
            if (showAlert) FrmAlert(alertID_dbgbase+1);
        }

        DmCloseDatabase(db);
    }

    // Restore the old window contents
    if (hSavedWindow != 0)
    {
        // if there was an alert shown, we have to set the drawing window
        // again to the DisplayWindow because we saved the DisplayWindow
        WinSetDrawWindow(WinGetDisplayWindow());
        // and now restore the bits
        WinRestoreBits (hSavedWindow, (Coord)0, (Coord)0);
    }
    if (hWindowDisplay != 0)
    {
        WinSetDrawWindow(hWindowDisplay);
    }
    
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static void getDisplayRect(RectangleType *pRect)
{
    Coord extentX,extentY;

    WinGetDisplayExtent (&extentX, &extentY);
    pRect->topLeft.x = 0;
    pRect->topLeft.y = 0;
    pRect->extent.x  = extentX; 
    pRect->extent.y  = extentY;
    //  step(1,extentX,extentY);
 }

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
WinHandle saveWindow()
{
    WinHandle hWindow;
    RectangleType rect;
    UInt16 error = 0;

    getDisplayRect(&rect);

    // Don't forget to free the Window using WinRestoreBits
    hWindow = WinSaveBits (&rect, &error); 

    // Called when going to sleep or in test-mode, 
    // so we do a clear screen here  */
    WinEraseRectangle (&rect, 0);

    return hWindow;    
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static RGBColorType *saveColorMap(int bitmapDepth)
{
    RGBColorType *pColorMap = NULL;
    if (bitmapDepth >= 8)
    {
        Err error;
        
        // Get Memory for the color palette
        pColorMap = (RGBColorType*)MemPtrNew(256*sizeof(RGBColorType));
        if (pColorMap != NULL)
        {
            // Get old palette
            error = WinPalette (winPaletteGet,0,256,pColorMap);
            if (error == 0)
            {
                // Set default palette
                WinPalette (winPaletteSetToDefault,0,256,NULL);
            }
            else
            {
                MemPtrFree(pColorMap);
                pColorMap = NULL;
            } 
        }
    }
    return pColorMap;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static void restoreColorMap(RGBColorType *pColorMap)
{
    if (pColorMap != NULL)
    {
        // Erase the screen before restoring the color palette
        RectangleType rect;
        getDisplayRect(&rect);
        WinEraseRectangle (&rect, 0);

        // Restore the colormap. This seems not to be enough for 
        // 16 bit color images 
        WinPalette(winPaletteSet,0,256,pColorMap);

        // Free the memory allocated in saveColorMap
        MemPtrFree(pColorMap);
    }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static void doBacklight(Boolean requested, Boolean state)
{
    if (requested) 
    {
        UInt32 backlight;

        if (FtrGet (sysFtrCreator, sysFtrNumBacklight,  &backlight) == 0)
        {
            if (backlight>0)
            {
                HwrBacklight(true,state);
            }
        }
    }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static void showBitmap(BitmapPtr pBitmap)
{
    // If we reach this point, we know and must be sure that the image is
    // compatible to our hardware 
    UInt32 newDepth = pBitmap->pixelSize;
    UInt32 oldDepth = newDepth;
    Err    error;
    RGBColorType *pColorMap = NULL;

    if (newDepth > 1) 
    {
        // Depth > 1 and knowing the hardware is compatible
        // says that we have a PalmOS > 2.0 so we can use
        // WinScreenMode the get and set the screen depth
        error = WinScreenMode (winScreenModeGet, NULL, NULL, &oldDepth, NULL);
        if (error == 0 && (oldDepth != newDepth) )
        {
            // Set new screen depth
            WinScreenMode (winScreenModeSet, NULL, NULL, &newDepth, NULL); 
        }
    }

    // It's a color image. Save the old palette
    // Bug#007: Colorpalette is not set to default when showing color images
    // Fix: Save the colormap
    pColorMap = saveColorMap(newDepth);

    // Draw, Wait and Restore 
    WinDrawBitmap(pBitmap,0,0); 
    doBacklight(isFlagSet(FLAG_BACKLIGHT),true);

    SysTaskDelay(getNoOfSecs() * SysTicksPerSecond());// Wait

    doBacklight(isFlagSet(FLAG_BACKLIGHT),false);

    restoreColorMap(pColorMap);

    if (oldDepth != newDepth)
    {
        // oldDepth and newDepth can only be different if we already
        // used WinScreenMode so restore the old screen depth
        WinScreenMode (winScreenModeSet, NULL, NULL, &oldDepth, NULL); 
    }
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
static Boolean isHardwareCompatible(BitmapPtr pBitmap)
{
    Preferences prefs;
    Boolean     result = false;
    UInt8       pixelSize = pBitmap->pixelSize;

    getPrefs(&prefs);

    result |= (pixelSize <=  1 && (prefs.flags & FLAG_1BIT));
    result |= (pixelSize ==  2 && (prefs.flags & FLAG_2BIT));
    result |= (pixelSize ==  4 && (prefs.flags & FLAG_4BIT));
    result |= (pixelSize ==  8 && (prefs.flags & FLAG_8BIT));
    result |= (pixelSize == 16 && (prefs.flags & FLAG_16BIT));

    if (pBitmap->flags.compressed == 1 && pBitmap->version > 1)
    {
        if (pBitmap->compressionType == BitmapCompressionTypeRLE)
        {
            result &= ((prefs.flags & FLAG_RLE) != 0);
        }
    }

//  step (100,pBitmap->width,pBitmap->height);
//  step (101,pixelSize,pBitmap->flags.compressed);
//  step (102,prefs.flags,result);
    return result;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void setPrefs(Preferences *pPrefs)
{
    PrefSetAppPreferencesV10(CREATOR, PREV_VERSION, (void*)pPrefs, sizeof(Preferences));
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void getPrefs(Preferences *pPrefs)
{
    if (!PrefGetAppPreferencesV10(CREATOR, PREV_VERSION, (void*)pPrefs, sizeof(Preferences)))
    {
        UInt32 featureValue;
        
        pPrefs->noOfSecs   = 5;
        pPrefs->nextBitmap = 0;
        pPrefs->flags      = FLAG_1BIT;
        pPrefs->count      = 0;
        // Test available hardware features
        
        // check for PalmOS 3
        FtrGet(sysFtrCreator, sysFtrNumROMVersion, &featureValue);
        if (featureValue >= 0x03003000 ) 
        {
            Boolean enableColor;
            // Compression Type
            if (featureValue >= 0x03503000) pPrefs->flags |= FLAG_RLE;

            // PixelSize
            if (WinScreenMode (winScreenModeGetSupportedDepths, NULL, NULL, &featureValue, NULL) == 0)
            {
                if (featureValue & 0x00000002)  pPrefs->flags |= FLAG_2BIT;
                if (featureValue & 0x00000008)  pPrefs->flags |= FLAG_4BIT;
                if (featureValue & 0x00000080)  pPrefs->flags |= FLAG_8BIT;
                if (featureValue & 0x00008000)  pPrefs->flags |= FLAG_16BIT;
                if (featureValue & 0x00800000)  pPrefs->flags |= FLAG_24BIT;
            }
            
            // Color
            if (WinScreenMode (winScreenModeGetSupportsColor, NULL, NULL, NULL,&enableColor) == 0)
            {
                if (enableColor)  pPrefs->flags |= FLAG_COLOR;
            }
        }
        //step(100,0,pPrefs->flags);
        setPrefs(pPrefs);
    }
}


/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
int getNoOfSecs()
{
    Preferences prefs;
    
    getPrefs(&prefs);

    return prefs.noOfSecs;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
int getNextBitmap()
{
    Preferences prefs;
    
    getPrefs(&prefs);

    return prefs.nextBitmap;
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void setNoOfSecs(int noOfSecs)
{
    Preferences prefs;

    getPrefs(&prefs);
    prefs.noOfSecs   = noOfSecs;
    setPrefs(&prefs);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void setNextBitmap(int nextBitmap)
{
    Preferences prefs;
    getPrefs(&prefs);
    prefs.nextBitmap = nextBitmap;
    setPrefs(&prefs);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
int isFlagSet(int flag)
{
    Preferences prefs;
    getPrefs(&prefs);
    return (prefs.flags & flag);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void setFlag(Boolean on, int flag)
{
    Preferences prefs;
    getPrefs(&prefs);
    if (on)
    {
        prefs.flags |= flag;
    }
    else
    {
        prefs.flags &= ~flag;
    }
    setPrefs(&prefs);
}

/*---------------------------------------------------------------------------*/
/*                                                                           */
/*---------------------------------------------------------------------------*/
void step(int val1, int val2, int val3)
{
    char cbuffer1[20];
    char cbuffer2[20];
    char cbuffer3[20];

    StrIToA(cbuffer1,val1);
    StrIToA(cbuffer2,val2);
    StrIToA(cbuffer3,val3);
    FrmCustomAlert (alertID_dbgbase+4, cbuffer1, cbuffer2,cbuffer3) ;
}

/*---------------------------------------------------------------------------*/
/* EOF                                                                       */
/*---------------------------------------------------------------------------*/
