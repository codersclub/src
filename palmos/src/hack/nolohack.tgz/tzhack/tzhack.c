#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#define NON_PORTABLE
#include <Hardware/Hardware.h>
#include <System/Globals.h>

void mybattdialog()
{
  RectangleType r = {{0,0},{160,15}};
  if( GHwrBatteryLevel < GSysBatteryWarnThreshold )
    WinInvertRectangle(&r,0);
  return;
}
