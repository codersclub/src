#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#define NON_PORTABLE
#define asm
#include <Hardware/Hardware.h>

Boolean eventhandle(EventPtr event)
{
  FormPtr form;

  form = FrmGetActiveForm();

  {
    char obuf[80];

    obuf[0] = 0;
    StrIToA(&obuf[StrLen(obuf)], event->eType);
    StrCat(obuf, " ");
    StrIToA(&obuf[StrLen(obuf)], event->data.keyDown.chr);
    StrCat(obuf, " ");
    StrIToA(&obuf[StrLen(obuf)], event->data.keyDown.keyCode);
    StrCat(obuf, " ");
    StrIToA(&obuf[StrLen(obuf)], event->data.keyDown.modifiers);
    StrCat(obuf, "       ");
    WinDrawChars(obuf, StrLen(obuf), 10, 80);
  }

  switch (event->eType) {

  case frmOpenEvent:
    FrmDrawForm(form);
    return 1;

  case keyDownEvent:

  case menuEvent:
  case nilEvent:
  case daySelectEvent:
  case appStopEvent:
  case firstUserEvent:

  case fldEnterEvent:
  case fldHeightChangedEvent:
  case fldChangedEvent:

  case popSelectEvent:

  case lstEnterEvent:
  case lstSelectEvent:
  case lstExitEvent:

  case penDownEvent:
  case penUpEvent:
  case penMoveEvent:

  case sclExitEvent:
  case sclEnterEvent:
  case sclRepeatEvent:

  case tblEnterEvent:
  case tblSelectEvent:
  case tblExitEvent:

    if (FrmHandleEvent(form, event))
      return 1;
    if (event->screenY < 160)
      return 1;
    break;

  case ctlSelectEvent:
  case ctlEnterEvent:
  case ctlExitEvent:
  case ctlRepeatEvent:

  case frmLoadEvent:
  case frmGotoEvent:
  case frmSaveEvent:
  case frmCloseEvent:
  case frmTitleEnterEvent:
  case frmUpdateEvent:

  case winEnterEvent:
  case winExitEvent:
    FrmHandleEvent(form, event);
    return 1;

  case frmTitleSelectEvent:
    FrmGotoForm(9000);
    return 1;
  }

  return 0;
}
