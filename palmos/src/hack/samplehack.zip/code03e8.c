/*
Sample Hack

Put into the public domain by Roger Chaplin <foursquaredev@att.net>

Please read the readme.txt file that came in the Sample Hack package.

This file creates the code resource that patches an OS trap; in this case,
the EvtGetEvent OS call. It demonstrates the use of app preferences for
sharing data between the OS trap patch(es) and the hack's preferences panel,
if there is one.
*/


#include <Pilot.h>
#include <FeatureMgr.h>
#include "myhack.h"
#include "hackuidef.h"


// This is the code that will be called whenever ANY app calls EvtGetEvent,
// and myhack is enabled in HackMaster. HackMaster is not smart about the
// content of this file; it will simply jump to the first executable statement
// in this file. If you need helper functions, prototype them above, and
// define them AFTER the trap patch.
void
MyEvtGetEvent(EventPtr event, SDWord timeout)
{
    DWord               temp;
    void              (*oldTrap)(EventPtr, SDWord);
    mypref_t            prefs;

    // get the address of the old EvtGetEvent() from HackMaster
    FtrGet(MYCRID, trapIDEvtGetEvent, &temp);
    // set the function pointer to the old trap
    oldTrap = (void (*)(EventPtr, SDWord)) temp;

    // Since this hack is patching EvtGetEvent, there's not really much
    // useful work we can do BEFORE making the call to the OS, to get the
    // event, so we call the linked EvtGetEvent() first. This is not always
    // the case; sometimes you want to do something, then call the original
    // trap routine, then maybe do something else. This design decision is far
    // beyond the scope of this Sample.
    oldTrap(event, timeout);

    // Now, just for the sake of example, let's do something only if the event
    // is a backlightChr keyDown event.
    if (event->eType == keyDownEvent &&
            event->data.keyDown.chr == backlightChr &&
                (event->data.keyDown.modifiers & commandKeyMask))
        // Always always ALWAYS check for errors, and bail out if one occurs.
        // This sample uses the old v1.0 preferences call, so that it can run
        // on any OS.
        if (PrefGetAppPreferencesV10(MYCRID, MYPREFVERSION,
                    (VoidPtr) &prefs, sizeof(mypref_t)))
            // Just for sake of example, let's check the control value as
            // entered in the hack's preferences panel, and, if it's greater
            // than 3, swallow up the event, thus disabling the backlight
            // control.
            if (prefs.controlvalue > 3)
                event->eType = nilEvent;
}
