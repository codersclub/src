/*
Sample Hack

Put into the public domain by Roger Chaplin <foursquaredev@att.net>

Please read the readme.txt file that came in the Sample Hack package.

This file is the source code for the hack's preferences panel.
*/


#include <Pilot.h>
#include "myhack.h"
#include "hackuidef.h"

// This is the code that will be called whenever the user taps myhack's "+"
// button in the HackMaster list. HackMaster is not smart about the content of
// this file; it will simply jump to the first executable statement in this
// file. If you need helper functions, prototype them above, and define them
// AFTER the trap patch.
static Boolean
PrefsHandler(EventPtr event)
{
    FormPtr         form;
    VoidHand        h, oldh;
    CharPtr         str;
    FieldPtr        fld;
    mypref_t        prefs;
    int             handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
            form = FrmGetActiveForm();
            // Here, if the get app preferences operation fails, we initialize
            // the prefs and save them. This is the appropriate place to do
            // this, NOT in the OS trap patch routine.
            if (!PrefGetAppPreferencesV10(MYCRID, MYPREFVERSION,
                        (VoidPtr) &prefs, sizeof(mypref_t)))
            {
                prefs.controlvalue = 0;
                PrefSetAppPreferencesV10(MYCRID, MYPREFVERSION,
                        (VoidPtr) &prefs, sizeof(mypref_t));
            }
            fld = FrmGetObjectPtr(form, FrmGetObjectIndex(form, FIDcontrol));
            h = MemHandleNew(4);
            if (h)
            {
                str = MemHandleLock(h);
                StrIToA(str, prefs.controlvalue);
                MemHandleUnlock(h);
                oldh = (VoidHand) FldGetTextHandle(fld);
                FldSetTextHandle(fld, (Handle) h);
                if (oldh)
                    MemHandleFree(oldh);
            }
            FrmDrawForm(form);
            handled = 1;
            break;

        case ctlSelectEvent:
            switch (event->data.ctlEnter.controlID)
            {
                case BIDprefOK:
                    form = FrmGetActiveForm();
                    PrefGetAppPreferencesV10(MYCRID, MYPREFVERSION,
                        (VoidPtr) &prefs, sizeof(mypref_t));
                    fld = FrmGetObjectPtr(form,
                            FrmGetObjectIndex(form, FIDcontrol));
                    h = (VoidHand) FldGetTextHandle(fld);
                    if (h)  // make sure there's a valid handle in the field
                    {
                        str = MemHandleLock(h);
                        if (*str)   // make sure it's not a null string
                        {
                            prefs.controlvalue = StrAToI(str);
                            PrefSetAppPreferencesV10(MYCRID, MYPREFVERSION,
                                    (VoidPtr) &prefs, sizeof(mypref_t));
                        }
                        MemHandleUnlock(h);
                    }

                    // INTENTIONAL FALL-THROUGH HERE
                case BIDprefcancel:
                    FrmGotoForm(9000);  // return to HackMaster control panel
                    handled = 1;
                    break;
            }
            break;

        default:
            break;
    }

    return handled;
}
