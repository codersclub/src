// This file is included by .rcp files compiled by Pilrc
// It must be compatible with Pilrc's requirements
// That accounts for the scarcity of comments and other filler

#define trapIDEvtGetEvent       1000
#define trapnumEvtGetEvent      41245
#define FMIDprefs       2000
#define FIDcontrol      2001
#define BIDprefOK       2002
#define BIDprefcancel   2003
#define appIconID       3000
#define FMIDabout       3000
#define HIDabout        3000
