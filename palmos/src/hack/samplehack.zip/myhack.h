/*
Sample Hack

Put into the public domain by Roger Chaplin <foursquaredev@att.net>

Please read the readme.txt file that came in the Sample Hack package.

This is the header file that declares constants and data that are shared
amongst the various parts of the hack (the code resources for the trap
patches, and the optional preferences panel).
*/


// The hack's creator ID -- make sure you reserve one at the Palm Developer
// Zone. The one given here is entirely bogus and is not reserved.
#define MYCRID          'myHK'

// The struct that defines the app preferences for the hack.
#define MYPREFVERSION   1
typedef struct
{
    Word        controlvalue;
} mypref_t;
