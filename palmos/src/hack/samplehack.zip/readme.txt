This is the readme.txt file for the Sample Hack package.
Placed into the public domain by Roger Chaplin <foursquaredev@att.net>

This package is intended to demonstrate the creation of a HackMaster hack for
Palm Computing(R) platform handhelds, using the free GNU GCC/prctools
development tools.

The package includes the following files:
    hackapi.html
    code03e8.c
    code07d0.c
    myhack.h
    hackuidef.h
    myhack.prc
    makefile

Before you can hope to understand any of the source code, you need to read and
comprehend "How To Write a Hack" by Edward Keyes. I have included a copy in
the Sample Hack package; it is the hackapi.html file.

Although the code in this package is intended purely as an example, it will
compile and do something reasonably useful: disable turning on or off the
backlight. The sample illustrates the use of app preferences for sharing data
among code resources, and the use of a HackMaster preferences panel.

A little bit of my philosophy of design has crept into the code in this
sample. This is most apparent in the way preferences are handled. First, I
continue to use the old V1.0 app preferences routines, as that is one of the
many things necessary to enable my apps to run on Pilot 1000s and 5000s.
Second, I don't ever create app preferences or databases in the OS trap patch
code; instead, I test for the presence of apps/databases and create them if
necessary in the hack's preference panel. OS trap patch code is time critical;
the preferences panel is not. A result of this design choice is that until the
user opens the preferences panel, the hack is essentially a no-op, even if
it's been enabled using the checkbox. Of course, there is nothing forcing you
to do it the same way; you just need to be aware that *this* code works that
way.

The odd names for the C source files derive from the way the makefile is
written. From each C source file it creates a code resource having the same
name, but with extension .bin rather than .c. This greatly simplifies writing
make dependencies and rules, and facilitates adding or removing code resources
by simply adding or removing their names from the HACKSRC definition in the
makefile.

This sample does not intend to teach the use of make; there are plenty of
other places where you can learn that. If you know make well, you should not
be too hard pressed to figure out what I've done (after all, I'm no make
guru). If the makefile makes no sense to you (pardon the pun), then rest
assured that you can create any hack you want by simply modifying the lines
above the one that says

    # You shouldn't have to change anything below this line

The makefile is written so that if you issue the simple command `make' it will
build the debug version, suitable for installing on Poser and debugging with
GDB. If you use `make release' it will build with debug symbols disabled and
full optimization enabled. If you want to rebuild everything, then do a
`make clean' first.

Happy hacking!

