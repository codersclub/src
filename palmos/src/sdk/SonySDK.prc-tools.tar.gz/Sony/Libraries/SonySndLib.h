/******************************************************************************
 *                                                                            *
 *            (C) Copyright 2000-2002, Sony Corporation                       *
 *                                                                            *
 *----------------------------------------------------------------------------*
 *                                                                            *
 *    <IDENTIFICATION>                                                        *
 *       file name    : $Workfile: SonySndLib.h $
 *                                                                            *
 *    <PROFILE>                                                               *
 *       Header file for SonySnd Library                                      *
 *                                                                            *
 *    <HISTORY>                                                               *
 *       Started on   : 02/06/24                                              *
 *       Last Modified: $Date: 02/08/15 2:24 $
 *                                                                            *
 ******************************************************************************/
#ifndef _SNDMGRLIB_H_INCLUDED_
#define _SNDMGRLIB_H_INCLUDED_

#include <SonyErrorBase.h>
#include <SonySystemResources.h>
#include <SoundMgr.h>


#if CPU_TYPE != CPU_68K
	#define SonySnd_LIB_TRAP(trapNum) 	// direct link to library code
#else
	#define SonySnd_LIB_TRAP(trapNum)	SYS_TRAP(trapNum)
#endif

#define SonySnd_LIB_APIVersion		(0x00000002)
#define SonySndLibVersionNum2		(0x00020000)

#define sndPcmPlayAllMilliSec		(0xFFFFFFFFUL)
// System Sounds
#define sysResTSound					'wave'	// Resource type for sound resources.

/****************************************************************************
	Sony Sound Library	Error Codes( See sndErrorClass which is defined in SystemMgr.h )
****************************************************************************/
#define	SonySndErrBase				(sndErrorClass)
#define	errOpenError				sndErrOpen
#define errAlreadyOpen				(SonySndErrBase | 10)
#define errCloseError				(SonySndErrBase | 11)
#define	errAlreadyClose				(SonySndErrBase | 12)

/****************************************************************************
		Struct
****************************************************************************/
typedef struct _tagSndPcmCallbacksType {
	SndCallbackInfoType	completion;
	SndCallbackInfoType	continuous;
	SndCallbackInfoType	blocking;
	SndCallbackInfoType	reserced;
	} SndPcmCallbacksType;

typedef struct _tagSndPcmFormatType {
	UInt16				formatTag;
	UInt16				numOfChan;
	UInt32				samplePerSec;
	UInt16				bitPerSample;
	UInt32				dataSize;
} SndPcmFormatType;
	
typedef struct _tagSndPcmOptionsType {
	UInt16				amplitude;
	UInt16				pan;
	Boolean				interruptible;
	UInt8				reserved;
	UInt32				dwStartMilliSec;
	UInt32				dwEndMilliSec;
} SndPcmOptionsType;


typedef enum _tagSndPcmCmdEnum {
	sndPcmCmdPlay  = 1,
	sndPcmCmdPlayList,
	sndPcmCmdEndOfList,
	sndPcmCmdDuration
} SndPcmCmdEnum;


#if CPU_TYPE == CPU_68K
#define SonySndTrapLibAPIVersion 		(sysLibTrapCustom)
#define SonySndTrapSndExtnGetProperty		(sysLibTrapCustom+1)
#define SonySndTrapSndPlayPcm			(sysLibTrapCustom+2)
#define SonySndTrapSndPlayPcmResource		(sysLibTrapCustom+3)
#define SonySndTrapSndExtnSetPa1Volume		(sysLibTrapCustom+4)
#define SonySndTrapSndExtnGetPa1Volume		(sysLibTrapCustom+5)
#define SonySndTrapSndExtnGetDuration		(sysLibTrapCustom+6) 	
#define SonySndTrapSndExtnEnableSystemSound	(sysLibTrapCustom+7)
#define SonySndTrapSndPlayPcmResourceAsync	(sysLibTrapCustom+8)
#endif

typedef enum SndExtnSrcEnumTag {
	sndExtnSrcStreamAudio = 0,
//	sndExtnSrcBeep,
//	sndExtnSrcSndMgr,
    sndExtnSrcAll = 0xFFFFFFFF // all src
} SndExtnSrc;

typedef enum SndExtnPropEnumTag {
	sndExtnPropVolumeStepNum = 1,
	sndExtnPropPlayOrgADPCM,
	sndExtnPropPlayImaADPCM,
	sndExtnPropRecImaADPCM
} SndExtnProcEnum;

/********************************************************************
 * API Prototypes
 ********************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

#if CPU_TYPE == CPU_68K
/****************************************************************************
 * 		Standard library open, close, sleep and wake functions
 ***************************************************************************/

extern Err SndExtnOpen(UInt16 refNum)
	  			SonySnd_LIB_TRAP(sysLibTrapOpen);

extern Err SndExtnClose(UInt16 refNum)
				SonySnd_LIB_TRAP(sysLibTrapClose);

extern Err SndExtnWake(UInt16 refNum)
  				SonySnd_LIB_TRAP(sysLibTrapWake);

extern Err SndExtnSleep(UInt16 refNum)
				SonySnd_LIB_TRAP(sysLibTrapSleep);

/************************************************************************
 * 		Custom library API functions
 ************************************************************************/
extern UInt32 SndExtnGetAPIVersion(UInt16 refNum)
				SonySnd_LIB_TRAP(SonySndTrapLibAPIVersion);

extern Err SndExtnPlayPcm(UInt16 refNum, void* chanP, SndPcmCmdEnum cmd, UInt8* pcmP, 
               SndPcmFormatType* formatP, SndPcmOptionsType* selP, 
               SndPcmCallbacksType* callbacksP, Boolean bNoWait )
				SonySnd_LIB_TRAP(SonySndTrapSndPlayPcm);

extern Err SndExtnPlayPcmResource(UInt16 refNum, UInt32 resType, Int16 resID, 
                       SystemPreferencesChoice volumeSelector)
				SonySnd_LIB_TRAP(SonySndTrapSndPlayPcmResource);

/************************************************************************
 * 		New API
 ************************************************************************/
extern Err SndExtnGetProperty(UInt16 refNum, SndExtnProcEnum sndProp, void *propP)
				SonySnd_LIB_TRAP(SonySndTrapSndExtnGetProperty);

extern Err SndExtnSetPa1Volume(UInt16 refNum, UInt8*, UInt8*)
				SonySnd_LIB_TRAP(SonySndTrapSndExtnSetPa1Volume);

extern Err SndExtnGetPa1Volume(UInt16 refNum, UInt8*, UInt8*)
				SonySnd_LIB_TRAP(SonySndTrapSndExtnGetPa1Volume);
				
extern Err SndExtnGetDuration(UInt16 refNum, UInt8*, UInt32*)
				SonySnd_LIB_TRAP(SonySndTrapSndExtnGetDuration);

extern Err SndExtnEnableSystemSound(UInt16 refNum,Boolean, SndSysBeepType)
				SonySnd_LIB_TRAP(SonySndTrapSndExtnEnableSystemSound);

extern Err SndExtnPlayPcmResourceAsync(UInt16 refNum, UInt32 resType,
							Int16 resID, SystemPreferencesChoice volumeSelector)
				SonySnd_LIB_TRAP(SonySndTrapSndPlayPcmResourceAsync);


/************************************************************************
 * 		define
 ************************************************************************/
#define NewSndOpen(a) SndExtnOpen((a)) 
#define NewSndClose(a) SndExnClose((a)) 
#define NewSndWake(a) SndExtnWake((a)) 
#define NewSndSleep(a) SndExnSleep((a))

#define SonySndLibGetVersion(a) SndExtnGetAPIVersion((a)) 
#define SndPlayPcm(a, b, c, d, e, f, g, h) SndExtnPlayPcm((a), (b), (c), (d), (e), (f), (g), (h)) 
#define SndPlayPcmResource(a, b, c, d) SndExtnPlayPcmResource((a), (b), (c), (d)) 

#else //CPU_TYPE != CPU_68K
/****************************************************************************
 * 		Standard library open, close, sleep and wake functions
 ***************************************************************************/
extern Err SndExnOpen(void);
extern Err SndExnClose(void);
extern Err SndExtnWake(void);
extern Err SndExnSleep(void);

/************************************************************************
 * 		Custom library API functions
 ************************************************************************/
extern UInt32 SonySndLibGetVersion(void);
extern Err SndExtnPlayPcm(void* chanP, SndPcmCmdEnum cmd, UInt8* pcmP, 
               SndPcmFormatType* formatP, SndPcmOptionsType* selP, 
               SndPcmCallbacksType* callbacksP, Boolean bNoWait );

extern Err SndExtnPlayPcmResource(UInt32 resType, Int16 resID, 
                       SystemPreferencesChoice volumeSelector);

/************************************************************************
 * 		New API
 ************************************************************************/
extern Err SndExtnGetProperty(SndExtnProcEnum sndProp, void *propP);
extern Err SndExtnSetPa1Volume(UInt8*, UInt8*);
extern Err SndExtnGetPa1Volume(UInt8*, UInt8*);
extern Err SndExtnGetDuration(UInt8*, UInt32*);
extern Err SndExtnEnableSystemSound(Boolean, SndSysBeepType);
extern Err SndExtnPlayPcmResourceAsync(UInt32 resType, Int16 resID, 
                       SystemPreferencesChoice volumeSelector);


/************************************************************************
 * 		define
 ************************************************************************/

#endif // CPU_TYPE == CPU_68K



#ifdef __cplusplus 
}
#endif


#endif 	/* _SNDMGRLIB_H_INCLUDED_ */
