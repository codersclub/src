/******************************************************************************
 *                                                                            *
 *            (C) Copyright 2000-2002, Sony Corporation                       *
 *                                                                            *
 *----------------------------------------------------------------------------*
 *                                                                            *
 *    <IDENTIFICATION>                                                        *
 *       file name    : $Workfile: SonyPnP.h $
 *                                                                            *
 *    <PROFILE>                                                               *
 *       Type/DataStructure of PnP (Plug and Play)                            *
 *                                                                            *
 *    <HISTORY>                                                               *
 *       Started on   : 02/03/03                                              *
 *       Last Modified: $Date: 02/06/11 14:54 $
 *                                                                            *
 ******************************************************************************/
/* this file is best viewed by setting TAB-stop as 3 */

#ifndef __SONYPNP_H__
#define __SONYPNP_H__

/******************************************************************************
 *    Includes                                                                *
 ******************************************************************************/
#include <SonyTypes.h>

/******************************************************************************
 *    Constants                                                               *
 ******************************************************************************/
/*** PnP Notification Priority ***/
#define sysNotifyPnpAttachPifPriority					(18)
#define sysNotifyPnpDetachPifPriority					(-18)
#define sysNotifyPnpAttachSpecificDrvPriorityHigh	(-10)
#define sysNotifyPnpAttachSpecificDrvPriorityLow	(-1)
#define sysNotifyPnpAttachNormalDrvPriority			(0)
#define sysNotifyPnpDetachNormalDrvPriority			(0)
#define sysNotifyPnpAttachGeneralDrvPriorityHigh	(1)
#define sysNotifyPnpAttachGeneralDrvPriorityLow		(10)


/******************************************************************************
 *    Type/DataStructure of Notifications                                     *
 ******************************************************************************/
/*** for sysNotifyPnPDeviceAttachedEvent & sysNotifyPnPDeviceDetachedEvent */
	/* (void *)notifyDetailsP is pointer to SysNotifyPnPDeviceType */
/*
typedef struct {
	UInt16 pifClass;
	UInt16 pifId;
	UInt32 infoSize;
	void *infoP;
	UInt32 reserved;
} SysNotifyPnPDeviceType;
*/

/*** pifClass ***/
#define sysPnpPifClassCF		(1)
#define sysPnpPifClassMS		(2)
#define sysPnpPifClassUSB		(3)
#define sysPnpPifClassExtCnt	(4)
	/* alias */
#define pnpPifClassCF			sysPnpPifClassCF
#define pnpPifClassMS			sysPnpPifClassMS
#define pnpPifClassUSB			sysPnpPifClassUSB
#define pnpPifClassExtCnt		sysPnpPifClassExtCnt

/*** pifId ***/
	/* CF: slotRefNum */
	/* MS: slotRefNum */
	/* ExtCnt: unused */

/* infoP points to structures as follows */
	/* CF */
typedef struct {
    UInt16	manfID;
    UInt16	cardID;
} SysPnPDeviceCFManfIDType;

typedef struct {
    UInt8	majorVersion;
    UInt8	minorVersion;
    UInt8	numString;
    UInt8	offset[4];
    Char	string[254];
}SysPnPDeviceCFVers1InfoType;

#define sysPnpCfFuncIdMulti				0x00
#define sysPnpCfFuncIdMemory			0x01
#define sysPnpCfFuncIdSerial			0x02
#define sysPnpCfFuncIdParallel			0x03
#define sysPnpCfFuncIdFixed				0x04
#define sysPnpCfFuncIdVideo				0x05
#define sysPnpCfFuncIdNetwork			0x06
#define sysPnpCfFuncIdAims				0x07
#define sysPnpCfFuncIdScsi				0x08
#define sysPnpCfFuncIdSecurity			0x09
#define sysPnpCfFuncIdInstruments		0x0A
#define sysPnpCfFuncIdSerialIOBus		0x0B
#define sysPnpCfFuncIdVenderSpecific	0xFE
#define sysPnpCfFuncIdDoNotUse			0xFF

#define sysPnpCfSysInitPost	0x01
#define sysPnpCfSysInitRom	0x02

typedef struct {
    UInt8	function;
    UInt8	sysinit;
} SysPnPDeviceCFFuncIDType;

typedef struct {
	SysPnPDeviceCFManfIDType	manfID;
	SysPnPDeviceCFVers1InfoType	ver1Info;
	UInt8						numFunc;
	SysPnPDeviceCFFuncIDType	funcID[8];
}SysPnPDeviceCFInfoType, *SysPnPDeviceCFInfoPtr;
	/* MS */
typedef struct {
	UInt8 typeNum;
	UInt8 categoryNum;
	UInt8 classNum;
}SysPnPDeviceMSFuncType, *SysPnPDeviceMSFuncPtr;

typedef struct {
	Char companyName[33];
	Char productName[33];
	Char versionNum[17];
} SysPnPDeviceMSAttributeInfoType, *SysPnPDeviceMSAttributeInfoPtr;

typedef struct {
	SysPnPDeviceMSAttributeInfoType	attrInfo;
	UInt8							numFunc;
	SysPnPDeviceMSFuncType			funcID[8];
}SysPnPDeviceMSInfoType, *SysPnPDeviceMSInfoPtr;

	/* ExtCnt */
typedef struct {
	 UInt8  venderId;		// What type of event occurred?
	 UInt8  modelId;		// normally creator code of broadcasting app
	 UInt8  rsv1;			// ptr to notification-specific data, if any
	 UInt8  versionNo;	// user specified ptr passed back with notification
	 UInt8  feature;		// true if event is handled yet
	 UInt8  rsv2;
	 UInt8  rsv3;
	 EventType *eventP;
} SysPnPDeviceExtCntInfoType;
typedef SysPnPDeviceExtCntInfoType *SysPnPDeviceExtCntInfoPtr;
typedef SysPnPDeviceExtCntInfoType SonyPnPDeviceExtCntInfoType;
typedef SonyPnPDeviceExtCntInfoType *SonyPnPDeviceExtCntInfoPtr;

/*** handled ***/
	/* CF */
#define sysPnpHandledCFFunc0	(0x01)
#define sysPnpHandledCFFunc1	(0x02)
#define sysPnpHandledCFFunc2	(0x04)
#define sysPnpHandledCFFunc3	(0x08)
#define sysPnpHandledCFFunc4	(0x10)
#define sysPnpHandledCFFunc5	(0x20)
#define sysPnpHandledCFFunc6	(0x40)
#define sysPnpHandledCFFunc7	(0x80)

	/* MS */
#define sysPnpHandledMSFunc0	(0x01)
#define sysPnpHandledMSFunc1	(0x02)
#define sysPnpHandledMSFunc2	(0x04)
#define sysPnpHandledMSFunc3	(0x08)
#define sysPnpHandledMSFunc4	(0x10)
#define sysPnpHandledMSFunc5	(0x20)
#define sysPnpHandledMSFunc6	(0x40)
#define sysPnpHandledMSFunc7	(0x80)

	/* ExtCnt */

#endif	// __SONYPNP_H__

