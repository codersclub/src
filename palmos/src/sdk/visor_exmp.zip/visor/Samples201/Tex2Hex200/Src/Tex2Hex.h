//**************************************************************
//
//  Project:
//	  Handspring Sample PalmOS Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  Tex2Hex.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
// 
//	 This app is derived from the Tex 2 Hex 1.0 sample source written by
//	 Andrew Howlett (howlett@iosphere.net) provided with his ASDK tutorial.
//
// History:
//	  11-Feb-1999  - Created 
//***************************************************************/

#define resFormIDTex2Hex			1000
									
#define resMenuIDTex2Hex			1000

#define resMenuItemConvert			1000
#define resMenuItemAbout			1001
#define resMenuItemCopy				1002
#define resMenuItemPaste			1003

#define resBitmapIDText				1000
#define resBitmapIDHex				1001
									
#define resFieldIDText				1000
#define resFieldIDHex				1001

#define resButtonIDConvert			1002

									
#define resAlertIDAbout				1000
#define resAlertIDErrNullStr		1001	
									
