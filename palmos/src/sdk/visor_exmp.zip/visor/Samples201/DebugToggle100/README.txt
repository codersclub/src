Copyright (c) 2000 Handspring, Inc.
All rights reserved.

Project: DebugToggle
Author:  Frank Voqui
Date:    Apr 5 2001

Description:

 *		Toggle a custom feature using the Feature Manager.  The custom
 *		feature will be read by other applications to conditionally enter
 *		a break point with DbgBreak(). 
 *
 *		Note:  Current UI only toggles bit 0 of the feature and print 
 *		the setting to the Palm-Debugger. To implement multi debug levels,
 *      new modification must be added to control the setting of the 
 *		other bit fields.
 *
 *		Current implementation allows application to act as a quick toggle
 *		button.  Mapped this application to a hard-key or the calculator
 *		(silk-screen) button to use as a quick toggle switch.
