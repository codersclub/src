
/***********************************************************************
 *
 * Copyright (c) 2000 Handspring, Inc.
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     DebugToggle.c
 * AUTHOR:   Frank Voqui: Mar 28 2001
 *
 * DECLARER: DebugToggle
 *
 * DESCRIPTION:
 *
 *		Toggle a custom feature using the Feature Manager.  The custom
 *		feature will be read by other applications to conditionally enter
 *		a break point with DbgBreak(). 
 *
 *		Note:  Current UI only toggles bit 0 of the feature and print 
 *		the setting to the Palm-Debugger. To implement multi debug levels,
 *      new modification must be added to control the setting of the 
 *		other bit fields.
 *
 *		Current implementation allows application to act as a quick toggle
 *		button.  Mapped this application to a hard-key or the calculator
 *		(silk-screen) button to use as a quick toggle switch.
 *
 **********************************************************************/
#include <PalmOS.h>
#include <CoreCompatibility.h>
#include "DebugToggle.h"




/***********************************************************************
 *
 * FUNCTION:    Conditional_DbgBreak
 *
 * DESCRIPTION: Dynamically check the Feature Manager (set by DebugToggle)
 *				to conditionally call DbgBreak();
 *
 * PARAMETERS:  void
 *
 * RETURNED:    void
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
void Conditional_DbgBreak( void )
{
UInt32	  data;

  // Read current feature setting
  if (!FtrGet(DebugToggleCreator, appFtrIDDebugToggle, (DWordPtr)&data))
	{
		if ( data )		// Debug on 
		  {
		  DbgMessage( "Stop in debug mode\n");
		  DbgBreak();
		  }
	}

  return;
}