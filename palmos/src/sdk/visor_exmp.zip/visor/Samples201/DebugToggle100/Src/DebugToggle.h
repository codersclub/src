
/***********************************************************************
 *
 * Copyright (c) 2000 Handspring, Inc.
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     SpringBoardTest.h
 * AUTHOR:   Frank Voqui: Mar 28 2001
 *
 * DECLARER: SpringBoard Test
 *
 * DESCRIPTION:
 *
 *		SpringBoard Test is an application which exercises the read and
 *		write access to a location on the Springboard module.
 *
 **********************************************************************/



/***********************************************************************
 *
 *    Constants
 *
 ***********************************************************************/
#define DebugToggleCreator		'DBGT'
#define	appFtrIDDebugToggle		1


// Set the appropriate debug bit field(s) to toggle.  New UI needs to be 
// added if multiple debugLevel bit fields are used.

#define debugLevel1				0x1	  // bit 0, for say DbgBreak
#define debugLevel2				0x2	  // bit 1, for say DbgMessage
#define debugLevel3				0x4   // bit 2, for custom


/***********************************************************************
 *
 *    APIs
 *
 ***********************************************************************/

void Conditional_DbgBreak( void );
