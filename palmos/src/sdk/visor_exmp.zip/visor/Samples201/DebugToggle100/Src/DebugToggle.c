
/***********************************************************************
 *
 * Copyright (c) 2000 Handspring, Inc.
 * All rights reserved.
 *
 * PROJECT:  Pilot
 * FILE:     DebugToggle.c
 * AUTHOR:   Frank Voqui: Mar 28 2001
 *
 * DECLARER: DebugToggle
 *
 * DESCRIPTION:
 *
 *		Toggle a custom feature using the Feature Manager.  The custom
 *		feature will be read by other applications to conditionally enter
 *		a break point with DbgBreak(). 
 *
 *		Note:  Current UI only toggles bit 0 of the feature and print 
 *		the setting to the Palm-Debugger. To implement multi debug levels,
 *      new modification must be added to control the setting of the 
 *		other bit fields.
 *
 *		Current implementation allows application to act as a quick toggle
 *		button.  Mapped this application to a hard-key or the calculator
 *		(silk-screen) button to use as a quick toggle switch.
 *
 **********************************************************************/
#include <PalmOS.h>
#include <CoreCompatibility.h>
#include "DebugToggle.h"


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - word value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  word value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 
PilotMain( UInt16 cmd, MemPtr cmdPBP, UInt16 launchFlags)
{

	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
		  {
	
		  UInt32	  data;
		  VoidPtr	  ftrMem =0;
		  Char		  text[20];

		  if ( FtrGet(DebugToggleCreator, appFtrIDDebugToggle, (DWordPtr)&data) == ftrErrNoSuchFeature )
			{
			// Feature does not yet exist.  Create it
			FtrPtrNew(DebugToggleCreator, appFtrIDDebugToggle, 4, ftrMem);

			// Set feature initially to 0
			FtrSet(DebugToggleCreator, appFtrIDDebugToggle, 0);
			}

		  // Read current feature setting
		  if (!FtrGet(DebugToggleCreator, appFtrIDDebugToggle, (DWordPtr)&data))
			{
			//StrPrintF(text, "%ld\n", data);
			//DbgMessage(text);

			// Set the appropriate debug bit field(s) to toggle.  New UI needs to be 
			// added if multiple debugLevel bit fields are used.


			// Currently, only bit 0 is toggle.
			data = data ^ debugLevel1;
			//StrPrintF(text, "%ld\n", data);
			//DbgMessage(text);

			
			FtrSet(DebugToggleCreator, appFtrIDDebugToggle, data);

			StrCopy(text, data? "\t Debug is On \n" : "\t Debug is Off \n");
			WinDrawChars( text, StrLen(text), 50, 80 );
			DbgMessage(text);
			SysTaskDelay(100);
			
			}

		  break;
		  }

		default:
		  break;
		}

	
	return 0;

}

