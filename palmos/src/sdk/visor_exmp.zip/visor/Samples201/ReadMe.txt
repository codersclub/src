This file contains generic Palm OS projects that are built using the Handspring
Palm OS GNU Tools. 

*** IMPORTANT ***

The latest sample code for Springboard module development has been to the DiagRefModule download at the following URL:

http://www.handspring.com/developers/sw_dev.jhtml

The Handspring reference design (Diagnostic Module) code sample download contains
examples related to:

- Setup application
- Welcome application
- Serial Library sample
- Hand Terminal application
- Incorporating the CardUpdaterMakerSDK (used to build user friendly flash updaters)
  into a project.

An application note on the Diagnostic Reference module (AN-03) is on the Handspring website.
http://www.handspring.com/developers/tech_notes.jhtml
