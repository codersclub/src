/***************************************************************
 *
 *  Project:
 *	  Handspring Sample PalmOS Application 
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  SimpleIO.c
 * 
 *  Description:
 *	  This is the main source file for the sample application. It
 *	 demonstrate basic IO using text fields.
 *
 * ToDo:
 *
 * History:
 *	  19-Apr-2001  - Created 
 ****************************************************************/

#include <PalmOS.h>
#include <CoreCompatibility.h>
#include "SimpleIO.h"



// -------------------------------------------------------------
// Constants
// -------------------------------------------------------------
#define SimpleIODBCreator    'ezIO'   



// -------------------------------------------------------------
// Prototypes
// -------------------------------------------------------------
static int		StartApplication (void);
static void		EventLoop (void);
static void		StopApplication(void);
static Boolean	SimpleIO (EventPtr event);
static void		Echo (void);


// -------------------------------------------------------------
// Globals
// -------------------------------------------------------------
FieldPtr		FieldTextInP;     
FieldPtr		FieldTextOutP;     


// ==================================================================
// Pilot Main
// =================================================================
DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  int error;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{

	  error = StartApplication();	// Application start code
	  if (error) return error;

	  EventLoop();					// Event loop

	  StopApplication ();			// Application stop code
	}
  return 0;
}



// ==================================================================
// Start Application
// =================================================================
static int 
StartApplication(void)
{

  FrmGotoForm (resFormIDSimpleIO);
  return 0;
}




// ==================================================================
// Event Loop
// =================================================================
static void 
EventLoop(void)
{
  short		err;
  int		formID;
  FormPtr	formP;
  EventType event;

  do
	{

	  EvtGetEvent (&event, sysTicksPerSecond/2);

	  if (SysHandleEvent (&event)) continue;
	  if (MenuHandleEvent ((void *)0, &event, &err)) continue;

	  if (event.eType == frmLoadEvent)
		{
		  formID = event.data.frmLoad.formID;
		  formP = FrmInitForm (formID);
		  FrmSetActiveForm (formP);

		  switch (formID) 
			{
			case resFormIDSimpleIO:
			  FrmSetEventHandler (formP, (FormEventHandlerPtr) SimpleIO);
			  break;
			}
		}

	  FrmDispatchEvent(&event);

	 } while(event.eType != appStopEvent);
}


// ==================================================================
// Stop Application
// =================================================================
static void 
StopApplication (void)
{
  FldSetTextHandle (FieldTextInP, NULL);
}



// ==================================================================
// Form Event Handler
// =================================================================
static Boolean 
SimpleIO (EventPtr event)
{
  FormPtr   formP;
  int       handled = 0;

  switch (event->eType) 
	{
	case frmOpenEvent:
	  formP = FrmGetActiveForm();

	  FieldTextInP = FrmGetObjectPtr (formP, 
		  FrmGetObjectIndex (formP, resFieldIDTextIn));
	  
	  FieldTextOutP = FrmGetObjectPtr (formP, 
		  FrmGetObjectIndex (formP, resFieldIDTextOut));
	  
	  FrmDrawForm(formP);
	  handled = 1;
	  break;
    
	case ctlSelectEvent:  // A control button was pressed and released.
	  if (event->data.ctlEnter.controlID == resButtonIDEcho)
		{
		  Echo();
		  handled = 1;
		}
	  break;

	case menuEvent:
	  switch (event->data.menu.itemID)
		{
		case resMenuItemAbout:
		  FrmAlert(resAlertIDAbout);
		  break;
		case resMenuItemCopy:
		  FldCopy (FieldTextInP);   // user has to select (highllight) the text to copy
		  break;
		case resMenuItemPaste:
		  FldPaste (FieldTextInP);
		  break;
		case resMenuItemEcho:
		  Echo();
		  break;
		}
	  handled = 1;
	  break;

	default:
	  break;
	}
  return handled;
}



// ==================================================================
// Echo
// =================================================================
static void 
Echo(void)
{
  int		textLength;
  CharPtr	textP;

  textP = FldGetTextPtr (FieldTextInP);
  textLength = FldGetTextLength (FieldTextInP);
  if (textLength)
	{
	  FldSetTextPtr (FieldTextOutP, textP);
	  FldRecalculateField (FieldTextOutP, true);

	  FrmDrawForm (FrmGetActiveForm());
	  //DbgMessage(textP);
	}
}


