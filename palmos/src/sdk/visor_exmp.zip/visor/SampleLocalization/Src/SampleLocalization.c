/***************************************************************
 *
 *  Project:
 *	  Handspring Sample PalmOS Application 
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  SampleLocalization.c
 * 
 *  Description:
 *	  This is the main source file for the sample application. It is
 *	 derived from the "Tex 2 Hex" 1.0 sample source written by
 *	 Andrew Howlett (howlett@iosphere.net) provided with his
 *	 ASDK tutorial.
 *
 * ToDo:
 *
 * History:
 *	  10-Feb-1999  - Created 
 ****************************************************************/

#include <PalmOS.h>
#include <CoreCompatibility.h>
#include "SampleLocalization.h"

#include <OverlayUtils.h>



// Allow VC++ to compile...
#if defined(_MSC_VER)
  #define OVERLAY_BASENAME ""
#endif


// -------------------------------------------------------------
// Prototypes
// -------------------------------------------------------------
static int		StartApplication (void);
static void		EventLoop (void);
static void		StopApplication(void);
static Boolean	SampleLocalization (EventPtr event);
static void		DisplayBitmap (void);


// -------------------------------------------------------------
// Globals
// -------------------------------------------------------------
FieldPtr		FieldTextP;     


// ==================================================================
// Pilot Main
// =================================================================
DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  int error;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{
	  DmOpenRef overlayDb = NULL;

	  // Open overlay...
	  overlayDb = HsUtilOverlayInitialize (OVERLAY_BASENAME);

	  error = StartApplication();	// Application start code
	  if (error) return error;

	  EventLoop();					// Event loop

	  StopApplication ();			// Application stop code

      if (overlayDb != NULL)
        {
          HsUtilOverlayCleanup (overlayDb);
        }

	}

  return 0;
}



// ==================================================================
// Start Application
// =================================================================
static int 
StartApplication(void)
{
  
  FrmGotoForm (resFormIDSampleLocalization);
  return 0;
}


// ==================================================================
// Event Loop
// =================================================================
static void 
EventLoop(void)
{
  short		err;
  int		formID;
  FormPtr	formP;
  EventType event;

  do
	{

	  EvtGetEvent (&event, sysTicksPerSecond/2);

	  if (SysHandleEvent (&event)) continue;
	  if (MenuHandleEvent ((void *)0, &event, &err)) continue;

	  if (event.eType == frmLoadEvent)
		{
		  formID = event.data.frmLoad.formID;
		  formP = FrmInitForm (formID);
		  FrmSetActiveForm (formP);

		  switch (formID) 
			{
			case resFormIDSampleLocalization:
			  FrmSetEventHandler (formP, (FormEventHandlerPtr) SampleLocalization);
			  break;
			}
		}

	  FrmDispatchEvent(&event);

	 } while(event.eType != appStopEvent);
}


// ==================================================================
// Stop Application
// =================================================================
static void 
StopApplication (void)
{
  FldSetTextHandle (FieldTextP, NULL);
}



// ==================================================================
// Form Event Handler
// =================================================================
static Boolean 
SampleLocalization (EventPtr event)
{
  FormPtr   formP;
  VoidHand	strH;
  int       handled = 0;

  switch (event->eType) 
	{
	case frmOpenEvent:
	  formP = FrmGetActiveForm();

	  strH = DmGetResource (strRsc, resTextIDCommon);
	  FieldTextP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, resFieldIDCommon));
	  FldSetTextHandle (FieldTextP, strH );
	  DmReleaseResource (strH);

	  strH = DmGetResource (strRsc, resTextIDLocalized);
	  FieldTextP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, resFieldIDLocalized));
	  FldSetTextHandle (FieldTextP, strH );
	  DmReleaseResource (strH);

	  
	  DisplayBitmap();

	  FrmDrawForm(formP);
	  handled = 1;
	  break;
    

	default:
	  break;
	}
  return handled;
}





// ==================================================================
// ChangeBitmap
// =================================================================
static void 
DisplayBitmap(void)
{
  VoidHand	  bitmapH;
  BitmapPtr	  bitmapP;
  

  bitmapH = DmGet1Resource('Tbmp', resBitmapIDLocalized);

  if (!bitmapH) return;

  bitmapP = MemHandleLock (bitmapH);
  WinDrawBitmap (bitmapP, 20, 80);
  MemHandleUnlock (bitmapH);
}





