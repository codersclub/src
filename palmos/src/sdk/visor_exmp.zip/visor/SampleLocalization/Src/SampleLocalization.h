//**************************************************************
//
//  Project:
//	  Handspring Sample PalmOS Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  SampleLocalization.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
// 
//	 This app is derived from the Tex 2 Hex 1.0 sample source written by
//	 Andrew Howlett (howlett@iosphere.net) provided with his ASDK tutorial.
//
// History:
//	  11-Feb-1999  - Created 
//***************************************************************/

#define resFormIDSampleLocalization			1000
									
#define resMenuIDSampleLocalization			1000

#define resBitmapIDLocalized				1000
									
#define resFieldIDLocalized				1000
#define resFieldIDCommon				1001

#define resTextIDLocalized				1000
#define resTextIDCommon					1001

									
