/***********************************************************************
 *
 * Copyright (c) 1999-2001, TRG, All Rights Reserved
 *
 * PROJECT:         StarKist
 *
 * FILE:            StarKist.r
 *
 * DESCRIPTION:     
 *
 * AUTHOR:          John Ehm
 *
 * DATE:            01/17/01
 *
 **********************************************************************/


type 'sKst' {
    //Currently no data is stored in resource, need dummy otherwise 
    //resource is not linked in
    unsigned longint;   
};


resource 'sKst' (1000, "StarKist Aware")
{
    0x00000000;

};
