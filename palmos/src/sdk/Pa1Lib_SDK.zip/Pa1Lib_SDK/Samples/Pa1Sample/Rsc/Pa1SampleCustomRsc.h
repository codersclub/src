#ifndef SND_SAMPLE_CUSTOM_RSC_H
#define SND_SAMPLE_CUSTOM_RSC_H

#define SonyPCMRsc  'pcmR'

#define HelloPCM    1000
#define OpeningPCM  1100

#endif // SND_SAMPLE_CUSTOM_RSC_H
