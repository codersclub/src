#include "Pa1SampleCustomRsc.h"

// store raw Yamaha ADPCM data as a resource
//
// see the readme.txt file for more information about creating this
// resource
//
// (the size of the ADPCM data must be within the standard Palm OS resource
// limits; i.e., the ADPCM file size must be less than 64K.)
read SonyPCMRsc (HelloPCM) "hello.pcmR.bin";

read SonyPCMRsc (OpeningPCM) "opening.pcmR.bin";
