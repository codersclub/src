/******************************************************************************
 * This program is subject to copyright protection in accordance with the
 * applicable law and is also subject to the Developer Download Software
 * License Agreement, ("License Agreement") agreed to by the licensee prior to
 * download and receipt of this program.  It must only be used for the purpose
 * of developing software that is compatible with the CLI� handheld computer.
 * It must not, except as permitted in the License Agreement, by any means or
 * in any form be reproduced, distributed or lent.  Moreover, no part of the
 * program may be used, viewed, printed, disassembled or otherwise interfered
 * with in any form, except where allowed by the License Agreement, without the
 * express written consent of the copyright holder.
 *
 * THIS PROGRAM IS FURTHER PROVIDED "AS IS" WITH NO WARRANTY OF ANY KIND AND
 * THE COPYRIGHT HOLDER HEREBY DISCLAIMS ALL WARRANTIES, EXPRESS AND IMPLIED AS
 * TO THE PROGRAM.
 *
 * Copyright (c) 2003 Sony Electronics Inc.
 * Some portions copyright (c) 1999 Palm Computing, Inc. or its subsidiaries.
 * All Rights Reserved.
 *
 * File: Pa1Sample.cpp
 *
 *****************************************************************************/


/** Pa1Sample
  */

#include <PalmOS.h>
#include <SonyCLIE.h>

#include "Pa1Lib.h"

#include "Pa1SampleRsc.h"
#include "Pa1SampleCustomRsc.h" // custom resources created outside of Constructor



/* CONSTANTS ----------------------------------------------------------- */

#define appFileCreator 'STRT'
#define appVersionNum 0x01
#define appPrefID 0x00
#define appPrefVersionNum 0x01

// minimum OS version supported
// NOTE: OS 4.0 devices incorrectly report the stage number as
// sysROMStageDevelopment (0) instead of sysROMStageRelease (3)
#define MIN_OS_VERSION sysMakeROMVersion(4, 0, 0, 0, 0)

#define sonySysFtrNumSystemBase 10000
#define sonySysFtrNumSystemAOutSndStateOnHandlerP (sonySysFtrNumSystemBase + 4)
#define sonySysFtrNumSystemAOutSndStateOffHandlerP (sonySysFtrNumSystemBase + 5)

#define aOutSndKindSp (0) /* speaker */
#define aOutSndKindHp (2) /* headphone */

#define ADPCM_MODE_NONCONTINUOUS_PB 0x01
#define ADPCM_MODE_INTERRUPT_MODE 0x02

#define ADPCM_4_KHZ 0
#define ADPCM_8_KHZ 1

#define appStopSoundEvent firstUserEvent



/* TYPEDEFS ------------------------------------------------------------ */

typedef void (*sndStateOnType)(UInt8 /* kind */,
                               UInt8 /* left volume 0-31 */,
                               UInt8 /* right volume 0-31 */);
typedef void (*sndStateOffType)(UInt8 /* kind */);



/* GLOBALS ------------------------------------------------------------- */

typedef struct
{
    UInt16 refNum;
    struct
    {
        UInt8 hd;
        MemHandle resH;
    } curADPCM;
} Pa1StateType;

static Pa1StateType gPa1State = { sysInvalidRefNum, { 0, NULL } };



/* FUNCTION PROTOTYPES ------------------------------------------------- */

static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags);
static void* GetObjectPtr(const FormType* frmP, UInt16 objectID);

static Err OpenPa1Lib(UInt16* pa1LibRefNumP);
static Err ClosePa1Lib(UInt16 pa1LibRefNum);
static void SetVolume(UInt16 pa1LibRefNum, UInt8 volume);
static void Pa1Callback(UInt32 /* dwUserData */);
static Err PlayADPCMResource(UInt16 pa1LibRefNum, DmResID id);
static Err StopADPCMResource(Pa1StateType* pa1StateP);



/* FUNCTION DEFINITIONS ------------------------------------------------ */

#pragma mark -
/***********************************************************************
 * FUNCTION:    RomVersionCompatible
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h
 *                                for format)
 *              launchFlags     - flags that indicate if the application
 *                                  UI is initialized
 * RETURNS:     Err value; errNone if ROM is compatible
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
    UInt32 romVersion;

    // ensure that the device is using the required version of the ROM or later
    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion < requiredVersion)
    {
        if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
            == (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
        {
            FrmAlert(RomIncompatibleAlert);

            // Palm OS 1.0 will continuously relaunch this app unless we switch to
            // a safe one.
            if (romVersion < sysMakeROMVersion(2, 0, 0, sysROMStageRelease, 0))
            {
                AppLaunchWithCommand(sysFileCDefaultApp,
                                     sysAppLaunchCmdNormalLaunch, NULL);
            }
        }

       return sysErrRomIncompatible;
    }

    return errNone;
}


/***********************************************************************
 * FUNCTION:    GetObjectPtr
 * DESCRIPTION: returns a pointer to an object in the given Form
 * PARAMETERS:  IN frmP  - pointer to the Form;
 *                         pass NULL to use the currently active Form
 *              objectID - ID number of the object in the Form
 * RETURNS:     void*
 ***********************************************************************/
static void* GetObjectPtr(const FormType* frmP, UInt16 objectID)
{
    if (frmP == NULL) { frmP = FrmGetActiveForm(); }
    return FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID));
}


#pragma mark -
/***********************************************************************
 * FUNCTION:    OpenPa1Lib
 * DESCRIPTION: opens the Pa1Lib library and retrives its reference number
 * PARAMETERS:  OUT pa1LibRefNumP - the reference number to the Pa1Lib
 *                                    library;
 *                                  set to sysInvalidRefNum if there is an
 *                                   error opening the library
 * RETURNS:     Err value
 ***********************************************************************/
static Err OpenPa1Lib(UInt16* pa1LibRefNumP)
{
    Err error;
    UInt16 pa1LibRefNum;

    *pa1LibRefNumP = sysInvalidRefNum;

    error = SysLibFind(PA1Lib_NAME, &pa1LibRefNum);
    if (error != errNone) { error = SysLibLoad(sysFileTLibrary, PA1Lib_ID, &pa1LibRefNum); }

    if (error == errNone)
    {
        error = PA1LibOpen(pa1LibRefNum);
        if (error == errNone)
        {
            SetVolume(pa1LibRefNum, sndMaxAmp);
            *pa1LibRefNumP = pa1LibRefNum;
        }
    }

    if (error != errNone) { *pa1LibRefNumP = sysInvalidRefNum; }

    return error;
}


/***********************************************************************
 * FUNCTION:    ClosePa1Lib
 * DESCRIPTION: closes the Pa1Lib library
 * PARAMETERS:  pa1LibRefNum - reference number to the Pa1Lib library
 * RETURNS:     errNone
 ***********************************************************************/
static Err ClosePa1Lib(UInt16 pa1LibRefNum)
{
    Err error = errNone;

    if (pa1LibRefNum == sysInvalidRefNum)
    {
        error = sysErrLibNotFound;
    }
    else
    {
        sndStateOffType sndStateOffFuncP;
        if (FtrGet(sonySysFileCSystem,
                   sonySysFtrNumSystemAOutSndStateOffHandlerP,
                   (UInt32*) &sndStateOffFuncP)
            == errNone)
        {
            sndStateOffFuncP(aOutSndKindSp);
            sndStateOffFuncP(aOutSndKindHp);
        }

        UInt16 usecount;
        PA1LibClose(pa1LibRefNum, &usecount);

        if (usecount == 0) { SysLibRemove(pa1LibRefNum); }
    }
    return error;
}


/***********************************************************************
 * FUNCTION:    SetVolume
 * DESCRIPTION: sets the speaker and headphone volume
 *              (does not affect system sounds)
 * PARAMETERS:  pa1LibRefNum - reference number to the Pa1Lib library
 *              volume       - the desired volume;
 *                             value must be in the range [0, 31]
 * RETURNS:
 ***********************************************************************/
static void SetVolume(UInt16 pa1LibRefNum, UInt8 volume)
{
    // the sndState function pointers must be called to initialize
    // sound playback properly
    sndStateOnType sndStateOnFuncP;
    if (FtrGet(sonySysFileCSystem,
               sonySysFtrNumSystemAOutSndStateOnHandlerP,
               (UInt32*) &sndStateOnFuncP)
        == errNone)
    {
        sndStateOnFuncP(aOutSndKindSp, volume, volume);
        sndStateOnFuncP(aOutSndKindHp, volume, volume);
    }

    Boolean successful;
    (void) PA1L_devSpVolume(pa1LibRefNum, volume, &successful);
    (void) PA1L_devHpVolume(pa1LibRefNum, volume, volume, &successful);
}


/***********************************************************************
 * FUNCTION:    Pa1Callback
 * DESCRIPTION: completion callback for playing ADPCM data
 * PARAMETERS:  dwUserData - pointer to the Pa1StateType globals
 * RETURNS:
 ***********************************************************************/
static void Pa1Callback(UInt32 /* dwUserData */)
{
    // Using interrupt mode, bad things may happen on some devices if we
    // try to stop playback directly in the callback.  Instead, enqueue
    // an event do it.
    EventType e;
    MemSet(&e, sizeof e, 0);
    e.eType = appStopSoundEvent;
    EvtAddEventToQueue(&e);
}


/***********************************************************************
 * FUNCTION:    PlayADPCMResource
 * DESCRIPTION: plays the specified ADPCM resource
 * PARAMETERS:  pa1LibRefNum - reference number to the Pa1Lib library
 *              id           - the resource ID of the ADPCM resource to
 *                               play
 * RETURNS:     Err value
 ***********************************************************************/
static Err PlayADPCMResource(UInt16 pa1LibRefNum, DmResID id)
{
    Err error = errNone;
    if (pa1LibRefNum == sysInvalidRefNum)
    {
        error = sysErrLibNotFound;
    }
    else
    {
        MemHandle pcmH = DmGetResource(SonyPCMRsc, id);

        // if something's already playing, stop it first
        if (gPa1State.curADPCM.resH != NULL) { StopADPCMResource(&gPa1State); }

        if (pcmH == NULL)
        {
            // PCM resource not found
            error = sndErrBadParam;
        }
        else
        {
            Boolean successful;
            UInt8 adpcmHd;

            CallbackInfoType callbackInfo = { Pa1Callback, NULL };

            // pointer to PCM data stream
            UInt8* pcmP = (UInt8*) MemHandleLock(pcmH);

            error = PA1L_adpcmOpen(pa1LibRefNum, ADPCM_8_KHZ, pcmP, MemPtrSize(pcmP), &callbackInfo,
                                   &adpcmHd, &successful);
            if (error == errNone && successful)
            {
                // if using the event mode, call PA1L_sndEventProc regularly to
                // play the sound
                error = PA1L_adpcmStart(pa1LibRefNum, adpcmHd,
                                        ADPCM_MODE_NONCONTINUOUS_PB | ADPCM_MODE_INTERRUPT_MODE,
                                        &successful);

                if (error != errNone || !successful)
                {
                    (void) PA1L_adpcmClose(pa1LibRefNum, adpcmHd, &successful);
                }
            }

            if (error == errNone && successful)
            {
                gPa1State.curADPCM.hd = adpcmHd;
                gPa1State.curADPCM.resH = pcmH;
            }
            else
            {
                MemHandleUnlock(pcmH);
                DmReleaseResource(pcmH);
                error = sndErrBadParam;
            }
        }
    }
    return error;
}


/***********************************************************************
 * FUNCTION:    StopADPCMResource
 * DESCRIPTION: stops playing and frees the current ADPCM resource
 * PARAMETERS:  IN/OUT pa1StateP - pointer to the Pa1StateType globals
 * RETURNS:
 ***********************************************************************/
static Err StopADPCMResource(Pa1StateType* pa1StateP)
{
    Err error = errNone;

    if (pa1StateP->refNum == sysInvalidRefNum)
    {
        error = sysErrLibNotFound;
    }
    else if (pa1StateP->curADPCM.resH != NULL)
    {
        Boolean successful;
        (void) PA1L_adpcmClose(pa1StateP->refNum, pa1StateP->curADPCM.hd, &successful);
        MemHandleUnlock(pa1StateP->curADPCM.resH);
        DmReleaseResource(pa1StateP->curADPCM.resH);

        pa1StateP->curADPCM.resH = NULL;
    }
    return error;
}


#pragma mark -
/***********************************************************************
 * FUNCTION:    MainUpdateVolumeField
 * DESCRIPTION: updates the Volume field on the Main form
 * PARAMETERS:  IN/OUT frmP - pointer to the Main form
 *              volume      - the new volume value
 *              draw        - whether or not to visually update the Field
 * RETURNS:
 ***********************************************************************/
static void MainUpdateVolumeField(FormType* frmP, UInt16 volume, Boolean draw)
{
    MemHandle h = MemHandleNew(maxStrIToALen);
    if (h != NULL)
    {
        UInt16 len;
        Char* s = (Char*) MemHandleLock(h);
        StrIToA(s, volume);
        len = StrLen(s);
        MemHandleUnlock(h);
        MemHandleResize(h, len + 1);

        FieldType* fieldP = (FieldType*) GetObjectPtr(frmP, MainVolumeField);
        MemHandle oldTextH = FldGetTextHandle(fieldP);
        FldSetTextHandle(fieldP, h);
        if (draw) { FldDrawField(fieldP); }
        if (oldTextH != NULL) { MemHandleFree(oldTextH); }
    }
}


/***********************************************************************
 * FUNCTION:    MainFormInit
 * DESCRIPTION: This routine initializes the MainForm form.
 * PARAMETERS:  IN/OUT frmP - pointer to the MainForm form.
 * RETURNS:
 ***********************************************************************/
static void MainFormInit(FormType* frmP)
{
    ControlType* sliderP = (ControlType*) GetObjectPtr(frmP, MainVolumeFeedbackSliderControl);
    UInt16 volume = CtlGetValue(sliderP);

    MainUpdateVolumeField(frmP, volume, false);
}


/***********************************************************************
 * FUNCTION:    MainFormDoCommand
 * DESCRIPTION: This routine performs the menu command specified.
 * PARAMETERS:  command - menu item ID
 * RETURNS:     true if the menu command has been handled
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
    Boolean handled = false;

    FormType* frmP;

    switch (command)
    {
        case MainOptionsAbout:
            // display the About dialog
            MenuEraseStatus(NULL);
            frmP = FrmInitForm(AboutForm);
            FrmDoDialog(frmP);
            FrmDeleteForm(frmP);
            handled = true;
            break;
    }

    return handled;
}


/***********************************************************************
 * FUNCTION:    MainFormHandleEvent
 * DESCRIPTION: This routine is the event handler for MainForm
 * PARAMETERS:  IN eventP - a pointer to an EventType structure
 * RETURNS:     true if the event has been handled and should not be passed
 *              to a higher level handler.
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventType* eventP)
{
    Err error;
    Boolean handled = false;

    FormType* frmP;

    switch (eventP->eType)
    {
        case menuEvent:
            handled = MainFormDoCommand(eventP->data.menu.itemID);
            break;

        case frmOpenEvent:
            frmP = FrmGetActiveForm();
            MainFormInit(frmP);
            FrmDrawForm(frmP);
            handled = true;
            break;

        case ctlSelectEvent:
            frmP = FrmGetActiveForm();
            switch (eventP->data.ctlSelect.controlID)
            {
                case MainPlayADPCM1Button:
                    if ((error = PlayADPCMResource(gPa1State.refNum, HelloPCM)) != errNone)
                    {
                        ErrAlert(error);
                    }
                    handled = true;
                    break;

                case MainPlayADPCM2Button:
                    if ((error = PlayADPCMResource(gPa1State.refNum, OpeningPCM)) != errNone)
                    {
                        ErrAlert(error);
                    }
                    handled = true;
                    break;

                case MainStopButton:
                    StopADPCMResource(&gPa1State);
                    handled = true;
                    break;
            }
            break;

        case ctlRepeatEvent:
            if (eventP->data.ctlSelect.controlID == MainVolumeFeedbackSliderControl)
            {
                UInt8 volume = (UInt8) eventP->data.ctlRepeat.value;
                if (gPa1State.refNum != sysInvalidRefNum)
                {
                    SetVolume(gPa1State.refNum, volume);
                }
                MainUpdateVolumeField(FrmGetActiveForm(), volume, true);

                // leave unhandled so that the system continues to generate ctlRepeat events
            }
            break;

        default:
            break;
    }

    return handled;
}


#pragma mark -
/***********************************************************************
 * FUNCTION:    AppHandleEvent
 * DESCRIPTION: This routine loads form resources and sets the form event
 *              handlers.
 * PARAMETERS:  IN eventP - a pointer to the event to handle
 * RETURNS:     true if the event has been handled and should not be passed
 *              to a higher level handler.
 ***********************************************************************/
static Boolean AppHandleEvent(EventType* eventP)
{
    Boolean handled = false;

    UInt16 formID;
    FormType* frmP;

    switch (eventP->eType)
    {
        case frmLoadEvent:
            // load the form resource
            formID = eventP->data.frmLoad.formID;
            frmP = FrmInitForm(formID);
            FrmSetActiveForm(frmP);

            // Set the event handler for the form.  The handler of the currently
            // active form is called by FrmHandleEvent each time it receives an
            // event.
            switch (formID)
            {
                case MainForm:
                    FrmSetEventHandler(frmP, MainFormHandleEvent);
                    handled = true;
                    break;

                default:
                    // ErrFatalDisplay("Invalid Form Load Event");
                    break;
            }
            break;

        case appStopSoundEvent:
            StopADPCMResource(&gPa1State);
            handled = true;
            break;
    }

    return handled;
}


/***********************************************************************
 * FUNCTION:    AppEventLoop
 * DESCRIPTION: This routine is the main event loop for the application.
 * PARAMETERS:
 * RETURNS:
 ***********************************************************************/
static void AppEventLoop(void)
{
    // Boolean successful;
    Err error;
    EventType event;

    do
    {
        EvtGetEvent(&event, 100);
        if (!SysHandleEvent(&event))
        {
            if (!MenuHandleEvent(0, &event, &error))
            {
                if (!AppHandleEvent(&event))
                {
                    FrmDispatchEvent(&event);
                }
            }
        }
    } while (event.eType != appStopEvent);
}


/***********************************************************************
 * FUNCTION:     AppStart
 * DESCRIPTION:  Gets the application's preferences and initializes
 *               necessary data structures.
 * PARAMETERS:
 * RETURNS:      Err value
 ***********************************************************************/
static Err AppStart(void)
{
    if (OpenPa1Lib(&gPa1State.refNum) != errNone)
    {
        FrmAlert(Pa1LibNotFoundAlert);
    }

    return errNone;
}


/***********************************************************************
 * FUNCTION:    AppStop
 * DESCRIPTION: Saves the current state of the application and frees used
 *              system resources.
 * PARAMETERS:
 * RETURNS:
 ***********************************************************************/
static void AppStop(void)
{   // close all open forms
    FrmCloseAllForms();

    // free resources
    if (gPa1State.refNum != sysInvalidRefNum)
    {
        if (gPa1State.curADPCM.resH != NULL) { StopADPCMResource(&gPa1State); }
        (void) ClosePa1Lib(gPa1State.refNum);
    }
}


/***********************************************************************
 * FUNCTION:    PilotMain
 * DESCRIPTION: This is the main entry point for the application.
 * PARAMETERS:  cmd         - value specifying the launch code
 *              IN cmdPBP   - pointer to a structure specific to the launch code
 *              launchFlags - extra information about the launch
 * RETURNS:     Result of launch
 ***********************************************************************/
UInt32 PilotMain(UInt16 cmd, void* /* cmdPBP */, UInt16 launchFlags)
{
    Err error = RomVersionCompatible(MIN_OS_VERSION, launchFlags);
    if (error != errNone) { return error; }

    switch (cmd)
    {
        case sysAppLaunchCmdNormalLaunch:
            error = AppStart();
            if (error == errNone)
            {
                FrmGotoForm(MainForm);
                AppEventLoop();
            }
            AppStop();
            break;

        default:
            break;
    }

    return error;
}
