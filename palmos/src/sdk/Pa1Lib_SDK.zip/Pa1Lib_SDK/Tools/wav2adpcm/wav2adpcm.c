/*
   aica adpcm <-> wave converter;

   (c) 2002 BERO <bero@geocities.co.jp>
   under GPL or notify me

   aica adpcm seems same as YMZ280B adpcm
   adpcm->pcm algorithm can found MAME/src/sound/ymz280b.c by Aaron Giles

   this code is for little endian machine

   -------------------------------------------------------------------------

   Modified by Daniel Morais ( daniel@morais.com ) on 09/09/2002 :
   - better precision when encoding ( removed rounding errors )
   - 4 bit nibbles are swapped as it seem it is the format used
   - can now be used on big and little endian computers

   The goal is to be able to use the generated data on Sony Clie devices
   which use Yamaha ADPCM algorithm.

   All the changes can be unset by just commenting some defines ( SWAP_NIBBLE and MORE_PRECISE )
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*  To swap data on big-endian computer */

#define SwapW(x)     ((unsigned short)(((x>>8)&0xff)|(x<<8)))
#define SwapL(x)     ((unsigned long)((SwapW(x))<<16)|(SwapW(x>>16)&0xffff))

/* Set this define to allow more precise computations while still using ints ( remove rounding errors ) */

#define MORE_PRECISE

/* Set this define to swap the 4 bit nibbles, as it seem to be the format used on the audio chip in Clie devices */

#define SWAP_NIBBLES

/* big / little endian "detection" */

#ifndef LITTLE_ENDIAN
#define  LITTLE_ENDIAN  1234  /* LSB first: i386, vax */
#endif

#ifndef BIG_ENDIAN
#define  BIG_ENDIAN  4321  /* MSB first: 68000, ibm, net, ppc */
#endif

/* Set little endian mode by default */
#ifndef BYTE_ORDER
/* #define   BYTE_ORDER  BIG_ENDIAN */
#define  BYTE_ORDER  LITTLE_ENDIAN
#endif

struct wavhdr_t {
      char hdr1[4];
      long totalsize;

      char hdr2[8];
      long hdrsize;
      short format;
      short channels;
      long freq;
      long byte_per_sec;
      short blocksize;
      short bits;

      char hdr3[4];
      long datasize;
};

static int diff_lookup[16] = {
   1,3,5,7,9,11,13,15,
   -1,-3,-5,-7,-9,-11,-13,-15,
};

static int index_scale[16] = {

   0x0e6, 0x0e6, 0x0e6, 0x0e6, 0x133, 0x199, 0x200, 0x266,
   0x0e6, 0x0e6, 0x0e6, 0x0e6, 0x133, 0x199, 0x200, 0x266 /* same value for speedup */
};

static int limit(int val,int min,int max)
{
   if (val<min) return min;
   else if (val>max) return max;
   else return val;
}

void pcm2adpcm(unsigned char *dst,const short *src,size_t length)
{
   int signal,step;
   signal = 0;
   step = 0x7F;

   length/=4;
   do {
      int data,val,diff;

      /* hign nibble */

#ifdef MORE_PRECISE

      diff = *src++ - signal;

      if ( diff < 0 )
      {
         val = ( (diff * 8) - step ) / ( 2 * step );
         val = -val;
         if ( val > 7 ) val = 7;
         val += 8;

         signal += ( (step * diff_lookup[val]) - 4 ) / 8;
      }
      else
      {
         val = ( ( diff * 8 ) + step ) / ( 2 * step );
         if ( val > 7 ) val = 7;

         signal += ( (step*diff_lookup[val]) + 4 ) / 8;
      }

      signal = limit( signal, -32768, 32767 );

      /* It seems the quality is lower on Clie devices audio chip when correctly rounding step ! */
      /* step = ( ( (step * index_scale[val]) ) + 128 ) >> 8; */
      step = (step * index_scale[val]) >> 8;

      step = limit(step,0x7F,0x6000);

#else /* MORE_PRECISE */

      diff = *src++ - signal;
      diff = (diff*8)/step;

      val = (abs(diff))/2;
      if (val>7) val = 7;
      if (diff<0) val+=8;

      signal += (step*diff_lookup[val])/8;
      signal = limit(signal,-32768,32767);

      step = (step * index_scale[val]) >> 8;
      step = limit(step,0x7F,0x6000);

#endif /* MORE_PRECISE */

#ifdef SWAP_NIBBLES

      data = val;

#else /* SWAP_NIBBLES */

      data = val<<4;

#endif /* SWAP_NIBBLES */

      /* low nibble */

#ifdef MORE_PRECISE

      diff = *src++ - signal;

      if ( diff < 0 )
      {
         val = ( (diff * 8) - step ) / ( 2 * step );
         val = -val;
         if ( val > 7 ) val = 7;
         val += 8;

         signal += ( (step * diff_lookup[val]) - 4 ) / 8;
      }
      else
      {
         val = ( ( diff * 8 ) + step ) / ( 2 * step );
         if ( val > 7 ) val = 7;

         signal += ( (step*diff_lookup[val]) + 4 ) / 8;
      }

      signal = limit( signal, -32768, 32767 );

      /* It seems the quality is lower on Clie devices audio chip when correctly rounding step ! */
      /* step = ( ( (step * index_scale[val]) ) + 128 ) >> 8; */
      step = (step * index_scale[val]) >> 8;

      step = limit(step,0x7F,0x6000);

#else /* MORE_PRECISE */

      diff = *src++ - signal;
      diff = (diff*8)/step;

      val = (abs(diff))/2;
      if (val>7) val = 7;
      if (diff<0) val+=8;

      signal += (step*diff_lookup[val])/8;
      signal = limit(signal,-32768,32767);

      step = (step * index_scale[val]) >> 8;
      step = limit(step,0x7F,0x6000);

#endif /* MORE_PRECISE */

#ifdef SWAP_NIBBLES

      data |= val<<4;

#else /* SWAP_NIBBLES */

      data |= val;

#endif /* SWAP_NIBBLES */

      *dst++ = (unsigned char) data;

   } while(--length);
}

void adpcm2pcm(short *dst,const unsigned char *src,size_t length)
{
   int signal,step;
   signal = 0;
   step = 0x7f;

   do {
      int data,val;

      data = *src++;

      /* high nibble */

#ifdef SWAP_NIBBLES

      val = data & 15;

#else /* SWAP_NIBBLES */

      val = data >> 4;

#endif /* SWAP_NIBBLES */

#ifdef MORE_PRECISE

      if ( val & 8 ) signal += ( (step * diff_lookup[val]) - 4 ) / 8; /* diff_lookup is negative */
      else           signal += ( (step * diff_lookup[val]) + 4 ) / 8;

#else /* MORE_PRECISE */

      signal += (step*diff_lookup[val])/8;

#endif /* MORE_PRECISE */

      signal = limit(signal,-32768,32767);

#ifdef MORE_PRECISE

      /* It seems the quality is lower on Clie devices audio chip when correctly rounding step ! */

      /* step = ( ( (step * index_scale[val]) ) + 128 ) >> 8; */
      step = (step * index_scale[val]) >> 8;

#else /* MORE_PRECISE */

      step = (step * index_scale[val]) >> 8;

#endif /* MORE_PRECISE */

      step = limit(step,0x7f,0x6000);

      *dst++= (unsigned char) signal;

      /* low nibble */

#ifdef SWAP_NIBBLES

      val = data >> 4;

#else /* SWAP_NIBBLES */

      val = data & 15;

#endif /* SWAP_NIBBLES */

#ifdef MORE_PRECISE

      if ( val & 8 ) signal += ( (step * diff_lookup[val]) - 4 ) / 8; /* diff_lookup is negative */
      else           signal += ( (step * diff_lookup[val]) + 4 ) / 8;

#else /* MORE_PRECISE */

      signal += (step*diff_lookup[val])/8;

#endif /* MORE_PRECISE */

      signal = limit(signal,-32768,32767);

#ifdef MORE_PRECISE

      /* It seems the quality is lower on Clie devices audio chip when correctly rounding step ! */

      /* step = ( ( (step * index_scale[val]) ) + 128 ) >> 8; */
      step = (step * index_scale[val]) >> 8;

#else /* MORE_PRECISE */

      step = (step * index_scale[val]) >> 8;

#endif /* MORE_PRECISE */

      step = limit(step,0x7f,0x6000);

      *dst++ = (unsigned char) signal;

   } while(--length);
}

#if BYTE_ORDER == BIG_ENDIAN

void SwapHdr( struct wavhdr_t *wavhdr )
{
   wavhdr->totalsize    = SwapL( wavhdr->totalsize );
   wavhdr->hdrsize      = SwapL( wavhdr->hdrsize );
   wavhdr->format       = SwapW( wavhdr->format );
   wavhdr->channels     = SwapW( wavhdr->channels );
   wavhdr->freq         = SwapL( wavhdr->freq );
   wavhdr->byte_per_sec = SwapL( wavhdr->byte_per_sec );
   wavhdr->blocksize    = SwapW( wavhdr->blocksize );
   wavhdr->bits         = SwapW( wavhdr->bits );
   wavhdr->datasize     = SwapL( wavhdr->datasize );
}

#endif /* BIG_ENDIAN */

int wav2adpcm(const char *infile,const char *outfile)
{
   struct wavhdr_t wavhdr;
   FILE *in,*out;
   size_t pcmsize,adpcmsize;
   void *pcmbuf,*adpcmbuf;

   in = fopen(infile,"rb");
   if (in==NULL)  {
      printf("can't open %s\n",infile);
      return -1;
   }
   fread(&wavhdr,1,sizeof(wavhdr),in);

#if BYTE_ORDER == BIG_ENDIAN

   SwapHdr( &wavhdr );

#endif /* BIG_ENDIAN */

   if(memcmp(wavhdr.hdr1,"RIFF",4)
   || memcmp(wavhdr.hdr2,"WAVEfmt ",8)
   || memcmp(wavhdr.hdr3,"data",4)
   || wavhdr.hdrsize!=0x10
   || wavhdr.format!=1
   || wavhdr.channels!=1
   || wavhdr.bits!=16) {
      printf("unsupport format ( only 16 bit, mono, uncompress PCM data format is supported )\n");
      fclose(in);
      return -1;
   }

   pcmsize = wavhdr.datasize;

   adpcmsize = pcmsize/4;
   pcmbuf = malloc(pcmsize);
   adpcmbuf = malloc(adpcmsize);

   fread(pcmbuf,1,pcmsize,in);
   fclose(in);

#if BYTE_ORDER == BIG_ENDIAN

   {
      int i;
      short *ptr;

      ptr = pcmbuf;

      for ( i=0; i<pcmsize/2; i++ ) ptr[i] = SwapW( ptr[i] );
   }
#endif /* BIG_ENDIAN */

   pcm2adpcm(adpcmbuf,pcmbuf,pcmsize);

   out = fopen(outfile,"wb");
   fwrite(adpcmbuf,1,adpcmsize,out);
   fclose(out);

   return 0;
}

int adpcm2wav(const char *infile,const char *outfile,int freq)
{
   struct wavhdr_t wavhdr = {
      "RIFF",0,
      "WAVEfmt ",0x10,1/* PCM */,2,44100,44100*2*2,2*2,16,
      "data"
   };

   FILE *in,*out;
   size_t pcmsize,adpcmsize;
   void *pcmbuf,*adpcmbuf;

   in = fopen(infile,"rb");
   if (in==NULL)  {
      printf("can't open %s\n",infile);
      return -1;
   }
   fseek(in,0,SEEK_END);
   adpcmsize = ftell(in);
   fseek(in,0,SEEK_SET);

   pcmsize = adpcmsize*4;
   adpcmbuf = malloc(adpcmsize);
   pcmbuf = malloc(pcmsize);

   fread(adpcmbuf,1,adpcmsize,in);
   fclose(in);

   adpcm2pcm(pcmbuf,adpcmbuf,adpcmsize);

   wavhdr.channels = 1;
   wavhdr.freq = freq;
   wavhdr.blocksize = (short) (wavhdr.channels*sizeof(short));
   wavhdr.byte_per_sec = wavhdr.freq*wavhdr.blocksize;
   wavhdr.datasize = pcmsize;
   wavhdr.totalsize = wavhdr.datasize + sizeof(wavhdr)-8;

#if BYTE_ORDER == BIG_ENDIAN

   SwapHdr( &wavhdr );

   {
      int i;
      short *ptr;

      ptr = pcmbuf;

      for ( i=0; i<pcmsize/2; i++ ) ptr[i] = SwapW( ptr[i] );
   }

#endif /* BIG_ENDIAN */

   out = fopen(outfile,"wb");
   fwrite(&wavhdr,1,sizeof(wavhdr),out);
   fwrite(pcmbuf,1,pcmsize,out);
   fclose(out);

   return 0;
}

int main(int argc,char **argv)
{
   if (argc==3) {
      return wav2adpcm(argv[1],argv[2]);
   } else if (argc==5 && strcmp(argv[1],"-r")==0) {
      return adpcm2wav(argv[3],argv[4],atoi(argv[2]));
   } else {
      printf( "wav2adpcm: 16bit mono wav to aica adpcm (c)2002 BERO\n"
         " wav2adpcm <infile.wav> <outfile.pcm>\n"
         " wav2adpcm -r <freq> <infile.pcm> <outfile.pcm>\n"
      );
      return -1;
   }
}
