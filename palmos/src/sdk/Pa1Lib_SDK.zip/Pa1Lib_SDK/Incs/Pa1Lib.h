/************************************************************************
 *
 * Copyright (c) 2001 YAMAHA CORPORATION. or its subsidiaries.
 * All rights reserved.
 *
 * File: Pa1Lib.h
 *
 * Description:
 *		Include file for Pa1Lib Sound Library
 *
 * History:
 *		2001/07/02		Initial Release
 *		2001/11/14		Removed some function's definitions
 *
 ************************************************************************/

#ifndef _PA1LIB_H_INCLUDED_
#define _PA1LIB_H_INCLUDED_

/************************************************************************/

#define PA1Lib_NAME	"Pa1Lib"
#define PA1Lib_ID	'yP1L'

/************************************************************************/

typedef struct CallbackInfoType {
   void		(*funcP)(UInt32);
   UInt32 	dwUserData;
} CallbackInfoType;

typedef struct SmfMgrChanRangeType {
   UInt8 	bFirstChan;
   UInt8 	bLastChan;
} SmfMgrChanRangeType;

typedef struct SmfMgrPlayTimeType {
  UInt32 dwStartMilliSec;
  UInt32 dwEndMilliSec;
} SmfMgrPlayTimeType;


/************************************************************************
 * Prototypes of local functions
 ************************************************************************/
Boolean Pa1Lib_Open();
void Pa1Lib_Close();
Boolean Pa1Lib_smfOpen( UInt8 *pSmaf, MemPtr reservedP,
							UInt8 *hd, UInt32 *duration );
Boolean Pa1Lib_smfPlay( UInt8 hd, UInt8 mode,
							SmfMgrPlayTimeType  *playTimeP,
							SmfMgrChanRangeType *chanRangeP,
							CallbackInfoType *callbackInfoP );
Boolean Pa1Lib_smfClose( UInt8 hd );
Boolean Pa1Lib_smfStop( UInt8 hd );
Boolean Pa1Lib_smfGetCurrentPosition( UInt8 hd, UInt32 *pos );
Boolean Pa1Lib_midiOpen( MemPtr reservedP, UInt8 *hd );
Boolean Pa1Lib_midiClose( UInt8 hd );
Boolean Pa1Lib_midiNoteOn( UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel );
Boolean Pa1Lib_midiNoteOff( UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel );
Boolean Pa1Lib_midiControlChange( UInt8 hd, UInt8 ch, UInt8 ctrl, UInt8 param );
Boolean Pa1Lib_midiProgramChange( UInt8 hd, UInt8 ch, UInt8 prgchng );
Boolean Pa1Lib_midiPitchBend( UInt8 hd, UInt8 ch, short bend );
Boolean Pa1Lib_sndEventProc();
Boolean Pa1Lib_devSpVolume( UInt8 vol );
Boolean Pa1Lib_devHpVolume( UInt8 vol_l, UInt8 vol_r );
Boolean Pa1Lib_adpcmOpen(UInt8 fs, UInt8 *data, UInt32 dwSize,
						 CallbackInfoType *callbackInfoP,
						 UInt8 *hd );
Boolean Pa1Lib_adpcmClose(UInt8 hd);
Boolean Pa1Lib_adpcmStart(UInt8 hd, UInt8 mode);
Boolean Pa1Lib_adpcmStop(UInt8 hd);
Boolean Pa1Lib_adpcmAddPlayList(UInt8 hd);

/************************************************************************
 * API Prototypes
 ************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif

/************************************************************************
 * 		Standard library open, close, sleep and wake functions
 ************************************************************************/

Err PA1LibOpen(UInt16 refNum)
	SYS_TRAP(sysLibTrapOpen);

Err PA1LibClose(UInt16 refNum, UInt16 *numAppsP)
	SYS_TRAP(sysLibTrapClose);

Err PA1LibSleep(UInt16 refNum)
	SYS_TRAP(sysLibTrapSleep);

Err PA1LibWake(UInt16 refNum)
	SYS_TRAP(sysLibTrapWake);


/************************************************************************
 *		SMF Manager Functions
 ************************************************************************/

Err PA1L_smfOpen( UInt16 refNum, UInt8 *pSmf,
			 MemPtr reservedP,
			 UInt8 *hd, UInt32 *duration, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 0 );

Err PA1L_smfClose( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 1 );

Err PA1L_smfPlay( UInt16 refNum, UInt8 hd, UInt8 mode, 
			SmfMgrPlayTimeType  *playTimeP,
			SmfMgrChanRangeType *chanRangeP,
			CallbackInfoType *callbackInfoP, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 2 );

Err PA1L_smfStop( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 3 );

Err PA1L_smfGetCurrentPosition(UInt16 refNum, UInt8 hd,
			UInt32 *pos, Boolean *retval)
	SYS_TRAP( sysLibTrapCustom + 6 );


/************************************************************************
 *		MIDI Manager Functions
 ************************************************************************/

Err PA1L_midiOpen( UInt16 refNum,
			MemPtr reservedP, UInt8 *hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 7 );

Err PA1L_midiClose( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 8 );

Err PA1L_midiNoteOn( UInt16 refNum, UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 9 );

Err PA1L_midiNoteOff( UInt16 refNum, UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 10 );

Err PA1L_midiControlChange( UInt16 refNum, UInt8 hd, UInt8 ch, UInt8 ctrl,
			UInt8 param, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 11 );

Err PA1L_midiProgramChange( UInt16 refNum, UInt8 hd, UInt8 ch, UInt8 prgchng,
			Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 12 );

Err PA1L_midiPitchBend( UInt16 refNum, UInt8 hd, UInt8 ch, short bend, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 13 );


/************************************************************************
 *		Adpcm Functions
 ************************************************************************/

Err PA1L_adpcmOpen( UInt16 refNum, UInt8 fs, UInt8 *data, UInt32 dwSize,
						 CallbackInfoType *callbackInfoP,
						 UInt8 *hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 39 );

Err PA1L_adpcmClose( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 40 );

Err PA1L_adpcmStart( UInt16 refNum, UInt8 hd, UInt8 mode, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 41 );

Err PA1L_adpcmStop( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 42 );

Err PA1L_adpcmAddPlayList( UInt16 refNum, UInt8 hd, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 43 );


/************************************************************************
 *		Other Functions
 ************************************************************************/

Err PA1L_sndEventProc( UInt16 refNum, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 20 );

Err PA1L_devSpVolume( UInt16 refNum, UInt8 vol, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 25 );

Err PA1L_devHpVolume( UInt16 refNum, UInt8 vol_l, UInt8 vol_r, Boolean *retval )
	SYS_TRAP( sysLibTrapCustom + 27 );


#ifdef __cplusplus 
}
#endif

#endif	/* _PA1LIB_H_INCLUDED_ */
