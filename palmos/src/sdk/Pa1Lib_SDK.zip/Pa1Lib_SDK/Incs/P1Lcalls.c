/************************************************************************
 *
 * Copyright (c) 2001 YAMAHA CORPORATION. or its subsidiaries.
 * All rights reserved.
 *
 * File Name: Pa1Sample.c
 *
 * Description:
 *  Pa1Lib function wrappers for more convenient
 *
 * Date:
 *  2001/06/26    Initial release
 *  2001/07/18    Modified Pa1Lib_Open(). When SysLibLoad() returns any 
 *                error, this function returns false.
 *  2001/11/14    Removed some functions.
 ************************************************************************/
#include <PalmOS.h>
#include "Pa1Lib.h"

UInt16  	Pa1LibRef;
Boolean		Pa1LibOpened = false;

/************************************************************************
 * Name 		: Pa1LibOpen
 * Function 	: Open PA-1 Library
 * Input 		: none
 * Return 		: Boolean :	true  ... Success
 * 							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_Open()
{
	Err  error;

	error = SysLibFind( PA1Lib_NAME, &Pa1LibRef );
	if( error ) {
		error = SysLibLoad( 'libr', PA1Lib_ID, &Pa1LibRef );
		if( error )
			return false;
	}
	
	error = PA1LibOpen( Pa1LibRef );
	if( error )
		return false;
	else {
		Pa1LibOpened = true;
		return true;
	}
}

/************************************************************************
 * Name	 	: Pa1LibClose
 * Function 	: Close PA-1 Library
 * Input 		: none
 * Return 		: none
 ************************************************************************/
void Pa1Lib_Close()
{
	UInt16 usecount;

	if( !Pa1LibOpened )
		return;
		
	PA1LibClose(Pa1LibRef, &usecount);

	if( usecount==0 )
		SysLibRemove(Pa1LibRef);
}

/************************************************************************
 * Name 		: Pa1Lib_smfOpen
 * Function 	: Open SMF File
 * Input 		: UInt8 *pSmaf
 * 				  MemPtr reservedP
 * 				  UInt8 *hd
 *				  UInt32 *duration
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_smfOpen( UInt8 *pSmaf, MemPtr reservedP,
				UInt8 *hd, UInt32 *duration )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_smfOpen( Pa1LibRef, pSmaf, NULL, hd, duration, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_smfPlay
 * Function 	: Start SMF Playback
 * Input 		: UInt8 hd	: handle
 *				  UInt8 mode
 *				  SmfMgrPlayTimeType *playTimeP
 *				  SmfMgrChanRangeType *chanRangeP
 *				  CallbackInfoType *callbackInfoP 
 *	Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_smfPlay( UInt8 hd, UInt8 mode,
							SmfMgrPlayTimeType *playTimeP,
							SmfMgrChanRangeType *chanRangeP,
							CallbackInfoType *callbackInfoP )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_smfPlay( Pa1LibRef, hd, mode, playTimeP, chanRangeP, 
											callbackInfoP, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_smfClose
 * Function 	: Close SMF File
 * Input 		: UInt8 hd	: handle
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_smfClose( UInt8 hd )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_smfClose( Pa1LibRef, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_smfStop
 * Function 	: Stop SMF Playback
 * Input 		: UInt8 hd	: handle
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_smfStop( UInt8 hd )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_smfStop( Pa1LibRef, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_smfGetCurrentPosition
 * Function 	: Report Current Position
 * Input 		: UInt8 hd	: handle
 *				  UInt32 *pos
 *	Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_smfGetCurrentPosition( UInt8 hd, UInt32 *pos )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_smfGetCurrentPosition( Pa1LibRef, hd, pos, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiOpen
 * Function 	: Open MIDI device
 * Input 		: MemPtr reservedP
 *				  UInt8  *hd
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiOpen( MemPtr reservedP, UInt8 *hd )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiOpen( Pa1LibRef, NULL, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiClose
 * Function 	: Close MIDI device
 * Input 		: UInt8  hd	 : handle
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiClose( UInt8 hd )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiClose( Pa1LibRef, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiNoteOn
 * Function 	: MIDI Note On
 * Input 		: UInt8  hd	 : handle
 *				  UInt8  ch    : channel
 *				  UInt8  key   : key
 *				  UInt8  vel   : velocity
 *	Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiNoteOn( UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiNoteOn( Pa1LibRef, hd, ch, key, vel, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiNoteOff
 * Function 	: MIDI Note Off
 * Input 		: UInt8  hd	 : handle
 *				  UInt8  ch    : channel
 *				  UInt8  key   : key
 *				  UInt8  vel   : velocity
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiNoteOff( UInt8 hd, UInt8 ch, UInt8 key, UInt8 vel )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiNoteOff( Pa1LibRef, hd, ch, key, vel, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiControlChange
 * Function 	: MIDI Control Change
 * Input 		: UInt8  hd	 : handle
 *				  UInt8  ch    : channel
 *				  UInt8  ctrl  : control num
 *				  UInt8  param : parameter
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiControlChange( UInt8 hd, UInt8 ch, UInt8 ctrl, UInt8 param )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiControlChange( Pa1LibRef, hd, ch, ctrl, param, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiProgramChange
 * Function 	: MIDI Program Change
 * Input 		: UInt8  hd	   : handle
 *				  UInt8  ch      : channel
 *				  UInt8  prgchng : program change
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiProgramChange( UInt8 hd, UInt8 ch, UInt8 prgchng )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiProgramChange( Pa1LibRef, hd, ch, prgchng, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_midiPitchBend
 * Function 	: MIDI Pitch Bend
 * Input :		  UInt8  hd	 : handle
 * 				  UInt8  ch    : channel
 *				  short  bend  : pitch bend(-8192-8191)
 *	Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_midiPitchBend( UInt8 hd, UInt8 ch, short bend )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_midiPitchBend( Pa1LibRef, hd, ch, bend, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_sndEventProc
 * Function 	: 
 * Input 		: none
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_sndEventProc( )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_sndEventProc( Pa1LibRef , &retval);
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_devSpVolume
 * Function 	: Set speaker volume
 * Input 		: UInt8  vol : volume
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_devSpVolume( UInt8 vol )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_devSpVolume( Pa1LibRef, vol, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_devHpVolume
 * Function 	: Set head phone volume
 * Input 		: UInt8 vol_l : Left volume
 *				  UInt8 vol_r : Right volume
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_devHpVolume( UInt8 vol_l, UInt8 vol_r )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_devHpVolume( Pa1LibRef, vol_l, vol_r, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_adpcmOpen
 * Function 	: 
 * Input 		: UInt8 fs
 *				  UInt8 *data
 *				  UInt32 dwSize
 *				  CallbackInfoType *callbackInfoP
 *				  UInt8 *hd
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_adpcmOpen(UInt8 fs, UInt8 *data, UInt32 dwSize,
						 CallbackInfoType *callbackInfoP,
						 UInt8 *hd )
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_adpcmOpen( Pa1LibRef, fs, data, dwSize, callbackInfoP, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_adpcmClose
 * Function 	: 
 * Input 		: UInt8 hd
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_adpcmClose(UInt8 hd)
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_adpcmClose( Pa1LibRef, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_adpcmStart
 * Function 	: 
 * Input 		: UInt8 hd
 *				  UInt8 mode
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_adpcmStart(UInt8 hd, UInt8 mode)
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_adpcmStart( Pa1LibRef, hd, mode, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_adpcmStop
 * Function 	: 
 * Input 		: UInt8 hd
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_adpcmStop(UInt8 hd)
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_adpcmStop( Pa1LibRef, hd, &retval );
	return retval;
}

/************************************************************************
 * Name 		: Pa1Lib_adpcmAddPlayList
 * Function 	: 
 * Input 		: UInt8 hd	: handle(0xFF means Flush Play List)
 * Return 		: Boolean :	true  ... Success
 *							false ... N.G
 ************************************************************************/
Boolean Pa1Lib_adpcmAddPlayList(UInt8 hd)
{
	Boolean retval;

	if( !Pa1LibOpened )
		return false;
		
	PA1L_adpcmAddPlayList( Pa1LibRef, hd, &retval );
	return retval;
}
