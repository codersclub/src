//   genpw.h

//   Include for genpw.c Generate Password program
//   This file contains the defines for ID number of
//   objects used in the program
//

#define GenPWPrefID    0x00
#define GenPWPrefsVersionNum  4
#define GenPWPrefsVersionOld  3

#define genpwFormMain  1000

#define genpwMenu1     1002
#define genpwHelp1     1003
#define genpwBitmap    1004
#define genpwAbout1    1005

#define idCaseLbl      2000
#define idMixedPB      2001
#define idUpperPB      2002
#define idLowerPB      2003
#define idNumberCB     2004
#define idSpecCharCB   2005
#define idDownRB       2006
#define idNumberFld    2007
#define idUpRB         2008
#define idPasswdFld    2009
#define idOKB          2010
#define idVersionLbl   2011
#define idNumPB        2012
#define idHexPB        2013

#define idGenMenu      5000
#define idCopyMenu     5002
#define idAboutMenu    5004
#define idHelpMenu     5005
#define RomIncompatibleAlert  5006
