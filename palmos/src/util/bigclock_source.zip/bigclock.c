/*
BigClock

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Written by Jens Rupp
jens@gacel.de
http://www.gacel.de/bigclock.htm
*/
#define NON_PORTABLE

#include <PalmOS.h>
#include <CoreTraps.h>
#include <System/SerialMgrOld.h>   // for talelight
#include <SysEvtMgr.h>
#include <PalmCompatibility.h>
#include "bigclock.h"
#include "gccfix.h"
#include "Trg.h"
#include "Vga.h"
#include "Silk.h"


#define BCAppID       'BClk'
#define ymove 2

#define SEG_UTIL  __attribute__ ((section ("util")))
#define SEG_OPTION  __attribute__ ((section ("option")))
#define SEG_DRAW  __attribute__ ((section ("draw")))
#define SEG_FIRE  __attribute__ ((section ("fire")))


//default panels
const int defpages[2][8] ={
                       {pnMonth << 3 ,pnTime << 3, (pnAlarm << 3) +0,(pnAlarm << 3) +1,(pnTime << 3) + 1,(pnTime << 3) + 2,pnTimer << 3,pnControl << 3},
                       {pnDate << 3,(pnTime << 3) , (pnAlarm << 3) +2,(pnAlarm << 3) +3,pnWorld << 3,(pnWorld << 3) +1, (pnTimer << 3) + 1,(pnControl << 3) + 1}
                      };


// default sounds
const unsigned int inits[4][4][3] = {
                        { {1000,200,0} , {2000,200,0} , {0,0,0}, {0,0,0}},
                        { {500,100,0} , {1000,100,0} , {500,100,0}, {1000,100,50}},
                        { {1000,100,0} , {2000,100,0} , {4000,100,0}, {5000,100,300}},
                        { {2000,300,0} , {4000,300,0} , {2000,200,0}, {4000,200,20}}
                       }; //96


#include "bigclocktypes.h"

//main segment
int StartApplication(void);
Boolean ReadAlarm(DmOpenRef BCdb,int num,BigClockAlarm *target);
Boolean WriteAlarm(DmOpenRef BCdb,int num,BigClockAlarm *source);
Boolean bigclock(EventPtr event);
void EventLoop(void);
void StopApplication(void);
void SetNextAlarm(UInt cno,LocalID aid);
void CloseAlarm(DmOpenRef BCdb);
DmOpenRef OpenAlarm();
void AlarmTriggered (SysAlarmTriggeredParamType * cmdPBP);
void DisplayAlarm (SysAlarmTriggeredParamType * cmdPBP);
void SwitchAlarm();
void ResetData();
void UpdateSystemAlarm ();
void UpdateTimer(int num);
Boolean newyear(EventPtr event);

#define debug

#ifdef debug
  HostFILEType  *log;
#endif

//options segment
Boolean layout(EventPtr event);
Boolean optionsworld(EventPtr event);
Boolean optionsglobal(EventPtr event);
Boolean optionssound(EventPtr event);
Boolean optionscolor(EventPtr event);
Boolean optionslocaltime(EventPtr event);
Boolean optionsalarm(EventPtr event);
Boolean labelhistory(EventPtr event);

//draw segment in draw.c
extern void ColorSet(Boolean i) SEG_DRAW;
//extern void MyDrawChars(const Char *chars, Int16 len,Coord x, Coord y,Boolean i) SEG_DRAW;
extern void SwitchDrawSection(int val,int y,Boolean sw) SEG_DRAW;
extern void DrawTime(int num,int y,Boolean alarm, Boolean timer,Boolean small) SEG_DRAW;
extern void DrawButton(char *t,Boolean i,int x, int y, int h, int w, int o)  SEG_DRAW;
extern void MySetFont(int n) SEG_DRAW;
extern void TinyNumber(int size,int x,int y,int num) SEG_DRAW;
extern void DrawSilkMonth(int off,int x,int y) SEG_DRAW;




//util segment
void SetSound(int a,int w);

//fire segment
void initrockets(void) SEG_FIRE;
void animaterockets() SEG_FIRE;
void addexplode(int x,int y) SEG_FIRE;
void addrocket(int x,int y,int xs,int ys,int time, Boolean explode, int sprite) SEG_FIRE;
void freerockets(void)  SEG_FIRE;
int  SysRandomUnder(int num) SEG_FIRE;

Boolean	HwrBacklight(Boolean set, Boolean newState) SYS_TRAP(sysTrapHwrBacklightV33);


char help[256];       // used to store different data ( Theme list) and debugging
Boolean dirty=false;  // for the backup bit of the data database
DWord romversion;
Boolean is35;         // os 3.5 or higher
Boolean isTRG;        //larger screen
Boolean iscolor;      // color device
UInt32  maxdepth;
UInt32  screenwidth;
UInt32  screenheight;
UInt32  panelwidth=160;
UInt32  panelheight=62;
UInt32  startscreendepth;
int   changed[2];     // upper (0) or lower (1) panel changed -> redraw
Boolean GotHelp;
Boolean InfoIconState=false;
UInt32  ytop=15;         // upper panel
UInt32 ybottom=77;      // lower panel



VoidHand hdays;
char      *pdays;
//WinHandle bitmaps;
WinHandle build=NULL;
DateTimeType Time[wCount];
Boolean recreate=false;
//Boolean screenChanged = false;


VoidHand   bigbitmapH[16];
BitmapPtr  bigbitmapP[16];


int        ThemeMode=0;

DmOpenRef  ThemeDB=0;
Boolean    resdb=true;
int        BackgroundID=0;
VoidHand   BackgroundH;
BitmapPtr  Background=NULL;
VoidHand   ThemeDefH=NULL;
BigClockThemeDef *ThemeDef=NULL;
VoidHand   ThemeBonusH=NULL;
BigClockBonusDef *ThemeBonus=NULL;
char       *ThemeList[maxthemes];


BigClockRegion *regions=NULL;

//61

SystemPreferencesType SysPref; //100
DateTimeType LastTime[1];
DmOpenRef     SysDB;
//108

//day and month text parsed from resource
char      daystrings[100];
char      monthstrings[100];
char      *day[7];
char      *month[12];

char      page=0;
Boolean   running=false;
char      optionpage=0;
Int8      historymode;
char      detailweek[12];
char      detailday[12];
char      detailhour[12];

char      stimer[4][12];

char      salarmmode[2][12];
char      stimermode[7][14];

char      reltimerdate[12];
char      reltimertime[12];
//484

UInt cardNo;
LocalID appID;
//8

// midi support...  still not done :(
//Boolean   usemidi;
//char   **midilist=NULL;

BigClockPrefType prefs;

Boolean ao;
int     obase;
int     timercommand=0;
//6

const int inot[2] = {1,0};


#include "util.c"
#include "option.c"
#include "fire.c"


void DrawSilk()
{
  RectangleType rc = {{0,240},{240,66}};

  ColorSet(false);
  WinEraseRectangle(&rc,0);
  WinDrawLine(0,240,239,240);

  DrawSilkMonth(-1+prefs.monthadd,1,244);
  WinDrawLine(79,240,79,306);
  DrawSilkMonth(0+prefs.monthadd,80+4,244);
  WinDrawLine(161,240,161,306);
  DrawSilkMonth(1+prefs.monthadd,160+6,244);

}


static void ResizeForm() //(Boolean draw)
{
    Coord         x,y;
    RectangleType r;
    FormPtr       frmP;

    WinGetDisplayExtent(&x, &y);
    RctSetRectangle(&r, 0, 0, x, y+1);

    frmP = FrmGetActiveForm();
    WinSetWindowBounds(FrmGetWindowHandle(frmP), &r);
    //screenChanged = false;

    /*
    if (draw)
    {
      DrawSilk();
    } */
}


DWord  PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  int error;



  if (cmd == sysAppLaunchCmdNormalLaunch)
  {
#ifdef debug
  log=HostFOpen("c:\\palm\\bigclock\\log.txt","w");
  HostFPutS("Startlog\n", log);
#endif

    error = StartApplication();	// Application start code

    if (error) return error;
    EventLoop();	// Event loop

    StopApplication ();	// Application stop code
#ifdef debug
  HostFPutS("END\n", log);
  HostFClose(log);
#endif

  } else if (cmd == sysAppLaunchCmdAlarmTriggered)
  {
    AlarmTriggered ((SysAlarmTriggeredParamType *)cmdPBP);
  } else if (cmd == sysAppLaunchCmdDisplayAlarm)
  {
    DisplayAlarm ((SysAlarmTriggeredParamType *)cmdPBP);
  } else if ((cmd == sysAppLaunchCmdSystemReset) ||
             (cmd == sysAppLaunchCmdTimeChange)
             )

  {
    UpdateSystemAlarm();
  } else if (cmd==sysAppLaunchCmdNotify)
  {
    /*
    if(launchFlags & sysAppLaunchFlagSubCall)
    {
      UInt16 formID;
      Boolean draw;

    if ((formID = FrmGetActiveFormID()) == formID_bigclock)
        {
          if (FrmVisible(FrmGetActiveForm()))
            draw = true;
          else
            draw = false;
          ResizeForm(draw);
        }
      else
        screenChanged = true;
    } */
  }



  return (0);
}

#ifdef debug
void debugi(char *name,Int32 value)
{
  char out[128];
  char n[32];

  StrCopy(out,name);
  StrCat(out,": ");
  StrIToA(n,value);
  StrCat(out,n);
  StrCat(out,"\n");
  HostFPutS(out, log);
}

void debugs(char *name,char* value)
{
  char out[128];

  StrCopy(out,name);
  StrCat(out,": ");
  StrCat(out,value);
  StrCat(out,"\n");
  HostFPutS(out, log);
}

#endif


void CustomBeep(int num)
{
  int iii;
  SndCommandType cmd;


  cmd.cmd = sndCmdFreqDurationAmp;
  cmd.param3 = sndMaxAmp;

  if (num==0)
  {
    for (iii=0 ; iii<20 ; iii++)
    {

      cmd.param1 = 3000;
      cmd.param2 = 20;
      SndDoCmd(0, &cmd, 0);

      cmd.param1 = 5000;
      cmd.param2 = 1;
      SndDoCmd(0, &cmd, 0);
    }
  }
  else if (num==1)
  {
    cmd.param1 = 3000;
    for (iii=0 ; iii < 4 ; iii++)
     {
       cmd.param2 = 200;
       cmd.param3 = sndMaxAmp;
       SndDoCmd(0, &cmd, 0);
       cmd.param2 = 80;
       cmd.param3 = 1;
       SndDoCmd(0, &cmd, 0);
     }
  }

}


int DisplayAndSound(SysAlarmTriggeredParamType * cmdPBP,int typ)
{
  FormPtr frm;
  FormPtr curForm;
  EventType	event;
  RectangleType rc1 = {{0,0},{160,40}};
  RectangleType rc2 = {{0,40},{160,120}};
  RectangleType rc3 = {{16,20},{128,18}};
  int dummy;
  DateTimeType time;
  BigClockAlarm *alarm;
  SystemPreferencesType *lSysPref;
  DWord backlight;
  int note;
  int rep;
  Boolean quit;
  SndCommandType cmd;
  int stop;
  DmOpenRef BCdb;
  Boolean del;
  Boolean blok;
  UInt    serialRef = -1;
  int     result=0;
  char    message[32];
  char    number[6];
  WinHandle Save;
  FontID oldfont;
  RectangleType screen = {{0,0},{160,160}};
  DWord version;
  int err;
  Boolean isTRGl;
  VgaScreenModeType oldmode;
  VgaRotateModeType oldrotation;
  VgaScreenStateType oldstate;

  isTRGl=FtrGet(TRGSysFtrID, TRGVgaFtrNum, &version) == 0;


  //remember old form
  curForm = FrmGetActiveForm ();
  //remember old font
  oldfont = FntGetFont();

  //set new form
  frm= FrmGetFormPtr(formID_displayalarm);
  if (frm==NULL)
    {
      // if not created already, create it
      frm = FrmInitForm (formID_displayalarm);
      del=true;
    }
  else
    del=false;  // remember not to delete the form

  //if (isTRG)
  //  VgaFrmModify(frm,vgaFormModify160To240);


  FrmSetActiveForm (frm);


  if (isTRGl)
  {
    VgaSaveScreenState(&oldstate);
    VgaGetScreenMode(&oldmode,&oldrotation);

    VgaSetScreenMode(screenMode1To1,oldrotation);
    screen.extent.x=240;
    screen.extent.y=240;
    Save=WinCreateOffscreenWindow(240,240,screenFormat,(Word *)&dummy);
  } else
  {
    // create offscreen window to save screen
    Save=WinCreateOffscreenWindow(160,160,screenFormat,(Word *)&dummy);
  }

  // save screen
  if (Save!=NULL)
    WinCopyRectangle(WinGetDisplayWindow(),Save,&screen,0,0,scrCopy);

  if (isTRGl)
    VgaSetScreenMode(screenModeScaleToFit,oldrotation);


  //WinSetDrawWindow(WinGetActiveWindow());

  //display form
  FntSetFont(2);

  //bug, depending on compile this is required or creates a exception
  err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &version);
  if(version < 0x03500000)
    WinEraseWindow();

  FrmDrawForm (frm);


  // read preferences
  lSysPref=MemPtrNew(sizeof(SystemPreferencesType));
  if (lSysPref==NULL) return result;
  PrefGetPreferences(lSysPref);

  //read alarm data
  alarm=MemPtrNew(sizeof(BigClockAlarm));
  if (alarm==NULL) return result;
  BCdb=OpenAlarm();
  ReadAlarm(BCdb,cmdPBP->ref,alarm);
  CloseAlarm(BCdb);

  // display data
  TimSecondsToDateTime(cmdPBP->alarmSeconds,&time);
  TimAdjust(&time,alarm->worldoffset);
  TimeToAscii(time.hour,time.minute,lSysPref->timeFormat,message);
  WinDrawChars(alarm->worldname,StrLen(alarm->worldname),2,90);
  WinDrawChars(message,StrLen(message),2,106);
  WinDrawChars(alarm->name,StrLen(alarm->name),2,122);

  //display snooze
  if (alarm->options.snooze==1)
  {
    SysCopyStringResource(message,stringID_stopsnooze);
    FntSetFont(0);
    dummy=FntCharsWidth(message,StrLen(message));
    WinDrawRectangleFrame(roundFrame,&rc3);
    WinDrawChars(message,StrLen(message),80-(dummy /2),24);
    if (alarm->snoozecurrent > 0)
    {
       StrCopy(message,"Snooze ");
       StrIToA(number,alarm->snoozecurrent);
       StrCat(message,number);
       StrCat(message," / ");
       StrIToA(number,alarm->snoozecount);
       StrCat(message,number);
       FntSetFont(2);
       WinDrawChars(message,StrLen(message),2,138);
    }
  }

  // use backlight?
  blok=false;
  if  ((alarm->options.backlight > 0) && (typ==1))
  {
    FtrGet(sysFtrCreator, sysFtrNumBacklight, &backlight);
    blok=(backlight>0);
  }

  // use talelight?
  if ((alarm->options.talelight >0) && (typ==1))
  {
    dummy=SysLibFind("Serial Library", &serialRef);
    if (dummy) serialRef=-1;
  }

  //clear events
  do
  {
    EvtGetEvent(&event, 1);
    if (SysHandleEvent (&event)) continue;
  } while (event.eType != nilEvent);

  note=0;
  rep=0;
  dummy=1;
  quit=false;

  if ((alarm->options.wait==0) || (typ==1))
    stop=1;
  else
    stop=-1;

  do
    {
     EvtGetEvent(&event, dummy);

    if (SysHandleEvent (&event)) continue;

    if (event.eType == penDownEvent)
    {
      if (event.screenY < 40)
      {
        WinInvertRectangle(&rc1,0);
        result=1;
      } else
      {
        WinInvertRectangle(&rc2,0);
      }
      //quit=true;
    }
    //check key
    if (event.eType == keyDownEvent)
      if (
         (event.data.keyDown.chr == pageDownChr) ||
         (event.data.keyDown.chr == pageUpChr)
         )
       {
         quit=true;
       }

    //check pen
    if (event.eType == penUpEvent)
      quit=true;



    if (!quit)
      {
        if (typ==1)  // play sound
        {
          if (rep < alarm->sound.count) // number of repetition?
            {
              //backlight
              if (blok) HwrBacklight(true,true);
              // talelight
              if (serialRef != -1) SerOpen(serialRef, 0, 19200L);

              //Sound alarm?
              if (
                   (alarm->options.silent == 0) &&
                   (
                     (lSysPref->alarmSoundLevelV20 != 1) ||
                     (alarm->options.ignoresystemsoundoff)
                   )
                 )
              {
                //keep on while playing sounds
                EvtResetAutoOffTimer();

                // system sound?
                if (alarm->sound.type==1)
                {
                  //play a system alarm
                  SndPlaySystemSound(sndAlarm);
                } else if (alarm->sound.type==0)
                {
                  if (alarm->sound.freq[note] > 0)
                  {
                    //play the note
                    cmd.cmd = sndCmdFreqDurationAmp;
                    cmd.param1 = alarm->sound.freq[note];
                    cmd.param2 = alarm->sound.time[note];
                    cmd.param3 = alarm->sound.amplitude[note];
                    SndDoCmd(0, &cmd, 0);
                  }
                } else if (alarm->sound.type>=2)
                {
                  CustomBeep(alarm->sound.type-2);
                }

              }
              //talelight off
              if (serialRef != -1) SerClose(serialRef);
              //backlight off
              if (blok) HwrBacklight(true,false);

              //set pause
              if (alarm->sound.type == 0)
                dummy=alarm->sound.pause[note];
              else
                dummy=100;

              note++;  //next note
              if ((note==4) || (alarm->sound.type != 0)) // last note in set of 4?
              {
                rep++;  // next repetition
                note=0; // first note
              }
            }
          else
            dummy=stop;
        }
         else
           {
             dummy=stop;
             rep=alarm->sound.count+1;
           }
      }

  //check key
  if (event.eType == keyDownEvent)
    if (
       (event.data.keyDown.chr == pageDownChr) ||
       (event.data.keyDown.chr == pageUpChr)
       )
     {
       quit=true;
     }
  //check pen
  if (event.eType == penUpEvent)
    quit=true;


 } while (
          (! quit) &&
          (! (
               (
                 (alarm->options.wait==0) ||
                 (typ==1)
                ) &&
               (rep >= alarm->sound.count)
             )
          ) /*&&
          (event.eType != appStopEvent)*/
         );

  // close serial
  if (serialRef != -1) SerClose(serialRef);
  // keep backlight on
  if (blok) HwrBacklight(true,true);

  if (quit)
    alarm->options.closed=1;
  else
    alarm->options.closed=0;

  // remember closed alarm
  BCdb=OpenAlarm();
  WriteAlarm(BCdb,cmdPBP->ref,alarm);
  CloseAlarm(BCdb);

  //free memory
  MemPtrFree(lSysPref);
  MemPtrFree(alarm);

  // restore old font
  FntSetFont(oldfont);

  //delete form
  //FrmCustomAlert(alertID_text,"del",NULL,NULL);

  if (del)
  {
    //FrmEraseForm(frm);  bug, causes fatal error with launcherIII, i restore the screen later anyway
    FrmDeleteForm (frm);
  }




  if (isTRGl)
    VgaSetScreenMode(screenMode1To1,oldrotation);

  // restore screen
  if (Save != NULL)
  {
    WinCopyRectangle(Save,WinGetDisplayWindow(),&screen,0,0,scrCopy);
    WinDeleteWindow(Save,false);
  }
  if (isTRGl)
  {
    VgaRestoreScreenState(&oldstate);
    //VgaSetScreenMode(oldmode,oldrotation);
  }
  //restore active form
  FrmSetActiveForm (curForm);

  //FrmCustomAlert(alertID_text,"return",NULL,NULL);
  return result;
}

void UpdateSystemAlarm ()
{
  UInt cardNo;
  LocalID dbID;
  DmSearchStateType searchInfo;

  DmGetNextDatabaseByTypeCreator (true, &searchInfo,
     sysFileTApplication, BCAppID, true, &cardNo, &dbID);

  SetNextAlarm(cardNo,dbID);
}



void AlarmTriggered (SysAlarmTriggeredParamType * cmdPBP)
{
  int r;
  BigClockAlarm *alarm;
  DmOpenRef BCdb;


  UpdateSystemAlarm();

  r=0;
  if (cmdPBP->ref != -2)
    r=DisplayAndSound(cmdPBP,1);

  if ((r!=0) && (cmdPBP->ref >= 0))
  {
     alarm=MemPtrNew(sizeof(BigClockAlarm));
     BCdb=OpenAlarm();
     ReadAlarm(BCdb,cmdPBP->ref,alarm);
     if (alarm->options.snooze == 1)
     {
       // set to end of snooze
       alarm->snoozecurrent=alarm->snoozecount+1;
       WriteAlarm(BCdb,cmdPBP->ref,alarm);
     }
     CloseAlarm(BCdb);
     MemPtrFree(alarm);
  }
}


void DisplayAlarm (SysAlarmTriggeredParamType * cmdPBP)
{
  UInt cardNo;
  LocalID dbID;
  DmSearchStateType searchInfo;
  BigClockAlarm *alarm;
  unsigned long now;
  DmOpenRef BCdb;
  int r=0;


  if (cmdPBP->ref == -2) return;


  DmGetNextDatabaseByTypeCreator (true, &searchInfo,
     sysFileTApplication, BCAppID, true, &cardNo, &dbID);

  alarm=MemPtrNew(sizeof(BigClockAlarm));

  BCdb=OpenAlarm();
  ReadAlarm(BCdb,cmdPBP->ref,alarm);
  CloseAlarm(BCdb);

  if ((alarm->options.closed==0) &&
      (alarm->options.wait==1))
    r=DisplayAndSound(cmdPBP,0);

  //snooze
  if ((alarm->options.snooze == 1) && (r != 1))
    {
      now=TimGetSeconds();
      alarm->snoozeoffset=now+alarm->snoozetime*60;
      alarm->snoozecurrent++;

      if (alarm->snoozecurrent>alarm->snoozecount)
        {
           alarm->snoozecurrent=0;
           if (alarm->options.trigger==2)
              alarm->options.active=0;
        }

      BCdb=OpenAlarm();
      WriteAlarm(BCdb,cmdPBP->ref,alarm);
      CloseAlarm(BCdb);


      SetNextAlarm(cardNo,dbID);

    }
  else if (alarm->options.trigger==2)
    {
      alarm->options.active=0;
      BCdb=OpenAlarm();
      WriteAlarm(BCdb,cmdPBP->ref,alarm);
      CloseAlarm(BCdb);
      SetNextAlarm(cardNo,dbID);
    }
  else
    {
      alarm->snoozecurrent=0;
      BCdb=OpenAlarm();
      WriteAlarm(BCdb,cmdPBP->ref,alarm);
      CloseAlarm(BCdb);

      SetNextAlarm(cardNo,dbID);
    }

  MemPtrFree(alarm);
}


void SetDeepthDefault()
{
  switch (prefs.screendepth)
  {
    case 1: prefs.colorb=0;
            prefs.colorf=1;
            prefs.colorbi=1;
            prefs.colorfi=0;
            break;
    case 2: prefs.colorb=0;
            prefs.colorf=3;
            prefs.colorbi=3;
            prefs.colorfi=0;
            break;
    case 4: prefs.colorb=0;
            prefs.colorf=15;
            prefs.colorbi=15;
            prefs.colorfi=0;
            break;
    case 8: case 16:prefs.colorb=37;
            prefs.colorf=255;
            prefs.colorbi=255;
            prefs.colorfi=0;
            break;
  }
}

void FreeRegions()
{
  BigClockRegion *n;
  BigClockRegion *p;

  if (regions != NULL)
  {
    n=regions;
    do
    {
      p=(BigClockRegion *)n->next;
      MemPtrFree(n);
      n=p;
    } while (n != NULL);
  }
  regions=NULL;
}

void AddRegion(Coord x1,Coord y1,Coord x2,Coord y2, UInt8 panel,UInt8 sub,UInt8 id)
{
  BigClockRegion *n;
  BigClockRegion *p;

  n=MemPtrNew(sizeof(BigClockRegion));
  n->x1=x1;
  n->y1=y1;
  n->x2=x2;
  n->y2=y2;
  n->id=id;
  n->panel=panel;
  n->sub=sub;
  n->next=NULL;

  if (regions==NULL)
    regions=n;
  else
    {
      p=regions;
      while (p->next != NULL)
      {
        p=(BigClockRegion *)p->next;
      }
      p->next=(void *)n;
    }
}


UInt8 RegionTap(Coord x,Coord y,UInt8 panel,UInt8 sub)
{
  BigClockRegion *n;
  n=regions;


  while (n != NULL)
  {
    if (n->panel == panel)
      if ((n->sub & sub) > 0)
        if  ( (x>=n->x1) && (x<= n->x2) && (y>=n->y1) && (y<= n->y2) )
          return n->id;
    n=(BigClockRegion *)n->next;
  }
  return 0;
}


void InitRegions160()
{
  int iii;
  int x;
  int n;
  UInt8 sub;

  FreeRegions();

  //********************************************************
  //pntime  hh:mm:ss and hh:mm am
  // sub=1   hh:mm
  // sub=2   ss
  // sub=4   hh:mm centered
  // sub=8   am/pm
  // sub=16   am/pm small
  x=0;
  sub=1;
  n=7;
  for (iii=0; iii<6 ; iii++)
  {
    if (iii > 3)
      sub=2;
    AddRegion(x,21,x+23,40, pnTime,sub,n);
    AddRegion(x,41,x+23,60, pnTime,sub,n+9);
    if ((iii%2) == 0)
     x+=24;
   else
     x+=24+8;
    if (iii==0)
      n-=2;
    else
      n--;
  }
  // am/pm big
  AddRegion(112,21,112+47,60, pnTime,8,7);
  // am/pm small
  AddRegion(135,0,159,18, pnTime,16,7);

  //pntime  hh:mm centered
  x=28;
  n=7;
  for (iii=0; iii<4 ; iii++)
  {
    AddRegion(x,21,x+23,40, pnTime,4,n);
    AddRegion(x,41,x+23,60, pnTime,4,n+9);
    if ((iii%2) == 0)
     x+=24;
   else
     x+=24+8;
   if (iii==0)
     n-=2;
   else
     n--;
  }

  //********************************************************
  //pnalarm
  // hh:mm

  x=56;
  n=7;
  for (iii=0; iii<4 ; iii++)
  {
    AddRegion(x,21,x+23,40, pnAlarm,1,n);
    AddRegion(x,41,x+23,60, pnAlarm,1,n+9);
    if ((iii%2) == 0)
     x+=24;
   else
     x+=24+8;
   if (iii==0)
     n-=2;
   else
     n--;
  }

  // am/pm
  AddRegion(135,0,159,18, pnAlarm,2,7);

  //checkbox
  AddRegion(3,18,3+20,18+20, pnAlarm,1,20);

  //label
  AddRegion(0,0,80,18, pnAlarm,1,21);

  // days
  for (iii=0; iii<7 ; iii++)
    AddRegion(80+iii*8,0,80+7+iii*8,18, pnAlarm,1,30+iii);

  for (iii=0; iii<4 ; iii++)
    AddRegion(34,16+iii*10,34+19,16+iii*10+9, pnAlarm,1,40+iii);

  //********************************************************
  //pntimer

  //normal mode
  x=0;
  n=6;
  for (iii=0; iii<6 ; iii++)
  {
    AddRegion(x,21,x+23,40, pnTimer,1,n);
    AddRegion(x,41,x+23,60, pnTimer,1,n+9);
    if ((iii%2) == 0)
     x+=24;
   else
     x+=24+8;
    n--;
  }

  //calcmode
  x=4;
  for (iii=0; iii<6 ; iii++)
  {
    AddRegion(x,21,x+23,40, pnTimer,2,5-iii);
    AddRegion(x,41,x+23,60, pnTimer,2,10-iii);
    if (iii != 3)
     x+=24;
   else
     x+=24+8;
  }


  //label
  AddRegion(0,0,79,18, pnTimer,4,regLabel);
  //timer toggle
  AddRegion(80,0,140,16, pnTimer,4,regTimerToggle);

  //********************************************************
  //pncontrol

  //start big
  AddRegion(3,16,3+43,16+39, pnControl,1,regTimerStart);
  //start small
  AddRegion(3,22+16,3+43,22+16+17, pnControl,4,regTimerStart);
  //label
  AddRegion(0,0,79,18, pnControl,4,regLabel);
  //timer toggle
  AddRegion(80,0,140,16, pnControl,4,regTimerToggle);
  //reset
  AddRegion(59,16,59+43,16+17, pnControl,2,regTimerReset);
  //clear
  AddRegion(59,16+22,59+43,16+17+22, pnControl,2,regTimerClear);
  //up
  AddRegion(115,16,115+19,16+19, pnControl,2,regTimerUp);
  //down
  AddRegion(115,16+20,115+19,16+19+20, pnControl,2,regTimerDown);
  //sound
  for (iii=0; iii<4 ; iii++)
    AddRegion(139,16+iii*10,139+19,16+iii*10+9, pnControl,2,40+iii);

  //********************************************************
  //pnmonth
  AddRegion(0,0,39,panelheight, pnMonth,1,regMonthLeft);
  AddRegion(40,0,79,panelheight, pnMonth,1,regMonthRight);
  AddRegion(80,0,159,panelheight, pnMonth,1,regMonthDate);


}

void InitRegionsStar()
{
  int iii;
  int x;
  int n;
  UInt8 sub;

  FreeRegions();

  //********************************************************
  //pntime  hh:mm:ss and hh:mm am
  // sub=1   hh:mm
  // sub=2   ss
  // sub=4   hh:mm centered
  // sub=8   am/pm
  // sub=16   am/pm small
  x=0;
  sub=1;
  n=7;
  for (iii=0; iii<6 ; iii++)
  {
    if (iii > 3)
      sub=2;
    AddRegion(x,24,x+35,24+29, pnTime,sub,n);
    AddRegion(x,24+30,x+35,24+59, pnTime,sub,n+9);
    if ((iii%2) == 0)
     x+=36;
   else
     x+=36+12;
    if (iii==0)
      n-=2;
    else
      n--;
  }
  // am/pm big
  AddRegion(168,24,239,84, pnTime,8,7);
  // am/pm small
  AddRegion(209,0,239,18, pnTime,16,7);

  //pntime  hh:mm centered
  x=42;
  n=7;
  for (iii=0; iii<4 ; iii++)
  {
    AddRegion(x,24,x+35,24+29, pnTime,4,n);
    AddRegion(x,24+30,x+35,24+59, pnTime,4,n+9);

    if ((iii%2) == 0)
     x+=36;
   else
     x+=36+12;
   if (iii==0)
     n-=2;
   else
     n--;
  }

  //********************************************************
  //pnalarm
  // hh:mm

  x=84;
  n=7;
  for (iii=0; iii<4 ; iii++)
  {
    AddRegion(x,24,x+35,24+29, pnAlarm,1,n);
    AddRegion(x,24+30,x+35,24+59, pnAlarm,1,n+9);
    if ((iii%2) == 0)
     x+=36;
   else
     x+=36+12;
   if (iii==0)
     n-=2;
   else
     n--;
  }

  // am/pm
  AddRegion(209,0,239,18, pnAlarm,2,7);


  //checkbox
  AddRegion(6,28,6+30,28+30, pnAlarm,1,20);

  //label
  AddRegion(0,0,120,18, pnAlarm,1,21);

  // days
  for (iii=0; iii<7 ; iii++)
    AddRegion(120+iii*12,0,120+11+iii*12,18, pnAlarm,1,30+iii);

  for (iii=0; iii<4 ; iii++)
    AddRegion(50,24+iii*15,50+30,24+iii*15+14, pnAlarm,1,40+iii);

  //********************************************************
  //pntimer

  //normal mode
  x=0;
  n=6;

  for (iii=0; iii<6 ; iii++)
  {
    AddRegion(x,24,x+35,24+29, pnTimer,1,n);
    AddRegion(x,24+30,x+35,24+59, pnTimer,1,n+9);
    if ((iii%2) == 0)
     x+=36;
   else
     x+=36+12;
    n--;
  }

  //calcmode
  x=6;
  for (iii=0; iii<6 ; iii++)
  {
    AddRegion(x,24,x+35,24+29, pnTimer,2,5-iii);
    AddRegion(x,24+30,x+35,24+59, pnTimer,2,10-iii);
    if (iii != 3)
     x+=36;
   else
     x+=36+12;
  }


  //label
  AddRegion(0,0,119,18, pnTimer,4,regLabel);
  //timer toggle
  AddRegion(120,0,201,18, pnTimer,4,regTimerToggle);

  //********************************************************
  //pncontrol

  //start big
  AddRegion(4,26,4+65,26+59, pnControl,1,regTimerStart);
  //start small
  AddRegion(4,59,4+65,59+26, pnControl,4,regTimerStart);
  //label
  AddRegion(0,0,119,18, pnControl,4,regLabel);
  //timer toggle
  AddRegion(120,0,210,18, pnControl,4,regTimerToggle);
  //reset
  AddRegion(88,26,88+65,26+26, pnControl,2,regTimerReset);
  //clear
  AddRegion(88,26+33,88+65,26+33+26, pnControl,2,regTimerClear);
  //up
  AddRegion(172,26,172+29,26+29, pnControl,2,regTimerUp);
  //down
  AddRegion(172,26+30,172+29,26+30+29, pnControl,2,regTimerDown);
  //sound
  for (iii=0; iii<4 ; iii++)
    AddRegion(208,26+iii*15,208+29,26+iii*15+14, pnControl,2,40+iii);

  //********************************************************
  //pnmonth
  AddRegion(0,0,63,panelheight, pnMonth,1,regMonthLeft);
  AddRegion(64,0,150,panelheight, pnMonth,1,regMonthRight);
  AddRegion(151,0,panelwidth,panelheight, pnMonth,1,regMonthDate);

  //pnSetTime

}

/*
void ShowRegions(UInt32 panel,UInt32 sub)
{
  BigClockRegion *n;
  RectangleType rc;

  n=regions;
  while (n!=NULL)
  {
    if ((n->panel==panel) && ((n->sub & sub) > 0))
    {
       rc.topLeft.x=n->x1+1;
       rc.topLeft.y=n->y1+1;
       rc.extent.x=n->x2-n->x1-1;
       rc.extent.y=n->y2-n->y1-1;
       //WinSetForeColor(150);
       WinDrawRectangleFrame(1,&rc);
       StrIToA(help,n->id);
       FntSetFont(0);
       WinDrawChars(help,StrLen(help),n->x1+1,n->y1+1);
    }
    n=(BigClockRegion *)n->next;
  }

}*/


 void InitPref()
{
  int iii;
  int jjj;
  int v;
  Boolean ampm;

  MemSet(&prefs,sizeof(BigClockPrefType),0);

  prefs.version=282;

  prefs.mode=0;
  prefs.pageset=0;

  ampm=!Use24HourFormat(SysPref.timeFormat);
  if (ampm)
    v=0;
  else
    v=1;

  // 0 local 1=world1 2=world2
  for (iii=0; iii<wCount; iii++)
  {
    MemSet(&prefs.world[iii],sizeof(BigClockTime),0);
    prefs.world[iii].options.ampm=ampm;
    prefs.world[iii].options.seconds=v;
    prefs.world[iii].options.wait=1;
    prefs.world[iii].options.timerup=1;
    prefs.world[iii].options.mode=3;
    prefs.world[iii].options.trigger=1;
    prefs.world[iii].days=127;
    prefs.world[iii].snoozetime=5;
    prefs.world[iii].snoozecount=3;
    prefs.world[iii].date=TimGetSeconds();
    prefs.world[iii].calc=100;
  }
  prefs.world[wLocal].options.active=1;


  for (iii=0; iii<4; iii++)
  {
    prefs.world[wAlarm1+iii].options.seconds=false;
    prefs.world[wAlarm1+iii].value=(long)daysInSeconds*1000;
    prefs.world[wTimer1+iii].options.ampm=0;
    prefs.world[wTimer1+iii].options.seconds=1;
  }

  for (iii=0; iii<13 ; iii++)
    SysCopyStringResource(prefs.world[wLocal+iii].name,stringID_localtime+iii);

  for (iii=0; iii<2 ; iii++)
    for (jjj=0; jjj<8; jjj++)
         prefs.pages[iii][jjj]=defpages[iii][jjj];

  for (iii=0; iii<2 ; iii++)
    for (jjj=0; jjj<4 ; jjj++)
      SysCopyStringResource(prefs.pagenames[iii][jjj],stringID_pagenames00+iii*4+jjj);

  for (iii=0; iii<4; iii++)
  {
     for (jjj=0; jjj<4; jjj++)
       {
         prefs.sounds[iii].freq[jjj]=inits[iii][jjj][0];
         prefs.sounds[iii].time[jjj]=inits[iii][jjj][1];
         prefs.sounds[iii].amplitude[jjj]=sndMaxAmp;
         prefs.sounds[iii].pause[jjj]=inits[iii][jjj][2];;
       }
  }
  prefs.sounds[0].count=1;
  prefs.sounds[1].count=3;
  prefs.sounds[2].count=10;
  prefs.sounds[3].count=15;
  prefs.sounds[3].type=2;

  prefs.screendepth=startscreendepth;
  SetDeepthDefault();


}

 void DrawWorldName (Int16 itemNum, RectangleType *bounds,Char **itemsText)
{
	CharPtr	itemTextP;
	SWord		itemTextLen;
	SWord		itemWidth;


	itemTextP = prefs.world[wLocal+itemNum].name;

	itemTextLen = StrLen(itemTextP);
	// Get the width of the text
	itemWidth = FntCharsWidth(itemTextP, itemTextLen);
	// Does it fit?
	if (itemWidth <= bounds->extent.x)
		{
		// Draw entire item text as is
		WinDrawChars(itemTextP, itemTextLen, bounds->topLeft.x, bounds->topLeft.y);
		}
	else
		{
		// We're going to truncate the item text
		Boolean	ignored;
		char		ellipsisChar =0x85;
                //horizEllipsisChr;
		// Set the new max item width
		itemWidth = bounds->extent.x - FntCharWidth(ellipsisChar);
		// Find the item length that fits in the bounds minus the ellipsis
		FntCharsInWidth(itemTextP, &itemWidth, &itemTextLen, &ignored);
		// Draw item text that fits
		WinDrawChars(itemTextP, itemTextLen, bounds->topLeft.x, bounds->topLeft.y);
		// Draw ellipsis char
		WinDrawChars(&ellipsisChar, 1, bounds->topLeft.x + itemWidth, bounds->topLeft.y);
		}

}

Boolean WritePref()
{
  DmOpenRef BCdb;
  VoidHand  BCprefHandle;
  BigClockPrefType *BCpref=NULL;
  //UInt          index = 0;
  UInt      attr;
  LocalID   id;

  BCdb = DmOpenDatabaseByTypeCreator('data', BCAppID, dmModeReadWrite);
  BCprefHandle=DmGetRecord(BCdb,0);
  BCpref=MemHandleLock(BCprefHandle);

  DmWrite(BCpref,0,&prefs,sizeof(BigClockPrefType));

  MemPtrUnlock(BCpref);
  DmReleaseRecord(BCdb, 0, true);
  DmCloseDatabase(BCdb);

  //for now backup always
  dirty=true;
  if (dirty)
  {
    id=DmFindDatabase(0,"BigClock data");
    if (id!=0)
    {
      DmDatabaseInfo(0,id,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
      attr=attr | dmHdrAttrBackup;
      DmSetDatabaseInfo(0,id,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
    }
  }
  return true;
}


Boolean ReadPref()
{
  DmOpenRef BCdb;
  VoidHand  BCprefHandle;
  BigClockPrefType *BCpref=NULL;
  UInt          index = 0;
  UInt lNo;
  LocalID dbID;
  DmSearchStateType searchInfo;

  BCdb = DmOpenDatabaseByTypeCreator('data', BCAppID, dmModeReadWrite);
  // if database is does not exist create it
  if (!BCdb)
  {
    if (DmCreateDatabase(0, "BigClock data", BCAppID, 'data', false)) return 1;
    BCdb = DmOpenDatabaseByTypeCreator('data', BCAppID, dmModeReadWrite);
    BCprefHandle = DmNewRecord(BCdb, &index, sizeof(BigClockPrefType));
    BCpref = MemHandleLock(BCprefHandle);
    //init the data
    InitPref();
  } else
  {
    BCprefHandle=DmGetRecord(BCdb,0);
    BCpref=MemHandleLock(BCprefHandle);
    if (MemPtrSize(BCpref) != sizeof(BigClockPrefType))
    {
      //old version
      MemPtrUnlock(BCpref);
      DmReleaseRecord(BCdb, 0, false);
      DmResizeRecord(BCdb,0,sizeof(BigClockPrefType));
      InitPref();
      BCprefHandle=DmGetRecord(BCdb,0);
      BCpref=MemHandleLock(BCprefHandle);

      if (DmGetNextDatabaseByTypeCreator (true, &searchInfo,
         'bcal', BCAppID, true, &lNo, &dbID) == 0)
      {
        DmDeleteDatabase(lNo,dbID);
      }
      SetNextAlarm(cardNo,appID);

    } else
    MemMove(&prefs,BCpref,sizeof(BigClockPrefType));
  }
  MemPtrUnlock(BCpref);
  DmReleaseRecord(BCdb, 0, false);
  DmCloseDatabase(BCdb);
  WritePref();
  return true;
}



void CloseAlarm(DmOpenRef BCdb)
{
   DmCloseDatabase(BCdb);
}


DmOpenRef OpenAlarm()
{
  VoidHand  BCalarmHandle;
  BigClockAlarm *BCalarm=NULL;
  UInt          index = 0;
  DmOpenRef BCdb;

  BCdb = DmOpenDatabaseByTypeCreator('bcal', BCAppID, dmModeReadWrite);
  // if database  does not exist create it
  if (!BCdb)
  {

    if (DmCreateDatabase(0, "Alarmlist", BCAppID, 'bcal', false)) return false;
    BCdb = DmOpenDatabaseByTypeCreator('bcal', BCAppID, dmModeReadWrite);


    for (index=0; index<aCount ; index++)
    {
      BCalarmHandle = DmNewRecord(BCdb, &index, sizeof(BigClockAlarm));
      BCalarm = MemHandleLock(BCalarmHandle);
      DmSet(BCalarm, 0, sizeof(BigClockAlarm) , 0);
      MemPtrUnlock(BCalarm);
      DmReleaseRecord(BCdb, index, false);
    }
  }
  return BCdb;
}

 Boolean ReadAlarm(DmOpenRef BCdb,int num,BigClockAlarm *target)
{
  VoidHand  BCalarmHandle;
  BigClockAlarm *BCalarm=NULL;

  BCalarmHandle = DmGetRecord(BCdb, num);

  //old version -> resize
  if (MemHandleSize(BCalarmHandle)<sizeof(BigClockAlarm))
    MemHandleResize(BCalarmHandle,sizeof(BigClockAlarm));

  BCalarm = MemHandleLock(BCalarmHandle);
  MemMove(target,BCalarm,sizeof(BigClockAlarm));

  MemPtrUnlock(BCalarm);
  DmReleaseRecord(BCdb, num, false);
  return true;
}


Boolean WriteAlarm(DmOpenRef BCdb,int num,BigClockAlarm *source)
{
  VoidHand  BCalarmHandle;
  BigClockAlarm *BCalarm=NULL;

  BCalarmHandle = DmGetRecord(BCdb, num);
  if (MemHandleSize(BCalarmHandle)<sizeof(BigClockAlarm))
    MemHandleResize(BCalarmHandle,sizeof(BigClockAlarm));


  BCalarm = MemHandleLock(BCalarmHandle);
  DmWrite(BCalarm,0,source,sizeof(BigClockAlarm));

  MemPtrUnlock(BCalarm);
  DmReleaseRecord(BCdb, num, false);
  return true;
}


void OpenBigBitmaps(void)
{
  int iii;
  int start;

  start=ThemeDef->numbers;
  if (start==0)
    start=7184;

  if ((resdb) || (ThemeDef->numbers==0))
  {
     for (iii=0 ; iii<16 ; iii++)
     {
      bigbitmapH[iii]=DmGetResource('Tbmp',start+iii);
      bigbitmapP[iii]=MemHandleLock(bigbitmapH[iii]);
     }
   }
  else
  {
    for (iii=0 ; iii<16 ; iii++)
     {
       if (DmNumRecords(ThemeDB) > ThemeDef->numbers+iii)
       {
         bigbitmapH[iii]=DmQueryRecord(ThemeDB,ThemeDef->numbers+iii);
         bigbitmapP[iii]=MemHandleLock(bigbitmapH[iii]);
       } else
       {
          bigbitmapH[iii]=DmGetResource('Tbmp',7184+iii);
          bigbitmapP[iii]=MemHandleLock(bigbitmapH[iii]);
       }
     }
  }

}

void CloseBigBitmaps(void)
{
  int iii;

  for (iii=0 ; iii<16 ; iii++)
    MemHandleUnlock(bigbitmapH[iii]);
}

/*
void FreeBigBitmaps(void)
{
  int iii;
  for (iii=0 ; iii<16 ; iii++)
  {
    if (bigbitmapP[iii] != 0)
      BmpDelete(bigbitmapP[iii]);
    bigbitmapP[iii]=NULL;
  }
} */

void SetPageResource(int set,int  num,int hour)
{
  int newid;
  int iii;
  BackgroundInfo *c;

  newid=-1;
  iii=0;
  c=&(ThemeDef->back);



  while ((newid < 0) && (iii<ThemeDef->count))
  {
    if ( ((c->set == set) || (c->set==2)) && ((c->page == num) || (c->page==4)) && (hour >= c->start ) && (hour < c->end))
    {
      newid=c->id;
    }
    iii++;
    c++;
  }
  if (newid < 0)
   newid=0;



  if (newid != BackgroundID)
  {
    changed[0]=1;
    changed[1]=1;

    //if a background is currently used...
    if (BackgroundH != 0)
      //release the handle
      MemHandleUnlock(BackgroundH);
    //use background on this page?
    if (newid != 0)
    {
      //yes, set the background
      if (resdb)
      {
        BackgroundH=DmGetResource('Tbmp',newid);
        Background=MemHandleLock(BackgroundH);
      } else
      {
        BackgroundH=DmQueryRecord(ThemeDB,newid);
        Background=MemHandleLock(BackgroundH);
      }
    } else
    {
      //no, clear background
      BackgroundH=0;
      BackgroundID=0;
      Background=NULL;
    }
    BackgroundID=newid;
  }
}


void OpenTheme(char *name)
{
  LocalID id;
  UInt16  attr;
  VoidHand trgres;
  int     trgmode=0;

  //Voidhand kindh;
  //UInt8 *kind;

  UInt32 version;
  Word x;

#ifdef debug
  debugs("OpenTheme",name);
#endif


  ThemeDB=0;
  resdb=true;
  //use external theme?
  if (StrLen(name) > 0)
  {
#ifdef debug
  debugs("OpenTheme","external theme");
#endif
    id=DmFindDatabase(0,name);
    if (id!=0)
    {
      DmDatabaseInfo(0,id,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
      ThemeDB=DmOpenDatabase(0,id,dmModeReadOnly);
      resdb=(attr & dmHdrAttrResDB);
    }
  }

      if (resdb)
      {
         ThemeDefH=DmGetResource('ctrl',7168);
         ThemeDef=MemHandleLock(ThemeDefH);
         OpenBigBitmaps();
         SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);
      } else
      {
         ThemeDefH=DmQueryRecord(ThemeDB,0);
         ThemeDef=MemHandleLock(ThemeDefH);
         ThemeBonusH=DmQueryRecord(ThemeDB,1);
         ThemeBonus=MemHandleLock(ThemeBonusH);
         OpenBigBitmaps();
         SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);
      }


 if (FtrGet(TRGSysFtrID, TRGVgaFtrNum, &version) == 0)
 {
    if (resdb)
    {
      trgres=DmGetResource('bctt',333);
      if (trgres!=NULL)
        trgmode=1;
      DmReleaseResource(trgres);
    }  else
    {
      if (ThemeBonus->handera !=0)
        trgmode=1;
    }
    //trgmode=1;
    if (trgmode != 0)
    {
      //DmReleaseResource(trgres);
      panelwidth=240;
      panelheight=93;
      screenwidth=240;
      screenheight=320;
      ytop=22;         // upper panel
      ybottom=115;      // lower panel
      VgaSetScreenMode(screenMode1To1,rotateModeNone);
      isTRG=true;
    } else
    {
      isTRG=false;
      VgaSetScreenMode(screenModeScaleToFit,rotateModeNone);
      screenwidth=160;
      screenheight=160;
      panelwidth=160;
      panelheight=62;
      ytop=15;
      ybottom=77;
    }
    FreeRegions();
    if (isTRG)
      InitRegionsStar();
    else
      InitRegions160();


    recreate=true;

    /*
    form=FrmGetActiveForm ();
    if (form != NULL)
    {
      FrmDeleteForm (form);
      form= FrmInitForm (formID_bigclock);
      FrmSetActiveForm (form);
      if (isTRG)
        VgaFrmModify(form,vgaFormModify160To240);
    }
    */
 }

 if (build != NULL)
 {
   WinDeleteWindow(build,true);
 }
 build=WinCreateOffscreenWindow(panelwidth,panelheight,screenFormat,&x);

}

void CloseTheme()
{
  CloseBigBitmaps();

  if (ThemeDefH != 0)
    MemHandleUnlock(ThemeDefH);
  if (!resdb)
    MemHandleUnlock(ThemeBonusH);

  if (BackgroundH != 0)
    MemHandleUnlock(BackgroundH);
  BackgroundH=0;
  BackgroundID=-1;
  if (ThemeDB != 0)
  {
    DmCloseDatabase(ThemeDB);
    ThemeDB=0;
  }
  Background=NULL;
  ThemeDefH=NULL;
}


void FindTRGTheme(UInt32 type,char *name)
{
  int     num;
  DmSearchStateType state;
  UInt16  card;
  LocalID dbid;
  Boolean found;
  int d;
  int  res=0;
  DmOpenRef  TestDB=0;
  UInt16  attr;
  Err       error;


  num=1;
  found=false;
  d=0;

  while ( (!found) &&
          (DmGetNextDatabaseByTypeCreator(num==1,&state,type,BCAppID,false,&card,&dbid) == 0)
        )
  {
    //open the db
    error=DmDatabaseInfo(0,dbid,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
    TestDB=DmOpenDatabase(0,dbid,dmModeReadOnly);


    if (attr & dmHdrAttrResDB)
    {
      res=DmFindResource (TestDB,'bctt',333, NULL);
    } else
    {
      ThemeBonusH=DmQueryRecord(TestDB,1);
      ThemeBonus=MemHandleLock(ThemeBonusH);
      res=ThemeBonus->handera;
      MemHandleUnlock(ThemeBonusH);
      ThemeBonusH=0;
      ThemeBonus=0;
    }


    DmCloseDatabase(TestDB);

    if (res>=0)
    {
      DmDatabaseInfo(card,dbid,name,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
      found=true;
    }
    num++;
  }

}


 int StartApplication(void)
{
  int error;
  int iii;
  int jjj;
  //int num;
  DmOpenRef BCdb=NULL;
  //VoidHand  hbmp;
  //BitmapPtr pbmp;
  //WinHandle oldwin;
  UInt32 version;
  DmSearchStateType stateInfo;
  UInt16            hlpCard;
  LocalID           hlpdbID;
  UInt32            depth;
  //VoidHand         trgres=NULL;
  //LocalID               id;

  error = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romversion);
  //usemidi=(romversion>=0x03003000);
  //usemidi=false;
  is35 = (romversion >= 0x03503000);
  //is35=false;
  isTRG=FtrGet(TRGSysFtrID, TRGVgaFtrNum, &version) == 0;


  //read system configuration
  if (is35)
    {
      WinScreenMode(winScreenModeGetSupportsColor,NULL,NULL,NULL,&iscolor);
      WinScreenMode(winScreenModeGetSupportedDepths,NULL,NULL,&depth,NULL);
#ifdef debug
      debugi("depth before",depth);
      if (isTRG)
        debugs("device","trg"     );

#endif

      if ((depth & 32768) == 32768)
        maxdepth=16;
      else if ((depth & 128) == 128)
        maxdepth=8;
      else if ((depth & 8) == 8)
        maxdepth=4;
      else if ((depth & 2) == 2)
        maxdepth=2;
      else
        maxdepth=1;

      WinScreenMode(winScreenModeGetDefaults,&screenwidth,&screenheight,&startscreendepth,NULL);
#ifdef debug
  debugi("maxdepth after",maxdepth);
  debugi("Screenwidth",screenwidth);
  debugi("Screenheight",screenheight);
  debugi("Start screen mode",startscreendepth);
  debugi("Start screen mode",startscreendepth);
#endif

    }
  else
  {
    screenwidth=160;
    screenheight=160;
    maxdepth=1;
    startscreendepth=1;
    iscolor=false;
  }

  /*
  if (is35)
  {
    if ((id = DmFindDatabase(0, "BigClock")) != 0)
    {
       SysNotifyRegister(0, id, trgNotifySilkEvent, NULL, sysNotifyNormalPriority, NULL);
    }
  } */

  //read preferences
  SysCurAppDatabase(&cardNo, &appID);
  PrefGetPreferences(&SysPref);
  ReadPref();

  //setscreenmode
  if (prefs.screendepth>maxdepth)
    prefs.screendepth=maxdepth;


#ifdef debug
  debugi("Set screen mode",prefs.screendepth);
#endif
  if (is35)
    WinScreenMode(winScreenModeSet,NULL,NULL,&prefs.screendepth,NULL);


  //no theme on TRG?
  if ((StrLen(prefs.theme) == 0) && (isTRG))
  {
     FindTRGTheme('BCth',prefs.theme);
  }

  OpenTheme(prefs.theme);

  if (build == NULL)
    return 1;
  /*
  if (isTRG)
  {
    //check for trg theme
    trgres=DmGetResource('bctt',333);
    if (trgres != NULL)
    {
      DmReleaseResource(trgres);
      panelwidth=240;
      panelheight=93;
      VgaSetScreenMode(screenMode1To1,rotateModeNone);
      ytop=22;         // upper panel
      ybottom=115;      // lower panel
    } else
    {
      isTRG=false;
      screenwidth=160;
      screenheight=160;
    }



  }*/

  //is GotHelp installed and running?
  GotHelp =
    ( (DmGetNextDatabaseByTypeCreator(true, &stateInfo, 'appl', 'pHLP', false, &hlpCard, &hlpdbID) ==errNone) &&
      (FtrGet('pHLP',1000,&version) != ftrErrNoSuchFeature)
    );





  if (prefs.startfirst)
    {
      prefs.mode=0;
      prefs.pageset=0;
    }


  BCdb=OpenAlarm();
  if (BCdb==0) return 1;
  CloseAlarm(BCdb);


  //on this a panel display is created, after that copied to the screen
  //build=WinCreateOffscreenWindow(panelwidth,panelheight,screenFormat,&x);



  //initbigbitmap();

#ifdef debug
  debugs("StartApplication","InitRegion");
#endif
  if (isTRG)
    InitRegionsStar();
  else
    InitRegions160();
#ifdef debug
  debugs("StartApplication","InitRegion done");
#endif



  //init month and weekday strings
  SysCopyStringResource(daystrings,stringID_weekdays);
  SysCopyStringResource(monthstrings,stringID_months);

  iii=0;
  jjj=0;
  day[jjj]=&daystrings[iii];
  while (jjj<6)
  {
    if (daystrings[iii] == 32)
    {
     jjj++;
     daystrings[iii]=0;
     day[jjj]=&daystrings[iii+1];
    }
    iii++;
  }

  iii=0;
  jjj=0;
  month[jjj]=&monthstrings[iii];
  while (jjj<11)
  {
    if (monthstrings[iii] == 32)
    {
     jjj++;
     monthstrings[iii]=0;
     month[jjj]=&monthstrings[iii+1];
    }
    iii++;
  }

  SysCopyStringResource(detailweek,stringID_detailweek);
  SysCopyStringResource(detailday,stringID_detailday);
  SysCopyStringResource(detailhour,stringID_detailhour);

  for (iii=0; iii<4 ; iii++)
    SysCopyStringResource(stimer[iii],stringID_timerstart+iii);

  SysCopyStringResource(salarmmode[0],stringID_alarmmode2);
  SysCopyStringResource(salarmmode[1],stringID_alarmmode3);

  for (iii=0; iii<7 ; iii++)
    SysCopyStringResource(stimermode[iii],stringID_timermode0+iii);

#ifdef debug
  debugs("StartApplication","goto form");
#endif

  FrmGotoForm(formID_bigclock);
  return 0;
}


 void EventLoop(void)
{
  short err;
  int formID;
  FormPtr form;
  EventType event;
  int wait=0;

  do
  {
    EvtGetEvent(&event, wait);
    if (newyeardone==1)
      wait=0;
    else
      wait=10;

    if (SysHandleEvent(&event)) continue;
    if (MenuHandleEvent((void *)0, &event, &err)) continue;

    if (event.eType == frmLoadEvent)
    {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID)
      {
      case formID_bigclock:
        FrmSetEventHandler(form, (FormEventHandlerPtr) bigclock);
         break;
      case formID_layout:
        FrmSetEventHandler(form, (FormEventHandlerPtr) layout);
        break;
      case formID_world:
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionsworld);
        break;
      case formID_global:
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionsglobal);
        break;
      case formID_localtime:
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionslocaltime);
        break;
      case formID_timer:
        ao=false;
        obase=wTimer1;
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionsalarm);
        break;
      case formID_alarm:
        ao=true;
        obase=wAlarm1;
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionsalarm);
        break;
      case formID_sound:
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionssound);
        break;
      case formID_color:
        FrmSetEventHandler(form, (FormEventHandlerPtr) optionscolor);
        break;
      case formID_history:
        FrmSetEventHandler(form, (FormEventHandlerPtr) labelhistory);
        break;

      case formID_newyear:
        FrmSetEventHandler(form, (FormEventHandlerPtr) newyear);
        break;

       default: break;
      }
    }
    FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}

 void StopApplication(void)
{
  //int iii;
  //LocalID          id;

  //if (midilist != NULL)
  //  MemPtrFree(midilist);

  WritePref();

  //WinDeleteWindow(bitmaps,true);
  WinDeleteWindow(build,true);

  if (ThemeDefH!=NULL)
    CloseTheme();

  FreeRegions();

  /*
  if (is35)
    if ((id = DmFindDatabase(0, "BigClock")) != 0)
       SysNotifyUnregister(0, id, trgNotifySilkEvent, sysNotifyNormalPriority);
  */

  FrmCloseAllForms ();
}


void SetPageNames()
{
  FormPtr   form;
  ControlPtr check;
  int iii;

  form = FrmGetActiveForm();

  for (iii=0; iii<4 ; iii++)
  {
    check = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,buttonID_m1+iii));
    CtlSetLabel(check,prefs.pagenames[prefs.pageset][iii]);
  }
}



/*
void DrawSysInfo(int y)
{
  ULong free;
  int id;
  ULong s;
  ULong m;
  char help[16];
  char help2[16];
  MemPtr startPP;
  MemPtr endPP;
  WinHandle wh;
  WinPtr  wp;
  char *screen;
  int iii;
  DWord romversion;
  int error;
  unsigned char *c;


  FntSetFont(0);


  error = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romversion);

  c=(char *)&romversion;
  MyDrawChars("OS:",3,0,y);
  StrCopy(help,"V ");
  iii=*c;
  StrIToA(help2,iii);
  StrCat(help,help2);
  StrCat(help,".");
  c++;
  s=*c;
  StrIToH(help2,s);
  StrCat(help,&help2[6]);
  MyDrawChars(help,StrLen(help),50,y);



  MyDrawChars("Freemem:",8,0,y+1*12);
  MemCardInfo(0,NULL,NULL,NULL,NULL,NULL,NULL,&free);
  StrIToA(help,free);
  MyDrawChars(help,StrLen(help),50,y+1*12);

  MyDrawChars("Dynamic:",8,0,y+2*12);

  id=MemHeapID(0,0);
  if (MemHeapDynamic(id))
  {
    MemHeapFreeBytes(id,&s,&m);
    StrIToA(help,s);
    MyDrawChars(help,StrLen(help),50,y+2*12);
  }
  if (romversion  >= 0x03003000)
  {
      MyDrawChars("Stack:",6,0,y+3*12);
      SysGetStackInfo(&startPP,&endPP);
      StrIToA(help,(Long)endPP-(Long)startPP);
      MyDrawChars(help,StrLen(help),50,y+3*12);
  }

}*/


void IdleDrawSection(int val,int y,int up)
{
  if (changed[up] != 0)
  {
    SwitchDrawSection(val,y,false);
    changed[up]=0;
  }
}


int checkchanged(int pan)
{
  int r=0;

  switch (pan)
  {
    case pnDate :
    case pnMonth :
       if (prefs.world[0].options.daychanged == 1)
         r=1;
      break;

    case pnAlarm:
    case pnTime :
    case pnWorld :
    case pnDateD :
    case pnAnalog :
    case pnTimer :
    case pnCTimer :
    case pnVTimer :
      r=1;
      break;
  }
  return r;
}

int UpdateTimes()
{
  int iii;
  int n;
  Long now;
  Long add;
  DateTimeType last;
  BigClockTime *bct;
  int result=0;

  now=TimGetSeconds();

  TimSecondsToDateTime(now,&Time[0]);
  TimAdjust(&Time[0],prefs.world[0].value);

  TimSecondsToDateTime(prefs.world[0].last,&last);
  if (
       (last.year != Time[0].year) ||
       (last.month != Time[0].month) ||
       (last.day != Time[0].day)
      )
    prefs.world[0].options.daychanged=1;
  else
    prefs.world[0].options.daychanged=0;

  if (last.hour != Time[0].hour)
    SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);


  for (iii=0 ; iii<4 ; iii++)
  {
    //adjust time
    Time[iii+1]=Time[0];
    TimAdjust(&Time[iii+1],prefs.world[iii+1].value);

    TimSecondsToDateTime(prefs.world[iii+1].last,&last);
    if (
         (last.year != Time[iii+1].year) ||
         (last.month != Time[iii+1].month) ||
         (last.day != Time[iii+1].day)
      )
      prefs.world[iii+1].options.daychanged=1;
    else
      prefs.world[iii+1].options.daychanged=0;


    prefs.world[iii+1].last=TimDateTimeToSeconds(&Time[iii+1]);


    bct=&prefs.world[wTimer1+iii];
    //adjust timers
    if (bct->options.active)
    {
      if (bct->options.daterelative==0)
      {
        if (bct->last !=0)
        {
          add=now-bct->last;
          bct->last=now;
        } else
        {
          add=1;
          bct->last=now;
        }

        if (bct->options.timerup == 0)
          add=-add;


        bct->value=bct->value+add;
      } else
      {
        bct->value=now-bct->date;
        if (bct->value < 0)
        {
          bct->value=-bct->value;
          if ( bct->options.timerup!=0)
          {
             bct->options.timerup=0;
             result=2;
          }
        }  else
        {
          if (bct->options.timerup != 1 )
          {
            bct->options.timerup=1;
            result=2;
          }
        }
      } // else date relative

      if (bct->value<0)
      {
        if ((bct->options.mode < 5) && (bct->options.mode!=2) && (bct->options.mode!=4))
          bct->value=0;
        add=0;
      }

      if ((bct->value<=0) && (bct->options.timerup == 0) /*(add<=0)*/)
      {
        if ((bct->options.mode==2) || (bct->options.mode==4))
        {
          while (bct->value <= 0)
            bct->value+=bct->reset;
        }
        else if ((bct->options.mode>0) && (bct->options.mode < 5))
          bct->value=bct->reset;
        if ((bct->options.mode != 2) && (bct->options.mode < 4))
          bct->options.active=0;
        if (bct->options.mode == 4)
          UpdateTimer(wTimer1+iii);
        if (bct->options.mode >= 5)
        {
          bct->value=-bct->value;
          bct->options.timerup=1;
        }
        //SetNextAlarm(cardNo,appID);

        prefs.world[0].last=now;
        SwitchDrawSection(prefs.pages[prefs.pageset][prefs.mode*2],ytop,true);
        SwitchDrawSection(prefs.pages[prefs.pageset][prefs.mode*2+1],ybottom,true);
        return 0;
      }
    }
  }

  if (
       (Time[0].month==1) &&
       (Time[0].day==1) &&
       (Time[0].hour==0) &&
       (Time[0].minute==0)
      )
  {
    if (newyeardone==0)
      FrmGotoForm(formID_newyear);
  }


  if (prefs.world[0].last != now )
  {
    prefs.world[0].last=now;
    result++;

    //does panel require update?
    n=checkchanged((prefs.pages[prefs.pageset][prefs.mode*2]) >> 3);
    if (n>0)
      changed[0]=n;
    n=checkchanged((prefs.pages[prefs.pageset][prefs.mode*2+1]) >> 3);
    if (n>0)
      changed[1]=n;
  }
  return result;
}


void SwitchDraw()
{
  UpdateTimes();

  SwitchDrawSection(prefs.pages[prefs.pageset][prefs.mode*2],ytop,true);
  SwitchDrawSection(prefs.pages[prefs.pageset][prefs.mode*2+1],ybottom,true);
}

void DrawCaptionTime()
{
  char text[30];
  RectangleType rc = {{115,0},{45,12}};
  int w;

  if (isTRG)
  {
    rc.topLeft.x=screenwidth-70;
    rc.extent.x=70;
    rc.extent.y=18;
  }

  TimeToAscii(Time[0].hour,Time[0].minute,SysPref.timeFormat,text);
  MySetFont(1);

  if (is35)
  {
    WinSetForeColor(UIColorGetTableEntryIndex(UIFormFill));
    WinSetBackColor(UIColorGetTableEntryIndex(UIFormFill));
    WinSetTextColor(UIColorGetTableEntryIndex(UIFieldText));
  }

  WinEraseRectangle(&rc,0);
  w=FntCharsWidth(text,StrLen(text));
  WinDrawChars(text,StrLen(text),screenwidth-w,1);
}

void IdleDraw()
{
  int n;

  n=UpdateTimes();
  if (n>0)
  {
   #ifdef debug
     debugs("idledraw","draw caption time");
   #endif

    DrawCaptionTime();
    if (n>1)
      SwitchDraw();
    else
      {
        IdleDrawSection(prefs.pages[prefs.pageset][prefs.mode*2],ytop,0);
        IdleDrawSection(prefs.pages[prefs.pageset][prefs.mode*2+1],ybottom,1);
      }
  }
}

void ChangeDays(int num, int d)
{
  unsigned char b;
  if (prefs.world[num].options.trigger==1)
  {
    b=prefs.world[num].days;
    b=b ^ ( 1 << ((d+SysPref.weekStartDay) % 7));
    prefs.world[num].days=b;
  }

}

void ChangeCalcTimer(int num , int id)
{
  long add=0;
  Boolean up;


  up=(id < 6);
  if (!up)
    id -=5;


  switch (id)
  {
    case 0: add=(long)3600 / (long)prefs.world[num].calc;
            break;
    case 1: add=(long)36000 / (long)prefs.world[num].calc ;
            break;
    case 2: add=(long)360000 / (long)prefs.world[num].calc;
            break;
    case 3: add=(long)3600000 / (long)prefs.world[num].calc;
            break;
    case 4: add=(long)36000000 / (long)prefs.world[num].calc;
            break;
    case 5: add=(long)360000000 / (long)prefs.world[num].calc;
            break;
  }

  if (!up)
    add=-add;

  prefs.world[num].value=prefs.world[num].value+add;//TimDateTimeToSeconds(&temp);
  if (prefs.world[num].value<0)
    prefs.world[num].value=0;
}


/*
//for debugging
void Showdate(char *name,unsigned long d)
{
  DateTimeType s;
  char h1[32];
  char h2[32];

  TimSecondsToDateTime(d,&s);
  DateToAscii(s.month,s.day,s.year,dfDMYWithDots,h1);
  TimeToAscii(s.hour,s.minute,false,h2);
  FrmCustomAlert(alertID_text3,name,h1,h2);
};*/


void SetNextAlarm(UInt cno,LocalID aid)
{
  unsigned long as;
  unsigned long now;
  unsigned long al;
  DateTimeType d;
  int num;
  BigClockAlarm *alarm;
  int iii;
  DmOpenRef BCdb=NULL;
  Boolean wakeup;


  alarm=MemPtrNew(sizeof(BigClockAlarm));


  wakeup=false;
  BCdb=OpenAlarm();

  as=0;
  now=TimGetSeconds();
  num=-1;

  for (iii=0; iii<aCount; iii++)
  {
    ReadAlarm(BCdb,iii,alarm);

    if ((alarm->options.active) || (alarm->snoozecurrent > 0))
    {
      if (alarm->snoozecurrent > 0 )
      {
        al=alarm->snoozeoffset;
      } else
      {
        //set now,d to worldtime of alarm
        now=TimGetSeconds();
        TimSecondsToDateTime(now,&d);
        if (alarm->options.trigger !=3)
          TimAdjust(&d,alarm->worldoffset);
        now=TimDateTimeToSeconds(&d);

        al=0;
        wakeup=false;

        if ((alarm->days<128) && (alarm->days>0))
        {
          //normal alarm
          d.hour=alarm->time.hour;
          d.minute=alarm->time.minute;
          d.second=0;
          al=TimDateTimeToSeconds(&d);


          while (
                 ( (alarm->days & ( 1 << d.weekDay)) == 0 ) ||
                   ( al <= now)
                 )
          {
            al+=daysInSeconds;
            TimSecondsToDateTime(al,&d);
          }

          //adjust alarm time to local time
          if (alarm->options.trigger !=3)
            TimAdjust(&d,-alarm->worldoffset);
          al=TimDateTimeToSeconds(&d);
          //Showdate("alarm adjusted",al);


        } else if (alarm->days>=128)
        {
          if (alarm->options.trigger != 3)
          {
             //timer alarm
             al=TimDateTimeToSeconds(&(alarm->time));
             if (al > (now+60))
             {
               al-=60;
               wakeup=true;
             }
          }
          else
            {
              //chime
              if (( TimDateTimeToSeconds(&alarm->time) % daysInSeconds) != 0)
              {
                al=now / ( TimDateTimeToSeconds(&alarm->time) % daysInSeconds);
                al=(al + 1) * (TimDateTimeToSeconds(&alarm->time) % daysInSeconds);

                //adjust to local time
                TimSecondsToDateTime(al,&d);
                if (alarm->options.trigger !=3)
                  TimAdjust(&d,-alarm->worldoffset);
                al=TimDateTimeToSeconds(&d);
              } else
                al=0;
            }
        }
      }

      //set now to local time
      now=TimGetSeconds();

      if (
           (
            ( al>(now+1)) &&

            (
               (al<as) ||
               (as==0)
            )
           ) ||
           (
            ( al>(now+1)) &&
            ( alarm->options.trigger != 3) &&
            (
               (al<=as) ||
               (as==0)
            )
           )
         )
        {

          as=al;
          if (wakeup)
            num=-2;
          else
            num=iii;

        }
    }
  }


  if (num==-1)
    as=0;
  CloseAlarm(BCdb);

  AlmSetAlarm(cno,aid,num,as,false);

  MemPtrFree(alarm);

}

void SetSound(int a,int w)
{
  if ((w>=0) && (w<=3))
  {
    prefs.world[a].options.sound=w;
  }
}


void UpdateAlarm(int num)
{
  BigClockAlarm alarm;
  DmOpenRef BCdb=NULL;

  BCdb=OpenAlarm();

  ReadAlarm(BCdb,num-5,&alarm);

  TimSecondsToDateTime(prefs.world[num].value,&alarm.time);

  alarm.options=prefs.world[num].options;
  alarm.options.ignoresystemsoundoff=prefs.ignoresystemsoundoff;
  alarm.sound=prefs.sounds[prefs.world[num].options.sound];
  alarm.snoozecurrent=0;
  alarm.snoozecount=prefs.world[num].snoozecount;
  alarm.snoozetime=prefs.world[num].snoozetime;

  StrCopy(alarm.name,prefs.world[num].name);
  StrCopy(alarm.worldname,prefs.world[prefs.world[num].options.base].name);
  alarm.worldoffset=prefs.world[prefs.world[num].options.base].value;
  if (alarm.options.trigger==1)
    alarm.days=prefs.world[num].days;
  else if (alarm.options.trigger==0)
    alarm.days=127;
  else if (alarm.options.trigger==2)
    alarm.days=127;
  else if (alarm.options.trigger==3)
    alarm.days=128;

  WriteAlarm(BCdb,num-5,&alarm);
  CloseAlarm(BCdb);
}

void ToggleAlarm(int num)
{
  prefs.world[num].options.active = inot[prefs.world[num].options.active];
  UpdateAlarm(num);
  SetNextAlarm(cardNo,appID);
}

Boolean SetTime(int num,UInt8 id,Boolean under)
{
  const long off[19] = {0,                               // dummy
                        1,                               // 1s
                        10,                              // 10s
                        hoursInSeconds /60,              // 1m
                        hoursInSeconds /6,               // 10m
                        hoursInSeconds,                  // 1h
                        (long)hoursInSeconds*10,         // 10h
                        (long)hoursInSeconds*12,         // 12h
                        (long)hoursInSeconds*24,         // 1d
                        (long)hoursInSeconds*240,        // 10d
                       -1,                               // 1s
                       -10,                              // 10s
                       -hoursInSeconds /60,              // 1m
                       -hoursInSeconds /6,               // 10m
                       -hoursInSeconds,                  // 1h
                       -(long)hoursInSeconds*10,         // 10h
                       -(long)hoursInSeconds*12,         // 12h
                       -(long)hoursInSeconds*24,         // 1d
                       -(long)hoursInSeconds*240         // 10d
                       };

  if (prefs.world[num].options.active==0)
  {
    prefs.world[num].value+=off[id];
    if ((!under) && (prefs.world[num].value < 0))
      prefs.world[num].value=0;
    return true;
  }
  return false;
}


Boolean SetTimer(int num, int id,int drawpage)
{
  long    dummy;
  Boolean b;
  int iii,kkk;

  b=false;
  if (id<20)
  {
    if (prefs.world[num].options.calc)
    {
      ChangeCalcTimer(num ,id);
      b=true;
    }
    else
    {
      dummy=prefs.world[num].value / ((long)hoursInSeconds);
      if ( dummy >= 24)
      {
        id+=2;
        if ((id==7) || (id==8) || (id==16) || (id==17))
          id++;
      }
      b=SetTime(num,id,false);
    }


    prefs.world[num].reset=prefs.world[num].value;
  } else if (id==regLabel)
  {
    //label
    historymode=num;
    FrmPopupForm(formID_history);
  } else if (id==regTimerToggle)
  {
     if (!prefs.locktimer)
     {
       iii=prefs.pages[prefs.pageset][drawpage];
       kkk= iii & 7;
       prefs.pages[prefs.pageset][drawpage]=(pnCTimer << 3)+kkk;
       b=true;
     }
  }

  return b;
}



Boolean SetAlarm(int num, int id)
{
  Boolean b;

  b=true;
  if (id==20)
  {
    //checkbox
    ToggleAlarm(num);
    b=true;
  } else if  (prefs.world[num].options.active==0)
  {
   if (id==regLabel)
    {
      //label
      historymode=num;
      FrmPopupForm(formID_history);
      b=false;
    } else if ((id>=30) && (id<=37))
    {
      //days
      ChangeDays(num,id-30);
    } else if ((id>=40) && (id<=44))
    {
      SetSound(num,id-40);

    } else
    {
      //numbers & am/pm
      SetTime(num,id,false);
    }
  }  

  return b;
}



void UpdateTimer(int num)
{
  BigClockAlarm alarm;
  DmOpenRef BCdb=NULL;

  BCdb=OpenAlarm();
  ReadAlarm(BCdb,num-5,&alarm);

  //is timermode with alarm?
  if (
       (prefs.world[num].options.mode>=3) &&
       (prefs.world[num].options.mode!=5) &&
       ((prefs.world[num].options.timerup==0) || (prefs.world[num].options.daterelative==1))
     )
     {
       alarm.days=128;
       alarm.sound=prefs.sounds[prefs.world[num].options.sound];
       alarm.options=prefs.world[num].options;
       alarm.options.ignoresystemsoundoff=prefs.ignoresystemsoundoff;
       alarm.snoozetime=prefs.world[num].snoozetime;
       alarm.snoozecount=prefs.world[num].snoozecount;
       alarm.snoozecurrent=0;

       StrCopy(alarm.name,prefs.world[num].name);

       if (prefs.world[num].options.daterelative==1)
       {
         TimSecondsToDateTime(prefs.world[num].date,&alarm.time);
       } else
       {
         //set alarm.time to date/time of the alarm

         // .last set to timgetseconds (=now) in controltap
         TimSecondsToDateTime(prefs.world[num].last,&alarm.time);
         // add timer value to now
         TimAdjust(&alarm.time,prefs.world[num].value);
       }
    } // active alarm
  else
     {
      alarm.options.active=0;
     }

  WriteAlarm(BCdb,num-5,&alarm);
  CloseAlarm(BCdb);

}



Boolean ControlTap(int num, int id,int drawpage)
{
  int iii,kkk;
  //Boolean b;

  timercommand=0;

  if (id==regTimerStart)
  {
    if (prefs.world[num].options.active==1)
    {
      prefs.world[num].options.active=0;
    } else
    {
      prefs.world[num].options.active=1;
      prefs.world[num].last=TimGetSeconds();
    }
    if ((prefs.world[num].options.alternate==1) && (prefs.world[num].options.active==1))
    {
      //chess mode
      iii=wTimer1;
      if (num==wTimer1) iii=wTimer2;
      else if (num==wTimer2) iii=wTimer1;
      else if (num==wTimer3) iii=wTimer4;
      else if (num==wTimer4) iii=wTimer3;
      prefs.world[iii].options.active=0;
      UpdateTimer(iii);
    }


    UpdateTimer(num);
    SetNextAlarm(cardNo,appID);
  } else if (prefs.world[num].options.active==0)
  {
    if (id==regTimerReset)
      timercommand=1+10*num;
    else if (id==regTimerClear)
      timercommand=2+10*num;
    else if (id==regTimerUp)
      prefs.world[num].options.timerup=1;
    else if (id==regTimerDown)
      prefs.world[num].options.timerup=0;
    else if (id>=40)
      prefs.world[num].options.sound=id-40;
    else if (id==regTimerToggle)
    {
      iii=prefs.pages[prefs.pageset][drawpage];
      kkk= iii & 7;
      prefs.pages[prefs.pageset][drawpage]=(pnTimer << 3)+kkk;
    }
  }
  if (id==regLabel)
  {
    historymode=num;
    FrmPopupForm(formID_history);
  }
  return true;
}

Boolean ChangeMonthOffset(int num,int i)
{
  prefs.world[num].monthoffset+=i;
  return true;
}

Boolean SectionPenUp(int val)
{
  unsigned char pan;
  unsigned char num;

  pan=val >> 3;
  num= val & 7;


  if (timercommand>0)
  {

    if (timercommand==2+10*(wTimer1+num))
    {
      prefs.world[wTimer1+num].value=0;
    } else if (timercommand==(1+10*(wTimer1+num)))
    {
      prefs.world[wTimer1+num].value=prefs.world[wTimer1+num].reset;
      if (prefs.world[wTimer1+num].options.mode > 4)
      {
        prefs.world[wTimer1+num].options.timerup=0;
      }
    }
    //changed[0]=1;
    //changed[1]=1;
    SwitchDraw();
  } else
    return false;
  return true;
}


Boolean SectionPenDown(int val, int x,int y,int drawpage)
{
  UInt8 id;
  UInt8 sub;
  Boolean b;
  unsigned char pan;
  unsigned char num;

  if (val>=0)
  {
    pan=val >> 3;
    num= val & 7;
  }  else
  {
    pan=255;
    num=0;
  }

  b=false;
  switch (pan)
  {
    case 255:   if (prefs.world[0].options.ampm==0)
                 sub=3; // 1+2
               else
                 sub=19; // 1+2+16
                id=RegionTap(x,y,pnTime,sub);
                b=SetTime(0,id,true);
             break;
    case pnTime: {
                   if (prefs.world[wLocal+num].options.seconds!=0)
                   {
                     if (prefs.world[wLocal+num].options.ampm==0)
                       sub=3; // 1+2
                     else
                       sub=19; // 1+2+16
                   }
                   else
                   { if (prefs.world[wLocal+num].options.ampm==0)
                       sub=4; //4
                     else
                       sub=9; // 1+8
                   }
                   id=RegionTap(x,y,pnTime,sub);
                   b=SetTime(wLocal+num,id,true);
                   break;
                 }
    case pnAlarm: {
                    if (prefs.world[wAlarm1+num].options.ampm==0)
                       sub=1;
                     else
                       sub=3; //1+2
                    id=RegionTap(x,y,pnAlarm,sub);
                    b=SetAlarm(wAlarm1+num, id);
              break;
            }
    case pnTimer:  {
                     if (prefs.world[wTimer1+num].options.calc)
                       sub=6;  //2+4
                     else
                       sub=5;  //1+4
                     id=RegionTap(x,y,pnTimer,sub);
                     b=SetTimer(wTimer1+num,id,drawpage);
               break;
             }
    case pnCTimer:  {
                      sub=6;
                      id=RegionTap(x,y,pnControl,sub);
                      b=ControlTap(wTimer1+num,id,drawpage);
               break;
             }
    case pnControl: {
                      sub=3;
                      id=RegionTap(x,y,pnControl,sub);
                      b=ControlTap(wTimer1+num,id,drawpage);
                 break;
              }
    case pnMonth:  {
                      sub=1;
                      id=RegionTap(x,y,pnMonth,sub);
                      if (id==regMonthLeft)
                        b=ChangeMonthOffset(wLocal+num,-1);
                      else if (id==regMonthRight)
                        b=ChangeMonthOffset(wLocal+num,1);
                      else if (id==regMonthDate)
                      {
                        prefs.world[wLocal+num].monthoffset=0;
                        b=true;
                      }
               break;
             }
  }

  return b;
}


 Boolean bigclock(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  Word      w1;
  Word      w2;
  Boolean   b;
  char      menutext[16];

  //FntSetFont(0);
  //WinDrawChars(help,StrLen(help),0,0);

  if (recreate)
  {
    form=FrmGetActiveForm ();
    if (form != NULL)
    {
      FrmDeleteForm (form);
      form= FrmInitForm (formID_bigclock);
      FrmSetActiveForm (form);
      recreate=false;
      FrmSetEventHandler(form, (FormEventHandlerPtr) bigclock);
      event->eType=frmOpenEvent;
      if (isTRG)
      {
        VgaFrmModify(form,vgaFormModify160To240);
        ResizeForm();
      }
    }
  }


  switch (event->eType)
  {
  case frmOpenEvent:
     if (isTRG)
     {
        ResizeForm();
     }
#ifdef debug
  debugs("bigclock","open form");
#endif

    form = FrmGetActiveForm();

#ifdef debug
  debugs("bigclock","draw form");
#endif

    FrmDrawForm(form);
    //page=3;


    SetPageNames();
    CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+prefs.mode)),1);
    CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_pageset1+prefs.pageset)),1);

    UpdateTimes();
    SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);
    //FrmCustomAlert(alertID_text,"B",NULL,NULL);

    SwitchDraw();

    DrawCaptionTime();

    if (isTRG)
      if (! SilkWindowMaximized())
      {
        DrawSilk();
      }  

    running=true;
    handled = 1;
#ifdef debug
  debugs("bigclock","openform done");
#endif
    break;
  case displayExtentChangedEvent:
         {
           ResizeForm();
           if (! SilkWindowMaximized())
             DrawSilk();
           handled = 1;
         }
  case menuOpenEvent:
      if (is35)
      {
        SysCopyStringResource(menutext,stringID_colormenu);
        //MenuAddItem ( menuitemID_layout, menuitemID_color,'C', "Color...");
        MenuAddItem ( menuitemID_layout, menuitemID_color,'C', menutext);
      }
    break;
  case frmUpdateEvent:
    form = FrmGetActiveForm();
    FrmDrawForm(form);
    SwitchDraw();
    handled=1;
    break;
  case menuEvent:
    switch (event->data.menu.itemID)
    {
    case menuitemID_about:
      FrmAlert(alertID_info);
      break;
    case menuitemID_help:
        FrmHelp(stringID_help);
      break;
    case menuitemID_layout:
        FrmPopupForm(formID_layout);
        handled=1;
      break;
    case menuitemID_localtime:
        FrmPopupForm(formID_localtime);
        handled=1;
      break;
    case menuitemID_world:
        FrmPopupForm(formID_world);
        handled=1;
      break;
    case menuitemID_global:
        FrmPopupForm(formID_global);
        handled=1;
      break;
    case menuitemID_alarm:
        FrmPopupForm(formID_alarm);
        handled=1;
      break;
    case menuitemID_timer:
        FrmPopupForm(formID_timer);
        handled=1;
      break;
    case menuitemID_sounds:
        obase=0;
        FrmPopupForm(formID_sound);
        handled=1;
      break;
    case menuitemID_color:
        FrmPopupForm(formID_color);
        handled=1;
      break;
   case menuitemID_reset:
        if (FrmAlert(formID_sure)==0)
          ResetData();
        handled=1;
      break;
    }
    handled = 1;
    break;

  case ctlSelectEvent:
   if ( (event->data.ctlEnter.controlID <= buttonID_m4) &&
        (event->data.ctlEnter.controlID >= buttonID_m1))
   {
     prefs.mode= event->data.ctlEnter.controlID - buttonID_m1;
     SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);
     SwitchDraw();
     //handled = 1;
   } else if ( (event->data.ctlEnter.controlID <= buttonID_pageset2) &&
        (event->data.ctlEnter.controlID >= buttonID_pageset1))
   {
     prefs.pageset=event->data.ctlEnter.controlID-buttonID_pageset1;
     SetPageResource(prefs.pageset,prefs.mode,Time[0].hour);
     SwitchDraw();
     SetPageNames();
   }
   break;

  case keyDownEvent:
   form= FrmGetActiveForm ();

   if (prefs.hardwarebuttons)
   {
     if (event->data.keyDown.chr  == pageUpChr)
     {
       ControlTap(5, regTimerStart,-1);
       SwitchDraw();
     } else if (event->data.keyDown.chr == pageDownChr)
     {
       if (prefs.world[5].options.active==1)
       {
         ControlTap(5, regTimerStart,-1);
       }  else
       {
         timercommand=1+(10*wTimer1);
         SectionPenUp(16);
         timercommand=0;
       }
       SwitchDraw();
     }

   } else
   {
     CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+prefs.mode)),0);
     if (event->data.keyDown.chr  == pageUpChr)
       {
        if (prefs.mode<3)
          prefs.mode++;
        else prefs.mode=0;
        SwitchDraw();
        handled = 1;
       }
     else if (event->data.keyDown.chr == pageDownChr)
       {
        if (prefs.mode>0)
          prefs.mode--;
        else prefs.mode=3;
        SwitchDraw();
        handled = 1;
       }
      CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+prefs.mode)),1);
    }
    break;
  case penDownEvent:
    if ( (event->screenY >=ytop) && (event->screenY <=(ybottom+panelheight) ))
    {
      if (event->screenY >=ybottom)
          b=SectionPenDown(prefs.pages[prefs.pageset][prefs.mode*2+1],event->screenX,event->screenY-ybottom,prefs.mode*2+1);
      else
          b=SectionPenDown(prefs.pages[prefs.pageset][prefs.mode*2],event->screenX,event->screenY-ytop,prefs.mode*2);
      if (b)
        SwitchDraw();
    } else
    {
      if (isTRG)
      {
        if (event->screenY > 240)
        {
          if (event->screenX < 79)
            prefs.monthadd--;
          else if (event->screenX < 161)
            prefs.monthadd=0;
          else
            prefs.monthadd++;
          DrawSilk();
        }
      }
    }
    break;
  case penUpEvent:
    if (event->screenY >=ybottom)
      b=SectionPenUp(prefs.pages[prefs.pageset][prefs.mode*2+1]);
    else
      b=SectionPenUp(prefs.pages[prefs.pageset][prefs.mode*2]);
    timercommand=0;
    if (b)
      SwitchDraw();

    break;
  case winEnterEvent:
     page=3;
     //if ((isTRG) && (screenChanged && (FrmGetActiveFormID() == formID_bigclock)))
     //   ResizeForm(true);

  case nilEvent:
    //reduce startup flicker
    if (running)
    {
      WinGetWindowExtent(&w1,&w2);
      if ((w1==screenwidth) /*&& (w2==screenwidth)*/)
        IdleDraw();
      handled = 1;
    }
    break;
    default: break;
  }


  return handled;
}


void SetLayoutLabels()
{
  FormPtr   form;
  ListPtr    list;
  CharPtr    listItem;
  ControlPtr popup;
  int iii;
  unsigned char val;
  unsigned char pan;
  unsigned char num;

  form = FrmGetActiveForm();

  for (iii=0; iii<4 ; iii++)
    SetFieldText(editID_time+iii,prefs.pagenames[prefs.pageset][iii], 9);

  for (iii=0; iii<8; iii++)
  {
    val=prefs.pages[prefs.pageset][iii];
    pan=val >> 3;
    num=val & 7;

    list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_paneltypes));
    listItem = LstGetSelectionText(list, pan);
    if(!listItem) listItem = "?";
    popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_panel11g+iii));
    CategorySetTriggerLabel(popup, listItem);

    list=NULL;
    switch (pan)
    {
      case pnDate: case pnTime: case pnDateD: case pnMonth: case pnAnalog: /*case pnAnalogU: case pnAnalogL:*/{
          list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_timelist));
          break;
          }
      case pnAlarm: case pnTimer: case pnControl: case pnVTimer: case pnCTimer:{
          list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_alarmlist));
          break;
          }
      case pnWorld:  {
          list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_worldlist));
          break;
          }
      default: break;

    }
    if (list != NULL)
    {
     listItem = LstGetSelectionText(list, num);
      if(!listItem) listItem = "?";
      popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_panel11t+iii));
      CategorySetTriggerLabel(popup, listItem);
    }

    switch (pan)
    {
      case pnEmpty:  {
                 HideEdit(popupID_panel11t+iii);
                 HideEdit(checkboxID_time1a+iii);
                 HideEdit(checkboxID_time1b+iii);
                 break;
              }
      case pnTime: case pnAnalog: {
                 SetCheckBox(checkboxID_time1a+iii,prefs.world[wLocal+num].options.seconds==1);
                 ShowEdit(checkboxID_time1a+iii);
                 SetCheckBox(checkboxID_time1b+iii,prefs.world[wLocal+num].options.ampm!=1);
                 ShowEdit(checkboxID_time1b+iii);
                 ShowEdit(popupID_panel11t+iii);
                 break;
              }
      case pnMonth: case pnDate: case pnDateD: case pnTimer: case pnCTimer: case pnVTimer: case pnWorld: {
                 HideEdit(checkboxID_time1a+iii);
                 HideEdit(checkboxID_time1b+iii);
                 ShowEdit(popupID_panel11t+iii);
                 break;
              }
      case pnAlarm:{
               HideEdit(checkboxID_time1a+iii);
               SetCheckBox(checkboxID_time1b+iii,prefs.world[wAlarm1+num].options.ampm != 1);
               ShowEdit(checkboxID_time1b+iii);
               ShowEdit(popupID_panel11t+iii);
               break;
             }
   /*
      case pnAnalog: {
              SetCheckBox(checkboxID_time1a+iii,prefs.world[wLocal+num].options.seconds==1);
              ShowEdit(checkboxID_time1a+iii);
              HideEdit(checkboxID_time1b+iii);
              ShowEdit(popupID_panel11t+iii);
              break;
            }
    */        
      default:  {
                   HideEdit(checkboxID_time1a+iii);
                   HideEdit(checkboxID_time1b+iii);
                   break;
                }
    }
  }
}


void InfoIconDraw(int i)
{
  MemHandle  imageH;
  BitmapPtr  imageP;


  imageH=DmGetResource('Tbmp', bitmapID_infoicon+i);
  imageP = MemHandleLock(imageH);

  if (is35)
  {
    WinSetForeColor(UIColorGetTableEntryIndex(UIDialogFrame));
    WinSetBackColor(UIColorGetTableEntryIndex(UIDialogFill));
  }

  WinDrawBitmap(imageP, 144, 0);

  MemHandleUnlock(imageH);
  DmReleaseResource(imageH);
}


 Boolean layout(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  int       index;
  ListPtr   ListP;
  int iii;
  int num;
  unsigned char val;

  switch (event->eType)
  {
  case frmOpenEvent:
    form = FrmGetActiveForm();
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }

    SetLayoutLabels();
    FrmDrawForm(form);
    page=1;
    handled = 1;
    break;


 case ctlSelectEvent:
   if (event->data.ctlEnter.controlID == buttonID_ok)
   {
     for (iii=0; iii<4 ; iii++)
       GetFieldText(editID_time+iii,prefs.pagenames[prefs.pageset][iii]);
     changed[0]=1;
     changed[1]=1;
     FrmReturnToForm(formID_bigclock);
     SetPageNames();

     handled = 1;
   } else if (
               (event->data.ctlEnter.controlID >= popupID_panel11g) &&
               (event->data.ctlEnter.controlID <= popupID_panel42g)
             )
   {
     form = FrmGetActiveForm();
     index = FrmGetObjectIndex(form, popuplistID_paneltypes);
     ListP = FrmGetObjectPtr(form, index);
     num=event->data.ctlEnter.controlID-popupID_panel11g;
     LstSetPosition(ListP,0,13+(num/2)*34+(num % 2) * 11);

     val=(prefs.pages[prefs.pageset][num]);
     LstSetSelection(ListP,val >> 3);
     iii=LstPopupList(ListP);
     if (iii != -1)
     {
       val= (iii << 3);
       prefs.pages[prefs.pageset][num]=val;
     }
     SetLayoutLabels();
   } else if (
               (event->data.ctlEnter.controlID >= popupID_panel11t) &&
               (event->data.ctlEnter.controlID <= popupID_panel42t)
             )
   {
     form = FrmGetActiveForm();

     num=event->data.ctlEnter.controlID-popupID_panel11t;
     val=(prefs.pages[prefs.pageset][num]);
     index=-1;
     iii=-1;

     switch (val >> 3)
     {
      case pnDate: case pnTime: case pnDateD: case pnMonth: case pnAnalog: {
          index=FrmGetObjectIndex(form, popuplistID_timelist);
          break;
          }
      case pnAlarm: case pnTimer: case pnControl: case pnVTimer: case pnCTimer:{
          index=FrmGetObjectIndex(form, popuplistID_alarmlist);
          break;
          }
      case pnWorld:  {
          index=FrmGetObjectIndex(form, popuplistID_worldlist);
          break;
          }
     }

     if (index>0)
     {
       ListP = FrmGetObjectPtr(form, index);
       LstSetPosition(ListP,50,13+(num/2)*34+(num % 2) * 11);

       LstSetSelection(ListP,val & 7);

       iii=LstPopupList(ListP);
     }
     if (iii != -1)
     {
       val= (val & 248) + iii;
       prefs.pages[prefs.pageset][num]=val;
     }
     SetLayoutLabels();
   } else if (
               (event->data.ctlEnter.controlID >= checkboxID_time1a) &&
               (event->data.ctlEnter.controlID <= checkboxID_timer2a)
             )
   {
       val=prefs.pages[prefs.pageset][event->data.ctlEnter.controlID-checkboxID_time1a];
       num=val >> 3;
       iii= val & 7;
       switch (num)
       {
         case pnTime: case pnAnalog: {
                   prefs.world[wLocal+iii].options.seconds=GetCheckBox(event->data.ctlEnter.controlID);
                   break;
                 }
       }
      SetLayoutLabels();
   } else if (
               (event->data.ctlEnter.controlID >= checkboxID_time1b) &&
               (event->data.ctlEnter.controlID <= checkboxID_timer2b)
             )
   {
       val=prefs.pages[prefs.pageset][event->data.ctlEnter.controlID-checkboxID_time1b];
       num=val >> 3;
       iii= val & 7;
       switch (num)
       {
         case pnTime: case pnAnalog : {
                    prefs.world[wLocal+iii].options.ampm= ! GetCheckBox(event->data.ctlEnter.controlID);
                    break;
                  }
         case pnAlarm:  {
                   prefs.world[wAlarm1 + iii].options.ampm= ! GetCheckBox(event->data.ctlEnter.controlID);
                    break;
                 }
       }
      SetLayoutLabels();
   }
   break;

  case penDownEvent:
      break;
  default: break;
  }
  return handled;
}



void ResetData()
{
  BigClockAlarm alarm;
  int b;
  int iii;
  DmOpenRef BCdb=NULL;

  b=prefs.mode;

  BCdb=OpenAlarm();

  CloseTheme();
  InitPref();

  if (is35)
    WinScreenMode(winScreenModeSet,NULL,NULL,&prefs.screendepth,NULL);


  for (iii=0 ; iii<aCount ; iii++)
  {
    ReadAlarm(BCdb,iii,&alarm);
    alarm.options.active=0;
    WriteAlarm(BCdb,iii,&alarm);
  }
  CloseAlarm(BCdb);
  SetNextAlarm(cardNo,appID);
  prefs.mode=b;
  SetPageNames();
  OpenTheme(prefs.theme);
  SwitchDraw();

}

int InfoIconHandler(int i,int res,int x,int y)
{
  if ((x>=144) && (x<=159) && (y<=16))
  {
    InfoIconDraw(i);
    if (i==0) 
      {
        if  (InfoIconState)
        {
          FrmHelp(res);
          InfoIconState=false;
        }
      } else
          InfoIconState=true;
    return 1;
  } else
  {
    if (InfoIconState)
    {
      InfoIconDraw(0);
      InfoIconState=false;
    }
    return 0;
  }
}

void SetWorldOptions(int num)
{
  FormPtr   form;
  ListPtr    list;
  CharPtr    listItem;
  ControlPtr popup;
  Long h;
  Long m;
  char number[6];

  form= FrmGetActiveForm ();

  SetCheckBox(checkboxID_lock,prefs.world[num+wWorld1].options.active == 1);

  popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_tzd));
  list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,listID_tzd ));
  if (prefs.world[num+wWorld1].value < 0)
  {
    listItem = LstGetSelectionText(list, 1);
    LstSetSelection(list,1);
  } else
  {
    listItem = LstGetSelectionText(list, 0);
    LstSetSelection(list,0);
  }
  CtlSetLabel(popup,listItem);


  h=abs(prefs.world[num+wWorld1].value / (60*60));


  if (prefs.world[num+wWorld1].value < 0)
    m=abs((prefs.world[num+wWorld1].value + (h*60*60)) / 60);
  else
    m=abs((prefs.world[num+wWorld1].value - (h*60*60)) / 60);

  StrIToA(number,h);
  SetFieldText(editID_tzh,number,6);
  ShowEdit(editID_tzh);
  StrIToA(number,m);
  SetFieldText(editID_tzm,number,6);
  ShowEdit(editID_tzm);

  SetFieldText(editID_name,prefs.world[num+wWorld1].name,12);
  ShowEdit(editID_name);

}


void GetWorldEdit(int num)
{
  FormPtr   form;
  Long h;
  Long m;
  char text[8];
  ListPtr    list;

  form= FrmGetActiveForm ();

  GetFieldText(editID_tzh,text);
  h=StrAToI(text);


  GetFieldText(editID_tzm,text);
  m=abs(StrAToI(text));


  list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,listID_tzd ));
  if (LstGetSelection(list)==1)
    prefs.world[num+wWorld1].value=-(h*60*60+m*60);
  else
    prefs.world[num+wWorld1].value=h*60*60+m*60;

  GetFieldText(editID_name,prefs.world[num+wWorld1].name);
}


 Boolean optionsworld(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;

  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }

    optionpage=0;
    SetWorldOptions(optionpage);
    CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+optionpage)),1);

    if (GotHelp)
      form->helpRscId=stringID_help;

    FrmDrawForm(form);
    //if (palmhelp)
    //  InfoIconDraw(0);
    handled = 1;
    page=2;
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_ok)
    {
      GetWorldEdit(optionpage);
      changed[0]=1;
      changed[1]=1;

      FrmReturnToForm(formID_bigclock);
      handled = 1;
    } else if (
               (event->data.ctlEnter.controlID >= buttonID_ml) &&
               (event->data.ctlEnter.controlID <= buttonID_m4)
             )

    {
     GetWorldEdit(optionpage);
     optionpage=event->data.ctlEnter.controlID-buttonID_m1;
     SetWorldOptions(optionpage);
    } else if (event->data.ctlEnter.controlID == checkboxID_lock)
    {
      prefs.world[optionpage+wWorld1].options.active=GetCheckBox(checkboxID_lock);
    }
    break;
  /*
  case penDownEvent:
     if (palmhelp)
       handled=InfoIconHandler(1,stringID_help,event->screenX,event->screenY);
     break;
  case penUpEvent:
     if (palmhelp)
       handled=InfoIconHandler(0,stringID_help,event->screenX,event->screenY);
     break;
  */   
   default: break;

  }


  return handled;
}

 Boolean optionsglobal(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;

  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }
    SetCheckBox(checkboxID_hardware,prefs.hardwarebuttons);
    SetCheckBox(checkboxID_soundoff,prefs.ignoresystemsoundoff);
    SetCheckBox(checkboxID_locktimer,prefs.locktimer);
    SetCheckBox(checkboxID_startfirst,prefs.startfirst);

    FrmDrawForm(form);
    handled = 1;
    page=7;
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_ok)
    {
      FrmReturnToForm(formID_bigclock);
      handled = 1;
    } else if (event->data.ctlEnter.controlID == checkboxID_hardware)
    {
       prefs.hardwarebuttons=GetCheckBox(checkboxID_hardware);
    } else if (event->data.ctlEnter.controlID == checkboxID_soundoff)
    {
       prefs.ignoresystemsoundoff=GetCheckBox(checkboxID_soundoff);
    } else if (event->data.ctlEnter.controlID == checkboxID_startfirst)
    {
       prefs.startfirst=GetCheckBox(checkboxID_startfirst);
    } else if (event->data.ctlEnter.controlID == checkboxID_locktimer)
    {
       prefs.locktimer=GetCheckBox(checkboxID_locktimer);
    }

    break;
   default: break;

  }


  return handled;
}


 Boolean optionslocaltime(EventPtr event)
{
  RectangleType rc = {{0,50},{160,40}};
  FormPtr   form;
  int       handled = 0;
  Boolean b=false;
  Long now;
  Long now2;
  DateTimeType time1;
  DateTimeType time2;
  int       start;

  if (isTRG)
  {
    rc.topLeft.y=70;
    rc.extent.y=panelheight;
    rc.extent.x=240;
    start=70;
  } else
    start=50;
  rc.extent.y=panelheight;

  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:

    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }
    FrmDrawForm(form);

    if (is35)
      ColorSet(false);
    page=4;
    DrawTime(0,start,false,false,false);

    handled = 1;
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_ok)
    {
      now=TimGetSeconds();
      TimSecondsToDateTime(now,&time1);
      TimSecondsToDateTime(now+prefs.world[0].value,&time2);
      time2.month=time1.month;
      time2.day=time1.day;
      time2.year=time1.year;
      now2=TimDateTimeToSeconds(&time2);
      TimSetSeconds(now2);

      if (GetCheckBox(checkboxID_keepworld) !=0)
      {
        prefs.world[1].value-=now2-now;;
        prefs.world[2].value-=now2-now;;
        prefs.world[3].value-=now2-now;;
        prefs.world[4].value-=now2-now;;
      }

      prefs.world[0].value=0;
      FrmReturnToForm(formID_bigclock);
      handled = 1;
    } else if (event->data.ctlEnter.controlID == buttonID_cancel)
    {
      prefs.world[0].value=0;
      FrmReturnToForm(formID_bigclock);
      handled = 1;
    }
    break;
  case penDownEvent:
    if ( (event->screenY >=start) && (event->screenY <=start+panelheight) )
    {
      prefs.world[0].options.active=0;
      b=SectionPenDown(-1,event->screenX,event->screenY-start,0);
      if (b)
      {
        UpdateTimes();
        WinEraseRectangle(&rc,0);
        DrawTime(0,start,false,false,false);
      }
      prefs.world[0].options.active=1;
      handled=1;
    }
    break;
  case nilEvent:
       if (UpdateTimes()>0)
       {
         WinEraseRectangle(&rc,0);
         DrawTime(0,start,false,false,false);
       }
       break;
    default: break;

  }
  return handled;
}

void SetAlarmOptions(int num)
{
  FormPtr   form;
  ListPtr    list;
  CharPtr    listItem;
  ControlPtr popup;
  char number[9];
  DateTimeType rel;

  form= FrmGetActiveForm ();

  {
    if (ao)
    {
      //alrm
      popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_base));
      CategorySetTriggerLabel(popup, prefs.world[wLocal+prefs.world[num+obase].options.base].name);

      list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_trigger));
      listItem = LstGetSelectionText(list, prefs.world[num+obase].options.trigger);
      popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_trigger));
      CategorySetTriggerLabel(popup, listItem);
    } else
    {
      //timer
      list = (ListPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form, popuplistID_mode));
      listItem = LstGetSelectionText(list, prefs.world[num+obase].options.mode);
      popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_mode));
      CategorySetTriggerLabel(popup, listItem);
      SetCheckBox(checkboxID_autooff,prefs.world[num+obase].options.autooff == 1);
      SetCheckBox(checkboxID_chess,prefs.world[num+obase].options.alternate == 1);
      SetCheckBox(checkboxID_calc,prefs.world[num+obase].options.calc == 1);
      StrIToA(number,prefs.world[num+obase].calc);
      SetFieldText(editID_calc,number,8);
      ShowEdit(editID_calc);


      if (romversion>=0x03103000)
      {
          TimSecondsToDateTime(prefs.world[num+obase].date,&rel);
          DateToAscii(rel.month,rel.day,rel.year,SysPref.dateFormat,reltimerdate);
          CtlSetLabel(FrmGetObjectPtr(form,FrmGetObjectIndex(form,selectorID_reldate )),reltimerdate);

          TimeToAscii(rel.hour,rel.minute,SysPref.timeFormat,reltimertime);
          CtlSetLabel(FrmGetObjectPtr(form,FrmGetObjectIndex(form,selectorID_reltime )),reltimertime);
          SetCheckBox(checkboxID_daterel,prefs.world[num+obase].options.daterelative == 1);
      } else
      {
        HideEdit(checkboxID_daterel);
        HideEdit(selectorID_reldate);
        HideEdit(selectorID_reltime);

      }

    }

    SetCheckBox(checkboxID_backlight,prefs.world[num+obase].options.backlight == 1);
    SetCheckBox(checkboxID_talelight,prefs.world[num+obase].options.talelight == 1);
    SetCheckBox(checkboxID_silent,prefs.world[num+obase].options.silent == 1);
    SetCheckBox(checkboxID_wait,prefs.world[num+obase].options.wait == 0);

    SetCheckBox(checkboxID_snooze,prefs.world[num+obase].options.snooze == 1);

    StrIToA(number,prefs.world[num+obase].snoozetime);
    SetFieldText(editID_snooze,number,6);
    ShowEdit(editID_snooze);

    StrIToA(number,prefs.world[num+obase].snoozecount);
    SetFieldText(editID_max,number,6);
    ShowEdit(editID_max);

  }
}


Boolean getalarmtext(int num)
{
  char text[8];

  GetFieldText(editID_snooze,text);
  prefs.world[num+obase].snoozetime=StrAToI(text);
  GetFieldText(editID_max,text);
  prefs.world[num+obase].snoozecount=StrAToI(text);
  if (!ao)
  {
    GetFieldText(editID_calc,text);
    prefs.world[num+obase].calc=StrAToI(text);
  }
  return true;
}


 Boolean optionsalarm(EventPtr event)
{
  FormPtr   form;
  int       handled  = 0;
  int       index;
  ListPtr   ListP;
  int num;
  DateTimeType now;
  BigClockOptions *bco;
  char      dialogtext[32];

  form = FrmGetActiveForm();



  if (event->eType == frmOpenEvent)
  {
    optionpage=0;
    SetAlarmOptions(optionpage);
    CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+optionpage)),1);
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }

    FrmDrawForm(form);
    handled = 1;
    page=2;
  } else if (event->eType == ctlSelectEvent)
  {
     //AlarmOptionsSelectEvent(event);
   bco=&prefs.world[optionpage+obase].options;
   if (event->data.ctlEnter.controlID == buttonID_ok)
   {
     changed[0]=1;
     changed[1]=1;

     getalarmtext(optionpage);
     FrmReturnToForm(formID_bigclock);

     if (ao)
     {
       UpdateAlarm(wAlarm1);
       UpdateAlarm(wAlarm2);
       UpdateAlarm(wAlarm3);
       UpdateAlarm(wAlarm4);
     } else
     {
       UpdateTimer(wTimer1);
       UpdateTimer(wTimer2);
       UpdateTimer(wTimer3);
       UpdateTimer(wTimer4);
     }

     SetNextAlarm(cardNo,appID);

     handled = 1;
   } else if (event->data.ctlEnter.controlID == popupID_base)
   {
     index = FrmGetObjectIndex(form, popuplistID_times);
     ListP = FrmGetObjectPtr(form, index);
     LstSetDrawFunction(ListP,DrawWorldName);

     LstSetSelection(ListP,bco->base);
     LstSetPosition(ListP,60,20);
     num=LstPopupList(ListP);
     if (num != -1)
       bco->base=num;
     SetAlarmOptions(optionpage);
   } else if (
               (event->data.ctlEnter.controlID >= buttonID_m1) &&
               (event->data.ctlEnter.controlID <= buttonID_m4)
             )

   {
     getalarmtext(optionpage);
     optionpage=event->data.ctlEnter.controlID-buttonID_m1;
     SetAlarmOptions(optionpage);
   } else if (event->data.ctlEnter.controlID == checkboxID_backlight)
   {
     bco->backlight=GetCheckBox(checkboxID_backlight);
   } else if (event->data.ctlEnter.controlID == checkboxID_talelight)
   {
     bco->talelight=GetCheckBox(checkboxID_talelight);
   } else if (event->data.ctlEnter.controlID == checkboxID_silent)
   {
     bco->silent=GetCheckBox(checkboxID_silent);
   } else if (event->data.ctlEnter.controlID == checkboxID_wait)
   {
     bco->wait=inot[GetCheckBox(checkboxID_wait)];
   } else if (event->data.ctlEnter.controlID == checkboxID_snooze)
   {
     bco->snooze=GetCheckBox(checkboxID_snooze);
   } else if (event->data.ctlEnter.controlID == checkboxID_autooff)
   {
     bco->autooff=GetCheckBox(checkboxID_autooff);
   /*} else if (event->data.ctlEnter.controlID == checkboxID_hardware)
   {
     bco->hardwarebuttons=GetCheckBox(checkboxID_hardware);*/
   } else if (event->data.ctlEnter.controlID == checkboxID_daterel)
   {
     bco->daterelative=GetCheckBox(checkboxID_daterel);
   } else if (event->data.ctlEnter.controlID == checkboxID_chess)
   {
     bco->alternate=GetCheckBox(checkboxID_chess);
   } else if (event->data.ctlEnter.controlID == checkboxID_calc)
   {
     bco->calc=GetCheckBox(checkboxID_calc);
   } else if (event->data.ctlEnter.controlID == popupID_trigger)
   {
     index = FrmGetObjectIndex(form, popuplistID_trigger);
     ListP = FrmGetObjectPtr(form, index);

     LstSetSelection(ListP,bco->trigger);
     LstSetPosition(ListP,60,112);
     num=LstPopupList(ListP);
     if (num != -1)
       bco->trigger=num;
     SetAlarmOptions(optionpage);
   } else if (event->data.ctlEnter.controlID == popupID_mode)
   {
     index = FrmGetObjectIndex(form, popuplistID_mode);
     ListP = FrmGetObjectPtr(form, index);

     LstSetSelection(ListP,bco->mode);
     LstSetPosition(ListP,60,20);
     num=LstPopupList(ListP);
     if (num != -1)
       bco->mode=num;
     SetAlarmOptions(optionpage);
   } else if (event->data.ctlEnter.controlID == selectorID_reldate)
   {
      TimSecondsToDateTime(prefs.world[optionpage+obase].date,&now);
      now.second=0;

      SysCopyStringResource(dialogtext,stringID_datedialog);

      if (SelectDay(selectDayByDay,&(now.month),&(now.day),&(now.year),dialogtext))
      {
         prefs.world[optionpage+obase].date=TimDateTimeToSeconds(&now);
         SetAlarmOptions(optionpage);
      }
   } else if (event->data.ctlEnter.controlID == selectorID_reltime)
   {
      TimSecondsToDateTime(prefs.world[optionpage+obase].date,&now);
      now.second=0;
      SysCopyStringResource(dialogtext,stringID_timedialog);
      if (SelectOneTime(&(now.hour),&(now.minute),dialogtext))
      {
         prefs.world[optionpage+obase].date=TimDateTimeToSeconds(&now);
         SetAlarmOptions(optionpage);
      }
   }
  }
  return handled;
}
void setsoundlabels()
{
   int iii;
   FormPtr   form;
   char number[6];
   int       index;
   ListPtr   ListP;
   ControlPtr popup;
   CharPtr    listItem;


   form = FrmGetActiveForm();

   index = FrmGetObjectIndex(form, popuplistID_soundtypes);
   ListP = FrmGetObjectPtr(form, index);
   listItem = LstGetSelectionText(ListP,prefs.sounds[obase].type );
   if(!listItem) listItem = "?";
   popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_soundtypes));
   CategorySetTriggerLabel(popup,listItem );

   if ( prefs.sounds[obase].type != 0)
   {
      HideEdit(labelID_soundfreq);
      HideEdit(labelID_soundtime);
      HideEdit(labelID_soundampli);
      HideEdit(labelID_soundpause);
      for (iii=0; iii<4; iii++)
      {
        HideEdit(editID_soundf1+iii*4);
        HideEdit(editID_soundf1+iii*4+1);
        HideEdit(editID_soundf1+iii*4+2);
        HideEdit(editID_soundf1+iii*4+3);
      }

   } else
   {
     ShowEdit(labelID_soundfreq);
     ShowEdit(labelID_soundtime);
     ShowEdit(labelID_soundampli);
     ShowEdit(labelID_soundpause);

     for (iii=0; iii<4; iii++)
     {
       if ( prefs.sounds[obase].type == 0)
       {
         StrIToA(number,prefs.sounds[obase].freq[iii]);
         SetFieldText(editID_soundf1+iii*4,number,5);
         ShowEdit(editID_soundf1+iii*4);

         StrIToA(number,prefs.sounds[obase].time[iii]);
         SetFieldText(editID_soundf1+iii*4+1,number,5);
         ShowEdit(editID_soundf1+iii*4+1);

         StrIToA(number,prefs.sounds[obase].amplitude[iii]);
         SetFieldText(editID_soundf1+iii*4+2,number,5);
         ShowEdit(editID_soundf1+iii*4+2);

         StrIToA(number,prefs.sounds[obase].pause[iii]);
         SetFieldText(editID_soundf1+iii*4+3,number,5);
         ShowEdit(editID_soundf1+iii*4+3);
       }
     }  
   }

  StrIToA(number,prefs.sounds[obase].count);
  SetFieldText(editID_soundr,number,5);
  ShowEdit(editID_soundr);
}


void getsoundlabels()
{
  char text[8];
  int iii;

  if (prefs.sounds[obase].type==0)
  {
    for (iii=0; iii<4; iii++)
    {
       GetFieldText(editID_soundf1+iii*4,text);
       prefs.sounds[obase].freq[iii]=StrAToI(text);
       GetFieldText(editID_soundf1+iii*4+1,text);
       prefs.sounds[obase].time[iii]=StrAToI(text);
       GetFieldText(editID_soundf1+iii*4+2,text);
       prefs.sounds[obase].amplitude[iii]=StrAToI(text);
       GetFieldText(editID_soundf1+iii*4+3,text);
       prefs.sounds[obase].pause[iii]=StrAToI(text);
    }
  }
  GetFieldText(editID_soundr,text);
  prefs.sounds[obase].count=StrAToI(text);
}

void testsound(int num)
{
  int iii;
  int jjj;
  Boolean quit;
  SndCommandType cmd;
  EventType	event;
  int wait=0;
  UInt32 last;

  iii=0;
  jjj=0;
  quit=false;


  if ( prefs.sounds[num].type == 0)
  {
    last=TimGetTicks();
    while ( (iii< prefs.sounds[num].count) && (!quit) )
    {
      EvtGetEvent(&event, wait);

      if (SysHandleEvent (&event)) continue;
      if (event.eType == penDownEvent) return;

      if ((TimGetTicks()-last) < wait) continue;




      if (prefs.sounds[num].freq[jjj] >0)
      {
        cmd.cmd = sndCmdFreqDurationAmp;
        cmd.param1 = prefs.sounds[num].freq[jjj];
        cmd.param2 = prefs.sounds[num].time[jjj];
        cmd.param3 = prefs.sounds[num].amplitude[jjj];
        SndDoCmd(0, &cmd, 0);

      }
      wait=prefs.sounds[num].pause[jjj];
      last=TimGetTicks();

      jjj++;
      if (jjj>=4)
      {
        iii++;
        jjj=0;
      }

    }
  } else if ( prefs.sounds[num].type == 1)
  {
    SndPlaySystemSound(sndAlarm);
  } else if (  prefs.sounds[num].type >= 2)
  {
    wait=0;
    while ( (jjj< prefs.sounds[num].count) && (!quit) )
    {
      EvtGetEvent(&event, wait);
      wait=100;
      if (SysHandleEvent (&event)) continue;

      if (event.eType == penDownEvent) return;
      CustomBeep(prefs.sounds[num].type -2);
      jjj++;
     }

  }

}

Boolean optionssound(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  int iii;
  int       index;
  ListPtr   ListP;
  RectangleType rc = {{50,50},{60,60}};

  //char soundname[12];
  //Word      midicount;
  //Handle    midih;
  if (isTRG)
  {
    rc.extent.x=90;
    rc.extent.y=90;
    rc.topLeft.x=75;
    rc.topLeft.y=75;
  }

  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }

    obase=0;
    CtlSetValue(FrmGetObjectPtr(form,FrmGetObjectIndex(form,buttonID_m1+obase)),1);

    //no midi yet
    /*
    if (usemidi)
    {
      usemidi=SndCreateMidiList(NULL,true,&midicount,&midih);
      //StrIToA(help,midicount);
      if (midilist != NULL)
        MemPtrFree(midilist);
      //midilist=MemPtrNew(sizeof(* char) * midicount);
    }

    */

    setsoundlabels();
    FrmDrawForm(form);
    handled = 1;
    page=2;
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_ok)
    {
      getsoundlabels();
      //if (midilist != NULL)
      //  MemPtrFree(midilist);
      FrmReturnToForm(formID_bigclock);
      handled = 1;
   } else if (event->data.ctlEnter.controlID == popupID_soundtypes)
   {
     form = FrmGetActiveForm();
     index = FrmGetObjectIndex(form, popuplistID_soundtypes);
     ListP = FrmGetObjectPtr(form, index);
     LstSetSelection(ListP,prefs.sounds[obase].type);
     iii=LstPopupList(ListP);
     if (iii != -1)
      prefs.sounds[obase].type=iii;
     setsoundlabels();

   } else if (event->data.ctlEnter.controlID == buttonID_test)
   {
     form = FrmGetActiveForm();
     FrmSetFocus(form,noFocus);

     WinEraseRectangle(&rc,5);
     WinDrawRectangleFrame(roundFrame,&rc);
     MySetFont(2);
     if (isTRG)
       WinDrawChars("STOP",4,100,110);
     else
       WinDrawChars("STOP",4,68,74);

     getsoundlabels();
     testsound(obase);
     rc.extent.x+=2;
     rc.extent.y+=2;
     rc.topLeft.x--;
     rc.topLeft.y--;

     WinEraseRectangle(&rc,5);
     FrmDrawForm(form);
   } else if (
               (event->data.ctlEnter.controlID >= buttonID_m1) &&
               (event->data.ctlEnter.controlID <= buttonID_m4)
             )

   {
     getsoundlabels();
     obase=event->data.ctlEnter.controlID-buttonID_m1;
     setsoundlabels();
    }
    break;
    default: break;

   }
   return handled;
}


void drawcolorsquares(void)
{
    RectangleType rcb = {{40,40},{50,14}};
    RectangleType rcf = {{40,58},{50,14}};
    RectangleType rcbi = {{100,40},{50,14}};
    RectangleType rcfi = {{100,58},{50,14}};

    if (isTRG)
    {
      rcb.topLeft.x=60;
      rcb.topLeft.y=60;
      rcb.extent.x=75;
      rcb.extent.y=21;

      rcf.topLeft.x=60;
      rcf.topLeft.y=87;
      rcf.extent.x=75;
      rcf.extent.y=21;

      rcbi.topLeft.x=150;
      rcbi.topLeft.y=60;
      rcbi.extent.x=75;
      rcbi.extent.y=21;

      rcfi.topLeft.x=150;
      rcfi.topLeft.y=87;
      rcfi.extent.x=75;
      rcfi.extent.y=21;
    }

    WinSetForeColor(prefs.colorb);
    WinDrawRectangle(&rcb,0);

    WinSetForeColor(prefs.colorf);
    WinDrawRectangle(&rcf,0);

    WinSetForeColor(prefs.colorbi);
    WinDrawRectangle(&rcbi,0);

    WinSetForeColor(prefs.colorfi);
    WinDrawRectangle(&rcfi,0);

    WinSetForeColor(UIColorGetTableEntryIndex(UIObjectFrame));

    WinDrawRectangleFrame(1,&rcb);
    WinDrawRectangleFrame(1,&rcf);
    WinDrawRectangleFrame(1,&rcbi);
    WinDrawRectangleFrame(1,&rcfi);


  }




void InitThemeList(UInt32 type,int listid,char *def)
{
  FormPtr Form;
  ListPtr  list;
  int     pos;
  int     num;
  DmSearchStateType state;
  UInt16  card;
  LocalID dbid;
  int d;


  Form= FrmGetActiveForm();
  list=FrmGetObjectPtr(Form,FrmGetObjectIndex(Form,listid));

  pos=0;
  num=0;
  ThemeList[0]=NULL;

  StrCopy(help,"<no theme>");

  SysCopyStringResource(help,stringID_notheme);


  ThemeList[num]=&help[pos];
  pos+=StrLen(&help[pos])+1;
  num++;
  d=0;

  while ( (num<maxthemes) &&
          (DmGetNextDatabaseByTypeCreator(num==1,&state,type,BCAppID,false,&card,&dbid) == 0)
        )
  {
    ThemeList[num]=&help[pos];
    DmDatabaseInfo(card,dbid,&help[pos],NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
    pos+=StrLen(&help[pos])+1;
    if (StrCompare(def,ThemeList[num])==0)
      d=num;
    num++;
  }

  LstSetListChoices(list,ThemeList,num);
  LstSetSelection(list,d);
}


// Callback for ExgDBWrite to send data with Exchange Manager
Err WriteDBData(const void* dataP, ULong* sizeP, void* userDataP)
{
  Err err;
  *sizeP = ExgSend((ExgSocketPtr)userDataP, (void*)dataP, *sizeP, &err);
  return err;
}

Err SendDatabase (Word cardNo, LocalID dbID, CharPtr nameP,CharPtr descriptionP)
{
  ExgSocketType exgSocket;
  Err err;
  // Create exgSocket structure
  MemSet(&exgSocket, sizeof(exgSocket), 0);
  exgSocket.description = descriptionP;
  exgSocket.name = nameP;
  // Start an exchange put operation
  err = ExgPut(&exgSocket);
  if (!err) {
      err = ExgDBWrite(WriteDBData, &exgSocket, NULL, dbID, cardNo);
      err = ExgDisconnect(&exgSocket, err);
     }
  return err;
}


 Boolean optionscolor(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  IndexedColorType icolor;
  RGBColorType rgbcolor;
  LocalID id;
  ListPtr    list;
  CharPtr    listItem;
  ControlPtr popup;
  int iii;
  int        index;
  UInt16     x;
  int       cx1,cx2,cw;
  int       cy1,cy2,ch;
  UInt16  attr;
  Err       error;
  Boolean   rd;
  char      beamname[40];
  //char      beamdisplay[64];


  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    page=5;
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }

    CloseTheme();

    InitThemeList('BCth',listID_theme,prefs.theme);


   //set screen mode
   index = FrmGetObjectIndex(form, popuplistID_screenmode);
   list = FrmGetObjectPtr(form, index);
   iii=0;
   switch (prefs.screendepth)
   {
     case 1: iii=0;
             break;
     case 2: iii=1;
             break;
     case 4: iii=2;
             break;
     case 8: iii=3;
             break;
     case 16: iii=4;
             break;
   }
   listItem = LstGetSelectionText(list,iii);
   if(!listItem) listItem = "?";
   popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_screenmode));
   CategorySetTriggerLabel(popup,listItem );

    FrmDrawForm(form);
    drawcolorsquares();


    handled = 1;
    break;
  case penDownEvent:
      rd=false;
      if (isTRG)
      {
        cx1=60;
        cx2=150;
        cw=75;
        cy1=60;
        cy2=87;
        ch=21;
      } else
      {
        cx1=40;
        cx2=100;
        cw=50;
        cy1=40;
        cy2=58;
        ch=14;
      }
      if ( (event->screenX >=cx1) && (event->screenX <=cx1+cw) )
      {
        //left
        if ( (event->screenY >=cy1) && (event->screenY <=cy1+ch) )
        {
          //top
          icolor=prefs.colorb;
          UIPickColor(&icolor,&rgbcolor,UIPickColorStartPalette,"Back","");
          prefs.colorb=icolor;
          rd=true;
        } else if ( (event->screenY >=cy2) && (event->screenY <= cy2+ch) )
        {
          //bottom
          icolor=prefs.colorf;
          UIPickColor(&icolor,&rgbcolor,UIPickColorStartPalette,"Text","");
          prefs.colorf=icolor;
          rd=true;
        }
      } else if ( (event->screenX >=cx2) && (event->screenX <=cx2+cw) )
      {
        //right
        if ( (event->screenY >=cy1) && (event->screenY <=cy1+ch) )
        {
          //top
          icolor=prefs.colorbi;
          UIPickColor(&icolor,&rgbcolor,UIPickColorStartPalette,"Back selected","");
          prefs.colorbi=icolor;
          rd=true;
        } else if ( (event->screenY >=cy2) && (event->screenY <=cy2+ch) )
        {
          //bottom
          icolor=prefs.colorfi;
          UIPickColor(&icolor,&rgbcolor,UIPickColorStartPalette,"Text selected","");
          prefs.colorfi=icolor;
          rd=true;
        }
      }
    if (rd)
    {
      FrmDrawForm(form);
      drawcolorsquares();
      handled=true;
    }
    //handled = 1;
    break;
  case lstSelectEvent:
       if (event->data.lstSelect.selection > 0)
       {
         StrCopy(prefs.theme,ThemeList[event->data.lstSelect.selection]);
         //check for hicolor

         if (StrLen(prefs.theme) > 0)
         {

           id=DmFindDatabase(0,prefs.theme);
           error=DmDatabaseInfo(0,id,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
           ThemeDB=DmOpenDatabase(0,id,dmModeReadOnly);

           if (!(attr & dmHdrAttrResDB))
           {
             ThemeBonusH=DmQueryRecord(ThemeDB,1);
             ThemeBonus=MemHandleLock(ThemeBonusH);

             if (
                  (ThemeBonus->maxdepth==3) &&
                  (romversion < 0x04000000) &&
                  (maxdepth < 16)
                )
             {
                FrmCustomAlert(alertID_text,"This theme requires support for 16bit graphics!",NULL,NULL);
                StrCopy(prefs.theme,"");
             } else
             {
               if (prefs.screendepth >= 8)
               {
                 prefs.colorb=ThemeBonus->colorb;
                 prefs.colorbi=ThemeBonus->colorbi;
                 prefs.colorf=ThemeBonus->colorf;
                 prefs.colorfi=ThemeBonus->colorfi;
                 drawcolorsquares();
               }
               MemHandleUnlock(ThemeBonusH);
               ThemeBonusH=0;
               ThemeBonus=0;

             }



           DmCloseDatabase(ThemeDB);
           ThemeDB=0;
         }  

       }


       }
       else
         prefs.theme[0]=0;
    break;

  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_ok)
    {

      //initbigbitmap();
      OpenTheme(prefs.theme);
      changed[0]=1;
      changed[1]=1;

      FrmReturnToForm(formID_bigclock);



      handled = 1;
    } else
    if (event->data.ctlEnter.controlID == buttonID_info)
    {
      if (StrLen(prefs.theme) > 0)
      {
       id=DmFindDatabase(0,prefs.theme);
       error=DmDatabaseInfo(0,id,NULL,&attr,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL);
       ThemeDB=DmOpenDatabase(0,id,dmModeReadOnly);

       if (attr & dmHdrAttrResDB)
       {
         ThemeDefH=DmGetResource('tSTR',7169);
         if (ThemeDefH != 0)
         {
           ThemeDef=MemHandleLock(ThemeDefH);
           FrmCustomAlert(alertID_text,(char *)ThemeDef,NULL,NULL);
           MemHandleUnlock(ThemeDefH);
           ThemeDefH=0;
         }
       } else
       {
         ThemeDefH=DmQueryRecord(ThemeDB,2);
         ThemeDef=MemHandleLock(ThemeDefH);
         FrmCustomAlert(alertID_text,(char *)ThemeDef,NULL,NULL);
         MemHandleUnlock(ThemeDefH);
         ThemeDefH=0;
       }
       DmCloseDatabase(ThemeDB);
       ThemeDB=0;

      }  else
      {
         FrmCustomAlert(alertID_text,"Use the build in font and no background.",NULL,NULL);
      }
    } else
    if (event->data.ctlEnter.controlID == buttonID_beam)
    {
       id=DmFindDatabase(0,prefs.theme);
       StrCopy(beamname,prefs.theme);
       StrCat(beamname,".pdb");

       //StrCopy(beamdisplay,"BigClock theme """);
       //StrCat(beamdisplay,prefs.theme);
       //StrCat(beamdisplay,"""");

       SendDatabase (0, id, beamname,prefs.theme);
    } else
    if (event->data.ctlEnter.controlID == buttonID_delete)
    {
      if (StrLen(prefs.theme) > 0)
      {
        if (FrmCustomAlert(alertID_confirmation,prefs.theme,NULL,NULL) == 0)
        {
          id=DmFindDatabase(0,prefs.theme);
          DmDeleteDatabase(0,id);
          prefs.theme[0]=0;
          InitThemeList('BCth',listID_theme,prefs.theme);
          FrmDrawForm(form);
          drawcolorsquares();
        }
      }
   } else if (event->data.ctlEnter.controlID == popupID_screenmode)
   {
     form = FrmGetActiveForm();
     index = FrmGetObjectIndex(form, popuplistID_screenmode);
     list = FrmGetObjectPtr(form, index);

     iii=0;
     switch (prefs.screendepth)
     {
       case 1: iii=0;
               break;
       case 2: iii=1;
               break;
       case 4: iii=2;
               break;
       case 8: iii=3;
               break;
       case 16: iii=4;
               break;
     }

     LstSetSelection(list,iii);
     iii=LstPopupList(list);
     if (iii != -1)
     {
       prefs.screendepth=1;
       switch (iii)
       {
         case 0: prefs.screendepth=1;
                 break;
         case 1: prefs.screendepth=2;
                 break;
         case 2: prefs.screendepth=4;
                 break;
         case 3: prefs.screendepth=8;
                 break;
         case 4: prefs.screendepth=16;
                 break;
       }
#ifdef debug
      debugi("maxdepth",maxdepth);
      debugi("screendepth",prefs.screendepth);
#endif      
      if (prefs.screendepth>maxdepth)
      {
        prefs.screendepth=maxdepth;
      }
      WinDeleteWindow(build,true);
      WinScreenMode(winScreenModeSet,NULL,NULL,&prefs.screendepth,NULL);
      build=WinCreateOffscreenWindow(panelwidth,panelheight,screenFormat,&x);
      //build=WinCreateOffscreenWindow(panelwidth,panelheight,genericFormat,&x);
      SetDeepthDefault();

      switch (prefs.screendepth)
      {
        case 1: iii=0;
                break;
        case 2: iii=1;
                break;
        case 4: iii=2;
                break;
        case 8: iii=3;
                break;
        case 16: iii=4;
                break;
      }
      listItem = LstGetSelectionText(list,iii);
      if(!listItem) listItem = "?";
      popup = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,popupID_screenmode));
      CategorySetTriggerLabel(popup,listItem );

      FrmDrawForm(form);
      drawcolorsquares();

     }
    }


    break;

    default: break;

   }
   return handled;
}

void drawlabels()
{
  int iii,yadd;

  MySetFont(2);

  if (isTRG)
    yadd=21;
  else
    yadd=14;

  for (iii=0; iii<8; iii++)
  {
    WinDrawChars(prefs.history[iii],StrLen(prefs.history[iii]),40,yadd+iii*yadd);
  }
}


void addtohistory(char *label)
{
  int iii;
  int free;
  Boolean found;

  found=false;
  iii=0;
  free=-1;

  while ((!found) && (iii<8))
  {
    if ((prefs.history[iii][0]==0) && (free==-1))
    {
      free=iii;
    } else if (StrCompare(label,prefs.history[iii])==0)
    {
      found=true;
    } else
      iii++;
  }
  if (!found)
  {
    if (free==-1)
    {
      MemMove(&prefs.history[0][0],&prefs.history[1][0],7*12);
      free=7;
    }
    StrCopy(prefs.history[free],label);
  }

}



 Boolean labelhistory(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  int       num;


  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    if (isTRG)
    {
      VgaFrmModify(form,vgaFormModify160To240);
    }
  
    page=6;

    FrmDrawForm(form);

    drawlabels();

    SetFieldText(editID_edit1, "",12);
    FrmSetFocus(form,FrmGetObjectIndex(form,editID_edit1));


    handled = 1;
    break;
  case ctlSelectEvent:
    if (event->data.ctlEnter.controlID == buttonID_cancel)
    {
      FrmReturnToForm(formID_bigclock);
      handled = 1;
    } else if (event->data.ctlEnter.controlID == buttonID_set)
    {
      GetFieldText(editID_edit1,prefs.world[historymode].name);
      if (StrLen(prefs.world[historymode].name) > 0)
        addtohistory(prefs.world[historymode].name);

      changed[0]=1;
      changed[1]=1;
      FrmReturnToForm(formID_bigclock);
      handled = 1;
    }
    break;
   case penDownEvent:
   {
     if ((event->screenY >= 14) && (event->screenY < 126))
     {
       num= (event->screenY - 14) / 14;
       StrCopy(prefs.world[historymode].name,prefs.history[num]);
       changed[0]=1;
       changed[1]=1;
       FrmReturnToForm(formID_bigclock);
       handled=1;
     }
     break;
    default: break;

   }

  }
  return handled;
}


Boolean newyear(EventPtr event)
{
  FormPtr   form;
  int       handled = 0;
  int       xa;
  int       xp;
  RectangleType rc = {{0,16},{160,144}};  

  form = FrmGetActiveForm();
  switch (event->eType)
  {
  case frmOpenEvent:
    FrmDrawForm(form);

    if (iscolor)
    {
      WinSetForeColor(255);
      WinSetBackColor(255);
      WinDrawRectangle(&rc,0);
    }


    page=-1;
    initrockets();
    newyeardone=1;

    addrocket(200,1600,5,-10,100,true,0);

    handled = 1;
    break;

  case penDownEvent:
    newyeardone=2;
    freerockets();
    FrmGotoForm(formID_bigclock);
    handled = 1;
    break;
  case nilEvent:
    animaterockets();
    if (SysRandomUnder(120)==0)
    {
      xp=SysRandomUnder(1600);
      xa=SysRandomUnder(6);
      if (xp>800)
      {
        xa=-xa;
      }
      addrocket(xp,1600,xa,-10,SysRandomUnder(70)+50,true,SysRandomUnder(3));
      SndPlaySystemSound(sndWarning);
    }
    handled = 1;
    break;
    default: break;

   }
   return handled;
}



void initrockets(void)
{
  rocket *r;
  int    iii;
  DWord backlight;

  backlight=0;
  FtrGet(sysFtrCreator, sysFtrNumBacklight, &backlight);
  if (backlight>0)
    HwrBacklight(true,true);


  rocketlist=MemPtrNew(sizeof(rocket)*maxrockets);
  r=rocketlist;
  for (iii=0; iii<maxrockets; iii++)
  {
    r->time=0;
    r++;
  }
  for (iii=0; iii<6; iii++)
  {
    rocketimageh[iii]=DmGetResource('Tbmp',bitmapID_circlelarge+iii);
    rocketimagep[iii]=MemHandleLock(rocketimageh[iii]);
  }

}

void freerockets(void)
{
  int iii;
  MemPtrFree(rocketlist);
  for (iii=0; iii<6; iii++)
  {
    MemHandleUnlock(rocketimageh[iii]);
    DmReleaseResource(rocketimageh[iii]);
  }
}

int SysRandomUnder(int num)
{
 return ( (Int)
          ( (DWord)
                (   (DWord) SysRandom(0)*(DWord)(num)
                ) / (DWord)((DWord)sysRandomMax+1)
          )
        );
}

void addrocket(int x,int y,int xs,int ys,int time, Boolean explode, int sprite)
{
  rocket *r;
  int iii;

  r=rocketlist;

  iii=0;
  while ((iii<maxrockets) && (r->time>0))
  {
    r++;
    iii++;
  }
  if (r->time==0)
  {
    r->time=time;
    r->xpos=x;
    r->ypos=y;
    r->xspeed=xs;
    r->yspeed=ys;
    r->explode=explode;
    r->sprite=sprite;
  }

}

void addexplode(int x,int y)
{
  int s1,s2,i1,i2,t1,t2,style;

  i1=SysRandomUnder(3)+3;
  i2=SysRandomUnder(3)+3;
  s1=SysRandomUnder(5)+2;
  s2=SysRandomUnder(5)+2;
  t1=SysRandomUnder(50);
  t2=SysRandomUnder(50);
  style=SysRandomUnder(10);

  if (style<6)
  {
    addrocket(x,y,0,-s1,t1,false,i1);
    addrocket(x,y,s1,0,t1,false,i1);
    addrocket(x,y,0,s1,t1,false,i1);
    addrocket(x,y,-s1,0,t1,false,i1);

    addrocket(x,y,s2,s2,t2,false,i2);
    addrocket(x,y,s2,-s2,t2,false,i2);
    addrocket(x,y,-s2,s2,t2,false,i2);
    addrocket(x,y,-s2,-s2,t2,false,i2);
  } else
  {
    addrocket(x,y,-s1,-s1,t1,false,i1);
    addrocket(x,y,-s2,-s1,t1,false,i2);
    addrocket(x,y,0,-s1,t1,false,i1);
    addrocket(x,y,s2,-s1,t1,false,i2);
    addrocket(x,y,s1,-s1,t1,false,i1);
  }
}

void animaterockets()
{
   int iii;
   rocket *r;
   int x,y;
   RectangleType rc = {{0,0},{11,11}};


   r=rocketlist;
   for (iii=0; iii<maxrockets ; iii++)
   {
     if (r->time>0)
     {
       r->time--;
       if (r->time ==0)
       {
         if (r->explode)
         {
           addexplode(r->xpos,r->ypos);
           SndPlaySystemSound(sndClick);
         }
         else
           {
             rc.topLeft.x = r->xpos / 10;
             rc.topLeft.y = r->ypos / 10;
             WinEraseRectangle(&rc,0);
           }
       } else
       {
         r->xpos+=r->xspeed;
         r->ypos+=r->yspeed;
         x= r->xpos / 10;
         y= r->ypos / 10;
         WinDrawBitmap(rocketimagep[r->sprite],x,y);
         if (
             (r->xpos>1700) ||
             (r->xpos<-100) ||
             (r->ypos>1700) ||
             (r->ypos<-100)
            )
          r->time=1;
       }
     }
     r++;
   }
}




