//for new year easter egg
typedef struct
        {
          Boolean explode;
          int     xpos;
          int     ypos;
          int     xspeed;
          int     yspeed;
          int     sprite;
          int     time;
        } rocket;

int newyeardone=0;
int maxrockets=60;
rocket *rocketlist;
VoidHand  rocketimageh[6];
BitmapPtr rocketimagep[6];


