#define NON_PORTABLE

#include <PalmOS.h>
#include <CoreTraps.h>
#include <System/SerialMgrOld.h>   // for talelight
#include <SysEvtMgr.h>
#include <PalmCompatibility.h>
#include "vga.h"
#include "bigclock.h"

#define BCAppID       'BClk'
#define ymove 2

#define SEG_DRAW  __attribute__ ((section ("draw")))
#define SEG_UTIL  __attribute__ ((section ("util")))

#include "bigclocktypes.h"
#define nodebug


void ColorSet(Boolean i)  SEG_DRAW;
void MyDrawChars(const Char *chars, Int16 len,Coord x, Coord y,Boolean i)  SEG_DRAW;
void MySetFont(int n) SEG_DRAW;
void DrawTiny(int size,int x,int y,int n)  SEG_DRAW;
void TinyNumber(int size,int x,int y,int num) SEG_DRAW;
void DrawUpDown(int num,int x, int y) SEG_DRAW;
void DrawButton(char *t,Boolean i,int x, int y, int h, int w, int o)  SEG_DRAW;
void DrawBigNumber(Boolean out,int num,UInt32 *x,UInt32 *y) SEG_DRAW;
void DrawBigAMPM(Boolean out,int num,UInt32 *x,UInt32 *y)  SEG_DRAW;
void DrawSmallDate(int num,int y) SEG_DRAW;
void DrawAlarmDays(int num,int x,int y) SEG_DRAW;
void DrawAlarmSound(int num,int x,int y) SEG_DRAW;
void DrawTime(int num,int y,Boolean alarm, Boolean timer,Boolean small) SEG_DRAW;
void DrawTime2(int y,int d,int h,int m,int s,Boolean small)  SEG_DRAW;
void DrawBigSymbol(Boolean out,int num,UInt32 *x,UInt32 *y)  SEG_DRAW;
void DrawBig(char *text,int x, int y,int w, int h,UInt8 align)  SEG_DRAW;
void DrawAnalogTime(int num,int y) SEG_DRAW;
void DrawTimerTime(int num,int y,Boolean ns,Boolean small) SEG_DRAW;
void DrawTwoTimes(int num,int y) SEG_DRAW;
void DrawDateDetail(int num,int y) SEG_DRAW;
void DrawDate(int num,int y) SEG_DRAW;
void DrawTimerControls(int num,int y,Boolean small)  SEG_DRAW;
void DrawAlarmCheck(int num, int y) SEG_DRAW;
void DrawMonthView(int num,int y,Boolean r) SEG_DRAW;
void SwitchDrawSection(int val,int y,Boolean sw) SEG_DRAW;
void DrawSilkMonth(int off,int x,int y) SEG_DRAW;

extern void CloseAlarm(DmOpenRef BCdb);
extern DmOpenRef OpenAlarm();
extern void DrawCircle(int r,int xa,int ya) SEG_UTIL;
extern void WLine(int w,int r1,int r2,int xa,int ya) SEG_UTIL;
extern void DrawZeiger(int w,int l, int s, int xa, int ya) SEG_UTIL;
extern void CalcDateData(DateTimeType now,Long *data) SEG_UTIL;
extern Boolean ReadAlarm(DmOpenRef BCdb,int num,BigClockAlarm *target);
#ifdef debug
extern void debugi(char *name,Int32 value);
extern void debugs(char *name,char* value);
#endif
extern void ShowRegions(UInt32 panel,UInt32 sub);




extern Boolean iscolor;
extern Boolean is35;
extern Boolean isTRG;
extern UInt32  maxdepth;
extern UInt32  panelwidth;
extern UInt32 panelheight;
extern UInt32  ytop;         // upper panel
extern UInt32 ybottom;      // lower panel


extern BigClockPrefType prefs;
extern BitmapPtr  bigbitmapP[16];
extern SystemPreferencesType SysPref; //100
extern char      *day[7];
extern char      *month[12];
extern char      stimer[4][12];
extern DateTimeType Time[wCount];
extern char help[256];
extern char      detailweek[12];
extern char      detailday[12];
extern char      detailhour[12];
extern int     timercommand;
extern WinHandle build;
extern BitmapPtr  Background;
extern char      salarmmode[2][12];
extern char      stimermode[7][14];




void ColorSet(Boolean i)
{
  if (is35)
  {
    if (i)
    {
      WinSetBackColor(prefs.colorbi);
      WinSetTextColor(prefs.colorfi);
      WinSetForeColor(prefs.colorfi);
    } else
    {
      WinSetBackColor(prefs.colorb);
      WinSetTextColor(prefs.colorf);
      WinSetForeColor(prefs.colorf);
    }
  }
}

void MySetFont(int n)
{
  if (isTRG)
    FntSetFont(VgaBaseToVgaFont(n));
  else
    FntSetFont(n);
}


void MyDrawChars3(const Char *chars, Int16 len,Coord x, Coord y,Boolean i)
{
   #ifdef debug
    debugs("MyDrawChars n","Start");
   #endif
   if (is35 && (Background != NULL))
   {
     WinPushDrawState();
     WinSetTextColor( 255 );
     WinSetBackColor( 0 );
     WinSetDrawMode( winMask );
     WinPaintChars( chars, len, x, y );
     WinPopDrawState();
     WinSetBackColor(255);
     WinSetDrawMode( winOverlay );
     WinPaintChars( chars, len, x, y );
   } else
   {
     WinDrawChars(chars,len,x,y);
   }
   #ifdef debug
    debugs("MyDrawChars n","Done");
   #endif
}

void MyDrawChars(const Char *chars, Int16 len,Coord x, Coord y,Boolean i)
{
  BitmapType *bitmap;
  WinHandle  win;
  WinHandle  oldwin;
  Int16 h;
  Int16 max;
  Int16 maxs;
  Boolean trunc;
  Err bmperror;
  RectangleType rc = {{0,0},{0,0}};

   #ifdef debug
    debugs("MyDrawChars","Start");
   #endif

  if (len>0)
  {
    if (iscolor || (Background != NULL))
    {
      if (is35)
        WinPushDrawState();
      max=160;
      maxs=len;
      FntCharsInWidth (chars,&max,&maxs,&trunc);
      h=FntCharHeight();


      if (prefs.screendepth != 16)
         bitmap= BmpCreate(max, h, prefs.screendepth, NULL, &bmperror);
      else
         bitmap= BmpCreate(max, h, 8 , NULL, &bmperror);
      win = WinCreateBitmapWindow(bitmap, &bmperror);
      oldwin=WinGetDrawWindow();
      WinSetDrawWindow(win);


      rc.extent.x = max;
      rc.extent.y = h;
      ColorSet(i);


      bitmap->flags.hasTransparency=1;

      WinEraseRectangle(&rc,0);

      if (i)
        bitmap->transparentIndex=prefs.colorbi;
      else
        bitmap->transparentIndex=prefs.colorb;

      /*
      if (prefs.screendeepth==16)
      {

      } */


      WinDrawChars(chars,len,0,0);

      WinSetDrawWindow(oldwin);

      if (is35)
      {
        WinSetBackColor(0);
        WinSetTextColor(1);
        WinSetForeColor(1);
      }
      WinDrawBitmap(bitmap,x,y);

      WinDeleteWindow(win,false);

      BmpDelete(bitmap);
      if (is35)
        WinPopDrawState();

    } else
    {
      WinDrawChars(chars,len,x,y);
    }
  }
   #ifdef debug
    debugs("MyDrawChars","done");
   #endif
}

// Display a big number
void DrawBigNumber(Boolean out,int num,UInt32 *x,UInt32 *y)
{
  if (out)
    WinDrawBitmap(bigbitmapP[num],*x,*y);
  else
  {
    if (bigbitmapP[num]->height > *y)
      *y=bigbitmapP[num]->height;
  }
  *x+=bigbitmapP[num]->width;
}

// Display AM or PM image
void DrawBigAMPM(Boolean out,int num,UInt32 *x,UInt32 *y)
{
  DrawBigNumber(out,num+14,x,y);
  //WinDrawBitmap(bigbitmapP[num+14],x,y);
}

// Display Big / : . *
void DrawBigSymbol(Boolean out,int num,UInt32 *x,UInt32 *y)
{
  DrawBigNumber(out,num+10,x,y);
  //WinDrawBitmap(bigbitmapP[num+10],x,y);
}

// Display a string in big
void DrawBig(char *text,int x, int y,int w, int h,UInt8 align)
{
  UInt32 xdraw;
  UInt32 ydraw;
  char *t;
  UInt8  m;

   #ifdef debug
    debugs("DrawBig",text);
    debugi("DrawBig X",x);
    debugi("DrawBig Y",y);
   #endif
  ColorSet(false);


  for (m=0 ; m<2 ; m++)
  {
    t=text;

    if (m==1)
    {
   #ifdef debug
    debugi("DrawBig w",w);
    debugi("DrawBig xdraw",xdraw);
    debugi("DrawBig w/2",w/2);
    debugi("DrawBig xdraw/2",xdraw/2);
   #endif
      //always center  vertical
      ydraw=(h / 2) - (ydraw / 2)+y;
     if (align==0)
     {
       //left
       xdraw=x;
     }  else if (align==1)
     {
       //center
        xdraw=(w / 2) - (xdraw / 2)+x;
     } else if (align==2)
     {
       xdraw=w-xdraw+x;
     }
   #ifdef debug
    debugi("DrawBig xdraw",xdraw);
    debugi("DrawBig Ydraw",ydraw);
   #endif
    } else
    {
      xdraw=0;
      ydraw=0;
    }

    while (*t != 0)
    {
      if ( (*t >= '0') && ( *t <= '9') )
      {
        DrawBigNumber(m==1,*t - '0',&xdraw,&ydraw);
      } else
      {
        switch (*t)
        {
           case 'a' : DrawBigAMPM(m==1,0,&xdraw,&ydraw);
                      break;
           case 'p' : DrawBigAMPM(m==1,1,&xdraw,&ydraw);
                      break;
           case '#' : //x+=24;
                      if (isTRG)
                        xdraw+=36;
                      else
                        xdraw+=24;
                      break;
           case '/' : DrawBigSymbol(m==1,0,&xdraw,&ydraw);
                      break;
           case ':' : DrawBigSymbol(m==1,1,&xdraw,&ydraw);
                      break;
           case '.' : DrawBigSymbol(m==1,2,&xdraw,&ydraw);
                      break;
           case '*' : DrawBigSymbol(m==1,3,&xdraw,&ydraw);
                      break;
           case ' ' : //x+=8;
                      if (isTRG)
                        xdraw+=12;
                      else
                        xdraw+=8;
                      break;
           default  : break;
        }
      }

      t++;
    }
  }
}


//draw date in normal font above the time
void DrawSmallDate(int num,int y)
{
  char text[30];

  DateToAscii(Time[num].month,Time[num].day,Time[num].year,SysPref.dateFormat,text);
  MySetFont(2);
  MyDrawChars(text,StrLen(text),panelwidth/2,y,false);
}

void DrawAlarmDays(int num,int x,int y)
{
  int iii;
  unsigned char bits[]={1,2,4,8,16,32,64,128,1};
  RectangleType rc={{x-1,y},{8,11}};
  Boolean i;
  int w;

  if (isTRG)
  {
    rc.extent.x=12;
    rc.extent.y=16;
    rc.topLeft.y=y+2;
  }


  //rc.extent.x = 8;
  MySetFont(0);
  for (iii=0 ; iii<7 ; iii++)
  {
    if (isTRG)
      rc.topLeft.x = x+iii*12-1;
    else
      rc.topLeft.x = x+iii*8-1;

    i=(prefs.world[num].days & bits[(iii+SysPref.weekStartDay) % 7]) != 0;
    if (is35)
    {
      ColorSet(i);
      if (i)
      {
        WinEraseRectangle(&rc,0);
      }
    }

    w=FntCharWidth(day[(iii+SysPref.weekStartDay) % 7][0]);
    if (isTRG)
      MyDrawChars(day[(iii+SysPref.weekStartDay) % 7],1,x+iii*12+5-(w /2),y+2,i);
    else
      MyDrawChars(day[(iii+SysPref.weekStartDay) % 7],1,x+iii*8+3-(w /2),y,i);
    if (i && (!is35))
      WinInvertRectangle(&rc,0);
  }

}

void DrawAlarmSound(int num,int x,int y)
{
  int iii;
  RectangleType rc={{x,0},{19,9}};
  char c= '1';

  //ColorSet(false);

  MySetFont(1);
  if (isTRG)
  {
    rc.extent.x=29;
    rc.extent.y=14;
  }

  for (iii=0; iii<4; iii++)
  {
    if (isTRG)
    {
      rc.topLeft.y = 24+y+iii*15;
    }  else
    {
      rc.topLeft.y = 16+y+iii*10;
    }

    if (is35)
    {
      ColorSet(prefs.world[num].options.sound==iii);
      if (prefs.world[num].options.sound==iii)
        {
          WinEraseRectangle(&rc,0);
        }
      if (isTRG)
        MyDrawChars(&c,1,x+10,24+y+iii*15-1,prefs.world[num].options.sound==iii);
      else
        MyDrawChars(&c,1,x+7,16+y+iii*10-1,prefs.world[num].options.sound==iii);

      ColorSet(false);
      WinDrawRectangleFrame(1,&rc);
    } else
    {
      rc.topLeft.y = 16+y+iii*10;
      WinEraseRectangle(&rc,0);
      WinDrawChars(&c,1,x+7,16+y+iii*10-1);
      WinDrawRectangleFrame(1,&rc);
      if (prefs.world[num].options.sound==iii)
        WinInvertRectangle(&rc,0);
    }
    c++;
  }
}

void DrawButton(char *t,Boolean i,int x, int y, int h, int w, int o)
{
  RectangleType rc={{x,y},{w,h}};
  MySetFont(2);


  if (is35)
  {
     //ColorSet(i);
     if (i)
     {
       WinSetForeColor(prefs.colorbi);
       WinDrawRectangle(&rc,5);
     }
     ColorSet(i);
     MyDrawChars(t,StrLen(t),(w / 2) - (FntCharsWidth(t,StrLen(t)) / 2) + x,y+o,i);
     WinDrawRectangleFrame(roundFrame,&rc);


  } else
  {
    if (i)
      {
        WinDrawRectangleFrame(roundFrame,&rc);
        rc.extent.x =w+2;
        rc.extent.y = h+2;
        rc.topLeft.x = x-1;
        rc.topLeft.y = y-1;
        WinDrawRectangle(&rc,7);
        WinEraseChars(t,StrLen(t),(w/2)-(FntCharsWidth(t,StrLen(t)) / 2)+x,y+o);
      }
    else
      {
        WinEraseRectangle(&rc,0);
        WinDrawRectangleFrame(roundFrame,&rc);
        WinDrawChars(t,StrLen(t),(w/2)-(FntCharsWidth(t,StrLen(t)) / 2)+x,y+o);
     }
  }

}


void DrawUpDown(int num,int x,int y)
{
  RectangleType rc={{x,0},{19,19}};
  int iii;
  char  d;
  Boolean i;

  if (isTRG)
  {
    rc.extent.x=29;
    rc.extent.y=29;
  }

  MySetFont(5);
  for (iii=0; iii<2; iii++)
  {
    if (isTRG)
      rc.topLeft.y = y+24+iii*30;
    else
      rc.topLeft.y = y+16+iii*20;

    d=iii+1;

    i=iii != prefs.world[num].options.timerup;
    if (is35)
    {
      ColorSet(i);
      if (i)
        WinEraseRectangle(&rc,0);
      if (isTRG)
        MyDrawChars(&d,1,x+7,y+33+iii*30,i);
      else
        MyDrawChars(&d,1,x+4,y+20+iii*22,i);
      ColorSet(false);
      WinDrawRectangleFrame(1,&rc);
    } else
    {
      WinEraseRectangle(&rc,0);
      WinDrawRectangleFrame(1,&rc);
      WinDrawChars(&d,1,x+4,y+20+iii*22);
      if (i)
        WinInvertRectangle(&rc,0);
    }
  }
}

void DrawTimerControls(int num,int y,Boolean small)
{
  char text[25];
  DateTimeType rel;

  MySetFont(2);

  if (isTRG)
  {
    if (small)
      DrawButton(stimer[prefs.world[num].options.active],prefs.world[num].options.active,4,y+24+33,26,65,4);
    else
      DrawButton(stimer[prefs.world[num].options.active],prefs.world[num].options.active,4,y+24,59,65,19);
    DrawButton(stimer[2],timercommand==1+10*num,88,y+24,26,65,4) ;
    DrawButton(stimer[3],timercommand==2+10*num,88,y+24+33,26,65,4);
    DrawUpDown(num,172,y);
    DrawAlarmSound(num,208,y);
  } else
  {
    if (small)
      DrawButton(stimer[prefs.world[num].options.active],prefs.world[num].options.active,3,y+16+22,17,43,2);
    else
      DrawButton(stimer[prefs.world[num].options.active],prefs.world[num].options.active,3,y+16,39,43,13);
    DrawButton(stimer[2],timercommand==1+10*num,59,y+16,17,43,2);
    DrawButton(stimer[3],timercommand==2+10*num,59,y+16+22,17,43,2);
    DrawUpDown(num,115,y);
    DrawAlarmSound(num,139,y);
  }


  if (!small)
  {
    if (prefs.world[num].options.daterelative==1)
    {
      StrCopy(text,"");
      MySetFont(1);
      TimSecondsToDateTime(prefs.world[num].date,&rel);
      DateToAscii(rel.month,rel.day,rel.year,SysPref.dateFormat,help);
      StrCat(text,help);
      TimeToAscii(rel.hour,rel.minute,SysPref.timeFormat,help);
      StrCat(text," - ");
      StrCat(text,help);
      MyDrawChars(text,StrLen(text),0,y+2,false);
    }  else if (prefs.world[num].options.calc==1)
    {
      if (prefs.world[num].calc >= 100)
      {
        StrIToA(text,prefs.world[num].calc / 100);
        StrCat(text,".");
      }
      else
        StrCopy(text,("0."));

      StrIToA(help,prefs.world[num].calc % 100);
      if (StrLen(help)==2)
        StrCat(text,help);
      else
      {
        StrCat(text,"0");
        StrCat(text,help);
      }

      StrCat(text," / hour");
      MySetFont(1);
      MyDrawChars(text,StrLen(text),0,y+2,false);
    }
  }
}

void DrawTiny(int size,int x,int y,int n)
{
  int a,b,c;

  if (size==1)
  {
    a=4;
    b=3;
    c=6;
  } else
  {
    a=2;
    b=2;
    c=4;
  }


  if (n & 1)
    WinDrawLine(x,y,x+a,y);
  if (n & 2)
    WinDrawLine(x,y,x,y+b);
  if (n & 4)
    WinDrawLine(x+a,y,x+a,y+b);
  if (n & 8)
    WinDrawLine(x,y+b,x+a,y+b);
  if (n & 16)
    WinDrawLine(x,y+b,x,y+c);
  if (n & 32)
    WinDrawLine(x+a,y+b,x+a,y+c);
  if (n & 64)
    WinDrawLine(x,y+c,x+a,y+c);
}

void TinyNumber(int size,int x,int y,int num)
{
  const int numbers[10] = {119,36,93,109,46,107,123,37,127,111};
  //if ((num >=0) && (num<=9))
  DrawTiny(size,x,y,numbers[num ]);
}



//draw the time
void DrawTime(int num,int y,Boolean alarm, Boolean timer,Boolean small)
{
  int h;
  int am;
  int sum;
  Boolean ShowDate;
  RectangleType rc;
  char time[9];
  Boolean special;
  unsigned char val1;
  unsigned char val2;
  char sep=':';

  MemSet(time,9,0);

  //display on set time screen?
  special=FrmGetActiveFormID() == formID_localtime;

  //display date above time?
  ShowDate=true;
  if (special)
     ShowDate=false;
  else
    {
      val1=prefs.pages[prefs.pageset][prefs.mode*2];
      val2=prefs.pages[prefs.pageset][prefs.mode*2+1];
      //upper and lower panel same worldtime
      if ((val1 & 7) == (val2 & 7))
      {
        //already a big date on upper or lower panel?
        sum= (val1 >> 3) + (val2 >> 3);
        if  ((sum==3) || (sum==10) || (sum==9))
          ShowDate=false;
      }
    }

  MySetFont(2);

  // if no am/pm and seconds center it
  /*
  if ((prefs.world[num].options.seconds==0) && (prefs.world[num].options.ampm==0) && (!special))
    prefs.world[num].add=24;
  else*/
  prefs.world[num].add=0;

  if (alarm)
  {
    if (isTRG)
      prefs.world[num].add=84;
    else
      prefs.world[num].add=56;
  }

  am=0;
  h=Time[num].hour;
  if (
       (prefs.world[num].options.ampm==1) &&
       (prefs.world[num].options.trigger != 3)
      )
  {
    am=1;
    if (h>=12)
     am=2;
    if (h>12)
     h-=12;
    if (h==0) h=12;
  }

  switch (SysPref.timeFormat)
  {
    case tfDot: case  tfDotAMPM: case  tfDot24h :
    {
       sep='.';
    }
    default: break;
  }


  time[0]=(h / 10) + '0';
  time[1]=(h % 10) + '0';
  time[2]=sep;

  time[3]=(Time[num].minute / 10) + '0';
  time[4]=(Time[num].minute % 10) + '0';

  if ((prefs.world[num].options.seconds==1) || (special))
  {
    time[5]=sep;
    time[6]=(Time[num].second / 10) + '0';
    time[7]=(Time[num].second % 10) + '0';
  }

  if (am!=0)
  {
    if ( (prefs.world[num].options.seconds==0) && (!alarm) && (!special))
    {
      time[5]=' ';
      if (am==1)
        time[6]='a';
      else
        time[6]='p';
    } else
    {
      // small am/pm
      rc.extent.x =15;
      rc.extent.y = 16;
      rc.topLeft.x = 130;
      rc.topLeft.y = y;
      //WinEraseRectangle(&rc,0);
      if (am==1)
        MyDrawChars("am",2,panelwidth-FntCharsWidth("am",2),y,false);
      else if (am==2)
        MyDrawChars("pm",2,panelwidth-FntCharsWidth("pm",2),y,false);
    }
  }
  if ((ShowDate) && (!alarm) && (!timer))
    DrawSmallDate(num,y);



   if (small)
     MyDrawChars(time,StrLen(time),3,y,false);
   else
     DrawBig(time,prefs.world[num].add,y+13,panelwidth-prefs.world[num].add,panelheight-16,1);
}


void DrawTime2(int y,int d,int h,int m,int s,Boolean small)
{
  char time [9];
  char sec[4];
  MemSet(time,9,0);

  time[2]='/';
  time[5]=':';
  while (d>=100)
    d-=100;

  time[0]=(d / 10) + '0';
  time[1]=(d % 10) + '0';
  time[3]=(h / 10) + '0';
  time[4]=(h % 10) + '0';
  time[6]=(m / 10) + '0';
  time[7]=(m % 10) + '0';

  if (small)
     MyDrawChars(time,StrLen(time),0,y,false);
  else
     DrawBig(time,0,y+13,panelwidth,panelheight-16,1);

  if ((s>=0) != small)
  {
    FntSetFont(2);
    StrIToA(sec,s);
    if (s<10)
    {
      sec[2]=sec[1];
      sec[1]=sec[0];
      sec[0]='0';
    }
    MyDrawChars(sec,StrLen(sec),140,y,false);
  }
}


void DrawAnalogTime(int num,int y)
{
  int iii;
  int dx,dy;
  int r1,r2,r3,r4,r5,yadd;
  int h,am;

  if (isTRG)
  {
    dx=180;
    dy=45+3;
    r1=43;
    r2=39;
    r3=5;
    r4=22;
    r5=35;
    yadd=21;
  } else
  {
    dx=28+90;
    dy=28+4;
    r1=28;
    r2=26;
    r3=4;
    r4=15;
    r5=22;
    yadd=14;
  }

  ColorSet(false);

  DrawCircle(r1,dx,dy);
  DrawCircle(r2,dx,dy);
  DrawCircle(r3,dx,dy);

  for (iii=0 ; iii< 12 ; iii++)
     WLine(iii*5,r2+1,r1-1,dx,dy);


  DrawZeiger((Time[num].hour % 12) *5 + (Time[num].minute / 12), r4, r3,dx,dy);
  DrawZeiger(Time[num].minute, r5,r3,dx,dy);
  if (prefs.world[num].options.seconds==1)
  {
    //DrawZeiger(Time[num].second, 25, 5,28+analogx,28+analogy);
    WLine(Time[num].second,r2-1,r3,dx,dy);

  }

  MySetFont(1);
  StrCopy(help,prefs.world[num].name);
  MyDrawChars( help,StrLen(help),8 ,y,false);
  MySetFont(2);

  MyDrawChars(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )],StrLen(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )]),8,y+yadd,false);
  DateToAscii(Time[num].month,Time[num].day,Time[num].year,SysPref.dateFormat,help);
  MyDrawChars(help,StrLen(help),8,y+yadd*2,false);


  if (prefs.world[num].options.ampm==1)
  {
    MySetFont(0);
    h=Time[num].hour;
    am=1;
    if (h>=12)
     am=2;
    if (am==1)
      MyDrawChars("am",2,panelwidth-FntCharsWidth("am",2),y,false);
    else if (am==2)
      MyDrawChars("pm",2,panelwidth-FntCharsWidth("pm",2),y,false);
  }

}

void DrawTimerTime(int num,int y,Boolean ns,Boolean small)
{
  long d,s,m,h,h2;
  unsigned long c;
  Boolean daymode;
  char o[8];
  int iii,jjj,kkk;



  d=0;
  h2=prefs.world[num].value / hoursInSeconds;
  h=h2;
  if (h>=24)
  {
    d=(h / 24);
    h=h-d*24;
    daymode=true;
  } else
    daymode=false;

  m=(prefs.world[num].value - h2 * hoursInSeconds) / minutesInSeconds;
  s=prefs.world[num].value - h2 * hoursInSeconds - m * minutesInSeconds;

  if  (prefs.world[num].options.calc)
  {
    if (prefs.world[num].calc < 36000)
      c=  (  (unsigned long)prefs.world[num].value *
             (unsigned long)prefs.world[num].calc
           ) /
              (unsigned long)3600;
    else
      c=  (   (unsigned long)prefs.world[num].calc /
              (unsigned long)3600
           ) *
              (unsigned long)prefs.world[num].value;
    StrIToA(help,c);

    MemSet(&o,7,'0');
    o[7]=0;
    iii=StrLen(help);
    kkk=iii;
    jjj=6;
    while ((iii>0) && (jjj>=0))
    {
      if (jjj!=4)
      {
        o[jjj]=help[iii-1];
        iii--;
      }
      jjj--;
    }
    o[4]='.';



    if (small)
     MyDrawChars(o,7,3,y,false);
    else
      DrawBig(o,0,y+16,panelwidth,panelheight-16,1);

  } else if (daymode)
  {
    if (((prefs.world[num].options.mode!=0) && (prefs.world[num].options.mode!=3)) || ns)
      s=-1;
    DrawTime2(y,d,h,m,s,small);
  }  else
  {

    Time[num].second=s;
    Time[num].minute=m;
    Time[num].hour=h;
    DrawTime(num,y,false,true,small);
  }

  if ((prefs.world[num].options.active==1) && (prefs.world[num].options.autooff==1))
    EvtResetAutoOffTimer();
}

void DrawTwoTimes(int num,int y)
{
  char text[30];
  int iii;
  int yadd;

  if (isTRG)
    yadd=21;
  else
    yadd=14;  

  for (iii=0 ; iii<2; iii++)
  {
    MySetFont(1);
    MyDrawChars(prefs.world[num+iii].name,StrLen(prefs.world[num+iii].name),iii*(panelwidth/2),y,false);
    MySetFont(2);
    MyDrawChars(day[DayOfWeek( Time[num+iii].month, Time[num+iii].day, Time[num+iii].year )],StrLen(day[DayOfWeek( Time[num+iii].month, Time[num+iii].day, Time[num+iii].year )]),iii*(panelwidth /2),y+yadd,false);
    DateToAscii(Time[num+iii].month,Time[num+iii].day,Time[num+iii].year,SysPref.dateFormat,text);
    MyDrawChars(text,StrLen(text),iii*(panelwidth /2),y+yadd*2,false);
    TimeToAscii(Time[num+iii].hour,Time[num+iii].minute,SysPref.timeFormat,text);
    MyDrawChars(text,StrLen(text),iii*(panelwidth/2),y+yadd*3,false);
  }
}

void DrawDateDetail(int num,int y)
{
  char text[30];
  char number[10];
  int  x1,x2,x3,xdraw,xdraw2;
  Long data[6];
  int yadd;

  if (isTRG)
    yadd=21;
  else
    yadd=14;

  CalcDateData(Time[num],& data[0]);

  //Weekday
  MySetFont(2);
  MyDrawChars(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )],StrLen(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )]),0,y,false);

  //Date
  DateToAscii(Time[num].month,Time[num].day,Time[num].year,SysPref.dateFormat,text);
  MyDrawChars(text,StrLen(text),80,y,false);

  x1=FntCharsWidth(detailweek,StrLen(detailweek));
  x2=FntCharsWidth(detailweek,StrLen(detailday));
  x3=FntCharsWidth(detailweek,StrLen(detailhour));
  if (x1>x2)
  {
    if (x1>x3)
      xdraw=x1;
    else
      xdraw=x3;
  } else
  {
    if (x2>x3)
      xdraw=x2;
    else
      xdraw=x3;
  }
  xdraw+=8;
  //StrIToA(number,hourleft);
  StrIToA(number,data[5]);
  xdraw2=FntCharsWidth(number,StrLen(number))+16+xdraw;

  //Hour
  MyDrawChars(detailhour,StrLen(detailhour),0,y+3*yadd,false);
  //StrIToA(text,hour);
  StrIToA(text,data[4]);
  MyDrawChars(text,StrLen(text),xdraw,y+3*yadd,false);

  StrCopy(text,"(");
  StrCat(text,number);
  StrCat(text,")");
  MyDrawChars(text,StrLen(text),xdraw2,y+3*yadd,false);

  //Week
  MyDrawChars(detailweek,StrLen(detailweek),0,y+yadd,false);
  StrIToA(text,data[0]);
  MyDrawChars(text,StrLen(text),xdraw,y+yadd,false);

  StrIToA(number,data[1]);
  StrCopy(text,"(");
  StrCat(text,number);
  StrCat(text,")");
  MyDrawChars(text,StrLen(text),xdraw2,y+yadd,false);

  //Day
  MyDrawChars(detailday,StrLen(detailday),0,y+2*yadd,false);
  StrIToA(text,data[2]);
  MyDrawChars(text,StrLen(text),xdraw,y+2*yadd,false);

  StrIToA(number,data[3]);
  StrCopy(text,"(");
  StrCat(text,number);
  StrCat(text,")");
  MyDrawChars(text,StrLen(text),xdraw2,y+2*yadd,false);

}

void DrawDate(int num,int y)
{
  int       year;
  int       dp;
  int       mp;
  int       yp;
  Int8      sep;
  char      date[8];
  char      sepchar[]={'/',':','.','*'};

  date[8]=0;

  //draw the weekday
  MySetFont(2);
  MyDrawChars(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )],StrLen(day[DayOfWeek( Time[num].month, Time[num].day, Time[num].year )]),0,y,false);

  //calculate the format
  sep=0;
  dp=3;
  mp=0;
  yp=6;

  switch (SysPref.dateFormat)
  {
    case dfMDYWithSlashes: {
                             sep=0;
                             dp=3;
                             mp=0;
                             yp=6;
                             break;
                           }
    case dfDMYWithDashes: {
                             sep=3;
                             dp=0;
                             mp=3;
                             yp=6;
                             break;
                          }
    case dfDMYWithDots:  {
                             sep=2;
                             dp=0;
                             mp=3;
                             yp=6;
                             break;
                          }
    case dfDMYWithSlashes:
                           {
                             sep=0;
                             dp=0;
                             mp=3;
                             yp=6;
                             break;
                           }
    case dfYMDWithDashes: {
                             sep=3;
                             dp=6;
                             mp=3;
                             yp=0;
                             break;
                          }
    case dfYMDWithDots: {
                             sep=2;
                             dp=6;
                             mp=3;
                             yp=0;
                             break;
                         }
    case dfYMDWithSlashes:
                           {
                             sep=0;
                             dp=6;
                             mp=3;
                             yp=0;
                             break;
                           }
    default: break;                       
    }

    //symbol
    date[2]=sepchar[sep];
    date[5]=sepchar[sep];

    //Day
    date[dp]=(Time[num].day / 10) + '0';
    date[dp+1]=(Time[num].day % 10) + '0';

    //Month
    date[mp]=(Time[num].month / 10) + '0';
    date[mp+1]=(Time[num].month % 10) + '0';

    //Year
    year=Time[num].year % 100;

    date[yp]=(year / 10) + '0';
    date[yp+1]=(year % 10) + '0';

    //Draw the date
    DrawBig(date,0,y+16,panelwidth,panelheight-16,1);
}

void DrawMonthView(int num,int y,Boolean r)
{
  int iii;
  int jjj;
  int kkk;
  int d;
  int s;
  RectangleType rc;
  char help2[5];
  char daytext[4];
  int mo;
  int yo;
  DateTimeType old;
  Long data[6];
  DateTimeType week;
  Boolean wd;
  int w;

   #ifdef debug
    debugs("DrawMonthView","Start");
   #endif

  ColorSet(false);
  TimSecondsToDateTime(prefs.world[num].last,&old);

  if (isTRG)
  {
    MySetFont(1);
    for (iii=0 ; iii<7 ; iii++)
    {
      w=FntCharWidth(day[(iii+SysPref.weekStartDay) % 7][0]);
      MyDrawChars(day[(iii+SysPref.weekStartDay) % 7],1,12+iii*17-(w /2),y,false);
    }

  } else
  {
    FntSetFont(1);
    for (iii=0 ; iii<7 ; iii++)
    {
      w=FntCharWidth(day[(iii+SysPref.weekStartDay) % 7][0]);
      MyDrawChars(day[(iii+SysPref.weekStartDay) % 7],1,3+iii*11+5-(w /2),y,false);
    }
  }



  mo=((Time[num].month-1)+prefs.world[num].monthoffset+12*100) % 12;

  if (prefs.world[num].monthoffset<0)
    yo=Time[num].year+( Time[num].month+prefs.world[num].monthoffset-12) / 12;
  else
    yo=Time[num].year+( Time[num].month+prefs.world[num].monthoffset-1) / 12;

  d=DaysInMonth(mo+1,yo);
  s=DayOfWeek(mo+1,1,yo);
  jjj=(s-SysPref.weekStartDay+7) % 7;
  kkk=1;
  iii=0;

  week=Time[num];
  week.month=mo+1;
  week.year=yo;
  wd=false;

  if (isTRG)
  {
    rc.extent.x =14;
    rc.extent.y = 9;
  } else
  {
    rc.extent.x =9;
    rc.extent.y = 7;
  }

   #ifdef debug
    debugs("DrawMonthView","calc done");
   #endif

  while ((iii<7) && (kkk<=d))
  {
    if (isTRG)
    {
      rc.topLeft.x = jjj*17+1+2;
      rc.topLeft.y = iii*10+y+15;
    } else
    {
      rc.topLeft.x = 3+jjj*11;
      rc.topLeft.y = iii*6+y+11;
    }

   #ifdef debug
    debugs("DrawMonthView","erase");
   #endif

   if (is35)
   {
     if ((kkk==Time[num].day) && (yo==Time[num].year) && ((mo+1)==Time[num].month))
     {
       ColorSet(true);
       WinEraseRectangle(&rc,0);
     }
       else
     {
       ColorSet(false);
     }
   } else
     WinEraseRectangle(&rc,0);

   #ifdef debug
    debugs("DrawMonthView","drawtiny");
   #endif
   if (isTRG)
   {
     if ((kkk/10) != 0)
      {
        TinyNumber(1,4+jjj*17,iii*10+y+16,kkk / 10);
        TinyNumber(1,4+jjj*17+7,iii*10+y+16,kkk % 10);
      }
      else
        TinyNumber(1,4+jjj*17+5,iii*10+y+16,kkk % 10);
   } else
   {
      if ((kkk/10) != 0)
      {
        TinyNumber(0,4+jjj*11,iii*6+y+12,kkk / 10);
        TinyNumber(0,4+jjj*11+4,iii*6+y+12,kkk % 10);
      }
      else
        TinyNumber(0,4+jjj*11+2,iii*6+y+12,kkk % 10);
    }

   #ifdef debug
    debugs("DrawMonthView","invert?");
   #endif

    if (! is35)
      if ((kkk==Time[num].day) && (yo==Time[num].year) && ((mo+1)==Time[num].month))
        WinInvertRectangle(&rc,0);

   #ifdef debug
    debugs("DrawMonthView","draw week");
   #endif

    if ((! wd) && (jjj>0))
    {
      ColorSet(false);

      wd=true;
      week.day=kkk;
      CalcDateData(week,&data[0]);
      if (isTRG)
      {
        if ((data[0] / 10) != 0)
        {
          TinyNumber(1,132,iii*10+y+16,data[0] / 10);
          TinyNumber(1,132+7,iii*10+y+16,data[0] % 10);
        } else
          TinyNumber(1,132+7,iii*10+y+16,data[0] % 10);
      } else
      {
        if ((data[0] / 10) != 0)
        {
          TinyNumber(0,92-4,iii*6+y+12,data[0] / 10);
          TinyNumber(0,92,iii*6+y+12,data[0] % 10);
        } else
          TinyNumber(0,92,iii*6+y+12,data[0] % 10);
      }

    }

    jjj++;
    if (jjj>=7)
      {
        wd=false;
        iii++;
        jjj=0;
      }
    kkk++;
  }
   #ifdef debug
    debugs("DrawMonthView","tiny done");
   #endif

  ColorSet(false);

  MySetFont(0);
  StrCopy(help,month[mo]);
  StrIToA(help2,yo);
  StrCat(help," ");
  StrCat(help,help2);
  iii=FntCharsWidth(help,StrLen(help));
  if (isTRG)
  {
    MyDrawChars( help,StrLen(help),(panelwidth/4)-(iii /2),panelheight-FntCharHeight() ,false);
  } else
  {
    MyDrawChars( help,StrLen(help),(panelwidth/4)-(iii /2),panelheight-FntCharHeight(),false);
  }

  MySetFont(2);
  StrCopy(help,month[Time[num].month-1]);
  iii=FntCharsWidth(help,StrLen(help));
  MyDrawChars( help,StrLen(help),panelwidth-iii,y,false);

  if ((Time[num].day / 10) != 0)
    daytext[0]=(Time[num].day / 10) + '0';
  else
    daytext[0]='#';
  daytext[1]=(Time[num].day % 10) + '0';
  daytext[2]=0;

   #ifdef debug
    debugs("DrawMonthView","draw big");
   #endif

  DrawBig(daytext,0,y+16,panelwidth,panelheight-16,2);

   #ifdef debug
    debugs("DrawMonthView","done");
   #endif
}


void DrawSilkMonth(int off,int x,int y)
{
  int iii;
  int jjj;
  int kkk;
  int d;
  int s;
  RectangleType rc;
  char help2[5];
  //char daytext[4];
  int mo;
  int yo;
  DateTimeType old;
  //Long data[6];
  //DateTimeType week;
  int w;

   #ifdef debug
    debugs("DrawMonthView","Start");
   #endif

  ColorSet(false);
  TimSecondsToDateTime(prefs.world[0].last,&old);

  FntSetFont(1);
  for (iii=0 ; iii<7 ; iii++)
  {
    w=FntCharWidth(day[(iii+SysPref.weekStartDay) % 7][0]);
    MyDrawChars(day[(iii+SysPref.weekStartDay) % 7],1,x+iii*11+5-(w /2),y,false);
  }



  mo=((Time[0].month-1)+off+12*100) % 12;

  if (prefs.world[0].monthoffset<0)
    yo=Time[0].year+( Time[0].month+off-12) / 12;
  else
    yo=Time[0].year+( Time[0].month+off-1) / 12;

  d=DaysInMonth(mo+1,yo);
  s=DayOfWeek(mo+1,1,yo);
  jjj=(s-SysPref.weekStartDay+7) % 7;
  kkk=1;
  iii=0;

  rc.extent.x =9;
  rc.extent.y = 7;

  while ((iii<7) && (kkk<=d))
  {
    rc.topLeft.x = x+jjj*11;
    rc.topLeft.y = iii*6+y+11;

   #ifdef debug
    debugs("DrawMonthView","erase");
   #endif

   if ((kkk==Time[0].day) && (yo==Time[0].year) && ((mo+1)==Time[0].month))
    {
      ColorSet(true);
      WinEraseRectangle(&rc,0);
    }
      else
    {
      ColorSet(false);
    }

    if ((kkk/10) != 0)
    {
      TinyNumber(0,x+jjj*11,iii*6+y+12,kkk / 10);
      TinyNumber(0,x+jjj*11+4,iii*6+y+12,kkk % 10);
    }
    else
      TinyNumber(0,x+jjj*11+2,iii*6+y+12,kkk % 10);

    jjj++;
    if (jjj>=7)
      {
        iii++;
        jjj=0;
      }
    kkk++;
  }

  ColorSet(false);

  FntSetFont(0);
  StrCopy(help,month[mo]);
  StrIToA(help2,yo);
  StrCat(help," ");
  StrCat(help,help2);
  iii=FntCharsWidth(help,StrLen(help));
  MyDrawChars( help,StrLen(help),(panelwidth/6)-(iii /2)+x,y+48 ,false);
}




void DrawAlarmCheck(int num, int y)
{
  Boolean	ignored;
  //char		ellipsisChar = 0x85; //horizEllipsisChr;
  SWord		itemTextLen;
  SWord		itemWidth;
  CharPtr	itemTextP;
  BigClockAlarm alarm;
  DmOpenRef     BCdb;
  RectangleType rc={{3,y+18},{20,20}};

  if (isTRG)
  {
    rc.topLeft.x=6;
    rc.topLeft.y=24+y+2;
    rc.extent.x=30;
    rc.extent.y=30;
  }


  ColorSet(false);
  //WinEraseRectangle(&rc,0);
  WinDrawRectangleFrame(3,&rc);

  //remove checked if trigger=once and already done
  if (prefs.world[num].options.trigger==2)
    {
      BCdb=OpenAlarm();
      ReadAlarm(BCdb,num-5,&alarm);
      CloseAlarm(BCdb);
      if (alarm.options.active==0)
        prefs.world[num].options.active=0;
    }

   //draw the cross
  if (prefs.world[num].options.active==1)
  {
    WinDrawLine(rc.topLeft.x,rc.topLeft.y,rc.topLeft.x+rc.extent.x,rc.topLeft.y+rc.extent.y);
    WinDrawLine(rc.topLeft.x,rc.topLeft.y+1,rc.topLeft.x+rc.extent.x-1,rc.topLeft.y+rc.extent.y);
    WinDrawLine(rc.topLeft.x+1,rc.topLeft.y,rc.topLeft.x+rc.extent.x,rc.topLeft.y+rc.extent.y-1);

    WinDrawLine(rc.topLeft.x-1+rc.extent.x,rc.topLeft.y,rc.topLeft.x-1,rc.topLeft.y+rc.extent.y);
    WinDrawLine(rc.topLeft.x-1-1+rc.extent.x,rc.topLeft.y,rc.topLeft.x-1,rc.topLeft.y+rc.extent.y-1);
    WinDrawLine(rc.topLeft.x-1+rc.extent.x,rc.topLeft.y+1,rc.topLeft.x+1-1,rc.topLeft.y+rc.extent.y);

    /*
    WinDrawLine(3,y+18,23,y+38);
    WinDrawLine(3,y+19,22,y+38);
    WinDrawLine(4,y+18,23,y+37);

    WinDrawLine(23,y+18,3,y+38);
    WinDrawLine(22,y+18,3,y+37);
    WinDrawLine(23,y+19,4,y+38);
    */
  }

  FntSetFont(0);
  if (prefs.world[num].options.base>0)
  {
    if (isTRG)
      itemWidth = 48;
    else
      itemWidth = 32;
    itemTextLen = 160;
    itemTextP = prefs.world[wLocal+prefs.world[num].options.base].name;

    FntCharsInWidth(itemTextP, &itemWidth, &itemTextLen, &ignored);
    MyDrawChars(itemTextP, itemTextLen, 0,rc.topLeft.y+rc.extent.y+4,false);
  }
}


void SwitchDrawSection(int val,int y,Boolean sw)
{
  int iii;
  unsigned char pan;
  unsigned char num;
  char text[64];
  char help[32];
  DateTimeType rel;
  WinHandle old;
  RectangleType all = {{0,0},{panelwidth,panelheight}};
  Int16 width;
  Int16 length;
  Boolean trunc;
  //UInt8  sub;

  //FrmCustomAlert(alertID_text,"switchdraw",NULL,NULL);

   #ifdef debug
    debugs("SwitchDrawSection","Start");
   #endif


  old=WinGetDrawWindow();
  WinSetDrawWindow(build);

   #ifdef debug
    debugs("SwitchDrawSection","Window set");
   #endif

  if (is35)
  {
   #ifdef debug
    debugs("SwitchDrawSection","is35");
   #endif
    ColorSet(false);
     /*
    WinSetForeColor(prefs.colorf);
    WinSetTextColor(prefs.colorf);
    WinSetBackColor(prefs.colorb);
    */

   #ifdef debug
    debugs("SwitchDrawSection","background");
   #endif
    if (Background != NULL)
    {
      if (y==ytop)
        WinDrawBitmap(Background,0,0);
      else
        WinDrawBitmap(Background,0,-panelheight);
    } else
    {
      WinSetForeColor(prefs.colorb);
      WinDrawRectangle(&all,0);
    }

  }  else
  {
    WinEraseWindow();
  }

  pan=val >> 3;
  num= val & 7;

   #ifdef debug
    debugs("SwitchDrawSection","switch");
   #endif

  switch (pan)
  {
    case pnEmpty: {
                     /*
                     id=MemHeapID(0,0);
                      if (MemHeapDynamic(id))
                      {
                        MemHeapFreeBytes(id,&s,&m);
                        StrIToA(help,s);
                        WinDrawChars(help,StrLen(help),10,y+2);
                      }*/
                    break;
                  }
    case pnDate: {
              DrawDate(wLocal+num,0);
              break;
            }
    case pnTime:  {
              MySetFont(2);
              width=panelwidth / 2;
              length=11;
              FntCharsInWidth(prefs.world[wLocal+num].name,&width,&length,&trunc);
              MyDrawChars(prefs.world[wLocal+num].name,length,0,ymove,false);
              if (isTRG)
                DrawTime(wLocal+num,ymove+4,false,false,false);
              else
                DrawTime(wLocal+num,ymove,false,false,false);

              break;
            }
    case pnAlarm: {
              TimSecondsToDateTime(prefs.world[wAlarm1+num].value,&Time[wAlarm1+num]);
              MySetFont(2);

              width=panelwidth/2;
              length=11;
              FntCharsInWidth(prefs.world[wAlarm1+num].name,&width,&length,&trunc);
              MyDrawChars(prefs.world[wAlarm1+num].name,length,0,ymove,false);

              DrawAlarmCheck(wAlarm1+num,ymove);
              if (isTRG)
                DrawTime(wAlarm1+num,ymove+4,true,false,false);
              else
                DrawTime(wAlarm1+num,ymove,true,false,false);

              if (prefs.world[wAlarm1+num].options.trigger==1)
              {
                DrawAlarmDays(wAlarm1+num,(panelwidth /2)+1,ymove);
              }
              else
                MyDrawChars(salarmmode[prefs.world[wAlarm1+num].options.trigger-2],StrLen(salarmmode[prefs.world[wAlarm1+num].options.trigger-2]),panelwidth/2,ymove,false);

              if (isTRG)
                 DrawAlarmSound(wAlarm1+num,50,ymove);
              else
                 DrawAlarmSound(wAlarm1+num,34,ymove);
                /*
              if (prefs.world[wAlarm1+num].options.ampm==0)
                ShowRegions(pnAlarm,1);
              else
                ShowRegions(pnAlarm,3);
                */

              break;
            }
    case pnTimer: case pnCTimer:{
              MySetFont(2);


              width=panelwidth /2;
              length=11;
              FntCharsInWidth(prefs.world[wTimer1+num].name,&width,&length,&trunc);
              MyDrawChars(prefs.world[wTimer1+num].name,length,0,ymove,false);



              if (pan==pnTimer)
              {
                if (isTRG)
                  DrawTimerTime(wTimer1+num,ymove+4,false,false);
                else
                  DrawTimerTime(wTimer1+num,ymove,false,false);
              }
              else
              {
                if (isTRG)
                  DrawTimerTime(wTimer1+num,ymove+29,false,true);
                else
                  DrawTimerTime(wTimer1+num,ymove+18,false,true);
                DrawTimerControls(wTimer1+num,ymove,true);
                /*
                DrawButton(stimer[prefs.world[wTimer1+num].options.active],prefs.world[wTimer1+num].options.active,3,ymove+22+16,17,43,2);
                DrawButton(stimer[2],timercommand==1+10*(wTimer1+num),59,ymove+16,17,43,2);
                DrawButton(stimer[3],timercommand==2+10*(wTimer1+num),59,ymove+22+16,17,43,2);
                DrawUpDown(wTimer1+num,ymove);
                DrawAlarmSound(wTimer1+num,139,ymove);
                */
              }
              ColorSet(false);
              iii=prefs.world[wTimer1+num].options.mode;
              if (iii>6)
              {
                prefs.world[wTimer1+num].options.mode=3;
                iii=3;
              }
              MySetFont(2);
              MyDrawChars(stimermode[iii],StrLen(stimermode[iii]),panelwidth/2,ymove,false);
              break;
            }
    case pnVTimer: {
                    StrCopy(text,prefs.world[wTimer1+num].name);
                    MySetFont(1);
                    if (prefs.world[wTimer1+num].options.daterelative==1)
                    {
                      StrCat(text," - ");
                      //MySetFont(1);
                      TimSecondsToDateTime(prefs.world[wTimer1+num].date,&rel);
                      DateToAscii(rel.month,rel.day,rel.year,SysPref.dateFormat,help);
                      StrCat(text,help);
                      TimeToAscii(rel.hour,rel.minute,SysPref.timeFormat,help);
                      StrCat(text," - ");
                      StrCat(text,help);

                    }
                    iii=FntCharsWidth(text,StrLen(text));
                    MyDrawChars(text,StrLen(text),(panelwidth /2 )-(iii/2),ymove+2,false);
                    if (isTRG)
                      DrawTimerTime(wTimer1+num,ymove+4,true,false);
                    else
                      DrawTimerTime(wTimer1+num,ymove,true,false);
                      break;
                   }
    case pnControl:{
               DrawTimerControls(wTimer1+num,ymove,false);
               break;
             }
    case pnWorld: {
               DrawTwoTimes(wLocal+num*2+1,ymove);
               break;
             }
    case pnDateD: {
               DrawDateDetail(wLocal+num,ymove);
               break;
             }
    case pnMonth:
   #ifdef debug
    debugs("SwitchDrawSection","month");
   #endif

              DrawMonthView(wLocal+num,ymove,true);
   #ifdef debug
    debugs("SwitchDrawSection","month done");
   #endif
              break;
    case pnAnalog:
              DrawAnalogTime(wLocal+num,ymove);
              break;
    default: break;


  }
   #ifdef debug
    debugs("SwitchDrawSection","switch done");
   #endif

  WinSetDrawWindow(old);
  //the offscreen image is already in the right colors, dont invert again on copyrectangle
  if (is35)
  {
    WinSetBackColor(0);
    WinSetTextColor(1);
    WinSetForeColor(1);
  }
   #ifdef debug
    debugs("SwitchDrawSection","copy");
   #endif

  WinCopyRectangle(build,old,&all,0,y,winPaint);

   #ifdef debug
    debugs("SwitchDrawSection","done");
   #endif


}
