
//for analog clock
const int yv[61] = {-512,-509,-500,-486,-467,-443,-414,-380,-342,-300,-256,-208,-158,-106,-53,0,53,106,158,208,255,300,342,380,414,443,467,486,500,509,512,509,500,486,467,443,414,380,342,300,256,208,158,106,53,0,-53,-106,-158,-208,-256,-300,-342,-380,-414,-443,-467,-486,-500,-509,-512};
const int xv[61] = {0,53,106,158,208,256,300,342,380,414,443,467,486,500,509,512,509,500,486,467,443,414,380,342,300,256,208,158,106,53,0,-53,-106,-158,-208,-255,-300,-342,-380,-414,-443,-467,-486,-500,-509,-512,-509,-500,-486,-467,-443,-414,-380,-342,-300,-256,-208,-158,-106,-53,0};

//Boolean	HwrBacklight2(Boolean set, Boolean newState) SYS_TRAP(sysTrapHwrBacklightV33);


void CalcDateData(DateTimeType now,Long *data) SEG_UTIL;

void CalcDateData(DateTimeType now,Long *data)
{
  /*
  0 week
  1 weekleft
  2 day
  3 dayleft
  4 hour
  5 hourleft
  */
  DateTimeType  start;
  DateTimeType  end;
  Long wstart;
  Long ends;
  Long nows;
  Long starts;
  int dummy;

  //init start and end
  start=now;
  start.month=1;
  start.day=1;
  start.minute=0;
  start.hour=0;
  start.second=0;

  end=now;
  end.month=12;
  end.day=31;
  end.minute=59;
  end.hour=23;
  end.second=59;

  nows=TimDateTimeToSeconds(&now);
  starts=TimDateTimeToSeconds(&start);
  ends=TimDateTimeToSeconds(&end);

  //day
  data[2]=nows-starts;
  data[2]=(data[2] / (long) daysInSeconds)  +1;
  data[3]=ends-nows;
  data[3]=(data[3] / (long) daysInSeconds)  ;

  //hour
  data[4]=(nows-starts) / (Long)(60*60) +1;
  data[5]=(ends-nows) / (Long)(60*60) ;

  //week
  wstart= DayOfWeek( start.month, start.day, start.year );
  if (wstart==0)
    wstart=7;
  if (wstart<5)
    dummy=1;
  else
    dummy=0;
  data[0]=(data[2]-(8-wstart)+6) / 7 + dummy;
  data[1]=52-data[0]; //(data[3]-(8-wstart)+6) / 7 - dummy;
}

void DisplayNum(int number) SEG_UTIL;

void DisplayNum(int number)
{
  char text[30];
  StrIToA(text,number);
  FrmCustomAlert(alertID_text,text,NULL,NULL);
}

void SetFieldText(int id_in, char *text_in_t, UInt length) SEG_UTIL;

void SetFieldText(int id_in, char *text_in_t, UInt length)
{
  char *new_field_t;
  FieldPtr field_p;
  VoidHand old_handle;
  VoidHand new_handle;
  int field_index;
  //int field_empty_flag=0;

  field_index = FrmGetObjectIndex(FrmGetActiveForm(), id_in);
  field_p = FrmGetObjectPtr(FrmGetActiveForm(), field_index);

  if (field_p == NULL)
    return;

  old_handle = (VoidHand) FldGetTextHandle(field_p);
  new_handle = MemHandleNew(length) ;
  new_field_t = MemHandleLock(new_handle);
  StrCopy(new_field_t, text_in_t);

  FldSetTextHandle(field_p, (Handle) new_handle);
  MemHandleUnlock(new_handle);

  if (old_handle == NULL)
    return;
  MemHandleFree(old_handle);
  }

void GetFieldText(int id,char *target) SEG_UTIL;

void GetFieldText(int id,char *target) 
{
  FieldPtr field_p;
  int field_index;
  VoidHand old_handle;
  char *new_field_t;

  field_index = FrmGetObjectIndex(FrmGetActiveForm(), id);
  field_p = FrmGetObjectPtr(FrmGetActiveForm(), field_index);
  old_handle = (VoidHand) FldGetTextHandle(field_p);
  new_field_t = MemHandleLock(old_handle);
  StrCopy(target,new_field_t);
  MemHandleUnlock(old_handle);
}

void ShowEdit(int start) SEG_UTIL;

void ShowEdit(int start)
{
  FormPtr form;
  form= FrmGetActiveForm ();
  FrmShowObject(form, FrmGetObjectIndex(form,start));
}

void SetUsable(int start,Boolean b) SEG_UTIL;
void SetUsable(int start,Boolean b)
{
  FormPtr form;
  FieldPtr field;

  form= FrmGetActiveForm ();
  field=FrmGetObjectPtr(form,FrmGetObjectIndex(form,start));
  if (!b)
    FldReleaseFocus(field);
  FldSetUsable(field,b);
}

void HideEdit(int start) SEG_UTIL;

void HideEdit(int start)
{
  FormPtr form;
  form= FrmGetActiveForm ();
  FrmHideObject(form, FrmGetObjectIndex(form,start));
}

void SetCheckBox(int id,short b) SEG_UTIL;
void SetCheckBox(int id,short b)
{
   FormPtr   form;
   ControlPtr check;

   form = FrmGetActiveForm();
   check = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,id));
   CtlSetValue(check, b);
}

Int GetCheckBox(int id) SEG_UTIL;
Int GetCheckBox(int id)
{
   FormPtr   form;
   ControlPtr check;

   form = FrmGetActiveForm();
   check = (ControlPtr)FrmGetObjectPtr(form, FrmGetObjectIndex(form,id));
   return CtlGetValue(check);
}

void ChangeVisible(int num,Boolean h) SEG_UTIL;
void ChangeVisible(int num,Boolean h)
{
  if (h)
    HideEdit(num);
  else
    ShowEdit(num);
}

//draw a line in the circle
void WLine(int w,int r1,int r2,int xa,int ya) SEG_UTIL;
void WLine(int w,int r1,int r2,int xa,int ya)
{
  int x1,x2,y1,y2;

  x1=((xv[w] * r1 ) / 512) + xa;
  y1=((yv[w] * r1 ) / 512) + ya;

  x2=((xv[w] * r2 ) / 512) + xa;
  y2=((yv[w] * r2 ) / 512) + ya;

  WinDrawLine(x1,y1,x2,y2);
}

void DrawZeiger(int w,int l, int s, int xa, int ya) SEG_UTIL;
void DrawZeiger(int w,int l, int s, int xa, int ya)
{
  int x1,x2,x3,y1,y2,y3;

  x1=((xv[w] * l ) / 512) + xa;
  y1=((yv[w] * l ) / 512) + ya;

  x2=((xv[(w+8) % 60] * s ) / 512) + xa;
  y2=((yv[(w+8) % 60] * s ) / 512) + ya;

  x3=((xv[(w+52) % 60] * s ) / 512) + xa;
  y3=((yv[(w+52) % 60] * s ) / 512) + ya;

  WinDrawLine(x1,y1,x2,y2);
  WinDrawLine(x1,y1,x3,y3);
}

void DrawCircle(int r,int xa,int ya) SEG_UTIL;
void DrawCircle(int r,int xa,int ya)
{
  int iii;
  int x1,x2,y1,y2;
  for (iii=0;iii < 60 ; iii++)
  {
     x1=((xv[iii] * r ) / 512) + xa;
     y1=((yv[iii] * r ) / 512) + ya;
     x2=((xv[iii+1] * r ) / 512) + xa;
     y2=((yv[iii+1] * r ) / 512) + ya;
     WinDrawLine(x1,y1,x2,y2);
  }
}




