// New Consts
#define numpanels   16
#define numpages    numpanels / 4
#define maxthemes   16
#define numpanelkind  12

#define maxnumworld 16
#define maxnumtimer 8
#define maxnumalarm 8

#define helpmaxlinehight 32
#define helpmaxlinks     32
#define helpmaxlines     64
#define halpmaxhistory   32

//#define analogx          90
//#define analogy          4

#define numtimeslots maxnumworld+maxnumtimer+maxnumalarm
#define worldstart 0
#define timerstart worldstart+maxnumworld
#define alarmstart timerstart+maxnumtimer


// Timelist
#define wCount    13
#define aCount    8

#define wLocal     0
#define wWorld1    1
#define wWorld2    2
#define wWorld3    3
#define wWorld4    4

#define wTimer1    5        //0   number in Alarmlist
#define wTimer2    6        //1
#define wTimer3    7        //2
#define wTimer4    8        //3

#define wAlarm1    9        //4
#define wAlarm2   10        //5
#define wAlarm3   11        //6
#define wAlarm4   12        //7

//PageList

#define pnEmpty    0
#define pnTime     1
#define pnMonth    2
#define pnDate     3
#define pnDateD    4
#define pnAlarm    5
#define pnTimer    6
#define pnControl  7
#define pnCTimer   8
#define pnVTimer   9
#define pnWorld    10
#define pnAnalog   11

#define regLabel   21
#define regTimerToggle 22

//pntimer
#define regTimerStart 1
#define regTimerReset 2
#define regTimerClear 3
#define regTimerUp    4
#define regTimerDown  5

//pnmonth
#define regMonthLeft  1
#define regMonthRight 2
#define regMonthDate  3



/*
#define pEmpty     0

#define pDate0     1
#define pTime0     2
#define pDate1     3
#define pTime1     4
#define pDate2     5
#define pTime2     6
#define pDate3     7
#define pTime3     8
#define pDate4     9
#define pTime4    10

#define pAlarm1   11
#define pAlarm2   12
#define pAlarm3   13
#define pAlarm4   14

#define pTimer1   15
#define pControl1 16
#define pTimer2   17
#define pControl2 18
#define pTimer3   19
#define pControl3 20
#define pTimer4   21
#define pControl4 22

#define pWorld12  23
#define pWorld34  24

#define wDateDL   25
#define wDateD1   26
#define wDateD2   27
#define wDateD3   28
#define wDateD4   29

#define pMonth0   30
#define pMonth1   31
#define pMonth2   32
#define pMonth3   33
#define pMonth4   34

#define pAnalogL  35
#define pAnalog1  36
#define pAnalog2  37
#define pAnalog3  38
#define pAnalog4  39
*/


#define AlarmCount 4

//forms 1000-1049
#define formID_bigclock          1000
#define formID_layout            1001
#define formID_option            1002
#define formID_sure              1003
#define formID_lock              1004
#define formID_alarm             1005
#define formID_timer             1006
#define formID_world             1007
#define formID_sound             1008
#define formID_localtime         1009
#define formID_newyear           1010
#define formID_color             1011
#define formID_history           1012
#define formID_help              1013
#define formID_global            1014
#define formID_displayalarm      1015

//alerts 1050-1099
#define alertID_info             1050
#define alertID_confirmation     1051
#define alertID_text             1052
#define alertID_test             1053
#define alertID_checked          1054
#define alertID_help             1056
#define alertID_text2            1057
#define alertID_text3            1058


//bitmaps 1100-1199
#define bitmapID_num0            1000
#define bitmapID_num1            1001
#define bitmapID_num2            1002
#define bitmapID_num3            1003
#define bitmapID_num4            1004
#define bitmapID_num5            1005
#define bitmapID_num6            1006
#define bitmapID_num7            1007
#define bitmapID_num8            1008
#define bitmapID_num9            1009
#define bitmapID_points          1010
#define bitmapID_point           1011
#define bitmapID_alarm           1012
#define bitmapID_slash           1013
#define bitmapID_am              1014
#define bitmapID_pm              1015
#define bitmapID_infoicon        1020
#define bitmapID_infoiconi       1021
#define bitmapID_large           1050
#define bitmapID_circlelarge     1051
#define bitmapID_circlesmall     1052
#define bitmapID_circletiny      1053
#define bitmapID_starlarge       1054
#define bitmapID_starsmall       1055
#define bitmapID_startiny        1056
#define bitmapID_back            1057
#define bitmapID_list            1058
#define bitmapID_mona            1059
#define bitmapID_info            1060


//edits 1200-1299

#define editID_soundf1           1200
#define editID_soundt1           1201
#define editID_sounda1           1202
#define editID_soundp1           1203
#define editID_soundf2           1204
#define editID_soundt2           1205
#define editID_sounda2           1206
#define editID_soundp2           1207
#define editID_soundf3           1208
#define editID_soundt3           1209
#define editID_sounda3           1210
#define editID_soundp3           1211
#define editID_soundf4           1212
#define editID_soundt4           1213
#define editID_sounda4           1214
#define editID_soundp4           1215
#define editID_soundr            1216
#define editID_edit1             1220
#define editID_edit2             1221
#define editID_tzh               1222
#define editID_tzm               1223
#define editID_name              1230
#define editID_max               1240
#define editID_time              1241
#define editID_alarm             1242
#define editID_world             1243
#define editID_timer             1244
#define editID_price             1245
#define editID_calc              1250
#define editID_snooze            1251


//menues 1300-1399
#define menuID_bigclock          1300
#define menuitemID_about         1301
#define menuitemID_test          1302
#define menuitemID_seconds       1303
#define menuitemID_test2         1304
#define menuitemID_test3         1305
#define menuitemID_test4         1306
#define menuitemID_test5         1307
#define menuitemID_help          1308
#define menuitemID_layout        1309
#define menuitemID_options       1310
//#define menuitemID_sounds        1311
#define menuitemID_reset         1312
#define menuitemID_lock          1313
#define menuitemID_alarm         1314
#define menuitemID_timer         1315
#define menuitemID_world         1316
#define menuitemID_sound1        1317
#define menuitemID_sound2        1318
#define menuitemID_sound3        1319
#define menuitemID_sound4        1320
#define menuitemID_localtime     1321
#define menuitemID_sounds        1322
#define menuitemID_color         1323
#define menuitemID_global        1324

//labels 1400-1499
#define labelID_active1          1400
#define labelID_active2          1401
#define labelID_active3          1402
#define labelID_active4          1403
#define labelID_soundfreq        1404
#define labelID_soundtime        1405
#define labelID_soundampli       1406
#define labelID_soundpause       1407



//buttons 1500-1599
#define buttonID_ml              1500
#define buttonID_m1              1501
#define buttonID_m2              1502
#define buttonID_m3              1503
#define buttonID_m4              1504
#define buttonID_ok              1505
#define buttonID_reset           1506
#define buttonID_yes             1507
#define buttonID_no              1508
#define buttonID_test            1509
#define buttonID_cancel          1510
#define buttonID_pageset1        1511
#define buttonID_pageset2        1512
#define buttonID_colorb          1513
#define buttonID_colorf          1514
#define buttonID_set             1515
#define buttonID_colorbi         1516
#define buttonID_colorfi         1517
#define buttonID_delete          1518
#define buttonID_info            1519
#define buttonID_up              1520
#define buttonID_down            1521
#define buttonID_close           1522
#define buttonID_index           1523
#define buttonID_back            1524
#define buttonID_beam            1525



//list&popup 1600-1699
#define listID_theme             1600
#define popupID_tzd              1601
#define listID_tzd               1602
#define popupID_time1            1603
#define popupID_time2            1604
#define popupID_alarm1           1605
#define popupID_alarm2           1606
#define popupID_world1           1607
#define popupID_world2           1608
#define popupID_timer1           1609
#define popupID_timer2           1610
#define popupID_base             1611
#define popupID_mode             1612
#define popupID_panel11g         1613
#define popupID_panel12g         1614
#define popupID_panel21g         1615
#define popupID_panel22g         1616
#define popupID_panel31g         1617
#define popupID_panel32g         1618
#define popupID_panel41g         1619
#define popupID_panel42g         1620
#define popupID_panel11t         1621
#define popupID_panel12t         1622
#define popupID_panel21t         1623
#define popupID_panel22t         1624
#define popupID_panel31t         1625
#define popupID_panel32t         1626
#define popupID_panel41t         1627
#define popupID_panel42t         1628
#define popupID_trigger          1629
#define popupID_hour             1630
#define popupID_minute           1631
#define popupID_second           1632
#define popupID_day              1633
#define popupID_month            1634
#define popupID_year             1635
#define listID_hour              1636
#define listID_minute            1637
#define listID_second            1638
#define listID_day               1639
#define listID_month             1640
#define listID_year              1641
#define popuplistID_midi         1642
#define popuplistID_page         1643
#define popuplistID_snooze       1644
#define popuplistID_times        1645
#define popuplistID_count        1646
#define popuplistID_trigger      1647
#define popuplistID_mode         1648
#define popuplistID_paneltypes   1649
#define popuplistID_timelist     1650
#define popuplistID_worldlist    1651
#define popuplistID_alarmlist    1652
#define popupID_midi             1653
#define popupID_soundtypes       1654
#define popuplistID_soundtypes   1655
#define popupID_screenmode       1656
#define popuplistID_screenmode   1657




//checkbox 1700-1799
#define checkboxID_snooze        1700
#define checkboxID_time1a        1701
#define checkboxID_time2a        1702
#define checkboxID_alarm1a       1703
#define checkboxID_alarm2a       1704
#define checkboxID_world1a       1705
#define checkboxID_world2a       1706
#define checkboxID_timer1a       1707
#define checkboxID_timer2a       1708
#define checkboxID_time1b        1709
#define checkboxID_time2b        1710
#define checkboxID_alarm1b       1711
#define checkboxID_alarm2b       1712
#define checkboxID_world1b       1713
#define checkboxID_world2b       1714
#define checkboxID_timer1b       1715
#define checkboxID_timer2b       1716
#define checkboxID_timel         1718
#define checkboxID_time1         1719
#define checkboxID_time2         1720
#define checkboxID_autoreset     1721
#define checkboxID_autostart     1722
#define checkboxID_alarm         1723
#define checkboxID_backlight     1724
#define checkboxID_silent        1725
#define checkboxID_talelight     1726
#define checkboxID_hardware      1727
#define checkboxID_chess         1728
#define checkboxID_soundoff      1729
#define checkboxID_calc          1730
#define checkboxID_wait          1731
#define checkboxID_systemsound   1732
#define checkboxID_locktimer     1733
#define checkboxID_days          1734
#define checkboxID_autooff       1735
#define checkboxID_daterel       1736
#define checkboxID_lock          1737
#define checkboxID_price         1738
#define checkboxID_keepworld     1739
#define checkboxID_startfirst    1740

//selector 1800
#define selectorID_reldate       1800
#define selectorID_reltime       1801


//strings 2000-
#define stringID_help_a          2000
#define stringID_help_b          2001
#define stringID_help_c          2002
#define stringID_help_d          2003
#define stringID_help            2004
#define stringID_a               2005
#define stringID_b               2006
#define stringID_c               2007
#define stringID_d               2008
#define stringID_e               2009
#define stringID_f               2010
#define stringID_g               2011
#define stringID_h               2012
#define stringID_localtime       2013
#define stringID_world1          2014
#define stringID_world2          2015
#define stringID_world3          2016
#define stringID_world4          2017
#define stringID_timer1          2018
#define stringID_timer2          2019
#define stringID_timer3          2020
#define stringID_timer4          2021
#define stringID_alarm1          2022
#define stringID_alarm2          2023
#define stringID_alarm3          2024
#define stringID_alarm4          2025
#define stringID_pagenames00     2026
#define stringID_pagenames01     2027
#define stringID_pagenames02     2028
#define stringID_pagenames03     2029
#define stringID_pagenames10     2030
#define stringID_pagenames11     2031
#define stringID_pagenames12     2032
#define stringID_pagenames13     2033
#define stringID_detailweek      2034
#define stringID_detailday       2035
#define stringID_detailhour      2036
#define stringID_timerstart      2037
#define stringID_timerstop       2038
#define stringID_timerreset      2039
#define stringID_timerclear      2040
#define stringID_alarmmode2      2041
#define stringID_alarmmode3      2042
#define stringID_timermode0      2043
#define stringID_timermode1      2044
#define stringID_timermode2      2045
#define stringID_timermode3      2046
#define stringID_timermode4      2047
#define stringID_timermode5      2048
#define stringID_timermode6      2049
#define stringID_soundname1      2050
#define stringID_soundname2      2051
#define stringID_soundname3      2052
#define stringID_soundname4      2053
#define stringID_weekdays        2054
#define stringID_months          2055
#define stringID_stopsnooze      2056
#define stringID_colormenu       2057
#define stringID_datedialog      2058
#define stringID_timedialog      2059
#define stringID_notheme         2060







