// sound definition
typedef struct
         {
            UInt8   type;
            int  freq[4];
            int  time[4];
            int  amplitude[4];
            int  pause[4];
            Char  count;
         } BigClockSound; //34 byte

typedef struct
        {
          Word           active     :1 ;    // is alarm active
          Word           ampm       :1 ;    // display ampm
          Word           seconds    :1 ;    // display seconds
          Word           backlight  :1 ;    // activate backlight
          Word           wait       :1 ;    // autoclose alarm screen
          Word           timerup    :1 ;    // count timer up
          Word           sound      :2 ;    // sound to use
          Word           oldmode    :2 ;    // 0 simple
                                            // 1 reset
                                            // 2 loop
                                            // 3 alarm
          Word           snooze     :1 ;    // use snooze
          Word           base       :3 ;    // worldtime to use
          Word           trigger    :2 ;    // display day selection
          Word           silent     :1 ;    // no sound
          Word           talelight  :1 ;    // use talelight
          Word           closed     :1 ;    // manually closed
          Word           autooff    :1 ;    // keep device on
          Word           mode       :4 ;    // 0 simple
                                            // 1 reset
                                            // 2 loop
                                            // 3 alarm
                                            // 4 alarm&loop
                                            // 5 go on
                                            // 6 alarm and go on
          Word           daychanged :1 ;    // flag set if day or month or year is changed since last redraw
          Word           daterelative:1;    // date relative timer
          Word           alternate :1;      // chessmode
          Word           ignoresystemsoundoff:1; //required to store in alarm
          Word           calc:1;             //calculated timer
        } BigClockOptions;    //4


typedef struct
        {
          Char set;
          Char page;
          Char start;
          Char end;
          UInt16 id;
        } BackgroundInfo;


typedef struct
        {
          Word numbers;
          Word count;
          BackgroundInfo back;
        } BigClockThemeDef;

typedef struct
        {
          UInt8  handera;
          UInt8  maxdepth;
          UInt8  alarmbitmap;
          IndexedColorType colorb;
          IndexedColorType colorf;
          IndexedColorType colorbi;
          IndexedColorType colorfi;
        } BigClockBonusDef;

typedef struct
        {
          DateTimeType   time;          // time of alarm
          BigClockOptions  options;
          BigClockSound  sound;         // what alarm to sound
          unsigned char          days;          // days to sound alarm
          char           name[12];      // name of alarm
          char           worldname[12]; // name of the worldtime used
          long           worldoffset;   // offset of the worldtime used
          Word           snoozetime;    // time between snooze alarms
          Char           snoozecount;   // number of snooze alarms
          Char           snoozecurrent; // number of snooze to sound
          unsigned long  snoozeoffset;  // number of seconds to add for snooze;
              } BigClockAlarm; //80

typedef struct
        {
          char             name[12];      // name of time
          long             value;         // current value
          long             reset;         // reset value
          long             date;          // date for relative timer
          BigClockOptions  options;        // options
          ULong            last;          // last displayed value
          Word             snoozetime;    // snooze time in minutes
          Char             snoozecount;   // number of snooze
          unsigned char            days;          // days to sound alarm
          Int8             add;           // display x add
          int              monthoffset;   // month offset for month view
          int              weekcalc;      // offset for weeknumbr calculation
          long             calc;
        } BigClockTime; //40


typedef struct
	{
          Word    version;
          BigClockTime     world[wCount];
          BigClockSound    sounds[4];
          Int8 mode;
          Int8 pageset;
          unsigned char pages[2][8];
          char pagenames[2][4][9];
          IndexedColorType colorb;
          IndexedColorType colorf;
          IndexedColorType colorbi;
          IndexedColorType colorfi;
          char history[8][12];
          char theme[32];
          Boolean  hardwarebuttons; // use up/down for timer
          Boolean  ignoresystemsoundoff;
          UInt32    screendepth;
          Int32    monthadd;
          Word     locktimer:1;
          Word     startfirst:1;
	} BigClockPrefType;


typedef struct
         {
           Coord   x1;
           Coord   y1;
           Coord   x2;
           Coord   y2;
           UInt8   panel;
           UInt8   sub;
           UInt8   id;
           void *next;
         } BigClockRegion;

