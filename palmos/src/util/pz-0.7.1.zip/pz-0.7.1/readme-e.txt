pz ver 0.7.1 (Jan 20, 2000)

Latest version of pz may be found at:
    http://www.sra.co.jp/people/hoshi/palmos/pz.html

Caution: pz ver 0.7 is a beta version.  Use it on your own risk.


<<< What's pz? >>>

pz is an archiver for Palm OS.

* You can compress/extract databases on Palm OS.  Extraction-only
  version (unpz) is also provided.

* You can have multiple compressed databases in an archive.
  (Of course, you can have multiple archives.)

* You can convert .zip file to pz archive with zip2pz.pl.
  (Files must be compressed by `deflate' method.)  If converted
  pz archive contains a text file, you can read it.

* You can delete databases, and view/modify their attributes.
  It also provides powerful filtering and sorting capabilities.


<<< Database List View >>>

Database list view shows a list of databases on the Palm device.

One of the following information can be displayed on the left side
of the database name:
* - (nothing)
* where
* kind

Meaning of `where' is:
* -    - RAM
* rom  - ROM or the unmodifiable area of the flash memory
* flsh - modifiable (by FlashPro) area of the flash memory
* ext  - external memory card, such as SpringBoard

Meaning of `kind' is:
* sys  - system databases
* pz   - pz archives
* app  - applications
* pnl  - preference panels
* hac  - HackMaster extensions (hacks)
* da   - Desk Accessories (DA)
* loc  - localizers
* dat  - normal data (whose type is 'DATA' or 'Data')
* doc  - DOC reader documents
* img  - ImageViewer image data
* ?    - others

Up to two of the following can be displayed on the right side:
* - (nothing)
* type
* crea (creator)
* recs (# of records)
* size
* attr
* cdat (date of creation)
* mdat (date of last modification)
* bdat (date of last backup)
* vers
* mods (# of modifications)

Sorting order of the databases can be specified by `sort by:' pop-up
on the top of screen.

It is also possible to narrow down the databases to display, about
the place and the kind by two pop-ups at the lower left of screen.

There are several buttons:
* info - show the information of the selected database.
* cmpr - compress the selected database.
* open - open the selected pz archive.

In `unpz', the set of information is fixed (where, recs, and size),
and there is no sorting and filtering capability, nor `cmpr' button.

Tapping the selected database again, open it if it is a pz archive,
or show its information otherwise.

Graffiti input of the initial letter of the database name (type or
creator, when sorting order is `type' or 'crea', respectively), to
scroll to the database.

Free size of RAM is displayed at the upper right corner.


<<< Compress Dialog >>>

You can create a new archive, or add to an existing archive.

Copy protected databases (commercial applications, etc.) can only
be added to copy protected archives.  Be careful that pz prohibit
to change the copy protect attribute.


<<< Archive View >>>

Archive view shows a list of compressed items in the pz archive.

There are several buttons:
* done - close the archive and go back to the database list view.
* info - show the information of the selected item.
* extr - extract (or read) the selected item.
* del  - delete the selected item, or the archive if empty.
(`unpz' doesn't have `del' button.)

Tapping the selected item again, extract it if it is a database,
or read its contents otherwise.

Free size of RAM is displayed at the upper right corner.


<<< Database Information View >>>

Database information view displays information of the database.

You can modify name, type, creator, and attributes of the database,
by `apply changes' button.  Changing of `res db', `copy protect',
or `open' attribute is prohibited.

`del' button deletes the database, and `beam' button beams.

You can't modify information, delete, or beam when the database is
in ROM or flash, or compressed.


<<< Usage of zip2pz.pl >>>

`zip2pz.pl' is a perl script to convert from .zip file to pz archive.
Files must be compressed by `deflate' method.  `implode' method is
not supported.

Usage is:
    perl zip2pz.pl [-f|-n|-q] file.zip [(directory|out-file.pz.pdb) [dbname.pz]]

Options are:
* -f ... overwrite <out-file.pz.pdb> if it already exists.
* -n ... don't output.
* -q ... run quietly.

You need to have the perl to run this script.  I think it would run
fine on Windows.  I don't know about Mac OS...


<<< Copyright >>>

pz is copyrighted (c) 1999-2000 by Hoshi Takanori.  You may use or
redistribute the non-modified copy of original archive for free.

pz is privided on an `as is' basis, WITHOUT ANY WARRANTY.

pz uses zlib 1.1.3 for compression and decompression.  zlib's
copyright is: (C) 1995-1998 Jean-loup Gailly and Mark Adler


<<< Revision History >>>

ver 0.7.1 (Jan 20, 2000)
* improve handling of low memory condition in the read view.

ver 0.7 (Jan 19, 2000)
* add `copy', `prev', and `next' buttons to the read view.  (ver 0.6.1)
* add `del' button to the database information view.  (ver 0.6.2)
* add extraction-only version (unpz).  (ver 0.6.3)
* add `beam' button to the database information view.  (not tested)
* add the attribute dialog, and minor improvements.

ver 0.6 (Dec 22, 1999)
* implement modification of name, type, creator, and attributes.
* support copy protection, and add the read view.
* support graffiti input in the database list view.
* the archive view shows the total size and compression ratio.

ver 0.5 (Dec 13, 1999)
* support multiple compressed databases in an archive.
* add the archive view and the database information view.

ver 0.2 (Dec 3, 1999) alpha version, pilot-tech-ml only
* support compression of large databases.
* major improvement of the database list view.

ver 0.1 (Oct 1, 1999) alpha version, pilot-tech-ml only
* initial release.


Hoshi Takanori (hoshi@sra.co.jp, http://www.sra.co.jp/people/hoshi/)
