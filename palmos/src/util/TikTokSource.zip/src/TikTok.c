///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  TikTok.c                                            //
//     Original Author:  David A. Pearson (� 1997-2000)                      //
// Modification Author:  Mike McCollister (� 1999-2001)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8                                           //
//                       HandEra Header Files from SDK 1.01                  //
//         Description:  TikTok is a simple multi-stopwatch for a Palm       //
//                       Connected organizer.                                //
//               Notes:  This program is free software; you can redistribute //
//                       it and/or modify it under the terms of the GNU      //
//                       General Public License as published by the Free     //
//                       Software Foundation; either version 2 of the        //
//                       license, or (at your option) any later version.     //
//                                                                           //
//                       This program is distributed in the hope that it     //
//                       will be useful, but WITHOUT ANY WARRANTY; without   //
//                       even the implied warranty of MERCHANTABILITY or     //
//                       FITNESS FOR A PARTICULAR PURPOSE.  See the GNU      //
//                       General Public License for more details.            //
//                                                                           //
//                       You should have received a copy of the GNU General  //
//                       Public License along with this program; if not,     //
//                       write to the Free Software Foundation, Inc., 675    //
//                       Mass Ave, Cambridge, MA 02139, USA.                 //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

//////////////////////
// Error Prevention //
//////////////////////

#define DO_NOT_ALLOW_ACCESS_TO_INTERNALS_OF_STRUCTS


///////////////////
// Include Files //
///////////////////

#include <PalmOS.h>
#include <HandEra/Vga.h>

#include "TikTok.h"


/////////////
// Defines //
/////////////

#define APP_ID               ((UInt32)'DAP2')
#define PREF_VER             4
#define APP_TYPE             'appl'

#define TT_CLOCKS            32
#define TT_CLOCKS_PER_PAGE   8
#define TT_NUM_PAGES         (TT_CLOCKS / TT_CLOCKS_PER_PAGE)
#define TT_SYNC_ALL          -1

#define BEEP                 SndPlaySystemSound(sndInfo)
#define DEBUG_BEEP           BEEP
#define CLICK                SndPlaySystemSound(sndClick)

#define SDESC_SIZE           32
#define TEMP_BUF_SIZE        10

#define soundTriggerLabelLen 32  // Max len of sound trigger label placeholder


////////////
// Macros //
////////////

#define IS_TIKTOK_CTRL(wId) ((wId) >= ID_ChkFirst && (wId) < (ID_ChkFirst + TT_CLOCKS_PER_PAGE))
#define IS_STICKY_CTRL(wId) ((wId) >= ID_StkFirst && (wId) < (ID_StkFirst + TT_CLOCKS_PER_PAGE))
#define IS_TEXT_FIELD(wId)  ((wId) >= ID_TxtFirst && (wId) < (ID_TxtFirst + TT_CLOCKS_PER_PAGE))
#define IS_SEC_FIELD(wId)   ((wId) >= ID_SecFirst && (wId) < (ID_SecFirst + TT_CLOCKS_PER_PAGE))


////////////////
// Structures //
////////////////

typedef enum {
   AS_OFF,             // No alarm set
   AS_AWAITING_ALARM,  // Awaiting alarm
   AS_AWAITING_DISPLAY // Awaiting alarm display
} t_AlmState;          // TikTok alarm states

typedef struct {
   Boolean    bOn     : 1;       // Is the timer running?
   Boolean    bEmpty  : 1;       // Is it empty?
   Boolean    bSticky : 1;       // Is it a persistant timer?
   UInt32     ulStart;           // When did it start running?
   Int32      lElapsed;          // How much time has elapsed?
   Int32      lInitial;          // What was the initial value?
   t_AlmState AlmState;          // Alarm state
   Char       sDesc[SDESC_SIZE]; // Short note for the timer.
} t_TikTok;                      // Used to hold/save info about a clock.

typedef struct {
   MemHandle hndTime;          // Handle for the timer field.
   MemHandle hndDesc;          // Handle for the note field.
   FieldPtr ptrTime;           // Pointer to the time field.
   FieldPtr ptrDesc;           // Pointer to the note field.
} t_TikTokCtrl;                // Used to track the display control.

typedef enum {
   BF_START_STOP,              // Button toggles the start and stop
   BF_PERSIST,                 // Button toggles the persistent
   BF_PREV_FIELD,              // Button goes to previous field
   BF_NEXT_FIELD,              // Button goes no next field
   BF_PAGE_UP,                 // Button goes to previous page
   BF_PAGE_DOWN                // Button goes to next page
} t_TikTokBtnFn;               // TikTok button options

typedef struct {
   Boolean  bVisAlm    : 1;    // Visual alarm?
   Boolean  bButtonAll : 1;    // Buttons perform actions on all timers?
   Boolean  bShowTime  : 1;    // Display a clock?
   Boolean  bMemory    : 1;    // Do timers have start time memory?
   Boolean  bAlmStop   : 1;    // Do alarms stop when they fire?
   Int32    iFocused;          // Focus memory.
   Int32    iPage;             // Current page
   UInt32   SoundRecID;        // Alarm Sound
   t_TikTokBtnFn bfUp;         // Page Up Button Function
   t_TikTokBtnFn bfDown;       // Page Down Button Function
   t_TikTok ttClocks[TT_CLOCKS];    
} t_TikTokPrefs;               // Used to store the app prefs.

typedef enum {
   TT_CLR_FOCUSED,             // Clear the focused timer.
   TT_CLR_STOPPED,             // Clear all stopped timers.
   TT_CLR_ALL                  // Clear all timers.
} t_TikTokClear;               // TikTok clear methods.

typedef enum {
   TT_ALL  = 0,
   TT_PAGE = 1,
   TT_NONE = 2,
   TT_ONE  = 3
} t_Quantity;

typedef enum {
   TT_START,
   TT_STOP,
   TT_TOGGLE
} t_Method;

typedef enum {
   TF_NO_CHANGE,
   TF_TEXT,
   TF_SEC,
   TF_NA
} t_Focused;


//////////////////////
// Global Variables //
//////////////////////
    
t_TikTokPrefs         ttPrefs;               // Application preferences.
t_TikTokCtrl          ttControls[TT_CLOCKS_PER_PAGE]; // Control details array.
SystemPreferencesType sysPrefs;              // User's Palm preferences.
Char                  timeSeparator;         // time separator in system prefs
Char                  decimalChar;           // decimal Char in system prefs
Char                  sTimeSeparator[2];     // string version of time spearator
Char                  sDecimalChar[2];       // string version of decimal Char
UInt32                ulLast = 0L;           // Last time we drew the display.
Boolean               bCanUpdate = true;     // Can we update the screen?
Int32                 iLastFocused = -1;     // last text field with focus

UInt16 ROMVerMajor;                          // ROM version

// Alarm Sound Globals
Char* soundTriggerLabelP; // Placeholder for sound trigger label
MemHandle gMidiListH;     // handle to the list containing names and DB info of
                          //   MIDI tracks.  Each entry is of type
                          //   SndMidiListItemType.
UInt16 gMidiCount;        // number of entries in the MIDI list
UInt32 tempSoundRecID;    // used for storing temporary sound record

// High Resolution Screen Globals
Boolean bVgaExists = false;
RectangleType oldWinRect = {{0, 0}, {240, 240}};


/////////////////////////
// Function Prototypes //
/////////////////////////

static Boolean ApplicationHandleEvent(EventPtr e);
static Boolean MainFormHandleEvent(EventPtr e);
static Boolean PrefsFormHandleEvent(EventPtr e);
static void LoadTikToks(t_TikTokPrefs *pttPrefs);
static void SyncTikToks(Int32 iTikTok, Boolean UpdateControls,
                        Boolean UpdateDescriptions, Boolean ForceTimerUpdate);
static void ToggleTikTok(Int32 iTikTokControl);
static void StopTikTok(Int32 iTikTok, t_Quantity quantity);
static void StartTikTok(Int32 iTikTok, t_Quantity quantity);
static void ToggleSticky(Int32 iTikTokControl);
static void FormatTimer(Char *sTimer, Int32 lElapsed);
static void ICat(UInt32 ui, Char *s);
static void ZeroPadICat(UInt32 ui, Char *s);
static void SaveTikToks(t_TikTokPrefs *pttPrefs, Boolean bSaveDesc);
static void ClearTikToks(t_TikTokClear ttClrType, Boolean bSetToZero);
static void *Id2Ptr(UInt16 wID);
static void DefaultTheDescription(Int32 iTikTok, UInt32 ulTime);
static Int32 FocusedTikTok(void);
static UInt16 GetFocusID(void);
static Boolean IsTimeFieldDirty(Int32 iTikTok);
static void SetTimeFldEditable(Int32 iTikTok, Boolean bEdit);
static Int32 ParseTimeField(Int32 iTikTok, Boolean *pbOk, Boolean bGui);
static void StuffTikTok(const Char *pszTime);
static void ShowTime(void);
static UInt32 CalcNextAlarm(Boolean bRecalcAll, t_TikTokPrefs *pttPrefs);
static void SetAlarm(t_TikTokPrefs *pttPrefs, Boolean bRecalcAll);
static void PlayAlarm(t_TikTokPrefs *pttPrefs);
static void RaiseAlarm(t_TikTokPrefs *pttPrefs, Boolean bAppIsActive);
static UInt16 GetROMVerMajor(void);
static UInt16 GetCurrentFieldId(void);
static void HandleNextPrevField(UInt16 keyDown);
static void StartStopFocused(t_Method method);
static void TogglePersistentFocused(void);
static Int32 GetiFocused(void);
static void SetFocused(Int32 iFocus, Boolean changeFocus, Boolean force,
                       t_Focused focusType);
static void PutWordToString(Char *pszTxt, UInt16 w, UInt16 wMaxSize,
                            Boolean bZeroPad);
static void SystemWasReset(void);
static Boolean AlarmEventHandler(EventPtr event);
static void DisplayAboutForm(UInt16 rscID);
static Boolean HandlePageUpDown(t_TikTokBtnFn direction, Boolean bWrap);
static void MainUpdateForm(Boolean refresh);
static Boolean IsVisible(Int32 iTikTok);
static Boolean IsNotValidChar(WChar *key);
static Char DecimalChar(NumberFormatType n);

// alarm sound prototypes
static void PlayAlarmSound(UInt32 uniqueRecID);
static void AlarmSoundListInit(void);
static void SetSoundLabel(FormPtr formP, const Char* labelP);
static void MidiPickListDrawItem(UInt16 itemNum, RectanglePtr bounds, 
                                 Char **unusedP);
static void CreateMidiPickList(FormPtr pForm, ListPtr listP,
                               ListDrawDataFuncPtr funcP, UInt16 listID);
static void FreeMidiPickList(void);
static void FreeAllSoundStuff(void);
static void HandleAlarmChange(EventPtr e);

// HandEra VGA Functions
static void SizeForm(FormPtr pForm);
static UInt16 GetGSIIndex(FormPtr pForm);
static void ResizeObject(FormPtr pForm, UInt16 objectIndex,
                         Coord xMove, Coord yMove,
                         Coord xExp, Coord yExp, Boolean bDraw);


///////////////
// Functions //
///////////////
    
UInt32 PilotMain(UInt16 cmd, MemPtr cmdPBP __attribute__ ((unused)),
                 UInt16 launchFlags __attribute__ ((unused)))
{
   Boolean bAppIsActive = (Boolean)(launchFlags & sysAppLaunchFlagSubCall);
   UInt16 returnVal = sysErrParamErr;
   UInt32 version;

   if(cmd == sysAppLaunchCmdNormalLaunch) {
      short     err;
      EventType e;
      Boolean   bExit = false;
      Int32     i;

      if(_TRGVGAFeaturePresent(&version))
         bVgaExists = true;

      /* Get the user's preferences for their Palm, we want this
         so we can know their desired date and time format. */
      PrefGetPreferences(&sysPrefs);
      timeSeparator     = TimeSeparator(sysPrefs.timeFormat);
      sTimeSeparator[0] = timeSeparator;
      sTimeSeparator[1] = 0x00;
      decimalChar       = DecimalChar(sysPrefs.numberFormat);
      sDecimalChar[0]   = decimalChar;
      sDecimalChar[1]   = 0x00;

      ROMVerMajor = GetROMVerMajor();

      LoadTikToks(&ttPrefs);

      for(i = 0; i < TT_CLOCKS_PER_PAGE; i++) {
         ttControls[i].hndTime = MemHandleNew(SDESC_SIZE);
         ttControls[i].hndDesc = MemHandleNew(SDESC_SIZE);
      }
        
      if(bVgaExists)
         VgaSetScreenMode(screenMode1To1, rotateModeNone);
      FrmGotoForm(ID_FrmTikTok);

      while(!bExit) {
         EvtGetEvent(&e, bCanUpdate ? sysTicksPerSecond / 4 : evtWaitForever);

         if(SysHandleEvent(&e))
            continue;

         if(MenuHandleEvent(0, &e, &err))
            continue;

         if(ApplicationHandleEvent(&e))
            continue;

         FrmDispatchEvent(&e);

         if(e.eType == appStopEvent) {
            FrmCloseAllForms();
            bExit = true;
         }
      }

      returnVal = 0;
   }
   else if(cmd == sysAppLaunchCmdAlarmTriggered) {
      if(bAppIsActive) {
         Boolean bMainFormVisible = FrmGetActiveFormID() == ID_FrmTikTok;

         if(bMainFormVisible)
            SyncTikToks(TT_SYNC_ALL, true, true, true);

         PlayAlarm(&ttPrefs);

         // update descriptions
         SaveTikToks(&ttPrefs, bMainFormVisible);
      }
      else {
         t_TikTokPrefs *pttPrefs;

         /* When called as an alarm you can't use globals and it seeams you
            can't have large local structures either. So, in this case we'll
            allocate some memory and load the preferences into there instead. */
    
         pttPrefs = (t_TikTokPrefs *)MemPtrNew(sizeof(t_TikTokPrefs));
    
         LoadTikToks(pttPrefs);
         PlayAlarm(pttPrefs);
         SaveTikToks(pttPrefs, false);
         MemPtrFree((MemPtr)pttPrefs);
      }
      returnVal = 0;
   }
   else if(cmd == sysAppLaunchCmdDisplayAlarm) {
      if(bAppIsActive) {
         RaiseAlarm(&ttPrefs, bAppIsActive);
      }
      else {
         t_TikTokPrefs *pttPrefs;

         pttPrefs = (t_TikTokPrefs *)MemPtrNew(sizeof(t_TikTokPrefs));
         RaiseAlarm(pttPrefs, bAppIsActive);
         MemPtrFree(pttPrefs);
      }
      returnVal = 0;
   }
   else if(cmd == sysAppLaunchCmdSystemReset ||
           cmd == sysAppLaunchCmdSyncNotify) {
      SystemWasReset();
      returnVal = 0;
   }

   return returnVal;
}


static Boolean ApplicationHandleEvent(EventPtr e)
{
   Boolean bUsed = false;
    
   if(e->eType == frmLoadEvent) {
      UInt16  wForm  = e->data.frmLoad.formID;
      FormPtr ptrFrm = FrmInitForm( wForm );

      FrmSetActiveForm(ptrFrm);

      switch(wForm) {
         case ID_FrmTikTok:
            FrmSetEventHandler(FrmGetFormPtr(e->data.frmLoad.formID),
                               MainFormHandleEvent);
            bUsed = true;
            break;
            
         case ID_FrmPrefs:
            FrmSetEventHandler(FrmGetFormPtr(e->data.frmLoad.formID),
                               PrefsFormHandleEvent);
            bUsed = true;
            break;
      }
   }

   if(e->eType == fldEnterEvent) {
      SetFocused(GetiFocused(), true, false, TF_NO_CHANGE);
   }

   return bUsed;
}


static Boolean MainFormHandleEvent(EventPtr e)
{
   Boolean bUsed = true;
   FormPtr pForm = FrmGetActiveForm();
   Int32 i;
   UInt32 ulNow;
   UInt16 wFocus = GetFocusID();

   switch(e->eType) {
      case frmOpenEvent:
         if(bVgaExists)
            VgaFormModify(pForm, vgaFormModify160To240);

         for(i = 0; i < TT_CLOCKS_PER_PAGE; i++) {
            ttControls[i].ptrTime = Id2Ptr(ID_SecFirst + i);
            ttControls[i].ptrDesc = Id2Ptr(ID_TxtFirst + i);
         }
         SizeForm(pForm);
         MainUpdateForm(false);
         ShowTime();
         SyncTikToks(TT_SYNC_ALL, true, true, true);
         SetFocused(ttPrefs.iFocused, true, false, TF_TEXT);
         break;
            
      case displayExtentChangedEvent:
         SizeForm(pForm);
         break;

      case frmUpdateEvent:
         MainUpdateForm(false);
         SetFocused(ttPrefs.iFocused, false, true, TF_NO_CHANGE);
         break;

      case ctlSelectEvent:
         SaveTikToks(&ttPrefs, true);
         if(IS_TIKTOK_CTRL(e->data.ctlSelect.controlID)) {
            ToggleTikTok(e->data.ctlSelect.controlID - ID_ChkFirst);
            SyncTikToks(TT_SYNC_ALL, false, false, false);
         }
         else if(IS_STICKY_CTRL(e->data.ctlSelect.controlID)) {
            ToggleSticky(e->data.ctlSelect.controlID - ID_StkFirst);
         }
         else {
            bUsed = false;
         }
         switch(e->data.ctlEnter.controlID) {
            case ID_BtnStart:
               if(ttPrefs.bButtonAll)
                  StartTikTok(0, FrmAlert(ID_AltStartAll));
               else
                  StartStopFocused(TT_START);
               break;

            case ID_BtnStop:
               if(ttPrefs.bButtonAll)
                  StopTikTok(0, FrmAlert(ID_AltStopAll));
               else
                  StartStopFocused(TT_STOP);
               break;

            case ID_BtnClear:
               if(ttPrefs.bButtonAll)
                  ClearTikToks(TT_CLR_ALL, false);
               else
                  ClearTikToks(TT_CLR_FOCUSED, false);
               break;

            case ID_BtnZero:
               if(ttPrefs.bButtonAll)
                  ClearTikToks(TT_CLR_ALL, true);
               else
                  ClearTikToks(TT_CLR_FOCUSED, true);
               break;
         }
         break;
            
      case ctlRepeatEvent:
         switch(e->data.ctlEnter.controlID) {
            case ID_RepUp:
               HandlePageUpDown(BF_PAGE_UP, false);
               bUsed = false;
               break;

            case ID_RepDown:
               HandlePageUpDown(BF_PAGE_DOWN, false);
               bUsed = false;
               break;

            default:
               bUsed = false;
               break;
         }
         break;

      case menuEvent:
         SaveTikToks(&ttPrefs, true);
         switch(e->data.menu.itemID) {
            case ID_MnuClearFocused:
               ClearTikToks(TT_CLR_FOCUSED, false);
               break;
                    
            case ID_MnuClearStopped:
               ClearTikToks(TT_CLR_STOPPED, false);
               break;
                    
            case ID_MnuClearAll:
               ClearTikToks(TT_CLR_ALL, false);
               break;

            case ID_MnuZeroFocused:
               ClearTikToks(TT_CLR_FOCUSED, true);
               break;

            case ID_MnuZeroStopped:
               ClearTikToks(TT_CLR_STOPPED, true);
               break;

            case ID_MnuZeroAll:
               ClearTikToks(TT_CLR_ALL, true);
               break;

            case ID_MnuStartAll:
               StartTikTok(0, FrmAlert(ID_AltStartAll));
               break;

            case ID_MnuStopAll:
               {
                  t_Quantity quantity = FrmAlert(ID_AltStopAll);
                  if(quantity != TT_NONE) {
                     StopTikTok(0, quantity);
                     SyncTikToks(TT_SYNC_ALL, true, false, false);
                  }
               }
               break;

            case ID_MnuAlarm1Min:
               StuffTikTok("-1t");
               break;

            case ID_MnuAlarm2Min:
               StuffTikTok("-2t");
               break;

            case ID_MnuAlarm3Min:
               StuffTikTok("-3t");
               break;
                    
            case ID_MnuAlarm4Min:
               StuffTikTok("-4t");
               break;
                    
            case ID_MnuAlarm5Min:
               StuffTikTok("-5t");
               break;

            case ID_MnuAlarm30Min:
               StuffTikTok("-30t");
               break;

            case ID_MnuAlarm1Hr:
               StuffTikTok("-1tt");
               break;

            case ID_MnuAlarm2Hr:
               StuffTikTok("-2tt");
               break;

            case ID_MnuAlarm3Hr:
               StuffTikTok("-3tt");
               break;
                    
            case ID_MnuAlarm4Hr:
               StuffTikTok("-4tt");
               break;

            case ID_MnuAlarm5Hr:
               StuffTikTok("-5tt");
               break;

            case ID_MnuAlarm1Day:
               StuffTikTok("-1d");
               break;

            case ID_MnuAlarm2Day:
               StuffTikTok("-2d");
               break;

            case ID_MnuEditUndo:
               FldUndo(Id2Ptr(wFocus));
               if(IS_SEC_FIELD(wFocus))
                  ParseTimeField(ttPrefs.iFocused, NULL, true);
               break;
                    
            case ID_MnuEditCut:
               FldCut(Id2Ptr(wFocus));
               break;

            case ID_MnuEditCopy:
               FldCopy(Id2Ptr(wFocus));
               break;

            case ID_MnuEditPaste:
               FldPaste(Id2Ptr(wFocus));
               if(IS_SEC_FIELD(wFocus))
                  ParseTimeField(ttPrefs.iFocused, NULL, true);
               break;

            case ID_MnuEditSelectAll:
               FldSetSelection(Id2Ptr(wFocus), 0,
                               FldGetTextLength(Id2Ptr(wFocus)));
               break;

            case ID_MnuEditKeyboard:
               if(ROMVerMajor >= 2 && IS_SEC_FIELD(GetCurrentFieldId()))
                  SysKeyboardDialog(kbdNumbersAndPunc);
               else
                  SysKeyboardDialogV10();
               break;

            case ID_MnuEditGrafHelp:
               if(ROMVerMajor >= 2)
                  SysGraffitiReferenceDialog(referenceDefault);
               else
                  BEEP;
               break;

            case ID_MnuOptionsPrefs:
               FrmPopupForm(ID_FrmPrefs);
               break;

            case ID_MnuOptionsGetInfo:
               FrmHelp(ID_HlpTikTok);
               break;

            case ID_MnuOptionsAbout:
               DisplayAboutForm(ID_FrmAbout);
               break;

            default:
               bUsed = false;
               break;
         }
         break;
            
      case menuCmdBarOpenEvent:
         MenuCmdBarAddButton(menuCmdBarOnLeft, BarInfoBitmap,
                             menuCmdBarResultMenuItem, ID_MnuOptionsGetInfo, 0);

         bUsed = false; // don't set bUsed to true; this event must fall
                          //   through to the system.
         break;

      case keyDownEvent:
         switch(e->data.keyDown.chr) {
            case vchrPageUp:
               switch(ttPrefs.bfUp) {
                  case BF_START_STOP:
                     StartStopFocused(TT_TOGGLE);
                     break;

                  case BF_PERSIST:
                     TogglePersistentFocused();
                     break;

                  case BF_PREV_FIELD:
                     HandleNextPrevField(vchrPrevField);
                     break;

                  case BF_NEXT_FIELD:
                     HandleNextPrevField(vchrNextField);
                     break;

                  case BF_PAGE_UP:
                  case BF_PAGE_DOWN:
                     HandlePageUpDown(ttPrefs.bfUp, true);
                     break;
               }
               break;
                    
            case vchrPageDown:
               switch(ttPrefs.bfDown) {
                  case BF_START_STOP:
                     StartStopFocused(TT_TOGGLE);
                     break;

                  case BF_PERSIST:
                     TogglePersistentFocused();
                     break;

                  case BF_PREV_FIELD:
                     HandleNextPrevField(vchrPrevField);
                     break;

                  case BF_NEXT_FIELD:
                     HandleNextPrevField(vchrNextField);
                     break;

                  case BF_PAGE_UP:
                  case BF_PAGE_DOWN:
                     HandlePageUpDown(ttPrefs.bfDown, true);
                     break;
               }
               break;

            case vchrPrevField:
            case vchrNextField:
               HandleNextPrevField(e->data.keyDown.chr);
               break;

            case chrCarriageReturn:
               StartStopFocused(TT_TOGGLE);
               break;

            default:
               if(TxtCharIsHardKey(e->data.keyDown.modifiers,
                                   e->data.keyDown.chr)) {
                  if(!(e->data.keyDown.modifiers & poweredOnKeyMask))
                     HandlePageUpDown(BF_PAGE_DOWN, true);
                  bUsed = true;
               }
               else
                  bUsed = IsNotValidChar(&e->data.keyDown.chr);
               break;
         }
         break;

      case popSelectEvent:
         switch(e->data.lstSelect.listID) {
            case popuptriggerID_page:
               SaveTikToks(&ttPrefs, true);
               ttPrefs.iPage = LstGetSelection(Id2Ptr(listID_page));
               MainUpdateForm(true);
               SyncTikToks(TT_SYNC_ALL, true, true, true);
               break;

            default:
               bUsed = false;
               break;
         }
         break;

      case winEnterEvent:
         bCanUpdate = (e->data.winExit.exitWindow !=
                       (WinHandle)FrmGetFormPtr(ID_FrmTikTok));
         break;
            
      case nilEvent:
         ulNow = TimGetSeconds();
         if(ulNow > ulLast && bCanUpdate) {
            ShowTime();
            SyncTikToks(TT_SYNC_ALL, false, false, false);
            ulLast = ulNow;
         }
         break;
            
      case frmCloseEvent:
         SaveTikToks(&ttPrefs, true);
         SetAlarm(&ttPrefs, true);
         FrmEraseForm(pForm);
         FrmDeleteForm(pForm);
         break;

      default:
         bUsed = false;
         break;
   }
       
   return bUsed;
}


static Boolean PrefsFormHandleEvent(EventPtr e)
{
   Boolean bUsed = true;
   FormPtr pForm = FrmGetActiveForm();
   static Boolean bLastMemory;
   UInt16 i;

   switch(e->eType) {
      case frmOpenEvent:
         if(bVgaExists)
            VgaFormModify(pForm, vgaFormModify160To240);

         AlarmSoundListInit();
  
         CtlSetValue(Id2Ptr(ID_ChkShowTime),  ttPrefs.bShowTime);
         CtlSetValue(Id2Ptr(ID_ChkVisAlm),    ttPrefs.bVisAlm);
         CtlSetValue(Id2Ptr(ID_ChkButtonAll), ttPrefs.bButtonAll);
         CtlSetValue(Id2Ptr(ID_ChkMemory),    ttPrefs.bMemory);
         CtlSetValue(Id2Ptr(ID_ChkAlmStp),    ttPrefs.bAlmStop);

         LstSetSelection(Id2Ptr(listID_PageUp), ttPrefs.bfUp - BF_START_STOP);
         CtlSetLabel(Id2Ptr(popuptriggerID_PageUp),
                     LstGetSelectionText(Id2Ptr(listID_PageUp),
                                         ttPrefs.bfUp - BF_START_STOP));

         LstSetSelection(Id2Ptr(listID_PageDown),
                         ttPrefs.bfDown - BF_START_STOP);
         CtlSetLabel(Id2Ptr(popuptriggerID_PageDown),
                     LstGetSelectionText(Id2Ptr(listID_PageDown),
                                         ttPrefs.bfDown - BF_START_STOP));

         bLastMemory = ttPrefs.bMemory;

         FrmDrawForm(pForm);
         break;

      case ctlSelectEvent:
         switch(e->data.ctlSelect.controlID) {
            case ID_BtnOK:
               ttPrefs.bShowTime = CtlGetValue(Id2Ptr(ID_ChkShowTime));
               ttPrefs.bVisAlm = CtlGetValue(Id2Ptr(ID_ChkVisAlm));
               ttPrefs.bButtonAll = CtlGetValue(Id2Ptr(ID_ChkButtonAll));
               ttPrefs.bMemory = CtlGetValue(Id2Ptr(ID_ChkMemory));
               ttPrefs.bAlmStop = CtlGetValue(Id2Ptr(ID_ChkAlmStp));

               ttPrefs.bfUp = LstGetSelection(Id2Ptr(listID_PageUp)) +
                                              BF_START_STOP;
               ttPrefs.bfDown = LstGetSelection(Id2Ptr(listID_PageDown)) +
                                                BF_START_STOP;
               ttPrefs.SoundRecID = tempSoundRecID;
               FreeAllSoundStuff();
               FrmReturnToForm(ID_FrmTikTok);

               // make sure that the display time is not lost
               if(bLastMemory != ttPrefs.bMemory)
                  for(i = 0; i < TT_CLOCKS_PER_PAGE; i++)
                     FldSetDirty(Id2Ptr(ID_SecFirst + i), true);
               break;

            case ID_BtnCancel:
               FreeAllSoundStuff();
               FrmReturnToForm(ID_FrmTikTok);
               break;

            default:
               bUsed = false;
               break;
         }
         break;
        
      case popSelectEvent:
         switch(e->data.lstSelect.listID) {
            case popuptriggerID_AlarmSound:
               HandleAlarmChange(e);
               break;

            default:
               bUsed = false;
               break;
         }
         break;

      case frmCloseEvent:
         FreeAllSoundStuff();
         FrmEraseForm(pForm);
         FrmDeleteForm(pForm);
         break;
        
      default:
         bUsed = false;
         break;
   }
    
   return bUsed;
}


static void LoadTikToks(t_TikTokPrefs *pttPrefs)
{
   Int32   i;
   Boolean bNew = !PrefGetAppPreferencesV10(APP_ID, PREF_VER,
                                            (MemPtr)pttPrefs,
                                            sizeof(t_TikTokPrefs));

   if(bNew) {
      pttPrefs->bVisAlm     = true;
      pttPrefs->iFocused    = 0;
      pttPrefs->iPage       = 0;
      pttPrefs->bShowTime   = true;
      pttPrefs->bButtonAll  = true;
      pttPrefs->bMemory     = true;
      pttPrefs->bAlmStop    = true;
      pttPrefs->bfUp        = BF_PAGE_UP;
      pttPrefs->bfDown      = BF_PAGE_DOWN;

      for(i = 0; i < TT_CLOCKS; i++) {
         pttPrefs->ttClocks[i].bOn      = false;
         pttPrefs->ttClocks[i].bEmpty   = true;
         pttPrefs->ttClocks[i].bSticky  = false;
         pttPrefs->ttClocks[i].lElapsed = 0L;
         pttPrefs->ttClocks[i].lInitial = 0L;
         pttPrefs->ttClocks[i].ulStart  = 0L;
         pttPrefs->ttClocks[i].AlmState = AS_OFF;
      }
   }
}


static void SyncTikToks(Int32 iTikTok, Boolean UpdateControls,
                        Boolean UpdateDescriptions, Boolean ForceTimerUpdate)
{
   UInt32       ulNow = TimGetSeconds();
   Char         *sDesc, *sTime;
   Int32        i, j, iMin, iMax;
   Int32        offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;
   static Int32 iLastPage = -1;

   // return if specified TikTok is not visible
   if(!IsVisible(iTikTok) && iTikTok != TT_SYNC_ALL)
      return;

   if(iTikTok == TT_SYNC_ALL) {
      iMin = 0;
      iMax = TT_CLOCKS_PER_PAGE;
   }
   else {
      iMin = iTikTok - offset;
      iMax = iMin + 1;
   }

   for(i = iMin, j = offset + iMin; i < iMax; i++, j++) {
      // update timers
      if(ttPrefs.ttClocks[j].bOn) {
         Int32 lTotal = ttPrefs.ttClocks[j].lElapsed;
            
         lTotal += (ulNow - ttPrefs.ttClocks[j].ulStart);

         if(ttPrefs.bAlmStop &&
            (ttPrefs.ttClocks[j].lInitial < 0L && lTotal >= 1L)) {
               lTotal = 0L;
               ttPrefs.ttClocks[j].lElapsed =
                  (ttPrefs.bMemory ? ttPrefs.ttClocks[j].lInitial : 0L);
               ttPrefs.ttClocks[j].lInitial =
                  (ttPrefs.bMemory ? ttPrefs.ttClocks[j].lInitial : 0L);
               ttPrefs.ttClocks[j].bOn      = false;
               ttPrefs.ttClocks[j].bEmpty   = false;
               if(IsVisible(j))
                  CtlSetValue(Id2Ptr(ID_ChkFirst + i), false);
         }
         SetTimeFldEditable(i, !ttPrefs.ttClocks[j].bOn);

         sTime = (Char *)MemHandleLock(ttControls[i].hndTime);
         if(ttPrefs.bMemory && !ttPrefs.ttClocks[j].bOn)
            FormatTimer(sTime, ttPrefs.ttClocks[j].lInitial);
         else
            FormatTimer(sTime, lTotal);

         MemHandleUnlock(ttControls[i].hndTime);
         FldSetTextHandle(ttControls[i].ptrTime,
                          (MemHandle)ttControls[i].hndTime);
         FldDrawField(ttControls[i].ptrTime);
      }
      else if(iLastPage != ttPrefs.iPage || ForceTimerUpdate) {
         SetTimeFldEditable(i, true);

         sTime = (Char *)MemHandleLock(ttControls[i].hndTime);
         if(ttPrefs.ttClocks[j].bEmpty)
            StrCopy(sTime, "");
         else {
            FormatTimer(sTime, ttPrefs.ttClocks[j].lElapsed);
         }
            
         MemHandleUnlock(ttControls[i].hndTime);
         FldSetTextHandle(ttControls[i].ptrTime,
                          (MemHandle)ttControls[i].hndTime);
         FldDrawField(ttControls[i].ptrTime);
      }

      // update descriptions
      if(UpdateDescriptions) {
         sDesc = MemHandleLock(ttControls[i].hndDesc);
         StrCopy(sDesc, ttPrefs.ttClocks[j].sDesc);
         MemHandleUnlock(ttControls[i].hndDesc);
         FldSetTextHandle(ttControls[i].ptrDesc,
                          (MemHandle)ttControls[i].hndDesc);
         FldDrawField(ttControls[i].ptrDesc);
      }

      // update controls
      if(UpdateControls) {
         CtlSetValue(Id2Ptr(ID_ChkFirst + i), ttPrefs.ttClocks[j].bOn);
         CtlSetValue(Id2Ptr(ID_StkFirst + i), ttPrefs.ttClocks[j].bSticky);
      }
   }

   iLastPage = ttPrefs.iPage;
}


static void ToggleTikTok(Int32 iTikTokControl)
{
   Int32 iTikTok = iTikTokControl + ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   SetFocused(iTikTokControl, true, true, TF_TEXT);

   if(ttPrefs.ttClocks[iTikTok].bOn)
      StopTikTok(iTikTok, TT_ONE);
   else
      StartTikTok(iTikTok, TT_ONE);
}


static void StopTikTok(Int32 iTikTok, t_Quantity quantity)
{
   UInt32 ulNow = TimGetSeconds();
   Int32 i, iMin, iMax;
   Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   if(quantity == TT_NONE)
      return;

   if(quantity == TT_ALL) {
      iMin = 0;
      iMax = TT_CLOCKS;
   }
   else if(quantity == TT_PAGE) {
      iMin = offset;
      iMax = iMin + TT_CLOCKS_PER_PAGE;
   }
   else { // quantity == TT_ONE
      iMin = iTikTok;
      iMax = iMin + 1;
   }

   for(i = iMin; i < iMax; i++) {
      if(ttPrefs.ttClocks[i].bOn) {
         ttPrefs.ttClocks[i].lElapsed += (ulNow - ttPrefs.ttClocks[i].ulStart);
         ttPrefs.ttClocks[i].bOn       = false;
         ttPrefs.ttClocks[i].bEmpty    = false;
         ttPrefs.ttClocks[i].AlmState  = AS_OFF;
      }
      if(IsVisible(i)) {
         SetTimeFldEditable(i - offset, true);
         CtlSetValue(Id2Ptr(ID_ChkFirst + i - offset), false);
      }
   }

   SetAlarm(&ttPrefs, true);
}


static void StartTikTok(Int32 iTikTok, t_Quantity quantity)
{
   UInt32  ulNow = TimGetSeconds();
   Boolean bOk;
   Int32   lEntered;
   Boolean bEntered;
   Int32   i, iMin, iMax;
   Int32   offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   SaveTikToks(&ttPrefs, true);

   if(quantity == TT_NONE)
      return;

   if(quantity == TT_ALL) {
      iMin = 0;
      iMax = TT_CLOCKS;
   }
   else if(quantity == TT_PAGE) {
      iMin = offset;
      iMax = iMin + TT_CLOCKS_PER_PAGE;
   }
   else { // quantity == TT_ONE
      iMin = iTikTok;
      iMax = iMin + 1;
   }

   for(i = iMin; i < iMax; i++) {
      bOk = true;
      lEntered = 0L;
      if(IsVisible(i))
         bEntered = IsTimeFieldDirty(i - offset);
      else
         bEntered = false;

      if(!ttPrefs.ttClocks[i].bOn) {
         if(bEntered)
            lEntered = ParseTimeField(i - offset, &bOk, true);

         if(bOk) {
            ttPrefs.ttClocks[i].bOn     = true;
            ttPrefs.ttClocks[i].ulStart = ulNow;

            if(bEntered) {
               ttPrefs.ttClocks[i].lElapsed = lEntered;
               ttPrefs.ttClocks[i].lInitial = lEntered;
            }
            else if(!ttPrefs.ttClocks[i].bSticky) {
               ttPrefs.ttClocks[i].lElapsed =
                  (ttPrefs.bMemory ? ttPrefs.ttClocks[i].lInitial : 0L);
            }
        
            ttPrefs.ttClocks[i].AlmState =
               (ttPrefs.ttClocks[i].lInitial < 0 ? AS_AWAITING_ALARM : AS_OFF);

            DefaultTheDescription(i, ulNow);

            if(IsVisible(i)) {
               CtlSetValue(Id2Ptr(ID_ChkFirst + i - offset), false);
            }
         }
      }
      SyncTikToks(i, true, true, true);
   }

   SetAlarm(&ttPrefs, true);
}


static void ToggleSticky(Int32 iTikTokControl)
{
   Int32 iTikTok = iTikTokControl + ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   SetFocused(iTikTokControl, true, false, TF_NO_CHANGE);
   ttPrefs.ttClocks[iTikTok].bSticky = !ttPrefs.ttClocks[iTikTok].bSticky;
}


static void FormatTimer(Char *sTimer, Int32 lElapsed)
{
   Boolean bNeg = (lElapsed < 0);
   UInt32  uiDays;
   UInt32  uiHours;
   UInt32  uiMins;
   UInt32  uiSecs;

   StrCopy(sTimer, (bNeg ? "-" : ""));

   if(bNeg)
      lElapsed = -lElapsed;
    
   uiDays   = (UInt32)(lElapsed / 86400L);
   lElapsed =  (Int32)(lElapsed % 86400L);
   uiHours  = (UInt32)(lElapsed / 3600L );
   lElapsed =  (Int32)(lElapsed % 3600L );
   uiMins   = (UInt32)(lElapsed / 60L   );
   uiSecs   = (UInt32)(lElapsed % 60L   );

   ICat(uiDays, sTimer);
   StrCat(sTimer, sDecimalChar);
   ZeroPadICat(uiHours, sTimer);
   StrCat(sTimer, sTimeSeparator);
   ZeroPadICat(uiMins, sTimer);
   StrCat(sTimer, sTimeSeparator);
   ZeroPadICat(uiSecs, sTimer);
}


static void ICat(UInt32 ui, Char *s)
{
   Char sBuff[TEMP_BUF_SIZE];

   StrIToA(sBuff, ui);
   StrCat(s, sBuff);
}


static void ZeroPadICat(UInt32 ui, Char *s)
{
   if(ui < TEMP_BUF_SIZE)
      StrCat(s, "0");

   ICat(ui, s);
}


static void SaveTikToks(t_TikTokPrefs *pttPrefs, Boolean bSaveDesc)
{
   Char  *ptrDesc;
   Int32 i, j;
   Boolean bOk;
   Int32   lEntered;

   if(bSaveDesc) {
      Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

      for(i = 0, j = offset; i < TT_CLOCKS_PER_PAGE; i++, j++) {
         ptrDesc = MemHandleLock(ttControls[i].hndDesc);
         StrCopy(pttPrefs->ttClocks[j].sDesc, ptrDesc);
         MemHandleUnlock(ttControls[i].hndDesc);

         // save any unstarted timers
         if(!ttPrefs.ttClocks[i + offset].bOn) {
            if(IsTimeFieldDirty(i)) {
               lEntered = ParseTimeField(i, &bOk, false);

               if(bOk) {
                  ttPrefs.ttClocks[i+offset].bEmpty = (Boolean)(lEntered == 0L);
                  ttPrefs.ttClocks[i+offset].lElapsed = lEntered;
                  ttPrefs.ttClocks[i+offset].lInitial = lEntered;
               }
            }
         }
      }
   }

   PrefSetAppPreferencesV10(APP_ID, PREF_VER, (MemPtr)pttPrefs,
                            sizeof(t_TikTokPrefs));
}


static void ClearTikToks(t_TikTokClear ttClrType, Boolean bSetToZero)
{
   UInt32  ulNow;
   Int32   iFirst = 0;
   Int32   iLast  = TT_CLOCKS;
   Boolean bAll   = false;
   Int32   i;
   Int32   offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   switch(ttClrType) {
      case TT_CLR_FOCUSED:
         iFirst = FocusedTikTok() + offset;
         iLast  = iFirst + 1;
         bAll   = true;
         break;

      case TT_CLR_STOPPED:
         bAll = false;
         break;

      case TT_CLR_ALL:
         {
            t_Quantity quantity = 
               FrmAlert(bSetToZero ? ID_AltZeroAll : ID_AltClearAll);

            if(quantity == TT_ALL) {
               iFirst = 0;
               iLast  = TT_CLOCKS;
               bAll   = true;
            }
            else if(quantity == TT_PAGE) {
               iFirst = offset;
               iLast  = iFirst + TT_CLOCKS_PER_PAGE;
               bAll   = true;
            }
            else {
               iFirst = iLast = 0;
            }
         }
         break;
   }
    
   ulNow = TimGetSeconds();

   for(i = iFirst; i < iLast; i++) {
      if((!ttPrefs.ttClocks[i].bOn && !ttPrefs.ttClocks[i].bSticky ) || bAll) {
         ttPrefs.ttClocks[i].AlmState = AS_OFF;

         if(!bSetToZero) {
            ttPrefs.ttClocks[i].bOn     = false;
            ttPrefs.ttClocks[i].bEmpty  = true;
            ttPrefs.ttClocks[i].bSticky = false;
            StrCopy(ttPrefs.ttClocks[i].sDesc, "");
         }
         else {
            ttPrefs.ttClocks[i].ulStart = ulNow;
         }

         ttPrefs.ttClocks[i].lElapsed = 0L;
         ttPrefs.ttClocks[i].lInitial = 0L;

         SyncTikToks(i, true, true, true);
      }
   }

   SetAlarm(&ttPrefs, true);
}


static void *Id2Ptr(UInt16 wID)
{
   FormPtr pForm = FrmGetActiveForm();

   return(FrmGetObjectPtr(pForm, FrmGetObjectIndex(pForm, wID)));
}


static void DefaultTheDescription(Int32 iTikTok, UInt32 ulTime)
{
   Char         *ptrEOS;
   DateTimeType dtNow;

   if(StrLen(ttPrefs.ttClocks[iTikTok].sDesc) == 0) {
      TimSecondsToDateTime(ulTime, &dtNow);

      DateToAscii(dtNow.month, dtNow.day, dtNow.year, sysPrefs.dateFormat,
                  ttPrefs.ttClocks[iTikTok].sDesc);
      StrCat(ttPrefs.ttClocks[iTikTok].sDesc, " ");
      ptrEOS = ttPrefs.ttClocks[iTikTok].sDesc +
               StrLen(ttPrefs.ttClocks[iTikTok].sDesc);
      TimeToAscii(dtNow.hour, dtNow.minute, sysPrefs.timeFormat, ptrEOS);
   }
}


static Int32 FocusedTikTok(void)
{
   Int32  iTikTokControl  = 0;
   UInt16 wFocused = GetFocusID();

   if(IS_TEXT_FIELD(wFocused))
      iTikTokControl = wFocused - ID_TxtFirst;
   else if(IS_SEC_FIELD(wFocused))
      iTikTokControl = wFocused - ID_SecFirst;

   return iTikTokControl;
}


static UInt16 GetFocusID(void)
{
   UInt16 wFocused = FrmGetFocus(FrmGetActiveForm());

   if(wFocused != noFocus)
      wFocused = FrmGetObjectId(FrmGetActiveForm(), wFocused);
    
   return wFocused;
}


static Boolean IsTimeFieldDirty(Int32 iTikTok)
{
   return FldDirty(Id2Ptr(ID_SecFirst + iTikTok));
}


static void SetTimeFldEditable(Int32 iTikTok, Boolean bEdit)
{
   FieldPtr      ptrTime = Id2Ptr(ID_SecFirst + iTikTok);
   FieldAttrType attr;

   FldGetAttributes(ptrTime, &attr);
   attr.editable = bEdit;
   FldSetAttributes(ptrTime, &attr);
   FldReleaseFocus(ptrTime);
   FldDrawField(ptrTime);
}


static Int32 ParseTimeField(Int32 iTikTok, Boolean *pbOk, Boolean bGui)
{
   Int32   lTime      = 0L;
   Int32   lCurrent   = 0L;
   Int32   lDays      = 0L;
   Int32   iColons    = 0;
   Char    *pTime     = FldGetTextPtr(Id2Ptr(ID_SecFirst + iTikTok));
   Boolean bNeg       = false;
   Boolean bErr       = false;
   Boolean bHitStart  = false;
   Boolean bHitDigits = false;
   Boolean bGotDays   = false;

   if(pTime) {
      /* Skip any whitespace we find at the start. */
      while(*pTime && *pTime == ' ') {
         ++pTime;
      }
        
      for(; *pTime && !bErr; pTime++) {
         if(*pTime == '-') {
            if(!bHitStart) {
               bNeg      = true;
               bHitStart = true;
            }
            else {
               bErr = true;
            }
         } else if(*pTime == '+') {
            if(!bHitStart) {
               bNeg      = false;
               bHitStart = true;
            }
            else {
               bErr = true;
            }
         } else if((*pTime == decimalChar || *pTime == 'd') && !bGotDays) {
            if(bHitStart && bHitDigits && !bGotDays) {
               lDays    = lCurrent;
               lCurrent = 0L;
               bGotDays = true;
            }
            else {
               bErr = true;
            }
         } else if(*pTime == timeSeparator || *pTime == 't') {
            if(bHitStart && bHitDigits && iColons < 2) {
               lTime    = (lTime + lCurrent) * 60L;
               lCurrent = 0L;
               ++iColons;
            }
            else {
               bErr = true;
            }
         } else {
            if(*pTime >= '0' && *pTime <= '9') {
               bHitDigits = true;
               bHitStart  = true;
               lCurrent   = (lCurrent * 10L) + (*pTime - '0');
            }
            else {
               bErr = true;
            }
         }
      }

      lTime += lCurrent;
        
      if(lDays) {
         while(iColons < 2) {
            lTime *= 60L;
            ++iColons;
         }
         lTime += lDays * 86400L;
      }
   }

   if(pbOk != NULL)
      *pbOk = !bErr;
    
   if(bErr && bGui)
      FrmAlert(ID_AltParseErr);
    
   return (bNeg ? -lTime : lTime);
}


static void StuffTikTok(const Char *pszTime)
{
   Char *sTime;
   Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;
   Int32 iTikTok = FocusedTikTok() + offset;

   StopTikTok(iTikTok, TT_ONE);

   if(IsVisible(iTikTok)) {
      sTime = (Char *)MemHandleLock(ttControls[iTikTok - offset].hndTime);
      StrCopy(sTime, pszTime);
      MemHandleUnlock(ttControls[iTikTok - offset].hndTime);
      FldSetTextHandle(Id2Ptr(iTikTok - offset + ID_SecFirst),
                       (MemHandle)ttControls[iTikTok - offset].hndTime);

      FldSetDirty(ttControls[iTikTok - offset].ptrTime, true);
   }
                        
   SetFocused(ttPrefs.iFocused, true, false, TF_TEXT);

   StartTikTok(iTikTok, TT_ONE);

   SyncTikToks(TT_SYNC_ALL, false, false, false);
}


static void ShowTime(void)
{
   static RectangleType clearAllRect   = {{92, 18}, {60, 22}};
   static RectangleType clearDigitRect = {{92, 18}, { 9, 22}};
   static Boolean bLastShowTime = true;

   if(bVgaExists)
      VgaSetScreenMode(screenModeScaleToFit, rotateModeNone);

   if(ttPrefs.bShowTime) {
      DateTimeType dtNow;
      Boolean bAm = false;
      FontID savedFont = FntGetFont();
      Char sTemp[3];

      TimSecondsToDateTime(TimGetSeconds(), &dtNow);

      if(!Use24HourFormat(sysPrefs.timeFormat)) {
         bAm = !(dtNow.hour >= 12);
         if(!bAm) {
            dtNow.hour -= 12;
         }
         if(dtNow.hour == 0) {
            dtNow.hour += 12;
         }
      }

      FntSetFont(ledFont);
      PutWordToString(sTemp, dtNow.hour,   3, false);
      if(dtNow.hour < 10) {
         WinEraseRectangle(&clearDigitRect, 0);
         WinDrawChars(sTemp, 1, 101, 18);
      }
      else {
         WinDrawChars(sTemp, 2, 92,  18);
      }
      PutWordToString(sTemp, dtNow.minute, 3, true);
      WinDrawChars(sTemp, 2, 114, 18);
      FntSetFont(savedFont);
      PutWordToString(sTemp, dtNow.second, 3, true);
      WinDrawChars(sTemp, 2, 134, 17);
      if(!Use24HourFormat(sysPrefs.timeFormat))
         WinDrawChars(bAm ? "am" : "pm", 2, 134, 27);

      bLastShowTime = true;
   }
   else {
      if(bLastShowTime) {
         WinEraseRectangle(&clearAllRect, 0);
         bLastShowTime = false;
      }
   }

   if(bVgaExists)
      VgaSetScreenMode(screenMode1To1, rotateModeNone);
}


static UInt32 CalcNextAlarm(Boolean bRecalcAll, t_TikTokPrefs *pttPrefs)
{
   UInt32 ulNext = 0;
   UInt32 ulExpires;
   Int32  i;

   for(i = 0; i < TT_CLOCKS; i++) {
      t_AlmState AlmState = pttPrefs->ttClocks[i].AlmState;

      if(AlmState == AS_AWAITING_ALARM || (bRecalcAll && AlmState > AS_OFF)) {
         ulExpires = pttPrefs->ttClocks[i].ulStart -
                     pttPrefs->ttClocks[i].lElapsed;

         if(ulNext == 0 || ulExpires < ulNext) {
            ulNext = ulExpires;
         }
      }
   }

   return ulNext;
}


static void SetAlarm(t_TikTokPrefs *pttPrefs, Boolean bRecalcAll)
{
   UInt16            uiCardNo;
   LocalID           dbID;
   DmSearchStateType dmsDummy;

   if(!DmGetNextDatabaseByTypeCreator(true, &dmsDummy, APP_TYPE, APP_ID,
                                      true, &uiCardNo, &dbID)) {
      UInt32 ulAlarm = CalcNextAlarm(bRecalcAll, pttPrefs);
        
      AlmSetAlarm(uiCardNo, dbID, 0, ulAlarm, 0);
   }
}


static void PlayAlarm(t_TikTokPrefs *pttPrefs)
{
   Int32  i;
   Int32  initialOffset = 0;
   UInt32 ulExpires = 0;
   UInt32 ulNow = TimGetSeconds();
   UInt16 alarmCount = 0;

   for(i = 0; i < TT_CLOCKS; i++) {
      if(pttPrefs->ttClocks[i].AlmState == AS_AWAITING_ALARM) {
         ulExpires = pttPrefs->ttClocks[i].ulStart -
                     pttPrefs->ttClocks[i].lElapsed;

         // (ulExpires - 1) takes into account short one second alarms
         initialOffset = (pttPrefs->ttClocks[i].lInitial == -1 ? 1 : 0);
         if((ulExpires - initialOffset) <= ulNow) {
            pttPrefs->ttClocks[i].AlmState =
               (pttPrefs->bVisAlm ? AS_AWAITING_DISPLAY : AS_OFF);
            alarmCount++;
         }
      }
   }

   SetAlarm(pttPrefs, false); // set next alarm

   PlayAlarmSound(pttPrefs->SoundRecID);
}


static void RaiseAlarm(t_TikTokPrefs *pttPrefs, Boolean bAppIsActive)
{
   /* When called as an alarm you can't use globals and it seeams you can't
      have large local structures either. So, in this case we'll allocate
      some memory and load the preferences into there instead. */
    
   if(pttPrefs->bVisAlm) {
      Int32 i;

      for(i = 0; i < TT_CLOCKS; i++) {
         MemHandle hndNote;
         Char      *pszNote;
         FormPtr   pForm, pCurrentForm;
         FieldPtr  pTxtAlarm;
         
         LoadTikToks(pttPrefs);

         if(pttPrefs->ttClocks[i].AlmState != AS_AWAITING_DISPLAY)
            continue;

         hndNote = MemHandleNew(50);
         pszNote = (Char *)MemHandleLock(hndNote);

         pttPrefs->ttClocks[i].AlmState = AS_OFF;

         SaveTikToks(pttPrefs, false);

         if(pttPrefs->ttClocks[i].sDesc && pttPrefs->ttClocks[i].sDesc[0]) {
            StrCopy(pszNote, pttPrefs->ttClocks[i].sDesc);
         }
         else {
            StrCopy(pszNote, "(untitled)");
         }
        
         // handle VGA scaling
         if(bAppIsActive)
            if(bVgaExists)
               VgaSetScreenMode(screenModeScaleToFit, rotateModeNone);

         // init alarm form
         pForm =
            FrmInitForm((GetROMVerMajor() >= 3 ? ID_FrmAlarm3 : ID_FrmAlarm));

         // save current form and set new form
         pCurrentForm = FrmGetActiveForm();
         if(pCurrentForm)
            FrmSetActiveForm(pForm);
   
         // set alarm form event handler
         FrmSetEventHandler(pForm, AlarmEventHandler);

         // draw the alarm form
         FrmDrawForm(pForm);

         // set alarm message
         pTxtAlarm = FrmGetObjectPtr(pForm,
                                     FrmGetObjectIndex(pForm, ID_TxtAlarm));
         FldSetTextHandle(pTxtAlarm, (MemHandle)hndNote);
         MemHandleUnlock(hndNote);
         FldDrawField(pTxtAlarm);

         // now wait for alarm form to exit
         FrmDoDialog(pForm);

         // handle VGA scaling
         if(bAppIsActive)
            if(bVgaExists)
               VgaSetScreenMode(screenMode1To1, rotateModeNone);


         // now clean up form
         FrmEraseForm(pForm);
         FrmDeleteForm(pForm);
         FrmSetActiveForm(pCurrentForm);

         // no longer needed since attached to a form // MemHandleFree(hndNote);
      }
   }
}


static UInt16 GetROMVerMajor(void)
{
   UInt32 dwROMVer;

   FtrGet(sysFtrCreator, sysFtrNumROMVersion, &dwROMVer);

   return sysGetROMVerMajor(dwROMVer);
}


static UInt16 GetCurrentFieldId(void)
{
   FormPtr pForm = FrmGetActiveForm();
   UInt16 wFocused = FrmGetFocus(pForm);

   return FrmGetObjectId(pForm, wFocused);
}


static void HandleNextPrevField(UInt16 keyDown)
{
   UInt16 fieldID = GetCurrentFieldId();
   Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;
   Int32  iFocus;
   t_Focused focusType;

   if(IS_TEXT_FIELD(fieldID)) {
      focusType = TF_SEC;

      iFocus = fieldID - ID_TxtFirst;
      if(keyDown == vchrPrevField)
         iFocus--;

      if(ttPrefs.ttClocks[iFocus + offset].bOn) {
         focusType = TF_TEXT;
         if(keyDown == vchrNextField)
            iFocus++;
      }
   }
   else {
      iFocus = fieldID - ID_SecFirst;
      focusType = TF_TEXT;
      if(keyDown == vchrNextField)
         iFocus++;
   }
   
   if(iFocus < 0) {
      iFocus = TT_CLOCKS_PER_PAGE - 1;
      focusType = TF_SEC;
   } else if(iFocus >= TT_CLOCKS_PER_PAGE) {
      iFocus = 0;
      focusType = TF_TEXT;
   }
      
   SetFocused(iFocus, true, false, focusType);
}


static void StartStopFocused(t_Method method)
{
   Int32 iTikTokControl = FocusedTikTok();
   Int32 iTikTok = iTikTokControl + ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   switch(method) {
      case TT_START:
         StartTikTok(iTikTok, TT_ONE);
         break;

      case TT_STOP:
         StopTikTok(iTikTok, TT_ONE);
         break;

      case TT_TOGGLE:
         ToggleTikTok(iTikTokControl);
         break;
   }
}


static void TogglePersistentFocused(void)
{
   Int32 iTikTok = FocusedTikTok();
                        
   CtlSetValue(Id2Ptr(ID_StkFirst + iTikTok),
               !CtlGetValue(Id2Ptr(ID_StkFirst + iTikTok)));
   ToggleSticky(iTikTok);
   SyncTikToks(TT_SYNC_ALL, false, false, false);
}


static Int32 GetiFocused(void)
{
   UInt16 wFocused = FrmGetFocus(FrmGetActiveForm());
   Int32 iFocused = 0;

   if(wFocused != noFocus) {
      iFocused = FrmGetObjectId(FrmGetActiveForm(), wFocused);

      if(IS_TEXT_FIELD(iFocused)) {
         iFocused -= ID_TxtFirst;
      }
      else if(IS_SEC_FIELD(iFocused)) {
         iFocused -= ID_SecFirst;
      }
      else {
         iFocused = 0;
      }
   }

   return iFocused;
}


static void SetFocused(Int32 iFocus, Boolean changeFocus, Boolean force,
                       t_Focused focusType)
{
   static RectangleType r = {{12, 46}, {3, 8}};
   RectangleType rTemp;
   static t_Focused lastFocusType = TF_NA;
   Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;
   Int32 base;
   Int32 topLine, lineSpacing;

   if(iLastFocused == iFocus && lastFocusType == focusType && force == false)
      return;

   switch(focusType) {
      case TF_TEXT:
         base = ID_TxtFirst;
         break;

      case TF_SEC:
         base = ID_SecFirst;
         break;

      case TF_NO_CHANGE:
      default:
         if(IS_TEXT_FIELD(GetCurrentFieldId()))
            base = ID_TxtFirst;
         else
            base = ID_SecFirst;
         break;
   }

   if(ttPrefs.ttClocks[iFocus + offset].bOn)
      base = ID_TxtFirst;

   if(changeFocus)
      FrmSetFocus(FrmGetActiveForm(), FrmGetObjectIndex(FrmGetActiveForm(),
                  base + iFocus));
   ttPrefs.iFocused = iFocus;

   topLine     = (bVgaExists ? 69 : 46);
   lineSpacing = (bVgaExists ? 18 : 12);
   if(bVgaExists) {
      r.topLeft.x = 18;
      r.topLeft.y = 69;
      r.extent.x  = 5;
      r.extent.y  = 12;
   }

   if(iLastFocused != -1) {
      FldGetBounds(Id2Ptr(ID_TxtFirst + iLastFocused), &rTemp);
      r.topLeft.y = rTemp.topLeft.y + (bVgaExists ? 3 : 2);
      WinEraseRectangle(&r, 0);
   }
   FldGetBounds(Id2Ptr(ID_TxtFirst + iFocus), &rTemp);
   r.topLeft.y = rTemp.topLeft.y + (bVgaExists ? 3 : 2);
   WinDrawRectangle(&r, 0);

   iLastFocused = iFocus;
   lastFocusType = (base == ID_TxtFirst ? TF_TEXT : TF_SEC);
}


static void PutWordToString(Char *pszTxt, UInt16 w,
                            UInt16 wMaxSize __attribute__ ((unused)),
                            Boolean bZeroPad)
{
   *pszTxt = 0;

   if(bZeroPad)
      ZeroPadICat(w, pszTxt);
   else
      ICat(w, pszTxt);
}


static void SystemWasReset(void)
{
   t_TikTokPrefs *pttPrefs = (t_TikTokPrefs *)MemPtrNew(sizeof(t_TikTokPrefs));

   // Note that this function does not see any globals
    
   LoadTikToks(pttPrefs);
   SetAlarm(pttPrefs, true);
   MemPtrFree((MemPtr)pttPrefs);
}


static Boolean AlarmEventHandler(EventPtr event)
{
   Boolean handled = true;

   // We don't want to allow an other application to be launched 
   // while an alarm is displayed, so we intercept appStop events.
   // All other event are handled by FrmDoDialog.
   if(event->eType != appStopEvent)
      handled = false;

   return handled;
}


static void DisplayAboutForm(UInt16 rscID)
{
   FormPtr pForm = FrmGetActiveForm();
   FormPtr pNewForm = FrmInitForm(rscID);

   if(bVgaExists)
      VgaFormModify(pNewForm, vgaFormModify160To240);

   // show the about form
   FrmDoDialog(pNewForm);

   FrmDeleteForm(pNewForm);
   FrmSetActiveForm(pForm);
}


static Boolean HandlePageUpDown(t_TikTokBtnFn direction, Boolean bWrap)
{
   Boolean bUpdate = true;

   SaveTikToks(&ttPrefs, true);

   switch(direction) {
      case BF_PAGE_UP:
         ttPrefs.iPage--;
         if(ttPrefs.iPage < 0) {
            if(bWrap)
               ttPrefs.iPage = TT_NUM_PAGES - 1;
            else {
               ttPrefs.iPage = 0;
               bUpdate = false;
            }
         }
         break;

      case BF_PAGE_DOWN:
         ttPrefs.iPage++;
         if(ttPrefs.iPage >= TT_NUM_PAGES) {
            if(bWrap)
               ttPrefs.iPage = 0;
            else {
               ttPrefs.iPage = TT_NUM_PAGES - 1;
               bUpdate = false;
            }
         }
         break;

      default:
         break;
   }

   if(bUpdate) {
      MainUpdateForm(true);
      SyncTikToks(TT_SYNC_ALL, true, true, true);
   }

   SetFocused(ttPrefs.iFocused, true, true, TF_NO_CHANGE);

   return bUpdate;
}


static void MainUpdateForm(Boolean bRefresh)
{
   FormPtr pForm = FrmGetActiveForm();
   UInt16 wUp    = FrmGetObjectIndex(pForm, ID_RepUp);
   UInt16 wDown  = FrmGetObjectIndex(pForm, ID_RepDown);

   FrmUpdateScrollers(pForm, wUp, wDown,
                      ttPrefs.iPage != 0, ttPrefs.iPage != TT_NUM_PAGES - 1);

   if(!bRefresh)
      FrmDrawForm(pForm);

   // upate "page x of y"
   LstSetSelection(Id2Ptr(listID_page), ttPrefs.iPage);
   CtlSetLabel(Id2Ptr(popuptriggerID_page),
               LstGetSelectionText(Id2Ptr(listID_page), ttPrefs.iPage));
}


static Boolean IsVisible(Int32 iTikTok)
{
   Int32 offset = ttPrefs.iPage * TT_CLOCKS_PER_PAGE;

   return (iTikTok >= offset && iTikTok < offset + TT_CLOCKS_PER_PAGE);
}


static Boolean IsNotValidChar(WChar *key)
{
   Boolean result = true;

   if(IS_TEXT_FIELD(GetCurrentFieldId()))
      return false;

   if(*key >= '0' && *key <= '9')
      result = false;
   if(*key == (WChar)timeSeparator ||
      *key == (WChar)decimalChar   ||
      *key == '+'                  ||
      *key == '-'                  ||
      *key == chrLeftArrow         ||
      *key == chrRightArrow        ||
      *key == chrBackspace         ||
      *key == 0x0001               ||   // Del   on Palm Portable Keyboard
      *key == 0x012d               ||   // Ctl-X on Palm Portable Keyboard
      *key == 0x012e               ||   // Ctl-C on Palm Portable Keyboard
      *key == 0x012f                  ) // Ctl-V on Palm Portable Keyboard
         result = false;

   if(result)
      CLICK;

   return result;
}


static Char DecimalChar(NumberFormatType n)
{
   Char decimalChar;

   switch(n) {
      case nfPeriodComma:
      case nfSpaceComma:
      case nfApostropheComma:
         decimalChar = ',';
         break;

      default:
         decimalChar = '.';
         break;
   }

   return decimalChar;
}


static void PlayAlarmSound(UInt32 uniqueRecID)
{
   Err err;
   MemHandle midiH;               // handle of MIDI record
   SndMidiRecHdrType* midiHdrP;   // pointer to MIDI record header
   UInt8* midiStreamP;            // pointer to MIDI stream beginning with
                                  //   the 'MThd' SMF header chunk
   UInt16 cardNo;                 // card number of System MIDI database
   LocalID dbID;                  // Local ID of System MIDI database
   DmOpenRef dbP = NULL;          // reference to open database
   UInt16 recIndex;               // record index of the MIDI record to play
   SndSmfOptionsType smfOpt;      // SMF play options
   DmSearchStateType searchState; // search state for finding the System
                                  //   MIDI database
   Boolean bError = false;        // set to true if we couldn't find the
                                  //   MIDI record

   // Find the system MIDI database
   err = DmGetNextDatabaseByTypeCreator(true, &searchState,
                                        sysFileTMidi, sysFileCSystem, false, 
                                        &cardNo, &dbID);
   if(err)
      bError = true; // DB not found

   // Open the MIDI database in read-only mode
   if(!bError) {
      dbP = DmOpenDatabase(cardNo, dbID, dmModeReadOnly);
      if(!dbP)
         bError = true; // couldn't open
   }

   // Find the MIDI track record
   if(!bError) {
      err = DmFindRecordByID(dbP, uniqueRecID, &recIndex);
      if(err)
         bError = true; // record not found
   }

   // Lock the record and play the sound
   if(!bError) {
      // Find the record handle and lock the record
      midiH = DmQueryRecord(dbP, recIndex);
      midiHdrP = MemHandleLock(midiH);

      // Get a pointer to the SMF stream
      midiStreamP = (UInt8*)midiHdrP + midiHdrP->bDataOffset;

      // Play the sound (ignore the error code)
      // The sound can be interrupted by a key/digitizer event
      smfOpt.dwStartMilliSec = 0;
      smfOpt.dwEndMilliSec = sndSmfPlayAllMilliSec;
      smfOpt.amplitude = (UInt16)PrefGetPreference(prefAlarmSoundVolume);
      smfOpt.interruptible = true;
      smfOpt.reserved = 0;
      err = SndPlaySmf(NULL, sndSmfCmdPlay, midiStreamP, &smfOpt,
                       NULL, NULL, false);
		
      // Unlock the record
      MemPtrUnlock(midiHdrP);
   }

   // Close the MIDI database
   if(dbP)
      DmCloseDatabase(dbP);

   // If there was an error, play the built-in alarm sound
   if(bError)
      SndPlaySystemSound(sndAlarm);
}


static void AlarmSoundListInit(void)
{
   FormPtr pForm = FrmGetActiveForm();
   ListPtr listP;
   UInt16 item;
   UInt16 i;
   SndMidiListItemType* midiListP;
   Char* defaultName;
	
   if(ROMVerMajor < 3) {
      FrmHideObject(pForm, FrmGetObjectIndex(pForm, ID_AlarmSoundLabel));
      CtlHideControl(Id2Ptr(popuptriggerID_AlarmSound));
      CtlHideControl(Id2Ptr(listID_AlarmSound));
      return;
   }

   tempSoundRecID = ttPrefs.SoundRecID;

   listP = Id2Ptr(listID_AlarmSound);

   CreateMidiPickList(pForm, listP, (ListDrawDataFuncPtr)MidiPickListDrawItem,
                      listID_AlarmSound);

   // Traverse MIDI pick list and find the item whose unique ID matches our
   // saved unique ID and use its index as our list selection index. If we
   // don't find a match, then we want to use the MIDI sound that corresponds
   // to our default sound name; if that's not found, use item 0.

   // Default to first sound in list
   item = 0;

   // Lock MIDI sound list
   if(gMidiListH) {
      midiListP = MemHandleLock(gMidiListH);
      defaultName = MemHandleLock(DmGetResource(strRsc,
                                                ID_DefaultAlarmSoundName));

      // Iterate through each item and get its unique ID
      for(i = 0; i < gMidiCount; i++) {
         if(midiListP[i].uniqueRecID == ttPrefs.SoundRecID) {
            item = i;
            break; // exit for loop
         }
         else if(StrCompare(midiListP[i].name, defaultName) == 0) {
            item = i;
         }
      }

      MemPtrUnlock(defaultName);

      // Set the list selection
      LstSetSelection(listP, item);

      // Init the sound trigger label
      // Create a new ptr to hold the label
      soundTriggerLabelP = MemPtrNew(soundTriggerLabelLen);
      // Check for mem failure
      ErrFatalDisplayIf(soundTriggerLabelP == NULL, "Out of memory");
      // Set the trigger label
      SetSoundLabel(pForm, midiListP[item].name);

      // Unlock MIDI sound list
      MemPtrUnlock(midiListP);
   }
}


static void SetSoundLabel(FormPtr formP, const Char* labelP)
{
   ControlPtr triggerP;
   UInt16 triggerIdx;

   // Copy the label, winUp to the max into the ptr
   StrNCopy(soundTriggerLabelP, labelP, soundTriggerLabelLen);
   // Terminate string at max len
   soundTriggerLabelP[soundTriggerLabelLen - 1] = '\0';
   // Get trigger idx
   triggerIdx = FrmGetObjectIndex(formP, popuptriggerID_AlarmSound);
   // Get trigger control ptr
   triggerP = FrmGetObjectPtr(formP, triggerIdx);
   // Use category routines to truncate it
   CategoryTruncateName(soundTriggerLabelP, soundTriggerLabelWidth);
   // Set the label
   CtlSetLabel(triggerP, soundTriggerLabelP);
}


static void MidiPickListDrawItem(UInt16 itemNum, RectanglePtr bounds, 
                                 Char **unusedP __attribute__ ((unused)))
{
   Char* itemTextP;
   Int16 itemTextLen;
   Int16 itemWidth;
   SndMidiListItemType* listP;
	
   ErrNonFatalDisplayIf(itemNum >= gMidiCount, "index out of bounds");
	
   // Bail out if MIDI sound list is empty
   if(gMidiListH == NULL)
      return;
	
   listP = MemHandleLock(gMidiListH);

   itemTextP = listP[itemNum].name;

   // Truncate the item with an ellipsis if it doesnt fit in the list width.
   // Get the item text length
   itemTextLen = StrLen(itemTextP);
   // Get the width of the text
   itemWidth = FntCharsWidth(itemTextP, itemTextLen);
   // Does it fit?
   if(itemWidth <= bounds->extent.x) {
      // Draw entire item text as is
      WinDrawChars(itemTextP, itemTextLen, bounds->topLeft.x,
                   bounds->topLeft.y);
   }
   else {
      // We're going to truncate the item text
      Boolean ignored;
      Char ellipsisChar = chrEllipsis;

      // Set the new max item width
      itemWidth = bounds->extent.x - FntCharWidth(ellipsisChar);
      // Find the item length that fits in the bounds minus the ellipsis
      FntCharsInWidth(itemTextP, &itemWidth, &itemTextLen, &ignored);
      // Draw item text that fits
      WinDrawChars(itemTextP, itemTextLen, bounds->topLeft.x,
                   bounds->topLeft.y);
      // Draw ellipsis Char
      WinDrawChars(&ellipsisChar, 1, bounds->topLeft.x + itemWidth,
                   bounds->topLeft.y);
   }

   // Unlock list items
   MemPtrUnlock(listP);
}


static void CreateMidiPickList(FormPtr pForm, ListPtr listP,
                               ListDrawDataFuncPtr funcP, UInt16 listID)
{
   SndMidiListItemType* midiListP;
   UInt16 i;
   UInt16 listWidth;
   UInt16 maxListWidth;
   Boolean bSuccess;
   RectangleType r;
   RectangleType listBounds;
   UInt16 listIndex = FrmGetObjectIndex(pForm, listID);
		
   // Load list of midi record entries
   bSuccess = SndCreateMidiList(sysFileCSystem, false, &gMidiCount,
                                &gMidiListH);
   if(!bSuccess) {
      gMidiListH = 0;
      gMidiCount = 0;
      return;
   }

   // Now set the list to hold the number of sounds found.  There
   // is no array of text to use.
   LstSetListChoices(listP, NULL, gMidiCount);

   // Now resize the list to the number of panel found
   LstSetHeight(listP, gMidiCount);

   // Because there is no array of text to use, we need a function
   // to interpret the panelIDsP list and draw the list items.
   LstSetDrawFunction(listP, funcP);

   // Make the list as wide as possible to display the full sound names
   // when it is popped winUp.

   // Lock MIDI sound list
   midiListP = MemHandleLock(gMidiListH);
   // Initialize max width
   maxListWidth = 0;
   // Iterate through each item and get its width
   for(i = 0; i < gMidiCount; i++) {
      // Get the width of this item
      listWidth = FntCharsWidth(midiListP[i].name, StrLen(midiListP[i].name));
      // If item width is greater that max, swap it
      if(listWidth > maxListWidth) {
         maxListWidth = listWidth;
      }
   }
   // Unlock MIDI sound list
   MemPtrUnlock(midiListP);

   // get list bounds
   FrmGetObjectBounds(pForm, listIndex, &listBounds);

   // Set list width to max width + left margin
   listBounds.extent.x = maxListWidth + 4;
   // Get pref dialog window extent
   FrmGetFormBounds(FrmGetActiveForm(), &r);
   // Make sure width is not more than window extent
   if(listBounds.extent.x > r.extent.x) {
      listBounds.extent.x = r.extent.x;
   }
   // Move list left if it doesnt fit in window
   if(listBounds.topLeft.x + listBounds.extent.x > r.extent.x) {
      listBounds.topLeft.x = r.extent.x - listBounds.extent.x;
   }
}


static void FreeMidiPickList(void)
{
   if(gMidiListH) {
      MemHandleFree(gMidiListH);
      gMidiListH = 0;
      gMidiCount = 0;
   }
}


static void FreeAllSoundStuff(void)
{
   // Free the MIDI pick list
   FreeMidiPickList();

   // Free the sound trigger label placeholder
   if(soundTriggerLabelP) {
      MemPtrFree(soundTriggerLabelP);
      soundTriggerLabelP = NULL;
   }
}


static void HandleAlarmChange(EventPtr e)
{
   UInt16 item;
   SndMidiListItemType* listP;
   FormPtr pForm = FrmGetActiveForm();

   // Get new selected item
   item = e->data.popSelect.selection;

   // Lock MIDI list
   listP = MemHandleLock(gMidiListH);

   // Save alarm sound unique rec ID
   tempSoundRecID = listP[item].uniqueRecID;

   // Erase control
   CtlEraseControl(e->data.popSelect.controlP);

   // Set new trigger label
   SetSoundLabel(pForm, listP[item].name);

   // Redraw control
   CtlDrawControl(e->data.popSelect.controlP);

   // Unlock MIDI list
   MemPtrUnlock(listP);

   // Play new alarm sound
   PlayAlarmSound(tempSoundRecID);
}


///////////////////////////
// HandEra VGA Functions //
///////////////////////////

static void SizeForm(FormPtr pForm)
{
   RectangleType winRect;
   Coord xDiff, yDiff;
   Boolean bDraw;

   if(!bVgaExists)
      return;

   bDraw = FrmVisible(pForm);

   // set new window bounds
   winRect.topLeft.x = 0;
   winRect.topLeft.y = 0;
   WinGetDisplayExtent(&winRect.extent.x, &winRect.extent.y);
   xDiff = winRect.extent.x - oldWinRect.extent.x;
   yDiff = winRect.extent.y - oldWinRect.extent.y;
   oldWinRect = winRect;

   if((xDiff > 0) || (yDiff > 0))
      WinSetWindowBounds(FrmGetWindowHandle(pForm), &winRect);

   // move and size objects on form
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_BtnStart),
                0, yDiff, 0, 0, bDraw);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_BtnStop),
                0, yDiff, 0, 0, bDraw);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_BtnClear),
                0, yDiff, 0, 0, bDraw);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_BtnZero),
                0, yDiff, 0, 0, bDraw);
   ResizeObject(pForm, GetGSIIndex(pForm),
                0, yDiff, 0, 0, bDraw);
   if(yDiff > 0) {
      if(bDraw) {
         RectangleType rect;

         FrmGetObjectBounds(pForm,
                            FrmGetObjectIndex(pForm, ID_SecFirst+7), &rect);
         rect.topLeft.y += rect.extent.y;
         rect.extent.y  = yDiff;
         WinEraseRectangle(&rect, 0);
     }
   }
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_RepUp),
                0, yDiff, 0, 0, bDraw);
   ResizeObject(pForm, FrmGetObjectIndex(pForm, ID_RepDown),
                0, yDiff, 0, 0, bDraw);

   // redraw form (make sure graffiti shift indicator gets drawn)
   if(bDraw)
      FrmDrawForm(pForm);
}


static UInt16 GetGSIIndex(FormPtr pForm)
{
   UInt16 i, numObjects;

   numObjects = FrmGetNumberOfObjects(pForm);
   for(i = 0; i < numObjects; i++) {
      if(FrmGetObjectType(pForm, i) == frmGraffitiStateObj)
         return i;
   }

   return -1;
}


static void ResizeObject(FormPtr pForm, UInt16 objectIndex,
                         Coord xMove, Coord yMove,
                         Coord xExp, Coord yExp, Boolean bDraw)
{
   RectangleType r;
    
   if((xMove == 0) && (yMove == 0) && (xExp == 0) && (yExp == 0))
      return;
    
   FrmGetObjectBounds(pForm, objectIndex, &r);
   if(bDraw)
      FrmHideObject(pForm, objectIndex);
   r.topLeft.x += xMove;
   r.topLeft.y += yMove;
   r.extent.x  += xExp;
   r.extent.y  += yExp;
   FrmSetObjectBounds(pForm, objectIndex, &r);
    
   if(FrmGetObjectType(pForm, objectIndex) == frmGraffitiStateObj)
      GsiSetLocation(r.topLeft.x, r.topLeft.y);
    
   if(bDraw)
      FrmShowObject(pForm, objectIndex);
}
