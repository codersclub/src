///////////////////////////////////////////////////////////////////////////////
//                                                                           //
//        Program Name:  TikTok.h                                            //
//     Original Author:  David A. Pearson (� 1997-1998)                      //
// Modification Author:  Mike McCollister (� 1999-2001)                      //
//            Language:  PRC-Tools 2.0.92                                    //
//                       Palm OS 4.0 header files                            //
//                       PilRC 2.8                                           //
//                       HandEra Header Files from SDK 1.01                  //
//         Description:  Header file for TikTok.c                            //
//               Notes:  Distributed under the terms of the GNU General      //
//                       Public License version 2.0.                         //
//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#ifndef TIKTOK_H
#define	TIKTOK_H 1

/////////////
// Defines //
/////////////

#define MAX_TXT_CHARS		20	// used in form
#define MAX_SEC_CHARS		12	// used in form

#define MIN_X			0
#define MIN_Y			0
#define MAX_WIDTH		160
#define MAX_HEIGHT		160
#define MIN_X_MOD		2
#define MIN_Y_MOD		2
#define MAX_WIDTH_MOD		156
#define MAX_HEIGHT_MOD		156
#define CENTER_MOD		78
#define ALARM_LINE_SPACING	12
#define ABOUT_LINE_SPACING	12
#define ABOUT_LINE_SPACING2	18

#define soundTriggerLabelWidth  60


///////////////////
// Main Form IDs //
///////////////////

#define ID_ChkFirst             1300
#define ID_TxtFirst             1350
#define ID_SecFirst             1400
#define ID_StkFirst             1450

#define popuptriggerID_page	1500
#define listID_page		1501

#define ID_BtnStart   		1600
#define ID_BtnStop   		1601
#define ID_BtnClear		1602
#define ID_BtnZero		1603

#define ID_RepUp		1650
#define ID_RepDown		1651

#define ID_MnuTikTok            1000
#define ID_MnuClearFocused      1001
#define ID_MnuClearStopped      1002
#define ID_MnuClearAll          1003
#define ID_MnuZeroFocused       1004
#define ID_MnuZeroStopped       1005
#define ID_MnuZeroAll           1006
#define ID_MnuStartAll          1007
#define ID_MnuStopAll           1008

#define ID_MnuAlarm1Min         1020
#define ID_MnuAlarm2Min         1021
#define ID_MnuAlarm3Min         1022
#define ID_MnuAlarm4Min         1023
#define ID_MnuAlarm5Min         1024
#define ID_MnuAlarm30Min        1025
#define ID_MnuAlarm1Hr          1026
#define ID_MnuAlarm2Hr          1027
#define ID_MnuAlarm3Hr          1028
#define ID_MnuAlarm4Hr          1029
#define ID_MnuAlarm5Hr          1030
#define ID_MnuAlarm1Day         1031
#define ID_MnuAlarm2Day         1032

#define ID_MnuEditUndo          1040
#define ID_MnuEditCut           1041
#define ID_MnuEditCopy          1042
#define ID_MnuEditPaste         1043
#define ID_MnuEditSelectAll     1044
#define ID_MnuEditSep0          1045
#define ID_MnuEditKeyboard      1046
#define ID_MnuEditGrafHelp      1047

#define ID_MnuOptionsPrefs      1050
#define ID_MnuOptionsGetInfo    1051
#define ID_MnuOptionsAbout      1052


//////////////////////////
// Preferences Form IDs //
//////////////////////////

#define ID_FrmPrefs             1700

#define ID_ChkVisAlm              1710
#define ID_ChkButtonAll           1711
#define ID_ChkShowTime            1712
#define ID_ChkMemory              1713
#define ID_ChkAlmStp              1714
#define ID_BtnOK                  1715
#define ID_BtnCancel              1716
#define popuptriggerID_PageUp     1717
#define listID_PageUp             1718
#define popuptriggerID_PageDown   1719
#define listID_PageDown           1720
#define ID_AlarmSoundLabel        1721
#define popuptriggerID_AlarmSound 1722
#define listID_AlarmSound         1723
#define ID_DefaultAlarmSoundName  1724


////////////////////
// Alarm Form IDs //
////////////////////

#define ID_FrmAlarm             2000
#define ID_FrmAlarm3            2001


#define ID_TxtAlarm		2100


//////////////////////
// Alert Dialog IDs //
//////////////////////

#define ID_FrmTikTok            1200
#define ID_FrmAbout             1201


////////////////
// String IDs //
////////////////

#define ID_HlpTikTok            1100
#define ID_HlpPrefs             1101

#define ID_AltClearAll          1600
#define ID_AltParseErr          1601
#define ID_AltZeroAll           1602
#define ID_AltStartAll          1603
#define ID_AltStopAll           1604


////////////////
// Bitmap IDs //
////////////////

#define ID_BitmapAlarm          1700
#define ID_BitmapIcon           1701
#define ID_BitmapArrows         1702


#endif
