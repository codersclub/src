/*
 *  BackAll
 *  Change backup bits on a Palm Computing Platform device
 *
 *  Copyright 1999 Matthias Jordan <mjordan@sensenet.wirepool.free.de>
 *
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
 *
 */


#pragma pack(2)

#include "backall.h"

#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <System/DataMgr.h>


int mode;
#define mode_all 0
#define mode_new 1
#define mode_force 2



static void Change(int mode)
{
    Err res;
    DmSearchStateType state;
    UInt card;
    LocalID lid;
    UInt att;
    ULong moddate, backdate, crdate;
    char name[33], dumatt[17];


    res = DmGetNextDatabaseByTypeCreator(1, &state, 0l, 0l, 0, &card, &lid);
    while (res == 0)
    {
        DmDatabaseInfo(card, lid, name, &att, NULL, &crdate, &moddate, &backdate, NULL, NULL, NULL, NULL, NULL);
        
        if ((att & dmHdrAttrReadOnly) == 0)
        {
            /* database is writeable - so not in ROM */
            att = att | dmHdrAttrBackup;

            if (mode == mode_all)
            {
                DmSetDatabaseInfo(card, lid, NULL, &att, NULL, &crdate, &moddate, &backdate, NULL, NULL, NULL, NULL, NULL);
            }

            if ((moddate > backdate) || (backdate == 0))
            {
                DmSetDatabaseInfo(card, lid, NULL, &att, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            }

            if (mode == mode_force)
            {
                DmSetDatabaseInfo(card, lid, NULL, &att, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
            }
        }


        res = DmGetNextDatabaseByTypeCreator(0, &state, 0l, 0l, 0, &card, &lid);
    }
} /* Change */



static void RefreshForm(void)
{
    FrmDrawForm(FrmGetActiveForm());
} /* RefreshForm */



static Boolean ChangeHandler(EventPtr event)
{
    int handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
            RefreshForm();
            SysTaskDelay(sysTicksPerSecond);
            Change(mode);
            FrmReturnToForm(formID_bal);
            handled = 1;
            break;
    }
    return handled;
} /* ChangeHandler */








static Boolean MainHandler(EventPtr event)
{
int handled = 0,
    checked_button;
  char dum[20];

    switch (event->eType)
    {
        case frmOpenEvent:
            RefreshForm();
            handled = 1;
            break;

        case frmGotoEvent:
            RefreshForm();
            handled = 1;
            break;

        case ctlSelectEvent:  // A control button was pressed and released.
            switch (event->data.ctlEnter.controlID)
            {
                case buttonID_all:
                    {
                        mode = mode_all;
                        FrmPopupForm(formID_do);
                        handled = 1;
                        break;
                    }

                case buttonID_new:
                    {
                        mode = mode_new;
                        FrmPopupForm(formID_do);
                        handled = 1;
                        break;
                   }

                case buttonID_force:
                    {
                        mode = mode_force;
                        FrmPopupForm(formID_do);
                        handled = 1;
                        break;
                   }
            }
            break;
    }
    return handled;
} /* MainHandler */




static void EventLoop(void)
{
  short err;
  int formID;
  FormPtr form;
  EventType event;

  do
  {

    EvtGetEvent(&event, 2);

    if (SysHandleEvent(&event)) continue;
    if (MenuHandleEvent((void *)0, &event, &err)) continue;

    if (event.eType == frmLoadEvent)
    {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) 
      {
        case formID_bal:
        FrmSetEventHandler(form, (FormEventHandlerPtr) MainHandler);
        break;

        case formID_do:
        FrmSetEventHandler(form, (FormEventHandlerPtr) ChangeHandler);
        break;
      }
    } 
    FrmDispatchEvent(&event);
  }
  while(event.eType != appStopEvent);
} /* EventLoop */






DWord  PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  int error;

  if (cmd == sysAppLaunchCmdNormalLaunch)
  {
    FrmGotoForm(formID_bal);
    EventLoop();    // Event loop
    FrmCloseAllForms();
  }
  return 0;
} /* PilotMain */

