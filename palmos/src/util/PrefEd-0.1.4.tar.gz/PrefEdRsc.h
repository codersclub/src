//
// $Id: PrefEdRsc.h,v 1.9 2000/10/07 18:11:16 bodo Exp $
//
// Copyright (C) 1998 Bodo Bellut
//
// This program is free software; you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation; either version 2 of the License, or
// (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
//
//   Authors:  Bodo Bellut (bodo@bellut.net)

#define MainForm 1000
#define ViewForm 1001

#define MainMenu 1000
#define MainHelp 1000

#define liPrefs  1000

#define btView   2000
#define btDelete 2001
#define pbSaved  2002
#define pbUnsaved 2003
#define btUp     2004
#define btDown   2005
#define btDone   2006
#define btHelp   2007

#define laNumber 3000

#define alVerify 1000
#define alAbout  1001

#define mnAbout  1000
#define mnHelp   1001
#define mnExportL 1002
#define mnExportI 1003

