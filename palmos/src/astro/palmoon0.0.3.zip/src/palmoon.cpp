#include <PalmOS.h>
#include <StringMgr.h>
#include <FloatMgr.h>
#include <SysEvtMgr.h>
#include "MathLib.h"
#include "moontool.h"

#include "palmoon.resource.h"

#define CREATORID 'PMon'

const Char *g_sMon[12] = {"Jan","Feb","Mar","Apl","May","Jun",
                        "Jul","Aug","Sep","Oct","Nov","Dec"};

const Char *g_sTZ[22]={"HST","HAST","AKST","PST","MST",
                       "CST","EST","AST","NST","UTC",
                       "UCT","CUT","UT","GMT","WET",
                       "CET","MET","MEZ","EET","IST",
                       "JST","NZST"};
Int32 g_lTD[22]={0-36000L,0-36000L,0-32400L,0-28800L,0-25200L,
                       0-21600L,0-18000L,0-14400L,0-12600L,0L,
                       0L,0L,0L,0L,0L,
                       3600L,3600L,3600L,7200L,19800L,
                       32400L,43200L};


typedef struct{
  Int32 lTimeDifferenceSeconds;
  Char  sZoneName[5];
  Int16 FlagView;
} AppPrefType;

const Int16 fv_LOCALTIME = 0x0001;
const Int16 fv_MODIFIED  = 0x0002;
const Int16 fv_MJD       = 0x0004;
const Int16 fv_JDVIEW    = 0x0008;

static AppPrefType g;


Char *StrDToA(Char *s, FlpCompDouble d);
void *GetObjectPtr(Int16 objIndex);

void SetTZView(const Char *abbr, Int32 diff);

void PrintJulianDate(FlpCompDouble jd);
void PrintCurrentTime(DateTimeType dtt, Char *tz);
void PrintMoonPhase(FlpCompDouble cphase);
void PrintAgeOfMoon(FlpCompDouble aom);
void PrintLunation(Int32 lunation);
void PrintMisc(const double adPhasar[5], const double adPhasarGMT[5],
               FlpCompDouble jd, Int16 *nexteventindex);

static Err StartApplication(void);
static void StopApplication(void);
static Boolean AboutFormHandleEvent(EventPtr event);
static Boolean TimezoneFormHandleEvent(EventPtr event);
static Boolean formPalMoonIDHandleEvent(EventPtr event);
static Boolean ApplicationHandleEvent(EventPtr event);
static void EventLoop(void);
UInt32 PilotMain(UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags);



Char *StrDToA(Char *s, FlpCompDouble d)
{
  Int32 p, q;
  FlpCompDouble e;
  
  p = _d_dtoi(d.fd);
  e.d = ((d.d - p)* 1000000.0)+0.5;
  q = abs(_d_dtoi(e.fd));
  while(q>=1000000){q-=1000000;p++;}//workaround(v1.03)

  StrPrintF(s, "%ld.%06ld", p, q); /* max 10+1+6 characters and NULL */

  return s;
}



void *GetObjectPtr(Int16 objIndex)
{
  FormPtr form;
  form = FrmGetActiveForm();
  return FrmGetObjectPtr(form, FrmGetObjectIndex(form, objIndex));
}



void SetTZView(const Char *abbr, Int32 diff)
{
  FieldPtr fieldptr;

  fieldptr = (FieldPtr)GetObjectPtr(fieldZoneNameID);
  FldDelete(fieldptr, 0, 4);
  FldInsert(fieldptr, abbr, StrLen(abbr));
  FldDrawField(fieldptr);

  Char tmp[32];	/* max 1+10 chrs + null*/
  StrPrintF(tmp, "%s%ld", (diff>0)?"+":"-", abs(diff));
  fieldptr = (FieldPtr)GetObjectPtr(fieldTimeDifferenceID);
  FldDelete(fieldptr, 0, 6);
  FldInsert(fieldptr, tmp, StrLen(tmp));
  FldDrawField(fieldptr);
}



static Err StartApplication(void)
{
  Err error;
  error = SysLibFind(MathLibName, &MathLibRef);
  if(error){  // Just an example; handle it gracefully
    error = SysLibLoad(LibType, MathLibCreator, &MathLibRef);
  }
  ErrFatalDisplayIf(error, "Can't find MathLib");
  error = MathLibOpen(MathLibRef, MathLibVersion);
  ErrFatalDisplayIf(error, "Can't open MathLib"); 

  UInt16 prefSize=sizeof(g);
  Int16 prefExist = PrefGetAppPreferences(CREATORID, 0, &g, &prefSize, false);
  if(prefExist == noPreferenceFound){
    StrNCopy(g.sZoneName, "JST", sizeof(g.sZoneName));
    g.lTimeDifferenceSeconds=32400;
    g.FlagView=fv_LOCALTIME;
  }

  FrmGotoForm(formPalMoonID);

  return 0;
}



static void StopApplication(void)
{
  FrmCloseAllForms();

  PrefSetAppPreferences(CREATORID, 0, 1, &g, sizeof(g), false);

  UInt16 usecount;
  Err error;
  error = MathLibClose(MathLibRef, &usecount);
  ErrFatalDisplayIf(error, "Can't close MathLib");
  if(usecount == 0){
    SysLibRemove(MathLibRef); 
  }
}



static Boolean AboutFormHandleEvent(EventPtr event)
{
  Boolean handled = false;

  switch(event->eType){
    case frmOpenEvent:
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;

    case ctlSelectEvent:
      switch(event->data.ctlSelect.controlID){
        case buttonAboutOKID:
          FrmReturnToForm(formPalMoonID);
          handled = true;
          break;

        default:
          break;
      }
      break;

    default:
      break;
  }
  return handled;
}


static Boolean TimezoneFormHandleEvent(EventPtr event)
{
  Boolean handled = false;

  switch(event->eType){
    case frmOpenEvent:
      FrmDrawForm(FrmGetActiveForm());
      SetTZView(g.sZoneName, g.lTimeDifferenceSeconds);
      handled = true;
      break;

    case popSelectEvent:
      switch(event->data.popSelect.listID){
        case listZoneNamePresetID:
          SetTZView(g_sTZ[event->data.popSelect.selection],
                    g_lTD[event->data.popSelect.selection]);
          handled = false;
          break;

        default:
          break;
      }
      break;

    case ctlSelectEvent:
      switch(event->data.ctlSelect.controlID){
        case buttonTimeZoneCancelID:
          FrmReturnToForm(formPalMoonID);
          handled = true;
          break;

        case buttonTimeZoneOKID:
          FieldPtr fieldptr;
          fieldptr = (FieldPtr)GetObjectPtr(fieldTimeDifferenceID);
          g.lTimeDifferenceSeconds = StrAToI(FldGetTextPtr(fieldptr));
          fieldptr = (FieldPtr)GetObjectPtr(fieldZoneNameID);
          StrNCopy(g.sZoneName, FldGetTextPtr(fieldptr), sizeof(g.sZoneName));
          g.FlagView |= fv_MODIFIED;
          FrmReturnToForm(formPalMoonID);
          handled = true;
          break;

        default:
          break;
      }
      break;

    default:
      break;
  }
  return handled;
}














void PrintJulianDate(FlpCompDouble jd){
  static Char buf[32];
  FieldPtr fieldptr;

  if(g.FlagView&fv_MJD){
    jd.d-=2400000.5; /* See, http://tycho.usno.navy.mil/mjd.html */
    StrDToA(buf, jd); /* max 10+1+10 characters and NULL */
    StrCat(buf, " MJD");
  }else{
    StrDToA(buf, jd); /* max 10+1+10 characters and NULL */
    StrCat(buf, " JD");
  }
  fieldptr = (FieldPtr)GetObjectPtr(fieldJulianDateID);
  FldSetTextPtr(fieldptr, buf);
  FldDrawField(fieldptr);
}

void PrintCurrentTime(DateTimeType dtt, Char *tz){
  static Char buf[32];//at least 24+1
  FieldPtr fieldptr;

  StrPrintF(buf, "%02d:%02d:%02d %02d %s %04d %s",
            dtt.hour,dtt.minute,dtt.second,
            dtt.day,g_sMon[dtt.month-1],dtt.year,tz);
  fieldptr = (FieldPtr)GetObjectPtr(fieldCurrentTimeID);
  FldSetTextPtr(fieldptr, buf);
  FldDrawField(fieldptr);
}

void PrintMoonPhase(FlpCompDouble cphase){
  static Char buf[32];
  FieldPtr fieldptr;

  cphase.d *= 100.0;
  StrDToA(buf, cphase); /* max 10+1+10 characters and NULL */
  StrCat(buf, " %");
  fieldptr = (FieldPtr)GetObjectPtr(fieldMoonPhaseID);
  FldSetTextPtr(fieldptr, buf);
  FldDrawField(fieldptr);
}

void PrintAgeOfMoon(FlpCompDouble aom){
  static Char buf[32];
  FieldPtr fieldptr;
  FlpCompDouble fcdTemp;

  Int32 aom_d = _d_dtoi(aom.fd);
  fcdTemp.d = 24.0 * (aom.d - floor(aom.d));
  Int32 aom_h = _d_dtoi(fcdTemp.fd);
  fcdTemp.d = fmod(1440.0 * (aom.d - floor(aom.d)), 60.0);
  Int32 aom_m = _d_dtoi(fcdTemp.fd);
  fcdTemp.d = fmod(60.0 * 1440.0 * (aom.d - floor(aom.d)), 60.0);
  Int32 aom_s = _d_dtoi(fcdTemp.fd);

  StrPrintF(buf, "%ldday%s %02ld:%02ld:%02ld",
            aom_d, (aom_d==1) ? "" : "s", aom_h, aom_m, aom_s);
  fieldptr = (FieldPtr)GetObjectPtr(fieldAgeOfMoonID);
  FldSetTextPtr(fieldptr, buf);
  FldDrawField(fieldptr);
}

void PrintLunation(Int32 lunation){
  FieldPtr fieldptr;
  static Char buf1[32], buf2[32];

  /* Lunation 1st */
  StrPrintF(buf1, "%ld", lunation);
  fieldptr = (FieldPtr)GetObjectPtr(fieldLunation1ID);
  FldSetTextPtr(fieldptr, buf1);
  FldDrawField(fieldptr);

  /* Lunaion 2nd */
  StrPrintF(buf2, "%ld", lunation+1);
  fieldptr = (FieldPtr)GetObjectPtr(fieldLunation2ID);
  FldSetTextPtr(fieldptr, buf2);
  FldDrawField(fieldptr);
}

void PrintMisc(const double adPhasar[5], const double adPhasarGMT[5],
               FlpCompDouble jd, Int16 *nexteventindex){
  Int32 yy;
  Int16 mm, dd, hh, mmm, ss;
  FieldPtr fieldptr;
  static Char buf[5][32];
  Boolean flagUL=false;

  for(Int16 n=0;n<5;n++){
    if(g.FlagView&fv_JDVIEW){
      FlpCompDouble fcdTemp;
      if(g.FlagView&fv_MJD){
        fcdTemp.d = adPhasarGMT[n]-2400000.5;
        /* See, http://tycho.usno.navy.mil/mjd.html */
        StrDToA(buf[n], fcdTemp); /* max 10+1+10 characters and NULL */
        StrCat(buf[n], " MJD");
      }else{
        fcdTemp.d = adPhasarGMT[n];
        StrDToA(buf[n], fcdTemp); /* max 10+1+10 characters and NULL */
        StrCat(buf[n], " JD");
      }
    }else{
      jyear(adPhasar[n], &yy, &mm, &dd);
      jhms(adPhasar[n], &hh, &mmm, &ss);
      StrPrintF(buf[n], "%02d:%02d:%02d %02d %s %04ld %s",
                hh,mmm,ss, dd, g_sMon[mm-1], yy,
                (g.FlagView&fv_LOCALTIME) ? g.sZoneName:"GMT");
    }
    fieldptr = (FieldPtr)GetObjectPtr(fieldLastNewID+n);

    FieldAttrType attr;
    FldGetAttributes(fieldptr, &attr);
    if((!flagUL) && (adPhasarGMT[n]>jd.d)){
      attr.underlined = solidUnderline;
      *nexteventindex=n;
      flagUL=true;
    }else{
      attr.underlined = noUnderline;
    }
    FldSetAttributes(fieldptr, &attr);

    FldSetTextPtr(fieldptr, buf[n]);
    FldDrawField(fieldptr);
  }
}



static Boolean formPalMoonIDHandleEvent(EventPtr event)
{
  Boolean handled = false;

  switch(event->eType){
    case frmOpenEvent:
      FrmDrawForm(FrmGetActiveForm());
      handled = true;
      break;

    case menuEvent:
      switch(event->data.menu.itemID) {
        case menuPalMoonTZID:
          g.FlagView^=fv_LOCALTIME;
          g.FlagView|=fv_MODIFIED;
          handled = true;
          break;

        case menuPalMoonJDViewID:
          g.FlagView^=fv_JDVIEW;
          g.FlagView|=fv_MODIFIED;
          handled = true;
          break;

        case menuPalMoonMJDID:
          g.FlagView^=fv_MJD;
          g.FlagView|=fv_MODIFIED;
          handled = true;
          break;

        case menuPalMoonTimeZoneID:
          FrmPopupForm(formTimeZoneID);
          handled = true;
          break;

        case menuPalMoonAboutID:
          FrmPopupForm(formAboutID);
          handled = true;
          break;

        default:
          break;
      }
      break;

    case nilEvent:
      /* CHECKER */
      MenuBarType *b;
      b = MenuGetActiveMenu();
      if(b->attr.visible){
        handled = true;
        break;
      }

      UInt32 lLOCALSeconds, lGMTSeconds;
      DateTimeType dttLOCAL, dttGMT;
      FlpCompDouble jd;
      FlpCompDouble p,cphase,aom,cdist,cangdia,csund,csuang;
      static UInt32 lPrevSec;

      lLOCALSeconds = TimGetSeconds();

      if((g.FlagView&fv_MODIFIED) || (lLOCALSeconds != lPrevSec)){
        lPrevSec = lLOCALSeconds;

        TimSecondsToDateTime(lLOCALSeconds, &dttLOCAL);
        lGMTSeconds = lLOCALSeconds - g.lTimeDifferenceSeconds;
        TimSecondsToDateTime(lGMTSeconds, &dttGMT);
        jtime(&dttGMT, &jd);

        p.d = phase(jd.d, &(cphase.d), &(aom.d), &(cdist.d),
                    &(cangdia.d), &(csund.d), &(csuang.d));

        /*****************
          JulianDate View
         *****************/
        PrintJulianDate(jd);

        /******************
          CurrentTime View
         ******************/
        if(g.FlagView&fv_LOCALTIME){
          PrintCurrentTime(dttLOCAL, g.sZoneName);
        }else{
          PrintCurrentTime(dttGMT, "GMT");
        }

        /****************
          MoonPhase View
         ****************/
        PrintMoonPhase(cphase);

        /*************
          Age of Moon
         *************/
        PrintAgeOfMoon(aom);

        double adPhasar[5];
        static double adPhasarGMT[5];
        static Int16 nexteventindex;

        if((g.FlagView&fv_MODIFIED) || (jd.d > adPhasarGMT[nexteventindex])){
          nexteventindex=0;
          double diff=0.5;
          while(1){//workaround(v1.03)
            phasehunt(jd.d + diff, adPhasarGMT);
            if(jd.d < adPhasarGMT[0]){diff-=1.0;}
            else if(adPhasarGMT[4] < jd.d){diff+=1.0;}
            else{break;}
          }
          //adPhasar[] is the modified value.
          for(Int16 n=0;n<5;n++){
            if(g.FlagView&fv_LOCALTIME){
              adPhasar[n]=adPhasarGMT[n]+(g.lTimeDifferenceSeconds/86400.0);
            }else{
              adPhasar[n]=adPhasarGMT[n];
            }
          }

          FlpCompDouble fcdTemp;
          Int32 lunation;

          fcdTemp.d = floor(((adPhasarGMT[0]+7.0)-lunatbase)/synmonth)+1;
          lunation = _d_dtoi(fcdTemp.fd);

          /*************************
            Lunation and Misc. View
           *************************/
          PrintLunation(lunation);
          PrintMisc(adPhasar, adPhasarGMT, jd, &nexteventindex);

          g.FlagView^=fv_MODIFIED;
        }
      }
      handled = true;
      break;

    default:
      break;
  }
  return handled;
}


static Boolean ApplicationHandleEvent(EventPtr event)
{
  FormPtr frm;
  UInt16 formId;
  Boolean handled = false;

  if(event->eType == frmLoadEvent){
    formId = event->data.frmLoad.formID;
    frm = FrmInitForm(formId);
    FrmSetActiveForm(frm);

    switch(formId){
      case formPalMoonID:
        FrmSetEventHandler(frm, formPalMoonIDHandleEvent);
        handled = true;
        break;
      case formTimeZoneID:
        FrmSetEventHandler(frm, TimezoneFormHandleEvent);
        handled = true;
        break;
      case formAboutID:
        FrmSetEventHandler(frm, AboutFormHandleEvent);
        handled = true;
        break;
    }
  }
  return handled;
}


static void EventLoop(void)
{
  EventType event;
  UInt16 error;

  do{
    EvtGetEvent(&event, 10);
    if(!SysHandleEvent(&event)){
      if(!MenuHandleEvent(0, &event, &error)){
        if(!ApplicationHandleEvent(&event)){
          FrmDispatchEvent(&event);
        }
      }
    }
  }while(event.eType != appStopEvent);

}


UInt32 PilotMain(UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags)
{
  Err err = 0;

  if(launchCode == sysAppLaunchCmdNormalLaunch){
    if((err = StartApplication()) == 0){
      EventLoop();
      StopApplication();
    }
  }

  return err;
}

