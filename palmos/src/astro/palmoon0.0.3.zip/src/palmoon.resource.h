/********************
  "Timezone Setting"
 ********************/
#define formTimeZoneID				2000
#define fieldZoneNameID				2001
#define fieldTimeDifferenceID		2002
#define popuptrigZoneNamePresetID	2003
#define listZoneNamePresetID		2004
#define buttonTimeZoneOKID			2005
#define buttonTimeZoneCancelID		2006

/*****************
  "About PalMoon"
 *****************/
#define formAboutID					3000
#define buttonAboutOKID				3001

/***********
  "PalMoon"
 ***********/
#define formPalMoonID				1000
#define fieldJulianDateID			1001
#define fieldCurrentTimeID			1002

#define fieldMoonPhaseID			1003
#define fieldAgeOfMoonID			1004

#define fieldLunation1ID			1005
#define fieldLunation2ID			1006

#define menuPalMoonMJDID			1007
#define menuPalMoonTZID				1008
#define menuPalMoonJDViewID			1009
#define menuPalMoonMainID			1010
#define menuPalMoonTimeZoneID		1011
#define menuPalMoonAboutID			1012

//must be sequential
#define fieldLastNewID				1100
#define fieldWaxingHalfID			1101
#define fieldFullMoonID				1102
#define fieldWaningHalfID			1103
#define fieldNextNewID				1104



