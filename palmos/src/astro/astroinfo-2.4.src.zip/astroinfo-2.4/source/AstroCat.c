/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: AstroCat.c,v 1.43 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2000, Michael Heinz
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#include <PalmOS.h>
#include "PalmUtil.h"
#include "resource.h"
#include "Astro.h"
#include "AstroLib.h"
#include "AstroCat.h"
#include "AstroSky.h"
#include "FixedPoint.h"

extern void * memcpy(void *dst,const void *src,unsigned long l);

/*
 * Information about currently selected catalog
 */
static DmOpenRef       catDB = NULL;
static LocalID         catDbID = NULL;
static UInt16          catNumRecords = 0;
static UInt16          catCurrRecord = 0;


DmOpenRef GetCatalogRef() { return catDB; }
LocalID GetCatalogID() { return catDbID; }
UInt16 GetCurrentRecord() { return catCurrRecord; }
UInt16 SetCurrentRecord(UInt16 num) {  catCurrRecord = num; return num; }
UInt16 GetTotalRecords() { return catNumRecords; }
UInt16 SetTotalRecords(UInt16 num) {  catNumRecords = num; return num; }

/*
 * List of installed catalogs
 */
static DBRecord**      recordList = NULL;
static int             recordCount = 0;

/*
 * Pointers to catalog objects
 */
static ListPtr         catNamePtr;
static ListPtr         catalogPtr;


// Global used to hold last find text.
static char findString[FIELDLENGTH] = { "\0" };

void GetCurrentStar(AstroRecordType *art) {
    MemHandle handle;

    ErrFatalDisplayIf(catDB == NULL, "Database isn't open!");

    handle = DmQueryRecord(catDB, catCurrRecord);
    ErrFatalDisplayIf(handle == NULL,"Could not retrieve record!");

    MemMove(art, (AstroRecordType*) MemHandleLock(handle), 
            sizeof(AstroRecordType));
    MemHandleUnlock(handle);
}

/*
 * Events for the FindObject form
 */
Boolean
FindObjectFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    
    switch (event->eType) {
        case ctlSelectEvent:
            if (event->data.ctlSelect.controlID == b_OK) {
                char *newString = FldGetTextPtr
                    ((FieldPtr) FrmGetObjectPtrByID(formPtr,f_Find));
                if (newString != NULL) 
                {
                    StrToLower(findString,newString);
                    if (catDB != NULL)
                        FindObject(0);
                }                
                else 
                {
                    findString[0]='\0';
                }
                
                FrmReturnToForm(0);
                handled = true;
            }
            else if (event->data.ctlSelect.controlID == b_Cancel)
            {
                FrmReturnToForm(0);
                handled = true;
            }

            break;

        case frmOpenEvent:
            {
                UInt16 findIdx = FrmGetObjectIndex(formPtr,f_Find);
                FieldPtr findPtr = (FieldPtr) 
                    FrmGetObjectPtr(formPtr, findIdx);
                MemHandle handle = MemHandleNew(FIELDLENGTH);
                MemPtr ptr = MemHandleLock(handle);
                StrCopy(ptr, findString);
                MemHandleUnlock(handle);
                FldSetText(findPtr, handle, 0, FIELDLENGTH);
                FrmDrawForm(formPtr);
                FrmSetFocus(formPtr, findIdx);
                handled = true;
            }
            break;

        default:
            handled = false;
    }

    return handled;
}


/*
 * Display the current catalog of objects.
 */
static void
CatalogListDrawData(Int16 itemNum, RectangleType *bounds, Char **itemsText)
{
    MemHandle handle;
    AstroRecordType* art;
    FontID oldfont;

    /*
     * Get the cat string
     */
    if (catDB != NULL) {
        handle = DmQueryRecord(catDB, itemNum);
        art = (AstroRecordType*)MemHandleLock(handle);

        // Set to normal font by default
        oldfont = FntSetFont(stdFont);

        // Optionally show whether object is currently above horizon
        if (userPrefs.optFlags.moreAccurate) {
            Int32  sinlat, coslat;
            Int32  UTr, UTs;
            int    flags;
            int    upnow = 0;
            fpsincos(userPrefs.lat, &sinlat, &coslat);

            flags = StarRiseSet(currentJDay, currentJTime, 
                                art->ra, art->dec,
                                sinlat, coslat, userPrefs.lng,
                                &UTr, &UTs);
            
            // If it's up then draw it bold
            upnow = UpNow(flags, UTr, UTs, currentJTime);
          
            FntSetFont(boldFont);

            if (upnow) {
                WinDrawChars("^", 1,
                             bounds->topLeft.x, bounds->topLeft.y);
            } else if (flags & (ASTROLIB_DONTRISESET)) {
                WinDrawChars("x", 1,
                             bounds->topLeft.x, bounds->topLeft.y);
            }
            FntSetFont(stdFont);
        }

        // Show object name
        WinDrawChars(art->description, StrLen(art->description),
                bounds->topLeft.x + (userPrefs.optFlags.moreAccurate ? 11 : 0), bounds->topLeft.y);

        // Restore entry font
        FntSetFont(oldfont);

        MemHandleUnlock(handle);
    }
}

void
OpenCatalog() 
{
    LocalID local;
    Err err;
    AstroAppInfoType* aaInfo;

    FreeCatalog();

    /* See if we can find the last used catalog. */
    catDbID = DmFindDatabase(userPrefs.catCardNo,
                             userPrefs.catDbName);
    
    if (catDbID != 0)
    {
        catDB = DmOpenDatabase(userPrefs.catCardNo,
                               catDbID, dmModeReadOnly);
        ErrFatalDisplayIf(catDB==0,
                          "Could not open the database!");
        /*
         * Get the application info.
         */
        err = DmDatabaseInfo(userPrefs.catCardNo,
                             catDbID,
                             NULL, NULL, NULL, NULL,
                             NULL, NULL, NULL,
                             &local,
                             NULL, NULL, NULL);
        ErrFatalDisplayIf(err!=errNone,
                          "Could not retrieve catalog info.");
        
        aaInfo = MemLocalIDToLockedPtr(local, userPrefs.catCardNo);
        
        // Restore previous position
        SetTotalRecords(aaInfo->numRecords);
        SetCurrentRecord(aaInfo->currRecord);
        
        MemPtrUnlock(aaInfo);
    }

    /* Call this even if catalog could not be loaded */
    SkyMapLoadCatalog();
}

/*
 * Events for the SelectCatalog form
 */
Boolean
SelectCatalogFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    int i;
    Err err;
    
    switch (event->eType) {
    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case b_OK:
            i = LstGetSelection(catNamePtr);
            
            if (recordList != NULL && i != noListSelection) {
                userPrefs.catCardNo = recordList[i]->cardNo;
                catDbID = recordList[i]->dbID;
                StrCopy(userPrefs.catDbName,recordList[i]->name);
                
                OpenCatalog();
                SetCurrentRecord(0);
                
                FrmUpdateForm(f_Catalog, updateObjectListChanged);
                
                if (recordList != NULL)
                    FreeDBList(recordList,recordCount);
                
                FrmReturnToForm(0);
            }
            handled = true;
            break;
            
        case b_Delete:
            // Get the database that was selected for deletion.
            i = LstGetSelection(catNamePtr);
            
            // Confirm that the user really wants to delete a db.
            if (recordList != NULL && i != noListSelection
                && FrmAlert(a_AreYouSure) == 0) 
            {
                /*
                 * Are we deleting the currently open database?
                 */
                if ((userPrefs.catCardNo == recordList[i]->cardNo)
                    && (catDbID == recordList[i]->dbID))
                    FreeCatalog();
                
                err = DmDeleteDatabase(recordList[i]->cardNo,
                                       recordList[i]->dbID);
                ErrFatalDisplayIf(err!=errNone,
                                  "Failed to delete database!");

                FreeDBList(recordList,recordCount);
                recordList = GetDBList(ASTRODBTYPE,
                                       APPID,
                                       &recordCount);
                if (recordList != NULL) {
                    LstSetSelection(catNamePtr,-1);
                    LstSetListChoices(catNamePtr,
                                      (char**)recordList,
                                      recordCount);
                    LstSetTopItem(catNamePtr,0);
                    LstDrawList(catNamePtr);
                }
            }
            handled = true;
            break;
            
        case b_Cancel:
            if (recordList != NULL)
                FreeDBList(recordList,recordCount);
            FrmReturnToForm(0);
            handled = true;
            break;
            
        default:
        }
        break;
        
    case frmOpenEvent:
        catNamePtr = (ListPtr)FrmGetObjectPtrByID(formPtr, ls_CatName);
                                                                
        recordList = GetDBList(ASTRODBTYPE,
                               APPID,
                               &recordCount);
        if (recordList != NULL) 
        {
            LstSetSelection(catNamePtr,-1);
            LstSetListChoices(catNamePtr,
                              (char**)recordList,
                              recordCount);
            LstSetTopItem(catNamePtr,0);
        }
        FrmDrawForm(formPtr);
        
        handled = true;
        break;
        
    case frmCloseEvent:
        if (recordList != NULL)
            FreeDBList(recordList,recordCount);
        handled = false;
        break;
        
    default:
        handled = false;
    }
    
    return handled;
}

/*
 * Events for the main catalog form showing list of catalogue objects
 */
Boolean
CatalogFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr formPtr = FrmGetActiveForm();

    if (DateChangeHandleEvent(event)
        || FormChangeHandleEvent(event))
        return true;
    
    switch (event->eType) {
        case keyDownEvent:
            
            // Use Page Up/Down buttons to scroll object list.
                
            if (event->data.keyDown.chr == pageUpChr) 
            {
                LstScrollList(catalogPtr, winUp, 8);
                handled = true;
            }
            else if (event->data.keyDown.chr == pageDownChr) 
            {
                LstScrollList(catalogPtr, winDown, 8);
                handled = true;
            }
            break;

        case ctlSelectEvent:
            // Process various button clicks.

            switch (event->data.ctlSelect.controlID) {
                case b_CatalogSelect:
                    FrmPopupForm(f_SelectCatalog);
                    break;

                case b_CatalogFind:
                    FrmPopupForm(f_FindObject);
                    break;

                case b_CatalogAgain:
                    if (catDB != NULL)
                        FindObject(catCurrRecord + 1);
                    break;
            }
            handled = true;
            break;

        case lstSelectEvent:
            if (catDB != NULL) 
            {
                SetCurrentRecord(LstGetSelection(catalogPtr));
                SetDetailObjectType(CATOBJ);
                FrmGotoForm(f_ObjectDetail);
            }
            break;

        case frmOpenEvent:
            FrmSetMenu(formPtr, mainMenu);            

            catalogPtr = (ListPtr)FrmGetObjectPtrByID(formPtr, ls_Catalog);

            LstSetDrawFunction(catalogPtr, CatalogListDrawData);
            
            FrmDrawForm(formPtr);

            DrawDatePicker();
            DrawTimePicker();

            FrmUpdateForm(f_Catalog, updateObjectListChanged);

            handled = true;
            break;
            
        case frmUpdateEvent:
            if (event->data.frmUpdate.updateCode == updateObjectListChanged) {
                // Fill the list with objects.
                LstSetListChoices(catalogPtr, NULL, catNumRecords);
                
                if (catNumRecords) 
                {
                    /* Try to position selected object in the middle
                     * of display area.
                     */
                    LstSetTopItem(catalogPtr, GetCurrentRecord() > 4 ?
                                  GetCurrentRecord() - 4 : 0);
                    /* Select the active object */
                    LstSetSelection(catalogPtr, GetCurrentRecord());
                }
            }
            FrmDrawForm(formPtr);
            handled = true;
            break;
            
        case frmCloseEvent:
            handled = false;
            break;

        default:
            handled = false;
    }

    return handled;
}

static void
SaveCurrEntry()
{
  Err err;
  LocalID local;
  AstroAppInfoType* aaInfo;

  catDB = DmOpenDatabase(userPrefs.catCardNo,
                         catDbID,
                         dmModeReadWrite);
  if (catDB == 0)
    return;
  
  /*
   * Get the application info.
   */
  err = DmDatabaseInfo(userPrefs.catCardNo,
                       catDbID,
                       NULL, NULL, NULL, NULL,
                       NULL, NULL, NULL,
                       &local,
                       NULL, NULL, NULL);
  ErrFatalDisplayIf(err!=errNone,
                    "Could not retrieve catalog info.");
  aaInfo = MemLocalIDToLockedPtr(local, 
                                 userPrefs.catCardNo);
  err=DmWrite(aaInfo,
              OffsetOf(AstroAppInfoType, currRecord),
              &catCurrRecord,
              sizeof(UInt16));
  MemPtrUnlock(aaInfo);
    
  ErrFatalDisplayIf(err,"DMWrite Failed!");
  err = DmCloseDatabase(catDB);
  ErrFatalDisplayIf(err!=errNone,
                    "Could not close catalog!");
  catDB = NULL;
}

/*
 * Release the open catalog
 */
void
FreeCatalog()
{
    Err err;
    
    if (catDB != NULL) {
        /*
         * Close previous catalog
         */
        err = DmCloseDatabase(catDB);
        ErrFatalDisplayIf(err!=errNone,
                          "Could not close catalog!");
        catDB = NULL;
        SaveCurrEntry();
    }
    SetTotalRecords(0);
    SkyMapFreeCatalog();
}

/*
 * Display the current catalog of objects.
 */
void
FindObject(UInt16 start) 
{
    MemHandle handle;
    UInt16 i;
    AstroRecordType* art;
    char description[sizeof(art->description)];
    
    i = start;
    while (i < catNumRecords)
    {
        handle = DmQueryRecord(catDB,i);
        ErrFatalDisplayIf(handle==NULL,"DmQueryRecord failed!");
        art = (AstroRecordType*)MemHandleLock(handle);
        StrToLower(description,art->description);
        if (StrStr(description,findString) != NULL)
        {
            MemHandleUnlock(handle);
            LstSetTopItem(catalogPtr,i);
            LstSetSelection(catalogPtr,i);
            SetCurrentRecord(i);
            break;
        }
        MemHandleUnlock(handle);
        i++;
    } 
    FrmUpdateForm(f_Catalog,frmRedrawUpdateCode);
}

