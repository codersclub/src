/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: Astro.c,v 1.118 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "PalmUtil.h"
#include "resource.h"
#include "Astro.h"
#include "AstroLib.h"
#include "AstroCat.h"
#include "AstroSky.h"
#include "FixedPoint.h"
#include "Grayscale.h"
#include "AstroDST.h"


SystemPreferencesType   sysPrefs;
UserPrefsType           userPrefs;

/* Allow elegant remote access to current object */
int GetCurrentObject() { return userPrefs.currentObj; }
void SetDetailObjectType(int num) { userPrefs.currentObj = num; }

UInt16 mainMenu = m_Normal;

UInt32 currentJDay;
UInt32 currentJTime;

static RockerType currentRocker;
static Int32 currentTzDST;
static Int32 currentGSTOffset;

static Boolean  hasRom31, hasRom35;

// Our normal image area
static RectangleType widebox = {{ 0, 15}, {160, 54}};

static const UserPrefsType defaultPrefs = {
    ASTROVERSION,             /* version */
    0,                        /* dstRuleNr */
    -4 * 3600000L,            /* tz */
    FP( 41.25 / 90),          /* lat */
    FP(-75.50 / 90),          /* lng */
    FP_ONE, 0,                /* alt/az */
    { 0, },                   /* dstRule */
    1, 0,                     /* isNow, pad0 */
    { 0, 0, 0, 1, 1, 2000 },  /* currentDT */
    { 0, 0, 1, 0, 1, 2 },     /* skyFlags */
    { 1,1,1,1,15,0,0 },       /* optFlags */
    PAGEBTNROCKER, 0,         /* pageBtnFunction, pad1 */
    0L,                       /* currentObj */

    f_Options,                /* active FormId */
    0, "\0",                  /* catCardNo, catDbName */
    0,0,0,0                   /* rocker values */
};

#define MOONDETAILPAGES 1
#define SOLARDETAILPAGES 1
#define PLANETDETAILPAGES 2
#define CATOBJDETAILPAGES 1

#define IMAGEBMPCENTERX 80
#define IMAGEBMPCENTERY 42

/* Prototypes we don't want to advertise outside of this file */

static Boolean SetDate(void);
static Boolean SetTime(void);
static Boolean SetNow(void);

/*
 * Update a label.
 */
static void
UpdateTextLabel(UInt16 objid, Char *t)
{
    FormPtr formPtr = FrmGetActiveForm();
    FrmCopyLabel(formPtr, objid, t);
}

static void *
AstroTblGetItemPtr(TableType *tableP, int row, int column)
{
    return tableP->items[row * tableP->numColumns + column].ptr;
}

static void
AstroFreeTable(TableType *tableP)
{
    int i;
    int numItems = TblGetNumberOfRows(tableP) * tableP->numColumns;
    for (i = 0; i < numItems; i++) {
        if (tableP->items[i].ptr) {
            MemHandleFree((MemHandle) tableP->items[i].ptr);
            tableP->items[i].ptr = NULL;
        }
    }
}

static void 
AstroTableDrawItem(void *tblP, 
                   Int16 row, Int16 column, RectangleType *bounds) 
{
    FontID curFont;
    TablePtr tableP = (TablePtr) tblP;
    MemHandle handle = (MemHandle) AstroTblGetItemPtr(tableP, row, column);
    Char *text = NULL;
    int  opts, len;
    int  space;

    /* PalmOS 3.0 needs this */
    WinEraseRectangle(bounds, 0);

    if (handle == NULL)
        return;

    text = (Char*) MemHandleLock(handle);
    len = StrLen(text);
    opts = TblGetItemInt(tableP, row, column);
    curFont = FntSetFont(TblGetItemFont(tableP, row, column));

    if ((opts & 3) == leftAlign) {
        space = 0;
    } else {
        space = bounds->extent.x - FntCharsWidth(text, len);
        if ((opts & 3) == centerAlign)
            space /= 2;
    }
    WinSetUnderlineMode(noUnderline);
    WinDrawChars(text, len, bounds->topLeft.x + space, bounds->topLeft.y);
    FntSetFont(curFont);
    MemHandleUnlock(handle);
}

/*
 * Set the field text.  It allocates a copy on the heap, so you can give
 * a local variable as text.
 */
static void
UpdateTblItemText(TablePtr table, int row, int col, Char *text)
{
    MemHandle handle = (MemHandle) AstroTblGetItemPtr(table, row, col);
    int size = StrLen(text) + 1;
        
    if (handle != NULL) {
        if (MemHandleSize(handle) < size) {
            MemHandleFree(handle);
            handle = MemHandleNew(size);
        }
    } else
        handle = MemHandleNew(size);
            
    StrCopy (MemHandleLock(handle), text);
    MemHandleUnlock(handle);
    TblSetItemPtr(table, row, col, handle);
}

/*
 * Set the field text.  It allocates a copy on the heap, so you can give
 * a local variable as text.
 */
void
UpdateTextField(UInt16 objid, Char *text)
{
    FormPtr  formPtr = FrmGetActiveForm();
    FieldPtr fld = (FieldPtr) FrmGetObjectPtrByID(formPtr, objid);
    MemHandle handle;
        
    FldFreeMemory(fld); 
    handle = MemHandleNew(StrLen(text) + 1);
    StrCopy (MemHandleLock(handle), text);
    MemHandleUnlock(handle);
    FldSetTextHandle(fld, handle);
}

/*
 * Time is measured in seconds since midday. Positive forward, negative back.
 *
 */
static Char *
FormatTime(Int32 time, Char *s, UInt16 size, Char *flags, Boolean force24H)
{
    Int32       hr, min;
    int         day;

    time += HALFDAY;
    day = 0;
    while (time < 0) {
        time += DAY;
        day++;
    }
    while (time >= DAY) {
        time -= DAY;
        day--;
    }
        
    min = time / 60000;
    hr  = (min / 60) % 24; 
    min = min % 60;
    
    TimeToAscii(hr, min, 
                userPrefs.optFlags.time24Hour || force24H
                ? tfColon24h : sysPrefs.timeFormat, s);
    
    /* Indicate next, previous, current day. */
    if (flags) {
        if (userPrefs.tz != currentTzDST)
            *flags++ = 31;

        if (day < 0)
            *flags++ = 29;
        else if (day > 0)
            *flags++ = 30;
        
        *flags = 0;
    }

    return s;
}

/*
 * Update a button label.
 */
void
UpdateControlLabel(UInt16 objid, Char *t)
{
    FormPtr       formPtr = FrmGetActiveForm();
    UInt16        objIndex = FrmGetObjectIndex(formPtr, objid);
    ControlType * fld = (ControlType *)FrmGetObjectPtr(formPtr, objIndex);
    
    ErrFatalDisplayIf(objIndex == frmInvalidObjectId,
                      "Missing form element!");
    
    /* Hide to force redraw in case label text is smaller now. */
    FrmHideObject(formPtr, objIndex);
    
    CtlSetLabel(fld, t);
    
    FrmShowObject(formPtr, objIndex);
}

void SetControlValue(UInt16 objid, Int16 num)
{
    FormPtr     formPtr = FrmGetActiveForm();
    ControlPtr  fld = (ControlPtr)FrmGetObjectPtrByID(formPtr, objid);

    ErrFatalDisplayIf(fld == NULL, "Missing form element!");
    CtlSetValue(fld, num);
}

Int16 GetControlValue(UInt16 objid)
{
    FormPtr     formPtr = FrmGetActiveForm();
    ControlPtr  fld = (ControlPtr)FrmGetObjectPtrByID(formPtr, objid);

    ErrFatalDisplayIf(fld == NULL, "Missing form element!");

    return CtlGetValue(fld);
}

/*
 * Update an field with a text value.
 */
static void
SetFieldValue(UInt16 objid, Int16 num)
{
    Char text[FIELDLENGTH];
    StrIToA(text, num);
    
    UpdateTextField(objid, text);
}

Char * 
GetStringResource(UInt16 stringid, Char *buffer) {
    Char* text;
    MemHandle handle = DmGetResource('tSTR', stringid);
    
    if (handle) {
        text = MemHandleLock(handle);
        StrNCopy(buffer, text, FIELDLENGTH);
        MemHandleUnlock(handle);
        DmReleaseResource(handle);
    } else {
        *buffer = 0;
    }
    return buffer;
}


/*
 * Create a global pointer to the current rocker to use in ...DetailHandleEvents and set some defaults.
 */
static void
SetRocker(Int16 current, Int16 min, Int16 max)
{
    FormPtr  formPtr = FrmGetActiveForm();
    
    currentRocker.value = current < min ? min : current > max ? max : current;
    currentRocker.minValue = min;
    currentRocker.maxValue = max;

    // Hide rocker and get out if there is only one page.
    if (max == min) {
        FrmHideObject(formPtr, FrmGetObjectIndex(formPtr, r_DetDown));
        FrmHideObject(formPtr, FrmGetObjectIndex(formPtr, r_DetUp));
        
        return;
    }
    
    // Show disabled up arrow if already at top
    if (current == min)
        UpdateControlLabel(r_DetUp, "\003");
    else
        UpdateControlLabel(r_DetUp, "\001");
    
    if (current == max)
        UpdateControlLabel(r_DetDown, "\004");
    else
        UpdateControlLabel(r_DetDown, "\002");
}

static void
SetupObjectForm(FormPtr formPtr) {
    static Char formTitle[FIELDLENGTH];
 

    switch (GetCurrentObject()) {
    case MERCURY:
    case VENUS:
    case EARTH:
    case MARS:
    case JUPITER:
    case SATURN:
    case URANUS:
    case NEPTUNE:
    case PLUTO:
        // Setting the title shorter than the previous title leaves a display artifact.
        FrmSetTitle(formPtr,"");
        FrmSetTitle(formPtr, GetStringResource(s_PlanetDetail, formTitle));
        SetRocker(userPrefs.PlanetDetailRocker, 1, PLANETDETAILPAGES);
        break;
    case MOON:
        FrmSetTitle(formPtr,"");
        FrmSetTitle(formPtr,GetStringResource(s_MoonDetail, formTitle));
        // XXX: Enable phase button
        SetRocker(userPrefs.MoonDetailRocker, 1, MOONDETAILPAGES);
        break;
    case SUN:
        FrmSetTitle(formPtr,"");
        FrmSetTitle(formPtr, GetStringResource(s_SunDetail, formTitle));
        SetRocker(userPrefs.SolarDetailRocker, 1, SOLARDETAILPAGES);
        break;
    case CATOBJ:
        FrmSetTitle(formPtr,"");
        FrmSetTitle(formPtr, GetStringResource(s_CatObjDetail, formTitle));
        SetRocker(userPrefs.CatObjDetailRocker, 1, CATOBJDETAILPAGES);
        break;
    }
}

static void
CloseObjectForm() {
    switch (GetCurrentObject()) {
    case MERCURY:
    case VENUS:
    case EARTH:
    case MARS:
    case JUPITER:
    case SATURN:
    case URANUS:
    case NEPTUNE:
    case PLUTO:
        userPrefs.PlanetDetailRocker = currentRocker.value;
        break;
    case MOON:
        userPrefs.MoonDetailRocker = currentRocker.value;
        break;
    case SUN:
        userPrefs.SolarDetailRocker = currentRocker.value;
        break;
    case CATOBJ:
        userPrefs.CatObjDetailRocker = currentRocker.value;
        break;
    }
}


/*
 * Calculates the floating point lat/long from dms lat/long values
 */
static void
CalculateDate()
{
    Int32 jday, jtime, dstoffset;
    jday = JDay(userPrefs.currentDT.year,
                userPrefs.currentDT.month,
                userPrefs.currentDT.day);
    jtime = (userPrefs.currentDT.hour - 12) * 3600000
      + userPrefs.currentDT.minute * 60000 - userPrefs.tz;

    dstoffset = getDSTOffset(jday, jtime, 
                             userPrefs.tz, &userPrefs.dstRule);
    jtime -= dstoffset;

    currentJDay = jday;
    currentJTime = jtime;
    currentTzDST = userPrefs.tz + dstoffset;
    currentGSTOffset = getGSTOffset(jday);
}

static Char datestr[FIELDLENGTH];
static Char timestr[FIELDLENGTH];
static Char dstRuleName[FIELDLENGTH];

void
DrawDatePicker()
{
    FormPtr  formPtr = FrmGetActiveForm();
    ControlPtr datePtr = (ControlPtr)FrmGetObjectPtrByID(formPtr, s_Date);

    if (datePtr) {
        DateToAscii(userPrefs.currentDT.month,
                    userPrefs.currentDT.day,
                    userPrefs.currentDT.year,
                    sysPrefs.dateFormat,
                    datestr);
        CtlSetLabel(datePtr, datestr);
    }
}

void
DrawTimePicker()
{
    TimeToAscii(userPrefs.currentDT.hour,
                userPrefs.currentDT.minute,
                userPrefs.optFlags.time24Hour?tfColon24h:sysPrefs.timeFormat,
                timestr);
    UpdateControlLabel(s_Time, timestr);
}


/*
 * Change the base date (used for various calculations) by 'days'.
 */
static void
ChangeDate(long days)
{
    DateType    dt;

    dt.year = userPrefs.currentDT.year - 1904;
    dt.month = userPrefs.currentDT.month;
    dt.day = userPrefs.currentDT.day;
    
    DateAdjust(&dt, days);

    userPrefs.currentDT.year = dt.year + 1904;
    userPrefs.currentDT.month = dt.month;
    userPrefs.currentDT.day = dt.day;
    userPrefs.isNow = false;

    DrawDatePicker();
    CalculateDate();    
    FrmUpdateForm(FrmGetActiveFormID(), updateDateChanged);
}




/* Determines whether an object is above the horizon based on rise/set time. */

int UpNow(int flags, Int32 rise, Int32 set, Int32 now) {
    switch (flags & ASTROLIB_DONTRISESET) {
    case 0:
        return (rise <= now) && (now <= set);

    case ASTROLIB_DONTRISE:
        return now <= set;

    case ASTROLIB_DONTSET:
        return rise <= now;

    case ASTROLIB_DONTRISESET:
        return flags & ASTROLIB_CIRCUMPOLAR;
    }
    // Only get here if something is VERY wrong!
    abort();
}

static void
InitDetailTable()
{
    FormPtr  formPtr = FrmGetActiveForm();
    TablePtr tableDet = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_Details);
    TablePtr tableRTS = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_RTS);

    int row, col;
    
    for (row = 0; row < 4; row++) {
        TblSetRowUsable(tableDet, row, true);
        for (col = 0; col < 4; col++) {
            TblSetItemPtr(tableDet, row, col, NULL);
            TblSetItemStyle(tableDet, row, col, customTableItem);
            if ((col & 1) == 0) {
                TblSetItemInt(tableDet, row, col, rightAlign);
                TblSetItemFont(tableDet, row, col, 1);
            } else {
                TblSetItemInt(tableDet, row, col, leftAlign);
                TblSetItemFont(tableDet, row, col, 0);
            }
        }
    }
    for (row = 0; row < 2; row++) {
        TblSetRowUsable(tableRTS, row, true);
        for (col = 0; col < 6; col++) {
            TblSetItemPtr(tableRTS, row, col, NULL);
            TblSetItemStyle(tableRTS, row, col, customTableItem);
            if ((col & 1) == 0) {
                if ((row & 1) == 0) {
                    TblSetItemInt(tableRTS, row, col, rightAlign);
                    TblSetItemFont(tableRTS, row, col, 1);
                } else {
                    TblSetItemInt(tableRTS, row, col, rightAlign);
                    TblSetItemFont(tableRTS, row, col, 0);
                }
            } else {
                TblSetItemInt(tableRTS, row, col, leftAlign);
                TblSetItemFont(tableRTS, row, col, 130);
            }
        }
    }
    for (col = 0; col < 4; col++) {
        TblSetCustomDrawProcedure(tableDet, col, AstroTableDrawItem);
        TblSetColumnUsable(tableDet, col,true);
        TblSetColumnSpacing(tableDet, col, 0);
    }
    for (col = 0; col < 6; col++) {
        TblSetCustomDrawProcedure(tableRTS, col, AstroTableDrawItem);
        TblSetColumnUsable(tableRTS, col,true);
        TblSetColumnSpacing(tableRTS, col, 0);
    }
        
    /* XXX Bug in PilRC?? the usable flag isn't set automatically */
    FrmShowObject(formPtr, FrmGetObjectIndex(formPtr, tbl_Details));
    FrmShowObject(formPtr, FrmGetObjectIndex(formPtr, tbl_RTS));
}

static void
ClearDetailArea()
{
    FormPtr  formPtr = FrmGetActiveForm();
    TablePtr tableDet = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_Details);
    TablePtr tableRTS = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_RTS);

    int row, col;
    
    for (row = 0; row < 4; row++) {
        for (col = 0; col < 4; col++) {
            MemHandle handle = (MemHandle) AstroTblGetItemPtr(tableDet, row, col);
            if (handle)
                MemHandleFree(handle);
            TblSetItemPtr(tableDet, row, col, NULL);
        }
    }
    for (row = 0; row < 2; row++) {
        for (col = 0; col < 6; col++) {
            MemHandle handle = (MemHandle) AstroTblGetItemPtr(tableRTS, row, col);
            if (handle)
                MemHandleFree(handle);
            TblSetItemPtr(tableRTS, row, col, NULL);
        }
    }
}


#if 0
/*
 * Draw the phase of a moon or planet for the given age and full values
 * (x0,y0): Coordinate of top left corner.
 * handle : handle to bitmap of correct size, NULL for lineart.
 * full   : fullness in 0..1 as Fixed point.
 * waxing : true when waxing, false when waning. 
 * sa,ca  : sine and cosine of rotation angle (clockwise).
 */
static void
DrawPhase2(int x0, int y0, int radius, MemHandle handle,
           Int32 sa, Int32 ca, Int32 full, Boolean waxing)
{
    int x1, x2, y;
    Int32 ypixel, pixelsize;
    Int32 f, H, K, D;
    int h,c;

    void EraseHLine(int xs, int xe, int y) {
        if (xe > xs)
            WinEraseLine(x0+xs, y, x0-1+xe, y);
    }

    if (ca < 0) {
        waxing = !waxing;
    }

    f = full*2 - FP_ONE;
    H = fpsqrt(fpsq(ca) + fpsq(fpmul(f, sa)));
    h = GP_ROUND(fpmul(radius * GP_ONE, H));
    c = GP_ROUND(fpmul(radius * GP_ONE, ca));
    pixelsize = (FP_ONE / radius);

    if (h > 0) {
        K = fpmul(radius * GP_ONE, fpdiv(fpmul(fpmul(sa, ca), 
                                               FP_ONE - fpabs(f)), H));
        D = fpmul(radius * GP_ONE, fpdiv(f, H));
        ypixel = fpdiv(FP_ONE/radius, H);
    } else {
        ypixel = K = D = 0;
    }

    if (!userPrefs.optFlags.blackBackground) {
        RectangleType bounds = {{ x0 - 1, y0 - 1},
                                {2*radius+2, 2*radius+2}};
        WinFillRectangle(&bounds, radius+1);
    }

    for (y = 0; y < radius; y++) {
        Int32 fpx = fpsqrt(FP_ONE - fpsq(y * pixelsize + pixelsize/2));
        Int32 circx = GP_ROUND(fpmul(radius * GP_ONE, fpx));
        int y1 = y0 - 1 - y;
        int y2 = y0 + y;

        if (y >= h) {
            /* above/below shadow line */
            if ((waxing ^ (sa < 0)))
                EraseHLine(-circx, +circx, y2);
            else
                EraseHLine(-circx, +circx, y1);
        } else {
            Int32 fpy, diff, cent;
                  
            fpy = y * ypixel + ypixel/2;                 
            diff = fpmul(D, fpsqrt(FP_ONE - fpsq(fpy)));
            cent = fpmul(K, fpy);
            x1 = GP_ROUND(cent - diff);
            x2 = GP_ROUND(cent + diff);

            if (y < c) {
                /* one shadow line */
                if (waxing) {
                    EraseHLine( x1, circx, y1);
                    EraseHLine(-x2, circx, y2);
                } else {
                    EraseHLine(-circx,  x2, y1);
                    EraseHLine(-circx, -x1, y2);
                }
            } else {
                /* two or zero shadow lines */
                if ((waxing ^ (sa < 0))) {
                    if (x1 > x2) {
                        EraseHLine(-circx, -x1, y2);
                        EraseHLine(-x2, circx, y2);
                    } else {
                        EraseHLine(x1, x2, y1);
                        EraseHLine(-circx, circx, y2);
                    }
                } else {
                    if (x1 > x2) {
                        EraseHLine(-circx, x2, y1);
                        EraseHLine(x1, circx, y1);
                    } else {
                        EraseHLine(-circx, circx, y1);
                        EraseHLine(-x2, -x1, y2);
                    }
                }
            }
        }
    }
}
#endif

/*
 * Draw the phase of a moon or planet for the given age and full values
 * (x0,y0):  Coordinate of center.
 * handle:   handle to bitmap of correct size, NULL for lineart.
 * full  :   fullness in 0..1 as Fixed point.
 * waxing:   true when waxing, false when waning. 
 * Black
 */
static void
DrawPhase(Int32 x0, Int32 y0, int radius, MemHandle handle,
          Int32 full, Boolean waxing, Boolean bkgBlack)
{
    Int32 horiz1, horiz2;
    int x1, x2, y;
    Int32 gpradius  = radius * GP_ONE;
    Int32 pixelsize = (FP_ONE / radius);

    // This has to be big enough to hold the image plus an optional border
    RectangleType bounds = {{ x0 - radius - 1, y0 - radius - 1},
                                {2*radius + 2, 2*radius + 2}};

    if (handle) {
        BitmapPtr     bmp;
#if DARKEN_BITMAP
        Char *bits, *line1, *line2;
        UInt32 size;
        MemHandle copy;
#endif            

        if (waxing) {
            horiz1 = -gpradius;
            horiz2 = fpmul(gpradius, FP_ONE - full*2);
        } else {
            horiz1 = fpmul(gpradius, full*2 - FP_ONE);
            horiz2 = gpradius;
        }

#if DARKEN_BITMAP
        size = MemHandleSize(handle);
        copy = MemHandleNew(size);
        bmp = MemHandleLock(copy);
        MemMove(bmp, MemHandleLock(handle), size);
        MemHandleUnlock(handle);
        bits = (Char *) BmpGetBits(bmp);
        
        line2 = bits + radius * bmp->rowBytes;
        line1 = line2 - bmp->rowBytes;
        
        for (y = 0; y < radius; y++) {
            Int32 circx = fpsqrt(FP_ONE - fpsq(y * pixelsize + pixelsize/2));
            x1 = GP_ROUND(fpmul(horiz1, circx));
            x2 = GP_ROUND(fpmul(horiz2, circx)) - 1;
            
            while (x1 <= x2) {
                Char* ptr = line1 + (x1>>1);
                if ((x1 & 1))
                    *ptr = (*ptr & 0xf0) | (((*ptr & 0x0f) >> 1) + 8);
                else
                    *ptr = 0x80 | ((*ptr & 0xe0) >> 1) | (*ptr & 0x0f);
                ptr = line2 + (x1>>1);
                if ((x1 & 1))
                    *ptr = (*ptr & 0xf0) | (((*ptr & 0x0f) >> 1) + 8);
                else
                    *ptr = 0x80 | ((*ptr & 0xe0) >> 1) | (*ptr & 0x0f);
                x1++;
            }
            line1 -= bmp->rowBytes;
            line2 += bmp->rowBytes;
            
        }
        WinDrawBitmap(bmp, x0 - bmp->width / 2, 
                      y0 - bmp->height / 2);
#else
        bmp = MemHandleLock(handle);
        WinDrawBitmap(bmp, x0 - bmp->width / 2, 
                      y0 - bmp->height / 2);
        MemHandleUnlock(handle);
        
        for (y = 0; y < radius; y++) {
            Int32 circx = fpsqrt(FP_ONE - fpsq(y * pixelsize + pixelsize/2));
            x1 = GP_ROUND(fpmul(horiz1, circx));
            x2 = GP_ROUND(fpmul(horiz2, circx));
            
            if (bkgBlack) {
                WinDrawLine(x0+x1, y0-1-y, x0+x2, y0-1-y);
                WinDrawLine(x0+x1, y0+y,   x0+x2, y0+y);
            } else {
                int xb = GP_ROUND(fpmul(gpradius, circx));
                WinEraseLine(x0+x1, y0-1-y, x0+x2, y0-1-y);
                WinEraseLine(x0+x1, y0+y,   x0+x2, y0+y);
                if (xb < radius) {
                    WinEraseLine(x0-radius, y0-1-y, x0-xb-1, y0-1-y);
                    WinEraseLine(x0-radius, y0+y,   x0-xb-1, y0+y);
                    WinEraseLine(x0+xb, y0-1-y, x0+radius-1, y0-1-y);
                    WinEraseLine(x0+xb, y0+y,   x0+radius-1, y0+y);
                }
            }
        }
#endif
    } else {

        if (waxing) {
            horiz1 = fpmul(gpradius, FP_ONE - full*2);
            horiz2 = gpradius;
        } else {
            horiz1 = -gpradius;
            horiz2 = fpmul(gpradius, full*2 - FP_ONE);
        }

        /* Draw a circle! */
        if (!bkgBlack) {
            // Add an extra pixel to draw a circle to outline the phase
            WinDrawRectangle(&bounds, radius+1);
        }

        for (y = 0; y < radius; y++) {
            Int32 circx = fpsqrt(FP_ONE - fpsq(y * pixelsize + pixelsize/2));
            x1 = GP_ROUND(fpmul(horiz1, circx));
            x2 = GP_ROUND(fpmul(horiz2, circx));
            
            if (waxing) {
                if (x2 > x1) {
                    WinEraseLine(x0+x1, y0-1-y, x0+x2-1, y0-1-y);
                    WinEraseLine(x0+x1, y0+y,   x0+x2-1, y0+y);
                }
            } else {
                if (x2 > x1) {
                    WinEraseLine(x0+x1, y0-1-y, x0+x2-1, y0-1-y);
                    WinEraseLine(x0+x1, y0+y,   x0+x2-1, y0+y);
                }
            }
        }
    }
}

/*
 * This can be used to display rise, trans and set information on any
 * form with two or three time fields.  (Transit time is optional and
 * can be excluded by passing transid as 0)
 */
static void
ShowRiseSet(TablePtr table, int row, int flags, Int32 LTr, Int32 LTs,
            int labelcol, int risecol, int transcol, int setcol)
{
    int			font = 0;
    Char str[FIELDLENGTH];
    Char flstr[3];

    font = UpNow(flags, LTr, LTs, currentJTime + currentTzDST) ? 1 : 0;

    // Usually a button if set
    if (labelcol >= 0)
        TblSetItemFont(table, row, labelcol, font);
    
    if (flags & ASTROLIB_DONTRISE) {
        GetStringResource(flags & ASTROLIB_CIRCUMPOLAR ? s_CirPl: s_NvrUp, 
                          str);
        UpdateTblItemText(table, row, risecol, str);
    } else {
        FormatTime(LTr,  str, FIELDLENGTH, flstr, false);
        UpdateTblItemText(table, row, risecol, str);
        UpdateTblItemText(table, row, risecol+1, flstr);
    }
    TblSetItemFont(table, row, risecol, font);

    // We don't always show the transit time
    if (transcol >= 0) {
        if ((flags & (ASTROLIB_DONTRISE | ASTROLIB_DONTSET))) {
            GetStringResource(flags & ASTROLIB_CIRCUMPOLAR ? s_CirPl: s_NvrUp,
                              str);
            UpdateTblItemText(table, row, transcol, str);
                             
        }
        else {
            FormatTime((LTs + LTr) / 2,  str, FIELDLENGTH, flstr, false);
            UpdateTblItemText(table, row, transcol, str);
            UpdateTblItemText(table, row, transcol+1, flstr);
        }
        TblSetItemFont(table, row, transcol, font);
    }
    
    if (flags & ASTROLIB_DONTSET) {
        GetStringResource(flags & ASTROLIB_CIRCUMPOLAR ? s_CirPl: s_NvrUp, 
                          str);
        UpdateTblItemText(table, row, setcol, str);
    } else {
        FormatTime(LTs,  str, FIELDLENGTH, flstr, false);
        UpdateTblItemText(table, row, setcol, str);
        UpdateTblItemText(table, row, setcol+1, flstr);
    }
    TblSetItemFont(table, row, setcol, font);
}

/*
 * Get a textual description for the given moon age in percent.
 */
static Char *
GetMoonPhaseDescription(Int32 phase, Char *phaseName)
{
    /* Convert phase to name. */
    static const Char xlatarr[] =
        { 0, 1,1,1,1, 2, 3,3,3,3, 4, 5,5,5,5, 6, 7,7,7,7, 0 };
    SysStringByIndex(stbl_MoonPhases, 
                     xlatarr[GP_ROUND((FPTOGP(phase) + GP(2)) * 5)],
                     phaseName, FIELDLENGTH);
    return phaseName;
}





/*
 * Display the current Greenwich and Local Sidereal times
 */
static void
ShowTimebases(FormPtr formPtr)
{
    Int32 gst, lst;
    int  frac, deltaday;
    Char str[FIELDLENGTH];
    
    gst = UTCToGST(currentJTime, currentGSTOffset);
    lst = GSTToLST(gst, userPrefs.lng);

    frac     = (int) ((currentJTime + currentTzDST) / (DAY/10));
    deltaday = frac / 10;
    frac     %= 10;
    if (frac < 0) {
        frac += 10;
        deltaday--;
    }

    StrPrintF(str, "%ld.%d", currentJDay + deltaday, frac);
    UpdateTextField(f_Jday, str);

    FormatTime(fpmul(gst + -2*FP_ONE, DAY/4), str, FIELDLENGTH, NULL, true);
    UpdateTextField(f_GST, str);
    FormatTime(fpmul(lst + -2*FP_ONE, DAY/4), str, FIELDLENGTH, NULL, true);
    UpdateTextField(f_LST, str);
}

static UInt16 object_imageID[] = {
    0, 0, /*Earth*/0, bmp_MoonG, bmp_Mars, 0, 
    0, 0, 0, bmp_Pluto, 0/*Sun*/
};

/*
 * Display the rising and setting times for the 8 planets.
 */
static void
ShowSolarSystem(FormPtr formPtr)
{
    int         planet, flags;
    Int32       sinlat, coslat;
    Int32       UTr, UTs;
    Int32       tz;
    Char        str[FIELDLENGTH];
    TablePtr    tablePlanets = (TablePtr) 
        FrmGetObjectPtrByID(formPtr, tbl_Planets);

    tz = currentTzDST;

    fpsincos(userPrefs.lat, &sinlat, &coslat);

    for (planet = SUN; planet >= MERCURY; planet--)
    {
        if (planet == EARTH)
            continue;

        flags = SolObjectRiseSet(planet, currentJDay, currentJTime, 
                                 sinlat, coslat, userPrefs.lng, &UTr, &UTs);
        

        
        SysStringByIndex(stbl_SolarObjects, planet, str, FIELDLENGTH);
        UpdateTblItemText(tablePlanets, planet, 0, str);
        TblSetItemInt(tablePlanets, planet, 0, centerAlign);
        ShowRiseSet(tablePlanets, planet, flags, UTr + tz, UTs + tz, 
                    0, 1, -1, 3);
    }
    
}



/*
 * Display detail pages for non catalogue objects.
 *
 * Standard first page:
 *
 *              Rise          Trans           Set
 *              88:88         88:88          88:88
 *                   Alt                  RA
 *                   Az                   Dec
 *                   IllF                 Mag
 *                   R6C1                 R6C2
 *
 * Subsequent pages:
 *
 *                   R1C1                 R1C2
 *                   R2C1                 R2C2 <- Normally start this row for spacing
 *                   R3C1                 R3C2
 *                   R4C1                 R4C2
 *                   R5C1                 R5C2
 *                   R6C1                 R6C2
 */

static void
DrawObjectImage(FormPtr formPtr)
{
    if (userPrefs.currentObj < CATOBJ) {
        Int32 pa, illf;
        MemHandle handle = NULL;
        Boolean bkgBlack = userPrefs.optFlags.blackBackground;
        Boolean scrLocked = false;

        if (userPrefs.optFlags.showImage && grayscaleSupport) {
            if (object_imageID[userPrefs.currentObj] > 0) {
                    /* Image available */
                handle = DmGetResource('Tbmp', 
                                       object_imageID[userPrefs.currentObj]);
            }
        }
        
        // Now draw whatever we have decided
        if (hasRom35)
            scrLocked = (WinScreenLock(winLockCopy) != NULL);
        
        // Paint background black if preferred
        if (bkgBlack) {
            WinDrawRectangle(&widebox, 2);
        } else {
            WinEraseRectangle(&widebox, 2);
        }

        if (userPrefs.currentObj == SUN) {
            /* Sun is always full */
            pa = 0;
            illf = FP_ONE;
        } else if (userPrefs.currentObj == MOON) {
            LunarPhase(&pa, &illf, currentJDay, currentJTime);
        } else {
            Int32 Ex, Ey, Er;
            Int32 sinracosdec, cosracosdec, sindec, mag, dist, semid;

            HelioPlanetPos(EARTH, currentJDay, currentJTime, NULL,
                           &Ey, &Ex, &Er);

            PlanetPos(userPrefs.currentObj, currentJDay, currentJTime, 
                      Ex, Ey, Er,
                      &sinracosdec, &cosracosdec, &sindec, 
                      &illf, &mag, &dist, &semid, &pa);
        }

        DrawPhase(IMAGEBMPCENTERX, IMAGEBMPCENTERY, 25, 
                  handle, illf, pa < 0, bkgBlack);
        
        if (scrLocked)
            WinScreenUnlock();
    }
}

static void
ShowSSObjectDetail(FormPtr formPtr)
{
    Int32 gst, lst, illf, mag, dist, semid, pa;
    Int32 ra, dec, sinracosdec, cosracosdec, sindec;
    Int32 alt, az, sinalt, sinazcosalt, cosazcosalt;
    Int16 h,m,s;
    Int32 sinlat, coslat, sinlst, coslst;
    Int32 Ex, Ey, Er;

    TablePtr tableDet = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_Details);
    TablePtr tableRTS = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_RTS);
    
    // This variable is used to temporarily use a different background
    // if appropriate image is not available

    int         flags;
    Int32       UTr, UTs;
    Int32       tz;
		

    Char str[FIELDLENGTH];

    gst = UTCToGST(currentJTime, currentGSTOffset);
    lst = GSTToLST(gst,userPrefs.lng);
	
    fpsincos(userPrefs.lat, &sinlat, &coslat);
    fpsincos(lst, &sinlst, &coslst);
    
    /*
     * Longitude of the sun
     */
    SolarPos(currentJDay, currentJTime, 
             &sinracosdec, &cosracosdec, &sindec);

    ra  = fpatan2(sinracosdec, cosracosdec);
    dec = fpatan2(sindec, fpsqrt(FP_ONE - fpsq(sindec)));

    tz = currentTzDST;

    if (userPrefs.currentObj == SUN) {
            SolarPos(currentJDay, currentJTime,
                     &sinracosdec, &cosracosdec, &sindec);
            GetStringResource(s_OurOwnStar, str);
    } else if (userPrefs.currentObj == MOON) {
            LunarPos(currentJDay, currentJTime, NULL,
                &sinracosdec, &cosracosdec, &sindec);

            LunarPhase(&pa, &illf, currentJDay, currentJTime);
            GetMoonPhaseDescription(pa, str);
    } else {
            HelioPlanetPos(EARTH, currentJDay, currentJTime, 
                           NULL, &Ey, &Ex, &Er);

            PlanetPos(userPrefs.currentObj, currentJDay, currentJTime, 
                      Ex, Ey, Er,
                      &sinracosdec, &cosracosdec, &sindec, 
                      &illf, &mag, &dist, &semid, &pa);
            SysStringByIndex(stbl_SolarObjects, GetCurrentObject(), 
                             str, FIELDLENGTH);
    }

    UpdateTextLabel(f_DetDesc, str);
    FrmAlignObjectAt(formPtr, f_DetDesc, 80, centerAlign);

    ClearDetailArea();
    switch (currentRocker.value) {
    case 1:
        fpsincos(userPrefs.lat, &sinlat, &coslat);
        fpsincos(lst, &sinlst, &coslst);
        RaDecToAltAz(sinlat, coslat,
                     sinlst, coslst,
                     sinracosdec, cosracosdec, sindec,
                     &sinalt, &sinazcosalt, &cosazcosalt);
        az  = fpatan2(sinazcosalt, cosazcosalt);
        alt = fpatan2(sinalt, fpsqrt(FP_ONE - fpsq(sinalt)));
        userPrefs.az = az;
        userPrefs.alt = alt;
        
        ra  = fpatan2(sinracosdec, cosracosdec);
        dec = fpatan2(sindec, fpsqrt(FP_ONE - fpsq(sindec)));
        
        /* Alt/Az */
        UpdateTblItemText(tableDet, 0, 0, GetStringResource(s_Alt, str));
        AngToDMS(fpabs(alt), &h,&m,&s);
        StrPrintF(str,"%s%d\260 %d' %d\"",
                  alt < 0 ? "-" : "", h,m,s);
        UpdateTblItemText(tableDet, 0, 1, str);
        
        UpdateTblItemText(tableDet, 1, 0, GetStringResource(s_Az, str));
        AngToDMS(az, &h,&m,&s);
        StrPrintF(str,"%d\260 %d' %d\"", h,m,s);
        UpdateTblItemText(tableDet, 1, 1, str);

        /* Ra/Dec */
        UpdateTblItemText(tableDet, 0, 2, GetStringResource(s_Ra, str));
        AngToHMS(ra, &h,&m,&s);
        StrPrintF(str,"%dh %dm %ds",
                  h,m,s);
        UpdateTblItemText(tableDet, 0, 3, str);
        
        UpdateTblItemText(tableDet, 1, 2, GetStringResource(s_Dec, str));
        AngToDMS(fpabs(dec), &h,&m,&s);
        StrPrintF(str,"%s%d\260 %d' %d\"", 
                  dec < 0 ? "-" : "", h,m,s);
        UpdateTblItemText(tableDet, 1, 3, str);
        
        flags = SolObjectRiseSet(userPrefs.currentObj, 
                                 currentJDay, currentJTime,
                                 sinlat, coslat, userPrefs.lng, 
                                 &UTr, &UTs);


        UpdateTblItemText(tableRTS, 0, 0, GetStringResource(s_Rise, str));
        UpdateTblItemText(tableRTS, 0, 2, GetStringResource(s_Trans, str));
        UpdateTblItemText(tableRTS, 0, 4, GetStringResource(s_Set, str));
        ShowRiseSet(tableRTS, 1, flags, UTr + tz, UTs + tz, 
                    -1, 0, 2, 4);
        
        if (userPrefs.currentObj == SUN) {
            /* Nothing special */
        } else if (userPrefs.currentObj == MOON) {
            UpdateTblItemText(tableDet, 2, 0, GetStringResource(s_IllF, str));
            FormatGPNumber(FPTOGP(illf) * 100, 2, str, FIELDLENGTH);
            StrCat(str, "%");
            UpdateTblItemText(tableDet, 2, 1, str);
            
            /* pa is from -2..2, age should be from 0..100 */
            UpdateTblItemText(tableDet, 2, 2, GetStringResource(s_Age, str));
            FormatGPNumber(FPTOGP(pa) * 25 + GP(50), 1, str, FIELDLENGTH);
            StrCat(str, "%");
            UpdateTblItemText(tableDet, 2, 3, str);
            
        } else {
            UpdateTblItemText(tableDet, 2, 0, GetStringResource(s_IllF, str));
            FormatGPNumber(FPTOGP(illf) * 100, 2, str, FIELDLENGTH);
            StrCat(str, "%");
            UpdateTblItemText(tableDet, 2, 1, str);
            
            UpdateTblItemText(tableDet, 2, 2, GetStringResource(s_Mag, str));
            FormatGPNumber(mag, 2, str, FIELDLENGTH);
            UpdateTblItemText(tableDet, 2, 3, str);
        }
        break;

    case 2:
        // Extras per object type on second page
        UpdateTblItemText(tableDet, 0, 2, GetStringResource(s_Phase, str));
        AngToDMS(pa, &h,&m,&s);
        StrPrintF(str,"%d\260 %d' %d\"", h,m,s);
        UpdateTblItemText(tableDet, 0, 3, str);
        
        UpdateTblItemText(tableDet, 1, 0, GetStringResource(s_Size, str));
        FormatGPNumber(semid, 1, str, FIELDLENGTH);
        StrCat(str, "\"");
        UpdateTblItemText(tableDet, 1, 1, str);

        UpdateTblItemText(tableDet, 1, 2, GetStringResource(s_Dist, str));
        FormatGPNumber(FPTOGP(dist) * 40, 1, str, FIELDLENGTH);
        StrCat(str, " AU");
        UpdateTblItemText(tableDet, 1, 3, str);
        break;
    }
}


/*
 * Display the currently selected object.
 */
static void
ShowCatObjDetail(FormPtr formPtr)
{
    Int32  tz, UTr, UTs, gst, lst;
    Int32  ra, dec, sindec, cosdec, sinra, cosra;
    Int32  sinracosdec, cosracosdec;
    Int32  sinlst, coslst;
    Int32  alt, az, sinalt, sinazcosalt, cosazcosalt;
    Int16  h,m,s;
    Int32  sinlat, coslat;
    char   str[FIELDLENGTH];
    int    flags;

    AstroRecordType art;

    TablePtr tableDet = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_Details);
    TablePtr tableRTS = (TablePtr) FrmGetObjectPtrByID(formPtr, tbl_RTS);

    GetCurrentStar(&art);

    UpdateTextLabel(f_DetDesc, art.description);
    FrmAlignObjectAt(formPtr, f_DetDesc, 80, centerAlign);

    ra = art.ra;
    dec = art.dec;

    gst = UTCToGST(currentJTime, currentGSTOffset);
    lst = GSTToLST(gst,userPrefs.lng);

    fpsincos(userPrefs.lat, &sinlat, &coslat);
    fpsincos(dec, &sindec, &cosdec);
    fpsincos(lst, &sinlst, &coslst);
    fpsincos(ra, &sinra, &cosra);
    sinracosdec = fpmul(sinra, cosdec);
    cosracosdec = fpmul(cosra, cosdec);
    RaDecToAltAz(sinlat, coslat, sinlst, coslst,
                 sinracosdec, cosracosdec, sindec,
                 &sinalt, &sinazcosalt, &cosazcosalt);
    az  = fpatan2(sinazcosalt, cosazcosalt);
    alt = fpatan2(sinalt, fpsqrt(FP_ONE - fpsq(sinalt)));
    userPrefs.az = az;
    userPrefs.alt = alt;

    tz = currentTzDST;
    flags = StarRiseSet(currentJDay, currentJTime,
                        ra, dec,
                        sinlat, coslat, lst,
                        &UTr, &UTs);

    ClearDetailArea();
    
    switch (currentRocker.value) {

    case 1:
        /* Alt/Az */
        UpdateTblItemText(tableDet, 0, 0, GetStringResource(s_Alt, str));
        AngToDMS(fpabs(alt), &h,&m,&s);
        StrPrintF(str,"%s%d\260 %d' %d\"",
                  alt < 0 ? "-" : "", h,m,s);
        UpdateTblItemText(tableDet, 0, 1, str);
        
        UpdateTblItemText(tableDet, 1, 0, GetStringResource(s_Az, str));
        AngToDMS(az, &h,&m,&s);
        StrPrintF(str,"%d\260 %d' %d\"", h,m,s);
        UpdateTblItemText(tableDet, 1, 1, str);

        /* Ra/Dec */
        UpdateTblItemText(tableDet, 0, 2, GetStringResource(s_Ra, str));
        AngToHMS(ra, &h,&m,&s);
        StrPrintF(str,"%dh %dm %ds",
                  h,m,s);
        UpdateTblItemText(tableDet, 0, 3, str);
        
        UpdateTblItemText(tableDet, 1, 2, GetStringResource(s_Dec, str));
        AngToDMS(fpabs(dec), &h,&m,&s);
        StrPrintF(str,"%s%d\260 %d' %d\"", 
                  dec < 0 ? "-" : "", h,m,s);
        UpdateTblItemText(tableDet, 1, 3, str);
            

        UpdateTblItemText(tableRTS, 0, 0, GetStringResource(s_Rise, str));
        UpdateTblItemText(tableRTS, 0, 2, GetStringResource(s_Trans, str));
        UpdateTblItemText(tableRTS, 0, 4, GetStringResource(s_Set, str));
        ShowRiseSet(tableRTS, 1, flags, UTr + tz, UTs + tz, 
                    -1, 0, 2, 4);
        
        UpdateTblItemText(tableDet, 2, 0, GetStringResource(s_Mag, str));
        StrPrintF(str,"%s%d.%02d", art.magnitude < 0 ? "-" : "",
                  abs(art.magnitude)/100, abs(art.magnitude)%100);
        UpdateTblItemText(tableDet, 2, 1, str);

        if (art.sizex == 0 && art.sizey == 0) {
            UpdateTblItemText(tableDet, 2, 2, GetStringResource(s_Size, str));
            if (art.sizex == art.sizey)
                StrPrintF(str, "%d.%d", art.sizex / 10, art.sizex % 10);
            else
                StrPrintF(str, "%d.%dx%d.%d", art.sizex / 10, art.sizex % 10, 
                          art.sizey / 10, art.sizey % 10);
        }

        UpdateTblItemText(tableDet, 2, 3, str);
        break;
    default:
    }
}

Boolean
DateChangeHandleEvent(EventPtr event)
{
    switch (event->eType) {
    case nilEvent:
        if (userPrefs.isNow)
            SetNow();
        break;
    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case s_Date:
            SetDate();
            return true;
        case s_Time:
            SetTime();
            return true;
        case b_Now:
            SetNow();
            return true;
        default:
        }
        break;

    case keyDownEvent:
        if (userPrefs.pageBtnFunction == PAGEBTNDATE) {
            if (event->data.keyDown.chr == pageUpChr) {
                ChangeDate(1);
                return true;
            } else if (event->data.keyDown.chr == pageDownChr) {
                ChangeDate(-1);
                return true;
            }
        }
        break;
        
    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case r_Dated:
            ChangeDate(-1);
            CtlHandleEvent(event->data.ctlRepeat.pControl, event);
            return true;
        case r_Dateu:
            ChangeDate(1);
            CtlHandleEvent(event->data.ctlRepeat.pControl, event);
            return true;
        default:
        }
        break;
    default:
    }
    return false;
}


/*
 * Display the date selector and update the current date with the
 * user's selection. dP is a pointer to the selector resource
 * to refresh.
 *
 * Return boolean indicating whether date has actually changed to reduce unnecessary recalc
 */
static Boolean
SetDate()
{    
    Int16	oldmonth, oldday, oldyear;
    Char str[FIELDLENGTH];

    // Capture the current setting.
    oldday = userPrefs.currentDT.day;
    oldmonth = userPrefs.currentDT.month;
    oldyear = userPrefs.currentDT.year;

    SelectDay(selectDayByDay,
              &userPrefs.currentDT.month,
              &userPrefs.currentDT.day,
              &userPrefs.currentDT.year,
              GetStringResource(s_SelectDate, str));

    // Only refresh if something changed
    if (oldday != userPrefs.currentDT.day
        || oldmonth != userPrefs.currentDT.month
        || oldyear != userPrefs.currentDT.year) {
        userPrefs.isNow = false;
        DrawDatePicker();
        CalculateDate();
        FrmUpdateForm(FrmGetActiveFormID(), updateDateChanged);

        return true;
    }
    return false;
}

/*
 * Display the time selector and update the time with the user's
 * selection.
 *
 * Return boolean indicating whether time has actually changed to reduce unnecessary recalc
 */
static Boolean
SetTime()
{
    Int16	oldhours, oldminutes;
    Char str[FIELDLENGTH];

    // Capture the current setting.
    oldhours = userPrefs.currentDT.hour;
    oldminutes = userPrefs.currentDT.minute;

    /* PalmOS 3.1+ has a nice time picker. */
    if (hasRom31) {
        
        Int16	hours, minutes;
        
        /* Provide a default of the current setting. */
        hours = userPrefs.currentDT.hour;
        minutes = userPrefs.currentDT.minute;
        
        if (SelectOneTime(&hours, &minutes, 
                          GetStringResource(s_SelectTime, str))) {
            userPrefs.currentDT.hour = hours;
            userPrefs.currentDT.minute = minutes;
            userPrefs.isNow = false;
        }
    } else {
        /* Pre PalmOS 3.1 it's a bit clumsier. */
        
        TimeType    s,e;
        
        e.hours = s.hours = userPrefs.currentDT.hour;
        e.minutes = s.minutes = userPrefs.currentDT.minute;

        if (SelectTimeV33(&s, &e, false, 
                          GetStringResource(s_SetStartTimeOnly, str), 0)
            && *((Int16*)&s) != -1) {
            userPrefs.currentDT.hour = s.hours;
            userPrefs.currentDT.minute = s.minutes;
            userPrefs.isNow = false;
        }
    }

    // Only refresh if something changed
    if (oldhours != userPrefs.currentDT.hour
        || oldminutes != userPrefs.currentDT.minute) {
        DrawTimePicker();
        CalculateDate();
        FrmUpdateForm(FrmGetActiveFormID(), updateDateChanged);

        return true;
    }
    return false;
}


/*
 * Set the base date and TOD (used for various calculations) to 'now'.
 */
static Boolean
SetNow()
{
    Int16	oldhours, oldminutes, oldday, oldmonth, oldyear;

    // Capture the current setting.
    oldday = userPrefs.currentDT.day;
    oldmonth = userPrefs.currentDT.month;
    oldyear = userPrefs.currentDT.year;
    oldhours = userPrefs.currentDT.hour;
    oldminutes = userPrefs.currentDT.minute;

    userPrefs.isNow = true;
    /*
     * Set the date and time to now.
     */
    TimSecondsToDateTime(TimGetSeconds(), &userPrefs.currentDT);
     
    // Only refresh if something changed.
    if (oldday != userPrefs.currentDT.day
        || oldmonth != userPrefs.currentDT.month
        || oldyear != userPrefs.currentDT.year
        || oldhours != userPrefs.currentDT.hour
        || oldminutes != userPrefs.currentDT.minute) {
        
        DrawTimePicker();
        DrawDatePicker();
        CalculateDate();
        FrmUpdateForm(FrmGetActiveFormID(), updateDateChanged);
        
        return true;
    }
    return false;
}



/*
 * Process all menu selections. This is possible because
 * all Astro forms use the same menu.
 */
Boolean
FormChangeHandleEvent(EventPtr event)
{
    Boolean handled = false;

    switch (event->eType) {
    case ctlSelectEvent:
        if (event->data.ctlSelect.controlID == b_SS) {
            FrmGotoForm(f_SolarSystem);
            handled = true;
        }
        if (event->data.ctlSelect.controlID == b_Sky) {
            FrmGotoForm(f_Sky);
            handled = true;
        }
        if (event->data.ctlSelect.controlID == b_Catalog) {
            FrmGotoForm(f_Catalog);
            handled = true;
        }
        break;

    case menuEvent:
        switch (event->data.menu.itemID) {
        case mi_SolarSystem:
            if (userPrefs.activeFormId != f_SolarSystem)
                FrmGotoForm(f_SolarSystem);
            handled = true;
            break;

        case mi_About:
            if (userPrefs.activeFormId != f_About) 
                FrmPopupForm(f_About);
            handled = true;
            break;

        case mi_Options:
            if (userPrefs.activeFormId != f_Options) 
                FrmGotoForm(f_Options);
            handled = true;
            break;

        case mi_Catalog:
            if (userPrefs.activeFormId != f_Catalog) 
                FrmGotoForm(f_Catalog);
            handled = true;
            break;

        case mi_Timebases:
            if (userPrefs.activeFormId != f_Timebases)
                FrmGotoForm(f_Timebases);
            handled = true;
            break;

        case mi_Sky:
            if (userPrefs.activeFormId != f_Sky)
                FrmGotoForm(f_Sky);
            handled = true;
            break;
            
        case mi_Help:
            switch (userPrefs.activeFormId) 
            {
                case f_ObjectDetail:
                    FrmHelp(s_DetailHelp);
                    break;
                case f_Timebases:
                    FrmHelp(s_TimebasesHelp);
                    break;
                case f_Sky:
                    FrmHelp(s_SkyHelp);
                    break;
                case f_Options:
                    FrmHelp(s_OptionsHelp);
                    break;
                case f_SolarSystem:
                    FrmHelp(s_SolarSystemHelp);
                    break;
                case f_Catalog:
                    FrmHelp(s_CatalogHelp);
                    break;
                default:
                    ErrFatalDisplay("Unknown form. Missing Help!");
            }
            handled = true;
            break;

        case mi_Night:
            if (colorSupport)
            {
                /* Color support is enabled. Toggle night mode. */
                userPrefs.optFlags.nightMode = !userPrefs.optFlags.nightMode;
                NightMode();
            }
        }
    default:
    }
    return handled;
}


static Boolean
ChangeRocker(Boolean rockup)
{
    if (rockup) {
        // If we haven't hit the top.
        if (currentRocker.value > currentRocker.minValue) {
            // If we move away from bottom then show enabled down.
            if (currentRocker.value == currentRocker.maxValue)
                UpdateControlLabel(r_DetDown, "\002");
            currentRocker.value--;
            // If we move to the top then show disabled up.
            if (currentRocker.value == 1)
                UpdateControlLabel(r_DetUp, "\003");
            
            return true;
        }
    } else {
        // If we haven't hit the bottom.
        if (currentRocker.value < currentRocker.maxValue) {
            // If we move away from top then show enabled up.
            if (currentRocker.value == 1)
                UpdateControlLabel(r_DetUp, "\001");
            currentRocker.value++;
            // If we move to the bottom then show disabled down.
            if (currentRocker.value == currentRocker.maxValue)
                UpdateControlLabel(r_DetDown, "\004");
            
            return true;
        }
    }
    return false;
}

/*
 * Rocker code based on switching two pairs of characters representing up/down enabled/disabled arrows.
 */
Boolean
RockerChangeHandleEvent(EventPtr event)
{
    Boolean handled = false;
        
    switch (event->eType) {
    case keyDownEvent:
        if (userPrefs.pageBtnFunction ==  PAGEBTNROCKER) {
            if (event->data.keyDown.chr == pageUpChr) {
                ChangeRocker(true);
                handled = true;
                break;

            }
            else if (event->data.keyDown.chr == pageDownChr) {
                ChangeRocker(false);
                handled = true;
                break;
            }
        }
        break;

    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case r_DetUp:
                ChangeRocker(true);
                CtlHandleEvent(event->data.ctlRepeat.pControl, event);
                handled = true;
                break;

        case r_DetDown:
                ChangeRocker(false);
                CtlHandleEvent(event->data.ctlRepeat.pControl, event);
                handled = true;
                break; 
        default:
        }
        break;
    default:
    }

    if (handled) {
        /* Only update detail area since date/time hasn't been changed */
        FrmUpdateForm(FrmGetActiveFormID(), updateDetailChanged);
    }

    return handled;
}

static void
InitSolarTable(FormPtr formPtr) {
    TablePtr      tablePlanets = (TablePtr) 
        FrmGetObjectPtrByID(formPtr, tbl_Planets);
    int row, col;

    for (col = 0; col < 5; col++) {
        TblSetCustomDrawProcedure(tablePlanets, col, AstroTableDrawItem);
        TblSetColumnUsable(tablePlanets, col, true);
        TblSetColumnSpacing(tablePlanets, col, 0);
    }
    for (row = MERCURY; row <= SUN; row++) {
        TblSetRowUsable(tablePlanets, col,true);
        for (col = 0; col < 5; col++) {
            TblSetItemPtr(tablePlanets, row, col, NULL);
            TblSetItemInt(tablePlanets, row, col, 
                          col == 2 || col == 4 ? leftAlign :
                          col == 0 ? centerAlign : rightAlign);
            TblSetItemFont(tablePlanets, row, col, 
                           col == 2 || col == 4 ? 130 : 0);
            TblSetItemStyle(tablePlanets, row, col, customTableItem);
        }
    }

    /* XXX Bug in PilRC?? the usable flag isn't set automatically */
    FrmShowObject(formPtr, FrmGetObjectIndex(formPtr, tbl_Planets));
}

/*
 * Events for the entry Solar System form.
 */
static Boolean
SolarSystemFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr formPtr = FrmGetActiveForm();
    
    if (DateChangeHandleEvent(event)
        || FormChangeHandleEvent(event))
        return true;

    switch (event->eType) {
        case tblSelectEvent:
            if (event->data.tblSelect.row != EARTH) {
                SetDetailObjectType(event->data.tblSelect.row);
                FrmGotoForm(f_ObjectDetail);
            }
            handled = true;
            break;

        case frmOpenEvent:
            DrawTimePicker();
            DrawDatePicker();

            InitSolarTable(formPtr);
            ShowSolarSystem(formPtr);
            FrmSetMenu(formPtr,mainMenu);
            FrmDrawForm(formPtr);

            handled = true;
            break;

        case frmCloseEvent:
            AstroFreeTable((TablePtr) 
                           FrmGetObjectPtrByID(formPtr, tbl_Planets));
            handled = false;
            break;

        case frmUpdateEvent:
            switch (event->data.frmUpdate.updateCode) {
            case updateDateChanged:
                ShowSolarSystem(formPtr);
                break;
            }
            FrmDrawForm(formPtr);
            handled = true;
            break;
            
        default:
            handled = false;
    }

    return handled;
}



/*
 * Events for the sidereal time form
 */
static Boolean
TimebasesFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    
    if (DateChangeHandleEvent(event)
        || FormChangeHandleEvent(event))
        return true;

    switch (event->eType) {
        case frmOpenEvent:
            DrawTimePicker();
            DrawDatePicker();
            ShowTimebases(formPtr);

            FrmSetMenu(formPtr,mainMenu);
            FrmDrawForm(formPtr);

            handled = true;
            break;

        case frmUpdateEvent:
            switch (event->data.frmUpdate.updateCode) {
            
            case updateDateChanged:
                ShowTimebases(formPtr);
                break;
            }
            handled = false;
            break;

        default:
            handled = false;
    }

    return handled;
}


static Boolean
AboutFormHandleEvent(EventPtr event)
{
    FormPtr formPtr = FrmGetActiveForm();
    Boolean handled = false;
    static  MemHandle versionHandle, contentHandle;

    switch (event->eType) {
    case ctlSelectEvent:
        if (event->data.ctlSelect.controlID == b_OK) {
            
            FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Version),
                             NULL);
            FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Content),
                             NULL);
            DmReleaseResource(versionHandle);
            DmReleaseResource(contentHandle);
            
            FrmReturnToForm(0);
            handled = true;
            break;
        }
        break;

    case frmCloseEvent:
        FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Version),
                         NULL);
        FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Content),
                         NULL);
        DmReleaseResource(versionHandle);
        DmReleaseResource(contentHandle);
        break;

    case frmOpenEvent:
        
        versionHandle = DmGetResource('tver', 1);
        contentHandle = DmGetResource('tSTR', s_About);
        FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Version),
                         versionHandle);
        
        FldSetTextHandle((FieldPtr)FrmGetObjectPtrByID(formPtr, f_Content),
                         contentHandle);

        FrmSetMenu(formPtr,mainMenu);
        FrmDrawForm(formPtr);
        handled = true;
        break;
        
    default:
    }
    return handled;
}

/*
 * Events for the options form
 */
static Boolean
OptionsFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    Int16 d, m, s;
    Int32 tz;

    if (FormChangeHandleEvent(event))
        return true;
    
    switch (event->eType) {
    case frmCloseEvent:
        userPrefs.tz = GetNumField(formPtr,f_TZh) * 3600000
            + GetNumField(formPtr,f_TZm) * 60000;
        if (GetControlValue(p_TZw))
            userPrefs.tz = -userPrefs.tz;
        
        userPrefs.dstRuleNr = LstGetSelection
            ((ListPtr) FrmGetObjectPtrByID(formPtr, l_dst));
        SetDSTRule(userPrefs.dstRuleNr, &userPrefs.dstRule);
        
        userPrefs.lat = DMSToAng(GetNumField(formPtr,f_LATd),
                                 GetNumField(formPtr,f_LATm),
                                 GetNumField(formPtr,f_LATs));
        if (GetControlValue(p_LATs)) 
            userPrefs.lat = -userPrefs.lat;
        
        userPrefs.lng = DMSToAng(GetNumField(formPtr,f_LNGd),
                                 GetNumField(formPtr,f_LNGm),
                                 GetNumField(formPtr,f_LNGs));
        
        if (GetControlValue(p_LNGw)) 
            userPrefs.lng = -userPrefs.lng;
        
        userPrefs.optFlags.time24Hour = GetControlValue(p_TIME24);
        if (GetControlValue(p_PB_DetRocker))
            userPrefs.pageBtnFunction = PAGEBTNROCKER;
        else if (GetControlValue(p_PB_DateTime))
            userPrefs.pageBtnFunction = PAGEBTNDATE;
        else
            userPrefs.pageBtnFunction = PAGEBTNOBJECT;
        
        CloseDSTRules();
        CalculateDate();
        handled = false;
        break;

    case popSelectEvent:
        GetDSTName(event->data.popSelect.selection, dstRuleName);
        CtlSetLabel(event->data.popSelect.controlP, dstRuleName);
        handled = true;
        break;

    case frmOpenEvent:
        // local scope
        {
            int entries = OpenDSTRules();
            
            ListPtr dstlistPtr = (ListPtr) FrmGetObjectPtrByID(formPtr, l_dst);
            
            if (userPrefs.dstRuleNr >= entries)
                userPrefs.dstRuleNr = 0;
            
            LstSetListChoices(dstlistPtr, NULL, entries);
            LstSetDrawFunction(dstlistPtr, DSTListDrawData);
            LstSetSelection(dstlistPtr, userPrefs.dstRuleNr);
            LstSetTopItem(dstlistPtr, userPrefs.dstRuleNr);
            
            GetDSTName(userPrefs.dstRuleNr, dstRuleName);
            UpdateControlLabel(pt_dst, dstRuleName);
        }

        /* Calculate absolute timezone in minutes; round to nearest */
        tz = ((userPrefs.tz > 0 ? userPrefs.tz : -userPrefs.tz) + 30000)
            / 60000;
        SetFieldValue(f_TZh, tz / 60);
        SetFieldValue(f_TZm, tz % 60);
        SetControlValue(p_TZw, (userPrefs.tz < 0));
        SetControlValue(p_TZe, (userPrefs.tz > 0));
        
        AngToDMS(fpabs(userPrefs.lat), &d, &m, &s);
        SetFieldValue(f_LATd, d);
        SetFieldValue(f_LATm, m);
        SetFieldValue(f_LATs, s);
        SetControlValue(p_LATs, (userPrefs.lat < 0));
        SetControlValue(p_LATn, (userPrefs.lat > 0));
        
        AngToDMS(fpabs(userPrefs.lng), &d, &m, &s);
        SetFieldValue(f_LNGd, d);
        SetFieldValue(f_LNGm, m);
        SetFieldValue(f_LNGs, s);
        SetControlValue(p_LNGw, (userPrefs.lng < 0));
        SetControlValue(p_LNGe, (userPrefs.lng > 0));

        // Choose time format for display
        SetControlValue(p_TIME24, userPrefs.optFlags.time24Hour);
        SetControlValue(p_TIMEs, !userPrefs.optFlags.time24Hour);

        // Choose action page up/down buttons perform
        SetControlValue(p_PB_DetRocker, 
                        userPrefs.pageBtnFunction == PAGEBTNROCKER);
        SetControlValue(p_PB_DateTime,
                        userPrefs.pageBtnFunction == PAGEBTNDATE);
        SetControlValue(p_PB_None,
                        userPrefs.pageBtnFunction == PAGEBTNOBJECT);

        FrmSetMenu(formPtr,mainMenu);
        FrmDrawForm(formPtr);

        handled = true;
        break;
        
    default:
        handled = false;
    }

    return handled;
}



static Boolean
PhaseOptionsFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    
    switch (event->eType) {
    case ctlSelectEvent:
         if (event->data.ctlSelect.controlID == b_OK) {

                userPrefs.optFlags.blackBackground = 
                        GetControlValue(p_OBJECTBGBL);

                /* It's not gray then its none. */
                userPrefs.optFlags.showImage = 
                        GetControlValue(p_OBJECTIMAGE);

                FrmUpdateForm(userPrefs.activeFormId, updateDateChanged);
                FrmReturnToForm(0);
                handled = true;
         }
        break;

    case frmOpenEvent:

        SetControlValue(p_OBJECTLINEART, ! userPrefs.optFlags.showImage);
        SetControlValue(p_OBJECTIMAGE, userPrefs.optFlags.showImage);
        SetControlValue(p_OBJECTBGWH, ! userPrefs.optFlags.blackBackground);
        SetControlValue(p_OBJECTBGBL, userPrefs.optFlags.blackBackground);
         
        FrmDrawForm(formPtr);

        handled = true;
        break;
        
    default:
        handled = false;
    }

    return handled;
}

static void
ChangeObject(FormPtr formPtr, int delta)
{
    Int16 currObj = GetCurrentObject();

    if (currObj != CATOBJ) {
        currObj += delta;
        // Skip Earth;
        if (currObj == EARTH)
            currObj += delta;
        if (currObj > SUN)
            currObj = MERCURY;
        if (currObj < MERCURY)
            currObj = SUN;
        SetDetailObjectType(currObj);

        // Since we are changing object and the available
        // fields may be different...
        CloseObjectForm();
        SetupObjectForm(formPtr);

    } else {
        currObj = GetCurrentRecord() + delta;
        if (currObj < 0) 
            currObj = GetTotalRecords() - 1;
        else if (currObj == GetTotalRecords())
            currObj = 0;
        SetCurrentRecord(currObj);
    }

    FrmUpdateForm(FrmGetActiveFormID(), updateDateChanged);
}

/*
 * Events for the Planet Detail form
 */
static Boolean
ObjectDetailFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();

    if (DateChangeHandleEvent(event)
        || FormChangeHandleEvent(event)
        || RockerChangeHandleEvent(event))
        return true;
    
    switch (event->eType) {
        
    case keyDownEvent:
        if (userPrefs.pageBtnFunction == PAGEBTNOBJECT) {
            if (event->data.keyDown.chr == pageUpChr) {
                ChangeObject(formPtr, -1);
                handled = true;
            }
            else if (event->data.keyDown.chr == pageDownChr) {
                ChangeObject(formPtr, +1);
                handled = true;
            }
        }
        break;
        
    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case r_ObjPrev:
            ChangeObject(formPtr, -1);
            CtlHandleEvent(event->data.ctlRepeat.pControl, event);
            handled = true;
            break;
            
        case r_ObjNext:
            ChangeObject(formPtr, +1);
            CtlHandleEvent(event->data.ctlRepeat.pControl, event);
            handled = true;
            break; 
        }
        break;

    case ctlSelectEvent:
        if (event->data.ctlSelect.controlID == b_Option) {
            FrmPopupForm(f_ObjectOptions);
            handled = true;
        }
        break;

    case frmOpenEvent:
        SetupObjectForm(formPtr);
        
        DrawTimePicker();
        DrawDatePicker();
        InitDetailTable();

        if (userPrefs.currentObj < CATOBJ) {
            ShowSSObjectDetail(formPtr);
        } else {
            ShowCatObjDetail(formPtr);
        }

        FrmSetMenu(formPtr,mainMenu);
        FrmDrawForm(formPtr);
        DrawObjectImage(formPtr);
        handled = true;
        break;
        
    case frmUpdateEvent:
        switch (event->data.frmUpdate.updateCode) {
            
            // Second flag to each function determines whether to
            // perform a redraw of top half of screen.  This may be
            // meaningless for some objects and is simply ignored.
        case updateDateChanged:
        case updateDetailChanged:
            if (userPrefs.currentObj < CATOBJ) {
                ShowSSObjectDetail(formPtr);
            } else {
                ShowCatObjDetail(formPtr);
            }
            break;
        }
        FrmDrawForm(formPtr);
        DrawObjectImage(formPtr);
            
        handled = true;
        break;
            
    case frmCloseEvent:
        AstroFreeTable((TablePtr) 
                       FrmGetObjectPtrByID(formPtr, tbl_RTS));
        AstroFreeTable((TablePtr) 
                       FrmGetObjectPtrByID(formPtr, tbl_Details));
        CloseObjectForm();
        handled = false;
        break;
        
    default:
        handled = false;
    }

    return handled;
}

/*
 * Events for the main application (basically, setting form event
 * handlers.)
 */
static Boolean
ApplicationHandleEvent(EventPtr event)
{
    FormPtr form;
    UInt16 formId;
    Boolean handled = false;

    if (event->eType == frmLoadEvent) {
        formId = event->data.frmLoad.formID;
        form = FrmInitForm(formId);
        FrmSetActiveForm(form);
        
        switch (formId) {

            case f_SolarSystem:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   SolarSystemFormHandleEvent);
                handled = true;
                break;

            case f_ObjectDetail:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   ObjectDetailFormHandleEvent);
                handled = true;
                break;

            case f_ObjectOptions:
                FrmSetEventHandler(form,
                                   PhaseOptionsFormHandleEvent);
                handled = true;
                break;
/**********/
            case f_Catalog:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   CatalogFormHandleEvent);
                handled = true;
                break;
                
            case f_SelectCatalog:
                FrmSetEventHandler(form,
                                   SelectCatalogFormHandleEvent);
                handled = true;
                break;
                
            case f_FindObject:
                FrmSetEventHandler(form,
                                   FindObjectFormHandleEvent);
                handled = true;
                break;
/**********/
            case f_Timebases:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   TimebasesFormHandleEvent);
                handled = true;
                break;
/**********/
            case f_Sky:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   SkyFormHandleEvent);
                handled = true;
                break;

            case f_SkyOptions:
                FrmSetEventHandler(form,
                                   SkyOptionsFormHandleEvent);
                handled = true;
                break;
/**********/
            case f_Options:
                userPrefs.activeFormId = formId;
                FrmSetEventHandler(form,
                                   OptionsFormHandleEvent);
                handled = true;
                break;

            case f_About:
                FrmSetEventHandler(form,
                                   AboutFormHandleEvent);
                handled = true;
                break;
        }
    }
    return handled;
}

#ifdef SELFTEST
extern void ReportTest(Char* text);

void
ReportTest(Char* text)
{
    FrmCustomAlert(a_Warning, text, " ", " ");
}

static void RunTests() {
    DSTTest();
    LibTest();
}
#endif

/*
 * Application event loop. duh.
 */
static void
EventLoop(void)
{
    EventType   event;
    UInt16      error;
    Int32       timeout;
    Int32       ticksPerSec = SysTicksPerSecond();

    do {
        if (userPrefs.isNow) {
            /* Wait until the next minute starts */
            timeout = (60 - (TimGetSeconds() % 60)) * ticksPerSec;
        } else
            timeout = evtWaitForever;
        EvtGetEvent(&event, timeout);
        if (!SysHandleEvent(&event))
            if (!MenuHandleEvent(NULL, &event, &error))
                if (!ApplicationHandleEvent(&event))
                    FrmDispatchEvent(&event);
    } while (event.eType != appStopEvent);
}

/*
 * Initialize the math library; allocate the handles for
 * various text fields; load our previously saved preferences.
 */
static void
StartApplication(void)
{
    UInt16 mptSize = sizeof(userPrefs);

    MemHandle fontHandle;
    FontType *fontPtr;

    fontHandle=DmGetResource('NFNT',fnt_Tiny);
    fontPtr=MemHandleLock(fontHandle);
    FntDefineFont(130, fontPtr);

    // Handy flags used in lots of places in this file
    hasRom31 = CheckMinRomVersion(sysVersion31);
    hasRom35 = CheckMinRomVersion(sysVersion35);

    PrefGetPreferences(&sysPrefs);

    MemMove(&userPrefs, &defaultPrefs, sizeof(userPrefs));
    if ((PrefGetAppPreferences(APPID, 0,
                               &userPrefs,
                               &mptSize,
                               true) != noPreferenceFound)
        && userPrefs.version != ASTROVERSION) {

        int compsize = ASTROCOMPSIZE(userPrefs.version);
        if (compsize == 0) {
            /* We found a very old version, warn user about userPrefs
             * changes.
             */
            FrmAlert(a_PrefsChanged);
        }

        MemMove((Char *)&userPrefs + compsize, 
                (Char *)&defaultPrefs + compsize, 
                sizeof(userPrefs) - compsize);
        userPrefs.version = ASTROVERSION;
    }

    if (userPrefs.isNow) {
        /*
         * Set the date and time to now.
         */
        TimSecondsToDateTime(TimGetSeconds(), &userPrefs.currentDT);
    }

    /* Protect user against complete failure if the form IDs
     * changed.
     */
    switch (userPrefs.activeFormId) {
    case f_SolarSystem:
    case f_Catalog:
    case f_Sky:
    case f_ObjectDetail:
    case f_Timebases:
    case f_Options:
        break;
    default:
        userPrefs.activeFormId = defaultPrefs.activeFormId;
    }

    CalculateDate();
    EnableGraphicsMode();

    if (colorSupport) {
        NightMode();
        mainMenu=m_Color;
    }

#ifdef SELFTEST
    RunTests();
#endif

    /* Open previously opened catalog.
     * Also initialises catalog for sky map.
     */
    OpenCatalog();

    FrmGotoForm(userPrefs.activeFormId);
}

/*
 * Releases all memory; closes libraries; saves preferences
 */
static void
StopApplication()
{
    MemHandle fontHandle;

    FreeCatalog();
        
    FrmCloseAllForms();

    fontHandle = DmGetResource('NFNT',fnt_Tiny);
    MemHandleUnlock(fontHandle);

    PrefSetAppPreferences(APPID,
                          0, 1,
                          &userPrefs,
                          sizeof(userPrefs),
                          true);

    DisableGraphicsMode();
}

UInt32
PilotMain(UInt16 cmd,
          MemPtr cmdBPD,
          UInt16 launchFlags)
{
    if (cmd == sysAppLaunchCmdNormalLaunch)
    {
        if (!CheckMinRomVersion(sysVersion30)) {
            FrmAlert(a_TooLimited);
            return 0;
        }

        /* Main application */
        StartApplication();
        EventLoop();
        StopApplication();
        /* End of main application. */
        
        return 0;
    }

    return 0;
}

/*
 * This color table defines a set things to be drawn in red.
 */
static UIColorTableEntries redList[] = {
    UIObjectFrame, UIObjectForeground, UIObjectSelectedFill,
    UIMenuFrame, UIMenuForeground, UIMenuSelectedFill,
    UIFieldText, UIFieldCaret, UIFieldTextHighlightBackground,
    UIFieldFepRawText, UIFieldFepConvertedText,
    UIFieldFepUnderline, UIFormFrame,
    UIDialogFrame, UIAlertFrame, UIOK, UICaution, UIWarning,
    UILastColorTableEntry 
};

/*
 * My version of a color table.
 */
typedef struct MyColorTableType
{
    UInt16 numEntries;
    RGBColorType rgb[UILastColorTableEntry];
    UInt32 appid;
} MyColorTableType;

/*
 * Sets or clears the red-on-black color scheme for color palm pilots
 * to match the userPrefs.optFlags.nightMode flag.
 *
 * Color tables are saved by renaming them from type sysResTSysPref
 * to type MWH2.
 */
void
NightMode()
{
    DmOpenRef savedPrefs = NULL;
    MemHandle handle = NULL;
    MyColorTableType *table;
    Boolean inNightMode = false;
    
    Err err;
    UInt16 length = UILastColorTableEntry;
    UInt32 appId = APPID;
    
    int i;    
    
    RGBColorType redColor = { 0, 0xA0, 0, 0 };
    RGBColorType blackColor = { 0, 0, 0, 0 };
    
    Int16 indexCurrent, indexSave;

    savedPrefs=DmOpenDatabaseByTypeCreator(sysFileTSavedPreferences,
                                           sysFileCSystem,
                                           dmModeReadWrite);
    ErrFatalDisplayIf(savedPrefs==0,"Couldn't open Saved Preferences!");
    
    indexCurrent = DmFindResource(savedPrefs,
                                  sysResTSysPref,
                                  sysResIDPrefUIColorTable8,
                                  NULL);
    indexSave = DmFindResource(savedPrefs,
                               APPID,
                               sysResIDPrefUIColorTable8,
                               NULL);
    if (indexCurrent >= 0)
    {
        /* A table exists. Is it one of ours? */
        handle = DmGetResourceIndex(savedPrefs, indexCurrent);
        if (MemHandleSize(handle) == sizeof(struct MyColorTableType)) 
        {
            table = MemHandleLock(handle);
            inNightMode = (table->appid == APPID);
            MemHandleUnlock(handle);
        }
        DmReleaseResource(handle);
    }

    if (inNightMode == userPrefs.optFlags.nightMode) {
        /* No need to change night mode. */
        DmCloseDatabase(savedPrefs);
        return;
    } 
    else if (!userPrefs.optFlags.nightMode)
    {
        /* Turn night mode off. */

        /* Delete the red-on-black color table. */
        err = DmRemoveResource(savedPrefs, indexCurrent);
        ErrFatalDisplayIf(err,"Failed to remove color table!");
        
        if (indexSave>=0) 
        {
            /* Restore saved table. */
            DmResType rt = sysResTSysPref;
            
            err = DmSetResourceInfo(savedPrefs, indexSave,
                                    &rt, NULL);
        }
    }
    else 
    {
        if (indexSave>=0) 
        {
            /* Delete the old save table. */
            err = DmRemoveResource(savedPrefs, indexSave);
            ErrFatalDisplayIf(err,"Failed to remove color table!");
        }

        if (indexCurrent >= 0)
        {
            /* Save the current table, by renaming it. */
            err = DmSetResourceInfo(savedPrefs,
                                    indexCurrent,
                                    &appId,
                                    NULL);
            ErrFatalDisplayIf(err,"Failed to save color table!");
        }
        
        /*
         * Turn night mode on.  Set up the new color scheme!
         */
        handle = DmNewResource(savedPrefs,
                               sysResTSysPref,
                               sysResIDPrefUIColorTable8,
                               sizeof(MyColorTableType));
        ErrFatalDisplayIf(handle == NULL, "Couldn't create a Preference!");
        
        table = MemHandleLock(handle);

        /*
         * Set the color table length field
         */
        err=DmWrite(table,
                    OffsetOf(MyColorTableType,numEntries),
                    &length,
                    sizeof(UInt16));

        ErrFatalDisplayIf(err,"DMWrite Failed!");

        /*
         * Set our special "cookie" so that we can identify 
         * color tables that we created.
         */
        err=DmWrite(table,
                    OffsetOf(MyColorTableType,appid),
                    &appId,
                    sizeof(UInt32));

        /*
         * Set the entire table to black.
         */
        for (i=0; i<UILastColorTableEntry; i++)
            DmWrite(table,
                    OffsetOf(MyColorTableType,rgb[i]),
                    &blackColor,sizeof(RGBColorType));
        /*
         * Set all entries in the redlist to red!
         */
        for (i=0; redList[i]!=UILastColorTableEntry; i++)
            DmWrite(table,
                    OffsetOf(MyColorTableType,rgb[redList[i]]),
                    &redColor,sizeof(RGBColorType));

        MemHandleUnlock(handle);
    
        DmReleaseResource(handle);
    }

    DmCloseDatabase(savedPrefs);
    GotoApplication(APPID);
}
