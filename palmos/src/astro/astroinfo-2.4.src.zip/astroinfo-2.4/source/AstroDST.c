/*
 * Astro DST - Daylight Savings for AstroInfo.
 * 
 * $Id: AstroDST.c,v 1.14 2001/11/24 19:05:50 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "resource.h"
#include "Astro.h"
#include "AstroLib.h"
#include "AstroDST.h"

static DmOpenRef dstRulesDB = NULL;

static __inline__ Int16
daysInMonth(Int16 month, Int16 year)
{
    static const Int16 days_per_month[] = {
        31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
    };

    /* Years is year since 1904 and between 0 and 127, there is no
     * leap year exception as 1900 or 2100 in this range.
     * Use simple "mod 4" rule.
     */
    if (month == 2 && (year & 3) == 0)
        return 29;
    return days_per_month[month-1];
}

static Boolean 
isBefore(DateType *date, Int8 dow, Int16 minutes,
         Int16 cTime, Int16 cDay, Int8 cMonth, Int8 cDOW)
{
    Boolean yearSwitch = false;

    switch (cMonth - date->month) {
    case -11:
        cDay += daysInMonth(date->month, date->year);
        yearSwitch = true;
        break;
    case -1:
        cDay -= daysInMonth(cMonth, date->year);
        break;
    case 0:
        break;
    case 1:
        cDay += daysInMonth(date->month, date->year);
        break;
    case 11:
        cDay -= daysInMonth(cMonth, date->year-1);
        yearSwitch = true;
        break;
    default:
        return date->month < cMonth;
    }

    if (cDOW != 7)
        cDay += (cDOW - dow + date->day - cDay + 70) % 7;

    if (cDay != date->day)
        return yearSwitch ^ (date->day < cDay);
    return yearSwitch ^ (minutes < cTime);
}

Int32
getDSTOffset(Int32 jday, Int32 jtime, Int32 tz, DSTRule *dst)
{
    DateType date;
    Int16 minutes;
    Int8  dow;

    if (dst->savings == 0)
        return 0;

    if (!dst->isUTC)
        jtime += tz;
    
    jtime += 43200000L;
    if (jtime < 0) {
        jtime += 86400000L;
        jday--;
    } else if (jtime >= 86400000L){
        jtime -= 86400000L;
        jday++;
    }
    minutes = jtime / 60000L;
    
    dow = (Int16) ((jday+1) % 7);
    DateDaysToDate(jday - 2416481L, &date);
    
    return (dst->startMon < dst->endMon)
        ^ (isBefore(&date, dow, minutes,
                    dst->startTime, dst->startDay,
                    dst->startMon, dst->startDOW))
        ^ (isBefore(&date, dow, minutes,
                    dst->endTime, dst->endDay, 
                    dst->endMon, dst->endDOW)) ? 0 : dst->savings * 60000L;
}

UInt16
OpenDSTRules()
{
    dstRulesDB = DmOpenDatabaseByTypeCreator(ASTRODSTDBTYPE,
                                             APPID, dmModeReadOnly);
    if (!dstRulesDB)
        return 1;

    return DmNumRecords(dstRulesDB) + 1;
}

void
CloseDSTRules()
{
    if (dstRulesDB) {
        Err err = DmCloseDatabase(dstRulesDB);
        ErrFatalDisplayIf(err != errNone,
                          "Could not close dst rules!");
        dstRulesDB = NULL;
    }
}

void 
SetDSTRule(Int16 itemNum, DSTRule *rule)
{
    MemHandle handle;
    DSTRecord* dstrec;

    if (itemNum == 0 || dstRulesDB == NULL)
        rule->savings = 0;
    else {
        handle = DmQueryRecord(dstRulesDB, itemNum - 1);
        dstrec = (DSTRecord*)MemHandleLock(handle);
        *rule = dstrec->rule;
        MemHandleUnlock(handle);
    }
}


void
GetDSTName(Int16 itemNum, Char *dstRuleName)
{
    MemHandle handle;
    DSTRecord* dstrec;

    if (itemNum == 0 || dstRulesDB == NULL) {
        GetStringResource(s_NoDST, dstRuleName);
    } else {
        handle = DmQueryRecord(dstRulesDB, itemNum - 1);
        dstrec = (DSTRecord*)MemHandleLock(handle);
        StrNCopy(dstRuleName, dstrec->name, FIELDLENGTH);
        MemHandleUnlock(handle);
    }
}

void
DSTListDrawData(Int16 itemNum, RectangleType *bounds, Char **itemsText)
{
    MemHandle handle;
    DSTRecord* dstrec;
    Char *text;

    if (itemNum == 0 || dstRulesDB == NULL) {
        handle = DmGetResource('tSTR', s_NoDST);
        text = MemHandleLock(handle);
        WinDrawChars(text, StrLen(text), 
                     bounds->topLeft.x, bounds->topLeft.y);
        MemHandleUnlock(handle);
        DmReleaseResource(handle);
    } else {
        handle = DmQueryRecord(dstRulesDB, itemNum - 1);
        dstrec = (DSTRecord*)MemHandleLock(handle);
        WinDrawChars(dstrec->name, StrLen(dstrec->name), 
                     bounds->topLeft.x, bounds->topLeft.y);
        MemHandleUnlock(handle);
    }
}

#ifdef SELFTEST
void ReportTest(Char *text);

#define TEST(TEXT, COND) \
  if (!(COND)) { \
    ReportTest("Test Failed: \n" TEXT "\n" \
               #COND "\nin " __FILE__ "\n"); \
  }

void DSTTest() {
    DSTRule europe = {
        1*60, 4, 1*60, 10, 1,
        0, -6, -6, 0, 60
    };
    DSTRule namibia = {
        2*60, 9, 2*60, 4, 0,
        0, 1, 1, 0, 60
    };
    DSTRule rule;
    int numEntries;

    TEST("dIM(2)", daysInMonth(2, 3) == 28);
    TEST("dIM(2) LEAP", daysInMonth(2, 4) == 29);
    TEST("dIM(3)", daysInMonth(3, 3) == 31);
    TEST("dIM(8)", daysInMonth(8, 14) == 31);
    TEST("dIM(9)", daysInMonth(9, 16) == 30);

    TEST("1.1.1904     0:0 CET", 
         getDSTOffset(2416481L, -43200000L, 3600000L, &europe) == 0);
    TEST("1.1.1904     0:0 WAST", 
         getDSTOffset(2416481L, -43200000L, 11*3600000L, &namibia) == 3600000L);
    TEST("31.12.2031 24:00 CET", 
         getDSTOffset(2463232L, +43199999L, 3600000L, &europe) == 0);
    TEST("31.12.2031 24:00 WAST", 
         getDSTOffset(2416481L, +43199999L, 11*3600000L, &namibia) == 3600000L);
    TEST("25.03.2001  0:59 CET", 
         getDSTOffset(2451994L, -43200000L + 3600000L - 1L, 
                      3600000L, &europe) ==  0);
    TEST("25.03.2001  1:00 CEST", 
         getDSTOffset(2451994L, -43200000L + 3600000L, 
                      3600000L, &europe) == 3600000L);
    TEST("01.04.2001  0:59 WAST", 
         getDSTOffset(2452001L, -43200000L + 3600000L - 1L, 
                      3600000L, &namibia) == 3600000L);
    TEST("01.04.2001  1:00 WAT", 
         getDSTOffset(2452001L, -43200000L + 3600000L, 
                      3600000L, &namibia) ==  0);

    numEntries = OpenDSTRules();
    if (numEntries == 1)
        ReportTest("DST Rules not installed");
    else {
        SetDSTRule(1, &rule);
        TEST("Australia Rule",
             rule.startTime == 2*60 && rule.startMon == 11
             && rule.startDay == -6 && rule.startDOW == 0
             && rule.endTime == 2*60 && rule.endMon == 4
             && rule.endDay == -6 && rule.endDOW == 0
             && rule.savings == 60 && rule.isUTC == 0);
        SetDSTRule(numEntries-1, &rule);
        TEST("USA Rule",
             rule.startTime == 2*60 && rule.startMon == 4
             && rule.startDay == 1 && rule.startDOW == 0
             && rule.endTime == 2*60 && rule.endMon == 11
             && rule.endDay == -6 && rule.endDOW == 0
             && rule.savings == 60 && rule.isUTC == 0);
        CloseDSTRules();
    }
}
#endif
