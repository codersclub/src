/*
 * Astro Sky - an astronomical visualizer for PalmOS devices.
 * 
 * $Id: Grayscale.c,v 1.11 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "PalmUtil.h"
#include "Grayscale.h"

Boolean grayscaleSupport;
Boolean colorSupport;

static Int32 oldDepth, depth;
static Boolean oldColor;

/* Enable Grayscale or color mode, if Palm supports it. 
 */
void EnableGraphicsMode ()
{
    UInt32    depthMask;
    int       i;
    WinHandle oldDrawWindow;

    /* First check if this PalmOS is recent enough for grayscale/color. 
     *
     * WinScreenMode maps to ScrDisplayMode function versions of PalmOS pre 3.5.
     * Features are equivalent and name change was simply for consistency within
     * the API. Obviously older devices will report many features as not present.
     */
    if (!CheckMinRomVersion(sysVersion30)) { 
        oldDepth = depth = 1;
        oldColor = colorSupport = false;
        grayscaleSupport = false;
        return;
    }

    depth = 1;       

    /* When this function is called we normally don't have a draw window.
     * We work on the display window. 
     */
    oldDrawWindow = WinSetDrawWindow(WinGetDisplayWindow());

    /* Query old depth */
    WinScreenMode(winScreenModeGet, NULL, NULL, &oldDepth, &oldColor);

    /* Query supported depth and colormode */
    WinScreenMode(winScreenModeGetSupportedDepths, 
                  NULL, NULL, &depthMask, NULL);
    WinScreenMode(winScreenModeGetSupportsColor, 
                  NULL, NULL, NULL, &colorSupport);
    
    /* Switch to maximum supported depth
     */
    depth = oldDepth;
    for (i = oldDepth + 1; i < 32; i++) {
        if ((depthMask & (1UL << (i-1))))
            depth = i;
    }

    /* 
     * Force into colour mode if available in case we came here from somewhere weird.
     */
    if (oldDepth != depth || oldColor != colorSupport)
        WinScreenMode(winScreenModeSet, NULL, NULL, &depth, &colorSupport);
    
    /* Restore old draw window (which is normally NULL) */
    WinSetDrawWindow(oldDrawWindow);
    grayscaleSupport = depth > 1;
}

void DisableGraphicsMode() {
    Err err;
    if (oldDepth != depth || oldColor != colorSupport) {
        err = WinScreenMode(winScreenModeSet, 
                            NULL, NULL, &oldDepth, &oldColor);
        ErrFatalDisplayIf(err!=errNone,
                          "Could not restore depth!");
    }
    grayscaleSupport = false;
}
