/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: AstroLib.c,v 1.44 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "AstroLib.h"
#include "constants.h"
#include "FixedPoint.h"


/* Correction since we measure in 40 AU but planet mag is based on AU */
#define GP_MAGCORRECTION GP(16.02060) /* 5 * log(40*40) */

/* Factor for transforming fpln_16 results in magnitude scale */
#define GP_MAGFACTOR     GP(34.74356) /* 5 / fpln_16(10) */

#define GREGORIAN_CUTOVER 2299161L

/*
 * Returns the Julian Day of noon of the given day.
 *
 */
Int32
JDay(int year, int month, int day)
{
    Int32 jday;
  
    if (month<3) {
        month += 12;
        year --;
    }
    
    jday = ((1461 * (Int32) year) >> 2)
        + ((unsigned) (month + 1) * 153L) / 5 + day + 1720995L;
    
    if (jday >= GREGORIAN_CUTOVER) {
        int century = (unsigned) year / 100;
        jday -= (3 * century - 5) >> 2;
    }
    
    return jday;
}

static ALIBSECTION Int32
RadialPos(Int32 radperday, int shift, Int32 jday, Int32 jtime)
{
    Int32 pos, frac, tmp;
    
    frac = fpmul(jtime, 0x636BA876);
    jday += frac >> 27;
    frac &= (1L << 27) - 1;

    pos = radperday * (jday >> shift);
    tmp = ((frac << 3) >> shift);
    frac = ((jday << (30 - shift)) & (FP_ONE - 1)) + tmp; 
    pos += fpmul(radperday, frac);
    return pos;
}

/*
 * Calculate the phase of the moon and full for the current julian
 * day and time.  Result is in FP.
 *
 * phase is the angle sun-moon-earth; 0 for full moon, negative for
 * waxing, positive for waning moon.
 * full is from 0 to 1 as you would expect.
 */
void
LunarPhase(Int32 *phase, Int32 *full,
           Int32 jday, Int32 time)
{
    UInt32 i;
    
    /* age = ((jday + time / 86400000 - 2451550.1) / 29.530588853)  % 1
     * 1 / 29.530588853 ~= 20939 / 618341
     * 
     * (618341 * age)
     *  ~= ((jday + time / 86400000 - 2451550.1) * 20939) % 618341
     *  ~= ((jday % 618341) * 20939 + (time / 4126) - 192747) % 618341
     *   = ((jday % 618341) * (60 * 349 - 1) + (time / 4126) - 192747) % 618341
     */
    
    i = jday % 618341;
    i = ((i * 349) % 618341) * 60 - i;
    i = (i + time / 4126 - 192747) % 618341;
    if (i < 0)
        i += 618341;

    /* Now i is age in range 0..618340. Scale it to fixed point 0..1 */
    i = fpmul(i*1024, FP(1.0*FP_ONE/(1024*618341)));

    /* And finally scale it to -2..2, our angle range. */
    i = (i - FP_ONE/2) << 2;

    *phase = i;

    /* Fullness is (cos(phase) + 1) / 2
     */
    *full = fpcos(i)/2 + FP_ONE/2;
    return;
}

/* Tropic year in days  */
#define TROPYEAR  (31556926.0 / 86400.0)  
/* Sidereal day in days */
#define SIDDAY    (1.0 + 1/TROPYEAR)
/* Sidereal day in angle per millisecond */
#define SIDDAYANG (SIDDAY * 4 * FP_ONE / DAY)

/* Get the GST offset for noon of the given day.  The GST offset
 * is the difference between greenwich sidereal time and UTC in
 * fixed point angle.
 */
Int32 
getGSTOffset(Int32 jday)
{
    Int32 D;

    D = (jday - 2451545);
    return 0xC7704C27
        + ((D>>7) * FP(512 / TROPYEAR))
        + fpmul((D&0x7f) << 23, FP(512 / TROPYEAR));
}

/*
 * Convert a Julian Time to GST
 *
 * Note that utc is in milliseconds, while gst is in fixed point angle.
 */
Int32
UTCToGST(Int32 utc, Int32 gstOffset)
{
    return (fpmul(utc, FP(SIDDAYANG / 32)) << 5) + gstOffset;
}

/*
 * Convert GST to UTC.
 * @param gst       the GST to convert.  In fixed point angle.
 * @param gstOffset the GST offset for noon (UT) of the current julian day.
 * @param jtime     the current julian time (UT) in seconds since noon.  The
 *                  returned time is put in the "vicinity" of jtime.
 * @return The time in UTC in seconds since noon.
 */
Int32 GSTToUTC(Int32 gst, Int32 gstOffset, Int32 jtime)
{
    Int32 jtimeOffset = fpmul(jtime, FP(SIDDAYANG / 32)) << 5;
    return fpmul(gst - gstOffset - jtimeOffset, FP(1 / SIDDAYANG)) + jtime;
}

/*
 * Convert a gst and longitude to LST.
 * all values are in fixed point angle
 */
Int32
GSTToLST(Int32 gst, Int32 lng)
{
    return gst + lng;
}

/*
 * Convert a LST and longitude to GST
 * all values are in fixed point angle
 */
Int32
LSTToGST(Int32 lst, Int32 lng)
{
    return lst - lng;
}

/*
 * Convert fixed point angle to degrees, minutes, seconds
 *
 * For simplicity the angle is considered as unsigned, i.e. degree is
 * in range 0..359, not -180..180.  If you want to display negative
 * angles with a "-" sign you should handle that yourself.
 */
void
AngToDMS(Int32 rad, Int16 *d, Int16 *m, Int16 *s)
{
    /* convert to unsigned and add half a second to rad so we 
     * round to nearest
     */
    UInt32 urad = rad + 1657;

    /* Multiply urad with 360/512 = 45/64 = 3/4 * 15/16.
     * Then degree is in high 9 bits 
     */
    urad -= (urad >> 2);
    urad -= (urad >> 4);
    *d   = urad >> 23;
    urad &= 0x007fffff;

    /* Multiply urad with 60/4 = 15 = 5 * 3 */
    urad += urad << 2;
    urad += urad << 1;
    *m   = urad >> 21;
    urad &= 0x001fffff;

    /* Multiply urad with 60/4 = 15 = 5 * 3 */
    urad += urad << 2;
    urad += urad << 1;
    *s   = urad >> 19;
}

/*
 * Convert fixed point angle to hour, minutes, seconds
 *
 * Note that all values are positive.
 */
void
AngToHMS(Int32 rad, Int16 *h, Int16 *m, Int16 *s)
{
    /* Add half a second to rad so we round to nearest and convert to
       unsigned */
    UInt32 urad = rad + 24855;

    /* Multiply urad with 24/32 = 3/4;  Then hour is in high 5 bits */
    urad -= (urad >> 2);
    *h    = urad >> 27;
    urad &= 0x07ffffff;

    /* Multiply rad with 60/4 = 15 = 5 * 3 */
    urad += urad << 2;
    urad += urad << 1;
    *m   = urad >> 25;
    urad &= 0x01ffffff;

    /* Multiply urad with 60/4 = 15 = 5 * 3 */
    urad += urad << 2;
    urad += urad << 1;
    *s   = urad >> 23;
}

/*
 * Convert DMS to fixed point angle
 *
 * Note that the assumption is that for negative values of DMS, all
 * d, m and s are negative.
 */
Int32
DMSToAng(Int16 d, Int16 m, Int16 s)
{
    return d * 11930464L + m * 198841L + s * 3314L;
}

#if 0  /* No longer used. */
/*
 * Convert HMS to fixed point angle
 *
 * Note that the assumption is that for negative values of DMS, all
 * d, m and s are negative.
 */
Int32
HMSToAng(Int16 d, Int16 m, Int16 s)
{
    return d * 178956970L + m * 2982616L + s * 49710L;
}
#endif

/*
 * Convert R.A./Dec to Alt/Az
 *
 * All in fixed point.
 */
void
RaDecToAltAz(Int32 sinlat, Int32 coslat,
             Int32 sinlst, Int32 coslst,
             Int32 sinracosdec, Int32 cosracosdec, 
             Int32 sindec,
             Int32 *sinalt, 
             Int32 *sinazcosalt, Int32 *cosazcosalt)
{
    Int32 cosHAcosdec;
    
    /* Don't ask me how I got these equations...
     * HA stands for hour angle, i.e. angle between lst and ra
     */
    cosHAcosdec = fpmul(coslst, cosracosdec)
        + fpmul(sinlst, sinracosdec);
    *sinalt = fpmul(sinlat, sindec)
        + fpmul(coslat, cosHAcosdec);
    *cosazcosalt = fpmul(coslat, sindec)
        - fpmul(sinlat, cosHAcosdec);
    *sinazcosalt = fpmul(sinracosdec, coslst)
        - fpmul(cosracosdec, sinlst);
}

/*
 * Convert celestial co-ordinates (lat,long)
 * to right ascension and declination.
 *
 * All angles in radians.
 */
void
CelestialToRaDec(Int32 sinlat, 
                 Int32 sinlngcoslat, Int32 coslngcoslat,
                 Int32 jday,
                 Int32 *sinracosdec,
                 Int32 *cosracosdec,
                 Int32 *sindec)
{
    Int32 t;
    Int32 eo, coseo, sineo;
    /*
     * Calculate ecliptic obliquity
     */
    t = jday - 2451545; /* EPOCH = January 2000 1.5 */
    eo = 0x10AAFE27 - fpmul(0x43F66979, t << 2)
        - fpmul(fpmul(0x7E97E010, t << 9), t << 9)
        - (fpmul(fpmul(fpmul(0x55A6EB21, t << 9), t << 9), t << 9) << 8);

    //e0 = 84381.448 - 46.8150 * t - 0.00059 * t^2 + 0.001813 * t ^ 3;
    coseo = fpcos(eo);
    sineo = fpsin(eo);

    *sindec      = fpmul(sinlngcoslat,sineo) + fpmul(sinlat,coseo);
    *sinracosdec = fpmul(sinlngcoslat,coseo) - fpmul(sinlat,sineo);
    *cosracosdec = coslngcoslat;
}


/*
 * Solve Kepler's Equation.  All units in fixed points.
 */
static Int32
Kepler(Int32 MeanAnomoly, Int32 Eccentricity)
{
    Int32 E, dE, d;

    
    Eccentricity = fpmul(Eccentricity, FP_2_PI);
    E = MeanAnomoly;
    d = fpmul(Eccentricity, fpsin(E));

    while (fpabs(d) > 32) {
        dE = fpdiv(d, FP_ONE - fpmul(Eccentricity,fpcos(E)));
        E  = E - dE;
        d  = E - fpmul(Eccentricity,fpsin(E)) - MeanAnomoly;
    }
    return E;
}

/*
 * Calculate the rising and setting times for an object.
 *
 * Times in LST.  If the object does not rise/set at this
 * latitude, returns -1, and LSTr and LSTs are not set.
 *
 * ra and dec are in radians.
 */
static ALIBSECTION int
RiseSet(Int32 sinracosdec, Int32 cosracosdec, Int32 sindec,
        Int32 sinlat, Int32 coslat,
        Int32 px, Int32 *LSTt, Int32 *H)
{
    Int32 coslatsq = fpsq(coslat);
    Int32 sindecsq = fpsq(sindec);
    Int32 D = coslatsq - sindecsq;

    *LSTt = fpatan2(sinracosdec, cosracosdec);
        
    if (D < 0) {
        if ((sindec < 0) ^ (sinlat < 0)) {
            *H = 0;
            return ASTROLIB_DONTRISESET;
        } else {
            *H = -2*FP_ONE;
            return ASTROLIB_CIRCUMPOLAR | ASTROLIB_DONTRISESET;
        }
    } else {
        Int32 y;
        Int32 sinpx   = fpsin(IOR_EST - px);
        Int32 sinpxsq = fpsq(sinpx);
        Int32 cosdec  = fpsqrt(FP_ONE - sindecsq);
        
        /* Time shift for parallax and refraction */
        y = fpatan2(fpmul(sinpx, cosdec), 
                    fpsqrt(D - fpmul(1 - sindecsq, sinpxsq)));
        
        /*
         * Hour angle
         */
        *H = fpatan2(fpsqrt(D), -fpmul(sinlat, sindec))
            + fpmul(y, cosdec);

        /* always/never arise due to parallax */
        if (*H < 0)
            return (y > 0 ? ASTROLIB_CIRCUMPOLAR : 0) | ASTROLIB_DONTRISESET;

        return 0;
    }
}

/*
 * Data for planetary equations.
 * see astrolib.h for definitions of MERCURY, MARS, etc..
 */

/* We measure distances in 40 AU (approx the radius of pluto's orbit) */
#define FP_AU(x) FP(x/40.0)

/* Average speed of planet in radians per day */
static const Int8 radshift[] = {
    5, 6, 7, 0/*Moon*/, 8, 11, 12, 13, 14, 15
};
static const Int32 radperday[] = {
    0x5D1F9611,
    0x48EA27BD,
    0x59B65454,
    0, /* Moon */
    0x5F6522CE,
    0x7900739e,
    0x6169d58b,
    0x4452a1f0,
    0x45af7499,
    0x5D12458E
};

/* Longitude at epoch relative to perihelion (Radians)*/
static const Int32 elong[] = {
    0xf43b4ffc,
    0xe170c0b0,
    0xfdd203c1,
    0, /* Moon */
    0xbc591dfc,
    0x366078e7,
    0x8a8b780f,
    0x45d0d11b,
    0xa6a44222,
    0xfe10c8d5
};

/* longitude at perihelion (radians) */
// XXX This has to stay in global section as it is accessed in Astro.c
static const Int32 sinplong[] = {
    0x3e6f25c1,
    0x2ffc19ab,
    0x3e7d961a,
    0, /* Moon */
    0xe5d75f6c,
    0x0fab0199,
    0x3feb9294,
    0x07ed63ed,
    0x2f918d40,
    0xd36f63da
};
// XXX This has to stay in global section as it is accessed in Astro.c
static const Int32 cosplong[] = {
    0x0e1201be,
    0xd5a69516,
    0xf22eac1a,
    0, /* Moon */
    0x3a68f290,
    0x3e0d714b,
    0xfcce1b71,
    0xc07e2b91,
    0x2ad0f64a,
    0xd210c9a6
};

/* Eccentricity of the orbit */
// XXX This has to stay in global section as it is accessed in Astro.c
static const Int32 ecc[] = {
    0x0d291750,
    0x006f0cfe,
    0x0111d367,
    0, /* Moon */
    0x05fa3337,
    0x031a543f,
    0x038ea39c,
    0x02f6ec5b,
    0x00938152,
    0x0fc2656b
};

/* precalculated values of sqrt((1 + ecc) / (1 - ecc)); */
static const Int32 sqrtecc[] = {
    0x4ed87307,
    0x406f6dff,
    0x4114271a,
    0, /* Moon */
    0x4648d897,
    0x432e8dba,
    0x43a96a35,
    0x4309581a,
    0x40942cd8,
    0x524b132c
};

/* Semi-major axis of the orbit */
static const Int32 sma[] = {
    FP_AU( 0.3870986),
    FP_AU( 0.7233316),
    FP_AU( 1.0000000),
    0, /* Moon */
    FP_AU( 1.5236883),
    FP_AU( 5.202561),
    FP_AU( 9.554747),
    FP_AU(19.21814),
    FP_AU(30.10957),
    FP_AU(39.3414),
};

/* inclination of the orbit */
static const Int32 cosinc[] = {
    0x3f85b7c7,
    0x3fe34103,
    0x40000000,
    0, /* Moon */
    0x3ff7766c,
    0x3ffbc26b,
    0x3ff08b10,
    0x3ffe8238,
    0x3ff82d50,
    0x3d282d56
};
static const Int32 sininc[] = {
    0x07cdfef2, 
    0x03ca1d9a, 
    0x00000000, 
    0, /* Moon */
    0x0210d952, 
    0x0174bdfe, 
    0x02c78306, 
    0x00dd0e59, 
    0x01fa3e79, 
    0x12dd08d9, 
};

/* longitude of the ascending node (sinus/cosinus) */
static const Int32 sinasc[] = {
    0x2fb84e84,
    0x3e4148fd,
    0x00000000,
    0, /* Moon */
    0x30a6d563,
    0x3ef53f98,
    0x3aa86ad5,
    0x3d7f8abb,
    0x2fce82de,
    0x3c15cab1,
};
static const Int32 cosasc[] = {
    0x2aa5c07d,
    0x0ed7ca14,
    0x40000000,
    0, /* Moon */
    0x2994d68b,
    0xf47f8df1,
    0xe666ef3d,
    0x11b81d93,
    0xd5732503,
    0xe9f5aa61
};

#define PLUTOEPOCH 2447161

/* angular semidiameter @ 1 AU (in arc seconds)*/
static const Int16 angsemidau[] = { 
    GP16(  3.36),
    GP16(  8.41),        // Based on atmosphere, rather than 8.34 for the crust
    0,  
    0, /* Moon */
    GP16(  4.68),
    GP16( 98.44),
    GP16( 82.73),
    GP16( 35.02),
    GP16( 33.50),
    GP16(  2.70),
    GP16(959.63)

};

/* Visual magnitude at distance 1 AU from earth and sun. */
static const Int16 vmau[] = {
    GP16(-0.42),
    GP16(-4.40),
    0,
    0, /* Moon */
    GP16(-1.52),
    GP16(-9.40),
    GP16(-8.88),
    GP16(-7.19),
    GP16(-6.87),
    GP16(-1.00)
};



void
HelioPlanetPos(int planet, Int32 jday, Int32 jtime, Int32 *ms, 
               Int32 *sinl, Int32 *cosl, Int32 *phdist)
{
    Int32 ma, e, sine2, cose2, d, sinv2, cosv2, sinv, cosv;

    /*
     * Mean Anomoly
     */
    ma = elong[planet] + 
        RadialPos(radperday[planet], radshift[planet], 
                  jday - (planet == PLUTO ? PLUTOEPOCH : EPOCH),
                  jtime - HALFDAY);
    if (ms)
        *ms = ma;
    
    e = Kepler(ma, ecc[planet]);
    fpsincos(e/2, &sine2, &cose2);
    d = fpsqrt(fpdiv(FP_ONE - ecc[planet], 
                     FP_ONE + fpmul(ecc[planet], FP_ONE - 2 * fpsq(cose2))));
    
    /*
     * True Anomoly
     */
    cosv2 = fpmul(cose2, d);
    sinv2 = fpmul(sine2, fpmul(sqrtecc[planet], d));
    
    sinv = 2*fpmul(sinv2,cosv2);
    cosv = 2*fpmul(cosv2,cosv2) - FP_ONE;
    
    if (cosl)
        *cosl = fpmul(cosv, cosplong[planet])
            - fpmul(sinv, sinplong[planet]);
    if (sinl)
        *sinl = fpmul(sinv, cosplong[planet])
            + fpmul(cosv, sinplong[planet]);
    
    // MEEUS AA 30.2: r = sma * (1 - ecc * cos e)
    if (phdist)
        *phdist = fpmul(sma[planet], FP_ONE - fpmul(ecc[planet], fpcos(e))); 
}



void SolarLong(Int32 jday, Int32 jtime, 
               Int32 *ms, Int32 *sinl, Int32 *cosl) {
    HelioPlanetPos(EARTH, jday, jtime, ms, sinl, cosl, NULL);
    *cosl = -*cosl;
    *sinl = -*sinl;
}

void SolarPos(Int32 jday, Int32 jtime, 
              Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec)
{
    Int32 sinl, cosl;
    /*
     * Longitude of the earth relative to sun
     */
    HelioPlanetPos(EARTH, jday, jtime, NULL, &sinl, &cosl, NULL);
    
    /*
     * ra and dec.
     */
    CelestialToRaDec(0, -sinl, -cosl, jday,
                     sinracosdec, cosracosdec, sindec);
}

/*
 * Lunar Position for the current date/time angles in radians.
 *
 * ra2, dec2 and EC are optional returns.  EC is the (optional) error
 * correcting term for parallax equations. If EC = NULL then it is not
 * populated.
 */
void
LunarPos(Int32 jday, Int32 jtime, Int32 *EC,
         Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec)
{
    Int32 sinls, cosls, ms;            /* solar info */
    Int32 lm, mm, nm;                  /* lunar info */
    Int32 ev, ae, a3, a4, ec;          /* various correcting factors */
    Int32 xy, x, y, z;                 /* moon's pos */
    Int32 sinmm, cosmm, sinms;
    Int32 sinlm, coslm, sinlmls, coslmls, sin2lmls, cos2lmls, sinlmnm;
    
    /*
     * Longitude and anomoly of the sun
     */
    SolarLong(jday, jtime, &ms, &sinls, &cosls);
    
    /*
     * Mean Longitude and anomoly of the moon
     */
    lm = MOON_L0 + RadialPos(0x4af5847c, 3, jday - EPOCH, jtime- HALFDAY);
    mm = lm - MOON_P0 - RadialPos(0x511f3a97, 10, jday-EPOCH, jtime - HALFDAY);

    /*
     * Node longitude
     */
    nm = MOON_N0
        - RadialPos(0x4d1ea482, 11, jday - EPOCH, jtime - HALFDAY)
        - fpmul(0x1D208A, fpsin(ms));
    
    /* Calculate helping sin
     * sinlmls = sin(lm-ls)
     * coslmls = cos(lm-ls)
     */

    sinlm = fpsin(lm);
    coslm = fpcos(lm);
    sinlmls  = fpmul(sinlm, cosls) - fpmul(coslm, sinls);
    coslmls  = fpmul(coslm, cosls) + fpmul(sinlm, sinls);
    sin2lmls = 2*fpmul(sinlmls, coslmls);
    cos2lmls = 2*fpmul(coslmls, coslmls) - FP_ONE;
    sinmm  = fpsin(mm);
    cosmm  = fpcos(mm);
    sinms  = fpsin(ms);

    /*
     * Corrections
     */
    ev = fpmul(0xe7e80b, fpmul(sin2lmls, cosmm) - fpmul(cos2lmls, sinmm));
    ae = fpmul(0x21d2e8, sinms);
    a3 = fpmul(0x435b3f, sinms);
    
    /*
     * Corrected anomoly
     */
    mm += ev - ae - a3;

    /*
     * Equation of the center
     */
    ec = fpmul(0x478ce00, fpsin(mm));
    
    if (EC)
        *EC = mm + ec;
    
    /*
     * Y.A.C.
     */
    a4 = ev + ec - ae + fpmul(0x26f51f, fpsin(2 * mm));

    lm += a4;
    sin2lmls = fpmul(sin2lmls, fpcos(2*a4)) + fpmul(cos2lmls, fpsin(2*a4));
    lm += fpmul(0x77D700, sin2lmls);
    
    /*
     * Moon's position
     */
    sinlmnm = fpsin(lm - nm);
    xy = fpmul(sinlmnm, FP_ONE - fpcos(MOON_I));
    
    
    x = fpcos(lm) + fpmul(fpsin(nm), xy);
    y = fpsin(lm) - fpmul(fpcos(nm), xy);
    z = fpmul(sinlmnm, fpsin(MOON_I));

    /*
     * Convert to ra and dec
     */
    CelestialToRaDec(z, y, x,
                     jday, sinracosdec, cosracosdec, sindec);
}

/*
 * Calculate the position of a planet for a given
 * julian date.
 */
void
PlanetPos(int planet, Int32 jday, Int32 jtime, 
          Int32 Ex, Int32 Ey, Int32 Er,
          Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec, 
          Int32 *pillf, Int32 *pmag, Int32 *pgeodist, 
          Int32 *psemid, Int32 *ppa)
{
    Int32 x, y, z, cosi;
    Int32 xy, sinl, cosl;
    Int32 sinlasc;
    Int32 sinlat, sinlngcoslat, coslngcoslat;
    Int32 heldist, geodistsq;
    Int32 geoheldist;
    Int32 mag, geodist, pa, pasq;

    HelioPlanetPos(planet, jday, jtime, NULL, &sinl, &cosl, &heldist);

    sinlasc = fpmul(sinl, cosasc[planet]) - fpmul(cosl, sinasc[planet]);
    xy = fpmul(sinlasc, FP_ONE - cosinc[planet]);

    /*
     * Heliocentric coordinates of planet
     * x coordinate points in direction of asc.
     */
    x  = fpmul(cosl + fpmul(sinasc[planet], xy), heldist) - fpmul(Ex, Er);
    y  = fpmul(sinl - fpmul(cosasc[planet], xy), heldist) - fpmul(Ey, Er);
    z  = fpmul(fpmul(sinlasc, sininc[planet])  , heldist);

    geodistsq = fpsq(x) + fpsq(y) + fpsq(z);
    *pgeodist = geodist = fpsqrt(geodistsq);

    sinlat       = fpdiv(z, geodist);
    sinlngcoslat = fpdiv(y, geodist);
    coslngcoslat = fpdiv(x, geodist);

    /* cosine rule for triangle sun, planet, earth:
     * MEEUS AA 41.2: cosi = (heldist^2 + geodist^2 - Er^2) / (2*heldist*geodist)
     */
    geoheldist = fpmul(geodist, heldist);
    cosi = fpdiv((fpsq(heldist)>>1) + (geodistsq>>1) - (fpsq(Er)>>1), 
                 geoheldist);

    /* Illuminated fraction. */
    // MEEUS AA 41.1: k = (1 + cosi) / 2
    *pillf = ((FP_ONE/2) + (cosi>>1));

    /* phase angle */
    pa = fpatan2(fpsqrt(FP_ONE - fpsq(cosi)), cosi);

    /* Scale semidiameter based on the distance from us. 
     * The 40 is for our AU factor, the 2 for "semi".
     * MEEUS AA 55.1:
     */
    *psemid = fpdiv(GP16TO32(angsemidau[planet] / (40 / 2)), geodist);

    /* Relative visual magnitude and semidiameter from Earth.
     * MEEUS AA 41.d: 
     * mag = vmau[planet] + 5 * log(geodist * heldist) + c[planet] * pa
     */
    mag = GP16TO32(vmau[planet]) + GP_MAGCORRECTION + fpmul(GP_MAGFACTOR, fpln_16(geoheldist));

    pasq = fpsq(pa);

    switch (planet) {
    case MERCURY:
        mag += fpmul(GP(0.0380 * 90), pa) - fpmul(GP(0.000273 * 90), pasq) + fpmul(GP(0.000002 * 90), fpmul(pasq, pa));
        break;
    case VENUS:
        mag += fpmul(GP(0.0009 * 90), pa) + fpmul(GP(0.000239 * 90), pasq) - fpmul(GP(0.00000065 * 90), fpmul(pasq, pa));
    case MARS:
        mag += fpmul(GP(0.016 * 90), pa);
        break;
    case JUPITER:
        mag += fpmul(GP(0.005 * 90), pa);
        break;
    case SATURN:
            // TODO: Add ring brightness based on plane of rings
        break;
    default:
        break;
    }
    *pmag = mag;
    *ppa = fpmul(sinl,Ex) - fpmul(cosl,Ey) > 0 ? pa : -pa;

    CelestialToRaDec(sinlat, sinlngcoslat, coslngcoslat, jday, 
                     sinracosdec, cosracosdec, sindec);
    return;
}

/*
 * Returns position (Ra/Dec) and parallax for a solar system object.
 * @param solarID  one of SUN, MOON or MERCURY..PLUTO.
 */
static ALIBSECTION void 
SolObjectPosPx(int solarID, Int32 jday, Int32 jtime,
               Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec,
               Int32 *px) {
    if (solarID == SUN) {
        SolarPos(jday, jtime, sinracosdec, cosracosdec, sindec);
        *px = SOLAR_P - SOLAR_A / 2;
    } else if (solarID == MOON) {
        Int32 EC;
        LunarPos(jday, jtime, &EC, sinracosdec, cosracosdec, sindec);
        *px = fpmul(MOON_P - MOON_A / 2, 
                    fpdiv(FP_ONE + fpmul(MOON_E, fpcos(EC)),
                          FP_ONE - fpsq(MOON_E)));
    } else {
        Int32 illf, mag, dist, semid, pa;
        Int32 Ex, Ey, Er;
            
        HelioPlanetPos(EARTH, jday, jtime,
                       NULL, &Ey, &Ex, &Er);
        PlanetPos(solarID, jday, jtime, Ex, Ey, Er,
                  sinracosdec, cosracosdec, sindec, 
                  &illf, &mag, &dist, &semid, &pa);
        *px = fpdiv(FP(4.263452e-5), dist);
    }
}


/*
 * Returns the times of moon or planet rise and moon set in UT.
 * @param solarID  one of SUN, MOON or MERCURY..PLUTO.
 */
int
SolObjectRiseSet(int solarID, Int32 jday, Int32 jtime,
                 Int32 sinlat, Int32 coslat, Int32 lng,
                 Int32 *pUTr, Int32 *pUTs)
{
    Int32 sinracosdec, cosracosdec, sindec;
    Int32 px;
    int i, retry;
    int flags;
    Int32 lstt, H;
    Int32 UTr, UTs, UTt;
    Int32 gstOffset;
    
    gstOffset = getGSTOffset(jday);

    /*
     * First Approximation of position.
     */
    SolObjectPosPx(solarID, jday, jtime, 
                   &sinracosdec, &cosracosdec, &sindec, &px);

    /*
     * Initial guess at rise and set times.
     */
    flags = RiseSet(sinracosdec, cosracosdec, sindec,
                    sinlat, coslat, px,
                    &lstt, &H);

    /*
     * First approximation of rise and set.
     */
    UTt  = GSTToUTC(lstt - lng, gstOffset, jtime);
    H    = fpmul(H, FP(1/SIDDAYANG));
    UTr  = UTt - H;
    UTs  = UTt + H;
    retry = 100;

    while ((flags & ASTROLIB_DONTRISE) == 0 && retry--) {
        jtime = UTr;

        /*
         * Improved position at rise time.
         */
        SolObjectPosPx(solarID, jday, jtime, 
                       &sinracosdec, &cosracosdec, &sindec, &px);
        
        /*
         * Improved guess at rise time.
         * We ignore the set time.
         */
        i = RiseSet(sinracosdec, cosracosdec, sindec,
                    sinlat, coslat, px,
                    &lstt, &H);

        if (i & ASTROLIB_DONTRISE) {
            flags |= i & (ASTROLIB_CIRCUMPOLAR | ASTROLIB_DONTRISE);
            break;
        }
        
        UTr = GSTToUTC(lstt - H - lng, gstOffset, jtime);
        if (fpabs(UTr - jtime) < 15000)
            break;
    }

    *pUTr = UTr;
    retry = 100;
    
    while ((flags & ASTROLIB_DONTSET) == 0 && retry--) {
        jtime = UTs;
        
        /*
         * Improved position at set time.
         */
        SolObjectPosPx(solarID, jday, jtime, 
                       &sinracosdec, &cosracosdec, &sindec, &px);
        
        /*
         * Improved guess at set time.
         * We ignore the rise time.
         */
        i = RiseSet(sinracosdec, cosracosdec, sindec,
                    sinlat, coslat, px,
                    &lstt, &H);

        if (i & ASTROLIB_DONTSET) {
            flags |= i & (ASTROLIB_CIRCUMPOLAR | ASTROLIB_DONTRISE);
            break;
        }

        UTs = GSTToUTC(lstt + H - lng, gstOffset, jtime);
        if (fpabs(UTs - jtime) < 15000)
            break;
    }
    *pUTs = UTs;

    return flags;
}

/*
 * Returns the times of moon or planet rise and moon set in UT.
 * @param solarID  one of SUN, MOON or MERCURY..PLUTO.
 */
int
StarRiseSet(Int32 jday, Int32 jtime,
            Int32 ra, Int32 dec,
            Int32 sinlat, Int32 coslat, Int32 lng,
            Int32 *pUTr, Int32 *pUTs)
{
    int flags;
    Int32 lstt, H, UTt;
    Int32 gstOffset;
    Int32 sinra, cosra, sindec, cosdec;
    
    gstOffset = getGSTOffset(jday);
    fpsincos(dec, &sindec, &cosdec);
    fpsincos(ra,  &sinra, &cosra);
    

    flags =  RiseSet(fpmul(sinra, cosdec), fpmul(cosra,cosdec), sindec,
                     sinlat, coslat, 0,
                     &lstt, &H);
    UTt  = GSTToUTC(lstt - lng, gstOffset, jtime);
    H    = fpmul(H, FP(1/SIDDAYANG));
    *pUTr  = UTt - H;
    *pUTs  = UTt + H;
    return flags;
}

#ifdef SELFTEST
void ReportTest(Char *text);

#define TEST(TEXT, COND) \
  if (!(COND)) { \
    ReportTest("Test Failed: \n" TEXT "\n" \
               #COND "\nin " __FILE__ "\n"); \
  }

void LibTest() {
    Int32 jday;
    Int32 Ey, Ex, Er, Eang;
    Int32 sinracosdec, cosracosdec, sindec, ra, dec;
    Int32 ill, mag, dist, semid, pa;
    Int32 sinlat, coslat;
    Int32 UTr, UTs;
    
    jday = JDay(2001, 1, 1);
    TEST("Jday", jday == 2451911L)
    
    HelioPlanetPos(EARTH, jday, 0,
                   NULL, &Ey, &Ex, &Er);
    Eang = fpatan2(Ey, Ex);
    TEST("Eang", fpabs(Eang - FP(1.12229029)) < FP(2E-8))
    TEST("Erad", fpabs(Er - FP_AU(.9832923)) < FP_AU(2E-7));

    PlanetPos(MERCURY, jday, 0,
              Ex, Ey, Er,
              &sinracosdec, &cosracosdec, &sindec,
              &ill, &mag, &dist, &semid, &pa);
    ra  = fpatan2(sinracosdec, cosracosdec);
    dec = fpatan2(sindec, fpsqrt(FP_ONE - fpsq(sindec)));

    TEST("Ppos"  , 
         fpabs(ra - FP(-.81702497)) + fpabs(dec - FP(-.27314817)) < FP(2E-8));
    TEST("pgeodist" , fpabs(dist - FP_AU(1.4178786)) < FP_AU(2E-7));
    TEST("Pmag"  , fpabs(mag - GP(-1.04)) < GP(0.01));
    TEST("Pill"  , fpabs(ill - FP(.9927)) < FP(.0001));
    TEST("Psemid", fpabs(semid - GP(4.74)) < GP(0.01));

    fpsincos(FP( 41.25 / 90), &sinlat, &coslat);
    SolObjectRiseSet(MOON, jday, 0, sinlat, coslat, FP(-75.50 / 90),
                     &UTr, &UTs);

    TEST("MoonRise", fpabs(UTr - ((16-12)*60+34)*60000L) < 60000L);
    TEST("MoonSet",  fpabs(UTs - (( 4+12)*60+22)*60000L) < 60000L);
}
#endif
