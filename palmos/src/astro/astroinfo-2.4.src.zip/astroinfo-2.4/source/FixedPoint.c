/*
 * FixedPoint - calculations in fixed points for PalmOS devices.
 * 
 * $Id: FixedPoint.c,v 1.12 2001/10/11 16:48:33 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "FixedPoint.h"

#ifdef NO_ASSEMBLER

#define umulw(a,b,prod) \
  prod = ((UInt32)(a) & 0xffff) * ((b) & 0xffff);
#define udivw(a,b,remquot) \
  remquot = (((a) % ((b) & 0xffff)) << 16) \
          | (((a) / ((b) & 0xffff)) & 0xffff);

Int32 fpdiv(Int32 a, Int32 b)
{
    return ((long long)a << 30) / b;
}

Int32 fpmul(Int32 a, Int32 b)
{
    return ((long long)a * b + (1<<29)) >> 30;
}
Int32 fpsq(Int32 a)
{
    return fpmul(a, a);
}
#else /* ! NO_ASSEMBLER */

#define umulw(a,b,prod) \
  __asm__ ("mulu%.w %1,%0" : "=d" (prod) : "d" (b), "0" (a));
#define udivw(a,b,remquot) \
  __asm__ ("divu%.w %1,%0" : "=d" (remquot) : "d" (b), "0" (a));

Int32 fpmul(Int32 a, Int32 b)
{
    Int32 result, tmp1, tmp2, tmp3, tmp4;
    __asm__ ("move%.l %5, %0      /* %0 = a */\n\t"
             "bpl     1f\n\t"
             "neg%.l  %0\n\t"
             "addq%.w #1, %4      /* switch sign flag */\n"
             "1:\t"
             "add%.l  %0, %0      /* shift right a */\n\t"
             "move%.l %0, %2      /* copy a to %2 */\n\t"
             "move%.l %6, %1      /* %1 = b */\n\t"
             "bpl     1f\n\t"
             "neg%.l  %1\n\t"
             "subq%.w #1, %4      /* switch sign flag */\n"
             "1:\t"
             "add%.l  %1, %1      /* shift right b */\n\t"
             "move%.l %1, %3      /* copy b to %3 */\n\t"
             "swap    %3          /* %3 = high(b) */\n\t"
             "mulu%.w %3,%0       /* %0 = high(b) * low(a) */\n\t"
             "swap    %2          /* %2 = high(a) */\n\t"
             "mulu%.w %2,%1       /* %1 = high(a) * low(b) */\n\t"
             "add%.l  %1,%0\n\t"
             "scs     %1\n\t"
             "clr.w   %0\n\t"
             "sub%.b  %1,%0\n\t"
             "swap    %0          /* %0 = h*l + l*h >> 16 */\n\t"
             "addq%.l #1,%0       /* adjust for missing l*l */\n\t"
             "mulu%.w %3,%2       /* %2 = h*h */\n\t"
             "add%.l  %2,%0\n\t"
             "move%.b %4,%4       /* test sign */\n\t"
             "beq     1f\n\t"
             "neg%.l  %0\n"
             "1:"
             : "=d" (result), "=d" (tmp1), "=d" (tmp2), 
             "=d" (tmp3), "=d" (tmp4)
             : "m" (a), "m" (b), "4" (0));
    return result;
}

Int32 fpdiv(Int32 a, Int32 b)
{
    Int32 tmp0,tmp1,tmp2,tmp3,result;
    __asm__ ("add%.l  %1,%1   /* Shift b and test for negative */\n\t"
             /* %0=a, %1=2*b */	   
             "bcc     1f\n\t"
             "neg%.l  %0      /* negate a and b */\n\t"
             "neg%.l  %1\n"
             "bne     1f\n\t"
             "move%.l %0, %4  /* Special case: b=-2 */\n\t"
             "asr%.l  #1, %4\n\t"
             "bra     4f\n\t"
             "1:\t"
             "beq     2f\n\t  /* b == 0: Force a div by zero error */\n\t"
             "move%.l %0,%2   /* Store a we need its sign later */\n\t"
             "bpl     1f\n\t"
             "neg%.l  %0\n"
             "1:\t"
             "tst%.l  %1\n\t"
             "bmi     2f      /* Test if high bit in b is set. */\n"
             "1:\t"
             "add%.l  %0,%0   /* Shift a and b until high bit in b set. */\n\t"
             "add%.l  %1,%1\n\t"
             "bpl     1b\n"
             "2:\t"
             "move%.l %1,%3   /* copy b */\n\t"
             "swap    %3\n\t"
             "divu%.w %3,%0\n\t"
             "move%.w %0,%4   /* save q_hi */\n\t"
             "mulu%.w %0,%1\n\t"
             "clr%.w  %0\n\t"
             "sub%.l  %1,%0   /* %0 = a - b*q_hi */\n\t" 
             "bcc     2f\n\t"
             "subq%.w #1,%4   /* decrease q_hi */\n\t"
             "swap    %3\n\t"
             "add%.l  %3,%0   /* adapt a - b*q_hi */\n\t"
             "bcs     1f      /* carry -> okay */\n\t"
             "subq%.w #1,%4   /* decrease q_hi again */\n\t"
             "add%.l  %3,%0   /* adapt a - b*q_hi again */\n"
             "1:\t"
             "swap    %3      /* reswap b */\n"
             "2:\t"
             "divu%.w %3,%0\n\t"
             "swap    %4\n\t"
             "move%.w %0,%4\n\t"
             "lsr%.l  #1,%4\n\t"
             "tst%.l  %2\n\t"
             "jpl     4f\n\t"
             "neg%.l  %4\n"
             "4:"
             : "=d" (tmp0), "=d" (tmp1), "=d" (tmp2), 
             "=d" (tmp3), "=d" (result)
             : "0" (a), "1" (b));
    return result;
}

Int32 fpsq(Int32 a)
{
    Int32 result, tmp1;
    /* make a positive and shift left */
    a = (a > 0 ? a : -a) << 1;
    __asm__ ("swap    %0\n\t      /* %0 = hi; %1 = lo */\n\t"
             "mulu%.w %0, %1      /* %2 = hi*lo */\n\t"
             "mulu%.w %0, %0\n\t"
             "clr%.w  %1\n\t"
             "swap    %1\n\t"
             "add%.l  %1, %1      /* %2 = 2*hi*lo>>16 */\n\t"
             "addq%.l #1, %1      /* round up since we omit lo*lo */\n\t"
             "add%.l  %1, %0"
             : "=d" (result), "=d" (tmp1)
             : "0" (a), "1" (a));
    return result;
}
#endif

Int32 fpsqrt(Int32 a)
{
    UInt32 dif,s;
    UInt16 r;
    int shift = 0;
    if (a <= 0)
        return 0;
    
    /* Shift a into range 1/4..1, and remember how far we shifted. */
    if (a <= (1L << 28)) {
        if (a <= (1L << 14)) {
            a <<= 16;
            shift += 8;
        }
        if (a <= (1L << 22)) {
            a <<= 8;
            shift += 4;
        }
        if (a <= (1L << 26)) {
            a <<= 4;
            shift += 2;
        }
        if (a <= (1L << 28)) {
            a <<= 2;
            shift++;
        }
    }
    
    if (a <= 0x1C71C71C)
        /* a < (1/1.5)^2, use 1/1.5 as start value:
         * r = ((1/1.5) + a / (1/1.5)) / 2 = 1/3 + 1.5 * a / 2
         *   = 1/3 + a/2 + a/4 
         */
        r = 0x2AAD + (a >> 17);
    else
        /* use 1 as start value
         * r = (1 + a / 1) / 2
         *   = 1/2 + a/2
         */
        r = 0x4001;
    r += (a >> 16);
    umulw(r,r,s);
    dif = s - a;

    /* first iteration: dif = r^2 - a \in [0..04f05ba7] */
    udivw(dif >> 1, r, s);
    dif = (dif & 1) | ((s >> 16) << 1);
    r -= s;
    umulw(s,s,s);
    dif += s;
    
    /* second iteration: dif = r^2 - a \in [0..002f73C8] */
    udivw(dif >> 1, r, s);
    dif = (dif & 1) | ((s >> 16) << 1);
    r -= s;
    umulw(s,s,s);
    dif += s;

    /* third and last iteration:  dif = r^2 - a \in [0..FFFF]*/
    udivw((dif << 14),r,s);
    return (((UInt32)r << 15) - (s & 0xffff) - 1) >> shift;
}

/* Internal sinus function, a in angle value; range -1/2 .. 1/2 
 *
 * The polynomial to approximated sin was calculated with the Remez
 * algorithm and later hand optimized.  It is exact to 31 digits (we
 * have 30).
 */
static FPSECTION Int32 fpsin_internal(Int32 a)
{
    Int32 asq;
    asq = fpsq (a);
    return fpmul(fpmul(fpmul(fpmul((asq >> 13) - 5004660
                                   , asq) + 85565180, 
                             asq) - 693598386,
                       asq) + 1686629708,
                 a);
}

/* internal cosinus function, a in angle value; range -1/2 .. 1/2 */
static FPSECTION Int32 fpcos_internal(Int32 a)
{
    Int32 asq;
    asq = fpsq (a);
    return fpmul(fpmul(fpmul((asq >> 10) - (asq >> 14) - 22404606,
                             asq) + 272376174,
                       asq) - 1324675910,
                 asq) + FP_ONE;
}

/* sinus function, a in range -2.000 .. 1.999 */
Int32 fpsin(Int32 a)
{
    if (a > FP_ONE || a < -FP_ONE)
        a = -2*FP_ONE - a;
    if (a > (FP_ONE/2))
        return fpcos_internal(FP_ONE - a);
    else if (a < (-FP_ONE/2))
        return -fpcos_internal(-FP_ONE - a);
    else
        return fpsin_internal(a);
}

/* cosinus function, a in range -2.000 .. 1.999 */
Int32 fpcos(Int32 a)
{
    if (a < 0)
        a += FP_ONE;
    else
        a = FP_ONE - a;
    if (a > (FP_ONE/2))
        return fpcos_internal(FP_ONE - a);
    else if (a < (-FP_ONE/2))
        return -fpcos_internal(-FP_ONE - a);
    else
        return fpsin_internal(a);
}

/* Calculate both sinus and cosinus function, a in range -2.000 .. 1.999 */
void fpsincos(Int32 a, Int32 *sin, Int32 *cos)
{
    Int32 v;
    switch ((a + FP_ONE/2) >> 30) {
    case -2:
        *sin = v = fpsin_internal(-2*FP_ONE - a);
        *cos = - fpsqrt(FP_ONE - fpsq(v));
        break;
    case -1:
        *cos = v = fpsin_internal( 1*FP_ONE + a);
        *sin = - fpsqrt(FP_ONE - fpsq(v));
        break;
    case  0:
        *sin = v = fpsin_internal(          + a);
        *cos = + fpsqrt(FP_ONE - fpsq(v));
        break;
    case  1:
        *cos = v = fpsin_internal( 1*FP_ONE - a);
        *sin = + fpsqrt(FP_ONE - fpsq(v));
        break;
    }
}


/* atan(.25), atan(.5), atan(.8) */
#define FP_ATAN_25 FP(.1559582608)
#define FP_ATAN_5  FP(.2951672353)
#define FP_ATAN_8  FP(.4295534250)

Int32 fpatan2(Int32 y, Int32 x)
{
    Int16 octant = 0;
    Int16 sign = 1;
    Int32 q, z, a;
    
    /* This handles the special case x == y == 0 */
    if (y == 0)
        return 0;
    
    if (y < 0) {
        y = -y;
        sign = -sign;
    }
    if (x < 0) {
        x = -x;
        octant = sign << 1;
        sign = -sign;
    }
    
    if (y > x) {
        Int32 t = x;
        x = y;
        y = t;
        octant += sign;
        sign = -sign;
    }

    /* y/x is in range 0..1.  Now we bring it in range 0..1/8 with the
     * help of addition theorems for arctan.  We keep 3 additional low
     * bits in q for good precision, and make sure that the denominator
     * doesn't overflow, especially in the last case.
     *
     *   y/x  0..1/8 1/8..3/8   3/8..5/8       5/8..1
     *
     *          y     4y - x     2y - x        5y - 4x
     *   q/8:  ---   --------   --------      ---------
     *          x     4x + y     2x + y        5x + 4y
     *
     *         8y     4y - x     4y - 2x     2.5y - 2x
     *     q:  ---  ----------  ---------- -------------
     *          x   .5x + 1/8y  .5x + .25y  5/16x + 1/4y
     *
     * a(y/x)   a    a(.25)+a    a(.5)+a   a(.8)+a
     */
    
    if (y < (x>>2)+(x>>3)) {
        if (y < (x>>3)) {
            a = 0;
            q = fpdiv(y << 3, x); 
        } else {
            a = FP_ATAN_25;
            q = fpdiv((y<<2) - x, (UInt32)(x + (y>>2)) >> 1);
        }
    } else {
        if (y < (x >> 1)+(x >> 3)) {
            a = FP_ATAN_5;
            q = fpdiv((y<<2) - (x<<1), (UInt32)(x + (y>>1)) >> 1);
        } else {
            a = FP_ATAN_8;
            q = fpdiv(((y - x) << 1) + (y>>1), 
                      (UInt32)((x >> 1) + (x >> 3) + (y >> 1)) >> 1);
        }
    }
    
    /* Now |q/8| <= 1/8 */
    z = fpsq(q) >> 6;
    
    /* The arc tan Remez approximated polynom.  It is similar to
     *   q/PI_2 - (q/PI_2)^3/3 + (q/PI_2)^5/5
     * but more accurate.
     */
    a += fpmul(fpmul(fpmul(134084000, z) - 227834680, z) + 683565236, q) >> 3;
    
    if (sign < 0)
        a = -a;
    a += ((Int32)octant << 30);
    return a;
}

/**
 * Calculate ln(a)/16.  Note that the result value is always in fixed
 * point range -2..2:
 *
 * Precondition:    0  <    a     <= 2*FP_SQRT2
 *               -1.30 < ln(a)/16 <  0.065
 */
Int32 fpln_16(UInt32 a)
{
  Int32 f,s,z;
  Int32 r = FP_LN2/16;

  /* Scale a into the handled regions and adjust result */
  if (a < (FP_SQRT2 >> 15)) {
    a <<= 16;
    r -= FP_LN2;
  }
  if (a < (FP_SQRT2 >> 7)) {
    a <<= 8;
    r -= FP_LN2/2;
  }
  if (a < (FP_SQRT2 >> 3)) {
    a <<= 4;
    r -= FP_LN2/4;
  }
  if (a < (FP_SQRT2 >> 1)) {
    a <<= 2;
    r -= FP_LN2/8;
  }
  if (a < (FP_SQRT2     )) {
    a <<= 1;
    r -= FP_LN2/16;
  }

  /* Now FP_SQRT2 <= a < 2*FP_SQRT2 and ln(orig_a) = r + ln(a/2) */
  f = a + -2*FP_ONE;
  s = fpdiv(f, (a>>2) + FP_ONE/2) >> 2;

  /* f = a - 2 and s = (a-2) / (a+2);
   * ==> ln(1+s) - ln(1-s) = ln((1+s)/(1-s)) = ln(a/2)
   *
   * We use a Remez approximated polynom to calculate for s in [-.1716,.1716]
   *   R = ln(1+s) - ln(1-s) - 2s ~= c1*s + c3*s^3 + c5*s^5
   * with c1,c3,c5 given below in fixed point.
   * R is exact to 27 bits after decimal point (we need 26).
   *
   * This gives the equation:
   *   ln(a/2) ~= 2s + R = f/2 + s*(R/s - f/2)
   */
#define c1 0x00000384
#define c3 0x2aa6f69c
#define c5 0x1a925790
  z = fpmul(s,s);
  r += ((f>>1) + fpmul(fpmul(fpmul(c5, z) + c3, z) + c1 - (f>>1), s))>>4;
#undef c1
#undef c3
#undef c5
  return r;
}

Char *
FormatGPNumber(Int32 gp, int places, char *s, UInt16 size)
{
    Char *tail;
    UInt16 round = 0x8000;
    int i;
    Boolean sign;

    for (i = 0; i < places; i++)
        round /= 10;

    gp += round;
    sign = gp < 0;
    gp = fpabs(gp);

    /* Print digits before binary point.
     */
    StrPrintF(s, "%s%d", sign ? "-" : "", GP_TRUNC(gp));

    if (places == 0)
        return s;

    /* Skip to end of string and add decimal point. */
    tail = s + StrLen(s);
    *tail++ = '.';

    /* Add digits behind decimal point */
    while (places > 0) {
        /* get frac of (positive) number */
        gp &= 0xffff;
        /* extract next digit */
        gp *= 10;
        /* add digit to string */
        *tail++ = '0' + (gp >> 16);
        
        places--;
    }
    /* close string */
    *tail = 0;
    return s;
}
