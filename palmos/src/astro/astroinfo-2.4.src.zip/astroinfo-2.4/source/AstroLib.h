/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: AstroLib.h,v 1.28 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2000, Michael Heinz
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef AstroLib_h
#define AstroLib_h

#define ALIBSECTION __attribute__ ((section ("code2")))
/*
 * Not the best place for this, but it used by a number of other files.
 *
 * Max length of all text fields
 */
#define FIELDLENGTH     32

#define ASTROLIB_DONTRISE    1
#define ASTROLIB_DONTSET     2
#define ASTROLIB_DONTRISESET 3  /* dont rise and dont set */
#define ASTROLIB_CIRCUMPOLAR 4

#define DAY 86400000
#define HALFDAY 43200000

/*
 * Returns the Julian Day.
 *
 * This formula is valid for all dates from 1 to 9999
 */
Int32
JDay(int year, int month, int day) ALIBSECTION;

/*
 * Calculate the phase of the moon and full for the current julian
 * day and time.  Result is in FP.
 *
 * phase is the angle sun-moon-earth; 0 for full moon, negative for
 * waxing, positive for waning moon.
 * full is from 0 to 1 as you would expect.
 */
void
LunarPhase(Int32 *phase, Int32 *full,
           Int32 jday, Int32 time) ALIBSECTION;

Int32 getGSTOffset(Int32 jday) ALIBSECTION;

/*
 * Convert a Julian day to GST
 */
Int32 UTCToGST(Int32 utc, Int32 gstOffset) ALIBSECTION;

/*
 * Convert a gst and longitude to LST
 * longitude is in radians.
 */
Int32 GSTToLST(Int32 gst, Int32 lng) ALIBSECTION;

/*
 * Convert GST to UTC.
 * @param gst       the GST to convert.  In fixed point angle.
 * @param gstOffset the GST offset for noon (UT) of the current julian day.
 * @param jtime     the current julian time (UT) in seconds since noon.  The
 *                  returned time is put in the "vicinity" of jtime.
 * @return The time in UTC in seconds since noon.
 */
Int32 GSTToUTC(Int32 gst, Int32 gstOffset, Int32 jtime) ALIBSECTION;

/*
 * Convert a LST and longitude to GST.
 * longitude is in radians.
 */
Int32 LSTToGST(Int32 lst, Int32 lng) ALIBSECTION;


/*
 * Convert radians to degrees, minutes, seconds
 *
 * Note that for negative values of rad, all h, m and s will be negative.
 */
void AngToDMS(Int32 rad,
              Int16 *h, Int16 *m, Int16 *s) ALIBSECTION;

/*
 * Convert radians to hours, minutes, seconds
 */
void AngToHMS(Int32 rad,
              Int16 *h, Int16 *m, Int16 *s) ALIBSECTION;

/*
 * Convert DMS to decimal degrees. Note that for negative values, the
 * assumption is that if d, m and s are all negative.
 */
Int32 DMSToAng(Int16 d, Int16 m, Int16 s) ALIBSECTION;

#if 0  /* No longer used. */
/*
 * Convert HMS to fixed point angle
 *
 * Note that the assumption is that for negative values of DMS, all
 * d, m and s are negative.
 */
Int32 HMSToAng(Int16 h, Int16 m, Int16 s) ALIBSECTION;
#endif

/*
 * Convert R.A./Dec to Alt/Az
 *
 * ra = Right Ascension, dec = Declination
 * lst = observer's Local Sidereal Time, lat = observer's Latitude
 * alt = the final altitude, az = the final azimuth.
 *
 * All values in fixed point.  Note that the three coordinates
 * correspond to x, y, z in cartesian coordinates.
 */
void RaDecToAltAz(Int32 sinlat, Int32 coslat,
		  Int32 sinlst, Int32 coslst,
		  Int32 sinracosdec, Int32 cosracosdec, 
		  Int32 sindec,
		  Int32 *sinalt, 
		  Int32 *sinazcosalt, Int32 *cosazcosalt) ALIBSECTION;

/*
 * Convert celestial co-ordinates (lat,long)
 * to right ascension and declination.
 *
 * All values in fixed point.  Note that the three coordinates
 * correspond to x, y, z in cartesian coordinates.
 */
void CelestialToRaDec(Int32 sinlat, 
		      Int32 sinlngcoslat, Int32 coslngcoslat,
		      Int32 jday,
		      Int32 *sinracosdec, Int32 *cosracosdec,
		      Int32 *sindec) ALIBSECTION;
/*
 * Return the longitude of the Sun for a given julian day.
 * If ms is !NULL then returns the mean anomoly, too.
 */
void SolarLong(Int32 jday, Int32 jtime,
	       Int32 *ms, Int32 *cosl, Int32 *sinl) ALIBSECTION;


void SolarPos(Int32 jday, Int32 jtime, 
	      Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec) ALIBSECTION;

/*
 * Calculate the rising and setting times for the given solar system
 * object at the given (local) julian day and time.  All times are in
 * milliseconds UTC since local noon; negative before noon.
 *
 * The rise/set time are matching, i.e. UTr < UTs and (UTr+UTs)/2
 * denotes zenith transition time.  The chosen rise/set pair is the one,
 * whose transition time is nearest to the given time.
 * 
 * The rise/set time can be less or greater than -HALFDAY or HALFDAY
 * denoting the previous or next day.
 *
 * The return value is 0 if everthing is okay, or a bitmask of 
 * ASTROLIB_DONTRISE, ASTROLIB_DONTSET and ASTROLIB_CIRCUMPOLAR.
 * There are some cases where an object changes from circumpolar to
 * normal, in that case it can have a valid rise but an invalid set
 * time.  This is indicated by (ASTROLIB_CIRCUMPOLAR|ASTROLIB_DONTRISE). 
 *                                              
 * @param solarID One of MOON, SUN or MERCURY..PLUTO, but not EARTH :).
 * @param jday    The julian day.
 * @param jtime   The time in milliseconds since noon of jday (UTC).
 * @param sinlat  The observers latitude (sine).
 * @param coslat  The observers latitude (cosine).
 * @param lng     The observers longitude (fixed point angle).
 * @param UTr     pointer where rise time is stored.
 * @param UTs     pointer where set time is stored.
 * @return flags to indicate if rise/set make sense (see above).
 */
int
SolObjectRiseSet(int solarID, Int32 jday, Int32 jtime,
                 Int32 sinlat, Int32 coslat, Int32 lng,
                 Int32 *UTr, Int32 *UTs) ALIBSECTION;

/*
 * Calculate the rising and setting times for the given Ra/Dec coords
 * at the given (local) julian day and time.  All times are in
 * milliseconds UTC since local noon; negative before noon.
 *
 * The rise/set time are matching, i.e. UTr < UTs and (UTr+UTs)/2
 * denotes zenith transition time.  The chosen rise/set pair is the one,
 * whose transition time is nearest to the given time.
 * 
 * The rise/set time can be less or greater than -HALFDAY or HALFDAY
 * denoting the previous or next day.
 *
 * The return value is 0 if everthing is okay, or a bitmask of 
 * ASTROLIB_DONTRISE, ASTROLIB_DONTSET and ASTROLIB_CIRCUMPOLAR.
 * There are some cases where an object changes from circumpolar to
 * normal, in that case it can have a valid rise but an invalid set
 * time.  This is indicated by (ASTROLIB_CIRCUMPOLAR|ASTROLIB_DONTRISE). 
 *                                              
 * @param jday    The julian day.
 * @param jtime   The time in milliseconds since noon of jday (UTC).
 * @param ra      The right ascension in fixed point angle
 * @param dec     The declination in fixed point angle
 * @param sinlat  The observers latitude (sine).
 * @param coslat  The observers latitude (cosine).
 * @param lng     The observers longitude (fixed point angle).
 * @param UTr     pointer where rise time is stored.
 * @param UTs     pointer where set time is stored.
 * @return flags to indicate if rise/set make sense (see above).
 */
int
StarRiseSet(Int32 jday, Int32 jtime, Int32 ra, Int32 dec,
            Int32 sinlat, Int32 coslat, Int32 lng,
            Int32 *pUTr, Int32 *pUTs);

/*
 * Lunar Position for the current date/time
 * angles in radians.  If EC is non-null
 * it will contain an estimated correction
 * for parallax.
 */
void
LunarPos(Int32 jday, Int32 jtime, Int32 *EC,
	 Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec) ALIBSECTION;

/*
 * Planet numbers
 */
#define MERCURY         0
#define VENUS           1
#define EARTH           2
#define MOON            3
#define MARS            4
#define JUPITER         5 
#define SATURN          6
#define URANUS          7
#define NEPTUNE         8
#define PLUTO           9
#define SUN             10
#define CATOBJ          11

void 
HelioPlanetPos(int planet, Int32 jday, Int32 jtime, 
	       Int32 *ms, Int32 *sinl, Int32 *cosl, Int32 *ecc) ALIBSECTION;


/*
 * Calculate the position of a planet for a given
 * julian date. Returns the right ascension and
 * declination in radians. planet is the planet number
 * listed above.
 */
void
PlanetPos(int planet, Int32 jday, Int32 jtime, 
          Int32 Ex, Int32 Ey, Int32 Er,
          Int32 *sinracosdec, Int32 *cosracosdec, Int32 *sindec, 
          Int32 *pillf, Int32 *pmag, Int32 *pgdist, 
          Int32 *psemid, Int32 *ppa) ALIBSECTION;

/*
 * Calculate the rising and setting times for the planet, the given
 * (local) julian day.  All times are in milliseconds LT, 0 for local noon,
 * negative before noon, positive after noon.
 *
 * The rise/set time can be less or greater than -HALFDAY or HALFDAY
 * if the object doesn't rises or sets on that particular day, but a
 * few minutes earlier/later.
 *
 * The return value is 0 if everthing is okay, ASTROLIB_CIRCUMPOLAR if
 * the object is always visible, ASTROLIB_NEVERUP if its not visible.
 *
 * lat and lng are the observer's position in radians.  
 * Ex, Ey is heliocentric position of earth in cartesian coordinates, with
 * Ex^2 + Ey^2 = 1.  Er is distant sun-earth in AU.
 */
int
PlanetRiseSet(int planet, Int32 jday, Int32 jtime,
              Int32 sinlat, Int32 coslat, 
              Int32 lng, Int32 gstOffset,
              Int32 *UTr, Int32 *UTs,
              Int32 Ex, Int32 Ey, Int32 Er) ALIBSECTION;

typedef struct _AstroRecord
{
    char description[32]; // max 32 chars
    short raH, raM, raS;
    short decH, decM, decS;
    char magnitude[4]; // max 4 chars
    char size[8]; // max 8 chars
} AstroRecord;

#ifdef SELFTEST
void LibTest(void);
#endif

#endif    // AstroLib_h
