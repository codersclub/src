/*
 * Astro Sky - an astronomical visualizer for PalmOS devices.
 * 
 * $Id: AstroSky.c,v 1.38 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Jochen Hoenicke
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "PalmUtil.h"
#include "resource.h"
#include "Astro.h"
#include "AstroLib.h"
#include "AstroCat.h"
#include "AstroSky.h"
#include "FixedPoint.h"

#define ASTRO_SKY_PROJ_SPH   0
#define ASTRO_SKY_PROJ_CYL   1
#define ASTRO_SKY_PROJ_CON   2

typedef struct {
    Int32 X, Y, Z;
    Int16 magnitude;
    Int16 index;
} mapped_object;

#define NO_OBJECT 65535
typedef void (*DrawObjectFunc) (Int16 mag, Int16 x, Int16 y);

// This
static int TotalSkyObjects;
static MemHandle objHandle;
/* The current lst, lat for which objHandle contains right az/alt values */
static Int32 objectLst, objectLat;

static Int16 zoom;
static UInt16 markedObject = NO_OBJECT;
static BitmapPtr bitmap = NULL;

static RectangleType skyRect;

#define SKY_WIDTH (skyRect.extent.x)
#define SKY_HEIGHT (skyRect.extent.y)
#define SKY_X (skyRect.topLeft.x)
#define SKY_Y (skyRect.topLeft.y)
#define SKY_CNTX (SKY_X + SKY_WIDTH / 2)
#define SKY_CNTY (SKY_Y + SKY_HEIGHT / 2)

#define NUM_SOLAROBJS 10 /* 8 planets + moon + sun */


#undef DEBUG_STARS

static void SkyMapDescribe(FormPtr formPtr, int objectNr) SKYSECTION;

void 
SkyMapFreeCatalog() {
    if (objHandle != NULL) {
        MemHandleFree(objHandle);
        objHandle = NULL;
    }
}

void 
SkyMapLoadCatalog() {
    FormPtr busyForm, oldForm;
    mapped_object *objects;
    UInt16 i;
    
    objectLst = 0;
    objectLat = FP_ONE;
   
    TotalSkyObjects = NUM_SOLAROBJS + GetTotalRecords();

    objHandle = MemHandleNew(sizeof(mapped_object) * TotalSkyObjects);
    if (objHandle == NULL) {
        FrmAlert(a_OOM);
        TotalSkyObjects = 0;
        return;
    }

    if (GetTotalRecords() == 0)
        return;

    busyForm = FrmInitForm(f_LoadObjects);
    oldForm = FrmGetActiveForm();
    FrmSetActiveForm(busyForm);
    FrmDrawForm(busyForm);

    /*
     * Read in the catalog objects and convert polar coords into
     * cartesian.
     */
    objects = MemHandleLock(objHandle);
    for(i = NUM_SOLAROBJS; i < TotalSkyObjects; i++) {
        Int32 sindec, cosdec, sinra, cosra;
        AstroRecordType *art;
        MemHandle handle;
        
        handle = DmQueryRecord (GetCatalogRef(), i - NUM_SOLAROBJS);
        
        // Unpack the record
        art = (AstroRecordType*) MemHandleLock(handle);
        objects[i].index = i - NUM_SOLAROBJS;
        /* XXX magnitude should be in GP16 in the catalog, this requires 
         * downloading new star catalogs though.  We should delay the
         * change until we include the type.
         */
        objects[i].magnitude = (Int16) ((art->magnitude * 256L) / 100);
        
        fpsincos(art->dec, &sindec, &cosdec);
        fpsincos(art->ra, &sinra, &cosra);
        objects[i].Z = sindec;
        objects[i].X = fpmul(sinra, cosdec);
        objects[i].Y = -fpmul(cosra, cosdec);
        MemHandleUnlock(handle);
    }
    MemHandleUnlock(objHandle);

    FrmEraseForm(busyForm);
    FrmDeleteForm(busyForm);
    FrmSetActiveForm(oldForm);
}

void
SkyMapInit (FormPtr formPtr)
{
    zoom = 24;
    
    if (CheckMinRomVersion(sysVersion33)) {
        Err err;
        bitmap = BmpCreate(SKY_WIDTH, SKY_HEIGHT, 4, NULL, &err);
    }
}

static SKYSECTION void
SkyMapRotateStars(mapped_object * objects, UInt16 start,
                  Int32 XX, Int32 XY, Int32 XZ, 
                  Int32 YX, Int32 YY, Int32 YZ,
                  Int32 ZX, Int32 ZY, Int32 ZZ)
{ 
    UInt16 i;
      
    for(i = start; i < TotalSkyObjects; i++) {
        Int32 X, Y, Z;
        X = fpmul(XX, objects[i].X)
            + fpmul(XY, objects[i].Y)
            + fpmul(XZ, objects[i].Z);
        Y = fpmul(YX, objects[i].X)
            + fpmul(YY, objects[i].Y)
            + fpmul(YZ, objects[i].Z);
        Z = fpmul(ZX, objects[i].X)
            + fpmul(ZY, objects[i].Y)
            + fpmul(ZZ, objects[i].Z);
        objects[i].X = X;
        objects[i].Y = Y;
        objects[i].Z = Z;
    }
}

/* Transform planets to the given day and time.
 * lst contains local siderean time as angle value,
 * lat contains latitude as angle value.
 */
void
SkyMapSetPosTime(FormPtr formPtr, Int32 jday, Int32 jtime, 
                 Int32 lat, Int32 lng)
{
    Int32 gst, lst, illf, mag, dist, semid, pa;
    Int32 sinlastlat, coslastlat, sinlat, coslat, sinlst, coslst;
    Int32 Ex, Ey, Er;
    Int32 sinracosdec, cosracosdec, sindec;
    Int32 XX, XY, XZ, YX, YY, YZ, ZX, ZY, ZZ;
    mapped_object *objects;
    Char text[FIELDLENGTH];
    UInt16 i;
    
    if (objHandle == NULL)
        return;

    // Show Status
    GetStringResource(s_RotateObjects, text);
    UpdateTextField(f_SkyObject, text);
    FldDrawField((FieldPtr) 
                 FrmGetObjectPtrByID(formPtr, f_SkyObject));

    gst = UTCToGST(jtime, getGSTOffset(jday));
    lst = GSTToLST(gst, lng);
    fpsincos(lat, &sinlat, &coslat);
    fpsincos(lst, &sinlst, &coslst);
    
    /* Get Position of sun, moon and planets */
    HelioPlanetPos(EARTH, jday, jtime, NULL, &Ey, &Ex, &Er);
    
    objects = MemHandleLock(objHandle);
    
    illf = mag = dist = semid = pa = 0;

    for(i = 0; i < NUM_SOLAROBJS; i++) {
        if (i == EARTH) /* Map SUN on EARTH's index */
            SolarPos(jday, jtime,
                     &sinracosdec, &cosracosdec, &sindec);
        else if (i == MOON)
            LunarPos(jday, jtime, NULL,
                     &sinracosdec, &cosracosdec, &sindec);
        else
            PlanetPos(i, jday, jtime, Ex, Ey, Er,
                      &sinracosdec, &cosracosdec, &sindec, &illf, &mag, &dist, &semid, &pa);
        
        if (!userPrefs.skyFlags.radec) {
            RaDecToAltAz(sinlat, coslat, sinlst, coslst,
                         sinracosdec, cosracosdec, sindec,
                         &objects[i].Z, 
                         &objects[i].X, &objects[i].Y);
        } else {
            objects[i].X = sinracosdec;
            objects[i].Y = -cosracosdec;
            objects[i].Z = sindec;
        }
        objects[i].index = -1;
        objects[i].magnitude = GP32TO16(mag);
    }

    if (!userPrefs.skyFlags.radec) {
        /*
         * Rotate the catalog objects
         */
        fpsincos(lst - objectLst, &sinlst, &coslst);
        fpsincos(objectLat, &sinlastlat, &coslastlat);
        fpsincos(lat, &sinlat, &coslat);
        
        /* Calculate Transformation Matrix */
        
        ZZ = fpmul(sinlastlat,sinlat) 
            + fpmul(fpmul(coslastlat, coslat), coslst);
        ZY = fpmul(coslastlat,sinlat)
            - fpmul(fpmul(sinlastlat, coslat), coslst);
        ZX = fpmul(coslat, sinlst);
        
        YZ = fpmul(sinlastlat,coslat)
            - fpmul(fpmul(coslastlat, sinlat), coslst);
        YY = fpmul(coslastlat,coslat)
            + fpmul(fpmul(sinlastlat, sinlat), coslst);
        YX = -fpmul(sinlat, sinlst);
        
        XZ = -fpmul(coslastlat,sinlst);
        XY = fpmul(sinlastlat,sinlst);
        XX = coslst;
        
        SkyMapRotateStars(objects, NUM_SOLAROBJS,
                          XX, XY, XZ, YX, YY, YZ, ZX, ZY, ZZ);
    }
    MemHandleUnlock(objHandle);
    objectLat = lat;
    objectLst = lst;
}

static SKYSECTION void SkyMapSetCoord(Boolean radec)
{
    Int32 sinlat, coslat, sinlst, coslst;
    Int32 XX, XY, XZ, YX, YY, YZ, ZX, ZY, ZZ;
    mapped_object * objects;

    fpsincos(objectLst, &sinlst, &coslst);
    fpsincos(objectLat, &sinlat, &coslat);

    if (radec == userPrefs.skyFlags.radec)
        /* No change */
        return;

    userPrefs.skyFlags.radec = radec;
    if (objHandle == NULL)
        return;
    
    if (radec) {
        /*
         * Rotate the catalog objects
         */
        ZZ = sinlat;
        ZY = coslat;
        ZX = 0;
        
        YZ = -fpmul(coslat, coslst);
        YY = fpmul(sinlat, coslst);
        YX = sinlst;
        
        XZ = fpmul(coslat, sinlst);
        XY = -fpmul(sinlat, sinlst);
        XX = coslst;
    } else {
        /*
         * Rotate the catalog objects
         */
        ZZ = sinlat;
        ZY = - fpmul(coslat, coslst);
        ZX = fpmul(coslat, sinlst);
        
        YZ = coslat;
        YY = fpmul(sinlat, coslst);
        YX = - fpmul(sinlat, sinlst);
        
        XZ = 0;
        XY = sinlst;
        XX = coslst;

    }

    objects = MemHandleLock(objHandle);
    SkyMapRotateStars(objects, 0,
                      XX, XY, XZ, YX, YY, YZ, ZX, ZY, ZZ);

    MemHandleUnlock(objHandle);
}

void
SkyMapFree ()
{
    if (bitmap)
        BmpDelete(bitmap);
}

static SKYSECTION void
MarkSkyObject(RectangleType skyRect, mapped_object *object)
{
    Int32 tx, ty, cosHAcosalt;
    RectangleType oldClip, rect;
    Int32 sinAzCnt, cosAzCnt, sinAltCnt, cosAltCnt;
    
    fpsincos(userPrefs.alt, &sinAltCnt, &cosAltCnt);
    fpsincos(userPrefs.az, &sinAzCnt, &cosAzCnt);
    
    tx = (fpmul(object->X, cosAzCnt)
          - fpmul(object->Y, sinAzCnt)) >> zoom;
    if (abs(tx) > SKY_WIDTH/2+2)
        return;
    
    cosHAcosalt = fpmul(object->Y, cosAzCnt) 
        + fpmul(object->X, sinAzCnt);
    ty = (fpmul(object->Z, cosAltCnt)
          - fpmul(cosHAcosalt, sinAltCnt)) >> zoom;
    if (abs(ty) > SKY_HEIGHT/2+2)
        return;

    WinGetClip(&oldClip);
    WinSetClip(&skyRect);
    
    RctSetRectangle(&rect, SKY_CNTX + tx - 2, SKY_CNTY - ty - 2, 5, 5);
    WinInvertRectangleFrame(rectangleFrame, &rect);

    WinSetClip(&oldClip);
}

static SKYSECTION Int16
SkyMapLimitingMag ()
{
    return GP32TO16(userPrefs.skyFlags.brightness * GP(0.5)
                    + (26 - zoom) * GP(1.0));
}

#if 0
static SKYSECTION void
SkyMapDrawCyl (Int16 skyW2, Int16 skyH2, Int16 magnitude,
               mapped_object *objects, DrawObjectFunc drawObject)
{
    UInt16 i;
    
    Boolean hasRom35, inverted, cutHoriz;
    Int32 az, alt;
    
    hasRom35 = CheckMinRomVersion(sysVersion35);
    inverted = userPrefs.skyFlags.inverse || userPrefs.optFlags.nightMode;
    cutHoriz = !(userPrefs.skyFlags.radec || userPrefs.skyFlags.horizon);
    
    az = userPrefs.az;
    alt = userPrefs.alt;
    
    /*
     * Get the cat strings
     */
    for(i=0; i < TotalSkyObjects; i++) {
        Coord x, y;
        Int32 tx, ty;
        Int32 cosHAcosalt;
        
        if (objects[i].magnitude > magnitude
            || (cutHoriz && objects[i].Z < 0))
            continue;

        tx = (X - az) >> zoom;
        if (tx > skyW2 || tx < -skyW2)
            continue;
        
        ty = (Y - alt) >> zoom;
        if (ty > skyH2 || ty < -skyH2)
            continue;

        x = skyX + tx;
        y = skyY - ty;
        
    }
}
#endif

static SKYSECTION void
SkyMapDrawSph (Int16 skyW2, Int16 skyH2, Int16 magnitude,
               mapped_object *objects, DrawObjectFunc drawObject)
{
    UInt16 i;
    Int32 sinAzCnt, cosAzCnt, sinAltCnt, cosAltCnt;
    Boolean cutHoriz = !(userPrefs.skyFlags.radec
                         || userPrefs.skyFlags.horizon);

    fpsincos(userPrefs.alt, &sinAltCnt, &cosAltCnt);
    fpsincos(userPrefs.az, &sinAzCnt, &cosAzCnt);

    /*
     * Get the cat strings
     */
    for(i=0; i < TotalSkyObjects; i++) {
        Int32 tx, ty;
        Int32 cosHAcosalt;
        
        if (objects[i].magnitude > magnitude
            || (cutHoriz && objects[i].Z < 0))
            continue;

        tx = (fpmul_fast(objects[i].X, cosAzCnt)
              - fpmul_fast(objects[i].Y, sinAzCnt)) >> zoom;
        if (tx > skyW2 || tx < -skyW2)
            continue;
        
        cosHAcosalt = fpmul_fast(objects[i].Y, cosAzCnt) 
            + fpmul_fast(objects[i].X, sinAzCnt);
        ty = (fpmul_fast(objects[i].Z, cosAltCnt)
              - fpmul_fast(cosHAcosalt, sinAltCnt)) >> zoom;
        if (ty > skyH2 || ty < -skyH2)
            continue;
        
        if (fpmul_fast(objects[i].Z, sinAltCnt)
            + fpmul_fast(cosHAcosalt, cosAltCnt) < 0)
            /* This object is on the other side of the globe, 
             * thus not visible */
            continue;
        
        if (zoom < 18) {
            tx = (fpmul(objects[i].X, cosAzCnt)
                  - fpmul(objects[i].Y, sinAzCnt)) >> zoom;
            cosHAcosalt = fpmul(objects[i].Y, cosAzCnt) 
                + fpmul(objects[i].X, sinAzCnt);
            ty = (fpmul(objects[i].Z, cosAltCnt)
                  - fpmul(cosHAcosalt, sinAltCnt)) >> zoom;
        }
        
        drawObject(objects[i].magnitude, tx, ty);
    }
}

#if 0
static SKYSECTION void
SkyMapDrawCon (Int16 skyW2, Int16 skyH2, Int16 magnitude,
               mapped_object *objects, DrawObjectFunc drawObject)
{
    UInt16 i;
    
    Boolean hasRom35, inverted, cutHoriz;
    Int32 sinAzCnt, cosAzCnt, altCnt, azCnt;
    Int32 r;
    Int16 rexp;
    
    hasRom35 = CheckMinRomVersion(sysVersion35);
    cutHoriz = !(userPrefs.skyFlags.radec || userPrefs.skyFlags.horizon);
                 
    azCnt  = userPrefs.az;
    altCnt = userPrefs.alt;
    fpsincos(altCnt, &sinAltCnt, &cosAltCnt);

    sapi = fpmul(sinAlt, PI_2)>>1;
    sapi2_6 = fpmul(fpsq(sapi), 2*FP_ONE/3);
    
    fastWinDrawLine = (void (*) (Coord, Coord, Coord, Coord))
        SysGetTrapAddress(hasRom35 ? sysTrapWinDrawPixel : sysTrapWinDrawLine);
    if (hasRom35 && useGrayScale)
        fastWinSetForeColor = (IndexedColorType (*) (IndexedColorType)) 
            SysGetTrapAddress(sysTrapWinSetForeColor);
    /*
     * Get the cat strings
     */
    for(i=0; i < TotalSkyObjects; i++) {
        Coord x, y;
        Int32 sinaz, cosaz, alt;
        Int32 d;
        Int16 octant;

        if (objects[i].magnitude > magnitude
            || (cutHoriz && objects[i].Z < 0))
            continue;

            
        alt = objects[i].Z - altCnt;
        az  = objects[i].X - azCnt;

        temp1 = (cosalt>>1) - fpmul_fast(alt, sapi);
        azsq = fpsq(az);
        temp2 = fpmul_fast(azsq, sapi2_6);
        if (temp2 > FP_ONE/6)
            continue;
        temp2 = fpmul_fast(temp1, temp2);
        tx = fpmul_fast(az, temp1 - temp2) >> (zoom-1);
        if (tx > skyW2 || -tx < skyW2)
            continue;
        ty = alt + fpmul_fast(fpmul_fast(azsq, sapi), (temp2>>1) - temp1);
        ty >>= zoom;
        if (ty > skyH2 || -tx < skyH2)
            continue;

        x = skyX + tx;
        y = skyY - ty;
    }
}
#endif

void
SkyMapDraw (FormPtr formPtr)
{
    Int16 skyX, skyY, skyW2, skyH2;
    RectangleType oldClip;
    Boolean hasRom35, scrLocked = false;
    mapped_object *objects;
    void (*fastWinPaintRectangle) (RectangleType *, UInt16);
    int magnitude = SkyMapLimitingMag();
    Boolean inverted;
    DrawObjectFunc drawObject;
    Char *bits;

    static SKYSECTION void DrawObjectBmp(Int16 mag, Int16 tx, Int16 ty) {
        int x,y;
        Char *ptr, *ptr2;

        mag = ((magnitude - mag) / GP16(0.5));
        if (mag > 3)
            mag = 3;

        tx = SKY_WIDTH/2  + tx - mag/2;
        ty = SKY_HEIGHT/2 - ty - mag/2;
        ptr = bits + ((Int32)ty * bitmap->rowBytes);
        
        for (y = 0; y <= mag; y++) {
            if (ty >= 0 && ty < SKY_HEIGHT) {
                int xoff = tx;
                int xend = tx+mag;
                if (mag >= 2 && (y == 0 || y == mag)) {
                    xoff++;
                    xend--;
                }
                ptr2 = ptr + (xoff) / 2;
                for (x = xoff; x <= xend; x++) {
                    if (x >= 0 && x < SKY_WIDTH) {
                        if (ptr2 < bits
                            || ptr2 >= bits + SKY_HEIGHT * bitmap->rowBytes) {
                            Char buffer[200];
                            StrPrintF(buffer, "Out Of Bitmap: %08lx\n"
                                      "x:%d y:%d tx:%d ty:%d",
                                      (UInt32)(ptr2-bits), x,y,tx,ty);

                            ErrFatalDisplayIf(1, buffer);
                            return;
                        }
                            
                        if ((x & 1)) {
                            if (inverted)
                                *ptr2 &= 0xf0;
                            else
                                *ptr2 |= 0x0f;
                        } else if (x == xend) {
                            if (inverted)
                                *ptr2 &= 0x0f;
                            else
                                *ptr2 |= 0xf0;
                        } else {
                            if (inverted)
                                *ptr2 &= 0x00;
                            else
                                *ptr2 |= 0xff;
                            x++;
                        }
                        ptr2++;
                    }
                }
            }
            ty++;
            ptr += bitmap->rowBytes;
        }
    }

    static SKYSECTION void DrawObject20(Int16 mag, Int16 tx, Int16 ty) {
        Coord x, y;
        RectangleType rect;

        x = skyX + tx;
        y = skyY - ty;
        
        mag = ((magnitude - mag) / GP16(0.5));
        if (mag > 3)
            mag = 3;
        if (mag < 2) {
            rect.topLeft.x = x - mag/2;
            rect.topLeft.y = y - mag/2;
            rect.extent.x = mag+1;
            rect.extent.y = mag+1;
            fastWinPaintRectangle(&rect, 0);
        } else {
            rect.topLeft.x = x - mag/2;
            rect.topLeft.y = y - mag/2+1;
            rect.extent.x = mag+1;
            rect.extent.y = mag-1;
            fastWinPaintRectangle(&rect, 0);
            rect.topLeft.x = x - mag/2+1;
            rect.topLeft.y = y - mag/2;
            rect.extent.x = mag-1;
            rect.extent.y = mag+1;
            fastWinPaintRectangle(&rect, 0);
        }
    }

    if (objHandle == NULL)
        return;
    
    skyX = SKY_CNTX;
    skyY = SKY_CNTY;
    skyW2 = SKY_WIDTH / 2;
    skyH2 = SKY_HEIGHT / 2;
    
    hasRom35 = CheckMinRomVersion(sysVersion35);
    inverted = userPrefs.skyFlags.inverse || userPrefs.optFlags.nightMode;

    fastWinPaintRectangle = (void (*) (RectangleType *, UInt16))
        SysGetTrapAddress(inverted ? sysTrapWinEraseRectangle
                          : sysTrapWinDrawRectangle);
    if (bitmap) {

        bits = (Char*) BmpGetBits(bitmap);
        drawObject = DrawObjectBmp;
        MemSet(bits, bitmap->rowBytes * SKY_HEIGHT, inverted ? 0xff : 0);

    } else {
        drawObject = DrawObject20;

        if (hasRom35) {
            scrLocked = (WinScreenLock(winLockCopy) != NULL);
            WinPushDrawState ();
        }

        if (inverted)
            WinDrawRectangle(&skyRect, 0);
        else
            WinEraseRectangle(&skyRect, 0);
    }
        
    WinGetClip(&oldClip);
    WinSetClip(&skyRect);
    objects = MemHandleLock(objHandle);
#if 0    
    switch (userPrefs.skyFlags.projection) {
    case ASTRO_SKY_PROJ_CYL:
        SkyMapDrawCyl(skyW2, skyH2, magnitude, objects, drawObject);
        break;

    case ASTRO_SKY_PROJ_SPH:
        SkyMapDrawSph(skyW2, skyH2, magnitude, objects, drawObject);
        break;

    case ASTRO_SKY_PROJ_CON:
        SkyMapDrawCon(skyW2, skyH2, magnitude, objects, drawObject);
        break;
    }
#else
    SkyMapDrawSph(skyW2, skyH2, magnitude, objects, drawObject);
#endif

    if (bitmap)
        WinDrawBitmap(bitmap, SKY_X, SKY_Y);

    MemHandleUnlock(objHandle);

    WinSetClip(&oldClip);

    SkyMapDescribe (formPtr, markedObject);

    if (hasRom35 && !bitmap) {
        WinPopDrawState ();
        if (scrLocked)
            WinScreenUnlock();
    }
}


void
SkyShift(FormPtr formPtr, int x, int y)
{
    Int32 yZoom;
    userPrefs.az -= (Int32) x << zoom;

    yZoom = (Int32) y << zoom;
    
    if (y > 0 && userPrefs.alt > FP_ONE - yZoom)
        userPrefs.alt = FP_ONE;
    else if (y < 0 && userPrefs.alt < -FP_ONE - yZoom)
        userPrefs.alt = -FP_ONE;
    else
        userPrefs.alt += yZoom;

    SkyMapDraw(formPtr);
}

void
SkyZoom(FormPtr formPtr, Boolean in)
{
    if (in) {
        if (zoom > 1)
            zoom--;
    } else {
        if (zoom < 24)
            zoom++;
    }
    SkyMapDraw(formPtr);
}

/* Find object at the given coordinates */
static SKYSECTION int
SkyMapFindObject(Coord x, Coord y)
{
    UInt16 i, objectNr;
    Int32 stx, sty, stz, tmp;
    Int32 sinalt, sinazcosalt, cosazcosalt;
    UInt32 bestDist = FP_ONE;
    mapped_object *objects;
    Int32 sinAzCnt, cosAzCnt, sinAltCnt, cosAltCnt;
    Boolean cutHoriz;
    int magnitude = SkyMapLimitingMag();

    objectNr = NO_OBJECT;
    cutHoriz = !(userPrefs.skyFlags.radec || userPrefs.skyFlags.horizon);
    
    if (objHandle == NULL)
        return objectNr;
    
    stx = (Int32) (x - SKY_CNTX) << zoom;
    sty = (Int32) (SKY_CNTY - y) << zoom;
    
    fpsincos(userPrefs.az, &sinAzCnt, &cosAzCnt);
    fpsincos(userPrefs.alt, &sinAltCnt, &cosAltCnt);
    
    tmp = FP_ONE - fpsq(stx) - fpsq(sty);
    if (tmp < 0)
        return objectNr;
    stz = fpsqrt(tmp);

    tmp = fpmul(cosAltCnt, stz) - fpmul(sinAltCnt, sty);
    sinalt = fpmul(cosAltCnt, sty) + fpmul(sinAltCnt, stz);
    sinazcosalt = fpmul(sinAzCnt, tmp) + fpmul(cosAzCnt, stx);
    cosazcosalt = fpmul(cosAzCnt, tmp) - fpmul(sinAzCnt, stx);
    
    objects = MemHandleLock(objHandle);
    
    // Mark object closest to the desired point
    for(i=0; i < TotalSkyObjects ; i++) {
        UInt32 dist;
        Int16 smag = objects[i].magnitude;
        
        if (smag > magnitude 
            || (objects[i].Z < 0 && cutHoriz))
            continue;
        if (smag < 100)
            smag = 100;
        
        dist = fpsq(objects[i].Z - sinalt)
            + fpsq(objects[i].X - sinazcosalt)
            + fpsq(objects[i].Y - cosazcosalt);
        if (dist > bestDist)
            continue;
        
        bestDist = dist;
        objectNr = i;
    }
    MemHandleUnlock(objHandle);
    return objectNr;
}

/* Describe the object at the given location. */
static SKYSECTION void
SkyMapDescribe(FormPtr formPtr, int objectNr)
{
    mapped_object *objects;

    objects = MemHandleLock(objHandle);
    
    markedObject = objectNr;
    if (markedObject < TotalSkyObjects) {
        MemHandle handle;
        Char text[FIELDLENGTH];
        AstroRecordType *art;
        
        MarkSkyObject (skyRect, &objects[markedObject]);
        
        if (markedObject < NUM_SOLAROBJS) {
            SysStringByIndex(stbl_SolarObjects, 
                             /* Map SUN on EARTH's index */
                             markedObject == EARTH ? SUN : markedObject,
                             text, FIELDLENGTH);
        } else {
            SetCurrentRecord(objects[markedObject].index);
            
            handle = DmQueryRecord (GetCatalogRef(), objects[markedObject].index);
            art = (AstroRecordType*) MemHandleLock(handle);
            StrCopy(text, art->description);
            MemHandleUnlock(handle);
        }
        UpdateTextField(f_SkyObject, text);
    } else {
        UpdateTextField(f_SkyObject, "");
    }
    FldDrawField((FieldPtr) FrmGetObjectPtrByID(formPtr, f_SkyObject));
    MemHandleUnlock(objHandle);
}

Boolean
SkyMapGadgetHandler(FormPtr formPtr, EventPtr event)
{
    static int firstX, firstY, lastX, lastY;
    Boolean handled = false;
    switch (event->eType) {
    case penDownEvent:
        lastX = firstX = event->screenX;
        lastY = firstY = event->screenY;
        handled = true;
        break;
        
    case penMoveEvent:
        if (abs(firstX - event->screenX) > 5
            || abs(firstY - event->screenY) > 5)
            firstX = -1000;
        if (abs(lastX - event->screenX) > 3
            || abs(lastY - event->screenY) > 3) {
            SkyShift(formPtr, event->screenX - lastX, event->screenY - lastY);
            lastX = event->screenX;
            lastY = event->screenY;
        }
        handled = true;
        break;
        
    case penUpEvent:
        if (abs(firstX - lastX) <= 5
                && abs(firstY - lastY) <= 5) {
            Int16 newObject = SkyMapFindObject(firstX, firstY);

            /* Select no object if the marked object was selected */
            if (newObject == markedObject)
                newObject = NO_OBJECT;

            /* Remove mark from old object */
            if (markedObject < TotalSkyObjects) {
                mapped_object *objects;
                objects = MemHandleLock(objHandle);
                MarkSkyObject(skyRect, &objects[markedObject]);
                MemHandleUnlock(objHandle);
            }
            
            /* Mark and describe new object */
            SkyMapDescribe (formPtr, newObject);
        }
        handled = true;
        break;
        
    default:
    }
    return handled;
}


/*
 * Events for the sky view form
 */
Boolean
SkyFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    static Boolean grabbedPen = false;
    FormPtr formPtr = FrmGetActiveForm();
    UInt16 gadgetIndex;
    RectangleType rect;

    if (DateChangeHandleEvent(event)
        || FormChangeHandleEvent(event))
        return true;

    switch (event->eType) {
    case ctlSelectEvent:
        /* Process various button clicks. */
        switch (event->data.ctlSelect.controlID) {
        case b_Option:
            FrmPopupForm(f_SkyOptions);
            handled = true;
            break;

        case b_Info:
            if (markedObject < NUM_SOLAROBJS) {
                SetDetailObjectType
                    (markedObject == EARTH ? SUN : markedObject);
                FrmGotoForm(f_ObjectDetail);
            } else {
                SetDetailObjectType(CATOBJ);
                FrmGotoForm(f_ObjectDetail);
            }
            handled = true;
            break;
        case b_ZoomIn:
            SkyZoom(formPtr, true);
            handled = true;
            break;
        case b_ZoomOut:
            SkyZoom(formPtr, false);
            handled = true;
            break;
        }
        break;

        case keyDownEvent:
        switch (event->data.keyDown.chr) {
        case vchrPageUp:
            SkyZoom(formPtr, true);
            handled = true;
            break;
        case vchrPageDown:
            SkyZoom(formPtr, false);
            handled = true;
            break;
        }
        break;

    case penDownEvent:
        gadgetIndex = FrmGetObjectIndex(formPtr, f_SkyGadget);
        FrmGetObjectBounds(formPtr, gadgetIndex, &rect);
        if (RctPtInRectangle (event->screenX, event->screenY, &rect))
            grabbedPen = true;
        /* fall through */
    case penMoveEvent:
    case penUpEvent:
        if (grabbedPen) {
            handled = SkyMapGadgetHandler(formPtr, event);
            if (event->eType == penUpEvent)
                grabbedPen = false;
        }
        break;
        
    case frmOpenEvent:
        FrmSetMenu(formPtr,mainMenu);            
        
        FrmDrawForm(formPtr);
    
        FrmGetObjectBounds(formPtr, FrmGetObjectIndex(formPtr, f_SkyGadget),
                           &skyRect);

        DrawDatePicker();
        DrawTimePicker();
        
        SkyMapInit (formPtr);
        SkyMapSetPosTime (formPtr, currentJDay, currentJTime, 
                          userPrefs.lat, userPrefs.lng);
        switch (userPrefs.currentObj) {
        case SUN:
            markedObject = EARTH;  /* Map SUN to EARTH */
            break;
        case CATOBJ:
            markedObject = NUM_SOLAROBJS + GetCurrentRecord();
            break;
        default:
            markedObject = userPrefs.currentObj;
            break;
        }
        SkyMapDraw (formPtr);

        if (GetTotalRecords() == 0) {
            /* Warn the user */
            FrmAlert(a_NoCatalog);
        }

        handled = true;
        break;
        
    case frmUpdateEvent:
        FrmDrawForm(formPtr);
        if (event->data.frmUpdate.updateCode == updateDateChanged)
            SkyMapSetPosTime (formPtr, currentJDay, currentJTime, 
                              userPrefs.lat, userPrefs.lng);
        SkyMapDraw (formPtr);
        handled = true;
        break;
        
    case frmCloseEvent:
        SkyMapFree ();
        handled = false;
        break;
        
        
    default:
    }
  
    return handled;
}

/*
 * Events for the sky view form
 */
Boolean
SkyOptionsFormHandleEvent(EventPtr event)
{
    Boolean handled = false;
    FormPtr  formPtr = FrmGetActiveForm();
    
    switch (event->eType) {
    case ctlSelectEvent:
        /* Process various button clicks. */
        switch (event->data.ctlSelect.controlID) {
        case b_OK:
            SkyMapSetCoord(GetControlValue(p_radec));

            if (GetControlValue(p_sph))
                userPrefs.skyFlags.projection = ASTRO_SKY_PROJ_SPH;
            else if (GetControlValue(p_cyl))
                userPrefs.skyFlags.projection = ASTRO_SKY_PROJ_CYL;
            else if (GetControlValue(p_con))
                userPrefs.skyFlags.projection = ASTRO_SKY_PROJ_CON;

            userPrefs.skyFlags.horizon = GetControlValue(c_horizon);

            userPrefs.skyFlags.inverse = GetControlValue(c_inverse);

            userPrefs.skyFlags.constell = 
                GetControlValue(c_const);

            if (GetControlValue(p_br1))
                userPrefs.skyFlags.brightness = 0;
            else if (GetControlValue(p_br2))
                userPrefs.skyFlags.brightness = 1;
            else if (GetControlValue(p_br3))
                userPrefs.skyFlags.brightness = 2;
            else if (GetControlValue(p_br4))
                userPrefs.skyFlags.brightness = 3;
            else if (GetControlValue(p_br5))
                userPrefs.skyFlags.brightness = 4;
            else if (GetControlValue(p_br6))
                userPrefs.skyFlags.brightness = 5;

            FrmReturnToForm(0);
            FrmUpdateForm(f_Sky, updateDateChanged);
            handled = true;
            break;
        case b_Cancel:
            FrmReturnToForm(0);
            handled = true;
            break;
        }
        break;
        
    case frmOpenEvent:
        SetControlValue(p_radec, userPrefs.skyFlags.radec);
        SetControlValue(p_altaz, !userPrefs.skyFlags.radec);

        SetControlValue(p_sph, userPrefs.skyFlags.projection == ASTRO_SKY_PROJ_SPH);
        SetControlValue(p_cyl, userPrefs.skyFlags.projection == ASTRO_SKY_PROJ_CYL);
        SetControlValue(p_con, userPrefs.skyFlags.projection == ASTRO_SKY_PROJ_CON);
        SetControlValue(c_horizon, userPrefs.skyFlags.horizon);
        SetControlValue(c_inverse, userPrefs.skyFlags.inverse);
        SetControlValue(c_const, userPrefs.skyFlags.constell);

        SetControlValue(p_br1, userPrefs.skyFlags.brightness == 0);
        SetControlValue(p_br2, userPrefs.skyFlags.brightness == 1);
        SetControlValue(p_br3, userPrefs.skyFlags.brightness == 2);
        SetControlValue(p_br4, userPrefs.skyFlags.brightness == 3);
        SetControlValue(p_br5, userPrefs.skyFlags.brightness == 4);
        SetControlValue(p_br6, userPrefs.skyFlags.brightness == 5);

        FrmDrawForm(formPtr);
        handled = true;
        break;
        
    default:
    }
    
    return handled;
}
