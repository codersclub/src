/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: Astro.h,v 1.58 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef Astro_h
#define Astro_h

#include "AstroDST.h"

/* width of a moon pixel in frac. MOONPIXEL = FP_ONE / 25 */
#define MOONPIXEL 42949673L

typedef struct {
    UInt16 projection : 2;
    UInt16 radec      : 1;
    UInt16 inverse    : 1;
    UInt16 horizon    : 1;
    UInt16 constell   : 1;
    UInt16 brightness : 3;
} AstroSkyFlags;

typedef struct {
    Int16 minValue : 4;
    Int16 maxValue : 4;
    Int16 value    : 4;
    Int16 reserved : 4;
} RockerType;

/* Function of the pageBtn. */
#define PAGEBTNROCKER  0
#define PAGEBTNOBJECT  1
#define PAGEBTNDATE    2

/* Application Preferences
 *
 * Be careful when changing this, as the user doesn't like loosing his
 * preferences.  Best ask me <hoenicke@users.sourceforge.net> if the
 * change is okay.
 *
 * You may safely add new fields to the end, but think twice if its
 * really a preference before adding a field as this structure should
 * remain clean.
 * 
 * If you change something early in the structure user looses
 * preferences when upgrading so don't do it.
 *
 * If you change something at the end user will loose preferences on
 * downgrading, which is not as bad.
 */
typedef struct {
    UInt16              version;       // validates the prefs structure
    UInt16              dstRuleNr;     // Number for current DST Rule.
    Int32               tz;            // timezone in minutes relative to UTC.
    Int32               lat, lng;      // lat/lng 
    Int32               alt, az;       // last visited alt/az
    DSTRule             dstRule;

    /* If you change anything above increase version number to 1024.
     * The user will loose all his preferences when up- or downgrading.
     */

    Boolean             isNow;         // Set time to now.
    UInt8               pad0;          // defaults to zero
    DateTimeType        currentDT;     // currently selected date/time.

    AstroSkyFlags       skyFlags;
    struct {
        /* These flags default to one */
        UInt16 time24Hour      : 1;
        UInt16 moreAccurate    : 1;  /* provide more details and accuracy */
        UInt16 blackBackground : 1;
        UInt16 showImage       : 1;
        UInt16 reservedOne     : 4;  /* Don't forget to adapt defaultPrefs
                                      * when adding new flags */
        /* These flags default to zero */
        UInt16 nightMode       : 1;
        UInt16 reservedZero    : 7;
    } optFlags;

    /* R3: Some of the above options will probably change and be per solar
     * object???
     */
    UInt8   pageBtnFunction;
    UInt8   pad1;

    /* Remember which object we had selected when returning to detail
     * screen.  This is purposely 32 bit; in future this should also
     * be able to address a catalog object.
     */
    UInt32  currentObj;

    /* If you change anything above adapt ASTROCOMPSIZE() below.
     */


    UInt16  activeFormId;  // The page we were on last time

    UInt16  catCardNo;     // The RAM bank containing the catalog.
    Char    catDbName[33]; // The name of the most recent catalog.

    /* The page of our lightweight scrollbar/toggle. */
    UInt8 PlanetDetailRocker, MoonDetailRocker,
          SolarDetailRocker, CatObjDetailRocker;
    
    /* Add new fields always to the end.  Don't forget to change the
     * defaultPrefs in Astro.c.  The prefs mechanism will always fill
     * new fields with their default value so normally you don't
     * change the ASTROVERSION.
     */
} UserPrefsType;

/* The following constant needs to be incremented everytime something
 * changes in the format of the userPrefs data.  This constant is written
 * to the saved preferences, allowing us to verify that they are not 
 * obsolete when we start.  (see the UserPrefsType, above.)
 *
 * It should also be incremented if the number of detail pages for an
 * object DECREASES to ensure current page is reset below max.
 */
#define ASTROVERSION   144

/* This is the version number when the core options changed.  These
 * are the most important options such as location and time zone and
 * shouldn't be changed as often as the other parts.
 *
 * Everytime it changes the user has to reconfigure AstroInfo for his
 * location again, so don't change it unnecessarily.
 */
#define SIZEUPTO(type,field) ((UInt16) (&((type*)NULL)->field + 1))
#define ASTROCOMPSIZE(v) \
    v < 115          ? 0 : \
    v < 144          ? SIZEUPTO(UserPrefsType, az) : \
    v < ASTROVERSION ? SIZEUPTO(UserPrefsType, currentObj) : \
    v < 1024         ? SIZEUPTO(UserPrefsType, dstRule) : \
    /* Grmpf, Astro-2.3.1 has its version number in the high bits. */ \
    v >= 115*256U && v < 144*256U ? SIZEUPTO(UserPrefsType, az) : 0


/* Catalog AppInfo */
typedef struct {
    UInt16              numRecords;
    UInt16              currRecord;
} AstroAppInfoType;

/* Catalog Record Type */
typedef struct {
    Int32  ra;
    Int32  dec;
    Int16  magnitude;
    Int16  sizex;
    Int16  sizey;
    Char   description[32];
// R3    UInt16    type;
} AstroRecordType;

// R3 constants for type in AstroRecordType

/* AstroRecordType.type: 
 * Most significant 8 bits are type, the other are subtype.
 * subtype 0 means it is unknown/unspecified.
 */
#define typeUnknown             0

#define typeStar                (1 << 8)
#define typeSingleStar          (typeStar+1)
#define typeDoubleStar          (typeStar+2)
#define typeMultipleStar        (typeStar+3)

#define typeCluster             (2 << 8)
#define typeOpenCluster         (typeCluster+1)
#define typeGlobularCluster     (typeCluster+2)
#define typeAsterism            (typeCluster+3)

#define typeNebula              (3 << 8)
#define typeEmissionNebula      (typeNebula+1)
#define typeReflectionNebula    (typeNebula+2)
#define typeDarkNebula          (typeNebula+3)
#define typePlanetaryNebula     (typeNebula+4)
#define typeDiffuseNebula       (typeNebula+5)

#define typeGalaxy              (4 << 8)
#define typePlanet              (5 << 8)
#define typeSuperType(x)        ((x) & 0xff00)

#define ASTRODBTYPE    'DATA'

// Flags used to send events

#define updateRedraw        0
#define updateDateChanged   1
#define updateDetailChanged 2
#define updateObjectListChanged 3

/*
 * Needed by other code sections
 */
extern UserPrefsType userPrefs;
extern UInt16 mainMenu;
extern UInt32 currentJDay;
extern UInt32 currentJTime;

/*
 * Various functions related to updating the Astro Info GUI.
 */
void DrawDatePicker(void);
void DrawTimePicker(void);
void NightMode(void);

// Wouldn't have to prototype these here if we could suck the drawing code out of Astrocat.c.
Boolean DateChangeHandleEvent(EventPtr event);
Boolean FormChangeHandleEvent(EventPtr event);
Boolean RockerChangeHandleEvent(EventPtr event);

//void UpdateTimeField(FieldPtr fld, Int32 time);

void UpdateTextField(UInt16 objid, char *t);
Int16 GetControlValue(UInt16 objid);

Char * GetStringResource(UInt16 stringid, Char *buffer);

void UpdateControlLabel(UInt16 objid, Char *t);
void SetControlValue(UInt16 objid, Int16 num);

int  GetCurrentObject(void);
void SetDetailObjectType(int num);

int UpNow(int flags, Int32 rise, Int32 set, Int32 now);

/* Columns in display for detail scroller. */

#define DetailC1 30
#define DetailC2 105
/*
 * Converts hms to floating point hours. 
 */
#define doubletime(h, m, s) (h + m / 60.0 + s / 3600.0)
#define inttime(h, m) (h * 60 + m)

#define MIN(x,y) ((x)<(y)?(x):(y))
#define MAX(x,y) ((x)>(y)?(x):(y))

#endif
