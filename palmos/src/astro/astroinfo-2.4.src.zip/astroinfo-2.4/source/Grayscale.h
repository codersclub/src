/*
 * Astro Sky - an astronomical visualizer for PalmOS devices.
 * 
 * $Id: Grayscale.h,v 1.3 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Jochen Hoenicke
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef Grayscale_h
#define Grayscale_h

/* True if gray scale or color mode is enabled. */
extern Boolean grayscaleSupport;
extern Boolean colorSupport;

/* Enable Graphics mode, if Palm supports it. */
void EnableGraphicsMode (void);

/* Close Graphics mode. */
void DisableGraphicsMode (void);

#endif
