/*
 * Astro Sky - an astronomical visualizer for PalmOS devices.
 * 
 * $Id: AstroSky.h,v 1.10 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef AstroSky_h
#define AstroSky_h

#define SKYSECTION __attribute__ ((section ("code2")))

/* Read in the object catalog and set variables */
void SkyMapInit (FormPtr formPtr) SKYSECTION;

/* Set position and time */
void SkyMapSetPosTime(FormPtr formPtr, Int32 jday, Int32 jtime, 
                      Int32 lat, Int32 lng) SKYSECTION;

/* Free the star catalog */
void SkyMapFree (void) SKYSECTION;

/* Redraw the sky. */
void SkyMapDraw (FormPtr formPtr) SKYSECTION;

/* Zoom in/out. */
void SkyZoom(FormPtr formPtr, Boolean in) SKYSECTION;

/* Rotate the sky and redraw. */
void SkyShift(FormPtr formPtr, int x, int y) SKYSECTION;

/* Handle a SkyMap event */
Boolean SkyMapGadgetHandler(FormPtr formPtr, EventPtr event) SKYSECTION;

/* Handle a event on the Sky Map form */
Boolean SkyFormHandleEvent(EventPtr event) SKYSECTION;

/* Handle a event on the Sky Options form */
Boolean SkyOptionsFormHandleEvent(EventPtr event) SKYSECTION;

/* Load in current catalog and convert coordinates to cartesian. */
void SkyMapLoadCatalog(void) SKYSECTION;
void SkyMapFreeCatalog(void) SKYSECTION;


#endif
