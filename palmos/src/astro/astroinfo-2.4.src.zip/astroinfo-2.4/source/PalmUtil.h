/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: PalmUtil.h,v 1.6 2001/11/30 23:38:24 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef PalmUtil_h
#define PalmUtil_h


#include <PalmOS.h>

// Some basic ROM versions
#define sysVersion10	sysMakeROMVersion(1,0,0,sysROMStageRelease,0)
#define sysVersion20	sysMakeROMVersion(2,0,0,sysROMStageRelease,0)
#define sysVersion30	sysMakeROMVersion(3,0,0,sysROMStageRelease,0)
#define sysVersion31	sysMakeROMVersion(3,1,0,sysROMStageRelease,0)
#define sysVersion33	sysMakeROMVersion(3,3,0,sysROMStageRelease,0)
#define sysVersion35	sysMakeROMVersion(3,5,0,sysROMStageRelease,0)
#define sysVersion40	sysMakeROMVersion(4,0,0,sysROMStageRelease,0)

// For writing to databases.
#define offsetof(type, member) (UInt32)&(((type *)0)->member)

/*
 * Returns true if the ROM version is at least
 * minVersion.
 */
Boolean CheckMinRomVersion(UInt32 minVersion);

/*
 * Retrieve the current value of a field.
 * formPtr = the form containing the field.
 * id = the resource # of the field.
 * Returns the integer value of the field.
 */
int GetNumField(FormPtr formPtr, UInt16 id);

/*
 * Convert a double to a string.
 * s = destination string
 * d = number to convert
 * p = # of digits to the right of the decimal.
 * l = the maximum length of s.
 */
void StrDToA(char *s, double d, int p, int l);

typedef struct _DBRecord 
{
    char       name[33];
    UInt16     cardNo;
    LocalID    dbID;
} DBRecord;

DBRecord **GetDBList(UInt32 type, UInt32 creator, int *count);
void FreeDBList(DBRecord **recordList, int count);

void GotoApplication(UInt32 ApplId);
void *FrmGetObjectPtrByID(FormPtr formPtr, UInt16 objid);
/* Align form object horizontally. */
void  FrmAlignObjectAt(FormPtr formPtr, UInt16 objid, 
                       int position, JustificationType align);



#endif    // PalmUtil_h

