/*
 * FixedPoint - calculations in fixed points for PalmOS devices.
 * 
 * $Id: FixedPoint.h,v 1.6 2001/11/10 18:40:28 hoenicke Exp $
 * Copyright (C) 2001, Jochen Hoenicke
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef FixedPoint_h
#define FixedPoint_h

#include <PalmOS.h>

#define FPSECTION __attribute__ ((section ("code2")))

/*
 * We use two kinds of fixed points.  The most important are 2+30
 * fixed points (which we often abbreviate as FP).
 * 
 * 2+30 means two binary digits (including sign) before point, 30
 * digits after.  The value of a fixed point number n is (n / 2^30).
 * The range of the fixed point is [-2.000 .. 1.999].
 *
 * The angles are neither in radians nor in degree.  Instead they are
 * in the above range.  So the angles are represented like this:
 * 
 *   0 degree =  0.0
 *  90 degree =  1.0
 * 180 degree = -2.0
 * 270 degree = -1.0
 *
 * The fpmul/fpsq/fpdiv functions only work for number in range [-1.0 .. 1.0]
 * There are no fpadd/fpsub functions, since you can use +/-.
 *
 ************************************
 * 
 * Since it is often inconvenient to hold values in range -2..1.999,
 * we allow a kind of fixed points, general purpose fixed points
 * (abbreviated as GP).  These are 16+16 bit nubmers;  their range is
 * -32768..32767.  
 *
 * There is a 16 bit variant (8+8) called GP16 which should only be
 * used in arrays or databases where we want to spare some bits.
 */

/* The number 1 in FP */
#define FP_ONE    (0x40000000)

/* Convert double to fixed point.  Use this only for constant values!
 * You should give 10 decimal digits after decimal point.
 */
#define FP(d) ((Int32) ((d) * FP_ONE + 0.5))

/* Some more or less important numbers */
#define FP_PI_2  FP(3.1415926536/2)
#define FP_2_PI  FP(2/3.1415926536)
#define FP_SQRT2 FP(1.4142135623)
#define FP_LN2   FP( .6931471806)

/* The number 1 in GP and GP16 */
#define GP_ONE    (0x00010000L)

/* Some conversion functions */
#define GP(d)      ((Int32) ((d) * GP_ONE + .5))
#define FPTOGP(f)  (((f) + 0x2000) >> 14)
#define GPTOFP(f)  ((f) << 14)
#define GP_ROUND(g) ((Int16) (((g) + GP(.5)) >> 16))
#define GP_TRUNC(g) ((Int16) ((g) >> 16))

/* GP16 numbers and conversion functions */
#define GP16_ONE    (0x0100)
#define GP16(d)     ((Int16) ((d) * GP16_ONE + .5))
#define GP16TO32(g) ((Int32) (g) << 8)
#define GP32TO16(g) ((Int16) ((g+0x80) >> 8))

extern Int32 fpmul (Int32 a, Int32 b) FPSECTION;
extern Int32 fpdiv (Int32 a, Int32 b) FPSECTION;
extern Int32 fpsq (Int32 a) FPSECTION;
extern Int32 fpsqrt (Int32 a) FPSECTION;
extern Int32 fpsin (Int32 a) FPSECTION;
extern Int32 fpcos (Int32 a) FPSECTION;
extern void  fpsincos (Int32 a, Int32 *sin, Int32 *cos) FPSECTION;
extern Int32 fpatan2 (Int32 y, Int32 x) FPSECTION;
extern Int32 fpln_16 (UInt32 a) FPSECTION;

static __inline__ Int32 fpabs(Int32 a)
{
    return a >= 0 ? a : -a;
}

/* Pass in GP value, number of decimals places, a buffer to return the
 * value and the buffer size.  
 */
char *FormatGPNumber(Int32 num, int places, char *s, UInt16 size) FPSECTION;


/* The fpxxx_fast routines are only exact to 2+14 bits. */

#ifdef NO_ASSEMBLER

static __inline__ Int32 fpmul_fast(Int32 a, Int32 b)
{
    return (a>>15) * (b>>15);
}
static __inline__ Int32 fpsq_fast(Int32 a)
{
    return fpmul_fast(a, a);
}

#else /* ! NO_ASSEMBLER */

static __inline__ Int32 fpmul_fast(Int32 a, Int32 b)
{
    Int32 result, tmp1;
    __asm__ ("swap    %1          /* %1 = high(b) */\n\t"
             "swap    %0          /* %0 = high(a) */\n\t"
             "muls%.w %1,%0       /* %0 = high(b) * high(a) */\n\t"
             "asl%.l  #2,%0"
             : "=d" (result), "=d" (tmp1)
             : "0" (a), "1" (b));
    return result;
}

static __inline__ Int32 fpsq_fast(Int32 a)
{
    Int32 result;
    __asm__ ("add%.l  %0,%0\n\t"
             "swap    %0\n\t"
             "muls%.w %0,%0\n\t"
             : "=d" (result) : "0" (a));
    return result;
}

#endif

#endif
