/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: constants.h,v 1.9 2001/11/22 21:55:21 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef constants_h
#define constants_h

/*
 * EPOCH is 1990.
 */
#define EPOCH   2447891

/*
 * Estimated index of refraction for things on the horizon
 */
#define IOR_EST 0x672895

/*
 * Solar constants
 */
 
/* Angular diameter at r = r0 */
#define SOLAR_A         0x610d91

/* geocentric parallax */
#define SOLAR_P         0x71d7

/*
 * Lunar constants
 */

/* Mean Longitude at epoch */
#define MOON_L0 FP(318.351648 / 90)
/* Mean Longitude of the perigee at epoch */
#define MOON_P0 FP(36.340410 / 90)

/* Mean Longitude of the node at epoch */
#define MOON_N0 FP(318.510107 / 90)

/* Inclination of the moon's orbit */
#define MOON_I  FP(5.145396 / 90)

/* Eccentricity of the moon's orbit */
#define MOON_E  FP(.0549)

/* Semi-Major Axis of the Moon's Orbit */
/*#define MOON_U  384401 km*/

/* Moon's Angular size at distance U from Earth */
#define MOON_A  FP(0.5181 / 90)

/* Parallax at distance U from Earth: */
#define MOON_P  FP(0.9507 / 90)

#endif // constants_h
