/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: AstroCat.h,v 1.13 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#ifndef AstroCat_h
#define AstroCat_h

#include <PalmOS.h>

#define DBSECTION __attribute__ ((section ("code2")))

Boolean CatObjDetailFormHandleEvent(EventPtr event) DBSECTION;
Boolean FindObjectFormHandleEvent(EventPtr event) DBSECTION;
Boolean SelectCatalogFormHandleEvent(EventPtr event); // DBSECTION;
Boolean CatalogFormHandleEvent(EventPtr event) DBSECTION;

void OpenCatalog(void) DBSECTION;
void FreeCatalog(void) DBSECTION;
void LoadObject(FormPtr formPtr) DBSECTION;
void FindObject(UInt16 start) DBSECTION;

DmOpenRef GetCatalogRef(void) DBSECTION;
LocalID GetCatalogID(void) DBSECTION;
UInt16 GetCurrentRecord(void) DBSECTION;
UInt16 SetCurrentRecord(UInt16 num) DBSECTION;
UInt16 GetTotalRecords(void) DBSECTION;
UInt16 SetTotalRecords(UInt16 num) DBSECTION;
void GetCurrentStar(AstroRecordType *art) DBSECTION;
#endif

