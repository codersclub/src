/*
 * Astro Info - a an astronomical calculator/almanac for PalmOS devices.
 * 
 * $Id: PalmUtil.c,v 1.8 2001/12/02 17:32:02 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <PalmOS.h>
#include "PalmUtil.h"

/*
 * Returns true if the ROM version is at least
 * minVersion.
 */
Boolean CheckMinRomVersion(UInt32 minVersion)
{
    UInt32 romVersion;
    
    FtrGet(sysFtrCreator,
           sysFtrNumROMVersion,
           &romVersion);

    return (minVersion <= romVersion);
}

void *
FrmGetObjectPtrByID(FormPtr formPtr, UInt16 objid)
{
    return (FieldPtr) FrmGetObjectPtr(formPtr, 
                                      FrmGetObjectIndex(formPtr, objid));
}

/* Retrieve the current value of a field. */
int GetNumField(FormPtr formPtr, UInt16 id)
{ 
    int value;
    FieldPtr fld = (FieldPtr) FrmGetObjectPtrByID(formPtr, id);
    value = StrAToI(FldGetTextPtr(fld));
    return value;
}

/* Align form object horizontally. */
void
FrmAlignObjectAt(FormPtr formPtr, UInt16 objid, int position, JustificationType align)
{
    UInt16  objIndex = FrmGetObjectIndex(formPtr, objid);
    RectangleType   rect;
    
    FrmGetObjectBounds(formPtr, objIndex, &rect);
    
    FrmHideObject(formPtr, objIndex);
    FrmSetObjectPosition(formPtr, objIndex,
                         position + (align == leftAlign ? 0 : -(rect.extent.x / ((align == centerAlign) ? 2 : 1))),
                         rect.topLeft.y);
    FrmShowObject(formPtr, objIndex);
}

#define MAXDBRECORDS 16

DBRecord**
GetDBList(UInt32 type,
          UInt32 creator,
          int *count) 
{
    Err error;
    Boolean newSearch = 1;
    
    DmSearchStateType* state = (DmSearchStateType*)MemPtrNew(sizeof(DmSearchStateType));
    DBRecord** recordList = (DBRecord**)MemPtrNew(sizeof(DBRecord*)*MAXDBRECORDS);

    *count = 0;
    while (*count < MAXDBRECORDS) 
    {
        DBRecord* record = MemPtrNew(sizeof(DBRecord));
        recordList[*count] = record;
        
        error = DmGetNextDatabaseByTypeCreator(newSearch,
                                               state,
                                               type,
                                               creator,
                                               0,
                                               &(record->cardNo),
                                               &(record->dbID));
        if (error) 
        {
            MemPtrFree(record);
            break;
        }

        error = DmDatabaseInfo(record->cardNo,
                               record->dbID,
                               record->name,
                               NULL, NULL, NULL,NULL,
                               NULL, NULL, NULL, NULL,
                               NULL, NULL);
        if (error)
        {
            MemPtrFree(record);
            break;
        }
                               
        newSearch = 0;
        (*count)++;
    }
    
    MemPtrFree(state);
    
    if ((*count) == 0) 
    {
        FreeDBList(recordList,0);
        return NULL;
    }
    
    return recordList;
}

void
FreeDBList(DBRecord **recordList, int count)
{
    int i;
    for (i=0; i < count; i++) 
    {
        DBRecord *record = recordList[i];
        MemPtrFree(record);
    }
    MemPtrFree(recordList);
}

void
GotoApplication(UInt32 ApplId) 
{
    Err err;
    UInt16 cardNo;
    LocalID dbID;
    DmSearchStateType dss;

    /*
     * Bounce the application
     */
    err = DmGetNextDatabaseByTypeCreator(true,
                                         &dss,
                                         sysFileTApplication,
                                         ApplId,
                                         true,
                                         &cardNo,
                                         &dbID);
    ErrFatalDisplayIf(err != errNone,"Failed to launch application!");
    
    SysUIAppSwitch(cardNo,dbID,
                   sysAppLaunchCmdNormalLaunch,
                   NULL);
}
