/*
 * Astro DST - Daylight Savings for AstroInfo.
 * 
 * $Id: AstroDST.h,v 1.6 2001/12/02 17:32:01 hoenicke Exp $
 * Copyright (C) 2001, Astro Info SourceForge Project
 * 
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */
#ifndef Astro_DST_h
#define Astro_DST_h

#define ASTRODSTDBTYPE    'DST0'

typedef struct _DSTRule {
    /* Strange ordering, but we want to save every bit :) */

    UInt16   startTime  : 12;  /* Start Time in standard time (or UTC)
                                * in minutes since midnight */
    UInt16   startMon   :  4;  /* Start Month, 1=Jan .. 12 = Dec */

    UInt16   endTime    : 12;  /* End Time */
    UInt16   endMon     :  4;  /* End Month */

    UInt16   isUTC      :  1;  /* 1 if start/end time are in UTC */
    UInt16   startDOW   :  3;  /* Start day of week
                                * 0=Sun..6=Sat, 7=exact date */
    Int16    startDay   :  6;  /* Start day - earliest day of change,
                                * may be 0 or negative to count from
                                * the end of the previous month.
                                */
    Int16    endDay     :  6;  /* End day */

    UInt16   endDOW     :  3;  /* End day of week */
    UInt16   savings    : 13;  /* Amount of day light savings in minutes 
                                * 0 means no day light savings at all.
                                */
} DSTRule;

typedef struct _DSTRecord {
    Char    name[16];
    DSTRule rule; 
} DSTRecord;


Int32
getDSTOffset(Int32 jday, Int32 jtime, Int32 tz, DSTRule *dst);

UInt16
OpenDSTRules(void);

void
CloseDSTRules(void);

void 
SetDSTRule(Int16 itemNum, DSTRule *rule);

void
GetDSTName(Int16 itemNum, Char *dstRuleName);

void
DSTListDrawData(Int16 itemNum, RectangleType *bounds, Char **itemsText);

#ifdef SELFTEST
void DSTTest(void);
#endif

#endif
