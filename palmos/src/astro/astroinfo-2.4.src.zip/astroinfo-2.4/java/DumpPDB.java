import palmutils.pdb.*;
import java.io.*;

public class DumpPDB 
{
    static public void main(String args[]) throws IOException
    {
        FileInputStream fis = new FileInputStream(args[0]);
        DataInputStream dis = new DataInputStream(fis);

        DatabaseHeader dbh = new DatabaseHeader(dis);
        System.out.println(dbh.toString());
        
        RecordIndex ri = new RecordIndex(dis);
        System.out.println(ri.toString());

        AstroAppInfo aai = new AstroAppInfo(dis);
        System.out.println(aai.toString());

        for (int i=0;i<aai.numRecords;i++) 
        {
            AstroRecord ar = new AstroRecord(dis);
            System.out.println(ar.toString());
        }
        
    }
}

