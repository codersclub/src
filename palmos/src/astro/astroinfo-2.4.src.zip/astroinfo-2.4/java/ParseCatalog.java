import palmutils.pdb.*;
import java.io.*;
import java.util.*;

class CatalogRecord
{
    String harvardRevisedNumber; // 1-4
    String name; // 5-11
    String constellation; //12-14
    String saoCatalog; // 32-37
    String raH2000; //76-77
    String raM2000; //78-79
    String raS2000; //80-83
    String decH2000; //84-86
    String decM2000; //87-88
    String decS2000; //89-90
    String vMag; //103-107

    public String toString() 
    {
        return
            name +
            ": CON="+constellation+
            ": HRN="+harvardRevisedNumber+
            ", SAO="+saoCatalog+
            ", RA="+raH2000+":"+raM2000+":"+raS2000+
            ", DEC="+decH2000+":"+decM2000+":"+decS2000+
            ", Mag="+vMag;
    }       
}   
    
    
public class ParseCatalog 
{
    static void encode(String source,
                       String north,
                       String south)
    {
        FileReader fr = null;
        BufferedReader br = null;
        FileWriter fw = null;
        PrintWriter pwNorth = null;
        PrintWriter pwSouth = null;
        
        try 
        {
            /*
             * Open the files
             */
            fr = new FileReader(source);
            br = new BufferedReader(fr);
        }
        catch(Exception e) 
        {
            System.err.println("Could not open "+source+".");
            System.err.println(e.getMessage());
            return;
        }
        try 
        {
            fw = new FileWriter(north);
            pwNorth = new PrintWriter(fw,true);
        }
        catch(Exception ioe) 
        {
            System.err.println("Could not open "+north+".");
            System.err.println(ioe.getMessage());
            return;
        }
        try 
        {
            fw = new FileWriter(south);
            pwSouth = new PrintWriter(fw,true);
        }
        catch(Exception ioe) 
        {
            System.err.println("Could not open "+south+".");
            System.err.println(ioe.getMessage());
            return;
        }

        try 
        {
            pwSouth.println("Bright Southern Stars");
            pwNorth.println("Bright Northern Stars");
            
            CatalogRecord cr = new CatalogRecord();
            
            /*
             * Read the records, loading them into the vector
             */
            while (br.ready()) 
            {
                String buffer = br.readLine();

                cr.harvardRevisedNumber=buffer.substring(0,4).trim();
                cr.name=buffer.substring(4,11).trim();
                cr.constellation=buffer.substring(11,14).trim();
                cr.saoCatalog=buffer.substring(31,37).trim();
                cr.raH2000=buffer.substring(75,77).trim();
                cr.raM2000=buffer.substring(77,79).trim();
                cr.raS2000=buffer.substring(79,83).trim();
                
                if (buffer.charAt(83)=='+') // skip plus signs.
                    cr.decH2000=buffer.substring(84,86).trim();
                else
                    cr.decH2000=buffer.substring(83,86).trim();
                
                cr.decM2000=buffer.substring(86,88).trim();
                cr.decS2000=buffer.substring(88,90).trim();
                cr.vMag=buffer.substring(102,107).trim();

                try 
                {
                    String description;
                    if (cr.constellation.length() != 0 &&
                        cr.name.length() != 0)
                        description = cr.constellation +
                            ": " +
                            cr.name +
                            " (SAO"+cr.saoCatalog+")";
                    else
                        description = "SAO"+cr.saoCatalog;

                    double decH = Double.valueOf(cr.decH2000).doubleValue();
                    double vMag = Double.valueOf(cr.vMag).doubleValue();
                    if (vMag < 5 && decH > -40) 
                    {
                        pwNorth.println(description+"\t"+
                                        cr.raH2000+"\t"+
                                        cr.raM2000+"\t"+
                                        cr.raS2000+"\t"+
                                        cr.decH2000+"\t"+
                                        cr.decM2000+"\t"+
                                        cr.decS2000+"\t"+
                                        cr.vMag+"\t--");
                    }
                    if (vMag < 5 && decH < 40) 
                    {
                        pwSouth.println(description+"\t"+
                                        cr.raH2000+"\t"+
                                        cr.raM2000+"\t"+
                                        cr.raS2000+"\t"+
                                        cr.decH2000+"\t"+
                                        cr.decM2000+"\t"+
                                        cr.decS2000+"\t"+
                                        cr.vMag+"\t--");
                    }
                }
                catch (Exception e) 
                {
                    System.out.println("Skip:"+cr);
                }
            }            
        }
        catch (EOFException ee) 
        {
            // do nothing
        }
        catch (Exception e) 
        {
            System.err.println(e);
            e.printStackTrace();
            return;
        }
    }
    
    static void main(String args[]) throws IOException
    {
        encode(args[0],args[1], args[2]);
    }    
}
