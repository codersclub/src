import palmutils.pdb.*;
import java.io.*;

public class AstroAppInfo extends PDBElement
{
    short numRecords; // # of records in the db.
    short currRecord; // Last place we looked for a record.

    public String toString() 
    {
        return "["+numRecords+","+currRecord+"]";
    }
    
    public int getSize() 
    {
        return 4;
    }
    
    public void write(DataOutput out) throws IOException 
    {
        out.writeShort(numRecords);
        out.writeShort(currRecord);
    }

    public void read(DataInput in) throws IOException 
    {
        numRecords = in.readShort();
        currRecord = in.readShort();
    }

    public AstroAppInfo() 
    {}

    public AstroAppInfo(DataInput in) throws IOException
    {
        read(in);
    }
}
