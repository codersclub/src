package palmutils.pdb;
import java.io.*;

/**
 * <code>RecordOffset</code> class is used to read/write Palm database record indexes
 * NOTE: Thi is based on work by Jefferey A. Krzysztow and Pat Beirne.
 * <p>
 * PDB Files use variable length records. Each file begins with a
 * database header, followed by a RecordIndex that contains one or
 * more RecordOffsets.  Each RecordOffset contains the location of the
 * PDB record it refers to, an attribute byte and a unique id. The unique id is
 * assigned by the Palm, so this class forces it to zero.
 * @author Michael Heinz
 * @version 1.0
 */
public class RecordOffset extends PDBElement 
{
	private int fileOffset = -1;

	/**
	 * the attributes of the record. Note that the low 4 bits are used to specify
     * the category. 
	 */
	private byte attribute = 0;	

    /**
     * Indicates that the record should be considered "private". The application
     * has the responsibility to hide private records unless the user sets
     * the "show private records" preference in Security.
     */
	public final static byte ATTRIBUTEPRIVATE = 0x10;

    /**
     * Probably shouldn't be used. Specified for completeness.
     */
    public final static byte ATTRIBUTEBUSY = 0x20;

    /**
     * Probably shouldn't be used. Specified for completeness.
     */
    public final static byte ATTRIBUTEDIRTY = 0x40;

    /**
     * Probably shouldn't be used. Specified for completeness.
     */
    public final static byte ATTRIBUTEDELETE = (byte)0x80;
    
	/**
	 * unique ID required for the RecordOffset. Should not be specified
	 */
	private int uniqueID = 0;

    public RecordOffset() 
    {}

    public RecordOffset(DataInput di) throws IOException 
    {
        read(di);
    }
    
	/**
	 * Reads the RecordOffset from the DataInput
	 * @param di the DataInput to read from
	 */
	public void read(DataInput di) throws IOException
    {
		fileOffset = di.readInt();
		attribute = di.readByte();
		uniqueID = ((0xff & di.readByte()) << 16) + ((0xff & di.readByte()) << 8) + (di.readByte() & 0xff);
	}

	/**
	 * Writes the RecordOffset to the DataOutput
	 * @param out the DataOutput to write to
	 */
	public void write(DataOutput out) throws IOException
    {
		out.writeInt(fileOffset);
		out.write(attribute);
		out.write((byte)(uniqueID >> 16));
		out.write((byte)(uniqueID >> 8));
		out.write((byte)uniqueID);
	}

	/**
	 * Dumps to standard error the contents of RecordOffset
	 */
	public String toString()
    {
        return "{" + fileOffset + "," + attribute + "," + uniqueID + "}";
    }

    public void setOffset(int n_offset) 
    {
        fileOffset = n_offset;
    }

    public int getOffset() 
    {
        return fileOffset;
    }

    public void setAttribute(int n_attribute)
    {
        attribute = (byte) (n_attribute & 0xff);
    }

    public byte getAttribute() 
    {
        return attribute;
    }

    public int getSize() 
    {
        return 8;
    }
}
