package palmutils.pdb;
import java.io.*;
import java.util.*;

/**
 * <code>RecordIndex</code> class is a table of RecordOffsets. It is used to read
 * and write Palm PDB database files. Note: this is based on work done by
 * Jefferey A. Krzysztow and Pat Beirne.
 * @author Michael Heinz
 * @version 1.0
 */
public class RecordIndex extends PDBElement
{
    /**
     * The number of records in the database. Note that some
     * definitions of PDB files put this in the header.
     */
    private short numRecords;

    public short getNumRecords() 
    {
        return numRecords;
    }
    
    /**
     * The list of offsets
     */
    private Vector recordOffsets;

    public RecordIndex() 
    {
        recordOffsets = new Vector();
    }

    public RecordIndex(DataInput di) throws IOException
    {
        recordOffsets = new Vector();
        read(di);
    }

    /**
     * Reads the entire index from the DataInput.
     * @param di the DataInput to read from.
     */
    public void read(DataInput di) throws IOException
    {
        numRecords = di.readShort();

        recordOffsets = new Vector();

        for (int i=0; i<numRecords; i++) 
        {
            RecordOffset ro = new RecordOffset(di);
            recordOffsets.addElement(ro);
        }
    }

	/**
	 * Writes the RecordIndex to the DataOutput
	 * @param out the DataOutput to write to
	 */
	public void write(DataOutput out) throws IOException {
		out.writeShort(numRecords);

        for (int i=0; i<numRecords; i++) 
        {
            RecordOffset ro = (RecordOffset)recordOffsets.elementAt(i);
            ro.write(out);;
        }
	}

    public int getSize() 
    {
        RecordOffset ro = new RecordOffset();
        return numRecords*ro.getSize()+2;
    }

    public RecordOffset getOffset(int i) 
    {
        return (RecordOffset)recordOffsets.elementAt(i);
    }

    public void addOffset(RecordOffset ro) 
    {
        numRecords++;
        recordOffsets.addElement(ro);
    }

    public String toString() 
    {
        StringBuffer sb = new StringBuffer("{"+numRecords);
        for (int i=0;i<numRecords;i++) 
        {
            sb.append(",");
            sb.append(((RecordOffset)recordOffsets.elementAt(i)).toString());
        }
        sb.append("}");
        return sb.toString();
    }
}
