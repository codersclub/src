package palmutils.pdb;

import java.io.*;

public abstract class PDBElement 
{
    public abstract void read(DataInput di) throws IOException;
    public abstract void write(DataOutput out) throws IOException;
    public abstract int getSize();

    /**
     * Writes a string to out, truncating or padding it as needed, so
     * that no more than 'length' bytes are written.
     *
     * @param out the file to write to
     * @param string the string to write
     * @param length the maximum number of bytes to write.  */
    protected void writePackedString(DataOutput out,
                                     String string,
                                     int length) throws IOException
    {
        int i, l, maxbytes;
        byte[] bytes = null;

        // we will write, at most, length-1 bytes so that there will
        // be room for the null byte.
        maxbytes = length-1;
        
        if (string == null) 
        {
            l = 0;
        }
        else 
        {
            bytes = string.getBytes();
            l = (bytes.length<maxbytes)?bytes.length:maxbytes;
        }

        if (l>0)
            out.write(bytes,0,l);
        
        out.writeByte(0); // null terminator
    }

    /**
     * Reads up to 'length' bytes from 'di' and converts them to a string,
     * discarding the trailing null.
     */
    public String readPackedString(DataInput di,
                                   int length) throws IOException
    {
        byte[] b = new byte[length];

        int i = 0;

        for (i=0; i < length; i++)
        {
            b[i] = di.readByte();
	    if (b[i] == 0)
		break;
        }

        if (i == 0)
            return null;
        
		return new String(b,0,i-1);
    }

    /**
     * Writes a string to out, truncating or padding it as needed, so
     * that exactly 'length' bytes are written.
     * @param out the file to write to
     * @param string the string to write
     * @param length the number of bytes to write.  */
    protected void writeString(DataOutput out, String string, int length) throws IOException
    {
        int i, l, maxbytes;
        byte[] bytes = null;

        // we will write, at most, length-1 bytes so that there will
        // be room for the null byte.
        maxbytes = length-1;
        
        if (string == null) 
        {
            l = 0;
        }
        else 
        {
            bytes = string.getBytes();
            l = (bytes.length<maxbytes)?bytes.length:maxbytes;
        }
        
		for(i = 0; i < l; i++) 
            out.writeByte(bytes[i]);
        for(i = l; i < length; i++)
            out.writeByte(0);
    }

    /**
     * Reads 'length' bytes from 'di' and converts them to a string, discarding
     * the trailing nulls (if any).
     */
    public String readString(DataInput di, int length) throws IOException
    {
        byte[] b = new byte[length];
        di.readFully(b);
        
		String string = new String(b);
		int i = string.indexOf(0);
        if (i>=0)
            return string.substring(0, i);
        else
            return string;
    }
}
