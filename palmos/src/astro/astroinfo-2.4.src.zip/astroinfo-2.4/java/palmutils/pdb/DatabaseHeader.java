package palmutils.pdb;
import java.io.*;
import java.util.*;

/**
 * <code>DatabaseHeader</code> class is used to read/write Palm database header records
 */
public class DatabaseHeader extends PDBElement
{
	/**
	 * name of database. Will be truncated to 32 characters.
	 */
	private String name = "";
    
    public void setName(String n_name) 
    {
        name = n_name;
    }

    public String getName() 
    {
        return name;
    }

	/**
	 *	0x0002 Read-Only database
     */
    public final static short ATTRIBUTEREADONLY = 0x0002;

    /**
	 *	0x0004 Dirty AppInfoArea
     */
    public final static short ATTRIBUTEDIRTYAPPINFO = 0x0004;

    /**
	 *	0x0008 Backup this database (i.e. no conduit exists)
     */
    public final static short ATTRIBUTEBACKUPNEEDED = 0x0008;

    /*
	 *	0x0010 Okay to install newer over existing copy, if present on
     * PalmPilot
     */
    public final static short ATTRIBUTEOVERWRITEALLOWED = 0x0010;

    /**
	 *	0x0020 (32 decimal) Force the PalmPilot to reset after this database
     * is installed.
     */
    public final static short ATTRIBUTEFORCERESET = 0x0020;

    /**
	 *	0x0040 (64 decimal) Don't allow copy of file to be beamed to other
     * Pilot.
	 */
    public final static short ATTRIBUTEUNBEAMABLE = 0x0040;
    
	private short attribute = 0;

    public void setAttribute(int n_attribute)
    {
        attribute = (short)(n_attribute & 0xffff);
    }

    public short getAttribute() 
    {
        return attribute;
    }

	/**
	 * version of database
	 * defined by application
	 * @since 1.0
	 */
	private short version = 0;	

    public void setVersion(short n_version)
    {
        version = n_version;
    }

    public short getVersion() 
    {
        return version;
    }

	/**
	 * creation date of database
	 * Expressed as the number of seconds since January 1, 1904.
	 * <b>The database will not install if this value is zero.</b>
	 */
	private int creationDate = 0;
    
    /**
	 * returns the creation date as a Date
	 * @returns Date indicating creation date
	 */
	public Date getCreationDate() {
		Calendar cl = Calendar.getInstance();
		long temp = new Integer(creationDate).longValue();
		if(temp < 0) {
			temp += ((long) 1) << 32;
		}
		return new Date((temp - SecondsSince1904) * 1000 - cl.get(Calendar.ZONE_OFFSET) - cl.get(Calendar.DST_OFFSET));
	}

	/**
	 * last modification date of database
	 * Expressed as the number of seconds since January 1, 1904.
	 * <b>The database will not install if this value is zero.</b>
	 */
	private int modificationDate = 0;

    /**
	 * Sets the modification date member to now
     */
	public void setModificationDate() {
		// find the current time, and convert into number of seconds
        // since Jan 1, 1904
		Calendar cl = Calendar.getInstance();
		modificationDate = (int)((System.currentTimeMillis() +
                                  cl.get(Calendar.ZONE_OFFSET) +
                                  cl.get(Calendar.DST_OFFSET))
			/ 1000 + SecondsSince1904);
	}

	/**
	 * returns the modification date as a Date
	 * @returns Date indicating modification date
	 */
	public Date getModificationDate() {
		Calendar cl = Calendar.getInstance();
		long temp = new Integer(modificationDate).longValue();
		if(temp < 0) {
			temp += ((long) 1) << 32;
		}
		return new Date((temp - SecondsSince1904) * 1000 - cl.get(Calendar.ZONE_OFFSET) - cl.get(Calendar.DST_OFFSET));
	}

	/**
	 * last date database was HotSynced
	 * Expressed as the number of seconds since January 1, 1904.
	 * The database will install if this value is zero.
	 */
	private int lastBackupDate = 0;
    
	public Date getLastBackupDate() {
		Calendar cl = Calendar.getInstance();
		long temp = new Integer(lastBackupDate).longValue();
		if(temp < 0) {
			temp += ((long) 1) << 32;
		}
		return new Date((temp - SecondsSince1904) * 1000 - cl.get(Calendar.ZONE_OFFSET) - cl.get(Calendar.DST_OFFSET));
	}

	/**
	 * modification number.
	 * Set to zero.
	 */
	private int modificationNumber = 0;

    public int getModificationNumber()
    {
        return modificationNumber;
    }
    
	/**
	 * appInfoID
	 * The byte number in the PDB file (counting from zero) at
	 * which the AppInfoArea is located. This must be the first
	 * entry in the Data portion of the PDB file. If this
	 * database does not have an AppInfoArea, set this value to
	 * zero.
	 */
	private int appInfoID = 0;
    public void setAppInfoID(int n_AppInfoID)
    {
        appInfoID = n_AppInfoID;
    }

    public int getAppInfoID()
    {
        return appInfoID;
    }
    
	/**
	 * sortInfoID
	 * The byte number in the PDB file (counting from zero) at
	 * which the SortInfoArea is located. This must be placed
	 * immediately after the AppInfoArea, if one exists, within
	 * the Data portion of the PDB file. If this database does
	 * not have a SortInfoArea, set this value to zero. Do not
	 * use this.
	 */
	private int sortInfoID = 0;
    
    public void setSortInfoID(int n_sortInfoID)
    {
        sortInfoID = n_sortInfoID;
    }

    public int getSortInfoID()
    {
        return sortInfoID;
    }
    
	/**
	 * Database type id. Used to identify databases in the palm.
	 */
	private int typeID = 0;
    public void setTypeID(String n_typeID)
    {
        typeID = convertStringToID(n_typeID);
    }

    public String getTypeID()
    {
        return convertIDToString(typeID);
    }
    
	/**
	 * ID of application that created database.
	 */
	private int creatorID = 0;					// 4 DWord
    public void setCreatorID(String n_creatorID)
    {
        creatorID = convertStringToID(n_creatorID);
    }

    public String getCreatorID()
    {
        return convertIDToString(creatorID);
    }
    
	/**
	 * uniqueIDSeed
	 * This is used to generate the Unique ID number of
	 * subsequent records. This should be set to zero.
	 */
	private int uniqueIDSeed = 0;

    public int getUniqueIDSeed() 
    {
        return uniqueIDSeed;
    }
    
	/**
	 * nextRecordListID
	 * Set this to zero. The element is used only in the
	 * in-memory representation of a PDB file, but exists
	 * in the external version for consistency.
	 */
	private int nextRecordListID = 0;

    public int getNextRecordListID() 
    {
        return nextRecordListID;
    }

	public DatabaseHeader() {
		// find the current time, and convert into number of seconds since Jan 1, 1904
        setModificationDate();
        creationDate = modificationDate;
	}

    public DatabaseHeader(DataInput di) throws IOException
    {
        read(di);
    }
    
	/**
	 * The size of the DatabaseHeader in bytes
	 * @returns the number of bytes in the DatabaseHeader
	 * @since 1.0
	 */
	public int getSize() {
		return(76);
	}

	/**
	 * Reads the DatabaseHeader from the DataInput
	 * @param di the DataInput to read from
	 */
	public void read(DataInput di) throws IOException {
        name = readString(di,32);
		attribute = di.readShort();
		version = di.readShort();
		creationDate = di.readInt();
		modificationDate = di.readInt();
		lastBackupDate = di.readInt();
		modificationNumber = di.readInt();
		appInfoID = di.readInt();
		sortInfoID = di.readInt();
		typeID = di.readInt();
		creatorID = di.readInt();
		uniqueIDSeed = di.readInt();
		nextRecordListID = di.readInt();
	}

	/**
	 * Writes the DatabaseHeader to the DataInput
	 * @param out the DataInput to write to
	 */
	public void write(DataOutput out) throws IOException
    {

        writeString(out,name,32);
		out.writeShort(attribute);
		out.writeShort(version);
		out.writeInt(creationDate);
		out.writeInt(modificationDate);
		out.writeInt(lastBackupDate);
		out.writeInt(modificationNumber);
		out.writeInt(appInfoID);
		out.writeInt(sortInfoID);
		out.writeInt(typeID);
		out.writeInt(creatorID);
		out.writeInt(uniqueIDSeed);
		out.writeInt(nextRecordListID);
	}

	/**
	 * override Object.toString()
	 */
	public String toString()  {
		char[] creatorIDa = new char[4];
		creatorIDa[0] = (char)((creatorID >> 24) & 0xff);
		creatorIDa[1] = (char)((creatorID >> 16) & 0xff);
		creatorIDa[2] = (char)((creatorID >> 8) & 0xff);
		creatorIDa[3] = (char)(creatorID & 0xff);
		char[] typeIDa = new char[4];
		typeIDa[0] = (char)((typeID >> 24) & 0xff);
		typeIDa[1] = (char)((typeID >> 16) & 0xff);
		typeIDa[2] = (char)((typeID >> 8) & 0xff);
		typeIDa[3] = (char)(typeID & 0xff);
		return "{`"	+ name + "`, A= 0x" + Integer.toHexString(attribute)
			+ ", V=" + version
			+ ", CD=" + creationDate + "(" + getCreationDate()
			+ "), MD=" + modificationDate + "(" + getModificationDate() 
			+ "), BD=" + lastBackupDate
			+ ", MN=" + modificationNumber
			+ ", AI=" + appInfoID
			+ ", SI= " + sortInfoID
			+ ", type= 0x" + Integer.toHexString(typeID)
            + " `" + new String(typeIDa) + "`"
			+ ", creator = 0x" + Integer.toHexString(creatorID)
            + " `" + new String(creatorIDa) + "`"
			+ ", US = " + uniqueIDSeed
            + ", NR = " + nextRecordListID + "}";
	}

	/**
	 * Seconds since 1904. Used in date attributes.
	 */
	private final static int SecondsSince1904 = 2082844800;

	/**
	 * converts the String representation of typeID to an int representation
	 * @param typeID String representation of typeID
	 * @return int representation of typeID
	 */
	public static int convertStringToID(String typeID) {
		byte typeIDa[] = typeID.getBytes();
		return ((0xff & typeIDa[0]) << 24)
			+ ((0xff & typeIDa[1]) << 16)
			+ ((0xff & typeIDa[2]) << 8)
			+ (0xff & typeIDa[3]);
	}

	/**
	 * converts the int representation of typeID to a String representation
	 * @param typeID int representation of typeID
	 * @return String representation of typeID
	 */
	public static String convertIDToString(int typeID)	 {
		char[] typeIDa = new char[4];
		typeIDa[0] = (char)((typeID >> 24) & 0xff);
		typeIDa[1] = (char)((typeID >> 16) & 0xff);
		typeIDa[2] = (char)((typeID >> 8) & 0xff);
		typeIDa[3] = (char)(typeID & 0xff);
		return new String(typeIDa);
	}
}

