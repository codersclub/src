import palmutils.pdb.*;
import java.io.*;

public class AstroRecord extends PDBElement
{
    public static final int DESCRIPTIONSIZE = 32;
    
    String description; // must be less than 32 letters (32 bytes)
    double ra;          // right ascension in radians.
    double dec;         // declination in radians.
    double magnitude;   // the visual magnitude.
    double sizex;       // x-size in seconds
    double sizey;       // y-size in seconds
    int type;		// type of object for sorting and classifying

    public String toString() 
    {
        return "["+description+": ("+(ra * 12 / Math.PI)+"),("+
            (dec * 180 / Math.PI)+"),"+magnitude+","+sizex+"x"+sizey+"]"+
            "{"+getSize()+"}";
    }
    
    public int getType()
    {
	return type;
    }

    public int getSize() 
    {
        return 14 + ( description == null ? 1 
		      : description.length() < DESCRIPTIONSIZE
		      ? description.length() + 1 : DESCRIPTIONSIZE);
    }
    
    public void write(DataOutput out) throws IOException 
    {
	if (sizex > 3270.0 || sizey > 3270.0 || magnitude > 128.0
	    || sizex < 0 || sizey < 0 || magnitude < -128.0)
	    throw new IllegalArgumentException(toString());

	out.writeInt((int) (long) (ra  * (1L << 31) / Math.PI));
	out.writeInt((int) (long) (dec * (1L << 31) / Math.PI));
	/* The format of the magnitude will be changed in AI-3 */
	/* out.writeShort((int) (magnitude * 256)); */
	out.writeShort((int) (magnitude * 100));
	/* Should we change the format of sizex,sizey to GP16, too? 
	 * Or should we change it to angle FP (32 bits)? The latter
	 * would take 4 bytes more.
	 */
	out.writeShort((int) (sizex * 10));
	out.writeShort((int) (sizey * 10));
        writePackedString(out,description,32);
	/* This field will be inserted in AI-3 */
	/* out.writeShort((int) (type));*/
    }

    public void read(DataInput in) throws IOException 
    {
	ra = Math.PI / (1 << 31) * in.readInt();
	in.readInt(); // ignore sin(ra).
	dec = Math.PI / (1 << 31) * in.readInt();
	in.readInt(); // ignore sin(dec).
	magnitude = in.readShort() / 100.0;
	sizex = in.readShort() / 100.0;
	sizey = in.readShort() / 100.0;
        description = readPackedString(in,32);
	type = in.readShort(); 
    }

    public AstroRecord() 
    {}

    public AstroRecord(DataInput in) throws IOException 
    {
        read(in);
    }
    
}

