import palmutils.pdb.*;
import java.io.*;
import java.util.*;

public class ConvertDST 
{
    final static String weekday_names[] = {
	"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"
    };
    final static String month_names[] = {
	"Jan", "Feb", "Mar", "Apr", "May", "Jun",
	"Jul", "Aug", "Sep", "Oct", "Nov", "Dec"
    };

    final static int NAME_LENGTH = 16;

    static class DSTRecord extends PDBElement {
	String  name;
	int     startTime;
	int     startDay;
	int     startMonth;
	int     startDOW;
	int     endTime;
	int     endDay;
	int     endMonth;
	int     endDOW;
	int     savings;
	boolean isUTC;

	public String printTime(int minutes)
	{
	    String hour = "0" + minutes/60;
	    String min  = "0" + minutes%60;
	    return hour.substring(hour.length()-2)+":"
		+ min.substring(min.length()-2);
	}

	public int getSize() 
	{
	    return NAME_LENGTH + 8;
	}

	public int parseTime(String str)
	{
	    if (str.charAt(2) != ':')
		throw new IllegalArgumentException
		    ("Malformed time: `"+str+"'");
	    return Integer.parseInt(str.substring(0,2)) * 60 
		+ Integer.parseInt(str.substring(3,5));
	}
	

	public String parseRule(boolean isStart, String line)
	{
	    int dow;
	    int day = 0;
	    int month;
	    int time;
	    boolean ge = true;
	    boolean isLast = false;
	    boolean parseDay = true;
	    boolean utc = false;
	    for (dow=0; dow < 7; dow++) {
		if (line.toLowerCase()
		    .startsWith(weekday_names[dow].toLowerCase())) {
		    line = line.substring(3).trim();
		    if (line.startsWith("<="))
			ge = false;
		    else if (line.startsWith(">="))
			ge = true;
		    else
			throw new IllegalArgumentException
			    ("Weekday without <=/>=");
		    line = line.substring(2).trim();
		    break;
		}
	    }
	    if (line.startsWith("last")) {
		isLast = true;
		line = line.substring(4).trim();
		if (!line.startsWith("-"))
		    parseDay = false;
		else
		    line = line.substring(1).trim();
	    }
	    if (parseDay) {
		int i;
		for (i = 0; 
		     i < line.length() && Character.isDigit(line.charAt(i));
		     i++);
		day = Integer.parseInt(line.substring(0,i));
		line = line.substring(i).trim();
	    }
	    for (month = 0; month < 12; month++) {
		if (line.toLowerCase()
		    .startsWith(month_names[month].toLowerCase())) {
		    line = line.substring(3).trim();
		    break;
		}
	    }
	    if (month == 12)
		throw new IllegalArgumentException("Unknown Month");
	    time = parseTime(line.substring(0, 5));
	    line = line.substring(5);
	    if (line.charAt(0) == 'U') {
		utc = true;
		line =line.substring(1);
	    }
	    line = line.trim();
	    month++;
	    if (isLast) {
		day = -day;
		month = (month % 12) + 1;
	    }
	    if (!ge)
		day -= 6;

	    if (isStart) {
		startDOW = dow;
		startDay = day;
		startMonth = month;
		startTime = time;
		isUTC = utc;
	    } else {
		endDOW = dow;
		endDay = day;
		endMonth = month;
		endTime = time;
		if (isUTC != utc)
		    throw new IllegalArgumentException("UTC inconsistent");
	    }
	    return line;
	}

	public void parse(String line)
	{
	    int colon = line.indexOf(':');
	    if (colon < 0 || colon > NAME_LENGTH)
		throw new IllegalArgumentException("Colon not found");
	    name = line.substring(0, colon);
	    line = line.substring(colon+1).trim();
	    line = parseRule(true, line);
	    line = parseRule(false, line);
	    savings = parseTime(line.substring(0,5));
	    line = line.substring(5).trim();
	    if (line.length() > 0)
		throw new IllegalArgumentException("Trailing garbage: `"
						   +line+"'");
	}

	public void write(DataOutput out) throws IOException 
	{
	    writeString(out, name, NAME_LENGTH);
	    out.writeShort((startTime << 4) | (startMonth & 0xf));
	    out.writeShort((endTime << 4) | (endMonth & 0xf));
	    out.writeShort((isUTC ? 0x8000 : 0)
			   | ((startDOW & 7) << 12)
			   | ((startDay & 0x3f) << 6)
			   | (endDay & 0x3f));
	    out.writeShort(((endDOW & 7) << 13)
			   | (savings & 0x1fff));
	}

	public void read(DataInput in) throws IOException 
	{
	    byte[] bytes = new byte[NAME_LENGTH];
	    int tmp;
	    in.readFully(bytes);
	    name = new String(bytes).trim();
	    tmp = in.readShort();
	    startTime = tmp >> 4;
	    startMonth = tmp & 0xf;
	    tmp = in.readShort();
	    endTime = tmp >> 4;
	    endMonth = tmp & 0xf;

	    tmp = in.readShort();
	    isUTC = (tmp & 0x8000) != 0;
	    startDOW = (tmp >> 12) & 7;
	    startDay = (tmp >> 6)  & 0x3f;
	    if (startDay >= 32)
		startDay -= 64;
	    endDay = tmp & 0x3f;
	    if (endDay >= 32)
		endDay -= 64;
	    tmp = in.readShort();
	    endDOW = (tmp >> 13) & 7;
	    savings = tmp & 0x1fff;
	}


	public String printRule(int DOW, int mon, int day, int time, 
				boolean isUTC)
	{
	    StringBuffer sb = new StringBuffer();
	    if (DOW != 7) {
		sb.append(weekday_names[DOW]).append(" >= ");
	    }
	    if (day <= 0) {
		sb.append("last");
		if (day < 0)
		    sb.append(day);
		sb.append(' ').append(month_names[(mon-1 + 11) % 12]);
	    } else
		sb.append(day).append(' ').append(month_names[mon-1]);
	    sb.append(' ').append(printTime(time));
	    if (isUTC)
		sb.append('U');
	    return sb.toString();
	}

	public String toString() 
	{
	    return (name + ":                               ")
		.substring(0,NAME_LENGTH+2)
		+ printRule(startDOW, startMonth, startDay, 
			    startTime, isUTC)
		+ " "
		+ printRule(endDOW, endMonth, endDay, endTime, isUTC)
		+ " " + printTime(savings);
	}

    }

    static void encode(String source,
                       String destination,
                       boolean noSeconds)
    {
        FileReader fr = null;
        BufferedReader br = null;
        DataOutputStream dos = null;
        DatabaseHeader databaseHeader = new DatabaseHeader();
        RecordIndex recordIndex = new RecordIndex();
        Vector records = new Vector();
        
        try 
        {
            /*
             * Open the files
             */
            fr = new FileReader(source);
            br = new BufferedReader(fr);
            dos = new DataOutputStream(new FileOutputStream(destination));
        }
        catch(FileNotFoundException fnfe) 
        {
            System.err.println("Could not open "+source+".");
            System.err.println(fnfe.getMessage());
            return;
        }
        catch(IOException ioe) 
        {
            System.err.println("Could not open "+destination+".");
            System.err.println(ioe.getMessage());
            return;
        }

        try 
        {
            /*
             * Initialize the header.
             */
            databaseHeader.setName(br.readLine());
            databaseHeader.setVersion((short)0);
            databaseHeader.setTypeID("DST0");
            databaseHeader.setCreatorID("MWH2");

            /*
             * Read the records, loading them into the vector
             */
            while (br.ready()) 
            {
                DSTRecord dr = new DSTRecord();
                String buffer = br.readLine();

		dr.parse(buffer);
                records.addElement(dr);
                recordIndex.addOffset(new RecordOffset());
                
            }
            
        }
        catch (EOFException ee) 
        {
            // do nothing
        }
        catch (Exception e) 
        {
            System.err.println(e);
            e.printStackTrace();
            return;
        }
        
        try 
        {
            /*
             * Calculate the size of the header & index.
             */
            int offset = databaseHeader.getSize() +
                         recordIndex.getSize();
	    int numRecords = recordIndex.getNumRecords();

            /*
             * Set the location of the app info.
             */
            databaseHeader.setAppInfoID(0);

            /*
             * Build the record index
             */
            for (int i=0; i < numRecords; i++) 
            {
                RecordOffset ro = recordIndex.getOffset(i);
                DSTRecord dr = (DSTRecord)records.elementAt(i);
                ro.setOffset(offset);
                offset = offset + dr.getSize();
            }

            br.close();

            /*
             * Write the header, index and app info.
             */
            databaseHeader.write(dos);
            recordIndex.write(dos);

            /*
             * Write the records
             */
            for (int i=0; i < numRecords; i++) 
            {
                DSTRecord dr = (DSTRecord)records.elementAt(i);
                dr.write(dos);
            }
            dos.close();
        }
        catch (Exception e) 
        {
            System.err.println(e);
            e.printStackTrace();
        }
    }
    
    static public void main(String args[]) throws IOException
    {
        int argsOffset = 0;
        boolean noSeconds = true;
        while (argsOffset <= args.length && args[argsOffset].charAt(0)=='-')
        try {
            switch (args[argsOffset].charAt(1))
            {
                case 's':
                    noSeconds = false;
                    break;
                default:
                    System.err.println("Invalid option.");
                        return;
            }
            argsOffset++;            
        }
        catch (Exception e) 
        {
            System.err.println("Failed parsing arguments.");
            return;
        }

        encode(args[argsOffset],args[argsOffset+1],noSeconds);
    }    
}
