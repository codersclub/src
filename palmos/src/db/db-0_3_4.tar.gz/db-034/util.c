/* DB: Utility Functions
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include <CharAttr.h>
#include <PalmOSGlue.h>
#include <unix_stdarg.h>
#include "db.h"
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_DEBUG
#include <HostControl.h>
#endif

#include "io.h"

#include "enum.h"
#include "double.h"
#include "util.h"

#ifdef CONFIG_HANDERA
static void UtilMoveObject(FormPtr frmP, UInt16 objIndex, Coord x_diff, Coord y_diff, Boolean draw) SECT_UI2;
static void UtilResizeObject(FormPtr frmP, UInt16 objIndex, Coord x_diff, Coord y_diff, Boolean draw) SECT_UI2;
static Boolean UtilGetSizeForm(FormPtr form, Coord *x_diff, Coord *y_diff, Boolean draw) SECT_UI2;
#endif

#define MAXUINT32 0x7FFFFFFF

/* When UtilWinDrawTruncChars is called with right-justification, this is
 *  the number of pixels left on the right hand side of the clipping
 *  rectangle as a margin for the next column.
 *
 *  This isn't an ideal solution, becuase if all columns are right
 *  justified, we shouldn't waste space with margins, but since it is
 *  likely that most will be left justified, this seems to be an
 *  acceptable temporary method 
 */
#define RIGHT_JUSTIFICATION_MARGIN 10  

#ifdef GLOBAL_ACCESS
UInt8 MyErr;
#endif
LocalizationInfo LocalInfo;


Boolean
HandleCommonMenuEvent(UInt16 menuitemID)
{
    switch (menuitemID) {
    case menuitemID_AppPrefs:
        FrmPopupForm(formID_AppPrefs);
        return true;

    case menuitemID_About:
#ifdef CONFIG_ABOUT
	  FrmPopupForm( formID_About );
#else
      FrmAlert( formID_About );
#endif
	  return true;

#ifdef CONFIG_HANDERA
    case menuitemID_HanderaRotate:
    {
        VgaRotateModeType mode;

        if (!FeatureSetHandera)
            return false;

        mode = VgaRotateSelect(rotateModeNone);
        VgaSetScreenMode(screenMode1To1, mode);
        FrmUpdateForm( FrmGetFormId(FrmGetActiveForm()), 0x02);
        return true;
    }
#endif
    default:
        return false;
    } 
}

void
DbgPrintF(const Char * fmt, ...)
{
    va_list args;
    Char buf[256];

#ifdef CONFIG_DEBUG
#define DEBUG_OUT_NAME "debug.txt"
	HostFILE  *hf=NULL;

    va_start(args, fmt);
    HostTraceOutputVTL( 0, fmt, args);
    hf = HostFOpen(DEBUG_OUT_NAME,"a");
    if (hf) {
        StrVPrintF(buf, fmt, args);
	    HostFPrintF(hf,buf);
	    HostFPrintF(hf,"\n");
	    HostFClose(hf);
    }
    va_end(args);
#else
    va_start(args, fmt);
    StrVPrintF(buf, fmt, args);
    va_end(args);

    FrmCustomAlert(alertID_Debug, buf, " ", " ");
#endif
}

char *
GetStringResource(UInt16 stringID)
{
    MemHandle str_handle;
    char * str;

    str_handle = DmGetResource(strRsc, stringID);
    if (! str_handle)
        return 0;

    str = (char *)MemHandleLock(str_handle);
    return str;
}

void
PutStringResource(const char * str)
{
    MemHandle str_handle = MemPtrRecoverHandle((MemPtr) str);

    MemHandleUnlock(str_handle);
    DmReleaseResource(str_handle);
}

char *
CopyStringResource(UInt16 stringID)
{
    MemHandle str_handle;
    char * str;
    char * str_copy;

    str_handle = DmGetResource(strRsc, stringID);
    if (! str_handle)
        return 0;

    str = (char *)MemHandleLock(str_handle);

    str_copy = (char *)AllocateMemPtr(1 + StrLen(str));
    ErrFatalDisplayIf( !str_copy, "out of Memory");
    if (str_copy) {
        StrCopy(str_copy, str);
    }
    RecordMemInfo( str_copy, str_copy );

    MemHandleUnlock(str_handle);
    DmReleaseResource(str_handle);

    return str_copy;
}

Boolean
IsNumber(const char * str)
{
    String2Long(str);
#ifdef GLOBAL_ACCESS
    if (MyErr)
        return false;
    else
#endif
        return true;
}

Int32
String2Long(const char * str)
{
    Int16 len = StrLen(str), index = 0;
    Int32 value;//,result = 0;
    UInt32 result = 0UL;
    Int16 base = 10;
    Boolean positive = true;
    WChar ch;

#ifdef GLOBAL_ACCESS
    MyErr = 0;
#endif

    /* Skip over any - at the start of a string. */
    index += TxtGlueGetNextChar(str, index, &ch);
    if (ch == chrHyphenMinus) {
        positive = false;
        if (index >= len) goto ERROR;
        index += TxtGlueGetNextChar(str, index, &ch);
    }

    /* Check for leading 0 or 0x which signifies octal and hexadecimal. */
    if (ch == chrDigitZero) {
        base = 8;
        if (index >= len) return 0;
        index += TxtGlueGetNextChar(str, index, &ch);
        if (ch == chrSmall_X || ch == chrCapital_X) {
            base = 16;
            if (index >= len) goto ERROR;
            index += TxtGlueGetNextChar(str, index, &ch);
        }
    }

    while (1) {
        if (TxtGlueCharIsDigit(ch))
            value = ch - chrDigitZero;
        else if (TxtGlueCharIsLower(ch))
            value = ch - chrSmall_A + 10;
        else if (TxtGlueCharIsUpper(ch))
            value = ch - chrCapital_A + 10;
        else
            goto ERROR;
    
        /* If we exceed the base, then it is not a valid number. */
        if (value >= base) goto ERROR;
    
        /* Move this digit into the result. */
#ifdef __GNUC__
        result = (result * base) + value;
#else
        /* this a bug but i don't know how to do 
         * a long multiplication with CodeWarrior
         */
        result = ((short)result * base) + value;
#endif
    
        if (result > MAXUINT32){
            result = MAXUINT32;
            break;
        }
        /* Drop out of the loop if we are at the end of string. */
        if (index >= len) break;
    
        /* Pull the next character from the string. */
        index += TxtGlueGetNextChar(str, index, &ch);
    }

    return positive ? result : (- result);
ERROR:
#ifdef GLOBAL_ACCESS
    MyErr = -1;
#endif
    return 0;
}

Boolean
MatchString(const char * str, const char * substr,
            Boolean case_sensitive, Boolean wholeWord)
{
    UInt16 len_str, len_substr, offset;
    Int16 (*Compare)(const Char*, UInt16, UInt16 *,
                     const Char*, UInt16, UInt16*);
    UInt32 word_start, word_end;

    len_substr = StrLen(substr);
    if (len_substr == 0)
        return true;
    len_str = StrLen(str);

    /* Determine the comparison routine to use. */
    if (case_sensitive)
        Compare = (Int16 (*)(const Char*, UInt16, UInt16 *, const Char*, UInt16, UInt16*))
        			IntlGlueGetRoutineAddress(intlTxtCompare, TxtLatinCompare);
    else
        Compare = (Int16 (*)(const Char*, UInt16, UInt16 *, const Char*, UInt16, UInt16*))
        			IntlGlueGetRoutineAddress(intlTxtCaselessCompare,
                                            TxtLatinCaselessCompare);

    offset = 0;
    while (offset + len_substr <= len_str) {
        if (Compare(str + offset, len_substr, 0, substr, len_substr, 0) == 0) {
            /* If we don't need to match a word, then a match was found. */
            if (! wholeWord) return true;

            /* Figure out where a word is in the current match. */
            if (TxtGlueWordBounds(str, len_str, offset,
                                  &word_start, &word_end)) {
                if (word_start == offset
                    && word_end - word_start == len_substr) return true;
            }
        }

        /* Slide the offset to the right by one character. */
        offset += TxtGlueGetNextChar(str, offset, 0);
    }

    return false;
}

Boolean
CmpField(DataSource * source, DataSourceGetter* getter, void* rec_data, UInt16 i, const char* str, Boolean caseSens, Boolean wholeWord)
{
    char buf[256];

    ConvertFieldToString(source, getter, rec_data, i, buf, sizeof(buf)-1);
    return MatchString(buf, str, caseSens, wholeWord);
}

void UtilWinDrawTruncChars(const char * str, UInt16 length,
                         Int16 x, Int16 y, Int16 maxWidth, Boolean ljustify)
{
    Boolean fitInWidth;
    Int16 len, width;

	if ( !ljustify ) maxWidth -= RIGHT_JUSTIFICATION_MARGIN;

	width = maxWidth;
    len = length;
    fitInWidth = false;		
    FntCharsInWidth(str, &width, &len, &fitInWidth);
	

	
    if (fitInWidth) {
	  if ( !ljustify ) x += maxWidth - width;
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum){
            HRWinDrawChars(SonyLibRefNum, str, length, x, y);
        } else
#endif
        WinDrawChars(str, length, x, y);
    } else {
        WChar ch;

        /* Retrieve the ellipsis character. */
        ch = TxtGlueGetHorizEllipsisChar();

        /* Figure out how many characters can be shown with the ellipsis. */
        width = maxWidth - TxtGlueCharWidth(ch);
        len = length;
        fitInWidth = false;
        FntCharsInWidth(str, &width, &len, &fitInWidth);

        /* Draw the string and the ellipsis. */
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum){
            HRWinDrawChars(SonyLibRefNum, str, len, x, y);
            HRWinDrawChar(SonyLibRefNum, ch, x + width, y);
        } else
#endif
        {
            WinDrawChars(str, len, x, y);
            WinGlueDrawChar(ch, x + width, y);
        }
    }
}




struct indicator_context
{
    RectangleType bounds;    /* bounds of the entire saved area */
    WinHandle winH;          /* offscreen window from WinSaveBits */
};

void *
ShowModalMessage(const char * msg, FontID font, FrameType frame)
{
    struct indicator_context * context;
    RectangleType interior;
    Coord screen_width, screen_height;
    FontID oldFont;
    Err err;

    /* Allocate the context structure used to restore the screen. */
    context = (struct indicator_context *) AllocateMemPtr(sizeof(struct indicator_context));
    /* Switch to the font to be used for drawing the text. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        oldFont = HRFntSetFont( SonyLibRefNum, font);
    else
#endif
    oldFont = FntSetFont(font);

    /* Calculate the interior size of the window to be drawn. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        HRWinGetDisplayExtent( SonyLibRefNum, &screen_width, &screen_height);
    else
#endif
    WinGetDisplayExtent(&screen_width, &screen_height);
    interior.extent.x = FntCharsWidth(msg,StrLen(msg)) + FntAverageCharWidth();
   interior.extent.y = FntLineHeight() * 2;
    interior.topLeft.x = (screen_width - interior.extent.x) / 2;
    interior.topLeft.y = (screen_height - interior.extent.y) / 2;

    /* Save the interior area and the frame that will be drawn later. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRWinGetFramesRectangle( SonyLibRefNum, frame, &interior, &context->bounds);
        context->winH = HRWinSaveBits( SonyLibRefNum, &context->bounds, &err);
    } else
#endif
    {
        WinGetFramesRectangle(frame, &interior, &context->bounds);
        context->winH = WinSaveBits(&context->bounds, &err);
    }

    /* Save the current draw state and switch to the UIAlert scheme. */
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        WinPushDrawState();
        WinSetForeColor(UIColorGetTableEntryIndex(UIAlertFrame));
        WinSetBackColor(UIColorGetTableEntryIndex(UIAlertFill));
        WinSetTextColor(UIColorGetTableEntryIndex(UIObjectForeground));
        WinSetUnderlineMode(noUnderline);
    }
#endif

    /* Clear the interior of the dialog to the background color. */

#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRWinEraseRectangle(SonyLibRefNum, &interior, 0);
    } else
#endif
    WinEraseRectangle(&interior, 0);

    /* Draw the frame around the interior. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        WinSetDrawMode(winOverlay);
        HRWinDrawRectangleFrame(SonyLibRefNum, frame, &interior);
    } else
#endif
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        WinSetDrawMode(winOverlay);
        WinPaintRectangleFrame(frame, &interior);
    } else
#endif
    WinDrawRectangleFrame(frame, &interior);

    /* Finally, draw the text centered within the interior. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRWinDrawChars(SonyLibRefNum, msg, StrLen(msg),
                 interior.topLeft.x + (FntAverageCharWidth() / 2),
                 interior.topLeft.y + (FntLineHeight() / 2));
    } else
#endif
    WinDrawChars(msg, StrLen(msg),
                 interior.topLeft.x + (FntAverageCharWidth() / 2),
                 interior.topLeft.y + (FntLineHeight() / 2));

    /* Restore the original draw state. */
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        WinPopDrawState();
    }
#endif

    /* Restore the original text font. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        HRFntSetFont( SonyLibRefNum, oldFont);
    else
#endif
    FntSetFont(oldFont);

    return context;
}

void
HideModalMessage(void * ptr)
{
    struct indicator_context * context = (struct indicator_context *) ptr;

    if (context->winH) {
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum)
            HRWinRestoreBits( SonyLibRefNum, context->winH,
                       context->bounds.topLeft.x, context->bounds.topLeft.y);
        else
#endif
        WinRestoreBits(context->winH,
                       context->bounds.topLeft.x, context->bounds.topLeft.y);
    } else {
        FrmUpdateForm(FrmGetActiveFormID(), frmRedrawUpdateCode);
    }

    /* Free the context structure now that we are done with it. */
    DeallocateMemPtr(context);
}

void *
ShowWorkingIndicator(void)
{
    void * context;
    char * msg;

    msg = CopyStringResource(stringID_Working);
#ifdef CONFIG_HANDERA
    if (FeatureSetHandera)
        context = ShowModalMessage(msg, VgaBaseToVgaFont(boldFont), boldRoundFrame);
    else
#endif
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        context = ShowModalMessage(msg, hrBoldFont, boldRoundFrame);
    else
#endif
    context = ShowModalMessage(msg, boldFont, boldRoundFrame);
    DeallocateMemPtr(msg);
    return context;
}

void
HideWorkingIndicator(void * context)
{
    HideModalMessage(context);
}

#ifdef CONFIG_HANDERA
#include "enum-icons.h"
static void
UtilMoveObject(FormPtr frmP, UInt16 objIndex, Coord x_diff, Coord y_diff, Boolean draw)
{
    RectangleType r;
    
    FrmGetObjectBounds(frmP, objIndex, &r);
    if (draw)
    {
        RctInsetRectangle(&r, -2);   //need to erase the frame as well
        WinEraseRectangle(&r, 0);
        RctInsetRectangle(&r, 2);
    }    
    r.topLeft.y += y_diff;
    r.topLeft.x += x_diff;
    FrmSetObjectBounds(frmP, objIndex, &r);
}

static void
UtilResizeObject(FormPtr frmP, UInt16 objIndex, Coord x_diff, Coord y_diff, Boolean draw)
{
    RectangleType r;

    FrmGetObjectBounds(frmP, objIndex, &r);
    if (draw)
        WinEraseRectangle(&r, 0);
    r.extent.x += x_diff;
    r.extent.y += y_diff;
    FrmSetObjectBounds(frmP, objIndex, &r);
}

static Boolean
UtilGetSizeForm(FormPtr form, Coord *x_diff, Coord *y_diff, Boolean draw)
{
    Coord         x, y;
    RectangleType r, erase_rect;

    WinGetDisplayExtent(&x, &y);

    FrmGetFormBounds(form, &r);
    
    *x_diff = x - (r.topLeft.x + r.extent.x);
    *y_diff = y - (r.extent.y + r.topLeft.y);
    if (!(*y_diff))
        return false;

    if (draw  &&  (y_diff < 0))
    {
        erase_rect           = r;
        erase_rect.topLeft.y = r.extent.y + (*y_diff);
        erase_rect.extent.y  = -(*y_diff);
        erase_rect.topLeft.x = r.extent.x + (*x_diff);
        erase_rect.extent.x  = -(*x_diff);
        WinEraseRectangle(&erase_rect, 0);
    }    
        
    r.extent.y += (*y_diff);
    r.extent.x += (*x_diff);
    WinSetWindowBounds(FrmGetWindowHandle(form), &r);
/*#else
    *x_diff = 0;
    *y_diff = 0;
*/
    return true;
}

Boolean
UtilResizeForm(FormPtr form, UInt16 * objectID1, UInt16 * objectID2, UInt16 * objectID3, UInt16 centralObject, Boolean draw)
{
    UInt16        i;
    Coord         y_diff;
    Coord         x_diff;

    //unuse to resize no high resolution device
    if (!FeatureSetHandera)
        return false;

    if (!UtilGetSizeForm (form, &x_diff, &y_diff, draw))
        return false;

    for (i = 0; objectID1[i]; i++) {
        UtilMoveObject(form, FrmGetObjectIndex(form, objectID1[i]), 0, y_diff, draw);
    }
    for (i = 0; objectID2[i]; i++) {
        UtilMoveObject(form, FrmGetObjectIndex(form, objectID2[i]), x_diff, y_diff, draw);
    }
    for (i = 0; objectID3[i]; i++) {
        UtilMoveObject(form, FrmGetObjectIndex(form, objectID3[i]), x_diff, 0, draw);
    }

    UtilResizeObject(form, FrmGetObjectIndex(form, centralObject), x_diff, y_diff, draw);
    return true;
}

Boolean
UtilCenterForm(FormPtr form, Boolean draw)
{
    Coord         x, y;
    RectangleType r, erase_rect;

    WinGetDisplayExtent(&x, &y);

    FrmGetFormBounds(form, &r);

    erase_rect           = r;

    r.topLeft.y = (y - r.extent.y) / 2 ;
    r.topLeft.x = (x - r.extent.x) / 2;

    if (r.topLeft.y > 0 &&  r.topLeft.x > 0) {
        if (draw)
        {
            WinEraseRectangle(&erase_rect, 0);
        }    

        WinSetWindowBounds(FrmGetWindowHandle(form), &r);
        return true;
    } else
        return false;
}

Boolean
UtilCheckSizeForm(FormPtr form, Boolean draw)
{
    Coord         x, y;
    RectangleType r;

    WinGetDisplayExtent(&x, &y);

    FrmGetFormBounds(form, &r);

    if (draw)
    {
        WinEraseRectangle(&r, 0);
    }    
    
    if ((r.extent.y > y) || (r.extent.x > x))
        return false;

    r.topLeft.y = y - r.extent.y - 2;
    r.topLeft.x = ((x - r.extent.x) / 2);

    WinSetWindowBounds(FrmGetWindowHandle(form), &r);
    return true;
}
#endif

Boolean
UtilRctPtInRectangle( Int16 x, Int16 y, RectangleType *r)
{
#ifdef CONFIG_SONY
    if( FeatureSetSony){
        if ( (x > r->topLeft.x && x < (r->extent.x + r->topLeft.x)) &&
             (y > r->topLeft.y && y < (r->extent.y + r->topLeft.y)))
            return true;
        else
            return false;
    } else
#endif
    return RctPtInRectangle(x, y, r);
}

Boolean IsInt( char *str ) {
  UInt16 i = 0;
  

  if ( str[i] == '-' ) i++;

  for( ; str[i] != '\0'; i++ ) {
	if ( str[i] < '0' || str[i] > '9' ) return 0;
  }
  return 1;
}

Boolean IsFloat( char *str ) {
  int i = 0;
  
  if ( str[i] == '-' ) i++;  
  while( str[i] >= '0' && str[i] <= '9' ) i++;
  if ( !str[i] ) return 1;
  if ( str[i] == LocalInfo.decimalChar ) i++;
  while( str[i] >= '0' && str[i] <= '9' ) i++;
  if ( !str[i] ) return 1;
  
  return 0;
}

Boolean IsDate( char *str, Date *date ) {
  int i = 0;
  UInt16 m, d, y;
  
  m = d = y = 0;
  while( str[i] >= '0' && str[i] <= '9' ) {
	m *= 10;
	m += str[i++] - '0';
  }
  if ( str[i++] != LocalInfo.dateChar ) return 0;
  while( str[i] >= '0' && str[i] <= '9' ) {
	d *= 10;
	d += str[i++] - '0';
  }
  if ( str[i++] != LocalInfo.dateChar ) return 0;
  while( str[i] >= '0' && str[i] <= '9' ) {
	y *= 10;
	y += str[i++] - '0';
  }
  switch ( LocalInfo.dateOrder ) {
  case YMD:
	date->year = m; 	date->month = d;	date->day = y;	    break;
  case DMY:
	date->day = m;	    date->month = d;	date->year = y;	break;
  case MDY:
	date->month = m;	date->day = d;  	date->year = y;	break;
  }
  
  if ( date->year < 30 ) date->year += 2000;
  if ( date->year < 100 ) date->year += 1900;
  if ( date->month > 12 || date->month < 1 ) return 0;
  if ( date->day > DaysInMonth( date->month, date->year ) ) return 0;

  
  return 1;
}


Boolean IsTime( char *str, Time *t ) {
  
  int i = 0;

  t->hour = t->min = 0;
  while( str[i] >= '0' && str[i] <= '9' ) {
	t->hour *= 10;
	t->hour += str[i++] - '0';
  }
  if ( t->hour > 24 || str[i++] != ':' ) return 0;
  while( str[i] >= '0' && str[i] <= '9' )  {
	t->min *= 10;
	t->min += str[i++] - '0';
  }
  if ( t->min > 59 ) return 0;

  return 1;
}



void
Localize()
{
    UInt16 pref;

	// localize decimal character
    pref = PrefGetPreference( prefNumberFormat);
	
	if ( pref == nfPeriodComma ||
		 pref == nfSpaceComma ||
		 pref == nfApostropheComma ) {
        LocalInfo.decimalChar = ',';
	}
	else {
        LocalInfo.decimalChar = '.';
	}

	pref = PrefGetPreference( prefDateFormat );
	if ( pref == dfMDYWithDashes ||
		 pref == dfDMYWithDashes ||
		 pref == dfYMDWithDashes ) {
	  LocalInfo.dateChar = '-';	  
    }
	else if ( pref == dfDMYWithDots ||
			  pref == dfYMDWithDots ) {
	  LocalInfo.dateChar = '.';
	}
	else LocalInfo.dateChar = '/';
	
	if ( pref == dfMDYWithDashes ||
		 pref == dfMDYWithSlashes ) {
	  LocalInfo.dateOrder = MDY;
	}
	else if ( pref == dfYMDWithDashes ||
			  pref == dfYMDWithDots ||
			  pref == dfYMDWithSlashes ) {
	  LocalInfo.dateOrder = YMD;
	}
	else 
	  LocalInfo.dateOrder = DMY;

}
