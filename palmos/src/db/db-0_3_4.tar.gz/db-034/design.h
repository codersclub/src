#ifndef _DESIGN_H_
#define _DESIGN_H_

typedef struct
{
    MemHandle name;            /* Handle used for this field's name. */
    UInt32 uniqueID;           /* Unique ID number for changed/new fields. */
    DataSourceFieldType type;  /* Type of data for this field. */
    Char old_name[33];         /* Old name of this field (for the label). */
    Boolean lock;
    Boolean resetData;
    DataSourceFieldData data;
} SchemaDesignField;


#endif
