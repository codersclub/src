/*
 * DB: Database and Application Preference Dialogs
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif
#include "grid.h"
#include "prefs.h"

#include "util.h"
#include "enum.h"


DBPrefsType DBPrefs;

static void SetDirectionList( FormPtr form, UInt16 triggerID, UInt16 listID,
                        Char **labels, UInt16 numLabels, UInt16 pref) EDITSECT;

#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))

void
InitPrefs(DBPrefsPtr prefs)//, GridPrefsPtr gprefs)
{
    MemSet(prefs, sizeof(*prefs), 0);

    prefs->flags = prefFlagPageUpPage
    | prefFlagPageDownPage | prefFlagRecordUpPage
    | prefFlagRecordDownPage | prefFlagUnuseFilters;
    prefs->ChooserCurrentCategory = dmAllCategories;
    prefs->ChooserShowAllCategories = true;
    prefs->ChooserSortOrder = chooserSortOrderManual;

#ifdef CONFIG_HANDERA
    if (FeatureSetHandera) {
        prefs->TheStdFont = VgaBaseToVgaFont(stdFont);
        prefs->TheBoldFont = VgaBaseToVgaFont(boldFont);
    } else
#endif
#ifdef CONFIG_SONY
    if (FeatureSetSony) {
        prefs->TheStdFont = hrStdFont;
        prefs->TheBoldFont = hrBoldFont;
    } else
#endif
    {
        prefs->TheStdFont = stdFont;
        prefs->TheBoldFont = boldFont;
    }

    prefs->GridDisplay = Display_Header;
    prefs->FloatDigits = 1;
    prefs->ColumnWidth = 80;

    prefs->ChooserForceRescan = true;
    PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, DBPrefsVersion,
                      prefs, sizeof(DBPrefsType), false);
}

void
PopupDBPrefs(void)
{
    FormPtr form, oldForm;
    ControlPtr ctl;
    LocalID dbID;
    UInt16 cardNo, attr, i;
    Boolean DisableFind;

    DmOpenDatabaseInfo(CurrentSource->db, &dbID, 0, 0, &cardNo, 0);
    DmDatabaseInfo(cardNo, dbID, 0, &attr, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    if (CurrentSource->ops.GetOption_Boolean)
        DisableFind =
            CurrentSource->ops.GetOption_Boolean(CurrentSource,
                                                 optionID_DisableGlobalFind);
    else
      DisableFind = false;

    oldForm = FrmGetActiveForm();
    form = FrmInitForm(formID_DBPrefs);
    FrmSetActiveForm(form);
#ifdef CONFIG_HANDERA
    if (FeatureSetHandera) {
        VgaFormModify(form, vgaFormModify160To240);
        UtilCenterForm(form, false);
    }
#endif

    ctl = GetObjectPtr(form, ctlID_DBPrefs_BackupDB);
    CtlSetValue(ctl, ((attr & dmHdrAttrBackup) == dmHdrAttrBackup) ? 1 : 0);

    ctl = GetObjectPtr(form, ctlID_DBPrefs_DisableFind);
    CtlSetValue(ctl, DisableFind ? 1 : 0);

    if (FrmDoDialog(form) == ctlID_DBPrefs_OkayButton) {
        ctl = GetObjectPtr(form, ctlID_DBPrefs_BackupDB);
        i = CtlGetValue(ctl);
        if (i)
            attr |= dmHdrAttrBackup;
        else
            attr &= ~(dmHdrAttrBackup);
        DmSetDatabaseInfo(cardNo, dbID, 0, &attr, 0, 0, 0, 0, 0, 0, 0, 0, 0);

        ctl = GetObjectPtr(form, ctlID_DBPrefs_DisableFind);
        i = CtlGetValue(ctl);
        if (i && !DisableFind)
            CurrentSource->ops.SetOption_Boolean(CurrentSource,
                                                 optionID_DisableGlobalFind,
                                                 true);
        else if (!i && DisableFind)
            CurrentSource->ops.SetOption_Boolean(CurrentSource,
                                                 optionID_DisableGlobalFind,
                                                 false);
    }

    FrmDeleteForm(form);
    FrmSetActiveForm(oldForm);
}

static void
SetDirectionList( FormPtr form, UInt16 triggerID, UInt16 listID,
                        Char **labels, UInt16 numLabels, UInt16 pref)
{
    ControlPtr ctl;
    ListType * lst;

    ctl = GetObjectPtr(form, triggerID);
    lst = GetObjectPtr(form, listID);
    LstSetListChoices(lst, labels, numLabels);
    LstSetHeight(lst, numLabels);
    if ((DBPrefs.flags & pref) == pref) {
        CtlSetLabel(ctl, labels[1]);
        LstSetSelection(lst, 1);
    } else {
        CtlSetLabel(ctl, labels[0]);
        LstSetSelection(lst, 0);
    }
}

static void
AppPrefsSetupForm(FormPtr form, Char **labels)
{
    char * fldTxt;
    ControlPtr ctl;
    FieldPtr fld;
    MemHandle textH;
    UInt16 i;

    fld = GetObjectPtr(form, ctlID_AppPrefs_FloatDigit);
    textH = FldGetTextHandle(fld);
    if (!textH)
        textH = AllocateMemHandle(11);
    else
        FldSetTextHandle (fld, NULL);
    fldTxt = MemHandleLock( textH);
    StrIToA( fldTxt, DBPrefs.FloatDigits);
    MemPtrUnlock(fldTxt);
    FldSetTextHandle (fld, textH);
    FldDrawField(fld);

    fld = GetObjectPtr(form, ctlID_AppPrefs_ColumnWidth);
    textH = FldGetTextHandle(fld);
    if (!textH)
        textH = AllocateMemHandle(11);
    else
        FldSetTextHandle (fld, NULL);
    fldTxt = MemHandleLock( textH);
    StrIToA( fldTxt, DBPrefs.ColumnWidth);
    MemPtrUnlock(fldTxt);
    FldSetTextHandle (fld, textH);
    FldDrawField(fld);

    ctl = GetObjectPtr(form, ctlID_AppPrefs_ShowHeader);
    i = ((DBPrefs.GridDisplay & Display_Header) == Display_Header) ? 1 : 0;
    CtlSetValue(ctl, i);

    ctl = GetObjectPtr(form, ctlID_AppPrefs_ShowSeparator);
    i = ((DBPrefs.GridDisplay & Display_Col_sep) == Display_Col_sep) ? 1 : 0;
    CtlSetValue(ctl, i);

    ctl = GetObjectPtr(form, ctlID_AppPrefs_EnableFind);
    i = ((DBPrefs.flags & prefFlagEnableFind) == prefFlagEnableFind) ? 1 : 0;
    CtlSetValue(ctl, i);

    ctl = GetObjectPtr(form, ctlID_AppPrefs_RDWRMode);
    i = ((DBPrefs.flags & prefFlagOpenRDWRMode) == prefFlagOpenRDWRMode) ? 1 : 0;
    CtlSetValue(ctl, i);

    ctl = GetObjectPtr(form, ctlID_AppPrefs_UseFilters);
    i = ((DBPrefs.flags & prefFlagUnuseFilters) == prefFlagUnuseFilters) ? 0 : 1;
    CtlSetValue(ctl, i);
	
	/* sw begin */
    ctl = GetObjectPtr(form, ctlID_AppPrefs_RRAfterEdit);
    i = ((DBPrefs.flags & prefFlagRRAfterEdit) == prefFlagRRAfterEdit) ? 1 : 0;
    CtlSetValue(ctl, i);
	/* sw end */

    SetDirectionList(form, ctlID_AppPrefs_Trigger1, ctlID_AppPrefs_List1,
                        labels, 2, prefFlagUpArrowPage);
    SetDirectionList(form, ctlID_AppPrefs_Trigger2, ctlID_AppPrefs_List2,
                        labels, 2, prefFlagDownArrowPage);
    SetDirectionList(form, ctlID_AppPrefs_Trigger3, ctlID_AppPrefs_List3,
                        labels, 2, prefFlagPageUpPage);
    SetDirectionList(form, ctlID_AppPrefs_Trigger4, ctlID_AppPrefs_List4,
                        labels, 2, prefFlagPageDownPage);
    SetDirectionList(form, ctlID_AppPrefs_Trigger5, ctlID_AppPrefs_List5,
                        labels, 2, prefFlagRecordUpPage);
    SetDirectionList(form, ctlID_AppPrefs_Trigger6, ctlID_AppPrefs_List6,
                        labels, 2, prefFlagRecordDownPage);

}

static void
AppPrefsFreeForm(FormPtr form, Char **labels)
{
    FieldPtr fld;
    MemHandle textH;

    fld = GetObjectPtr(form, ctlID_AppPrefs_FloatDigit);
    textH = FldGetTextHandle( fld);
    FldSetTextHandle( fld, NULL);
    DeallocateMemHandle(textH);
    
    fld = GetObjectPtr(form, ctlID_AppPrefs_ColumnWidth);
    textH = FldGetTextHandle( fld);
    FldSetTextHandle( fld, NULL);
    DeallocateMemHandle(textH);

    if (labels[0]) {
        DeallocateMemPtr(labels[0]);
        DeallocateMemPtr(labels[1]);
        labels[0] = labels[1] = 0;
    }

}

Boolean
AppPrefsHandleEvent(EventPtr event)
{
    UInt16 ButtonsObjectsTable[] =
    {
        9000,
        9001,
        9002,
        9003,
        9004,
        9005,
        9007,
        9008,
        ctlID_AppPrefs_Trigger1,
        ctlID_AppPrefs_List1,
        ctlID_AppPrefs_Trigger2,
        ctlID_AppPrefs_List2,
        ctlID_AppPrefs_Trigger3,
        ctlID_AppPrefs_List3,
        ctlID_AppPrefs_Trigger4,
        ctlID_AppPrefs_List4,
        ctlID_AppPrefs_Trigger5,
        ctlID_AppPrefs_List5,
        ctlID_AppPrefs_Trigger6,
        ctlID_AppPrefs_List6,
        0
    };
    
    UInt16 ActionsObjectsTable[] =
    {
        ctlID_AppPrefs_EnableFind,
        ctlID_AppPrefs_RDWRMode,
        ctlID_AppPrefs_UseFilters,
		ctlID_AppPrefs_RRAfterEdit,
        0
    };
    
    UInt16 DisplayObjectsTable[] =
    {
        9010,
        9011,
        9012,
        ctlID_AppPrefs_Font,
        ctlID_AppPrefs_FloatDigit,
        ctlID_AppPrefs_ColumnWidth,
        ctlID_AppPrefs_ShowHeader,
        ctlID_AppPrefs_ShowSeparator,
        0
    };

    FormPtr form;
    static UInt16 *objectsList;
    ControlPtr ctl;
    FieldPtr fld;
    UInt16 i;
    static Char * Labels[3] = { 0, 0, 0 };
    FontID tempoFont;

    switch (event->eType) {
    case frmOpenEvent:
    {
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
            if (!UtilCheckSizeForm(form, 0)) {
                FrmAlert(alertID_FormTooBig);
                FrmReturnToForm(0);
                return true;
            }
        }
#endif

        Labels[0] = CopyStringResource(stringID_Line);
        Labels[1] = CopyStringResource(stringID_Page);

        AppPrefsSetupForm(form, Labels);

        ctl = GetObjectPtr(form, ctlID_AppPrefs_PrefActions);
        CtlSetValue(ctl, 1);

        FrmUpdateForm( FrmGetActiveFormID(), ctlID_AppPrefs_PrefActions);
        FrmDrawForm(form);

    }
    return true;
    case frmCloseEvent:
        form = FrmGetActiveForm();
        AppPrefsFreeForm (form, Labels);
    return true;
    case frmUpdateEvent:
        form = FrmGetActiveForm();
        switch (event->data.frmUpdate.updateCode) {
        case ctlID_AppPrefs_PrefButtons:
            objectsList = ButtonsObjectsTable;
        break;
        case ctlID_AppPrefs_PrefActions:
            objectsList = ActionsObjectsTable;
        break;
        case ctlID_AppPrefs_PrefDisplay:
            objectsList = DisplayObjectsTable;
        break;
        }
#define HideObject(f,id) FrmHideObject((f),FrmGetObjectIndex((f),(id)))
#define ShowObject(f,id) FrmShowObject((f),FrmGetObjectIndex((f),(id)))
        i = 0;
        while(ButtonsObjectsTable[i] != 0) HideObject(form, ButtonsObjectsTable[i++]);
        i = 0;
        while(ActionsObjectsTable[i] != 0) HideObject(form, ActionsObjectsTable[i++]);
        i = 0;
        while(DisplayObjectsTable[i] != 0) HideObject(form, DisplayObjectsTable[i++]);
        i = 0;
        while(objectsList[i] != 0) ShowObject(form, objectsList[i++]);
#undef HideObject
#undef ShowObject
    return true;
    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case ctlID_AppPrefs_OkayButton:
            form = FrmGetActiveForm();

            fld = GetObjectPtr(form, ctlID_AppPrefs_FloatDigit);
            if (FldDirty(fld)) {
                DBPrefs.FloatDigits = (UInt16) StrAToI(FldGetTextPtr(fld));
            }

            fld = GetObjectPtr(form, ctlID_AppPrefs_ColumnWidth);
            if (FldDirty(fld)) {
                DBPrefs.ColumnWidth = (UInt16) StrAToI(FldGetTextPtr(fld));
            }

            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_ShowHeader));
            if (i != 0)
                DBPrefs.GridDisplay |= (Display_Header|Display_Header_sep);
            else
                DBPrefs.GridDisplay &= ~(Display_Header|Display_Header_sep);

            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_ShowSeparator));
            if (i != 0)
                DBPrefs.GridDisplay |= Display_Col_sep;
            else
                DBPrefs.GridDisplay &= ~(Display_Col_sep);

            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_EnableFind));
            if (i != 0)
                DBPrefs.flags |= prefFlagEnableFind;
            else
                DBPrefs.flags &= ~(prefFlagEnableFind);

            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_RDWRMode));
            if (i != 0)
                DBPrefs.flags |= prefFlagOpenRDWRMode;
            else
                DBPrefs.flags &= ~(prefFlagOpenRDWRMode);

            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_UseFilters));
            if (i != 0)
                DBPrefs.flags &= ~(prefFlagUnuseFilters);
            else
                DBPrefs.flags |= prefFlagUnuseFilters;

			/* sw begin */
            i = CtlGetValue(GetObjectPtr(form, ctlID_AppPrefs_RRAfterEdit));
            if (i != 0)
                DBPrefs.flags |= prefFlagRRAfterEdit;
            else
                DBPrefs.flags &= ~(prefFlagRRAfterEdit);
           /* sw end */

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List1));
            if (i != 0)
                DBPrefs.flags |= prefFlagUpArrowPage;
            else
                DBPrefs.flags &= ~(prefFlagUpArrowPage);

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List2));
            if (i != 0)
                DBPrefs.flags |= prefFlagDownArrowPage;
            else
                DBPrefs.flags &= ~(prefFlagDownArrowPage);

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List3));
            if (i != 0)
                DBPrefs.flags |= prefFlagPageUpPage;
            else
                DBPrefs.flags &= ~(prefFlagPageUpPage);

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List4));
            if (i != 0)
                DBPrefs.flags |= prefFlagPageDownPage;
            else
                DBPrefs.flags &= ~(prefFlagPageDownPage);

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List5));
            if (i != 0)
                DBPrefs.flags |= prefFlagRecordUpPage;
            else
                DBPrefs.flags &= ~(prefFlagRecordUpPage);

            i = LstGetSelection(GetObjectPtr(form, ctlID_AppPrefs_List6));
            if (i != 0)
                DBPrefs.flags |= prefFlagRecordDownPage;
            else
                DBPrefs.flags &= ~(prefFlagRecordDownPage);

             /* Force the new value to be in the preferences. */
            PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, DBPrefsVersion,
                              &DBPrefs, sizeof(DBPrefs), false);

        case ctlID_AppPrefs_CancelButton:
            form = FrmGetActiveForm();
            AppPrefsFreeForm (form, Labels);
            FrmReturnToForm(0);
            FrmUpdateForm( FrmGetActiveFormID(), updateFontChanged);
        return true;
        case ctlID_AppPrefs_DefaultButton:
            form = FrmGetActiveForm();
            InitPrefs(&DBPrefs);
            AppPrefsSetupForm(form, Labels);
            FrmUpdateForm( FrmGetActiveFormID(), ctlID_AppPrefs_PrefActions);
        return true;
        case ctlID_AppPrefs_PrefButtons:
            FrmUpdateForm( FrmGetActiveFormID(), ctlID_AppPrefs_PrefButtons);
        return true;
        case ctlID_AppPrefs_PrefActions:
            FrmUpdateForm( FrmGetActiveFormID(), ctlID_AppPrefs_PrefActions);
        return true;
        case ctlID_AppPrefs_PrefDisplay:
            FrmUpdateForm( FrmGetActiveFormID(), ctlID_AppPrefs_PrefDisplay);
        return true;
        case ctlID_AppPrefs_Font:
#ifdef CONFIG_HANDERA
            if (FeatureSetHandera){
                DBPrefs.TheStdFont = VgaFontSelect( vgaFontSelectVgaText, DBPrefs.TheStdFont);
                tempoFont = VgaVgaToBaseFont( DBPrefs.TheStdFont);
                FntSetFont( DBPrefs.TheStdFont);
            } else
#endif
#ifdef CONFIG_SONY
            if (FeatureSetSony && SonyLibRefNum){
                if (FrmAlert( alertID_TypeFontSelect))
                    DBPrefs.TheStdFont = HRFontSelect( SonyLibRefNum, DBPrefs.TheStdFont);
                else
                    DBPrefs.TheStdFont = FontSelect( DBPrefs.TheStdFont);
                tempoFont = (DBPrefs.TheStdFont > 7)? DBPrefs.TheStdFont - 8: DBPrefs.TheStdFont;
                HRFntSetFont(SonyLibRefNum, DBPrefs.TheStdFont);
            }
            else 
#endif
            {
                DBPrefs.TheStdFont = FontSelect( DBPrefs.TheStdFont);
                tempoFont = DBPrefs.TheStdFont;
                FntSetFont( DBPrefs.TheStdFont);
            }
            switch (tempoFont) {
            case stdFont:
            case boldFont:
                DBPrefs.TheBoldFont = (DBPrefs.TheStdFont - tempoFont) + boldFont;
            break;
            case largeFont:
            case largeBoldFont:
                DBPrefs.TheBoldFont = (DBPrefs.TheStdFont - tempoFont) + largeBoldFont;
            break;
            default:
                DBPrefs.TheBoldFont = boldFont;
            }
        return true;
        }
    default:
    }
    return false;

}
