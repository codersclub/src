#ifndef _DB_H
#define _DB_H

#include <PalmOS.h>

#include "leakdetect.h"
#include "datasource.h"
#include "config.h"

#define DBCreatorID 'DBOS'
#define DBTypeID 'DB99'
#define DBHelpTypeID 'HELP'
#define DBPrefsVersion 0

#define offsetof(s,m) ( ((ULong) (&(s).m)) - ((ULong)&(s)) )

/* redefine the PalmOS 3.5 function TblGetItemPtr*/
#ifdef CONFIG_PALMOS31
#undef TblGetItemPtr
#define TblGetItemPtr(table, row, column)(table->items[row * table->numColumns + column].ptr)
#endif

#define updateFontChanged 0x80

typedef struct {
    Char name[33];
    UInt16 fieldNum;
    UInt32 uniqID;
} LinkType;
typedef LinkType * LinkPtr;

extern DataSourceSchema *DesignViewInitialSchema;
extern DataSourceDriver *DesignViewDriver;
extern char *DesignViewName;
extern DataSource * CurrentSource;
extern UInt16 CurrentRecord;
extern Boolean DesignNewDB;
extern UInt16 TopVisibleRecord;
extern UInt16 CurrentCategory;
extern Boolean IsNewRecord;
extern privateRecordViewEnum PrivateRecordStatus;
extern DataSourceDriver * DriverList;
extern UInt16 ListViewEditor_ViewNum;

/* Macros to allow functions to be placed in other code sections. */
#ifdef __GNUC__
#define SECT_HND  __attribute__ ((__section__("hndsect")))
#define SECT_UI  __attribute__ ((__section__("ui1sect")))
#define SECT_UI2 __attribute__ ((__section__("ui2sect")))
#define EDITSECT __attribute__ ((__section__("editsect")))
#else
#define SECT_HND
#define SECT_UI
#define SECT_UI2
#define EDITSECT
#endif

/* Keep track of what features this PalmOS version has. */
extern Boolean FeatureSet30, FeatureSet31, FeatureSet32, FeatureSet35, FeatureSet40;
extern Boolean FeatureSetHandera, FeatureSetSony;
extern UInt32 WinDepth;
#ifdef CONFIG_SONY
extern UInt16 SonyLibRefNum;
#endif
#ifdef CONFIG_HANDERA
extern char * RotateString;
#endif

extern Boolean ChooserHandleEvent(EventPtr) SECT_HND;
extern Boolean DesignViewHandleEvent(EventPtr) SECT_HND;
extern Boolean ListViewHandleEvent(EventPtr) SECT_HND;
extern Boolean FindDialogHandleEvent(EventPtr) SECT_HND;
extern Boolean EditViewHandleEvent(EventPtr) SECT_HND;
extern Boolean ListViewEditorHandleEvent(EventPtr event) SECT_HND;
extern Boolean ChooserInfoDialogHandleEvent(EventPtr) SECT_HND;
extern Boolean DuplicateDlgHandleEvent(EventPtr event) SECT_HND;
extern Boolean CreateDlgHandleEvent(EventPtr event) SECT_HND;
extern Boolean RenameDlgHandleEvent(EventPtr event) SECT_HND;
extern Boolean SortEditor_HandleEvent(EventPtr event) SECT_HND;
extern Boolean NamesEditorHandleEvent(EventType* event) SECT_HND;
extern Boolean HandleCommonMenuEvent(UInt16 menuitemID) SECT_HND;
extern Boolean NoteHandleEvent(EventPtr event) SECT_HND;
extern Boolean FieldPropertiesHandleEvent(EventPtr event) SECT_HND;
extern Boolean AppPrefsHandleEvent(EventPtr event) SECT_HND;
extern Boolean LinkSelectHandleEvent( EventPtr event) SECT_HND;
#ifdef CONFIG_ABOUT
extern Boolean AboutHandleEvent(EventPtr event) SECT_HND;
#endif

extern void    DbgPrintF(const Char * fmt, ...) ;
extern char*   GetStringResource(UInt16 stringID);
extern void    PutStringResource(const char * str);
extern char *  CopyStringResource(UInt16 stringID);
extern void GlobalSearch(FindParamsPtr params);

/*this functions must be in the main section of the application*/
/*the global search load only the main section*/
extern Boolean IsNumber(const char * s);
extern Int32   String2Long(const char * cp);
extern Boolean MatchString(const char *, const char *, Boolean, Boolean);

typedef struct
{
    UInt16 sourceID;
    Char title[32];
    /* variable-sized key data follows the above fixed portion */
} ChooserRecord;

extern void Chooser_Open(void);
extern void Chooser_Close(void);
extern Boolean Chooser_Seek(UInt16 * indexP, Int16 offset, Int16 direction);
extern DmOpenRef Chooser_Ref(void);
#if 0
extern void Chooser_AddDatabase(const char *title, UInt16 sourceID,
				void * key_data, UInt16 key_size) ;
#endif
extern void Chooser_RescanDatabases(void);
extern void Chooser_RenameDatabase(UInt16 sourceID,
				   void * old_key_data, UInt16 old_key_size,
				   void * new_key_data, UInt16 new_key_size,
				   const char* new_title) ;

extern Boolean CmpField(DataSource * source, DataSourceGetter* getter,
                void* rec_data, UInt16 i, const char* str,
                Boolean caseSens, Boolean wholeWord) SECT_UI2;

/*link.c functions*/
extern void LinkGo( UInt32 chooserRecordID, UInt16 fieldNum, LinkPtr link) SECT_UI2;
extern Boolean LinkSelect( UInt32 chooserRecordID, UInt16 filedNum, LinkPtr link) SECT_UI2;
extern Boolean LinkUpdate( UInt32 chooserRecordID, UInt16 fieldNum, LinkPtr link) SECT_UI2;
extern Boolean LinkIsUsefull( UInt32 chooserRecordID) SECT_UI2;

/*duplicate.c function*/
extern void DuplicateDatabase(DataSource *src, DataSourceDriver * driver,
            const char* dst_title, Boolean everything) SECT_UI2;
extern DataSource * RebuildDatabase(DataSource * src, DataSourceSchema * schema,
            UInt32 * reorder) SECT_UI2;

#endif
