#!/usr/bin/perl
#
# Escape strings so that they pass through pilrc. This is useful for the
# strings in ja.rcp which are Unicode.

while (<>) {
    chomp;
    my $pos = index($_, '=');
    if ($pos != -1) {
	my $pos1 = index($_, '"', $pos + 1);
	my $str = substr($_, $pos1 + 1);

	my $rpos = rindex($str, '"');
	$str = substr($str, 0, $rpos);

	my $orig_str = $str;

	$str =~ s/\\/\\\\/g;
	$str =~ s/\033/\\e/g;
	$str =~ s/"/\\"/g;

	substr($_, $pos1 + 1, length($orig_str)) = $str;
    }
    print "$_\n";
}
