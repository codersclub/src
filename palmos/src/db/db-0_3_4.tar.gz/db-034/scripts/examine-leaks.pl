#!/usr/bin/perl

@usage = ( 0 , 0, 0 );
@max_usage = (0, 0, 0 );

$total_usage = 0;
$pointer_usage = 0;
$handle_usage = 0;
$max_usage = 0;
# go through each line in leaks file and find
# unmatched new_allocs (those without corresponding
# new_free)


while (<>) {
    @line = split;
    if (($type) = ($line[0] =~ /(.)a/)) {
		$addr = $line[1];
		$size = $line[2];
		$allocs{$addr} = $size;
		$full_lines{$addr} = $_;

		if ( $type eq 'h' ) { 
			$type_i = 1;			
		} elsif ( $type eq 'p' ) {
			$type_i = 0;
		} else {
			print "Error: unknown allocation source '$type'\n";
		}
				
		$usage[$type_i] += hex( $line[2] );
		$max_usage[$type_i] = $usage[$type_i] > $max_usage[$type_i] ? $usage[$type_i] : $max_usage[$type_i];
		
		$usage[2] = $usage[0] + $usage[1];
		$max_usage[2] = $usage[2] > $max_usage[2] ? $usage[2] : $max_usage[2];

    } elsif ( ($type) = ($line[0] =~ /(.)f/) )  {
		$addr = $line[1];
		if ( exists( $allocs{$addr} ) ) {
			$size = $allocs{$addr};
			delete $allocs{$addr};
			delete $full_lines{$addr};
			delete $info{$addr};

			if ( $type eq 'h' ) { 
				$type_i = 1;			
			} elsif ( $type eq 'p' ) {
				$type_i = 0;
			} else {
				print "Error: unknown allocation source '$type'\n";
			}
			$usage[$type_i] -= hex($size);

			$usage[2] = $usage[0] + $usage[1]
		}

    } elsif ( $line[0] =~ /i/ )  {
		$info{$line[1]} = $_;

	} else {
		print "Error: unknown line type $line[0]\n";
	}

}
$n = 0;
foreach $key (keys %full_lines) {
	$line = $full_lines{$key};
	print "memory leaked: $line";
	if ( exists $info{$key} ) {
		print " - info : ".$info{$key};
	}
	$n++;
}
print "---------------------------------------------------------\n";
print "Max usage (ptrs, handles, total): ($max_usage[0], $max_usage[1], $max_usage[2])\n";
print "Total Leaks = $n\n";
