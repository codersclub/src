/***********************************************************************
 pdouble.c - Contains a routine to print double-precision floating
    point numbers and associated routines, written by Fred Bayer,
    author of LispMe.  It is available from
    http://www.lispme.de/lispme/gcc/tech.html

 This version was formatted and tweaked slightly by Warren Young
    <tangent@cyberport.com>
 This routine is in the Public Domain.
***********************************************************************/
/* Macros to allow functions to be placed in other code sections. */

#if EMULATION_LEVEL != EMULATION_NONE
    // Simulator builds must use the Flp* functions and likely want to
    // use _d_mul etc instead of native operators.
    #undef USE_OPERATORS_AND_BUFFERED_FUNCTIONS
#elif defined __GNUC__
    // Programs compiled with m68k-palmos-gcc for a Palm OS device *must*
    // use both operators and FlpBuffer* functions.
    #define USE_OPERATORS_AND_BUFFERED_FUNCTIONS
#else
    // Programs compiled with CodeWarrior for Palm OS can use either
    // Flp* or FlpBuffer* functions, and can use the _d_mul etc fuctions
    // (provided FloatMgr.h has been #included) or can use fp operators
    // explicitly (provided that the Code Generation:68K Processor:Floating
    // Point setting is set to "PalmOS").

    // Either one of these can be uncommented
    #define USE_OPERATORS_AND_BUFFERED_FUNCTIONS
    //#undef USE_OPERATORS_AND_BUFFERED_FUNCTIONS
#endif


//#define _DONT_USE_FP_TRAPS_ 1
#include <PalmTypes.h>
#include <PalmCompatibility.h>
#include <FloatMgr.h>
#include <PalmOSGlue.h>
#include <CoreTraps.h>
#include "db.h"
#include "double.h"
#include "util.h"


/**********************************************************************/
/* Formatting parameters                                              */
/**********************************************************************/
#define NUM_DIGITS   15
#define MIN_FLOAT    4
#define ROUND_FACTOR 1.0000000000000005 /* NUM_DIGITS zeros */

void SysTrapBinOp( FlpDouble *, FlpDouble, FlpDouble)SYS_TRAP(sysTrapFlpEmDispatch);

double
DoubleDiv( double a, double b  ) 
{
    return a/b;
}

double
DoubleAdd( double a, double b ) {
  return a+b;
}

double
DoubleMul( double a, double b ) {
  return a*b;
}

double
DoubleSub( double a, double b ) {
  return a-b;
}

double
DoubleIToD( int i)
{
    return (double)i;
}


Int32
DoubleComp( FlpDouble fd1, FlpDouble fd2)
{
    return _d_cmp( fd1, fd2);
}



void
DoublePrintValue(double x, char *s, UInt16 nbDigits)
{
    FlpCompDouble   X;
	double rounder;
    Err             theErr;
    UInt32  xMantissa = 0;
    Int16 xExponent = 0;
    Int16 xSign = 0;
    Int16   xDecimalPos = 0;
    Int16   count = 0;
    Int16   xDecimalDigits = 0;
    Char    *mantissaStrP, *dispMantissaStrP;
    Char    mantissaStr[kMaxMantissaDigits+2];      // allow for '-' and '\0'
    Char    dispMantissaStr[kMaxMantissaDigits+4];  // allow for '-0.' and '\0 
    UInt16 i;

    if (!nbDigits) nbDigits = 1;

	X.d = x;
	if ( (X.ul[0] & 0x7ff00000) == 0x7ff00000 ) {
	  if ( X.fdb.manH == 0 && X.fdb.manL == 0 ) {
		if ( X.fdb.sign )
		  StrCopy( s, "[-inf]" );
		else
		  StrCopy( s, "[inf]" );
	  }
	  else StrCopy( s, "[nan]" );
	  return;
	}

	// a slow, but decent way to round...
	if ( x < 0 ) {
	  rounder = -.1;
	  while( rounder < x ) rounder = DoubleDiv( rounder, 10.0 );
	}
	else {
	  rounder = .1;
	  while( rounder > x )  rounder = DoubleDiv( rounder, 10.0 );
	}
	for( i = 0; i < nbDigits; i++ ) {
	  rounder = DoubleDiv( rounder, 10.0 );
	}
    rounder = DoubleMul( rounder, 5.0 );

	X.d  = DoubleAdd( X.d, rounder );

	i = 0;

    theErr = FlpBase10Info(X.fd, &xMantissa, &xExponent, &xSign);
	// One might want to consider rounding since we may not be showing all digits...
	if ( theErr == flpErrOutOfRange ) {
	  // I believe that the error from this is if the 32bit mantissa is
	  // too small for what's in the double....
	  StrCopy( s, "[big]" );
	  return;
	}
	// NewFloatMgr bug: FlpBase10Info says zero is "negative", with exponent of one.
        
	if (xMantissa == 0) {
	  StrCopy (mantissaStr, "00000000");      // should really be kMaxMantissaDigits zeros
	  xExponent = 1-kMaxMantissaDigits;       // force "zero" to be displayed as 0.000
	  xSign = 0;                                      // clear the sign (NewFloatMgr bug workaround)
	} else {
	  StrIToA(mantissaStr, xMantissa);
	}
	
	if (xSign /*&& xMantissa*/) // if xMantissa was zero, we've already cleared xSign
	  s[i++] = kCharMinus;// display minus sign
	
	
	// Format the mantissa (install decimal point, etc.), and display it...
	
	if ((xExponent<=0) && (xExponent>(-kMaxMantissaDigits-nbDigits))) {
	  xDecimalPos = xExponent + kMaxMantissaDigits;   // place the decimal correctly
	  xExponent = 0;                                  // no exponent displayed
	  
	} else {
	  // xExponent > 0 || xExponent <= -8-nbDigits
	  // ex: 12345678e01 --> 1.234e08 and 12345678e-11 --> 1.234e-4

	  xDecimalPos = 1;                    // put decimal after first digit
	  xExponent += kMaxMantissaDigits-1;  // bump exponent to reflect new decimal position
	  
	}
	
	if (xDecimalPos<1) {                                        // put "0." at front of number
	  dispMantissaStr[count++] = kCharZero;
	  dispMantissaStr[count++] = LocalInfo.decimalChar;
	}
	
	while ( (xDecimalPos + xDecimalDigits) < 0) {   // add any needed zeros after decimal
	  dispMantissaStr[count++] = kCharZero;
	  xDecimalDigits++;
	}
	
	mantissaStrP = mantissaStr;
	dispMantissaStrP = dispMantissaStr;
	
	while ((count<kMaxMantissaDigits+1) && (xDecimalDigits<nbDigits)) {
	  dispMantissaStr[count++] = *mantissaStrP++;
	  if (count == xDecimalPos) {                 // put the decimal here
		dispMantissaStr[count++] = LocalInfo.decimalChar;
	  } else if (count > xDecimalPos) {           // keep track of the decimal digits
		xDecimalDigits++;
	  }
	}
	dispMantissaStr[count++] = kCharNull;           // terminate the string
	
	StrNCopy(s+i, dispMantissaStr, StrLen(dispMantissaStr));
	i += StrLen(dispMantissaStr);
	
	// Display the exponent...
	
	if (xExponent) {
	  Char    exponentStr[2];
	  
	  s[i++] = kCharExp;
	  if (xExponent<0) {
		s[i++] = kCharMinus;   // display minus sign
		xExponent = -xExponent;
	  }
	  
	  exponentStr[1] = xExponent % 10 + '0';
	  xExponent /= 10;
	  exponentStr[0] = xExponent % 10 + '0';
	  
	  StrNCopy(s+i, exponentStr, 2);
	  i +=2;
	}
    
    s[i++] = 0;
}

void 
DoubleAToD( double *d, char *string ) {

  double fractionPart, result;
  double sign, tenten = 1e10;
  char *p = string, *dp, *edp;
  Int16 exp;
  Boolean negExp;

  result = 0.0;
  fractionPart = 0.0;

  while( *p == ' ' ) p++; // eat leading white space
  
  if ( *p == kCharMinus ) {
	sign = -1.0;
	p++;
	if ( *p == '\0' ) goto ERROR;           // "-" is not a number
  }
  else sign = 1.0;
  
  /* left hand side of decimal */
  while( *p >= '0' && *p <= '9' ) {
	result = DoubleMul( result, 10.0 );	
	result = DoubleAdd( result, DoubleIToD( *p - '0' ) );

	p++;
  }
  
  /* look for decimal */
  if ( *p == LocalInfo.decimalChar ) {
	p++;

	/* find end of decimal, then move from right to left */
	edp =  p;
	while( *edp >= '0' && *edp <= '9' ) edp++;
	dp = edp - 1;
	while( dp >= p  ) {	  
	  fractionPart = DoubleDiv( fractionPart , 10.0) ;
	  fractionPart = DoubleAdd( fractionPart, DoubleIToD( *dp - '0' ) );

	  dp--;
	}
	// add the decimal to the accumulator
	fractionPart = DoubleDiv( fractionPart, 10.0 );
	result = DoubleAdd( result, fractionPart );

	p = edp;
  }

  /* look for exponent marker */
  negExp = false;
  exp = 0;
  if ( *p == kCharExp ) {
	p++;
	if ( *p == kCharMinus ) {
	  p++;
	  negExp = true;
	}
	else if ( *p == kCharPlus ) p++;
	exp = *p++ - '0';
	if ( *p >= '0' && *p <= '9' ) exp = exp * 10 + (*p++ - '0');

  }
  if ( negExp ) {
	while( exp > 10 ) { result = DoubleDiv( result, tenten ); exp -= 10; }
	while( exp-- > 0 )  result = DoubleDiv( result, 10.0 );
  }
  else {
	while( exp > 10 ) { result = DoubleMul( result, tenten ); exp -= 10; }
	while( exp-- > 0 ) result =  DoubleMul( result, 10.0 );
  }

  if ( *p != '\0' ) goto ERROR;
  
  *d = DoubleMul( result, sign );
  
  return;
  
 ERROR: 
  {
	FlpCompDouble fcd;

	fcd.ul[0] = 0x7ff00001;   // nan
	*d = fcd.d;
	return;
  }
}

