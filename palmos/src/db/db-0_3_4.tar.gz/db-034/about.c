#include <PalmOS.h>
#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif

#include "util.h"
#include "enum.h"

#define ABOUTMSG_HEADER 2
#define ABOUTMSG_ROLLOVER 20

static char *AboutMsg = NULL;
static Int8 AboutLine;

static void DrawMessage( FormPtr form, int line ) SECT_UI2;
static void DrawAboutBox() SECT_UI2;

static void
DrawMessage( FormPtr form, int line )
{
    RectangleType r;
    int i, nLinesInRect, lineHeigt;
    char *p;
    FontID oldFont;

#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum) {
        oldFont = HRFntSetFont( SonyLibRefNum, hrStdFont);
    }
    else
#endif
#ifdef CONFIG_HANDERA
    if (FeatureSetHandera) {
        oldFont = FntSetFont( VgaBaseToVgaFont(stdFont) );
    }
    else		
#endif	  
    oldFont = FntSetFont( stdFont );	  

    lineHeigt = FntLineHeight();
    FrmGetObjectBounds(form, FrmGetObjectIndex(form, ctlID_About_Display), &r);
#ifdef CONFIG_SONY
    if (FeatureSetSony){
        r.extent.x *= 2;
        r.extent.y *= 2;
        r.topLeft.x *= 2;
        r.topLeft.y *= 2;
    }
#endif
    p = AboutMsg;

    if ( !AboutMsg ) return;
    nLinesInRect = r.extent.y / lineHeigt;
    AboutLine += line;
    line = AboutLine;

    
    if ( line < -nLinesInRect ) {
        line = AboutLine = ABOUTMSG_ROLLOVER;
    }
    else if ( line > ABOUTMSG_ROLLOVER ) {
        line = AboutLine = -nLinesInRect;
    }


#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRWinEraseRectangle(SonyLibRefNum, &r, 0);
    } else
#endif
    WinEraseRectangle( &r, 0 );
    if ( line > 0 ) {
        while( line && *p ) { if (*p++ == '\n') line--; }
    }
    else {
        while( line ) { 
            nLinesInRect--; 
            r.topLeft.y += lineHeigt; 
            line++;
        }
    }
    while( *p && nLinesInRect-- > 0 ) {
        i = 0;
        while( p[i] && p[i] != '\n' ) i++;
        if ( i ) {
            UtilWinDrawTruncChars( p, i, r.topLeft.x, r.topLeft.y , r.extent.x, true);
            p = &p[i];
            if ( !*p ) break;
        }
        p++;
        r.topLeft.y += lineHeigt;
    }

#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        HRFntSetFont( SonyLibRefNum, oldFont);
    else
#endif
    FntSetFont( oldFont );

}

static void
DrawAboutBox()
{
    RectangleType r;
    MemHandle h;
    BitmapType * bitmap;
    char *str;
    int i,j;

    FontID oldFont;
    FormPtr form = FrmGetActiveForm();

#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum) {
        oldFont = HRFntSetFont( SonyLibRefNum, hrBoldFont);
    }
    else
#endif
#ifdef CONFIG_HANDERA
    if (FeatureSetHandera) {
        VgaFormModify(form, vgaFormModify160To240);
        UtilCenterForm( form, false );
        oldFont = FntSetFont( VgaBaseToVgaFont(boldFont) );
    }
    else		
#endif	  
    oldFont = FntSetFont( boldFont );	  

    FrmDrawForm( form );
	  
    // draw the bitmap
    h = DmGetResource(iconType, 1000);
    bitmap = (BitmapType *) MemHandleLock(h);
    WinDrawBitmap(bitmap, 5, 20);
    MemPtrUnlock(bitmap);
    DmReleaseResource(h);
	  
    // write version and build date
    str = AboutMsg;
    FrmGetObjectBounds(form, FrmGetObjectIndex(form, ctlID_About_HeaderDisplay), &r);
#ifdef CONFIG_SONY
    if (FeatureSetSony){
        r.extent.x *= 2;
        r.extent.y *= 2;
        r.topLeft.x *= 2;
        r.topLeft.y *= 2;
    }
#endif
    for (i = 0; i < ABOUTMSG_HEADER; i++ ) {
        j = 0;
        while( str[j] && str[j] != '\n' ) j++;
        if ( j ) {
            UtilWinDrawTruncChars( str, j, r.topLeft.x, r.topLeft.y , r.extent.x, true);
            str = &str[j];
        }
        if ( !*str ) break;
        str++;
		
        r.topLeft.y += FntLineHeight();
    }
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        HRFntSetFont( SonyLibRefNum, oldFont);
    else
#endif
    FntSetFont( oldFont );

    AboutLine = ABOUTMSG_HEADER;
    DrawMessage( form, 0 );
}

Boolean
AboutHandleEvent(EventPtr event)
{
    FormPtr form;
 
  switch (event->eType) { 
  case frmOpenEvent:	
	  AboutMsg = GetStringResource( stringID_AboutMsg );
	  DrawAboutBox();
	  break;
  case frmCloseEvent:
    goto close_AboutBox;
  case ctlRepeatEvent:
	switch (event->data.ctlSelect.controlID) {
	case ctlID_About_UpButton:
	    form = FrmGetActiveForm();
	    DrawMessage(form, -1 );  break;
	case ctlID_About_DownButton:
	    form = FrmGetActiveForm();
	    DrawMessage( form, 1 );	  break;
	default:
	  return false;
	}

  case ctlSelectEvent:
	switch (event->data.ctlSelect.controlID) {
	  
	case ctlID_About_OkButton:
	  FrmReturnToForm(0);
    goto close_AboutBox;

	default:
	  return false;
	}

  default:
	return false;
  }
  return true;

close_AboutBox:
    if (AboutMsg) {
        PutStringResource( AboutMsg );
        AboutMsg = NULL;
    }
return true;
}


