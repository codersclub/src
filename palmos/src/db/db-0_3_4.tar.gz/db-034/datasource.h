/*
 * DB: Data Source Definitions
 * Copyright (C) 2000 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef __DB_DATASOURCE_H__
#define __DB_DATASOURCE_H__

#if defined(__GNUC__)
#define SECT_DRV __attribute__ ((__section__("drvsect")))
#else
#define SECT_DRV
#endif

#include "config.h"
/*
 * Definitions used by the chooser support functions.
 */

typedef struct data_source_chooser_key {
    UInt16 cardNo;
    char name[dmDBNameLength];
} DataSourceChooserKey;


/*
 * Schema Definitions
 */
#define NOTE_MAXCHAR 3072
#define MAX_NOTE 10

typedef enum {
    FIELD_TYPE_SKIP,     /* uneditable field type that must be skipped. */
    FIELD_TYPE_STRING,   /* null-terminated string */
    FIELD_TYPE_INTEGER,  /* 32-bit signed integer */
    FIELD_TYPE_BOOLEAN,  /* true/false */
    FIELD_TYPE_DATE,     /* date */
    FIELD_TYPE_TIME,     /* time */
    FIELD_TYPE_NOTE,     /* note string more 256 char length */
    FIELD_TYPE_LIST,     /* items list*/
    FIELD_TYPE_LINK,     /* link to a database record*/
	FIELD_TYPE_FLOAT,    /* 64-bit double */
	FIELD_TYPE_CALCULATED, /* a field calculated using a script */
    FIELD_TYPE_LINKED,   /* field of another link*/
    NUM_FIELD_TYPES
} DataSourceFieldType;

#define MAX_LISTITEMS 32
typedef struct {
    Boolean changed;
    UInt32 dbID;
    UInt16 fieldNum;
}LinkData;

typedef struct {
    Boolean changed;
    UInt16 linkNum;
    UInt16 fieldNum;
}LinkedData;

typedef struct {
    Boolean changed;
    char **items;
    UInt16 numItems;
    UInt16 *uniqID;
}ListData;

typedef struct {
    Boolean changed;
    char *defaultValue;
} StringData;

typedef struct {
  Boolean changed;
  Int32 defaultValue;
  Int16 increment;
} IntegerData;

typedef struct {
  Boolean changed;
  double defaultValue;
} FloatData;

/**
 *  This structure contains information about a script used to calculate
 *  a value from fields throughout the database.  The implementation details
 *  of the script and its language are mostly hidden from db, but db does
 *  require some knowledge of what the script will do, and when it can be
 *  executed.
 *
 *   bytecode_sz  -  the amount of space needed to store the bytecode 
 *                   in bytes. 
 *   returnType   -  the type of value returned by the script, it should
 *                   be a field type, or a CV_FIELD_TYPE as defined in 
 *                   calcvalue.h
 *   access       -  the access requirements of the script.  This field
 *                   identifies when the script can be run, it is a 
 *                   bit-wise ORed set of values from the 
 *                   ScriptAccessRequirements enum
 *   scriptText   -  this is a handle to the textual (human readable)
 *                   version of the script.  It should be filled out
 *                   by translating the bytecode from the internal format
 *                   to a human readable format when the function 
 *                   source.class_ops.DecompileScript() is called.
 *   bytecode     -  this is a handle to the bytecode (executable)
 *                   form of the script.  It should be filled out
 *                   by translating the scriptText into an format that
 *                   is recognized by the script engin when the 
 *                   source.class_ops.CompileScript() function is called.
 *
 *
 */
typedef struct {
  Boolean changed;
  UInt8     bytecode_sz;    // the size of the byte code
  UInt8     returnType;     // return type of script or CV_FIELD_TYPE_UNKNOWN
  UInt8     access;         // bit OR-ed value of script's access requirements
  MemHandle scriptText;     // text representation of script is stored here
  MemHandle bytecode;       // executable representation is stored here
} CalculationData;

/**
 * These values are used to describe the access requirements of a 
 * given script.
 *
 *  see the script interface overview in calcvalue.c
 */
typedef enum script_access_requirements {
  // entirely self contained, requiring no outside data
  NO_EXTERNAL_ACCESS = 0x00, 
  // requires reading field data from a record
  FIELD_READING = 0x01,    
  // requires reading a the 'current' record
  SINGLE_RECORD_READING = 0x02,
  // requires reading more than one record
  MULTI_RECORD_READING = 0x04 | 0x02,
  // requires moving records
  ARRANGING = 0x08

} ScriptAccessRequirements;

typedef enum script_execution_context {

  // This context is used when a script is being executed to
  // calculated a field value for a specific record
  RECORD_FIELD_WRITING_CONTEXT = 0x00,
  FILTERING_CONTEXT,

} ScriptExecutionContext;

typedef struct script_exe_context {
  ScriptExecutionContext context;
  union {
	UInt16 record;
  } info;
} ScriptExeContext;


typedef struct date_struct {
  UInt16 year;
  UInt8 month;
  UInt8 day;
} Date;

typedef struct time_struct {
  UInt8 hour;
  UInt8 min;
} Time;


typedef union {
  double d;
  char *s;
  UInt16 uh;
  UInt32 ui;
  Int32   i;
  Date ymd;
  Time t;
} FieldValueUnion;


typedef struct calculated_value_struct {
  
  UInt8 info;
  FieldValueUnion value;

} CalculatedValue;

typedef union {
    Boolean changed;
    ListData list;
    StringData string;
    IntegerData integer;
    FloatData   floatNum;
    LinkData link;
    LinkedData linked;
    CalculationData calc;  
 } DataSourceFieldData;

typedef struct data_source_field_info {
    char * name;               /* name of this field */
    DataSourceFieldType type;  /* type of data stored in the field */
    Boolean lock;
    DataSourceFieldData data;
} DataSourceFieldInfo;

typedef struct data_source_schema {
    UInt16 numFields;
    DataSourceFieldInfo * fields;
} DataSourceSchema;



/*
 * View Definitions
 *
 * A data source can store one or more "views" of the data. A view
 * defines the columns displayed in the list view as well as the width
 * of each column.
 */
#define VIEWFLAG_USE_IN_EDITVIEW 0x01

typedef struct data_source_view_column {
    UInt16 fieldNum;
    UInt16 width;
} DataSourceViewColumn;

typedef struct data_source_view {
    UInt16 flags;
    Char name[32];
    int numCols;
    DataSourceViewColumn * cols;
} DataSourceView;

/*
 * Capability definitions
 *
 * A data source can various operations performed on it. However, not
 * all data source drivers support all operations. Thus, the following
 * enumeration allows a caller to ask a data source what operations it
 * can do. Note: This state is dynamic esp. if the data source is
 * opened in read-only mode.
 */

typedef enum data_source_capability {
    DS_CAPABLE_LISTVIEW_EDIT,
    DS_CAPABLE_LISTVIEW_INSERT,
    DS_CAPABLE_LISTVIEW_DELETE,
    DS_CAPABLE_LISTVIEW_NAME_EDIT,
    DS_CAPABLE_LISTVIEW_FIELD_EDIT,
    DS_CAPABLE_LISTVIEW_FIELD_INSERT,
    DS_CAPABLE_LISTVIEW_FIELD_DELETE,
    DS_CAPABLE_LISTVIEW_WIDTH_EDIT,
    DS_CAPABLE_LISTVIEW_FILTER
} DataSourceCapability;

/*
 * Filter definition
 * a database can have various filter
 */
typedef enum data_source_filter {
  FILTERNONE = 0x00,
  FILTER1 = 0x01,
  FILTER2 = 0x02,
  FILTER3 = 0x04,
  FILTER4 = 0x08,
  FILTERALL = dmAllCategories
} DataSourceFilter;

/*
 * Data Source Definitions
 *
 * A data source is an abstraction of a PalmOS database so the
 * remainder of DB does not have to deal with the specifics of how
 * records are stored into the database. Every data source has a set
 * of function pointers implementing standard operations on the data
 * source.  */

/* Forward delcarations for the structures below. */
struct data_source_operations;
struct data_source;

/* Options that can be set on a data source. */
typedef enum data_source_options_enum {
    optionID_DisableGlobalFind = 0U,
    optionID_LFind_CaseSensitive,
    optionID_LFind_WholeWord,
    optionID_ListView_ActiveView,
    optionID_ListView_TopVisibleRecord,
    optionID_Database_ReadOnly,
} DataSourceOptionsEnum;

/* Function pointers to retrieve specific fields of a record. */
/* !! all getter functions used by Global Search must be in the main section*/
typedef struct data_source_getter
{
    char *  (*GetString) (void * data, UInt16 fieldNum);
    Int32   (*GetInteger)(void * data, UInt16 fieldNum);
    Boolean (*GetBoolean)(void * data, UInt16 fieldNum);
    void    (*GetDate)(void * data, UInt16 fieldNum,
		       UInt16* year, UInt8* mon, UInt8* day);
    void    (*GetTime)(void * data, UInt16 fieldNum,
		       UInt8* hour, UInt8* minute);
    char *  (*GetNote)(void * data, UInt16 fieldNum);
    char *  (*GetNoteTitle)(void * data, UInt16 fieldNum);
    UInt8    (*GetListItem)(void * data, UInt16 fieldNum);
    char *  (*GetLink)(void * data, UInt16 fieldNum, UInt32* uniqID);
    char *  (*GetLinked)(void * data, UInt16 fieldNum);
    double (*GetFloat)(void * data, UInt16 fieldNum);
    void  (*GetCalculated) (void * data, UInt16 fieldNum, CalculatedValue *cv);
} DataSourceGetter;

/* Direction of a field sort. */
typedef enum data_source_sort_direction {
    SORT_DIRECTION_DESCENDING,
    SORT_DIRECTION_ASCENDING
} DataSourceSortDirection;

/* Instructions on how to sort a single field. */
typedef struct data_source_sort_field {
    UInt16 fieldNum;
    DataSourceSortDirection direction;
    Boolean case_sensitive;
} DataSourceSortField;

/* Instructions on how to sort a data source. */
typedef struct data_source_sort_info {
    UInt16 numFields;
    DataSourceSortField * fields;
} DataSourceSortInfo;

/* Callback function provided to the sorting function of a data source
 * to order records. -1 for less than, 0 for equal, 1 for greater than
 */
typedef int (*DataSourceSortCallback)(struct data_source *,
				      DataSourceGetter * getter1, void * data1,
				      DataSourceGetter * getter2, void * data2,
				      void * callback_data);

/* Standard sorting callback function that callers can make use of. */
extern int DS_StandardSortCallback(struct data_source *,
				   DataSourceGetter * getter1, void * data1,
				   DataSourceGetter * getter2, void * data2,
				   void * callback_data);

typedef struct data_source_operations {
    /* Close the data source. */
    void (*Close)(struct data_source *);

    /* Seek forward or backward in the data source. */
    /* !! Seek used by Global Search must be in the main section*/
    Boolean (*Seek)(struct data_source *, UInt16 *, Int16, Int16);
    
    /* Lock a record and return a 'handle' and getter that get be used
     * to access the field data.
     */
    /* !! LockRecord used by Global Search must be in the main section*/
    void (*LockRecord)(struct data_source *, UInt16 index, Boolean writable,
		       DataSourceGetter * getter, void ** data_ptr);

    /* Unlock a previously locked record. */
    /* !! UnlockRecord used by Global Search must be in the main section*/
    void (*UnlockRecord)(struct data_source *, UInt16 index, Boolean writable,
			 void * record_data);

    /* Run script on all Calculated Fields of all records*/
    void (*RecalculateFields)( struct data_source *);
    
   /* Add a new record to the data source. */
    Err (*UpdateRecord)(struct data_source *, UInt16 * index,
			Boolean doInsert, DataSourceGetter *, void *);

    /* Update a specific field of a record. */
    void (*SetField)(struct data_source *, void *, UInt16 fieldNum,
		     DataSourceGetter *, void *);

    /* Delete the specified index from the data source. */
    void (*DeleteRecord)(struct data_source *, UInt16 index);

    /* Return the unique ID for the given record. */
    UInt32 (*GetRecordID)(struct data_source *, UInt16 index);

    /* Return the index for the given record. */
    UInt16 (*GetRecordIndex)(struct data_source *, UInt32 ID);

    /* Set the record visible when the Filter will be enabled*/
    void (*FilterRecord)(struct data_source *, UInt16 index,
			enum data_source_filter filter);
    
    /* Set the filter enabled or not*/
    void (*SetFilter)(struct data_source *, enum data_source_filter enabled, Boolean reset);

    /* get the current filter actif*/
    enum data_source_filter (*GetCurrentFilter)(struct data_source *);

    /* Retrieve the number of views that this data source supports. */
    UInt16 (*GetNumOfViews)(struct data_source *);

    /* Allocate and retrieve the N-th view. */
    DataSourceView* (*GetView)(struct data_source *, UInt16 viewIndex);

    /* Free a view retrieved through GetView above. */
    void (*PutView)(struct data_source *, UInt16 viewIndex, DataSourceView *);

    /* Replace (or add for invalid index) the view given. */
    void (*StoreView)(struct data_source *, UInt16 viewIndex,
		      DataSourceView *);

    /* Delete the given view. */
    void (*DeleteView)(struct data_source *, UInt16 viewIndex);

    /* Determine if a change to the schema could be made. */
    void (*CheckUpdateSchema)(struct data_source *,
			      DataSourceSchema *, UInt32* reorder,
			      Boolean* changed, Boolean* rebuild);

    /* Make a change to the schema. Assume CanUpdateSchema is true. */
    void (*UpdateSchema) (struct data_source *, DataSourceSchema *, UInt32 *);

    /* Get/Set boolean options. */
    Boolean (*GetOption_Boolean)(struct data_source *, UInt16 optionID);
    void (*SetOption_Boolean)(struct data_source *,
			      UInt16 optionID, Boolean value);

    /* Get/set options that are UInt16 types. */
    /* !! GetOption_UInt16 used by Global Search must be in the main section*/
    UInt16 (*GetOption_UInt16)(struct data_source *, UInt16 optionID);
    void (*SetOption_UInt16)(struct data_source *,
			     UInt16 optionID, UInt16 value);

    /* Return a key that can be passed to OpenDataSource(). */
    UInt16 (*GetKey)(struct data_source *, void * buffer);

    /* Return the Palm database (if any) backing this data source. */
    void (*GetPDB)(struct data_source *, UInt16 *, LocalID *);

    /* Get/set the title of this data source. */
    /* !! GetTitle used by Global Search must be in the main section*/
    void (*GetTitle)(struct data_source *, char *, UInt32);
    void (*SetTitle)(struct data_source *, const char * title,
		     void ** key_data_ptr, UInt16 * key_size_ptr);

    /* Sort all of the records in the data source using the callback. */
    void (*Sort)(struct data_source *,
		 DataSourceSortCallback callback, void * callback_data);

    /* Return true if a particular capability is supported by the driver. */
    Boolean (*Capable)(struct data_source *, DataSourceCapability capability);

    /* Get informations about the data source. */
    void (*Info)(struct data_source *, UInt16 * cardNo,
                LocalID * dbID, UInt32 * dbType, UInt32 * creator,
                UInt32 * numRecord, UInt32 * size);

	/* Execute a script */
	void (*ExecuteScript)(struct data_source *, ScriptExeContext *context,
						  UInt8 *bytecode, void *packed, DataSourceGetter *,
						  CalculatedValue *result);

} DataSourceOperations;

/* Prototype of the function called by the enumeration method. */
typedef void (*DataSourceEnumerationFunc)(void * arg, const char* title,
					  UInt16 sourceID, void * key_data,
					  UInt32 key_size);

typedef Boolean (*DataSourceGlobalFindFunc)(FindParamsPtr,
					    struct data_source *,
					    UInt16, LocalID);

typedef struct data_source_class_operations
{
    /* Open the identified data source. */
    Err (*Open)(struct data_source *, UInt16 mode,
		void * key_data, UInt16 key_size);

    /* Open the identified data source. */
    Err (*OpenPDB)(struct data_source *, UInt16 mode,
		   UInt16 cardNo, LocalID dbID);

    /* Check to see if a title is usable. */
    Boolean (*CheckTitle)(const char* title);

    /* Create an empty database with the given title and schema. The
     * key is returned in memory that must be freed using
     * DeallocateMemPtr().
     */
    Err (*Create)(const char* title, DataSourceSchema* schema,
		  void ** key_data_ptr, UInt16 * key_size_ptr);

    /* Returns true if the given field type is supported. */
    Boolean (*SupportsFieldType)(DataSourceFieldType);

    /* Delete the identified data source. */
    void (*Delete)(void * key_data, UInt32 key_size);

    /* True if this driver can handle the named database. */
    void (*Enumerate)(DataSourceEnumerationFunc callback, void * arg);

    /* Enumerate and open all sources willing to participate in global
     * find. If callback returns true, then enumeration function
     * should save state and also return true. Normal completion
     * returns false.
     */
    /* !! GlobalFind used by Global Search must be in the main section*/
    Boolean (*GlobalFind)(DataSourceGlobalFindFunc callback,
			  Boolean continuation, FindParamsPtr params);

    /* Return true if the identified data source is present. */
    Boolean (*IsPresent)(void * key_data, UInt32 key_size);

    /* Return true if both keys are identical. */
    Boolean (*CompareKey)(void * key1_data, UInt16 key1_size,
			  void * key2_data, UInt16 key2_size);

    /* Return true if this driver can handle the Palm database. */
    Boolean (*CanHandlePDB)(UInt16 cardNo, LocalID dbID,
			    UInt32 type, UInt32 creator);

    /* Exchange (Beam) the named data source. */
    Err (*Exchange)(void * key_data, UInt16 key_size);

    /**
	 * Compile a Script from a text form to its executable form return
	 *  false if compilation fails
	 *  see calcvalue.c for an overview of the script engine interface
	 */
    Boolean (*CompileScript)( CalculationData *, UInt16 fieldID, 
							  ScriptExecutionContext context);
  
    /**
	 * Decompile a Script from its executable form to a text form	 
	 *    see calcvalue.c for an overview of the script engine interface
	 */
    MemHandle (*DecompileScript)( CalculationData *calc);

} DataSourceClassOperations;

typedef struct {
    void * data;
    UInt16 size;
}DataSourceKey;

#define MaskReadEdit        0x8000
#define dmModeReadEdit      MaskReadEdit | dmModeReadWrite

typedef struct data_source {
    /* database key */
    DataSourceKey key;

    /* mode used to open the database */
    UInt16 openMode;

    /* The open PalmOS database associated with this data source. */
    DmOpenRef db;

    /* The schema of this data source. */
    DataSourceSchema schema;

    /* The driver which controls this source. */
    struct data_source_driver * driver;

    /* Pointer to the operations stucture for this data source. */
    struct data_source_operations ops;

    /* Private data for use by this data source. */
    void * data;

    /* Filter value. Some driver doesn't use this variable*/
    DataSourceFilter currentfilter;
} DataSource;

typedef enum data_source_id_enum {
    sourceID_DB = 0U,
    sourceID_DB02x = 1U,
    sourceID_MobileDB = 2U,
    sourceID_JFile3 = 3U,
    sourceID_DBvfs = 4U
} DataSourceIDEnum;

typedef struct data_source_driver {
    /* ID number of this data source. */
    UInt16 sourceID;

    /* Name of this data source driver. */
    char name[32];

    /* Class operations for this driver. */
    DataSourceClassOperations class_ops;

    /* Pointer to the next driver. (drivers shouldn't touch this) */
    struct data_source_driver * next;
} DataSourceDriver;

/* Build and return a linked list of just native data source drivers. */
/* !! GetInternalDataSources used by Global Search must be in the main section*/
extern DataSourceDriver * GetInternalDataSources(void) ;

/* Build and return a linked list of all data source drivers. */
extern DataSourceDriver * GetDataSources(void) SECT_DRV;

/* Free a list of data source drivers. */
/* !! PutDataSources used by Global Search must be in the main section*/
extern void PutDataSources(DataSourceDriver *) ;

/* Free a data source schema memory*/
/* !! FreeSchema used by Global Search must be in the main section*/
extern void FreeSchema(DataSourceSchema * schema) ;

/* Copy a data source schema. */
extern void CopySchema(DataSourceSchema * dst, DataSourceSchema * src) SECT_DRV;

/* Attempt to open the database identified by the key. */
extern DataSource *
OpenDataSource(DataSourceDriver * drivers, UInt16 mode, UInt16 sourceID,
	       void * key_data, UInt16 key_size) SECT_DRV;

/* Open the database which resides in the identifed PDB. */
extern DataSource *
OpenDataSourcePDB(DataSourceDriver * drivers, UInt16 mode,
		  UInt16 cardNo, LocalID dbID) SECT_DRV;

/* Close a data source and free all data associated with it. */
extern void CloseDataSource(DataSource * source) SECT_DRV;

/* Delete the specified data source. */
extern void DeleteDataSource(DataSourceDriver * drivers, UInt16 sourceID,
			     void * key_data, UInt32 key_size) SECT_DRV;

/* Search the drivers list for a specific ID. */
extern DataSourceDriver * GetDriverByID(UInt16 sourceID) SECT_DRV;

/* Beam a data source. */
extern Err ExchangeDataSource(DataSourceDriver * drivers, UInt16 sourceID,
			  void * key_data, UInt16 key_size) SECT_DRV;

/* Convert a field to a string if it's possible or return "N/A"*/
/* !! ConvertFieldToString used by Global Search must be in the main section*/
extern void ConvertFieldToString(DataSource * source, DataSourceGetter * getter,
                            void * row_data, UInt16 fieldNum, char *data, UInt16 len);

extern DataSource * RebuildRecords(DataSource * source) SECT_DRV;

#endif
