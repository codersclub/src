/*
 * Grid Widget Implementation
 * Copyright (C) 2000-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include <unix_stdarg.h>

#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif

#include "grid.h"
#include "util.h"
#include "enum.h"
#include "prefs.h"

typedef enum {
    gridPositionNone,
    gridPositionHeaderCell,
    gridPositionHeaderColumnSep,
    gridPositionCell,
    gridPositionColumnSep,
} GridPosition;

static void FillColumnInfo(GridType*) GRIDSECT;
static void InitRowInfo(GridType*) GRIDSECT;
static void InvalidateGrid(GridType*) GRIDSECT;
static void LoadGrid(GridType *) GRIDSECT;
static void GetCellBounds(const GridType*, UInt16, UInt16,
              RectangleType*) GRIDSECT;
static void GetRowBounds(const GridType*, UInt16, RectangleType*) GRIDSECT;
static GridPosition PtToPosition(const GridType*, UInt16 *,
                 UInt16 *, Int16, Int16) GRIDSECT;
static void DrawCellBoolean(const GridType*, RectangleType*, Boolean) GRIDSECT;
static void DrawCell(const GridType*, UInt16, UInt16, void *) GRIDSECT;
static void DrawRow(const GridType*, UInt16, Boolean) GRIDSECT;
#ifdef CONFIG_COLOR
static void ReplaceTwoColors(const GridType*, RectangleType *,
                 UInt16, GridUIColorTableEntries,
                 GridUIColorTableEntries, GridUIColorTableEntries,
                 GridUIColorTableEntries) GRIDSECT;
static void DoCellColorSwap(const GridType*, RectangleType*,
                Boolean, Boolean) GRIDSECT;
#endif
static void SelectCell_Boolean(const GridType*, UInt16, UInt16,
                   EventType* event) GRIDSECT;
static void SelectCell(const GridType*, UInt16, UInt16) GRIDSECT;
static void SelectHeaderCell(const GridType*, UInt16) GRIDSECT;

MemHandle GridColorH;

static void
FillColumnInfo(GridType* grid)
{
    EventType e;
    UInt16 width;
    Int16 x;
    Boolean rightColumnClipped = false;

    x = 0;
    while (x < grid->bounds.extent.x && grid->rightColumn < grid->numCols) {
        /* Ask the grid model for the desired width of this column. */
        width = grid->model->GetColumnWidth(grid->model_data,
                            grid->rightColumn);
    
        /* Clip the requested width to the actual space remaining. */
        if (width > grid->bounds.extent.x - x) {
            width = grid->bounds.extent.x - x;
            rightColumnClipped = true;
        }
    
        /* If this is the rightmost column, allocate it all remaining space. */
        if (grid->rightColumn == grid->numCols - 1
            && width < grid->bounds.extent.x - x)
            width = grid->bounds.extent.x - x;
    
        /* Assign the column to this x-offset and allocated width. */
        grid->cols[grid->rightColumn].x = x;
        grid->cols[grid->rightColumn].width = width;
    
        /* Bump the column number up. */
        grid->rightColumn += 1;
    
        /* Move the x-offset ahead by the width of the field, both
         * column sep gutters, and the column sep if necessary.
         */
        x += width + 2 * grid->columnGutterExtent;
        if ((grid->display & Display_Col_sep)) x += 1;
    }

    /* We incremented one too many times. */
    grid->rightColumn -= 1;

    /* Send an event to the form to enable/disable scroll buttons. */
    MemSet(&e, sizeof(e), 0);
    e.eType = gridHorizontalScrollersEvent;
    e.data.generic.datum[0] = grid->controlID;
    e.data.generic.datum[1] = (grid->leftColumn > 0);
    e.data.generic.datum[2] = (grid->rightColumn < grid->numCols - 1)
    || ( rightColumnClipped && (grid->leftColumn < (grid->numCols - 1)) );
    EvtAddEventToQueue(&e);
}

static void
InitRowInfo(GridType* grid)
{
    Int16 height, i;

    /* Free any existing screenRows array. (Can happens if look is changed.) */
    if (grid->screenRows) {
        DeallocateMemPtr(grid->screenRows);
        grid->screenRows = 0;
    }

    /* Determine the number of rows and then allocate space for screenRows. */
    height = grid->bounds.extent.y - grid->headerExtent;
    grid->numScreenRows = height / grid->lineHeight;
    grid->screenRows = AllocateMemPtr(grid->numScreenRows * sizeof(GridScreenRow));

    /* Setup the screenRows array with default values. */
    for (i = 0; i < grid->numScreenRows; ++i) {
        grid->screenRows[i].height = grid->lineHeight;
        grid->screenRows[i].usable = false;
        grid->screenRows[i].valid = false;
        grid->screenRows[i].highlighted = false;
    }
}

Err
GridChange(GridType* grid, FormPtr form, GridModelPtr model,
     void * model_data)
{
    UInt16 i;

    /* Fill in the model provided by the user. */
    grid->model = model;
    grid->model_data = model_data;
    grid->form = form;

    /* For now, we use the standard font to draw all rows in the grid. */
    grid->lineHeight = FntLineHeight();

    /* Query the model for column informaton and cache in the grid struct. */
    grid->numCols = grid->model->GetColumnCount(grid->model_data);
    if (grid->cols)
        DeallocateMemPtr(grid->cols);
    grid->cols = AllocateMemPtr(grid->numCols * sizeof(GridScreenColumn));
    for (i = 0; i < grid->numCols; ++i) {
        grid->cols[i].width = grid->model->GetColumnWidth(grid->model_data, i);
    }

    /* Now determine what columns are visible and their offsets. */
    grid->leftColumn = grid->rightColumn = 0;

    InitRowInfo(grid);
    FillColumnInfo(grid);
    InvalidateGrid(grid);

    return 0;
}

Err
GridInit(GridType* grid, FormPtr form, UInt16 grid_gadget_id,
     UInt16 grid_checkbox_id, GridModelPtr model,
     void * model_data)
{
    Err err;

    if (grid->win){
        GridFree(grid);
    }

    /* Clear out the entire structure. */
    MemSet(grid, sizeof(*grid), 0);

    /* Fill in the model provided by the user. */
    grid->controlID = grid_gadget_id;
    grid->ctl_checkbox_id = grid_checkbox_id;
    grid->ctl_checkbox_index = FrmGetObjectIndex(form, grid_checkbox_id);
    grid->ctl_checkbox = FrmGetObjectPtr(form, grid->ctl_checkbox_index);

    /* Use the form to pull the bounds out of the gadget. */
    FrmGetObjectBounds(form, FrmGetObjectIndex(form, grid_gadget_id),
               &(grid->bounds));

    /* Allocate an offscreen window for flicker-free drawing. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum) {
        grid->bounds.extent.x *= 2;
        grid->bounds.extent.y *= 2;
        grid->bounds.topLeft.x *= 2;
        grid->bounds.topLeft.y *= 2;

        grid->win = HRWinCreateOffscreenWindow(SonyLibRefNum, grid->bounds.extent.x,
                     grid->bounds.extent.y,
                     screenFormat, &err);
    }else
#endif

    grid->win = WinCreateOffscreenWindow(grid->bounds.extent.x,
                     grid->bounds.extent.y,
                     screenFormat, &err);

    /* Bail out now if we could not allocate the offscreen window. */
    if (!grid->win) {
        return err;
    }

    /* Initialize the color scheme that will be used by the grid. */
    grid->colors = NULL;
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        grid->colors = MemHandleLock(GridColorH) + 2 * sizeof(UInt16) ;
    }
#endif

    grid->display = DBPrefs.GridDisplay;
    GridSetHeaderLook(grid, DBPrefs.GridDisplay & Display_Header,
                            DBPrefs.GridDisplay & Display_Header_sep,
                            true,
                            DBPrefs.TheBoldFont);
    GridSetColumnLook(grid, DBPrefs.GridDisplay & Display_Col_sep);

    /* All the UI components are initially invalid. */
    grid->valid = 0;

    err = GridChange( grid, form, model, model_data);

    /* Fill in the remainder of the fields. */
    grid->topIndex = 0;

    grid->screenRowSelected = NoneScreenRowSelected;

    return err;
}

void
GridFree(GridType* grid)
{

    if (grid->screenRows) {
        DeallocateMemPtr(grid->screenRows);
        grid->screenRows = 0;
    }
    if (grid->cols) {
        DeallocateMemPtr(grid->cols);
        grid->cols = 0;
    }
    if (grid->highlights) {
        DeallocateMemPtr(grid->highlights);
        grid->highlights = 0;
        grid->numHighlights = 0;
    }
    if (grid->win) {
        WinDeleteWindow(grid->win, false);
        grid->win = 0;
    }
    if (grid->colors)
        MemHandleUnlock(GridColorH);
}

/* Invalidate the entire grid so that GridDraw() will redraw it all. */
static void
InvalidateGrid(GridType* grid)
{
    UInt16 i;

    /* Set all state variables to the invalid position. */
    grid->valid = 0;
    for (i = 0; i < grid->numScreenRows; ++i) {
        grid->screenRows[i].valid = false;
    }
}

/* Figure out what rows to display in the grid. */
static void
LoadGrid(GridType* grid)
{
    UInt16 row, index, j;
    UInt32 uniqueID;
    Boolean scrollUp, scrollDown;
    EventType e;

    /* Adjust the top visible row so it is valid. */
    grid->model->Seek(grid->model_data, &(grid->topIndex), 0, dmSeekForward);

    /* Make sure that the entire display area is filled if possible. */
    index = grid->topIndex;
    if (! grid->model->Seek(grid->model_data, &index,
                grid->numScreenRows - 1, dmSeekForward)) {

        /* We are less than a page from the end of the model so
         * display the final page of rows.
         */
        grid->topIndex = dmMaxRecordIndex;
        if (! grid->model->Seek(grid->model_data, &(grid->topIndex),
                grid->numScreenRows - 1, dmSeekBackward)) {
            /* There are not enough records to fill even one page so
             * make the first row visible.
             */
            grid->topIndex = 0;
            grid->model->Seek(grid->model_data, &(grid->topIndex),
                  0, dmSeekForward);
        }
    }

    index = grid->topIndex;
    for (row = 0; row < grid->numScreenRows; ++row) {
        /* Stop the loop if no more rows are available from the model. */
        if (! grid->model->Seek(grid->model_data, &index, 0, dmSeekForward))
            break;

        /* Retrieve the unique ID for this row from the model. */
        grid->model->GetCellID(grid->model_data, index, &uniqueID);

        /* Mark this row for drawing if it had previously held no
         * index at all or another index from the model.
         */
        if (! grid->screenRows[row].usable
            || grid->screenRows[row].modelUniqueID != uniqueID) {
            grid->screenRows[row].usable = true;
            grid->screenRows[row].valid = false;
            grid->screenRows[row].modelUniqueID = uniqueID;
            grid->screenRows[row].modelIndex = index;
            grid->screenRows[row].height = grid->lineHeight;

            /* Determine if this row should be highlighted. */
            grid->screenRows[row].highlighted = false;
            for (j = 0; j < grid->numHighlights; ++j)
                if (grid->highlights[j] == index)
                    grid->screenRows[row].highlighted = true;
        }

        /* Increment the row index past the current index. */
        if (! grid->model->Seek(grid->model_data, &index, 1, dmSeekForward)) {
            row ++;
            break;
        }
    }

    /* Mark the remaining rows as unusable. */
    while (row < grid->numScreenRows) {
        grid->screenRows[row].usable = false;
        grid->screenRows[row].valid = false;
        ++row;
    }

    /* Determine if the model can be scrolled up and down. */
    scrollUp = false;
    if (grid->screenRows[0].usable) {
        index = grid->screenRows[0].modelIndex;
        if (grid->model->Seek(grid->model_data, &index, 1, dmSeekBackward))
            scrollUp = true;
    }
    scrollDown = false;
    if (grid->screenRows[grid->numScreenRows - 1].usable) {
        index = grid->screenRows[grid->numScreenRows - 1].modelIndex;
        if (grid->model->Seek(grid->model_data, &index, 1, dmSeekForward))
            scrollDown = true;
    }

    if (DBPrefs.TheBoldFont != grid->header_font){
        GridSetHeaderLook(grid, DBPrefs.GridDisplay & Display_Header,
                                DBPrefs.GridDisplay & Display_Header_sep,
                                true, DBPrefs.TheBoldFont);
    }
    /* Send a notification event to the form about the vertical scrollers. */
    MemSet(&e, sizeof(e), 0);
    e.eType = gridVerticalScrollersEvent;
    e.data.generic.datum[0] = grid->controlID;
    e.data.generic.datum[1] = scrollUp;
    e.data.generic.datum[2] = scrollDown;
    EvtAddEventToQueue(&e);
}

static void
GetCellBounds(const GridType* grid, UInt16 screenRow, UInt16 col,
          RectangleType* r)
{
    UInt16 i;

    /* Determine the top of the cell. */
    r->extent.y = grid->screenRows[screenRow].height;
    r->topLeft.y = grid->headerExtent;
    for (i = 0; screenRow > 0; ++i, --screenRow) {
        r->topLeft.y += grid->screenRows[i].height;
    }

    /* Determine the left of the cell. */
    r->topLeft.x = grid->cols[col].x;
    r->extent.x = grid->cols[col].width;
}

static void
GetRowBounds(const GridType* grid, UInt16 screenRow, RectangleType* r)
{
    UInt16 i;

    /* Determine the top of the cell. */
    r->extent.y = grid->screenRows[screenRow].height;
    r->topLeft.y = grid->headerExtent;
    for (i = 0; screenRow > 0; ++i, --screenRow) {
        r->topLeft.y += grid->screenRows[i].height;
    }

    r->topLeft.x = 0;
    r->extent.x = grid->bounds.extent.x;
}

static GridPosition
PtToPosition(const GridType* grid, UInt16 * row, UInt16 * col,
         Int16 x, Int16 y)
{
    /* Normalize the point into local coordinates. */
    x -= grid->bounds.topLeft.x;
    y -= grid->bounds.topLeft.y;

    /* Determine if the header row was hit. */
    if (grid->display & Display_Header) {
        if (y < grid->headerExtent) {
            *col = grid->leftColumn;
            while (*col < grid->numCols && x > grid->cols[*col].width + 2*grid->columnGutterExtent
                                       + ((grid->display & Display_Col_sep) ? 1 : 0)) {
                x -= grid->cols[*col].width - 2*grid->columnGutterExtent
                                - ((grid->display & Display_Col_sep) ? 1 : 0);
                *col += 1;
            }
    
            if (x < grid->cols[*col].width)
                return gridPositionHeaderCell;
            else if (x >= grid->cols[*col].width
                         && x < (grid->cols[*col].width
                             + 2*grid->columnGutterExtent
                             + ((grid->display & Display_Col_sep) ? 1 : 0)))
                return gridPositionHeaderColumnSep;
        }
    
        /* Remove the header row from the y coordinate. */
        y -= grid->headerExtent;
    }

    /* Determine the row where the point lies. */
    *row = 0;
    while (*row < grid->numScreenRows && y >= grid->screenRows[*row].height) {
        y -= grid->screenRows[*row].height;
        *row += 1;
    }

    /* Determine the column where the point lies. */
    *col = grid->leftColumn;
    while (*col < grid->numCols && x >= grid->cols[*col].width + 2*grid->columnGutterExtent
                               + ((grid->display & Display_Col_sep) ? 1 : 0)) {
        x -= grid->cols[*col].width - 2*grid->columnGutterExtent
            - ((grid->display & Display_Col_sep) ? 1 : 0);
        *col += 1;
    }

    if (x < grid->cols[*col].width)
        return gridPositionCell;
    else if (x >= grid->cols[*col].width
                            && x < (grid->cols[*col].width + 2*grid->columnGutterExtent
                                + ((grid->display & Display_Col_sep) ? 1 : 0)))
        return gridPositionColumnSep;
    else
        return gridPositionNone;
}

static void
DrawCellBoolean(const GridType* grid, RectangleType* r, Boolean value)
{
    /* Clear out any extra stuff from the cell. */
    WinEraseRectangle(r, 0);

    /* Setup the checkbox structure for this cell. */
    CtlSetEnabled(grid->ctl_checkbox, 1);
    CtlSetUsable(grid->ctl_checkbox, 1);
    FrmSetObjectBounds(grid->form, grid->ctl_checkbox_index, r);
    CtlSetValue(grid->ctl_checkbox, value);

    /* Now instruct the checkbox to draw itself. */
    CtlDrawControl(grid->ctl_checkbox);

    /* Make the sure the checkbox is not usable again. */
    CtlSetEnabled(grid->ctl_checkbox, 0);
    CtlSetUsable(grid->ctl_checkbox, 0);
}

static void
DrawCell(const GridType* grid, UInt16 row, UInt16 col, void * data)
{
    RectangleType r;
    Char buf[128];
    Boolean b;
	GridCellType type;

    /* Retrieve the location of this cell. */
    GetCellBounds(grid, row, col, &r);
	type = (grid->model->GetCellType(grid->model_data,
					 grid->screenRows[row].modelIndex, col));
    switch ( type ) {
	case gridCellTypeRJString:								  
    case gridCellTypeNote:
    case gridCellTypeString:
      grid->model->GetCellString(grid->model_data,
				 grid->screenRows[row].modelIndex,
				 col, buf, sizeof(buf), data);
      buf[sizeof(buf)-1] = '\0';
      
      WinEraseRectangle(&r, 0);
      UtilWinDrawTruncChars(buf, StrLen(buf),
			    r.topLeft.x, r.topLeft.y, r.extent.x, 
			    (type == gridCellTypeRJString) ? 0:1);
      break;
      
    case gridCellTypeBoolean:
        b = grid->model->GetCellBoolean(grid->model_data,
                        grid->screenRows[row].modelIndex,
                        col, data);
        DrawCellBoolean(grid, &r, b);
    break;
    }
}

static void
DrawRow(const GridType* grid, UInt16 row, Boolean highlighted)
{
    GridScreenRow* screenRow = &grid->screenRows[row];
    void * data;
    UInt16 col;

    data = grid->model->LockIndex(grid->model_data,
                  screenRow->modelIndex, false);

#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        if (!screenRow->highlighted && (grid->screenRowSelected != row)) {
            if (screenRow->modelIndex % 2)
                WinSetBackColor(grid->colors[GridUICellBackground]);
            else
                WinSetBackColor(grid->colors[GridUICellBackground2]);
            WinSetTextColor(grid->colors[GridUICellForeground]);
        } else {
            WinSetBackColor(grid->colors[GridUICellHighlightedBackground]);
            WinSetTextColor(grid->colors[GridUICellHighlightedForeground]);
        }
    }
#endif
    for (col = grid->leftColumn; col <= grid->rightColumn; ++col) {
        DrawCell(grid, row, col, data);
    }

    grid->model->UnlockIndex(grid->model_data, screenRow->modelIndex,
                 false, data);
}

void
GridDraw(GridType* grid)
{
    UInt16 col, row;
    RectangleType r;
    Char buf[128];
    WinHandle winH;
    FontID oldFont;

    /* On PalmOS 3.5+, save the current draw state. */
    if (FeatureSet35) {
        WinPushDrawState();
    }

    /* Update the usable and valid flags of the displayable rows. */
    LoadGrid(grid);

    /* Switch the draw window to the offscreen window. */
    winH = WinGetDrawWindow();
    WinSetDrawWindow(grid->win);

    /* Draw the column headers and column markers. */
    if ((grid->display & Display_Header) && !(grid->valid & Valid_Header)) {
        /* Switch to the header's color scheme. */
#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            WinSetBackColor(grid->colors[GridUIHeaderBackground]);
            WinSetTextColor(grid->colors[GridUIHeaderText]);
        }
#endif
    
        /* Clear the header to the background color. */
        r.topLeft.x = r.topLeft.y = 0;
        r.extent.x  = grid->bounds.extent.x;
        r.extent.y  = grid->headerExtent;
        WinEraseRectangle(&r, 0);

        /* Render the name of each column. */
        for (col = grid->leftColumn; col <= grid->rightColumn; ++col) {
            /* Retrieve the column name. */
            grid->model->GetColumnName(grid->model_data, col, buf, sizeof buf);
            buf[sizeof(buf) - 1] = '\0';
    
            /* Draw the column name. */
#ifdef CONFIG_SONY
            if (FeatureSetSony && SonyLibRefNum){
                oldFont = HRFntSetFont(SonyLibRefNum, grid->header_font);

		        UtilWinDrawTruncChars(buf, StrLen(buf), grid->cols[col].x, 0,
				                        grid->cols[col].width,
				                        (grid->model->GetCellType(grid->model_data,
								        grid->screenRows[0].modelIndex, col) != gridCellTypeRJString));       
                HRFntSetFont(SonyLibRefNum, oldFont);
            } else
#endif
            {
                oldFont = FntSetFont(grid->header_font);

		        UtilWinDrawTruncChars(buf, StrLen(buf), grid->cols[col].x, 0,
				                        grid->cols[col].width,
				                        (grid->model->GetCellType(grid->model_data,
								        grid->screenRows[0].modelIndex, col) != gridCellTypeRJString));
                FntSetFont(oldFont);
            }
        }

#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            WinSetBackColor(grid->colors[GridUICellBackground]);
            WinSetTextColor(grid->colors[GridUICellForeground]);
        }
#endif
        /* Mark the header valid now that it has been drawn. */
        grid->valid |= Valid_Header;

        /* Draw the seperator between the header and data rows. */
        if ((grid->display & Display_Header_sep) && !(grid->valid & Valid_Header_sep)) {
#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                WinSetForeColor(grid->colors[GridUIHeaderSeparator]);
            }
#endif
            WinDrawLine(0, grid->headerExtent - 1,
                grid->bounds.extent.x, grid->headerExtent - 1);

#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                WinSetBackColor(grid->colors[GridUICellBackground]);
            }
#endif
            grid->valid |= Valid_Header_sep;
        }
    }

    /* Scan through each row and see what cells need to be redrawn. */
    for (row = 0; row < grid->numScreenRows; ++row) {
        if (grid->screenRows[row].usable) {
            if (! grid->screenRows[row].valid) {
                DrawRow(grid, row, grid->screenRows[row].highlighted);
                grid->screenRows[row].valid = true;
            }
        } else {
            if (! grid->screenRows[row].valid) {
                GetRowBounds(grid, row, &r);
#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                if (row % 2)
                    WinSetBackColor(grid->colors[GridUICellBackground]);
                else
                    WinSetBackColor(grid->colors[GridUICellBackground2]);
            }
#endif
                WinEraseRectangle(&r, 0);
                grid->screenRows[row].valid = true;
            }
        }
    }

    /* Draw the vertical cell seperator lines. */
    if ((grid->display & Display_Col_sep) && !(grid->valid & Valid_Col_sep)) {
#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            WinSetForeColor(grid->colors[GridUICellColumnSeparator]);
        }
#endif
        for (col = grid->leftColumn + 1; col <= grid->rightColumn; ++col) {
            r.topLeft.x = grid->cols[col].x - 2 * grid->columnGutterExtent - 1;
            r.topLeft.y = 0;
            r.extent.x = 3;
            r.extent.y = grid->bounds.extent.y;
            WinEraseRectangle(&r, 0);
            WinDrawLine(grid->cols[col].x - grid->columnGutterExtent - 1,
                0,
                grid->cols[col].x - grid->columnGutterExtent - 1,
                grid->bounds.extent.y);
        }
#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            WinSetBackColor(grid->colors[GridUICellBackground]);
        }
#endif
        grid->valid |= Valid_Col_sep;
    }

    /* Erase any remaining space in the grid not used by a row. */
    r.topLeft.x = 0;
    r.topLeft.y = grid->headerExtent + grid->numScreenRows * grid->lineHeight;
    r.extent.x = grid->bounds.extent.x;
    r.extent.y = grid->bounds.extent.y - r.topLeft.y;
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        WinSetBackColor(grid->colors[GridUICellBackground]);
    }
#endif
    WinEraseRectangle(&r, 0);

    /* Reset back to the original draw window. */
    WinSetDrawWindow(winH);

    /* Restore the original draw state. */
    if (FeatureSet35) {
        WinPopDrawState();
    }

    /* Copy the offscreen window to the actual screen. */
    r.topLeft.x = 0;
    r.topLeft.y = 0;
    r.extent.x = grid->bounds.extent.x;
    r.extent.y = grid->bounds.extent.y;
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum) {
        HRWinCopyRectangle(SonyLibRefNum, grid->win, 0, &r, grid->bounds.topLeft.x,
             grid->bounds.topLeft.y, winPaint);
    }else 
#endif
    WinCopyRectangle(grid->win, 0, &r, grid->bounds.topLeft.x,
             grid->bounds.topLeft.y, winPaint);
}

/* Swap colors on the screen. Can only be called on PalmOS 3.5 or higher. */
#ifdef CONFIG_COLOR
static void
ReplaceTwoColors(const GridType* grid,
         RectangleType * rP, UInt16 cornerDiam,
         GridUIColorTableEntries oldForeground,
         GridUIColorTableEntries oldBackground,
         GridUIColorTableEntries newForeground,
         GridUIColorTableEntries newBackground)
{
    IndexedColorType oldForegroundIndex = grid->colors[oldForeground];
    IndexedColorType oldBackgroundIndex = grid->colors[oldBackground];
    IndexedColorType newForegroundIndex = grid->colors[newForeground];
    IndexedColorType newBackgroundIndex = grid->colors[newBackground];

    WinPushDrawState();
    WinSetDrawMode(winSwap);
    WinSetPatternType(blackPattern);

    if (newBackgroundIndex == oldForegroundIndex) {
        if (newForegroundIndex == oldBackgroundIndex) {
            /* Handle the case when foreground and background colors
             * change places, such as on black and white systems, with
             * a single swap.
             */
            WinSetBackColor(oldBackgroundIndex);
            WinSetForeColor(oldForegroundIndex);
#ifdef CONFIG_SONY
            if (FeatureSetSony && SonyLibRefNum)
                HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
            else
#endif
            WinPaintRectangle(rP, cornerDiam);
        } else {
            /* Handle the case when the old foreground and the new
             * background are the same, using two swaps.
             */
            WinSetBackColor(oldForegroundIndex);
            WinSetForeColor(oldBackgroundIndex);
#ifdef CONFIG_SONY
            if (FeatureSetSony && SonyLibRefNum)
                HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
            else
#endif
            WinPaintRectangle(rP, cornerDiam);
            WinSetBackColor(oldBackgroundIndex);
            WinSetForeColor(newForegroundIndex);
#ifdef CONFIG_SONY
            if (FeatureSetSony && SonyLibRefNum)
                HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
            else
#endif
            WinPaintRectangle(rP, cornerDiam);
        }
    } else if (oldBackgroundIndex == newForegroundIndex) {
        /* Handle the case when the old background and the new
         * foreground are the same, using two swaps.
         */
        WinSetBackColor(newForegroundIndex);
        WinSetForeColor(oldForegroundIndex);
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum)
            HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
        else
#endif
        WinPaintRectangle(rP, cornerDiam);
        WinSetBackColor(newBackgroundIndex);
        WinSetForeColor(oldForegroundIndex);
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum)
            HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
        else
#endif
        WinPaintRectangle(rP, cornerDiam);
    } else  {
        /* Handle the case when no two colors are the same, as is
         * typically the case on color systems, using two swaps.
         */
        WinSetBackColor(oldBackgroundIndex);
        WinSetForeColor(newBackgroundIndex);
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum)
            HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
        else
#endif
        WinPaintRectangle(rP, cornerDiam);
        WinSetBackColor(oldForegroundIndex);
        WinSetForeColor(newForegroundIndex);
#ifdef CONFIG_SONY
        if (FeatureSetSony && SonyLibRefNum)
            HRWinPaintRectangle( SonyLibRefNum, rP, cornerDiam);
        else
#endif
        WinPaintRectangle(rP, cornerDiam);
    }

    WinPopDrawState();
}
#endif

static void
SelectCell_Boolean(const GridType* grid, UInt16 row, UInt16 col,
           EventType* event)
{
    RectangleType screen_rect, offscreen_rect;
    Boolean value, orig_value;
    WinHandle winH;
    void * row_data;
    EventType new_event;

    /* Save the current draw state. */
    if (FeatureSet35) {
        WinPushDrawState();
    }

    /* Determine the location of this cell on-screen and off-screen. */
    GetCellBounds(grid, row, col, &offscreen_rect);
    RctCopyRectangle(&offscreen_rect, &screen_rect);
    screen_rect.topLeft.x += grid->bounds.topLeft.x;
    screen_rect.topLeft.y += grid->bounds.topLeft.y;

    /* Lock down this index in the model. */
    row_data = grid->model->LockIndex(grid->model_data,
                      grid->screenRows[row].modelIndex, true);

    /* Query the model for the current value of the cell. */
    value = grid->model->GetCellBoolean(grid->model_data,
                    grid->screenRows[row].modelIndex,
                    col, row_data);
    orig_value = value;

    /* Setup the checkbox structure for this cell. */
    CtlSetEnabled(grid->ctl_checkbox, 1);
    CtlSetUsable(grid->ctl_checkbox, 1);
    FrmSetObjectBounds(grid->form, grid->ctl_checkbox_index, &screen_rect);
    CtlSetValue(grid->ctl_checkbox, value);
    CtlDrawControl(grid->ctl_checkbox);

    /* Fake a ctlEnterEvent for the checkbox control. */
    EvtCopyEvent(event, &new_event);
    new_event.eType = ctlEnterEvent;
    new_event.data.ctlEnter.controlID = grid->ctl_checkbox_id;
    new_event.data.ctlEnter.pControl = grid->ctl_checkbox;

    while (true) {
        if (new_event.eType == ctlEnterEvent) {
            CtlHandleEvent(grid->ctl_checkbox, &new_event);
        } else if (new_event.eType == ctlSelectEvent) {
            value = CtlGetValue(grid->ctl_checkbox);
            /* SendTableSelectEvent (table, row, column); */
        } else if (new_event.eType == ctlExitEvent) {
            /* Post a tableExitEvent. */
            /* SendTableExitEvent (table, row, column); */
        } else {
            /* If we got an event that we didn't expect, put it back
             * in the queue.
             */
            EvtAddEventToQueue(&new_event);
            break;
        }
    
        /* Retrieve the next event. */
        EvtGetEvent(&new_event, evtWaitForever);
    }

    /* Disable the checkbox so it not handled by the form. */
    CtlSetEnabled(grid->ctl_checkbox, 0);
    CtlSetUsable(grid->ctl_checkbox, 0);

    /* If the user completed the selection, then inform the model. */
    if (value != orig_value) {
        grid->model->SetCellBoolean(grid->model_data,
                        grid->screenRows[row].modelIndex,
                        col, value, row_data);
    
        winH = WinGetDrawWindow();
        WinSetDrawWindow(grid->win);
        DrawCellBoolean(grid, &offscreen_rect, value);
        WinSetDrawWindow(winH);
    }

    /* Unlock this index in the model. */
    grid->model->UnlockIndex(grid->model_data,
                 grid->screenRows[row].modelIndex,
                 true, row_data);

    /* Restore the previous draw state. */
    if (FeatureSet35) {
        WinPopDrawState();
    }
}

#ifdef CONFIG_COLOR
static void
DoCellColorSwap(const GridType* grid, RectangleType* r,
        Boolean highlighted, Boolean selected)
{
    GridUIColorTableEntries old_fore, old_back, new_fore, new_back, tmp;

    if (highlighted) {
        old_fore = GridUICellHighlightedForeground;
        old_back = GridUICellHighlightedBackground;
        new_fore = GridUICellSelectedForeground;
        new_back = GridUICellSelectedBackground;
    } else {
        old_fore = GridUICellForeground;
        old_back = GridUICellBackground;
        new_fore = GridUICellSelectedForeground;
        new_back = GridUICellSelectedBackground;
    }

    if (!selected) {
#define swap_color(a,b) tmp = a; a = b; b = tmp
        swap_color(old_fore, new_fore);
        swap_color(old_back, new_back);
#undef swap_color
    }

    ReplaceTwoColors(grid, r, 0, old_fore, old_back, new_fore, new_back);
}
#endif

static void
SelectCell(const GridType* grid, UInt16 row, UInt16 col)
{
    RectangleType offscreen_rect, screen_rect;
    Boolean selected, highlighted;
    Coord x, y;

    /* Save the current draw state. */
    if (FeatureSet35) {
        WinPushDrawState();
    }

    /* Retrieve the location of the row that was tapped. */
    GetRowBounds(grid, row, &offscreen_rect);
    RctCopyRectangle(&offscreen_rect, &screen_rect);
    screen_rect.topLeft.x += grid->bounds.topLeft.x;
    screen_rect.topLeft.y += grid->bounds.topLeft.y;

    /* Draw the row in the highlighted state and put it on the screen. */
    selected = true;
    highlighted = grid->screenRows[row].highlighted;
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        DoCellColorSwap(grid, &screen_rect, highlighted, selected);
    } else
#elif defined(CONFIG_SONY)
    if (FeatureSetSony && SonyLibRefNum){
        HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
    } else
#endif
    WinInvertRectangle(&screen_rect, 0);
    /* Loop until the user lifts the pen. */
    while (true) {
        Boolean redraw, penDown;
    
        /* Get the current pen status. Leave the loop when it is lifted. */
        PenGetPoint(&x, &y, &penDown);
        if (!penDown)
            break;
#ifdef CONFIG_SONY
        if (FeatureSetSony){
            x *= 2;
            y *= 2;
        }
#endif
        /* Check to see if the pen moved in or out of the row. */
        redraw = false;
        if (RctPtInRectangle(x, y, &screen_rect)) {
            if (! selected) {
            selected = true;
            redraw = true;
            }           
        } else {
            if (selected) {
            selected = false;
            redraw = true;
            }
        }
    
        /* If the state of the selection changed, redraw the row. */
        if (redraw) {
#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                DoCellColorSwap(grid, &screen_rect, highlighted, selected);
            } else
#elif defined(CONFIG_SONY)
            if (FeatureSetSony && SonyLibRefNum){
                HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
            } else
#endif
            WinInvertRectangle(&screen_rect, 0);
        }
    }
        
    /* Uninvert the selection if the pen is still over it. */
    if (selected) {
        EventType e;
    
        /* Restore the unselected appearance of the row. */
#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            DoCellColorSwap(grid, &screen_rect, highlighted, false);
        } else
#elif defined(CONFIG_SONY)
        if (FeatureSetSony && SonyLibRefNum){
            HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
         } else
#endif
        WinInvertRectangle(&screen_rect, 0);

        /* Inform the system about the selection. */
        MemSet(&e, sizeof(e), 0);
        e.eType = gridSelectEvent;
        e.data.tblSelect.tableID = grid->controlID;
        e.data.tblSelect.pTable = (TableType *) grid;
        e.data.tblSelect.row = grid->screenRows[row].modelIndex;
        e.data.tblSelect.column = col;
        EvtAddEventToQueue(&e);
    }

    /* Restore the previous draw state. */
    if (FeatureSet35) {
        WinPopDrawState();
    }
}

static void
SelectHeaderCell(const GridType* grid, UInt16 col)
{
    RectangleType offscreen_rect, screen_rect;
    Boolean selected;
    Coord x, y;
    char buf[128];
    FontID oldFont;

    /* Save the current draw state and switch to header font. */
    if (FeatureSet35) {
        WinPushDrawState();
    }
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum)
        oldFont = HRFntSetFont( SonyLibRefNum, grid->header_font);
    else
#endif
    oldFont = FntSetFont(grid->header_font);

    /* Construct rectangles representing the location of the header cell. */
    offscreen_rect.topLeft.x = grid->cols[col].x;
    offscreen_rect.topLeft.y = 0;
    offscreen_rect.extent.x = grid->cols[col].width;
    offscreen_rect.extent.y = grid->headerExtent;
    RctCopyRectangle(&offscreen_rect, &screen_rect);
    screen_rect.topLeft.x += grid->bounds.topLeft.x;
    screen_rect.topLeft.y += grid->bounds.topLeft.y;

    /* Retrieve the header text. */
    MemSet(buf, sizeof(buf), 0);
    grid->model->GetColumnName(grid->model_data, col, buf, sizeof(buf));
    buf[sizeof(buf) - 1] = '\0';

    /* Draw the header cell in the highlighted state. */
    selected = true;
#ifdef CONFIG_COLOR
    if (FeatureSet35) {
        ReplaceTwoColors(grid, &screen_rect, 0,
                 GridUIHeaderText,
                 GridUIHeaderBackground,
                 GridUIHeaderSelectedText,
                 GridUIHeaderSelectedBackground);
    } else
#elif defined(CONFIG_SONY)
        if (FeatureSetSony && SonyLibRefNum){
            HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
         } else
#endif
    WinInvertRectangle(&screen_rect, 0);

    /* Loop until the user lifts the pen. */
    while (true) {
        Boolean redraw, penDown;

        /* Get the current pen status. Leave the loop when it is lifted. */
        PenGetPoint(&x, &y, &penDown);
        if (!penDown)
            break;
#ifdef CONFIG_SONY
        if (FeatureSetSony){
            x *= 2;
            y *= 2;
        }
#endif

        /* Check to see if the pen moved in or out of the header cell. */
        redraw = false;
        if (RctPtInRectangle(x, y, &screen_rect)) {
            if (! selected) {
                selected = true;
                redraw = true;
            }
        } else {
            if (selected) {
                selected = false;
                redraw = true;
            }
        }

        /* If the state of the selection changed, redraw the row. */
        if (redraw) {
#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                if (selected) {
                    ReplaceTwoColors(grid, &screen_rect, 0,
                             GridUIHeaderText,
                             GridUIHeaderBackground,
                             GridUIHeaderSelectedText,
                             GridUIHeaderSelectedBackground);
                } else {
                    ReplaceTwoColors(grid, &screen_rect, 0,
                             GridUIHeaderSelectedText,
                             GridUIHeaderSelectedBackground,
                             GridUIHeaderText,
                             GridUIHeaderBackground);
                }
            } else
#elif defined(CONFIG_SONY)
            if (FeatureSetSony && SonyLibRefNum){
                HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
             } else
#endif
            WinInvertRectangle(&screen_rect, 0);
       }
    }

    /* Uninvert the selection if the pen is still over it. */
    if (selected) {
        EventType e;

        /* Restore the unselected appearance of the row. */
#ifdef CONFIG_COLOR
        if (FeatureSet35) {
            ReplaceTwoColors(grid, &screen_rect, 0,
                     GridUIHeaderSelectedText,
                     GridUIHeaderSelectedBackground,
                     GridUIHeaderText,
                     GridUIHeaderBackground);
        } else
#elif defined(CONFIG_SONY)
        if (FeatureSetSony && SonyLibRefNum){
            HRWinInvertRectangle(SonyLibRefNum, &screen_rect, 0);
        } else
#endif
        WinInvertRectangle(&screen_rect, 0);

        /* Inform the system about the selection. */
        MemSet(&e, sizeof(e), 0);
        e.eType = gridHeaderSelectEvent;
        e.data.tblSelect.tableID = grid->controlID;
        e.data.tblSelect.pTable = (TableType *) grid;
        e.data.tblSelect.row = 0;
        e.data.tblSelect.column = col;
        EvtAddEventToQueue(&e);
    }

    /* Restore the previous draw state. */
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRFntSetFont( SonyLibRefNum, oldFont);
    } else
#endif
    FntSetFont(oldFont);
    if (FeatureSet35) {
        WinPopDrawState();
    }
}

Boolean
GridHandleEvent(GridType* grid, EventType* e)
{
    UInt16 row, col;
    Coord x, y;

    switch (e->eType) {
    case penDownEvent:
        x = e->screenX;
        y = e->screenY;

#ifdef CONFIG_SONY
        if (FeatureSetSony){
            x *= 2;
            y *= 2;
        }
#endif
        if (! RctPtInRectangle(x, y, &(grid->bounds)) ||
                y > grid->headerExtent + grid->numScreenRows * grid->lineHeight)
            return false;

       switch (PtToPosition(grid, &row, &col, x, y)) {
        case gridPositionNone:
            break;

        case gridPositionHeaderCell:
            /* Only continue if the header is configured as selectable. */
            if (! grid->header_selectable)
                break;

            SelectHeaderCell(grid, col);
        break;

        case gridPositionHeaderColumnSep:
            /* No action right now. Maybe resize the columns by dragging? */
        break;

        case gridPositionColumnSep:
            /* No action right now. Maybe resize the columns by dragging? */
        break;

        case gridPositionCell:
            /* If this row is being used, then bail out. */
            if (! grid->screenRows[row].usable)
                break;

            switch (grid->model->GetCellType(grid->model_data,
                             grid->screenRows[row].modelIndex,
                             col)) {
            case gridCellTypeNote:
                SelectCell(grid, row, col);
            break;
            case gridCellTypeBoolean:
                if (grid->model->IsColumnEditable(grid->model_data, col)) {
                    SelectCell_Boolean(grid, row, col, e);
                    break;
                }

                /* fall-through if the column is not editable */

            default:
                SelectCell(grid, row, col);
            break;
            }
        break;

        }
    return true;

    default:
    break;

    }

    return false;
}

void GridScrollVertical(GridType* grid, WinDirectionType direction,
            UInt16 increment)
{
    int i;
    UInt16 newTopmostRow, distance;
    RectangleType r, dummy;
    WinHandle winH;

    /* If the increment is greater than or equal to the number of
     * visible rows, then it is simpler to invalidate every row and
     * redraw everthing. GridDraw() outputs everything to the screen
     * at once so there will be no flicker.
     */

    if (increment >= grid->numScreenRows) {
        if (direction == winDown) {
            grid->model->Seek(grid->model_data, &grid->topIndex,
                      increment, dmSeekForward);
        } else {
            if (! grid->model->Seek(grid->model_data, &grid->topIndex,
                        increment, dmSeekBackward))
                grid->topIndex = 0;
        }

        /* Invalidate all of the rows onscreen. */
        for (i = 0; i < grid->numScreenRows; ++i) {
            grid->screenRows[i].valid = false;
        }

#ifdef CONFIG_JOGDIAL
        if (grid->screenRowSelected != NoneScreenRowSelected)
            grid->screenRowSelected = 0;
#endif
        /* Redraw the screen and return to caller. */
        GridDraw(grid);
        return;
    }

    /* Otherwise, we will move the rows that will stay on screen up
     * the offscreen buffer and then force a redraw on the new rows
     * that have been opened up.
     */

    /* Move the rows within the screenRows array to new positions. */
    if (direction == winDown) {
#ifdef CONFIG_JOGDIAL
        if (grid->screenRowSelected != NoneScreenRowSelected)
            grid->screenRowSelected -= increment;
#endif
        for (i = increment; i < grid->numScreenRows; ++i) {
            grid->screenRows[i - increment] = grid->screenRows[i];
        }
        for (i = grid->numScreenRows-increment; i < grid->numScreenRows; ++i) {
            grid->screenRows[i].usable = false;
            grid->screenRows[i].valid = false;
        }
    } else {
#ifdef CONFIG_JOGDIAL
        if (grid->screenRowSelected != NoneScreenRowSelected)
            grid->screenRowSelected += increment;
#endif
        for (i = grid->numScreenRows - increment - 1; i >= 0; --i) {
            grid->screenRows[i + increment] = grid->screenRows[i];
        }
        for (i = 0; i < increment; ++i) {
            grid->screenRows[i].usable = false;
            grid->screenRows[i].valid = false;
        }
    }

    /* Switch to the offscreen window. */
    winH = WinGetDrawWindow();
    WinSetDrawWindow(grid->win);

    /* Move the rows within the offscreen window. */
    r.topLeft.x = 0;
    r.topLeft.y = grid->headerExtent;
    r.extent.x = grid->bounds.extent.x;
    r.extent.y = grid->numScreenRows * grid->lineHeight;
    distance = 0;
    if (direction == winDown) {
        for (i = 0; i < increment; ++i) {
            distance += grid->screenRows[i].height;
        }
        WinScrollRectangle(&r, winUp, distance, &dummy);
    } else {
        for (i = grid->numScreenRows - increment; i < grid->numScreenRows; ++i) {
            distance += grid->screenRows[i].height;
        }
        WinScrollRectangle(&r, winDown, distance, &dummy);
    }
    WinEraseRectangle(&dummy, 0);

    /* Draw the column seperators in the vacated area. */
    if (grid->display & Display_Col_sep) {
        for (i = grid->leftColumn + 1; i <= grid->rightColumn; ++i) {
#ifdef CONFIG_COLOR
            if (FeatureSet35) {
                WinSetForeColor(grid->colors[GridUICellColumnSeparator]);
            }
#endif
            r.topLeft.x = grid->cols[i].x - 2 * grid->columnGutterExtent - 1;
            r.topLeft.y = dummy.topLeft.y;
            r.extent.x = 3;
            r.extent.y = dummy.topLeft.y + distance;
            WinEraseRectangle(&r, 0);
            WinDrawLine(grid->cols[i].x - grid->columnGutterExtent - 1,
                        dummy.topLeft.y,
                        grid->cols[i].x - grid->columnGutterExtent - 1,
                        dummy.topLeft.y + distance);
        }
    }

    /* Switch back to the original draw window. */
    WinSetDrawWindow(winH);

    /* Determine what the new topmost index will be. */
    newTopmostRow = grid->topIndex;
    if (direction == winDown) {
        grid->model->Seek(grid->model_data, &newTopmostRow,
                  increment, dmSeekForward);
    } else {
        if (! grid->model->Seek(grid->model_data, &newTopmostRow,
                    increment, dmSeekBackward))
            newTopmostRow = 0;
    }
    grid->topIndex = newTopmostRow;

    /* Draw the rows that have been displaced. */
    GridDraw(grid);
}

void GridScrollHorizontal(GridType* grid, WinDirectionType direction,
              UInt16 increment)
{
    if (direction == winRight) {
        if (grid->leftColumn + increment < grid->numCols)
            grid->leftColumn += increment;
    } else {
        if (increment > grid->leftColumn)
            grid->leftColumn = 0;
        else
            grid->leftColumn -= increment;
    }

    grid->rightColumn = grid->leftColumn;
    FillColumnInfo(grid);
    InvalidateGrid(grid);
}

void GridSetHeaderLook(GridType* grid, Boolean display_header,
               Boolean display_header_sep,
               Boolean header_selectable, FontID header_font)
{
    FontID oldFont;
    if (display_header_sep)
        grid->display |= Display_Header_sep;
    else
        grid->display &= ~(Display_Header_sep);
    grid->header_selectable = header_selectable;
    grid->header_font = header_font;

    if (display_header) {
        grid->display |= Display_Header;
#ifdef CONFIG_SONY
        if (FeatureSetSony){
            oldFont = HRFntSetFont(SonyLibRefNum, grid->header_font);
            grid->headerExtent = FntLineHeight();
            HRFntSetFont(SonyLibRefNum, oldFont);
        } else
#endif
        {
            oldFont = FntSetFont(grid->header_font);
            grid->headerExtent = FntLineHeight();
            FntSetFont(oldFont);
        }

        if (grid->display & Display_Header_sep)
            grid->headerExtent += 1;
    } else {
        grid->display &= ~(Display_Header);
    }
}

void GridSetColumnLook(GridType* grid, Boolean display_colsep)
{
    if (display_colsep) {
        grid->display |= Display_Col_sep;
        grid->columnGutterExtent = 1;
    } else {
        grid->display &= ~(Display_Col_sep);
        grid->columnGutterExtent = 0;
    }

    grid->rightColumn = grid->leftColumn;
}

UInt16 GridGetNumberOfRows(GridType* grid)
{
    return grid->numScreenRows;
}

void 
GridHighlightIndex(GridType* grid, UInt16 index)
{
    UInt16 i, * new_highlights;

    /* Ensure this index is not already in the list of highlighted rows. */
    for (i = 0; i < grid->numHighlights; ++i) {
        if (grid->highlights[i] == index)
            return;
    }

    /* Add this index to the list of highlighted indexes. */
    new_highlights = AllocateMemPtr((grid->numHighlights + 1) * sizeof(UInt16));
    if (grid->highlights) {
        MemMove(new_highlights, grid->highlights,
            grid->numHighlights * sizeof(UInt16));
        DeallocateMemPtr(grid->highlights);
        grid->highlights = 0;
    }
    grid->highlights = new_highlights;
    grid->highlights[grid->numHighlights] = index;
    ++(grid->numHighlights);

    /* Now scan the list of visible indexes and force a redraw for the
     * index if it is present.
     */
    for (i = 0; i < grid->numScreenRows; ++i) {
        if (grid->screenRows[i].valid && grid->screenRows[i].modelIndex == index) {
            grid->screenRows[i].valid = false;
            grid->screenRows[i].highlighted = true;
        }
    }
}

void GridUnhighlightAll(GridType* grid)
{
    UInt16 i;

    /* Force a redraw for any rows that are highlighted. */
    for (i = 0; i < grid->numScreenRows; ++i) {
        if (grid->screenRows[i].valid && grid->screenRows[i].highlighted) {
            grid->screenRows[i].valid = false;
            grid->screenRows[i].highlighted = false;
        }
    }

    /* Destroy the list of highlighted rows. */
    if (grid->highlights) {
        DeallocateMemPtr(grid->highlights);
        grid->highlights = 0;
        grid->numHighlights = 0;
    }
}

void GridMakeIndexVisible(GridType* grid, UInt16 index)
{
    UInt16 row;

    /* Check to see if the row is already visible. If so, return. */
    for (row = 0; row < grid->numScreenRows; ++row) {
        if (grid->screenRows[row].usable
                && grid->screenRows[row].modelIndex == index)
            return;
    }

    /* Shift to the requested index and invalidate all rows. */
    GridSetTopIndex(grid, index);
    for (row = 0; row < grid->numScreenRows; ++row) {
        grid->screenRows[row].usable = false;
        grid->screenRows[row].valid = false;
    }
}

UInt16 GridGetTopIndex(const GridType* grid)
{
    return grid->topIndex;
}

void GridSetTopIndex(GridType* grid, UInt16 index)
{
    grid->topIndex = index;
}

#ifdef CONFIG_COLOR
IndexedColorType
GridGetColor(const GridType* grid, GridUIColorTableEntries index)
{
    return grid->colors[index];
}

void
GridSetColor(GridType* grid, GridUIColorTableEntries index,
         IndexedColorType color)
{
    grid->colors[index] = color;
}
#endif

void
GridGetHeaderBounds(const GridType* grid, UInt16 col, RectangleType* r)
{
    /* Determine the top of the cell. */
    r->extent.y = grid->headerExtent;
    r->topLeft.y = grid->bounds.topLeft.y;
    r->topLeft.x = grid->cols[col].x;
    r->extent.x = grid->cols[col].width;
}

#ifdef CONFIG_JOGDIAL
void
GridSelectRowIndex(GridType* grid, UInt16 index)
{
    UInt16 i;
    for (i = 0; i < grid->numScreenRows; i++) {
        if (grid->screenRows[i].modelIndex == index)
            grid->screenRowSelected = i;
    }
}

void
GridMoveSelectedLine(GridType* grid, WinDirectionType direction)
{
    Int16 row = grid->screenRowSelected;

    grid->screenRows[row].valid = false;

    switch (direction) {
    case winDown:
        row++;
    break;
    case winUp:
        row--;
    break;
    default:
        row = 0;
    }

    if (row > -1 && row < grid->numScreenRows) {
        grid->screenRows[row].valid = false;
        grid->screenRowSelected = row;
    }

    GridDraw(grid);
}

#endif

