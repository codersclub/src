/*
 * DB: Database Script Support
 * Copyright (C) 2002 by Scott Wallace.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */


#ifndef _SCRIPT_H
#define _SCRIPT_H

#include "design.h"
#include "db.h"
#include "calcvalue.h"




/*
 *  The expected maximum size of the compiled script.  Note that this
 *  does not affect the storage size of the bytecode in the database
 *  it just affects how much memory is used during the design/compile
 *  stage.  Note also that if the bytecode exceeds this buffer, the \
 *  the buffer will grow as needed.
 */
#define SCRIPT_BYTECODE_SIZE 50




/* This should go in the same code resource as the DB_* function in db3.c */
extern void ScriptRun(DataSource *src, ScriptExeContext *sec, UInt8 *bytecode, 
					  void *packed, DataSourceGetter *getter,
					  CalculatedValue *cv)  SECT_S;

extern UInt8 *ScriptRunIRFirstClause(DataSource *src, UInt8 *bytecode) SECT_S;
extern UInt8 ScriptCompile( CalculationData *c, UInt16 field, ScriptExecutionContext purpose ) SECT_S;
extern MemHandle ScriptDecompile( CalculationData *c ) SECT_S;
extern void ScriptGetSafeScript( CalculationData *c ) SECT_S;




#endif// _SCRIPT_H
