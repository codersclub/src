/*
 * DB: Database I/O code
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <TxtGlue.h>

#include "db.h"

#include "enum.h"
#include "io.h"
#ifdef CONFIG_SCRIPTS
#include "script.h"
#endif

/*
 * Global Find feature doesn't support driver in another segment
 * as the main one and global variables!!!!!
*/


typedef struct
{
    DataSourceSortCallback callback;
    void * callback_data;
    DataSource * source;
    DataSourceGetter getter;
} SortCallbackData;

/* While this pointer breaks the reentrant style of the data source
 * layer, it is necessary since PalmOS doesn't let you pass a pointer
 * to the sort callback but rather an integer instead.
 */
static SortCallbackData * sort_callback_data;


/*
 * Data source driver routines for DB's native format.
 */

/* Provide convenient reference to chunks in the app info block. */

typedef struct {
    UInt8 * ptr;
    UInt32 size;
} AppInfoBlock;

typedef struct {
    UInt16 chunk_type;
    UInt16 chunk_size;
    UInt8 * chunk_data;
} AppInfoChunk;

typedef struct {
    UInt16 fieldNum;
    UInt16 width;
} ListViewColumn;

typedef struct {
    UInt16 flags;
    UInt16 numCols;
    Char name[32];
    ListViewColumn * cols;
} ListViewDefinition;

static Err      GetAppInfoBlock(DataSource * source, AppInfoBlock * info) ;
static void     PutAppInfoBlock(DataSource * source, AppInfoBlock * info) ;
static Boolean  ValidateAppInfoBlock(AppInfoBlock * info) ;
static Boolean  GetNextChunk(AppInfoBlock * info, UInt32 * token, AppInfoChunk * chunk) ;
static Boolean  GetChunkByType(AppInfoBlock * info, AppInfoChunk * chunk,
                            UInt16 chunk_type, UInt16 index) ;
static Err      AppendChunk(MemHandle h, UInt16 chunk_type,
                            UInt8 * chunk_data, UInt16 chunk_size) SECT_DRV;
static UInt8 *  BuildFieldDataChunk( DataSourceSchema * schema, UInt16 fieldNum, UInt32 *sizeP) SECT_DRV;
static Err      DB_InstallAppInfoBlock(DataSource* source, MemHandle tmpAppInfoHand) SECT_DRV;
static Err      DB_Chunk_Append(DataSource * source, UInt16 new_chunk_type,
                                UInt8 * new_chunk_data, UInt16 new_chunk_size) SECT_DRV;
static Err      DB_Chunk_Replace(DataSource * source, UInt16 chunk_type, UInt16 index,
                                UInt8 * new_chunk_data, UInt16 new_chunk_size) SECT_DRV;
static Err      DB_Chunk_Delete(DataSource * source, UInt16 chunk_type, UInt16 index) SECT_DRV;
static Err      ExtractSchema(DataSource * source, AppInfoBlock * info) ;
static UInt32   DB_PackedRecordSize(DataSource * source,
                                DataSourceGetter * getter, void * data) SECT_DRV;
static void     DB_PackRecord(DataSource * source, void * dest,
                            DataSourceGetter * getter, void * data) SECT_DRV;
#ifdef CONFIG_SCRIPTS
static Err      DB_PackCalculation(void *dest, UInt16 field,
								  CalculatedValue *cv, Int16 slotSize ) SECT_S;
static void     DB_PackSRCalculations(DataSource * source, void * dest, UInt16 record ) SECT_S;
static void     DB_PackIRCalculations( DataSource *source) SECT_S;
#endif
/*Getter functions*/
static char *   DB_Getter_GetString(void * data, UInt16 fieldNum) ;
static Int32    DB_Getter_GetInteger(void * data, UInt16 fieldNum) ;
static Boolean  DB_Getter_GetBoolean(void * data, UInt16 fieldNum) ;
static void     DB_Getter_GetDate(void * data, UInt16 fieldNum,
                                UInt16* year, UInt8* month, UInt8* day) ;
static void     DB_Getter_GetTime(void * data, UInt16 fieldNum,
                                UInt8* hour, UInt8* minute) ;
static char *   DB_Getter_GetNoteTitle(void * data, UInt16 fieldNum) ;
static char *   DB_Getter_GetNote(void * data, UInt16 fieldNum) ;
static UInt8    DB_Getter_GetListItem(void * data, UInt16 fieldNum) ;
static char *   DB_Getter_GetLink(void * data, UInt16 fieldNum, UInt32* uniqID) ;
static char *   DB_Getter_GetLinked(void * data, UInt16 fieldNum) ;
static double   DB_Getter_GetFloat(void * data, UInt16 fieldNum);
#ifdef CONFIG_SCRIPTS
static void DB_Getter_GetCalculated(void * data, UInt16 fieldNum, CalculatedValue *cv);
#endif

static void     DB_PDB_LockRecord(DataSource * source, UInt16 index, Boolean writable,
                            DataSourceGetter * getter, void ** data_ptr) ;
static void     DB_PDB_UnlockRecord(DataSource * source, UInt16 index, Boolean writable,
                                void * record_data) ;
static Err      DB_PDB_UpdateRecord(DataSource * source, UInt16 * index, Boolean doInsert,
                                DataSourceGetter * getter, void * data) SECT_DRV;
static void     DB_SetField(DataSource * source, void * data, UInt16 fieldNum,
                            DataSourceGetter * getter, void * getter_arg) SECT_DRV;
static UInt16   DB_GetNumOfViews(DataSource * source) SECT_DRV;
static DataSourceView *     DB_GetView(DataSource * source, UInt16 viewIndex) SECT_DRV;
static void     DB_StoreView(DataSource * source, UInt16 viewIndex, DataSourceView * view) SECT_DRV;
static void     DB_DeleteView(DataSource * source, UInt16 index) SECT_DRV;
static void     DB_UpdateSchema(DataSource * source,
                                DataSourceSchema * schema, UInt32 * reorder) SECT_DRV;
static Boolean  DB_GetOption_Boolean(DataSource * source, UInt16 optionID) ;
static void     DB_SetOption_Boolean(DataSource * source, UInt16 optionID, Boolean value) SECT_DRV;
static UInt16   DB_GetOption_UInt16(DataSource * source, UInt16 optionID) ;
static void     DB_SetOption_UInt16(DataSource * source, UInt16 optionID, UInt16 value) SECT_DRV;
static Int16    DB_SortCallback(void * rec1, void * rec2, Int16 other,
                                SortRecordInfoPtr rec1SortInfo, SortRecordInfoPtr rec2SortInfo,
                                MemHandle appInfoH) SECT_DRV;
static void     DB_Sort(DataSource * source, DataSourceSortCallback callback, void * callback_data) SECT_DRV;
static Boolean  DB_Capable(DataSource * source, DataSourceCapability capability) ;

/*Driver Functions must not be in another section than the main for the globel find*/
static Err      DB_PDB_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size);
static Err      DB_OpenPDB(DataSource * source, UInt16 mode, UInt16 cardNo, LocalID dbID);
static Err      DB_Create(const char* name, DataSourceSchema* schema,
                            void ** key_data_ptr, UInt16 * key_size_ptr) ;
static Boolean  DB_SupportsFieldType(DataSourceFieldType type);
static void     DB_Enumerate(DataSourceEnumerationFunc callback, void * arg);
#ifdef CONFIG_GLOBALFIND
static Boolean  DB_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation, FindParamsPtr params);
#endif
static Boolean  DB_IsPresent(void * key_data, UInt32 key_size);
static Boolean  DB_CanHandlePDB(UInt16 cardNo, LocalID dbID, UInt32 type, UInt32 creator);

/* Valid chunk types in the database header. Read docs/format.txt for info. */
#define CHUNK_FIELD_NAMES         0U
#define CHUNK_FIELD_TYPES         1U
#define CHUNK_FIELD_DATA          2U
#define CHUNK_LISTVIEW_DEFINITION 64U
#define CHUNK_LISTVIEW_OPTIONS    65U
#define CHUNK_LFIND_OPTIONS       128U
#define CHUNK_DATABASE_INFO       255U

/* Valid values for the flags word at the start of the database header. */
#define FLAG_GFIND_FORCE_DISABLE   0x0001
#define FLAG_GFIND_FORCE_ENABLE    0x0002
#define FLAG_DATABASE_SYSPWD       0x4000
#define FLAG_DATABASE_READONLY     0x8000

static Err GetAppInfoBlock(DataSource * source, AppInfoBlock * info)
{
    UInt16 cardNo;
    LocalID appInfoID;

    DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
    appInfoID = DmGetAppInfoID(source->db);
    if (!appInfoID)
        return -1;
    info->ptr = (UInt8 *)MemLocalIDToLockedPtr(appInfoID, cardNo);
    info->size = MemPtrSize(info->ptr);
    return 0; 
}

static void PutAppInfoBlock(DataSource * source, AppInfoBlock * info)
{
    if (info->ptr)
        MemPtrUnlock(info->ptr);
}

/* Validate that the chunks fill the app info block. */
static Boolean
ValidateAppInfoBlock(AppInfoBlock * info)
{
    AppInfoChunk chunk;
    UInt32 i;
    Boolean result = false;

    if (info->size >= 4UL) {
        /* Loop through each chunk in the block while data remains. */
        i = 4UL;
        while (i < info->size) {
            /* Stop the loop if there is not enough room for even one
             * chunk header.
             */
            if (i + 4UL >= info->size)
                break;

            /* Copy the chunk type and size into the local buffer. */
            MemMove(&(chunk.chunk_type), info->ptr + i, sizeof(UInt16));
            MemMove(&(chunk.chunk_size), info->ptr + i + 2, sizeof(UInt16));
            i += 4UL;

            /* Advance the index by the size of the chunk. */
            i += chunk.chunk_size;
        }

        /* If everything was correct, then we should be exactly at the
         * end of the block. 
         */
        if (i == info->size)
            result = true;
    }

    return result;
}

/* Iterate over each chunk. The 'token' argument should be zero to start. */
static Boolean
GetNextChunk(AppInfoBlock * info, UInt32 * token, AppInfoChunk * chunk)
{
    /* If the token is 0, then point at the first chunk. */
    if (! (*token)) *token = 4UL;

    /* If the token is past the end of the app info block, signal done. */
    if (*token >= info->size)
        return false;

    /* Retrieve the header and size of the next chunk. */
    MemMove(&(chunk->chunk_type), info->ptr + (*token), sizeof(UInt16));
    MemMove(&(chunk->chunk_size), info->ptr + (*token) + 2, sizeof(UInt16));

    /* Point at the start of the chunk data. */
    chunk->chunk_data = info->ptr + (*token) + 4;

    /* Advance the token to the next chunk. */
    (*token) += 2 * sizeof(UInt16) + chunk->chunk_size;

    /* Align the pointer to a 16-bit (UInt16) boundary. */
    /* (*token) = ( ( (*token) + 1ul ) & 1ul ); */

    return true;
}

/* Find the first chunk with the matching type and return it. */
static Boolean
GetChunkByType(AppInfoBlock * info, AppInfoChunk * chunk,
               UInt16 chunk_type, UInt16 index)
{
    UInt32 token = 0;

    while (GetNextChunk(info, &token, chunk)) {
        if (chunk->chunk_type == chunk_type) {
            if (index == 0) {
                /* We found a worthy chunk. Return to the caller. */
                return true;
            }
            index--;
        }
    }

    return false;
}

/* Append the given data to a normal memory handle as a new chunk. */
static Err
AppendChunk(MemHandle h, UInt16 chunk_type,
            UInt8 * chunk_data, UInt16 chunk_size)
{
    Err err;
    UInt8 * p;
    UInt32 size, orig_size;

    /* Resize the handle to make room for the new chunk. */
    orig_size = MemHandleSize(h);
    size = orig_size + 2 * sizeof(UInt16) + chunk_size;
    err = MemHandleResize(h, size);
    if (err)
        return err;

    /* Store the new chunk at the end of the handle. */
    p = (UInt8 *)MemHandleLock(h);
    MemMove(p + orig_size, &chunk_type, sizeof(UInt16));
    MemMove(p + orig_size + 2UL, &chunk_size, sizeof(UInt16));
    MemMove(p + orig_size + 4UL, chunk_data, chunk_size);
    MemHandleUnlock(h);

    return 0;
}

/* Finish off a chunk operation by installing the new app info block. */
static Err
DB_InstallAppInfoBlock(DataSource* source, MemHandle tmpAppInfoHand)
{
    MemHandle appInfoHand, oldAppInfoHand;
    UInt16 cardNo;
    LocalID dbID, appInfoID, oldAppInfoID;
    void *p, *q;
    UInt32 size;

    /* Allocate a handle in the storage memory for the new block. */
    size = MemHandleSize(tmpAppInfoHand);
    appInfoHand = DmNewHandle(source->db, size);
    if (!appInfoHand)
            return DmGetLastErr();

    /* Copye the new block into what will be its final location. */
    p = MemHandleLock(appInfoHand);
    q = MemHandleLock(tmpAppInfoHand);
    DmWrite(p, 0, q, size);
    MemPtrUnlock(q);
    MemPtrUnlock(p);

    /* Point the Data Manager at the new block. */
    DmOpenDatabaseInfo(source->db, &dbID, 0, 0, &cardNo, 0);
    oldAppInfoID = DmGetAppInfoID(source->db);
    appInfoID = MemHandleToLocalID(appInfoHand);
    DmSetDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, &appInfoID, 0, 0, 0);

    /* Finally, free the old block. */
    p = MemLocalIDToLockedPtr(oldAppInfoID, cardNo);
    oldAppInfoHand = MemPtrRecoverHandle(p);
    MemHandleUnlock(oldAppInfoHand);
    DeallocateMemHandle(oldAppInfoHand);

    /* Success! */
    return 0;
}

/* Append the given data as a new chunk. */
static Err
DB_Chunk_Append(DataSource * source, UInt16 new_chunk_type,
                UInt8 * new_chunk_data, UInt16 new_chunk_size)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    MemHandle h;
    UInt32 token = 0;
    Err err;
    void * p;

    /* Lock down the current block. */
    GetAppInfoBlock(source, &info);

    /* Allocate a temporary handle to build new block with. */
    h = AllocateMemHandle(4ul);
    p = MemHandleLock(h);
    MemMove(p, info.ptr, 4);
    MemPtrUnlock(p);

    /* Loop through each chunk and move them to the temporary handle. */
    while (GetNextChunk(&info, &token, &chunk)) {
        AppendChunk(h, chunk.chunk_type, chunk.chunk_data, chunk.chunk_size);
    }

    /* Append the new chunk after the end of the other chunks. */
    AppendChunk(h, new_chunk_type, new_chunk_data, new_chunk_size);

    /* Release the current block. */
    PutAppInfoBlock(source, &info);

    /* Install the new block. */
    err = DB_InstallAppInfoBlock(source, h);
    DeallocateMemHandle(h);
    return err;
}

/* Replace an existing chunk with new given data. */
static Err
DB_Chunk_Replace(DataSource * source, UInt16 chunk_type, UInt16 index,
                 UInt8 * new_chunk_data, UInt16 new_chunk_size)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    MemHandle h;
    UInt32 token = 0;
    Boolean found_victim_chunk;
    Err err;
    void * p;

    /* Lock down the current block. */
    GetAppInfoBlock(source, &info);

    /* Allocate a temporary handle to build new block with. */
    h = AllocateMemHandle(4ul);
    p = MemHandleLock(h);
    MemMove(p, info.ptr, 4);
    MemPtrUnlock(p);

    /* Loop through each chunk and move them to the temporary
     * handle. We stop when the chunk to replace has been found.
     */
    found_victim_chunk = false;
    while (GetNextChunk(&info, &token, &chunk)) {
        if (chunk.chunk_type == chunk_type) {
            if (chunk_type == CHUNK_FIELD_DATA){
                if ((UInt16)( *(chunk.chunk_data+1)) == index)
                    found_victim_chunk = true;
                    break;
            } else {
                if (index == 0) {
                    /* Bail out since we have found the chunk to replace. */
                    found_victim_chunk = true;
                    break;
                } else {
                    /* Otherwise, decrement the index and fall through
                     * into the normal chunk copying code.
                     */
                    index--;
                }
            }
        }

        /* Copy the current chunk into the temporary handle. */
        AppendChunk(h, chunk.chunk_type, chunk.chunk_data, chunk.chunk_size);
    }

    /* If we found the chunk to replace, then do the actual
     * replacement. If the victim was not found, then that means we
     * scanned all the chunks without finding it.
     */
    if (found_victim_chunk) {
        /* Place the new chunk into position where the old one was. */
        AppendChunk(h, chunk_type, new_chunk_data, new_chunk_size);

        /* Copy the remainder of the chunks into place. */
        while (GetNextChunk(&info, &token, &chunk)) {
            AppendChunk(h, chunk.chunk_type,
                        chunk.chunk_data, chunk.chunk_size);
        }
    }

    /* Release the current block. */
    PutAppInfoBlock(source, &info);

    /* Install the new app info block into place. */
    err = DB_InstallAppInfoBlock(source, h);
    DeallocateMemHandle(h);
    return err;
}

/* Delete the given chunk. */
static Err
DB_Chunk_Delete(DataSource * source, UInt16 chunk_type, UInt16 index)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    MemHandle h;
    UInt32 token = 0;
    Boolean found_victim_chunk;
    Err err;
    void * p;

    /* Lock down the current block. */
    GetAppInfoBlock(source, &info);

    /* Allocate a temporary handle to build new block with. */
    h = AllocateMemHandle(4ul);
    p = MemHandleLock(h);
    MemMove(p, info.ptr, 4);
    MemPtrUnlock(p);

    /* Loop through each chunk and move them to the temporary
     * handle. We stop when the chunk to delete has been found.
     */
    found_victim_chunk = false;
    while (GetNextChunk(&info, &token, &chunk)) {
        if (chunk.chunk_type == chunk_type) {
            if (index == 0) {
                        /* Bail out since we have found the chunk to delete. */
                        found_victim_chunk = true;
                        break;
            } else {
                        /* Otherwise, decrement the index and fall through
                         * into the normal chunk copying code.
                         */
                        index--;
            }
        }

        /* Copy the current chunk into the temporary handle. */
        AppendChunk(h, chunk.chunk_type, chunk.chunk_data, chunk.chunk_size);
    }

    /* If we found the chunk to replace, then just copy the remaining
     * chunks to the temporary handle. If the victim was not found,
     * then that means we scanned all the chunks without finding it.
     */
    if (found_victim_chunk) {
        while (GetNextChunk(&info, &token, &chunk)) {
            AppendChunk(h, chunk.chunk_type,
                        chunk.chunk_data, chunk.chunk_size);
        }
    }

    /* Release the current block. */
    PutAppInfoBlock(source, &info);

    /* Install the new app info block into place. */
    err = DB_InstallAppInfoBlock(source, h);
    DeallocateMemHandle(h);
    return err;
}

static Err
ExtractSchema(DataSource * source, AppInfoBlock * info)
{
    AppInfoChunk names_chunk, types_chunk, info_chunk;
    UInt16 i, j, index;
    UInt32 size;
    char *p, *q;
    UInt16 type;

    /* Retrieve and verify the chunks containing schema information. */
    if (! GetChunkByType(info, &names_chunk, CHUNK_FIELD_NAMES, 0)
        || ! GetChunkByType(info, &types_chunk, CHUNK_FIELD_TYPES, 0)
        || (source->schema.numFields*sizeof(UInt16)) != types_chunk.chunk_size)
        return dmErrCorruptDatabase;

    /* Calculate how much space to allocate. */
    size = source->schema.numFields * sizeof(DataSourceFieldInfo);
    p = (char *)names_chunk.chunk_data;
    for (i = 0; i < source->schema.numFields; ++i) {
        size += StrLen(p) + 1;
        p += StrLen(p) + 1;
    }

    /* Allocate the field info structure and extra space for strings. */
    source->schema.fields = AllocateMemPtr(size);

    /* Fill out the field info structure. */
    p = (char *) names_chunk.chunk_data;
    q = (char *) (source->schema.fields + source->schema.numFields);
    for (i = 0; i < source->schema.numFields; ++i) {
        /* Copy and set the field name. */
        StrCopy(q, p);
        source->schema.fields[i].name = q;
        p += StrLen(p) + 1;
        q += StrLen(q) + 1;
    
        /* Set the field type. */
        MemMove(&type, types_chunk.chunk_data + i * sizeof(UInt16),
                sizeof(UInt16));
        type &= 0x00FF;
        switch (type) {
        case 0:
            source->schema.fields[i].type = FIELD_TYPE_STRING;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 1:
            source->schema.fields[i].type = FIELD_TYPE_BOOLEAN;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 2:
            source->schema.fields[i].type = FIELD_TYPE_INTEGER;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 3:
            source->schema.fields[i].type = FIELD_TYPE_DATE;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 4:
            source->schema.fields[i].type = FIELD_TYPE_TIME;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 5:
            source->schema.fields[i].type = FIELD_TYPE_NOTE;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
    
        case 6:
            source->schema.fields[i].type = FIELD_TYPE_LIST;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;

        case 7:
            source->schema.fields[i].type = FIELD_TYPE_LINK;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;

        case 8:
            source->schema.fields[i].type = FIELD_TYPE_FLOAT;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
			
#ifdef CONFIG_SCRIPTS
        case 9:
            source->schema.fields[i].type = FIELD_TYPE_CALCULATED;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            break;
#endif

        case 10:
            source->schema.fields[i].type = FIELD_TYPE_LINKED;
            MemSet( &source->schema.fields[i].data, sizeof(DataSourceFieldData), 0);
            source->schema.fields[i].data.linked.linkNum = 0xFFFF;
            break;

        }
        source->schema.fields[i].lock = true;
    }

    index = 0;
    while (GetChunkByType(info, &info_chunk, CHUNK_FIELD_DATA, index)) {
        UInt8 *p = info_chunk.chunk_data;

        i = (UInt16)(*(p + 1));
        p += 2UL;
        if (i >= source->schema.numFields)
            break;
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            source->schema.fields[i].data.string.defaultValue = (char *)AllocateMemPtr( StrLen((const char *)p)+1);
            StrCopy( source->schema.fields[i].data.string.defaultValue, (const char *)p);
            p +=  StrLen((const char *)p)+1;
        break;
        case FIELD_TYPE_INTEGER:
            MemMove(&(source->schema.fields[i].data.integer.defaultValue), (UInt8 *) p, sizeof(Int32));
            p += 4UL;
            MemMove(&(source->schema.fields[i].data.integer.increment), (UInt8 *) p, sizeof(Int16));
            p += 2UL;
        break;
        case FIELD_TYPE_FLOAT:
            MemMove(&(source->schema.fields[i].data.floatNum.defaultValue), (UInt8 *) p, sizeof(double));
            p += sizeof(double);
        break;
        case FIELD_TYPE_LIST:
            source->schema.fields[i].data.list.items = (char **)AllocateMemPtr( 32 * sizeof(char*));
            MemMove(&(source->schema.fields[i].data.list.numItems), (UInt8 *) p, sizeof(Int16));
            p += 2UL;
            p += 2UL;
            source->schema.fields[i].data.list.uniqID = 
                                (UInt16 *)AllocateMemPtr( source->schema.fields[i].data.list.numItems * sizeof(UInt16));
            for ( j = 0; j < source->schema.fields[i].data.list.numItems; j++) {
                source->schema.fields[i].data.list.uniqID[j] = j;
                source->schema.fields[i].data.list.items[j] = (char *)AllocateMemPtr( StrLen((const char *)p)+1);
                StrCopy( source->schema.fields[i].data.list.items[j], (const char *)p);
                p +=  StrLen((const char *)p)+1;
            }
        break;
        case FIELD_TYPE_LINK:
            MemMove(&(source->schema.fields[i].data.link.dbID), (UInt8 *) p, sizeof(Int32));
            p += 4UL;
            MemMove(&(source->schema.fields[i].data.link.fieldNum), (UInt8 *) p, sizeof(Int16));
            p += 2UL;
        break;
        case FIELD_TYPE_LINKED:
            MemMove(&(source->schema.fields[i].data.linked.linkNum), (UInt8 *) p, sizeof(Int16));
            p += 2UL;
            MemMove(&(source->schema.fields[i].data.linked.fieldNum), (UInt8 *) p, sizeof(Int16));
            p += 2UL;
        break;
#ifdef CONFIG_SCRIPTS
		case FIELD_TYPE_CALCULATED:
		{
		  UInt8 *bc;
		  Int16 hSize;
		  CalculationData *c;

		  hSize = (Int16)(*p);
		  c = &(source->schema.fields[i].data.calc);
		  c->bytecode_sz = hSize;

		  p++;
		  if ( (*p & 0xf0) == 0x10 ) {
			// swbug out of mem not handled
			c->bytecode = AllocateMemHandle(hSize);

			p++;
			// get header info
			c->access = *p++;
			
			// backward compatiblity for scripts prior to the script interface
			// scripts with access 0x00 are inter record scripts
			// scripts with access 0x02 are single record scripts
			if ( c->access == 0x00 )
			  c->access = ARRANGING | MULTI_RECORD_READING | FIELD_READING;
			else if ( c->access == 0x02 )
			  c->access = SINGLE_RECORD_READING | FIELD_READING;

			
			c->returnType = *p++;

			bc = (UInt8 *)MemHandleLock( c->bytecode );
			MemMove( bc, p, hSize );
			MemPtrUnlock( bc );
		  }
		  else {
			DbgPrintF( "You've got the pre-alpha scripts, please re-enter them" );
			ScriptGetSafeScript( c );

		  }

		  break;
		}
#endif		 
        default:
            MemMove( &source->schema.fields[i].data, p, sizeof(source->schema.fields[i].data));
            p += sizeof(source->schema.fields[i].data);
        }
        index++;
    }
    return 0;
}

static UInt32
DB_PackedRecordSize(DataSource * source,
                    DataSourceGetter * getter, void * data)
{
    UInt32 size, value;
    UInt16 i;
    char * str;

    size = source->schema.numFields * sizeof(UInt16);
    for (i = 0; i < source->schema.numFields; i++) {
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            str = getter->GetString(data, i);
            if (str)
                size += StrLen(str) + 1;
            else
                size += 1;
            break;

        case FIELD_TYPE_NOTE:
            str = getter->GetNoteTitle(data, i);
            size += StrLen(str) + 3;
            str = getter->GetNote(data, i);
            if ( str && StrLen(str))
                size += StrLen(str) + 1;
            else
                size += 1;
            break;

        case FIELD_TYPE_BOOLEAN:
            size += sizeof(UInt8);
            break;

        case FIELD_TYPE_INTEGER:
            size += sizeof(Int32);
            break;

        case FIELD_TYPE_DATE:
            size += sizeof(UInt16) + 2 * sizeof(UInt8);
            break;

        case FIELD_TYPE_TIME:
            size += 2 * sizeof(UInt8);
            break;

        case FIELD_TYPE_LIST:
            size += sizeof(UInt8);
            break;

        case FIELD_TYPE_LINK:
            str = getter->GetLink(data, i, &value);
            if (str)
                size += StrLen(str) + 5;
            else
                size += 5;
            break;

        case FIELD_TYPE_LINKED:
            str = getter->GetLinked(data, i);
            if (str)
                size += StrLen(str) + 1;
            else
                size += 1;
            break;

        case FIELD_TYPE_FLOAT:
            size += sizeof(double);
            break;

#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
          size += CV_GetPackedSize(&(source->schema.fields[i].data.calc));
        break;
#endif

        default:
            ErrDisplay("DB_PackedRecordSize: unsupported field type");
            break;
        }
    }

    return size;
}


#ifdef CONFIG_SCRIPTS

static Err
DB_PackCalculation( void *dest, UInt16 field, CalculatedValue *cv, Int16 slotSize ) {

    UInt8 nothing = 0;
    UInt16 offset;
    UInt8 info;

    offset = ((UInt16 *)dest)[field];

    //  DbgPrintF( "Packing Script Type %u %u", cv->info, CV_FIELD_TYPE_BROKEN );
    info = cv->info;

    // a dynamically allocated string becomes normal after it is stored.
    if ( info == CV_FIELD_TYPE_ALLOC_STRING ) info = FIELD_TYPE_STRING;
    DmWrite( dest, offset, &info, sizeof( UInt8 ) );
    offset += sizeof( UInt8 );

    slotSize -= 1;
    /*
    * if we're dealing with a string, see if it needs to
    * be truncated
    */
    if ( info == FIELD_TYPE_STRING ) {
        if ( (StrLen(cv->value.s) + 1) > slotSize ) {
            DbgPrintF( "Too big for slot" );
            DmWrite( dest, offset, cv->value.s, slotSize - 1 );
            DmWrite( dest, offset+slotSize-1, &nothing, sizeof( UInt8 ) );
        }else {
            DmWrite( dest, offset, cv->value.s, StrLen(cv->value.s) + 1);
        }
    } else {
        if ( slotSize ) { DmWrite( dest, offset, &(cv->value), slotSize ); }
    }

    return 0;
}
/*
   Pack Single Record Calculations -- currently the only type
   of calculated field
*/
static void
DB_PackSRCalculations(DataSource * source, void * dest, UInt16 record )
{
    UInt16 i;
	int  scriptId;
	DataSourceGetter getter;
	UInt8 *bc = NULL;
	CalculatedValue cv;
	UInt16 size;
	ScriptExeContext sec;

	scriptId = 0;
    getter.GetString  = DB_Getter_GetString;
    getter.GetInteger = DB_Getter_GetInteger;
    getter.GetBoolean = DB_Getter_GetBoolean;
    getter.GetDate    = DB_Getter_GetDate;
    getter.GetTime    = DB_Getter_GetTime;
    getter.GetNote    = DB_Getter_GetNote;
    getter.GetNoteTitle = DB_Getter_GetNoteTitle;
    getter.GetListItem = DB_Getter_GetListItem;
    getter.GetLink = DB_Getter_GetLink;
    getter.GetLinked = DB_Getter_GetLinked;
    getter.GetFloat = DB_Getter_GetFloat;
	getter.GetCalculated = DB_Getter_GetCalculated;

	sec.context = RECORD_FIELD_WRITING_CONTEXT;

    for (i = 0; i < source->schema.numFields; i++) {
      if ( source->schema.fields[i].type == FIELD_TYPE_CALCULATED ) {

		if ( ScriptRequiresAtMost( &(source->schema.fields[i].data.calc),
								   MULTI_RECORD_READING | FIELD_READING )
            && source->schema.fields[i].data.calc.bytecode ) {

		  sec.info.record = record;
		  bc = (UInt8 *)MemHandleLock( source->schema.fields[i].data.calc.bytecode );
		  ScriptRun( source, &sec , bc, dest, &getter, &cv );
		  size = CV_GetPackedSize( &(source->schema.fields[i].data.calc ));
		  DB_PackCalculation( dest, i, &cv, size  );
		  MemPtrUnlock( bc );
		}
		else {
		  cv.info = CV_FIELD_TYPE_NA;
		  DB_PackCalculation( dest, i, &cv, 1 );
		}
		CV_FreeData( &cv );
	  } /* If field is a calculated field */

	}
}

static void 
DB_PackIRCalculations( DataSource *source)
{
    UInt8 *secondScriptClauseBegin, *bc;
    DataSourceGetter getter;
    UInt16 record;
    void *packed;
    CalculatedValue cv;
    Int16 size;
    UInt16 filter;
    ScriptExeContext sec;
    int i;

    filter = source->ops.GetCurrentFilter(source);
    source->ops.SetFilter( source, FILTERALL, false );
    sec.context = RECORD_FIELD_WRITING_CONTEXT;

    for (i = 0; i < source->schema.numFields; i++) {
        if (source->schema.fields[i].type == FIELD_TYPE_CALCULATED) {
            if ( ScriptRequiresAtMost( &(source->schema.fields[i].data.calc),
                                FIELD_READING | MULTI_RECORD_READING | ARRANGING )
                && ScriptRequiresAtLeast(&(source->schema.fields[i].data.calc),
                                ARRANGING)
                && source->schema.fields[i].data.calc.bytecode ) {

                size = CV_GetPackedSize( &(source->schema.fields[i].data.calc) );
                bc = (UInt8 *)MemHandleLock( source->schema.fields[i].data.calc.bytecode );

                secondScriptClauseBegin = ScriptRunIRFirstClause( source, bc );


                // run the script on each field.
                record = 0;
                while( 1 ) {
                    if (!source->ops.Seek(source, &record, 0, dmSeekForward))
                        break;

                    source->ops.LockRecord(source, record, true, &getter, &packed );
                    sec.info.record = record;

                    ScriptRun( source, &sec, secondScriptClauseBegin,
                                packed, &getter, &cv);

                    DB_PackCalculation( packed, i, &cv, size );
                    CV_FreeData( &cv );
                    source->ops.UnlockRecord( source, record, true, packed );
                    record++;
                }
                MemPtrUnlock( bc );
            }
        }
    }
}
#endif


static void
DB_PackRecord(DataSource * source, void * dest,
              DataSourceGetter * getter, void * data)
{
    UInt16 offset;
    Int32 value;
    UInt16 i;
    UInt8 b;
    char * str;
    Int16 noteField = -1;
    UInt16 notetitleLength = 0;
    UInt16 *offsets;
    UInt16 size = source->schema.numFields * sizeof(UInt16);
    Err err = errNone;

    offsets = (UInt16 *)AllocateMemPtr(size);
    offset = source->schema.numFields * sizeof(UInt16);
    for (i = 0; i < source->schema.numFields; i++) {
        /* Mark the starting offset of this field. */
        offsets[i] = offset;

        /* Pack the field into the buffer. */
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            str = getter->GetString(data, i);
            err = DmWrite(dest, offset, str, StrLen(str) + 1);
            offset += StrLen(str) + 1;
            break;

        case FIELD_TYPE_NOTE:
            str = getter->GetNoteTitle(data, i);
            err = DmWrite(dest, offset, str, StrLen(str) + 1);
            offset += StrLen(str) +3;
            if( noteField == -1) {
                notetitleLength = StrLen(str);
                noteField = i;
            }
            break;

        case FIELD_TYPE_BOOLEAN:
            b = (getter->GetBoolean(data, i)) ? 1 : 0;
            err = DmWrite(dest, offset, &b, sizeof(UInt8));
            offset += sizeof(UInt8);
            break;

        case FIELD_TYPE_INTEGER:
            value = getter->GetInteger(data, i);
            err = DmWrite(dest, offset, &value, sizeof(Int32));
            offset += sizeof(Int32);
            break;

        case FIELD_TYPE_DATE:
            {
                UInt16 year;
                UInt8 month, day;

                getter->GetDate(data, i, &year, &month, &day);

                err = DmWrite(dest, offset, &year, sizeof(year));
                offset += sizeof(year);

                err = DmWrite(dest, offset, &month, sizeof(month));
                offset += sizeof(month);

                err = DmWrite(dest, offset, &day, sizeof(day));
                offset += sizeof(day);
            }
            break;

        case FIELD_TYPE_TIME:
            {
                UInt8 hour, minute;

                getter->GetTime(data, i, &hour, &minute);

                err = DmWrite(dest, offset, &hour, sizeof(hour));
                offset += sizeof(hour);

                err = DmWrite(dest, offset, &minute, sizeof(minute));
                offset += sizeof(minute);
            }
            break;

        case FIELD_TYPE_LIST:
            {
                UInt8 value;

                value = getter->GetListItem(data, i);

                err = DmWrite(dest, offset, &value, sizeof(value));
                offset += sizeof(value);
            }
            break;

        case FIELD_TYPE_LINK:
            {
                str = getter->GetLink(data, i, (UInt32 *)&value);

                err = DmWrite(dest, offset, &value, sizeof(UInt32));
                offset += sizeof(UInt32);
                if (str) {
                    err = DmWrite(dest, offset, str, StrLen(str) + 1);
                    offset += StrLen(str) + 1;
                } else {
                    err = DmWrite(dest, offset, "\0", 1);
                    offset += 1;                
                }
            }
            break;

        case FIELD_TYPE_LINKED:
            {
                str = getter->GetLinked(data, i);

                if (str) {
                    err = DmWrite(dest, offset, str, StrLen(str) + 1);
                    offset += StrLen(str) + 1;
                } else {
                    err = DmWrite(dest, offset, "\0", 1);
                    offset += 1;                
                }
            }
            break;

        case FIELD_TYPE_FLOAT:
            {
                double fv;

                fv = getter->GetFloat( data, i );
                err = DmWrite(dest, offset, &fv, sizeof(double));
                offset += sizeof(double);
            }
            break;

#ifdef CONFIG_SCRIPTS
		case FIELD_TYPE_CALCULATED:
		  {
			// Don't actually pack, we do that later in
			// DB_PackSRCalculations and DB_PackIRCalculations
            offset +=
			  CV_GetPackedSize(&(source->schema.fields[i].data.calc));
            break;
          }
#endif

        default:
            ErrDisplay("DB_PackRecord: unsupported field type");
            break;
        }

        if (source->schema.fields[i].data.changed){
            UInt32 tsize;
            UInt8 *p;

            p = BuildFieldDataChunk( &(source->schema), i, &tsize);
            if (p) {
                DB_Chunk_Replace(source, CHUNK_FIELD_DATA, i, p, tsize);
                DeallocateMemPtr(p);
            }
        }
    }
    if (noteField > -1) {
        str = getter->GetNote(data, noteField);
        if( str && StrLen( str)) {
            err = DmWrite(dest, offset, str, (NOTE_MAXCHAR > StrLen(str) + 1)?StrLen(str) + 1:NOTE_MAXCHAR);
            err = DmWrite(dest, offsets[noteField] + 1 + notetitleLength, &offset, sizeof(UInt16));
        } else {
            offset = 0;
            err = DmWrite(dest, offsets[noteField] + 1 + notetitleLength, &offset, sizeof(UInt16));
        }
    }

    /* Write the offset table into the start of the record. */
    err = DmWrite(dest, 0, &offsets[0], size);

    DeallocateMemPtr(offsets);
}

static char *
DB_Getter_GetString(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;

    return (char *)((UInt8 *) data) + offsets[fieldNum];
}

static Int32
DB_Getter_GetInteger(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;
    Int32 value;

    MemMove(&value, ((UInt8 *) data) + offsets[fieldNum], sizeof(Int32));
    return value;
}

static Boolean
DB_Getter_GetBoolean(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;

    if ( *(((UInt8 *) data) + offsets[fieldNum]) )
        return true;
    else
        return false;
}

static void
DB_Getter_GetDate(void * data, UInt16 fieldNum,
                  UInt16* year, UInt8* month, UInt8* day)
{
    UInt16 * offsets = (UInt16 *) data;
    UInt8 * ptr =  ((UInt8 *) data) + offsets[fieldNum];

    MemMove(year, ptr, sizeof(UInt16));
    MemMove(month, ptr + sizeof(UInt16), sizeof(UInt8));
    MemMove(day, ptr + sizeof(UInt16) + sizeof(UInt8), sizeof(UInt8));
}

static void
DB_Getter_GetTime(void * data, UInt16 fieldNum,
                  UInt8* hour, UInt8* minute)
{
    UInt16 * offsets = (UInt16 *) data;
    UInt8 * ptr =  ((UInt8 *) data) + offsets[fieldNum];

    MemMove(hour, ptr, sizeof(UInt8));
    MemMove(minute, ptr + sizeof(UInt8), sizeof(UInt8));
}

static char *
DB_Getter_GetNoteTitle(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;

    return (char*)((UInt8 *) data) + offsets[fieldNum];
}

static char *
DB_Getter_GetNote(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;
    UInt16 offset = 0;

    MemMove(&offset, ((UInt8 *) data) + offsets[fieldNum]
                + StrLen( (char *)((UInt8 *) data) + offsets[fieldNum]) + 1, sizeof(UInt16));
    if( !offset)
        return 0;

    return (char *)((UInt8 *) data) + offset;
}

static UInt8
DB_Getter_GetListItem(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;
    UInt8 value;

    MemMove(&value, ((UInt8 *) data) + offsets[fieldNum], sizeof(UInt8));
    return value;
}

static char *
DB_Getter_GetLink(void * data, UInt16 fieldNum, UInt32* uniqID)
{
    UInt16 * offsets = (UInt16 *) data;
    Char * p = (Char *)((UInt8 *) data) + offsets[fieldNum] + sizeof(UInt32);

    if ( uniqID) {
        MemMove(uniqID, ((UInt8 *) data) + offsets[fieldNum], sizeof(UInt32));
    }
    return p;
}

static char *
DB_Getter_GetLinked(void * data, UInt16 fieldNum)
{
    UInt16 * offsets = (UInt16 *) data;
    Char * p = (Char *)((UInt8 *) data) + offsets[fieldNum];

    return p;
}

static double
DB_Getter_GetFloat(void * data, UInt16 fieldNum)
{
    
  UInt16 * offsets = (UInt16 *)data;
  double d = 0.0;
  
  MemMove( &d, ((UInt8 *)data) + offsets[fieldNum], sizeof( double ) );
  return d;

}

#ifdef CONFIG_SCRIPTS
static void
DB_Getter_GetCalculated(void * data, UInt16 fieldNum, CalculatedValue *c)
{
    
  UInt16 * offsets = (UInt16 *)data;
  UInt8 *p;

  p = ((UInt8 *) data) + offsets[fieldNum];
  c->info = *p;

  switch( c->info ) {
  case FIELD_TYPE_STRING:
	c->value.s = (char *)p+1; break;
  case CV_FIELD_TYPE_DURATION:
  case FIELD_TYPE_INTEGER:
	MemMove( &(c->value.i), p+1, sizeof( Int32 ) ); break;
  case FIELD_TYPE_FLOAT:
	MemMove( &(c->value.d), p+1, sizeof( double ) ); break;
  case FIELD_TYPE_DATE:
	MemMove( &(c->value.ymd), p+1, sizeof( Date ) ); break;
  case FIELD_TYPE_TIME:
	MemMove( &(c->value.t), p+1, sizeof( Time ) ); break;
  case CV_FIELD_TYPE_NA:
  case CV_FIELD_TYPE_BROKEN:
	break; // do nothing. the calculated value has no known value
  default:
	DbgPrintF("Trying to get unimplemented Calculated type %u", c->info);
	break;

  }

}
#endif

static void
DB_PDB_LockRecord(DataSource * source, UInt16 index, Boolean writable,
              DataSourceGetter * getter, void ** data_ptr)
{
    MemHandle h;

    if (writable) {
        h = DmGetRecord(source->db, index);
    } else {

        h = DmQueryRecord(source->db, index);
    }
    *data_ptr = MemHandleLock(h);

    getter->GetString  = DB_Getter_GetString;
    getter->GetInteger = DB_Getter_GetInteger;
    getter->GetBoolean = DB_Getter_GetBoolean;
    getter->GetDate    = DB_Getter_GetDate;
    getter->GetTime    = DB_Getter_GetTime;
    getter->GetNote    = DB_Getter_GetNote;
    getter->GetNoteTitle = DB_Getter_GetNoteTitle;
    getter->GetListItem = DB_Getter_GetListItem;
    getter->GetLink = DB_Getter_GetLink;
    getter->GetLinked = DB_Getter_GetLinked;
    getter->GetFloat = DB_Getter_GetFloat;
#ifdef CONFIG_SCRIPTS
	getter->GetCalculated = DB_Getter_GetCalculated;
#endif
}

static void
DB_PDB_UnlockRecord(DataSource * source, UInt16 index, Boolean writable,
                void * record_data)
{
    MemPtrUnlock(record_data);
    if (writable) {
//        MemPtrUnlock(record_data);
        DmReleaseRecord(source->db, index, true);
//    } else {
//        DeallocateMemPtr(record_data);
    }
}

static Err
DB_PDB_UpdateRecord(DataSource * source, UInt16 * indexP, Boolean doInsert,
                DataSourceGetter * getter, void * data)
{
    UInt32 size;
    MemHandle recH;
    void * packed;

    /* Determine the packed size of the new record. */
    size = DB_PackedRecordSize(source, getter, data);

    if (*indexP == dmMaxRecordIndex || doInsert) {
        /* Create a new record in the database. */
        recH = DmNewRecord(source->db, indexP, size);
        if (recH == 0) {
            /* If we couldn't make the record, bail out. */
            return DmGetLastErr();
        }
    } else {
        /* Otherwise, retrieve and resize an existing record. */
        DmResizeRecord(source->db, *indexP, size);
        recH = DmGetRecord(source->db, *indexP);
        if (recH == 0) {
            /* If we couldn't make the record, bail out. */
            return DmGetLastErr();
        }
    }

    /* Pack the new data into the record. */
    packed = MemHandleLock(recH);
    DB_PackRecord(source, packed, getter, data);
	/* swallace begin  */
#ifdef CONFIG_SCRIPTS
	DB_PackSRCalculations( source, packed, *indexP );
#endif
    /* swallace end */
    MemPtrUnlock(packed);

    /* Release the write lock on the record. */
    DmReleaseRecord(source->db, *indexP, true);

    return 0;
}

static void
DB_SetField(DataSource * source, void * data, UInt16 fieldNum,
            DataSourceGetter * getter, void * getter_arg)
{
    UInt16 * offsets = (UInt16 *) data;
    UInt8 b;
    Int32 value;
	double fv;

    switch (source->schema.fields[fieldNum].type) {
    case FIELD_TYPE_BOOLEAN:
        b = getter->GetBoolean(getter_arg, fieldNum) ? 1 : 0;
        DmWrite(data, offsets[fieldNum], &b, sizeof(UInt8));
        break;

    case FIELD_TYPE_INTEGER:
        value = getter->GetInteger(getter_arg, fieldNum);
        DmWrite(data, offsets[fieldNum], &value, sizeof(Int32));
        break;

	case FIELD_TYPE_FLOAT:
	  
	    fv = getter->GetFloat(getter_arg, fieldNum);
		DmWrite(data, offsets[fieldNum], &fv, sizeof(double));
		break;

    default:
        ErrDisplay("field type not supported");
        break;
    }
}

static UInt16
DB_GetNumOfViews(DataSource * source)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    UInt32 token = 0;
    UInt16 numViews = 0;

    GetAppInfoBlock(source, &info);
    while (GetNextChunk(&info, &token, &chunk)) {
        if (chunk.chunk_type == CHUNK_LISTVIEW_DEFINITION) numViews++;
    }
    PutAppInfoBlock(source, &info);

    return numViews;
}

static DataSourceView *
DB_GetView(DataSource * source, UInt16 viewIndex)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    DataSourceView * view;

    /* Retrieve the list view definition. */
    GetAppInfoBlock(source, &info);
    if (GetChunkByType(&info, &chunk, CHUNK_LISTVIEW_DEFINITION, viewIndex)) {
        UInt16 flags, numCols, i;
        UInt8 * p;
    
        /* Allocate space for the view structure. */
        view = (DataSourceView *) AllocateMemPtr(sizeof(*view));

        /* Copy the header of this definition into local storage. */
        MemMove(&flags,   chunk.chunk_data,     sizeof(UInt16));
        MemMove(&numCols, chunk.chunk_data + 2, sizeof(UInt16));

        StrNCopy(view->name, (const char *)chunk.chunk_data + 4, sizeof(view->name));
        view->flags = flags;
        view->numCols = numCols;
        view->cols = AllocateMemPtr(view->numCols * sizeof(DataSourceViewColumn));

        /* Copy the column info of this definition into local storage. */
        p = chunk.chunk_data + 2 + 2 + 32;
        for (i = 0; i < view->numCols; ++i) {
                UInt16 fieldNum, width;

            MemMove(&fieldNum, p,     sizeof(UInt16));
            MemMove(&width,    p + 2, sizeof(UInt16));
            p += 4ul;

            view->cols[i].fieldNum = fieldNum;
                view->cols[i].width = width;
        }
    } else {
        view = DS_GetView(source, viewIndex);
    }
    PutAppInfoBlock(source, &info);

    return view;
}

static void
DB_StoreView(DataSource * source, UInt16 viewIndex, DataSourceView * view)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    UInt8 *p, *q;
    Boolean exists;
    UInt16 flags = view->flags, i;

    /* Construct the chunk that we will store. */
    p = (UInt8 *)AllocateMemPtr(2ul + 2ul + 32ul + view->numCols * (2ul + 2ul));
    MemMove(p, &flags, sizeof(UInt16));
    MemMove(p + 2ul, &view->numCols, sizeof(UInt16));
    MemMove(p + 4ul, view->name, 32);
    for (i = 0, q = p + 2 + 2 + 32; i < view->numCols; ++i) {
        MemMove(q, &(view->cols[i].fieldNum), sizeof(UInt16));
        MemMove(q + 2ul, &(view->cols[i].width), sizeof(UInt16));
        q += 4ul;
    }

    /* See if this view is an existing one that we can replace. */
    GetAppInfoBlock(source, &info);
    exists = GetChunkByType(&info, &chunk,
                            CHUNK_LISTVIEW_DEFINITION, viewIndex);
    PutAppInfoBlock(source, &info);

    if (exists) {
        /* We can replace the existing chunk. */
        DB_Chunk_Replace(source, CHUNK_LISTVIEW_DEFINITION, viewIndex,
                         p, MemPtrSize(p));
    } else {
        /* Append this chunk to the app info block instead. */
        DB_Chunk_Append(source, CHUNK_LISTVIEW_DEFINITION, p, MemPtrSize(p));
    }

    /* Free the temporary copy of the chunk. */
    DeallocateMemPtr(p);
}

static void
DB_DeleteView(DataSource * source, UInt16 index)
{
    UInt16 numViews, activeView;

    /* Sanity check: Ensure that at least 1 view will remain and that
     * the index is valid.
     */
    numViews = source->ops.GetNumOfViews(source);
    if (numViews < 1 || index >= numViews)
            return;

    /* Delete the list view's chunk from the app info block. */
    DB_Chunk_Delete(source, CHUNK_LISTVIEW_DEFINITION, index);

    /* Update the active list view index if its list view shifted down. */
    activeView = source->ops.GetOption_UInt16(source,
                                              optionID_ListView_ActiveView);
    if (activeView == index) {
        /* active view was the one just deleted, only safe one is the first */
        activeView = 0;
    } else if (activeView > index) {
        /* active view was above so it is now been shifted down one */
        activeView--;
    }
    source->ops.SetOption_UInt16(source, optionID_ListView_ActiveView, activeView);
    source->ops.SetOption_UInt16(source, optionID_ListView_TopVisibleRecord, 0);
}

static UInt8 *
BuildFieldDataChunk( DataSourceSchema * schema, UInt16 fieldNum, UInt32 *sizeP)
{
    UInt16 j;
    UInt8 *p, *q;
    UInt16 size;

	p = NULL;
    switch (schema->fields[fieldNum].type){
    case FIELD_TYPE_STRING:
        if (!schema->fields[fieldNum].data.string.defaultValue ||
                !StrLen( schema->fields[fieldNum].data.string.defaultValue))
            break;
        *sizeP = 2;
        size = StrLen( schema->fields[fieldNum].data.string.defaultValue) + 1;
        *sizeP += size;
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        StrCopy((char *)q, schema->fields[fieldNum].data.string.defaultValue);
        q += size;
    break;
    case FIELD_TYPE_INTEGER:
        if (!schema->fields[fieldNum].data.integer.defaultValue
                && !schema->fields[fieldNum].data.integer.increment)
            break;
        *sizeP = 2UL;
        *sizeP += 4UL;
        *sizeP += 2UL;
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &(schema->fields[fieldNum].data.integer.defaultValue), sizeof(Int32));
        q += 4UL;
        MemMove(q, &(schema->fields[fieldNum].data.integer.increment), sizeof(Int16));
        q += 2UL;
    break;
    case FIELD_TYPE_FLOAT:
        if (!schema->fields[fieldNum].data.floatNum.defaultValue)
            break;
        *sizeP = 2;
        *sizeP += sizeof(double);
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &(schema->fields[fieldNum].data.floatNum.defaultValue), sizeof(double));
        q += sizeof(double);
	break;
    case FIELD_TYPE_LIST:
    {
        UInt16 numItems = schema->fields[fieldNum].data.list.numItems;
        if (numItems == 0)
            break;
        *sizeP = 2;
        *sizeP += 2 + 2;
        for (j = 0; j < numItems; j++) {
            *sizeP += StrLen( schema->fields[fieldNum].data.list.items[j]) + 1;
        }
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &numItems, sizeof(UInt16));
        q += 2UL;
        q += 2UL;//for the future
        for (j = 0; j < numItems; j++) {
            StrCopy((char *)q, schema->fields[fieldNum].data.list.items[j]);
            q += StrLen(schema->fields[fieldNum].data.list.items[j]) + 1;
        }
    }
    break;
    case FIELD_TYPE_LINK:
        if (schema->fields[fieldNum].data.link.dbID == 0)
            break;
        *sizeP = 2;
        *sizeP += 4 + 2;
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &schema->fields[fieldNum].data.link.dbID, sizeof(UInt32));
        q += 4UL;
        MemMove(q, &schema->fields[fieldNum].data.link.fieldNum, sizeof(UInt16));
        q += 2UL;
    break;
    case FIELD_TYPE_LINKED:
        if (schema->fields[fieldNum].data.linked.linkNum == 0xFFFF)
            break;
        *sizeP = 2UL;
        *sizeP += 2UL + 2UL;
        p = q = (UInt8 *)AllocateMemPtr(*sizeP);
        MemMove(q, &fieldNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &schema->fields[fieldNum].data.linked.linkNum, sizeof(UInt16));
        q += 2UL;
        MemMove(q, &schema->fields[fieldNum].data.linked.fieldNum, sizeof(UInt16));
        q += 2UL;
    break;
#ifdef CONFIG_SCRIPTS
	case FIELD_TYPE_CALCULATED:
	{

	    UInt8 *bc;
		CalculationData *c;

		c = &(schema->fields[fieldNum].data.calc);
		if ( !(c->bytecode) ) {
		  break;
		}
		*sizeP = 2;
		bc = (UInt8 *)MemHandleLock( c->bytecode );

		// room for the size, return type, header and bytecode
		// note that the order does not correspond to the field order of the
		// struct.  This is becuase we want the 1st byte after the size
		// to hold the version...
		*sizeP += c->bytecode_sz + 4;
		p = q = (UInt8 *)AllocateMemPtr( *sizeP );
		MemMove( q, &fieldNum, sizeof(UInt16) );
		q += 2UL;
		*q++ = c->bytecode_sz;      //  bytecode size
		*q++ = 0x10;                //  a version flag
		*q++ = c->access;
		*q++ = c->returnType;       //  script's return type
		MemMove( q, bc, c->bytecode_sz );                  // bytecode
		MemPtrUnlock( bc );

		break;

	}
#endif
    default:
        p = q = NULL;
    }
    return p;
}

static void
DB_UpdateSchema(DataSource * source,
                DataSourceSchema * schema, UInt32 * reorder)
{
    UInt16 i;
    UInt8 *p, *q;
    UInt32 size;

    /* We can only reach this point if DB_CheckUpdateSchema() verified
     * that only field name changes were done. Thus, we can safely
     * just go ahead and change the field names.
     */

    /* Determine the size of the new field name chunk. */
    size = 0;
    for (i = 0; i < schema->numFields; ++i) {
        size += StrLen(schema->fields[i].name) + 1;
    }

    /* Allocate, fill, and install the new field name chunk. */
    p = q = (UInt8 *)AllocateMemPtr(size);
    for (i = 0; i < schema->numFields; ++i) {
        StrCopy((char *)q, schema->fields[i].name);
        q += StrLen(schema->fields[i].name) + 1;
    }
    DB_Chunk_Replace(source, CHUNK_FIELD_NAMES, 0, p, size);
    DeallocateMemPtr(p);

    for (i = 0; i < schema->numFields; ++i) {
        if (schema->fields[i].data.changed) {
            p = BuildFieldDataChunk( schema, i, &size);
            if (p) {
                DB_Chunk_Replace(source, CHUNK_FIELD_DATA, i, p, size);
                DeallocateMemPtr(p);
            }
        }
    }

    {
        AppInfoBlock info;
        GetAppInfoBlock(source, &info);
        if (! ValidateAppInfoBlock(&info))
            DbgPrintF("invalid!!");
        PutAppInfoBlock(source, &info);
    }

    /* Now we need to update the schema. */
    FreeSchema( &source->schema);
    CopySchema(&source->schema, schema);
}

static Boolean
DB_GetOption_Boolean(DataSource * source, UInt16 optionID)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    Boolean result = false;
    UInt16 flags;

    GetAppInfoBlock(source, &info);
    switch (optionID) {
    case optionID_DisableGlobalFind:
        flags = *((UInt16 *) info.ptr);
        if ((flags & FLAG_GFIND_FORCE_ENABLE) != 0)
            result = false;
        else if ((flags & FLAG_GFIND_FORCE_DISABLE) != 0)
            result = true;
        else
            result = false;
        break;

    case optionID_Database_ReadOnly:
        flags = *((UInt16 *) info.ptr);
        if ((flags & FLAG_DATABASE_READONLY) != 0)
            result = true;
        else
            result = false;
        break;

    case optionID_LFind_CaseSensitive:
    case optionID_LFind_WholeWord:
        if (GetChunkByType(&info, &chunk, CHUNK_LFIND_OPTIONS, 0)) {
            MemMove(&flags, chunk.chunk_data, sizeof(flags));
            switch (optionID) {
            case optionID_LFind_CaseSensitive:
                result = (flags & 0x0001) != 0;
                break;
    
            case optionID_LFind_WholeWord:
                result = (flags & 0x0002) != 0;
                break;
            }
        } else {
            result = false;
        }
        break;

    default:
            result = false;
        break;
    }
    PutAppInfoBlock(source, &info);

    return result;
}

static void
DB_SetOption_Boolean(DataSource * source, UInt16 optionID, Boolean value)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    UInt16 flags;

    GetAppInfoBlock(source, &info);
    switch (optionID) {
    case optionID_DisableGlobalFind:
        flags = *((UInt16 *) info.ptr);
        flags &= ~(FLAG_GFIND_FORCE_DISABLE | FLAG_GFIND_FORCE_ENABLE);
        if (value) flags |= FLAG_GFIND_FORCE_DISABLE;
        DmWrite(info.ptr, 0, &flags, sizeof(flags));
        break;

    case optionID_LFind_CaseSensitive:
    case optionID_LFind_WholeWord:
        if (GetChunkByType(&info, &chunk, CHUNK_LFIND_OPTIONS, 0)) {
            UInt16 bits;
    
            MemMove(&flags, chunk.chunk_data, sizeof(UInt16));
            switch (optionID) {
            case optionID_LFind_CaseSensitive:
                bits = 0x0001;
                break;
    
            case optionID_LFind_WholeWord:
                bits = 0x0002;
                break;
    
            default:
                bits = 0;
                break;
            }
            if (value)
                flags |= bits;
            else
                flags &= ~(bits);
            DmWrite(info.ptr, chunk.chunk_data - info.ptr,
                    &flags, sizeof(flags));
        }
        break;
    }
    PutAppInfoBlock(source, &info);
}

static UInt16
DB_GetOption_UInt16(DataSource * source, UInt16 optionID)
{
    AppInfoBlock info;
    AppInfoChunk chunk;
    UInt16 result;

    switch (optionID) {
    case optionID_ListView_ActiveView:
    case optionID_ListView_TopVisibleRecord:
        GetAppInfoBlock(source, &info);
        if (GetChunkByType(&info, &chunk, CHUNK_LISTVIEW_OPTIONS, 0)) {
            switch (optionID) {
            case optionID_ListView_ActiveView:
                MemMove(&result, ((UInt16 *) chunk.chunk_data) + 0,
                                        sizeof(UInt16));
                break;
    
            case optionID_ListView_TopVisibleRecord:
                MemMove(&result, ((UInt16 *) chunk.chunk_data) + 1,
                                        sizeof(UInt16));
                break;
            }
        } else
            result = 0;
        PutAppInfoBlock(source, &info);
        break;

    default:
        result = 0;
        break;
    }

    return result;
}

static void
DB_SetOption_UInt16(DataSource * source, UInt16 optionID, UInt16 value)
{
    AppInfoBlock info;
    AppInfoChunk chunk;

    switch (optionID) {
    case optionID_ListView_ActiveView:
    case optionID_ListView_TopVisibleRecord:
        GetAppInfoBlock(source, &info);
        if (GetChunkByType(&info, &chunk, CHUNK_LISTVIEW_OPTIONS, 0)) {
            switch (optionID) {
            case optionID_ListView_ActiveView:
                DmWrite(info.ptr, chunk.chunk_data - info.ptr,
                                        &value, sizeof(value));
                break;
    
            case optionID_ListView_TopVisibleRecord:
                DmWrite(info.ptr, chunk.chunk_data-info.ptr + 1*sizeof(UInt16),
                                        &value, sizeof(value));
                break;
            }
        }
        PutAppInfoBlock(source, &info);
        break;
    }
}

static Int16
DB_SortCallback(void * rec1, void * rec2, Int16 other,
                SortRecordInfoPtr rec1SortInfo, SortRecordInfoPtr rec2SortInfo,
                MemHandle appInfoH)
{
    SortCallbackData * data = (SortCallbackData *) sort_callback_data;
    int result;

    result = data->callback(data->source,
                            &data->getter, rec1,
                            &data->getter, rec2,
                            data->callback_data);

    return result;
}

static void
DB_Sort(DataSource * source,
        DataSourceSortCallback callback, void * callback_data)
{
    SortCallbackData data;

    data.callback = callback;
    data.callback_data = callback_data;
    data.source = source;
    data.getter.GetString = DB_Getter_GetString;
    data.getter.GetInteger = DB_Getter_GetInteger;
    data.getter.GetBoolean = DB_Getter_GetBoolean;
    data.getter.GetDate = DB_Getter_GetDate;
    data.getter.GetTime = DB_Getter_GetTime;
    data.getter.GetNote = DB_Getter_GetNote;
    data.getter.GetNoteTitle = DB_Getter_GetNoteTitle;
    data.getter.GetListItem = DB_Getter_GetListItem;
    data.getter.GetLink = DB_Getter_GetLink;
    data.getter.GetLinked = DB_Getter_GetLinked;
    data.getter.GetFloat = DB_Getter_GetFloat;
#ifdef CONFIG_SCRIPTS
    data.getter.GetCalculated = DB_Getter_GetCalculated;
#endif
    sort_callback_data = &data;
    DmQuickSort(source->db, DB_SortCallback, 0);
}

static Boolean
DB_Capable(DataSource * source, DataSourceCapability capability)
{
    switch (capability) {
    case DS_CAPABLE_LISTVIEW_EDIT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_INSERT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_DELETE:
        return ! (source->openMode == dmModeReadOnly) && source->ops.GetNumOfViews(source) > 0;
    case DS_CAPABLE_LISTVIEW_NAME_EDIT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_FIELD_EDIT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_FIELD_INSERT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_FIELD_DELETE:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_WIDTH_EDIT:
        return ! (source->openMode == dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_FILTER:
        return true;
    default:
        return false;
    }
}

static Err
OpenDB(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size)
{
    DataSourceChooserKey * key = (DataSourceChooserKey *) key_data;
    Err err;
    UInt32 dbType;
    UInt16 numFields;
    AppInfoBlock info;
    LocalID dbID;
    UInt16 attr;

    /* Make sure that the key has a valid size. */
    if (key_size != sizeof(DataSourceChooserKey))
        return dmErrCantOpen;
    
    source->openMode = mode;
    mode &= ~MaskReadEdit;

    /* We do not have any private data for this source. */
    source->data = 0;

    /* Retrieve the location in memory of this database. */
    dbID = DmFindDatabase(key->cardNo, key->name);
    if (!dbID)
        return DmGetLastErr();

    /* Check to see if we support this type of database. */
    DmDatabaseInfo(key->cardNo, dbID, 0, &attr, 0, 0, 0, 0, 0, 0, 0, &dbType, 0);
    if (dbType != 'DB00')
        return dmErrCantOpen;

    if (attr & dmHdrAttrReadOnly){
        source->openMode = dmModeReadOnly;
        mode = dmModeReadOnly;
        //return dmErrCantOpen;
    }

    /* Open this database. */
    source->db = DmOpenDatabase(key->cardNo, dbID, mode);
    if (! source->db)
        return DmGetLastErr();

    /* Retrieve the app info block which contains all the metadata. */
    if (GetAppInfoBlock(source, &info))
        return dmErrCorruptDatabase;

    /* Validate the app info block before using it. */
    if (! ValidateAppInfoBlock(&info)) {
        PutAppInfoBlock(source, &info);
        DmCloseDatabase(source->db);
        source->db = 0;
        return dmErrCorruptDatabase;
    }

    if ((mode != dmModeReadOnly) 
            && ((((UInt16 *)info.ptr)[0] & FLAG_DATABASE_READONLY) != 0)) {
        PutAppInfoBlock(source, &info);
        DmCloseDatabase(source->db);
        source->db = 0;
        return OpenDB(source, dmModeReadOnly, key_data, key_size);
    }

   /* Extract the number of fields from the header. */
    MemMove(&numFields, info.ptr + sizeof(UInt16), sizeof(numFields));
    source->schema.numFields = numFields;

    /* Extract the entire schema into local storage. */
    err = ExtractSchema(source, &info);
    if (err) {
        PutAppInfoBlock(source, &info);
        DmCloseDatabase(source->db);
        source->db = 0;
        return err;
    }

    /* Put away our reference to the app info block. */
    PutAppInfoBlock(source, &info);

    return 0;
}

static Err
DB_PDB_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size)
{
    Err error;

    /* Fill in the operations structure. */
    source->ops.Close = DS_PDB_Close;
    source->ops.Seek = DS_Seek;
    source->ops.LockRecord = DB_PDB_LockRecord;
    source->ops.UnlockRecord = DB_PDB_UnlockRecord;
    source->ops.UpdateRecord = DB_PDB_UpdateRecord;
    source->ops.SetField = DB_SetField;
    source->ops.DeleteRecord = DS_DeleteRecord;
    source->ops.GetRecordID = DS_GetRecordID;
    source->ops.GetRecordIndex = DS_GetRecordIndex;
    source->ops.FilterRecord = DS_FilterRecord;
    source->ops.SetFilter = DS_SetFilter;
    source->ops.GetCurrentFilter = DS_GetCurrentFilter;
    source->ops.GetNumOfViews = DB_GetNumOfViews;
    source->ops.GetView = DB_GetView;
    source->ops.PutView = DS_PutView;
    source->ops.StoreView = DB_StoreView;
    source->ops.DeleteView = DB_DeleteView;
    source->ops.CheckUpdateSchema = DS_CheckUpdateSchema;
    source->ops.UpdateSchema = DB_UpdateSchema;
    source->ops.GetOption_Boolean = DB_GetOption_Boolean;
    source->ops.SetOption_Boolean = DB_SetOption_Boolean;
    source->ops.GetOption_UInt16 = DB_GetOption_UInt16;
    source->ops.SetOption_UInt16 = DB_SetOption_UInt16;
    source->ops.GetKey = DS_GetKey;
    source->ops.GetPDB = DS_PDB_GetPDB;
    source->ops.GetTitle = DS_PDB_GetTitle;
    source->ops.SetTitle = DS_PDB_SetTitle;
    source->ops.Sort = DB_Sort;
    source->ops.Capable = DB_Capable;
    source->ops.Info = DS_PDB_Info;
#ifdef CONFIG_SCRIPTS
    source->ops.RecalculateFields = DB_PackIRCalculations;
	source->ops.ExecuteScript = ScriptRun;
#else
    source->ops.RecalculateFields = NULL;
	source->ops.ExecuteScript = NULL;
#endif

    error = OpenDB(source, mode, key_data, key_size);
    if (!error) {
        /* store the key of the database*/
        source->key.size = key_size;
        source->key.data = AllocateMemPtr(key_size);
        MemMove( source->key.data, key_data, key_size);
    }
    return error;
}


static Err
DB_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size)
{
    if (key_size == sizeof(DataSourceChooserKey)) {
        return DB_PDB_Open(source, mode, key_data, key_size);
    }else
        return 0;
}

static Err
DB_OpenPDB(DataSource * source, UInt16 mode, UInt16 cardNo, LocalID dbID)
{
    DataSourceChooserKey key;

    key.cardNo = cardNo;
    DmDatabaseInfo(cardNo, dbID, key.name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return DB_PDB_Open(source, mode, &key, sizeof(key));
}


#ifdef CONFIG_GLOBALFIND
static Err
DB_QuickOpenPDB(DataSource * source, UInt16 mode, UInt16 cardNo, LocalID dbID)
{
    Err error;
    DataSourceChooserKey key;

    key.cardNo = cardNo;
    DmDatabaseInfo(cardNo, dbID, key.name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    source->ops.Close = DS_PDB_Close;
    source->ops.Seek = DS_Seek;
    source->ops.LockRecord = DB_PDB_LockRecord;
    source->ops.UnlockRecord = DB_PDB_UnlockRecord;
    source->ops.GetRecordID = DS_GetRecordID;
    source->ops.GetRecordIndex = DS_GetRecordIndex;
    source->ops.GetOption_Boolean = DB_GetOption_Boolean;
    source->ops.GetOption_UInt16 = DB_GetOption_UInt16;
    source->ops.GetKey = DS_GetKey;
    source->ops.GetPDB = DS_PDB_GetPDB;
    source->ops.GetTitle = DS_PDB_GetTitle;
    source->ops.Capable = DB_Capable;
    source->ops.Info = DS_PDB_Info;

    error = OpenDB(source, mode, &key, sizeof(DataSourceChooserKey));
    if (!error) {
        /* store the key of the database*/
        source->key.size = sizeof(DataSourceChooserKey);
        source->key.data = AllocateMemPtr(source->key.size);
        MemMove( source->key.data, &key, source->key.size);
    }
    return error;
}
#endif

static Err
DB_Create(const char* name, DataSourceSchema* schema,
          void ** key_data_ptr, UInt16 * key_size_ptr)
{
    Err err;
    LocalID dbID, appInfoID;
    MemHandle appInfoHand, h;
    UInt8 *p, *q;
    UInt16 flags, i, attr;
    UInt32 size;
    DmOpenRef db;
    DataSourceChooserKey *key;
    Boolean onlyOneNote = false;

    for (i = 0; i < schema->numFields; ++i) {
        switch (schema->fields[i].type) {
        case FIELD_TYPE_INTEGER:
        break;		  
        case FIELD_TYPE_NOTE:
            if (onlyOneNote)
            {
                FrmAlert( alertID_MaxNoteSupport);
                return 1;
            }
            else
                onlyOneNote = true;
        break;

        default:
            break;
        }
    }

    err = DmCreateDatabase(0, name, DBCreatorID, 'DB00', false);
    if (err)
        return err;
    err = 0;

    dbID = DmFindDatabase(0, name);

    db = DmOpenDatabase(0, dbID, dmModeReadWrite);
    if (! db)
        return DmGetLastErr();

    /* Create a memory handle with no chunks. */
    h = AllocateMemHandle(2 * sizeof(UInt16));
    p = (UInt8 *)MemHandleLock(h);
    flags = 0;
    MemMove(p, &flags, sizeof(UInt16)); /* flags */
    MemMove(p + sizeof(UInt16), &(schema->numFields), sizeof(UInt16));
    MemPtrUnlock(p);
    
    /* Determine how large the field name chunk should be. */
    size = 0;
    for (i = 0; i < schema->numFields; ++i) {
        size += StrLen(schema->fields[i].name) + 1;
    }
    p = q = (UInt8 *)AllocateMemPtr(size);
    for (i = 0; i < schema->numFields; ++i) {
        StrCopy((char *)q, schema->fields[i].name);
        q += StrLen(schema->fields[i].name) + 1;
    }
    AppendChunk(h, CHUNK_FIELD_NAMES, p, size);
    DeallocateMemPtr(p);

    /* Build the field types chunk. */
    p = (UInt8 *)AllocateMemPtr(schema->numFields * sizeof(UInt16));
    for (i = 0, q = p; i < schema->numFields; ++i) {
        UInt16 type;
    
        switch (schema->fields[i].type) {
        case FIELD_TYPE_STRING:
            type = 0;
            break;
    
        case FIELD_TYPE_BOOLEAN:
            type = 1;
            break;
    
        case FIELD_TYPE_INTEGER:
            type = 2;
            break;
    
        case FIELD_TYPE_DATE:
            type = 3;
            break;
    
        case FIELD_TYPE_TIME:
            type = 4;
            break;
    
        case FIELD_TYPE_NOTE:
                type = 5;
            break;
    
        case FIELD_TYPE_LIST:
                type = 6;
            break;
    
        case FIELD_TYPE_LINK:
                type = 7;
            break;
    
		case FIELD_TYPE_FLOAT:
                type = 8;
            break;

#ifdef CONFIG_SCRIPTS
		case FIELD_TYPE_CALCULATED:
                type = 9;
            break;
#endif

        case FIELD_TYPE_LINKED:
                type = 10;
            break;
    
        default:
            ErrDisplay("field type not supported");
            break;
        }
    
        MemMove(q, &type, sizeof(UInt16));
        q += 2UL;
    }
    AppendChunk(h, CHUNK_FIELD_TYPES, p, schema->numFields * sizeof(UInt16));
    DeallocateMemPtr(p);

    for (i = 0; i < schema->numFields; i++) {
        p = BuildFieldDataChunk( schema, i, &size);
        if (p) {
            AppendChunk(h, CHUNK_FIELD_DATA, p, size);
            DeallocateMemPtr(p);
        }
    }

    /* Create and append the chunk that will hold list view options. */
    p = (UInt8 *)AllocateMemPtr(2 * sizeof(UInt16));
    MemSet(p, MemPtrSize(p), 0);
    AppendChunk(h, CHUNK_LISTVIEW_OPTIONS, p, MemPtrSize(p));
    DeallocateMemPtr(p);
    /* Create and append the chunk that will hold the local find options. */
    p = (UInt8 *)AllocateMemPtr(1 * sizeof(UInt16));
    MemSet(p, MemPtrSize(p), 0);
    AppendChunk(h, CHUNK_LFIND_OPTIONS, p, MemPtrSize(p));
    DeallocateMemPtr(p);

    /* Create and fill the handle that will actually store the data. */
    size = MemHandleSize(h);
    appInfoHand = DmNewHandle(db, size);
    appInfoID = MemHandleToLocalID(appInfoHand);
    p = (UInt8 *)MemLocalIDToLockedPtr(appInfoID, 0);
    q = (UInt8 *)MemHandleLock(h);
    DmWrite(p, 0, q, MemHandleSize(h));
    MemPtrUnlock(p);
    MemPtrUnlock(q);
    DeallocateMemHandle(h);

    /*set the backup attribut to true*/
    DmDatabaseInfo(0, dbID, 0, &attr, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    attr |= dmHdrAttrBackup;

    /* Store a handle to the app info block. */
    DmSetDatabaseInfo(0, dbID, 0, &attr, 0, 0, 0, 0, 0, &appInfoID, 0, 0, 0);

    /* Close the database. */
    DmCloseDatabase(db);

    /* Add this database into the chooser screen. */
    key = (DataSourceChooserKey *) AllocateMemPtr(sizeof(DataSourceChooserKey));
    MemSet(key, sizeof(*key), 0);
    key->cardNo = 0;
    StrNCopy(key->name, name, sizeof(key->name) - 1);
    key->name[sizeof(key->name)-1] = '\0';
    *key_data_ptr = key;
    *key_size_ptr = sizeof(*key);

    return err;
}

static Boolean
DB_SupportsFieldType(DataSourceFieldType type)
{
    switch (type) {
    case FIELD_TYPE_STRING:
    case FIELD_TYPE_INTEGER:
    case FIELD_TYPE_BOOLEAN:
    case FIELD_TYPE_DATE:
    case FIELD_TYPE_TIME:
    case FIELD_TYPE_NOTE:
    case FIELD_TYPE_LIST:
    case FIELD_TYPE_LINK:
    case FIELD_TYPE_LINKED:
	case FIELD_TYPE_FLOAT:
#ifdef CONFIG_SCRIPTS
	case FIELD_TYPE_CALCULATED:
#endif
        return true;

    default:
        return false;
    }
}

static void
DB_Enumerate(DataSourceEnumerationFunc callback, void * arg)
{
    DS_Enumerate(callback, arg, 'DB00', DBCreatorID, sourceID_DB);
}

#ifdef CONFIG_GLOBALFIND
static Boolean
DB_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation,
              FindParamsPtr params)
{
    return DS_GlobalFind(callback, continuation, params, 'DB00',
                             DBCreatorID, DB_QuickOpenPDB);
}
#endif

static Boolean
DB_IsPresent(void * key_data, UInt32 key_size)
{
    return DS_IsPresent(key_data, key_size, 'DB00', DBCreatorID);
}

static Boolean
DB_CanHandlePDB(UInt16 cardNo, LocalID dbID, UInt32 type, UInt32 creator)
{
    return (creator == DBCreatorID) && (type == 'DB00');
}

DataSourceDriver *
DB_GetDriver(void)
{
    DataSourceDriver * driver = AllocateMemPtr(sizeof(DataSourceDriver));

    StrCopy(driver->name, "DB");
    driver->sourceID = sourceID_DB;
    driver->class_ops.Open = DB_Open;
    driver->class_ops.OpenPDB = DB_OpenPDB;
    driver->class_ops.CheckTitle = DS_CheckTitle;
    driver->class_ops.Create = DB_Create;
    driver->class_ops.SupportsFieldType = DB_SupportsFieldType;
    driver->class_ops.Delete = DS_Delete;
    driver->class_ops.Enumerate = DB_Enumerate;
#ifdef CONFIG_GLOBALFIND
    driver->class_ops.GlobalFind = DB_GlobalFind;
#else
    driver->class_ops.GlobalFind = NULL;
#endif
    driver->class_ops.IsPresent = DB_IsPresent;
    driver->class_ops.CompareKey = DS_CompareKey;
    driver->class_ops.CanHandlePDB = DB_CanHandlePDB;
    driver->class_ops.Exchange = DS_PDB_Exchange;
#ifdef CONFIG_SCRIPTS
#ifdef GLOBAL_ACCESS
	driver->class_ops.CompileScript = ScriptCompile;
	driver->class_ops.DecompileScript = ScriptDecompile;
#endif
#endif
    return driver;
}

#ifdef CONFIG_GLOBALFIND
DataSourceDriver *
DB_GetSmallDriver(void)
{
    DataSourceDriver * driver = AllocateMemPtr(sizeof(DataSourceDriver));

    StrCopy(driver->name, "DB");
    driver->sourceID = sourceID_DB;
    driver->class_ops.Open = DB_Open;
    driver->class_ops.OpenPDB = DB_OpenPDB;
    driver->class_ops.CheckTitle = DS_CheckTitle;
    driver->class_ops.SupportsFieldType = DB_SupportsFieldType;
    driver->class_ops.GlobalFind = DB_GlobalFind;
    driver->class_ops.IsPresent = DB_IsPresent;
    driver->class_ops.CompareKey = DS_CompareKey;
    driver->class_ops.CanHandlePDB = DB_CanHandlePDB;
    driver->class_ops.Exchange = DS_PDB_Exchange;
    return driver;
}
#endif
/************************************************************************************/
/*VFS support                                                                       */
/************************************************************************************/
#ifdef CONFIG_VFS
#include <VFSMgr.h>
#include "iovfs.h"


static void     DB_VFS_Enumerate(DataSourceEnumerationFunc callback, void * arg) SECT_DRV;
static Boolean  DB_VFS_IsPresent(void * key_data, UInt32 key_size) SECT_DRV;
static Err      DB_VFS_Open(DataSource * source, UInt16 mode,
                                void * key_data, UInt16 key_size) SECT_DRV;
static Err      DB_VFS_Create(const char* name, DataSourceSchema* schema,
                                void ** key_data_ptr, UInt16 * key_size_ptr) SECT_DRV;

static void
DB_VFS_Enumerate(DataSourceEnumerationFunc callback, void * arg)
{
    DS_VFS_Enumerate(callback, arg, 'DB00', DBCreatorID, sourceID_DBvfs);
}

static Boolean
DB_VFS_IsPresent(void * key_data, UInt32 key_size)
{
    return DS_VFS_IsPresent(key_data, key_size, 'DB00', DBCreatorID);
}

static Err
DB_VFS_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size)
{
    Err error;
    VFSChooserKey* key = (VFSChooserKey *) key_data;
    DataSourceChooserKey keyPDB;
    UInt16 cardNo;
    LocalID dbID;

    if (key_size != sizeof(VFSChooserKey))
        return dmErrCantOpen;

    if (VFSImportDatabaseFromFile(key->volRefNum, key->name, &cardNo, &dbID) != errNone)
        return dmErrCantOpen;

    DmDatabaseInfo(cardNo, dbID, keyPDB.name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    keyPDB.cardNo = cardNo;

    /* Fill in the operations structure. */
    source->ops.Close = DS_VFS_Close;
    source->ops.Seek = DS_Seek;
    source->ops.LockRecord = DB_PDB_LockRecord;
    source->ops.UnlockRecord = DB_PDB_UnlockRecord;
    source->ops.UpdateRecord = DB_PDB_UpdateRecord;
    source->ops.SetField = DB_SetField;
    source->ops.DeleteRecord = DS_DeleteRecord;
    source->ops.GetRecordID = DS_GetRecordID;
    source->ops.GetRecordIndex = DS_GetRecordIndex;
    source->ops.FilterRecord = DS_FilterRecord;
    source->ops.SetFilter = DS_SetFilter;
    source->ops.GetCurrentFilter = DS_GetCurrentFilter;
    source->ops.GetNumOfViews = DB_GetNumOfViews;
    source->ops.GetView = DB_GetView;
    source->ops.PutView = DS_PutView;
    source->ops.StoreView = DB_StoreView;
    source->ops.DeleteView = DB_DeleteView;
    source->ops.CheckUpdateSchema = DS_CheckUpdateSchema;
    source->ops.UpdateSchema = DB_UpdateSchema;
    source->ops.GetOption_Boolean = DB_GetOption_Boolean;
    source->ops.SetOption_Boolean = DB_SetOption_Boolean;
    source->ops.GetOption_UInt16 = DB_GetOption_UInt16;
    source->ops.SetOption_UInt16 = DB_SetOption_UInt16;
    source->ops.GetKey = DS_GetKey;
    source->ops.GetPDB = DS_PDB_GetPDB;
    source->ops.GetTitle = DS_PDB_GetTitle;
    source->ops.SetTitle = DS_PDB_SetTitle;
    source->ops.Sort = DB_Sort;
    source->ops.Capable = DB_Capable;
    source->ops.Info = DS_PDB_Info;
#ifdef CONFIG_SCRIPTS
    source->ops.RecalculateFields = DB_PackIRCalculations;
	source->ops.ExecuteScript = ScriptRun;
#else
    source->ops.RecalculateFields = NULL;
	source->ops.ExecuteScript = NULL;
#endif

    error = OpenDB(source, mode, &keyPDB, sizeof(DataSourceChooserKey));
    if (!error) {
        /* store the key of the database*/
        source->key.size = key_size;
        source->key.data = AllocateMemPtr(key_size);
        MemMove( source->key.data, key_data, key_size);
    }
    return error;
}

DataSourceDriver *
DBvfs_GetDriver(void)
{
    DataSourceDriver * driver;

    if (!DeviceSupportVFS())
        return NULL;

    driver = AllocateMemPtr(sizeof(DataSourceDriver));

    StrCopy(driver->name, "DBvfs");
    driver->sourceID = sourceID_DBvfs;
    driver->class_ops.Open = DB_VFS_Open;
    driver->class_ops.OpenPDB = NULL;
    driver->class_ops.CheckTitle = DS_VFS_CheckTitle;
    driver->class_ops.Create = DB_VFS_Create;
    driver->class_ops.SupportsFieldType = DB_SupportsFieldType;
    driver->class_ops.Delete = DS_VFS_Delete;
    driver->class_ops.Enumerate = DB_VFS_Enumerate;
    driver->class_ops.GlobalFind = NULL;
    driver->class_ops.IsPresent = DB_VFS_IsPresent;
    driver->class_ops.CompareKey = DS_VFS_CompareKey;
    driver->class_ops.CanHandlePDB = DB_CanHandlePDB;
    driver->class_ops.Exchange = NULL;
#ifdef CONFIG_SCRIPTS
#ifdef GLOBAL_ACCESS
	driver->class_ops.CompileScript = ScriptCompile;
	driver->class_ops.DecompileScript = ScriptDecompile;
#endif
#endif
    return driver;
}

static Err
DB_VFS_Create(const char* name, DataSourceSchema* schema,
          void ** key_data_ptr, UInt16 * key_size_ptr)
{
    Err err;
    void * srcKey;
    UInt16 srcKeySize;

    err = DB_Create(name, schema, &srcKey, &srcKeySize);
    MoveDatabaseToCard( srcKey, srcKeySize, key_data_ptr, key_size_ptr);
    DeallocateMemPtr(srcKey);

    return err;
}

#endif
