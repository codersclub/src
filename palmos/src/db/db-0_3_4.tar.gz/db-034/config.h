/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */

/* Color support. */
#define CONFIG_COLOR 1

/* HostControl support. */
/* #undef CONFIG_DEBUG */

/* Memory check support. */
/* #undef DETECT_LEAKS */

/* Icon support. */
#define CONFIG_ICONS 1

/* Plugin support. */
#define CONFIG_PLUGINS 1

/* Sort Editor support. */
#define CONFIG_SORT 1

/* LinkMaster support. */
#define CONFIG_LINKAWARE 1

/* Global Find support. */
#define CONFIG_GLOBALFIND 1

/* Advanced about box. */
#define CONFIG_ABOUT 1

/* DB 0.2.x support. */
/* #undef CONFIG_FMT_DB2 */

/* VFS support. */
/* #undef CONFIG_VFS */

/* MobileDB support. */
/* #undef CONFIG_FMT_MOBILEDB */

/* JFile3 support. */
/* #undef CONFIG_FMT_JFILE3 */

/* HandEra SilkScreen support. */
#define CONFIG_HANDERA 1

/* JogDial support. */
#define CONFIG_JOGDIAL 1

/* Sony JogDial support. */
#define CONFIG_SONY 1

/* JogDial support. */
#define CONFIG_JOGDIAL 1

/* Compatibility with PalmOS 3.1. */
#define CONFIG_PALMOS31 1

/* Scripting support. */
#define CONFIG_SCRIPTS 1

/* Maximum number of fields when creating a new database. */
#define CONFIG_MAX_NUM_FIELDS_FOR_NEW_DB 32

/* System ROM stage. */
#define SYSROMSTAGE sysROMStageRelease

