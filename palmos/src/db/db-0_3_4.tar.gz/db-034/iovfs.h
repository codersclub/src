/*
 * Database standard I/O VFS Definitions
 * Copyright (C) 2002 by Marc Chalain
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _IOVFS_H
#define _IOVFS_H

#if defined(__GNUC__)
#define SECT_DRV __attribute__ ((__section__("drvsect")))
#else
#define SECT_DRV
#endif

typedef struct vfs_chooser_key {
    UInt16 volRefNum;
    char name[255];
} VFSChooserKey;

extern Boolean DS_VFS_CheckTitle(const char* title)SECT_DRV;

extern void DS_VFS_Delete(void * key_data, UInt32 key_size) SECT_DRV;

extern void DS_VFS_Enumerate(DataSourceEnumerationFunc callback, void * arg,
                 UInt32 type, UInt32 creator, UInt16 sourceID) SECT_DRV;
extern Boolean DS_VFS_IsPresent(void * key_data, UInt32 key_size,
                 UInt32 ds_type, UInt32 ds_creator) SECT_DRV;
extern Boolean DS_VFS_CompareKey(void * key1_data, UInt16 key1_size,
                  void * key2_data, UInt16 key2_size) SECT_DRV;
extern void DS_VFS_Close(DataSource * source) SECT_DRV;

extern Err MoveDatabaseToCard(void * key_src_data, UInt16 key_src_size,
               void ** key_dst_data, UInt16 * key_dst_size) SECT_DRV;

extern Boolean DeviceSupportVFS() SECT_DRV;

#endif
