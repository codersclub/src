/*
 * DB: Record Edit Form
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif

#include "enum.h"
#include "enum-icons.h"
#include "util.h"
#include "io.h"
#include "linkaware.h"
#ifdef CONFIG_PLUGINS
#include "plug.h"
#endif
#include "note.h"
#include "double.h"
#include "prefs.h"

#ifdef CONFIG_SCRIPTS
#include "script.h"
#include "calcvalue.h"
#endif

#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))
#define noFieldIndex 32
#define MAX_STRING_LENGTH 256

#undef min
#undef max
static inline int min(int a, int b) { return (a < b) ? a : b; }
static inline int max(int a, int b) { return (a > b) ? a : b; }

typedef struct {
    Char *display;
} ScriptType;
typedef ScriptType * ScriptPtr;

typedef struct {
    MemHandle h;
} EditorType;
typedef EditorType * EditorPtr;

typedef struct ListInfo {
    char ** items;
    UInt8 numItems;
    UInt8 selected;
} ListItemsType;
typedef ListItemsType * ListItemsPtr;

typedef struct {
    Boolean checked;
} CheckBoxType;
typedef CheckBoxType * CheckBoxPtr;

typedef struct {
    EditorPtr editor;
    NotePtr note;
    CheckBoxPtr checkbox;
    DateTimeType datetime;
    LinkPtr link;
    ListItemsPtr list;
    ScriptPtr script;
} EditViewFieldData;

UInt16 CurrentRecord;
Boolean IsNewRecord;

static UInt16 TopVisibleField, CurrentField;
static EditViewFieldData * fields;
static Boolean IsDirty;
static UInt16 ActiveViewIndex;
static DataSourceView * ActiveView;

static Err EditViewLoadRecord(void * table, Int16 row, Int16 column,
                  Boolean editing, MemHandle * textH,
                  Int16 * textOffset, Int16 * textAllocSize,
                  FieldPtr fld) EDITSECT;
static Boolean EditViewSaveRecord(void * table,
                  Int16 row, Int16 column) EDITSECT;
static void EditViewUpdateScrollers(FormPtr frm, UInt16 bottomField,
                    Boolean lastItemClipped) EDITSECT;
static UInt16 EditViewGetFieldHeight(TablePtr table, UInt16 fieldNum,
                     UInt16 columnWidth, UInt16 maxHeight)
     EDITSECT;
static void EditViewInitTableRow(TablePtr table, UInt16 row, UInt16 fieldNum,
                 short rowHeight) EDITSECT;
static void EditViewLoadTable(TablePtr table) EDITSECT;
static void EditViewInitTable(TablePtr table) EDITSECT;
static void EditViewResizeDescription(EventPtr event) EDITSECT;
#if 0
static void EditViewHandleSelectField(UInt16 row, const UInt8 column) EDITSECT;
#endif
static void EditViewScroll(WinDirectionType direction, Int8 numLines) EDITSECT;
static Boolean ValidateData(void) EDITSECT;
static Boolean SaveRecord(void) EDITSECT;
static void SetupRecordData(void) EDITSECT;
static void FreeRecordData(void) EDITSECT;
static void EditViewSetFieldEnabled( Boolean enabled) EDITSECT;
static Boolean EditViewUpdateForm(UInt16 updateMode)EDITSECT;
static void LockData( char *ptrs[] ) EDITSECT;
static void UnlockData( char *ptrs[] ) EDITSECT;

/*Getter functions*/
static char * EditView_GetString(void * data, UInt16 fieldNum) EDITSECT;
static Int32 EditView_GetInteger(void * data, UInt16 fieldNum) EDITSECT;
static Boolean EditView_GetBoolean(void * data, UInt16 fieldNum) EDITSECT;
static void EditView_GetDate(void * data, UInt16 fieldNum,
         UInt16* year, UInt8* month, UInt8* day) EDITSECT;
static void EditView_GetTime(void * data, UInt16 fieldNum, UInt8* hour, UInt8* minute) EDITSECT;
static char * EditView_GetNoteTitle(void * data, UInt16 fieldNum) EDITSECT;
static char * EditView_GetNote(void * data, UInt16 fieldNum) EDITSECT;
static UInt8 EditView_GetListItem(void * data, UInt16 fieldNum) EDITSECT;
static char * EditView_GetLink(void * data, UInt16 fieldNum, UInt32 *uniqID) EDITSECT;
static char * EditView_GetLinked(void * data, UInt16 fieldNum) EDITSECT;
static double EditView_GetFloat( void * data, UInt16 fieldNum ) EDITSECT;
#ifdef CONFIG_SCRIPTS
static void EditView_GetCalculated( void * data, UInt16 fieldNum, CalculatedValue *cv ) EDITSECT;
#endif

static void
EditViewCustomDraw(void * table, Int16 row, Int16 col, RectangleType *b)
{
    UInt16 fieldNum = ActiveView->cols[TblGetRowID(table, row)].fieldNum;
    UInt16 fieldType = CurrentSource->schema.fields[fieldNum].type;
    char str[max(longDateStrLength, timeStringLength) + 1];

    //i don't know why but i lost the font selection?
#ifdef CONFIG_SONY
    if (FeatureSetSony && DBPrefs.TheStdFont > 7)
        HRFntSetFont( SonyLibRefNum, DBPrefs.TheStdFont);
    else if (FeatureSetSony)
        HRFntSetFont( SonyLibRefNum, DBPrefs.TheStdFont + 8);
#endif

    if (col == 1) {
        switch (fieldType) {
        case FIELD_TYPE_DATE:
            if (fields[fieldNum].datetime.month != 0)
                DateToAscii(fields[fieldNum].datetime.month,
                        fields[fieldNum].datetime.day,
                        fields[fieldNum].datetime.year,
                        PrefGetPreference(prefLongDateFormat),
                        str);
            else
                StrCopy(str,"N/A");
            WinEraseRectangle(b, 0);
#ifdef CONFIG_SONY
            if (FeatureSetSony){
                UtilWinDrawTruncChars(str, StrLen(str),
                                b->topLeft.x * 2, b->topLeft.y * 2, b->extent.x * 2, true);
            } else
#endif
            UtilWinDrawTruncChars(str, StrLen(str),
                            b->topLeft.x, b->topLeft.y, b->extent.x, true);
        break;

        case FIELD_TYPE_TIME:
            if (fields[fieldNum].datetime.hour < 24)
                TimeToAscii(fields[fieldNum].datetime.hour,
                        fields[fieldNum].datetime.minute,
                        PrefGetPreference(prefTimeFormat),
                        str);
            else
                StrCopy(str,"N/A");
            WinEraseRectangle(b, 0);
#ifdef CONFIG_SONY
            if (FeatureSetSony){
                UtilWinDrawTruncChars(str, StrLen(str),
                                b->topLeft.x * 2, b->topLeft.y * 2, b->extent.x * 2, true);
            } else
#endif
            UtilWinDrawTruncChars(str, StrLen(str),
                            b->topLeft.x, b->topLeft.y, b->extent.x, true);
        break;

        case FIELD_TYPE_LIST:
        {
            FormPtr form = FrmGetActiveForm();
            ControlPtr ctl = GetObjectPtr(form, ctlID_EditView_ListTrigger);
            CtlSetEnabled(ctl, 1);
            CtlSetUsable(ctl, 1);
            FrmSetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_ListTrigger), b);

            if (fields[fieldNum].list->numItems > fields[fieldNum].list->selected)
                CtlSetLabel( ctl, fields[fieldNum].list->items[fields[fieldNum].list->selected]);
            else
                CtlSetLabel( ctl, "N/A");
            CtlDrawControl(ctl);

            CtlSetEnabled(ctl, 0);
            CtlSetUsable(ctl, 0);
        }
        break;

        case FIELD_TYPE_LINK:
        case FIELD_TYPE_LINKED:
            WinEraseRectangle(b, 0);
#ifdef CONFIG_SONY
            if (FeatureSetSony){
                UtilWinDrawTruncChars(fields[fieldNum].link->name, StrLen(fields[fieldNum].link->name),
                                b->topLeft.x * 2, b->topLeft.y * 2, b->extent.x * 2, true);
            } else
#endif
            UtilWinDrawTruncChars(fields[fieldNum].link->name, StrLen(fields[fieldNum].link->name),
                            b->topLeft.x, b->topLeft.y, b->extent.x, true);
        break;
        }
    }
}

static Err
EditViewLoadRecord(void * table, Int16 row, Int16 column,
           Boolean editing, MemHandle * textH, Int16 * textOffset,
           Int16 * textAllocSize, FieldPtr fld)
{
    UInt16 fieldNum = ActiveView->cols[TblGetRowID(table, row)].fieldNum;
    FieldAttrType attr;

    ErrFatalDisplayIf(fieldNum >= CurrentSource->schema.numFields,
              "out of range field #");

    if ( fld) {
        switch (CurrentSource->schema.fields[fieldNum].type) {
        case FIELD_TYPE_INTEGER:
    	case FIELD_TYPE_FLOAT:
            FldSetMaxChars(fld, 10);
            FldGetAttributes(fld, &attr);
            attr.singleLine = true;
            attr.dynamicSize = false;
            FldSetAttributes(fld, &attr);
        break;
	    case FIELD_TYPE_NOTE:
          {
            Char * title = fields[fieldNum].note->title;
 
            FldSetMaxChars(fld, 11);
            FldGetAttributes(fld, &attr);
            attr.singleLine = true;
            attr.dynamicSize = false;
            FldSetAttributes(fld, &attr);

            if (title[0]) {
                Char * fieldP;
    
                fieldP = MemHandleLock(fields[fieldNum].editor->h);
                StrNCopy(fieldP, title, 11);
                MemHandleUnlock(fields[fieldNum].editor->h);
            }
         }
        break;
        case FIELD_TYPE_STRING:
            FldSetMaxChars(fld, MAX_STRING_LENGTH);
            FldGetAttributes(fld, &attr);
            attr.singleLine = false;
            attr.dynamicSize = true;
            FldSetAttributes(fld, &attr);
        break;
        default:
        }
    }

    *textH = fields[fieldNum].editor->h;
    *textOffset = 0;
    *textAllocSize = MemHandleSize(fields[fieldNum].editor->h);

    return (0);
}

static Boolean
EditViewSaveRecord(void * table, Int16 row, Int16 column)
{
    FieldPtr fld;

    fld = TblGetCurrentField(table);
    if (fld && FldDirty(fld)) {
        IsDirty = true;
    }

    return false;
}

static void
EditViewUpdateScrollers(FormPtr frm, UInt16 bottomField, Boolean lastItemClipped)
{
    UInt16 upIndex;
    UInt16 downIndex;
    Boolean scrollableUp;
    Boolean scrollableDown;

    /* If the first field displayed is not the fist field in the
     * record, enable the up scroller.
     */
    scrollableUp = TopVisibleField > 0;

    /* If the last field displayed is not the last field in the
     * record, enable the down scroller.
     */
    scrollableDown = (lastItemClipped ||
              (bottomField < ActiveView->numCols - 1));

    /* Update the scroll button. */
    upIndex = FrmGetObjectIndex(frm, ctlID_EditView_UpButton);
    downIndex = FrmGetObjectIndex(frm, ctlID_EditView_DownButton);
    FrmUpdateScrollers (frm, upIndex, downIndex, scrollableUp, scrollableDown);
}

static UInt16
EditViewGetFieldHeight(TablePtr table, UInt16 fieldID, UInt16 columnWidth,
               UInt16 maxHeight)
{
    UInt16 height, lineHeight;
    Char * str;
    UInt16 fieldNum = ActiveView->cols[fieldID].fieldNum;;

    switch (CurrentSource->schema.fields[fieldNum].type) {
    case FIELD_TYPE_STRING:
        str = MemHandleLock(fields[fieldNum].editor->h);
#ifdef CONFIG_SONY
        if (FeatureSetSony && DBPrefs.TheStdFont > 7)
            height = FldCalcFieldHeight(str, columnWidth * 2);
        else
#endif
        height = FldCalcFieldHeight(str, columnWidth);
        lineHeight = FntLineHeight ();
        height = min (height, (maxHeight / lineHeight));
        height *= lineHeight;
        MemHandleUnlock(fields[fieldNum].editor->h);
    break;

    case FIELD_TYPE_BOOLEAN:
    case FIELD_TYPE_INTEGER:
    case FIELD_TYPE_DATE:
    case FIELD_TYPE_TIME:
    case FIELD_TYPE_NOTE:
    case FIELD_TYPE_LIST:
    case FIELD_TYPE_LINK:
    case FIELD_TYPE_LINKED:
	case FIELD_TYPE_FLOAT:
#ifdef CONFIG_SCRIPTS
	case FIELD_TYPE_CALCULATED:
#endif
        height = FntLineHeight();
    break;

    default:
        height = FntLineHeight();
    break;
    }

#ifdef CONFIG_SONY
    if (FeatureSetSony && DBPrefs.TheStdFont > 7)
        height /= 2;
#endif
    return height;
}

static void
EditViewInitTableRow(TablePtr table, UInt16 row, UInt16 fieldID,
             short rowHeight)
{
    UInt16 fieldNum = ActiveView->cols[fieldID].fieldNum;

    /* Make the row usable and selectable. */
    TblSetRowUsable(table, row, true);
    TblSetRowSelectable(table, row, true);

    /* Set the height of the row to the height of the desc. */
    TblSetRowHeight(table, row, rowHeight);

    /* Store the record number as the row id. */
    TblSetRowID(table, row, (UInt16) fieldID);
    ErrFatalDisplayIf(fieldNum >= CurrentSource->schema.numFields,
              "out-of-range field #");

    /* Mark the row invalid so that it will draw when we call the
     * draw routine.
     */
    TblMarkRowInvalid(table, row);

    /* Setup the field label column. */
    TblSetItemStyle(table, row, 0, labelTableItem);
    TblSetItemPtr(table, row, 0, CurrentSource->schema.fields[fieldNum].name);

    /* Setup the field data column. */
    switch (CurrentSource->schema.fields[fieldNum].type) {
    case FIELD_TYPE_STRING:
    case FIELD_TYPE_INTEGER:
	case FIELD_TYPE_FLOAT:
        TblSetItemStyle(table, row, 1, textTableItem);
    break;

#ifdef CONFIG_SCRIPTS
	case FIELD_TYPE_CALCULATED:
	    TblSetItemStyle(table, row, 1, labelTableItem);
	    TblSetItemPtr(table, row, 1, fields[fieldNum].script->display);
	break;
#endif

    case FIELD_TYPE_NOTE:
        TblSetItemStyle(table, row, 1, textWithNoteTableItem);
    break;

    case FIELD_TYPE_BOOLEAN:
        TblSetItemStyle(table, row, 1, checkboxTableItem);
        if (fields[fieldNum].checkbox->checked)
            TblSetItemInt(table, row, 1, 1);
    else
        TblSetItemInt(table, row, 1, 0);
    break;

    case FIELD_TYPE_DATE:
    case FIELD_TYPE_TIME:
    case FIELD_TYPE_LINK:
    case FIELD_TYPE_LINKED:
    case FIELD_TYPE_LIST:
        TblSetItemStyle(table, row, 1, customTableItem);
    break;

    default:
        ErrDisplay("field type not supported");
    break;
    }
}

static void
EditViewSetColumnWidth(TablePtr table)
{
    UInt16 labelWidth, width, i;
    Coord x = 160;
#ifdef CONFIG_HANDERA
    Coord y = 0;
#endif

    /* Figure out the width of the label column. */
    labelWidth = FntCharsWidth(CurrentSource->schema.fields[0].name,
                   StrLen(CurrentSource->schema.fields[0].name))
    + FntCharWidth(':');
#ifdef CONFIG_SONY
    if (FeatureSetSony && DBPrefs.TheStdFont > 7)
        labelWidth /= 2;
#endif
    for (i = 1; i < CurrentSource->schema.numFields; i++) {
        width = FntCharsWidth(CurrentSource->schema.fields[i].name,
                              StrLen(CurrentSource->schema.fields[i].name))
                + FntCharWidth(':');
#ifdef CONFIG_SONY
        if (FeatureSetSony && DBPrefs.TheStdFont > 7)
            width /= 2;
#endif
        if (width > labelWidth)
            labelWidth = width;
    }
    if (labelWidth > 80)
        labelWidth = 80;
    TblSetColumnWidth(table, 0, labelWidth);
#ifdef CONFIG_HANDERA
    if (FeatureSetHandera)
        WinGetDisplayExtent(&x, &y);
#endif
    TblSetColumnWidth(table, 1, x - labelWidth - 1);
}

static void
EditViewLoadTable(TablePtr table)
{
    UInt16 row;
    UInt16 numRows;
    UInt16 fieldIndex, lastFieldIndex;
    UInt16 lineHeight,dataHeight,tableHeight;
    UInt16 columnWidth;
    UInt16 pos, oldPos;
    UInt16 height, oldHeight;
    Boolean rowUsable;
    Boolean rowsInserted = false;
    Boolean lastItemClipped;
    RectangleType r;

    TblGetBounds (table, &r);
    tableHeight = r.extent.y;
    columnWidth = TblGetColumnWidth(table, 1);

    /* If we currently have a selected record, make sure that it is not
     * above the first visible record.
     */
    if (CurrentField != noFieldIndex) {
        if (CurrentField < TopVisibleField)
            TopVisibleField = CurrentField;
    }

    row = 0;
    dataHeight = 0;
    oldPos = pos = 0;
    fieldIndex = TopVisibleField;
    lastFieldIndex = fieldIndex;

    /* Load records into the table. */
    while (fieldIndex < ActiveView->numCols) {
        /* Compute the height of the field's text string. */
        height = EditViewGetFieldHeight(table, fieldIndex, columnWidth,
                        tableHeight);

        /* Is there enough room for at least one line of the the field. */
        lineHeight = FntLineHeight();
#ifdef CONFIG_SONY
        if (FeatureSetSony && DBPrefs.TheStdFont > 7)
            lineHeight /= 2;
#endif
        if (tableHeight >= dataHeight + lineHeight) {
            rowUsable = TblRowUsable(table, row);

            /* Get the height of the current row. */
            if (rowUsable)
                oldHeight = TblGetRowHeight(table, row);
            else
                oldHeight = 0;

            /* If the field is not already being displayed in the current
             * row, load the field into the table.
             */
            if ((! rowUsable) ||
              (TblGetRowID (table, row) != fieldIndex)) {
                EditViewInitTableRow(table, row, fieldIndex, height);
            }

            /* If the height or the position of the item has changed
             * draw the item.
             */
            else if (height != oldHeight) {
                TblSetRowHeight(table, row, height);
                TblMarkRowInvalid (table, row);
            } else if (pos != oldPos) {
                TblMarkRowInvalid (table, row);
            }

            pos += height;
            oldPos += oldHeight;
            lastFieldIndex = fieldIndex;
            fieldIndex++;
            row++;
        }

        dataHeight += height;

        /* Is the table full? */
        if (dataHeight >= tableHeight) {
            /* If we have a currently selected field, make sure that it is
             * not below the last visible field.  If the currently selected
             * field is the last visible record, make sure the whole field
             * is visible.
             */
            if (CurrentField == noFieldIndex)
                break;
            /* Above last visible? */
            else if (CurrentField < fieldIndex)
                break;
            /* Last visible? */
            else if (fieldIndex == lastFieldIndex) {
                if ((fieldIndex == TopVisibleField) || (dataHeight == tableHeight))
                    break;
            }

            /* Remove the top item from the table and reload the table
             * again.
             */
            TopVisibleField++;
            fieldIndex = TopVisibleField;


            // Below last visible.
            //          else
            //              TopVisibleField = CurrentField;

            row = 0;
            dataHeight = 0;
            oldPos = pos = 0;
        }
    }

    /* Hide the item that don't have any data. */
    numRows = TblGetNumberOfRows (table);
    while (row < numRows) {
        TblSetRowUsable (table, row, false);
        row++;
    }

    /* If the table is not full and the first visible field is not the
     * first field in the record, displays enough fields to fill out
     * the table by adding fields to the top of the table.
     */
    while (dataHeight < tableHeight) {
        fieldIndex = TopVisibleField;
        if (fieldIndex == 0) break;
        fieldIndex--;

        /* Compute the height of the field. */
        height = EditViewGetFieldHeight(table, fieldIndex,
                        columnWidth, tableHeight);

        /* If adding the item to the table will overflow the height of
         * the table, don't add the item.
         */
        if (dataHeight + height > tableHeight)
            break;

        /* Insert a row before the first row. */
        TblInsertRow(table, 0);

        EditViewInitTableRow(table, 0, fieldIndex, height);

        TopVisibleField = fieldIndex;

        rowsInserted = true;

        dataHeight += height;
    }

    /* If rows were inserted to full out the page, invalidate the
     * whole table, it all needs to be redrawn.
     */
    if (rowsInserted){
        TblMarkTableInvalid(table);
    }

    /* If the height of the data in the table is greater than the
     * height of the table, then the bottom of the last row is clip
     * and the table is scrollable.
     */
    lastItemClipped = (dataHeight > tableHeight);

    /* Update the scroll arrows. */
    EditViewUpdateScrollers(FrmGetActiveForm(),
                lastFieldIndex, lastItemClipped);

    TblSetColumnEditIndicator (table, 1, false);
}

static void
EditViewInitTable(TablePtr table)
{
    UInt16 numRows, i;

    /* Initialize the table rows to a none default. */
    numRows = TblGetNumberOfRows(table);
    for (i = 0; i < numRows; i++) {
        TblSetItemStyle(table, i, 0, labelTableItem);
        TblSetRowUsable (table, i, false);
    }

    /* Enable the label and data columns. */
    TblSetColumnUsable(table, 0, true);
    TblSetColumnUsable(table, 1, true);

    EditViewSetColumnWidth(table);

    TblSetLoadDataProcedure(table, 1, EditViewLoadRecord);
    TblSetSaveDataProcedure(table, 1, EditViewSaveRecord);
    TblSetCustomDrawProcedure(table, 1, EditViewCustomDraw);

    EditViewLoadTable(table);
}

static void
EditViewResizeDescription(EventPtr event)
{
    UInt16 pos = 0;
    UInt16 row;
    UInt16 column;
    UInt16 lastRow;
    UInt16 fieldIndex = 0;
    UInt16 lastFieldIndex;
    UInt16 topFieldIndex;
    FieldPtr fld;
    TablePtr table;
    Boolean restoreFocus = false;
    Boolean lastItemClipped;
    RectangleType itemR;
    RectangleType tableR;
    RectangleType fieldR;


    // Get the current height of the field;
    fld = event->data.fldHeightChanged.pField;
    FldGetBounds (fld, &fieldR);

    // Have the table object resize the field and move the items below
    // the field up or down.
    table = GetObjectPtr(FrmGetActiveForm(), ctlID_EditView_Table);
    TblHandleEvent (table, event);

#ifdef CONFIG_SONY
        if (FeatureSetSony && DBPrefs.TheStdFont > 7)
            event->data.fldHeightChanged.newHeight /= 2;
#endif
    // If the field's height has expanded , we're done.
    if (event->data.fldHeightChanged.newHeight >= fieldR.extent.y) {
        topFieldIndex = TblGetRowID (table, 0);
        if (topFieldIndex != TopVisibleField)
            TopVisibleField = topFieldIndex;
        else {
            // Since the table has expanded we may be able to scroll
            // when before we might not have.
            lastRow = TblGetLastUsableRow (table);
            TblGetBounds (table, &tableR);
            TblGetItemBounds (table, lastRow, 1, &itemR);
            lastItemClipped = (itemR.topLeft.y + itemR.extent.y >
                       tableR.topLeft.y + tableR.extent.y);
            lastFieldIndex = TblGetRowID (table, lastRow);

            EditViewUpdateScrollers (FrmGetActiveForm (), lastFieldIndex,
                         lastItemClipped);

            return;
        }
    }

    // If the field's height has contracted and the field edit field
    // is not visible then the table may be scrolled.  Release the
    // focus,  which will force the saving of the field we are editing.
    else if (TblGetRowID (table, 0) != 0) {
        TblGetSelection (table, &row, &column);
        fieldIndex = TblGetRowID (table, row);

        fld = TblGetCurrentField (table);
        pos = FldGetInsPtPosition (fld);
        TblReleaseFocus (table);

        restoreFocus = true;
    }

    // Add items to the table to fill in the space made available by the
    // shorting the field.
    EditViewLoadTable(table);
    TblRedrawTable (table);

    // Restore the insertion point position.
    if (restoreFocus) {
        TblFindRowID (table, fieldIndex, &row);
        TblGrabFocus (table, row, column);
        FldSetInsPtPosition (fld, pos);
        FldGrabFocus (fld);
    }
}

#if 0
static void
EditViewHandleSelectField(UInt16 row, const UInt8 column)
{
    TablePtr table;
    FieldPtr fld;
    UInt16 fieldNum;
    Char buf[16];

    StrIToA(buf, column);
    FrmCustomAlert(alertID_Debug, "row = ", buf, " ");

    table = GetObjectPtr(FrmGetActiveForm(), ctlID_EditView_Table);
    fieldNum = ActiveView->cols[TblGetRowID(table, row)].fieldNum;

    if (fieldNum != CurrentField) {
    if (TblGetCurrentField(table)) {
        TblReleaseFocus(table);
        FrmCustomAlert(alertID_Debug, "focus released", " ", " ");
    }
    TblUnhighlightSelection(table);
    TblGrabFocus(table, row, 1);
    fld = TblGetCurrentField(table);
    if (fld) {
        FldGrabFocus(fld);
        FldMakeFullyVisible(fld);
    }
    FrmCustomAlert(alertID_Debug, "focus grabbed", " ", " ");
    CurrentField = fieldNum;
    }
}
#endif

static void
EditViewScroll(WinDirectionType direction, Int8 numLines)
{
    Int16 row, height, fieldIndex, columnWidth, tableHeight;
    TablePtr       table;
    RectangleType   r;

    table = GetObjectPtr(FrmGetActiveForm(), ctlID_EditView_Table);

    TblReleaseFocus(table);


    /* Get the height of the table and the width of the description
     * column.
     */
    TblGetBounds (table, &r);
    tableHeight = r.extent.y;
    height = 0;
    columnWidth = TblGetColumnWidth (table, 1);

    /* Scroll the table down. */
    if (direction == winDown) {
        if (numLines == -1) {//scroll one page
            // Get the index of the last visible field, this will become
            // the index of the top visible field, unless it occupies the
            // whole screeen, in which case the next field will be the
            // top field.

            row = TblGetLastUsableRow (table);
            fieldIndex = TblGetRowID (table, row);

            // If the last visible field is also the first visible field
            // then it occupies the whole screeen.
            if (row == 0)
                fieldIndex = min(ActiveView->numCols-1, fieldIndex+1);
        } else { //scroll number of lines
            row = TblGetNumberOfRows (table);
            if (row < numLines) {
                fieldIndex = TblGetRowID (table, row) + numLines;
            } else {
                fieldIndex = TblGetRowID (table, numLines);
            }

        }
    }
    // Scroll the table up.
    else {
        if (numLines == -1) {//scroll one page
            // Scan the fields before the first visible field to determine
            // how many fields we need to scroll.  Since the heights of the
            // fields vary,  we sum the height of the records until we get
            // a screen full.

            fieldIndex = TblGetRowID (table, 0);
            ErrFatalDisplayIf(fieldIndex >= CurrentSource->schema.numFields,
                      "Invalid field Index");
            if (fieldIndex == 0)
                return;

            height = TblGetRowHeight (table, 0);
            if (height >= tableHeight)
                height = 0;

            while (height < tableHeight && fieldIndex > 0) {
                char * str;

                switch (CurrentSource->schema.fields[ActiveView->cols[fieldIndex].fieldNum].type) {
                case FIELD_TYPE_STRING:
                    str = MemHandleLock(fields[fieldIndex].editor->h);
                    height += FldCalcFieldHeight(str, columnWidth)
                        * FntLineHeight();
                    MemPtrUnlock(str);
                break;
                case FIELD_TYPE_BOOLEAN:
                case FIELD_TYPE_INTEGER:
                case FIELD_TYPE_NOTE:
                case FIELD_TYPE_LIST:
                case FIELD_TYPE_LINK:
                case FIELD_TYPE_LINKED:
                case FIELD_TYPE_FLOAT:
#ifdef CONFIG_SCRIPTS
                case FIELD_TYPE_CALCULATED:
#endif
                default:
                    height += FntLineHeight();
                break;
                }
                if ((height <= tableHeight)
                  || (fieldIndex == TblGetRowID (table, 0)))
                    fieldIndex--;
            }
        } else {
            fieldIndex = TblGetRowID (table, 0) - numLines;
            if (fieldIndex < 0)
                return;
        }
    }

    TblMarkTableInvalid (table);
    CurrentField = noFieldIndex;
    TopVisibleField = fieldIndex;

    TblUnhighlightSelection (table);
    EditViewLoadTable(table);
    //TblRedrawTable not use to erase the table
    //with PalmOS 3.1 and prior TblRedrawTable doen't Draw table!
    TblRedrawTable (table);
}

/* Returns true if the data in the record is valid. */
static Boolean
ValidateData(void)
{
    Char * s;
    UInt16 i;

    for (i = 0; i < CurrentSource->schema.numFields; i++) {
        switch (CurrentSource->schema.fields[i].type) {
        case FIELD_TYPE_INTEGER:
            s = MemHandleLock(fields[i].editor->h);
            if (! IsNumber(s) && s[0] != 0) {
                MemPtrUnlock(s);
                return false;
            }
            MemPtrUnlock(s);
            break;

        case FIELD_TYPE_FLOAT:
        break;

        default:
            /* No checks for other data types. */
            break;
        }
    }

    return true;
}

static DataSourceGetter EditViewGetter = {
    GetString: EditView_GetString,
    GetInteger: EditView_GetInteger,
    GetBoolean: EditView_GetBoolean,
    GetDate: EditView_GetDate,
    GetTime: EditView_GetTime,
    GetNote: EditView_GetNote,
    GetNoteTitle: EditView_GetNoteTitle,
    GetListItem: EditView_GetListItem,
    GetLink: EditView_GetLink,
    GetLinked: EditView_GetLinked,
    GetFloat: EditView_GetFloat,
#ifdef CONFIG_SCRIPTS
	GetCalculated: EditView_GetCalculated
#endif
};

static char *
EditView_GetString(void * data, UInt16 fieldNum)
{
    char ** ptrs = (char **)data;
    return ptrs[fieldNum];
}

static Int32
EditView_GetInteger(void * data, UInt16 fieldNum)
{
    char ** ptrs = (char **)data;
    Int32 value;

    if (ptrs[fieldNum] != 0) {
        value = String2Long(ptrs[fieldNum]);
    }
    else
	  value = 0;
    if (IsNewRecord && CurrentSource->schema.fields[fieldNum].data.integer.increment) {
        CurrentSource->schema.fields[fieldNum].data.integer.defaultValue +=
                   (Int32)CurrentSource->schema.fields[fieldNum].data.integer.increment;
        CurrentSource->schema.fields[fieldNum].data.changed = true;
    }
    return value;
}

static Boolean
EditView_GetBoolean(void * data, UInt16 fieldNum)
{
    return fields[fieldNum].checkbox->checked;
}

static void
EditView_GetDate(void * data, UInt16 fieldNum,
         UInt16* year, UInt8* month, UInt8* day)
{
    *month = (fields[fieldNum].datetime.month & 0xFF);
    *day = (fields[fieldNum].datetime.day & 0xFF);
    *year = (fields[fieldNum].datetime.year & 0xFFFF);
}

static void
EditView_GetTime(void * data, UInt16 fieldNum, UInt8* hour, UInt8* minute)
{
    *hour = (fields[fieldNum].datetime.hour & 0xFF);
    *minute = (fields[fieldNum].datetime.minute & 0xFF);
}

static char *
EditView_GetNoteTitle(void * data, UInt16 fieldNum)
{
    char ** ptrs = (char **)data;
    return ptrs[fieldNum];
}

static char *
EditView_GetNote(void * data, UInt16 fieldNum)
{
    if (fields[fieldNum].note->h)
        return fields[fieldNum].note->s;
    else
        return NULL;
}

static UInt8
EditView_GetListItem(void * data, UInt16 fieldNum)
{
    return (UInt8) fields[fieldNum].list->selected;
}

static char *
EditView_GetLink(void * data, UInt16 fieldNum, UInt32 *uniqID)
{
    char ** ptrs = (char **)data;
    if (uniqID)
        *uniqID = fields[fieldNum].link->uniqID;
    return ptrs[fieldNum];
}

static char *
EditView_GetLinked(void * data, UInt16 fieldNum)
{
    char ** ptrs = (char **)data;
    return ptrs[fieldNum];
}

static double
EditView_GetFloat( void * data, UInt16 fieldNum )
{
    char ** ptrs = (char **)data;
    double d;

    if ( StrLen( ptrs[fieldNum] ) > 14 ) {
        DbgPrintF("Float too long to parse");
        return 0.0;
    }

    DoubleAToD( &d, ptrs[fieldNum] );

    return d;

}

#ifdef CONFIG_SCRIPTS
static void
EditView_GetCalculated( void * data, UInt16 fieldNum, CalculatedValue *cv )
{
  UInt8 *bc = NULL;
  char **ptrs = data;
  ScriptExeContext sec;

  if (ScriptRequiresAtMost(&(CurrentSource->schema.fields[fieldNum].data.calc),
						   SINGLE_RECORD_READING | FIELD_READING )
        && CurrentSource->schema.fields[fieldNum].data.calc.bytecode ) {

	bc = MemHandleLock( CurrentSource->schema.fields[fieldNum].data.calc.bytecode );
	sec.context = RECORD_FIELD_WRITING_CONTEXT;
	sec.info.record = CurrentRecord;

    CurrentSource->ops.ExecuteScript( CurrentSource, &sec, bc, ptrs,
							  &EditViewGetter, cv );

	MemPtrUnlock( bc );

  }
  else {
	DbgPrintF( "Cannot run script in this context... ",
			   CurrentSource->schema.fields[fieldNum].data.calc.access);
	cv->info = CV_FIELD_TYPE_NA;
  }
}
#endif

static void
LockData( char *ptrs[] )
{
  UInt16 i;

    /* Lock all of the handles for strings. */
    for (i = 0; i < CurrentSource->schema.numFields; i++) {
        switch (CurrentSource->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
        case FIELD_TYPE_INTEGER:
        case FIELD_TYPE_FLOAT:
            ptrs[i] = MemHandleLock(fields[i].editor->h);
            break;

        case FIELD_TYPE_LINKED:
        case FIELD_TYPE_LINK:
            ptrs[i] = fields[i].link->name;
            break;

        case FIELD_TYPE_NOTE:
            ptrs[i] = MemHandleLock(fields[i].editor->h);
            if (fields[i].note->h)
                fields[i].note->s = MemHandleLock(fields[i].note->h);
            break;

        default:
            ptrs[i] = 0;
        }
    }

}

static void
UnlockData( char *ptrs[] )
{

  UInt16 i;
    for (i = 0; i < CurrentSource->schema.numFields; i++) {
        switch (CurrentSource->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
        case FIELD_TYPE_INTEGER:
        case FIELD_TYPE_FLOAT:
            MemHandleUnlock(fields[i].editor->h);
            break;

        case FIELD_TYPE_NOTE:
            MemHandleUnlock(fields[i].editor->h);
            if (fields[i].note->h)
                MemHandleUnlock(fields[i].note->h);
            break;

        default:
            break;
        }
    }
}

static Boolean
SaveRecord(void)
{
    char* ptrs[CurrentSource->schema.numFields];
    UInt16 recNum;//, i;
    Err err;

    /* Only save the record if the record is dirty. */
    if ((CurrentSource->openMode == dmModeReadOnly) || !IsDirty) return true;

    if ( !ValidateData()) {
        FrmAlert( alertID_ValidationFailure);
        return false;
    }

    LockData( ptrs );

    /* Tell the data source layer to add/modify this record. */
    recNum = IsNewRecord ? dmMaxRecordIndex : CurrentRecord;
/*    if (IsNewRecord) {
        for (i = 0; i < CurrentSource->schema.numFields; i++) {
            switch (CurrentSource->schema.fields[i].type) {
            case FIELD_TYPE_INTEGER:
                if (CurrentSource->schema.fields[i].data.integer.increment) {
                    CurrentSource->schema.fields[i].data.integer.defaultValue +=
                        (Int32)CurrentSource->schema.fields[i].data.integer.increment;
                    CurrentSource->schema.fields[i].data.changed = true;
                }
            break;
            default:
            }
        }
    }
*/
    err = CurrentSource->ops.UpdateRecord(CurrentSource, &recNum, false,
                      &EditViewGetter, &ptrs);
    if (err != 0) {
        FrmAlert(DeviceFullAlert);
    }

    /* Unlock all of the handles locked in the previous step. */
    UnlockData( ptrs );

    return (err? 0 : 1);
}

static void
SetupRecordData(void)
{
    DataSourceGetter getter;
    void * rec_data;
    Int32 value;
    Char *s, *p;
    UInt16 i, j = 0;

    /* Allocate the global space for this record. */
    fields = AllocateMemPtr(CurrentSource->schema.numFields
               * sizeof(EditViewFieldData));
    ErrFatalDisplayIf(!fields, "out of Memory");

    /* For new records, just blank out the entire setup. */
    if (IsNewRecord) {
        for (i = 0; i < CurrentSource->schema.numFields; i++) {
            switch (CurrentSource->schema.fields[i].type) {
            case FIELD_TYPE_NOTE:
                fields[i].editor = AllocateMemPtr(sizeof(EditorType));
                fields[i].editor->h = AllocateMemHandle(12);
                ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                s = MemHandleLock(fields[i].editor->h);
                s[0] = '\0';
                MemPtrUnlock(s);
                fields[i].note = AllocateMemPtr(sizeof(NoteType));
                fields[i].note->h = NULL;
                fields[i].note->s = NULL;
                fields[i].note->title[0] = 0;
            break;
            case FIELD_TYPE_STRING:
                fields[i].editor = AllocateMemPtr(sizeof(EditorType));
                if (CurrentSource->schema.fields[i].data.string.defaultValue) {
                    fields[i].editor->h = AllocateMemHandle(
                            StrLen(CurrentSource->schema.fields[i].data.string.defaultValue) + 1);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    StrCopy(s, CurrentSource->schema.fields[i].data.string.defaultValue);
                } else {
                    fields[i].editor->h = AllocateMemHandle(1);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    s[0] = '\0';
                }
                MemPtrUnlock(s);
            break;

            case FIELD_TYPE_LINK:
            case FIELD_TYPE_LINKED:
                fields[i].link = AllocateMemPtr(sizeof(LinkType));
                fields[i].link->name[0] = '\0';
                fields[i].link->uniqID = 0;
            break;

            case FIELD_TYPE_INTEGER:
                value = CurrentSource->schema.fields[i].data.integer.defaultValue;
                fields[i].editor = AllocateMemPtr(sizeof(EditorType));
                if (value != 0) {
                    fields[i].editor->h = AllocateMemHandle(32);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    MemSet(s, 32, 0);
                    StrIToA(s, value);
                } else {
                    fields[i].editor->h = AllocateMemHandle(1);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    s[0] = '\0';
                }
                MemPtrUnlock(s);
            break;

            case FIELD_TYPE_BOOLEAN:
                fields[i].checkbox = AllocateMemPtr(sizeof(CheckBoxType));
                fields[i].checkbox->checked = false;
            break;

            case FIELD_TYPE_DATE:
            case FIELD_TYPE_TIME:
                fields[i].datetime.hour = 24;
                fields[i].datetime.month = 0;
//                TimSecondsToDateTime(TimGetSeconds(), &fields[i].datetime);
            break;

            case FIELD_TYPE_LIST:
                fields[i].list = AllocateMemPtr(sizeof(ListItemsType));
                fields[i].list->numItems = CurrentSource->schema.fields[i].data.list.numItems;
                fields[i].list->items = CurrentSource->schema.fields[i].data.list.items;
                fields[i].list->selected = noListSelection;
            break;

            case FIELD_TYPE_FLOAT:
              {
                double fvalue = CurrentSource->schema.fields[i].data.floatNum.defaultValue;
                fields[i].editor = AllocateMemPtr(sizeof(EditorType));
                if (fvalue != 0) {
                    fields[i].editor->h = AllocateMemHandle(32);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    MemSet(s, 32, 0 );
                    DoublePrintValue( fvalue, s, kMaxMantissaDigits);
                } else {
                    fields[i].editor->h = AllocateMemHandle(1);
                    ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
                    s = MemHandleLock(fields[i].editor->h);
                    s[0] = '\0';
                }
                MemPtrUnlock(s);
              }
            break;
#ifdef CONFIG_SCRIPTS
            case FIELD_TYPE_CALCULATED:
              {
                fields[i].script = AllocateMemPtr(sizeof(ScriptType));
                fields[i].script->display = AllocateMemPtr( CV_MAX_STRING_SIZE );
                fields[i].script->display[0] = '?';
                fields[i].script->display[1] = '\0';
              }
              break;
#endif


            default:
                ErrDisplay("unsupported field type");
            break;
            }
        }

        /* Do not fall into the normal code path. */
        return;
    }

    /* Retrieve a copy of the record. */
    CurrentSource->ops.LockRecord(CurrentSource, CurrentRecord, false,
                  &getter, &rec_data);

    /* Copy the record data into place. */
    j = 0;
    for (i = 0; i < CurrentSource->schema.numFields; i++) {
        UInt32 size;
        switch (CurrentSource->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            p = getter.GetString(rec_data, i);
            fields[i].editor = AllocateMemPtr(sizeof(EditorType));
            size = StrLen(p) + 1;
            size = min(size, MAX_STRING_LENGTH);
            fields[i].editor->h = AllocateMemHandle(size);
            ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
            s = MemHandleLock(fields[i].editor->h);
            StrNCopy(s, p, MAX_STRING_LENGTH);
            MemPtrUnlock(s);
            break;

        case FIELD_TYPE_LINK:
            fields[i].link = AllocateMemPtr(sizeof(LinkType));
            p = getter.GetLink(rec_data, i, &(fields[i].link->uniqID));
            StrNCopy(fields[i].link->name, p, 32);
            if (LinkUpdate( CurrentSource->schema.fields[i].data.link.dbID,
                        CurrentSource->schema.fields[i].data.link.fieldNum,
                        fields[i].link))
                IsDirty = true;
            break;

        case FIELD_TYPE_LINKED:
            fields[i].link = AllocateMemPtr(sizeof(LinkType));
            p = getter.GetLinked(rec_data, i);
            if (p)
                StrNCopy(fields[i].link->name, p, 32);
            else
                fields[i].link->name[0] = 0;
            if (CurrentSource->schema.fields[i].data.linked.linkNum < i
                    && CurrentSource->schema.fields[CurrentSource->schema.fields[i].data.linked.linkNum].type == FIELD_TYPE_LINK) {
                fields[i].link->uniqID = 
                    fields[CurrentSource->schema.fields[i].data.linked.linkNum].link->uniqID;
                if (LinkUpdate( CurrentSource->schema.fields[CurrentSource->schema.fields[i].data.linked.linkNum].data.link.dbID,
                            CurrentSource->schema.fields[i].data.linked.fieldNum,
                            fields[i].link))
                    IsDirty = true;
            } else
                fields[i].link->uniqID = 0;

            break;

        case FIELD_TYPE_NOTE:
            p = getter.GetNoteTitle(rec_data, i);
            fields[i].editor = AllocateMemPtr(sizeof(EditorType));
            fields[i].editor->h = AllocateMemHandle(12);
            ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
            s = MemHandleLock(fields[i].editor->h);
            if (p)
                StrNCopy(s, p, 11);
            else
                s[0] = 0;
            MemPtrUnlock(s);
            fields[i].note = AllocateMemPtr(sizeof(NoteType));
            ErrFatalDisplayIf(!fields[i].note, "out of Memory");
            StrNCopy(fields[i].note->title, p, 11);
            p = getter.GetNote(rec_data, i);
            if (p) {
                fields[i].note->h = AllocateMemHandle(StrLen(p) + 1);
                ErrFatalDisplayIf(!fields[i].note->h, "out of Memory");
                s = MemHandleLock(fields[i].note->h);
                StrCopy(s, p);
                MemPtrUnlock(s);
            } else 
                fields[i].note->h = NULL;
            break;

        case FIELD_TYPE_BOOLEAN:
            fields[i].checkbox = AllocateMemPtr(sizeof(CheckBoxType));
            fields[i].checkbox->checked = getter.GetBoolean(rec_data, i);
            break;

        case FIELD_TYPE_INTEGER:
            value = getter.GetInteger(rec_data, i);
            fields[i].editor = AllocateMemPtr(sizeof(EditorType));
            fields[i].editor->h = AllocateMemHandle(32);
            ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
            s = MemHandleLock(fields[i].editor->h);
            MemSet(s, 32, 0);
            StrIToA(s, value);
            MemPtrUnlock(s);
            break;

        case FIELD_TYPE_DATE:
            {
            UInt16 year;
            UInt8 month, day;

            getter.GetDate(rec_data, i, &year, &month, &day);
            fields[i].datetime.month = month;
            fields[i].datetime.day   = day;
            fields[i].datetime.year  = year;
            }
            break;

        case FIELD_TYPE_TIME:
            {
            UInt8 hour, minute;

            getter.GetTime(rec_data, i, &hour, &minute);
            fields[i].datetime.hour = hour;
            fields[i].datetime.minute = minute;
            }
            break;

        case FIELD_TYPE_LIST:
            fields[i].list = AllocateMemPtr(sizeof(ListItemsType));
            fields[i].list->numItems = CurrentSource->schema.fields[i].data.list.numItems;
            fields[i].list->items = CurrentSource->schema.fields[i].data.list.items;
            fields[i].list->selected = getter.GetListItem(rec_data, i);
            break;

        case FIELD_TYPE_FLOAT:
          {
            double fvalue = getter.GetFloat(rec_data, i );
            fields[i].editor = AllocateMemPtr(sizeof(EditorType));
            fields[i].editor->h = AllocateMemHandle(32);
            ErrFatalDisplayIf(!fields[i].editor->h, "out of Memory");
            s = MemHandleLock(fields[i].editor->h);
            MemSet(s, 32, 0 );
            DoublePrintValue( fvalue, s, kMaxMantissaDigits);
            MemPtrUnlock(s);
            break;
          }
#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
          {
            CalculatedValue cv;

            fields[i].script = AllocateMemPtr(sizeof(ScriptType));
            getter.GetCalculated(rec_data, i, &cv);
            fields[i].script->display = AllocateMemPtr( CV_MAX_STRING_SIZE );
            CV_PrintValue( &cv, fields[i].script->display, CV_MAX_STRING_SIZE );
            CV_FreeData( &cv );
            break;
          }
#endif
        default:
            break;
        }
    }

    /* Unlock the record. */
    CurrentSource->ops.UnlockRecord(CurrentSource, CurrentRecord, false,
                    rec_data);
}

static void
FreeRecordData(void)
{
    UInt16 i;
    Err err;

    for (i = 0; i < CurrentSource->schema.numFields; ++i) {
        switch (CurrentSource->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
        case FIELD_TYPE_INTEGER:
        case FIELD_TYPE_FLOAT:
            err = DeallocateMemHandle(fields[i].editor->h);
            ErrFatalDisplayIf( err, "Memory not Free");
            err = DeallocateMemPtr(fields[i].editor);
            break;

        case FIELD_TYPE_NOTE:
            err = DeallocateMemHandle(fields[i].editor->h);
            ErrFatalDisplayIf( err, "Memory not Free");
            err = DeallocateMemPtr(fields[i].editor);
            ErrFatalDisplayIf( err, "Memory not Free");
            if (fields[i].note->h) {
                err = DeallocateMemHandle(fields[i].note->h);
                ErrFatalDisplayIf( err, "Memory not Free");
            }
            err = DeallocateMemPtr(fields[i].note);
            break;

        case FIELD_TYPE_LIST:
            err = DeallocateMemPtr(fields[i].list);
            break;

        case FIELD_TYPE_LINK:
        case FIELD_TYPE_LINKED:
            err = DeallocateMemPtr(fields[i].link);
            break;

#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
            if (fields[i].script->display) {
                err = DeallocateMemPtr(fields[i].script->display);
                ErrFatalDisplayIf( err, "Memory not Free");
            }
            err = DeallocateMemPtr(fields[i].script);
            break;
#endif

        case FIELD_TYPE_BOOLEAN:
            err = DeallocateMemPtr(fields[i].checkbox);
            break;
        default:
            err = 0;
            /* Nothing to free for other field types. */
            break;
        }
        ErrFatalDisplayIf( err, "Memory not Free");
    }

    err = DeallocateMemPtr(fields);
    ErrFatalDisplayIf( err, "Memory not Free");

    fields = 0;
}

static Boolean
EditViewUpdateForm(UInt16 updateMode)
{
    TablePtr table;
    FormPtr form;
#ifdef CONFIG_HANDERA
    UInt16 objectID1[] = {  ctlID_EditView_DoneButton,
                ctlID_EditView_CancelButton,
                ctlID_EditView_ModifyButton,
#ifdef CONFIG_ICONS
                ctlID_EditView_DuplicateButton,
                ctlID_EditView_DeleteButton,
                bmpID_SaveButton,
                bmpID_UndoButton,
                bmpID_DeleteButton,
                bmpID_DuplicateButton,
                bmpID_ModifyButton,
#endif
                0};
    UInt16 objectID2[] = {  ctlID_EditView_UpButton,
                ctlID_EditView_DownButton,
                0};
    UInt16 objectID3[] = {  ctlID_EditView_AllFieldsButton,
                0};
#endif
    form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
    UtilResizeForm(form, objectID1, objectID2, objectID3, ctlID_EditView_Table, true);
#endif
    table = GetObjectPtr(form, ctlID_EditView_Table);
    if( updateMode & 0x01) {
        EditViewInitTable(table);
    } else {
        EditViewLoadTable(table);
    }
    if ( updateMode & (0x01|updateFontChanged)) {
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaTableUseBaseFont(table, !VgaIsVgaFont(DBPrefs.TheStdFont));
        }
#endif
        EditViewSetColumnWidth(table);
    }

    FrmDrawForm(form);
    TblRedrawTable(table);

    /* Disable the cancel button in read-only mode. */
#define HideObject(f,id) FrmHideObject((f),FrmGetObjectIndex((f),(id)))
    if (CurrentSource->openMode == dmModeReadOnly) {
        HideObject(form, ctlID_EditView_DoneButton);
#ifdef CONFIG_ICONS
        HideObject(form, ctlID_EditView_DeleteButton);
        HideObject(form, ctlID_EditView_DuplicateButton);
#endif
        EditViewSetFieldEnabled( false);
        HideObject(form, ctlID_EditView_ModifyButton);
#ifdef CONFIG_ICONS
        HideObject( form, bmpID_ModifyButton);
#endif
    } else if ((CurrentSource->openMode == dmModeReadWrite) || IsNewRecord) {
    //Read Write mode or Read Edit mode but is a new record
        EditViewSetFieldEnabled( true);
    } else {
    //Read Edit mode and an existing record
        if( updateMode & 0x01)
            EditViewSetFieldEnabled( false);
        else
            EditViewSetFieldEnabled( !TblGetRowData( table, 0));
    }
#undef HideObject
    if (IsNewRecord) {
        CurrentRecord = dmMaxRecordIndex;
        CurrentSource->ops.Seek(CurrentSource, &CurrentRecord, 0, dmSeekForward);
    }

    return true;
}

Boolean
EditViewHandleEvent(EventPtr event)
{
    FormPtr form;
    TablePtr table;
    UInt16 fieldNum;
    FieldPtr fld;
    ListPtr lst;
    ControlPtr ctl;

    switch (event->eType) {
    case frmOpenEvent:
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
        }
#endif
        table = GetObjectPtr(form, ctlID_EditView_Table);
        ActiveViewIndex =
            CurrentSource->ops.GetOption_UInt16(CurrentSource,
                            optionID_ListView_ActiveView);

        ActiveView = CurrentSource->ops.GetView(CurrentSource, ActiveViewIndex);
        if ((ActiveView->flags & VIEWFLAG_USE_IN_EDITVIEW) != VIEWFLAG_USE_IN_EDITVIEW) {
            CurrentSource->ops.PutView(CurrentSource, ActiveViewIndex, ActiveView);
            ActiveView = DS_GetView(CurrentSource, ActiveViewIndex);
            ActiveViewIndex = 0xFF;
        }
        if (ActiveViewIndex == 0xFF)
#define HideObject(f,id) FrmHideObject((f),FrmGetObjectIndex((f),(id)))
            HideObject( form, ctlID_EditView_AllFieldsButton);
#undef HideObject

        /* Initialize the globals we use. */
        IsDirty = false;   /* Data is not dirty initially. */
        TopVisibleField = 0;
        CurrentField = noFieldIndex;
    
        SetupRecordData();
    
        FrmCopyTitle(form, ActiveView->name);
    
        EditViewUpdateForm(0x01);
        return true;
    
    case frmCloseEvent:
		/* sw bug
		   Scott Note
		   this needs to be changed to the record's unique
		   id, instead of its index, so if the list view is sorted 
		   when its entered, everything will still work out ok
		   
		   However, the unique id is 24 bits long.  I think that
		   we should change SetOption_UInt16 to a general 'SetOption'
		   we will pass in a (void *) and based on the option id,
		   we will write a specified number of bits/bytes.

		   what do you think?

		   at this point, the top of the list will be incorrect when
		   the global preference is set for 'Rebuild Records after edits'
		*/
        CurrentSource->ops.SetOption_UInt16(CurrentSource,
                        optionID_ListView_TopVisibleRecord,
                        CurrentRecord);
        /* Make sure table no longer has focus. */
        form = FrmGetActiveForm();
        table = GetObjectPtr(form, ctlID_EditView_Table);
        if (TblGetCurrentField(table)) {
            TblReleaseFocus(table);
        }

        /* Free the record data. */
        FreeRecordData();
        CurrentSource->ops.PutView(CurrentSource, ActiveViewIndex, ActiveView);
        CurrentSource->ops.SetOption_UInt16(CurrentSource,
                                    optionID_ListView_ActiveView,
                                    ActiveViewIndex);
    return false;

    case frmUpdateEvent:
        EditViewUpdateForm(event->data.frmUpdate.updateCode);
    return true;
/*    case frmSaveEvent:
    form = FrmGetActiveForm();
    table = GetObjectPtr(form, ctlID_EditView_Table);
    if (TblGetCurrentField(table)) {
        TblReleaseFocus(table);
    }
    if ( (CurrentSource->openMode!= dmModeReadOnly) && ValidateData()) {
        SaveRecord();
    }
    return true;
*/  
    case tblEnterEvent:
        table = event->data.tblSelect.pTable;
        if (TblGetRowData(table, event->data.tblSelect.row)){
            fieldNum = ActiveView->cols[TblGetRowID(table, event->data.tblSelect.row)].fieldNum;
            switch (CurrentSource->schema.fields[fieldNum].type) {
            case FIELD_TYPE_NOTE:
                NotePopupForm( fields[fieldNum].note, false);
            break;
            case FIELD_TYPE_LINK:
                LinkGo( CurrentSource->schema.fields[fieldNum].data.link.dbID,
                        CurrentSource->schema.fields[fieldNum].data.link.fieldNum,
                        fields[fieldNum].link);
            break;
            case FIELD_TYPE_LIST:
                if (event->data.tblSelect.column == 1) {
                    RectangleType r;

                    form = FrmGetActiveForm();
                    lst = GetObjectPtr(form, ctlID_EditView_List);
                    if (fields[fieldNum].list->numItems > 0) {
                        LstSetListChoices( lst, fields[fieldNum].list->items, fields[fieldNum].list->numItems);
                        TblGetItemBounds(table, event->data.tblSelect.row, 1, &r);
                        FrmSetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_List), &r);
                        LstSetSelection(lst, fields[fieldNum].list->selected);
                        LstSetHeight(lst, fields[fieldNum].list->numItems);
                        LstPopupList(lst);
                    }
                }
            break;
            default:
            break;
            }
            return true;
        }
    break;
    case tblSelectEvent:
        table = event->data.tblSelect.pTable;
        fieldNum = ActiveView->cols[TblGetRowID(table, event->data.tblSelect.row)].fieldNum;
        switch (CurrentSource->schema.fields[fieldNum].type) {
        case FIELD_TYPE_STRING:
        case FIELD_TYPE_INTEGER:
        case FIELD_TYPE_FLOAT:
            if (event->data.tblSelect.column == 0) {
                /* A tap on the label edits the field. */
                if (TblGetCurrentField(table)) {
                    TblReleaseFocus(event->data.tblSelect.pTable);
                }
                TblUnhighlightSelection(table);
                TblGrabFocus(table, event->data.tblSelect.row, 1);
                fld = TblGetCurrentField(table);
                if (fld) {
                    FldGrabFocus(fld);
                    FldMakeFullyVisible(fld);
                }
                return true;
            }
        break;

        case FIELD_TYPE_LINK:
            TblUnhighlightSelection(table);
            if (LinkSelect( CurrentSource->schema.fields[fieldNum].data.link.dbID,
                            CurrentSource->schema.fields[fieldNum].data.link.fieldNum,
                            fields[fieldNum].link))
                IsDirty = true;
        return true;

        case FIELD_TYPE_NOTE:
            if (event->data.tblSelect.column == 0) {
                /* A tap on the label edits the field. */
                if (TblGetCurrentField(table)) {
                    TblReleaseFocus(event->data.tblSelect.pTable);
                }
                TblUnhighlightSelection(table);
                TblGrabFocus(table, event->data.tblSelect.row, 1);
                fld = TblGetCurrentField(table);
                if (fld) {
                    FldGrabFocus(fld);
                    FldMakeFullyVisible(fld);
                }
                return true;
            } else {
                fld = TblGetCurrentField( table);
                if( !fld) {
                    NotePopupForm( fields[fieldNum].note, true);
                    IsDirty = true;
                    TblMarkRowInvalid(table, event->data.tblSelect.row);
                    TblUnhighlightSelection(table);
                    TblRedrawTable(table);
                    TblReleaseFocus(table);
                    return true;
                }
            }
        break;
    
        case FIELD_TYPE_BOOLEAN:
           if (event->data.tblSelect.column == 1) {
                if (TblGetItemInt(table,
                          event->data.tblSelect.row,
                          event->data.tblSelect.column))
                    fields[fieldNum].checkbox->checked = true;
                else
                    fields[fieldNum].checkbox->checked = false;
                IsDirty = true;
            }
        break;
    
        case FIELD_TYPE_DATE:
            if (event->data.tblSelect.column == 1) {
                RectangleType r1, r2;
                Boolean selected = false;
                Int16 month, day, year;
    
                form = FrmGetActiveForm();
                lst = GetObjectPtr(form, ctlID_EditView_DateTimeChoiceList);
                TblGetItemBounds(table, event->data.tblSelect.row, 1, &r2);
                FrmGetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_DateTimeChoiceList), &r1);
                r1.topLeft.x = r2.topLeft.x;
                r1.topLeft.y = r2.topLeft.y;
                FrmSetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_DateTimeChoiceList), &r1);
                LstSetHeight(lst, 2);
                switch (LstPopupList(lst)) {
                case 1:
                    fields[fieldNum].datetime.month = 0;
                    selected = true;
                break;
                case 0:
                    if (fields[fieldNum].datetime.month == 0)
                        TimSecondsToDateTime(TimGetSeconds(), &fields[fieldNum].datetime);
                    month = fields[fieldNum].datetime.month;
                    day = fields[fieldNum].datetime.day;
                    year = fields[fieldNum].datetime.year;
                    if (SelectDay(selectDayByDay,
                              &month, &day, &year,
                              "Edit Date")) {
                        fields[fieldNum].datetime.month = month;
                        fields[fieldNum].datetime.day = day;
                        fields[fieldNum].datetime.year = year;
                        selected = true;
                    }
                break;
                }
                if (selected) {
                    TblMarkRowInvalid(table, event->data.tblSelect.row);
                    TblRedrawTable(table);
                    IsDirty = true; 
                }
            }
        break;
    
        case FIELD_TYPE_TIME:
            if (event->data.tblSelect.column == 1) {
                RectangleType r1, r2;
                Boolean selected = false;
    
                form = FrmGetActiveForm();
                lst = GetObjectPtr(form, ctlID_EditView_DateTimeChoiceList);
                TblGetItemBounds(table, event->data.tblSelect.row, 1, &r2);
                FrmGetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_DateTimeChoiceList), &r1);
                r1.topLeft.x = r2.topLeft.x;
                r1.topLeft.y = r2.topLeft.y;
                FrmSetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_DateTimeChoiceList), &r1);
                LstSetHeight(lst, 2);
                switch (LstPopupList(lst)) {
                case 1:
                    fields[fieldNum].datetime.hour = 24;
                    selected = true;
                break;
                case 0:
                    if (FeatureSet31) {
                        Int16 hour, minute;
            
                        if (fields[fieldNum].datetime.hour > 23)
                            TimSecondsToDateTime(TimGetSeconds(), &fields[fieldNum].datetime);
                        hour = fields[fieldNum].datetime.hour;
                        minute = fields[fieldNum].datetime.minute;
                        if (SelectOneTime(&hour, &minute, "Edit Time")) {
                            fields[fieldNum].datetime.hour = hour;
                            fields[fieldNum].datetime.minute = minute;
                            selected = true;
                        }
                    } else {
                        TimeType start, finish;
            
                        if (fields[fieldNum].datetime.hour > 23)
                            TimSecondsToDateTime(TimGetSeconds(), &fields[fieldNum].datetime);
                        start.hours = fields[fieldNum].datetime.hour;
                        start.minutes = fields[fieldNum].datetime.minute;
                        finish.hours = noTime;
                        finish.minutes = noTime;
            
                        if (SelectTimeV33(&start, &finish, false,
                                  "Edit Time", 0)) {
                            fields[fieldNum].datetime.hour = start.hours;
                            fields[fieldNum].datetime.minute = start.minutes;
                            selected = true;
                        }
                    }
                break;
                }

                if (selected) {
                    TblMarkRowInvalid(table, event->data.tblSelect.row);
                    TblRedrawTable(table);
                    IsDirty = true; 
                }
            }
        break;
    
        case FIELD_TYPE_LIST:
            if (event->data.tblSelect.column == 1) {
                RectangleType r;
                Int8 value;

                form = FrmGetActiveForm();
                lst = GetObjectPtr(form, ctlID_EditView_List);
                if (fields[fieldNum].list->numItems > 0) {
                    LstSetListChoices( lst, fields[fieldNum].list->items, fields[fieldNum].list->numItems);
                    TblGetItemBounds(table, event->data.tblSelect.row, 1, &r);
                    FrmSetObjectBounds(form, FrmGetObjectIndex(form, ctlID_EditView_List), &r);
                    LstSetSelection(lst, fields[fieldNum].list->selected);
                    LstSetHeight(lst, fields[fieldNum].list->numItems);
                    value = LstPopupList(lst);
                    if (value != fields[fieldNum].list->selected) {
                        fields[fieldNum].list->selected = value;
                        TblMarkRowInvalid(table, event->data.tblSelect.row);
                        TblRedrawTable(table);
                        IsDirty = true;
                    }
                }
            }
        break;
    
#ifdef CONFIG_SCRIPTS
  	    case FIELD_TYPE_CALCULATED:
            if (event->data.tblSelect.column == 1) {
			  CalculatedValue cv;
			  char *ptrs[CurrentSource->schema.numFields];
			  
			  LockData( ptrs );
			  EditView_GetCalculated( ptrs, fieldNum, &cv );
			  CV_PrintValue( &cv, fields[fieldNum].script->display, CV_MAX_STRING_SIZE );
			  CV_FreeData( &cv );			  
			  UnlockData( ptrs );
			  
			  TblMarkRowInvalid(table, event->data.tblSelect.row);
			  TblRedrawTable( table );
			
			}
			break;
#endif
        default:
        break;
        }
    break;

    case ctlSelectEvent:
        form = FrmGetActiveForm();
        table = GetObjectPtr(form, ctlID_EditView_Table);
        if (TblGetCurrentField(table)) {
            TblReleaseFocus(table);
        }
        switch (event->data.ctlSelect.controlID) {
	    case ctlID_EditView_CancelButton:
            if (IsDirty && FrmAlert(alertID_ConfirmRecordSave)) IsDirty = 0;
        /*continue*/
        case ctlID_EditView_DoneButton:

            if (SaveRecord())
                FrmGotoForm(formID_ListView);
            return true;
    
        case ctlID_EditView_ModifyButton:
            if (CurrentSource->openMode == (dmModeReadEdit)) {
                EditViewSetFieldEnabled( true);
            }
            return true;
        case ctlID_EditView_DeleteButton:
            if (!IsNewRecord && (CurrentSource->openMode != dmModeReadOnly)
                && FrmAlert(alertID_ConfirmDelete) == 0) {
                CurrentSource->ops.DeleteRecord(CurrentSource, CurrentRecord);
//                CurrentRecord = dmMaxRecordIndex;
                FrmGotoForm(formID_ListView);
            }
            return true;
        case ctlID_EditView_DuplicateButton:
            if (SaveRecord() && !IsNewRecord && (CurrentSource->openMode != dmModeReadOnly)) {
			    UInt32 i, value;
				Char *s;
                IsDirty = true;
                IsNewRecord = true;
				for (i = 0; i < CurrentSource->schema.numFields; i++) {
                    if (CurrentSource->schema.fields[i].type == FIELD_TYPE_INTEGER
                            && CurrentSource->schema.fields[i].data.integer.increment != 0) {
                        value = CurrentSource->schema.fields[i].data.integer.defaultValue;
                        if (value != 0) {
                            s = MemHandleLock(fields[i].editor->h);
                            MemSet(s, 32, 0);
                            StrIToA(s, value);
                        }
                    }
                }
                EditViewSetFieldEnabled( true);
            }
            return true;
        case ctlID_EditView_AllFieldsButton:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            ctl = GetObjectPtr(form, ctlID_EditView_AllFieldsButton);
            CurrentSource->ops.PutView(CurrentSource, ActiveViewIndex, ActiveView);
            if (CtlGetValue( ctl)) {
                ActiveView = DS_GetView(CurrentSource, ActiveViewIndex);
            } else {
                ActiveView = CurrentSource->ops.GetView(CurrentSource, ActiveViewIndex);
            }
            TblEraseTable(table);
            EditViewInitTable(table);
            TblDrawTable(table);
            return true;

        }
        
    break;

    case fldHeightChangedEvent:
        EditViewResizeDescription(event);
    return true;

    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case ctlID_EditView_UpButton:
            EditViewScroll(winUp, -1);
        break;

        case ctlID_EditView_DownButton:
            EditViewScroll(winDown, -1);
        break;
        }
    break;

#ifdef CONFIG_HANDERA
    case menuOpenEvent:
        if (FeatureSetHandera) {
            MenuAddItem(menuitemID_AppPrefs, menuitemID_HanderaRotate,
                    '\0', RotateString);
        }
        break;
#endif

    case menuEvent:
        switch (event->data.menu.itemID) {
#ifdef CONFIG_LINKAWARE
        case menuitemID_PublishLink:
            {
            Char name[dmDBNameLength];
            LocalID dbID;
            UInt16 cardNo;
            LinkInfoPtr link;
            
            /* Only handle if data source is backed by a PDB. */
            /* and is not a new record because the Record Index is not set. */
            if (CurrentSource->ops.GetPDB && !IsNewRecord) {
                CurrentSource->ops.GetPDB(CurrentSource, &cardNo, &dbID);
                DmDatabaseInfo(cardNo, dbID, name, 0,0,0,0,0,0,0,0,0,0);
                link = (LinkInfoPtr) LinkSimpleNew(CurrentSource->db,
                                   CurrentRecord, name);
                if (! LinkPublish(link)) {
                FrmAlert(alertID_NoLinkMaster);
                }
    
                return true;
            }
            }
            break;
#endif      
        case menuitemID_Duplicate:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if (TblGetCurrentField(table)) {
                TblReleaseFocus(table);
            }
            if (SaveRecord() && !IsNewRecord && (CurrentSource->openMode != dmModeReadOnly)) {
                UInt32 i, value;
                Char *s;
                IsDirty = true;
                IsNewRecord = true;
                for (i = 0; i < CurrentSource->schema.numFields; i++) {
                    if (CurrentSource->schema.fields[i].type == FIELD_TYPE_INTEGER
                          && CurrentSource->schema.fields[i].data.integer.increment != 0) {
                        value = CurrentSource->schema.fields[i].data.integer.defaultValue;
                        if (value != 0) {
                            s = MemHandleLock(fields[i].editor->h);
                            MemSet(s, 32, 0);
                            StrIToA(s, value);
                        }
                    }
                }
                EditViewSetFieldEnabled( true);
            }
            break;
        case menuitemID_Delete:
            if (!IsNewRecord && (CurrentSource->openMode != dmModeReadOnly) 
                    && FrmAlert(alertID_ConfirmDelete) == 0) {
                CurrentSource->ops.DeleteRecord(CurrentSource, CurrentRecord);
                FrmGotoForm(formID_ListView);
            }
            return true;
    
#ifdef CONFIG_PLUGINS
        case menuitemID_Plugins:
        {
            PlugEnvironement l_PluginInfo;
    
            l_PluginInfo.m_Screen = PLUGINTYPE_EDIT;
            l_PluginInfo.m_DataBase = CurrentSource;
            l_PluginInfo.m_Record = CurrentRecord;
            Plug_ShowList( &l_PluginInfo); 
            return true;
        }
#endif
    
        default:
            return HandleCommonMenuEvent(event->data.menu.itemID);
        }
    break;

    case keyDownEvent:
        switch (event->data.keyDown.chr) {
        case pageUpChr:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if (TblGetCurrentField(table)) {
                TblReleaseFocus(table);
            }
            if (DBPrefs.flags & prefFlagRecordUpPage) {
                if( SaveRecord()
                        && CurrentSource->ops.Seek(CurrentSource, &CurrentRecord, 1, dmSeekBackward)) {
                    IsNewRecord = false;
                    FrmGotoForm(formID_EditView);
                }
            } else
                EditViewScroll(winUp, -1);
            
            return true;
    
        case pageDownChr:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if (TblGetCurrentField(table)) {
                TblReleaseFocus(table);
            }
            if (DBPrefs.flags & prefFlagRecordDownPage) {
                if (!IsNewRecord && SaveRecord()
                        && CurrentSource->ops.Seek(CurrentSource, &CurrentRecord, 1, dmSeekForward)) {
                    IsNewRecord = false;
                    FrmGotoForm(formID_EditView);
                }
            } else
                EditViewScroll(winDown, -1);
            return true;
#ifdef CONFIG_HANDERA
        case vchrNextField :
#endif
#ifdef CONFIG_SONY
        case vchrJogDown :
#endif
        case downArrowChr:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if (!TblGetRowData(table, 0))
            {
                Int16 row, column;
    
                TblGetSelection( table, &row, &column);
                if (TblGetCurrentField(table)) {
                    TblReleaseFocus(table);
                }

                TblUnhighlightSelection(table);

                if (TblGetRowID(table, row) == ActiveView->numCols - 1)
                    return true;

                if (row < TblGetLastUsableRow(table)) {
                    row ++;
                } else {
                    EditViewScroll(winDown, 1);
                }
                fieldNum = ActiveView->cols[TblGetRowID(table, row)].fieldNum;
                switch (CurrentSource->schema.fields[fieldNum].type) {
                case FIELD_TYPE_STRING:
                case FIELD_TYPE_INTEGER:
                case FIELD_TYPE_NOTE:
                case FIELD_TYPE_FLOAT:
                    TblGrabFocus(table, row, 1);
                    fld = TblGetCurrentField(table);
                    if (fld) {
                        FldGrabFocus(fld);
                        FldMakeFullyVisible(fld);
                    }
                break;
                default:
                    TblSelectItem( table, row, 1);
                }
            } else {
                EditViewScroll(winDown, 1);
            }
        return true;
#ifdef CONFIG_HANDERA
        case vchrPrevField :
#endif
#ifdef CONFIG_SONY
        case vchrJogUp :
#endif
        case upArrowChr:
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);

            if (!TblGetRowData(table, 0))
            {
            Int16 row, column;
    
                TblGetSelection( table, &row, &column);

                TblUnhighlightSelection(table);

                if (TblGetRowID(table, row) == 0)
                    return true;

                if (TblGetCurrentField(table)) {
                    TblReleaseFocus(table);
                }
                if (row > 0)
                    row--;
                else {
                    EditViewScroll(winUp, 1);
                }

                fieldNum = ActiveView->cols[TblGetRowID(table, row)].fieldNum;
                switch (CurrentSource->schema.fields[fieldNum].type) {
                case FIELD_TYPE_STRING:
                case FIELD_TYPE_INTEGER:
                case FIELD_TYPE_NOTE:
                    TblGrabFocus(table, row, 1);
                    fld = TblGetCurrentField(table);
                    if (fld) {
                        FldGrabFocus(fld);
                        FldMakeFullyVisible(fld);
                    }
                break;
                default:
                    TblSelectItem( table, row, 1);
                }
            } else {

                EditViewScroll(winUp, 1);
            }
        return true;
#ifdef CONFIG_SONY
        case vchrJogPushedUp :
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if( SaveRecord()
                    && CurrentSource->ops.Seek(CurrentSource, &CurrentRecord, 1, dmSeekBackward)) {
                IsNewRecord = false;
                FrmGotoForm(formID_EditView);
            }
            return true;
#endif
#ifdef CONFIG_SONY
        case vchrJogPushedDown :
            form = FrmGetActiveForm();
            table = GetObjectPtr(form, ctlID_EditView_Table);
            if( SaveRecord()
                    && CurrentSource->ops.Seek(CurrentSource, &CurrentRecord, 1, dmSeekForward)) {
                IsNewRecord = false;
                FrmGotoForm(formID_EditView);
            }
            return true;
#endif
        default:
            break;
        }
    break;
#ifdef CONFIG_HANDERA
    case displayExtentChangedEvent:
        EditViewUpdateForm(0x02);
    break;
#endif
    default:
    break;
    }

    return false;
}

static void
EditViewSetFieldEnabled( Boolean enabled)
{
    FormPtr form;
    TablePtr table;
    UInt16 i, numRows;

    form = FrmGetActiveForm();
    table = GetObjectPtr(form, ctlID_EditView_Table);

    numRows = TblGetNumberOfRows( table);
    for (i = 0; i < numRows; i++)
        TblSetRowData( table, i, !enabled);

#define HideObject(f,id) FrmHideObject((f),FrmGetObjectIndex((f),(id)))
    if( enabled)
    {
        HideObject( form, ctlID_EditView_ModifyButton);
#ifdef CONFIG_ICONS
        HideObject( form, bmpID_ModifyButton);
#endif
    }
#undef HideObject
}

