#ifndef _PLUGIN_H
#define _PLUGIN_H

#define PlugInMain __Startup__

#include "db.h"
//#include "grid.h"

typedef enum {
    plgCmdEvent = firstUserEvent + 0x200,
    plgStopEvent = firstUserEvent + 0x201
}PluginEventEnum;

typedef enum
{
	PLUGINTYPE_AUTOSTART = 0x01,
	PLUGINTYPE_CHOOSER = 0x02,
	PLUGINTYPE_LISTVIEW = 0x04,
	PLUGINTYPE_EDIT  = 0x08,
	PLUGINTYPE_ABOUT = 0x80
} PluginType;

typedef Boolean GridFilterF ( DataSource *, UInt16);

typedef DataSourceDriver * GetDriverF(void);
typedef GridFilterF * GetFilterF(void);
typedef DataSource * GetDataSourceF(void);
typedef UInt16 GetRecordF(void);

typedef struct _AppliAccess
{
	DataSource		*m_CurrentSource;
	UInt16			m_CurrentRecord;
	GetDriverF		*getDriver;
	GetFilterF		*getFilter;
	GetDataSourceF		*getNewDataSource;
	GetRecordF		*getNewRecord;
}AppliAccess;

typedef void RestorePluginF(void);
typedef Boolean InitFormHandleEvent( EventPtr );
typedef int StartPluginF( AppliAccess *);
typedef int StopPluginF( AppliAccess *);
typedef int CmdPluginF( AppliAccess *, UInt8);
typedef void AboutAlertF(void);

typedef struct _PluginArgument
{
	UInt16			m_Type;
	RestorePluginF		*restore;
	InitFormHandleEvent	*initFormHandleEvent;
	AboutAlertF		*showAboutAlert;
	StartPluginF		*startPlugin;
	StopPluginF		*stopPlugin;
	CmdPluginF		*cmdPlugin;
}PluginArgument;

typedef void PlugInMainF( PluginArgument *p_PluginInfo);

#endif
