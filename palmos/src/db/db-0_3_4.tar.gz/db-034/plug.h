#ifndef _PLUG_H
#define _PLUG_H

#include "plugin.h"
//#include "db.h"
typedef struct _PlugEvironement
{
	PluginType		m_Screen;
	DataSource		*m_DataBase;
	UInt16			m_Record;
} PlugEnvironement;

void Plug_Setup(void);
void Plug_Restore(void);

DataSourceDriver *Plug_GetDriver(void);
GridFilterF *Plug_GetFilter( void);
void Plug_ShowList( PlugEnvironement *p_Info);
void Plug_StopLastPlugin( void);

Boolean PluginListHandleEvent( EventPtr p_Event);
Boolean PlugHandleEvent(EventPtr event);
#endif
