#ifndef __UTIL_H__
#define __UTIL_H__


#define YMD 0
#define DMY 1
#define MDY 2

typedef struct localization_info_struct {
  
  Char decimalChar;
  Char dateChar;
  UInt8 dateOrder;

} LocalizationInfo;


extern LocalizationInfo LocalInfo;
extern void Localize() SECT_UI2;

extern void * ShowModalMessage(const char *, FontID, FrameType) SECT_UI2;
extern void   HideModalMessage(void * ptr) SECT_UI2;
extern void * ShowWorkingIndicator(void) SECT_UI2;
extern void   HideWorkingIndicator(void *) SECT_UI2;
extern void   UtilWinDrawTruncChars(const char * str, UInt16 length,
				Int16 x, Int16 y, Int16 maxWidth, Boolean ljustify) SECT_UI2;
#ifdef CONFIG_HANDERA
extern Boolean UtilResizeForm(FormPtr form, UInt16 * objectID1,
                UInt16 * objectID2, UInt16 * objectID3,
                UInt16 centralObject, Boolean draw) SECT_UI2;
extern Boolean UtilCenterForm(FormPtr form, Boolean draw) SECT_UI2;
extern Boolean UtilCheckSizeForm(FormPtr form, Boolean draw) SECT_UI2;
#endif
extern Boolean UtilRctPtInRectangle( Int16 x, Int16 y, RectangleType *r) SECT_UI2;
extern Boolean IsInt( char *str )  SECT_UI2;
extern Boolean IsFloat( char *str ) SECT_UI2;
extern Boolean IsDate( char *str, Date *d ) SECT_UI2;
extern Boolean IsTime( char *str, Time *t ) SECT_UI2;


#endif
