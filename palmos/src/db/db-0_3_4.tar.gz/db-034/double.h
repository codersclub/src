#ifndef _DOUBLE_H
#define _DOUBLE_H

#define kDefaultDisplayString	"00.000000e000"

#define kMaxMantissaDigits	8		// max digits in display value, NOT including decimal
#define kMaxExponentDigits	2		// max digits in exponent value (determined by FplAtoF)

#define kCharPlus				'+'
#define kCharMinus			'-'
#define kCharTimes			'*'
#define kCharDivide			'/'
#define kCharEquals			'='
#define kCharZero				'0'
#define kCharOne				'1'
#define kCharNull				'\0'
#define kCharExp            'e'

#define kDispCharWidth		8
#define kDispManTop			10
#define kDispWidth			135
#define kDispHeight			20

#define kDispManSignLeft	10
#define kDispMantissaLeft	kDispManSignLeft+kDispCharWidth
#define kDispErrorLeft		kDispManSignLeft+(8*kDispCharWidth)
#define kDispExponentLeft	kDispManSignLeft+kDispWidth-(3*kDispCharWidth)
#define kDispExpSignLeft	kDispExponentLeft-kDispCharWidth

typedef enum {
	kfNoOp = 0,	// 0
	kfAdd,		// 1
	kfSub,		// 2
	kfMul,		// 3
	kfDiv,		// 4
	kfExchg,		// 5
	kfEnd
} CalculationSelectorType;


extern void DoubleFree() SECT_UI2;

/* !! DoublePrintValue used by Global Search must be in the main section*/
extern void DoublePrintValue(double x, char *s, UInt16 nbDigits);

extern void DoubleAToD( double *d, Char *str) SECT_UI2;

extern Int32 DoubleComp( FlpDouble fd1, FlpDouble fd2) SECT_UI2;

extern double DoubleIToD( int i) SECT_UI2;
extern double DoubleDiv( double a, double b ) SECT_UI2;
extern double DoubleAdd( double a, double b ) SECT_UI2;
extern double DoubleMul( double a, double b ) SECT_UI2;
extern double DoubleSub( double a, double b ) SECT_UI2;


#endif//_DOUBLE_H
