/*
 * DB: Database I/O code
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <TxtGlue.h>

#include "db.h"
#include "enum.h"
#include "io.h"

typedef struct
{
    DataSourceSortCallback callback;
    void * callback_data;
    DataSource * source;
    DataSourceGetter getter;
} SortCallbackData;

/* While this pointer breaks the reentrant style of the data source
 * layer, it is necessary since PalmOS doesn't let you pass a pointer
 * to the sort callback but rather an integer instead.
 */
static SortCallbackData * sort_callback_data;

static char *   OldDB_Getter_GetString(void * data, UInt16 fieldNum) SECT_DRV;
static Int32    OldDB_Getter_GetInteger(void * data, UInt16 fieldNum) SECT_DRV;
static Boolean  OldDB_Getter_GetBoolean(void * data, UInt16 fieldNum) SECT_DRV;

static void     OldDB_UnpackRecord(DataSource * source, void * packed, void * unpacked[]) SECT_DRV;
static UInt32   OldDB_PackedRecordSize(DataSource * source,
                        DataSourceGetter * getter, void * data) SECT_DRV;
static void     OldDB_PackRecord(DataSource * source, void * dest,
                        DataSourceGetter * getter, void * data) SECT_DRV;
static void     OldDB_LockRecord(DataSource * source, UInt16 index, Boolean writable,
                        DataSourceGetter * getter, void ** data_ptr) SECT_DRV;
static void     OldDB_UnlockRecord(DataSource * source, UInt16 index, Boolean writable,
                        void * record_data) SECT_DRV;
static Err      OldDB_UpdateRecord(DataSource * source, UInt16 * index, Boolean doInsert,
                        DataSourceGetter * getter, void * data) SECT_DRV;
static void     OldDB_SetField(DataSource * source, void * arg, UInt16 fieldNum,
                        DataSourceGetter * getter, void * data) SECT_DRV;

static void     OldDB_UpdateSchema(DataSource * source,
                        DataSourceSchema * schema, UInt32 * reorder) SECT_DRV;
static Boolean  OldDB_GetOption_Boolean(DataSource * source, UInt16 optionID) SECT_DRV;
static void     OldDB_SetOption_Boolean(DataSource * source, UInt16 optionID, Boolean value) SECT_DRV;
static UInt16   OldDB_GetOption_UInt16(DataSource * source, UInt16 optionID) SECT_DRV;
static void     OldDB_SetOption_UInt16(DataSource * source, UInt16 optionID, UInt16 value) SECT_DRV;
static Int16    OldDB_SortCallback(void * rec1, void * rec2, Int16 other,
                        SortRecordInfoPtr rec1SortInfo,
                        SortRecordInfoPtr rec2SortInfo, MemHandle appInfoH) SECT_DRV;
static void     OldDB_Sort(DataSource * source,
                        DataSourceSortCallback callback, void * callback_data) SECT_DRV;
static Boolean  OldDB_Capable(DataSource * source, DataSourceCapability capability) SECT_DRV;
static Err      OldDB_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size) SECT_DRV;
static Err      OldDB_Create(const char* title, DataSourceSchema* schema,
                        void ** key_data_ptr, UInt16 * key_size_ptr) SECT_DRV;
static Boolean  OldDB_SupportsFieldType(DataSourceFieldType type) SECT_DRV;
static void     OldDB_Enumerate(DataSourceEnumerationFunc callback, void * arg) SECT_DRV;
#if 0
static Boolean  OldDB_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation,
                        FindParamsPtr params) SECT_DRV;
#endif
static Err      OldDB_OpenPDB(DataSource * source, UInt16 mode, UInt16 cardNo, LocalID dbID) SECT_DRV;
static Boolean  OldDB_IsPresent(void * key_data, UInt32 key_size) SECT_DRV;
static Boolean  OldDB_CanHandlePDB(UInt16 cardNo, LocalID dbID, UInt32 type, UInt32 creator) SECT_DRV;

static char *
OldDB_Getter_GetString(void * data, UInt16 fieldNum)
{
    void * * ptrs = data;

    return ptrs[fieldNum];
}

static Int32
OldDB_Getter_GetInteger(void * data, UInt16 fieldNum)
{
    void * * ptrs = data;
    Int32 value;

    MemMove(&value, ptrs[fieldNum], sizeof(Int32));
    return value;
}

static Boolean
OldDB_Getter_GetBoolean(void * data, UInt16 fieldNum)
{
    void * * ptrs = data;

    if ( *((UInt8 *) ptrs[fieldNum]))
        return true;
    else
        return false;
}

static void
OldDB_UnpackRecord(DataSource * source, void * packed, void * unpacked[])
{
    UInt8 * rec = packed;
    UInt16 i;

    for (i = 0; i < source->schema.numFields; i++) {
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            unpacked[i] = rec;
            rec += StrLen((const char *)rec) + 1;
            break;

        case FIELD_TYPE_BOOLEAN:
            unpacked[i] = rec;
            rec += 1;
            break;

        case FIELD_TYPE_INTEGER:
            unpacked[i] = rec;
            rec += 4;
            break;

        default:
            ErrDisplay("unknown field type");
            break;
        }
    }
}

static UInt32
OldDB_PackedRecordSize(DataSource * source,
                       DataSourceGetter * getter, void * data)
{
    UInt32 size = 0;
    UInt16 i;
    char * str;

    for (i = 0; i < source->schema.numFields; i++) {
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            str = getter->GetString(data, i);
            size += StrLen(str) + 1;
            break;

        case FIELD_TYPE_BOOLEAN:
            size += sizeof(UInt8);
            break;

        case FIELD_TYPE_INTEGER:
            size += sizeof(Int32);
            break;

        default:
            ErrDisplay("unsupported field type");
            break;
        }
    }

    return size;
}

static void
OldDB_PackRecord(DataSource * source, void * dest,
                 DataSourceGetter * getter, void * data)
{
    UInt32 offset = 0;
    Int32 value;
    UInt16 i;
    UInt8 b;
    char * str;

    for (i = 0; i < source->schema.numFields; i++) {
        switch (source->schema.fields[i].type) {
        case FIELD_TYPE_STRING:
            str = getter->GetString(data, i);
            DmWrite(dest, offset, str, StrLen(str) + 1);
            offset += StrLen(str) + 1;
            break;

        case FIELD_TYPE_BOOLEAN:
            b = (getter->GetBoolean(data, i)) ? 1 : 0;
            DmWrite(dest, offset, &b, sizeof(UInt8));
            offset += sizeof(UInt8);
            break;

        case FIELD_TYPE_INTEGER:
            value = getter->GetInteger(data, i);
            DmWrite(dest, offset, &value, sizeof(Int32));
            offset += sizeof(Int32);
            break;

        default:
            ErrDisplay("unsupported field type");
            break;
        }
    }
}

static void
OldDB_LockRecord(DataSource * source, UInt16 index, Boolean writable,
                 DataSourceGetter * getter, void ** data_ptr)
{
    void ** ptrs, *packed;
    MemHandle h;

    ptrs = AllocateMemPtr(source->schema.numFields * sizeof(void *));

    if (writable)
        h = DmGetRecord(source->db, index);
    else
        h = DmQueryRecord(source->db, index);

    packed = MemHandleLock(h);
    OldDB_UnpackRecord(source, packed, ptrs);

    getter->GetString  = OldDB_Getter_GetString;
    getter->GetInteger = OldDB_Getter_GetInteger;
    getter->GetBoolean = OldDB_Getter_GetBoolean;
    getter->GetDate    = DS_Getter_GetDate;
    getter->GetTime    = DS_Getter_GetTime;
    getter->GetNote    = DS_Getter_GetNote;
    getter->GetNoteTitle = DS_Getter_GetNoteTitle;
    *data_ptr = ptrs;
}

static void
OldDB_UnlockRecord(DataSource * source, UInt16 index, Boolean writable,
                void * record_data)
{
    void * * ptrs = record_data;

    MemPtrUnlock(ptrs[0]);

    if (writable)
        DmReleaseRecord(source->db, index, true);

    DeallocateMemPtr(ptrs);
}

static Err
OldDB_UpdateRecord(DataSource * source, UInt16 * indexP, Boolean doInsert,
                   DataSourceGetter * getter, void * data)
{
    UInt32 size;
    MemHandle recH;
    void * packed;

    /* Determine the packed size of the new record. */
    size = OldDB_PackedRecordSize(source, getter, data);

    if (*indexP == dmMaxRecordIndex || doInsert) {
        /* Create a new record in the database. */
        recH = DmNewRecord(source->db, indexP, size);
        if (recH == 0) {
            /* If we couldn't make the record, bail out. */
            return DmGetLastErr();
        }
    } else {
        /* Otherwise, retrieve and resize an existing record. */
        DmResizeRecord(source->db, *indexP, size);
        recH = DmGetRecord(source->db, *indexP);
    }

    /* Pack the new data into the record. */
    packed = MemHandleLock(recH);
    OldDB_PackRecord(source, packed, getter, data);
    MemPtrUnlock(packed);

    /* Release the write lock on the record. */
    DmReleaseRecord(source->db, *indexP, true);

    return 0;
}

static void
OldDB_SetField(DataSource * source, void * arg, UInt16 fieldNum,
               DataSourceGetter * getter, void * data)
{
    void **ptrs = (void **) arg;
    UInt8 b;
    Int32 value;

    /* Specific behavior depends on the type of field. */
    switch (source->schema.fields[fieldNum].type) {
    case FIELD_TYPE_BOOLEAN:
        b = getter->GetBoolean(data, fieldNum) ? 1 : 0;
        DmWrite(ptrs[0], ((UInt32)ptrs[fieldNum] - (UInt32)ptrs[0]), &b, sizeof(UInt8));
        break;

    case FIELD_TYPE_INTEGER:
        value = getter->GetInteger(data, fieldNum);
        DmWrite(ptrs[0], ((UInt32)ptrs[fieldNum] - (UInt32)ptrs[0]), &value, sizeof(Int32));
        break;

    default:
        ErrDisplay("field type not supported");
        break;
    }
}

static void
OldDB_UpdateSchema(DataSource * source,
                   DataSourceSchema * schema, UInt32 * reorder)
{
    UInt16 cardNo, i;
    void * appInfo;
    UInt32 offset;
    LocalID appInfoID;
    Char name[32];

    /* Retrieve a pointer into the app info block. */
    DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
    appInfoID = DmGetAppInfoID(source->db);
    appInfo = MemLocalIDToLockedPtr(appInfoID, cardNo);

    offset = 6;
    for (i = 0; i < source->schema.numFields; ++i) {
        /* Build a local copy of the field name. */
        StrNCopy(name, schema->fields[i].name, sizeof(name) - 1);
        name[sizeof(name)-1] = '\0';

        /* Store the field name into the app info block. */
        DmWrite(appInfo, offset + 2, &name[0], 32);

        /* Advance to the next entry. */
        offset += 2 + 32 + 2 + 2;
    }
        
    /* Put away the pointer to the app info block. */
    MemPtrUnlock(appInfo);

    /* Now we need to update the schema. */
    DeallocateMemPtr(source->schema.fields);
    CopySchema(&source->schema, schema);
}

static Boolean
OldDB_GetOption_Boolean(DataSource * source, UInt16 optionID)
{
    UInt16 cardNo;
    void * appInfo;
    LocalID appInfoID;
    Boolean result;

    /* Retrieve a pointer into the app info block. */
    DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
    appInfoID = DmGetAppInfoID(source->db);
    appInfo = MemLocalIDToLockedPtr(appInfoID, cardNo);

    switch (optionID) {
    case optionID_DisableGlobalFind:
        result = ( *((UInt16 *) appInfo) & 0x0001 ) != 0;
        break;

    case optionID_LFind_CaseSensitive:
        result = ( *((UInt16 *) appInfo) & 0x0002 ) != 0;
        break;

    case optionID_LFind_WholeWord:
        result = ( *((UInt16 *) appInfo) & 0x0004 ) != 0;
        break;

    default:
        result = false;
        break;
    }

    MemPtrUnlock(appInfo);

    return result;
}

static void
OldDB_SetOption_Boolean(DataSource * source, UInt16 optionID, Boolean value)
{
    UInt16 cardNo;
    void * appInfo;
    LocalID appInfoID;
    UInt16 flags, bits;

    /* Retrieve a pointer into the app info block. */
    DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
    appInfoID = DmGetAppInfoID(source->db);
    appInfo = MemLocalIDToLockedPtr(appInfoID, cardNo);

    flags = *((UInt16 *) appInfo);

    switch (optionID) {
    case optionID_DisableGlobalFind:
        bits = 0x0001;
        break;

    case optionID_LFind_CaseSensitive:
        bits = 0x0002;
        break;

    case optionID_LFind_WholeWord:
        bits = 0x0004;
        break;

    default:
        bits = 0x0000;
        break;
    }

    if (value)
        flags |= bits;
    else
        flags &= ~(bits);

    DmWrite(appInfo, 0, &flags, sizeof(UInt16));
    MemPtrUnlock(appInfo);
}

static UInt16
OldDB_GetOption_UInt16(DataSource * source, UInt16 optionID)
{
    void * appInfo;
    LocalID appInfoID;
    UInt16 result, cardNo;

    switch (optionID) {
    case optionID_ListView_ActiveView:
        result = 0;
        break;

    case optionID_ListView_TopVisibleRecord:
        DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
        appInfoID = DmGetAppInfoID(source->db);
        appInfo = MemLocalIDToLockedPtr(appInfoID, cardNo);
        result = *( ((UInt16 *) appInfo) + 1 );
        MemPtrUnlock(appInfo);
        break;

    default:
        result = 0;
        break;
    }

    return result;
}

static void
OldDB_SetOption_UInt16(DataSource * source, UInt16 optionID, UInt16 value)
{
    if (optionID == optionID_ListView_TopVisibleRecord) {
        void * appInfo;
        LocalID appInfoID;
        UInt16 cardNo;

        DmOpenDatabaseInfo(source->db, 0, 0, 0, &cardNo, 0);
        appInfoID = DmGetAppInfoID(source->db);
        appInfo = MemLocalIDToLockedPtr(appInfoID, cardNo);
        DmWrite(appInfo, 1 * sizeof(UInt16), &value, sizeof(value));
        MemPtrUnlock(appInfo);
    }
}

static Int16
OldDB_SortCallback(void * rec1, void * rec2, Int16 other,
                   SortRecordInfoPtr rec1SortInfo,
                   SortRecordInfoPtr rec2SortInfo, MemHandle appInfoH)
{
    SortCallbackData * data = (SortCallbackData *) sort_callback_data;
//    void * ptrs1[data->source->schema.numFields];
//    void * ptrs2[data->source->schema.numFields];
    void * ptrs1[CONFIG_MAX_NUM_FIELDS_FOR_NEW_DB];
    void * ptrs2[CONFIG_MAX_NUM_FIELDS_FOR_NEW_DB];
    int result;

    OldDB_UnpackRecord(data->source, rec1, ptrs1);
    OldDB_UnpackRecord(data->source, rec2, ptrs2);

    result = data->callback(data->source,
                            &data->getter, &ptrs1,
                            &data->getter, &ptrs2,
                            data->callback_data);

    return result;
}

static void
OldDB_Sort(DataSource * source,
           DataSourceSortCallback callback, void * callback_data)
{
    SortCallbackData data;

    data.callback = callback;
    data.callback_data = callback_data;
    data.source = source;
    data.getter.GetString = OldDB_Getter_GetString;
    data.getter.GetInteger = OldDB_Getter_GetInteger;
    data.getter.GetBoolean = OldDB_Getter_GetBoolean;
    sort_callback_data = &data;
    DmQuickSort(source->db, OldDB_SortCallback, 0);
}

static Boolean
OldDB_Capable(DataSource * source, DataSourceCapability capability)
{
    switch (capability) {
    case DS_CAPABLE_LISTVIEW_EDIT:
        return (CurrentSource->openMode != dmModeReadOnly);
    case DS_CAPABLE_LISTVIEW_WIDTH_EDIT:
        return (CurrentSource->openMode != dmModeReadOnly);
    default:
        return false;
    }
}

static Err
OldDB_Open(DataSource * source, UInt16 mode, void * key_data, UInt16 key_size)
{
    DataSourceChooserKey * key = (DataSourceChooserKey *) key_data;
    UInt32 dbType, size;
    UInt16 numFields, i;
    LocalID dbID, appInfoID;
    UInt8* appInfo, *p, *q;
    UInt16* widths;

    /* Make sure that the key has a valid size. */
    if (key_size != sizeof(DataSourceChooserKey))
        return 0;
    
    /* Fill in the operations structure. */
    source->ops.Close = DS_PDB_Close;
    source->ops.Seek = DS_Seek;
    source->ops.LockRecord = OldDB_LockRecord;
    source->ops.UnlockRecord = OldDB_UnlockRecord;
    source->ops.UpdateRecord = OldDB_UpdateRecord;
    source->ops.SetField = OldDB_SetField;
    source->ops.DeleteRecord = DS_DeleteRecord;
    source->ops.GetRecordID = DS_GetRecordID;
    source->ops.GetRecordIndex = DS_GetRecordIndex;
    source->ops.GetNumOfViews = DS_GetNumOfViews;
    source->ops.GetView = DS_GetView;
    source->ops.PutView = DS_PutView;
    source->ops.StoreView = NULL;
    source->ops.CheckUpdateSchema = DS_CheckUpdateSchema;
    source->ops.UpdateSchema = OldDB_UpdateSchema;
    source->ops.GetOption_Boolean = OldDB_GetOption_Boolean;
    source->ops.SetOption_Boolean = OldDB_SetOption_Boolean;
    source->ops.GetOption_UInt16 = OldDB_GetOption_UInt16;
    source->ops.SetOption_UInt16 = OldDB_SetOption_UInt16;
    source->ops.GetKey = DS_GetKey;
    source->ops.GetPDB = DS_PDB_GetPDB;
    source->ops.GetTitle = DS_PDB_GetTitle;
    source->ops.SetTitle = DS_PDB_SetTitle;
    source->ops.Sort = OldDB_Sort;
    source->ops.Capable = OldDB_Capable;
    source->ops.Info = DS_PDB_Info;
    source->ops.RecalculateFields = NULL;

    /* Retrieve the location in memory of this database. */
    dbID = DmFindDatabase(key->cardNo, key->name);
    if (!dbID)
        return DmGetLastErr();

    /* Check to see if we support this type of database. */
    DmDatabaseInfo(key->cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, &dbType, 0);
    if (dbType != 'DB99')
        return dmErrCantOpen;

    /* Open this database. */
    source->db = DmOpenDatabase(key->cardNo, dbID, mode & ~MaskReadEdit);
    if (! source->db)
        return DmGetLastErr();

    source->mode = mode;

    /* Retrieve the app info block which contains all the metadata. */
    appInfoID = DmGetAppInfoID(source->db);
    appInfo = MemLocalIDToLockedPtr(appInfoID, key->cardNo);
    size = MemPtrSize(appInfo);

    /* Extract the number of fields from the header. */
    MemMove(&numFields, appInfo + 2*sizeof(UInt16), sizeof(numFields));
    source->schema.numFields = numFields;
    source->data = AllocateMemPtr(numFields * sizeof(UInt16));
    widths = (UInt16 *) source->data;

    /* Ensure that we have enough space for all the fields. */
    if (size < (numFields * (2 + 32 + 2 + 2))) {
        MemPtrUnlock(appInfo);
        DmCloseDatabase(source->db);
        return dmErrCantOpen;
    }

    /* Determine how much space needs to be allocated. */
    p = appInfo + 6;
    size = numFields * sizeof(DataSourceFieldInfo);
    for (i = 0; i < numFields; ++i) {
        size += StrLen((const char *)p + 2) + 1;
        p += 2 + 32 + 2 + 2;
    }
    source->schema.fields = AllocateMemPtr(size);

    /* Extract the remainder of the schema from the block. */
    p = appInfo + 6;
    q = (UInt8 *) (source->schema.fields + numFields);
    for (i = 0; i < numFields; ++i) {
        UInt16 type;

        MemMove(&type, p + 0, sizeof(UInt16));
        switch (type) {
        case 0:
            source->schema.fields[i].type = FIELD_TYPE_STRING;
            break;
        case 1:
            source->schema.fields[i].type = FIELD_TYPE_BOOLEAN;
            break;
        case 2:
            source->schema.fields[i].type = FIELD_TYPE_INTEGER;
            break;
        }

        /* Copy the field name over. */
        source->schema.fields[i].name = (char *)q;
        StrCopy((char *) q, (char *) (p + 2));
        q += StrLen((char *) (p + 2)) + 1;

        /* Copy the width into the private data section of source. */
        MemMove(&widths[i], p + 2 + 32 + 2, sizeof(UInt16));

        /* Advance to the next entry. */
        p += 2 + 32 + 2 + 2;
    }

    /* Put away our reference to the app info block. */
    MemPtrUnlock(appInfo);

    /* store the key of the database*/
    source->key.size = key_size;
    source->key.data = AllocateMemPtr(key_size);
    MemMove( source->key.data, key_data, key_size);

    return 0;
}

static Err
OldDB_Create(const char* title, DataSourceSchema* schema,
             void ** key_data_ptr, UInt16 * key_size_ptr)
{
    Err err;
    LocalID dbID, appInfoID;
    MemHandle appInfoHand;
    DmOpenRef db;
    DataSourceChooserKey *key;
    UInt32 size, offset;
    void *p;
    UInt16 v, i;

    err = DmCreateDatabase(0, title, DBCreatorID, 'DB99', false);
    if (err)
        return err;

    dbID = DmFindDatabase(0, title);
    if (!dbID)
        return DmGetLastErr();

    db = DmOpenDatabase(0, dbID, dmModeReadWrite);
    if (!db)
        return DmGetLastErr();

    /* Allocate a handle for the app info block. */
    size = 6 + (schema->numFields * (2 + 32 + 2 + 2));
    appInfoHand = DmNewHandle(db, size);
    p = MemHandleLock(appInfoHand);
    DmSet(p, 0, size, 0);

    /* Store the number of fields. */
    v = schema->numFields;
    DmWrite(p, 2 * sizeof(UInt16), &v, sizeof(UInt16));

    /* Store the field information. */
    offset = 6;
    for (i = 0; i < schema->numFields; ++i) {
        /* Store the field type. */
        switch (schema->fields[i].type) {
        case FIELD_TYPE_STRING:
            v = 0;
            break;
        case FIELD_TYPE_BOOLEAN:
            v = 1;
            break;
        case FIELD_TYPE_INTEGER:
            v = 2;
            break;
        default:
            ErrDisplay("field type not supported");
            break;
        }
        DmWrite(p, offset, &v, sizeof(UInt16));

        /* Store the field name. */
        DmStrCopy(p, offset + 2, schema->fields[i].name);

        /* Set the initial column width. */
        v = 80;
        DmWrite(p, offset + 2 + 32 + 2, &v, sizeof(UInt16));

        /* Advance the offset to the next field. */
        offset += 2 + 32 + 2 + 2;
    }

    /* Store the app info handle into the database. */
    appInfoID = MemHandleToLocalID(appInfoHand);
    DmSetDatabaseInfo(0, dbID, 0, 0, 0, 0, 0, 0, 0, &appInfoID, 0, 0, 0); 

    /* Close the database. */
    DmCloseDatabase(db);

    /* Add this database into the chooser screen. */
    key = (DataSourceChooserKey *) AllocateMemPtr(sizeof(DataSourceChooserKey));
    MemSet(key, sizeof(*key), 0);
    key->cardNo = 0;
    StrNCopy(key->name, title, sizeof(key->name) - 1);
    key->name[sizeof(key->name)-1] = '\0';
    *key_data_ptr = key;
    *key_size_ptr = sizeof(*key);

    return 0;
}

static Boolean
OldDB_SupportsFieldType(DataSourceFieldType type)
{
    switch (type) {
    case FIELD_TYPE_STRING:
    case FIELD_TYPE_INTEGER:
    case FIELD_TYPE_BOOLEAN:
        return true;
 
    default:
        return false;
    }
}

static void
OldDB_Enumerate(DataSourceEnumerationFunc callback, void * arg)
{
    DS_Enumerate(callback, arg, 'DB99', DBCreatorID,
                            sourceID_DB02x);
}

static Err
OldDB_OpenPDB(DataSource * source, UInt16 mode, UInt16 cardNo, LocalID dbID)
{
    DataSourceChooserKey key;

    key.cardNo = cardNo;
    DmDatabaseInfo(cardNo, dbID, key.name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    return OldDB_Open(source, mode, &key, sizeof(key));
}

//We can't use the Global Find with functions in  the drv section
#if 0
static Boolean
OldDB_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation,
                 FindParamsPtr params)
{
    return DS_GlobalFind(callback, continuation, params, 'DB99',
                             DBCreatorID, OldDB_OpenPDB);
}
#endif

static Boolean
OldDB_IsPresent(void * key_data, UInt32 key_size)
{
    return DS_IsPresent(key_data, key_size, 'DB99', DBCreatorID);
}

static Boolean
OldDB_CanHandlePDB(UInt16 cardNo, LocalID dbID, UInt32 type, UInt32 creator)
{
    return (creator == DBCreatorID) && (type == 'DB99');
}

DataSourceDriver *
OldDB_GetDriver(void)
{
    DataSourceDriver * driver = AllocateMemPtr(sizeof(DataSourceDriver));

    StrCopy(driver->name, "DB 0.2.x");
    driver->sourceID = 1;
    driver->class_ops.Open = OldDB_Open;
    driver->class_ops.OpenPDB = OldDB_OpenPDB;
    driver->class_ops.CheckTitle = DS_CheckTitle;
    driver->class_ops.Create = OldDB_Create;
    driver->class_ops.SupportsFieldType = OldDB_SupportsFieldType;
    driver->class_ops.Delete = DS_Delete;
    driver->class_ops.Enumerate = OldDB_Enumerate;
//    driver->class_ops.GlobalFind = OldDB_GlobalFind;
    driver->class_ops.GlobalFind = NULL;
    driver->class_ops.IsPresent = OldDB_IsPresent;
    driver->class_ops.CompareKey = DS_CompareKey;
    driver->class_ops.CanHandlePDB = OldDB_CanHandlePDB;
    driver->class_ops.Exchange = DS_PDB_Exchange;

    return driver;
}
