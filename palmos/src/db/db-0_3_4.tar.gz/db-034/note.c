#include <PalmOS.h>
#include <Window.h>

#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#include "enum.h"
#include "util.h"
#include "note.h"

#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))

//static void NoteSetTitle (void) SECT_UI;
static void NoteUpdateScrollers() EDITSECT;
static Boolean NoteUpdateDisplay (Int16 updateCode) EDITSECT;
static void NoteSaveData() EDITSECT;
static void NoteRetrieveData(FieldPtr fld) EDITSECT;
static void NoteScroll (WinDirectionType direction, UInt16 linesToScroll) EDITSECT;

static NotePtr CurrentNote;
static Boolean Editable;

UInt16 NotePopupForm( NotePtr note, Boolean editable)
{
    if (!note) return 0;
    if (!note->h) {
        Char * s;

        note->h = AllocateMemHandle( 256);
        s = MemHandleLock(note->h);
        s[0] = '\0';
        MemHandleUnlock(note->h);
    }
    CurrentNote = note;
    Editable = editable;
    FrmPopupForm(formID_Note);
    return 0;
}

/***********************************************************************
 *
 * FUNCTION:    NoteSetTitle
 *
 * DESCRIPTION: P16. This routine formats and sets the title of the edit view.
 *              If the edit view is visible, the new title is drawn.
 *
 *					 The title parts are referenced as follows:
 *					 [text 1][arg 1][text 2][arg 2][text 3]
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
/*
static void NoteSetTitle (void)
{
    FormPtr form;

    if (CurrentNote->title[0]) {
        form = FrmGetFormPtr (formID_Note);
        FrmCopyTitle (form, CurrentNote->title);
    } else {
        Char * titleTemplateP = CopyStringResource(stringID_Note);
        form = FrmGetFormPtr (formID_Note);
        FrmCopyTitle (form, titleTemplateP);
        DeallocateMemPtr(titleTemplateP);
    }
}
*/
/***********************************************************************
 *
 * FUNCTION:    NoteUpdateScrollers
 *
 * DESCRIPTION: P13. Visually updates the scroll arrows.
 *
 * PARAMETERS:  frm - poInt16er to the Edit View form.
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void NoteUpdateScrollers()
{
	FieldPtr fieldP;
	ScrollBarPtr scrollBarP;

	UInt16 nPosition, nMax;
	UInt16 textHeight, fieldHeight;
    FormPtr form = FrmGetActiveForm();

	fieldP = GetObjectPtr(form,ctlID_Note_EditField);
	scrollBarP = GetObjectPtr(form,ctlID_Note_ScrollBar);

	FldGetScrollValues(fieldP, &nPosition, &textHeight, &fieldHeight);

	if (textHeight > fieldHeight){
		nMax = textHeight - fieldHeight + FldGetNumberOfBlankLines (fieldP);
	} else if (nPosition) {
		nMax = nPosition;
	} else {
		nMax = 0;
	}

	SclSetScrollBar(scrollBarP, nPosition, 0, nMax, fieldHeight - 1);


}


/***********************************************************************
 *
 * FUNCTION:    NoteUpdateDisplay
 *
 * DESCRIPTION: P11. This routine updates the display of the edit view
 *
 * PARAMETERS:  updateCode - a code that indicated what changes have been
 *                           made to the view.
 *                		
 * RETURNED:    nothing
 *
 ***********************************************************************/
static Boolean NoteUpdateDisplay (Int16 updateCode)
{
/*
	FormPtr frm;

	frm = FrmGetActiveForm ();
*/
	return (false);
}


/***********************************************************************
 *
 * FUNCTION:		NoteSaveData
 *
 * DESCRIPTION:	P5. Saves the data in the field as the first record in 
 *                the application's database.
 *
 * PARAMETERS:		fld - the field that contains the text.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void NoteSaveData()
{
	FieldPtr fld;
	FormPtr	frm;

	frm = FrmGetActiveForm();
	fld = GetObjectPtr(frm, ctlID_Note_EditField);

	if (FldDirty (fld))
	{
		FldCompactText (fld);
	}

}


/***********************************************************************
 *
 * FUNCTION:		NoteRetrieveData
 *
 * DESCRIPTION:	P5. Retrieves the data from the first record of a database 
 *						and places it in a field.
 *
 * PARAMETERS:		fld - the field to contain the text.
 *
 * RETURNED:		Nothing.
 *
 ***********************************************************************/
static void NoteRetrieveData(FieldPtr fld)
{
    // Check to make sure there is a record to retrieve.
    FldSetTextHandle(fld, CurrentNote->h);

//    NoteSetTitle();

    NoteUpdateScrollers();
}


/***********************************************************************
 *
 * FUNCTION:    NoteScroll
 *
 * DESCRIPTION: P13. Scrolls the edit view a page or a line at a time.
 *
 * PARAMETERS:  direction - up or dowm
 *              oneLine   - true scroll one line, false scrolls one page
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void NoteScroll (WinDirectionType direction, UInt16 linesToScroll)
{
	FieldPtr fld;
	Int16 blankLines;

	fld = GetObjectPtr(FrmGetActiveForm(),ctlID_Note_EditField);

	if (FldScrollable (fld, direction))
	{
		blankLines = FldGetNumberOfBlankLines(fld);

		FldScrollField(fld, linesToScroll, direction);
		NoteUpdateScrollers();
	}
}


/***********************************************************************
 *
 * FUNCTION:		NoteHandleEvent
 *
 * DESCRIPTION:	P3. Handles processing of events for the �edit� form.
 *
 * PARAMETERS:		event	- the most recent event.
 *
 * RETURNED:		True if the event is handled, false otherwise.
 *
 ***********************************************************************/
Boolean NoteHandleEvent(EventPtr event)
{
	FormPtr		frm;
	FieldPtr	fld;
    ControlPtr  ctl;
	Boolean	handled = false;
	FieldAttrType	attr;


	switch (event->eType)
	{
	case frmOpenEvent:
		frm = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(frm, vgaFormModify160To240);
            if (!UtilCheckSizeForm(frm, 0)) {
                FrmAlert(alertID_FormTooBig);
                FrmReturnToForm(0);
                return true;
            }
        }
#endif
		fld = GetObjectPtr(frm, ctlID_Note_EditField);

   		NoteRetrieveData(fld);
   		FldSetMaxChars(fld, NOTE_MAXCHAR);
   		FldGetAttributes( fld, &attr);
   		attr.editable = Editable;
   		FldSetAttributes( fld, &attr);
		
		FrmDrawForm(frm);
			
		FrmSetFocus(frm, FrmGetObjectIndex(frm, ctlID_Note_EditField));
		handled = true;
	break;
  	case frmCloseEvent:
            frm = FrmGetActiveForm();
            fld = GetObjectPtr(frm,ctlID_Note_EditField);
        	FldSetTextHandle (fld, 0);
	break;
  	case frmUpdateEvent:
		handled =  NoteUpdateDisplay (event->data.frmUpdate.updateCode);
	break;
   	case keyDownEvent:
   		if (event->data.keyDown.chr == pageUpChr)
		{
			UInt16 fieldHeight, null1, null2;
			fld = GetObjectPtr(FrmGetActiveForm(),ctlID_Note_EditField);
			FldGetScrollValues(fld, &null1, &null2, &fieldHeight);
			NoteScroll (winUp, fieldHeight);
			handled = true;
		}
	
		else if (event->data.keyDown.chr == pageDownChr)
		{
			UInt16 fieldHeight, null1, null2;
			fld = GetObjectPtr(FrmGetActiveForm(),ctlID_Note_EditField);
			FldGetScrollValues(fld, &null1, &null2, &fieldHeight);
			NoteScroll (winDown, fieldHeight);
			handled = true;
		}
		else
		{
			frm = FrmGetActiveForm ();
			FrmHandleEvent (frm, event);
			NoteUpdateScrollers ();
			handled = true;
		}
		break;
			
	case sclRepeatEvent:
		if( (event->data.sclRepeat.newValue - event->data.sclRepeat.value) < 0)
			NoteScroll (winUp, event->data.sclRepeat.value - event->data.sclRepeat.newValue);
		else
	   		NoteScroll (winDown, event->data.sclRepeat.newValue - event->data.sclRepeat.value);
		break;
			
			
   	case ctlSelectEvent:  // A control button was pressed and released.
	   	switch (event->data.ctlEnter.controlID)
	   	{
	   	case ctlID_Note_DoneButton:
            frm = FrmGetActiveForm();
            fld = GetObjectPtr(frm,ctlID_Note_EditField);
            if (Editable) {
                ctl = GetObjectPtr(frm, ctlID_Note_QuickTitle);
                if (CtlGetValue(ctl)) {
                    int i = 0;
                    Char *fieldP = FldGetTextPtr(fld);
                    while (i < 11 && fieldP[i] != 0 && fieldP[i] != '\n')
                        CurrentNote->title[i] = fieldP[i++];
                    CurrentNote->title[i] = '\0';
                }
                NoteSaveData();
            }
        	FldSetTextHandle (fld, 0);
            FrmReturnToForm(formID_EditView);
            FrmUpdateForm(formID_EditView, 0);
            handled = true;
        break;
        }
    break;
    case menuEvent:
        MenuEraseStatus(0);

        handled = HandleCommonMenuEvent(event->data.menu.itemID);
    break;
    default:
    break;
    }
    return(handled);
}

#undef GetObjectPtr
