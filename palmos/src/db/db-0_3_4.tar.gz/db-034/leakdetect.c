#include <PalmOS.h>
#include "config.h"
#include "leakdetect.h"

#ifdef DETECT_LEAKS
#define LEAK_OUT_NAME "leaks.txt"
void RecordMemInfoFn( void *addr, char *str, char *file, long line ) {
	HostFILE  *hf=NULL;

	ASSERT(file);
	
	hf = HostFOpen(LEAK_OUT_NAME,"a");
	if (hf) {
		HostFPrintF(hf,"i 0x%lx '%s' %s %ld\n", (long)addr, str, file, line);
		HostFClose(hf);
#ifdef CONFIG_DEBUG
        HostTraceOutputTL( 0, "i 0x%lx '%s' %s %ld\n", (long)addr, str, file, line);
#endif
	}
}


MemHandle AllocateMemHandleFn(long size, char *file, long line)
{
     MemHandle   addr=NULL;
     HostFILE  *hf=NULL;

     ASSERT(file);

     addr = MemHandleNew(size);
     hf = HostFOpen(LEAK_OUT_NAME,"a");
     if (hf) {
	  HostFPrintF(hf,"ha 0x%lx 0x%lx %s %ld\n", (long)addr, (long)size, file, line);
	  HostFClose(hf);
#ifdef CONFIG_DEBUG
      HostTraceOutputTL( 0, "ha 0x%lx 0x%lx %s %ld\n", (long)addr, (long)size, file, line);
#endif
     }
     return addr;
}

Err DeallocateMemHandleFn(MemHandle addr, char *file, long line)
{
     HostFILE  *hf=NULL;
	 Err e;

     ASSERT(addr);
     ASSERT(file);

     e = MemHandleFree(addr);
     hf = HostFOpen(LEAK_OUT_NAME,"a");
     if (hf) {
	  HostFPrintF(hf,"hf 0x%lx %s %ld\n", (long) addr, file, line);
	  HostFClose(hf);
#ifdef CONFIG_DEBUG
	  HostTraceOutputTL( 0, "hf 0x%lx %s %ld\n", (long) addr, file, line);
#endif
     }
	 return e;


}

MemPtr AllocateMemPtrFn(long size, char *file, long line)
{
     MemPtr   addr=NULL;
     HostFILE  *hf=NULL;

     ASSERT(file);

     addr = MemPtrNew(size);
     hf = HostFOpen(LEAK_OUT_NAME,"a");
     if (hf) {
	  HostFPrintF(hf,"pa 0x%lx 0x%lx %s %ld\n", (long)addr, (long)size, file, line);
	  HostFClose(hf);
#ifdef CONFIG_DEBUG
	  HostTraceOutputTL(0,"pa 0x%lx 0x%lx %s %ld\n", (long)addr, (long)size, file, line);
#endif
     }
     return addr;
}

Err DeallocateMemPtrFn(MemPtr addr, char *file, long line)
{
     HostFILE  *hf=NULL;
	 Err e;

     ASSERT(addr);
     ASSERT(file);

     e = MemPtrFree(addr);
     hf = HostFOpen(LEAK_OUT_NAME,"a");
     if (hf) {
	  HostFPrintF(hf,"pf 0x%lx %s %ld\n", (long) addr, file, line);
	  HostFClose(hf);
#ifdef CONFIG_DEBUG
	  HostTraceOutputTL(0,"pf 0x%lx %s %ld\n", (long) addr, file, line);
#endif
     }
	 return e;

}
#endif

