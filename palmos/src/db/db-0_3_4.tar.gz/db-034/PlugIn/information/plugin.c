/***********************************************************************
*
**********************************************************************/
#include <PalmOS.h>
#include <PalmCompatibility.h>

#include "plugin.h"
#include "db.h"
#include "informationres.h"

extern int showAlert( AppliAccess *p_Access);
void restorePlugin( void);
void about( void);
void PlugInMain( PluginArgument *p_PluginInfo);

void restorePlugin( void)
{
}

void about( void)
{
}
/***********************************************************************/

void PlugInMain( PluginArgument *p_PluginInfo)
{

	p_PluginInfo->m_Type = PLUGINTYPE_LISTVIEW | PLUGINTYPE_ABOUT;
	p_PluginInfo->restore = restorePlugin;
	p_PluginInfo->showAboutAlert = about;
	p_PluginInfo->startPlugin = showAlert;
}

/***********************************************************************
***********************************************************************/
DWord PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags)
{
	#pragma unused (cmd, cmdPBP, launchFlags)
	return (0);
}
