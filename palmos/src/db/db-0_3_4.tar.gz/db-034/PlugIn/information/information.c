#include <PalmOS.h>

#include "db.h"
#include "plugin.h"
#include "informationres.h"

int showAlert( AppliAccess *p_Access);

int
showAlert( AppliAccess *p_Access)
{
	int nbRecord = 0;
	Char string[10];

	if ( p_Access->m_CurrentSource == NULL)
		return -1;
	nbRecord = DmNumRecords( p_Access->m_CurrentSource->db);
	/* Unlock the information on the data source. */
	FrmCustomAlert( alertID_InfoDialog, StrIToA( string, nbRecord), NULL, NULL);
	return 0;
}
