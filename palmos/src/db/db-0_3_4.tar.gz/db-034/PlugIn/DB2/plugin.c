/***********************************************************************
**********************************************************************/
#include <PalmOS.h>
#include <PalmCompatibility.h>

#include "plugin.h"

extern DataSourceDriver *OldDB_GetDriver(void);

int start( AppliAccess *p_Access)
{
	p_Access->getDriver = OldDB_GetDriver;
	return 0;
}

void restorePlugin( void)
{
}

void about( void)
{
}

/***********************************************************************/

void PlugInMain( PluginArgument *p_PluginInfo)
{
	p_PluginInfo->m_Type = PLUGINTYPE_AUTOSTART;
	p_PluginInfo->restore = restorePlugin;
	p_PluginInfo->showAboutAlert = about;
	p_PluginInfo->startPlugin = start;
}

/***********************************************************************
***********************************************************************/
DWord PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags)
{
	#pragma unused (cmd, cmdPBP, launchFlags)
	return (0);
}
