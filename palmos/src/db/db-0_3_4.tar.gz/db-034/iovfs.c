/*
 * DB: Database I/O on VFS code
 * Copyright (C) 2002 by Chalain Marc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <TxtGlue.h>
#include <VFSMgr.h>

#include "db.h"
#include "enum.h"
#include "io.h"
#include "iovfs.h"
#ifdef CONFIG_PLUGINS
#include "plug.h"
#endif
#include "double.h"
#ifdef CONFIG_SCRIPTS
#include "calcvalue.h"
#endif

#define DS_VFS_DirPathName "/PALM/Launcher/"

static FileInfoType * FileInfoNew(UInt16 nameLength) SECT_DRV;
static void FileInfoFree(FileInfoType * fileInfo) SECT_DRV;
static void PathCopy( Char * dstP, Char * srcP) SECT_DRV;
static FileRef OpenDBDirectory(UInt16 volRefNum) SECT_DRV;

static FileInfoType *
FileInfoNew(UInt16 nameLength)
{
    FileInfoType * fileInfo;

    fileInfo = AllocateMemPtr( sizeof(FileInfoType));
    MemSet(fileInfo, sizeof(FileInfoType), 0);
    fileInfo->nameP = (char *)AllocateMemPtr(nameLength);
    fileInfo->nameBufLen = nameLength;
    return fileInfo;
}

static void
FileInfoFree(FileInfoType * fileInfo)
{
    DeallocateMemPtr( fileInfo->nameP);
    DeallocateMemPtr( fileInfo);
}

static void
PathCopy( Char * dstP, Char * srcP)
{
    StrCopy( dstP, DS_VFS_DirPathName);
    if (dstP[StrLen(dstP)-1] != '/')
        StrCat( dstP, "/");
    StrCat( dstP, srcP);
}

static FileRef
OpenDBDirectory(UInt16 volRefNum)
{
    FileRef dirRef;

    if (VFSFileOpen(volRefNum, DS_VFS_DirPathName, vfsModeReadWrite, &dirRef) != errNone){
        if (VFSDirCreate( volRefNum, DS_VFS_DirPathName) != errNone)
           return 0;
        if (VFSFileOpen(volRefNum, DS_VFS_DirPathName, vfsModeReadWrite, &dirRef) != errNone)
           return 0;
    }
    return dirRef;
}

Boolean
DS_VFS_CheckTitle(const char* title)
{
    UInt16 volRefNum;
    UInt32 volIterator = 0, dirIterator = 0;
    FileRef dirRef, fileRef;
    FileInfoType * fileInfo;
    Char nameDB[dmDBNameLength], pathFile[255];
    Err err;

   while ( VFSVolumeEnumerate(&volRefNum, &volIterator) == errNone) {
        dirRef = OpenDBDirectory(volRefNum);
        if (!dirRef)
            return false;
        dirIterator = vfsIteratorStart;
        fileInfo = FileInfoNew(50);
        while (dirIterator != vfsIteratorStop ) {
            if (VFSDirEntryEnumerate(dirRef, &dirIterator, fileInfo) != errNone)
                break;
            PathCopy( pathFile, fileInfo->nameP);
            if ((err = VFSFileOpen(volRefNum, pathFile, vfsModeRead, &fileRef)) != errNone){
                ErrAlert(err);
                continue;
            }
            VFSFileDBInfo(fileRef, nameDB, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
            if ( StrCompare(title, nameDB) == 0) {
                FileInfoFree( fileInfo);
                VFSFileClose(fileRef);
                VFSFileClose( dirRef);
                return true;
            }
            VFSFileClose(fileRef);
        }
        FileInfoFree( fileInfo);
        VFSFileClose( dirRef);
    }
    return false;
}

void
DS_VFS_Delete(void * key_data, UInt32 key_size)
{
    VFSChooserKey * key = (VFSChooserKey *) key_data;

    VFSFileDelete(key->volRefNum, key->name);
}

void
DS_VFS_Enumerate(DataSourceEnumerationFunc callback, void * arg,
                 UInt32 type, UInt32 creator, UInt16 sourceID)
{
    VFSChooserKey key;
    UInt16 volRefNum;
    UInt32 volIterator = 0, dirIterator = 0;
    UInt32 typeID = 0, creatorID = 0;
    FileRef dirRef, fileRef;
    FileInfoType * fileInfo;
    Char nameDB[dmDBNameLength], pathFile[255];
    Err err;

    while ( VFSVolumeEnumerate(&volRefNum, &volIterator) == errNone) {
        dirRef = OpenDBDirectory(volRefNum);
        if (!dirRef)
            return;
        dirIterator = vfsIteratorStart;
        fileInfo = FileInfoNew(50);
        while (dirIterator != vfsIteratorStop ) {
            if (VFSDirEntryEnumerate(dirRef, &dirIterator, fileInfo) != errNone)
                break;
            PathCopy( pathFile, fileInfo->nameP);
            if ((err = VFSFileOpen(volRefNum, pathFile, vfsModeRead, &fileRef)) != errNone){
                ErrAlert(err);
                continue;
            }
            VFSFileDBInfo(fileRef, nameDB, 0, 0, 0, 0, 0, 0, 0, 0, &typeID, &creatorID, 0);
            if ( typeID == type && creatorID == creator) {
                StrCopy( key.name, pathFile);
                key.volRefNum = volRefNum;
                callback(arg, nameDB, sourceID, &key, sizeof(key));
            }
            VFSFileClose(fileRef);
        }
        VFSFileClose( dirRef);
        FileInfoFree( fileInfo);
    }
}

Boolean
DS_VFS_IsPresent(void * key_data, UInt32 key_size,
                 UInt32 ds_type, UInt32 ds_creator)
{
    UInt32 creator, type;
    FileRef fileRef = 0;
    VFSChooserKey * key = (VFSChooserKey *) key_data;

    if (key_size == sizeof(VFSChooserKey)
            && VFSFileOpen(key->volRefNum, key->name, vfsModeReadWrite, &fileRef) == errNone
            && VFSFileDBInfo(fileRef, 0, 0, 0, 0, 0, 0, 0, 0, 0, &type, &creator, 0) == errNone
            && creator == ds_creator
            && type == ds_type) {
        VFSFileClose(fileRef);
        return true;
    }
    if (fileRef)
        VFSFileClose(fileRef);
    return false;
}

Boolean
DS_VFS_CompareKey(void * key1_data, UInt16 key1_size,
                  void * key2_data, UInt16 key2_size)
{
    VFSChooserKey * key1 = (VFSChooserKey *) key1_data;
    VFSChooserKey * key2 = (VFSChooserKey *) key2_data;

    return (key1_size == key2_size)
        && (key1->volRefNum == key2->volRefNum)
        && (StrCompare(key1->name, key2->name) == 0);
}

void
DS_VFS_Close(DataSource * source)
{
    VFSChooserKey key;
    LocalID dbID;
    UInt16 cardNo;

    source->ops.Info(source, &cardNo, &dbID, 0, 0, 0, 0);

    source->ops.GetKey(source, &key);
    DmCloseDatabase(source->db);
    source->db = 0;
    if (source->data) DeallocateMemPtr(source->data);
    if (source->key.data) DeallocateMemPtr(source->key.data);
    FreeSchema( &source->schema);


    VFSFileDelete(key.volRefNum, key.name);
    VFSExportDatabaseToFile(key.volRefNum, key.name, cardNo, dbID);
    DmDeleteDatabase(cardNo, dbID);
}


Err
MoveDatabaseToCard(void * key_src_data, UInt16 key_src_size,
               void ** key_dst_data, UInt16 * key_dst_size)
{
    UInt16 volRefNum;
    UInt32 volIterator = 0;
    FileRef dirRef;
    DataSourceChooserKey * srcKey = (DataSourceChooserKey *) key_src_data;
    VFSChooserKey * dstKey;
    LocalID dbID;
    Char pathFile[255];
    Err err;

    if (!DeviceSupportVFS())
        return dmErrCantOpen;

    if (key_src_size != sizeof(DataSourceChooserKey))
        return dmErrCantOpen;
    
    dbID = DmFindDatabase(srcKey->cardNo, srcKey->name);
    if (!dbID)
        return DmGetLastErr();

    if ((err = VFSVolumeEnumerate(&volRefNum, &volIterator)) == errNone) {
        if (!(dirRef = OpenDBDirectory(volRefNum)))
            return dmErrCantOpen;
        VFSFileClose( dirRef);
        PathCopy( pathFile, srcKey->name);

        VFSFileDelete(volRefNum, pathFile);
        VFSExportDatabaseToFile(volRefNum, pathFile, srcKey->cardNo, dbID);
        DmDeleteDatabase(srcKey->cardNo, dbID);

        dstKey = (VFSChooserKey *) AllocateMemPtr(sizeof(VFSChooserKey));
        MemSet(dstKey, sizeof(VFSChooserKey), 0);
        StrNCopy(dstKey->name, pathFile, sizeof(pathFile));
        dstKey->volRefNum = volRefNum;

        *key_dst_data = dstKey;
        *key_dst_size = sizeof(*dstKey);

    } else {
        *key_dst_data = NULL;
        *key_dst_size = 0;
    }
    return err;
}

Boolean
DeviceSupportVFS()
{
    UInt32 version;

    if (FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &version) == 0) {
//        if (version == 1) {
            return true;
//        }
    }
    return false;
}
