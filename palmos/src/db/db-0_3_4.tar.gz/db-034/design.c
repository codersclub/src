/*
 * DB Database Design Form
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 * Copyright (C) 2002-2003 by Chalain Marc (maarc-chalain@voila.fr)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

/*
 * The design form is activated from two different contexts in the
 * program. The first context is when creating a new data source. In
 * this case. the following hold:
 *
 *   CurrentSource == NULL
 *   DesignViewDriver points at the data source driver to use
 *   DesignViewInitialSchema:
 *     NULL for blank schema 
 *     points at schema to fill the form with (freed when form closes)
 *   DesignViewName points at the name to use (freed when form closes)
 *
 * The second context is when an existing data source's schema is
 * being viewed or modified. In this case, the following hold:
 *
 *   CurrentSource points at the open data source
 *   DesignViewDriver == CurrentSource->driver
 *   DesignViewInitialSchema == NULL (ignored by code)
 *   DesignViewName == NULL (ignored by code)
 *
 * The difference between the modes can be determined based on the
 * state of the CurrentSource variable.
 */

#include <PalmOS.h>
#include <FloatMgr.h>	// Include Floating Point headers

#include "db.h"
//db.h must be included before to use the defines
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif

#include "enum.h"
#include "util.h"
#include "double.h"
#include "design.h"
#ifdef CONFIG_SCRIPTS
#include "calcvalue.h"
#endif
#include "prefs.h"


#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))

#define col_popup   0
#define col_oldname 1
#define col_name    2
#define col_type    3

static UInt16 FirstField;
static MemHandle SchemaFieldsHandle = 0;
static Char *FieldString;
//this variable are used in script.c it's not a static.
SchemaDesignField * SchemaFields = 0;
UInt16 NumFields = 0;
static UInt32 NextUniqueID = 0;
static char ** popup_strings = 0;
static UInt16 popup_strings_count = 0;

static struct types_t {
    DataSourceFieldType type;
    UInt16 nameID;
    Int16 index;
} types[] = {
    { FIELD_TYPE_STRING,  stringID_String,  -1 },
    { FIELD_TYPE_NOTE,    stringID_Note,    -1 },
    { FIELD_TYPE_BOOLEAN, stringID_Boolean, -1 },
    { FIELD_TYPE_INTEGER, stringID_Integer, -1 },
    { FIELD_TYPE_FLOAT,   stringID_Float,   -1 },
#ifdef CONFIG_SCRIPTS
    { FIELD_TYPE_CALCULATED, stringID_Calculated, -1 },
#endif
    { FIELD_TYPE_DATE,    stringID_Date,    -1 },
    { FIELD_TYPE_TIME,    stringID_Time,    -1 },
    { FIELD_TYPE_LIST,    stringID_List,    -1 },
    { FIELD_TYPE_LINK,    stringID_Link,    -1 },
    { FIELD_TYPE_LINKED,  stringID_Linked,  -1 },
    { 0 , 0, -1},
};

/* Global variables to allow other portions of the DB code to tell
 * this form if a blank schema should be used or if there is some
 * initial schema that should be used to fill the display.
 */

DataSourceSchema *DesignViewInitialSchema = 0;
DataSourceDriver *DesignViewDriver = 0;
char *DesignViewName = 0;

static void DrawPopupIndicator(void *, Int16, Int16, RectangleType *) SECT_UI;
static void UpdateScrollers(void) SECT_UI;
static Err LoadData(void *, Int16, Int16, Boolean, MemHandle *, Int16 *,
                    Int16 *, FieldPtr) SECT_UI;
static Boolean SaveData(void *, Int16, Int16) SECT_UI;
static void LoadTable(TablePtr) SECT_UI;
static void SetColumnWidths(TablePtr) SECT_UI;
static void InitTable(TablePtr) SECT_UI;
static void Scroll(WinDirectionType) SECT_UI;
static UInt32 * CopyLocalSchema(DataSourceSchema * dst,
                     SchemaDesignField * src, UInt16 numFields) SECT_UI;
static Boolean UpdateNewDesign(void) SECT_UI;
static Boolean UpdateExistingDesign(void) SECT_UI;
static void InsertField(UInt16) SECT_UI;
static void DeleteField(UInt16) SECT_UI;
static void HandleContextMenu(FormType *, TableType *, Int16) SECT_UI;
static void ShowFieldProperties(UInt16 whichField) SECT_UI;
static Boolean DesignViewUpdateForm(FormPtr form, UInt16 type) SECT_UI;

static void
DrawPopupIndicator(void * table, Int16 row, Int16 col, RectangleType *b)
{
    Coord x, y, width;
 
    width = 8;
    x = b->topLeft.x + 1;
    y = b->topLeft.y + (TblGetRowHeight(table, row) - (width / 2)) / 2;

    while (width > 0) {
        WinDrawLine(x, y, x + width - 1, y);
        x += 1;
        y += 1;
        width -= 2;
    }

} 

static void
UpdateScrollers(void)
{
    UInt16 upIndex, downIndex, fieldNum;
    Boolean scrollUp, scrollDown;
    Int16 row;
    FormPtr form;
    TablePtr table;

    scrollUp = FirstField != 0 && NumFields > 0;

    form = FrmGetActiveForm();
    table = GetObjectPtr(form, ctlID_DesignView_Table);
    row = TblGetLastUsableRow(table);
    if (row != -1 && row != 0) {
        fieldNum = TblGetRowID(table, row);
        scrollDown = fieldNum < NumFields - 1;
    } else {
        scrollDown = false;
    }

    upIndex = FrmGetObjectIndex(form, ctlID_DesignView_UpButton);
    downIndex = FrmGetObjectIndex(form, ctlID_DesignView_DownButton);
    FrmUpdateScrollers(form, upIndex, downIndex, scrollUp, scrollDown);
}

static Err
LoadData(void * table, Int16 row, Int16 column,
         Boolean editing, MemHandle * textH, Int16 * textOffset,
         Int16 * textAllocSize, FieldPtr fld)
{
    UInt16 fieldNum = TblGetRowID(table, row);

    *textH = SchemaFields[fieldNum].name;
    *textOffset = 0;
    *textAllocSize = MemHandleSize(SchemaFields[fieldNum].name);
    if (fld) {
        FieldAttrType attr;

        FldGetAttributes(fld, &attr);
        attr.singleLine = 1;
        attr.dynamicSize = 0;
        attr.underlined = 1;
        FldSetAttributes(fld, &attr);
        
        FldSetMaxChars(fld, 31);
    }

    return 0;
}           

static Boolean
SaveData(void * table, Int16 row, Int16 col)
{
    return false;
}

static void
LoadTable(TablePtr table)
{
    UInt16 numRows, row, fieldNum, i;
    ListPtr list;
    FormPtr form;
    form = FrmGetActiveForm();
    list = GetObjectPtr(form, ctlID_DesignView_PopupList);

#ifdef CONFIG_HANDERA
    if (FeatureSetHandera) {
        VgaTableUseBaseFont(table, !VgaIsVgaFont(DBPrefs.TheStdFont));
    }
#endif

    numRows = TblGetNumberOfRows(table);
    fieldNum = FirstField;
    for (row = 0; row < numRows; row++) {
        /* Stop the loop if no more fields are available. */
        if (fieldNum >= NumFields)
            break;

        /* Mark the row as usable. */
        TblSetRowUsable(table, row, true);
        TblSetRowHeight(table, row, FntLineHeight());
        TblSetRowID(table, row, fieldNum);
        TblSetRowData(table, row, SchemaFields[fieldNum].uniqueID);
        TblSetRowSelectable(table, row, true);
        TblMarkRowInvalid(table, row);

        /* popup indicator */
        TblSetItemStyle(table, row, col_popup, customTableItem);
            
        /* old name */
        TblSetItemStyle(table, row, col_oldname, labelTableItem);
        TblSetItemPtr(table, row, col_oldname,
                          SchemaFields[fieldNum].old_name);

        /* current name */
        TblSetItemStyle(table, row, col_name, textTableItem);

        /* field type */
        TblSetItemStyle(table, row, col_type, popupTriggerTableItem);
        TblSetItemPtr(table, row, col_type, list);
        i = 0;
        while (types[i].type != 0) {
            if (types[i].type == SchemaFields[fieldNum].type) {
                TblSetItemInt(table, row, col_type, types[i].index);
                break;
            }
            i++;
        }

        /* Advance the field number. */
        fieldNum++;
    }

    /* Mark the remainder of the rows as unusable. */
    while (row < numRows) {
        TblSetRowUsable(table, row, false);
        row++;
    }

    /* Update the scroll arrows. */
    UpdateScrollers();
}

static void
SetColumnWidths(TableType* table)
{
    Coord oldname_width, fieldtype_width;
    Int16 i, w;
    RectangleType bounds;
    FormPtr form;
    ListPtr lst;
    UInt16 lstIndex;

    oldname_width = FntCharsWidth(FieldString, StrLen(FieldString))+ FntCharsWidth(" XX:", 1);

    /* Determine and set the width of the field type column. */
    fieldtype_width = 0;
    for (i = 0; i < popup_strings_count; ++i) {
        w = FntCharsWidth(popup_strings[i], StrLen(popup_strings[i]));
        if (w > fieldtype_width)
            fieldtype_width = w;
    }

    /* The width of the field entry column is the remaining width. */
    TblGetBounds(table, &bounds);
    TblSetColumnWidth(table, col_popup, 10);
    /*on some OS a line appear after the col_popup when the line is deselected without this line*/
    TblSetColumnSpacing(table, col_popup, 0);
    TblSetColumnWidth(table, col_oldname, oldname_width);
    TblSetColumnWidth(table, col_type, fieldtype_width + 15);
    TblSetColumnWidth(table, col_name, bounds.extent.x - 10 - oldname_width
                      - (fieldtype_width + 15));

    form = FrmGetActiveForm();
    lstIndex = FrmGetObjectIndex(form, ctlID_DesignView_PopupList);
    lst = FrmGetObjectPtr(form, lstIndex);

    LstSetListChoices(lst, popup_strings, popup_strings_count);
    LstSetHeight(lst, popup_strings_count);

    FrmGetObjectBounds(form, lstIndex, &bounds);
    bounds.extent.x = fieldtype_width + 10;
    FrmSetObjectBounds(form, lstIndex, &bounds);
}

static void
InitTable(TablePtr table)
{
    UInt16 row, numRows;

    numRows = TblGetNumberOfRows(table);
    for (row = 0; row < numRows; row++) {
        TblSetRowUsable(table, row, false);
    }

    TblSetColumnUsable(table, col_popup, true);
    TblSetColumnUsable(table, col_oldname, true);
    TblSetColumnUsable(table, col_name, true);
    TblSetColumnUsable(table, col_type, true);

    TblSetCustomDrawProcedure(table, col_popup, DrawPopupIndicator);
    TblSetLoadDataProcedure(table, col_name, LoadData);
    TblSetSaveDataProcedure(table, col_name, SaveData);

    SetColumnWidths(table);

    LoadTable(table);
}

static void
Scroll(WinDirectionType direction)
{
    UInt16 newFirstField;

    newFirstField = FirstField;

    if (direction == winDown) {
        newFirstField++;
    } else {
        newFirstField--;
    }

    if (FirstField != newFirstField) {
        FormPtr form;
        TablePtr table;

        FirstField = newFirstField;

        form = FrmGetActiveForm();
        table = GetObjectPtr(form, ctlID_DesignView_Table);
        LoadTable(table);
        TblRedrawTable(table);
    }
}

static UInt32 *
CopyLocalSchema(DataSourceSchema * dst, SchemaDesignField * src, UInt16 numFields)
{
    UInt32 *reorder;
    UInt16 i;

    /* Flag an error if no fields were defined. */
    if (numFields == 0) {
        FrmAlert(alertID_NoFields);
        return NULL;
    }

    /* Build a schema from the current design to pass to the data source. */
    dst->numFields = numFields;
    dst->fields = AllocateMemPtr(numFields * sizeof(DataSourceFieldInfo));
    reorder = AllocateMemPtr(numFields * sizeof(UInt32));
    for (i = 0; i < numFields; ++i) {
        dst->fields[i].name = MemHandleLock(src[i].name);
        dst->fields[i].type = src[i].type;
        dst->fields[i].lock = src[i].lock;
        MemMove( &(dst->fields[i].data), &src[i].data, sizeof(DataSourceFieldData));
        reorder[i] = src[i].uniqueID;
    }

    return reorder;
}

static Boolean
UpdateNewDesign(void)
{
    DataSourceSchema schema;
    UInt32 *reorder;
    int i, numFields;
    void * key_data = NULL;
    UInt16 key_size;
    Err err;

    /* Determine the number of fields by finding the last nonempty field. */
    if (! DesignViewInitialSchema) {
        /* Blank schema, so search for number of fields to use. */
        for (i = NumFields - 1; i >= 0; i--) {
            char * p = MemHandleLock(SchemaFields[i].name);
            Int16 len = StrLen(p);
            MemPtrUnlock(p);

            if (len > 0) break;
        }
        numFields = i + 1;
    } else {
        /* Had an initial schema so just use the current number of fields. */
        numFields = NumFields;
    }

    //CopyLocalSchema return a pointer for reorder, we don't use it here
    if( (reorder = CopyLocalSchema( &schema, SchemaFields, numFields)))
        DeallocateMemPtr(reorder);
    else
        return false;

    /* Create the database. Creation routine will display any errors. */
    err = DesignViewDriver->class_ops.Create(DesignViewName, &schema,
                                             &key_data, &key_size);

    if (err == 0) {
        Chooser_RescanDatabases();
#if 0
        Chooser_AddDatabase(DesignViewName, DesignViewDriver->sourceID,
                            key_data, key_size);
#endif
    }
    if (key_data)
        DeallocateMemPtr(key_data);
    /* Unlock and free any temporary data. */
    /* with CopyLocalSchema there is not more memory allocated than the fields*/
    for (i = 0; i < numFields; ++i) {
        MemHandleUnlock(SchemaFields[i].name);
    }
    DeallocateMemPtr( schema.fields);

    if (err == 0) 
        return true;
    else
        return false;

    return true;
}

static Boolean
UpdateExistingDesign(void)
{
    Boolean changed, rebuild, result;
    DataSourceSchema schema;
    UInt32 *reorder;
    int i;

    reorder = CopyLocalSchema( &schema, SchemaFields, NumFields);
    if (!reorder)
        return false;
    
    /* Ask the data source about the extent of the changes. */
    CurrentSource->ops.CheckUpdateSchema(CurrentSource, &schema, reorder,
                                         &changed, &rebuild);

    result = true;
    if (changed) {
        if (rebuild) {
            /* The changes require a rebuild, inform the user. */
            if (FrmAlert(alertID_RebuildRequired) == 0) {
                void *context;

                context = ShowWorkingIndicator();
                CurrentSource = RebuildDatabase(CurrentSource, &schema, reorder);
                HideWorkingIndicator(context);
            } else {
                /* User does not want to do a rebuild. Stay in design mode. */
                result = false;
            }
        } else {
            /* User made changes that the data source can handle itself. */
            CurrentSource->ops.UpdateSchema(CurrentSource, &schema, reorder);
        }
    }

    /* Free the schema that was built to pass to the data source. */
    for (i = 0; i < NumFields; ++i) {
        MemHandleUnlock(SchemaFields[i].name);
    }
    DeallocateMemPtr( schema.fields);
    DeallocateMemPtr(reorder);

    return result;
}

static void
InsertField(UInt16 WhichField)
{
    Char * str1, *p;
    UInt16 i;

    /* Allocate more space for the additional field. */
    MemHandleUnlock(SchemaFieldsHandle);
    MemHandleResize(SchemaFieldsHandle,
                    (NumFields + 1) * sizeof(SchemaDesignField));
    SchemaFields = MemHandleLock(SchemaFieldsHandle);

    /* Move the fields after the insert position to the right. */
    if (WhichField < NumFields) {
        for (i = NumFields; i != WhichField; --i) {
            MemMove(&SchemaFields[i], &SchemaFields[i - 1],
                    sizeof(SchemaFields[i]));
        }
    }

    str1 = GetStringResource(stringID_New);

    SchemaFields[WhichField].name = AllocateMemHandle(StrLen(str1) + 1);
    p = MemHandleLock(SchemaFields[WhichField].name);
    StrCopy(p, str1);
    MemPtrUnlock(p);
    SchemaFields[WhichField].uniqueID = NextUniqueID++;
    SchemaFields[WhichField].type = FIELD_TYPE_STRING;
    SchemaFields[WhichField].lock = true;
    MemSet( &SchemaFields[WhichField].data, sizeof(DataSourceFieldData), 0);
    StrPrintF(SchemaFields[WhichField].old_name, FieldString, (Int16) WhichField);

    PutStringResource(str1);

    /* Increment the number of fields in the design. */
    NumFields++;
}

static void
DeleteField(UInt16 WhichField)
{
    Int16 i;

    DeallocateMemHandle(SchemaFields[WhichField].name);
    /* Move the other fields down. */
    for (i = WhichField; i < NumFields - 1; i++) {
        MemMove(&(SchemaFields[i]), &(SchemaFields[i + 1]),
                sizeof(SchemaFields[i]));
    }
    NumFields--;

    /* Reallocate the space in the handle to remove last position. */
    MemHandleUnlock(SchemaFieldsHandle);
    MemHandleResize(SchemaFieldsHandle,
                    NumFields * sizeof(SchemaDesignField));
    SchemaFields = MemHandleLock(SchemaFieldsHandle);
}

static void
HandleContextMenu(FormType* form, TableType* table, Int16 row)
{
    ListType* list;
    UInt16 list_index;
    UInt16 selection;
    RectangleType cell_bounds, list_bounds;
 
    /* Remove any selection UI that the table control does. */
    TblUnhighlightSelection(table);
 
    /* Retrieve the popup choices list. */
    list_index = FrmGetObjectIndex(form, ctlID_DesignView_InserterList);
    list = FrmGetObjectPtr(form, list_index);
 
    /* Set the location for the popup list. */
    TblGetItemBounds(table, row, col_popup, &cell_bounds);
    FrmGetObjectBounds(form, list_index, &list_bounds);
    list_bounds.topLeft.x = cell_bounds.topLeft.x;
    list_bounds.topLeft.y = cell_bounds.topLeft.y;
    FrmSetObjectBounds(form, list_index, &list_bounds);
 
    /* Set the choices which will be presented to the user. */
    LstSetSelection(list, noListSelection);
    /* Let the user choose an action. */
    selection = LstPopupList(list);

    /* Insert or delete a column as necessary. */
    if (selection != noListSelection) {
        UInt16 entry = TblGetRowID(table, row);

        switch (selection) {
        case 0:
            InsertField(entry);
            /* Redraw the table now that we have changed the ordering. */
            LoadTable(table);
            TblRedrawTable(table);
            break;
 
        case 1:
            InsertField(entry + 1);
            /* Redraw the table now that we have changed the ordering. */
            LoadTable(table);
            TblRedrawTable(table);
            break;
 
        case 2:
            DeleteField(entry);
            /* Redraw the table now that we have changed the ordering. */
            LoadTable(table);
            TblRedrawTable(table);
            break;

        case 3:
            ShowFieldProperties(entry);
            break;
        }
 
    }
} 

static void
FillLocalSchema(void)
{
    DataSourceSchema * schema;
    Int16 i, j;
    char * p;

    /* Determine the number of fields that we will display. */
    if (CurrentSource) {
        schema = &CurrentSource->schema;
        NumFields = schema->numFields;
    } else if (DesignViewInitialSchema) {
        schema = DesignViewInitialSchema;
        NumFields = schema->numFields;
    } else {
        schema = 0;
        NumFields = CONFIG_MAX_NUM_FIELDS_FOR_NEW_DB;
    }

    /* Allocate the temporary memory space. */
    SchemaFieldsHandle = AllocateMemHandle(NumFields * sizeof(SchemaDesignField));
    SchemaFields = MemHandleLock(SchemaFieldsHandle);
    NextUniqueID = 0;

    if (schema) {
        for (i = 0; i < NumFields; i++) {
            UInt32 len = StrLen(schema->fields[i].name);
            SchemaFields[i].name = AllocateMemHandle(1 + len);
            p = MemHandleLock(SchemaFields[i].name);
            StrCopy(p, schema->fields[i].name);
            MemPtrUnlock(p);
            SchemaFields[i].uniqueID = NextUniqueID++;
            SchemaFields[i].type = schema->fields[i].type;
            SchemaFields[i].lock = schema->fields[i].lock;
            SchemaFields[i].resetData = 0;
            switch (schema->fields[i].type){
            case FIELD_TYPE_STRING:
                if (schema->fields[i].data.string.defaultValue) {
                    SchemaFields[i].data.string.defaultValue = AllocateMemPtr( 33);
                    StrNCopy( SchemaFields[i].data.string.defaultValue, 
                        schema->fields[i].data.string.defaultValue, 32);
                } else {
                    SchemaFields[i].data.string.defaultValue = NULL;
                }
            break;
            case FIELD_TYPE_INTEGER:
                SchemaFields[i].data.integer.defaultValue = schema->fields[i].data.integer.defaultValue;
                SchemaFields[i].data.integer.increment = schema->fields[i].data.integer.increment;
            break;
            case FIELD_TYPE_FLOAT:
                SchemaFields[i].data.floatNum.defaultValue = schema->fields[i].data.floatNum.defaultValue;
            break;
            case FIELD_TYPE_LIST:
            {
                UInt16 itemNum = schema->fields[i].data.list.numItems;
                SchemaFields[i].data.list.numItems = itemNum;
                SchemaFields[i].data.list.items = AllocateMemPtr( MAX_LISTITEMS * sizeof(char *));
                MemSet( SchemaFields[i].data.list.items, MAX_LISTITEMS * sizeof(char *), 0);
                SchemaFields[i].data.list.uniqID = AllocateMemPtr(MAX_LISTITEMS *sizeof(UInt16));
                MemSet( SchemaFields[i].data.list.uniqID, MAX_LISTITEMS * sizeof(UInt16), 0xFF);
                for (j = 0; j < itemNum; j++){
                    SchemaFields[i].data.list.items[j] = AllocateMemPtr( StrLen(schema->fields[i].data.list.items[j]) + 1);
                    StrCopy( SchemaFields[i].data.list.items[j], schema->fields[i].data.list.items[j]);
                    SchemaFields[i].data.list.uniqID[j] = j;
                }
            }
            break;
            case FIELD_TYPE_LINK:
                SchemaFields[i].data.link.dbID = schema->fields[i].data.link.dbID;
                SchemaFields[i].data.link.fieldNum = schema->fields[i].data.link.fieldNum;
            break;

            case FIELD_TYPE_LINKED:
                SchemaFields[i].data.linked.linkNum = schema->fields[i].data.linked.linkNum;
                SchemaFields[i].data.linked.fieldNum = schema->fields[i].data.linked.fieldNum;
            break;

#ifdef CONFIG_SCRIPTS
			case FIELD_TYPE_CALCULATED:
		    {
                MemMove( &(SchemaFields[i].data.calc), 
					   &(schema->fields[i].data.calc),
					   sizeof( CalculationData ) );
                SchemaFields[i].data.calc.scriptText = 
                DesignViewDriver->class_ops.DecompileScript(&schema->fields[i].data.calc);			  
			}
			break;
#endif

            default:
                MemMove( &(SchemaFields[i].data), &(schema->fields[i].data), sizeof(DataSourceFieldData));
            }
            SchemaFields[i].data.changed = false;
            StrPrintF(SchemaFields[i].old_name, FieldString, i);
        }
    } else {
        for (i = 0; i < NumFields; i++) {
            SchemaFields[i].name = AllocateMemHandle(33);
            p = MemHandleLock(SchemaFields[i].name);
            MemSet(p, 32, 0);
            MemPtrUnlock(p);
            SchemaFields[i].uniqueID = NextUniqueID++;
            SchemaFields[i].type = FIELD_TYPE_STRING;
            StrPrintF(SchemaFields[i].old_name, FieldString, i);
            MemSet( &SchemaFields[i].data, sizeof(DataSourceFieldData), 0);
        }
    }
}

static void
ClearLocalSchema(void)
{
    Int16 i, j;

    for (i = 0; i < NumFields; i++) {
        switch (SchemaFields[i].type){
        case FIELD_TYPE_STRING:
            if (SchemaFields[i].data.string.defaultValue)
                DeallocateMemPtr( SchemaFields[i].data.string.defaultValue);
        break;
        case FIELD_TYPE_INTEGER:
        break;            
        case FIELD_TYPE_LIST:
        {
            if (SchemaFields[i].data.list.items) {
                for (j = 0; j < SchemaFields[i].data.list.numItems; j++){
                    if (SchemaFields[i].data.list.items[j])
                        DeallocateMemPtr(SchemaFields[i].data.list.items[j]);
                }

                DeallocateMemPtr(SchemaFields[i].data.list.items);
            }
            if (SchemaFields[i].data.list.uniqID)
                 DeallocateMemPtr(SchemaFields[i].data.list.uniqID);
        }
        break;
#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
          {
            if (SchemaFields[i].data.calc.scriptText) {
			  DeallocateMemHandle(SchemaFields[i].data.calc.scriptText);
			  SchemaFields[i].data.calc.scriptText = NULL;
			}
          }
        break;
#endif
        default:
        }
        DeallocateMemHandle(SchemaFields[i].name);
    }
    MemHandleUnlock(SchemaFieldsHandle);
    DeallocateMemHandle(SchemaFieldsHandle);
    SchemaFields = 0;
    SchemaFieldsHandle = 0;
}

static void
SetupPopupList(void)
{
    UInt16 i, index;

    /* Count the number of valid field types. */
    popup_strings_count = 0;
    i = 0;
    while (types[i].type != 0) {
        if (DesignViewDriver->class_ops.SupportsFieldType(types[i].type))
            popup_strings_count++;
        i++;
    }

    /* Allocate space for the popup list strings. */
    popup_strings = AllocateMemPtr(popup_strings_count * sizeof(char *));

    /* Fill in the popup list strings. */
    i = index = 0;
    while (types[i].type != 0) {
        if (DesignViewDriver->class_ops.SupportsFieldType(types[i].type)) {
            /* Copy the field type name string into place. */
            popup_strings[index] = CopyStringResource(types[i].nameID);
    
            /* Advance the index inside the popup_strings array. */
            types[i].index = index;
            index++;
        } else {
            types[i].index = -1;
        }
        i++;
    }
}

static Boolean
DesignViewUpdateForm(FormPtr form, UInt16 type)
{
    TablePtr table;
#ifdef CONFIG_HANDERA
    UInt16 objectID1[] = {  ctlID_DesignView_DoneButton,
                ctlID_DesignView_CancelButton,
                0};
    UInt16 objectID2[] = {  ctlID_DesignView_UpButton,
                ctlID_DesignView_DownButton,
                0};
    UInt16 objectID3[] = {  0};
#endif

#ifdef CONFIG_HANDERA
    UtilResizeForm(form, objectID1, objectID2, objectID3, ctlID_DesignView_Table, true);
#endif
    if (type == 0) {
        /* Initialize the table that holds the design information. */
        table = GetObjectPtr(form, ctlID_DesignView_Table);
        InitTable(table);
    }

    /* Draw the form with field #1 appearing at the top. */
    FrmDrawForm(form);
    return true;
}

Boolean
DesignViewHandleEvent(EventPtr event)
{
    FormPtr form;
    FieldPtr fld;
    TablePtr table;
    Char * name;
    UInt16 i;

    switch (event->eType) {
    case frmOpenEvent:
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
        }
#endif
        FieldString = GetStringResource(stringID_Field);

        /* Initialize the working copy of the schema. */
        FillLocalSchema();
    
        /* Setup the popup list used for data types. */
        SetupPopupList();
    
        /* Set the title of depending on what mode we are in. */
        if (CurrentSource) {
            name = GetStringResource(stringID_DatabaseDesign);
        }
        else
            name = GetStringResource(stringID_NewDatabase);
        FrmCopyTitle(form, name);
        PutStringResource(name);
    
        /* Initialize the table that holds the design information. */
        FirstField = 0;
        DesignViewUpdateForm(form, 0);

        return true;

    case frmCloseEvent:
        form = FrmGetActiveForm();
        /* Make sure the table no longer has focus. */
        table = GetObjectPtr(form, ctlID_DesignView_Table);
        if (TblGetCurrentField(table)) {
            TblReleaseFocus(table);
        }
    
        /* Free the local working copy of the schema. */
        if (SchemaFields) {
            ClearLocalSchema();
        }
    
        /* Free the popup list strings. */
        if (popup_strings) {
            for( i = 0; i <popup_strings_count; i++)
                if( popup_strings[i])
                    DeallocateMemPtr(popup_strings[i]);
            DeallocateMemPtr(popup_strings);
            popup_strings = 0;
            popup_strings_count = 0;
        }

        /* Free the name selected by the creation dialog. */
        if (DesignViewName) {
            DeallocateMemPtr(DesignViewName);
            DesignViewName = 0;
        }

        /* Free any initial schema. */
        if (DesignViewInitialSchema) {
            FreeSchema(DesignViewInitialSchema);
            DeallocateMemPtr(DesignViewInitialSchema);
            DesignViewInitialSchema = 0;
        }

        PutStringResource( FieldString);

        break;

    case tblSelectEvent:
            if (event->data.tblSelect.column == col_popup) {
                HandleContextMenu(FrmGetActiveForm(),
                              event->data.tblSelect.pTable,
                              event->data.tblSelect.row);
            return true;
            } else if (event->data.tblSelect.column == col_type) {
                UInt16 fieldNum, index;

                fieldNum = TblGetRowID(event->data.tblSelect.pTable,
                                   event->data.tblSelect.row);
                index = TblGetItemInt(event->data.tblSelect.pTable,
                                                event->data.tblSelect.row,
                                                    event->data.tblSelect.column);
                i = 0;
                while (types[i].type != 0) {
                    if (types[i].index >= 0 && types[i].index == index) {
                        switch( SchemaFields[fieldNum].type) {
                        case FIELD_TYPE_LIST:
                            if( SchemaFields[fieldNum].data.list.items) {
                                UInt8 j;

                                for (j = 0; j < SchemaFields[fieldNum].data.list.numItems; j++) {
                                    DeallocateMemPtr(SchemaFields[fieldNum].data.list.items[j]);
                                }
                                DeallocateMemPtr( SchemaFields[fieldNum].data.list.items);
                                SchemaFields[fieldNum].data.list.numItems = 0;
                            }
                            if (SchemaFields[fieldNum].data.list.uniqID)
                                DeallocateMemPtr(SchemaFields[fieldNum].data.list.uniqID);
                        break;
#ifdef CONFIG_SCRIPTS
                        case FIELD_TYPE_CALCULATED:
                            DeallocateMemHandle( SchemaFields[fieldNum].data.calc.scriptText );
                            SchemaFields[fieldNum].data.calc.scriptText = NULL;
                        break;                                       
#endif
                        default:
                        }
                        MemSet( &SchemaFields[fieldNum].data, sizeof(DataSourceFieldData), 0);
                        SchemaFields[fieldNum].type = types[i].type;
                        switch( types[i].type) {
                        case FIELD_TYPE_LIST:
                            if( !SchemaFields[fieldNum].data.list.items) {
                                SchemaFields[fieldNum].data.list.items = AllocateMemPtr( MAX_LISTITEMS*sizeof(char*));
                                SchemaFields[fieldNum].data.list.uniqID = AllocateMemPtr( MAX_LISTITEMS*sizeof(UInt16));
                                MemSet( SchemaFields[fieldNum].data.list.uniqID, MAX_LISTITEMS * sizeof(UInt16), 0xFF);
                                SchemaFields[fieldNum].data.list.numItems = 0;
                            }
                            ShowFieldProperties( fieldNum);
                        break;
#ifdef CONFIG_SCRIPTS
                        case FIELD_TYPE_CALCULATED:
                            SchemaFields[fieldNum].data.calc.scriptText = AllocateMemHandle( SCRIPT_TEXT_SIZE );
                            ShowFieldProperties( fieldNum);
                        break;
#endif
                        case FIELD_TYPE_LINKED:
                            SchemaFields[fieldNum].data.linked.linkNum = 0xFFFF;
                            SchemaFields[fieldNum].data.linked.fieldNum = 0;
                        case FIELD_TYPE_LINK:
                             ShowFieldProperties( fieldNum);
                        break;

                        default:
                        }
                    }
                    i++;
                }
                return true;
            } else if (event->data.tblSelect.column == col_oldname) {
                /* A tap on the label edits the field name. */
                TblReleaseFocus(event->data.tblSelect.pTable);
                TblUnhighlightSelection(event->data.tblSelect.pTable);
                TblGrabFocus(event->data.tblSelect.pTable,
                                    event->data.tblSelect.row, col_name);
                fld = TblGetCurrentField(event->data.tblSelect.pTable);
                if (fld) {
                        FldGrabFocus(fld);
                        FldMakeFullyVisible(fld);
                }
                return true;
            }
        break;

    case ctlSelectEvent:
            switch (event->data.ctlSelect.controlID) {
            case ctlID_DesignView_DoneButton:
                if (CurrentSource) {
                        /* Discard all changes in read-only mode. */
                        if (CurrentSource->openMode == dmModeReadOnly) {
                            FrmGotoForm(formID_ListView);
                            return true;
                        }

                        /* Try to implement any edits the user wants. */
                        if (! UpdateExistingDesign())
                            return true;
                } else {
                        /* Try to create the database as specified. */
                        if (! UpdateNewDesign())
                            return true;
                }

            case ctlID_DesignView_CancelButton:
                if (CurrentSource)
                        FrmGotoForm(formID_ListView);
                    else
                        FrmGotoForm(formID_Chooser);

                return true;
            }
        break;

    case ctlRepeatEvent:
            switch (event->data.ctlRepeat.controlID) {
            case ctlID_DesignView_UpButton:
                Scroll(winUp);
            break;

            case ctlID_DesignView_DownButton:
                Scroll(winDown);
            break;
            }
        break;

    case menuEvent:
            switch (event->data.menu.itemID) {
            case menuitemID_Help:
                FrmHelp(stringID_Help_DesignView);
            return true;

            default:
            return HandleCommonMenuEvent(event->data.menu.itemID);
            }
        break;

#ifdef CONFIG_HANDERA
    case displayExtentChangedEvent:
        form = FrmGetActiveForm();
        DesignViewUpdateForm(form,  1);
    break;
#endif

    default:
        break;
    }

    return false;
}

static UInt16 FieldNumProperties;
static void
ShowFieldProperties(UInt16 whichField)
{
    FieldNumProperties = whichField;
    FrmPopupForm(formID_FieldProperties);
}


Boolean
FieldPropertiesHandleEvent(EventPtr event)
{
    static char **items;
    static UInt16 *itemsID;
    static int numItems;
    static char **items2;
    static int numItems2;
    static DataSource * source;
    static UInt16 lastItemSelected;
    FormPtr form;
    ControlPtr ctl;
    FieldPtr fld;
    ListPtr lst;
    MemHandle h;
    UInt16 i;
	Char *s;
    UInt16 ListObjectsTable[] =
    {
        ctlID_FieldProperties_ItemList,
        ctlID_FieldProperties_NewItemButton,
        ctlID_FieldProperties_ItemField,
        ctlID_FieldProperties_DeleteItemButton,
        0
    };
    
    UInt16 LinkObjectsTable[] =
    {
        ctlID_FieldProperties_DatabasesList,
        ctlID_FieldProperties_FieldsList,
        ctlID_FieldProperties_KeepLinksBox,
        0
    };

    UInt16 LinkedObjectsTable[] =
    {
        ctlID_FieldProperties_LinkFieldList,
        ctlID_FieldProperties_FieldsList,
        0
    };

#ifdef CONFIG_SCRIPTS
    UInt16 CalculatedObjectsTable[] =
    {
        9001,
        ctlID_FieldProperties_ScriptField,
        ctlID_FieldProperties_HelpScriptButton,
        0
    };
#endif
    UInt16 StringObjectsTable[] =
    {
        9002,
        ctlID_FieldProperties_DefaultValueField,
        0
    };

    UInt16 IntegerObjectsTable[] =
    {
        9002,
		9003,
        ctlID_FieldProperties_DefaultValueField,
        ctlID_FieldProperties_IncrementField,
        0
    };

    UInt16 FloatObjectsTable[] =
    {
        9002,
        ctlID_FieldProperties_DefaultValueField,
        0
    };


    switch (event->eType) {
    case frmOpenEvent:
        items =  NULL;
        numItems = 0;
        itemsID = NULL;
        source = 0;
        items2 = NULL;
        numItems2 = 0;

        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
            if (!UtilCheckSizeForm(form, 0)) {
                FrmAlert(alertID_FormTooBig);
                FrmReturnToForm(0);
                return true;
            }
        }
#endif

        FrmSetTitle(form, SchemaFields[FieldNumProperties].old_name);
        ctl = GetObjectPtr(form, ctlID_FieldProperties_LockBox);
        CtlSetValue(ctl, SchemaFields[FieldNumProperties].lock);
#define ShowObject(f,id) FrmShowObject((f),FrmGetObjectIndex((f),(id)))
        switch( SchemaFields[FieldNumProperties].type) {
        case FIELD_TYPE_STRING:
            i = 0;
            while(StringObjectsTable[i] != 0) ShowObject(form, StringObjectsTable[i++]);
            fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
            h = AllocateMemHandle( 33);
            s = MemHandleLock(h);
            if (SchemaFields[FieldNumProperties].data.string.defaultValue)
                StrNCopy( s, SchemaFields[FieldNumProperties].data.string.defaultValue, 32);
            else
                s[0] = 0;
            MemHandleUnlock(h);
            FldSetTextHandle( fld, h );
        break;
        case FIELD_TYPE_INTEGER:
          {
            Int32 value = SchemaFields[FieldNumProperties].data.integer.defaultValue;
            i = 0;
            while(IntegerObjectsTable[i] != 0) ShowObject(form, IntegerObjectsTable[i++]);
            fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
            h = AllocateMemHandle( 33);
            s = MemHandleLock(h);
            MemSet(s, 32, 0);
            StrIToA(s, value);
            MemHandleUnlock(h);
            FldSetTextHandle( fld, h );
            value = (Int32)SchemaFields[FieldNumProperties].data.integer.increment;
            fld = GetObjectPtr(form, ctlID_FieldProperties_IncrementField);
            h = AllocateMemHandle( 33);
            s = MemHandleLock(h);
            MemSet(s, 32, 0);
            StrIToA(s, value);
            MemHandleUnlock(h);
            FldSetTextHandle( fld, h );
          }
        break;
        case FIELD_TYPE_FLOAT:
          {
            double fvalue = SchemaFields[FieldNumProperties].data.floatNum.defaultValue;
            i = 0;
            while(FloatObjectsTable[i] != 0) ShowObject(form, FloatObjectsTable[i++]);
            fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
            h = AllocateMemHandle( 33);
            s = MemHandleLock(h);
            MemSet(s, 32, 0 );
            DoublePrintValue( fvalue, s, kMaxMantissaDigits);
            MemHandleUnlock(h);
            FldSetTextHandle( fld, h );
          }
        break;
        case FIELD_TYPE_LIST:
            i = 0;
            while(ListObjectsTable[i] != 0) ShowObject(form, ListObjectsTable[i++]);
            if (!FeatureSet35){
                ((ListPtr)FrmGetObjectPtr(form,
                                        FrmGetObjectIndex(form,
                                            ctlID_FieldProperties_ItemList)))->attr.usable = true;
            }
            items = SchemaFields[FieldNumProperties].data.list.items;
            itemsID = SchemaFields[FieldNumProperties].data.list.uniqID;
            numItems = SchemaFields[FieldNumProperties].data.list.numItems;
            lastItemSelected = -1;
        break;
        case FIELD_TYPE_LINK:
        {
            UInt16 databaseRecord = dmMaxRecordIndex;
            UInt16 i;

            i = 0;
            while(LinkObjectsTable[i] != 0) ShowObject(form, LinkObjectsTable[i++]);
            //correct a bug from PalmOS 3.0 to 3.2
            if (!FeatureSet35) {
                ((ListPtr)FrmGetObjectPtr(form,
                                        FrmGetObjectIndex(form,
                                            ctlID_FieldProperties_DatabasesList)))->attr.usable = true;
                ((ListPtr)FrmGetObjectPtr(form,
                                        FrmGetObjectIndex(form,
                                            ctlID_FieldProperties_FieldsList)))->attr.usable = true;
            }
            Chooser_Open();
            while (Chooser_Seek( &databaseRecord, 1, dmSeekBackward)) numItems++;
            if (databaseRecord != dmMaxRecordIndex) numItems++;
            items = AllocateMemPtr( numItems * sizeof( char *));
            databaseRecord = 0;
            for (i = 0; i < numItems; i++) {
                ChooserRecord * rec;
                MemHandle h;

                if (!Chooser_Seek( &databaseRecord, 0, dmSeekForward))
                    break;
                h = DmQueryRecord(Chooser_Ref(), databaseRecord);
                rec = MemHandleLock(h);
                items[i] = AllocateMemPtr( 33);
                StrCopy(items[i], rec->title);
                MemHandleUnlock(h);
                databaseRecord++;
            }
            lst = GetObjectPtr(form, ctlID_FieldProperties_DatabasesList);
            LstSetListChoices( lst, items, numItems);
            LstSetSelection( lst, noListSelection);
        }
        break;
        case FIELD_TYPE_LINKED:
        {
            UInt16 i, j;
            char *p;

            i = 0;
            while(LinkedObjectsTable[i] != 0) ShowObject(form, LinkedObjectsTable[i++]);
            //correct a bug from PalmOS 3.0 to 3.2
            if (!FeatureSet35) {
                ((ListPtr)FrmGetObjectPtr(form,
                                        FrmGetObjectIndex(form,
                                            ctlID_FieldProperties_LinkFieldList)))->attr.usable = true;
                ((ListPtr)FrmGetObjectPtr(form,
                                        FrmGetObjectIndex(form,
                                            ctlID_FieldProperties_FieldsList)))->attr.usable = true;
            }

            for (i = 0; i < FieldNumProperties; i++)
                if (SchemaFields[i].type == FIELD_TYPE_LINK)
                    numItems++;
            if (!numItems) {
                FrmAlert(alertID_CreateLinkField);
                break;
            }
            items = AllocateMemPtr( numItems * sizeof( char *));
            for (i = 0, j = 0; i < FieldNumProperties; i++) {
                if (SchemaFields[i].type == FIELD_TYPE_LINK) {
                    items[j] = AllocateMemPtr(33);
                    p = MemHandleLock(SchemaFields[i].name);
                    StrNCopy(items[j++], p, 32);
                    MemPtrUnlock(p);
                }
            }
            lst = GetObjectPtr(form, ctlID_FieldProperties_LinkFieldList);
            LstSetListChoices( lst, items, numItems);
            LstSetSelection( lst, noListSelection);
            Chooser_Open();
        }
        break;
#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
        {
            fld = GetObjectPtr(form, ctlID_FieldProperties_ScriptField);
            h = FldGetTextHandle( fld );
            FldSetTextHandle( fld, SchemaFields[FieldNumProperties].data.calc.scriptText );
            if ( h ) DeallocateMemHandle( h );

            i = 0;
            while(CalculatedObjectsTable[i] != 0) ShowObject(form, CalculatedObjectsTable[i++]);
        }
        break;
#endif
        default:
        }
#undef ShowObject
        FrmDrawForm(form);
        FrmUpdateForm(formID_FieldProperties, 0);
    return true;
    case frmCloseEvent:
    goto close_propertiesbox;
    case frmUpdateEvent:
        form = FrmGetActiveForm();
        switch( SchemaFields[FieldNumProperties].type) {
        case FIELD_TYPE_LIST:
            lst = GetObjectPtr(form, ctlID_FieldProperties_ItemList);
            LstSetListChoices( lst, items, numItems);
            LstSetTopItem( lst, event->data.frmUpdate.updateCode);
            LstSetSelection( lst, -1);
            LstDrawList(lst);
        break;
        default:
        }
    return true;
    case lstSelectEvent:
        switch (event->data.lstSelect.listID) {
        case ctlID_FieldProperties_DatabasesList:
          {
            UInt16 i;
            ChooserRecord * record;

            h = DmQueryRecord(Chooser_Ref(), event->data.lstSelect.selection);

            record = MemHandleLock(h);

            if (source)
                CloseDataSource( source);

            source = OpenDataSource(DriverList, dmModeReadOnly,
                                    record->sourceID,
                                    (void *) (record + 1),
                                    MemHandleSize(h) -
                                    sizeof(ChooserRecord));
            MemHandleUnlock(h);

            if (!source)
                break;

            numItems2 = source->schema.numFields;
            items2 = AllocateMemPtr( numItems2 * sizeof( char *));

            for( i = 0; i < numItems2; i++) {
                    items2[i] = source->schema.fields[i].name;
            }
            form = FrmGetActiveForm();
            lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
            LstSetListChoices( lst, items2, numItems2);
            LstSetSelection( lst, noListSelection);
            LstDrawList(lst);
          }
        return true;
        case ctlID_FieldProperties_LinkFieldList:
          {
            UInt16 i, index;
            ChooserRecord * record;
            int j = 0;
            i = 0;

            while (i < FieldNumProperties)
                if (SchemaFields[i++].type == FIELD_TYPE_LINK && event->data.lstSelect.selection == j++)
                    break;

            if (DmFindRecordByID(Chooser_Ref(), SchemaFields[i-1].data.link.dbID, &index)){
                return true;
            }

            h = DmQueryRecord(Chooser_Ref(), index);

            record = MemHandleLock(h);

            if (source)
                CloseDataSource( source);

            source = OpenDataSource(DriverList, dmModeReadOnly,
                                    record->sourceID,
                                    (void *) (record + 1),
                                    MemHandleSize(h) -
                                    sizeof(ChooserRecord));
            MemHandleUnlock(h);

            if (!source)
                break;

            numItems2 = source->schema.numFields;
            items2 = AllocateMemPtr( numItems2 * sizeof( char *));

            for( i = 0; i < numItems2; i++) {
                    items2[i] = source->schema.fields[i].name;
            }
            form = FrmGetActiveForm();
            lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
            LstSetListChoices( lst, items2, numItems2);
            LstSetSelection( lst, noListSelection);
            LstDrawList(lst);
          }
        return true;
        case ctlID_FieldProperties_ItemList:
            form = FrmGetActiveForm();
            lst = GetObjectPtr(form, ctlID_FieldProperties_ItemList);
            if (lastItemSelected == event->data.lstSelect.selection) {
                LstSetSelection( lst, -1);
                lastItemSelected = -1;
                return true;
            }
            lastItemSelected = event->data.lstSelect.selection;
        break;
        default:
        }
    break;
    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case ctlID_FieldProperties_LockBox:
                form = FrmGetActiveForm();
                ctl = GetObjectPtr(form, ctlID_FieldProperties_LockBox);

                SchemaFields[FieldNumProperties].lock = CtlGetValue(ctl);
        return true;
        case ctlID_FieldProperties_NewItemButton:
            if (numItems > MAX_LISTITEMS-1)
			  return true;
            form = FrmGetActiveForm();
            fld = GetObjectPtr(form, ctlID_FieldProperties_ItemField);
            if (FldGetTextLength(fld)) {
                UInt16 itemNum;
                UInt16 tempoNumItems = numItems;

                if (!items) {
                    items = AllocateMemPtr(MAX_LISTITEMS*sizeof(char*));
                }

                lst = GetObjectPtr(form, ctlID_FieldProperties_ItemList);
                itemNum = LstGetSelection(lst);
                if (itemNum == noListSelection)
                    itemNum = numItems;
                while( itemNum < tempoNumItems) {
                    items[tempoNumItems] = items[tempoNumItems-1];
                    itemsID[tempoNumItems] = itemsID[tempoNumItems-1];
                    tempoNumItems--;
                }

                items[itemNum] = AllocateMemPtr(FldGetTextLength(fld) + 1);
                itemsID[itemNum] = numItems;
                StrCopy( items[itemNum], FldGetTextPtr(fld));
                numItems++;
                SchemaFields[FieldNumProperties].data.list.changed = true;

                FrmUpdateForm(formID_FieldProperties, itemNum);
                // we need this for palm os 3.1, otherwise we crash
                FldSetSelection(fld, 0, StrLen( items[itemNum] ) );
            }
        return true;
        case ctlID_FieldProperties_DeleteItemButton:
        {
            UInt16 itemNum;
            if (numItems == 0)
                    return true;
            form = FrmGetActiveForm();
            lst = GetObjectPtr(form, ctlID_FieldProperties_ItemList);
            itemNum = LstGetSelection(lst);
            if (itemNum == noListSelection)
                return true;
            DeallocateMemPtr(items[itemNum]);
            numItems--;
            if (numItems) {
                while( itemNum < numItems) {
                    items[itemNum] = items[itemNum+1];
                    itemsID[itemNum] = itemsID[itemNum+1];
                    itemNum++;
                }
                itemsID[numItems] = itemsID[numItems+1];
            } else {
                DeallocateMemPtr(items);
                items = NULL;
            }
            SchemaFields[FieldNumProperties].data.list.changed = true;

            FrmUpdateForm(formID_FieldProperties, itemNum);
        }
        return true;
        case ctlID_FieldProperties_HelpScriptButton:
            FrmHelp(stringID_Help_Script);
        return true;
        case ctlID_FieldProperties_OK:
            form = FrmGetActiveForm();
            switch( SchemaFields[FieldNumProperties].type) {
            case FIELD_TYPE_STRING:
                fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
                if (!FldGetTextLength(fld))
                    break;
                if (SchemaFields[FieldNumProperties].data.string.defaultValue)
                    DeallocateMemPtr(SchemaFields[FieldNumProperties].data.string.defaultValue);
                SchemaFields[FieldNumProperties].data.string.defaultValue = AllocateMemPtr( FldGetTextLength(fld) + 1);
                StrNCopy( SchemaFields[FieldNumProperties].data.string.defaultValue, FldGetTextPtr(fld), 32);
                if (SchemaFields[FieldNumProperties].data.string.defaultValue[0] != '\0')
                    SchemaFields[FieldNumProperties].data.link.changed = true;
            break;
            case FIELD_TYPE_INTEGER:
              {
                fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
                SchemaFields[FieldNumProperties].data.integer.defaultValue = String2Long(FldGetTextPtr(fld));
                fld = GetObjectPtr(form, ctlID_FieldProperties_IncrementField);
                SchemaFields[FieldNumProperties].data.integer.increment = (Int16)String2Long(FldGetTextPtr(fld));
                if (SchemaFields[FieldNumProperties].data.integer.defaultValue != 0 
                        || SchemaFields[FieldNumProperties].data.integer.increment != 0)
                    SchemaFields[FieldNumProperties].data.link.changed = true;
              }
            break;
            case FIELD_TYPE_FLOAT:
              {
                fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
                DoubleAToD( &SchemaFields[FieldNumProperties].data.floatNum.defaultValue, FldGetTextPtr(fld));
                if (SchemaFields[FieldNumProperties].data.integer.defaultValue != 0.0)
                    SchemaFields[FieldNumProperties].data.link.changed = true;
              }
            break;
            case FIELD_TYPE_LIST:
                SchemaFields[FieldNumProperties].data.list.numItems = numItems;
                SchemaFields[FieldNumProperties].data.list.items = items;
            break;
            case FIELD_TYPE_LINK:
            {
                UInt16  listSelection;

                form = FrmGetActiveForm();
                lst = GetObjectPtr(form, ctlID_FieldProperties_DatabasesList);
                listSelection = LstGetSelection( lst);
                if ( listSelection != noListSelection) {
                    UInt32 uniqID;
                    DmRecordInfo(Chooser_Ref(), listSelection, NULL,
                                &uniqID, NULL);
                    SchemaFields[FieldNumProperties].data.link.dbID = uniqID;
                    lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
                    listSelection = LstGetSelection( lst);
                    if (listSelection == noListSelection) listSelection = 0;
                    SchemaFields[FieldNumProperties].data.link.fieldNum = listSelection;
                    SchemaFields[FieldNumProperties].data.link.changed = true;
                } else {
                    SchemaFields[FieldNumProperties].data.link.dbID = 0;
                    SchemaFields[FieldNumProperties].data.link.fieldNum = 0;
                    SchemaFields[FieldNumProperties].data.link.changed = true;
                }
                ctl = GetObjectPtr(form, ctlID_FieldProperties_KeepLinksBox);
                SchemaFields[FieldNumProperties].resetData = CtlGetValue(ctl);
            }
            break;
            case FIELD_TYPE_LINKED:
            {
                UInt16  listSelection;

                form = FrmGetActiveForm();
                lst = GetObjectPtr(form, ctlID_FieldProperties_LinkFieldList);
                listSelection = LstGetSelection( lst);
                if ( listSelection != noListSelection) {
                    int j = 0;
                    i = 0;
                    while (i < FieldNumProperties)
                        if (SchemaFields[i++].type == FIELD_TYPE_LINK && listSelection == j++)
                            break;
 
                    SchemaFields[FieldNumProperties].data.linked.linkNum = i - 1;
                    lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
                    listSelection = LstGetSelection( lst);
                    if (listSelection == noListSelection) listSelection = 0;
                    SchemaFields[FieldNumProperties].data.linked.fieldNum = listSelection;
                    SchemaFields[FieldNumProperties].data.linked.changed = true;
                } else {
                    SchemaFields[FieldNumProperties].data.linked.linkNum = 0xFFFF;
                    SchemaFields[FieldNumProperties].data.linked.fieldNum = 0;
                    SchemaFields[FieldNumProperties].data.linked.changed = true;
                }
            }
            break;
#ifdef CONFIG_SCRIPTS
            case FIELD_TYPE_CALCULATED:
                //this function will use SchemaDesignField variable.
                if ( DesignViewDriver->class_ops.CompileScript( &SchemaFields[FieldNumProperties].data.calc, FieldNumProperties, RECORD_FIELD_WRITING_CONTEXT ) ) {
                    FldSetTextHandle( GetObjectPtr( form, ctlID_FieldProperties_ScriptField ), NULL );
                    SchemaFields[FieldNumProperties].data.changed = true;
                }
                else {
                    DeallocateMemHandle( SchemaFields[FieldNumProperties].data.calc.bytecode );
                    SchemaFields[FieldNumProperties].data.calc.bytecode = NULL;
                    return true;
                }
            break;
#endif
            default:
            }
            ctl = GetObjectPtr(form, ctlID_FieldProperties_LockBox);
            SchemaFields[FieldNumProperties].lock = CtlGetValue(ctl);
        case ctlID_FieldProperties_Cancel:
        goto close_propertiesbox;
        default:
        }
    break;
    default:
    }
    return false;
    
close_propertiesbox:
    form = FrmGetActiveForm();
    switch( SchemaFields[FieldNumProperties].type) {
    case FIELD_TYPE_INTEGER:
        fld = GetObjectPtr(form, ctlID_FieldProperties_IncrementField);
        h = FldGetTextHandle(fld);
        FldSetTextHandle( fld, NULL );
        DeallocateMemHandle( h );
    case FIELD_TYPE_STRING:
    case FIELD_TYPE_FLOAT:
        fld = GetObjectPtr(form, ctlID_FieldProperties_DefaultValueField);
        h = FldGetTextHandle(fld);
        FldSetTextHandle( fld, NULL );
        DeallocateMemHandle( h);
    break;
    case FIELD_TYPE_LINK:
      {
        UInt16 j = 0;

        lst = GetObjectPtr(form, ctlID_FieldProperties_DatabasesList);
        LstSetListChoices( lst, NULL, 0);
        while (j < numItems)
            DeallocateMemPtr( items[j++]);
        if (items)
            DeallocateMemPtr( items);
        Chooser_Close();
        if (source)
            CloseDataSource( source);
        lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
        LstSetListChoices( lst, NULL, 0);
        if (items2) {
            DeallocateMemPtr( items2);
        }
      }
    break;
    case FIELD_TYPE_LINKED:
      {
        UInt16 j = 0;

        lst = GetObjectPtr(form, ctlID_FieldProperties_LinkFieldList);
        LstSetListChoices( lst, NULL, 0);
        while (j < numItems)
            DeallocateMemPtr( items[j++]);
        if (items)
            DeallocateMemPtr( items);
        Chooser_Close();
        if (source)
            CloseDataSource( source);
        lst = GetObjectPtr(form, ctlID_FieldProperties_FieldsList);
        LstSetListChoices( lst, NULL, 0);
        if (items2) {
            DeallocateMemPtr( items2);
        }
      }
    break;
    case FIELD_TYPE_LIST:
      {
        lst = GetObjectPtr(form, ctlID_FieldProperties_ItemList);
        LstSetListChoices( lst, NULL, 0);
      }
    break;
#ifdef CONFIG_SCRIPTS
	case FIELD_TYPE_CALCULATED:			  
        fld = GetObjectPtr(form, ctlID_FieldProperties_ScriptField);
	    FldSetTextHandle(fld,NULL );
	break;
#endif
    default:
    }
    FrmReturnToForm(0);
    return true;

}

