/*
 * Database standard I/O Definitions
 * Copyright (C) 2000-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#ifndef _IO_H
#define _IO_H

#if defined(__GNUC__)
#define SECT_DRV __attribute__ ((__section__("drvsect")))
#else
#define SECT_DRV
#endif

extern Boolean DS_CheckTitle(const char* title);

extern void DS_Delete(void * key_data, UInt32 key_size);

extern void DS_Enumerate(DataSourceEnumerationFunc callback, void * arg,
			     UInt32 type, UInt32 creator, UInt16 sourceID);

extern Boolean DS_GlobalFind(DataSourceGlobalFindFunc callback,
				 Boolean continuation, FindParamsPtr params,
				 UInt32 type, UInt32 creator,
				 Err (*OpenPDB)(DataSource *, UInt16,
						UInt16, LocalID));

extern Boolean DS_IsPresent(void * key_data, UInt32 key_size,
				UInt32 ds_type, UInt32 ds_creator);

extern Boolean DS_CompareKey(void * key1_data, UInt16 key1_size,
				 void * key2_data, UInt16 key2_size);

extern Err DS_PDB_Exchange(void * key_data, UInt16 key_size);

extern UInt16 DS_GetKey(DataSource * source, void * buffer);

extern void DS_PDB_GetPDB(DataSource * source,
			  UInt16 * cardNo_ptr, LocalID * dbID_ptr);

extern void DS_PDB_GetTitle(DataSource * source, char * buf, UInt32 len);

extern void DS_PDB_SetTitle(DataSource * source, const char * title,
			    void ** key_data_ptr, UInt16 * key_size_ptr);

extern void DS_PDB_Info(DataSource * source, UInt16 * cardNo,
                LocalID * dbID, UInt32 * dbType, UInt32 * creator,
                UInt32 * numRecord, UInt32 * size);

extern int	DS_StandardSortCallback(DataSource * source,
			DataSourceGetter * getter1, void * rec1_data,
			DataSourceGetter * getter2, void * rec2_data,
			void * callback_data);

extern void	DS_PDB_Close(DataSource * source);

extern Boolean	DS_Seek(DataSource * source, UInt16 * indexP, Int16 offset, Int16 direction);

extern void	DS_DeleteRecord(DataSource * source, UInt16 index);

extern UInt32	DS_GetRecordID(DataSource * source, UInt16 index);

extern UInt16 DS_GetRecordIndex(DataSource * source, UInt32 ID);

extern void	DS_FilterRecord(DataSource * source, UInt16 index, DataSourceFilter filter);

extern void	DS_SetFilter(DataSource * source, DataSourceFilter filter, Boolean reset);

extern DataSourceFilter DS_GetCurrentFilter(DataSource * source);

extern UInt16 DS_GetNumOfViews(DataSource * source);

extern DataSourceView * DS_GetView(DataSource * source, UInt16 viewIndex);

extern void	DS_PutView(DataSource * source, UInt16 viewIndex, DataSourceView * view);

extern void	DS_CheckUpdateSchema(DataSource * source,
			DataSourceSchema * schema, UInt32* reorder,
			Boolean* changed, Boolean* rebuild);

extern Int32 DS_Getter_GetInteger(void * data, UInt16 fieldNum);
extern Boolean DS_Getter_GetBoolean(void * data, UInt16 fieldNum);
extern void DS_Getter_GetDate(void * data, UInt16 fieldNum,
		     UInt16* year, UInt8* mon, UInt8* day);
extern void DS_Getter_GetTime(void * data, UInt16 fieldNum, UInt8* hour, UInt8* minute);
extern char * DS_Getter_GetNoteTitle(void * data, UInt16 fieldNum);
extern char * DS_Getter_GetNote(void * data, UInt16 fieldNum);

/* Prototypes for the driver initialization routines. */
/* !! DB_GetSmallDriver used by Global Search must be in the main section*/
extern DataSourceDriver* DB_GetSmallDriver(void);

extern DataSourceDriver* DB_GetDriver() SECT_DRV;
#ifdef CONFIG_VFS
extern DataSourceDriver* DBvfs_GetDriver() SECT_DRV;
#endif
#ifdef CONFIG_FMT_DB2
extern DataSourceDriver* OldDB_GetDriver() SECT_DRV;
#endif
#ifdef CONFIG_FMT_MOBILEDB
extern DataSourceDriver * MobileDB_GetDriver(void) SECT_DRV;
#endif
#ifdef CONFIG_FMT_JFILE3
extern DataSourceDriver * JFile3_GetDriver(void) SECT_DRV;
#endif

#endif
