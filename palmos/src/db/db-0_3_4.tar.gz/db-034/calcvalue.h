/*
 * DB: Database Script Support
 * Copyright (C) 2002 by Scott Wallace.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */


#ifndef _CALCVALUE_H_
#define _CALCVALUE_H_

#ifdef __GNUC__
#define SECT_S __attribute__ ((__section__("scrsect")))
#else
#define SECT_S
#endif






/*  This value is used for two purposes.  It is:
 *   - the maximem length of the string representation of a calculated
 *       field no matter what type it is.
 *   - the value returned for the storage size of a calculated field if
 *       its type is either string or unknown at compile time
 *
 *  So it is important that this value is at least big enough to print
 *  out all the digits in a float, or an integer.  And big enough to store
 *  a decent number of characters.  But we don't want it too big, becuase
 *  that may mean wasted space allocated for each record.
 */
#define CV_MAX_STRING_SIZE 16


/* the maximum number of chars in the text representation of the script */
#define SCRIPT_TEXT_SIZE 50        


#define MINUTES_PER_DAY 1440L
#define MINUTES_PER_HOUR 60L



/* This enumeration is meant to be used in conjunction with
 *  the FIELD_TYPE_* found in datasource.h
 *
 * These extended field types are used to give information about the
 *  type of data stored in the CalculatedValue, or a StackValue
 *
 */
typedef enum {
  CV_FIELD_TYPE_NA = NUM_FIELD_TYPES + 1,    // the not-applicable type
  CV_FIELD_TYPE_OPERATOR,                    // an operator
  CV_FIELD_TYPE_ALLOC_STRING,
  CV_FIELD_TYPE_UNKNOWN,                     // a currently unknown type
  CV_FIELD_TYPE_BROKEN,                      // a broken result
  CV_FIELD_TYPE_CANNOT_EXE,
  CV_FIELD_TYPE_DURATION                     // a duration (days, hh:mm)
} CalculatedSpecialFieldTypes;

#define ScriptRequiresAtMost(c,a)  ( (((c)->access) & ~(a)) == 0 )
#define ScriptRequiresAtLeast(c,a) ( (((c)->access) & (a)) == (a) )

#define CV_FreeData(pCV) { if((pCV)->info == CV_FIELD_TYPE_ALLOC_STRING) \
                             DeallocateMemPtr( ((pCV)->value.s) ); }

#define SV_FreeData(pSV) { if((pSV)->info == CV_FIELD_TYPE_ALLOC_STRING) \
                             DeallocateMemPtr( ((pSV)->value.s) ); }
                         

/* This should go in the same code resource as the DB_* function in db3.c */
extern Int16 CV_GetPackedSize( CalculationData *calc ) SECT_S;  
/* !! CV_PrintValue used by Global Search must be in the main section*/
extern void CV_PrintValue(CalculatedValue *v, char *buf, Int32 len);



#endif// _CALCVALUE_H_
