/*
 * DB: Database Script Support
 * Copyright (C) 2001 by Scott Wallace.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <PalmOSGlue.h>
#include <FloatMgr.h>

#include "db.h"
#include "enum.h"
#include "design.h"
#include "script.h"
#include "double.h"
#include "io.h"
#include "util.h"





/**
 * Size history
 *                                     text    data   total  
 * ----------------------------------------------------------------------
 *  16 Nov:   base functionality       5986    140    6126 
 *  21 Nov:   ir scripts, err chking   6754    146    6900
 *  24 Nov:   minor optimizations,
 *                unused code removed  6062    146    6208
 *  25 Nov:   bytecode buffer grows    6208    146    6354
 *  26 Nov:   mutli word strings       6324    146    6470
 *  27 Nov:   field name references    6884    146    7030
 *  27 Nov:   date support             7206    146    7352
 *  27 Nov:   check for stack overflow 7280    146    7426
 *  28 Nov:   finished? date ,time sup 7474    146    7620
 *  29 Nov:   CALC & SKIP unsupported  
 *             other unknown types 
 *             become ALLOC_STRING     7840    146    7986
 *  30 Nov:   Minor optimizations      7822    146    7968

 *    Scripts are executed to calculate the value of a field using
 *  the values from zero or more other fields in the database.
 *
 *    Initially, a script is written by the user in a text form.
 *
 *    The text form is a prefix, lisp like structure composed of
 *   one of more clauses, each of which looks like this:
 *
 *   (<operator> <arg-1> ... <arg-n>)
 *
 *   this script is compiled into a bytecode which will be stored and
 *   executed later.
 *
 *    Compilation involves replacing string tokens for the bytecode
 *   representatives.  Most of this mapping is described in script.h
 *   During the first stage of compilation three thing happen:
 *    -  tokens such as '(' and ')' are replaced with bytecode equivilants
 *    -  operator names (the first word in a clause) are replaced with
 *           a bytecode id
 *    -  literal or constant arguments are translated from strings
 *           into their operative form (e.g. string, float, int )
 *
 *   During this first stage of compilation, operator bytecode ids
 *   are chosen without any knowledge of the types of arguments that will
 *   be used.  In certain cases, this may be problematic, or inefficient.
 *   Thus, a second stage of compilation processes the byte code exaclty
 *   as would occur during execution.  During this phase the exact types
 *   of the arguments will be known, and general operations (such as '+')
 *   can be specialized.  This second phase is also important because we
 *   can validate the arguments to ensure that the operations will be
 *   executed successfully.  Thus we don't have to check that we're adding
 *   numbers instead of strings each time the script is executed.
 *
 *   After compilation, bytecode is stored inside the FieldData chunk
 *   the bytecode has a maximum length which is determined at compile time
 *   but the FieldData chunk requires only the minimum necessary space.
 *
 *   During execution, the script's bytecode is grabbed from the 
 *   FieldData chunk and processed, as in second stage compilation.
 *   The only difference is that operations are executed instead of
 *   validated and specialized. 
 *
 *   Modifying the script at a later time requires decompilation of 
 *   the bytecode back into a text representation.  Again we are bounded
 *   by the size of the MemHandle that is allocated (a compile time option)
 *
 *
 *
 *
 *   Compilation should take care of most of the necessary error checking
 *   so the basic assumption is that script operations do not really need
 *   to do checking of their arguments.  However, in the case of a failure
 *   it would be a good idea to fail safe.  Fortunately, the only real
 *   danger seems be in dereferencing strings.  So functions that
 *   expect string values should make sure that StackValues are indeed
 *   string types.
 *
 *
 **************************************************************************/



/**
 *  Tokens are characters found in the text version of the script
 *  which are used to delimit words that have a special meaning, 
 *  (e.g. operators or field references)  words that are not delimited
 *  with these tokens are typically interpreted as literal constants
 */
#define ENTER_TOKEN '('
#define EXIT_TOKEN  ')'
#define FIELD_ID_REFERENCE_TOKEN   '%'
#define FIELD_NAME_REFERENCE_TOKEN '|'
#define MULTI_WORD_STRING_TOKEN '\''


/**
 *   The byte code processor works differently depending on its state
 *   possible states are identified here:
 */
#define MODE_NORMAL          0
#define MODE_ABORT           1

/** ********************************************************************
 *
 *   Operator classes
 *
 ***********************************************************************/

/**
 *   WARNING: Of course new operators can be added to the scripting
 *  sub-code, however, there are two important considerations
 *
 *  The first is to ensure that previously defined operators remain
 *  undisturbed.  This means operators should not be moved between
 *  groups, and that new operators should only be added to the END of
 *  any particular operator group enumeration.
 * 
 *  The second consideration is to ensure that the operator is
 *  placed in the appropriate enumeration.
 *
 */

/**
 * CLASS 1 OPERATIONS:
 *
 *  Occurs in the bytecode but not in the text, these correspond
 *  to Class 3 operators in the text.  They have a 16 bit operator
 *  code which includes an operator id, and an optional 8 bit argument
 */
typedef enum {
  INTEGER_ARITH_OP,
  FLOAT_ARITH_OP,
  NUM_NUM_I_OP,
  STR_STR_I_OP,
  DT_DT_I_OP,
  VOID_A_OP,
  ANY_I_OP,
  GROUP_1_SIZE
} Grp1Operations;




/**
 * CLASS 2 OPERATIONS:
 *
 * The second class of operations are those which have a one to one
 * correspondence between a symbol in the script text and an operator
 * id, these operators have a minimal 8-bit operator code
 *
 * Most operators are likely to fall into this category...
 */
typedef enum {
	AND_OP,            // operation 0
	OR_OP,
	ALL_OP,
	BRANCH_OP,
	TWO_CHOICE_OP,
	NOT_OP,
	FIELD_FROM_RECORD_OP,
	SORT_OP,
	CAST_I_OP,
	CAST_DUR_OP,       // operation 9
	GROUP_2_SIZE
} Grp2Operations;

/*
 *  Group 3, occurs in the text, but not final the bytecode they
 *  should be reduced to Group 1 oeprators after the final stages
 *  of compilation are completed.
 */
typedef enum {

  GENERIC_ADD_OP,
  GENERIC_SUBTRACT_OP,
  GENERIC_MULTIPLY_OP,
  GENERIC_DIVIDE_OP,
  LT_OPERATION,
  LE_OPERATION,
  GT_OPERATION,
  GE_OPERATION,
  EQ_OPERATION,
  SEQ_OPERATION,
  SUBSTR_OPERATION,
  RANDOM_OPERATION,
  GROUP_3_SIZE
} Grp3Operations;


/**
 * Special operation codes
 *
 * Anything that occurs here is not in an operator map and
 *  must be tested for explicitly.
 *
 */
typedef enum {
  RESERVED_OP_CODE_0,
  RESERVED_OP_CODE_1,        // reserved for later use
  RESERVED_OP_CODE_2,        // reserved for later use
  RESERVED_OP_CODE_3,        // reserved for later use
  RESERVED_OP_CODE_4,        // reserved for later use
  RESERVED_OP_CODE_5,        // reserved for later use
  RESERVED_OP_CODE_6,        // reserved for later use
  RESERVED_OP_CODE_7,        // reserved for later use
  RESERVED_OP_CODE_8,        // reserved for later use
  GROUP_4_SIZE
} Grp4Operations;


/*
 *  A typical operator is described by a UInt8 digit
 *  This digit represents the operator's group and index
 */
#define GROUP_1 0x40
#define GROUP_2 0x80
#define GROUP_3 0xc0
#define GROUP_4 0x00
#define GROUP_MASK 0xc0     // the upper 2 bits describe the group
#define OPERATOR_MASK 0x3f  // the lower 6 bits describe the index

/*   -----------------------------------------------------------------     */
/*                 End of operator enumerations                            */
/*   -----------------------------------------------------------------     */


/*
 *  This enumeration contains all the special values that
 *  may be contained in the script's compiled byte-code.
 *  This is a superset of the tokens found in the text
 *  representation and also contains values to identify 
 *  different types of constant literals that might be contained
 *  in the scripts
 */

typedef enum {
  ENTER_8_BIT = 1,
  ENTER_16_BIT,
  EXIT,
  FIELD_NAME_REFERENCE,
  FIELD_ID_REFERENCE,
  LITERAL_STRING,
  LITERAL_INTEGER,
  LITERAL_FLOAT,
  LITERAL_DATE,
  LITERAL_TIME,
  NUM_SCRIPT_TOKENS

} ScriptControlType;


/**
 *  Information from the compiled byte code is put into
 *  StackValue structures during execution.  These structures
 *  hold operator ids and arguments, and are modified to contain
 *  the results of a function call.  They are essentially a
 *  CalculatedValue structure with a little bit of added information
 */
typedef struct stack_value_struct {
  
  UInt8 info;
  UInt8 meta_info;
  FieldValueUnion value;

} StackValue;


/**
 *  Here are the types of meta info that may be used
 *  to describe a StackValue
 */
#define NUMBER_META_INFO    0x10
#define STRING_META_INFO    0x20
#define TIME_META_INFO      0x40
#define DATE_META_INFO      0x80
#define POTENTIAL_META_INFO 0x01
#define NO_META_INFO        0x00




/**  The size of the execution engine's stack 
 *   It must be big enough to hold all arguments passed to a function */
#define STACK_SIZE 10



typedef UInt8 (*processor)( StackValue *top, StackValue *res );
typedef void (*operation)( StackValue *top, StackValue *res );

typedef struct script_glb_data_struct {
  DataSource *src;
  UInt16      rf;
}  ScriptGlbData;



/*  We will store exection error codes in here... */
extern UInt8 MyErr;
extern SchemaDesignField *SchemaFields;
extern UInt16 NumFields;

/* This is a map of every operation in its string form */
static char *Grp2DecompilationMap[GROUP_2_SIZE] = {
  "and", "or", "all", "br", "?", "!", "ffr", "sort", "int", "dur" };
static char *Grp3DecompilationMap[GROUP_3_SIZE] = {
  "+", "-", "*", "/", "lt", "le", "gt", "ge", "eq", "seq", "sstr", "rand" };
static ScriptGlbData ScriptExeData = { NULL, 0 };



/**
 * Begin static  prototypes
 */


static Int8 Script_FieldNameToReference(char *name, Boolean useDSch ) SECT_S;
static Boolean Script_GetFieldValue( StackValue *top, UInt16 fieldID, 
									 DataSourceGetter *getter, void *packed ) SECT_S;
static UInt8 Script_ExecuteOp( StackValue *top, StackValue *res ) SECT_S;
static Boolean Script_SpecializeOp( StackValue *top, StackValue *res ) SECT_S;
static UInt16 Script_ProcessByteCode( UInt8 *script, processor perform, 
									void *packed, DataSourceGetter *getter,
									CalculatedValue *cv ) SECT_S;
static Boolean Script_GeneralizeOp(char *name, UInt8 **bc, UInt8 *scriptInfo) SECT_S;
static Boolean Script_CompileLiteral( char *literal, UInt8 **bytecode, 
				      Int8 space, Boolean forceToString ) SECT_S;
static Boolean IsTrue( StackValue *v ) SECT_S;




/*
 * 
 * Operation declarations.  
 *
 *  functions suffix indicates the resulting type of the CalculateValue
 *
 */

static void arith_i( StackValue *top, StackValue *res ) SECT_S;
static void arith_f( StackValue *top, StackValue *res ) SECT_S;
static void and_i( StackValue *top, StackValue *res ) SECT_S;
static void or_i( StackValue *top, StackValue *res ) SECT_S;
static void all_a( StackValue *top, StackValue *res ) SECT_S;
static void branch_a( StackValue *top, StackValue *res ) SECT_S;
static void twochoice_a ( StackValue *top, StackValue *res ) SECT_S;
static void num_num_i( StackValue *top, StackValue *res ) SECT_S;
static void dt_dt_i( StackValue *top, StackValue *res ) SECT_S;
static void str_str_i( StackValue *top, StackValue *res ) SECT_S;
static void not_i( StackValue *top, StackValue *res ) SECT_S;
static void ffr_a( StackValue *top, StackValue *res ) SECT_S;
static void sort_n( StackValue *top, StackValue *res ) SECT_S;
static void void_a( StackValue *top, StackValue *res ) SECT_S;
static void cast_i( StackValue *top, StackValue *res ) SECT_S;
static void cast_dur( StackValue *top, StackValue *res ) SECT_S;

void ScriptGetSafeScript( CalculationData *c ) {
#ifdef GLOBAL_ACCESS

  c->scriptText = AllocateMemHandle( 20 );
  StrCopy( (char *)MemHandleLock( c->scriptText ), "(all 'old script')" );
  MemHandleUnlock( c->scriptText );
  
  ScriptCompile( c, 0, RECORD_FIELD_WRITING_CONTEXT );
  DeallocateMemHandle( c->scriptText );
  c->scriptText = NULL;
#endif  
}
  
 


void ScriptRun( DataSource *src, ScriptExeContext *sec, UInt8 *bytecode,
				void *packed, DataSourceGetter *g, CalculatedValue *cv ) {
  
  UInt16 len;
  char *s;

  ScriptExeData.src = src;
  ScriptExeData.rf = sec->info.record;
  
  len = Script_ProcessByteCode( bytecode, Script_ExecuteOp, packed, g, cv ); 
  
  // we must not return a string value that references the bytecode.
  // Becuase it may be that the bytecode is unlocked before the
  // Calculated value is used.  That would be a big problem.
  if ( cv->info == FIELD_TYPE_STRING &&
	   (void *)(cv->value.s) >= (void *)(bytecode) &&
	   (void *)(cv->value.s) <= (void *)(bytecode + len) ) {
	
	s = cv->value.s;
	cv->value.s = (char *)AllocateMemPtr( StrLen( s ) + 1 );
	StrCopy( cv->value.s, s );
	cv->info = CV_FIELD_TYPE_ALLOC_STRING;
  }

}

UInt8 *ScriptRunIRFirstClause( DataSource *src, UInt8 *bytecode ) {
  UInt8 *start = bytecode;
  UInt8 *endClause;
  UInt8 endClauseTemp;
  CalculatedValue cv;

  ScriptExeData.src = src;

  endClause = start;
  while( *endClause++ != EXIT );
  endClauseTemp = *endClause;
  *endClause = '\0';
  
  Script_ProcessByteCode( start, Script_ExecuteOp, NULL, NULL, &cv );
  *endClause = endClauseTemp;
  
  return endClause;

}

#ifdef GLOBAL_ACCESS
/* Marc: for the Plugin Driver i need that you don't use global variables.
 * Is it possible?
 *
 *  Maybe, but I would probably need string constants for the compilation
 *  map.
 *  
 *  it would also be useful to have static arrays (within a function scope)
 *  but it wouldn't be critical.
 *
 *  it would mean passing another argument around each of the script functions
 *  e.g. add_f,  so that we could handle errors without using the global.
 *
 */

/**
 *
 * compileScript
 *
 * Read the string version of the script and compile into a sort of
 * byte-code...Of course, the compilation is lossless, allowing the
 * compiled script to be re-represented later as the original string.
 *
 * essentially, we will traverse the string, picking out tokens
 * once a token is encountered, we will look for the end of the
 * word or words associated with this token.  Then we will
 * temporarily modify the script, replacing the character at the
 * end of the word(s) with a '\0'.  The original char is kept in
 * the wend_temp variable.  At this point, we can do string
 * operations on the the pointer to the beginning of the token.
 * everyone is happy and we have saved copying into a buffer for
 * a number of our operations...
 *
 * Finally, in the end, we have a bytecode version of the script 
 */
UInt8
ScriptCompile( CalculationData *c, UInt16 field, ScriptExecutionContext context )
{
    Int16 level = 0;
    Int32 anInt;
    UInt8 *bc, *bytecode, *bytecode_end;
	UInt32 offset;
    char *wb, *p;
    char wend_temp;
	CalculatedValue cv;
	char *errMsg = "Unexpected End";
	char *errMsgArg = " ";
	Boolean forceString;

    p = MemHandleLock( c->scriptText );
	
	ScriptExeData.rf = field;

	/** initialize the script's header */
	c->access = NO_EXTERNAL_ACCESS;

	// sw fix, if we've previously compiled a script for this field, 
	// free the bytecode and make room for the new...
	if ( c->bytecode ) DeallocateMemHandle( c->bytecode );

    c->bytecode = AllocateMemHandle( SCRIPT_BYTECODE_SIZE );
    bytecode = MemHandleLock( c->bytecode );
	bytecode_end = bytecode + SCRIPT_BYTECODE_SIZE;
	bc = bytecode;


    do {

	  switch ( *p++ ) {
		
	  case ' ':
        break;
		
	  case ENTER_TOKEN:   
		// size of this is token plus termination is 3 or 4 no need
		// to check for space
		wb = p;		
		while( *p != ' ' && *p != EXIT_TOKEN && *p != 0 )  p++; 
		
		wend_temp = *p;
		if (wend_temp == 0) {//unexpected end of script
		  goto fail;
		}
		*p = '\0';
		// This function must also place the ENTER_? token
		if ( Script_GeneralizeOp( wb, &bc, &(c->access) ) ) {
		  errMsg = "Unknown Operator";
		  goto fail;
		}
		*p = wend_temp;
		level++;
        break;
		
	  case EXIT_TOKEN:
		// size of this token plus terminator is 2.  No need to check
		*bc++ = EXIT;
		level--;
        break;
		
	  case FIELD_NAME_REFERENCE_TOKEN:
		{
		  Int8 fv;

		  wb = p;
		  if ( *wb == MULTI_WORD_STRING_TOKEN ) {
			wb++;
			while( *p != 0 && *p != MULTI_WORD_STRING_TOKEN ) p++;
		  }
		  else {
			while( *p != ' ' && *p != EXIT_TOKEN && *p != 0 ) p++;
		  }
		  wend_temp = *p;
		  if ( wend_temp == 0 ) 
			goto fail;
		  *p = '\0';
		  
		  fv = Script_FieldNameToReference( wb, true );
		  if ( fv == -1 ) {
			errMsg = "Could not resolve id:";
			errMsgArg = wb;
			goto fail;
		  }
		  *p = wend_temp;
		  if ( *p == MULTI_WORD_STRING_TOKEN ) p++;
		  *bc++ = FIELD_NAME_REFERENCE;
		  *bc++ = (UInt8)fv;
		  c->access |= SINGLE_RECORD_READING | FIELD_READING;
		  break;
		}
	  case FIELD_ID_REFERENCE_TOKEN:
		// size of this token plus null terminator is 3 no need to check
		wb = p;
		
		while( *p != ' ' && *p != EXIT_TOKEN && *p != 0 )  p++; 
		
		wend_temp = *p;
		if (wend_temp == 0) {//unexpected end of script
		  goto fail;
		}
		*p = '\0';
		if (!IsInt(wb)) {
		  errMsg = "Bad Field Reference";
		  goto fail;
		}
		anInt = StrAToI( wb );
		*p = wend_temp;
		

		/*
		 * swbug
		 *   cannot easily determine if a field id reference 
		 *   is valid.  Scripts are compiled before we really
		 *   know how many fields are defined.... here
		 *   we just assume that things will work out
		 *
		 */
		*bc++ = FIELD_ID_REFERENCE;
		*bc++ = (UInt8)anInt;
		c->access |= SINGLE_RECORD_READING | FIELD_READING;
        break;
		
		
	  default:
		// literal
		wb = p-1;
		
		if ( *wb == MULTI_WORD_STRING_TOKEN ) {
		  wb++;
		  forceString = true;
		  while( *p != 0 && *p != MULTI_WORD_STRING_TOKEN ) p++;
		}
		else {
		  forceString = false;
		  while( *p != ' ' && *p != EXIT_TOKEN && *p != 0 ) p++;
		}
		
		wend_temp = *p;
		if (wend_temp == 0) {//unexpected end of script
		  goto fail;
		}
		*p = '\0';
		
		// this only fails if the bytecode buffer gets full
		while (!Script_CompileLiteral(wb, &bc, bytecode_end-bc, forceString)) {
		  offset = (UInt32) (bc - bytecode);
		  MemHandleUnlock( c->bytecode );
		  MemHandleResize( c->bytecode, MemHandleSize( c->bytecode ) + 20 );
		  bytecode = MemHandleLock( c->bytecode );
		  bytecode_end = bytecode + MemHandleSize( c->bytecode );
		  bc = bytecode + offset;
		}
		*p = wend_temp;
		if ( *p == MULTI_WORD_STRING_TOKEN ) p++;

		break;

	  } // end of switch
	  
	  
	  // is there room for another token and
	  if ( bytecode_end - bc < 4 ) { 
		  offset = (UInt32) (bc - bytecode);
		  MemHandleUnlock( c->bytecode );
		  MemHandleResize( c->bytecode, MemHandleSize( c->bytecode ) + 20 );
		  bytecode = MemHandleLock( c->bytecode );
		  bytecode_end = bytecode + MemHandleSize( c->bytecode );
		  bc = bytecode + offset;
	  }
	  
    } while( *p );
    *bc++ = '\0';
    *bc = '\0';
	
    if (level)  // level counts open and close tokens
        goto fail;

	// we will free the bytecode in this asme procedure, and won't
	// return the calculatedValue, so there is no need to actually
	// invoke ScriptReleaseAndUnlockCV...
    Script_ProcessByteCode( bytecode, Script_SpecializeOp, NULL, NULL, &cv );
	
    c->bytecode_sz = bc - bytecode;
	c->returnType = cv.info;

	if ( cv.info == CV_FIELD_TYPE_BROKEN ) {
	  errMsg = "Bad Arguments for ";
	  errMsgArg = cv.value.s;
	  goto fail;
	}


	errMsg = "Improper IR Script";
	if ( context == RECORD_FIELD_WRITING_CONTEXT &&
		 (ScriptRequiresAtLeast( c, ARRANGING ) ||
		  ScriptRequiresAtLeast( c, MULTI_RECORD_READING ) )) {
	  
	  // make sure that the script's first clause is:
	  // a sort operation...
	  // it has no embedded clauses
	  // it does not have field references.
	  level = 0;
	  bc = bytecode;
	  do {
		switch ( *bc ) {
		case ENTER_8_BIT: 
		  level++;
		  bc++;
		  if ( level > 1 ) goto fail;      // embedded clause
		  if ( *bc != (GROUP_2 | SORT_OP) ) goto fail; // only sort allowed
		  break;
		case LITERAL_INTEGER:
		  bc += sizeof( Int32 ); // these are ok...
		  break;
		case EXIT:
		  break;
		default:
		  goto fail;
		}
	  } while( *bc != EXIT && bc++ );
	  if ( *(bc+1) != ENTER_8_BIT && *(bc+1) != ENTER_16_BIT )
		goto fail;

	  
	}

    MemHandleUnlock( c->bytecode );
    MemHandleUnlock( c->scriptText );

    return true;
fail:
    MemHandleUnlock( c->bytecode );
    MemHandleUnlock( c->scriptText );
    FrmCustomAlert(alertID_ScriptSyntaxError, errMsg, errMsgArg, " ");
    return false;
}



/**
 * Get the string representation of the script.
 */	  
MemHandle
ScriptDecompile( CalculationData *calc )
{

  
  MemHandle decompiled;
  UInt8 *p;
  char *c;
  FieldValueUnion fvu;
  UInt8 opId;


  decompiled = AllocateMemHandle( SCRIPT_TEXT_SIZE );
  c = MemHandleLock( decompiled );
  
  
  if ( calc->bytecode == NULL ) {
	*c = '\0';
	MemHandleUnlock( decompiled );
	return decompiled;
  }
  
  p = MemHandleLock( calc->bytecode );

  do {
	switch (*p++) {
	case EXIT:
	  *c++ = EXIT_TOKEN;
	  break;
	case ENTER_16_BIT:	  
	  p++; // advance
	case ENTER_8_BIT:
	  *c++ = ENTER_TOKEN;
	  opId = *p++;   // get the operator id and advance
	  if ( (opId & GROUP_MASK) == GROUP_2 ) {
		opId = opId & OPERATOR_MASK;
		StrPrintF( c, "%s ", Grp2DecompilationMap[opId] );
	  }
	  else if ( (opId & GROUP_MASK) == GROUP_1 ) {
		opId = opId & OPERATOR_MASK;
		if ( opId <= VOID_A_OP ) {
		  opId = *(p-2);  // decompMap id is actually stored in the argument
		}
		StrPrintF( c, "%s ", Grp3DecompilationMap[opId] );
	  }
	  else {
		DbgPrintF( "Cannot decompile op!" );
	  }
	  while( *c ) c++;
	  break;
	case LITERAL_FLOAT: 
	  MemMove( &fvu.d, p, sizeof( double ) );
	  DoublePrintValue( fvu.d, c, kMaxMantissaDigits );
	  p += sizeof( double );
	  while( *c ) c++;
	  *c++ = ' ';
	  break;
	case LITERAL_INTEGER:
	  MemMove( &fvu.i, p, sizeof( Int32 ) );
	  StrPrintF( c, "%ld ", fvu.i );
	  p += sizeof( Int32 );
	  while( *c ) c++;
	  break;
	case LITERAL_STRING:
	  if ( StrChr( (char *)p, (WChar)' ' ) )
		StrPrintF( c, "'%s' ", p );
	  else 
		StrPrintF( c, "%s ", p );
	  while ( *p ) p++;
	  while( *c ) c++;
	  p++;
	  break;

	case LITERAL_DATE:
	  MemMove( &fvu.ymd, p, sizeof( Date ));
	  DateToAscii( fvu.ymd.month, fvu.ymd.day, fvu.ymd.year, 
				   PrefGetPreference(prefDateFormat), c );
	  p += sizeof( Date );
	  while( *c ) c++;
	  break;

	  // for script literals, we force tfColon24h format
	case LITERAL_TIME:
	  MemMove( &fvu.t, p, sizeof( Time ) );
	  TimeToAscii( fvu.t.hour, fvu.t.min, 
				   PrefGetPreference(tfColon24h), c );
	  p += sizeof( Time );
	  while( *c ) c++;
	  break;
	
	case FIELD_NAME_REFERENCE:
	case FIELD_ID_REFERENCE:
	  StrPrintF( c,  "%%%d ", *p );
	  while( *c ) c++;
	  p++;
	  break;

	}
  } while ( *p );
  *c = '\0';
  MemHandleUnlock( decompiled );
  MemHandleUnlock( calc->bytecode );

  return decompiled;

}




/**
 *  Find the id of a field given a name or partial name
 *  Return -1 if no match is found, or more than one match is found
 */
static Int8 Script_FieldNameToReference( char *name, Boolean useDesignSchema ) {
  int i;
  char *fieldName;
  int caselessPart = -1;
  int caselessWhole = -1;
  int casedWhole = -1;
  Boolean dclp, dclw;
  
  dclp = dclw = 0;

  if ( useDesignSchema ) {
	if ( SchemaFields == NULL ) {
	  DbgPrintF( "ERROR: script.c -> FieldNameToReference" );
	  return -1;
	}
	for ( i = 0; i < NumFields; i++ ) {
	  if ( SchemaFields[i].name != NULL ) {
		fieldName = MemHandleLock( SchemaFields[i].name );
		if ( dclp || MatchString( fieldName, name, 0, 0 ) ) {
		  if ( caselessPart != -1 ) dclp = true;
		  caselessPart = i;
		  if ( dclw || MatchString( fieldName, name, 0, 1 ) ) {
			if ( caselessWhole != -1 ) dclw = true;
			caselessWhole = i;
			
			if ( MatchString( fieldName, name, 1, 1 ) ){
			  if ( casedWhole != -1 ) return -1;
			  casedWhole = i;
			}
		  }
		}
		MemHandleUnlock( SchemaFields[i].name );
	  }
	}
  }
	if ( !dclp ) return caselessPart;
	if ( !dclw ) return caselessWhole;
	return casedWhole;
  
}
#endif


/**
 *  Grab the value out of a field given its id
 *    (the field reference)
 */
static Boolean Script_GetFieldValue( StackValue *top, UInt16 fieldID,
									 DataSourceGetter *getter, void *packed ) {
/* Marc: Here, it seems impossible to have a result with a Calculated Field of another record.
 * It's really useless. It's impossible to do a recurence like:
 *  field 0: integer
 *  field 1: Calculated (sort 1 1)(+ %0 (ffr 2 -1))
 * an example it's to know the money in your bank after a transaction.
 *
 * Ok  I fixed this in my version, but I didn't send you the changes becuase
 *  I didn't want to add new features at this point.  But since you bring it
 *  up I will put in the fixes.
 *
 * (ffr ) now takes 2-3 arguments, the 3rd is a deafault value in case
 *   the record requested is not found (like would happen if you requested
 *   record -1 for the first record)
 *
 *  when you supply a third argument, it bypasses the checking invloved
 *   in this function, so the script you have above can be written as:
 *
 *  (sort 0 1)(+ %0 (ffr 1 -1 0))
 *
 *  note: (ffr 1... is not a typeo, fields are 0 indexed
 */
  static UInt8  metaInfo[NUM_FIELD_TYPES] =
  { 0x00, STRING_META_INFO, NUMBER_META_INFO,
	NUMBER_META_INFO, DATE_META_INFO, TIME_META_INFO, STRING_META_INFO,
  	STRING_META_INFO, STRING_META_INFO, NUMBER_META_INFO, 0x00 };


#ifdef GLOBAL_ACCESS
  if ( packed == NULL ) {
	if ( SchemaFields == NULL ) {
	  // this should never happen
	  DbgPrintF( "ERROR: script.c  -> GetFieldValue()" );
	  return 1;
	}
	if ( fieldID >= NumFields ) return 1;
	top->info = SchemaFields[fieldID].type;
	top->meta_info = metaInfo[top->info];


	// check for unsupported field types
	if ( (top->info == FIELD_TYPE_SKIP) ) return 1;

	if ( (top->info == FIELD_TYPE_CALCULATED) )  {
	  if ( ScriptExeData.rf <= fieldID ||
		   ScriptRequiresAtLeast( &(SchemaFields[fieldID].data.calc),
								  MULTI_RECORD_READING ) ) {
		return 1;
	  } else {
		top->info = SchemaFields[fieldID].data.calc.returnType;
		if ( top->info >= NUM_FIELD_TYPES ) return 1;
		top->meta_info = metaInfo[top->info];
		return 0;
	  }
	}


	// check for types that we don't handle as native primitives
	// we don't call these ALLOC_STRINGs becuase that is a decision
	// that is made when the field is actually accessed.
	if (((top->info > FIELD_TYPE_TIME) && (top->info <= FIELD_TYPE_LINK))) {
	  top->info = FIELD_TYPE_STRING;
	}

	return 0;
  }
#endif

  if ( fieldID >= ScriptExeData.src->schema.numFields ) return 1;
  top->info = ScriptExeData.src->schema.fields[fieldID].type;
  top->meta_info = metaInfo[top->info];

  switch ( top->info ) {
  case FIELD_TYPE_INTEGER:
	top->value.i = getter->GetInteger( packed, fieldID );
	break;
  case FIELD_TYPE_FLOAT:
	top->value.d = getter->GetFloat( packed, fieldID );
	break;
  case FIELD_TYPE_STRING:
	top->value.s = getter->GetString( packed, fieldID );
	break;
  case FIELD_TYPE_BOOLEAN:
	top->value.i = getter->GetBoolean( packed, fieldID );
	break;
  case FIELD_TYPE_DATE:
	getter->GetDate( packed, fieldID, &(top->value.ymd.year),
					 &(top->value.ymd.month), &(top->value.ymd.day));
	break;
  case FIELD_TYPE_TIME:
	getter->GetTime( packed, fieldID, &(top->value.t.hour),
					 &(top->value.t.min) );
	break;
  case FIELD_TYPE_CALCULATED:
	{
	  CalculatedValue cv;

	  getter->GetCalculated( packed, fieldID, &cv );
	  top->value = cv.value;
	  top->info = cv.info;
	  top->meta_info = metaInfo[cv.info];
	  // dont free anything data here, because we're not done with top.
	  // if for some reason we get a cv with dynamically allocated data
	  // it will be released later in ProcessByteCode
	  break;
	}
  default:
	top->value.s = (char *)AllocateMemPtr( CV_MAX_STRING_SIZE );
	top->info = CV_FIELD_TYPE_ALLOC_STRING;
	ConvertFieldToString( ScriptExeData.src, getter, packed, fieldID,
						  (top->value.s), CV_MAX_STRING_SIZE - 1 );
	break;
	
  }
  return 0;
}




 
/**
 * Operation maps
 */
static operation Grp1OperationMap[GROUP_1_SIZE] = {
	arith_i, arith_f, num_num_i, str_str_i, dt_dt_i, void_a
 };


static operation Grp2OperationMap[GROUP_2_SIZE] = {
	and_i, or_i, all_a, branch_a, twochoice_a, not_i, ffr_a, sort_n, cast_i, cast_dur
};





/**
 * Script_ExecuteOp
 *
 * look up the current operation in the map, invoke it
 * and modify the stack appropriately
 *
 * arguments:
 *       top -  points to  the top of the stack
 *        
 *       res -  a pointer to the stack location holding the operator
 *                this will be rewriten to hold the result of the
 *                operation.
 */
static UInt8
Script_ExecuteOp( StackValue *top, StackValue *res )
{
#ifdef GLOBAL_ACCESS
  MyErr = MODE_NORMAL;
#endif

  if ( (*(res->value.s) & GROUP_MASK) == GROUP_1 ) {
	if ( ((*res->value.s) & OPERATOR_MASK) >= GROUP_1_SIZE )
	  goto broken;

	Grp1OperationMap[ (*(res->value.s) & OPERATOR_MASK)]( top, res );

  }
  else if ( (*(res->value.s) & GROUP_MASK) == GROUP_2 ) {
	if ( ((*res->value.s) & OPERATOR_MASK) >= GROUP_2_SIZE )
	  goto broken;
	
	Grp2OperationMap[ (*(res->value.s) & OPERATOR_MASK)]( top, res );
  }
  else {
	goto broken;
  }  
#ifdef GLOBAL_ACCESS
  return MyErr;
#else
  return MODE_NORMAL;
#endif
 broken:
  (res-1)->info = CV_FIELD_TYPE_BROKEN;
  (res-1)->value.s = "op code";
  return MODE_ABORT;
  
}


/**
 * 
 *  Script_SpecializeOp
 *
 *  after a first pass at compilation, the bytecode is in a form that
 *  is 'mostly' complete.  However, some operations cannot be fully
 *  defined until the types of the arguments are known.  Because
 *  Script_SpecializeOp is invoked just as Script_ExecuteOp, it is
 *  given a complete argument stack including the types of each
 *  argument.  This allows another degree of compilation /AND/ error
 *  checking to take place before the script is ever executed.
 *
 *  This comes into play mainly for arthimetic functions, although
 *  many other functions profit from error checking.
 *  
 *    
*/
static Boolean
Script_SpecializeOp( StackValue *top, StackValue *res )
{
  UInt8 meta_type, info = CV_FIELD_TYPE_UNKNOWN, allSameType;
  StackValue *lastArg;


  // top is unused, go to first arg on stack
  lastArg = top + 1;
  
  if ( (*((UInt8*)res->value.s) & GROUP_MASK) == GROUP_1 ) {
	switch ( *(res->value.s) & OPERATOR_MASK ) {
	case NUM_NUM_I_OP:
	  if ( lastArg->info == FIELD_TYPE_DATE || lastArg->info == FIELD_TYPE_TIME) 
		*(res->value.s) = GROUP_1 | DT_DT_I_OP;
	  // drop through
	case STR_STR_I_OP:
	  res->meta_info = NUMBER_META_INFO;
	  res->info = FIELD_TYPE_INTEGER;
	  break;
	case VOID_A_OP:	  
	  res->meta_info = NUMBER_META_INFO;
	  res->info = FIELD_TYPE_INTEGER;	
	  break;
	}
  }
  else if ( (*(res->value.s) & GROUP_MASK) == GROUP_2 ) {
    switch( *(res->value.s) & OPERATOR_MASK ) {	  
	  
	case ALL_OP:
	  res->meta_info = lastArg->meta_info;
	  res->info = lastArg->info;
	  break;

	case BRANCH_OP:
	  res->meta_info = lastArg->meta_info;
	  allSameType = lastArg->info;
	  while( ++lastArg < (res-1) ) {
		res->meta_info |= lastArg->meta_info;
		if ( lastArg->info != allSameType ) {
		  allSameType = CV_FIELD_TYPE_UNKNOWN;
		  res->meta_info |= POTENTIAL_META_INFO;
		}
	  }
	  res->info = allSameType;
	  break;

	case TWO_CHOICE_OP:
	  res->meta_info = lastArg->meta_info;
	  res->meta_info |= (lastArg+1)->meta_info;
	  if ( lastArg->info == (lastArg+1)->info ) allSameType = lastArg->info;
	  else {
		allSameType = CV_FIELD_TYPE_UNKNOWN;
		res->meta_info |= POTENTIAL_META_INFO;
	  }
	  res->info = allSameType;
	  break;
	  
	case FIELD_FROM_RECORD_OP:

		/**
		 * ensure that the proper number of arguments are given and
		 * that the first 2 are both integers.  If there are only
		 * two arguments, then fetch the appropriate info about
		 * their type using GetFieldValue
		 */
		if ( res-lastArg < 2 || res-lastArg > 3 ||
			 (res-2)->info != FIELD_TYPE_INTEGER || 
			 (res-1)->info != FIELD_TYPE_INTEGER ||
			 ( res-lastArg == 2 && 
			   Script_GetFieldValue(res, (lastArg+1)->value.i, NULL, NULL) )) {
			
			(res-1)->value.s = Grp2DecompilationMap[ FIELD_FROM_RECORD_OP ];
			(res-1)->info = CV_FIELD_TYPE_BROKEN;
			return MODE_ABORT;
		}
		/**
		 * if a defulat value is supplied, we already know one of
		 * the possible result types.  This way we can circumvent 
		 * calling GetFieldValue and essentially create a circular
		 * reference!
		 */
		if ( res-lastArg == 3 ) {
			MemMove( res, lastArg, sizeof( StackValue ) );
			// maximally specialize the argument type to do safe
			// functions...  this only is necessary right now for numbers
			if ( res->meta_info == NUMBER_META_INFO ) 
				res->info = FIELD_TYPE_FLOAT;
		}
	  break;
	case SORT_OP:
	  if ( ((res-lastArg) % 2) != 0 || lastArg->info != FIELD_TYPE_INTEGER ||
		   (lastArg+1)->info != FIELD_TYPE_INTEGER) {
		
		(res-1)->value.s = Grp2DecompilationMap[ SORT_OP ];
		(res-1)->info = CV_FIELD_TYPE_BROKEN;
		return MODE_ABORT;
	  }
	  
	  // currently NOT_OP,  AND_OP, OR_OP, CAST_I_OP
	default:
	  res->info = FIELD_TYPE_INTEGER;
	  res->meta_info = NUMBER_META_INFO;
	  break;
	}
  }
  else if ( (*(res->value.s) & GROUP_MASK) == GROUP_3 ) {
  
    switch( *(res->value.s) & OPERATOR_MASK ) {
	case GENERIC_ADD_OP:
	case GENERIC_SUBTRACT_OP:
	case GENERIC_MULTIPLY_OP:
	case GENERIC_DIVIDE_OP:
    // validate arguments are acceptable

	  meta_type = lastArg->meta_info;
	  while( ++lastArg < res ) {
		if ( lastArg->meta_info != meta_type || meta_type != NUMBER_META_INFO ) {
		  
		  (res-1)->value.s = Grp3DecompilationMap[ *(res->value.s) & OPERATOR_MASK ];
		  (res-1)->info = CV_FIELD_TYPE_BROKEN;
		  return MODE_ABORT;
		
		}
	  }
    
	  lastArg = top + 1;
	  switch( meta_type ) {
	  case NUMBER_META_INFO:
		info = lastArg->info;
		while( ++lastArg < res ) {
		  switch ( lastArg->info ) {
		  case FIELD_TYPE_FLOAT:
			info = FIELD_TYPE_FLOAT; break;
		  }
		}
	  }
	  /*
		if we get here, the operation is valid, and we've found the 
		return type, shift the stack top to its soon to be new location...
		the stack member at op_i will be replaced with info about 
		this return type...
	  */
	  res->meta_info = meta_type;
	  res->info = info;
	  *(res->value.s) = GROUP_1 | INTEGER_ARITH_OP;
	  
	  switch( info ) {
	  case FIELD_TYPE_FLOAT:
		(*(res->value.s))++;
		break;
	  }
	  
	  break;
	}
  }
  
  if ( (res->meta_info & POTENTIAL_META_INFO) == POTENTIAL_META_INFO ) {
	if ((res->meta_info & ~POTENTIAL_META_INFO) == STRING_META_INFO ) {
	  res->meta_info = STRING_META_INFO;
	  res->info = FIELD_TYPE_STRING;
	}
	else if ((res->meta_info & ~POTENTIAL_META_INFO) == NUMBER_META_INFO ) {
	  res->meta_info = NUMBER_META_INFO;
	  res->info = FIELD_TYPE_FLOAT;
	}
  }
  return MODE_NORMAL;
}  
  




/**
 *  Script_ProcessByteCode
 *
 *  read the compiled byte code, and either specialize it, or
 *  execute it depending on the value of perform.  In either case
 *  an argument stack is built as the bytecode is read.  The 
 *  stack holds all sorts of info about the arguments and operators
 *  that is needed for validation, specialization and execution.
 */
static UInt16
Script_ProcessByteCode( UInt8 *script, processor perform,
					void *packed, 
					DataSourceGetter *getter, CalculatedValue *cv )
{

  StackValue stack[STACK_SIZE];
  StackValue *top, *op;
  UInt16 level = 0, mode = MODE_NORMAL;
  UInt8 *p = script;


  top = &stack[STACK_SIZE - 1];


  do {

	switch ( *p++ ) {

	case EXIT: 
	  level--; 
	  op = top + 1;
	  while( op->info != CV_FIELD_TYPE_OPERATOR ) op++;	  
	  mode = perform( top, op );	 


	  // free up allocated strings if they are no londer needed
	  if ( op->info != CV_FIELD_TYPE_ALLOC_STRING ) {
		while( top < op ) {
		  SV_FreeData( top );
		  top++;
		}
	  }
	  else {
		while( top < op ) {
		  if ( top->value.s != op->value.s ) SV_FreeData( top );
		  top++;
		}
	  }
		


	  top = op - 1;

	  // if we're aborting, don't adjust the top pointer
	  if ( mode == MODE_ABORT ) goto done;

	  if ( !level ) 
		top++;

	  break;
	
	case ENTER_16_BIT:
	  p++;  // drop through
	case ENTER_8_BIT:
	  level++;
	  top->info = CV_FIELD_TYPE_OPERATOR; // operator
	  top->value.s = (char *)p;
	  p++;
	  top--;
	  break;

	case LITERAL_INTEGER:
	  top->meta_info = NUMBER_META_INFO;
	  top->info = FIELD_TYPE_INTEGER;
	  MemMove( &top->value.i, p, sizeof( Int32 ) );
	  p += sizeof( Int32 );
	  top--;
	  break;

	case LITERAL_FLOAT:
	  top->meta_info = NUMBER_META_INFO;
	  top->info = FIELD_TYPE_FLOAT;
	  MemMove( &top->value.d, p, sizeof( double ) );
	  p += sizeof( double );
	  top--;
	  break;

	case LITERAL_DATE:
	  top->meta_info = DATE_META_INFO;
	  top->info = FIELD_TYPE_DATE;
	  MemMove( &top->value.ymd, p, sizeof( Date ) );
	  p += sizeof( Date );
	  top--;
	  break;

	case LITERAL_TIME:
	  top->meta_info = TIME_META_INFO;
	  top->info = FIELD_TYPE_TIME;
	  MemMove( &top->value.t, p, sizeof( Time ) );
	  p += sizeof( Time );
	  top--;
	  break;

	case LITERAL_STRING:
	  top->meta_info = STRING_META_INFO;
	  top->info = FIELD_TYPE_STRING;
	  top->value.s = (char *)p;
	  while( *p ) p++;
	  p++;
	  top--;
	  break;

	case FIELD_NAME_REFERENCE:
	case FIELD_ID_REFERENCE: 
	  if ( Script_GetFieldValue( top, (UInt16)*p, getter, packed ) ) {
		top->info = CV_FIELD_TYPE_BROKEN;
		top->value.s = "%";
		goto done;
	  }
	  p++;
	  top--;
	  break;

	} // switch ( operator id )

	if ( top - stack  < 0 ) {
	  top->info = CV_FIELD_TYPE_BROKEN;
	  top->value.s = "Overflow";
	  goto done;
	}

  } while ( *p );

 done:
  cv->info = top->info;
  cv->value = top->value;
  return (UInt16)(script - p );


}


/**
 *  Script_GeneralizeOp
 *
 *  during the first pass of compilation, operators must be chosen to
 *  map to their string counterparts without necessarily knowing the
 *  types of their arguments.  In this function, strings are replaced
 *  with generalized operators that may later be refined by the
 *  function specializeOperator once the types of their arguments are
 *  known.
 *
 *   
 */
static Boolean
Script_GeneralizeOp( char *name, UInt8 **bc, UInt8 *access )
{
  UInt16 i;
  Char * s;
  Int16 (*Compare)(const Char*, UInt16, UInt16 *,
                   const Char*, UInt16, UInt16*);

  Compare = (Int16 (*)(const Char*, UInt16, UInt16 *, const Char*, UInt16, UInt16*))
            IntlGlueGetRoutineAddress(intlTxtCompare, TxtLatinCompare);

  for ( i = 0; i < GROUP_2_SIZE; i++ ) {
  	s = Grp2DecompilationMap[i];
	if ( !Compare( name, StrLen(name), 0, s, StrLen( s), 0) ) {
	  **bc = ENTER_8_BIT;
	  (*bc)++;
	  **bc = GROUP_2 | (UInt8)i;
	  if ( i == FIELD_FROM_RECORD_OP )
		*access |= MULTI_RECORD_READING;
	  else if ( i == SORT_OP ) 
		*access |= ARRANGING;
	  (*bc)++;
	  return 0;
	}
  }
  
  for ( i = 0 ; i < GROUP_3_SIZE; i++ ) {
  	s = Grp3DecompilationMap[i];
	if ( !Compare( name, StrLen(name), 0, s, StrLen( s), 0) ) {
	  **bc = ENTER_16_BIT;
	  (*bc)++;
	  **bc = i;  // this is the argument to the operator
	  (*bc)++;
	  if ( i <= GENERIC_DIVIDE_OP ) {
		**bc = GROUP_3 | i; // needs to be specialized ... still grp 3
	  }
	  else if ( i <= EQ_OPERATION ) {
		**bc = GROUP_1 | NUM_NUM_I_OP;
	  }
	  else if ( i <= SUBSTR_OPERATION ) {
		**bc = GROUP_1 | STR_STR_I_OP;
	  }
	  else if ( i <= RANDOM_OPERATION ) {
		**bc = GROUP_1 | VOID_A_OP;
	  }
	  (*bc)++;
	  return 0;
	  
	} // is it a group 3 operation?
  } // foreach element in the group 3 map
 
  return 1;

}




static Boolean
Script_CompileLiteral( char *literal, UInt8 **bytecode, Int8 space, Boolean fString )
{
  FieldValueUnion fvu;

  space -= 6; // just about the minimum space (room for a Int32, or 3 chars)
  if ( space < 0 ) return 0;

  if ( fString ) goto force_string;


  if ( IsInt( literal ) ) { 
	// only need 6 bytes of space...
	**bytecode = (UInt8)LITERAL_INTEGER;
	(*bytecode)++;

	fvu.i = StrAToI( literal );
	MemMove( *bytecode, &fvu.i, sizeof( Int32 ));
	(*bytecode) += sizeof( Int32 );

  }
  else if ( IsFloat( literal ) ) {
	if ( space < 4 ) return 0;
	**bytecode = LITERAL_FLOAT;
	(*bytecode)++;
	DoubleAToD( &fvu.d, literal );
	MemMove( *bytecode, &fvu.d, sizeof( double ) );
	(*bytecode) += sizeof( double );
	
  }
  else if ( IsDate( literal, &fvu.ymd ) ) {
	// only need 6 bytes of space
	**bytecode = LITERAL_DATE;
	(*bytecode)++;
	// year month date
	MemMove( *bytecode, &fvu.ymd, sizeof( Date ) );
	(*bytecode) += sizeof( Date );
  }
  else if ( IsTime( literal, &fvu.t ) ) {
	**bytecode = LITERAL_TIME;
	(*bytecode)++;
	MemMove( *bytecode, &fvu.t, sizeof( Time ) );
	(*bytecode) += sizeof( Time );

  }
  else {  // default to string

  force_string:
	// the space calculation already is big enough for a 3 char string
	if ( space <  StrLen( literal ) - 2 ) return 0;
	**bytecode = LITERAL_STRING;
	while( *literal ) {
	  (*bytecode)++;
	  **bytecode = *literal++;
	}
	(*bytecode)++;
	**bytecode = '\0';
	(*bytecode)++;
  }
  return 1;

}
	

static Boolean
IsTrue( StackValue *sv ) {
  
  switch ( sv->info ) {
  case FIELD_TYPE_INTEGER: return (sv->value.i)?1:0;
  case FIELD_TYPE_FLOAT:   return (sv->value.d)?1:0;

  case CV_FIELD_TYPE_ALLOC_STRING:
  case FIELD_TYPE_STRING:  return (*sv->value.s)?1:0; 
  }
  return 0;
}



/**********************************************************************
 *
 *                         Script Operations
 *
 **********************************************************************/








/**
 *  arith_i
 *
 *  Performs a basic arthimetic operation returning an integer
 *
 *  Returns:
 *   - INTEGER whose value is the functional result of all arguments
 *
 *  Constraints:
 *    -  Arguments MUST be of type INTEGER
 *
 */
static void arith_i( StackValue *top, StackValue *res ) {
  StackValue *arg;
  Int16 opType;

  opType = *(res->value.s - 1);
  arg = res - 1;
  
  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;
  res->value.i = arg->value.i;

  while( --arg > top ) {
	if ( opType == GENERIC_ADD_OP ) res->value.i += arg->value.i;
	else if ( opType == GENERIC_SUBTRACT_OP ) res->value.i -= arg->value.i; 
	else if ( opType == GENERIC_MULTIPLY_OP ) res->value.i *= arg->value.i; 
	else if ( opType == GENERIC_DIVIDE_OP ) {
	  if ( arg->value.i == 0 ) {
#ifdef GLOBAL_ACCESS
		MyErr = MODE_ABORT;
#endif
		(res-1)->info = CV_FIELD_TYPE_BROKEN;
		break;
	  } else {
		res->value.i /= arg->value.i; 
	  }
	}
  }
  

}

/**
 *  arith_f
 *
 *  Performs a basic arithmetic operation returning a float
 *
 *  Returns:
 *   - FLOAT whose value is the functional result of all arguments
 *
 *  Constraints:
 *    -  Arguments MUST be of type INTEGER | FLOAT
 *
 */
static void arith_f( StackValue *top, StackValue *res ) {
  StackValue *arg;
  Int16 opType;
  double (*op)(double a, double b);

  opType = *(res->value.s - 1);
  arg = res - 1;

	
  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_FLOAT;


  switch ( opType ) {
  case GENERIC_SUBTRACT_OP:  op = DoubleSub; break;
  case GENERIC_MULTIPLY_OP:  op = DoubleMul; break;
  case GENERIC_DIVIDE_OP:    op = DoubleDiv; break;
  case GENERIC_ADD_OP:
  default:
	op = DoubleAdd; break;
  }

  
  switch( arg->info ) {
  case FIELD_TYPE_FLOAT:
    res->value.d = arg->value.d;
    break;
  case FIELD_TYPE_INTEGER:
    res->value.d = DoubleIToD(arg->value.i);
    break;
  }

  while( --arg > top ) {
	switch( arg->info ) {
	case FIELD_TYPE_FLOAT:
	  res->value.d = op( res->value.d, arg->value.d );  
		break;
	  case FIELD_TYPE_INTEGER: 
		res->value.d = op( res->value.d, DoubleIToD(arg->value.i) );
		break;
	  }
	}


  
}

/**
 *  and_i
 *
 *  returns 1 if all arguments are true (non-nill)
 *  returns 0 otherwise.
 *
 *  Constraints:
 *    -  none
 *
 */
static void and_i( StackValue *top, StackValue *res ) {
  
  StackValue *arg = top;

  res->info = FIELD_TYPE_INTEGER;
  res->meta_info = NUMBER_META_INFO;

  while( ++arg < res ) {
	if ( !IsTrue( arg ) ) {
	  res->value.i = 0;
	  return;
	}
  }
  res->value.i = 1;
  return;
}


/**
 *  all_a
 *
 *  returns the value of the last argument
 *
 *  Returns:
 *   - the last argument
 *
 *  Constraints:
 *    -  none
 *
 */
static void or_i( StackValue *top, StackValue *res ) {
  
  StackValue *arg;

  arg = top;
  res->info = FIELD_TYPE_INTEGER;
  res->meta_info = NUMBER_META_INFO;
  while( ++arg < res ) {
	if ( IsTrue( arg ) ) {
	  res->value.i = 1;
	  return;
	}
  }
  res->value.i = 0;
  return;
}



/**
 *  all_a
 *
 *  returns the value of the last argument
 *
 *  Returns:
 *   - the last argument
 *
 *  Constraints:
 *    -  none
 *
 */
static void all_a( StackValue *top, StackValue *res ) {
  
  MemMove( res, top+1, sizeof( StackValue ) );

}




/**
 *  branch_a
 *
 *  Takes >= 2 arguments.  The first argument will be refered to as
 *    the branching value, the remained are considered a list numbered
 *    from 0...n
 *
 *  Returns:
 *   - the (n)st argument where n is the branching value
 *      if n is out of bounds the first or last element is the branch
 *      list is returned
 *
 *  Constraints:
 *    -  0th argument must be an INTEGER
 *
 */
static void branch_a( StackValue *top, StackValue *res ) {
  int switch_i;
  StackValue *arg;

  switch_i = (res - 1)->value.i;
  arg = top + 3;
  if ( switch_i < 0 ) switch_i = 0;
  else if ( switch_i > res - arg ) switch_i = res - arg;

  *res = *(res - switch_i - 2);
  

}


static void twochoice_a ( StackValue *top, StackValue *res ) {
  
  if ( IsTrue( res - 1 ) ) *res = *(res - 2);
  else *res = *(res - 3);

}


static void num_num_i( StackValue *top, StackValue *res ) {

  double d[2];
  int i;
  int function = *(res->value.s - 1);  // its a 16 bit operation code
  StackValue *arg;

  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;

  arg = res - 1;  // skip to 
  for( i = 0; i < 2 ; i++, arg-- ) {
	
	switch ( arg->info ) {
	case FIELD_TYPE_INTEGER: d[i] = DoubleIToD( arg->value.i ); break;
	case FIELD_TYPE_FLOAT:   d[i] = arg->value.d; break;
	}
  }
  switch( function ) {

  case GT_OPERATION:  res->value.i = ( d[0] > d[1] ) ? 1 : 0; break;
  case LT_OPERATION:  res->value.i = ( d[0] < d[1] ) ? 1 : 0; break;
  case GE_OPERATION:  res->value.i = ( d[0] >= d[1] ) ? 1 : 0; break;
  case LE_OPERATION:  res->value.i = ( d[0] <= d[1] ) ? 1 : 0; break;
  case EQ_OPERATION:  res->value.i = ( d[0] == d[1] ) ? 1 : 0; break;
  default: res->value.i = -4000;
  }


}


static void dt_dt_i( StackValue *top, StackValue *res ) {

  UInt32 ui[2];
  int i;
  int function = *(res->value.s - 1);  // its a 16 bit operation code
  StackValue *arg;

  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;

  arg = res - 1;  // skip to 
  for( i = 0; i < 2 ; i++, arg-- ) {
	
	switch ( arg->info ) {
	case FIELD_TYPE_DATE: ui[i] = arg->value.ui; break;
	case FIELD_TYPE_TIME: ui[i] = (UInt32)arg->value.uh; break;
	}
  }
  switch( function ) {

  case GT_OPERATION:  res->value.i = ( ui[0] > ui[1] ) ? 1 : 0; break;
  case LT_OPERATION:  res->value.i = ( ui[0] < ui[1] ) ? 1 : 0; break;
  case GE_OPERATION:  res->value.i = ( ui[0] >= ui[1] ) ? 1 : 0; break;
  case LE_OPERATION:  res->value.i = ( ui[0] <= ui[1] ) ? 1 : 0; break;
  case EQ_OPERATION:  res->value.i = ( ui[0] == ui[1] ) ? 1 : 0; break;
  default: res->value.i = -4000;
  }

}


static void str_str_i( StackValue *top, StackValue *res ) {

  int function = *(res->value.s - 1);  // its a 16 bit operation code

  
  // make sure we're really dealing with strings!  This is the 
  // only critical error checking
  if ( ((res-1)->meta_info != STRING_META_INFO) || 
	   ((res-2)->meta_info != STRING_META_INFO) ) {
	
	(res-1)->info = CV_FIELD_TYPE_BROKEN;	// script is broken
#ifdef GLOBAL_ACCESS
	MyErr = MODE_ABORT;
#endif
	return;
  }  

  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;
  switch( function ) {
  case SEQ_OPERATION:
	res->value.i = 
	  (StrCompare((res-1)->value.s, (res-2)->value.s) == 0) ? 1 : 0; break;
  case SUBSTR_OPERATION:
	res->value.i =
	  (StrStr((res-1)->value.s, (res-2)->value.s) == NULL) ? 0 : 1; break;
  }
  
  
}
static void not_i( StackValue *top, StackValue *res ) {
  

  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;  
  res->value.i =  ( IsTrue( res-1 ) ) ? 0 : 1;
  
}



/**
 *  ffr_a
 *
 *
 *  Takes 2 or 3 arguments.  The first argument indicates the relative
 *  location of the record to grab the field value from and the second
 *  argument indicates the field index.
 *
 *  Returns:
 *   - the value of the field from another record

 *
 *  Constraints:
 *    -  the 1st argument must be an integer (positive or negative)
 *    -  the 2nd argument must be a valid field id
 *
 */
static void ffr_a( StackValue *top, StackValue *res ) {
  
  Int32 i;
  Int16 dir;
  UInt16 rIndex;
  DataSourceGetter getter;
  void *data;

  i = (res-2)->value.i;
  if ( i > 0 ) dir = dmSeekForward;
  else { dir = dmSeekBackward; i = -i; }
  

  rIndex = ScriptExeData.rf;
  if (!ScriptExeData.src->ops.Seek( ScriptExeData.src, &rIndex,
									(UInt16)i, dir )){
		
	  if ( res - top == 4 ) {
		  MemMove( res, top+1, sizeof( StackValue ) );
		  return;
	  }
	  
#ifdef GLOBAL_ACCESS
	MyErr = MODE_ABORT;
#endif
	// when aborting, top will be returned.
	(res-1)->meta_info = NO_META_INFO;
	(res-1)->info = CV_FIELD_TYPE_NA;

	return;
  }
  
  ScriptExeData.src->ops.LockRecord( ScriptExeData.src, rIndex,
									 false, &getter, &data);

  if ( Script_GetFieldValue( res, (res-1)->value.i, &getter, data ) ) {
#ifdef GLOBAL_ACCESS
	MyErr = MODE_ABORT;
#endif
	(res-1)->info = CV_FIELD_TYPE_BROKEN;
  } 

  ScriptExeData.src->ops.UnlockRecord(ScriptExeData.src, rIndex, false, data);

}

static void sort_n( StackValue *top, StackValue *res ) {

  DataSourceSortInfo info;
  DataSourceSortField fields[3];  // allow sorting on up to three fields
  int nfields, i;


  nfields = (res - top - 1) / 2;
  
  /* Build the information used by the standard sorting callback. */
  info.numFields = nfields;
  info.fields = &fields[0];
  for( i = 0; i < nfields; i++ ) {
	
	info.fields[i].fieldNum =  (UInt16)((res-(i*2)-1)->value.i);
	info.fields[i].direction = ((res-(i*2)-2)->value.i)?SORT_DIRECTION_ASCENDING:SORT_DIRECTION_DESCENDING;
	info.fields[i].case_sensitive = false;

  }
  /* Tell the data source to sort itself. */
  ScriptExeData.src->ops.Sort(ScriptExeData.src, DS_StandardSortCallback, 
							  &info);
  
  res->meta_info = NUMBER_META_INFO;
  res->info = FIELD_TYPE_INTEGER;
  res->value.i = 1;
  
}




static void void_a( StackValue *top, StackValue *res ) {

  switch ( *(res->value.s - 1) ) {
  case RANDOM_OPERATION:
	res->meta_info = NUMBER_META_INFO;
	res->info = FIELD_TYPE_INTEGER;
	res->value.i = (Int32) SysRandom( 0 );
	break;
  }

}

static void cast_i( StackValue *top, StackValue *res ) {
	DateTimeType dt;

	res->info = FIELD_TYPE_INTEGER;
	res->meta_info = FIELD_TYPE_INTEGER;

	switch( (res-1)->info ) {
	case FIELD_TYPE_TIME:
		dt.year = 1904;
		dt.month = 1;
		dt.day = 1;
		dt.second = 0;
		dt.hour = (res-1)->value.t.hour;
		dt.minute = (res-1)->value.t.min;
		
		if ( dt.hour <= 24 ) 
			res->value.i = (Int32) (TimDateTimeToSeconds( &dt )/60L);
		else
			res->value.i = 0L;

		break;

	case FIELD_TYPE_DATE:
		dt.year = (res-1)->value.ymd.year;
		dt.month = (res-1)->value.ymd.month;
		dt.day = (res-1)->value.ymd.day;
		dt.second = 0;
		dt.hour = 0;
		dt.minute = 0;
		
		if ( dt.month != 0 )
			res->value.i = (Int32) (TimDateTimeToSeconds( &dt )/60L);
		else
			res->value.i = 0;
		break;

	default:
		MemMove( res, (res-1), sizeof( StackValue ) );
		break;

	}
	
}


static void cast_dur( StackValue *top, StackValue *res ) {
  
  MemMove( res, (res-1), sizeof( StackValue ) );
  res->info = CV_FIELD_TYPE_DURATION;
  res->meta_info = FIELD_TYPE_INTEGER;
}
