#ifndef _NOTE_H
#define _NOTE_H

typedef struct {
    MemHandle h;
    Char *s;
    Char title[12];
} NoteType;
typedef NoteType * NotePtr;

extern UInt16 NotePopupForm(NotePtr, Boolean) EDITSECT;

#endif