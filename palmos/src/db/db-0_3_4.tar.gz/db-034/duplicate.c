/*
 * Duplicate database.
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <TxtGlue.h>

#include "db.h"

#include "enum.h"
#include "io.h"
#include "double.h"
#include "util.h"
#ifdef CONFIG_SCRIPTS
#include "script.h"
#endif


typedef struct {
    /* Info needed to get old data out of source database. */
    DataSourceGetter getter;
    void * rec_data;

    /* Info on the source database so conversion can be determined. */
    DataSource * src;
    UInt32 * reorder;
    DataSourceSchema * dstSchema;
} RebuildData, DuplicateData;

static char * Source_GetString(void * ptr, UInt16 fieldNum) SECT_UI;
static Int32 Source_GetInteger(void * ptr, UInt16 fieldNum) SECT_UI;
static Boolean Source_GetBoolean(void * ptr, UInt16 fieldNum) SECT_UI;
static void Source_GetDate(void * ptr, UInt16 fieldNum,
                            UInt16* year, UInt8* month, UInt8* day) SECT_UI;
static void Source_GetTime(void * ptr, UInt16 fieldNum,
                            UInt8* hour, UInt8* minute) SECT_UI;
static char * Source_GetNote(void * ptr, UInt16 fieldNum) SECT_UI;
static char * Source_GetNoteTitle(void * ptr, UInt16 fieldNum) SECT_UI;
static UInt8 Source_GetListItem(void * ptr, UInt16 fieldNum) SECT_UI;
static char * Source_GetLink(void * ptr, UInt16 fieldNum, UInt32 * uniqID) SECT_UI;
static char * Source_GetLinked(void * ptr, UInt16 fieldNum) SECT_UI;
static double Source_GetFloat(void * ptr, UInt16 fieldNum) SECT_UI;
#ifdef CONFIG_SCRIPTS
static void Source_GetCalculated (void * data, UInt16 fieldNum, CalculatedValue *cv) SECT_UI;
#endif

static DataSourceGetter Source_Getter = {
    GetString: Source_GetString,
    GetInteger: Source_GetInteger,
    GetBoolean: Source_GetBoolean,
    GetDate: Source_GetDate,
    GetTime: Source_GetTime,
    GetNote: Source_GetNote,
    GetNoteTitle: Source_GetNoteTitle,
    GetListItem: Source_GetListItem,
    GetLink: Source_GetLink,
    GetLinked: Source_GetLinked,
    GetFloat: Source_GetFloat,
#ifdef CONFIG_SCRIPTS
    GetCalculated: Source_GetCalculated
#else
    GetCalculated: NULL
#endif
};

static char * Source_GetString(void * ptr, UInt16 fieldNum)
{
    static char buf[32];

    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    Int32 v;
    char *p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields) {
        buf[0] = '\0';
        return buf;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        p = data->getter.GetString(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_LIST:
        v = data->getter.GetListItem(data->rec_data, srcFieldNum);
        /* it's not work because i already desallocate items string*/
        /*and numItems = 0*/
        if (v >= 0 && v < data->dstSchema->fields[fieldNum].data.list.numItems)
            p = data->dstSchema->fields[fieldNum].data.list.items[v];
        else {
            buf[1] = '\0';
            p = buf;
        }
        break;

    default:
        ConvertFieldToString(data->src, &(data->getter), data->rec_data, fieldNum, buf, 32);
        p = buf;
        break;
    }

    return p;
}

static Int32 Source_GetInteger(void * ptr, UInt16 fieldNum)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    Int32 v;
    char * p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields)
        return 0;

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        p = data->getter.GetString(data->rec_data, srcFieldNum);
        v = String2Long(p);
        break;

    case FIELD_TYPE_NOTE:
        p = data->getter.GetNoteTitle(data->rec_data, srcFieldNum);
        v = String2Long(p);
        break;

    case FIELD_TYPE_INTEGER:
        v = data->getter.GetInteger(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_BOOLEAN:
        if (data->getter.GetBoolean(data->rec_data, srcFieldNum))
            v = 1;
        else
            v = 0;
        break;

    case FIELD_TYPE_LIST:
        v = data->getter.GetListItem(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_LINK:
        data->getter.GetLink(data->rec_data, srcFieldNum, &v);
        break;

	case FIELD_TYPE_FLOAT:
	  v = (Int32) data->getter.GetFloat( data->rec_data, srcFieldNum );
	  break;

    default:
            v = 0;
        break;
    }

    return v;
}

static Boolean Source_GetBoolean(void * ptr, UInt16 fieldNum)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    Boolean b;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields)
        return false;

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        b = *(data->getter.GetString(data->rec_data, srcFieldNum)) != '0';
        break;

    case FIELD_TYPE_INTEGER:
        if (data->getter.GetInteger(data->rec_data, srcFieldNum))
            b = true;
        else
            b = false;
        break;

    case FIELD_TYPE_BOOLEAN:
        b = data->getter.GetBoolean(data->rec_data, srcFieldNum);
        break;

    default:
        b = false;
        break;
    }

    return b;
}

static void
Source_GetDate(void * ptr, UInt16 fieldNum,
                UInt16* year, UInt8* month, UInt8* day)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    DateTimeType datetime;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    /* For new fields, just return the current date. */
    if (srcFieldNum >= data->src->schema.numFields) {
        TimSecondsToDateTime(TimGetSeconds(), &datetime);
        *year = datetime.year;
        *month = datetime.month;
        *day = datetime.day;
        return;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_DATE:
        data->getter.GetDate(data->rec_data, srcFieldNum, year, month, day);
        break;

    default:
        TimSecondsToDateTime(TimGetSeconds(), &datetime);
        *year = datetime.year;
        *month = datetime.month;
        *day = datetime.day;
        break;
    }
}

static void
Source_GetTime(void * ptr, UInt16 fieldNum, UInt8* hour, UInt8* minute)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;

    DateTimeType datetime;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    /* For new fields, just return the current date. */
    if (srcFieldNum >= data->src->schema.numFields) {
        TimSecondsToDateTime(TimGetSeconds(), &datetime);
        *hour = datetime.hour;
        *minute = datetime.minute;
        return;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_TIME:
        data->getter.GetTime(data->rec_data, srcFieldNum, hour, minute);
        break;

    default:
        TimSecondsToDateTime(TimGetSeconds(), &datetime);
        *hour = datetime.hour;
        *minute = datetime.minute;
        break;
    }
}

static char * Source_GetNote(void * ptr, UInt16 fieldNum)
{
    static char buf[32];

    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    Int32 v;
    char *p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields) {
            buf[0] = '\0';
            return buf;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
            p = data->getter.GetString(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_NOTE:
            p = data->getter.GetNote(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_LINK:
        p = data->getter.GetLink(data->rec_data, srcFieldNum, &v);
        break;

    case FIELD_TYPE_LINKED:
        p = data->getter.GetLinked(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_INTEGER:
            v = data->getter.GetInteger(data->rec_data, srcFieldNum);
            StrPrintF(buf, "%ld", v);
            p = buf;
        break;

    case FIELD_TYPE_BOOLEAN:
            if (data->getter.GetBoolean(data->rec_data, srcFieldNum))
                buf[0] = '1';
            else
            buf[0] = '0';
            buf[1] = '\0';
            p = buf;
        break;

    case FIELD_TYPE_LIST:
        v = data->getter.GetListItem(data->rec_data, srcFieldNum);
        p = data->dstSchema->fields[fieldNum].data.list.items[v];
        break;

    default:
            buf[0] = '\0';
            p = buf;
    }

    return p;
}

static char * Source_GetNoteTitle(void * ptr, UInt16 fieldNum)
{
    static char buf[32];
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    Int32 v;
    char *p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields) {
            buf[0] = '\0';
            return buf;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        MemMove( buf, data->getter.GetString(data->rec_data, srcFieldNum), 11);
        p = buf;
        break;

    case FIELD_TYPE_NOTE:
        p = data->getter.GetNoteTitle(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_LINK:
        MemMove( buf, data->getter.GetLink(data->rec_data, srcFieldNum, &v), 11);
            p = buf;
        break;

    case FIELD_TYPE_LINKED:
        MemMove( buf, data->getter.GetLinked(data->rec_data, srcFieldNum), 11);
            p = buf;
        break;

    case FIELD_TYPE_INTEGER:
        v = data->getter.GetInteger(data->rec_data, srcFieldNum);
        StrPrintF(buf, "%ld", v);
        p = buf;
        break;

    case FIELD_TYPE_BOOLEAN:
        if (data->getter.GetBoolean(data->rec_data, srcFieldNum))
                buf[0] = '1';
            else
            buf[0] = '0';
            buf[1] = '\0';
            p = buf;
        break;

    case FIELD_TYPE_LIST:
        v = data->getter.GetListItem(data->rec_data, srcFieldNum);
        p = data->dstSchema->fields[fieldNum].data.list.items[v];
        break;

    default:
            buf[0] = '\0';
            p = buf;
    }

    return p;
}

static UInt8 Source_GetListItem(void * ptr, UInt16 fieldNum)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    UInt8 v, j;
    char * p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields)
        return 0;

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        p = data->getter.GetString(data->rec_data, srcFieldNum);
        v = -1;
        for ( j = 0; j < data->dstSchema->fields[fieldNum].data.list.numItems; j++) {
            if ( MatchString( p, data->dstSchema->fields[fieldNum].data.list.items[j], false, true)){
                v = j;
                break;
            }
        }
        break;

    case FIELD_TYPE_NOTE:
        p = data->getter.GetNoteTitle(data->rec_data, srcFieldNum);
        v = -1;
        for ( j = 0; j < data->dstSchema->fields[fieldNum].data.list.numItems; j++) {
            if ( MatchString( p, data->dstSchema->fields[fieldNum].data.list.items[j], false, true)){
                v = j;
                break;
            }
        }
        break;

    case FIELD_TYPE_INTEGER:
        v = (UInt8) data->getter.GetInteger(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_BOOLEAN:
        if (data->getter.GetBoolean(data->rec_data, srcFieldNum))
            v = 1;
        else
            v = 0;
        break;

    case FIELD_TYPE_LIST:
    {
        UInt16 value;
        value = data->getter.GetListItem(data->rec_data, srcFieldNum);
        v = -1;
        if (!data->dstSchema->fields[fieldNum].data.list.uniqID)
            break;
        for ( j = 0; j < data->dstSchema->fields[fieldNum].data.list.numItems; j++) {
            if ( data->dstSchema->fields[fieldNum].data.list.uniqID[j] == value){
                v = j;
                break;
            }
        }
        break;
    }
    default:
        v = -1;
        break;
    }

    return v;
}

static char *
Source_GetLink(void * ptr, UInt16 fieldNum, UInt32 * uniqID)
{
    static char buf[32];
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    char * p = NULL;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields) {
        goto error;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_LINK:
      {
        LinkType link;

        p = data->getter.GetLink(data->rec_data, srcFieldNum, &(link.uniqID));
        if (p)
            StrNCopy( link.name, p, 32);
        else
            link.name[0] = 0;
        LinkUpdate( data->dstSchema->fields[fieldNum].data.link.dbID,
                    data->dstSchema->fields[fieldNum].data.link.fieldNum,
                    &link);
        if (uniqID) {
           *uniqID = link.uniqID;
        }
      }
    break;

    case FIELD_TYPE_LINKED:
      {
        LinkType link;

        p = data->getter.GetLinked(data->rec_data, srcFieldNum);
        data->getter.GetLink(data->rec_data, data->dstSchema->fields[fieldNum].data.linked.linkNum, &(link.uniqID));
        if (p)
            StrNCopy( link.name, p, 32);
        else
            link.name[0] = 0;
        LinkUpdate( data->dstSchema->fields[data->dstSchema->fields[fieldNum].data.linked.linkNum].data.link.dbID,
                    data->dstSchema->fields[fieldNum].data.linked.fieldNum,
                    &link);
        if (uniqID) {
           *uniqID = link.uniqID;
        }
      }
    break;

    default:
        ConvertFieldToString(data->src, &(data->getter), data->rec_data, fieldNum, buf, 32);
        p = buf;
        goto error;
    break;
    }
    return p;

error:
    if (uniqID){
        *uniqID = 0UL;
    }
    return p;
}

static char *
Source_GetLinked(void * ptr, UInt16 fieldNum)
{
    static char buf[32];
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    char * p = NULL;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields) {
        return p;
    }

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_LINKED:
        p = data->getter.GetLinked(data->rec_data, srcFieldNum);
        if ( data->reorder)
            data->dstSchema->fields[fieldNum].data.linked.linkNum = 
                data->reorder[data->dstSchema->fields[fieldNum].data.linked.linkNum];
        if (data->dstSchema->fields[data->dstSchema->fields[fieldNum].data.linked.linkNum].type == FIELD_TYPE_LINK) {
            LinkType link;

            if (p)
                StrNCopy( link.name, p, 32);
            else
                link.name[0] = 0;
            data->getter.GetLink(data->rec_data, data->dstSchema->fields[fieldNum].data.linked.linkNum, &(link.uniqID));
            LinkUpdate( data->dstSchema->fields[data->dstSchema->fields[fieldNum].data.linked.linkNum].data.link.dbID,
                        data->dstSchema->fields[fieldNum].data.linked.fieldNum,
                        &link);
        }
    break;

    default:
        ConvertFieldToString(data->src, &(data->getter), data->rec_data, fieldNum, buf, 32);
        p = buf;
    break;
    }
    return p;

}

static double
Source_GetFloat(void * ptr, UInt16 fieldNum) {
  
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;
    double v;
    char * p;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    if (srcFieldNum >= data->src->schema.numFields)
        return 0;

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_STRING:
        p = data->getter.GetString(data->rec_data, srcFieldNum);
        DoubleAToD( &v, p);
        break;

    case FIELD_TYPE_NOTE:
        p = data->getter.GetNote(data->rec_data, srcFieldNum);
        DoubleAToD( &v, p);
        break;

    case FIELD_TYPE_INTEGER:
        v = (double)data->getter.GetInteger(data->rec_data, srcFieldNum);
        break;

    case FIELD_TYPE_BOOLEAN:
        if (data->getter.GetBoolean(data->rec_data, srcFieldNum))
            v = 1.0;
        else
            v = 0.0;
        break;

    case FIELD_TYPE_FLOAT:
        v = data->getter.GetFloat(data->rec_data, srcFieldNum);
        break;

    default:
            v = 0.0;
        break;
    }

    return v;


}

#ifdef CONFIG_SCRIPTS
static void
Source_GetCalculated (void * ptr, UInt16 fieldNum, CalculatedValue *cv)
{
    RebuildData * data = (RebuildData *) ptr;
    UInt16 srcFieldNum;

    if ( data->reorder)
        srcFieldNum = data->reorder[fieldNum];
    else
        srcFieldNum = fieldNum;

    switch (data->src->schema.fields[srcFieldNum].type) {
    case FIELD_TYPE_CALCULATED:
        data->getter.GetCalculated(data->rec_data, srcFieldNum, cv);
        break;

    default:
        cv->info = FIELD_TYPE_INTEGER;
        cv->value.i = 0;
        break;
    }

}
#endif

void
DuplicateDatabase(DataSource *src, DataSourceDriver * driver,
            const char* dst_title, Boolean everything)
{
    RebuildData data;
    DataSource *dst;
    DataSourceSchema schema;
    Err err;
    void * dst_key_data;
    UInt16 dst_key_size, recNum, i;

    if (!src) {
        FrmAlert(alertID_RebuildFailed);
        return;
    }

    /* Make a local copy of the source's schema. If the destination
     * driver doesn't support all of the source's field types, then
     * change that field type to string. If the string field typeisn't
     * supported, then flag an error.
     */
    CopySchema(&schema, &src->schema);
    for (i = 0; i < schema.numFields; ++i) {
        if (! driver->class_ops.SupportsFieldType(schema.fields[i].type)) {
            if (! driver->class_ops.SupportsFieldType(FIELD_TYPE_STRING)) {
                FrmAlert(alertID_RebuildFailed);
                FreeSchema(&schema);
                return;
            }
            schema.fields[i].type = FIELD_TYPE_STRING;
        }
    }

    /* Create the destination data source. */
    err = driver->class_ops.Create(dst_title, &schema,
                                   &dst_key_data, &dst_key_size);
    if (err != 0) {
        FrmAlert(alertID_RebuildFailed);
        FreeSchema(&schema);
        return;
    }

    /* Free the copied schema now that it is outlived its usefulness. */
    FreeSchema(&schema);

    /* Open the destination for read/write access. */
    dst = OpenDataSource(DriverList, dmModeReadWrite, driver->sourceID,
                         dst_key_data, dst_key_size);
    if (!dst) {
        FrmAlert(alertID_RebuildFailed);
        return;
    }

    /* Fill in the information needed by our custom getter. */
    data.src = src;
    data.reorder = NULL;
    data.dstSchema = &(src->schema);

    /* Loop for each record and use the data source methods to have fun. */
    if (everything) {
        if( src->ops.Capable( src, DS_CAPABLE_LISTVIEW_FILTER)) {
            src->ops.SetFilter( src, FILTERALL, false );
    	}

        recNum = 0;
        while (1) {
            UInt16 index = dmMaxRecordIndex;
            /* Make sure that this is a valid record. */
            if (! src->ops.Seek(src, &recNum, 0, dmSeekForward))
                break;

            /* Copy the record to the destination. */
            src->ops.LockRecord(src, recNum, false,
                                &data.getter, &data.rec_data);
            err = dst->ops.UpdateRecord(dst, &index, false,
                                        &Source_Getter, &data);
            src->ops.UnlockRecord(src, recNum, false, data.rec_data);

            /* If the copy failed, then notify the user. */
            if (err != 0) {
                /* Remove working indicator and display the error. */
                FrmAlert(DeviceFullAlert);

                /* Close both data sources and delete the destination. */
                CloseDataSource(dst);
                DeleteDataSource(DriverList, driver->sourceID,
                                 dst_key_data, dst_key_size);
                DeallocateMemPtr(dst_key_data);
                return;
            }

            /* Advance the record number. */
            recNum++;
        }
    }

    /* Now copy each view in the source over. */
    for (i = 0; i < src->ops.GetNumOfViews(src); ++i) {
        DataSourceView * view;

        view = src->ops.GetView(src, i);
        if (dst->ops.Capable(dst, DS_CAPABLE_LISTVIEW_INSERT)){
            dst->ops.StoreView(dst, i, view);
        }
        src->ops.PutView(src, i, view);
    }

    /* Close the destination. */
    CloseDataSource(dst);

    DeallocateMemPtr(dst_key_data);
}

DataSource *
RebuildDatabase(DataSource * src, DataSourceSchema * schema, UInt32 * reorder)
{
    RebuildData data;
    DataSource * dst;
    void * key_data;
    UInt16 key_size, recNum, i;
    Err err;
    DataSourceSchema * useSchema;

    if (schema)
        useSchema = schema;
    else
        useSchema = &(src->schema);

    /* Create a temporary database to move the fields into. */
    err = src->driver->class_ops.Create("DBOStmp", useSchema,
                                        &key_data, &key_size);
    if (err != 0) {
        FrmAlert(alertID_RebuildFailed);
        return src;
    }

    /* Open the temporary data source for writing. */
    dst = OpenDataSource(DriverList, dmModeReadWrite, src->driver->sourceID,
                         key_data, key_size);
    if (!dst) {
        FrmAlert(alertID_RebuildFailed);
        return src;
    }

    /* Fill in the fields of the rebuild data that we know of. */
    data.src = src;
    data.reorder = reorder;
    data.dstSchema = useSchema;
	
    /* Convert the records into the temporary database. */
    recNum = 0;
    while (1) {
        UInt16 index = dmMaxRecordIndex;
        /* Make sure that this is a valid record. */
        if (! src->ops.Seek(src, &recNum, 0, dmSeekForward))
            break;

        /* Copy and convert the record to the destination. */
        src->ops.LockRecord(src, recNum, false, &data.getter, &data.rec_data);
        err = dst->ops.UpdateRecord(dst, &index, false,
                                    &Source_Getter, &data);
        src->ops.UnlockRecord(src, recNum, false, data.rec_data);

        /* If the copy failed, then notify the user. */
        if (err != 0) {
            /* Flag the error. */
            ErrAlert( err);

            /* Close the temporary database and delete it. */
            CloseDataSource(dst);
            DeleteDataSource(DriverList, src->driver->sourceID,
                             key_data, key_size);
            DeallocateMemPtr(key_data);
            return src;
        }

        /* Advance the record number. */
        recNum++;
    }

    if (src->driver->class_ops.SupportsFieldType(FIELD_TYPE_CALCULATED))
        src->ops.RecalculateFields(src);

    /* Now copy each view in the source over. */
    for (i = 0; i < src->ops.GetNumOfViews(src); ++i) {
        DataSourceView * view;
        UInt16 col, j;

        /* Retrieve a copy of this view. */
        view = src->ops.GetView(src, i);

        if (reorder) {
            UInt16 newFieldNum;

            /* Validate the view in light of any fields added or removed. */
            for (col = 0; col < view->numCols; ++col) {
                /* Assume that we don't find anything. Use first field. */
                newFieldNum = 0;

                /* Look up this field number in the reordering list. */
                for (j = 0; j < useSchema->numFields; ++j) {
        			if (view->cols[col].fieldNum == reorder[j]){
            			newFieldNum = j;
                        break;
                    }
                }
                /* Remap this column. */
                view->cols[col].fieldNum = newFieldNum;
            }
        }
    
        /* Store the view in the destination and free view data. */
        if (dst->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_INSERT))
            dst->ops.StoreView(dst, i, view);
        src->ops.PutView(src, i, view);
    }

    /* Close and delete the active source database. */
    {
        UInt16 sourceID = src->driver->sourceID, src_key_size;
        void * src_key_data;
        char title[64];
    
        /* Retrieve the name of the source database. */
        src->ops.GetTitle(src, title, sizeof(title));
    
        /* Get a key we can use to delete the source database. */
        src_key_size = src->ops.GetKey(src, 0);
        src_key_data = AllocateMemPtr(src_key_size);
        src->ops.GetKey(src, src_key_data);
    
        /* retrieve others informations*/
        dst->openMode = src->openMode;
        dst->currentfilter = src->currentfilter;
        /* Close the source database. */
        CloseDataSource(src);

        /* Delete the source database. */
        DeleteDataSource(DriverList, sourceID, src_key_data, src_key_size);
        DeallocateMemPtr(src_key_data);
    
        /* Rename the destination database to the name the source had. */
        dst->ops.SetTitle(dst, title, &(dst->key.data), &(dst->key.size));
        Chooser_RenameDatabase(dst->driver->sourceID,
                               key_data, key_size,
                               dst->key.data, dst->key.size, title);
    }

    /* Free any temporary allocations. */
    DeallocateMemPtr(key_data);
    
    return dst;
}
