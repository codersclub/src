/*
 * DB: Record List View
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include <PalmOSGlue.h>

#include "db.h"
//db.h must be included before to use the defines
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif

#include "enum.h"
#include "grid.h"
#include "prefs.h"
#include "io.h"
#include "util.h"
#include "popuplist.h"
#ifdef CONFIG_PLUGINS
#include "plug.h"
#endif
#ifdef CONFIG_ICONS
#include "enum-icons.h"
#endif

#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))
#define noRecord dmMaxRecordIndex
#define updateRedrawGrid 0x01
#define updateModelChanged 0x02
#define updateModelNew 0x04

static UInt16 ActiveViewIndex;
static DataSourceView * ActiveView;
static GridModelType * ViewModel;
static GridType Grid;

typedef struct {
    UInt16 fieldNum;
    Boolean caseSens;
    Boolean wholeWord;
    Char string[33];
    UInt16 lastFound;
} FindData;

static FindData FindInfo;

static void UpdateFieldButtons(Boolean, Boolean) SECT_UI;
static void UpdateScrollers(Boolean, Boolean) SECT_UI;
static void LocalSearch(FindData *, DataSourceFilter) SECT_UI;
static Boolean DoCommand(UInt16 itemID) SECT_UI;
static Boolean ListViewUpdateForm(FormPtr form, UInt16 type) SECT_UI;
static void SelectViewTrigger(void) SECT_UI;
static void DoQuickSort( UInt16 fieldNum , UInt16 sortOrder) SECT_UI;
static void LookUpList( UInt16 fieldNum, Char search) SECT_UI;

static void
UpdateFieldButtons(Boolean scrollLeft, Boolean scrollRight)
{
    FormPtr form;
    UInt16 leftIndex, rightIndex;

    form = FrmGetActiveForm();
    leftIndex = FrmGetObjectIndex(form, ctlID_ListView_LeftButton);
    rightIndex = FrmGetObjectIndex(form, ctlID_ListView_RightButton);

    if (scrollLeft)
        FrmShowObject(form, leftIndex);
    else
        FrmHideObject(form, leftIndex);

    if (scrollRight)
        FrmShowObject(form, rightIndex);
    else
        FrmHideObject(form, rightIndex);
}

static void
UpdateScrollers(Boolean scrollUp, Boolean scrollDown)
{
    FormPtr form;
    UInt16 upIndex, downIndex;

    form = FrmGetActiveForm();
    upIndex = FrmGetObjectIndex(form, ctlID_ListView_UpButton);
    downIndex = FrmGetObjectIndex(form, ctlID_ListView_DownButton);
    FrmUpdateScrollers(form, upIndex, downIndex, scrollUp, scrollDown);
}

static void
LocalSearch(FindData *findInfo, DataSourceFilter filter)
{
    UInt16 recNum, foundRecNum;
    DataSourceGetter getter;
    void * rec_data;
    Boolean match;
    void * context;

    /* Display an on-screen "Working..." message. */
    context = ShowWorkingIndicator();

    if (filter) {
        CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, false);
        recNum = 0;
    } else {
        recNum = findInfo->lastFound + 1;
    }
    foundRecNum = noRecord;
    while (1) {
        if (! CurrentSource->ops.Seek(CurrentSource, &recNum, 0,
                                      dmSeekForward)) {
            break;
        }

        /* Lock down the record. */
        CurrentSource->ops.LockRecord(CurrentSource, recNum, false,
                                      &getter, &rec_data);

        match = false;
        if (findInfo->fieldNum == 0) {
            UInt16 i;

            /* Search all string fields for the string. */
            for (i = 0; i < CurrentSource->schema.numFields; ++i) {
                /* Compare the string to the field. */
                match = CmpField(CurrentSource, &getter, rec_data, i,
                    findInfo->string, findInfo->caseSens, findInfo->wholeWord);

                /* Bail out if we found a match. */
                if (match) break;
            }
        } else {
            /* Search the single field. */
            match = CmpField(CurrentSource, &getter, rec_data, findInfo->fieldNum - 1, 
                findInfo->string, findInfo->caseSens, findInfo->wholeWord);
        }

        //if a new match and a filter exists (else filter == 0)
        if (match && filter) {
            CurrentSource->ops.FilterRecord(CurrentSource, recNum, filter);
        } 

        /* Unlock the record. */
        CurrentSource->ops.UnlockRecord(CurrentSource, recNum,
                                        false, rec_data);

        /* If a match was found, then stop the search. */
        if (match) {
            foundRecNum = recNum;
            if (!filter)
                break;
        }


        /* Increment the record number. */
        recNum++;
    }

    HideWorkingIndicator(context);
    /* Highlight the found record or scroll grid so record is visible. */
    GridUnhighlightAll(&Grid);
    if (filter) {
        if (foundRecNum != noRecord) {
            CurrentSource->ops.SetFilter( CurrentSource, filter, false);
        } else {
            FrmAlert(alertID_MatchNotFound);
            CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, false);
        }
    } else {
        if (foundRecNum != noRecord) {
            GridSetTopIndex(&Grid, foundRecNum);
            GridHighlightIndex(&Grid, foundRecNum);
#ifdef CONFIG_JOGDIAL
            if (Grid.screenRowSelected != 0xFFFF)
                GridSelectRowIndex(&Grid, foundRecNum);
#endif
            findInfo->lastFound = foundRecNum;
        } else {
            FrmAlert(alertID_MatchNotFound);
            GridSetTopIndex(&Grid, 0);
            GridUnhighlightAll(&Grid);
#ifdef CONFIG_JOGDIAL
            if (Grid.screenRowSelected != 0xFFFF)
                GridSelectRowIndex(&Grid, 0);
#endif
            findInfo->lastFound = 0xFFFF;
        }
    }

    FrmUpdateForm(formID_ListView, updateRedrawGrid);
}

Boolean
FindDialogHandleEvent(EventPtr event)
{
    static char ** names;

    FormPtr form;
    FieldPtr fld;
    ControlPtr ctl;
    ListPtr lst;
    Char * str;
    UInt16 i, objIndex;
    Int16 width, w;
    Int16 filter;
    RectangleType r;
    MemHandle strH;

    switch (event->eType) {
    case frmOpenEvent:
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
            if (!UtilCheckSizeForm(form, 0)) {
                FrmAlert(alertID_FormTooBig);
                FrmReturnToForm(0);
                return true;
            }
        }
#endif

        ctl = GetObjectPtr(form, ctlID_FindDialog_AddCheckBox);
        CtlSetValue(ctl, false);

        ctl = GetObjectPtr(form, ctlID_FindDialog_CaseSensCheckbox);
        CtlSetValue(ctl, FindInfo.caseSens ? 1 : 0);

        ctl = GetObjectPtr(form, ctlID_FindDialog_WholeWordCheckbox);
        CtlSetValue(ctl, FindInfo.wholeWord ? 1 : 0);

        /* Allocate space for an array of string pointers for field list. */
        names = (char **) AllocateMemPtr((CurrentSource->schema.numFields + 1) * sizeof(char *));

        /* Duplicate the "All Fields" string. */
        names[0] = CopyStringResource(stringID_AllFields);

        /* Figure out the width needed for the field popup list. */
        width = FntCharsWidth(names[0], StrLen(names[0]));
        for (i = 0; i < CurrentSource->schema.numFields; i++) {
            names[1 + i] = CurrentSource->schema.fields[i].name;
            w = FntCharsWidth(names[1 + i], StrLen(names[1 + i]));
            if (w > width)
                width = w;
        }
        width += 10;

        /* Set the width of the field popup list. */
        objIndex = FrmGetObjectIndex(form, ctlID_FindDialog_FieldList);
        lst = FrmGetObjectPtr(form, objIndex);
        FrmGetObjectBounds(form, objIndex, &r);
        r.extent.x = width;
        FrmSetObjectBounds(form, objIndex, &r);

        /* Set the remainder of the list parameters. */
        LstSetListChoices(lst, names, 1 + CurrentSource->schema.numFields);
        LstSetSelection(lst, FindInfo.fieldNum);
        LstSetHeight(lst, 1 + CurrentSource->schema.numFields);

        ctl = GetObjectPtr(form, ctlID_FindDialog_FieldTrigger);
        CtlSetLabel(ctl, names[FindInfo.fieldNum]);

        strH = AllocateMemHandle(33);
        str = MemHandleLock(strH);
        StrNCopy(str, FindInfo.string,32);
        str[32] = 0;
        MemPtrUnlock(str);
    
        fld = GetObjectPtr(form, ctlID_FindDialog_Field);
        FldSetTextHandle(fld, strH);

        if ((DBPrefs.flags & prefFlagUnuseFilters)
                || !CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER)) {
            FrmHideObject(form, FrmGetObjectIndex(form,
                                              ctlID_FindDialog_FilterTrigger));
            FrmHideObject(form, FrmGetObjectIndex(form,
                                              ctlID_FindDialog_AddCheckBox));
            GridSetTopIndex(&Grid, 0);
        }

        FrmDrawForm(form);
        FrmSetFocus(form, FrmGetObjectIndex(form, ctlID_FindDialog_Field));

        return true;

/* unuse for a popup form*/
    case frmCloseEvent:
        if (names) {
            DeallocateMemPtr(names[0]);
            DeallocateMemPtr(names);
            names = 0;
        }
        form = FrmGetActiveForm();
        fld = GetObjectPtr(form, ctlID_FindDialog_Field);
        strH = FldGetTextHandle(fld);
        FldSetTextHandle(fld, 0);
        DeallocateMemHandle(strH);
        return false;
    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case ctlID_FindDialog_FindButton:
            form = FrmGetActiveForm();

            /*The field must be reseted to use strH*/
            fld = GetObjectPtr(form, ctlID_FindDialog_Field);
            strH = FldGetTextHandle(fld);
            FldSetTextHandle(fld, 0);

            str = MemHandleLock(strH);
            ctl = GetObjectPtr(form, ctlID_FindDialog_CaseSensCheckbox);
            if ((FindInfo.caseSens = CtlGetValue(ctl)))
                StrNCopy(FindInfo.string, str,32);
            else {
                char tempo[33];
                StrNCopy(tempo, str, 32);
                StrToLower(FindInfo.string, tempo);
            }
            FindInfo.string[32] = 0;
            MemPtrUnlock(str);

            ctl = GetObjectPtr(form, ctlID_FindDialog_WholeWordCheckbox);
            FindInfo.wholeWord = (CtlGetValue(ctl)) ? true : false;

            lst = GetObjectPtr(form, ctlID_FindDialog_FieldList);
            FindInfo.fieldNum = LstGetSelection(lst);

            /* Update the database flags with the current checkbox settings. */
            CurrentSource->ops.SetOption_Boolean(CurrentSource,
                                                 optionID_LFind_CaseSensitive,
                                                 FindInfo.caseSens);
            CurrentSource->ops.SetOption_Boolean(CurrentSource,
                                                 optionID_LFind_WholeWord,
                                                 FindInfo.wholeWord);

            /* Do the actual find operation. */
            if (FindInfo.string[0] != '\0') {
                if (!(DBPrefs.flags & prefFlagUnuseFilters)
                        && CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER)) {
                    Int16 result;

                    lst = GetObjectPtr(form, ctlID_FindDialog_FilterList);
                    result = LstGetSelection(lst);
                    if (result == noListSelection)
                        filter = FILTER1;
                    else
                        filter = (0x01 << result);
                    ctl = GetObjectPtr(form, ctlID_FindDialog_AddCheckBox);
                    if (!CtlGetValue(ctl))
                        CurrentSource->ops.SetFilter( CurrentSource, filter, true);
                    LocalSearch(&FindInfo, filter);
                } else {
                    FindInfo.lastFound = 0xFFFF;
                    LocalSearch(&FindInfo, 0);
                }
            }

            form = FrmGetActiveForm();
            /* Remove the find dialog from the screen. */
            if (names) {
                DeallocateMemPtr(names[0]);
                DeallocateMemPtr(names);
                names = 0;
            }
            DeallocateMemHandle(strH);
            FrmReturnToForm(0);

            return true;

        case ctlID_FindDialog_CancelButton:
            form = FrmGetActiveForm();
            /* Remove the find dialog from the screen. */
            if (names) {
                DeallocateMemPtr(names[0]);
                DeallocateMemPtr(names);
                names = 0;
            }
            fld = GetObjectPtr(form, ctlID_FindDialog_Field);
            strH = FldGetTextHandle(fld);
            FldSetTextHandle(fld, 0);
            DeallocateMemHandle(strH);
            FrmReturnToForm(0);
            return true;
        }
        break;

    default:
        break;
    }

    return false;
}

static Boolean
DoCommand(UInt16 itemID)
{
    switch (itemID) {
    case menuitemID_DatabaseDesign:
        if ((CurrentSource->openMode != dmModeReadOnly)
                && (CurrentSource->driver->class_ops.Create)) {
            if( CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER)) {
                CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, false);
            }
            DesignViewDriver = CurrentSource->driver;
            FrmGotoForm(formID_DesignView);
        }
        return true;

    case menuitemID_Find:
        FrmPopupForm(formID_FindDialog);
        return true;

    case menuitemID_Repeat:
        if ((DBPrefs.flags & prefFlagUnuseFilters)
                || !CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER))
            LocalSearch(&FindInfo, 0);
        return true;

#ifdef CONFIG_SORT
    case menuitemID_Sort:
        if (CurrentSource->openMode != dmModeReadOnly) {
            FrmGotoForm(formID_SortEditor);
        }
        return true;
#endif
	case menuitemID_RebuildRecords:
	{
        void * context;

		if ( CurrentSource->ops.RecalculateFields ) {
			
			/* Display an on-screen "Working..." message. */
			context = ShowWorkingIndicator();
			CurrentSource->ops.RecalculateFields( CurrentSource );
			HideWorkingIndicator(context);
			FrmUpdateForm( formID_ListView, updateModelChanged );
		}
		return true;


	}
    case menuitemID_RebuildDatabase:
      {
        void * context;

        /* Display an on-screen "Working..." message. */
        context = ShowWorkingIndicator();
        CurrentSource = RebuildDatabase(CurrentSource, NULL, NULL);
        HideWorkingIndicator(context);
        ViewModel = ViewModel_New( CurrentSource, ActiveView);
        FrmUpdateForm( formID_ListView, updateModelChanged );
        return true;
     }
    case menuitemID_NewRecord:
        if (CurrentSource->openMode != dmModeReadOnly) {
            IsNewRecord = true;
            FrmGotoForm(formID_EditView);
        }
        return true;

    case menuitemID_DeleteAllRecords:
        if (CurrentSource->openMode != dmModeReadOnly 
                && FrmAlert(alertID_ConfirmDelete) == 0) {
            UInt16 recNum = 0;
            while (1) {
                if (! CurrentSource->ops.Seek(CurrentSource, &recNum, 0,
                                              dmSeekForward)) {
                    break;
                }
                CurrentSource->ops.DeleteRecord(CurrentSource, recNum);
            }
            FrmUpdateForm(formID_ListView, updateRedrawGrid);
        }
        return true;

    case menuitemID_GotoTop:
        GridSetTopIndex(&Grid, 0);
        FrmUpdateForm(formID_ListView, updateRedrawGrid);
        return true;

    case menuitemID_GotoBottom:
        GridSetTopIndex(&Grid, dmMaxRecordIndex);
        FrmUpdateForm(formID_ListView, updateRedrawGrid);
        return true;

    case menuitemID_DatabasePrefs:
        MenuEraseStatus(0);
        PopupDBPrefs();
        return true;

    case menuitemID_Help:
        FrmHelp(stringID_Help_ListView);
        return true;

#ifdef CONFIG_PLUGINS
    case menuitemID_Plugins:
    {
        PlugEnvironement l_PluginInfo;
        l_PluginInfo.m_Screen = PLUGINTYPE_LISTVIEW;
        l_PluginInfo.m_DataBase = CurrentSource;
        Plug_ShowList( &l_PluginInfo);
        return true;
    }
#endif
    default:
        return HandleCommonMenuEvent(itemID);

    }
}

static void
SelectViewTrigger(void)
{
    FormType * form;
    ListType * lst;
    UInt16 numViews, i;
    Int16 new_view_index;
    char ** view_names;

    form = FrmGetActiveForm();

    /* Construct an array of the names of the views in this database. */
    numViews = CurrentSource->ops.GetNumOfViews(CurrentSource);
    view_names = AllocateMemPtr((numViews + 2) * sizeof(char *));
    for (i = 0; i < numViews; ++i) {
        DataSourceView * v = CurrentSource->ops.GetView(CurrentSource, i);
        view_names[i] = AllocateMemPtr(1 + StrLen(v->name));
        StrCopy(view_names[i], v->name);
        CurrentSource->ops.PutView(CurrentSource, i, v);
    }
    /* add "All" View and Edit list Views*/
    view_names[i++] = CopyStringResource(stringID_AllFields);
    view_names[i++] = CopyStringResource(stringID_EditListViews);

    /* Setup the list and popup trigger. */
    lst = GetObjectPtr(form, ctlID_ListView_ViewList);
    LstSetListChoices(lst, view_names, numViews + 2);
    LstSetHeight(lst, numViews + 2);
    LstSetSelection(lst, ActiveViewIndex);

    new_view_index = LstPopupList(lst);

    /* check if View All is selected */
    if (new_view_index == numViews)
        new_view_index = 0xFF;

    /* check if Edit list Views selected*/
    if (new_view_index == numViews + 1) {
        FrmGotoForm(formID_NamesEditor);
        goto free_viewnames;
    }
        
    /* If the user switched views, move to the new view. */
    if ((new_view_index != ActiveViewIndex) && (new_view_index >= 0)) {
        if (ActiveViewIndex == 0xFF)
            DS_PutView(CurrentSource, ActiveViewIndex, ActiveView);
        else
            CurrentSource->ops.PutView(CurrentSource, ActiveViewIndex, ActiveView);

        /* Update the in-core variables to the new view. */
        ActiveViewIndex = new_view_index;
        if (ActiveViewIndex == 0xFF)
            ActiveView = DS_GetView(CurrentSource, ActiveViewIndex);
        else
            ActiveView = CurrentSource->ops.GetView(CurrentSource, ActiveViewIndex);

        /* Tell the list form to reinitialize the Grid. */
        FrmUpdateForm(formID_ListView, updateModelChanged);
    }

free_viewnames:
    /* free the view names. */
    for (i = 0; i < numViews + 2; ++i) {
        DeallocateMemPtr(view_names[i]);
    }
    DeallocateMemPtr(view_names);

}

static void
LookUpList( UInt16 fieldNum, Char search)
{
    UInt16 recNum, foundRecNum;
    DataSourceGetter getter;
    void * rec_data;
    Char string[2], c;

    foundRecNum = noRecord;
    recNum = 0;
    if (TxtCharIsUpper(search))
        search += 0x20;

    while (1) {
        if (! CurrentSource->ops.Seek(CurrentSource, &recNum, 0,
                                      dmSeekForward)) {
            break;
        }

        /* Lock down the record. */
        CurrentSource->ops.LockRecord(CurrentSource, recNum, false,
                                      &getter, &rec_data);

        ConvertFieldToString(CurrentSource, &getter, rec_data,
                        fieldNum, string, 1);
        c = string[0];
        if (TxtCharIsUpper(c))
            c += 0x20;

        if (c == search) {
            foundRecNum = recNum;
            break;
        }
        /* Unlock the record. */
        CurrentSource->ops.UnlockRecord(CurrentSource, recNum,
                                        false, rec_data);

        /* Increment the record number. */
        recNum++;
    }

    if (foundRecNum != noRecord) {
        GridSetTopIndex(&Grid, foundRecNum);
    } else {
        GridSetTopIndex(&Grid, 0);
    }

    FrmUpdateForm(formID_ListView, updateRedrawGrid);
}

static void
DoQuickSort( UInt16 fieldNum , UInt16 sortOrder)
{
    DataSourceSortInfo info;
    DataSourceSortField fields[1];
    void * indicator_context;

    /* Build the information used by the standard sorting callback. */
    info.numFields = 1;
    info.fields = &fields[0];
    info.fields[0].fieldNum = fieldNum;
    info.fields[0].direction = sortOrder;
    info.fields[0].case_sensitive = false;

    /* Tell the data source to sort itself. */
    indicator_context = ShowWorkingIndicator();
    CurrentSource->ops.Sort(CurrentSource, DS_StandardSortCallback, &info);
    HideWorkingIndicator(indicator_context);
}

enum {
        actionID_SortAscend,
        actionID_SortDescend,
        actionID_ResetFilter
};

static ActionDetails
popup_menu[] = {
    { stringID_SortAscend,              actionID_SortAscend,    false },
    { stringID_SortDescend,     actionID_SortDescend,   false },
//    { stringID_ResetFilter,   actionID_ResetFilter, false},
    { 0,                                0,                      true}
};

static Boolean
ListViewUpdateForm(FormPtr form, UInt16 type)
{
    ControlType * ctl;
    ListType * lst;
    static char viewName[12];
#ifdef CONFIG_HANDERA
    UInt16 objectID1[] = {      ctlID_ListView_DoneButton,
                                ctlID_ListView_NewButton,
                                ctlID_ListView_FilterTrigger,
                                ctlID_ListView_FilterList,
#ifdef CONFIG_ICONS
                                ctlID_ListView_FindButton,
                                bmpID_ExitButton,
                                bmpID_NewRButton,
                                bmpID_FindButton,
                                bmpID_LockButton,
#endif
                                0};
    UInt16 objectID2[] = {      ctlID_ListView_UpButton,
                                ctlID_ListView_DownButton,
                                ctlID_ListView_RightButton,
                                ctlID_ListView_LeftButton,
                                0};
    UInt16 objectID3[] = {      ctlID_ListView_ViewTrigger,
                                ctlID_ListView_ViewList,
                                0};
#endif

#ifdef CONFIG_HANDERA
    UtilResizeForm(form, objectID1, objectID2, objectID3, ctlID_ListView_Grid, true);
#endif
    /* If the model changed, then reinitialize the grid widget. */
    if (type & updateModelNew){
        GridInit(&Grid, form, ctlID_ListView_Grid,
                     ctlID_ListView_GridCheckbox, ViewModel, 0);
        GridSetTopIndex(&Grid,  CurrentSource->ops.GetOption_UInt16(CurrentSource, optionID_ListView_TopVisibleRecord));
    }
    if (type & (updateModelChanged | updateFontChanged) ) {
        GridSetHeaderLook(&Grid, DBPrefs.GridDisplay & Display_Header,
                                DBPrefs.GridDisplay & Display_Header_sep,
                                true,
                                DBPrefs.TheBoldFont);
        GridSetColumnLook(&Grid, DBPrefs.GridDisplay & Display_Col_sep);
        GridChange(&Grid, form, ViewModel, 0);
        GridSetTopIndex(&Grid,  CurrentSource->ops.GetOption_UInt16(CurrentSource, optionID_ListView_TopVisibleRecord));
    }

    ctl = GetObjectPtr(form, ctlID_ListView_ViewTrigger);
    MemMove( viewName, ActiveView->name, 11);
    CtlSetLabel(ctl, viewName);

    ctl = GetObjectPtr(form, ctlID_ListView_FilterTrigger);
    lst = GetObjectPtr(form, ctlID_ListView_FilterList);
    if ( !(DBPrefs.flags & prefFlagUnuseFilters)
            && CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER)) {
#ifdef CONFIG_ICONS
        if (((ControlPtr)GetObjectPtr(form, ctlID_ListView_RepeatButton))->attr.visible) {
            FrmShowObject(form, FrmGetObjectIndex(form,
                                              ctlID_ListView_FilterTrigger));

            FrmHideObject(form, FrmGetObjectIndex(form,
                                              ctlID_ListView_RepeatButton));
            FrmHideObject(form, FrmGetObjectIndex(form,
                                              bmpID_RepeatButton));

        }
#endif
        switch( CurrentSource->ops.GetCurrentFilter(CurrentSource))
        {
        case FILTER1:
            CtlSetLabel(ctl, LstGetSelectionText(lst, 1));
        break;
        case FILTER2:
            CtlSetLabel(ctl, LstGetSelectionText(lst, 2));
        break;
        case FILTER3:
            CtlSetLabel(ctl, LstGetSelectionText(lst, 3));
        break;
        case FILTER4:
            CtlSetLabel(ctl, LstGetSelectionText(lst, 4));
        break;
        case FILTERALL:
        case FILTERNONE:
        default:
            CtlSetLabel(ctl, LstGetSelectionText(lst, 0));
        break;
        }
    }
#ifdef CONFIG_ICONS
	else if (!((ControlPtr)GetObjectPtr(form, ctlID_ListView_RepeatButton))->attr.visible) {
        if (CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER))
            CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, true);
        FrmHideObject(form, FrmGetObjectIndex(form,
                                              ctlID_ListView_FilterTrigger));

        FrmShowObject(form, FrmGetObjectIndex(form,
                                              ctlID_ListView_RepeatButton));
        FrmShowObject(form, FrmGetObjectIndex(form,
                                              bmpID_RepeatButton));

    }        
#endif
    /* Redraw the entire display. */
    FrmDrawForm(FrmGetActiveForm());
    GridDraw(&Grid);
    return true;
}

Boolean
ListViewHandleEvent(EventPtr event)
{
    FormPtr form;
    ListType * lst;
    UInt16 action;
    static char title[21];

    switch (event->eType) {
    case frmOpenEvent:
    {
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
        }
#endif
        /* Get the active list view definition. */
        ActiveViewIndex =
            CurrentSource->ops.GetOption_UInt16(CurrentSource,
                                                optionID_ListView_ActiveView);
        if (ActiveViewIndex == 0xFF)
            ActiveView = DS_GetView(CurrentSource, ActiveViewIndex);
        else
            ActiveView = CurrentSource->ops.GetView(CurrentSource, ActiveViewIndex);
		if ( (DBPrefs.flags & prefFlagRRAfterEdit) && 
			 CurrentSource->ops.RecalculateFields ) 
			CurrentSource->ops.RecalculateFields( CurrentSource );
			 
        ViewModel = ViewModel_New( CurrentSource, ActiveView);

        FindInfo.fieldNum = 0;
        FindInfo.caseSens = CurrentSource->ops.GetOption_Boolean(CurrentSource, optionID_LFind_CaseSensitive);
        FindInfo.wholeWord = CurrentSource->ops.GetOption_Boolean(CurrentSource, optionID_LFind_WholeWord);
        FindInfo.string[0] = '\0';

        /* Make the form title reflect the database name. */
        StrCopy(title, "DB: ");
        CurrentSource->ops.GetTitle(CurrentSource, title+4, sizeof(title)-4);
        if (FntCharsWidth(title, StrLen(title)) < 75)
            title[sizeof(title)-1] = '\0';
        else
            while (FntCharsWidth(title, StrLen(title)) > 75)
            {
                StrCopy( title+StrLen(title)-4, "...");
            }
        FrmSetTitle(form, title);

        /* Setup the action list and trigger. */
        SetupPopupList( form, ctlID_ListView_ActionList, popup_menu);

        /* Hide the "new" button if we are in read-only mode. */
        if (CurrentSource->openMode == dmModeReadOnly) {
#define HideObject(f,id) FrmHideObject((f),FrmGetObjectIndex((f),(id)))
#ifdef CONFIG_ICONS
            HideObject(form, bmpID_NewRButton);
            FrmShowObject(form, FrmGetObjectIndex(form,
                                                  bmpID_LockButton));
#endif
            HideObject(form, ctlID_ListView_NewButton);
#undef HideObject
        }
        ListViewUpdateForm(form, updateModelNew);

        return true;
    }
    case frmCloseEvent:
        CurrentSource->ops.SetOption_UInt16(CurrentSource,
                                            optionID_ListView_TopVisibleRecord,
                                            GridGetTopIndex(&Grid));

        GridFree(&Grid);
        CurrentSource->ops.PutView(CurrentSource, ActiveViewIndex, ActiveView);
        CurrentSource->ops.SetOption_UInt16(CurrentSource,
                                            optionID_ListView_ActiveView,
                                            ActiveViewIndex);

        FreePopupList( popup_menu);
        break;

    case frmUpdateEvent:
        form = FrmGetActiveForm();
        return ListViewUpdateForm(form, event->data.frmUpdate.updateCode);

    case frmGotoEvent:
        form = FrmGetActiveForm();
        GridSetTopIndex(&Grid, event->data.frmGoto.recordNum);
        GridDraw(&Grid);
        return true;

    case penDownEvent:
        if (GridHandleEvent(&Grid, event))
            return true;
        break;

    case gridSelectEvent:
      {
        UInt32 numRecords;
        CurrentSource->ops.Info(CurrentSource, NULL, NULL, NULL, NULL, &numRecords, NULL);
        if (event->data.tblSelect.row < numRecords) {
            CurrentRecord = event->data.tblSelect.row;
            IsNewRecord = false;
            FrmGotoForm(formID_EditView);
        }
        return true;
      }
    case gridHeaderSelectEvent:
        if (CurrentSource->openMode != dmModeReadOnly) {
            form = FrmGetActiveForm();
            action = ShowPopupList( form, ctlID_ListView_ActionList, event);

            switch( action) {
            case actionID_SortAscend:
                DoQuickSort( ActiveView->cols[event->data.tblSelect.column].fieldNum,
                                        SORT_DIRECTION_ASCENDING);
            GridDraw(&Grid);
            break;
            case actionID_SortDescend:
                DoQuickSort( ActiveView->cols[event->data.tblSelect.column].fieldNum,
                                        SORT_DIRECTION_DESCENDING);
            GridDraw(&Grid);
            break;
/*          case actionID_ResetFilter:
            if( CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER)) {
                CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, true);
                FrmUpdateForm(formID_ListView, updateRedrawGrid);
            }
            break;
*/          default :
            }
        }
    return true;

    case gridVerticalScrollersEvent:
        UpdateScrollers(event->data.generic.datum[1],
                        event->data.generic.datum[2]);
        return true;

    case gridHorizontalScrollersEvent:
        UpdateFieldButtons(event->data.generic.datum[1],
                           event->data.generic.datum[2]);
        return true;

#ifdef CONFIG_HANDERA
    case menuOpenEvent:
        if (FeatureSetHandera) {
            MenuAddItem(menuitemID_AppPrefs, menuitemID_HanderaRotate,
                                '\0', RotateString);
        }
        break;
#endif

    case menuEvent:
        return DoCommand(event->data.menu.itemID);

    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
        case ctlID_ListView_DoneButton:
            FrmGotoForm(formID_Chooser);
            return true;

        case ctlID_ListView_NewButton:
            IsNewRecord = true;
            FrmGotoForm(formID_EditView);
            return true;

        case ctlID_ListView_FindButton:
            FrmPopupForm( formID_FindDialog);
            return true;

        case ctlID_ListView_RepeatButton:
            LocalSearch(&FindInfo, 0);
            return true;

        case ctlID_ListView_FilterTrigger:
            if( (DBPrefs.flags & prefFlagUnuseFilters)
                    || !CurrentSource->ops.Capable(CurrentSource, DS_CAPABLE_LISTVIEW_FILTER))
                return true;
            form = FrmGetActiveForm();
            lst = GetObjectPtr(form, ctlID_ListView_FilterList);
            switch( CurrentSource->ops.GetCurrentFilter(CurrentSource))
            {
            case FILTER1:
                LstSetSelection(lst, 1);
            break;
            case FILTER2:
                LstSetSelection(lst, 2);
            break;
            case FILTER3:
                LstSetSelection(lst, 3);
            break;
            case FILTER4:
                LstSetSelection(lst, 4);
            break;
            case FILTERALL:
            case FILTERNONE:
            default:
                LstSetSelection(lst, 0);
            break;
            }
            switch (LstPopupList(lst)) {
            case 0:
                CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, false);
            break;
            case 1:
                CurrentSource->ops.SetFilter( CurrentSource, FILTER1, false);
            break;
            case 2:
                CurrentSource->ops.SetFilter( CurrentSource, FILTER2, false);
            break;
            case 3:
                CurrentSource->ops.SetFilter( CurrentSource, FILTER3, false);
            break;
            case 4:
                CurrentSource->ops.SetFilter( CurrentSource, FILTER4, false);
            break;
            }
            FrmUpdateForm(formID_ListView, updateRedrawGrid);
            return true;

        case ctlID_ListView_ViewTrigger:
            SelectViewTrigger();
            return true;
        }
        break;

    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case ctlID_ListView_UpButton:
            if (DBPrefs.flags & prefFlagUpArrowPage)
                GridScrollVertical(&Grid, winUp, GridGetNumberOfRows(&Grid));
            else
                GridScrollVertical(&Grid, winUp, 1);
            break;

        case ctlID_ListView_DownButton:
            if (DBPrefs.flags & prefFlagDownArrowPage)
                GridScrollVertical(&Grid, winDown, GridGetNumberOfRows(&Grid));
            else
                GridScrollVertical(&Grid, winDown, 1);
            break;

        case ctlID_ListView_LeftButton:
            GridScrollHorizontal(&Grid, winLeft, 1);
            GridDraw(&Grid);
            break;

        case ctlID_ListView_RightButton:
            GridScrollHorizontal(&Grid, winRight, 1);
            GridDraw(&Grid);
            break;
        }
        break;

    case keyDownEvent:
        switch (event->data.keyDown.chr) {
        case pageUpChr:
            if (DBPrefs.flags & prefFlagPageUpPage)
                GridScrollVertical(&Grid, winUp, GridGetNumberOfRows(&Grid));
            else
                GridScrollVertical(&Grid, winUp, 1);
            return true;

        case pageDownChr:
            if (DBPrefs.flags & prefFlagPageDownPage)
                GridScrollVertical(&Grid, winDown, GridGetNumberOfRows(&Grid));
            else
                GridScrollVertical(&Grid, winDown, 1);
            return true;

#ifdef CONFIG_JOGDIAL
        case upArrowChr:
#ifdef CONFIG_SONY
        case vchrJogUp :
#endif
#ifdef CONFIG_HANDERA
        case vchrPrevField :
#endif
            if (Grid.screenRowSelected != NoneScreenRowSelected) {
                if (Grid.screenRowSelected == 0)
                    GridScrollVertical(&Grid, winUp, 1);
                GridMoveSelectedLine(&Grid, winUp);
            } else
                GridScrollVertical(&Grid, winUp, 1);
            return true;

        case downArrowChr:
#ifdef CONFIG_SONY
        case vchrJogDown :
#endif
#ifdef CONFIG_HANDERA
        case vchrNextField :
#endif
            if (Grid.screenRowSelected != NoneScreenRowSelected) {
                if ( Grid.screenRowSelected == (GridGetNumberOfRows(&Grid) - 1))
                    GridScrollVertical(&Grid, winDown, 1);
                GridMoveSelectedLine(&Grid, winDown);
            } else
                GridScrollVertical(&Grid, winDown, 1);
            return true;

        case chrLineFeed:
#ifdef CONFIG_HANDERA
        case chrCarriageReturn : 
#endif
#ifdef CONFIG_SONY
        case vchrJogPush :
#endif
            if (Grid.screenRowSelected == NoneScreenRowSelected) {
                Grid.screenRowSelected = 0;
                GridMoveSelectedLine(&Grid, winUp);
            } else {
                CurrentRecord = GridGetTopIndex(&Grid) + Grid.screenRowSelected;
                IsNewRecord = false;
                FrmGotoForm(formID_EditView);
            }   
          return true;
#endif /*#ifdef CONFIG_JOGDIAL*/

        default:
            if (TxtGlueCharIsAlNum(event->data.keyDown.chr))
                LookUpList(ActiveView->cols[0].fieldNum, event->data.keyDown.chr);
        }
        break;

#ifdef CONFIG_HANDERA
    case displayExtentChangedEvent:
        form = FrmGetActiveForm();
        ListViewUpdateForm(form, updateModelNew);
    break;
#endif
    default:
        break;
    }

    return false;
}
