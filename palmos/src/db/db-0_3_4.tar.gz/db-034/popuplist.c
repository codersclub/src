#include <PalmOS.h>

#include "db.h"
#include "grid.h"
#include "popuplist.h"

#define GetObjectPtr(f,i) FrmGetObjectPtr((f),FrmGetObjectIndex((f),(i)))

static char ** Names;
static UInt16 * Actions;

void
SetupPopupList( FormPtr form, UInt16 lstID, ActionDetails *popup_menu)
{
	UInt16 i, j, count, lstIndex;
	RectangleType bounds;
	ListPtr lst;

	/* Count the number of Actions for the popup menu. */
	count = 0;
	for (i = 0; popup_menu[i].nameID != 0; ++i) {
		if (popup_menu[i].needsFeatureSet30) {
			if (FeatureSet30) count++;
		} else
		count++;
	}

	/* Allocate space for the strings and Actions. */
	Names = AllocateMemPtr(count * sizeof(char *));
	Actions = AllocateMemPtr(count * sizeof(UInt16));

	/* Fill in the name for each action. */
	for (i = j = 0; popup_menu[i].nameID != 0; ++i) {
		Boolean add = true;

		/* Do not add this item if a feature is missing. */
		if (popup_menu[i].needsFeatureSet30 && !FeatureSet30)
			add = false;

		/* Add the item to the popup Actions. */
		if (add) {
			Names[j] = CopyStringResource(popup_menu[i].nameID);
			Actions[j] = popup_menu[i].actionID;
			j++;
		}
	}

	/* Retrieve a pointer to the popup list. */
	lstIndex = FrmGetObjectIndex(form, lstID);
	lst = FrmGetObjectPtr(form, lstIndex);

	/* Setup the list choices, selection, and the trigger. */
	LstSetListChoices(lst, Names, count);
	LstSetHeight(lst, count);

	/* Determine the minimum width needed for the list. */
	FrmGetObjectBounds(form, lstIndex, &bounds);
	bounds.extent.x = 0;
	for (i = 0; i < count; ++i) {
		UInt16 width = FntCharsWidth(Names[i], StrLen(Names[i])) + 10;
		if (width > bounds.extent.x) bounds.extent.x = width;
	}
	FrmSetObjectBounds(form, lstIndex, &bounds);
}

void
FreePopupList( ActionDetails *popup_menu)
{
    UInt16 i, count;

    count = 0;
    for (i = 0; popup_menu[i].nameID != 0; ++i) {
	if (popup_menu[i].needsFeatureSet30) {
	    if (FeatureSet30) count++;
	} else
	    count++;
    }

    for (i = 0; i < count; ++i) DeallocateMemPtr(Names[i]);
    DeallocateMemPtr(Names);
    DeallocateMemPtr(Actions);
}


UInt16 ShowPopupList( FormPtr form, UInt16 lstID, EventPtr event)
{
	ListPtr lst;
	RectangleType r;
	Int16 result;
	UInt16 action;

	lst = GetObjectPtr(form, lstID);

	switch( event->eType) {
	case tblSelectEvent:
		TblUnhighlightSelection(event->data.tblSelect.pTable);
		TblGetItemBounds(event->data.tblSelect.pTable,
				event->data.tblSelect.row,
				event->data.tblSelect.column, &r);
	break;
	case gridHeaderSelectEvent:
		GridGetHeaderBounds( (GridType*) event->data.tblSelect.pTable,
				event->data.tblSelect.column, &r);
	break;
	default:
	}

	LstSetPosition(lst, r.topLeft.x, r.topLeft.y);
	LstSetSelection(lst, noListSelection);
	result = LstPopupList(lst);
	if (result >= 0)
		action = Actions[(UInt16) result];
	else
		action = -1;

	return action;
}
