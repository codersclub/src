#ifndef __POPUPLIST_H
#define __POPUPLIST_H

typedef struct {
	UInt16 nameID;
	UInt16 actionID;
	Boolean needsFeatureSet30;
} ActionDetails;

extern void SetupPopupList( FormPtr form, UInt16 lstID, ActionDetails *popup_menu);
extern void FreePopupList( ActionDetails *popup_menu);
extern UInt16 ShowPopupList( FormPtr form, UInt16 lstID, EventPtr event);


#endif