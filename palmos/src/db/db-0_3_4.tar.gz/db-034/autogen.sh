#!/bin/sh
#
# Generate all dynamicly-built files.

# Ensure that autoconf is present on the system.
(autoconf --version) < /dev/null > /dev/null 2>&1 || {
  echo
  echo "**Error**: You must have \`autoconf' installed to compile."
  echo "Download the appropriate package for your distribution,"
  echo "or get the source tarball at ftp://ftp.gnu.org/pub/gnu/"
  exit 1
}

# Run autoconf to generate configure from configure.in.
autoheader
autoconf
