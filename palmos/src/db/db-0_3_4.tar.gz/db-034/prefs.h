#ifndef _PREFS_H
#define _PREFS_H

#include "db.h"
#include "grid.h"

#define prefFlagEnableFind      0x0001
#define prefFlagUpArrowPage     0x0002
#define prefFlagDownArrowPage   0x0004
#define prefFlagPageUpPage      0x0008
#define prefFlagPageDownPage    0x0010
#define prefFlagRecordUpPage    0x0020
#define prefFlagRecordDownPage  0x0040
#define prefFlagOpenRDWRMode    0x0080
#define prefFlagUnuseFilters    0x0100
#define prefFlagRRAfterEdit     0x0200

#define chooserSortOrderAlphabetic 0
#define chooserSortOrderManual     1

/*Global Preferences declaration*/
typedef struct {
    /* Flags */
    UInt16 flags;

    /* Current chooser category. */
    UInt16 ChooserCurrentCategory;
    Boolean ChooserShowAllCategories;
    Boolean ChooserForceRescan;
    Boolean Unused[6];
    UInt8 ChooserSortOrder;

    /* Grid display*/
    UInt16 GridDisplay;
    UInt16 FloatDigits;
    UInt16 ColumnWidth;

    /* Font choice */
    FontID TheStdFont;
    FontID TheBoldFont;

} DBPrefsType, *DBPrefsPtr;

extern DBPrefsType DBPrefs;

extern void PopupDBPrefs(void) EDITSECT;
extern void InitPrefs(DBPrefsPtr prefs);

#endif
