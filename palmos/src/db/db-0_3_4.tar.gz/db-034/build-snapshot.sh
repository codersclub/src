#!/bin/sh
#
# Automate the building of the snapshot
# to do it manually each time.

if [ "x$1" = "x" ]; then
	lang="en"
else
	lang="$1"
fi


#  potential versions
light="--disable-sort"
full="--enable-icons --enable-color --enable-sony --enable-handera"

builds="light full"




# Form the filename that we will use.
ver=`echo $1 | sed -e 's/\./_/g'`
zipfile="../snapshot_${lang}.zip"

# Do some initial cleanups.
if [ -f Makefile ]; then
	make distclean
fi
rm -f "$zipfile"

for build in ${builds}; do

	if [ -f Makefile ]; then
		make clean
	fi
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	echo "+ Making ${build}"
	echo "+ Options: ${!build}"
	echo "++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++"
	./configure ${!build}
	make db-${lang}.prc
	mv db-${lang}.prc db-${build}.prc
	builtfiles="$builtfiles db-${build}.prc"
done

#zip "$zipfile" ${builtfiles}

