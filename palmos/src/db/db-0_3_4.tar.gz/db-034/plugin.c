#include <PalmOS.h>
#include <PalmCompatibility.h>
#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#include "util.h"
#include "enum.h"
#include "plugin.h"
#include "plug.h"

#define MAX_PLUGINS     10 
#define DBPluginType    'PLUG'
#define DBPluginResType 'PLUG'
#define DBPluginResID   0

#ifdef __GNUC__
#define PLUGINSECT  __attribute__ ((__section__("plugsect")))
#else
#define PLUGINSECT
#endif


typedef struct _PluginList{
        DmOpenRef               m_DbRef;
        VoidHand                m_ResH;
        PluginArgument          m_Arguments;
        UInt8                   m_ID;
        struct _PluginList      *m_Next;
}PluginList;
static PluginList       *g_FirstPlugin;
static PluginList       *g_PluginLaunch;

static DataSourceDriver *g_FirstDriver;
static PlugEnvironement g_PluginInfo;
static GridFilterF              *g_Filter;

static void InstallDriver(DataSourceDriver *newDriver) PLUGINSECT;
static void InstallFilter( GridFilterF *newFilter)PLUGINSECT;
static void StartListPlugin( PlugEnvironement *p_Info)PLUGINSECT;
static void ExecutePlugin( PluginList *p_Plugin, PlugEnvironement *p_Env)PLUGINSECT;
static void FreePluginList( char **p_NamesList, PluginType p_Screen)PLUGINSECT;
static Err LoadPlugIn( PluginList *p_PluginInfo, Boolean p_NewSearch, DmSearchStateType *p_SearchState)PLUGINSECT;
static void UnLoadPlugIn( PluginList *p_PluginInfo)PLUGINSECT;
static void FillPluginList( FormPtr p_Form, ListPtr p_List, char ***p_NamesList, PluginType p_Screen)PLUGINSECT;

/****************************************************************************************/
/*Instalation of different functionnality                                               */
/****************************************************************************************/
static void InstallUtils( AppliAccess *p_Access)
{
        Boolean l_DataSourceChanged = false;
        Boolean l_RecordChanged = false;

        if ( p_Access->getDriver != NULL)
                InstallDriver( (*p_Access->getDriver)());
        if ( p_Access->getFilter != NULL)
                InstallFilter( (*p_Access->getFilter)());
        if ( p_Access->getNewDataSource != NULL)
        {
                l_DataSourceChanged = true;
                CurrentSource = p_Access->getNewDataSource();
        }
        if ( p_Access->getNewRecord != NULL)
        {
                l_RecordChanged = true;
                CurrentRecord = p_Access->getNewRecord();
        }
}

static void InstallDriver(DataSourceDriver *newDriver)
{
    DataSourceDriver* last;

    last = g_FirstDriver;
    if ( last == NULL) {
        g_FirstDriver = newDriver;
    }
    else {
        while ( last->next != 0) last = last->next;
        last->next = newDriver;
    }
    newDriver->next = 0;
}

static void InstallFilter( GridFilterF *newFilter)
{
        g_Filter = newFilter;
}

static void StartListPlugin( PlugEnvironement *p_Info)
{
        MemMove( &g_PluginInfo, p_Info, sizeof( PlugEnvironement));

        FrmPopupForm( formID_PluginListDialog);
}

/****************************************************************************************/
/*Plugin List Form functions                                                            */
/****************************************************************************************/
static void
FillPluginList( FormPtr p_Form, ListPtr p_List, char ***p_NamesList, PluginType p_Screen)
{
        PluginList *l_Plugin;
        UInt16 count;

        l_Plugin = g_FirstPlugin;
        /* Count the number of drivers available. */
        count = 0;
        for( l_Plugin = g_FirstPlugin; l_Plugin; l_Plugin = l_Plugin->m_Next)
        { 
                if( l_Plugin->m_Arguments.m_Type & p_Screen)
                { 
                        count++;
                } 
        } 

        /* Allocate space for the names. */
        if (count) {
                *p_NamesList = AllocateMemPtr(count * sizeof(char *));

                /* Fill in the space with the driver names. */
                count = 0;
                for( l_Plugin = g_FirstPlugin; l_Plugin;  l_Plugin = l_Plugin->m_Next)
                {
                        if( l_Plugin->m_Arguments.m_Type & p_Screen)
                        {
                                LocalID l_DbID;
                                UInt16 l_CardNo;

                                (*p_NamesList)[ count] = AllocateMemPtr(32);
                                DmOpenDatabaseInfo(l_Plugin->m_DbRef, &l_DbID, NULL, NULL, &l_CardNo, NULL);
                                DmDatabaseInfo( l_CardNo, l_DbID, (*p_NamesList)[ count], NULL,
                                                NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
                                l_Plugin->m_ID = count;
                                count++;
                        }
                        else
                                l_Plugin->m_ID = -1;
                }
        }
        else
                *p_NamesList = NULL;


        /* Update the list with the names. */
        LstSetListChoices( p_List, *p_NamesList, count);
}

static void
FreePluginList( char **p_NamesList, PluginType p_Screen)
{
        PluginList *l_Plugin;
        UInt8   i;
        UInt16 count;

        l_Plugin = g_FirstPlugin;

        count = 0;
        for( l_Plugin = g_FirstPlugin; l_Plugin; l_Plugin = l_Plugin->m_Next)
        { 
                if( l_Plugin->m_Arguments.m_Type & p_Screen)
                { 
                        count++;
                } 
        } 
        for( i = 0; i < count; i++)
        {
                if( p_NamesList[ i])
                        DeallocateMemPtr(p_NamesList[ i]);
                p_NamesList[ i] = NULL;
        }
        if (p_NamesList)
                DeallocateMemPtr( p_NamesList);

}

static char **g_NamesList;
Boolean
PluginListHandleEvent( EventPtr p_Event)
{
        FormPtr l_Form;
        ListPtr l_List;
        UInt16  l_ListIndex;
 
        switch( p_Event->eType)
        {
        case frmOpenEvent:              
                l_Form = FrmGetActiveForm(); 
#ifdef CONFIG_HANDERA
                if (FeatureSetHandera) {
                    VgaFormModify(l_Form, vgaFormModify160To240);
                    if (!UtilCheckSizeForm(l_Form, 0)) {
                        FrmAlert(alertID_FormTooBig);
                        FrmReturnToForm(0);
                        return true;
                    }
                }
#endif
                g_PluginLaunch = NULL;  
                /* Update the driver list and trigger in the UI. */
                l_ListIndex = FrmGetObjectIndex(l_Form, ctlID_PluginListDialog_PluginList);
                l_List = FrmGetObjectPtr(l_Form, l_ListIndex);
                FillPluginList( l_Form, l_List, &g_NamesList, g_PluginInfo.m_Screen);
                FrmDrawForm( l_Form);
        return true;
        case frmCloseEvent: 
            FreePluginList( g_NamesList, g_PluginInfo.m_Screen);
        return true;
        case ctlSelectEvent: 
                switch( p_Event->data.ctlSelect.controlID)
                {
                case ctlID_PluginListDialog_StartButton:
                {
                        PluginList *l_Plugin;

                        l_Form = FrmGetActiveForm(); 
                        l_ListIndex = FrmGetObjectIndex(l_Form, ctlID_PluginListDialog_PluginList); 
                        l_List = FrmGetObjectPtr(l_Form, l_ListIndex); 

                        g_PluginLaunch = NULL;
                        for( l_Plugin = g_FirstPlugin; l_Plugin != NULL; l_Plugin = l_Plugin->m_Next) 
                        { 
                                if( l_Plugin->m_ID == LstGetSelection( l_List))
                                {
                                        g_PluginLaunch = l_Plugin;
                                }
                        } 
                        FrmReturnToForm(0);
                        if( g_PluginLaunch != NULL)
                                ExecutePlugin( g_PluginLaunch, &g_PluginInfo);
                        FreePluginList( g_NamesList, g_PluginInfo.m_Screen);
                }
                return true;
                case ctlID_PluginListDialog_CancelButton:
                        FrmReturnToForm(0);
                        FreePluginList( g_NamesList, g_PluginInfo.m_Screen);
                return true;
                } 
        default:
        break;
        }

        return false;

}

Boolean
PlugHandleEvent(EventPtr event)
{

        PluginList      *l_Plugin;
        
        l_Plugin = g_FirstPlugin;

        switch( event->eType)
        {
        case frmLoadEvent:
                while( l_Plugin != NULL)
                {
                        if( l_Plugin->m_Arguments.initFormHandleEvent != NULL)
                        {
                                if( l_Plugin->m_Arguments.initFormHandleEvent( event))
                                        return true;
                        }
                        l_Plugin = l_Plugin->m_Next;
                }
                ErrDisplay("unknown form ID");
        break;
        case plgCmdEvent:
                if( l_Plugin->m_Arguments.cmdPlugin != NULL)
                {
                        AppliAccess l_Access;

                        l_Access.getDriver = NULL;
                        l_Access.getFilter = NULL;
                        l_Access.getNewDataSource = NULL;
                        l_Access.getNewRecord = NULL;
                        l_Access.m_CurrentSource = CurrentSource;
                        l_Access.m_CurrentRecord = CurrentRecord;
                        (*l_Plugin->m_Arguments.cmdPlugin)( &l_Access, event->data.frmClose.formID);
                }
        break;
        case plgStopEvent:
                if( l_Plugin->m_Arguments.stopPlugin != NULL)
                {
                        AppliAccess l_Access;

                        l_Access.getDriver = NULL;
                        l_Access.getFilter = NULL;
                        l_Access.getNewDataSource = NULL;
                        l_Access.getNewRecord = NULL;
                        l_Access.m_CurrentSource = CurrentSource;
                        l_Access.m_CurrentRecord = CurrentRecord;
                        (*l_Plugin->m_Arguments.stopPlugin)( &l_Access);
                        InstallUtils( &l_Access);
                }
                g_PluginLaunch = NULL;
        break;
        default:
        break;
        }
        return false;
}

/****************************************************************************************/
/*Resource Loading and Unloading                                                        */
/****************************************************************************************/
static Err LoadPlugIn( PluginList *p_PluginInfo, Boolean p_NewSearch, DmSearchStateType *p_SearchState)
{
        // The following code will locate our plug-in resource (which may be in our own
        // resource file or in a separate PRC file to be opened by type and creator as
        // demonstrated below)
        PlugInMainF                             *StartFunction;
        UInt                                    l_CardNo;
        LocalID                                 l_PlugInDbID = 0;
        Err                                     l_Return = 0;


        // The following code could be modified to iterate through
        // multiple (separate) plug-in database(s), if desired...
        l_Return = DmGetNextDatabaseByTypeCreator(p_NewSearch, 
                                                p_SearchState,
                                                DBPluginType, 
                                                DBCreatorID,
                                                false /* all versions */,
                                                &l_CardNo,
                                                &l_PlugInDbID);

        if (l_Return)   // no plug-in database found
        {                                                               
                l_PlugInDbID = 0;
                p_PluginInfo->m_DbRef = 0;
                return l_Return;

        }       
        else    // we found a plug-in database
        {                                                                               
                if (l_PlugInDbID)
                {       // open the plug-in database
                        p_PluginInfo->m_DbRef = DmOpenDatabase( l_CardNo, l_PlugInDbID, dmModeReadOnly);
                }
        }

        // Get a handle to our plug-in resource
        p_PluginInfo->m_ResH = DmGetResource( DBPluginResType, DBPluginResID);

        // Make sure we found it
        if (!p_PluginInfo->m_ResH)
                return 1;

        // Lock down the plug-in so it doesn't move
        StartFunction = (PlugInMainF *) MemHandleLock( p_PluginInfo->m_ResH);
        p_PluginInfo->m_Arguments.m_Type = 0;
        p_PluginInfo->m_Arguments.restore = NULL;
        p_PluginInfo->m_Arguments.initFormHandleEvent = NULL;
        p_PluginInfo->m_Arguments.showAboutAlert = NULL;
        p_PluginInfo->m_Arguments.startPlugin = NULL;
        p_PluginInfo->m_Arguments.stopPlugin = NULL;
        p_PluginInfo->m_Arguments.cmdPlugin = NULL;
        StartFunction( &p_PluginInfo->m_Arguments);

        return 0;
}

static void UnLoadPlugIn( PluginList *p_PluginInfo)
{
        if( p_PluginInfo->m_Arguments.stopPlugin)
                (*p_PluginInfo->m_Arguments.restore)();
        if( p_PluginInfo->m_ResH)
        {
                // Unlock the plug-in resource
                MemHandleUnlock( p_PluginInfo->m_ResH);

                // Release the plug-in resource
                DmReleaseResource( p_PluginInfo->m_ResH);
        }

        // If we opened a separate plug-in database, close it now
        if( p_PluginInfo->m_DbRef)
        {
                DmCloseDatabase( p_PluginInfo->m_DbRef);
        }
}

static void
ExecutePlugin( PluginList *p_Plugin, PlugEnvironement *p_Env)
{
        AppliAccess l_Access;

        if ( !(p_Env->m_Screen & p_Plugin->m_Arguments.m_Type))
                return;

        l_Access.getDriver = NULL;
        l_Access.getFilter = NULL;
        l_Access.getNewDataSource = NULL;
        l_Access.getNewRecord = NULL;
        if( p_Plugin != NULL)
        { 
                switch( p_Env->m_Screen)
                { 
                case PLUGINTYPE_AUTOSTART:
                        l_Access.m_CurrentSource = NULL;
                        l_Access.m_CurrentRecord = 0;
                        (*p_Plugin->m_Arguments.startPlugin)( &l_Access);
                break; 
                case PLUGINTYPE_CHOOSER:
                        l_Access.m_CurrentSource = NULL;
                        l_Access.m_CurrentRecord = 0;
                        (*p_Plugin->m_Arguments.startPlugin)( &l_Access);
                break; 
                case PLUGINTYPE_LISTVIEW: 
                        l_Access.m_CurrentSource = CurrentSource;
                        l_Access.m_CurrentRecord = 0;
                        (*p_Plugin->m_Arguments.startPlugin)( &l_Access);
                break; 
                case PLUGINTYPE_EDIT:
                        l_Access.m_CurrentSource = CurrentSource;
                        l_Access.m_CurrentRecord = CurrentRecord;
                        (*p_Plugin->m_Arguments.startPlugin)( &l_Access);
                break;
                case PLUGINTYPE_ABOUT: 
                        (*p_Plugin->m_Arguments.showAboutAlert)();
                break; 
                default: 
                break; 
                }
        }
        InstallUtils( &l_Access);

}

/************************************************/
/*external functions                            */
/************************************************/
/* Prototypes for the driver initialization routines. */
void Plug_Setup(void)
{
        PluginList              l_Plugin;
        PluginList              *l_CurrentPlugin;
        PluginList              *l_NextPlugin;
        DmSearchStateType       l_SearchState;
        Boolean                 l_FirstSearch = true;
        UInt8                   i = 0;

        //Initialize Data for DB environnement
        g_FirstDriver = NULL;

        //Load Plugins
        g_FirstPlugin = NULL;
        l_CurrentPlugin = NULL;
        g_PluginLaunch = NULL;

        while( !LoadPlugIn( &l_Plugin, l_FirstSearch, &l_SearchState) && i < MAX_PLUGINS)
        {
                //change for the next LoadPlugin
                l_FirstSearch = false;
                //stack management
                if( l_Plugin.m_DbRef != 0)
                {
                        l_NextPlugin = AllocateMemPtr(sizeof(PluginList));
                        MemMove(l_NextPlugin, &l_Plugin, sizeof(PluginList));
                        l_NextPlugin->m_Next = NULL;
                        if( l_CurrentPlugin != NULL)
                                l_CurrentPlugin->m_Next = l_NextPlugin;
                        else
                                g_FirstPlugin = l_NextPlugin;
                        l_CurrentPlugin = l_NextPlugin;

                        //Plugin initialisation
                        g_PluginInfo.m_Screen = PLUGINTYPE_AUTOSTART;
                        ExecutePlugin( &l_Plugin, &g_PluginInfo);
                }
                i++;
        }
}

DataSourceDriver *Plug_GetDriver(void)
{
    return g_FirstDriver;
}

GridFilterF *Plug_GetFilter( void)
{
        return g_Filter;
}

void Plug_ShowList( PlugEnvironement *p_Info)
{
        StartListPlugin( p_Info);
}

void Plug_Restore(void)
{
        PluginList      *l_Plugin;
        PluginList      *l_CurrentPlugin;
        
        l_Plugin = g_FirstPlugin;
        l_CurrentPlugin = l_Plugin; 

        while( l_Plugin != NULL)
        {
                UnLoadPlugIn( l_Plugin);
                l_CurrentPlugin = l_CurrentPlugin->m_Next;
                DeallocateMemPtr( l_Plugin);
                l_Plugin = l_CurrentPlugin;
        }
}
