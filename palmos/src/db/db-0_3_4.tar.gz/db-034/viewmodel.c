#include <PalmOS.h>

#include "db.h"
#include "grid.h"
#include "io.h"

static DataSourceGetter Getter;
static DataSourceView * ActiveView;
static DataSource * Source;

static UInt16 ViewModel_GetColumnCount(void * __unused) SECT_UI;
static void ViewModel_GetColumnName(void *, UInt16, Char *, UInt32) SECT_UI;
static UInt16 ViewModel_GetColumnWidth(void *, UInt16) SECT_UI;
static void ViewModel_SetColumnWidth(void *, UInt16, UInt16) SECT_UI;
static void * ViewModel_LockIndex(void *, UInt16, Boolean) SECT_UI;
static void ViewModel_UnlockIndex(void *, UInt16, Boolean, void *) SECT_UI;
static GridCellType ViewModel_GetCellType(void *,UInt16,UInt16) SECT_UI;
static void ViewModel_GetCellString(void *, UInt16, UInt16, Char *,
                                    UInt32, void *) SECT_UI;
static Boolean ViewModel_GetCellBoolean(void *, UInt16, UInt16, void *_data) SECT_UI;
static Boolean bool_getter_GetBoolean(void * data, UInt16 fieldNum) SECT_UI;
static void ViewModel_SetCellBoolean(void *, UInt16, UInt16, Boolean,
                                     void *) SECT_UI;
static void ViewModel_GetCellID(void *, UInt16, UInt32 *) SECT_UI;
static Boolean ViewModel_Seek(void *, UInt16 *, Int16, Int16) SECT_UI;
static Boolean ViewModel_IsColumnEditable(void * __unused, UInt16 col) SECT_UI;

static GridModelType ViewModel = {
    GetColumnCount: ViewModel_GetColumnCount,
    GetColumnName: ViewModel_GetColumnName,
    GetColumnWidth: ViewModel_GetColumnWidth,
    SetColumnWidth: ViewModel_SetColumnWidth,
    LockIndex: ViewModel_LockIndex,
    UnlockIndex: ViewModel_UnlockIndex,
    GetCellType: ViewModel_GetCellType,
    GetCellString: ViewModel_GetCellString,
    GetCellBoolean: ViewModel_GetCellBoolean,
    SetCellBoolean: ViewModel_SetCellBoolean,
    GetCellID: ViewModel_GetCellID,
    Seek: ViewModel_Seek,
    IsColumnEditable: ViewModel_IsColumnEditable
};

GridModelType * ViewModel_New( DataSource * source, DataSourceView *activeView)
{
    ActiveView = activeView;
    Source = source;
    return &ViewModel;
}

static UInt16 ViewModel_GetColumnCount(void * __unused)
{
    return ActiveView->numCols;
}

static void ViewModel_GetColumnName(void * __unused, UInt16 col,
                                    Char * name, UInt32 len)
{
    StrNCopy(name,
             Source->schema.fields[ActiveView->cols[col].fieldNum].name,
             len);
}

static UInt16 ViewModel_GetColumnWidth(void * __unused, UInt16 col)
{
    return ActiveView->cols[col].width;
}

static void ViewModel_SetColumnWidth(void * __unused, UInt16 col, UInt16 width)
{
}

static void * ViewModel_LockIndex(void * __unused,
                                  UInt16 index, Boolean writable)
{
    void * row_data;

    Source->ops.LockRecord(Source, index, writable,
                                  &Getter, &row_data);
    return row_data;
}

static void ViewModel_UnlockIndex(void * __unused, UInt16 index,
                                  Boolean writable, void * row_data)
{
    Source->ops.UnlockRecord(Source, index, writable, row_data);
}

static GridCellType ViewModel_GetCellType(void * __unused,
                                          UInt16 index, UInt16 col)
{
    switch (Source->schema.fields[ActiveView->cols[col].fieldNum].type) {
    case FIELD_TYPE_BOOLEAN:
        return gridCellTypeBoolean;
    case FIELD_TYPE_NOTE:
        return gridCellTypeNote;
    case FIELD_TYPE_FLOAT:
      return gridCellTypeRJString;
    case FIELD_TYPE_STRING:
    case FIELD_TYPE_INTEGER:
    case FIELD_TYPE_LINK:
    case FIELD_TYPE_LINKED:
    default:
        return gridCellTypeString;
    }
}

static void ViewModel_GetCellString(void * __unused, UInt16 index, UInt16 col,
                                    Char * data, UInt32 len, void * row_data)
{
    const UInt16 fieldNum = ActiveView->cols[col].fieldNum;

    ConvertFieldToString( Source, &Getter, row_data,
                        fieldNum, data, len);
}

static Boolean ViewModel_GetCellBoolean(void * __unused, UInt16 index,
                                        UInt16 col, void * row_data)
{
    return Getter.GetBoolean(row_data, ActiveView->cols[col].fieldNum);
}

static Boolean bool_getter_GetBoolean(void * data, UInt16 fieldNum)
{
    return (data != 0) ? true : false;
}

static DataSourceGetter bool_getter = {
    GetBoolean: bool_getter_GetBoolean,
};

static void ViewModel_SetCellBoolean(void * __unused, UInt16 index,
                                     UInt16 col, Boolean b, void * row_data)
{
    Source->ops.SetField(Source, row_data,
                                ActiveView->cols[col].fieldNum, &bool_getter,
                                b ? ((void *) 1) : ((void *) 0));
}

static void ViewModel_GetCellID(void * __unused, UInt16 index, UInt32 * idP)
{
    UInt32 uniqueID;

    uniqueID = Source->ops.GetRecordID(Source, index);
    *idP = uniqueID;
}

static Boolean ViewModel_Seek(void * __unused, UInt16 * indexP,
                              Int16 offset, Int16 direction)
{
    return Source->ops.Seek(Source, indexP, offset, direction);
}

static Boolean ViewModel_IsColumnEditable(void * __unused, UInt16 col)
{
    Boolean result = false;

    if ((Source->schema.fields[ActiveView->cols[col].fieldNum].type) == FIELD_TYPE_BOOLEAN
            && (CurrentSource->openMode == dmModeReadWrite))
        result = true;

    return result;
}

