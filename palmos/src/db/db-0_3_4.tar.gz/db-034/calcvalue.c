/*
 * DB: Database Script Support
 * Copyright (C) 2001 by Scott Wallace.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <FloatMgr.h>

#include "db.h"
#include "calcvalue.h"
#include "double.h"
#include "prefs.h"


/**
 *  The Calculated Value provide a means of storing different data types
 *   that may be returned by the scripting engine.  Most of the 
 *   details of the script engine are hidden from the DB interface
 *   layer.  However, the interface layer must know about CalculatedValues
 *   about about certain general properties of scripts.
 *
 *  The script interface contains three functions:
 *    CompileScript
 *    DecompileScript
 *    ExecuteScript
 *
 *  Each of these three functions manipulates values in the CalculationInfo
 *   structure associated with the particualr script.
 *
 *  Initially scripts are compiled from their textual form into their
 *   executable form.
 *
 *
 *  -- CompileScript -- 
 *
 *
 * Scripts are compiled for a give purpose.  This purpose is
 *    represented as a ScriptExecutionContext. For example the purpose
 *    of calculating a field value in a record.  The purpose is passed
 *    to the the compiler so that errors can be flaged if the script
 *    is contains invalid operators for a particualr purpose or
 *    whatever.  Once compilation is complete, the CalculationInfo
 *    must be filled appropriately: 
 *     ->bytecode must contain a valid handle to the bytecode
 *     ->bytecode_sz specifies the length of the bytecode 
 *     ->access specifies the access requirements for the script.
 *    Access requirements are stored as a bitwise ORed value of
 *    the primitives in the enumeration ScriptAccessRequirements
 *
 *
 *  -- DecompileScript -- 
 *
 *
 *  Script decompilation is the inverse of compilation.  Here the
 *    script's bytecode is read (the CalculationInfo should have a valid
 *    handle to the bytecode) and a new handle is allocated from the
 *    scriptText which is then filled in appropriately.
 *
 *
 *  -- ExecuteScript -- 
 *
 *
 *  Finally during execution, the script is run.  Before a script is
 *   executed, its access requirement should be checked to make sure
 *   that it doesn't perform any operations that are illegal in the
 *   current context.  Once the script is run, its result is stored in
 *   a CalculatedValue.  The CalculatedValue returned by this function
 *   /MUST NOT/ keep pointers to data inside the bytecode.  Although
 *   this may be legitimate for intermediate parts of the the
 *   calculation, once the script's execution is complete, data
 *   referenced by such pointers should be copied into dynamically
 *   allocated memory and the type should be changed to
 *   CV_FIELD_TYPE_STRING_ALLOC or a similar variant.  This copying is
 *   critical because data in the CalculatedValue may be used after
 *   the byctecode associated with the script is unlocked. Once the
 *   CalculatedValue is no longer needed, the function CV_FreeData()
 *   should be called on it to free up any memory that was temporarily
 *   allocated for the result.
 *
 *
 * */




Int16 CV_GetPackedSize( CalculationData *c ) {

  switch ( c->returnType ) {

  case CV_FIELD_TYPE_ALLOC_STRING:
  case FIELD_TYPE_STRING:
  case CV_FIELD_TYPE_UNKNOWN:
	return CV_MAX_STRING_SIZE + 1;
  case FIELD_TYPE_FLOAT:
	return sizeof( double ) + 1;
  case CV_FIELD_TYPE_NA:
	return 1;
  default:
	return sizeof( Int32 ) + 1;
  }

}



/**
 * Print the string representation of the CalculatedValue
 */
void CV_PrintValue( CalculatedValue *v, char *buf, Int32 len ) {

  switch ( v->info ) {

  case FIELD_TYPE_INTEGER:
	StrIToA( buf, v->value.i );
	break;
	
  case FIELD_TYPE_FLOAT:
#ifdef GLOBAL_ACCESS
	DoublePrintValue( v->value.d, buf, DBPrefs.FloatDigits);
#else
	DoublePrintValue( v->value.d, buf, 3);
#endif
	break;

  case CV_FIELD_TYPE_ALLOC_STRING:
  case FIELD_TYPE_STRING:
	StrNCopy( buf, v->value.s, len );
	buf[len-1] = '\0';
	break;

  case FIELD_TYPE_DATE:
	DateToAscii( v->value.ymd.month, v->value.ymd.day, v->value.ymd.year,
				 PrefGetPreference(prefDateFormat), buf);
	break;
  case FIELD_TYPE_TIME:
	TimeToAscii( v->value.t.hour, v->value.t.min, 
				 PrefGetPreference(prefTimeFormat), buf );
	break;

  case CV_FIELD_TYPE_DURATION: 
  {
	  Int32 tv;
	  UInt16 i1, i2, i3;
	  char mins[3];

	  if ( v->value.i >= 0 ) tv = v->value.i;
	  else tv = -1L * v->value.i;

	  i1 = (UInt16) (tv / MINUTES_PER_DAY );
	  i2 = (UInt16) (tv % MINUTES_PER_DAY );
	  i2 /= MINUTES_PER_HOUR;
	  i3 = (UInt16) (tv % MINUTES_PER_HOUR);
	  StrPrintF( mins, "%2d", i3 );
	  if ( i3 < 10 ) mins[0] = '0';
	  if ( v->value.i < 0 )
		  StrPrintF( buf, "-%ud,%u:%s", i1, i2, mins );
	  else 
		  StrPrintF( buf, "%ud,%u:%s", i1, i2, mins );
	  break;
  }
  case CV_FIELD_TYPE_NA:
	StrCopy( buf, "[n/a]" );
	break;
  case CV_FIELD_TYPE_BROKEN:
	StrCopy( buf, "[broken]");
	break;


  default:
	StrCopy( buf, "?Who Knows?" );
	break;
  }

}
