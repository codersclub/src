
#define bmpID_ExitButton			1100
#define bmpID_NewDButton			1101
#define bmpID_NewRButton			1102
#define bmpID_FindButton			1103
#define bmpID_RepeatButton   		1104
#define bmpID_SaveButton			1105
#define bmpID_UndoButton			1106
#define bmpID_DeleteButton			1107
#define bmpID_DuplicateButton			1108
#define bmpID_ModifyButton			1109
#define bmpID_LockButton			1110

#define HbmpID_ExitButton			5196
#define HbmpID_NewDButton			5197
#define HbmpID_NewRButton			5198
#define HbmpID_FindButton			5199
#define HbmpID_RepeatButton   		5200
#define HbmpID_SaveButton			5201
#define HbmpID_UndoButton			5202
#define HbmpID_DeleteButton			5203
#define HbmpID_DuplicateButton		5204
#define HbmpID_ModifyButton			5205
#define HbmpID_LockButton			5206