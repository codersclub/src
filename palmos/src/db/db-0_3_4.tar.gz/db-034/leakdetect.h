#ifndef _LEAK_DETECT_H_
#define _LEAK_DETECT_H_

#define	 ASSERT(c)         ErrFatalDisplayIf(!(c),#c)

#include "config.h"

#ifdef DETECT_LEAKS
MemPtr AllocateMemPtrFn(long size, char *file, long line);
Err   DeallocateMemPtrFn(MemPtr addr, char *file, long line);
MemHandle AllocateMemHandleFn(long size, char *file, long line);
Err DeallocateMemHandleFn(MemHandle addr, char *file, long line);
void RecordMemInfoFn( void *addr, char *str, char *file, long line ); 

#define AllocateMemPtr(size) AllocateMemPtrFn(size,__FILE__,__LINE__)
#define DeallocateMemPtr(addr) DeallocateMemPtrFn(addr,__FILE__,__LINE__)
#define AllocateMemHandle(size) AllocateMemHandleFn(size,__FILE__,__LINE__)
#define DeallocateMemHandle(addr) DeallocateMemHandleFn(addr,__FILE__,__LINE__)
#define RecordMemInfo(addr,str) RecordMemInfoFn(addr,str,__FILE__,__LINE__)
#else /* ! DETECT_LEAKS */
#define AllocateMemPtr(size) MemPtrNew(size)
#define DeallocateMemPtr(addr) MemPtrFree(addr)
#define AllocateMemHandle(size) MemHandleNew(size)
#define DeallocateMemHandle(addr) MemHandleFree(addr)
#define RecordMemInfo(addr,str) {}
#endif /* ! DETECT_LEAKS */

#endif 



