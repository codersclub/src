/*
 * Link Field Type Implementation
 * Copyright (C) 2000-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 * Copyright (C) 2001 by Marc Chalain (marc-chalain@voila.fr)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>
#include <PalmOSGlue.h>

#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#include "grid.h"
#include "enum.h"
#include "util.h"
#include "io.h"
#include "double.h"
#ifdef CONFIG_SCRIPTS
#include "calcvalue.h"
#endif

static void UpdateFieldButtons(Boolean, Boolean) SECT_UI2;
static void UpdateScrollers(Boolean, Boolean) SECT_UI2;

void
LinkGo( UInt32 chooserRecordID, UInt16 fieldNum, LinkPtr link)
{
    GoToParamsPtr params = 0;
    ChooserRecord * record;
    MemHandle h = 0;
    UInt16 index;

    if (chooserRecordID == 0) {
        FrmAlert(alertID_NoLinkedDatabase);
        return;
    }

    if ((link->uniqID != 0) && (FrmAlert(alertID_LinkGo) == 0)){
        DataSource * source;
        UInt32 creator = DBCreatorID;
        DmSearchStateType searchState;
        UInt16 cardNo;
        LocalID dbId;
        Err err;
        UInt32 result = 0;

        /* open the Chooser to retrieve information about the database*/
        Chooser_Open();
    
        if (DmFindRecordByID(Chooser_Ref(), chooserRecordID, &index)){
            FrmAlert(alertID_NoLinkedDatabase);
            goto LinkGoErr;
        }

        h = DmQueryRecord(Chooser_Ref(), index);
        if ( !h || (MemHandleSize(h) - sizeof(ChooserRecord)) < sizeof(DataSourceChooserKey)){
            FrmAlert(alertID_NoLinkedDatabase);
            goto LinkGoErr;
        }

        record = MemHandleLock(h);

        source = OpenDataSource(DriverList, dmModeReadOnly,
                                    record->sourceID,
                                    (void *) (record + 1),
                                    MemHandleSize(h) -
                                    sizeof(ChooserRecord));

        if (!source) {
            FrmAlert(alertID_NoLinkedDatabase);
            goto LinkGoErr;
        }

        params = AllocateMemPtr(sizeof(GoToParamsType));
        MemPtrSetOwner(params, 0);

        source->ops.Info( source, &(params->dbCardNo),
                                &(params->dbID), 0, &creator,
                                0, 0);

        params->recordNum = source->ops.GetRecordIndex( source, link->uniqID);

        MemHandleUnlock(h);

        CloseDataSource( source);

        /*look for the dbID and cardNo of the application to launch*/
        err=DmGetNextDatabaseByTypeCreator(true, &searchState,
                                            'appl', creator,
                                            true, &cardNo, &dbId);

        /*if there are no default application for the databse we try to open it with Pilot-DB*/
        if (err)
            err=DmGetNextDatabaseByTypeCreator(true, &searchState,
                                                'appl', DBCreatorID,
                                                true, &cardNo, &dbId);

        if (err)
            goto LinkGoErr;

        SysAppLaunch(cardNo, dbId, 0,
                    sysAppLaunchCmdGoTo, (void *)params, &result);

        Chooser_Close();
    }
    return;
LinkGoErr:
    if (params)
        DeallocateMemPtr(params);
    if (h)
        MemHandleUnlock(h);
    Chooser_Close();
    return;
}

static GridType Grid;
static GridModelType * ViewModel;
static LinkPtr Link;
static DataSource * SourceLink;
static UInt16 FieldNum;

static void
UpdateFieldButtons(Boolean scrollLeft, Boolean scrollRight)
{
    FormPtr form;
    UInt16 leftIndex, rightIndex;

    form = FrmGetActiveForm();
    leftIndex = FrmGetObjectIndex(form, ctlID_LinkSelect_LeftButton);
    rightIndex = FrmGetObjectIndex(form, ctlID_LinkSelect_RightButton);

    if (scrollLeft)
        FrmShowObject(form, leftIndex);
    else
        FrmHideObject(form, leftIndex);

    if (scrollRight)
        FrmShowObject(form, rightIndex);
    else
        FrmHideObject(form, rightIndex);
}

static void
UpdateScrollers(Boolean scrollUp, Boolean scrollDown)
{
    FormPtr form;
    UInt16 upIndex, downIndex;

    form = FrmGetActiveForm();
    upIndex = FrmGetObjectIndex(form, ctlID_LinkSelect_UpButton);
    downIndex = FrmGetObjectIndex(form, ctlID_LinkSelect_DownButton);
    FrmUpdateScrollers(form, upIndex, downIndex, scrollUp, scrollDown);
}

Boolean
LinkSelectHandleEvent( EventPtr event)
{
    FormPtr form;

    switch (event->eType) {
    case frmOpenEvent:
        form = FrmGetActiveForm();
#ifdef CONFIG_HANDERA
        if (FeatureSetHandera) {
            VgaFormModify(form, vgaFormModify160To240);
            if (!UtilCheckSizeForm(form, 0)) {
                FrmAlert(alertID_FormTooBig);
                FrmReturnToForm(0);
                return true;
            }
        }
#endif
        GridInit(&Grid, form, ctlID_LinkSelect_Grid,
                         ctlID_LinkSelect_GridCheckbox, ViewModel, 0);
        GridSetTopIndex(&Grid, 0);
        FrmDrawForm( form);
        GridDraw(&Grid);
    return true;

    case frmUpdateEvent:
        GridDraw(&Grid);
    return true;
/* unuse for a popup form
    case frmCloseEvent:
    return false;
*/
    case penDownEvent:
        if (GridHandleEvent(&Grid, event))
            return true;
    break;

    case gridSelectEvent:
    {
        DataSourceGetter getter;
        void * rec_data;

        Link->uniqID = SourceLink->ops.GetRecordID(SourceLink, event->data.tblSelect.row);
        SourceLink->ops.LockRecord(SourceLink, event->data.tblSelect.row, false,
                  &getter, &rec_data);

        ConvertFieldToString( SourceLink, &getter, rec_data,
                            FieldNum, Link->name, 32);

        SourceLink->ops.UnlockRecord(SourceLink, event->data.tblSelect.row, false,
                    rec_data);
        GridFree(&Grid);
        CloseDataSource( SourceLink);
        FrmReturnToForm( 0);
        FrmUpdateForm( formID_EditView, 0x02);
    }
    return true;

    case gridVerticalScrollersEvent:
        UpdateScrollers(event->data.generic.datum[1],
                        event->data.generic.datum[2]);
    return true;

    case gridHorizontalScrollersEvent:
        UpdateFieldButtons(event->data.generic.datum[1],
                           event->data.generic.datum[2]);
        return true;

    case ctlSelectEvent:
        switch (event->data.ctlSelect.controlID) {
	    case ctlID_LinkSelect_DoneButton:
            GridFree(&Grid);
            CloseDataSource( SourceLink);
            FrmReturnToForm( 0);
            FrmUpdateForm( formID_EditView, 0x02);
        return true;
        default:
        }
    break;

    case ctlRepeatEvent:
        switch (event->data.ctlRepeat.controlID) {
        case ctlID_LinkSelect_UpButton:
            GridScrollVertical(&Grid, winUp, 1);
            break;

        case ctlID_LinkSelect_DownButton:
            GridScrollVertical(&Grid, winDown, 1);
            break;

        case ctlID_LinkSelect_LeftButton:
            GridScrollHorizontal(&Grid, winLeft, 1);
            GridDraw(&Grid);
            break;

        case ctlID_LinkSelect_RightButton:
            GridScrollHorizontal(&Grid, winRight, 1);
            GridDraw(&Grid);
            break;
        }
    break;

    case keyDownEvent:
        switch (event->data.keyDown.chr) {
        case pageUpChr:
            GridScrollVertical(&Grid, winUp, GridGetNumberOfRows(&Grid));
            return true;
        case pageDownChr:
            GridScrollVertical(&Grid, winDown, GridGetNumberOfRows(&Grid));
            return true;
        case upArrowChr:
            GridScrollVertical(&Grid, winUp, 1);
            return true;
        case downArrowChr:
            GridScrollVertical(&Grid, winDown, 1);
            return true;
        }
    break;
    default:
    }
    return false;
}

Boolean
LinkSelect( UInt32 chooserRecordID, UInt16 fieldNum, LinkPtr link)
{
    ChooserRecord * record;
    MemHandle h;
    UInt16 index;

    if (chooserRecordID == 0) {
        FrmAlert(alertID_NoLinkedDatabase);
        return false;
    }

    Chooser_Open();
    if (DmFindRecordByID(Chooser_Ref(), chooserRecordID, &index)){
        Chooser_Close();
        FrmAlert(alertID_NoLinkedDatabase);
        return false;
    }

    h = DmQueryRecord(Chooser_Ref(), index);
    record = MemHandleLock(h);

    SourceLink = OpenDataSource(DriverList, dmModeReadOnly,
                            record->sourceID,
                            (void *) (record + 1),
                            MemHandleSize(h) -
                            sizeof(ChooserRecord));
    MemHandleUnlock(h);
    Chooser_Close();

    ViewModel = ViewModel_New( SourceLink, DS_GetView(SourceLink, 0));
    Link = link;
    FieldNum = fieldNum;
    FrmPopupForm(formID_LinkSelect);

    return true;
}

Boolean
LinkUpdate( UInt32 chooserRecordID, UInt16 fieldNum, LinkPtr link)
{
    Boolean match = false;
    ChooserRecord * record;
    MemHandle h;
    UInt16 index;
    DataSourceGetter getter;
    void * rec_data;
    char str[33];
    Int16 (*Compare)(const Char*, UInt16, UInt16 *,
                     const Char*, UInt16, UInt16*);

    if (chooserRecordID == 0) {
//        FrmAlert(alertID_NoLinkedDatabase);
        return false;
    }

    Chooser_Open();

    if (DmFindRecordByID(Chooser_Ref(), chooserRecordID, &index)){
        Chooser_Close();
//        FrmAlert(alertID_NoLinkedDatabase);
        return false;
    }

    h = DmQueryRecord(Chooser_Ref(), index);
    record = MemHandleLock(h);

    SourceLink = OpenDataSource(DriverList, dmModeReadOnly,
                            record->sourceID,
                            (void *) (record + 1),
                            MemHandleSize(h) -
                            sizeof(ChooserRecord));
    MemHandleUnlock(h);
    Chooser_Close();

    Compare = IntlGlueGetRoutineAddress(intlTxtCompare, TxtLatinCompare);

    if (!link->uniqID) {
        /* The record doen't know the link record*/
        UInt16 recNum = 0;
        while (1) {
            if (! SourceLink->ops.Seek(SourceLink, &recNum, 0,
                                        dmSeekForward)) {
                break;
            }

            /* Lock down the record. */
            SourceLink->ops.LockRecord(SourceLink, recNum, false,
                                        &getter, &rec_data);

            match = false;
            /* Search the single field. */
            ConvertFieldToString(SourceLink, &getter, rec_data,
                                fieldNum, str, 32);
            match = !Compare(link->name, StrLen(link->name), 0, str, StrLen(str), 0);

            /* Unlock the record. */
            SourceLink->ops.UnlockRecord(SourceLink, recNum,
                                            false, rec_data);

            /* If a match was found, then stop the search. */
            if (match) {
                link->uniqID = SourceLink->ops.GetRecordID(SourceLink, recNum);
                break;
            }

            /* Increment the record number. */
            recNum++;
        }
    } else {
        /* The record knows the link record*/
        if (SourceLink->ops.GetRecordIndex(SourceLink, link->uniqID) == 0xFFFF){
            link->uniqID = 0;
            CloseDataSource( SourceLink);
            return false;
        }

        SourceLink->ops.LockRecord(SourceLink, SourceLink->ops.GetRecordIndex(SourceLink, link->uniqID), false,
                    &getter, &rec_data);

        ConvertFieldToString(SourceLink, &getter, rec_data,
                                fieldNum, str, 32);
        match = Compare(link->name, StrLen(link->name), 0, str, StrLen(str), 0);

        if (match){
            StrNCopy( link->name, str, 32);
        }

        SourceLink->ops.UnlockRecord(SourceLink, SourceLink->ops.GetRecordIndex(SourceLink, link->uniqID), false,
                        rec_data);
    }

    CloseDataSource( SourceLink);
   return match;
}

Boolean
LinkIsUsefull( UInt32 chooserRecordID)
{
    UInt16 index;

    if (chooserRecordID == 0) {
        return false;
    }

    Chooser_Open();

    if (DmFindRecordByID(Chooser_Ref(), chooserRecordID, &index)){
        Chooser_Close();
        return false;
    }
    Chooser_Close();
    return true;
}
