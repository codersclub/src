/*
 * DB: Database I/O code
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307 USA
 */

#include <PalmOS.h>
#include <TxtGlue.h>

#include "db.h"
#include "enum.h"
#include "io.h"
#ifdef CONFIG_PLUGINS
#include "plug.h"
#endif
#include "double.h"
#ifdef CONFIG_SCRIPTS
#include "calcvalue.h"
#endif
#include "prefs.h"


DataSource * CurrentSource = 0;

/*
 * Generic implementations of data source driver methods.
 *
 * These helper routines are called directly and indirectly by the
 * actual data source drivers. Generally, they implement routines
 * which are only specific to PalmOS database and not the specific
 * format.
 */

Boolean
DS_CheckTitle(const char* title)
{
    LocalID dbID;

    dbID = DmFindDatabase(0, title);
    return (dbID == 0);
}

void
DS_Delete(void * key_data, UInt32 key_size)
{
    DataSourceChooserKey * key = (DataSourceChooserKey *) key_data;
    LocalID dbID;

    dbID = DmFindDatabase(key->cardNo, key->name);
    if (dbID) {
        DmDeleteDatabase(key->cardNo, dbID);
    }
}

void
DS_Enumerate(DataSourceEnumerationFunc callback, void * arg,
                 UInt32 type, UInt32 creator, UInt16 sourceID)
{
    DmSearchStateType state;
    Boolean flag;
    LocalID dbID;
    DataSourceChooserKey key;

    flag = true;
    while (DmGetNextDatabaseByTypeCreator(flag, &state, type, creator,
                                          false, &key.cardNo, &dbID) == 0) {
        MemSet(&key, sizeof(key), 0);
        DmDatabaseInfo(key.cardNo, dbID, key.name, 0,0,0,0,0,0,0,0,0,0);
        callback(arg, key.name, sourceID, &key, sizeof(key));
        flag = false;
    }
    flag = true;
}

static Boolean
DS_PDB_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation,
                  FindParamsPtr params, UInt32 type, UInt32 creator,
                  Err (*OpenPDB)(DataSource *, UInt16, UInt16, LocalID))
{
    struct {
        DmSearchStateType state;
        UInt16 cardNo;
        LocalID dbID;
    } data;
    Err err;
    Boolean r;

    /* Fill in the search state from preferences if we are continuing
     * or initialize if this is the first time.  */
    if (! continuation) {
        err = DmGetNextDatabaseByTypeCreator(true, &data.state,
                                             type, creator, false,
                                             &data.cardNo, &data.dbID);
        if (err != 0) {
            /* No more databases of this type to be found. */
            return false;
        }
    } else {
        UInt16 prefsSize = sizeof(data);

        PrefGetAppPreferences(DBCreatorID, prefID_GFind_DataSource, &data,
                              &prefsSize, false);
    }

    do {
        DataSource * source = (DataSource *)AllocateMemPtr(sizeof(DataSource));

        /* Open the data source. */
        err = OpenPDB(source, params->dbAccesMode, data.cardNo, data.dbID);
        if (err != 0) {
            /* If we cannot open the database, jump to the next one. */
            DeallocateMemPtr(source);
            goto next_db;
        }

        /* Reset the record number if this is not a continuation. */
        if (continuation)
            continuation = false;
        else
            params->recordNum = 0;

        /* Let the global find code have a go at the database. */
        r = callback(params, source, data.cardNo, data.dbID);

        /* Close the data source. */
        source->ops.Close(source);
        DeallocateMemPtr(source);

        /* Check if global find code wants us to save our position. */
        if (r) {
            PrefSetAppPreferences(DBCreatorID, prefID_GFind_DataSource, 0,
                                  &data, sizeof(data), false);
            return true;
        }

        /* Get the next data source. */
    next_db:
        err = DmGetNextDatabaseByTypeCreator(false, &data.state,
                                             type, creator, false,
                                             &data.cardNo, &data.dbID);
    } while (!err);

    /* No more databases to be found. */
    return false;
}

Boolean
DS_GlobalFind(DataSourceGlobalFindFunc callback, Boolean continuation,
                  FindParamsPtr params, UInt32 type, UInt32 creator,
                  Err (*OpenPDB)(DataSource *, UInt16, UInt16, LocalID))
{
    return DS_PDB_GlobalFind(callback, continuation, params, type, creator, OpenPDB);
}

static Boolean
DS_PDB_IsPresent(void * key_data, UInt32 key_size,
                 UInt32 ds_type, UInt32 ds_creator)
{
    DataSourceChooserKey* key = (DataSourceChooserKey *) key_data;
    LocalID dbID;
    UInt32 creator, type;

    if ((dbID = DmFindDatabase(key->cardNo, key->name)) != 0
        && DmDatabaseInfo(key->cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                          &type, &creator) == 0
        && creator == ds_creator
        && type == ds_type)
        return true;

    return false;
}

Boolean
DS_IsPresent(void * key_data, UInt32 key_size,
                 UInt32 ds_type, UInt32 ds_creator)
{
    if (key_size == sizeof(DataSourceChooserKey)) {
        return DS_PDB_IsPresent(key_data, key_size, ds_type, ds_creator);
    }else
        return false;
}

static Boolean
DS_PDB_CompareKey(void * key1_data, UInt16 key1_size,
                  void * key2_data, UInt16 key2_size)
{
    DataSourceChooserKey * key1 = (DataSourceChooserKey *) key1_data;
    DataSourceChooserKey * key2 = (DataSourceChooserKey *) key2_data;

    return (key1->cardNo == key2->cardNo)
        && (StrCompare(key1->name, key2->name) == 0);
}

Boolean
DS_CompareKey(void * key1_data, UInt16 key1_size,
              void * key2_data, UInt16 key2_size)
{
    if (key1_size == sizeof(DataSourceChooserKey)
            && key2_size == sizeof(DataSourceChooserKey)) {
        return DS_PDB_CompareKey(key1_data, key1_size, key2_data, key2_size);
    }else
        return false;
}

static Err
WriteDBData(const void * dataP, UInt32 * sizeP, void * userDataP)
{
    Err err;

    /* Try to send as many bytes as were requested by the caller. */
    *sizeP = ExgSend((ExgSocketPtr)userDataP, (void *)dataP, *sizeP, &err);
    return err;
}

Err 
DS_PDB_Exchange(void * key_data, UInt16 key_size)
{
    DataSourceChooserKey * key = (DataSourceChooserKey *) key_data;
    LocalID dbID;
    char name[dmDBNameLength + 4];
    char url[dmDBNameLength + 20];
    ExgSocketType exgSocket;
    Err err;
    UInt16 attr;

    /* Make sure that the key has a valid size. */
    if (key_size != sizeof(DataSourceChooserKey))
        return 0;

    /* Retrieve the location in memory of this database. */
    dbID = DmFindDatabase(key->cardNo, key->name);
    if (!dbID)
        return DmGetLastErr();

    /* Form the file name that we will send. */
    DmDatabaseInfo(key->cardNo, dbID, name, 0, &attr, 0, 0, 0, 0, 0, 0, 0, 0);
    StrCat(name, ".pdb");

    if (attr & dmHdrAttrCopyPrevention){
        return dmErrCantOpen;
    }

    /* Create exgSocket structure. */
    MemSet(&exgSocket, sizeof(exgSocket), 0);
    exgSocket.description = name;
#ifdef GLOBAL_ACCESS
    if (FeatureSet40)
        StrPrintF( url, "%s%s", exgSendBeamPrefix, name);
    else
#endif
        StrCopy( url, name);
    exgSocket.name = url;

    /* Initiate the exchange. */
    err = ExgPut(&exgSocket);
    if (!err) {
        err = ExgDBWrite(WriteDBData, &exgSocket, NULL, dbID, key->cardNo);
        err = ExgDisconnect(&exgSocket, err);
    }

    return err;
}


/*
 * Generic implementations of data source methods.
 *
 * These helper routines are called directly and indirectly by the
 * actual data source functions. Generally, they implement routines
 * which are only specific to PalmOS database and not the specific
 * format.
 */
UInt16
DS_GetKey(DataSource * source, void * buffer)
{
    if (buffer) {
        MemMove( buffer, source->key.data, source->key.size);
    }
    return source->key.size;
}

void
DS_PDB_GetPDB(DataSource * source, UInt16 * cardNo_ptr, LocalID * dbID_ptr)
{
    DmOpenDatabaseInfo(source->db, dbID_ptr, 0, 0, cardNo_ptr, 0);
}

void
DS_PDB_GetTitle(DataSource * source, char * buf, UInt32 len)
{
    char name[dmDBNameLength];
    UInt16 cardNo;
    LocalID dbID;

    DmOpenDatabaseInfo(source->db, &dbID, 0, 0, &cardNo, 0);
    DmDatabaseInfo(cardNo, dbID, name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
    StrNCopy(buf, name, len);
    buf[len-1] = '\0';
}

void
DS_PDB_SetTitle(DataSource * source, const char * title,
                void ** key_data_ptr, UInt16 * key_size_ptr)
{
    char name[dmDBNameLength];
    UInt16 cardNo;
    LocalID dbID;
    DataSourceChooserKey * key;

    /* Make the title fit within the PalmOS limits. */
    StrNCopy(name, title, sizeof(name));
    name[sizeof(name)-1] = '\0';

    /* Set the database title. */
    DmOpenDatabaseInfo(source->db, &dbID, 0, 0, &cardNo, 0);
    DmSetDatabaseInfo(cardNo, dbID, name, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);

    /* Return a new key for the chooser. */
    key = (DataSourceChooserKey *) AllocateMemPtr(sizeof(DataSourceChooserKey));
    MemSet(key, sizeof(*key), 0);
    key->cardNo = cardNo;
    StrNCopy(key->name, name, sizeof(key->name));
    key->name[sizeof(key->name) - 1] = '\0';
    *key_data_ptr = key;
    *key_size_ptr = sizeof(*key);
}

void
DS_PDB_Info(DataSource * source, UInt16 * cardNo,
                LocalID * dbID, UInt32 * dbType, UInt32 * creator,
                UInt32 * numRecord, UInt32 * size)
{
    UInt16 tcardno;
    LocalID tdbID;

    DmOpenDatabaseInfo(source->db, &tdbID, 0, 0, &tcardno, 0);
    DmDatabaseInfo(tcardno, tdbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, dbType, creator);
    DmDatabaseSize(tcardno, tdbID, numRecord, size, 0);
    if (cardNo) *cardNo = tcardno;
    if (dbID) *dbID = tdbID;
}

DataSourceDriver *
GetInternalDataSources(void)
{
    DataSourceDriver* driver_DB;
    driver_DB = DB_GetDriver();
    driver_DB->next = 0;

    return driver_DB;
}

DataSourceDriver *
GetDataSources(void)
{
    DataSourceDriver * drivers = GetInternalDataSources();
#ifdef CONFIG_VFS
    DataSourceDriver* driver_DBvfs = DBvfs_GetDriver();
#endif
#ifdef CONFIG_PLUGINS
    DataSourceDriver* drivers_Plugin = Plug_GetDriver();
#endif
#ifdef CONFIG_FMT_MOBILEDB
    DataSourceDriver* driver_MobileDB = MobileDB_GetDriver();
#endif
#ifdef CONFIG_FMT_JFILE3
    DataSourceDriver* driver_JFile3 = JFile3_GetDriver();
#endif
#ifdef CONFIG_FMT_DB2
    DataSourceDriver* driver_OldDB = OldDB_GetDriver();
#endif
    DataSourceDriver* last;

    /* XXX: Make it so we can disable other data source drivers. */
    last = drivers;
    while (last->next != 0) last = last->next;
#ifdef CONFIG_VFS
    last->next = driver_DBvfs;
    if (last->next)
        last = last->next;
#endif
#ifdef CONFIG_FMT_DB2
    last->next = driver_OldDB;
    if (last->next)
        last = last->next;
#endif
#ifdef CONFIG_FMT_MOBILEDB
    last->next = driver_MobileDB;
    if (last->next)
        last = last->next;
#endif
#ifdef CONFIG_FMT_JFILE3
    last->next = driver_JFile3;
    if (last->next)
        last = last->next;
#endif
#ifdef CONFIG_PLUGINS
    last->next = drivers_Plugin;
#else
    last->next = 0;
#endif
    return drivers;
}

void
PutDataSources(DataSourceDriver * drivers)
{
    DataSourceDriver * tmp;

    while (drivers != 0) {
        tmp = drivers;
        drivers = drivers->next;
        DeallocateMemPtr(tmp);
    }
}

void
DeleteDataSource(DataSourceDriver * drivers, UInt16 sourceID,
                 void * key_data, UInt32 key_size)
{
    while (drivers) {
        if (sourceID == drivers->sourceID) {
            drivers->class_ops.Delete(key_data, key_size);
            return;
        }
        drivers = drivers->next;
    }
}

DataSource *
OpenDataSource(DataSourceDriver * drivers, UInt16 mode, UInt16 sourceID,
               void * key_data, UInt16 key_size)
{
    DataSource * source;
    Err err;

    source = (DataSource *)AllocateMemPtr(sizeof(DataSource));
    MemSet(source, sizeof(*source), 0);

    while (drivers) {
        if (sourceID == drivers->sourceID) {
            if (!drivers->class_ops.IsPresent( key_data, key_size))
                break;
            err = drivers->class_ops.Open(source, mode, key_data, key_size);
            if (err == 0) {
                source->driver = drivers;
                return source;
            }
            
        }
        drivers = drivers->next;
    }

    DeallocateMemPtr(source);
    return 0;
}

DataSource *
OpenDataSourcePDB(DataSourceDriver * drivers, UInt16 mode,
                  UInt16 cardNo, LocalID dbID)
{
    DataSource * source;
    Err err;
    UInt32 type, creator;

    if (DmDatabaseInfo(cardNo, dbID, 0, 0, 0, 0, 0, 0, 0, 0, 0, &type, &creator) != errNone)
        return 0;

    source = (DataSource *)AllocateMemPtr(sizeof(DataSource));
    MemSet(source, sizeof(*source), 0);

    while (drivers) {
        if (drivers->class_ops.CanHandlePDB
                && drivers->class_ops.CanHandlePDB(cardNo, dbID, type, creator)) {
            err = drivers->class_ops.OpenPDB(source, mode, cardNo, dbID);
            if (err == 0) {
                source->driver = drivers;
                return source;
            }
        }
        drivers = drivers->next;
    }

    DeallocateMemPtr(source);
    return 0;
}

void
CloseDataSource(DataSource * source)
{
    source->ops.Close(source);
    DeallocateMemPtr(source);
}

void FreeSchema(DataSourceSchema * schema)
{
    UInt16 i, j;
    for (i = 0; i < schema->numFields; i++) {
        switch (schema->fields[i].type){
        case FIELD_TYPE_STRING:
            if (schema->fields[i].data.string.defaultValue)
                DeallocateMemPtr(schema->fields[i].data.string.defaultValue);
        break;
        case FIELD_TYPE_LIST:
            if (schema->fields[i].data.list.items) {
                for (j = 0; j < schema->fields[i].data.list.numItems; j++) {
                    DeallocateMemPtr( schema->fields[i].data.list.items[j]);
                    schema->fields[i].data.list.items[j] = NULL;
                }
                if (schema->fields[i].data.list.uniqID)
                    DeallocateMemPtr(schema->fields[i].data.list.uniqID);
                schema->fields[i].data.list.uniqID = NULL;
                DeallocateMemPtr( schema->fields[i].data.list.items);
                schema->fields[i].data.list.items = NULL;
            }
        break;
        case FIELD_TYPE_CALCULATED:
            if (schema->fields[i].data.calc.bytecode)
                DeallocateMemHandle(schema->fields[i].data.calc.bytecode);
        break;
        default:
        break;
        }
    }
    if (schema->fields)
        DeallocateMemPtr(schema->fields);
    schema->numFields = 0;
    schema->fields = 0;
}

void CopySchema(DataSourceSchema * dst, DataSourceSchema * src)
{
    UInt32 size;
    UInt16 i, j;
    char * p;

    /* Destination will have the same number of fields. */
    dst->numFields = src->numFields;

    /* Calclate how much space is needed for strings. */
    size = dst->numFields * sizeof(DataSourceFieldInfo);
    for (i = 0; i < src->numFields; ++i)
        size += StrLen(src->fields[i].name) + 1;

    /* Allocate space for the field information and name strings. */
    dst->fields = (DataSourceFieldInfo *)AllocateMemPtr(size);

    /* Copy all of the data over. */
    p = (char *) (dst->fields + dst->numFields);
    for (i = 0; i < dst->numFields; ++i) {
        dst->fields[i].name = p;
        dst->fields[i].type = src->fields[i].type;
        dst->fields[i].lock = src->fields[i].lock;
        switch (dst->fields[i].type){
        case FIELD_TYPE_STRING:
            if (src->fields[i].data.string.defaultValue) {
                dst->fields[i].data.string.defaultValue = 
                	(char *)AllocateMemPtr( StrLen(src->fields[i].data.string.defaultValue) + 1);
                StrCopy( dst->fields[i].data.string.defaultValue, src->fields[i].data.string.defaultValue);
            } else {
                dst->fields[i].data.string.defaultValue = NULL;
            }
        break;
        case FIELD_TYPE_INTEGER:
            dst->fields[i].data.integer.defaultValue = src->fields[i].data.integer.defaultValue;
            dst->fields[i].data.integer.increment = src->fields[i].data.integer.increment;
        break;
        case FIELD_TYPE_FLOAT:
            dst->fields[i].data.floatNum.defaultValue = src->fields[i].data.floatNum.defaultValue;
        break;
        case FIELD_TYPE_LIST:
        {
            UInt16 itemNum = src->fields[i].data.list.numItems;
            dst->fields[i].data.list.numItems = itemNum;
            if (itemNum > 0) {
                dst->fields[i].data.list.items = (char **)AllocateMemPtr( itemNum * sizeof(char *));
                MemSet( dst->fields[i].data.list.items, itemNum * sizeof(char *), 0);
                dst->fields[i].data.list.uniqID = 
                                (UInt16 *)AllocateMemPtr( dst->fields[i].data.list.numItems * sizeof(UInt16));
                for (j = 0; j < itemNum; j++){
                    dst->fields[i].data.list.uniqID[j] = src->fields[i].data.list.uniqID[j];
                    dst->fields[i].data.list.items[j] = (char *)AllocateMemPtr( StrLen(src->fields[i].data.list.items[j]) + 1);
                    StrCopy( dst->fields[i].data.list.items[j], src->fields[i].data.list.items[j]);
                }
            } else {
                dst->fields[i].data.list.items = NULL;
            }
        }
        break;
        case FIELD_TYPE_LINK:
            dst->fields[i].data.link.dbID = src->fields[i].data.link.dbID;
            dst->fields[i].data.link.fieldNum = src->fields[i].data.link.fieldNum;
        break;
        case FIELD_TYPE_LINKED:
            dst->fields[i].data.linked.linkNum = src->fields[i].data.linked.linkNum;
            dst->fields[i].data.linked.fieldNum = src->fields[i].data.linked.fieldNum;
        break;
        case FIELD_TYPE_CALCULATED:
        {
            UInt8 *d_bc, *s_bc;

            dst->fields[i].data.calc.bytecode_sz = src->fields[i].data.calc.bytecode_sz;
            dst->fields[i].data.calc.returnType = src->fields[i].data.calc.returnType;
            dst->fields[i].data.calc.access = src->fields[i].data.calc.access;
            // scriptText should only be non null when in the design screen
            dst->fields[i].data.calc.bytecode = AllocateMemHandle( dst->fields[i].data.calc.bytecode_sz );
            d_bc = (UInt8 *)MemHandleLock( dst->fields[i].data.calc.bytecode );
            s_bc = (UInt8 *)MemHandleLock( src->fields[i].data.calc.bytecode );
            MemMove( d_bc, s_bc, dst->fields[i].data.calc.bytecode_sz );
            MemPtrUnlock( s_bc );
            MemPtrUnlock( d_bc );
        }
        break;
        default:
            MemMove( &(dst->fields[i].data), &(src->fields[i].data), sizeof(DataSourceFieldData));
        }
        StrCopy(p, src->fields[i].name);
        p += StrLen(src->fields[i].name) + 1;
    }
}

/* Search the drivers list for a specific ID. */
DataSourceDriver *
GetDriverByID(UInt16 sourceID)
{
    DataSourceDriver * driver = DriverList;

    while (driver) {
        if (driver->sourceID == sourceID) return driver;
        driver = driver->next;
    }

    return 0;
}

Err
ExchangeDataSource(DataSourceDriver * drivers, UInt16 sourceID,
               void * key_data, UInt16 key_size)
{
    while (drivers) {
        if (drivers->sourceID == sourceID) {
            return drivers->class_ops.Exchange(key_data, key_size);
        }
        drivers = drivers->next;
    }

    return 0;
}

int
DS_StandardSortCallback(DataSource * source,
                        DataSourceGetter * getter1, void * rec1_data,
                        DataSourceGetter * getter2, void * rec2_data,
                        void * callback_data)
{
    DataSourceSortInfo * info = (DataSourceSortInfo *) callback_data;
    UInt16 i;
    char *p1, *p2;
    Int16 result = -1;
    Int32 v1, v2;
    Boolean b1, b2;
    UInt16 match1, match2;

    for (i = 0; i < info->numFields; ++i) {
        UInt16 fieldNum = info->fields[i].fieldNum;
        DataSourceSortDirection direction = info->fields[i].direction;
        Boolean case_sensitive = info->fields[i].case_sensitive;

        switch (CurrentSource->schema.fields[fieldNum].type) {
        case FIELD_TYPE_STRING:
            p1 = getter1->GetString(rec1_data, fieldNum);
            p2 = getter2->GetString(rec2_data, fieldNum);
            if (case_sensitive)
                result = TxtGlueCompare(p1, StrLen(p1), &match1,
                                        p2, StrLen(p2), &match2);
            else
                result = TxtGlueCaselessCompare(p1, StrLen(p1), &match1,
                                                p2, StrLen(p2), &match2);
            break;

        case FIELD_TYPE_NOTE:
            p1 = getter1->GetNoteTitle(rec1_data, fieldNum);
            p2 = getter2->GetNoteTitle(rec2_data, fieldNum);
            if (case_sensitive)
                result = TxtGlueCompare(p1, StrLen(p1), &match1,
                                        p2, StrLen(p2), &match2);
            else
                result = TxtGlueCaselessCompare(p1, StrLen(p1), &match1,
                                                p2, StrLen(p2), &match2);
            break;

        case FIELD_TYPE_INTEGER:
            v1 = getter1->GetInteger(rec1_data, fieldNum);
            v2 = getter2->GetInteger(rec2_data, fieldNum);
            if (v1 < v2)
                result = -1;
            else if (v1 > v2)
                result = 1;
            else
                result = 0;
            break;

        case FIELD_TYPE_BOOLEAN:
            b1 = getter1->GetBoolean(rec1_data, fieldNum);
            b2 = getter2->GetBoolean(rec2_data, fieldNum);
            if (b1 == b2)
                result = 0;
            else if (!b1)
                result = -1;
            else
                result = 1;
            break;

        case FIELD_TYPE_DATE:
            {
                UInt16 y1, y2;
                UInt8 m1, m2, d1, d2;

                getter1->GetDate(rec1_data, fieldNum, &y1, &m1, &d1);
                getter2->GetDate(rec2_data, fieldNum, &y2, &m2, &d2);

                if (y1 < y2)
                    result = -1;
                else if (y1 > y2)
                    result = 1;
                else {
                    if (m1 < m2)
                        result = -1;
                    else if (m1 > m2)
                        result = 1;
                    else {
                        if (d1 < d2)
                            result = -1;
                        else if (d1 > d2)
                            result = 1;
                        else
                            result = 0;
                    }
                }
            }
            break;

        case FIELD_TYPE_TIME:
            {
                UInt8 h1, h2, m1, m2;

                getter1->GetTime(rec1_data, fieldNum, &h1, &m1);
                getter2->GetTime(rec2_data, fieldNum, &h2, &m2);

                if (h1 < h2)
                    result = -1;
                else if (h1 > h2)
                    result = 1;
                else {
                    if (m1 < m2)
                        result = -1;
                    else if (m1 > m2)
                        result = 1;
                    else
                        result = 0;
                }
            }
            break;

        case FIELD_TYPE_LIST:
            {
                UInt8 item1, item2;

                item1 = getter1->GetListItem(rec1_data, fieldNum);
                item2 = getter2->GetListItem(rec2_data, fieldNum);

                if (item1 < item2)
                    result = -1;
                else if (item1 > item2)
                    result = 1;
                else
                    result = 0;
            }
            break;

        case FIELD_TYPE_LINK:
            p1 = getter1->GetLink(rec1_data, fieldNum,(UInt32 *)&v1);
            p2 = getter2->GetLink(rec2_data, fieldNum,(UInt32 *)&v2);
            if (case_sensitive)
                result = TxtGlueCompare(p1, StrLen(p1), &match1,
                                        p2, StrLen(p2), &match2);
            else
                result = TxtGlueCaselessCompare(p1, StrLen(p1), &match1,
                                                p2, StrLen(p2), &match2);
            break;

        case FIELD_TYPE_LINKED:
            p1 = getter1->GetLinked(rec1_data, fieldNum);
            p2 = getter2->GetLinked(rec2_data, fieldNum);
            if (case_sensitive)
                result = TxtGlueCompare(p1, StrLen(p1), &match1,
                                        p2, StrLen(p2), &match2);
            else
                result = TxtGlueCaselessCompare(p1, StrLen(p1), &match1,
                                                p2, StrLen(p2), &match2);
            break;

        case FIELD_TYPE_FLOAT:
            {
                FlpCompDouble f1, f2;

                f1.d = getter1->GetFloat(rec1_data, fieldNum);
                f2.d = getter2->GetFloat(rec2_data, fieldNum);
                switch (DoubleComp(f1.fd,f2.fd)) {
                case flpEqual:
                    result = 0;
                break;
                case flpLess:
                    result = -1;
                break;
                case flpGreater:
                    result = 1;
                break;
                default:
                    result = 0;
                }
            }
            break;

#ifdef CONFIG_SCRIPTS
        case FIELD_TYPE_CALCULATED:
            {
                CalculatedValue cv1, cv2;
                getter1->GetCalculated( rec1_data, fieldNum, &cv1 );
                getter2->GetCalculated( rec2_data, fieldNum, &cv2 );
                result = 0;
                if ( cv1.info != cv2.info ) break;
                if ( cv1.info == FIELD_TYPE_INTEGER ) {
                    if (cv1.value.i < cv2.value.i)
                        result = -1;
                    else if (cv1.value.i > cv2.value.i)
                        result = 1;
                    else
                        result = 0;
                }

                CV_FreeData( &cv1 );
                CV_FreeData( &cv2 );
            }
            break;
#endif
        default:
            /* Assume that any types not known to us are equal. */
            result = 0;
            break;
        }

        /* If we are going in descending order, invert the result. */
        if (direction == SORT_DIRECTION_DESCENDING) {
            if (result < 0)
                result = 1;
            else if (result > 0)
                result = -1;
        }

        /* If we found a difference (nonzero basically), stop the loop. */
        if (result != 0) break;
    }

    return result;
}

void
DS_PDB_Close(DataSource * source)
{
    DmCloseDatabase(source->db);
    source->db = 0;
    if (source->data) DeallocateMemPtr(source->data);
    if (source->key.data) DeallocateMemPtr(source->key.data);
    FreeSchema( &source->schema);
}

Boolean
DS_Seek(DataSource * source, UInt16 * indexP, Int16 offset, Int16 direction)
{

    if (source->ops.Capable(source, DS_CAPABLE_LISTVIEW_FILTER)
            && source->currentfilter != FILTERALL) {
        DmSeekRecordInCategory(source->db, indexP, offset, direction,
                           source->currentfilter);
    }
    else
        DmSeekRecordInCategory(source->db, indexP, offset, direction,
                           dmAllCategories);
    if (DmGetLastErr())
        return false;

    return true;
}

void
DS_DeleteRecord(DataSource * source, UInt16 index)
{
    DmRemoveRecord(source->db, index);
}

void
DS_FilterRecord(DataSource * source, UInt16 index, DataSourceFilter filter)
{
    UInt16 category, recAttr = 0;
    LocalID dbID;
    UInt16 cardNO;

    if (CurrentSource->openMode == dmModeReadOnly) {
        DmOpenDatabaseInfo( source->db, &dbID, NULL, NULL, &cardNO, NULL);
        DmCloseDatabase( source->db);
        source->db = DmOpenDatabase( cardNO, dbID, dmModeReadWrite);
    }

    DmRecordInfo(source->db, index, &recAttr, NULL, NULL);
    category = recAttr & dmRecAttrCategoryMask;
    if (category != filter) {
        category = filter;
        recAttr &= !dmRecAttrCategoryMask;
        recAttr |= category;
        DmSetRecordInfo( source->db, index, &recAttr, NULL);
    }

    if (CurrentSource->openMode == dmModeReadOnly) {
        DmCloseDatabase( source->db);
        source->db = DmOpenDatabase( cardNO, dbID, dmModeReadOnly);
    }
}

void
DS_SetFilter(DataSource * source, DataSourceFilter filter, Boolean reset)
{
    LocalID dbID;
    UInt16 cardNO;

    if( reset){
        if (CurrentSource->openMode == dmModeReadOnly) {
            DmOpenDatabaseInfo( source->db, &dbID, NULL, NULL, &cardNO, NULL);
            DmCloseDatabase( source->db);
            source->db = DmOpenDatabase( cardNO, dbID, dmModeReadWrite);
        }
        DmMoveCategory( source->db, FILTERNONE, filter, false);
        if (CurrentSource->openMode == dmModeReadOnly) {
            DmCloseDatabase( source->db);
            source->db = DmOpenDatabase( cardNO, dbID, dmModeReadOnly);
        }
        source->currentfilter = FILTERALL;
    } else if ( filter) {
        source->currentfilter = filter;
    } else {
        source->currentfilter = FILTERALL;
    }
}

DataSourceFilter
DS_GetCurrentFilter(DataSource * source)
{
    return source->currentfilter;
}

UInt32
DS_GetRecordID(DataSource * source, UInt16 index)
{
    UInt32 uniqueID;

    DmRecordInfo(source->db, index, 0, &uniqueID, 0);
    return uniqueID;
}

UInt16
DS_GetRecordIndex(DataSource * source, UInt32 ID)
{
    UInt16 recordNum;
    if (!DmFindRecordByID(source->db, ID, &recordNum))
        return recordNum;
    else
        return 0xFFFF;
}

UInt16
DS_GetNumOfViews(DataSource * source)
{
    return 0;
}

DataSourceView *
DS_GetView(DataSource * source, UInt16 viewIndex)
{
    DataSourceView *newView;
    char * p;
    UInt16 i;

    newView = (DataSourceView *) AllocateMemPtr(sizeof(DataSourceView));
    p = CopyStringResource(stringID_AllFields);
    StrNCopy(newView->name, p, 32-1);
    DeallocateMemPtr( p);
    newView->numCols = source->schema.numFields;
    newView->cols = AllocateMemPtr(newView->numCols * sizeof(DataSourceViewColumn));
    for (i = 0; i < newView->numCols; i++)
    {
        newView->cols[i].fieldNum = i;
#ifdef GLOBAL_ACCESS
        newView->cols[i].width = DBPrefs.ColumnWidth;
#else
        newView->cols[i].width = 80;
#endif
    }
    return newView;
}

void
DS_PutView(DataSource * source, UInt16 viewIndex, DataSourceView * view)
{
    DeallocateMemPtr(view->cols);
    DeallocateMemPtr(view);
}

void
DS_CheckUpdateSchema(DataSource * source,
                     DataSourceSchema * schema, UInt32* reorder,
                     Boolean* changed, Boolean* rebuild)
{
    UInt16 i;

    /* By default, we assume no changes happened whatsoever. */
    *changed = false;
    *rebuild = false;

    /* Adding or deleting fields requires a rebuild. */
    if (source->schema.numFields != schema->numFields) {
        *changed = true;
        *rebuild = true;
        return;
    }

    for (i = 0; i < source->schema.numFields; ++i) {
        /* Changing the order of the fields or changing the type
         * requires a full rebuild.
         */
        if (source->schema.fields[i].type != schema->fields[i].type
            || reorder[i] != i) {
            *changed = true;
            *rebuild = true;
            return;
        }

        if (schema->fields[i].data.changed){
            *changed = true;
            *rebuild = true;
        }

        /* Field name changes don't need a rebuild. */
        if (StrCompare(source->schema.fields[i].name,
                       schema->fields[i].name) != 0) {
            *changed = true;
        }
    }
}

void
ConvertFieldToString(DataSource * source, DataSourceGetter * getter, void * row_data,
                        UInt16 fieldNum, char *data, UInt16 len)
{
    char * p;
    Int32 value;
    UInt8 day, month, hour, minute;
    UInt16 year;

    if (!data)
        return;

    switch (source->schema.fields[fieldNum].type) {
    case FIELD_TYPE_STRING:
        p = getter->GetString(row_data, fieldNum);
        StrNCopy(data, p, len);
        break;

    case FIELD_TYPE_BOOLEAN:
        StrCopy(data,(getter->GetBoolean(row_data, fieldNum))?"1":"0");
        break;

    case FIELD_TYPE_NOTE:
        p = getter->GetNoteTitle(row_data, fieldNum);
        StrNCopy(data, p, len);
        break;

    case FIELD_TYPE_INTEGER:
        value = getter->GetInteger(row_data, fieldNum);
        StrIToA(data, value);
        break;

    case FIELD_TYPE_DATE:
        getter->GetDate(row_data, fieldNum, &year, &month, &day);
        if (month != 0)
            DateToAscii(month, day, year, PrefGetPreference(prefDateFormat), data);
        else
            StrCopy(data,"N/A");
        break;

    case FIELD_TYPE_TIME:
        getter->GetTime(row_data, fieldNum, &hour, &minute);
        if (hour < 24)
            TimeToAscii(hour, minute, PrefGetPreference(prefTimeFormat), data);
        else
            StrCopy(data,"N/A");
        break;

    case FIELD_TYPE_LIST:
    {
        UInt16 itemNum = getter->GetListItem(row_data, fieldNum);
        if (itemNum < source->schema.fields[fieldNum].data.list.numItems
                && source->schema.fields[fieldNum].data.list.items
                && source->schema.fields[fieldNum].data.list.items[itemNum]) {
            StrNCopy(data, source->schema.fields[fieldNum].data.list.items[itemNum], len);
        } else
            StrNCopy(data, "N/A", len);
        break;
    }
    case FIELD_TYPE_LINK:
        p = getter->GetLink(row_data, fieldNum, NULL);
        if (p)
            StrNCopy(data, p, len);
        else
            data[0] = 0;
        break;

    case FIELD_TYPE_LINKED:
        p = getter->GetLinked(row_data, fieldNum);
        if (p)
            StrNCopy(data, p, len);
        else
            data[0] = 0;
        break;

    case FIELD_TYPE_FLOAT:
    {
        double f =  getter->GetFloat( row_data, fieldNum );
#ifdef GLOBAL_ACCESS
        DoublePrintValue( f, data, DBPrefs.FloatDigits );
#else
        DoublePrintValue( f, data, 3 );
#endif
        break;
    }
#ifdef CONFIG_SCRIPTS
    case FIELD_TYPE_CALCULATED:
    {
        CalculatedValue cv;

		getter->GetCalculated( row_data, fieldNum, &cv );
        CV_PrintValue( &cv, data, len );
		CV_FreeData( &cv );
        break;
    }
#endif

    default:
        StrNCopy(data, "N/A", len);
        break;
    }
}

Int32
DS_Getter_GetInteger(void * data, UInt16 fieldNum)
{
    ErrDisplay("Getter_GetInteger: no support");
    return 0;
}

Boolean
DS_Getter_GetBoolean(void * data, UInt16 fieldNum)
{
    ErrDisplay("Getter_GetBoolean: no support");
    return false;
}

void
DS_Getter_GetDate(void * data, UInt16 fieldNum,
                     UInt16* year, UInt8* mon, UInt8* day)
{
    ErrDisplay("Getter_GetDate: no support");
}

void
DS_Getter_GetTime(void * data, UInt16 fieldNum, UInt8* hour, UInt8* minute)
{
    ErrDisplay("Getter_GetTime: no support");
}

char *
DS_Getter_GetNoteTitle(void * data, UInt16 fieldNum)
{
    ErrDisplay("Getter_GetNoteTitle: no support");
    return NULL;
}

char *
DS_Getter_GetNote(void * data, UInt16 fieldNum)
{
    ErrDisplay("Getter_GetNote: no support");
    return NULL;
}
