/*
 * DB: Database Program for Pilot
 * Copyright (C) 1998-2001 by Tom Dyas (tdyas@users.sourceforge.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 */

#include <PalmOS.h>

#include "db.h"
#ifdef CONFIG_HANDERA
#include <Vga.h>
#endif
#ifdef CONFIG_SONY
#include <SonyCLIE.h>
#endif
#ifdef CONFIG_VFS
#include <VFSMgr.h>
#endif
#ifdef CONFIG_DEBUG
#include <HostControl.h>
#endif

#include "prefs.h"
#include "enum.h"
#include "linkaware.h"
#ifdef CONFIG_PLUGINS
#include "plug.h"
#endif
#include "util.h"

privateRecordViewEnum PrivateRecordStatus;
Boolean FeatureSet30, FeatureSet31, FeatureSet32, FeatureSet35, FeatureSet40;
Boolean FeatureSetHandera, FeatureSetSony;
DataSourceDriver * DriverList;
UInt32 WinDepth;
#ifdef CONFIG_SONY
UInt16 SonyLibRefNum;
#endif
#ifdef CONFIG_HANDERA
char * RotateString;
#endif

static Boolean AppHandleEvent(EventPtr event) SECT_HND;
static void EventLoop(void) SECT_HND;
static void HelpInit() SECT_UI;
static void HelpFree() SECT_UI;
#ifdef CONFIG_COLOR
static void SetColorDefinition() SECT_UI;
#endif
static void ChooseInitialForm(void) SECT_UI;
static Boolean GoToItem(GoToParamsPtr goToParams) SECT_UI;
static Err CheckMinVersion(UInt16 launchFlags) SECT_UI;
static Err StartApplication() SECT_UI;
static void ChooseInitialForm(void) SECT_UI;
static void SaveCurrentDataSource(void) SECT_UI;
static void StopApplication(void) SECT_UI;


static Boolean
AppHandleEvent(EventPtr event)
{
    UInt16 formID;
    FormPtr form;

    if (event->eType == frmLoadEvent) {
        formID = event->data.frmLoad.formID;
        form = FrmInitForm(formID);
        FrmSetActiveForm(form);
        switch (formID) {
        case formID_Chooser:
            FrmSetEventHandler(form, ChooserHandleEvent);
            break;
        case formID_DesignView:
            FrmSetEventHandler(form, DesignViewHandleEvent);
            break;
        case formID_ListView:
            FrmSetEventHandler(form, ListViewHandleEvent);
            break;
        case formID_FindDialog:
            FrmSetEventHandler(form, FindDialogHandleEvent);
            break;
        case formID_EditView:
            FrmSetEventHandler(form, EditViewHandleEvent);
            break;
        case formID_ChooserInfoDialog:
            FrmSetEventHandler(form, ChooserInfoDialogHandleEvent);
            break;
        case formID_ListViewEditor:
            FrmSetEventHandler(form, ListViewEditorHandleEvent);
            break;
        case formID_CreateDlg:
            FrmSetEventHandler(form, CreateDlgHandleEvent);
            break;
        case formID_DuplicateDlg:
            FrmSetEventHandler(form, DuplicateDlgHandleEvent);
            break;
        case formID_RenameDlg:
            FrmSetEventHandler(form, RenameDlgHandleEvent);
            break;
        case formID_AppPrefs:
            FrmSetEventHandler(form, AppPrefsHandleEvent);
            break;
#ifdef CONFIG_SORT
        case formID_SortEditor:
            FrmSetEventHandler(form, SortEditor_HandleEvent);
            break;
#endif
        case formID_NamesEditor:
            FrmSetEventHandler(form, NamesEditorHandleEvent);
            break;
#ifdef CONFIG_PLUGINS
        case formID_PluginListDialog:
            FrmSetEventHandler(form, PluginListHandleEvent);
            break;
#endif
        case formID_Note:
            FrmSetEventHandler(form, NoteHandleEvent);
            break;
        case formID_FieldProperties:
            FrmSetEventHandler(form, FieldPropertiesHandleEvent);
            break;
        case formID_LinkSelect:
            FrmSetEventHandler(form, LinkSelectHandleEvent);
            break;
		case formID_About:
#ifdef CONFIG_ABOUT
		  FrmSetEventHandler(form, AboutHandleEvent);
#endif
		  break;
        default:
    //      ErrDisplay("unknown form ID");
            return false;
        }
        return true;
    }
    return false;
}

static void
EventLoop(void)
{
    UInt16 err;
    EventType event;

    do {
        EvtGetEvent(&event, evtWaitForever);
    
        if (!SysHandleEvent(&event))
            if (!MenuHandleEvent((void *)0, &event, &err))
                if (!AppHandleEvent(&event))
#ifdef CONFIG_PLUGINS
                    if (!PlugHandleEvent(&event))
#endif
                        FrmDispatchEvent(&event);
    } while (event.eType != appStopEvent);
}

static DmOpenRef HelpDBRef = 0;
static void
HelpInit()
{

    HelpDBRef = DmOpenDatabaseByTypeCreator(DBHelpTypeID, 
                            DBCreatorID,dmModeReadOnly);

}

static void
HelpFree()
{
    if (HelpDBRef)
        DmCloseDatabase(HelpDBRef);
}

static Err
CheckMinVersion(UInt16 launchFlags)
{
    UInt32 version;

    if (FtrGet(sysFtrCreator, sysFtrNumROMVersion, &version) == 0) {
        if (version < sysMakeROMVersion(2, 0, 0, sysROMStageRelease, 0)) {
            if ((launchFlags &
             (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
            (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) {
            FrmAlert(alertID_RomIncompatible);

            /* Pilot 1.0 will continuously relaunch this app unless we
             * switch to another safe one.
             */
            if (version < 0x02000000)
                AppLaunchWithCommand(sysFileCDefaultApp,
                         sysAppLaunchCmdNormalLaunch, NULL);
            }

            return sysErrRomIncompatible;
        }
    }
#ifdef CONFIG_DEBUG
	if( FtrGet(kPalmOSEmulatorFeatureCreator, kPalmOSEmulatorFeatureNumber, &version ) == ftrErrNoSuchFeature ) {
		DbgPrintF( "Error: You can't run a debug version on a real palm!" );
		return sysErrRomIncompatible;
	}
#endif

    return 0;
}

#ifdef CONFIG_COLOR
static void
SetColorDefinition()
{
    DmResID  gridColorID = 0;

    if (FeatureSet30) {
        WinScreenMode(winScreenModeGetSupportedDepths, NULL, NULL, &WinDepth, NULL);

        if (WinDepth == 0x808B) {
            WinDepth = 16;
            gridColorID = wlistID_GridColors16;
        } else if (WinDepth == 0x8B) {
            WinDepth = 8;
            gridColorID = wlistID_GridColors16;
        } else if (WinDepth == 0x0B) {
            WinDepth = 4;
            gridColorID = wlistID_GridColors4;
        } else if (WinDepth == 0x03) {
            WinDepth = 2;
            gridColorID = wlistID_GridColors2;
        } else {
            WinDepth = 1;
            gridColorID = wlistID_GridColors2;
        }
        WinScreenMode(winScreenModeSet, NULL, NULL, &WinDepth, NULL);
        if (FeatureSet35) {
            GridColorH = DmGetResource('BLST', gridColorID);
        }
    } else {
        WinDepth = 1;
    }
}
#endif

static Err
StartApplication()
{
    UInt32 version;
    UInt16 prefsSize = sizeof(DBPrefsType);
    Int16 prefsVersion;

    /* Detect the PalmOS version so we know what features exist. */
    if (FtrGet(sysFtrCreator, sysFtrNumROMVersion, &version) == 0) {
#define ver(a,b) sysMakeROMVersion(a, b, 0, SYSROMSTAGE, 0)
        FeatureSet30 = (version >= ver(3,0));
        FeatureSet31 = (version >= ver(3,1));
        FeatureSet32 = (version >= ver(3,2));
        FeatureSet35 = (version >= ver(3,5));
        FeatureSet40 = (version >= ver(4,0));
#undef ver
    }

    FeatureSetHandera = false;
    FeatureSetSony = false;

#ifdef CONFIG_HANDERA
    RotateString = NULL;
    if (FtrGet(TRGSysFtrID, TRGVgaFtrNum, &version) == 0) {
        if (sysGetROMVerMajor(version) >= 1)
        {
            FeatureSetHandera = true;
            VgaSetScreenMode(screenMode1To1, rotateModeNone);
            RotateString = CopyStringResource( stringID_Rotate);
        }
    }
#endif
#ifdef CONFIG_SONY
    SonyLibRefNum = 0;
  {
    SonySysFtrSysInfoP sonySysFtrSysInfoP;
    Err error = 0;

    if (FtrGet(sonySysFtrCreator, sonySysFtrNumSysInfoP, (UInt32*)&sonySysFtrSysInfoP) == 0) {
        FeatureSetSony = true;
        if (sonySysFtrSysInfoP->libr & sonySysFtrSysInfoLibrHR) {
            if ((error = SysLibFind(sonySysLibNameHR, &SonyLibRefNum))){
                if (error == sysErrLibNotFound) {
                    error = SysLibLoad( 'libr', sonySysFileCHRLib, &SonyLibRefNum );
                }
            }
        }
    }
  }
    if (FeatureSetSony && SonyLibRefNum){
        UInt32 width, height, depth;
        HROpen(SonyLibRefNum);
        width = 320; height = hrHeight;
        depth = 8; // (in color mode of 256 colors)
        HRWinScreenMode ( SonyLibRefNum, winScreenModeSet,
                            &width, &height, &depth, NULL );
    }
#endif

#ifdef CONFIG_COLOR
    SetColorDefinition();
#else
    WinDepth = 1;
#endif
    // Read the current application preferences.
    prefsVersion = PrefGetAppPreferences(DBCreatorID, prefID_GlobalPrefs,
                       &DBPrefs, &prefsSize, false);

    // Reset the preferences if they don't exist or have the wrong size. 
    if (prefVersion != DBPrefsVersion || prefsSize != sizeof(DBPrefsType)) {
        PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, prefVersion,
                      NULL, 0, false);
        InitPrefs(&DBPrefs);
    }

    // Detect what should be done with private records.
    if (FeatureSet35) {
        PrivateRecordStatus = PrefGetPreference(prefShowPrivateRecords);
    } else {
        if (PrefGetPreference(prefHidePrivateRecordsV33))
            PrivateRecordStatus = hidePrivateRecords;
        else
            PrivateRecordStatus = showPrivateRecords;
    }
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRFntSetFont( SonyLibRefNum, DBPrefs.TheStdFont);
    } else
#endif
    FntSetFont(DBPrefs.TheStdFont);

    HelpInit();

    Localize();

#ifdef CONFIG_PLUGINS
    //initialize the plugin mechanism, look for plugins and load their
    Plug_Setup();
#endif
    /* Initialize any built-in data source drivers. */
    DriverList = GetDataSources();

    return 0;
}

static void
ChooseInitialForm(void)
{
    UInt16 formID = formID_Chooser;
    UInt8 * key_data;
    UInt16 key_size = 0, mode;
    UInt16 sourceID;

    /* Open any previously active data source. */
    if (PrefGetAppPreferences(DBCreatorID, prefID_LastDataSource,
                  NULL, &key_size, false) != noPreferenceFound) {

        key_data = AllocateMemPtr(key_size);
        PrefGetAppPreferences(DBCreatorID, prefID_LastDataSource,
                      key_data, &key_size, false);
    
        sourceID = *((UInt16 *) key_data);
        mode = *((UInt16 *) (key_data + 2));

        CurrentSource = OpenDataSource(DriverList, mode, sourceID,
                                               key_data + 4, key_size - 4);

        if (CurrentSource){
            if (CurrentSource->ops.Capable( CurrentSource, DS_CAPABLE_LISTVIEW_FILTER))
			  CurrentSource->ops.SetFilter( CurrentSource, FILTERALL, false);
            formID = formID_ListView;
        }
        DeallocateMemPtr(key_data);
    }

    FrmGotoForm(formID);
}

static void
SaveCurrentDataSource(void)
{
    UInt8 * key_data;
    UInt32 key_size;

    if (CurrentSource) {
        /* Store a key to this source so we can open it later. */
        key_size = CurrentSource->ops.GetKey(CurrentSource, 0);
        key_size += 2 * sizeof(UInt16);
        key_data = AllocateMemPtr(key_size);
        *((UInt16 *) key_data) = CurrentSource->driver->sourceID;
        *((UInt16 *) (key_data +  2)) = CurrentSource->openMode;
        CurrentSource->ops.GetKey(CurrentSource, key_data + 4);
        PrefSetAppPreferences(DBCreatorID, prefID_LastDataSource, 0,
                      key_data, key_size, false);
        DeallocateMemPtr(key_data);
        /* Now close the data source for real. */
        CloseDataSource(CurrentSource);
        CurrentSource = 0;
    } else {
        PrefSetAppPreferences(DBCreatorID, prefID_LastDataSource, 0,
                      0, 0, false);
    }
}

static void
StopApplication(void)
{
    FrmSaveAllForms();
    FrmCloseAllForms();

    /* Close the active data source (if any) and remember it for later. */
    SaveCurrentDataSource();

    /* Save the application preferences. */
    PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, DBPrefsVersion,
              &DBPrefs, sizeof(DBPrefsType), false);

    /* Free the list of available data sources. */
    PutDataSources(DriverList);
#ifdef CONFIG_COLOR
    if (WinDepth > 1){
        WinDepth = 1;
        WinScreenMode(winScreenModeSet, NULL, NULL, &WinDepth, NULL);
    }    
    if (FeatureSet35) {
        DmReleaseResource( GridColorH);
    }
#endif
#ifdef CONFIG_HANDERA
    if(FeatureSetHandera && RotateString)
        DeallocateMemPtr(RotateString);
#endif
#ifdef CONFIG_SONY
    if (FeatureSetSony && SonyLibRefNum){
        HRWinScreenMode ( SonyLibRefNum, winScreenModeSetToDefaults, 
                            NULL, NULL, NULL, NULL );
        HRClose(SonyLibRefNum);
    }
#endif
    HelpFree();

#ifdef CONFIG_PLUGINS
    Plug_Restore();
#endif

}

static Boolean
GoToItem(GoToParamsPtr goToParams)
{
    UInt16 recordNum = goToParams->recordNum;
 
    if (CurrentSource) {
        UInt32 uniqueID;
        UInt16 cardNo;
        LocalID dbID;

        CurrentSource->ops.Info( CurrentSource, &cardNo, &dbID, 0, 0, 0, 0);
        if (cardNo == goToParams->dbCardNo && dbID == goToParams->dbID) {
            /* For same database, recordNum could change. */
            uniqueID = CurrentSource->ops.GetRecordID( CurrentSource, recordNum);
            FrmCloseAllForms();
            recordNum = CurrentSource->ops.GetRecordIndex( CurrentSource, uniqueID);
        } else {
            /* Switch to the other database. */
            FrmCloseAllForms();
            CloseDataSource(CurrentSource);
            CurrentSource = OpenDataSourcePDB(DriverList, dmModeReadWrite,
                          goToParams->dbCardNo,
                          goToParams->dbID);
        }
    } else {
        CurrentSource = OpenDataSourcePDB(DriverList, dmModeReadWrite,
                          goToParams->dbCardNo,
                          goToParams->dbID);
    }

    if (!CurrentSource) {
        FrmGotoForm(formID_Chooser);
        return true;
    }

    /*set the protected mode switch the preferences*/
    if ((DBPrefs.flags & prefFlagOpenRDWRMode) == prefFlagOpenRDWRMode)
        CurrentSource->openMode = dmModeReadWrite;
    else
        CurrentSource->openMode = dmModeReadEdit;

    IsNewRecord = false;
    CurrentRecord = goToParams->recordNum;
    FrmGotoForm(formID_EditView);
    return true;
}

UInt32
PilotMain(UInt16 cmd, void * cmdPBP, UInt16 launchFlags)
{
    Err err;

#ifdef CONFIG_DEBUG
    HostTraceInit();
#endif

    /* Before we continue, make sure we are on PalmOS 2.0 or higher. */
    switch (cmd){
    case sysAppLaunchCmdNormalLaunch:
        err = CheckMinVersion(launchFlags);
        if (err)
            return err;

        err = StartApplication();
        if (err)
            return err;

        ChooseInitialForm();
        EventLoop();
        StopApplication();
    break;
    case sysAppLaunchCmdOpenDB:
      {
        SysAppLaunchCmdOpenDBType * db = (SysAppLaunchCmdOpenDBType *) cmdPBP;

        err = CheckMinVersion(launchFlags);
        if (err)
            return err;

        err = StartApplication();
        if (err)
            return err;

        CurrentSource = OpenDataSourcePDB(DriverList, dmModeReadWrite,
                      db->cardNo, db->dbID);
        if (CurrentSource)
            FrmGotoForm(formID_ListView);
        else
            FrmGotoForm(formID_Chooser);

        EventLoop();
        StopApplication();
      }
    break;
    case sysAppLaunchCmdSyncNotify:
      {
        DBPrefsType prefs;
        UInt16 prefsSize = sizeof(DBPrefsType);
        UInt32 value;

        if (FtrGet(sysFtrCreator, sysFtrNumNotifyMgrVersion, &value) == errNone) {
            UInt16 cardNo;
            LocalID dbID;

            SysCurAppDatabase(&cardNo, &dbID);
            SysNotifyRegister(cardNo, dbID, sysNotifyVolumeMountedEvent, NULL,
                            sysNotifyNormalPriority, NULL);
            SysNotifyRegister(cardNo, dbID, sysNotifyVolumeUnmountedEvent, NULL,
                            sysNotifyNormalPriority, NULL);
        }
        if (PrefGetAppPreferences(DBCreatorID, prefID_GlobalPrefs, &prefs,
                    &prefsSize, false) != DBPrefsVersion
                  || prefsSize != sizeof(DBPrefsType)) {
            InitPrefs(&prefs);
        } else {
            prefs.ChooserForceRescan = true;
            PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, DBPrefsVersion,
                                  &prefs, sizeof(DBPrefsType), false);
        }
        PrefSetAppPreferences(DBCreatorID, prefID_LastDataSource, 0,
                              0, 0, false);
      }
    break;
    case sysAppLaunchCmdFind:
#ifdef CONFIG_GLOBALFIND
      {
        DBPrefsType prefs;
        UInt16 prefsSize = sizeof(DBPrefsType);

        if (PrefGetAppPreferences(DBCreatorID, prefID_GlobalPrefs, &prefs,
                  &prefsSize, false) != noPreferenceFound) {
            if (prefs.flags & prefFlagEnableFind) {
                GlobalSearch((FindParamsPtr)cmdPBP);
            }
        }
      }
#endif
    break;
    case sysAppLaunchCmdGoTo:
      {
        Boolean launched;
        GoToParamsPtr go;

        launched = launchFlags & sysAppLaunchFlagNewGlobals;
        go = (GoToParamsPtr) cmdPBP;

        if (launched) {
            err = CheckMinVersion(launchFlags);
            if (err)
                return err;

            err = StartApplication();
            if (err)
                return err;

            if (GoToItem(go))
                EventLoop();
            StopApplication();
        } else {
            GoToItem(go);
        }
      }
    break;
    case sysAppLaunchCmdNotify:
      {
        DBPrefsType prefs;
        UInt16 prefsSize = sizeof(DBPrefsType);
        SysNotifyParamType *data = (SysNotifyParamType *) cmdPBP;
        
        switch (data->notifyType) {
        case sysNotifyVolumeMountedEvent:
        case sysNotifyVolumeUnmountedEvent:
            if ( PrefGetAppPreferences(DBCreatorID, prefID_GlobalPrefs, &prefs,
                                    &prefsSize, false) != DBPrefsVersion)
                break;
            prefs.ChooserForceRescan = true;
            PrefSetAppPreferences(DBCreatorID, prefID_GlobalPrefs, DBPrefsVersion,
                                  &prefs, sizeof(DBPrefsType), false);
        break;
        default:
        }
      }
    break;
#ifdef CONFIG_LINKAWARE
    case linkAppLaunchRequestLink:
        err = CheckMinVersion(launchFlags);
        if (err)
            return err;

        err = StartApplication();
        if (err)
            return err;
        FrmGotoForm(formID_Chooser); /* Go to index when a link is requested */
        EventLoop();
        StopApplication();
    break;
    case linkAppLaunchFollowLinkSubCall:
        if ( ! (launchFlags&sysAppLaunchFlagNewGlobals) ) {
            DmSearchStateType state;
            UInt16 cardNo;
            LocalID dbID;

            if (DmGetNextDatabaseByTypeCreator(true, &state,
                           sysFileTApplication,
                           DBCreatorID, false,
                           &cardNo, &dbID) == 0) {
                SysUIAppSwitch(cardNo, dbID, linkAppLaunchFollowLink, cmdPBP);
            }
        } else {
            GoToParamsPtr go;
    
            go = LinkSimpleToGoToParams((LinkSimplePtr) cmdPBP);
    
            if (go) {
                GoToItem(go);
                DeallocateMemPtr(go);
            } else {
                FrmAlert(alertID_NoLinkRecord);
            }
        }
    break;
    case linkAppLaunchFollowLink:
      {
        GoToParamsPtr go;

        go = LinkSimpleToGoToParams((LinkSimplePtr) cmdPBP);

        if (go) {
            err = CheckMinVersion(launchFlags);
            if (err)
                return err;

            err = StartApplication();
            if (err)
                return err;

            if (GoToItem(go))
                EventLoop();
            StopApplication();
            DeallocateMemPtr(go);
        } else {
            FrmAlert(alertID_NoLinkRecord);
        }
      }
    break;
#endif
    default:
    }

#ifdef CONFIG_DEBUG
    HostTraceClose();
#endif

    return 0;
}
