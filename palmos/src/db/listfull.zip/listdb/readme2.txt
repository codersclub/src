ListDB Version 0.99

This is part of the List package.  It is also freeware and falls under
the same conditions as the pilot application.

Command line options:
-c : create a .pdb file from a .csv file
example: listdb -c <output.pdb> <input.csv>

-x : extract a .csv file from a .pdb file
example: listdb -x <input.pdb> <output.csv>

-p : create a copy protected .pdb file from a .csv file
example: listdb -p <output.pdb> <input.csv>


Input file format: CSV

First line of input file:

databasename,customfield1,customfield2,category1,category2,...

Every other line..

category,field1data,field2data,notedata

To put CR's into the notedata simply add the delimiter (,) wherever a
CR is required.

See tests\test.csv for an example.



Example input file:
===cut===
databasename,customfield1,customfield2,category1,category2
category1,field1data,field2data,notedata
===cut===

Cut the text above and put the two lines into a normal text file.  For
example use notepad to create the file test.txt with these two lines. 
Then run the listdb program from a MsDOS command prompt:

listdb -c test.pdb test.txt

Then install the resulting test.pdb file.



Known Limitations:
	This version is hard coded to support a maximum of 20,000 records.
	Carriage returns in the first two fields are converted to
		dashes when extracting a database.  Use the windows
		version (WListDB) to work-around this limitation.
	Empty Note fields are not possible, you always get a free CR.
	Listdb is not very user-friendly, use WListDB instead, or maybe
		one of the Perl scripts ;)
	This file is lousy documentation.
