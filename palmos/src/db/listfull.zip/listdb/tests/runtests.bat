del zz*.*
..\listdb -x one.pdb zzone.csv
..\listdb -x two.pdb zztwo.csv
..\listdb -x pjs.pdb zzpjs.csv
..\listdb -x freq.pdb zzfreq.csv

..\listdb -c zzcd_list.pdb cd_list.csv
..\listdb -c zztwo.pdb zztwo.csv
..\listdb -c zzone.pdb zzone.csv
..\listdb -c zztest.pdb test.csv
..\listdb -c zzmoo.pdb moo.csv
..\listdb -c zzdbaert.pdb dbaert.csv
..\listdb -c zzpjs.pdb zzpjs.csv
..\listdb -c zznote1.pdb note1.csv

..\listdb -c zzbadcat.pdb badcat.csv
