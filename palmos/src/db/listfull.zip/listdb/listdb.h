/*
 */

#pragma pack(2)

/* internal structure for records */
typedef struct {
        int offset;
	int size;
	unsigned char *record;
	int category;
} PCRecord;

typedef struct {
	int offset;
	unsigned char attributes;
	unsigned char uniqueID[3];
} RecordEntry;

typedef struct {
	int nextRecordList;
	short numRecords;
/*	short firstEntry; */
} RecordList;

typedef struct {
	char name[32];
	short attributes;
	short version;
	int creationDate;
	int modificationDate;
	int lastBackupDate;
	int modificationNumber;
	int appInfoID;		/* an offset */
	int sortInfoID;		/* an offset */
	int type;
	int creator;
	int uniqueIDSeed;
	RecordList recordList;
} DatabaseHeader;

typedef struct {
	short renamedCategories;
	char categoryLabels[16][16];
	unsigned char categoryUniqIDs[16];
	unsigned char lastUniqID;
	
	unsigned char displayStyle;
	unsigned char writeProtect;
        unsigned char lastCategory;
	char customField1[16];
	char customField2[16];
        char padding[202]; /* exactly 512 bytes */
} ListAppInfo;

typedef struct {
	unsigned char field1;
	unsigned char field2;
	unsigned char note;
} ListEntry;

#ifdef LISTDB_BIG_ENDIAN
#define SWAP_WORD(x)
#define SWAP_LONG(x)
#else
#define SWAP_WORD(x) { short lo = x; \
		     short hi = x; \
		     lo = (lo >> 8) & 0x00FF; \
		     hi = (hi << 8) & 0xFF00; \
		     x = lo | hi; }

#define SWAP_LONG(x) { int result = (x >> 24) & 0x000000FF; \
		     result |= (x >> 8) & 0x0000FF00; \
		     result |= (x << 8) & 0x00FF0000; \
		     result |= (x << 24) & 0xFF000000; \
		     x = result; }
#endif


