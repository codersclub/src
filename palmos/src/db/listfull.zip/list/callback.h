#ifndef __CALLBACK_H__
#define __CALLBACK_H__

/* This is a workaround for a bug in the current version of gcc:

   gcc assumes that no one will touch %a4 after it is set up in crt0.o.
   This isn't true if a function is called as a callback by something
   that wasn't compiled by gcc (like FrmCloseAllForms()).  It may also
   not be true if it is used as a callback by something in a different
   shared library.

   We really want a function attribute "callback" which will insert this
   progloue and epilogoue automatically.

      - Ian */

register void *reg_a4 asm("%a4");

#define CALLBACK_PROLOGUE \
    void *save_a4 = reg_a4; asm("move.l %%a5,%%a4; sub.l #edata,%%a4" : :);

#define CALLBACK_EPILOGUE reg_a4 = save_a4;

#endif

/* 
In any function in your code that is called _directly from the OS_
(like custom draw routines, event handlers, etc.), insert CALLBACK_PROLOGUE
at the beginning (right after the local var declarations), and
CALLBACK_EPILOGUE at the end (right before the "return").  NOTE: make sure
that it is _impossible_ for your routine to return without executing
the CALLBACK_EPILOGUE.  Also, make sure to #include "callback.h", of course.

There is a compiler flag that attempts to do this, but last I checked,
the code it generates was wrong; it forgot to restore the original %a4 value.

   - Ian

*/
