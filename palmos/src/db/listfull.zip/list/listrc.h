// Application-defined resource ids

#define idMainForm	      1000
#define idViewForm	      1001
#define idEditForm            1002
#define idCustomForm          1003
#define idSelectFormV10       1004
#define idFindForm            1005
#define idFindResultsForm     1006
#define idNoteEditForm        1007
#define idSelectFormV20       1008

#define idMainMenu	      1000
#define idEditMenu	      1001
#define idAbout               1002
#define idDuplicateDB         1003
#define idVerifyDeleteRecord  1004
#define idVerifyDeleteDB      1005
#define idMaxNumberOfDBs      1006
#define idNameConflict        1007
#define idNameEmptyError      1008
#define idWriteProtect        1009
#define idNoMemUpdate         1010
#define idVerifyReplaceDB     1011
#define idBeamNotSupported    1012
#define idCopyProtected       1013

#define idMainCategoryTrigger 2010
#define idMainCategoryList    2011
#define idViewCategoryTrigger 2012
#define idEditCategoryTrigger 2013
#define idEditCategoryList    2014

#define idMainNewButton	      1000
#define idViewEditButton      1001
#define idViewDoneButton      1002
#define idEditDeleteButton    1003
#define idEditDoneButton      1004
#define idEditNoteButton      1005
#define idCustomDoneButton    1006
#define idMainSelectButton    1007
#define idMainFindButton      1008
#define idMainLookupText      1009

#define idMainUpButton        1100
#define idMainDownButton      1101
#define idViewUpButton        1102
#define idViewDownButton      1103
#define idEditUpButton        1104
#define idEditDownButton      1105

#define idEditTable	      1009
#define idMainTable	      1010
#define idSelectTable	      1011
#define idFindTable           1012
#define idSelectList	      1013

#define idMainMenuSelectDB    1000
#define idMainMenuNewDB       1001
#define idMainMenuDelDB       1002
#define idMainMenuCustom      1003
#define idMainMenuAbout       1004
#define idMainMenuBeamDB      1005

#define idEditMenuUndo        1010
#define idEditMenuCut         1011
#define idEditMenuCopy        1012
#define idEditMenuPaste       1013
#define idEditMenuSelectAll   1014
#define idEditMenuKeyboard    1015
#define idNoteEditField       1016

#define idFindLabel           2200
#define idFindText            2201
#define idFindOkButton        2202
#define idFindCancelButton    2203
#define idFindResCancelButton 2204
#define idFindResMoreButton   2205

#define idCustomLabel1        2501
#define idCustomLabel2        2502
#define idCustomLabel3        2503
#define idCustomLabel4        2504

#define idCustomFieldListName 2601
#define idCustomFieldField1   2602
#define idCustomFieldField2   2603

#define idCustomPopupTrigger  2700
#define idCustomPopupList     2701

#define idCustomCheckWritePro 2702
#define idCustomCheckBackup   2703
#define idCustomCheckAutomate 2704
#define idCustomCheckSelect   2705

#define idCustomHelp          5000

// String constants to allow internationalization

#define idStringView			6000
#define idStringOf				6001
#define idStringUnfiled			6002
#define idStringNewDatabase		6003
#define idStringField1			6004
#define idStringField2			6005
#define idStringNote			6006

#define bad		      1234


// Nifty constants for table sizes 

#define mainTableRows		11
#define editTableRows		3
#define selectTableRows		12
#define findTableRows           10

#define editTableLabelCol	0
#define editTableDataCol	1

#define editTableSpacing	2

