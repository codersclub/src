List 0.99

List is compatible with ALL versions of PalmOS. (PalmOS1.0 -> PalmOS3.5)

** Did you download the right version?? **  
listlite.zip - English version of List
listintl.zip - Translations of List (ie: all other versions)

list.prc   - the pilot application (English)
listfr.prc - the pilot application (French)
listgr.prc - the pilot application (German)
listjp.prc - the pilot application (Japanese)
listru.prc - the pilot application (Russian)
listdk.prc - the pilot application (Danish)
listsp.prc - the pilot application (Spanish)

[NOTE: only install ONE of the .prc files!  Choose the appropriate language.]

listdb.exe - the PC companion program for List
listdb.lnx - the Linux companion program for List.
             Compiled for RedHat 6.0

For a Windows based companion program visit the list website and
download WListDB by Olaf Martens martens@manhattan.lt.

My thanks go to the many contributors that have helped 
make List a better program.  The new translations were
done by:

French - Laurent Poujoulat (lpoujoulat@attglobal.net)
German - Jens Albrecht
Japanese - Yutakano (yutakano@tim.hi-ho.ne.jp)
Russian - Valery Sukhanov (valery@neuhaus.ru)
Danish - Henrik Clausen
Spanish - Rivero Alberto (arivero@sade.com.ar)

The List program should be so easy to use you won't need any
documentation :)  If for some reason this isn't true, please
visit the web site: http://www.magma.ca/~roo/list/list.html

New in 0.99:
------------
Added spanish version
Fixed quick scroll algorithm (fast!)
Moved most english strings to .rc (better international support)
Fixed OS3.5 fatal exception
Cleaned up problems with FldSetText
Removed 12 database limit (PalmOS2.0 and later)

To Do:
------
Website rework (gee how long has this been on the todo?)
Review translations for correctness, UI layout.
Check out Launch'Em and its sysAppLaunchCmdOpenDB (post PalmOS3 feature?)
Make use of TextManager (better international support) OS3.1 and later..
On post-V10 OS use appropriate calls
Try to make tabs display a little nicer (same defect as the AddressBook)
Copy/duplicate record? (maybe)
Investigate SysUIAppSwitch to launch "plug-ins"
Use hardware keys for scroll up/down in select screen
Add delete to view screen?
Show category on main view?  Show note on main view? More display options?
Minor UI bug, use next field/prev field graffiti stroke doesn't get upppercase?
List doesn't like its databases in FLASH ROM (TRG Pro,Visor)?

-------------------------------------------------------------

listdb.exe & listdb.lnx instructions:

Example input file:
===cut===
databasename,customfield1,customfield2,category1,category2
category1,field1data,field2data,notedata
===cut===

Cut the text above and put the two lines into a normal text file.  For
example use notepad to create the file test.txt with these two lines. 
Then run the listdb program from a MsDOS command prompt:

listdb -c test.pdb test.txt

Then install the resulting test.pdb file.

More detailed examples and instructions on the web site
http://www.magma.ca/~roo/list/list.html

-------------------------------------------------------------

List is freeware, it may be distributed freely, but not sold
or included in for-profit collections without written permission
from the author.

roo@magma.ca




