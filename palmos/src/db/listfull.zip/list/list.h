#include "callback.h"   /* work around for PilotGCC 0.5.0 bug */

#define ListCreator 'LSdb'    /* creator ID, also used in the makefile */
#define ListType    'DATA'    /* type of database */
#define ListVersion 01        /* version number */

#define ListExgType "LSdb"    /* "type" of exchange data, can be anything */

#define MAX_RECORD_SIZE   (3 + 256 + 4096)
#define CUSTOM_FIELD_SIZE 16

#define emptyRecordLabel	"-empty-"


/* The List database entry is very simple.
   3 fields field1/field2/note
   There is a header of 3 bytes that indicates the byte offset of the
   fields.  

   The maximum size of each field is:
   field1:	127 bytes + zero termination
   field2:	126 bytes + zero termination
   (This restriction allows note to be at most 255 bytes away)
   note:		4095 bytes + zero termination
*/

typedef struct  {
  unsigned char field1;  /* offset from start for first field */
  unsigned char field2;  /* offset from start for second field */
  unsigned char note;    /* offset from start of note field */
} ListDBHeader;

/* This is a superset of the AppInfoType structure */
typedef struct {
  Word renamedCategories;
  Char categoryLabels[dmRecNumCategories][dmCategoryLength];
  Byte categoryUniqIDs[dmRecNumCategories];
  Byte lastUniqID;
  /* end of AppInfoType structure, start of custom fields */
  Byte displayStyle;
  Byte writeProtect;
  Byte lastCategory;
  Char customField1[CUSTOM_FIELD_SIZE];
  Char customField2[CUSTOM_FIELD_SIZE];
  /* Pad to exactly 512 bytes */
  Char padding[202];
} ListAppInfoType;

/* The structure stored as the application preferences */
typedef struct {
  char lastDBName[dmDBNameLength];
  Boolean automateBackup;
  Boolean selectDatabaseOnStartup;
} ListPreferences;


/* Declare those nasty globals */
extern DmOpenRef CurrentDB;
extern Word CurrentRecord;
extern Word TopVisibleRecord;
extern Word TopVisibleField;
extern Word CurrentCategory;
extern char CategoryName[];
extern char ListDBName[];
extern char CustomField1[];
extern char CustomField2[];
extern Byte DisplayStyle;
extern Byte WriteProtect;
extern Word ViewPage;
extern Boolean MultipleLists;
extern char ViewTitle[];
extern char NoteText[];
extern char LocalFindText[];

/* Prototypes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags);
Word StartApplication();
void StopApplication();
Boolean ApplicationHandleEvent(EventPtr event);
Boolean MainFormEventHandler(EventPtr event);
void MainTableDrawRecord(VoidPtr table, Word row, Word column, RectanglePtr bounds );
Word MainLoadTable();
Boolean EditFormEventHandler(EventPtr event);
Boolean NoteEditFormEventHandler(EventPtr event);
void EditLoadTable(TablePtr table, Boolean initializeTable );
Boolean ViewFormEventHandler(EventPtr event);
Err EditGetRecordField(VoidPtr table, Word row, Word col, Boolean editing, VoidHand *textHandle,
		       WordPtr textOffset, WordPtr textSize, FieldPtr field );
Boolean EditSetRecordField( VoidPtr table, Word row, Word col );
void UpdateRecord( Word field, CharPtr newText );
Boolean CustomFormEventHandler(EventPtr event);
int CustomFormClose();
int CreateDatabase();
void ReadDatabaseInfo();
Boolean SelectFormEventHandlerV10(EventPtr event);
Boolean SelectFormEventHandlerV20(EventPtr event);
void SelectTableDrawRecord(VoidPtr table, Word row, Word column, RectanglePtr bounds );
void SelectListDrawItem( UInt index, RectanglePtr bounds, CharPtr *data );
void SelectLoadTable();
Int ListCompareRecords( ListDBHeader *record1, ListDBHeader *record2, Int style );
void CloseDatabase();
void ViewDrawRecord();
CharPtr ViewDrawChars(CharPtr string, Word *y, Word maxY, Boolean draw);
Word EditGetFieldHeight( Word field, Word width, ListDBHeader *record );
void ListSearch( FindParamsPtr params );
void EventLoop();
void ListDrawEntry( ListDBHeader *record, RectanglePtr bounds, Byte displayStyle );
void ListHandleSync();
void ListMarkDirty();
Boolean EditCurrentRecordEmpty();
Boolean FindFormEventHandler(EventPtr event);
Boolean FindResultsFormEventHandler(EventPtr event);
Boolean ListLocalSearch();
int QueryPalmOSVersion();