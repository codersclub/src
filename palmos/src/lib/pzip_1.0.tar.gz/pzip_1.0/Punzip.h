/* -----------------
 * Punzip.h
 * -----------------
 * header file for:
 *   o Punzip.c
 * -----------------
 */

MemPtr Punzip(DmResID resID);
