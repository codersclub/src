/* -----------------
 * pzip.h
 * -----------------
 * header file for:
 *   o pzip.c
 * -----------------
 */

/* constants */
#define bool       int
#define true       1
#define false      0
#define COUNT_BITS 3    /* why this value? I don't know */
#define DISP_BITS  11   /* ditto */

/* global */
typedef struct {
    unsigned char  *data;
    unsigned short len;
    unsigned short orig_len;
} buffer;

/* local function declarations */
void uncompress(buffer*);
void compress(buffer *b);
void put_byte( register buffer *b, unsigned char c, bool *space );
unsigned char* mem_find( register unsigned char *t, int t_len, register unsigned char *m, int m_len );
