/******************************************************************************
 *
 * Pzip.c
 * compress a text file (must be in unix-flavoured plain text)
 * Version: 1.0
 *
 * Copyright (c) 2002 Robert Watkins
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************
 *
 * The functions outside main were modified from the source for txt2pdpdoc
 * Written by Paul J. Lucas et al.
 * http://homepage.mac.com/pauljlucas/software.html
 *
 *****************************************************************************/

#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <unistd.h>
#include "pzip.h"

int main(int argc, char *argv[])
{
	int    in_file, read_size, out_file;
	char   out_filename[128];
	char   orig_len[16];
	struct stat stbuf;
	buffer buf;

	if (argc != 2) {
		fprintf(stderr, "Usage: %s <[/path/to/]file>\n", argv[0]);
		exit(1);
	}

	in_file = open(argv[1], O_RDONLY);
	if (in_file < 0) {
		fprintf(stderr, "Unable to open %s\n", argv[1]);
		exit(2);
	}

	sprintf(out_filename, "%s.pz", argv[1]);

	out_file = open(out_filename, O_WRONLY|O_TRUNC|O_CREAT, 0666);
	if (out_file < 0) {
		fprintf(stderr, "Unable to create %s\n", out_filename);
		exit(3);
	}

	fstat(in_file, &stbuf);
	buf.len = buf.orig_len = stbuf.st_size;

	buf.data = calloc(buf.len, sizeof(char));

	read_size = read(in_file, buf.data, buf.len);
	if (read_size != buf.len) {
		fprintf(stderr, "Problem reading data from filehandle to %s\n", argv[1]);
		exit(4);
	}

	compress(&buf);

	sprintf(orig_len, "%08d", buf.orig_len);

	// add buf.orig_len to end of buf.data so that it can be read on uncompress
	memcpy((buf.data + buf.len), orig_len, strlen(orig_len));

	write(out_file, buf.data, (buf.len + strlen(orig_len)));

	close(in_file);

	exit(0);
}

/*****************************************************************************
 *
 * SYNOPSIS
 */
	void compress( buffer *b )
/*
 * DESCRIPTION
 *
 *	Replace the given buffer with a compressed version of itself.
 *	I don't understand this algorithm, I just cleaned up the code.
 *
 * PARAMETERS
 *
 *	b	The buffer to be compressed.
 *
 *****************************************************************************/
{
	int i, j;
	bool space = false;

	unsigned char *buf_orig;
	unsigned char *p;      /* walking test hit; works up on successive matches */
	unsigned char *p_prev;
	unsigned char *head;   /* current test string */
	unsigned char *tail;   /* 1 past the current test buffer */
	unsigned char *end;    /* 1 past the end of the input buffer */

	p = p_prev = head = buf_orig = b->data;
	tail = head + 1;
	end = b->data + b->len;

	b->data = malloc( b->len );
	b->len  = 0;

	/* loop, absorbing one more unsigned char from the input buffer on each pass */
	while ( head != end ) {
		/* establish where the scan can begin */
		if ( head - p_prev > (( 1 << DISP_BITS )-1) )
			p_prev = head - (( 1 << DISP_BITS )-1);

		/* scan in the previous data for a match */
		p = mem_find( p_prev, tail - p_prev, head, tail - head );

		/* on a mismatch or end of buffer, issued codes */
		if ( !p || p == head || tail - head > ( 1 << COUNT_BITS ) + 2 || tail == end) {
			/* issued the codes */
			/* first, check for short runs */
			if ( tail - head < 4 )
				put_byte( b, *head++, &space );
			else {
				unsigned dist = head - p_prev;
				unsigned compound = (dist << COUNT_BITS)
					+ tail - head - 4;

				if ( dist >= ( 1 << DISP_BITS ) || tail - head - 4 > 7)
					fprintf( stderr, "ERROR: dist overflow\n");

				/* for longer runs, issue a run-code */
				/* issue space unsigned char if required */
				if ( space ) {
					b->data[ b->len++ ] = ' ';
					space = false;
				}

				b->data[ b->len++ ] = 0x80 + ( compound >> 8 );
				b->data[ b->len++ ] = compound & 0xFF;
				head = tail - 1;/* and start again */
			}
			p_prev = buf_orig;	/* start search again */
		} else
			p_prev = p;		/* got a match */

		/* when we get to the end of the buffer, don't inc past the */
		/* end; this forces the residue unsigned chars out one at a time */
		if ( tail != end )
			++tail;
	}
	free( buf_orig );

	if ( space )
		b->data[ b->len++ ] = ' ';	/* add left-over space */

	/* final scan to merge consecutive high unsigned chars together */
	for ( i = j = 0; i < b->len; ++i, ++j ) {
		b->data[ j ] = b->data[ i ];

		/* skip run-length codes */
		if ( b->data[ j ] >= 0x80 && b->data[ j ] < 0xC0 )
			b->data[ ++j ] = b->data[ ++i ];

		/* if we hit a high unsigned char marker, look ahead for another */
		else if ( b->data[ j ] == '\1' ) {
			b->data[ j + 1 ] = b->data[ i + 1 ];
			while ( i + 2 < b->len &&
				b->data[ i + 2 ] == 1 && b->data[ j ] < 8
			) {
				b->data[ j ]++;
				b->data[ j + b->data[ j ] ] = b->data[ i + 3 ];
				i += 2;
			}
			j += b->data[ j ];
			++i;
		}
	}
	b->len = j;
}


/*****************************************************************************
 *
 * SYNOPSIS
 */
	void put_byte( register buffer *b, unsigned char c, bool *space )
/*
 * DESCRIPTION
 *
 *	Put a byte into a buffer.
 *
 * PARAMETERS
 *
 *	b	The buffer to be affected.
 *
 *	c	The byte.
 *
 *	space	Is it a space?
 *
 *****************************************************************************/
{
	if ( *space ) {
		*space = false;
		/*
		** There is an outstanding space unsigned char: see if we can squeeze it
		** in with an ASCII unsigned char.
		*/
		if ( c >= 0x40 && c <= 0x7F ) {
			b->data[ b->len++ ] = c ^ 0x80;
			return;
		}
		b->data[ b->len++ ] = ' ';	/* couldn't squeeze it in */
	} else if ( c == ' ' ) {
		*space = true;
		return;
	}

	if ( (c >= 1) && (c <= 8 || c >= 0x80) )
		b->data[ b->len++ ] = '\1';

	b->data[ b->len++ ] = c;
}

/*****************************************************************************
 *
 *	Miscellaneous function(s)
 *
 *****************************************************************************/

/* replacement for strstr() which deals with 0's in the data */
unsigned char* mem_find( register unsigned char *t, int t_len, register unsigned char *m, int m_len ) {
	register int i;
	for ( i = t_len - m_len + 1; i > 0; --i, ++t )
		if ( *t == *m && !memcmp( t, m, m_len ) )
			return t;
	return 0;
}

