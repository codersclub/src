/******************************************************************************
 *
 * Punzip.c
 * Version: 1.0
 *
 * Copyright (c) 2002 Robert Watkins
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 *****************************************************************************
 *
 * The uncompress function was modified from the source for txt2pdpdoc
 * Written by Paul J. Lucas et al.
 * http://homepage.mac.com/pauljlucas/software.html
 *
 *****************************************************************************/

#include <PalmOS.h>
#include "Punzip.h"

/* constants */
#define COUNT_BITS 3    /* why this value? I don't know */
#define DISP_BITS  11   /* ditto */
#define LEN_STRLEN 8

/* global */
typedef struct {
    UInt8  *data;
    UInt16 len;
    UInt16 orig_len;
} buffer;

/* local function declaration */
MemPtr uncompress(buffer*);

MemPtr Punzip(DmResID resID)
{
	MemHandle memH;
	buffer    buf;
	UInt16    ptrSize;
	Char      orig_len[LEN_STRLEN + 1];
	Err       err;
	Char     *str;
	
	memH     = DmGetResource('pzip', resID);
	buf.data = MemHandleLock(memH);
	ptrSize  = (UInt16)MemPtrSize(buf.data);

	buf.len = ptrSize - LEN_STRLEN;  // compressed length of data
	orig_len[LEN_STRLEN] = '\0';
	MemMove(orig_len, &buf.data[buf.len], sizeof(orig_len));
	buf.orig_len = (UInt16)StrAToI(orig_len) + 1;  // +1 for NULL terminator

	err = MemHandleUnlock(memH);
	err = DmReleaseResource(memH);
	
	str = uncompress(&buf);
	
	return str;
}

MemPtr uncompress( buffer *b )
{
	unsigned char *const new_data = MemPtrNew( b->orig_len );
	int i, j;

	MemSet(new_data, b->orig_len, '\0');  // to ensure NULL termination

	for ( i = j = 0; i < b->len; ) {
		register unsigned c = b->data[ i++ ];

		if ( c >= 1 && c <= 8 ) {
			while ( c-- ) {
				new_data[ j++ ] = b->data[ i++ ];
			}
		}
		else if ( c <= 0x7F ) {
			new_data[ j++ ] = c;
		}
		else if ( c >= 0xC0 ) {
			new_data[ j++ ] = ' ';
			new_data[ j++ ] = c ^ 0x80;
		}
		else {
			register int di, n;
			c  = (c << 8) + b->data[ i++ ];
			di = (c & 0x3FFF) >> COUNT_BITS;
			for ( n = (c & ((1 << COUNT_BITS) - 1)) + 3; n--; ++j ) {
				new_data[ j ] = new_data[ j - di ];
			}
		}
	}
	b->len = j;
	return new_data;
}
