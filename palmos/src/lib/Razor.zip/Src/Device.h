/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Device.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef DEVICE_H
#define DEVICE_H

#include <PalmOS.h>


/**
 * Low level device operations.
 */
class Device
{
	public:

	/**
	 * Initialize the Device subsystem. This operation needs to be invoked
	 * before all others.
	 */
	static void init();
	
	/**
	 * PANIC!! Display a message to the user, then exit with a soft reset.
	 * Invoke this operation in case of an unresolvable runtime problem
	 * that is not your fault (e.g. low memory). Use the macros from the
	 * ErrorManager for all problems which are your fault (i.e. which
	 * will be ironed out in the release version).
	 */
	static void panic(Err error, Char* message);


	/**
	 * Check that the ROM version is meeting your minimum requirements.
	 *
	 * @param requiredVersion minimum ROM version required (see sysFtrNumROMVersion in SystemMgr.h for format)
	 * @param launchFlags flags that indicate if the application UI is initialized.
	 *
	 * @return sysErrRomIncompatible, or errNone.
	 */
	static Err romVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags);

	/// Does the Palm device support Palm OS 3.0 Feature Set?
	static Boolean supports30;
	/// Does the Palm device support Palm OS 3.1 Feature Set?
	static Boolean supports31;
	/// Does the Palm device support Palm OS 3.5 Feature Set?
	static Boolean supports35;



	private:

	static UInt32 romVersion;	
	static const UInt32 RomVersion30 = sysMakeROMVersion(3,0,0,sysROMStageRelease,0);
	static const UInt32 RomVersion31 = sysMakeROMVersion(3,1,0,sysROMStageRelease,0);
	static const UInt32 RomVersion35 = sysMakeROMVersion(3,5,0,sysROMStageRelease,0);
};


#endif
