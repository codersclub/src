/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Presentation.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef PRESENTATION_H
#define PRESENTATION_H

#include <PalmOS.h>
#include "Customization.h"
#include "ActionEngineFactory.h"

#include "ActionEngine.h"
#include "Canvas.h"
#include "HardKeyManager.h"


/**
 * Presentation controls the flow of a presentation. It is a facade
 * that delegates most of the work to other classes.
 *
 * @see ActionEngine
 * @see Canvas
 * @see HardKeyManager
 */
class Presentation
{
	public:

///@name Construction / Destruction
//@{
	/**
	 * Construct a new Presentation.
	 */
	Presentation() :
		canvas(createCanvas()), actionEngine(createActionEngine()) 
	{
		HardKeyManager::init();
		SoundEngine::init();
		
		state = presReady;
		
		// Initialize the actionEngine
		actionEngine.restart();

		// Restore saved state
		UInt16 prefsSize = 0;
		Int16 prefResult = PrefGetAppPreferences(appCreator, 0, NULL, &prefsSize, false);
		
		if (prefResult != noPreferenceFound)
		{
			void *stateBuffer = actionEngine.getRestoreStateBuffer();
			ErrNonFatalDisplayIf(stateBuffer == NULL, "Restore state buffer == NULL");
			prefsSize = actionEngine.getStateBufferSize();
			PrefGetAppPreferences(appCreator, 0, stateBuffer, &prefsSize, false);
			actionEngine.restoreState(stateBuffer);
			actionEngine.releaseRestoreStateBuffer(stateBuffer);
		}
	}

	
	/**
	 * Destroy the Presentation.
	 */
	~Presentation()
	{
		// Save state
		void *stateBuffer = actionEngine.getSaveStateBuffer();
		ErrNonFatalDisplayIf(stateBuffer == NULL, "Save state buffer == NULL");
		UInt16 prefsSize = actionEngine.getStateBufferSize();
		PrefSetAppPreferences(appCreator, 0, appVersionNum, stateBuffer, prefsSize, false);
		actionEngine.releaseSaveStateBuffer(stateBuffer);

		delete &actionEngine; 
		delete &canvas;
		HardKeyManager::destroy();
		SoundEngine::destroy();
	}

//@}

	//********************************************************************************************************
	
	
/// @name Flow Control & Timing
//@{

	/**
	 * Begin the presentation.
	 */
	void begin()
	{
		HardKeyManager::captureHardKeys();

		state = presResuming;
		pausedTime = 0;
		
		// Synchronize the periods to the timer.
		nextPeriodTime = TimGetTicks() + max(presPauseLengthBeforeResuming, presAdvanceTimeInterval);

		draw();
		show();
	}


	/**
	 * Has the presentation begun?
	 */
	Boolean hasBegun() const
	{
		return (state != presReady);
	}	
	

	/**
	 * Step to the next period.
	 */
	void nextPeriod()
	{
		state = presRunning;

		if (appPreventAutoOff)
			EvtResetAutoOffTimer();
	
		// Show display-buffer on screen
		show();				

		// Make sure SoundEngine gets invoked on a regular basis
		SoundEngine::timeTick();

		// Move objects, etc...
		actionEngine.nextPeriod();
		nextPeriodTime = TimGetTicks() + presAdvanceTimeInterval;		
		
		// Render into display-buffer
		draw();				

		// Make sure SoundEngine gets invoked on a regular basis
		SoundEngine::timeTick();
	}


	/**
	 * Draw the state of the current period again.
	 */
	void redraw() const
	{
		draw();
		show();
	}

	
	/**
	 * Is the presentation currenty paused?
	 *
	 * @return true if paused, false if not paused
	 */
	Boolean isPaused() const
	{
		return (state == presPaused);
	}	


	/**
	 * Pause the presentation.
	 */
	void pause()
	{
		state = presPaused;
		pausedTime = TimGetTicks();

		HardKeyManager::releaseHardKeys();
	}


	/**
	 * Resume a paused presentation.
	 */
	void resume()
	{
		HardKeyManager::captureHardKeys();

		if (state == presPaused)
		{
			nextPeriodTime += (TimGetTicks() - pausedTime);

			state = presResuming;
		}
		else
		{
			nextPeriodTime = TimGetTicks() + presAdvanceTimeInterval;
		}					
	}
	

	/**
	 * Determine the amount of time until the next period begins.
	 * The result can be passed directly into a call to EvtGetEvent().
	 *
	 * @return the amount of time in ticks (1/100 secs) or evtWaitForever
	 */
	Int32 getTimeUntilNextPeriod() const
	{
		if (state == presPaused)
		{
			return evtWaitForever;
		}
		else
		{	
			Int32 timeRemaining = (Int32)(nextPeriodTime - TimGetTicks());
			if (timeRemaining < 0)
				timeRemaining = 0;

			return timeRemaining;	
		}
	}
//@}


/// @name Input management
//@{
	/**
	 * Receive an input event. The event will be forwarded to
	 * the ActionEngine which has to decide whether it wants to
	 * react to it.
	 */
	void receiveEvent(const EventType* evtPtr)
	{
		actionEngine.receiveEvent(evtPtr);
	}
	
//@}


	//********************************************************************************************************
	private:


/// @name Multimedia output
//@{
	/**
	 * Draw the current state of the presentation. Drawing might occur into
	 * an invisible buffer.
	 */
	void draw() const
	{		
		canvas.beginDraw(actionEngine.getWinLockMode());

		RectangleType bounds;
		bounds.topLeft.x = 0;
		bounds.topLeft.y = 0;
		bounds.extent.x = 0;
		bounds.extent.y = 0;
		
		actionEngine.draw(&bounds);
		canvas.endDraw(&bounds);
	}
	
	
	/**
	 * Show the result of the last invocation of draw(). 
	 */
	void show() const
	{
		canvas.show();
	}
//@}



	//********************************************************************************************************
		
	// The drawing canvas	
	Canvas& canvas;

	// The ActionEngine
	ActionEngine& actionEngine;

	// Current state of the presentation
	enum 
	{
		presReady,              ///<The presentation is ready, but has not begun yet.
		presResuming, 			///<Don't change the current state. Wait a little before setting presentation in motion.
		presRunning, 	 		///<Advance and draw the current state
		presPaused              ///<Presentation paused. Don't change the current state.
	} state;


	UInt32					nextPeriodTime;		// Time when next period occurs
	UInt32					pausedTime;			// When did the pause start?
};


#endif
