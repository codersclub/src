/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: SoundEngine.cpp,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include "SoundEngine.h"
#include "Customization.h"

#ifdef NO_SOUND

void SoundEngine::init() {}
void SoundEngine::destroy() {}
void SoundEngine::timeTick() {}



#else

// ================================================ SoundEngine =============================================================


MusicEngine *SoundEngine::musicEngine;
FxEngine *SoundEngine::fxEngine;
UInt16 SoundEngine::baseAmplitude;
Boolean SoundEngine::mute;
UInt32 SoundEngine::nextTimer;


void SoundEngine::playFx(DmResID resID)
{
	if (fxEngine == NULL)
		fxEngine = new FxEngine(baseAmplitude);
		
	fxEngine->playFx(resID);
}


void SoundEngine::playSong(DmResID resID)
{
	if (musicEngine == NULL)
		musicEngine = new MusicEngine(baseAmplitude);
		
	musicEngine->playSong(resID);
}


void SoundEngine::stopSong()
{
	if (musicEngine != NULL)
		musicEngine->stopSong();
}


void SoundEngine::init()
{
	baseAmplitude = (UInt16)PrefGetPreference(prefGameSoundVolume);		
	mute = (baseAmplitude == 0);

	musicEngine = NULL;
	fxEngine = NULL;
	
	nextTimer = TimGetTicks();
}
	
	
void SoundEngine::destroy()
{
	if (fxEngine != NULL)
		delete fxEngine;
	if (musicEngine != NULL)
		delete musicEngine;
}


void SoundEngine::timeTick()
{
	if (!mute)
	{
		UInt32 currentTicks = TimGetTicks();

	    if (currentTicks >= nextTimer)
		{
  			nextTimer = currentTicks + 15;

			if ((fxEngine == NULL) || (!(fxEngine->timeTick())))
			{
				if (musicEngine != NULL)
					musicEngine->timeTick();
			}
   		} 
	}
}


// ================================================ FxEngine ================================================================


FxEngine::FxEngine(UInt16 baseAmplitude)
{
	this->baseAmplitude = baseAmplitude;
	playing = false;
}


FxEngine::~FxEngine()
{
}

	
Boolean FxEngine::timeTick()
{
	if (!playing)
		return false;

	Boolean finished = false;
	
    MemHandle resH = DmGetResource( (DmResType)'Tsfx', fxResID );
    ErrNonFatalDisplayIf( !resH, "Effect not found!" );
    UInt8* sfxBytes = (UInt8*)MemHandleLock(resH);	

	do
	{
		UInt8* sfxPos = sfxBytes + fxPosition * 4;
		UInt16 frequency = *((UInt16*)sfxPos);
		UInt16 duration = (UInt16)(*((UInt8*)(sfxPos + 2)));
		Int16  amplitude = (Int16)(*((Int8*)(sfxPos + 3)));

		if (frequency == FREQ_END)
		{
			playing = false;
			finished = true;
			continue;
		}
				
		SndCommandType snd;
		snd.cmd = sndCmdFreqDurationAmp;
		
		snd.param1 = frequency;
		snd.param2 = duration;
		snd.param3 = baseAmplitude + amplitude;

		(void)SndDoCmd(NULL, &snd, 0);

		fxPosition++;
		
		if (duration == DURATION_YIELD)
		{
			finished = true;
		}
	} while(!finished);

  	MemPtrUnlock(sfxBytes);
  	DmReleaseResource( resH );

	return true;
}

	
void FxEngine::playFx(DmResID resID)
{
	fxResID = resID;
	fxPosition = 0;
	playing = true;
}


// ================================================ MusicEngine =============================================================


MusicEngine::MusicEngine(UInt16 baseAmplitude)
{
	channel1Playing = channel2Playing = channel2Playing = false;
	playing = false;
	this->baseAmplitude = baseAmplitude;		
}
	
	
MusicEngine::~MusicEngine()
{
} 


Boolean MusicEngine::timeTick()
{
	if (!playing)
		return false;

	// Play current chord
	if (channel1Playing) hitIt(patternPosition, channel1Pattern, baseAmplitude, baseDuration,     channel2Playing || channel3Playing);
   	if (channel2Playing) hitIt(patternPosition, channel2Pattern, 5,             baseDuration - 3, channel3Playing);  
    if (channel3Playing) hitIt(patternPosition, channel3Pattern, 2,             baseDuration - 5, false);

	// Advance to next position in pattern
	patternPosition++;
   	if (patternPosition > 63)
	{
		// Pattern has been played. Which one do we play next?
		patternPosition = 0;
		trackPosition++;
		setPatternsFromTrack();
   	} 

	return true;
}


void MusicEngine::playSong(DmResID resID)
{
	trackResID = resID;
	patternPosition = 0;
	trackPosition = 0;
	baseDuration = 22;
	playing = true;

	setPatternsFromTrack();	
}


void MusicEngine::stopSong()
{
	playing = false;
}


void MusicEngine::setPatternsFromTrack()
{
    MemHandle resH = DmGetResource( (DmResType)'Ttrk', trackResID );
    ErrNonFatalDisplayIf( !resH, "Track not found!" );
    UInt8* trackBytes = (UInt8*)MemHandleLock(resH);	

	Boolean finished = false;
	do
	{
		UInt8* trackPos = trackBytes + trackPosition * 3;

		UInt8 channel1Byte = *trackPos;
		UInt8 channel2Byte = *(trackPos + 1);
		UInt8 channel3Byte = *(trackPos + 2);
		
		switch(channel1Byte)
		{
			case TRACK_REPEAT:
				trackPosition = 0;
				break;
			case TRACK_END:
				playing = false;
				finished = true;
				break;
			default:
				channel1Pattern = channel1Byte;			
				channel2Pattern = channel2Byte;			
				channel3Pattern = channel3Byte;
				
				channel1Playing = (channel1Byte != CHANNEL_MUTE);
				channel2Playing = (channel2Byte != CHANNEL_MUTE);
				channel3Playing = (channel3Byte != CHANNEL_MUTE);
				
				finished = true;
		}
	} while(!finished);
	
  	MemPtrUnlock(trackBytes);
  	DmReleaseResource( resH );
}


void MusicEngine::playNote(UInt16 note, UInt16 octave, UInt16 amplitude, UInt16 duration, Boolean wait) const
{
	static const Int32 freqHz[] = {66,70,74,78,83,88,93,98,104,110,116,122,
				      131,139,147,156,165,175,185,196,207,220,233,245,
				 	  262,278,294,311,330,349,370,392,415,440,466,494,
	                  523,554,587,622,659,698,740,784,831,880,932,988,
	                  1047,1109,1175,1245,1319,1397,1480,1568,1660,0,0,0};

	ErrNonFatalDisplayIf((note < 0) || (note > 11), "Note out of range");
   	ErrNonFatalDisplayIf(octave > 4, "Invalid octave!");

	SndCommandType snd;
	if (wait)
		snd.cmd = sndCmdFreqDurationAmp;
	else
		snd.cmd = sndCmdFrqOn;
		
	snd.param1 = freqHz[octave * 12 + note];
	snd.param2 = duration;
	snd.param3 = amplitude;

	(void)SndDoCmd(NULL, &snd, 0);
}



void MusicEngine::playMute(UInt16 duration, Boolean wait) const
{
	SndCommandType snd;
  		
	if (wait)
	{
		snd.cmd = sndCmdFreqDurationAmp;
		snd.param1 = 0;
		snd.param2 = duration;
	    snd.param3 = 1;
	}
	else
	{
		snd.cmd = sndCmdQuiet;
		snd.param1 = 0;
		snd.param2 = 0;
		snd.param3 = 0;
	}
		
    (void)SndDoCmd(NULL, &snd, 0);  
}


void MusicEngine::hitIt(UInt16 position, UInt16 pattern, UInt16 amplitude, UInt16 duration, Boolean wait) const
{
    MemHandle resH = DmGetResource( (DmResType)'Tpat', (DmResID)pattern );
    ErrNonFatalDisplayIf( !resH, "Pattern not found!" );
    Char* patternString = (Char*)MemHandleLock(resH);
	Char* patternPos = patternString + position * 3;
	Char noteChar  = *patternPos;
	Char sharpChar = *(patternPos + 1);
	Char octaveChar = *(patternPos + 2);
  	MemPtrUnlock(patternString);
  	DmReleaseResource( resH );

	UInt16 note = 0xFFFF;
	switch (noteChar)
	{
	   	case 'c': note =  0; break;
		case 'd': note =  2; break;
		case 'e': note =  4; break;
		case 'f': note =  5; break;
		case 'g': note =  7; break;
		case 'a': note =  9; break;
		case 'b': note = 11; break;
		case '-': break;

		default:
			ErrNonFatalDisplay("Illegal note char!");
		break;
	}

	if (note != 0xFFFF)
	{
		// Determine sharp
		if (sharpChar == '#') note++;

		// Determine octave
   		UInt16 octave = 0;
		switch (octaveChar)
		{
			case '-': octave = 0; break;
			case '1': octave = 1; break;
			case '2': octave = 2; break;
			case '3': octave = 3; break;
			case '4': octave = 4; break;
				
			default:
				ErrNonFatalDisplay("Illegal octave char!");
			break;
		}

   		playNote(note, octave, amplitude, duration, wait);
	}	
	else
	{
   		playMute(duration, wait);
	}
}


#endif // !NO_SOUND
