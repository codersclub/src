/*******************************************************
 *
 * $Id: ActionEngineFactory.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * This file has been placed in the public domain.
 *
 *******************************************************/



#ifndef ACTIONENGINE_FACTORY_H
#define ACTIONENGINE_FACTORY_H

#include <PalmOS.h>


/**
 * A factory for the ActionEngine object. Include the correct header and modify createActionEngine accordingly.
 */
#include "DemoActionEngine.h"
static ActionEngine& createActionEngine()
{
	return (*(new DemoActionEngine()));
}


#endif
