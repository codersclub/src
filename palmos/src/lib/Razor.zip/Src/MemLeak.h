/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: MemLeak.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 * Adapted from: http://www.fifthgate.org/articles/palm_mem_leaks.html
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef _MEM_LEAK_H_
#define _MEM_LEAK_H_

#include <PalmOS.h>

#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

MemPtr _SafeMemPtrNew(UInt32 size, Char *file, UInt32 line);
Err    _SafeMemPtrFree(void* addr, Char *file, UInt32 line);

#define SafeMemPtrNew(size) _SafeMemPtrNew(size,__FILE__,__LINE__)
#define SafeMemPtrFree(addr) _SafeMemPtrFree(addr,__FILE__,__LINE__)

#else /* ! ERROR_CHECK_FULL */

#define SafeMemPtrNew(size) MemPtrNew(size)
#define SafeMemPtrFree(addr) MemPtrFree(addr)

#endif /* ! ERROR_CHECK_FULL */

#endif /* ! _MEM_LEAK_H_ */
