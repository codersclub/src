/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: SoundEngine.h,v 1.1.1.1 2000/12/09 09:28:40 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/



#ifndef SOUND_ENGINE_H
#define SOUND_ENGINE_H

#include <PalmOS.h>
#include "Customization.h"


#ifdef NO_SOUND

class SoundEngine
{
	public:

	static void timeTick();

	private:
	SoundEngine() {};
	~SoundEngine() {};

	static void init();
	static void destroy();

	friend class Presentation;
};

#else


class MusicEngine;
class FxEngine;


/**
 * SoundEngine is a facade for sound output from two different sources (music, FX).
 */
class SoundEngine
{
	public:		
	/**
	 * Play a sound effect which is stored in a resource of type 'Tsfx' with the
	 * specified resource ID.
     *
     * @param resID the ID of the 'Tsfx' resource
	 */
	static void playFx(DmResID resID);
	
	/**
	 * Play a song where the sequence of patterns is stored in a resource of type
	 * 'Ttrk' with the specified resource ID. 
	 * The patterns themselves are stored in resources of type 'Tpat' where the 
	 * pattern ID is the resource ID.
     *
     * @param resID the ID of the 'Ttrk' resource
	 */
	static void playSong(DmResID resID);
	
	
	/**
	 * Stop the currently playing song.
	 */
	static void stopSong();
	

	/**
	 * This method needs to be invoked periodically, in order for SoundEngine
	 * to work.
	 */
	static void timeTick();


	private:	
	// SoundEngine cannot be instantiated or destroyed.
	SoundEngine() {}	
	~SoundEngine() {}

	static void init();
	static void destroy();

	static FxEngine *fxEngine;
	static MusicEngine *musicEngine;

	static UInt16 baseAmplitude;
	static Boolean mute;
	static UInt32 nextTimer;


	friend class Presentation;
};



/**
 * FxEngine can play sound fx.
 */
class FxEngine
{
	private:
	
	FxEngine(UInt16 baseAmplitude);
	~FxEngine();
	
	/**
	 * Play the next portion of the sound.
     *
	 * @return true = sound has been played, false = no sound has been played
	 */
	Boolean timeTick();
	
	void playFx(DmResID resID);


	Boolean playing;
	DmResID fxResID;
	UInt16 fxPosition;
	UInt16 baseAmplitude;

	/// A frequency with value FREQ_END means, that the end of the sound effect has been reached.
	static const UInt16 FREQ_END = 0x0000;
	/// A duration with value DURATION_YIELD means, that timeTick() shall return control to the caller.
	static const UInt8 DURATION_YIELD = 0x00;

	friend class SoundEngine;
};


/**
 * MusicEngine can playback music. It is based on a pattern model,
 * comparable to that of MOD players, and it can fake three channels.
 */
class MusicEngine
{
	private:

	MusicEngine(UInt16 baseAmplitude);
	~MusicEngine();


	/**
	 * Play the next portion of the sound.
     *
	 * @return true = sound has been played, false = no sound has been played
	 */
	Boolean timeTick();

	void playSong(DmResID resID);
	void stopSong();

	void setPatternsFromTrack();

	void playNote(UInt16 note, UInt16 octave, UInt16 amplitude, UInt16 duration, Boolean wait) const;
	void playMute(UInt16 duration, Boolean wait) const;

	void hitIt(UInt16 position, UInt16 pattern, UInt16 amplitude, UInt16 duration, Boolean wait) const;


	DmResID trackResID;
	UInt16 trackPosition;
	UInt16 channel1Pattern;
	UInt16 channel2Pattern;
	UInt16 channel3Pattern;
	
	UInt16 pattern;
	UInt16 patternPosition;

	Boolean playing;
	Boolean channel1Playing;
	Boolean channel2Playing;
	Boolean channel3Playing;

	UInt16 baseDuration;
	UInt16 baseAmplitude;

	static const UInt8 CHANNEL_MUTE = 0xFD;
	static const UInt8 TRACK_REPEAT = 0xFE;
	static const UInt8 TRACK_END    = 0xFF;

	friend class SoundEngine;
};


#endif // !NO_SOUND

#endif
