/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: SpriteEngine.h,v 1.1.1.1 2000/12/09 09:28:40 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/



#ifndef SPRITE_ENGINE_H
#define SPRITE_ENGINE_H

#include <PalmOS.h>
#include "Canvas.h"


class SpriteGroup;


/**
 * AnimFrames manages the frames of an animated Sprite. Each Sprite is associated
 * with an instance of AnimFrames. Several Sprites may share the same instance of
 * AnimFrames if they have the same appearance. This is recommended, since it saves
 * valuable resources.<br>
 * All frames within an AnimFrames object share the same size, the same hotspot and the same
 * mode of optimization.
 */
class AnimFrames
{
	public:

	enum OptimizationMode
	{
		optNONE       = 0,   ///<Do not optimize the frames
		optBUFFER     = 1,   ///<Draw the frames into an offscreen buffer for faster display
		optNO_MASK    = 2    ///<Make the frames non-transparent. Do this whenever possible!
	};



	/**
	 * Create an instance of AnimFrames. The frames will be constructed from bitmap
	 * resources in a resource database. The bitmap families for the frames need to
	 * be stored at IDs bitmapID..(bitmapID + numFrames) - 1. The 1bpp bitmaps for the
	 * transparency masks need to be stored at IDs maskID..(maskID + numFrames) - 1.
	 *
     * @param numFrames the number of frames
	 * @param bitmapID the ID of the first image bitmap in the resource database.
	 * @param maskID the ID of the first mask bitmap in the resource database, or -1 when no masks are desired (optimizationMode == optNO_MASK).
	 * @param hotSpotX the horizontal offset of the hotspot.
	 * @param hotSpotY the vertical offset of the hotspot.
	 * @param optimizationMode which optimizations shall be applied?
	 */
	AnimFrames(UInt16 numFrames, DmResID bitmapID, DmResID maskID = -1, Coord hotSpotX = 0, Coord hotSpotY = 0, OptimizationMode optimizationMode = optNONE);


	/**
	 * Destroy the AnimFrames and deallocate all used resources.
	 */
	~AnimFrames();


	/**
	 * Get the screen space filled by the AnimFrames when it is placed at the specified coordinates.
	 *
	 * @param x the x coordinate
	 * @param y the y coordinate
     * @param bounds a pointer to a rectangle which will be filled with the screen space
     *        filled by the AnimFrames.
	 */
	void getBounds(Coord x, Coord y, RectangleType *bounds) const;


	private:

	
	/**
	 * Draw a frame at the specified location.
	 * Inquire the current draw window and allocate draw buffers as neccessary.
     *
	 * @param index the index of the displayed frame (0..numFrames).
	 * @param x the x coordinate
	 * @param y the y coordinate
     * @param bounds a pointer to a rectangle which will be filled with the screen space
     *        filled by the frame, or NULL.
	 */
	void draw(UInt16 index, Coord x, Coord y, RectangleType *bounds = NULL) const;


	/**
	 * Draw the frame at the specified location into the specified drawWindow 
	 * and use the specified offScreen buffer for internal drawing operations.
     *
	 * @param index the index of the displayed frame (0..numFrames).
	 * @param x the x coordinate
	 * @param y the y coordinate
     * @param bounds a pointer to a rectangle which will be filled with the screen space
     *        filled by the frame, or NULL.
	 */
	void quickDraw(UInt16 index, Coord x, Coord y, WinHandle drawWindow, WinHandle offScreenH, RectangleType *bounds) const;
	

	OptimizationMode getOptimizationMode() const;


	UInt16  numFrames;
	DmResID bitmapID;
	DmResID maskID;
	Coord hotSpotX;
	Coord hotSpotY;
	Int16 width;
	Int16 height;
	OptimizationMode optimizationMode;

	struct FrameDescriptor
	{
		WinHandle offScreenBitmap;
		WinHandle offScreenMask;
	};
	
	FrameDescriptor *frameDescriptors;
	
	friend class Sprite;
};



/**
 * Sprite describes a single sprite, i.e. a movable graphical object
 * with a transparent background.
 */
class Sprite
{
	public:

	/**
	 * Create a Sprite with no animation. The required AnimFrames object will be created implicitly, and will automatically
	 * be destroyed when the sprite is destroyed.
	 *
	 * @param bitmapID the ID of the image bitmap in the resource database.
	 * @param maskID the ID of the mask bitmap in the resource database, or -1 when no masks are desired (optimizationMode == optNO_MASK).
	 * @param hotSpotX the horizontal offset of the hotspot.
	 * @param hotSpotY the vertical offset of the hotspot.
	 * @param visible shall the sprite be visible?
	 * @param optimizationMode which optimizations shall be applied?
	 */
	Sprite(DmResID bitmapID, DmResID maskID = -1, Coord hotSpotX = 0, Coord hotSpotY = 0, Boolean visible = true, AnimFrames::OptimizationMode optimizationMode = AnimFrames::optNONE);


	/**
	 * Create an animated sprite with the specified AnimFrames. Ownership of the AnimFrames object is <em>NOT</em>
	 * transferred to the Sprite. It will not automatically be destroyed when the Sprite is destroyed.
	 *
	 * @param animFrames a reference to an AnimFrames object
	 * @param visible shall the sprite be visible?
	 */
	Sprite(AnimFrames& animFrames, Boolean visible = true);
	
	
	/**
	 * Destroy the Sprite and deallocate all used resources.
	 */
	~Sprite();


	/**
	 * Show the sprite during subsequent draws.
	 */
	void show();


	/**
	 * Hide the sprite during subsequent draws.
	 */
	void hide();


	/**
	 * Set the visibility of the sprite through a flag.
     *
	 * @param visible shall the sprite be visible (true = shown / false = hidden)
	 */
	Boolean setVisibility(Boolean visible);


	/**
	 * Will the sprite be drawn during subsequent draws?
	 */
	Boolean isVisible() const;


	/**
	 * Set the displayed frame of the Sprite.
	 *
	 * @param frameIndex the index of the displayed frame. Must be between 0..numFrames-1 of the associated AnimFrames.
	 */
	void setFrame(UInt16 frameIndex);


	/**
	 * Move the sprite (i.e. its hotspot) to the specified coordinates.
	 */
	void move(Coord x, Coord y);


	/**
	 * Draw the sprite at its current location.
	 * Inquire the current draw window and allocate draw buffers as neccessary.
     *
     * @param bounds a pointer to a rectangle which will be filled with the screen space
     *        filled by the sprite, or NULL.
	 */
	void draw(RectangleType *bounds = NULL) const;


	/**
	 * Get the screen space filled by the sprite.
	 *
     * @param bounds a pointer to a rectangle which will be filled with the screen space
     *        filled by the sprite.
	 */
	void getBounds(RectangleType *bounds) const;



	private:

	
	/**
	 * Draw the sprite at its current location into the specified drawWindow 
	 * and use the specified offScreen buffer for internal drawing operations.
	 */
	void quickDraw(WinHandle drawWindow, WinHandle offScreenH, RectangleType *bounds) const;
	

	AnimFrames::OptimizationMode getOptimizationMode() const;


	AnimFrames *animFrames;
	Boolean ownsAnimFrames;

	UInt16 frameIndex;
	Boolean visible;
	Coord x;
	Coord y;


	// Ain't it nice to have friends...
	friend class SpriteGroup;
};



/**
 * SpriteGroup assists in the management of a collection of sprites.
 */
class SpriteGroup
{
	public:
	
	
	/**
	 * Create the SpriteGroup. The group may contain up to maxSprites Sprites.
	 * @param maxSprites the maximum number of managed sprites
	 */
	SpriteGroup(int maxSprites);
	
	
	/**
	 * Destroy the SpriteGroup and deallocate all used resources.
	 */
	~SpriteGroup();


	/**
	 * Add a sprite to the group.
	 *
	 * @param sprite a reference to the sprite. Ownership of the sprite will remain
	 *        with the caller, i.e. SpriteGroup will not destroy the sprite when the
	 *        group is destroyed.
	 */
	void addSprite(Sprite& sprite);


	/**
	 * Draw all the sprites in the group.
	 */
	void draw(RectangleType *bounds);


	private:

	int maxSprites;
	int currSprites;
	Sprite* *theSprites;
	
	WinHandle offscreenH;
	int maxWidth;
	int maxHeight;
	int oldMaxWidth;
	int oldMaxHeight;
	Boolean needBuffer;
};



#endif
