/*******************************************************
 *
 * $Id: DemoActionEngine.h,v 1.2 2000/12/17 11:50:30 christ Exp $
 *
 * This file has been placed in the public domain.
 *
 *******************************************************/


#ifndef DEMOACTIONENGINE_H
#define DEMOACTIONENGINE_H

#include <PalmOS.h>

#include "Customization.h"

#include "ActionEngine.h"
#include "HardKeyManager.h"
#include "SpriteEngine.h"
#include "SoundEngine.h"


/**
 * DemoActionEngine demonstrates the implementation of a
 * customized ActionEngine. 
 */
class DemoActionEngine : public ActionEngine
{
	public:

	DemoActionEngine() : ActionEngine()
	{
		// Prepare two animated Sprites (both with the same frames of animation),
		// and add them to a SpriteGroup for optimized drawing,
		tuxFrames = new AnimFrames(3, 2000, 2005, 42, 75, AnimFrames::optBUFFER);
		sprite1 = new Sprite(*tuxFrames, true);
		sprite2 = new Sprite(*tuxFrames, true);

		spriteGroup = new SpriteGroup(2);
		spriteGroup->addSprite(*sprite1);
		spriteGroup->addSprite(*sprite2);
	}


	~DemoActionEngine()
	{
		delete spriteGroup;
		delete sprite1;
		delete sprite2;
		delete tuxFrames;
	}

	
	void restart()
	{
		state.periodCounter = state.lastMoved = 0;
		state.xCoord = 80;
		state.yCoord = 80;

		SoundEngine::playSong(0);
	}


	void nextPeriod()
	{
		state.periodCounter++;


		// Evaluate the currently pressed keys
		UInt32 keyState = HardKeyManager::getCurrentState();

		if (keyState & (keyBitHard1 | keyBitHard2 | keyBitHard3 | keyBitHard4 | keyBitPageDown | keyBitPageUp))
		{
			state.lastMoved = state.periodCounter;
				
			if (keyState & keyBitHard1)
				state.xCoord -= 5;
			else if (keyState & keyBitHard2)
				state.xCoord += 5;

			if (keyState & keyBitPageDown)
				state.yCoord += 5;
			else if (keyState & keyBitPageUp)
				state.yCoord -= 5;


			if (keyState & keyBitHard3)
			{
				SoundEngine::playFx(0);
				sprite1->setVisibility(!(sprite1->isVisible()));
			}

			if (keyState & keyBitHard4)
				sprite2->setVisibility(!(sprite2->isVisible()));
		}

				
		// Walk around if the user hasn't moved us for a while...
		if ((state.periodCounter - state.lastMoved) > 100)
			state.xCoord += 4;


		// Wrap around at screen edge
		if (state.xCoord > 200)
			state.xCoord = -40;

		if (state.yCoord > 220)
			state.yCoord = -60;
		
		sprite1->move(state.xCoord, state.yCoord);
		sprite2->move(80 - (state.xCoord - 80), state.yCoord + 20);

		sprite1->setFrame((state.periodCounter >> 2) % 3);
	}


	WinLockInitType getWinLockMode() const
	{
		return winLockErase;   // We always want a clear background.
	}


	void draw(RectangleType *bounds) const
	{
		// Paint sprites
		spriteGroup->draw(bounds);
	}


	void receiveEvent(const EventType* /* evtPtr */)
	{
		// We're not interested in any events
	}


// ================================== Save & Restore =============================================================

	void* getRestoreStateBuffer()
	{
		return &state;
	}
	
	void releaseRestoreStateBuffer(void* /* stateBuffer */) const
	{
		// The state buffer is static. Do nothing.
	}
	
	void* getSaveStateBuffer()
	{
		return &state;
	}
	
	void releaseSaveStateBuffer(void* /* stateBuffer */) const
	{
		// The state buffer is static. Do nothing.
	}
	
	Int16 getStateBufferSize() const
	{
		return sizeof(state);
	}

	void restoreState(void *stateBuffer)
	{
		ErrNonFatalDisplayIf(stateBuffer != &state, "State buffer mismatch!");

		sprite1->move(state.xCoord, state.yCoord);
		sprite2->move(80 - (state.xCoord - 80), state.yCoord + 20);
	}


	private:	

	struct
	{
		UInt32 periodCounter;
		UInt32 lastMoved;
	
		Coord xCoord;
		Coord yCoord;
	} state;


	AnimFrames *tuxFrames;
	Sprite *sprite1;
	Sprite *sprite2;
	SpriteGroup *spriteGroup;
};


#endif
