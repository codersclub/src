/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Starter.cpp,v 1.1.1.1 2000/12/09 09:28:40 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include <PalmOS.h>
#include "../Rsc/StarterRsc.h"

#include "Device.h"
#include "Presentation.h"
#include "Customization.h"

/**
 * @file Starter.cpp
 * The main application. This is the bare skeleton of a functional
 * PalmOS application. It delegates most of the work to a Presentation
 * object.
 */



// ***********************************************************************

static Presentation *presentation;

// ***********************************************************************



/**
 * Perform the specified menu command
 *
 * @param command menu item id
 *
 * @return true if the command has been handled
 */
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;

	switch (command)
	{
		case MainOptionsAboutRazor:
			presentation->pause();

			MenuEraseStatus(0);					// Clear the menu status from the display.
			FormType* frmP = FrmInitForm(AboutForm);
			FrmDoDialog (frmP);					// Display the About Box.
			FrmDeleteForm (frmP);
			handled = true;
			
			presentation->resume();
		break;
	}
	
	return handled;
}


/**
 * The event handler for the "MainForm" of this application.
 * 
 * @param eventP a pointer to an EventType structure
 *
 * @return true if the event has been handled and should not be passed to a higher level handler.
 */
static Boolean MainFormHandleEvent(EventType* eventP)
{
	Boolean handled = false;

	switch (eventP->eType) 
	{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);

		case frmOpenEvent:
			{   // This scope is required for PRC-Tools 2.0
				FormType* frmP = FrmGetActiveForm();
				FrmDrawForm (frmP);
			}
			// Begin the presentation
			presentation->begin();

			handled = true;			
			break;

		default:
			break;		
	}
	
	return handled;
}




/**
 * Load form resources and set the event handler for the form loaded.
 *
 * @param eventP a pointer to an EventType structure
 *
 * @return true if the event has been handled and should not be passed to a higher level handler.
 */
static Boolean AppHandleEvent(EventType* eventP)
{
	if (eventP->eType == frmLoadEvent)
	{
		// Load the form resource.
		UInt16 formId = eventP->data.frmLoad.formID;
		FormType* frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
		{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			default:
				ErrNonFatalDisplay("Invalid Form Load Event");
				break;

		}
		return true;
	}
	
	return false;
}


/**
 * The event loop for the application.  
 */
static void AppEventLoop()
{
	UInt16 error;
	EventType event;
	Boolean redrawWhenReturningToGameWindow;


	// The game has not yet begun. Let PalmOS handle all events until
	// frmOpenEvent has been received on the Main form.
	do
	{
		EvtGetEvent (&event, evtWaitForever);
		if (! SysHandleEvent (&event))
			if (! MenuHandleEvent (NULL, &event, &error))
				if (! AppHandleEvent (&event))
					FrmDispatchEvent (&event);

	} while ((event.eType != appStopEvent) && (!(presentation->hasBegun())));


	do
	{
		// Wait until the next game period.
		EvtGetEvent (&event, presentation->getTimeUntilNextPeriod());
		
		
		// Detect exiting the game's window.  This must be checked for.  At this
		// point there probably exists another window which may cover part of
		// the MainView window.  Suppress drawing.  Otherwise drawing may draw
		// to part of the window covered by the new window.
		if (event.eType == winExitEvent)
		{
			if (event.data.winExit.exitWindow == (WinHandle) FrmGetFormPtr(MainForm))
			{
				presentation->pause();
			}
		}

		// Detect entering the game's window.  Resume drawing to our window.
		else if (event.eType == winEnterEvent)
		{
			// In the current code, the menu doesn't remove itself when it receives
			// a winExitEvent.
			if (event.data.winEnter.enterWindow == (WinHandle) FrmGetFormPtr(MainForm) &&
				event.data.winEnter.enterWindow == (WinHandle) FrmGetFirstForm ())
			{
				// Sometimes we can enter the game's window without knowing it was 
				// ever left.  In that case the pause time will not have been recorded.
				// Presentation is smart enough to handle that, and will set the current 
				// period back to it's beginning.
				presentation->resume();
				
				
				// Redraw the game window.  This is normally triggered when the launcher
				// is activated during a low heap memory condition to work around a launcher
				// bug which causes it to fail to send a frmUpdateEvent when it doesn't
				// restore the bits underneath it.
				if (redrawWhenReturningToGameWindow)
				{
					presentation->redraw();
					redrawWhenReturningToGameWindow = false;
				}
			}
		}
		else
		{
			presentation->receiveEvent(&event);

			// If it's time, go to the next time period
			if (presentation->getTimeUntilNextPeriod() == 0)
			{		
				presentation->nextPeriod();
			}
		}


		if (event.eType == nilEvent)
			continue; 


		// Intercept the hard keys to prevent them from switching apps
		if (event.eType == keyDownEvent)
		{
			// Swallow events notifying us of key presses.  We poll instead.
			if (event.data.keyDown.chr >= hard1Chr &&
				event.data.keyDown.chr <= hard4Chr &&
				!(event.data.keyDown.modifiers & poweredOnKeyMask))
			{
				continue;
			}
			
			// Handle a launcher bug.  It can fail to send a frmUpdateEvent.
			else if (event.data.keyDown.chr >= launchChr)
			{
				UInt32 freeBytes;
				UInt32 maxChunk;
				const UInt32 saveBitsThreshold = 4000;
								
				MemHeapFreeBytes (0, &freeBytes, &maxChunk);
				if (freeBytes <= saveBitsThreshold)
				{
					redrawWhenReturningToGameWindow = true;
				}
			}

		}



		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/**
 * Prepare the App for running
 */
static Err AppStart(UInt16 launchFlags)
{
	Device::init();

	Err error = Device::romVersionCompatible(appMinRomVersion, launchFlags);
	if (error != errNone) 
		return error;

	// Establish the presentation
	presentation = new Presentation();

	return errNone;
}


/**
 * Shutdown the App (save prefs, restore display to normal)
 */
static void AppStop()
{
	// Close all the open forms.
	FrmCloseAllForms ();

	delete presentation;
}


/**
 * This is the main entry point for the application.
 *
 * @param cmd word value specifying the launch code. 
 * @param cmdPB pointer to a structure that is associated with the launch code. 
 * @param launchFlags word value providing extra information about the launch.
 *
 * @return Result of launch
 */
static UInt32 StarterPalmMain(UInt16 cmd, void* /*cmdPBP*/, UInt16 launchFlags)
{
	if (cmd == sysAppLaunchCmdNormalLaunch)
	{
		Err error = AppStart(launchFlags);
		if (error != errNone)
			return error;
				
		FrmGotoForm(MainForm);
		AppEventLoop();
		AppStop();

		return errNone;
	}
	else
	{
		return errNone;
	}
}


/**
 * This is the public main entry point for the application.
 *
 * @param cmd word value specifying the launch code. 
 * @param cmdPB pointer to a structure that is associated with the launch code. 
 * @param launchFlags word value providing extra information about the launch.
 *
 * @return Result of launch
 */
UInt32 PilotMain( UInt16 cmd, void* cmdPBP, UInt16 launchFlags)
{
    return StarterPalmMain(cmd, cmdPBP, launchFlags);
}

