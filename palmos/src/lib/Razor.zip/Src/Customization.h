/*******************************************************
 *
 * $Id: Customization.h,v 1.3 2000/12/17 11:49:16 christ Exp $
 *
 * This file has been placed in the public domain.
 *
 *******************************************************/



#ifndef CUSTOMIZATION_H
#define CUSTOMIZATION_H

#include <PalmOS.h>
#include "Canvas.h"


/********************************************************
 * Modify the settings in this file to adjust the
 * behavior of the Razor! Engine to your requirements.
 ********************************************************/


/**
 * Application settings
 */

// Make sure the linker settings match these!!!
static const UInt32 appCreator        = 'Razr';    // Don't use this default!  Obtain your own Creator ID from Palm, Inc.!!!
static const Int16  appVersionNum     = 0x01;

// The framework requires a minimum of v3.0, but you can raise the limit as required by your own application.
static const UInt32 appMinRomVersion = sysMakeROMVersion(3,0,0,sysROMStageRelease,0);

// Shall auto-off be disabled while presentation is running?
static const Boolean appPreventAutoOff = true;

/**
 * Presentation settings
 */

// How long is one time-slice (1/100 secs)?
static const UInt32 presAdvanceTimeInterval            =   6;			

// How long do we wait after starting, or resuming the presentation (1/100 secs)? 
// You might want to set this to zero, and handle these pauses yourself in your ActionEngine.
static const UInt32 presPauseLengthBeforeResuming      =   0;			


/**
 * Sound settings
 */
// Define this, if you don't want any sound
#undef NO_SOUND
//#define NO_SOUND


/**
 * Canvas settings
 */

// Supported bit-depths and color modes. Put more desired modes first. Always terminate with a zero!!!
static UInt32 supportedCanvasModes[] = {Canvas::COLOR_8BPP, Canvas::GRAY_2BPP, 0};


/**
 * A factory for the Canvas object. Include the correct header and modify createCanvas accordingly.
 */
#include "DoubleBufferCanvas.h"
static Canvas& createCanvas()
{
	return (*(new DoubleBufferCanvas()));
}


/**
 * The Factory for the ActionEngine, which is the most import class in this engine had to be moved to
 * an extra file called ActionEngineFactory.h, in order to avoid nasty circular includes. 
 * 
 * BE SURE TO MODIFY THIS FILE!!!!
 */


#endif
