/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: ActionEngine.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef ACTIONENGINE_H
#define ACTIONENGINE_H

#include <PalmOS.h>

#include "Canvas.h"


/**
 * ActionEngine defines the interface for the application-specific
 * behavior. It is triggered in regular intervals and has to react
 * by providing a visual representation of the current state.
 */
class ActionEngine
{
	public:
	/**
	 * Construct a new ActionEngine
	 */
	ActionEngine() 
	{
	}


	/**
	 * Destroy the ActionEngine
	 */
	virtual ~ActionEngine() {}
	
	/**
	 * Reset the ActionEngine.
	 */
	virtual void restart() = 0;

	/**
	 * Progress to the next period. Update the internal state of your
	 * ActionEngine, but <em>DO NOT DRAW ANYTHING!</em>. Only draw
	 * in your draw() operation.
	 */
	virtual void nextPeriod() = 0;

	
	/**
	 * This method is invoked before the draw() method in order to
	 * find out, whether the background of the drawing canvas shall
	 * be left untouched since the last draw, erased to white, or
	 * you don't care. 
	 * Don't cache this value, since it might change during each period!
	 *
	 * @return Same semantics as initMode parameter of WinScreenLock function of PalmOS 3.5: 
	 * <ul>
	 * <li>        winLockCopy - Provide the same screen contents as drawn by the last invocation of draw() 
	 * <li>        winLockErase - Erase to white,
	 * <li>        winLockDontCare - Don't care.
	 * </ul>
	 */
	virtual WinLockInitType getWinLockMode() const = 0;


	/**
	 * Draw the visual appearance of the action onto the canvas.
     *
	 * @param bounds this needs to be filled in with the coordinates of the area
	 *               that was modified by the paint operations.
	 */
	virtual void draw(RectangleType *bounds) const = 0;


/// @name Input management
//@{
	/**
	 * Receive an input event.
	 * The ActionEngine can freely decide whether it wants to
	 * react to it, or not.
	 */
	virtual void receiveEvent(const EventType* evtPtr) = 0;
//@}


/// @name Save & Restore
//@{
	/**
     * Get the save buffer. The contents of this buffer will
     * be saved away for later restoration.
 	 */
	virtual void* getSaveStateBuffer() = 0;

	/**
	 * Release the save buffer. This is invoked when the
	 * restore buffer is no longer needed. 
	 */
	virtual void releaseSaveStateBuffer(void *stateBuffer) const = 0;

	/**
	 * Return the size of the buffer which contains the
	 * state. This size is assumed to be the size of
	 * the save state buffer and of the restore state buffer.
	 */
	virtual Int16 getStateBufferSize() const = 0;	

	/**
	 * Get the restore buffer. This buffer will be
	 * filled in with the stored state of the ActionEngine
	 * and then presented to restoreState.
	 */
	virtual void* getRestoreStateBuffer() = 0;

	/**
	 * Release the restore buffer. This is invoked when the
	 * restore buffer is no longer needed. 
	 */
	virtual void releaseRestoreStateBuffer(void *stateBuffer) const = 0;

	/**
	 * Set the current state from the restore buffer. The
	 * buffer is guaranteed to be identical to the one
	 * which was returned by getRestoreStateBuffer().
	 */
	virtual void restoreState(void *stateBuffer) = 0;
//@}
};


#endif
