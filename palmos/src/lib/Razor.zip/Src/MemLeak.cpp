/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: MemLeak.cpp,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 * Adapted from: http://www.fifthgate.org/articles/palm_mem_leaks.html
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include <PalmOS.h>
#include "MemLeak.h"

#if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL

static const char *LEAK_OUT_NAME = "leaks.txt";

MemPtr _SafeMemPtrNew(UInt32 size, Char *file, UInt32 line)
{
    MemPtr addr = MemPtrNew(size);

    HostFILE *hf = HostFOpen(LEAK_OUT_NAME,"a");
    if (hf) 
    {
    	HostFPrintF(hf,"@ 0x%lx 0x%lx %s %ld\n", (UInt32)addr, size, file, line);
        HostFClose(hf);
    }

    return addr;
}

Err _SafeMemPtrFree(void *addr, Char *file, UInt32 line)
{
    ErrFatalDisplayIf(addr == NULL, "_SafeMemPtrFree: addr == 0!");

    Err error = MemPtrFree(addr);
	ErrFatalDisplayIf(error != errNone, "_SafeMemPtrFree: Error!");


    HostFILE *hf = HostFOpen(LEAK_OUT_NAME,"a");
    if (hf) 
    {
    	HostFPrintF(hf,"! 0x%lx %s %ld\n", (UInt32)addr, file, line);
        HostFClose(hf);
    }

	return error;
}


#endif
