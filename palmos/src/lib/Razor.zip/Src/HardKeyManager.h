/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: HardKeyManager.h,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef HARDKEYMANAGER_H
#define HARDKEYMANAGER_H

#include <PalmOS.h>


/**
 * HardKeyManager manages the hard keys (Up/Down, Calendar, Address Book, etc.) of the device.
 * It can prevent them from switching apps, it can modify their repeat rate, and it can poll their state.
 */
class HardKeyManager
{
	public:	

	
	/**
	 * Prepare the hard keys for polling (i.e. turn off event generation). Idempotent.
	 */
	static void captureHardKeys();
	

	/**
	 * Return the hard keys to event generation mode. Idempotent.
	 */
	static void releaseHardKeys();
		

	/**
	 * Get the current state of the hard keys.
	 * The result will be identical to that from
	 * the KeyCurrentState() PalmOS call.
	 *
	 * @return the currently pressed keys. Use the keyXXX constants from KeyMgr.h to decipher it.
	 */
	static UInt32 getCurrentState();
	

	/**
	 * Express your interest in the keys specified by the mask.
	 *
	 * @param the keys you want to listen to. Use the keyXXX constants from KeyMgr.h.
	 */
	static void setMask(UInt32 mask);


	private:

	// HardKeyManager cannot be instantiated or destroyed.
	HardKeyManager() {}
	~HardKeyManager() {}


	/**
	 * Prepare the HardKeyManager for use.
	 */
	static void init();
	
	
	/**
	 * Release the hard keys and all other resources.
	 */
	static void destroy();


	// Constants
	static const UInt32 keysAllowedMask = (keyBitHard1 | keyBitHard2 | keyBitHard3 | keyBitHard4 | keyBitPageUp | keyBitPageDown );
	
	// Current key settings
	static UInt32 mask;

	// Original key settings
	static UInt16 oldInitDelay;
	static UInt16 oldPeriod;
	static UInt16 oldDoubleTapDelay;
	static Boolean oldQueueAhead;

	friend class Presentation;
};


#endif
