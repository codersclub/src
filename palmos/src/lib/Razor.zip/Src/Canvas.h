/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Canvas.h,v 1.2 2000/12/17 11:48:57 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/

#ifndef CANVAS_H
#define CANVAS_H

#include <PalmOS.h>

/**
 * Canvas manages a canvas into which a user can paint.
 */
class Canvas
{
	public:

	/// 1bpp b/w
	static const UInt32 GRAY_1BPP   = 0x00000001;  
	/// 2bpp grayscale
	static const UInt32 GRAY_2BPP   = 0x00000002;
	/// 4bpp grayscale
	static const UInt32 GRAY_4BPP   = 0x00000008;
	/// 4bpp color. Use the special 4bpp color commands from PilRC 2.6 or higher to generate the required bitmap resources.
	static const UInt32 COLOR_4BPP  = 0x80000008;
	/// 8bpp color
	static const UInt32 COLOR_8BPP  = 0x80000080;
	/// 16bpp color. Use the special HandSpring resource compiler to generate the required bitmap resources.
	static const UInt32 COLOR_16BPP = 0x80008000;


///@name Construction / Destruction
//@{
	/**
	 * Construct a new canvas.
	 */
	Canvas();


	/**
	 * Destroy the canvas.
	 */
	virtual ~Canvas();
//@}


/// @name Output management
//@{
	/**
	 * Switch drawing window to the window into which the application shall paint.
	 */
	virtual void beginDraw(WinLockInitType initMode) = 0;
	
	/**
	 * Notify the canvas of the end of user paint operations.
	 * 
	 * @param bounds the area that was modified by the user draw operation
	 */
	virtual void endDraw(RectangleType *bounds) = 0;

	/**
	 * Display user painted graphics.
	 */
	virtual void show() = 0;	
//@}


/// @name Physical Display management
//@{
	/**
	 * Get the width of the display
	 */
	Coord getWidth() const
	{
		return width;
	}

	
	/**
	 * Get the height of the display
	 */
	Coord getHeight() const
	{
		return height;
	}
//@}



/// @name Utility operations
//@{
	/**
	 * Determine a rectangle that encompasses two other rectangles.
	 *
	 * @param rect1Bound the bounds of rectangle #1
	 * @param rect2Bound the bounds of rectangle #2
	 * @param resultBound the bounds of the encompassing rectangle.
	          rect1Bound, or rect2Bound, and resultBound may safely point to the same RectangleType structure.
	 */
	static void uniteBounds(RectangleType *rect1Bound, RectangleType *rect2Bound, RectangleType *resultBound);
//@}

	protected:
	RectangleType displayBounds;

	Coord width;
	Coord height;
	UInt32 selectedDepth;
	Boolean colorMode;
};


#endif
