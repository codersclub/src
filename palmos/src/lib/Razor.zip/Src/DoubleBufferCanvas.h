/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: DoubleBufferCanvas.h,v 1.2 2000/12/09 10:47:30 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#ifndef DOUBLEBUFFERCANVAS_H
#define DOUBLEBUFFERCANVAS_H

#include <PalmOS.h>
#include "Canvas.h"



/**
 * DoubleBufferCanvas manages a <EM>double-buffered</EM> canvas into which a user can paint.
 */
class DoubleBufferCanvas : public Canvas
{
	public:

	DoubleBufferCanvas();
	
	~DoubleBufferCanvas();

	void beginDraw(WinLockInitType initMode);
		
	void endDraw(RectangleType *bounds);

	void show();

	private:
	WinHandle deviceDrawWindowH;
	WinHandle screenBufferH;

	RectangleType currentBounds;
	RectangleType lastBounds;
	RectangleType copyBounds;
};


#endif
