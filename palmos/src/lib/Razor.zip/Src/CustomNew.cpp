/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: CustomNew.cpp,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include <PalmOS.h>
#include "Device.h"
#include "MemLeak.h"

/**
 * @file CustomNew.cpp
 * Overloaded global operators new and delete. The default operators
 * throw an std:bad_alloc exception, which requires C++ exception
 * handling to be enabled. The customized versions will invoke
 * Device::panic in case of insufficient memory.
 */


/**
 * Operator new that panics instead of throwing std::bad_alloc.
 */
void * operator new (UInt32 size)
{
	// C++ specs require the allocation of at least one byte, regardless of request size
	if (size == 0L)
		size = 1L;

    void *p = SafeMemPtrNew(size);
    
    if (p == NULL)
    	Device::panic(memErrNotEnoughSpace, "Not enough memory for operator new");

	return p;    	    	
}


/**
 * Operator new that panics instead of throwing std::bad_alloc.
 */
void * operator new[] (UInt32 size)
{
	// C++ specs require the allocation of at least one byte, regardless of request size
	if (size == 0L)
		size = 1L;

    void *p = SafeMemPtrNew(size);
    
    if (p == NULL)
    	Device::panic(memErrNotEnoughSpace, "Not enough memory for operator new");

	return p;    	    	
}


/**
 * Operator delete that is compatible with the customized operators new.
 */
void operator delete(void* p)
{
	Err error = SafeMemPtrFree(p);
	
	// It's probably a good idea to stop a program which has corrupted memory
	ErrFatalDisplayIf(error != errNone, "Invalid pointer for delete.");
}


/**
 * Operator delete that is compatible with the customized operators new.
 */
void operator delete[] (void* p)
{
	Err error = SafeMemPtrFree(p);
	
	// It's probably a good idea to stop a program which has corrupted memory
	ErrFatalDisplayIf(error != errNone, "Invalid pointer for delete.");
}
