/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Canvas.cpp,v 1.1 2000/12/17 11:48:57 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include "Customization.h"
#include "Canvas.h"
#include "Device.h"

Canvas::Canvas()
{
	//
	// Determine size of display
	//
	WinGetDisplayExtent(&width, &height);
		
	displayBounds.topLeft.x = 0;
	displayBounds.topLeft.y = 0;
	displayBounds.extent.x = width;
	displayBounds.extent.y = height;


	//
	// Set proper color mode and bit-depth
	//
	UInt32 supportedDepths;
	Boolean supportsColor;
	WinScreenMode(winScreenModeGetSupportedDepths, NULL, NULL, &supportedDepths, NULL);		
	WinScreenMode(winScreenModeGetSupportsColor, NULL, NULL, NULL, &supportsColor);	
			
	// Iterate over all supported modes
	for (UInt16 i = 0; ; i++)
	{
		UInt32 mode = supportedCanvasModes[i];
		if (mode == 0)
		{
			Device::panic(sysErrParamErr, "Required screen mode not supported by device!");
		}		

		if ((mode & 0x80000000) && (!supportsColor))
		{
			continue;  // Color required, but device is only grayscale.
		}

		if (!(mode & supportedDepths))
		{
			continue;  // Required bit-depth not available
		}

		// All requirements of this mode are fulfilled :-)))

		colorMode = (mode & 0x80000000);

		// Determine selectedDepth
		selectedDepth = 1;
		for (UInt32 selector = 1; ; selector <<= 1, selectedDepth++)
		{
			if (mode & selector)
				break;						
		}
		
		break;
	}


	// Set selected screen mode	
	Err error = WinScreenMode(winScreenModeSet, NULL, NULL, &selectedDepth, NULL);
 	ErrNonFatalDisplayIf(error, "Unable to set screen mode");

	// Ugly hack against broken grayscale palette in PalmOS 3.1. This is fixed in 3.1.1
	if (selectedDepth == 2)
	{
		if ((Device::supports31) && (!(Device::supports35)))
		{					
		    UInt16 value = 3 + (7 << 4) + (1 << 12);
			*((UInt16 *)0xFFFFFA32) = value;    // Poke default grayscale values directly into display controller
		}
	}

	// Enable special 4bpp color mode
	if ((selectedDepth == 4) && colorMode)
	{
		RGBColorType palette[] = {
                             {  0, 0xff, 0xff, 0xff },
                             {  1, 0x80, 0x80, 0x80 },
                             {  2, 0x80, 0x00, 0x00 },
                             {  3, 0x80, 0x80, 0x00 },
                             {  4, 0x00, 0x80, 0x00 },
                             {  5, 0x00, 0x80, 0x80 },
                             {  6, 0x00, 0x00, 0x80 },
                             {  7, 0x80, 0x00, 0x80 },
                             {  8, 0xff, 0x00, 0xff },
                             {  9, 0xc0, 0xc0, 0xc0 },
                             { 10, 0xff, 0x00, 0x00 },
                             { 11, 0xff, 0xff, 0x00 },
                             { 12, 0x00, 0xff, 0x00 },
                             { 13, 0x00, 0xff, 0xff },
                             { 14, 0x00, 0x00, 0xff },
                             { 15, 0x00, 0x00, 0x00 }
                           };
                           
		WinPalette(winPaletteSet,0,16,palette);
	}
}


Canvas::~Canvas() 
{
	// Restore display color-depth to normal
   	WinScreenMode(winScreenModeSetToDefaults, NULL, NULL, NULL, NULL);
}


void Canvas::uniteBounds(RectangleType *rect1Bound, RectangleType *rect2Bound, RectangleType *resultBound)
{
	Coord rect1RightEdge = rect1Bound->topLeft.x + rect1Bound->extent.x;
	Coord rect2RightEdge = rect2Bound->topLeft.x + rect2Bound->extent.x;

	if (rect1Bound->topLeft.x < rect2Bound->topLeft.x)
		resultBound->topLeft.x = rect1Bound->topLeft.x;
	else
		resultBound->topLeft.x = rect2Bound->topLeft.x;

	if (rect1RightEdge > rect2RightEdge)
		resultBound->extent.x = rect1RightEdge - resultBound->topLeft.x;
	else
		resultBound->extent.x = rect2RightEdge - resultBound->topLeft.x;


	Coord rect1BottomEdge = rect1Bound->topLeft.y + rect1Bound->extent.y;
	Coord rect2BottomEdge = rect2Bound->topLeft.y + rect2Bound->extent.y;

	if (rect1Bound->topLeft.y < rect2Bound->topLeft.y)
		resultBound->topLeft.y = rect1Bound->topLeft.y;
	else
		resultBound->topLeft.y = rect2Bound->topLeft.y;

	if (rect1BottomEdge > rect2BottomEdge)
		resultBound->extent.y = rect1BottomEdge - resultBound->topLeft.y;
	else
		resultBound->extent.y = rect2BottomEdge - resultBound->topLeft.y;
}
