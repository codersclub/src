/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: SpriteEngine.cpp,v 1.1.1.1 2000/12/09 09:28:40 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/



#include "SpriteEngine.h"
#include "SoundEngine.h"        // Needed for invocations of SoundEngine::timeTick()


AnimFrames::AnimFrames(UInt16 numFrames, DmResID bitmapID, DmResID maskID, Coord hotSpotX, Coord hotSpotY, OptimizationMode optimizationMode)
{
	this->numFrames = numFrames;
	this->bitmapID  = bitmapID;
	this->maskID    = maskID;
	this->hotSpotX  = hotSpotX;
	this->hotSpotY  = hotSpotY;		
	this->optimizationMode = optimizationMode;

	// Determine width/height
	MemHandle resH = DmGetResource( bitmapRsc, bitmapID );
	ErrNonFatalDisplayIf( !resH, "Missing bitmap" );
	BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

	this->width  = resP->width;
	this->height = resP->height;

	MemPtrUnlock(resP);
	DmReleaseResource( resH );


	/////////////////////////////
	// Prepare optimized images
	/////////////////////////////
	frameDescriptors = new FrameDescriptor[numFrames];
	
		
	switch(optimizationMode)
	{
	case AnimFrames::optBUFFER:
		{
		WinHandle oldDrawH = WinGetDrawWindow();
		UInt16 error = errNone;

		for (int frameIdx = 0; frameIdx < numFrames; frameIdx++)
		{
			{
				// Paint sprite-bitmap to offscreen window
				MemHandle resH = DmGetResource( bitmapRsc, bitmapID + frameIdx);
				ErrNonFatalDisplayIf( !resH, "Missing bitmap" );
				BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

				frameDescriptors[frameIdx].offScreenBitmap = WinCreateOffscreenWindow(resP->width, resP->height, screenFormat, &error);
				WinSetDrawWindow(frameDescriptors[frameIdx].offScreenBitmap);
				WinDrawBitmap (resP, 0,0);

				MemPtrUnlock(resP);
				DmReleaseResource( resH );
			}

			{
				// Paint sprite-mask to offscreen window
				MemHandle resH = DmGetResource( bitmapRsc, maskID + frameIdx);
				ErrNonFatalDisplayIf( !resH, "Missing mask" );
				BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

				frameDescriptors[frameIdx].offScreenMask = WinCreateOffscreenWindow(resP->width, resP->height, screenFormat, &error);
				WinSetDrawWindow(frameDescriptors[frameIdx].offScreenMask);
				WinDrawBitmap (resP, 0,0);
				MemPtrUnlock(resP);
				DmReleaseResource( resH );				
			}
		}

		WinSetDrawWindow(oldDrawH);
		}			
		break;
		
	case AnimFrames::optNONE:
	case AnimFrames::optNO_MASK:
		for (int frameIdx = 0; frameIdx < numFrames; frameIdx++)
		{
			frameDescriptors[frameIdx].offScreenBitmap = NULL;
			frameDescriptors[frameIdx].offScreenMask   = NULL;
		}		
		break;
	}
}


AnimFrames::~AnimFrames()
{
	for (int frameIdx = 0; frameIdx < numFrames; frameIdx++)
	{
		if (frameDescriptors[frameIdx].offScreenBitmap != NULL)
		{
			WinDeleteWindow(frameDescriptors[frameIdx].offScreenBitmap, false);
		}

		if (frameDescriptors[frameIdx].offScreenMask != NULL)
		{
			WinDeleteWindow(frameDescriptors[frameIdx].offScreenMask, false);
		}
	}

	delete[] frameDescriptors;
}


void AnimFrames::getBounds(Coord x, Coord y, RectangleType *bounds) const
{
	ErrNonFatalDisplayIf(bounds == NULL, "getBounds: bounds == NULL");
	
	bounds->topLeft.x = x - hotSpotX;
	bounds->topLeft.y = y - hotSpotY;
	bounds->extent.x = width;
	bounds->extent.y = height;
}


void AnimFrames::draw(UInt16 index, Coord x, Coord y, RectangleType *bounds) const
{
	UInt16 error;
		
	WinHandle drawWindow = WinGetDrawWindow();

	switch(optimizationMode)
	{
	case AnimFrames::optBUFFER:
	case AnimFrames::optNO_MASK:
		quickDraw(index, x, y, drawWindow, NULL, bounds);
			
		break;

	case AnimFrames::optNONE:
		WinHandle offScreenH = WinCreateOffscreenWindow(width, height, screenFormat, &error);
		WinSetDrawWindow(offScreenH);
		quickDraw(index, x, y, drawWindow, offScreenH, bounds);
		WinSetDrawWindow(drawWindow);
		WinDeleteWindow(offScreenH, false);

		break;
	}
}


void AnimFrames::quickDraw(UInt16 index, Coord x, Coord y, WinHandle drawWindow, WinHandle offScreenH, RectangleType *bounds) const
{
	if (bounds != NULL)
		getBounds(x, y, bounds);

	RectangleType size;
	size.topLeft.x = 0;
	size.topLeft.y = 0;
	size.extent.x = width;
	size.extent.y = height;			
		
		
	switch(optimizationMode)
	{
	case AnimFrames::optBUFFER:
		// The fast drawing code...		
		
		WinCopyRectangle(frameDescriptors[index].offScreenMask, drawWindow, &size, x - hotSpotX, y - hotSpotY, winMask);
		SoundEngine::timeTick();
		WinCopyRectangle(frameDescriptors[index].offScreenBitmap, drawWindow, &size, x - hotSpotX, y - hotSpotY, winOverlay);
		SoundEngine::timeTick();
		
		break;	

	case AnimFrames::optNONE:
		// The slow drawing code...
		{
			// Paint sprite-mask to offscreen window
			MemHandle resH = DmGetResource( bitmapRsc, maskID + index);
			ErrNonFatalDisplayIf( !resH, "Missing mask" );
			BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

			WinDrawBitmap (resP, 0,0);

			MemPtrUnlock(resP);
			DmReleaseResource( resH );				

			WinCopyRectangle(offScreenH, drawWindow, &size, x - hotSpotX, y - hotSpotY, winMask);
	
			SoundEngine::timeTick();
		}
			
		{
			// Paint sprite-overlay over the masked-out area
			MemHandle resH = DmGetResource( bitmapRsc, bitmapID + index);
			ErrNonFatalDisplayIf( !resH, "Missing bitmap" );
			BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

			WinDrawBitmap (resP, 0,0);

			MemPtrUnlock(resP);
			DmReleaseResource( resH );

			WinCopyRectangle(offScreenH, drawWindow, &size, x - hotSpotX, y - hotSpotY, winOverlay);

			SoundEngine::timeTick();	
		}
		
		break;
			
			
	case AnimFrames::optNO_MASK:
		{
			MemHandle resH = DmGetResource( bitmapRsc, bitmapID + index);
			ErrNonFatalDisplayIf( !resH, "Missing bitmap" );
			BitmapType* resP = (BitmapPtr)MemHandleLock(resH);

			WinDrawBitmap (resP, x - hotSpotX, y - hotSpotY);

			MemPtrUnlock(resP);
			DmReleaseResource( resH );

			SoundEngine::timeTick();	
		}	
	}
}


AnimFrames::OptimizationMode AnimFrames::getOptimizationMode() const
{
	return optimizationMode;
}




Sprite::Sprite(DmResID bitmapID, DmResID maskID, Coord hotSpotX, Coord hotSpotY, Boolean visible, AnimFrames::OptimizationMode optimizationMode)
{
	animFrames = new AnimFrames(1, bitmapID, maskID, hotSpotX, hotSpotY, optimizationMode);
	ownsAnimFrames = true;

	this->visible  = visible;
	move(0,0);
	setFrame(0);
}
	

Sprite::Sprite(AnimFrames& animFrames, Boolean visible)
{
	this->animFrames = &animFrames;
	ownsAnimFrames = false;
	
	this->visible = visible;
	move(0,0);
	setFrame(0);
}
	

Sprite::~Sprite()
{
	if (ownsAnimFrames)
		delete animFrames;
}


void Sprite::show()
{
	visible = true;
}


void Sprite::hide()
{
	visible = false;
}


Boolean Sprite::setVisibility(Boolean visible)
{
	Boolean oldVisible = visible;
	this->visible = visible;
		
	return oldVisible;
}


Boolean Sprite::isVisible() const
{
	return visible;
}


void Sprite::setFrame(UInt16 frameIndex)
{
	this->frameIndex = frameIndex;
}


void Sprite::move(Coord x, Coord y)
{
	this->x = x;
	this->y = y;
}


void Sprite::draw(RectangleType *bounds) const
{
	if (!visible)
	{
		if (bounds != NULL)
		{
			bounds->topLeft.x = 0;
			bounds->topLeft.y = 0;
			bounds->extent.x = 0;
			bounds->extent.y = 0;
		}
			
		return;
	}

	animFrames->draw(frameIndex, x, y, bounds);
}


void Sprite::getBounds(RectangleType *bounds) const
{
	animFrames->getBounds(x, y, bounds);
}


void Sprite::quickDraw(WinHandle drawWindow, WinHandle offScreenH, RectangleType *bounds) const
{
	if (!visible)
	{
		if (bounds != NULL)
		{
			bounds->topLeft.x = 0;
			bounds->topLeft.y = 0;
			bounds->extent.x = 0;
			bounds->extent.y = 0;
		}
			
		return;
	}


	animFrames->quickDraw(frameIndex, x, y, drawWindow, offScreenH, bounds);
}
	

AnimFrames::OptimizationMode Sprite::getOptimizationMode() const
{
	return animFrames->getOptimizationMode();
}



SpriteGroup::SpriteGroup(int maxSprites)
{
	ErrNonFatalDisplayIf(maxSprites == 0, "maxSprites == 0");
	this->maxSprites = maxSprites;
	this->currSprites = 0;
	
	this->theSprites = new Sprite*[maxSprites];

	this->offscreenH = NULL;
	this->maxWidth = 0;
	this->maxHeight = 0;
	this->oldMaxWidth = -1;
	this->oldMaxHeight = -1;
	this->needBuffer = false;
}
	
	
SpriteGroup::~SpriteGroup()
{
	delete [] theSprites;
		
	if (offscreenH != NULL)
		WinDeleteWindow(offscreenH, false);
}


void SpriteGroup::addSprite(Sprite& sprite)
{
	ErrNonFatalDisplayIf(currSprites == maxSprites, "SpriteGroup size exhausted");

	this->theSprites[currSprites] = &sprite;

	// Adjust size of drawing buffer if neccessary
	if (sprite.getOptimizationMode() == AnimFrames::optNONE)
	{
		RectangleType bounds;
		sprite.getBounds(&bounds);

		maxWidth  = max(bounds.extent.x, maxWidth);
		maxHeight = max(bounds.extent.y, maxHeight);
			
		needBuffer = true;
	}

	currSprites++;
}


void SpriteGroup::draw(RectangleType *bounds)
{
	if (currSprites == 0)
		return;

	WinHandle drawWindow = WinGetDrawWindow();
	if (needBuffer)
	{
		if ((maxWidth != oldMaxWidth) || (maxHeight != oldMaxHeight))
		{
			if (offscreenH != NULL)
			{
				WinDeleteWindow(offscreenH, false);
				offscreenH = NULL;
			}
			
			oldMaxWidth = maxWidth;
			oldMaxHeight = maxHeight;
			
			UInt16 error;
			offscreenH = WinCreateOffscreenWindow(maxWidth, maxHeight, screenFormat, &error);
		}

		WinSetDrawWindow(offscreenH);
	}
	

	RectangleType spriteBounds;
	for(int i = 0; i < currSprites; i++)
	{
		this->theSprites[i]->quickDraw(drawWindow, offscreenH, &spriteBounds);
		Canvas::uniteBounds(&spriteBounds, bounds, bounds);
	}

	if (needBuffer)
		WinSetDrawWindow(drawWindow);
}
