/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: HardKeyManager.cpp,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/



#include "HardKeyManager.h"


void HardKeyManager::init()
{
	// Get the key repeat rate for when we want to restore it after the game.
	KeyRates(false, &oldInitDelay, &oldPeriod, &oldDoubleTapDelay, &oldQueueAhead);
		
	setMask(keysAllowedMask);
}


void HardKeyManager::destroy() 
{
	releaseHardKeys();
}

	
void HardKeyManager::captureHardKeys()
{
	// Set the keys we poll to not generate events.  This saves CPU cycles.
	KeySetMask(	~mask );
}
	

void HardKeyManager::releaseHardKeys()
{
	KeySetMask(keyBitsAll);
	KeyRates(true, &oldInitDelay, &oldPeriod, &oldDoubleTapDelay, &oldQueueAhead);
}
		

UInt32 HardKeyManager::getCurrentState()
{
	return KeyCurrentState();
}
	

void HardKeyManager::setMask(UInt32 mask)
{
	HardKeyManager::mask = mask;
}

	
UInt32 HardKeyManager::mask;

UInt16 HardKeyManager::oldInitDelay;
UInt16 HardKeyManager::oldPeriod;
UInt16 HardKeyManager::oldDoubleTapDelay;
Boolean HardKeyManager::oldQueueAhead;
