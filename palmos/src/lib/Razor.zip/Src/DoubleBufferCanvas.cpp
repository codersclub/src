/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: DoubleBufferCanvas.cpp,v 1.2 2000/12/17 11:51:06 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include "DoubleBufferCanvas.h"
#include "Device.h"


DoubleBufferCanvas::DoubleBufferCanvas() : Canvas()
{
	// Remember old draw window
	WinHandle oldDrawWinH = WinGetDrawWindow();

	// Setup the screenBuffer.
	UInt16 error;
	screenBufferH = WinCreateOffscreenWindow(getWidth(), getHeight(), screenFormat, &error);
	if (error)
		Device::panic(error, "Cannot create double buffer.");
				
	// Clear buffer for use
	WinSetDrawWindow(screenBufferH);
	WinEraseRectangle(&displayBounds, 0);

	// Restore old draw window
	WinSetDrawWindow(oldDrawWinH);			

	// Prepare bounds for screen copy
	currentBounds.topLeft.x = 0;
	currentBounds.topLeft.y = 0;
	currentBounds.extent.x = getWidth();
	currentBounds.extent.y = getHeight();
}
	
	
DoubleBufferCanvas::~DoubleBufferCanvas()
{
	// Destroy the double buffered window
	WinDeleteWindow(screenBufferH, false);
}

	
void DoubleBufferCanvas::beginDraw(WinLockInitType initMode)
{
	deviceDrawWindowH = WinGetDrawWindow();
	WinSetDrawWindow(screenBufferH);	


	lastBounds.topLeft.x = currentBounds.topLeft.x;
	lastBounds.topLeft.y = currentBounds.topLeft.y;
	lastBounds.extent.x = currentBounds.extent.x;
	lastBounds.extent.y = currentBounds.extent.y;


	switch(initMode)
	{
		case winLockCopy:
		case winLockDontCare:
			break;

		case winLockErase:
			// Clear buffer for use
			WinEraseRectangle(&displayBounds, 0);
				
			break;
		default:
			ErrNonFatalDisplay("DoubleBufferCanvas.beginDraw: Invalid initMode");
			break;
	}
}
	
	
void DoubleBufferCanvas::endDraw(RectangleType *bounds)
{
	ErrNonFatalDisplayIf(bounds == NULL, "DoubleBufferCanvas.endDraw: bounds == NULL");

	WinSetDrawWindow(deviceDrawWindowH);
		
	currentBounds.topLeft.x = bounds->topLeft.x;
	currentBounds.topLeft.y = bounds->topLeft.y;
	currentBounds.extent.x = bounds->extent.x;
	currentBounds.extent.y = bounds->extent.y;

	Canvas::uniteBounds(&lastBounds, &currentBounds, &copyBounds);

	// Don't show stuff off screen
	copyBounds.topLeft.x = max(copyBounds.topLeft.x, 0);
	copyBounds.topLeft.y = max(copyBounds.topLeft.y, 0);

	copyBounds.extent.x = min(copyBounds.extent.x, getWidth() - copyBounds.topLeft.x);
	copyBounds.extent.y = min(copyBounds.extent.y, getHeight() - copyBounds.topLeft.y);

	// Align the x coordinate with the nearest word to speed up the WinCopyRectangle.
	UInt16 offset = copyBounds.topLeft.x & 0x000F;
	if (offset)
	{
		copyBounds.topLeft.x -= offset;
		copyBounds.extent.x += offset;
	}
	
	// Push the extent out to fill the entire word.
	copyBounds.extent.x = (copyBounds.extent.x + 0x0F) & 0xFFF0;
}


void DoubleBufferCanvas::show()
{
	// Copy the screenBuffer
	WinCopyRectangle (screenBufferH, 0, &copyBounds, 
		copyBounds.topLeft.x, 
		copyBounds.topLeft.y, 
		winPaint); 
}
