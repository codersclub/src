/*********************************************************************************
 *
 * Razor! Engine - A modular C++ presentation engine
 *
 * $Id: Device.cpp,v 1.1.1.1 2000/12/09 09:28:39 christ Exp $
 *
 * Copyright (c) 2000 Tilo Christ. All Rights Reserved.
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 *
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 **********************************************************************************/


#include "Device.h"
#include "../Rsc/StarterRsc.h"    // Needed for ROM incompatible alert



UInt32  Device::romVersion;
Boolean Device::supports30;
Boolean Device::supports31;
Boolean Device::supports35;


void Device::panic(Err /* error */, Char* message)
{
	SysFatalAlert(message);
	SysReset();
}


void Device::init()
{
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &Device::romVersion);
	if (romVersion >= RomVersion30)
		supports30 = true;
	if (romVersion >= RomVersion31)
		supports31 = true;
	if (romVersion >= RomVersion35)
		supports35 = true;
}


Err Device::romVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	// See if the device contains the minimum required version of the ROM or later.
	if (Device::romVersion < requiredVersion)
	{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		{
			FrmAlert (RomIncompatibleAlert);
		
			// Palm OS 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (sysGetROMVerMajor(Device::romVersion) == 1)
			{
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		}
		
		return sysErrRomIncompatible;
	}

	return errNone;
}

