extern unsigned long start();
      unsigned long myStart()
      {
        return start();
      }

