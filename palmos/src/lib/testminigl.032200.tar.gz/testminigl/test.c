
#include "minigl.h"
#include "fastmath.h"

#include "test.h"
#include "test_res.h"

const unsigned long appFileCreator = SPM_FILE_CREATOR;
const unsigned short appFileVersion = SPM_FILE_VERSION;
const unsigned short appPrefID = SPM_PREF_ID;
const unsigned short appPrefVersion = SPM_PREF_VERSION;
const unsigned long appOSVersion = PALMOS_VERSION;
const unsigned long osVersion20 = PALMOS_VERSION_20;            

static Err AppStart();
static void AppStop();
static void AppEventLoop(void);
static Boolean AppEventHandler(EventPtr);
static void AppLoadForm(Word);     
static void MainFormInit(FormPtr formP); 
static int fi = 21, psi = -34, lit=1, wire=0;
static UInt xOld=-1, yOld;

Boolean MainFormEventHandler(EventPtr eventP) {
        Boolean handled = false;
        FormPtr formP;

	switch(eventP->eType) {
                case frmOpenEvent:
                        formP = FrmGetActiveForm();
                        FrmDrawForm(formP);
                        MainFormInit(formP);
                        handled = true;
                        break;            
		default:
                        break;
        }

        return handled;
} 

static int patchdata[][16] =
{
    /* rim */
  {102, 103, 104, 105, 4, 5, 6, 7, 8, 9, 10, 11,
    12, 13, 14, 15},
    /* body */
  {12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23,
    24, 25, 26, 27},
  {24, 25, 26, 27, 29, 30, 31, 32, 33, 34, 35, 36,
    37, 38, 39, 40},
    /* lid */
  {96, 96, 96, 96, 97, 98, 99, 100, 101, 101, 101,
    101, 0, 1, 2, 3,},
  {0, 1, 2, 3, 106, 107, 108, 109, 110, 111, 112,
    113, 114, 115, 116, 117},
    /* bottom */
  {118, 118, 118, 118, 124, 122, 119, 121, 123, 126,
    125, 120, 40, 39, 38, 37},
    /* handle */
  {41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52,
    53, 54, 55, 56},
  {53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64,
    28, 65, 66, 67},
    /* spout */
  {68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79,
    80, 81, 82, 83},
  {80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91,
    92, 93, 94, 95}
}; 

static float cpdata[][3] =
{
    {0.2, 0, 2.7}, {0.2, -0.112, 2.7}, {0.112, -0.2, 2.7}, {0,
    -0.2, 2.7}, {1.3375, 0, 2.53125}, {1.3375, -0.749, 2.53125},
    {0.749, -1.3375, 2.53125}, {0, -1.3375, 2.53125}, {1.4375,
    0, 2.53125}, {1.4375, -0.805, 2.53125}, {0.805, -1.4375,
    2.53125}, {0, -1.4375, 2.53125}, {1.5, 0, 2.4}, {1.5, -0.84,
    2.4}, {0.84, -1.5, 2.4}, {0, -1.5, 2.4}, {1.75, 0, 1.875},
    {1.75, -0.98, 1.875}, {0.98, -1.75, 1.875}, {0, -1.75,
    1.875}, {2, 0, 1.35}, {2, -1.12, 1.35}, {1.12, -2, 1.35},
    {0, -2, 1.35}, {2, 0, 0.9}, {2, -1.12, 0.9}, {1.12, -2,
    0.9}, {0, -2, 0.9}, {-2, 0, 0.9}, {2, 0, 0.45}, {2, -1.12,
    0.45}, {1.12, -2, 0.45}, {0, -2, 0.45}, {1.5, 0, 0.225},
    {1.5, -0.84, 0.225}, {0.84, -1.5, 0.225}, {0, -1.5, 0.225},
    {1.5, 0, 0.15}, {1.5, -0.84, 0.15}, {0.84, -1.5, 0.15}, {0,
    -1.5, 0.15}, {-1.6, 0, 2.025}, {-1.6, -0.3, 2.025}, {-1.5,
    -0.3, 2.25}, {-1.5, 0, 2.25}, {-2.3, 0, 2.025}, {-2.3, -0.3,
    2.025}, {-2.5, -0.3, 2.25}, {-2.5, 0, 2.25}, {-2.7, 0,
    2.025}, {-2.7, -0.3, 2.025}, {-3, -0.3, 2.25}, {-3, 0,
    2.25}, {-2.7, 0, 1.8}, {-2.7, -0.3, 1.8}, {-3, -0.3, 1.8},
    {-3, 0, 1.8}, {-2.7, 0, 1.575}, {-2.7, -0.3, 1.575}, {-3,
    -0.3, 1.35}, {-3, 0, 1.35}, {-2.5, 0, 1.125}, {-2.5, -0.3,
    1.125}, {-2.65, -0.3, 0.9375}, {-2.65, 0, 0.9375}, {-2,
    -0.3, 0.9}, {-1.9, -0.3, 0.6}, {-1.9, 0, 0.6}, {1.7, 0,
    1.425}, {1.7, -0.66, 1.425}, {1.7, -0.66, 0.6}, {1.7, 0,
    0.6}, {2.6, 0, 1.425}, {2.6, -0.66, 1.425}, {3.1, -0.66,
    0.825}, {3.1, 0, 0.825}, {2.3, 0, 2.1}, {2.3, -0.25, 2.1},
    {2.4, -0.25, 2.025}, {2.4, 0, 2.025}, {2.7, 0, 2.4}, {2.7,
    -0.25, 2.4}, {3.3, -0.25, 2.4}, {3.3, 0, 2.4}, {2.8, 0,
    2.475}, {2.8, -0.25, 2.475}, {3.525, -0.25, 2.49375},
    {3.525, 0, 2.49375}, {2.9, 0, 2.475}, {2.9, -0.15, 2.475},
    {3.45, -0.15, 2.5125}, {3.45, 0, 2.5125}, {2.8, 0, 2.4},
    {2.8, -0.15, 2.4}, {3.2, -0.15, 2.4}, {3.2, 0, 2.4}, {0, 0,
    3.15}, {0.8, 0, 3.15}, {0.8, -0.45, 3.15}, {0.45, -0.8,
    3.15}, {0, -0.8, 3.15}, {0, 0, 2.85}, {1.4, 0, 2.4}, {1.4,
    -0.784, 2.4}, {0.784, -1.4, 2.4}, {0, -1.4, 2.4}, {0.4, 0,
    2.55}, {0.4, -0.224, 2.55}, {0.224, -0.4, 2.55}, {0, -0.4,
    2.55}, {1.3, 0, 2.55}, {1.3, -0.728, 2.55}, {0.728, -1.3,
    2.55}, {0, -1.3, 2.55}, {1.3, 0, 2.4}, {1.3, -0.728, 2.4},
    {0.728, -1.3, 2.4}, {0, -1.3, 2.4}, {0, 0, 0}, {1.425,
    -0.798, 0}, {1.5, 0, 0.075}, {1.425, 0, 0}, {0.798, -1.425,
    0}, {0, -1.5, 0.075}, {0, -1.425, 0}, {1.5, -0.84, 0.075},
    {0.84, -1.5, 0.075}
}; 

static float tex[2][2][2] =
{
  { {0, 0},
    {1, 0}},
  { {0, 1},
    {1, 1}}
};    

static void
teapot(GLint grid, GLdouble scale, GLenum type)
{
  float p[4][4][3], q[4][4][3], r[4][4][3], s[4][4][3];
  long i, j, k, l;

  glPushAttrib(GL_ENABLE_BIT | GL_EVAL_BIT);
  glEnable(GL_AUTO_NORMAL);
  glEnable(GL_NORMALIZE);
  glEnable(GL_MAP2_VERTEX_3);
  glEnable(GL_MAP2_TEXTURE_COORD_2);
  glPushMatrix();
  glRotatef(270.0, 1.0, 0.0, 0.0);
  glScalef(0.5 * scale, 0.5 * scale, 0.5 * scale);
  glTranslatef(0.0, 0.0, -1.5);
  for (i = 0; i < 10; i++) {
    for (j = 0; j < 4; j++) {
      for (k = 0; k < 4; k++) {
        for (l = 0; l < 3; l++) {
          p[j][k][l] = cpdata[patchdata[i][j * 4 + k]][l];
          q[j][k][l] = cpdata[patchdata[i][j * 4 + (3 - k)]][l];
          if (l == 1)
            q[j][k][l] *= -1.0;
          if (i < 6) {
            r[j][k][l] =
              cpdata[patchdata[i][j * 4 + (3 - k)]][l];
            if (l == 0)
              r[j][k][l] *= -1.0;
            s[j][k][l] = cpdata[patchdata[i][j * 4 + k]][l];
            if (l == 0)
              s[j][k][l] *= -1.0;
            if (l == 1)
              s[j][k][l] *= -1.0;
          }                               
        }
      }
    }
    glMap2f(GL_MAP2_TEXTURE_COORD_2, 0, 1, 2, 2, 0, 1, 4, 2,
      &tex[0][0][0]);
    glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4,
      &p[0][0][0]);
    glMapGrid2f(grid, 0.0, 1.0, grid, 0.0, 1.0);
    glEvalMesh2(type, 0, grid, 0, grid);
    glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4,
      &q[0][0][0]);
    glEvalMesh2(type, 0, grid, 0, grid);
    if (i < 6) {
      glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4,
        &r[0][0][0]);
      glEvalMesh2(type, 0, grid, 0, grid);
      glMap2f(GL_MAP2_VERTEX_3, 0, 1, 3, 4, 0, 1, 12, 4,
        &s[0][0][0]);
      glEvalMesh2(type, 0, grid, 0, grid);
    }
  }
  glPopMatrix();
  glPopAttrib();
} 

void DrawSolidSphere(float radius, int theta_steps, int fi_steps) {
        float theta, fi, d_theta, d_fi;

        d_theta = PI/theta_steps - (0.01/(theta_steps-1));
        d_fi = 2*PI/fi_steps - (0.01/(fi_steps-1));

        for (theta = 0.01; theta < (PI-d_theta); theta += PI/theta_steps) {
                for (fi = 0.01; fi < 2*PI; fi += 2*PI/fi_steps) {
                        glBegin(GL_POLYGON);
				glNormal3f(radius*sin(theta)*cos(fi),
					radius*sin(theta)*sin(fi),
					radius*cos(theta));
                                glVertex3f(radius*sin(theta)*cos(fi),
                                        radius*sin(theta)*sin(fi),
                                        radius*cos(theta));
                                glVertex3f(radius*sin(theta)*cos(fi+d_fi),
                                        radius*sin(theta)*sin(fi+d_fi),
                                        radius*cos(theta));
                                glVertex3f(radius*sin(theta+d_theta)
                                                *cos(fi+d_fi),
                                        radius*sin(theta+d_theta)*sin(fi+d_fi),
                                        radius*cos(theta+d_theta));
                                glVertex3f(radius*sin(theta+d_theta)*cos(fi),
                                        radius*sin(theta+d_theta)*sin(fi),
                                        radius*cos(theta+d_theta));
                        glEnd();
                }
        }
}             

DrawSolidCone(float radius, float height, int theta_steps) {
	float theta, d_theta;

	d_theta = 2.0*PI/theta_steps;
	
	for (theta = 0; theta < 2.0*PI; theta+= d_theta) {
		glBegin(GL_POLYGON);
			glNormal3f(sin(theta), sin(atan(radius/height)),
					cos(theta));
			glVertex3f(radius*sin(theta),
				0, radius*cos(theta));
			glVertex3f(0,height,0);
			glVertex3f(radius*sin(theta+d_theta),
				0, radius*cos(theta+d_theta));
		glEnd();
	}
}

void Move() {
	/** +Z is into the screen */
	glLoadIdentity(); 
	glRotatef(fi,0,1,0);
	glRotatef(psi,1,0,0);
	glTranslatef(0, 0.1, 0); 
	//glTranslatef(0, -0.2, 1); 
}

// draw bidness here.
void Draw() {

	glClear(GL_COLOR);

	//DrawSolidSphere(0.4, 7, 7);
	//DrawSolidCone(0.5, 0.8, 15);

	glColor3f(170,170,170);

	glBegin(GL_POLYGON);
		glNormal3f(0,0,-1);
		glVertex3f(-0.25, -0.25, -0.25);
		glVertex3f(0.25, -0.25, -0.25);
		glVertex3f(0.25, 0.25, -0.25);
		glVertex3f(-0.25, 0.25, -0.25);
	glEnd();

	//glColor3f(255,100,0);
	glBegin(GL_POLYGON);
		glNormal3f(0,0,1);
		glVertex3f(-0.25, -0.25, 0.25);
		glVertex3f(-0.25, 0.25, 0.25);
		glVertex3f(0.25, 0.25, 0.25);
		glVertex3f(0.25, -0.25, 0.25);
	glEnd();

	//glColor3f(100,255,0);
	glBegin(GL_POLYGON);
		glNormal3f(-1,0,0);
                glVertex3f(-0.25, -0.25, 0.25);
                glVertex3f(-0.25, -0.25, -0.25);
                glVertex3f(-0.25, 0.25, -0.25);
                glVertex3f(-0.25, 0.25, 0.25);
	glEnd();

	//glColor3f(100,0,255);
	glBegin(GL_POLYGON);
		glNormal3f(1,0,0);
                glVertex3f(0.25, -0.25, -0.25);
                glVertex3f(0.25, -0.25, 0.25);
                glVertex3f(0.25, 0.25, 0.25);
                glVertex3f(0.25, 0.25, -0.25);
        glEnd(); 

	//glColor3f(0,100,255);
	glBegin(GL_POLYGON);
		glNormal3f(0,-1,0);
		glVertex3f(0.25, -0.25, -0.25);
		glVertex3f(-0.25, -0.25, -0.25);
		glVertex3f(-0.25, -0.25, 0.25);
		glVertex3f(0.25, -0.25, 0.25);
	glEnd();

	//glColor3f(0,255,100);
	glBegin(GL_POLYGON);
		glNormal3f(0,1,0);
		glVertex3f(-0.25, 0.25, -0.25);
		glVertex3f(0.25, 0.25, -0.25);
		glVertex3f(0.25, 0.25, 0.25);
		glVertex3f(-0.25, 0.25, 0.25);
	glEnd();

	/*
	glBegin(GL_TRIANGLE_STRIP);
		glVertex3f(-0.25, -0.25, -0.25);
		glVertex3f(0.25, -0.25, -0.25);
		glVertex3f(0.25, 0.25, -0.25);
		glVertex3f(-0.25, 0.25, -0.25);
		glVertex3f(-0.25, -0.25, 0.25);
		glVertex3f(-0.25, 0.25, 0.25);
		glVertex3f(0.25, 0.25, 0.25);
		glVertex3f(0.25, -0.25, 0.25);
                glVertex3f(-0.25, -0.25, 0.25);
                glVertex3f(-0.25, -0.25, -0.25);
                glVertex3f(-0.25, 0.25, -0.25);
                glVertex3f(-0.25, 0.25, 0.25);
                glVertex3f(0.25, -0.25, -0.25);
                glVertex3f(0.25, -0.25, 0.25);
                glVertex3f(0.25, 0.25, 0.25);
                glVertex3f(0.25, 0.25, -0.25);
		glVertex3f(0.25, -0.25, -0.25);
		glVertex3f(-0.25, -0.25, -0.25);
		glVertex3f(-0.25, -0.25, 0.25);
		glVertex3f(0.25, -0.25, 0.25);
		glVertex3f(-0.25, 0.25, -0.25);
		glVertex3f(0.25, 0.25, -0.25);
		glVertex3f(0.25, 0.25, 0.25);
		glVertex3f(-0.25, 0.25, 0.25);
	glEnd();
	*/

	glFlush();
} 

void DrawButtons() {
	BitmapPtr pBitmap;
	VoidHand hBitmap;
	int greyscale;

	greyscale = (OSVersion(3,3));
	if (greyscale == 1) {
		hBitmap = DmGetResource(bitmapRsc, 1009);
	} else {
		hBitmap = DmGetResource(bitmapRsc, 1209);
	}
	if (hBitmap) {
		
		pBitmap = (BitmapPtr)MemHandleLock(hBitmap);
		WinDrawBitmap(pBitmap, 109, 133);
		MemHandleUnlock(hBitmap);

		DmReleaseResource (hBitmap);
	}

	if (greyscale == 1) { 
		hBitmap = DmGetResource(bitmapRsc, 1010);
	} else {
		hBitmap = DmGetResource(bitmapRsc, 1210);
	}
	if (hBitmap) {
		
		pBitmap = (BitmapPtr)MemHandleLock(hBitmap);
		WinDrawBitmap(pBitmap, 5, 143);
		MemHandleUnlock(hBitmap);

		DmReleaseResource (hBitmap);
	}

	/** lighting toggle button */
	hBitmap = DmGetResource(bitmapRsc, 1220);
	pBitmap = (BitmapPtr)MemHandleLock(hBitmap);
	WinDrawBitmap(pBitmap, 45, 140); 
	MemHandleUnlock(hBitmap);  
	DmReleaseResource (hBitmap);   
	
	/** wireframe toggle button */
	hBitmap = DmGetResource(bitmapRsc, 1221);
	pBitmap = (BitmapPtr)MemHandleLock(hBitmap);
	WinDrawBitmap(pBitmap, 65, 140); 
	MemHandleUnlock(hBitmap);  
	DmReleaseResource (hBitmap);   
}

void MainFormInit(FormPtr formP) {
	GLfloat pos[4];
	GLfloat amb[4] = {0.3, 0.3, 0.3, 0};
	GLfloat dif[4] = {1,1,1,0};

	WinSetGLArea(0,15,160,135);

	gluPerspective(40.0, 1.4, 1.5, 4.0);

	pos[0] = -0.25;
	pos[1] = -0.25;
	pos[2] = -1.5;
	pos[3] = 1;

	glLightfv(GL_LIGHT0, GL_POSITION, pos);
	glLightfv(GL_LIGHT0, GL_DIFFUSE, dif);
	glLightfv(GL_LIGHT0, GL_AMBIENT, amb);
	glEnable(GL_LIGHT0);
	glEnable(GL_LIGHTING);
	lit = 1;

	glEnable(GL_CULL_FACE);

	Move();
	Draw();

	DrawButtons();
}

Boolean AppEventHandler(EventPtr pEvent) {
        Boolean bHandled = false;
        Word wFormID;               
	UInt xNew, yNew;
	int changed = 0;

	switch(pEvent->eType) {
                case ctlSelectEvent:
                        if (pEvent->data.ctlEnter.controlID == ExitButton) {
                                pEvent->eType = appStopEvent;
                        }                       
			if (pEvent->data.ctlEnter.controlID == LightButton) {
				if (lit) {
					glDisable(GL_LIGHTING);
					lit = 0;
				} else {
					glEnable(GL_LIGHTING);
					lit = 1;
				}
				DrawButtons();
				Draw();
			}
			if (pEvent->data.ctlEnter.controlID == WireButton) {
				if (wire) {
					wire = 0;
					glPolygonMode(GL_FRONT, GL_FILL);
				} else {
					wire = 1;
					glPolygonMode(GL_FRONT, GL_LINE);
				}
				DrawButtons();
				Draw();
			}
			break;
		case penDownEvent:
			xOld = pEvent->screenX;
			yOld = pEvent->screenY;
			break;
		case penMoveEvent:
			xNew = pEvent->screenX;
			yNew = pEvent->screenY;
			if (xNew > xOld) {
				fi-=(xNew-xOld);
				changed = 1;
			} else if (xNew < xOld){
				fi+=(xOld-xNew);
				changed = 1;
			}
			if (yNew > yOld) {
				psi-=(yNew-yOld);
				changed = 1;
			} else if (yNew < yOld) {
				psi+=(yOld-yNew);
				changed = 1;
			} 

			if (changed == 1) {
				Move();
				Draw();
				changed = 0;
			}
			xOld = xNew;
			yOld = yNew;
			break;
		case frmLoadEvent:
                        wFormID = pEvent->data.frmLoad.formID;
                        AppLoadForm(wFormID);
                        bHandled = true;
                        break;                                     
		case menuEvent:
			switch (pEvent->data.menu.itemID) {
				case MenuItem:
					FrmAlert(AlertAbout);
					break;
			}
			break;
		 default:
                        break;
        }

        return bHandled;
}        


void AppLoadForm(Word wFormID) {
        FormPtr pForm = FrmInitForm(wFormID);
        FrmSetActiveForm(pForm);

        switch(wFormID) {
                case MainForm:
                        FrmSetEventHandler(pForm, MainFormEventHandler);
                        break;
                default:
                        break;
        }
}         


DWord PilotMain(Word wCmd, Ptr pinfo, Word fuLaunch) {
        Err err;

        /*
        err = AppCheckVersion(appOSVersion, fuLaunch);
        if (err) {
                return err;
        }
        */

        switch (wCmd) {
                case sysAppLaunchCmdNormalLaunch:
                        err = AppStart();
                        if (!err) {
                                FrmGotoForm(MainForm);
                                AppEventLoop();
                                AppStop();
                        }
                        break;
                default:
                        err = 0;  
                        break;
        }

        return err;
}                         

Err AppStart() {
        Err error = 0;
        DWord romVersion;

/*
        error = SysLibFind(MathLibName, &MathLibRef);
        if (error)
                error = SysLibLoad(LibType, MathLibCreator, &MathLibRef);


        ErrFatalDisplayIf(error, "Can't find MathLib"); 

        error = MathLibOpen(MathLibRef, MathLibVersion);

        ErrFatalDisplayIf(error, "Can't open MathLib"); 
*/

return error;
}         


void AppStop() {
        UInt usecount;
        Err error;

/*
        error = MathLibClose(MathLibRef, &usecount);
        ErrFatalDisplayIf(error, "Can't close MathLib");
        if (usecount == 0)
                SysLibRemove(MathLibRef);
*/

}         

void AppEventLoop(void) {
        EventType event;
        Word error;

        do {
                EvtGetEvent(&event, evtWaitForever);
		//Win2PreFilterEvent(&event);
                if (false == SysHandleEvent(&event)) {
                        if (false == MenuHandleEvent(0, &event, &error)) {
                                if (false == AppEventHandler(&event)) {
                                        FrmDispatchEvent(&event);
                                }
                        }
                }
        } while (event.eType != appStopEvent);
}   
