
#define MainForm	1001
#define ExitButton	1002
#define AlertAbout	1003
#define MainMenu	1004
#define MenuItem	1005
#define LightButton	1006
#define WireButton	1007
