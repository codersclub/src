
#define SPM_PREF_VERSION        2
#define SPM_PREF_ID             2
#define SPM_FILE_VERSION        2
#define SPM_FILE_CREATOR        ('SPCB')
#define PALMOS_VERSION_20       (0x03100000)
#define PALMOS_VERSION          (PALMOS_VERSION_20)    

