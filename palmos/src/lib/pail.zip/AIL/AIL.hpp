////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifdef __VISUAL_STUDIO__
#   pragma warning(disable: 4284) // template stuff
#   pragma warning(disable: 4786) // for debug > 255
#   pragma warning(disable: 4355) // 'this' : used in base member initializer list
#   pragma warning(disable: 4930) // prototyped function not called (was a variable definition intended?)
#endif

#ifndef __AIL_H__
#define __AIL_H__

#pragma once

#define COMMETHOD STDMETHODCALLTYPE

#define __LITTLE_ENDIAN__ 0
#define __BIG_ENDIAN__    1
#define __PDP_ENDIAN__    2

#define __ENDIAN__ __LITTLE_ENDIAN__

#ifndef __VISUAL_STUDIO__
#   define __PALM_OS__ 0x0350
#   define __NO_THREADS__
#endif

#ifdef __VISUAL_STUDIO__
#   define __MS_WINDOWS__
#   define __HAS_INT64__
#   define __AIL_STDCALL__ __stdcall
#endif

#ifdef __PALM_OS__
#   define __AIL_STDCALL__
#endif

#ifdef __MS_WINDOWS__
#define _WINSOCKAPI_   // prevent inclusion of winsock.h in windows.h
#define __BYTE_ORDER__ __LITTLE_ENDIAN__
#   ifdef __MFC__
#       define _AFX_NO_SOCKET_SUPPORT
#       include <afxwin.h>
#       include <afxext.h>
#       include <afxcmn.h>
#   else
#       ifndef _WINDOWS_
#           include <windows.h>
#       endif
#   endif
#endif

#ifdef __VISUAL_STUDIO__
#   ifndef _INC_TCHAR
#       include <tchar.h>
#   endif
#endif

#ifdef __PALM_OS__
#   include <PalmOS.h>
#endif
////////////////////////////////////////////////////////////////////////////////////////
// Typedefs
// --------
#ifdef __VISUAL_STUDIO__
typedef TCHAR               tchar;
#else
typedef char                tchar;
#endif
typedef wchar_t             wchar;
typedef unsigned char       byte;
typedef unsigned short      ushort;
typedef unsigned int        uint;
typedef unsigned long       ulong;
#ifdef __VISUAL_STUDIO__    
typedef char                int8;    // 1  byte
typedef unsigned char       uint8;   // 1  byte
typedef short               int16;   // 2  bytes
typedef unsigned short      uint16;  // 2  bytes
typedef long                int32;   // 4  bytes
typedef unsigned long       uint32;  // 4  bytes
typedef __int64             int64;   // 8  bytes
typedef unsigned __int64    uint64;  // 8  bytes
#elif __PALM_OS__
typedef Int8                int8;    // 1  byte
typedef UInt8               uint8;   // 1  byte
typedef Int16               int16;   // 2  bytes
typedef UInt16              uint16;  // 2  bytes
typedef Int32               int32;   // 4  bytes
typedef UInt32              uint32;  // 4  bytes
typedef long long           int64;   // 8  bytes
typedef unsigned long long  uint64;  // 8  bytes
#else
typedef long                int64;   // 8  bytes :)
typedef unsigned long       uint64;  // 8  bytes :)
#endif
/*
typedef __int128          int128;  // 16 bytes
typedef unsigned __int128 uint128; // 16 bytes
*/
//
#ifdef __HAS_INT64__
typedef __int64     _time;
#else
typedef long        _time;
#endif
typedef uint         address_t;
typedef const void*  pvoid;
typedef const byte*  pcbyte;
typedef const tchar* pctchar;

#ifdef __HAS_INT64__
typedef uint64 fpos_t_;
typedef uint64 fsize_t_;
typedef uint64 hstream_;
#else
typedef uint32 fpos_t_;
typedef uint32 fsize_t_;
typedef uint32 hstream_;
#endif

#ifdef __PALM_OS__
typedef DateTimeType _time_t;
#endif

#ifdef __MS_WINDOWS__
typedef ULONG refcnt;
#else
typedef ulong refcnt;
#endif
////////////////////////////////////////////////////////////////////////////////////////
#define PCBYTE(x) (reinterpret_cast<pcbyte&>(x))
////////////////////////////////////////////////////////////////////////////////////////
// Global definitions
// ------ -----------
#define __NO_THROW_X__ throw()

#define __BEGIN_NAMESPACE__ namespace ail {
#define __END_NAMESPACE__   }

// Export/Import stuff
#ifdef __USE_DLL__
#   if defined(__BUILD_DLL__)
#       define __DECLSPEC__
#   else
#       define __DECLSPEC__ __declspec(dllimport)
#   endif
#else
#   define __DECLSPEC__
#endif

#ifdef __DISABLE_INLINE__
#   define __INLINE_TEMPLATE__
#   define __INLINE__
#else
#   define __INLINE_TEMPLATE__  inline
#   define __INLINE__           inline
#endif

#ifndef null
#   define null NULL
#endif

#ifdef __PALM_OS__
#   define _t
#else
#   define _t _T
#endif

#ifdef __PALM_OS__
typedef uint16  HANDLE;
typedef uint16  HMODULE;
typedef uint16  HINSTANCE;
#endif
//
__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// Global const
// ------ -----
extern fpos_t_  fpos_stub;
extern fsize_t_ fsize_stub;
extern hstream_ hstream_stub;

// i/o
extern const fpos_t_  ConstBadPos;
extern const fsize_t_ ConstBadSize;

// zero/error
extern const byte   ConstZero8;
extern const ushort ConstZero16;
extern const ulong  ConstZero32;
#ifdef __HAS_INT64__
extern const uint64 ConstZero64;
#endif

extern const byte   ConstError8;
extern const ushort ConstError16;
extern const ulong  ConstError32;
#ifdef __HAS_INT64__
extern const uint64 ConstError64;
#endif

// internal
extern const ushort ConstMagicNumber;
extern const byte   ConstMagicSequence[6];

#ifdef __BUILD_DLL__
extern const tchar TheModuleName[];
#endif

#ifdef _UNICODE
#   define compose swprintf
#else
#   define compose sprintf
#endif

#ifdef __MS_WINDOWS__
#   define BEEP  (::MessageBeep(-1));
#endif

//
#define TEXT_SIZE_SMALL     32
#define TEXT_SIZE           256
#define STRING_SIZE_SMALL   TEXT_SIZE_SMALL
#define STRING_SIZE         TEXT_SIZE
#ifdef _UNICODE
#define CHARACTER_COUNT     65536
#else
#define CHARACTER_COUNT     256
#endif
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__ // namespace ail

#endif // __AIL_H__ 
