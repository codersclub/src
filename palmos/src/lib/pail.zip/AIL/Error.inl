////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_ERROR_INL__
#define __AIL_ERROR_INL__

#pragma once

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class ErrorDescriptions
// ----- -----------------
__INLINE__ std::map<uint, std::string>& Error::ErrorDescriptions::GetDescriptions()
{
    return Descriptions;
}
////////////////////////////////////////////////////////////////////////////////////////
// class Error
// ----- -----
__INLINE__ const std::vector<uint>& Error::GetErrors() const
{
    return Errors;
}

__INLINE__ std::map<uint, std::string>& Error::GetDescriptions()
{
    return Error::ErrorDescriptions::GetDescriptions();
}
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__

#endif // __AIL_ERROR_INL__
