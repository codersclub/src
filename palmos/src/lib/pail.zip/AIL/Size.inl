////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __SIZE_INL__
#define __SIZE_INL__

#pragma once

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class Size
// ----- ----
__INLINE__ bool Size::operator == (const Size& _other) const
{
    return (_other.cx == cx && _other.cy == cy);
}

__INLINE__ bool Size::operator != (const Size& _other) const
{
    return (_other.cx != cx || _other.cy != cy);
}

__INLINE__ Size Size::operator + (const Size& _sz) const
{
    return Size(cx+_sz.cx, cy+_sz.cy);
}

__INLINE__ Size Size::operator - (const Size& _sz) const
{
    return Size(cx-_sz.cx, cy-_sz.cy);
}

__INLINE__ Size Size::operator - () const
{
    return Size(-cx, -cy);
}

__INLINE__ Size& Size::operator += (const Size& _sz)
{
    cx += _sz.cx;
    cy += _sz.cy;

    return *this;
}

__INLINE__ Size& Size::operator -= (const Size& _sz)
{
    cx -= _sz.cx;
    cy -= _sz.cy;

    return *this;
}

#ifndef __PALM_OS__
__INLINE__ int Size::Magnitude() const
{
    // Return the distance between the origin and the point.
    return Sqrt(long(cx)*long(cx)+long(cy)*long(cy));
}
#endif
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__

#endif // __SIZE_INL__
