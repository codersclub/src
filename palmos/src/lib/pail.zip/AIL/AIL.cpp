////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_H__
#   include <ail.hpp>
#endif

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// Global const
// ------ -----
fpos_t_  fpos_stub    = 0;
fsize_t_ fsize_stub   = 0;
hstream_ hstream_stub = 0;

// i/o
const fpos_t_  ConstBadPos  = static_cast<fpos_t_>(-1);
const fsize_t_ ConstBadSize = static_cast<fpos_t_>(-1);

// zero/error
const byte   ConstZero8  = 0x00U;
const ushort ConstZero16 = 0x0000U;
const ulong  ConstZero32 = 0x00000000U;
#ifdef __HAS_INT64__
const uint64 ConstZero64 = 0x0000000000000000U;
#endif

const byte   ConstError8  = 0xFFU;
const ushort ConstError16 = 0xFFFFU;
const ulong  ConstError32 = 0xFFFFFFFFUL;
#ifdef __HAS_INT64__
const uint64 ConstError64 = 0xFFFFFFFFFFFFFFFFUL;
#endif

// internal
const ushort ConstMagicNumber     = 0xAF07;
const byte   ConstMagicSequence[] = { 0x41, 0x72, 0x74, 0x68, 0x75, 0x72 };

#ifdef __BUILD_DLL__
const tchar TheModuleName[] = _t("AIL.DLL");
#endif
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__
