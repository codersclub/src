////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __SIZE_H__
#define __SIZE_H__

#pragma once

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
#if !defined(__MS_WINDOWS__)

typedef struct tagSIZE
{
#ifdef __PALM_OS__
    Coord cx;
    Coord cy;
#else
    int cx;
    int cy;
#endif
} SIZE;
#endif
////////////////////////////////////////////////////////////////////////////////////////
// class Size
// ----- ----
class __DECLSPEC__ Size : public tagSIZE
{
    public:
     // ctor/dtor
            Size();
            Size(const Size&);
            Size(int, int);
#ifdef __MS_WINDOWS__
            Size(const POINT&);
            Size(uint);
#endif
            Size(const SIZE&);

     // operators
     bool   operator == (const Size&)   const;
     bool   operator != (const Size&)   const;

     Size   operator + (const Size&)    const;
     Size   operator - (const Size&)    const;
     Size   operator - ()               const;
     Size&  operator += (const Size&);
     Size&  operator -= (const Size&);

     // protocol
#ifndef __PALM_OS__
     int    Magnitude()                 const;
#endif
};
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__

#endif // __SIZE_H__
