////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_H__
#   include <ail.hpp>
#endif

#ifndef __SIZE_INC__
#   include <Size.inc>
#endif

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class Size
// ----- ----
Size::Size()
{
    cx = 0;
    cy = 0;
}

Size::Size(const Size& _sz)
{
    cx = _sz.cx;
    cy = _sz.cy;
}

Size::Size(int _dx, int _dy)
{
#ifdef __PALM_OS__
    cx = static_cast<Coord>(_dx);
    cy = static_cast<Coord>(_dy);
#else
    cx = _dx;
    cy = _dy;
#endif
}

#ifdef __MS_WINDOWS__
Size::Size(const POINT& _pt)
{
    cx = _pt.x;
    cy = _pt.y;
}

Size::Size(uint _dw)
{
    cx = LOWORD(_dw);
    cy = HIWORD(_dw);
}
#endif

Size::Size(const SIZE& _sz)
{
    cx = _sz.cx;
    cy = _sz.cy;
}
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__
