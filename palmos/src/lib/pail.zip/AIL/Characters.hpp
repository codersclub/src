////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __CHARACTERS_H__
#define __CHARACTERS_H__

#pragma once

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class Char
// ----- ----
class __DECLSPEC__ Char
{
    public:
     static tchar   Bell;
     static tchar   Backspace;
     static tchar   Tab;
     static tchar   HTab;
     static tchar   VTab;
     static tchar   FormFeed;
     static tchar   NewLine;
     static tchar   LF;
     static tchar   CR;
     static tchar   CarriageReturn;
     static tchar   Space;
     static tchar   Exclam;
     static tchar   QuouteDbl;
     static tchar   NumberSign;
     static tchar   Dollar;
     static tchar   Percent;
     static tchar   Ampersand;
     static tchar   QuouteSingle;
     static tchar   ParenLeft;
     static tchar   ParenRight;
     static tchar   Asterisk;
     static tchar   Plus;
     static tchar   Comma;
     static tchar   Minus;          // HypHen minus ! ...
     static tchar   Period;
     static tchar   Slash;
     static tchar   Colon;
     static tchar   Semicolon;
     static tchar   Less;
     static tchar   Equal;
     static tchar   Greater;
     static tchar   Question;
     static tchar   At;             // Commercial at ! ...
     static tchar   BracketLeft;
     static tchar   BackSlash;
     static tchar   BracketRight;
     static tchar   ASCIICircum;
     static tchar   Underscore;
     static tchar   Grave;
     static tchar   BraceLeft;
     static tchar   Bar;
     static tchar   BraceRight;
     static tchar   ASCIITilde;
     //
     static tchar   BaseLineSingleQuote;
     static tchar   Florin;
     static tchar   BaseLineDoubleQuote;
     static tchar   Ellipsis;
     static tchar   Dagger;
     static tchar   DoubleDagger;
     static tchar   Circumflex;
     static tchar   Permille;
     static tchar   SHacek;
     static tchar   LeftSingleGuillemet;
     static tchar   OEligature;
     static tchar   LeftSingleQuote;
     static tchar   RightSingleQuote;
     static tchar   LeftDoubleQuote;
     static tchar   RightDoubleQuote;
     static tchar   Bullet;
     static tchar   EnDash;
     static tchar   EmDash;
     static tchar   Tilde;
     static tchar   TrademarkLigature;
     static tchar   sHacek;
     static tchar   RightSingleGuillemet;
     static tchar   oeligature;
     static tchar   YDieresis;
     //
     static tchar*  CRLF;
     static tchar*  SPTAB;
     static tchar*  LeftArrow;
     static tchar*  RightArrow;
};
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__

#endif // __CHARACTERS_H__
