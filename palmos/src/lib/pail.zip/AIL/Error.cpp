////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_H__
#   include <ail.hpp>
#endif

#ifndef __ERROR_INC__
#   include <Error.inc>
#endif

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class ErrorDescriptions
// ----- -----------------
std::map<uint, std::string> Error::ErrorDescriptions::Descriptions;
////////////////////////////////////////////////////////////////////////////////////////
// class Error
// ----- -----
Error::Error()
{
}

Error::~Error()
{
    Reset();
}

const tchar* Error::GetDescription(uint _error)
{
   _Descriptions::const_iterator it = Error::ErrorDescriptions::GetDescriptions().find(_error);

    if(it != Error::ErrorDescriptions::GetDescriptions().end())
    {
        return (*it).second.c_str();
    }
    return null;
}

void Error::AddError(uint _error)
{
    if(Error::ErrorDescriptions::GetDescriptions().size() == 0)
    {
        // try to load descriptions
        LoadErrorDescriptions();
    }

   _Descriptions::const_iterator it = Error::ErrorDescriptions::GetDescriptions().find(_error);

    if(it == Error::ErrorDescriptions::GetDescriptions().end())
    {
        Errors.push_back(_error);
    }
}

void Error::AddDescription(uint _id, const tchar* _desc)
{
    if(_desc != null)
    {
        Error::ErrorDescriptions::GetDescriptions()[_id] = _string(_desc);
    }
}

void Error::LoadErrorDescriptions()
{
    // base errors
    GetDescriptions()[eNoError]       = "No error";
    GetDescriptions()[eUnknown]       = "Unknown error";
    GetDescriptions()[eInvalidArg]    = "Invalid argument(s)";
    GetDescriptions()[eOutOfMemory]   = "Out of memory";
    GetDescriptions()[eOutOfRange]    = "Out of range";
    GetDescriptions()[eUninitialized] = "The object is not initilized";
    GetDescriptions()[eTypeMismatch]  = "Type mismatch: classes - bad relation";
}

void Error::PromptError(uint32, const tchar*)
{
    // see derived classes
}

void Error::Reset()
{
    Errors.clear();
    Error::ErrorDescriptions::GetDescriptions().clear();
}
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__
