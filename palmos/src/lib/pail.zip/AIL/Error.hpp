////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_ERROR_H__
#define __AIL_ERROR_H__

#pragma once

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class Error
// ----- -----
class __DECLSPEC__ Error
{
    typedef std::string             _string;
    typedef std::map<uint, _string> _Descriptions;
    typedef std::vector<uint>       _Errors;

    private:

    class __DECLSPEC__ ErrorDescriptions
    {
        typedef std::string             _string;
        typedef std::map<uint, _string> _Descriptions;
    
        private:
         static _Descriptions   Descriptions;
        public:
         // access
         static _Descriptions&  GetDescriptions();
    };

    public:

    enum EErrors
    {
        eNoError = -100,
        eUnknown,
        eInvalidArg,
        eOutOfMemory,
        eOutOfRange,
        eUninitialized,
        eTypeMismatch,
        eOperationFailure
    };

    protected:
    _Errors                 Errors;
    protected:
     virtual void           LoadErrorDescriptions();
     virtual void           PromptError(uint32, const tchar* = null);
    public:
     // ctor/dtor
                            Error();
     virtual               ~Error();

     // access
     const _Errors&         GetErrors()                 const;
     static _Descriptions&  GetDescriptions();
     static const tchar*    GetDescription(uint);

     // api
     void                   AddError(uint);
     void                   AddDescription(uint, const tchar*);

     void                   Reset();
};
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__

#endif // __AIL_ERROR_H__
