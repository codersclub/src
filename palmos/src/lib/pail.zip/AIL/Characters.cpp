////////////////////////////////////////////////////////////////////////////////////////
//......................................................................................
//  This is a part of AI Library [Arthur's Interfaces Library].                        .
//  Copyright � 1989-2001 Arthur Amshukov                                              .
//......................................................................................
//  THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND         .
//  DO NOT REMOVE MY NAME AND THIS NOTICE FROM THE SOURCE                              .
//......................................................................................
////////////////////////////////////////////////////////////////////////////////////////
#ifndef __AIL_H__
#   include <ail.hpp>
#endif

#ifndef __CHARACTERS_INC__
#   include <Characters.inc>
#endif

__BEGIN_NAMESPACE__
////////////////////////////////////////////////////////////////////////////////////////
// class Char
// ----- ----
tchar Char::Bell                  = _t('\a');
tchar Char::Backspace             = _t('\b');
tchar Char::Tab                   = _t('\t');
tchar Char::HTab                  = _t('\t');
tchar Char::VTab                  = _t('\v');
tchar Char::FormFeed              = _t('\f');
tchar Char::NewLine               = _t('\n');
tchar Char::LF                    = _t('\n');
tchar Char::CarriageReturn        = _t('\r');
tchar Char::CR                    = _t('\r');
tchar Char::Space                 = _t(' ');
tchar Char::Exclam                = _t('!');
tchar Char::QuouteDbl             = _t('"');
tchar Char::NumberSign            = _t('#');
tchar Char::Dollar                = _t('$');
tchar Char::Percent               = _t('%');
tchar Char::Ampersand             = _t('&');
tchar Char::QuouteSingle          = _t('\'');
tchar Char::ParenLeft             = _t('(');
tchar Char::ParenRight            = _t(')');
tchar Char::Asterisk              = _t('*');
tchar Char::Plus                  = _t('+');
tchar Char::Comma                 = _t(',');
tchar Char::Minus                 = _t('-'); // HypHen minus ! ...
tchar Char::Period                = _t('.');
tchar Char::Slash                 = _t('/');
tchar Char::Colon                 = _t(':');
tchar Char::Semicolon             = _t(';');
tchar Char::Less                  = _t('<');
tchar Char::Equal                 = _t('=');
tchar Char::Greater               = _t('>');
tchar Char::Question              = _t('?');
tchar Char::At                    = _t('@'); // Commercial at ! ...
tchar Char::BracketLeft           = _t('[');
tchar Char::BackSlash             = _t('\\');
tchar Char::BracketRight          = _t(']');
tchar Char::ASCIICircum           = _t('^');
tchar Char::Underscore            = _t('_');
tchar Char::Grave                 = _t('`');
tchar Char::BraceLeft             = _t('{');
tchar Char::Bar                   = _t('|');
tchar Char::BraceRight            = _t('}');
tchar Char::ASCIITilde            = _t('~');
//
tchar Char::BaseLineSingleQuote   = tchar(130);
tchar Char::Florin                = tchar(131);
tchar Char::BaseLineDoubleQuote   = tchar(132);
tchar Char::Ellipsis              = tchar(133);
tchar Char::Dagger                = tchar(134);
tchar Char::DoubleDagger          = tchar(135);
tchar Char::Circumflex            = tchar(136);
tchar Char::Permille              = tchar(137);
tchar Char::SHacek                = tchar(138);
tchar Char::LeftSingleGuillemet   = tchar(139);
tchar Char::OEligature            = tchar(140);
tchar Char::LeftSingleQuote       = tchar(145);
tchar Char::RightSingleQuote      = tchar(146);
tchar Char::LeftDoubleQuote       = tchar(147);
tchar Char::RightDoubleQuote      = tchar(148);
tchar Char::Bullet                = tchar(149);
tchar Char::EnDash                = tchar(150);
tchar Char::EmDash                = tchar(151);
tchar Char::Tilde                 = tchar(152);
tchar Char::TrademarkLigature     = tchar(153);
tchar Char::sHacek                = tchar(154);
tchar Char::RightSingleGuillemet  = tchar(155);
tchar Char::oeligature            = tchar(156);
tchar Char::YDieresis             = tchar(159);
//
tchar* Char::CRLF                 = "\r\n";
tchar* Char::SPTAB                = " \t";
tchar* Char::LeftArrow            = "<-";
tchar* Char::RightArrow           = "->";
////////////////////////////////////////////////////////////////////////////////////////
__END_NAMESPACE__
