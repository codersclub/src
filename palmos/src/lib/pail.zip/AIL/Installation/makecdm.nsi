Name "CDM Version 2.28"
OutFile Setup.exe
CRCCheck on
SetOverwrite on
AutoCloseWindow false
ShowInstDetails NeverShow
SetDatablockOptimize on
Icon c:\user\sw\csmdm\csmdm.ico
BGGradient 0000FF 800000 FFFFFF

LicenseText "You must read the following license before installing."
LicenseData cdm-license.txt
ComponentText "This will install the CDM Version 2.28 on your computer."

InstType Typical
InstType Full

DirText "Please select a location to install CDM (or use the default)."
InstallDir $PROGRAMFILES\Qualcomm\CDM
InstallDirRegKey HKEY_LOCAL_MACHINE "Software\CDM" "instpath"

; replace the default checked and unchecked icons
EnabledBitmap checked.bmp
DisabledBitmap unchecked.bmp

Section "CDM Application files (required)"
  CreateDirectory $INSTDIR
  SectionIn 1,2
  SetOutPath $INSTDIR
  File c:\user\sw\csmdm\csmdm.exe
  File C:\user\SW\csmdm\Doc\CSMDM\csmdm.hlp
  File c:\user\sw\rpc\bin\oncrpc.dll
  File c:\user\sw\rpc\bin\rpcinfo.exe
  SetOutPath $STARTMENU\Programs\CDM
  CreateShortcut "$STARTMENU\Programs\CDM\Uninstall.lnk" "$INSTDIR\nsuninst.exe" "" "" 0
  SetOutPath $INSTDIR
  CreateShortcut "$STARTMENU\Programs\CDM\CDM Help.lnk" "$INSTDIR\csmdm.hlp" "" "" 0
  CreateShortcut "$STARTMENU\Programs\CDM\CDM App.lnk" "$INSTDIR\csmdm.exe" "" "" 0
  CreateShortcut "$DESKTOP\CDM App.lnk" "$INSTDIR\csmdm.exe" "" "" 0
  WriteUninstaller $INSTDIR\nsuninst.exe
SectionEnd


Section "CDM utils, example and target files"
  SectionIn 2
  SetOutPath $INSTDIR
  File c:\user\sw\csmdm\cdmscript.pl
  File c:\user\sw\ChartEditor\ChartEditor.exe
  File c:\user\sw\Log2Cdm\Log2Cdm.exe
  CreateShortcut "$STARTMENU\Programs\CDM\Chart Editor.lnk" "$INSTDIR\ChartEditor.exe" "" "" 0
  CreateShortcut "$STARTMENU\Programs\CDM\Log2CDM.lnk" "$INSTDIR\Log2Cdm.exe" "" "" 0
  SetOutPath $INSTDIR\Target
  File c:\user\sw\csmdm\cdmrpc.x
  File c:\user\sw\csmdm\cdmdef.h
  File c:\user\sw\csmdm\cdmrpc_x.h
  File c:\user\sw\csmdm\cdmsprintf.h
  File c:\user\sw\csmdm\cdmLogMgr.h
  File c:\user\sw\csmdm\cdmtarget.h
  File c:\user\sw\csmdm\cdmrpc_svc_x.c
  File c:\user\sw\csmdm\cdmrpc_xdr_x.c
  File c:\user\sw\csmdm\cdmsprintf.c
  File c:\user\sw\csmdm\cdmrpcx.cxx
  File c:\user\sw\csmdm\cdmtarget.cxx
SectionEnd


Section "Target lib and emulation for PC"
  SectionIn 2
  SetOutPath $INSTDIR\Emulation\CDM_Lib\debug
  File c:\user\sw\cdmserv\cdm_lib\debug\cdm_lib.lib
  SetOutPath $INSTDIR\Emulation\CDM_Lib
  File c:\user\sw\cdmserv\cdm_lib\cdm_lib.dsp
  File c:\user\sw\cdmserv\cdmtarget.h
  File c:\user\sw\cdmserv\cdmdef.h
  File c:\user\sw\cdmserv\cdm_lib\debug\cdm_lib.lib
  File c:\user\sw\cdmserv\oncrpcms.lib
  SetOutPath $INSTDIR\Emulation
  File c:\user\sw\csmdm\silf.h
  File c:\user\sw\csmdm\lib_cdef.h
  File c:\user\sw\csmdm\sil.h
  File c:\user\sw\csmdm\sil_spec.h
  File c:\user\sw\csmdm\csil.h
  File c:\user\sw\csmdm\cai.h
  File c:\user\sw\csmdm\qw.h
  File c:\user\sw\csmdm\zapp_c2k.h
  File c:\user\sw\csmdm\L3MessageParser.h
  File c:\user\sw\csmdm\L3MessageParser.cpp
  File c:\user\sw\csmdm\vxworks.h
  File c:\user\sw\csmdm\vxworks.cpp
  File c:\user\sw\cdmserv\silklibms.lib
  File c:\user\sw\cdmserv\cdmdef.h
  File c:\user\sw\cdmserv\cdmrpc.h
  File c:\user\sw\cdmserv\cdmrpc.x
  File c:\user\sw\cdmserv\cdmPcSim.h
  File c:\user\sw\cdmserv\cdmPcSim.cpp
  File c:\user\sw\cdmserv\cdmsprintf.h
  File c:\user\sw\cdmserv\cdmLogMgr.h
  File c:\user\sw\cdmserv\cdmtarget.h
  File c:\user\sw\cdmserv\cdmrpc_svc.c
  File c:\user\sw\cdmserv\cdmrpc_xdr.c
  File c:\user\sw\cdmserv\cdmsprintf.c
  File c:\user\sw\cdmserv\cdmrpcx.cpp
  File c:\user\sw\cdmserv\cdmtarget.cpp
  File c:\user\sw\cdmserv\csmserver.cpp
  File c:\user\sw\cdmserv\semLib.h
  File c:\user\sw\cdmserv\oncrpcms.lib
  File c:\user\sw\cdmserv\cdmserv.dsp
  File c:\user\sw\cdmserv\cdmserv.dsw
  File c:\user\sw\cdmserv\debug\cdmserv.exe
  CreateShortcut "$STARTMENU\Programs\CDM\CDM Target Simulation.lnk" "$INSTDIR\Emulation\cdmserv.exe" "" "" 0
  SetOutPath $INSTDIR\Emulation\Debug
  File c:\user\sw\cdmserv\cdm_lib\debug\cdm_lib.lib
  SetOutPath $INSTDIR\Emulation\Release
  File c:\user\sw\cdmserv\cdm_lib\release\cdm_lib.lib
  SetOutPath $INSTDIR\RPC
  File c:\user\sw\rpc.exe
SectionEnd


Section "CDM Scripting interface"
  SectionIn 1,2
  SetOutPath $INSTDIR
  File c:\user\sw\rpc\bin\pm_ascii.exe
  File c:\user\sw\csmdm\swig50\cdmscript.pm
  File c:\user\sw\csmdm\swig50\cdmscript.dll
  SetOutPath $INSTDIR\Perl50
  File c:\user\sw\csmdm\swig50\cdmscript.pm
  File c:\user\sw\csmdm\swig50\cdmscript.dll
  SetOutPath $INSTDIR\Perl56
  File c:\user\sw\csmdm\swig56\cdmscript.pm
  File c:\user\sw\csmdm\swig56\cdmscript.dll
  CreateShortcut "$STARTMENU\Programs\CDM\PM_ASCII.lnk" "$INSTDIR\pm_ascii.exe"    "" "" 0
SectionEnd


Section "CDM Display configuration"
  SectionIn 1,2
  SetOutPath $INSTDIR
  ; first read the data from the exisitng INI file (if exist)
  ReadINIStr $0 $INSTDIR\CSMDM.INI TTargetData IPAddr.Text
  ReadINIStr $1 $INSTDIR\CSMDM.INI TTargetData LogFile.Text
  ReadINIStr $2 $INSTDIR\CSMDM.INI TTargetData FileLog.Checked
  ReadINIStr $3 $INSTDIR\CSMDM.INI TTargetData TargetKeepAlive.Checked
  ReadINIStr $4 $INSTDIR\CSMDM.INI TTargetData AppendLog.Checked
  ReadINIStr $5 $INSTDIR\CSMDM.INI TTargetData AutoConnect.Checked
  ReadINIStr $6 $INSTDIR\CSMDM.INI TTargetData Suppress.Checked
  ; overwrite the existing INI file
  File c:\user\sw\instsh\cdm\App\csmdm.ini
  File c:\user\sw\instsh\cdm\App\*.Tee
  ; Write the target address back to the INI file
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData IPAddr.Text              $0
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData LogFile.Text             $1
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData FileLog.Checked          $2
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData TargetKeepAlive.Checked  $3
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData AppendLog.Checked        $4
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData AutoConnect.Checked      $5
  WriteINIStr $INSTDIR\CSMDM.INI TTargetData Suppress.Checked         $6
SectionEnd


Section "Uninstall"
  Delete "$DESKTOP\CDM App.lnk"
  RMDIR /r  $STARTMENU\programs\cdm
  RMDir /r  $INSTDIR
  DeleteRegValue HKEY_LOCAL_MACHINE "Software\Microsoft\Windows\CurrentVersion\Uninstall\CDM" "DisplayName"
  DeleteRegValue HKEY_LOCAL_MACHINE "Software\Microsoft\Windows\CurrentVersion\Uninstall\CDM" "UninstallString"
SectionEnd


Section -PostInstall
  WriteRegStr HKEY_LOCAL_MACHINE "Software\Microsoft\Windows\CurrentVersion\Uninstall\CDM" "DisplayName" "CDM (remove only)"
  WriteRegStr HKEY_LOCAL_MACHINE "Software\Microsoft\Windows\CurrentVersion\Uninstall\CDM" "UninstallString" '"$INSTDIR\nsuninst.exe"'
  WriteRegStr HKEY_LOCAL_MACHINE "Software\CDM" "instpath" $INSTDIR
SectionEnd


Function un.onInit
  MessageBox MB_YESNO "This will uninstall CDM, deleting all files. Continue?" IDYES NoAbort
    Abort ; causes uninstaller to quit.
  NoAbort:
FunctionEnd

