#!/bin/tcsh

echo "** Making static lib version"
make

echo "** Making shared lib .prc file"
m68k-palmos-coff-exportlist libminigl.a > minigl.exp
m68k-palmos-coff-stubgen "miniGL Library" MnGL miniglstub.c miniGLLib.S < minigl.exp
m68k-palmos-coff-gcc -shared -o miniGLLib miniGLLib.S libminigl.a
m68k-palmos-coff-obj-res -l miniGLLib
build-prc -l miniGLLib.prc "miniGL Library" MnGL GLib0000.miniGLLib.grc data0000.miniGLLib.grc rloc0000.miniGLLib.grc

echo "** Making stub library"
m68k-palmos-coff-gcc -c -w miniglstub.c
m68k-palmos-coff-ar rcs libminigl.sa miniglstub.o
