
                        IrPad version 1.0


This program allows you to print on IR-enabled printer, communicate with
mobile phone or with PC using IR link.

This is a public domain. NO WARRANTY.


How to print:
-------------

Paste the text in to the text area; point your Palm to the IR printer and press
SEND button. In order to begin printing select Disconnect (or simply close
application).
SEND button will send only the selected text or whole text area if nothing was
selected.

How to communicate with mobile phone:
-------------------------------------

Terminal mode must be enabled.
Establish connection by selecting Connect item from menu. Now you can type
the AT-commands.

How to communicate with PC:
---------------------------
(Tested on Windows98 using HyperTerminal)

Infrared communications must be enabled on PC (in BIOS setup and in Infrared
Monitor applet).
Make HyperTerminal connection using "Direct to COMx" option (where COMx is a
port used by Windows infrared support). Note that terminal must be in
"connected" mode.
Establish connection by selecting Connect item from menu. Now you can exchange
data between PC and Palm.

Supported:
----------

    IrLPT
    IrCOMM 3-Wire raw
    IrCOMM 3-Wire and 9-Wire (without control channel)

Minimal requirements:
---------------------

    Palm III
    PalmOS 3.1

Development:
------------

    PRC-Tools 2.0 and SDK 3.1

Bug fix:
--------

    28.04.00    - fixed bug causing fatal error when the IR library open operation fails.


Sergey Udovenko
udovenko@bluewin.ch
