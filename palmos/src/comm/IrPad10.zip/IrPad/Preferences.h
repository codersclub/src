//
//  Preferences.h
//
//  24 feb 2000
//

#include "Util/Serializable.h"
#include "Util/MemBuffer.h"
#include "Util/AppPreferences.h"


class Preferences: private Util::Serializable
{
public:
    Preferences();
    ~Preferences();

    // Preferences(const Preferences&);
    // Preferences& operator =(const Preferences&);

// attributes

    Util::MemBuffer& textBuffer()                       { return _textBuffer; }
    void setTextBuffer(const Util::MemBuffer& buffer)   { _textBuffer = buffer; }

    bool autoConnect() const                { return _autoConnect; }
    int autoConnectPeriod() const           { return _autoConnectPeriod; }
    bool terminalMode() const               { return _terminalMode; }
    bool localEcho() const                  { return _localEcho; }
    bool sendNewLineAsCRLF() const          { return _sendNewLineAsCRLF; }

    void setAutoConnect(bool flag)          { _autoConnect = flag; }
    void setAutoConnectPeriod(int period);
    void setTerminalMode(bool flag)         { _terminalMode = flag; }
    void setLocalEcho(bool flag)            { _localEcho = flag; }
    void setSendNewLineAsCRLF(bool flag)    { _sendNewLineAsCRLF = flag; }

// serialization
private:
    virtual void serialize(Util::DataOutputStream& stream) const;
    virtual void restore(const Util::DataInputStream& stream);

// data members
private:
    Util::AppPreferences _appPreferences;

    Util::MemBuffer _textBuffer;
    bool _autoConnect;
    int _autoConnectPeriod;     // sec
    bool _terminalMode;
    bool _localEcho;
    bool _sendNewLineAsCRLF;
};
