//
//  IrIasParameters.cc
//
//  06 mar 2000
//

#include <Common.h>
#include <ErrorMgr.h>
#include "IrIasParameters.h"
#include "../Util/PrintStream.h"
#include "../Util/Error.h"


namespace IrDA
{
    //==========================================================================
    // IasParameter class
    //==========================================================================

    // operations

    void IasParameter::initFrom(const Byte* stream)
    {
        assert(stream != NULL);

        _identifier = stream[0];
        _length = stream[1];
        _value = stream+2;
    }

    // impelmentation

    void IasParameter::printBitMaskDescription(Util::PrintStream& ps, Byte bitMask, const char* descText[], int descCount) const
    {
        for (int i = 0, count = 0; i < descCount; ++i)
        {
            if ((bitMask >> i & 1) != 0)
            {
                if (count++ > 0)
                    ps.print(", ");

                ps.print(descText[i]);
            }
        }
    }

    //==========================================================================
    // IasServiceTypeParameter class
    //==========================================================================

    void IasServiceTypeParameter::printOn(Util::PrintStream& ps) const
    {
        static const char* services[] =
        {
            "3-Wire raw",
            "3-Wire",
            "9-Wire",
            "Centronics"
        };

        ps.print("- Service types: ");
        printBitMaskDescription(ps, *value(), services, sizeof(services)/sizeof(char*));
        ps.print("\n");
    }


    //==========================================================================
    // IasPortTypeParameter class
    //==========================================================================

    void IasPortTypeParameter::printOn(Util::PrintStream& ps) const
    {
        static const char* ports[] =
        {
            "serial",
            "parallel"
        };

        ps.print("- Port types: ");
        printBitMaskDescription(ps, *value(), ports, sizeof(ports)/sizeof(char*));
        ps.print("\n");
    }


    //==========================================================================
    // IasParameterList class
    //==========================================================================

    IasParameterList::IasParameterList(const Byte* stream, int size):
        _stream(stream), _size(size)
    {
        assert(stream != NULL);
        assert(size > 0);
    }

    // operations

    bool IasParameterList::getParameter(IasParameter& parameter) const
    {
        if (_stream != NULL)
        {
            for (int pos = 0; pos < _size; pos += parameter.size())
            {
                parameter.initFrom(_stream+pos);
                if (parameter.checkType())
                    return true;
            }
        }

        return false;
    }
}
// namespace IrDA
