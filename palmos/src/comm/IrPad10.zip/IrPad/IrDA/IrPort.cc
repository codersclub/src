//
//  IrPort.cc
//
//  23 feb 2000
//

#include <Pilot.h>
#include <irlib.h>
#include "IrPort.h"
#include "IrConnection.h"
#include "../Util/Error.h"
#include "../Util/PrintStream.h"


namespace IrDA
{
    //==============================================================================
    //  Constants
    //==============================================================================

    const Word  NULL_REF_NUM = 0xFFFF;


    //==============================================================================
    //  Port class
    //==============================================================================

    Port::Port():
        _opened(false),
        _refNum(NULL_REF_NUM),
        _connection(new Connection)
    {}

    Port::~Port()
    {
        close();
        delete _connection;
    }

    // operations

    bool Port::open(Callback* callback)
    {
        assert(!_opened);

        if(!initIrLib())
            return false;

        if (IrOpen(_refNum, irOpenOptSpeed115200) != 0)
        {
            Util::ErrorMessage("Fail to open IR Library");
            return false;
        }

        // connection could be NULL if allocation in constructor has been failed
        if (_connection == NULL || !_connection->init(_refNum, callback))
        {
            IrClose(_refNum);
            return false;
        }

        _opened = true;
        return true;
    }

    void Port::close()
    {
        if (isOpened())
        {
            _connection->shutdown();

            if (!IrClose(_refNum) == 0)
                Util::ErrorMessage("Fail to close IR Library");

           _opened = false;
        }
    }

    bool Port::connect()
    {
        assert(isOpened());
        return _connection->connect();
    }

    void Port::disconnect()
    {
        assert(isOpened());
        _connection->disconnect();
    }

    void Port::sendData(const Byte* data, int size)
    {
        assert(isOpened());

        if (_connection->ready())
            _connection->sendData(data, size);
    }

    void Port::printOn(Util::PrintStream& stream) const
    {
        stream.print("IR Port:\n");
        stream.addIndent(1);

        stream.printf("- IrLib reference: %d\n", _refNum);

        if (_opened)
            _connection->printOn(stream);

        stream.addIndent(-1);
    }

    // attributes

    bool Port::isConnected() const
    {
        return isOpened() && _connection->ready();
    }

    int Port::getMaxTxSize() const
    {
        assert(isOpened());

        if (_connection->ready())
            return _connection->getMaxTxSize();
    }

    bool Port::dataSendReady() const
    {
        assert(isOpened());

        if (_connection->ready())
            return _connection->dataSendReady();
    }

    // implementation

    bool Port::initIrLib()
    {
        if (_refNum == NULL_REF_NUM)
        {
            if (SysLibFind(irLibName, &_refNum) != 0)
            {
                Util::ErrorMessage("Can't find library: %s", irLibName);
                _refNum = NULL_REF_NUM;
                return false;
            }
        }

        return true;
    }
}
// namespace IrDA
