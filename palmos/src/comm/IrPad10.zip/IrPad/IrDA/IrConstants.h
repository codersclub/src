//
//  IrConstants.h
//
//  23 feb 2000
//

#ifndef _IrConstants_h_
#define _IrConstants_h_


// uncomment this to display IR layer debug info
//#define IR_DEBUG


namespace IrDA
{
    enum IrClassType
    {
        IrUnknownClass,
        IrCommClass,
        IrLptClass
    };

    enum IrProtocolType
    {
        IrUnknownProtocol,
        IrLmpProtocol,
        IrTpProtocol
    };
}
// namespace IrDA

#endif  // _IrConstants_h_
