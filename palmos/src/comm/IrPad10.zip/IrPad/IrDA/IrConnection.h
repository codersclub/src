//
//  IrConnection.h
//
//  23 feb 2000
//

#ifndef _IrConnection_h_
#define _IrConnection_h_

#include "IrConstants.h"
#include "../Util/MemBuffer.h"

namespace Util { class PrintStream; }


namespace IrDA
{
    class Callback;

    class Connection
    {
    public:
        Connection();
        ~Connection();

    private:
        Connection(const Connection&);
        Connection& operator =(const Connection&);

    // operations
    public:
        bool init(Word refNum, Callback* callback);
        void shutdown();

        bool connect();
        void disconnect();

        bool sendData(const Byte* data, int size);

        void printOn(Util::PrintStream& stream) const;

    // attributes

        bool ready() const { return _ready; }
        bool dataSendReady() const { return _dataSendReady; }

        int getMaxTxSize() const;
        int getMaxRxSize() const;

    // implementation
    private:

        // protocol commands

        bool bind();
        void unbind();
        bool discovery();
        bool connectLap();
        bool disconnectLap();
        bool connectComm();
        bool connectLmp(Byte remoteLsap);
        bool connectTinyTp(Byte remoteLsap);

        bool setDeviceInfo();

        void initServiceTypePacket();
        void initDataPacket(const Byte* data, int size);

        // utilities

        bool waitUntilMediaReady() const;
        bool waitForResult() const;

        // callback handling

        static void irCallback(IrConnect* conn, IrCallBackParms* params);

        void discovered(IrDeviceList* devices);
        void connectedLap();
        void requestedLapConnection();
        void disconnectedLap();
        void connectedLm();
        void requestedLmConnection();
        void disconnectedLm();
        void packetHandled();
        void dataReceived(const Byte* data, int size);
        void statusChanged(IrStatus status);

        // debug

        #ifdef IR_DEBUG
        void debugPrintStatus(IrStatus status);
        void debugPrintEvent(IrEvent event);
        void debugPrintDeviceInfo(IrDeviceInfo& deviceInfo);
        #endif

    // data members
    private:
        static Connection*  _this;

        Word _refNum;
        bool _bound;
        bool _ready;
        bool _dataSendReady;
        bool _cookedProtocol;

        enum CommandType
        {
            NoCommand,
            DiscoveryCommand,
            ConnectLapCommand,
            DisconnectLapCommand,
            ConnectLmCommand,
            SendDataCommand
        };

        CommandType _pendingCommand;
        bool _commandSucceed;

        IrDeviceInfo _deviceInfo;
        IrPacket _packet;
        IrConnect _connect;

        Util::MemBuffer _packetBuffer;

        Callback* _callback;
    };
}
// namespace IrDA

#endif // _IrConnection_h_
