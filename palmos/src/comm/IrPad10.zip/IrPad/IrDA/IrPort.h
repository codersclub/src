//
//  IrPort.h
//
//  23 feb 2000
//

#ifndef _IrPort_h_
#define _IrPort_h_

namespace Util { class PrintStream; }


namespace IrDA
{
    class Connection;
    class Callback;

    class Port
    {
    public:
        Port();
        ~Port();

    // operations

        bool open(Callback* callback);
        void close();

        bool connect();
        void disconnect();

        void sendData(const Byte* data, int size);

        void printOn(Util::PrintStream& stream) const;

    // attributes

        bool isOpened() const { return _opened; }
        bool isConnected() const;

        bool dataSendReady() const;
        int getMaxTxSize() const;

    // implementation
    private:
        bool initIrLib();

    // data members
    private:
        bool _opened;
        Word _refNum;

        Connection* _connection;
    };
}
// namespace IrDA

#endif // _IrPort_h_
