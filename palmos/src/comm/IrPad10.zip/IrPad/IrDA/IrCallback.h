//
//  IrCallback.h
//
//  23 feb 2000
//

#ifndef _IrCallback_h_
#define _IrCallback_h_


namespace IrDA
{
    class Callback
    {
    public:
        virtual void connected() = 0;
        virtual void disconnected() = 0;

        virtual void dataSendReady() = 0;
        virtual void dataReceived(const Byte* data, int size) = 0;

        enum Status
        {
            MediaNotBusyStatus,
            NoProgressStatus,
            LineOkStatus
        };
        virtual void statusChanged(Status status) = 0;
    };
}
// namespace IrDA

#endif // _IrCallback_h_
