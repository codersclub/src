//
//  IrIAS.h
//
//  23 feb 2000
//

#ifndef _IrIAS_h_
#define _IrIAS_h_

#include "IrConstants.h"


namespace IrDA
{
    class IasParameter;


    //==============================================================================
    // IasQueryBuffer class
    //==============================================================================

    class IasQueryBuffer
    {
    public:
        IasQueryBuffer();
        IasQueryBuffer(const IasQueryBuffer& other);
        IasQueryBuffer& operator =(const IasQueryBuffer& other);

    // operation

        void init(const char* className, const char* attributeName);
        void reset() { _size = 0; }
        IasQueryBuffer& append(const char* piece);

    // attributes

        const Byte* data() const { return _buffer; }
        int size() const { return _size; }

        char* toString(char* str) const;

    private:
        Byte _buffer[IR_MAX_QUERY_LEN];
        int _size;
    };


    //==============================================================================
    // IasAttributeName class
    //==============================================================================

    class IasAttributeName
    {
    public:
        IasAttributeName();
        IasAttributeName(const char* protocol, const char* attribute);

        IasAttributeName(const IasAttributeName& other);
        IasAttributeName& operator =(const IasAttributeName& other);

    // operation

        void reset() { _name[0] = 0; }
        IasAttributeName& append(const char* piece);

    // attributes

        operator const char*() const { return _name; }

    private:
        char _name[IR_MAX_IAS_NAME+1];
    };


    //==============================================================================
    //  IasQuery class
    //==============================================================================

    class IasQuery
    {
    public:
        IasQuery(Word refNum);
        ~IasQuery();

    private:
        IasQuery(const IasQuery&);
        IasQuery& operator =(const IasQuery&);

    // operations
    public:
        bool getRemoteLsap(IrClassType classType, IrProtocolType protocolType, Byte& remoteLsap) const;
        bool getRemoteDeviceName(char* buffer) const;
        bool getRemoteInstanceName(char* buffer) const;
        bool getRemoteParameter(IasParameter& remoteParameter) const;

    // utilities

        static const char* classTypeName(IrClassType classType);
        static const char* protocolTypeName(IrProtocolType protocolType);

    // implementation
    private:
        bool execute(const char* className, const char* attributeName) const;
        bool waitForResult(int expectedResultType) const;
        bool checkResultType(int resultType) const;
        bool getResultUserString(char* buffer) const;

        static void queryCallback(IrStatus status);

    // data members
    private:
        static const IasQuery* _this;

        Word _refNum;

        enum ResultState
        {
            ResultNotReady,
            ResultReady,
            ErrorResult,
        };
        mutable ResultState _resultState;

        mutable IrIasQuery _query;
        mutable IasQueryBuffer _queryBuffer;
        mutable Byte _resultBuffer[IR_MAX_IAS_ATTR_SIZE];
    };
}
// namespace IrDA

#endif  // _IrIAS_h_
