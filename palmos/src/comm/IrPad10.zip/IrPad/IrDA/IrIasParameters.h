//
//  IrIasParameters.h
//
//  06 mar 2000
//

#ifndef _IrIasParameters_h_
#define _IrIasParameters_h_

namespace Util { class PrintStream; }


namespace IrDA
{
    //==========================================================================
    // IasParameter class
    //==========================================================================

    class IasParameter
    {
    public:
        IasParameter(): _identifier(0), _length(0), _value(NULL) {}
        virtual ~IasParameter() {}

        // IasParameter(const IasParameter&);
        // IasParameter& operator =(const IasParameter&);

    // operations

        void initFrom(const Byte* stream);

        virtual void printOn(Util::PrintStream& ps) const = 0;

    // attributes

        virtual bool checkType() const = 0;

        int size() const { return sizeof(_identifier)+sizeof(_length)+_length; }

    protected:
        // Only service type and port type are currently supported.
        enum ParameterType
        {
            SeviceTypeParameter     = 0x0,
            PortTypeParameter       = 0x1
        };

        ParameterType type() const { return (ParameterType)_identifier; }
        const Byte* value() const { return _value; }

    // impelmentation

        void printBitMaskDescription(Util::PrintStream& ps, Byte bitMask, const char* descText[], int descCount) const;

    // data members
    private:
        Byte _identifier;
        Byte _length;
        const Byte* _value;
    };

    //==========================================================================
    // IasServiceTypeParameter class
    //==========================================================================

    class IasServiceTypeParameter: public IasParameter
    {
    public:

    // operations

        virtual void printOn(Util::PrintStream& ps) const;

    // attribute

        virtual bool checkType() const { return type() == SeviceTypeParameter; }

        bool is3WireRaw() const     { return *value() & 0x01; }
        bool is3Wire() const        { return *value() & 0x02; }
        bool is9Wire() const        { return *value() & 0x04; }
        bool isCentronics() const   { return *value() & 0x08; }
    };


    //==========================================================================
    // IasPortTypeParameter class
    //==========================================================================

    class IasPortTypeParameter: public IasParameter
    {
    public:

    // operations

        virtual void printOn(Util::PrintStream& ps) const;

    // attributes

        virtual bool checkType() const { return type() == PortTypeParameter; }

        bool isSerial() const       { return *value() & 0x01; }
        bool isParallel() const     { return *value() & 0x02; }
    };


    //==========================================================================
    // IasParameterList class
    //==========================================================================

    class IasParameterList
    {
    public:
        IasParameterList(const Byte* stream, int size);

        // IasParameterList(const IasParameterList&);
        // IasParameterList& operator =(IasParameterList&);

    // operations

        bool getParameter(IasParameter& parameter) const;

    // data members
    private:
        const Byte* _stream;
        int _size;
    };
}
// namespace IrDA

#endif  // _IrIasParameters_h_
