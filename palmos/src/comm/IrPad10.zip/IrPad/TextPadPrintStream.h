//
//  TextPadPrintStream.h
//
//  29 feb 2000
//

#ifndef _TextPadPrintStream_h_
#define _TextPadPrintStream_h_

#include "Util/PrintStream.h"
#include "TextPad.h"


class TextPadPrintStream: public Util::PrintStream
{
public:
    TextPadPrintStream(TextPad& textPad): _textPad(textPad) {}

private:
    virtual void writeData(const void* string, int size) { _textPad.insertString((const char*)string, size); }

    TextPad& _textPad;
};

#endif // _TextPadPrintStream_h_
