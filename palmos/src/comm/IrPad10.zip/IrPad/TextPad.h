//
//  TextPad.h
//
//  25 feb 2000
//

#ifndef _TextPad_h_
#define _TextPad_h_

#include "UI/EditBox.h"
#include "UI/ScrollBar.h"
#include "Util/MemBuffer.h"

class Preferences;
namespace IrDA { class Port; }


class TextPad
{
public:
    TextPad(UI::Form& parent, Preferences& preferences);
    ~TextPad();

// operations

    void init();
    void shutdown();

    void open();

    void appendText(const char* text, int size);
    void sendText(IrDA::Port& irPort) const;

    void insertString(const char* string, int size);

// event handlers

    bool eventHandler(EventType* event);
    bool handleStandardMenuEvents(Word itemID);

// implementation
private:
    bool getSelectedText(const char*& data, int& size) const;

    int sendDataPacket(IrDA::Port& irPort, const char* data, int size) const;
    void appendToTextBuffer(const char* data, int size);
    void scrollToEndOfText();

    int translateOutgoingText(char* dest, int destSize, const char* src, int srcSize, int& difference) const;
    int translateIncomingText(char* dest, int destPos, const char* src, int srcSize) const;

    void initFromPreferences();
    void saveToPreferences();

// data members
private:
    Preferences& _preferences;

    UI::EditBox _editBox;
    UI::ScrollBar _editScrollBar;

    mutable Util::MemBuffer _translationBuffer;
};

#endif // _TextPad_h_
