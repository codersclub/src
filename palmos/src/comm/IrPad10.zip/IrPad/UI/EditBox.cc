//
//  EditBox.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include <KeyMgr.h>
#include "EditBox.h"
#include "ScrollBar.h"
#include "Form.h"


namespace UI
{
    EditBox::EditBox(Form& parent, Word fieldID):
        FormElement(parent, fieldID),
        _fieldPtr(NULL),
        _scrollBar(NULL)
    {}

    // operations

    void EditBox::selectAll()
    {
        FldSetSelection(fieldPtr(), 0, FldGetTextLength(fieldPtr()));
    }

    void EditBox::clearAll()
    {
        FldDelete(fieldPtr(), 0, FldGetTextLength(fieldPtr()));
    }

    void EditBox::updateScrollBar()
    {
        if (_scrollBar != NULL)
        {
            Word scrollPos, textHeight, fieldHeight;
            FldGetScrollValues(fieldPtr(), &scrollPos, &textHeight, &fieldHeight);

            int maxValue;
            if (textHeight > fieldHeight)
                maxValue = textHeight-fieldHeight;
            else
                maxValue = scrollPos;

            SclSetScrollBar(_scrollBar->scrollBarPtr(), scrollPos, 0, maxValue, fieldHeight-1);
        }
    }

    Boolean EditBox::eventHandler(EventType* event)
    {
        switch (event->eType)
        {
            case fldChangedEvent:
                if (event->data.fldChanged.fieldID == elementID())
                    updateScrollBar();
                break;

            case keyDownEvent:
                if (hasFocus())
                    return processPageKeys();
                break;
        }

        return false;
    }

    // attributes

    FieldPtr EditBox::fieldPtr() const
    {
        if (_fieldPtr == NULL)
            _fieldPtr = parent().getObjectPtr<FieldPtr>(frmFieldObj, elementID());

        return _fieldPtr;
    }

    void EditBox::setScrollBar(ScrollBar& scrollBar)
    {
        _scrollBar = &scrollBar;
        _scrollBar->setScrollable(*this);
    }

    // implementation

    void EditBox::scrollPage(DirectionType direction)
    {
        FldScrollField(fieldPtr(), FldGetVisibleLines(fieldPtr()), direction);
        updateScrollBar();
    }

    bool EditBox::processPageKeys()
    {
        DWord state = KeyCurrentState();

        if ((state & keyBitPageUp) != 0)
        {
            scrollPage(up);
            return true;
        }
        else if ((state & keyBitPageDown) != 0)
        {
            scrollPage(down);
            return true;
        }
        return false;
    }

    void EditBox::updateScrollPosition(Word oldPosition, Word newPosition)
    {
        DirectionType dir;
        Word lines;

        if (oldPosition > newPosition)
        {
            dir = up;
            lines = oldPosition-newPosition;
        }
        else
        {
            dir = down;
            lines = newPosition-oldPosition;
        }

        FldScrollField(fieldPtr(), lines, dir);
    }
}
// namespace UI
