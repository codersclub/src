//
//  FormElement.h
//
//  21 feb 2000
//

#ifndef _FormElement_h_
#define _FormElement_h_


namespace UI
{
    class Form;

    class FormElement
    {
    protected:
        FormElement(Form& parent, Word elementID);
        ~FormElement() {}

    private:
        FormElement(const FormElement&);
        FormElement& operator =(const FormElement&);

    // operations
    public:
        void setFocus();
        bool hasFocus() const;

    // attributes

        Form& parent() const { return *_parent; }
        Word elementID() const { return _elementID; }

    // data members
    private:
        Form* _parent;
        Word _elementID;
    };
}
// namespace UI

#endif // _FormElement_h_
