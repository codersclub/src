//
//  Application.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include "Application.h"
#include "Form.h"


namespace UI
{
    void Application::run(Form& mainForm, long eventLoopDelay)
    {
        start();

        FrmGotoForm(mainForm.formID());
        eventLoop(mainForm, eventLoopDelay);

        stop();
    }

    void Application::start()
    {}

    void Application::stop()
    {}

    void Application::eventLoop(Form& mainForm, long delay)
    {
        for (;;)
        {
            Word error;
            EventType event;

            EvtGetEvent(&event, delay);

            if (SysHandleEvent(&event))
                continue;

            if (MenuHandleEvent(NULL, &event, &error))
                continue;

            switch (event.eType)
            {
                case frmLoadEvent:
                    if (event.data.frmLoad.formID == mainForm.formID())
                        mainForm.loadForm();
                    else
                        FrmDispatchEvent(&event);
                    break;

                case appStopEvent:
                    mainForm.closeForm();   // do it here due to the problems with static variables
                    FrmCloseAllForms();
                    return;

                default:
                    FrmDispatchEvent(&event);
                    break;
            }
        }
    }
}
// namespace UI
