//
//  Scrollable.h
//
//  21 feb 2000
//

#ifndef _Scrollable_h_
#define _Scrollable_h_


namespace UI
{
    class Scrollable
    {
    public:
        Scrollable() {}
        virtual ~Scrollable() {}

        virtual void updateScrollPosition(Word oldPosition, Word newPosition) = 0;
    };
}
// namespace UI

#endif // _Scrollable_h_
