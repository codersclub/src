//
//  ScrollBar.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include "ScrollBar.h"
#include "Scrollable.h"
#include "Form.h"


namespace UI
{
    ScrollBar::ScrollBar(Form& parent, Word scrollBarID):
        FormElement(parent, scrollBarID),
        _scrollBarPtr(NULL)
    {}

    // operations

    Boolean ScrollBar::eventHandler(EventType* event)
    {
        if (event->eType == sclRepeatEvent && event->data.sclRepeat.scrollBarID == elementID())
        {
            if (_scrollable != NULL)
                _scrollable->updateScrollPosition(event->data.sclRepeat.value, event->data.sclRepeat.newValue);
        }

        return false;
    }

    // attributes

    ScrollBarPtr ScrollBar::scrollBarPtr() const
    {
        if (_scrollBarPtr == NULL)
            _scrollBarPtr = parent().getObjectPtr<ScrollBarPtr>(frmScrollBarObj, elementID());

        return _scrollBarPtr;
    }
}
// namespace UI
