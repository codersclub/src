//
//  Form.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include "Form.h"


namespace UI
{
    Form::Form(Word formID):
        _formID(formID),
        _formPtr(NULL)
    {}

    // operations

    void Form::loadForm()
    {
        _formPtr = FrmInitForm(_formID);
        FrmSetActiveForm(_formPtr);
    }

    void Form::closeForm()
    {
        FrmSetEventHandler(formPtr(), NULL);
    }

    void Form::showElement(Word elementID)
    {
        FrmShowObject(formPtr(), FrmGetObjectIndex(formPtr(), elementID));
    }

    void Form::hideElement(Word elementID)
    {
        FrmHideObject(formPtr(), FrmGetObjectIndex(formPtr(), elementID));
    }

    // implementation

    bool Form::eventHandler(EventType* event)
    {
        switch(event->eType)
        {
            case frmLoadEvent:
                return handleLoadFormEvent(event->data.frmLoad.formID);
            case frmOpenEvent:
                return handleFormOpenEvent(event->data.frmLoad.formID);
            case ctlSelectEvent:
                return handleCtlSelectEvent(event->data.ctlSelect.controlID, event->data.ctlSelect.on);
            case menuEvent:
                return handleMenuEvent(event->data.menu.itemID);
            case keyDownEvent:
                return handleKeyDownEvent(event->data.keyDown.chr, event->data.keyDown.keyCode, event->data.keyDown.modifiers);
            case nilEvent:
                return handleNilEvent();
        }

        return false;
    }

    bool Form::handleLoadFormEvent(Word formID)
    {
        return false;
    }

    bool Form::handleFormOpenEvent(Word formID)
    {
        FrmDrawForm(FrmGetFormPtr(formID));
        return true;
    }

    bool Form::handleCtlSelectEvent(Word controlID, bool on)
    {
        return false;
    }

    bool Form::handleMenuEvent(Word menuID)
    {
        return false;
    }

    bool Form::handleKeyDownEvent(char asciiChar, Word keyCode, Word modifiers)
    {
        return false;
    }

    bool Form::handleNilEvent()
    {
        return false;
    }
}
// namespace UI
