//
//  Application.h
//
//  21 feb 2000
//

#ifndef _Application_h_
#define _Application_h_


namespace UI
{
    class Form;

    class Application
    {
    public:
        Application() {}
        virtual ~Application() {}

    private:
        Application(const Application&);
        Application& operator =(const Application&);

    public:
        void run(Form& mainForm, long eventLoopDelay);

    protected:
        virtual void start();
        virtual void stop();
        virtual void eventLoop(Form& mainForm, long delay);
    };
}
// namespace UI

#endif // _Application_h_
