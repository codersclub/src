//
//  Form.h
//
//  21 feb 2000
//

#ifndef _Form_h_
#define _Form_h_

#include "../Util/Error.h"


namespace UI
{
    //==============================================================================
    //  Form class
    //==============================================================================

    class Form
    {
    public:
        Form(Word formID);
        virtual ~Form() {}

    private:
        Form(const Form&);
        Form& operator =(const Form&);

    // operations
    public:

        virtual void loadForm();
        virtual void closeForm();

        void showElement(Word elementID);
        void hideElement(Word elementID);

    // attributes

        Word formID() const { return _formID; }
        FormPtr formPtr() const { return _formPtr; }

        template <class T> T getObjectPtr(FormObjectKind objectKind, Word objectID) const;

    // handlers to override

        virtual bool eventHandler(EventType* event);

    protected:
        virtual bool handleLoadFormEvent(Word formID);
        virtual bool handleFormOpenEvent(Word formID);
        virtual bool handleCtlSelectEvent(Word controlID, bool on);
        virtual bool handleMenuEvent(Word menuID);
        virtual bool handleKeyDownEvent(char asciiChar, Word keyCode, Word modifiers);
        virtual bool handleNilEvent();

    // data items
    private:
        Word _formID;
        FormPtr _formPtr;
    };

    template <class T>
    T Form::getObjectPtr(FormObjectKind objectKind, Word objectID) const
    {
        int index = FrmGetObjectIndex(formPtr(), objectID);
        assert(FrmGetObjectType(formPtr(), index) == objectKind);

        T ptr = reinterpret_cast<T>(FrmGetObjectPtr(formPtr(), index));
        assert(ptr != NULL);
        return ptr;
    }


    //==============================================================================
    //  FormEventHandler template class
    //==============================================================================

    template <class T>
    class FormEventHandler
    {
    public:
        void init(T* form)
        {
            _form = form;
            FrmSetEventHandler(_form->formPtr(), eventHandlerCallback);
        }

    private:
        static Boolean eventHandlerCallback(EventType* event)
        {
            return _form->eventHandler(event);
        }

        static T* _form;
    };

    template <class T> T* FormEventHandler<T>::_form;
}
// namespace UI

#endif // _Form_h_
