//
//  ScrollBar.h
//
//  21 feb 2000
//

#ifndef _ScrollBar_h_
#define _ScrollBar_h_

#include "FormElement.h"


namespace UI
{
    class Scrollable;

    class ScrollBar: public FormElement
    {
    public:
        ScrollBar(Form& parent, Word scrollBarID);
        ~ScrollBar() {}

    // operations

        // must be called by parent form directly
        Boolean eventHandler(EventType* event);

    // attributes

        ScrollBarPtr scrollBarPtr() const;
        void setScrollable(Scrollable& scrollable) { _scrollable = &scrollable; }

    // data members
    private:
        mutable ScrollBarPtr _scrollBarPtr;
        Scrollable* _scrollable;
    };
}
// namespace UI

#endif // _ScrollBar_h_
