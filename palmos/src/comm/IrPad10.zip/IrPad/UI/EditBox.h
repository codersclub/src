//
//  EditBox.h
//
//  21 feb 2000
//

#ifndef _EditBox_h_
#define _EditBox_h_

#include "FormElement.h"
#include "Scrollable.h"


namespace UI
{
    class ScrollBar;

    class EditBox: public FormElement, private Scrollable
    {
    public:
        EditBox(Form& parentForm, Word fieldID);
        ~EditBox() {}

    // operations

        void selectAll();
        void clearAll();

        void updateScrollBar();

        // must be called by parent form directly
        Boolean eventHandler(EventType* event);

    // attributes

        FieldPtr fieldPtr() const;
        void setScrollBar(ScrollBar& scrollBar);

    // implemntation
    private:
        void scrollPage(DirectionType direction);
        bool processPageKeys();

        virtual void updateScrollPosition(Word oldPosition, Word newPosition);

    // data members
    private:
        mutable FieldPtr _fieldPtr;
        ScrollBar* _scrollBar;
    };
}
// namespace UI

#endif // _EditBox_h_
