//
//  FormElement.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include "FormElement.h"
#include "Form.h"


namespace UI
{
    FormElement::FormElement(Form& parent, Word elementID):
        _parent(&parent),
        _elementID(elementID)
    {}

    // operations

    void FormElement::setFocus()
    {
        FrmSetFocus(_parent->formPtr(), FrmGetObjectIndex(_parent->formPtr(), elementID()));
    }

    bool FormElement::hasFocus() const
    {
        return FrmGetFocus(_parent->formPtr()) == FrmGetObjectIndex(_parent->formPtr(), elementID());
    }
}
// namespace UI
