//
//  TextPad.cc
//
//  25 feb 2000
//

#include <Pilot.h>
#include "IrDA/IrPort.h"
#include "Util/Error.h"
#include "TextPad.h"
#include "Preferences.h"
#include "IrPadRes.h"


TextPad::TextPad(UI::Form& parent, Preferences& preferences):
    _preferences(preferences),
    _editBox(parent, ID_EDIT_BOX),
    _editScrollBar(parent, ID_EDIT_SCROLLBAR)
{}

TextPad::~TextPad()
{}

void TextPad::init()
{
    FldSetMaxChars(_editBox.fieldPtr(), maxFieldTextLen);
    _editBox.setScrollBar(_editScrollBar);

    initFromPreferences();
}

void TextPad::shutdown()
{
    saveToPreferences();
}

void TextPad::open()
{
    _editBox.setFocus();
    scrollToEndOfText();
}

void TextPad::appendText(const char* text, int size)
{
    appendToTextBuffer(text, size);
    scrollToEndOfText();
}

void TextPad::sendText(IrDA::Port& irPort) const
{
    assert(irPort.isConnected());

    int size;
    const char* data;

    if (getSelectedText(data, size))
    {
        for (int read = 0, offset = 0; offset < size; offset += read)
        {
            if ((read = sendDataPacket(irPort, data+offset, size-offset)) == -1)
                break;
        }
    }
}

void TextPad::insertString(const char* string, int size)
{
    FldInsert(_editBox.fieldPtr(), (char*)string, size);
}

// event handlers

bool TextPad::eventHandler(EventType* event)
{
    return _editBox.eventHandler(event) || _editScrollBar.eventHandler(event);
}

bool TextPad::handleStandardMenuEvents(Word itemID)
{
    if (!_editBox.hasFocus())
        return false;

    switch(itemID)
    {
        case ID_MENU_UNDO:
            FldUndo(_editBox.fieldPtr());
            break;

        case ID_MENU_CUT:
            FldCut(_editBox.fieldPtr());
            break;

        case ID_MENU_COPY:
            FldCopy(_editBox.fieldPtr());
            break;

        case ID_MENU_PASTE:
            FldPaste(_editBox.fieldPtr());
            break;

        case ID_MENU_SELECT_ALL:
            _editBox.selectAll();
            break;

        case ID_MENU_CLEAR_ALL:
             _editBox.clearAll();
            break;

        default:
            return false;
    }

    return true;
}

// implementation

bool TextPad::getSelectedText(const char*& data, int& size) const
{
    data = FldGetTextPtr(_editBox.fieldPtr());    // assuming field will unlock it automatically
    if (data == NULL)
        return false;

    Word start, end;
    FldGetSelection(_editBox.fieldPtr(), &start, &end);

    if (start < end)
    {
        data += start;
        size = end-start;
    }
    else
        size = FldGetTextLength(_editBox.fieldPtr());

    return true;
}

int TextPad::sendDataPacket(IrDA::Port& irPort, const char* data, int size) const
{
    char* buffer = (char*)_translationBuffer.lock(irPort.getMaxTxSize());

    if (buffer != NULL)
    {
        int difference;
        int translatedSize = translateOutgoingText(buffer, _translationBuffer.size(), data, size, difference);

        irPort.sendData((Byte*)buffer, translatedSize);
        _translationBuffer.unlock();

        return translatedSize-difference;
    }

    _translationBuffer.unlock();
    return -1;
}

void TextPad::appendToTextBuffer(const char* data, int size)
{
    int textSize = FldGetTextLength(_editBox.fieldPtr());

    Util::MemBuffer editBuffer = (Util::MemBuffer::MemHandle)FldGetTextHandle(_editBox.fieldPtr());
    FldSetTextHandle(_editBox.fieldPtr(), NULL);

    char* text = (char*)editBuffer.lock(textSize+size+1);

    if (text != NULL)
    {
        textSize = translateIncomingText(text, textSize, data, size);
        text[textSize] = 0;
    }

    FldSetTextHandle(_editBox.fieldPtr(), (Handle)editBuffer.release());
}

void TextPad::scrollToEndOfText()
{
    int textLen = FldGetTextLength(_editBox.fieldPtr());

    FldSetScrollPosition(_editBox.fieldPtr(), textLen);
    FldSetInsertionPoint(_editBox.fieldPtr(), textLen);

    _editBox.updateScrollBar();
}

int TextPad::translateOutgoingText(char* dest, int destSize, const char* src, int srcSize, int& difference) const
{
    int destPos, srcPos;

    for (destPos = 0, srcPos = 0; destPos < destSize && srcPos < srcSize; ++srcPos)
    {
        if (src[srcPos] == '\n')
        {
            if (_preferences.sendNewLineAsCRLF())
            {
                if (destPos+2 > destSize)
                    break;

                dest[destPos++] = '\r';
                dest[destPos++] = '\n';
            }
            else
                dest[destPos++] = '\r';
        }
        else
            dest[destPos++] = src[srcPos];
    }

    difference = destPos-srcPos;
    return destPos;
}

int TextPad::translateIncomingText(char* dest, int destPos, const char* src, int srcSize) const
{
    for (int srcPos = 0; srcPos < srcSize; ++srcPos)
    {
        switch(src[srcPos])
        {
            case '\r':
                if (!_preferences.sendNewLineAsCRLF())
                    dest[destPos++] = '\n';
                break;

            case '\n':
                dest[destPos++] = '\n';
                break;

            case '\b':
                if (destPos > 0)
                    destPos--;                  // move position back inside the text buffer
                break;

            default:
                dest[destPos++] = src[srcPos];
        }
    }

    return destPos;
}

void TextPad::initFromPreferences()
{
    FldSetTextHandle(_editBox.fieldPtr(), (Handle)_preferences.textBuffer().release());
}

void TextPad::saveToPreferences()
{
    Util::MemBuffer textBuffer = (Util::MemBuffer::MemHandle)FldGetTextHandle(_editBox.fieldPtr());

    if (!textBuffer.isNull())
    {
        int textSize = FldGetTextLength(_editBox.fieldPtr());
        FldSetTextHandle(_editBox.fieldPtr(), NULL);

        textBuffer.resize(textSize+1);      // plus trailing zero
    }

    _preferences.setTextBuffer(textBuffer);
}
