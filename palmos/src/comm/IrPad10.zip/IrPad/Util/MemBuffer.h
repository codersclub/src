//
//  MemBuffer.h
//
//  14 feb 2000
//

#ifndef _MemBuffer_h_
#define _MemBuffer_h_

#include "Serializable.h"


namespace Util
{
    class MemBuffer: public Serializable
    {
    public:
        typedef VoidHand MemHandle;

        MemBuffer();
        MemBuffer(MemHandle handle);
        ~MemBuffer();

        // shallow copy, transfers ovnership to destination
        MemBuffer(const MemBuffer& other);
        MemBuffer& operator =(const MemBuffer& other);

    // operations

        // Returns NULL when fails to lock
        void* lock(int size);

        void* lock()                { return lock(size()); }
        const void* lock() const    { return const_cast<MemBuffer*>(this)->lock(); }

        void unlock() const;

        bool resize(int size);

        void free();
        MemHandle release();

    // attributes

        int size() const;
        bool isLocked() const { return _locked; }
        bool isNull() const { return _handle == 0; }

    // serialization

        virtual void serialize(DataOutputStream& stream) const;
        virtual void restore(const DataInputStream& stream);

    // implemntation
    private:

        bool allocate(int size);

    // data members
    private:
        MemHandle _handle;
        mutable bool _locked;
    };
}
// namespace Util

#endif // _MemBuffer_h_
