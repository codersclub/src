//
//  MemStream.cc
//
//  2 mar 2000
//

#include <Pilot.h>
#include "MemStream.h"


namespace Util
{
    MemStream::MemStream():
        _position(0)
    {}

    MemStream::MemStream(const MemBuffer& buffer)
    {
        setBuffer(buffer);
    }

    // operations

    int MemStream::readData(void* data, int size) const
    {
        if (!eof() && data != NULL && size > 0)
        {
            if (_position+size > _buffer.size())
                size = _buffer.size()-_position;

            MemMove(data, (Byte*)_buffer.lock()+_position, size);
            _position += size;

            return size;
        }

        return 0;
    }

    void MemStream::writeData(const void* data, int size)
    {
        if (data != NULL && size > 0)
        {
            int bufSize = _buffer.size();
            void* bufData = _buffer.lock(bufSize+size);

            if (bufData != NULL)
                MemMove((Byte*)bufData+bufSize, data, size);

            _buffer.unlock();
        }
    }

    // attributes

    void MemStream::setBuffer(const MemBuffer& buffer)
    {
        _buffer = buffer;
        reset();
    }
}
// namespace Util
