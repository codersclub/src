//
//  MemStream.h
//
//  2 mar 2000
//

#ifndef _MemStream_h_
#define _MemStream_h_

#include "DataInputStream.h"
#include "DataOutputStream.h"
#include "MemBuffer.h"


namespace Util
{
    class MemStream: public DataInputStream, public DataOutputStream
    {
    public:
        MemStream();
        MemStream(const MemBuffer& buffer);
        virtual ~MemStream() {}

        // MemStream(const MemStream&);
        // MemStream& operator = (const MemStream&);

    // operations

        void reset() { _position = 0; }

        virtual int readData(void* data, int size) const;
        virtual void writeData(const void* data, int size);

        virtual bool eof() const { return _position == _buffer.size(); }

    // attributes

        const MemBuffer& buffer() const { return _buffer; }
        void setBuffer(const MemBuffer& buffer);

    // data memebers
    private:
        mutable int _position;
        MemBuffer _buffer;
    };
}
// namespace Util

#endif // _MemStream_h_
