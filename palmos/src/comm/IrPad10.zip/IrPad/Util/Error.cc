//
//  Error.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include <stdarg.h>
#include "Error.h"

#ifdef DEBUG
#include <stdio.h>  // Stuff from libc used only for debugging
#include "MemStream.h"
#endif

// "Very" unique ID for standard error alert.
#define ID_ERROR_MESSAGE_ALERT      4848


namespace Util
{
    //==============================================================================
    // Debuging
    //==============================================================================

    #ifdef DEBUG

    void DebugMessage(const char* file, int line, const char* format, ...)
    {
        va_list args;
        char buffer[256];

        va_start(args, format);
        StrVPrintF(buffer, format, args);
        va_end(args);

        ErrDisplayFileLineMsg(file, line, buffer);
    }

    void DebugPrintf(const char* format, ...)
    {
        va_list args;
        char buffer[256];

        va_start(args, format);
        StrVPrintF(buffer, format, args);
        va_end(args);

        for (int i = 0, len = StrLen(buffer); i < len; ++i)
            putchar(buffer[i]);
    }

    void DebugDump(OutputStream& os, const void* data, int size, int charsInLine)
    {
        if (data == NULL || size == 0)
            return;

        for (int i = 0, count; i < size; i += count)
        {
            count = i+charsInLine > size? size-i : charsInLine;

            for (int j = 0; j < count; ++j)
            {
                char buff[10];
                sprintf(buff, "%02X ", ((unsigned char*)data)[i+j]);
                os.writeData(buff, StrLen(buff));
            }

            for (int j = 0; j < count; ++j)
            {
                char buff[] = { ((unsigned char*)data)[i+j] };
                os.writeData(buff, 1);
            }

            os.writeData("\n", 1);
        }

        os.writeData(0, 1);
    }

    class Stdout: public OutputStream
    {
        virtual void writeData(const void* data, int size)
        {
            for (int i = 0; i < size; ++i)
                 putchar(((Byte*)data)[i]);
        }
    };

    void DebugDumpPrint(const void* data, int size)
    {
        Stdout os;
        DebugDump(os, data, size, 8);
    }

    void DebugDumpMessage(const void* data, int size)
    {
        MemStream os;
        DebugDump(os, data, size, 6);

        FrmCustomAlert(ID_ERROR_MESSAGE_ALERT, (char*)os.buffer().lock(), "", "");
        os.buffer().unlock();
    }

    #endif  // DEBUG


    //==============================================================================
    // Error message
    //==============================================================================

    void ErrorMessage(const char* format, ...)
    {
        va_list args;
        char buffer[256];

        va_start(args, format);
        StrVPrintF(buffer, format, args);
        va_end(args);

        FrmCustomAlert(ID_ERROR_MESSAGE_ALERT, buffer, "", "");
    }
}
// namespace Util
