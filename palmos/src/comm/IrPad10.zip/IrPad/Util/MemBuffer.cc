//
//  MemBuffer.cc
//
//  14 feb 2000
//

#include <MemoryMgr.h>
#include <ErrorMgr.h>
#include "MemBuffer.h"
#include "DataInputStream.h"
#include "DataOutputStream.h"
#include "Error.h"


namespace Util
{
    MemBuffer::MemBuffer():
        _handle(0),
        _locked(false)
    {}

    MemBuffer::MemBuffer(MemHandle handle):
        _handle(handle),
        _locked(false)
    {}

    MemBuffer::~MemBuffer()
    {
        unlock();
        free();
    }

    MemBuffer::MemBuffer(const MemBuffer& other):
        _handle(0),
        _locked(false)
    {
        operator =(other);
    }

    MemBuffer& MemBuffer::operator =(const MemBuffer& other)
    {
        unlock();
        free();

        _handle = other._handle;
        _locked = other._locked;

        // transfer ownership
        const_cast<MemBuffer&>(other)._handle = NULL;

        return *this;
    }

    // operations

    void* MemBuffer::lock(int lockSize)
    {
        if (lockSize == 0)
            return NULL;

        if (_handle == 0)
        {
            allocate(lockSize);
        }
        else
        {
            if (size() < lockSize)
                resize(lockSize);
        }

        if (_handle == 0)
            return NULL;

        _locked = true;
        return (char*)MemHandleLock(_handle);
    }

    void MemBuffer::unlock() const
    {
        if (_handle != 0 && _locked)
        {
            if (MemHandleUnlock(_handle) != 0)
                ErrorMessage("Fail to unlock memory handle");
        }

        _locked = false;
    }


    bool MemBuffer::resize(int size)
    {
        if (MemHandleResize(_handle, size) != 0)
        {
            ErrorMessage("Memory reallocation error");
            return false;
        }

        return true;
    }

    void MemBuffer::free()
    {
        if (_handle != 0)
        {
            if (MemHandleFree(_handle) != 0)
                ErrorMessage("Fail to free memory handle");

            _handle = 0;
        }
    }

    MemBuffer::MemHandle MemBuffer::release()
    {
        unlock();

        MemHandle handle = _handle;
        _handle = 0;
        return handle;
    }

    // attributes

    int MemBuffer::size() const
    {
        return _handle != 0? MemHandleSize(_handle) : 0;
    }

    // serialization

    void MemBuffer::serialize(DataOutputStream& stream) const
    {
        void* data = const_cast<MemBuffer*>(this)->lock();

        if (data != NULL)
        {
            stream.write(size());
            stream.writeData(data, size());
        }
        else
        {
            stream.write(0);
        }

        const_cast<MemBuffer*>(this)->unlock();
    }

    void MemBuffer::restore(const DataInputStream& stream)
    {
        int len = stream.readAs<int>();
        void* data = lock(len);

        if (data != NULL)
            stream.readData(data, len);

        unlock();
    }

    // implemntation

    bool MemBuffer::allocate(int size)
    {
        assert(_handle == NULL);

        _handle = MemHandleNew(size);
        if (_handle == 0)
        {
            ErrorMessage("Memory allocation error");
            return false;
        }

        return true;
    }
}
// namespace Util
