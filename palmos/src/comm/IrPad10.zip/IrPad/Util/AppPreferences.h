//
//  AppPreferences.h
//
//  2 mar 2000
//

#ifndef _AppPreferences_h_
#define _AppPreferences_h_

namespace Util
{
    class Serializable;

    class AppPreferences
    {
    public:
        AppPreferences(DWord creatorID, Word preferencesID, int appVersion);

        // operations

        void save(const Serializable& preferences);
        bool load(Serializable& preferences) const;

    // data member
    private:
        DWord _creatorID;
        Word _preferencesID;
        int _appVersion;
    };
}
// namespace Util

#endif // _AppPreferences_h_
