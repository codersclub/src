//
//  DataInputStream.h
//
//  02 mar 2000
//

#ifndef _DataInputStream_h_
#define _DataInputStream_h_

#include "InputStream.h"


namespace Util
{
    class DataInputStream: public InputStream
    {
    public:
        void readAsString(char* string, int length) const   { readData(string, length); }

        template <typename T> T readAs() const;
    };

    template <typename T>
    T DataInputStream::readAs() const
    {
        T value = T();
        readData(&value, sizeof(T));
        return value;
    }
}
// namespace Util

#endif // _DataInputStream_h_
