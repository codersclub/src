//
//  DataOutputStream.h
//
//  02 mar 2000
//

#ifndef _DataOutputStream_h_
#define _DataOutputStream_h_

#include "OutputStream.h"


namespace Util
{
    class DataOutputStream: public OutputStream
    {
    public:
        void write(const char* string, int length)  { writeData(string, length); }

        template <typename T> void write(T value)   { writeData(&value, sizeof(value)); }
    };
}
// namespace Util

#endif // _DataOutputStream_h_
