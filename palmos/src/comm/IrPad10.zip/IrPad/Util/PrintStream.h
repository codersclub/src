//
// PrintStream.h
//
// 29 feb 2000
//

#ifndef _PrintStream_h_
#define _PrintStream_h_

#include "OutputStream.h"


namespace Util
{
    class PrintStream: public OutputStream
    {
    public:
        PrintStream();
        virtual ~PrintStream();

        // PrintStream(const PrintStream&);
        // PrintStream& operator =(const PrintStream&);

    // operations

        void print(const char* string);
        void print(const char* string, int size);
        void printf(const char* format, ...);

        void addIndent(int num)     { _indent += num; }
        void setIndent(int num)     { _indent = num; }
        int indent() const          { return _indent; }

    // implementation
    private:
        void printIndent();

    // data members
    private:
        int _indent;
        bool _newLine;
    };
}
// namespace Util

#endif // _PrintStream_h_
