//
// PrintStream.cc
//
// 29 feb 2000
//

#include <Pilot.h>
#include <stdarg.h>
#include "PrintStream.h"
#include "Error.h"


namespace Util
{
    PrintStream::PrintStream():
        _indent(0),
        _newLine(true)
    {}

    PrintStream::~PrintStream()
    {}

    void PrintStream::print(const char* string)
    {
        print(string, StrLen(string));
    }

    void PrintStream::print(const char* string, int size)
    {
        assert(string != NULL);

        if (_newLine)
            printIndent();
        _newLine = size > 0 && string[size-1] == '\n';

        writeData(string, size);
    }

    void PrintStream::printf(const char* format, ...)
    {
        assert(format != NULL);

        va_list args;
        char buffer[256];

        va_start(args, format);
        StrVPrintF(buffer, format, args);
        va_end(args);

        print(buffer);
    }

    void PrintStream::printIndent()
    {
        for (int i = 0; i < _indent; ++i)
            writeData("  ", 2);
    }
}
// namespace Util
