//
//  Serializable.h
//
//  02 mar 2000
//

#ifndef _Serializable_h_
#define _Serializable_h_

namespace Util
{
    class DataInputStream;
    class DataOutputStream;

    class Serializable
    {
    public:
        Serializable() {}
        virtual ~Serializable() {}

        virtual void serialize(DataOutputStream& stream) const = 0;
        virtual void restore(const DataInputStream& stream) = 0;
    };
}

#endif // _Serializable_h_
