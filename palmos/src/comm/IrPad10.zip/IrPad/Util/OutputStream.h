//
//  OutputStream.h
//
//  02 mar 2000
//

#ifndef _OutputStream_h_
#define _OutputStream_h_

namespace Util
{
    class OutputStream
    {
    public:
        OutputStream() {}
        virtual ~OutputStream() {}

        virtual void writeData(const void* data, int size) = 0;
    };
}
// namespace Util

#endif // _OutputStream_h_
