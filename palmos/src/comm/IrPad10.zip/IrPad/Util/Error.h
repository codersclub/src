//
//  Error.h
//
//  21 feb 2000
//

#ifndef _Error_h_
#define _Error_h_


//==============================================================================
// Debugging
//==============================================================================

#ifdef DEBUG

namespace Util
{
    class OutputStream;

    void DebugMessage(const char* file, int line, const char* format, ...);
    void DebugPrintf(const char* format, ...);

    void DebugDump(OutputStream& os, const void* data, int size, int charsInLine);
    void DebugDumpPrint(const void* data, int size);
    void DebugDumpMessage(const void* data, int size);
}

#define assert(cond) \
    ((cond)? (void)0 : ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assertion failed: " #cond))

#define assertf(cond, format, args...) \
    ((cond)? (void)0 : Util::DebugMessage(__FILE__, __LINE__, (format), ##args))

#else   // DEBUG

#define assert(cond)                        ((void)0)
#define assertf(cond, format, args...)      ((void)0)

#endif  // DEBUG


//==============================================================================
// Error message
//==============================================================================

namespace Util
{
    void ErrorMessage(const char* format, ...);
}

#endif _Error_h_
