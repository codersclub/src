//
//  AppPreferences.cc
//
//  2 mar 2000
//

#include <Pilot.h>
#include "AppPreferences.h"
#include "Serializable.h"
#include "MemStream.h"
#include "Error.h"


namespace Util
{
    AppPreferences::AppPreferences(DWord creatorID, Word preferencesID, int appVersion):
        _creatorID(creatorID),
        _preferencesID(preferencesID),
        _appVersion(appVersion)
    {}

    // operations

    void AppPreferences::save(const Serializable& preferences)
    {
        MemStream stream;
        preferences.serialize(stream);

        const MemBuffer& buffer = stream.buffer();
        PrefSetAppPreferences(_creatorID, _preferencesID, _appVersion, (void*)buffer.lock(), buffer.size(), true);
        buffer.unlock();
    }

    bool AppPreferences::load(Serializable& preferences) const
    {
        Word size = 0;

        if (PrefGetAppPreferences(_creatorID, _preferencesID, NULL, &size, true) != noPreferenceFound)
        {
            MemBuffer buffer;
            PrefGetAppPreferences(_creatorID, _preferencesID, buffer.lock(size), &size, true);
            buffer.unlock();

            MemStream stream(buffer);
            preferences.restore(stream);

            assert(stream.eof());

            return stream.eof();
        }

        return false;
    }
}
// namespace Util
