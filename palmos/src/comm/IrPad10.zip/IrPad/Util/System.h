//
//  System.h
//
//  23 feb 2000
//

#ifndef _System_h_
#define _System_h_


namespace Util
{
    void YieldControlToSystem(long delay, bool enableUI);
}

#endif // _System_h_