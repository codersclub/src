//
// System.cc
//
// 23 feb 2000
//

#include <Pilot.h>


namespace Util
{
    void YieldControlToSystem(long time, bool enableUI)
    {
        EventType event;

        EvtGetEvent(&event, time);

        if (!SysHandleEvent(&event) && enableUI)
        {
            Word err;

            if (!MenuHandleEvent(NULL, &event, &err))
                FrmDispatchEvent(&event);
        }
    }
}
