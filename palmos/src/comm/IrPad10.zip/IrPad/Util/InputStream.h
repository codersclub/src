//
//  InputStream.h
//
//  02 mar 2000
//

#ifndef _InputStream_h_
#define _InputStream_h_

namespace Util
{
    class InputStream
    {
    public:
        InputStream() {}
        virtual ~InputStream() {}

        virtual int readData(void* data, int size) const = 0;
        virtual bool eof() const = 0;
    };
}
// namespace Util

#endif // _InputStream_h_
