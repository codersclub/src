//
//  PreferencesForm.cc
//
//  22 feb 2000
//

#include <Pilot.h>
#include "PreferencesForm.h"
#include "Preferences.h"
#include "Util/MemBuffer.h"
#include "IrPadRes.h"


PreferencesForm::PreferencesForm(Preferences& preferences):
    UI::Form(ID_PREFERENCES_FORM),
    _preferences(preferences)
{}

void PreferencesForm::loadForm()
{
    UI::Form::loadForm();

    // creates static "thunk" for the form' event handler
    static UI::FormEventHandler<PreferencesForm> eventHandler;
    eventHandler.init(this);

    loadPreferences();
}

bool PreferencesForm::handleCtlSelectEvent(Word controlID, bool on)
{
    switch(controlID)
    {
        case ID_OK_BUTTON:
            savePreferences();
            FrmReturnToForm(ID_MAIN_FORM);
            return true;

        case ID_CANCEL_BUTTON:
            FrmReturnToForm(ID_MAIN_FORM);
            return true;
    }

    return false;
}

// implementation

void PreferencesForm::loadPreferences()
{
    setControlValue(ID_AUTO_CONNECT_CHECKBOX, _preferences.autoConnect());
    setFieldIntValue(ID_SECONDS_FIELD, _preferences.autoConnectPeriod());
    setControlValue(ID_TERMINAL_MODE_CHECKBOX, _preferences.terminalMode());
    setControlValue(ID_LOCAL_ECHO_CHECKBOX, _preferences.localEcho());
    setControlValue(ID_SEND_CRLF_CHECKBOX, _preferences.sendNewLineAsCRLF());
}

void PreferencesForm::savePreferences()
{
    _preferences.setAutoConnect(controlValue(ID_AUTO_CONNECT_CHECKBOX));
    _preferences.setAutoConnectPeriod(fieldIntValue(ID_SECONDS_FIELD));
    _preferences.setTerminalMode(controlValue(ID_TERMINAL_MODE_CHECKBOX));
    _preferences.setLocalEcho(controlValue(ID_LOCAL_ECHO_CHECKBOX));
    _preferences.setSendNewLineAsCRLF(controlValue(ID_SEND_CRLF_CHECKBOX));
}

int PreferencesForm::fieldIntValue(Word fieldID) const
{
    return StrAToI(FldGetTextPtr(getObjectPtr<FieldPtr>(frmFieldObj, fieldID)));
}

void PreferencesForm::setFieldIntValue(Word fieldID, int value)
{
    Util::MemBuffer numBuffer;
    StrIToA((char*)numBuffer.lock(sizeof(long)*8+1), value);

    FldSetTextHandle(getObjectPtr<FieldPtr>(frmFieldObj, fieldID), (Handle)numBuffer.release());
}

int PreferencesForm::controlValue(Word controlID) const
{
    return CtlGetValue(getObjectPtr<ControlPtr>(frmControlObj, controlID));
}

void PreferencesForm::setControlValue(Word controlID, int value)
{
    CtlSetValue(getObjectPtr<ControlPtr>(frmControlObj, controlID), value);
}
