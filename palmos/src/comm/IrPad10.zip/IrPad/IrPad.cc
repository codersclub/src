//
//  IrPad.cc
//
//  21 feb 2000
//

#include <Pilot.h>
#include "UI/Application.h"
#include "IrPad.h"
#include "TextPadPrintStream.h"
#include "IrPadRes.h"


static const int    EVENT_LOOP_DELAY        = 50;


//==============================================================================

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
    if (cmd == sysAppLaunchCmdNormalLaunch)
    {
        IrPadForm form;

        UI::Application app;
        app.run(form, EVENT_LOOP_DELAY);
    }

    return 0;
}


//==============================================================================
//  IrPadForm class
//==============================================================================


IrPadForm::IrPadForm():
    UI::Form(ID_MAIN_FORM),
    _preferencesForm(_preferences),
    _textPad(*this, _preferences),
    _lastAutoConnectTime(0)
{
    _irCallback._parent = this;
}

IrPadForm::~IrPadForm()
{}

void IrPadForm::loadForm()
{
    UI::Form::loadForm();

    // creates static "thunk" for the form' event handler
    static UI::FormEventHandler<IrPadForm> eventHandler;
    eventHandler.init(this);

    _textPad.init();
}

void IrPadForm::closeForm()
{
    UI::Form::closeForm();

    _irPort.close();
    _textPad.shutdown();
}

bool IrPadForm::eventHandler(EventType* event)
{
    if (_textPad.eventHandler(event))
        return true;

    return UI::Form::eventHandler(event);
}

bool IrPadForm::handleLoadFormEvent(Word formID)
{
    if (formID == _preferencesForm.formID())
    {
        _preferencesForm.loadForm();
        return true;
    }
}

bool IrPadForm::handleFormOpenEvent(Word formID)
{
    if (UI::Form::handleFormOpenEvent(formID))
    {
        _irPort.open(&_irCallback);
        _textPad.open();
        return true;
    }
    return false;
}

bool IrPadForm::handleCtlSelectEvent(Word controlID, bool on)
{
    if (controlID == ID_SEND_BUTTON)
    {
        irConnect();
        irSendTextPad();
        return true;
    }

    return false;
}

bool IrPadForm::handleMenuEvent(Word itemID)
{
    switch(itemID)
    {
        case ID_MENU_CONNECT:
            irConnect();
            break;

        case ID_MENU_DISCONNECT:
            irDisconnect();
            break;

        case ID_MENU_INFO:
            printInfo();
            break;

        case ID_MENU_PREFERENCES:
            FrmPopupForm(_preferencesForm.formID());
            break;

        case ID_MENU_ABOUT:
            FrmAlert(ID_ABOUT_ALERT);
            break;

        default:
            return _textPad.handleStandardMenuEvents(itemID);
    }
    return true;
}

bool IrPadForm::handleKeyDownEvent(char asciiChar, Word keyCode, Word modifiers)
{
    if (_preferences.terminalMode())
    {
        irSendChar(asciiChar);

        return !_preferences.localEcho();    // true, event has been processed - no local echo
    }

    return false;
}

bool IrPadForm::handleNilEvent()
{
    irAutoConnect();
    return true;
}

// implementation

void IrPadForm::irAutoConnect()
{
    if (_preferences.autoConnect())
    {
        if (!_irPort.isConnected())
        {
            if (_lastAutoConnectTime+_preferences.autoConnectPeriod() < TimGetSeconds())
            {
                irConnect();
                _lastAutoConnectTime = TimGetSeconds();
            }
        }
        else
            _lastAutoConnectTime = TimGetSeconds();
    }
}

void IrPadForm::irConnect()
{
    if (_irPort.isOpened())
    {
        if (!_irPort.isConnected())
        {
            showElement(ID_IR_DISCOVERY_BITMAP);
            if (!_irPort.connect())
                showElement(ID_IR_IDLE_BITMAP);
        }
    }
}

void IrPadForm::irDisconnect()
{
    if (_irPort.isConnected())
        _irPort.disconnect();
}

void IrPadForm::irSendTextPad()
{
    if (_irPort.isConnected())
    {
        showElement(ID_IR_TX_ACTIVE_BITMAP);
        _textPad.sendText(_irPort);
        hideElement(ID_IR_TX_ACTIVE_BITMAP);
    }
}

void IrPadForm::irSendChar(char ch)
{
    if (_irPort.isConnected())
    {
        showElement(ID_IR_TX_ACTIVE_BITMAP);

        if (ch == '\n')
        {
            if (_preferences.sendNewLineAsCRLF())
                _irPort.sendData((const Byte*)"\r\n", 2);
            else
                _irPort.sendData((const Byte*)"\r", 1);
        }
        else
        {
            Byte buff[] = { ch };
            _irPort.sendData(buff, 1);
        }

        hideElement(ID_IR_TX_ACTIVE_BITMAP);
    }
}

void IrPadForm::printInfo()
{
    TextPadPrintStream stream(_textPad);

    stream.print("\n");
    _irPort.printOn(stream);
    stream.print("\n");
}

//==============================================================================
// IrCallback class
//==============================================================================

void IrPadForm::IrCallback::connected()
{
    _parent->showElement(ID_IR_CONNECTED_BITMAP);
}

void IrPadForm::IrCallback::disconnected()
{
    _parent->showElement(ID_IR_IDLE_BITMAP);
}

void IrPadForm::IrCallback::dataSendReady()
{
    FormBitmapType* bitmap = _parent->getObjectPtr<FormBitmapType*>(frmBitmapObj, ID_IR_TX_ACTIVE_BITMAP);

    // little hack, but how to do it else?!
    if (bitmap->attr.usable)
        _parent->hideElement(ID_IR_TX_ACTIVE_BITMAP);
    else
        _parent->showElement(ID_IR_TX_ACTIVE_BITMAP);
}

void IrPadForm::IrCallback::dataReceived(const Byte* data, int size)
{
    _parent->showElement(ID_IR_RX_ACTIVE_BITMAP);

    _parent->_textPad.appendText((const char*)data, size);

    _parent->hideElement(ID_IR_RX_ACTIVE_BITMAP);
}

void IrPadForm::IrCallback::statusChanged(Status status)
{
    if (status == NoProgressStatus)
        _parent->showElement(ID_IR_NOPROGRESS_BITMAP);
    else if (status == LineOkStatus)
        _parent->showElement(ID_IR_CONNECTED_BITMAP);
}
