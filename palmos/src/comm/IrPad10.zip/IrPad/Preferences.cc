//
//  Preferences.cc
//
//  24 feb 2000
//

#include <Pilot.h>
#include "Preferences.h"
#include "Util/DataInputStream.h"
#include "Util/DataOutputStream.h"


static const DWord  APP_CREATOR_ID                  = 'IrPd';
static const Word   APP_PREFERENCES_ID              = 0;
static const Word   APP_PREFERENCES_VERSION         = 1;

static const int    MAX_AUTO_CONNECTION_PERIOD      = 10;   // sec
static const int    DEFAULT_AUTO_CONNECTION_PERIOD  = 3;    // sec


Preferences::Preferences():
    _appPreferences(APP_CREATOR_ID, APP_PREFERENCES_ID, APP_PREFERENCES_VERSION),
    _autoConnect(false),
    _autoConnectPeriod(DEFAULT_AUTO_CONNECTION_PERIOD),
    _terminalMode(false),
    _localEcho(false),
    _sendNewLineAsCRLF(true)
{
    _appPreferences.load(*this);
}

Preferences::~Preferences()
{
    _appPreferences.save(*this);
}

// attributes

void Preferences::setAutoConnectPeriod(int period)
{
    if (period <= 0 || period > MAX_AUTO_CONNECTION_PERIOD)
        _autoConnectPeriod = DEFAULT_AUTO_CONNECTION_PERIOD;
    else
        _autoConnectPeriod = period;
}

// serialization

void Preferences::serialize(Util::DataOutputStream& stream) const
{
    _textBuffer.serialize(stream);
    stream.write(_autoConnect);
    stream.write(_autoConnectPeriod);
    stream.write(_terminalMode);
    stream.write(_localEcho);
    stream.write(_sendNewLineAsCRLF);
}

void Preferences::restore(const Util::DataInputStream& stream)
{
    _textBuffer.restore(stream);
    _autoConnect = stream.readAs<bool>();
    _autoConnectPeriod = stream.readAs<int>();
    _terminalMode = stream.readAs<bool>();
    _localEcho = stream.readAs<bool>();
    _sendNewLineAsCRLF = stream.readAs<bool>();
}
