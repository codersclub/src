//
//  PreferencesForm.h
//
//  22 feb 2000
//

#include "UI/Form.h"

class Preferences;


class PreferencesForm: public UI::Form
{
public:
    PreferencesForm(Preferences& preferences);

    virtual void loadForm();

protected:
    virtual bool handleCtlSelectEvent(Word controlID, bool on);

// implementation
private:
    void loadPreferences();
    void savePreferences();

    int fieldIntValue(Word fieldID) const;
    void setFieldIntValue(Word fieldID, int value);

    int controlValue(Word controlID) const;
    void setControlValue(Word controlID, int value);

// data members
private:
    Preferences& _preferences;
};
