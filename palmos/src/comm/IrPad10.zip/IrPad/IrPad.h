//
//  IrPad.h
//
//  21 feb 2000
//

#ifndef _IrPad_h_
#define _IrPad_h_

#include "UI/Form.h"
#include "IrDA/IrPort.h"
#include "IrDA/IrCallback.h"
#include "PreferencesForm.h"
#include "Preferences.h"
#include "TextPad.h"


class IrPadForm: public UI::Form
{
public:
    IrPadForm();
    ~IrPadForm();

// operations

    virtual void loadForm();
    virtual void closeForm();
    virtual bool eventHandler(EventType* event);

protected:
    virtual bool handleLoadFormEvent(Word formID);
    virtual bool handleFormOpenEvent(Word formID);
    virtual bool handleCtlSelectEvent(Word controlID, bool on);
    virtual bool handleMenuEvent(Word itemID);
    virtual bool handleKeyDownEvent(char asciiChar, Word keyCode, Word modifiers);
    virtual bool handleNilEvent();

// implementation
private:
    void irAutoConnect();

    void irConnect();
    void irDisconnect();
    void irSendTextPad();
    void irSendChar(char ch);

    void printInfo();

// data memebers
private:
    PreferencesForm _preferencesForm;
    Preferences _preferences;

    TextPad _textPad;

    DWord _lastAutoConnectTime;
    IrDA::Port _irPort;

    // IR Calback implementation

    struct IrCallback: public IrDA::Callback
    {
        virtual void connected();
        virtual void disconnected();
        virtual void dataSendReady();
        virtual void dataReceived(const Byte* data, int size);
        virtual void statusChanged(Status status);

        IrPadForm* _parent;
    };
    friend struct IrCallback;

    IrCallback _irCallback;
};

#endif // _IrPad_h_
