//
//  IrPadRes.h
//
//  21 feb 2000
//

//-- Main form -----------------------------------------------------------------

#define ID_MAIN_FORM                1000

#define ID_EDIT_BOX                 1000
#define ID_EDIT_SCROLLBAR           1001

#define ID_IR_IDLE_BITMAP           1100
#define ID_IR_DISCOVERY_BITMAP      1101
#define ID_IR_CONNECTED_BITMAP      1102
#define ID_IR_NOPROGRESS_BITMAP     1103

#define ID_IR_RX_ACTIVE_BITMAP      1104
#define ID_IR_TX_ACTIVE_BITMAP      1105

#define ID_SEND_BUTTON              1010

#define ID_MAIN_MENU                1000

#define ID_MENU_CONNECT             1001
#define ID_MENU_DISCONNECT          1002
#define ID_MENU_INFO                1003

#define ID_MENU_UNDO                1010
#define ID_MENU_CUT                 1011
#define ID_MENU_COPY                1012
#define ID_MENU_PASTE               1013
#define ID_MENU_SELECT_ALL          1014
#define ID_MENU_CLEAR_ALL           1015

#define ID_MENU_PREFERENCES         1020
#define ID_MENU_ABOUT               1021

//-- Preferences form ----------------------------------------------------------

#define ID_PREFERENCES_FORM         1001

#define ID_AUTO_CONNECT_CHECKBOX    1001
#define ID_SECONDS_FIELD            1003
#define ID_TERMINAL_MODE_CHECKBOX   1006
#define ID_LOCAL_ECHO_CHECKBOX      1007
#define ID_SEND_CRLF_CHECKBOX       1008

#define ID_OK_BUTTON                1010
#define ID_CANCEL_BUTTON            1011

#define ID_PREFERENCES_HELP         1000

//-- Alerts --------------------------------------------------------------------

#define ID_ABOUT_ALERT              1000
#define ID_ERROR_MESSAGE_ALERT      4848        // used by ErrorMessage()
