#include <Pilot.h>
#include <FileStream.h>
#include "booger.h"

const unsigned char twhite[] = {
  "00110101.10011.101010.0101000.00011011.00101001.00001011.01011001."
};

const unsigned char ntwhite[] = {
  ".11011.10010.010111.0110111.00110110.00110111.01100100"
    ".01100101.01101000.01100111.011001100.011001101.011010010"
    ".011010011.011010100.011010101.011010110.011010111"
    ".011011000.011011001.011011010.011011011.010011000"
    ".010011001.010011010.011000.010011011.00000001000"
    ".00000001100.00000001101.000000010010.000000010011"
    ".000000010100.000000010101.000000010110.000000010111"
    ".000000011100.000000011101.000000011110.000000011111."
};

const unsigned char tblack[] = {
  "0000110111.000101.0000010111.00000010111.000001101010.000001101100.000001100100.000000101000."
};

const unsigned char ntblack[] = {
  ".0000001111.000011001000.000011001001.000001011011"
    ".000000110011.000000110100.000000110101.0000001101100"
    ".0000001101101.0000001001010.0000001001011.0000001001100"
    ".0000001001101.0000001110010.0000001110011.0000001110100"
    ".0000001110101.0000001110110.0000001110111.0000001010010"
    ".0000001010011.0000001010100.0000001010101.0000001011010"
    ".0000001011011.0000001100100.0000001100101.00000001000"
    ".00000001100.00000001101.000000010010.000000010011"
    ".000000010100.000000010101.000000010110.000000010111"
    ".000000011100.000000011101.000000011110.000000011111."
};

const unsigned char fxeol[3] = { 0, 0, 1 };

// 1728 - 0 - EOL 0100 1101 1-001 1010 10-00 0000 0000 0001

const unsigned char blankline[4] = { 0x4d, 0x9a, 0x80, 0x01 };
const unsigned char eofx[8] = { 0, 0x10, 1, 0, 0x10, 1, 0, 0x10 };

#define fwrite(dataP, objSize, numObj, stream) \
  FileWrite((stream), (dataP), (objSize), (numObj), NULL)

int outbit, count;
unsigned char t, *c;

void bitsout(const unsigned char *d, int rx)
{
  while (rx--)
    while (*d++ != '.');

  while (*d != '.') {

    if (*d++ & 1)
      t |= outbit;

    outbit >>= 1;
    if (!outbit) {

      *c++ = t;

      t = 0;
      count++;
      outbit = 0x80;
    }
  }
}

// Note this is one-eighth rez.
unsigned char cvtbuf[200];

void convert(unsigned char *bb, FileHand fd)
{
  int i, j, r, bit;

  for (i = 0; i < 160; i++) {


    {
      char bufx[20];
      StrIToA(bufx, i);
      WinDrawChars(bufx, StrLen(bufx), 20, 0);
    }

    j = 0;
    while (j < 20 && !*bb)
      j++, bb++;

    if (j == 20) {
      for (r = 0; r < 8; r++)
        fwrite(blankline, 1, 4, fd);
      continue;
    }

    r = (j + 1) << 3;
    c = cvtbuf;
    bit = 0x80;
    outbit = 0x80;
    t = 0;
    count = 0;

    while (j < 20) {

      while (j < 20) {
        while (bit) {
          if (*bb & bit)
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;
        for (;;) {
          j++;
          if (*++bb || j > 19)
            break;
          r += 8;
        }
      }
      if (j == 20)
        r += 48;

      if (r > 7)
        bitsout(ntwhite, r >> 3);
      bitsout(twhite, r & 7);
      r = 0;

      if (j > 19)
        break;

      while (j < 20) {
        while (bit) {
          if (!(*bb & bit))
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;

        for (;;) {
          j++;
          if (*++bb != 0xff || j > 19)
            break;
          r += 8;
        }
      }

      if (r > 7)
        bitsout(ntblack, r >> 3);
      bitsout(tblack, r & 7);
      r = 0;
      if (j == 20) {
        bitsout(ntwhite, 6);
        bitsout(twhite, 0);
      }

    }

    if (outbit != 0x80) {
      *c++ = t;
      count++;
    }

    *c++ = 0;
    *c++ = 0;
    *c++ = 1;
    count += 3;
    for (r = 0; r < 8; r++)
      fwrite(cvtbuf, 1, count, fd);
  }
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP)
{
  Char title[32];
  FileHand fd;
  int slen;

  /* Create the database */
  MemSet(title, 32, 0);
  StrNCopy(title, kleenexP->text, 28);
  StrCat(title, ".001");

  fd = FileOpen(0, title, 'DATA', 'ZFAX', fileModeReadWrite, NULL);

  // Start with several blank lines

  fwrite(fxeol, 1, 3, fd);
  for (slen = 0; slen < 64; slen++)
    fwrite(blankline, 1, 4, fd);

  convert(kleenexP->data, fd);

  // Append 3 blank lines
  for (slen = 0; slen < 16; slen++)
    fwrite(blankline, 1, 4, fd);

  FileClose(fd);

  kleenexP->booger.cmdPBP = NULL;
  kleenexP->booger.cmd = sysAppLaunchCmdNormalLaunch;
  kleenexP->booger.cardNo = 0;
  kleenexP->booger.dbID = DmFindDatabase(0, "ZBoxZ");

  /* Alls well that ends well... */
  return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{

  if (cmd != boogerPlugLaunchCmdBlowNose)
    return 0;

  BlowNose((KleenexPtr) cmdPBP);
  return 0;
}
