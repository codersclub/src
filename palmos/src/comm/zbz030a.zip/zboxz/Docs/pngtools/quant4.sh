pngtopnm $1 | ppmquant -map pal4.ppm | pnmtopng >Q4-$1
