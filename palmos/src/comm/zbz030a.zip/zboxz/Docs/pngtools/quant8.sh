pngtopnm $1 | ppmquant -map pal8.ppm | pnmtopng >Q8-$1
