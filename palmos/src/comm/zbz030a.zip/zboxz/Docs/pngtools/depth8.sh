pngtopnm $1 | pnmdepth 8 | pnmtopng >Q8-$1
