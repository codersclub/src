
ZBoxZ (tm) - File packager and handler for the Palm.

---------------------------------------------------

Release 0.25rc4

Tom Zerucha - tomz@users.sourceforge.net

(Formerly known as Boxer or PalmBoxer, but due to trademark conflicts
has been renamed)

Distributed under the GNU General Public License - see license.html
and include it with any distribution or derivative works.  Binaries
are being distributed separately, but anyone who wants to mirror the
binaries must include a way of getting the source under this license.

---------------------------------------------------------------------------

[Example useages, walkthroughs need to be added]

OMNISKY/PalmVII/Wireless kit

HiBrowz (browz.prc) is a helper app that downloads boxes from URLs.

If you simply run it you can enter data into the text field for the
URL and it will attempt to download it.  YOU NEED A PALM VII OR
WIRELESS KIT OR SOMETHING SUPPORTING THE CLIPPER.  Note the edit menu
is present so you can paste URLs from elsewhere or cut them (to save
off) or other similar things.

It also handles clipper download URLs.  For example, if you can browse
my web page at http://www.execpc.com/~tz you will find a PQA testing
section with tzgps.zip (my GPS program) with a URL of the form:

palm:BRWS.appl?http://www.execpc.com/~tz/tzgps.zip

If you tap on it on your VII or OmniSky it will download the file into
ZBoxZ.  PalmGear does this with autoinstall PQAs only, but with
boxer you can save money using zipped files and include the
documentation.

You can use PQAnywhere (included) to access my website and test this,
just enter http://www.execpc.com/~tz/ and tap the Now! button.

IF YOU DON'T HAVE WIRELESS WEB CLIPPING, BUT HAVE INTERNET:

LoBrowz web client is included if you don't have clipper but have a
modem or cradle that can link to the net.  It is almost identical to
HiBrowz.  It only does http, but will work on any port, so you can
enter more URLs.  It doesn't support https URLs, only http.

IMPORTANT NOTE ON ZBoxZ CREATOR TYPES.

ZBoxZ supports four types of boxes.

BOXR are for transfers between desktops (requires the backup bit to
download to the unbox directory using the conduit, or to the normal
backup directory).

BRWS is for the files downloaded by HiBrowz.

TZIP is for RUnZip files.

ATCH is for the files made available by Atache (for now it also does
     BOXR).

On the Info screen, you can make something a BOXR file, so you can
transport it to your desktop (remember to set the backup bit and
save).

MORE UTILITIES

PiNGer is the PNG/GIF viewer.  It has its own README.

Atache is the Web Server (yes, it can server web pages, albeit slowly
and with limits) It has its own readme.

RUnZip is the application compressor.

CapBMP captures any screen to a standard BMP file.

---------------------------------------------------------------------------

COMPILING

I am compiling with the prc-tools-2.0 at palmos.com and pilrc 2.5c.
Other versions may work.

DeskCore contains the core routines for the desktop programs.  These
are needed for all of the desktop builds.

Windows uses Visual C of some flavor, and Mac uses CodeWarrior.  The
linux version is the generic command line GCC version (though the open
modes should be binary if you port it to something like WinGNU).

All files in the MacBox directory including the C sources are in
MacBinary format.

---------------------------------------------------------------------------

OTHER STUFF

ZLib is in a separate PRC because it has multiple uses beyond just
Zips and GZips.  Portable Network Graphics (PNG) use it.  PPP Deflate
uses it.

ZLib has a homepage at:

	http://www.info-zip.org/pub/infozip/zlib/

Which includes all the versions, source, and technical details you
would ever want.

The Palm ZLib homepage is at palmzlib.sourceforge.net and contains
specific information about the shared library prc.

I've included the diff against the 1.1.3 (current) distribution, and a
precompiled .prc

---------------------------------------------------------------------------

TODO

-High--------------------------

Give warnings (and a chance to rename) for Overwrites (DmCreate/FOpen)

True Macintosh conduit (to replace macbox/macunbox)

RipUnX -> RipIt, add 2nd phase stop/install/ask; install/leave/delete

BoxOpen! auto RipIt (for installs of other software)

-Medium--------------------------

Check/process the Read-Only database bit correctly. (for delete or
overwrite, prompt?) or don't use it.

Pass a database and function code as an API, doc the APIs for ZFaxZ
and friends.

-Low-----------------------------

Concatenate several boxes (download part1, part2, part3, etc.).

Scratchpad overrun failures should autoexpand the DB and be maintained
in a pref entry.

Doc->box

PGP: armoring, literal wrapping, and compression - crypto later

---------------------------------------------------------------------------

-----------------------
NOTICES
-----------------------

ZBoxZ is a trademark of Tom Zerucha.

Other trademarks are the property of their respective owners.

-----------------------

ZLib:

Copyright notice:

 (C) 1995-1998 Jean-loup Gailly and Mark Adler

  This software is provided 'as-is', without any express or implied
  warranty.  In no event will the authors be held liable for any damages
  arising from the use of this software.

  Permission is granted to anyone to use this software for any purpose,
  including commercial applications, and to alter it and redistribute it
  freely, subject to the following restrictions:

  1. The origin of this software must not be misrepresented; you must not
     claim that you wrote the original software. If you use this software
     in a product, an acknowledgment in the product documentation would be
     appreciated but is not required.
  2. Altered source versions must be plainly marked as such, and must not be
     misrepresented as being the original software.
  3. This notice may not be removed or altered from any source distribution.

  Jean-loup Gailly        Mark Adler
  jloup@gzip.org          madler@alumni.caltech.edu

If you use the zlib library in a product, we would appreciate *not*
receiving lengthy legal documents to sign. The sources are provided
for free but without warranty of any kind.  The library has been
entirely written by Jean-loup Gailly and Mark Adler; it does not
include third-party code.

If you redistribute modified sources, we would appreciate that you include
in the file ChangeLog history information documenting your changes.

-----------------------

Although I tend to replace everything eventually, the skeleton I
started with may still have some particles left so here are the
original notices:

-----------------------

/*********************************************************************
*
* Copyright (c) 1998
* 3Com/Palm Computing Division.  All rights reserved.
*
* Redistribution and use in source and binary forms, with or without
* modification, are permitted provided that the following conditions
* are met:
* 1. Redistributions of source code must retain the above copyright
*    notice, this list of conditions and the following disclaimer.
* 2. Redistributions in binary form must reproduce the above
*    copyright notice, this list of conditions and the following
*    disclaimer in the documentation and/or other materials provided
*    with the distribution.
* 3. All advertising materials mentioning features or use of this
*    software must display the following acknowledgement:
* This product includes software developed by 3Com and its
* contributors.
* 4. Neither 3Com nor the names of its contributors may be used to
*    endorse or promote products derived from this software
*    without specific prior written permission.
*
* THIS SOFTWARE IS PROVIDED BY THE 3COM AND CONTRIBUTORS ``AS IS''
* AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED
* TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A
* PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL 3COM OR
* CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
* SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
* LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF
* USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
* ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
* OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
* OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY
* OF SUCH DAMAGE.
*
*******************************************************************/

---------------------------------------------------------------------------
PiNGer is based on pngcheck.

/*============================================================================
 *
 *   Copyright 1995-1999 by Alexander Lehmann <lehmann@usa.net>,
 *                          Andreas Dilger <adilger@enel.ucalgary.ca>,
 *                          Glenn Randers-Pehrson <randeg@alum.rpi.edu>,
 *                          Greg Roelofs <newt@pobox.com>,
 *                          John Bowler <jbowler@acm.org>,
 *                          Tom Lane <tgl@sss.pgh.pa.us>
 *  
 *   Permission to use, copy, modify, and distribute this software and its
 *   documentation for any purpose and without fee is hereby granted, provided
 *   that the above copyright notice appear in all copies and that both that
 *   copyright notice and this permission notice appear in supporting
 *   documentation.  This software is provided "as is" without express or
 *   implied warranty.
 *
 *===========================================================================*/

---------------------------------------------------------------------------

GIF decode routines (mainly just the decompression which is heavily
adapted but still has much of the original) based on gif2png's
gifread.c, which is under the zlib/libpng license, but I am
reproducing the copyright notices.

The gif2png home site is http://www.tuxedo.org/~esr/gif2png/ if you
want to see the full original (or better yet, want to use the
program).

The gif2png code is Copyright (C) 1995 Alexander Lehmann and 
                    Copyright (C) 1999 by Eric S. Raymond.
The file gifread.c is also Copyright 1990-1994 by David Koblas.

The Graphics Interchange Format(c) is the Copyright property of
CompuServe Incorporated. GIF(sm) is a Service Mark property of
CompuServe Incorporated.
