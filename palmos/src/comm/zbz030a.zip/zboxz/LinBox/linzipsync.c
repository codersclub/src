#include <stdio.h>
#include <string.h>

int zipsync(FILE * infd, char *title, FILE * outfd);

int main(int argc, char *argv[])
{
  FILE *outfd, *infd;
  int argp = 1;
  unsigned char title[128];

  if (argc < 2) {
    fprintf(stderr, "Usage: %s pdbfile...\n", argv[0]);
    exit(1);
  }

  while (argp < argc) {

    if (!(infd = fopen(argv[argp], "rb"))) {
      fprintf(stderr, "Can't open file %s\n", argv[argp]);
      exit(-2);
    }

    if (!strcasecmp(&argv[argp][strlen(argv[argp]) - 4], ".pqa"))
      argv[argp][strlen(argv[argp]) - 4] = 0;

    strcpy(title, argv[argp]);
    strcpy(&title[strlen(title) - 4], ".z");
    strcat(title, &argv[argp][strlen(argv[argp]) - 4]);

    outfd = fopen(title, "wb");

    title[strlen(title) - 4] = 0;

    zipsync(infd, title, outfd);

    argp++;
  }
  return 0;
}
