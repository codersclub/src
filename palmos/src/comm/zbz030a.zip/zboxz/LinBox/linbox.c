#include <stdio.h>
#include <string.h>

int box(FILE * infd, const char *fname, FILE * outfd);

int main(int argc, char *argv[])
{
  char fname[256];
  FILE *outfd, *infd;

  int argp = 1;

  if (argc < 2) {
    fprintf(stderr, "Usage: %s inputfile(s)\n", argv[0]);
    exit(1);
  }

  while (argp < argc) {

    if (!(infd = fopen(argv[argp], "rb")))
      exit(-1);

    strcpy(fname, argv[argp]);
    strcat(fname, ".pdb");

    if (!(outfd = fopen(fname, "wb")))
      exit(-1);

    box(infd, argv[argp], outfd);

    argv++;
  }
  return 0;
}
