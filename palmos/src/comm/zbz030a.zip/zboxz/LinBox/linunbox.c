#include <stdio.h>
#include <string.h>

int unbox(FILE * infd, FILE * outfd);

int main(int argc, char *argv[])
{
  char bbuf[256];
  FILE *outfd, *infd;
  int argp;

  if (argc < 2) {
    fprintf(stderr, "Usage: %s prcfile\n", argv[0]);
    exit(1);
  }

  for (argp = 1; argp < argc; argp++) {

    infd = fopen(argv[argp], "rb");
    strcpy(bbuf, argv[argp]);
    if (!strcmp(&bbuf[strlen(bbuf) - 4], ".pdb"))
      bbuf[strlen(bbuf) - 4] = 0;
    else
      strcat(bbuf, ".out");
    outfd = fopen(bbuf, "wb");

    unbox(infd, outfd);

  }
  return 0;
}
