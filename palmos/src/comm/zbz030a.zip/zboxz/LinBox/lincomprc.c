#include <stdio.h>
#include <string.h>

int comprc(FILE * infd, FILE * outfd);

int main(int argc, char *argv[])
{

  char fname[256];
  FILE *outfd, *infd;
  int argp = 1;

  if (argc < 2) {
    fprintf(stderr, "Usage: %s inputfile(s)\n", argv[0]);
    exit(1);
  }

  while (argp < argc) {
    strcpy(fname, argv[argp++]);

    if (!(infd = fopen(fname, "rb")))
      exit(-1);

    fprintf(stderr, "%s:\n", fname);


    if (!strcmp(&fname[strlen(fname) - 4], ".prc"))
      fname[strlen(fname) - 4] = 0;
    if (!strcmp(&fname[strlen(fname) - 4], ".PRC"))
      fname[strlen(fname) - 4] = 0;
    if (!strcmp(&fname[strlen(fname) - 4], ".Prc"))
      fname[strlen(fname) - 4] = 0;

    strcat(fname, ".pdb");

    if (!(outfd = fopen(fname, "wb")))
      exit(-1);

    comprc(infd, outfd);
  }
  return 0;
}
