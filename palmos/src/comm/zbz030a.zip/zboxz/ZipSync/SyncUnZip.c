#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>

#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"
#include "stdio2.h"

#define NOZLIBDEFS
#include "SysZLib.h"


void diagprogress(RectangleType * r)
{
  int i = 2;
  while (i--) {
    r->topLeft.y += 8, r->topLeft.x -= 8;
    WinDrawRectangle(r, 0);
  }
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{

  struct prchead {
    char name[32];              //0-32
    short int attr;             //32-33
    short int vers;             //34-35
    long int cr, md, bkt;       //times 36-47
    long int mn, app, sort;     // zero 48-59 - zero for prcs.
    long int type, crea;        //60-67
    long int uidseed, nxrec;    //68-75 - uidseed rand, nxrec zero;
    short int nrecs;            //76-78
  } head;

  struct rmstrec {
    unsigned long rsrc;
    unsigned short rsid;
    unsigned short ssz;
  } rs;
  struct dmstrec {
    unsigned long rsrc;
    unsigned short ssz;
  } ds;

  char name[36];
  LocalID lid, aiid, siid;
  int i, k;
  UInt32 total, uid;
  UInt16 asz, ssz, attr;
  DmOpenRef db;
  void *ap;
  UInt16 cardno = 0;
  FILE *fd, *ofd;
  z_stream pgpz;
  char *ibuf, *obuf;
  Err err;
  RectangleType r;
  DmSearchStateType dss;

  UInt ZLibRef = 0;


  if (cmd != sysAppLaunchCmdSyncNotify &&
      cmd != sysAppLaunchCmdOpenDB &&
      cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  for (;;) {

    EvtResetAutoOffTimer();

    WinEraseWindow();

    if (DmGetNextDatabaseByTypeCreator(true, &dss, 'DATA', 'SZIP', false,
				       &cardno, &lid))
      return 0;

    DmDatabaseInfo(cardno, lid, name, NULL, NULL, NULL, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL);

    WinDrawChars(name, strlen(name), 10, 20);

    fd = FileOpen(cardno, name, 'DATA', 'SZIP', fileModeReadOnly, &err);

    if (!fd || err) {
      WinDrawChars("OpenFail  ", 10, 80, 20);
      SysTaskDelay(100);
      return 1;
    }

    ofd =
      FileOpen(0, "SYNCUNZIPSCRATCH", 'TEMP', 'SZIP', fileModeReadWrite, &err);

    memset(&pgpz, 0, sizeof(pgpz));
    ZLSetup;

    if (inflateInit2(&pgpz, -15)) {
      WinDrawChars("NoUnZip   ", 10, 80, 20);
      SysTaskDelay(100);
      ZLTeardown;
      return 1;
    }

    FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);

#define BSIZ 2048
#define ZBSIZ (BSIZ*3)

    ibuf = MemPtrNew(BSIZ);
    obuf = MemPtrNew(ZBSIZ);

    r.topLeft.x = 0, r.topLeft.y = 0, r.extent.y = 16;

    FileTell(fd, &total, NULL);
    while (!feof(fd)) {

      pgpz.avail_in = fread(ibuf, 1, BSIZ, fd);
      pgpz.next_in = ibuf;

      r.extent.x = 160 * pgpz.total_in / total;
      WinDrawRectangle(&r, 0);
      EvtResetAutoOffTimer();

      while (pgpz.avail_in || feof(fd)) {
        pgpz.next_out = obuf;
        pgpz.avail_out = ZBSIZ;

        k = inflate(&pgpz, !feof(fd) ? 0 : Z_FINISH);
        /* SHOULD CHECK FOR ERRORS */
        fwrite(obuf, 1, ZBSIZ - pgpz.avail_out, ofd);

        if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ && feof(fd))
          continue;             /* for undoc zlib */

        if (k != Z_OK)
          break;
      }
    }

    EvtResetAutoOffTimer();

    r.extent.x = 160;
    WinDrawRectangle(&r, 0);

    r.extent.y = 8;
    r.extent.x = 24;
    r.topLeft.y = 8, r.topLeft.x = 136;

    diagprogress(&r);

    MemPtrFree(obuf);
    MemPtrFree(ibuf);

    inflateEnd(&pgpz);
    ZLTeardown;

    fclose(fd);

    FileDelete(cardno, name);

    fd = ofd;

    diagprogress(&r);

    rewind(fd);
    FileTell(fd, &total, NULL);
    FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);
    memset(&head, 0, sizeof(head));
    fread(&head, sizeof(head), 1, fd);

    WinDrawChars(head.name, strlen(head.name), 80, 128);

    diagprogress(&r);
    if (DmCreateDatabase(cardno, head.name, head.crea, head.type,
                         (head.attr & dmHdrAttrResDB))) {
      lid = DmFindDatabase(cardno, head.name);

      /////////////////CONFIRM

      if (lid)
        DmDeleteDatabase(cardno, lid);
      DmCreateDatabase(cardno, head.name, head.crea, head.type,
                       (head.attr & dmHdrAttrResDB));
    }

    lid = DmFindDatabase(cardno, head.name);
    if (!lid) {
      fclose(fd);
      return 1;
    }

    diagprogress(&r);

    head.attr &= ~dmHdrAttrReadOnly;
    DmSetDatabaseInfo(cardno, lid, NULL, &head.attr, &head.vers, &head.cr,
                      &head.md, &head.bkt, &head.mn, NULL, NULL, NULL, NULL);

    diagprogress(&r);
    db = DmOpenDatabase(cardno, lid, dmModeReadWrite);
    diagprogress(&r);

#define dmfread(bufP, objSize, numObj, stream) \
FileDmRead((stream), bufP, 0, (objSize), (numObj), NULL)

    fread(&asz, 1, 2, fd);
    if (asz) {
      ap = DmNewHandle(db, asz);
      dmfread(MemHandleLock(ap), 1, asz, fd);
      MemHandleUnlock(ap);
      aiid = MemHandleToLocalID(ap);
      DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                        &aiid, NULL, NULL, NULL);
    }

    diagprogress(&r);

    fread(&ssz, 1, 2, fd);
    if (ssz) {
      ap = DmNewHandle(db, ssz);
      dmfread(MemHandleLock(ap), 1, ssz, fd);
      MemHandleUnlock(ap);
      siid = MemHandleToLocalID(ap);
      DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                        NULL, &siid, NULL, NULL);
    }

    diagprogress(&r);

WinDrawChars("AtRecs    ", 10, 80, 20);

    r.topLeft.y = 144, r.topLeft.x = 0, r.extent.y = 16;
    k = 0;
    r.extent.x = 1;
    if (head.nrecs <= 160)
      r.extent.x = 160 / head.nrecs;

    for (i = 0; i < head.nrecs; i++) {
      EvtResetAutoOffTimer();

      k += 160;
      if (k >= head.nrecs) {
        if (head.nrecs > 160)
          k -= head.nrecs;
        else
          k = 0;
        WinDrawRectangle(&r, 0);
        r.topLeft.x += r.extent.x;
      }

      if (head.attr & dmHdrAttrResDB) {

        fread(&rs, 1, 8, fd);
        ap = DmNewResource(db, rs.rsrc, rs.rsid, rs.ssz);
        dmfread(MemHandleLock(ap), 1, rs.ssz, fd);
        MemHandleUnlock(ap);
        DmReleaseResource(ap);

      }  else {

        fread(&ds, 1, 6, fd);
        asz = 0xffff;
        ap = DmNewRecord(db, &asz, ds.ssz);
        dmfread(MemHandleLock(ap), 1, ds.ssz, fd);
        MemHandleUnlock(ap);
        attr = ds.rsrc >> 24;
        uid = ds.rsrc & 0xffffffUL;
        DmSetRecordInfo(db, asz, &attr, &uid);
        DmReleaseRecord(db, asz, false);

      }
    }

    fclose(fd);
    DmCloseDatabase(db);

  }

  EvtResetAutoOffTimer();

  unlink("SYNCUNZIPSCRATCH");

  return 0;
}
