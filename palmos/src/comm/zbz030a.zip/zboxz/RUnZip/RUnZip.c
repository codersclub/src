#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>

#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"
#include "stdio2.h"

#include "SysZLib.h"

void diagprogress(RectangleType * r)
{
  int i = 2;
  while (i--) {
    r->topLeft.y += 8, r->topLeft.x -= 8;
    WinDrawRectangle(r, 0);
  }
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{

  struct prchead {
    char name[32];              //0-32
    short int attr;             //32-33
    short int vers;             //34-35
    long int cr, md, bkt;       //times 36-47
    long int mn, app, sort;     // zero 48-59 - zero for prcs.
    long int type, crea;        //60-67
    long int uidseed, nxrec;    //68-75 - uidseed rand, nxrec zero;
    short int nrecs;            //76-78
  } head;

  struct rsrcdbent {
    long int rsrc;
    short int rsid;
    long int ofst;              //80+10*(nrecs+index)
  } *rsrcent;

  struct runzip {
    UInt16 cn;
    LocalID li;
    UInt16 cmd;
    void *cmdPBP;
  } *x;

  char name[36], *delmkp, dblist[256], *dblp;
  LocalID aiid, siid;
  int i, k, rsize;
  UInt32 asz, ssz, ofst, count, total;
  DmOpenRef db;
  void *ap;
  FILE *ifd, *ofd;
  z_stream pgpz;
  char *ibuf, *obuf;
  Err err;
  RectangleType r;
  LocalID lid = 0, delmark = 0;
  UInt16 zcmd = sysAppLaunchCmdNormalLaunch;
  void *zcmdPBP = NULL;

  if (cmd != sysAppLaunchCmdOpenDB && cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  if (!cmdPBP)
    return 0;

  x = cmdPBP;

  if (MemPtrSize(cmdPBP) == sizeof(struct runzip)) {
    zcmd = x->cmd;
    zcmdPBP = x->cmdPBP;
  }

  DmDatabaseInfo(x->cn, x->li, name, NULL, NULL, NULL, NULL,
                 NULL, NULL, NULL, NULL, NULL, NULL);

  ifd =
    FileOpen(x->cn, name, 'DATA', 'TZIP',
             fileModeReadOnly | fileModeAnyTypeCreator, &err);

  if (!ifd)
    for (x->cn = 0; x->cn < MemNumCards() && !ifd; x->cn++)
      ifd =
        FileOpen(x->cn, name, 'DATA', 'TZIP',
                 fileModeReadOnly | fileModeAnyTypeCreator, &err);

  if (!ifd)
    return 1;

#define BSIZ 2048
#define ZBSIZ (BSIZ*3)

  ibuf = MemPtrNew(BSIZ);
  obuf = MemPtrNew(ZBSIZ);
  ZLSetup;
  dblp = dblist;
  *dblp = 0;
  dblp[1] = 0;
  delmkp = NULL;

  do {
    count = FileTell(ifd, &total, NULL);
    if (total - count < 32)     /* too small for even a header */
      break;

    memset(&pgpz, 0, sizeof(pgpz));

    WinEraseWindow();
    WinDrawChars(name, strlen(name), 10, 20);

    r.topLeft.x = 0, r.topLeft.y = 0, r.extent.y = 16;
    ofd = FileOpen(0, "RUNZIPSCRATCH", 'TEMP', 'TZIP', fileModeReadWrite, NULL);
    //dmHdrAttrRecyclable
    inflateInit2(&pgpz, -15);
    k = Z_OK;

    while (k == Z_OK && !feof(ifd)) {
      pgpz.avail_in = fread(ibuf, 1, BSIZ, ifd);
      pgpz.next_in = ibuf;

      r.extent.x = 160 * (count + pgpz.total_in) / total;
      WinDrawRectangle(&r, 0);

      while (pgpz.avail_in || feof(ifd)) {
        pgpz.next_out = obuf;
        pgpz.avail_out = ZBSIZ;

        k = inflate(&pgpz, !feof(ifd) ? 0 : Z_FINISH); /* SHOULD CHECK FOR ERRORS */
        fwrite(obuf, 1, ZBSIZ - pgpz.avail_out, ofd);
        if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ && feof(ifd))
          continue;             /* for undoc zlib */
        if (k != Z_OK)          /* Z_STREAM_END */
          break;
      }
    }

    count = FileTell(ifd, NULL, NULL);

    if (pgpz.avail_in && total - count > 32)
      FileSeek(ifd, count - pgpz.avail_in, fileOriginBeginning); // for multi packed files

    inflateEnd(&pgpz);

    if (k != Z_OK && k != Z_STREAM_END)
      break;

    r.extent.x = 160;
    WinDrawRectangle(&r, 0);
    r.extent.y = 8, r.extent.x = 24, r.topLeft.y = 8, r.topLeft.x = 136;

    diagprogress(&r);

    rewind(ofd);
    FileTell(ofd, &total, NULL);
    FileControl(fileOpDestructiveReadMode, ofd, NULL, NULL);

    diagprogress(&r);

    memset(&head, 0, sizeof(head));
    fread(&head, sizeof(head), 1, ofd);
    count = sizeof(head);

    WinDrawChars(head.name, strlen(head.name), 10, 35);

    delmark = 0;

    strcpy(dblp, head.name);
    if (DmCreateDatabase(0, head.name, head.crea, head.type,
                         (head.attr & dmHdrAttrResDB))) {
      delmark = DmFindDatabase(0, head.name);
      if (!delmark)
        return -1;              // not a dupe but couldn't create?
#if 0
      if (head.type == 'appl') { // Switch out applications, so the stub can have the same name
        delmkp = dblp;
        if ((lid = DmFindDatabase(0, "RUNZIPMOVEDTEMP")))
          DmDeleteDatabase(0, lid);
        DmSetDatabaseInfo(0, delmark, "RUNZIPMOVEDTEMP", NULL, NULL, NULL, NULL,
                          NULL, NULL, NULL, NULL, NULL, NULL);
        //+ Save this name for the undo at bottom
      } else {
#endif
        DmDeleteDatabase(0, delmark);
        delmark = 0;
	//      }
      DmCreateDatabase(0, head.name, head.crea, head.type,
                       (head.attr & dmHdrAttrResDB));
    }
    dblp += strlen(dblp) + 1;
    *dblp = 0;

    lid = DmFindDatabase(0, head.name);
    diagprogress(&r);

    rsize = sizeof(struct rsrcdbent); //RSRC
    i = rsize * head.nrecs;
    rsrcent = MemPtrNew(rsize + i);
    fread(rsrcent, 1, i, ofd);
    count += i;
    rsrcent[head.nrecs].ofst = total; //RSRC
    ofst = rsrcent[0].ofst;     //RSRC

    diagprogress(&r);

    db = DmOpenDatabase(0, lid, dmModeReadWrite);

    diagprogress(&r);

    asz = 0;
    ssz = 0;
    if (head.app)
      asz = (head.sort ? head.sort : ofst) - head.app;
    if (head.sort)
      ssz = ofst - head.sort;

    diagprogress(&r);

#define dmfread(bufP, objSize, numObj, stream) \
FileDmRead((stream), bufP, 0, (objSize), (numObj), NULL)

    if (asz) {
      while (count < head.app)
        count +=
          fread(name, 1, head.app - count > 32 ? 32 : head.app - count, ofd);
      ap = DmNewHandle(db, asz);
      count += dmfread(MemHandleLock(ap), 1, asz, ofd);
      MemHandleUnlock(ap);
      aiid = MemHandleToLocalID(ap);
      DmSetDatabaseInfo(0, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                        &aiid, NULL, NULL, NULL);
    }

    diagprogress(&r);

    if (ssz) {
      while (count < head.sort)
        count +=
          fread(name, 1, head.sort - count > 32 ? 32 : head.sort - count, ofd);

      ap = DmNewHandle(db, ssz);
      count += dmfread(MemHandleLock(ap), 1, ssz, ofd);
      MemHandleUnlock(ap);
      siid = MemHandleToLocalID(ap);
      DmSetDatabaseInfo(0, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                        NULL, &siid, NULL, NULL);
    }

    diagprogress(&r);
    r.topLeft.y = 144, r.topLeft.x = 0, r.extent.y = 16;

    for (i = 0; i < head.nrecs; i++) {
      r.extent.x = ((i + 1) << 5) / head.nrecs * 5;
      WinDrawRectangle(&r, 0);

      while (count < rsrcent[i].ofst && !feof(ofd)) //RSRC...
        count +=
          fread(name, 1,
                rsrcent[i].ofst - count > 32 ? 32 : rsrcent[i].ofst - count,
                ofd);
      ssz = rsrcent[i + 1].ofst - rsrcent[i].ofst;
      ap = DmNewResource(db, rsrcent[i].rsrc, rsrcent[i].rsid, ssz);
      count += dmfread(MemHandleLock(ap), 1, ssz, ofd);
      MemHandleUnlock(ap);
      DmReleaseResource(ap);
    }

    fclose(ofd);
    MemPtrFree(rsrcent);
    DmCloseDatabase(db);
    unlink("RUNZIPSCRATCH");

    // At this point the original PRC is now on card 0

  } while (!feof(ifd));

  //---future multiprc loop ends

  MemPtrFree(obuf);
  MemPtrFree(ibuf);
  ZLTeardown;
  fclose(ifd);

  if (zcmdPBP) {
    void *tcmdPBP = MemPtrNew(MemPtrSize(zcmdPBP));
    memcpy(tcmdPBP, zcmdPBP, MemPtrSize(zcmdPBP));
    MemPtrSetOwner(tcmdPBP, 0);
    //???    MemPtrFree(zcmdpbp);
    zcmdPBP = tcmdPBP;
  }

  SysAppLaunch(0, lid, launchFlags, zcmd, zcmdPBP, &total);

  //+ Use the list created earlier to delete all and restore any appname
  dblp = dblist;
  while (*dblp) {
    DmDeleteDatabase(0, DmFindDatabase(0, dblp)); // in case lid changed
    dblp += strlen(dblp) + 1;
  }
#if 0
  if (delmark)
    DmSetDatabaseInfo(0, DmFindDatabase(0, "RUNZIPMOVEDTEMP"), delmkp, NULL,
                      NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

#endif
  return 0;
}
