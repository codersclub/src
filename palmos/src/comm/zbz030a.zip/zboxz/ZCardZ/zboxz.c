#include <PalmOS.h>

#include <ExgMgr.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <System/SysEvtMgr.h>
#include "zboxz.h"

#include <Unix/sys_types.h>

#include "stringil.h"

#define NOZLIBDEFS
#include "SysZLib.h"

static int toprow = 0;
static char *filelist;
static short int *filesort;
static FileRef archfd;

int selection = -1;
long int *filedisp;
int maxrow = 0;
unsigned char sels[256];
int bulk = 0;
char **filelp;
unsigned char prefs[12];

UInt16 lastform;

/* **************************************************************************** */
TableDrawItemFuncType TableDrawCell;

void TableDrawCell(VoidPtr tableP, Int16 row, Int16 column,
                   RectangleType * bounds)
{
  char *c;
  unsigned long which;

  which = TblGetRowData(tableP, row);
  c = filelp[which] + SORTPREFIX;
  WinEraseRectangle(bounds, 0);
  WinDrawChars(c, strlen(c), bounds->topLeft.x + 1, bounds->topLeft.y);
  if (sels[which >> 3] & (1 << (which & 7)))
    WinInvertRectangle(bounds, 0);
}

/* **************************************************************************** */

int unzipdir(FileRef infile, char *dir, long int *loc);
int untardir(FileRef fd, char *dir, long int *loc);

static Int16 fncomp(void *x, void *y, Int32 z)
{
  unsigned char **zx;
  int num = 32;

  zx = (unsigned char **) z;
  x = zx[*(short int *) x];
  y = zx[*(short int *) y];

  while (--num && *(unsigned char *) y++ == *(unsigned char *) x++);
  y--;
  x--;
  return *(unsigned char *) x - *(unsigned char *) y;

}

static void doflp()
{
  char *c;
  int i;

  c = filelist;
  for (i = 0; i < maxrow; i++) {
    DmWrite(filelp, 4 * i, &c, 4);
    c += strlen(c) + 1;
  }
}

static void nosortl()
{
  short int *sortlist, i;

  sortlist = MemPtrNew(maxrow * 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;

  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);
}

char tempath[512];
char savepath[512];

#define MAXCARDS 16

UInt16 dirlevel=0,dlvlsave=0;
UInt16 volno[MAXCARDS], curvol,savevol;
char name[512];

void scandbs()
{
  UInt16 vn;
  UInt32 volit, i, ndb, j, *flpt, disp, *fl;
  char tp[80];
  short int *sortlist;
  FileInfoType fileinf;
  FileRef dir;

  WinEraseWindow();             /* user feedback */
  maxrow = 0;
  disp = 0;

  WinDrawChars("Getting Directory...", 20, 0, 0);
  if (bulk)
    memset(sels, 0, 256);
  
  volit = vfsIteratorStart;
  if( !dirlevel ) {
    ndb = MAXCARDS;
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    i = 0;
    while( volit != vfsIteratorStop ) {
      if( VFSVolumeEnumerate(&vn,&volit) )
	break;
      volno[maxrow] = vn;
      memset(tp, 0, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */
      StrIToA(&tp[SORTPREFIX], vn+1);
      strcat(&tp[SORTPREFIX], ": ");
      VFSVolumeGetLabel(vn,&tp[SORTPREFIX+3],64);
      memcpy(tp, &vn, 2); //Sort by card number
      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
  }
  if( maxrow == 1 ) {
    strcpy(tempath,"/");
    curvol = volno[0];
    dirlevel = 1;
    maxrow = 0;
    disp = 0;
    volit = vfsIteratorStart;
  }
  if( dirlevel ) {

    strcpy( name,tempath);
    if( dirlevel > 1 )      
      name[strlen(name)-1] = 0; // remove trailing slash

    if(VFSFileOpen(curvol,name,vfsModeRead,&dir) )
      ErrDisplay("Could not access directory");

    ndb = 256;
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    i = 0;
    fileinf.nameBufLen=72;

    while( volit != vfsIteratorStop ) {
      memset(tp, 0, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */
      fileinf.nameP = &tp[SORTPREFIX];
      if( VFSDirEntryEnumerate(dir,&volit,&fileinf) )
	break;
      memcpy(&tp[1], &tp[SORTPREFIX], SORTPREFIX-1); /* this speeds up the sort */
      if( fileinf.attributes & vfsFileAttrDirectory )
	strcat(&tp[SORTPREFIX],"/");
      else
	tp[0]=1;

      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
    VFSFileClose(dir);
  }
  WinDrawChars("Sorting Directory...", 20, 0, 15);
  sortlist = MemPtrNew(maxrow * 2 + 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;
  SysQSort(sortlist, maxrow, 2, fncomp, (Int32) filelp);
  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);

  selection = -1;
  toprow = 0;
}

/* **************************************************************************** */

void swapdir()
{
  int vol1;

  vol1 = curvol;
  curvol = savevol;
  savevol = vol1;

  vol1 = dirlevel;
  dirlevel = dlvlsave;
  dlvlsave = vol1;

  strcpy(name,tempath);
  strcpy(tempath,savepath);
  strcpy(savepath,name);
  scandbs();
  FrmGotoForm(FrmGetActiveFormID());
}

void godir() {

  if (selection != -1) {

    if( dirlevel && filelp[selection][0] )
      return;
    if( !dirlevel ) {
      curvol = volno[selection];
      strcpy(tempath,"/");
    }
    else 
      strncat(tempath, filelp[selection] + SORTPREFIX,60);
    dirlevel++;
  }
  else if( dirlevel) {
    dirlevel--;
    if( dirlevel ) {
      char *c;
      c = tempath + strlen(tempath) - 1;
      while( *--c != '/' );
      *++c = 0;
    }
  }
  scandbs();
  FrmGotoForm(FrmGetActiveFormID());
}

RectangleType infoico = { {148, 0}
, {10, 10}
};

void settable()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  UInt top;
  Word row, numRows;
  ScrollBarPtr bar;

  WinEraseWindow();
  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  top = toprow;
  numRows = TblGetNumberOfRows(tptr);

  for (n = 0; n < 1; n++)
    TblSetColumnUsable(tptr, n, true);

  for (row = 0; row < numRows; row++, top++) {

    if (top < maxrow)
      TblSetRowData(tptr, row, (ULong) filesort[top]);

    if (top < maxrow) {
      TblSetRowSelectable(tptr, row, true);

      for (n = 0; n < 1; n++) {
        TblSetItemStyle(tptr, row, n, customTableItem);
        TblSetCustomDrawProcedure(tptr, n, TableDrawCell);
      }
      TblMarkRowInvalid(tptr, row);
    } else
      TblSetRowUsable(tptr, row, false);

  }

  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));

  if (maxrow <= numRows)
    SclSetScrollBar(bar, 0, 0, 0, 10);
  else
    SclSetScrollBar(bar, toprow, 0, maxrow - numRows, numRows);

  FrmDrawForm(frm);
  WinInvertRectangle(&infoico, 5);

#ifdef LEAKDETECT
  {
    UInt32 f, m;
    char buf[16];
    MemHeapFreeBytes(0, &f, &m);
    StrIToA(buf, f);
    strcat(buf, "   ");
    WinDrawChars(buf, strlen(buf), 40, 0);
    StrIToA(buf, m);
    strcat(buf, "   ");
    WinDrawChars(buf, strlen(buf), 100, 0);
  }
#endif
  top = toprow;
  for (row = 0; row < numRows; row++, top++)
    if (top < maxrow && selection == filesort[top]) {
      TblSelectItem(tptr, row, 0);
      break;
    }
  if (bulk || row == numRows)
    selection = -1;

}

/* **************************************************************************** */

void dopage(int down)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow += n * (((down) << 1) - 1);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doscroll()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  ScrollBarPtr bar;
  Word v, mn, mx, ps;

  frm = FrmGetActiveForm();
  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));
  SclGetScrollBar(bar, &v, &mn, &mx, &ps);
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow = v;
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doseek(char val)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  char *c;

  do {
    c = filelp[filesort[++toprow]] + SORTPREFIX;
  } while (toprow < maxrow && *c != val);

  if (toprow == maxrow) {
    toprow = 0;
    c = filelp[filesort[toprow]] + SORTPREFIX;
    while (toprow < maxrow && *c != val) // if rewound, use top if matched
      c = filelp[filesort[++toprow]] + SORTPREFIX;
    if (toprow == maxrow)
      toprow = 0;
  }

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;
  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

/* HANDLERS */
extern void ronamatic();

int basehand(EventPtr event)
{
  switch (event->eType) {

  case frmOpenEvent:
    settable();
    return 1;

  case sclExitEvent:
    doscroll();
    return 1;

  case keyDownEvent:

    switch (event->data.keyDown.chr) {
    case vchrSendData:
    case vchrRonamatic:
      ronamatic();
      return 1;
    case pageUpChr:
    case pageDownChr:
      dopage(event->data.keyDown.chr == pageDownChr);
      return 1;
    default:
      doseek(event->data.keyDown.chr);
      return 0;
    }

  case tblSelectEvent:
    selection = filesort[toprow + event->data.tblSelect.row];
    if (bulk) {
      FormPtr frm;
      TablePtr tptr;

      frm = FrmGetActiveForm();
      tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
      TblUnhighlightSelection(tptr);

      if( filelp[selection][0]) {
	sels[selection >> 3] ^= (1 << (selection & 7));
	WinEraseRectangle(&infoico, 5);
	FrmDrawForm(frm);
	WinInvertRectangle(&infoico, 5);
      }

      selection = -1;
    }
    else
      if( !filelp[selection][0]) {
	godir();
	scandbs();
	selection = -1;
      }
    return 1;
  default:
    return 0;
  }

}

/* **************************************************************************** */
int unzip(FileRef infile, long int loc, int local);
int untar(FileRef fd, long int loc, int local);

static Boolean UnzipH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bunzip:
    if (selection == -1)
      break;
    WinEraseWindow();
    unzip(archfd, filedisp[selection],FrmAlert(2400));
    FrmGotoForm(unzipform);
    return 1;
  case bexit:
    VFSFileClose(archfd);
    toprow = 0;
    scandbs();
    FrmGotoForm(decomform);
    return 1;
  }
  return 0;

}

/* **************************************************************************** */

static Boolean UntarH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case buntar:
    if (selection == -1)
      return 1;
    WinEraseWindow();
    untar(archfd, filedisp[selection], FrmAlert(2400));
    FrmGotoForm(untarform);
    return 1;

  case bexit:
    VFSFileClose(archfd);
    toprow = 0;
    scandbs();
    FrmGotoForm(decomform);
    return 1;
  }

  return 0;
}

/* **************************************************************************** */

static Boolean MainH(EventPtr event)
{
  int eid;
  LocalID lid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;
  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bfile:
    FrmGotoForm(fileform);
    return 1;
  case bdecom:
    FrmGotoForm(decomform);
    return 1;
  case binst:
    FrmGotoForm(instform);
    return 1;
  case bcomm:
    FrmGotoForm(commform);
    return 1;
  case bview:
    FrmGotoForm(viewform);
    return 1;
  case bgodir:
    godir();
    return 1;
  case bpref:
    FrmGotoForm(prefform);
    return 1;
  case bswap:
    swapdir();
    return 1;
  case bexit:
    lid = DmFindDatabase(0, "ZBoxZ");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdNormalLaunch, NULL);
    return 1;
  default:

    return 0;
  }
}

/* **************************************************************************** */
int MakeDatabase(FileRef fd);

static Boolean DecomH(EventPtr event)
{
  Word n, k;
  FileRef fd;
  int eid, lcl;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;
  eid = event->data.ctlEnter.controlID;
  if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  }
  if (selection == -1)
    return 1;

  strcpy(name,tempath);
  strcat(name,filelp[selection]+SORTPREFIX);
  VFSFileOpen(curvol, name, vfsModeRead , &fd);
  WinEraseWindow();

  switch (eid) {
  case bunzip:
    archfd = fd;
    n = unzipdir(archfd, filelist, filedisp);
    if (n) {
      toprow = 0;
      maxrow = n;
      doflp();
      nosortl();
      FrmGotoForm(unzipform);
    } else {
      FrmAlert(4000);
      VFSFileClose(archfd);
      scandbs();
      FrmGotoForm(decomform);
    }
    return 1;

  case buntar:
    archfd = fd;
    n = untardir(archfd, filelist, filedisp);
    if (n) {
      toprow = 0;
      maxrow = n;
      doflp();
      nosortl();
      FrmGotoForm(untarform);
    } else {
      FrmAlert(4000);
      VFSFileClose(archfd);
      scandbs();
      FrmGotoForm(decomform);
    }
    return 1;

  case bgunzip:
    n = unzip(fd, 0, FrmAlert(2400));
    VFSFileClose(fd);
    scandbs();
    FrmGotoForm(decomform);
    return 1;

  case bgzip:
    FrmGotoForm(gzipform);
    return 1;

  case bripunzip:
    WinEraseWindow();

    lcl = FrmAlert(2400);
    k = unzipdir(fd, filelist, filedisp);
    if (k) {
      n = unzip(fd, -1, lcl);
      VFSFileClose(fd);
      if (n != -1)
        FileDelete(0, name);
    } else {
      WinEraseWindow();
      k = untardir(fd, filelist, filedisp);
      if (k) {
        n = untar(fd, -1, lcl);
	VFSFileClose(fd);
	if (n != -1)
	  FileDelete(0, name);
      }
      else
	VFSFileClose(fd);
    }

    //Now install the files in filelist.
    if (k) {
      char *c = filelist + SORTPREFIX, *d, d1,d2;

      for (n = 0; n < k; n++,c += strlen(c) + 1 + SORTPREFIX) {
	d = &c[strlen(c) - 4];
	if ( *d++ != '.' )
	  continue;
	if ( toupper(*d++) != 'P' )
	  continue;
	d1 = toupper(*d++);
	d2 = toupper(*d++);
	if(!( d1 == 'R' && d2 == 'C' ) &&
	   !( d1 == 'D' && d2 == 'B' ) &&
	   !( d1 == 'Q' && d2 == 'A' ) )
	  continue;

	WinEraseWindow();
	WinDrawChars(c, strlen(c), 0, 15);
	VFSFileOpen(curvol, c, vfsModeRead , &fd);
	MakeDatabase(fd);
	VFSFileClose(fd);
	VFSFileDelete(curvol, c);
      }
    }

    scandbs();
    FrmGotoForm(decomform);
    return 1;

  case bgodir:
    godir();
    return 1;
  case bswap:
    swapdir();
    return 1;

  default:
    return 0;
  }

}

/* **************************************************************************** */
extern char ibuf[];

static Boolean CopyH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 type, crea, tlen, xlen;
  FileRef fd, ofd;
  int eid;
  UInt16 ivol;

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();

    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);

    VFSFileOpen(curvol, name, vfsModeRead , &fd);
    VFSFileSize(fd, &tlen);
    VFSFileClose(fd);

    thand = MemHandleNew(64);
    tptr = MemHandleLock(thand);
    strcpy(tptr,filelp[selection]+SORTPREFIX);
    strcat(tptr, "-Cpy");
    MemHandleUnlock(thand);

    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));
    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);

    StrIToA(name, tlen);
    strcat(name, " Bytes in file");
    WinDrawChars(name, strlen(name), 5, 45);
    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
  case binst:

    if( eid != bok && !dlvlsave)// No directory specified
      return 1;

    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);

    // COPY PREVENT?
    VFSFileOpen(curvol, name, vfsModeRead , &fd);
    VFSFileSize(fd, &tlen);

    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);
    tptr = MemHandleLock(thand);

    if( eid == bok)
      ivol = curvol, strcpy(name,tempath);
    else
      ivol = savevol, strcpy(name,savepath);

    strcat(name,tptr);
    MemHandleUnlock(thand);
    
    VFSFileOpen(ivol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd);

    WinEraseWindow();

    crea = tlen;
    WinDrawChars("Copying:", 8, 0, 15);
    while (tlen) {
      RectangleType r = { {0, 30}
      , {0, 15}
      };

      type = tlen > BSIZ ? BSIZ : tlen;
      VFSFileRead(fd, type, ibuf, &xlen);
      if (type != xlen)
        break;                  // ERROR MESSAGE
      VFSFileWrite(ofd, xlen, ibuf, &xlen);
      tlen -= xlen;

      r.extent.x = 160 - (160 * tlen / crea);
      WinDrawRectangle(&r, 0);

    }
    VFSFileClose(fd);
    VFSFileClose(ofd);

    // FALLTHROUGH

  case bexit:
    scandbs();
    FrmGotoForm(fileform);
    return 1;

  default:
    return 0;
  }
}


/* **************************************************************************** */

extern void gzip(FileRef fd, FileRef ofd);

static Boolean GzipH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 tlen;
  FileRef fd, ofd;
  int eid;

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();


    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);
    VFSFileOpen(curvol, name, vfsModeRead , &fd);
    VFSFileSize(fd, &tlen);
    VFSFileClose(fd);

    thand = MemHandleNew(32);
    tptr = MemHandleLock(thand);
    strcpy(tptr,filelp[selection]+SORTPREFIX);
    strcat(tptr, ".gz");

    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));
    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);

    StrIToA(name, tlen);
    strcat(name, " Bytes");
    WinDrawChars(name, strlen(name), 5, 45);
    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    VFSFileOpen(curvol, name, vfsModeRead , &fd);
    VFSFileSize(fd, &tlen);

    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);
    tptr = MemHandleLock(thand);

    strcpy(name,tempath);
    strcat(name,tptr);
    MemHandleUnlock(thand);
    VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd);

    WinEraseWindow();

    gzip(fd, ofd);

    VFSFileClose(fd);
    VFSFileClose(ofd);

    // FALLTHROUGH

  case bexit:
    scandbs();
    FrmGotoForm(decomform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

static Boolean PrefH(EventPtr event)
{
  FormPtr frm;
  int eid;
  ListPtr lptr;

  if (event->eType == frmOpenEvent) {
    WinEraseWindow();
    frm = FrmGetActiveForm();
    for (eid = 0; eid < 2; eid++)
      CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bpref1 + eid)),
                  !!prefs[eid]);

    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);
    return 1;
  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {

  case bok:
    frm = FrmGetActiveForm();
    lptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ltype));

    for (eid = 0; eid < 2; eid++)
      prefs[eid] =
        !!CtlGetValue(FrmGetObjectPtr
                      (frm, FrmGetObjectIndex(frm, bpref1 + eid)));
    FtrSet('BOXR', 1, prefs[2]);
    // Fallthrough
  case bexit:
    scandbs();
    FrmGotoForm(mainform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */
extern Boolean FileH(EventPtr event);
extern Boolean BulkH(EventPtr event);
extern Boolean InstH(EventPtr event);
extern Boolean MkDirH(EventPtr event);
extern Boolean InfoH(EventPtr event);
extern Boolean CommH(EventPtr event);
extern Boolean ViewH(EventPtr event);
extern unsigned long baud;

int removed;
Err setremoved(SysNotifyParamType *notif) {
  int *dp = notif->userDataP;
  UInt16 *vol;
  EventType e;

  notif->handled = -1;
  vol = notif->notifyDetailsP;
  if( vol )
    *dp = (int) vol; //The docs lie?
  else
    *dp = -1;

  e.eType = nilEvent;
  EvtAddEventToQueue (&e);
  return 0;
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  short err;
  int formID;
  FormPtr form = NULL;
  EventType event;
  LocalID lid;
  DmOpenRef scratch;
  Word dbrec;
  VoidHand hand;

  if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  if( FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &hand) )
    ErrDisplay("This Palm does not support the Filesystem used to access cards");

  removed = -1;
  SysNotifyRegister(0,0/*code resource lid*/, sysNotifyVolumeUnmountedEvent, setremoved , 0,  &removed);
  SysNotifyRegister(0,0/*code resource lid*/, sysNotifyVolumeMountedEvent, setremoved , 0,  &removed);

  toprow = 0;

  {
    UInt ps;
    ps = sizeof(prefs);
    MemSet(&prefs, ps, 1);
    PrefGetAppPreferences('BOXR', 1, &prefs, &ps, true);
    if (ps != sizeof(prefs)) {
      memset(&prefs, 1, sizeof(prefs));
      prefs[6] = 0;
      baud = 19200;
      (void) memcpy(&prefs[8], &baud, 4);
    }
    FtrSet('BOXR', 1, prefs[2]);
    (void) memcpy(&baud, &prefs[8], 4);

    ps = sizeof(tempath);
    MemSet(&name, ps, 3);
    PrefGetAppPreferences('ZCDZ', 1, &name, &ps, true);
    if(name[0] == 1) {
      curvol = savevol = name[1];
      dirlevel = dlvlsave =  name[2];
      if( dirlevel ) {
	FileRef dir;

	strcpy(tempath,&name[3]);
	strcpy(savepath,&name[3]);
	strcpy(name,tempath);
	name[strlen(name)-1] = 0; // remove trailing slash
	if( !VFSFileOpen(curvol,name,vfsModeRead,&dir) ) {
	  VFSFileClose(dir);
	  removed = 0;
	  FrmGotoForm(mainform);
	}
      }
    }
  }

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }

  //dmHdrAttrRecyclable

  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");
  dbrec = 0;
  hand = DmNewRecord(scratch, &dbrec, 20480);
  filelist = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048); /* max tar or zip directory size * 4 */
  filedisp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 4096);
  filelp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048);
  filesort = MemHandleLock(hand);

  if( !removed )
    scandbs();

  do {
    if (removed) {
      bulk = 0;
      if( removed == -1 )
	dirlevel =   dlvlsave = 0;
      else {
	if(savevol == removed )
	  dlvlsave = 0;
	if(curvol == removed )
	  dirlevel = 0;
      }

      scandbs();
      FrmGotoForm(mainform);
      removed = 0;
    }

    EvtGetEvent(&event, -1);

    if(event.eType == nilEvent)
      continue;

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;
    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      bulk = 0;
      switch (formID) {

      default:

      case mainform:
        FrmSetEventHandler(form, MainH);
        break;
      case fileform:
        FrmSetEventHandler(form, FileH);
        break;
      case decomform:
        FrmSetEventHandler(form, DecomH);
        break;
      case instform:
        FrmSetEventHandler(form, InstH);
        break;
      case unzipform:
        FrmSetEventHandler(form, UnzipH);
        break;
      case untarform:
        FrmSetEventHandler(form, UntarH);
        break;
      case copyform:
        FrmSetEventHandler(form, CopyH);
        break;
      case mkdirform:
        FrmSetEventHandler(form, MkDirH);
        break;
      case gzipform:
        FrmSetEventHandler(form, GzipH);
        break;
      case infoform:
        FrmSetEventHandler(form, InfoH);
        break;
      case prefform:
        FrmSetEventHandler(form, PrefH);
        break;
      case bulkform:
        bulk = 1;
        FrmSetEventHandler(form, BulkH);
        break;
      case commform:
        FrmSetEventHandler(form, CommH);
        break;
      case viewform:
        FrmSetEventHandler(form, ViewH);
        break;
      }

    }
    if (form)
      FrmDispatchEvent(&event);
  } while (event.eType != appStopEvent);

  SysNotifyUnregister(0,0/*code resource lid*/, sysNotifyVolumeUnmountedEvent, 0);
  SysNotifyUnregister(0,0/*code resource lid*/, sysNotifyVolumeMountedEvent, 0);

  (void) memcpy(&prefs[8], &baud, 4);
  PrefSetAppPreferences('BOXR', 1, 1, prefs, sizeof(prefs), true);

  name[0] = 1;
  name[1] = curvol;
  name[2] = dirlevel;
  strcpy(&name[3],tempath);
  PrefSetAppPreferences('ZCDZ', 1, 1, name, 4 + strlen(&name[3]), true);

  ZLTeardown;

  MemPtrUnlock(filedisp);
  MemPtrUnlock(filesort);
  MemPtrUnlock(filelp);
  MemPtrUnlock(filelist);
  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);
  DmCloseDatabase(scratch);

  return 0;
}
