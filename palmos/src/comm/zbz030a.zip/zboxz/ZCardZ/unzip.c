#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"

#include "SysZLib.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

extern UInt16 curvol,savevol;
extern char name[];
extern char tempath[],savepath[];

int VFSFGetC(FileRef fp)
{
  unsigned char lastchr;

  if( VFSFileRead(fp, 1, &lastchr, NULL) )
    return -1; 

  return lastchr & 0xff;
}

#define STORED            0     /* compression methods */
#define DEFLATED          8

#  define CRCVAL_INITIAL  0L

/* PKZIP header definitions */
#define ZIPMAG 0x4b50           /* two-byte zip lead-in */
#define LOCREM 0x0403           /* remaining two bytes in zip signature */
#define LOCSIG 0x04034b50L      /* full signature */
#define LOCFLG 4                /* offset of bit flag */
#define  CRPFLG 1               /*  bit for encrypted entry */
#define  EXTFLG 8               /*  bit for extended local header */
#define LOCHOW 6                /* offset of compression method */
#define LOCTIM 8                /* file mod time (for decryption) */
#define LOCCRC 12               /* offset of crc */
#define LOCSIZ 16               /* offset of compressed size */
#define LOCLEN 20               /* offset of uncompressed length */
#define LOCFIL 24               /* offset of file name field length */
#define LOCEXT 26               /* offset of extra field length */
#define LOCHDR 28               /* size of local header, including LOCREM */
#define EXTHDR 16               /* size of extended local header, inc sig */

/* GZIP header definitions */
#define GZPMAG 0x8b1f           /* two-byte gzip lead-in */
#define GZPHOW 0                /* offset of method number */
#define GZPFLG 1                /* offset of gzip flags */
#define  GZPMUL 2               /* bit for multiple-part gzip file */
#define  GZPISX 4               /* bit for extra field present */
#define  GZPISF 8               /* bit for filename present */
#define  GZPISC 16              /* bit for comment present */
#define  GZPISE 32              /* bit for encryption */
#define GZPTIM 2                /* offset of Unix file modification time */
#define GZPEXF 6                /* offset of extra flags */
#define GZPCOS 7                /* offset of operating system compressed on */
#define GZPHDR 8                /* length of minimal gzip header */

/* Macros for getting two-byte and four-byte header values */
#define SH(p) ((unsigned short int)(unsigned char)((p)[0]) | ((unsigned short int)(unsigned char)((p)[1]) << 8))
#define LG(p) ((unsigned long)(SH(p)) | ((unsigned long)(SH((p)+2)) << 16))

/* Globals */

#define ZBSIZ (BSIZ/4)

unsigned char ibuf[BSIZ], obuf[ZBSIZ];

#define fprintf(a,b) ErrDisplay(b)
#define err(n, m) {ErrDisplay(m);return n;}

int unzipdir(FileRef ifd, char *dir, long int *loc)
{
  unsigned long total, disp = 0, i=0;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  char *c;
  int max;

  DmSet(dir,0,2,0);
  max = 0;

  VFSFileSeek(ifd, vfsOriginBeginning, 0);

  /* read ZIPal header, check validity */
  n = VFSFGetC(ifd);
  if (n > 255 || VFSFileEOF(ifd))
    return 0;
  n |= VFSFGetC(ifd) << 8;

  if (n != ZIPMAG)
    return 0;

  for (;;) {

    VFSFileTell(ifd, &total);
    total -= 2;
    DmWrite(loc,(i++)*4,&total,4);

    VFSFileRead(ifd, LOCHDR, (char *) h, NULL);
    if (SH(h) == 0x0201)
      return max;               // start of central directory
    if (SH(h) != LOCREM)
      err(3, "invalid zipfile");

    /* FILENAME */
    ibuf[SH(h + LOCFIL)] = 0;

    VFSFileRead(ifd, SH(h + LOCFIL), ibuf, NULL);

    for (n = SH(h + LOCEXT); n--;)
      VFSFGetC(ifd);

    total = LG(h + LOCSIZ);
    c = ibuf;

    DmWrite(dir,disp,"    ",4);
    DmWrite(dir,disp+4,c,strlen(c)+1);
    disp += 4+strlen(c)+1;
    DmSet(dir,disp,1,0);

    VFSFileSeek(ifd, vfsOriginCurrent, total);
    /* if extended header, get it */
    if ((h[LOCFLG] & EXTFLG) &&
        VFSFileRead(ifd, EXTHDR, (char *) h + LOCCRC - 4, NULL) != EXTHDR)
      err(3, "zipfile ended prematurely");

    max++;

    VFSFileTell(ifd, &total);

    /* read local header, check validity, and skip name and extra fields */
    n = VFSFGetC(ifd);
    if (n > 255 || VFSFileEOF(ifd))
      return max;
    n |= VFSFGetC(ifd) << 8;

    if (n != ZIPMAG)
      return max;
  }
}

/* ************************************************************************ */

int unzip(FileRef ifd, long int loc, int local)
{
  FileRef ofd;
  unsigned long crc32val;
  unsigned long outsiz;         /* total bytes written to out */
  int encrypted;                /* flag to turn on decryption */
  unsigned long total, itot;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  int k = 0;
  UInt32 got;
  z_stream pgpz;
  int gz = 0;                   /* true if gzip format */
  char *c;
  RectangleType r;
  UInt16 ivol;

  VFSFileSeek(ifd, vfsOriginBeginning, 0);
  /* read ZIPal header, check validity */
  n = VFSFGetC(ifd);
  if (n > 255 || VFSFileEOF(ifd) )
    return 0;
  n |= VFSFGetC(ifd) << 8;

  if (n != ZIPMAG && n != GZPMAG)
    return -1;

  VFSFileSize(ifd, &total);
  VFSFileSeek(ifd, vfsOriginBeginning, loc == -1 ? 0 : loc);

  for (;;) {

    /* read local header, check validity, and skip name and extra fields */
    n = VFSFGetC(ifd);
    if (n > 255 || VFSFileEOF(ifd) )
      return 0;

    n |= VFSFGetC(ifd) << 8;

    r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
    WinEraseRectangle(&r, 0);

    if(local)
      ivol = curvol,	strcpy(ibuf,tempath);
    else
      ivol = savevol,	strcpy(ibuf,savepath);

    if (n == ZIPMAG) {
      VFSFileRead(ifd, LOCHDR, (char *) h, NULL);
      if (SH(h) == 0x0201)
        return 0;               // start of central directory
      if (SH(h) != LOCREM)
        err(3, "invalid zipfile");
      if (SH(h + LOCHOW) != STORED && SH(h + LOCHOW) != DEFLATED)
        err(3, "entry not deflated or stored--cannot unpack");

      if(local)
	ivol = curvol,	strcpy(ibuf,tempath);
      else
	ivol = savevol,	strcpy(ibuf,savepath);

      c = ibuf;
      c += strlen(ibuf);
      c[SH(h + LOCFIL)] = 0;
      VFSFileRead(ifd, SH(h + LOCFIL), c, NULL);

      for (n = SH(h + LOCEXT); n--;)
        gz = VFSFGetC(ifd);
      gz = 0;
      encrypted = h[LOCFLG] & CRPFLG;
    }

    else if (n == GZPMAG) {
      VFSFileRead(ifd, GZPHDR, (char *) h, NULL);
      if ((h[GZPHOW] != DEFLATED) || (h[GZPFLG] & GZPMUL))
        err(3, "cannot handle this gzip file");

      if (h[GZPFLG] & GZPISX) {
        n = VFSFGetC(ifd);
        n |= VFSFGetC(ifd) << 8;
        VFSFileRead(ifd, n, ibuf, NULL);
      }

      if (h[GZPFLG] & GZPISF) {

	if(local)
	  ivol = curvol,	strcpy(ibuf,tempath);
	else
	  ivol = savevol,	strcpy(ibuf,savepath);

        c = ibuf;
	c += strlen(ibuf);
        while ((*c++ = VFSFGetC(ifd)) != 0);
	*c = 0;

      } else {

	strcpy(ibuf,name);
	ivol = curvol;
	if( !local ) {
	  ivol = savevol;
	  strcpy(name,savepath);
	  c = &ibuf[strlen(ibuf)-1];
	  while( *c != '/' )
	    c--;
	  c++;
	  strcat(name,c);
	  strcpy(ibuf,name);
	}

        c = &ibuf[strlen(ibuf) - 4];
        if (!strcmp(c, ".tgz") || !strcmp(c, ".TGZ"))
          c[2] = 'a', c[3] = 'r';
        else if (!strcmp(++c, ".gz") || !strcmp(c, ".GZ"))
          *c = 0;
        else
          strcat(ibuf, ".guz");
      }

      if (h[GZPFLG] & GZPISC)
        while ((gz = VFSFGetC(ifd)) != 0 && gz != -1);

      gz = 1;
      encrypted = h[GZPFLG] & GZPISE;
    }

    else
      return 1;

    if( !gz )
      total = LG(h + LOCSIZ);
    if (!total) {
      if (loc == -1)
        continue;
      else
        return -1;
    }

    /* fix filename? and open for write */

    if( VFSFileOpen(ivol, ibuf, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd) ) {
      c = &ibuf[1];
      while( *c ) {
	while( *c && *c != '/' )
	  c++;
	if( *c == '/' ) {
	  *c = 0;
	  VFSDirCreate(curvol, ibuf);
	  *c++ = '/';
	}
      }
      VFSFileOpen(ivol, ibuf, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd);
    }

    if( !ofd )
      return -1;
    WinDrawChars(c, strlen(c), 0, 15);

    /* if entry encrypted, decrypt and validate encryption header */
    if (encrypted)
      err(3, "cannot decrypt entry (need to recompile with full crypt.c)");

    itot = total;
    outsiz = 0L;
    crc32val = CRCVAL_INITIAL;

    r.topLeft.y = 30, r.extent.y = 15;

    /* decompress */
    if (gz || h[LOCHOW]) {      /* deflated entry */
      outsiz = 0;
      memset(&pgpz, 0, sizeof(pgpz));
      ZLSetup;
      inflateInit2(&pgpz, -15);

      while (total && !VFSFileEOF(ifd) ) {

	VFSFileRead(ifd, total > BSIZ ? BSIZ : total,ibuf, &got);
	if( !got )
	  break;

	total -= got;
	r.extent.x = 160 - (160 * total / itot);
	WinDrawRectangle(&r, 0);

	pgpz.next_in = ibuf;
	pgpz.avail_in = got;
	while (pgpz.avail_in || !total || VFSFileEOF(ifd)) {
	  pgpz.next_out = obuf;
	  pgpz.avail_out = ZBSIZ;
	  k = inflate(&pgpz, !total || !VFSFileEOF(ifd) ? 0 : Z_FINISH);
	  /* SHOULD CHECK FOR ERRORS */
	  VFSFileWrite(ofd,  ZBSIZ - pgpz.avail_out, obuf, NULL);
	  outsiz += ZBSIZ - pgpz.avail_out;
	  crc32val = crc32(crc32val, obuf, ZBSIZ - pgpz.avail_out);

	  if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ
	      && (total || VFSFileEOF(ifd) )) continue; /* for undoc zlib */
	  if (k != Z_OK)
	    break;
	}
      }
      inflateEnd(&pgpz);

      //error status:       (k == Z_STREAM_END);
    }
    else {                      /* stored entry */

      got = LG(h + LOCLEN);
      if (got != LG(h + LOCSIZ))
        err(4, "invalid compressed data--length mismatch");

      total = got;
      while (total) {
        VFSFileRead(ifd, total > BSIZ ? BSIZ : total, ibuf, &got);
        outsiz += got;
        total -= got;
        r.extent.x = 160 * total / itot;
        WinDrawRectangle(&r, 0);
        crc32val = crc32(crc32val, ibuf, got);

        VFSFileWrite(ofd, got, ibuf, NULL);
      }
    }
    VFSFileClose(ofd);
    EvtResetAutoOffTimer();

    /* if extended header, get it */
    if (gz) {
      if (pgpz.avail_in < 8)
        err(3, "gzip ended prematurely");
      memcpy((char *) h + LOCCRC, pgpz.next_in, 8);

      break;                    //THIS DOESN'T WORK HERE
    }
      else
      if ((h[LOCFLG] & EXTFLG) &&
          VFSFileRead(ifd, EXTHDR, (char *) h + LOCCRC - 4, NULL) != EXTHDR)
        err(3, "zipfile ended prematurely");

    /* validate decompression */
    if (LG(h + LOCCRC) != crc32val)
      err(4, "invalid compressed data--crc error");

    if (LG((gz ? (h + LOCSIZ) : (h + LOCLEN))) != outsiz)
      err(4, "invalid compressed data--length error");

    if (loc != -1)
      break;
  }
  return 0;
}


char gzhead[10] = {0x1f , 0x8b, 8 , 0,0,0,0,0,0,3 };

int gzip(FileRef ifd, FileRef outf)
{
  z_stream gzipit;
  int isav;
  unsigned long crc32val, itotal, total = 0, got;
  RectangleType r;

  r.topLeft.x = 0, r.topLeft.y = 30, r.extent.x = 160, r.extent.y = 15;
  WinDrawChars("GZipping:",9 , 0, 15);

  memset(&gzipit, 0, sizeof(gzipit));
  VFSFileWrite(outf, 10, gzhead, NULL);

  VFSFileSize(ifd, &itotal);

  crc32val = CRCVAL_INITIAL;

  gzipit.next_out = ibuf;
  gzipit.avail_out = BSIZ;

  ZLSetup;
  deflateInit2(&gzipit, /* level */ 6, 8,/* bits */ -13, /* memlevel */ 6, 0);
  got = ZBSIZ;

  while (!VFSFileEOF(ifd) && got == ZBSIZ) {
    VFSFileRead(ifd, ZBSIZ, obuf, &got);
    if( !got )
      break;

    crc32val = crc32(crc32val, obuf, got);
    total += got;
    r.extent.x = 160 * total / itotal;
    WinDrawRectangle(&r, 0);

    gzipit.next_in = obuf;
    gzipit.avail_in = got;

    while (gzipit.avail_in || got != ZBSIZ) {
      isav = deflate(&gzipit, got == ZBSIZ ? 0 : Z_FINISH);
      if( gzipit.avail_out == BSIZ ) /* no bytes added */
	break;
      VFSFileWrite(outf, BSIZ - gzipit.avail_out, ibuf, NULL);
      gzipit.avail_out = BSIZ;
      gzipit.next_out = ibuf;
    }

  }

  isav = deflate(&gzipit, Z_FINISH);
  VFSFileWrite(outf, BSIZ - gzipit.avail_out, ibuf, NULL);

  deflateEnd(&gzipit);

  memcpy(ibuf,&crc32val,4);
  itotal = LG(ibuf);
  VFSFileWrite(outf, 4, &itotal, NULL);
  memcpy(ibuf,&total,4);
  itotal = LG(ibuf);
  VFSFileWrite(outf, 4, &itotal, NULL);

  return 0;
}
