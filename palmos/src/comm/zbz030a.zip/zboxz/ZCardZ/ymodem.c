#include <PalmOS.h>
#include <SerialMgrOld.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include "zboxz.h"

typedef unsigned long size_t;

#include "stringil.h"

#define SOH (1)
#define STX (2)
#define EOT (4)
#define ACK (6)
#define NAK (0x15)
#define CAN (0x18)
#define EoF (26)

/***************************************************************************/

unsigned short crctab[256] = {
  0x0000, 0x1021, 0x2042, 0x3063, 0x4084, 0x50A5, 0x60C6, 0x70E7,
  0x8108, 0x9129, 0xA14A, 0xB16B, 0xC18C, 0xD1AD, 0xE1CE, 0xF1EF,
  0x1231, 0x0210, 0x3273, 0x2252, 0x52B5, 0x4294, 0x72F7, 0x62D6,
  0x9339, 0x8318, 0xB37B, 0xA35A, 0xD3BD, 0xC39C, 0xF3FF, 0xE3DE,
  0x2462, 0x3443, 0x0420, 0x1401, 0x64E6, 0x74C7, 0x44A4, 0x5485,
  0xA56A, 0xB54B, 0x8528, 0x9509, 0xE5EE, 0xF5CF, 0xC5AC, 0xD58D,
  0x3653, 0x2672, 0x1611, 0x0630, 0x76D7, 0x66F6, 0x5695, 0x46B4,
  0xB75B, 0xA77A, 0x9719, 0x8738, 0xF7DF, 0xE7FE, 0xD79D, 0xC7BC,
  0x48C4, 0x58E5, 0x6886, 0x78A7, 0x0840, 0x1861, 0x2802, 0x3823,
  0xC9CC, 0xD9ED, 0xE98E, 0xF9AF, 0x8948, 0x9969, 0xA90A, 0xB92B,
  0x5AF5, 0x4AD4, 0x7AB7, 0x6A96, 0x1A71, 0x0A50, 0x3A33, 0x2A12,
  0xDBFD, 0xCBDC, 0xFBBF, 0xEB9E, 0x9B79, 0x8B58, 0xBB3B, 0xAB1A,
  0x6CA6, 0x7C87, 0x4CE4, 0x5CC5, 0x2C22, 0x3C03, 0x0C60, 0x1C41,
  0xEDAE, 0xFD8F, 0xCDEC, 0xDDCD, 0xAD2A, 0xBD0B, 0x8D68, 0x9D49,
  0x7E97, 0x6EB6, 0x5ED5, 0x4EF4, 0x3E13, 0x2E32, 0x1E51, 0x0E70,
  0xFF9F, 0xEFBE, 0xDFDD, 0xCFFC, 0xBF1B, 0xAF3A, 0x9F59, 0x8F78,
  0x9188, 0x81A9, 0xB1CA, 0xA1EB, 0xD10C, 0xC12D, 0xF14E, 0xE16F,
  0x1080, 0x00A1, 0x30C2, 0x20E3, 0x5004, 0x4025, 0x7046, 0x6067,
  0x83B9, 0x9398, 0xA3FB, 0xB3DA, 0xC33D, 0xD31C, 0xE37F, 0xF35E,
  0x02B1, 0x1290, 0x22F3, 0x32D2, 0x4235, 0x5214, 0x6277, 0x7256,
  0xB5EA, 0xA5CB, 0x95A8, 0x8589, 0xF56E, 0xE54F, 0xD52C, 0xC50D,
  0x34E2, 0x24C3, 0x14A0, 0x0481, 0x7466, 0x6447, 0x5424, 0x4405,
  0xA7DB, 0xB7FA, 0x8799, 0x97B8, 0xE75F, 0xF77E, 0xC71D, 0xD73C,
  0x26D3, 0x36F2, 0x0691, 0x16B0, 0x6657, 0x7676, 0x4615, 0x5634,
  0xD94C, 0xC96D, 0xF90E, 0xE92F, 0x99C8, 0x89E9, 0xB98A, 0xA9AB,
  0x5844, 0x4865, 0x7806, 0x6827, 0x18C0, 0x08E1, 0x3882, 0x28A3,
  0xCB7D, 0xDB5C, 0xEB3F, 0xFB1E, 0x8BF9, 0x9BD8, 0xABBB, 0xBB9A,
  0x4A75, 0x5A54, 0x6A37, 0x7A16, 0x0AF1, 0x1AD0, 0x2AB3, 0x3A92,
  0xFD2E, 0xED0F, 0xDD6C, 0xCD4D, 0xBDAA, 0xAD8B, 0x9DE8, 0x8DC9,
  0x7C26, 0x6C07, 0x5C64, 0x4C45, 0x3CA2, 0x2C83, 0x1CE0, 0x0CC1,
  0xEF1F, 0xFF3E, 0xCF5D, 0xDF7C, 0xAF9B, 0xBFBA, 0x8FD9, 0x9FF8,
  0x6E17, 0x7E36, 0x4E55, 0x5E74, 0x2E93, 0x3EB2, 0x0ED1, 0x1EF0
};

void docrc(unsigned char *str)
{
  int len;
  unsigned short crc, *ct;

  len = str[0] == SOH ? 128 : 1024;
  str += 3;
  crc = 0;
  ct = crctab;
  while (len--)
    crc = ct[(crc >> 8) ^ *str++] ^ crc << 8;

  *str++ = crc >> 8;
  *str = crc;
}

int testcrc(unsigned char *str)
{
  int len;
  unsigned short crc, *ct;

  if (str[0] != SOH && str[0] != STX)
    return 1;
  if (str[1] + str[2] != 255)
    return 1;

  len = str[0] == SOH ? 128 : 1024;
  str += 3;
  crc = 0;
  ct = crctab;
  while (len--)
    crc = ct[(crc >> 8) ^ *str++] ^ crc << 8;

  if (*str++ != crc >> 8)
    return 1;
  if (*str != (crc & 0xff))
    return 1;
  return 0;
}

/***************************************************************************/

int checkevent()
{
  EventType event;
  //  Err err;

  for (;;) {
    EvtGetEvent(&event, 0);
    if (event.eType == nilEvent)
      return 0;
    if (event.eType == penDownEvent)
      return 1;
  }
}

/***************************************************************************/

UInt16 SerL = 0;

int getone(int timeout)
{
  unsigned char buf;
  UInt32 n;

  SerClearErr(SerL);
  EvtResetAutoOffTimer();

  if (checkevent())
    return -2;

  SerReceiveWait(SerL, 1, timeout * 100);
  SerReceiveCheck(SerL, &n);
  if (!n)
    return -1;
  SerReceive10(SerL, &buf, 1, 0);
  return buf;
}

/***************************************************************************/

int getbuf(unsigned char *buf, int len, int tmo)
{
  UInt32 n, cnt;

  // get timer and compare instead of this...
  cnt = tmo * 100;

  SerClearErr(SerL);
  EvtResetAutoOffTimer();

  while (len) {
    if (checkevent())
      return len;
    SerReceiveCheck(SerL, &n);
    if (!n) {
      SysTaskDelay(5);
      cnt -= 5;
      if (!cnt)
        return len;
      continue;
    }

    if (n > len)
      n = len;
    SerReceive10(SerL, buf, n, 0);

    len -= n;
    buf += n;

  }
  return 0;
}

void sendbuf(char *buf, int len)
{
  if (SerSend10(SerL, buf, len))
    SerClearErr(SerL);
}

void sendchar(char ch)
{
  if (SerSend10(SerL, &ch, 1))
    SerClearErr(SerL);
}

#define getmo(tmo) {i = getone(tmo); if (i == -2 || i == CAN) { sendchar(CAN); closerial(); return; } }
#define waitack(siz) do { sendbuf(ibuf, siz); getmo(10); } while (i != ACK);

/***************************************************************************/

// Should do a dialog, but when I move to the connection manager it won't matter
void *sbuf;
unsigned long baud;

void setserial()
{
  SerSettingsType serSettings;

  if (SerL)
    return;
  SysLibFind("Serial Library", &SerL);
  SerOpen(SerL, 0, baud);
  SerGetSettings(SerL, &serSettings);
  serSettings.flags = serSettingsFlagBitsPerChar8 | serSettingsFlagStopBits1;
  SerSetSettings(SerL, &serSettings);
  SerSetReceiveBuffer(SerL, sbuf = MemPtrNew(4096), 4096);
}

void closerial()
{
  SerClose(SerL);
  SerL = 0;
  MemPtrFree(sbuf);
}

extern unsigned char ibuf[];

/***************************************************************************/
int domodem()
{
  FormPtr ff;
  FieldPtr textf;
  MemHandle thand;
  char *c, *d;
  int k;

  do {
    if (!(ff = FrmInitForm(fymsend)))
      return 0;

    thand = MemHandleNew(256);
    strcpy(MemHandleLock(thand), "ATA");
    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
    FldSetTextHandle(textf, thand);
    FrmSetFocus(ff, FrmGetObjectIndex(ff, bstring));

    k = FrmDoDialog(ff);
    if (k == bexit) {
      FrmDeleteForm(ff);
      return 1;
    }

    textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
    thand = FldGetTextHandle(textf);
    c = MemHandleLock(thand);
    d = c;
    while( *d ) {
      if( *d == '\n' )
	*d = '\r';
      d++;
    }
    sendbuf(c, strlen(c));
    
    MemHandleUnlock(thand);
    FrmDeleteForm(ff);
  } while (k != bmcont);

  return 0;
}

void ysend(FileRef fd, char *fname)
{
  int i;
  unsigned long flen, xlen, fln1;

  WinEraseWindow();
  setserial();
  WinDrawChars("YModem Starting", 15, 0, 0);

  if (domodem()) {
    closerial();
    return;
  }

  ibuf[0] = SOH;
  memset(&ibuf[1], 0, 130);
  ibuf[2] = 255;

  if (fname) {
    WinDrawChars(fname, strlen(fname), 0, 15);
    strcpy(&ibuf[3], fname);
    for (i = 3; ibuf[i]; i++)
      if (ibuf[i] == ' ')
        ibuf[i] = '_';
    ibuf[i++] = 0;
    VFSFileTell(fd, &flen);
    StrIToA(&ibuf[i], flen);
  }

  docrc(ibuf);
  WinDrawChars("Startup", 7, 0, 30);

  do {
    getmo(5);
  } while (i != 'C');
  waitack(133);
  if (!fname) {                 /* last file sent */
    closerial();
    return;
  }

  WinDrawChars("File", 4, 0, 45);

  xlen = flen;
  while (flen) {
    ibuf[1]++;
    ibuf[2]--;
    memset(&ibuf[3], EoF, 128);

    /////progress bar
    StrIToA(&ibuf[3], flen);
    strcat(&ibuf[3], "   ");
    WinDrawChars(&ibuf[3], strlen(&ibuf[3]), 0, 60);

    VFSFileRead(fd, flen > 128 ? 128 : flen, &ibuf[3], &fln1);
    flen -= fln1;
    docrc(ibuf);
    waitack(133);
  }

  ibuf[0] = EOT;
  waitack(1);
  WinDrawChars("Exit", 4, 0, 75);
}

/***************************************************************************/
extern char name[];
extern char tempath[];
extern UInt16 curvol;

void rrec(char *c)
{
  unsigned long n, tot;
  FileRef fd;

  strcpy(name,tempath);
  strcat(name,c);
  VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &fd);

  setserial();
  WinDrawChars("Receiving Raw:", 13, 0, 0);

  if (domodem()) {
    closerial();
    return;
  }

  tot = 0;
  for (;;) {
    SerClearErr(SerL);
    EvtResetAutoOffTimer();
    if (checkevent())
      break;
    SerReceiveWait(SerL, 1, 100);
    n = 1024;
    while (n > 1023) {
      SerReceiveCheck(SerL, &n);
      if (!n)
        break;
      SerReceive10(SerL, &ibuf, n, 0);
      VFSFileWrite(fd, n, ibuf, NULL);
      tot += n;
    }
    StrIToA(ibuf, tot);
    WinDrawChars(ibuf, strlen(ibuf), 0, 75);
  }
  closerial();
}

/***************************************************************************/

void rsend(FileRef fd)
{
  unsigned long flen, xlen, ilen;

  setserial();
  WinDrawChars("Sending Raw:", 12, 0, 0);
  if (domodem()) {
    closerial();
    return;
  }
  VFSFileTell(fd, &flen);
  xlen = flen;
  while (flen) {
    /////progress bar
    StrIToA(&ibuf[3], flen);
    strcat(&ibuf[3], "   ");
    WinDrawChars(&ibuf[3], strlen(&ibuf[3]), 0, 75);
    ilen = VFSFileRead(fd,  flen > 128 ? 128 : flen,&ibuf[3], NULL);
    flen -= ilen;
    sendbuf(ibuf, ilen);

  }
  closerial();
}

/***************************************************************************/

int nextblk(int schar, unsigned char seq)
{
  int i;
  for (;;) {
    i = getone(10);
    if (i != SOH && i != STX) {
      if (i == -2) {
        sendchar(CAN);
        return 2;
      }
      if (i == CAN)
        return 2;
      if (i == EOT) {
        sendchar(ACK);
        return 1;
      }
      if (i == -1)
        sendchar(schar);
      continue;
    }
    ibuf[0] = i;
    getbuf(&ibuf[1], i == SOH ? 132 : 1028, 10);

    if (ibuf[1] == seq && !testcrc(ibuf)) {
      sendchar(ACK);
      return 0;
    }
    sendchar(schar);
  }
}

int yrec()
{
  FileRef fd;
  unsigned long ilen, tlen, hlen;
  int i;
  unsigned char seq;
  char *c, bchr;

  WinEraseWindow();
  setserial();

  if (domodem()) {
    closerial();
    return 1;
  }

  while (getone(0) >= 0);
  for (;;) {

    WinEraseWindow();
    seq = 0;
    WinDrawChars("Startup", 7, 0, 0);

    bchr = 'C';
    seq = 0;
    sendchar(bchr);

    if (nextblk(bchr, seq)) {
      closerial();
      return 1;
    }

    seq++;
    c = &ibuf[3];
    WinDrawChars(c, strlen(c), 0, 15);
    if (!*c) {
      WinDrawChars("Normal End", 10, 80, 15);
      SysTaskDelay(100);
      break;
    }

    strcpy(name,tempath);
    strcat(name,c);
    VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &fd);

    c += strlen(c) + 1;
    tlen = StrAToI(c);
    WinDrawChars(c, strlen(c), 0, 30);
    ilen = 0;

    sendchar(bchr);
    WinDrawChars("BlockLoop", 9, 0, 60);

    ilen = tlen;
    for (;;) {
      i = nextblk(bchr, seq);
      if (i)
        VFSFileClose(fd);
      if (i == 1)
        break;
      else if (i == 2) {
        closerial();
        return 1;
      }
      seq++;
      bchr = NAK;
      hlen = ibuf[0] == SOH ? 128 : 1024;
      if (hlen > ilen)
        hlen = ilen;
      c = &ibuf[3];
      VFSFileWrite(fd, hlen, c, NULL);
      ilen -= hlen;
      StrIToA(c, ilen);
      strcat(c, "    ");
      WinDrawChars(c, strlen(c), 0, 45);
    }
    WinDrawChars("File Done", 9, 0, 75);
  }
  closerial();
  return 0;
}
