/* based on funzip.c from unzip 5.40 */

#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

extern char ibuf[], tempath[], savepath[];
extern char name[];
extern UInt16 curvol,savevol;

int untardir(FileRef  fd, char *dir, long int *loc)
{
  char *c;
  unsigned long total, disp=0, i=0;
  int max;

  max = 0;
  DmSet(dir,0,2,0);

  VFSFileSeek(fd, vfsOriginBeginning, 0);

  VFSFileRead(fd,  512,ibuf, NULL);
  if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
    return 0;

  VFSFileSeek(fd, vfsOriginBeginning, 0);

  for (;;) {
    VFSFileRead(fd,  512,ibuf, NULL);

    if (ibuf[0] == 0)
      VFSFileRead(fd, 512, ibuf,  NULL);

    if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
      return max;

    VFSFileTell(fd,&total);
    total -= 512;
    DmWrite(loc,(i++)*4,&total,4);

    DmWrite(dir,disp,"    ",4);
    DmWrite(dir,disp+4,ibuf,strlen(ibuf)+1);
    disp += 4+strlen(ibuf)+1;
    DmSet(dir,disp,1,0);

    c = &ibuf[124];
    while (*c == ' ')
      c++;
    total = 0;

    do {
      total = (total << 3) + *c++ - '0';
    } while (*c != ' ');

    // round to the block size
    total += 512;
    total &= ~511;
    VFSFileSeek(fd, vfsOriginCurrent, total);
    max++;
  }
}

int untar(FileRef fd, long int loc, int local)
{
  char *c;
  unsigned long total, itot;
  FileRef ofd;
  RectangleType r;
  UInt16 ivol;

  VFSFileSeek(fd, vfsOriginCurrent, 0);

  VFSFileRead(fd,512,ibuf, NULL);
  if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
    return -1;

  VFSFileSeek(fd, vfsOriginBeginning,loc == -1? 0: loc);

  for (;;) {
    VFSFileRead(fd,512,ibuf,  NULL);

    if (ibuf[0] == 0)
      VFSFileRead(fd, 512,ibuf, NULL);

    if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
      return 0;

    r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
    WinEraseRectangle(&r, 0);

    r.topLeft.x = 0, r.topLeft.y = 30, r.extent.x = 160, r.extent.y = 15;

    c = &ibuf[124];
    while (*c == ' ')
      c++;
    total = 0;

    do {
      total = (total << 3) + *c++ - '0';
    } while (*c != ' ');


    if( local )
      ivol = curvol, strcpy(name,tempath);
    else
      ivol = savevol, strcpy(name,savepath);

    strcat(name,ibuf);

    if( VFSFileOpen(ivol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd) ) {
      c = &name[1];
      while( *c ) {
	while( *c && *c != '/' )
	  c++;
	if( *c == '/' ) {
	  *c = 0;
	  VFSDirCreate(curvol, name);
	  *c++ = '/';
	}
      }
      VFSFileOpen(ivol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &ofd);
    }

    StrIToA(ibuf,total);
    strcat(ibuf,"     ");
    WinDrawChars(ibuf,strlen(ibuf),120,0);

    itot = total;
    while (total) {

      VFSFileRead(fd, BSIZ, ibuf, NULL);
      VFSFileWrite(ofd,  total > BSIZ ? BSIZ : total, ibuf, NULL);
      total -= total > BSIZ ? BSIZ : total;
      r.extent.x = 160 - (160 * total / itot);
      WinDrawRectangle(&r, 0);
    }
    VFSFileClose(ofd);
    EvtResetAutoOffTimer();

    if( loc != -1 )
      break;

  }
  return 0;

}
