#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <ExgMgr.h>
#include <System/FileStream.h>
#include <System/SysEvtMgr.h>
#include "zboxz.h"

#include <Unix/sys_types.h>

#include "stringil.h"

extern char name[];
extern char tempath[];
extern UInt16 curvol;

extern int maxrow;
extern unsigned char sels[256];
extern int bulk;
extern char ibuf[];
extern unsigned char prefs[];
extern char **filelp;
extern RectangleType infoico;
extern int selection;

int basehand(EventPtr event);
void scandbs();
int MakeDoc(char *name, FileRef fd);
int MakeDatabase(FileRef fd);
extern void godir();
extern void swapdir();
extern UInt16 dirlevel;

/* **************************************************************************** */
extern Err SendPalmDB(ExgDBWriteProcPtr wrtit, void *fd, const char *nameP,
                      LocalID lid, UInt16 cardno);

Err WriteDBData(const void *dataP, ULong * sizeP, void *userDataP)
{
  Err err;

  *sizeP = ExgSend((ExgSocketPtr) userDataP, (void *) dataP, *sizeP, &err);
  return err;
}

Err FileDBW(const void *dataP, ULong * sizeP, void *userDataP)
{
  Err err;

  *sizeP = FileWrite(userDataP, (void *) dataP, 1, *sizeP, &err);
  return err;
}

/* **************************************************************************** */

/* handle get string modal dialog */
static char retstr[256];
static int dodlg(int id)
{
  FormPtr ff;
  FieldPtr textf;
  VoidHand thand;
  int k;

  if (!(ff = FrmInitForm(id)))
    return 0;

  thand = MemHandleNew(256);
  strcpy(MemHandleLock(thand), retstr);
  MemHandleUnlock(thand);
  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  FldSetTextHandle(textf, (Handle) thand);
  FrmSetFocus(ff, FrmGetObjectIndex(ff, bstring));

  k = FrmDoDialog(ff);
  retstr[0] = 0;

  if (k != bok) {
    FrmDeleteForm(ff);
    return 0;
  }

  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  thand = (VoidHand) FldGetTextHandle(textf);

  k = MemHandleSize(thand);
  strncpy(retstr, MemHandleLock(thand), k);
  retstr[k] = 0;

  MemHandleUnlock(thand);
  FrmDeleteForm(ff);

  return 1;
}

/* **************************************************************************** */
void ysend(FileRef fd, char *fname);
void rsend(FileRef fd);
void rrec(char *);
void yrec(void);

extern unsigned long baud;

Boolean CommH(EventPtr event)
{
  FileRef fd;
  int eid;
  char *x, name[256];

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == byrec) {
    yrec();
    scandbs();
    FrmGotoForm(commform);
    return 1;
  } else if (eid == bbaud) {
    FormPtr ff;
    FieldPtr textf;
    VoidHand thand;
    int k, bx;

    if (!(ff = FrmInitForm(bbaud)))
      return 0;

    thand = MemHandleNew(10);
    StrIToA(MemHandleLock(thand), baud);
    MemHandleUnlock(thand);
    bx = FrmGetObjectIndex(ff, bbox);

    textf = FrmGetObjectPtr(ff, bx);
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(ff, bx);
    k = FrmDoDialog(ff);
    if (k == bok) {
      textf = FrmGetObjectPtr(ff, bx);
      thand = (VoidHand) FldGetTextHandle(textf);
      baud = StrAToI(MemHandleLock(thand));
      MemHandleUnlock(thand);
      FrmDeleteForm(ff);
    }

    FrmGotoForm(commform);
    return 1;
  } else if (eid == brrec) {
  } else if (eid == bexit) {
  }

  switch( eid ) {
  case brrec:
    strcpy(retstr, "RawSer");
    StrIToH(&retstr[6], TimGetSeconds());
    if (dodlg(ffname))
      rrec(retstr);
    return 1;
  case bexit:
    FrmGotoForm(mainform);
    return 1;
  case bgodir:
    godir();
    return 1;
  case bswap:
    swapdir();
    return 1;
  }

  if (selection == -1)
    return 1;

  if (eid == bfsnd) {
    LocalID lid;

    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) +strlen(tempath)+ 3);
    x[0]='s';
    x[1]=curvol;
    strcpy(&x[2],tempath);
    strcat(&x[2], filelp[selection] + SORTPREFIX);

    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  }

  strcpy(name,tempath);
  strcat(name,filelp[selection]+SORTPREFIX);
  VFSFileOpen(curvol, name, vfsModeRead , &fd);

  WinEraseWindow();

  switch (eid) {
  case bysend:
    ysend(fd, filelp[selection] + SORTPREFIX);
    ysend(NULL, NULL);
    break;

  case brsend:
    rsend(fd);
    break;
  }
  VFSFileClose(fd);
  scandbs();
  FrmGotoForm(commform);
  return 1;

}

/* **************************************************************************** */

Boolean ViewH(EventPtr event)
{
  LocalID lid;
  char *x;
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  switch (eid) {
  case bexit:
    FrmGotoForm(mainform);
    return 1;
  case bswap:
    swapdir();
    return 1;
  case bgodir:
    godir();
    return 1;
  }

  if (selection == -1)
    return 1;

  switch (eid) {

  case bvpng:

    lid = DmFindDatabase(0, "PiNGer");
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + strlen(tempath) + 3);
    x[0]=0;
    x[1]=curvol;
    strcpy(&x[2],tempath);
    strcat(&x[2], filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case bvfax:

    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) +strlen(tempath)+ 3);
    x[0]='v';
    x[1]=curvol;
    strcat(&x[2],tempath);
    strcat(&x[2], filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case bmidi:

    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + strlen(tempath) + 3);
    x[0]=0;
    x[1]=curvol;
    strcpy(&x[2],tempath);
    strcat(&x[2], filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "MusicBox");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  default:
    return 0;
  }
  FrmAlert(2200);
  return 1;
}

/* **************************************************************************** */

Boolean InstH(EventPtr event)
{
  Word n;
  FileRef fd;

  int eid;
  char *x;
  LocalID lid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  switch (eid) {

  case bclipto:
    {
    VoidHand clip;

    clip = ClipboardGetItem(clipboardText, &n);
    if (!clip)
      return 1;                 //+++ ERROR: Nothing to paste...

    StrIToH(retstr, TimGetSeconds());
    strcpy(&retstr[8],".clp");
    if (!dodlg(ffname))
      return 1;

    strcpy(name,tempath);
    strcat(name,retstr);
    VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &fd);
    VFSFileWrite(fd, n, MemHandleLock(clip), NULL);
    MemHandleUnlock(clip);
    VFSFileClose(fd);
    scandbs();
    FrmGotoForm(instform);
    return 1;
  }

  case bexit:
    FrmGotoForm(mainform);
    return 1;
  case bswap:
    swapdir();
    return 1;
  case bgodir:
    godir();
    return 1;
  }

  if (selection == -1)
    return 1;

  switch (eid) {

  case binst:
    {
      char *c;
      FileRef fd;
      FileHand tfd;
      UInt32 len;

      c = filelp[selection]+SORTPREFIX;
      strcpy(name,tempath);
      strcat(name,c);

      VFSFileOpen(curvol, name, vfsModeRead , &fd);
      tfd = FileOpen(0, c, 'DATA', 'BOXR', fileModeReadWrite, NULL);
      len = 1;
      while( len ) {
	if( VFSFileRead(fd, BSIZ, ibuf, &len) )
	  break;
	FileWrite(tfd, ibuf, 1, len, NULL);
      }
      FileClose(tfd);
      VFSFileClose(fd);
    }
    selection = -1;
    return 1;

  case btofax:

    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) +strlen(tempath) + 3);
    x[0]='c';
    x[1]=curvol;
    strcpy(&x[2],tempath);
    strcat(&x[2], filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case btodoc:
    strcpy(name, tempath);
    strcat(name, filelp[selection] + SORTPREFIX);
    VFSFileOpen(curvol, name, vfsModeRead , &fd);

    WinEraseWindow();

    strcat(name, ".box");
    MakeDoc(name, fd);
    VFSFileClose(fd);

    scandbs();
    FrmGotoForm(instform);
    return 1;

  case binstall:
    strcpy(name, tempath);
    strcat(name, filelp[selection] + SORTPREFIX);
    VFSFileOpen(curvol, name, vfsModeRead , &fd);

    WinEraseWindow();
    MakeDatabase(fd);
    VFSFileClose(fd);

    scandbs();
    FrmGotoForm(instform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */
void mkdt(char *c, UInt32 secs) {
  DateTimeType dtbuf;

  TimSecondsToDateTime(secs, &dtbuf);
  StrIToA(ibuf, dtbuf.year);
  strcat(&ibuf[strlen(ibuf)], "-");
  if (dtbuf.month < 10)
    strcat(ibuf, "0");
  StrIToA(&ibuf[strlen(ibuf)], dtbuf.month);
  strcat(ibuf, "-");
  if (dtbuf.day < 10)
    strcat(ibuf, "0");
  StrIToA(&ibuf[strlen(ibuf)], dtbuf.day);
  strcat(ibuf, " ");
  if (dtbuf.hour < 10)
    strcat(ibuf, "0");
  StrIToA(&ibuf[strlen(ibuf)], dtbuf.hour);
  strcat(ibuf, ":");
  if (dtbuf.minute < 10)
    strcat(ibuf, "0");
  StrIToA(&ibuf[strlen(ibuf)], dtbuf.minute);
  strcat(ibuf, ":");
  if (dtbuf.second < 10)
    strcat(ibuf, "0");
  StrIToA(&ibuf[strlen(ibuf)], dtbuf.second);
  strcat(ibuf,c);

}

Boolean InfoH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 tlen, attr,cdate,mdate,adate;
  FileRef fd;
  int eid;
  char nbuf[16], *c;

  if (event->eType == frmOpenEvent) {
    WinEraseWindow();

    frm = FrmGetActiveForm();

    thand = MemHandleNew(64);
    tptr = MemHandleLock(thand);

    strcpy(tptr, filelp[selection] + SORTPREFIX);
    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);

    VFSFileOpen(curvol, name, vfsModeRead , &fd);
    VFSFileSize(fd, &tlen);
    VFSFileGetAttributes(fd,&attr);
    VFSFileGetDate(fd,vfsFileDateCreated, &cdate);
    VFSFileGetDate(fd,vfsFileDateModified, &mdate);
    VFSFileGetDate(fd,vfsFileDateAccessed, &adate);
    VFSFileClose(fd);

    MemHandleUnlock(thand);

    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));

    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup)),
                attr & vfsFileAttrArchive);
    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bhidden)),
                attr & vfsFileAttrHidden);
    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, breadon)),
                attr & vfsFileAttrReadOnly);
    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bsystem)),
                attr & vfsFileAttrSystem);

    FrmDrawForm(frm);
    WinDrawChars("Size:", 5, 5, 45);
    StrIToA(nbuf, tlen);
    WinDrawChars(nbuf, strlen(nbuf), 25, 45);

    if( attr & vfsFileAttrDirectory)
      WinDrawChars("[Dir]", 5, 5, 108);
    if( attr & vfsFileAttrLink)
      WinDrawChars("[Lnk]", 5, 35, 108);
    if( attr & vfsFileAttrLink)
      WinDrawChars("[Vol]", 5, 65, 108);

    mkdt("-CR",cdate);
    WinDrawChars(ibuf,strlen(ibuf),60,72);
    mkdt("-WR",mdate);
    WinDrawChars(ibuf,strlen(ibuf),60,84);
    mkdt("-AC",adate);
    WinDrawChars(ibuf,strlen(ibuf),60,96);

    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);

    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);

    VFSFileOpen(curvol, name, vfsModeRead | vfsModeWrite , &fd);
    VFSFileGetAttributes(fd,&attr);
    cdate = attr;
    attr &= ~(vfsFileAttrReadOnly|vfsFileAttrHidden|vfsFileAttrSystem|vfsFileAttrArchive);
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup))))
      attr |= vfsFileAttrArchive;
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, breadon))))
      attr |= vfsFileAttrReadOnly;
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bhidden))))
      attr |= vfsFileAttrHidden;
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bsystem))))
      attr |= vfsFileAttrSystem;
    if( attr != cdate )
      VFSFileSetAttributes(fd,attr);
    VFSFileClose(fd);

// will fail if not renamed , or if new name would collide - need to
// display error msg in latter case.
    c = MemHandleLock(thand);

    if (strcmp(c, filelp[selection]+SORTPREFIX)) {
      strcpy(name,tempath);
      strcat(name,filelp[selection]+SORTPREFIX);
      if( c[strlen(c)-1] == '/' )
	c[strlen(c)-1] = 0;
      VFSFileRename(curvol,name,c);
    }

    MemHandleUnlock(thand);

    // Fallthrough
  case bexit:
    scandbs();
    FrmGotoForm(fileform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

static int beambox(int i)
{
  VoidPtr px;
  Word err;
  long unsigned int xcnt, outhis, tlen;
  ExgSocketType exgSocket;
  FileRef fd;
  UInt32 len;

  strcpy(name,tempath);
  strcat(name,filelp[i]+SORTPREFIX);
  VFSFileOpen(curvol, name, vfsModeRead , &fd);
  VFSFileSize(fd, &len);

  MemSet(&exgSocket, sizeof(exgSocket), 0);
  exgSocket.description = filelp[i] + SORTPREFIX;
  exgSocket.name = filelp[i] + SORTPREFIX;
  exgSocket.length = len;
  exgSocket.target = 'BOXR';

  if (!ExgPut(&exgSocket)) {
    xcnt = 0;
    while (xcnt < len) {
      VFSFileRead(fd, BSIZ, ibuf, &tlen);
      xcnt += tlen;
      px = ibuf;
      while (tlen) {
        outhis = ExgSend(&exgSocket, px, tlen, &err);
        if (err)
          break;
        tlen -= outhis;
        px += outhis;
        EvtResetAutoOffTimer();
      }
    }
    VFSFileClose(fd);
    EvtResetAutoOffTimer();
    ExgDisconnect(&exgSocket, err);
  }
  SysTaskDelay(200);
  return err;
}

void ronamatic(void)
{
  if (!bulk) {
    if (beambox(selection))
      FrmAlert(2100);
  } else {
    int i;
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if (beambox(i))
        break;
    }
  }
}

/* ************************************************************************ */

Boolean FileH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  switch (eid) {
  case binst:
    selection = -1;
    FrmGotoForm(mkdirform);
    return 1;
  case bexit:
    FrmGotoForm(mainform);
    return 1;
  case bswap:
    swapdir();
    return 1;
  case bgodir:
    godir();
    return 1;
  case bbulk:
    selection = -1;
    FrmGotoForm(bulkform);
    return 1;
  }

  if (selection == -1 || !dirlevel)
    return 1;

  switch (eid) {
  case bcpy:
    if(filelp[selection][0])
      FrmGotoForm(copyform);
    return 1;

  case binfo:
    FrmGotoForm(infoform);
    return 1;

  case bdelete:
    if(filelp[selection][0])
      FrmGotoForm(copyform);
    if (prefs[0] && FrmAlert(2000))
      return 1;

    strcpy(name,tempath);
    strcat(name,filelp[selection]+SORTPREFIX);
    VFSFileDelete(curvol, name);
    selection = -1;
    scandbs();
    FrmGotoForm(fileform);
    return 1;

  case bbeam:
    if(filelp[selection][0])
      FrmGotoForm(copyform);
    if (beambox(selection))
      FrmAlert(2100);
    return 1;

  default:
    return 0;
  }

}

/* **************************************************************************** */
Boolean BulkH(EventPtr event)
{
  int eid;
  int i;
  char *c;
  FileRef fd;
  FileHand tfd;
  UInt32 len;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;
  }
  switch (eid) {
  case ball:
    for (i = 0; i < maxrow; i++)
      if( filelp[i][0])
	sels[i >> 3] ^= (1 << (i & 7));

    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
    return 1;

  case bnone:
    memset(sels, 0, 256);
    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
    return 1;

  case bysend:
    for (i = 0; i < maxrow; i++) {

      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if( !filelp[i][0] )
	continue;
      strcpy(name,tempath);
      strcat(name,filelp[i]+SORTPREFIX);
      VFSFileOpen(curvol, name, vfsModeRead , &fd);
      ysend(fd, filelp[i] + SORTPREFIX);
    }
    ysend(NULL, NULL);
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bbeam:
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if( !filelp[i][0] )
	continue;
      if (beambox(i))
        break;
    }
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bdelete:
    if (prefs[0] && FrmAlert(2000))
      return 1;
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if( !filelp[i][0] )
	continue;
      c = filelp[i]+SORTPREFIX;
      strcpy(name,tempath);
      strcat(name,c);
      WinEraseWindow();
      WinDrawChars(c, strlen(c), 0, 15);
      VFSFileDelete(curvol, name);
    }
    selection = -1;
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bbackup:
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if( !filelp[i][0] )
	continue;
      c = filelp[i]+SORTPREFIX;
      strcpy(name,tempath);
      strcat(name,c);
      WinEraseWindow();
      WinDrawChars(c, strlen(c), 0, 15);

      VFSFileOpen(curvol, name, vfsModeRead , &fd);
      tfd = FileOpen(0, c, 'DATA', 'BOXR', fileModeReadWrite, NULL);
      len = 1;
      while( len ) {
	if( VFSFileRead(fd, BSIZ, ibuf, &len) )
	  break;
	FileWrite(tfd, ibuf, 1, len, NULL);
      }
      FileClose(tfd);
      VFSFileClose(fd);
    }
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case binst:
    {
      FileRef fd;
      char *c;

      for (i = 0; i < maxrow; i++) {
        if (!(sels[i >> 3] & (1 << (i & 7))))
          continue;
	if( !filelp[i][0] )
	  continue;
        c = filelp[i] + SORTPREFIX;
        WinEraseWindow();
        WinDrawChars(c, strlen(c), 0, 15);

	strcpy(name,tempath);
	strcat(name,c);
	VFSFileOpen(curvol, name, vfsModeRead , &fd);
        MakeDatabase(fd);
        VFSFileClose(fd);
      }
    }
    scandbs();
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;
  default:
    return 0;
  }
}

Boolean MkDirH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  int eid;

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();

    thand = MemHandleNew(64);
    tptr = MemHandleLock(thand);
    strcpy(tptr,"FOLDER.NEW");
    MemHandleUnlock(thand);

    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));
    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);
    return 0;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:

    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);
    tptr = MemHandleLock(thand);

    strcpy(name,tempath);
    strcat(name,tptr);
    MemHandleUnlock(thand);
    
    WinEraseWindow();

    VFSDirCreate(curvol, name);
    // FALLTHROUGH

  case bexit:
    scandbs();
    FrmGotoForm(fileform);
    return 1;

  default:
    return 0;
  }
}
