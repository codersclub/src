#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>

#include "stringil.h"

int compdoc(unsigned char *ibuf, int ilen, unsigned char *obuf, int level);

int MakeDoc(char *name, FileRef fd)
{
  VoidHand hand2;
  VoidPtr ptr2, ptr1;
  char xbuf[36];
  Err err;
  LocalID docid;
  DmOpenRef docdb;
  UInt32 length, count, cnt1;
  UInt16 nrecs, dbrec, l;
  RectangleType r;

  r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
  WinEraseRectangle(&r, 0);
  r.topLeft.y = 30, r.extent.y = 15;

  strcpy(xbuf, name);
  err = DmCreateDatabase(0, xbuf, 'REAd', 'TEXt', 0);

  if (err == dmErrAlreadyExists) {
    strcat(xbuf, "@");
    while (err == dmErrAlreadyExists) {
      xbuf[strlen(xbuf) - 1]++;
      err = DmCreateDatabase(0, xbuf, 'REAd', 'TEXt', 0);
    }
  }

  docid = DmFindDatabase(0, xbuf);
  docdb = DmOpenDatabase(0, docid, dmModeReadWrite);

  VFSFileTell(fd, &length);

  count = length;
  nrecs = 0;

  ptr1 = MemPtrNew(6144);

  while (count) {
    dbrec = 0xffff;
    l = count > 4096 ? 4096 : count;
    hand2 = DmNewRecord(docdb, &dbrec, l);
    ptr2 = MemHandleLock(hand2);
    VFSFileReadData(fd, l,  ptr2, 0, &cnt1);
    count -= cnt1;

    r.extent.x = 160 - (160 * count / length);
    WinDrawRectangle(&r, 0);
    WinDrawChars("Compress..",10,8,32);

    l = compdoc(ptr2,l,ptr1, 2);
    if( l )
      DmWrite(ptr2,0,ptr1,l);

    MemHandleUnlock(hand2);

    if( l )
      DmResizeRecord(docdb,dbrec,l);

    DmReleaseRecord(docdb, dbrec, 1);

  }

  MemPtrFree(ptr1);

  nrecs = dbrec + 1;

  dbrec = 0;
  hand2 = DmNewRecord(docdb, &dbrec, 16);
  ptr2 = MemHandleLock(hand2);
  memset(xbuf, 0, 16);
  xbuf[1] = 2;
  xbuf[10] = 0x10;
  DmWrite(ptr2, 0, xbuf, 16);
  DmWrite(ptr2, 4, &length, 4);
  DmWrite(ptr2, 8, &nrecs, 2);
  MemHandleUnlock(hand2);
  DmReleaseRecord(docdb, dbrec, 1);
  DmCloseDatabase(docdb);

  return 0;
}
