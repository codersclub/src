#define ffunc 1000
#define brec 1001
#define bcvt 1002
#define bcvtsnd 1003
#define ffname 1004
#define bstring 1005
#define fdial 1006
#define fring 1007

#define bcanc 1110
#define bok 1111
#define bman 1112
#define bnote 1113
