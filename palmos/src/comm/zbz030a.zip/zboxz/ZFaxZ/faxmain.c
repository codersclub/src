#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stringil.h"
#include "zfaxz.h"
#include <Extensions/ExpansionMgr/VFSMgr.h>

void cleanFAX();
void faxrec();
void faxsend(char *);
extern void faxdisp(char *cp);
extern char *faxcvt(char *);
extern char *cvtnote(void);

FileHand fd = 0;
FileRef fr = 0;
UInt16 cv;

unsigned long fread(void *buf, unsigned long size) {
unsigned long x;
  if( fr )
    VFSFileRead(fr,size,buf,&x);
  else
    x = FileRead(fd,buf,1,size,NULL);
  return x;
}

void fclose() {
  if( fr ) {
    VFSFileClose(fr);
    fr = 0;
  }
  else {
    FileClose(fd);
    fd = 0;
  }
}

int feof() {
  if( fr )
    return VFSFileEOF(fr);
  else
    return FileEOF(fd);
}

 void rewind() {
  if( fr )
    VFSFileSeek(fr,vfsOriginBeginning, 0);
  else
    FileSeek(fd,0,fileOriginBeginning);
}


UInt32 PilotMain(UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
  char *cp = NULL;
  FormPtr ff;
  int k;

  if (cmd != sysAppLaunchCmdOpenDB || !cmdPBP || !strlen(cmdPBP)) {

    if (cmd != sysAppLaunchCmdNormalLaunch)
      return 0;

    if (!(ff = FrmInitForm(ffunc)))
      return 0;
    k = FrmDoDialog(ff);
    FrmDeleteForm(ff);

    switch (k) {
    case brec:
      faxrec();
      return 0;
    case bnote:
      if ((cp = cvtnote()))
        faxsend(cp);
      return 0;
    case bcvt:
      faxcvt(NULL);
      return 0;
    case bcvtsnd:
      if ((cp = faxcvt(NULL)))
        faxsend(cp);
      return 0;
    case bcanc:
      return 0;
    }
  } else {

    cp = cmdPBP;
    switch (*cp) {
    case 'R':
      faxrec();
      return 0;
    case 'S':
    case 's':
      faxsend(cp);
      return 0;
    case 'V':
    case 'v':
      faxdisp(cp);
      return 0;
    case 'C':
    case 'c':
      faxcvt(cp);
      return 0;
    default:
      return 0;
    }
  }
  return 0;
}
