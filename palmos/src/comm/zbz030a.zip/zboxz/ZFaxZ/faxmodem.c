#include <PalmOS.h>
#include <SerialMgrOld.h>

typedef unsigned long size_t;
#include "stringil.h"

#include "zfaxz.h"
extern char retstr[256];
extern int dodlg(int id);

/***************************************************************************/
static int cancflg;
static int checkevent()
{
  EventType event;

  for (;;) {
    EvtGetEvent(&event, 0);
    if (event.eType == nilEvent)
      return 0;
    if (event.eType == penDownEvent || event.eType == keyDownEvent) {
      cancflg = 1;
      return 1;
    }
  }
}

/***************************************************************************/

static UInt16 FaxSerL;
static unsigned char *obuf, *ibuf;

Err err;

static int getstr(char *str, int timeout)
{
  UInt32 n, j, l;

  if( cancflg )
    return -2;

  SerClearErr(FaxSerL);
  EvtResetAutoOffTimer();

  memset(obuf, 0, 256);

  l = strlen(str);
  j = 0;

  for (;;) {
    if (checkevent())
      return -2;

    SerReceiveWait(FaxSerL, 1, timeout);
    SerReceiveCheck(FaxSerL, &n);
    if (!n)
      return -1;
    while( n-- ) {
      SerReceive(FaxSerL, &obuf[j], 1, 0, &err);
      j++;
      if (!strncmp("OK\r\n", &obuf[j - 4], 4))
	return 0;
      if (str && !strncmp(str, &obuf[j - l], l))
        return 1;
    }
  }
}

/***************************************************************************/
#define sendstr(buf) {if (SerSend(FaxSerL, buf, strlen(buf),&err)) SerClearErr(FaxSerL); SerSendFlush(FaxSerL);}

#define DLE (16)
#define ETX (3)

static void faxset()
{
  SerSettingsType serSettings;

  cancflg = 0;
  SysLibFind("Serial Library", &FaxSerL);
  SerOpen(FaxSerL, 0, 19200);
  SerGetSettings(FaxSerL, &serSettings);
  serSettings.flags = serSettingsFlagBitsPerChar8 | serSettingsFlagStopBits1;
  SerSetSettings(FaxSerL, &serSettings);

  WinDrawChars("Start   ", 8, 0, 0);
  sendstr("ATZ\r");
  getstr(NULL, 500);
  sendstr("AT+FCLASS=2\r");
  getstr(NULL, 500);
  sendstr("AT+FDCC=1,5,0,2,0,0,0,0\r");
  getstr(NULL, 500);
  sendstr("AT+FLID=\"ZFAXZ\"\r");
  getstr(NULL, 500);
}

void faxrec()
{
  FileHand fd;
  char *c, *d, name[32];
  int i, dlef, eoff, page;
  UInt32 n, sm;
  void *sbuf;

  WinEraseWindow();

  // name dialog...
  strcpy(retstr, "FAX");
  StrIToH(&retstr[3], TimGetSeconds());
  if (!dodlg(ffname))
    return;

  //+++Wait for RING [Yes] [no] [Cancel]
  sm = FrmAlert(2000);
  if( sm == 2 )
    return;

  strcpy(name, retstr);
  strcat(name, ".000");

  ibuf = MemPtrNew(4096);
  obuf = MemPtrNew(1024);

  WinDrawChars(name, strlen(name), 80, 0);

  faxset();

  sendstr("AT+FCR=1\r");
  getstr(NULL, 500);
  sendstr("AT+FAA=1\r");
  getstr(NULL, 500);

  if( !sm ) do {
    sm = getstr("RING\r\n",1500);
  } while( sm == 0 || sm == -1 );

  sendstr("ATA\r");
  getstr("ATA", 500);

  sbuf = MemPtrNew(4096);
  SerSetReceiveBuffer(FaxSerL, sbuf, 4096);

  WinDrawChars("Answer    ", 10, 0, 0);

  page = 0;
  fd = NULL;

  if (0 <= getstr(NULL, 1000))
    while (!cancflg) {
      sm = 0;
      if (fd)
        FileClose(fd);

      SerClearErr(FaxSerL);
      sendstr("AT+FDR\r");
      WinDrawChars("FDR            ", 15, 0, 0);

      if(1 != getstr("CONNECT\r\n", 1500))
        break;

      WinDrawChars("CONN    ", 8, 0, 0);

      StrIToH(ibuf, ++page);
      WinDrawChars(&ibuf[5], 3, 0, 15);

      if (name[strlen(name) - 1] != '9')
        name[strlen(name) - 1]++;
      else
        name[strlen(name) - 1] = 'A';

      fd =
        FileOpen(0, name, 'DATA', 'ZFAX',
                 fileModeReadWrite | fileModeAnyTypeCreator, NULL);
      sendstr("\021");
      SerReceiveWait(FaxSerL, 16, 1000);

      dlef = 0;
      eoff = 0;
      for (;;) {
        SerReceiveWait(FaxSerL, 1024, 50);
        SerReceiveCheck(FaxSerL, &n);
        if (!n)
          break;
        if (n > 2048)
          n = 2048;
        SerReceive(FaxSerL, ibuf, n, 0, &err);
        d = c = ibuf;
        i = n;
        while (i--) {
          if (dlef || *c == DLE) {
            if (!i) {
              dlef = 1;
              break;
            }
            if (!dlef)
              c++, i--, n--;
            if (*c == ETX) {
              eoff = 1, n -= i + 1;
              break;
            }
            if (*c != DLE) {
              c++, n--;
              continue;
            }
          }
          *d++ = *c++;
        }
  
        FileWrite(fd, ibuf, 1, n, &err);
        sm += n;
        StrIToA(ibuf, sm);
        strcat(ibuf, "     ");
        WinDrawChars(ibuf, strlen(ibuf), 0, 30);

        if (eoff || checkevent())
          break;
      }
      SerReceiveWait(FaxSerL, 256, 100);
      getstr(NULL, 1000);

      WinDrawChars("Page      ", 10, 0, 0);
      if (checkevent())
        break;
    }

  SerClose(FaxSerL);
  MemPtrFree(sbuf);
  MemPtrFree(ibuf);
  MemPtrFree(obuf);
}

/************************************************************************/
static const unsigned char reverse[256] = {
  0x00, 0x80, 0x40, 0xc0, 0x20, 0xa0, 0x60, 0xe0,
  0x10, 0x90, 0x50, 0xd0, 0x30, 0xb0, 0x70, 0xf0,
  0x08, 0x88, 0x48, 0xc8, 0x28, 0xa8, 0x68, 0xe8,
  0x18, 0x98, 0x58, 0xd8, 0x38, 0xb8, 0x78, 0xf8,
  0x04, 0x84, 0x44, 0xc4, 0x24, 0xa4, 0x64, 0xe4,
  0x14, 0x94, 0x54, 0xd4, 0x34, 0xb4, 0x74, 0xf4,
  0x0c, 0x8c, 0x4c, 0xcc, 0x2c, 0xac, 0x6c, 0xec,
  0x1c, 0x9c, 0x5c, 0xdc, 0x3c, 0xbc, 0x7c, 0xfc,
  0x02, 0x82, 0x42, 0xc2, 0x22, 0xa2, 0x62, 0xe2,
  0x12, 0x92, 0x52, 0xd2, 0x32, 0xb2, 0x72, 0xf2,
  0x0a, 0x8a, 0x4a, 0xca, 0x2a, 0xaa, 0x6a, 0xea,
  0x1a, 0x9a, 0x5a, 0xda, 0x3a, 0xba, 0x7a, 0xfa,
  0x06, 0x86, 0x46, 0xc6, 0x26, 0xa6, 0x66, 0xe6,
  0x16, 0x96, 0x56, 0xd6, 0x36, 0xb6, 0x76, 0xf6,
  0x0e, 0x8e, 0x4e, 0xce, 0x2e, 0xae, 0x6e, 0xee,
  0x1e, 0x9e, 0x5e, 0xde, 0x3e, 0xbe, 0x7e, 0xfe,
  0x01, 0x81, 0x41, 0xc1, 0x21, 0xa1, 0x61, 0xe1,
  0x11, 0x91, 0x51, 0xd1, 0x31, 0xb1, 0x71, 0xf1,
  0x09, 0x89, 0x49, 0xc9, 0x29, 0xa9, 0x69, 0xe9,
  0x19, 0x99, 0x59, 0xd9, 0x39, 0xb9, 0x79, 0xf9,
  0x05, 0x85, 0x45, 0xc5, 0x25, 0xa5, 0x65, 0xe5,
  0x15, 0x95, 0x55, 0xd5, 0x35, 0xb5, 0x75, 0xf5,
  0x0d, 0x8d, 0x4d, 0xcd, 0x2d, 0xad, 0x6d, 0xed,
  0x1d, 0x9d, 0x5d, 0xdd, 0x3d, 0xbd, 0x7d, 0xfd,
  0x03, 0x83, 0x43, 0xc3, 0x23, 0xa3, 0x63, 0xe3,
  0x13, 0x93, 0x53, 0xd3, 0x33, 0xb3, 0x73, 0xf3,
  0x0b, 0x8b, 0x4b, 0xcb, 0x2b, 0xab, 0x6b, 0xeb,
  0x1b, 0x9b, 0x5b, 0xdb, 0x3b, 0xbb, 0x7b, 0xfb,
  0x07, 0x87, 0x47, 0xc7, 0x27, 0xa7, 0x67, 0xe7,
  0x17, 0x97, 0x57, 0xd7, 0x37, 0xb7, 0x77, 0xf7,
  0x0f, 0x8f, 0x4f, 0xcf, 0x2f, 0xaf, 0x6f, 0xef,
  0x1f, 0x9f, 0x5f, 0xdf, 0x3f, 0xbf, 0x7f, 0xff
};

#include <Extensions/ExpansionMgr/VFSMgr.h>

static  FileHand fd;
static  FileRef fr;

static int faxbuf()
{
  unsigned long int i, n;
  unsigned char *c, *d, t;

  d = ibuf;
  i = 0;
  while (i < 2560) {
    n = 0;
    if( fd )
      n = FileRead(fd,obuf,1,1024,&err);
    else
      VFSFileRead(fr,1024,obuf, &n);

    if (!n)
      return i;
    c = obuf;
    while (n--) {
      t = reverse[*c++];
      if (t == DLE)
        *d++ = DLE, i++;
      *d++ = t, i++;
    }
  }
  return i;
}

void faxsend(char *inname)
{
  char name[40];
  int i, page;
  UInt32 sm;
  Err err;

  // Dial string dialog, Dial, Manual, Cancel
  strcpy(retstr, "T9,18005551212");
  if (!(i = dodlg(fdial)))
    return;

  WinEraseWindow();

  obuf = MemPtrNew(1024);
  ibuf = MemPtrNew(4096);

  faxset();

  if (i == bman) {
    sendstr("ATX1D\r");
  } else {
    sendstr("ATD");
    sendstr(retstr);
    sendstr("\r");
  }

  WinDrawChars("Dialing   ", 10, 0, 0);

  page = 1;
  fd = NULL;
  fr = NULL;

  //+++ GET remote ID string for display from +FCSI:

  if (!getstr(NULL, 1500)) {
    strcpy(name, &inname[1]);
    if( inname[0] == 'S' )
      fd = FileOpen(0, &inname[1], 'DATA', 'BOXR',  fileModeReadOnly | fileModeAnyTypeCreator, &err);
    else {
      err = VFSFileOpen(inname[1],&inname[2],vfsModeRead,&fr);
      strcpy(name, &inname[2]);
    }
    WinDrawChars(name, strlen(name), 60, 0);
  }

  if (err || cancflg)
    fd = NULL, fr = NULL;

  while (fd || fr) {

    if( fd )
      FileTell(fd, &sm, NULL);
    else
      VFSFileSize(fr,&sm);

    if (sm == 0xffffffff)
      break;
    StrIToA(ibuf, sm);
    strcat(ibuf, "        ");
    WinDrawChars(ibuf, strlen(ibuf), 40, 30);

    sm = 0;
    i = faxbuf();

    WinDrawChars(name, strlen(name), 0, 15);
    sendstr("AT+FDT\r");
    WinDrawChars("Send      ", 10, 0, 0);

    if (1 != getstr("CONNECT", 1500))
      break;
    WinDrawChars("Connect   ", 10, 0, 0);

    while (i) {
      sm += i;
      SerSend(FaxSerL, ibuf, i, &err);
      StrIToA(ibuf, sm);
      strcat(ibuf, "   ");
      WinDrawChars(ibuf, strlen(ibuf), 0, 30);
      if (checkevent())
	break;
      i = faxbuf();
      SerSendFlush(FaxSerL);
    }

    WinDrawChars("PageEnd   ", 10, 0, 0);
    ibuf[0] = DLE;
    ibuf[1] = ETX;
    SerSend(FaxSerL, ibuf, 2, &err);
    SerSendFlush(FaxSerL);
    getstr(NULL, 1000);

    if (fd)
      FileClose(fd);
    if (fr)
      VFSFileClose(fr);

    if (checkevent())
      break;

    WinDrawChars("Page      ", 10, 0, 0);
    page++;

    if (name[strlen(name) - 1] != '9')
      name[strlen(name) - 1]++;
    else
      name[strlen(name) - 1] = 'A';

    if( fd )
      fd = FileOpen(0, name, 'DATA', 'BOXR', fileModeReadOnly | fileModeAnyTypeCreator, &err);
    else 
      err = VFSFileOpen(inname[1],&inname[2],vfsModeRead,&fr);

    if (err)
      fd = NULL, fr = NULL;
    sendstr("AT+FET=");
    sendstr(fd ? "0\r" : "2\r");
    getstr(NULL, 1000);
  }

  SerSendFlush(FaxSerL);
  SerClose(FaxSerL);
  MemPtrFree(ibuf);
  MemPtrFree(obuf);

}
