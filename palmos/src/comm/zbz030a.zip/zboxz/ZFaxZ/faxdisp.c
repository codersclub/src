#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stringil.h"
#include <handera/Vga.h>
#include "zfaxz.h"

static const unsigned char counts[256] = {
  0x00, 0x01, 0x01, 0x02, 0x01, 0x02, 0x02, 0x03,
  0x01, 0x02, 0x02, 0x03, 0x02, 0x03, 0x03, 0x04,
  0x10, 0x11, 0x11, 0x12, 0x11, 0x12, 0x12, 0x13,
  0x11, 0x12, 0x12, 0x13, 0x12, 0x13, 0x13, 0x14,
  0x10, 0x11, 0x11, 0x12, 0x11, 0x12, 0x12, 0x13,
  0x11, 0x12, 0x12, 0x13, 0x12, 0x13, 0x13, 0x14,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x10, 0x11, 0x11, 0x12, 0x11, 0x12, 0x12, 0x13,
  0x11, 0x12, 0x12, 0x13, 0x12, 0x13, 0x13, 0x14,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x30, 0x31, 0x31, 0x32, 0x31, 0x32, 0x32, 0x33,
  0x31, 0x32, 0x32, 0x33, 0x32, 0x33, 0x33, 0x34,
  0x10, 0x11, 0x11, 0x12, 0x11, 0x12, 0x12, 0x13,
  0x11, 0x12, 0x12, 0x13, 0x12, 0x13, 0x13, 0x14,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x30, 0x31, 0x31, 0x32, 0x31, 0x32, 0x32, 0x33,
  0x31, 0x32, 0x32, 0x33, 0x32, 0x33, 0x33, 0x34,
  0x20, 0x21, 0x21, 0x22, 0x21, 0x22, 0x22, 0x23,
  0x21, 0x22, 0x22, 0x23, 0x22, 0x23, 0x23, 0x24,
  0x30, 0x31, 0x31, 0x32, 0x31, 0x32, 0x32, 0x33,
  0x31, 0x32, 0x32, 0x33, 0x32, 0x33, 0x33, 0x34,
  0x30, 0x31, 0x31, 0x32, 0x31, 0x32, 0x32, 0x33,
  0x31, 0x32, 0x32, 0x33, 0x32, 0x33, 0x33, 0x34,
  0x40, 0x41, 0x41, 0x42, 0x41, 0x42, 0x42, 0x43,
  0x41, 0x42, 0x42, 0x43, 0x42, 0x43, 0x43, 0x44
};

extern unsigned short int w, h, bandh;

extern char **lines, *editln;

extern int doFAX();
extern void cleanFAX();

static UInt32 deep;

/**************************************************/
static  Coord maxx, maxy;

/* Depends on w, h, bandh globals */
static void dobitmap(short unsigned int xofs, short unsigned int yofs,
                     short unsigned int dx, short unsigned int dy,
                     short unsigned int dw, short unsigned int dh)
{
  // these comments pertain to rendering to a bitmap
#define bp ((BitmapType *)bpx)
  static unsigned char bpx[sizeof(BitmapType) + 320 + 1024]; // this would be passed in
  unsigned char *loc, *loc2;
  unsigned short int i, j, k;

  bp->width = dw;
  bp->height = 1;               // dh
  bp->pixelSize = deep;
  bp->rowBytes = dw / (8 / deep);
  bp->version = 2;

  loc = (void *) bp;
  loc += sizeof(BitmapType);
  memset(loc, 0, bp->rowBytes); /* really should be bkgd, not 0 */// * dh

  if (dw + xofs >= w)
    j = (w - xofs + 7) / 8;
  else
    j = (dw + 7) / 8;

  yofs &= ~(deep - 1);

  for (i = 0; yofs < h && i < dh; i++, yofs += deep) {
    loc = (void *) bp;
    loc += sizeof(BitmapType);

    loc2 = lines[yofs >> 8] + 216 * (yofs & 0xff) + xofs / 8;
    k = j * deep;

    switch (deep) {
    case 1:
      memcpy(loc, loc2, k);
      break;
    case 4:
      while (k--) {
        *loc++ =
          counts[loc2[0]] + counts[loc2[216] & 0xbf] +
          counts[loc2[432] & 0xfd] + counts[loc2[648]];

        loc2++;
      }
      break;
    }
    WinDrawBitmap(bp, dx, dy + i);
  }

  if (i < dh) {
    RectangleType r = { {0, i}
    , {dh, dh - i}
    };
    WinEraseRectangle(&r, 0);   /* SHOULD BE BKGD! */
  }
}

/**************************************************/
#include <Extensions/ExpansionMgr/VFSMgr.h>

extern FileHand fd;
extern FileRef fr;
extern UInt16 cv;

void faxdisp(char *cp)
{
  UInt32 odeep,sdeep;
  EventType event;
  long int xo, yo;
  int refresh;
  RectangleType r;
  Coord dx, dy, mx,my, xmargin,ymargin;
#ifdef __VGA_H__
  int vga = 0;
  VgaRotateModeType rotateMode;
  VgaScreenModeType screenMode;
#else
#warning No Handera VGA Support
#endif

  {
    char *c = cp;
    if( *c++ == 'V' ) {
      WinDrawChars(c, strlen(c), 0, 145);
      fd = FileOpen(0, c, 'DATA', 'BOXR',
                fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    }
    else {
      WinDrawChars(&c[1], strlen(&c[1]), 0, 145);
      VFSFileOpen(*c,&c[1],vfsModeRead,&fr);
    }
  }
  if (!fd && !fr)
    return;

#ifdef __VGA_H__
  if ( !FtrGet(TRGSysFtrID, TRGVgaFtrNum, &deep) ) {
    VgaSetScreenMode(screenMode1To1,rotateModeNone);
    vga = 1;
  }
#endif

  doFAX();

  ScrDisplayMode(scrDisplayModeGetSupportedDepths, NULL, NULL, &sdeep, NULL);

  deep = 1;
  if (sdeep & 8)
    deep = 4;

  ScrDisplayMode(scrDisplayModeGet, NULL, NULL, &odeep, NULL);

  if( odeep < deep )
    ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &deep, NULL);

  WinGetDisplayExtent (&maxx, &maxy);

  xo = yo = dx = dy = 0;
  refresh = 0;
  xmargin = maxx * deep; 
  ymargin = maxy * deep; 
  if( ymargin > h )
    ymargin = h;
  if( xmargin > w )
    xmargin = w;
  dobitmap(0, 0, 0, 0, maxx, maxy);

  do {

    EvtResetAutoOffTimer();
    EvtGetEvent(&event, refresh ? 0 : -1);

    if (event.eType == nilEvent && !refresh)
      continue;

#ifdef __VGA_H__XX
    if(event.eType == displayExtentChangedEvent ) {
      WinGetDisplayExtent (&maxx, &maxy);
      refresh = 2;
    }
#endif

    if (event.eType == keyDownEvent)
      switch (event.data.keyDown.chr) {

#ifdef __VGA_H__
        case '0':
        case '9':
	  if( !vga )
	    break;
	  VgaGetScreenMode(&screenMode, &rotateMode);
	  VgaSetScreenMode(screenMode1To1, VgaRotateSelect(rotateMode));
	  WinGetDisplayExtent (&maxx, &maxy);
	  refresh = 2;
	  break;
#endif

      case pageUpChr:
      case pageDownChr:
        if (deep == 4 || !(sdeep & 8))
	  deep = 1;
        else if (deep == 1)
	  deep = 4;

	ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &deep, NULL);
	WinGetDisplayExtent (&maxx, &maxy);

	xmargin = maxx * deep; 
	ymargin = maxy * deep; 
	if( ymargin > h )
	  ymargin = h;
	if( xmargin > w )
	  xmargin = w;
	dobitmap(0, 0, 0, 0, maxx, maxy);

        continue;
      case vchrLaunch:
	event.eType = appStopEvent;
	break;
      }

    if (SysHandleEvent(&event)) {

      WinGetDisplayExtent(&mx, &my);
      if (mx != maxx || my != maxy) {
        maxx = mx, maxy = my;
        refresh = 2;
      } else
        continue;
    }

    dx = xo, dy = yo;
    if (event.eType == penDownEvent || event.eType == penMoveEvent) {
      if (event.screenY > maxy)
        continue;
      xo = event.screenX;
      yo = event.screenY;
      refresh = 1;
    }

    if (refresh) {

      xo -= 4;
      if (xo > maxx - 8)
        xo = w - xmargin;
      else
        xo = xo * (w - xmargin) / (maxx - 8);
      if (xo < 0)
        xo = 0;

      yo -= 4;
      if (yo > maxy - 8)
        yo = h - ymargin;
      else
        yo = yo * (h - ymargin) / (maxy - 8);
      if (yo < 0)
        yo = 0;

      xo &= ~(8 / deep - 1);
      yo &= ~(deep - 1);

      // This needs to be seriously modified for 4bpp to redraw partial.

      dx -= xo;
      dy -= yo;

      if (refresh == 2 || deep > 1 || dy > maxy -1 || dx > maxx -1 || dx < 1 - maxx || dy < 1-maxy ) {
        dobitmap(xo, yo, 0, 0, maxx, maxy);
	refresh = 0;
        continue;
      }
      refresh = 0;

      if (dx > 0) {
        r.topLeft.x = 0;
        r.extent.x = maxx - dx;
      } else {
        r.topLeft.x = -dx;
        r.extent.x = maxx + dx;
        dx = 0;
      }

      if (dy > 0) {
        r.topLeft.y = 0;
        r.extent.y = maxy - dy;
      } else {
        r.topLeft.y = -dy;
        r.extent.y = maxy + dy;
        dy = 0;
      }

      WinCopyRectangle(NULL, NULL, &r, dx, dy, winPaint);

      /* minimal draw */

      if (dy) {
        dobitmap(xo, yo, 0, 0, maxx, dy);
        if (dx)
          dobitmap(xo, yo + dy, 0, dy, dx, maxy - dy);
        if (r.topLeft.x)
          dobitmap(xo + maxx - r.topLeft.x, yo + dy,
                   maxx - r.topLeft.x, dy, r.topLeft.x, maxy - dy);
      } else if (r.topLeft.y) {
        dobitmap(xo, yo + maxy - r.topLeft.y, 0, maxy - r.topLeft.y,
                 maxx, r.topLeft.y);
        if (dx)
          dobitmap(xo, yo, 0, 0, dx, maxy - r.topLeft.y);
        if (r.topLeft.x)
          dobitmap(xo + maxx - r.topLeft.x, yo, maxx - r.topLeft.x, 0,
                   r.topLeft.x, maxy - r.topLeft.y);
      } else if (dx)
        dobitmap(xo, yo, 0, 0, dx, maxy);
      else if (r.topLeft.x)
        dobitmap(xo + maxx - r.topLeft.x, yo, maxx - r.topLeft.x, 0,
                 r.topLeft.x, maxy);
      continue;

    }
  } while (event.eType != appStopEvent);

  ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &odeep, NULL);

  cleanFAX();
  return;
}
