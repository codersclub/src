#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stdio2.h"
#include "stringil.h"
#include "zfaxz.h"

/* handle find modal dialog */
char retstr[256];
int dodlg(int id)
{
  FormPtr ff;
  FieldPtr textf;
  VoidHand thand;
  int k;

  if (!(ff = FrmInitForm(id)))
    return 0;

  thand = MemHandleNew(256);
  strcpy(MemHandleLock(thand), retstr);
  MemHandleUnlock(thand);
  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  FldSetTextHandle(textf, (Handle) thand);
  FrmSetFocus(ff, FrmGetObjectIndex(ff, bstring));

  k = FrmDoDialog(ff);
  retstr[0] = 0;

  if (k != bok) {
    FrmDeleteForm(ff);
    if( k == bcanc )
      return 0;
    if( k == bman )
      return 2;
  }

  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  thand = (VoidHand) FldGetTextHandle(textf);
  
  k = MemHandleSize(thand);
  strncpy(retstr, MemHandleLock(thand), k);
  retstr[k] = 0;

  MemHandleUnlock(thand);
  FrmDeleteForm(ff);

  return 1;
}
