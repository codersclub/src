#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <handera/Vga.h>

typedef unsigned long size_t;
#include "stringil.h"
#include "faxruns.h"
unsigned char cvtbuf[2048];

#include "zfaxz.h"
extern int dodlg(int id);

static int dubline;

#define bitsout(x) { \
  d = x; \
  while (*d) { \
    if (*d++ & 1) \
      t |= outbit; \
    outbit >>= 1; \
    if (!outbit) { \
      *c++ = t; \
      t = 0; \
      count++; \
      outbit = 0x80; \
    } \
  } \
}

// Note this is half-rez, doubling each pixel.
#define fwrite(a,b)      FileWrite(ofd, a, 1, b, NULL)

FileHand ofd;

void convert(unsigned char *bb, int wid, int hght)
{
  int i, j, r, bit;
  int outbit, count;
  unsigned char *c, *d, t;

  for (i = 0; i < hght; i++) {




    j = 0;
    while (j < wid && !*bb)
      j++, bb++;

    if (j == wid) {
      fwrite(blankline, 4);
      if (dubline)
        fwrite(blankline, 4);
      continue;
    }

    r = j << 3;
    c = cvtbuf;
    bit = 0x80;
    outbit = 0x80;
    t = 0;
    count = 0;

    while (j < wid) {

      while (j < wid) {
        while (bit) {
          if (*bb & bit)
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;
        for (;;) {
          j++;
          if (*++bb || j > wid - 1)
            break;
          r += 8;
        }
      }

      bitsout(ntwhite[r >> 5]);
      bitsout(twhite[(r & 31) * 2]);
      r = 0;

      if (j > wid - 1)
        break;

      while (j < wid) {
        while (bit) {
          if (!(*bb & bit))
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;

        for (;;) {
          j++;
          if (*++bb != 0xff || j > wid - 1)
            break;
          r += 8;
        }

      }

      bitsout(ntblack[r >> 5]);
      bitsout(tblack[(r & 31) * 2]);
      r = 0;

    }
    if (outbit != 0x80) {
      *c++ = t;
      count++;
    }

    *c++ = 0;
    *c++ = 0;
    *c++ = 1;
    count += 3;
    fwrite(cvtbuf, count);
    if (dubline)
      fwrite(cvtbuf, count);

  }
}

/* ************************************************************************ */

#include <Extensions/ExpansionMgr/VFSMgr.h>

extern FileHand fd;
extern FileRef fr;
extern UInt16 cv;
unsigned long fread(void *buf, unsigned long size);
void fclose();
int feof();

char name[32];
extern char retstr[256];
char *faxcvt(char *cp)
{
  Err err;
  WinHandle w2;
  WinPtr w1;
  BitmapType *bp;
  unsigned char *bb;
  void *xp;
  char *c;
  int cmax, linecnt;
  UInt16 slen;
  RectangleType r = { {32, 0}, {160, 16} };
  UInt32 romVersion;
  UInt32 deep, odeep;

  // SET NAME from dialog
  strcpy(retstr, "FAX");
  StrIToH(&retstr[3], TimGetSeconds());
  if (!dodlg(ffname))
    return NULL;

  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);

  if (!cp) {
    xp = ClipboardGetItem(clipboardText, &slen);
    if (!xp)
      return NULL;
    //+++ ERROR: Nothing to paste...
    c = MemHandleLock(xp);
  } else {
    c = cp;
    if (*c++ == 'C') {
      WinDrawChars(c, strlen(c), 0, 145);
      fd = FileOpen(0, c, 'DATA', 'BOXR',
                    fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    } else {
      WinDrawChars(&c[1], strlen(&c[1]), 0, 145);
      VFSFileOpen(*c, &c[1], vfsModeRead, &fr);
    }

    if (!fd && !fr)
      return NULL;
    c = MemPtrNew(4096);
    xp = c;
    memset(c, 0, 4096);
    fread(c, 4096);
    if (feof())
      fclose();
  }

  deep = 1;
  ScrDisplayMode(scrDisplayModeGet, NULL, NULL, &odeep, NULL);
  ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &deep, NULL);


#ifdef __VGA_H__
  if ( !FtrGet(TRGSysFtrID, TRGVgaFtrNum, &deep) )
    VgaSetScreenMode(screenMode1To1,rotateModeNone);
#endif


  w1 = WinCreateOffscreenWindow(864, 16, 0, &err);
  w2 = WinSetDrawWindow(w1);
  if (romVersion >= sysMakeROMVersion(3, 5, 0, sysROMStageRelease, 0)) {
    bp = WinGetBitmap(w1);
    bb = BmpGetBits(bp);
  } else {
    bp = w1->bitmapP;
    bb = (unsigned char *) &bp[1];
    if (bp->flags.indirect)
      bb = (unsigned char *) *(unsigned long *) bb;
    else {
      WinEraseWindow();
      memcpy(cvtbuf, bb, 2048);
      r.topLeft.x = 0;
      WinDrawRectangle(&r, 0);
      slen = 0;
      while (*bb == cvtbuf[slen++])
        bb++;
      r.topLeft.x = 32;
    }
  }

  FntSetFont(largeFont);
  dubline = 1;                  //hirez

  strcpy(name, retstr);
  strcat(name, ".000");

  //FOR EACH PAGE...
  cmax = 1;
  while (cmax) {

    if (name[strlen(name) - 1] != '9')
      name[strlen(name) - 1]++;
    else
      name[strlen(name) - 1] = 'A';

    ofd = FileOpen(0, name, 'DATA', 'ZFAX', fileModeReadWrite, NULL);

    // Start with 3 blank lines

    fwrite(fxeol, 3);
    for (slen = 0; slen < (dubline + 1) * 16 * 3; slen++)
      fwrite(blankline, 4);

    linecnt = 0;
    while ((cmax = strlen(c))) {

      if ((fd || fr) && cmax < 1024) {
        // append another chunk for file convert
        strcpy(xp, c);
        c = xp;
        memset(&c[strlen(c)], 0, 4096 - strlen(c));
        fread(&c[strlen(c)], 4096 - strlen(c));
        if (feof())
          fclose();
      }

      if (linecnt == 60)
        break;
      linecnt++;

      WinSetDrawWindow(w2);
      StrIToA(bb, linecnt);
      strcat(bb, "/");
      strcat(bb, &name[strlen(name) - 1]);
      strcat(bb, "      ");
      WinDrawChars(bb, strlen(bb), 0, 0);
      WinSetDrawWindow(w1);

      if (cmax > 256)
        cmax = 256;

      //cmax = first linefeed
      for (slen = 0; slen < cmax; slen++) {
        if (c[slen] == '\r') {
          if (slen + 1 < cmax && c[slen + 1] == '\n')
            c[slen] = ' ';
          else
            c[slen] = '\n';
        }
        if (c[slen] == '\n')
          break;
      }
      cmax = slen;

      // if too wide
      if ((slen = FntCharsWidth(c, cmax)) > 800) {
        // Rewind to just before final overlap
        do {
          slen -= FntCharWidth(c[--cmax]);
        } while (slen > 800);
        // chop at earliest space (if there is a space)
        slen = cmax;
        while (cmax && cmax != strlen(c) && c[cmax - 1] != ' ')
          cmax--;
        if (!cmax)
          cmax = slen;
      }

      WinEraseWindow();
      WinDrawChars(c, cmax, 32, 0);
      convert(bb, 108, 16);

      r.topLeft.x = 32;
      WinCopyRectangle(w1, w2, &r, 0, 32, winPaint);
      r.topLeft.x += 160;
      WinCopyRectangle(w1, w2, &r, 0, 48, winPaint);
      r.topLeft.x += 160;
      WinCopyRectangle(w1, w2, &r, 0, 64, winPaint);
      r.topLeft.x += 160;
      WinCopyRectangle(w1, w2, &r, 0, 80, winPaint);
      r.topLeft.x += 160;
      WinCopyRectangle(w1, w2, &r, 0, 96, winPaint);

      c += cmax;
      if (*c == '\n')
        c++;
      else
        while (*c && *c == ' ')
          c++;
    }

    // Append 3 blank lines
    for (slen = 0; slen < (dubline + 1) * 16 * 3; slen++)
      fwrite(blankline, 4);

    FileClose(ofd);
  }

  WinSetDrawWindow(w2);
  ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &odeep, NULL);

  if (!cp)
    MemHandleUnlock(xp);
  else
    MemPtrFree(xp);

  FntSetFont(stdFont);
  name[strlen(name) - 1] = '1';
  return name;
}
