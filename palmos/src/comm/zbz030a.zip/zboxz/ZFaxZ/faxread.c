#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>

#include "stringil.h"

#define malloc MemPtrNew
#define free MemPtrFree

unsigned short w, h, bandh;

DmOpenRef scratch;
char **lines, *lcur, *editln;

/***************************************************************************/
short int heap[209][2] = {
  1, 105, 2, 93, 3, 55, 4, 37, 5, 27, 6, 24, 7, 22, 8, 21, -32768, 9, 10, 16,
  11, 13, -1792, 12, -1984, -2048, 14, 15, -2112, -2176, -2240, -2304, 17, 18,
  -1856, -1920, 19, 20, -2368, -2432, -2496, -2560, -29, -30, 23, -22, -45,
  -46, 25, -13, -23, 26, -47, -48, 28, 34, 29, 31, -20, 30, -33, -34, 32, 33,
  -35, -36, -37, -38, 35, -1, -19, 36, -31, -32, 38, 48, 39, 42, -12, 40, 41,
  -26, -53, -54, 43, 46, 44, 45, -39, -40, -41, -42, 47, -21, -43, -44, 49,
  -10, 50, 52, -28, 51, -61, -62, 53, 54, -63, 0, -320, -384, 56, 75, 57, 65,
  -11, 58, 59, 61, -27, 60, -59, -60, 62, -18, 63, 64, -1472, -1536, -1600,
  -1728, 66, 71, 67, 69, -24, 68, -49, -50, 70, -25, -51, -52, 72, -192, 73,
  74, -55, -56, -57, -58, 76, -2, 77, 82, -1664, 78, 79, 80, -448, -512, 81,
  -640, -704, -768, 83, 89, 84, 86, -576, 85, -832, -896, 87, 88, -960, -1024,
  -1088, -1152, 90, -256, 91, 92, -1216, -1280, -1344, -1408, 94, 100, 95, 97,
  -3, 96, -128, -8, 98, -4, -9, 99, -16, -17, 101, 104, -5, 102, 103, -64,
  -14, -15, -6, -7, 106, 208, 107, 207, 108, 206, 109, 204, 110, 183, 111,
  158, 112, 125, -32768, 113, 114, 120, 115, 117, -1792, 116, -1984, -2048,
  118, 119, -2112, -2176, -2240, -2304, 121, 122, -1856, -1920, 123, 124,
  -2368, -2432, -2496, -2560, 126, 142, 127, 133, -18, 128, 129, 131, -52,
  130, -640, -704, 132, -55, -768, -832, 134, 139, 135, 137, -56, 136, -1280,
  -1344, 138, -59, -1408, -1472, 140, -24, -60, 141, -1536, -1600, 143, 151,
  144, 147, -25, 145, 146, -320, -1664, -1728, 148, 149, -384, -448, 150, -53,
  -512, -576, 152, -64, 153, 155, -54, 154, -896, -960, 156, 157, -1024,
  -1088, -1152, -1216, 159, 171, -13, 160, 161, 167, 162, 164, -23, 163, -50,
  -51, 165, 166, -44, -45, -46, -47, 168, -16, 169, 170, -57, -58, -61, -256,
  172, -14, 173, 177, -17, 174, 175, 176, -48, -49, -62, -63, 178, 181, 179,
  180, -30, -31, -32, -33, 182, -22, -40, -41, 184, 185, -10, -11, 186, -12,
  187, 194, -15, 188, 189, 192, 190, 191, -128, -192, -26, -27, 193, -19, -28,
  -29, 195, 201, 196, 198, -20, 197, -34, -35, 199, 200, -36, -37, -38, -39,
  202, 0, -21, 203, -42, -43, 205, -7, -9, -8, -6, -5, -1, -4, -3, -2
};

static unsigned char bit;
static long len;
static unsigned char *stream, *buf;

unsigned long fread(void *buf, unsigned long size);
void fclose();

unsigned char lsb2msb = 0;

extern inline int checkbit()
{
  register int i;

  i = !!(bit & *stream);
  if( lsb2msb )
    bit <<= 1;
  else
    bit >>= 1;

  if (!bit) {
    bit = lsb2msb ? 1 : 0x80, stream++, len--;
    if (!len) {
      len = fread(buf, 4096);
      stream = buf;
    }
  }
  return i;
}


/***************************************************************************/


int doFAX()
{
  unsigned char outbuf[216];

  int i,j,k,ilen, linerr;
  unsigned int eolcnt, linelen, linecnt;

  LocalID lid;
  unsigned short dbrec;
  VoidHand hand;

  w = 1728;

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }
  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");

  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);

  editln = malloc(216);
  buf = malloc(4096);
  bandh = 256;
  h = 2560;

  lines = malloc(40);

  for (i = 0; i < 10; i++) {
    dbrec = 65535;
    hand = DmNewRecord(scratch, &dbrec, 216 * bandh);
    if (!hand)
      ErrFatalDisplay("Out of Memory");
    lines[i] = MemHandleLock(hand);
  }

  ilen = len = fread(buf, 4096);
  stream = buf;
  bit = lsb2msb ? 1 : 0x80;
  while (checkbit());
  linecnt = 0;
  eolcnt = 0;
  linerr=0;
  while (eolcnt < 5 && linecnt < 2560) {

    while (!checkbit());
    linelen = 0;
    j = 0;
    memset(outbuf, 0, 216);

    for (;;) {

      i = heap[0][j];
      while (i > 0)
        i = heap[i][checkbit()];

      if (len <= 0 || i == -32768)
        break;
      i = -i;
      k = i;

      if (k + linelen > 1728)
        linerr++, k = 1728 - linelen;
      if (j)
        while (k--) {
          outbuf[linelen >> 3] |= (0x80 >> (linelen & 7));
          linelen++;
      } else
        linelen += k;

      if (i < 64)
        j ^= 1;
    }

#if 1
    if( linerr && !lsb2msb ) {
      stream = buf;
      len = ilen;
      lsb2msb = 1;
      bit = 1;
      while (checkbit());
      continue;
    }
#endif

    if (linelen == 0)
      eolcnt++;
    else
      eolcnt = 0;

    DmWrite(lines[linecnt >> 8], 216 * (unsigned short) (linecnt & 0xffU), outbuf, 216);

    linecnt++;
    StrIToA(outbuf,linecnt);
    WinDrawChars(outbuf,strlen(outbuf),0,0);
  }
  if (eolcnt)
    linecnt -= eolcnt;
  h = linecnt;
  fclose();
  free(buf);
  return 0;
}

/**************************************************/
void cleanFAX()
{
  int i;

  for (i = 0; i < h; i += bandh)
    MemPtrUnlock(lines[i / bandh]);

  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);

  DmCloseDatabase(scratch);
  free(lines);
  free(editln);
}
