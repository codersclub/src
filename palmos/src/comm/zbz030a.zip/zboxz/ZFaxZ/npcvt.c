#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stringil.h"

extern unsigned char *twhite[];
extern unsigned char *ntwhite[];
extern unsigned char *tblack[];
extern unsigned char *ntblack[];
extern const unsigned char fxeol[3];
extern const unsigned char blankline[4];
extern const unsigned char eofx[8];

#define bitsout(x) { \
  d = x; \
  while (*d) { \
    if (*d++ & 1) \
      t |= outbit; \
    outbit >>= 1; \
    if (!outbit) { \
      *c++ = t; \
      t = 0; \
      count++; \
      outbit = 0x80; \
    } \
  } \
}

#define fwrite(dataP, num)  FileWrite(ofd, (dataP), 1, (num), NULL)

// Note this is one-fourth rez.
extern unsigned char cvtbuf[];
extern FileHand ofd;

static void cvtnp(unsigned char *bb, int wid, int hght)
{
  int i, j, r, bit;
  int outbit, count;
  unsigned char *c, *d, t;

  for (i = 0; i < hght; i++) {

    StrIToA(cvtbuf, i);
    StrCat(cvtbuf, "      ");
    WinDrawChars(cvtbuf, StrLen(cvtbuf), 20, 0);

    j = 0;
    while (j < wid && !*bb)
      j++, bb++;

    if (j == wid) {
      for (r = 0; r < 8; r++)
        fwrite(blankline, 4);
      continue;
    }

    r = j << 3;
    r += 16;
    c = cvtbuf;
    bit = 0x80;
    outbit = 0x80;
    t = 0;
    count = 0;

    while (j < wid) {

      while (j < wid) {
        while (bit) {
          if (*bb & bit)
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;
        for (;;) {
          j++;
          if (*++bb || j > wid - 1)
            break;
          r += 8;
        }
      }

      if (j == wid)
        r += 16 * 16;

      bitsout(ntwhite[r >> 4]);
      bitsout(twhite[(r & 15) * 4]);
      r = 0;

      if (j > wid - 1)
        break;

      while (j < wid) {
        while (bit) {
          if (!(*bb & bit))
            break;
          r++;
          bit >>= 1;
        }
        if (bit)
          break;
        bit = 0x80;

        for (;;) {
          j++;
          if (*++bb != 0xff || j > wid - 1)
            break;
          r += 8;
        }
      }

      bitsout(ntblack[r >> 4]);
      bitsout(tblack[(r & 15) * 4]);
      r = 0;
      if (j == wid) {
        bitsout(ntwhite[16]);
        bitsout(twhite[0]);
      }
    }

    if (outbit != 0x80) {
      *c++ = t;
      count++;
    }

    *c++ = 0;
    *c++ = 0;
    *c++ = 1;
    count += 3;
    for (r = 0; r < 4; r++)
      fwrite(cvtbuf, count);
  }
}

char *cvtnote()
{
  int slen, i, j, k, nrecs, sec, min, hr, day, mon, yr;
  unsigned int l;
  LocalID lid;
  DmOpenRef db;
  VoidHand xp;
  unsigned char *cp, *xb, *c, title[40];

  xb = MemPtrNew(8192);
  lid = DmFindDatabase(0, "npadDB");
  db = DmOpenDatabase(0, lid, dmModeReadOnly);
  nrecs = DmNumRecords(db);

  for (i = 0; i < nrecs; i++) {
    xp = DmGetRecord(db, i);
    if (!xp)
      continue;
    slen = MemHandleSize(xp);
    if (!slen)
      continue;
    cp = MemHandleLock(xp);

    sec = *cp++ << 8;
    sec |= *cp++;
    min = *cp++ << 8;
    min |= *cp++;
    hr = *cp++ << 8;
    hr |= *cp++;
    day = *cp++ << 8;
    day |= *cp++;
    mon = *cp++ << 8;
    mon |= *cp++;
    yr = *cp++ << 8;
    yr |= *cp++;

    slen -= 12;

    while (slen > 0) {
      slen -= 2;
      k = *cp++ << 8;
      k |= *cp++;
      if (k)
        continue;
      k = *cp++ << 8;
      k |= *cp++;
      slen -= 2;
      if (k == slen)
        break;
    }
    k = 1;
    if (!slen) {

      MemHandleUnlock(xp);
      DmReleaseRecord(db, i, false);
      continue;
    }

    // w, h , d? , ?, bmlen

    for (j = 0; j < 5; j++) {
      l = (unsigned long) *cp++ << 24;
      l |= (unsigned long) *cp++ << 16;
      l |= (unsigned long) *cp++ << 8;
      l |= (unsigned long) *cp++;
    }

    c = xb;

    while (slen > 0) {
      
      j = *cp++;
      if (!j)
	break;
      k = *cp++;

      while (j--)
	*c++ = k;
      slen -= 2;
    }

    MemHandleUnlock(xp);
    DmReleaseRecord(db, i, false);

    /* Create the database */
    StrIToA(title, mon);
    StrCat(title, ".");
    StrIToA(&title[strlen(title)], day);
    StrCat(title, ".");
    StrIToA(&title[strlen(title)], yr);
    StrCat(title, ".");
    StrIToA(&title[strlen(title)], hr);
    StrCat(title, ".");
    StrIToA(&title[strlen(title)], min);
    StrCat(title, ".");
    StrIToA(&title[strlen(title)], sec);
    StrCat(title, ".FAX");

#define bmp ((BitmapType *)cvtbuf)
    memset(cvtbuf,0,sizeof(BitmapType));
    bmp->width = 160;
    bmp->height = 1;          // dh
    bmp->pixelSize = 1;
    bmp->rowBytes = 20;
    bmp->version = 2;

    cp = xb;

    for (k = 0; k < 160; k++) {
      memcpy(cvtbuf + sizeof(BitmapType), cp, 20);
      cp += 20;
      WinDrawBitmap(bmp, 0, k);
    }
    SysTaskDelay(100);

    //Display title, top of image, ask to convert or skip
    k = FrmAlert(2900);

    if (k == 3)
      break;

    if (k == 2)
      continue;

    //convert, or convert+send
    
    ofd = FileOpen(0, title, 'DATA', 'ZFAX', fileModeReadWrite, NULL);

    // Start with several blank lines
    fwrite(fxeol, 3);
    for (slen = 0; slen < 32; slen++)
      fwrite(blankline, 4);

    cvtnp(xb, 20, 352);

    // Append 3 blank lines
    for (slen = 0; slen < 16; slen++)
      fwrite(blankline, 4);
    
    FileClose(ofd);

    //Future, cvt & send
    if( k == 1 ) {
      DmCloseDatabase(db);
      MemPtrFree(xb);
      strcpy(cvtbuf,title);
WinDrawChars(cvtbuf,strlen(cvtbuf),0,30);
      return cvtbuf;
    }

  }
  DmCloseDatabase(db);
  MemPtrFree(xb);
  return NULL;
}
