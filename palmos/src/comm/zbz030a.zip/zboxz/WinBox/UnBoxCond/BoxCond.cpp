#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000
#define VC_EXTRALEAN            // Exclude rarely-used stuff from Windows headers
#include <afxwin.h>             // MFC core and standard components
#include <afxext.h>             // MFC extensions
#include "syncmgr.h"
#include "hslog.h"
#include "condapi.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <time.h>
#ifndef ExportFunc
#define ExportFunc __declspec( dllexport )
#endif
#include "basemon.h"
#include "condmgr.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;

#endif
HINSTANCE myInst = 0;

class CBoxcondDll:public CWinApp { public:
  virtual BOOL InitInstance();  // Initialization
  virtual int ExitInstance();   // Termination 
    DECLARE_MESSAGE_MAP();
};

BEGIN_MESSAGE_MAP(CBoxcondDll, CWinApp)
  END_MESSAGE_MAP();

     BOOL CBoxcondDll::InitInstance()
{
  myInst = AfxGetInstanceHandle();
  return TRUE;
}

int CBoxcondDll::ExitInstance()
{
  return CWinApp::ExitInstance();
}

CBoxcondDll boxcondDll;

ExportFunc long OpenConduit(PROGRESSFN pFn, CSyncProperties & rProps)
{
  AFX_MANAGE_STATE(AfxGetStaticModuleState());
  long retval = 0, len;
  unsigned char palmdb = 0;
  unsigned char whichway = 0;
  struct _stat statbuf;
  struct tm *tzfl;
  CFile localFile;
  CString localFileName;
  CONDHANDLE conduitHandle = (CONDHANDLE) 0;
  CRawRecordInfo rawRecord;
  char iobufc[4800];
  void *iobuf = iobufc;

  // Register this conduit with SyncMgrDLL for communication to HH
  if (retval = SyncRegisterConduit(conduitHandle))
    return (retval);

  switch (rProps.m_SyncType) {
  case eFast:
  case eSlow:
    whichway = 3;
    break;
  case eInstall:
  case ePCtoHH:
    whichway = 2;
    break;
  case eBackup:
  case eHHtoPC:
    whichway = 1;
    break;
  default:
    break;
  }

  if (whichway) {
    time(&retval);
    tzfl = localtime(&retval);
    retval = 0;
    SyncWriteSysDateTime(time(NULL));
  }


  if (1 || whichway & 1) {
    SyncDatabaseInfoType sdbi;
    SyncFindDbByTypeCreatorParams sfdbtc = { 0xe0, 0x80, 'DATA', 'BOXR' };

    while (!SyncFindDbByTypeCreator(sfdbtc, sdbi)) {
      sfdbtc.bSrchFlags = 0;

      if (!strcmp("ZBOXZSCRATCHPAD", sdbi.baseInfo.m_Name))
        continue;

      //Remove stale ToBox entry
      localFileName = rProps.m_PathName;
      localFileName += "../ToBox/";
      localFileName += sdbi.baseInfo.m_Name;
      statbuf.st_ctime = 0;
      _stat(localFileName, &statbuf);
      if (statbuf.st_ctime && tzfl->tm_isdst)
        statbuf.st_ctime += 3600;
      if (statbuf.st_ctime && statbuf.st_ctime < sdbi.baseInfo.m_CreateDate)
        remove(localFileName);

      localFileName = rProps.m_PathName;
      localFileName += sdbi.baseInfo.m_Name;
      statbuf.st_ctime = 0;
      _stat(localFileName, &statbuf);
      if (statbuf.st_ctime && tzfl->tm_isdst)
        statbuf.st_ctime += 3600;

      if (statbuf.st_ctime && statbuf.st_ctime > sdbi.baseInfo.m_CreateDate)
        continue;
      if (statbuf.st_ctime)
        remove(localFileName);

      SyncOpenDB(sdbi.baseInfo.m_Name, 0, palmdb);
      retval =
        !(localFile.Open
          (LPCTSTR(localFileName), CFile::modeCreate | CFile::modeWrite));

      if (retval || localFile.m_hFile == CFile::hFileNull)
		continue;

      memset(&rawRecord, 0, sizeof(CRawRecordInfo));
      rawRecord.m_pBytes = (unsigned char *) iobufc;
      rawRecord.m_FileHandle = palmdb;
      rawRecord.m_TotalBytes = 4800;
      memset(iobuf, 0, 4800);

      while (!(retval = SyncReadRecordByIndex(rawRecord))) {
        len = rawRecord.m_pBytes[4] << 24;
        len |= rawRecord.m_pBytes[5] << 16;
        len |= rawRecord.m_pBytes[6] << 8;
        len |= rawRecord.m_pBytes[7];
        localFile.Write(&rawRecord.m_pBytes[8], len);
        rawRecord.m_RecIndex++;
      }

      localFile.Close();
      SyncResetSyncFlags(palmdb);
      SyncCloseDB(palmdb);

      if (retval == SYNCERR_FILE_NOT_FOUND)
        retval = 0;

      strcpy(iobufc, "UnBoxed: ");
      strcat(iobufc, sdbi.baseInfo.m_Name);
      LogAddEntry(iobufc, slText, FALSE);
    }
  }
  if (whichway & 2) {
    CFileFind findat;
    CDbCreateDB dbInfo;
    long findsts, total, thissize;

    localFileName = rProps.m_PathName;
    localFileName += "..\\ToBox\\*.*";

    findsts = findat.FindFile(localFileName, 0);

    while (findsts) {
      findsts = findat.FindNextFile();

      retval = !(localFile.Open(findat.GetFilePath(), CFile::modeRead));
      if (retval || localFile.m_hFile == CFile::hFileNull)
        continue;

      SyncDeleteDB(findat.GetFileName(), 0);

      memset(&dbInfo, 0, sizeof(dbInfo));
      dbInfo.m_Creator = 'BOXR';
      dbInfo.m_Flags = (enum eDbFlags) 0x80;
      dbInfo.m_CardNo = 0;
      dbInfo.m_Type = 'DATA';
      strncpy(dbInfo.m_Name, findat.GetFileName(), 32);

      if ((retval = SyncCreateDB(dbInfo))) {
        localFile.Close();
        continue;
      }

      total = localFile.GetLength();
      strcpy(iobufc, "DBLK");
      iobufc[4] = iobufc[5] = iobufc[7] = 0;
      iobufc[6] = 0x10;
      while (total) {
        thissize = total > 4096 ? 4096 : total;
        total -= thissize;

        // initialize the rawRecord
        memset(&rawRecord, 0, sizeof(CRawRecordInfo));
        rawRecord.m_pBytes = (unsigned char *) iobufc;
        rawRecord.m_FileHandle = dbInfo.m_FileHandle;
        rawRecord.m_TotalBytes = thissize + 8;
        rawRecord.m_RecSize = thissize + 8;
        localFile.Read(&iobufc[8], thissize);
        if (thissize < 4096)
          iobufc[6] = (char) (thissize >> 8),
            iobufc[7] = (char) (thissize & 0xff);
        retval = SyncWriteRec(rawRecord);
        rawRecord.m_RecIndex++;
      }
      localFile.Close();
      SyncCloseDB(dbInfo.m_FileHandle);
      strcpy(iobufc, "Boxed: ");
      strcat(iobufc, findat.GetFileName());
      LogAddEntry(iobufc, slText, FALSE);
    }

    retval = 0;
  }
  SyncUnRegisterConduit(conduitHandle);
  return (retval);
}

ExportFunc long GetConduitName(char *pszName, WORD nLen)
{
  AFX_MANAGE_STATE(AfxGetStaticModuleState());
  long retval = 0;
  memset(pszName, 0, nLen);
  strncpy(pszName, "ZBoxZ", nLen - 1);
  return retval;
}

ExportFunc DWORD GetConduitVersion()
{
  AFX_MANAGE_STATE(AfxGetStaticModuleState());
  return 5;
}

ExportFunc long GetConduitInfo(ConduitInfoEnum infoType, void *pInArgs,
                               void *pOut, DWORD * pdwOutSize)
{
  AFX_MANAGE_STATE(AfxGetStaticModuleState());
  if (!pOut)
    return CONDERR_INVALID_PTR;
  if (!pdwOutSize)
    return CONDERR_INVALID_OUTSIZE_PTR;
  switch (infoType) {
  case eMfcVersion:
    if (*pdwOutSize != sizeof(DWORD))
      return CONDERR_INVALID_BUFFER_SIZE;
    (*(DWORD *) pOut) = MFC_VERSION_50;
    break;
  case eConduitName:
    // This code is for example. This conduit does not use this code
    if (!pInArgs)
      return CONDERR_INVALID_INARGS_PTR;
    ConduitRequestInfoType *pInfo;
    pInfo = (ConduitRequestInfoType *) pInArgs;
    if ((pInfo->dwVersion != CONDUITREQUESTINFO_VERSION_1) ||
        (pInfo->dwSize != SZ_CONDUITREQUESTINFO))
        return CONDERR_INVALID_INARGS_STRUCT;
    memset((TCHAR *) pOut, 0, *pdwOutSize);
    strncpy((TCHAR *) pOut, "ZBoxZ", (*pdwOutSize) - 1);
    break;

  case eDefaultAction:
    if (*pdwOutSize != sizeof(eSyncTypes))
      return CONDERR_INVALID_BUFFER_SIZE;
    (*(eSyncTypes *) pOut) = eFast;
    break;

  default:
    return CONDERR_UNSUPPORTED_CONDUITINFO_ENUM;
  }
  return 0;
}
