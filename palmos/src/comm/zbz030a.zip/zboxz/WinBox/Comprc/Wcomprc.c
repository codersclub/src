#include <stdio.h>
#include <string.h>
#include <time.h>

#include <windowsx.h>
#define STRICT
#include <windows.h>
#include <commdlg.h>

int comprc(FILE * infd, FILE * outfd);

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int cmdShow)
{

  unsigned long cofst;
  unsigned char bbuf[256];
  unsigned long xlong;
  char fname[256],  *cmdlp;
  FILE *outfd, *infd;
 
  WIN32_FIND_DATA findat;
  OPENFILENAME winofn;

  cmdlp = lpCmdLine;
  if (!lpCmdLine || !strlen(lpCmdLine)) {

    memset(&winofn, 0, sizeof(OPENFILENAME));
    winofn.lStructSize = sizeof(OPENFILENAME);
    //  winofn.hwndOwner = 0;        // An invalid hWnd causes non-modality
    winofn.lpstrFilter = (LPSTR) "Palm Resource (*.prc)\0*.prc\0";
    winofn.nFilterIndex = 1;
    winofn.lpstrFile = (LPSTR) fname; // Stores the result in this variable
    winofn.nMaxFile = sizeof(fname);
    winofn.lpstrTitle = "File to compress"; // Title for dialog
    winofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    winofn.lpstrDefExt = "*";
  }

  for (;;) {
    fname[0] = 0;
    if (strlen(cmdlp)) {
      strcpy(fname, cmdlp);
      for (cofst = 0; cofst < strlen(fname); cofst++)
        if (fname[cofst] == ' ') {
          fname[cofst] = 0;
          break;
        }

      cmdlp += strlen(fname)+1;
      while (*cmdlp && *cmdlp == ' ')
        cmdlp++;
      {
      }
    } else {

      if (lpCmdLine && strlen(lpCmdLine))
        break;

      if (GetOpenFileName(&winofn) != TRUE) {
        xlong = CommDlgExtendedError();
        if (xlong != 0)         // 0 value means user selected Cancel
        {
          sprintf(bbuf, "File Open returned error %ld", xlong);
          MessageBox(0, bbuf, "WARNING", MB_OK | MB_ICONSTOP);
          continue;
        } else
          break;
      }
    }
    if (!(infd = fopen(fname, "rb")))
      exit(-1);

    FindClose(FindFirstFile(fname, &findat));

    if (!strcmp(&fname[strlen(fname) - 4], ".prc"))
      fname[strlen(fname) - 4] = 0;
    if (!strcmp(&fname[strlen(fname) - 4], ".PRC"))
      fname[strlen(fname) - 4] = 0;
    if (!strcmp(&fname[strlen(fname) - 4], ".Prc"))
      fname[strlen(fname) - 4] = 0;

    strcat(fname, ".pdb");

    if (!(outfd = fopen(fname, "wb")))
      exit(-1);

	comprc(infd,outfd);
  }
  return 0;
}
