#include <stdio.h>
#include <string.h>

#include <windowsx.h>
#define STRICT
#include <windows.h>
#include <commdlg.h>

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int cmdShow)
{
  char bbuf[5000], fname[256], *cmdlp, *fxp;
  unsigned long xlong;
  unsigned short xshort;
  long bbuflen;
  int i;
  FILE *outfd, *infd;

  OPENFILENAME winofn;

  memset(&winofn, 0, sizeof(OPENFILENAME));
  winofn.lStructSize = sizeof(OPENFILENAME);
  winofn.lpstrFile = (LPSTR) fname; // Default in, actual out
  winofn.nMaxFile = 256;

  cmdlp = lpCmdLine;

  for (;;) {
    fname[0] = 0;

    if (strlen(cmdlp)) {
      strcpy(fname, cmdlp);
      for (i = 0; i < (int) strlen(fname); i++)
        if (fname[i] == ' ') {
          fname[i] = 0;
          break;
        }

      cmdlp += strlen(fname);
      while (*cmdlp && *cmdlp == ' ')
        cmdlp++;
    } else {

      if (lpCmdLine != NULL && strlen(lpCmdLine))
        break;

      winofn.lpstrFilter =
        (LPSTR) "ZBoxZ (palmdb) Files (*.pdb)\0*.pdb\0All Files (*.*)\0*.*\0";
      winofn.nFilterIndex = 1;
      winofn.lpstrTitle = "File to UnBox"; // Title for dialog
      winofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
      winofn.lpstrDefExt = "*";


      if (GetOpenFileName(&winofn) != TRUE) {
        xlong = CommDlgExtendedError();
        if (xlong != 0)         // 0 value means user selected Cancel
        {
          sprintf(bbuf, "File Open returned error %ld", xlong);
          MessageBox(0, bbuf, "WARNING", MB_OK | MB_ICONSTOP);
          continue;
        } else
          break;
      }
    }
    infd = fopen(fname, "rb");

    strcpy(bbuf, fname);

    fxp = bbuf;
    fxp += strlen(bbuf) - 1;
    while (fxp != bbuf && *fxp != '\\')
      fxp--;
    if (*fxp == '\\')
      fxp++;

    fread(fxp, 1, 32, infd);

    fxp = &bbuf[4096];

    fread(fxp, 1, 2, infd);
    i = *++fxp;

    fseek(infd, 76, SEEK_SET);
    fread(&xshort, 1, 2, infd);
    fread(&xlong, 1, 4, infd);

    xshort = htons(xshort);
    xlong = htonl(xlong);
    fseek(infd, xlong, SEEK_SET);

    bbuflen = fread(fxp, 1, 8, infd);
    if (!(i & 0x80) || bbuflen != 8 || strncmp(fxp, "DBLK", 4)) {
      strcat(fname, " Is not a box");
      MessageBox(0, fname, "Not a Box", MB_OK);
      fclose(infd);
      continue;
    }

    fseek(infd, xlong, SEEK_SET);
    strcpy(fname, bbuf);

// maybe should retain save path?

    winofn.lpstrFilter = (LPSTR) "All Files (*.*)\0*.*\0";
    winofn.nFilterIndex = 1;
    winofn.lpstrTitle = "Save Box As..."; // Title for dialog
    winofn.Flags = OFN_PATHMUSTEXIST;
    winofn.lpstrDefExt = NULL;

    if (GetSaveFileName(&winofn) != TRUE) {
      xlong = CommDlgExtendedError();
      if (xlong != 0)           // 0 value means user selected Cancel
      {
        sprintf(bbuf, "File Save returned error %ld", xlong);
        MessageBox(0, bbuf, "WARNING", MB_OK | MB_ICONSTOP);
        continue;
      } else
        break;
    }

    outfd = fopen(fname, "wb");

    for (i = 0; i < xshort; i++) {
      bbuflen = fread(bbuf, 1, 4104, infd);
      if (bbuflen < 8 || strncmp(bbuf, "DBLK", 4)) {
        MessageBox(0, "Box damaged", "WARNING", MB_OK | MB_ICONEXCLAMATION);
        break;
      }
      fwrite(&bbuf[8], 1, bbuflen - 8, outfd);
    }
    fclose(outfd);
    fclose(infd);

  }
  return 0;
}
