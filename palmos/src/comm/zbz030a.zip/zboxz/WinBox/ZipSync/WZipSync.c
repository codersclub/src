#include <stdio.h>
#include <string.h>

#include <windowsx.h>

#define STRICT
#include <windows.h>
#include <commdlg.h>

extern zipsync(FILE * ,char *, FILE *);

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int cmdShow)
{
  unsigned long cofst, xlong;
  unsigned char bbuf[256];
  FILE *outfd, *infd;
  int argp = 1;
  unsigned char title[256], fname[256], *cmdlp;

  WIN32_FIND_DATA findat;
  OPENFILENAME winofn;

  cmdlp = lpCmdLine;
    if (!lpCmdLine || !strlen(lpCmdLine)) {

    memset(&winofn, 0, sizeof(OPENFILENAME));
    winofn.lStructSize = sizeof(OPENFILENAME);
    //  winofn.hwndOwner = 0;        // An invalid hWnd causes non-modality
    winofn.lpstrFilter = (LPSTR) "Palm Resource (*.prc)\0*.prc\0Palm Database (*.pdb)\0*.pdb\0All Files (*.*)\0*.*\0";
    winofn.nFilterIndex = 1;
    winofn.lpstrFile = (LPSTR) fname; // Stores the result in this variable
    winofn.nMaxFile = sizeof(fname);
    winofn.lpstrTitle = "File to compress"; // Title for dialog
    winofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    winofn.lpstrDefExt = "*";
  }

  for (;;) {
fname[0] = 0;
    if (strlen(cmdlp)) {
      strcpy(fname, cmdlp);

      for (cofst = 0; cofst < strlen(fname); cofst++)
        if (fname[cofst] == ' ') {
          fname[cofst] = 0;
          break;
        }

      cmdlp += strlen(fname) + 1;
      while (*cmdlp && *cmdlp == ' ')
        cmdlp++;
    } else {
      if (lpCmdLine && strlen(lpCmdLine))
        break;

      if (GetOpenFileName(&winofn) != TRUE) {
        xlong = CommDlgExtendedError();
        if (xlong != 0) {       // 0 value means user selected Cancel
          sprintf(bbuf, "File Open returned error %ld", xlong);
          MessageBox(0, bbuf, "WARNING", MB_OK | MB_ICONSTOP);
          break;
        } else
          break;
      }
    }
    if (!(infd = fopen(fname, "rb")))
      exit(-1);

    FindClose(FindFirstFile(fname, &findat));

    strcpy(title, fname);
    strcpy(&title[strlen(title) - 4], ".z");
    strcat(title, &fname[strlen(fname) - 4]);

    outfd = fopen(title, "wb");

    title[strlen(title) - 4] = 0;

    zipsync(infd, title, outfd);

  }
  return 0;
}
