#include <Windows.h>
#include <stdio.h>
#include <condmgr.h>
const char *kCreator = "BOXR";
int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int cmdShow)
{
  int err;
  
  err =
    MessageBox(0,
               "Do you want ZBoxZ Conduit Installed?\nYes (re)installs, No uninstalls.",
               "ZBoxZ Conduit Installation", MB_YESNOCANCEL | MB_ICONASTERISK);
  if (err == IDNO)
	  CmRemoveConduitByCreatorID(kCreator);
  else if (err == IDYES) {
	  CmRemoveConduitByCreatorID(kCreator);
	  if (err = CmInstallCreator(kCreator, CONDUIT_APPLICATION))
      return err;
    if (err = CmSetCreatorName(kCreator, "BoxrCn25.DLL"))
      return err;
    if (err = CmSetCreatorDirectory(kCreator, "Unboxed"))
      return err;
    if (err = CmSetCreatorFile(kCreator, "default"))
      return err;
    if (err = CmSetCreatorPriority(kCreator, 2))
      return err;
  }
  return 0;
}
