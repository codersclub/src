#include <stdio.h>
#include <string.h>
#include <time.h>

#include <windowsx.h>
#define STRICT
#include <windows.h>
#include <commdlg.h>

int PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int cmdShow)
{
  unsigned long cofst;
  unsigned char bbuf[5000], flist[5000], *flp = flist;
  unsigned short xshort;
  unsigned long xlong, xid;
  long bbuflen;
  int maxsect;
  char fname[256], *cmdlp;
  FILE *outfd, *infd;

  WIN32_FIND_DATA findat;
  OPENFILENAME winofn;
  *flp = 0;

  cmdlp = lpCmdLine;
  if (!lpCmdLine || !strlen(lpCmdLine)) {

    memset(&winofn, 0, sizeof(OPENFILENAME));
    winofn.lStructSize = sizeof(OPENFILENAME);
    //  winofn.hwndOwner = 0;        // An invalid hWnd causes non-modality
    winofn.lpstrFilter = (LPSTR) "All Files (*.*)\0*.*\0";
    winofn.nFilterIndex = 1;
    winofn.lpstrFile = (LPSTR) fname; // Stores the result in this variable
    winofn.nMaxFile = sizeof(fname);
    winofn.lpstrTitle = "File to Box"; // Title for dialog
    winofn.Flags = OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST;
    winofn.lpstrDefExt = "*";
  }

  for (;;) {
    fname[0] = 0;
    if (strlen(cmdlp)) {
      strcpy(fname, cmdlp);
      for (cofst = 0; cofst < strlen(fname); cofst++)
        if (fname[cofst] == ' ') {
          fname[cofst] = 0;
          break;
        }

      cmdlp += strlen(fname);
      while (*cmdlp && *cmdlp == ' ')
        cmdlp++;
      {
      }
    } else {

      if (lpCmdLine && strlen(lpCmdLine))
        break;

      if (GetOpenFileName(&winofn) != TRUE) {
        xlong = CommDlgExtendedError();
        if (xlong != 0)         // 0 value means user selected Cancel
        {
          sprintf(bbuf, "File Open returned error %ld", xlong);
          MessageBox(0, bbuf, "WARNING", MB_OK | MB_ICONSTOP);
          continue;
        } else
          break;
      }
    }
    if (!(infd = fopen(fname, "rb")))
      exit(-1);

    FindClose(FindFirstFile(fname, &findat));

    memset(bbuf, 0, 32);
    strcpy(bbuf, findat.cFileName);
    bbuf[32] = 0;

    strcpy(fname, findat.cFileName);
    strcat(fname, ".pdb");

    if (!(outfd = fopen(fname, "wb")))
      exit(-1);

    fwrite(bbuf, 1, 32, outfd);

    memset(bbuf, 0, 4);
    bbuf[1] = 0x88;
    bbuf[3] = 1;
    fwrite(bbuf, 1, 4, outfd);

    xlong = time(NULL) + ((66 * 365 + 17) * 24 * 3600UL);
    xlong = htonl(xlong);

    fwrite(&xlong, 1, 4, outfd);
    fwrite(&xlong, 1, 4, outfd);
    fwrite(&xlong, 1, 4, outfd);

    memset(bbuf, 0, 12);
    fwrite(bbuf, 1, 12, outfd);

    fwrite("DATA", 1, 4, outfd);
    fwrite("BOXR", 1, 4, outfd);

    bbuf[0] = 0x28;
    fwrite(bbuf, 1, 8, outfd);

    fseek(infd, 0, SEEK_END);
    xlong = ftell(infd);
    fseek(infd, 0, SEEK_SET);

    maxsect = xlong / 4096 + 1;
    xshort = htons((short) maxsect);
    fwrite(&xshort, 1, 2, outfd);

    cofst = 80 + 8 * maxsect;

    xid = 0x40000000UL + (rand() & 0x7fffffUL);

    strcpy(bbuf, "DBLK");
    bbuf[5] = bbuf[7] = 0;
    bbuf[6] = 0x10;

    while (maxsect--) {
      xlong = htonl(cofst);
      fwrite(&xlong, 1, 4, outfd);
      xlong = htonl(xid++);
      fwrite(&xlong, 1, 4, outfd);
      cofst += 4104;
    }

    xshort = 0;
    fwrite(&xshort, 1, 2, outfd);

    for (;;) {

      bbuflen = fread(&bbuf[8], 1, 4096, infd);

      if (bbuflen != 4096)
        break;

      fwrite(bbuf, 1, bbuflen + 8, outfd);
    }
    if (bbuflen < 0)
      exit(-3);

    fwrite(bbuf, 1, 4, outfd);
    xlong = htonl(bbuflen);
    fwrite(&xlong, 1, 4, outfd);
    fwrite(&bbuf[8], 1, bbuflen, outfd);

    fclose(infd);
    fclose(outfd);

    strcat(flist, fname);
    strcat(flist, " ");
  }

  return 0;

}
