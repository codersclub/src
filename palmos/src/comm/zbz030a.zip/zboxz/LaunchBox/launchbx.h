/* Resources */

#define mainform   1004
#define mainhelp   1005
#define maintable  1001
#define bfile      1002
#define ball       1003
#define bdest      1006
#define scrl       1080

#define SORTPREFIX 4
