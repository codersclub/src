  struct lboxrsrc {
    UInt32 crea;
    UInt16 cardno;
    char appn[32];
  };
