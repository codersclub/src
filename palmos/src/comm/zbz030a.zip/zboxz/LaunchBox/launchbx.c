#include <PalmOS.h>

#include <ExgMgr.h>
#include <System/FileStream.h>
#include <System/SysEvtMgr.h>
#include "launchbx.h"

#include <Unix/sys_types.h>

#include "stringil.h"
#include "stdio2.h"


#include "SysZLib.h"


#define NOZLIBDEFS
#include "SysZLib.h"

static int toprow = 0;
static char *filelist;
static short int *filesort;

static int selection = -1;
static char *filecard;
static long int *filedisp;
static int maxrow = 0;
static unsigned char sels[256];
static char **filelp;
static int xitapp = 0;
static int doall = 0;
static UInt32 romVersion;
/* **************************************************************************** */
TableDrawItemFuncType TableDrawCell;

void TableDrawCell(VoidPtr tableP, Int16 row, Int16 column,
                   RectangleType * bounds)
{
  char *c;
  unsigned long which;

  which = TblGetRowData(tableP, row);
  c = filelp[which] + SORTPREFIX;
  WinEraseRectangle(bounds, 0);
  WinDrawChars(c, strlen(c), bounds->topLeft.x + 1, bounds->topLeft.y);
  if (sels[which >> 3] & (1 << (which & 7)))
    WinInvertRectangle(bounds, 0);
}

/* **************************************************************************** */

static Int16 fncomp(void *x, void *y, Int32 z)
{
  unsigned char **zx;
  int num = 32;

  zx = (unsigned char **) z;
  x = zx[*(short int *) x];
  y = zx[*(short int *) y];

  while (--num && *(unsigned char *) y++ == *(unsigned char *) x++);
  y--;
  x--;
  return *(unsigned char *) x - *(unsigned char *) y;

}

void scandbs(int all)
{
  UInt16 cardno, attr;
  UInt32 type, crea, i, ndb, j, *flpt, disp, *fl, lnch;
  char tp[44];
  short int *sortlist;
  MemHandle ah;
  LocalID lid, aiid;

  WinEraseWindow();             /* user feedback */
  maxrow = 0;
  disp = 0;

  WinDrawChars("Getting Directory...", 20, 0, 0);

  memset(sels, 0, 256);
  for (cardno = 0; cardno < MemNumCards(); cardno++) {
    ndb = DmNumDatabases(cardno);
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    for (i = 0; i < ndb; i++) {

      /* TODO: sortprefix should be a global variable */

      lid = DmGetDatabase(cardno, i);
      DmDatabaseInfo(cardno, lid, &tp[SORTPREFIX], &attr, NULL, NULL, NULL,
                     NULL, NULL, (void *) &aiid, NULL, &type, &crea);
      if (!aiid || attr & 1 || (crea != 'TZIP' && crea != 'clpr'))
        continue;

      ah = MemLocalIDToLockedPtr(aiid, cardno);
      memcpy(&lnch, ah, 4);
      MemPtrUnlock(ah);
      if (lnch != 'lnch')
        continue;
      memcpy(tp, &crea, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */

      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmSet(filecard, j, maxrow - j, cardno);
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
  }

  WinDrawChars("Sorting Directory...", 20, 0, 15);

  sortlist = MemPtrNew(maxrow * 2 + 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;

  SysQSort(sortlist, maxrow, 2, fncomp, (Int32) filelp);

  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);

  selection = -1;
  toprow = 0;
}

/* **************************************************************************** */

RectangleType infoico = { {148, 0}
, {10, 10}
};
RectangleType infoln = { {0, 129}
, {160, 13}
};

void settable()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  UInt top;
  Word row, numRows;
  ScrollBarPtr bar;

  WinEraseWindow();
  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  top = toprow;
  numRows = TblGetNumberOfRows(tptr);


  for (n = 0; n < 1; n++)
    TblSetColumnUsable(tptr, n, true);

  for (row = 0; row < numRows; row++, top++) {

    if (top < maxrow)
      TblSetRowData(tptr, row, (ULong) filesort[top]);

    if (top < maxrow) {
      TblSetRowSelectable(tptr, row, true);

      for (n = 0; n < 1; n++) {
        TblSetItemStyle(tptr, row, n, customTableItem);
        TblSetCustomDrawProcedure(tptr, n, TableDrawCell);
      }
      TblMarkRowInvalid(tptr, row);
    } else
      TblSetRowUsable(tptr, row, false);

  }

  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));

  if (maxrow <= numRows)
    SclSetScrollBar(bar, 0, 0, 0, 10);
  else
    SclSetScrollBar(bar, toprow, 0, maxrow - numRows, numRows);

  FrmDrawForm(frm);
  WinInvertRectangle(&infoico, 5);

  top = toprow;
  for (row = 0; row < numRows; row++, top++)
    if (top < maxrow && selection == filesort[top]) {
      TblSelectItem(tptr, row, 0);
      break;
    }
  if (row == numRows)
    selection = -1;
}

/* **************************************************************************** */

void dopage(int down)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow += n * (((down) << 1) - 1);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doscroll()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  ScrollBarPtr bar;
  Word v, mn, mx, ps;

  frm = FrmGetActiveForm();
  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));
  SclGetScrollBar(bar, &v, &mn, &mx, &ps);
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow = v;
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doseek(char val)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  char *c;

  do {
    c = filelp[filesort[++toprow]] + SORTPREFIX;
  } while (toprow < maxrow && *c != val);

  if (toprow == maxrow) {
    toprow = 0;
    c = filelp[filesort[toprow]] + SORTPREFIX;
    while (toprow < maxrow && *c != val) // if rewound, use top if matched
      c = filelp[filesort[++toprow]] + SORTPREFIX;
    if (toprow == maxrow)
      toprow = 0;
  }

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;
  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

DmOpenRef rdb;

void mvrsrc(UInt32 rsrc, int num)
{
  MemHandle ap, sp;
  int len;

  sp = DmGetResource(rsrc, num);
  len = MemHandleSize(sp);
  ap = DmNewResource(rdb, rsrc, num - 1000, len);
  DmWrite(MemHandleLock(ap), 0, MemHandleLock(sp), len);
  MemHandleUnlock(ap);
  MemHandleUnlock(sp);
  DmReleaseResource(ap);
  DmReleaseResource(sp);
}

int newrsrc(unsigned char **ptr, UInt32 rsrc, int rsid)
{
  MemHandle ap;
  int len;

  len = *(*ptr)++ << 8;
  len += (0xff & *(*ptr)++);
  len *= 2;
  if (!len)
    return 1;
  ap = DmNewResource(rdb, rsrc, rsid, len);
  DmWrite(MemHandleLock(ap), 0, *ptr, len);
  MemHandleUnlock(ap);
  DmReleaseResource(ap);
  *ptr += len;
  return 0;
}

void instAIN(char *name) {
  MemHandle ap;

  ap = DmNewResource(rdb, 'tAIN', 1000, strlen(name));
  DmWrite(MemHandleLock(ap), 0, name, strlen(name));
  MemHandleUnlock(ap);
  DmReleaseResource(ap);
}


#include "lbox.h"

static Boolean MainH(EventPtr event)
{
  int eid, i, dest;
  void *ap;
  unsigned char *ptr, *aptr;
  Word cardno, attr;
  UInt32 crea, cre2;
  char buf[64], *fnp;
  LocalID lid, aiid, zlid;
  struct lboxrsrc lbox;
  FormPtr frm;

  switch (event->eType) {
  case frmOpenEvent:
    settable();
    return 1;

  case sclExitEvent:
    doscroll();
    return 1;

  case keyDownEvent:

    switch (event->data.keyDown.chr) {
    case pageUpChr:
    case pageDownChr:
      dopage(event->data.keyDown.chr == pageDownChr);
      return 1;
    default:
      doseek(event->data.keyDown.chr);
      return 0;
    }

  case tblSelectEvent:
    selection = filesort[toprow + event->data.tblSelect.row];
    if (romVersion) {
      FormPtr frm;
      TablePtr tptr;

      sels[selection >> 3] ^= (1 << (selection & 7));

      frm = FrmGetActiveForm();
      tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
      TblUnhighlightSelection(tptr);
      WinEraseRectangle(&infoico, 5);
      FrmDrawForm(frm);
      WinInvertRectangle(&infoico, 5);
      selection = -1;
    }
    return 1;


  case ctlSelectEvent:
    eid = event->data.ctlEnter.controlID;
    switch (eid) {
    case ball:
      doall = 1;
    case bfile:

      ZLSetup;

      frm = FrmGetActiveForm();
      dest = CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bdest)));

      for (i = 0; i < maxrow; i++) {
        if (!doall && !(sels[i >> 3] & (1 << (i & 7))))
          continue;
        cardno = filecard[i];
        fnp = filelp[i] + SORTPREFIX;
        WinEraseRectangle(&infoln, 0);

        lid = DmFindDatabase(cardno, fnp);
        DmDatabaseInfo(cardno, lid, NULL, &attr, NULL, NULL, NULL,
                       NULL, NULL, (void *) &aiid, NULL, NULL, &cre2);


        if (doall && cre2 != 'TZIP')
          continue;

        WinDrawChars(fnp, strlen(fnp), 0, 129);

        /* unzip just enough to get the creator type */
        if (cre2 == 'TZIP') {
          FileHand fd;
          unsigned char ibuf[128], obuf[68];
          z_stream pgpz;

          fd =
            FileOpen(cardno, fnp, 'DATA', 'TZIP',
                     fileModeReadOnly | fileModeAnyTypeCreator, NULL);

          memset(&pgpz, 0, sizeof(pgpz));
          inflateInit2(&pgpz, -15);
          pgpz.next_out = obuf;
          pgpz.avail_out = 68;
          pgpz.avail_in = 0;

          while (pgpz.avail_out) {
            if (!pgpz.avail_in) {
              pgpz.avail_in = fread(ibuf, 1, 128, fd);
              pgpz.next_in = ibuf;
            }
            inflate(&pgpz, Z_PARTIAL_FLUSH);
          }

          fclose(fd);

          memcpy(&crea, &obuf[64], 4);

          inflateEnd(&pgpz);

          WinDrawChars((void *)&crea, 4, 135, 129);
        } else {
          StrIToH(buf, i);
          memcpy(&crea, buf, 4);
        }

        if (fnp[0] == '_') {
          strcpy(buf, fnp);
	  buf[0] = '^';
        } else {
          strcpy(buf, "^");
          strcat(buf, fnp);
        }

        if (DmCreateDatabase(0, buf, crea, 'appl', true)) {
          zlid = DmFindDatabase(0, buf);

          if (zlid)
            DmDeleteDatabase(0, zlid);
          DmCreateDatabase(0, buf, crea, 'appl', true);
        }

        zlid = DmFindDatabase(0, buf);
        rdb = DmOpenDatabase(0, zlid, dmModeReadWrite);

        aptr = ptr = MemLocalIDToLockedPtr(aiid, cardno);
        ptr += 8;

        newrsrc( &ptr, 'tver', 1);

        if( newrsrc( &ptr, 'tAIN', 1000) ) {
	  if (fnp[0] == '_')
	    instAIN(&fnp[1]);
	  else
	    instAIN(fnp);
	}

        newrsrc( &ptr, 'tAIB', 1000);
        newrsrc( &ptr, 'tAIB', 1001);

        ap = DmNewResource(rdb, 'LBOX', 1, sizeof(lbox));
        lbox.cardno = cardno;
        lbox.crea = cre2;
        strncpy(lbox.appn, fnp, 32);
        DmWrite(MemHandleLock(ap), 0, &lbox, sizeof(lbox));
        MemHandleUnlock(ap);
        DmReleaseResource(ap);

        mvrsrc( 'code', 1001);
        mvrsrc( 'code', 1000);
        mvrsrc( 'data', 1000);
        mvrsrc( 'pref', 1000);
        mvrsrc( 'rloc', 1000);


        MemPtrUnlock(aptr);
        DmCloseDatabase(rdb);

        aiid = 0;
        attr &= ~dmHdrAttrLaunchableData;
        /* delete launchability */
        if (dest)
          DmSetDatabaseInfo(cardno, lid, NULL, &attr, NULL, NULL, NULL,
                            NULL, NULL, &aiid, NULL, NULL, &crea);


      }
      ZLTeardown;

      xitapp = 1;
      return 1;

    default:
      return 0;
    }
  default:
    return 0;

  }

}

/* **************************************************************************** */

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  short err;
  int formID;
  FormPtr form = NULL;
  EventType event;
  LocalID lid;
  DmOpenRef scratch;
  Word dbrec;
  VoidHand hand;

  if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
  romVersion = romVersion >= sysMakeROMVersion(3, 2, 0, sysROMStageRelease, 0);
  if (!romVersion)
    doall = 1;

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }
  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");
  dbrec = 0;
  hand = DmNewRecord(scratch, &dbrec, 20480);
  filelist = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048); /* max tar or zip directory size * 4 */
  filedisp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 4096);
  filelp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048);
  filesort = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 1024);
  filecard = MemHandleLock(hand);


  toprow = 0;
  scandbs(0);
  FrmGotoForm(mainform);

  do {

    EvtGetEvent(&event, -1);

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;
    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) {

      default:

      case mainform:
        FrmSetEventHandler(form, MainH);
        break;
      }

    }
    if (form)
      FrmDispatchEvent(&event);
  } while (!xitapp && event.eType != appStopEvent);


  MemPtrUnlock(filedisp);
  MemPtrUnlock(filesort);
  MemPtrUnlock(filelp);
  MemPtrUnlock(filecard);
  MemPtrUnlock(filelist);
  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);
  DmCloseDatabase(scratch);


  return 0;
}
