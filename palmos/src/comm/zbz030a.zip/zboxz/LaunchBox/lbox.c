#include <SystemMgr.h>

#if defined(SDK_VERSION) && SDK_VERSION < 35
#define NON_PORTABLE
#include <SystemPrv.h>
#endif


extern inline void *mcpy(void *dst, const void *src, int num)
{
  register void *ds = dst;
  while (num--)
    *((char *) dst)++ = *((char *) src)++;
  return ds;
}

#include "lbox.h"

UInt32 start()
{
  SysAppInfoType *appInfo;
  void *prevGlobals;
  void *globalsPtr;
  LocalID lid, zlid;
  MemHandle hand;
  UInt16 zcardno, cn;
  struct lboxrsrc *lbox;
  DmSearchStateType sst;
  struct runzip {
    UInt16 cn;
    LocalID li;
    UInt16 cmd;
    void *cmdPBP;
  } *x;

  if (SysAppStartup(&appInfo, &prevGlobals, &globalsPtr))
    return -1;

  if (appInfo->cmd == sysAppLaunchCmdNormalLaunch
      || appInfo->cmd == sysAppLaunchCmdOpenDB
      //  sysAppLaunchCmdFind
      || appInfo->cmd == sysAppLaunchCmdGoTo
      || appInfo->cmd == sysAppLaunchCmdAddRecord
      || appInfo->cmd == sysAppLaunchCmdURLParams
      || appInfo->cmd == sysAppLaunchCmdGoToURL) {

    hand = DmGetResource('LBOX', 1);
    lbox = MemHandleLock(hand);
    cn = lbox->cardno;
    lid = DmFindDatabase(cn, lbox->appn);

    DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', lbox->crea, true,
                                   &zcardno, &zlid);
    MemHandleUnlock(hand);

    if (zlid) {

      x = MemPtrNew(sizeof(struct runzip));
      x->cn = cn;
      x->li = lid;
      x->cmd = appInfo->cmd;
      x->cmdPBP = NULL;

      if (appInfo->cmdPBP) {
        x->cmdPBP = MemPtrNew(MemPtrSize(appInfo->cmdPBP));
        mcpy(x->cmdPBP, appInfo->cmdPBP, MemPtrSize(appInfo->cmdPBP));
        MemPtrSetOwner(x->cmdPBP, 0);
      }

      MemPtrSetOwner(x, 0);
      SysUIAppSwitch(zcardno, zlid, sysAppLaunchCmdOpenDB, x);

    }
  }

  SysAppExit(appInfo, prevGlobals, globalsPtr);
  return 0;
}
