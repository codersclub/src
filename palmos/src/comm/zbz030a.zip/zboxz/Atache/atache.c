#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <Unix/sys_socket.h>

#include "stringil.h"
#include "stdio2.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

char httphead1[] =
  "HTTP/1.1 200 OK\nConnection: close\nContent-type: application/octet-stream\n\n";

char httpheadh[] =
  "HTTP/1.1 200 OK\nConnection: close\nContent-type: text/html\n\n";

char httpheadt[] =
  "HTTP/1.1 200 OK\nConnection: close\nContent-type: text/plain\n\n";

char httpheadg[] =
  "HTTP/1.1 200 OK\nConnection: close\nContent-type: image/png\n\n";

char httpheadx[] = "HTTP/1.1 403 Forbidden\n\n";

char httpheady[] = "HTTP/1.1 404 Not Found\n\n";

char htmlhead[] =
  "<html><head><title>MyOmniSkyPalmV</title></head><body><table>\n";
char htmlmid[] = "<tr><th>Database<th>Size\n";
char htmltail[] = "\n</table></body></html>\n";


DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  unsigned char *buf;
  NetSocketAddrType addr;

  NetSocketRef fd, fd0;
  int endit;
  Int16 addrlen;
  NetSocketAddrINType *naddr;
  UInt16 cardno;

  Err err, err2;
  Byte allup;
  LocalID lid;
  int i;
  UInt32 type, crea;

  if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  fd = -1, fd0 = -1;
  endit = 0;
  addrlen = sizeof(addr);
  naddr = &addr;
  cardno = 0;
  buf = MemPtrNew(512);

  naddr->family = PF_INET;
  naddr->port = 80;
  naddr->addr = 0UL;

  AppNetRefnum = 0;

  err = SysLibFind("Net.lib", &AppNetRefnum);
  err |= NetLibOpen(AppNetRefnum, &err2);
  if (!err && !err2)
    NetLibConnectionRefresh(AppNetRefnum, true, &allup, &err2);

  if (err | err2) {
    err = NetLibClose(AppNetRefnum, true);
    err = SysLibFind("Net.lib", &AppNetRefnum);
    err |= NetLibOpen(AppNetRefnum, &err2);
    NetLibConnectionRefresh(AppNetRefnum, true, &allup, &err2);
  }
  if (!err && !err2)
    return 1;

  AppNetTimeout = 1000;

  fd0 = socket(AF_INET, SOCK_STREAM, IPPROTO_TCP);

  if (fd0 < 0)
    return 1;

  bind(fd0, &addr, addrlen);
  fd = listen(fd0, 1);
  if (fd != 0)
    return 1;

  do {

    fd = -1;
    AppNetTimeout = 50;

    for (;;) {
      WinDrawChars("Wait      ", 10, 0, 15);
      {
        EventType e;
        do {
          EvtGetEvent(&e, 0);
          SysHandleEvent(&e);
          if (e.eType == appStopEvent)
            endit = 1;
        } while (e.eType != nilEvent);
      }
      if (endit) {
        WinDrawChars("Exit      ", 10, 0, 15);
        break;
      }
      fd = accept(fd0, &addr, &addrlen);

      WinDrawChars("Acpt      ", 10, 0, 15);

      if (fd >= 0)
        break;

    }

    AppNetTimeout = -1L;

    if (fd < 0)
      break;

    WinDrawChars("Connect   ", 10, 0, 15);

    recv(fd, buf, 512, 0);

    WinDrawChars(&buf[5], 80, 0, 0);

    for (i = 5; i < 40; i++)
      if (!strncmp(&buf[i], " HTTP/1.", 8)) {
        buf[i] = 0;
        break;
      }
    WinDrawChars(&buf[5], strlen(&buf[5]), 0, 30);

    if (buf[5]) {

      if (buf[5] == '0' && !buf[6])
        endit = 1;

      else {
        if ((lid = DmFindDatabase(cardno, &buf[5]))) {
          UInt16 attr;
          DmDatabaseInfo(cardno, lid, NULL, &attr, NULL, NULL, NULL, NULL, NULL,
                         NULL, NULL, &type, &crea);

          if (type != 'DATA' || (crea != 'BOXR' && crea != 'ATCH' && crea != 'TAPZ')
              || attr & dmHdrAttrCopyPrevention || !(attr & dmHdrAttrStream))
            send(fd, httpheadx, strlen(httpheadx), 0);
          else {
#define WRTLIM 512

            FILE *ifd;
            unsigned char ibuf[WRTLIM];
            int ic, oc, t;

            if (!strcmp(&buf[i - 4], ".png"))
              send(fd, httpheadg, strlen(httpheadg), 0);
            if (!strcmp(&buf[i - 5], ".html"))
              send(fd, httpheadh, strlen(httpheadh), 0);
            if (!strcmp(&buf[i - 4], ".txt"))
              send(fd, httpheadt, strlen(httpheadt), 0);

            ifd = FileOpen(0, &buf[5], type, crea, fileModeReadOnly, NULL);

            while (!feof(ifd)) {
              ic = fread(ibuf, 1, WRTLIM, ifd);
              if (ic <= 0)
                break;
              oc = 0;
              while (oc < ic) {
                t = send(fd, &ibuf[oc], ic - oc, 0);
                if (t < 0)
                  break;
                oc += t;
              }
            }

            fclose(ifd);

          }
        }

        else
          send(fd, httpheadx, strlen(httpheady), 0);

      }
    } else {
      send(fd, htmlhead, strlen(htmlhead), 0);
      send(fd, htmlmid, strlen(htmlmid), 0);

      {
        LocalID lid, aiid, siid;
        int i;
        UInt16 cardno = 0;
        char name[36];

        UInt16 num, attr, vers;
        UInt32 cr, md, bk, mn, nrec, sz;
        num = DmNumDatabases(cardno);

        for (i = 0; i < num; i++) {
          lid = DmGetDatabase(cardno, i);

          DmDatabaseInfo(cardno, lid, name, &attr, &vers, &cr, &md, &bk, &mn,
                         &aiid, &siid, &type, &crea);

          if (!(attr & dmHdrAttrStream) || type != 'DATA'
              || (crea != 'ATCH' && crea != 'BOXR' && crea != 'ATCH'))
            continue;

          strcpy(buf, "\n<tr><td><a HREF=\"");
          strcat(buf, name);
          strcat(buf, "\">");

          strcat(buf, name);
          strcat(buf, "</a><td>");

          DmDatabaseSize(cardno, lid, &nrec, &sz, NULL);
          StrIToA(name, sz);
          strcat(buf, name);

          send(fd, buf, strlen(buf), 0);

        }
      }
      send(fd, htmltail, strlen(htmltail), 0);
    }

    WinDrawChars("DONE      ", 10, 0, 15);
    close(fd);
  }
  while (!endit);

  if (fd0 != -1)
    close(fd0);

  /* this will shut down the modem */
#if 0
  err = NetLibClose(AppNetRefnum, true);
  SysTaskDelay(200);
#endif

  return 0;
}
