#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>

#include "stringil.h"
#include "stdio2.h"

char pqahead[] = {
  'l', 'n', 'c', 'h',
  0, 3, 0x80, 1,
  0, 1, '1', 0,                 // len/2, version
  0, 1, 'X', 0,                 // len/2, Title
  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
  0, 0,                         // len/2, icon
  0, 0                          // len/2, smallicon
};

char pqatwo[] = {
  0, 0, 0, 16,                  /*url offset */
  0, 1,                         /* url length */
  0, 0, 0, 18,                  /*html offset */
  0, 1,                         /* html length */
  4, 1,                         /* content, compression */
  0, 0,
  'X', 0,
};

char bbuf[512];

char *d;
int len, count;

void putbits(int i, unsigned long val)
{
  while (--i >= 0) {
    if ((1 << i) & (val))
      *d |= 1 << count;
    if (count-- == 0) {
      count = 7;
      len++;
      d++;
    }
  }
}

void putstring(char *c)
{
  while (*c) {
    if (*c >= 'a' && *c <= 'z')
      putbits(5, *c + 6 - 'a');
    else if (*c == ' ')
      putbits(5, 5);
    else {
      putbits(5, 2);
      putbits(8, *c);
    }
    c++;
  }
}

LocalID lid;

int MakePQA(char *url, char *title, int img)
{
  LocalID aiid;
  UInt16 num, attr;
  UInt32 asz;
  DmOpenRef db;
  void *ap, *xp;

  lid = DmFindDatabase(0, title);
  if (lid)
    DmDeleteDatabase(0, lid);
  DmCreateDatabase(0, title, 'clpr', 'pqa ', 0);
  lid = DmFindDatabase(0, title);
  attr = 0x200;
  DmSetDatabaseInfo(0, lid, NULL, &attr, NULL, NULL, NULL,
                    NULL, NULL, NULL, NULL, NULL, NULL);
  WinDrawChars("/", 1, 150, 0);
  db = DmOpenDatabase(0, lid, dmModeReadWrite);

  if( !strcmp( &title[strlen(title)-4],".pqa") )
    title[strlen(title)-4] = 0;
  if( !strcmp( &title[strlen(title)-4],".PQA") )
    title[strlen(title)-4] = 0;

  asz = 50;
  ap = DmNewHandle(db, asz);
  aiid = MemHandleToLocalID(ap);
  xp = MemHandleLock(ap);
  pqahead[13] = ( strlen(title) + 1 ) / 2;
  strcpy(&pqahead[14],title);
  DmWrite(xp, 0, pqahead, asz);

  MemHandleUnlock(ap);
  DmSetDatabaseInfo(0, lid, NULL, NULL, NULL, NULL, NULL, NULL,
                    NULL, &aiid, NULL, NULL, NULL);

  num = 0xffff;
  ap = DmNewRecord(db, &num, 1024);
  xp = MemHandleLock(ap);

  memset(bbuf, 0, 512);

  d = bbuf;
  count = 7;
  len = 1;

  putstring(title);        //title
  putbits(5, 0);

  if( !img ) {
    putbits(5, 1);                //Link
    putbits(8, 17);
    putbits(2, 0);
    putbits(8, 0x21);

    putstring(url);               //URL
    putbits(5, 0);

    putstring("go");              //button
    putbits(5, 0);
  } else {

    putbits(5, 1);                //Img URL
    putbits(8, 0x34);
    putbits(8, 0x20);

    putstring(url);               //URL
    putbits(5, 0);
  }

  putbits(5, 1);                //EOPQA
  putbits(8, 0x71);

  pqatwo[11] = len + 6;

  DmWrite(xp, 0, pqatwo, 18);
  DmWrite(xp, 18, bbuf, len);

  MemHandleUnlock(ap);
  DmResizeRecord(db, num, len + 18);
  DmReleaseRecord(db, num, false);
  DmCloseDatabase(db);
  return 0;
}

FormPtr form = NULL;

int exitflg;
char *desturl[512];
Boolean handleit(EventPtr event)
{
  FieldPtr tf1;
  VoidHand tf2;
  unsigned char *tp1,*tp2;
  unsigned int eid;

  switch (event->eType) {

  case frmOpenEvent:
    tf2 = MemHandleNew(120);
    tp1 = MemHandleLock(tf2);
    strcpy(tp1, "http://www..com/~");
    MemHandleUnlock(tf2);
    tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
    FldSetTextHandle(tf1, tf2);

    tf2 = MemHandleNew(32);
    tp1 = MemHandleLock(tf2);
    strcpy(tp1, "MyNewPQA.pqa");
    MemHandleUnlock(tf2);
    tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1010));
    FldSetTextHandle(tf1, tf2);

    FrmDrawForm(form);
    FrmSetFocus(form, FrmGetObjectIndex(form, 1001));
    return 1;
  case ctlSelectEvent:

    eid = event->data.ctlEnter.controlID;

    /* process form */

    if (eid == 1004 || eid == 1007) {

      tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
      tp1 = FldGetTextPtr(tf1);

      tf2 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1010));
      tp2 = FldGetTextPtr(tf2);

      MakePQA(tp1, tp2, eid != 1004);
      exitflg = 2;

    }

    if (eid == 1005)
      exitflg = 1;

    if (eid == 1006) {

      tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
      tp1 = FldGetTextPtr(tf1);
      strcpy( desturl, tp1 );
      exitflg = 3;

    }

    return 1;
  default:
    return 0;
  }
  return 0;
}


DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType event;
  Err err;
  int formID;

  if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  FrmGotoForm(1000);
  exitflg = 0;

  do {
    EvtGetEvent(&event, -1);

    if (event.eType == nilEvent)
      continue;

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;

    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      FrmSetEventHandler(form, (FormEventHandlerPtr) handleit);
    }
    if (form)
      FrmDispatchEvent(&event);
  }
  while (event.eType != appStopEvent && !exitflg);


  if (exitflg == 2) {
    struct {
      UInt16 cn;
      LocalID li;
    } *x;
    x = MemPtrNew(sizeof(*x));
    x->cn = 0;
    x->li = lid;
    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "Clipper");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdOpenDB, x);
  }

  if (exitflg == 3) {
    char *x;
    x = MemPtrNew(strlen(desturl)+1);
    strcpy(x,desturl);
    MemPtrSetOwner(x, 0);
    lid = DmFindDatabase(0, "Clipper");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdGoToURL, x);
  }

  return 0;
}
