#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "zlib.h"

static unsigned short xtons(unsigned short y ) {
  unsigned short x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 8;
  x |= *c;
  return x;
}

static unsigned long xtonl(unsigned long y ) {
  unsigned long x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 24;
  x |= *c++ << 16;
  x |= *c++ << 8;
  x |= *c;
  return x;
}


#pragma pack(2)

struct prchead {
  char name[32];                //0-32
  short int attr;               //32-33
  short int vers;               //34-35
  long int cr, md, bkt;         //times 36-47
  long int mn, app, sort;       // zero 48-59 - zero for prcs.
  long int type, crea;          //60-67
  long int uidseed, nxrec;      //68-75 - uidseed rand, nxrec zero;
  short int nrecs;              //76-78
} head;

int zipsync(FILE * infd, char *title, FILE * outfd)
{

  unsigned long cofst, xlong, xlong2, xid;
  unsigned char *bbuf;
  long bbuflen;
  int i, maxsect;
  unsigned char *outbuf, *op, *zippo, obuf[12];
  int isrsrc;
  unsigned short xshort;
  long fsize;
  z_stream pgpz;


  if (!(bbuf = malloc(65536)))
    return -1;

  fseek(infd, 0, SEEK_END);
  xlong = ftell(infd);
  fseek(infd, 0, SEEK_SET);

  outbuf = malloc(xlong);
  zippo = malloc(xlong);

  op = outbuf;

  fread(&head, 1, sizeof(head), infd);

  memcpy(op, &head, sizeof(head));
  op += sizeof(head);

  maxsect = xtons(head.nrecs);

  isrsrc = 1 & xtons(head.attr);

  xlong2 = ftell(infd);

  fread(&xlong, 1, 4, infd);
  if (isrsrc) {
    fread(&xlong, 1, 2, infd);
    fread(&xlong, 1, 4, infd);
  }
  if ((cofst = xtonl(head.app))) {
    if (!(bbuflen = xtonl(head.sort))) {
      if (maxsect) {
        bbuflen = xtonl(xlong);
        bbuflen = bbuflen - cofst;
      } else
        bbuflen = 65534;
    }
    if (bbuflen > 65534)
      exit(-1);
#ifdef NOISY
    fprintf(stderr, "appl len: %ld\n", bbuflen);
#endif
    fseek(infd, cofst, SEEK_SET);
    bbuflen = fread(bbuf, 1, bbuflen, infd);

    *op++ = bbuflen >> 8;
    *op++ = bbuflen;
    memcpy(op, bbuf, bbuflen);
    op += bbuflen;


  } else {
    *op++ = 0;
    *op++ = 0;
  }

  if ((cofst = xtonl(head.sort))) {
    if (maxsect) {
      bbuflen = xtonl(xlong);
      bbuflen = bbuflen - cofst;
    } else
      bbuflen = 65534;

    if (bbuflen > 65534)
      exit(-1);
#ifdef NOISY
    fprintf(stderr, "sort len: %ld\n", bbuflen);
#endif
    fseek(infd, cofst, SEEK_SET);
    bbuflen = fread(bbuf, 1, bbuflen, infd);

  } else {
    *op++ = 0;
    *op++ = 0;
  }

  fseek(infd, xlong2, SEEK_SET);


  cofst = xtonl(xlong);

  for (i = 0; i < maxsect; i++) {

    if (isrsrc) {
      fread(op, 1, 6, infd);

      op += 6;

      if (i + 1 != maxsect) {
        xlong = ftell(infd);
        fseek(infd, xlong + 10, SEEK_SET);
        fread(&xlong2, 1, 4, infd);
        fseek(infd, xlong + 4, SEEK_SET);

        bbuflen = xtonl(xlong2);
        bbuflen = bbuflen - cofst;
      } else
        bbuflen = 65534;


    } else {


      if (i + 1 != maxsect) {
        xlong = ftell(infd);
        fseek(infd, xlong + 8, SEEK_SET);
        fread(&xlong2, 1, 4, infd);
        fseek(infd, xlong + 4, SEEK_SET);

        bbuflen = xtonl(xlong2);
        bbuflen = bbuflen - cofst;
      } else {
        bbuflen = 65534;
        fread(&xlong2, 1, 4, infd);
      }

      fread(op, 1, 4, infd);

      op += 4;

    }


    if (bbuflen > 65534)
      exit(-1);

    xlong = ftell(infd);
    fseek(infd, cofst, SEEK_SET);
    bbuflen = fread(bbuf, 1, bbuflen, infd);
    fseek(infd, xlong, SEEK_SET);

    cofst = xtonl(xlong2);

    *op++ = bbuflen >> 8;
    *op++ = bbuflen;

    memcpy(op, bbuf, bbuflen);
    op += bbuflen;

  }
  fclose(infd);

  fsize = op - outbuf;


  memset(&pgpz, 0, sizeof(pgpz));
  deflateInit2(&pgpz, 9, Z_DEFLATED, -15, 8, 0);
  pgpz.next_in = outbuf;
  pgpz.avail_in = fsize;
  pgpz.next_out = zippo;
  pgpz.avail_out = fsize;
  deflate(&pgpz, Z_FINISH);
  deflateEnd(&pgpz);
  free(outbuf);

  i = fsize - pgpz.avail_out;
#ifdef NOISY
  fprintf(stderr, "Compressed: %ld%%\n", 100 - i * 100 / fsize);
#endif
  fsize = i;
  maxsect = fsize / 4096 + 1;
  cofst = 80 + 8 * maxsect;

  fwrite(title, 1, 32, outfd);

  memset(bbuf, 0, 4);
  bbuf[0] = 2;
  bbuf[1] = 0x88;
  bbuf[3] = 1;
  fwrite(bbuf, 1, 4, outfd);
  //36
  xlong = time(NULL) + ((66 * 365 + 17) * 24 * 3600UL);
  xlong = xtonl(xlong);

  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);
  //48
  memset(bbuf, 0, 12);
  fwrite(bbuf, 1, 12, outfd);

  //60
  fwrite("DATA", 1, 4, outfd);
  fwrite("SZIP", 1, 4, outfd);

  bbuf[0] = 0x28;
  fwrite(bbuf, 1, 8, outfd);

  xshort = xtons(maxsect);
  fwrite(&xshort, 1, 2, outfd);

  xid = 0x40000000UL + (rand() & 0x7fffffUL);

  while (maxsect--) {
    xlong = xtonl(cofst);
    fwrite(&xlong, 1, 4, outfd);
    xlong = xtonl(xid++);
    fwrite(&xlong, 1, 4, outfd);
    cofst += 4104;
  }

  xshort = 0;
  fwrite(&xshort, 1, 2, outfd);

  strcpy(obuf, "DBLK");
  obuf[5] = obuf[7] = obuf[4] = 0;
  obuf[6] = 0x10;

  op = zippo;

  while (fsize > 4096) {
    fwrite(obuf, 1, 8, outfd);
    fwrite(op, 1, 4096, outfd);
    op += 4096;
    fsize -= 4096;
  }

  fwrite(obuf, 1, 4, outfd);
  xlong = xtonl(fsize);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(op, 1, fsize, outfd);

  fclose(outfd);
  free(zippo);

  return 0;
}
