#include <stdio.h>
#include <string.h>

static unsigned short htons(unsigned short y ) {
  unsigned short x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 8;
  x |= *c;
  return x;
}

static unsigned long htonl(unsigned long y ) {
  unsigned long x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 24;
  x |= *c++ << 16;
  x |= *c++ << 8;
  x |= *c;
  return x;
}

int unbox(FILE * infd, FILE * outfd)
{
  unsigned char bbuf[5000];
  unsigned long xlong;
  unsigned short xshort;
  int i;

  fseek(infd, 76, SEEK_SET);
  fread(&xshort, 1, 2, infd);
  xshort = htons(xshort);
  fread(&xlong, 1, 4, infd);
  xlong = htonl(xlong);
  fseek(infd, xlong, SEEK_SET);

  for (i = 0; i < xshort; i++) {
    fread(bbuf, 1, 4, infd);
    if ( strncmp(bbuf, "DBLK", 4))
      exit(-2);
    fread(&xlong, 1, 4, infd);
    xlong = htonl(xlong);
    xlong = fread(bbuf, 1, xlong, infd);
    fwrite(bbuf, 1, xlong, outfd);
  }
  fclose(outfd);
  fclose(infd);

  return 0;
}
