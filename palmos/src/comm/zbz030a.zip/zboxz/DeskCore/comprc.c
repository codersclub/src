#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>

#include "zlib.h"

static unsigned short xtons(unsigned short y ) {
  unsigned short x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 8;
  x |= *c;
  return x;
}

static unsigned long xtonl(unsigned long y ) {
  unsigned long x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 24;
  x |= *c++ << 16;
  x |= *c++ << 8;
  x |= *c;
  return x;
}

char pqahead[] = {
  'l', 'n', 'c', 'h',
  0, 3, 0x80, 1,
};

char bbuf[65534];

int comprc(FILE * infd, FILE * outfd)
{
  unsigned long cofst;
  char obuf[4200];
  unsigned short xshort;
  unsigned long xlong, xid, fsize;
  long bbuflen;
  int maxsect, i;
  char title[40], *inbuf, *outbuf, dbname[36];
  z_stream pgpz;
  char *tAIB1 = NULL, *tAIB0 = NULL, *tAIN = NULL, *tver = NULL;
  int ntAIB1 = 0, ntAIB0 = 0, ntAIN = 0, ntver = 0;


  memset(dbname, 0, 36);
  fread(dbname, 1, 32, infd);
  fseek(infd, 76, SEEK_SET);
  fread(&xshort, 1, 2, infd);   /* num resources */

  maxsect = xtons(xshort);

  for (i = 0; i < maxsect; i++) {
    fread(title, 1, 4, infd);
    fread(&xshort, 1, 2, infd);
    xshort = xtons(xshort);
    sprintf(&title[4], "%04x", xshort);

    fread(&xlong, 1, 4, infd);
    cofst = xtonl(xlong);
    xlong = ftell(infd);

    if (i + 1 != maxsect) {
      fread(&bbuflen, 1, 4, infd);
      fread(&bbuflen, 1, 2, infd);
      fread(&bbuflen, 1, 4, infd);
      bbuflen = xtonl(bbuflen);
      bbuflen = bbuflen - cofst;
    } else
      bbuflen = 65534;

    fseek(infd, cofst, SEEK_SET);
    bbuflen = fread(bbuf, 1, bbuflen, infd);
    fseek(infd, xlong, SEEK_SET);

    if (!strcmp("tAIN03e8", title)) {
      ntAIN = (bbuflen + 1) / 2;
      tAIN = malloc(ntAIN * 2);
      memcpy(tAIN, bbuf, ntAIN * 2);
#ifdef NOISY
      fprintf(stderr, "\tName:%s\n", bbuf);
#endif
    }

    if (!strcmp("tAIB03e8", title)) {
      ntAIB0 = (bbuflen + 1) / 2;
      tAIB0 = malloc(ntAIB0 * 2);
      memcpy(tAIB0, bbuf, ntAIB0 * 2);
#ifdef NOISY
      fprintf(stderr, "\tIcon\n");
#endif
    }

    if (!strcmp("tAIB03e9", title)) {
      ntAIB1 = (bbuflen + 1) / 2;
      tAIB1 = malloc(ntAIB1 * 2);
      memcpy(tAIB1, bbuf, ntAIB1 * 2);
#ifdef NOISY
      fprintf(stderr, "\tSmall Icon\n");
#endif
    }

    if (!strcmp("tver0001", title)) {
      ntver = (bbuflen + 1) / 2;
      tver = malloc(ntver * 2);
      memcpy(tver, bbuf, ntver * 2);
#ifdef NOISY
      fprintf(stderr, "\tVersion:%s\n", bbuf);
#endif
    }

  }

  fseek(infd, 0, SEEK_END);
  fsize = ftell(infd);
  fseek(infd, 0, SEEK_SET);

  inbuf = malloc(fsize);
  outbuf = malloc(fsize + 10);

  memset(&pgpz, 0, sizeof(pgpz));
  deflateInit2(&pgpz, 9, Z_DEFLATED, -15, 8, 0);

  pgpz.next_in = inbuf;
  pgpz.avail_in = fsize;
  fread(inbuf, 1, fsize, infd);
  pgpz.next_out = outbuf;
  pgpz.avail_out = fsize + 10;
  deflate(&pgpz, Z_FINISH);
  deflateEnd(&pgpz);

  i = fsize + 10 - pgpz.avail_out;
#ifdef NOISY
  fprintf(stderr, "Compressed: %ld%%\n", 100 - i * 100 / fsize);
#endif
  fsize = i;

  maxsect = fsize / 4096 + 1;
  cofst = 80 + 8 * maxsect;

  fwrite("_", 1, 1, outfd);
  fwrite(dbname, 1, 31, outfd);

  memset(bbuf, 0, 4);
  bbuf[0] = 2;
  bbuf[1] = 0x88;
  bbuf[3] = 1;
  fwrite(bbuf, 1, 4, outfd);
  //36
  xlong = time(NULL) + ((66 * 365 + 17) * 24 * 3600UL);
  xlong = xtonl(xlong);

  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);
  //48
  memset(bbuf, 0, 12);
  fwrite(bbuf, 1, 4, outfd);
  xlong = xtonl(cofst);
  fwrite(&xlong, 1, 4, outfd);


  cofst += 8 + 8 + ntAIB0 * 2 + ntAIB1 * 2 + ntAIN * 2 + ntver * 2;

  fwrite(bbuf, 1, 4, outfd);

  //60
  fwrite("DATA", 1, 4, outfd);
  fwrite("TZIP", 1, 4, outfd);

  bbuf[0] = 0x28;
  fwrite(bbuf, 1, 8, outfd);

  xshort = xtons(maxsect);
  fwrite(&xshort, 1, 2, outfd);

  xid = 0x40000000UL + (rand() & 0x7fffffUL);


  while (maxsect--) {
    xlong = xtonl(cofst);
    fwrite(&xlong, 1, 4, outfd);
    xlong = xtonl(xid++);
    fwrite(&xlong, 1, 4, outfd);
    cofst += 4104;
  }

  xshort = 0;
  fwrite(&xshort, 1, 2, outfd);

  fwrite(pqahead, 1, 8, outfd);

  xshort = xtons(ntver);
  fwrite(&xshort, 1, 2, outfd);
  if (ntver) {
    fwrite(tver, 1, ntver * 2, outfd);
    free(tver);
  }

  xshort = xtons(ntAIN);
  fwrite(&xshort, 1, 2, outfd);
  if (ntAIN) {
    fwrite(tAIN, 1, ntAIN * 2, outfd);
    free(tAIN);
  }

  xshort = xtons(ntAIB0);
  fwrite(&xshort, 1, 2, outfd);
  if (ntAIB0) {
    fwrite(tAIB0, 1, ntAIB0 * 2, outfd);
    free(tAIB0);
  }

  xshort = xtons(ntAIB1);
  fwrite(&xshort, 1, 2, outfd);
  if (ntAIB1) {
    fwrite(tAIB1, 1, ntAIB1 * 2, outfd);
    free(tAIB1);
  }

  tAIB1 = NULL, tAIB0 = NULL, tAIN = NULL, tver = NULL;
  ntAIB1 = 0, ntAIB0 = 0, ntAIN = 0, ntver = 0;

  strcpy(obuf, "DBLK");
  obuf[5] = obuf[7] = obuf[4] = 0;
  obuf[6] = 0x10;

  while (fsize > 4096) {
    fwrite(obuf, 1, 8, outfd);
    fwrite(outbuf, 1, 4096, outfd);
    outbuf += 4096;
    fsize -= 4096;
  }

  fwrite(obuf, 1, 4, outfd);
  xlong = xtonl(fsize);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(outbuf, 1, fsize, outfd);

  fclose(infd);
  fclose(outfd);

  return 0;
}
