#include <stdio.h>
#include <string.h>
#include <time.h>
#include <stdlib.h>


static unsigned short htons(unsigned short y ) {
  unsigned short x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 8;
  x |= *c;
  return x;
}

static unsigned long htonl(unsigned long y ) {
  unsigned long x;
  unsigned char *c = (unsigned char *)&y;
  x = *c++ << 24;
  x |= *c++ << 16;
  x |= *c++ << 8;
  x |= *c;
  return x;
}

int box(FILE * infd, const char *fname, FILE * outfd)
{

  unsigned long cofst;
  char bbuf[5000];
  unsigned short xshort;
  unsigned long xlong, xid;
  long bbuflen;
  int maxsect;


  memset(bbuf, 0, 32);
  if (strlen(fname) < 32)
    strcpy(bbuf, fname);
  else
    strcpy(bbuf, &fname[strlen(fname) - 32]);

  fwrite(bbuf, 1, 32, outfd);

  memset(bbuf, 0, 4);
  bbuf[1] = 0x88;
  bbuf[3] = 1;
  fwrite(bbuf, 1, 4, outfd);

  xlong = time(NULL) + ((66 * 365 + 17) * 24 * 3600UL);
  xlong = htonl(xlong);

  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(&xlong, 1, 4, outfd);

  memset(bbuf, 0, 12);
  fwrite(bbuf, 1, 12, outfd);

  fwrite("DATA", 1, 4, outfd);
  fwrite("BOXR", 1, 4, outfd);

  bbuf[0] = 0x28;
  fwrite(bbuf, 1, 8, outfd);

  fseek(infd, 0, SEEK_END);
  xlong = ftell(infd);
  fseek(infd, 0, SEEK_SET);

  maxsect = xlong / 4096 + 1;
  xshort = htons(maxsect);
  fwrite(&xshort, 1, 2, outfd);

  cofst = 80 + 8 * maxsect;

  xid = 0x40000000UL + (rand() & 0x7fffffUL);

  strcpy(bbuf, "DBLK");
  bbuf[5] = bbuf[7] = 0;
  bbuf[6] = 0x10;

  while (maxsect--) {
    xlong = htonl(cofst);
    fwrite(&xlong, 1, 4, outfd);
    xlong = htonl(xid++);
    fwrite(&xlong, 1, 4, outfd);
    cofst += 4104;
  }

  xshort = 0;
  fwrite(&xshort, 1, 2, outfd);

  for (;;) {

    bbuflen = fread(&bbuf[8], 1, 4096, infd);

    if (bbuflen != 4096)
      break;

    fwrite(bbuf, 1, bbuflen + 8, outfd);
  }
  if (bbuflen < 0)
    exit(-3);

  fwrite(bbuf, 1, 4, outfd);
  xlong = htonl(bbuflen);
  fwrite(&xlong, 1, 4, outfd);
  fwrite(&bbuf[8], 1, bbuflen, outfd);

  fclose(infd);
  fclose(outfd);
  return 0;

}
