#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include <INetMgr.h>
#include <CTP.h>

#include "stringil.h"
#include "stdio2.h"

int GetURL(char *host)
{
  FILE *fd;
  UInt16 INRef, CfIn;

  VoidHand inh, sock;
  Err err;
  unsigned long len, lact;
  UInt32 set;
  char *buf, *fnp;

  /* bypass until URL */
  while (*host && strncmp(host, "http://", 7))
    host++;

  if (!*host)
    return 2;

  err = SysLibFind("INet.lib", &INRef);

  INetLibConfigIndexFromName(INRef, inetCfgNameCTPDefault, &CfIn);

  err = INetLibOpen(INRef, CfIn, 0, 0, 0, &inh);
  set = 64000;
  err |= INetLibSettingSet(INRef, inh, inetSettingMaxRspSize, &set, 4);
  set = ctpConvNone;
  err |= INetLibSettingSet(INRef, inh, inetSettingConvAlgorithm, &set, 4);
  err |= INetLibURLOpen(INRef, inh, host, NULL, &sock, 2000, 0);

  if (err) {
    INetLibClose(INRef, inh);
    return 1;
  }

  WinDrawChars("Open      ", 10, 0, 112);

  fnp = host;
  if (strlen(host) > 30)
    fnp += strlen(host) - 30;

  fd = FileOpen(0, fnp, 'DATA', 'BRWS', fileModeReadWrite, NULL);

  len = 0;
  buf = MemPtrNew(2050);
  for (;;) {

    WinDrawChars("get     ", 8, 0, 112);

    err = INetLibSockRead(INRef, sock, buf, 2048, &lact, 3000);

    if (!lact)
      break;

    if (err) {
      StrIToH(buf, err);
      strcat(buf, "    ");
      WinDrawChars(buf, strlen(buf), 0, 100);
      SysTaskDelay(200);
      break;
    }

    len += lact;

    WinDrawChars("More      ", 10, 0, 112);
    if (lact != fwrite(buf, 1, lact, fd)) {
      WinDrawChars("WERR      ", 10, 0, 100);
      fclose(fd);
      unlink(fnp);
      INetLibClose(INRef, inh);
      MemPtrFree(buf);
      SysTaskDelay(200);
      return 3;
    }

    StrIToA(buf, len);
    strcat(buf, "    ");
    WinDrawChars(buf, strlen(buf), 0, 124);
  }

  MemPtrFree(buf);
  INetLibClose(INRef, inh);
  fclose(fd);

  if (!len) {
    unlink(fnp);
    return 1;
  }

  return 0;
}

FormPtr form = NULL;

Boolean handleit(EventPtr event)
{
  FieldPtr tf1;
  unsigned char *tp1;
  unsigned int eid;

  switch (event->eType) {

  case frmOpenEvent:
    FrmDrawForm(form);
    FrmSetFocus(form, FrmGetObjectIndex(form, 1001));
    return 1;

  case ctlSelectEvent:

    eid = event->data.ctlEnter.controlID;
    /* process form */
    if (eid == 1005) {

      tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
      tp1 = FldGetTextPtr(tf1);

      GetURL(tp1);
      WinEraseWindow();
      FrmDrawForm(form);
    }
    return 1;
  default:
    return 0;
  }
  return 0;
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  LocalID lid;
  EventType event;
  Err err;
  Word fid;
  FormPtr ofrm;
  VoidPtr textf;
  VoidHand thand;
  UInt16 cardno;
  DmSearchStateType sst;

  if (cmdPBP && strlen(cmdPBP)) {

    if (cmd != sysAppLaunchCmdURLParams && cmd != sysAppLaunchCmdNormalLaunch)
      return 0;

    // normal launch for palm:, URLP for palmcall:
    ofrm = FrmGetActiveForm(); //palmcall

    // display form here

    form = FrmInitForm(1000);
    FrmSetActiveForm(form);
    thand = MemHandleNew(strlen(cmdPBP) + 1);
    strcpy(MemHandleLock(thand), cmdPBP);
    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
    FldSetTextHandle(textf, (Handle) thand);
    FrmDrawForm(form);

    err = GetURL(cmdPBP);

    FrmEraseForm(form);
    FrmDeleteForm(form);

    if (cmd == sysAppLaunchCmdURLParams) {
      if (ofrm)
	FrmSetActiveForm(ofrm);
      return err;               // palmcall, go back..
    }

    // Otherwise run zboxz - later send cmdPBP to dowloaded file
    if( !DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'BOXR', true,
					&cardno, &lid))
      SysUIAppSwitch(cardno, lid, sysAppLaunchCmdNormalLaunch, NULL);

  } else { //Manual mode

    if (cmd != sysAppLaunchCmdNormalLaunch)
      return 0;

    FrmGotoForm(1000);

    do {
      EvtGetEvent(&event, -1);

      if (SysHandleEvent(&event))
        continue;
      if (MenuHandleEvent((void *) 0, &event, &err))
        continue;

      if (event.eType == frmLoadEvent) {
        fid = event.data.frmLoad.formID;
        form = FrmInitForm(fid);
        FrmSetActiveForm(form);
        FrmSetEventHandler(form, (FormEventHandlerPtr) handleit);
      }

      if (form)
        FrmDispatchEvent(&event);

    }
    while (event.eType != appStopEvent);

  }

  return 0;
}
