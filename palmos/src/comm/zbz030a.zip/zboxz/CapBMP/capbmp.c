#include <PalmOS.h>

static unsigned char *getstring(int);

void myEvtGetEvent(EventPtr event, long timeout)
{
  void (*last) ();
  UInt32 odeep;
  short i, j;
  FileHand fp;
  unsigned char *cp, *dp, *pp, c, buf[20];

  FtrGet('ZBMP', 1000, (unsigned long *) &last);
  last(event, timeout);
  // 20b is contrast 10b is calc
  if (event->eType != keyDownEvent || event->data.keyDown.chr != 0x10b)
    return;
  //    HwrBacklight(1, !HwrBacklight(0, 0));

  buf[0]='B';
  buf[1]='M';
  buf[2]='P';
  StrIToH(&buf[3], TimGetSeconds());
  i = StrLen(buf);
  buf[i++] = '.';
  buf[i++] = 'b';
  buf[i++] = 'm';
  buf[i++] = 'p';
  buf[i] = 0;

  fp = FileOpen(0, buf, 'DATA', 'BOXR', fileModeReadWrite, NULL);
  if (!fp)
    return;

  WinScreenMode(winScreenModeGet, NULL, NULL, &odeep, NULL);
  dp = WinGetDisplayWindow()->displayAddrV20;
  cp = getstring(odeep);

  switch (odeep) {
  case 1:
    FileWrite(fp, cp, 1, 62, NULL);
    for (i = 159; i >= 0; i--)
      FileWrite(fp, &dp[20 * i], 1, 20, NULL);
    break;
  case 2:
    FileWrite(fp, cp, 1, 118, NULL);
    pp = dp;
    for (j = 159; j >= 0; j--) {
      dp = &pp[j * 40];
      for (i = 0; i < 40; i++, dp++) {
        buf[0] = (*dp & 0xc0) | ((*dp >> 2) & 0x3c) | ((*dp >> 4) & 3);
        buf[1] = ((*dp << 4) & 0xc0) | ((*dp << 2) & 0x3c) | (*dp & 3);
        FileWrite(fp, buf, 1, 2, NULL);
      }
    }
    break;
  case 4:
    FileWrite(fp, cp, 1, 118, NULL);
    for (i = 159; i >= 0; i--)
      FileWrite(fp, &dp[80 * i], 1, 80, NULL);
    break;
  case 8:
    FileWrite(fp, cp, 1, 54, NULL);
    pp = MemPtrNew(1024);
    cp = pp;

#if 0
    // This is probably not required,
    // but nowhere does it say indexes are sorted and without gaps
    for (i = 0; i < 256; i++, pp+= 4)
      pp[0] = i;
    pp = cp;
    WinPalette(winPaletteGet, WinUseTableIndexes, 256, cp);
#else
    WinPalette(winPaletteGet, 0, 256, cp);
#endif

    for (i = 0; i < 256; i++) {
      // irgb -> bgr0
      pp[0] = pp[3];
      pp[3] = 0;
      c = pp[1];
      pp[1] = pp[2];
      pp[2] = c;
      pp += 4;
    }
    FileWrite(fp, cp, 1, 1024, NULL);
    MemPtrFree(cp);
    for (i = 159; i >= 0; i--)
      FileWrite(fp, &dp[160 * i], 1, 160, NULL);
    break;
  }
  FileClose(fp);
  //    HwrBacklight(1, !HwrBacklight(0, 0));
  event->eType = nilEvent;
  return;
}


static const unsigned char bmp8[54] = {
  'B', 'M', 0x36, 0x68, 0, 0, 0, 0, 0, 0, 0x36, 4, 0, 0, 40, 0, 0, 0, 160, 0,
  0, 0, 160, 0, 0, 0, 1, 0, 8, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0
};

static const unsigned char bmp4[118] = {
  'B', 'M', 0x76, 0x32, 0, 0, 0, 0, 0, 0, 0x76, 0, 0, 0, 40, 0, 0, 0, 160, 0,
  0, 0, 160, 0, 0, 0, 1, 0, 4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xff, 0xff, 0xff, 0, 0xee, 0xee, 0xee, 0, 0xdd, 0xdd, 0xdd, 0,
  0xcc, 0xcc, 0xcc, 0, 0xbb, 0xbb, 0xbb, 0, 0xaa, 0xaa, 0xaa, 0,
  0x99, 0x99, 0x99, 0, 0x88, 0x88, 0x88, 0, 0x77, 0x77, 0x77, 0,
  0x66, 0x66, 0x66, 0, 0x55, 0x55, 0x55, 0, 0x44, 0x44, 0x44, 0,
  0x33, 0x33, 0x33, 0, 0x22, 0x22, 0x22, 0, 0x11, 0x11, 0x11, 0,
  0, 0, 0, 0
};

static const unsigned char bmp1[62] = {
  'B', 'M', 0xbe, 0x0c, 0, 0, 0, 0, 0, 0, 0x3e, 0, 0, 0, 40, 0, 0, 0, 160, 0,
  0, 0, 160, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
  0, 0, 0, 0, 0, 0, 0, 0, 0,
  0xff, 0xff, 0xff, 0, 0, 0, 0, 0
};

static unsigned char *getstring(int i)
{
  switch (i) {
  case 1:
    return (void *) bmp1;
  case 2:
  case 4:
    return (void *) bmp4;
  case 8:
    return (void *) bmp8;
  }
  return NULL;
}
