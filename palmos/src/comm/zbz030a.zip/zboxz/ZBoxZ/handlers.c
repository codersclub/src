#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <ExgMgr.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <System/FileStream.h>
#include <System/SysEvtMgr.h>
#include "zboxz.h"

#include <Unix/sys_types.h>

#include "stringil.h"

extern char *filecard;
extern int maxrow;
extern unsigned char sels[256];
extern int bulk;
extern char ibuf[];
extern unsigned char prefs[];
extern char **filelp;
extern RectangleType infoico;
extern int selection;

int basehand(EventPtr event);
void scandbs(int all);
int MakeDoc(char *name, FileHand fd, int destruct);
int MakeDatabase(FileHand fd, int destruct);
static DmSearchStateType sst;
/* **************************************************************************** */
extern Err SendPalmDB(ExgDBWriteProcPtr wrtit, void *fd, const char *nameP,
                      LocalID lid, UInt16 cardno);

Err WriteDBData(const void *dataP, ULong * sizeP, void *userDataP)
{
  Err err;

  *sizeP = ExgSend((ExgSocketPtr) userDataP, (void *) dataP, *sizeP, &err);
  return err;
}

Err FileDBW(const void *dataP, ULong * sizeP, void *userDataP)
{
  Err err;

  *sizeP = FileWrite(userDataP, (void *) dataP, 1, *sizeP, &err);
  return err;
}

/* **************************************************************************** */

/* handle get string modal dialog */
static char retstr[256];
static int dodlg(int id)
{
  FormPtr ff;
  FieldPtr textf;
  VoidHand thand;
  int k;

  if (!(ff = FrmInitForm(id)))
    return 0;

  thand = MemHandleNew(256);
  strcpy(MemHandleLock(thand), retstr);
  MemHandleUnlock(thand);
  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  FldSetTextHandle(textf, (Handle) thand);
  FrmSetFocus(ff, FrmGetObjectIndex(ff, bstring));

  k = FrmDoDialog(ff);
  retstr[0] = 0;

  if (k != bok) {
    FrmDeleteForm(ff);
    return 0;
  }

  textf = FrmGetObjectPtr(ff, FrmGetObjectIndex(ff, bstring));
  thand = (VoidHand) FldGetTextHandle(textf);

  k = MemHandleSize(thand);
  strncpy(retstr, MemHandleLock(thand), k);
  retstr[k] = 0;

  MemHandleUnlock(thand);
  FrmDeleteForm(ff);

  return 1;
}

/* **************************************************************************** */
void ysend(FileHand fd, char *fname);
void rsend(FileHand fd);
void rrec(char *);
void yrec(void);

extern unsigned long baud;

Boolean CommH(EventPtr event)
{
  FileHand fd;
  int eid;
  char *x;
  LocalID lid;
  UInt16 cardno;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == byrec) {
    yrec();
    scandbs(0);
    FrmGotoForm(commform);
    return 1;
  } else if (eid == bfrec) {

    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'ZFAX', true,
                                       &cardno, &lid)) {
      FrmAlert(2200);
      return 1;
    }
    x = MemPtrNew(2);
    strcpy(x, "R");
    MemPtrSetOwner(x, 0);
    //    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  } else if (eid == bbaud) {
    FormPtr ff;
    FieldPtr textf;
    VoidHand thand;
    int k, bx;

    if (!(ff = FrmInitForm(bbaud)))
      return 0;

    thand = MemHandleNew(10);
    StrIToA(MemHandleLock(thand), baud);
    MemHandleUnlock(thand);
    bx = FrmGetObjectIndex(ff, bbox);

    textf = FrmGetObjectPtr(ff, bx);
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(ff, bx);
    k = FrmDoDialog(ff);
    if (k == bok) {
      textf = FrmGetObjectPtr(ff, bx);
      thand = (VoidHand) FldGetTextHandle(textf);
      baud = StrAToI(MemHandleLock(thand));
      MemHandleUnlock(thand);
      FrmDeleteForm(ff);
    }

    FrmGotoForm(commform);
    return 1;
  } else if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  } else if (eid == brrec) {
    strcpy(retstr, "RawSer");
    StrIToH(&retstr[6], TimGetSeconds());
    if (dodlg(ffname))
      rrec(retstr);
    return 1;
  }

  if (selection == -1)
    return 1;

  if (eid == bfsnd) {

    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'ZFAX', true,
                                       &cardno, &lid)) {
      FrmAlert(2200);
      return 1;
    }
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + 2);
    strcpy(x, "S");
    strcat(x, filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    //    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  }

  fd =
    FileOpen(filecard[selection], filelp[selection] + SORTPREFIX, 'DATA',
             'BOXR', fileModeUpdate | fileModeAnyTypeCreator, NULL);

  WinEraseWindow();

  switch (eid) {
  case bysend:
    ysend(fd, filelp[selection] + SORTPREFIX);
    ysend(NULL, NULL);
    break;

  case brsend:
    rsend(fd);
    break;
  }
  FileClose(fd);
  scandbs(0);
  FrmGotoForm(commform);
  return 1;

}

/* **************************************************************************** */

Boolean ViewH(EventPtr event)
{
  LocalID lid;
  UInt16 cardno;
  char *x;
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  }
  if (selection == -1)
    return 1;

  switch (eid) {

  case bvpng:

    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'PNGv', true,
                                       &cardno, &lid))
      break;
    //    lid = DmFindDatabase(0, "PiNGer");
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + 1);
    strcpy(x, filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case bvfax:
    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'ZFAX', true,
                                       &cardno, &lid))
      break;
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + 2);
    strcpy(x, "V");
    strcat(x, filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    //    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case bmidi:
    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'MIDI', true,
                                       &cardno, &lid))
      break;
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + 1);
    strcpy(x, filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    //    lid = DmFindDatabase(0, "MusicBox");
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  default:
    return 0;
  }
  FrmAlert(2200);
  return 1;
}

/* **************************************************************************** */

extern char tempath[];
extern UInt16 dirlevel;
extern UInt16 curvol;

Boolean InstH(EventPtr event)
{
  Word n;
  FileHand fd;
  char name[512];
  int eid;
  char *x;
  LocalID lid;
  UInt16 cardno;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bclipto) {
    VoidHand clip;

    clip = ClipboardGetItem(clipboardText, &n);
    if (!clip)
      return 1;                 //+++ ERROR: Nothing to paste...

    strcpy(retstr, "Clp");
    StrIToH(&retstr[3], TimGetSeconds());
    if (!dodlg(ffname))
      return 1;

    n = 1;
    if (DmFindDatabase(0, retstr)) {
      n = FrmAlert(5000);
      if (n == 2)
        return 1;
    }

    fd =
      FileOpen(0, retstr, 'DATA', 'BOXR',
               n ? fileModeAppend : fileModeReadWrite, NULL);

    FileWrite(fd, MemHandleLock(clip), 1, n, NULL);
    MemHandleUnlock(clip);
    FileClose(fd);
    scandbs(0);
    FrmGotoForm(instform);
    return 1;

  }

  if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  }
  if (selection == -1)
    return 1;

  switch (eid) {

  case binst:
    {
      FileRef vfd;
      UInt32 len;

      if( !dirlevel ) {
	FrmAlert(2500);
	return 1;
      }

      strcpy(name, filelp[selection] + SORTPREFIX);
      fd = FileOpen(filecard[selection], name, 'DATA', 'BOXR',
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);
      if( !fd )
	return 1;
      strcpy(name,tempath);
      strcat(name, filelp[selection] + SORTPREFIX);

      vfd = 0;
      if( VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &vfd) ) {
	FrmAlert(2600);
	return 1;
      }

      WinEraseWindow();

      len = BSIZ;
      while( len == BSIZ ) {
	len = FileRead(fd, ibuf, 1, BSIZ, NULL);
	if( !len )
	  break;
	VFSFileWrite(vfd, len, ibuf, &len);
      }

      FileClose(fd);
      VFSFileClose(vfd);
      scandbs(0);
      FrmGotoForm(instform);
    }
    return 1;

  case btofax:

    if (DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'ZFAX', true,
                                       &cardno, &lid)) {
      FrmAlert(2200);
      return 1;
    }
    x = MemPtrNew(strlen(filelp[selection] + SORTPREFIX) + 2);
    strcpy(x, "C");
    strcat(x, filelp[selection] + SORTPREFIX);
    MemPtrSetOwner(x, 0);
    //    lid = DmFindDatabase(0, "ZFaxZ");
    SysUIAppSwitch(cardno, lid, sysAppLaunchCmdOpenDB, x);
    return 1;

  case btodoc:

    strcpy(name, filelp[selection] + SORTPREFIX);
    fd = FileOpen(filecard[selection], name, 'DATA', 'BOXR',
                  fileModeUpdate | fileModeAnyTypeCreator, NULL);

    n = (prefs[1] && FrmAlert(3000));
    WinEraseWindow();

    strcat(name, ".box");
    MakeDoc(name, fd, n);
    FileClose(fd);
    if (n) {
      name[strlen(name) - 4] = 0;
      FileDelete(filecard[selection], name);
    }
    scandbs(0);
    FrmGotoForm(instform);
    return 1;

  case binstall:

    fd =
      FileOpen(filecard[selection], filelp[selection] + SORTPREFIX, 'DATA',
               'BOXR', fileModeUpdate | fileModeAnyTypeCreator, NULL);

    n = (prefs[1] && FrmAlert(3000));
    WinEraseWindow();
    MakeDatabase(fd, n);
    FileClose(fd);
    if (n)
      FileDelete(filecard[selection], filelp[selection] + SORTPREFIX);

    scandbs(0);
    FrmGotoForm(instform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

Boolean InfoH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 type, crea, tlen;
  Word attr;
  FileHand fd;
  int eid;
  LocalID lid;
  ListPtr lptr;
  UInt32 crealist[] =
    { 'BOXR', 'ATCH', 'BRWS', 'TZIP', 'ZFAX', 'TAPZ', 'NZIP' };
  char nbuf[40], *c;

  if (event->eType == frmOpenEvent) {
    WinEraseWindow();

    frm = FrmGetActiveForm();
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    thand = MemHandleNew(32);
    tptr = MemHandleLock(thand);
    strcpy(tptr, filelp[selection] + SORTPREFIX);

    DmDatabaseInfo(filecard[selection], lid, NULL, &attr, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, &type, &crea);

    fd = FileOpen(filecard[selection], tptr, type, crea,
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);

    FileTell(fd, &tlen, NULL);
    FileClose(fd);
    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));

    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));

    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup)),
                attr & dmHdrAttrBackup);
    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bcopypr)),
                attr & dmHdrAttrCopyPrevention);
    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, breadon)),
                attr & dmHdrAttrReadOnly);

    for (eid = 0; eid < 5; eid++)
      if (crea == crealist[eid])
        break;

    lptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ltype));
    LstSetTopItem(lptr, eid);
    LstSetSelection(lptr, eid);
    CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ptype)),
                lptr->itemsText[eid]);

    FrmDrawForm(frm);
    WinDrawChars("Size:", 5, 110, 45);
    StrIToA(nbuf, tlen);
    WinDrawChars(nbuf, strlen(nbuf), 110, 57);

    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);

    lptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ltype));
    crea = crealist[LstGetSelection(lptr)];
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);

    DmDatabaseInfo(filecard[selection], lid, nbuf, &attr, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, NULL, NULL);

    attr &= ~(dmHdrAttrCopyPrevention | dmHdrAttrBackup | dmHdrAttrReadOnly);

    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup))))
      attr |= dmHdrAttrBackup;
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bcopypr))))
      attr |= dmHdrAttrCopyPrevention;
    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, breadon))))
      attr |= dmHdrAttrReadOnly;

// will fail if not renamed , or if new name would collide - need to
// display error msg in latter case.
    c = MemHandleLock(thand);

    if (strcmp(c, nbuf))
      DmSetDatabaseInfo(filecard[selection], lid, c, NULL,
                        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

    DmSetDatabaseInfo(filecard[selection], lid, NULL, NULL,
                      NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, &crea);
    DmSetDatabaseInfo(filecard[selection], lid, NULL, &attr,
                      NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

    MemHandleUnlock(thand);

    // Fallthrough
  case bexit:
    scandbs(0);
    FrmGotoForm(fileform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

Boolean AInfoH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 type, crea, tlen;
  Word attr;
  int eid;
  LocalID lid;
  char nbuf[36],*c;

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    thand = MemHandleNew(32);
    DmDatabaseInfo(filecard[selection], lid, tptr =
                   MemHandleLock(thand), &attr, NULL, NULL, NULL, NULL, NULL,
                   NULL, NULL, &type, &crea);


    DmDatabaseSize(filecard[selection], lid, NULL, &tlen, NULL);

    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));

    CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup)),
                attr & dmHdrAttrBackup);


    FrmDrawForm(frm);
    WinDrawChars("Size:", 5, 5, 60);
    StrIToA(nbuf, tlen);
    WinDrawChars(nbuf, strlen(nbuf), 30, 60);
    WinDrawChars("Type:", 5, 5, 72);
    WinDrawChars((void *) &type, 4, 30, 72);
    WinDrawChars("Crea:", 5, 5, 84);
    WinDrawChars((void *) &crea, 4, 30, 84);

    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);

    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);

    DmDatabaseInfo(filecard[selection], lid, nbuf, &attr, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, NULL, NULL);

    attr &= ~(dmHdrAttrBackup);

    if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bbackup))))
      attr |= dmHdrAttrBackup;

// will fail if not renamed , or if new name would collide - need to
// display error msg in latter case.
    c = MemHandleLock(thand);
    if (strcmp(c, nbuf))
      DmSetDatabaseInfo(filecard[selection], lid, c, NULL,
			NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

    DmSetDatabaseInfo(filecard[selection], lid, NULL, &attr,
                      NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

    MemHandleUnlock(thand);

    // Fallthrough
  case bexit:
    scandbs(1);
    FrmGotoForm(alldbform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

static int beambox(int i)
{
  LocalID lid;
  VoidPtr px;
  Word err;
  long unsigned int xcnt, outhis, tlen;
  ExgSocketType exgSocket;
  FileHand fd;
  UInt32 len;
  UInt16 attr;

  lid = DmFindDatabase(filecard[i], filelp[i] + SORTPREFIX);
  DmDatabaseInfo(filecard[i], lid, NULL, &attr, NULL, NULL, NULL,
                 NULL, NULL, NULL, NULL, NULL, NULL);

  if (attr & dmHdrAttrCopyPrevention)
    return 1;

  fd = FileOpen(filecard[i], filelp[i] + SORTPREFIX, 'DATA', 'BOXR',
                fileModeReadOnly | fileModeAnyTypeCreator, NULL);
  FileTell(fd, &len, NULL);

  MemSet(&exgSocket, sizeof(exgSocket), 0);
  exgSocket.description = filelp[i] + SORTPREFIX;
  exgSocket.name = filelp[i] + SORTPREFIX;
  exgSocket.length = len;
  exgSocket.target = 'BOXR';

  if (!ExgPut(&exgSocket)) {
    xcnt = 0;
    while (xcnt < len) {
      tlen = FileRead(fd, ibuf, 1, BSIZ, NULL);
      xcnt += tlen;
      px = ibuf;
      while (tlen) {
        outhis = ExgSend(&exgSocket, px, tlen, &err);
        if (err)
          break;
        tlen -= outhis;
        px += outhis;
        EvtResetAutoOffTimer();
      }
    }
    FileClose(fd);
    EvtResetAutoOffTimer();
    ExgDisconnect(&exgSocket, err);
  }
  SysTaskDelay(200);
  return err;
}

void ronamatic(void)
{
  if (!bulk) {
    if (beambox(selection))
      FrmAlert(2100);
  } else {
    int i;
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if (beambox(i))
        break;
    }
  }
}

Boolean FileH(EventPtr event)
{
  LocalID lid;
  int eid;
  UInt16 attr;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  }

  if (selection == -1 && eid != bbulk)
    return 1;

  switch (eid) {
  case bcpy:
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    DmDatabaseInfo(filecard[selection], lid, NULL, &attr, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, NULL, NULL);
    if (attr & dmHdrAttrCopyPrevention) {
      FrmAlert(2100);
      return 1;
    }
    FrmGotoForm(copyform);
    return 1;

  case binfo:
    FrmGotoForm(infoform);
    return 1;

  case bbulk:
    selection = -1;
    FrmGotoForm(bulkform);
    return 1;

  case bdelete:
    if (prefs[0] && FrmAlert(2000))
      return 1;

    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    DmDeleteDatabase(filecard[selection], lid);

    scandbs(0);
    FrmGotoForm(fileform);
    return 1;

  case bbeam:
    if (beambox(selection))
      FrmAlert(2100);
    return 1;

  default:
    return 0;
  }

}

/* **************************************************************************** */
#if 0
all() {
    memset(sels, 255, 256);
    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
}
#endif

Boolean BulkH(EventPtr event)
{
  LocalID lid;
  int eid;
  UInt16 attr;
  int i;
  char *c;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;
  }
  switch (eid) {
  case ball:

    if( !dirlevel ) {
      FrmAlert(2500);
      return 1;
    }

    for (i = 0; i < maxrow; i++) {
      FileHand fd;
      FileRef vfd;
      UInt32 len;
      char name[512];
      
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;

      WinEraseWindow();

      c = filelp[i] + SORTPREFIX;
      fd = FileOpen(filecard[i], c, 'DATA', 'BOXR',
                    fileModeReadOnly | fileModeAnyTypeCreator, NULL);
      if( !fd )
	continue;
      strcpy(name,tempath);
      strcat(name, c);

      WinDrawChars(c, strlen(c), 0, 15);

      VFSFileOpen(curvol, name, vfsModeCreate | vfsModeTruncate | vfsModeWrite , &vfd);

      len = BSIZ;
      while( len == BSIZ ) {
	len = FileRead(fd, ibuf, 1, BSIZ, NULL);
	if( !len )
	  break;
	VFSFileWrite(vfd, len, ibuf, &len);
      }

      FileClose(fd);
      VFSFileClose(vfd);

    }
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bnone:
    memset(sels, 0, 256);
    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
    return 1;

  case bysend:
    for (i = 0; i < maxrow; i++) {
      FileHand fd;

      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      fd = FileOpen(filecard[i], filelp[i] + SORTPREFIX, 'DATA', 'BOXR',
                    fileModeUpdate | fileModeAnyTypeCreator, NULL);
      ysend(fd, filelp[i] + SORTPREFIX);
    }
    ysend(NULL, NULL);
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bbeam:
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      if (beambox(i))
        break;
    }
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bdelete:
    if (prefs[0] && FrmAlert(2000))
      return 1;
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      c = filelp[i] + SORTPREFIX;
      WinEraseWindow();
      WinDrawChars(c, strlen(c), 0, 15);
      if (!(lid = DmFindDatabase(filecard[i], c)))
        continue;
      DmDeleteDatabase(filecard[i], lid);
    }
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case bbackup:
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      lid = DmFindDatabase(filecard[i], filelp[i] + SORTPREFIX);
      DmDatabaseInfo(filecard[i], lid, NULL, &attr, NULL, NULL, NULL,
                     NULL, NULL, NULL, NULL, NULL, NULL);
      attr |= dmHdrAttrBackup;
      DmSetDatabaseInfo(filecard[i], lid, NULL, &attr,
                        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    }
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;

  case binst:
    {
      int n;
      FileHand fd;
      char *c;

      n = (prefs[1] && FrmAlert(3000));
      for (i = 0; i < maxrow; i++) {
        if (!(sels[i >> 3] & (1 << (i & 7))))
          continue;
        c = filelp[i] + SORTPREFIX;
        WinEraseWindow();
        WinDrawChars(c, strlen(c), 0, 15);
        fd = FileOpen(filecard[i], c, 'DATA', 'BOXR',
                      fileModeUpdate | fileModeAnyTypeCreator, NULL);
        MakeDatabase(fd, n);
        FileClose(fd);
        if (n)
          FileDelete(filecard[i], c);
      }
    }
    scandbs(0);
    bulk = 0;
    FrmGotoForm(fileform);
    return 1;
  default:
    return 0;
  }
}

/* **************************************************************************** */

Boolean AlldbH(EventPtr event)
{
  LocalID lid;
  UInt32 type, crea;
  int eid;
  char name[40];
  Word attr, err;
  ExgSocketType exgSocket;
  FileHand dbofd;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    scandbs(0);
    FrmGotoForm(mainform);
    return 1;
  }

  if (eid == bbulk) {
    selection = -1;
    FrmGotoForm(abulkform);
    return 1;
  }

  if (selection == -1)
    return 1;

  lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
  DmDatabaseInfo(filecard[selection], lid, name, &attr, NULL, NULL, NULL,
                 NULL, NULL, NULL, NULL, &type, &crea);

  switch (eid) {
  case binfo:
    FrmGotoForm(ainfoform);
    return 1;

  case bbulk:

  case bdelete:
    if (prefs[0] && FrmAlert(2000))
      return 1;
    DmDeleteDatabase(filecard[selection], lid);
    scandbs(1);
    FrmGotoForm(alldbform);
    return 1;

  case bbeam:
    if (attr & dmHdrAttrCopyPrevention) {
      FrmAlert(2100);
      return 1;
    }

    strcat(name, ".box");
    memset(&exgSocket, 0, sizeof(exgSocket));
    exgSocket.description = name;
    exgSocket.name = name;
    exgSocket.target = 'BOXR';
    err = ExgPut(&exgSocket);
    if (!err) {
      err = SendPalmDB(WriteDBData, &exgSocket, NULL, lid, filecard[selection]);
      err = ExgDisconnect(&exgSocket, err);
      EvtResetAutoOffTimer();
    }
    scandbs(1);
    FrmGotoForm(alldbform);
    return 1;

  case bbox:
    strcat(name, ".box");

    dbofd = FileOpen(0, name, 'DATA', 'BOXR', fileModeReadWrite, NULL);

    WinEraseWindow();
    WinDrawChars("Boxing:", 7, 0, 15);

    err = SendPalmDB(FileDBW, dbofd, NULL, lid, filecard[selection]);
    EvtResetAutoOffTimer();
    FileClose(dbofd);
    scandbs(0);
    FrmGotoForm(mainform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

Boolean ABulkH(EventPtr event)
{
  int eid;
  int i;
  LocalID lid;
  UInt16 attr;
  char *c;
  char name[36];
  UInt32 type, crea;

  bulk = 1;
  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;

  if (eid == bexit) {
    scandbs(1);
    bulk = 0;
    FrmGotoForm(alldbform);
    return 1;
  }

  switch (eid) {
  case ball:
    memset(sels, 255, 256);
    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
    return 1;
  case bnone:
    memset(sels, 0, 256);
    WinEraseRectangle(&infoico, 5);
    FrmDrawForm(FrmGetActiveForm());
    WinInvertRectangle(&infoico, 5);
    return 1;

  case bbeam:
    {
      ExgSocketType exgSocket;
      Word err;

      for (i = 0; i < maxrow; i++) {
        if (!(sels[i >> 3] & (1 << (i & 7))))
          continue;

        lid = DmFindDatabase(filecard[i], filelp[i] + SORTPREFIX);
        DmDatabaseInfo(filecard[i], lid, name, &attr, NULL, NULL, NULL,
                       NULL, NULL, NULL, NULL, &type, &crea);
        if (attr & dmHdrAttrCopyPrevention)
          continue;

        strcat(name, ".box");
        memset(&exgSocket, 0, sizeof(exgSocket));
        exgSocket.description = name;
        exgSocket.name = name;
        exgSocket.target = 'BOXR';
        if (!ExgPut(&exgSocket)) {
          err = SendPalmDB(WriteDBData, &exgSocket, NULL, lid, filecard[i]);
          ExgDisconnect(&exgSocket, err);
          EvtResetAutoOffTimer();
        }
        SysTaskDelay(100);
      }
    }
    scandbs(1);
    bulk = 0;
    FrmGotoForm(alldbform);
    return 1;

  case bdelete:
    if (prefs[0] && FrmAlert(2000))
      return 1;
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      c = filelp[i] + SORTPREFIX;
      WinEraseWindow();
      WinDrawChars(c, strlen(c), 0, 15);
      if (!(lid = DmFindDatabase(filecard[i], c)))
        continue;

      DmDeleteDatabase(filecard[i], lid);
    }
    scandbs(1);
    bulk = 0;
    FrmGotoForm(alldbform);
    return 1;

  case bbackup:
    for (i = 0; i < maxrow; i++) {
      if (!(sels[i >> 3] & (1 << (i & 7))))
        continue;
      lid = DmFindDatabase(filecard[i], filelp[i] + SORTPREFIX);
      DmDatabaseInfo(filecard[i], lid, NULL, &attr, NULL, NULL, NULL,
                     NULL, NULL, NULL, NULL, NULL, NULL);
      attr |= dmHdrAttrBackup;
      DmSetDatabaseInfo(filecard[i], lid, NULL, &attr,
                        NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    }
    scandbs(1);
    bulk = 0;
    FrmGotoForm(alldbform);
    return 1;

  case bbox:
    {
      FileHand fd;
      Word err;

      for (i = 0; i < maxrow; i++) {
        if (!(sels[i >> 3] & (1 << (i & 7))))
          continue;

        lid = DmFindDatabase(filecard[i], filelp[i] + SORTPREFIX);
        DmDatabaseInfo(filecard[i], lid, name, &attr, NULL, NULL, NULL,
                       NULL, NULL, NULL, NULL, &type, &crea);
        strcat(name, ".box");
        fd = FileOpen(0, name, 'DATA', 'BOXR', fileModeReadWrite, NULL);
        WinEraseWindow();
        WinDrawChars("Boxing:", 7, 0, 15);
        err = SendPalmDB(FileDBW, fd, NULL, lid, filecard[i]);
        EvtResetAutoOffTimer();
        FileClose(fd);
      }
    }
    scandbs(1);
    bulk = 0;
    FrmGotoForm(alldbform);
    return 1;

  default:
    return 0;
  }
}
