#include <PalmOS.h>

#include <ExgMgr.h>
#include <System/FileStream.h>
#include <System/SysEvtMgr.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include "zboxz.h"

#include <Unix/sys_types.h>

#include "stringil.h"

#define NOZLIBDEFS
#include "SysZLib.h"

int toprow = 0;
char *filelist;
short int *filesort;
static FileHand archfd;

int selection = -1;
char *filecard;
long int *filedisp;
int maxrow = 0;
unsigned char sels[256];
int bulk = 0;
unsigned char prefs[12];
char **filelp;

/* **************************************************************************** */
TableDrawItemFuncType TableDrawCell;

void TableDrawCell(VoidPtr tableP, Int16 row, Int16 column,
                   RectangleType * bounds)
{
  char *c;
  unsigned long which;

  which = TblGetRowData(tableP, row);
  c = filelp[which] + SORTPREFIX;
  WinEraseRectangle(bounds, 0);
  WinDrawChars(c, strlen(c), bounds->topLeft.x + 1, bounds->topLeft.y);
  if (sels[which >> 3] & (1 << (which & 7)))
    WinInvertRectangle(bounds, 0);
}

/* **************************************************************************** */

int unzipdir(FileHand infile, char *dir, long int *loc);
int untardir(FileHand fd, char *dir, long int *loc);

Int16 fncomp(void *x, void *y, Int32 z)
{
  unsigned char **zx;
  int num = 32;

  zx = (unsigned char **) z;
  x = zx[*(short int *) x];
  y = zx[*(short int *) y];

  while (--num && *(unsigned char *) y++ == *(unsigned char *) x++);
  y--;
  x--;
  return *(unsigned char *) x - *(unsigned char *) y;

}

static void doflp()
{
  char *c;
  int i;

  c = filelist;
  for (i = 0; i < maxrow; i++) {
    DmWrite(filelp, 4 * i, &c, 4);
    c += strlen(c) + 1;
  }
}

static void nosortl()
{
  short int *sortlist, i;

  sortlist = MemPtrNew(maxrow * 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;

  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);
}

void scandbs(int all)
{
  UInt16 cardno, attr;
  UInt32 type, crea, i, ndb, j, *flpt, disp, *fl, crd, bkd, mdd, size, nrecs;
  char tp[44];
  short int *sortlist;
  LocalID lid;

  WinEraseWindow();             /* user feedback */
  maxrow = 0;
  disp = 0;

  WinDrawChars("Getting Directory...", 20, 0, 0);
  if (bulk)
    memset(sels, 0, 256);
  for (cardno = 0; cardno < MemNumCards(); cardno++) {
    ndb = DmNumDatabases(cardno);
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    for (i = 0; i < ndb; i++) {

      /* TODO: sortprefix should be a global variable */

      memset(tp, 0, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */
      lid = DmGetDatabase(cardno, i);
      DmDatabaseInfo(cardno, lid, &tp[SORTPREFIX], &attr, NULL, NULL, NULL,
                     NULL, NULL, NULL, NULL, &type, &crea);
      if (!all) {
        if (!(attr & dmHdrAttrStream) || type != 'DATA')
          continue;
        if (crea != 'BOXR' && crea != 'TAPZ' && crea != 'ZFAX' && !(prefs[3] && crea == 'ATCH')
            && !(prefs[4] && crea == 'BRWS')
            && !(prefs[5] && crea == 'TZIP')
            && crea != 'NZIP')
          continue;
      }

      /* else, all filter */
      switch (prefs[6]) {
      default:
      case 0:
        memcpy(tp, &tp[SORTPREFIX], SORTPREFIX); /* this speeds up the sort */
        break;
      case 1:
        memcpy(tp, &type, 4);
        break;
      case 2:
        memcpy(tp, &crea, 4);
        break;
      case 3:
        DmDatabaseSize(cardno, lid, NULL, &size, NULL); /* total, data */
        memcpy(tp, &size, 4);
        break;
      case 4:
        DmDatabaseSize(cardno, lid, &nrecs, NULL, NULL); /* total, data */
        memcpy(tp, &nrecs, 4);
        break;
      case 5:
        DmDatabaseInfo(cardno, lid, NULL, NULL, NULL, &crd,
                       NULL, NULL, NULL, NULL, NULL, NULL, NULL);
        memcpy(tp, &crd, 4);
        break;
      case 6:
        DmDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL,
                       &mdd, NULL, NULL, NULL, NULL, NULL, NULL);
        memcpy(tp, &mdd, 4);
        break;
      case 7:
        DmDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL,
                       NULL, &bkd, NULL, NULL, NULL, NULL, NULL);
        memcpy(tp, &bkd, 4);
        break;
      }

      /* Copy type, creator, size, i , nrecs, bk/cr/md diate, into tp
         (4 bytes) for alternate sorting */

      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmSet(filecard, j, maxrow - j, cardno);
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
  }

  WinDrawChars("Sorting Directory...", 20, 0, 15);

  sortlist = MemPtrNew(maxrow * 2 + 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;

  SysQSort(sortlist, maxrow, 2, fncomp, (Int32) filelp);

  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);

  selection = -1;
  toprow = 0;
}

/* **************************************************************************** */

int unrunzip(FileHand infile);
int unzip(FileHand infile, long int loc);
int untar(FileHand fd, long int loc);

RectangleType infoico = { {148, 0}
, {10, 10}
};

void settable()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  UInt top;
  Word row, numRows;
  ScrollBarPtr bar;

  WinEraseWindow();
  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  top = toprow;
  numRows = TblGetNumberOfRows(tptr);


  for (n = 0; n < 1; n++)
    TblSetColumnUsable(tptr, n, true);

  for (row = 0; row < numRows; row++, top++) {

    if (top < maxrow)
      TblSetRowData(tptr, row, (ULong) filesort[top]);

    if (top < maxrow) {
      TblSetRowSelectable(tptr, row, true);

      for (n = 0; n < 1; n++) {
        TblSetItemStyle(tptr, row, n, customTableItem);
        TblSetCustomDrawProcedure(tptr, n, TableDrawCell);
      }
      TblMarkRowInvalid(tptr, row);
    } else
      TblSetRowUsable(tptr, row, false);

  }

  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));

  if (maxrow <= numRows)
    SclSetScrollBar(bar, 0, 0, 0, 10);
  else
    SclSetScrollBar(bar, toprow, 0, maxrow - numRows, numRows);

  FrmDrawForm(frm);
  WinInvertRectangle(&infoico, 5);

#ifdef LEAKDETECT
  {
    UInt32 f, m;
    char buf[16];
    MemHeapFreeBytes(0, &f, &m);
    StrIToA(buf, f);
    strcat(buf, "   ");
    WinDrawChars(buf, strlen(buf), 40, 0);
    StrIToA(buf, m);
    strcat(buf, "   ");
    WinDrawChars(buf, strlen(buf), 100, 0);
  }
#endif
  top = toprow;
  for (row = 0; row < numRows; row++, top++)
    if (top < maxrow && selection == filesort[top]) {
      TblSelectItem(tptr, row, 0);
      break;
    }
  if (bulk || row == numRows)
    selection = -1;
}

/* **************************************************************************** */

void dopage(int down)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow += n * (((down) << 1) - 1);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doscroll()
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  ScrollBarPtr bar;
  Word v, mn, mx, ps;

  frm = FrmGetActiveForm();
  bar = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, scrl));
  SclGetScrollBar(bar, &v, &mn, &mx, &ps);
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  toprow = v;
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;

  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

void doseek(char val)
{
  TablePtr tptr;
  Word n;
  FormPtr frm;
  char *c;

  do {
    c = filelp[filesort[++toprow]] + SORTPREFIX;
  } while (toprow < maxrow && *c != val);

  if (toprow == maxrow) {
    toprow = 0;
    c = filelp[filesort[toprow]] + SORTPREFIX;
    while (toprow < maxrow && *c != val) // if rewound, use top if matched
      c = filelp[filesort[++toprow]] + SORTPREFIX;
    if (toprow == maxrow)
      toprow = 0;
  }

  frm = FrmGetActiveForm();
  tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
  n = TblGetNumberOfRows(tptr);
  if ((toprow + n) >= maxrow)
    toprow = maxrow - n;
  if (toprow < 0)
    toprow = 0;
  FrmGotoForm(FrmGetActiveFormID());
}

/* **************************************************************************** */

/* HANDLERS */
extern void ronamatic();

int basehand(EventPtr event)
{
  switch (event->eType) {

  case frmOpenEvent:
    settable();
    return 1;

  case sclExitEvent:
    doscroll();
    return 1;

  case keyDownEvent:

    switch (event->data.keyDown.chr) {
    case vchrSendData:
    case vchrRonamatic:
      ronamatic();
      return 1;
    case pageUpChr:
    case pageDownChr:
      dopage(event->data.keyDown.chr == pageDownChr);
      return 1;
    default:
      doseek(event->data.keyDown.chr);
      return 0;
    }

  case tblSelectEvent:
    selection = filesort[toprow + event->data.tblSelect.row];
    if (bulk) {
      FormPtr frm;
      TablePtr tptr;

      sels[selection >> 3] ^= (1 << (selection & 7));

      frm = FrmGetActiveForm();
      tptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, maintable));
      TblUnhighlightSelection(tptr);
      WinEraseRectangle(&infoico, 5);
      FrmDrawForm(frm);
      WinInvertRectangle(&infoico, 5);
      selection = -1;
    }
    return 1;

  default:
    return 0;
  }

}

/* **************************************************************************** */

static Boolean UnzipH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bunzip:
    if (selection == -1)
      break;
    WinEraseWindow();
    unzip(archfd, filedisp[selection]);
    FrmGotoForm(unzipform);
    return 1;
  case bexit:
    FileClose(archfd);
    toprow = 0;
    scandbs(0);
    FrmGotoForm(decomform);
    return 1;
  }
  return 0;

}

/* **************************************************************************** */

void godir();
void cardir();
void cardsetup();
extern char tempath[];

static Boolean CardH(EventPtr event)
{
  int eid;
  LocalID lid;

  if( event->eType == frmOpenEvent ) {
    basehand(event);
    WinDrawChars(tempath,strlen(tempath),3,132);
    return 1;
  }

  if (basehand(event))
    return 1;

  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    godir();
    return 1;
  case binst:
    lid = DmFindDatabase(0, "ZCardZ");
    SysUIAppSwitch(0, lid, sysAppLaunchCmdNormalLaunch, NULL);
    return 1;
  case bexit:
    toprow = 0;
    scandbs(0);
    FrmGotoForm(mainform);
    return 1;
  }
  return 0;

}

/* **************************************************************************** */

static Boolean UntarH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case buntar:
    if (selection == -1)
      return 1;
    WinEraseWindow();
    untar(archfd, filedisp[selection]);
    FrmGotoForm(untarform);
    return 1;

  case bexit:
    FileClose(archfd);
    toprow = 0;
    scandbs(0);
    FrmGotoForm(decomform);
    return 1;
  }

  return 0;
}

/* **************************************************************************** */

static Boolean MainH(EventPtr event)
{
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;
  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bfile:
    FrmGotoForm(fileform);
    return 1;
  case bdecom:
    FrmGotoForm(decomform);
    return 1;
  case binst:
    FrmGotoForm(instform);
    return 1;
  case bcomm:
    FrmGotoForm(commform);
    return 1;
  case bview:
    FrmGotoForm(viewform);
    return 1;
  case balldb:
    scandbs(1);
    FrmGotoForm(alldbform);
    return 1;
  case bok:
    cardir();
    FrmGotoForm(cardform);
    return 1;
  case bpref:
    FrmGotoForm(prefform);
    return 1;
  default:
    return 0;
  }
}

/* **************************************************************************** */
int MakeDoc(char *name, FileHand fd, int destruct);
int MakeDatabase(FileHand fd, int destruct);

static Boolean DecomH(EventPtr event)
{
  Word n, k;
  LocalID lid;
  FileHand fd;
  char name[256];
  UInt32 type, crea;
  int eid;

  if (basehand(event))
    return 1;
  if (event->eType != ctlSelectEvent)
    return 0;
  eid = event->data.ctlEnter.controlID;
  if (eid == bexit) {
    FrmGotoForm(mainform);
    return 1;
  }
  if (selection == -1)
    return 1;

  lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
  DmDatabaseInfo(filecard[selection], lid, name, NULL, NULL, NULL, NULL,
                 NULL, NULL, NULL, NULL, &type, &crea);
  fd = FileOpen(filecard[selection], name, type, crea,
                fileModeUpdate | fileModeAnyTypeCreator, NULL);
  WinEraseWindow();

  switch (eid) {
  case bunzip:
    archfd = fd;
    n = unzipdir(archfd, filelist, filedisp);
    if (n) {
      toprow = 0;
      maxrow = n;
      doflp();
      nosortl();
      FrmGotoForm(unzipform);
    } else {
      FrmAlert(4000);
      FileClose(archfd);
      scandbs(0);
      FrmGotoForm(decomform);
    }
    return 1;

  case buntar:
    archfd = fd;
    n = untardir(archfd, filelist, filedisp);
    if (n) {
      toprow = 0;
      maxrow = n;
      doflp();
      nosortl();
      FrmGotoForm(untarform);
    } else {
      FrmAlert(4000);
      FileClose(archfd);
      scandbs(0);
      FrmGotoForm(decomform);
    }
    return 1;

  case bgunzip:
    n = unzip(fd, 0);
    FileClose(fd);
    scandbs(0);
    FrmGotoForm(decomform);
    return 1;

  case bunrzip:
    n = unrunzip(fd);
    FileDelete(filecard[selection], name);
    scandbs(0);
    FrmGotoForm(decomform);
    return 1;

  case bgzip:
    FrmGotoForm(gzipform);
    return 1;

  case bripunzip:
    WinEraseWindow();

    k = unzipdir(fd, filelist, filedisp);
    if (k) {
      n = unzip(fd, -1);
      FileClose(fd);
      if (n != -1)
        FileDelete(filecard[selection], name);
    } else {
      WinEraseWindow();
      k = untardir(fd, filelist, filedisp);
      if (k) {
        n = untar(fd, -1);
	FileClose(fd);
	if (n != -1)
	  FileDelete(filecard[selection], name);
      }
      else
	FileClose(fd);
    }

    //Now install the files in filelist.
    if (k) {
      char *c = filelist + SORTPREFIX, *d, d1,d2;

      for (n = 0; n < k; n++,c += strlen(c) + 1 + SORTPREFIX) {
	d = &c[strlen(c) - 4];
	if ( *d++ != '.' )
	  continue;
	if ( toupper(*d++) != 'P' )
	  continue;
	d1 = toupper(*d++);
	d2 = toupper(*d++);
	if(!( d1 == 'R' && d2 == 'C' ) &&
	   !( d1 == 'D' && d2 == 'B' ) &&
	   !( d1 == 'Q' && d2 == 'A' ) )
	  continue;

	WinEraseWindow();
	WinDrawChars(c, strlen(c), 0, 15);
	fd = FileOpen(0, c, 'DATA', 'BOXR',
		      fileModeUpdate | fileModeAnyTypeCreator, NULL);
	MakeDatabase(fd, 1);
	FileClose(fd);
	FileDelete(0, c);

	
      }
    }

    scandbs(0);
    FrmGotoForm(decomform);
    return 1;

  default:
    return 0;
  }

}

/* **************************************************************************** */
extern char ibuf[];

static Boolean CopyH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 type, crea, tlen, xlen;
  Word attr;
  FileHand fd, ofd;
  int eid;
  LocalID lid;
  char name[32];

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    thand = MemHandleNew(32);
    DmDatabaseInfo(filecard[selection], lid, tptr =
                   MemHandleLock(thand), &attr, NULL, NULL, NULL, NULL, NULL,
                   NULL, NULL, &type, &crea);

    fd = FileOpen(filecard[selection], tptr, type, crea,
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);

    FileTell(fd, &tlen, NULL);
    FileClose(fd);

    strcat(tptr, "-Cpy");

    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));
    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);

    StrIToA(name, tlen);
    strcat(name, " Bytes in box");
    WinDrawChars(name, strlen(name), 5, 45);
    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:
    // COPY PREVENT?
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    DmDatabaseInfo(filecard[selection], lid, name, NULL, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, &type, &crea);
    fd = FileOpen(filecard[selection], name, type, crea,
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    FileTell(fd, &tlen, NULL);

    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);
    ofd = FileOpen(filecard[selection], MemHandleLock(thand), 'DATA', 'BOXR',
                   fileModeReadWrite, NULL);
    MemHandleUnlock(thand);

    WinEraseWindow();

    crea = tlen;
    WinDrawChars("Copying:", 8, 0, 15);
    while (tlen) {
      RectangleType r = { {0, 30}
      , {0, 15}
      };

      type = tlen > BSIZ ? BSIZ : tlen;
      xlen = FileRead(fd, ibuf, 1, type, NULL);
      if (type != xlen)
        break;                  // ERROR MESSAGE
      FileWrite(ofd, ibuf, 1, xlen, NULL);
      tlen -= xlen;

      r.extent.x = 160 - (160 * tlen / crea);
      WinDrawRectangle(&r, 0);

    }
    FileClose(fd);
    FileClose(ofd);

    // FALLTHROUGH

  case bexit:
    scandbs(0);
    FrmGotoForm(fileform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

extern void gzip(FileHand fd, FileHand ofd);

static Boolean GzipH(EventPtr event)
{
  FormPtr frm;
  FieldPtr textf;
  VoidHand thand;
  VoidPtr tptr;
  UInt32 type, crea, tlen;
  Word attr;
  FileHand fd, ofd;
  int eid, n;
  LocalID lid;
  char name[32];

  if (event->eType == frmOpenEvent) {

    WinEraseWindow();
    frm = FrmGetActiveForm();
    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    thand = MemHandleNew(32);
    DmDatabaseInfo(filecard[selection], lid, tptr =
                   MemHandleLock(thand), &attr, NULL, NULL, NULL, NULL, NULL,
                   NULL, NULL, &type, &crea);

    fd = FileOpen(filecard[selection], tptr, type, crea,
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);

    FileTell(fd, &tlen, NULL);
    FileClose(fd);

    strcat(tptr, ".gz");

    MemHandleUnlock(thand);
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    FldSetTextHandle(textf, (Handle) thand);
    FrmSetFocus(frm, FrmGetObjectIndex(frm, namefld));
    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);

    StrIToA(name, tlen);
    strcat(name, " Bytes in box");
    WinDrawChars(name, strlen(name), 5, 45);
    return 1;

  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {
  case bok:

    lid = DmFindDatabase(filecard[selection], filelp[selection] + SORTPREFIX);
    DmDatabaseInfo(filecard[selection], lid, name, NULL, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, &type, &crea);
    fd = FileOpen(filecard[selection], name, type, crea,
                  fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    FileTell(fd, &tlen, NULL);

    frm = FrmGetActiveForm();
    textf = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, namefld));
    thand = (VoidHand) FldGetTextHandle(textf);
    ofd = FileOpen(filecard[selection], MemHandleLock(thand), 'DATA', 'BOXR',
                   fileModeReadWrite, NULL);
    MemHandleUnlock(thand);

    n = (prefs[1] && FrmAlert(3000));
    if (n)
      FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);

    WinEraseWindow();

    gzip(fd, ofd);

    FileClose(fd);
    FileClose(ofd);

    if (n)
      FileDelete(filecard[selection], name);

    // FALLTHROUGH

  case bexit:
    scandbs(0);
    FrmGotoForm(decomform);
    return 1;

  default:
    return 0;
  }
}

/* **************************************************************************** */

static Boolean PrefH(EventPtr event)
{
  FormPtr frm;
  int eid;
  ListPtr lptr;
#if 0
  //+++ get from ltype ID

  char *typelist[] =
    { "File Name", "DB Type", "Creator", "Data Size", "Num Recs", "T-Created",
      "T-Modified",
    "T-Backup"
  };
#endif
  if (event->eType == frmOpenEvent) {
    WinEraseWindow();
    frm = FrmGetActiveForm();
    for (eid = 0; eid < 6; eid++)
      CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, bpref1 + eid)),
                  !!prefs[eid]);


    lptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ltype));
    LstSetTopItem(lptr, prefs[6]);
    LstSetSelection(lptr, prefs[6]);
    CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ptype)),
                lptr->itemsText[prefs[6]]);

    FrmDrawForm(frm);
    WinInvertRectangle(&infoico, 5);
    return 1;
  } else if (event->eType != ctlSelectEvent)
    return 0;

  eid = event->data.ctlEnter.controlID;
  switch (eid) {

  case bok:
    frm = FrmGetActiveForm();
    lptr = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ltype));
    prefs[6] = LstGetSelection(lptr);

    for (eid = 0; eid < 6; eid++)
      prefs[eid] =
        !!CtlGetValue(FrmGetObjectPtr
                      (frm, FrmGetObjectIndex(frm, bpref1 + eid)));
    FtrSet('BOXR', 1, prefs[2]);
    // Fallthrough
  case bexit:
    scandbs(0);
    FrmGotoForm(mainform);
    return 1;

  default:
    return 0;
  }
}


/* **************************************************************************** */
extern Boolean FileH(EventPtr event);
extern Boolean AlldbH(EventPtr event);
extern Boolean BulkH(EventPtr event);
extern Boolean ABulkH(EventPtr event);
extern Boolean InstH(EventPtr event);
extern Boolean InfoH(EventPtr event);
extern Boolean AInfoH(EventPtr event);
extern Boolean CommH(EventPtr event);
extern Boolean ViewH(EventPtr event);
extern unsigned long baud;

int dirtyp;

extern UInt16 curvol, dirlevel;
int removed;
Err setremoved(SysNotifyParamType *notif) {
  int *dp = notif->userDataP;
  UInt16 *vol;
  EventType e;

  notif->handled = -1;
  vol = notif->notifyDetailsP;
  if( vol )
    *dp = (int) vol; //The docs lie?
  else
    *dp = -1;

  e.eType = nilEvent;
  EvtAddEventToQueue (&e);
  return 0;
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  short err;
  int formID;
  FormPtr form = NULL;
  EventType event;
  LocalID lid;
  DmOpenRef scratch;
  Word dbrec;
  VoidHand hand;
  UInt32 ver;

  if (cmd == sysAppLaunchCmdSystemReset) {
    if ((lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD")))
      DmDeleteDatabase(0, lid);
    return 0;
  } else if (cmd == sysAppLaunchCmdExgAskUser) {
    UInt32 ask = 1;
    ExgAskParamPtr exgP = (ExgAskParamPtr) cmdPBP;
    FtrGet('BOXR', 1, &ask);
    exgP->result = ask ? exgAskDialog : exgAskOk; /* Dialog, Ok, Cancel */
    return 0;
  } else if (cmd == sysAppLaunchCmdExgReceiveData) {
    ExgSocketPtr exgSocketP = (ExgSocketPtr) cmdPBP;
    unsigned char buf[256];
    int inthis;
    FileHand fd;

    err = ExgAccept(exgSocketP);
    fd = FileOpen(0, exgSocketP->name, 'DATA', 'BOXR', fileModeReadWrite, NULL);

    if ((launchFlags & sysAppLaunchFlagSubCall))
      dirtyp++;

    if (err)
      return err;

    inthis = 1;
    while (inthis) {
      inthis = ExgReceive(exgSocketP, buf, 256, &err);
      if (err)
        break;
      FileWrite(fd, buf, 1, inthis, NULL);
      EvtResetAutoOffTimer();
    }
    FileClose(fd);
    ExgDisconnect(exgSocketP, err);
    EvtResetAutoOffTimer();
    return 0;
#if 0
  } else if (cmd == sysAppLaunchCmdOpenDB) {


    struct {
      UInt16 cn;
      LocalID li;
    } *x;
    char name[36];

    x = cmdPBP;

    DmDatabaseInfo(x->cn, x->li, name, NULL, NULL, NULL, NULL,
                   NULL, NULL, NULL, NULL, NULL, NULL);

    WinDrawChars(name, strlen(name), 10, 40);
    SysTaskDelay(300);

    return 0;
#endif
  } else if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

  removed = 0;
  SysNotifyRegister(0,0/*code resource lid*/, sysNotifyVolumeUnmountedEvent, setremoved , 0,  &removed);
  SysNotifyRegister(0,0/*code resource lid*/, sysNotifyVolumeMountedEvent, setremoved , 0,  &removed);

  toprow = 0;
  dirtyp = 1;

  {
    UInt ps;
    ps = sizeof(prefs);
    MemSet(&prefs, ps, 1);
    PrefGetAppPreferences('BOXR', 1, &prefs, &ps, true);
    if (ps != sizeof(prefs)) {
      memset(&prefs, 1, sizeof(prefs));
      prefs[6] = 0;
      baud = 19200;
      (void) memcpy(&prefs[8], &baud, 4);
    }
    FtrSet('BOXR', 1, prefs[2]);
    (void) memcpy(&baud, &prefs[8], 4);
  }

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }

  //dmHdrAttrRecyclable

  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");
  dbrec = 0;
  hand = DmNewRecord(scratch, &dbrec, 20480);
  filelist = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048); /* max tar or zip directory size * 4 */
  filedisp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 4096);
  filelp = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 2048);
  filesort = MemHandleLock(hand);
  hand = DmNewRecord(scratch, &dbrec, 1024);
  filecard = MemHandleLock(hand);


  if( !FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &ver) )
    cardsetup();

  do {
    if (dirtyp) {
      bulk = 0;
      scandbs(0);
      FrmGotoForm(mainform);
      dirtyp = 0;
    }

    EvtGetEvent(&event, -1);

    if (removed) {
      if( removed == -1 || curvol == removed )
	dirlevel = 0;
      removed = 0;
      FrmGotoForm(FrmGetActiveFormID());
    }

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;
    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      bulk = 0;
      switch (formID) {

      default:

      case mainform:
        FrmSetEventHandler(form, MainH);
        break;
      case fileform:
        FrmSetEventHandler(form, FileH);
        break;
      case decomform:
        FrmSetEventHandler(form, DecomH);
        break;
      case instform:
        FrmSetEventHandler(form, InstH);
        break;
      case unzipform:
        FrmSetEventHandler(form, UnzipH);
        break;
      case untarform:
        FrmSetEventHandler(form, UntarH);
        break;
      case copyform:
        FrmSetEventHandler(form, CopyH);
        break;
      case gzipform:
        FrmSetEventHandler(form, GzipH);
        break;
      case infoform:
        FrmSetEventHandler(form, InfoH);
        break;
      case alldbform:
        FrmSetEventHandler(form, AlldbH);
        break;
      case prefform:
        FrmSetEventHandler(form, PrefH);
        break;
      case ainfoform:
        FrmSetEventHandler(form, AInfoH);
        break;
      case bulkform:
        bulk = 1;
        FrmSetEventHandler(form, BulkH);
        break;
      case commform:
        FrmSetEventHandler(form, CommH);
        break;
      case viewform:
        FrmSetEventHandler(form, ViewH);
        break;
      case abulkform:
        bulk = 1;
        FrmSetEventHandler(form, ABulkH);
        break;
      case cardform:
	if( !FtrGet(sysFileCVFSMgr, vfsFtrIDVersion, &ver) )
	  FrmSetEventHandler(form, CardH);
	else {
	  FrmGotoForm(mainform);
	  FrmSetEventHandler(form, MainH);
	}
        break;
      }

    }
    if (form)
      FrmDispatchEvent(&event);
  } while (event.eType != appStopEvent);

  SysNotifyUnregister(0,0/*code resource lid*/, sysNotifyVolumeUnmountedEvent, 0);
  SysNotifyUnregister(0,0/*code resource lid*/, sysNotifyVolumeMountedEvent, 0);

  (void) memcpy(&prefs[8], &baud, 4);
  PrefSetAppPreferences('BOXR', 1, 1, prefs, sizeof(prefs), true);

  ZLTeardown;

  MemPtrUnlock(filedisp);
  MemPtrUnlock(filesort);
  MemPtrUnlock(filelp);
  MemPtrUnlock(filecard);
  MemPtrUnlock(filelist);
  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);
  DmCloseDatabase(scratch);

  return 0;
}
