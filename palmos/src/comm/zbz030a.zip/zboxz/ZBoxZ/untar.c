/* based on funzip.c from unzip 5.40 */

#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

extern char ibuf[];

int untardir(FileHand  fd, char *dir, long int *loc)
{
  char *c;
  unsigned long total, disp=0, i=0;
  int max;

  max = 0;
  DmSet(dir,0,2,0);

  FileSeek(fd, 0, fileOriginBeginning);

  FileRead(fd, ibuf, 1, 512, NULL);
  if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
    return 0;

  FileSeek(fd, 0, fileOriginBeginning);

  for (;;) {
    FileRead(fd, ibuf, 1, 512, NULL);

    if (ibuf[0] == 0)
      FileRead(fd, ibuf, 1, 512, NULL);

    if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
      return max;

    total = FileTell(fd,NULL,NULL) - 512L;
    DmWrite(loc,(i++)*4,&total,4);

    DmWrite(dir,disp,"    ",4);
    DmWrite(dir,disp+4,ibuf,strlen(ibuf)+1);
    disp += 4+strlen(ibuf)+1;
    DmSet(dir,disp,1,0);

    c = &ibuf[124];
    while (*c == ' ')
      c++;
    total = 0;

    do {
      total = (total << 3) + *c++ - '0';
    } while (*c != ' ');

    // round to the block size
    total += 512;
    total &= ~511;
    FileSeek(fd, total, fileOriginCurrent);
    max++;
  }
}

int untar(FileHand  fd, long int loc)
{
  char *c;
  unsigned long total, itot;
  FileHand ofd;
  RectangleType r;

  FileSeek(fd, 0, fileOriginCurrent);

  FileRead(fd,ibuf, 1, 512, NULL);
  if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
    return -1;

  if( loc == -1 ) {
    FileSeek(fd, 0, fileOriginBeginning);
    FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);
  }
  else
    FileSeek(fd, loc, fileOriginBeginning);

  for (;;) {

    FileRead(fd,ibuf, 1, 512, NULL);

    if (ibuf[0] == 0)
      FileRead(fd, ibuf, 1, 512, NULL);

    if (strncmp(&ibuf[257], "GNUtar",6) && strncmp(&ibuf[257], "ustar", 5))
      return 0;

    r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
    WinEraseRectangle(&r, 0);

    r.topLeft.x = 0, r.topLeft.y = 30, r.extent.x = 160, r.extent.y = 15;


    c = &ibuf[124];
    while (*c == ' ')
      c++;
    total = 0;

    do {
      total = (total << 3) + *c++ - '0';
    } while (*c != ' ');

    ofd = FileOpen(0, ibuf, 'DATA', 'BOXR', fileModeReadWrite, NULL);

    StrIToA(ibuf,total);
    strcat(ibuf,"     ");
    WinDrawChars(ibuf,strlen(ibuf),120,0);


    itot = total;
    while (total) {

      FileRead(fd, ibuf, 1, BSIZ, NULL);
      FileWrite(ofd, ibuf, 1, total > BSIZ ? BSIZ : total, NULL);
      total -= total > BSIZ ? BSIZ : total;
      r.extent.x = 160 - (160 * total / itot);
      WinDrawRectangle(&r, 0);
    }
    FileClose(ofd);
    EvtResetAutoOffTimer();

    if( loc != -1 )
      break;

  }
  return 0;

}
