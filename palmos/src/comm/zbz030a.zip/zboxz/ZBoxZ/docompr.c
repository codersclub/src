#define IGNORE_STDIO_STUBS
#define __string_h

#ifdef OLDGCC

#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#else

#include <PalmOS.h>
#include <PalmCompatibility.h>

#endif

#include <Unix/sys_types.h>

int compcore(unsigned char **matat, unsigned char *head, int max);

int compdoc(unsigned char *ibuf, int ilen, unsigned char *obuf, int quick)
{
  int space = 0; /* set for pending space */
  int nhc = 0; /* number of literals in block (so far) */
  int mlen, max; /* for repeated section compression */

  unsigned char *matat; /* match at pointer - where to begin search and where found */
  unsigned char *iptr = ibuf, *iend = ibuf + ilen, *optr = obuf; /* working pointers */
  unsigned char c; /* faster than *iptr everywhere */

  /* 2047 is the maximum displacement,
     shifting narrows the search (it is an N**2 term, so 1023 is almost 4x faster) */

  quick = 2047 >> quick;

  while (iptr != iend) {

    matat = iptr - ibuf > quick ? iptr - quick : ibuf;

    max = iend - iptr > 11 ? 11 : iend - iptr;

    /* check beginning and end cases, then test for a repeat match */
    if (max > 3 && matat != iptr && (mlen = compcore(&matat, iptr, max)) > 1 ) {
      unsigned int uw16;

      nhc = 0;
      if (space)
	*optr++ = ' ', space = 0;

      uw16 = 0x8000 | ((iptr - --matat) << 3) | (++mlen - 3);
      *optr++ = uw16 >> 8;
      *optr++ = uw16 & 0xFF;
      iptr += mlen;
      continue;
    }

    c = *iptr++;

    if (c == ' ') {
      if (space)
        *optr++ = ' ';
      space = 1;
      nhc = 0;
      continue;
    }

    if (space) {
      space = 0;
      nhc = 0;
      if (c >= 0x40 && c <= 0x7F) {
        *optr++ = c ^ 0x80;
        continue;
      } else
        *optr++ = ' ';          /* couldn't squeeze it in */
    }

    if ((c >= 1 && c <= 8) || c >= 0x80) {
      if (nhc) {                /* continue? */
        ++*(optr - ++nhc);
        if (nhc == 8)
          nhc = 0;
      } else {                  /* start */
        *optr++ = '\1';
        nhc = 1;
      }
    } else
      nhc = 0;

    *optr++ = c;

  }

  if (space)
    *optr++ = ' ';              /* add left-over space */

  return optr - obuf;
}
