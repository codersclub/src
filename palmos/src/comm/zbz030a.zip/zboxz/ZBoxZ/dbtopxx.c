#include <PalmOS.h>
typedef unsigned long size_t;
#include "stringil.h"

struct prchead {
  char name[32];                //0-32
  short int attr;               //32-33
  short int vers;               //34-35
  long int cr, md, bkt;         //times 36-47
  long int mn, app, sort;       // zero 48-59 - zero for prcs.
  long int type, crea;          //60-67
  long int uidseed, nxrec;      //68-75 - uidseed rand, nxrec zero;
  short int nrecs;              //76-78
};

struct rsrcdbent {
  long int rsrc;
  short int rsid;
  long int ofst;                //80+10*(nrecs+index)
};

struct normdbent {
  long int ofst;                //80+8*(nrecs+index)
  unsigned char attr, uid[3];
};

/* this won't return any error, but probably should */

/* It also doesn't work (yet) */

Err SendPalmDB(ExgDBWriteProcPtr wrtit, void *fd, const char *nameP,
                LocalID lid, UInt16 cardno)
{
  struct prchead head;
  struct rsrcdbent rsrcent;
  struct normdbent dataent;
  unsigned char buf[40];
  LocalID aiid, siid, lid2;
  int i;
  UInt16 attr;
  UInt32 uid, asz, ssz, ofst, wsz;
  DmOpenRef db;
  void *ap = NULL, *sp = NULL, *xp;

  memset(&head, 0, sizeof(head));

  DmDatabaseInfo(cardno, lid, buf, &head.attr, &head.vers, &head.cr, &head.md,
                 &head.bkt, &head.mn, &aiid, &siid, &head.type, &head.crea);

  strncpy(head.name, buf, 32);

  asz = 0;
  ssz = 0;
  head.app = 0;
  head.sort = 0;

  db = DmOpenDatabase(cardno, lid, dmModeReadOnly);

  if (head.attr & dmHdrAttrResDB) {
    head.nrecs = DmNumResources(db);
    ofst = 80 + 10 * head.nrecs;
  } else {
    head.nrecs = DmNumRecords(db);
    ofst = 80 + 8 * head.nrecs;
  }

  if (aiid) {
    ap = MemLocalIDToLockedPtr(aiid, cardno);
    asz = MemPtrSize(ap);
  }
  if (siid) {
    sp = MemLocalIDToLockedPtr(siid, cardno);
    ssz = MemPtrSize(sp);
  }
  if (asz)
    head.app = ofst;
  if (ssz)
    head.sort = ofst + asz;
  ofst += asz + ssz;

  wsz = sizeof(struct prchead);
  wrtit(&head, &wsz, fd);

  if (head.attr & dmHdrAttrResDB)
    for (i = 0; i < head.nrecs; i++) {
      DmResourceInfo(db, i, &rsrcent.rsrc, &rsrcent.rsid, &lid2);
      rsrcent.ofst = ofst;

      xp = DmGetResourceIndex(db, i);
      uid = MemHandleSize(xp);
      DmReleaseResource(xp);
      ofst += uid;
      wsz = sizeof(rsrcent);
      wrtit(&rsrcent, &wsz, fd);
  } else
    for (i = 0; i < head.nrecs; i++) {
      DmRecordInfo(db, i, &attr, &uid, &lid2);
      dataent.ofst = ofst;

      dataent.attr = attr;
      dataent.uid[0] = uid >> 16;
      dataent.uid[1] = uid >> 8;
      dataent.uid[2] = uid;

      xp = DmGetRecord(db, i);
      uid = MemHandleSize(xp);
      DmReleaseRecord(db, i, false);
      ofst += uid;
      wsz = sizeof(dataent);
      wrtit(&dataent, &wsz, fd);
    }

  i = 0;
  wsz = 2;
  wrtit(&i, &wsz, fd);

  if (aiid) {
    wsz = asz;
    wrtit(ap, &wsz, fd);
    MemPtrUnlock(ap);
  }
  if (siid) {
    wsz = ssz;
    wrtit(sp, &ssz, fd);
    MemPtrUnlock(sp);
  }
#define WRTLIM 2048

  if (head.attr & dmHdrAttrResDB)
    for (i = 0; i < head.nrecs; i++) {
      ap = DmGetResourceIndex(db, i);
      sp = MemHandleLock(ap);
      uid = MemPtrSize(sp);

      ofst = uid;
      while (ofst) {
        wsz = ofst > WRTLIM ? WRTLIM : ofst;
        wrtit(sp, &wsz, fd);
        sp += wsz;
        ofst -= wsz;
      }

      MemHandleUnlock(ap);
      DmReleaseResource(ap);
    } else
    for (i = 0; i < head.nrecs; i++) {
      ap = DmGetRecord(db, i);
      sp = MemHandleLock(ap);
      uid = MemPtrSize(sp);

      ofst = uid;
      while (ofst) {
        wsz = ofst > WRTLIM ? WRTLIM : ofst;
        wrtit(sp, &wsz, fd);
        sp += wsz;
        ofst -= wsz;
      }

      MemHandleUnlock(ap);
      DmReleaseRecord(db, i, false);
    }
  DmCloseDatabase(db);
  return 0;
}
