#define SORTPREFIX 4

#define __string_h

#include <PalmOS.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

extern char ibuf[];

char tempath[512];

extern int selection;
extern char *filecard;
extern long int *filedisp;
extern int maxrow;
extern char *filelist;
extern short int *filesort;
extern char **filelp;
extern int toprow;
extern Int16 fncomp(void *x, void *y, Int32 z);
#define MAXCARDS 16

UInt16 dirlevel = 0;
UInt16 volno[MAXCARDS], curvol;

void cardir()
{
  UInt16 vn;
  UInt32 volit, i, ndb, j, *flpt, disp, *fl;
  char tp[80];
  short int *sortlist;
  FileInfoType fileinf;
  FileRef dir;

  WinEraseWindow();             /* user feedback */
  maxrow = 0;
  disp = 0;

  WinDrawChars("Getting Card Directory...", 25, 0, 0);
  
  volit = vfsIteratorStart;
  if( !dirlevel ) {
    ndb = MAXCARDS;
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    i = 0;
    while( volit != vfsIteratorStop ) {
      if( VFSVolumeEnumerate(&vn,&volit) )
	break;
      volno[maxrow] = vn;
      memset(tp, 0, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */
      StrIToA(&tp[SORTPREFIX], vn+1);
      strcat(&tp[SORTPREFIX], ": ");
      VFSVolumeGetLabel(vn,&tp[SORTPREFIX+3],64);
      memcpy(tp, &vn, 2); //Sort by card number
      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
    strcpy(tempath,"*** Card List ***");
  }
  if( maxrow == 1 ) {
    strcpy(tempath,"/");
    curvol = volno[0];
    dirlevel = 1;
    maxrow = 0;
    disp = 0;
    volit = vfsIteratorStart;
  }
  if( dirlevel ) {
    strcpy(ibuf,tempath);
    if( dirlevel > 1 )      
      ibuf[strlen(ibuf)-1] = 0; // remove trailing slash

    if(VFSFileOpen(curvol,ibuf,vfsModeRead,&dir) )
      ErrDisplay("Could not access directory");

    ndb = 256;
    j = maxrow;
    fl = flpt = MemPtrNew(ndb * 4);
    i = 0;
    fileinf.nameBufLen=72;

    while( volit != vfsIteratorStop ) {
      memset(tp, 0, SORTPREFIX); /* for robustness, if sortprefix is >4, and the sort opt is smaller */
      fileinf.nameP = &tp[SORTPREFIX];
      if( VFSDirEntryEnumerate(dir,&volit,&fileinf) )
	break;
      memcpy(&tp[1], &tp[SORTPREFIX], SORTPREFIX-1); /* this speeds up the sort */
      if( fileinf.attributes & vfsFileAttrDirectory )
	strcat(&tp[SORTPREFIX],"/");
      else
	tp[0]=1;

      DmWrite(filelist, disp, tp, strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1);
      *fl++ = (UInt32) filelist + disp;
      disp += strlen(&tp[SORTPREFIX]) + SORTPREFIX + 1;
      maxrow++;
    }
    DmWrite(filelp, j * 4, flpt, (maxrow - j) * 4);
    MemPtrFree(flpt);
    VFSFileClose(dir);
  }
  WinDrawChars("Sorting Directory...", 20, 0, 15);
  sortlist = MemPtrNew(maxrow * 2 + 2);
  for (i = 0; i < maxrow; i++)
    sortlist[i] = i;
  SysQSort(sortlist, maxrow, 2, fncomp, (Int32) filelp);
  DmWrite(filesort, 0, sortlist, maxrow * 2);
  MemPtrFree(sortlist);

  selection = -1;
  toprow = 0;
}

void cardsetup() {
  FileRef dir;

  dirlevel = 0;
  cardir();
  if(!VFSFileOpen(curvol,"/PALM/Launcher",vfsModeRead,&dir) ) {
    strcpy(tempath,"/PALM/Launcher/");
    dirlevel=2;
    VFSFileClose(dir);
  }

}

void godir() {

  if (selection != -1) {
    if( dirlevel && filelp[selection][0] )
      return;
    if( !dirlevel ) {
      curvol = volno[selection];
      strcpy(tempath,"/");
    }
    else 
      strncat(tempath, filelp[selection] + SORTPREFIX,60);
    dirlevel++;
  }
  else if(dirlevel) {
    dirlevel--;
    if( dirlevel ) {
      char *c;
      c = tempath + strlen(tempath) - 1;
      while( *--c != '/' );
      *++c = 0;
    }
  }
  cardir();
  FrmGotoForm(FrmGetActiveFormID());
}
