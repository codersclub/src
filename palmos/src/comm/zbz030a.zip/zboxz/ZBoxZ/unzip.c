#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include "stringil.h"

#include "SysZLib.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

int FileGetC(FileHand fp)
{
  unsigned char lastchr;
  if (1 != FileRead(fp, &lastchr, 1, 1, NULL))
    return -1;
  return lastchr;
}

#define STORED            0     /* compression methods */
#define DEFLATED          8

#  define CRCVAL_INITIAL  0L

/* PKZIP header definitions */
#define ZIPMAG 0x4b50           /* two-byte zip lead-in */
#define LOCREM 0x0403           /* remaining two bytes in zip signature */
#define LOCSIG 0x04034b50L      /* full signature */
#define LOCFLG 4                /* offset of bit flag */
#define  CRPFLG 1               /*  bit for encrypted entry */
#define  EXTFLG 8               /*  bit for extended local header */
#define LOCHOW 6                /* offset of compression method */
#define LOCTIM 8                /* file mod time (for decryption) */
#define LOCCRC 12               /* offset of crc */
#define LOCSIZ 16               /* offset of compressed size */
#define LOCLEN 20               /* offset of uncompressed length */
#define LOCFIL 24               /* offset of file name field length */
#define LOCEXT 26               /* offset of extra field length */
#define LOCHDR 28               /* size of local header, including LOCREM */
#define EXTHDR 16               /* size of extended local header, inc sig */

/* GZIP header definitions */
#define GZPMAG 0x8b1f           /* two-byte gzip lead-in */
#define GZPHOW 0                /* offset of method number */
#define GZPFLG 1                /* offset of gzip flags */
#define  GZPMUL 2               /* bit for multiple-part gzip file */
#define  GZPISX 4               /* bit for extra field present */
#define  GZPISF 8               /* bit for filename present */
#define  GZPISC 16              /* bit for comment present */
#define  GZPISE 32              /* bit for encryption */
#define GZPTIM 2                /* offset of Unix file modification time */
#define GZPEXF 6                /* offset of extra flags */
#define GZPCOS 7                /* offset of operating system compressed on */
#define GZPHDR 8                /* length of minimal gzip header */

/* Macros for getting two-byte and four-byte header values */
#define SH(p) ((unsigned short int)(unsigned char)((p)[0]) | ((unsigned short int)(unsigned char)((p)[1]) << 8))
#define LG(p) ((unsigned long)(SH(p)) | ((unsigned long)(SH((p)+2)) << 16))

/* Globals */

#define ZBSIZ (BSIZ/4)

unsigned char ibuf[BSIZ], obuf[ZBSIZ];



#define fprintf(a,b) ErrDisplay(b)
#define err(n, m) {ErrDisplay(m);return n;}

int unzipdir(FileHand ifd, char *dir, long int *loc)
{
  unsigned long total, disp = 0, i=0;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  char *c;
  int max;

  DmSet(dir,0,2,0);
  max = 0;

  FileSeek(ifd, 0, fileOriginBeginning);

  /* read ZIPal header, check validity */
  n = FileGetC(ifd);
  if (n > 255 || FileEOF(ifd))
    return 0;
  n |= FileGetC(ifd) << 8;

  if (n != ZIPMAG)
    return 0;

  for (;;) {
    total = FileTell(ifd,NULL,NULL) - 2L;
    DmWrite(loc,(i++)*4,&total,4);

    FileRead(ifd, (char *) h, 1, LOCHDR, NULL);
    if (SH(h) == 0x0201)
      return max;               // start of central directory
    if (SH(h) != LOCREM)
      err(3, "invalid zipfile");

    /* FILENAME */
    ibuf[SH(h + LOCFIL)] = 0;

    FileRead(ifd, ibuf, 1, SH(h + LOCFIL), NULL);

    for (n = SH(h + LOCEXT); n--;)
      FileGetC(ifd);

    total = LG(h + LOCSIZ);
    c = ibuf;

    DmWrite(dir,disp,"    ",4);
    DmWrite(dir,disp+4,c,strlen(c)+1);
    disp += 4+strlen(c)+1;
    DmSet(dir,disp,1,0);

    FileSeek(ifd, total, fileOriginCurrent);

    /* if extended header, get it */
    if ((h[LOCFLG] & EXTFLG) &&
        FileRead(ifd, (char *) h + LOCCRC - 4, 1, EXTHDR, NULL) != EXTHDR)
      err(3, "zipfile ended prematurely");

    max++;

    /* read local header, check validity, and skip name and extra fields */
    n = FileGetC(ifd);
    if (n > 255 || FileEOF(ifd))
      return max;
    n |= FileGetC(ifd) << 8;
    if (n != ZIPMAG)
      return max;
  }
}

/* ************************************************************************ */

int unzip(FileHand ifd, long int loc)
{
  FileHand ofd;
  unsigned long crc32val;
  unsigned long outsiz;         /* total bytes written to out */
  int encrypted;                /* flag to turn on decryption */
  unsigned long total, itot;
  unsigned short int n;
  unsigned char h[LOCHDR];      /* first local header (GZPHDR < LOCHDR) */
  int k = 0, got;
  z_stream pgpz;
  int gz = 0;                   /* true if gzip format */
  char *c;
  RectangleType r;
  DmOpenRef db;

  FileSeek(ifd, 0, fileOriginBeginning);
  /* read ZIPal header, check validity */
  n = FileGetC(ifd);
  if (n > 255 || FileEOF(ifd))
    return 0;
  n |= FileGetC(ifd) << 8;

  if (n != ZIPMAG && n != GZPMAG)
    return -1;

  total = sizeof(db);
  FileControl(fileOpGetOpenDbRef, ifd, &db, &total);

  FileTell(ifd, &total, NULL);

  if (loc == -1) {
    FileSeek(ifd, 0, fileOriginBeginning);
    FileControl(fileOpDestructiveReadMode, ifd, NULL, NULL);
  } else
    FileSeek(ifd, loc, fileOriginBeginning);

  for (;;) {

    /* read local header, check validity, and skip name and extra fields */
    n = FileGetC(ifd);
    if (n > 255 || FileEOF(ifd))
      return 0;

    n |= FileGetC(ifd) << 8;

    r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;
    WinEraseRectangle(&r, 0);

    if (n == ZIPMAG) {
      FileRead(ifd, (char *) h, 1, LOCHDR, NULL);
      if (SH(h) == 0x0201)
        return 0;               // start of central directory
      if (SH(h) != LOCREM)
        err(3, "invalid zipfile");
      if (SH(h + LOCHOW) != STORED && SH(h + LOCHOW) != DEFLATED)
        err(3, "entry not deflated or stored--cannot unpack");

      /* FILENAME */
      ibuf[SH(h + LOCFIL)] = 0;
      FileRead(ifd,ibuf, 1, SH(h + LOCFIL), NULL);

      for (n = SH(h + LOCEXT); n--;)
        gz = FileGetC(ifd);
      gz = 0;
      encrypted = h[LOCFLG] & CRPFLG;
    }

    else if (n == GZPMAG) {
      FileRead(ifd,(char *) h, 1, GZPHDR, NULL);
      if ((h[GZPHOW] != DEFLATED) || (h[GZPFLG] & GZPMUL))
        err(3, "cannot handle this gzip file");

      if (h[GZPFLG] & GZPISX) {
        n = FileGetC(ifd);
        n |= FileGetC(ifd) << 8;
        FileRead(ifd, ibuf, 1, n, NULL);
      }

      if (h[GZPFLG] & GZPISF) {
        c = ibuf;
        while ((*c++ = FileGetC(ifd)) != 0);
      } else {
        LocalID lid;
        UInt16 cardno;

        // Mung the name for gzips if one isn't within the file
        DmOpenDatabaseInfo(db, &lid, NULL, NULL, &cardno, NULL);
        DmDatabaseInfo(cardno, lid, ibuf, NULL, NULL, NULL, NULL,
                       NULL, NULL, NULL, NULL, NULL, NULL);

        c = &ibuf[strlen(ibuf) - 4];
        if (!strcmp(c, ".tgz") || !strcmp(c, ".TGZ"))
          c[2] = 'a', c[3] = 'r';
        else if (!strcmp(++c, ".gz") || !strcmp(c, ".GZ"))
          *c = 0;
        else
          strcat(ibuf, ".guz");
      }

      if (h[GZPFLG] & GZPISC)
        while ((gz = FileGetC(ifd)) != 0 && gz != -1);

      gz = 1;
      encrypted = h[GZPFLG] & GZPISE;
    }

    else
      return 1;

    if( !gz )
      total = LG(h + LOCSIZ);
    if (!total) {
      if (loc == -1)
        continue;
      else
        return -1;
    }

    /* fix filename and open for write */
    c = ibuf;
    while (*c) {
      if (*c <= ' ' || *c >= 0x7f)
        *c = '_';
      c++;
    }
    c = ibuf;
    if (strlen(ibuf) >= 32)
      c += strlen(ibuf) - 31;
    c[31] = 0;
    ofd = FileOpen(0, c, 'DATA', 'BOXR', fileModeReadWrite, NULL);
    WinDrawChars(c, strlen(c), 0, 15);
    if( !ofd )
      return -1;

    /* if entry encrypted, decrypt and validate encryption header */
    if (encrypted)
      err(3, "cannot decrypt entry (need to recompile with full crypt.c)");

    itot = total;
    outsiz = 0L;
    crc32val = CRCVAL_INITIAL;

    r.topLeft.y = 30, r.extent.y = 15;

    /* decompress */
    if (gz || h[LOCHOW]) {      /* deflated entry */
      outsiz = 0;
      memset(&pgpz, 0, sizeof(pgpz));
      ZLSetup;
      inflateInit2(&pgpz, -15);

      while (total && !FileEOF(ifd)) {

	if (0 > (got = FileRead(ifd, ibuf, 1, total > BSIZ ? BSIZ : total, NULL)))
	  break;

	total -= got;
	r.extent.x = 160 - (160 * total / itot);
	WinDrawRectangle(&r, 0);

	pgpz.next_in = ibuf;
	pgpz.avail_in = got;
	while (pgpz.avail_in || !total || FileEOF(ifd) ) {
	  pgpz.next_out = obuf;
	  pgpz.avail_out = ZBSIZ;
	  k = inflate(&pgpz, !total || !FileEOF(ifd) ? 0 : Z_FINISH);
	  /* SHOULD CHECK FOR ERRORS */
	  FileWrite(ofd, obuf, 1, ZBSIZ - pgpz.avail_out, NULL);
	  outsiz += ZBSIZ - pgpz.avail_out;
	  crc32val = crc32(crc32val, obuf, ZBSIZ - pgpz.avail_out);

	  if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ
	      && (total || FileEOF(ifd) ) )  continue; /* for undoc zlib */
	  if (k != Z_OK)
	    break;
	}
      }
      inflateEnd(&pgpz);

      //error status:       (k == Z_STREAM_END);
    }
    else {                      /* stored entry */

      got = LG(h + LOCLEN);
      if (got != LG(h + LOCSIZ))
        err(4, "invalid compressed data--length mismatch");

      total = got;
      while (total) {
        got = FileRead(ifd, ibuf, 1, total > BSIZ ? BSIZ : total, NULL);
        outsiz += got;
        total -= got;
        r.extent.x = 160 * total / itot;
        WinDrawRectangle(&r, 0);
        crc32val = crc32(crc32val, ibuf, got);

        FileWrite(ofd, ibuf, 1, got, NULL);
      }
    }
    FileClose(ofd);
    EvtResetAutoOffTimer();

    /* if extended header, get it */
    if (gz) {
      if (pgpz.avail_in < 8)
        err(3, "gzip ended prematurely");
      memcpy((char *) h + LOCCRC, pgpz.next_in, 8);

      break;                    //THIS DOESN'T WORK HERE
    }
      else
      if ((h[LOCFLG] & EXTFLG) &&
          FileRead(ifd, (char *) h + LOCCRC - 4, 1, EXTHDR, NULL) != EXTHDR)
        err(3, "zipfile ended prematurely");

    /* validate decompression */
    if (LG(h + LOCCRC) != crc32val)
      err(4, "invalid compressed data--crc error");

    if (LG((gz ? (h + LOCSIZ) : (h + LOCLEN))) != outsiz)
      err(4, "invalid compressed data--length error");

    if (loc != -1)
      break;

  }

  return 0;
}


char gzhead[10] = {0x1f , 0x8b, 8 , 0,0,0,0,0,0,3 };

int gzip(FileHand inf, FileHand outf)
{
  z_stream gzipit;
  int readgot, isav;
  unsigned long crc32val, itotal, total = 0;
  RectangleType r;

  r.topLeft.x = 0, r.topLeft.y = 30, r.extent.x = 160, r.extent.y = 15;
  WinDrawChars("GZipping:",9 , 0, 15);

  memset(&gzipit, 0, sizeof(gzipit));
  FileWrite(outf, gzhead, 1, 10, NULL);

  FileTell(inf,&itotal, NULL);

  crc32val = CRCVAL_INITIAL;

  gzipit.next_out = ibuf;
  gzipit.avail_out = BSIZ;

  ZLSetup;
  deflateInit2(&gzipit, /* level */ 6, 8,/* bits */ -13, /* memlevel */ 6, 0);
  readgot = ZBSIZ;

  while (!FileEOF(inf) && readgot == ZBSIZ) {
    if (0 >= (readgot = FileRead(inf, obuf, 1, ZBSIZ, NULL)))
      break;

    crc32val = crc32(crc32val, obuf, readgot);
    total += readgot;
    r.extent.x = 160 * total / itotal;
    WinDrawRectangle(&r, 0);

    gzipit.next_in = obuf;
    gzipit.avail_in = readgot;

    while (gzipit.avail_in || readgot != ZBSIZ) {
      isav = deflate(&gzipit, readgot == ZBSIZ ? 0 : Z_FINISH);
      if( gzipit.avail_out == BSIZ ) /* no bytes added */
	break;
      FileWrite(outf, ibuf, 1, BSIZ - gzipit.avail_out, NULL);
      gzipit.avail_out = BSIZ;
      gzipit.next_out = ibuf;
    }

  }

  isav = deflate(&gzipit, Z_FINISH);
  FileWrite(outf, ibuf, 1, BSIZ - gzipit.avail_out, NULL);

  deflateEnd(&gzipit);

  memcpy(ibuf,&crc32val,4);
  itotal = LG(ibuf);
  FileWrite(outf, &itotal, 1, 4, NULL);
  memcpy(ibuf,&total,4);
  itotal = LG(ibuf);
  FileWrite(outf, &itotal, 1, 4, NULL);

  return 0;
}


/**************************************/

void unrunzip(FileHand ifd) {

  struct prchead {
    char name[32];              //0-32
    short int attr;             //32-33
    short int vers;             //34-35
    long int cr, md, bkt;       //times 36-47
    long int mn, app, sort;     // zero 48-59 - zero for prcs.
    long int type, crea;        //60-67
    long int uidseed, nxrec;    //68-75 - uidseed rand, nxrec zero;
    short int nrecs;            //76-78
  } head;

  struct rsrcdbent {
    long int rsrc;
    short int rsid;
    long int ofst;              //80+10*(nrecs+index)
  } *rsrcent;

  char name[36];
  LocalID lid, aiid, siid;
  int i, k;
  UInt32 asz, ssz, ofst, count, total, got;
  DmOpenRef db;
  void *ap;
  UInt16 cardno = 0;
  FileHand ofd;
  z_stream pgpz;
  RectangleType r;


  FileControl(fileOpDestructiveReadMode, ifd, NULL, NULL);

  ofd = FileOpen(0, "RUNZIPSCRATCH", 'TEMP', 'TZIP', fileModeReadWrite, NULL);

  memset(&pgpz, 0, sizeof(pgpz));
  ZLSetup;
  inflateInit2(&pgpz, -15);

  FileTell(ifd, &total, NULL);
  count = total;

  r.topLeft.y = 15, r.extent.y = 16;

  while (!FileEOF(ifd) ) {

    got = FileRead(ifd, ibuf, 1, BSIZ, NULL);

    count -= got;
    r.extent.x = 160 - (160 * count / total);
    WinDrawRectangle(&r, 0);

    pgpz.next_in = ibuf;
    pgpz.avail_in = got;

    while (pgpz.avail_in || FileEOF(ifd)) {
      pgpz.next_out = obuf;
      pgpz.avail_out = ZBSIZ;

      k = inflate(&pgpz, FileEOF(ifd) ? Z_FINISH : 0);
      /* SHOULD CHECK FOR ERRORS */
      FileWrite(ofd, obuf, 1, ZBSIZ - pgpz.avail_out, NULL);

      if (k == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ && FileEOF(ifd))
        continue;               /* for undoc zlib */

      if (k != Z_OK)
        break;
    }
  }

  inflateEnd(&pgpz);

  FileClose(ifd);

  FileRewind(ofd);
  FileTell(ofd, &total, NULL);
  FileControl(fileOpDestructiveReadMode, ofd, NULL, NULL);

  memset(&head, 0, sizeof(head));
  FileRead(ofd,&head, sizeof(head), 1, NULL);
  count = sizeof(head);


  WinDrawChars(head.name, strlen(head.name), 5, 0);

  if( DmCreateDatabase(cardno, head.name, head.crea, head.type,
		       (head.attr & dmHdrAttrResDB)) ) {
    lid = DmFindDatabase(cardno, head.name);

    /////////////////CONFIRM
    if (lid)
      DmDeleteDatabase(cardno, lid);
    DmCreateDatabase(cardno, head.name, head.crea, head.type,
		     (head.attr & dmHdrAttrResDB)) ;
  }
  lid = DmFindDatabase(cardno, head.name);

  head.attr &= ~dmHdrAttrReadOnly;
  DmSetDatabaseInfo(cardno, lid, NULL, &head.attr, &head.vers, &head.cr,
                    &head.md, &head.bkt, &head.mn, NULL, NULL, NULL, NULL);

  i = sizeof(struct rsrcdbent) * head.nrecs;
  rsrcent = MemPtrNew(sizeof(struct rsrcdbent) + i);
  FileRead(ofd, rsrcent, 1, i, NULL);
  count += i;
  rsrcent[head.nrecs].ofst = total;
  ofst = rsrcent[0].ofst;

  db = DmOpenDatabase(cardno, lid, dmModeReadWrite);

  asz = 0;
  ssz = 0;
  if (head.app)
    asz = (head.sort ? head.sort : ofst) - head.app;
  if (head.sort)
    ssz = ofst - head.sort;

  if (asz) {
    while (count < head.app)
      count +=
        FileRead(ofd, name, 1, head.app - count > 32 ? 32 : head.app - count, NULL);
    ap = DmNewHandle(db, asz);
    count += FileDmRead(ofd, MemHandleLock(ap), 0, 1, asz, NULL);
    MemHandleUnlock(ap);
    aiid = MemHandleToLocalID(ap);
    DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                      &aiid, NULL, NULL, NULL);
  }

  if (ssz) {
    while (count < head.sort)
      count +=
        FileRead(ofd, name, 1, head.sort - count > 32 ? 32 : head.sort - count, NULL);
    ap = DmNewHandle(db, ssz);
    count += FileDmRead(ofd, MemHandleLock(ap), 0, 1, ssz, NULL);
    MemHandleUnlock(ap);
    siid = MemHandleToLocalID(ap);
    DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                      NULL, &siid, NULL, NULL);
  }

  r.topLeft.y = 40, r.topLeft.x = 0, r.extent.y = 16;

  for (i = 0; i < head.nrecs; i++) {
    r.extent.x = ((i + 1) << 5) / head.nrecs * 5;
    WinDrawRectangle(&r, 0);

    while (count < rsrcent[i].ofst && !FileEOF(ofd))
      count +=
        FileRead(ofd, name, 1,
              rsrcent[i].ofst - count > 32 ? 32 : rsrcent[i].ofst - count, NULL);
    ssz = rsrcent[i + 1].ofst - rsrcent[i].ofst;
    ap = DmNewResource(db, rsrcent[i].rsrc, rsrcent[i].rsid, ssz);
    count += FileDmRead(ofd, MemHandleLock(ap), 0, 1, ssz, NULL);
    MemHandleUnlock(ap);
    DmReleaseResource(ap);
  }

  FileClose(ofd);
  MemPtrFree(rsrcent);
  DmCloseDatabase(db);
  FileDelete(0,"RUNZIPSCRATCH");

  return;
}
