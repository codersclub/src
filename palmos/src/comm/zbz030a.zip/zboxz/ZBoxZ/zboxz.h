/* Resources */

#define mainform   1100
#define unzipform  1110
#define untarform  1120
#define fileform   1130
#define decomform  1140
#define instform   1150
#define copyform   1160
#define renform    1170
#define infoform   1180
#define gzipform   1190
#define alldbform  1200
#define prefform   1210
#define ainfoform  1220
#define bulkform   1230
#define abulkform  1240
#define commform   1250
#define viewform   1260
#define cardform   1270

#define mainhelp   1105
#define unziphelp  1115
#define untarhelp  1125
#define filehelp   1135
#define decomhelp  1145
#define insthelp   1155
#define copyhelp   1165
#define renhelp    1175
#define infohelp   1185
#define gziphelp   1195
#define alldbhelp  1205
#define prefhelp   1215
#define ainfohelp  1225
#define bulkhelp   1235
#define abulkhelp  1245
#define commhelp   1255
#define viewhelp   1265
#define cardhelp   1275

#define maintable  1001
#define bripunzip  1002
#define bunzip     1003
#define btodoc     1004
#define buntar     1005
#define binstall   1006
#define bdelete    1007
#define bbeam      1008
#define bfile      1009
#define bexit      1010
#define bdecom     1011
#define binst      1012
#define binfo      1013
#define bhelp      1014
#define bgunzip    1015
#define namefld    1016
#define bok        1017
#define bcpy       1018
#define bren       1019
#define bboxr      1020
#define bgzip      1021
#define bview      1022
#define balldb     1023
#define bbox       1024
#define bunrzip    1024

#define ltype      1025
#define ptype      1026

#define bpref      1027
#define bbulk      1028
#define bnone      1029
#define ball       1030

#define bpref1     1031
#define bpref2     1032
#define bpref3     1033
#define bpref4     1034
#define bpref5     1035
#define bpref6     1036

#define bbackup    1051
#define breadon    1052
#define bcopypr    1053

#define bclipto    1054
#define bysend     1055
#define byrec      1056
#define brsend     1057
#define brrec      1058
#define bvpng      1059
#define bcomm      1060
#define bbaud      1061
#define bmidi      1062
#define bvfax      1063
#define btofax     1064

#define ffname	   1065
#define bstring	   1066
#define fymsend    1067
#define bmcont     1068

#define scrl       1080

#define bfrec	   1099
#define bfsnd      1098

/* ZBoxZ internal */

#define SORTPREFIX 4
