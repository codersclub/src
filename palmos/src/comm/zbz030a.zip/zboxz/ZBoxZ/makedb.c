#define IGNORE_STDIO_STUBS
#define __string_h

#ifdef OLDGCC

#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <Unix/sys_types.h>

#else

#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>

#endif

#include "stringil.h"

struct prchead {
  char name[32];                //0-32
  short int attr;               //32-33
  short int vers;               //34-35
  long int cr, md, bkt;         //times 36-47
  long int mn, app, sort;       // zero 48-59 - zero for prcs.
  long int type, crea;          //60-67
  long int uidseed, nxrec;      //68-75 - uidseed rand, nxrec zero;
  short int nrecs;              //76-78
} head;

struct rsrcdbent {
  long int rsrc;
  short int rsid;
  long int ofst;                //80+10*(nrecs+index)
} rsrcent, rsrcnxt;

struct normdbent {
  long int ofst, uid;           //80+8*(nrecs+index)
} dataent, datanxt;

int MakeDatabase(FileHand  fd, int destruct)
{
  FileHand tfd;
  LocalID lid, aiid, siid;
  int i;
  UInt16 cardno = 0;
  UInt16 num, attr;
  UInt32 uid, asz, ssz, ofst, count, total;
  DmOpenRef db;
  void *ap;
  char buf[8];
  RectangleType r;

  r.topLeft.x = 0, r.topLeft.y = 15, r.extent.x = 160, r.extent.y = 30;

  WinEraseRectangle(&r, 0);
  r.topLeft.y = 30, r.extent.y = 15;

  FileTell(fd, &total, NULL);
  if( destruct )
    FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);

  memset(&head, 0, sizeof(head));
  FileRead(fd, &head, sizeof(head), 1, NULL);

  count = sizeof(head);

  r.extent.x = 160 * count / total;
  WinDrawRectangle(&r, 0);

  WinDrawChars(head.name, strlen(head.name), 0, 15);

  if( DmCreateDatabase(cardno, head.name, head.crea, head.type,
		       (head.attr & dmHdrAttrResDB)) ) {
    lid = DmFindDatabase(cardno, head.name);

    /////////////////CONFIRM

    if (lid)
      DmDeleteDatabase(cardno, lid);
    DmCreateDatabase(cardno, head.name, head.crea, head.type,
		     (head.attr & dmHdrAttrResDB)) ;
  }

  lid = DmFindDatabase(cardno, head.name);

  if (!lid) {
    FileClose(fd);
    return 1;
  }

  //////////FIXME - set this at the end if true;

  head.attr &= ~dmHdrAttrReadOnly;
  DmSetDatabaseInfo(cardno, lid, NULL, &head.attr, &head.vers, &head.cr,
                    &head.md, &head.bkt, &head.mn, NULL, NULL, NULL, NULL);

  {
    char buf[256];

  tfd = FileOpen(0, "MAKEDBtemporary", 'DATA', 'BOXR', fileModeReadWrite, NULL);

  if (head.attr & dmHdrAttrResDB) {
    ssz = sizeof(struct rsrcdbent) * head.nrecs;
    count += ssz;
    while( ssz ) {
      i = ssz > 256 ? 256 : ssz;
      FileRead(fd, buf, 1, i , NULL);
      FileWrite(tfd, buf, 1, i, NULL);
      ssz -= i;
    }
    FileControl(fileOpDestructiveReadMode, tfd, NULL, NULL);
    FileRead(tfd, &rsrcent,1,sizeof(rsrcent),NULL);
    ofst = rsrcent.ofst;
  } else {
    ssz = sizeof(struct normdbent) * head.nrecs;
    count += ssz;
    while( ssz ) {
      i = ssz > 256 ? 256 : ssz;
      FileRead(fd, buf, 1, i , NULL);
      FileWrite(tfd, buf, 1, i, NULL);
      ssz -= i;
    }
    FileControl(fileOpDestructiveReadMode, tfd, NULL, NULL);
    FileRead(tfd, &dataent,1,sizeof(dataent),NULL);
    ofst = dataent.ofst;
  }
  }

  r.extent.x = 160 * count / total;
  WinDrawRectangle(&r, 0);

  db = DmOpenDatabase(cardno, lid, dmModeReadWrite);

  asz = 0;
  ssz = 0;
  if (head.app)
    asz = (head.sort ? head.sort : ofst) - head.app;
  if (head.sort)
    ssz = ofst - head.sort;

  if (asz) {
    while (count < head.app)
      count += FileRead(fd, buf, 1 , head.app - count > 8 ? 8 : head.app - count, NULL);
    ap = DmNewHandle(db, asz);
    count += FileDmRead(fd, MemHandleLock(ap), 0, 1, asz, NULL);
    MemHandleUnlock(ap);
    aiid = MemHandleToLocalID(ap);
    DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                      &aiid, NULL, NULL, NULL);
  }

  if (ssz) {
    while (count < head.sort)
      count += FileRead(fd, buf, 1, head.sort - count > 8 ? 8 : head.sort - count, NULL);
    ap = DmNewHandle(db, ssz);
    count += FileDmRead(fd, MemHandleLock(ap), 0, 1, ssz, NULL);
    MemHandleUnlock(ap);
    siid = MemHandleToLocalID(ap);
    DmSetDatabaseInfo(cardno, lid, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                      NULL, &siid, NULL, NULL);
  }

  r.extent.x = 160 * count / total;
  WinDrawRectangle(&r, 0);

  if (head.attr & dmHdrAttrResDB) {
    for (i = 0; i < head.nrecs; i++) {

      if( i < head.nrecs - 1 )
	FileRead(tfd, &rsrcnxt,1,sizeof(struct rsrcdbent),NULL);
      else
	rsrcnxt.ofst = total;
      ssz = rsrcnxt.ofst - rsrcent.ofst;

      ap = DmNewResource(db, rsrcent.rsrc, rsrcent.rsid, ssz);
      while (count < rsrcent.ofst)
	count += FileRead(fd, buf, 1, rsrcent.ofst - count > 8 ? 8 : rsrcent.ofst - count, NULL);
      count += FileDmRead(fd, MemHandleLock(ap), 0, 1, ssz, NULL);
      MemHandleUnlock(ap);
      DmReleaseResource(ap);

      rsrcent = rsrcnxt;

      r.extent.x = 160 * count / total;
      WinDrawRectangle(&r, 0);
    }

  } else {
    for (i = 0; i < head.nrecs; i++) {

      if( i < head.nrecs - 1 )
	FileRead(tfd, &datanxt,1,sizeof(struct normdbent), NULL);
      else
	datanxt.ofst = total;
      ssz = datanxt.ofst - dataent.ofst;

      num = 0xffff;
      ap = DmNewRecord(db, &num, ssz);
      while (count < dataent.ofst)
	count += FileRead(fd, buf, 1, dataent.ofst - count > 8 ? 8 : dataent.ofst - count, NULL);
      count += FileDmRead(fd, MemHandleLock(ap), 0, 1, ssz, NULL);
      MemHandleUnlock(ap);

      attr = dataent.uid >> 24;
      uid = dataent.uid & 0xffffffUL;
      DmSetRecordInfo(db, num, &attr, &uid);
      DmReleaseRecord(db, num, false);

      dataent = datanxt;

      r.extent.x = 160 * count / total;
      WinDrawRectangle(&r, 0);
    }
  }

  DmCloseDatabase(db);
  FileClose(tfd);
  FileDelete(0,"MAKEDBtemporary");
  return 0;

}
