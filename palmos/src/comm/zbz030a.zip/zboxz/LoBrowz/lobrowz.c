#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <Unix/sys_socket.h>

#include "stringil.h"
#include "stdio2.h"

#ifdef __PALMOS_TRAPS__
Err errno;
#endif

char sendstr1[] = "GET /";
char sendstr2[] = " HTTP/1.0\nHost: ";
char sendstr3[] = "\nAccept: */*\n\n";

char buf[2050];

int MakeDatabase(FILE * fd);

int GetURL(char *host, char *path, int port)
{
  NetSocketRef sock = -1;       // socked file descriptor
  FILE *fd;
  char *cp = NULL;
  Err err, err2;
  Byte allup;
  int i;
  unsigned long len;
  RectangleType r;

  AppNetRefnum = 0;

  err = SysLibFind("Net.lib", &AppNetRefnum);
  err = NetLibOpen(AppNetRefnum, &err2);

  AppNetTimeout = 3000;

  NetLibConnectionRefresh(AppNetRefnum, true, &allup, &err2);

  sock = NetUTCPOpen(host, NULL, port);

  if (sock < 0)
    return 1;

  AppNetTimeout = -1;

  WinDrawChars("Connect   ", 10, 0, 112);

  if( *path == '/' )
    path++;

  send(sock, sendstr1, strlen(sendstr1), 0);
  send(sock, path, strlen(path), 0);
  send(sock, sendstr2, strlen(sendstr2), 0);
  send(sock, host, strlen(host), 0);
  send(sock, sendstr3, strlen(sendstr3), 0);

  len = 0;

  for (;;) {

    WinDrawChars("Wait      ", 10, 0, 112);
    i = recv(sock, &buf[len], 2048 - len, 0);

    if (i < 0)
      break;

    if (!i) {
      WinDrawChars("Bad Header         ", 20, 0, 112);
      SysTaskDelay(100);
      break;
    }

    len += i;

    buf[len] = 0;

    cp = buf;

    while (*cp && strncmp(cp, "\r\n\r\n", 4))
      cp++;
    if (*cp) {
      WinDrawChars(buf, 80, 0, 100);
      cp += 4;
      break;
    }

    WinDrawChars("NoEOH     ", 10, 0, 112);

    SysTaskDelay(100);
  }

  WinDrawChars(buf, 32, 40, 112);

  if (i <= 0) {
    close(sock);
    return 1;
  }

  r.topLeft.x = 0, r.topLeft.y = 0, r.extent.x = 160, r.extent.y = 15;

  WinDrawChars("Open      ", 10, 0, 112);

  WinEraseRectangle(&r, 0);

  fd = FileOpen(0, "WWWFileTempXYZ", 'DATA', 'BRWS', fileModeReadWrite, NULL);

  len -= (cp - buf);

  fwrite(cp, 1, len, fd);

  cp = buf;
  while (*cp && strncmp(cp, "Content-Length: ", 16))
    cp++;
  if (*cp) {
    char *dp;
    cp += 16;
    dp = cp;
    while (*dp >= ' ')
      dp++;
    *dp = 0;
    WinDrawChars(cp, strlen(cp), 0, 100);
  }

  for (;;) {

    i = recv(sock, buf, 1024, 0);

    if (!i) {
      WinDrawChars("Stall      ", 10, 0, 112);
      AppNetTimeout = 1000;
      i = recv(sock, buf, 1024, 0);
      AppNetTimeout = -1;
      if (!i)
        break;
    }

    if (i <= 0)
      break;
    len += i;
    WinDrawChars("More      ", 10, 0, 112);
    if (i != fwrite(buf, 1, i, fd)) {
      WinDrawChars("WERR      ", 10, 0, 112);
      fclose(fd);
      unlink("WWWFileTempXYZ");
      close(sock);
      SysTaskDelay(300);
      return 3;
    }

    StrIToA(buf, len);
    strcat(buf, "    ");
    WinDrawChars(buf, strlen(buf), 0, 100);

  }

  close(sock);

  fclose(fd);
  rename("WWWFileTempXYZ", path);

  return 0;
}


void BreakGetURL(char *tp1)
{
  unsigned char *tp2, *tp3, dns[128];
  unsigned int port = 80, x;

  tp2 = NULL;

  /* break apart URL */

  tp3 = tp1;
  x = 0;
  while (*tp3 && *tp3 != '/' && *tp3 != ':')
    tp3++,x++;

  if( !x || x > 127)
    return;

  memcpy(dns,tp1,x);
  dns[x] = 0;

  if (*tp3 == ':') {
    *tp3++ = 0;
    tp2 = tp3;
    while (*tp3 && *tp3 != '/')
      tp3++;
  }

  x = 0;
  if (tp2 && strlen(tp2))
    x = StrAToI(tp2);
  if (x)
    port = x;

  GetURL(dns, tp3, port);
}

FormPtr form = NULL;

Boolean handleit(EventPtr event)
{
  FieldPtr tf1;
  unsigned char *tp1;
  unsigned int eid;

  switch (event->eType) {

  case frmOpenEvent:
    FrmDrawForm(form);
    FrmSetFocus(form, FrmGetObjectIndex(form, 1001));
    return 1;

  case ctlSelectEvent:

    eid = event->data.ctlEnter.controlID;
    /* process form */
    if (eid == 1005) {

      tf1 = FrmGetObjectPtr(form, FrmGetObjectIndex(form, 1001));
      tp1 = FldGetTextPtr(tf1);

      BreakGetURL(tp1);
      WinEraseWindow();
      FrmDrawForm(form);
    }
    return 1;
  default:
    return 0;
  }
  return 0;
}


DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType event;
  Err err;
  int fid;

  if (cmd != sysAppLaunchCmdNormalLaunch)
    return 0;

    FrmGotoForm(1000);

    do {
      EvtGetEvent(&event, -1);

      if (SysHandleEvent(&event))
        continue;
      if (MenuHandleEvent((void *) 0, &event, &err))
        continue;

      if (event.eType == frmLoadEvent) {
        fid = event.data.frmLoad.formID;
        form = FrmInitForm(fid);
        FrmSetActiveForm(form);
        FrmSetEventHandler(form, (FormEventHandlerPtr) handleit);
      }

      if (form)
        FrmDispatchEvent(&event);

    }
    while (event.eType != appStopEvent);

  return 0;
}
