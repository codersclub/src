#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>

#include "stringil.h"

#define malloc MemPtrNew
#define free MemPtrFree

Boolean color;
unsigned short w,h,bandh;
unsigned int mapmax;
RGBColorType map[256];

unsigned char tcmap[256];

DmOpenRef scratch;
char **lines, *lcur, *editln;

/***************************************************************************/

extern short int *lwzstack, lwzsp, *table;

int nextLWZ();
void initLWZ(short int input_code_size);
#define readLWZ() (lwzsp ? lwzstack[--lwzsp] : nextLWZ())

#define USAT(a,b)                 (((b)<<8)|(a))

int ycnt;

static void putline(int ypos) {
  unsigned char *cp;
  int xpos;
  char buf[10];
 
  StrIToA(buf,ycnt++);
  strcat(buf,"    ");
  WinDrawChars(buf,strlen(buf),0,30);

  cp = editln;
  xpos = w;
  while( xpos-- )
    *cp++ = tcmap[readLWZ()];
  DmWrite(lines[ypos / bandh], w * (ypos % bandh), editln, w);
}

/***************************************************************************/
unsigned long fread(void *buf, unsigned long size);

int doGIF()
{
  unsigned char gbuf[24], c, *cp;
  int i, ypos, lace;
  int Bkgnd;
  LocalID lid;
  unsigned short dbrec;
  VoidHand hand;
  unsigned char cmap[3 * 256];

  fread(gbuf, 13);

  if (strncmp(gbuf, "GIF87a", 6) && strncmp(gbuf, "GIF89a", 6))
    return 1;

  //  w = USAT(gbuf[6], gbuf[7]);
  //  h = USAT(gbuf[8], gbuf[9]);
  // [12] is aspect ratio
  mapmax = 2 << (gbuf[10] & 0x07);

  if (gbuf[10] & 0x80) {         /* Global CMap */
    fread(cmap, mapmax * 3);
    Bkgnd = gbuf[11];
  } else {
    /* if no color maps are present default should have black and white as the first two colors. */
    static int colors[] = { 0, 7, 1, 2, 4, 3, 5, 6 };
    for (i = 0; i < 256 - 8; i++) {
      cmap[i * 3] = (colors[i & 7] & 1) ? ((255 - i) & 0xf8) : 0;
      cmap[i * 3 + 1] = (colors[i & 7] & 2) ? ((255 - i) & 0xf8) : 0;
      cmap[i * 3 + 2] = (colors[i & 7] & 4) ? ((255 - i) & 0xf8) : 0;
    }
    for (; i < 256; i++) {
      cmap[i * 3] = (colors[i & 7] & 1) ? 4 : 0;
      cmap[i * 3 + 1] = (colors[i & 7] & 2) ? 4 : 0;
      cmap[i * 3 + 2] = (colors[i & 7] & 4) ? 4 : 0;
    }
    Bkgnd = -1;                 /* background unspecified */
  }

  fread(gbuf, 10);
  if (gbuf[0] != ',')
    return 2;

  w = USAT(gbuf[5], gbuf[6]);
  h = USAT(gbuf[7], gbuf[8]);
  lace = gbuf[9] & 0x40;
  if (gbuf[9] & 0x80) {
    mapmax = 1 << ((gbuf[9] & 0x07) + 1);
    fread(cmap, mapmax * 3);
  }

  for( i = 0,cp = cmap; i < mapmax; i++ ) {
    map[i].r = *cp++;
    map[i].g = *cp++;
    map[i].b = *cp++;
    map[i].index = i;
    if( !color )
      tcmap[i] = (map[i].r * 54 + map[i].g * 183 + map[i].b * 18) >> 8;
    else
      tcmap[i] = i;
  }

  {
  char buf[10];
 
  StrIToA(buf,w);
  WinDrawChars(buf,strlen(buf),0,15);
  StrIToA(buf,h);
  WinDrawChars(buf,strlen(buf),20,15);

  }

  lwzstack = MemPtrNew(8192);
  table = MemPtrNew(16384);
  if (!lwzstack || !table )
    ErrFatalDisplay("Out of Memory");

  fread(&c, 1);
  initLWZ(c);

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }
  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");

  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);

  editln = malloc(w);
  bandh = 49152 / w;
  lines = malloc((h + bandh - 1) / bandh * 4);

  for (i = 0; i < h; i += bandh) {
    dbrec = 65535;
    hand = DmNewRecord(scratch, &dbrec, w * bandh);
    if (!hand)
      ErrFatalDisplay("Out of Memory");
    lines[i / bandh] = MemHandleLock(hand);
  }

  ycnt = 0;
  if (lace) {
    for (ypos = 0; ypos < h; ypos += 8)
      putline(ypos);
    for (ypos = 4; ypos < h; ypos += 8) 
       putline(ypos);
    for (ypos = 2; ypos < h; ypos += 4) 
       putline(ypos);
    for (ypos = 1; ypos < h; ypos += 2) 
       putline(ypos);
  } else
    for (ypos = 0; ypos < h; ypos++) 
        putline(ypos);

  MemPtrFree(table);
  MemPtrFree(lwzstack);

  return 0;
}

/**************************************************/
void cleanGIF()
{
  int i;

  for (i = 0; i < h; i += bandh)
    MemPtrUnlock(lines[i / bandh]);

  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);

  DmCloseDatabase(scratch);
  free(lines);
  free(editln);
}
