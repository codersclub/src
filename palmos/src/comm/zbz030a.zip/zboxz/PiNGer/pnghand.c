#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stringil.h"

extern unsigned short int w, h, bandh;

UInt32 deep;
Boolean color;

extern char **lines, *editln;

int doPNG();
void cleanPNG();
int doGIF();
void cleanGIF();

FileHand fd = 0;

unsigned long fread(void *buf, unsigned long size) {
  return FileRead(fd,buf,1,size,NULL);
}

void fclose() {
  FileClose(fd);
  fd = 0;
}

int feof() {
  return FileEOF(fd);
}

void rewind() {
  FileSeek(fd,0,fileOriginBeginning);
}

unsigned char *screen;
Byte *LPICF = (Byte *) 0xFFFFFA20;
Byte *LVPW = (Byte *) 0xFFFFFA05;
ULong *LSSA = (ULong *) 0xFFFFFA00;


/**************************************************/
static BitmapType bp1;

void dobitmap(BitmapType * bp, unsigned short int xofs, unsigned short int yofs,
              unsigned short int mag)
{
  unsigned char *loc, *loc2;
  unsigned short int imask, bw, i, j, j0, k, bmw, bmh, bmrb, deep;

  bmw = bp->width;
  bmh = bp->height;
  bmrb = bp->rowBytes;
  deep = bp->pixelSize;

  bw = 8 / deep;
  imask = 0xff << (8 - deep);
  imask &= 0xff;

  memset(screen, 0, 12800);

  if (bmw * mag + xofs >= w)
    j0 = (w / mag - xofs + bw - 1) / bw;
  else
    j0 = bmw / bw;

  for (i = 0; yofs < h && i < bmh; i++, yofs += mag) {

    loc = &screen[i * 80];
    loc2 = lines[yofs / bandh] + w * (yofs % bandh) + xofs;

    j=j0;

    if (mag == 1)
      while (j--) {
        k = 0xf0 & *loc2++;
        k |= *loc2++ >> 4;
        *loc++ = ~k;
    } else
      while (j--) {
        k = 0xf0 & *loc2;
        loc2 += mag;
        k |= *loc2 >> 4;
        loc2 += mag;
        *loc++ = ~k;
      }
  }
}

/**************************************************/
UInt32 PilotMain(UInt16 cmd, void * cmdPBP, UInt16 launchFlags)
{
  EventType event;
  int xo, yo, mag, refresh;
  char *oldscr;
  char tbuf[4];

  if (cmd == sysAppLaunchCmdNormalLaunch) { /* forward to zboxz */
    LocalID lid;
    UInt16 cardno;
    DmSearchStateType sst;
    if( !DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'BOXR', true,
                                       &cardno, &lid))
      SysUIAppSwitch(cardno, lid, sysAppLaunchCmdNormalLaunch, NULL);
    return 0;
  }

  if (cmd != sysAppLaunchCmdOpenDB || !cmdPBP || !strlen(cmdPBP))
    return 0;

  fd = FileOpen(0, cmdPBP, 'DATA', 'BOXR',
                fileModeReadOnly | fileModeAnyTypeCreator, NULL);

  if (!fd)
    return 1;

  deep = 4;
  color = false;

  fread(tbuf,4);
  rewind();

  if (!strncmp(tbuf,"\211PNG",4)) {
    if( doPNG()) {
      WinDrawChars("PNG File decode did not finish", 30, 0, 0);
      SysTaskDelay(200);
      return 1;
    }
  }
  else if (!strncmp(tbuf,"GIF8",4)) {
    if ( doGIF()) {
      cleanGIF();
      WinDrawChars("GIF File decode did not finish", 30, 0, 0);
      SysTaskDelay(200);
      return 1;
    }
  }
  else {
    WinDrawChars("Unrecognized file type", 22, 0, 0);
    SysTaskDelay(200);
    return 1;
  }

  memset(&bp1, 0, sizeof(bp1));

  screen = MemPtrNew(12800 + 40);

  oldscr = *LSSA;
  MemSet(screen, 12800, 0);
  *LPICF |= 0x02;
  *LVPW <<= 2;
  *LSSA = screen;

  bp1.width = 160;
  bp1.height = 160;
  bp1.rowBytes = 20 * deep;
  bp1.pixelSize = deep;
  bp1.version = 2;

  xo = w / 2 - 80, yo = h / 2 - 80, mag = 1, refresh = 1;
  do {
    EvtResetAutoOffTimer();
    EvtGetEvent(&event, refresh ? 0 : -1);

    if (event.eType == nilEvent && !refresh)
      continue;

    if (event.eType == keyDownEvent) {

      switch (event.data.keyDown.chr) {
      case '1'...'8':
        mag = event.data.keyDown.chr - '0';
        refresh = 1;
        break;
      case pageUpChr:
        mag++;
        refresh = 1;
        break;
      case pageDownChr:
        mag--;
        refresh = 1;
        break;
      case vchrLaunch:
	event.eType = appStopEvent;
	break;
      }
    }

    if (SysHandleEvent(&event))
      continue;

    if (event.eType == penDownEvent) {
      if (event.screenY > 160)
        continue;

      xo += event.screenX - 80;
      yo += event.screenY - 80;
      refresh = 1;
    }

    if (refresh) {
      if (mag < 1)
        mag = 1;
      if (mag > 8)
        mag = 8;
      if (xo < 0)
        xo = 0;
      if (yo < 0)
        yo = 0;
      if (xo + 160 * mag > w)
        xo = w - 161 * mag + 1;
      if (yo + 160 * mag > h)
        yo = h - 161 * mag + 1;
      if (xo < 0)
        xo = 0;
      if (yo < 0)
        yo = 0;

      dobitmap(&bp1, xo, yo, mag);
      refresh = 0;
    }

  } while (event.eType != appStopEvent);

  *LSSA = oldscr;
  *LVPW >>= 2;
  *LPICF &= 0xFC;

  MemPtrFree(screen);
  cleanPNG();

  return 0;
}
