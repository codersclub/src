#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Unix/sys_types.h>
#include "stringil.h"

static int ZeroDataBlock = 0;

unsigned long fread(void *buf, unsigned long size);

static int GetDataBlock(unsigned char *buf)
{
  unsigned char count;

  count = 0;
  fread(&count, 1);
  ZeroDataBlock = count == 0;
  if (count)
    fread(buf, count);

  return count;
}

/***************************************************************************/

static int curbit, lastbit, get_done, last_byte;
static int return_clear;

short int *lwzstack, lwzsp, *table;

static short int firstcode, oldcode;

static short int code_size, set_code_size;
static short int max_code, max_code_size;
static short int clear_code, end_code;

void initLWZ(short int input_code_size)
{
  set_code_size = input_code_size;
  code_size = set_code_size + 1;
  clear_code = 1 << set_code_size;
  end_code = clear_code + 1;
  max_code_size = 2 * clear_code;
  max_code = clear_code + 2;

  curbit = lastbit = 0;
  last_byte = 2;
  get_done = 0;

  return_clear = 1;
  lwzsp = 0;
}

static unsigned char lzcbuf[280];

static short int nextCode(short int code_size)
{
  int i, j, end;
  long ret;

  if (return_clear) {
    return_clear = 0;
    return clear_code;
  }

  end = curbit + code_size;

  if (end >= lastbit) {
    int count;

    if (get_done)
      return -1;

    lzcbuf[0] = lzcbuf[last_byte - 2];
    lzcbuf[1] = lzcbuf[last_byte - 1];

    if ((count = GetDataBlock(&lzcbuf[2])) == 0)
      get_done = 1;

    if (count < 0)
      return -1;

    last_byte = 2 + count;
    curbit = (curbit - lastbit) + 16;
    lastbit = (2 + count) * 8;

    end = curbit + code_size;
  }

  j = end / 8;
  i = curbit / 8;

  if (i == j)
    ret = (long) lzcbuf[i];
  else if (i + 1 == j)
    ret = (long) lzcbuf[i] | ((long) lzcbuf[i + 1] << 8);
  else
    ret =
      (long) lzcbuf[i] | ((long) lzcbuf[i + 1] << 8) | ((long) lzcbuf[i + 2] <<
                                                        16);

  ret = (ret >> (curbit % 8)) & (0x7fff >> (15 - code_size));
  curbit += code_size;

  return (int) ret;
}

short int nextLWZ()
{
  short int code, incode;
  register int i;

  while ((code = nextCode(code_size)) >= 0) {
    if (code == clear_code) {

      /* corrupt GIFs can make this happen */
      if (clear_code >= 4096)
        return -2;

      memset(table,0,16384);
      for (i = 0; i < clear_code; ++i)
        table[4096+i] = i;

      code_size = set_code_size + 1;
      max_code_size = 2 * clear_code;
      max_code = clear_code + 2;
      lwzsp = 0;
      do {
        firstcode = oldcode = nextCode( code_size);
      } while (firstcode == clear_code);

      return firstcode;
    }
    if (code == end_code) {
      int count;
      unsigned char wbuf[260];

      if (ZeroDataBlock)
        return -2;

      while ((count = GetDataBlock( wbuf)) > 0);

      return -2;
    }

    incode = code;

    if (code >= max_code) {
      lwzstack[lwzsp++] = firstcode;
      code = oldcode;
    }

    while (code >= clear_code) {
      lwzstack[lwzsp++] = table[4096+code];
      if (code == table[code])
        return (code);
      if (lwzsp >= 4096 )
        return (code);
      code = table[code];
    }

    lwzstack[lwzsp++] = firstcode = table[4096+code];

    if ((code = max_code) < 4096) {
      table[code] = oldcode;
      table[4096+code] = firstcode;
      ++max_code;
      if ((max_code >= max_code_size) && (max_code_size < 4096)) {
        max_code_size *= 2;
        ++code_size;
      }
    }

    oldcode = incode;

    if (lwzsp)
      return lwzstack[--lwzsp];
  }
  return code;
}
