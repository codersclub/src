#include <PalmOS.h>
#include <Unix/sys_types.h>

#include "stringil.h"

#include "SysZLib.h"

/* Mark's macros to extract big-endian short and long ints: */
typedef unsigned char uch;
typedef unsigned short ush;
typedef unsigned long ulg;
#define SH(p) ((ush)(uch)((p)[1]) | ((ush)(uch)((p)[0]) << 8))
#define LG(p) ((ulg)(SH((p)+2)) | ((ulg)(SH(p)) << 16))

#define BS 1440
#define OBS (3*BS)
unsigned char buffer[BS];
static uch outbuf[OBS];

extern Boolean color;

unsigned short int w, h;
unsigned short int bitdisp, bdepth, ityp, lace, nplte = 0, gskip =
  1, bskip, bandh;

static long sz;

int trspflg = 0;

static unsigned short int bkgdr = 0x80;
static unsigned short int bkgdg = 0x80;
static unsigned short int bkgdb = 0x80;

static unsigned short int tspr = 0;
static unsigned short int tspg = 0;
static unsigned short int tspb = 0;

static unsigned short int bkgdy = 0x80;
static unsigned short int tspy = 0;

LocalID lid;
DmOpenRef scratch;

char **lines, *lcur, *editln;

unsigned char cmap[256], r[256], g[256], b[256], a[256];
unsigned int mapmax = 0;
RGBColorType map[256];

unsigned long fread(void *buf, unsigned long size);
void fclose();
int feof();

/**************************************************/
static void filter(unsigned char *curr, unsigned char *prev, int filter,
                   int bpp, int llen)
{
  unsigned char *curr0 = curr, *prev0, *zp = NULL;
  int a, b, c, pa, pb, pc;

  if (filter > 1 && !prev) {
    zp = malloc(llen);
    bzero(zp, llen);
    prev = zp;
  }

  switch (filter) {

  case 1:
    curr += bpp;
    llen -= bpp;
    prev = curr0;
  case 2:
    while (llen--)
      *curr++ += *prev++;
  case 0:
    break;

  case 3:
    while (bpp-- && llen--)
      *curr++ += *prev++ >> 1;
    while (llen--)
      *curr++ += (*prev++ + *curr0++) >> 1;
    break;

  case 4:
    prev0 = prev;
    while (bpp-- && llen--)
      *curr++ += *prev++;
    while (llen--) {
      a = *curr0++, b = *prev++, c = *prev0++;

      pa = abs(b - c);
      pb = abs(a - c);
      pc = abs(a + b - (c << 1));

      *curr++ += (pa <= pb && pa <= pc) ? a : (pb <= pc) ? b : c;
    }
    break;
  }
  if (zp)
    free(zp);
}

 /* for color to grey (of 65536): R=13926 - 54, G=46884 - 183, B=4725 - 18 */
/**************************************************/
/* these are unsigned ints, but are actually 8 bit values */
int getcmap(unsigned int r, unsigned int g, unsigned int b, unsigned int a)
{

  /* a is transparency and is not used yet, or if == 0xff has no effect */
  if( trspflg ) {
    if (!a || (a == 255 && ityp == 2 && r == tspr && g == tspg && b == tspb)) {
      r = bkgdr;
      g = bkgdg;
      b = bkgdb;
    } else if (a < 255) {
      r = (bkgdr * (255 - a) + r * a) >> 8; /* should really be /255 */
      g = (bkgdg * (255 - a) + g * a) >> 8;
      b = (bkgdb * (255 - a) + b * a) >> 8;
    }
  }

  if (color) {
    map[mapmax].r = r;
    map[mapmax].g = g;
    map[mapmax].b = b;
    map[mapmax].index = mapmax;
    return mapmax++;
  } else
    return (r * 54 + g * 183 + b * 18) >> 8;
}

/**************************************************/
int doidat()
{
  /* static */
  unsigned char *p;             /* always points to next filter byte */
  int cur_x, cur_y, cur_pass, cur_xoff, cur_yoff, cur_xskip, cur_yskip, chunk =
    0;
  long cur_width, cur_linebytes;
  z_stream zstrm;
  Word dbrec;
  VoidHand hand;
  long i, j, k;
  unsigned char *eod;
  int err = Z_OK;


  j = (sz > BS) ? BS : sz;
  fread(buffer, (size_t) j);
  sz -= j;

  memset(&zstrm, 0, sizeof(zstrm));
  zstrm.next_in = buffer;
  zstrm.avail_in = j;
  zstrm.next_out = p = outbuf;
  zstrm.avail_out = OBS;

  inflateInit(&zstrm);

  cur_y = 0;
  cur_pass = 1;                 /* interlace pass:  1 through 7 */
  cur_xoff = cur_yoff = 0;
  cur_xskip = cur_yskip = lace ? 8 : 1;
  cur_width = (w + cur_xskip - 1) / cur_xskip; /* round up */
  cur_linebytes = ((cur_width * bitdisp + 7) >> 3) + 1; /* round, fltr */

  lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  if (!lid) {
    DmCreateDatabase(0, "ZBOXZSCRATCHPAD", 'BOXR', 'DATA', false);
    lid = DmFindDatabase(0, "ZBOXZSCRATCHPAD");
  }
  scratch = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!scratch)
    ErrDisplay("Could not access scratchpad");

  editln = malloc(w+8); /* +8 for interleave overflow */
  bandh = 49152 / w;
  lines = malloc((h + bandh - 1) / bandh * 4);

  for (i = 0; i < h; i += bandh) {
    dbrec = 65535;
    hand = DmNewRecord(scratch, &dbrec, w * bandh);
    if (!hand)
      ErrFatalDisplay("Out of Memory");
    lines[i / bandh] = MemHandleLock(hand);
  }

  for (i = 0; i < nplte; i++)
    cmap[i] = getcmap(r[i], g[i], b[i], a[i]);

  k = (1 << bitdisp) - 1;
  while (err != Z_STREAM_END) {

    err = inflate(&zstrm, Z_PARTIAL_FLUSH);
    eod = outbuf + OBS - zstrm.avail_out;

    {
      EventType event;
      EvtGetEvent(&event, 0);
      if (event.eType == penDownEvent) {
	inflateEnd(&zstrm);
	return 1;
      }
    }

    while (p + cur_linebytes <= eod) {

      if( p[0] )
	filter(&p[1], cur_y ? &p[1 - cur_linebytes] : NULL, p[0],
	       (bitdisp + 7) >> 3, cur_linebytes - 1);

      cur_x = cur_xoff;
      lcur = lines[cur_y / bandh];
      lcur += w * (cur_y % bandh);
      (void) memcpy(editln, lcur, w);

      switch (ityp) {

      case 2:
        if (bitdisp == 16)
          for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip)
	    editln[cur_x] = getcmap(p[j], p[j + 2], p[j + 4], 0xff);
        else
          for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip) 
	    editln[cur_x] = getcmap(p[j], p[j + 1], p[j + 2], 0xff);
        break;
      case 6:
        if (bitdisp == 16)
          for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip)
	    editln[cur_x] = getcmap(p[j], p[j + 2], p[j + 4], p[j + 6]);
	else
	  for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip)
	    editln[cur_x] = getcmap(p[j], p[j + 1], p[j + 2], p[j + 3]);
        break;

      case 3:
        if (bitdisp == 8 && gskip == 1) {
          /* optimized copy colormap entry direct */
          unsigned char *s = &p[1];
	  j = cur_linebytes - 1;
          if (color)
	    while( j-- ) {
	      editln[cur_x] = *s++;
	      cur_x += cur_xskip;
	    }
          else               /* still need to go through cmap */
	    while( j-- ) {
	      editln[cur_x] = cmap[*s++];
	      cur_x += cur_xskip;
	    }
        } else
          for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip)
            for (i = 8 - bskip; i >= 0; i -= bskip)
	      editln[cur_x] = cmap[((p[j] >> i) & k) << (8 - bskip)];
        break;
      case 0:
      case 4:                  /* if grey == trsp then sub bkgdy */

        if (bitdisp == 8 && gskip == 1) {
          /* optimized copy colormap entry direct */
          unsigned char *s = &p[1];
	  j = cur_linebytes - 1;
	  while( j-- ) {
	    editln[cur_x] = *s++;
	    cur_x += cur_xskip;
	  }
	}
	else
        for (j = 1; j < cur_linebytes; j += gskip, cur_x += cur_xskip)
          for (i = 8 - bskip; i >= 0; i -= bskip)
	    editln[cur_x] = ((p[j] >> i) & k) << (8 - bskip);
        break;
      }

      DmWrite(lines[cur_y / bandh], w * (cur_y % bandh), editln, w);

      p += cur_linebytes;
      cur_y += cur_yskip;

#ifndef QUIET
      {
        char buf[5];
        StrIToA(buf, chunk++);
        WinDrawChars(buf, strlen(buf), 25, 0);
      }
#endif

      if (lace) {
        while (cur_y >= h) {    /* may loop if very short image */
          ++cur_pass;
          if (cur_pass & 1) {   /* beginning an odd pass */
            cur_yoff = cur_xoff;
            cur_xoff = 0;
            cur_xskip >>= 1;
          } else {              /* beginning an even pass */
            if (cur_pass == 2)
              cur_xoff = 4;
            else {
              cur_xoff = cur_yoff >> 1;
              cur_yskip >>= 1;
            }
            cur_yoff = 0;
          }
          cur_y = cur_yoff;
          /* effective width is reduced if even pass: subtract cur_xoff */
          cur_width = (w - cur_xoff + cur_xskip - 1) / cur_xskip;
          cur_linebytes = ((cur_width * bitdisp + 7) >> 3) + 1;
        }
      } else if (cur_y >= h) {
        break;
      }
    }                           /*p<eod */

    if (err != Z_OK && err != Z_STREAM_END) {
      char buf[8];
      StrIToA(buf, err);
      strcat(buf, " |");
      WinDrawChars(buf, strlen(buf), 80, 0);
      inflateEnd(&zstrm);
      SysTaskDelay(300);
      return 1;
    }

    if (err != Z_OK)
      break;

    /* fix p leaving a history line */
    i = eod - p + cur_linebytes;
    (void) memcpy(outbuf, p - cur_linebytes, i);
    zstrm.next_out = outbuf + i;
    zstrm.avail_out = OBS - i;
    p = outbuf + cur_linebytes;

    if (zstrm.avail_in > BS / 2)
      continue;

    (void) memcpy(buffer, zstrm.next_in, zstrm.avail_in);
    zstrm.next_in = buffer;

    if (!sz) {
      char buf[12];
      fread(buf, 12);    /*crc,siz,IDAT */
      sz = LG(&buf[4]);
      WinDrawChars(&buf[8], 4, 0, 0);
    }

    i = BS - zstrm.avail_in;
    j = (sz > i) ? i : sz;
    fread(&buffer[zstrm.avail_in], j);

    sz -= j;
    zstrm.avail_in += j;

  }
  inflateEnd(&zstrm);
  /*  fread(buffer, 4); */
  return 0;
}

/**************************************************/
#ifndef QUIET
char *pngty[] =
  { "Gray", "Unk1", "RGB ", "CMAP", "GryA", "Unk5", "RGBA", "Unk7" };
#endif

void doihdr()
{
  int i;
#ifndef QUIET
  char buf[20];
#endif
  /* search for IHDR */
  while (!feof()) {

    if (8 != fread(buffer, 8))
      break;
    sz = LG(buffer);
    (void) memcpy(buffer, &buffer[4], 4);
    WinDrawChars(buffer, 4, 0, 0);
    buffer[4] = 0;

    /*------* 
     | IHDR | 
     *------*/
    if (strcmp(buffer, "IHDR") == 0) {

      fread(buffer, sz + 4);

      w = LG(buffer);
      h = LG(buffer + 4);
      bitdisp = (unsigned char) buffer[8];
      bdepth = bitdisp;
      ityp = (unsigned char) buffer[9];
      lace = (unsigned char) buffer[12];

#ifndef QUIET

      WinDrawChars("Width", 5, 1, 30);
      StrIToA(buf, w);
      WinDrawChars(buf, strlen(buf), 30, 30);

      WinDrawChars("Height", 6, 1, 45);
      StrIToA(buf, h);
      WinDrawChars(buf, strlen(buf), 30, 45);

      WinDrawChars("Depth", 5, 1, 60);
      StrIToA(buf, bitdisp);
      WinDrawChars(buf, strlen(buf), 30, 60);

      WinDrawChars("/", 2, 45, 0);

      WinDrawChars("Type", 4, 1, 15);
      StrIToA(buf, ityp);
      WinDrawChars(buf, strlen(buf), 30, 15);
      WinDrawChars(pngty[ityp], 4, 40, 15);

      if (lace) {
        WinDrawChars("Interlaced", 10, 0, 75);
        StrIToA(buf, h * 15 / 8);
        WinDrawChars(buf, strlen(buf), 50, 0);
      } else {
        StrIToA(buf, h);
        WinDrawChars(buf, strlen(buf), 50, 0);
      }
#endif

      switch (ityp) {
      case 0:
        if (bitdisp == 16)
          gskip = 2;
	for (i = 0; i < 256; i++) /* for the IIIc */
	  r[i] = g[i] = b[i] = i;
	memset(a, 0xff, 256);
	nplte = 256;
        break;
      case 2:
        if (bitdisp == 16)
          gskip = 6;
        else
          gskip = 3;
        bitdisp *= 3;           /* RGB */
        break;
      case 4:
        if (bitdisp == 16)
          gskip = 4;
        else
          gskip = 2;
        bitdisp *= 2;           /* gray+alpha */
	for (i = 0; i < 256; i++) /* for the IIIc */
	  r[i] = g[i] = b[i] = i;
	memset(a, 0xff, 256);
	nplte = 256;
        break;
      case 6:
        if (bitdisp == 16)
          gskip = 8;
        else
          gskip = 4;
        bitdisp *= 4;           /* RGBA */
        break;
      }
      bskip = bitdisp / gskip;
      break;

    } else {
      /* BYPASS REST OF UNKNOWN RECORD */
      i = 0;
      while (sz > i) {
        sz -= i;
        i = (sz > BS) ? BS : sz;
        fread(buffer, i);
      }
      fread(buffer, 4);  /* crc */
    }
  }
}

/**************************************************/
void doprefix()
{
  int i, j;
  unsigned char *c;

  /* Look for IDAT and other used chunks */
  while (!feof()) {

    if (8 != fread(buffer, 8))
      break;
    sz = LG(buffer);
    (void) memcpy(buffer, &buffer[4], 4);
    buffer[4] = 0;
    WinDrawChars(buffer, 4, 0, 0);

    c = buffer;

    if (strcmp(buffer, "IDAT") == 0)
      break;

    else if (strcmp(buffer, "PLTE") == 0) {
      fread(buffer, sz + 4);
      nplte = sz / 3;

      /* save palette and do later with alpha and bkgd */
      for (i = j = 0; i < nplte; i++, j += 3) {
        r[i] = *c++;
        g[i] = *c++;
        b[i] = *c++;
      }
      memset(a, 0xff, nplte);
    }
    /* The next two must occur after PLTE */
    else if (strcmp(buffer, "tRNS") == 0) {
      /* Swap bKGD gray for tRNS gray (if no other background) */
      trspflg = 1;

      fread(buffer, sz + 4);
      switch (ityp) {
      case 0:
        tspy = SH(buffer);      /* transparent gray value */
        break;
      case 3:
        c = buffer;
        for (i = 0; i < sz; ++i)
          a[i] = *c++;
        break;
      case 2:                  /* RGB */
        tspr = SH(c);
        c += 2;
        tspg = SH(c);
        c += 2;
        tspb = SH(c);
        if (bdepth == 16) {
          tspr >>= 8;
          tspg >>= 8;
          tspb >>= 8;
        }
        break;
      }

    } else if (strcmp(buffer, "bKGD") == 0) {
      fread(buffer, sz + 4);
      switch (ityp) {
      case 0:
      case 4:
        bkgdy = SH(c);
        if (bdepth == 16)
          bkgdy >>= 8;
        break;
      case 3:
        bkgdr = r[*c];
        bkgdg = g[*c];
        bkgdb = b[*c];
        break;
      case 2:
      case 6:
        bkgdr = SH(c);
        c += 2;
        bkgdg = SH(c);
        c += 2;
        bkgdb = SH(c);
        if (bdepth == 16) {
          bkgdr >>= 8;
          bkgdg >>= 8;
          bkgdb >>= 8;
        }
        break;
      }
    } else if (strcmp(buffer, "IEND") == 0) {
      break;
    } else {
      /* BYPASS REST OF UNIMPLEMENTED RECORD */
      i = 0;
      while (sz > i) {
        sz -= i;
        i = (sz > BS) ? BS : sz;
        fread(buffer, i);
      }
      fread(buffer,  4);  /* crc */
    }
  }
}

/**************************************************/
void cleanPNG()
{
  int i;

  for (i = 0; i < h; i += bandh)
    MemPtrUnlock(lines[i / bandh]);

  while (DmNumRecords(scratch))
    DmRemoveRecord(scratch, 0);

  DmCloseDatabase(scratch);
  free(lines);
  free(editln);
}

/**************************************************/
static unsigned char PNGmagic[] = "\211PNG\r\n\032\n";

int doPNG() {
  unsigned char magic[8];
  int i;

  fread(magic, 8);
  if (memcmp(magic, PNGmagic, 8)) {
    fclose();
    return 1;
  }

  doihdr();

  for (i = 0; i < 256; i++)
    cmap[i] = i;

  doprefix();

  if ((!nplte && ityp == 3) || strcmp(buffer, "IDAT")) {
    fclose();
    return 1;
  }

  ZLSetup;
  EvtResetAutoOffTimer();
  i = doidat();
  EvtResetAutoOffTimer();
  ZLTeardown;
  fclose();

  if (i) {
    cleanPNG();
    return 1;
  }
  return 0;
}
