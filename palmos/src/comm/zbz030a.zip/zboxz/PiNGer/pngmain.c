#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include <Unix/sys_types.h>
#include "stringil.h"
#include <handera/Vga.h>

extern unsigned short int w, h, bandh;

/* returns palette if color, etc. */
extern unsigned int mapmax;
extern RGBColorType map[256];

/* passed to PNG (maybe others) to generate greyscale or colors */
Boolean color;

extern char **lines, *editln;

int doPNG();
void cleanPNG();
int doGIF();
void cleanGIF();

FileHand fd = 0;
FileRef fr = 0;
UInt16 cv;

unsigned long fread(void *buf, unsigned long size)
{
  unsigned long x;
  if (fr)
    VFSFileRead(fr, size, buf, &x);
  else
    x = FileRead(fd, buf, 1, size, NULL);
  return x;
}

void fclose()
{
  if (fr) {
    VFSFileClose(fr);
    fr = 0;
  } else {
    FileClose(fd);
    fd = 0;
  }
}

int feof()
{
  if (fr)
    return VFSFileEOF(fr);
  else
    return FileEOF(fd);
}



void rewind()
{
  if (fr)
    VFSFileSeek(fr, vfsOriginBeginning, 0);
  else
    FileSeek(fd, 0, fileOriginBeginning);
}

/**************************************************/
static Coord maxx, maxy;

/* Depends on w, h, bandh globals */
static void dobitmap(short unsigned int xofs, short unsigned int yofs,
                     short unsigned int mag,
                     short unsigned int dx, short unsigned int dy,
                     short unsigned int dw, short unsigned int dh,
                     short unsigned int deep)
{
  // these comments pertain to rendering to a bitmap
  static unsigned char bpx[sizeof(BitmapType) + 320 + 1024]; // this would be passed in

#define bp ((BitmapType *)bpx)

  unsigned char *loc, *loc2;
  unsigned short int imask, bw, i, j, j0, k, bit;

  bp->width = dw;
  bp->height = 1;               // dh
  bp->pixelSize = deep;
  bp->rowBytes = deep * 20;     // (deep * (dw+15) / 8) & ~1, i.e. word boundary
  bp->version = 2;

  loc = (void *) bp;
  loc += sizeof(BitmapType);
  memset(loc, 0, bp->rowBytes); /* really should be bkgd, not 0 */// * dh

  bw = 8 / deep;
  imask = 0xff << (8 - deep);
  imask &= 0xff;

  if (dw * mag + xofs >= w)
    j0 = (w / mag - xofs + bw - 1) / bw;
  else
    j0 = (dw + bw - 1) / bw;

  for (i = 0; yofs < h && i < dh; i++, yofs += mag) {

    loc = (void *) bp;
    loc += sizeof(BitmapType);
    // loc += i * bp->rowBytes

    loc2 = lines[yofs / bandh] + w * (yofs % bandh) + xofs;

    j = j0;
    switch (deep) {
    case 8:
      if (mag == 1)
        while (j--)
          *loc++ = *loc2++;
      else
        while (j--) {
          *loc++ = *loc2;
          loc2 += mag;
        }
      break;

    case 4:
      if (mag == 1)
        while (j--) {
          k = 0xf0 & *loc2++;
          k |= *loc2++ >> 4;
          *loc++ = ~k;
      } else
        while (j--) {
          k = 0xf0 & *loc2;
          loc2 += mag;
          k |= *loc2 >> 4;
          loc2 += mag;
          *loc++ = ~k;
        }

      break;
    default:                   /* 2 or 1 */
      while (j--) {
        *loc = 0;
        bit = 0;
        do {
          k = ~*loc2 & imask;
          loc2 += mag;
          k >>= deep * bit;
          *loc |= k;
        } while (++bit < bw);
        loc++;
      }
      break;
    }

    WinDrawBitmap(bp, dx, dy + i);

  }
  if (i < dh) {
    RectangleType r = { {0, i}
    , {dh, dh - i}
    };
    WinEraseRectangle(&r, 0);   /* SHOULD BE BKGD! */
  }

}

/**************************************************/

UInt32 PilotMain(UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
  UInt32 deep, odeep;
  EventType event;
  int xo, yo, mag, refresh, xtl, ytl;
  char tbuf[4];
  RectangleType r;
  Coord dx, dy, dm, mx, my;

#ifdef __VGA_H__
  int vga = 0;
  VgaRotateModeType rotateMode;
#else
#warning No Handera VGA Support
#endif

  if (cmd == sysAppLaunchCmdNormalLaunch) { /* forward to zboxz */
    LocalID lid;
    UInt16 cardno;
    DmSearchStateType sst;
    if (!DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'BOXR', true,
                                        &cardno, &lid))
      SysUIAppSwitch(cardno, lid, sysAppLaunchCmdNormalLaunch, NULL);
    return 0;
  }


  if (cmd != sysAppLaunchCmdOpenDB || !cmdPBP)
    return 0;

  {
    char *c = cmdPBP;
    if (*c++) {
      WinDrawChars(cmdPBP, strlen(cmdPBP), 0, 145);
      fd = FileOpen(0, cmdPBP, 'DATA', 'BOXR',
                    fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    } else {
      WinDrawChars(&c[1], strlen(&c[1]), 0, 145);
      VFSFileOpen(*c, &c[1], vfsModeRead, &fr);
    }

  }

  if (!fd && !fr)
    return 1;
#ifdef __VGA_H__
  if (!FtrGet(TRGSysFtrID, TRGVgaFtrNum, &deep)) {
    VgaSetScreenMode(screenMode1To1, rotateModeNone);
    rotateMode = rotateModeNone;
    vga = 1;
  }
#endif
  deep = 1;
  ScrDisplayMode(scrDisplayModeGetSupportedDepths, NULL, NULL, &odeep, NULL);
  ScrDisplayMode(scrDisplayModeGetSupportsColor, NULL, NULL, NULL, &color);

  if (odeep & 0x80)
    deep = 8;
  else if (odeep & 8)
    deep = 4;
  else if (odeep & 2)
    deep = 2;

  ScrDisplayMode(scrDisplayModeGet, NULL, NULL, &odeep, NULL);

  fread(tbuf, 4);
  rewind();

  if (!strncmp(tbuf, "\211PNG", 4)) {
    if (doPNG()) {
      WinDrawChars("PNG File decode did not finish", 30, 0, 0);
      SysTaskDelay(200);
      return 1;
    }
  } else if (!strncmp(tbuf, "GIF8", 4)) {
    if (doGIF()) {
      cleanGIF();
      WinDrawChars("GIF File decode did not finish", 30, 0, 0);
      SysTaskDelay(200);
      return 1;
    }
  } else {
    WinDrawChars("Unrecognized file type", 22, 0, 0);
    SysTaskDelay(200);
    return 1;
  }

  if (color)
    WinPushDrawState();

  ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &deep, NULL);

  if (color)
    WinPalette(winPaletteSet, 0, mapmax, map);

  WinGetDisplayExtent(&maxx, &maxy);

  xo = w / 2 - maxx / 2, yo = h / 2 - maxy / 2, mag = 0, refresh = 1;
  do {

    EvtResetAutoOffTimer();
    EvtGetEvent(&event, refresh ? 0 : -1);

    if (event.eType == nilEvent && !refresh)
      continue;


    dx = xo, dy = yo, dm = mag;

    if (event.eType == keyDownEvent) {
      switch (event.data.keyDown.chr) {
      case '1'...'8':
        mag = event.data.keyDown.chr - '0';
        refresh = 2;
        break;
      case pageUpChr:
        mag++;
        refresh = 2;
        break;
      case pageDownChr:
        mag--;
        refresh = 2;
        break;

#ifdef __VGA_H__
      case '0':
      case '9':
        if (!vga)
          break;
	//        VgaGetScreenMode(&screenMode, &rotateMode);
        VgaSetScreenMode(screenMode1To1, rotateMode++ & 3);
        WinGetDisplayExtent(&maxx, &maxy);
        refresh = 2;
        break;
#endif
      case vchrLaunch:
        event.eType = appStopEvent;
        break;
      }
    }
#ifdef __VGA_H__XXX
    if (event.eType == displayExtentChangedEvent) {
      WinGetDisplayExtent(&maxx, &maxy);
      refresh = 2;
    }
#endif
    if (SysHandleEvent(&event)) {

      WinGetDisplayExtent(&mx, &my);
      if (mx != maxx || my != maxy) {
        maxx = mx, maxy = my;
        refresh = 2;
      } else
        continue;
    }

    if (event.eType == penDownEvent) {
      if (event.screenY > maxy)
        continue;
      xo += event.screenX - maxx / 2;
      yo += event.screenY - maxy / 2;
      refresh = 1;
    }

    if (refresh) {

      if (mag < 1)
        mag = 1;
      if (mag > 8)
        mag = 8;
      if (xo < 0)
        xo = 0;
      if (yo < 0)
        yo = 0;
      if (xo + maxx * mag > w)
        xo = w - (maxx + 1) * mag + 1;
      if (yo + maxy * mag > h)
        yo = h - (maxy + 1) * mag + 1;
      if (xo < 0)
        xo = 0;
      if (yo < 0)
        yo = 0;

      if (refresh == 2 || dm != mag || mag != 1) {
        if (refresh == 2) {
          r.topLeft.x = r.topLeft.y = 0;
          r.extent.x = maxx;
          r.extent.y = maxy;
          WinEraseRectangle(&r, 0);
        }
        refresh = 0;
        dobitmap(xo, yo, mag, 0, 0, maxx > w / mag ? w / mag : maxx,
                 maxy > h / mag ? h / mag : maxy, deep);
        continue;
      }
      refresh = 0;

      dx -= xo;
      dy -= yo;

      if (dx > 0) {
        r.topLeft.x = 0;
        r.extent.x = maxx - dx;
      } else {
        r.topLeft.x = -dx;
        r.extent.x = maxx + dx;
        dx = 0;
      }

      if (dy > 0) {
        r.topLeft.y = 0;
        r.extent.y = maxy - dy;
      } else {
        r.topLeft.y = -dy;
        r.extent.y = maxy + dy;
        dy = 0;
      }

      WinCopyRectangle(NULL, NULL, &r, dx, dy, winPaint);

      /* minimal draw */
      xtl = maxx - r.topLeft.x;
      ytl = r.topLeft.y;

      if (dy) {
        dobitmap(xo, yo, mag, 0, 0, maxx, dy, deep);

        if (dx)
          dobitmap(xo, yo + dy, mag, 0, dy, dx, maxy - dy, deep);

        else if (xtl != maxx)
          dobitmap(xo + xtl, yo + dy, mag, xtl, dy, xtl, maxy - dy, deep);

      } else if (ytl) {
        dobitmap(xo, yo + maxy - ytl, mag, 0, maxy - ytl, maxx, ytl, deep);

        if (dx)
          dobitmap(xo, yo, mag, 0, 0, dx, maxy - ytl, deep);

        else if (xtl != maxx)
          dobitmap(xo + xtl, yo, mag, xtl, 0, xtl, maxy - ytl, deep);

      } else if (dx)
        dobitmap(xo, yo, mag, 0, 0, dx, maxy, deep);
      else if (xtl != maxx)
        dobitmap(xo + xtl, yo, mag, xtl, 0, xtl, maxy, deep);
      continue;

    }

  } while (event.eType != appStopEvent);

  if (color)
    WinPalette(winPaletteSetToDefault, 0, 256, NULL);

  ScrDisplayMode(scrDisplayModeSet, NULL, NULL, &odeep, NULL);

  if (color)
    WinPopDrawState();

  cleanPNG();                   /* works for both */

  return 0;
}
