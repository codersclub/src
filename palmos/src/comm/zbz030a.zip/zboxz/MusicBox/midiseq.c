#define IGNORE_STDIO_STUBS
#define __string_h

#include <PalmOS.h>
#include <Unix/sys_socket.h>
#include <Unix/sys_types.h>
#include <System/SysEvtMgr.h>
#include <Extensions/ExpansionMgr/VFSMgr.h>
#include "stringil.h"

#include "SysZLib.h"

#include <SerialMgrOld.h>

#include "midiseq.h"
#include "midiseqr.h"

UInt16 *TCMP2 = (UInt16 *) 0xFFFFF606;
UInt16 *TCNT2 = (UInt16 *) 0xFFFFF608;

extern void nextbeat(unsigned long least);
extern void playnext();
extern void endseq();
extern void preset();
extern void play();
extern void soundoff();

static unsigned char obuf[64];
extern char chans[16];

UInt16 SerL;
long ttbase;

long click;
UInt16 uSptick;

long cumtick;
long cumtime;

unsigned int meternum;

unsigned int meascnt;
unsigned int beatcnt;
unsigned int subbeat;
unsigned int beatdiv;
char trkflg[NTRKS];

static struct mthd hdrbuf;

struct mthd *hdr;

char *mth[NTRKS];
int trksleft;
int paused;
int playing;
int ffwd;

long tempo;
unsigned int qtrdiv;
unsigned int ntrks;

int smpteclix = 600 / 30;

int playtrk = -1;
static int maxhbmp;
static VoidHand hbh[24];
VoidPtr hexbmp[24];

static DmOpenRef tempdb;
static VoidHand midifile[NTRKS + 2];
static unsigned int nblks;

static unsigned char lastbeat[10];
static int beatx[] = { 56, 72, 88, 104, 120, 128, 144 };

FileHand fd = 0;
FileRef fr = 0;
UInt16 cv;
/*------------------------------------------------------------------------*/

static void locplay()
{
  UInt x = 32767, *xp = &x, i;

  for (i = 1; i < ntrks; i++)
    if (!(trkflg[i] & 2))
      break;
  if (i == ntrks)
    return;

  SysBatteryInfoV20(true, NULL, NULL, xp, NULL, NULL);
  SndPlaySmf(NULL, sndSmfCmdPlay, mth[i] - 22, NULL, NULL, NULL, 0);
}



static unsigned long fread(void *buf, unsigned long size) {
unsigned long x;
  if( fr )
    VFSFileRead(fr,size,buf,&x);
  else
    x = FileRead(fd,buf,1,size,NULL);
  return x;
}

static void fseek(unsigned long offset) {
  if( fr )
    VFSFileSeek(fr,vfsOriginCurrent, offset);
  else
    FileSeek(fd,offset,fileOriginCurrent);
}

static unsigned int ftell() {
unsigned long x;
  if( fr )
    VFSFileTell(fr, &x);
  else
    x = FileTell(fd,NULL,NULL);
  return x;
}

static unsigned int fsize() {
unsigned long x;
  if( fr )
    VFSFileSize(fr, &x);
  else
    FileTell(fd,&x,NULL);
  return x;
}

static void fclose() {
  if( fr ) {
    VFSFileClose(fr);
    fr = 0;
  }
  else {
    FileClose(fd);
    fd = 0;
  }
}

static int feof() {
  if( fr )
    return VFSFileEOF(fr);
  else
    return FileEOF(fd);
}

static void      fdread(void *buf, unsigned int ofst, int len) {
  if( fr )
    VFSFileReadData(fr,len,buf,ofst,NULL);
  else
    FileDmRead(fd,buf,ofst,len,1,NULL);
}

static int opendb()
{
  UInt16 i, n;
  UInt32 tlen, ilen;
  VoidHand thand;
  unsigned char *tptr, *iptr, buf[32];
  LocalID lid;

  WinDrawChars("Open  ", 6, 10, 15);
  hdr = &hdrbuf;

  fread(hdr, 2);

  if (hdr->id[0] == 0x1f && hdr->id[1] == 0x8b) {
    FileHand ofd;
    z_stream pgpz;
    unsigned long int got, total, itot;
    unsigned char *ibuf, *zbuf;

    total = fsize();

    /* gzip */
    fread(buf, 8);

    if (buf[1] & 4) {
      fread(&buf[8], 2);
      i = (buf[9] << 8) + buf[8];
      fseek(i);
    }
    if (buf[1] & 8)
      do {
        buf[8] = 0;
        fread(&buf[8], 1);
      } while (buf[8]);
    if (buf[1] & 16)
      do {
        buf[8] = 0;
        fread(&buf[8], 1);
      } while (buf[8]);

    total -= ftell();
    itot = total;

    WinDrawChars("ungzip", 6, 10, 15);

    ofd = FileOpen(0, "RUNZIPSCRATCH", 'TEMP', 'TZIP', fileModeReadWrite, NULL);
    memset(&pgpz, 0, sizeof(pgpz));
    ZLSetup;
    inflateInit2(&pgpz, -15);
#define BSIZ 4096
#define ZBSIZ 1024
    ibuf = MemPtrNew(BSIZ);
    zbuf = MemPtrNew(ZBSIZ);

    while (!feof()) {

      if (0 > (got = fread(ibuf, BSIZ)))
        break;

      total -= got;
      StrIToA(obuf, total * 100 / itot);
      strcat(obuf, "%    ");
      WinDrawChars(obuf, strlen(obuf), 40, 15);

      pgpz.next_in = ibuf;
      pgpz.avail_in = got;
      while (pgpz.avail_in || feof()) {
        pgpz.next_out = zbuf;
        pgpz.avail_out = ZBSIZ;
        i = inflate(&pgpz, !feof() ? 0 : Z_PARTIAL_FLUSH);
        /* SHOULD CHECK FOR ERRORS */

        FileWrite(ofd, zbuf, ZBSIZ - pgpz.avail_out, 1, NULL);

        if (i == Z_BUF_ERROR && pgpz.avail_out != ZBSIZ && feof())
          continue;             /* for undoc zlib */
        if (i != Z_OK)
          break;
      }
    }

    inflateEnd(&pgpz);
    ZLTeardown;
    free(ibuf);
    free(zbuf);
    fclose();

    fd = ofd;
    fr = 0;

    FileRewind(fd);
    FileControl(fileOpDestructiveReadMode, fd, NULL, NULL);
    fread(hdr, 2);
  }

  WinDrawChars("Unpk            ", 16, 10, 15);
  fread(&(hdr->id[2]), 12);
  ntrks = hdr->ntrks;
  hdr->ntrks = 1;
  hdr->format = 0;

  if (strncmp("MThd", hdr->id, 4))
    return 1;

  lid = DmFindDatabase(0, "MIDITEMPFILE");
  if (!lid) {
    DmCreateDatabase(0, "MIDITEMPFILE", 'TZIP', 'TEMP', true);
    lid = DmFindDatabase(0, "MIDITEMPFILE");
  }

  tempdb = DmOpenDatabase(0, lid, dmModeReadWrite);
  if (!tempdb)
    ErrFatalDisplay("Can't access temp database");
  while (DmNumResources(tempdb))
    DmRemoveResource(tempdb, 0);

  strcpy(obuf, "Trks: ");
  StrIToA(&obuf[strlen(obuf)], ntrks);
  WinDrawChars(obuf, strlen(obuf), 10, 15);

  memcpy(buf, hdr, 14);
  nblks = 0;

  memset(trkflg, 0, sizeof(trkflg));

  for (i = 1; i <= ntrks; i++) {
    if (i > NTRKS)
      break;

    StrIToA(obuf, i);
    WinDrawChars(obuf, strlen(obuf), 50, 15);

    fread(&buf[14], 8);
    memcpy(&tlen, &buf[18], 4);

    ilen = tlen & 0x7fff;

    thand = DmNewResource(tempdb, 'MTrk', i, ilen + 22 + 4);
    if (!thand)
      ErrFatalDisplay("Out of Memory");

    midifile[nblks++] = thand;

    iptr = MemHandleLock(thand);

    DmWrite(iptr, 0, buf, 22);
    fdread(iptr, 22, ilen);
    mth[i - 1] = iptr + 22;
    tlen -= ilen;
    n = 22;
    while (tlen) {
      thand = DmNewResource(tempdb, 'MTrk', i + (tlen >> 8), 32800);
      midifile[nblks++] = thand;
      tptr = MemHandleLock(thand);
      DmWrite(iptr, ilen + n, &tptr, 4);
      ilen = 32768;
      n = 0;
      fdread(tptr, 0, ilen);
      iptr = tptr;
      tlen -= ilen;
    }
  }
  WinDrawChars("+++ ", 4, 10, 15);
  tempo = 500000UL;
  qtrdiv = hdr->division;
  fclose();
  WinDrawChars("--- ", 4, 10, 15);
  FileDelete(0,"RUNZIPSCRATCH");
  WinDrawChars("Ret ", 4, 10, 15);
  return 0;
}

void closedb()
{
  UInt16 i;
  LocalID lid;
  for (i = 0; i < nblks; i--) {
    MemHandleUnlock(midifile[i]);
    DmReleaseResource(midifile[i]);
  }
  nblks = 0;
  DmOpenDatabaseInfo(tempdb, &lid, NULL, NULL, &i, NULL);
  DmCloseDatabase(tempdb);
  DmDeleteDatabase(i, lid);
}

static RectangleType r;

void dispbeat()
{
  unsigned char *op, *lb;
  long l, sb, bc, mc;
  /* display measure and beat count */

  l = cumtime - msclk();
  mc = meascnt;
  bc = beatcnt;
  sb = subbeat;

  if (l) {
    l *= uSptick;
    l /= click;
    sb -= l;
    while (sb < 0)
      bc--, sb += beatdiv;
    while (bc < 0)
      mc--, bc += meternum;
  }

  if (mc < -1)
    mc = -1, bc = 0, sb = 0;

  op = obuf;
  l = mc + 1;
#if 0
  *op++ = l / 1000 % 10;
#endif
  *op++ = l / 100 % 10;
  *op++ = l / 10 % 10;
  *op++ = l % 10;
  *op++ = 17;

#if 0
  for (l = 0; l < 3; l++)
    if (obuf[l] != 0)
      break;
    else
      obuf[l] = 16;
#endif

  l = bc + 1;
  if (meternum > 9) {
    *op++ = l / 10;
    *op++ = l % 10;
  } else {
    *op++ = l;
    *op++ = 16;
  }

  op = obuf;
  lb = lastbeat;

  for (l = 1 /* 0 */ ; l < 7; l++, lb++, op++)
    if (*lb != *op) {
      WinDrawBitmap(hexbmp[*op], beatx[l], 104);
      *lb = *op;
    }
  op = obuf;

  l = 1 + sb * 48 / beatdiv;
  {
    r.topLeft.y = 112;
    r.extent.y = 8;

    if (l < 24) {
      r.topLeft.x = 8, r.extent.x = l;
      WinDrawRectangle(&r, 0);
      r.topLeft.x = 8 + l, r.extent.x = 24;
      WinEraseRectangle(&r, 0);
      r.topLeft.x = 32 + l, r.extent.x = 24 - l;
      WinDrawRectangle(&r, 0);
    } else {
      l -= 24;
      r.topLeft.x = 8, r.extent.x = l;
      WinEraseRectangle(&r, 0);
      r.topLeft.x = 8 + l, r.extent.x = 24;
      WinDrawRectangle(&r, 0);
      r.topLeft.x = 32 + l, r.extent.x = 24 - l;
      WinEraseRectangle(&r, 0);
    }
  }
}

unsigned char lastsmpte[20];
static int smptex[] = { 0, 8, 24, 40, 48, 64, 80, 88, 104, 120, 128, 144 };

void disptime()
{
  unsigned char *op, *lb;
  long l, t, t1;

  t = msclk();
  op = obuf;

  if (t < 0) {
    t = -t;
    *op++ = 19;
  } else
    *op++ = 21;

  t1 = t / 100 / CLKMUL;

  l = (t1 / 3600) % 100;
  *op++ = l / 10;
  *op++ = l % 10;
  *op++ = 17;

  l = (t1 / 60) % 100;
  *op++ = l / 10;
  *op++ = l % 10;
  *op++ = 17;

  l = t1 % 60;
  *op++ = l / 10;
  *op++ = l % 10;
  *op++ = 18;

  l = t % (CLKMUL * 100) / smpteclix;
  *op++ = l / 10;
  *op++ = l % 10;

  op = obuf;
  lb = lastsmpte;

  for (l = 0; l < 12; l++, lb++, op++)
    if (*lb != *op) {
      WinDrawBitmap(hexbmp[*op], smptex[l], 84);
      *lb = *op;
    }
}

void drawticker()
{
  r.topLeft.x = 6, r.topLeft.y = 110, r.extent.y = 12, r.extent.x = 52;
  WinDrawRectangle(&r, 0);
  r.topLeft.x = 8, r.topLeft.y = 112, r.extent.y = 8, r.extent.x = 48;
  WinEraseRectangle(&r, 0);

  r.topLeft.x = 7, r.topLeft.y = 114, r.extent.y = 4, r.extent.x = 50;
  WinEraseRectangle(&r, 0);

  r.topLeft.x = 8, r.topLeft.y = 111, r.extent.x = 16, r.extent.y = 1;
  WinEraseRectangle(&r, 0);
  r.topLeft.x = 40;
  WinEraseRectangle(&r, 0);

  r.topLeft.x = 8, r.topLeft.y = 120, r.extent.x = 12, r.extent.y = 1;
  WinEraseRectangle(&r, 0);
  r.topLeft.x = 32;
  WinEraseRectangle(&r, 0);
}

/*******OUTPUT******************/

FormPtr form;

long playupdate()
{
  long n;

  n = 20;
  if (playing) {
    if (!trksleft)
      endseq();
    else if (paused)
      ttbase += msclk() - cumtime;
    else {
      EvtResetAutoOffTimer();
      n = (cumtime - msclk());
      while (n < 4) {           /* 2.5 msec counts */
        while (cumtime > msclk())
          SysTaskDelay(1);      // save power
        playnext();
        if (!trksleft)
          break;
        if (ffwd) {
          ffwd++;
          ttbase += msclk() - cumtime;
          if (ffwd & 0xf0) {
            ffwd = 1;
            break;
          }
        }
        n = (cumtime - msclk());
      }
      dispbeat();
      disptime();
    }
  }
  if (ffwd)
    n = 1;
  SysTaskDelay(1);
  return n;
}

/*------------------------------------------------------------------------*/

void show()
{
  ttbase = absclk() - cumtime;
  dispbeat();
  ttbase = absclk() - cumtime;
  disptime();
}

void mseek(int type, long target)
{
  int i;

  if (!playing) {
    play();
    playnext();
  }

  paused = 1;
  ffwd = 1;
  i = 0;

  if (target < 0)
    target = 0;

  WinDrawBitmap(hexbmp[13], 4, 20);

  if (type)
    while (cumtime <= target && trksleft) {
      playnext();
      if (i++ == 400) {
        show();
        i = 0;
      }
    }

  else
    while (meascnt <= target && trksleft) {
      playnext();
      if (i++ == 400) {
        show();
        i = 0;
      }
    }
  show();
  WinDrawBitmap(hexbmp[12], 4, 20);
}


static unsigned char *ttlptr;
static long cuepoint = 1;
static VoidHand bpp;

void trkarrow()
{

  r.extent.y = 4;
  r.topLeft.x = 0;
  r.topLeft.y = 48;
  r.extent.x = 8 * 17;
  WinEraseRectangle(&r, 0);
  r.extent.y = 1;
  r.topLeft.x = 3 + 8 * (playtrk + 1);
  r.topLeft.y = 48;
  r.extent.x = 2;
  WinDrawRectangle(&r, 0);
  r.topLeft.x--;
  r.topLeft.y++;
  r.extent.x += 2;
  WinDrawRectangle(&r, 0);
  r.topLeft.x--;
  r.topLeft.y++;
  r.extent.x += 2;
  WinDrawRectangle(&r, 0);
  r.topLeft.x--;
  r.topLeft.y++;
  r.extent.x += 2;
  WinDrawRectangle(&r, 0);
}

static Boolean handleit(EventPtr event)
{
  int handled = 0;
  long target;

  switch (event->eType) {
  case frmOpenEvent:
    form = FrmGetActiveForm();
    FrmSetTitle(form, ttlptr);
    FrmDrawForm(form);

    WinDrawBitmap(MemHandleLock(bpp), 0, 40);
    MemHandleUnlock(bpp);
    memset(chans, 0, 16);
    trkarrow();

    WinDrawBitmap(hexbmp[11], 4, 20);
    drawticker();
    memset(lastsmpte, 0xff, 20);
    memset(lastbeat, 0xff, 10);
    endseq();
    preset();
    dispbeat();
    disptime();
    handled = 1;
    break;

  case ctlSelectEvent:         // A control button was pressed and released.

    switch (event->data.ctlEnter.controlID) {
    case bplay:
      memset(lastsmpte, 0xff, 20);
      memset(lastbeat, 0xff, 10);
      ffwd = 0;
      paused = 0;
      if (!playing)
        play();
      else
        WinDrawBitmap(hexbmp[10], 4, 20);
      handled = 1;
      break;

    case 3400 ... 3416:
      playtrk = event->data.ctlEnter.controlID - 3401;
      trkarrow();
      break;

#if 0
    case 3300:
      target = (cumtime / 21600000 + 1) * 21600000;
      mseek(1, target);
      break;
    case 3301:
      target = (cumtime / 2160000 + 1) * 2160000;
      mseek(1, target);
      break;
#endif
    case 3302:
      target = (cumtime / 360000 + 1) * 360000;
      mseek(1, target);
      break;
    case 3303:
      target = (cumtime / 36000 + 1) * 36000;
      mseek(1, target);
      break;
    case 3304:
      target = (cumtime / 6000 + 1) * 6000;
      mseek(1, target);
      break;
    case 3305:
      target = (cumtime / 600 + 1) * 600;
      mseek(1, target);
      break;
#if 0
      if (event->data.menu.itemID == mgotm && gtok == FrmDoDialog(gotmf)) {
        target = 2160000 * LstGetSelection(ph);
        target += 36000 * LstGetSelection(pm);
        target += 600 * LstGetSelection(ps);
        target += smpteclix * LstGetSelection(pf);
      }
#endif
    case 3308:
      target = ((meascnt + 1) / 1000 + 1) * 1000 - 2;
      mseek(0, target);
      break;
    case 3309:
      target = ((meascnt + 1) / 100 + 1) * 100 - 2;
      mseek(0, target);
      break;
    case 3310:
      target = ((meascnt + 1) / 10 + 1) * 10 - 2;
      mseek(0, target);
      break;
    case 3311:
      target = meascnt;         /* this works because of zero/one base */
      mseek(0, target);
      break;

    case blocal:
      locplay();
      handled = 1;
      break;

    case bstop:
      memset(lastsmpte, 0xff, 20);
      memset(lastbeat, 0xff, 10);
      endseq();
      preset();
      dispbeat();
      disptime();
      cumtime = 0;
      handled = 1;
      WinDrawBitmap(MemHandleLock(bpp), 0, 40);
      MemHandleUnlock(bpp);
      memset(chans, 0, 16);

      break;
    case bpause:
      if (playing)
        WinDrawBitmap(hexbmp[12], 4, 20);
      paused = 1;
      handled = 1;
      break;
    case bfwd:
      if (!playing)
        play();
      ffwd = 1;
      WinDrawBitmap(hexbmp[13], 4, 20);
      soundoff();
      handled = 1;
      break;
    }
    break;

  case menuEvent:
    switch (event->data.menu.itemID) {

    case mset:
      MenuEraseStatus(MenuGetActiveMenu());
      cuepoint = cumtime;
      handled = 1;
      break;
    case mgoto:
      MenuEraseStatus(MenuGetActiveMenu());
      if (cuepoint <= cumtime) {
        memset(lastsmpte, 0xff, 20);
        memset(lastbeat, 0xff, 10);
        endseq();
        preset();
        cumtime = 0;
      }
      mseek(1, cuepoint);
      handled = 1;
      break;
    case mmute:
      if (!playing) {
        int i;
        void *ph;
        FormPtr fm = FrmInitForm(fmute);

        for (i = 1; i < 65; i++) {
          ph = FrmGetObjectPtr(fm, FrmGetObjectIndex(fm, 3500 + i));
          CtlSetUsable(ph, i <= ntrks);
          if (i <= ntrks)
            CtlSetValue(ph, !!(trkflg[i] & 2));
        }
        FrmDoDialog(fm);
        for (i = 1; i <= ntrks; i++) {
          ph = FrmGetObjectPtr(fm, FrmGetObjectIndex(fm, 3500 + i));
          if (CtlGetValue(ph))
            trkflg[i] |= 2;
          else
            trkflg[i] &= 0xfd;
        }
      }
      break;

    case mabout:
      FrmAlert(aabout);
      break;
    case m24:
      smpteclix = 600 / 25;
      break;
    case m25:
      smpteclix = 600 / 24;
      break;
    case m30df:
    case m30:
      smpteclix = 600 / 30;
      break;
    }
    handled = 1;
    break;
  case nilEvent:
    handled = 1;
#if 1                           /* to identify the unhandled list */
  default:
#endif
    break;
  }

  if (!handled) {
    if (form)
      handled = FrmHandleEvent(form, event);
    if (event->screenY < 160)
      handled = 1;
  }
  return handled;
}


UInt32 PilotMain(UInt16 cmd, Ptr cmdPBP, UInt16 launchFlags)
{
  int i;
  SerSettingsType serSettings;
  UInt32 id;
  short err;
  int formID;
  EventType event;

  if (cmd == sysAppLaunchCmdNormalLaunch) { /* forward to zboxz */
    LocalID lid;
    UInt16 cardno;
    DmSearchStateType sst;
    if( !DmGetNextDatabaseByTypeCreator(true, &sst, 'appl', 'BOXR', true,
                                       &cardno, &lid))
      SysUIAppSwitch(cardno, lid, sysAppLaunchCmdNormalLaunch, NULL);
    return 0;
  }

  if (cmd == sysAppLaunchCmdSystemReset) {
    LocalID lid;
    if ((lid = DmFindDatabase(0, "MIDITEMPFILE")))
      DmDeleteDatabase(0, lid);
    return 0;
  }

  if (cmd != sysAppLaunchCmdOpenDB || !cmdPBP)
    return 0;


  {
    char *c = cmdPBP;
    if( *c++ ) {
      ttlptr = cmdPBP;
      WinDrawChars(cmdPBP, strlen(cmdPBP), 0, 145);
      fd = FileOpen(0, cmdPBP, 'DATA', 'BOXR',
                fileModeReadOnly | fileModeAnyTypeCreator, NULL);
    }
    else {
      ttlptr = &c[1];
      WinDrawChars(&c[1], strlen(&c[1]), 0, 145);
      VFSFileOpen(*c,&c[1],vfsModeRead,&fr);
    }

  }
  if (!fd && !fr)
    return 1;

  if (!FtrGet(sysFtrCreator, sysFtrNumProductID, &id) && (id >> 16) >= 2) {
    TCMP2 = (UInt16 *) 0xFFFFF610;
    TCNT2 = (UInt16 *) 0xFFFFF614;
  }
  else {
    TCMP2 = (UInt16 *) 0xFFFFF604;
    TCNT2 = (UInt16 *) 0xFFFFF608;
  }

  WinDrawChars("Loading...", 10, 0, 60);

  playing = 0;
  paused = 0;
  ffwd = 0;

  uSptick = 1000000L / SysTicksPerSecond();
  uSptick /= CLKMUL;

  bpp = DmGet1Resource('Tbmp', 4250);
  for (maxhbmp = 0; maxhbmp < 24; maxhbmp++) {
    if (!(hbh[maxhbmp] = DmGet1Resource('Tbmp', 4096 + maxhbmp)))
      break;
    hexbmp[maxhbmp] = MemHandleLock(hbh[maxhbmp]);
  }

  if (opendb()) {             // add NOT a MIDI file...
    for (i = 0; i < maxhbmp; i++) {
      MemHandleUnlock(hbh[i]);
      DmReleaseResource(hbh[i]);
    }
    DmReleaseResource(bpp);
    return 1;
  }

  SysLibFind("Serial Library", &SerL);
  SerOpen(SerL, 0, 31250);
  SerGetSettings(SerL, &serSettings);
  serSettings.flags = serSettingsFlagBitsPerChar8 | serSettingsFlagStopBits1;
  SerSetSettings(SerL, &serSettings);

  FrmGotoForm(fmiditest);

  form = NULL;
  for (;;) {
    playupdate();
    EvtGetEvent(&event, 0);
    if (event.eType == nilEvent)
      continue;

    if (event.eType == keyDownEvent && event.data.keyDown.chr == vchrLaunch)
      event.eType = appStopEvent;

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;
    if (event.eType == appStopEvent) {
      if (playing)
        endseq();
      break;
    }
    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) {
      case fmiditest:
        FrmSetEventHandler(form, (FormEventHandlerPtr) handleit);
        break;
      }
    }
    FrmDispatchEvent(&event);
  }
  closedb();
  SerClose(SerL);

  for (i = 0; i < maxhbmp; i++) {
    MemHandleUnlock(hbh[i]);
    DmReleaseResource(hbh[i]);
  }
  DmReleaseResource(bpp);
  return 0;
}
