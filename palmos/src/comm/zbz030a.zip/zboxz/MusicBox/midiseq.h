#if 0
#define OS1
#endif

#ifndef OS1 
#define NON_PORTABLE
#define asm

#if 0

#define sysTrapHwrDisplayDrawBootScreen                 0xA24D
//#include <Hardware/Hardware.h>
Err  HwrLCDDrawBitmap(UInt x, UInt y, Ptr bitmapP, Boolean clearFirst)
              SYS_TRAP(sysTrapHwrDisplayDrawBootScreen);

#define WinDrawBitmap(b,x,y) HwrLCDDrawBitmap(x, y, b, 0)
#endif

#else
#define SysTicksPerSecond() sysTicksPerSecond
#endif

#define OS1

#define NTRKS 64

struct mthd {
  unsigned char id[4];
  unsigned long int hlen;
  unsigned short int format;
  unsigned short int ntrks;
  unsigned short int division;
};

#define CLKMUL 6

#define msclk() ( (TimGetTicks()*CLKMUL+*TCNT2*CLKMUL / *TCMP2 ) - ttbase)
#define absclk() (TimGetTicks()*CLKMUL+*TCNT2*CLKMUL / *TCMP2 )

