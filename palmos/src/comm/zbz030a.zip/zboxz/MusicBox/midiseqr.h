#define mmiditest 1000

#define mabout 1001

#define m24 1009
#define m25 1010
#define m30df 1011
#define m30 1012

#define aabout 1000

#define fmiditest 1000

#define bplay 1000
#define bstop 1001
#define bpause 1002
#define bfwd 1003

#define plist 1005
#define tlist 1006

#define blocal 1004

#define gtok 1100

#define mmute 1032
#define mset 1033
#define mgoto 1034

#define fmute 1010
