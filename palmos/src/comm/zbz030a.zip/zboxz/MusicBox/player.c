#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <SerialMgrOld.h>
typedef unsigned long size_t;
#include "stringil.h"
#include "midiseq.h"

extern UInt16 *TCMP2,*TCNT2;
extern UInt16 SerL;
extern long ttbase;
extern long click;
extern UInt16 uSptick;
extern ULong cumtick;
extern ULong cumtime;
extern unsigned int meternum;
extern unsigned int meascnt;
extern unsigned int beatcnt;
extern unsigned int subbeat;
extern unsigned int beatdiv;
extern struct mthd *hdr;
extern char *mth[NTRKS];
extern char trkflg[NTRKS];
extern int trksleft;
extern int paused;
extern int playing;
extern int ffwd;
extern long tempo;
extern unsigned int qtrdiv;

unsigned int mclkdiv;
unsigned int metndiv;

ULong cumlow;
long nextmid;
unsigned int meterden;
unsigned int notesperclk;
unsigned int metronome;

extern unsigned int ntrks;
extern int playtrk;

int laststs[NTRKS];
long nextevt[NTRKS];

long tlens[NTRKS];
unsigned char *tptrs[NTRKS];
int trk;
long trklen;
unsigned char *trkbuf;

extern VoidPtr hexbmp[24];

#define mchkc() (*trkbuf)

extern inline unsigned char mgetc()
{
  unsigned char c;
  if (trklen) {
    c = *trkbuf++;
    if (!(--trklen & 0x7fff))
      memcpy(&trkbuf, trkbuf, 4);
    return c;
  }
  return 0;
}

#define getvar() \
{  register unsigned char cx; \
  for(delta = 0;;delta <<= 7) { \
    cx = mgetc(); \
    delta |= cx & 0x7f; \
    if(! (cx & 0x80)) break; \
  } }

/*---------------------------------------------------------------------------*/
void disptempo()
{
  long l = 600000000L;
  unsigned char obuf[8], *op = obuf;

  l += tempo / 2;
  l /= tempo;

  obuf[4] = l % 10, l /= 10;
  obuf[2] = l % 10, l /= 10;
  obuf[1] = l % 10, l /= 10;
  obuf[0] = l % 10;

  obuf[3] = 18;

  l = 0;
  while (obuf[l] == 0)
    obuf[l++] = 16;
  WinDrawBitmap(hexbmp[*op++], 0, 64);
  WinDrawBitmap(hexbmp[*op++], 16, 64);
  WinDrawBitmap(hexbmp[*op++], 32, 64);
  WinDrawBitmap(hexbmp[*op++], 48, 64);
  WinDrawBitmap(hexbmp[*op], 56, 64);
}

/*---------------------------------------------------------------------------*/
void dispmeter()
{
  unsigned char obuf[8], *op = obuf;
  int l;

  if (meterden < 10)
    *op++ = 16;
  if (meternum < 10)
    *op++ = 16;
  else
    *op++ = meternum / 10;
  *op++ = meternum % 10;
  *op++ = 20;                   /* / */
  if (meterden >= 10)
    *op++ = meterden / 10;
  *op++ = meterden % 10;

  l = 0;
  while (l < 5)
    WinDrawBitmap(hexbmp[obuf[l]], 80 + l * 16, 64), l++;
}

/*---------------------------------------------------------------------------*/
#if 0
char *keys[] = { "Cb ", "Gb ", "Db ", "Ab ", "Eb ", "Bb ", "F  ",
  "C  ", "G  ", "D  ", "A  ", "E  ", "B  ", "F# ", "C# ", "G# ", "D# ",
  "Cb ", "Gb ", "Db "
};

char *mode[] = { "Major", "minor" };
#endif

int dometa()
{
  register unsigned long delta;
  unsigned char c, d;
  int i;

  d = mgetc();
  getvar();
  switch (d) {
#if 0
  case 1...7:
    {
      char buf[128], *cp = buf, ct = 64;
      *cp++ = d + '0';
      *cp++ = ':';
      while (delta--)
        if (ct) {
          *cp++ = mgetc();
          ct--;
        }
      for (ct = 0; ct < 8; ct++)
        *cp++ = ' ';
      *cp = 0;
      WinDrawChars(buf, strlen(buf), 0, 45);
      return 0;
    }
#endif
  case 0x2f:                   /* end of track */
    trksleft--;
    return 1;
  case 0x51:                   /* tempo */
    delta = mgetc();
    delta <<= 8;
    delta |= mgetc();
    delta <<= 8;
    delta |= mgetc();
    click = delta / qtrdiv;
    tempo = delta;
    disptempo();
    return 0;
  case 0x59:
    /* delta should be 2 */
    i = mgetc();
    if (i > 127)
      i -= 256;
    c = mgetc();
    if (c)
      i += 3;
#if 0
    WinDrawChars(keys[i + 7], 3, 80, 75);
    WinDrawChars(mode[!!c], 5, 90, 75);
#endif
    return 0;
  case 0x58:
    /* delta should be 4 */

    meternum = mgetc();
    meterden = 1 << mgetc();

    beatdiv = (4 * qtrdiv) / meterden;

    metronome = mgetc();
    if (!metronome)
      metronome = 24;
    notesperclk = mgetc();

    mclkdiv = qtrdiv / (3 * notesperclk);
    metndiv = metronome * mclkdiv;
    dispmeter();
    return 0;
  default:
    while (delta--)
      mgetc();
    return 0;
  }
}

/*---------------------------------------------------------------------------*/

char chans[16];
int noisy;

int playevts(unsigned char c)
{
  unsigned char wbuf[4], *w = wbuf, wc = 0;
  unsigned char mtype = c;
  register unsigned long delta;

  /* handle special cases, metas and system exclusive */
  if (c >= 0xf0) {
    switch (c & 0x0f) {
    case 0x0f:
      return (dometa());
    case 7:
      getvar();
      while (delta--)
        mgetc();
      return 0;
    case 0:
      getvar();
      if (ffwd) {
        while (delta--)
          mgetc();
        return 0;
      }
      while (c != 0xf7) {
        delta--;
        SerSend10(SerL, &c, 1);
        c = mgetc();
      }
      SerSend10(SerL, &c, 1);

      if (delta) {
        char obuf[20];
        StrCopy(obuf, "Sysex len err ");
        StrIToA(&obuf[StrLen(obuf)], delta);
        WinDrawChars(obuf, StrLen(obuf), 10, 45);
      }
      return 0;
    }
    return 0;
  }
  if (ffwd) {
    if (c > 0x7f) {
      if ((c & 0xc0) == 0x80 || (c & 0xf0) == 0xe0)
        (void) mgetc();
      (void) mgetc();
    }
    return 0;
  }

  if (c > 0x7f) {
    RectangleType r;
    r.topLeft.x = ((c & 15) + 1) * 8, r.topLeft.y =
      40 + (chans[c & 15]++ & 7), r.extent.y = 1, r.extent.x = 8;
    WinInvertRectangle(&r, 0);

    //    WinDrawChars(&spin[chans[c&15]++ & 7],1,10*(c&15),45);
    *w++ = c;
    wc++;
    c = mgetc();
  }
  switch (mtype >> 4) {
  case 0x08:
  case 0x09:
  case 0x0a:
  case 0x0b:
  case 0x0e:
    *w++ = c;
    wc++;
    c = mgetc();
  case 0x0c:
  case 0x0d:
    *w++ = c;
    wc++;
  }

  if (SerSend10(SerL, wbuf, wc))
    SerClearErr(SerL);

#if 1
  if (playtrk == (0x0f & mtype))
    switch (mtype >> 4) {
      SndCommandType sound;

    case 0x08:                 //off
      if( (noisy & 0x7f) != wbuf[1] )
	break;
      noisy = 0;
      sound.cmd = sndCmdQuiet;
      SndDoCmd(NULL, &sound, true);
      break;

    case 0x09:                 //on
      sound.cmd = sndCmdNoteOn;
      sound.param1 = wbuf[1];
      noisy = wbuf[1] | 0x80;
      sound.param2 = -1;
      sound.param3 = wbuf[2];
      SndDoCmd(NULL, &sound, true);
      break;
    }
#endif

  return 0;
}

/*---------------------------------------------------------------------------*/

#ifdef MIDICLOCK
long midiccnt, midiclow;
#endif
#ifdef METROCLK
long metrncnt, metrnlow;
#endif

void nextbeat(unsigned long least)
{
  unsigned long nextsch;

  nextsch = least - cumtick;

  /* this has the next scheduled event - can be adjusted so
     split long periods for the metronome or such */

  subbeat += nextsch;

  beatcnt += subbeat / beatdiv;
  subbeat %= beatdiv;
  meascnt += beatcnt / meternum;
  beatcnt %= meternum;

  cumlow += nextsch * click;
  if (cumlow <= 0xffff) {
    UInt16 clt = cumlow;
    cumtime += clt / uSptick;
    clt %= uSptick;
    cumlow = clt;
  } else {
    cumtime += cumlow / uSptick;
    cumlow %= uSptick;
  }

  cumtick = least;

  /* technically, the midiclocks and metronome (including beats)
     should be handled as pseudo tracks so the events would be
     properly scheduled */

#ifdef MIDICLOCK
  midiclow += nextsch;
  /* midi clocks */
  midiccnt += midiclow / mclkdiv;
  midiclow %= mclkdiv;
#endif

#ifdef METROCLK
  metrnlow += nextsch;
  /* metronome tick (ding if beatcnt == 0 ) */
  metrncnt += metrnlow / metndiv;
  metrnlow %= metndiv;
#endif

#ifdef METRONOME
  if (metrnlow / metndiv) {
#if 0
    unsigned char metr1[] = { 0x99, 0x34, 0x64, 0x89, 0x34, 0x64 };
    unsigned char metr2[] = { 0x99, 0x33, 0x64, 0x89, 0x33, 0x64 };
    SerSend10(SerL, beatcnt ? metr2 : metr1, 6);
#else
    SYS_TRAP(sysTrapHwrBacklightV33);
#endif
  }
#endif
}

/*---------------------------------------------------------------------------*/
void playnext()
{
  register unsigned long delta;
  unsigned long *nevp = nextevt, least;
  char *dflg = trkflg;
  int *lsts = laststs;

  least = 0xffffffff;

  for (trk = 0; trk < ntrks; trk++, nevp++, dflg++, lsts++) {

    if (*dflg)
      continue;

    if (least > *nevp)
      least = *nevp;

    if (cumtick < *nevp)
      continue;

    if (0 >= (trklen = tlens[trk])) {
      (*dflg)++;
      trksleft--;
      continue;
    }
    trkbuf = tptrs[trk];
    do {
      if (mchkc() > 0x7f)
        *lsts = mgetc();

      if (!(*dflg = playevts(*lsts))) {
        getvar();
        *nevp += delta;
      } else
        break;

    } while (cumtick >= *nevp);

    tptrs[trk] = trkbuf;
    tlens[trk] = trklen;
  }

  if (least == 0xffffffff)
    return;

  nextbeat(least);
}

/*---------------------------------------------------------------------------*/
void preset()
{
  register unsigned long delta;
  /* click is the number of microseconds per delta */

  if (qtrdiv > 0)
    click = tempo / qtrdiv;     /* default tempo of 120 */
  else {                        /* smpte like */
    qtrdiv = -(hdr->division >> 8);
    if (qtrdiv == 29)
      qtrdiv++;
    click = 1000000 / (hdr->division & 0xff) / qtrdiv;
  }
  meternum = 4;
  meterden = 4;
  notesperclk = 8;
  metronome = 24;
  subbeat = 0;
  beatcnt = 0;
  meascnt = 0;
  beatdiv = (4 * qtrdiv) / meterden;
  mclkdiv = qtrdiv / (3 * notesperclk);
  metndiv = metronome * mclkdiv;

  trksleft = ntrks;
  if (!ntrks)
    return;

  for (trk = 0; trk < ntrks; trk++) {
    trkbuf = mth[trk];

    memcpy(&trklen, &trkbuf[-4], 4);

    if (trklen > 0 && !(trkflg[trk] & 0xfe)) {
      trkflg[trk] &= 0xfe;
      getvar();

      while (trklen > 0 && !delta) {
        unsigned char c;

        c = mchkc() & 0xf0;
        if (c != 0xf0 && c != 0xc0)
          break;
        trkflg[trk] = playevts(mgetc());
        getvar();
      }

      nextevt[trk] = delta;
    } else
      trkflg[trk] |= 1;

    tptrs[trk] = trkbuf;
    tlens[trk] = trklen;
  }

  ttbase = absclk();
  disptempo();
  dispmeter();
}

/*---------------------------------------------------------------------------*/
void play()
{
  preset();

  if (!trksleft)
    return;

  WinDrawBitmap(hexbmp[10], 4, 20);

  playing = 1;
  ttbase = absclk() + beatdiv * meternum * click / uSptick;
  cumtime = 0;
  cumlow = 0;
  cumtick = 0;

  /* if we don't want to start paused... */
#if 0
  playnext();
#endif
}

/*---------------------------------------------------------------------------*/
static unsigned char offmsg[] = { 0xb0, 123, 0, 120, 0, 121, 0, 40, 0 };

void soundoff()
{
  int i;

  for (i = 0; i < 16; i++) {
    if (SerSend10(SerL, offmsg, 9))
      SerClearErr(SerL);
    offmsg[0]++;
  }
  offmsg[0] = 0xb0;
  if (SerSend10(SerL, offmsg, 3))
    SerClearErr(SerL);
}

void endseq()
{
  SndCommandType sound;
  sound.cmd = sndCmdQuiet;
  SndDoCmd(NULL, &sound, true);

  if (playing) {
    playing = 0;
    soundoff();
  }

  WinDrawBitmap(hexbmp[11], 4, 20);
  ffwd = 0;
  paused = 0;
}
