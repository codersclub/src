#define fserttest           1000

#define mserttest           1000

#define mabout         1001
#define mnext          1002

#define aabout            1000

#define bbaud         1000
#define birda         1001
#define brs         1002
#define bsend         1003
#define baux         1004

#define bbackup         1005
#define bmemory         1006

#define plist 1005
#define tlist 1006

#define entarea 1010
