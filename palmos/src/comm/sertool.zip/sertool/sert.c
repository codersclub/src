#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <SerialMgr.h>
#include <System/SysEvtMgr.h>

#include "sert.h"

static UInt16 SerL = 0;
static unsigned char prefs[176];
static unsigned int screen[10][10];

int maxhbmp;
VoidHand hbh[24];
VoidPtr hexbmp[24];

static int StartApplication(void)
{
  SerSettingsType serSettings;
  UInt cps;

  for (maxhbmp = 0; maxhbmp < 24; maxhbmp++) {
    if (!(hbh[maxhbmp] = DmGet1Resource('Tbmp', 4096 + maxhbmp)))
      break;
    hexbmp[maxhbmp] = MemHandleLock(hbh[maxhbmp]);
  }

  MemSet(screen, sizeof(screen), 0xff);

  cps = sizeof(prefs);
  MemSet(&prefs, cps, 0);
#ifndef OS2
  PrefGetAppPreferencesV10('SerT', 0, &prefs, cps);
#else
  PrefGetAppPreferences('SerT', 0, &prefs, &cps, true);
#endif

  SysLibFind("Serial Library", &SerL);
  SerOpen(SerL, 0, 38400);
  SerGetSettings(SerL, &serSettings);
  serSettings.flags = serSettingsFlagBitsPerChar8 | serSettingsFlagStopBits1;
  SerSetSettings(SerL, &serSettings);

  FrmGotoForm(fserttest);
  return 0;
}

static void StopApplication(void)
{
  int i;

#ifndef OS2
  PrefSetAppPreferencesV10('SerT', 0, &prefs, sizeof(prefs));
#else
  PrefSetAppPreferences('SerT', 0, 1, &prefs, sizeof(prefs), true);
#endif
  SerClose(SerL);
  for (i = 0; i < maxhbmp; i++) {
    MemHandleUnlock(hbh[i]);
    DmReleaseResource(hbh[i]);
  }
}

static unsigned int displn = 0;

static void Dispsertn()
{
  unsigned char loctext[80];
  int i;
  unsigned long n = 0;

  if (SerReceiveCheck(SerL, &n))
    SerClearErr(SerL);
  if (!n)
    return;
  if (n > 80)
    n = 80;
  SerReceive10(SerL, loctext, n, -1);
  EvtResetAutoOffTimer();
  for (i = 0; i < n; i++) {
    WinDrawBitmap(hexbmp[loctext[i] >> 4],
                  (displn & 7) * 16, 16 + 10 * (displn >> 3));
    WinDrawBitmap(hexbmp[loctext[i] & 0x0f],
                  (displn & 7) * 16 + 7, 16 + 10 * (displn >> 3));
    displn++;
    if (displn >= 80)
      displn = 0;
  }
}

static FormPtr form;
static unsigned int xstate;
static unsigned char xmem[16];

#define UART_IRDA_ENABLE   0x0020
#define UART_IRDA_DISABLE  0xFFDF
#define UART_POLARITY_INVERTED   0x000C
#define UART_POLARITY_NORMAL     0xFFF3

Word *UART_BAUD_REG = (Word *) 0xfffff902;
Word *UART_MISC_REG = (Word *) 0xfffff908;
Word *UART_SC_REG = (Word *) 0xfffff900;
Word *UART_PORTJ_REG = (Word *) 0xfffff438;
Word *PLL_REG = (Word *) 0xfffff202;

#if 1
char rembuf[] =
{
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
  0xff, 0xff, 0xff, 0xff, 0xff,
  0x55, 0x55, 0x55, 0x55, 0x55,
};
#endif

	      char UUbuf[] = "UUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUUU";


static int irdaflg = 0;

static Boolean handleit(EventPtr event)
{
  unsigned int i, eid;
  int handled = 0;

  switch (event->eType) {
  case frmOpenEvent:
    form = FrmGetActiveForm();
    FrmDrawForm(form);
    handled = 1;
    break;
  case ctlSelectEvent:
    eid = event->data.ctlEnter.controlID;
    switch (eid) {
    case baux:
      {
        RectangleType r =
        {0, 126, 120, 8};
        unsigned long s = 0;
        unsigned int p,q;

        WinEraseRectangle(&r, 0);

        for (i = 0; i < xstate; i++)
          s = s * 10 + (i & 1 ? xmem[i / 2] & 0x0f : xmem[i / 2] >> 4);

        xstate = 0;
        handled = 1;
	s = (s + 16384) / 32768;
	p = s / 14 - 1;
	q = s % 14 + 1;
	if( p <= q )
	  break;

	*PLL_REG = (*PLL_REG & 0xf000) | (q << 8) | p;
        s = 32768 * (14 * (1 + p) + q + 1);

        StrIToA(xmem, s);
        WinDrawChars(xmem, StrLen(xmem), 0, 120);
      }
      break;
    case bbaud:
      {
        RectangleType r =
        {0, 126, 120, 8};
        unsigned long k, s, b = 0;
        unsigned int e = 0;

        WinEraseRectangle(&r, 0);

        for (i = 0; i < xstate; i++)
          b = b * 10 + (i & 1 ? xmem[i / 2] & 0x0f : xmem[i / 2] >> 4);
        xstate = 0;
        handled = 1;

        s = (32768 / 16) * (14 * (1 + (*PLL_REG & 0xff)) + ((*PLL_REG >> 8) & 0x0f) + 1);

        k = (s + b / 2) / b;
        while (k > 65)
          e++, k /= 2;
        *UART_BAUD_REG = (*UART_BAUD_REG & 0xf800) | (e << 8) | (65 - k);

        k = s / (k << e);
        StrIToA(xmem, k);
        WinDrawChars(xmem, StrLen(xmem), 0, 120);
      }
      break;
    case birda:
        *UART_MISC_REG = *UART_MISC_REG | UART_IRDA_ENABLE | UART_POLARITY_INVERTED;
        *UART_PORTJ_REG &= 0xffcf;
        irdaflg++;
      handled = 1;
      break;
    case brs:
        *UART_MISC_REG = *UART_MISC_REG & UART_IRDA_DISABLE & UART_POLARITY_NORMAL;
        *UART_PORTJ_REG |= 0x30;
        irdaflg = 0;
      handled = 1;
      break;
    case bsend:
      if (SerSend10(SerL, xmem, xstate / 2))
        SerClearErr(SerL);
      {
        RectangleType r =
        {0, 126, 120, 8};
        WinEraseRectangle(&r, 0);
      }
      xstate = 0;
      handled = 1;
      break;
    case bmemory:
      handled = 1;
      if (!(xstate & 1))
        break;
      {
        RectangleType r =
        {0, 126, 120, 8};
        WinEraseRectangle(&r, 0);
      }
      if (xstate == 1) {
        eid = (xmem[0] >> 4) + 1;
        if (eid > 10) {
#if 1
	  Err errx;
          Word *x;
          switch (eid) {
          case 16:
	    *UART_SC_REG &= 0xbfff;
	    *UART_MISC_REG &= 0xffdf;
            SysTaskDelay(2);
            for (i = 1; i < 5; i++) {
              SerSend(SerL, rembuf, sizeof(rembuf), &errx);
              SysTaskDelay(4);
            }
	    *UART_MISC_REG |= 0x20;
	    *UART_SC_REG |= 0x4000;
          default:
            xstate = 0;
            break;
          case 11:
            x = 0xFFFFF900UL;
            eid = *x;
            xmem[0] = eid >> 8;
            xmem[1] = eid;
            x = 0xFFFFF902UL;
            eid = *x;
            xmem[2] = eid >> 8;
            xmem[3] = eid;
            x = 0xFFFFF908UL;
            eid = *x;
            xmem[4] = eid >> 8;
            xmem[5] = eid;

            for (eid = 0; eid < 12; eid++) {
              WinDrawBitmap(hexbmp[xmem[eid / 2] >> 4], 8 * eid, 126);
              eid++;
              WinDrawBitmap(hexbmp[xmem[eid / 2] & 0x0f], 8 * eid - 1, 126);
            }
            xstate = 12;

            break;
          case 15:
	    {
	      Err errbuf;
	      for (i = 0; i < 64; i++) 
		SerSend(SerL, UUbuf, 64, &errbuf);
	      break;
	    }
          case 14:
	    {
	      Err errbuf;
	      char ibuf[64];
	      i = 5;
	      EvtGetEvent(event, 0);
	      EvtGetEvent(event, 0);
	      eid = event->eType;
	      for(;;) {
		SerSend(SerL, UUbuf, 64, &errbuf);
		SerReceive(SerL, ibuf, 64, 0, &errbuf);
		EvtGetEvent(event, 0);
		if (event->eType != eid)
		  break;
	      }
	      StrIToH(ibuf,event->eType);
	      WinDrawChars(ibuf, StrLen(ibuf), 0, 120);
	      StrIToH(ibuf,eid);
	      WinDrawChars(ibuf, StrLen(ibuf), 60, 120);
	      break;
	    }
          case 12:
            {
              unsigned long k, s, b;
              unsigned int e = 0;

              s = (32768 / 16) * (14 * (1 + (*PLL_REG & 0xff)) + ((*PLL_REG >> 8) & 0x0f) + 1);
              e = (*UART_BAUD_REG >> 8) & 7;
              k = 65 - (*UART_BAUD_REG & 63);
              b = s / (k << e);

              xmem[2] = (b % 10);
              b /= 10;
              xmem[2] |= (b % 10) << 4;
              b /= 10;
              xmem[1] = (b % 10);
              b /= 10;
              xmem[1] |= (b % 10) << 4;
              b /= 10;
              xmem[0] = (b % 10);
              b /= 10;
              xmem[0] |= (b % 10) << 4;
              b /= 10;


              for (eid = 0; eid < 6; eid++) {
                WinDrawBitmap(hexbmp[xmem[eid / 2] >> 4], 8 * eid, 126);
                eid++;
                WinDrawBitmap(hexbmp[xmem[eid / 2] & 0x0f], 8 * eid - 1, 126);
              }
              xstate = 6;
            }
            break;
          }
#endif
          break;
        }
        eid *= 16;
        xstate = prefs[eid++];
        MemMove(xmem, &prefs[eid], xstate);
        xstate *= 2;
        for (eid = 0; eid < xstate; eid++) {
          WinDrawBitmap(hexbmp[xmem[eid / 2] >> 4], 8 * eid, 126);
          eid++;
          WinDrawBitmap(hexbmp[xmem[eid / 2] & 0x0f], 8 * eid - 1, 126);
        }
      } else {
        eid = (xmem[xstate / 2] >> 4) + 1;
        if (eid > 10)
          break;
        eid *= 16;
        xstate /= 2;
        prefs[eid++] = xstate;
        for (i = 0; i < xstate; i++)
          prefs[eid++] = xmem[i];
        xstate = 0;
      }
      break;

    case 1100:
    case 1101:
    case 1102:
    case 1103:
    case 1104:
    case 1105:
    case 1106:
    case 1107:
    case 1108:
    case 1109:
    case 1110:
    case 1111:
    case 1112:
    case 1113:
    case 1114:
    case 1115:
      eid -= 1100;
      handled = 1;
      if (xstate >= 15)
        break;
      if (xstate & 1)
        xmem[xstate / 2] |= eid;
      else
        xmem[xstate / 2] = eid << 4;
      WinDrawBitmap(hexbmp[eid], 8 * xstate - (xstate & 1), 126);
      xstate++;
      break;
    case bbackup:
      handled = 1;
      if (!xstate)
        break;
      xstate--;
      if (xstate & 1)
        xmem[xstate / 2] &= 0xf0;
      WinDrawBitmap(hexbmp[16], 8 * xstate - (xstate & 1), 126);
      break;
    }
    break;
  case keyDownEvent:
    eid = event->data.keyDown.chr;
    if( eid ) {
      xstate &= 0xfe;
      xmem[xstate / 2] = eid;
      WinDrawBitmap(hexbmp[eid>>4], 8 * xstate, 126);
      WinDrawBitmap(hexbmp[eid&0x0f], 7 + 8 * xstate, 126);
      xstate += 2;
      handled = 1;
    }
    break;
  case menuEvent:
    switch (event->data.menu.itemID) {
    case mnext:
      MenuEraseStatus(MenuGetActiveMenu());
      break;
    case mabout:
      FrmAlert(aabout);
      break;
    }
    handled = 1;
    break;
  case nilEvent:
    handled = 1;
    break;
  }
  if (!handled) {
    handled = FrmHandleEvent(form, event);
    if (event->screenY < 160)
      handled = 1;
  }
  return handled;
}

static void EventLoop(void)
{
  short err;
  int formID;
  FormPtr form;
  EventType event;

  xstate = 0;
  do {
    EvtGetEvent(&event, 0);
    Dispsertn();
    if (event.eType == nilEvent)
      continue;

    EvtResetAutoOffTimer();

    if (SysHandleEvent(&event))
      continue;
    if (MenuHandleEvent((void *) 0, &event, &err))
      continue;

    if (event.eType == frmLoadEvent) {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) {
      case fserttest:
        FrmSetEventHandler(form, (FormEventHandlerPtr) handleit);
        break;
      }
    }
    FrmDispatchEvent(&event);
  } while (event.eType != appStopEvent);

}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  int error;

  if (cmd == sysAppLaunchCmdNormalLaunch) {
    if ((error = StartApplication()))
      return error;
    EventLoop();
    StopApplication();
  }
  return 0;
}
