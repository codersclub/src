#include <stdio.h>

main()
{
  unsigned int w, h, r, a1, a2, a3, a4, a5;
  unsigned char row[256], o;
  int i, j;

  gets(row);
  sscanf(row,"%d %d %d %d %d %d %d %d", &w, &h, &r, &a1, &a2, &a3, &a4, &a5);

  putchar(w >> 8);
  putchar(w);
  putchar(h >> 8);
  putchar(h);
  putchar(r >> 8);
  putchar(r);
  putchar(a1 >> 8);
  putchar(a1);
  putchar(a2 >> 8);
  putchar(a2);
  putchar(a3 >> 8);
  putchar(a3);
  putchar(a4 >> 8);
  putchar(a4);
  putchar(a5 >> 8);
  putchar(a5);

  while (h--) {
    memset(row,0,w);
    gets(row);
    for (i = 0; i < r; i++) {
      for (o = 0, j = 7; j >= 0; j--)
        o |= (row[i * 8 + 7 - j] & 1) << j;
      putchar(o);
    }
  }

}
