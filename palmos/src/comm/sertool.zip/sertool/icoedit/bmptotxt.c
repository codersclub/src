#include <stdio.h>

main()
{
  short unsigned int w, h, r, a1, a2, a3, a4, a5;
  unsigned char row[256], o;
  int i, j;

  w = getchar() << 8;
  w |= getchar() & 0xff;
  h = getchar() << 8;
  h |= getchar() & 0xff;
  r = getchar() << 8;
  r |= getchar() & 0xff;
  a1 = getchar() << 8;
  a1 |= getchar() & 0xff;
  a2 = getchar() << 8;
  a2 |= getchar() & 0xff;
  a3 = getchar() << 8;
  a3 |= getchar() & 0xff;
  a4 = getchar() << 8;
  a4 |= getchar() & 0xff;
  a5 = getchar() << 8;
  a5 |= getchar() & 0xff;

  printf("%d %d %d %d %d %d %d %d\n", w, h, r, a1, a2, a3, a4, a5);

  while (h-- && !feof(stdin)) {
    for (i = 0; i < r; i++) {
      o = getchar();
      if (feof(stdin))
        break;
      for (j = 7; j >= 0; j--)
        putchar((1 & (o >> j)) ? '#' : '.');
    }
    putchar('\n');
  }

}
