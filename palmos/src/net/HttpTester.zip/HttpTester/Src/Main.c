/***********************************************************************
 *
 * H T T P T E S T E R
 *
 * Version: $Id: Main.c,v 1.3 2002/04/09 20:45:11 koenig Exp $
 *
 **********************************************************************/
#define ALLOW_ACCESS_TO_INTERNALS_OF_FIELDS

#include <PalmOS.h>
#include "HttpTester_res.h"
#include <sys_socket.h>


/***********************************************************************
 *
 *   Entry Points
 *
 ***********************************************************************/


/***********************************************************************
 *
 *   Internal Structures
 *
 ***********************************************************************/
typedef struct 
	{
	UInt8 replaceme;
	} StarterPreferenceType;

typedef struct 
	{
	UInt8 replaceme;
	} StarterAppInfoType;

typedef StarterAppInfoType* StarterAppInfoPtr;


/***********************************************************************
 *
 *   Global variables
 *
 ***********************************************************************/
//static Boolean HideSecretRecords;
Err			errno;


/***********************************************************************
 *
 *   Internal Constants
 *
 ***********************************************************************/
#define appFileCreator			'HTst'
#define appVersionNum			0x01
#define appPrefID				0x00
#define appPrefVersionNum		0x01


// Define the minimum OS version we support
#define ourMinVersion	sysMakeROMVersion(2,0,0,sysROMStageRelease,0)


/***********************************************************************
 *
 *   Internal Functions
 *
 ***********************************************************************/


/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version is meet your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *
 * REVISION HISTORY:
 *
 ***********************************************************************/
static Err RomVersionCompatible(UInt32 requiredVersion, UInt16 launchFlags)
{
	UInt32 romVersion;

	// See if we're on in minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
		{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion < sysMakeROMVersion(2,0,0,sysROMStageRelease,0))
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
		return (sysErrRomIncompatible);
		}

	return (0);
}


/***********************************************************************
 *
 * FUNCTION:    GetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  formId - id of the form to display
 *
 * RETURNED:    MemPtr
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static MemPtr GetObjectPtr(UInt16 objectID)
	{
	FormPtr frmP;


	frmP = FrmGetActiveForm();
	return (FrmGetObjectPtr(frmP, FrmGetObjectIndex(frmP, objectID)));
}


//=======================================================================
// GetFieldText
//
// return a pointer to the text
// 
//=======================================================================

static Char * GetFieldText(FormPtr formP, UInt16 FieldID)
{
	FieldPtr	addrFieldP;	

	
	addrFieldP = (FieldPtr) FrmGetObjectPtr( formP, FrmGetObjectIndex( formP, FieldID ) );
	return (FldGetTextPtr( addrFieldP ));
}


//=======================================================================
// SetFieldTextFromStr
//
// given a formPtr and fieldID, set the text of the field from the string
// on strP (a copy is made). the active form is used if formP is NULL. works
// even if the field is not editable.
//
// return a pointer to the field.
// 
//=======================================================================

FieldPtr SetFieldTextFromStr( FormPtr formP, UInt16 fieldID, char* strP )
{
	MemHandle	oldTxtH;
	MemHandle	txtH;
	char*		txtP;

	FieldPtr	fldP=NULL;
	Boolean		fieldWasEditable;
	

	// get some space in which to stash the string.
		
	txtH	= MemHandleNew(  StrLen( strP ) + 1 );
	txtP	= MemHandleLock( txtH );


	// copy the string.
		
	StrCopy( txtP, strP );


	// unlock the string handle.
		
	MemHandleUnlock( txtH );
	txtP = 0;


	// get the field and the field's current text handle.
	
	fldP	= GetObjectPtr( fieldID );	
	oldTxtH	= FldGetTextHandle( fldP );
	
	
	// set the field's text to the new text.
	
	fieldWasEditable		= fldP->attr.editable;
	fldP->attr.editable	= true;
	
	FldSetTextHandle( fldP, txtH );
	FldDrawField( fldP );
	
	fldP->attr.editable	= fieldWasEditable;


	// free the handle AFTER we call FldSetTextHandle().
	
	if ( oldTxtH != NULL ) MemHandleFree( oldTxtH );
	
	return fldP;

}	// SetFieldTextFromStr



#pragma mark -
/***********************************************************************
 *
 * FUNCTION:    AboutFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AboutFormHandleEvent(EventPtr eventP)
{
    Boolean handled = false;
    FormPtr frmP;


	switch (eventP->eType) 
		{
		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			FrmDrawForm( frmP );
			handled = true;
			break;
			
		case ctlSelectEvent:
			switch (eventP->data.ctlSelect.controlID)
				{
				case AboutOKButton:
					FrmReturnToForm( MainForm );
					FrmUpdateForm( MainForm, frmRedrawUpdateCode );
					handled = true;
					break;
				}
		default:
			break;
		}

	return (handled);
}


#pragma mark -
/***********************************************************************
 *
 * FUNCTION:    MainFormInit
 *
 * DESCRIPTION: This routine initializes the MainForm form.
 *
 * PARAMETERS:  frm - pointer to the MainForm form.
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void MainFormInit(FormPtr frmP)
{
}


/***********************************************************************
 *
 * FUNCTION:    MainFormDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormDoCommand(UInt16 command)
{
	Boolean handled = false;


	switch (command)
		{
		case MainOptionsAboutHttpTester:
			MenuEraseStatus (0);
			FrmPopupForm( AboutForm );
			handled = true;
			break;

		}
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainFormHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "MainForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean MainFormHandleEvent(EventPtr eventP)
{
    Boolean handled = false;
    FormPtr frmP;

  	int  ret, lg;
  	char typeBuf[70], tmpBuf[100];
  	char theURL[100];

  	char *data=NULL, *filename=NULL;
	frmP = FrmGetActiveForm();

	switch (eventP->eType) 
		{
		case menuEvent:
			return MainFormDoCommand(eventP->data.menu.itemID);
			break;
			
		case ctlSelectEvent:
			switch(eventP->data.ctlSelect.controlID) {
				case MainGetButton:			
					StrCopy(theURL, GetFieldText(frmP, MainURLField));
					StrCopy(tmpBuf, theURL);

		  			ret=http_parse_url(theURL,&filename);
		      		ret=http_head(filename, &lg, typeBuf);

					SetFieldTextFromStr(frmP, MainURLField,  tmpBuf);
					SetFieldTextFromStr(frmP, MainTypeField, typeBuf);
					sprintf(tmpBuf, "%d", lg);
					SetFieldTextFromStr(frmP, MainLengthField, tmpBuf);
					break;
				case MainHeadButton:
//					StrCopy(theURL, "http://www.chronologic.se/frog.html");
					StrCopy(theURL, GetFieldText(frmP, MainURLField));
					StrCopy(tmpBuf, theURL);

		  			ret=http_parse_url(theURL,&filename);
		      		ret=http_head(filename, &lg, typeBuf);

					SetFieldTextFromStr(frmP, MainURLField,  tmpBuf);
					SetFieldTextFromStr(frmP, MainTypeField, typeBuf);
					sprintf(tmpBuf, "%d", lg);
					SetFieldTextFromStr(frmP, MainLengthField, tmpBuf);
					break;
				default:
					break;
			}


      		FrmUpdateForm(0, 0);
      		handled = true;
			break;


		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			MainFormInit( frmP);
			FrmDrawForm ( frmP);

			// initialise the URL field with some data
			StrCopy(tmpBuf, "http://www.chronologic.se/Palm/index.html");
			SetFieldTextFromStr(frmP, MainURLField,  tmpBuf);
	
			handled = true;
			break;

		case frmUpdateEvent:
			frmP = FrmGetActiveForm();
			FrmDrawForm ( frmP);
			handled = true;
			break;

		default:
			break;
		
		}
	
	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean AppHandleEvent( EventPtr eventP)
{
	UInt16 formId;
	FormPtr frmP;


	if (eventP->eType == frmLoadEvent)
		{
		// Load the form resource.
		formId = eventP->data.frmLoad.formID;
		frmP = FrmInitForm(formId);
		FrmSetActiveForm(frmP);

		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formId)
			{
			case MainForm:
				FrmSetEventHandler(frmP, MainFormHandleEvent);
				break;

			case AboutForm:
				FrmSetEventHandler(frmP, AboutFormHandleEvent);
				break;

			default:
//				ErrFatalDisplay("Invalid Form Load Event");
				break;

			}
		return true;
		}
	
	return false;
}


/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: This routine is the event loop for the application.  
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	UInt16 error;
	EventType event;


	do {
		EvtGetEvent(&event, evtWaitForever);
		
		
		if (! SysHandleEvent(&event))
			if (! MenuHandleEvent(0, &event, &error))
				if (! AppHandleEvent(&event))
					FrmDispatchEvent(&event);

	} while (event.eType != appStopEvent);
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  Get the current application's preferences.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     Err value 0 if nothing went wrong
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Err AppStart(void)
{
	Err						err;
    StarterPreferenceType prefs;
    UInt16 prefsSize;


	// Get the refNum of the Net Library
	err = SysLibFind("Net.lib", &AppNetRefnum);
	if (err) {
		ErrDisplay("\nNet Library not found, exiting...");
		return err;
		}


	// Read the saved preferences / saved-state information.
	prefsSize = sizeof(StarterPreferenceType);
	if (PrefGetAppPreferences(appFileCreator, appPrefID, &prefs, &prefsSize, true) != 
		noPreferenceFound)
		{
		}
	
   return 0;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: Save the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static void AppStop(void)
{
   StarterPreferenceType prefs;
   
   
	// Write the saved preferences / saved-state information.  This data 
	// will be backed up during a HotSync.
	PrefSetAppPreferences (appFileCreator, appPrefID, appPrefVersionNum, 
		&prefs, sizeof (prefs), true);
}



/***********************************************************************
 *
 * FUNCTION:    StarterPilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 * PARAMETERS:  cmd - UInt16 value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  UInt16 value providing extra information about the launch.
 *
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static UInt32 StarterPilotMain(UInt16 cmd, void * cmdPBP, UInt16 launchFlags)
{
	Err error;


	error = RomVersionCompatible (ourMinVersion, launchFlags);
	if (error) return (error);


	switch (cmd)
		{
		case sysAppLaunchCmdNormalLaunch:
			error = AppStart();
			if (error) 
				return error;
				
			FrmGotoForm(MainForm);
			AppEventLoop();
			AppStop();
			break;

		default:
			break;

		}
	
	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the application.
 *
 * PARAMETERS:  cmd - UInt16 value specifying the launch code. 
 *              cmdPB - pointer to a structure that is associated with the launch code. 
 *              launchFlags -  UInt16 value providing extra information about the launch.
 * RETURNED:    Result of launch
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
UInt32 PilotMain( UInt16 cmd, void *cmdPBP, UInt16 launchFlags)
{
    return StarterPilotMain(cmd, cmdPBP, launchFlags);
}

