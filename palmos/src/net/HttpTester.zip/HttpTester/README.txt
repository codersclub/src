HttpTester
==========


- Intro

This is an implementation of a small http library made available under the artistic
license by Laurent Demailly, Observatoire de Paris - Meudon - France. See
http://www.demailly.com/~dl/ for further details.

The program is a front end to one of the functions provided by the library; the GET
function. HEAD, PUT and DELETE are also available in the program but no UI has been
made for these.

The user inputs the full URL to any web resource and the contents type and size of
the resource are displayed in fields on the form. In addition to this is the actual data
retrieved in an internal structure but nothing further is done to it by the program.


- Installation Instructions

If the program is run in POSE must the "Redirect NetLib calls to host TCP/IP" options be checked.


- Building instructions

The source code included is for Metrowerk's CodeWarrior version 7. It should not be too difficult to adapt it to GCC/PrcTools, but that is left as an excercise for the reader.

The project file is included in exported format -- use File->Import Project... to read the enclosed XML file and convert it to a project file.


- Licensing

This program and source code is put under the Artistic License. See License.txt for details.


- Developer contact information

Karl-Koenig Koenigsson
Chronologic Sweden AB
koenig@chronologic.se

---------------------------------------
$Id: README.txt,v 1.3 2002/04/09 20:37:36 koenig Exp $