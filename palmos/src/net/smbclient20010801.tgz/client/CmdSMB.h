
#ifndef _CMDSMB_H
#define _CMDSMB_H

#include "includes.h"

Int16 CmdConnect(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdHostQuery(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdMessage(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdDebug(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdUser(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdWorkgroup(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdPwd(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdDir(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdCd(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;
Int16 CmdGet(UInt16 argc, const Char * argv[]) SECTION_CMDSMB;

BOOL CmdSMBInit(void) SECTION_CMDSMB;
void CmdSMBClose(void) SECTION_CMDSMB;

#endif
