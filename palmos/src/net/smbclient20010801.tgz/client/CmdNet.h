
#ifndef _CMDNET_H
#define _CMDNET_H

#include "config.h"


Int16 CmdClose(UInt16 argc, const Char * argv[]) SECTION_CMDNET;
Int16 CmdTimeout(UInt16 argc, const Char * argv[]) SECTION_CMDNET;
Int16 CmdOpen(UInt16 argc, const Char * argv[]) SECTION_CMDNET;

BOOL CmdNetInit(void) SECTION_CMDNET;
void CmdNetClose(void) SECTION_CMDNET;

#endif
