//**************************************************************
//
//  Project:
//	  Handspring simple serial terminal application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  HandTerminalRsc.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
//
// History:
//	  26-Feb-1999  RM  Created 
//***************************************************************/


// Main Form
#define resFormIDMain				1000
#define	resMainTextFldID			1002
#define	resMainScrollerID			1003
									

// Main Form menu
#define resMenuIDMain				1000
#define resMenuItemComm				1001
#define resMenuItemStatus			1002
#define resMenuItemAbout			1003

// About Alert
#define resAlertIDAbout				1000
