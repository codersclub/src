/******************************************************************************
 *
 * Copyright (c) 1994-1999 Palm, Inc. or its subsidiaries.
 * All rights reserved.
 *
 * File: CmdNet.c
 *
 * Release: SMBclient for PalmOS
 *
 * Description:
 * This module provides various commands to open, close, and change the
 *	timeout value used by the Berkeley sockets API macros of the Net Library.
 *
 *****************************************************************************/

// Include the PalmOS headers
#include <PalmOS.h>

// StdIO header
#include "AppStdIO.h"

// Socket Equates
#include <sys_socket.h>

// Application headers
#include "CmdNet.h"



static BOOL netLibOpen = false;


/***********************************************************************
 *
 * FUNCTION:   CmdTimeout
 *
 * DESCRIPTION:Setup Timeout for all subsequent Net commands
 *
 *	CALLED BY:	 AppExecCommand  
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
Int16 CmdTimeout(UInt16 argc, const Char * argv[])
{

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	
	// Get the new timeout value in seconds
	if (argc > 1) 
		AppNetTimeout = sysTicksPerSecond * atol(argv[1]);
	printf("Timeout set to %ld seconds\n", AppNetTimeout/sysTicksPerSecond);
	return;
	
ShortHelp:
	printf("%s\t\t# Get/Set AppNetTimeout\n", argv[0]);
	return;
	
FullHelp:
	printf("\nGet/Set timeout (in seconds) for NetLib commands");
	printf("\nSyntax: %s [<seconds>]", argv[0]);
	printf("\n");
}

/***********************************************************************
 *
 * FUNCTION:   CmdOpen()
 *
 * DESCRIPTION: Test NetLibOpen
 *
 *	CALLED BY:	AppProcessCommand in response to the "open" command
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
Int16 CmdOpen(UInt16 argc, const Char * argv[])
{
	UInt16		ifErrs;
	Err			err;
	UInt32		ifCreator;
	UInt16		ifInstance;
	
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	
	// check already open
	if (netLibOpen) {
		printf("NetLib already open...\n");
		return;
	}

	// If there are no interfaces attached, print error message
	err = NetLibIFGet(AppNetRefnum, 0, &ifCreator, &ifInstance);
	if (err) {
		Sioputs(	"\n##Error: No internet service setup.\n\n");
		return;
		}

	printf("Opening Connection... ");
	err = NetLibOpen(AppNetRefnum, &ifErrs);

	if (err == netErrAlreadyOpen)  {
		printf("\nNote: NetLib was open, open count incremented");
		err = 0;
	}
	if (err) {
		printf("\nOpen Error: %s\n", strerror(err));
		return;
	}
	if (!err) {
		netLibOpen = true;
		printf("done.");
	}

	//-------------------------------------------------------------------
	// If there were errors bringup any interfaces, see which ones
	//-------------------------------------------------------------------
	if (ifErrs) {
		UInt16		index;
		UInt8		up;
		UInt16		settingSize;
		Char		ifName[32];
		
		printf("\nInterface Error: %s", strerror(ifErrs));
		if (ifErrs == netErrPrefNotFound) {
			printf("\nThis most likely means that your internet setup is incomplete.");
			printf("\nSwitch to the Network preference panel and check your setup.");
			}
		for (index = 0; 1; index++) {
			err = NetLibIFGet(AppNetRefnum, index, &ifCreator, &ifInstance);
			if (err) break;

			settingSize = sizeof(up);
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance,
				netIFSettingUp, &up, &settingSize);
			if (err || up) continue;
			
			settingSize = 32;
			err = NetLibIFSettingGet(AppNetRefnum, ifCreator, ifInstance,
				netIFSettingName, ifName, &settingSize);
			if (err) continue;
			
			printf("\nInterface %s did not come up.", ifName);
			}

			
		// Close the NetLib if any interfaces failed to come up.
		CmdClose(0, NULL);
		}


	printf("\n");
	return;
	
ShortHelp:
	printf("%s\t\t# Open NetLib\n", argv[0]);
	return;
	
FullHelp:
	printf("\nOpen NetLib");
	printf("\nSyntax: %s ", argv[0]);
	printf("\n");

}


/***********************************************************************
 *
 * FUNCTION:   CmdClose()
 *
 * DESCRIPTION: Test NetLibClose
 *
 *	CALLED BY:	AppProcessCommand in response to the "close" command
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
Int16 CmdClose(UInt16 argc, const Char * argv[]) {
	Err		err;
	
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	
	// check not open
	if (!netLibOpen) {
		printf("NetLib was not open.\n");
		return;
	}

	printf("\nClosing NetLib... ");
	err = NetLibClose(AppNetRefnum, false);
	if (err) {
		printf("\nError closing: %s", strerror(err));
	}
	else {
		netLibOpen = false;
		printf("done.");
	}

	printf("\n");
	return;
	
ShortHelp:
	printf("%s\t\t# Close NetLib\n", argv[0]);
	return;
	
FullHelp:
	printf("\nClose NetLib");
	printf("\nSyntax: %s ", argv[0]);
	printf("\n");

}

/***********************************************************************
 *
 * FUNCTION:   	CmdSetupInstall
 *
 * DESCRIPTION: 	Installs the commands from this module into the
 *		master command table used by AppProcessCommand.
 *
 *	CALLED BY:		AppStart 
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
BOOL CmdNetInit(void)
{
	UInt16		ifErrs;
	Err			err;
	Int32		ifCreator;
	UInt16		ifInstance;

	// Get the refNum of the Net Library
	err = SysLibFind("Net.lib", &AppNetRefnum);
	if (err) {
		ErrDisplay("\nNet Library not found, exiting...");
		return false;
	}

	// If there are no interfaces attached, print error message
	err = NetLibIFGet(AppNetRefnum, 0, &ifCreator, &ifInstance);
	if (err) {
		Sioputs(	"\n##Error: No network service setup.\n\n");
		return false;
	}

	SioAddCommand("timeout", CmdTimeout);
	SioAddCommand("open", CmdOpen);
	SioAddCommand("close", CmdClose);
}


void CmdNetClose(void) {
	CmdClose(0, NULL);
}