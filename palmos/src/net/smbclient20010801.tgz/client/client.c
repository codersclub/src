/***************************************************************
 *
 *  Project:
 *	  SMB client for PalmOS
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  client.c
 * 
 *  Description:
 *		An attempt to port smbclient from the Samba suite to PalmOS
 *
 * ToDo:
 *	  
 *
 * History:
 *	  200106	Created by Olivier GERARDIN
 ****************************************************************/

#include <PalmOS.h>
//#include <StdIOPalm.h>
#include "AppStdio.h"

#include "includes.h"


#include "CmdNet.h"
#include "CmdSMB.h"

#include "clientRsc.h"
#include "build.h"


// command table
typedef struct {
	Char *				nameP;							// command name
	SioMainProcPtr			procP;							// procedure
} CmdTableEntryType;

#define					kMaxCommands 	64				// Max # of commands
UInt16					NumCommands = 0;
CmdTableEntryType		CmdTable[kMaxCommands];		// command table


//
// static declarations for section assignment
//
static void MainFrmInit (FormPtr frmP) SECTION_CLIENT;
static Boolean MainFrmDoCommand (UInt16 command) SECTION_CLIENT;
static Boolean MainFrmEventHandler (EventPtr eventP) SECTION_CLIENT;
static void AppExecCommand(char* cmdParamP) SECTION_CLIENT;
static UInt32 AppStart(void) SECTION_CLIENT;
static void AppStop (void) SECTION_CLIENT;
static Boolean AppHandleEvent (EventPtr eventP) SECTION_CLIENT;
static void AppProcessEvent(EventPtr e) SECTION_CLIENT;
static void AppEventLoop(void) SECTION_CLIENT;





/***************************************************************
 * @return The creator ID of this app
 ***************************************************************/
/*
UInt32 GetCreatorID(void)
{
    static UInt32 nCreatorID = 0;

    if (nCreatorID == 0) {
        UInt16 nCard;
        LocalID LocalDB;

        ErrFatalDisplayIf(SysCurAppDatabase(&nCard, &LocalDB),
                "Could not get current app database.");
        ErrFatalDisplayIf(DmDatabaseInfo(nCard, LocalDB, 0, 0, 0, 0,
                0, 0, 0, 0, 0, 0, &nCreatorID),
                "Could not get app database info, looking for creator ID");
    }

    return nCreatorID;
}
*/


/***************************************************************
 * Initialize the main form
 ****************************************************************/
static void MainFrmInit (FormPtr frmP) {
}


/***************************************************************
 * Execute a command from the main form
 * @param command the command to execute
 * @return true if the command was handled, false otherwise
 ****************************************************************/
static Boolean MainFrmDoCommand (UInt16 command) {
  Boolean	handled = true;
   
  switch (command) {
		  
	//...........................................................
	// Misc Menu
	//...........................................................
	case resMenuItemAbout:
	  FrmAlert (resAlertIDAbout);
	  break;
		
	case resMenuItemStatus:
	  printf ("\nStatus: ?\n");
	  break;
		
	default:
	  // allow edit events to be handled by frmhandleevent
	  handled = false;
	  break;
	}	

  return handled;
}



/***************************************************************
 * Handle an event in the main form.
 * @param eventP the event
 * @return true if the event was handled, false otherwise
 ****************************************************************/
static Boolean MainFrmEventHandler (EventPtr eventP) {
  FormPtr   formP;
  Boolean   handled = false;

  // See if StdIO can handle it
  if (SioHandleEvent (eventP)) {
	  return true;
  }

  switch (eventP->eType) {
	// Init the form
	case frmOpenEvent:
	  formP = FrmGetActiveForm ();
	  MainFrmInit (formP);
	  FrmDrawForm (formP);
	  printf("\nSMBClient version %s, build %d\n", VERSION, BUILD);
	  SioPrompt();
	  handled = true;
	  break;
    
	// Menu commands
	case menuEvent:
	  handled =  MainFrmDoCommand (eventP->data.menu.itemID);
	  break;

	//
	case nilEvent:
	  break;

	// Close our form
	case frmCloseEvent:
	  break;

	}
  return handled;
}


/***********************************************************************
 * Add a command to the command table.
 * @param cmdStr the command name
 * @param procP a pointer to the associated procedure
 ***********************************************************************/
void SioAddCommand(const Char * cmdStr, SioMainProcPtr procP) {
	if (NumCommands >= kMaxCommands-1) {
		ErrDisplay("Too many commands");
		return;
	}
	CmdTable[NumCommands].nameP = cmdStr;
	CmdTable[NumCommands++].procP = procP;
}


/***************************************************************
 * Execute a user-typed command. Separates a command line into 
 *	argc, argv components and then calls the appropriate routine.
 * @param  cmdParamP pointer to command line
 ****************************************************************/
static void AppExecCommand(char* cmdParamP) {
  Err	err;

	const int	maxArgc=10;
	Char *		argv[maxArgc+1];
	UInt16			argc;
	Boolean		done = false;
	UInt16			i;
	Char *		cmdBufP = 0;
	Char *		cmdP;

	// if null string, return
	if (!cmdParamP[0]) {
		SioPrompt();
		return;
	}

	// Make a copy of the command since we'll need to write
	// 0's between the words and it might be from read-only space
	cmdP = cmdBufP = MemPtrNew(StrLen(cmdParamP) + 1);
	if (!cmdP) {
		printf("\nOut of memory\n");
		goto Exit;
		}
	MemMove(cmdP, cmdParamP, StrLen(cmdParamP) + 1);

	// Separate the cmd line into arguments
	argc = 0;
	argv[0] = 0;
	for (argc=0; !done && argc<=maxArgc; argc++) {
	
		// Skip leading spaces
		while((*cmdP == ' ' || *cmdP == '\t') && (*cmdP != 0))
			cmdP++;
			
		// Break out on null
		if (*cmdP == 0) break;
		
		// Get pointer to command
		argv[argc] = cmdP;
		if (*cmdP == 0) break;
		
		// Find the end of a quoted argument
		if (*cmdP == '"') {
			cmdP++;
			argv[argc] = cmdP;
			while(*cmdP) {
				if (*cmdP == '"') {*cmdP = 0; break;}
				if (*cmdP == 0) {done = true; break;}
				cmdP++;
				}
			cmdP++;
			}
			
		// Find the end of an unquoted argument
		else {
			while(1) {
				if (*cmdP == 0) {done = true; break;}
				if ((*cmdP == ' ') || (*cmdP == '\t')) {
					*cmdP = 0; 
					break;
					}
				cmdP++;
				}
			cmdP++;
			}
		}
	
	// Return if no arguments
	if (!argc) goto Exit;
		
	//--------------------------------------------------------------------
	// Call the appropriate routine
	//--------------------------------------------------------------------
	
	// Look for the help command
	if (!StrCompare(argv[0], "help") || !StrCompare(argv[0], "?")) {
	
		// If asking about a particular command, get extended help (??)
		if (argc > 1) {
			argv[0] = argv[1];
			argv[1] = "??";
			}
			
		// Else, display 1 line help (?)
		else {
			Char *	helpP;
			helpP = "?";
			for (i=0; i<NumCommands; i++) {
				argv[0] = CmdTable[i].nameP;
				argv[1] = helpP;
				(CmdTable[i].procP)(2, (const Char**) argv);
				
				// Pause after every "page"
				if (i > 0 && (i % 8) == 0) {
					printf("<cr> to continue...");
					if (getchar() != '\n') break;
					printf("\n");
					}
				}
			printf("\n");
			goto Exit;
			}
		}
		
	// Else, look for this command
	for (i=0; i<NumCommands; i++) {
		if (!StrCompare(argv[0], CmdTable[i].nameP)) {
			(CmdTable[i].procP)(argc, (const Char**) argv);
			goto Exit;
			}
		}
	
	// Not found
	printf("Unknown command: %s\n", argv[0]);
	
Exit:
	if (cmdBufP) MemPtrFree(cmdBufP);
	cmdP = 0;
	cmdBufP = 0;

	SioPrompt();
}



/***************************************************************
 *	Application initialization when being launched
 *		as a normal application (i.e. not to execute an action code).
 ****************************************************************/
static UInt32 AppStart(void) {

	// Init our terminal functions for printing to the screen
	SioInit (resFormIDMain, resMainTextFldID, resMainScrollerID, AppExecCommand);
	//SioInit (resFormIDMain, resMainTextFldID, resMainScrollerID);

	//init modules
	CmdNetInit();
	CmdSMBInit();

	FrmGotoForm (resFormIDMain);
	return 0;
}


/***************************************************************
 * Application cleanup. This routine cleans up
 *	  all initialization performed by AppStart(). 
 ****************************************************************/
static void AppStop (void)
{
	EventType	event;
	Err	err;

	// Close the modules
	CmdSMBClose();
	CmdNetClose();

	// Close our main form
	event.eType = frmCloseEvent;
	event.data.frmClose.formID = resFormIDMain;
	FrmDispatchEvent (&event);

	// Free the Stdio Support
	SioFree ();
}



/***************************************************************
 * This routine loads form resources and set the event
 *              handler for the form loaded.
 * @param eventP pointer to event
 ****************************************************************/
static Boolean AppHandleEvent (EventPtr eventP)
{
  UInt16 formID;
  FormPtr frmP;

  Boolean handled = false;

  if (eventP->eType == frmLoadEvent) {
	  // Load the form resource.
	  formID = eventP->data.frmLoad.formID;
	  frmP = FrmInitForm (formID);
	  FrmSetActiveForm (frmP);		
	  // Set the event handler for the form.  The handler of the currently
	  // active form is called by FrmHandleEvent each time is receives an
	  // event.
		switch (formID) {
		  case resFormIDMain:
			  FrmSetEventHandler (frmP, MainFrmEventHandler);
			  break;
		}
		handled = true;
	}
  return handled;
}



/***************************************************************
 * Process one event from the main event loop
 * @param e the event to process
 ***************************************************************/
static void AppProcessEvent(EventPtr e)
{
	UInt16 error;

	if (SysHandleEvent(e)) {
		return;
	}
	if (MenuHandleEvent(NULL, e, &error)) {
		return;
	}
	if (AppHandleEvent(e)) {
		return;
	}
	FrmDispatchEvent(e);
}



/***************************************************************
 * Main event loop for the application
 ****************************************************************/
static void AppEventLoop(void)
{
	EventType event;

	do {
		//EvtGetEvent (&event, sysTicksPerSecond/4);
		EvtGetEvent (&event, evtWaitForever);
		AppProcessEvent(&event);
	} while (event.eType != appStopEvent);
}


/***********************************************************************
 * This is the main entry point for the Pilot application.
 ***********************************************************************/
UInt32 PilotMain (UInt16 cmd, void* cmdPBP, UInt16 launchFlags)
{
	Err err;
	if (cmd == sysAppLaunchCmdNormalLaunch) {
		err = AppStart();			// Application start code
		if (err) {
			return err;
		}
		AppEventLoop();				// Event loop
		AppStop ();					// Application stop code
	}
	return 0;
}

