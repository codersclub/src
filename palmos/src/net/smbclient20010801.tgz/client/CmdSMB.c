/******************************************************************************
 *
 * Copyright (c) 2001 Olivier GERARDIN
 * All rights reserved.
 *
 * SMB Client for PalmOS
 *
 * This module provides various commands to connect to a SMB server. It is
 * roughly the equivalent of the client/client.c from the original samba 
 * distribution.
 *****************************************************************************/

// StdIO header
#include "AppStdIO.h"

// Include the PalmOS headers
#include <PalmOS.h>

// Application headers
#include "CmdSMB.h"


//
// Globals
//
int DEBUGLEVEL = 0;

static struct cli_state *cli = NULL;
static pstring desthost;
static pstring cur_dir = "\\";
static uint32 dir_total;

extern pstring global_myname;

static int name_type = 0x20;

static int max_protocol = PROTOCOL_NT1;

static BOOL have_ip;
struct in_addr dest_ip;

static int port = SMB_PORT;
static size_t io_bufsize = 64512L;

static BOOL got_pass;
static pstring password;

static pstring username;
static pstring workgroup;
static pstring service;


//
// declaration of static functions just to put them in the right section
//
static void display_finfo(file_info *finfo, const char* mask) SECTION_CMDSMB;
static void browse_fn(const char *name, uint32 m, const char *comment) SECTION_CMDSMB;
static BOOL browse_host(BOOL sort) SECTION_CMDSMB;
static void server_fn(const char *name, uint32 m, const char *comment) SECTION_CMDSMB;
static BOOL list_servers(char *wk_grp) SECTION_CMDSMB;
static void do_get(char *rname) SECTION_CMDSMB;


/****************************************************************************
  get a file from rname to lname
  ****************************************************************************/
static void do_get(char *rname)
{  
	//int handle=0;
	int fnum;
	//BOOL newhandle = False;
	char *data;
	//struct timeval tp_start;
	size_t read_size = io_bufsize;
	uint16 attr;
	size_t size;
	off_t nread = 0;

	/*
	GetTimeOfDay(&tp_start);

	if (lowercase) {
		strlower(lname);
	}
	*/

	fnum = cli_open(cli, rname, O_RDONLY, DENY_NONE);

	if (fnum == -1) {
		DEBUG(0,("%s opening remote file %s\n",cli_errstr(cli),rname));
		return;
	}

	/*
	if(!strcmp(lname,"-")) {
		handle = fileno(stdout);
	} else {
		handle = sys_open(lname,O_WRONLY|O_CREAT|O_TRUNC,0644);
		newhandle = True;
	}
	if (handle < 0) {
		DEBUG(0,("Error opening local file %s\n",lname));
		return;
	}
	*/


	if (!cli_qfileinfo(cli, fnum, 
			   &attr, &size, NULL, NULL, NULL, NULL, NULL) &&
	    !cli_getattrE(cli, fnum, 
			  &attr, &size, NULL, NULL, NULL)) {
		DEBUG(0,("getattrib: %s\n",cli_errstr(cli)));
		return;
	}

	DEBUG(2,("getting file %s of size %lu\n", rname, size));

	if(!(data = (char *)malloc(read_size))) { 
		DEBUG(0,("malloc fail for size %lu\n", read_size));
		cli_close(cli, fnum);
		return;
	}

	while (1) {
		int i;
		int n = cli_read(cli, fnum, data, nread, read_size);

		if (n <= 0) break;
 
		/*
		if (writefile(handle,data, n) != n) {
			DEBUG(0,("Error writing local file\n"));
			break;
		}
		*/

		//OG: temporary: dump file to stdout
		for (i=0; i<n; i++) {
			SioPutChar(data[i]);
		}
      
		nread += n;
	}

	if (nread < size) {
		DEBUG (0, ("Short read when getting file %s. Only got %ld bytes.\n",
               rname, (long)nread));
	}

	free(data);
	
	if (!cli_close(cli, fnum)) {
		DEBUG(0,("Error %s closing remote file\n",cli_errstr(cli)));
	}

	/*
	if (newhandle) {
		close(handle);
	}
	*/

	/*
	if (archive_level >= 2 && (attr & aARCH)) {
		cli_setatr(cli, rname, attr & ~(uint16)aARCH, 0);
	}
	*/

	/*
	{
		struct timeval tp_end;
		int this_time;
		
		GetTimeOfDay(&tp_end);
		this_time = 
			(tp_end.tv_sec - tp_start.tv_sec)*1000 +
			(tp_end.tv_usec - tp_start.tv_usec)/1000;
		get_total_time_ms += this_time;
		get_total_size += nread;
		
		DEBUG(2,("(%3.1f kb/s) (average %3.1f kb/s)\n",
			 nread / (1.024*this_time + 1.0e-4),
			 get_total_size / (1.024*get_total_time_ms)));
	}
	*/
}


/****************************************************************************
  get a file
  ****************************************************************************/
Int16 CmdGet(UInt16 argc, const Char * argv[])
{
	static pstring rname;

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	if (argc < 2) goto FullHelp;

	if (!cli) {
		printf("Not connected!\n");
		return;
	}

	pstrcpy(rname,cur_dir);
	pstrcat(rname,"\\");
	pstrcat(rname, argv[1]);
	
	dos_clean_name(rname);
	
	do_get(rname);

	return;
	
ShortHelp:
	printf("%s\t\t# Get a file\n", argv[0]);
	return;
	
FullHelp:
	printf("\nGet a remote file");
	printf("\nSyntax: %s remote-filename", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Connect to a SMB server
 * @return a pointer to a cli_state object containing the session data
 ***********************************************************************/
struct cli_state *do_connect(char *server, char *share)
{
	struct cli_state *c;
	struct nmb_name called, calling;
	char *server_n;
	struct in_addr ip;
	extern struct in_addr ipzero;
	fstring servicename;
	char *sharename;
	
	// make a copy so we don't modify the global string 'service'
	safe_strcpy(servicename, share, sizeof(servicename)-1);
	sharename = servicename;
	if (*sharename == '\\') {
		server = sharename+2;
		sharename = strchr(server,'\\');
		if (!sharename) return NULL;
		*sharename = 0;
		sharename++;
	}

	server_n = server;
	
	ip = ipzero;

	get_myname((*global_myname)?NULL:global_myname);  

	make_nmb_name(&calling, global_myname, 0x0);
	make_nmb_name(&called , server, name_type);

 again:
	ip = ipzero;
	if (have_ip) ip = dest_ip;

	/* have to open a new connection */
	if (!(c=cli_initialise(NULL)) || (cli_set_port(c, port) == 0) ||
	    !cli_connect(c, server_n, &ip)) {
		DEBUG(0,("Connection to %s failed\n", server_n));
		return NULL;
	}

	c->protocol = max_protocol;

	if (!cli_session_request(c, &calling, &called)) {
		char *p;
		DEBUG(0,("session request to %s failed (%s)\n", 
			 called.name, cli_errstr(c)));
		cli_shutdown(c);
		free(c);
		if ((p=strchr(called.name, '.'))) {
			*p = 0;
			goto again;
		}
		if (strcmp(called.name, "*SMBSERVER")) {
			make_nmb_name(&called , "*SMBSERVER", 0x20);
			goto again;
		}
		return NULL;
	}

	DEBUG(4,(" session request ok\n"));

	if (!cli_negprot(c)) {
		DEBUG(0,("protocol negotiation failed\n"));
		cli_shutdown(c);
		free(c);
		return NULL;
	}

	if (!got_pass) {
		//char *pass = getpass("Password: ");
		//if (pass) {
		//	pstrcpy(password, pass);
		//}
	}

	if (!cli_session_setup(c, username, 
			       password, strlen(password),
			       password, strlen(password),
			       workgroup)) {
		// if a password was not supplied then try again with a null username
		if (password[0] || !username[0] || 
		    !cli_session_setup(c, "", "", 0, "", 0, workgroup)) { 
			DEBUG(0,("session setup failed: %s\n", cli_errstr(c)));
			cli_shutdown(c);
			free(c);
			return NULL;
		}
		DEBUG(0,("Anonymous login successful\n"));
	}

	 // These next two lines are needed to emulate
	 // old client behaviour for people who have
	 // scripts based on client output.
	 // QUESTION ? Do we want to have a 'client compatibility
	 // mode to turn these on/off ? JRA.

	if (*c->server_domain || *c->server_os || *c->server_type)
		DEBUG(1,("Domain=[%s] OS=[%s] Server=[%s]\n",
			c->server_domain,c->server_os,c->server_type));
	
	DEBUG(4,(" session setup ok\n"));

	if (!cli_send_tconX(c, sharename, "?????",
			    password, strlen(password)+1)) {
		DEBUG(0,("tree connect failed: %s\n", cli_errstr(c)));
		cli_shutdown(c);
		free(c);
		return NULL;
	}

	DEBUG(4,(" tconx ok\n"));

	return c;
}


/***********************************************************************
 * Connect to a network resource
 ***********************************************************************/
Int16 CmdConnect(UInt16 argc, const Char * argv[])
{
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	if (argc < 2) goto FullHelp;

	pstrcpy(service,argv[1]);  
	/* Convert any '/' characters in the service name to '\' characters */
	string_replace( service, '/','\\');
	if (count_chars(service,'\\') < 3) {
		printf("\n%s: Not enough '\\' characters in service\n",service);
		return;
	}

	if (argc >= 3) {
		dest_ip = *interpret_addr2((char*)argv[2]);
		if (zero_ip(dest_ip)) {
			return;
		}
		have_ip = True;
	}

	load_interfaces();

	cli = do_connect(desthost, service);
	if (!cli) {
		return;
	}

	//if (*base_directory) do_cd(base_directory);
	return;
	
ShortHelp:
	printf("%s\t\t# Connect to a SMB resource\n", argv[0]);
	return;
	
FullHelp:
	printf("\nConnect to a SMB resource");
	printf("\nSyntax: %s service [ip]", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Print current directory
 ***********************************************************************/
Int16 CmdPwd(UInt16 argc, const Char * argv[])
{
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	if (!cli) {
		printf("Not connected!\n");
		return;
	}
	DEBUG(0,("Current directory is %s",service));
	DEBUG(0,("%s\n",cur_dir));
	return;
	
ShortHelp:
	printf("%s\t\t# Print current directory\n", argv[0]);
	return;
	
FullHelp:
	printf("\nPrint current directory on remote host");
	printf("\nSyntax: %s", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Change current directory
 ***********************************************************************/
Int16 CmdCd(UInt16 argc, const Char * argv[])
{
	static pstring saved_dir;
	static pstring dname;
	fstring newdir;
	char *p = newdir;

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	if (argc < 2) goto FullHelp;

	if (!cli) {
		printf("Not connected!\n");
		return;
	}

	fstrcpy(newdir, argv[1]);
	dos_format(newdir);

	/* Save the current directory in case the
	   new directory is invalid */
	pstrcpy(saved_dir, cur_dir);
	if (*p == '\\')
		pstrcpy(cur_dir,p);
	else
		pstrcat(cur_dir,p);
	if (*(cur_dir+strlen(cur_dir)-1) != '\\') {
		pstrcat(cur_dir, "\\");
	}
	dos_clean_name(cur_dir);
	pstrcpy(dname,cur_dir);
	pstrcat(cur_dir,"\\");
	dos_clean_name(cur_dir);
	
	if (!strequal(cur_dir,"\\")) {
		if (!cli_chkpath(cli, dname)) {
			DEBUG(0,("cd %s: %s\n", dname, cli_errstr(cli)));
			pstrcpy(cur_dir,saved_dir);
		}
	}
	
	DEBUG(0,("Current directory is %s\n",cur_dir));
	return;
	
ShortHelp:
	printf("%s\t\t# Change current directory\n", argv[0]);
	return;
	
FullHelp:
	printf("\nChange current directory on remote host");
	printf("\nSyntax: %s dir", argv[0]);
	printf("\n");
}


/****************************************************************************
  display info about a file
  ****************************************************************************/
static void display_finfo(file_info *finfo, const char* mask)
{
	//if (do_this_one(finfo)) {
		time_t t = finfo->mtime; /* the time is assumed to be passed as GMT */
		//TODO: fix time problem
		//DEBUG(0,("  %s %s %ld  %s", finfo->name, attrib_string(finfo->mode), (uint32) finfo->size, asctime(LocalTime(&t))));
		DEBUG(0,("%s %s %lu\n", finfo->name, attrib_string(finfo->mode), finfo->size));
		dir_total += finfo->size;
	//}
}


/***********************************************************************
 * Print current directory
 ***********************************************************************/
Int16 CmdDir(UInt16 argc, const Char * argv[])
{
	uint16 attribute = aDIR | aSYSTEM | aHIDDEN;
	pstring mask;
	fstring buf;
	char *p=buf;

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	if (!cli) {
		printf("Not connected!\n");
		return;
	}

	dir_total = 0;
	pstrcpy(mask,cur_dir);
	if (mask[strlen(mask)-1]!='\\')
		pstrcat(mask,"\\");
	
	if (argc >= 2) {
		pstrcpy(buf, argv[1]);
		dos_format(p);
		if (*p == '\\')
			pstrcpy(mask,p);
		else
			pstrcat(mask,p);
	}
	else {
		pstrcat(mask,"*");
	}

	if (cli_list(cli, mask, attribute, display_finfo) == -1) {
		DEBUG(0, ("%s listing %s\n", cli_errstr(cli), mask));
	}

	//do_dskattr();

	DEBUG(3, ("Total bytes listed: %lu\n", dir_total));
	return;
	
ShortHelp:
	printf("%s\t\t# List current directory\n", argv[0]);
	return;
	
FullHelp:
	printf("\nList current directory on remote host");
	printf("\nSyntax: %s [mask]", argv[0]);
	printf("\n");
}


/****************************************************************************
list a share name
****************************************************************************/
static void browse_fn(const char *name, uint32 m, const char *comment)
{
        fstring typestr;

        *typestr=0;

        switch (m)
        {
          case STYPE_DISKTREE:
            fstrcpy(typestr,"Disk"); break;
          case STYPE_PRINTQ:
            fstrcpy(typestr,"Printer"); break;
          case STYPE_DEVICE:
            fstrcpy(typestr,"Device"); break;
          case STYPE_IPC:
            fstrcpy(typestr,"IPC"); break;
        }

        printf("%-15s %-10s %s\n",
               name, typestr,comment);
}

/****************************************************************************
try and browse available connections on a host
****************************************************************************/
static BOOL browse_host(BOOL sort)
{
	int ret;

        printf("\n");
		printf("Sharename      Type      Comment\n");
        printf("---------      ----      -------\n");

	if((ret = cli_RNetShareEnum(cli, browse_fn)) == -1)
		printf("Error returning browse list: %s\n", cli_errstr(cli));

	return (ret != -1);
}


/****************************************************************************
list a server name
****************************************************************************/
static void server_fn(const char *name, uint32 m, const char *comment)
{
        printf("%-16s     %s\n", name, comment);
}

/****************************************************************************
try and browse available connections on a host
****************************************************************************/
static BOOL list_servers(char *wk_grp)
{
	if (!cli->server_domain) return False;

        printf("\n");
		printf("Server               Comment\n");
        printf("---------            -------\n");

	cli_NetServerEnum(cli, cli->server_domain, SV_TYPE_ALL, server_fn);

        printf("\n");
		printf("Workgroup            Master\n");
        printf("---------            -------\n");

	cli_NetServerEnum(cli, cli->server_domain, SV_TYPE_DOMAIN_ENUM, server_fn);
	return True;
}


/***********************************************************************
 * Query available shares on a host
 ***********************************************************************/
Int16 CmdHostQuery(UInt16 argc, const Char * argv[])
{
	char* desthost;

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;
	if (argc < 2) goto FullHelp;

	desthost = (char*)argv[1];

	load_interfaces();

	cli = do_connect(desthost, "IPC$");
	if (!cli) {
		return;
	}
	browse_host(True);
	list_servers(workgroup);

	cli_shutdown(cli);
	return;

ShortHelp:
	printf("%s\t\t# Get a list of shares available on a host\n", argv[0]);
	return;
	
FullHelp:
	printf("\nGet a list of shares available on a host");
	printf("\nSyntax: %s host", argv[0]);
	printf("\n");
}


/***********************************************************************
 *
 ***********************************************************************/
Int16 CmdMessage(UInt16 argc, const Char * argv[])
{
	extern struct in_addr ipzero;
	struct in_addr ip;
	struct nmb_name called, calling;

	int total_len = 0;
	int grp_id;

	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	pstrcpy(desthost, argv[1]);

	load_interfaces();

	ip = ipzero;

	make_nmb_name(&calling, global_myname, 0x0);
	make_nmb_name(&called , desthost, name_type);

again_msg:
	ip = ipzero;
	if (have_ip) {
		ip = dest_ip;
	}

	if (!(cli=cli_initialise(NULL)) || (cli_set_port(cli, port) == 0) || !cli_connect(cli, desthost, &ip)) {
		DEBUG(0,("Connection to %s failed\n", desthost));
		return;
	}

	if (!cli_session_request(cli, &calling, &called)) {
		char *p;
		DEBUG(0,("session request to %s failed (%s)\n", 
			 called.name, cli_errstr(cli)));
		cli_shutdown(cli);
		free(cli);
		if ((p=strchr(called.name, '.'))) {
			*p = 0;
			goto again_msg;
		}
		if (strcmp(called.name, "*SMBSERVER")) {
			make_nmb_name(&called , "*SMBSERVER", 0x20);
			goto again_msg;
		}
		return;
	}

	if (!cli_message_start(cli, desthost, username, &grp_id)) {
		DEBUG(0,("message start: %s\n", cli_errstr(cli)));
		return;
	}

	printf("Connected. Type your message, ending it with a ~ \n");

	while (total_len < 1600) {
		int maxlen = MIN(1600 - total_len,127);
		pstring msg;
		int l=0;
		int c;

		ZERO_ARRAY(msg);

		for (l=0;l<maxlen && (c=getchar())!=-1;l++) {
			if (c == '\n')
				msg[l++] = '\r';
			msg[l] = c;   
		}

		/*
		 * The message is in UNIX codepage format. Convert to
		 * DOS before sending.
		 */
		unix_to_dos(msg, True);

		if (!cli_message_text(cli, msg, l, grp_id)) {
			printf("SMBsendtxt failed (%s)\n",cli_errstr(cli));
			return;
		}      
		
		total_len += l;
	}

	if (total_len >= 1600)
		printf("the message was truncated to 1600 bytes\n");
	else
		printf("sent %d bytes\n",total_len);

	if (!cli_message_end(cli, grp_id)) {
		printf("SMBsendend failed (%s)\n",cli_errstr(cli));
		return;
	}      

	cli_shutdown(cli);
	return;
	
ShortHelp:
	printf("%s\t\t# Send a message\n", argv[0]);
	return;
	
FullHelp:
	printf("\nSend a winpopup message to the host");
	printf("\nSyntax: %s host", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Set the debug level
 ***********************************************************************/
Int16 CmdDebug(UInt16 argc, const Char * argv[])
{
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	if (argc >= 2) {
		DEBUGLEVEL = atoi(argv[1]);
	}
	printf("Debug level is %d\n", DEBUGLEVEL);
	return;
	
ShortHelp:
	printf("%s\t\t# Set the debug level\n", argv[0]);
	return;
	
FullHelp:
	printf("\nSet the debug level");
	printf("\nSyntax: %s level (0..99)", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Set the user and password level
 ***********************************************************************/
Int16 CmdUser(UInt16 argc, const Char * argv[])
{
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	if (argc >= 2) {
		pstrcpy(username, argv[1]);
		strupper(username);
		if (argc >= 3) {
			pstrcpy(password, argv[2]);
		}
		else {
			password[0] = 0;
		}
		got_pass = true;
	}
	printf("User is '%s', password is '%s'\n", username, password);
	return;
	
ShortHelp:
	printf("%s\t\t# Set user/password\n", argv[0]);
	return;
	
FullHelp:
	printf("\nSet the user name and password for resource access");
	printf("\nSyntax: %s user [pass]", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Set the workgroup level
 ***********************************************************************/
Int16 CmdWorkgroup(UInt16 argc, const Char * argv[])
{
	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	if (argc >= 2) {
		pstrcpy(workgroup, argv[1]);
	}
	printf("Workgroup is '%s'\n", workgroup);
	return;
	
ShortHelp:
	printf("%s\t\t# Set workgroup\n", argv[0]);
	return;
	
FullHelp:
	printf("\nSet the workgroup name");
	printf("\nSyntax: %s workgroup", argv[0]);
	printf("\n");
}


/***********************************************************************
 * Initialize the module's internals, and installs the user commands 
 * into the command table.
 ***********************************************************************/
BOOL CmdSMBInit(void)
{
	// initialize SMB stuff
	//TimeInit();
	charset_initialise();
	//codepage_initialise(lp_client_code_page());
	pstrcpy(workgroup, lp_workgroup());
	// Don't call load_interfaces() now because NetLib might not be open yet

	// This is for debugging only
	pstrcpy(workgroup, "WORKGROUP");
	pstrcpy(username, "olivier");
	pstrcpy(password, "");
	got_pass = true;

	SioAddCommand("debug", CmdDebug);
	SioAddCommand("user", CmdUser);
	SioAddCommand("wg", CmdWorkgroup);

	SioAddCommand("query", CmdHostQuery);
	SioAddCommand("msg", CmdMessage);
	SioAddCommand("connect", CmdConnect);
	SioAddCommand("dir", CmdDir);
	SioAddCommand("ls", CmdDir);
	SioAddCommand("pwd", CmdPwd);
	SioAddCommand("cd", CmdCd);
	SioAddCommand("get", CmdGet);
}

/***********************************************************************
 * Shutdown and cleanup this module
 ***********************************************************************/
void CmdSMBClose(void) {
	if (cli) {
		cli_shutdown(cli);
	}
}