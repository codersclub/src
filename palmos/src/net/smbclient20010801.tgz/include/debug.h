/* 
   Unix SMB/Netbios implementation.
   Version 1.9.
   SMB debug stuff
   Copyright (C) Andrew Tridgell 1992-1998
   Copyright (C) John H Terpstra 1996-1998
   Copyright (C) Luke Kenneth Casson Leighton 1996-1998
   Copyright (C) Paul Ashton 1998
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef _DEBUG_H
#define _DEBUG_H


extern int DEBUGLEVEL;


/* Debugging macros
 *
 * DEBUGLVL()
 *   If the 'file specific' debug class level >= level OR the system-wide 
 *   DEBUGLEVEL (synomym for DEBUGLEVEL_CLASS[ DBGC_ALL ]) >= level then
 *   generate a header using the default macros for file, line, and 
 *   function name. Returns True if the debug level was <= DEBUGLEVEL.
 * 
 *   Example: if( DEBUGLVL( 2 ) ) dbgtext( "Some text.\n" );
 *
 * DEBUGLVLC()
 *   If the 'macro specified' debug class level >= level OR the system-wide 
 *   DEBUGLEVEL (synomym for DEBUGLEVEL_CLASS[ DBGC_ALL ]) >= level then 
 *   generate a header using the default macros for file, line, and 
 *   function name. Returns True if the debug level was <= DEBUGLEVEL.
 * 
 *   Example: if( DEBUGLVL( DBGC_TDB, 2 ) ) dbgtext( "Some text.\n" );
 *
 * DEBUG()
 *   If the 'file specific' debug class level >= level OR the system-wide 
 *   DEBUGLEVEL (synomym for DEBUGLEVEL_CLASS[ DBGC_ALL ]) >= level then 
 *   generate a header using the default macros for file, line, and 
 *   function name. Each call to DEBUG() generates a new header *unless* the 
 *   previous debug output was unterminated (i.e. no '\n').
 *   See debug.c:dbghdr() for more info.
 *
 *   Example: DEBUG( 2, ("Some text and a valu %d.\n", value) );
 *
 * DEBUGC()
 *   If the 'macro specified' debug class level >= level OR the system-wide 
 *   DEBUGLEVEL (synomym for DEBUGLEVEL_CLASS[ DBGC_ALL ]) >= level then 
 *   generate a header using the default macros for file, line, and 
 *   function name. Each call to DEBUG() generates a new header *unless* the 
 *   previous debug output was unterminated (i.e. no '\n').
 *   See debug.c:dbghdr() for more info.
 *
 *   Example: DEBUG( DBGC_TDB, 2, ("Some text and a valu %d.\n", value) );
 *
 *  DEBUGADD(), DEBUGADDC()
 *    Same as DEBUG() and DEBUGC() except the text is appended to the previous
 *    DEBUG(), DEBUGC(), DEBUGADD(), DEBUGADDC() with out another interviening 
 *    header.
 *
 *    Example: DEBUGADD( 2, ("Some text and a valu %d.\n", value) );
 *             DEBUGADDC( DBGC_TDB, 2, ("Some text and a valu %d.\n", value) );
 *
 * Note: If the debug class has not be redeined (see above) then the optimizer 
 * will remove the extra conditional test.
 */

#define DEBUGLVL( level ) \
  (DEBUGLEVEL >= (level)

#define DEBUG( level, body ) \
  (void)( ((DEBUGLEVEL >= (level))  ) \
       && (printf body) )

#define DEBUGADD( level, body ) \
  (void)( ((DEBUGLEVEL >= (level))  ) \
       && (printf body) )

#endif
