/* include/config.h.  Generated automatically by configure.  */
/* include/config.h.in.  Generated automatically from configure.in by autoheader.  */

#ifndef _CONFIG_H
#define _CONFIG_H

/* Define if on AIX 3.
   System headers sometimes define this.
   We just want to avoid a redefinition error message.  */
#ifndef _ALL_SOURCE
/* #undef _ALL_SOURCE */
#endif

/* Define if type char is unsigned and you are not using gcc.  */
#ifndef __CHAR_UNSIGNED__
/* #undef __CHAR_UNSIGNED__ */
#endif

#define DEBUG_SNPRINTF

#ifdef PALMOS
//OG: The PalmOS has a 32K limit on code size (or more precisely, on jumps).
// To overcome this limit, we have to split the functions across several
// "sections" that the GCC linker knows how to handle.
// The sections must also be listed in the "client.def" file.
// A function is assigned to a section by appending the SECTION_XXXXXX macro
// to its declaration. This is usually done in the "proto.h" file.
#define SECTION_UTIL_STR	__attribute__ ((section ("u_str")))
#define SECTION_UTIL		__attribute__ ((section ("util")))
#define SECTION_TALLOC		__attribute__ ((section ("talloc")))
#define SECTION_SLPRINTF	__attribute__ ((section ("slprintf")))
#define SECTION_MS_FNMATCH	__attribute__ ((section ("fnmatch")))
#define SECTION_GENRAND		__attribute__ ((section ("genrand")))
#define SECTION_SNPRINTF	__attribute__ ((section ("snprintf")))
#define SECTION_INTERFACE	__attribute__ ((section ("if")))
#define SECTION_INTERFACES	__attribute__ ((section ("ifs")))
#define SECTION_SELECT		__attribute__ ((section ("select")))
#define SECTION_UTIL_SOCK	__attribute__ ((section ("u_sock")))
#define SECTION_REPLACE		__attribute__ ((section ("replace")))
#define SECTION_SYSTEM		__attribute__ ((section ("system")))
#define SECTION_CHARSET		__attribute__ ((section ("charset")))
#define SECTION_CHARCNV		__attribute__ ((section ("charcnv")))
#define SECTION_TIME		__attribute__ ((section ("time")))
#define SECTION_CLIENTGEN	__attribute__ ((section ("cligen")))
#define SECTION_CLICONNECT	__attribute__ ((section ("cliconn")))
#define SECTION_CLIERROR	__attribute__ ((section ("clierror")))
#define SECTION_NAMEQUERY	__attribute__ ((section ("namequer")))
#define SECTION_NMBLIB		__attribute__ ((section ("nmblib")))
#define SECTION_NTERR		__attribute__ ((section ("nterr")))
#define SECTION_PWD_CACHE	__attribute__ ((section ("pwd_cach")))
#define SECTION_SMBDES		__attribute__ ((section ("smbdes")))
#define SECTION_SMBENCRYPT	__attribute__ ((section ("smbencry")))
#define SECTION_SMBERR		__attribute__ ((section ("smberr")))
#define SECTION_UNEXPECTED	__attribute__ ((section ("unexp")))
#define SECTION_MD4			__attribute__ ((section ("md4")))
#define SECTION_CLIENT		__attribute__ ((section ("client")))
#define SECTION_CMDNET		__attribute__ ((section ("cmdnet")))
#define SECTION_CMDSMB		__attribute__ ((section ("cmdsmb")))
#define SECTION_LOADPARM	__attribute__ ((section ("loadparm")))
#define SECTION_CLIRAP		__attribute__ ((section ("clirap")))
#define SECTION_CLITRANS	__attribute__ ((section ("clitrans")))
#define SECTION_CLIMESSAGE	__attribute__ ((section ("climsg")))
#define SECTION_CLILIST		__attribute__ ((section ("clilist")))
#define SECTION_CLIFILE		__attribute__ ((section ("clifile")))
#define SECTION_CLIREADWRITE	__attribute__ ((section ("clirw")))
#else
#define SECTION_UTIL_STR
#define SECTION_UTIL
#define SECTION_TALLOC
#define SECTION_SLPRINTF
#define SECTION_MS_FNMATCH
#define SECTION_GENRAND
#define SECTION_SNPRINTF
#define SECTION_INTERFACE
#define SECTION_INTERFACES
#define SECTION_SELECT
#define SECTION_UTIL_SOCK
#define SECTION_REPLACE
#define SECTION_SYSTEM
#define SECTION_CHARSET
#define SECTION_CHARCNV
#define SECTION_TIME
#define SECTION_CLIENTGEN
#define SECTION_CLICONNECT
#define SECTION_CLIERROR
#define SECTION_NAMEQUERY
#define SECTION_NMBLIB
#define SECTION_NTERR
#define SECTION_PWD_CACHE
#define SECTION_SMBDES
#define SECTION_SMBENCRYPT
#define SECTION_SMBERR
#define SECTION_UNEXPECTED
#define SECTION_MD4
#define SECTION_CLIENT
#define SECTION_CMDNET
#define SECTION_CMDSMB
#define SECTION_LOADPARM
#define SECTION_CLIRAP
#define SECTION_CLITRANS
#define SECTION_CLIMESSAGE
#define SECTION_CLILIST
#define SECTION_CLIFILE
#define SECTION_CLIREADWRITE
#endif

//
// undefined types
//

#define ptrdiff_t unsigned long

typedef void* DIR;

//typedef void *FILE;


#define _O_RDONLY       0x0000  /* open for reading only */
#define _O_WRONLY       0x0001  /* open for writing only */
#define _O_RDWR         0x0002  /* open for reading and writing */
#define _O_APPEND       0x0008  /* writes done at eof */

#define _O_CREAT        0x0100  /* create and open file */
#define _O_TRUNC        0x0200  /* open and truncate */
#define _O_EXCL         0x0400  /* open only if file doesn't already exist */

#define _O_TEXT         0x4000  /* file mode is text (translated) */
#define _O_BINARY       0x8000  /* file mode is binary (untranslated) */

#define O_RDONLY        _O_RDONLY
#define O_WRONLY        _O_WRONLY
#define O_RDWR          _O_RDWR
#define O_APPEND        _O_APPEND
#define O_CREAT         _O_CREAT
#define O_TRUNC         _O_TRUNC
#define O_EXCL          _O_EXCL
#define O_TEXT          _O_TEXT
#define O_BINARY        _O_BINARY
#define O_RAW           _O_BINARY
#define O_TEMPORARY     _O_TEMPORARY
#define O_NOINHERIT     _O_NOINHERIT
#define O_SEQUENTIAL    _O_SEQUENTIAL
#define O_RANDOM        _O_RANDOM

/* Define to empty if the keyword does not work.  */
/* #undef const */

/* Define to `int' if <sys/types.h> doesn't define.  */
#define gid_t int
#define uid_t int

/* Define if you have a working `mmap' system call.  */
/* #define HAVE_MMAP 1 */


/* Define if your struct stat has st_rdev.  */
/* #define HAVE_ST_RDEV 1 */

/* Define if you have <sys/wait.h> that is POSIX.1 compatible.  */
/* #define HAVE_SYS_WAIT_H 1 */

/* Define as __inline if that's what the C compiler calls it.  */
/* #undef inline */

/* Define to `int' if <sys/types.h> doesn't define.  */
#define mode_t int

/* Define if your C compiler doesn't accept -c and -o together.  */
/* #undef NO_MINUS_C_MINUS_O */

/* Define to `long' if <sys/types.h> doesn't define.  */
#define off_t unsigned long

/* Define to `int' if <sys/types.h> doesn't define.  */
#define pid_t int

#define time_t long

struct utimbuf 
{
  time_t actime;
  time_t modtime; 
};


#define nlink_t int
#define dev_t long
#define ino_t long

struct	stat 
{
  dev_t		st_dev;
  ino_t		st_ino;
  mode_t	st_mode;
  nlink_t	st_nlink;
  uid_t		st_uid;
  gid_t		st_gid;
  dev_t		st_rdev;
  off_t		st_size;
  time_t	st_atime;
  time_t	st_mtime;
  time_t	st_ctime;
};

struct passwd {
	char	*pw_name;		/* user name */
	char	*pw_passwd;		/* encrypted password */
	int	pw_uid;			/* user uid */
	int	pw_gid;			/* user gid */
	char	*pw_comment;		/* comment */
	char	*pw_gecos;		/* Honeywell login info */
	char	*pw_dir;		/* home directory */
	char	*pw_shell;		/* default shell */
};


struct tm
{
  int	tm_sec;
  int	tm_min;
  int	tm_hour;
  int	tm_mday;
  int	tm_mon;
  int	tm_year;
  int	tm_wday;
  int	tm_yday;
  int	tm_isdst;
};

#define LocalTime localtime


/* Define as the return type of signal handlers (int or void).  */
#define RETSIGTYPE void

/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */

/* Define if you have the ANSI C header files.  */
/* #define STDC_HEADERS 1 */

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define to `int' if <sys/types.h> doesn't define.  */
#define uid_t int

/* Define if your processor stores words with the most significant
   byte first (like Motorola and SPARC, unlike Intel and VAX).  */
#define WORDS_BIGENDIAN

#define HAVE_VOLATILE 1
/* #undef HAVE_BROKEN_READDIR */
#define HAVE_ERRNO_DECL 1
#define HAVE_LONGLONG 1
/* #undef HAVE_OFF64_T */
/* #undef HAVE_REMSH */
/* #undef HAVE_UNSIGNED_CHAR */
/* #define HAVE_UTIMBUF 1 */
/*#define HAVE_SIG_ATOMIC_T_TYPE 1 */
typedef long ssize_t;
/* #undef ino_t */
/* #undef ssize_t */
#define loff_t off_t
#define offset_t loff_t
/* #undef aclent_t */
/* #undef wchar_t */
#define HAVE_CONNECT 1
/* #undef HAVE_SHORT_INO_T */
/* #undef WITH_SMBWRAPPER */
/* #undef WITH_AFS */
/* #undef WITH_DFS */
//#define PALMOS
/* #undef SUNOS5 */
/* #undef SUNOS4 */
/* #undef LINUX */
/* #undef AIX */
/* #undef BSD */
/* #undef IRIX */
/* #undef IRIX6 */
/* #undef HPUX */
/* #undef QNX */
/* #undef SCO */
/* #undef OSF1 */
/* #undef NEXT2 */
/* #undef RELIANTUNIX */
#define HAVE_MMAP 1
/* #undef HAVE_FCNTL_LOCK */
#define HAVE_FTRUNCATE_EXTEND 1
/* #undef FTRUNCATE_NEEDS_ROOT */
/* #undef HAVE_TRAPDOOR_UID */
/* #undef HAVE_ROOT */
#define HAVE_GETTIMEOFDAY_TZ 1
/* #undef HAVE_SOCK_SIN_LEN */
/* #undef STAT_READ_FILSYS */
/* #define STAT_STATFS2_BSIZE 1 */
/* #undef STAT_STATFS2_FSIZE */
/* #undef STAT_STATFS2_FS_DATA */
/* #undef STAT_STATFS3_OSF1 */
/* #undef STAT_STATFS4 */
/* #undef STAT_STATVFS */
/* #undef STAT_STATVFS64 */
/* #undef HAVE_IFACE_AIX */
/* #undef HAVE_IFACE_IFCONF */
/* #undef HAVE_IFACE_IFREQ */
#define HAVE_IFACE_PALMOS 1
/* #undef HAVE_CRYPT */
/* #undef HAVE_PUTPRPWNAM */
/* #undef HAVE_SET_AUTH_PARAMETERS */
/* #undef WITH_SYSLOG */
/* #undef WITH_PROFILE */
/* #undef WITH_SSL */
/* #undef WITH_LDAP */
/* #undef WITH_NISPLUS */
/* #undef WITH_TDBPWD */
/* #undef WITH_PAM */
/* #undef WITH_NISPLUS_HOME */
/* #undef WITH_AUTOMOUNT */
/* #undef WITH_SMBMOUNT */
/* #undef HAVE_BROKEN_GETGROUPS */
#define REPLACE_GETPASS 1
/* #undef REPLACE_INET_NTOA */
/* #define HAVE_FILE_MACRO 1 */
/* #define HAVE_FUNCTION_MACRO 1 */
/* #undef HAVE_SETRESUID_DECL */
/* #undef HAVE_SETRESUID */
/* #undef WITH_NETATALK */
/* #undef WITH_UTMP */
/* #undef WITH_MSDFS */
/* #undef WITH_VFS */
/* #undef HAVE_INO64_T */
/* #undef HAVE_STRUCT_FLOCK64 */
/* #undef SIZEOF_INO_T */
/* #undef SIZEOF_OFF_T */
/* #undef STAT_STATVFS64 */
/* #undef HAVE_LIBREADLINE */
/* #undef HAVE_KERNEL_SHARE_MODES */
/* #undef HAVE_KERNEL_OPLOCKS_IRIX */
/* #undef HAVE_KERNEL_OPLOCKS_LINUX */
/* #undef HAVE_KERNEL_CHANGE_NOTIFY */
/* #undef HAVE_IRIX_SPECIFIC_CAPABILITIES */
/* #undef HAVE_INT16_FROM_RPC_RPC_H */
/* #undef HAVE_UINT16_FROM_RPC_RPC_H */
/* #undef HAVE_INT32_FROM_RPC_RPC_H */
/* #undef HAVE_UINT32_FROM_RPC_RPC_H */
/* #undef KRB4_AUTH */
/* #undef KRB5_AUTH */
/* #define SEEKDIR_RETURNS_VOID 1 */
/* #undef HAVE_DIRENT_D_OFF */
/* #undef HAVE_GETSPNAM */
/* #undef HAVE_BIGCRYPT */
/* #undef HAVE_GETPRPWNAM */
/* #undef HAVE_FSTAT64 */
/* #undef HAVE_LSTAT64 */
/* #undef HAVE_STAT64 */
/* #undef HAVE_SETRESGID */
/* #undef HAVE_SETRESGID_DECL */
/* #undef HAVE_SHADOW_H */
//#define HAVE_STRCASECMP 1
/* #undef HAVE_STRUCT_DIRENT64 */
#define HAVE_TRUNCATED_SALT 1
#define BROKEN_NISPLUS_INCLUDE_FILES 1
/* #undef HAVE_RPC_AUTH_ERROR_CONFLICT */
/* #undef HAVE_EXPLICIT_LARGEFILE_SUPPORT */
/* #undef USE_BOTH_CRYPT_CALLS */
/* #undef HAVE_BROKEN_FCNTL64_LOCKS */
/* #undef HAVE_SECURE_MKSTEMP */
/* #undef HAVE_FNMATCH */
/* #undef USE_SETEUID */
/* #undef USE_SETRESUID */
/* #undef USE_SETREUID */
/* #undef USE_SETUIDX */
/* #undef HAVE_LIBDL */
//#define SYSCONF_SC_NGROUPS_MAX 1
#define HAVE_UT_UT_NAME 1
#define HAVE_UT_UT_USER 1
#define HAVE_UT_UT_ID 1
#define HAVE_UT_UT_HOST 1
#define HAVE_UT_UT_TIME 1
/* #undef HAVE_UT_UT_TV */
#define HAVE_UT_UT_TYPE 1
#define HAVE_UT_UT_PID 1
/* #undef HAVE_UT_UT_EXIT */
#define HAVE_UT_UT_ADDR 1
/* #undef HAVE_UX_UT_SYSLEN */
/* #undef PUTUTLINE_RETURNS_UTMP */
#define COMPILER_SUPPORTS_LL 1
/* #undef HAVE_YP_GET_DEFAULT_DOMAIN */
/* #undef USE_SPINLOCKS */
/* #undef SPARC_SPINLOCKS */
/* #undef INTEL_SPINLOCKS */
/* #undef MIPS_SPINLOCKS */
/* #undef POWERPC_SPINLOCKS */
/* #undef HAVE_POSIX_ACLS */
/* #undef HAVE_ACL_GET_PERM_NP */
/* #undef HAVE_UNIXWARE_ACLS */
/* #undef HAVE_SOLARIS_ACLS */
/* #undef HAVE_IRIX_ACLS */
/* #undef HAVE_XFS_ACLS */
/* #undef HAVE_AIX_ACLS */
#define HAVE_NO_ACLS 1

/* The number of bytes in a int.  */
#define SIZEOF_INT 4

/* The number of bytes in a long.  */
#define SIZEOF_LONG 4

/* The number of bytes in a short.  */
#define SIZEOF_SHORT 2

/* Define if you have the __acl function.  */
/* #undef HAVE___ACL */

/* Define if you have the __chdir function.  */
/* #undef HAVE___CHDIR */

/* Define if you have the __close function.  */
/* #undef HAVE___CLOSE */

/* Define if you have the __closedir function.  */
/* #undef HAVE___CLOSEDIR */

/* Define if you have the __dup function.  */
/* #undef HAVE___DUP */

/* Define if you have the __dup2 function.  */
/* #undef HAVE___DUP2 */

/* Define if you have the __facl function.  */
/* #undef HAVE___FACL */

/* Define if you have the __fchdir function.  */
/* #undef HAVE___FCHDIR */

/* Define if you have the __fcntl function.  */
/* #undef HAVE___FCNTL */

/* Define if you have the __fork function.  */
/* #undef HAVE___FORK */

/* Define if you have the __fstat function.  */
/* #undef HAVE___FSTAT */

/* Define if you have the __fstat64 function.  */
/* #undef HAVE___FSTAT64 */

/* Define if you have the __fxstat function.  */
/* #undef HAVE___FXSTAT */

/* Define if you have the __getcwd function.  */
/* #undef HAVE___GETCWD */

/* Define if you have the __getdents function.  */
/* #undef HAVE___GETDENTS */

/* Define if you have the __llseek function.  */
/* #undef HAVE___LLSEEK */

/* Define if you have the __lseek function.  */
/* #undef HAVE___LSEEK */

/* Define if you have the __lstat function.  */
/* #undef HAVE___LSTAT */

/* Define if you have the __lstat64 function.  */
/* #undef HAVE___LSTAT64 */

/* Define if you have the __lxstat function.  */
/* #undef HAVE___LXSTAT */

/* Define if you have the __open function.  */
/* #undef HAVE___OPEN */

/* Define if you have the __open64 function.  */
/* #undef HAVE___OPEN64 */

/* Define if you have the __opendir function.  */
/* #undef HAVE___OPENDIR */

/* Define if you have the __pread function.  */
/* #undef HAVE___PREAD */

/* Define if you have the __pread64 function.  */
/* #undef HAVE___PREAD64 */

/* Define if you have the __pwrite function.  */
/* #undef HAVE___PWRITE */

/* Define if you have the __pwrite64 function.  */
/* #undef HAVE___PWRITE64 */

/* Define if you have the __read function.  */
/* #undef HAVE___READ */

/* Define if you have the __readdir function.  */
/* #undef HAVE___READDIR */

/* Define if you have the __readdir64 function.  */
/* #undef HAVE___READDIR64 */

/* Define if you have the __seekdir function.  */
/* #undef HAVE___SEEKDIR */

/* Define if you have the __stat function.  */
/* #undef HAVE___STAT */

/* Define if you have the __stat64 function.  */
/* #undef HAVE___STAT64 */

/* Define if you have the __sys_llseek function.  */
/* #undef HAVE___SYS_LLSEEK */

/* Define if you have the __telldir function.  */
/* #undef HAVE___TELLDIR */

/* Define if you have the __write function.  */
/* #undef HAVE___WRITE */

/* Define if you have the __xstat function.  */
/* #undef HAVE___XSTAT */

/* Define if you have the _acl function.  */
/* #undef HAVE__ACL */

/* Define if you have the _chdir function.  */
/* #define HAVE__CHDIR 1 */

/* Define if you have the _close function.  */
/* #define HAVE__CLOSE 1 */

/* Define if you have the _closedir function.  */
/* #define HAVE__CLOSEDIR 1 */

/* Define if you have the _dup function.  */
/* #define HAVE__DUP 1 */

/* Define if you have the _dup2 function.  */
/* #define HAVE__DUP2 1 */

/* Define if you have the _facl function.  */
/* #undef HAVE__FACL */

/* Define if you have the _fchdir function.  */
/* #undef HAVE__FCHDIR */

/* Define if you have the _fcntl function.  */
/* #define HAVE__FCNTL 1 */

/* Define if you have the _fork function.  */
/* #define HAVE__FORK 1 */

/* Define if you have the _fstat function.  */
/* #define HAVE__FSTAT 1 */

/* Define if you have the _fstat64 function.  */
/* #undef HAVE__FSTAT64 */

/* Define if you have the _getcwd function.  */
/* #define HAVE__GETCWD 1 */

/* Define if you have the _getdents function.  */
/* #undef HAVE__GETDENTS */

/* Define if you have the _llseek function.  */
/* #undef HAVE__LLSEEK */

/* Define if you have the _lseek function.  */
/* #define HAVE__LSEEK 1 */

/* Define if you have the _lstat function.  */
/* #define HAVE__LSTAT 1 */

/* Define if you have the _lstat64 function.  */
/* #undef HAVE__LSTAT64 */

/* Define if you have the _open function.  */
/* #define HAVE__OPEN 1 */

/* Define if you have the _open64 function.  */
/* #undef HAVE__OPEN64 */

/* Define if you have the _opendir function.  */
/* #define HAVE__OPENDIR 1 */

/* Define if you have the _pread function.  */
/* #undef HAVE__PREAD */

/* Define if you have the _pread64 function.  */
/* #undef HAVE__PREAD64 */

/* Define if you have the _pwrite function.  */
/* #undef HAVE__PWRITE */

/* Define if you have the _pwrite64 function.  */
/* #undef HAVE__PWRITE64 */

/* Define if you have the _read function.  */
/* #define HAVE__READ 1 */

/* Define if you have the _readdir function.  */
/* #define HAVE__READDIR 1 */

/* Define if you have the _readdir64 function.  */
/* #undef HAVE__READDIR64 */

/* Define if you have the _seekdir function.  */
/* #undef HAVE__SEEKDIR */

/* Define if you have the _stat function.  */
/* #define HAVE__STAT 1 */

/* Define if you have the _stat64 function.  */
/* #undef HAVE__STAT64 */

/* Define if you have the _telldir function.  */
/* #undef HAVE__TELLDIR */

/* Define if you have the _write function.  */
/* #define HAVE__WRITE 1 */

/* Define if you have the atexit function.  */
/* #define HAVE_ATEXIT 1 */

/* Define if you have the bigcrypt function.  */
/* #undef HAVE_BIGCRYPT */

/* Define if you have the bzero function.  */
#define HAVE_BZERO 1

/* Define if you have the chmod function.  */
/* #define HAVE_CHMOD 1 */

/* Define if you have the chown function.  */
/* #define HAVE_CHOWN 1 */

/* Define if you have the chroot function.  */
/* #define HAVE_CHROOT 1 */

/* Define if you have the connect function.  */
#define HAVE_CONNECT 1

/* Define if you have the creat64 function.  */
/* #undef HAVE_CREAT64 */

/* Define if you have the crypt function.  */
/* #undef HAVE_CRYPT */

/* Define if you have the crypt16 function.  */
/* #undef HAVE_CRYPT16 */

/* Define if you have the dup2 function.  */
/* #define HAVE_DUP2 1 */

/* Define if you have the endnetgrent function.  */
/* #undef HAVE_ENDNETGRENT */

/* Define if you have the execl function.  */
/* #define HAVE_EXECL 1 */

/* Define if you have the fchmod function.  */
/* #define HAVE_FCHMOD 1 */

/* Define if you have the fchown function.  */
/* #undef HAVE_FCHOWN */

/* Define if you have the fcvt function.  */
//#define HAVE_FCVT 1

/* Define if you have the fcvtl function.  */
/* #undef HAVE_FCVTL */

/* Define if you have the fopen64 function.  */
/* #undef HAVE_FOPEN64 */

/* Define if you have the fseek64 function.  */
/* #undef HAVE_FSEEK64 */

/* Define if you have the fseeko64 function.  */
/* #undef HAVE_FSEEKO64 */

/* Define if you have the fstat function.  */
/* #define HAVE_FSTAT 1 */

/* Define if you have the fstat64 function.  */
/* #undef HAVE_FSTAT64 */

/* Define if you have the fsync function.  */
/* #define HAVE_FSYNC 1 */

/* Define if you have the ftell64 function.  */
/* #undef HAVE_FTELL64 */

/* Define if you have the ftello64 function.  */
/* #undef HAVE_FTELLO64 */

/* Define if you have the ftruncate function.  */
//#define HAVE_FTRUNCATE 1

/* Define if you have the ftruncate64 function.  */
/* #undef HAVE_FTRUNCATE64 */

/* Define if you have the getauthuid function.  */
/* #undef HAVE_GETAUTHUID */

/* Define if you have the getcwd function.  */
//#define HAVE_GETCWD 1

/* Define if you have the getdents function.  */
/* #undef HAVE_GETDENTS */

/* Define if you have the getgrent function.  */
//#define HAVE_GETGRENT 1

/* Define if you have the getgrnam function.  */
//#define HAVE_GETGRNAM 1

/* Define if you have the getnetgrent function.  */
/* #undef HAVE_GETNETGRENT */

/* Define if you have the getprpwnam function.  */
/* #undef HAVE_GETPRPWNAM */

/* Define if you have the getpwanam function.  */
/* #undef HAVE_GETPWANAM */

/* Define if you have the getrlimit function.  */
/* #undef HAVE_GETRLIMIT */

/* Define if you have the getspnam function.  */
/* #undef HAVE_GETSPNAM */

/* Define if you have the getutmpx function.  */
/* #undef HAVE_GETUTMPX */

/* Define if you have the glob function.  */
/* #undef HAVE_GLOB */

/* Define if you have the grantpt function.  */
//#define HAVE_GRANTPT 1

/* Define if you have the initgroups function.  */
//#define HAVE_INITGROUPS 1

/* Define if you have the innetgr function.  */
/* #undef HAVE_INNETGR */

/* Define if you have the llseek function.  */
/* #undef HAVE_LLSEEK */

/* Define if you have the lseek64 function.  */
/* #undef HAVE_LSEEK64 */

/* Define if you have the lstat64 function.  */
/* #undef HAVE_LSTAT64 */

/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1
#define memmove MemMove

/* Define if you have the memset function.  */
#define HAVE_MEMSET 1

/* Define if you have the mktime function.  */
//#define HAVE_MKTIME 1

/* Define if you have the open64 function.  */
/* #undef HAVE_OPEN64 */

/* Define if you have the pathconf function.  */
//#define HAVE_PATHCONF 1

/* Define if you have the pipe function.  */
//#define HAVE_PIPE 1

/* Define if you have the poll function.  */
/* #undef HAVE_POLL */

/* Define if you have the pread function.  */
/* #undef HAVE_PREAD */

/* Define if you have the pread64 function.  */
/* #undef HAVE_PREAD64 */

/* Define if you have the putprpwnam function.  */
/* #undef HAVE_PUTPRPWNAM */

/* Define if you have the pututline function.  */
/* #undef HAVE_PUTUTLINE */

/* Define if you have the pututxline function.  */
/* #undef HAVE_PUTUTXLINE */

/* Define if you have the pwrite function.  */
/* #undef HAVE_PWRITE */

/* Define if you have the pwrite64 function.  */
/* #undef HAVE_PWRITE64 */

/* Define if you have the rand function.  */
//#define HAVE_RAND 1

/* Define if you have the random function.  */
//#define HAVE_RANDOM 1

/* Define if you have the rdchk function.  */
/* #undef HAVE_RDCHK */

/* Define if you have the readdir64 function.  */
/* #undef HAVE_READDIR64 */

/* Define if you have the rename function.  */
#define HAVE_RENAME 1

/* Define if you have the select function.  */
//#define HAVE_SELECT 1

/* Define if you have the set_auth_parameters function.  */
/* #undef HAVE_SET_AUTH_PARAMETERS */

/* Define if you have the setenv function.  */
//#define HAVE_SETENV 1

/* Define if you have the setgidx function.  */
/* #undef HAVE_SETGIDX */

/* Define if you have the setgroups function.  */
/* #undef HAVE_SETGROUPS */

/* Define if you have the setlinebuf function.  */
/* #undef HAVE_SETLINEBUF */

/* Define if you have the setluid function.  */
/* #undef HAVE_SETLUID */

/* Define if you have the setnetgrent function.  */
/* #undef HAVE_SETNETGRENT */

/* Define if you have the setpriv function.  */
/* #undef HAVE_SETPRIV */

/* Define if you have the setsid function.  */
//#define HAVE_SETSID 1

/* Define if you have the setuidx function.  */
/* #undef HAVE_SETUIDX */

/* Define if you have the sigaction function.  */
//#define HAVE_SIGACTION 1

/* Define if you have the sigblock function.  */
/* #undef HAVE_SIGBLOCK */

/* Define if you have the sigprocmask function.  */
//#define HAVE_SIGPROCMASK 1

/* Define if you have the snprintf function.  */
/* #undef HAVE_SNPRINTF */

/* Define if you have the srand function.  */
//#define HAVE_SRAND 1

/* Define if you have the srandom function.  */
//#define HAVE_SRANDOM 1

/* Define if you have the stat64 function.  */
/* #undef HAVE_STAT64 */

/* Define if you have the strcasecmp function.  */
//#define HAVE_STRCASECMP 1

/* Define if you have the strchr function.  */
#define HAVE_STRCHR 1

/* Define if you have the strdup function.  */
//#define HAVE_STRDUP 1

/* Define if you have the strerror function.  */
//#define HAVE_STRERROR 1

/* Define if you have the strftime function.  */
//#define HAVE_STRFTIME 1

/* Define if you have the strpbrk function.  */
//#define HAVE_STRPBRK 1

/* Define if you have the strtoul function.  */
//#define HAVE_STRTOUL 1

/* Define if you have the syscall function.  */
/* #undef HAVE_SYSCALL */

/* Define if you have the sysconf function.  */
//#define HAVE_SYSCONF 1

/* Define if you have the updwtmp function.  */
/* #undef HAVE_UPDWTMP */

/* Define if you have the updwtmpx function.  */
/* #undef HAVE_UPDWTMPX */

/* Define if you have the usleep function.  */
//#define HAVE_USLEEP 1

/* Define if you have the utime function.  */
//#define HAVE_UTIME 1

/* Define if you have the utimes function.  */
//#define HAVE_UTIMES 1

/* Define if you have the vsnprintf function.  */
/* #undef HAVE_VSNPRINTF */

/* Define if you have the waitpid function.  */
//#define HAVE_WAITPID 1

/* Define if you have the yp_get_default_domain function.  */
/* #undef HAVE_YP_GET_DEFAULT_DOMAIN */

/* Define if you have the <acl/acl.h> header file.  */
/* #undef HAVE_ACL_ACL_H */

/* Define if you have the <arpa/inet.h> header file.  */
//#define HAVE_ARPA_INET_H 1

/* Define if you have the <compat.h> header file.  */
/* #undef HAVE_COMPAT_H */

/* Define if you have the <ctype.h> header file.  */
//#define HAVE_CTYPE_H 1

/* Define if you have the <dirent.h> header file.  */
/* #define HAVE_DIRENT_H 1 */

/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1

/* Define if you have the <glob.h> header file.  */
/* #undef HAVE_GLOB_H */

/* Define if you have the <grp.h> header file.  */
/* #define HAVE_GRP_H 1 */

/* Define if you have the <history.h> header file.  */
/* #undef HAVE_HISTORY_H */

/* Define if you have the <lastlog.h> header file.  */
//#define HAVE_LASTLOG_H 1

/* Define if you have the <limits.h> header file.  */
//#define HAVE_LIMITS_H 1

/* Define if you have the <memory.h> header file.  */
/* #define HAVE_MEMORY_H 1 */

/* Define if you have the <ndir.h> header file.  */
/* #undef HAVE_NDIR_H */

/* Define if you have the <net/if.h> header file.  */
/* #define HAVE_NET_IF_H 1 */

/* Define if you have the <netinet/in_ip.h> header file.  */
/* #define HAVE_NETINET_IN_IP_H */

/* Define if you have the <netinet/in_systm.h> header file.  */
#define HAVE_NETINET_IN_SYSTM_H

/* Define if you have the <netinet/ip.h> header file.  */
#define HAVE_NETINET_IP_H 1

/* Define if you have the <netinet/tcp.h> header file.  */
#define HAVE_NETINET_TCP_H

/* Define if you have the <nss.h> header file.  */
/* #undef HAVE_NSS_H */

/* Define if you have the <poll.h> header file.  */
/* #undef HAVE_POLL_H */

/* Define if you have the <readline.h> header file.  */
/* #undef HAVE_READLINE_H */

/* Define if you have the <readline/history.h> header file.  */
/* #undef HAVE_READLINE_HISTORY_H */

/* Define if you have the <readline/readline.h> header file.  */
//#define HAVE_READLINE_READLINE_H 1

/* Define if you have the <rpc/rpc.h> header file.  */
/* #undef HAVE_RPC_RPC_H */

/* Define if you have the <rpcsvc/nis.h> header file.  */
/* #undef HAVE_RPCSVC_NIS_H */

/* Define if you have the <rpcsvc/yp_prot.h> header file.  */
/* #undef HAVE_RPCSVC_YP_PROT_H */

/* Define if you have the <rpcsvc/ypclnt.h> header file.  */
/* #undef HAVE_RPCSVC_YPCLNT_H */

/* Define if you have the <security/pam_appl.h> header file.  */
/* #undef HAVE_SECURITY_PAM_APPL_H */

/* Define if you have the <shadow.h> header file.  */
/* #undef HAVE_SHADOW_H */

/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1

/* Define if you have the <stdlib.h> header file.  */
#define HAVE_STDLIB_H 1

/* Define if you have the <string.h> header file.  */
#define HAVE_STRING_H 1

/* Define if you have the <strings.h> header file.  */
/* #define HAVE_STRINGS_H 1 */

/* Define if you have the <stropts.h> header file.  */
/* #undef HAVE_STROPTS_H */

/* Define if you have the <sys/acl.h> header file.  */
/* #undef HAVE_SYS_ACL_H */

/* Define if you have the <sys/capability.h> header file.  */
/* #undef HAVE_SYS_CAPABILITY_H */

/* Define if you have the <sys/cdefs.h> header file.  */
//#define HAVE_SYS_CDEFS_H 1

/* Define if you have the <sys/dir.h> header file.  */
/* #undef HAVE_SYS_DIR_H */

/* Define if you have the <sys/dustat.h> header file.  */
/* #undef HAVE_SYS_DUSTAT_H */

/* Define if you have the <sys/fcntl.h> header file.  */
/* #define HAVE_SYS_FCNTL_H 1 */

/* Define if you have the <sys/filio.h> header file.  */
/* #undef HAVE_SYS_FILIO_H */

/* Define if you have the <sys/filsys.h> header file.  */
/* #undef HAVE_SYS_FILSYS_H */

/* Define if you have the <sys/fs/s5param.h> header file.  */
/* #undef HAVE_SYS_FS_S5PARAM_H */

/* Define if you have the <sys/fs/vx_quota.h> header file.  */
/* #undef HAVE_SYS_FS_VX_QUOTA_H */

/* Define if you have the <sys/id.h> header file.  */
/* #undef HAVE_SYS_ID_H */

/* Define if you have the <sys/ioctl.h> header file.  */
/* #define HAVE_SYS_IOCTL_H 1 */

/* Define if you have the <sys/mman.h> header file.  */
/* #define HAVE_SYS_MMAN_H 1 */

/* Define if you have the <sys/mode.h> header file.  */
/* #undef HAVE_SYS_MODE_H */

/* Define if you have the <sys/mount.h> header file.  */
/* #define HAVE_SYS_MOUNT_H 1 */

/* Define if you have the <sys/ndir.h> header file.  */
/* #undef HAVE_SYS_NDIR_H */

/* Define if you have the <sys/param.h> header file.  */
/* #define HAVE_SYS_PARAM_H 1 */

/* Define if you have the <sys/priv.h> header file.  */
/* #undef HAVE_SYS_PRIV_H */

/* Define if you have the <sys/resource.h> header file.  */
/* #undef HAVE_SYS_RESOURCE_H 1 */

/* Define if you have the <sys/security.h> header file.  */
/* #undef HAVE_SYS_SECURITY_H */

/* Define if you have the <sys/select.h> header file.  */
/* #define HAVE_SYS_SELECT_H 1 */

/* Define if you have the <sys/socket.h> header file.  */
#define HAVE_SYS_SOCKET_H 1

/* Define if you have the <sys/sockio.h> header file.  */
/* #undef HAVE_SYS_SOCKIO_H */

/* Define if you have the <sys/statfs.h> header file.  */
/* #undef HAVE_SYS_STATFS_H */

/* Define if you have the <sys/statvfs.h> header file.  */
/* #undef HAVE_SYS_STATVFS_H */

/* Define if you have the <sys/syscall.h> header file.  */
/* #undef HAVE_SYS_SYSCALL_H */

/* Define if you have the <sys/termio.h> header file.  */
/* #define HAVE_SYS_TERMIO_H 1 */

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <sys/un.h> header file.  */
/* #undef HAVE_SYS_UN_H */

/* Define if you have the <sys/unistd.h> header file.  */
//#define HAVE_SYS_UNISTD_H 1

/* Define if you have the <sys/vfs.h> header file.  */
/* #define HAVE_SYS_VFS_H 1 */

/* Define if you have the <sys/wait.h> header file.  */
/* #define HAVE_SYS_WAIT_H 1 */

/* Define if you have the <syscall.h> header file.  */
/* #undef HAVE_SYSCALL_H */

/* Define if you have the <termio.h> header file.  */
/* #define HAVE_TERMIO_H 1 */

/* Define if you have the <termios.h> header file.  */
/* #define HAVE_TERMIOS_H 1 */

/* Define if you have the <unistd.h> header file.  */
/* #define HAVE_UNISTD_H 1 */

/* Define if you have the <utime.h> header file.  */
/* #define HAVE_UTIME_H 1 */

/* Define if you have the <utmp.h> header file.  */
//#define HAVE_UTMP_H 1

/* Define if you have the <utmpx.h> header file.  */
/* #undef HAVE_UTMPX_H */

/* Define if you have the acl library (-lacl).  */
/* #undef HAVE_LIBACL */

/* Define if you have the cups library (-lcups).  */
/* #undef HAVE_LIBCUPS */

/* Define if you have the gen library (-lgen).  */
/* #undef HAVE_LIBGEN */

/* Define if you have the inet library (-linet).  */
/* #undef HAVE_LIBINET */

/* Define if you have the nsl library (-lnsl).  */
/* #undef HAVE_LIBNSL */

/* Define if you have the nsl_s library (-lnsl_s).  */
/* #undef HAVE_LIBNSL_S */

/* Define if you have the resolv library (-lresolv).  */
/* #undef HAVE_LIBRESOLV */

/* Define if you have the sec library (-lsec).  */
/* #undef HAVE_LIBSEC */

/* Define if you have the security library (-lsecurity).  */
/* #undef HAVE_LIBSECURITY */

/* Define if you have the socket library (-lsocket).  */
/* #undef HAVE_LIBSOCKET */

#endif