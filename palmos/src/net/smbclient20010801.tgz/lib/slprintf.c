/* 
   Unix SMB/Netbios implementation.
   Version 1.9.
   snprintf replacement
   Copyright (C) Andrew Tridgell 1998
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "includes.h"


/* this is like vsnprintf but the 'n' limit does not include
   the terminating null. So if you have a 1024 byte buffer then
   pass 1023 for n */
int vslprintf(char *str, int n, char *format, va_list ap)
{
	int ret;
	ret = vsnprintf(str, n, format, ap);
	if (ret > n || ret < 0) {
		str[n] = 0;
		return -1;
	}
	str[ret] = 0;
	return ret;
}

#ifdef HAVE_STDARG_H
 int slprintf(char *str, int n, char *format, ...)
{
#else
 int slprintf(va_alist)
va_dcl
{
	char *str, *format;
	int n;
#endif
	va_list ap;  
	int ret;

#ifdef HAVE_STDARG_H
	va_start(ap, format);
#else
	va_start(ap);
	str = va_arg(ap,char *);
	n = va_arg(ap,int);
	format = va_arg(ap,char *);
#endif

#ifdef PALMOS
	//OG: vslprintf fails on PalmOS, so we use this until it's fixed
	ret = StrVPrintF(str, format, ap);
#else
	ret = vslprintf(str,n,format,ap);
#endif

	va_end(ap);
	return ret;
}

#ifndef PALMOS

 /* this is rather line fprintf, except that it works on a file descriptor
    and is limited to one pstring of output */
#ifdef HAVE_STDARG_H
 int fdprintf(int fd, char *format, ...)
{
#else
 int fdprintf(va_alist)
va_dcl
{
	int fd;
	char *format;
#endif
	va_list ap;  
	pstring str;

#ifdef HAVE_STDARG_H
	va_start(ap, format);
#else
	va_start(ap);
	fd = va_arg(ap,int);
	format = va_arg(ap,char *);
#endif
	str[0] = 0;

	vslprintf(str,sizeof(str),format,ap);
	va_end(ap);
	return write(fd, str, strlen(str));
}

#endif //PALMOS