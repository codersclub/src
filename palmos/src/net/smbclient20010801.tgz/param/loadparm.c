/* 
   Unix SMB/Netbios implementation.
   Version 1.9.
   Parameter loading functions
   Copyright (C) Karl Auer 1993-1998

   Largely re-written by Andrew Tridgell, September 1994
   
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.
   
   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.
   
   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/


//
// Very stripped-down version for PalmOS
// These options should ultimately be part of "User preferences"
// stored in the PrefsDB of the Palm and graphically editable.
//

#include "includes.h"

pstring global_scope = "";


char* lp_winbind_separator() {
	return "\\";
}

char* lp_interfaces() {
	return "";
}

int lp_readsize() {
	return 16*1024;
}

char* lp_panic_action () {
	return "";
}

char *lp_socket_address() {
	return "0.0.0.0";
}

char *lp_workgroup() {
	return "WORKGROUP";
}

char *lp_name_resolve_order() {
	//return "lmhosts host wins bcast";
	return "hosts";
}

BOOL lp_wins_support() {
	return False;
}


