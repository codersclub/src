/*-------------------------------------------------------------------
 *	Copyright (c) 1998, Machina Software, Inc., All Rights Reserved
 *-------------------------------------------------------------------
*/

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include "PalmPing.h"
#include "TcpIp.h"


// Our globals
FieldPtr HostFieldPtr;              // data entry field, IP or Host name
FieldPtr StatsFieldPtr;             // stats field
FieldPtr MsgFieldPtr;               // message field
ListPtr ServiceListPtr;             // list of services (e.g. echo, telnet)
Word HostFieldIndex;                // used to set the focus to the data entry field
FormPtr MainFormPtr;                // pointer to main form (ID_fPalmPing)
FormPtr StatsFormPtr;               // pointer to stats form (ID_fStats)
char errorBuffer[ 256 ];            // used to fill strings from resource file


// display the General Alert form, using the string id in the resource file
void PopupError( Word id )
{
    SysCopyStringResource ( errorBuffer, id );
    FrmCustomAlert( ID_fGeneralAlert, errorBuffer, NULL, NULL );
}



static void SetFieldText( FieldPtr field, char *string, Word length )
{
    FieldPtr f = field;
    VoidHand h;
    CharPtr s;

    if ( !( h = (VoidHand) FldGetTextHandle( f ) ) )
    {
        h = MemHandleNew( sizeof( Char ) * length );
    }

    s = MemHandleLock( h );

    StrCopy( s, string );

    MemHandleUnlock( h );
    FldSetTextHandle( f, (Handle) h );
    FldDrawField( f );
}


// Cycle through services, and report on availability
static Word PingCycle( void )
{
    CharPtr Host;
    Word itemNumber;
    CharPtr itemTextPtr;
    Char localBuffer[ 50 ];
    Word i, n, errID;

    // get user entry
    Host = FldGetTextPtr( HostFieldPtr );
    if ( !FldGetTextLength( HostFieldPtr ) )
    {
        PopupError( ID_ErrHostEntry );
        return ID_ErrHostEntry;
    }

    StrCopy( localBuffer, "Looking up host..." );
    SetFieldText( MsgFieldPtr, localBuffer, sizeof( localBuffer ) );

    *errorBuffer = 0;

    // Cycle through the services listed in the resource file.
    n = LstGetNumberOfItems( ServiceListPtr );
    for ( i = 0; i < n; i++ )
    {
        itemTextPtr = LstGetSelectionText ( ServiceListPtr, i );

        // use tcp (as opposed to udp)
        errID = Connect( Host, itemTextPtr, "tcp" );

        StrPrintF( localBuffer, "Checking %s\nfor %s", IPAddress, itemTextPtr );
        SetFieldText( MsgFieldPtr, localBuffer, sizeof( localBuffer ) );

        if ( errID == ID_ErrHostNotFound || errID == ID_ErrSocketOpen )
        {
            PopupError( errID );
            return errID;
        }
        else if ( errID )
        {
            StrPrintF( localBuffer, "%s not available\n", itemTextPtr );
        }
        else
        {
            StrPrintF( localBuffer, "%s OK\n", itemTextPtr );
        }
        StrCat( errorBuffer, localBuffer );
    }

    return 0;
}


static void GetStats( Word cmd )
{
    NetMasterPBType* s;
    Char IPString[ 16 ];

    error = NetLibMaster( AppNetRefnum, cmd, &Stats, MAXTIMEOUT );

    if ( error )
    {
        PopupError( ID_ErrStats );
        return;
    }

    s = &Stats;

    // format stats in errorBuffer for display.  Note: Limit of 11 lines max
    // for multiline field objects (per header file info).  Must use another UI
    // object (e.g. table) if more than 11 lines needed...
    switch ( cmd )
    {
        case netMasterIPStats:
            StrPrintF( errorBuffer, "ipInReceives:\t\t%ld\n"\
                                    "ipInHdrErrors:\t\t%ld\n"\
                                    "ipInAddrErrors:\t%ld\n"\
                                    "ipInDiscards:\t\t%ld\n"\
                                    "ipInDelivers:\t\t%ld\n"\
                                    "ipOutRequests:\t%ld\n"\
                                    "ipOutDiscards:\t\t%ld\n"\
                                    "ipOutNoRoutes:\t%ld\n",
                                    s->param.ipStats.ipInReceives,
                                    s->param.ipStats.ipInHdrErrors,
                                    s->param.ipStats.ipInAddrErrors,
                                    s->param.ipStats.ipInDiscards,
                                    s->param.ipStats.ipInDelivers,
                                    s->param.ipStats.ipOutRequests,
                                    s->param.ipStats.ipOutDiscards,
                                    s->param.ipStats.ipOutNoRoutes );
            break;

        case netMasterICMPStats:
            StrPrintF( errorBuffer, "icmpInMsgs:\t\t\t%ld\n"\
                                    "icmpInErrors:\t\t\t%ld\n"\
                                    "icmpInDestUnreachs:\t%ld\n"\
                                    "icmpInTimeExcds:\t\t%ld\n"\
                                    "icmpInEchos:\t\t\t%ld\n"\
                                    "icmpOutMsgs:\t\t\t%ld\n"\
                                    "icmpOutErrors:\t\t%ld\n"\
                                    "icmpOutDestUnreachs:\t%ld\n"\
                                    "icmpOutEchos:\t\t\t%ld\n",
                                    s->param.icmpStats.icmpInMsgs,
                                    s->param.icmpStats.icmpInErrors,
                                    s->param.icmpStats.icmpInDestUnreachs,
                                    s->param.icmpStats.icmpInTimeExcds,
                                    s->param.icmpStats.icmpInEchos,
                                    s->param.icmpStats.icmpOutMsgs,
                                    s->param.icmpStats.icmpOutErrors,
                                    s->param.icmpStats.icmpOutDestUnreachs,
                                    s->param.icmpStats.icmpOutEchos );
            break;

        case netMasterUDPStats:
            StrPrintF( errorBuffer, "udpInDatagrams:\t\t%ld\n"\
                                    "udpNoPorts:\t\t\t%ld\n"\
                                    "udpInErrors:\t\t\t%ld\n"\
                                    "udpOutDatagrams:\t\t%ld\n",
                                    s->param.udpStats.udpInDatagrams,
                                    s->param.udpStats.udpNoPorts,
                                    s->param.udpStats.udpInErrors,
                                    s->param.udpStats.udpOutDatagrams );
            break;

        case netMasterTCPStats:
            StrPrintF( errorBuffer, "In:\t\t\t%ld\n"\
                                    "Out:\t\t\t%ld\n"\
                                    "Retry:\t\t%5\n"\
                                    "Errors:\t\t%5\n",
                s->param.tcpStats.tcpInSegs,
                s->param.tcpStats.tcpOutSegs,
                s->param.tcpStats.tcpRetransSegs,
                s->param.tcpStats.tcpInErrs );
            break;

        case netMasterInterfaceStats:
            StrPrintF( errorBuffer, "inOctets\t\t\t%ld\n"\
                                    "inUcastPkts\t\t%ld\n"\
                                    "inNUcastPkts\t\t%ld\n"\
                                    "inDiscards\t\t%ld\n"\
                                    "inErrors\t\t\t%ld\n"\
                                    "outOctets\t\t%ld\n"\
                                    "outUcastPkts\t\t%ld\n"\
                                    "outNUcastPkts\t%ld\n"\
                                    "outDiscards\t\t%ld\n"\
                                    "outErrors\t\t\t%ld\n",
                                    s->param.interfaceStats.inOctets,
                                    s->param.interfaceStats.inUcastPkts,
                                    s->param.interfaceStats.inNUcastPkts,
                                    s->param.interfaceStats.inDiscards,
                                    s->param.interfaceStats.inErrors,
                                    s->param.interfaceStats.outOctets,
                                    s->param.interfaceStats.outUcastPkts,
                                    s->param.interfaceStats.outNUcastPkts,
                                    s->param.interfaceStats.outDiscards,
                                    s->param.interfaceStats.outErrors );
            break;

        case netMasterInterfaceInfo:
            StrPrintF( errorBuffer, "drvrName\t%s\n"\
                                    "mtu\t\t\t%d\n"\
                                    "speed\t\t%ld\n"\
                                    "ipAddr\t\t%s\n",
                                    s->param.interfaceInfo.drvrName,
                                    s->param.interfaceInfo.mtu,
                                    s->param.interfaceInfo.speed,
                                    ConvertAddressToString( IPString, s->param.interfaceInfo.ipAddr ) );
            break;
    }
}



static void ProcessMenuEvent( Word id )
{
    Char localBuffer[ 50 ];

    // Note:
    // In this version menu events are associated only with the ID_fPalmPing,
    // since it is the only one with a menu object
    //
    switch ( id )
    {
        case ID_mAbout:
            FrmAlert( ID_fAbout );
            break;

        case ID_mCut:
            FldCut( HostFieldPtr );
            break;

        case ID_mCopy:
            FldCopy( HostFieldPtr );
            break;

        case ID_mPaste:
            FldPaste( HostFieldPtr );
            break;

        case ID_mCopyIP:
            StrCopy( localBuffer, IPAddress );
            SetFieldText( MsgFieldPtr, localBuffer, sizeof( localBuffer ) );
            FldSetSelection ( MsgFieldPtr, 0, FldGetTextLength( MsgFieldPtr ) );
            FldCopy( MsgFieldPtr );
            FldSetSelection ( MsgFieldPtr, 0, 0 );
            break;

        case ID_mKbd:
            SysKeyboardDialog( kbdDefault );
            break;

        case ID_mTCP:
            GetStats( netMasterTCPStats );
            FrmPopupForm( ID_fStats );
            break;

        case ID_mIP:
            GetStats( netMasterIPStats );
            FrmPopupForm( ID_fStats );
            break;

        case ID_mUDP:
            GetStats( netMasterUDPStats );
            FrmPopupForm( ID_fStats );
            break;

        case ID_mICMP:
            GetStats( netMasterICMPStats );
            FrmPopupForm( ID_fStats );
            break;

        case ID_mIINFO:
            GetStats( netMasterInterfaceInfo );
            FrmPopupForm( ID_fStats );
            break;

        case ID_mISTATS:
            GetStats( netMasterInterfaceStats );
            FrmPopupForm( ID_fStats );
            break;

        default:
            break;
    }
}


static void EventLoop( void )
{
    short i;
    short err;
    int formID;
    FormPtr form;
    EventType event;

    do
    {
        EvtGetEvent( &event, 200 );

        if ( SysHandleEvent( &event ) )
        {
            continue;
        }

        if ( MenuHandleEvent((void *)0, &event, &err ) )
        {
            continue;
        }

        switch ( event.eType )
        {
            case frmLoadEvent:
                formID = event.data.frmLoad.formID;
                switch ( formID )
                {
                    case ID_fPalmPing:
                        form = MainFormPtr ? MainFormPtr : FrmInitForm( ID_fPalmPing );
                        MainFormPtr = form;
                        break;

                    case ID_fStats:
                        form = StatsFormPtr ? StatsFormPtr : FrmInitForm( ID_fStats );
                        StatsFormPtr = form;
                        break;
                }
                FrmSetActiveForm( form );
                break;

            case frmOpenEvent:
                form = FrmGetActiveForm();
                formID = event.data.frmLoad.formID;
                switch ( formID )
                {
                    case ID_fPalmPing:
                        if ( HostFieldPtr == NULL )
                        {
                            HostFieldPtr = FrmGetObjectPtr( form, FrmGetObjectIndex( form, ID_fldHost ));
                            MsgFieldPtr = FrmGetObjectPtr( form, FrmGetObjectIndex( form, ID_fldMessage ));
                            ServiceListPtr = FrmGetObjectPtr( form, FrmGetObjectIndex( form, ID_lItem ));
                            HostFieldIndex = FrmGetObjectIndex( form, ID_fldHost );
                        }
                        FrmDrawForm( form );
                        FrmSetFocus( form, HostFieldIndex );
                        break;

                    case ID_fStats:
                        if ( StatsFieldPtr == NULL )
                        {
                            StatsFieldPtr = FrmGetObjectPtr( form, FrmGetObjectIndex( form, ID_fldStats ));
                        }
                        FrmDrawForm( form );
                        SetFieldText( StatsFieldPtr, errorBuffer, sizeof( errorBuffer ) );
                        break;
                }
                break;

            case ctlSelectEvent:
                switch ( event.data.ctlEnter.controlID )
                {
                    // appears only in main form
                    case ID_bPing:
                        if ( !PingCycle() )
                        {
                            FrmCustomAlert( ID_fCycleStats, errorBuffer, NULL, NULL );
                        }
                        break;

                    // appears only in stats form
                    case ID_bOK:
                        SetFieldText( StatsFieldPtr, " ", 2 );
                        FrmEraseForm( StatsFormPtr );
                        FrmSetActiveForm( MainFormPtr );
                        break;

                    default:
                        FrmHandleEvent( FrmGetActiveForm(), &event );
                        break;
                }
                break;

            case menuEvent:
                ProcessMenuEvent( event.data.menu.itemID );
                break;

            case nilEvent:
                break;

            default:
                FrmHandleEvent( FrmGetActiveForm(), &event );
                break;
        }

    }
    while(event.eType != appStopEvent);
}


static int StartApplication( void )
{
    int err;

    err = CheckForNetwork();

    if ( err )
    {
        return err;
    }

    // make sure these are set, whether the compiler initializes globals to
    // zero or not...
    MainFormPtr = NULL;
    StatsFormPtr = NULL;
    HostFieldPtr = NULL;
    ServiceListPtr = NULL;

    // start up the main form
    FrmGotoForm( ID_fPalmPing );
    return 0;
}


static void StopApplication( void )
{
    NetLibClose( AppNetRefnum, false );
    FrmCloseAllForms();
}


DWord  PilotMain( Word cmd, Ptr cmdPBP, Word launchFlags )
{
    int errApp;
    DWord RomVersion;

    // Make sure we are running OS 2.0
    error = FtrGet( sysFtrCreator, sysFtrNumROMVersion, &RomVersion );
    if ( error )
    {
        return error;
    }
    if ( !(RomVersion & 0x02000000 ) )
    {
        return ftrErrROMBased;
    }

    if ( cmd == sysAppLaunchCmdNormalLaunch )
    {
        if  ( ( errApp = StartApplication() ) )
        {
            return errApp;
        }

        EventLoop();
        StopApplication ();
    }

    return 0;
}


