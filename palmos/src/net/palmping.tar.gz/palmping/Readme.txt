PalmPing V1.0.0:

The program provides an example of how to use the PalmOS network API.  Given a host name or an IP address, the program will cycle through several services (e.g. echo), detecting the presence of that service at the given host.  Network statistics are also shown, using the PalmOS statistics queries.  Source code is included and should give you a start on PalmPilot network programming.  The software was created and compiled on a Windows 95 machine, using the gnu compiler and utilities.

Files included are:

PalmPing.prc	PalmPilot module

Makefile		Makefile for gnu
PalmPing.c		The main source module
PalmPing.h		The main header file
TcpIp.c		Routines to interface with the PalmOS network API
TcpIp.h		Header for the above
PalmPing.bmp	Our icon bitmap
PalmPing.rcp	Our resource file

You can reach us at http://machinasoftware.com...

  