/*-------------------------------------------------------------------
 *	Copyright (c) 1998, Machina Software, Inc., All Rights Reserved
 *-------------------------------------------------------------------
*/

#ifndef PALMPINGTCP_H
#define PALMPINGTCP_H

#include <Core/System/Unix/sys_socket.h>

#define MAXTIMEOUT      (10 * sysTicksPerSecond)
#ifndef MAXHOSTNAMELEN
#define MAXHOSTNAMELEN	64
#endif

// externs
extern Word AppNetRefnum;
extern long AppNetTimeout;
extern Err errno;
extern Err error;
extern char HostName[];
extern char IPAddress[];
extern NetHostInfoPtr HostInfoPtr;
extern NetHostInfoBufType HostInfoBuffer;
extern NetSocketRef SocketNumber;
extern NetSocketAddrINType Destination;
extern Word Port;
extern NetIPAddr DestinationIPAddress;
extern NetServInfoBufType ServInfoBuffer;
extern unsigned char ReceiveBuffer[];
extern NetSocketAddrType Sender;
extern Word SenderLength;
extern DWord SavedNetSettings;
extern NetMasterPBType Stats;


// prototypes
int CheckForNetwork( void );
Word GetHost( CharPtr lookup );
Word Connect( CharPtr name, CharPtr service, CharPtr protocol );
void Disconnect( void );
Err SendData( VoidPtr data, Word length );
Err ReceiveData( void );
CharPtr ConvertAddressToString( CharPtr string, NetIPAddr address );

#endif // PALMPINGTCP_H

// eof

