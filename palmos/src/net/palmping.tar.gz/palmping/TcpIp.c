/*-------------------------------------------------------------------
 *	Copyright (c) 1998, Machina Software, Inc., All Rights Reserved
 *-------------------------------------------------------------------
*/

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include "PalmPing.h"
#include "TcpIp.h"



// Global variables required by Pilot API
Word AppNetRefnum;
long AppNetTimeout = MAXTIMEOUT;
Err errno;

// Our globals
Err error;                          // global error variable
char HostName[ MAXHOSTNAMELEN ];    // string to store host name
char IPAddress[ 16 ];               // string to store IP Address
NetHostInfoBufType HostInfoBuffer;
NetSocketRef SocketNumber;
NetSocketAddrINType Destination;
Word Port;
NetIPAddr DestinationIPAddress;
NetServInfoBufType ServInfoBuffer;
unsigned char ReceiveBuffer[ 256 ];      // only used for echo/finger
NetSocketAddrType Sender;
Word SenderLength;

// statistics
DWord SavedNetSettings;  // to store previous settings
NetMasterPBType Stats;


int CheckForNetwork( void )
{
    Word err;
    Word ifErrs;
//    Word settingSize = sizeof( DWord );
//    DWord TraceNetSettings;

    if ( ( err = SysLibFind( "Net.lib", &AppNetRefnum ) ) )
    {
        return ID_ErrNetLib;
    }

//    if ( ( error = NetLibSettingGet( AppNetRefnum, netSettingTraceBits, &SavedNetSettings, &settingSize ) ) )
//    {
//        return error;
//    }

    // set all tracing options on
//    TraceNetSettings =     netTracingErrors		    // record errors
//                         | netTracingMsgs			// record messages
//                         | netTracingPkts			// record packets I/O
//                         | netTracingFuncs		    // record function flow
//                         | netTracingAppMsgs		// record application messages
//                         ;

//    if ( ( error = NetLibSettingSet( AppNetRefnum, netSettingTraceBits, &TraceNetSettings, settingSize ) ) )
//    {
//        return error;
//    }

    err = NetLibOpen( AppNetRefnum, &ifErrs );
    if ( err == netErrAlreadyOpen )
    {
        return 0;
    }

    if ( err || ifErrs )
    {
        NetLibClose( AppNetRefnum, false );
        return ID_ErrNetLibOpen;
    }

    return 0;
}

// lookup the host name or ip address, given a lookup name.
// The IP Address is stored in IPAddress[], and the host name in HostName[]
// Return 0 for no errors.
Word GetHost( CharPtr lookup )
{
    NetHostInfoPtr HostInfoPtr;
    NetIPAddr* temp;

    // got an IP address?
	if ( ( Destination.addr = NetLibAddrAToIN( AppNetRefnum, lookup ) ) != -1 )
    {
        HostInfoPtr = NetLibGetHostByAddr( AppNetRefnum,
                                (BytePtr)&Destination.addr,
                                sizeof( Destination.addr),
                                netSocketAddrINET,
                                &HostInfoBuffer,
                                MAXTIMEOUT, &error );
        if ( HostInfoPtr )
        {
            StrCopy( HostName, HostInfoBuffer.hostInfo.nameP );
            StrCopy( IPAddress, lookup );
        }
        else
        {
            return 1;
        }
	}
    else    // got a host name
    {
        HostInfoPtr = NetLibGetHostByName( AppNetRefnum,
                            lookup, &HostInfoBuffer,
                            MAXTIMEOUT,
                            &error );

		if ( HostInfoPtr )
        {
            temp = (NetIPAddr*)HostInfoBuffer.hostInfo.addrListP[ 0 ];
            if ( *temp == 0 )
            {
                ++temp;
            }
            NetLibAddrINToA( AppNetRefnum, *temp, IPAddress );
            StrCopy( HostName, lookup );
		}
        else
        {
            return 1;
		}
	}

    return 0;
}


void Disconnect( void )
{
    if ( SocketNumber != 0 )
    {
        NetLibSocketClose ( AppNetRefnum, SocketNumber, -1, &error );
        SocketNumber = 0;
    }
}


// create a socket and connect to name (either ip address or host name)
// and service. Return 0 if no error.
Word Connect( CharPtr name, CharPtr service, CharPtr protocol )
{
    // make sure any prior socket is closed
    Disconnect();

    if ( GetHost( name ) )
    {
        return ID_ErrHostNotFound;
    }

    NetLibGetServByName( AppNetRefnum, service, protocol , &ServInfoBuffer,
                              MAXTIMEOUT,
                              &error );

    SocketNumber = NetLibSocketOpen( AppNetRefnum,
                                     netSocketAddrINET,
                                     netSocketTypeStream,
                                     htons( 6 ), // ignored...
                                     MAXTIMEOUT,
                                     &error );

    if ( SocketNumber == 0 )
    {
        return ID_ErrSocketOpen;
    }

    // attempt to connect socket to destination address
	bzero((char *)&Destination, sizeof( Destination ) );
    Destination.family = AF_INET;
    Destination.port = ServInfoBuffer.servInfo.port;
    Destination.addr = NetLibAddrAToIN( AppNetRefnum, IPAddress );

    if ( NetLibSocketConnect( AppNetRefnum,
                              SocketNumber,
                              (NetSocketAddrType*)&Destination,
                              sizeof( Destination ),
                              MAXTIMEOUT,
                              &error )  == -1 )
    {
        return ID_ErrSocketConnect;
    }

    return 0;
}



Err SendData( VoidPtr data, Word length )
{
    Err serr;

    if ( !SocketNumber )
    {
        return 1;
    }

    serr = NetLibSend( AppNetRefnum, SocketNumber, data, length,
                          netIOFlagDontRoute,  // flags
                          &Destination,
                          sizeof( Destination),
                          MAXTIMEOUT,
                          &error );

    if ( serr == 0 )
    {
        return netErrSocketNotOpen;
    }
    else if ( serr == -1 )
    {
        return error;
    }
    else
    {
        return 0;
    }
}


// receive data into the global ReceiveBuffer[]
Err ReceiveData( void )
{
    Err serr;

    serr = NetLibReceive( AppNetRefnum,
                          SocketNumber,
                          ReceiveBuffer,
                          sizeof( ReceiveBuffer ),
                          0, // flags
                          &Sender,
                          &SenderLength,
                          MAXTIMEOUT,
                          &error );

    if ( serr == 0 )
    {
        return netErrSocketNotOpen;
    }
    else if ( serr == -1 )
    {
        return error;
    }
    else
    {
        return 0;
    }
}


CharPtr ConvertAddressToString( CharPtr string, NetIPAddr address )
{
    NetLibAddrINToA( AppNetRefnum, address, string );
    return string;
}

