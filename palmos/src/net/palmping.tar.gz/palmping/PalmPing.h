#define ID_fPalmPing        1001
#define ID_fAbout           1002
#define ID_fGeneralAlert    1003
#define ID_fStats           1007
#define ID_fCycleStats      1008

#define menuPalmPing        2000
#define labelHost            500
#define labelService         501

#define ID_fldHost          1110
#define ID_fldMessage       1111
#define ID_fldStats         1113

#define ID_bPing            1200
#define ID_bOK              1201

#define ID_mAbout           5001
#define ID_mCut             5002
#define ID_mCopy            5003
#define ID_mPaste           5004
#define ID_mCopyIP          5005
#define ID_mKbd             5006

#define ID_mTCP             5010
#define ID_mIP              5011
#define ID_mUDP             5012
#define ID_mICMP            5013
#define ID_mIINFO           5014
#define ID_mISTATS          5015

#define ID_pItem           1500
#define ID_lItem            1501

#define helpAbout           5001

#define ID_ErrUnknown        100
#define ID_ErrHostEntry      101
#define ID_ErrStats          102
#define ID_ErrNetLib         103
#define ID_ErrNetLibOpen     104
#define ID_ErrHostNotFound   105
#define ID_ErrSocketOpen     106
#define ID_ErrSocketConnect  107
#define ID_ErrSendData       108
#define ID_ErrRcvData        109

