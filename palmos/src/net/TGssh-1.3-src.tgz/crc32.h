unsigned long do_crc( unsigned char *data, unsigned long len );
