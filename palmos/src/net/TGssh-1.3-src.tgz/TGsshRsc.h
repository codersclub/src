#define MainForm 1000
#define TitleLbl 1001
#define VersionFld 1002
#define LibVersionFld 1003
#define HostLbl 1004
#define HostFld 1005
#define UserLbl 1006
#define UserFld 1007
#define PassLbl 1008
#define PassFld 1009
#define hidePwBtn 1010
#define startNetBtn 1011

#define MainMenu 1050
#define EditMenuUndo 1051
#define EditMenuCut 1052
#define EditMenuCopy 1053
#define EditMenuPaste 1054
#define EditMenuSelectAll 1055
#define EditMenuKeyboard 1056
#define EditMenuGraffiti 1057
#define loadMenuBase 1060
#define loadMenu1 1061
#define loadMenu2 1062
#define loadMenu3 1063
#define loadMenu4 1064
#define loadMenu5 1065
#define saveMenuBase 1070
#define saveMenu1 1071
#define saveMenu2 1072
#define saveMenu3 1073
#define saveMenu4 1074
#define saveMenu5 1075

#define AboutForm 1500

#define sshProgressForm 1100
#define ProgMsgField 1101
#define progCancelBtn 1102

#define alertErrorDismiss 2000
#define alertInfoDismiss 2100
