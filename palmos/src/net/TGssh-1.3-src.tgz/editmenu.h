#ifndef EDITMENU_H
#define EDITMENU_H

/* Handler for the standard Edit menu */
Boolean EditMenuHandleEvent(Word menuitem, FormPtr frm);

#endif /* EDITMENU_H */
