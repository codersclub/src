/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmprefsp.c
//
// handle the polling prefs form of yanoff
// Matthias Jordan, 9-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/DateTime.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefsp.h"
#include "prefs.h"
#include "ngroup.h"
#include "subscrdb.h"
#include "network.h"
#include "lang.h"



static UInt MakeSelection(void)
{
	if (!NGNewsgroupOpen())
	{
		// selection: "all servers", "server 1", "server 2", ...
		if (pprefs.poll_from == poll_from_all_servers)
		{
			return 0;
		}
		else if (pprefs.poll_from == poll_from_one_server)
		{
			return pprefs.poll_server;
		}
		else
		{
			return 0;
		}
	}
	else
	{
		// selection: "active group", "all servers", "server 1", ...
		if (pprefs.poll_from == poll_from_active_group)
		{
			return 0;
		}
		else if (pprefs.poll_from == poll_from_all_servers)
		{
			return 1;
		}
		else if (pprefs.poll_from == poll_from_one_server)
		{
			return pprefs.poll_server + 1;
		}
	}
	return 0;
} /* MakeSelection */




static int SavePollPrefs(int to_prefs)
{
	UInt from;

	pprefs.poll_what = LstGetSelection(GetObjectPtr(lstPrefsPollWhat));
	pprefs.poll_news = CtlGetValue(GetObjectPtr(chkPrefsPollNews));
	pprefs.post_news = CtlGetValue(GetObjectPtr(chkPrefsPollPostNews));
	pprefs.post_email = CtlGetValue(GetObjectPtr(chkPrefsPollPosteMail));
	from = LstGetSelection(GetObjectPtr(lstPrefsPollFrom));
	
	if (!NGNewsgroupOpen())
	{
		// selection: "all servers", "server 1", "server 2", ...
		if (from == 0)
		{
			pprefs.poll_from = poll_from_all_servers;
			pprefs.poll_server = 0;
		}
		else
		{
			pprefs.poll_from = poll_from_one_server;
			pprefs.poll_server = from;
		}
	}
	else
	{
		// selection: "active group", "all servers", "server 1", ...
		if (from == 0)
		{
			pprefs.poll_from = poll_from_active_group;
			pprefs.poll_server = 0;
		}
		else if (from == 1)
		{
			pprefs.poll_from = poll_from_all_servers;
			pprefs.poll_server = 0;
		}
		else
		{
			pprefs.poll_from = poll_from_one_server;
			pprefs.poll_server = from - 1;
		}
	}

	if (to_prefs)
	{
		if (NGNewsgroupOpen())
		{
 			PrSavePollPrefs(pprefs_ng, &pprefs);
		}
		else
		{
			PrSavePollPrefs(pprefs_all, &pprefs);
		}
	}
	return 0;
} /* SavePollPrefs */



static void UpdateNewsPrefsDisplay(void)
{
	ControlPtr ctl;
	int show;
	FormPtr form;
	
	form = FrmGetActiveForm();
	ctl = GetObjectPtr(chkPrefsPollNews);
	show = CtlGetValue(ctl);

	if (show)
	{
		FrmShowObject(form, FrmGetObjectIndex(form, lblPrefsPollGet));
		FrmShowObject(form, FrmGetObjectIndex(form, trgPrefsPollWhat));
		FrmShowObject(form, FrmGetObjectIndex(form, lblPrefsPollFrom));
		FrmShowObject(form, FrmGetObjectIndex(form, trgPrefsPollFrom));
	}
	else
	{
		FrmHideObject(form, FrmGetObjectIndex(form, lblPrefsPollGet));
		FrmHideObject(form, FrmGetObjectIndex(form, trgPrefsPollWhat));
		FrmHideObject(form, FrmGetObjectIndex(form, lblPrefsPollFrom));
		FrmHideObject(form, FrmGetObjectIndex(form, trgPrefsPollFrom));
	}
	RefreshForm();
} /* UpdateNewsPrefsDisplay */



static void InitForm(void)
{
	ControlPtr ctl;
	ListPtr lst;
	DBServerNum list_count;

	if (NGNewsgroupOpen())
	{
		FrmCopyTitle(FrmGetActiveForm(), "Groups Polling Prefs");
		PrGetPollPrefs(pprefs_ng, &pprefs);
	}
	else
	{
		FrmCopyTitle(FrmGetActiveForm(), "General Polling Prefs");
		PrGetPollPrefs(pprefs_all, &pprefs);
	}

	ctl = GetObjectPtr(chkPrefsPollNews);
	CtlSetValue(ctl, pprefs.poll_news);

	ctl = GetObjectPtr(chkPrefsPollPostNews);
	CtlSetValue(ctl, pprefs.post_news);

	ctl = GetObjectPtr(chkPrefsPollPosteMail);
	CtlSetValue(ctl, pprefs.post_email);

	ctl = GetObjectPtr(trgPrefsPollWhat);
	lst = GetObjectPtr(lstPrefsPollWhat);
	LstSetSelection(lst, pprefs.poll_what);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	servers = SrvGetServerList(srv_list_mode_poll, &list_count);
	ctl = GetObjectPtr(trgPrefsPollFrom);
	lst = GetObjectPtr(lstPrefsPollFrom);
	LstSetListChoices(lst, servers, list_count);
	LstSetHeight(lst, min(list_count, 5));
	LstSetSelection(lst, MakeSelection());
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));
	UpdateNewsPrefsDisplay();
} /* InitForm */




Boolean HandlePrefsPoll(EventPtr event)
{
    int handled = 0;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitForm();
            RefreshForm();
            handled = 1;
            break;
        }
           
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case chkPrefsPollNews:
				{
					UpdateNewsPrefsDisplay();
					break;
				}

				case btnCancel:
				{
					SrvFreeServerList(servers);
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					res = SavePollPrefs(1);
					SrvFreeServerList(servers);
					if (!res)
					{
						NPExitForm();
					}
					handled = 1;
					break;
				}
				
				case btnPrefsPollSavePoll:
				case btnPrefsPollPoll:
				{
					// Save Settings if user wants that. Poll in either case
					res = SavePollPrefs((event->data.ctlSelect.controlID == btnPrefsPollSavePoll));
					SrvFreeServerList(servers);
					if (!res)
					{
						NPExitForm();
						NPInvokePoll(pollNormally, 0);
					}
					handled = 1;
					break;
				}

				default:
			}
			break;
		}
		
        default:
		
    }
    return handled;
} /* HandlePrefsPoll */




