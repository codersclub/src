/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// general.c
//
// general routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/StringMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "lang.h"
#include "prefs.h"
#include "ngroup.h"
#include "frmpost.h"
#include "scoring.h"
#include "frmart.h"


char wdays[7][4] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};
char mons[12][4] = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul",
					"Aug", "Sep", "Oct", "Nov", "Dec"};

char bad_characters[] = {"()/\\@!\"�$%&=?�}][{,;:#'+*~<>| \n\r"};


DWord romVersion;	
char **servers; // needed for the server popup lists


//
//
// Opens database by name. If is doesn�t exist: create it!
//
// returns 0 in case of error
// returns DmOpenRef > 0 in case of success
//

DmOpenRef NPOpenDB(char *name)
{
    LocalID lid;
    Err err;
    DmOpenRef db;

    lid = DmFindDatabase(0, name);
    if (lid == 0)
    {
        // not found - so create it
        err = DmCreateDatabase(0, name, CREATOR, TYPE, 0);
        if (err)
        {
            return 0;
        }
        lid = DmFindDatabase(0, name);
    }
    db = DmOpenDatabase(0, lid, dmModeReadWrite);
    return db;
} /* NPOpenDB */





//
//
// Allocate memory for a string and copy a default value into it.
// The destination pointer has to point to a valid string or
// to NULL
//

char *StrInit(char **str, char *value)
{
	if (*str != NULL)
	{
		MemPtrFree(*str);
	}
	*str = (char*) MemPtrNew(StrLen(value)+1);
	if (*str != NULL)
	{
		StrCopy(*str, value);
	}
	return *str;
} /* StrInit */





//
//
// Checks whether there is a letter in a string
// Used to determine if address is dotted quad or FQDN
//

int StrHasLetter(char *c)
{
    char *testfield;
    VoidHand h;
    int res = 0;

    h = MemHandleNew(StrLen(c) + 1);
    if (h == 0)
    {
        return 0;
    }
    testfield = (char *) MemHandleLock(h);
    StrToLower(testfield, c);
    while (*testfield && !res)
    {
        if ((*testfield >= 'a') && (*testfield <= 'z'))
        {
            res = 1;
        }
        testfield++;
    }
    MemHandleUnlock(h);
    MemHandleFree(h);
    return res;
} /* StrHasLetter */





//
//
// Free chunk based on pointer
//

void FreePointer(Ptr p)
{

    if (p == NULL)
        return;
	MemPtrFree(p);
} /* FreePointer */





//
//
// Common UI routines
//
//


VoidPtr GetObjectPtr(Word objectID)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm();
	return (FrmGetObjectPtr (frm, FrmGetObjectIndex(frm, objectID)));
} /* GetObjectPtr */



//
//
// Get pointer to field contents.
// 
// If fieldname is not NULL, the field has to have some contents.
// If it doesn't an alert is popped up.
//
// Returns: NULL in case of empty field
// Returns: pointer to contents in case of success.
//


char *GetFormParameter(char *fieldname, Word id)
{
    FieldPtr field;
    FormPtr form;
    char *contents;

    form = FrmGetActiveForm();
    field = FrmGetObjectPtr(form, FrmGetObjectIndex(form, id));
    contents = FldGetTextPtr(field);
    if (!FldGetTextLength(field))
    {
		if (fieldname != NULL)
		{
	        FrmCustomAlert(alertID_dum, yf_field_empty, "\n", fieldname);
	    }
    }
    return contents;
} /* GetFormParameter */





void RefreshForm(void)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm();
    FrmDrawForm(frm);
} /* RefreshForm */



//
//  Routines for the forms stack
//  formstacktop is the index of the form that is currently active
//

typedef struct fstackitem
{
	Word id;
	int updatecode;
} fstackitem_t;


#define FORMSTACKMAX 10
fstackitem_t formstack[FORMSTACKMAX];
int formstacktop; 




static void MakeJumpBackSane(void)
{
	struct articledb_item a;

	if (ystate.currently_writing_article != -1)
	{
		if (ystate.currently_writing_article != (ArtArticlesCount() - 1))
		{
			ystate.currently_writing_article = -1;
		}
		
		if (NGOpenNewsgroupByPos(0) != NULL)
		{
			if (NGArticlesCount() == 0)
			{
				// Last saved article has been abandoned
				ystate.currently_writing_article = -1;
			}
			NGCloseNewsgroup();
		}
		else
		{
			ystate.currently_writing_article = -1;
		}
	}

	if ((ystate.last_ng != -1) && NGOpenNewsgroupByPos(ystate.last_ng) == NULL)
	{
		// Newsgroup no longer present
		ystate.last_ng = -1;
		ystate.last_art = -1;
	}
	else
	{
		if ((ystate.last_art != -1) && NGReadArticle(ystate.last_art, &a) == 1)
		{
			// Article no longer present
			ystate.last_art = -1;
			ystate.currently_writing_article = -1;
		}
	}
} /* MakeJumpBackSane */



static void PushFormStackItem(Word formID)
{
	formstack[++formstacktop].id = formID;
	formstack[formstacktop].updatecode = -1;
} /* PushFormStackItem */


void NPInitFormStack(Word formID)
{
    formstacktop = 0;
    formstack[formstacktop].id = formID;
    formstack[formstacktop].updatecode = -1;

	MakeJumpBackSane();

	if (ystate.last_ng != -1)
	{
		PushFormStackItem(frmArtList);
		active_ng_num = ystate.last_ng;
	}
	if (ystate.last_art != -1)
	{
		PushFormStackItem(frmArticle);
		active_article = ystate.last_art;	
	}

	FrmGotoForm(formstack[formstacktop].id);
} /* NPInitFormStack */



void NPGotoForm(Word formID)
{
	if (formstacktop < (FORMSTACKMAX - 1))
	{
		PushFormStackItem(formID);
		FrmPopupForm(formID);
	}
	else
	{
		FrmCustomAlert(alertID_dum, yf_fs_overflow, " ", " ");
	}
} /* NPGotoForm */


void NPExitForm(void)
{
	Word nextID;
	
	if (formstacktop > 0) // don't let the stack get empty
	{
		formstacktop--;
		nextID = formstack[formstacktop].id;
		if (FrmGetFormPtr(nextID) == NULL)
		{
			FrmGotoForm(nextID);
		}
		else
		{
			if (formstack[formstacktop].updatecode != -1)
			{
				FrmUpdateForm(nextID, formstack[formstacktop].updatecode);
				formstack[formstacktop].updatecode = -1;
			}
			FrmReturnToForm(nextID);
		}
	}
	else
	{
		FrmCustomAlert(alertID_dum, yf_fs_underrun, " ", " ");
	}
} /* NPExitForm */


Word NPGetTopForm(void)
{
	return formstack[formstacktop].id;
} /* NPGetTopForm */


void NPUpdateForm(Word formID, int code)
{
	int i = 0;
	
	while (i <= formstacktop)
	{
		// only set update code if the form doesn't have only one
		if ((formstack[i].id == formID) && (formstack[i].updatecode == -1))
		{
			formstack[i].updatecode = code;
			i = formstacktop + 1; // exit loop
		}
		i++;
	}
} /* NPUpdateForm */











static void MakeNewNGName(char *new, char *ng, SWord len)
{
	SWord act = 0;

	while (*ng && (act < len))
	{
		*new++ = *ng++;
		act++;
		while (*ng && (*ng != '.'))
		{
			ng++;
		}
		if (*ng == '.')
		{
			*new++ = *ng++;
			act++;
		}
	}
	*new = 0;
} /* MakeNewNGName */



void NPSetFormTitle(FormPtr frm, char *title, int is_ng)
{
	char dum[41];
	RectangleType r;
	SWord width, len;
	Boolean fits = 0;
	FontID font;
	
	FrmGetFormBounds(frm, &r);
	width = r.extent.x - 3;
	len = StrLen(title);
	font = FntSetFont(boldFont);
	FntCharsInWidth(title, &width, &len, &fits);
	if (!fits)
	{
		len = min(len, 40);
		if (is_ng)
		{
			MakeNewNGName(dum, title, len);
		}
		else
		{
			StrNCopy(dum, title, len); dum[len] = 0;
		}
		FrmCopyTitle(frm, dum);
	}
	else
	{
		StrNCopy(dum, title, 40); dum[40] = 0;
		FrmCopyTitle(frm, title);
	}
	FntSetFont(font);
} /* NPSetFormTitle */




Word GetNewTopline(Word currenttop, Word linestotal, 
	Word linesdisplayed, Short scllines)
{
	if (linestotal < linesdisplayed)
	{
		return currenttop;
	}
	if ((scllines < 0) && (currenttop < -scllines)) 
	{
		// "new_top < 0" for Word new_top (that cannot be < 0)
		return 0;
	}
	if ((scllines > 0) && ((currenttop + scllines) > (linestotal - linesdisplayed)))
	{
		return linestotal - linesdisplayed;
	}
	else
	{
		return currenttop + scllines;
	}
} /* GetNewTopline */




//
//
// Needed for table inits
//

void DrawItemString(CharPtr dum, short x, short y, short width)
{
	Int titlelen;
	short titlewidth;
	Boolean stringfit;
	
	titlewidth = width;
	titlelen = StrLen(dum);
	FntCharsInWidth(dum, &titlewidth, &titlelen, &stringfit);
	if (stringfit)
	{
		WinDrawChars(dum, titlelen, x, y);
	}
	else
	{
		width -= (FntCharWidth('.') * 3);
		while (titlewidth > width)
		{
			titlewidth -= FntCharWidth(dum[--titlelen]);
		}
		WinDrawChars(dum, titlelen, x, y);
		x += titlewidth;
		WinDrawChars("..", 2, x, y);
	}
} /* DrawItemString */




//
//
// Needed for table inits 2
//

void MakeItemString(CharPtr dum, short width, char *out)
{
	Int titlelen;
	short titlewidth;
	Boolean stringfit;
	
	titlewidth = width;
	titlelen = StrLen(dum);
	FntCharsInWidth(dum, &titlewidth, &titlelen, &stringfit);
	if (stringfit)
	{
		StrCopy(out, dum);
	}
	else
	{
		while (--titlelen)
		{
			*out++ = *dum++;
		}
		*out = 0;
		StrCat(out, "..");
	}
} /* MakeItemString */



//
//
//  Handle PenDownEvent: Probably the user wants to drag the column
//  separation in the article view around... Handle these events.
//


#define epsilon 5

void ArtListMoveColSep(Word id, Word col, EventPtr event, UInt *sepx)
{
	int itemx;
	TablePtr tbl;
	RectangleType ri, r;
	
	tbl = GetObjectPtr(id);
	TblGetBounds(tbl, &r);
	TblGetItemBounds(tbl, 0, col, &ri);

	itemx = event->screenX - ri.topLeft.x;
	if (((*sepx + epsilon) > itemx) 
		&& (*sepx < (itemx + epsilon)))
	{
		WinInvertLine(itemx + ri.topLeft.x, FIRSTY, itemx + ri.topLeft.x, r.topLeft.y + r.extent.y);
		do
		{
			EvtGetEvent(event, 2);
		    if (!SysHandleEvent(event))
		    {
				if (event->eType == penMoveEvent)
				{
					WinInvertLine(itemx + ri.topLeft.x, FIRSTY, itemx + ri.topLeft.x, r.topLeft.y + r.extent.y);
					itemx = event->screenX - ri.topLeft.x;
					if (event->screenX < ri.topLeft.x)
					{
						itemx = 0;
					}
					if (event->screenX > (ri.topLeft.x + ri.extent.x))
					{
						itemx = ri.extent.x;
					}
					WinInvertLine(itemx + ri.topLeft.x, FIRSTY, itemx + ri.topLeft.x, r.topLeft.y + r.extent.y);
				}
				else
				{
					FrmDispatchEvent(event);
				}
			}
		}
		while (event->eType != penUpEvent);
		WinInvertLine(itemx + ri.topLeft.x, FIRSTY, itemx + ri.topLeft.x, r.topLeft.y + r.extent.y);
		FrmUpdateForm(id, 1);
		*sepx = itemx;
	}
} /* ArtListMoveColSep */




int GetFormValue(char *name, Word id, UInt *val)
{
	char *str;
	UInt dum;
	
	str = GetFormParameter(name, id);
	if (str == NULL)
	{
		return 1;
	}
	dum = StrAToI(str);
	if (dum != 0)
	{
		*val = dum;
		return 0;
	}
	return 1;
} /* GetFormValue */




int GetVariableField(char *name, Word id, char **dest)
{
	char *str;
	VoidHand h;

	str = GetFormParameter(name, id);
	if (*str == 0)
	{
		// Field is empty
		if (name != NULL)
		{
			// Field must not be empty
			return 1;	
		}
	}
	MemPtrFree(*dest);
	h = MemHandleNew(StrLen(str) + 1);
	if (h == 0)
	{
		return 3;
	}
	*dest = (char *) MemHandleLock(h);
	StrCopy(*dest, str);
	return 0;
} /* GetVariableField */


void SetFocus(Word id)
{
	FormPtr frm;
	
	frm = FrmGetActiveForm();
	FrmSetFocus(frm, FrmGetObjectIndex(frm, id));
} /* SetFocus */



Word CountLF(char *str, Word *len)
{
	char *begin;
	Word lf = 0;
	
	begin = str;
	while (*str)
	{
		if (*str++ == '\n')
		{
			lf++;
		}
	}
	*len = str - begin;
	return lf;
} /* CountLF */







int ScrollField(Short linesToScroll, Word fldID, Word sbID)
{
	Short min, max, value, pageSize;
	FieldPtr fld;
	ScrollBarPtr bar;
	Word blanks;
	
    fld = GetObjectPtr(fldID);

	if (linesToScroll < 0)
	{
		blanks = FldGetNumberOfBlankLines(fld);
        FldScrollField(fld, -linesToScroll, up);
        if (blanks)
        {
	  		bar = GetObjectPtr(sbID);
		    SclGetScrollBar(bar, &value, &min, &max, &pageSize);
			if (blanks > -linesToScroll)
			{
				max += linesToScroll;
			}
			else
			{
				max -= blanks;
			}
		    SclSetScrollBar(bar, value, min, max, pageSize);
        }
	}		
	else if (linesToScroll > 0)
	{
		FldScrollField (fld, linesToScroll, down);
	}

    return 0;
} /* ScrollField */





Word UpdateField(Word fldID, Word sbID)
{
	Word fieldheight,
		textheight,
		max,
		top_line,
		pagesize;
	
	FldGetScrollValues(GetObjectPtr(fldID), &top_line, &textheight, &fieldheight);
	pagesize = fieldheight - 1;
	if (textheight > fieldheight)
	{
		max = textheight - fieldheight;
	}
	else if (top_line)
	{
		max = top_line;
	}
	else
	{
		max = 0;
	}
	SclSetScrollBar(GetObjectPtr(sbID), top_line, 0,  max, pagesize);
	
	return pagesize;
} /* UpdateField */






int HandleEditMenu(EventPtr e)
{
	FieldPtr fld;
	FormPtr frm;
	Word id;

	frm = FrmGetActiveForm();
	id = FrmGetFocus(frm);
	switch (e->data.menu.itemID)
	{
		case mArtCut:
		{
			if (id != -1)
			{
				fld = FrmGetObjectPtr(frm, id);
				FldCut(fld);
				FldSetSelection(fld, 0, 0);
				FldRecalculateField(fld, 1);
				return 1;
			}
			break;
		}

		case mArtPaste:
		{
			if (id != -1)
			{
				fld = FrmGetObjectPtr(frm, id);
				FldPaste(fld);
				FldSetSelection(fld, 0, 0);
				FldRecalculateField(fld, 1);
				return 1;
			}
			break;
		}

		case mArtUndo:
		{
			if (id != -1)
			{
				fld = FrmGetObjectPtr(frm, id);
				FldUndo(fld);
				FldSetSelection(fld, 0, 0);
				FldRecalculateField(fld, 1);
				return 1;
			}
			break;
		}
		case mArtCopy:
		{
			if (id != -1)
			{
				fld = FrmGetObjectPtr(frm, id);
				FldCopy(fld);
				FldSetSelection(fld, 0, 0);
				FldRecalculateField(fld, 1);
				return 1;
			}
			break;
		}

		case mArtSelectAll:
		{
			if (id != -1)
			{
				fld = FrmGetObjectPtr(frm, id);
				FldSetSelection(fld, 0, FldGetTextLength(fld));
				FldRecalculateField(fld, 0);
				return 1;
			}
			break;
		}
		
		case mPrefs2ServerDup:
		{
			return 2;
		}

		case mPrefs2ServerDel:
		{
			return 3;
		}
		
		default:
	}
	
	return 0;
} /* HandleEditMenu */




char *CreateNewDatabase(char *prefix, char *tempname, char *dum)
{
	Err err;
	UInt numdum = 0;
	UInt prelen;

    // First, create a new newsgroup database
    // This part has complexity O(n) but we don�t create a new
    // newsgroup very often and with this algorithm we don�t need to care
    // about deleted newsgroups and gaps in the database name order
    // i.e.: pre: databases Group-1, Group-2, Group-3 exist. We delete Group-2
    // The next created database gets name Group-2 because the name is free.
    
    prelen = StrLen(prefix);
    StrCopy(tempname, prefix);
    do
    {
        numdum++;
        StrIToA(dum, numdum);
        StrCopy(tempname+prelen, dum);
        err = DmCreateDatabase(0, tempname, CREATOR, TYPE, 0);
        if (err && (err != dmErrAlreadyExists))
        {
            return NULL;
        }
    }
    while (err == dmErrAlreadyExists);

    // At this point a new database has been created with name tempname
    return tempname;
} /* CreateNewDatabase */





//
//
// If a character was entered in field fieldid and we are in permit_mode
// then 1 is returned, if the character was not found in tokens
// If we are not in permit_mode (i.e. we prohibit certain characters as
// found in tokens) we return 1 if the character was found.
//

int HandleInput(EventPtr e, Word fieldid, int permit_mode, char *tokens)
{
	FormPtr frm;
	Word id;
	char c;
	

	c = e->data.keyDown.chr;
	frm = FrmGetActiveForm();
	id = FrmGetObjectId(frm, FrmGetFocus(frm));
	if (id == fieldid)
	{
		switch (permit_mode)
		{
			case 0:
			{
				return (StrChr(tokens, c) != NULL);
				break;
			}
			case 1:
			{
				return (StrChr(tokens, c) == NULL);
				break;
			}

			case 2:
			{
				return !(((c >= 'a') && (c <= 'z'))
						|| ((c >= 'A') && (c <= 'Z'))
						|| ((c >= '0') && (c <= '9'))
						|| (StrChr("-_.+\010", c) != NULL)
						|| (StrChr(tokens, c) != NULL)
						|| (c == leftArrowChr)
						|| (c == rightArrowChr));
				break;
			}
			default:
		}
	}
	return 0;
} /* HandleInput */



void ShowButton(Word id, int visible)
{
	ControlType *btn;
	
	btn = GetObjectPtr(id);
	if (visible)
	{
		CtlShowControl(btn);
	}
	else
	{
		CtlHideControl(btn);
	}

} /* SwitchButton */





//
//
// Generates a From line for output like the user likes it most ...
//



void GetInfoOfFromField(char *header_field, char *out, char style)
{
	char *start;

	switch (style)
	{
		case yfFromStyle_name:
		{
			start = StrChr(header_field, '(');
			if (start != NULL)
			{
				start++;
				while (*start && (*start != ')'))
				{
					*out++ = *start++;
				}
				*out = 0;
			}
			else
			{
				start = header_field;
				while (*start && (*start != '<'))
				{
					*out++ = *start++;
				}
				*out = 0;
			}
			break;
		}

		case yfFromStyle_address:
		{
			start = StrChr(header_field, '<');
			if (start != NULL)
			{
				start++;
				while (*start && (*start != '>'))
				{
					*out++ = *start++;
				}
				*out = 0;
			}
			else
			{
				start = header_field;
				while (*start && (*start != '('))
				{
					*out++ = *start++;
				}
				*out = 0;
			}
			
			break;
		}
		
		case yfFromStyle_both:
		{
			StrCopy(out, header_field);
			break;
		}
		
		default:
	}
} /* GetInfoOfFromField */



char *GenFromStyle(char *header_field, char *out, int show_scoring)
{
	char dum[2];
	Word score;

	if (yprefs.scoring && show_scoring)
	{
		ScrReadAuthorsScore(header_field, &score);
		if (score)
		{
			StrCopy(out, StrIToA(dum, score));
			StrCat(out, ":");
			out += 2;
		}
		else
		{
			StrCopy(out, "    ");
			out += 4;
		}
	}

	GetInfoOfFromField(header_field, out, yprefs.from_style);

	return out;
} /* GenFromStyle */



void GenScoringAddress(char *header_field, char *out)
{
	GetInfoOfFromField(header_field, out, yfFromStyle_address);
} /* GenScoringAddress */






void EditSavedArticle(void)
{
	DBNGNum old_ng;
	DBArtNum last_art;
	struct articledb_item art;

	ystate.currently_writing_article = -1;
	old_ng = NGRememberActive();
	NGCloseNewsgroup();
	NGOpenNewsgroupByName(drafts_group);
	last_art = NGArticlesCount() - 1;
	NGReadArticle(last_art, &art);
	//delete_on_exit = 
	InvokePost(1, (StrChr(art.newsgroups, '@') != NULL), 
		art.newsgroups, art.subject, art.ref, art.body, art.server);
	NGDeleteArticle(last_art);
	NGCloseNewsgroup();
	NGOpenOldActive(old_ng);
} /* EditSavedArticle */



//
//
// places has the number of places the selector has been moved.
// This can be any number such as -23 or 2 (e.g. when the user skipped
// through multiple articles in art view mode)
//
// Returns number of lines the art or ng list has to be scrolled.
//

int CalcPageSize(int places, Word rows)
{
	int dir, pages;
	
	if (places < 0)
	{
		dir = -1;
	}
	else if (places > 0)
	{
		dir = 1;
	}
	else
	{
		dir = 0;  
	}

	pages = (places / (int) rows) + dir;

	switch (yprefs.pagesize)
	{
		case yfPageSizeOneLine:
		{
			return places;
			break;
		}
		case yfPageSizeOnePage:
		{
			return pages * rows;
			break;
		}
		case yfPageSizeOnePageMinOne:
		{
			return pages * (rows - 1);
			break;
		}

		default:
			// never reached - hopefully
			return places;
	}
} /* CalcPageSize */

