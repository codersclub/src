/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// lang.h
//
// strings that can be localized
// Matthias Jordan, 7-1999
//
//

#ifndef LANG_H
#define LANG_H

extern char yf_mem_low[],
	yf_save_art_err[],
	yf_from[],
	yf_nsubject[],
	yf_ndate[],
	yf_nnewsgroups[],
	yf_nmsgid[],
	yf_head[],
	yf_body[],
	yf_header_not_avail[],
	yf_title_subject[],
	yf_newsgroup[],
	yf_saving_failed[],
	yf_id_purge[],
	yf_art_purge[],
	yf_sample_arts[],
	yf_timeout[],
	yf_article_max[],
	yf_no_zero_val[],
	yf_max_31_k[],
	yf_name[],
	yf_newsserver[],
	yf_mailserver[],
	yf_port[],
	yf_already_subs[],
	yf_suc_unsub[],
	yf_field_empty[],
	yf_fs_overflow[],
	yf_fs_underrun[],
	yf_srv_con_online[],
	yf_network_closed[],
	yf_old[],
	yf_all[],
	yf_every_single[],
	yf_selected[],
	yf_read[],
	yf_articles[],
	yf_art_in_db[],
	yf_msgids[],
	yf_inside_group_warning[],
	yf_empty_fields_not_all[],
	yf_edit[],
	yf_groups[],

	yf_net_timeout[],
	yf_net_socket_not_open[],
	yf_net_socket_busy[],
	yf_net_name_too_long[],
	yf_net_bad_name[],
	yf_net_sock_closed_remote[],
	yf_net_error_num[],
	yf_net_unexp_resp[],
	yf_net_sock_usable[],
	yf_net_lib_not_found[],
	yf_net_lib_connect_failed[],
	yf_net_sock_open_err[],
	yf_net_err_alloc_buf_db[],
	yf_net_sock_close_err[],
	yf_net_addr_err[],
	yf_net_sock_con_err[],
	yf_net_auth_err[],
	yf_net_auth_req[],
	yf_net_read_err[],
	yf_net_send_err[],
	yf_net_group_unknown[],
	yf_net_art_not_on_server[],
	yf_net_nart_body[],
	yf_net_narticle[],
	yf_net_npolling[],
	yf_net_nget_headers[],
	yf_net_ngroup_entered[],
	yf_net_server_port_err[],
	yf_net_connected[],
	yf_net_ninst_arts[],
	yf_net_no_new_arts[],
	yf_net_art_post_err[],
	yf_net_npostingemail[],
	yf_net_npostingart[],
	yf_net_transfer[],
	yf_net_nng_empty[],
	yf_must_be_online[],
	yf_complete_setup[],
	yf_cant_unsub_outgoing[],
	yf_cant_post_to_outgoing[],
	
	yf_purging_arts[],
	yf_purging_msgids[],
	yf_purging_all_arts[],
	yf_reindexing[],

	yf_palmos_warning[],
	outgoing_group[],
	drafts_group[],

	yf_none[],
	yf_current_group[],
	yf_all_servers[],
	yf_copy[],
	yf_mailsrv_del[],
	yf_standard_sig[],
	yf_ng_set_to_dont_poll[],
	yf_this_server[],
	yf_and_articles[],
	yf_dummy_server[],
	yf_no_server_for_group[];
	

#endif

