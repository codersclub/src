/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmprefs2.c
//
// handle the server prefs forms of Yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/DateTime.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefs2.h"
#include "prefs.h"
#include "ngroup.h"
#include "lang.h"
#include "serverdb.h"
#include "subscrdb.h"


VoidHand hn, hs, hp, hau, htim, hap;
VoidHand huser, hhost, hzone, hreal, hsig;







short actnum = 0;


static short GetNameSelection(void)
{
	ListPtr l;
	char **items;
	short choice;
	DBServerNum i_count;

	items = SrvGetServerList(srv_list_mode_all, &i_count);
	
	l = GetObjectPtr(lstPrefs2Name);
	LstSetListChoices(l, items, SrvServersCount());
	LstSetSelection(l, actnum);
	LstSetHeight(l, min(i_count, 5));

	choice = LstPopupList(l);

	SrvFreeServerList(items);
	return choice;
} /* GetNameSelection */




static int SavePrefsServer(int to_db)
{
	int res;
	ControlPtr ctl;
		
	if ((res = GetVariableField(yf_name, fldPrefs2Name, &actserver.name)) != 0)
	{
		return res;
	}
	
	if ((res = GetVariableField(yf_newsserver, fldPrefs2Address, &actserver.address)) != 0)
	{
		return res;
	}
	
	if (GetFormValue(yf_timeout, fldPrefs2Timeout, &actserver.timeoutsecs))
	{
		return 1;
	}

	if (GetFormValue(yf_port, fldPrefs2Port, &actserver.port))
	{
		return 1;
	}

	if (actnum == 0)
	{
		// This is the mailserver so get reply to value from this field
		if ((res = GetVariableField(NULL, fldPrefs2ReplyTo, &actserver.auth_user)) != 0)
		{
			return res;
		}
	}
	else
	{
		GetVariableField(NULL, fldPrefs2AuthName, &actserver.auth_user);
	
		ctl = GetObjectPtr(chkPrefs2Poll);
		actserver.poll = CtlGetValue(ctl);
	
		ctl = GetObjectPtr(chkPrefs2UseAuth);
		actserver.use_auth = CtlGetValue(ctl);
	}
	
	if (to_db)
	{
		SrvWriteServer(&actserver, 1, &actnum);
	}
	return 0;
} /* SavePrefsServer */



static void UpdateSelector(void)
{
	ControlPtr slt;
	
	slt = GetObjectPtr(sltPrefs2AuthPass);
	CtlSetLabel(slt, *actserver.auth_pass ? "Entered" : "None");
} /* UpdateSelector */




static void InitFormServer(void)
{
	FieldPtr fld;
	FormPtr frm;
	ControlPtr ctl;
	char *n, *s, *p, *au, *tim;
	
	hn = MemHandleNew(StrLen(actserver.name) + 1);
	hs = MemHandleNew(StrLen(actserver.address) + 1);
	hp = MemHandleNew(6);
	htim = MemHandleNew(6);
	
	if (!(hn && hs && hp && htim))
	{
		return;
	}
	n = (char *) MemHandleLock(hn);
	s = (char *) MemHandleLock(hs);
	p = (char *) MemHandleLock(hp);
	tim = (char *) MemHandleLock(htim);
	
	StrCopy(n, actserver.name);
	StrCopy(s, actserver.address);
	StrIToA(p, actserver.port);
	StrIToA(tim, actserver.timeoutsecs);
	
	MemHandleUnlock(hn);
	MemHandleUnlock(hs);
	MemHandleUnlock(hp);
	MemHandleUnlock(htim);

	fld = GetObjectPtr(fldPrefs2Name);
	FldSetTextHandle(fld, (Handle) hn);
	
	ctl = GetObjectPtr(lblPrefs2Type);
	CtlSetLabel(ctl, actnum ? "Newsserver" : "Mailserver");
	
	fld = GetObjectPtr(fldPrefs2Address);
	FldSetTextHandle(fld, (Handle) hs);
	
	fld = GetObjectPtr(fldPrefs2Port);
	FldSetTextHandle(fld, (Handle) hp);

	fld = GetObjectPtr(fldPrefs2Timeout);
	FldSetTextHandle(fld, (Handle) htim);

	if (actnum == 0)
	{
		// Mailservers don't use authentication etc.
		frm = FrmGetActiveForm();
		FrmHideObject(frm, FrmGetObjectIndex(frm, lblPrefs2Poll));
		FrmHideObject(frm, FrmGetObjectIndex(frm, chkPrefs2Poll));
		FrmHideObject(frm, FrmGetObjectIndex(frm, lblPrefs2UseAuth));
		FrmHideObject(frm, FrmGetObjectIndex(frm, chkPrefs2UseAuth));
		FrmHideObject(frm, FrmGetObjectIndex(frm, lblPrefs2AuthName));
		FrmHideObject(frm, FrmGetObjectIndex(frm, fldPrefs2AuthName));
		FrmHideObject(frm, FrmGetObjectIndex(frm, lblPrefs2AuthPass));
		FrmHideObject(frm, FrmGetObjectIndex(frm, sltPrefs2AuthPass));
		FrmShowObject(frm, FrmGetObjectIndex(frm, lblPrefs2ReplyTo));
		FrmShowObject(frm, FrmGetObjectIndex(frm, fldPrefs2ReplyTo));
		
		hau = MemHandleNew(StrLen(actserver.auth_user) + 1);
		au = (char *) MemHandleLock(hau);
		StrCopy(au, actserver.auth_user);
		MemHandleUnlock(hau);
		fld = GetObjectPtr(fldPrefs2ReplyTo);
		FldSetTextHandle(fld, (Handle) hau);
	}
	else
	{
		frm = FrmGetActiveForm();
		FrmShowObject(frm, FrmGetObjectIndex(frm, lblPrefs2Poll));
		FrmShowObject(frm, FrmGetObjectIndex(frm, chkPrefs2Poll));
		FrmShowObject(frm, FrmGetObjectIndex(frm, chkPrefs2UseAuth));
		FrmShowObject(frm, FrmGetObjectIndex(frm, lblPrefs2UseAuth));
		FrmShowObject(frm, FrmGetObjectIndex(frm, lblPrefs2AuthName));
		FrmShowObject(frm, FrmGetObjectIndex(frm, fldPrefs2AuthName));
		FrmShowObject(frm, FrmGetObjectIndex(frm, lblPrefs2AuthPass));
		FrmShowObject(frm, FrmGetObjectIndex(frm, sltPrefs2AuthPass));
		FrmHideObject(frm, FrmGetObjectIndex(frm, lblPrefs2ReplyTo));
		FrmHideObject(frm, FrmGetObjectIndex(frm, fldPrefs2ReplyTo));

		ctl = GetObjectPtr(chkPrefs2Poll);
		CtlSetValue(ctl, actserver.poll);
	
		ctl = GetObjectPtr(chkPrefs2UseAuth);
		CtlSetValue(ctl, actserver.use_auth);
	
		hau = MemHandleNew(StrLen(actserver.auth_user) + 1);
		au = (char *) MemHandleLock(hau);
		StrCopy(au, actserver.auth_user);
		MemHandleUnlock(hau);
		fld = GetObjectPtr(fldPrefs2AuthName);
		FldSetTextHandle(fld, (Handle) hau);
	}
} /* InitFormServer */



static void ClearFieldsServer(void)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldPrefs2Name);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Address);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Port);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Timeout);
	FldSetTextHandle(fld, 0);

	if (actnum == 0)
	{
		fld = GetObjectPtr(fldPrefs2ReplyTo);
		FldSetTextHandle(fld, 0);
	}
	else
	{
		fld = GetObjectPtr(fldPrefs2AuthName);
		FldSetTextHandle(fld, 0);
	}
	
	MemHandleFree(hn);
	MemHandleFree(hs);
	MemHandleFree(hp);
	MemHandleFree(htim);
	MemHandleFree(hau);
} /* ClearFieldsServer */



static void ValueZeroAlert(void)
{ 
	FrmCustomAlert(altInfo, yf_no_zero_val, " ", " ");
} /* ValueZeroAlert */




static void DuplicateServerEntry(void)
{
	char *oldname;
	short num;
    int res = 0;

	// Duplicate
	oldname = actserver.name;
	actserver.name = MemPtrNew(StrLen(oldname) + StrLen(yf_copy) + 1);
	if (actserver.name == NULL)
	{
		actserver.name = oldname;
	}
	else
	{
		StrCopy(actserver.name, oldname);
		StrCat(actserver.name, yf_copy);
		SrvAppendServer(&actserver);
		MemPtrFree(actserver.name);
		actserver.name = oldname;
		num = SrvServersCount() - 1;
		res = SavePrefsServer(1);
		actnum = num;
		FrmUpdateForm(frmPrefs2Server1, 1);
	}
} /* DuplicateServerEntry */




Boolean HandlePrefs2Server1(EventPtr event)
{
    int handled = 0;
	short num;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitFormServer();
			UpdateSelector();
            RefreshForm();
            handled = 1;
            break;
		}

		case frmUpdateEvent:
		{
			if (event->data.frmUpdate.updateCode == 1)
			{
				SrvFreeData(&actserver);
    	    	SrvCopyServer(&actserver, actnum);
				InitFormServer();
			}
			UpdateSelector();
			RefreshForm();
			handled = 1;
			break;
		}

        case menuEvent:
        {
			handled = HandleEditMenu(event);
			if (handled == 2)
			{
				DuplicateServerEntry();
#ifdef COMMENT
				// Duplicate
				oldname = actserver.name;
				actserver.name = MemPtrNew(StrLen(oldname) + StrLen(yf_copy) + 1);
				if (actserver.name == NULL)
				{
					actserver.name = oldname;
				}
				else
				{
					StrCopy(actserver.name, oldname);
					StrCat(actserver.name, yf_copy);
					SrvAppendServer(&actserver);
					MemPtrFree(actserver.name);
					actserver.name = oldname;

					num = SrvServersCount() - 1;
					res = SavePrefsServer(1);
					actnum = num;
					FrmUpdateForm(frmPrefs2Server1, 1);
				}
#endif

			} 
			else if (handled == 3)
			{
				// Delete
				if (actnum > 0)  // Mailserver resides in pos 0
				{
					if (!FrmCustomAlert(altDeleteConf, yf_this_server, yf_and_articles, " "))
					{
						SrvDeleteServer(actnum);
						SubCorrectServerNum(actnum);
						NGUpdateOutgoing(actnum);
						actnum--; // 0 does always exist so this is always legal
						FrmUpdateForm(frmPrefs2Server1, 1);
						NPUpdateForm(frmArtList, updArtListMajorChanges);
						NPUpdateForm(frmNewsgroups, 1);
					}
				}
				else
				{
					FrmCustomAlert(alertID_dum, yf_mailsrv_del, " ", " ");
				}
			}
			break;
        }


		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case trgPrefs2Name:
				{
					num = GetNameSelection();
					if (num != -1)
					{
						res = SavePrefsServer(1);
						actnum = num;
						FrmUpdateForm(frmPrefs2Server1, 1);
					}
					handled = 1;
					break;
				}

				case sltPrefs2AuthPass:
				{
					NPGotoForm(frmAuthPass);
					handled = 1;
					break;
				}

				case btnCancel:
				{
					ClearFieldsServer();
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					res = SavePrefsServer(1);
					if (!res)
					{
						ClearFieldsServer();
						NPExitForm();
					}
					else if (res == 1)
					{
						ValueZeroAlert();
					}
					else if (res == 3)
					{
						FrmCustomAlert(altInfo, yf_mem_low, " ", " ");
						ClearFieldsServer();
						NPExitForm();
					}
					handled = 1;
					break;
				}

				case btnPrefs2Add:
				{
					DuplicateServerEntry();
					break;
				}
				
				case btnNext:
				{
					res = SavePrefsServer(0);
					if (!res)
					{
						ClearFieldsServer();
						NPExitForm();
						NPGotoForm(frmPrefs2Server2);
					}
					handled = 1;
					break;
				}
				
				default:
			}
			break;
		}
		
        default:
		
    }
    return handled;
} /* HandlePrefs2Server1 */





void PrefsInvokeServer(short num)
{
	actnum = num;

	SrvInitData(&actserver);
   	SrvCopyServer(&actserver, actnum);
	NPGotoForm(frmPrefs2Server1);
} /* PrefsInvokeServer */










/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// handle the Posting prefs form of yanoff
// Matthias Jordan, 4-1999
//
//




static int SavePrefsPost(int to_db)
{
	int res;

	if ((res = GetVariableField(NULL, fldPrefs2Username, &actserver.username)) != 0)
	{
		return res;
	}
	if ((res = GetVariableField(NULL, fldPrefs2Hostname, &actserver.hostname)) != 0)
	{
		return res;
	}
	if ((res = GetVariableField(NULL, fldPrefs2Zone, &actserver.zone)) != 0)
	{
		return res;
	}
	if ((res = GetVariableField(NULL, fldPrefs2Realname, &actserver.realname)) != 0)
	{
		return res;
	}
	if ((res = GetVariableField(NULL, fldPrefs2Sig, &actserver.sig)) != 0)
	{
		return res;
	}

	if (to_db)
	{
		SrvWriteServer(&actserver, 1, &actnum);
	}
	return 0;
} /* SavePrefsPost */



static void InitFormPost(void)
{
	FieldAttrType attr;
	FieldPtr fld;
	char *user, *host, *zone, *real, *sig;
	
	huser = MemHandleNew(StrLen(actserver.username) + 1);
	hhost = MemHandleNew(StrLen(actserver.hostname) + 1);
	hzone = MemHandleNew(StrLen(actserver.zone) + 1);
	hreal = MemHandleNew(StrLen(actserver.realname) + 1);
	hsig = MemHandleNew(StrLen(actserver.sig) + 1);
	
	if (!(huser && hhost && hzone && hreal && hsig))
	{
		return;
	}
	user = (char *) MemHandleLock(huser);
	host = (char *) MemHandleLock(hhost);
	zone = (char *) MemHandleLock(hzone);
	real = (char *) MemHandleLock(hreal);
	sig = (char *) MemHandleLock(hsig);
	
	StrCopy(user, actserver.username);
	StrCopy(host, actserver.hostname);
	StrCopy(zone, actserver.zone);
	StrCopy(real, actserver.realname);
	StrCopy(sig, actserver.sig);
	
	MemHandleUnlock(huser);
	MemHandleUnlock(hhost);
	MemHandleUnlock(hzone);
	MemHandleUnlock(hreal);
	MemHandleUnlock(hsig);

	fld = GetObjectPtr(fldPrefs2Username);
	FldSetTextHandle(fld, (Handle) huser);

	fld = GetObjectPtr(fldPrefs2Hostname);
	FldSetTextHandle(fld, (Handle) hhost);

	fld = GetObjectPtr(fldPrefs2Zone);
	FldSetTextHandle(fld, (Handle) hzone);

	fld = GetObjectPtr(fldPrefs2Realname);
	FldSetTextHandle(fld, (Handle) hreal);

	fld = GetObjectPtr(fldPrefs2Sig);
	FldSetTextHandle(fld, (Handle) hsig);
	
	FldSetScrollPosition(fld, 0);
    FldGetAttributes(fld, &attr);
    attr.hasScrollBar = 1;
    FldSetAttributes(fld, &attr);
	UpdateField(fldPrefs2Sig, sbPrefs2Sig);
} /* InitFormPost */



static void ClearFieldsPost(void)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldPrefs2Username);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Hostname);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Zone);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Realname);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs2Sig);
	FldSetTextHandle(fld, 0);
	
	MemHandleFree(huser);
	MemHandleFree(hhost);
	MemHandleFree(hzone);
	MemHandleFree(hreal);
	MemHandleFree(hsig);
} /* ClearFieldsPost */





Boolean HandlePrefs2Server2(EventPtr event)
{
    int handled = 0;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitFormPost();
            RefreshForm();
            handled = 1;
            break;
        }

		case fldChangedEvent:
		{
			UpdateField(fldPrefs2Sig, sbPrefs2Sig);
			handled = 1;
			break;
		}

		case sclRepeatEvent:
		{
			ScrollField(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value, fldPrefs2Sig, sbPrefs2Sig);
			break;
		}
		
        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					ClearFieldsPost();
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					res = SavePrefsPost(1);
					if (!res)
					{
						ClearFieldsPost();
						NPExitForm();
					}
					handled = 1;
					break;
				}

				case btnPrev:
				{
					res = SavePrefsPost(0);
					if (!res)
					{
						ClearFieldsPost();
						NPExitForm();
						NPGotoForm(frmPrefs2Server1);
					}
					handled = 1;
					break;
				}
				
				default:
			}
			break;
		}
		
		case keyDownEvent:
		{
			handled = HandleInput(event, fldPrefs2Username, 2, "")
				|| HandleInput(event, fldPrefs2Realname, 2, " ")
				|| HandleInput(event, fldPrefs2Hostname, 2, "");
			break;
		}
		
		
        default:
		
    }
    return handled;
} /* HandlePrefs2Server2 */






