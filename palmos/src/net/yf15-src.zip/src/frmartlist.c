/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmartlist.c
//
// Handle the article list form
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "ngroup.h"
#include "prefs.h"
#include "lang.h"
#include "subscrdb.h"
#include "hardbtn.h"

#include "frmnglist.h"
#include "frmartlist.h"
#include "frmart.h"
#include "frmpost.h"

#include "mainmenu.h"


DBArtNum top_article,
	sel_art_in_list;
int artlistpagesize,
	scroll_acc;
FontID ArtListFont = stdFont;



DBArtNum FrmArtListTopArticle(void)
{
	return top_article;
} /* FrmArtListTopArticle */



void FrmArtListAdvanceSelArtNum(int dir)
{
	scroll_acc += dir;
} /* AdvanceSelArtNum */



void FrmArtListUpdateNGEntry(void)
{
	SubUpdateSubscriptionTopArt(NGActiveNGNum(), top_article, sel_art_in_list);
} /* FrmArtListUpdateNGEntry */



static DBArtNum SelArtNum(void)
{
	return top_article + sel_art_in_list;
} /* SelectedArtNum */


static void HighlightActArt(int delete)
{
	if ((NGArticlesCount() > 0) || delete)
	{
		HighlightActEntry(tblArtList, sel_art_in_list, delete);
	}
} /* HighlightActArt */



//
//
//  Init article list table
//
//



static void InitTopArticle(void)
{
	TablePtr table;
	Word numrows;
	DBArtNum arts, old_topart;
	
	table = GetObjectPtr(tblArtList);
	numrows = TblGetNumberOfRows(table);

	top_article = active_ng.last_top;
	sel_art_in_list = active_ng.last_sel;
	
	// Maybe the conduit or whatever deleted some articles from
	// the newsgroup meanwhile ...
	arts = NGArticlesCount();
	old_topart = top_article;
	if ((top_article + numrows) > arts)
	{
		if (arts >= numrows)
		{
			top_article = (arts - numrows);
		}
		else
		{
			top_article = 0;
		}
	}
	sel_art_in_list += (old_topart - top_article);
	if (sel_art_in_list >= numrows)
	{
		// selected article was deleted so after shifting the window
		// of the displayed articles in the art list view above
		// the selector would be below the last article in the group
		// This is a Bad Idea (TM) so let's go sure.
		sel_art_in_list = (numrows - 1);
		if (sel_art_in_list > arts)
		{
			// There are fewer articles than table rows in the group
			sel_art_in_list = (arts - 1);
		}
	}
} /* InitTopArticle */




#define colsepx 2


static void ArtListDrawLabels(void)
{
	int extx = 160,     // was 151 // was 138
		x = 15,			// was 15
		y = 16;			// was 16
	RectangleType r;

	r.topLeft.x = 0;
	r.topLeft.y = y;
	r.extent.x = extx;
	r.extent.y = 12;	// was 11
	WinEraseRectangle(&r, 0);

	if (yprefs.artspx > 5)
	{
		DrawItemString(yf_from, x, y, yprefs.artspx);
	}

	if (yprefs.artspx < (extx - 5))
	{
		DrawItemString(yf_title_subject, x + yprefs.artspx + colsepx, y, extx - colsepx - yprefs.artspx - 1);
	}	

	WinInvertRectangle(&r, 0);
	WinDrawGrayLine(0, 142, 160, 142);
} /* ArtListDrawLabels */


#ifdef OS35
#define Word Int16
#endif

static void ArticlesListDrawItem(VoidPtr table, Word row, Word column, 
	RectanglePtr bounds)
{
	Word recnum;
	short x, y;
	struct articledb_item a;
	char *fromdum = NULL;
	
CALLBACK_PROLOGUE

	recnum = TblGetRowID(table, row);
	if (recnum == -1)
	{
		// empty table entry
		return;
	}
	x = bounds->topLeft.x + 1;
	y = bounds->topLeft.y;
	FntSetFont(ArtListFont);
	NGReadArticle((DBArtNum) recnum, &a);
	switch (column)
	{
		case 0:
		{
			WinEraseRectangle(bounds, 0);
			// Chars possible: .:il!|
			if (a.flags & yfArticleFlagMarked)
			{
				DrawItemString("!", x, y, bounds->extent.x);
			}
			if (a.flags & yfArticleFlagKeep)
			{
				DrawItemString("i", x+4, y, bounds->extent.x);
			}
			else
			{
				if (a.flags & yfArticleFlagRead)
				{
					DrawItemString(".", x+4, y, bounds->extent.x);
				}
			}
			if (*a.body)
			{
				DrawItemString("|", x+8, y, bounds->extent.x);
			}
 			break;
		}

		case 1:
		{
			if (yprefs.artspx > 5)
			{
				fromdum = MemPtrNew(StrLen(a.from) + 1 + 4); // add 3 byte for scoring info
				if (fromdum == NULL)
				{
					return;
				}
				GenFromStyle(a.from, fromdum, 1);
				DrawItemString(fromdum, x, y, yprefs.artspx);
				MemPtrFree(fromdum);
			}

			if (yprefs.artspx < (bounds->extent.x - 5))
			{
				DrawItemString(a.subject, x + yprefs.artspx + colsepx, y, bounds->extent.x - colsepx - yprefs.artspx - 1);
			}	
			break;
		}
		default:
	}

CALLBACK_EPILOGUE

} /* ArticlesListDrawItem */



//
//
//  Initialize the newsgroups list table
//	lines: number of rows scrolled - to calculate what rows have to
//  be marked invalid to be redrawn.
//  lines == 0 -> init of table
//

static void InitArticlesTable(int lines)
{
	TablePtr table;
	RectangleType r;
	FontID curFont;
	Word row,
		 numrows,
		 tableheight,
		 lineheight;
	DBArtNum currecord, lastrecord;
	struct articledb_item a;
	
	table = GetObjectPtr(tblArtList);
	TblGetBounds(table, &r);
	tableheight = r.extent.y;

	curFont = FntSetFont(ArtListFont);
	lineheight = FntLineHeight();
	FntSetFont(curFont);
	numrows = TblGetNumberOfRows(table);

	
	lastrecord = NGArticlesCount() - 1; // dual-use of lastrecord... (not nice, but works)
	if (lastrecord + 1 >= numrows) // more articles than lines
	{
		if (top_article > lastrecord - numrows + 1) // top_article too high
		{
			top_article = lastrecord - numrows + 1;
		}
	}
	else
	{
		top_article = 0;
	}
	
	currecord = top_article;

	for (row = 0; row < numrows; row++)
	{
		if (!NGReadArticle(currecord, &a))
		{
			// newsgroup number currecord exists
			TblSetRowID(table, row, (Word) currecord);
			TblSetItemStyle(table, row, 0, customTableItem);
			TblSetItemStyle(table, row, 1, customTableItem);
			TblSetRowHeight(table, row, lineheight);
			TblSetRowData(table, row, (Word) currecord);
			TblSetRowUsable(table, row, true);
			if ((!lines || (!row && (lines < 0)) || (lines >= (int) numrows))
				|| ((lines > 0) && ((numrows - 1 - lines) < row) && (row < numrows))
				|| ((lines < 0) && (0 <= row) && (row < -lines)))
			{
				TblMarkRowInvalid(table, row);
			}

			lastrecord = currecord;
			if (row+1 < numrows)
			{
				currecord++;
			}
		}
		else
		{
			TblSetRowID(table, row, -1);
			TblSetRowUsable(table, row, false);
		}
	}
	TblSetCustomDrawProcedure(table, 0, ArticlesListDrawItem);
	TblSetCustomDrawProcedure(table, 1, ArticlesListDrawItem);
	TblSetColumnUsable(table, 0, true);
	TblSetColumnUsable(table, 1, true);
	
	artlistpagesize = numrows - 1;

	if (NGArticlesCount() > numrows)
	{
		TblHasScrollBar(table, true);
		SclSetScrollBar(GetObjectPtr(sbArtList), top_article, 0, NGArticlesCount() - numrows, artlistpagesize);
	}
	else
	{
		TblHasScrollBar(table, false);
		SclSetScrollBar(GetObjectPtr(sbArtList), 0, 0, 0, 0);
	}
	TblRedrawTable(table);
} /* InitArticlesTable */







//
//
// Scrolls article list lines lines down. If the end of page
// is reached, it returns 1, else 0
//

static int ScrollArtList(int lines, int advance_selection)
{
	Word lastRow, rows;
	Word scrollAmount, new_top;
	Int i, 
		count;
	TablePtr table;
	RectangleType scrollR;
	RectangleType vacated;
	DirectionType direction;


	table = GetObjectPtr(tblArtList);
	rows = TblGetNumberOfRows(table);
	count = NGArticlesCount();
	new_top = GetNewTopline(top_article, count, rows, lines);
	lines = new_top - top_article;

	if (lines)
	{
		HighlightActArt(1);
		top_article = new_top;

		if (((lines > 0) && (lines < rows)) ||
			 ((lines < 0) && (-lines < rows)))
		{
			scrollAmount = 0;
		
			if (lines > 0)
			{
				lastRow = TblGetLastUsableRow(table) - 1;
				for (i = 0; i < lines; i++)
				{
					scrollAmount += TblGetRowHeight(table, lastRow);
					TblRemoveRow(table, 0);
				}
				direction = up;
			}
			else
			{
				for (i = 0; i < -lines; i++)
				{
					scrollAmount += TblGetRowHeight(table, 0);
					TblInsertRow(table, 0);
				}
				direction = down;
			}
	
			TblGetBounds(table, &scrollR); 
			scrollR.topLeft.x -= 1;
	//		scrollR.topLeft.y -= 1;
	//		scrollR.extent.x += 2;
	//		scrollR.extent.y += 1;
			WinScrollRectangle(&scrollR, direction, scrollAmount, &vacated);
			WinEraseRectangle(&vacated, 0);
		}
		InitArticlesTable(lines);
		TblRedrawTable(table);
		HighlightActArt(0);
	}
	else
	{
		// The following lines check whether the user wants to switch
		// to the next or previous group. Do this only if the article
		// list view has not been scrolled. If if has, the selection
		// was not at the first or last article so no switch to another
		// newsgroup should be performed.
		
		if ((SelArtNum() == 0) && (advance_selection < 0))
		{
			// first item selected and scroll up wanted -> go to prev newsgroup
			return 1;
		}

		if ((SelArtNum() == (NGArticlesCount() - 1)) && (advance_selection > 0))
		{
			// dito but -> go to next newsgroup
			return 1;
		}
	}

	ScrollHighlighting(tblArtList, lines, advance_selection, &sel_art_in_list, SelArtNum());
	return 0;
} /* ScrollArtList */




static void HandleArtEnterEvent(EventPtr event)
{
	TablePtr table;
	Short row, col;
	DBArtNum n;

	table = event->data.tblSelect.pTable;
	row = event->data.tblSelect.row;
	col = event->data.tblSelect.column;
	n = TblGetRowID(table, row);
	HighlightActArt(1);
	sel_art_in_list = row;
	HighlightActArt(0);
	if (col == 0)
	{
		NGSetArticleFlag(n, yfArticleFlagMarked, -1);
		TblMarkRowInvalid(table, row);
		FrmUpdateForm(frmArtList, updArtListMinorChanges);
	}	
	else
	{
		ArtFGotoArticle(n);
	}
} /* HandleArtEnterEvent */



static void InitArticlesForm(void)
{
	DBArtNum count;
	
	ShowButton(btnPrev, (NGActiveNGNum() != 0));
	ShowButton(btnNext, (NGActiveNGNum() != (SubSubscriptionsCount() - 1)));
	ShowButton(btnArtListNewArt, (!active_ng.ng_flags & yfNGFlag_internal));

	InitArticlesTable(0);
	NGUpdateActiveNG();
	scroll_acc = 0;
	count = NGArticlesCount();
	if (sel_art_in_list > count - 1)
	{
		sel_art_in_list = count - 1;
	}
} /* InitArticlesForm */





static void SwitchToDifferentNG(int delta)
{
	DBNGNum ng_dum, 
		newng;

	ng_dum = NGActiveNGNum();
	// The sequence of the boolean expressions is important!
	if (((delta >= 0) || (ng_dum >= -delta))
		&& ((ng_dum + delta) < SubSubscriptionsCount()))
	{
		SubUpdateSubscriptionTopArt(ng_dum, top_article, sel_art_in_list);
		newng = ng_dum + delta;
		HighlightActArt(1);
		NGCloseNewsgroup();
		NGOpenNewsgroupByPos(newng);
		FrmUpdateForm(frmArtList, updArtListNewGroup);
		FrmNGListAdvanceSelNGNum(newng - ng_dum);
	}
	else
	{
		SndPlaySystemSound(sndInfo);
	}
} /* SwitchToDifferentNG */





static void ScrollArtDirection(int dir)
{
	TablePtr table;
	Word rows;
	int scroll = 0;

	table = GetObjectPtr (tblArtList);
	rows = TblGetNumberOfRows(table);

	if (((dir > 0) && (dir < rows) && (sel_art_in_list <= ((rows - 1) - dir)))
		|| ((dir < 0) && (dir > -rows) && (sel_art_in_list >= (0 - dir))))
	{
		// selector must be moved but art list doesn't need to be scrolled
		scroll = 0;
	}
	else
	{
		// art list has to be scrolled, too
		scroll = CalcPageSize(dir, rows);
	}

	if (NGArticlesCount() > 0)
	{
		if (ScrollArtList(scroll, dir))
		{
			SwitchToDifferentNG(dir);
		}
	}
 	else
	{
		SwitchToDifferentNG(dir);
	}
} /* ScrollArtDirection */







static void RecallSavedState(void)
{
	if (ystate.last_art == -1)
	{
		if (ystate.currently_writing_article != -1)
		{
			EditSavedArticle();
		}
	}
} /* RecallSavedState */



static void LeaveArtListView(void)
{
	SubUpdateSubscriptionTopArt(NGActiveNGNum(), top_article, sel_art_in_list);
	NGCloseNewsgroup();
	NPUpdateForm(frmNewsgroups, 0);
	NPExitForm();
} /* LeaveArtListView */



Boolean HandleArtList(EventPtr event)
{
	int handled = 0,
		ok = 1;
	FormPtr frm;
	
	frm = FrmGetActiveForm();


    switch (event->eType)
    {
        case frmOpenEvent:
        {
			ystate.last_ng = -1;
			if (!NGNewsgroupOpen())
			{
				if (NGOpenNewsgroupByPos(active_ng_num) == NULL)
				{
					// Error condition: tried to open non-existent (deleted) newsgroup
					ok = 0;
				}
			}
			if (ok)
			{
				InitTopArticle();
				NPSetFormTitle(FrmGetActiveForm(), NGActiveNewsgroup(), 1);
	            RefreshForm();
				InitArticlesForm();
				HighlightActArt(0);
				ArtListDrawLabels();
				RecallSavedState();
			}
			else
			{
				NPExitForm();
				// Set system to safe values
				active_ng_num = -1;
				ystate.currently_writing_article = -1;
			}
			handled = 1;
            break;
        }


		case frmUpdateEvent:
        {
        	if (event->data.frmUpdate.updateCode >= updArtListMajorChanges)
        	{
				NPSetFormTitle(FrmGetActiveForm(), NGActiveNewsgroup(), 1);
				HighlightActArt(1);
				if (event->data.frmUpdate.updateCode == updArtListNewGroup)
				{
					InitTopArticle(); 
				}
				ArtListDrawLabels();
				InitArticlesForm();
			}
			RefreshForm();
			HighlightActArt(0);
			if (scroll_acc)
			{
				ScrollArtDirection(scroll_acc);
				scroll_acc = 0;
			}
            handled = 1;
            break;
        }


		case sclRepeatEvent:
		{
			ScrollArtList(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value, 0);
			break;
		}

        case menuEvent:
        {
			handled = HandleMainMenu(event);
			break;
        }
		
		case tblEnterEvent:
		{
			HandleArtEnterEvent(event);
			handled = 1;
		}

		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnOK:
				{
					LeaveArtListView();
					handled = 1;
					break;
				}

				case btnPrev:
				{
					SwitchToDifferentNG(-1);
					handled = 1;
					break;
				}

				case btnNext:
				{
					SwitchToDifferentNG(1);
					handled = 1;
					break;
				}

				case btnArtListNewArt:
				{
					InvokePost(0, artModeNewsgroup, NGActiveNewsgroup(), NULL, NULL, NULL, 0);
					handled = 1;
					break;
				}
				
				default:

			}
			break;
		}

		case keyDownEvent:
		{
			switch (event->data.keyDown.chr)
			{
				case pageUpChr: 
				{
					ScrollArtDirection(-1);
					handled = 1;
					break;
				}

				case pageDownChr: 
				{
					ScrollArtDirection(1);
					handled = 1;
					break;
				}

				case chrBackspace:
				{
					LeaveArtListView();
					handled = 1; 
					break;
				}

				case vchrHard1:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						LeaveArtListView();
					}
					handled = 1; 
					break;
				}

				case vchrHard2:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						ArtFGotoArticle(SelArtNum());
					}
					handled = 1; 
					break;
				}
		

				case vchrHard3:
				{
					if (yprefs.buttons == yfButtonsLayout_left)
					{
						LeaveArtListView();
					}
					handled = 1; 
					break;
				}

				case vchrHard4:
				{
					if (yprefs.buttons == yfButtonsLayout_left)
					{
						ArtFGotoArticle(SelArtNum());
					}
					handled = 1; 
					break;
				}
		
				case '+':
				case ' ':
				{
					SwitchToDifferentNG(1);
					handled = 1;
					break;
				}

				case '-':
				{
					SwitchToDifferentNG(-1);
					handled = 1;
					break;
				}
			}	
			break;
		} // end keyDownEvent
		
		case penDownEvent:
		{
			if ((event->screenY < artlisttop) && (event->screenY >= FIRSTY)
				&& (event->screenX > 13))
			{
				ArtListMoveColSep(tblArtList, 1, event, &yprefs.artspx);
				handled = 1;
				break;
			}
		}

        default:
    }
    return handled;
} /* HandleArtList */






void ArtListGotoNewsgroup(DBNGNum ngnum)
{
	active_ng_num = ngnum;
	NPGotoForm(frmArtList);
} /* ArtListGotoNewsgroup */
