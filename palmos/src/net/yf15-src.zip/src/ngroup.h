/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// ngroup.h
//
// newsgroup article management headers for use with yanoff
// Matthias Jordan, 4-1999
//
// Put articles into the neccessary databases
//


#ifndef ARTMAN_H
#define ARTMAN_H

#include "segment.h"
#include "artdb.h"
#include "subscrdb.h"

#define purgeArticles 1
#define purgeMsgIDs 2
#define purgeAllArts 3
#define purgeReindex 4

#define ngNoNGOpen -1


extern struct subscriptiondb_item active_ng;

// Ydebug testing...
extern DBNGNum active_ng_num;


int NGNewsgroupOpen(void) SECTION_3;
DmOpenRef NGOpenNewsgroupByName(char *ng) SECTION_3;
DmOpenRef NGOpenNewsgroupByPos(DBNGNum pos) SECTION_3;

void NGCloseNewsgroup(void) SECTION_3;
void NGReopenNewsgroup(void) SECTION_3;

DBNGNum NGRememberActive(void) SECTION_3;
void NGOpenOldActive(DBNGNum oldng) SECTION_3;

char *NGActiveNewsgroup(void) SECTION_3;
DBNGNum NGActiveNGNum(void) SECTION_3;
void NGUpdateActiveNG(void) SECTION_3;


int NGWeaveInArticle(DBArtNum pos, char *nglist, int reindex) SECTION_3;
DBArtNum NGArticlesCount(void) SECTION_3;
int NGDeleteArticle(DBArtNum pos) SECTION_3;
int NGReadArticle(DBArtNum pos, struct articledb_item *art) SECTION_3;
int NGSetArticleFlag(DBArtNum pos, int flag, int value) SECTION_3;
void NGMarkArticles(int mode) SECTION_3;
void NGKeepSelected(int mode) SECTION_3;
void NGToggleReadSelected(void) SECTION_3;
void NGDeleteSelectedRead(int mode) SECTION_3;
ULong NGGetArticleUID(DBArtNum pos) SECTION_3;
int NGUpdateLastField(ULong newlast) SECTION_3;
ULong NGReadLastField(void) SECTION_3;
void NGResetNewsgroup(void) SECTION_3;
void NGPurgeOld(UInt purgedays) SECTION_3;

Boolean HandlePurge(EventPtr event) SECTION_3;
void NGPurge(int what) SECTION_3;

void NGUpdateOutgoing(DBServerNum deleted_server) SECTION_3;


#endif

