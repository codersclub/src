/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// authpass.c
//
// Handles the form to enter an authentication password
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "ngroup.h"
#include "lang.h"
#include "prefs.h"
#include "serverdb.h"
#include "frmpass.h"


VoidHand passh;


static void InitAuthPassField(void)
{
	FieldPtr fld;
	char *str;
	
	fld = GetObjectPtr(fldAuthPass);
	// allocate min 20 bytes so there is no need to resize the chunk too soon.
	passh = MemHandleNew(max(20, StrLen(actserver.auth_pass)+1)); 
	if (passh == 0)
	{
		FrmCustomAlert(altInfo, yf_mem_low, " ", " ");
		NPExitForm();
		return;
	}
	str = MemHandleLock(passh);
	StrCopy(str, actserver.auth_pass);
	MemHandleUnlock(passh);
	FldSetTextHandle(fld, (Handle) passh);
} /* InitSubsField */



Boolean AuthPassHandler(EventPtr event)
{
    int handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitAuthPassField();
            RefreshForm();
			SetFocus(fldAuthPass);
            handled = 1;
            break;
        }

        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			if (event->data.ctlSelect.controlID == btnOK)
			{
				GetVariableField(NULL, fldAuthPass, &actserver.auth_pass);
				PrefSetAppPreferences(TYPE, 11, VERSION, actserver.auth_pass, StrLen(actserver.auth_pass) + 1, 1);
			}
			NPUpdateForm(frmPrefs2Server1, 0);
			NPExitForm();
			handled = 1;
		}

        default:
    }
    return handled;
} /* AuthPassHandler */



