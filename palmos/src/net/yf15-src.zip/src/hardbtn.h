/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// hardbtn.h
//
// headers for the handling of hardbuttons for use with yanoff
// Matthias Jordan, 9-2000
//
//


#ifndef HARDBTN_H
#define HARDBTN_H

#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "segment.h"
#include "ngroup.h"


void HighlightActEntry(Word tableid, DBNGNum sel_list_item, int delete) SECTION_3;
void ScrollHighlighting(Word tableid, int lines, int advance_selection, DBNGNum *sel_list_item, DBNGNum sel_item) SECTION_3;


//
//
// Takes an event pointer
// returns 1 if Yanoff wants to handle the hardware button itself
// returns 0 if the system is supposed to handle the event
//

int HandleHardbuttons(EventPtr event) SECTION_3;



#endif

