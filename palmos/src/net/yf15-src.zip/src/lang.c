/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// lang.c
//
// Strings that can be localized
// Matthias Jordan, 7-1999
//
//

#include "lang.h"



char yf_mem_low[] = {"Memory low"},
	yf_save_art_err[] = {"Something went wrong while saving article.\nMaybe low memory.\nSorry"},
	yf_from[] = {"From: "},
	yf_nsubject[] = {"\nSubject: "},
	yf_ndate[] = {"\nDate: "},
	yf_nnewsgroups[] = {"\nNewsgroups: "},
	yf_nmsgid[] = {"\nMsgID: "},
	yf_head[] = {"Head"},
	yf_body[] = {"Body"},
	yf_header_not_avail[] = {"Header not available"},
	yf_title_subject[] = {"| Subject"},
	yf_newsgroup[] = {"| Newsgroup"},
	yf_saving_failed[] = {"Failed saving article."},
	yf_id_purge[] = {"ID Purge"},
	yf_art_purge[] = {"Art Purge"},
	yf_sample_arts[] = {"Sample Arts"},
	yf_timeout[] = {"Timeout"},
	yf_article_max[] = {"Article max"},
	yf_no_zero_val[] = {"Values of 0 are not allowed!"},
	yf_max_31_k[] = {"Max article size 31 KB. Sorry."},
	yf_name[] = {"Name"},
	yf_newsserver[] = {"Newsserver"},
	yf_mailserver[] = {"Mailserver"},
	yf_port[] = {"Port"},
	yf_already_subs[] = {" already subscribed"},
	yf_suc_unsub[] = {"Successfully unsubscribed"},
	yf_field_empty[] = {"Field empty:"},
	yf_fs_overflow[] = {"Form stack overflow"},
	yf_fs_underrun[] = {"Form stack underrun"},
	yf_srv_con_online[] = {"Server connected.\nWorking online."},
	yf_network_closed[] = {"Network closed"},
	yf_old[] = {"old"},
	yf_all[] = {"all"},
	yf_every_single[] = {"every single"},
	yf_selected[] = {"selected"},
	yf_read[] = {"read"},
	yf_articles[] = {"articles"},
	yf_art_in_db[] = {"article in the database"},
	yf_msgids[] = {"MsgIDs"},
	yf_inside_group_warning[] = {"You have to be inside a Newsgroup to unsubscribe it."},
	yf_empty_fields_not_all[] = {"Empty fields are not allowed!"},
	yf_edit[] = {"Edit"},
	yf_groups[] = {"Groups:"},

	yf_net_timeout[] = {"Timeout"},
	yf_net_socket_not_open[] = {"Socket not open"},
	yf_net_socket_busy[] = {"Socket busy"},
	yf_net_name_too_long[] = {"DNS: Name too long"},
	yf_net_bad_name[] = {"DNS: Bad name"},
	yf_net_sock_closed_remote[] = {"Socket closed by remote"},
	yf_net_error_num[] = {"Error #"},
	yf_net_unexp_resp[] = {"Unexpected server response. ("},
	yf_net_sock_usable[] = {"Socket already open and usable."},
	yf_net_lib_not_found[] = {"Network library not found."},
	yf_net_lib_connect_failed[] = {"Network connection failed"},
	yf_net_sock_open_err[] = {"Socket open error"},
	yf_net_err_alloc_buf_db[] = {"Could not allocate buffer DB"},
	yf_net_sock_close_err[] = {"Socket close error ("},
	yf_net_addr_err[] = {"Address error ("},
	yf_net_sock_con_err[] = {"Socket connect error ("},
	yf_net_auth_err[] = {"Authentication not accepted."},
	yf_net_auth_req[] = {"Authentication required"},
	yf_net_read_err[] = {"Read error ("},
	yf_net_send_err[] = {"Send error ("},
	yf_net_group_unknown[] = {"Group unknown: "},
	yf_net_art_not_on_server[] = {"Article no longer on server"},
	yf_net_nart_body[] = {"\nArticle body "},
	yf_net_narticle[] = {"\nArticle "},
	yf_net_npolling[] = {"\nPolling "},
	yf_net_nget_headers[] = {"\nGetting only headers"},
	yf_net_ngroup_entered[] = {"\nNewsgroup entered"},
	yf_net_server_port_err[] = {"Maybe wrong server name or port number."},
	yf_net_connected[] = {" connected"},
	yf_net_ninst_arts[] = {"\nInstalling articles"},
	yf_net_no_new_arts[] = {"\nNo new articles."},
	yf_net_art_post_err[] = {"Article could not be posted. I keep it in outbound."},
	yf_net_npostingemail[] = {"\nPosting eMail "},
	yf_net_npostingart[] = {"\nPosting Article "},
	yf_net_transfer[] = {"Network transfer..."},
	yf_net_nng_empty[] = {"\nNewsgroup empty"},
	yf_must_be_online[] = {"You have to be online to do this."},
	yf_complete_setup[] = {"You have to complete the setup first."},
	yf_cant_unsub_outgoing[] = {"unsubscribe"},
	yf_cant_post_to_outgoing[] = {"post to"},
	
	yf_purging_arts[] = {"Purging old Articles..."}, 
	yf_purging_msgids[] = {"Purging MsgIDs..."}, 
	yf_purging_all_arts[] = {"Purging all Articles..."}, 
	yf_reindexing[] = {"Reindexing dbase..."},

	yf_palmos_warning[] = {"Yanoff currently runs only on PalmOS 3.0 and better."},
	outgoing_group[] = {"!! Outgoing"},
	drafts_group[] = {"! Drafts"},
	
	yf_none[] = {"None"},
	yf_current_group[] = {"Current group"},
	yf_all_servers[] = {"All servers"},
	yf_copy[] = {" Copy"},
	yf_mailsrv_del[] = {"Mailserver must not be deleted!"},
	yf_standard_sig[] = {"-- \nPiloteers do it on the road\n"},
	yf_ng_set_to_dont_poll[] = {"Newsgroup set to \"Don't poll\"."},
	yf_this_server[] = {"this server"},
	yf_and_articles[] = {" and its outgoing articles"},
	yf_dummy_server[] = {"nowhere.zzz"},
	yf_no_server_for_group[] = {"Enter newsgroup prefs and specify a server!"};
	
	