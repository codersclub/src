/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmnglist.c
//
// handle the newsgroups list form
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
//	#include <System/Chars.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "subscrdb.h"
#include "frmartlist.h"
#include "ngroup.h"
#include "prefs.h"
#include "lang.h"
#include "network.h"
#include "frmnglist.h"
#include "hardbtn.h"
#include "mainmenu.h"


static FontID ListFont = stdFont;
DBNGNum top_newsgroup = 0,
		sel_ng_in_list = 0;
int ng_scroll_acc;		
Word nglistpagesize;





void FrmNGListAdvanceSelNGNum(int dir)
{
	ng_scroll_acc += dir;
} /* FrmNGListAdvanceSelNGNum */



static void HighlightActNG(int delete)
{
	HighlightActEntry(tblNewsgroups, sel_ng_in_list, delete);
} /* HighlightActNG */


static DBNGNum SelNGNum(void)
{
	return top_newsgroup + sel_ng_in_list;
} /* SelNGNum */




//
//
//  Init newsgroups list table
//
//



static void NewsgroupsDrawLabels(void)
{
	int extx = 160, // was 151
		x = 1, 
		y = 16;
	RectangleType r;

	r.topLeft.x = 0;
	r.topLeft.y = y;
	r.extent.x = extx;
	r.extent.y = 12;  
	WinEraseRectangle(&r, 0);

	if (yprefs.ngspx > 5)
	{
		DrawItemString("#", x, y, yprefs.ngspx);
	}

	if (yprefs.ngspx < (extx - 5))
	{
		DrawItemString(yf_newsgroup, x + yprefs.ngspx, y, extx - yprefs.ngspx - 1);
	}	
	
	WinInvertRectangle(&r, 0);
	WinDrawGrayLine(0, 142, 160, 142);
} /* NewsgroupsDrawLabels */


#ifndef OS35
static void NewsgroupsListDrawItem(VoidPtr table, Word row, Word column, 
	RectanglePtr bounds)
#else	
static void NewsgroupsListDrawItem(VoidPtr table, Int16 row, Int16 column, 
	RectangleType *bounds)
#endif
{
	DBNGNum recnum;
	char *dum,
		numdum[6];
	short x, y;
	DBArtNum count;

CALLBACK_PROLOGUE
	
	recnum = TblGetRowID(table, row);
	x = bounds->topLeft.x + 1;
	y = bounds->topLeft.y;
	FntSetFont(ListFont);
	SubSeekSubscription2(recnum, &dum);
	WinEraseRectangle(bounds, 0);
	if (yprefs.ngspx > 5)
	{
		NGOpenNewsgroupByPos(recnum);
		count = NGArticlesCount();
		NGCloseNewsgroup();
		StrIToA(numdum, count);
		DrawItemString(numdum, x, y, yprefs.ngspx - 2);
	}
	if (yprefs.ngspx < (bounds->extent.x - 5))
	{
		DrawItemString(dum, x + yprefs.ngspx, y, bounds->extent.x - yprefs.ngspx);
	}
	
CALLBACK_EPILOGUE

} /* NewsgroupsListDrawItem */



//
//
//  Initialize the newsgroups list table
//	lines: number of rows scrolled - to calculate what rows have to
//  be marked invalid to be redrawn.
//  lines == 0 -> init of table
//

static void InitNewsgroupsTable(int lines)
{
	TablePtr table;
	RectangleType r;
	FontID curFont;
	Word row,
		 numrows,
		 tableheight,
		 lineheight;
	DBNGNum	 currecord,
		 lastrecord;
	char *ng;

	
	table = GetObjectPtr(tblNewsgroups);
	TblGetBounds(table, &r);
	tableheight = r.extent.y;

	curFont = FntSetFont(ListFont);
	lineheight = FntLineHeight();
	FntSetFont(curFont);
	

	currecord = top_newsgroup;

	numrows = TblGetNumberOfRows(table);
	nglistpagesize = numrows - 1;

	for (row = 0; row < numrows; row++)
	{
		if (!SubSeekSubscription2(currecord, &ng))
		{
			// newsgroup number currecord exists
			TblSetRowID(table, row, currecord);
			TblSetItemStyle(table, row, 0, customTableItem);
			TblSetRowHeight(table, row, lineheight);
			TblSetRowData(table, row, currecord);
			TblSetRowUsable(table, row, true);
			if ((!lines || (!row && (lines < 0))|| (lines >= (int) numrows))
				|| ((lines > 0) && ((numrows - 1 - lines) < row) && (row < numrows))
				|| ((lines < 0) && (0 <= row) && (row < -lines)))
			{
				TblMarkRowInvalid(table, row);
			}
			lastrecord = currecord;
			if (row+1 < numrows)
			{
				currecord++;
			}
		}
		else
		{
			TblSetRowUsable(table, row, false);
		}
	}
	TblSetCustomDrawProcedure(table, 0, NewsgroupsListDrawItem);
	TblSetColumnUsable(table, 0, true);
	if (SubSubscriptionsCount() > numrows)
	{
		TblHasScrollBar(table, true);
		SclSetScrollBar(GetObjectPtr(sbNewsgroups), top_newsgroup, 0, SubSubscriptionsCount() - numrows, numrows - 1);
	}
	else
	{
		TblHasScrollBar(table, false);
		SclSetScrollBar(GetObjectPtr(sbNewsgroups), 0, 0, 0, 0);
	}
	TblRedrawTable(table);
} /* InitNewsgroupsTable */


// Code from Eric  Kenslow and Bozidar Benc (LauncherIII)

static void ShowRAM(void)
{
	ULong freeRamSize, ramSize, heapSize, freeHeapSize, maxHeapSize,
		totalSize, usedSize;
	char dum[20];
	short text_len;

	MemCardInfo(0, NULL, NULL, NULL, NULL, NULL, &ramSize, &freeRamSize);
	heapSize = 65536;
	MemHeapFreeBytes(0, &freeHeapSize, &maxHeapSize);
	if (romVersion < 0x02000000)
	{
		totalSize = ramSize;
	}
	else
	{
		totalSize = (ramSize - heapSize);
	}
	usedSize = totalSize - (freeRamSize - freeHeapSize);
	freeRamSize = totalSize - usedSize;
	StrIToA(dum, freeRamSize / 1024); 
	StrCat(dum, " KB free");
	text_len = FntLineWidth(dum, StrLen(dum));
	WinDrawChars(dum, StrLen(dum), 155 - text_len, 1);
} /* ShowRAM */




static void ScrollNGList(int lines, int advance_selection)
{
	Int i;
	Word rows, 
		lastRow, 
		scrollAmount = 0;
	DBNGNum new_top;
	TablePtr table;
	RectangleType scrollR;
	RectangleType vacated;
	DirectionType direction = up;


	table = GetObjectPtr (tblNewsgroups);
	rows = TblGetNumberOfRows(table);

	new_top = GetNewTopline(top_newsgroup, SubSubscriptionsCount(), rows, lines);
	lines = new_top - top_newsgroup;
	
	if (lines)
	{
		HighlightActNG(1);
		top_newsgroup = new_top;

		if (((lines > 0) && (lines < rows)) ||
			 ((lines < 0) && (-lines < rows)))
		{
			scrollAmount = 0;
	
			if (lines > 0)
			{
				lastRow = TblGetLastUsableRow(table) - 1;
				for (i = 0; i < lines; i++)
				{
					scrollAmount += TblGetRowHeight(table, lastRow);
					TblRemoveRow(table, 0);
				}
				direction = up;
			}
			else
			{
				for (i = 0; i < -lines; i++)
				{
					scrollAmount += TblGetRowHeight(table, 0);
					TblInsertRow(table, 0);
				}
				direction = down;
			}
	
			TblGetBounds(table, &scrollR);
			scrollR.topLeft.x -= 1;
	//		scrollR.topLeft.y -= 1;
	//		scrollR.extent.x += 2;
	//		scrollR.extent.y += 1;
	
			WinScrollRectangle(&scrollR, direction, scrollAmount, &vacated);
			WinEraseRectangle(&vacated, 0);
		}

		InitNewsgroupsTable(lines);
		TblRedrawTable(table);
		HighlightActNG(0);
		
	}

	ScrollHighlighting(tblNewsgroups, lines, advance_selection, &sel_ng_in_list, SelNGNum());
} /* ScrollNGList */


//
//
// dir is -1 or 1. No other values allowed
//

static void ScrollNGDirection(int dir)
{
	TablePtr table;
	Word rows;
	int scroll = 0;


	table = GetObjectPtr (tblNewsgroups);
	rows = TblGetNumberOfRows(table);

	if (((dir > 0) && (dir < rows) && (sel_ng_in_list <= ((rows - 1) - dir)))
		|| ((dir < 0) && (dir > -rows) && (sel_ng_in_list >= (0 - dir))))
	{
		scroll = 0;
	}
	else 
	{
		scroll = CalcPageSize(dir, rows);
	}

	ScrollNGList(scroll, dir);
} /* ScrollNGDirection */




static void EnterNewsgroup(EventPtr event)
{
	TablePtr table;
	Short row;
	DBNGNum ngnum;

	row = event->data.tblSelect.row;
	table = event->data.tblSelect.pTable;
	ngnum = TblGetRowID(table, row);
	HighlightActNG(1);
	active_ng_num = ngnum;
	sel_ng_in_list = row;
	HighlightActNG(0);
	ArtListGotoNewsgroup(ngnum);
} /* EnterNewsgroup */




static void RecallSavedState(void)
{
	if (ystate.currently_writing_article != -1)
	{
		EditSavedArticle();
	}	
} /* RecallSaveState */






Boolean HandleNewsgroups(EventPtr event)
{
    int handled = 0;
    
    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitNewsgroupsTable(0);
            RefreshForm();
			ShowRAM();
			NewsgroupsDrawLabels();
			RecallSavedState();
			HighlightActNG(0);
            handled = 1;
            break;
		}

		case frmUpdateEvent:
        {
			if (event->data.frmUpdate.updateCode == 1)
			{
				NewsgroupsDrawLabels();
				InitNewsgroupsTable(0);
			}
			ShowRAM();
			HighlightActNG(0);
			if (ng_scroll_acc)
			{
				ScrollNGDirection(ng_scroll_acc);
				ng_scroll_acc = 0;
			}
            handled = 1;
            break;
		}

        case menuEvent:
        {
			handled = HandleMainMenu(event);
			break;
        }

		case keyDownEvent:
		{
			switch (event->data.keyDown.chr)
			{
				case pageUpChr:
				{ 
					ScrollNGDirection(-1);
					handled = 1; 
					break;
				}
				
				case pageDownChr:
				{
					ScrollNGDirection(1);
					handled = 1; 
					break;
				}
				
				case vchrHard2:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						ArtListGotoNewsgroup(SelNGNum());
					}
					handled = 1; 
					break;
				}

				case vchrHard4:
				{
					if (yprefs.buttons == yfButtonsLayout_left)
					{
						ArtListGotoNewsgroup(SelNGNum());
					}
					handled = 1; 
					break;
				}
		
				default :
			}
			break;
		}        

		case sclRepeatEvent:
		{
			ScrollNGList(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value, 0);
			break;
		}

		case ctlSelectEvent:
		{
			if (event->data.ctlSelect.controlID == btnNewsgroupsSendPoll)
			{
				PrGetPollPrefs(pprefs_all, &pprefs);
				NPInvokePoll(pollNormally, 0);
				break;
			}
		}

		case tblEnterEvent:
		{
			EnterNewsgroup(event);
			handled = 1;
		}

		case penDownEvent:
		{
			if ((event->screenY < nglisttop) && (event->screenY >= FIRSTY))
			{
				ArtListMoveColSep(tblNewsgroups, 0, event, &yprefs.ngspx);
				handled = 1;
				break;
			}
		}

        default :
    }
    return handled;
} /* HandleNewsgroups */



