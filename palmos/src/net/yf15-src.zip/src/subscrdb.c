/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// subscrdb.c
//
// newsgroup subscription management routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "artdb.h"
#include "subscrdb.h"
#include "prefs.h"
#include "lang.h"




char subscrdb_name[20] = {"NewsSubscriptions"};
char groupdb_prefix[] = {"NewsGroup-"};


// internal database descriptor
static DmOpenRef subsdb;



//
//
// All routines
// return 0 in case of success and
// return err > 0 in case of error
//


//
//
// These routines return the beginning of either the name of the 
// database that belongs to the newsgroup whose record start is referred
// to by start_of_record or its newsgroup name
//

static char *SubNGNameOffset(char *start_of_record)
{
	char *dum;

    dum = start_of_record+sizeof(ULong)+(4*sizeof(UInt))
    	+ sizeof(DBServerNum) + sizeof(UInt) + 6;
    return dum + StrLen(dum)+1;
} /* SubNGNameOffset */




//
//
// Compare function
// if comp_db_entries is 1 the function compares db entries
// if comp_db_entries is 0 the value in *a1 is a string
//
// returns values like StrCompare
//

static Int comp_subs(void *a1, void *a2, int comp_db_entries,
    SortRecordInfoPtr p1, SortRecordInfoPtr p2, VoidHand h)
{
	if (comp_db_entries)
	{
		a1 = SubNGNameOffset(a1);
    }

	a2 = SubNGNameOffset(a2);

    return StrCompare((char *)a1, (char *)a2);
} /* comp_subs */






DmOpenRef SubOpenSubscriptions(void)
{
    subsdb = NPOpenDB(subscrdb_name);
    return subsdb;
} /* SubOpenSubscriptions */



void SubCloseSubscription(void)
{
    if (subsdb != 0)
    {
		DmCloseDatabase(subsdb);
		subsdb = 0;
    }
} /* SubCloseSubscription */





//
//
// Get complete subscription information from database
// sub is a pointer to a 0-initialized struct at time of function call
// on return, sub contains pointers to database entries.
//

int SubGetSubscriptionByPos(DBNGNum pos, struct subscriptiondb_item *sub)
{
    VoidHand h;
    Ptr p;

    if (subsdb == 0)
    {
        // db open error
        return 1;
    }
    h = DmQueryRecord(subsdb, pos);
    if (h == 0)
    {
        return 2;
    }
    p = MemHandleLock(h);

    sub->last = *(ULong *) p; 
    p += sizeof(ULong);

	sub->ng_flags = *(UInt *) p;
	p += sizeof(UInt);

	sub->ng_artmaxkb = *(UInt *) p;
	p += sizeof(UInt);

	sub->ng_downmax = *(UInt *) p;
	p += sizeof(UInt);

	sub->ng_samplearts = *(UInt *) p;
	p += sizeof(UInt);

	sub->server = *(DBServerNum *) p;
	p += sizeof(DBServerNum);

	sub->last_sel = *(DBArtNum *) p;
	p += sizeof(DBArtNum);

	// skip padding
	p += 1;
	
	sub->thread_arts = *(char *) p;
	p += sizeof(char);

	sub->last_top = *(DBArtNum *) p;
	p += sizeof(DBArtNum);

    sub->title_contents = *(UInt *) p;
    p += sizeof(UInt);

    sub->dbid = (char *) p;
    p += StrLen(p) + 1;

	sub->newsgroup = (char *) p;
    p += StrLen(p) + 1;

	sub->headers = (char *) p;
	
    MemHandleUnlock(h);

    return 0;
} /* SubGetSubscriptionByPos */



DBNGNum SubGetSubscriptionPos(char *newsgroup)
{
    return DmFindSortPositionV10(subsdb, newsgroup, (DmComparF *)comp_subs, 0) - 1;
} /* SubGetSubscriptionPos */



//
//
// Read subscription information from database
//
// Pass NULL in sub field to just check whether newsgroup is found.
//
// Returns != 0 in case of error and when newsgroup isn't found.
// returns 0 in case of success and when newsgroup is found.
//

int SubGetSubscriptionByName(char *newsgroup, struct subscriptiondb_item *sub)
{
	DBNGNum pos;
    int res;
    char *ng;

    if (subsdb == 0)
    {
        // db open error
        return 1;
    }
    pos = SubGetSubscriptionPos(newsgroup);
	if (SubSeekSubscription2(pos, &ng))
	{
		return 2; // not found
	}
	if ((ng == NULL) || (StrCompare(ng, newsgroup)))
	{
		return 2;
	}
	if (sub == NULL)
	{
		return 0; 
	}
	res = SubGetSubscriptionByPos(pos, sub);

    return res;
} /* SubGetSubscriptionByName */





//
//
// Write complete subscription information to database
//

int SubSetSubscriptionInfo(DBNGNum pos, struct subscriptiondb_item *sub)
{
    VoidHand h;
    UInt dbpos;
    Ptr p;


    if (subsdb == 0)
    {
        // db open error
        return 1;
    }
	DmResizeRecord(subsdb, pos, sizeof(ULong) + (4 * sizeof(UInt)) + 10 
    	+ StrLen(sub->dbid) + 1 + StrLen(sub->newsgroup) + 1
    	+ StrLen(sub->headers) + 1);

    h = DmGetRecord(subsdb, pos);
    if (h == 0)
    {
        return 2;
    }
    p = MemHandleLock(h);

	dbpos = 0;
    DmWrite(p, dbpos, &sub->last, sizeof(ULong));
    dbpos += 4;

    DmWrite(p, dbpos, &sub->ng_flags, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmWrite(p, dbpos, &sub->ng_artmaxkb, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmWrite(p, dbpos, &sub->ng_downmax, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmWrite(p, dbpos, &sub->ng_samplearts, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmWrite(p, dbpos, &sub->server, sizeof(DBServerNum));
    dbpos += sizeof(DBServerNum);

    DmWrite(p, dbpos, &sub->last_sel, sizeof(DBArtNum));
    dbpos += sizeof(DBArtNum);

	// insert padding
	DmSet(p, dbpos, 1, 0);
	dbpos += 1;
    
    DmWrite(p, dbpos, &sub->thread_arts, sizeof(char));
    dbpos += sizeof(char);

    DmWrite(p, dbpos, &sub->last_top, sizeof(DBArtNum));
    dbpos += sizeof(DBArtNum);

    DmWrite(p, dbpos, &sub->title_contents, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmStrCopy(p, dbpos, sub->dbid);
    dbpos += StrLen(sub->dbid) + 1;

    DmStrCopy(p, dbpos, sub->newsgroup);
    dbpos += StrLen(sub->newsgroup) + 1;

    DmStrCopy(p, dbpos, sub->headers);

    MemHandleUnlock(h);
    DmReleaseRecord(subsdb, pos, 1);
    DmQuickSort(subsdb, (DmComparF *)comp_subs, 1);
    return 0;
} /* SubSetSubscriptionInfo */





char *SubNGDatabaseName(char *ng, char *buf)
{
	struct subscriptiondb_item sub;

	if (SubGetSubscriptionByName(ng, &sub))
	{
		return NULL;
	}
	StrCopy(buf, groupdb_prefix);
	StrCat(buf, sub.dbid);
	return buf;
} /* SubNGDatabaseName */




//
//
// Add subscription to database
// Subscription is added to the db, the db recurds are sorted and the
// newsgroup db is created without any records
//
// returns 0 in case of success
// returns >0 in case of error
//

int SubAddSubscription(char *newsgroup, UInt flags, DBServerNum server)
{
    ULong size, last;
    DBNGNum pos = -1;
    VoidHand h;
    struct subscriptiondb_item *p;
    char tempname[20];
    UInt numdum = 0,
         dbpos;
    struct subscriptiondb_item sub;
    char dbid[6];
    char chardum;


    if (subsdb == 0)
    {
        // db open error
        return 1;
    }

    if (!SubGetSubscriptionByName(newsgroup, &sub))
    {
        return 2;
    }
	
	if (CreateNewDatabase(groupdb_prefix, tempname, dbid) == NULL)
	{
		return 1;
	}

    size = sizeof(ULong) + (4 * sizeof(UInt)) + sizeof(DBServerNum) + 8 
    	+ StrLen(dbid) + 1 + StrLen(newsgroup) + 1 + 2;

    h = DmNewRecord(subsdb, &pos, size);
    if (h == 0)
    {
        // error
        return 3;
    }
    p = (struct subscriptiondb_item *) MemHandleLock(h);

	last = 0;
	dbpos = 0;
    DmWrite(p, dbpos, &last, sizeof(ULong));
    dbpos += 4;

	if (server == 0)
	{
		// set new groups to "dont poll" if no server given
		flags |= yfNGFlag_dont_poll; 
	}
    DmWrite(p, dbpos, &flags, sizeof(UInt));
    dbpos += sizeof(UInt);

    numdum = yprefs.artmaxkb;
    DmWrite(p, dbpos, &numdum, sizeof(UInt));
    dbpos += sizeof(UInt);

    numdum = yprefs.samplearts;  // default value for downmax
    DmWrite(p, dbpos, &numdum, sizeof(UInt));
    dbpos += sizeof(UInt);

    numdum = yprefs.samplearts;
    DmWrite(p, dbpos, &numdum, sizeof(UInt));
    dbpos += sizeof(UInt);

    DmWrite(p, dbpos, &server, sizeof(DBServerNum));
    dbpos += sizeof(DBServerNum);

    last = 0l;
    DmWrite(p, dbpos, &last, sizeof(DBArtNum));
    dbpos += sizeof(DBArtNum);

	// insert padding
	DmSet(p, dbpos, 1, 0);
	dbpos += 1;

    chardum = 0;
    DmWrite(p, dbpos, &chardum, sizeof(char));
    dbpos += sizeof(char);

    last = 0l;
    DmWrite(p, dbpos, &last, sizeof(DBArtNum));
    dbpos += sizeof(DBArtNum);

    numdum = yfNGDisplay_subject;
    DmWrite(p, dbpos, &numdum, sizeof(UInt));
    dbpos += sizeof(UInt);
    
    DmStrCopy(p, dbpos, dbid);
    dbpos += StrLen(dbid) + 1;

    DmStrCopy(p, dbpos, newsgroup);
    dbpos += StrLen(newsgroup) + 1;

    DmStrCopy(p, dbpos, "");  // No custom headers when group is created

    MemHandleUnlock(h);
    DmReleaseRecord(subsdb, pos, 1);
    DmQuickSort(subsdb, (DmComparF *)comp_subs, 1);
    return 0;
} /* SubAddSubscription */



//
//
// Init the newsgroup in which outgoing articles are stored.
//

void SubInitInternalGroups(void)
{
	if (SubGetSubscriptionByName(outgoing_group, NULL))
	{
		SubAddSubscription(outgoing_group, yfNGFlag_internal, 0);
	}
	if (SubGetSubscriptionByName(drafts_group, NULL))
	{
		SubAddSubscription(drafts_group, yfNGFlag_internal, 0);
	}
} /* SubInitInternalGroups */



//
//
// Update subscription information to database
//

#define update_what_last 0
#define update_what_top_art 1

static int SubUpdateSubscriptionData(DBNGNum pos, void *data1, void *data2, int update_what)
{
    VoidHand h;
    Ptr p;


    if (subsdb == 0)
    {
        // db open error
        return 1;
    }

    h = DmQueryRecord(subsdb, pos); // - 1
    if (h == 0)
    {
        return 2;
    }
    p = MemHandleLock(h);
	if (update_what == update_what_last)
	{
	    DmWrite(p, 0, data1, sizeof(ULong));
	}
	else
	{
	    DmWrite(p, 14, data2, sizeof(DBArtNum));
	    DmWrite(p, 18, data1, sizeof(DBArtNum));
	}
    MemHandleUnlock(h);
    return 0;
} /* SubUpdateSubscriptionData */



int SubUpdateSubscription(DBNGNum pos, ULong last)
{
	return SubUpdateSubscriptionData(pos, &last, &last, update_what_last);
} /* SubUpdateSubscription */



int SubUpdateSubscriptionTopArt(DBNGNum pos, DBArtNum top_art, DBArtNum top_sel)
{
	return SubUpdateSubscriptionData(pos, &top_art, &top_sel, update_what_top_art);
} /* SubUpdateSubscriptionTopArt */




int SubSeekSubscription2(DBNGNum pos, char **ngname)
{
    VoidHand h;
    Ptr p;


    if (subsdb == 0)
    {
        // db open error
        return 1;
    }
    h = DmQueryRecord(subsdb, pos);
    if (h == 0)
    {
        return 2;
    }
    p = MemHandleLock(h);
	*ngname = SubNGNameOffset(p);
    MemHandleUnlock(h);
	return 0;
} /* SubSeekSubscription2 */





//
//
// Delete subscribed newsgroup database and subscription entry
//

int SubDeleteSubscription(char *newsgroup)
{
    DBNGNum pos;
    LocalID lid;
    char *ngname,
    	 groupdbname[20];

    pos = DmFindSortPositionV10(subsdb, newsgroup, (DmComparF *)comp_subs, 0);
	SubSeekSubscription2(pos - 1, &ngname);
	if (StrCompare(ngname, newsgroup))
	{
		// incorrect newsgroup record found - but why the hell?!?
		return 3;
	}
	SubNGDatabaseName(newsgroup, groupdbname);
    if (DmRemoveRecord(subsdb, pos - 1) != 0)
    {
        return 4;
    }
    lid = DmFindDatabase(0, groupdbname);
    if (DmDeleteDatabase(0, lid) != 0)
    {
        return 4;
    }
    return 0;
} /* SubDeleteSubscription */









DBNGNum SubSubscriptionsCount(void)
{
    if (subsdb == 0)
    {
        // db open error
        return 0;
    }
	return DmNumRecords(subsdb);    
} /* SubSubscriptionsCount */



//
//
// The server a newsgroup is associated with is saved in the
// newsgroup record as the position of the server record in the
// server database. I.e. if there are the following servers in the database:
//
// Mailserver, Massena, Localhost, deja
//
// And a newsgroup is to be polled from Localhost, the corresponding
// subscription database record contains the value 2 in the server field.
// When a server gets deleted, the server numbers of these servers change,
// that follow the deleted server record. So the subscription database
// has to be updated.
//

void SubCorrectServerNum(DBServerNum deleted_server_num)
{
	DBNGNum count, i;
	struct subscriptiondb_item act;

	if (subsdb == 0)
	{
		return;
	}
	
	count = SubSubscriptionsCount();
	for (i = 0; (i < count); i++)
	{
		SubGetSubscriptionByPos(i, &act);
		if (!(act.ng_flags & yfNGFlag_internal))
		{
			// Group is not an internal one so server has to be updated
			if (act.server == deleted_server_num)
			{
				// Oopsa! This newsgroup doesn't have a server
				act.server = 0;
				// 0 denotes the mailserver but in newsgroup prefs
				// this becomes "none"
				act.ng_flags |= yfNGFlag_dont_poll;
			}
			else if (act.server > deleted_server_num)
			{
				act.server--;
			}
			SubSetSubscriptionInfo(i, &act);
		}
	}
} /* SubCorrectServerNum */


void SubSortSubscriptions(void)
{
	if (subsdb == 0)
	{
		return;
	}
	
	DmQuickSort(subsdb, (DmComparF *)comp_subs, 1);
} /* SubSortSubscriptions */


