/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// menu.c
//
// handle the main menu of yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "network.h"
#include "ngroup.h"
#include "subscrdb.h"
#include "lang.h"
#include "prefs.h"
#include "frmsrvsel.h"
#include "frmsubs.h"
#include "frmnglist.h"
#include "frmpost.h"
#include "frmprefs2.h"
#include "frmprefs4.h"
#include "mainmenu.h"


int HandleMainMenu(EventPtr event)
{
	int handled = 0;
	char *ng;


	switch (event->data.menu.itemID)
	{
		case mConn:
	    {
//			if (!NPInitNetwork() && !NPConnect())
//			{
//				FrmCustomAlert(altInfo, yf_srv_con_online," ", " ");
//				NPWorkOnline(1); // set internal flag
//			}
//			NPGotoForm(frmServerSelection);
        	handled = 1;
        	break;
	    }
	    
	    case mDisc:
	    {
			NPCloseNetwork(1, 0);
			FrmCustomAlert(altInfo, yf_network_closed, " ", " ");
	        handled = 1;
	        break;
	    }

	    case mAbout:
	    {
			NPGotoForm(frmAbout);
    	    handled = 1;
    	    break;
	    }

	    case mNewArticle:
	    {
    		if (!NGNewsgroupOpen())
	    	{
		    	InvokeServerSelection(0, artModeNewsgroup, NULL, NULL, NULL, NULL);
		    } 
		    else
		    {
		    	ng = NGActiveNewsgroup();
//		    	if (StrCompare(ng, outgoing_group))
		    	if (!(active_ng.ng_flags & yfNGFlag_internal))
		    	{
			    	InvokePost(0, artModeNewsgroup, ng, NULL, NULL, NULL, 0);
			    }
				else
				{
					FrmCustomAlert(altChangeInternalGroup, yf_cant_post_to_outgoing, " ", " ");
				}
			}
	        handled = 1;
	        break;
	    }

	    case mNewEMail:
	    {
    		ng = NGActiveNewsgroup();
	    	InvokePost(0, artModeEMail, NULL, NULL, NULL, NULL, 0);
	        handled = 1;
	        break;
	    }
	    
	    case mPoll:
	    {
			if (NGNewsgroupOpen())
			{
				PrGetPollPrefs(pprefs_ng, &pprefs);
			}
			else
			{
				PrGetPollPrefs(pprefs_all, &pprefs);
			}
			NPInvokePoll(pollNormally, 0);
	        handled = 1;
	        break;
	    }
	    
	    case mPollPrefs:
	    {
    	    NPGotoForm(frmPrefsPoll);
	        handled = 1;
	        break;
	    }
	    
	    case mPrefs1:
	    {
    	    NPGotoForm(frmPrefs1Other);
	        handled = 1;
	        break;
	    }
	    
	    case mPrefs2:
	    {
			PrefsInvokeServer(0);
	        handled = 1;
	        break;
	    }

	    case mPrefs4:
	    {
//    		if (StrCompare(NGActiveNewsgroup(), outgoing_group))
	    	if (!(active_ng.ng_flags & yfNGFlag_internal))
	    	{
//		        NPGotoForm(frmPrefs4Newsgroup);
				InvokePrefs4Newsgroups(ngprefs_called_from_menu);
		    }
		    else
		    {
		    	FrmCustomAlert(altChangeInternalGroup, "change the setting for", " ", " ");
		    }
	        handled = 1;
	        break;
	    }

	    case mReindex:
	    {
			if (!FrmAlert(altReindex))
			{
				NGPurge(purgeReindex);
			}
	        handled = 1;
	        break;
	    }

	    case mResetNewsgroup:
	    {
    		NGResetNewsgroup();
	    	handled = 1;
	    	break;
	    }

	    case mPurgeArts:
	    {
			if (!FrmCustomAlert(altDeleteConf, yf_old, yf_articles, " "))
			{
				NGPurge(purgeArticles);
			}
	        handled = 1;
			break;
	    }

	    case mPurgeAllArts:
	    {
			if (!FrmCustomAlert(altDeleteConf, yf_all, yf_articles, " "))
			{
				if (!FrmCustomAlert(altDeleteConf, yf_every_single, yf_art_in_db, " "))
				{
					NGPurge(purgeAllArts);
				}
			}
	        handled = 1;
	        break;
	    }
	    
	    case mPurgeIDs:
	    {
			if (!FrmCustomAlert(altDeleteConf, yf_old, yf_msgids, " "))
			{
				NGPurge(purgeMsgIDs);
			}
	        handled = 1;
	        break;
	    }
	    
	    case mDeleteSel:
	    {
			if (!FrmCustomAlert(altDeleteConf, yf_selected, yf_articles, " "))
			{
				NGDeleteSelectedRead(0);
			}
	        handled = 1;
	        break;
	    }

	    case mDeleteRead:
	    {
			if (!FrmCustomAlert(altDeleteConf, yf_read, yf_articles, " "))
			{
				NGDeleteSelectedRead(1);
			}
	        handled = 1;
	        break;
	    }
	    
	    case mKeepSel:
	    {
			NGKeepSelected(1);
	        handled = 1;
	        break;
	    }
	    
	    case mUnkeepSel:
	    {
			NGKeepSelected(0);
	        handled = 1;
	        break;
	    }

		case mToggleReadSel:
		{
			NGToggleReadSelected();
			handled = 1;
			break;
		}
	    
	    case mSelAll:
	    {
	    	NGMarkArticles(1);
	        handled = 1;
	        break;
	    }

	    case mSelNone:
	    {
    		NGMarkArticles(0);
	        handled = 1;
	        break;
	    }
	    
	    case mSelInv:
	    {
    		NGMarkArticles(-1);
        	handled = 1;
        	break;
	    }
	    
	    case mSubs:
	    {
    	    NPGotoForm(frmSubscribe);
	        handled = 1;
	        break;
	    }
	    
		case mUnsubs:
	    {
	    	ng = NGActiveNewsgroup();
	    	if (ng != NULL)
	    	{
//	    		if (StrCompare(ng, outgoing_group))
		    	if (!(active_ng.ng_flags & yfNGFlag_internal))
	    		{
					if (FrmCustomAlert(altUnsubs, ng, " ", " ") == 0)
					{
						Unsubscribe(ng);
						NPUpdateForm(frmNewsgroups, 1);
						NPExitForm();
					}
				}
				else
				{
					FrmCustomAlert(altChangeInternalGroup, yf_cant_unsub_outgoing, " ", " ");
				}
			}
			else
			{
				FrmCustomAlert(altInfo, yf_inside_group_warning, " ", " ");
			}
	        handled = 1;
	        break;
	    }
	    
	    default:
	} // switch	
    return handled;
} /* HandleMainMenu */

