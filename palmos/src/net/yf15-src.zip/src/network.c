/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// network.c
//
// Network routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/SysEvtMgr.h>
	#include <System/SoundMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "network.h"
#include "artdb.h"
#include "msgiddb.h"
#include "ngroup.h"
#include "prefs.h"
#include "subscrdb.h"
#include "serverdb.h"
#include "lang.h"
#include "frmprefsp.h"
#include "frmart.h"
#include "frmnglist.h"
#include "frmartlist.h"



#define yfErrSuccess 0
#define yfErrSkip 1
#define yfErrAlreadyRead 1
#define yfErrArticleRejected 1
#define yfErrNotOnServer 2
#define yfErrSevere 3


typedef unsigned long SrvArtNum;












#ifdef PRC2

// start ##############

//int NPOnlineMode(void) SECTION_3;
//void NPWorkOnline(int mode) SECTION_3;
//int NPNetworkLayerUp(void) SECTION_3;
static char *NPErrorName(void) SECTION_3;
static void NPResponseAlert(char *response, char *info) SECTION_3;
static void NPDeleteBufferDatabase(void) SECTION_3;
static Ptr AllocateBuffer(Word *len, Word min, VoidHand *h) SECTION_3;
static Ptr NewBuffer(UInt artmaxkb) SECTION_3;
static void CloseBuffer(void) SECTION_3;
//int NPCloseNetwork(int immediately, int for_reopening) SECTION_3;
static int NPConnectNetwork(void) SECTION_3;
//int NPInitNetwork(void) SECTION_3;
static int NPConnect2(struct serverdb_item *srv) SECTION_3;
static void NPQuitServer(void) SECTION_3;
static int NPBringUpLink(void) SECTION_3;
static int ErrorCodeNonSevere(char *code) SECTION_3;
static SWord NPReadN(char *buf, Word pos, Word size) SECTION_3;
static SWord NPRead(char *buf, Word size) SECTION_3;
static int AnswerCodeOK(char *c, char *exp_answer) SECTION_3;
static int SkipResponse(char *buf, Word size) SECTION_3;
static Word NPGetAnswer(char *b, Word size, char *exp_answcode, int wait_on_dotterm) SECTION_3;
static SWord NPWriteN(char *buffer, Word size) SECTION_3;
static SWord NPWrite(char *buf) SECTION_3;
static SWord NPWriteP(char *b1, char *b2, char *b3) SECTION_3;
static SrvArtNum NextNum(char *p, int *pos) SECTION_3;
static int NPGroup(char *newsgroup, SrvArtNum *num, SrvArtNum *min, SrvArtNum *max) SECTION_3;
static char *NPMemCopy(char *dest, char *start, char *end) SECTION_3;
static char *GetHeaderField(char *header, char *buf, int optional) SECTION_3;
static char *FindMsgID(char *buf) SECTION_3;
static int NPGetArticleHeader2DB(SrvArtNum num, DBArtNum *pos) SECTION_3;
static int NPGetArticleBody2DB(DBArtNum pos) SECTION_3;
static int AbortButtonPressed(void) SECTION_3;
static void InitPollField(void) SECTION_3;
static void FieldFlush(void) SECTION_3;
static void FieldCompact(void) SECTION_3;
static void FieldOutput(char *str) SECTION_3;
static void FieldOutputRes(int header, int res) SECTION_3;
static void FieldOutputNum(ULong act, ULong max) SECTION_3;
static int NPPollNewsgroupBodyNG(DBArtNum posinng, DBArtNum max) SECTION_3;
static int NPPollNewsgroupBodies(void) SECTION_3;
static int NPPollNewsgroupHeaders(SrvArtNum last,
		SrvArtNum min, SrvArtNum maxart, int mode) SECTION_3;
static int NPPollNewsgroup(DBNGNum ng_num, int open) SECTION_3;
static void NPPollNewsgroupsFrom(DBServerNum srvnum) SECTION_3;
static void NPUpdateDatabases(UInt start) SECTION_3;
static void NPPollSingleBody(void) SECTION_3;
static Word GetQPrefix(char *str, char *prefix, int max) SECTION_3;
static void WriteBodyWordwrapped(char *body) SECTION_3;
static void NPWriteCustomHeaders(char *h) SECTION_3;
static int NPPostArticle(DBArtNum pos, DBArtNum act, DBArtNum max,
	DBServerNum snum, struct serverdb_item *srv) SECTION_3;
static DBArtNum NPPostArticles(DBServerNum snum, struct serverdb_item *srv) SECTION_3;
static char *GenRCPT(char *toline) SECTION_3;
static int NPPostEMailMessage(DBArtNum pos, DBArtNum act, DBArtNum max,
	struct serverdb_item *srv) SECTION_3;
static DBArtNum NPPostEMail(struct serverdb_item *srv) SECTION_3;
static void NPPollServers(void) SECTION_3;
//int HandlePoll(EventPtr event) SECTION_3;
//void NPInvokePoll(int mode, DBArtNum pos) SECTION_3;

#else

// Some prototypes. I hate them, but they are useful, sometimes.

static SWord NPWrite(char *buf);
static Word NPGetAnswer(char *b, Word size, char *exp_answcode, int wait_on_dotterm);

#endif















//
//
// Some definitions. Initially, we want a buffer of size buf_len bytes.
// NPInitNetwork will try to allocate a chunk of this size, sizing down
// in the event of an error (i.e. mem low).
// The real size of the allocated buffer is stored in buf_len.
// The same for the skip buffer into which data to be skipped is read
//

DmOpenRef buf_db = 0;
Ptr buf;
VoidHand buf_h;
Word buf_len;
Ptr skipbuf;
VoidHand skipbuf_h;
Word skipbuf_len = 4069;
char bufferdb_name[] = {"Newsbuffer"};


char zeroterm = 0;
char none[] = {"-None-"};
int pollmode;
DBArtNum pollart;

Err err;
char errname[30],
	lastresultcode[4];
Word nl = 0; /* Library-Reference */
NetSocketRef sock = -1;
NetSocketAddrINType remote;
Long timeoutticks;



int mode_online = 0;   // we operate online (that is, don't close network after work)
struct subscriptiondb_item actng;

UInt oldautooff;	
FieldPtr poll_fld;
VoidHand poll_h;





//
// ------------------------------------------------------------------
//
//  Routines for initializing or closing the network connection
//  for use with Yanoff. 
//  There are two modes: Online operation and offline.
//
//  Online operation works as follows:
//
//  Before the user can get articles from the net she has to
//  establish a connection: First initialize the network interface, 
//  then connect to the server. Maybe the Pilot already has a usable
//  network interface connection, maybe the link gets established
//  with all the UI-action this implicates. We don't care about that.
//  The server connection is maintained all the time until the user
//  decides to cut it off or she quits the application. In the latter
//  case only the server is quit and the socket is shut down so 
//  other apps can use the link. 
//  
//  Offline operation goes like this:
//
//  The user may be offline or not. Anyway, she decides to get some
//  information from the UseNet and selects "Get Headers", "Get Articles" or
//  "Get Bodies" without a usable network interface. So the interface is
//  brought up, the data is retrieved and the interface is closed again
//  along with net lib. So if no other app uses the interface within 
//  the system timeout, the connection is cut (modem hangs up, whatever).
//
// ------------------------------------------------------------------
//


int NPOnlineMode(void)
{
	return mode_online;
} /* NPOnlineMode */


void NPWorkOnline(int mode)
{
	mode_online = mode;
} /* NPWorkOnline */




int NPNetworkLayerUp(void)
{
	NetMasterPBType pbP;
	Word nl;
	
	// Maybe network has not been initialized yet so find netlib in either case.
	err = SysLibFind("Net.lib", &nl);
    if (err)
    {
        return 0;
    }

	pbP.param.interfaceInfo.index = 0;
	NetLibMaster(nl, netMasterInterfaceInfo, &pbP, timeoutticks);

	return (pbP.param.interfaceInfo.driverUp && pbP.param.interfaceInfo.ifUp);
} /* NPNetworkLayerUp */






//
//
// Returns const char with error name based on error number
// netErrorClass == 0x1200
//

static char *NPErrorName(void)
{
    switch (err)
    {
        case netErrTimeout: StrCopy(errname, yf_net_timeout); break;
        case netErrSocketNotOpen: StrCopy(errname, yf_net_socket_not_open); break;
        case netErrSocketBusy : StrCopy(errname, yf_net_socket_busy); break;
        case netErrDNSNameTooLong: StrCopy(errname, yf_net_name_too_long); break;
        case netErrDNSBadName: StrCopy(errname, yf_net_bad_name); break;
        case netErrSocketClosedByRemote: StrCopy(errname, yf_net_sock_closed_remote); break;
//        case netErr: StrCopy(errname, ""); break;
        default:
            {
                StrCopy(errname, yf_net_error_num);
                StrIToA(&errname[StrLen(errname)], (Long) err);
                StrCat(errname, " (");
                StrIToA(&errname[StrLen(errname)], (Long) err - 0x1200);
                StrCat(errname, ")");
            }
    }
    return errname;
} /* NPErrorName */




static void NPResponseAlert(char *response, char *info)
{
	char dum[20];
	
	StrCopy(dum, ") ");
	StrCat(dum, info);
	FrmCustomAlert(alertID_dum, yf_net_unexp_resp, response, dum);
} /* NPResponseAlert */



//
//
// Delete database that served as buffer dummy (and is empty)
// Qualifies as candidate for StopApplication
//

static void NPDeleteBufferDatabase(void)
{
    LocalID lid;

    lid = DmFindDatabase(0, bufferdb_name);
	if (lid != 0)
	{
	    DmDeleteDatabase(0, lid);
	}
} /* NPDeleteBufferDatabase */





//
//
// Allocate buffers with intended size *len and minimum size min
// Real size and the associated handle are stored in *len and *h, resp.
//
// Returns pointer to buffer chunk or NULL in case of error.
//

static Ptr AllocateBuffer(Word *len, Word min, VoidHand *h)
{
    char numdum[20];
    Ptr b;

    do
    {
        *h = DmNewHandle(buf_db, *len);
        if (*h == 0)
        {
            *len /= 2; // Buffer too big, try half sized one
        }
    }
    while ((*h == 0) && (*len >= min));

    if (*h == 0)
    {
        StrIToA(numdum, min);
        FrmCustomAlert(alertID_dum, yf_mem_low, " ", " ");
        return NULL;
    }
    b = (Ptr) MemHandleLock(*h);
    return b;
} /* AllocateBuffer */


static Ptr NewBuffer(UInt artmaxkb)
{
    // Allocate min 3 KB for header. Better overkill than miss any data
    buf_len = max(artmaxkb, 3) * 1024; 
    buf = AllocateBuffer(&buf_len, 3072, &buf_h);
    return buf;
} /* NewBuffer */


static void CloseBuffer(void)
{
	if (buf_h != 0)
	{
	    MemHandleUnlock(buf_h);
	    MemHandleFree(buf_h);
	    buf_h = 0;
	    buf = NULL;
	}
} /* CloseBuffer */


//
//
// Closes NetLibrary and socket, frees transfer buffer
//
// returns 0 if successful
// returns err > 0 if error and pops up an alert
//


int NPCloseNetwork(int immediately, int for_reopening)
{
	if (sock != -1)
	{
	    NetLibSocketClose(nl, sock, timeoutticks, &err);
	    sock = -1;
	}
	if (nl != 0)
	{
	    // bring down interface (i.e. hang up modem)
	    err = NetLibClose(nl, immediately);
	}
	if (!for_reopening)
	{
		CloseBuffer();
		if (skipbuf_h != 0)
		{
		    MemHandleUnlock(skipbuf_h);
		    MemHandleFree(skipbuf_h);
		    skipbuf_h = 0;
		    skipbuf = NULL;
		}
		if (buf_db != 0)
		{
		    DmCloseDatabase(buf_db);
		    NPDeleteBufferDatabase();
		    buf_db = 0;
		}
		mode_online = 0;
	}
    return err;
} /* NPCloseNetwork */



static int NPConnectNetwork(void)
{
    Word openerror;

    err = SysLibFind("Net.lib", &nl);
    if (err)
    {
        FrmCustomAlert(alertID_dum, yf_net_lib_not_found, " ", " ");
        return 1;
    }

	if (!NPNetworkLayerUp())
	{
		FrmCustomAlert(altInfo, "Network layer has been shut down.\nReopening...", " ", " ");
		NPCloseNetwork(1, 1);
	}

    err = NetLibOpen(nl, &openerror);
    if (openerror || (err && (err != netErrAlreadyOpen)))
    {
        FrmCustomAlert(alertID_dum, yf_net_lib_connect_failed, " ", " ");
		if (openerror)
		{
			NetLibClose(nl, 1);
		}
        return 2;
    }
    return 0;
} /* NPConnectNetwork */









//
//
// Opens NetLibrary if availiable and socket.
// NPInitNetwork will try to allocate a chunk of size buf_len, sizing down
// in the event of an error (i.e. mem low).
// The real size of the allocated buffer is stored in buf_len.
//
// returns 0 if successful
// returns err > 0 if error and pops up an alert
//

int NPInitNetwork(void)
{
    int res;

	buf_h = 0;
	timeoutticks = 20 * sysTicksPerSecond;

	res = NPConnectNetwork();
	if (res != 0)
	{
		return res;
	}


    sock = NetLibSocketOpen(nl, netSocketAddrINET, netSocketTypeStream, NetHToNS(6), timeoutticks, &err);
    if (sock == -1)
    {
        FrmCustomAlert(alertID_dum, yf_net_sock_open_err, " ", " ");
        NetLibClose(nl, 0);
        return 3;
    }

  	if (buf_db == 0)
  	{
	    // Allocate transfer buffer database and let buf point to the buffer
	    buf_db = NPOpenDB(bufferdb_name);
	    if (buf_db == 0)
	    {
	        FrmCustomAlert(alertID_dum, yf_net_err_alloc_buf_db, " ", " ");
			NPCloseNetwork(0, 0);
	        return 4;
	    }
	}
	if (buf == NULL)
	{
		buf = NewBuffer(yprefs.artmaxkb);
	    if (buf == NULL)
	    {
			NPCloseNetwork(0, 0);
	        return 5;
	    }
	}
	if (skipbuf == NULL)
	{
	    skipbuf = AllocateBuffer(&skipbuf_len, 1024, &skipbuf_h);
	    if (skipbuf == NULL)
	    {
			NPCloseNetwork(0, 0);
	        return 6;
    	}
    }
    err = 0;
    return 0;
} /* NPInitNetwork */












//
// ------------------------------------------------------------------
//
//    Routines for connecting to a server and exiting the server
//
// ------------------------------------------------------------------
//



//
//
// Connects Device to specified server. If server contains an FQDN
// the function gets the IP address by a DNS lookup.
//
// returns 0 if success
// returns err > 0 in case of error
//

static int NPConnect2(struct serverdb_item *srv)
{
    NetHostInfoBufType hostinfo;
    SWord num;
    UInt address_pos = 0;
    
	timeoutticks = srv->timeoutsecs * sysTicksPerSecond;
    err = 0;
    if (StrHasLetter(srv->address))
    {
		MemSet(&hostinfo, sizeof(hostinfo), 0);
        if (!NetLibGetHostByName(nl, srv->address, &hostinfo, timeoutticks, &err))
        {
            NPErrorName();
            FrmCustomAlert(alertID_dum, yf_net_addr_err, errname, ")");
            return 1;
        }
    }
    else
    {
        hostinfo.address[0] = NetLibAddrAToIN(nl, srv->address);
        if (remote.addr == -1)
        {
            err = netErrDNSBadName;
            NPErrorName();
            FrmCustomAlert(alertID_dum, yf_net_addr_err, errname, ")");
            return 2;
        }
    }

	do
	{
		num = -1;
	    remote.family = netSocketAddrINET;
	    remote.port = srv->port;
		do
		{
			remote.addr = hostinfo.address[address_pos];
		}
		while (!remote.addr && (++address_pos < netDNSMaxAddresses));

		if (remote.addr)
		{
//			{
//				char dum[20];
//				NetLibAddrINToA(nl, remote.addr, dum);
//				YdebugSI("Try ", address_pos+1);
//				Ydebug("Address: ", dum, " ");
//			}
	
		    num = NetLibSocketConnect(nl, sock, (NetSocketAddrType *)&remote, sizeof(remote), timeoutticks, &err);
		}
	}
	while ((num == -1) && (++address_pos < netDNSMaxAddresses));
	
    if (num == -1)
    {
	    NetLibSocketClose(nl, sock, timeoutticks, &err);
	    sock = NetLibSocketOpen(nl, netSocketAddrINET, netSocketTypeStream, NetHToNS(6), timeoutticks, &err);
	    if (sock == -1)
	    {
	        FrmCustomAlert(alertID_dum, yf_net_sock_open_err, " ", " ");
	        return 3;
	    }
		num = NetLibSocketConnect(nl, sock, (NetSocketAddrType *)&remote, sizeof(remote), timeoutticks, &err);
	    if (num == -1)
	    {
    	    NPErrorName();
	        FrmCustomAlert(alertID_dum, yf_net_sock_con_err, errname, ")");
	        return 3;
	    }
	}
    
    if (srv->use_auth)
    {
	    NPGetAnswer(buf, buf_len, "", 0); // skip answer and ingnore what comes
    	NPWrite("authinfo user ");
    	NPWrite(srv->auth_user);
    	NPWrite(crlf);
    	if (NPGetAnswer(buf, buf_len, "381", 0))
    	{
	    	NPWrite("authinfo pass ");
	    	NPWrite(srv->auth_pass);
	    	NPWrite(crlf);
	    	if (!NPGetAnswer(buf, buf_len, "281", 0))
	    	{
	    		FrmCustomAlert(altInfo, yf_net_auth_err, " ", " ");
	    		return 1;
	    	}
	    }
	    else
	    {
    		FrmCustomAlert(altInfo, yf_net_auth_err, " ", " ");
    		return 1;
	    }
    }
    else
    {
    	// Skip server status message
	    if (NPGetAnswer(buf, buf_len, "200", 0))
	    {
	    	// do nothing
	    }
	}
    return 0;
} /* NPConnect2 */


static void NPQuitServer(void)
{
	NPWrite("QUIT\r\n");
	NPGetAnswer(buf, buf_len, "205", 0);
	if (sock != -1)
	{
	    NetLibSocketClose(nl, sock, timeoutticks, &err);
	    sock = -1;
	}
} /* NPQuitServer */



static int NPBringUpLink(void)
{
	if (!NPOnlineMode() || !NPNetworkLayerUp())
	{
	    if (NPInitNetwork())
	    {
	        // Error is reported in NPInitNetwork
	        return 1;
	    }
	}
	return 0;
} /* NPBringUpLink */







//
// ------------------------------------------------------------------
//
//         Routines for network read operations
//
// ------------------------------------------------------------------
//


static int ErrorCodeNonSevere(char *code)
{
	return (!(StrCompare(code, "423") 
        	&& StrCompare(code, "430")));
} /* ErrorCodeNonSevere */


//
//
// Reads size bytes from network socket
// Requires a buffer buf of size bytes in size
//
// returns number of bytes read
// returns 0 if socket has been shut down remotely
// returns -1 in case of general error
//

static SWord NPReadN(char *buf, Word pos, Word size)
{
    SWord num;
    Word startpos;
    Err errdum;

	startpos = pos;
	do
	{
	    num = NetLibDmReceive(nl, sock, (VoidPtr) buf, pos, size, 0, 0, 0, timeoutticks, &err);
	    if (num == -1)
	    {
	        NPErrorName();
	        FrmCustomAlert(alertID_dum, yf_net_read_err, errname, ")");
	        return -1;
	    }
	    else if (num == 0)
	    {
	        FrmCustomAlert(alertID_dum, yf_net_sock_closed_remote, " ", " ");
	        return 0;
	    }
		pos += num;
		size -= num;
		num = NetLibDmReceive(nl, sock, (VoidPtr) buf, pos, 0, netIOFlagPeek, 0, 0, 0, &errdum);
	}
	while ((num > 0) && size);
    return (pos - startpos);
} /* NPReadN */




//
//
// Reads string from socket - data is 0-terminated
// returns number of bytes read, not counting 0-terminator
//
// returns 0 if socket has been shut down remotely
// returns -1 in case of general error
//

static SWord NPRead(char *buf, Word size)
{
    SWord len;

    len = NPReadN(buf, 0, size - 1);
    if (len > 0)
    {
        DmWrite(buf, len, &zeroterm, 1);
    }
    return len;
} /* NPRead */





//
//
// Read first 3 byte that contain the server answer code and
// compare it (i.e. "411") with expected answer code
//
// This function assumes for simplicity the allocated buffer is >= 4 byte large.
// Else it would simply make no sense to keep on working.
//
// returns 1 in case of match
// returns 0 in case of mismatch or error
//

static int AnswerCodeOK(char *c, char *exp_answer)
{
    SWord len;

    len = NPReadN(c, 0, 3);
    if (len > 0)
    {
        // Set 0-terminator behind the server's response code
        DmSet(c, len, 1, 0);
    }
    else
    {
		FrmCustomAlert(alertID_dum, "AnswerCodeOK 2 ", " ", " ");
        // Error
		*lastresultcode = 0;
        return 0;
    }
    StrCopy(lastresultcode, c);
    return (!StrCompare(c, exp_answer));
} /* AnswerCodeOK */




//
//
// Skip server error msg in the form
//
// -blablabla
// 441-foobar
// 441 end of rubbish
//
// The first numerical code is expected not to exist because
// AnswerCodeOK has alread read it when this function is called.
//
// Returns 0 in case of (network) error
// Returns 1 in case of success
//

static int SkipResponse(char *buf, Word size)
{
    SWord len;
    UInt pos = 0;

    len = NPReadN(buf, pos++, 1);
    if (len <= 0)
    {
		FrmCustomAlert(alertID_dum, "SkipResponse 1", " ", " ");
        return 0;
    }
    if (buf[0] == '-')
    {
        do
        {
            // msg continued on next line so skip line
            do
            {
                len = NPReadN(buf, pos, 1);
                if (len <= 0)
                {
					FrmCustomAlert(alertID_dum, "SkipResponse 2", " ", " ");
                    return 0;
                }
            }
            while (buf[pos++] != '\n');
            if (NPReadN(buf, pos, 4) <= 0)
            {
				FrmCustomAlert(alertID_dum, "SkipResponse 3", " ", " ");
            	return 0;
            }
            pos += 4;
        }
        while (buf[pos-1] == '-');
    }
    // skip last line
    do
    {
        if (pos < (buf_len - 1))
        {
            pos++;
        }
        len = NPReadN(buf, pos, 1);
        if (len <= 0)
        {
			FrmCustomAlert(alertID_dum, "SkipResponse 4", " ", " ");
            return 0;
        }
    }
    while (buf[pos] != '\n');
    return 1;
} /* SkipResponse */




//
//
// Read server answer
// into buffer buf that is size byte long and 0-terminate it
// If wait_on_dotterm: Read server answer that is terminated by a full stop (".")
//
// The status answer is NOT stored in buf. It is skipped. The data in
// buf after this function returns successfully is the complete
// server response without status lines and trailing dot-line.
//
// exp_answcode points to the expected answer code for ok response
// if *exp_answcode == 0 no special answer is expected and no error
// message is generated.
//
// Algorithm: Read answer into buffer until either a . is read
// or the buffer is full.
// In the first case: delete the .
// In the second case: memorize end of buffer, skip rest of answer
// At the end: 0-terminate buffer
//
// returns number of bytes read
// returns 0 in case of error
//

static Word NPGetAnswer(char *b, Word size, char *exp_answcode, int wait_on_dotterm)
{
    int dotterm_found = 0;
    char *dotterm = NULL;
    SWord len;
	Word context;
	ULong p;
	Word total = 0;
	char dum[6];


    if (!AnswerCodeOK(b, exp_answcode))
    {
        // Server error - msg other than exp_answcode recieved so skip rest
        // (server response is probably continued (500-blablabla))
        SkipResponse(b, size);
        return 0;
    }

    if (!wait_on_dotterm)
    {
    	len = NPRead(b, size);
    	if (len <= 0)
    	{
			FrmCustomAlert(alertID_dum, "GetAnswer 3", " ", " ");
    	}
        return (Word) len;
    }

    SkipResponse(b, size);

    p = 0; // Point to the beginning of b
    do
    {
        len = NPReadN(b, p, size - 1);
        if (len <= 0)
        {
			FrmCustomAlert(alertID_dum, "GetAnswer 1", " ", " ");
            return 0;
        }
        p += len;
        total += len;
        size -= len;
        DmSet(buf, total, 1, zeroterm);

        // Now determine whether terminating full stop has been read
        // For this, look after "\n.\r" in the last "context" bytes
		context = 200;
        if (total < context)
        {
            // in case that less than 50 bytes have been read, reduce "context"
            context = total;
        }
        if (p == len)
        {
            // p was 0 - so this is the first answer part we have got
            // from server. If answer starts with ".\r\n" the answer is empty
            dotterm = StrStr(b, ".\r\n");
            dotterm_found = (dotterm == b);
        }
        if (!dotterm_found)
        {
            dotterm = StrStr(&b[p]-context, "\n.\r\n");
            dotterm_found = (dotterm != NULL);
        }
    }
    while (((size - 1) > 0) && (!dotterm_found));

    if (dotterm_found)
    {
        // We have the whole response - including the traling dot-line
        // which we don't need. So kill the dot.
        DmSet(b, dotterm - b + 1, 1, zeroterm);
    }
    else
    {
	    // for this 0-terminator there is reserved space
    	// (the "-1" in NPReadN(b, 0, size - 1) above)
	    DmWrite(b, p, &zeroterm, 1);

       	// Move end of buf to the start of skipbuf to enhance .-recognition
       	DmWrite(skipbuf, 0, buf + total - 5, 5);
	    
        do
        {
            len = NPReadN(skipbuf, 5, skipbuf_len - 5 - 1);
            if (len <= 0)
            {
				FrmCustomAlert(alertID_dum, "GetAnswer 2", " ", " ");
            	return 0;
            }
            DmSet(skipbuf, len + 5, 1, zeroterm);
            dotterm = StrStr(skipbuf, "\r\n.\r\n");
            if (dotterm == NULL)
            {
            	// Move end of buffer to the start to enhance .-recognition
            	if (len < 5)
            	{
            		StrCopy(dum, &((char *)skipbuf)[len]);
            		DmWrite(skipbuf, 0, dum, 5);
            	}
            	else
            	{
	            	DmWrite(skipbuf, 0, skipbuf + len, 5);
	            }
            }
        }
        while (dotterm == NULL);
    }
    return len;
} /* NPGetAnswer */




//
// ------------------------------------------------------------------
//
//         Routines for network write operations
//
// ------------------------------------------------------------------
//





//
//
// Writes data to network socket
//
// returns number of bytes written
// returns 0 if socket has been shut down remotely
// returns -1 in case of general error
//

static SWord NPWriteN(char *buffer, Word size)
{
    SWord num;

	if (size == 0)
	{
		return 1; // nothing happend - so no error can be generated - so return non-error 
	}
    num = NetLibSend(nl, sock, (VoidPtr) buffer, size, 0, (VoidPtr) &remote, sizeof(remote), timeoutticks, &err);
    if (num == -1)
    {
        NPErrorName();
        FrmCustomAlert(alertID_dum, yf_net_send_err, errname, ")");
    }
    else if (num == 0)
    {
        FrmCustomAlert(alertID_dum, yf_net_sock_closed_remote, " ", " ");
    }
    return num;
} /* NPWriteN */



//
//
// Writes String to socket
//

static SWord NPWrite(char *buf)
{
    return NPWriteN(buf, StrLen(buf));
} /* NPWrite */



//
//
// Writes three strings to socket. 0-string to omitt parameter
//

static SWord NPWriteP(char *b1, char *b2, char *b3)
{
    SWord res,
          total = 0;

    if (*b1)
    {
        res = NPWrite(b1);
        if (res < 0)
            return res;
        else
            total += res;
    }
    if (*b2)
    {
        res = NPWrite(b2);
        if (res < 0)
            return res;
        else
            total += res;
    }
    if (*b3)
    {
        res = NPWrite(b3);
        if (res < 0)
            return res;
        else
            total += res;
    }

    return total;
} /* NPWriteP */






//
// ------------------------------------------------------------------
//
//           (Very many) Newsgroups related routines
//
// ------------------------------------------------------------------
//





static SrvArtNum NextNum(char *p, int *pos)
{
    char dum;
    SrvArtNum num;
    int start;

    while (p[*pos] && (p[*pos] != '\n') && (p[*pos] == ' '))
    {
        (*pos)++;
    }
    start = *pos;
    while (p[*pos] && (p[*pos] >= '0') && (p[*pos] <= '9'))
    {
        (*pos)++;
    }
    dum = p[*pos];
    DmWrite(p, *pos, "", 1);
    num = StrAToI(&p[start]);
    DmWrite(p, *pos, &dum, 1);
    return num;
} /* NextNum */







//
//
// Go to newsgroup
//
// The answer parameters of the server are stored in num, min, max:
// number of articles in group (est�d)
// min name of articles
// max name of articles
//
// returns 0 in case of error
// returns 1 in case of success
//

static int NPGroup(char *newsgroup, SrvArtNum *num, SrvArtNum *min, SrvArtNum *max)
{
    int res,
        pos = 0;

    if (NPWriteP("GROUP ", newsgroup, crlf) <= 0)
    {
    	return 0;
    }
    *num = *min = *max = 0;
	res = NPGetAnswer(buf, buf_len, "211", 0);
    if (!res)
    {
		if (!StrCompare(lastresultcode, "480"))
		{
			FrmCustomAlert(alertID_dum, yf_net_auth_req, " ", "  ");
		}
		else
		{
	        FrmCustomAlert(alertID_dum, yf_net_group_unknown, newsgroup, " ");
	    }
        return 0;
    }
    *num = NextNum(buf, &pos);
    *min = NextNum(buf, &pos);
    *max = NextNum(buf, &pos);
    return 1;
} /* NPGroup */








//
// ------------------------------------------------------------------
//
//               Routines for downloading news articles
//
// ------------------------------------------------------------------
//



//
//
// Copy memory portion between start and end (including) to
// the memory region dest
//
// Returns pointer to destination area for convenience
//

static char *NPMemCopy(char *dest, char *start, char *end)
{
    char *out;

    out = dest;
    while (start <= end)
    {
        *dest++ = *start++;
    }
    return out;
} /* NPMemCopy */





//
//
// Takes header data and fetches the content of a specific header field.
//
// returns a pointer to a movable chunk containing the header content.
// If the header has no content (standard violation - so what?) the
// chunk contains "-None-"
//
// The chunk has to be freed! Done in NPFreeArticleData
// Free the chunks! Save the whales!
//

static char *GetHeaderField(char *header, char *buf, int optional)
{
    VoidHand h;
    char *p, *start, *end;

    start = (char *) StrStr(buf, header);
    if (start != NULL)
    {
        // Header tag found - skip to colon
        while (*start && (*start != '\r') && (*start != ':'))
        {
            start++;
        }
        // Colon found - skip to content
        start++;
        while (*start && (*start != '\r') && ((*start == ' ') || (*start == '\t')))
        {
            start++;
        }
        // Content found - find end of line and terminate string temporarily
        end = start;
        while (*end && (*end != '\r'))
        {
            end++;
        }
        end--;
        // end now points to the last char of header content
        // if the header has no content (i.e. "From: \r\n"),
        // start points to the '\r' and end points to the char before '\r'
        // that is: end < start

        if (end < start)
        {
            start = none; // point to standard string
            end = &start[5];
        }
    }
    else
    {
    	if (optional)
    	{
    		return NULL;
    	}
        start = none;
        end = &start[5];
    }
    h = MemHandleNew((ULong) (end - start + 1) + 1);
    if (h == 0)
    {
        FrmCustomAlert(alertID_dum, yf_mem_low, " ", " ");
        return NULL;
    }
    p = MemHandleLock(h);
    NPMemCopy(p, start, end);
    ((char *)p)[(end - start + 1)] = 0;
    return p;
} /* GetHeaderField */








//
//
// Find MsgID in server reply in response to STAT command
//
// Returns pointer to 0-terminated MsgID in case of success
// Returns NULL else
//


static char *FindMsgID(char *buf)
{
    char *start, *end;

    start = StrChr(buf, '<');
    if (start == NULL)
    {
        return &zeroterm;
    }
    end = StrChr(buf, '>');
    if (end == NULL)
    {
        return &zeroterm;
    }
    DmSet(buf, (end - buf) + 1, 1, 0);
    return start;
} /* FindMsgID */







//
//
// Fetch article from server by number
//
// Store article including body in the article database
// If complete body doesn�t fit, allocate a smaller amount and retry
//
// The article is downloaded from the current newsgroup on the server
// The article is read into buf (global)
//
// returns 0 in case of success
// returns 1 in case that article is already in database (non-severe error)
// returns 2 in case that article is not on server (non-sever error)
// returns >2 for severe errors
//



static int NPGetArticleHeader2DB(SrvArtNum num, DBArtNum *pos)
{
    struct articledb_item art;
    char numdum[11],
         *id;
    int res = 0;

    StrIToA(numdum, num);
    NPWriteP("STAT ", numdum, crlf);
    if (NPGetAnswer(buf, buf_len, "223", 0) == 0)
    {
        // Error
        if (ErrorCodeNonSevere(lastresultcode))
        {
        	// Article not on server - so return corresponding result code
        	// so that PollNewsgroup continues work but without attempting
        	// to download the body.
        	return yfErrNotOnServer;
        }
        else
        {
        	NPResponseAlert(lastresultcode, "Head1");
	        return yfErrSevere;
	    }
    }

    id = FindMsgID(buf);
    if (MidMsgIDExists(id))
    {
		// return non-severe result code
        return yfErrAlreadyRead;
    }

    // Read and process header
    NPWriteP("HEAD ", numdum, crlf);
    if (NPGetAnswer(buf, buf_len, "221", 1) == 0)
    {
        // Error
        NPResponseAlert(lastresultcode, "Head2");
        return yfErrSevere;
    }

	ArtInitArticleData(&art);
    art.rcvdate = TimGetSeconds();
    art.newsgroups = GetHeaderField("Newsgroups:", buf, 0);
    art.from = GetHeaderField("From:", buf, 0);
    art.subject = GetHeaderField("Subject:", buf, 0);
    art.date = GetHeaderField("Date:", buf, 0);
    art.msgid = GetHeaderField("Message-ID:", buf, 0);
    art.fup_to = GetHeaderField("Followup-To:", buf, 1);
    art.ref = GetHeaderField("References:", buf, 1);

    if (ArtAppendArticleHeader(&art, pos))
    {
        FrmCustomAlert(alertID_dum, yf_mem_low, " ", " ");
        res = yfErrSevere + 1; // just to emphasize the severeness...
    }
    else
    {
	    MidAddMsgID(art.msgid); // Store MsgID in database
	}
	ArtFreeArticleData(&art);
	return res;
} /* NPGetArticleHeader2DB */




static int NPGetArticleBody2DB(DBArtNum pos)
{
    struct articledb_item art;
    char *cutmark;
		
	if (ArtReadArticle(pos, &art))
	{
		FrmCustomAlert(alertID_dum, "Article not in database. ", "This should NEVER happen.", " Contact maintainer, please!");
		return yfErrSevere;
	}
	if ((*art.body != 0) && (pprefs.poll_what != poll_what_complete))
	{
		// body already in database
		return yfErrAlreadyRead;
	}
	if (*art.msgid == 0)
	{
		// Article probably not read correctly
		return yfErrNotOnServer;
	}
    NPWriteP("BODY ", art.msgid, crlf);
    if (!NPGetAnswer(buf, min(buf_len, (actng.ng_artmaxkb * 1024)), "222", 1))
    {
        // Error
        if (ErrorCodeNonSevere(lastresultcode))
        {
	        ArtAppendArticleBody(pos, yf_net_art_not_on_server);
	        return yfErrNotOnServer;
	    }
		NPResponseAlert(lastresultcode, "Body1");
        return yfErrSevere;
    }
    else
    {
		if (yprefs.cutsig)
		{
			cutmark = StrStr(buf, "\r\n-- \r");
			if (cutmark != NULL)
			{
				// set 0-terminator on the first dash
				// ULong-casts included 21.8.2000 mjordan
				DmSet(buf, ((ULong) cutmark - (ULong) buf + (ULong) 2), 1, 0);
			}
		}
		ArtAppendArticleBody(pos, buf);
		if ((pprefs.poll_what == poll_what_complete) 
			&& (pollmode == pollSingleBody))
		{
			NPUpdateForm(frmArticle, artModeUpdate);
		}
    }
    return yfErrSuccess;
} /* NPGetArticleBody2DB */







static int AbortButtonPressed(void)
{
	int stop = 0;
	EventType event;
	
	do 
	{
	    EvtGetEvent(&event, sysTicksPerSecond / 20);
	    if (!SysHandleEvent(&event))
	    {
			CtlHandleEvent(GetObjectPtr(btnCancel), &event);
			if ((event.eType == ctlSelectEvent)
				&& (event.data.ctlSelect.controlID == btnCancel))
			{
				stop = 1;
			}
		}
	}
	while ((!stop) && (event.eType != nilEvent));
	
	return stop;
} /* AbortButtonPressed */







#define FIELD_WIN 100
#define FIELD_MAX 1000

static void InitPollField(void)
{
	FormPtr frm;
	char *p;

	frm = FrmGetActiveForm();
	poll_fld = GetObjectPtr(fldPoll);
	poll_h = MemHandleNew(FIELD_MAX);
	if (poll_h == 0)
	{
		return;
	}
	p = MemHandleLock(poll_h);
	*p = 0;
	MemHandleUnlock(poll_h);
	FldSetTextHandle(poll_fld, (Handle) poll_h);
} /* InitPollField */



static void FieldFlush(void)
{
	char *p;

	p = FldGetTextPtr(poll_fld);
	FldRecalculateField(poll_fld, 0);
	FldSetScrollPosition(poll_fld, StrLen(p));
	FldDrawField(poll_fld);
} /* FieldFlush */





static void FieldCompact(void)
{
	char *dum,
		*p, *op;
	ULong plen;
	
	dum = MemPtrNew(FIELD_WIN);
	if (dum == NULL)
	{
		return;
	}
	p = MemHandleLock(poll_h);
	plen = StrLen(p) + 1;
	if (plen <= FIELD_WIN)
	{
		MemHandleUnlock(poll_h);
		MemPtrFree(dum);
		return;
	}
	op = p + (plen - FIELD_WIN);
	MemMove(dum, op, FIELD_WIN);
	MemMove(p, dum, FIELD_WIN);
	MemPtrFree(dum);
	MemHandleUnlock(poll_h);
	FldSetTextHandle(poll_fld, 0);
	FldSetTextHandle(poll_fld, (Handle) poll_h);
	FieldFlush();
} /* FieldCompact */





static void FieldOutput(char *str)
{
	char *p;
	ULong strlen, hlen;

	p = MemHandleLock(poll_h);
	strlen = StrLen(str);
	hlen = StrLen(p);
	MemHandleUnlock(poll_h);
	if ((hlen + strlen + 1) > FIELD_MAX)
	{
		FieldCompact();
	}
	FldSetTextHandle(poll_fld, 0);
	p = MemHandleLock(poll_h);
	StrCat(p, str);
	MemHandleUnlock(poll_h);
	FldSetTextHandle(poll_fld, (Handle) poll_h);
} /* FieldOutput */






static void FieldOutputRes(int header, int res)
{
	if (res == yfErrSuccess)
	{
       	FieldOutput(header ? " h" : " b");
    }
	if (res == yfErrAlreadyRead)
	{
		FieldOutput(" -");
	}
	if (res == yfErrNotOnServer)
	{
		FieldOutput(" ?");
	}
	FieldFlush();
} /* FieldOutputRes */


static void FieldOutputNum(ULong act, ULong max)
{
	char dum[20];
	
	StrIToA(dum, act);
	FieldOutput(dum);
	FieldOutput("/");
	StrIToA(dum, max);
	FieldOutput(dum);
} /* FieldOutputNum */



//
//
// Download body for article # act in article database
//


static int NPPollNewsgroupBodyNG(DBArtNum posinng, DBArtNum max)
{
	DBArtNum posinartdb;
	int res = yfErrAlreadyRead;
	ULong uid;
	struct articledb_item art;

	uid = NGGetArticleUID(posinng);
	if (uid == 0)
	{
		return yfErrSuccess; // should not happen - so don't bother
	}
	if (ArtSeekArticle(uid, &posinartdb))
	{
		return yfErrSuccess; // dito
	}
	if (ArtReadArticle(posinartdb, &art))
	{
		return yfErrSuccess; // dito, again
	}
	// Now we've got the article's data, the article is present, everything's fine
	if (((pprefs.poll_what != poll_what_selected) 
		&& (pprefs.poll_what != poll_what_complete))
		|| ((pprefs.poll_what == poll_what_selected) && (art.flags & yfArticleFlagMarked))
		|| ((pprefs.poll_what == poll_what_complete) && (art.flags & yfArticleFlagMarked))
		|| (pollmode == pollSingleBody))
	{
		// Do this if either we don't want to poll only selected articles
		// or we only want selected ones and this one is selected.
		FieldOutput(yf_net_nart_body);
		FieldOutputNum(posinng + 1, max + 1);
		FieldFlush();
		res = NPGetArticleBody2DB(posinartdb);
		FieldOutputRes(0, res);
	}
	return res;
} /* NPPollNewsgroupBodyNG */



static int NPPollNewsgroupBodies(void)
{
	DBArtNum max, act;
	int res = 0,
		stop = 0;
	
	err = 0;
	max = NGArticlesCount();
	if (max == 0)
	{
		return yfErrSuccess;
	}
	max -= 1;
	if (pprefs.poll_what == poll_what_complete)
	{
		CloseBuffer();
		actng.ng_artmaxkb = 32;
		buf = NewBuffer(actng.ng_artmaxkb);
		if (buf == NULL)
		{
			return yfErrSevere;
		}
	}
    for (act=0; (!stop && (res < yfErrSevere) && !err && (act <= max)); act++)
    {
    	stop = AbortButtonPressed();
		if (!stop) 
		{
			res = NPPollNewsgroupBodyNG(act, max);
		}
    }
    return stop;
} /* NPPollNewsgroupBodies */





#define withoutBody 0
#define withBody 1


static int NPPollNewsgroupHeaders(SrvArtNum last, 
		SrvArtNum min, SrvArtNum maxart, int mode)
{
	SrvArtNum act;
	UInt res = 0, 
		stop = 0;
	DBArtNum pos;

	err = 0;
	if (maxart == 0)
	{
		FieldOutput(yf_net_nng_empty);
		FieldFlush();
		return 0;
	}
	for (act=min; (!stop && (res < yfErrSevere) && !err 
		&& (act <= maxart)); act++) 
	{
		stop = AbortButtonPressed();
		if (!stop)
		{
	    	FieldOutput(yf_net_narticle);
			FieldOutputNum(act, maxart);
	    	FieldFlush();
	        // Get article and store it in Newsarts
	        res = NPGetArticleHeader2DB(act, &pos);
	        FieldOutputRes(1, res);
	        if (res < yfErrSevere) // success or non-severe error
	        {
		       	last = act;
	        	if ((mode == withBody) && (res == yfErrSuccess))
	        	{
	        		// Header received ok or non-severe error
					res = NPGetArticleBody2DB(pos);
					FieldOutputRes(0, res);
		       	}
	        }
	        else
	        {
	        	stop = 1;
	        }
		}
    }
	NGUpdateLastField(last);    
	return stop;
} /* NPPollNewsgroupHeaders */








static int NPPollNewsgroup(DBNGNum ng_num, int open)
{
    SrvArtNum count, amin, amax; //, last;
    int stop = 0;
    DBNGNum oldng;


	oldng = NGRememberActive();
	NGCloseNewsgroup();
	NGOpenNewsgroupByPos(ng_num);

	FieldOutput(yf_net_npolling);
	FieldOutput(actng.newsgroup);
	if (pprefs.poll_what == poll_what_headers)
	{
		FieldOutput(yf_net_nget_headers);
	}
	FieldFlush();
	
    if (!NPGroup(actng.newsgroup, &count, &amin, &amax))
    {
		NGCloseNewsgroup();
		NGOpenOldActive(oldng);
        return 0;
    }

    FieldOutput(yf_net_ngroup_entered);
    FieldFlush();
	NPSetFormTitle(FrmGetActiveForm(), actng.newsgroup, 1);
	
	// Allocate new buffer
	CloseBuffer();
	if (pprefs.poll_what != poll_what_complete)
	{
		buf = NewBuffer(actng.ng_artmaxkb);
	}
	else
	{
		buf = NewBuffer(32);
	}
	if (buf != NULL)
	{
		if (actng.last == 0)
		{
			// Download of a freshly subscribed newsgroup - use samplearts
			if (actng.ng_samplearts < amax)
			{
				amin = max(amin, amax - actng.ng_samplearts + 1);
			}
		}
		else
		{
			// Newsgroup already polled - use download max to determine max
			if (actng.ng_flags & yfNGFlag_poll_next)
			{
				amin = actng.last + 1;
				amax = min(amax, amin + actng.ng_downmax - 1);
			}
			else
			{
				amin = max(amin, actng.last + 1); // get first article that we don't already have 
				if (amax - amin + 1 > actng.ng_downmax)
				{
					amin = amax - actng.ng_downmax + 1;
				}
			}
		}
		switch (pprefs.poll_what)
		{
			case poll_what_headers: 
			{
				stop = NPPollNewsgroupHeaders(actng.last, amin, amax, withoutBody); 
				break;
			}
			
			case poll_what_articles: 
			{
				stop = NPPollNewsgroupHeaders(actng.last, amin, amax, withBody); 
				break;
			}
			
			case poll_what_selected:
			case poll_what_complete:
			case poll_what_bodies: 
			{
				stop = NPPollNewsgroupBodies(); 
				break;
			}
			
			default: stop = 1;
		}
	} /* if (buf != NULL) */
	NGCloseNewsgroup();
	NGOpenOldActive(oldng);
	return stop;
} /* NPPollNewsgroup */




static void NPPollNewsgroupsFrom(DBServerNum srvnum)
{
    UInt pos, count;
	int stop = 0;


	if (pprefs.poll_from != poll_from_active_group)
	{
		count = SubSubscriptionsCount();
		for (pos=0; (!stop && (pos < count)); pos++)
		{
			SubGetSubscriptionByPos(pos, &actng);
			if ((!((actng.ng_flags & yfNGFlag_dont_poll)
				|| (actng.ng_flags & yfNGFlag_internal)))
				&& (srvnum == actng.server))
			{
				// Poll only "real" groups, not our internal one.
				// And poll only the groups of the current server
				stop = NPPollNewsgroup(pos, 0);
				stop = stop | AbortButtonPressed();
			}
		}
	}
	else
	{
		SubGetSubscriptionByPos(NGActiveNGNum(), &actng);
		if (!((active_ng.ng_flags & yfNGFlag_dont_poll)
			|| (active_ng.ng_flags & yfNGFlag_internal)))
		{
			NPPollNewsgroup(NGActiveNGNum(), 1);
		}
	}
} /* NPPollNewsgroupsFrom */




static void NPUpdateDatabases(UInt start)
{
	UInt count, pos;

	if (pprefs.poll_what != poll_what_bodies)
	{
		count = ArtArticlesCount();
		if (count != start)
		{
		    // Fetch record ID and enter it into the appropriate databases
		    // of the newsgroups that recieved this article and that we subscribed to
		   	FieldOutput(yf_net_ninst_arts);
		   	FieldFlush();
		    for (pos=start; (pos < count); pos++)
		    {
		        NGWeaveInArticle(pos, NULL, 0);
				if (((pos - start + 1) % 10) == 0)
 				{
					if (((pos - start + 1 - 10) % 50) == 0)
					{
						FieldOutput(" ");
					}
					FieldOutput(".");
					FieldFlush();
				}
		    }
		    NPUpdateForm(frmNewsgroups, 1);
		}
		else
		{
		   	FieldOutput(yf_net_no_new_arts);
		   	FieldFlush();
		   	SysTaskDelay(sysTicksPerSecond/2);
		}
	}
	else
	{
		NPUpdateForm(frmNewsgroups, 0);
	}
    if (NGNewsgroupOpen())
    {
	    NPUpdateForm(frmArtList, updArtListMajorChanges);
	}
} /* NPUpdateDatabases */





static void NPPollSingleBody(void)
{
	SrvArtNum count, min, max;
	struct serverdb_item srv;
	

	CloseBuffer();
	if (pprefs.poll_what == poll_what_complete)
	{
		actng.ng_artmaxkb = 32;
	}
	buf = NewBuffer(actng.ng_artmaxkb);
	if (buf == NULL)
	{
		return;
	}
	SrvReadServer(&srv, active_ng.server);
	if (NPConnect2(&srv))
	{
        // Error
        FrmCustomAlert(alertID_dum, yf_net_server_port_err, " ", " ");
    }
    else
    {
		FieldOutput(srv.name);
		FieldOutput(yf_net_connected);
		FieldFlush();
	
	    if (!NPGroup(NGActiveNewsgroup(), &count, &min, &max))
	    {
			FieldOutput(yf_net_group_unknown);
			FieldOutput(NGActiveNewsgroup());
			FieldFlush();
	        return;
	    }
	
		NPPollNewsgroupBodyNG(pollart, pollart);
		NPQuitServer();
	}
	CloseBuffer();
} /* NPPollSingleBody */










//
//
//  Posting routines
//
//



static Word GetQPrefix(char *str, char *prefix, int max)
{
	char q[] = ">!:|";
	char *start;
	
	start = str;
	max -= 1;
	if (StrChr(q, *str) != NULL)
	{
		while ((max) && (*str) && ((StrChr(q, *str) != NULL) || (*str == ' ')))
		{
			*prefix++ = *str++;
			max--;
		}
	}
	*prefix = 0;
	return (str - start);
} /* GetQPrefix */




#define X_UPPER_BOUND 65
#define QUOTE_PREFIX_LEN 20

static void WriteBodyWordwrapped(char *body)
{
	char *actpos,
		*endpos;
	Word x, qlen;
	char *previewpos;
	char quote[QUOTE_PREFIX_LEN];

	actpos = body;
	endpos = body + StrLen(body) - 1;
	if (StrStr(actpos, ".\n") == actpos)
	{
		NPWrite("..\r\n");
		actpos += 2;
	}
	while (actpos <= endpos)
	{
		qlen = GetQPrefix(actpos, quote, QUOTE_PREFIX_LEN);
		actpos += qlen; 
		x = qlen + 1;
		NPWrite(quote);
		previewpos = actpos;
		do
		{
			while ((*previewpos != '\n') 
				&& (*previewpos != ' ') 
				&& (previewpos <= endpos))
			{
				x++;
				previewpos++;
			}
			if (x > yprefs.wrap_len)
			{
				NPWrite(crlf);
				NPWrite(quote);
				x = qlen + (previewpos - actpos);
			}
			NPWriteN(actpos, previewpos - actpos);
			actpos = previewpos;
				// Print out word separator (linefeed or space)
			if (*actpos == '\n')
			{
				NPWrite("\r\n");
				actpos++;
				if ((*actpos == '.') 
					&& ((actpos[1] == '\n') || (actpos[1] == '.')
						|| (actpos == endpos)))
				{
					NPWrite("..");
					actpos += 1;
				}
			}
			else
			{
				NPWriteN(actpos, 1);
				actpos += 1;
				x++;
			}
		}
		while ((previewpos < endpos) && (*previewpos++ != '\n'));
	}
} /* WriteBodyWordwrapped */



static void NPWriteCustomHeaders(char *h)
{
	while (*h)
	{
		if (*h != '\n')
		{
			NPWriteN(h++, 1);
			if (*h == 0)
			{
				// after a non-LF-char there is a 0 char. This would corrupt
				// the header. So add a linebreak.
				NPWrite(crlf);
			}
		}
		else
		{
			NPWrite(crlf);
			while (*h == '\n')
			{
				// Skip superflous linebreaks.
				h++;
			}
		}
	}
} /* NPWriteCustomHeaders */


//
//
// Post an article denoted by the position of its record in the 
// database of the outgoing newsgroup 
//


static int NPPostArticle(DBArtNum pos, DBArtNum act, DBArtNum max, 
	DBServerNum snum, struct serverdb_item *srv)
{
	struct articledb_item art;
	int res;
	char dum[20];
	Word len;
	
	if (NGReadArticle(pos, &art))
	{
		return yfErrSevere;
	}

	if ((art.server != snum) || (StrChr(art.newsgroups, '@') != NULL))
	{
		return yfErrSkip;
	}

	FieldOutput(yf_net_npostingart);
	FieldOutputNum(act, max);
   	FieldFlush();

	NPWriteP("POST ", crlf, "");
	if (NPGetAnswer(buf, buf_len, "340", 0))
	{
		StrIToA(dum, CountLF(art.body, &len) + 1);
		// Posting ok, we are now sending the article
		NPWriteP("From: ", art.from, crlf);
		NPWriteP("Subject: ", art.subject, crlf);
		NPWriteP("Date: ", art.date, crlf);
		NPWriteP("Newsgroups: ", art.newsgroups, crlf);
		NPWriteP("Message-ID: ", art.msgid, crlf);
		NPWriteP("Path: ", srv->hostname, crlf);
		NPWriteP("Lines: ", dum, crlf);
		if (art.ref != NULL)
		{
			NPWriteP("References: ", art.ref, crlf);
		}
		NPWriteP("X-Newsreader: Yanoff 1.5 PalmPilot", crlf, "");
		NPWriteCustomHeaders(art.headers);
		NPWrite(crlf);
		WriteBodyWordwrapped(art.body);
		NPWriteP(crlf, ".", crlf);
		
		if (NPGetAnswer(buf, buf_len, "240", 0))
		{
			NGDeleteArticle(pos);
			NPUpdateForm(frmNewsgroups, 1);
			if (!StrCompare(NGActiveNewsgroup(), outgoing_group))
			{
				NPUpdateForm(frmArtList, updArtListMajorChanges);
			}
			res = yfErrSuccess;
		}
		else
		{
			FrmCustomAlert(alertID_dum, yf_net_art_post_err, buf, " ");
			res = yfErrArticleRejected;
		}
	}
	else
	{
		FrmCustomAlert(alertID_dum, yf_net_art_post_err, buf, " ");
		res = yfErrArticleRejected;
	}
	FieldOutput(res ? " -" : " +");
	FieldFlush();
	return res;
} /* NPPostArticle */




//
//
// This routine posts articles for a specific server defined by its number
// It returns the number of posted articles 
//

static DBArtNum NPPostArticles(DBServerNum snum, struct serverdb_item *srv)
{
	DBArtNum act, max, pos, posted = 0;
	int stop = 0, res = 0;
	DBNGNum oldng;

	
	oldng = NGRememberActive();
	NGCloseNewsgroup();
	NGOpenNewsgroupByName(outgoing_group);

	switch (pollmode)
	{
		case pollNormally:
		{
			err = 0;
			max = NGArticlesCount();
			if (max != 0)
			{
				pos = 0;
			    for (act=1; (!stop && (res < yfErrSevere) && !err && (act <= max)); act++)
			    {
			    	stop = AbortButtonPressed();
					if (!stop) 
					{
						if (NPPostArticle(pos, act, max, snum, srv))
						{
							// this article could not be sent for some reason
							// and has not been deleted.
							pos++;
						}
						else
						{
							posted++;
						}
					}
			    }
				NPUpdateForm(frmNewsgroups, 1);
			}
			break;
		}
		default:
		{
			pos = NGArticlesCount() - 1; // post last article in outgoing group
			if (!NPPostArticle(pos, 1, 1, snum, srv))
			{
				posted++;
			}
			FrmUpdateForm(frmPost, 0); // Close frmPost
		}
	}

	NGCloseNewsgroup();
	NGOpenOldActive(oldng);
	
	return posted;
} /* NPPostArticles */



//
//
// Generate a correct address out of a arbitrary address line
// like Blabla <user@home.com>
// or user@home.com (Blabla)
//

static char *GenRCPT(char *toline)
{
	char *begin, *end, *adr, *dum;
	
	dum = MemPtrNew(StrLen(toline) + 1);
	if (dum == NULL)
	{
		return NULL;
	}
	StrCopy(dum, toline);
	
	begin = StrChr(dum, '<');
	if (begin != NULL)
	{
		// Address is enclosed in angle brackets
		begin++;
		for (end=begin; (*end && (*end != '>')); end++);
	}
	else
	{
		for (begin=end=dum; (*end && (*end != ' ')); end++);
	}
	*end = 0;
	adr = MemPtrNew(StrLen(begin) + 1);
	if (adr == NULL)
	{
		MemPtrFree(dum);
		return NULL;
	}
	StrCopy(adr, begin);
	MemPtrFree(dum);
	return adr;
} /* GenRCPT */



//
//
// Post an email message denoted by the position of its record in the 
// database of the outgoing newsgroup 
//


static int NPPostEMailMessage(DBArtNum pos, DBArtNum act, DBArtNum max,
	struct serverdb_item *srv)
{
	struct articledb_item art;
	int res;
	char *rcpt;
	
	if (NGReadArticle(pos, &art))
	{
		return yfErrSevere;
	}

	if (StrChr(art.newsgroups, '@') == NULL)
	{
		return yfErrSkip;
	}

	FieldOutput(yf_net_npostingemail);
	FieldOutputNum(act, max);
   	FieldFlush();

	NPWriteP("HELO ", srv->hostname, crlf);
	if (!NPGetAnswer(buf, buf_len, "250", 0))
	{
		FrmCustomAlert(alertID_dum, "SMTP error ", buf, " ");
		return yfErrSevere;
	}


	NPWriteP("MAIL FROM:<", srv->username, "@");
	NPWriteP(srv->hostname, ">", crlf);
	if (!NPGetAnswer(buf, buf_len, "250", 0))
	{
		FrmCustomAlert(alertID_dum, "SMTP error ", buf, " ");
		return yfErrSevere;
	}

	rcpt = GenRCPT(art.newsgroups);
	if (rcpt == NULL)
	{
		return yfErrSevere;
	}

	NPWriteP("RCPT TO:<", rcpt, ">");
	NPWrite(crlf);
	if (!NPGetAnswer(buf, buf_len, "250", 0))
	{
		FrmCustomAlert(alertID_dum, "SMTP error ", buf, " ");
		MemPtrFree(rcpt);
		return yfErrSevere;
	}

	NPWriteP("DATA", crlf, "");
	if (NPGetAnswer(buf, buf_len, "354", 0))
	{
		NPWriteP("Date: ", art.date, crlf);
		NPWriteP("From: ", art.from, crlf);
		if (*art.fup_to != 0)
		{
			NPWriteP("Reply-To: ", art.fup_to, crlf);
		}
		NPWriteP("Subject: ", art.subject, crlf);
		NPWriteP("To: ", rcpt, crlf);
		NPWriteP("Message-ID: ", art.msgid, crlf);
		NPWriteP("X-Mailer: Yanoff 1.5 PalmPilot", crlf, "");
		NPWrite(crlf);
		WriteBodyWordwrapped(art.body);
		NPWriteP(crlf, ".", crlf);
		
		if (NPGetAnswer(buf, buf_len, "250", 0))
		{
			NGDeleteArticle(pos);
			NPUpdateForm(frmNewsgroups, 1);
			if (!StrCompare(NGActiveNewsgroup(), outgoing_group))
			{
				NPUpdateForm(frmArtList, updArtListMajorChanges);
			}
			res = yfErrSuccess;
		}
		else
		{
			FrmCustomAlert(alertID_dum, yf_net_art_post_err, buf, " ");
			res = yfErrArticleRejected;
		}
	}
	else
	{
		FrmCustomAlert(alertID_dum, yf_net_art_post_err, buf, " ");
		res = yfErrArticleRejected;
	}
	FieldOutput(res ? " -" : " +");
	FieldFlush();
	MemPtrFree(rcpt);
	return res;
} /* NPPostEMailMessage */





//
//
// This routine sends eMail messages and returns the number of
// messages it sent
//

static DBArtNum NPPostEMail(struct serverdb_item *srv)
{
	DBArtNum act, max, pos, posted = 0;
	int stop = 0, res = 0;
	DBNGNum oldng;

	
	oldng = NGRememberActive();
	NGCloseNewsgroup();
	SubGetSubscriptionByName(outgoing_group, NULL);
	NGOpenNewsgroupByName(outgoing_group);
	
	FieldOutput("\n");
	FieldOutput(srv->name);
	FieldOutput(yf_net_connected);
	FieldFlush();

	if (pollmode == pollNormally)
	{
		err = 0;
		max = NGArticlesCount();
		if (max != 0)
		{
			pos = 0;
		    for (act=1; (!stop && (res < yfErrSevere) && !err && (act <= max)); act++)
		    {
		    	stop = AbortButtonPressed();
				if (!stop) 
				{
					if (NPPostEMailMessage(pos, act, max, srv))
					{
						// this article could not be send for some reason
						// and has not been deleted.
						pos++;
					}
					else
					{
						posted++;
					}
				}
		    }
			NPUpdateForm(frmNewsgroups, 1);
		}
	}
	else
	{
		pos = NGArticlesCount() - 1; // post last article in outgoing group
		NPPostEMailMessage(pos, 1, 1, srv);
		FrmUpdateForm(frmPost, 0); // Close frmPost
	}
	
	NGCloseNewsgroup();
	NGOpenOldActive(oldng);
	return posted;
} /* NPPostEMail */






//
//
// Transport layer is active at this point
//


static void NPPollServers(void)
{
	DBServerNum srvnum, startsrv, endsrv;
	UInt first_new_art_after_poll;
	struct subscriptiondb_item ng;
	DBArtNum msg_posted = 0;
	struct serverdb_item srv;


	switch (pprefs.poll_from)
	{
		case poll_from_active_group:
		{
			SubGetSubscriptionByPos(NGActiveNGNum(), &ng);
			if (ng.ng_flags & yfNGFlag_dont_poll)
			{
				FrmCustomAlert(altInfo, yf_ng_set_to_dont_poll, " ", " ");
				startsrv = 1;
				endsrv = 0; // do nothing
			}
			else
			{
				startsrv = endsrv = ng.server;
			}
			break;
		}
		
		case poll_from_all_servers:
		{
			startsrv = 1;
			endsrv = SrvServersCount() - 1;
			break; 
		}

		case poll_from_one_server:
		{
			startsrv = endsrv = pprefs.poll_server;
			break;
		}
		
		default:
		{
			startsrv = 1;
			endsrv = 0; // do nothing
			break;
		}
	} // switch ...



	first_new_art_after_poll = ArtArticlesCount();

	// Now first sync UseNet groups

	if (pprefs.poll_news || pprefs.post_news)
	{
		for (srvnum = startsrv; (srvnum <= endsrv); srvnum++)
		{
			SrvReadServer(&srv, srvnum);
			if (srv.poll || (pprefs.poll_from == poll_from_active_group))
			{
				if (NPConnect2(&srv))
				{
			        // Error
			        FrmCustomAlert(alertID_dum, yf_net_server_port_err, " ", " ");
			    }
			    else
			    {
					FieldOutput(srv.address);
					FieldOutput(yf_net_connected);
					FieldFlush();
		
					if (pprefs.post_news)
					{
						msg_posted += NPPostArticles(srvnum, &srv);
					}
					if (pprefs.poll_news)
					{
						NPPollNewsgroupsFrom(srvnum);
					}
					NPQuitServer();
				}
			} // if (srv.poll)
		} // for ...
	} // if (poll || post)
	
	// Now post eMail messages

	if (pprefs.post_email)
	{
		SrvReadServer(&srv, 0); // 0 is the mail server
		if (NPConnect2(&srv))
		{
	        // Error
	        FrmCustomAlert(alertID_dum, yf_net_server_port_err, " ", " ");
	    }
	    else
	    {
			msg_posted += NPPostEMail(&srv);
			NPQuitServer();
		}
	}

	// Belongs to here because otherwise the links would be brought down
	// after all articles have been installed.
	NPCloseNetwork(0, 0);

	NPUpdateDatabases(first_new_art_after_poll - msg_posted);
} /* NPPollServers */





int HandlePoll(EventPtr event)
{
	int handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitPollField();
			oldautooff = SysSetAutoOffTime(0);

			NPSetFormTitle(FrmGetActiveForm(), yf_net_transfer, 0);
            RefreshForm();
			switch (pollmode)
			{
				case pollSingleBody:	
				{
					if (!NPBringUpLink())
					{
						NPPollSingleBody();
						NPCloseNetwork(0, 0);
					}
					break;
				}

				case pollNormally:
				{
					if (!NPBringUpLink())
					{
						NPPollServers();
					}
					break;
				}
				
				default:
			}

			if (yprefs.beep)
			{
				SndPlaySystemSound(sndInfo);
			}
		    SysSetAutoOffTime(oldautooff);
		    EvtResetAutoOffTimer();

			FldSetTextHandle(poll_fld, 0);
			MemHandleFree(poll_h);

            NPExitForm();
            handled = 1;
            break;
        }
	
		default:
    }

    return handled;
} /* HandlePoll */



void NPInvokePoll(int mode, DBArtNum pos)
{
	pollmode = mode;
	pollart = pos;
	NPGotoForm(frmPoll);
} /* NPInvokePoll */


