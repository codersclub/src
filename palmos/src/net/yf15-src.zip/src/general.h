/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// general.h
//
// general headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef GENERAL_H
#define GENERAL_H

#ifndef OS35
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
	
	enum directions {up = 0, down, left, right};
	typedef enum directions DirectionType;
#endif


#include "yanoff.h"

#define CREATOR 'MJyf'
#define TYPE    'MJyf'
#define VERSION 0x0105


#define BUF_LEN_DOWN 1000
#define BUF_START_LEN 65335

//#define Ydebug(a,b,c) {}
#define Ydebug(a,b,c) FrmCustomAlert(alertID_dum, a, b, c)
#define YdebugSI(a, b) {char dum1[20]; StrIToA(dum1, b); FrmCustomAlert(alertID_dum, a, dum1, " ");}

#define YdebugNG(a) { Ydebug("NG-debug", a, " "); \
					YdebugSI("ng addr:", (Long) active_ng.newsgroup); \
					Ydebug("Group: ", active_ng.newsgroup, " "); \
				}


#ifndef OS35
	// Code that fixes a callback bug in GCC - thanks to Ian Goldberg
	
	register void *reg_a4 asm("%a4");
	
	#define CALLBACK_PROLOGUE \
		void *save_a4 = reg_a4; asm("move.l %%a5, %%a4; sub.l #edata, %%a4" : :);
	
	#define CALLBACK_EPILOGUE \
		reg_a4 = save_a4;
#else
	#define CALLBACK_PROLOGUE ;
	#define CALLBACK_EPILOGUE ;
#endif



#define updArtListMinorChanges 0	// e.g. Flags set or reset etc.
#define updArtListMajorChanges 1	// e.g. article deleted, col sep moved
#define updArtListNewGroup 2		// e.g. new group =B)






extern char wdays[7][4];
extern char mons[12][4];
extern char bad_characters[];
extern DWord romVersion;
extern char **servers;









// Open some (some!) database. If not present: create it!
DmOpenRef NPOpenDB(char *name);

char *StrInit(char **str, char *value);

int StrHasLetter(char *c);
void FreePointer(Ptr p);

// some UI routines
VoidPtr GetObjectPtr(Word objectID);
char *GetFormParameter(char *fieldname, Word id);
void RefreshForm(void);

void NPInitFormStack(Word formID);
void NPGotoForm(Word formID);
Word NPGetTopForm(void);
void NPExitForm(void);
void NPUpdateForm(Word formID, int code);


void NPSetFormTitle(FormPtr form, char *buf, int is_ng);
Word GetNewTopline(Word currenttop, Word linestotal, Word linesdisplayed, Short scllines);
void DrawItemString(CharPtr dum, short x, short y, short width);
void MakeItemString(CharPtr dum, short width, char *out);
void ArtListMoveColSep(Word id, Word col, EventPtr event, UInt *sepx);
int GetFormValue(char *name, Word id, UInt *val);
void GetRowBounds(TablePtr tbl, int row, RectanglePtr r);
int GetVariableField(char *name, Word id, char **dest);
void SetFocus(Word id);
Word CountLF(char *str, Word *len);
int ScrollField(Short linesToScroll, Word fldID, Word sbID);
Word UpdateField(Word fldID, Word sbID);
int HandleEditMenu(EventPtr e);
char *CreateNewDatabase(char *prefix, char *tempname, char *dum);
int HandleInput(EventPtr e, Word fieldid, int permit_mode, char *tokens);
void ShowButton(Word id, int visible);
void GetInfoOfFromField(char *header_field, char *out, char style);
char *GenFromStyle(char *header_field, char *out, int show_scoring);
void GenScoringAddress(char *header_field, char *out);

void EditSavedArticle(void);
int CalcPageSize(int dir, Word rows);


#endif

