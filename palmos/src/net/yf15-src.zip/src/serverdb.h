/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// serverdb.h
//
// server database headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef SERVERDB_H
#define SERVERDB_H


#include "yanoff.h"


//
// The server db item
//

typedef struct serverdb_item
{
	UInt port,
		timeoutsecs;
	char poll,				// should Yanoff poll this server right now?
		use_auth,
		*name,				// to identify server config
		*address,
		*auth_user,			// in the mailserver this is Reply-To
		*auth_pass,
		*hostname,          // our hostname
		*username,          // sender name. from = username@hostname
		*realname,
		*zone,
		*sig;
							// 10 dummy bytes (NULL) in database at this place
} serverdb_item;

typedef unsigned short DBServerNum;


extern serverdb_item actserver;


void SrvInitData(struct serverdb_item *s);
void SrvFreeData(struct serverdb_item *s);

DmOpenRef SrvOpenServers(void);
void SrvCloseServers(void);

int SrvReadServer(struct serverdb_item *srv, DBServerNum pos);
int SrvCopyServer(struct serverdb_item *srv, DBServerNum pos);

int SrvWriteServer(struct serverdb_item *srv, int overwrite, DBServerNum *pos);
int SrvAppendServer(struct serverdb_item *srv);

DBServerNum SrvFindServer(char *name);

Err SrvDeleteServer(DBServerNum pos);

UInt SrvServersCount(void);

void SrvInitServerDatabase(void);



#define srv_list_mode_none 1
#define srv_list_mode_poll 2
#define srv_list_mode_post 3
#define srv_list_mode_all 4

char **SrvGetServerList(int mode, DBServerNum *list_count);



void SrvFreeServerList(char **list);


#endif

