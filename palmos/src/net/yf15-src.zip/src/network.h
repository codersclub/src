/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// network.h
//
// Network headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef NETWORK_H
#define NETWORK_H


#ifndef OS35
	#include <Common.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "artdb.h"
#include "segment.h"

#define crlf "\r\n"
#define MAXTIMEOUT (10 * sysTicksPerSecond)
#define BUF_NAME "Newsbuffer"

#define pollNormally 0
#define pollSingleBody 1
#define postLastMessage 2
#define pollCompleteBody 3


// Handle information about the online status
int NPOnlineMode(void) SECTION_3;
void NPWorkOnline(int mode) SECTION_3;

int NPNetworkLayerUp(void) SECTION_3;

// Handle the connection
int NPInitNetwork(void) SECTION_3;
int NPCloseNetwork(int immediately, int for_reopening) SECTION_3;
int NPConnect(void) SECTION_3;

int HandlePoll(EventPtr event) SECTION_3;
void NPInvokePoll(int mode, UInt pos) SECTION_3;


#endif
