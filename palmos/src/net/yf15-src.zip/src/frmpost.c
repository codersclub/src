/*************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmpost.c
//
// Handle the article form
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "subscrdb.h"
#include "ngroup.h"
#include "network.h"
#include "lang.h"
#include "prefs.h"

#include "frmartlist.h"
#include "frmart.h"
#include "frmnglist.h"
#include "mainmenu.h"
#include "frmpost.h"
#include "frmsrvsel.h"
#include "serverdb.h"


Word postpagesize;
VoidHand subjecth, newsgroupsh, bodyh;
int edit_mode,
	art_mode;

char *post_ng = NULL, 
	*post_subj = NULL,
	*init_subj = NULL,
	*post_refid = NULL,
	*post_body = NULL;

struct serverdb_item srv;


#define saveArticleAsk -1
#define saveArticleAsReady 0
#define saveArticleAsDraft 1
#define saveArticleAsDraftDueToQuit 2




static void InitTextField(Word id, VoidHand *h, char *pref)
{
	FieldPtr fld;
	char *fieldtext;

	if (pref != NULL)
	{
		*h = MemHandleNew(StrLen(pref) + 1);
	}
	else
	{
		*h = MemHandleNew(30);
	}
	if (*h == 0)
	{
		return;
	}
    fieldtext = MemHandleLock(*h);
	if (pref != NULL)
	{
		StrCopy(fieldtext, pref);
	}
	else
	{
	    *fieldtext = 0;
	}
    MemHandleUnlock(*h);
    fld = GetObjectPtr(id);
    FldEraseField(fld);
    FldSetTextHandle(fld, (Handle) *h);
} /* InitTextField */




static int InitPostField(void)
{
	FieldPtr fld;
	FieldAttrType attr;
	char *body;
	ControlType *btnC;
	
	InitTextField(fldPostSubject, &subjecth, post_subj);
	InitTextField(fldPostNewsgroups, &newsgroupsh, post_ng);
	InitTextField(fldPostText, &bodyh, post_body);

	if (!edit_mode && bodyh && *srv.sig)
	{
		fld = GetObjectPtr(fldPostText);
    	FldSetTextHandle(fld, 0);
		MemHandleResize(bodyh, MemHandleSize(bodyh) + StrLen(srv.sig) + 1);
		body = MemHandleLock(bodyh);
		StrCat(body, srv.sig);
		MemHandleUnlock(bodyh);
	    FldSetTextHandle(fld, (Handle) bodyh);
	}

    if (edit_mode)
    {
	    btnC = GetObjectPtr(btnCancel);
		CtlSetLabel(btnC, "Delete");	
	}
	
	if (art_mode != artModeEMail)
	{
		FrmCopyLabel(FrmGetActiveForm(), lblGroups, yf_groups);
	}
	
    fld = GetObjectPtr(fldPostText);
	FldSetScrollPosition(fld, 0);
//	FldSetInsPtPosition(fld, FldGetTextLength(fld));
	FldSetInsPtPosition(fld, 0);

    FldGetAttributes(fld, &attr);
    attr.hasScrollBar = 1;
    FldSetAttributes(fld, &attr);
	UpdateField(fldPostText, sbPost);

	RefreshForm();
	WinDrawLine(0, 44, 160, 44);
	if (!FldGetTextLength(GetObjectPtr(fldPostSubject)))
	{
		// User has to enter a subject
		SetFocus(fldPostSubject);
	}
	else
	{
		SetFocus(fldPostText);
	}
	return 0;
} /* InitPostField */






static void ClosePostField(void)
{
	FieldPtr fld;
	
    fld = GetObjectPtr(fldPostText);
    FldEraseField(fld);
	FldFreeMemory(fld);    
} /* ClosePostField */




static int SavePosting(int draft)
{
	DBArtNum pos;
	FieldPtr fsubject, fnewsgroups, fbody;
	char *subject, *newsgroups, *body, *r;
	
	fsubject = GetObjectPtr(fldPostSubject);
	fnewsgroups = GetObjectPtr(fldPostNewsgroups);
	fbody = GetObjectPtr(fldPostText);
	
	subject = FldGetTextPtr(fsubject);
	newsgroups = FldGetTextPtr(fnewsgroups);
	body = FldGetTextPtr(fbody);

	
	if (draft == saveArticleAsk)
	{
		draft = !FrmAlert(altSaveAsDraft);
	}

	if ((draft == saveArticleAsReady) && (!*subject || !*newsgroups || !*body))
	{
		FrmCustomAlert(alertID_dum, yf_empty_fields_not_all, " ", " ");
		return 1;
	}

	if (((init_subj != NULL) && StrCompare(subject, init_subj))
		|| (post_refid == NULL))
	{
		// Do not generate References if subject changed.
		r = "";
	}
	else
	{
		r = post_refid;
	}
	
	if (ArtSaveNewArticle(&srv, selected_srv, subject, newsgroups, 
		r, body, &pos))
	{
		FrmCustomAlert(alertID_dum, yf_saving_failed, " ", " ");
		return 1;
	}

	if (draft)
	{
		NGWeaveInArticle(pos, drafts_group, 0);
	}
	else
	{
		NGWeaveInArticle(pos, outgoing_group, 0);
	}

	if (draft == saveArticleAsDraftDueToQuit)
	{
		ystate.currently_writing_article = pos;
		if (NGNewsgroupOpen())
		{
			if (active_ng.ng_flags & yfNGFlag_internal)
			{
				NGDeleteArticle(FrmArtActiveArtNum());
			}
		}
	}
	return 0;
} /* SavePosting */




static void FreePostData(void)
{
	if (post_ng != NULL)
	{
		MemPtrFree(post_ng);
		post_ng = NULL;
	}
	if (post_subj != NULL)
	{
		MemPtrFree(post_subj);
		post_subj = NULL;
	}
	if (init_subj != NULL)
	{
		MemPtrFree(init_subj);
		init_subj = NULL;
	}
	if (post_refid != NULL)
	{
		MemPtrFree(post_refid);
		post_refid = NULL;
	}
	if (post_body != NULL)
	{
		MemPtrFree(post_body);
		post_body = NULL;
	}
} /* FreePostData */



//
//
// String is prepended in front of quotes.
// The prefs string may contain specials that are resolved here.
//
// \f : from (author's name)
// \a : author's address
// \i : msg id
// \n : newline
// \\ : '\'
// 

static void MakeIntro(char **intro)
{
	char tags[] = {"fani\\"},
		tagdum[3],
		*namedum,
		*qi, 
		*ii;
	Word len, taglen;
	int i;

	// Step 1: calculate the length of the intro
	
	len = StrLen(quote_intro) + 1;
	taglen = StrLen(tags);
	StrCopy(tagdum, "\\x");
	for (i = 0; (i < taglen); i++)
	{
		tagdum[1] = tags[i];
		if (StrStr(quote_intro, tagdum))
		{
			// tag found in quote_intro template
			len -= 2;
			switch (tags[i])
			{
				case 'f':
					len += StrLen(art.from); break; // too long is better than too short
					
				case 'a':
					len += StrLen(art.from); break; // also too long but who cares?
					
				case 'i':
					len += StrLen(art.msgid); break;

				case 'n':
					len += 1;

				default:
			}
		}
	}
	*intro = MemPtrNew(len);
	if (*intro == NULL)
	{
		return;
	}
	ii = *intro;

	// Step 2: parse intro string

	qi = quote_intro;
	while (*qi)
	{
		if (*qi != '\\')
		{
			*ii = *qi;
			ii++;
		}
		else
		{
			qi++;
			switch (*qi)
			{
				case 'f':
				{
					namedum = MemPtrNew(StrLen(art.from)+1);
					if (namedum == NULL)
					{
						MemPtrFree(*intro);
						*intro = NULL;
						return;
					}
					GetInfoOfFromField(art.from, namedum, yfFromStyle_name);
					StrCopy(ii, namedum); 
					ii += StrLen(namedum);
					break;
				}

				case 'a':
				{
					namedum = MemPtrNew(StrLen(art.from)+1);
					if (namedum == NULL)
					{
						MemPtrFree(*intro);
						*intro = NULL;
						return;
					}
					GetInfoOfFromField(art.from, namedum, yfFromStyle_address);
					StrCopy(ii, namedum); 
					ii += StrLen(namedum);
					break;
				}

				case 'i':
				{
					StrCopy(ii, art.msgid); 
					ii += StrLen(art.msgid);
					break;
				}

				case 'n':
				{
					StrCopy(ii, "\n"); 
					ii += 1;
					break;
				}
				
				case '\\':
				{
					StrCopy(ii, "\\"); 
					ii += 1;
					break;
				}
				

				default:
			}
			
		}
		qi++;
	}
} /* MakeIntro */



static void QuoteBody(char **dest, char *orig)
{
	Word lfcount,
		introcount = 0;
	Word len;
	char qsign[] = {"> "},
		*d,
		*intro = NULL;
	
	if (orig == NULL)
	{
		*dest = NULL;
		return;
	}
	
	MakeIntro(&intro);
	if (intro == NULL)
	{
		return;
	} 
	introcount= StrLen(intro);
	lfcount = CountLF(orig, &len);
	*dest = MemPtrNew(introcount + len + lfcount * StrLen(qsign) + 1 + 2);
	if (*dest == NULL)
	{
		return;
	}
	d = *dest;
	StrCopy(d, intro);
	d += introcount;
	while (*orig)
	{
		StrCopy(d, qsign);
		d += StrLen(qsign);
		while (*orig && (*orig != '\n'))
		{
			*d++ = *orig;
			orig++;
		}
		if (*orig)
		{
			*d++ = '\n';
			orig++;
		}
	}
	*d = 0;
} /* QuoteBody */




static void SaveAndExit(int draft)
{
	if (!SavePosting(draft))
	{
		NPUpdateForm(frmNewsgroups, 1);
		ClosePostField();
		FreePostData();
		NPExitForm();
	}
} /* SaveAndExit */




Boolean HandlePost(EventPtr event)
{
	int handled = 0;
	FormPtr frm;
	Word id;

    switch (event->eType)
    {
		case frmUpdateEvent:
		{
			FreePostData();
			NPExitForm();
			handled = 1;
			break;
		}
		
        case frmOpenEvent:
        {
			InitPostField();
            handled = 1;
            break;
        }

		case appStopEvent:
		{
			SaveAndExit(saveArticleAsDraftDueToQuit);
			break;
		}

		case fldChangedEvent:
		{
			UpdateField(fldPostText, sbPost);
			handled = 1;
			break;
		}

		case sclRepeatEvent:
		{
			ScrollField(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value, fldPostText, sbPost);
			break;
		}

        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case keyDownEvent:
		{
			switch (event->data.keyDown.chr)
			{
				case pageUpChr:
				{
					ScrollField(-postpagesize, fldPostText, sbPost);
					handled = 1;
					break;
				}

				case pageDownChr:
				{
					ScrollField(postpagesize, fldPostText, sbPost);
					handled = 1;
					break;
				}
				
				default:
				{
					frm = FrmGetActiveForm();
					id = FrmGetObjectId(frm, FrmGetFocus(frm));
					if ((id == fldPostNewsgroups) && (art_mode == artModeEMail))
					{
						if (StrChr("\t\n", event->data.keyDown.chr) != NULL)
						{
							handled = 1;
						}
					}
					else if (id == fldPostNewsgroups)
					{
						if (StrChr(" \t\n", event->data.keyDown.chr) != NULL)
						{
							handled = 1;
						}
					}
					else if (id == fldPostSubject)
					{
						if ((event->data.keyDown.chr != backspaceChr)
						   && ((event->data.keyDown.chr > 126) 
							|| (event->data.keyDown.chr < 32)
							|| (StrChr("\t\n", event->data.keyDown.chr) != NULL)))
						{
							handled = 1;
						}
					}
				}
			}
			break;
		}
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					ClosePostField();
					FreePostData();
					NPExitForm();
					handled = 1;
					break;
				}

				case btnPostSave:
				{
					SaveAndExit(saveArticleAsk);
					handled = 1;
					break;
				}

//				case btnPostSend:
//				{
//					if (NPOnlineMode())
//					{
//						if (!SavePosting(saveArticleAsReady))
//						{
//							NPInvokePoll(postLastMessage, 0);
//						}
//					}
//					else
//					{
//						FrmCustomAlert(altInfo, yf_must_be_online, " ", " ");
//					}
//					handled = 1;
//					break;
//				}

				default :;
			}
		}

        default:;
    }
    return handled;
} /* HandlePost */




int InvokePost(int edit, int artm, char *newsgroup, char *subject, 
	char *refid, char *body, DBServerNum server)
{
	if (edit)
	{
		selected_srv = server;
	}
	else
	{
		if (artm == artModeEMail)
		{
			selected_srv = 0;
		}
		else if ((artm == artModeNewsgroup) && (NGNewsgroupOpen()))
		{
			if (active_ng.server == 0)
			{
				FrmCustomAlert(altInfo, yf_no_server_for_group, " ", " ");
				return 0;
			}
			else
			{
				selected_srv = active_ng.server;
			}
		}
	}

	SrvReadServer(&srv, selected_srv);

	if (!*srv.username || !*srv.hostname || !*srv.zone
		|| !*srv.realname || !StrCompare(srv.hostname, yf_dummy_server)) 
		// sig may be empty
	{
		FrmCustomAlert(altInfo, yf_complete_setup, " ", " ");
		return 0;
	}
	edit_mode = edit;
	art_mode = artm;
	if (newsgroup != NULL)
	{
		post_ng = MemPtrNew(StrLen(newsgroup) + 1);	
		if (post_ng == NULL)
		{
			return 0;
		}
		StrCopy(post_ng, newsgroup);
	}
	if (subject != NULL)
	{
		post_subj = MemPtrNew(StrLen(subject) + 5);
		if (post_subj == NULL)
		{
			FreePostData();
			return 0;
		}
		if (!edit && (StrStr(subject, "Re:") != subject))
		{
			StrCopy(post_subj, "Re: ");
		}
		else
		{
			*post_subj = 0;
		}
		StrCat(post_subj, subject);
		init_subj = MemPtrNew(StrLen(post_subj) + 1);
		if (init_subj == NULL)
		{
			FreePostData();
			return 0;
		}
		StrCopy(init_subj, post_subj);
	}
	if (refid != NULL)
	{
		post_refid = MemPtrNew(StrLen(refid) + 1);
		if (post_refid == NULL)
		{
			FreePostData();
			return 0;
		}
		StrCopy(post_refid, refid);
	}
	if (body != NULL)
	{
		if (edit)
		{
			post_body = MemPtrNew(StrLen(body) + 1);
			if (post_body == NULL)
			{
				FreePostData();
				return 0;
			}
			StrCopy(post_body, body);
		}
		else
		{
			if (!FrmAlert(altQuote))
			{
				QuoteBody(&post_body, body);
			}
			else
			{
				post_body = NULL;			
			}
		}
	}
	else
	{
		post_body = NULL;
	}
	NPGotoForm(frmPost);
	return 1;
} /* InvokePost */
