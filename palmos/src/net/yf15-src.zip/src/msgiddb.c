/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// msgiddb.c
//
// newsgroup subscription management routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "artdb.h"
#include "subscrdb.h"
#include "prefs.h"
#include "msgiddb.h"


char msgiddb_name[] = {"NewsHistory"};


//
//
// All routines
// return 0 in case of success and
// return err > 0 in case of error
//



//
//
// Compare function
// if comp_db_entries is 1 the function compares db entries
// if comp_db_entries is 0 the value in *a1 is a string
//
// returns values like StrCompare
//

static Int comp_msgid(void *a1, void *a2, int comp_db_entries,
    SortRecordInfoPtr p1, SortRecordInfoPtr p2, VoidHand h)
{
    if (a1 == NULL)
    {
        return -1;
    }
    if (a2 == NULL)
    {
        return 1;
    }
	// the second parameter points to a database record - the rcv date
	// has to be skipped for the comparasion
    (char *) a2 += 4;

    return StrCompare((char *)a1, (char *)a2);
} /* comp_msgid */






//
//
// Add MsgID to database
// MsgID is added to the db and the db recurds are sorted
//
// returns 0 in case of success
// returns >0 in case of error
//

int MidAddMsgID(char *msgid)
{
    DmOpenRef db;
    ULong size,
    	timestamp;
    UInt pos = -1;
    VoidHand h;
    char *p;


    db = NPOpenDB(msgiddb_name);
    if (db == 0)
    {
        // db open error
        return 2;
    }

    pos = DmFindSortPositionV10(db, msgid, (DmComparF *)comp_msgid, 0);
    size = 4 + StrLen(msgid) + 1;
    h = DmNewRecord(db, &pos, size);
    if (h == 0)
    {
        // error
        DmCloseDatabase(db);
        return 3;
    }
    p = (char *) MemHandleLock(h);
	timestamp = TimGetSeconds();
	DmWrite(p, 0, &timestamp, 4);
    DmStrCopy(p, 4, msgid);
    MemHandleUnlock(h);
    DmReleaseRecord(db, pos, 1);
    DmCloseDatabase(db);
    return 0;
} /* MidAddMsgID */






//
//
// Find MsgID information in database
//

int MidMsgIDExists(char *msgid)
{
    UInt pos;
    DmOpenRef db;
    VoidHand h;
    Ptr p;
    int res;


    db = NPOpenDB(msgiddb_name);
    if (db == 0)
    {
        // db open error
        return 1;
    }

    pos = DmFindSortPositionV10(db, msgid, (DmComparF *)comp_msgid, 0);
    if (pos == 0)
    {
        DmCloseDatabase(db);
        return 0;
    }
    h = DmQueryRecord(db, pos - 1);
    if (h == 0)
    {
        DmCloseDatabase(db);
        return 0;
    }
    p = MemHandleLock(h);

    res = comp_msgid(msgid, p, 0, NULL, NULL, 0); // correct MsgID found?
    MemHandleUnlock(h);
    DmCloseDatabase(db);
    return !res;
} /* MidMsgIDExists */




int MidPurgeMsgIDs(ULong delta)
{
    DmOpenRef db;
    UInt pos, 
    	max;
    VoidHand h;
    Ptr p;
	ULong now,
		iddate;
	

	now = TimGetSeconds();

    db = NPOpenDB(msgiddb_name);
    if (db == 0)
    {
        // db open error
        return 1;
    }
	max = DmNumRecords(db);
	for (pos=0; (pos < max);)
	{
	    h = DmQueryRecord(db, pos);
	    if (h == 0)
	    {
	        return 2;
	    }
	    p = MemHandleLock(h);
		iddate = *(ULong *) p;
	    MemHandleUnlock(h);
	    if ((iddate + delta) < now)
	    {
		    if (DmRemoveRecord(db, pos) != 0)
		    {
		        DmCloseDatabase(db);
		        return 3;
		    }
		    max--; // one record less to delete
		}
		else
		{
			pos++; // record young enough - try next
		}
	}
    DmCloseDatabase(db);
    return 0;
} /* MidPurgeMsgIDs */


void MidSortMsgIds(void)
{
	DmOpenRef db;

    	db = NPOpenDB(msgiddb_name);
    	if (db == 0)
    	{
        	return;
    	}

        DmQuickSort(db, (DmComparF *)comp_msgid, 1);
    	DmCloseDatabase(db);
} /* MidSortMsgIds */





