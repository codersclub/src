/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// artdb.c
//
// article database routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "artdb.h"
#include "prefs.h"
#include "lang.h"
#include "serverdb.h"
#include "ngroup.h"

#define artdb_error 0
#define artdb_ok 1





#ifdef PRC2
static Word OptLen(char *field) SECTION_3;
static void OptWrite(Ptr p, Word pos, char *field) SECTION_3;
char *NPCopyBody2DB(char *dest, Word destpos, Word len, char *data) SECTION_3;
static void Make2DigitStr(char *dum, Long a) SECTION_3;
static int ArtCreateArticleHeader(struct serverdb_item *srv, DBServerNum snum,
	struct articledb_item *art, char *sub, char *ng, char *ref) SECTION_3;
#endif




char articledb_name[] = {"NewsArts"};

DmOpenRef artdb = NULL;




//
//
// Init article data to NULL values
//

void ArtInitArticleData(struct articledb_item *a)
{
    a->flags = 0;
    a->rcvdate = 0;
    a->xpostings = 0;
    a->server = 0;
    a->newsgroups = NULL;
    a->from = NULL;
    a->subject = NULL;
    a->date = NULL;
    a->body = NULL;
    a->ref = NULL;
    a->fup_to = NULL;
    a->headers = NULL;
} /* ArtInitArticleData */



//
//
// Free article data based on article structure
// Does NOT free the article struct itself!
//

void ArtFreeArticleData(struct articledb_item *a)
{
    FreePointer((Ptr) a->newsgroups);
    FreePointer((Ptr) a->from);
    FreePointer((Ptr) a->subject);
    FreePointer((Ptr) a->date);
    FreePointer((Ptr) a->body);
    FreePointer((Ptr) a->ref);
    FreePointer((Ptr) a->fup_to);
    FreePointer((Ptr) a->headers);
    ArtInitArticleData(a);
} /* ArtFreeArticleData */






DmOpenRef ArtOpenArticles(void)
{
	if (artdb == NULL)
	{
	    artdb = NPOpenDB(articledb_name);
	}
	return artdb;
} /* ArtOpenArticles */



void ArtCloseArticles(void)
{
	if (artdb != NULL)
	{
		DmCloseDatabase(artdb);
		artdb = NULL;
	}
} /* ArtOpenArticles */



int ArtRemoveArticlesDB(void)
{
	LocalID dbid;
	int records_deleted;

	records_deleted = (DmNumRecords(artdb) > 0);
	ArtCloseArticles();	
	dbid = DmFindDatabase(0, articledb_name);
	if (dbid != 0)
	{
		DmDeleteDatabase(0, dbid);
	}
	ArtOpenArticles();
	return records_deleted;
} /* ArtRemoveArticlesDB */




int ArtReadArticle(DBArtNum pos, struct articledb_item *art)
{
    VoidHand h;
    char *p;

    h = DmQueryRecord(artdb, pos);
    if (h == 0)
    {
        return 1;
    }
    p = (char *)MemHandleLock(h);

    art->flags = *(UInt *)p;
    p += sizeof(UInt);

    art->rcvdate = *(ULong *)p;
    p += sizeof(ULong);

    art->xpostings = *(UInt *)p;
    p += sizeof(UInt);

    art->server = *(DBServerNum *)p;
    p += sizeof(DBServerNum);

    art->from = p;
    p += StrLen(p) + 1;

    art->date = p;
    p += StrLen(p) + 1;

    art->subject = p;
    p += StrLen(p) + 1;

    art->newsgroups = p;
    p += StrLen(p) + 1;

    art->msgid = p;
    p += StrLen(p) + 1;

    art->ref = p;
    p += StrLen(p) + 1;
	
    art->fup_to = p;
    p += StrLen(p) + 1;
	
    art->headers = p;
    p += StrLen(p) + 1;
	
    art->body = p;

    MemHandleUnlock(h);
    return 0;
} /* ArtReadArticle */



static Word OptLen(char *field)
{
    if (field != NULL)
    {
	    return StrLen(field);
	}
	return 0; // empty ref + 0-terminator
} /* OptLen */


static void OptWrite(Ptr p, Word pos, char *field)
{
	if (field == NULL)
	{
	    DmStrCopy(p, pos, "");
	}
	else
	{
	    DmStrCopy(p, pos, field);
	}
} /* OptWrite */


//
//
// Create new article in database and append article header
// without body. This is appended by NPReadArticle2DB
// the database chunk is left open and its pointer, handle, offset and OpenRef
// are given back to NPReadArticle2DB
//
// Called by latter function without the body-part of *art (art->body == NULL)
//
// Returns 0 in case of error
// Returns 1 in case of success

int ArtAppendArticleHeader(struct articledb_item *art, DBArtNum *pos)
{
    UInt from_len,
        date_len,
        subject_len,
        newsgroups_len,
        msgid_len,
        ref_len,
        fup_to_len,
        headers_len,
        header_len;
    char *p;
    VoidHand h;
	Word bodypos, size;
	

    *pos = -1; // Append chunk to database
    size = 0;

    from_len = StrLen(art->from) + 1;
    date_len = StrLen(art->date) + 1;
    subject_len = StrLen(art->subject) + 1;
    newsgroups_len = StrLen(art->newsgroups) + 1;
    msgid_len = StrLen(art->msgid) + 1;
	ref_len = OptLen(art->ref) + 1;
    fup_to_len = OptLen(art->fup_to) + 1;
   	headers_len = OptLen(art->headers) + 1;
    

    header_len = 2 * sizeof(UInt) + sizeof(ULong) + sizeof(DBServerNum);
    header_len += from_len + date_len + subject_len + fup_to_len
	    		+ newsgroups_len + msgid_len + ref_len 
	    		+ headers_len + 1; // One byte for empty body

	h = DmNewRecord(artdb, pos, header_len);
    if (h == 0)
    {
        // Mem low
        FrmCustomAlert(alertID_dum, yf_mem_low, " ", " ");
        return 1;
    }
    p = (char *)MemHandleLock(h);

    DmWrite(p, 0, &(art->flags), sizeof(UInt));
    bodypos = sizeof(UInt);

    DmWrite(p, bodypos, &(art->rcvdate), sizeof(ULong));
    bodypos += sizeof(ULong);

    DmWrite(p, bodypos, &(art->xpostings), sizeof(UInt));
    bodypos += sizeof(UInt);

    DmWrite(p, bodypos, &(art->server), sizeof(DBServerNum));
    bodypos += sizeof(DBServerNum);

    DmStrCopy(p, bodypos, art->from);
    bodypos += from_len;

    DmStrCopy(p, bodypos, art->date);
    bodypos += date_len;

    DmStrCopy(p, bodypos, art->subject);
    bodypos += subject_len;

    DmStrCopy(p, bodypos, art->newsgroups);
    bodypos += newsgroups_len;

    DmStrCopy(p, bodypos, art->msgid);
    bodypos += msgid_len;
	
	OptWrite(p, bodypos, art->ref);
    bodypos += ref_len;

    OptWrite(p, bodypos, art->fup_to);
    bodypos += fup_to_len;
	
    OptWrite(p, bodypos, art->headers);
    bodypos += headers_len;
	
	DmStrCopy(p, bodypos, "");
	bodypos++;

    MemHandleUnlock(h);
    DmReleaseRecord(artdb, *pos, 1);
    return 0;
} /* ArtAppendArticleHeader */










//
//
// Copy message body from buffer to art structure - without
// the annoying '\r'
// len is size of the complete chunk dest
//
// Returns pointer to destination
//

char *NPCopyBody2DB(char *dest, Word destpos, Word len, char *data)
{
    len -= 1; // save place for 0-terminator
    while ((*data) && (destpos < len))
    {
        if (*data == '\r')
        {
            // skip CR - do nothing
        }
        else
        {
            DmSet(dest, destpos++, 1, *data);
        }
        data++;
    }
    DmSet(dest, destpos, 1, 0);
    return &dest[destpos];
} /* NPCopyBody2DB */






int ArtAppendArticleBody(DBArtNum pos, char *buf)
{
	VoidHand h;
	char *p, *end;
	Word bodypos,
		len;
	ULong old_len;
	
	// See how big the record is before we resize it.
	h = DmQueryRecord(artdb, pos);
	if (h == NULL)
	{
		return 1;
	}
	old_len = MemHandleSize(h);
	DmReleaseRecord(artdb, pos, 0);
	
	len = BUF_START_LEN;
	do
	{
		h = ArtResizeArticle(pos, len);
		if (h == NULL)
		{
			len -= BUF_LEN_DOWN;
		}
	}
	while ((h == NULL) && (len > 1024 + BUF_LEN_DOWN)); // arbitrary floor value

	if ((h == NULL) || (len < old_len))
	{
		// No mem could be allocated or the new chunk is 
		// smaller than the old one
		return 1;
	}
	
	h = DmGetRecord(artdb, pos);
	if (h == 0)
	{
		return 2;
	}
	p = (char *) MemHandleLock(h);
	bodypos = 10 ; // 2 + 4 + 2 + 2
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	bodypos += StrLen(p + bodypos) + 1;
	end = NPCopyBody2DB(p, bodypos, len, buf);
	MemHandleUnlock(h); 
	DmReleaseRecord(artdb, pos, 1);
	ArtResizeArticle(pos, end - p + 1);
	return 0;
} /* ArtAppendArticleBody */



static void Make2DigitStr(char *dum, Long a)
{
	StrIToA(dum, a);
	if (dum[1] == 0)
	{
		dum[1] = *dum;
		*dum = '0';
		dum[2] = 0;
	}
} /* Make2DigitStr */


static int ArtCreateArticleHeader(struct serverdb_item *srv, DBServerNum snum,
	struct articledb_item *art, char *sub, char *ng, char *ref)
{
	char dum[20];
	DateTimeType dt;

	art->flags |= yfArticleFlagDontReindex;
	art->rcvdate = -1; // never expire own articles
	art->server = snum;
	art->from = MemPtrNew(StrLen(srv->username) + 1 + StrLen(srv->hostname) 
		+ 2 + StrLen(srv->realname) + 1 + 1);
	if (art->from == 0)
	{
		return 1;
	}
	StrCopy(art->from, srv->username);
	StrCat(art->from, "@");
	StrCat(art->from, srv->hostname);
	StrCat(art->from, " (");
	StrCat(art->from, srv->realname);
	StrCat(art->from, ")");

	TimSecondsToDateTime(TimGetSeconds(), &dt);
	art->date = MemPtrNew(40);
	if (art->date == 0)
	{
		ArtFreeArticleData(art);
		return 2;
	}
	StrCopy(art->date, wdays[dt.weekDay]);
	StrCat(art->date, ", ");
	StrIToA(dum, dt.day);
	StrCat(art->date, dum);
	StrCat(art->date, " ");
	StrCat(art->date, mons[dt.month - 1]);
	StrCat(art->date, " ");
	StrIToA(dum, dt.year);
	StrCat(art->date, dum);
	StrCat(art->date, " ");

	Make2DigitStr(dum, dt.hour);
	StrCat(art->date, dum);
	StrCat(art->date, ":");
	Make2DigitStr(dum, dt.minute);
	StrCat(art->date, dum);
	StrCat(art->date, ":");
	Make2DigitStr(dum, dt.second);
	StrCat(art->date, dum);
	StrCat(art->date, " ");
	StrCat(art->date, srv->zone);
	

	art->subject = MemPtrNew(StrLen(sub) + 1);
	if (art->subject == 0)
	{
		ArtFreeArticleData(art);
		return 3;
	}
	StrCopy(art->subject, sub);
	
	art->newsgroups = MemPtrNew(StrLen(ng) + 1);
	if (art->newsgroups == 0)
	{
		ArtFreeArticleData(art);
		return 4;
	}
	StrCopy(art->newsgroups, ng);
	
	art->msgid = MemPtrNew(20 + StrLen(srv->hostname));
	if (art->msgid == 0)
	{
		ArtFreeArticleData(art);
		return 5;
	}
	
	StrCopy(art->msgid, "<");
	StrIToH(dum, TimGetSeconds());
	StrCat(art->msgid, dum);
	StrCat(art->msgid, "yf@");
	StrCat(art->msgid, srv->hostname);
	StrCat(art->msgid, ">");
	
	art->ref = MemPtrNew(StrLen(ref) + 1);
	if (art->ref == 0)
	{
		ArtFreeArticleData(art);
		return 6;
	}
	StrCopy(art->ref, ref);

	art->headers = MemPtrNew(StrLen(active_ng.headers) + 1);
	if (art->headers == 0)
	{
		ArtFreeArticleData(art);
		return 7;
	}
	StrCopy(art->headers, active_ng.headers);

	if ((StrChr(art->newsgroups, '@') != NULL) && (srv->auth_user != NULL))
	{
		// this is an eMail message and the user entered a Reply-To
		// (which is saved in the auth_user field)
		art->fup_to = MemPtrNew(StrLen(srv->auth_user) + 1);
		if (art->fup_to == 0)
		{
			ArtFreeArticleData(art);
			return 7;
		}
		StrCopy(art->fup_to, srv->auth_user);
	}

	return 0;
} /* ArtCreateArticleHeader */



int ArtSaveNewArticle(struct serverdb_item *srv, DBServerNum snum, char *subj, 
	char *newsgr, char *refid, char *body, DBArtNum *pos)
{
	struct articledb_item art;
	
	ArtInitArticleData(&art);	
	ArtCreateArticleHeader(srv, snum, &art, subj, newsgr, refid);
	
	if (!ArtAppendArticleHeader(&art, pos))
	{
		if (ArtAppendArticleBody(*pos, body))
		{
			FrmCustomAlert(alertID_dum, yf_save_art_err, " ", " ");
			ArtFreeArticleData(&art);
			return 1;
		}
	}
	ArtFreeArticleData(&art);
	return 0;
} /* ArtSaveNewArticle */





//
//
// Change an articles xposting count with ID uid
// 

UInt ArtChangeArticleXP(ULong uid, int dcount, int relative)
{
	VoidHand h;
    char *p;
    UInt *xp, xpdum, pos;
	
	if (DmFindRecordByID(artdb, uid, &pos) != 0)
	{
		return -1;
	}
	h = DmQueryRecord(artdb, pos);
	if (h == 0)
	{
		return -1;
	}
    p = (char *)MemHandleLock(h);
	if (relative)
	{
	    xp = (UInt *)(p + sizeof(UInt) + sizeof(ULong));
	    xpdum = (*xp) + dcount;
	}
	else
	{
		xpdum = dcount;
	}
    DmWrite(p, sizeof(UInt) + sizeof(ULong), &xpdum, sizeof(UInt));
    MemHandleUnlock(h);
	return xpdum;
} /* ArtChangeArticleXP */






//
//
// Delete Article from NewsArts
//
// First reduce appropriate xposting-count. If it reaches zero: remove article.
//

int ArtDeleteArticle(ULong uid)
{
    UInt xpdum, pos;


	if (DmFindRecordByID(artdb, uid, &pos) != 0)
	{
		return 1;
	}

	xpdum = ArtChangeArticleXP(uid, -1, 1);	

    if (xpdum == 0)
    {
        DmRemoveRecord(artdb, pos);
    }
    return 0;
} /* ArtDeleteArticle */



//
//
// Find article with unique ID uid in the global article database
//

int ArtSeekArticle(ULong uid, DBArtNum *pos)
{
	return DmFindRecordByID(artdb, uid, pos);
} /* ArtSeekArticle */



VoidHand ArtResizeArticle(DBArtNum pos, Word len)
{
	VoidHand h;

	h = DmResizeRecord(artdb, pos, len);
	return h;
} /* ArtResizeArticle */


ULong ArtGetArticleUID(DBArtNum pos)
{
	ULong uid;
	
	if (DmRecordInfo(artdb, pos, NULL, &uid, NULL))
	{
		return 0;
	}
	return uid;
} /* ArtGetArticleUID */



//
//
// Set an article flag on the article with unique ID uid
// value -1: toggle, value 0: set to 0, value 1: set to 1
//

int ArtSetArticleFlag(ULong uid, int flag, int value)
{
	VoidHand h;
	UInt *f, f2;
	DBArtNum pos;
	
	if (DmFindRecordByID(artdb, uid, &pos) != 0)
	{
		return 1;
	}
	h = DmQueryRecord(artdb, pos);
	if (h == 0)
	{
		return 2;
	}
	f = (UInt *) MemHandleLock(h);
	f2 = *f;
	if (value == -1)
	{
		f2 ^= flag;
	}
	else if (value == 1)
	{
		f2 |= flag;
	}
	else if (value == 0)
	{
		f2 &= (~flag);
	}
	DmWrite(f, 0, &f2, sizeof(f2));
	MemHandleUnlock(h);
	return 0;
} /* ArtSetArticleFlag */



UInt ArtArticlesCount(void)
{
	return DmNumRecords(artdb);
} /* ArtArticlesCount */






int ArtPurgeArticles(ULong deltadays)
{
	DBArtNum count, act;
	struct articledb_item art;
	ULong max;
	int somethinghappened = 0;
	
	max = TimGetSeconds() - (deltadays * 86400);
	count = ArtArticlesCount();
	for (act=0; (act < count);)
	{
		ArtReadArticle(act, &art);
		if ((art.rcvdate < max) && !(art.flags & yfArticleFlagKeep))
		{
			DmRemoveRecord(artdb, act);
			somethinghappened = 1;
			count--;
		}
		else
		{
			act++;
		}
	}
	return somethinghappened;
} /* ArtPurgeArticles */




//
//
// When a server is deleted, the servers with higher order in the database
// get a position that is their old position minus one.
// This routine changes a given article's server number that way.
//

int ArtUpdateServerNum(DBArtNum pos)
{
	VoidHand h;
	char *f;
	DBServerNum snum;
	
	h = DmQueryRecord(artdb, pos);
	if (h == 0)
	{
		return 2;
	}
	f = (char *) MemHandleLock(h);
	
	f += 8;
	snum = *(DBServerNum *) f;
	snum--; // Update server number - a server has been deleted

	DmWrite(f, 0, &snum, sizeof(DBServerNum));
	MemHandleUnlock(h);
	return 0;
} /* ArtUpdateServerNum */
