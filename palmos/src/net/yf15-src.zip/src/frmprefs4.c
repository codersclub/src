/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmprefs4.c
//
// handle the newsgroups prefs form of yanoff
// Matthias Jordan, 9-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/DateTime.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefs4.h"
#include "prefs.h"
#include "ngroup.h"
#include "subscrdb.h"
#include "lang.h"


VoidHand hname, hartmax, hdownmax, hsamplearts, hheaders;
struct subscriptiondb_item sub;
int called_after_subs; // Form called after subscribing or by menu?



static int SavePrefs(void)
{
	int res;
	char *ngname;

	ngname = MemPtrNew(1); // to fool GetVariableField
	if ((res = GetVariableField("Name", fldPrefs4Name, &ngname)) != 0)
	{
		return res;
	}
	if ((res = GetFormValue("Article max", fldPrefs4MaxKB, &sub.ng_artmaxkb)) != 0)
	{
		return res;
	}
	if ((res = GetFormValue("Download max", fldPrefs4DownMax, &sub.ng_downmax)) != 0)
	{
		return res;
	}
	if ((res = GetFormValue("Sample arts", fldPrefs4SampleArts, &sub.ng_samplearts)) != 0)
	{
		return res;
	}

	if (LstGetSelection(GetObjectPtr(lstPrefs4Poll)) == 0)
	{
		sub.ng_flags &= ~yfNGFlag_poll_next; // poll last
	}
	else
	{
		sub.ng_flags |= yfNGFlag_poll_next; // poll next
	}

	sub.thread_arts = CtlGetValue(GetObjectPtr(chkPrefs4Thread));

	if (CtlGetValue(GetObjectPtr(chkPrefs4Poll)))
	{
		sub.ng_flags &= ~yfNGFlag_dont_poll;
	}
	else
	{
		sub.ng_flags |= yfNGFlag_dont_poll;
	}

	sub.title_contents = LstGetSelection(GetObjectPtr(lstPrefs4display));

	sub.server = LstGetSelection(GetObjectPtr(lstPrefs4Server));
	if (sub.server == 0)
	{
		sub.ng_flags |= yfNGFlag_dont_poll; // no server -> don't poll
	}

	if (StrCompare(sub.newsgroup, ngname))
	{
		NPUpdateForm(frmNewsgroups, 1);
		NPUpdateForm(frmArtList, updArtListMajorChanges);
	}
	sub.newsgroup = ngname;
	SubSetSubscriptionInfo(NGActiveNGNum(), &sub);
	MemPtrFree(ngname);
	return 0;
} /* SavePrefs */



static void InitForm(void)
{
	FieldPtr fld;
	char *name, *artmax, *downmax, *samplearts;
	ControlPtr ctl;
	ListPtr lst;
	DBServerNum i_count;

	SubGetSubscriptionByPos(NGActiveNGNum(), &sub);
	
	hname = MemHandleNew(StrLen(sub.newsgroup) + 1);
	hartmax = MemHandleNew(7);
	hdownmax = MemHandleNew(7);
	hsamplearts = MemHandleNew(7);
	
	if (!(hname && hartmax && hdownmax && hsamplearts))
	{
		return;
	}
	name = (char *) MemHandleLock(hname);
	artmax = (char *) MemHandleLock(hartmax);
	downmax = (char *) MemHandleLock(hdownmax);
	samplearts = (char *) MemHandleLock(hsamplearts);

	StrCopy(name, sub.newsgroup);
	StrIToA(artmax, sub.ng_artmaxkb);
	StrIToA(downmax, sub.ng_downmax);
	StrIToA(samplearts, sub.ng_samplearts);
	
	MemHandleUnlock(hname);
	MemHandleUnlock(hartmax);
	MemHandleUnlock(hdownmax);
	MemHandleUnlock(hsamplearts);

	fld = GetObjectPtr(fldPrefs4Name);
	FldSetTextHandle(fld, (Handle) hname);

	fld = GetObjectPtr(fldPrefs4MaxKB);
	FldSetTextHandle(fld, (Handle) hartmax);

	fld = GetObjectPtr(fldPrefs4DownMax);
	FldSetTextHandle(fld, (Handle) hdownmax);

	fld = GetObjectPtr(fldPrefs4SampleArts);
	FldSetTextHandle(fld, (Handle) hsamplearts);

	ctl = GetObjectPtr(chkPrefs4Poll);
	if (!(sub.ng_flags & yfNGFlag_internal))
	{
		if (sub.server == 0)
		{
			CtlSetValue(ctl, 0);
		}
		else
		{
			CtlSetValue(ctl, !(sub.ng_flags & yfNGFlag_dont_poll));
		}
	}
	else
	{
		CtlSetUsable(ctl, 0);
		FrmCopyLabel(FrmGetActiveForm(), lblPrefs4Poll, " ");
	}

	ctl = GetObjectPtr(chkPrefs4Thread);
	CtlSetValue(ctl, sub.thread_arts);

	ctl = GetObjectPtr(trgPrefs4Poll);
	lst = GetObjectPtr(lstPrefs4Poll);
	LstSetSelection(lst, (sub.ng_flags & yfNGFlag_poll_next) ? 1 : 0);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	ctl = GetObjectPtr(trgPrefs4display);
	lst = GetObjectPtr(lstPrefs4display);
	LstSetSelection(lst, sub.title_contents);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	servers = SrvGetServerList(srv_list_mode_none, &i_count);
	ctl = GetObjectPtr(trgPrefs4Server);
	lst = GetObjectPtr(lstPrefs4Server);
	LstSetListChoices(lst, servers, SrvServersCount());
	LstSetHeight(lst, min(i_count, 5));
	LstSetSelection(lst, sub.server);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));
} /* InitForm */



static void ClearFields(void)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldPrefs4Name);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs4MaxKB);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs4DownMax);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs4SampleArts);
	FldSetTextHandle(fld, 0);
	
	MemHandleFree(hname);
	MemHandleFree(hartmax);
	MemHandleFree(hdownmax);
	MemHandleFree(hsamplearts);
} /* ClearFields */





Boolean HandlePrefs4(EventPtr event)
{
    int handled = 0;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitForm();
            RefreshForm();
            handled = 1;
            break;
        }
           
        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					ClearFields();
					SrvFreeServerList(servers);
					if (called_after_subs)
					{
						NGCloseNewsgroup();
						NPExitForm();
					}
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					res = SavePrefs();
					NGReopenNewsgroup();
					if (!res)
					{
						ClearFields();
						if (called_after_subs)
						{
							NGCloseNewsgroup();
							NPExitForm();
						}
						NPExitForm();
					}
					handled = 1;
					break;
				}
				
				case btnPrefs4Headers:
				{
					NPGotoForm(frmPrefs4CustomHeaders);
					handled = 1;
					break;
				}
				
				default:
			}
			break;
		}
		
        default:
		
    }
    return handled;
} /* HandlePrefs4 */
















static int SaveHeaders(void)
{
	int res;
	char *dum;
	
	dum = MemPtrNew(1);

	if ((res = GetVariableField(NULL, fldPrefs4Headers, &dum)) != 0)
	{
		return res;
	}

	sub.headers = dum;

	return 0;
} /* SaveHeaders */



static void InitFormHeaders(void)
{
	FieldAttrType attr;
	FieldPtr fld;
	char *headers;
	
	hheaders = MemHandleNew(StrLen(sub.headers) + 1);
	
	if (!hheaders)
	{
		return;
	}
	headers = (char *) MemHandleLock(hheaders);
	
	StrCopy(headers, sub.headers);
	
	MemHandleUnlock(hheaders);

	fld = GetObjectPtr(fldPrefs4Headers);
	FldSetTextHandle(fld, (Handle) hheaders);
	
	FldSetScrollPosition(fld, 0);
    FldGetAttributes(fld, &attr);
    attr.hasScrollBar = 1;
    FldSetAttributes(fld, &attr);
	UpdateField(fldPrefs4Headers, sbPrefs4Headers);
} /* InitFormPost */



static void ClearFieldsHeaders(void)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldPrefs4Headers);
	FldSetTextHandle(fld, 0);
	
	MemHandleFree(hheaders);
} /* ClearFieldsHeaders */





Boolean HandlePrefs4CustomHeaders(EventPtr event)
{
    int handled = 0;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitFormHeaders();
            RefreshForm();
            handled = 1;
            break;
        }

		case fldChangedEvent:
		{
			UpdateField(fldPrefs4Headers, sbPrefs4Headers);
			handled = 1;
			break;
		}

		case sclRepeatEvent:
		{
			ScrollField(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value, fldPrefs4Headers, sbPrefs4Headers);
			break;
		}
		
        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					ClearFieldsHeaders();
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					if (!FrmAlert(altHeadersConf))
					{
						res = SaveHeaders();
						if (!res)
						{
							ClearFieldsHeaders();
							NPExitForm();
						}
					}
					handled = 1;
					break;
				}

				default:
			}
			break;
		}
		
		case keyDownEvent:
		{
			handled = HandleInput(event, fldPrefs2Realname, 2, " ");
			break;
		}
		
		
        default:
		
    }
    return handled;
} /* HandlePrefs4CustomHeaders */






void InvokePrefs4Newsgroups(int cas)
{
	called_after_subs = cas;
	NPGotoForm(frmPrefs4Newsgroup);
} /* InvokePrefs4Newsgroups */