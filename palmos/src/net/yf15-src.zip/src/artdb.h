/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// artdb.h
//
// article database headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef ARTDB_H
#define ARTDB_H


#include "yanoff.h"
#include "serverdb.h"


//
// The article
//

typedef struct articledb_item
{
    UInt flags;				// Valid values: yfArticleFlagXXX (see below)
    ULong rcvdate;
    UInt xpostings;			// has the number of incarnations on the device (NOT the CrossPostings)
	DBServerNum server;		// in outgoing group: number of server; else 0
    char *from,
         *date,
         *subject,
         *newsgroups,
         *msgid,
         *ref,				// Only used for own follow-ups - not read from network
         *fup_to,			// used for follow-ups - Reply-To in eMail messages
         *headers,			// used for posting
         *body;
} articledb_item;

typedef unsigned short DBArtNum;



#define yfArticleFlagMarked 1
#define yfArticleFlagRead 2
#define yfArticleFlagKeep 4
#define yfArticleFlagDontReindex 8


void ArtInitArticleData(struct articledb_item *a) SECTION_3;
void ArtFreeArticleData(struct articledb_item *a) SECTION_3;


DmOpenRef ArtOpenArticles(void) SECTION_3;
void ArtCloseArticles(void) SECTION_3;
int ArtRemoveArticlesDB(void) SECTION_3;


// Append article to global article database
int ArtAppendArticleHeader(struct articledb_item *art, DBArtNum *pos) SECTION_3;
    
int ArtAppendArticleBody(DBArtNum pos, char *buf) SECTION_3;


int ArtSaveNewArticle(struct serverdb_item *srv, DBServerNum snum, char *subj,
	char *newsgr, char *refid, char *body, DBArtNum *pos) SECTION_3;
    

// Read article from global article database
int ArtReadArticle(DBArtNum pos, struct articledb_item *art) SECTION_3;

UInt ArtChangeArticleXP(ULong uid, int dcount, int relative) SECTION_3;

// Reduce xposting counter and delete article from db if xpostings == 0
int ArtDeleteArticle(ULong uid) SECTION_3;

// Get article with unique ID uid in open newsgroup
int ArtSeekArticle(ULong uid, DBArtNum *pos) SECTION_3;

int ArtSetArticleFlag(ULong uid, int flag, int value) SECTION_3;

VoidHand ArtResizeArticle(DBArtNum pos, Word len) SECTION_3;

ULong ArtGetArticleUID(DBArtNum pos) SECTION_3;
UInt ArtArticlesCount(void) SECTION_3;
//void ArtFreeArticleData(struct articledb_item *a) SECTION_3;
int ArtPurgeArticles(ULong deltadays) SECTION_3;
int ArtUpdateServerNum(DBArtNum pos) SECTION_3;


#endif

