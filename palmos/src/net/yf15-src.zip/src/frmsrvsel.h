/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
#ifndef FRMSRVSEL_H
#define FRMSRVSEL_H

//
//
// frmsrvsel.c
//
// handle the server selection form of yanoff
// Matthias Jordan, 9-1999
//
//



#ifndef OS35
	#pragma pack(2)
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "serverdb.h"

extern DBServerNum selected_srv;

Boolean HandleServerSelection(EventPtr event) SECTION_3;
void InvokeServerSelection(int edit, int artm, char *newsgroup, char *subject, 
	char *refid, char *body) SECTION_3;

#endif