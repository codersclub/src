/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// hardbtn.c
//
// routines for the handling of hardbuttons for use with yanoff
// Matthias Jordan, 9-2000
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
	#include<System/Chars.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "prefs.h"
#include "lang.h"
#include "hardbtn.h"




#ifdef PRC2
// prototypes for multisegment code
#endif



void HighlightActEntry(Word tableid, DBNGNum sel_list_item, int delete)
{
	RectangleType r, rdum;
	TablePtr tbl;
	
	tbl = GetObjectPtr(tableid);
	TblGetItemBounds(tbl, sel_list_item, 0, &r);
	if (tableid == tblArtList)
	{
		TblGetItemBounds(tbl, sel_list_item, 1, &rdum);
		r.extent.x += rdum.extent.x;
	}

	r.topLeft.y++;
	r.extent.y--;
	if (delete)
	{
		WinEraseRectangleFrame(rectangleFrame, &r);
	}
	else
	{
		WinDrawGrayRectangleFrame(rectangleFrame, &r);
	}
} /* HighlightActNG */




void ScrollHighlighting(Word tableid, int lines, int advance_selection, DBNGNum *sel_list_item, DBNGNum sel_item)
{
	TablePtr table;
	Word rows, last_row;

	table = GetObjectPtr (tableid);
	rows = TblGetNumberOfRows(table);
	last_row = TblGetLastUsableRow(table);
	if (last_row < rows)
	{
		rows = last_row + 1;
	}

	HighlightActEntry(tableid, *sel_list_item, 1);
	*sel_list_item -= lines;
	*sel_list_item += advance_selection;

	// Check whether selection scrolled out of visible area
	if ((*sel_list_item > (rows + 100)) // wrap-around
		|| (*sel_list_item < 0))
	{
		*sel_list_item = 0;
	}
	else if (*sel_list_item > rows - 1)
	{
		*sel_list_item = rows - 1;
	}
		
	HighlightActEntry(tableid, *sel_list_item, 0);
} /* ScrollHighlighting */




static int HandleNewsgroupsButtons(WChar chr)
{
	int handled_by_yanoff = 0;

	switch (chr)
	{
		case vchrHard1:
		case vchrHard2:
		case vchrHard3:
		case vchrHard4:
//		case pageUpChr:
//		case pageDownChr:
		{
			handled_by_yanoff = 1; 
			break;
		}
	
		default:
	}
	return handled_by_yanoff;
} /* HandleNewsgroupsButtons */






int HandleHardbuttons(EventPtr event)
{
	Word frmid;
	int handled_by_yanoff = 0;
	WChar chr;

	if (event->eType != keyDownEvent)
	{
		return 0;
	}
	
	if (!(event->data.keyDown.modifiers & commandKeyMask))
	{
		return 0;
	}

	if (event->data.keyDown.modifiers & autoRepeatKeyMask)
	{
		return 0;
	}

	if (event->data.keyDown.modifiers & poweredOnKeyMask)
	{
		return 0;
	}
		
	chr = event->data.keyDown.chr;
	frmid = FrmGetActiveFormID();

	if (yprefs.buttons)
	{
		handled_by_yanoff = HandleNewsgroupsButtons(chr);
	}
	else
	{
		handled_by_yanoff = 0;
	}
	
	return handled_by_yanoff;
} /* HandleHardbuttons */
