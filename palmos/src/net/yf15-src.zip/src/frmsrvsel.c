/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmsrvsel.c
//
// handle the server selection form of yanoff
// Matthias Jordan, 9-1999
//
//


//#pragma pack(2)

//#include <Common.h>
//#include <System/SysAll.h>
//#include <UI/UIAll.h>
//#include <System/DataMgr.h>
//#include <System/NetMgr.h>
//#include <System/DateTime.h>


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefsp.h"
#include "prefs.h"
#include "ngroup.h"
#include "subscrdb.h"
#include "network.h"
#include "lang.h"
#include "serverdb.h"
#include "frmpost.h"
#include "frmsrvsel.h"



#ifdef PRC2
static DBServerNum GetSelection(void) SECTION_3;
static void InitForm(void) SECTION_3;
Boolean HandleServerSelection(EventPtr event) SECTION_3;
void InvokeServerSelection(int edit, int artm, char *newsgroup, char *subject, 
	char *refid, char *body) SECTION_3;
#endif



DBServerNum selected_srv;


int sedit, sartm;
char *snewsgroup, *ssubject, *srefid, *sbody;



static DBServerNum GetSelection(void)
{
	return LstGetSelection(GetObjectPtr(lstSrvSel));
} /* SavePollPrefs */




static void InitForm(void)
{
	ControlPtr ctl;
	ListPtr lst;
	char **servers;
	DBServerNum list_count;

	servers = SrvGetServerList(srv_list_mode_post, &list_count);
	ctl = GetObjectPtr(trgSrvSel);
	lst = GetObjectPtr(lstSrvSel);
	LstSetListChoices(lst, servers, list_count);
	LstSetHeight(lst, min(list_count, 5));
	LstSetSelection(lst, 0);
	CtlSetLabel(ctl, LstGetSelectionText(lst, 0));
} /* InitForm */




Boolean HandleServerSelection(EventPtr event)
{
    int handled = 0;

    switch (event->eType)
    {
  		case frmUpdateEvent:
        case frmOpenEvent:
        {
			InitForm();
            RefreshForm();
            handled = 1;
            break;
        }
	           
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					selected_srv = -1;
					NPExitForm();
					handled = 1;
					break;
				}
						
				case btnOK:
				{
					selected_srv = GetSelection() + 1;
					NPExitForm();
					InvokePost(sedit, sartm, snewsgroup, ssubject, srefid, sbody, selected_srv);
					handled = 1;
					break;
				}
						
				default:
			}
			break;
		}
				
        default:
    } // switch

    
    return handled;
} /* HandleServerSelection */



void InvokeServerSelection(int edit, int artm, char *newsgroup, char *subject, 
	char *refid, char *body)
{

	if (SrvServersCount() == 2)
	{
		// There are only two servers present: one eMail server
		// and one news server - so we use the only new server we can
		InvokePost(edit, artm, newsgroup, subject, refid, body, 1);
		return;
	}

	sedit = edit;
	sartm = artm;
	snewsgroup = newsgroup;
	ssubject = subject;
	srefid = refid;
	sbody = body;

	NPGotoForm(frmServerSelection);
} /* InvokeServerSelection */

