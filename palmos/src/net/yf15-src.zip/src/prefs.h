/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
#ifndef PREFS_H
#define PREFS_H

//
//
//  Handle application preferences
//
//

#include "frmprefsp.h"
#include "subscrdb.h"
#include "artdb.h"


// Prefs sections in SavedPreferences
#define yMainPrefs 1
#define pprefs_all 2
#define pprefs_ng 3
#define yPrefsIntro 4

// Prefs sections in UnsavedPreferences
#define ySavedState 1



#define yfFromStyle_address 0
#define yfFromStyle_name 1
#define yfFromStyle_both 2

#define yfButtonsLayout_none 0
#define yfButtonsLayout_right 1
#define yfButtonsLayout_left 2

#define yfPageSizeOneLine 0
#define yfPageSizeOnePage 1
#define yfPageSizeOnePageMinOne 2




typedef struct prefs
{
	UInt idpurgedays,
		artpurgedays,
		samplearts,			// no longer user configurable
		artmaxkb,			// no longer user configurable
		artspx,             // separator position in article list
		ngspx;              // separator position in newsgroups list
	char scoring,			// use scoring system?
		beep,
		cutsig,
		jump_back,			// jump back to old position when entering Yanoff?
		from_style,			// show author's name, email or both of them?
		wrap_len,
		buttons,			// which button layout to use (if any)
		pagesize;			// how far to page when in last or first column
} prefs_t;


typedef struct pollprefs
{
	char poll_what,
		poll_from;
	UInt poll_server;
	char post_news;
	char post_email;
	char poll_news;
	char dum;
} pollprefs_t;


typedef struct state
{
	DBNGNum last_ng;
	DBArtNum dummy1,
		last_art;
	int need_sort,
		currently_writing_article;
	DBArtNum dummy2;
} state_t;



extern struct pollprefs pprefs;
extern struct prefs yprefs;
extern struct state ystate;
extern char *quote_intro;



void PrSavePrefs(void);
void PrGetPrefs(void);

void PrSaveState(void);
void PrGetState(void);


void PrSetSortNeeded(int sort_needed);
int PrSortNeeded(void);


void PrSavePollPrefs(int mode, struct pollprefs *prefs);
void PrGetPollPrefs(int mode, struct pollprefs *prefs);

#endif