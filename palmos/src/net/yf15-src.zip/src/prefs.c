/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// prefs.c
//
// handle the prefs form of yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/DateTime.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefsp.h"
#include "frmart.h"
#include "frmartlist.h"
#include "ngroup.h"
#include "prefs.h"

struct pollprefs pprefs;
struct prefs yprefs;
struct state ystate;
char *quote_intro = NULL;

#define savedPrefs 1
#define unsavedPrefs 0



// ---------
//
//
// App Prefs
//
//
// ---------


void PrSavePrefs(void)
{
	PrefSetAppPreferences(CREATOR, yMainPrefs, VERSION, &yprefs, sizeof(prefs_t), savedPrefs);
	PrefSetAppPreferences(CREATOR, yPrefsIntro, VERSION, quote_intro, StrLen(quote_intro)+1, savedPrefs);
} /* PrSavePrefs */



void PrGetPrefs(void)
{
	Word size;

	size = sizeof(prefs_t);
	// load defaults
	yprefs = (prefs_t) {3, 2, 20, 1, 30, 30, 0, 1, 0, 1, 0, 65, 0, 1};
	PrefGetAppPreferences(CREATOR, yMainPrefs, &yprefs, &size, savedPrefs);
	size = 0;
	PrefGetAppPreferences(CREATOR, yPrefsIntro, NULL, &size, savedPrefs);
	if (size == 0)
	{	
		size = 30;
	}
	quote_intro = MemPtrNew(size);
	if (quote_intro != NULL)
	{
		StrCopy(quote_intro, "Hello, \\f!\\nYou wrote:\\n\\n");
		PrefGetAppPreferences(CREATOR, yPrefsIntro, quote_intro, &size, savedPrefs);
	}
} /* PrGetPrefs */



// ----------
//
//
// State
//
//
// ----------





void PrSaveState(void)
{
	ystate.last_ng = NGActiveNGNum();
//	ystate.last_top = FrmArtListTopArticle();
	ystate.last_art = FrmArtActiveArtNum();	
	PrefSetAppPreferences(CREATOR, 1, VERSION, &ystate, sizeof(state_t), unsavedPrefs);
} /* PrSaveState */



void PrGetState(void)
{
	Word size;

	size = sizeof(state_t);
	ystate = (state_t) {-1, -1, -1, 0, -1, -1};
	if (yprefs.jump_back)
	{
		PrefGetAppPreferences(CREATOR, 1, &ystate, &size, unsavedPrefs);
	}
} /* PrGetState */



void PrSetSortNeeded(int sort_needed)
{
	PrGetState();
	ystate.need_sort = sort_needed;
	PrSaveState();
} /* PrSetSortNeeded */


// Beware: PrGetState has to be called before this function
int PrSortNeeded(void)
{
	return ystate.need_sort;
} /* PrSortNeeded */



// ----------
//
//
// Poll Prefs
//
//
// ----------



void PrSavePollPrefs(int mode, struct pollprefs *prefs)
{
	PrefSetAppPreferences(CREATOR, mode, VERSION, prefs, sizeof(*prefs), savedPrefs);
} /* PrSavePollPrefs */





void PrGetPollPrefs(int mode, struct pollprefs *prefs)
{
	Word size;

	size = sizeof(pollprefs_t);
	if (mode == pprefs_all)
	{
		*prefs = (pollprefs_t) {0, 1, 2, 1, 1, 1};
	}
	else
	{
		*prefs = (pollprefs_t) {0, 0, 1, 1, 1, 1};
	}
	PrefGetAppPreferences(CREATOR, mode, prefs, &size, savedPrefs);
} /* PrGetPollPrefs */
