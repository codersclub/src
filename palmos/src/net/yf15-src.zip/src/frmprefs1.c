/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmprefs.c
//
// handle the misc prefs form of yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/NetMgr.h>
	#include <System/DateTime.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "frmprefs1.h"
#include "prefs.h"
#include "ngroup.h"
#include "lang.h"


VoidHand hid, hart, hintro;




static int SavePrefs(void)
{
	ControlPtr chk;
	char old_from_style;

	if (GetFormValue(yf_id_purge, fldPrefs1IDPurge, &yprefs.idpurgedays))
	{
		return 1;
	}

	if (GetFormValue(yf_art_purge, fldPrefs1ArtPurge, &yprefs.artpurgedays))
	{
		return 1;
	}

	chk = GetObjectPtr(chkPrefs1Beep);
	yprefs.beep = CtlGetValue(chk);

	chk = GetObjectPtr(chkPrefs1CutSig);
	yprefs.cutsig = CtlGetValue(chk);

	chk = GetObjectPtr(chkPrefs1JumpBack);
	yprefs.jump_back = CtlGetValue(chk);

	chk = GetObjectPtr(chkPrefs1Scoring);
	yprefs.scoring = CtlGetValue(chk);

	old_from_style = yprefs.from_style;
	yprefs.from_style = LstGetSelection(GetObjectPtr(lstPrefs1FromStyle));
	if (yprefs.from_style != old_from_style)
	{
		NPUpdateForm(frmArtList, updArtListMinorChanges);
	}

	yprefs.pagesize = LstGetSelection(GetObjectPtr(lstPrefs1PageSize));

	switch (LstGetSelection(GetObjectPtr(lstPrefs1Wordwrap)))
	{
		case 0:	yprefs.wrap_len = 60; break;
		case 1:	yprefs.wrap_len = 65; break;
		case 2:	yprefs.wrap_len = 70; break;
		case 3:	yprefs.wrap_len = 75; break;
		default: yprefs.wrap_len = 60;
	}


	yprefs.buttons = LstGetSelection(GetObjectPtr(lstPrefs1ButtonsLayout));

	GetVariableField(NULL, fldPrefs1Intro, &quote_intro);

	PrSavePrefs();
	return 0;
} /* SavePrefs */



static void InitForm(void)
{
	FieldPtr fld;
	ControlPtr ctl;
	char *id, *art, *intro;
	ListPtr lst;
	UInt list_sel;
	
	hid = MemHandleNew(6);
	hart = MemHandleNew(6);
	hintro = MemHandleNew(StrLen(quote_intro) + 5);
	
	if (!(hid && hart && hintro))
	{
		return;
	}
	id = (char *) MemHandleLock(hid);
	art = (char *) MemHandleLock(hart);
	intro = (char *) MemHandleLock(hintro);
	
	StrIToA(id, yprefs.idpurgedays);
	StrIToA(art, yprefs.artpurgedays);
	StrCopy(intro, quote_intro);
	
	MemHandleUnlock(hid);
	MemHandleUnlock(hart);
	MemHandleUnlock(hintro);

	fld = GetObjectPtr(fldPrefs1IDPurge);
	FldSetTextHandle(fld, (Handle) hid);

	fld = GetObjectPtr(fldPrefs1ArtPurge);
	FldSetTextHandle(fld, (Handle) hart);

	ctl = GetObjectPtr(chkPrefs1Beep);
	CtlSetValue(ctl, yprefs.beep);

	ctl = GetObjectPtr(chkPrefs1CutSig);
	CtlSetValue(ctl, yprefs.cutsig);

	ctl = GetObjectPtr(chkPrefs1JumpBack);
	CtlSetValue(ctl, yprefs.jump_back);

	ctl = GetObjectPtr(chkPrefs1Scoring);
	CtlSetValue(ctl, yprefs.scoring);

	ctl = GetObjectPtr(trgPrefs1FromStyle);
	lst = GetObjectPtr(lstPrefs1FromStyle);
	LstSetSelection(lst, yprefs.from_style);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	ctl = GetObjectPtr(trgPrefs1PageSize);
	lst = GetObjectPtr(lstPrefs1PageSize);
	LstSetSelection(lst, yprefs.pagesize);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	switch (yprefs.wrap_len)
	{
		case 60: list_sel = 0; break;
		case 65: list_sel = 1; break;
		case 70: list_sel = 2; break;
		case 75: list_sel = 3; break;
		default: list_sel = 0;
	}
	ctl = GetObjectPtr(trgPrefs1Wordwrap);
	lst = GetObjectPtr(lstPrefs1Wordwrap);
	LstSetSelection(lst, list_sel);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	ctl = GetObjectPtr(trgPrefs1ButtonsLayout);
	lst = GetObjectPtr(lstPrefs1ButtonsLayout);
	LstSetSelection(lst, yprefs.buttons);
	CtlSetLabel(ctl, LstGetSelectionText(lst, LstGetSelection(lst)));

	fld = GetObjectPtr(fldPrefs1Intro);
	FldSetTextHandle(fld, (Handle) hintro);
} /* InitForm */



static void ClearFields(void)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldPrefs1IDPurge);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs1ArtPurge);
	FldSetTextHandle(fld, 0);
	
	fld = GetObjectPtr(fldPrefs1Intro);
	FldSetTextHandle(fld, 0);
	
	MemHandleFree(hid);
	MemHandleFree(hart);
	MemHandleFree(hintro);
} /* ClearFields */



static void ValueZeroAlert(void)
{ 
	FrmCustomAlert(altInfo, yf_no_zero_val, " ", " ");
} /* ValueZeroAlert */




Boolean HandlePrefs1(EventPtr event)
{
    int handled = 0;
    int res = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
			InitForm();
            RefreshForm();
            handled = 1;
            break;

        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnCancel:
				{
					ClearFields();
					NPExitForm();
					handled = 1;
					break;
				}
				
				case btnOK:
				{
					res = SavePrefs();
					if (!res)
					{
						ClearFields();
						NPExitForm();
					}
					else if (res == 1)
					{
						ValueZeroAlert();
					}
					else if (res == 2)
					{
						FrmCustomAlert(altInfo, yf_max_31_k, " ", " ");
					}
					handled = 1;
					break;
				}
				
				default:
			}
			break;
		}
		
        default:
		
    }
    return handled;
} /* HandlePrefs1 */




