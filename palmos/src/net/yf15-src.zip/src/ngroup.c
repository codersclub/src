/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// ngroup.c
//
// newsgroup article management routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
	#include <System/SysEvtMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "artdb.h"
#include "subscrdb.h"
#include "ngroup.h"
#include "prefs.h"
#include "msgiddb.h"
#include "lang.h"

#include "frmnglist.h"




DmOpenRef ngdb = NULL;
int purge_what;

struct subscriptiondb_item active_ng;
DBNGNum active_ng_num;


int NGNewsgroupOpen(void)
{
	return (ngdb != NULL);
} /* NGNewsgroupOpen */



DmOpenRef NGOpenNewsgroupByPos(DBNGNum pos)
{
	char tempname[20];
	
	active_ng_num = pos;
	if (SubGetSubscriptionByPos(pos, &active_ng) != 0)
	{
		return NULL;
	}
	SubNGDatabaseName(active_ng.newsgroup, tempname);	
    ngdb = NPOpenDB(tempname);
    return ngdb;
} /* NGOpenNewsgroupByPos */



DmOpenRef NGOpenNewsgroupByName(char *name)
{
	return NGOpenNewsgroupByPos(SubGetSubscriptionPos(name));
} /* NGOpenNewsgroupByName */




void NGCloseNewsgroup(void)
{
    if (ngdb != NULL)
    {
		DmCloseDatabase(ngdb);
		ngdb = NULL;
		active_ng.newsgroup = NULL;
    }
} /* NGCloseNewsgroup */


void NGReopenNewsgroup(void)
{
	DBNGNum ngdum;
	
	ngdum = active_ng_num;
	NGCloseNewsgroup();
	NGOpenNewsgroupByPos(ngdum);
} /* NGReopenNewsgroup */





DBNGNum NGRememberActive(void)
{
	if (!NGNewsgroupOpen())
	{
		return ngNoNGOpen;
	}
	return active_ng_num;
} /* NGRememberActive */


void NGOpenOldActive(DBNGNum oldng)
{
	if (oldng != ngNoNGOpen)
	{
		NGCloseNewsgroup();
	    NGOpenNewsgroupByPos(oldng);
	}
} /* NGOpenOldActive */




char *NGActiveNewsgroup(void)
{
	if (NGNewsgroupOpen())
	{
		return active_ng.newsgroup;
	}
	else
	{
		return NULL;
	}
} /* NGActiveNewsgroup */


DBNGNum NGActiveNGNum(void)
{
	if (!NGNewsgroupOpen())
	{
		return ngNoNGOpen;
	}
	return active_ng_num;
} /* NGActiveNGNum */




//
//
// This function gets called when user changes the name of a newsgroup
//

void NGUpdateActiveNG(void)
{
	SubGetSubscriptionByPos(active_ng_num, &active_ng);
} /* NGUpdateActiveNG */




//
//
// Count articles
//
//

DBArtNum NGArticlesCount(void)
{
	if (ngdb != NULL) 
		return DmNumRecords(ngdb);
	else
		return 0;
} /* NGArticlesCount */






//
//
// Find the n-th article in the currently open newsgroup
// and return its unique ID of its article database entry
//

ULong NGGetArticleUID(DBArtNum pos)
{
	VoidHand h;
	ULong *uid, u;
	
	h = DmQueryRecord(ngdb, pos);
	if (h == 0)
	{
		return 0;
	}
	uid = MemHandleLock(h);
	u = *uid;
	MemHandleUnlock(h);
	return u; 
} /* NGGetArticleUID */




//
//
// Find the n-th article in the currently open newsgroup
//

int NGReadArticle(DBArtNum ngpos, struct articledb_item *art)
{
	ULong uid;
	DBArtNum apos;
	
	uid = NGGetArticleUID(ngpos);
	if (ArtSeekArticle(uid, &apos))
	{
		art->from = 0;
		art->subject = 0;
		return 1;
	}
	else
	{
		return ArtReadArticle(apos, art); 
	}
} /* NGReadArticle */






static DBArtNum NGGetThreadingPosition(ULong id)
{
	DBArtNum apos, actpos, max;
	struct articledb_item art, actart;
	char *ref, *d;
	
	ArtSeekArticle(id, &apos);
	ArtReadArticle(apos, &art);
	
	// We are only interested in the first Reference so cut the remainder off
	ref = MemPtrNew(StrLen(art.ref)+1);
	if (ref == NULL)
	{
		return -1; // Sad but true
	}
	StrCopy(ref, art.ref);
	for (d=&ref[StrLen(ref)]; ((d > ref) && (*d != '<')); d--);
	
	max = NGArticlesCount();
	for (actpos=0; (actpos < max); actpos++)
	{
		NGReadArticle(actpos, &actart);
		if (!StrCompare(d, actart.msgid))
		{
			MemPtrFree(ref);
			return actpos + 1;
		}
	}
	MemPtrFree(ref);
	return -1;	
} /* NGGetThreadingPosition */



//
//
// Insert unique ID of an article in the global article db to
// the currently open newsgroup
//

static int NGInsertArticle(ULong id)
{
    DBArtNum pos;
    VoidHand h;
    ULong *targetid;

	if (active_ng.thread_arts)
	{
		pos = NGGetThreadingPosition(id);
	}
	else
	{
		pos = -1;
	}
    h = DmNewRecord(ngdb, &pos, sizeof(ULong));
    if (h == 0)
    {
        return 0;
    }
    targetid = (ULong *)MemHandleLock(h);
    DmWrite(targetid, 0, &id, sizeof(id));
    MemHandleUnlock(h);
    DmReleaseRecord(ngdb, pos, 1);
    return 1;
} /* NGInsertArticle */






//
//
// Install article with number pos to the corresponding newsgroups
// pos is the position of the article to install in NewsArts
// nglist is the string that contains the newsgroups in RFC form
// If nglist is NULL the newsgroups are taken from the article itself
// Otherwise the article is installed in the newsgroup(s) in nglist
// This is needed for posting of articles, where the saved article
// is installed in the newsgroup "!! Outgoing" regardless of art.newsgroups.
// 
// pos will normally be -1 to install the last article
//


int NGWeaveInArticle(DBArtNum pos, char *nglist, int reindex)
{
    char *newsgroups,
         *ngdum,
         *ngend;
    ULong uid;
    VoidHand ngh;
    struct articledb_item art;
    struct subscriptiondb_item sub;
	DBNGNum oldng;
	UInt xpostings = 0;

	ArtReadArticle(pos, &art);
	if (reindex && (art.flags & yfArticleFlagDontReindex))
	{
		// This article shall not be reindexed
		return 0;
	}
	uid = ArtGetArticleUID(pos);

	oldng = NGRememberActive();
	NGCloseNewsgroup();
	
	if (nglist == NULL)
	{
		ngdum = art.newsgroups;
	}
	else
	{
		ngdum = nglist;
	}
    ngh = MemHandleNew(StrLen(ngdum) + 1);
    if (ngh == 0)
    {
        return 0;
    }
    newsgroups = MemHandleLock(ngh);
    StrCopy(newsgroups, ngdum);
    ngend = newsgroups + StrLen(newsgroups);
    while (newsgroups < ngend)
    {
        ngdum = newsgroups;
        while (*ngdum && (*ngdum != ','))
        {
            ngdum++;
        }
        if (*ngdum == ',')
        {
            *ngdum = 0;
        }
        // newsgroups contains the name of one newsgroup to which the
        // article has to be posted

        if (!SubGetSubscriptionByName(newsgroups, &sub))
        {
        	NGOpenNewsgroupByName(newsgroups);
            NGInsertArticle(uid);
            NGCloseNewsgroup();
            xpostings++;
        }
        newsgroups = ngdum + 1;
    }
    MemHandleUnlock(ngh);
    MemHandleFree(ngh);


	NGOpenOldActive(oldng);
	
    ArtChangeArticleXP(uid, xpostings, 0);
    return 1;
} /* NGWeaveInArticle */







//
//
// Delete Article from NewsGroup database
//

int NGDeleteArticle(DBArtNum pos)
{
	ULong uid;

	uid = NGGetArticleUID(pos);
	ArtDeleteArticle(uid);
	DmRemoveRecord(ngdb, pos);
    return 0;
} /* NGDeleteArticle */




int NGSetArticleFlag(DBArtNum pos, int flag, int value)
{
	ULong uid;
	
	uid = NGGetArticleUID(pos);
	ArtSetArticleFlag(uid, flag, value);
	return 0; 
} /* NGSetArticleFlag */



static void NGSetArticleFlagAll(int flag, int mode)
{
	DBArtNum count, act;
	
	count = NGArticlesCount();
	for (act=0; (act < count); act++)
	{
		NGSetArticleFlag(act, flag, mode);
	}
} /* NGSetArticleFlagAll */



void NGMarkArticles(int mode)
{
	NGSetArticleFlagAll(yfArticleFlagMarked, mode);
   	FrmUpdateForm(frmArtList, updArtListMinorChanges);
} /* NGMarkArticles */




void NGDeleteSelectedRead(int mode)
{
	DBArtNum count, act, oldcount;
	struct articledb_item art;
	
	oldcount = count = NGArticlesCount();
	for (act=0; (act < count);)
	{
		NGReadArticle(act, &art);
		// if article is not to keep:
		// either if art is marked and mode is 0
		// or if art is read an mode is 1:
		// delete the article
		if (!(art.flags & yfArticleFlagKeep) && 
			((!mode && (art.flags & yfArticleFlagMarked))
			|| (mode && (art.flags & yfArticleFlagRead))))
		{
			// Maybe this article is a crossposting. So unset the
			// marked flag to be sure the display is correct.
			NGSetArticleFlag(act, yfArticleFlagMarked, 0); 
			NGDeleteArticle(act);
			count--; // one article less in newsgroup
		}
		else
		{
			if (!mode)
			{
				NGSetArticleFlag(act, yfArticleFlagMarked, 0);
			}
			act++;
		}
	}
	if (oldcount != NGArticlesCount())
	{
		FrmUpdateForm(frmArtList, updArtListMajorChanges);
		// remember to send frmNewsgroups an frmUpdateEvent
		NPUpdateForm(frmNewsgroups, 1);
	}
} /* NGDeleteSelectedRead */




void NGKeepSelected(int mode)
{
	DBArtNum count, act;
	struct articledb_item art;
	
	count = NGArticlesCount();
	for (act=0; (act < count); act++)
	{
		NGReadArticle(act, &art);
		if (art.flags & yfArticleFlagMarked)
		{
			NGSetArticleFlag(act, yfArticleFlagKeep, mode); 
			NGSetArticleFlag(act, yfArticleFlagMarked, 0);
		}
	}
	FrmUpdateForm(frmArtList, updArtListMinorChanges);
} /* NGKeepSelected */




void NGToggleReadSelected(void)
{
	DBArtNum count, act;
	struct articledb_item art;
	
	count = NGArticlesCount();
	for (act=0; (act < count); act++)
	{
		NGReadArticle(act, &art);
		if (art.flags & yfArticleFlagMarked)
		{
			NGSetArticleFlag(act, yfArticleFlagRead, !(art.flags & yfArticleFlagRead)); 
			NGSetArticleFlag(act, yfArticleFlagMarked, 0);
		}
	}
	FrmUpdateForm(frmArtList, updArtListMinorChanges);
} /* NGToggleReadSelected */






int NGUpdateLastField(ULong newlast)
{
	return SubUpdateSubscription(active_ng_num, newlast);
} /* NGUpdateLastField */


ULong NGReadLastField(void)
{
	struct subscriptiondb_item sub;

	SubGetSubscriptionByPos(active_ng_num, &sub);
	return sub.last;
} /* NGReadLastField */


void NGResetNewsgroup(void)
{
	UInt count, pos;

	if (!NGNewsgroupOpen())
	{
		if (!FrmAlert(altResetAllNewsgroups))
		{
			count = SubSubscriptionsCount();
			for (pos=0; (pos < count); pos++)
			{
				SubUpdateSubscription(pos, 0l);
			}
		}
	}
	else
	{
		if (!FrmAlert(altResetNewsgroup))
		{
	   		NGUpdateLastField(0l);
	    }
	}
} /* NGResetNewsgroup */



// purgedays == 0: purge all articles. Every single article.
void NGPurgeOld(UInt purgedays)
{
	UInt ngcount, actng;
	DBArtNum artcount, actart;
	char *ng;
	struct articledb_item art;
	int res, deleted_something = 0;
	DBNGNum oldng;
	DBArtNum old_last_top,
		old_last_sel;


	oldng = NGRememberActive();
	NGCloseNewsgroup();

	if (purgedays == 0)
	{
		res = ArtRemoveArticlesDB();
	}
	else
	{
		res = ArtPurgeArticles(purgedays);
	}
	if (res)
	{
		ngcount = SubSubscriptionsCount();
		for (actng=0; (actng < ngcount); actng++)
		{
			// Purge every single subscribed newsgroup
			if (!SubSeekSubscription2(actng, &ng))
//				&& ((purgedays == 0) || StrCompare(ng, outgoing_group)))
			{
				NGOpenNewsgroupByPos(actng);
				old_last_top = active_ng.last_top;
				old_last_sel = active_ng.last_sel;
				if (!(active_ng.ng_flags & yfNGFlag_internal)  
					|| (purgedays == 0))
				{
					artcount = NGArticlesCount();
					for (actart=0; (actart < artcount);)
					{
						if (NGReadArticle(actart, &art))
						{
							// article not in global article database
							DmRemoveRecord(ngdb, actart);
							if (actart < old_last_top)
							{
								old_last_top--;
							}
							artcount--;
						}
						else
						{
							actart++;
						}
					}
				} // act newsgroup not internal
				NGCloseNewsgroup();
				SubUpdateSubscriptionTopArt(actng, old_last_top, old_last_sel);
			}
		}
		deleted_something = 1;
	} /* if ArtPurgeArticles deleted some articles */
		
	NGOpenOldActive(oldng);

	if (deleted_something)
	{
		NPUpdateForm(frmNewsgroups, 1);
	    if (NGNewsgroupOpen())
	    {
		    FrmUpdateForm(frmArtList, updArtListMajorChanges);
		}
	}
} /* NGPurgeOld */




//
//
// In case of a crash during download the new downloaded articles
// are not properly installed in the databases
//
// Strategy: Kill all articles in the newsgroups and call
// WeaveInArticle for all articles in artdb
//


static void RestoreDatabase(void)
{
	DBArtNum artcount, actart;
	UInt ngcount, actng;
	char *ng; 
	DBNGNum oldng;

	oldng = NGRememberActive();
	NGCloseNewsgroup();

	ngcount = SubSubscriptionsCount();
	for (actng=0; (actng < ngcount); actng++)
	{
		// Purge every single subscribed newsgroup
		if (!SubSeekSubscription2(actng, &ng))
//			&& StrCompare(ng, outgoing_group))
		{
			NGOpenNewsgroupByPos(actng);
			if (!(active_ng.ng_flags & yfNGFlag_internal))
			{
				artcount = NGArticlesCount();
				for (actart=0; (actart < artcount); actart++)
				{
					DmRemoveRecord(ngdb, 0);
				}
			}
			NGCloseNewsgroup();
		}
	}
	
	artcount = ArtArticlesCount();
	for (actart=0; (actart < artcount); actart++)
	{
		NGWeaveInArticle(actart, NULL, 1);
	}

	NGOpenOldActive(oldng);
	NPUpdateForm(frmNewsgroups, 1);
    if (NGNewsgroupOpen())
    {
	    FrmUpdateForm(frmArtList, updArtListMajorChanges);
	}
} /* RestoreDatabase */





Boolean HandlePurge(EventPtr event)
{
    int handled = 0;
    UInt oldautooff;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
        	oldautooff = SysSetAutoOffTime(0);
			if (purge_what == purgeArticles)
			{
	            NPSetFormTitle(FrmGetActiveForm(), yf_purging_arts, 0);
	            RefreshForm();
				NGPurgeOld(yprefs.artpurgedays);
			}
			else if (purge_what == purgeMsgIDs)
			{
	            NPSetFormTitle(FrmGetActiveForm(), yf_purging_msgids, 0);
	            RefreshForm();
				MidPurgeMsgIDs(yprefs.idpurgedays * 86400);
			}
			else if (purge_what == purgeReindex)
			{
	            NPSetFormTitle(FrmGetActiveForm(), yf_reindexing, 0);
	            RefreshForm();
	            RestoreDatabase();
			}
			else
			{
	            NPSetFormTitle(FrmGetActiveForm(), yf_purging_all_arts, 0);
	            RefreshForm();
				NGPurgeOld(0);
			}
			SysSetAutoOffTime(oldautooff);
			EvtResetAutoOffTimer();
			NPExitForm();
			handled = 1;
			break;
		}
		
        default:
		
    }
    return handled;
} /* HandlePurge */



void NGPurge(int what)
{
	purge_what = what;
	NPGotoForm(frmPurge);
} /* NGPurge */




void NGUpdateOutgoing(DBServerNum deleted_server)
{
	DBNGNum oldng;
	DBArtNum actart, max;
	struct articledb_item art;
	
	oldng = NGRememberActive();
	NGCloseNewsgroup();
	NGOpenNewsgroupByName(outgoing_group);
	
	max = NGArticlesCount();
	for (actart = 0; (actart < max); actart++)
	{
		NGReadArticle(actart, &art);
		if (art.server == deleted_server)
		{
			NGDeleteArticle(actart);
			max--;
		}
		else if (art.server > deleted_server)
		{
			ArtUpdateServerNum(actart);
		}
	}
	NGCloseNewsgroup();
	NGOpenOldActive(oldng);
} /* NGUpdateOutgoing */
