// General header file for Yanoff. 

//
//
// The resource ID's
//

// all forms
#define FIRSTY 16  // was 17
#define CANCEL_W 35
#define OK_W 20
#define B_SEP 4
#define ARROW_W 8
#define BUTTON_H 13
#define SERVER_NAME_LEN 20

#define NLOWEST 1
#define NLEFTMOST 1

#define MLOWEST 5
#define MLEFTMOST 5


// frmPrefs
#define liney 12
#define tab1 54
#define tab2 58

#define tab3 124
#define tab4 128

// frmArtList
#define artlisttop 30 

// frmNewsgroups
#define nglisttop 29



// some buttons that are used around Yanoff

#define btnOK 9999
#define btnCancel 9998
#define btnPrev 9997
#define btnNext 9996





#define frmNewsgroups 1000
#define lblNewsgroupsMem 1001
#define tblNewsgroups 1002
#define sbNewsgroups 1003
#define btnNewsgroupsSendPoll 1004



#define frmArtList 1020
#define tblArtList 1021
#define sbArtList 1022
#define btnArtListNewArt 1023


#define frmArticle 1040
#define fldArtString 1041
#define sbArticle 1042
#define btnHeader 1043
#define btnFUp 1044
#define btnReply 1045
#define btnSelect 1046
#define btnKeep 1047



#define frmPost 1060
#define fldPostSubject 1061
#define lblGroups 1062
#define fldPostNewsgroups 1063
#define fldPostText 1064
#define sbPost 1065
#define btnPostSend 1066
#define btnPostSave 1067







#define frmPrefs1Other 1080
#define fldPrefs1IDPurge 1081
#define fldPrefs1ArtPurge 1082
//#define fldPrefs1SampleArts 1083
//#define fldPrefs1ArtMax 1084
#define chkPrefs1Beep 1086
#define chkPrefs1CutSig 1087
#define trgPrefs1FromStyle 1089
#define lstPrefs1FromStyle 1090
#define chkPrefs1JumpBack 1091
#define trgPrefs1Wordwrap 1092
#define lstPrefs1Wordwrap 1093
#define chkPrefs1Scoring 1094
#define trgPrefs1ButtonsLayout 1095
#define lstPrefs1ButtonsLayout 1096
#define trgPrefs1PageSize 1097
#define lstPrefs1PageSize 1098
#define fldPrefs1Intro 1099


#define frmPrefs2Server1 1120
#define trgPrefs2Name 1121
#define lstPrefs2Name 1122
#define fldPrefs2Name 1123
#define lblPrefs2Type 1124
#define fldPrefs2Address 1125
#define fldPrefs2Port 1126
#define fldPrefs2Timeout 1127
#define lblPrefs2Poll 1128
#define chkPrefs2Poll 1129
#define lblPrefs2UseAuth 1130
#define chkPrefs2UseAuth 1131
#define lblPrefs2AuthName 1132
#define fldPrefs2AuthName 1133
#define lblPrefs2AuthPass 1134
#define sltPrefs2AuthPass 1135
#define lblPrefs2ReplyTo 1136
#define fldPrefs2ReplyTo 1137
#define btnPrefs2Add 1138




#define frmPrefs2Server2 1140
#define fldPrefs2Username 1141
#define fldPrefs2Realname 1142
#define fldPrefs2Hostname 1143
#define fldPrefs2Zone 1144
#define fldPrefs2Sig 1145
#define sbPrefs2Sig 1146





#define frmPrefs4Newsgroup 1100
#define fldPrefs4Name 1101
#define fldPrefs4MaxKB 1102
#define fldPrefs4SampleArts 1103
#define trgPrefs4Poll 1104
#define lstPrefs4Poll 1105
#define fldPrefs4DownMax 1106
#define lblPrefs4Poll 1107
#define chkPrefs4Poll 1108
#define trgPrefs4Server 1109
#define lstPrefs4Server 1110
#define trgPrefs4display 1111
#define lstPrefs4display 1112
#define fldPrefs4CustomHeaders 1113
#define sbPrefs4CustomHeaders 1114
#define chkPrefs4Thread 1115



#define frmPrefs4CustomHeaders 1116
#define fldPrefs4Headers 1117
#define sbPrefs4Headers 1118
#define btnPrefs4Headers 1119


#define frmPrefsPoll 1160
#define trgPrefsPollWhat 1161
#define lstPrefsPollWhat 1162
#define trgPrefsPollFrom 1163
#define lstPrefsPollFrom 1164
#define chkPrefsPollNews 1165
#define btnPrefsPollPoll 1166
#define btnPrefsPollSavePoll 1167
#define chkPrefsPollPostNews 1168
#define chkPrefsPollPosteMail 1169
#define lblPrefsPollGet 1170
#define lblPrefsPollFrom 1171


#define frmAbout 1180



#define frmSubscribe 1190
#define fldSubsName 1191


#define frmServerSelection 1200
#define trgSrvSel 1201
#define lstSrvSel 1202


#define frmAuthPass 1210
#define fldAuthPass 1211


#define frmPoll 1220
#define fldPoll 1221


#define frmPurge 1230 






#define menuArticle 5000
#define menuEdit 5020
#define menuServer 5040

#define mArtCopy 5001
#define mArtSelectAll 5002
#define mArtExportMemo 5003
#define mArtUndo 5004
#define mArtCut  5005
#define mArtPaste 5006
#define mPrefs2ServerDup 5007
#define mPrefs2ServerDel 5008
#define mArtComplete 5009




#define menuGeneral 5060
#define menuArtList 5100

#define mConn 5061
#define mDisc 5062
#define mPoll 5063
#define mPollPrefs 5064
#define mNewArticle 5065
#define mNewEMail 5066
#define mSubs 5067
#define mPurgeArts 5068
#define mPurgeIDs 5069
#define mPurgeAllArts 5070
#define mPrefs2 5071
#define mPrefs1 5072
#define mReindex 5073
#define mResetNewsgroup 5074
#define mAbout 5075
#define mUnsubs 5076
#define mSelAll 5077
#define mSelNone 5078
#define mSelInv 5079
#define mKeepSel 5080
#define mUnkeepSel 5081
#define mDeleteSel 5082
#define mDeleteRead 5083
#define mPrefs4 5084
#define mToggleReadSel 5085




#define alertID_dum 6000
#define altInfo 6001
#define altUnsubs 6002
#define altQuote 6003
#define altDeleteConf 6004
#define altReindex 6005
#define altResetNewsgroup 6006
#define altResetAllNewsgroups 6007
#define altHeadersConf 6008
#define altSaveAsDraft 6009
#define altChangeInternalGroup 6010

#define strAbout 7001
#define strPrefs1Help 7002
#define strPrefs2Help 7003
#define strPrefs3Help 7004
#define strPrefs4Help 7005
#define strSubsHelp 7006
#define strAuthPassHelp 7007
#define strPrefsPollHelp 7008
#define strPrefs4HeadersHelp 7009

#define NPLogo 7100
#define bmpBack 7101
