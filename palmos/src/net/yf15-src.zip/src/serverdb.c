/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// serverdb.c
//
// server database routines for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "ngroup.h"
#include "serverdb.h"
#include "prefs.h"
#include "lang.h"


#define artdb_error 0
#define artdb_ok 1


char serverdb_name[] = {"NewsServers"};

DmOpenRef srvdb = NULL;

serverdb_item actserver;


//
//
// Init server data to NULL values
//

void SrvInitData(struct serverdb_item *s)
{
	s->name = NULL;
	s->address = NULL;
	s->auth_user = NULL;
	s->auth_pass = NULL;
	s->hostname = NULL;
	s->username = NULL;
	s->realname = NULL;
	s->zone = NULL;
	s->sig = NULL;
	s->use_auth = 0;
	s->port = 0;
	s->timeoutsecs = 10;
	s->poll = 1;
} /* SrvInitData */



//
//
// Free server data based on server structure
// Does NOT free the server struct itself!
//

void SrvFreeData(struct serverdb_item *s)
{
    FreePointer((Ptr) s->name);
    FreePointer((Ptr) s->address);
    FreePointer((Ptr) s->auth_user);
    FreePointer((Ptr) s->auth_pass);
    FreePointer((Ptr) s->hostname);
    FreePointer((Ptr) s->username);
    FreePointer((Ptr) s->realname);
    FreePointer((Ptr) s->zone);
    FreePointer((Ptr) s->sig);
    SrvInitData(s);
} /* SrvFreeData */






DmOpenRef SrvOpenServers(void)
{
	if (srvdb == NULL)
	{
	    srvdb = NPOpenDB(serverdb_name);
	}
	return srvdb;
} /* SrvOpenServers */



void SrvCloseServers(void)
{
	if (srvdb != NULL)
	{
		DmCloseDatabase(srvdb);
		srvdb = NULL;
	}
} /* SrvCloseServers */




//
//
// Inits a serverdb_item struct so that its contents point to 
// the corresponding pieces of information in the server database record 
//

int SrvReadServer(struct serverdb_item *srv, DBServerNum pos)
{
    VoidHand h;
    char *p;

    h = DmQueryRecord(srvdb, pos);
    if (h == 0)
    {
        return 1;
    }
    p = (char *)MemHandleLock(h);


    srv->port = *(UInt *)p;
    p += sizeof(UInt);

    srv->timeoutsecs = *(UInt *)p;
    p += sizeof(UInt);

    srv->poll = *(char *)p;
    p += sizeof(char);

    srv->use_auth = *(char *)p;
    p += sizeof(char);

    srv->name = p;
    p += StrLen(p) + 1;

    srv->address = p;
    p += StrLen(p) + 1;

    srv->auth_user = p;
    p += StrLen(p) + 1;

    srv->auth_pass = p;
    p += StrLen(p) + 1;

    srv->hostname = p;
    p += StrLen(p) + 1;

    srv->username = p;
    p += StrLen(p) + 1;

    srv->realname = p;
    p += StrLen(p) + 1;
	
    srv->zone = p;
    p += StrLen(p) + 1;
	
    srv->sig = p;
	
    MemHandleUnlock(h);
    return 0;
} /* SrvReadServer */


//
//
// Reads server data from database and creates a standalone copy of
// the data in heap memory.
//

int SrvCopyServer(struct serverdb_item *srv, DBServerNum pos)
{
    VoidHand h;
    char *p;

    h = DmQueryRecord(srvdb, pos);
    if (h == 0)
    {
        return 1;
    }
    p = (char *)MemHandleLock(h);

    srv->port = *(UInt *)p;
    p += sizeof(UInt);

    srv->timeoutsecs = *(UInt *)p;
    p += sizeof(UInt);

    srv->poll = *(char *)p;
    p += sizeof(char);

    srv->use_auth = *(char *)p;
    p += sizeof(char);

    StrInit(&srv->name, p);
    p += StrLen(p) + 1;

    StrInit(&srv->address, p);
    p += StrLen(p) + 1;

    StrInit(&srv->auth_user, p);
    p += StrLen(p) + 1;

    StrInit(&srv->auth_pass, p);
    p += StrLen(p) + 1;

    StrInit(&srv->hostname, p);
    p += StrLen(p) + 1;

    StrInit(&srv->username, p);
    p += StrLen(p) + 1;

    StrInit(&srv->realname, p);
    p += StrLen(p) + 1;
	
    StrInit(&srv->zone, p);
    p += StrLen(p) + 1;
	
    StrInit(&srv->sig, p);

    MemHandleUnlock(h);
    return 0;
} /* SrvCopyServer */








//
//
// Update server entry in database
//
// Returns 0 in case of error
// Returns 1 in case of success
//

int SrvWriteServer(struct serverdb_item *srv, int overwrite, DBServerNum *pos)
{
    UInt name_len,
    	address_len,
        auth_user_len,
        auth_pass_len,
        hostname_len,
        username_len,
        realname_len,
        zone_len,
        sig_len,
        header_len;
    char *p;
    VoidHand h;
	Word datapos, size;
	

    size = 0;
	name_len = StrLen(srv->name) + 1;
    address_len = StrLen(srv->address) + 1;
    auth_user_len = StrLen(srv->auth_user) + 1;
    auth_pass_len = StrLen(srv->auth_pass) + 1;
    hostname_len = StrLen(srv->hostname) + 1;
    username_len = StrLen(srv->username) + 1;
	realname_len = StrLen(srv->realname) + 1;
    zone_len = StrLen(srv->zone) + 1;
    sig_len = StrLen(srv->sig) + 1;
    

    header_len = 2 * sizeof(UInt) + 2 * sizeof(char);
    header_len += name_len + address_len + auth_user_len + auth_pass_len 
    			+ zone_len + hostname_len + username_len + realname_len 
    			+ sig_len;

	if (overwrite)
	{
//		h = DmGetRecord(srvdb, pos);
		h = DmResizeRecord(srvdb, *pos, header_len);
	}
	else
	{
		h = DmNewRecord(srvdb, pos, header_len);
	}
    if (h == 0)
    {
        // Mem low
        FrmCustomAlert(alertID_dum, yf_mem_low, " ", " ");
        return 1;
    }
    p = (char *)MemHandleLock(h);

    DmWrite(p, 0, &(srv->port), sizeof(UInt));
    datapos = sizeof(UInt);

    DmWrite(p, datapos, &(srv->timeoutsecs), sizeof(UInt));
    datapos += sizeof(UInt);

    DmWrite(p, datapos, &(srv->poll), sizeof(char));
    datapos += sizeof(char);

    DmWrite(p, datapos, &(srv->use_auth), sizeof(char));
    datapos += sizeof(char);

    DmStrCopy(p, datapos, srv->name);
    datapos += name_len;

    DmStrCopy(p, datapos, srv->address);
    datapos += address_len;

    DmStrCopy(p, datapos, srv->auth_user);
    datapos += auth_user_len;

    DmStrCopy(p, datapos, srv->auth_pass);
    datapos += auth_pass_len;

    DmStrCopy(p, datapos, srv->hostname);
    datapos += hostname_len;

    DmStrCopy(p, datapos, srv->username);
    datapos += username_len;
	
	DmStrCopy(p, datapos, srv->realname);
    datapos += realname_len;

    DmStrCopy(p, datapos, srv->zone);
    datapos += zone_len;
	
	DmStrCopy(p, datapos, srv->sig);

    MemHandleUnlock(h);
    DmReleaseRecord(srvdb, *pos, 1);
    return 0;
} /* SrvWriteServer */




//
//
// Create new server entry in database
//
// Returns 0 in case of error
// Returns 1 in case of success
//

int SrvAppendServer(struct serverdb_item *srv)
{
	DBServerNum pos;
	
	pos = -1; // Append mode
	SrvWriteServer(srv, 0, &pos);
    return 0;
} /* SrvAppendServer */






//
//
// Find server by name
//

DBServerNum SrvFindServer(char *name)
{
 	DBServerNum pos = 1,
 		count;
	
	struct serverdb_item srv;
	
	count = SrvServersCount();
	do
	{
		SrvReadServer(&srv, pos);
	}
	while (StrCompare(srv.name, name) && (++pos < count));

	if (pos == count)
	{
		return -1;
	}
	else
	{
		return pos;
	}
} /* SrvFindServer */




//
//
// Delete Server
//
//

Err SrvDeleteServer(DBServerNum pos)
{
    return DmRemoveRecord(srvdb, pos);
} /* SrvDeleteServer */




UInt SrvServersCount(void)
{
	return DmNumRecords(srvdb);
} /* SrvServersCount */



void SrvInitServerDatabase(void)
{
	serverdb_item srv;
	DBServerNum pos;

	if (SrvServersCount() == 0)
	{
		SrvInitData(&srv);
		srv.port = 25;
		srv.timeoutsecs = 20;
		srv.use_auth = 0;
		StrInit(&srv.name, "Mail");
		StrInit(&srv.address, "192.168.1.1");
		StrInit(&srv.auth_user, "");
		StrInit(&srv.auth_pass, "");
		StrInit(&srv.hostname, yf_dummy_server);
		StrInit(&srv.username, "john_doe");
		StrInit(&srv.realname, "John Doe");
		StrInit(&srv.zone, "GMT");
		StrInit(&srv.sig, yf_standard_sig);
		pos = 0;
		SrvWriteServer(&srv, 0, &pos);

		SrvFreeData(&srv);
		srv.port = 119;
		srv.timeoutsecs = 20;
		srv.use_auth = 0;
		StrInit(&srv.name, "Standard");
		StrInit(&srv.address, "news.massena.com");
		StrInit(&srv.auth_user, "");
		StrInit(&srv.auth_pass, "");
		StrInit(&srv.hostname, yf_dummy_server);
		StrInit(&srv.username, "john_doe");
		StrInit(&srv.realname, "John Doe");
		StrInit(&srv.zone, "GMT");
		StrInit(&srv.sig, yf_standard_sig);
		pos = 1;
		SrvWriteServer(&srv, 0, &pos);
		SrvFreeData(&srv);
	}
} /* SrvInitServerDatabase */




#ifdef COMMENT

static char *LinkNewStr(char **ptr, char *str)
{
	*ptr = (char *) MemPtrNew(StrLen(str) + 1);
	if (*ptr == NULL)
	{
		return NULL;
	}
	StrCopy(*ptr, str);
	return *ptr;
} /* LinkNewStr */

#endif



//
//
// Allocates memory in heap and makes an array of pointers that point
// to the list of server available.
// Has to be freed by SrvFreeServerList.
//


char **SrvGetServerList(int mode, DBServerNum *list_count)
{
	char **items;
	DBServerNum db_pos, list_pos;
	struct serverdb_item dum;
	char *cdum;

	// allocate memory for array of pointers
	if ((mode == srv_list_mode_poll) && (NGNewsgroupOpen()))
	{
		*list_count = SrvServersCount() + 1;
	}
	else
	{
		*list_count = SrvServersCount();
	}
	items = (char **) MemPtrNew(*list_count * sizeof (char *));
	if (items == NULL)
	{
		return NULL;
	}
	MemSet((VoidPtr) items, *list_count * sizeof (char*), 0);

	list_pos = 0;

	switch (mode)
	{
 		case srv_list_mode_none:
		{
			StrInit(&items[0], yf_none);
			list_pos++;
			break;
		}
		
		case srv_list_mode_post:
		{
			(*list_count)--;
			break;
		}
	
		case srv_list_mode_all:
		{
			SrvReadServer(&dum, 0);
			StrInit(&items[0], dum.name);
			list_pos++;
			break;
		}
		
		case srv_list_mode_poll:
		{
			if (NGNewsgroupOpen())
			{
				StrInit(&items[list_pos], yf_current_group);
				list_pos++;
			}
			StrInit(&items[list_pos], yf_all_servers);
			list_pos++;
			break;
		}
		
		default:
	}


	// fill in the names into the array
	for (db_pos = 1; (db_pos < SrvServersCount()); db_pos++, list_pos++)
	{
		SrvReadServer(&dum, db_pos);
		cdum = MemPtrNew(StrLen(dum.name) + 1);
	 	if (cdum == NULL)
	 	{
			items[list_pos] = NULL;
	 	}
	 	else
	 	{
			MakeItemString(dum.name, 75, cdum);
			StrInit(&items[list_pos], cdum);
			MemPtrFree(cdum);
		}
	}

	return items;
} /* SrvGetServerList */




void SrvFreeServerList(char **list)
{
	DBServerNum pos;

	for (pos = 0; (pos < SrvServersCount()); pos++)
	{
		MemPtrFree(list[pos]);
	}
	MemPtrFree(list);
} /* SrvFreeServerList */