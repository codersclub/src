#ifndef SEGMENT_H
#define SEGMENT_H

// General header file for Yanoff. First define multicode sections
// for PRC-Tools 2.0 then define resource ID's.

#ifdef PRC2
	#define SECTION_3 __attribute__ ((section("sec3")))
#else
	#define SECTION_3 /* do nothing */
#endif


#endif