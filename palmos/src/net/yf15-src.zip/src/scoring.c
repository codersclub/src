/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// scoring.c
//
// scoring routines for use with yanoff
// Matthias Jordan, 9-2000
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "scoring.h"
#include "general.h"
//#include "artdb.h"
//#include "prefs.h"
//#include "lang.h"
//#include "serverdb.h"
//#include "ngroup.h"




#ifdef PRC2
// prototypes for multisegment code	
static int ScrGetScoringEntryByKey(char *author, DBScoreNum *pos) SECTION_3;
#endif




char scoringdb_name[] = {"NewsScores"};

DmOpenRef scoringdb = NULL;





//
//
// Compare function
// if comp_db_entries is 1 the function compares db entries
// if comp_db_entries is 0 the value in *a1 is a string
//
// returns values like StrCompare
//

static Int comp_authors(void *a1, void *a2, int comp_db_entries,
    SortRecordInfoPtr p1, SortRecordInfoPtr p2, VoidHand h)
{
	if (comp_db_entries)
	{
		a1 += sizeof(Word) + sizeof(Word);
	}
	a2 += sizeof(Word) + sizeof(Word);
	
    return StrCompare((char *)a1, (char *)a2);
} /* comp_subs */





DmOpenRef ScrOpenScoring(void)
{
	if (scoringdb == NULL)
	{
	    scoringdb = NPOpenDB(scoringdb_name);
	}
	return scoringdb;
} /* ScrOpenScoring */



void ScrCloseScoring(void)
{
	if (scoringdb != NULL)
	{
		DmCloseDatabase(scoringdb);
		scoringdb = NULL;
	}
} /* ScrOpenScoring */





//
//
// Gets databases key and searches an appropriate record.
//

int ScrGetScoringEntryByKey(char *key, DBScoreNum *pos)
{
	VoidHand h;
	Ptr p;
	char *dbauthor;

    if (scoringdb == NULL)
    {
        // db open error
		*pos = 0; 
        return 1;
    }

	*pos = DmFindSortPositionV10(scoringdb, key, (DmComparF *)comp_authors, 0) - 1;

    h = DmQueryRecord(scoringdb, *pos);
    if (h == 0)
    {
		*pos = 0;
        return 2;
    }

    p = MemHandleLock(h);
    p += sizeof(Word) + sizeof(Word);
	dbauthor = (char *) p;

	if ((dbauthor == NULL) || (StrCompare(dbauthor, key)))
	{
		// not found
	    MemHandleUnlock(h);
		*pos = 0;
		return 2;
	}

    MemHandleUnlock(h);
    return 0;
} /* ScrGetScoringEntryByKey */




//
//
// Gets from field information, generates the key and gets
// scoring info if any
//

int ScrReadAuthorsScore(char *from_field, Word *score)
{
	DBScoreNum pos;
	VoidHand h;
	Ptr p;
	Word total, 
		ratings;
	char *key;
	
	*score = 0;
	key = MemPtrNew(StrLen(from_field)+1);
	if (key == NULL)
	{
		// out of mem.
		return 1;
	}
	GenScoringAddress(from_field, key);

    if (ScrGetScoringEntryByKey(key, &pos))
    {
    	// not found
		MemPtrFree(key);
    	return 2;
    }
	MemPtrFree(key);

    h = DmQueryRecord(scoringdb, pos);
    if (h == 0)
    {
        return 3;
    }
    p = MemHandleLock(h);
	total = *(Word *) p;
	p += sizeof(Word);
	ratings = *(Word *) p;

	// Calculate author's score given the accumulated total of scores given and
	// the number of scores.
		
	*score = total / ratings;

    MemHandleUnlock(h);
	return 0;
} /* ScrReadAuthorsScore */



//
//
// Gets from field information, generates the key and sets
// scoring info
//



int ScrGiveScoreToAuthor(char *from_field, Word score)
{
	DBScoreNum pos;
	VoidHand h;
	Ptr p;
	ULong size;
	Word dum;
	Word total, ratings;
	char sort_db = 0,
		*key;
	int res;
	

	key = MemPtrNew(StrLen(from_field)+1);
	if (key == NULL)
	{
		// out of mem.
		return 1;
	}
	GenScoringAddress(from_field, key);
	
	res = ScrGetScoringEntryByKey(key, &pos);
	if (res == 1)
	{
		// dbopen error
		MemPtrFree(key);
		return 2;
	}
    if (res == 0)
    {
	    h = DmGetRecord(scoringdb, pos);
		if (h == 0)
		{
			MemPtrFree(key);
			return 3;
		}
	    p = MemHandleLock(h);
	   	total = *(Word *) p;
	   	ratings = *(Word *) (p + sizeof(Word));
	    if ((total > 65526) || (ratings > 65526))
	    {

	    	total = total / ratings;
	    	ratings = 1;
	    }
	    else
	    {
		    total += score;
		    ratings++;
		}
	    DmWrite(p, 0, &total, sizeof(Word));
	    DmWrite(p, sizeof(Word), &ratings, sizeof(Word));
	    MemHandleUnlock(h);
	}
	else
    {
    	// not found so append entry
		size = StrLen(key) + 1 + 4;
	    h = DmNewRecord(scoringdb, &pos, size);
	    if (h == 0)
	    {
	    	return 1;
	    }
	    p = MemHandleLock(h);
	    sort_db = 1;
	    DmWrite(p, 0, &score, sizeof(Word));
	    dum = 1; // first rating
	    DmWrite(p, sizeof(Word), &dum, sizeof(Word));
	    DmStrCopy(p, sizeof(Word) + sizeof(Word), key);
	    MemHandleUnlock(h);
    }
    DmReleaseRecord(scoringdb, pos, 1);
	if (sort_db)
	{
	    DmQuickSort(scoringdb, (DmComparF *)comp_authors, 1);
	}
	MemPtrFree(key);
	return 0;
} /* ScrGiveScoreToAuthor */



