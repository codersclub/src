/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// export.c
//
// export routines of yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <System/DataMgr.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "lang.h"

#include "export.h"



int ExpExportToMemo(struct articledb_item *art)
{
	DmOpenRef mdb;
	VoidHand h; 
	char *dest;
	UInt len, dbpos = -1, pos, 
		lenfrom, lensubject, lendate, lennewsgroups, lenbody;
	
	mdb = NPOpenDB("MemoDB");
	if (mdb == 0)
	{
		return 1;
	}
	lenfrom = StrLen(art->from);
	lensubject = StrLen(art->subject);
	lendate = StrLen(art->date);
	lennewsgroups = StrLen(art->newsgroups);
	lenbody = StrLen(art->body);
	len = 6 + 10 + 7 + 13 + 2 + 
		lenfrom + lensubject + lendate + lennewsgroups + lenbody + 1;
	h = DmNewRecord(mdb, &dbpos, len);
	if (h == 0)
	{
		return 2;
	}
	dest = MemHandleLock(h);
	pos = 0;
	DmWrite(dest, pos, yf_from, 6); pos += 6;
	DmWrite(dest, pos, art->from, lenfrom); pos += lenfrom;
	DmWrite(dest, pos, yf_nsubject, 10); pos += 10;
	DmWrite(dest, pos, art->subject, lensubject); pos += lensubject;
	DmWrite(dest, pos, yf_ndate, 8); pos += 7;
	DmWrite(dest, pos, art->date, lendate); pos += lendate;
	DmWrite(dest, pos, yf_nnewsgroups, 13); pos += 13;
	DmWrite(dest, pos, art->newsgroups, lennewsgroups); pos += lennewsgroups;
	DmWrite(dest, pos, "\n\n", 2); pos += 2;
	DmWrite(dest, pos, art->body, lenbody + 1);
	MemHandleUnlock(h);
	DmReleaseRecord(mdb, dbpos, 1);
	DmCloseDatabase(mdb);
	return 0;
} /* ExpExportToMemo */

