/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
#ifndef FRMART_H
#define FRMART_H


#include "artdb.h"

#define artModeBody 0
#define artModeHeader 1
#define artModeUpdate 2

// Ydebug testing ...
extern DBArtNum active_article;
extern struct articledb_item art;


DBArtNum FrmArtActiveArtNum(void);

void ArtFGotoArticle(UInt n);
Boolean HandleArticle(EventPtr event);


#endif