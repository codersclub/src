/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// msgiddb.h
//
// MsgID management headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef MSGIDDB_H
#define MSGIDDB_H


typedef struct msgiddb_item
{
	ULong date;
	char *msgid;
} msgiddb_item;



int MidAddMsgID(char *msgid) SECTION_3;
int MidMsgIDExists(char *msgid) SECTION_3;
int MidPurgeMsgIDs(ULong delta) SECTION_3;
void MidSortMsgIds(void) SECTION_3;

Boolean HandlePurge(EventPtr event) SECTION_3;




#endif

