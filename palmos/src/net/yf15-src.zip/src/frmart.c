/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmart.c
//
// Handle the article form
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif


#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "ngroup.h"
#include "network.h"
#include "export.h"
#include "lang.h"
#include "subscrdb.h"

#include "frmartlist.h"
#include "frmart.h"
#include "frmpost.h"
#include "prefs.h"
#include "scoring.h"

#include "mainmenu.h"




int top_line, old_top_line;
FontID ArtFont = stdFont;
int artmode = artModeBody,
	delete_on_exit;
struct articledb_item art;
DBArtNum active_article = -1;
char *header;
Word artpagesize;




DBArtNum FrmArtActiveArtNum(void)
{
	return active_article;
} /* FrmArtActiveArtNum */


static int ScrollArtField(Short linesToScroll)
{
	Short min, max, value, pageSize;
	FieldPtr fld;
	ScrollBarPtr bar;
	RectangleType r;
	Word textheight, fieldheight, next_top;
	
    fld = GetObjectPtr(fldArtString);
 	FldGetBounds(fld, &r);
	fieldheight = r.extent.y / FntLineHeight();
	textheight = FldCalcFieldHeight(FldGetTextPtr(fld), r.extent.x);
	next_top = GetNewTopline(top_line, textheight, fieldheight, linesToScroll);

	if (linesToScroll < 0)
	{
        FldScrollField(fld, top_line - next_top, up);
	}		
	else if (linesToScroll > 0)
	{
		FldScrollField (fld, next_top - top_line, down);
	}

	if (next_top == top_line)
	{
		return 1; // switch to different article
	}

	top_line = next_top;
    bar = GetObjectPtr(sbArticle);
    SclGetScrollBar(bar, &value, &min, &max, &pageSize);
    SclSetScrollBar(bar, top_line, min, max, pageSize);
    return 0;
} /* ScrollArtField */







static void ConstructHeader(char **head)
{
	VoidHand h;
	UInt size;
	
	size = StrLen(art.subject) + StrLen(art.from) + StrLen(art.date)
		+ StrLen(art.newsgroups) + StrLen(art.msgid) + 49 + 1;
	h = MemHandleNew(size);
	if (h == 0)
	{
		*head = NULL;
		return;
	}
	*head = (char *) MemHandleLock(h);
	StrCopy(*head, yf_from);
	StrCat(*head, art.from);
	StrCat(*head, yf_nsubject);
	StrCat(*head, art.subject);
	StrCat(*head, yf_ndate);
	StrCat(*head, art.date);
	StrCat(*head, yf_nmsgid);
	StrCat(*head, art.msgid);
	StrCat(*head, yf_nnewsgroups);
	StrCat(*head, art.newsgroups);
	StrCat(*head, "\n");
} /* ConstructHeader */




static char *GenReferences(char *artref, char *artid)
{
	char *ref;
	
	ref = MemPtrNew(StrLen(artref) + StrLen(artid) + 2);
	if (ref == NULL)
	{
		return NULL;
	}
	*ref = 0;
	if (*artref)
	{
		StrCopy(ref, artref);
		StrCat(ref, " ");
	}
	StrCat(ref, artid);
	return ref;
} /* GenReferences */



static void InitArtField(int show_mode)
{
	FieldPtr fld;
	FormPtr frm;
	FieldAttrType attr;
	ControlType *btnH, *btnS;
	Word fieldheight,
		textheight;
	RectangleType r;
	char *fieldtext,
		*fromdum;
	int top_dum;
	

	
	NGReadArticle(active_article, &art);
    btnS = GetObjectPtr(btnSelect);
	CtlSetValue(btnS, (art.flags & yfArticleFlagMarked));
    btnS = GetObjectPtr(btnKeep);
	CtlSetValue(btnS, (art.flags & yfArticleFlagKeep));

    if ((artmode != show_mode) || (show_mode == artModeUpdate))
    {
		if (show_mode == artModeUpdate)
		{
			show_mode = artmode;
		}

//	    if (!StrCompare(NGActiveNewsgroup(), outgoing_group))
	    if (active_ng.ng_flags & yfNGFlag_internal)
	    {
		    btnH = GetObjectPtr(btnFUp);
			CtlSetLabel(btnH, yf_edit);	
			btnH = GetObjectPtr(btnReply);
			CtlSetUsable(btnH, 0);
			CtlHideControl(btnH);
		}
	    
	    btnH = GetObjectPtr(btnHeader);
		if (show_mode == artModeBody)
		{
			fieldtext = art.body;
			if (!(*art.body) && NPOnlineMode()) 
			{
				// Body empty - so get it while we are online
				NPInvokePoll(pollSingleBody, active_article);
				return;
			}
			CtlSetLabel(btnH, yf_head);
		}
		else if (header != NULL)
		{
			fieldtext = header;
			CtlSetLabel(btnH, yf_body);
		}
		else
		{
			fieldtext = yf_header_not_avail;
		}
	
		artmode = show_mode;
	
		top_dum = top_line;
	    top_line = old_top_line;
	    old_top_line = top_dum;
	
	
	    fld = GetObjectPtr(fldArtString);
	    FldEraseField(fld);
		FldSetTextPtr(fld, fieldtext);
		FldRecalculateField(fld, 0);
		FldSetScrollPosition(fld, 0);
		if (top_line)
		{
		    FldScrollField(fld, top_line, down);
		}
	
		frm = FrmGetActiveForm();
		if (active_ng.title_contents == yfNGDisplay_subject)
		{
			NPSetFormTitle(frm, art.subject, 0);
		}
		else
		{
			fromdum = MemPtrNew(StrLen(art.from) + 1);
			if (fromdum == NULL)
			{
				return;
			}
			GenFromStyle(art.from, fromdum, 0);
			NPSetFormTitle(frm, fromdum, 0);
			MemPtrFree(fromdum);
		}
	
	 	FldGetBounds(fld, &r);
		fieldheight = r.extent.y / FntLineHeight();
		textheight = FldCalcFieldHeight(fieldtext, r.extent.x);
	    FldGetAttributes(fld, &attr);
	
	
		artpagesize = fieldheight - 1;
		if (textheight > fieldheight)
		{
		    attr.hasScrollBar = 1;
			SclSetScrollBar(GetObjectPtr(sbArticle), top_line, 0,  textheight - fieldheight, artpagesize);
		}
		else
		{
		    attr.hasScrollBar = 0;
			SclSetScrollBar(GetObjectPtr(sbArticle), 0, 0,  0, 0);
		}
	    FldSetAttributes(fld, &attr);
//	    UpdateField(fldArtString, sbArticle);
	}
	
	RefreshForm();
	ShowButton(btnPrev, active_article != 0);
	ShowButton(btnNext, (active_article != (NGArticlesCount() - 1)));
} /* InitArtField */



static void FlipButton(Word btn)
{
	ControlType *btnS;
	Short dum;
	
    btnS = GetObjectPtr(btn);
	dum = CtlGetValue(btnS);
	CtlSetValue(btnS, !dum);
} /* FlipButton */




static void CloseArtField(void)
{
	FieldPtr fld;
	
    fld = GetObjectPtr(fldArtString);
    FldEraseField(fld);
	FldFreeMemory(fld);    
	MemPtrFree(header);
} /* CloseArtField */




static int HandleArtMenu(EventPtr e)
{
	FieldPtr fld;

	fld = GetObjectPtr(fldArtString);
	switch (e->data.menu.itemID)
	{
		case mArtCopy:
		{
			FldCopy(fld);
			FldSetSelection(fld, 0, 0);
			FldRecalculateField(fld, 1);
			return 1;
			break;
		}

		case mArtSelectAll:
		{
			FldSetSelection(fld, 0, FldGetTextLength(fld) - 1);
			FldRecalculateField(fld, 0);
			return 1;
			break;
		}
		
		case mArtExportMemo:
		{
			ExpExportToMemo(&art);
			return 1;
			break;
		}

		case mArtComplete:
		{
			pprefs.poll_what = poll_what_complete;
			NPInvokePoll(pollSingleBody, active_article);
			return 1;
			break;
		}
		
		default:
	}
	
	return 0;
} /* HandleArtMenu */




static void SwitchToDifferentArticle(int delta, int jump_to_unread)
{
	int stop = 0;
	DBArtNum next_art, art_dum;

	art_dum = active_article;
	next_art = active_article;
	// The sequence of the boolean expressions is important!
	while (!stop 
		&& ((delta >= 0) || (next_art >= -delta))
		&& ((next_art + delta) < NGArticlesCount()) )
	{
		next_art += delta;
		NGReadArticle(next_art, &art);
		if ((jump_to_unread && !(art.flags & yfArticleFlagRead))
			|| (!jump_to_unread))
		{
			active_article = next_art;
			artmode = -1;
			top_line = 0;
			old_top_line = 0;
			MemPtrFree(header);
			ConstructHeader(&header);
			NGSetArticleFlag(active_article, yfArticleFlagRead, 1);
			FrmUpdateForm(frmArticle, *(art.body) ? artModeBody : artModeHeader);
			stop = 1;
		}
	}
	if (art_dum == active_article)
	{
		SndPlaySystemSound(sndInfo);
	}
	FrmArtListAdvanceSelArtNum(active_article - art_dum);
} /* SwitchToDifferentArticle */







static void FollowUp(void)
{
	char *ng, *ref;

	ng = NGActiveNewsgroup();
//	if (StrCompare(ng, outgoing_group))
	if (!(active_ng.ng_flags & yfNGFlag_internal))
	{
		ref = GenReferences(art.ref, art.msgid);
		if (ref != NULL)
		{
			if (*art.fup_to)
			{
				if (StrCaselessCompare(art.fup_to, "poster"))
				{
					InvokePost(0, 0, art.fup_to, art.subject, ref, art.body, 0);
				}
				else
				{
					InvokePost(0, 1, art.from, art.subject, NULL, art.body, 0);
				}
			}
			else
			{
				InvokePost(0, 0, ng, art.subject, ref, art.body, 0);
			}
			MemPtrFree(ref);
		}
	}
	else
	{
		delete_on_exit = InvokePost(1, (StrChr(art.newsgroups, '@') != NULL), 
			art.newsgroups, art.subject, art.ref, art.body, art.server);
		// We are in Drafts or Outgoing so delete article - it
		// will be saved again anyway (or user doesn't want it)
//		NGDeleteArticle(active_article);
	}
} /* FollowUp */



static void ExitArticle(void)
{
	CloseArtField();
	if (delete_on_exit)
	{
		NGDeleteArticle(active_article);
		NPUpdateForm(frmArtList, updArtListMajorChanges);
		NPUpdateForm(frmNewsgroups, 1);
	}
	else
	{
		NPUpdateForm(frmArtList, updArtListMinorChanges);
	}
	NPExitForm();
	active_article = -1;
} /* ExitArticle */


static void RecallSavedState(void)
{
	if (ystate.currently_writing_article != -1)
	{
		EditSavedArticle();
	}
} /* RecallSavedState */



Boolean HandleArticle(EventPtr event)
{
	int handled = 0,
		ok = 1;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			artmode = -1;
			top_line = 0;
			old_top_line = 0;
			delete_on_exit = 0;
			if (!NGNewsgroupOpen())
			{
				if (NGOpenNewsgroupByPos(active_ng_num) == NULL)
				{
					// Go to Newsgroups list view because active ng doesn't exist.
					ok = 0;
				}
			}
			if (ok)
			{
				if (NGReadArticle(active_article, &art) == 1)
				{
					// Art no longer present
					ok = 0;
				}
				else
				{
					ConstructHeader(&header);
					InitArtField(*(art.body) ? artModeBody : artModeHeader);
					RecallSavedState();
				}
			}

			if (!ok)
			{
				NPExitForm();
				// Set system to safe values
				active_article = -1;
				ystate.currently_writing_article = -1;
			}
            handled = 1;
            break;
        }

		case frmUpdateEvent:
		{
			InitArtField(event->data.frmUpdate.updateCode);
			handled = 1;
			break;
		}

		case sclRepeatEvent:
		{
			ScrollArtField(event->data.sclRepeat.newValue -
						event->data.sclRepeat.value);
			break;
		}

        case menuEvent:
        {
			handled = HandleArtMenu(event);
			break;
        }
		
		case keyDownEvent:
		{
			switch (event->data.keyDown.chr)
			{
				case '0':
				case '1':
				case '2':
				case '3':
				case '4':
				case '5':
				{
					char dum[2];
					dum[0] = event->data.keyDown.chr;
					dum[1] = 0;
					ScrGiveScoreToAuthor(art.from, StrAToI(dum));
					ExitArticle();
					handled = 1;
					break;
				}

				case pageUpChr:
				{
					if (ScrollArtField(-artpagesize))
					{
						SwitchToDifferentArticle(-1, 0);
					}
					handled = 1;
					break;
				}

				case pageDownChr:
				{
					if (ScrollArtField(artpagesize))
					{
						SwitchToDifferentArticle(1, 0);
					}
					handled = 1;
					break;
				}

				case chrBackspace:
				{
					ExitArticle();
					handled = 1; 
					break;
				}

				case vchrHard1:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						ExitArticle();
					}
					else
					{
						NGSetArticleFlag(active_article, yfArticleFlagMarked, -1);
						FlipButton(btnSelect);
					}
					handled = 1; 
					break;
				}

				case vchrHard2:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						SwitchToDifferentArticle(1, 0);
					}
					else
					{
						NGSetArticleFlag(active_article, yfArticleFlagKeep, -1);
						FlipButton(btnKeep);
					}
					handled = 1; 
					break;
				}
		
				case vchrHard3:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						NGSetArticleFlag(active_article, yfArticleFlagMarked, -1);
						FlipButton(btnSelect);
					}
					else
					{
						ExitArticle();
					}
					handled = 1;
					break;
				}
		
				case vchrHard4:
				{
					if (yprefs.buttons == yfButtonsLayout_right)
					{
						NGSetArticleFlag(active_article, yfArticleFlagKeep, -1);
						FlipButton(btnKeep);
					}
					else
					{
						SwitchToDifferentArticle(1, 0);
					}
					handled = 1; 
					break;
				}

				case '+':
				case ' ':
				{
					SwitchToDifferentArticle(1, 0);
					handled = 1;
					break;
				}

				case '-':
				{
					SwitchToDifferentArticle(-1, 0);
					handled = 1;
					break;
				}

				case '.':
				{
					// Switch to next unread
					SwitchToDifferentArticle(1, 1);
					handled = 1;
					break;
				}

				default:
			}
			break;
		}
		
		case ctlSelectEvent:
		{
			switch (event->data.ctlSelect.controlID)
			{
				case btnOK:
				{
					ExitArticle();
					handled = 1;
					break;
				}
				
				case btnHeader:
				{
					NGReadArticle(active_article, &art);
					if (artmode == artModeBody)
					{
						FrmUpdateForm(frmArticle, artModeHeader);
					}
					else
					{
						FrmUpdateForm(frmArticle, artModeBody);
					}
					handled = 1;
					break;
				}
				
				case btnFUp:
				{
					FollowUp();
					handled = 1;
					break;
				}

				case btnReply:
				{
					InvokePost(0, 1, art.from, art.subject, NULL, art.body, 0);	
					handled = 1;
					break;
				}

				case btnPrev:
				{
					SwitchToDifferentArticle(-1, 0);
					handled = 1;
					break;
				}
				
				case btnNext:
				{
					SwitchToDifferentArticle(1, 0);
					handled = 1;
					break;
				}
				
				case btnSelect:
				{
					NGSetArticleFlag(active_article, yfArticleFlagMarked, -1);
					handled = 1;
					break;
				}

				case btnKeep:
				{
					NGSetArticleFlag(active_article, yfArticleFlagKeep, -1);
					handled = 1;
					break;
				}
			}
		}

        default:
    }
    return handled;
} /* HandleArticle */






void ArtFGotoArticle(UInt n)
{
	if (NGArticlesCount() > 0)
	{
		// only change to art view if there actually /is/ an article
		// (used for button navigation
		active_article = n;
		NGSetArticleFlag(n, yfArticleFlagRead, 1);
		NPGotoForm(frmArticle);
	}
} /* ArtFGotoArticle */
