/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
#ifndef FRMPREFS4_H
#define FRMPREFS4_H

//
//
// frmprefs4.c
//
// handle the newsgroups prefs form of yanoff
// Matthias Jordan, 9-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#define ngprefs_called_from_menu 0
#define ngprefs_called_from_subs 1

void InvokePrefs4Newsgroups(int cas);


Boolean HandlePrefs4(EventPtr event);
Boolean HandlePrefs4CustomHeaders(EventPtr event);

#endif