/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// yanoff.c
//
// yanoff dummy
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "network.h"
#include "artdb.h"
#include "ngroup.h"
#include "subscrdb.h"
#include "serverdb.h"
#include "prefs.h"
#include "msgiddb.h"
#include "lang.h"
#include "launch.h"
#include "scoring.h"

#include "hardbtn.h"

#include "frmsubs.h"
#include "frmprefs1.h"
#include "frmprefs2.h"
#include "frmprefs4.h"
#include "frmprefsp.h"
#include "frmnglist.h"
#include "frmartlist.h"
#include "frmart.h"
#include "frmpost.h"
#include "frmpass.h"
#include "frmsrvsel.h"

extern char *buf;
extern Word buf_len;

char needSort = 0;



static Boolean AboutHandler(EventPtr event)
{
    int handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
            RefreshForm();
            handled = 1;
            break;
        }

		case ctlSelectEvent:
		{
			if (event->data.ctlSelect.controlID == btnOK)
			{
				NPExitForm();
			}
			handled = 1;
			break;
		}

        default:
    }
    return handled;
} /* AboutHandler */










static Boolean AppHandleEvent(EventPtr event)
{
  int formID;
  FormPtr form;

    if (event->eType == frmLoadEvent)
    {
      formID = event->data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) 
      {
        case frmNewsgroups:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandleNewsgroups);
        break;

        case frmArtList:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandleArtList);
        break;

        case frmArticle:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandleArticle);
        break;

        case frmPoll:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePoll);
        break;

        case frmAbout:
        FrmSetEventHandler(form, (FormEventHandlerPtr) AboutHandler);
        break;

        case frmSubscribe:
        FrmSetEventHandler(form, (FormEventHandlerPtr) SubscribeHandler);
        break;

        case frmAuthPass:
        FrmSetEventHandler(form, (FormEventHandlerPtr) AuthPassHandler);
        break;

        case frmPrefs1Other:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefs1);
        break;

        case frmPrefs2Server1:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefs2Server1);
        break;

        case frmPrefs2Server2:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefs2Server2);
        break;

        case frmPrefs4Newsgroup:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefs4);
        break;

        case frmPrefs4CustomHeaders:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefs4CustomHeaders);
        break;

        case frmPrefsPoll:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePrefsPoll);
        break;

        case frmPurge:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePurge);
        break;

        case frmPost:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandlePost);
        break;

        case frmServerSelection:
        FrmSetEventHandler(form, (FormEventHandlerPtr) HandleServerSelection);
        break;
      }
      return true;
    } 
    return false;
} /* AppHandleEvent */











static void EventLoop(void)
{
	short err;
	EventType event;

	do
	{

		EvtGetEvent(&event, -1);
	
		if (!HandleHardbuttons(&event))
		{
		    if (!SysHandleEvent(&event))
		    {
			    if (!MenuHandleEvent((void *)0, &event, &err))
				{
					if (!AppHandleEvent(&event))
					{
						FrmDispatchEvent(&event);
					}
				}
			}
		}
		else
		{
			if (!AppHandleEvent(&event))
			{
				FrmDispatchEvent(&event);
			}
		}
	}
	while(event.eType != appStopEvent);
} /* EventLoop */


static void StartApp(void)
{
	PrGetPrefs();
	PrGetState();
	SubOpenSubscriptions();
	SubSortSubscriptions();
	SubInitInternalGroups();
	ArtOpenArticles();
	ScrOpenScoring();
	SrvOpenServers();
	SrvInitServerDatabase();
	if (PrSortNeeded()) 
	{
  		MidSortMsgIds(); 
		PrSetSortNeeded(0);
	}
	NPInitFormStack(frmNewsgroups);
} /* StartApp */



static void StopApp(void)
{
	PrSaveState();
	FrmArtListUpdateNGEntry();
	SrvCloseServers();
	ScrCloseScoring();
	ArtCloseArticles();
	NGCloseNewsgroup();
	SubCloseSubscription();
	NPCloseNetwork(0, 0);
	PrSavePrefs();
    FrmCloseAllForms();
} /* StopApp */


static void LaunchPollAndPost(void)
{
	EventType evt;


    evt.eType = menuEvent;
    evt.data.menu.itemID = mPoll;
    EvtAddEventToQueue(&evt);
} /* LaunchPollAndPost */



static int ROMVersionOK(void)
{
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < 0x02000000)
	{
		FrmCustomAlert(alertID_dum, yf_palmos_warning, " ", " ");
		return 0;
	}
	return 1;
} /* ROMVersionOK */



DWord  PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
	if ((cmd == sysAppLaunchCmdNormalLaunch) && ROMVersionOK())
	{
		StartApp();
		EventLoop();    // Event loop
		StopApp();
	}
	
	if ((cmd == yfAppLaunchPollAndPost) && ROMVersionOK())
	{
		StartApp();
		LaunchPollAndPost();
		EventLoop();    // Event loop
		StopApp();
	}
	
	if (cmd == sysAppLaunchCmdSaveData)
	{
		; // do nothing
	}
	

	if (cmd == sysAppLaunchCmdSyncNotify) 
	{
		; // PrSetSortNeeded(1);
	}

	return 0;
} /* PilotMain */

