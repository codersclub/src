/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// frmsubs.c
//
// Handles the Subscription form
// Matthias Jordan, 4-1999
//
//


#ifndef OS35
	#pragma pack(2)
	#include <Common.h>
	#include <System/SysAll.h>
	#include <UI/UIAll.h>
#else
	#include<PalmOS.h>
	#include<PalmCompatibility.h>
#endif

#include "yanoff.h"
#include "segment.h"
#include "general.h"
#include "subscrdb.h"
#include "ngroup.h"
#include "lang.h"
#include "frmprefs4.h"
#include "frmsubs.h"

VoidHand subsh;
char *ng;

//
//
// Subscription routines
//
//



static int Subscribe(void)
{
	int res;

    ng = GetFormParameter(yf_newsgroup, fldSubsName);
    if (*ng == 0)
    {
        return 0;
    }

	// If there is more than one (mail) server in the servers list
	// the default server is no 1. Otherwise it is 0 ("don't poll")
    if (SrvServersCount() >= 2)
    {
	    res = SubAddSubscription(ng, 0, 1);
	}
	else
	{
	    res = SubAddSubscription(ng, 0, 0);
	}

	if (!res)
    {
		// we have been called from menu in newsgroups list view so update
		// directly
        NPUpdateForm(frmNewsgroups, 1);
    }
    else if (res == 2)
    {
        FrmCustomAlert(altInfo, yf_newsgroup, yf_already_subs, " ");
    }
    else
    {
    	FrmCustomAlert(altInfo, yf_mem_low, " ", " ");
    }
    return 1;
} /* Subscribe */




static void InitSubsField(void)
{
	FieldPtr fld;
	char *str;
	
	fld = GetObjectPtr(fldSubsName);
	// allocate 100 bytes so there is no need to resize the chunk too soon.
	subsh = MemHandleNew(100); 
	if (subsh == 0)
	{
		FrmCustomAlert(altInfo, yf_mem_low, " ", " ");
		NPExitForm();
		return;
	}
	str = MemHandleLock(subsh);
	*str = 0;
	MemHandleUnlock(subsh);
	FldSetTextHandle(fld, (Handle) subsh);
} /* InitSubsField */



Boolean SubscribeHandler(EventPtr event)
{
    int handled = 0;

    switch (event->eType)
    {
        case frmOpenEvent:
        {
			InitSubsField();
            RefreshForm();
			SetFocus(fldSubsName);
            handled = 1;
            break;
        }

        case menuEvent:
        {
			handled = HandleEditMenu(event);
			break;
        }
		
		case ctlSelectEvent:
		{
			if (event->data.ctlSelect.controlID == btnOK)
			{
				if (Subscribe())
				{
					NGOpenNewsgroupByName(ng);
					InvokePrefs4Newsgroups(ngprefs_called_from_subs);
				}
				handled = 1;
			}
			else if (event->data.ctlSelect.controlID == btnCancel)
			{
				NPExitForm();
				handled = 1;
			}
			break;
		}
		
		case keyDownEvent:
		{
			handled = HandleInput(event, fldSubsName, 0, bad_characters);
			break;
		}
		
		default:
    }
    return handled;
} /* SubscribeHandler */






void Unsubscribe(char *ng)
{
	UInt max, 
		i;
	char *ng2del;
	VoidHand h;
	

    if (ng == NULL)
    {
        return;
    }
    
	// Memorize newsgroup name
	h = MemHandleNew(StrLen(ng) + 1);
	if (h == 0)
	{
		return;
	}
	ng2del = MemHandleLock(h);
	StrCopy(ng2del, ng);
	
	// Delete all articles in group
	max = NGArticlesCount();
	for (i = 0; (i < max); i++)
	{
		NGDeleteArticle(0);
	}
	NGCloseNewsgroup();
	
    if (!SubDeleteSubscription(ng2del))
    {
        FrmCustomAlert(altInfo, yf_suc_unsub, " ", " ");
    }
    MemHandleUnlock(h);
    MemHandleFree(h);
} /* Unsubscribe */

