/**************************************************************************

	Yanoff - the free UseNet news reader for the Palm Computing Platform
    Copyright (C) 1999 Matthias Jordan

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

	Reach the author via 
	email: mjordan@sensenet.wirepool.free.de

**************************************************************************/
//
//
// subscrdb.h
//
// newsgroup subscription management headers for use with yanoff
// Matthias Jordan, 4-1999
//
//


#ifndef SUBSCRDB_H
#define SUBSCRDB_H


#include "serverdb.h"
#include "artdb.h"

//
// All articles are stored in a huge database to implement crossposting.
// Every newsgroup gets its own ref database that only contains the ids
// of its articles from the article database.
// A third database is used to store the subscriptions, i.e.
// what newsgroups do we have, what is their last article and in
// which database are the article ids stored.
//


typedef struct subscriptiondb_item
{
    ULong last;
    UInt ng_flags,
	    ng_artmaxkb,
    	ng_downmax,
    	ng_samplearts;
    DBServerNum server;
    DBArtNum last_sel;		// the last selected article when leaving the group
    // In the database there is 1 byte padding at this place
    char thread_arts;
    DBArtNum last_top;		// the last top article when leaving the group
    UInt title_contents;	// should be the subject displayed in article view or the author?
    char *dbid,	
    	*newsgroup,
    	*headers;
} subscriptiondb_item_t;

typedef unsigned short DBNGNum;


#define yfNGFlag_internal 1     // don't ever poll this newsgroup
#define yfNGFlag_dont_poll 2	// don't poll newsgroup (editable by user)
#define yfNGFlag_poll_next 4	// poll next n articles instead of the last ones

#define yfNGDisplay_subject 0
#define yfNGDisplay_author 1



DmOpenRef SubOpenSubscriptions(void);
void SubCloseSubscription(void);
int SubReadSubscription2(char *newsgroup, char *dbid, ULong *last, 
	DBNGNum *npos);
int SubGetSubscriptionByPos(DBNGNum pos, struct subscriptiondb_item *sub);
DBNGNum SubGetSubscriptionPos(char *newsgroup);
int SubGetSubscriptionByName(char *newsgroup, struct subscriptiondb_item *sub);
int SubSetSubscriptionInfo(DBNGNum pos, struct subscriptiondb_item *sub);
char *SubNGDatabaseName(char *ng, char *buf);
int SubAddSubscription(char *newsgroup, UInt flags, DBServerNum server);
void SubInitInternalGroups(void);
int SubSeekSubscription2(DBNGNum pos, char **ngname);
int SubUpdateSubscription(DBNGNum pos, ULong last);
int SubUpdateSubscriptionTopArt(DBNGNum pos, DBArtNum top_art, DBArtNum top_sel);
int SubDeleteSubscription(char *newsgroup);
DBNGNum SubSubscriptionsCount(void);
void SubCorrectServerNum(DBServerNum deleted_server_num);
void SubSortSubscriptions(void);



#endif

