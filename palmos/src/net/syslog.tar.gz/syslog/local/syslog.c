#include <PalmOS.h>
#include <PalmCompatibility.h>

#define DOC_CREATOR    'REAd'
#define DOC_TYPE       'TEXt'
#define RECSIZE		4096

struct RECORD0 {
    Byte    crap;
    Byte    wVersion;
    Word    wSpare;
    DWord   dwStoryLen;
    Word    wNumRecs;
    Word    wRecSize;
    DWord   dwSpare2;
};

char		*logName = NULL;
struct RECORD0	rec0,*newP;

void LogInit(char *name) {
    LocalID		id;
    DmOpenRef		ref;
    UInt		index = dmMaxRecordIndex;
    MemHandle		newH;
    
    if (DmFindDatabase(0,name) == 0) {
	DmCreateDatabase(0,name,DOC_CREATOR,DOC_TYPE,false);
	id = DmFindDatabase(0,name);
	ref = DmOpenDatabase(0,id,dmModeWrite);

	newH = DmNewRecord(ref,&index,sizeof(rec0));
	newP = MemHandleLock(newH);
	MemSet(&rec0,sizeof(rec0),0);
	rec0.crap = 1;
	rec0.wVersion = 1;
	rec0.wRecSize = RECSIZE;
	rec0.wNumRecs = 1;
	DmWrite(newP,0,&rec0,sizeof(rec0));
	DmReleaseRecord(ref,index,true);
	MemHandleUnlock(newH);

	index = dmMaxRecordIndex;
	newH = DmNewRecord(ref,&index,1);
	DmWrite(MemHandleLock(newH),0,"",1);
	DmReleaseRecord(ref,index,true);
	MemHandleUnlock(newH);

	DmCloseDatabase(ref);
    }
    logName = name;
}

void LogWrite(char *who,char *message) {
    LocalID		id;
    DmOpenRef		ref;
    UInt		index;
    MemHandle		newH;
    DateTimeType	now;
    char		*text,str[256];
    char		*z1="",*z2="",*z3="",*z4="",*z5 = "";
    UInt32		size,newsize;
    
    TimSecondsToDateTime(TimGetSeconds(),&now);
    if (now.day < 10) z1 = "0";
    if (now.month < 10) z2 = "0";
    if (now.hour < 10) z3 = "0";
    if (now.minute < 10) z4 = "0";
    if (now.second < 10) z5 = "0";
    
    StrPrintF(str,"%s%u/%s%u %s%u:%s%u:%s%u [%s] %s\n",z1,now.day,z2,now.month,
	z3,now.hour,z4,now.minute,z5,now.second,who,message);

    if ((id = DmFindDatabase(0,logName)) != 0) {
	ref = DmOpenDatabase(0,id,dmModeWrite);

	index = DmNumRecords(ref) - 1;
	newH = DmGetRecord(ref,index);
	text = MemHandleLock(newH);
	size = StrLen(text);
	newsize = size+StrLen(str)+1;
	MemHandleUnlock(newH);
	
	if (newsize < RECSIZE) {
	    newH = DmResizeRecord(ref,index,newsize);
	} else {
	    newH = DmGetRecord(ref,0);
	    newP = MemHandleLock(newH);
	    MemMove(&rec0,newP,sizeof(rec0));
	    rec0.wNumRecs++;
	    DmWrite(newP,0,&rec0,sizeof(rec0));
	    DmReleaseRecord(ref,index,true);
	    MemHandleUnlock(newH);

	    index = dmMaxRecordIndex;
	    newH = DmNewRecord(ref,&index,StrLen(str)+1);
	    size = 0;
	}	
	text = MemHandleLock(newH);
	DmWrite(text,size,str,StrLen(str)+1);
	DmReleaseRecord(ref,index,true);
	MemHandleUnlock(newH);
	DmCloseDatabase(ref);
    }
}

void LogInfo(int pri, int facility) {
}
