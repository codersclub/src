syslog library (GLib shared .sa and static .a) for debug PalmOS applications.

local - it work local on palm device (write to .prb doc)
remote - it write to remote unix host (syslogd)

Author: Belousov Oleg <oleg@belousov.com>
