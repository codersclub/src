#include <PalmOS.h>
#include <PalmCompatibility.h>
#include <sys_socket.h>
#include <netdb.h>

#define PORT 514

Err	errno, h_errno;
Long	AppNetTimeout;
Word	AppNetRefnum;
int	netisopen;
char	*hostname;
char	pri_text[4];

static Err OpenNet(void)
{
    Err err;
    Word ifErrs;

    if (netisopen) return 0;

    err = SysLibFind("Net.lib", &AppNetRefnum);
    if (err) return err;

    err = NetLibOpen(AppNetRefnum, &ifErrs);
    if ((err && err != netErrAlreadyOpen) || ifErrs) return err;

    AppNetTimeout = SysTicksPerSecond() * 4;
    netisopen++;

    return 0;
}

void LogInit(char *name) {
    OpenNet();
    hostname = name;
    StrCopy(pri_text,"0");
}

void LogWrite(char *who,char *message) {
    int			fd = -1;
    struct sockaddr_in	saddr, myaddr;
    struct hostent 	*hp;
    char		pkt[512];

    bzero(&saddr, sizeof saddr);
    saddr.sin_family = AF_INET;
    saddr.sin_port = htons(PORT);
    if ((saddr.sin_addr.s_addr = inet_addr(hostname)) == -1) {
	hp = gethostbyname(hostname);
	bcopy(hp->h_addr, &saddr.sin_addr, sizeof saddr.sin_addr);
    }
    
    bzero(&myaddr, sizeof myaddr);
    myaddr.sin_family = AF_INET;
    myaddr.sin_port = htons(3030);
    myaddr.sin_addr.s_addr = INADDR_ANY;

    StrPrintF(pkt,"<%s>%s: %s",pri_text,who,message);
    fd = socket(AF_INET, SOCK_DGRAM, 0);
    bind(fd, (struct sockaddr *) &myaddr, sizeof myaddr);
    sendto(fd, &pkt, StrLen(pkt), 0, (struct sockaddr *) &saddr, sizeof saddr);

    if (fd >= 0) close(fd);
}

void LogInfo(int pri, int facility) {
    StrPrintF(pri_text,"%i",pri | facility);
}
