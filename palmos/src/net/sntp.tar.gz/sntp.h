#define formID_sntp		1000

#define menuID_sntp		1000

#define menuitemID_help		1001
#define menuitemID_about	1002
#define menuitemID_copy		1003
#define menuitemID_paste	1004

#define fieldID_host		1003
#define fieldID_ans		1004
#define fieldID_zone		1005

#define buttonID_query		1006
#define buttonID_set		1007
#define buttonID_TZ		1008

#define stringID_help		1010
#define alertID_about		1011
