#include "field.h"
#include "xio.h"

#define HttpdAppID    'hTTP'

#define PORT 80

/* System/Unix/unix_string.h has strcmp->StrCompare, but
   does *not* have strncmp doing the same, so we must be
   getting some other function and not getting a valid
   prototype... */
#undef strncmp
#define strncmp StrNCompare

extern char html0[];
extern char html_go_home[];
extern char httpd_icon[];
extern int httpd_icon_size;

int send_doc_index(XFILE *f);

int send_addr_index(XFILE *f);
int send_addr_file(XFILE *f, char *url);
int send_date_index(XFILE *f);
int send_date_file(XFILE *f, char *url);
int send_debug_index(XFILE *f);
int send_doc_index(XFILE *f);
int send_doc_file(XFILE *f, char* url);
int send_memo_index(XFILE *f, char *url);
int send_memo_file(XFILE *f, char *url, int flags);

int send_404(XFILE *f, char *url);
int wrstr(XFILE *f, const char *fmt, ...);
int pr(const char *fmt, ...);
void sprerr(char *buf, int err);
void prerr(char *s, int err);
