#define formID_httpd		1000

#define menuID_httpd		1000

#define menuitemID_about	1001
#define menuitemID_copy		1002
#define menuitemID_paste	1003

#define fieldID_msg		1001

#define buttonID_go		1021
#define buttonID_stop		1022

#define alertID_about		1000
