#define FLDFLUSH	0x1
#define FLDADDNL	0x2

#ifndef printf
#define printf palmprintf
#endif

/* This will pull in the clib sprintf instead of using the crippled Pilot rom one */
#undef sprintf
#undef vsprintf

/* System/Unix/unix_string.h has strcmp->StrCompare, but
   does *not* have strncmp doing the same, so we must be
   getting some other function and not getting a valid
   prototype... */
#undef strncmp
#define strncmp StrNCompare

extern FieldPtr printfield;

extern palmprintf(const char *fmt, ...);
extern prfield(FieldPtr fp, const char *fmt, ...);
extern setfield(FieldPtr fp, char *s);
extern putscrollfield(FieldPtr fp, char *s, int flags);
extern putfield(FieldPtr fp, char *s);
extern scrollfield(FieldPtr fp, int dirchr);
extern memofield(FieldPtr fp, char *title);
extern hidefield(UInt16 r);
extern showfield(UInt16 r);
extern char *strdup(char *s);
