#ifdef __palmos__
extern Err errno, h_errno;
extern Long AppNetTimeout;
extern Word AppNetRefnum;

extern int netisopen;

Err OpenNet(), CloseNet();
#endif

int openconn(char *hostname, int port, int flags);
