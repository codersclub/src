int tdb_open(char *name, char *crname, char *how);
int tdb_delete(char *name);
void *tdb_read();
void tdb_create(int len);
void tdb_write(void *p, int len);
void tdb_release();
void tdb_close();
