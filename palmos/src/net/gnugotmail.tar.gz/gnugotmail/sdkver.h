/* $Id: sdkver.h,v 1.1 2000/03/14 17:02:38 chrisf Exp $ */

#ifndef __SDKVER_H__
#define __SDKVER_H__

/* Ways to determine SDK header version (PalmOS2, 3 etc) */

#ifndef SDK_VERSION

/* 3.5 uses <PalmTypes.h> instead of <Common.h>.  */
#if defined(__PALMTYPES_H__)
#define SDK_VERSION 35

/* Otherwise, all versions of Common.h unconditionally #include
   <BuildRules.h>.  #defines corresponding to new functionality in
   each SDK were added to this file.  */

/* 3.1 added Japanese support.  */
#elif defined(LANGUAGE_JAPANESE)
#define SDK_VERSION 31

/* 3.0 introduced the v2 memory manager.  */
#elif defined(MEMORY_VERSION_2)
#define SDK_VERSION 30

/* 2.0 added Italian support.  */
#elif defined(LANGUAGE_ITALIAN)
#define SDK_VERSION 20

#else
#define SDK_VERSION 10
#endif

#endif

#endif
