/* $Id: sockets.c,v 1.24 1999/11/11 22:20:55 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <Pilot.h>
#include <System/NetMgr.h>
#include "common.h"
#include "gnugotmail.h"
#include "sockets.h"
#include "pop.h"

/* define some data types */

extern Long AppNetTimeout;
extern Word AppNetRefnum;
extern Err errno;
extern Char AppErrStr[];
extern struct spopdata popd;
extern struct ssmtpdata smtpd;

/* globals */

char localip[20], remoteip[20];
char base64[]="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
 
int connectsock(char *host, char *service)
{
    NetSocketRef sock;
    NetSocketAddrType laddr, raddr;
    NetIPAddr inetval;
    SWord laddrlen, raddrlen;
    int one;
    short i1;
    NetSocketAddrINType saddr;
    NetHostInfoPtr phe;
    NetHostInfoBufType AppHostInfo;
    char tempbuf[64];
    Boolean nameresolved=false;

    one = 1;

    MemSet((char *) &saddr, sizeof(saddr), 0);
    saddr.family = netSocketAddrINET;
    saddr.port = NetHToNS(StrAToI(service));

    if ((sock = NetLibSocketOpen(AppNetRefnum, netSocketAddrINET,
        netSocketTypeStream, 0, AppNetTimeout, &errno)) < 0) {
        ShowInfoMsg("");
        SetErrorMsg(ErrToString(errno));
        return 0;
    }

    /*
     * Map host name to IP address, allowing for dotted decimal.
     * I try to assimilate the name first to see if it is just
     * a dotted IP.  If not, then I use the DNS to resolve.
     */
    ShowInfoMsg("Looking up IP.");
    if ((saddr.addr = NetLibAddrAToIN(AppNetRefnum, host)) == -1) {
        if ((phe = NetLibGetHostByName(AppNetRefnum, host, &AppHostInfo,
            AppNetTimeout, &errno)) != 0) {
            /*
             * Sometimes the first address in the list is zero.  This
             * makes me have to search through them to find the first
             * non-zero address.
             */
            for (i1=0; i1 < netDNSMaxAddresses; i1++) {
                if (phe->addrListP[i1] != NULL) {
                    if (*phe->addrListP[i1] != '\0') {
                        MemMove((char *) &saddr.addr,
                            (char *) phe->addrListP[i1], phe->addrLen);
                        nameresolved = true;
                        break;
                    }
                }
            }
        }
        if (!nameresolved) {
            NetLibSocketClose(AppNetRefnum, sock, AppNetTimeout, &errno);
            ShowInfoMsg("");
            SetErrorMsg("NetLibGetHostByName failure.");
            return 0;
        }
    }

    if (NetLibSocketConnect(AppNetRefnum, sock, (NetSocketAddrType *) &saddr,
        sizeof(saddr), AppNetTimeout, &errno) != 0) {
        NetLibSocketClose(AppNetRefnum, sock, AppNetTimeout, &errno);
        ShowInfoMsg("");
        SetErrorMsg("connect failure.");
        return 0;
    }

    /*
     * Get the local and remote IP addresses.  This is used for the HELO
     * SMTP command later.
     */
    laddrlen = sizeof(laddr);
    raddrlen = sizeof(raddr);
    if ((NetLibSocketAddr(AppNetRefnum, sock, &laddr, &laddrlen,
        &raddr, &raddrlen, AppNetTimeout, &errno)) == 0) {
        /*
         * Trying to avoid a bus error which I presume would happen if
         * I tried to typecast.
         */
        inetval = ((DWord) laddr.data[5]) + (((DWord) laddr.data[4])<<8) +
             (((DWord) laddr.data[3])<<16) + (((DWord) laddr.data[2])<<24);
        NetLibAddrINToA(AppNetRefnum, inetval, localip);
        inetval = ((DWord) raddr.data[5]) + (((DWord) raddr.data[4])<<8) +
             (((DWord) raddr.data[3])<<16) + (((DWord) raddr.data[2])<<24);
        NetLibAddrINToA(AppNetRefnum, inetval, remoteip);
    } else {
        NetLibSocketClose(AppNetRefnum, sock, AppNetTimeout, &errno);
        localip[0] = (char) NULL;
        remoteip[0] = (char) NULL;
        ShowInfoMsg("");
        SetErrorMsg("NetLibSocketAddr failure.");
        return 0;
    }

    StrCopy(tempbuf, "Connected to ");
    StrCat(tempbuf, remoteip);
    ShowInfoMsg(tempbuf);

    return sock;
} 

/*
short writeall(int sock, char *str, short len)
{
    short i1, i2;
    i1 = 0;
    i2 = 0;
    TimGetTicks();
    while ((i1 = write(sock, &str[i2], len-i2)) > 0) {
        if ((i2 += i1) == len) break;
    }
    return i2;
}
*/

short writeall(int sock, struct ssq *sq, char *str, short len)
{
    short i1;
    i1 = MIN(SENDQSIZE-sq->sendqin, len);
    if (i1 <= 0) return 0;
    MemMove(&sq->sendq[sq->sendqin], str, i1);
    sq->sendqin += i1;
    return i1;
}

/*
 * This encodes with base-64 as it sticks data into the queue.  Make sure
 * you call it with 3 byte multiples, unless you want it padded -- like at
 * the end of a transmission.  Also this must be guaranteed to fit in the
 * sendq.. so you must've known to check if 4/3 * len will fit.
 */
short writeallb64(int sock, struct ssq *sq, char *str, short len)
{
    short i1, i2;
    unsigned long l1, l2, l3;
    i1 = MIN(SENDQSIZE-sq->sendqin, len);
    if (i1 <= 0) return 0;
    for (i2=0; i2 <= (len-3); i2=i2+3) {
        l1 = str[i2] & 0xff;
        l2 = str[i2+1] & 0xff;
        l3 = str[i2+2] & 0xff;
        l1 = (l1 << 16)|(l2 << 8)|l3;
        sq->sendq[sq->sendqin++] = base64[(l1 >> 18) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[(l1 >> 12) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[(l1 >> 6) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[l1 & 0x3f];
    }
    /* pad the remainder with = */
    switch(len % 3) {
    case 2:
        l1 = str[len-2] & 0xff;
        l2 = str[len-1] & 0xff;
        l1 = (l1 << 8)|l2;
        sq->sendq[sq->sendqin++] = base64[(l1 >> 10) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[(l1 >> 4) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[(l1 << 2) & 0x3c];
        sq->sendq[sq->sendqin++] = '=';
        break;
    case 1:
        l1 = str[len-1] & 0xff;
        sq->sendq[sq->sendqin++] = base64[(l1 >> 2) & 0x3f];
        sq->sendq[sq->sendqin++] = base64[(l1 << 4) & 0x30];
        sq->sendq[sq->sendqin++] = '=';
        sq->sendq[sq->sendqin++] = '=';
    }
    return len;
}
