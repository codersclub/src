/* $Id: pop.h,v 1.14 1999/11/01 01:48:33 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __POP_H__
#define __POP_H__

#define HDRFIELDS 10

enum Actions {
    actMATCH,
	actISWHITE,
    actWAITFOR,
	actGETNUM,
	actGETHEADER,
	actGETBODY
};

enum States {
    stOPEN, stOPEN2,
    stUSER, stUSER2,
    stPASS, stPASS2,
    stAPOP,
    stSTAT, stSTAT2, stSTAT3,
    stUIDL, stUIDL2, stUIDL3, stUIDL4, stUIDL5,
	stLIST, stLIST2, stLIST3, stLIST4, stLIST5,
	stRETR, stRETR2, stRETR3, stRETR4, stRETR5,
	stHEAD, stHEAD2, stHEAD3,
	stBODY,
    stDELE, stDELE2,
	stQUIT, stQUIT2,
    stERROR, stERROR2,
	stALLDONE
};

struct spopdata {
    short error;
	long msgnum;
    long msgstotal;
    long maxlines;
	char *msgrec;
	long msgreccnt;
	long msgrecsize;
	long msgrectotalcnt;
	long msgrectotalsize;
	VoidHand msgrechandle;
	UInt msgrecindex;
	char *patt, *pattb;
	char numbuf[11];
	short numbufcnt, hdrfield;
	long HDRoff[HDRFIELDS], HDRlen[HDRFIELDS];
	short parseAction, parseState, keepdata, skipdata;
    struct ssq sq;
    short isdotfound;
    short charsinline;
    short softret;
    short inquote;
    Boolean justhighmsg;
    Boolean onlylogin;
    short sendfilesnext;
};

long poptick(const char *new, short count, int clsock);
Boolean writeheaders(void);
Boolean addtorecord(char *str, short len);
Boolean beginnewrecord(void);
void endnewrecord(void);
void removenewrecord(void);

#endif
