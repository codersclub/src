/* $Id: gnugotmail.h,v 1.51 2000/12/07 15:24:10 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __GNUGOTMAIL_H__
#define __GNUGOTMAIL_H__

#include "sdkver.h"

/*
 * This flag (0 or 1) controls the ShowDebugMsg().. basically just showing
 * some extra messages on the screen.  Not extremely useful.
 */
#define DEBUGMSG 0

/*
 * These are X-Mailer and X-Url headers that are pasted for outgoing mail.
 */
#define XMAILER "GNU Got Mail 0.66 for PalmPilot"
#define XURL "http://rallypilot.sourceforge.net"

#define AppErrStrLen 32
#define ErrToString(err) SysErrString(err,AppErrStr,AppErrStrLen)

/*
 * MSGRECSIZE is the amount of memory to expand an Inbox record at one time.
 * This used to be small (2K) but I found that it would sneak into small
 * spaces and cause out of memory problems.  Also it must be large enough to
 * fit all of the header fields at one time (prob at least 1.5K).
 */
#define MSGRECSIZE 8192

/*
 * This needs to be big enough to hold the largest amount of chars that are
 * to be send at one time.  The sendq is completely flushed before the tick
 * functions (poptick(), smtptick()) are called each time.. so that they are
 * ensured to be able to fit their outgoing chars without checking.
 */
#define SENDQSIZE 256

/* function prototypes */

Boolean OpenPOP3(short whattodo);
void ClosePOP3(void);
Boolean OpenSMTP(short sendfiles);
void CloseSMTP(void);
Boolean OpenDatabases(void);
void CloseDatabases(void);
void ClearInbox(void);
void CheckPrefsR(void);
void ReadPrefsRec(void);
void WritePrefsRec(void);
void LoadPrefsFields(void);
void UnloadPrefsFields(Boolean save);
void LoadSMTPPrefsFields(void);
void UnloadSMTPPrefsFields(Boolean save);
void LoadPOPPrefsFields(void);
void UnloadPOPPrefsFields(Boolean save);
void LoadSendFilesPrefsFields(void);
Boolean UnloadSendFilesPrefsFields(Boolean save);
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags);

#endif
