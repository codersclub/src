// GNU Got Mail - An SMTP/POP3 client for the PalmPilot
// Copyright (C) 1999 Chris Faherty
//
// This program is free software; you can redistribute it and/or
// modify it under the terms of the GNU General Public License
// as published by the Free Software Foundation; either version 2
// of the License, or (at your option) any later version.
//
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with this program; if not, write to the Free Software
// Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

#define MainForm 100
#define PrefsForm 200
#define POPPrefsForm 300
#define POPPrefsPassForm 400
#define SMTPPrefsForm 500
#define AboutForm 600
#define SendFilesForm 700
#define RomIncompatibleAlert 800
#define SoftResetForm 850

#define PrefsTips 299
#define POPPrefsTips 499
#define SMTPPrefsTips 599
#define AboutTips 699
#define SendFilesTips 799

#define strID_pleasewait 1000

#define menuID_main 190
#define mitemID_prefs 191
#define mitemID_popprefs 192
#define mitemID_smtpprefs 193
#define mitemID_sendmail 194
#define mitemID_getmail 195
#define mitemID_highmsg 196
#define mitemID_about 197
#define mitemID_softreset 198

#define buttonID_sendmail 101
#define buttonID_getmail 102
#define buttonID_cancel 103
#define buttonID_clearinbox 104
// these must be consecutive
#define gadgetID_launch1 105
#define gadgetID_launch2 106
#define gadgetID_launch3 107
#define gadgetID_launch4 108
#define gadgetID_launch5 109
#define gadgetID_launch6 110

#define fieldID_prefsleavefree 201
#define checkboxID_prefsnoautooff 202
#define checkboxID_prefsreformat 203
#define checkboxID_prefsmakebeep 204
#define buttonID_prefsok 205
#define buttonID_prefscancel 206
// these must be consecutive
#define popuptriggerID_prefslaunch1 207
#define popuptriggerID_prefslaunch2 208
#define popuptriggerID_prefslaunch3 209
#define popuptriggerID_prefslaunch4 210
#define popuptriggerID_prefslaunch5 211
#define popuptriggerID_prefslaunch6 212
#define listID_prefslaunch1 213
#define listID_prefslaunch2 214
#define listID_prefslaunch3 215
#define listID_prefslaunch4 216
#define listID_prefslaunch5 217
#define listID_prefslaunch6 218

#define buttonID_popprefsok 301
#define buttonID_popprefscancel 302
#define fieldID_popserver 303
#define fieldID_popport 304
#define fieldID_popuser 305
#define triggerID_poppass 306
#define fieldID_popmaxlines 308
#define fieldID_popstartmsg 309
#define checkboxID_popdetectreset 310
#define checkboxID_popdeletemsg 311
#define checkboxID_popuseapop 312

#define fieldID_poppass 401
#define buttonID_popprefspassok 402
#define buttonID_popprefspasscancel 403

#define buttonID_smtpprefsok 501
#define buttonID_smtpprefscancel 502
#define fieldID_smtpserver 503
#define fieldID_smtpport 504
#define fieldID_smtpemail 505
#define fieldID_smtpname 506
#define fieldID_smtpaddbcc 507
#define checkboxID_smtpfiled 508
#define checkboxID_smtpfakepop 509

#define buttonID_aboutok 601

#define buttonID_sendfiles 701
#define fieldID_sendfilesemail 702
#define fieldID_sendfilessecret 703
#define checkboxID_sendfilesall 704
#define checkboxID_sendfilesfast 705
#define checkboxID_sendfilesclear 706
#define buttonID_sendfilesstart 707
#define buttonID_sendfilescancel 708
#define buttonID_sendfilesclearbits 709

#define buttonID_softresetyes 851
#define buttonID_softresetno 852
