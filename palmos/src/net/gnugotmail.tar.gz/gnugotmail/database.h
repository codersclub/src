/* $Id: database.h,v 1.1 1999/10/11 12:03:58 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __DATABASE_H__
#define __DATABASE_H__

enum filestates {
    filestOPEN,
    filestPRC,
    filestPRCHDR,
    filestPDB,
    filestPDBHDR,
    filestREAD,
    filestCLEARBITS,
    filestCLOSE,
    filestERROR,
    filestALLDONE
};

struct sfiledata {
    short parseState;
    ULong outoff;
    short outstage;
    LocalID dbID;
	LocalID appInfoID, sortInfoID, recordID;
	DmOpenRef dbP;
	Err err;
	UInt numRecords, dirtyRecords;
	ULong size;
	ULong offset;
	Int i;
	DatabaseHdrType hdr;
	BytePtr srcP;
	VoidHand resH;
	LocalID resChunkID;
	ULong resType;
	Int resID;
	RsrcEntryType resEntry;
	RecordEntryType recEntry;
	UInt attr;
	ULong uniqueID;
	VoidHand srcH;
	VoidHand appInfoH, sortInfoH;
	ULong appInfoSize, sortInfoSize;
	ULong totalBytes;
	ULong ticks;
	Word filler;
    ULong fullsize;
    unsigned char *recindexes;
};

long filetick(LocalID dbID, char *str, long len);

#endif
