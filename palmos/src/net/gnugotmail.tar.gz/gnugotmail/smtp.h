/* $Id: smtp.h,v 1.20 1999/09/22 21:17:49 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __SMTP_H__
#define __SMTP_H__

enum smtpactions {
    smtpactMATCH,
    smtpactISWHITE,
    smtpactWAITFOR,
	smtpactGETNUM,
	smtpactSENDBODY
};

enum smtpstates {
    smtpstOPEN, smtpstOPEN2, smtpstOPEN3, smtpstOPEN4,
    smtpstHELO, smtpstHELO2, smtpstHELO3, smtpstHELO4,
    smtpstMAIL, smtpstMAIL2,
    smtpstRCPT, smtpstRCPT2,
	smtpstHEAD, smtpstHEAD2, smtpstHEAD3,
    smtpstBODY, smtpstBODY2, smtpstBODY3, smtpstBODY4, smtpstBODY5,
    smtpstCLEARBITS,
    smtpstQUIT, smtpstQUIT2,
    smtpstERROR, smtpstERROR2,
    smtpstALLDONE
};

struct ssmtpdata {
    short error;
	long msgnum;
    long msgstotal;
	long msgrecsize;
    long rcptcount;
	VoidHand msgrechandle;
    char *msgrecptr;
	UInt msgrecindex;
	char *patt, *pattb;
	char numbuf[11];
	short numbufcnt;
	short parseAction, parseState, keepdata;
    char *rcptptr;
    long rcptmax;
    short rcptoff, rcptlen, rcptskip, rcpthdr;
    short hdrsubjectoff, hdrsubjectlen;
    short hdrtooff, hdrtolen;
    short hdrccoff, hdrcclen;
    short hdrbccoff, hdrbcclen;
	long msgoff, msglen, msgcnt;
    struct ssq sq;
    char genbuf[40];
    short genbufcnt;
    VoidHand sighandle;
    char *sigptr;
    Word siglen;
    short issignature;
    short outstage;
    ULong outoff;
    short inquote;
    short wrotenl;
    UInt fileindex, numfiles;
    LocalID dbID;
    short sendfiles;
    MailFlagsType mf;
};

long smtptick(const char *new, short count, int clsock);
Boolean buildrfc822(void);
Boolean getnextrcpt(void);
Boolean filerecord(DateTimeType *sentdate);
Boolean lockrecord(void);
void unlockrecord(void);
Boolean queryrecord(void);
Boolean locksignature(void);
void unlocksignature(void);

#endif
