#!/usr/bin/perl

# $Id: rim-font.pl,v 1.6 2000/04/14 18:39:51 chrisf Exp $

# rim-font font.pdb
#
# Extracts a FontHack style font from a pdb file and outputs to STDOUT a
# header file for a RIM pager.
#
# Copyright (C) 2000 Chris Faherty
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

$| = 1;

if ($#ARGV < 0) {
    print "Usage:\n";
    print " rim-font.pl font.pdb\n\n";
    exit;
}

# read in the original data file
if (-e $ARGV[0]) {
    &readfile($ARGV[0], *hdrtxt, *header, *appinfo, *sortinfo, *records,
        *recinfo, *recindexes, *delcount);
}

&writefile();

goto alldone;

sub readfile
{
local ($file, *hdrtxt, *header, *appinfo, *sortinfo, *records, *recinfo,
    *recindexes, *delcount) = @_;

# open the data files

open(FILE, "< $file") || die "$file can't open: $!";

@filestat = stat(FILE);

# grab the header

%header = ();
read(FILE, $hdrtxt, 78) == 78 || die "$file error reading header";
$header{'name'} = substr($hdrtxt, 0, 32);
$header{'attributes'} = unpack("n*", substr($hdrtxt, 32, 2));
$header{'version'} = unpack("n*", substr($hdrtxt, 34, 2));
$header{'createdate'} = unpack("N*", substr($hdrtxt, 36, 4));
$header{'modifydate'} = unpack("N*", substr($hdrtxt, 40, 4));
$header{'backupdate'} = unpack("N*", substr($hdrtxt, 44, 4));
$header{'modifynum'} = unpack("N*", substr($hdrtxt, 48, 4));
$header{'appinfoarea'} = unpack("N*", substr($hdrtxt, 52, 4));
$header{'sortinfoarea'} = unpack("N*", substr($hdrtxt, 56, 4));
$header{'databasetype'} = substr($hdrtxt, 60, 4);
$header{'creatorid'} = substr($hdrtxt, 64, 4);
$header{'uniqueidseed'} = unpack("N*", substr($hdrtxt, 68, 4));
$header{'nextrecordlistid'} = unpack("N*", substr($hdrtxt, 72, 4));
$header{'numrecs'} = unpack("n*", substr($hdrtxt, 76, 2));
# $header{'numrecs'} > 0 || die "must have at least 1 record";

# if it is a prc we return from here.
if ($header{'attributes'} & 0x0001) {
    close(FILE);
    return;
}

# get the record list

read(FILE, $recordlist, $header{'numrecs'}*8) ==
    $header{'numrecs'}*8 || die "$file error reading record list";
# Gotta find the first non-zero offset in the recordlist.  Normally
# it will be the first one, except that we cannot forget about
# deleted records having a zero offset because they lack a data chunk.
$firstrecoff = 0;
for ($i=0; $i < length($recordlist); $i=$i+8) {
    if (($firstrecoff = unpack("N*", substr($recordlist, $i, 4))) > 0) {
        last;
    }
}
$firstrecoff = $filestat[7] if $firstrecoff == 0;

# grab the appinfo

$appinfo = "";
if ($header{'appinfoarea'} > 0) {
    if ($header{'sortinfoarea'} > 0) {
        $len = $header{'sortinfoarea'}-$header{'appinfoarea'}
    } else {
        $len = $firstrecoff-$header{'appinfoarea'};
    }
    seek(FILE, $header{'appinfoarea'}, 0)
        || die "$file error seeking appinfo";
    read(FILE, $appinfo, $len) == $len || die "$file error reading appinfo";
}

# grab the sortinfo (not sure if it will ever exist)

$sortinfo = "";
if ($header{'sortinfoarea'} > 0) {
    $len = $firstrecoff-$header{'sortinfoarea'};
    seek(FILE, $header{'sortinfoarea'}, 0)
        || die "$file error seeking sortinfo";
    read(FILE, $sortinfo, $len) == $len ||
        die "$file error reading sortinfo";
}

# make the records array

@records = ();
@recinfo = ();
%recindexes = ();
$delcount = 0;

for ($i=0; $i < $header{'numrecs'}; $i++) {
    if ($i < ($header{'numrecs'}-1)) {
        $len = unpack("N*", substr($recordlist, ($i+1)*8, 4))-
            unpack("N*", substr($recordlist, $i*8, 4));
    } else {
        $len = $filestat[7]-unpack("N*", substr($recordlist, $i*8,
            4));
    }
    if ($len > 0) {
        seek(FILE, unpack("N*", substr($recordlist, $i*8, 4)), 0)
            || die "$file error seeking record #$i";
        read(FILE, $records[$i], $len) == $len
            || die "$file error reading record #$i";
    } else {
        $records[$i] = "";
    }
    $recinfo[$i] = substr($recordlist, $i*8, 8);
    # make a hash entry for later to make things quicker
    $recindexes{unpack("H*", substr($recinfo[$i], 5, 3))} = $i;
    $delcount++ if (ord(substr($recinfo[$i], 4, 1)) & 0x80);
}
close(FILE);

}

sub writefile
{
local ($i, $i2, $i3, $i4, $i5, $j, $t, $charcount, $height, $widthbytes,
    $firstChar, $lastChar, $fRectHeight, $x1, $x2, $x3, $bitmap, $maxwidth,
    $b1, $b2, $h, $h2, @widths);

for ($i=0; $i < $#records+1; $i++) {
    $j = 0;
#    print "fontType:    " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
    $firstChar = substr($records[$i], $j+1, 1);
#    print "firstChar:   " . unpack("C*", $firstChar) . "\n";
    $j += 2;
    $lastChar = substr($records[$i], $j+1, 1);
#    print "last Char:   " . unpack("C*", $lastChar) . "\n";
    $j += 2;
    $maxwidth = unpack("n*", substr($records[$i], $j, 2));
#    print "maxWidth:    " . $maxwidth . "\n";
    $j += 2;
#    print "kernMax:     " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
#    print "nDescent:    " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
#    print "fRectWidth:  " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
    $fRectHeight = substr($records[$i], $j, 2);
    $height = unpack("n*", $fRectHeight);
#    print "fRectHeight: " . unpack("n*", $fRectHeight) . "\n";
    $j += 2;
#    print "owTLoc:      " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
#    print "ascent:      " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
#    print "descent:     " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
#    print "leading:     " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
    $widthbytes = unpack("n*", substr($records[$i], $j, 2))*2;
#    print "rowWords:    " . unpack("n*", substr($records[$i], $j, 2)) . "\n";
    $j += 2;
    $bitmap = $j;
    $offsets = $j+($widthbytes*$height);
    
    $t = $ARGV[0];
    $t =~ s/([^\.])\.[pP][dD][bB]/$1/;
    $t =~ s/-/_/g;
    $b1 = $firstChar;
    $b1 = chr(0x20) if $firstChar lt 0x20;
    $b1 = $lastChar;
    $b1 = chr(0x7f) if $lastChar gt 0x7f;
    $b1 = $height-1;
    $charcount = ord($lastChar)-ord($firstChar)+1;

    print "const BYTE $t\_data\[\] = {\n";
    @widths = ();

    $i5 = 0;
    for ($i2=0; $i2 < $charcount; $i2++) {
        # nothing below 0x20
        next if ord($firstChar)+$i2 < 0x20;
        # nothing above 0x7f
        next if ord($firstChar)+$i2 > 0x7f;
        print "/* 0x" . unpack("H*", chr(ord($firstChar)+$i2)) . " */  ";

        $x1 = unpack("n*", substr($records[$i], $offsets+(2*$i2), 2));
        $x2 = unpack("n*", substr($records[$i], $offsets+(2*$i2)+2, 2))-$x1;
        $x3 = $x2;

        for ($i3=0; $i3 < $x2; $i3++) {
            $h = "";
            $h2 = "";
            for ($i4=0; $i4 < $height; $i4++) {
                $b1 = unpack("n*", substr($records[$i],
                    $bitmap+($widthbytes*$i4)+($x1/8), 2));
                $b2 = $x1 % 8;
                if (($b1 << ($i3+$b2)) & 0x8000) {
                    $h .= "1";
                } else {
                    $h .= "0";
                }
                if (length($h) == 8) {
                    $h2 .= "0x" . unpack("H*", pack("b*", $h)) . ",";
                    $h = "";
                }
            }
            if (length($h) > 0) {
                $h2 .= "0x" . unpack("H*", pack("b*", $h)) . ",";
            }
            # get rid of the last column if it is blank
            if (!(($i3 == ($x2-1)) && ($h2 == "0x00,0x00,"))) {
                print $h2;
            } else {
                $x3--;
            }
        }
        print "\n";
        $widths[$i5++] = $x3;

#        for ($i3=0; $i3 < $height; $i3++) {
#            print "[";
#            $b1 = unpack("n*", substr($records[$i],
#                $bitmap+($widthbytes*$i3)+($x1/8), 2));
#            $b2 = $x1 % 8;
#            for ($i4=0; $i4 < $x2; $i4++) {
#                if (($b1 << ($i4+$b2)) & 0x8000) {
#                    print "*";
#                } else {
#                    print " ";
#                }
#            }
#            print "]\n";
#        }

    }

    for ($i2=0; $i2 < length($t); $i2++) {
        print ord(substr($t, $i2, 1)) . ",";
    }
    print "0  /* FONT NAME = '$t' */\n};\n\n";

    print "const WORD $t\_width\[\] = {\n";
    $x3 = 0;
    for ($i2=0; $i2 < $#widths; $i2++) {
        print "$x3, ";
        $x3 += int(($height+7)/8)*$widths[$i2];
    }
    print "$x3\n};\n\n";

    print "const FontDefinition $t = {\n";
    print "/* Font flags */  0x81,\n";
    $b1 = chr(0x20) if $firstChar lt 0x20;
    print "/* First Char */  0x" . unpack("H*", $b1) . ",\n";
    $b1 = chr(0x7f) if $lastChar gt 0x7f;
    print "/* Last Char  */  0x" . unpack("H*", $b1) . ",\n";
    print "/* Max Height */  " . unpack("n*", $fRectHeight) . ",\n";
    $b1 = $height-1;
    print "/* Underline  */  " . "$b1,\n";
    print "/* Max Width  */  " . "$maxwidth,\n";
    print "                  (BYTE *) $t\_data,\n";
    print "                  (WORD *) $t\_width\n};\n";
    
}
}

alldone:
1;
