/* $Id: pop.c,v 1.45 1999/09/26 22:18:16 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/*
 * This is the incoming parser.  It is designed to maintain enough state
 * that only the new data needs to be read, and already stored data is
 * not re-read.
 */

#include <Pilot.h>
#include <System/DateTime.h>
#include "callback.h"
#include "gnugotmail.h"
#include "gnugotmailDB.h"
#include "common.h"
#include "sockets.h"
#include "global.h"
#include "md5.h"
#include "pop.h"

/* globals */

extern long RecordCount;
extern char tnum[];
extern char nullchar;
extern DmOpenRef MailDB;
extern struct sPrefsR *PrefsR;
extern Boolean PrefsRdirty;
extern long freeBytes;
extern long leavefree;
extern Word catInbox, catOutbox, catFiled;
extern DateTimeType dtnow;
extern ULong dtnowseconds;

struct spopdata popd;
char resCRLF[]="\r\n";
char resSPACE[]=" ";
char resOK[]="+OK";
char resERR[]="-ERR";
char resOKSPACE[]="+OK ";
char resDOTCRLF[]=".\r\n";
char resFROM[]="FROM: ";
char resTO[]="TO: ";
char resSUBJECT[]="SUBJECT: ";
char resDATE[]="DATE: ";
char resCC[]="CC: ";
char resBCC[]="BCC: ";
char resREPLYTO[]="REPLY-TO: ";
char resSENTTO[]="SENT-TO: ";
char resPRIORITY[]="PRIORITY: ";
char *hdrfields[]={resDATE, resSUBJECT, resFROM, resTO, resCC,
    resBCC, resREPLYTO, resSENTTO, resPRIORITY, resCRLF};
long erroff;
char lastchars[5];
char hextbl[]="0123456789abcdef";

long poptick(const char *new, short count, int clsock)
{
    short i1, i2, i3, i4, iswhite, oparseState;
    MD5_CTX context;
    unsigned char digest[16], temphex[32];

    i1 = 0;
    iswhite = 0;
    oparseState = popd.parseState;
    while ((i1 < count) || ((popd.parseAction == -1) &&
        (popd.parseState != oparseState)) ||
        (popd.parseState == stALLDONE)) {
        /*
         * Just a check because below I must insert a character here and
         * there and I want to make sure there is room in the msgrec.
         * Use MSGRECSIZE-1 to leave room for an extra character that I
         * may insert below.
         */
        if (popd.parseState != stALLDONE) {
            if ((popd.parseAction == actGETBODY) &&
                (popd.msgreccnt >= (MSGRECSIZE-1))) {
                if (!addtorecord(popd.msgrec, popd.msgreccnt)) {
                    popd.skipdata = 1;
                }
                popd.msgreccnt = 0;
            }
            if (popd.msgreccnt >= MSGRECSIZE) {
                ShowInfoMsg("");
                SetErrorMsg("msgrec exceeded!");
                popd.error = 1;
                popd.keepdata = 0;
                popd.parseAction = -1;
                popd.parseState = stALLDONE;
            }
        }
        oparseState = popd.parseState;
        /*
         * A little history of chars
         */
        lastchars[4] = lastchars[3];
        lastchars[3] = lastchars[2];
        lastchars[2] = lastchars[1];
        lastchars[1] = lastchars[0];
        lastchars[0] = *new;
        if (popd.keepdata) {
            /*
             * Here is the work-around test for the TOP command.
             * I need to look for a <CRLF>.<CRLF> to determine
             * if I have reached the end of an incoming message.
             *
             * We look for <CRLF>. and if we find it we set isdotfound=1.
             * Then when we look at the next character, if it is not a CR
             * we will set isdotfound=0.. elsewise we drop out of the action
             * clause.  Regardless, the . will not be stored; this is because
             * it will have either indicated the end of the message, or it is
             * an extra dot added by the POP server to escape a real dot.
             */
            if ((popd.parseAction == actGETBODY) &&
                (lastchars[2] == '\r') && (lastchars[1] == '\n') &&
                (*new == '.')) {
                i1++;
                new++; /* skip the character */
                popd.isdotfound = 1;
                /*
                 * We don't increment popd.msgrectotalcnt here because the
                 * extra dot isn't included in the message size.
                 */
                if (popd.msgrectotalcnt >= popd.msgrectotalsize) {
                    popd.parseAction = -1;
                } else continue;
            } else if ((popd.parseAction == actGETBODY) &&
                (popd.isdotfound == 1) && (*new == '\r')) {
                i1++;
                new++; /* skip the character */
                popd.isdotfound++;
                if (++popd.msgrectotalcnt >= popd.msgrectotalsize) {
                    popd.parseAction = -1;
                } else continue;
            } else if ((popd.parseAction == actGETBODY) &&
                (popd.isdotfound == 2) &&
                (*new == '\n')) {
                i1++;
                new++; /* skip the character */
                popd.isdotfound++;
                /*
                 * As you recall, the parseState should be set to
                 * stBODY so that is where it will end up.
                 */
                popd.parseAction = -1;
            } else if ((popd.parseAction == actGETBODY) &&
                (*new == '\r')) {
                /*
                 * If in the message body skip \r always.
                 */
            } else if ((PrefsR->Prefs.reformat == '1') &&
                (popd.parseAction == actGETBODY) && (*new == '\n')) {
                /*
                 * My feeble attempt at reformatting.  If there is a
                 * CRLFCRLF go ahead and keep it, otherwise convert it
                 * to a space.  Another guess is to see if the line is
                 * at least 60 characters.  If not, then I leave the
                 * hard return in there with the assumption that it is
                 * a table or something.
                 */
                if ((lastchars[3] == '\r') &&
                    (lastchars[2] == '\n') && (lastchars[1] == '\r')) {
                    /*
                     * Below we have determined whether to put a space
                     * or a hard return based on whether we need to
                     * justify the lines.
                     */
                    if (popd.softret) popd.msgrec[popd.msgreccnt++] = '\n';
                    /*
                     * At the top of this routine we flushed the msgrec
                     * buffer so I know I have enough room for some extra
                     * characters.
                     */
                    popd.msgrec[popd.msgreccnt++] = '\n';
                    popd.softret = 0;
                    popd.inquote = 0;
                } else if (popd.charsinline >= 60) {
                    popd.softret = 2;
                    popd.inquote++;
                } else {
                    popd.softret = 1;
                    popd.inquote = 0;
                }
                popd.charsinline = 0;
                popd.isdotfound = 0;
            } else if ((PrefsR->Prefs.reformat == '1') &&
                (popd.parseAction == actGETBODY) && (popd.inquote > 1) &&
                ((*new == '>') || (*new == ' '))) {
                /*
                 * Also skip whitespace with the quote prefix.
                 */
            } else if ((popd.parseAction != actGETBODY) && ((*new == '\r') ||
                (*new == '\n') || (*new == '\t'))) {
                /*
                 * If in the header or anywhere else don't store \r \n and \t.
                 */
            } else {
                /*
                 * Insert the soft return (space) before the new character.
                 */
                if (popd.parseAction == actGETBODY) {
                    if (popd.softret == 1) {
                        popd.msgrec[popd.msgreccnt++] = '\n';
                    } else if (popd.softret == 2) {
                        popd.msgrec[popd.msgreccnt++] = ' ';
                    }
                }
                popd.softret = 0;
                /*
                 * reset the inquote back until the next line
                 */
                if (popd.inquote > 1) popd.inquote = 1;
                if ((PrefsR->Prefs.reformat == '1') &&
                    (popd.parseAction == actGETBODY) && (popd.inquote == 0) &&
                    (lastchars[2] == '\r') && (lastchars[1] == '\n') &&
                    (*new == '>')) {
                    /*
                     * Quote character '>' reduction.  Keep the ones on the
                     * first line.
                     */
                    popd.inquote = 1;
                }
                popd.msgrec[popd.msgreccnt++] = *new;
                if (*new == '\n') popd.charsinline = 0; else popd.charsinline++;
                popd.isdotfound = 0;
            }
        }
        switch (popd.parseAction) {
        case actMATCH:
            if (*new != *popd.patt++) {
                /*
                 * Character not in pattern.
                 */
                popd.parseAction = -1;
                popd.parseState = stERROR;
                break;
            }
            popd.msgrectotalcnt++;
            i1++;
            new++;
            if (*popd.patt == (char) NULL) {
                /*
                 * End of pattern, must have found
                 * a match.
                 */
                popd.parseAction = -1;
                break;
            }
            continue;
        case actISWHITE:
            if ((*new == ' ') || (*new == '\t')) iswhite = 1;
            else iswhite = 0;
            popd.parseAction = -1;
            break;
        case actWAITFOR:
            i1++;
            popd.msgrectotalcnt++;
            if (*new++ == *popd.patt) {
                /*
                 * Found a char in pattern.
                 */
                popd.patt++;
            } else popd.patt = popd.pattb;
            if (*popd.patt == (char) NULL) {
                /*
                 * End of pattern, must have found
                 * a match.
                 */
                popd.parseAction = -1;
                break;
            }
            continue;
        case actGETNUM:
            if ((popd.numbufcnt < sizeof(popd.numbuf)) &&
                (*new >= '0') && (*new <= '9')) {
                /*
                 * Grab a digit and store it for
                 * later double dabble.
                 */
                *popd.patt++ = *new++;
                popd.numbufcnt++;
                i1++;
                popd.msgrectotalcnt++;
            } else {
                popd.numbuf[popd.numbufcnt] = (char) NULL;
                popd.parseAction = -1;
                break;
            }
            continue;
        case actGETHEADER:
            if (!popd.patt) {
                /*
                 * Header field candidate not found yet.
                 *
                 * FIXME:
                 *
                 * At the moment this will never find the
                 * Sent-to header because Subject is found
                 * first.
                 */
                for (i2=0; i2 < HDRFIELDS; i2++) {
                    if (WSPACE(UCASE(*new)) == 
                        hdrfields[i2][0]) {
                        popd.hdrfield = i2;
                        popd.patt = hdrfields[i2];
                        break;
                    }
                }
            }
            if (!popd.patt) {
                /*
                 * Not a necessary header field so lets
                 * get out of this and let the RETR state
                 * code control the skipping to the next
                 * line.
                 */
                popd.parseAction = -1;
                break;
            }
            if (WSPACE(UCASE(*new)) != *popd.patt++) {
                /*
                 * Character not in header candidate.
                 */
                popd.hdrfield = -1;
                popd.parseAction = -1;
                break;
            }
            i1++;
            new++;
            if (++popd.msgrectotalcnt >= popd.msgrectotalsize) {
                popd.parseAction = -1;
                break;
            }
            if (*popd.patt == (char) NULL) {
                /*
                 * End of pattern, must have found
                 * a header match (hdrfield).
                 */
                popd.parseAction = -1;
                break;
            }
            continue;
        case actGETBODY:
            i1++;
            new++;
            if (popd.msgreccnt == MSGRECSIZE) {
                if (!addtorecord(popd.msgrec, popd.msgreccnt)) {
                    popd.skipdata = 1;
                }
                popd.msgreccnt = 0;
            }
            if (++popd.msgrectotalcnt >= popd.msgrectotalsize) {
                popd.parseAction = -1;
                break;
            }
            if ((popd.msgrectotalcnt % 512) == 0) {
                ShowProgress(false, "", popd.msgrectotalcnt,
                    popd.msgrectotalsize, (popd.msgstotal-popd.msgnum)+1);
            }
            /*
             * If TOP test as we go just in case because we have promised
             * the user that we will leavefree memory.
             */
            if (popd.maxlines > 0) {
                /*
                 * We make a guess at how big a TOP message will be
                 * based on 100 chars per line.  Fudge by 1024 bytes.
                 */
                if ((freeBytes-1) <= leavefree) {
                    ShowInfoMsg("");
                    SetErrorMsg("memory limit reached.");
                    popd.error = 1;
                    popd.parseAction = -1;
                    popd.parseState = stALLDONE;
                    break;
                }
            }
            continue;
        }
        /*
         * Turn off the keepdata flag by default.  If we are
         * in a state which needs to keep data, it will reenable
         * this flag below.
         */
        popd.keepdata = 0;
        switch (popd.parseState) {
        case stOPEN:
            /*
             * We make sure to call this here because it loads the global
             * freeBytes value that we need below.
             */
            ShowStatusLine(false);
            popd.error = 0;
            popd.patt = resOK;
            popd.parseAction = actMATCH;
            popd.parseState = stOPEN2;
            popd.keepdata = 1; /* to store the greeting for APOP */
            break;
        case stOPEN2:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stUSER;
            popd.keepdata = 1; /* to store the greeting for APOP */
            break;
        case stUSER:
            if (PrefsR->POPPrefs.useapop == '1') {
                popd.parseState = stAPOP;
                break;
            }
            writeall(clsock, &popd.sq, "USER ", 5);
            writeall(clsock, &popd.sq, PrefsR->POPPrefs.user,
                StrLen(PrefsR->POPPrefs.user));
            writeall(clsock, &popd.sq, "\r\n", 2);
            popd.patt = resOK;
            popd.parseAction = actMATCH;
            popd.parseState = stUSER2;
            break;
        case stUSER2:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stPASS;
            break;
        case stPASS:
            writeall(clsock, &popd.sq, "PASS ", 5);
            writeall(clsock, &popd.sq, PrefsR->POPPrefs.pass,
                StrLen(PrefsR->POPPrefs.pass));
            writeall(clsock, &popd.sq, "\r\n", 2);
            popd.patt = resOK;
            popd.parseAction = actMATCH;
            popd.parseState = stPASS2;
            break;
        case stPASS2:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stSTAT;
            break;
        case stAPOP:
            /* Find the timestamp within the greeting */
            for (i2=0; i2 < popd.msgreccnt; i2++) {
                if (popd.msgrec[i2] == '<') {
                    for (i3=i2; i3 < popd.msgreccnt; i3++) {
                        if (popd.msgrec[i3] == '>') {
                            i4 = MIN(StrLen(PrefsR->POPPrefs.pass),
                                MSGRECSIZE-i3);
                            StrNCopy(&popd.msgrec[i3+1], PrefsR->POPPrefs.pass,
                                i4);
                            MD5Init(&context);
                            MD5Update(&context, &popd.msgrec[i2], (i3-i2)+i4+1);
                            MD5Final(digest, &context);
                            writeall(clsock, &popd.sq, "APOP ", 5);
                            writeall(clsock, &popd.sq, PrefsR->POPPrefs.user,
                                StrLen(PrefsR->POPPrefs.user));
                            writeall(clsock, &popd.sq, " ", 1);
                            /* convert to ascii-hex */
                            for (i2=0; i2 < sizeof(digest); i2++) {
                                temphex[i2*2] = hextbl[(digest[i2] >> 4) & 0xf];
                                temphex[i2*2+1] = hextbl[digest[i2] & 0xf];
                            }
                            writeall(clsock, &popd.sq, temphex,
                                sizeof(temphex));
                            writeall(clsock, &popd.sq, "\r\n", 2);
                            popd.patt = resOK;
                            popd.parseAction = actMATCH;
                            /* might as well use this state */
                            popd.parseState = stPASS2;
                            break;
                        }
                    }
                    break;
                }
            }
            /* see if the above was successful */
            if (popd.parseState == stPASS2) break;
            StrCopy(popd.msgrec, "APOP timestamp not found.");
            popd.parseState = stERROR2;
            break;
        case stSTAT:
            /*
             * We might only be doing this POP as a security feature for
             * the 'Fake POP' option required by some SMTP servers.
             */
            if (popd.onlylogin) {
                popd.parseState = stQUIT;
                break;
            }
            /*
             * The first thing we want to do is perform a STAT to see how
             * many messages exist.  I realize that the result of logging
             * in on most POP servers also produces a response which
             * includes this information.. but it is too painful to parse.
             */
            writeall(clsock, &popd.sq, "STAT\r\n", 6);
            popd.patt = resOKSPACE;
            popd.parseAction = actMATCH;
            popd.parseState = stSTAT2;
            break;
        case stSTAT2:
            popd.numbufcnt = 0;
            popd.patt = popd.numbuf;
            popd.parseAction = actGETNUM;
            popd.parseState = stSTAT3;
            break;
        case stSTAT3:
            /*
             * This is the number of messages reported by the STAT command.
             */
            popd.msgstotal = StrAToI(popd.numbuf);
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stUIDL;
            break;
        case stUIDL:
            /*
             * We're going to send a UIDL 1 to get the uidl for the first
             * message.  I use this to determine whether the mailbox has
             * been reset, by comparing this uidl with the one saved from
             * the last time.  I know, this is funky.. but it is very annoying
             * to not be able to reset the starting msg number because it
             * makes me have to go into the Pop Prefs 3 or 4 times/day.
             */
            if ((popd.msgstotal >= 1) &&
                (PrefsR->POPPrefs.detectreset == '1')) {
                writeall(clsock, &popd.sq, "UIDL 1\r\n", 8);
                popd.patt = resOKSPACE;
                popd.parseAction = actMATCH;
                popd.parseState = stUIDL2;
            } else {
                popd.parseState = stLIST;
            }
            break;
        case stUIDL2:
            /* skip past the message number, should always be 1 */
            popd.numbufcnt = 0;
            popd.patt = popd.numbuf;
            popd.parseAction = actGETNUM;
            popd.parseState = stUIDL3;
            break;
        case stUIDL3:
            /* skip past the next space */
            popd.patt = resSPACE;
            popd.parseAction = actMATCH;
            popd.parseState = stUIDL4;
            break;
        case stUIDL4:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stUIDL5;
            popd.msgreccnt = 0;
            popd.keepdata = 1; /* to start storing the UIDL */
            break;
        case stUIDL5:
            if (popd.msgreccnt <= sizeof(PrefsR->POPPrefs.firstuidl)-1) {
                /*
                 * See if the UIDL for message 1 matches.  If not, then
                 * reset the starting msg number to 1 because we can
                 * assume that someone else deleted the messages.
                 */
                if (StrNCompare(PrefsR->POPPrefs.firstuidl, popd.msgrec,
                    popd.msgreccnt) != 0) {
                    popd.msgnum = 1;
                    MemSet(PrefsR->POPPrefs.firstuidl,
                        sizeof(PrefsR->POPPrefs.firstuidl), 0);
                    MemMove(PrefsR->POPPrefs.firstuidl, popd.msgrec,
                        popd.msgreccnt);
                    PrefsRdirty = true;
                }
            }
            popd.parseState = stLIST;
            break;
        case stLIST:
            /*
             * If we are doing all of this just to get the highest message
             * number, then we will quit right now.  Otherwise we'll continue
             * and get the messages.  We made sure to do this after the UIDL
             * stuff because otherwise the mailbox reset detection would fire
             * off on the next mail check.
             */
            if (popd.justhighmsg) {
                popd.msgnum = popd.msgstotal+1;
                popd.parseState = stQUIT;
                break;
            }
            /*
             * Here we check to see if the msgnum > msgstotal.  If this is
             * the case, then we are to quit because we have retrieved all
             * of the messages.
             */
            if (popd.msgnum > popd.msgstotal) {
                popd.parseState = stQUIT;
                break;
            }
            writeall(clsock, &popd.sq, "LIST ", 5);
            i2 = numtotxt(popd.msgnum, tnum, false);
            writeall(clsock, &popd.sq, tnum, i2);
            writeall(clsock, &popd.sq, "\r\n", 2);
            popd.patt = resOKSPACE;
            popd.parseAction = actMATCH;
            popd.parseState = stLIST2;
            break;
        case stLIST2:
            popd.numbufcnt = 0;
            popd.isdotfound = 0;
            popd.patt = popd.numbuf;
            popd.parseAction = actGETNUM;
            popd.parseState = stLIST3;
            break;
        case stLIST3:
            popd.patt = resSPACE;
            popd.parseAction = actMATCH;
            popd.parseState = stLIST4;
            break;
        case stLIST4:
            popd.numbufcnt = 0;
            popd.patt = popd.numbuf;
            popd.parseAction = actGETNUM;
            popd.parseState = stLIST5;
            break;
        case stLIST5:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stRETR;
            break;
        case stRETR:
            popd.msgrectotalsize = StrAToI(popd.numbuf);
            popd.msgrectotalcnt = 0;
            ShowProgress(true, "", 0, 0, (popd.msgstotal-popd.msgnum)+1);
            /*
             * Here we test the wonderful leavefree value which will
             * hopefully prevent us all from bottoming out our memory
             * while we are in the can during the POP.
             */
            if (popd.maxlines > 0) {
                /*
                 * We make a guess at how big a TOP message will be
                 * based on 100 chars per line.
                 */
                if ((freeBytes-
                    (MIN(popd.maxlines*100, popd.msgrectotalsize))/1024) <=
                    leavefree) {
                    ShowInfoMsg("");
                    SetErrorMsg("memory limit reached.");
                    popd.error = 1;
                    popd.parseState = stQUIT;
                    break;
                }
            } else if ((freeBytes-(popd.msgrectotalsize/1024))
                <= leavefree) {
                ShowInfoMsg("");
                SetErrorMsg("memory limit reached.");
                popd.error = 1;
                popd.parseState = stQUIT;
                break;
            }
            for (i2=0; i2 < HDRFIELDS; i2++) {
                popd.HDRoff[i2] = -1;
                popd.HDRlen[i2] = 0;
            }
            /*
             * This is where we issue the message retrieval.  It will either
             * be a RETR (entire message), or a TOP if we want to only get
             * up to a certain number of message lines.  Note that TOP does
             * not include the header lines, so that a TOP 1 would retrieve
             * at most 1 line of the actual message body.
             *
             * I feel this is more efficient than counting bytes because there
             * is currently no way to proceed with message truncation using
             * the RETR command other than ignoring the remainder of the
             * message which would still waste time and batteries.
             *
             * The only annoying part about this is that the TOP response is
             * not guarranteed to return a byte count, therefore it cannot be
             * used to determine the message size.. since it may be smaller
             * than the LIST has indicated.  So in the case of a max lines
             * definition, I use the explicit <CRLF>.<CRLF> message end
             * indication.
             */
            if (popd.maxlines > 0) {
                writeall(clsock, &popd.sq, "TOP ", 4);
                i2 = numtotxt(popd.msgnum, tnum, false);
                writeall(clsock, &popd.sq, tnum, i2);
                writeall(clsock, &popd.sq, " ", 1);
                i2 = numtotxt(popd.maxlines, tnum, false);
                writeall(clsock, &popd.sq, tnum, i2);
                writeall(clsock, &popd.sq, "\r\n", 2);
            } else {
                writeall(clsock, &popd.sq, "RETR ", 5);
                i2 = numtotxt(popd.msgnum, tnum, false);
                writeall(clsock, &popd.sq, tnum, i2);
                writeall(clsock, &popd.sq, "\r\n", 2);
            }
            popd.msgreccnt = 0;
            popd.skipdata = 0;
            popd.hdrfield = -1;
            popd.patt = resOKSPACE;
            popd.parseAction = actMATCH;
            popd.parseState = stRETR3;
            break;
        case stRETR3:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stRETR4;
            break;
        case stRETR4:
            /*
             * This is set to zero here so that the counting is correct.
             */
            popd.msgrectotalcnt = 0;
            popd.patt = NULL;
            popd.parseAction = actGETHEADER;
            popd.parseState = stRETR5;
            break;
        case stRETR5:
            if ((popd.msgrectotalcnt % 512) == 0) {
                ShowProgress(false, "", popd.msgrectotalcnt,
                    popd.msgrectotalsize, (popd.msgstotal-popd.msgnum)+1);
            }
            /*
             * We come in here as each relevant
             * header is found, as well as when
             * the entire message is complete.
             *
             * As a header is found; being that we
             * are here and msgrectotalcnt<msgrectotalsize,
             * we mark this position and go to stHEAD which
             * will capture the relevant field contents and
             * then bounce back here.
             */
            if (popd.msgrectotalcnt < popd.msgrectotalsize) {
                if (popd.hdrfield == HDRFIELDS-1) {
                    /*
                     * This means that we matched the
                     * CRLF pattern which signifies
                     * the end of the header and the
                     * start of the body.
                     */
                    dtnowseconds = TimGetSeconds();
                    TimSecondsToDateTime(dtnowseconds, &dtnow);
                    if (!beginnewrecord()) {
                        /*
                         * Failed to create a new
                         * record so we will abort
                         * the parsing.
                         */
                        ShowInfoMsg("");
                        SetErrorMsg("beginnewrecord() failed.");
                        popd.error = 1;
                        popd.parseState = stALLDONE;
                        break;
                    }
                    /*
                     * DmWrite the headers and set the
                     * buffer to start receiving the
                     * body of the message.
                     */
                    if (!writeheaders()) {
                        /*
                         * Failed to write the headers so we will
                         * abort and remove the half-baked record.
                         */
                        ShowInfoMsg("");
                        SetErrorMsg("writeheaders() failed.");
                        popd.error = 1;
                        popd.parseState = stALLDONE;
                        break;
                    }
                    popd.msgreccnt = 0;
                    popd.keepdata = 1;
                    popd.charsinline = 0;
                    popd.softret = 0;
                    popd.inquote = 0;
                    popd.parseAction = actGETBODY;
                    popd.parseState = stBODY;
                    break;
                }
                popd.parseAction = actISWHITE;
                popd.parseState = stHEAD;
                break;
            }
            /*
             * In case the message ends while in the header we are still
             * prepared to go to the next msg.. after removing the half-
             * baked record.
             */
            removenewrecord();
            popd.patt = resDOTCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stLIST;
            popd.msgnum++;
            break;
        case stHEAD:
            /* Get past the whitespace */
            if (!iswhite) {
                popd.patt = resCRLF;
                popd.pattb = popd.patt;
                popd.parseAction = actWAITFOR;
                popd.parseState = stHEAD2;
                if (popd.hdrfield != -1) {
                    popd.HDRoff[popd.hdrfield] = popd.msgreccnt;
                    popd.keepdata = 1;
                }
                break;
            }
            /* The actISWHITE state doesn't increment these, so we need to */
            i1++;
            new++;
            popd.msgrectotalcnt++;
            popd.parseAction = actISWHITE;
            popd.parseState = stHEAD;
            break;
        case stHEAD2:
            /*
             * Grab the header and then go back to
             * stRETR5 to get some more.
             */
            if (popd.hdrfield >= 0) {
                /*
                 * The field doesn't stop until there
                 * is a CRLF followed by a non-whitespace
                 * character.
                 */
                popd.parseAction = actISWHITE;
                popd.parseState = stHEAD3;
                break;
            }
            popd.patt = NULL;
            popd.hdrfield = -1;
            popd.parseAction = actGETHEADER;
            popd.parseState = stRETR5;
            break;
        case stHEAD3:
            if (iswhite) {
                /*
                 * We are in the middle of a field and
                 * this line started with whitespace, so
                 * we need to continue for another line
                 * and check again.
                 */
                popd.patt = resCRLF;
                popd.pattb = popd.patt;
                popd.parseAction = actWAITFOR;
                popd.parseState = stHEAD2;
                popd.keepdata = 1;
                break;
            }
            /*
             * The entire field found.  Add a NULL to the end.
             */
            popd.HDRlen[popd.hdrfield] =
                popd.msgreccnt-popd.HDRoff[popd.hdrfield]+1;
            popd.msgrec[popd.msgreccnt++] = (char) NULL;
            popd.patt = NULL;
            popd.hdrfield = -1;
            popd.parseAction = actGETHEADER;
            popd.parseState = stRETR5;
            popd.keepdata = 0;
            break;
        case stBODY:
            /*
             * Finish up the remaining chunk of data,
             * if any.
             */
            if (popd.msgreccnt) {
                if (!addtorecord(popd.msgrec,
                    popd.msgreccnt)) {
                    popd.parseAction = -1;
                    popd.parseState = stALLDONE;
                    break;
                }
                popd.msgreccnt = 0;
            }
            /*
             * If we used TOP (as indicated by popd.maxlines>0) and the
             * termination dot was found, then we put a little indicator
             * to the user that the message was truncated.  This is because
             * if the dot was found it means that the POP server sent
             * a message that was shorter than the size it indicated in
             * the response to the TOP command.. therefore we tried to keep
             * reading and all we got was a dot.  This is normal because the
             * POP server only tells the total size of a message in the TOP
             * response, but what it actually sends you may be only a portion
             * depending on how many lines you asked for.
             */
            if ((popd.maxlines > 0) && (popd.isdotfound == 3)) {
                if (!addtorecord("\n/* TRUNCATED */\n", 17)) {
                    popd.parseAction = -1;
                    popd.parseState = stALLDONE;
                    break;
                }
            }
            ShowProgress(false, "", popd.msgrectotalcnt, popd.msgrectotalsize,
                (popd.msgstotal-popd.msgnum)+1);
            /*
             * Message body all complete so DmRelease the
             * record and update the status lines on the
             * screen.
             */
            endnewrecord();
            ShowStatusLine(false);
            /*
             * At this point we may have been using the TOP command which
             * doesn't have the luxury of a byte count.  The isdotfound
             * flag is tested to see if I need to WAITFOR one.  Actually
             * qpopper also can sometimes give the incorrect byte count and
             * so I check for a dot within the message to indicate the end.
             *
             * In the qpopper bug if you have a really long line in the
             * message, it will give a byte count +1 which makes you read
             * the message terminator dot by accident.  So we check if the
             * isdotfound is only in the first stage and set the pattern
             * to check for accordingly if there is only a CRLF remaining.
             */
            if (popd.isdotfound == 0) {
                popd.patt = resDOTCRLF;
                popd.pattb = popd.patt;
                popd.parseAction = actWAITFOR;
            } else if (popd.isdotfound == 1) {
                popd.patt = resDOTCRLF;
                popd.pattb = popd.patt;
                popd.parseAction = actWAITFOR;
            } else if (popd.isdotfound == 2) {
                /* it will be sitting on the \n w/ the qpopper bug */
                popd.patt = &resCRLF[1];
                popd.pattb = popd.patt;
                popd.parseAction = actWAITFOR;
            }
            popd.parseState = stDELE;
            break;
        case stDELE:
            /*
             * If the 'Delete messages from server' is checked then we
             * issue the DELE command.  This implies also that the starting
             * message number counter will NOT be incremented.. well it
             * doesn't do that here, but if you look at where it is called
             * you will see that I don't store the msgnum in the Prefs record.
             */
            if (PrefsR->POPPrefs.deletemsg == '1') {
                writeall(clsock, &popd.sq, "DELE ", 5);
                i2 = numtotxt(popd.msgnum, tnum, false);
                writeall(clsock, &popd.sq, tnum, i2);
                writeall(clsock, &popd.sq, "\r\n", 2);
                popd.patt = resOK;
                popd.parseAction = actMATCH;
                popd.parseState = stDELE2;
            } else {
                popd.parseState = stLIST;
                popd.msgnum++;
            }
            break;
        case stDELE2:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stLIST;
            popd.msgnum++;
            break;
        case stQUIT:
            writeall(clsock, &popd.sq, "QUIT\r\n", 6);
            popd.patt = resOK;
            popd.parseAction = actMATCH;
            popd.parseState = stQUIT2;
            break;
        case stQUIT2:
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stALLDONE;
            break;
        case stERROR:
            /*
             * Use the msgrec buffer to collect the
             * error line.
             */
            popd.msgreccnt = 0;
            popd.patt = resCRLF;
            popd.pattb = popd.patt;
            popd.parseAction = actWAITFOR;
            popd.parseState = stERROR2;
            popd.keepdata = 1;
            break;
        case stERROR2:
            /*
             * Show the error on the screen.
             */
            popd.msgrec[popd.msgreccnt] = (char) NULL;
            ShowInfoMsg("");
            SetErrorMsg(popd.msgrec);
            popd.error = 1;
            popd.parseState = stQUIT;
            break;
        case stALLDONE:
            if (popd.error) {
                removenewrecord();
                if (popd.error == 2) ShowInfoMsg("");
            } else {
                endnewrecord();
                ShowInfoMsg("");
            }
            ShowHeader("", "");
            return -1;
        }
    }
    return count;
}

Boolean writeheaders(void)
{
    short i1;
    DateType date;
    TimeType time;
    MailFlagsType mf;

    /*
     * The date field (from the incoming header) is special
     * because we want to store DateType, TimeType, & flags there
     * instead.
     */
    date.month = dtnow.month;
    date.day = dtnow.day;
    /*
     * This is pretty retarded, but the year member of DateType is
     * totally different than the one in DateTimeType.
     */
    date.year = dtnow.year-1904;
    time.hours = dtnow.hour;
    time.minutes = dtnow.minute;
    if (!addtorecord(((char *) &date), sizeof(DateType))) return false;
    if (!addtorecord(((char *) &time), sizeof(TimeType))) return false;
    mf.read = 0;
    mf.signature = 0;
    mf.confirmRead = 0;
    mf.confirmDelivery = 0;
    /*
     * The priority header is the 8th one.  See if the text is urgent and
     * set the flag accordingly.
     */
    if ((popd.HDRoff[8] != -1) &&
        (StrNCaselessCompare(&popd.msgrec[popd.HDRoff[8]], "urgent",
        MIN(popd.HDRlen[8], 6)) == 0)) {
        mf.priority = priorityHigh;
    } else mf.priority = priorityNormal;
    mf.addressing = sentTo;
    if (!addtorecord(((char *) &mf), sizeof(MailFlagsType))) return false;

    /*
     * Don't use the last two hdrfield entries.  They are the priority and
     * the crlf.
     */
    for (i1=1; i1 < HDRFIELDS-2; i1++) {
        if (popd.HDRoff[i1] == -1) {
            /*
             * Missing header, so just write a NULL.
             */
            if (!addtorecord(&nullchar, 1)) return false;
        } else {
            if (!addtorecord(&popd.msgrec[popd.HDRoff[i1]],
                popd.HDRlen[i1])) return false;
        }
    }
    ShowHeader(&popd.msgrec[popd.HDRoff[2]], &popd.msgrec[popd.HDRoff[1]]);
    return true;
}

Boolean addtorecord(char *str, short len)
{
    Ptr RecPointer;
    VoidHand newhand;
    if (popd.skipdata) return false;
/*    if (MemHandleResize(msgrechandle, msgrecsize+len)) return false; */
    if ((newhand = DmResizeRecord(MailDB, popd.msgrecindex,
        popd.msgrecsize+len)) == 0) {
        ShowInfoMsg("");
        SetErrorMsg("DmResizeRecord() failed.");
        popd.error = 1;
        return false;
    }
    popd.msgrechandle = newhand;
    RecPointer = MemHandleLock(popd.msgrechandle);
    DmWrite(RecPointer, popd.msgrecsize, str, len);
    MemPtrUnlock(RecPointer);
    popd.msgrecsize += len;
    return true;
}

/*
 * Called from the DmFindSortPosition() call to determine the insertion
 * point for a new record.  Normally r1 & r2 would be the same type but
 * it is easier to just compare the headers in the nature form that I have
 * available in msgrec.
 */
static Int Comparemsgrec(char *r1, struct sMailDB *r2,
    Int sortOrder, SortRecordInfoPtr info1, SortRecordInfoPtr info2,
    VoidHand appInfoH)
{
    Int result;
    DateType date1;
    TimeType time1;

    CALLBACK_PROLOGUE

    /*
     * We don't bother to look at r1 yet because it only has the headers.
     * The date that will be used is from the global dtnow variable.
     */
    date1.year = dtnow.year-1904;
    date1.month = dtnow.month;
    date1.day = dtnow.day;
    time1.hours = dtnow.hour;
    time1.minutes = dtnow.minute;
    if (DateToInt(date1) < DateToInt(r2->date)) {
        result = -1;
    } else if (DateToInt(date1) > DateToInt(r2->date)) {
        result = 1;
    } else if (TimeToInt(time1) < TimeToInt(r2->time)) {
        result = -1;
    } else {
        result = 1;
    }

    CALLBACK_EPILOGUE

    return result;
}

Boolean beginnewrecord(void)
{
    Ptr RecPointer;
    UInt attr;
    /*
     * We want the inbox record to be sorted according to the Show setting
     * in the Mail application.  The CompareMailRecords() is called to
     * compare two "records" although I am passing msgrec as the argument
     * because I don't have a record yet.  Also msgrec is not of the same
     * structure as a MailDB record but it shouldn't matter because I am
     * aware of this in CompareMailRecords().
     */
    popd.msgrecindex = DmFindSortPosition(MailDB, popd.msgrec, NULL,
        (DmComparF *) Comparemsgrec, sortByDateItem);
    popd.msgrecsize = 0;
    if ((popd.msgrechandle = DmNewRecord(MailDB, &popd.msgrecindex, 1))
        == 0) return false;
    DmReleaseRecord(MailDB, popd.msgrecindex, true);
    /*
     * Set the category of the new record to Inbox
     */
    DmRecordInfo(MailDB, popd.msgrecindex, &attr, NULL, NULL);
    attr &= ~dmRecAttrCategoryMask;
    attr |= catInbox;
    DmSetRecordInfo(MailDB, popd.msgrecindex, &attr, NULL);
    RecPointer = MemHandleLock(popd.msgrechandle);
    DmWrite(RecPointer, 0, &nullchar, 1);
    MemPtrUnlock(RecPointer);
    return true;
}

void endnewrecord(void)
{
    if (popd.msgrechandle) {
    /*
     * Make sure to terminate the messages body with TWO NULLs.  I thought
     * it was supposed to be one, but when I look at MailDB records created
     * by the Mail Application they all have an extra character at the end.
     */
    addtorecord(&nullchar, 1);
    addtorecord(&nullchar, 1);
/*        DmReleaseRecord(MailDB, msgrecindex, true); */
        RecordCount++;
        popd.msgrechandle = 0;
    }
}

void removenewrecord(void)
{
    if (popd.msgrechandle) {
        DmRemoveRecord(MailDB, popd.msgrecindex);
        popd.msgrechandle = 0;
    }    
}
