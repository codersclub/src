/* $Id: common.h,v 1.14 1999/09/22 21:17:47 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#ifndef __COMMONX_H__
#define __COMMONX_H__

#ifndef UCASE
#define UCASE(_a) ((_a)>='a' && (_a)<='z' ? (_a)-32:(_a))
#endif
#ifndef WSPACE
#define WSPACE(_a) ((_a)=='\t' ? ' ':(_a))
#endif
#ifndef	MAX
#define	MAX(_a,_b) ((_a)<(_b)?(_b):(_a))
#endif
#ifndef	MIN
#define	MIN(_a,_b) ((_a)<(_b)?(_a):(_b))
#endif
#ifndef	ABS
#define	ABS(_a) ((_a)>=0?(_a):-(_a))
#endif
#ifndef offsetof
#define offsetof(s,m) ((UInt)&(((s *)0)->m))
#endif

struct ssq {
    char *sendq;
    short sendqin, sendqout;
};

/* function prototypes */

short numtotxt(long num, char *txt, Boolean leadingzeroes);
void ShowStatusLine(Boolean force);
short DrawChars(char *str, Word len, SWord x, SWord y);
void DrawMsg(RectangleType r, char *str);
void ShowInfoMsg(char *str);
void SetErrorMsg(char *str);
void ShowErrorMsg(char *str);
void ShowHeader(char *from, char *subject);
void ShowFileInfo(short title, char *name);
Boolean DrawWrapped(RectangleType *r, char *str);
void ShowProgress(Boolean force, char *str, long num, long den, long left);
void ShowProgressBar(long num, long den);
void ShowButtons(short which);
void HideIcons(void);
void ShowIcons(void);
Boolean BuildIcons(void);

#endif
