/* $Id: smtp.c,v 1.66 2000/02/12 07:07:27 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/*
 * This sends the outbox via SMTP.  The parser is called intermittently
 * so that it can return to the event loop and respond to user events.
 */

#include <Pilot.h>
#include <System/DateTime.h>
#include <System/DataPrv.h>
#include "callback.h"
#include "gnugotmail.h"
#include "common.h"
#include "gnugotmailDB.h"
#include "sockets.h"
#include "smtp.h"
#include "database.h"

/* globals */

struct ssmtpdata smtpd;
extern struct sfiledata filed;
extern char tnum[];
extern char nullchar;
extern DmOpenRef MailDB;
extern struct sPrefsR *PrefsR;
extern Boolean PrefsRdirty;
extern char localip[];
extern Word catInbox, catOutbox, catFiled;

extern char resCRLF[];
extern char resOK[];
extern char resDOTCRLF[];
extern long OutboxCount;
extern DateTimeType dtnow;
extern ULong dtnowseconds;
char res220[]="220";
char res221SPACE[]="221 ";
char res250SPACE[]="250 ";
char res250[]="250";
char res354SPACE[]="354 ";
char dummystr[76];
char separator[]="--_=GNUGotMail-separator=_--";

/*
 * These were constants, but I needed to free up some code space.
 */
char xmailertxt[]=XMAILER;
char xurltxt[]=XURL;
char mimedisp[]="\r\nContent-Disposition: attachment\r\n";
char mimeenc[]="Content-Transfer-Encoding: base64\r\n";
char mimedesc[]="Content-Description: ";
char mimetype[]="\r\nContent-Type: application/x-pilot; ";
char mimever[]="MIME-Version: 1.0\r\n";
char mimecont1[]="Content-Type: multipart/mixed; \r\n";
char mimenote[]="This message is in MIME format.\r\n";
char mimecont2[]="\r\nContent-Type: text/plain; charset=us-ascii\r\n\r\n";

long smtptick(const char *new, short count, int clsock)
{
    short i1, i2, i3, i4, i5, avail, bytes, iswhite, oparseState;
    long l1;
    char *currptr;

    i1 = 0;
    iswhite = 0;
    oparseState = smtpd.parseState;
    while ((i1 < count) || ((smtpd.parseAction == -1) &&
        (smtpd.parseState != oparseState)) ||
        (smtpd.parseState == smtpstBODY) ||
        (smtpd.parseState == smtpstBODY2) ||
        (smtpd.parseState == smtpstCLEARBITS) ||
        (smtpd.parseState == smtpstHEAD3) ||
        (smtpd.parseState == smtpstALLDONE)) {
        oparseState = smtpd.parseState;
        if (smtpd.keepdata && (smtpd.genbufcnt < sizeof(smtpd.genbuf))) {
              smtpd.genbuf[smtpd.genbufcnt++] = *new;
        }
        switch (smtpd.parseAction) {
        case smtpactMATCH:
            if (*new != *smtpd.patt++) {
                /*
                 * Character not in pattern.
                 */
                smtpd.parseAction = -1;
                smtpd.parseState = smtpstERROR;
                break;
            }
            i1++;
            new++;
            if (*smtpd.patt == (char) NULL) {
                /*
                 * End of pattern, must have found
                 * a match.
                 */
                smtpd.parseAction = -1;
                break;
            }
            continue;
        case smtpactISWHITE:
            if ((*new == ' ') || (*new == '\t')) iswhite = 1;
            else iswhite = 0;
            smtpd.parseAction = -1;
            break;
        case smtpactWAITFOR:
            i1++;
            if (*new++ == *smtpd.patt) {
                /*
                 * Found a char in pattern.
                 */
                smtpd.patt++;
            } else smtpd.patt = smtpd.pattb;
            if (*smtpd.patt == (char) NULL) {
                /*
                 * End of pattern, must have found
                 * a match.
                 */
                smtpd.parseAction = -1;
                break;
            }
            continue;
        case smtpactGETNUM:
            if ((smtpd.numbufcnt < sizeof(smtpd.numbuf)) &&
                (*new >= '0') && (*new <= '9')) {
                /*
                 * Grab a digit and store it for
                 * later double dabble.
                 */
                *smtpd.patt++ = *new++;
                smtpd.numbufcnt++;
                i1++;
            } else {
                smtpd.numbuf[smtpd.numbufcnt] = (char) NULL;
                smtpd.parseAction = -1;
                break;
            }
            continue;
        }
        switch (smtpd.parseState) {
        case smtpstOPEN:
            smtpd.msgstotal = OutboxCount;
            smtpd.msgnum = 1;
            smtpd.msgrecindex = 0;
            smtpd.msgrechandle = 0;
            smtpd.msgrecptr = 0;
            smtpd.sigptr = 0;
            smtpd.error = 0;
            /*
             * Get the current date/time.  The Outbox messages don't have a
             * date/time yet so we will use the current time and when we are
             * done sending the message we will write this to the record as
             * we move the send message to the Filed category.
             */
            dtnowseconds = TimGetSeconds();
            TimSecondsToDateTime(dtnowseconds, &dtnow);
            smtpd.patt = res220;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstOPEN2;
            break;
        case smtpstOPEN2:
            /*
             * We use the ISWHITE action just to get to the next character
             * which will determine whether it is multi-line.
             */
            smtpd.parseAction = smtpactISWHITE;
            smtpd.parseState = smtpstOPEN3;
            break;
        case smtpstOPEN3:
            /*
             * The server response to the HELO command is multi-line.  The
             * hyphen following each 220 response indicates that there is
             * another line to follow.
             */
            if (*new == ' ') {
                smtpd.patt = resCRLF;
                smtpd.pattb = smtpd.patt;
                smtpd.parseAction = smtpactWAITFOR;
                smtpd.parseState = smtpstHELO;
                break;
            } else if (*new != '-') {
                /*
                 * Not a space or hyphen, then it must be an error.
                 */
                smtpd.patt = resCRLF;
                smtpd.pattb = smtpd.patt;
                smtpd.parseAction = smtpactWAITFOR;
                smtpd.parseState = smtpstERROR;
                break;
            }
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstOPEN4;
            break;
        case smtpstOPEN4:
            smtpd.patt = res220;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstOPEN2;
            break;
        case smtpstHELO:
            /*
             * The HELO command is optional but it helps to identify
             * your PalmPilot to the SMTP server.  We will give it the
             * IP.
             */
            writeall(clsock, &smtpd.sq, "HELO ", 5);
            writeall(clsock, &smtpd.sq, localip, StrLen(localip));
            writeall(clsock, &smtpd.sq, "\r\n", 2);
            smtpd.patt = res250;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstHELO2;
            break;
        case smtpstHELO2:
            /*
             * We use the ISWHITE action just to get to the next character
             * which will determine whether it is multi-line.
             */
            smtpd.parseAction = smtpactISWHITE;
            smtpd.parseState = smtpstHELO3;
            break;
        case smtpstHELO3:
            /*
             * The server response to the HELO command is multi-line.  The
             * hyphen following each 250 response indicates that there is
             * another line to follow.
             */
            if (*new == ' ') {
                smtpd.patt = resCRLF;
                smtpd.pattb = smtpd.patt;
                smtpd.parseAction = smtpactWAITFOR;
                smtpd.parseState = smtpstMAIL;
                break;
            } else if (*new != '-') {
                /*
                 * Not a space or hyphen, then it must be an error.
                 */
                smtpd.patt = resCRLF;
                smtpd.pattb = smtpd.patt;
                smtpd.parseAction = smtpactWAITFOR;
                smtpd.parseState = smtpstERROR;
                break;
            }
               smtpd.patt = resCRLF;
               smtpd.pattb = smtpd.patt;
               smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstHELO4;
            break;
        case smtpstHELO4:
            smtpd.patt = res250;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstHELO2;
            break;
        case smtpstMAIL:
            /*
             * Get an Outbox record, if any, to process.  If none, then go to
             * the quit state.
             */
            if (! (queryrecord() && lockrecord())) {
                smtpd.parseState = smtpstQUIT;
                break;
            }
            writeall(clsock, &smtpd.sq, "MAIL FROM:<", 11);
            writeall(clsock, &smtpd.sq, PrefsR->SMTPPrefs.email,
                StrLen(PrefsR->SMTPPrefs.email));
            writeall(clsock, &smtpd.sq, ">\r\n", 3);
            smtpd.rcptcount = 0;
            smtpd.patt = res250SPACE;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstMAIL2;
            break;
        case smtpstMAIL2:
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstRCPT;
            break;
        case smtpstRCPT:
            /*
             * If there are no more recipients, then go to the next state.
             */
            if (!getnextrcpt()) {
                /*
                 * If no recipients then quit.
                 */
                if (!smtpd.rcptcount) {
                    ShowInfoMsg("");
                    SetErrorMsg("No recipient.");
                    smtpd.error = 1;
                    smtpd.parseState = smtpstQUIT;
                    break;
                }
                writeall(clsock, &smtpd.sq, "DATA\r\n", 6);
                smtpd.patt = res354SPACE;
                smtpd.parseAction = smtpactMATCH;
                smtpd.parseState = smtpstHEAD;
                break;
            }
            /*
             * You can also get here if the recipients are blank or just have
             * whitespace characters.. indicated by smtpd.rcptlen == 0.  In
             * these cases we want to try again because the getnextrcpt()
             * will automatically advance through To:, Cc:, and Bcc:.
             *
             * In the event that it is blank we will keep calling it until it
             * is non-blank or it has failed.  Failure results in the same
             * treatment as above, which means that we progress to the next
             * state.
             *
             * A call to getnextrcpt() can result in a zero length or a string
             * of blanks which should both indicate to call again.  The first
             * char being a blank would indicate that the entire string is
             * blank as well because a recipient cannot start with blank.
             */
            i2 = 0;
            while ((smtpd.rcptlen == 0) ||
                (smtpd.rcptlen && (smtpd.rcptptr[smtpd.rcptoff] == ' '))) {
                if (!getnextrcpt()) {
                    /*
                     * If no recipients then quit.
                     */
                    if (!smtpd.rcptcount) {
                        ShowInfoMsg("");
                        SetErrorMsg("No recipient.");
                        smtpd.error = 1;
                        smtpd.parseState = smtpstQUIT;
                        i2 = 1;
                        break;
                    }
                    writeall(clsock, &smtpd.sq, "DATA\r\n", 6);
                    smtpd.patt = res354SPACE;
                    smtpd.parseAction = smtpactMATCH;
                    smtpd.parseState = smtpstHEAD;
                    i2 = 1;
                    break;
                }
            }
            /* a flag to indicate a break from above */
            if (i2) break;
            writeall(clsock, &smtpd.sq, "RCPT TO:<", 9);
            writeall(clsock, &smtpd.sq, &smtpd.rcptptr[smtpd.rcptoff],
                smtpd.rcptlen);
            writeall(clsock, &smtpd.sq, ">\r\n", 3);
            smtpd.rcptcount++;
            smtpd.patt = res250SPACE;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstRCPT2;
            break;
        case smtpstRCPT2:
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstRCPT;
            break;
        case smtpstHEAD:
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstHEAD2;
        case smtpstHEAD2:
            /*
             * Create an RFC822 compliant header from a message.
             */
            if (!buildrfc822()) {
                ShowInfoMsg("");
                SetErrorMsg("missing required rfc822 fields.");
                smtpd.error = 1;
                smtpd.parseState = smtpstQUIT;
                break;
            }
            /*
             * Fill the MailFlags.  I probably could've used it directly
             * within the record, but this is safer.
             */
            for (i2=0; i2 < sizeof(MailFlagsType); i2++) {
                ((char *) &smtpd.mf)[i2] =
                    smtpd.msgrecptr[i2+offsetof(struct sMailDB, flags)];
            }
            /*
             * I am a bit annoyed at this.  I spent forever trying to format
             * an RFC822 compliant Date: header and it turns out that it isn't
             * necessary when communicating to an SMTP server.  In fact it
             * creates a spurious date header which seems to confuse my desktop
             * email software.
             */
            /*
            DateToDOWDMFormat(dtnow.month, dtnow.day, dtnow.year,
                dfYMDLongWithSpace, smtpd.genbuf);
            writeall(clsock, &smtpd.sq, "Date: ", 6);
            */
            /* day of week
            writeall(clsock, &smtpd.sq, &smtpd.genbuf[0], 3);
            writeall(clsock, &smtpd.sq, ", ", 2);
            */
            /* day of month (need to determine if one-digit or two
            if (smtpd.genbuf[14] == '\0') t1 = 1; else t1 = 2;
            writeall(clsock, &smtpd.sq, &smtpd.genbuf[13], t1);
            writeall(clsock, &smtpd.sq, " ", 1);
            */
            /* month
            writeall(clsock, &smtpd.sq, &smtpd.genbuf[9], 4);
            */
            /* year
            writeall(clsock, &smtpd.sq, &smtpd.genbuf[4], 5);
            TimeToAscii(dtnow.hour, dtnow.minute, tfColon24h, smtpd.genbuf);
            */
            /* hh:mm:ss -0500
            writeall(clsock, &smtpd.sq, smtpd.genbuf, 5);
            */
            /*
             * DateToDOWDMFormat() doesn't include seconds but there is
             * a seconds member in the DateTimeType so we will use that
             * here to have accurate SMTP headers.
             */
            /*
            i2 = numtotxt(dtnow.second, tnum, true);
            tnum[5] = ':';
            writeall(clsock, &smtpd.sq, &tnum[5], 3);
            writeall(clsock, &smtpd.sq, " -0500", 6);
            writeall(clsock, &smtpd.sq, "\r\n", 2);
            */
            smtpd.outstage = 0;
            smtpd.outoff = 0;
            smtpd.parseState = smtpstHEAD3;
            break;
        case smtpstHEAD3:
            /*
             * I added this state because the headers can be larger than
             * the sendq so this lets me break it into chunks.  Remember
             * that this tick routine is only called when the sendq is
             * empty, so I can enqueue SENDQSIZE number of chars.
             *
             * Take a look at the while() and you will see that this is
             * one of the special states that can be called with a 0 count.
             *
             * In here we only break if we wrote something.  Otherwise we
             * continue down the if statements.  If we break without writing
             * something we will never be called back.  And if we don't break
             * after writing something we cannot guarantee that we have the
             * entire SENDQSIZE available.
             *
             * The do .. while(0) is just a trick I use to let me break out
             * if I want to.
             */
            do {
            if (smtpd.outstage == 0) {
                /* Will always fit */
                writeall(clsock, &smtpd.sq, "From: ", 6);
                writeall(clsock, &smtpd.sq, PrefsR->SMTPPrefs.name,
                    StrLen(PrefsR->SMTPPrefs.name));
                writeall(clsock, &smtpd.sq, " <", 2);
                writeall(clsock, &smtpd.sq, PrefsR->SMTPPrefs.email,
                    StrLen(PrefsR->SMTPPrefs.email));
                writeall(clsock, &smtpd.sq, ">\r\n", 3);
                smtpd.outstage++;
                break;
            }
            if (smtpd.outstage == 1) {
                /* Will always fit */
                smtpd.outstage++;
                smtpd.outoff = 0;
                if (smtpd.hdrsubjectlen) {
                    writeall(clsock, &smtpd.sq, "Subject: ", 9);
                    break;
                }
            }
            if (smtpd.outstage == 2) {
                /* May not fit so it is done in stages */
                if (smtpd.hdrsubjectlen) {
                    bytes = writeall(clsock, &smtpd.sq,
                        &smtpd.msgrecptr[smtpd.hdrsubjectoff+smtpd.outoff],
                        smtpd.hdrsubjectlen-smtpd.outoff);
                    if ((smtpd.outoff += bytes) < smtpd.hdrsubjectlen) break;
                    smtpd.outstage++;
                    break;
                }
                smtpd.outstage++;
            }
            if (smtpd.outstage == 3) {
                /* Will always fit */
                if (smtpd.hdrsubjectlen) writeall(clsock, &smtpd.sq, "\r\n", 2);
                if (smtpd.hdrtolen) writeall(clsock, &smtpd.sq, "To: ", 4);
                smtpd.outstage++;
                smtpd.outoff = 0;
                if (smtpd.hdrsubjectlen || smtpd.hdrtolen) break;
            }
            if (smtpd.outstage == 4) {
                /* May not fit so it is done in stages */
                if (smtpd.hdrtolen) {
                    bytes = 0;
                    i3 = 0;
                    for (i2=smtpd.outoff; (i2 < smtpd.hdrtolen); i2++) {
                        if (smtpd.msgrecptr[smtpd.hdrtooff+i2] == '\n') {
                            /* If we found a \n then we want to skip it. */
                            bytes++;
                            break;
                        }
                        if (smtpd.msgrecptr[smtpd.hdrtooff+i2] == ',') i3 = 1;
                    }
                    /* leave room in the sendq for a comma-space later. */
                    i4 = MIN(i2-smtpd.outoff, SENDQSIZE-2);
                    bytes += writeall(clsock, &smtpd.sq,
                        &smtpd.msgrecptr[smtpd.hdrtooff+smtpd.outoff], i4);
                    /*
                     * The built-in Mail application has a nasty habit of
                     * making a list of recipients with only a \n between
                     * them when you pick reply to all.  Above we took care
                     * of getting rid of the \n, but now we have to insert
                     * a comma if there wasn't already one there.
                     */
                    if ((smtpd.outoff += bytes) < smtpd.hdrtolen) {
                        if (!i3) writeall(clsock, &smtpd.sq, ", ", 2);
                        break;
                    }
                    smtpd.outstage++;
                    break;
                }
                smtpd.outstage++;
            }
            if (smtpd.outstage == 5) {
                /* Will always fit */
                if (smtpd.hdrtolen) writeall(clsock, &smtpd.sq, "\r\n", 2);
                if (smtpd.hdrcclen) writeall(clsock, &smtpd.sq, "Cc: ", 4);
                smtpd.outstage++;
                smtpd.outoff = 0;
                if (smtpd.hdrtolen || smtpd.hdrcclen) break;
            }
            if (smtpd.outstage == 6) {
                /* May not fit so it is done in stages */
                if (smtpd.hdrcclen) {
                    bytes = 0;
                    i3 = 0;
                    for (i2=smtpd.outoff; (i2 < smtpd.hdrcclen); i2++) {
                        if (smtpd.msgrecptr[smtpd.hdrccoff+i2] == '\n') {
                            /* If we found a \n then we want to skip it. */
                            bytes++;
                            break;
                        }
                        if (smtpd.msgrecptr[smtpd.hdrccoff+i2] == ',') i3 = 1;
                    }
                    /* leave room in the sendq for a comma-space later. */
                    i4 = MIN(i2-smtpd.outoff, SENDQSIZE-2);
                    bytes += writeall(clsock, &smtpd.sq,
                        &smtpd.msgrecptr[smtpd.hdrccoff+smtpd.outoff], i4);
                    /*
                     * The built-in Mail application has a nasty habit of
                     * making a list of recipients with only a \n between
                     * them when you pick reply to all.  Above we took care
                     * of getting rid of the \n, but now we have to insert
                     * a comma if there wasn't already one there.
                     */
                    if ((smtpd.outoff += bytes) < smtpd.hdrcclen) {
                        if (!i3) writeall(clsock, &smtpd.sq, ", ", 2);
                        break;
                    }
                    smtpd.outstage++;
                    break;
                }
                smtpd.outstage++;
            }
            if (smtpd.outstage == 7) {
                  if (smtpd.hdrcclen) writeall(clsock, &smtpd.sq, "\r\n", 2);
                /*
                 * I deliberately omit the Bcc from the rfc822 header because
                 * that is the most conservative approach.  Other approaches
                 * include the Bcc only to certain recipients (yourself for
                 * example).
                 *
                 * This doesn't mean that Bcc is disabled, it just means that
                 * the Bcc header isn't included in the message contents.
                 */
                /*
                 * These are the X headers
                 */
                writeall(clsock, &smtpd.sq, "X-Mailer: ", 10);
                writeall(clsock, &smtpd.sq, xmailertxt, sizeof(xmailertxt)-1);
                writeall(clsock, &smtpd.sq, "\r\n", 2);
                writeall(clsock, &smtpd.sq, "X-URL: ", 7);
                writeall(clsock, &smtpd.sq, xurltxt, sizeof(xurltxt)-1);
                writeall(clsock, &smtpd.sq, "\r\n", 2);
                /*
                 * This is a header used as a security check when I send
                 * files.  The user can set this secret and check it to
                 * verify that someone isn't trying to maliciously corrupt
                 * his sync repository.
                 */
                if (smtpd.sendfiles) {
                    writeall(clsock, &smtpd.sq, "X-GNUGotMail-Secret: ", 21);
                    writeall(clsock, &smtpd.sq, PrefsR->SendFilesPrefs.secret,
                        StrLen(PrefsR->SendFilesPrefs.secret));
                    writeall(clsock, &smtpd.sq, "\r\n", 2);
                }
                smtpd.outstage++;
                break;
            }
            if (smtpd.outstage == 8) {
                /* Will always fit */
                if (smtpd.mf.confirmDelivery) {
                    writeall(clsock, &smtpd.sq, "Return-Receipt-To: ", 19);
                    writeall(clsock, &smtpd.sq, PrefsR->SMTPPrefs.email,
                        StrLen(PrefsR->SMTPPrefs.email));
                    writeall(clsock, &smtpd.sq, "\r\n", 2);
                }
                if (smtpd.mf.confirmRead) {
                    writeall(clsock, &smtpd.sq, "X-Confirm-Reading-To: ", 22);
                    writeall(clsock, &smtpd.sq, PrefsR->SMTPPrefs.email,
                        StrLen(PrefsR->SMTPPrefs.email));
                    writeall(clsock, &smtpd.sq, "\r\n", 2);
                }
                /*
                 * Priority is kind of a weird header.  The only ones we know
                 * for sure are urgent and normal.  Low?  what's the point..
                 */
                switch (smtpd.mf.priority) {
                case priorityHigh:
                    writeall(clsock, &smtpd.sq, "Priority: urgent\r\n", 18);
                    break;
                }
                smtpd.outstage++;
                /* only break if we wrote something */
                if (smtpd.mf.confirmDelivery || smtpd.mf.confirmRead) break;
            }
            if (smtpd.outstage == 9) {
                /*
                 * MIME stuff if I'm sending an attachment.  If we aren't
                 * going to be sending an attachment, don't bother sending
                 * the message as MIME.
                 */
                if (smtpd.sendfiles) {
                    writeall(clsock, &smtpd.sq, mimever, sizeof(mimever)-1);
                    writeall(clsock, &smtpd.sq, mimecont1, sizeof(mimecont1)-1);
                    writeall(clsock, &smtpd.sq, " boundary=\"", 11);
                    writeall(clsock, &smtpd.sq, &separator[2],
                        sizeof(separator)-5);
                    writeall(clsock, &smtpd.sq, "\"\r\n", 3);
                }
                writeall(clsock, &smtpd.sq, "\r\n", 2);
                if (smtpd.sendfiles) {
                    writeall(clsock, &smtpd.sq, mimenote, sizeof(mimenote)-1);
                    writeall(clsock, &smtpd.sq, separator, sizeof(separator)-3);
                    writeall(clsock, &smtpd.sq, mimecont2, sizeof(mimecont2)-1);
                }
                smtpd.msgcnt = 0;
                smtpd.issignature = 0;
                smtpd.inquote = 0;
                /*
                 * Okay I am going to use a flag to let me know if we wrote
                 * a CRLF below.  If I don't terminate the last line of a
                 * message with CRLF, sometimes two messages in an mbox seem
                 * to run together.
                 */
                smtpd.wrotenl = 0;
                ShowProgress(true, "", smtpd.msgcnt, smtpd.msglen,
                    (smtpd.msgstotal-smtpd.msgnum)+1);
                smtpd.parseState = smtpstBODY;
                break;
            }
            } while (0);
            /*
             * Notice that we return here rather than break because we
             * must wait until the data is dequeued before we come back
             * into this state.
             */
            return count;
        case smtpstBODY:
            /*
             * Here is where I enqueue more data for transmission.  I have to
             * convert LF to CRLF in each instance and also make sure that
             * I don't have stray periods at the beginning of lines without
             * escaping them.
             *
             * I decided to just do a line at a time because then I can say
             * that the maximum amount I enqueue will be less exactly one
             * char (for the LF to CRLF conversion).  Actually, it has to
             * leave room for the extra stuff I will enqueue as the start
             * of a signature as well.. and also the <CRLF>.<CRLF> at the end.
             */
            avail = MIN(smtpd.msglen-smtpd.msgcnt,
                (SENDQSIZE-smtpd.sq.sendqin)-9);
            i2 = smtpd.msgcnt+smtpd.msgoff;
            /*
             * This needs some explanation.  Since I want to use this same
             * code for both the message body and the signature, I have to
             * use a flag, issignature, to let me know whether to refer to
             * the msgrecptr or the sigptr.
             */
            if (smtpd.issignature) currptr = smtpd.sigptr;
            else currptr = smtpd.msgrecptr;
            /*
             * Check if the first character is a period.  As you recall we
             * output line by line therefore a period at the beginning of a
             * line would always be here.
             */
            if (currptr[i2] == '.') {
                /*
                 * Remember the RFC821 rule regarding a . at the beginning of
                 * a line.  It must be preceeded by an extra period so that
                 * it isn't mistaken for the end of the message body.
                 */
                writeall(clsock, &smtpd.sq, ".", 1);
                /* Recompute the amount of avail send queue */
                avail = MIN(smtpd.msglen-smtpd.msgcnt,
                    (SENDQSIZE-smtpd.sq.sendqin)-9);
            }
            /*
             * Our attempt at prettifying message quoting by injecting
             * a quote prefix before each wrapped line of a paragraph.
             * This assumes that the message has been quote reduced
             * whereby the '>' char appears only at the beginning of
             * a paragraph.
             */
            if (PrefsR->Prefs.reformat == '1') {
                /* Word wrapping at 76 chars */
                avail = MIN(avail, 76);
                if (smtpd.inquote) {
                    avail = MIN(avail, 74);
                    writeall(clsock, &smtpd.sq, "> ", 2);
                }
                if (currptr[i2] == '>') {
                    smtpd.inquote = 1;
                }
                /*
                 * Skipping all spaces at the beginning of a line
                 * if the previous line was word wrapped.
                 */
                if (smtpd.wrotenl == 1) {
                    for (i4=0; (currptr[i2] == ' ') &&
                        ((smtpd.msgcnt+i4) < smtpd.msglen); i4++) i2++;
                    smtpd.msgcnt += i4;
                    avail = MIN(avail, smtpd.msglen-smtpd.msgcnt);
                }
            }
            i3 = i2;
            bytes = 0;
            for (i4=0; (i4 < avail) && (currptr[i2] != '\n'); i4++)
                i2++;
            if (currptr[i2] == '\n') {
                if (i4) bytes = writeall(clsock, &smtpd.sq,
                    &currptr[i3], i4);
                /* LF to CRLF */
                writeall(clsock, &smtpd.sq, "\r\n", 2);
                bytes++;
                smtpd.wrotenl = 2; /* 2 is a hard return */
                smtpd.inquote = 0;
            } else if (i4) {
                /*
                 * Try to fit complete words on the line.
                 */
                if (PrefsR->Prefs.reformat == '1') {
                    i5 = i4;
                    for (; (i4 > 0) && (currptr[i2] != ' ') &&
                        ((smtpd.msgcnt+i4) < smtpd.msglen); i4--) i2--;
                    /* allonebigword?  just write it then. */
                    if (i4 == 0) i4 = i5;
                }
                bytes += writeall(clsock, &smtpd.sq, &currptr[i3], i4);
                if (PrefsR->Prefs.reformat == '1') {
                    writeall(clsock, &smtpd.sq, "\r\n", 2);
                    smtpd.wrotenl = 1; /* 1 is a return I added due to wrap */
                }
            }
            smtpd.msgcnt += bytes;
            ShowProgress(false, "", smtpd.msgcnt, smtpd.msglen,
                (smtpd.msgstotal-smtpd.msgnum)+1);
            if (smtpd.msgcnt >= smtpd.msglen) {
                /*
                 * The signature must be sent now.  This is grabbed from
                 * the Mail Application's preferences.  I stay in this
                 * state until the signature is enqueued because it may
                 * have funky characters to escape as well, or it may be
                 * too large to fit in the sendq.  It is best to use this
                 * same code for outputting potentially large amounts of
                 * text.  i.e. signature.
                 *
                 * If it has just completed enqueueing a signature as indicated
                 * by issignature==1, then we will unlock the signature and
                 * terminate the message body.
                 */
                smtpd.inquote = 0;
                if (smtpd.issignature) {
                    unlocksignature();
                } else if ((smtpd.mf.signature) && locksignature()) {
                        smtpd.issignature = 1;
                        writeall(clsock, &smtpd.sq, "\r\n-- \r\n", 7);
                        smtpd.msgoff = 0;
                        smtpd.msgcnt = 0;
                        smtpd.msglen = smtpd.siglen;
                        return count;
                }
                /*
                 * Gotta make sure the last line has a CRLF after it.
                 */
                if (!smtpd.wrotenl) writeall(clsock, &smtpd.sq, "\r\n", 2);
                /*
                 * Check if I'm supposed to send the dirty records.  Right now
                 * I just look for "draino" in the subject.
                 */
                if (smtpd.sendfiles) {
                    smtpd.parseState = smtpstBODY2;
                    /*
                     * We'll need a full buffer if we're going to start sending
                     * an attachment so we'll return and wait until the last
                     * line is sent.
                     *
                     * Put an extra line before the attachment to make it
                     * look nicer.
                     *
                     */
                    writeall(clsock, &smtpd.sq, "\r\n", 2);
                    smtpd.msglen = 0;
                    smtpd.msgcnt = 0;
                    smtpd.fileindex = 0;
                    smtpd.numfiles = DmNumDatabases(0);
                    ShowFileInfo(0, "");
                    /*
                     * If this is the dummy record we added to the outbox
                     * we will go ahead and get rid of it now so that it
                     * isn't included in the attachment for MailDB.
                     */
                    filerecord(&dtnow);
                    unlockrecord();
                    return count;
                } else smtpd.parseState = smtpstBODY3;
                /*
                 * We left enough room for the <CRLF>.<CRLF> so we'll just
                 * break here and let it tack on to the remaining queue.
                 */
                break;
            }
            /*
             * Notice that we return here rather than break because we
             * must wait until the data is dequeued before we come back
             * into this state.
             */
            return count;
        case smtpstBODY2:
            /*
             * Sending a chunk of the attachment.  As each chunk is sent we
             * do a return from this function so that it can be dequeued.
             */
            if (smtpd.msglen == 0) {
                /*
                 * Get the next file name
                 */
                if ((smtpd.fileindex >= smtpd.numfiles) ||
                    (smtpd.dbID = DmGetDatabase(0, smtpd.fileindex)) == 0) {
                    /*
                     * No more files
                     */
                    smtpd.parseState = smtpstBODY3;
                    break;
                }
                /*
                 * Get the first chunk of file data.  We call this here also
                 * to have it fill in the header so we can grab the name.  We
                 * ask for zero bytes because we won't have enough in the
                 * sendq for a full base64 line anyhow.
                 */
                filed.parseState = filestOPEN;
                filetick(smtpd.dbID, dummystr, 0);
                if (filed.err) {
                    smtpd.parseState = smtpstBODY3;
                    break;
                }
                ShowFileInfo(1, filed.hdr.name);
                ShowProgress(true, "File:", 0, 0,
                    (smtpd.numfiles-smtpd.fileindex));
                if (filed.parseState == filestALLDONE) {
                    smtpd.fileindex++;
                    /* to make sure it initializes */
                    smtpd.msgcnt = 0;
                    smtpd.msglen = 0;
                    return count;
                }
                writeall(clsock, &smtpd.sq, separator, sizeof(separator)-3);
                writeall(clsock, &smtpd.sq, mimedisp, sizeof(mimedisp)-1);
                writeall(clsock, &smtpd.sq, mimeenc, sizeof(mimeenc)-1);
                writeall(clsock, &smtpd.sq, mimedesc, sizeof(mimedesc)-1);
                writeall(clsock, &smtpd.sq, filed.hdr.name,
                    StrLen(filed.hdr.name));
                if (filed.hdr.attributes & dmHdrAttrResDB)
                    writeall(clsock, &smtpd.sq, ".prc", 4);
                else writeall(clsock, &smtpd.sq, ".pdb", 4);
                writeall(clsock, &smtpd.sq, mimetype, sizeof(mimetype)-1);
                writeall(clsock, &smtpd.sq, "name=", 5);
                writeall(clsock, &smtpd.sq, filed.hdr.name,
                    StrLen(filed.hdr.name));
                if (filed.hdr.attributes & dmHdrAttrResDB)
                    writeall(clsock, &smtpd.sq, ".prc", 4);
                else writeall(clsock, &smtpd.sq, ".pdb", 4);
                writeall(clsock, &smtpd.sq, "; SizeOnDisk=", 13);
                i2 = numtotxt(filed.fullsize, tnum, false);
                writeall(clsock, &smtpd.sq, tnum, i2);
                writeall(clsock, &smtpd.sq, "\r\n\r\n", 4);
                smtpd.msglen = filed.fullsize;
                return count;
            } else {
                avail = MIN(57, (SENDQSIZE-smtpd.sq.sendqin)-7);
                bytes = filetick(smtpd.dbID, dummystr, avail);
                if (filed.err) {
                    smtpd.parseState = smtpstBODY3;
                    break;
                }
            }
            if (bytes) {
                l1 = smtpd.msgcnt;
                smtpd.msgcnt += writeallb64(clsock, &smtpd.sq, dummystr, bytes);
                writeall(clsock, &smtpd.sq, "\r\n", 2);
                if ((smtpd.msgcnt < smtpd.msglen) &&
                    (smtpd.msgcnt/512) != (l1/512)) {
                    ShowProgress(false, "File:", smtpd.msgcnt, smtpd.msglen,
                        (smtpd.numfiles-smtpd.fileindex));
                }
                return count;
            }
            writeall(clsock, &smtpd.sq, "\r\n", 2);
            ShowProgress(true, "File:", 0, 0,
                (smtpd.numfiles-smtpd.fileindex));
            /*
             * Continue in this same state with the next file.
             */
            smtpd.fileindex++;
            /* to make sure it initializes */
            smtpd.msgcnt = 0;
            smtpd.msglen = 0;
            return count;
        case smtpstBODY3:
            if (smtpd.sendfiles) {
                /*
                 * End of MIME
                 */
                writeall(clsock, &smtpd.sq, separator, sizeof(separator)-1);
                writeall(clsock, &smtpd.sq, "\r\n", 2);
            }
            /*
             * Print the final <CRLF>.<CRLF> that terminates the
             * DATA command.  I remember having a problem with an
             * MTA that sometimes needed a blank line before the dot.
             * If you follow the logic, you will see that this always
             * makes that blank line.
             */
            writeall(clsock, &smtpd.sq, "\r\n.\r\n", 5);
            smtpd.patt = res250SPACE;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstBODY4;
            break;
        case smtpstBODY4:
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstBODY5;
            break;
        case smtpstBODY5:
            /*
             * The message has been accepted, so now we deal with the Outbox
             * record.  Two things; fill in the date/time fields and move the
             * message into the Filed category.
             */
            if (!smtpd.sendfiles) {
                filerecord(&dtnow);
                unlockrecord();
            }
            smtpd.fileindex = 0;
            if (smtpd.sendfiles) ShowFileInfo(2, " ");
            smtpd.parseState = smtpstCLEARBITS;
            break;
        case smtpstCLEARBITS:
            /*
             * Now is the time to clear all of the dirty bits if we are
             * sending files.  It also updates the last backup date.  I
             * added the !clsock to test for the Clear Bits button being
             * pressed.
             */
            if ((smtpd.sendfiles && (PrefsR->SendFilesPrefs.clear == '1')) ||
                !clsock) {
                do {
                    if ((smtpd.fileindex >= smtpd.numfiles) ||
                        (smtpd.dbID = DmGetDatabase(0, smtpd.fileindex)) == 0) {
                        /*
                         * No more files
                         */
                        break;
                    }
                    filed.parseState = filestCLEARBITS;
                    filetick(smtpd.dbID, dummystr, 0);
/*                    ShowFileInfo(2, filed.hdr.name); */
                    ShowProgress(true, "File:", 0, 0,
                        (smtpd.numfiles-smtpd.fileindex));
                    smtpd.fileindex++;
                    return count;
                } while (0);
            }
            /*
             * I added this departure for when this state is called when the
             * user presses the Clear Bits button.  In this case we aren't
             * sending an email, we are just running through this state to
             * clear the bits.
             */
            if (!clsock) {
                smtpd.parseState = smtpstALLDONE;
                return count;
            }
            smtpd.msgnum++;
            /*
             * If we are sending files we only want to send this one message.
             */
            if (smtpd.sendfiles) smtpd.parseState = smtpstQUIT;
            else smtpd.parseState = smtpstMAIL;
            break;
        case smtpstQUIT:
            writeall(clsock, &smtpd.sq, "QUIT\r\n", 6);
            smtpd.patt = res221SPACE;
            smtpd.parseAction = smtpactMATCH;
            smtpd.parseState = smtpstQUIT2;
            break;
        case smtpstQUIT2:
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstALLDONE;
            break;
        case smtpstERROR:
            /*
             * Use the genbuf buffer to collect the
             * error line.
             */
            smtpd.patt = resCRLF;
            smtpd.pattb = smtpd.patt;
            smtpd.parseAction = smtpactWAITFOR;
            smtpd.parseState = smtpstERROR2;
            smtpd.genbufcnt = 0;
            smtpd.keepdata = 1;
            break;
        case smtpstERROR2:
            /*
             * Show the error on the screen.
             */
            smtpd.genbuf[smtpd.genbufcnt] = (char) NULL;
            ShowInfoMsg("");
            SetErrorMsg(smtpd.genbuf);
            smtpd.error = 1;
            smtpd.parseState = smtpstQUIT;
            break;
        case smtpstALLDONE:
            /*
             * Probably a user cancelled, so make sure whatever data file
             * was open gets closed by letting the filetick() finish.
             */
            if (smtpd.sendfiles && (filed.parseState != filestALLDONE)) {
                filed.parseState = filestCLOSE;
                filetick(smtpd.dbID, dummystr, 0);
            }
            /*
             * In case we missed these before.
             */
            unlockrecord();
            unlocksignature();
            if ((smtpd.error == 0) || (smtpd.error == 2)) ShowInfoMsg("");
            ShowHeader("", "");
            return -1;
        }
    }
    return count;
}

/*
 * Get the offsets of the fields necessary for an rfc822 compliant header.
 * If the "required" fields are not present, then return a false.
 */
Boolean buildrfc822(void)
{
    short i1;
    /*
     * 1st header (Subject:)
     */
    smtpd.hdrsubjectoff = offsetof(struct sMailDB, msg);
    for (i1=smtpd.hdrsubjectoff; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    smtpd.hdrsubjectlen = i1-smtpd.hdrsubjectoff;
    /*
     * Need to skip From: because it comes from the SMTP prefs.
     */
    for (i1++; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    /*
     * 3rd header (To:)
     */
    smtpd.hdrtooff = i1+1;
    for (i1=smtpd.hdrtooff; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    smtpd.hdrtolen = i1-smtpd.hdrtooff;
    /*
     * 4th header (Cc:)
     */
    smtpd.hdrccoff = i1+1;
    for (i1=smtpd.hdrccoff; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    smtpd.hdrcclen = i1-smtpd.hdrccoff;
    /*
     * 5th header (Bcc:)
     */
    smtpd.hdrbccoff = i1+1;
    for (i1=smtpd.hdrbccoff; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    smtpd.hdrbcclen = i1-smtpd.hdrbccoff;
    /*
     * Skip the next two (Reply-to:, Sent-to:)
     */
    for (i1++; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    for (i1++; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    /*
     * 8th section (Message body).  We know the message body is the last
     * item in the record and it is supposed to be terminated with a NULL.
     * However I have found that there is an extra byte at the end which I
     * have no idea what it is, so I am going to scan for a NULL to determine
     * the message body size.
     */
    smtpd.msgoff = ++i1;
    for (; (i1 < smtpd.msgrecsize) &&
        (smtpd.msgrecptr[i1] != '\0'); i1++);
    smtpd.msglen = i1-smtpd.msgoff;
    if (!smtpd.hdrtolen) return false;
    return true;
}
 
Boolean getnextrcpt(void)
{
    short i1, i2, atsignpos;
    Boolean inquote, nonblank;
    /*
     * If this is the first time this is called we must find the first
     * recipient.  Remember that the recipients are To:, Cc:, and Bcc: which
     * are 3rd, 4th, and 5th in the MailDB header (skipping the date, time,
     * and flags at the beginning).
     */
/*
 * DateType date;
 * TimeType time;
 * MailDBRecordFlags flags;
 * char subject[], from[], to[], cc[], bcc[], replyTo[], sentTo[], body[];
 */

    if (smtpd.rcptptr == 0) {
        smtpd.rcptptr = &smtpd.msgrecptr[offsetof(struct sMailDB, msg)];
        smtpd.rcptoff = 0;
        smtpd.rcptmax = smtpd.msgrecsize-offsetof(struct sMailDB, msg);
        /*
         * I have to get to the 3rd header (To:) within the message.
         */
        i2 = 1;
        i1 = smtpd.rcptoff;
        while ((i2 < 3) && (i1 < smtpd.rcptmax)) {
            for (; (i1 < smtpd.rcptmax) &&
                (smtpd.rcptptr[i1] != '\0'); i1++);
            if (i1 < smtpd.rcptmax) i1++;
            i2++;
        }
        smtpd.rcptoff = i1;
        smtpd.rcpthdr = i2;
    } else {
        /*
         * rcptskip lets us get to the next recipient.. it should take us
         * to the comma separator.
         */
        smtpd.rcptoff += smtpd.rcptskip;
        /*
         * Try and find the start of the next recipient address by skipping
         * over delimiter chars.
         */
        for (i1=smtpd.rcptoff; (i1 < smtpd.rcptmax) &&
            ((smtpd.rcptptr[i1] == ' ') ||
            (smtpd.rcptptr[i1] == ',') ||
            (smtpd.rcptptr[i1] == '>') ||
            (smtpd.rcptptr[i1] == '\n')); i1++);
        smtpd.rcptoff = i1;
    }
    /*
     * If I find that I've reached a NULL at the beginning of my recipient
     * search, I know that I have reached the end of a list.  I should then
     * proceed to the next list (To:, Cc:, Bcc:, etc).
     */
    if (smtpd.rcptptr[smtpd.rcptoff] == '\0') {
        /*
         * If we've reached the last of To:, Cc:, Bcc: then stop.
         */
        if ((smtpd.rcpthdr >= 5) || (smtpd.rcptoff >= smtpd.rcptmax)) {
            /*
             * If we have an additional Bcc defined we will return it.  Also
             * test if we already did this.  If so, return false and we are
             * all done.  We ignore this if we are in send files mode.
             */
            if ((smtpd.sendfiles) ||
                (smtpd.rcptptr == PrefsR->SMTPPrefs.addbcc)) return false;
            if (StrLen(PrefsR->SMTPPrefs.addbcc) > 0) {
                smtpd.rcptptr = PrefsR->SMTPPrefs.addbcc;
                smtpd.rcptoff = 0;
                smtpd.rcptlen = 0;
                smtpd.rcptskip = 0;
                smtpd.rcptmax = StrLen(PrefsR->SMTPPrefs.addbcc);
                return true;
            }
            return false;
        }
        /*
         * Otherwise we just advance past the NULL and continue.
         */
        smtpd.rcptoff++;
        smtpd.rcpthdr++;
    }
    /*
     * Nothing left in the field.  Return a zero length.  This indicates
     * the end of a field and the caller should call again to get the first
     * recipient of the next field.
     */
    if (smtpd.rcptptr[smtpd.rcptoff] == '\0') {
        smtpd.rcptlen = 0;
        smtpd.rcptskip = 0;
        return true;
    }
    /*
     * Find a user@domain email address.  We search for the @ within non-
     * quoted text.  This position is marked and then we extend to the
     * left and right.  rcptoff will be the start of the user@domain
     * address, rcptlen is the length of this, and rcptskip is the amount
     * to add to rcptoff to get to the delimeter.  To get rcptskip, we
     * have to read the text until we find the delimiter.
     */
    atsignpos = 0;
    inquote = false;
    nonblank = false;
    for (i1=smtpd.rcptoff; (i1 < smtpd.rcptmax) &&
        (smtpd.rcptptr[i1] != '\0') &&
        (smtpd.rcptptr[i1] != '\n') &&
        (inquote ||
        ((smtpd.rcptptr[i1] != ','))); i1++) {
        if ((smtpd.rcptptr[i1] == '"') || (smtpd.rcptptr[i1] == '(') ||
            (inquote && (smtpd.rcptptr[i1] == ')'))) inquote = !inquote;
        if (smtpd.rcptptr[i1] == '@') atsignpos = i1;
        if (smtpd.rcptptr[i1] != ' ') nonblank = true;
    }
    smtpd.rcptlen = i1-smtpd.rcptoff;
    smtpd.rcptskip = smtpd.rcptlen;
    /*
     * No @, then skip.
     */
    if (atsignpos == 0) return true;
    /*
     * Find the beginning of the user@domain address
     */
    for (i1=atsignpos; i1 > smtpd.rcptoff; i1--) {
        if ((smtpd.rcptptr[i1] == '<') || (smtpd.rcptptr[i1] == ' ')) {
            i1++;
            break;
        }
    }
    if ((smtpd.rcptptr[i1] == '<') || (smtpd.rcptptr[i1] == ' ')) i1++;
    smtpd.rcptskip -= (i1-smtpd.rcptoff);
    smtpd.rcptoff = i1;
    /*
     * Find the end of the user@domain address
     */
    for (i1=atsignpos; (i1 < (smtpd.rcptoff+smtpd.rcptskip)) &&
        (smtpd.rcptptr[i1] != '>') &&
        (smtpd.rcptptr[i1] != ' '); i1++);
    smtpd.rcptlen = i1-smtpd.rcptoff;
    return true;
}

/*
 * Called from the DmFindSortPosition() call to determine the insertion
 * point for a new record.
 */
static Int CompareMailRecords(struct sMailDB *r1, struct sMailDB *r2,
    Int sortOrder, SortRecordInfoPtr info1, SortRecordInfoPtr info2,
    VoidHand appInfoH)
{
    Int result;

    CALLBACK_PROLOGUE

    if (DateToInt(r1->date) < DateToInt(r2->date)) {
        result = 1;
    } else if (DateToInt(r1->date) > DateToInt(r2->date)) {
        result = -1;
    } else if (TimeToInt(r1->time) < TimeToInt(r2->time)) {
        result = 1;
    } else {
        result = -1;
    }

    CALLBACK_EPILOGUE

    return result;
}

/*
 * This is called once the Outbox message has been fully sent.  Here we
 * put a date/time into the Outbox record and then proceed to change the
 * category to Filed.
 */
Boolean filerecord(DateTimeType *sentdate)
{
    DateType date;
    TimeType time;
    UInt attr;
    UInt newindex;
    if (!smtpd.msgrecptr) return false;
    if (smtpd.sendfiles || (PrefsR->SMTPPrefs.filed != '1')) {
        /*
         * Don't move to Filed category.  We will remove the record
         * right after it is unlocked later.  This is also for that
         * dummy Outbox record I make when sending files.
         */
        return true;
    }
    date.month = sentdate->month;
    date.day = sentdate->day;
    /*
     * This is pretty retarded, but the year member of DateType is
     * totally different than the one in DateTimeType.
     */
    date.year = sentdate->year-1904;
    time.hours = sentdate->hour;
    time.minutes = sentdate->minute;
    DmWrite(smtpd.msgrecptr, offsetof(struct sMailDB, date), &date,
        sizeof(date));
    DmWrite(smtpd.msgrecptr, offsetof(struct sMailDB, time), &time,
        sizeof(time));
    DmRecordInfo(MailDB, smtpd.msgrecindex, &attr, NULL, NULL);
    attr &= ~dmRecAttrCategoryMask;
    attr |= catFiled;
    DmSetRecordInfo(MailDB, smtpd.msgrecindex, &attr, NULL);
    /*
     * Get the position to move the record to be sorted properly.
     */
    newindex = DmFindSortPosition(MailDB, smtpd.msgrecptr, NULL,
        (DmComparF *) CompareMailRecords, sortByDateItem);
    if (newindex != smtpd.msgrecindex) {
        unlockrecord();
        DmMoveRecord(MailDB, smtpd.msgrecindex, newindex);
        lockrecord();
    }
    return true;
}

/*
 * The Outbox record is locked during the time that it is being accessed.  This
 * includes all of the time that there are smtptick() calls while in states
 * that access the mail record.
 */
Boolean lockrecord(void)
{
    if ((smtpd.msgrecptr = MemHandleLock(smtpd.msgrechandle))) return true;
    return false;
}

void unlockrecord(void)
{
    if (smtpd.msgrecptr) {
        MemPtrUnlock(smtpd.msgrecptr);
        smtpd.msgrecptr = 0;
        if (smtpd.sendfiles || (PrefsR->SMTPPrefs.filed != '1')) {
            /*
             * Remove the outgoing record now if it hasn't been moved to the
             * Filed category.  Also this gets rid of the dummy record I
             * make for sending files.
             */
            DmRemoveRecord(MailDB, smtpd.msgrecindex);
        }
    }
}

/*
 * This is called successively for each Outbox record that is to be processed.
 *
 * The first call (when msgrechandle == 0) inits the vars and the following
 * calls just go to the next record within the Outbox category.
 */
Boolean queryrecord(void)
{
    long l1;
    UInt attr;
    DateType date;
    TimeType time;
    DateTimeType dt;
    MailFlagsType mf;
    char sixnulls[6]="\0\0\0\0\0\0";
    smtpd.rcptptr = 0;
    smtpd.rcptoff = 0;
    smtpd.rcptlen = 0;
    if (smtpd.msgrechandle == 0) {
        /*
         * Find the first record in the Outbox category.
         */
        smtpd.msgrecptr = 0;
    }
    /*
     * This is for the send files option.  Since I didn't want to rewrite
     * the smtptick(), I will create an outbox record in MailDB to hold
     * the information I need to create the message w/ attachments.
     *
     * It is only going to perform this one message send regardless of other
     * outbox records.
     */
    if (smtpd.sendfiles) {
        OutboxCount = 0;
        smtpd.msgrecindex = dmMaxRecordIndex;
        if ((smtpd.msgrechandle = DmNewRecord(MailDB, &smtpd.msgrecindex, 
            sizeof(struct sMailDB)+17+
            ((StrLen(PrefsR->SendFilesPrefs.email)+1)*2)+6))
            == 0) return false;
        /* temporarily lock it so I can write some headers */
        if ((smtpd.msgrecptr = MemHandleLock(smtpd.msgrechandle)) == 0)
            return false;
        TimSecondsToDateTime(TimGetSeconds(), &dt);
        date.month = dt.month;
        date.day = dt.day;
        date.year = dt.year-1904;
        time.hours = dt.hour;
        time.minutes = dt.minute;
        DmWrite(smtpd.msgrecptr, offsetof(struct sMailDB, date),
            ((char *) &date), sizeof(DateType));
        DmWrite(smtpd.msgrecptr, offsetof(struct sMailDB, time),
            ((char *) &time), sizeof(TimeType));
        mf.read = 0;
        mf.signature = 0;
        mf.confirmRead = 0;
        mf.confirmDelivery = 0;
        mf.priority = priorityNormal;
        mf.addressing = sentTo;
        DmWrite(smtpd.msgrecptr, offsetof(struct sMailDB, flags),
            ((char *) &mf), sizeof(MailFlagsType));
        l1 = offsetof(struct sMailDB, msg);
        /* subject */
        DmWrite(smtpd.msgrecptr, l1, "GNUGotMail files", 17);
        l1 += 17;
        /* from */
        DmWrite(smtpd.msgrecptr, l1, PrefsR->SendFilesPrefs.email,
            StrLen(PrefsR->SendFilesPrefs.email)+1);
        l1 += StrLen(PrefsR->SendFilesPrefs.email)+1;
        /* to */
        DmWrite(smtpd.msgrecptr, l1, PrefsR->SendFilesPrefs.email,
            StrLen(PrefsR->SendFilesPrefs.email)+1);
        l1 += StrLen(PrefsR->SendFilesPrefs.email)+1;
        DmWrite(smtpd.msgrecptr, l1, sixnulls, 6);
        MemPtrUnlock(smtpd.msgrecptr);
        smtpd.msgrecptr = 0;
        DmRecordInfo(MailDB, smtpd.msgrecindex, &attr, NULL, NULL);
        /* If it's dirty it will get sent.. don't want that to happen. */
        attr &= (~dmRecAttrCategoryMask & ~dmRecAttrDirty);
        attr |= catOutbox;
        DmSetRecordInfo(MailDB, smtpd.msgrecindex, &attr, NULL);
        smtpd.msgrecsize = MemHandleSize(smtpd.msgrechandle);
        /*
         * Normally I am doing a QueryRecord, but since I just did a
         * NewRecord I am going to release it and then query it so it
         * won't stay busy.
         */
        DmReleaseRecord(MailDB, smtpd.msgrecindex, false);
        if (!(smtpd.msgrechandle =
            DmQueryRecord(MailDB, smtpd.msgrecindex))) return false;
        return true;
    }
    if (OutboxCount == 0) return false;
    /*
     * Just as a safety measure in case we forgot to unlock the previous
     * record.
     */
   if (smtpd.msgrecptr) {
        MemPtrUnlock(smtpd.msgrecptr);
        smtpd.msgrecptr = 0;
    }
    /*
     * I am going to start at index 0 each time since when we filed the last
     * Outbox record we moved it into sorting position and changed its cat.
     */
    smtpd.msgrecindex = 0;
    if (!(smtpd.msgrechandle =
        DmQueryNextInCategory(MailDB, &smtpd.msgrecindex,
            catOutbox))) return false;
    smtpd.msgrecsize = MemHandleSize(smtpd.msgrechandle);
    OutboxCount--;
    return true;
}

/*
 * This gets the signature text from the Mail Application's preferences.
 */
Boolean locksignature(void)
{
    SWord version;
    /* Get the length of the signature. */
    smtpd.siglen = 0;
    smtpd.sigptr = 0;
    version = PrefGetAppPreferences(MailAppID, MailSigPrefID, NULL,
        &smtpd.siglen, true);
    if ((version == noPreferenceFound) || (!smtpd.siglen)) return false;
    /* Copy the signature. */
    if ((smtpd.sighandle = MemHandleNew(smtpd.siglen)) == 0) return false;
    smtpd.sigptr = MemHandleLock(smtpd.sighandle);
    PrefGetAppPreferences(MailAppID, MailSigPrefID, smtpd.sigptr, &smtpd.siglen,
        true);
    /* it has a NULL at the end, so we cut the length by one */
    if (smtpd.siglen) smtpd.siglen--;
    return true;
}

void unlocksignature(void)
{
    if (smtpd.sigptr) {
        MemPtrUnlock(smtpd.sigptr);
        smtpd.sigptr = 0;
        MemHandleFree(smtpd.sighandle);
    }
}
