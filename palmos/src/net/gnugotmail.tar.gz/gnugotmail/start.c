/*
 * This is part of a technique to allow more than 32K code segment size with
 * gcc.  As described by:
 * http://www.geocities.com/SiliconValley/Lab/9981/gcctech.htm
 */

extern unsigned long start();

unsigned long myStart()
{
    return start();
}
