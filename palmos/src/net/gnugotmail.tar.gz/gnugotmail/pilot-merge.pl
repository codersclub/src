#!/usr/bin/perl

# $Id: pilot-merge.pl,v 1.24 1999/05/18 06:16:47 chrisf Exp $

# pilot-merge orig.pdb in.pdb out.pdb
#
# This program makes the changes indicated in in.pdb to the orig.pdb and
# outputs a pdb file to out.pdb.  It writes a log to STDOUT.
#
# Copyright (C) 1999 Chris Faherty
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

$| = 1;

if ($#ARGV < 2) {
    print "Usage:\n";
    print " pilot-merge.pl orig.pdb in.pdb out.pdb\n\n";
    exit;
}

# open the output file
open(OUT, "> $ARGV[2]") || die "$ARGV[2] can't open: $!";

# read in the original data file
if (-e $ARGV[0]) {
    package first;
    &util'readfile($ARGV[0], *hdrtxt, *header, *appinfo, *sortinfo, *records,
        *recinfo, *recindexes, *delcount);
}

# read in the new data file
package second;
&util'readfile($ARGV[1], *hdrtxt, *header, *appinfo, *sortinfo, *records,
    *recinfo, *recindexes, *delcount);

# just replace it if it is a prc file
if ((-e $ARGV[1]) && ($header{'attributes'} & 0x0001)) {
    if (open(FILE, "< $ARGV[1]")) {
        while (<FILE>) {
            print main'OUT;
        }
        close(FILE);
    }
    print "$ARGV[0] replaced.\n";
    
} else {

    # If the creation dates are different we must assume the file is different.
    # So we just use the new file.  I do this the hard way because I need to
    # get rid of the special sortinfo I put in the file.  Also I may want to
    # wipe some attribute bits.
    if (!(-e $ARGV[0]) ||
        ($first'header{'createdate'} != $second'header{'createdate'})) {
        package main;
        if (!(-e $ARGV[0])) {
            print "$ARGV[0] added.\n";
        } else {
            print "$ARGV[0] replaced (creation dates differ).\n";
        }
        $first'hdrtxt = $second'hdrtxt;
        @first'header = @second'header;
        $first'appinfo = $second'appinfo;
        $first'sortinfo = $second'sortinfo;
        $first'delcount = $second'delcount;
        @first'records = @second'records;
        @first'recinfo = @second'recinfo;
        %first'recindexes = %second'recindexes;
        $second'hdrtxt = "";
        @second'header = ();
        $second'appinfo = "";
        $second'sortinfo = "";
        $second'delcount = 0;
        @second'records = ();
        @second'recinfo = ();
        %second'recindexes = ();
        &writefile();
    } else {
        print "$ARGV[0]\n";

        # and write out the merged data file
        package main;
        # I want the newer dates in the header, etc.
        $first'hdrtxt = $second'hdrtxt;
        &writefile();
    }

}

package main;
close(OUT);
goto alldone;

package util;

sub readfile
{
local ($file, *hdrtxt, *header, *appinfo, *sortinfo, *records, *recinfo,
    *recindexes, *delcount) = @_;

# open the data files

open(FILE, "< $file") || die "$file can't open: $!";

@filestat = stat(FILE);

# grab the header

%header = ();
read(FILE, $hdrtxt, 78) == 78 || die "$file error reading header";
$header{'name'} = substr($hdrtxt, 0, 32);
$header{'attributes'} = unpack("n*", substr($hdrtxt, 32, 2));
$header{'version'} = unpack("n*", substr($hdrtxt, 34, 2));
$header{'createdate'} = unpack("N*", substr($hdrtxt, 36, 4));
$header{'modifydate'} = unpack("N*", substr($hdrtxt, 40, 4));
$header{'backupdate'} = unpack("N*", substr($hdrtxt, 44, 4));
$header{'modifynum'} = unpack("N*", substr($hdrtxt, 48, 4));
$header{'appinfoarea'} = unpack("N*", substr($hdrtxt, 52, 4));
$header{'sortinfoarea'} = unpack("N*", substr($hdrtxt, 56, 4));
$header{'databasetype'} = substr($hdrtxt, 60, 4);
$header{'creatorid'} = substr($hdrtxt, 64, 4);
$header{'uniqueidseed'} = unpack("N*", substr($hdrtxt, 68, 4));
$header{'nextrecordlistid'} = unpack("N*", substr($hdrtxt, 72, 4));
$header{'numrecs'} = unpack("n*", substr($hdrtxt, 76, 2));
# $header{'numrecs'} > 0 || die "must have at least 1 record";

# if it is a prc we return from here.
if ($header{'attributes'} & 0x0001) {
    close(FILE);
    return;
}

# get the record list

read(FILE, $recordlist, $header{'numrecs'}*8) ==
    $header{'numrecs'}*8 || die "$file error reading record list";
# Gotta find the first non-zero offset in the recordlist.  Normally
# it will be the first one, except that we cannot forget about
# deleted records having a zero offset because they lack a data chunk.
$firstrecoff = 0;
for ($i=0; $i < length($recordlist); $i=$i+8) {
    if (($firstrecoff = unpack("N*", substr($recordlist, $i, 4))) > 0) {
        last;
    }
}
$firstrecoff = $filestat[7] if $firstrecoff == 0;

# grab the appinfo

$appinfo = "";
if ($header{'appinfoarea'} > 0) {
    if ($header{'sortinfoarea'} > 0) {
        $len = $header{'sortinfoarea'}-$header{'appinfoarea'}
    } else {
        $len = $firstrecoff-$header{'appinfoarea'};
    }
    seek(FILE, $header{'appinfoarea'}, 0)
        || die "$file error seeking appinfo";
    read(FILE, $appinfo, $len) == $len || die "$file error reading appinfo";
}

# grab the sortinfo (not sure if it will ever exist)

$sortinfo = "";
if ($header{'sortinfoarea'} > 0) {
    $len = $firstrecoff-$header{'sortinfoarea'};
    seek(FILE, $header{'sortinfoarea'}, 0)
        || die "$file error seeking sortinfo";
    read(FILE, $sortinfo, $len) == $len ||
        die "$file error reading sortinfo";
}

# make the records array

@records = ();
@recinfo = ();
%recindexes = ();
$delcount = 0;

for ($i=0; $i < $header{'numrecs'}; $i++) {
    if ($i < ($header{'numrecs'}-1)) {
        $len = unpack("N*", substr($recordlist, ($i+1)*8, 4))-
            unpack("N*", substr($recordlist, $i*8, 4));
    } else {
        $len = $filestat[7]-unpack("N*", substr($recordlist, $i*8,
            4));
    }
    if ($len > 0) {
        seek(FILE, unpack("N*", substr($recordlist, $i*8, 4)), 0)
            || die "$file error seeking record #$i";
        read(FILE, $records[$i], $len) == $len
            || die "$file error reading record #$i";
    } else {
        $records[$i] = "";
    }
    $recinfo[$i] = substr($recordlist, $i*8, 8);
    # make a hash entry for later to make things quicker
    $recindexes{unpack("H*", substr($recinfo[$i], 5, 3))} = $i;
    $delcount++ if (ord(substr($recinfo[$i], 4, 1)) & 0x80);
}
close(FILE);

}

package main;

sub writefile
{
local ($recoff);

$f1 = 0;

# Determine the number of records we will wind up with.  If we find a special
# sortinfo structure in the secondary, we will trust that.. except that we
# must realize that it also includes deleted records.

# we don't want a sortinfo in the resulting file
$first'sortinfo = "";

if (length($second'sortinfo) > 0) {
    $first'header{'numrecs'} = (length($second'sortinfo)/3)-$second'delcount;
} else {
    # We have to run through and create a suitable quasi-sortinfo structure
    # for the rest of this routine.  Since we don't know where to put new
    # records we will put them at the end.
    $second'sortinfo = "";
    for ($i=0; $i < @first'recinfo; $i++) {

        $recindexes{unpack("H*", substr($recinfo[$i], 5, 3))} = $i;

        if (exists $second'recindexes{unpack("H*",
            substr($first'recinfo[$i], 5, 3))}) {
            $i2 = $second'recindexes{unpack("H*",
                substr($first'recinfo[$i], 5, 3))};
            # we don't want deleted records
            if (!(ord(substr($second'recinfo[$i2], 4, 1)) & 0x80)) {
                $second'sortinfo .= substr($second'recinfo[$i2], 5, 3);
            }
        } else {
            # we don't want deleted records
            if (!(ord(substr($first'recinfo[$i], 4, 1)) & 0x80)) {
                $second'sortinfo .= substr($first'recinfo[$i], 5, 3);
            }
        }
    }
    # new records are ones that don't exist in the first set, and aren't
    # deleted.
    for ($i=0; $i < @second'recinfo; $i++) {
        if (!exists $first'recindexes{unpack("H*",
            substr($second'recinfo[$i], 5, 3))}) {
            if (!(ord(substr($second'recinfo[$i], 4, 1)) & 0x80)) {
                $second'sortinfo .= substr($second'recinfo[$i], 5, 3);
            }
        }
    }
    $first'header{'numrecs'} = length($second'sortinfo)/3;
}

# load appinfoarea

# checking for a dirty appinfo
if ($second'header{'attributes'} & 0x0004) {
    $first'appinfo = $second'appinfo;
    print " replaced appinfo\n";
}

if (length($first'appinfo) > 0) {
    $first'header{'appinfoarea'} = length($first'hdrtxt)+
        ($first'header{'numrecs'}*8)+2;
} else {
    $first'header{'appinfoarea'} = 0;
}

# load sortinfoarea (don't do this)

$first'header{'sortinfoarea'} = 0;

substr($first'hdrtxt, 52, 4) = pack("N*", $first'header{'appinfoarea'});
substr($first'hdrtxt, 56, 4) = pack("N*", $first'header{'sortinfoarea'});
substr($first'hdrtxt, 76, 2) = pack("n*", $first'header{'numrecs'});

# Here's were we pick apart my special sortinfo that I make in GNUGotMail.
# I use it to rewrite the records in proper order and dump the ones that
# don't exist any more.  Why bother?  Well, this let's me perform a fast
# sync on files that aren't designed for conduits.  Also it lets me recognize
# that records have changed sorting order; i.e. MemoPadDB records.

# record list

$recoff = length($first'hdrtxt)+(($first'header{'numrecs'})*8)+2+
    length($first'appinfo)+length($first'sortinfo);

# write the header

print main'OUT "$first'hdrtxt";

for ($i=0; $i < length($second'sortinfo); $i=$i+3) {
    if (exists $second'recindexes{unpack("H*",
        substr($second'sortinfo, $i, 3))}) {
        $i2 = $second'recindexes{unpack("H*", substr($second'sortinfo, $i, 3))};
        # skip deleted records
        if (!(ord(substr($second'recinfo[$i2], 4, 1)) & 0x80)) {
            print main'OUT pack("N*", $recoff);
            print main'OUT substr($second'recinfo[$i2], 4, 4);
            $recoff += length($second'records[$i2]);
        }
    } else {
        $i2 = $first'recindexes{unpack("H*", substr($second'sortinfo, $i, 3))};
        print main'OUT pack("N*", $recoff);
        print main'OUT substr($first'recinfo[$i2], 4, 4);
        $recoff += length($first'records[$i2]);
    }
}

# filler

print main'OUT "\0\0";

# appinfo

print main'OUT "$first'appinfo";

# sortinfo

#print main'OUT "$sortinfo";

# write records

$f1 = 0;
for ($i=0; $i < length($second'sortinfo); $i=$i+3) {
    if (exists $second'recindexes{unpack("H*",
        substr($second'sortinfo, $i, 3))}) {
        if (($f1 % 5) == 0) {
            if ($f1) {
                print "\n ";
            } else {
                print " ";
            }
        } else {
            print ", ";
        }
        $i2 = $second'recindexes{unpack("H*",
            substr($second'sortinfo, $i, 3))};
        # skip deleted records
        if (!(ord(substr($second'recinfo[$i2], 4, 1)) & 0x80)) {
            print main'OUT "$second'records[$i2]";
            if (exists $first'recindexes{unpack("H*",
                substr($second'sortinfo, $i, 3))}) {
                print "rep(0x" . unpack("H*",
                    substr($second'recinfo[$i2], 5, 3)) . ")";
            } else {
                print "add(0x" . unpack("H*",
                    substr($second'recinfo[$i2], 5, 3)) . ")";
            }
        } else {
            print "del(0x" . unpack("H*",
                substr($second'recinfo[$i2], 5, 3)) . ")";
        }
        $f1++;
    } else {
        $i2 = $first'recindexes{unpack("H*", substr($second'sortinfo, $i, 3))};
        print main'OUT "$first'records[$i2]";
    }
}

# Check for missing records.  These are records that have been removed because
# they don't show up in my special sortinfo, but they did exist in the
# repository.  This just shows that they were deleted in the report.

DEL:for ($i=0; $i < @first'recinfo; $i++) {
    for ($i2=0; $i2 < length($second'sortinfo); $i2=$i2+3) {
        if (unpack("H*", substr($second'sortinfo, $i2, 3)) eq
            unpack("H*", substr($first'recinfo[$i], 5, 3))) {
            next DEL;
        }
    }
    if (($f1 % 5) == 0) {
        if ($f1) {
            print "\n ";
        } else {
            print " ";
        }
    } else {
        print ", ";
    }
    print "del(0x" . unpack("H*",
        substr($first'recinfo[$i], 5, 3)) . ")";
    $f1++;
}

print "\n" if $f1;

}

alldone:
1;
