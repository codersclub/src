/* $Id: gnugotmailDB.h,v 1.17 2000/03/19 20:05:48 chrisf Exp $ */

/*
 * This is a structure of a MailDB record.
 *
 * DateType date;
 * TimeType time;
 * MailDBRecordFlags flags;
 * char subject[], from[], to[], cc[], bcc[], replyTo[], sentTo[], body[];
 *
 * And here is a structure with just the date, time, and flags so that I
 * can tell where the message data starts.
 */

#ifndef __GNUGOTMAILDB_H__
#define __GNUGOTMAILDB_H__

#define MailAppID 'mail'
#define MailDBType 'DATA'
#define MailSigPrefID 3

typedef struct {
        Word    read            : 1;
        Word    signature       : 1;
        Word    confirmRead     : 1;
        Word    confirmDelivery : 1;
        Word    priority        : 2; /* MailPriorityType */
        Word    addressing      : 2; /* MailAddressingType */
        Word    reserved        : 8;
} MailFlagsType;

typedef enum { priorityHigh, priorityNormal, priorityLow } MailPriorityType;
typedef enum { sentTo, sentCC, sentBCC } MailAddressingType;

struct sMailDB {
    DateType date;
    TimeType time;
    MailFlagsType flags;
    char *msg;
};

#define sortByDateItem      0
#define sortByFromItem      1
#define sortBySubjectItem   2

/* General Preferences */
struct sPrefs {
    char leavefree[6];
    char noautooff;
    char reformat;
    char makebeep;
    char launch[6][4];
};

/* The SMTP preferences */
struct sSMTPPrefs {
    char server[33];
    char port[6];
    char email[65];
    char name[65];
    char addbcc[65];
    char filed;
    char fakepop;
};

/* One of the POP preferences */
struct sPOPPrefs {
    char server[33];
    char port[6];
    char user[33];
    char pass[17];
    char maxlines[9];
    char startmsg[9];
    char detectreset;
    char deletemsg;
    char useapop;
    char firstuidl[81];
};

/* The Send Files preferences */
struct sSendFilesPrefs {
    char email[65];
    char secret[33];
    char all;
    char fast;
    char clear;
};

/*
 * A preferences record which consists of back-to-back
 * structures.  It also has a version char which starts at 1 to
 * allow testing for preferences migration in future versions.
 */
struct sPrefsR {
    char version;
    struct sPrefs Prefs;
    struct sSMTPPrefs SMTPPrefs;
    struct sPOPPrefs POPPrefs;
    struct sSendFilesPrefs SendFilesPrefs;
};

#endif
