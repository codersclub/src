#!/usr/bin/perl

# $Id: pilot-base64.pl,v 1.13 1999/05/12 02:43:17 chrisf Exp $

# pilot-base64
#
# This program decodes a MIME message that contains base64 encoded PalmPilot
# pdb files.  Then it calls pilot-merge to merge them into the files that
# are in the current directory.
#
# Copyright (C) 1999 Chris Faherty
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

$| = 1;

$temp = "tmp1.pdb";
$temp2 = "tmp2.pdb";

($sec, $min, $hour, $mday, $mon, $y, $wday, $yday, $isdst) = localtime(time);
$datestamp = sprintf("%.4d/%.2d/%.2d %.2d:%.2d:%.2d", $y+1900, $mon+1, $mday,
    $hour, $min, $sec);

print "****************************************************************\n";
print "$datestamp\n\n";

while (<>) {
    last if $boundary && /$boundary--/;
    $boundary = "--$1" if /boundary="(.[^"]*)"/;
    if ($boundary && /$boundary/) {
        # in MIME header
        while (<>) {
            last if /^$/;
            $name = $1 if /name=(.[^;]*);/;
        }
        # protect against .. and /
        next if !($name =~ /\.\.|\/|\s*\./);
        # fix unacceptable characters (= and /) in the filename
        $name =~ s/=/=3D/g;
        $name =~ s/\//=2F/g;
        next if !open(FILE, "> $temp");
        # in base64 data
        while (<>) {
            last if /^$/;
            tr#A-Za-z0-9+/##cd;                   # remove non-base64 chars
            tr#A-Za-z0-9+/# -_#;                  # convert to uuencoded format
            $len = pack("c", 32 + 0.75*length);   # compute length byte
            print FILE unpack("u", $len . $_);    # uudecode and print
        }
        close(FILE);
        $txt = `pilot-merge.pl "$name" "$temp" "$temp2" 2>&1`;
        if ($! != 0) {
            unlink("$name");
            rename("$temp2", "$name");
            unlink("$temp2");
        } else {
            unlink("$temp2");
        }
        unlink("$temp");
        print "$txt\n";
    }
}

1;
