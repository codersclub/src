#!/usr/bin/perl

# showtimes-base64
#
# This program decodes a MIME message that contains base64 encoded data
# files for the Showtimes program.  These files are sent in an email from
# this site; http://www.an.i-dentity.com/st.cgi
#
# Copyright (C) 1999 Chris Faherty
#
# This program is free software; you can redistribute it and/or
# modify it under the terms of the GNU General Public License
# as published by the Free Software Foundation; either version 2
# of the License, or (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

$| = 1;

while (<>) {
    last if $boundary && /$boundary--/;
    $boundary = "--$1" if /boundary="(.[^"]*)"/;
    if ($boundary && /$boundary/) {
        # in MIME header
        while (<>) {
            last if /^$/;
            $name = $1 if /name="(.[^"]*)"/;
        }
        # protect against .. and /
        next if !($name =~ /\.\.|\/|\s*\./);
        # fix unacceptable characters (= and /) in the filename
        $name =~ s/=/=3D/g;
        $name =~ s/\//=2F/g;
        next if !open(FILE, "> $name");
        # in base64 data
        while (<>) {
            last if /^$/;
            tr#A-Za-z0-9+/##cd;                   # remove non-base64 chars
            tr#A-Za-z0-9+/# -_#;                  # convert to uuencoded format
            $len = pack("c", 32 + 0.75*length);   # compute length byte
            print FILE unpack("u", $len . $_);    # uudecode and print
        }
        close(FILE);
        print "$name decoded.\n";
    }
}

1;
