/* $Id: common.c,v 1.34 2000/12/07 01:35:35 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <Pilot.h>
#include <System/DataPrv.h>
#include <System/AlarmMgr.h>
#include "gnugotmailRsc.h"
#include "gnugotmail.h"
#include "gnugotmailDB.h"
#include "common.h"

extern char tnum[];
extern char nullchar;
extern long RecordCount;
extern ULong Prefslaunch[];
extern short buttonsshown;
extern DmOpenRef MainDB;
extern VoidHand PrefsRecBHandle;
extern Char AppErrStr[AppErrStrLen];
extern struct sPrefsR *PrefsR;

/* globals */
long freeBytes;
long leavefree;
Boolean alarmnotify=true;

/*
 * txt must be at least char[9]
 */
short numtotxt(long num, char *txt, Boolean leadingzeroes)
{
    long i1, i2, base;
    i2 = 0;
    base = 10000000;
    while (base) {
        if ((i1 = num/base) || i2 || (base == 1) || leadingzeroes)
            txt[i2++] = (char) (i1+48);
        num -= i1*base;
        base /= 10;
    }
    txt[i2] = (char) NULL;
    return i2;
}

void ShowStatusLine(Boolean force)
{
    int i1, i2;
    UInt battv;
    RectangleType r, r2;
    FormPtr frm;
    static long oldfreeBytes=0;
    static UInt oldbattv=0;
    static long oldRecordCount=-1;

    if ((frm = FrmGetFormPtr(MainForm)) == 0) return;

    /*
     * Show the amount of free RAM.
     */
    MemCardInfo(0, NULL, NULL, NULL, NULL, NULL, NULL, &freeBytes);
    freeBytes -= 62000; /* fudge factor until I figure out the heap size */
    freeBytes /= 1024; /* Reduce to Kilobytes */
    r.topLeft.x = 1;
    r.topLeft.y = 17;
    r.extent.x = 54;
    r.extent.y = FntCharHeight()+2;
    if (force || (freeBytes != oldfreeBytes)) {
        i2 = DrawChars("Free:", 5, r.topLeft.x+4, r.topLeft.y+1);
        r2 = r;
        r2.topLeft.x += i2+4;
        r2.extent.x -= i2+4;
        WinEraseRectangle(&r2, 0);
        i1 = numtotxt(freeBytes, tnum, false);
        tnum[i1++] = 'K';
        i2 = FntCharsWidth(tnum, i1)+2;
        WinDrawChars(tnum, i1, r.topLeft.x+r.extent.x-i2, r.topLeft.y+1);
        WinDrawRectangleFrame(simpleFrame, &r);
        oldfreeBytes = freeBytes;
    }
    /*
     * Show the battery voltage.
     */
    r.topLeft.x += r.extent.x+1;
    r.extent.x = 50;
    #if SDK_VERSION < 30
    battv = SysBatteryInfo(false, NULL, NULL, NULL, NULL, NULL);
    #else
    battv = SysBatteryInfo(false, NULL, NULL, NULL, NULL, NULL, NULL);
    #endif
    if (force || (battv != oldbattv)) {
        i2 = DrawChars("Batt:", 5, r.topLeft.x+4, r.topLeft.y+1);
        r2 = r;
        r2.topLeft.x += i2+4;
        r2.extent.x -= i2+4;
        WinEraseRectangle(&r2, 0);
        i1 = numtotxt(battv, &tnum[1], false)+1;
        tnum[0] = tnum[1];
        tnum[1] = '.';
        tnum[i1++] = 'v';
        i2 = FntCharsWidth(tnum, i1)+2;
        WinDrawChars(tnum, i1, r.topLeft.x+r.extent.x-i2, r.topLeft.y+1);
        WinDrawRectangleFrame(simpleFrame, &r);
        oldbattv = battv;
    }
    /*
     * Show the inbox message count.
     */
    r.topLeft.x += r.extent.x+1;
    r.extent.x = 52;
    if (force || (RecordCount != oldRecordCount)) {
        i2 = DrawChars("Inbox:", 6, r.topLeft.x+4, r.topLeft.y+1);
        r2 = r;
        r2.topLeft.x += i2+4;
        r2.extent.x -= i2+4;
        WinEraseRectangle(&r2,0);
        i1 = numtotxt(RecordCount, tnum, false);
        i2 = FntCharsWidth(tnum, i1)+2;
        WinDrawChars(tnum, i1, r.topLeft.x+r.extent.x-i2, r.topLeft.y+1);
        WinDrawRectangleFrame(simpleFrame, &r);
        oldRecordCount = RecordCount;
    }
}

short DrawChars(char *str, Word len, SWord x, SWord y)
{
    WinDrawChars(str, len, x, y);
    return FntCharsWidth(str, len);
}

void DrawMsg(RectangleType r, char *str)
{
    int i1;
    r.extent.x = 160-r.topLeft.x-1;
    r.extent.y = FntCharHeight()+2;
    WinEraseRectangle(&r, 0);
    if ((i1 = StrLen(str)) > 0) {
        WinDrawChars(str, i1, r.topLeft.x+2, r.topLeft.y+1);
        WinDrawRectangleFrame(simpleFrame, &r);
    } else WinEraseRectangleFrame(simpleFrame, &r);
}

void ShowInfoMsg(char *str)
{
    RectangleType r;
    r.topLeft.x = 1;
    r.topLeft.y = 128;
    DrawMsg(r, str);
}

/*
 * Sometimes we want an error message to show later so we call this instead
 * of ShowErrorMsg().  Then at a later time we'll call ShowErrorMsg() with
 * a NULL parameter.
 */
void SetErrorMsg(char *str)
{
    StrNCopy(AppErrStr, str, AppErrStrLen-1);
}

void ShowErrorMsg(char *str)
{
    RectangleType r;
    r.topLeft.x = 1;
    r.topLeft.y = 116;
    if (str == NULL) DrawMsg(r, AppErrStr); else DrawMsg(r, str);
}

void ShowHeader(char *from, char *subject)
{
    RectangleType r, r2;
    Boolean f1;
    r.topLeft.x = 1;
    r.topLeft.y = 32;
    r.extent.x = 160-r.topLeft.x-1;
    r.extent.y = 115-r.topLeft.y-1;
    WinEraseRectangle(&r, 0);
    WinEraseRectangleFrame(simpleFrame, &r);
    r2 = r;
    r2.topLeft.x += 1;
    r2.topLeft.y += 1;
    r2.extent.x -= 2;
    r2.extent.y -= 2;
    f1 = DrawWrapped(&r2, from);
    f1 |= DrawWrapped(&r2, subject);
}

void ShowFileInfo(short title, char *name)
{
    RectangleType r, r2;
    r.topLeft.x = 1;
    r.topLeft.y = 32;
    r.extent.x = 160-r.topLeft.x-1;
    r.extent.y = 115-r.topLeft.y-1;
    if (title == 0) {
        WinEraseRectangle(&r, 0);
        WinEraseRectangleFrame(simpleFrame, &r);
    }
    r2 = r;
    r2.topLeft.x += 1;
    r2.topLeft.y += 1;
    r2.extent.x -= 2;
    r2.extent.y -= 2;
    if (StrLen(name)) {
        switch (title) {
        case 1:
            DrawWrapped(&r2, "Querying...");
            break;
        case 2:
            DrawWrapped(&r2, "Cleaning...");
        }
        r2.topLeft.y += FntCharHeight();
    } else {
        r2.topLeft.y += 2*FntCharHeight();
    }
    r = r2;
    r.extent.y = 115-r.topLeft.y-1;
    WinEraseRectangle(&r, 0);
    DrawWrapped(&r2, name);
}

Boolean DrawWrapped(RectangleType *r, char *str)
{
    Int textlen, textfit, width, newoff=0;
    Boolean fits=false;
    width = r->extent.x-2;
    if ((textlen = StrLen(str)) == 0) {
        r->topLeft.y += FntCharHeight(); 
        return false;
    }
    while (!fits) {
        textfit = textlen;
        FntCharsInWidth(str, &width, &textfit, &fits);
        WinDrawChars(&str[newoff], textfit, r->topLeft.x+2,
            r->topLeft.y);
        newoff += textfit;
        textlen -= textfit;
        r->topLeft.y += FntCharHeight(); 
    }
    return true;
}   

void ShowProgress(Boolean force, char *str, long num, long den, long left)
{
    RectangleType r, r2;
    int i1, i2;
    static long oldnum=0, oldden=0, oldleft=0;
    r.topLeft.x = 1;
    r.topLeft.y = 147;
    r.extent.x = 120-r.topLeft.x-1;
    r.extent.y = 12;
    if ((num == 0) && (left == 0)) {
        WinEraseRectangle(&r, 0);
        if (den == 0) {
            WinEraseRectangleFrame(simpleFrame, &r);
            return;
        }
    } else {
        r.extent.x = -4;
        /*
         * Number of messages remaining
         */
        r.topLeft.x += r.extent.x+4;
        r.extent.x = 42;
        r2 = r;
        r2.topLeft.x++;
        r2.topLeft.y++;
        r2.extent.x -= 2;
        r2.extent.y -= 2;
        if (force || (left != oldleft)) {
            if ((i1 = StrLen(str)) == 0)
                i2 = DrawChars("Msg:", 4, r.topLeft.x+4, r.topLeft.y+1);
            else i2 = DrawChars(str, i1, r.topLeft.x+4, r.topLeft.y+1);
            r2 = r;
            r2.topLeft.x += i2+4;
            r2.extent.x -= i2+4;
            WinEraseRectangle(&r2, 0);
            i1 = numtotxt(left, tnum, false);
            i2 = FntCharsWidth(tnum, i1)+2;
            WinDrawChars(tnum, i1, r.topLeft.x+r.extent.x-i2, r.topLeft.y+1);
            WinDrawRectangleFrame(simpleFrame, &r);
            oldleft = left;
        }
        /*
         * Number of bytes remaining
         */
        r.topLeft.x += r.extent.x+4;
        r.extent.x = 70;
        r2 = r;
        r2.topLeft.x++;
        r2.topLeft.y++;
        r2.extent.x -= 2;
        r2.extent.y -= 2;
        if (force || (num != oldnum) || (den != oldden)) {
            i2 = DrawChars("Bytes:", 6, r.topLeft.x+4, r.topLeft.y+1);
            r2 = r;
            r2.topLeft.x += i2+4;
            r2.extent.x -= i2+4;
            WinEraseRectangle(&r2, 0);
            if (!((num == 0) && (den == 0))) {
                /*
                 * Don't draw a zero if the den is zero.  I think it looks
                 * better.
                 */
                i1 = numtotxt(den-num, tnum, false);
                i2 = FntCharsWidth(tnum, i1)+2;
                WinDrawChars(tnum, i1, r.topLeft.x+r.extent.x-i2, r.topLeft.y+1);
            }
            WinDrawRectangleFrame(simpleFrame, &r);
            oldnum = num;
            oldden = den;
        }
    }
}

void ShowProgressBar(long num, long den)
{
    RectangleType r, r2;
    r.topLeft.x = 1;
    r.topLeft.y = 90;
    r.extent.x = 160-r.topLeft.x-1;
    r.extent.y = 12;
    if (num == 0) {
        WinEraseRectangle(&r, 0);
        if (den == 0) {
            WinEraseRectangleFrame(simpleFrame, &r);
            ShowIcons();
            return;
        }
        WinDrawRectangleFrame(simpleFrame, &r);
    } else {
        /*
         * The progress bar
         */
        r2 = r;
        r2.topLeft.x++;
        r2.topLeft.y++;
        r2.extent.x -= 2;
        r2.extent.y -= 2;
        r2.extent.x = (r2.extent.x*num)/den;
        WinSetPattern((CustomPatternType) {0xfefd,0xfbf7,0xefdf,0xbf7f});
        WinFillRectangle(&r2, 0);
    }
}

void ShowButtons(short which)
{
    FormPtr frm;
    if ((frm = FrmGetFormPtr(MainForm)) == 0) return;
    switch (which) {
    case 0:
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_cancel)));
        ShowProgress(true, "", 0, 0, 0);
        CtlShowControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_sendmail)));
        CtlShowControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_getmail)));
        CtlShowControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_clearinbox)));
        CtlShowControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_sendfiles)));
        ShowIcons();
        if (PrefsR->Prefs.makebeep == '1')
            SndPlaySystemSound(sndInfo); /* Ta Da, I've done something */
        break;
    case 1:
        HideIcons();
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_sendmail)));
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_getmail)));
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_clearinbox)));
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_sendfiles)));
/*        ShowProgress("", 0, 1, 0); */
        ShowErrorMsg("");
        break;
    case 2:
        CtlShowControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_cancel)));
        break;
    case 3:
        CtlHideControl(FrmGetObjectPtr(frm,
            FrmGetObjectIndex(frm, buttonID_cancel)));
        break;
    }
    buttonsshown = which;

    if (buttonsshown == 2) {
        /*
         * Whenever we are doing stuff we don't want the alarm notifications
         * to get in the way.
         */
        if (alarmnotify && (PrefsR->Prefs.noautooff == '1')) {
            AlmEnableNotification(false);
            alarmnotify = false;
        }
    } else {
        /* turn them back on */
        if (!alarmnotify && (PrefsR->Prefs.noautooff == '1')) {
            AlmEnableNotification(true);
            alarmnotify = true;
        }
    }
}

void HideIcons(void)
{
    RectangleType r1, r6;
    FormPtr frm;
    if ((frm = FrmGetFormPtr(MainForm)) == 0) return;
    FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch1), &r1);
    FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch6), &r6);
    r1.topLeft.x = 0;
    r1.extent.x = 160;
    r1.extent.y = r6.topLeft.y+r6.extent.y-r1.topLeft.y;
    WinEraseRectangle(&r1, 0);
}

void ShowIcons(void)
{
    RectangleType r;
    FormPtr frm;
    VoidHand iconh;
    BitmapPtr iconp;
    CharPtr icont;
    short i, i1, i2;
    UInt rindex;

    if ((frm = FrmGetFormPtr(MainForm)) == 0) return;

    /*
     * Draw all the icons & text that is stored at records 1-6.
     */

    for (i=0; i < 6; i++) {
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch1+i), &r);
        rindex = i+1;
        iconh = DmQueryRecord(MainDB, rindex);
        if (iconh && (icont = MemHandleLock(iconh))) {
            iconp = (BitmapPtr) ((CharPtr) icont+64);
            /* first check if it is just a dummy record */
            if (icont[0] == '\0') {
                MemHandleUnlock(iconh);
                continue;
            }
            /* The application's icon */
            WinDrawBitmap(iconp, r.topLeft.x+16-(iconp->width/2), r.topLeft.y);
            /* The application's name */
            if ((i1 = StrLen(icont))) {
                i2 = FntCharsWidth(icont, i1);
                WinDrawChars(icont, i1, r.topLeft.x+16-(i2/2),
                    r.topLeft.y+24);
            }
            MemHandleUnlock(iconh);
         }
    }
    
    return;
}

Boolean BuildIcons(void)
{
    UInt cardNo;
    LocalID dbID;
    DmOpenRef IconDB;
    Int iconi;
    VoidHand iconh;
    BitmapPtr iconp;
    CharPtr icont;
	DatabaseHdrType hdr;
    short i, i1;
    Ptr p;
    UInt rindex;
    VoidHand rhandle;
    Err err;
    long isize;

    /*
     * Store all of the icons & text into records 1-6 for quicker retrieval
     * later.  Otherwise drawing these launch icons can be painfully slow
     * due to the database and resource searching.
     */

    for (i=0; i < 6; i++) {

        rindex = i+1;
        rhandle = DmQueryRecord(MainDB, rindex);
        if (rhandle != 0) {
            /* get rid of existing record */
            err = DmRemoveRecord(MainDB, rindex);
            ErrFatalDisplayIf(err, ErrToString(err));
            rhandle = 0;
        }

        /*
         * First look for 'ovly' because on OS 3.5 color, all the icons
         * are in there rather than the 'appl'.
         */
        if (((IconDB = DmOpenDatabaseByTypeCreator('ovly',
            Prefslaunch[i], dmModeReadOnly)) != 0) ||
            ((IconDB = DmOpenDatabaseByTypeCreator(sysFileTApplication,
            Prefslaunch[i], dmModeReadOnly)) != 0)) {
            p = NULL;
            /* The application's icon */
            if ((iconi = DmFindResource(IconDB, 'tAIB', 1000, NULL)) != -1) {
                if ((iconh = DmGetResourceIndex(IconDB, iconi))) {
                    if ((iconp = MemHandleLock(iconh))) {
                        isize = MemHandleSize(iconh);
                        rhandle = DmNewRecord(MainDB, &rindex, isize+64);
                        ErrFatalDisplayIf(!rhandle,
                            "Could not create prefs bitmap record.");
                        /*
                         * Copy the bitmap into the record with 64 bytes
                         * left empty at the beginning that I will use
                         * for the title text later on.
                         */
                        if ((p = MemHandleLock(rhandle))) {
                            DmSet(p, 0, 64, 0);
                            DmWrite(p, 64, (char *) iconp, isize);
                        }
                        MemHandleUnlock(iconh);
                    }
                    DmReleaseResource(iconh);
                }
            }
            if (!p) {
                DmCloseDatabase(IconDB);
                return false;
            }
            /* The application's name */
            if ((iconi = DmFindResource(IconDB, 'tAIN', 1000, NULL)) != -1) {
                if ((iconh = DmGetResourceIndex(IconDB, iconi))) {
                    if ((icont = MemHandleLock(iconh))) {
                        if ((i1 = StrLen(icont))) {
                            DmWrite(p, 0, (char *) icont, MIN(i1, 63));
                        }
                        MemHandleUnlock(iconh);
                    }
                    DmReleaseResource(iconh);
                }
            } else {
                /* No tAIN resource, just use the file name then */
                if ((DmOpenDatabaseInfo(IconDB, &dbID, NULL, NULL, &cardNo,
                    NULL) == 0) &&
                    (DmDatabaseInfo(cardNo, dbID, hdr.name, NULL, NULL, NULL,
                    NULL, NULL, NULL, NULL, NULL, NULL, NULL) == 0)) {
                    if ((i1 = StrLen(hdr.name))) {
                        DmWrite(p, 0, (char *) hdr.name, MIN(i1, 63));
                    }
                }
            }
            DmCloseDatabase(IconDB);
            if (p) MemPtrUnlock(p);
        } else {
            /*
             * The application wasn't found, so we'll make a dummy record so
             * the ShowIcons() doesn't get confused.
             */
            rhandle = DmNewRecord(MainDB, &rindex, 1);
            ErrFatalDisplayIf(!rhandle,
                "Could not create prefs bitmap record.");
            if ((p = MemHandleLock(rhandle))) {
                DmSet(p, 0, 1, 0);
                MemPtrUnlock(p);
            }
        }
        if (rhandle) DmReleaseRecord(MainDB, rindex, true);
    }

    return true;
}
