/* $Id: database.c,v 1.47 1999/10/30 02:14:15 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

#include <Pilot.h>
#include <System/DataPrv.h>
#include "gnugotmail.h"
#include "common.h"
#include "gnugotmailDB.h"
#include "database.h"

extern struct sPrefsR *PrefsR;
extern Char AppErrStr[];
extern DmOpenRef MainDB, MailDB;
extern char MainDBName[], MailDBName[];

/* globals */

struct sfiledata filed;

/*
 * This routine is adapted from the example Code Warrior NetSample FTP client.
 *
 * The purpose of reading a data file is to encode it as an attachment in an
 * outgoing message.  My tick routines are designed to be called intermittently
 * so that I can return back to the EventLoop and sleep if I am waiting for
 * things to happen.  The filetick() is meant to be called successively for
 * each chunk of file data that you want.  It will always fill the requested
 * len even if it combines header data with record data, etc.  When it returns
 * with zero bytes, you have reached the end of the data file or hit an error.
 */

long filetick(LocalID dbID, char *str, long len)
{
    Int cardNo=0;
    long bytes=0, count=0;
    ULong dtsec;
    
    do {
    switch(filed.parseState) {
    case filestOPEN:
        /*
         * We are to initialize variables and open the database and
         * determine if it is a PRC or PDB.
         */
        filed.dbID = dbID;
        filed.dbP = 0;
        filed.err = 0;
        filed.appInfoH = 0;
        filed.sortInfoH = 0;
        filed.appInfoSize = 0;
        filed.sortInfoSize = 0;
        filed.totalBytes = 0;
        filed.filler = 0;
        filed.srcP = 0;
        filed.resH = 0;
        filed.recindexes = 0;
        MemSet((char *) filed.hdr.name, sizeof(filed.hdr.name), 0);
        filed.err = DmDatabaseInfo(cardNo, filed.dbID, filed.hdr.name,
                &filed.hdr.attributes, &filed.hdr.version,
                &filed.hdr.creationDate, &filed.hdr.modificationDate,
                &filed.hdr.lastBackupDate, &filed.hdr.modificationNumber,
                &filed.appInfoID, &filed.sortInfoID, &filed.hdr.type,
                &filed.hdr.creator);
        if (filed.err) {
            filed.parseState = filestERROR;
            break;
        }

        /*
         * Skip ROM and readonly files.  I've had problems working with ROM
         * and flash so I will just skip them.
         *
         * Until I put together a way to exclude files from this, I am just
         * ignoring 'LauncherIII Data' which gets dirtied wayyy too often.
         * Same thing with AvantGo data files.
         *
         * Checks the modification date to see if it is greater than the
         * last backup date.
         */
        if ((MemLocalIDKind(filed.dbID) != memIDHandle) ||
            (filed.hdr.attributes & dmHdrAttrReadOnly) ||
            (filed.hdr.creator == 'AvGo') ||
            (filed.hdr.creator == 'Cash') ||
            ((PrefsR->SendFilesPrefs.all != '1') &&
            (filed.hdr.modificationDate <= filed.hdr.lastBackupDate))) {
            filed.parseState = filestALLDONE;
            break;
        }

        filed.err = DmDatabaseSize(cardNo, filed.dbID, 0, 0, &filed.fullsize);
        if (filed.err) {
            filed.parseState = filestERROR;
            break;
        }
        filed.dbP = DmOpenDatabase(cardNo, filed.dbID, dmModeReadOnly |
            dmModeShowSecret);
        if (!filed.dbP) {
            filed.err = DmGetLastErr();
            filed.parseState = filestERROR;
            break;
        }
        if (filed.hdr.attributes & dmHdrAttrResDB) filed.parseState = filestPRC;
        else filed.parseState = filestPDB;
        break;
    case filestPRC:
        /* Figure out size of header */
        filed.numRecords = DmNumRecords(filed.dbP);
        filed.size = sizeof(DatabaseHdrType)+(filed.numRecords*
            sizeof(RsrcEntryType));
        /* Fill in header */
        filed.hdr.appInfoID = 0;
        filed.hdr.sortInfoID = 0;
        filed.hdr.recordList.nextRecordListID = 0;
        filed.hdr.recordList.numRecords = filed.numRecords;
        /* add the header to the fullsize */
        filed.fullsize += filed.size;
        filed.outoff = 0;
        filed.outstage = 0;
        filed.parseState = filestPRCHDR;
        break;
    case filestPRCHDR:
        if (filed.outstage == 0) {
            /*
             * We keep coming into this outstage until the data has been
             * written.  This is because I don't have enough space to take
             * an entire unit, so I must honor the caller's len.
             *
             * Write out the header
             */
            bytes = MIN(len-count,
                (sizeof(filed.hdr)-sizeof(filed.hdr.recordList.firstEntry))-
                filed.outoff);
            MemMove(&str[count], (char *) &filed.hdr+filed.outoff,
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) <
                (sizeof(filed.hdr)-sizeof(filed.hdr.recordList.firstEntry)))
                 break;
            filed.offset = filed.size;
            filed.i = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 1) {
            /*
             * Fill in the info on each resource into the header.  We bounce
             * back into this outstage every time the a resEntry is fully
             * written.  When all of them are written, we skip ahead two
             * stages.
             */
            if (filed.i >= filed.numRecords) {
                filed.outstage += 2;
                break;
            }
            filed.err = DmResourceInfo(filed.dbP, filed.i, &filed.resType,
                &filed.resID, &filed.resChunkID);
            if (filed.err) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            filed.resH = DmGetResourceIndex(filed.dbP, filed.i);
            if (filed.resH)  {
                filed.size = MemHandleSize(filed.resH);
                DmReleaseResource(filed.resH);
                filed.resH = 0;
            } else filed.size = 0;
               filed.resEntry.type = filed.resType;
            filed.resEntry.id = filed.resID;
            filed.resEntry.localChunkID = filed.offset;
            filed.outoff = 0;
            filed.outstage++;
        }            
        if (filed.outstage == 2) {
            /*
             * Write out the entry
             */
            bytes = MIN(len-count, sizeof(filed.resEntry)-filed.outoff);
            MemMove(&str[count], (char *) &filed.resEntry+filed.outoff,
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) < sizeof(filed.resEntry))
                 break;
            filed.totalBytes += sizeof(filed.resEntry);
            filed.offset += filed.size;
            filed.i++;
            filed.outstage--;
            break;
        }
        if (filed.outstage == 3) {
            /*
             * Write out the extra WORD that is currently in all .PRC
             * files due to an historical "oversight".
             *
             * We'll always have enough space for this.
             */
            bytes = sizeof(filed.filler);
            MemMove(&str[count], (char *) &filed.filler, bytes);
            count += bytes;
            filed.totalBytes += bytes;
            filed.i = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 4) {
            /*
             * Write out each resource
             */
            if (filed.i >= filed.numRecords) {
                filed.outstage += 2;
                break;
            }
            filed.err = DmResourceInfo(filed.dbP, filed.i, &filed.resType,
                &filed.resID, &filed.resChunkID);
            if (filed.err) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            if (filed.resChunkID) {
                filed.resH = DmGetResourceIndex(filed.dbP, filed.i);
                if (!filed.resH) {
                    filed.err = -1;
                    filed.parseState = filestERROR;
                    break;
                }
                filed.size = MemHandleSize(filed.resH);
                filed.srcP = MemHandleLock(filed.resH);
                filed.outoff = 0;
                filed.outstage++;
            } else {
                filed.i++;
            }
            break;
        }
        if (filed.outstage == 5) {
            /*
             * Write out the resource
             */
            bytes = MIN(len-count, filed.size-filed.outoff);
            MemMove(&str[count], (char *) &filed.srcP[filed.outoff],
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) < filed.size)
                 break;
            filed.totalBytes += filed.size;
            MemPtrUnlock(filed.srcP);
            filed.srcP = 0;
            DmReleaseResource(filed.resH);
            filed.resH = 0;
            filed.i++;
            filed.outstage--;
            break;
        }
        if (filed.outstage == 6) {
            filed.parseState = filestCLOSE;
            break;
        }
    case filestPDB:
        /* Figure out size of header */
        filed.numRecords = DmNumRecords(filed.dbP);
        /*
         * Instead of the sortinfo, I put in a funky record indexes list.
         * Read some of the comments below to figure out what I am talking
         * about.
         *
         * Attempt to allocate a list of record indexes.  I explain the
         * purpose of this a little further below.
         */
        if (filed.numRecords) {
            if ((filed.recindexes = MemPtrNew(filed.numRecords*3)) == 0) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            filed.sortInfoSize = filed.numRecords*3;
        }
        /*
         * I can't believe that I have to run through the entire file
         * to see how many dirty records there are.  Ugh, that makes
         * three times I have to do this.  I really only have to do
         * this to figure out how many bytes there are going to be.
         * Since I am here I already know there are dirty records because
         * the modified date has indicated this.
         *
         * I want to make sure I check for a last backup date of zero
         * because that means we should grab all records regardless of
         * their dirty status.  An example of this would be a data file
         * installed with pilot-xfer.
         */
        filed.dirtyRecords = 0;
        bytes = 0; /* temporary fullsize calculation */
        for (filed.i=0; filed.i < filed.numRecords; filed.i++) {
            filed.err = DmRecordInfo(filed.dbP, filed.i, &filed.attr,
                &filed.uniqueID, &filed.recordID);
            if (filed.err) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            /*
             * Now this is where I get funky.  Since I can't tell
             * if I am looking at a new record or an old record I
             * need to keep track of the index so I know where to
             * put it.  In other words, if this is a NEW record I
             * want to insert it into the proper physical location
             * so that whatever sort the user had them in is
             * preserved.  To do this I am going to cheat and place
             * record indexes in the sortinfo part of the PDB file.
             *
             * Okay I wound up putting the 3-byte record ID for *every*
             * record in here.  This is because some files let you sort
             * the records, and when they are moved around they don't
             * necessarily mark the dirty bit.  Therefore the only way
             * to determine if the sort order has changed is to send
             * the record IDs.  The good part about this is that it will
             * also let me perform fast syncing with non-conduit files
             * because I can tell which record IDs are missing and therefore
             * delete them from the host.
             *
             * It is basically a trade-off because I don't believe
             * the sortinfo is currently used.. certainly not for
             * files coming "from" the PalmPilot.  And I didn't
             * want to break any PDB file utilities by putting
             * funkiness anywhere else in the file.. mmmkay?
             */
            filed.recindexes[filed.i*3] =
                (filed.uniqueID >> 16) & 0x00FF;
            filed.recindexes[(filed.i*3)+1] =
                (filed.uniqueID >> 8) & 0x00FF;
            filed.recindexes[(filed.i*3)+2] = filed.uniqueID  & 0x00FF;
            if ((filed.attr & dmRecAttrDirty) ||
                (filed.attr & dmRecAttrDelete)) {
                if (filed.recordID &&
                    (filed.srcH = DmQueryRecord(filed.dbP, filed.i)))
                    bytes += MemHandleSize(filed.srcH);
                else bytes += 1; /* this is a 1 byte delete stub */
                filed.dirtyRecords++;
            }
        }
        if (filed.parseState == filestERROR) break;

        /*
         * I go through the above loop always to get the record indexes array.
         * Still if the file has never been backed up or the user doesn't want
         * fast mode, I will grab all records.  Still, we will always have a
         * full quasi-sortinfo including all records because we want to detect
         * sorting changes and place new records in the proper places.
         */
        if ((filed.hdr.lastBackupDate == 0) ||
            (PrefsR->SendFilesPrefs.all == '1') ||
            (PrefsR->SendFilesPrefs.fast != '1')) {
            filed.dirtyRecords = filed.numRecords;
        } else filed.fullsize = bytes;
        /*
         * Now I should have the dirtyRecords and the fullsize.  I still
         * have to add some stuff to fullsize though, if in fast mode.
         */

        filed.size = sizeof(DatabaseHdrType)+(filed.dirtyRecords*
            sizeof(RecordEntryType));
        /* Fill in header */
        filed.hdr.attributes &= ~dmHdrAttrOpen; /* don't want open */
        filed.hdr.appInfoID = 0;
        filed.hdr.sortInfoID = 0;
        filed.hdr.recordList.nextRecordListID = 0;
        filed.hdr.recordList.numRecords = filed.dirtyRecords;
        /*
         * Get the size of the appInfo and sort Info if they exist
         */
        filed.offset = filed.size;
        if (filed.appInfoID) {
            filed.hdr.appInfoID = filed.offset;
            filed.appInfoH = MemLocalIDToGlobal(filed.appInfoID, cardNo);
            if (!filed.appInfoH) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            filed.appInfoSize = MemHandleSize(filed.appInfoH);
            filed.offset += filed.appInfoSize;
        }
/*
        if (filed.sortInfoID) {
            filed.hdr.sortInfoID = filed.offset;
            filed.sortInfoH = MemLocalIDToGlobal(filed.sortInfoID, cardNo);
            if (!filed.sortInfoH) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            filed.sortInfoSize = MemHandleSize(filed.sortInfoH);
            filed.offset += filed.sortInfoSize;
        }            
*/
        if (filed.recindexes) {
            filed.hdr.sortInfoID = filed.offset;
            filed.offset += filed.sortInfoSize;
        }

        /*
         * Okay I'll just add the offset to fullsize and that should be
         * the total number of bytes to transfer.
         */
        filed.fullsize += filed.offset;
        filed.outoff = 0;
        filed.outstage = 0;
        filed.parseState = filestPDBHDR;
        break;
    case filestPDBHDR:
        if (filed.outstage == 0) {
            /*
             * We keep coming into this outstage until the data has been
             * written.  This is because I don't have enough space to take
             * an entire unit, so I must honor the caller's len.
             *
             * Write out the header
             */
            bytes = MIN(len-count,
                (sizeof(filed.hdr)-sizeof(filed.hdr.recordList.firstEntry))-
                filed.outoff);
            MemMove(&str[count], (char *) &filed.hdr+filed.outoff,
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) <
                (sizeof(filed.hdr)-sizeof(filed.hdr.recordList.firstEntry)))
                 break;
            filed.totalBytes += sizeof(filed.hdr)-
                sizeof(filed.hdr.recordList.firstEntry);
            filed.i = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 1) {
            /*
             * Fill in the info on each record into the header.  We bounce
             * back into this outstage every time the a resEntry is fully
             * written.  When all of them are written, we skip ahead two
             * stages.
             */
            if (filed.i >= filed.numRecords) {
                filed.outstage += 2;
                break;
            }
            filed.err = DmRecordInfo(filed.dbP, filed.i, &filed.attr,
                &filed.uniqueID, &filed.recordID);
            if (filed.err) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }

            /*
             * If the record is marked as deleted, temporarily un-delete
             * it so that we can get the handle to it's data, if any.
             *
             * I don't particularly care for this because it makes me
             * open the files in readwrite mode.  And if you open files
             * that are in ROM in readwrite mode, it will crash when you
             * try and DmCloseDatabase().  Furthermore who cares if there
             * is a data stub for a deleted record, not me.
             */
            /*
            if ((filed.attr & dmRecAttrDelete) && filed.recordID) {
                filed.attr &= ~dmRecAttrDelete;
                DmSetRecordInfo(filed.dbP, filed.i, &filed.attr, 0);
                filed.srcH = DmQueryRecord(filed.dbP, filed.i);
                filed.attr |= dmRecAttrDelete;
                DmSetRecordInfo(filed.dbP, filed.i, &filed.attr, 0);
            } else filed.srcH = DmQueryRecord(filed.dbP, filed.i);
            */

            /*
             * I want ONLY dirty and deleted records if I'm in fast mode.
             *
             * Though:
             * I want to make sure I check for a last backup date of zero
             * because that means we should grab all records regardless of
             * their dirty status.  An example of this would be a data file
             * installed with pilot-xfer.
             *
             * Also I figure I'll just do all records if the Backup attribute
             * is set.  This is supposed to mean that the data file doesn't
             * keep delete stubs, so otherwise I'll have no way to delete
             * records in the repository.  Actually I enhanced this but I'm
             * too busy to fix this comment right now.
             */
            if (filed.attr & dmRecAttrDelete) {
                filed.srcH = 0;
                filed.recEntry.localChunkID = filed.offset;
                filed.size = 1;  /* this is a 1 byte delete stub */
            } else if ((filed.hdr.lastBackupDate == 0) ||
                (PrefsR->SendFilesPrefs.all == '1') ||
                (PrefsR->SendFilesPrefs.fast != '1') ||
                (filed.attr & dmRecAttrDirty)) {
                filed.srcH = DmQueryRecord(filed.dbP, filed.i);
                filed.recEntry.localChunkID = filed.offset;
                filed.size = MemHandleSize(filed.srcH);
            } else {
                filed.i++;
                break;
            }

            /*
             * Collect the record entry info
             */
            filed.recEntry.attributes = filed.attr & ~dmRecAttrDirty;
            filed.recEntry.uniqueID[0] = (filed.uniqueID >> 16) & 0x00FF;
            filed.recEntry.uniqueID[1] = (filed.uniqueID >> 8) & 0x00FF;
            filed.recEntry.uniqueID[2] = filed.uniqueID  & 0x00FF;
            filed.outoff = 0;
            filed.outstage++;
        }            
        if (filed.outstage == 2) {
            /*
             * Write out the record list entry
             */
            bytes = MIN(len-count, sizeof(filed.recEntry)-filed.outoff);
            MemMove(&str[count], (char *) &filed.recEntry+filed.outoff,
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) < sizeof(filed.recEntry))
                 break;
            filed.totalBytes += sizeof(filed.recEntry);
            filed.offset += filed.size;
            filed.i++;
            filed.outstage--;
            break;
        }
        if (filed.outstage == 3) {
            /*
             * Write out the extra WORD that is currently in all .PRC
             * files due to an historical "oversight".
             *
             * We'll always have enough space for this.
             */
            bytes = sizeof(filed.filler);
            MemMove(&str[count], (char *) &filed.filler, bytes);
            count += bytes;
            filed.totalBytes += bytes;
            filed.i = 0;
            filed.outoff = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 4) {
            /*
             * Write out the appInfo if it exists
             */
            if (filed.appInfoID && filed.appInfoSize) {
                filed.srcP = MemHandleLock(filed.appInfoH);
                bytes = MIN(len-count, filed.appInfoSize-filed.outoff);
                MemMove(&str[count], (char *) &filed.srcP[filed.outoff],
                    bytes);
                MemPtrUnlock(filed.srcP);
                filed.srcP = 0;
                count += bytes;
                if ((filed.outoff += bytes) < filed.appInfoSize)
                     break;
                filed.totalBytes += filed.appInfoSize;
            }
            filed.outoff = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 5) {
            /*
             * Write out the sortInfo if it exists.  Well, really I am writing
             * the list of record indexes here if it exists.  That is a fancy
             * extension to the PDB form that I needed to let me add new records
             * in the proper physical locations.
             */
            if (filed.recindexes) {
                bytes = MIN(len-count, filed.sortInfoSize-filed.outoff);
                MemMove(&str[count], (char *) &filed.recindexes[filed.outoff],
                    bytes);
                count += bytes;
                if ((filed.outoff += bytes) < filed.sortInfoSize)
                     break;
                filed.totalBytes += filed.sortInfoSize;
            }
            filed.outstage++;
            break;
        }
        if (filed.outstage == 6) {
            /*
             * Loop for writing records
             */
            if (filed.i >= filed.numRecords) {
                filed.outstage += 2;
                break;
            }
            filed.err = DmRecordInfo(filed.dbP, filed.i, &filed.attr,
                &filed.uniqueID, &filed.recordID);
            if (filed.err) {
                filed.err = -1;
                filed.parseState = filestERROR;
                break;
            }
            /*
             * If the record is marked as deleted, temporarily un-delete
             * it so that we can get the handle to it's data, if any.
             *
             * I don't particularly care for this because it makes me
             * open the files in readwrite mode.  And if you open files
             * that are in ROM in readwrite mode, it will crash when you
             * try and DmCloseDatabase().  Furthermore who cares if there
             * is a data stub for a deleted record, not me.
             */
            /*
            if ((filed.attr & dmRecAttrDelete) && filed.recordID) {
                filed.attr &= ~dmRecAttrDelete;
                DmSetRecordInfo(filed.dbP, filed.i, &filed.attr, 0);
                filed.srcH = DmQueryRecord(filed.dbP, filed.i);
                filed.attr |= dmRecAttrDelete;
                DmSetRecordInfo(filed.dbP, filed.i, &filed.attr, 0);
            } else filed.srcH = DmQueryRecord(filed.dbP, filed.i);
            */

            /*
             * I want ONLY dirty and deleted records if I'm in fast mode.
             *
             * Though:
             * I want to make sure I check for a last backup date of zero
             * because that means we should grab all records regardless of
             * their dirty status.  An example of this would be a data file
             * installed with pilot-xfer.
             *
             * Also I figure I'll just do all records if the Backup attribute
             * is set.  This is supposed to mean that the data file doesn't
             * keep delete stubs, so otherwise I'll have no way to delete
             * records in the repository.
             */
            if (filed.attr & dmRecAttrDelete) {
                filed.srcH = 0;
                /*
                 * Some tools have a problem with delete record list entries
                 * that have no data chunk.  So I make a 1 byte data chunk
                 * for all deleted records that have no data chunk.
                 */
                str[count++] = (char) 0x86; /* seems appropriate (: */
                filed.totalBytes++;
                filed.i++;
                break;
            } else if ((filed.hdr.lastBackupDate == 0) ||
                (PrefsR->SendFilesPrefs.all == '1') ||
                (PrefsR->SendFilesPrefs.fast != '1') ||
                (filed.attr & dmRecAttrDirty)){
                filed.srcH = DmQueryRecord(filed.dbP, filed.i);
            } else {
                filed.i++;
                break;
            }

            if (!filed.srcH) {
                filed.i++;
                break;
            }
            filed.size = MemHandleSize(filed.srcH);
            filed.srcP = MemHandleLock(filed.srcH);
            filed.outoff = 0;
            filed.outstage++;
            break;
        }
        if (filed.outstage == 7) {
            /*
             * Write out the record
             */
            bytes = MIN(len-count, filed.size-filed.outoff);
            MemMove(&str[count], (char *) &filed.srcP[filed.outoff],
                bytes);
            count += bytes;
            if ((filed.outoff += bytes) < filed.size)
                 break;
            filed.totalBytes += filed.size;
            MemPtrUnlock(filed.srcP);
            filed.srcP = 0;
            filed.i++;
            filed.outstage--;
            break;
        }
        if (filed.outstage == 8) {
            filed.parseState = filestCLOSE;
            break;
        }
    case filestCLEARBITS:
        /*
         * We call this state to clear the dirty bits and delete the
         * deleted records.  No need to call any other state because
         * this opens the database and closes it when it's done going
         * through the records.
         */
        filed.dbID = dbID;
        filed.dbP = 0;
        filed.err = 0;
        filed.srcP = 0;
        filed.resH = 0;
        MemSet((char *) filed.hdr.name, sizeof(filed.hdr.name), 0);
        filed.err = DmDatabaseInfo(cardNo, filed.dbID, filed.hdr.name,
                &filed.hdr.attributes, &filed.hdr.version,
                &filed.hdr.creationDate, &filed.hdr.modificationDate,
                &filed.hdr.lastBackupDate, &filed.hdr.modificationNumber,
                &filed.appInfoID, &filed.sortInfoID, &filed.hdr.type,
                &filed.hdr.creator);
        if (filed.err) {
            filed.parseState = filestERROR;
            break;
        }

        /*
         * Skip ROM and readonly files.  I've had problems working with ROM
         * and flash so I will just skip them.
         *
         * Until I put together a way to exclude files from this, I am just
         * ignoring 'LauncherIII Data' which gets dirtied wayyy too often.
         * Same thing with AvantGo data files.
         *
         * Checks the modification date to see if it is greater than the
         * last backup date.
         */
        if ((MemLocalIDKind(filed.dbID) != memIDHandle) ||
            (filed.hdr.attributes & dmHdrAttrReadOnly) ||
            (filed.hdr.creator == 'AvGo') ||
            (filed.hdr.creator == 'Cash') ||
            ((PrefsR->SendFilesPrefs.all != '1') &&
            (filed.hdr.modificationDate <= filed.hdr.lastBackupDate))) {
            filed.parseState = filestALLDONE;
            break;
        }

        /*
         * We have MailDB and gnugotmailDB already open for read/write.
         * PalmOS doesn't support two opens for read/write so we have to
         * use our other db handles.  It should be okay because I only
         * call this after I've unlocked all MailDB records.
         */
        if (StrCompare(filed.hdr.name, MailDBName) == 0) filed.dbP = MailDB;
        else if (StrCompare(filed.hdr.name, MainDBName) == 0) filed.dbP = MainDB;
        else filed.dbP = DmOpenDatabase(cardNo, filed.dbID, dmModeReadWrite |
            dmModeShowSecret);

        if (!filed.dbP) {
            filed.err = DmGetLastErr();
            filed.parseState = filestERROR;
            break;
        }

        /*
         * Only mess with the records if it is not a prc.
         */
        if (!(filed.hdr.attributes & dmHdrAttrResDB)) {
            filed.numRecords = DmNumRecords(filed.dbP);
            for (filed.i=0; filed.i < filed.numRecords; filed.i++) {
                filed.err = DmRecordInfo(filed.dbP, filed.i, &filed.attr,
                    &filed.uniqueID, &filed.recordID);
                if (filed.err) {
                    filed.err = -1;
                    filed.parseState = filestERROR;
                    break;
                }
                /*
                 * For records that we have sent in fast mode (the ones that
                 * match the criterion and are assumed to be already sent) we
                 * reset the dirty bit and remove any records that are marked
                 * deleted.
                 */
                if (filed.attr & dmRecAttrDelete) {
                    if ((filed.err = DmRemoveRecord(filed.dbP, filed.i))) {
                        filed.err = -1;
                        filed.parseState = filestERROR;
                        break;
                    } else {
                        /*
                         * We just removed the record, so we adjust the counter
                         * so that we will start with the record that took it's
                         * place.
                         */
                        filed.i--;
                        filed.numRecords--;
                        continue;
                    }
                } else if (filed.attr & dmRecAttrDirty) {
                        filed.attr &= ~dmRecAttrDirty;
                        DmSetRecordInfo(filed.dbP, filed.i, &filed.attr, 0);
                }
            }
        }
        
        /*
         * Set the last backup date
         */
        dtsec = TimGetSeconds();
        DmSetDatabaseInfo(cardNo, filed.dbID, 0, 0, 0, 0, 0, &dtsec, 0,
            0, 0, 0, 0);
        /*
         * Make sure we don't close our two databases.
         */
        if ((filed.dbP != MailDB) && (filed.dbP != MainDB))
            DmCloseDatabase(filed.dbP);
        filed.parseState = filestALLDONE;
        break;
    case filestERROR:
        ShowErrorMsg(ErrToString(filed.err));
        filed.parseState = filestCLOSE;
    case filestCLOSE:
        if (filed.dbP) {
            /*
             * Make sure everything is unlocked.
             */
            if (filed.srcP) MemPtrUnlock(filed.srcP);
            if (filed.resH) DmReleaseResource(filed.resH);
            if (filed.recindexes) MemPtrFree(filed.recindexes);
            DmCloseDatabase(filed.dbP);
        }
        filed.parseState = filestALLDONE;
    case filestALLDONE:
        return count;
    }
    /*
     * I continue with the next state in certain cases because I want some
     * stuff calculated before I return.. like dirtyRecords.
     */
    } while ((count < len) || (filed.parseState == filestPRC) ||
        (filed.parseState == filestPDB) || (filed.parseState == filestCLOSE) ||
        (filed.parseState == filestALLDONE));
    return count;
}    
