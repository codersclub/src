/* $Id: gnugotmail.c,v 1.80 2000/12/07 01:35:36 chrisf Exp $ */

/*
GNU Got Mail - An SMTP/POP3 client for the PalmPilot
Copyright (C) 1999 Chris Faherty

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
*/

/* Main code for gnugotmail */

#include <Pilot.h>
#include <System/NetMgr.h>
#include <System/SysEvtMgr.h>
#include <System/DataPrv.h>
#include "callback.h"
#include "gnugotmailRsc.h"
#include "gnugotmail.h"
#include "gnugotmailDB.h"
#include "common.h"
#include "sockets.h"
#include "pop.h"
#include "smtp.h"
#include "database.h"

/* globals */

Err errno, h_errno;
Long AppNetTimeout;
Word AppNetRefnum=-1;

NetSocketRef popsock=0, smtpsock=0;
extern struct spopdata popd;
extern struct ssmtpdata smtpd;
extern struct sfiledata filed;
extern long leavefree;
extern char lastchars[];

long OutboxCount;
char tnum[10], nullchar='\0', ch[64];
Char AppErrStr[AppErrStrLen];
Boolean PrefsRdirty, PrefsWeredirty;
Word catInbox, catOutbox, catFiled;
short sendfilesnext;
DateTimeType dtnow;
ULong dtnowseconds;
Word tps;
Word AppsPopupCount;
Handle AppsPopupH;
ULong Prefslaunch[6];
short buttonsshown;

/*
 * Heap allocations
 */
VoidHand PrefsRecHandle, PrefsRHandle;
UInt PrefsRecIndex;
struct sPrefsR *PrefsR;
struct sPrefsR DefaultPrefsR={
    11,
    { "10", '1', '1', '0', { "mail", "date", "addr", "pref", "todo", "memo" } },
    { "smtpserv", "25", "dick@weed.net", "Dick Weed", "", '1', '0' },
    { "popserv", "110", "user", "pass", "0", "1", '1', '1', '0', "firstuidl" },
    { "", "secret", '0', '1', '1' }
};

/*
 * These are for the private database
 */
#define MainAppID 'GNGM'
#define MainDBType 'DATA'
DmOpenRef MainDB;
char MainDBName[] = "gnugotmailDB\0";

/*
 * These are for accessing the built-in MailDB
 */
DmOpenRef MailDB;
char MailDBName[] = "MailDB\0";
long RecordCount;

/*
 * Static function prototypes
 */
static Boolean MainFormHandleEvent(EventPtr e);
static Boolean PrefsFormHandleEvent(EventPtr e);
static Boolean SMTPPrefsFormHandleEvent(EventPtr e);
static Boolean POPPrefsFormHandleEvent(EventPtr e);
static Boolean POPPrefsPassFormHandleEvent(EventPtr e);
static Boolean SendFilesFormHandleEvent(EventPtr e);
static Boolean AboutFormHandleEvent(EventPtr e);
static FieldPtr GetFocusObjectPtr(void);
static Boolean FormHandleMenuEvent(Word menuID);
static Boolean ApplicationHandleEvent(EventPtr e);
static void freememories(void);
static Word StartApplication(void);
static void StopApplication(void);
static void EventLoop(void);
static void AppsPopupDrawItem(UInt itemNum, RectanglePtr bounds,
    CharPtr *unusedP);
static ULong AppsPopup(Word listid, Word triggerid, ULong curcreator);

static Boolean MainFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    RectangleType r, r1;
    Boolean ishighlit, isinside, penDown;
    SWord x, y;
    short i;
    UInt cardNo;
    LocalID dbID;
    DmSearchStateType searchInfo;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        FrmDrawForm(frm);
        ShowStatusLine(true);
        ShowIcons();
        /*
         * This is set if you confirmed the SendFilesForm
         */
        if (sendfilesnext && !smtpsock) {
            /* this also adheres to the fake POP setting */
            if (PrefsR->SMTPPrefs.fakepop == '1') {
                if (!popsock && !smtpsock) OpenPOP3(2);
            } else {
                if (!smtpsock) OpenSMTP(sendfilesnext);
            }
        }
        sendfilesnext = 0;
        handled = true;
        break;

    case frmUpdateEvent:
        /*
         * Not very likely, but the OS3.5 debug ROM was built to
         * provide this often for testing your program's reaction to low
         * memory conditions.  We return handled = true so that the default
         * action of the OS doesn't call FrmDrawForm() again.
         */
        frm = FrmGetActiveForm();
        FrmDrawForm(frm);
        ShowStatusLine(true);
        ShowIcons();
        handled = true;
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        switch(e->data.menu.itemID) {
        case mitemID_prefs:
            FrmGotoForm(PrefsForm);
            break;
        case mitemID_popprefs:
            FrmGotoForm(POPPrefsForm);
            break;
        case mitemID_smtpprefs:
            FrmGotoForm(SMTPPrefsForm);
            break;
        case mitemID_sendmail:
            /*
             * Sending mail can also involve sending a fake POP login.  If this
             * is enabled, we will call OpenPOP3() which will do a POP login
             * and then it will eventually cascade us into OpenSMTP().
             */
            if (PrefsR->SMTPPrefs.fakepop == '1') {
                if (!popsock && !smtpsock) OpenPOP3(2);
            } else {
                if (!smtpsock) OpenSMTP(0);
            }
            break;
        case mitemID_getmail:
            if (!popsock) OpenPOP3(0);
            break;
        case mitemID_highmsg:
            if (!popsock) OpenPOP3(1);
            break;
        case mitemID_about:
            FrmPopupForm(AboutForm);
            break;
        case mitemID_softreset:
            /*
             * I changed over to EVPlugBase from Hackmaster and I miss the
             * soft reset option.  So, well, here it is!
             */
            frm = FrmInitForm(SoftResetForm);
            i = FrmDoDialog(frm);
            FrmDeleteForm(frm);
            if (i == buttonID_softresetyes) SysReset();
            break;
        }
       handled = true;
       break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_sendmail:
            /*
             * Sending mail can also involve sending a fake POP login.  If this
             * is enabled, we will call OpenPOP3() which will do a POP login
             * and then it will eventually cascade us into OpenSMTP().
             */
            if (PrefsR->SMTPPrefs.fakepop == '1') {
                if (!popsock && !smtpsock) OpenPOP3(2);
            } else {
                if (!smtpsock) OpenSMTP(0);
            }
            break;
        case buttonID_getmail:
            if (!popsock) OpenPOP3(0);
            break;
        case buttonID_clearinbox:
            ClearInbox();
            break;
        case buttonID_sendfiles:
            sendfilesnext = 0;
            FrmGotoForm(SendFilesForm);
            break;
        case buttonID_cancel:
            ClosePOP3();
            CloseSMTP();
            ShowErrorMsg("user cancelled.");
            break;
        }
        break;

    case penDownEvent:
        /* first check if the icons are currently showing */
        if (buttonsshown != 0) break;
        frm = FrmGetActiveForm();
        /*
         * Checking if the user is pressing one of the six launch icons.  I
         * have gadgets to represent where they should be.
         */
        isinside = true;
        do {
        i = 0;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch1), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        i++;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch2), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        i++;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch3), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        i++;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch4), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        i++;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch5), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        i++;
        FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, gadgetID_launch6), &r);
        if (RctPtInRectangle(e->screenX, e->screenY, &r)) break;
        isinside = false;
        } while (0);
        if (!isinside) break;
        ishighlit = false;
        r1 = r;
        r1.extent.y = 24;
        /*
         * While the pen is held down I stay in this loop.  The user can move
         * the stylus outside of the area to stop the operation.
         */
        do {
            PenGetPoint(&x, &y, &penDown);
            isinside = RctPtInRectangle(x, y, &r);
            if ((!ishighlit && isinside) ||
                (ishighlit && !isinside)) {
                WinInvertRectangle(&r1, 5);
                ishighlit = !ishighlit;
            }
        } while (penDown);
        /*
         * If the stylus was still inside the icon when released then launch
         * the application.
         */
        if (ishighlit) {
            WinInvertRectangle(&r1, 5);
            if ((DmGetNextDatabaseByTypeCreator(true, &searchInfo,
                sysFileTApplication, Prefslaunch[i], true, &cardNo,
                &dbID) == 0)) {
                SysUIAppSwitch(cardNo, dbID, sysAppLaunchCmdNormalLaunch, NULL);
            }
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean PrefsFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    ULong AppID;
    static Boolean save;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        LoadPrefsFields();
        FrmDrawForm(frm);
        FrmSetFocus(frm, FrmGetObjectIndex(frm, fieldID_prefsleavefree));
        save = false;
        handled = true;
        break;

    case frmCloseEvent:
        UnloadPrefsFields(save);
        if (save) WritePrefsRec();
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        handled = FormHandleMenuEvent(e->data.menu.itemID);
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case popuptriggerID_prefslaunch1:
            MemMove(&AppID, PrefsR->Prefs.launch[0], sizeof(AppID));
            Prefslaunch[0] = AppsPopup(listID_prefslaunch1,
                popuptriggerID_prefslaunch1, AppID);
            break;
        case popuptriggerID_prefslaunch2:
            MemMove(&AppID, PrefsR->Prefs.launch[1], sizeof(AppID));
            Prefslaunch[1] = AppsPopup(listID_prefslaunch2,
                popuptriggerID_prefslaunch2, AppID);
            break;
        case popuptriggerID_prefslaunch3:
            MemMove(&AppID, PrefsR->Prefs.launch[2], sizeof(AppID));
            Prefslaunch[2] = AppsPopup(listID_prefslaunch3,
                popuptriggerID_prefslaunch3, AppID);
            break;
        case popuptriggerID_prefslaunch4:
            MemMove(&AppID, PrefsR->Prefs.launch[3], sizeof(AppID));
            Prefslaunch[3] = AppsPopup(listID_prefslaunch4,
                popuptriggerID_prefslaunch4, AppID);
            break;
        case popuptriggerID_prefslaunch5:
            MemMove(&AppID, PrefsR->Prefs.launch[4], sizeof(AppID));
            Prefslaunch[4] = AppsPopup(listID_prefslaunch5,
                popuptriggerID_prefslaunch5, AppID);
            break;
        case popuptriggerID_prefslaunch6:
            MemMove(&AppID, PrefsR->Prefs.launch[5], sizeof(AppID));
            Prefslaunch[5] = AppsPopup(listID_prefslaunch6,
                popuptriggerID_prefslaunch6, AppID);
            break;
        case buttonID_prefsok:
            save = true;
            FrmGotoForm(MainForm);
            break;
        case buttonID_prefscancel:
            FrmGotoForm(MainForm);
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean SMTPPrefsFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    static Boolean save;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        LoadSMTPPrefsFields();
        FrmDrawForm(frm);
        FrmSetFocus(frm, FrmGetObjectIndex(frm, fieldID_smtpserver));
        save = false;
        handled = true;
        break;

    case frmCloseEvent:
        UnloadSMTPPrefsFields(save);
        if (save) WritePrefsRec();
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        handled = FormHandleMenuEvent(e->data.menu.itemID);
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_smtpprefsok:
            save = true;
            FrmGotoForm(MainForm);
            break;
        case buttonID_smtpprefscancel:
            FrmGotoForm(MainForm);
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean POPPrefsFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    static Boolean save;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        LoadPOPPrefsFields();
        FrmDrawForm(frm);
        FrmSetFocus(frm, FrmGetObjectIndex(frm, fieldID_popserver));
        save = false;
        handled = true;
        break;

    case frmCloseEvent:
        UnloadPOPPrefsFields(save);
        if (save) WritePrefsRec();
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        handled = FormHandleMenuEvent(e->data.menu.itemID);
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_popprefsok:
            save = true;
            FrmGotoForm(MainForm);
            break;
        case buttonID_popprefscancel:
            FrmGotoForm(MainForm);
            break;
        case triggerID_poppass:
            FrmPopupForm(POPPrefsPassForm);
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean POPPrefsPassFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    VoidPtr obj;
    char *ts;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        FrmDrawForm(frm);
        FrmSetFocus(frm, FrmGetObjectIndex(frm, fieldID_poppass));
        handled = true;
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        switch(e->data.menu.itemID) {
        }
        handled = true;
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_popprefspassok:
            frm = FrmGetActiveForm();
            obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
                fieldID_poppass));
            MemSet(PrefsR->POPPrefs.pass,
                sizeof(PrefsR->POPPrefs.pass), 0);
            if ((ts = FldGetTextPtr(obj)))
                MemMove(PrefsR->POPPrefs.pass, ts, StrLen(ts));
            FrmReturnToForm(0);
            handled = true;
            break;
        case buttonID_popprefspasscancel:
            FrmReturnToForm(0);
            handled = true;
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean SendFilesFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;
    static Boolean save;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        LoadSendFilesPrefsFields();
        FrmDrawForm(frm);
        save = false;
        handled = true;
        break;

    case frmCloseEvent:
        if (UnloadSendFilesPrefsFields(save)) WritePrefsRec();
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        handled = FormHandleMenuEvent(e->data.menu.itemID);
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_sendfilesstart:
            save = true;
            sendfilesnext = 1;
            FrmGotoForm(MainForm);
            break;
        case buttonID_sendfilesclearbits:
            /*
             * Argh!  I wrote this Clear Bits button stuff before I thought
             * it all through.  Basically this was to be a time-saver for
             * when I load up a new pilot.  Since I already have the repository
             * there would be no need to have dirty bits or a last backup
             * date of zero, which would cause the first sync to take a long
             * time.  But alas I forgot that whenever you install a file
             * it is given a creation date.. and if that creation date does
             * not match the one on the repository file, I will assume the
             * file needs to be replaced -- rightfully so.
             *
             * I didn't have the heart to remove the code for this feature,
             * so I just set the button to be NONUSABLE until I can figure
             * out a way to match creation dates.  Though this may not be
             * a good idea, because who knows how the pilot creates new
             * record IDs.. or if it will create duplicate ones in that
             * case.
             */
            save = true;
            sendfilesnext = 2;
            FrmGotoForm(MainForm);
            break;
        case buttonID_sendfilescancel:
            save = true; /* save on cancel as well */
            FrmGotoForm(MainForm);
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

static Boolean AboutFormHandleEvent(EventPtr e)
{
    Boolean handled;
    FormPtr frm;

    CALLBACK_PROLOGUE

    handled = false;

    switch (e->eType) {
    case frmOpenEvent:
        frm = FrmGetActiveForm();
        FrmDrawForm(frm);
        handled = true;
        break;

    case menuEvent:
        MenuEraseStatus(NULL);
        switch(e->data.menu.itemID) {
        }
        handled = true;
        break;

    case ctlSelectEvent:
        switch(e->data.ctlSelect.controlID) {
        case buttonID_aboutok:
            FrmReturnToForm(0);
            handled = true;
            break;
        }
        break;

    default:
        break;
    }

    CALLBACK_EPILOGUE

    return handled;
}

/*
 * Returns field that has the focus, if any, including in embedded tables.
 */
static FieldPtr GetFocusObjectPtr(void)
{
    FormPtr frm;
    Word focus;
    FormObjectKind objType;
    frm = FrmGetActiveForm();
    focus = FrmGetFocus(frm);
    if (focus == noFocus) return NULL;
    objType = FrmGetObjectType(frm, focus);
    if (objType == frmFieldObj) return FrmGetObjectPtr(frm, focus);
    else if (objType == frmTableObj)
        return TblGetCurrentField(FrmGetObjectPtr(frm, focus));
    return NULL;
}

static Boolean FormHandleMenuEvent(Word menuID)
{
    FieldPtr fld;
    switch (menuID) {
    case sysEditMenuUndoCmd:
    case sysEditMenuCutCmd:
    case sysEditMenuCopyCmd:
    case sysEditMenuPasteCmd:
    case sysEditMenuSelectAllCmd:
        fld = GetFocusObjectPtr();
        if (!fld) return false;
        if (menuID == sysEditMenuUndoCmd) FldUndo(fld);
        else if (menuID == sysEditMenuCutCmd) FldCut(fld);
        else if (menuID == sysEditMenuCopyCmd) FldCopy(fld);
        else if (menuID == sysEditMenuPasteCmd) FldPaste(fld);
        else if (menuID == sysEditMenuSelectAllCmd)
            FldSetSelection (fld, 0, FldGetTextLength (fld));
        return true;
    case sysEditMenuKeyboardCmd:
        SysKeyboardDialog(kbdDefault);
        return true;
    case sysEditMenuGraffitiCmd:
        SysGraffitiReferenceDialog(referenceDefault);
        return true;
    }
    return false;
}

static Boolean ApplicationHandleEvent(EventPtr e)
{
    FormPtr frm;
    Word    formId;
    Boolean handled;

    CALLBACK_PROLOGUE

    handled = false;
    if (e->eType == frmLoadEvent) {
        formId = e->data.frmLoad.formID;
        frm = FrmInitForm(formId);
        FrmSetActiveForm(frm);

        switch(formId) {
        case MainForm:
            FrmSetEventHandler(frm, MainFormHandleEvent);
            break;
        case PrefsForm:
            FrmSetEventHandler(frm, PrefsFormHandleEvent);
            break;
        case POPPrefsForm:
            FrmSetEventHandler(frm, POPPrefsFormHandleEvent);
            break;
        case POPPrefsPassForm:
            FrmSetEventHandler(frm, POPPrefsPassFormHandleEvent);
            break;
        case SMTPPrefsForm:
            FrmSetEventHandler(frm, SMTPPrefsFormHandleEvent);
            break;
        case SendFilesForm:
            FrmSetEventHandler(frm, SendFilesFormHandleEvent);
            break;
        case AboutForm:
            FrmSetEventHandler(frm, AboutFormHandleEvent);
            break;
        }
        handled = true;
    }

    CALLBACK_EPILOGUE

    return handled;
}

/*
 * These are called in StartApplication and StopApplication because they
 * are required memory allocations that exist from start to finish of the
 * application run.
 */
static void freememories(void)
{
    if (popd.msgrec) MemPtrFree(popd.msgrec);
    if (popd.sq.sendq) MemPtrFree(popd.sq.sendq);
    if (smtpd.sq.sendq) MemPtrFree(smtpd.sq.sendq);
    if (PrefsRHandle) MemHandleFree(PrefsRHandle);
}

/* Get preferences, open (or create) app database */
static Word StartApplication(void)
{
    tps = SysTicksPerSecond();
    AppNetTimeout = 60*tps;
    AppNetRefnum = -1;
    buttonsshown = 0;
    MailDB = 0;
    popd.msgrec = 0;
    popd.sq.sendq = 0;
    popd.sq.sendqin = 0;
    popd.sq.sendqout = 0;
    smtpd.sq.sendq = 0;
    smtpd.sq.sendqin = 0;
    smtpd.sq.sendqout = 0;
    sendfilesnext = 0;
    PrefsRHandle = 0;
    PrefsR = NULL;
    PrefsRdirty = false;
    PrefsWeredirty = false;
    if ((popd.msgrec = MemPtrNew(MSGRECSIZE)) == 0) {
        freememories();
        return 1;
    }
    if ((popd.sq.sendq = MemPtrNew(SENDQSIZE)) == 0) {
        freememories();
        return 1;
    }
    if ((smtpd.sq.sendq = MemPtrNew(SENDQSIZE)) == 0) {
        freememories();
        return 1;
    }
    if ((PrefsRHandle = MemHandleNew(sizeof(struct sPrefsR))) == 0) {
        freememories();
        return 1;
    }
    /*
     * Lock the PrefsR structure
     */
    PrefsR = MemHandleLock(PrefsRHandle);
    if (!OpenDatabases()) return 1;
    FrmGotoForm(MainForm);
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void)
{
    FrmSaveAllForms();
    FrmCloseAllForms();
    ClosePOP3();
    CloseSMTP();
    CloseDatabases();
    freememories();
}

/* The main event loop */
static void EventLoop(void)
{
    Err err;
    EventType e;
    SWord rv, bytes;
    NetFDSetType rfds, wfds;
    long l1; 
    long eventTimeout, to, lastticks=0;
    Boolean onmainform=false;

    lastticks = TimGetTicks();
    do {

    if (popsock || smtpsock || (smtpd.parseState == smtpstCLEARBITS)) {
        /*
         * This select() is for all open sockets, and also it will
         * come out if there are any pending events which lets the
         * normal stuff happen.
         */
        netFDZero(&rfds);
        netFDZero(&wfds);
        netFDSet(sysFileDescStdIn, &rfds);
        /*
         * This tries to make sure that reads won't occur if there
         * is data still enqueued to go out.  Not very efficient, but
         * necessary so that I don't enqueue too much outgoing data.
         */
        if (popsock && !popd.sq.sendqin) netFDSet(popsock, &rfds);
        if (smtpsock && !smtpd.sq.sendqin) netFDSet(smtpsock, &rfds);
        /*
         * If there is any data enqueued for a connection we will set
         * the bit here so that it will indicate to us when it is ready
         * for writing.
         */
        if (popsock && popd.sq.sendqin) netFDSet(popsock, &wfds);
        if (smtpsock && smtpd.sq.sendqin) netFDSet(smtpsock, &wfds);
        /*
         * This select will drop out; when incoming data arrives, when
         * outgoing data may be sent, when an OS event occurs, and when
         * the timeout expires.  I set this to a reasonable value, unless
         * the smtptick() is in the CLEARBITS state because then I want
         * it to go very fast.
         *
         * We also do this during BODY2 so that the user may cancel during
         * file enumeration.  Normally we return here once some outgoing
         * data goes, but in BODY2 state we only output data when we find
         * an appropriate file.  So unless we allow this timeout, the user
         * wouldn't be able to cancel because I would need to stay inside
         * smtptick().
         */
        if (((smtpd.parseState == smtpstCLEARBITS) ||
            (!smtpd.sq.sendqin && (smtpd.parseState == smtpstBODY2)))) to = 0;
        else to = 2*tps;
        if (AppNetRefnum != -1) {
            rv = NetLibSelect(AppNetRefnum, netFDSetSize, &rfds, &wfds, NULL,
                to, &errno);
        } else {
            rv = 0;
        }
        if (onmainform) {
            /*
             * Update the status line whenever a timeout occurs.
             */
            to = TimGetTicks();
            if ((to-lastticks) >= (2*tps)) {
                ShowStatusLine(false);
                lastticks = to;
            }
        }
        if (rv > 0) {
            /*
             * Keep the unit on during network activity.
             */
            if (PrefsR->Prefs.noautooff == '1') EvtResetAutoOffTimer();
            /*
             * Incoming data
             */
            if (popsock && netFDIsSet(popsock, &rfds)) {
                if ((bytes = NetLibReceive(AppNetRefnum, popsock, ch,
                    sizeof(ch), 0, 0, 0, AppNetTimeout, &errno)) > 0) {
                    l1 = poptick(ch, bytes, popsock);
                    if (l1 < 0) ClosePOP3();
                } else ClosePOP3();
            }
            if (smtpsock && netFDIsSet(smtpsock, &rfds)) {
                if ((bytes = NetLibReceive(AppNetRefnum, smtpsock, ch,
                    sizeof(ch), 0, 0, 0, AppNetTimeout, &errno)) > 0) {
                    l1 = smtptick(ch, bytes, smtpsock);
                    if (l1 < 0) CloseSMTP();
                } else CloseSMTP();
            }
            /*
             * Checking for channels ready for writing.  These will only
             * be true if there is data in the sendq because of the
             * netFDSet() above.
             */
            if (popsock && netFDIsSet(popsock, &wfds)) {
                if ((bytes = NetLibSend(AppNetRefnum, popsock,
                    &popd.sq.sendq[popd.sq.sendqout],
                    popd.sq.sendqin-popd.sq.sendqout, 0, 0, 0, AppNetTimeout,
                    &errno)) > 0) {
                    popd.sq.sendqout += bytes;
                    if (popd.sq.sendqin == popd.sq.sendqout) {
                        popd.sq.sendqin = 0;
                        popd.sq.sendqout = 0;
                    }
                } else ClosePOP3();
            }
            if (smtpsock && netFDIsSet(smtpsock, &wfds)) {
                if ((bytes = NetLibSend(AppNetRefnum, smtpsock,
                    &smtpd.sq.sendq[smtpd.sq.sendqout],
                    smtpd.sq.sendqin-smtpd.sq.sendqout, 0, 0, 0, AppNetTimeout,
                    &errno)) > 0) {
                    smtpd.sq.sendqout += bytes;
                    if (smtpd.sq.sendqin == smtpd.sq.sendqout) {
                        smtpd.sq.sendqin = 0;
                        smtpd.sq.sendqout = 0;
                        /*
                         * This needs a little explanation.  At some time I
                         * will be needing to enqueue more data than will fit
                         * in the sendq.  For example the BODY state.  So I
                         * give the parser a call when the sendq has finished
                         * flushing.  Note that I call this with a length of
                         * zero because it is a special case.
                         */
                        smtptick(&nullchar, 0, smtpsock);
                    }
                } else CloseSMTP();
            }
        } else {
            /*
             * The CLEARBITS state wants me to call smtptick() as fast as
             * I can.  So when in that state I make the select timeout = 0.
             * The purpose of this is so that I can iterate through files
             * and still be responsive to the user's cancel request.
             */
            if (((smtpd.parseState == smtpstCLEARBITS) ||
                (!smtpd.sq.sendqin && (smtpd.parseState == smtpstBODY2)))) {
                smtptick(&nullchar, 0, smtpsock);
                /*
                 * CLEARBITS will throw me into this state if the Clear
                 * Bits button was pressed.
                 */
                if (!smtpsock && (smtpd.parseState == smtpstALLDONE))
                    CloseSMTP();
            }
        }
        eventTimeout = 0;
    } else eventTimeout = 2*tps;
    
    EvtGetEvent(&e, eventTimeout);
    /*
     * If one of the silk screened keys is hit we want
     * to shutdown the connection.
     */
    if ((e.eType == keyDownEvent) &&
        (e.data.keyDown.modifiers & commandKeyMask) &&
        ((e.data.keyDown.chr == launchChr) ||
        (e.data.keyDown.chr == menuChr) ||
        (e.data.keyDown.chr == autoOffChr) ||
        (e.data.keyDown.chr == hardPowerChr))) {
        ClosePOP3();
        CloseSMTP();
    }
    /*
     * Update the status line whenever a nilEvent occurs.  The showstatus
     * variable is used to determine if there is another form loaded.. in
     * which case we don't want to obscure it with the status line.
     */
    if (onmainform && (e.eType == nilEvent) &&
        !(popsock || smtpsock)) {
        ShowStatusLine(false);
    }

    if (! SysHandleEvent(&e))
        if (! MenuHandleEvent(NULL, &e, &err))
            if (! ApplicationHandleEvent(&e))
                FrmDispatchEvent(&e);

    if (e.eType == winEnterEvent) {
        if (e.data.winEnter.enterWindow ==
            (WinHandle) FrmGetFormPtr(MainForm))
            onmainform = true; else onmainform = false;
    }

    } while (e.eType != appStopEvent);

}

Boolean OpenPOP3(short whattodo)
{
    Err err, ifErrs;
    ShowInfoMsg("");
    err = SysLibFind("Net.lib", &AppNetRefnum);
    ErrNonFatalDisplayIf(err, ErrToString(err));
    ShowButtons(1);
    err = NetLibOpen(AppNetRefnum, &ifErrs);
    if ((err && err != netErrAlreadyOpen) || ifErrs) {
        /*
         * We always want to use a true on the NetLibClose() if there
         * was a failure with NetLibOpen().  Otherwise the PalmOS goes
         * berzerk thinking that it has a network connection when it
         * doesn't.. and it makes you cycle power to fix.
         */
        if (NetLibClose(AppNetRefnum, true) != netErrStillOpen) {
            AppNetRefnum = -1;
            ShowButtons(0);
        }
        ShowErrorMsg(ErrToString(ifErrs));
        return false;
    }
    /*
     * Here is where I would open the connection to the
     * POP3 server, which should start the train rolling.
     */
    popd.error = 0;
    popd.parseAction = -1;
    popd.parseState = stOPEN;
    popd.keepdata = 0;
    popd.skipdata = 0;
    popd.msgreccnt = 0;
    popd.msgnum = StrAToI(PrefsR->POPPrefs.startmsg);
    popd.maxlines = StrAToI(PrefsR->POPPrefs.maxlines);
    leavefree = StrAToI(PrefsR->Prefs.leavefree);
    popd.msgrechandle = 0;
    popd.sq.sendqin = 0;
    popd.sq.sendqout = 0;
    popd.justhighmsg = false;
    popd.onlylogin = false;
    popd.sendfilesnext = sendfilesnext; /* copy the global for later */
    switch (whattodo) {
    case 1:
        popd.justhighmsg = true;
        break;
    case 2:
        popd.onlylogin = true;
        break;
    }
    /*
     * Clear out the history chars
     */
    lastchars[0] = (char) NULL;
    lastchars[1] = (char) NULL;
    lastchars[2] = (char) NULL;
    lastchars[3] = (char) NULL;
    lastchars[4] = (char) NULL;
    if ((popsock =
        connectsock(PrefsR->POPPrefs.server, PrefsR->POPPrefs.port)) == 0) {
        if (NetLibClose(AppNetRefnum, false) != netErrStillOpen)
            AppNetRefnum = -1;
        ShowButtons(0);
        ShowErrorMsg(NULL);
        return false;
    } else ShowButtons(2);
    return true;
}

void ClosePOP3(void)
{
    int i1;
    /*
     * It wasn't finished yet, so we'll make it a special error.
     */
    if ((popd.parseState != stALLDONE) && (!popd.error)) popd.error = 2;
    if (popsock) {
        ShowButtons(3);
        popd.parseAction = -1;
        popd.parseState = stALLDONE;
        poptick(&nullchar, 1, popsock);
        /*
         * Keep the last message number if you are leaving mail on server.
         * But only if the 'Delete messages from server' is not set.  As you
         * recall this is meant to act as a way to leave your messages on
         * the server and just start reading at a particular message number.
         *
         * In addition we don't want to do this if this was the fake POP login
         * required by some SMTP servers before sending mail.
         */
        if ((!popd.onlylogin && (PrefsR->POPPrefs.deletemsg == '0')) ||
            popd.justhighmsg) {
            i1 = numtotxt(popd.msgnum, tnum, false);
            MemSet(PrefsR->POPPrefs.startmsg,
                sizeof(PrefsR->POPPrefs.startmsg), 0);
            StrCopy(PrefsR->POPPrefs.startmsg, tnum);
            PrefsRdirty = true;
        }
        if (popsock)
            NetLibSocketClose(AppNetRefnum, popsock, AppNetTimeout, &errno);
        popsock = 0;
        /*
         * Here we are nice and use a false on the NetLibClose() to allow it
         * to stay open if others are using it.
         */
        if ((AppNetRefnum != -1) &&
            (NetLibClose(AppNetRefnum, false) != netErrStillOpen)) {
            AppNetRefnum = -1;
        }
        /*
         * We aren't done yet if we only did this POP to allow the user
         * to send mail via SMTP.  If that is the case, then we want to
         * start sending the mail now.
         */
        if (popd.onlylogin && !popd.error && !smtpsock) {
            OpenSMTP(popd.sendfilesnext);
            return; /* we don't want to show the buttons yet */
        }
        ShowButtons(0);
        if (popd.error == 1) ShowErrorMsg(NULL);
    }
}

Boolean OpenSMTP(short sendfiles)
{
    Err err, ifErrs;
    /*
     * This is a special case where we only want to clear the dirty bits.
     * I feel this is a little funky here but I'm trying to conserve code
     * space, so I am using the smtpstCLEARBITS state of smtptick() without
     * having an open connection.
     */
    if (sendfiles == 2) {
        smtpd.error = 0;
        smtpd.parseAction = -1;
        smtpd.parseState = smtpstCLEARBITS;
        smtpd.keepdata = 0;
        smtpd.msgrechandle = 0;
        smtpd.sq.sendqin = 0;
        smtpd.sq.sendqout = 0;
        smtpd.sendfiles = true;
        filed.parseState = filestALLDONE;
        smtpd.fileindex = 0;
        smtpd.numfiles = DmNumDatabases(0);
        ShowInfoMsg("");
        ShowButtons(1);
        ShowButtons(2);
        ShowFileInfo(2, " ");
        return true;
    }
    /*
     * Why continue if there are no Outbox records.  This OutboxCount is
     * also used later. 
     */
    if (!sendfiles && (OutboxCount = DmNumRecordsInCategory(MailDB, catOutbox))
        <= 0) return false;
    ShowInfoMsg("");
    err = SysLibFind("Net.lib", &AppNetRefnum);
    ErrNonFatalDisplayIf(err, ErrToString(err));
    ShowButtons(1);
    err = NetLibOpen(AppNetRefnum, &ifErrs);
    if ((err && err != netErrAlreadyOpen) || ifErrs) {
        /*
         * We always want to use a true on the NetLibClose() if there
         * was a failure with NetLibOpen().  Otherwise the PalmOS goes
         * berzerk thinking that it has a network connection when it
         * doesn't.. and it makes you cycle power to fix.
         */
        if (NetLibClose(AppNetRefnum, true) != netErrStillOpen) {
            AppNetRefnum = -1;
            ShowButtons(0);
        }
        ShowErrorMsg(ErrToString(ifErrs));
        return false;
    }
    /*
     * Here is where I open the connection to the SMTP server, which should
     * start the train rolling.  I initialize some critical variables here
     * because the smtptick() may not get called at all until CloseSMTP()
     * and I need to make sure that the variables that are tested in the
     * smtpstALLDONE state are valid.
     */
    smtpd.error = 0;
    smtpd.parseAction = -1;
    smtpd.parseState = smtpstOPEN;
    smtpd.keepdata = 0;
    smtpd.msgrechandle = 0;
    smtpd.sq.sendqin = 0;
    smtpd.sq.sendqout = 0;
    smtpd.sendfiles = (Boolean) sendfiles;
    /*
     * In case it is aborted before it is started we don't want the
     * filetick() to be called in the smtpstALLDONE state.
     */
    filed.parseState = filestALLDONE;
    if ((smtpsock =
        connectsock(PrefsR->SMTPPrefs.server, PrefsR->SMTPPrefs.port)) == 0) {
        if (NetLibClose(AppNetRefnum, false) != netErrStillOpen)
            AppNetRefnum = -1;
        ShowButtons(0);
        ShowErrorMsg(NULL);
        return false;
    } else ShowButtons(2);
    return true;
}

void CloseSMTP(void)
{
    /*
     * It wasn't finished yet, so we'll make it a special error.
     */
    if ((smtpd.parseState != smtpstALLDONE) && (!smtpd.error)) smtpd.error = 2;
    smtpd.parseAction = -1;
    smtpd.parseState = smtpstALLDONE;
    if (smtpsock) {
        ShowButtons(3);
        smtptick(&nullchar, 1, smtpsock);
        if (smtpsock)
            NetLibSocketClose(AppNetRefnum, smtpsock, AppNetTimeout, &errno);
        smtpsock = 0;
        /*
         * Here we are nice and use a false on the NetLibClose() to allow it
         * to stay open if others are using it.
         */
        if ((AppNetRefnum != -1) &&
            (NetLibClose(AppNetRefnum, false) != netErrStillOpen)) {
            AppNetRefnum = -1;
        }
        if (smtpd.sendfiles) ShowFileInfo(0, " ");
        ShowButtons(0);
        if (smtpd.error == 1) ShowErrorMsg(NULL);
    }
}

Boolean OpenDatabases(void)
{
    Err err;
    Ptr p;

    /*
     * Set these to zero in case any of the opens fail.
     */
    MainDB = 0;
    MailDB = 0;
    PrefsRecHandle = 0;
    /*
     * Open/Create the private database
     */
    MainDB = DmOpenDatabaseByTypeCreator(MainDBType, MainAppID,
        dmModeReadWrite);
    if (!MainDB) {
        /*
         * Create our database if it doesn't exist yet
         */
        if (DmCreateDatabase(0, MainDBName, MainAppID, MainDBType, false))
            return false;
        MainDB = DmOpenDatabaseByTypeCreator(MainDBType, MainAppID,
            dmModeReadWrite);
        if (!MainDB) return false;
    }
    PrefsRecIndex = 0;
    PrefsRecHandle = DmQueryRecord(MainDB, PrefsRecIndex);
    if (PrefsRecHandle != 0) {
        /*
         * A Prefs record already exists so we will do a sanity check.
         */
        if (MemHandleSize(PrefsRecHandle) >= sizeof(PrefsR->version)) {
            /*
             * Let's compare the version number.  If it doesn't match we will
             * delete the record and make the user start from scratch.  Ha ha!
             *
             * BTW, the current Prefs record version is 11.
             * Change this each time the Prefs record layout changes.
             */
            p = MemHandleLock(PrefsRecHandle);
            if (*p != (char) 11) {
                MemPtrUnlock(p);
                err = DmRemoveRecord(MainDB, PrefsRecIndex);
                ErrFatalDisplayIf(err, ErrToString(err));
                PrefsRecHandle = 0;
            } else MemPtrUnlock(p);
        } else {
            err = DmRemoveRecord(MainDB, PrefsRecIndex);
            ErrFatalDisplayIf(err, ErrToString(err));
            PrefsRecHandle = 0;
        }
    }
    if (PrefsRecHandle == 0) {
        /*
         * Create the preferences record if it doesn't exist and
         * preload it with default values.
         */
        PrefsRecHandle = DmNewRecord(MainDB, &PrefsRecIndex,
            sizeof(struct sPrefsR));
        ErrFatalDisplayIf(!PrefsRecHandle, "Could not create prefs record.");
        p = MemHandleLock(PrefsRecHandle);
        err = DmWrite(p, 0, &DefaultPrefsR, sizeof(struct sPrefsR));
        ErrFatalDisplayIf(err, "Could not write default prefs.");
        MemPtrUnlock(p);
        ReadPrefsRec();
        BuildIcons(); /* cause it to rebuild the launch icon records */
    } else {
        ReadPrefsRec();
    }

    /*
     * A cheezy way to see if the launch icon cache records need to be rebuilt.
     */
    if (DmNumRecords(MainDB) < 7) BuildIcons();

    MailDB = DmOpenDatabaseByTypeCreator(MailDBType, MailAppID,
        dmModeReadWrite | dmModeShowSecret);
    if (!MailDB) return false;
    popd.msgrechandle = 0;
    /*
     * Get the category indexes.  We don't use the category names any more
     * because it has come to my attention that they are spelled differently
     * on International versions.
     */

/*
    catInbox = CategoryFind(MailDB, "Inbox");
    catOutbox = CategoryFind(MailDB, "Outbox");
    catFiled = CategoryFind(MailDB, "Filed");
*/

    catInbox = 0;
    catOutbox = 1;
    catFiled = 3;

    RecordCount = DmNumRecordsInCategory(MailDB, catInbox);
    return true;
}

void CloseDatabases(void)
{
    if (MailDB) {
        endnewrecord();
        DmCloseDatabase(MailDB);
    }
    if (MainDB) {
        if (PrefsRecHandle) {
            if (PrefsRdirty) WritePrefsRec();
            DmReleaseRecord(MainDB, PrefsRecIndex, PrefsWeredirty);
            /*
             * Unlock the PrefsR structure
             */
            if (PrefsR) MemPtrUnlock(PrefsR);
        }
        DmCloseDatabase(MainDB);
    }
}

void ClearInbox(void)
{
    UInt totalItems, i1, recordNum=0;
    VoidHand recordH;
    if (MailDB) {
        /*
         * Aha, this is from:
         *
         * Palm Programming: The Developer's Guide
         *
         * A book which I hope to get as soon as it shows up in my
         * bookstore.  Thankfully there is an online version for us
         * living in areas that don't have quality books.
         */
        if ((totalItems = DmNumRecordsInCategory(MailDB, catInbox)) <= 0)
            return; 
        recordNum = 0;
        ShowProgressBar(0, 1);
        for (i1=0; i1 < totalItems; i1++) {
            recordH = DmQueryNextInCategory(MailDB, &recordNum,
                catInbox);
            /*
             * Remove the record -- all of it.  Break if error.
             */
            if (DmRemoveRecord(MailDB, recordNum)) break;
            ShowProgressBar(i1, totalItems);
        }
        RecordCount = DmNumRecordsInCategory(MailDB, catInbox);
        ShowProgressBar(0, 0);
        ShowStatusLine(false);
    }
}

static void AppsPopupDrawItem(UInt itemNum, RectanglePtr bounds,
    CharPtr *unusedP)
{
    SysDBListItemType *listP;
	DatabaseHdrType hdr;
    SWord tl, tw;
    Boolean ignored;
    char ellipsisChar = horizEllipsisChr;

    CALLBACK_PROLOGUE

    if (AppsPopupH != NULL) {
        listP = MemHandleLock((VoidHand) AppsPopupH);
        if (DmDatabaseInfo(listP[itemNum].cardNo, listP[itemNum].dbID,
            hdr.name, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
            &hdr.creator) == 0) {
            tl = StrLen(hdr.name);
            tw = FntCharsWidth(hdr.name, tl);
            if (tw <= bounds->extent.x) {
                WinDrawChars(hdr.name, StrLen(hdr.name), bounds->topLeft.x,
                    bounds->topLeft.y);
            } else {
                tw = bounds->extent.x-FntCharWidth(ellipsisChar);
                FntCharsInWidth(hdr.name, &tw, &tl, &ignored);
                WinDrawChars(hdr.name, tl, bounds->topLeft.x,
                    bounds->topLeft.y);
                WinDrawChars(&ellipsisChar, 1, bounds->topLeft.x+tw,
                    bounds->topLeft.y);
            }
        }
        MemPtrUnlock(listP);
    }

    CALLBACK_EPILOGUE
}

static ULong AppsPopup(Word listid, Word triggerid, ULong curcreator)
{
    Word error;
    Int curSelection=-1;
    Int newSelection;
    Int i1, width, height;
    ULong newcreator=curcreator;
    ListPtr lst;
    ControlPtr trig;
	FormPtr frm;
    CharPtr label;
    RectangleType r;
    SysDBListItemType *listP;
	DatabaseHdrType hdr;
    WinHandle saved=0;
    VoidHand strH;
    CharPtr strP;

    /*
     * This is going to take a while, so we'll put a little message up
     * for the user.
     */
    if ((strH = DmGetResource(strRsc, strID_pleasewait))) {
        strP = MemHandleLock(strH);
        FntSetFont(boldFont);
        i1 = StrLen(strP);
        width = FntCharsWidth(strP, i1);
        height = FntCharHeight();
        r.topLeft.x = 80-((width+12)/2);
        r.topLeft.y = 80-((height+8)/2);
        r.extent.x = width+12;
        r.extent.y = height+8;
        if ((saved = WinSaveBits(&r, &error))) {
            WinEraseRectangle(&r, 0);
            r.topLeft.x++;
            r.topLeft.y++;
            r.extent.x -= 3;
            r.extent.y -= 3;
            WinDrawRectangleFrame(popupFrame, &r);
            WinDrawChars(strP, i1, r.topLeft.x+(r.extent.x/2)-(width/2),
                r.topLeft.y+(r.extent.y/2)-(height/2));
        }
        MemHandleUnlock(strH);
        DmReleaseResource(strH);
        FntSetFont(stdFont);
    }

    if (!SysCreateDataBaseList(sysFileTApplication, 0, &AppsPopupCount,
        &AppsPopupH, true)) {
        AppsPopupCount = 0;
        AppsPopupH = 0;
    } else {
        /* Figure out the current selection by comparing the creator ID's */
        listP = MemHandleLock((VoidHand) AppsPopupH);
        for (i1=0; i1 < AppsPopupCount; i1++) {
            if (listP[i1].creator == curcreator) {
                curSelection = i1;
                break;
            }
        }
        MemPtrUnlock(listP);
    }

    /* Get rid of the message */
    if (saved) WinRestoreBits(saved, --r.topLeft.x, --r.topLeft.y);

    if (AppsPopupCount) {
        frm = FrmGetActiveForm();
        lst = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, listid));
        LstSetDrawFunction(lst, (ListDrawDataFuncPtr) AppsPopupDrawItem);

        LstSetListChoices(lst, NULL, AppsPopupCount);
        LstSetSelection(lst, curSelection);
        LstSetTopItem(lst, curSelection);

        newSelection = LstPopupList(lst);

        if ((newSelection != curSelection) && (newSelection != -1)) {
            listP = MemHandleLock((VoidHand) AppsPopupH);
            if (DmDatabaseInfo(listP[newSelection].cardNo,
                listP[newSelection].dbID, hdr.name, NULL, NULL, NULL, NULL,
                NULL, NULL, NULL, NULL, NULL, &hdr.creator) == 0) {
                newcreator = hdr.creator;
                /*
                 * Copy the name into the popup trigger label.
                 */
                trig = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, triggerid));
                label = CtlGetLabel(trig);
                StrCopy(label, hdr.name);
                CtlSetLabel(trig, label);
            }
            MemPtrUnlock(listP);
        }
    }
    
    if (AppsPopupH) MemHandleFree((VoidHand) AppsPopupH);

    return newcreator;
}

void CheckPrefsR(void)
{
    /*
     * Do some sanity checks and rewrite the numeric fields to get
     * rid of whitespace or extraneous characters.  Maybe later on
     * I can figure out how to validate this in the input fields.
     */
    numtotxt(StrAToI(PrefsR->POPPrefs.startmsg), tnum, false);
    MemSet(PrefsR->POPPrefs.startmsg, sizeof(PrefsR->POPPrefs.startmsg), 0);
    StrCopy(PrefsR->POPPrefs.startmsg, tnum);
    if (StrAToI(PrefsR->POPPrefs.startmsg) < 1) {
        MemSet(PrefsR->POPPrefs.startmsg,
            sizeof(PrefsR->POPPrefs.startmsg), 0);
        StrCopy(PrefsR->POPPrefs.startmsg,
            DefaultPrefsR.POPPrefs.startmsg);
        PrefsRdirty = true;
    }
    numtotxt(StrAToI(PrefsR->POPPrefs.maxlines), tnum, false);
    MemSet(PrefsR->POPPrefs.maxlines, sizeof(PrefsR->POPPrefs.maxlines), 0);
    StrCopy(PrefsR->POPPrefs.maxlines, tnum);
    if (StrAToI(PrefsR->POPPrefs.maxlines) < 0) {
        MemSet(PrefsR->POPPrefs.maxlines,
            sizeof(PrefsR->POPPrefs.maxlines), 0);
        StrCopy(PrefsR->POPPrefs.maxlines,
            DefaultPrefsR.POPPrefs.maxlines);
        PrefsRdirty = true;
    }
    numtotxt(StrAToI(PrefsR->Prefs.leavefree), tnum, false);
    MemSet(PrefsR->Prefs.leavefree, sizeof(PrefsR->Prefs.leavefree), 0);
    StrCopy(PrefsR->Prefs.leavefree, tnum);
    if (StrAToI(PrefsR->Prefs.leavefree) < 0) {
        MemSet(PrefsR->Prefs.leavefree,
            sizeof(PrefsR->Prefs.leavefree), 0);
        StrCopy(PrefsR->Prefs.leavefree,
            DefaultPrefsR.Prefs.leavefree);
        PrefsRdirty = true;
    }
}

void ReadPrefsRec(void)
{
    Ptr p;
    short i;
    if (MainDB) {
        p = MemHandleLock(PrefsRecHandle);
        MemMove(PrefsR, p, sizeof(struct sPrefsR));
        MemPtrUnlock(p);
        PrefsRdirty = false;
        PrefsWeredirty = false;
        /* Set up the appID array for the icons */
        for (i=0; i < 6; i++) {
            MemMove(&Prefslaunch[i], PrefsR->Prefs.launch[i],
                sizeof(Prefslaunch[i]));
        }
    }
    CheckPrefsR();
}

void WritePrefsRec(void)
{
    Ptr p;
    Err err;
    CheckPrefsR();
    if (MainDB) {
        p = MemHandleLock(PrefsRecHandle);
        err = DmWrite(p, 0, PrefsR, sizeof(struct sPrefsR));
        ErrFatalDisplayIf(err, "Could not write prefs.");
        MemPtrUnlock(p);
        /*
         * This is set until we exit the app at which time the ReleaseRecord()
         * is called.
         */
        PrefsWeredirty = true;
        PrefsRdirty = false;
    }
}

void LoadPrefsFields(void)
{
    FormPtr frm;
	ControlPtr ctl;
	CharPtr label;
    UInt cardNo;
    LocalID dbID;
    DmSearchStateType searchInfo;
	DatabaseHdrType hdr;
    LocalID appInfoID, sortInfoID;
    ULong AppID;
    short i;

    if ((frm = FrmGetFormPtr(PrefsForm)) == 0) return;
    /* Memory to leave free */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_prefsleavefree)), PrefsR->Prefs.leavefree,
        StrLen(PrefsR->Prefs.leavefree));
    /* Disable auto-off during transfer */
    if (PrefsR->Prefs.noautooff == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsnoautooff)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsnoautooff)), 0);
    /* Attempt text reformatting */
    if (PrefsR->Prefs.reformat == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsreformat)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsreformat)), 0);
    /* Make beep when done */
    if (PrefsR->Prefs.makebeep == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsmakebeep)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsmakebeep)), 0);
    /* Launches; assumes that IDs are consecutive */
    for (i=0; i < 6; i++) {
        ctl = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            popuptriggerID_prefslaunch1+i));
        label = CtlGetLabel(ctl);
        MemMove(&AppID, PrefsR->Prefs.launch[i], sizeof(AppID));
        Prefslaunch[i] = AppID;
        if (DmGetNextDatabaseByTypeCreator(true, &searchInfo, 
            sysFileTApplication, AppID, true, &cardNo, &dbID) == 0) {
            if (DmDatabaseInfo(cardNo, dbID, hdr.name, &hdr.attributes,
                &hdr.version, &hdr.creationDate, &hdr.modificationDate,
                &hdr.lastBackupDate, &hdr.modificationNumber,
                &appInfoID, &sortInfoID, &hdr.type, &hdr.creator) == 0) {
                StrCopy(label, hdr.name);
                CtlSetLabel(ctl, label);
            }
        }
    }
}

void UnloadPrefsFields(Boolean save)
{
    FormPtr frm;
    VoidPtr obj;
    char *ts;
    short i;
    
    if ((frm = FrmGetFormPtr(PrefsForm)) == 0) return;
    /* Memory to leave free */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_prefsleavefree));
    if (save) {
        MemSet(PrefsR->Prefs.leavefree,
            sizeof(PrefsR->Prefs.leavefree), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->Prefs.leavefree, ts, StrLen(ts));
    }
    if (save) {
        /* Disable auto-off during transfer */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsnoautooff))) == 1)
            PrefsR->Prefs.noautooff = '1';
        else PrefsR->Prefs.noautooff = '0';
        /* Attempt text reformatting */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsreformat))) == 1)
            PrefsR->Prefs.reformat = '1';
        else PrefsR->Prefs.reformat = '0';
        /* Make beep when done */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_prefsmakebeep))) == 1)
            PrefsR->Prefs.makebeep = '1';
        else PrefsR->Prefs.makebeep = '0';
        /* Launches */
        for (i=0; i < 6; i++) {
            MemMove(PrefsR->Prefs.launch[i], &Prefslaunch[i],
                sizeof(Prefslaunch[i]));
        }
        BuildIcons(); /* cause it to rebuild the launch icon records */
    } else {
        /* revert a few settings */
        for (i=0; i < 6; i++) {
            MemMove(&Prefslaunch[i], PrefsR->Prefs.launch[i],
                sizeof(Prefslaunch[i]));
        }
    }
}

void LoadSMTPPrefsFields(void)
{
    FormPtr frm;
    if ((frm = FrmGetFormPtr(SMTPPrefsForm)) == 0) return;
    /* SMTP Server */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpserver)), PrefsR->SMTPPrefs.server,
        StrLen(PrefsR->SMTPPrefs.server));
    /* SMTP Port */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpport)), PrefsR->SMTPPrefs.port,
        StrLen(PrefsR->SMTPPrefs.port));
    /* Your Email */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpemail)), PrefsR->SMTPPrefs.email,
        StrLen(PrefsR->SMTPPrefs.email));
    /* Your Name */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpname)), PrefsR->SMTPPrefs.name,
        StrLen(PrefsR->SMTPPrefs.name));
    /* Additional Bcc */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpaddbcc)), PrefsR->SMTPPrefs.addbcc,
        StrLen(PrefsR->SMTPPrefs.addbcc));
    /* Move to Filed */
    if (PrefsR->SMTPPrefs.filed == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfiled)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfiled)), 0);
    /* POP auth */
    if (PrefsR->SMTPPrefs.fakepop == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfakepop)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfakepop)), 0);
}

void UnloadSMTPPrefsFields(Boolean save)
{
    FormPtr frm;
    VoidPtr obj;
    char *ts;
    if ((frm = FrmGetFormPtr(SMTPPrefsForm)) == 0) return;
    /* SMTP Server */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpserver));
    if (save) {
        MemSet(PrefsR->SMTPPrefs.server,
            sizeof(PrefsR->SMTPPrefs.server), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->SMTPPrefs.server, ts, StrLen(ts));
    }
    /* SMTP Port */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpport));
    if (save) {
        MemSet(PrefsR->SMTPPrefs.port,
            sizeof(PrefsR->SMTPPrefs.port), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->SMTPPrefs.port, ts, StrLen(ts));
    }
    /* Your Email */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpemail));
    if (save) {
        MemSet(PrefsR->SMTPPrefs.email,
            sizeof(PrefsR->SMTPPrefs.email), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->SMTPPrefs.email, ts, StrLen(ts));
    }
    /* Your Name */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpname));
    if (save) {
        MemSet(PrefsR->SMTPPrefs.name,
            sizeof(PrefsR->SMTPPrefs.name), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->SMTPPrefs.name, ts, StrLen(ts));
    }
    /* Additional Bcc */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_smtpaddbcc));
    if (save) {
        MemSet(PrefsR->SMTPPrefs.addbcc,
            sizeof(PrefsR->SMTPPrefs.addbcc), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->SMTPPrefs.addbcc, ts, StrLen(ts));
    }
    /* Move to Filed */
    if (save) {
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfiled))) == 1)
            PrefsR->SMTPPrefs.filed = '1';
        else PrefsR->SMTPPrefs.filed = '0';
    }
    /* POP auth */
    if (save) {
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_smtpfakepop))) == 1)
            PrefsR->SMTPPrefs.fakepop = '1';
        else PrefsR->SMTPPrefs.fakepop = '0';
    }
}

void LoadPOPPrefsFields(void)
{
    FormPtr frm;
    if ((frm = FrmGetFormPtr(POPPrefsForm)) == 0) return;
    /* POP Server */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popserver)), PrefsR->POPPrefs.server,
        StrLen(PrefsR->POPPrefs.server));
    /* POP Port */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popport)), PrefsR->POPPrefs.port,
        StrLen(PrefsR->POPPrefs.port));
    /* User */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popuser)), PrefsR->POPPrefs.user,
        StrLen(PrefsR->POPPrefs.user));
    /* Max msg lines */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popmaxlines)), PrefsR->POPPrefs.maxlines,
        StrLen(PrefsR->POPPrefs.maxlines));
    /* Starting message number */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popstartmsg)), PrefsR->POPPrefs.startmsg,
        StrLen(PrefsR->POPPrefs.startmsg));
    /* Detect mailbox reset */
    if (PrefsR->POPPrefs.detectreset == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdetectreset)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdetectreset)), 0);
    /* Delete messages from server */
    if (PrefsR->POPPrefs.deletemsg == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdeletemsg)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdeletemsg)), 0);
    /* Use APOP for authentication */
    if (PrefsR->POPPrefs.useapop == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popuseapop)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popuseapop)), 0);
}

void UnloadPOPPrefsFields(Boolean save)
{
    FormPtr frm;
    VoidPtr obj;
    char *ts;
    if ((frm = FrmGetFormPtr(POPPrefsForm)) == 0) return;
    /* POP Server */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popserver));
    if (save) {
        MemSet(PrefsR->POPPrefs.server,
            sizeof(PrefsR->POPPrefs.server), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->POPPrefs.server, ts, StrLen(ts));
    }
    /* POP Port */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popport));
    if (save) {
        MemSet(PrefsR->POPPrefs.port,
            sizeof(PrefsR->POPPrefs.port), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->POPPrefs.port, ts, StrLen(ts));
    }
    /* User */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popuser));
    if (save) {
        MemSet(PrefsR->POPPrefs.user,
            sizeof(PrefsR->POPPrefs.user), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->POPPrefs.user, ts, StrLen(ts));
    }
    /* Max msg lines */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popmaxlines));
    if (save) {
        MemSet(PrefsR->POPPrefs.maxlines,
            sizeof(PrefsR->POPPrefs.maxlines), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->POPPrefs.maxlines, ts, StrLen(ts));
    }
    /* Starting message number */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_popstartmsg));
    if (save) {
        MemSet(PrefsR->POPPrefs.startmsg,
            sizeof(PrefsR->POPPrefs.startmsg), 0);
        if ((ts = FldGetTextPtr(obj)))
            MemMove(PrefsR->POPPrefs.startmsg, ts, StrLen(ts));
    }
    /* Detect mailbox reset */
    if (save) {
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdetectreset))) == 1)
            PrefsR->POPPrefs.detectreset = '1';
        else PrefsR->POPPrefs.detectreset = '0';
    }
    /* Delete messages from server */
    if (save) {
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popdeletemsg))) == 1)
            PrefsR->POPPrefs.deletemsg = '1';
        else PrefsR->POPPrefs.deletemsg = '0';
    }
    /* Use APOP for authentication */
    if (save) {
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_popuseapop))) == 1)
            PrefsR->POPPrefs.useapop = '1';
        else PrefsR->POPPrefs.useapop = '0';
    }
}

void LoadSendFilesPrefsFields(void)
{
    FormPtr frm;
    if ((frm = FrmGetFormPtr(SendFilesForm)) == 0) return;
    /* Send to Email */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_sendfilesemail)), PrefsR->SendFilesPrefs.email,
        StrLen(PrefsR->SendFilesPrefs.email));
    /* X-GNUGotMail-Secret */
    FldInsert(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_sendfilessecret)), PrefsR->SendFilesPrefs.secret,
        StrLen(PrefsR->SendFilesPrefs.secret));
    /* Send all files (full backup) */
    if (PrefsR->SendFilesPrefs.all == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesall)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesall)), 0);
    /* Fast (dirty & deleted records) */
    if (PrefsR->SendFilesPrefs.fast == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesfast)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesfast)), 0);
    /* Clear dirty bits when done */
    if (PrefsR->SendFilesPrefs.clear == '1')
        CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesclear)), 1);
    else CtlSetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesclear)), 0);
}

/*
 * Since the Send Files dialog is confirmed (thereby saving prefs) during
 * normal operation, I put some tests in here to see if I can cut down on
 * the prefs updates.  I didn't do it to the other ones because you can
 * always press cancel on those dialogs if you don't want to save.
 */
Boolean UnloadSendFilesPrefsFields(Boolean save)
{
    FormPtr frm;
    VoidPtr obj;
    char *ts;
    Boolean changed=false;
    if ((frm = FrmGetFormPtr(SendFilesForm)) == 0) return save;
    /* Send to Email */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_sendfilesemail));
    if (save) {
        if ((ts = FldGetTextPtr(obj))) {
            if (StrCompare(PrefsR->SendFilesPrefs.email, ts) != 0) {
                changed = true;
                MemSet(PrefsR->SendFilesPrefs.email,
                    sizeof(PrefsR->SendFilesPrefs.email), 0);
                MemMove(PrefsR->SendFilesPrefs.email, ts, StrLen(ts));
            }
        }
    }
    /* X-GNUGotMail-Secret */
    obj = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
        fieldID_sendfilessecret));
    if (save) {
        if ((ts = FldGetTextPtr(obj))) {
            if (StrCompare(PrefsR->SendFilesPrefs.secret, ts) != 0) {
                changed = true;
                MemSet(PrefsR->SendFilesPrefs.secret,
                    sizeof(PrefsR->SendFilesPrefs.secret), 0);
                MemMove(PrefsR->SendFilesPrefs.secret, ts, StrLen(ts));
            }
        }
    }
    if (save) {
        /* Send all files (full backup) */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesall))) == 1) {
            if (PrefsR->SendFilesPrefs.all != '1') changed = true;
            PrefsR->SendFilesPrefs.all = '1';
        } else {
            if (PrefsR->SendFilesPrefs.all != '0') changed = true;
            PrefsR->SendFilesPrefs.all = '0';
        }
        /* Fast (dirty & deleted records) */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesfast))) == 1) {
            if (PrefsR->SendFilesPrefs.fast != '1') changed = true;
            PrefsR->SendFilesPrefs.fast = '1';
        } else {
            if (PrefsR->SendFilesPrefs.fast != '0') changed = true;
            PrefsR->SendFilesPrefs.fast = '0';
        }
        /* Clear dirty bits when done */
        if (CtlGetValue(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,
            checkboxID_sendfilesclear))) == 1) {
            if (PrefsR->SendFilesPrefs.clear != '1') changed = true;
            PrefsR->SendFilesPrefs.clear = '1';
        } else {
            if (PrefsR->SendFilesPrefs.clear != '0') changed = true;
            PrefsR->SendFilesPrefs.clear = '0';
        }
    }
    return changed;
}

/*
 * The program starts here.
 */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
    Word err;
    DWord romVersion;
    ULong theInstalledRAM; 

    if (cmd == sysAppLaunchCmdNormalLaunch) {
        /*
         * This ROM version test comes from Palm's Address application.
         * Thankfully too because I would hate to guess at this kind of
         * stuff and make some poor guy's Pilot blow up.
         */
        FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
        /*
         * Need at least a PalmPilot Pro because of the TCP/IP.
         */
        if (romVersion < 0x03000000) {
            if ((launchFlags &
                (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
                (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) {
                /*
                 * Pilot 1.0 will continuously relaunch this app unless we
                 * switch to another safe one.
                 */
                if (romVersion < 0x02000000) {
                    FrmAlert(RomIncompatibleAlert);
                    AppLaunchWithCommand(sysFileCDefaultApp,
                        sysAppLaunchCmdNormalLaunch, NULL);
                }
                err = MemCardInfo( 0, NULL, NULL, NULL, NULL, NULL,
                    &theInstalledRAM, NULL); 
                if (!err && (theInstalledRAM == 524288)) { 
                    /*
                     * We are running on a PalmPilot Personal unit
                     */
                    FrmAlert(RomIncompatibleAlert);
                    return sysErrRomIncompatible;
                }
               }
        }
        /*
         * I guess we are an appropriate ROM version so let's run.
         */
        err = StartApplication();
        if (err) return err;
        EventLoop();
        StopApplication();
    } else {
        return sysErrParamErr;
    }

    return 0;
}
