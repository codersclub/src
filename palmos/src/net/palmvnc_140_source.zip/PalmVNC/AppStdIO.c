/***********************************************************************
 *
 *	Copyright (c) Palm Computing 1997 -- All Rights Reserved ip_rcv
 *
 * PROJECT:  Any Pilot app that wants a stdio window
 * FILE:     AppStdIO.c
 *
 * DESCRIPTION:
 *	  This module implements stdin/stdout support for a pilot application.
 * It requires that the application provide a form with a text field and
 * scroll bar
 *
 *   The application code must call StdInit() and pass the resource ID's
 * of the form, field, and scroll bar along with other settings
 * before using any of the other calls.
 *
 *   See "AppStdIO.h" for a complete description of how to use this
 *	module. 
 *
 **********************************************************************/

#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <KeyMgr.h>

#include <unix_stdarg.h>

#include "AppStdIO.h"



#if EMULATION_LEVEL == EMULATION_NONE

/*********************************************************************
 * This stuff is needed if building for the device.
 *******************************************************************/


/*********************************************************************
 * Globals
 * These are initialized by parameters passed to StdInit().
 *******************************************************************/
static VoidHand PrvTextH = NULL;  	// holds latest text

static Word		 PrvFormID = 0;		// Form ID that contains text field
static Word		 PrvFieldID = 0;		// Field ID 
static Word		 PrvScrollerID = 0;


/***********************************************************************
 *
 * FUNCTION:		PrvCloneStr
 *
 * DESCRIPTION:	Allocates a handle and stuffs srcStr into it.
 *
 * CALLED BY:		 
 *
 * PARAMETERS:		srcStr - pointer to string to initialize handle with
 *
 * RETURNED:    	 
 *
 ***********************************************************************/
static Handle PrvCloneStr(CharPtr srcStr)
{
	Word		len;
	VoidHand 	stringH;
	CharPtr 	stringP;
	
	len = StrLen(srcStr);
	if (!len) return NULL;
	
	stringH = MemHandleNew((ULong)(len+1));
	if (stringH) {
		stringP = MemHandleLock(stringH);
		StrCopy(stringP,srcStr);
		MemPtrUnlock(stringP);
		}
	return (Handle)stringH;
}



/***********************************************************************
 *
 * FUNCTION:		PrvHandleStrCat
 *
 * DESCRIPTION:	Catenates a string into an existing handle
 *
 * CALLED BY:		 
 *
 * PARAMETERS:		stringH 	- existing handle with text
 *						srcP		- pointer to text to catenate
 *
 * RETURNED:    	 
 *
 ***********************************************************************/
static void PrvHandleStrCat(VoidHand stringH, CharPtr srcP)
{
	Word newSize,oldLength;
	CharPtr stringP;
	
	newSize = StrLen(srcP) + 1;					// initialize new size
	
	// Resize the existing handle, if any
	if ( stringH ) {
		stringP = MemHandleLock( stringH );
		oldLength = StrLen(stringP);
		newSize += oldLength;
		MemPtrUnlock( stringP );
		if ( MemHandleResize(stringH, newSize) == 0) {	// Append the new text
			stringP = MemHandleLock( stringH );
			StrCopy( stringP + oldLength, srcP );			// copy the new text
			MemPtrUnlock( stringP );
			}
		}
}



/***********************************************************************
 *
 * FUNCTION:		StdVPrintF
 *
 * DESCRIPTION:	Utility used to implement printf and fprintf
 *
 * CALLED BY:		StdPrintF, StdFPrintF
 *
 * PARAMETERS:		formatStr - format string
 *						args		 - pointer to argument list.
 *
 * RETURNED:    	# of characters sent to stdout.
 *
 ***********************************************************************/
int	StdVPrintF(const CharPtr formatStr, va_list args)
{
	SWord				result;
	const	UInt		textLen = 0x1FF;
	static Char		text[0x1FF+1]; // static so we don't eat up stack space
	
	// Crude check for overflow on the formatStr
	if (StrLen(formatStr) < textLen/2) {
		result = StrVPrintF(text, formatStr, args);
		StdPutS(text);
		}
	else {
		StdPutS(formatStr);
		result = StrLen(formatStr);
		}
		
	return result;
}


/***********************************************************************
 *
 * FUNCTION:    PrvGetObjectPtr
 *
 * DESCRIPTION: This routine returns a pointer to an object in the current
 *              form.
 *
 * PARAMETERS:  objectID - which object.
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static VoidPtr PrvGetObjectPtr (Word objectID)
{
	FormPtr frm;
	VoidPtr obj;
	
	frm = FrmGetActiveForm ();
	obj = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, objectID));

	return obj;
}




/***********************************************************************
 *
 * FUNCTION:	SetFieldText
 *
 * DESCRIPTION:	Set field object's text handle.  Will reuse an existing
 *						text handle, if any
 *
 * PARAMETERS:	fldID		-- field object id
 *					srcP		-- source text pointer
 *					append	-- if true, the new text will be appended
 *					redraw	-- if true, field will be redrawn
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *
 ***********************************************************************/
static void PrvSetFieldText(Word fldID, CharPtr srcP, Boolean append,
								Boolean redraw)
{
	Handle 		stringH;
	UInt			oldLength = 0;
	UInt			newSize;
	CharPtr 		stringP;
	FieldPtr		fldP;

	fldP = (FieldPtr)PrvGetObjectPtr(fldID);

	if (!srcP || !*srcP) {						// handle clearing field as well
		FldFreeMemory(fldP);
		if ( redraw )	 {
			FldEraseField( fldP );
			FldDrawField( fldP );
			}
		return;
		}
	
	
	newSize = StrLen(srcP) + 1;					// initialize new size
	stringH = FldGetTextHandle( fldP );			// get the current text handle
	FldSetTextHandle( fldP, 0 );					// release this handle from field

	// Resize the existing handle, if any
	if ( stringH ) {
		if ( append ) {
			stringP = MemHandleLock( (VoidHand)stringH );
			oldLength = StrLen(stringP);
			newSize += oldLength;
			MemPtrUnlock( stringP );
			}
		if ( MemHandleResize((VoidHand)stringH, newSize) )
			goto Exit;
		} // Resize the existing handle, if any
	
	// Otherwise, allocate a new handle
	else {
		stringH = (Handle)MemHandleNew( newSize );		// allocate a new chunk
		if ( !stringH )	return;
		}

	// Append the new text
	stringP = MemHandleLock( (VoidHand)stringH );
	StrCopy( stringP + oldLength, srcP );		// copy the new text
	MemPtrUnlock( stringP );
	
Exit:
	FldSetTextHandle( fldP, stringH );			// set the new text handle
	if ( redraw )	 {
		FldEraseField( fldP );
		FldDrawField( fldP );
		}
}



/***********************************************************************
 *
 * FUNCTION:    PrvFormUpdateScroller
 *
 * DESCRIPTION: This routine draws or erases the status view scrollbar
 *
 * PARAMETERS:  frm             -  pointer to the status form
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/7/95	Initial Revision
 *
 ***********************************************************************/
static void PrvFormUpdateScroller (FormPtr frm)
{
	Word 				scrollPos;
	Word 				textHeight;
	Word 				fieldHeight;
	Short 			maxValue;
	FieldPtr 		fld;
	ScrollBarPtr 	bar;

	fld = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, PrvFieldID));
	bar = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, PrvScrollerID));
	
	FldGetScrollValues (fld, &scrollPos, &textHeight,  &fieldHeight);

	if (textHeight > fieldHeight)
		maxValue = textHeight - fieldHeight;
	else
		maxValue = 0;

	SclSetScrollBar (bar, scrollPos, 0, maxValue, fieldHeight-1);
}



/***********************************************************************
 *
 * FUNCTION:    PrvFieldScroll
 *
 * DESCRIPTION: Scrolls the status view a page or a 
 *              line at a time.
 *
 * PARAMETERS:  direction - up or dowm
 *              oneLine   - true if scrolling a single line
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/7/95	Initial Revision
 *
 ***********************************************************************/
static void PrvFieldScroll (SWord linesToScroll)
{
	/*
	fld = PrvGetObjectPtr (PrvFieldID);
	if (FldScrollable (fld, direction)) {
		if (oneLine)
			linesToScroll = 1;
		else
			linesToScroll = FldGetVisibleLines (fld) - 1;
			
		FldScrollField (fld, linesToScroll, direction);
		PrvFormUpdateScroller (FrmGetActiveForm());
		}
	*/


	Word				blankLines;
	Short				min;
	Short				max;
	Short				value;
	Short				pageSize;
	FieldPtr			fld;
	ScrollBarPtr	bar;
	
	fld = PrvGetObjectPtr (PrvFieldID);

	if (linesToScroll < 0) {
		blankLines = FldGetNumberOfBlankLines (fld);
		FldScrollField (fld, -linesToScroll, winUp);
		
		// If there were blank lines visible at the end of the field
		// then we need to update the scroll bar.
		if (blankLines) {
			// Update the scroll bar.
			bar = PrvGetObjectPtr (PrvScrollerID);
			SclGetScrollBar (bar, &value, &min, &max, &pageSize);
			if (blankLines > -linesToScroll)
				max += linesToScroll;
			else
				max -= blankLines;
			SclSetScrollBar (bar, value, min, max, pageSize);
			}
		}

	else if (linesToScroll > 0)
		FldScrollField (fld, linesToScroll, winDown);

}

/***********************************************************************
 *
 * FUNCTION:    PrvFieldPageScroll
 *
 * DESCRIPTION: Scroll the owner message a page up or down.
 *
 * PARAMETERS:  direction - up or down
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			rsf	8/7/96	Initial Revision
 *
 ***********************************************************************/
static void PrvFieldPageScroll (WinDirectionType direction)
{
	Short value;
	Short min;
	Short max;
	Short pageSize;
	Word linesToScroll;
	FieldPtr fld;
	ScrollBarPtr bar;

	fld = PrvGetObjectPtr (PrvFieldID);
	
	if (FldScrollable (fld, direction)) {
		linesToScroll = FldGetVisibleLines (fld) - 1;
		FldScrollField (fld, linesToScroll, direction);

		// Update the scroll bar.
		bar = PrvGetObjectPtr (PrvScrollerID);
		SclGetScrollBar (bar, &value, &min, &max, &pageSize);

		if (direction == winUp)
			value -= linesToScroll;
		else
			value += linesToScroll;
		
		SclSetScrollBar (bar, value, min, max, pageSize);
		return;
		}
}


/***********************************************************************
 *
 * FUNCTION:    PrvFormInit
 *
 * DESCRIPTION: This routine initializes the "Status View"
 *
 * PARAMETERS:  frm  - a pointer to the Status form
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	7/15/96	Initial Revision
 *
 ***********************************************************************/
static void PrvFormInit (FormPtr frm)
{
	FieldAttrType 	attr;
	FieldPtr 		fldP;


	if (!PrvTextH)
		PrvTextH = (VoidHand)PrvCloneStr(" ");
		
	// Get the field ptr
	fldP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, PrvFieldID));
	
	// Indicate that it has a scroll bar
	FldGetAttributes (fldP, &attr);
	attr.hasScrollBar = true;
	FldSetAttributes (fldP, &attr);
	
	// Initialize it's text
	FldSetTextHandle( fldP, (Handle)PrvTextH );			// set the new text handle
	
	// No longer need background copy
	PrvTextH = 0;
	
}


/***********************************************************************
 *
 * FUNCTION:    PrvFormClose
 *
 * DESCRIPTION: Closes down the stdio form
 *
 * PARAMETERS:  frm  - a pointer to the Status form
 *
 * RETURNED:    nothing
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			gavin	7/15/96	Initial Revision
 *
 ***********************************************************************/
static void PrvFormClose (FormPtr frm)
{
	FieldPtr fldP;
	
	fldP = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, PrvFieldID));
	
	// Save the current handle
	if (PrvTextH) MemHandleFree(PrvTextH);
	PrvTextH = (VoidHand)FldGetTextHandle(fldP);
	
	// Take it out of the field object.
	FldSetTextHandle( fldP, NULL );			// remove the handle so it 
														//  isn't freed
}


/***********************************************************************
 *
 * FUNCTION:    PrvFormDraw
 *
 * DESCRIPTION: This routine draws the "Sync View"
 *
 * PARAMETERS:  frm - pointer to the view form.
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			vmk	10/16/95	Initial Revision
 *
 ***********************************************************************/
static void PrvFormDraw(FormPtr frm)
{
	PrvFormUpdateScroller ( frm );
}


/***********************************************************************
 *
 * FUNCTION:		StdPutS
 *
 * DESCRIPTION:	Utility used to print a string to stdout
 *
 * CALLED BY:		Applications.
 *
 * PARAMETERS:		str - string to print
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
void StdPutS (CharPtr str)
{	
	FieldPtr 	fldP;
	Word			maxSize;
	CharPtr		textP;
	Word			pos;
	
	if (FrmGetActiveFormID() == PrvFormID) {
		fldP = (FieldPtr)PrvGetObjectPtr(PrvFieldID);
		
		// Make sure there's room for this new text
		maxSize = FldGetMaxChars(fldP);
		textP = FldGetTextPtr(fldP);
		
		// If not enough room, lop off the top.
		if (textP) {
			if (StrLen(textP) + StrLen(str) >= maxSize) {
				RectangleType	clipR, savedClipR;

				// Clip off everything so that field package doesn't
				//  do a redraw during FldDelete()
				WinGetClip (&savedClipR);
				clipR = savedClipR;
				clipR.extent.x = clipR.extent.y = 0;
				WinSetClip (&clipR);

				// Lop off the top
				pos = FldGetInsPtPosition(fldP);
				FldDelete(fldP, 0, maxSize/4);
				FldSetInsPtPosition(fldP, pos);

				// Restore clip region.
				WinSetClip (&savedClipR);
				}
			}
		
		// Insert the new text
		FldInsert(fldP, str, StrLen(str));
		PrvFormUpdateScroller (FrmGetActiveForm());
		}
		
	else  {	
		if (PrvTextH)
			PrvHandleStrCat(PrvTextH, str);
		else
			PrvTextH = (VoidHand)PrvCloneStr(str);
		}
}



/***********************************************************************
 *
 * FUNCTION:		StdClear
 *
 * DESCRIPTION:	Clear the "screen"
 *
 * CALLED BY:		Applications.
 *
 * PARAMETERS:		void
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
void StdClear(void)
{
	if (FrmGetActiveFormID() == PrvFormID) {
		PrvSetFieldText(PrvFieldID, NULL, false, true);
		PrvFormUpdateScroller (FrmGetActiveForm());
		}
	else {
		if (PrvTextH) MemHandleFree(PrvTextH);
		PrvTextH = NULL;
		}
}






/******************************************************************************
 * The "printf" routine
 *****************************************************************************/
int	StdPrintF(const CharPtr formatStr, ...)
{
	va_list			args;
	SWord				result;
	
	va_start(args, formatStr);
	result = StdVPrintF(formatStr, args);
	va_end(args);
	
	return result;
}



/***********************************************************************
 *
 * FUNCTION:    StdHandleEvent
 *
 * DESCRIPTION: Handles events in the form that contains the
 *		stdio text field and scroll arrows if the event belongs to
 *		the text field or scroll arrows.
 *
 *		This routine should be called from the form event handler
 *		before it does it's own processing with any of the non stdio 
 *		objects in the form.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event was handled and should not be 
 *						processed by the app's own form event handler. 
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			roger	8/7/95	Initial Revision
 *
 ***********************************************************************/
Boolean StdHandleEvent (EventPtr event)
{
	FormPtr 			frmP;
	Boolean 			handled = false;


	if (event->eType == keyDownEvent) {

		if ( event->data.keyDown.chr == pageUpChr ) {
			PrvFieldPageScroll (winUp);
			handled = true;
			}
		
		else if ( event->data.keyDown.chr == pageDownChr ) {
			PrvFieldPageScroll (winDown);
			handled = true;
			}
		}


	else if (event->eType == sclRepeatEvent)
		{
		PrvFieldScroll (event->data.sclRepeat.newValue - 
			event->data.sclRepeat.value);
		}



	else if (event->eType == frmUpdateEvent) {
		PrvFormDraw( FrmGetActiveForm() );
		}
		
	else if (event->eType == fldChangedEvent) {
		PrvFormUpdateScroller( FrmGetActiveForm() );
		handled = true;
		}
		
		
	else if (event->eType == frmOpenEvent) {
		frmP = FrmGetActiveForm();
		PrvFormInit( frmP );
		PrvFormDraw( frmP );
		FrmSetFocus( frmP, FrmGetObjectIndex (frmP, PrvFieldID)) ;
		}
		
		
	else if (event->eType == frmCloseEvent) {
		frmP = FrmGetActiveForm();
		PrvFormClose(frmP);
		}
		
	return (handled);
}


/***********************************************************************
 *
 * FUNCTION:		StdInit
 *
 * DESCRIPTION:	Initialize the standard IO manager.
 *
 * CALLED BY:		Application during it's startup.
 *
 * PARAMETERS:		 
 *
 * RETURNED:    	 
 *
 ***********************************************************************/
Err	StdInit(Word formID, Word fieldID, Word scrollerID )
{
	
	// Save globals
	PrvFormID = formID;
	PrvFieldID = fieldID;
	PrvScrollerID = scrollerID;

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:		StdFree
 *
 * DESCRIPTION:	Closes down the standard IO manager.
 *
 * CALLED BY:		Application during it's shutdown.
 *
 * PARAMETERS:		 
 *
 * RETURNED:    	 
 *
 ***********************************************************************/
Err	StdFree(void)
{
	// Free the text handle
	if (PrvTextH) MemHandleFree(PrvTextH);
	PrvTextH = 0;
	
	// Clear globals
	PrvFormID = 0;
	PrvFieldID = 0;
	PrvScrollerID = 0;
	
	
	return 0;	
	
}

#endif	// EMULATION_LEVEL == EMULATION_NONE


/***********************************************************************
 *
 * FUNCTION: StdSave (VM)
 *
 * DESCRIPTION:	Saves the content of IO before leave the IO form
 *
 * CALLED BY: Application during before changing to another form with
 *            FrmReturnToForm().
 *
 * PARAMETERS:		 
 *
 * RETURNED:    	 
 *
 ***********************************************************************/
Err	StdSave(void)
{
  PrvFormClose(FrmGetActiveForm());
  return 0;
}


