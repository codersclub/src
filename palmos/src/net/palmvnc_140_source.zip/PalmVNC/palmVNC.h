/*
 *  Copyright (C) 1998 International Computer Science Institute (ICSI)
 *
 *  Author: Vladimir Minenko, minenko@icsi.berkeley.edu
 *
 *  This is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 *  USA.
 */


#include <PalmOS.h>
#include <PalmCompatibility.h>

#include <NetMgr.h>

// Include this header so that we can use the Berkeley sockets API
#include <sys_socket.h>

#define CARD8		unsigned char
#define CARD16		unsigned short
#define CARD32		unsigned long
#define Bool		Boolean
#define False		false
#define True		true

#include <rfbproto.h>
#include <AppStdIO.h>


#define PALMVNC_VERSION "1.40"
#define PALMVNC_DB_VERSION 140
#define CREATOR_ID		'PVNC'
#define DATABASE_NAME		"PalmVNCDB"

#define Swap16IfLE(s) s
#define Swap32IfLE(l) l

#define MAX_ENCODINGS 10

#define VNC_DATA_PORT_NR		5900

#define SCROLLBAR_SIZE			4
#define	VIEWABLE_MAX_H			160
#define	VIEWABLE_MAX_W			160
#define	VIRTUAL_20_MAX_H		156
#define	VIRTUAL_20_MAX_W		156
#define	VIRTUAL_30_MAX_H		156
#define	VIRTUAL_30_MAX_W		156

#ifdef DEBUG
//#define DEBUG_VNC_CODING 	// all VNC protocol stuff, very intensive
//#define DEBUG_EVENTS		// PalmOS evetns
//#define DEBUG_FLOW 		// misc. program flow
//#define DEBUG_COLOR		// color mapping
#endif

/* defines boudaries of the Pilot viewport */
typedef struct {
  rfbRectangle	desktop;	// Dimensions of unscaled desktop
  unsigned short scaleFactor; // Scale factor for current viewport
  rfbRectangle	viewable;	// what is visible
  rfbRectangle	virtual;	// what is in the off-screen window
  rfbRectangle	remote;		// what is on the server side
  rfbRectangle	zoomarea;	// specified zoom coordinates
  Boolean		zoomarea_ena; // Use specified zoom coordinates
} PRFBViewport;

typedef struct {
  UInt16 index;			// Database index for this server
  char name[32];		// VNC server display name
  char address[32];		// VNC server address (IP, or DNS name)
  short port;			// VNC port number
  char password[32];		// VNC password
  unsigned short beginX;	// initial coordinate X on the desktop
  unsigned short beginY;
  unsigned short scaleFactor; // Default scale factor
  Boolean sharedDesktop;	// share desktop with other viewer?
  char loginNameNT[32];		// user name used to login into a NT VNC
  char passwNT[32];		// a password for that
} DB_ServerConnection;

typedef struct {
  UInt16 databaseVersion;	// Version of the database (for future compatibility)
  UInt16 lastServer;		// last server accessed
} DB_GlobalPreferences;

extern PRFBViewport palmFB;
extern DB_ServerConnection server;

extern int endianTest;

/* rfbproto.c */

extern Bool useBGR233;
extern Bool debug;
extern int rfbsock;
extern rfbPixelFormat myFormat;
extern rfbServerInitMsg si;
extern Bool sendUpdateRequest;
extern Bool updateViewportSize;

extern Bool ConnectToRFBServer(char *hostname, int port);
extern Bool InitialiseRFBConnection();
extern Bool SetScaleFactor(unsigned short scaleFactor);
extern Bool SetFormatAndEncodings();
extern Bool SendIncrementalFramebufferUpdateRequest();
extern Bool SendFramebufferUpdateRequest(int x, int y, int w, int h, int incremental);
extern Bool SendPointerEvent(int x, int y, int buttonMask);
extern Bool SendKeyEvent(CARD32 key, int down);
extern Bool SendClientCutText(char *str, int len);
extern Bool HandleRFBServerMessage();
extern Bool GetPassword(char* password, int maxlength);


/* palmVNC.c */

/* Special for error handling */
#define	AppErrStrLen		32
extern	Char AppErrStr[AppErrStrLen];
#define	ErrToString(err)	SysErrString(err,AppErrStr,AppErrStrLen)

extern unsigned short BGR233ToPixel[];
/* extern unsigned short BGR233ToGrayScalePixel[]; */

extern void CopyDataToScreen(CARD8 *buf, short x, short y, unsigned short width, unsigned short height);
extern void PostProgressMessage (char *msgStr, unsigned short curr, unsigned short max);
extern void DrawVirtualFilledRectangle (unsigned short colorIndex,
				short x, short y,
				unsigned short w, unsigned short h,
				int adjust);

/* sockets.c */

// Set default timeout
#define SelectNetTimeout (sysTicksPerSecond / 10) /* Used for Select */
#define ConnectNetTimeout (sysTicksPerSecond * 10) /* Used for ConnectTcpAddr */
#define ReadNetTimeout (sysTicksPerSecond * 30) /* Used for ReadExact */

extern Bool errorMessageFromReadExact;
extern void PrintSentRecvStat (void);
extern Bool ReadExact (int sock, unsigned char *buf, int n);
extern Bool WriteExact (int sock, unsigned char *buf, int n);
extern int ConnectToTcpAddr (unsigned long host, int port);
extern int StringToIPAddr (char *str, unsigned long *addr);
