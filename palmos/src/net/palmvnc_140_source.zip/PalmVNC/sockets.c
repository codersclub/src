/*
 *  Copyright (C) 1997, 1998 Olivetti & Oracle Research Laboratory
 *
 *  Copyright (C) 1998 International Computer Science Institute (ICSI)
 *
 *  This is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 *  USA.
 */

/*
 * sockets.c - functions to deal with sockets.
 */

#include "palmVNC.h"
#include <NetMgr.h>

Err h_errno;

static unsigned long recvBytes = 0;
static unsigned long sentBytes = 0;
static unsigned long start;
static unsigned long sentInterval, recvInterval;

Bool errorMessageFromReadExact = True;

/******************************************************************
 * PrintSentRecvStat
 *
 * prints information about send/receive spped on the console
 *****************************************************************/
void PrintSentRecvStat ()
{
  if (sentBytes || recvBytes) {
    printf ("Network performance statistic:\n");
    printf ("\tsent: %ld bytes\n\trecv: %ld Kbytes\n", sentBytes, recvBytes/1000);
  }
  else
    return;

  if (sentInterval != 0)
    printf ("\tsend speed %ld bytes/sec\n",
	sentBytes * sysTicksPerSecond / sentInterval);

  if (recvInterval != 0)
    printf ("\treceive speed %ld bytes/sec\n",
	recvBytes * sysTicksPerSecond / recvInterval);

  recvBytes = sentBytes = 0;
  start = sentInterval = recvInterval = 0;
}


/******************************************************************
 * ReadExact
 * 
 * Read an exact number of bytes, and don't return until you've got them.
 *****************************************************************/

Bool ReadExact (int sock, unsigned char *buf, int n)
{
  	int i = 0;
  	int j;

  	start = TimGetTicks ();

  	while (i < n)
  	{
    	j = NetLibReceive (AppNetRefnum, sock, buf + i, (n - i), 0, 0, 0, SelectNetTimeout, &errno);
    	if (j <= 0)
    	{
      		if (j < 0)
      		{
      			if ((errno == netErrTimeout) && ((TimGetTicks() - start) < ReadNetTimeout))
      				continue;
				printf ("read failed (Err=0x%X)\n", errno);
      		}
      		else
      		{
				if (errorMessageFromReadExact)
				{
	  				printf ("read nothing\n");
				}
      		}
      		return False;
    	}
    	i += j;
  	}

  	recvInterval += TimGetTicks () - start;
  	recvBytes += n;

  	return True;
}


/******************************************************************
 * WriteExact
 * 
 * Write an exact number of bytes, and don't return until you've sent them.
 *****************************************************************/

Bool WriteExact (int sock, unsigned char *buf, int n)
{
  int i = 0;
  int j;

  start = TimGetTicks ();

  while (i < n) {
    j = NetLibSend(AppNetRefnum, sock,buf + i,(n - i),0,0,0,SelectNetTimeout,&errno);
    if (j <= 0) {
      if (j < 0) {
	printf ("write failed\n");
      } else {
        printf ("write nothing\n");
      }
      return False;
    }
    i += j;
  }

  sentInterval += TimGetTicks () - start;
  sentBytes += n;

  return True;
}


/******************************************************************
 * ConnectToTcpAddr
 * 
 * Connects to the given TCP port.
 *****************************************************************/

int ConnectToTcpAddr (unsigned long host, int port)
{
	Err socket_get_err;
    int sock;
    struct sockaddr_in addr;
    int one = 1;

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    addr.sin_addr.s_addr = host;

    sock = NetLibSocketOpen(AppNetRefnum, AF_INET, SOCK_STREAM, 0, ConnectNetTimeout, &errno);
    if (sock < 0) {
	printf ("ConnectToTcpAddr: cannot open socket\n");
	return -1;
    }

    if (NetLibSocketConnect(AppNetRefnum, sock, (NetSocketAddrType*)&addr, sizeof(addr), ConnectNetTimeout, &errno) < 0) {
	printf ("ConnectToTcpAddr: cannot connect\n");
	NetLibSocketClose(AppNetRefnum, sock, ConnectNetTimeout, &errno);
	return -1;
    }


    if (NetLibSocketOptionSet(AppNetRefnum, sock, IPPROTO_TCP, TCP_NODELAY,
		   	(char *)&one, sizeof(one), ConnectNetTimeout, &errno) < 0) {
	printf (": ConnectToTcpAddr: cannot set socket options\n");
	NetLibSocketClose(AppNetRefnum, sock, ConnectNetTimeout, &errno);
	return -1;
    }

    return sock;
}



/******************************************************************
 * StringToIPAddr
 * 
 * Converts a host string to an IP address.
*****************************************************************/
int StringToIPAddr (char *str, unsigned long *addr)
{
    struct hostent *hp = NULL;
    NetHostInfoBufType AppHostInfo;

    if ((hp = ((struct hostent*)NetLibGetHostByName(AppNetRefnum, str, &AppHostInfo, ConnectNetTimeout, &errno))) == NULL) {
      if ((long)(*addr = NetLibAddrAToIN(AppNetRefnum, str)) == -1)
        return 0;
    }
    else
      bcopy ((char *)(hp->h_addr), (char *)addr, hp->h_length);

    return 1;
}

