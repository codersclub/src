//
//  Copyright (C) 1998 International Computer Science Institute (ICSI)
//
//  Author: Vladimir Minenko, minenko@icsi.berkeley.edu
//
//  This is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.
//
//  This software is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this software; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
//  USA.
//

// Main screen
#define ID_MAIN								1000

#define ID_KEYBOARD							1050

// Main screen menu
#define ID_MAIN_MENUBAR						1100

#define ID_MAIN_MENUBAR_SERVER_OPEN			1110
#define ID_MAIN_MENUBAR_SERVER_CLOSE		1111
#define ID_MAIN_MENUBAR_SERVER_NETWORK		1112
#define ID_MAIN_MENUBAR_SERVER_DISCONNECT	1113

#define ID_MAIN_MENUBAR_VIEW_REFRESH		1120
#define ID_MAIN_MENUBAR_VIEW_SCALE1			1121
#define ID_MAIN_MENUBAR_VIEW_SCALE2			1122
#define ID_MAIN_MENUBAR_VIEW_SCALE3			1123
#define ID_MAIN_MENUBAR_VIEW_SCALE4			1124
#define ID_MAIN_MENUBAR_VIEW_SCALEDESKTOP	1125
#define ID_MAIN_MENUBAR_VIEW_SPECIALKEYS	1126
#define ID_MAIN_MENUBAR_VIEW_SAVEPOSITION	1127
#define ID_MAIN_MENUBAR_VIEW_OPENCONSOLE	1128

#define ID_MAIN_MENUBAR_SEND_CLIPBOARD		1130
#define ID_MAIN_MENUBAR_SEND_CTRLALTDEL		1131
#define ID_MAIN_MENUBAR_SEND_ALTF4			1132
#define ID_MAIN_MENUBAR_SEND_LOGIN			1133
#define ID_MAIN_MENUBAR_SEND_LOGOUT			1134
#define ID_MAIN_MENUBAR_SEND_LOCK			1135
#define ID_MAIN_MENUBAR_SEND_REBOOT			1136

#define ID_MAIN_MENUBAR_HELP_HELP			1140
#define ID_MAIN_MENUBAR_HELP_ABOUT			1141


// Console screen
#define ID_CONSOLE							1200

#define ID_CONSOLE_IO						1201
#define ID_CONSOLE_SCROLLBAR				1202
#define ID_CONSOLE_CLOSE					1203
#define ID_CONSOLE_CLEAR					1204


// Server select screen
#define	ID_SERVERSELECT						1300

#define ID_SERVERSELECT_LIST				1301
#define ID_SERVERSELECT_NEW					1302
#define ID_SERVERSELECT_EDIT				1303
#define ID_SERVERSELECT_COPY				1304
#define ID_SERVERSELECT_DELETE				1305
#define ID_SERVERSELECT_OPEN				1306
#define ID_SERVERSELECT_CANCEL				1307


// Server editing screen
#define ID_SERVEREDIT						1400

#define ID_SERVEREDIT_NAME					1401
#define ID_SERVEREDIT_ADDRESS				1402
#define ID_SERVEREDIT_DISPLAY				1403
#define ID_SERVEREDIT_PASSWORD				1404
#define ID_SERVEREDIT_OK					1405
#define ID_SERVEREDIT_CANCEL				1406
#define ID_SERVEREDIT_DETAILS				1407


// Server details screen
#define ID_SERVERDETAILS					1500

#define ID_SERVERDETAILS_BEGINX				1501
#define ID_SERVERDETAILS_BEGINY				1502
#define ID_SERVERDETAILS_SCALE				1503
#define ID_SERVERDETAILS_NTNAME				1504
#define ID_SERVERDETAILS_NTPASSWORD			1505
#define ID_SERVERDETAILS_SHARING			1506
#define ID_SERVERDETAILS_OK					1507
#define ID_SERVERDETAILS_CANCEL				1508


// General-purpose password dialog
#define ID_PASSWORD							2000
#define ID_PASSWORD_PASSWORD				2001
#define ID_PASSWORD_OK						2002
#define ID_PASSWORD_CANCEL					2003


// General-purpose edit menu
#define ID_EDIT_MENUBAR						3000

#define ID_EDIT_MENUBAR_COPY				3011
#define ID_EDIT_MENUBAR_PASTE				3012


// Dialogs
#define ID_ALERT_ABOUT						3500
#define ID_ALERT_VERSION					3501
#define ID_ALERT_CLIPBOARD					3502
#define ID_ALERT_SERVERDELETE				3503


// On-line Help
#define ID_HELP_GENERAL						4000
#define ID_HELP_SERVERSELECT				4001
#define ID_HELP_SERVEREDIT					4002
#define ID_HELP_SERVERDETAILS				4003


