/*
 *  Version 1.40 Copyright (C) 2001 Harakan Software
 *
 *  http://www.harakan.btinternet.co.uk/PalmVNC
 *
 *
 *  Copyright (C) 1998 International Computer Science Institute (ICSI)
 *
 *  Author: Vladimir Minenko, minenko@icsi.berkeley.edu
 *
 *  This is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This software is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this software; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307,
 *  USA.
 *
 */


#include "callback.h"

#include "palmVNC.h"
#include "palmVNCRsc.h"

#include <CharAttr.h>
#include <MemoryMgr.h>
#include <System/KeyMgr.h>
#include <System/SystemMgr.h>

#define MIN_VERSION     0x03000000 // PalmOS 3.0

#define INVALID_PIXEL       0xffffffff

#define COLORMAP_SIZE       256

// switch defines for scrollbars
// we have our own scrollbars because the native scrollbars are too large
#define HORIZ           1
#define HORIZ_UP        2
#define HORIZ_DOWN      3
#define HORIZ_TOP       4
#define HORIZ_BUTTOM    5

#define VERT            6
#define VERT_UP         7
#define VERT_DOWN       8
#define VERT_TOP        9
#define VERT_BUTTOM     10

#define MAIN_PRESSED    11
#define MAIN_MOVED      12
#define MAIN_ONCE       13
#define MAIN_DOUBLE     14

// modifiers and special Windows keys
#define TAB_KEY         0xff09
#define ENTER_KEY       0xff0d
#define ESC_KEY         0xff1b
#define SHIFT_KEY       0xffe1
#define CTRL_KEY        0xffe3
#define ALT_KEY         0xffe9
#define F4_KEY          0xffc1
#define DEL_KEY         0xffff

#define F1_KEY          0xffbe

static unsigned long lastPenTime = 0;
static unsigned short lastX=0, lastY=0;
static unsigned short currentMouseButton = 0;

// off-screen panning window
static WinHandle canvas = 0;

// Off-screen keyboard bitmap window
static WinHandle keyboard = 0;

// Define keyboard state bits
static unsigned short keyboard_state = 0;

#define keyboard_visible 7
#define keyboard_esc 0
#define keyboard_shift 1
#define keyboard_ctrl 2
#define keyboard_alt 3
#define keyboard_fn 4

#define keyboard_keywidth 20
#define keyboard_num_controls 5

// on-screen main window
static WinHandle topLevel = 0;

// data boundaries of the off-screen panning window
static char *screenData = NULL;

// Colour depth option
static unsigned short screenDepth = 0;


static unsigned short osVersion = 0;

// BGR233 codes for minimal greyscale colours
#define BLACK       0x00
#define DARK_GRAY   0x52
#define LIGHT_GRAY  0xA4
#define WHITE       0xFF
#define DARK_RED    0x04
#define DARK_BLUE   0x80

unsigned short BGR233ToIntensityNibble[COLORMAP_SIZE] = {
 0, 1, 3, 4, 5, 7, 8, 9,  1, 2, 3, 5, 6, 7, 9,10,  1, 3, 4, 5, 7, 8, 9,11,  2, 3, 5, 6, 7, 9,10,12,
 3, 4, 5, 7, 8,10,11,12,  3, 5, 6, 7, 9,10,12,13,  4, 5, 7, 8,10,11,12,14,  5, 6, 8, 9,10,12,13,14,

 1, 2, 3, 5, 6, 7, 9,10,  1, 3, 4, 5, 7, 8, 9,11,  2, 3, 5, 6, 7, 9,10,11,  3, 4, 5, 7, 8, 9,11,12,
 3, 5, 6, 7, 9,10,11,13,  4, 5, 7, 8, 9,11,12,13,  5, 6, 7, 9,10,11,13,14,  5, 7, 8, 9,11,12,13,15,

 1, 2, 4, 5, 6, 8, 9,10,  2, 3, 4, 6, 7, 8,10,11,  2, 4, 5, 6, 8, 9,11,12,  3, 4, 6, 7, 9,10,11,13,
 4, 5, 6, 8, 9,11,12,13,  4, 6, 7, 9,10,11,13,14,  5, 7, 8, 9,11,12,13,15,  6, 7, 9,10,11,13,14,15,

 2, 3, 4, 6, 7, 8,10,11,  2, 4, 5, 6, 8, 9,10,12,  3, 4, 6, 7, 8,10,11,12,  4, 5, 6, 8, 9,10,12,13,
 4, 6, 7, 8,10,11,12,14,  5, 6, 8, 9,10,12,13,14,  6, 7, 8,10,11,12,14,15,  6, 8, 9,10,12,13,14,15
};

typedef UInt8 BGR233ColorType;

BGR233ColorType IntensityNibbleToBGR233[16] = {
	0x00,
	0x00,
	0x09,
	0x09,
	0x52,
	0x52,
	0x5B,
	0x5B,
	0xA4,
	0xA4,
	0xB6,
	0xB6,
	0xFF
};

static DmOpenRef prefDB;
DB_GlobalPreferences pref;
DB_ServerConnection server;

// pen event processing
static int downX, downY;
static unsigned short buttonState = 0;
static int viewportX = 0, viewportY = 0;

static pen_zooming = false;

// for error handling
char AppErrStr[AppErrStrLen];

RectangleType vertScrollbarRect = {{VIEWABLE_MAX_W - SCROLLBAR_SIZE, 0},
				{SCROLLBAR_SIZE, VIEWABLE_MAX_H}};
RectangleType horizScrollbarRect = {{0, VIEWABLE_MAX_H - SCROLLBAR_SIZE},
				{VIEWABLE_MAX_H - SCROLLBAR_SIZE, SCROLLBAR_SIZE}};
RectangleType vertSlideRect = {{VIEWABLE_MAX_W - SCROLLBAR_SIZE, 0},
				{SCROLLBAR_SIZE, SCROLLBAR_SIZE}};
RectangleType horizSlideRect = {{0, VIEWABLE_MAX_H - SCROLLBAR_SIZE},
				{SCROLLBAR_SIZE, SCROLLBAR_SIZE}};
RectangleType updateRect = {{0, 0}, {0, 0}};

RectangleType viewableBounds = {{0, 0}, {VIEWABLE_MAX_W, VIEWABLE_MAX_H}};
RectangleType virtualBounds = {{0, 0}, {VIRTUAL_20_MAX_W, VIRTUAL_20_MAX_H}};

Err errno;
Word AppNetRefnum;
static Boolean networkIsOpen = false;

static void InitVirtual (void);
static Err CreateWindows (FormPtr frmPtr);
static Boolean OpenConnection (void);
static Boolean OpenNetwork (void);
static void ShutdownNetwork (Boolean enforcedClose);
static void ShutdownConnection (void);
static void SendKeySequence (unsigned short mod1, unsigned short mod2, unsigned short mod3,
			  unsigned short *keys, int n, Boolean ascii);
static void PositionViewport (void);
static void UpdateScrollbars (void);
static void PositionScrollbars (void);
static void UpdateViewport (void);
static void ProcessPenUpDownEvent (EventPtr e);
static void ProcessPenMoveEvent (EventPtr e);
static void ProcessScrollPenDownEvent (EventPtr e);
static void ProcessScrollPenMoveEvent (EventPtr e);
static Boolean ConsoleFormHandleEvent (EventPtr e);


/******************************************************************
 * mySetForeColor
 *
 * Sets the foregroung ink to the specified BGR233 color,
 * regardless of mode.
 *****************************************************************/
void mySetForeColor (BGR233ColorType color)
{
	RGBColorType newColor;

	if (screenDepth == 8)
	{
		WinSetForeColor(color);
		WinSetTextColor(color);
	}
	else
	{
		newColor.index = 0;
		newColor.r = (BGR233ToIntensityNibble[color] << 4) | BGR233ToIntensityNibble[color];
		newColor.g = newColor.r;
		newColor.b = newColor.r;
		WinSetColors(&newColor, 0, 0, 0);
	}
}


/******************************************************************
 * DrawingBlocked
 *
 * returns true if the menu bar is open or the main form isn't
 * active
 *****************************************************************/
Boolean DrawingBlocked (void)
{
	if (MenuGetActiveMenu())
		return (MenuGetActiveMenu()->attr.visible);

	/*** Crashes ***/
/*  if (MenuGetActiveMenu () != (MenuBarPtr)NULL)
	return true;*/

	/*** Erratic ***/
	return (ID_MAIN != FrmGetActiveFormID());

/*  return (topLevel != WinGetActiveWindow()); */

}


/***********************************************************************
 *
 * RomVersionCompatible
 *
 * This routine checks that a ROM version meets your
 * minimum requirement and sets the version number in global variable
 ***********************************************************************/
static DWord RomVersionCompatible (DWord requiredVersion, Word launchFlags)
{
  DWord romVersion;

  // See if we have at least the minimum required version of the ROM or later.
  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);

  if (romVersion < requiredVersion) {
	if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		== (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) {
	  FrmAlert (ID_ALERT_VERSION);

	  // Pilot 1.0 will continuously relaunch this app unless we switch to
	  // another safe one.
	  if (romVersion < 0x02000000) {
	Err err;
		AppLaunchWithCommand (sysFileCDefaultApp,
		sysAppLaunchCmdNormalLaunch, NULL);
	  }
	}

	return sysErrRomIncompatible;
  }

  osVersion = sysGetROMVerMajor(romVersion);

  return 0;
}


/******************************************************************
 * PostProgressMessage
 *
 * writes a message and and draws a simple progress bar
 *****************************************************************/
void PostProgressMessage (char *msgStr, unsigned short curr, unsigned short max)
{
  RGBColorType oldColor_RGB;
  RGBColorType newColor_RGB;
  IndexedColorType oldColor_Index;
  RectangleType r = {{20, 140}, {120, 10}};
  unsigned short length = StrLen (msgStr);

 if (DrawingBlocked ())
   return;

  mySetForeColor (DARK_GRAY);

  WinEraseRectangle (&r, 0);

  WinDrawChars (msgStr, length,
	80 - FntLineWidth (msgStr, length) / 2, 139);

  WinDrawRectangleFrame (simpleFrame, &r);

  if (max) {
	r.extent.x = (120 * curr) / max;
	WinInvertRectangle (&r, 0);
  }
  /*WinSetForeColor (&grayScalePixelToColor[BLACK], &oldColor); Should be oldColor */
  mySetForeColor (BLACK);
}


/******************************************************************
 * GetUpdateRectAtPos
 *
 * Re-aasigns the coordinates of the update rect. and returns the
 * pointer to it.
 *****************************************************************/
RectanglePtr GetUpdateRectAtPos (unsigned short x, unsigned short y)
{
  updateRect.topLeft.x = x;
  updateRect.topLeft.y = y;
  return &updateRect;
}


/******************************************************************
 * InitVirtual
 *
 * Inits the content of the off-screen window
 *****************************************************************/
static void InitVirtual (void)
{
  IndexedColorType oldColor;
  WinHandle prevDrawWin = WinGetDrawWindow ();
  unsigned short hpos = 0;
  int i, j, k;

  WinSetDrawWindow (canvas);

  WinEraseWindow ();
  FntSetFont (largeBoldFont);
  hpos = 50;

	mySetForeColor (DARK_GRAY);
  WinDrawChars("Palm", 4, hpos, 20);
  hpos += FntLineWidth("Palm", 4);

  if (screenDepth == 8)
  {
	mySetForeColor (DARK_RED);
  }
  else
  {
	mySetForeColor(BLACK);
  }
  WinDrawChars("VNC", 3, hpos, 20);

  mySetForeColor(BLACK);
  WinDrawLine(48, 18, 98, 18);
  WinDrawLine(48, 35, 98, 35);

  if (screenDepth == 8)
  {
	mySetForeColor (DARK_BLUE);
  }
  else
  {
	mySetForeColor(BLACK);
  }
  FntSetFont (boldFont);
  WinDrawChars("version", 7, 45, 45);
  WinDrawChars(PALMVNC_VERSION, StrLen(PALMVNC_VERSION), 85, 45);

  mySetForeColor(BLACK);
  FntSetFont (stdFont);
  WinDrawChars("For more help on PalmVNC see:", 29, 0, 96);
  if (screenDepth == 8)
  {
	mySetForeColor (DARK_BLUE);
  }
  else
  {
	mySetForeColor(BLACK);
  }
  WinDrawChars("http://www.harakan.btinternet.", 30, 10, 110);
  WinDrawChars("co.uk/PalmVNC", 13, 81, 120);

  if (screenDepth == 8)
  {
	mySetForeColor (BLACK);
	WinDrawChars("using 8-bit colour", 18, 42, 68);
	for (i = 0; i < 8; i++)
		for (j = 0; j < 100; j++)
		{
			if (screenData[((77 - i) * VIEWABLE_MAX_W) + 27 + j] == 0) screenData[((77 - i) * VIEWABLE_MAX_W) + 27 + j] = (i << 3) + (7 - i);
		}
  }
  else if (screenDepth == 4)
  {
	  for (i = 0; i < 7; i++)
	  {
		 mySetForeColor (IntensityNibbleToBGR233[(i*2)]);
		 WinDrawLine(27, 74+i, 127, 74+i);
		 WinDrawLine(27, 74-i, 127, 74-i);
	  }
	  mySetForeColor (BLACK);
	  WinEraseChars("using 4-bit greyscale", 21, 36, 68);
  }
  else if (screenDepth == 2)
  {
	  for (i = 0; i < 7; i++)
	  {
		 mySetForeColor (IntensityNibbleToBGR233[i*2]);
		 WinDrawLine(27, 74+i, 127, 74+i);
		 WinDrawLine(27, 74-i, 127, 74-i);
	  }
	  mySetForeColor (BLACK);
	  WinEraseChars("using 2-bit greyscale", 21, 36, 68);
  }

  mySetForeColor (BLACK);
  PostProgressMessage ("Not Connected", 0, 0);

  FntSetFont (stdFont);
  WinSetDrawWindow (prevDrawWin);

  WinCopyRectangle (canvas, topLevel,
	GetUpdateRectAtPos (palmFB.viewable.x - palmFB.virtual.x,
				palmFB.viewable.y - palmFB.virtual.y),
	0, 0, scrCopy);

}


/******************************************************************
 * DrawVirtualFilledRectangle
 *
 * Draws a filled rectangle in the virtual window If adjust is true
 * x and y coordinates are translatds to the origin in the virtual
 *****************************************************************/
void DrawVirtualFilledRectangle (unsigned short color,
				short x, short y,
				unsigned short width, unsigned short height,
				int adjust)
{
	short row = 0;
	short column = 0;
	short start_column = 0;
	short end_column = 0;
	short start_row = 0;
	short end_row = 0;

	// align to real coordinates
	if (adjust)
	{
		x -= palmFB.virtual.x;
		y -= palmFB.virtual.y;
	}

	// Check top-left corner
	if ((x >= palmFB.virtual.w) || (y >= palmFB.virtual.h))
	{
		return;
	}

	// Check top and bottom boundaries
	if (y < 0)
		start_row = -y;
	else
		start_row = 0;
	if ((y + height) >= palmFB.virtual.h)
		end_row = (palmFB.virtual.h - y)-1;
	else
		end_row = height-1;
	if (end_row < start_row)
		return;

	// Check left and right boundaries
	if (x < 0)
		start_column = -x;
	else
		start_column = 0;
	if ((x + width) >= palmFB.virtual.w)
		end_column = (palmFB.virtual.w - x)-1;
	else
		end_column = width-1;
	if (end_column < start_column)
		return;


	if (screenDepth == 8)
	{
		/* Do whole region */
		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column <= end_column; column ++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + column + x)] = color;
			}
		}
	}
	else if (screenDepth == 4)
	{
		color = BGR233ToIntensityNibble[color];
		/* Do left-hand column if non-aligned */
		if (((x+start_column) % 2)) /* 1, 3, 5, ...  */
		{
			for (row = start_row; row <= end_row; row++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + start_column + x) / 2] |= (0xF);
				screenData[(((row + y) * VIEWABLE_MAX_W) + start_column + x) / 2] ^= (color);
			}
			start_column++;
		}

		/* Check if only 1 column */
		if (end_column < start_column)
			return;

		/* Do right-hand column if non-aligned */
		if (!((x+end_column) % 2)) /* 0, 2, 4, ...  */
		{
			for (row = start_row; row <= end_row; row++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + end_column + x) / 2] |= (0xF << 4);
				screenData[(((row + y) * VIEWABLE_MAX_W) + end_column + x) / 2] ^= (color << 4);
			}
			end_column--;
		}

		/* Check if only 2 columns */
		if (end_column <= start_column)
			return;

		/* Do middle region */
		color = ~(color + (color << 4));
		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column < end_column; column += 2)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 2] = color;
			}
		}
	}
	else if (screenDepth == 2)
	{
		/* Very slow implementation for now to sanity-check */

		color = (BGR233ToIntensityNibble[color] >> 2) & 0x3;

		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column <= end_column; column++)
			{
				switch ((x + column) % 4)
				{
					case 0:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 6);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= (color << 6);
							break;
						}
					case 1:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 4);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= (color << 4);
							break;
						}
					case 2:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 2);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= (color << 2);
							break;
						}
					case 3:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 0);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= (color << 0);
							break;
						}
				}
			}
		}
	}
}


/******************************************************************
 * CopyDataToScreen
 *
 * Copies a 8bit pixel array into a correspond 4bit data area of the
 * off-screen window. Probably can be made more efficient, but this
 * part must be replaced by "official" bitmap operations via
 * WinDrawBitmap(). This re-implementation is also required for
 * a support of grayscale representation
 *****************************************************************/
void CopyDataToScreen (CARD8 *buf, short x, short y, unsigned short width, unsigned short height)
{
	short row = 0;
	short column = 0;
	short start_column = 0;
	short end_column = 0;
	short start_row = 0;
	short end_row = 0;

	short x_off = 0;
	unsigned short color_temp = 0;
	unsigned short color_mask = 0;

	// align to real coordinates
	x -= palmFB.virtual.x;
	y -= palmFB.virtual.y;

	// Check top-left corner
	if ((x >= palmFB.virtual.w) || (y >= palmFB.virtual.h))
	{
		return;
	}

	// Check top and bottom boundaries
	if (y < 0)
		start_row = -y;
	else
		start_row = 0;
	if ((y + height) >= palmFB.virtual.h)
		end_row = (palmFB.virtual.h - y)-1;
	else
		end_row = height-1;
	if (end_row < start_row)
		return;

	// Check left and right boundaries
	if (x < 0)
		start_column = -x;
	else
		start_column = 0;
	if ((x + width) >= palmFB.virtual.w)
		end_column = (palmFB.virtual.w - x)-1;
	else
		end_column = width-1;
	if (end_column < start_column)
		return;

	if (screenDepth == 8)
	{
		/* Do middle region */
		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column <= end_column; column ++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + column + x)] = buf[(row * width) + column];
			}
		}
	}
	else if (screenDepth == 4)
	{
		/* Do left-hand column if non-aligned */
		if (((x+column) % 2)) /* 1, 3, 5, ...  */
		{
			for (row = start_row; row <= end_row; row++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + start_column + x) / 2] |= (0xF);
				screenData[(((row + y) * VIEWABLE_MAX_W) + start_column + x) / 2] ^= (BGR233ToIntensityNibble[buf[(row * width) + start_column]]);
			}
			start_column++;
		}

		/* Check if only 1 column */
		if (end_column < start_column)
			return;

		/* Do right-hand column if non-aligned */
		if (!((x+end_column) % 2)) /* 0, 2, 4, ...  */
		{
			for (row = start_row; row <= end_row; row++)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + end_column + x) / 2] |= (0xF << 4);
				screenData[(((row + y) * VIEWABLE_MAX_W) + end_column + x) / 2] ^= (BGR233ToIntensityNibble[buf[(row * width) + end_column]] << 4);
			}
			end_column--;
		}

		/* Check if only 2 columns */
		if (end_column <= start_column)
			return;

		/* Do middle region */
		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column < end_column; column += 2)
			{
				screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 2] = ~(BGR233ToIntensityNibble[buf[(row * width) + column + 1]] +
																			   (BGR233ToIntensityNibble[buf[(row * width) + column]] << 4));
			}
		}
	}
	else if (screenDepth == 2)
	{
		/* Very slow implementation for now to sanity-check */

		for (row = start_row; row <= end_row; row++)
		{
			for (column = start_column; column <= end_column; column++)
			{
				switch ((x + column) % 4)
				{
					case 0:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 6);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= ((BGR233ToIntensityNibble[buf[(row * width) + column]] << 4) & (0x3 << 6));
							break;
						}
					case 1:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 4);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= ((BGR233ToIntensityNibble[buf[(row * width) + column]] << 2) & (0x3 << 4));
							break;
						}
					case 2:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 2);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= ((BGR233ToIntensityNibble[buf[(row * width) + column]] << 0) & (0x3 << 2));
							break;
						}
					case 3:
						{
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] |= (0x3 << 0);
							screenData[(((row + y) * VIEWABLE_MAX_W) + column + x) / 4] ^= ((BGR233ToIntensityNibble[buf[(row * width) + column]] >> 2) & (0x3 << 0));
							break;
						}
				}
			}
		}
	}
}

/******************************************************************
 * CreateWindows
 *
 * Creates the off-screen panning window and inits global variables.
 * Called only once wenn the MainFrom is loaded and opened.
 *****************************************************************/
static Err CreateWindows (FormPtr frmPtr)
{
  Err error;
  WinPtr canvasWinPtr;
  WinHandle prevDrawWin = WinGetDrawWindow ();
  BitmapType* keyboard_bmp;
  MemHandle keyboard_res;


  // always use BGR233 format! Maybe we will have something else in the future
  useBGR233 = True;

  /* this is a set-up for BRG233 format. We tell the server that we
   * use BRG233 and have 8 bit color depth. We map BRG233 pixels to
   * 4 bit grayscale. All that is because VNC currently does not
   * provide data formats for depths less then 8
   */

  myFormat.bitsPerPixel = 8;
  myFormat.depth = 8;
  myFormat.trueColour = 1;
  myFormat.bigEndian = 0;
  myFormat.redMax = 7;
  myFormat.greenMax = 7;
  myFormat.blueMax = 3;
  myFormat.redShift = 0;
  myFormat.greenShift = 3;
  myFormat.blueShift = 6;

  viewportX = 0;
  viewportY = 0;

  /* set up the size of the update rectangle */
  updateRect.extent.x = palmFB.viewable.w;
  updateRect.extent.y = palmFB.viewable.h;

  /* the display area take the whole main form */
  topLevel = FrmGetWindowHandle (frmPtr);

  if (!canvas)
	/* canvas = WinGetDrawWindow (); */
   canvas = WinCreateOffscreenWindow(VIEWABLE_MAX_W, VIEWABLE_MAX_H, /* palmFB.virtual.w, palmFB.virtual.h, */
		screenFormat, &error);

  if (!keyboard)
  {
	keyboard_res = DmGetResource(bitmapRsc, ID_KEYBOARD);
	keyboard_bmp = MemHandleLock(keyboard_res);
	keyboard = WinCreateOffscreenWindow(keyboard_bmp->width, keyboard_bmp->height, screenFormat, &error);
	WinSetDrawWindow(keyboard);
	WinDrawBitmap(keyboard_bmp, 0, 0);
	MemHandleUnlock(keyboard_res);
	DmReleaseResource(keyboard_res);
  }

  WinSetDrawWindow (canvas);
  WinEraseWindow ();
  WinSetDrawWindow (prevDrawWin);

  canvasWinPtr = WinGetWindowPointer(canvas);

  screenData = canvasWinPtr->displayAddrV20;

  return 0;
}


/******************************************************************
 * OpenNetworkPreferences
 *
 * Opens the network preferences dialog
 *****************************************************************/
Boolean OpenNetworkPreferences (void)
{
	Err                     err;
	UInt                    cardNo;
	LocalID                 dbID;
	DmSearchStateType       searchState;

	// Shut down the app, reset video, etc.
//  StopApplication();

	// Get the card number and database id of the Address application.
	err = DmGetNextDatabaseByTypeCreator (true, &searchState,
		sysFileTPanel, sysFileCNetworkPanel, true, &cardNo, &dbID);
	ErrFatalDisplayIf(err, "Network panel not found");
	if (err) return;

	SysUIAppSwitch(cardNo, dbID, sysAppLaunchCmdPanelCalledFromApp, NULL);
}


/******************************************************************
 * OpenNetwork
 *
 * Loads the lib and connects to the network
 *****************************************************************/
Boolean OpenNetwork (void)
{
  Word  ifErrs;
  Err  err;

  printf ("\nOpening the network...");

  err = NetLibOpen (AppNetRefnum, &ifErrs);

	if (err == netErrAlreadyOpen || err == 0)
	{
		printf("skipped\n");
		return true;
	}
	else
	{
		if (ifErrs == netErrUserCancel)
		{
			ShutdownNetwork (true);
			return false;
		}

		printf ("\nERROR: opening network: %s\n", ErrToString (err));

		if (ifErrs == netErrPrefNotFound)
			printf ("\nNetwork preference not set\n");

		return false;
	}

	printf ("opened\n");

	return true;
}


/******************************************************************
 * OpenConnection
 *
 * Opens a connection to the server
 *****************************************************************/
static Boolean OpenConnection (void)
{
  Err  err;

	if (rfbsock > 0)
	{
		printf ("Already connected\n");
		return true;
	}

	if (!networkIsOpen)
	{
		  if ((networkIsOpen = OpenNetwork ()) != true)
		  {
			  printf ("ERROR: cannot open network\n");
			  return false;
		  }
	}


  printf ("Connecting to \"%s:%d\"...\n",
		server.address, server.port);

  err = 0;

  viewportX = palmFB.viewable.x = palmFB.virtual.x = server.beginX;
  viewportY = palmFB.viewable.y = palmFB.virtual.y = server.beginY;

  PostProgressMessage ("Connecting...", 0, 0);

  if (!ConnectToRFBServer (server.address, server.port)) {
	printf ("ERROR: cannot connect to \"%s:%d\"\n", server.address, server.port);
	err = true;
  } else if (!InitialiseRFBConnection(rfbsock)) {
	printf ("ERROR: cannot initialize \"%s:%d\"\n", server.address, server.port);
	err = true;
  } else if (!SetFormatAndEncodings()) {
	err = true;
	printf ("ERROR: cannot set format\n");
  } else if (server.scaleFactor != 1)
  {
	if (!SetScaleFactor(server.scaleFactor)) {
		err = true;
	}
  }
  if (server.scaleFactor == 1)
  {
	  if ((err == false) && (!SendFramebufferUpdateRequest(palmFB.virtual.x, palmFB.virtual.y,
			 palmFB.virtual.w, palmFB.virtual.h, False))) {
		printf ("ERROR: cannot send buffer update\n");
		err = true;
	  }
  }

  if (err) {
	PostProgressMessage ("Cannot connect!", 0, 0);
	ShutdownConnection ();
	return false;
  }

  /* set up the size of scrollbar slides */
  horizSlideRect.extent.x =
	(SWord)((palmFB.viewable.w * palmFB.viewable.w) /
		palmFB.remote.w);
  vertSlideRect.extent.y =
	(SWord)((palmFB.viewable.h * palmFB.viewable.h) /
		palmFB.remote.h);

  /* set the pen time tracing, used to catch double-taps */
  lastPenTime = TimGetTicks ();

  printf ("Connected!\n");

  return true;
}


/******************************************************************
 * ShutdownConnection
 *
 * Closes the current connection to the VNC server
 *****************************************************************/
void ShutdownConnection ()
{
  if (rfbsock > 0) {
	NetLibSocketClose(AppNetRefnum, rfbsock, ConnectNetTimeout, &errno);
	rfbsock = 0;

	PrintSentRecvStat ();

	printf ("Connection closed\n\n");

	/* set up the size of scrollbar slides */
	horizSlideRect.extent.x = 0;
	vertSlideRect.extent.y = 0;

	viewportX = palmFB.viewable.x = palmFB.virtual.x = 0;
	viewportY = palmFB.viewable.y = palmFB.virtual.y = 0;

	palmFB.remote.h = palmFB.remote.w = 0;

	/*InitVirtual ();*/

	PositionScrollbars ();
/*  UpdateViewport(); */

	PostProgressMessage ("Server connection closed", 0, 0);
  }
}


/******************************************************************
 * ShutdownNetwork
 *
 * Closes the network. If enforcedClose == True requests the modem
 * to hang up, otherwise closes only ots own API to the Network lib.
 *****************************************************************/
void ShutdownNetwork (Boolean enforcedClose)
{
  Err err;

  ShutdownConnection ();

  printf ("Closing NetLib...\n");
  err = NetLibClose (AppNetRefnum, enforcedClose);

  if (err == netErrNotOpen)
	printf ("ERROR: cannot close: %s\n", ErrToString(err));
  else if (err == netErrStillOpen)
	printf ("Network is still in use\n");
  else
	printf ("Network is closed\n");

  networkIsOpen = false;
  return;
}


/******************************************************************
 * SendKeySequence
 *
 * Sends a sequence of n characters as a keyboard input to the VNC
 * server. Works with unsigned short data because the server works
 * with 16bit KeySyms from X11. mod1 and mod2 are two available
 * modifiers. If ascii is true, convert the data into a sequence of
 * unsigned short
 *****************************************************************/
void SendKeySequence (unsigned short mod1, unsigned short mod2, unsigned short mod3,
			  unsigned short *keys, int n, Boolean ascii)
{
  int i;
  unsigned short key;

  if (keys == 0) {
	return;
  }

  if (mod1 > 0)
	SendKeyEvent(mod1, true); // modifier 1 pressed

  if (mod2 > 0)
	SendKeyEvent(mod2, true); // modifier 2 pressed

  if (mod3 > 0)
	SendKeyEvent(mod3, true); // modifier 3 pressed

  for (i = 0; i < n; i++) {
	if (ascii)
	  key = ((unsigned char *)keys)[i];
	else
	  key = keys[i];

  if (key == 10) key = 13; // Override for carriage return

	if ((keyboard_state & (1 << keyboard_visible)) && (keyboard_state & (1 << keyboard_shift)))
	{
		if ((key >= 'a') && (key <= 'z')) key -= ('a' - 'A');
	}

	if ((keyboard_state & (1 << keyboard_visible)) && (keyboard_state & (1 << keyboard_fn)))
	{
		if ((key >= '1') && (key <= '9')) key = (key - '1') + F1_KEY;
		if (key == '0') key = F1_KEY + 9;
	}


	SendKeyEvent(key, true); // pressed
	SendKeyEvent(key, false); // released
  }

  if (mod3 > 0)
	SendKeyEvent(mod3, false); // released

  if (mod2 > 0)
	SendKeyEvent(mod2, false); // released

  if (mod1 > 0)
	SendKeyEvent(mod1, false); // released
}


/******************************************************************
 * PositionViewport
 *
 * Moves visible area over the virtual panning window. If the
 * the boundaries of the visible area is beyond the panning window,
 * the panning window will be moved and a new portion of the screen
 * data will be requested
 *****************************************************************/
static void PositionViewport ()
{
  int deltaX=0, deltaY=0;
  int updateViewport = False;

  if (viewportX < 0)
	viewportX = 0;

  if (viewportX > (palmFB.remote.w - palmFB.viewable.w))
	viewportX = palmFB.remote.w - palmFB.viewable.w;

  if (viewportY < 0)
	viewportY = 0;

  if (viewportY > (palmFB.remote.h - palmFB.viewable.h))
	viewportY = palmFB.remote.h - palmFB.viewable.h;

  if (palmFB.viewable.x != viewportX) {
	if (viewportX < palmFB.virtual.x ||
	viewportX + palmFB.viewable.w > palmFB.virtual.w) {
	  deltaX = (int)palmFB.viewable.x - viewportX;
	}
	updateViewport = True;
	palmFB.viewable.x = viewportX;
  }

  if ((int)palmFB.virtual.x - deltaX < 0)
	 deltaX = palmFB.virtual.x;

  if (palmFB.viewable.y != viewportY) {
	if (viewportY < palmFB.virtual.y ||
	viewportY + palmFB.viewable.h > palmFB.virtual.h) {
	  deltaY = (int)palmFB.viewable.y - viewportY;
	}
	updateViewport = True;
	palmFB.viewable.y = viewportY;
  }

  if ((int)palmFB.virtual.y - deltaY < 0)
	deltaY = palmFB.virtual.y;

  if (deltaX != 0 || deltaY != 0) {
	int obscuredRectX=0, obscuredRectY=0;
	RectangleType r;

	r.topLeft.x = r.topLeft.y = 0;
	r.extent.x = palmFB.virtual.w;
	r.extent.y = palmFB.virtual.h;

	if (deltaX > 0) r.extent.x -= deltaX;
	if (deltaY > 0) r.extent.y -= deltaY;

	WinCopyRectangle (canvas, canvas, &r, deltaX, deltaY, scrCopy);

	if (deltaX < 0)
	  obscuredRectX = (int)palmFB.virtual.w + deltaX;

	if (deltaX != 0) {

	  DrawVirtualFilledRectangle (LIGHT_GRAY, obscuredRectX, 0,
		abs(deltaX), palmFB.virtual.h, false);

	  palmFB.virtual.x -= deltaX;
	  deltaX = abs(deltaX);
	  if (deltaX > 156) deltaX = 156;

	  (void)SendFramebufferUpdateRequest (palmFB.virtual.x + obscuredRectX,
					palmFB.virtual.y,
					deltaX,
					palmFB.virtual.h,
					False);
	}

	if (deltaY < 0)
	  obscuredRectY = (int)palmFB.virtual.h + deltaY;

	if (deltaY != 0) {

	  DrawVirtualFilledRectangle (LIGHT_GRAY, 0, obscuredRectY,
		palmFB.virtual.w, abs(deltaY), false);

	  palmFB.virtual.y -= deltaY;
	  deltaY = abs(deltaY);
	  if (deltaY > 156) deltaY = 156;

	  (void)SendFramebufferUpdateRequest (palmFB.virtual.x,
					palmFB.virtual.y + obscuredRectY,
					palmFB.virtual.w,
					deltaY,
					False);
	}

	sendUpdateRequest = true;
	updateViewport = true;
  }

  if (updateViewport)
	UpdateViewport ();
}


/******************************************************************
 * UpdateViewport
 *
 * Copies the viewable portion of the off-screen window into the
 * visible window
 *****************************************************************/
static void UpdateViewport (void)
{
  RectangleType rect;
  int i;

  if (rfbsock == 0)
	return;

 if (DrawingBlocked ())
   return;

  WinCopyRectangle (canvas, topLevel,
	GetUpdateRectAtPos (palmFB.viewable.x - palmFB.virtual.x,
				palmFB.viewable.y - palmFB.virtual.y),
	0, 0, scrCopy);

	if (keyboard_state & (1 << keyboard_visible))
	{
		/* Copy keyboard */
		rect.extent.x = 1 + keyboard_keywidth;
		rect.extent.y = 6;
		for (i = 0; i < keyboard_num_controls; i++)
		{
			rect.topLeft.x = keyboard_keywidth * i;
			if (keyboard_state & (1 << i))
				rect.topLeft.y = 6;
			else
				rect.topLeft.y = 0;
			WinCopyRectangle(keyboard, topLevel, &rect, rect.topLeft.x, 150, scrCopy);
		}
	}
}


/******************************************************************
 * UpdateScrollbars
 *
 * Repaints scrollbars
 *****************************************************************/
static void UpdateScrollbars (void)
{
  IndexedColorType oldColor;

  mySetForeColor (LIGHT_GRAY);
  WinDrawRectangle (&horizScrollbarRect, 0);
  WinDrawRectangle (&vertScrollbarRect, 0);

  mySetForeColor (BLACK);
  WinDrawRectangle (&horizSlideRect, 0);
  WinDrawRectangle (&vertSlideRect, 0);
}


/******************************************************************
 * PositionScrollbars
 *
 * re-computes scrollbar rectangles and re-paints scrollbars
 *****************************************************************/
static void PositionScrollbars ()
{
  if (palmFB.remote.w == 0)
	horizSlideRect.topLeft.x = 0;
  else
	horizSlideRect.topLeft.x = (((UInt32)viewportX * (UInt32)palmFB.viewable.w) / palmFB.remote.w);

  if (palmFB.remote.h == 0)
	vertSlideRect.topLeft.y = 0;
  else
	vertSlideRect.topLeft.y = ((UInt32)(viewportY * (UInt32)palmFB.viewable.h) / palmFB.remote.h);

  UpdateScrollbars ();
}


/******************************************************************
 * PointInRectangle
 *
 * returns true if the point (x,y) is in the rect. rp otherwise
 * false
 *****************************************************************/
Boolean PointInRectangle (unsigned x, unsigned y, RectangleType *rp)
{
  return ((x >= rp->topLeft.x) &&
	(y >= rp->topLeft.y) &&
	((unsigned)(x - rp->topLeft.x) < rp->extent.x) &&
	((unsigned)(y - rp->topLeft.y) < rp->extent.y));
}


/******************************************************************
 * InMainArea
 *
 * returns true if the point (x,y) is in the VNC area otherwise
 * false
 *****************************************************************/
Boolean InMainArea (unsigned short x, unsigned short y)
{
  return (x < palmFB.viewable.w &&
	  y < palmFB.viewable.h);
}

/******************************************************************
 * InKeyboardArea
 *
 * returns true if the point (x,y) is in the keyboard area otherwise
 * false
 *****************************************************************/
Boolean InKeyboardArea (unsigned short x, unsigned short y)
{
	if (!(keyboard_state & (1 << keyboard_visible))) return false;
	if ((x < (keyboard_num_controls * keyboard_keywidth + 1)) && (y >= 150) && (y <= 155))
		return true;
	return false;
}


/******************************************************************
 * ToggleKeyboardState
 *
 * Toggles the special keyboard on and off
 ******************************************************************/
static void ToggleKeyboardState (void)
{
	keyboard_state ^= (1 << keyboard_visible);
	if (keyboard_state & (1 << keyboard_visible))
	{
		if (keyboard_state & (1 << keyboard_shift))
			SendKeyEvent(SHIFT_KEY, true);
		if (keyboard_ctrl & (1 << keyboard_ctrl))
			SendKeyEvent(CTRL_KEY, true);
		if (keyboard_alt & (1 << keyboard_alt))
			SendKeyEvent(ALT_KEY, true);
	}
	else
	{
		if (keyboard_state & (1 << keyboard_shift))
			SendKeyEvent(SHIFT_KEY, false);
		if (keyboard_state & (1 << keyboard_ctrl))
			SendKeyEvent(CTRL_KEY, false);
		if (keyboard_state & (1 << keyboard_alt))
			SendKeyEvent(ALT_KEY, false);
	}
}


/******************************************************************
 * ProcessKeyboardPenDownEvent
 *
 * Handles events penDown for the keyboard masked area
 ******************************************************************/
static void ProcessKeyboardPenDownEvent (EventPtr e)
{
	unsigned short key;
	if (e->screenX >= 156)
	{
		ToggleKeyboardState();
	}
	else
	{
		key = (e->screenX / keyboard_keywidth);
		keyboard_state ^= (1 << key);
		if (key == keyboard_shift)
		{
			if (keyboard_state & (1 << keyboard_shift))
				SendKeyEvent(SHIFT_KEY, true);
			else
				SendKeyEvent(SHIFT_KEY, false);
		}
		if (key == keyboard_ctrl)
		{
			if (keyboard_state & (1 << keyboard_ctrl))
				SendKeyEvent(CTRL_KEY, true);
			else
				SendKeyEvent(CTRL_KEY, false);
		}
		if (key == keyboard_alt)
		{
			if (keyboard_state & (1 << keyboard_alt))
				SendKeyEvent(ALT_KEY, true);
			else
				SendKeyEvent(ALT_KEY, false);
		}
	}

	UpdateViewport();
}

/******************************************************************
 * ProcessKeyboardPenUpEvent
 *
 * Handles events penUp for the keyboard masked area
 ******************************************************************/
static void ProcessKeyboardPenUpEvent (EventPtr e)
{
	unsigned short key;
	unsigned short oneKey;
	if (e->screenX >= 156)
		return;

	key = (e->screenX / keyboard_keywidth);

	/* Escape key */
	if (key == 0)
	{
		keyboard_state ^= (1 << key);
		oneKey = ESC_KEY;
		SendKeySequence(0, 0, 0, &oneKey, 1, false);
		UpdateViewport();
	}
}


/******************************************************************
 * InScrollbar
 *
 * returns true if the point (x,y) is in the specified scrollbar
 * area otherwise false
 *****************************************************************/
Boolean InScrollbar (unsigned short barType, unsigned short x, unsigned short y)
{
  Boolean ret = false;

  switch (barType) {
	case HORIZ:
	  ret = PointInRectangle (x, y, &horizSlideRect);
	  break;

	case HORIZ_UP:
	  ret = PointInRectangle (x, y, &horizScrollbarRect) &&
		!PointInRectangle (x, y, &horizSlideRect) &&
		(x < horizSlideRect.topLeft.x);
	  break;

	case HORIZ_DOWN:
	  ret = PointInRectangle (x, y, &horizScrollbarRect) &&
		!PointInRectangle (x, y, &horizSlideRect) &&
		(x > horizSlideRect.topLeft.x + horizSlideRect.extent.x);
	  break;

	case HORIZ_TOP:
	  ret = false;
	  break;

	case HORIZ_BUTTOM:
	  ret = false;
	  break;

	case VERT:
	  ret = PointInRectangle (x, y, &vertSlideRect);
	  break;

	case VERT_UP:
	  ret = PointInRectangle (x, y, &vertScrollbarRect) &&
		!PointInRectangle (x, y, &vertSlideRect) &&
		(y < vertSlideRect.topLeft.y);
	  break;

	case VERT_DOWN:
	  ret = PointInRectangle (x, y, &vertScrollbarRect) &&
		!PointInRectangle (x, y, &vertSlideRect) &&
		(y > vertSlideRect.topLeft.y + horizSlideRect.extent.y);
	  break;

	case VERT_TOP:
	  ret = false;
	  break;

	case VERT_BUTTOM:
	  ret = false;
	  break;

	default:
	  return false;
  }

  return ret;
}


/******************************************************************
 * ProcessScrollPenMoveEvent
 *
 * Handles events penMoveEvent in the main form
 *****************************************************************/
static void ProcessScrollPenMoveEvent (EventPtr e)
{
  if (buttonState == HORIZ) {
	viewportX += ((e->screenX - downX) * (int)(palmFB.remote.w
			/ palmFB.viewable.w));
	downX = e->screenX;

  } else if (buttonState == VERT) {
	viewportY += ((e->screenY - downY) * (int)(palmFB.remote.h
			/ palmFB.viewable.h));
	downY = e->screenY;

  } else
	return;

  PositionViewport ();
  PositionScrollbars ();
}


/******************************************************************
 * ProcessScrollKeyEvent
 *
 * Handles events keyEvent for the scrolling hard keys
 ******************************************************************/
static void ProcessScrollKeyEvent (EventPtr e)
{
	DWord keystate = KeyCurrentState();
	if (keystate & keyBitPageUp) viewportY -= 16;
	if (keystate & keyBitPageDown) viewportY += 16;
	if (keystate & keyBitHard3) viewportX -= 16;
	if (keystate & keyBitHard4) viewportX += 16;

	PositionViewport();
	PositionScrollbars();

}


/******************************************************************
 * ProcessScrollPenDownEvent
 *
 * Handles events penDownEvent in scrollers
 *****************************************************************/
static void ProcessScrollPenDownEvent (EventPtr e)
{
  if (InScrollbar (HORIZ, e->screenX , e->screenY)) {
	downX =  e->screenX;

	buttonState = HORIZ;
	return;
  } else if (InScrollbar (VERT,  e->screenX ,  e->screenY)) {
	downY =  e->screenY;

	buttonState = VERT;
	return;
  } else if (InScrollbar (HORIZ_UP,  e->screenX ,  e->screenY)) {
	viewportX -= palmFB.viewable.w;

  } else if (InScrollbar (HORIZ_DOWN, e->screenX , e->screenY)) {
	viewportX += palmFB.viewable.w;

  } else if (InScrollbar (VERT_UP, e->screenX , e->screenY)) {
	viewportY -= palmFB.viewable.h;

  } else if (InScrollbar (VERT_DOWN, e->screenX , e->screenY)) {
	viewportY += palmFB.viewable.h;

  } else
	return;

  buttonState = 0;
  PositionViewport ();
  PositionScrollbars ();
}


/******************************************************************
 * ProcessPenMoveEvent
 *
 * Handles events penMoveEvent in the main form
 *****************************************************************/
static void ProcessPenMoveEvent (EventPtr e)
{
  unsigned long penTime = TimGetTicks ();
  unsigned short serverX, serverY;

  if (DrawingBlocked ())
	return;

  if (penTime <= lastPenTime + 100)
	return;

  serverX = e->screenX + palmFB.viewable.x;
  serverY = e->screenY + palmFB.viewable.y;

  if (buttonState == MAIN_PRESSED || buttonState == MAIN_MOVED) {
	(void)SendPointerEvent (serverX, serverY, currentMouseButton);
	buttonState = MAIN_MOVED;

  }
}


/******************************************************************
 * ProcessPenUpDownEvent
 *
 * Handles events penUpEvent and PenDownEvent in the main form
 *****************************************************************/
static void ProcessPenUpDownEvent (EventPtr e)
{
	unsigned long penTime;
	unsigned short serverX, serverY;

	if (DrawingBlocked ())
		return;

	penTime = TimGetTicks ();
	serverX = e->screenX + palmFB.viewable.x;
	serverY = e->screenY + palmFB.viewable.y;

	if (lastX == 0)
		lastX = serverX;
	if (lastY == 0)
		lastY = serverY;

	if (e->penDown)
	{
		if (pen_zooming == true)
		{
			palmFB.zoomarea_ena = true;
			palmFB.zoomarea.x = e->screenX;
			palmFB.zoomarea.y = e->screenY;
			/* viewportY = palmFB.viewable.y = palmFB.virtual.y = e->screenY; */
			SetScaleFactor(server.scaleFactor);
			pen_zooming = false;
			return;
		}
		else
		{
			if (buttonState == MAIN_ONCE && penTime <= lastPenTime + 100)
			{
				buttonState = MAIN_DOUBLE;
				(void)SendPointerEvent (lastX, lastY, currentMouseButton);
				(void)SendPointerEvent (lastX, lastY, 0);
			}
			else
			{
				buttonState = MAIN_PRESSED;
				// sync the intial mouse position first
				(void)SendPointerEvent (serverX, serverY, 0);
				(void)SendPointerEvent (serverX, serverY, currentMouseButton);
			}

			lastX = serverX;
			lastY = serverY;
			return;
		}
	}

	else
	{   // penUp
		if (buttonState == MAIN_PRESSED)
		{
			(void)SendPointerEvent (lastX, lastY, 0);

			buttonState = MAIN_ONCE;
		}
		else if (buttonState == MAIN_MOVED)
		{
			buttonState = 0;
			(void)SendPointerEvent (serverX, serverY, 0);
		}


		// Allow the masked off key to now send keyDownEvents.
		KeySetMask(keyBitsAll);
		currentMouseButton = 1;
	}

	lastPenTime = penTime;
}


/******************************************************************
 * LoadServerConnection
 *
 * Copies the server connection settings from the appropriate database record
 *****************************************************************/
static void LoadServerConnection (DmOpenRef db, DB_ServerConnection *server, UInt16 index)
{
	VoidHand RecHandle;
	VoidPtr RecPointer;

	char *dummy_name = "My server\0";
	char *dummy_addr = "host.company.com\0";
	char *dummy_username = "username\0";
	char *dummy_passwd = "\0";

	Bool loaded = false;

	if (index > 0)
	{
		// Load an exisiting profile.
		RecHandle = DmGetRecord (db, index);
		if (RecHandle != NULL)
		{
			RecPointer = MemHandleLock (RecHandle);
			if (RecPointer != NULL)
			{
				MemSet (server, sizeof (DB_ServerConnection), (Byte)0);
				MemMove (server, RecPointer, sizeof (DB_ServerConnection));
				loaded = true;
				server->index = index;
				MemHandleUnlock (RecHandle);
			}
			DmReleaseRecord (db, index, true);
		}
	}

	if (loaded == false)
	{
		// fill default values
		server->index = 0;
		MemMove (server->name, dummy_name, StrLen (dummy_name)+1);
		MemMove (server->address, dummy_addr, StrLen (dummy_addr)+1);
		MemMove (server->password, dummy_passwd, StrLen (dummy_passwd)+1);
		server->port = VNC_DATA_PORT_NR;
		server->beginX = 0;
		server->beginY = 0;
		server->scaleFactor = 1;
		server->sharedDesktop = true;
		MemMove (server->loginNameNT, dummy_username, StrLen (dummy_username)+1);
		MemMove (server->passwNT, dummy_passwd, StrLen (dummy_passwd)+1);
	}

	return;
}

/******************************************************************
 * SaveServerConnection
 *
 *  Copies the server connection settings to the database
 *****************************************************************/
static UInt16 SaveServerConnection (DmOpenRef db, DB_ServerConnection *server)
{
	VoidHand RecHandle;
	VoidPtr RecPointer;

	UInt16 local_index;

	local_index = server->index;

	if (local_index > 0)
	{
		// Overwrite an existing profile.
		RecHandle = DmGetRecord (db, server->index);
		if (RecHandle != NULL)
		{
			RecPointer = MemHandleLock (RecHandle);
			if (RecPointer == NULL)
				local_index = 0;
			else
				MemHandleUnlock (RecHandle);
			DmReleaseRecord (db, server->index, true);
		}
		else
			local_index = 0;
	}

	if (local_index == 0)
	{
		// Create a new profile.
		local_index = dmMaxRecordIndex;
		RecHandle = DmNewRecord(db, &local_index, sizeof (DB_ServerConnection));
		RecPointer = MemHandleLock (RecHandle);
		DmWrite(RecPointer, 0, server, sizeof (DB_ServerConnection));
		MemHandleUnlock (RecHandle);
		DmReleaseRecord (db, local_index, true);
	}
	else
	{
		RecHandle = DmGetRecord (db, local_index);
		RecPointer = MemHandleLock (RecHandle);
		DmWrite (RecPointer, 0, server, sizeof (DB_ServerConnection));
		MemHandleUnlock (RecHandle);
		DmReleaseRecord (db, local_index, true);
	}
	server->index = local_index;

	return local_index;
}


/******************************************************************
 * DeleteServerConnection
 *
 *  Removes server connection settings from the database
 *****************************************************************/
static void DeleteServerConnection (DmOpenRef db, UInt16 index)
{
	VoidHand RecHandle;
	VoidPtr RecPointer;

	UInt16 local_index;

	local_index = index;

	if (local_index > 0)
	{
		// Delete an existing profile.
		DmRemoveRecord (db, index);
	}
}





/******************************************************************
 * PasswordFormHandleEvent
 *
 * Handles events in the password entry form
 *****************************************************************/
static Boolean PasswordFormHandleEvent (EventPtr e)
{
  Boolean handled;
  FormPtr frm;
  FieldPtr  fieldPtr;
  VoidHand  passwdH;
  char buffer[32];
  char *str;
  Word field;

  CALLBACK_PROLOGUE

	frm = FrmGetActiveForm();
	handled = false;

	switch (e->eType)
	{
		case menuEvent:
			MenuEraseStatus(NULL);
			field = FrmGetFocus(frm);
			switch(e->data.menu.itemID)
			{
				case ID_EDIT_MENUBAR_COPY:
					FldCopy (FrmGetObjectPtr (frm, field));
					break;

				case ID_EDIT_MENUBAR_PASTE:
					FldPaste (FrmGetObjectPtr (frm, field));
					break;

				default:
					break;
			}
			break;

		default:
			break;
	}

	CALLBACK_EPILOGUE
	return handled;
}

/******************************************************************
 * GetPassword
 *
 * Generates the Password dialog
 *****************************************************************/
Boolean GetPassword (char* password, int maxlength)
{
 	FormPtr previousForm = FrmGetActiveForm();
	FormPtr frm = FrmInitForm(ID_PASSWORD);
	UInt16 hitButton;
	FieldPtr fieldPtr;
	MemHandle passwdH;
	
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, PasswordFormHandleEvent);

	/* Set default password to blank */
	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_PASSWORD_PASSWORD));
	passwdH = MemHandleNew (maxlength);
	MemMove (MemHandleLock (passwdH), "\0", 1);
	MemHandleUnlock (passwdH);
	FldSetTextHandle (fieldPtr, (Handle)passwdH);
	FrmSetFocus(frm, FrmGetObjectIndex(frm, ID_PASSWORD_PASSWORD));

	hitButton = FrmDoDialog(frm);
	
	if (hitButton == ID_PASSWORD_OK)
	{
		MemSet (password, maxlength, 0);
		if ((FldGetTextPtr (fieldPtr) != NULL) && ((StrLen (FldGetTextPtr (fieldPtr)) + 1) < maxlength))
			MemMove (password, FldGetTextPtr (fieldPtr), StrLen (FldGetTextPtr (fieldPtr)) + 1);
		else
			hitButton = ID_PASSWORD_CANCEL;
	}
	
	if (previousForm)
		FrmSetActiveForm(previousForm);
	FrmDeleteForm(frm);
	
	return (hitButton == ID_PASSWORD_OK);
}


/******************************************************************
 * ServerDetailsFormHandleEvent
 *
 * Handles events in the console form
 *****************************************************************/
static Boolean ServerDetailsFormHandleEvent (EventPtr e)
{
  Boolean handled, closeServerDetails;
  FormPtr frm;
  FormPtr passwdFrm;
  FieldPtr  fieldPtr;
  FieldPtr  pw_Fptr;
  Word field;

  CALLBACK_PROLOGUE

	frm = FrmGetActiveForm();
	handled = false;
	closeServerDetails = false;

  switch (e->eType)
  {
		case ctlSelectEvent:
			switch(e->data.ctlSelect.controlID)
			{
				case ID_SERVERDETAILS_NTPASSWORD:
					GetPassword(server.passwNT, 32);
					if (StrLen(server.passwNT) == 0)
						CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVERDETAILS_NTPASSWORD)), "-Prompt-");
					else
						CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVERDETAILS_NTPASSWORD)), "-Assigned-");
					FrmDrawForm(frm);
					handled = true;
					break;

				default:
					break;
			}
			break;

		case menuEvent:
			MenuEraseStatus(NULL);
			field = FrmGetFocus(frm);
			switch(e->data.menu.itemID)
			{
				case ID_EDIT_MENUBAR_COPY:
					FldCopy (FrmGetObjectPtr (frm, field));
					break;

				case ID_EDIT_MENUBAR_PASTE:
					FldPaste (FrmGetObjectPtr (frm, field));
					break;

				default:
					break;
			}
			break;

		default:
			break;

	}

  CALLBACK_EPILOGUE
  return handled;
}


/******************************************************************
 * ServerDetails
 *
 * Generates the Server Details dialog
 *****************************************************************/
Boolean ServerDetails ()
{
 	FormPtr previousForm = FrmGetActiveForm();
	FormPtr frm = FrmInitForm(ID_SERVERDETAILS);
	UInt16 hitButton;
	FieldPtr fieldPtr;
    VoidHand  beginXH, beginYH, scaleFactorH, loginNTH, passwNTH;
  	char buffer[32];
  	char *str;
	
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, ServerDetailsFormHandleEvent);

	/* Set default values */
	if (StrLen(server.passwNT) == 0)
		CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVERDETAILS_NTPASSWORD)), "-Prompt-");
	else
		CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVERDETAILS_NTPASSWORD)), "-Assigned-");

	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_BEGINX));
	beginXH = MemHandleNew (5);
	str = StrIToA (buffer, server.beginX);
	MemMove (MemHandleLock (beginXH), str, StrLen (str)+1);
	MemHandleUnlock (beginXH);
	FldSetTextHandle (fieldPtr, (Handle)beginXH);

	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_BEGINY));
	beginYH = MemHandleNew (5);
	str = StrIToA (buffer, server.beginY);
	MemMove (MemHandleLock (beginYH), str, StrLen (str)+1);
	MemHandleUnlock (beginYH);
	FldSetTextHandle (fieldPtr, (Handle)beginYH);

	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_SCALE));
	scaleFactorH = MemHandleNew (2);
	str = StrIToA (buffer, server.scaleFactor);
	MemMove (MemHandleLock (scaleFactorH), str, StrLen (str)+1);
	MemHandleUnlock (scaleFactorH);
	FldSetTextHandle (fieldPtr, (Handle)scaleFactorH);

	FrmSetControlValue (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_SHARING), server.sharedDesktop);

	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_NTNAME));
	loginNTH = MemHandleNew (32);
	MemMove (MemHandleLock (loginNTH), server.loginNameNT, StrLen (server.loginNameNT)+1);
	MemHandleUnlock (loginNTH);
	FldSetTextHandle (fieldPtr, (Handle)loginNTH);

	hitButton = FrmDoDialog(frm);
	
	if (hitButton == ID_SERVERDETAILS_OK)
	{
		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_BEGINX)));
		server.beginX = StrAToI (str);

		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_BEGINY)));
		server.beginY = StrAToI (str);

		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_SCALE)));
		server.scaleFactor = StrAToI (str);

		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_NTNAME)));
		MemSet (server.loginNameNT, 32, 0);
		MemMove (server.loginNameNT, str, StrLen (str));

		server.sharedDesktop = FrmGetControlValue (frm, FrmGetObjectIndex (frm, ID_SERVERDETAILS_SHARING));
	}
	
	if (previousForm)
		FrmSetActiveForm(previousForm);
	FrmDeleteForm(frm);
	
	return (hitButton == ID_SERVERDETAILS_OK);
}


/******************************************************************
 * ServerEditFormHandleEvent
 *
 * Handles events in the console form
 *****************************************************************/
static Boolean ServerEditFormHandleEvent (EventPtr e)
{
  Boolean handled, closeServerEdit;
  FormPtr frm;
  FormPtr passwdFrm;
  FieldPtr  pw_Fptr;
  char buffer[32];
  char *str;
  Word field;

  CALLBACK_PROLOGUE

	frm = FrmGetActiveForm();
	handled = false;
	closeServerEdit = false;

  switch (e->eType)
  {
	case ctlSelectEvent:
		switch(e->data.ctlSelect.controlID)
		{
			case ID_SERVEREDIT_DETAILS:
				ServerDetails();
				handled = true;
				break;
				
			case ID_SERVEREDIT_PASSWORD:
				GetPassword(server.password, 32);
				if (StrLen(server.password) == 0)
					CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVEREDIT_PASSWORD)), "-Prompt-");
				else
					CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVEREDIT_PASSWORD)), "-Assigned-");
				FrmDrawForm(frm);
				handled = true;
				break;

			default:
				break;
		}
		break;

	case menuEvent:
		MenuEraseStatus(NULL);
		field = FrmGetFocus(frm);
		switch(e->data.menu.itemID)
		{
			case ID_EDIT_MENUBAR_COPY:
				FldCopy (FrmGetObjectPtr (frm, field));
				break;

			case ID_EDIT_MENUBAR_PASTE:
				FldPaste (FrmGetObjectPtr (frm, field));
				break;

			default:
				break;
		}
		break;

	default:
		break;

  }

  CALLBACK_EPILOGUE

  return handled;
}


/******************************************************************
 * ServerEdit
 *
 * Generates the Server Edit dialog
 *****************************************************************/
Boolean ServerEdit ()
{
 	FormPtr previousForm = FrmGetActiveForm();
	FormPtr frm = FrmInitForm(ID_SERVEREDIT);
	UInt16 hitButton;
	FieldPtr fieldPtr;
	VoidHand  nameH, addrH, displayH, passwdH;
  	char buffer[32];
  	char *str;
	
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, ServerEditFormHandleEvent);

	/* Set default values */
	fieldPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVEREDIT_NAME));
	nameH = MemHandleNew (32);
	MemMove (MemHandleLock (nameH), server.name, StrLen (server.name)+1);
	MemHandleUnlock (nameH);
	FldSetTextHandle (fieldPtr, (Handle)nameH);
	
	fieldPtr = FrmGetObjectPtr (frm,
	FrmGetObjectIndex (frm, ID_SERVEREDIT_ADDRESS));
	addrH = MemHandleNew (32);
	MemMove (MemHandleLock (addrH),
	server.address, StrLen (server.address)+1);
	MemHandleUnlock (addrH);
	FldSetTextHandle (fieldPtr, (Handle)addrH);
	
	fieldPtr = FrmGetObjectPtr (frm,
	FrmGetObjectIndex (frm, ID_SERVEREDIT_DISPLAY));
	displayH = MemHandleNew (6);
	str = StrIToA (buffer, server.port-VNC_DATA_PORT_NR);
	MemMove (MemHandleLock (displayH), str, StrLen (str)+1);
	MemHandleUnlock (displayH);
	FldSetTextHandle (fieldPtr, (Handle)displayH);
	
	if (StrLen(server.password) == 0)
	{
		CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVEREDIT_PASSWORD)), "-Prompt-");
	}
	else
	{
		CtlSetLabel(FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, ID_SERVEREDIT_PASSWORD)), "-Assigned-");
	}
	FrmSetFocus(frm, FrmGetObjectIndex(frm, ID_SERVEREDIT_NAME));

	hitButton = FrmDoDialog(frm);
	
	if (hitButton == ID_SERVEREDIT_OK)
	{
		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVEREDIT_NAME)));
		MemSet (server.name, 32, 0);
		MemMove (server.name, str, StrLen (str));

		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVEREDIT_ADDRESS)));
		MemSet (server.address, 32, 0);
		MemMove (server.address, str, StrLen (str));

		str = FldGetTextPtr (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVEREDIT_DISPLAY)));
		server.port = (StrAToI (str)) + VNC_DATA_PORT_NR;
	}
	
	if (previousForm)
		FrmSetActiveForm(previousForm);
	FrmDeleteForm(frm);
	
	return (hitButton == ID_SERVEREDIT_OK);
}


/******************************************************************
 * ServerSelect_PopulateList
 *
 * Fills in the list of available servers
 *****************************************************************/
Boolean ServerSelect_PopulateList (FormPtr frm, Boolean do_populate)
{
  	ListPtr listPtr;
  	static int servers_list_count = 0;
  	static MemHandle servers_listH = NULL;
  	static MemHandle serverH_H = NULL;
  	static MemHandle* serverH = NULL;
  	static Char** servers_list = NULL;

  	UInt16 NumServers;
  	VoidHand RecHandle;
  	DB_ServerConnection* RecPointer;
  	UInt16 index;

	/* Clear any old lists */
	listPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERSELECT_LIST));
	LstSetListChoices(listPtr, NULL, 0);
	
	if (servers_list_count != 0)
	{
		for (index = 0; index < servers_list_count; index++)
		{
			MemHandleUnlock(serverH[index]);
			MemHandleFree(serverH[index]);
		}
		MemHandleUnlock(serverH_H);
		MemHandleFree(serverH_H);
		MemHandleUnlock(servers_listH);
		MemHandleFree(servers_listH);
		servers_list_count = 0;
	}
	
	if (do_populate == false)
		return false;
	
	/* Look for stored server configurations */
	NumServers = DmNumRecordsInCategory(prefDB, dmAllCategories) - 1;
	if (NumServers == 0)
		return false;

	/* Build an index of available servers */
	servers_list_count = NumServers;
	servers_listH = MemHandleNew (sizeof(char*) * servers_list_count);
	servers_list = MemHandleLock(servers_listH);
	serverH_H = MemHandleNew (sizeof(MemHandle) * servers_list_count);
	serverH = MemHandleLock(serverH_H);
	index = 1;
	while ((RecHandle = DmQueryNextInCategory(prefDB, &index, dmAllCategories)) != NULL)
	{
		RecPointer = MemHandleLock(RecHandle);
		serverH[index-1] = MemHandleNew(sizeof(char) * (StrLen (RecPointer->name) + 1));
		servers_list[index-1] = MemHandleLock(serverH[index-1]);
		MemMove (servers_list[index-1], RecPointer->name, sizeof(char) * (StrLen (RecPointer->name) + 1));
		MemHandleUnlock( RecHandle);
		index++;
	}
	LstSetListChoices(listPtr, servers_list, servers_list_count);
	if ((pref.lastServer > 0) && (pref.lastServer <= servers_list_count))
		LstSetSelection(listPtr, pref.lastServer - 1);
	else
		LstSetSelection(listPtr, 0);
		
	return true;
}


/******************************************************************
 * ServerSelectFormHandleEvent
 *
 * Handles events in the server selection form
 *****************************************************************/
static Boolean ServerSelectFormHandleEvent (EventPtr e)
{

  	Boolean handled, closeServerSelectForm;
  	FormPtr frm;
  	FormPtr editFrm;
	UInt16 index;
  	ListPtr listPtr;

  	CALLBACK_PROLOGUE

	frm = FrmGetActiveForm();
	handled = false;
	closeServerSelectForm = false;

	switch (e->eType)
	{
		case frmOpenEvent:
			FrmDrawForm(frm);
			break;

		case frmCloseEvent:
			closeServerSelectForm = true;
			handled = true;
			break;

		case ctlSelectEvent:
			switch(e->data.ctlSelect.controlID)
			{

				case ID_SERVERSELECT_NEW:
				case ID_SERVERSELECT_EDIT:
					if (e->data.ctlSelect.controlID == ID_SERVERSELECT_NEW)
						index = 0;
					else
					{
						listPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERSELECT_LIST));
						index = LstGetSelection(listPtr) + 1;
					}
					LoadServerConnection(prefDB, &server, index);
					if (ServerEdit())
						SaveServerConnection(prefDB, &server);
					else
						LoadServerConnection(prefDB, &server, index);
					pref.lastServer = index;
					ServerSelect_PopulateList(frm, true);
					FrmDrawForm(frm);
					handled = true;
					break;

				case ID_SERVERSELECT_COPY:
				case ID_SERVERSELECT_DELETE:
					listPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERSELECT_LIST));
					switch (e->data.ctlSelect.controlID)
					{
						case ID_SERVERSELECT_COPY:
							index = LstGetSelection(listPtr);
							if (index != noListSelection)
							{
								index++;
								LoadServerConnection(prefDB, &server, index);
								server.index = 0;
								pref.lastServer = SaveServerConnection(prefDB, &server);
								ServerSelect_PopulateList(frm, true);
								FrmDrawForm(frm);
							}
							handled = true;
							break;

						case ID_SERVERSELECT_DELETE:
							index = LstGetSelection(listPtr);
							if (index != noListSelection)
							{
								index++;
								LoadServerConnection(prefDB, &server, index);
								if (FrmCustomAlert(ID_ALERT_SERVERDELETE, server.name, "", "") == 0)
								{
									DeleteServerConnection(prefDB, index);
									pref.lastServer = 1;
									ServerSelect_PopulateList(frm, true);
									FrmDrawForm(frm);
								}
							}
							handled = true;
							break;
					}
					break;

				default:
					 break;
			}
			break;

		default:
			break;
	}

	if (closeServerSelectForm)
	{
		// the memory under field text handles is freed by the UI manager
		CALLBACK_EPILOGUE
		FrmReturnToForm (ID_MAIN);
	}

	CALLBACK_EPILOGUE
	return handled;
}


/******************************************************************
 * ServerSelect
 *
 * Generates the ServerSelect dialog
 *****************************************************************/
Boolean ServerSelect ()
{
  	ListPtr listPtr;
	FormPtr previousForm = FrmGetActiveForm();
	FormPtr frm = FrmInitForm(ID_SERVERSELECT);
	UInt16 hitButton;
	UInt16 index;
	
	FrmSetActiveForm(frm);
	FrmSetEventHandler(frm, ServerSelectFormHandleEvent);

	/* Populate list */
	if (!ServerSelect_PopulateList(frm, true))
	{
		/* Request new default server */
		LoadServerConnection(prefDB, &server, 0);
		if (!ServerEdit())
		{
			if (previousForm)
				FrmSetActiveForm(previousForm);
			FrmDeleteForm(frm);
			return false;
		}
		SaveServerConnection(prefDB, &server);
		ServerSelect_PopulateList(frm, true);
	}

	hitButton = FrmDoDialog(frm);
	
	if (hitButton == ID_SERVERSELECT_OPEN)
	{
		listPtr = FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, ID_SERVERSELECT_LIST));
		index = LstGetSelection(listPtr);
		if (index != noListSelection)
		{
			index++;
			LoadServerConnection(prefDB, &server, index);
			pref.lastServer = index;
		}
		else
			hitButton = ID_SERVERSELECT_CANCEL;
	}

	/* Empty list */
	ServerSelect_PopulateList(frm, false);
	
	if (previousForm)
		FrmSetActiveForm(previousForm);
	FrmDeleteForm(frm);

	return (hitButton == ID_SERVERSELECT_OPEN);
}


/******************************************************************
 * ConsoleFormHandleEvent
 *
 * Handles events in the Console form
 *****************************************************************/
static Boolean ConsoleFormHandleEvent (EventPtr e)
{
	Boolean handled;
	FormPtr frm;
	Word field;

	CALLBACK_PROLOGUE

	handled = false;
	frm = FrmGetActiveForm();

	// Let StdIO handler to it's things first.
	if (StdHandleEvent(e)) {
	  CALLBACK_EPILOGUE
	  return true;
	}

	switch (e->eType) {
	case frmOpenEvent:
	FrmDrawForm(frm);
	handled = true;
	break;

	case ctlSelectEvent:
	switch(e->data.ctlSelect.controlID) {
	  case ID_CONSOLE_CLOSE:
		(void)StdSave();
		FrmReturnToForm (ID_MAIN);
		handled = true;
		break;
	  case ID_CONSOLE_CLEAR:
		StdClear();
		handled = true;
		break;
	  default:
		handled = true;
		break;
	}
	break;

	case menuEvent:
	MenuEraseStatus(NULL);
	field = FrmGetFocus(frm);
	switch(e->data.menu.itemID) {
	  case ID_EDIT_MENUBAR_COPY:
		FldCopy (FrmGetObjectPtr (frm, field));
		break;

	  case ID_EDIT_MENUBAR_PASTE:
		FldPaste (FrmGetObjectPtr (frm, field));
		break;

	  default:
		break;
	}
	break;

	default:
		break;
	}

	CALLBACK_EPILOGUE

	return handled;
}


/******************************************************************
 * MainFormHandleEvent
 *
 *
 *****************************************************************/
static Boolean MainFormHandleEvent (EventPtr e)
{
	Boolean handled;
	FormPtr frm;
	unsigned short oneKey;
	Word clipboardLength;
	VoidHand handle;
	VoidPtr ptr;
	int scale;

	char mypass[32];
	FormPtr passwdFrm;
	FieldPtr  pw_Fptr;

	CALLBACK_PROLOGUE

	handled = false;

	switch (e->eType) {
	case frmOpenEvent:
	frm = FrmGetActiveForm();
	FrmDrawForm(frm);
	CreateWindows (frm);

	InitVirtual ();
	UpdateScrollbars ();
	UpdateViewport ();
	handled = true;
	break;

	case frmUpdateEvent:
	UpdateViewport ();
	UpdateScrollbars ();

	handled = true;
	break;

	case nilEvent:
		UpdateViewport ();
		break;

	case menuEvent:
	/*MenuEraseStatus(NULL);*/

	switch(e->data.menu.itemID) {
	  case ID_MAIN_MENUBAR_VIEW_OPENCONSOLE:
		FrmPopupForm (ID_CONSOLE);
		UpdateViewport ();
		break;

	  case ID_MAIN_MENUBAR_SERVER_OPEN:
		if (ServerSelect())
		{
			if (rfbsock > 0)
				ShutdownConnection();
			if (!OpenConnection ())
		  		(void)FrmPopupForm (ID_CONSOLE);
			else
				PositionScrollbars ();
		}
		break;

	  case ID_MAIN_MENUBAR_SERVER_CLOSE:
		ShutdownConnection ();
		break;

	  case ID_MAIN_MENUBAR_SERVER_DISCONNECT:
		ShutdownNetwork (true);
		PostProgressMessage ("Modem disconnected", 0, 0);
		break;

	  case ID_MAIN_MENUBAR_SERVER_NETWORK:
		OpenNetworkPreferences();
		break;

	  case ID_MAIN_MENUBAR_HELP_ABOUT:
		FrmCustomAlert(ID_ALERT_ABOUT, PALMVNC_VERSION, NULL, NULL);
		break;

	  case ID_MAIN_MENUBAR_HELP_HELP:
		FrmHelp(ID_HELP_GENERAL);
		break;

		  // request a "hard" update of the whole virtual area
	  case ID_MAIN_MENUBAR_VIEW_REFRESH:
		(void)SendFramebufferUpdateRequest((int)palmFB.virtual.x,
		(int)palmFB.virtual.y,
		(int)palmFB.virtual.w,
		(int)palmFB.virtual.h,
		false);
		break;

	  case ID_MAIN_MENUBAR_VIEW_SAVEPOSITION:
			server.beginX = palmFB.viewable.x;
			server.beginY = palmFB.viewable.y;
			break;

	  case ID_MAIN_MENUBAR_SEND_CTRLALTDEL:
		oneKey = DEL_KEY;
		SendKeySequence (CTRL_KEY, ALT_KEY, 0, &oneKey, 1, false);
		break;

	  case ID_MAIN_MENUBAR_VIEW_SPECIALKEYS:
		ToggleKeyboardState();
		break;


	  case ID_MAIN_MENUBAR_SEND_ALTF4:
		oneKey = F4_KEY;
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);
		break;

	  case ID_MAIN_MENUBAR_SEND_LOGIN:
		// switch to the user name text field
		oneKey = (unsigned char)'u';
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);

		// send the user name
		if (StrLen (server.loginNameNT) > 0) {
		  SendKeySequence (0, 0, 0, (unsigned short *)&server.loginNameNT,
				StrLen (server.loginNameNT), true);

		  // switch to the password text field
		  oneKey = (unsigned char)'p';
		  SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);

		  // send the password
			if (StrLen(server.passwNT) == 0)
			{
				MemSet (mypass, 32, 0);
				GetPassword(mypass, 32);
			}
			else
			{
				StrCopy(mypass, server.passwNT);
			}
		  if (StrLen (mypass) > 0)
			SendKeySequence (0, 0, 0, (unsigned short *)&mypass,
				StrLen (mypass), true);
		}

		// confirm with "enter", even if no user name or password
		oneKey = ENTER_KEY;
		SendKeySequence (0, 0, 0, &oneKey, 1, false);

		break;

	  case ID_MAIN_MENUBAR_SEND_LOGOUT:
		oneKey = (unsigned char)'l';
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);
		oneKey = ENTER_KEY;
		SendKeySequence (0, 0, 0, &oneKey, 1, false);
		break;

	  case ID_MAIN_MENUBAR_SEND_LOCK:
		oneKey = (unsigned char)'w';
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);
		break;

	  case ID_MAIN_MENUBAR_SEND_REBOOT:
		oneKey = (unsigned char)'s';
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);
		oneKey = (unsigned char)'r';
		SendKeySequence (ALT_KEY, 0, 0, &oneKey, 1, false);
		oneKey = ENTER_KEY;
		SendKeySequence (0, 0, 0, &oneKey, 1, false);
		break;

	  case ID_MAIN_MENUBAR_SEND_CLIPBOARD:
		handle = ClipboardGetItem (clipboardText, &clipboardLength);
		if (handle != 0 && clipboardLength != 0) {
		  ptr = MemHandleLock (handle);
		  SendClientCutText (ptr, clipboardLength);
		  (void)MemHandleUnlock (handle);
		}
		break;

	  case ID_MAIN_MENUBAR_VIEW_SCALEDESKTOP:
	  case ID_MAIN_MENUBAR_VIEW_SCALE1:
	  case ID_MAIN_MENUBAR_VIEW_SCALE2:
	  case ID_MAIN_MENUBAR_VIEW_SCALE3:
	  case ID_MAIN_MENUBAR_VIEW_SCALE4:
		palmFB.zoomarea_ena = true;
		palmFB.zoomarea.x = viewportX + (palmFB.viewable.w / 2);
		palmFB.zoomarea.y = viewportY + (palmFB.viewable.h / 2);
		switch (e->data.menu.itemID)
		{
			case ID_MAIN_MENUBAR_VIEW_SCALEDESKTOP:
				scale = (palmFB.desktop.w / palmFB.viewable.w);
				if (palmFB.desktop.w > (palmFB.viewable.w * scale)) scale++;
				if ((palmFB.desktop.h / palmFB.viewable.h) > scale) scale = (palmFB.desktop.h / palmFB.viewable.h);
				if (palmFB.desktop.h > (palmFB.viewable.h * scale)) scale++;
				pen_zooming = true;
				break;

			case ID_MAIN_MENUBAR_VIEW_SCALE2:   scale = 2;  break;
			case ID_MAIN_MENUBAR_VIEW_SCALE3:   scale = 3;  break;
			case ID_MAIN_MENUBAR_VIEW_SCALE4:   scale = 4;  break;
			default:                            scale = 1;  break;
		}

		SetScaleFactor(scale);
		break;

	  default:
		break;
	}
		handled = true;
	break;

	case penDownEvent:
		if (rfbsock <= 0)
			break;

		if (InKeyboardArea (e->screenX, e->screenY))
		{
			ProcessKeyboardPenDownEvent(e);
			handled = true;
			break;
		}
		else if (!InMainArea (e->screenX, e->screenY))
		{
			ProcessScrollPenDownEvent (e);
			handled = true;
			break;
		}

	case penUpEvent:
		if (rfbsock <= 0)
			  break;

		if (InKeyboardArea (e->screenX, e->screenY))
		{
			ProcessKeyboardPenUpEvent(e);
			handled = true;
		}
		else if (InMainArea (e->screenX, e->screenY))
		{
			ProcessPenUpDownEvent (e);
			handled = true;
		}
		else
			buttonState = 0;

		break;


	case penMoveEvent:
		if (rfbsock <= 0)
		  break;

		if (buttonState == HORIZ || buttonState == VERT /*!InMainArea (e->screenX, e->screenY)*/) {
		  ProcessScrollPenMoveEvent (e);
		  handled = true;
			  break;
			}
		else
		  if (!(InKeyboardArea (e->screenX, e->screenY)))
			ProcessPenMoveEvent (e);

		handled = true;
		break;

	case keyDownEvent:

	/* Allow keyboard areas of Graffiti to activate special keys menu */
	if  ((e->data.keyDown.modifiers & commandKeyMask) &&
		((e->data.keyDown.chr == vchrKeyboard) ||
		 (e->data.keyDown.chr == vchrKeyboardNumeric) ||
		 (e->data.keyDown.chr == vchrKeyboardAlpha)))
	{
		if (rfbsock <= 0)
			break;
		ToggleKeyboardState();
		handled = true;
		KeySetMask(~KeyCurrentState());
		UpdateViewport();
		break;
	}

	// the hardware key 1 (DateBook) used to emulate the middle mouse button
	if (KeyCurrentState() & keyBitHard1)
	{
		if (currentMouseButton)
		{
			if (KeyCurrentState() & keyBitHard2)
				currentMouseButton = 0;
			else
				currentMouseButton = 2;
		}
		handled = true;
		// Mask off the key to avoid repeat keys causing clicking sounds
		KeySetMask(~KeyCurrentState());
		break;
	}
	// the hardware key 2 (PhoneBook) used to emulate the right mouse button
	if (KeyCurrentState() & keyBitHard2)
	{
		if (currentMouseButton)
		{
			if (KeyCurrentState() & keyBitHard1)
				currentMouseButton = 0;
			else
				currentMouseButton = 4;
		}
		handled = true;
		// Mask off the key to avoid repeat keys causing clicking sounds
		KeySetMask(~KeyCurrentState());
		break;
	}

	if (KeyCurrentState() & (keyBitHard3 | keyBitHard4 | keyBitPageUp | keyBitPageDown))
	{
		ProcessScrollKeyEvent(e);
		handled = true;
		break;
	}

	if ((!(e->data.keyDown.modifiers & commandKeyMask)) && IsAscii (e->data.keyDown.chr))
	{
		SendKeySequence (0, 0, 0, &(e->data.keyDown.chr), 1, false);
	}

		handled = true;
	break;

	default:
		break;
	}

	CALLBACK_EPILOGUE

	return handled;
}


/******************************************************************
 * ApplicationHandleEvent
 *
 * loads the form and sets up event handlers
 *****************************************************************/
static Boolean ApplicationHandleEvent (EventPtr e)
{
	FormPtr frm;
	Word    formId;
	Boolean handled = false;

	if (e->eType == frmLoadEvent)
	{
		formId = e->data.frmLoad.formID;
		frm = FrmInitForm (formId);
		FrmSetActiveForm (frm);

		switch(formId)
		{
			case ID_MAIN:
				FrmSetEventHandler(frm, MainFormHandleEvent);
				break;

			case ID_CONSOLE:
				FrmSetEventHandler(frm, ConsoleFormHandleEvent);
				break;

			case ID_SERVERSELECT:
				FrmSetEventHandler(frm, ServerSelectFormHandleEvent);
				break;

			case ID_SERVEREDIT:
				FrmSetEventHandler(frm, ServerEditFormHandleEvent);
				break;

			case ID_SERVERDETAILS:
				FrmSetEventHandler(frm, ServerDetailsFormHandleEvent);
				break;

			case ID_PASSWORD:
				FrmSetEventHandler(frm, PasswordFormHandleEvent);
				break;
		}
		handled = true;
	}

	return handled;
}


/******************************************************************
 * OpenDatabase
 *
 * Opens the database, or converts database from previous version, and load preferences
 *****************************************************************/
 static DmOpenRef OpenDatabase (DB_GlobalPreferences* pref)
{
	UInt index = 0;
	VoidHand RecHandle;
	VoidPtr RecPointer;
	DmOpenRef db;
	Word err, oldRecordSize;
	Bool create_new = false;
	DmSearchStateType search_data;
	UInt16 cardNo;
	LocalID dbID;

	// First, check that if the database does exist, it is the correct version
	if (!(db = DmOpenDatabaseByTypeCreator ('Data', CREATOR_ID, dmModeReadWrite)))
		create_new = true;
	else
	{
		RecHandle = DmGetRecord (db, 0);
		RecPointer = MemHandleLock (RecHandle);
		oldRecordSize = MemPtrSize (RecPointer);
		if (oldRecordSize != sizeof (DB_GlobalPreferences))
			create_new = true;
		else
		{
			MemSet (pref, sizeof (DB_GlobalPreferences), (Byte)0);
			MemMove (pref, RecPointer, sizeof (DB_GlobalPreferences));
			if (pref->databaseVersion != PALMVNC_DB_VERSION)
				create_new = true;
		}
		MemHandleUnlock (RecHandle);
		DmReleaseRecord(db, 0, true);
		DmCloseDatabase(db);
	}


	if (create_new == true)
	{
		// Create new database
		printf("Creating new database.\n");
		while (DmGetNextDatabaseByTypeCreator(true, &search_data, 'Data', CREATOR_ID, false, &cardNo, &dbID) == errNone)
			DmDeleteDatabase(cardNo, dbID);

		if ((err = DmCreateDatabase (0, DATABASE_NAME, CREATOR_ID, 'Data', false)))
			return 0;

		pref->databaseVersion = PALMVNC_DB_VERSION;
		pref->lastServer = 0;

		db = DmOpenDatabaseByTypeCreator ('Data', CREATOR_ID, dmModeReadWrite);
		RecHandle = DmNewRecord(db, &index, sizeof (DB_GlobalPreferences));
		DmWrite(MemHandleLock (RecHandle), 0, pref, sizeof (DB_GlobalPreferences));
		MemHandleUnlock (RecHandle);
		DmReleaseRecord (db, index, true);
	}
	else
	{
		// Load an existing database
		db = DmOpenDatabaseByTypeCreator ('Data', CREATOR_ID, dmModeReadWrite);
		RecHandle = DmGetRecord (db, 0);
		RecPointer = MemHandleLock (RecHandle);
		MemSet (pref, sizeof (DB_GlobalPreferences), (Byte)0);
		MemMove (pref, RecPointer, sizeof (DB_GlobalPreferences));
		MemHandleUnlock (RecHandle);
		DmReleaseRecord (db, 0, true);
	}

  return db;
}

/******************************************************************
 * CloseDatabase
 *
 * Save preferences information.
 *****************************************************************/
static void CloseDatabase (DmOpenRef db, DB_GlobalPreferences* pref)
{
  VoidPtr p = MemHandleLock (DmGetRecord(db, 0));
  DmWrite (p, 0, pref, sizeof (DB_GlobalPreferences));
  MemPtrUnlock (p);
  DmReleaseRecord (db, 0, true);
  DmCloseDatabase(db);
}


/******************************************************************
 * StartApplication
 *
 * Get preferences, open (or create) app database
 *****************************************************************/
static Word StartApplication (void)
{
  Err err;

  // Init our terminal functions for printing to the screen
  // They allow to use printf () & Co. with the output to
  // a text field in the Console form
  StdInit (ID_CONSOLE, ID_CONSOLE_IO, ID_CONSOLE_SCROLLBAR);

  // Get the refNum of the Net Library
  err = SysLibFind ("Net.lib", &AppNetRefnum);
  if (err) {
	ErrDisplay ("\nNet Library not found, exiting...");
	return err;
  }

  palmFB.viewable.x = palmFB.viewable.y = 0;
  palmFB.viewable.h = VIEWABLE_MAX_H - SCROLLBAR_SIZE;
  palmFB.viewable.w = VIEWABLE_MAX_W - SCROLLBAR_SIZE;
  palmFB.virtual.x = palmFB.virtual.y = 0;
  palmFB.zoomarea_ena = false;

	palmFB.virtual.h = VIRTUAL_30_MAX_H;
	palmFB.virtual.w = VIRTUAL_30_MAX_W;
	virtualBounds.extent.x = VIRTUAL_30_MAX_W;
	virtualBounds.extent.y = VIRTUAL_30_MAX_H;

  palmFB.remote.x = palmFB.remote.y = palmFB.remote.h = palmFB.remote.w = 0;

  pen_zooming = false;

  // get preferences which overwrite default values if DB exists
  if ((prefDB = OpenDatabase(&pref)) == 0)
	return dmErrCantOpen;

  FrmGotoForm(ID_MAIN);
  return 0;
}


/******************************************************************
 * StopApplication
 *
 * Save preferences, close forms, close app database
 *****************************************************************/
static void StopApplication (void)
{
	FrmSaveAllForms();
/*  FrmCloseAllForms(); */
	ShutdownNetwork (false);
	StdFree();
	CloseDatabase(prefDB, &pref);

	if (screenDepth == 8)
	{
		WinPalette (winPaletteSetToDefault, 0, 0, 0);
	}

	ScrDisplayMode(scrDisplayModeSetToDefaults,
				NULL, NULL, NULL, NULL);

}


/******************************************************************
 * EventLoop
 *
 * The main event loop
 *****************************************************************/
static void EventLoop (void)
{
  Word err;
  EventType e;
  fd_set fds;
  long eventTimeout;
  Boolean passSystem = false;

  do {
	if (rfbsock)
	  eventTimeout = 0; // we sleep in select
	else
	  eventTimeout = evtWaitForever;

	EvtGetEvent(&e, eventTimeout);

	// we capture the DateBook and PhoneBook keys to emulate
	// the second and the third mouse buttons
	passSystem = e.eType == keyDownEvent &&
		(e.data.keyDown.chr == hard1Chr ||
		 e.data.keyDown.chr == hard2Chr ||
		 e.data.keyDown.chr == hard3Chr ||
		 e.data.keyDown.chr == hard4Chr ||
		 e.data.keyDown.chr == pageUpChr ||
		 e.data.keyDown.chr == pageDownChr ||
		 e.data.keyDown.chr == vchrKeyboard ||
		 e.data.keyDown.chr == vchrKeyboardAlpha ||
		 e.data.keyDown.chr == vchrKeyboardNumeric) ;

	if (passSystem) {
	  if (!ApplicationHandleEvent (&e))
	FrmDispatchEvent (&e);
	}
	else {
	  if (!SysHandleEvent (&e))
		if (!MenuHandleEvent (NULL, &e, &err))
	  if (!ApplicationHandleEvent (&e))
		FrmDispatchEvent (&e);
	}

	if (rfbsock <= 0)
	  continue;

	FD_ZERO (&fds);
	FD_SET (sysFileDescStdIn, &fds);
	FD_SET (rfbsock,&fds);

	if (updateViewportSize)
	{

	  WinHandle prevDrawWin = WinGetDrawWindow ();
	  WinSetDrawWindow (canvas);
	  WinEraseWindow ();
	  WinSetDrawWindow(prevDrawWin);

	  viewportX = palmFB.virtual.x;
	  viewportY = palmFB.virtual.y;

		/* set up the size of scrollbar slides */
		horizSlideRect.extent.x =
		(SWord)(((UInt32)palmFB.virtual.w * (UInt32)palmFB.virtual.w) /
			palmFB.remote.w);
		vertSlideRect.extent.y =
		(SWord)(((UInt32)palmFB.virtual.h * (UInt32)palmFB.virtual.h) /
			palmFB.remote.h);

		/* set the pen time tracing, used to catch double-taps */
		lastPenTime = TimGetTicks ();

		(void)SendFramebufferUpdateRequest((int)palmFB.virtual.x,
		(int)palmFB.virtual.y,
		(int)palmFB.virtual.w,
		(int)palmFB.virtual.h,
		false);

		UpdateViewport();
		PositionScrollbars();
		updateViewportSize = false;
		sendUpdateRequest = false;
	}

	if (sendUpdateRequest) {
	  if (!SendIncrementalFramebufferUpdateRequest())
	ShutdownConnection();
	  sendUpdateRequest = false;
	}

// the BSD select() call cannot be compiled with GCC, use the native one
//   if (select (FD_SETSIZE, &fds, NULL, NULL, NULL) < 0) {

	if (NetLibSelect (AppNetRefnum, rfbsock+1, &fds, NULL, NULL,
			SelectNetTimeout, &errno) < 0) {
	  printf ("select returns error\n");
	  ShutdownConnection ();
	}

	if (FD_ISSET(rfbsock, &fds)) {
	  if (!HandleRFBServerMessage()) {
		ShutdownConnection ();
	/* (void)FrmPopupForm (ConsoleForm); */
		PostProgressMessage ("Connection Lost!", 0, 0);
	  }
	  UpdateViewport ();
	}
#ifdef DEBUG_FLOW
	  else if (!FD_ISSET(sysFileDescStdIn, &fds))
	printf ("Select returned nothing, timeout?\n");
#endif

  } while (e.eType != appStopEvent);
}


/******************************************************************
 * PilotMain
 *
 *
 *****************************************************************/
DWord PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  Word err;
  DWord requiredDepth = 8;
  RGBColorType* col;
  int i;

  if (cmd == sysAppLaunchCmdNormalLaunch) {

	err = RomVersionCompatible (MIN_VERSION, launchFlags);
	if (err) return (err);

	/* First, try for 8-bit colour */
	err = ScrDisplayMode(scrDisplayModeSet,
				NULL, NULL, &requiredDepth, NULL);
	if (err)
	{
		/* Okay, try for 4-bit greyscale */
		requiredDepth = 4;
		err = ScrDisplayMode(scrDisplayModeSet,
					NULL, NULL, &requiredDepth, NULL);
		if (err)
		{
			/* Okay, let's try dropping back to 2-bit mode */
			requiredDepth = 2;
			err = ScrDisplayMode(scrDisplayModeSet,
						NULL, NULL, &requiredDepth, NULL);
			if (err)
			{
				FrmAlert (ID_ALERT_VERSION);
				return err;
			}
			else
			{
				screenDepth = 2;
			}
		}
		else
		{
			screenDepth = 4;
		}
	}
	else
	{
		screenDepth = 8;

		col = malloc(sizeof(RGBColorType) * 256);
		/* Set color palette to match BGR233 */
		for (i = 0; i < 256; i++)
		{
			col[i].index = 0;
			col[i].r = (((i >> 0) & 0x7) << 5) | (((i >> 0) & 0x7) << 2) | (((i >> 0) & 0x7) >> 1);
			col[i].g = (((i >> 3) & 0x7) << 5) | (((i >> 3) & 0x7) << 2) | (((i >> 3) & 0x7) >> 1);
			col[i].b = (((i >> 6) & 0x3) << 6) | (((i >> 6) & 0x3) << 4) | (((i >> 6) & 0x3) << 2) | ((i >> 6) & 0x3);
		}
		WinPalette (winPaletteSet, 0, 256, col);
		free(col);
	}

	err = StartApplication();
	if (err) return err;

	sendUpdateRequest = true;
	EventLoop();

	StopApplication();

  } else {
	return sysErrParamErr;
  }

  return 0;
}
