PalmVNC 1.40
============

Installation
------------

It is strongly recommended that you install both the PalmVNC client and the WinVNC-3.3.3r7 with Scaling Extensions. If an alternative VNC server is used, the scaling features of PalmVNC will not be available. See the FAQ for more information.

* Client plus WinVNC-3.3.3r7 with Scaling Extensions

To install PalmVNC and the WinVNC server with scaling extensions, simply run the SETUP.EXE file. This will install both the client and server on your computer.

Note: The WinVNC server with scaling extensions requires more memory and has poorer performance than the standard WinVNC server provided by AT&T.

* Client Only

To install the PalmVNC client, simply double-click on the PalmVNC.prc file included in the distribution. This will cause the program to be installed on your Palm device the next time you hotsync.

To use PalmVNC, you must also have a VNC server installed on your desktop. To obtain a VNC server, see the VNC homepage. You must also have a working TCP/IP network connection between the Palm and the server.




After installation, please read the "manual.htm" file for important installation instructions and FAQs.


7th Jan 2001 Harakan Software.
