/***********************************************************************
 *
 * Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 * All rights reserved.
 *
 * PROJECT:  Pilot Sample Internet Application
 * FILE:     CmdFTP.c
 *
 * DESCRIPTION:
 *	
 * This module provides the "ftp" command to the NetSample application. 
 * This is a minimalistic FTP implementation that supports ftp'ing of a 
 * Pilot database (either resource or record) to and from an FTP server. 
 *
 * WARNING: This module does NOT support transferring ANY OTHER TYPES OF FILES
 *  other than Pilot databases. 
 *
 * ANOTHER WARNING!! This module is not guaranteed to be compatible in the
 *  future if the format of Pilot Databases changes!!! Notice that it includes
 *  <DataPrv.h> which is a NON_PORTABLE header file. Future versions of PalmOS
 *  might change the definitions in this header. 
 *
 * The supported commands are:
 *  get, put, dir, cd, pwd
 *
 **********************************************************************/


//#define FtpDebug 1	




// Socket Equates
#include <sys_socket.h>

// StdIO header
#include "AppStdIO.h"

// Application headers
#include "NetSample.h"

// Pilot headers
#include <DataMgr.h>
#include <SysAll.h>
#include <UIAll.h>


// WARNING!!! This module is NOT GUARANTEED to be compatible with future
//  versions of the PalmOS because it uses definitions in the non-portable
//  header file <DataPrv.h>
#define	NON_PORTABLE
#include <DataPrv.h>

// include for TRGPro
#include "ffslib.h"

// include for CLIe
#include "clie.h"


// include for Sony
/*
#include <VFSMgr.h>
#include <ExpansionMgr.h>
*/

// Constants
//#define	kReplyTimeout			AppNetTimeout
DWord myTimeout=3000; //30s


/***********************************************************************
 * Globals
 *
 ***********************************************************************/
static Boolean	FTPQuit = false;
static int		FTPCtlSock = -1;

// This is a global used for forming FTP commands. We only make this
//  a global so that we can cut down on stack space usage.
static Char		FTPCommand[32];
static Char		FTPResponse[64];

#include "LFtpPrefs.h"

extern LFtpPreferenceType LFtpPrefs;



/* get_memo_title is from
 * Simple http (web) server.
 * Jim Rees University of Michigan April 1998
 */
static void get_memo_title(char *mp, char *title)
{
    char *cp0, *cp1;

    /* copy memo title, first line or up to 40 chars */
    for (cp0 = mp, cp1 = title; *cp0 && *cp0 != '\n' && *cp0 != '\r' && cp0 - mp < 40; )
	*cp1++ = *cp0++;
    *cp1 = '\0';
}




/***********************************************************************
 *
 * FUNCTION:   CmdDivider()
 *
 * DESCRIPTION: This command exists solely to print out a dividing line
 *		when the user does a help all.
 *
 *	CALLED BY:	 
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdDivider(int argc, CharPtr argv[])
{
	// Check for short help
	if (argc > 1 && !StrCompare(argv[1], "?")) 
		printf("\n-- FTP --\n");
}



/***********************************************************************
 *
 * FUNCTION:    PrvDmReadN
 *
 * DESCRIPTION: High level convenience function that reads N bytes from
 *		a socket into a database record
 *	
 *		This code was modified from the readn() routine from Richard Stevens' 
 *		book 'Unix Network  Programming'. 
 *
 * CALLED BY:	 Applications.
 *
 * PARAMETERS:  fd			- socket refnum
 *					 ptr			- buffer pointer
 *					 nbytes		- number of bytes to read
 *
 * RETURNED:    # of bytes read, or <0 if error
 *
 ***********************************************************************/
static SDWord		PrvDmReadN(NetSocketRef sock, BytePtr recP, DWord offset, DWord nbytes)
{
	DWord	nleft;
	SWord nread;
	Word	chunk;

	nleft = nbytes;
	while (nleft > 0) {
		if (nleft > 0x7000) chunk = 0x7000;
		else chunk = nleft;
		
		nread = NetLibDmReceive(AppNetRefnum, sock, recP, offset, chunk, 
						0, 0, 0, AppNetTimeout, &errno);

		if (nread < 0)
			return(nread);		/* error, return < 0 */
		else if (nread == 0)
			break;			/* EOF */

		nleft -= nread;
		offset += nread;
	}
	return(nbytes - nleft);		/* return >= 0 */
}










static Err IsRessource(CharPtr nameP)
{
	LocalID				dbID;
	UInt				attributes;
	Err err;
	

	
	err=1;
	
	//------------------------------------------------------------
	// Locate the Database and see what kind of database it is
	//------------------------------------------------------------
	dbID = DmFindDatabase(0, nameP);
	if (dbID) 
	{
	
		err = DmDatabaseInfo(0, dbID, 0,
				&attributes, NULL, NULL,
				NULL, NULL,
				NULL, NULL,
				NULL, NULL,
				NULL);
		if (!err) 
		{
			// resource database
			if (attributes & dmHdrAttrResDB)
			{
				err=1;
			}
			else
			{
				err=0;
			}
		}
	}
	
Exit:
	return err;
}







/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseRead()
 *
 * DESCRIPTION: This routine reads a .PRC from the FTP server and 
 *		installs into the Pilot as a database.
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseRead(Int cardNo, CharPtr nameP, int sock)
{
	char*					bufferP = 0;

	DmOpenRef			dbP = 0;
	DatabaseHdrType	hdr;
	LocalID				dbID=0;

	Int					i;
	char					typeStr[8];
	char					crStr[8];
	Err					err;
	Boolean				preserveDates = true;

	RsrcEntryType		resEntry, nextResEntry;
	ULong					resSize;
	Handle				newResH;
	
	BytePtr				dstP;

	Handle				newRecH;
	RecordEntryType	recEntry, nextRecEntry;
	ULong					recSize;

	LocalID				appInfoID;
	LocalID				sortInfoID;
	LocalID				recordID;

	UInt					index = 0xFFFF;
	UInt					attr;
	ULong					id;

	BytePtr				bufP;
	const int			bufSize = 0x400;
	SWord					bytes;
	DWord					offset = 0;
	
	ULong					totalBytes = 0;
	ULong					ticks;
	Word					filler;

				

	//------------------------------------------------------------
	// Create temp buffer
	//------------------------------------------------------------
	bufP = MemPtrNew(bufSize);
	if (!bufP) {err = memErrNotEnoughSpace; goto Exit;}
				


	//------------------------------------------------------------
	// Read in the header
	//------------------------------------------------------------
	ticks = TimGetTicks();
	recSize = sizeof(hdr) - sizeof(hdr.recordList.firstEntry);
	if (NetUReadN(sock, (BytePtr)&hdr, recSize)  != recSize)  goto ExitBadDatabase;
	totalBytes += recSize;


	//------------------------------------------------------------
	// Create The database 
	//------------------------------------------------------------
	MemMove(typeStr, &hdr.type, 4);
	typeStr[4] = 0;
	MemMove(crStr, &hdr.creator, 4);
	crStr[4] = 0;
	
	printf("\nCreating Database on card %d\n name: %s\n type %s, creator %s\n",
			cardNo, hdr.name, typeStr, crStr);

	// Delete the old one, if it exists
	dbID = DmFindDatabase(cardNo, (char*)hdr.name);
	if (dbID) 
		DmDeleteDatabase(cardNo, dbID);
	err = DmCreateDatabase(cardNo, (char*)hdr.name, hdr.creator, hdr.type, 
				hdr.attributes & dmHdrAttrResDB);

	if (err) goto Exit;



	//------------------------------------------------------------
	// Set the database info 
	//------------------------------------------------------------
	dbID = DmFindDatabase(cardNo, (char*)hdr.name);
	if (preserveDates) {
		err = DmSetDatabaseInfo(cardNo, dbID, 0,
					&hdr.attributes, &hdr.version, &hdr.creationDate,
					&hdr.modificationDate, &hdr.lastBackupDate,
					&hdr.modificationNumber, 0,
					0, &hdr.type,
					&hdr.creator);
		}
	else {
		err = DmSetDatabaseInfo(cardNo, dbID, 0,
					&hdr.attributes, &hdr.version, 0,
					0, 0,
					&hdr.modificationNumber, 0,
					0, &hdr.type,
					&hdr.creator);
		}
	if (err) goto Exit;



	//------------------------------------------------------------
	// If it's a resource database, Add the Resources
	//------------------------------------------------------------
	if (hdr.attributes & dmHdrAttrResDB) {
		dbP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
		if (!dbP) {err = DmGetLastErr(); goto Exit;}
		
		// Get the "next" resource entry
		if (hdr.recordList.numRecords) {
			if (NetUReadN(sock, (BytePtr)&nextResEntry, sizeof(nextResEntry)) != sizeof(nextResEntry))
				goto ExitBadDatabase;
			totalBytes += sizeof(nextResEntry);
			}
				

		// Loop through each of the entries and add them to the database
		for (i=0; i<hdr.recordList.numRecords; i++) {
			resEntry = nextResEntry;
		
			// Get the resource entry
			if (i < hdr.recordList.numRecords-1) {
				if (NetUReadN(sock, (BytePtr)&nextResEntry, sizeof(nextResEntry)) != sizeof(nextResEntry))
					goto ExitBadDatabase;
				totalBytes += sizeof(nextResEntry);
				}
				
			// Calculate the size of the resource
			if (i < hdr.recordList.numRecords - 1) 
				resSize = (ULong)nextResEntry.localChunkID - (ULong)resEntry.localChunkID;
			else
				resSize = 1;										// This gets fixed up later.
			
			// Allocate space for the new resource
			newResH = (Handle)DmNewResource(dbP, resEntry.type, resEntry.id, resSize);
			if (!newResH) {err = DmGetLastErr(); goto Exit;}
	
			// Done with it for now
			DmReleaseResource(newResH);
			}
			
			
			
		// Read the filler byte which is in .PRC files due to an historical "oversight"
		NetUReadN(sock, (BytePtr)&filler, sizeof(filler));
		totalBytes += sizeof(filler);
			
		// Now, go back and write the data into each resource
		for (i=0; i<hdr.recordList.numRecords; i++) {
			
			// Print progress
			StdPutS(".");
				
			// Get the new resource handle
			newResH = (Handle)DmGetResourceIndex(dbP, i);
			if (!newResH) {err = DmGetLastErr(); goto Exit;}
			
			// Write the data to it
			if (i < hdr.recordList.numRecords - 1) {
				dstP = (BytePtr)MemHandleLock(newResH);
				resSize = MemHandleSize(newResH);
				if (PrvDmReadN(sock, dstP, 0, resSize) != resSize)
					goto ExitBadDatabase;
				totalBytes += resSize;
				MemHandleUnlock(newResH);
				}
				
				
			// The last one is tricky because we don't know the file size, hence the resource
			//   size. We'll read in 1K chunks until there ain't no more.
			else {
				resSize = offset = 0;
				while (1) {
					bytes = NetUReadN(sock, bufP, bufSize);
					if (bytes <= 0) break;
					totalBytes += bytes;

					resSize += bytes;
					newResH = DmResizeResource(newResH, resSize);
					if (!newResH) {err = DmGetLastErr(); break;}
					
					dstP = (BytePtr)MemHandleLock(newResH);
					DmWrite(dstP, offset, bufP, bytes);
					offset += bytes;
					MemHandleUnlock(newResH);
					}
				if (bytes < 0) {err = errno; goto Exit;}
				}
	
			// Done with it for now
			DmReleaseResource(newResH);
			}
		}
		
		
	//------------------------------------------------------------
	// If it's a Record database, Add the Records
	//------------------------------------------------------------
	else {
		dbP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
		if (!dbP) {err = DmGetLastErr(); goto Exit;}
		

		// This is 0 till we read it in.
		nextRecEntry.localChunkID = 0;
		
		
		// If there's an appInfo, add that. NOTE: This logic assumes there is at least
		//  1 record in the database because it calculates the size of the appInfo from
		//  the offset of the first record. 
		if (hdr.appInfoID) {
			if (!hdr.recordList.numRecords) 
				goto ExitBadDatabase;
				
			if (hdr.sortInfoID) 
				recSize = (ULong)hdr.sortInfoID - (ULong)hdr.appInfoID;
			else {
				if (NetUReadN(sock, (BytePtr)&nextRecEntry, sizeof(nextRecEntry)) != 
										sizeof(nextRecEntry))
					goto ExitBadDatabase;
				totalBytes += sizeof(nextRecEntry);
				recSize = (ULong)nextRecEntry.localChunkID - (ULong)hdr.appInfoID;
				}
			
			// Allocate the chunk
			newRecH = (Handle)DmNewHandle(dbP, recSize);
			if (!newRecH) {err = DmGetLastErr(); goto Exit;}
				
			// Store it in the header
			appInfoID = MemHandleToLocalID(newRecH);
			DmSetDatabaseInfo(cardNo, dbID, 0,
				0, 0, 0,
				0, 0,
				0, &appInfoID,
				0, 0, 
				0);
			}
			
			
			
		// If there's a sortInfo, add that. NOTE: This logic assumes there is at least
		//  1 record in the database because it calculates the size of the appInfo from
		//  the offset of the first record. 
		if (hdr.sortInfoID) {
			if (!hdr.recordList.numRecords) 
				goto ExitBadDatabase;
				
			if (NetUReadN(sock, (BytePtr)&nextRecEntry, sizeof(nextRecEntry)) 
							!= sizeof(nextRecEntry))
				goto ExitBadDatabase;
			totalBytes += sizeof(nextRecEntry);
			recSize = (ULong)nextRecEntry.localChunkID - (ULong)hdr.sortInfoID;
			
			// Allocate the chunk
			newRecH = (Handle)DmNewHandle(dbP, recSize);
			if (!newRecH) {err = DmGetLastErr(); goto Exit;}
				
			// Store it in the header
			sortInfoID = MemHandleToLocalID(newRecH);
			DmSetDatabaseInfo(cardNo, dbID, 0,
				0, 0, 0,
				0, 0,
				0, 0,
				&sortInfoID, 0, 
				0);
			}
			
		
		
		// Add Each of the records.
		if (!nextRecEntry.localChunkID && hdr.recordList.numRecords) {
			if (NetUReadN(sock, (BytePtr)&nextRecEntry, sizeof(nextRecEntry)) != sizeof(nextRecEntry))
				goto ExitBadDatabase;
			totalBytes += sizeof(nextRecEntry);
			}

			
		for (i=0; i<hdr.recordList.numRecords; i++) {
			index = i;
			
			// Read in the next entry
			recEntry = nextRecEntry;
			if (i < hdr.recordList.numRecords-1) {
				if (NetUReadN(sock, (BytePtr)&nextRecEntry, sizeof(nextRecEntry)) != sizeof(nextRecEntry))
					goto ExitBadDatabase;
				totalBytes += sizeof(nextRecEntry);
				}
			
			
			// Calculate the size of the record
			if (i < hdr.recordList.numRecords - 1) 
				recSize = (ULong)nextRecEntry.localChunkID - (ULong)recEntry.localChunkID;
			else
				recSize = 1;							// will get fixed later...
			
			// If the record is 0 size, just attach a nil handle
			if (!recSize) {
				DmAttachRecord(dbP, &index, 0, 0);
				}
			
			// Allocate the new record if it has non-zero size
			else {
				newRecH = (Handle)DmNewRecord(dbP, &index, recSize);
				if (!newRecH) {err = DmGetLastErr(); goto Exit;}
				}
					
			// Set the attributes
			attr = recEntry.attributes;
			id = recEntry.uniqueID[0];
			id = (id << 8) | recEntry.uniqueID[1];
			id = (id << 8) | recEntry.uniqueID[2];
			DmSetRecordInfo(dbP, index, &attr, &id);
	
			// Done with it
			DmReleaseRecord(dbP, index, false);		// vmk 10/17/95 preserve dirty flag
			}
			
			
		// Read the filler byte which is in .PRC files due to an historical "oversight"
		NetUReadN(sock, (BytePtr)&filler, sizeof(filler));
		totalBytes += sizeof(filler);
			
		//--------------------------------------------------------------------------------
		// Now, go back and put in the contents of each record
		//--------------------------------------------------------------------------------
		// First the app info
		if (hdr.appInfoID) {
			newRecH = MemLocalIDToGlobal(appInfoID, cardNo);
			dstP = MemHandleLock(newRecH);
			recSize = MemHandleSize(newRecH);
			if (PrvDmReadN(sock, dstP, 0, recSize) != recSize)
			MemHandleUnlock(newRecH);
			totalBytes += recSize;
			}
		
		// Next the sort info
		if (hdr.sortInfoID) {
			newRecH = MemLocalIDToGlobal(sortInfoID, cardNo);
			dstP = MemHandleLock(newRecH);
			recSize = MemHandleSize(newRecH);
			if (PrvDmReadN(sock, dstP, 0, recSize) != recSize)
			MemHandleUnlock(newRecH);
			totalBytes += recSize;
			}
		
		// Next each of the records
		for (i=0; i<hdr.recordList.numRecords; i++) {
			index = i;
			
			// Get the record info
			if ((i & 0x0F) == 0) StdPutS(".");

			
			// If the record is marked as deleted, temporarily un-delete it so
			//  that we can get the handle to it's data, if any
			DmRecordInfo(dbP, index, &attr, 0, &recordID);
			if ((attr & dmRecAttrDelete) && recordID) {
				attr &= ~dmRecAttrDelete;
				DmSetRecordInfo(dbP, index, &attr, 0);
				newRecH = (Handle)DmQueryRecord(dbP, index);
				attr |= dmRecAttrDelete;
				DmSetRecordInfo(dbP, index, &attr, 0);
				}
			else
				newRecH = (Handle)DmQueryRecord(dbP, index);

			if (!newRecH) continue;
			
			
			// Read it in
			if (i < hdr.recordList.numRecords-1) {
				recSize = MemHandleSize(newRecH);
				dstP = MemHandleLock(newRecH);
				if (PrvDmReadN(sock, dstP, 0, recSize) != recSize)
					goto ExitBadDatabase;
				totalBytes += recSize;
				MemHandleUnlock(newRecH);
				}
				
			// The last one is tricky because we don't know the file size, hence the record size.
			else {
				recSize = offset = 0;
				while (1) {
					bytes = NetUReadN(sock, bufP, bufSize);
					if (bytes <= 0) break;
					totalBytes += bytes;

					recSize += bytes;
					newRecH = DmResizeRecord(dbP, index, recSize);
					if (!newRecH) {err = DmGetLastErr(); break;}
					
					dstP = (BytePtr)MemHandleLock(newRecH);
					DmWrite(dstP, offset, bufP, bytes);
					offset += bytes;
					MemHandleUnlock(newRecH);
					}
				if (bytes < 0) {err = errno; goto Exit;}
				}
			
			}
			
		}
		
		
	goto Exit;
	
ExitBadDatabase:
	printf("\nError: invalid format Pilot database\n");

	
Exit:
	ticks = TimGetTicks() - ticks;
	if (dbP) DmCloseDatabase(dbP);

	if (!err && preserveDates) {
		DmSetDatabaseInfo(cardNo, dbID, 0,
					&hdr.attributes, &hdr.version, &hdr.creationDate,
					&hdr.modificationDate, &hdr.lastBackupDate,
					&hdr.modificationNumber, 0,
					0, &hdr.type,
					&hdr.creator);
		}

	if (bufP) MemPtrFree(bufP);
	if (err) {
		printf("Get error: %s", appErrString(err));
		if (dbID) 
			DmDeleteDatabase(cardNo, dbID);
		}
	else printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	return err;
}

/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseReadToCF()
 *
 * DESCRIPTION: This routine reads a file from the FTP server and 
 *		installs into the TRGPro compact flash root directory.
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseReadToCF(Int cardNo, CharPtr nameP, int sock)
{
	Int16	dest_fd;
	Int32 num_read;
	DmOpenRef			dbP = 0;

	Err					err = 0;
	BytePtr				srcP;

	

	ULong					totalBytes = 0;
	ULong					ticks;
	
	UInt16    FfsLibRef;

	err = SysLibFind(FfsLibName, &FfsLibRef);
    if (err == 0)
    {
        printf("Ffs library already loaded\n");
//        return err;
    }
    else
    {
        // The library wasn't pre-loaded -- we need to load it ourselves
        if ((err = SysLibLoad(FfsLibTypeID, FfsLibCreatorID, &FfsLibRef)) != 0)
        {
            printf("Could not load the Ffs library\n");
            return(err);
        }
    }
    
    /* Library loaded -- now open it */
    if ((err = FfsLibOpen(FfsLibRef)) != 0)
    {
        printf("Could not open the Ffs library\n");
        return(err);
    }


	
	 /* allocate a 4K buffer to hold data */
    if ((srcP = (UInt8 *)MemPtrNew(4096)) == NULL)
    {
        printf("Can't allocate buffer\r\n");
        goto CloseLib;
    }


	//------------------------------------------------------------
	// Create dest file
	//------------------------------------------------------------
    if ((dest_fd = FfsOpen(FfsLibRef,nameP,O_CREAT|O_WRONLY,S_IWRITE)) == -1)
    {
        printf("Can't create destination file %s\n", nameP);
        FfsClose(FfsLibRef,dest_fd);
        MemPtrFree(srcP);
        return;
    }



	ticks = TimGetTicks();
	num_read=0;

    /* copy the data */
    while((num_read=NetUReadN(sock, srcP, 4096)) > 0)
    {

		StdPutS(".");

        if (num_read != FfsWrite(FfsLibRef,dest_fd,srcP,num_read))
        {
            printf("Dest write error\n");
            goto CloseFile;
            break;
        }

		totalBytes += num_read;
	}


CloseFile:
    FfsClose(FfsLibRef,dest_fd);
    MemPtrFree(srcP);



	
CloseLib:	
	/* close and unload the Ffs library */
    FfsLibClose(FfsLibRef);
    SysLibRemove(FfsLibRef);    // for now, this needs to be done
	
	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nGet error: %s", appErrString(err));
	else
		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond,
			totalBytes * sysTicksPerSecond / ticks);
	
	return err;

}

/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseWriteTextOnly()
 *
 * DESCRIPTION: This routine takes a database from the Pilot and writes it
 *		out, in .PRC format, to a socket. It is used by the FTPPut command
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseWriteTextOnly(Int cardNo, CharPtr nameP, int sock)
{
	LocalID				dbID;
	UInt					attributes, version;
	ULong					crDate, modDate, bckUpDate;
	ULong					type, creator;
	ULong					modNum;
	LocalID				appInfoID, sortInfoID, recordID;
	DmOpenRef			dbP = 0;

	Err					err = 0;
	UInt					numRecords;
	ULong					size;
	Int					i;
	BytePtr				srcP;

	
	UInt					attr;
	ULong					uniqueID;
	Handle				srcH;
	Handle				appInfoH=0, sortInfoH=0;
	ULong					appInfoSize=0, sortInfoSize=0;

	ULong					totalBytes = 0;
	ULong					ticks;
	Word					filler = 0;

	ticks = TimGetTicks();
	
	//------------------------------------------------------------
	// Locate the Database and see what kind of database it is
	//------------------------------------------------------------
	dbID = DmFindDatabase(cardNo, nameP);
	if (!dbID) {err = DmGetLastErr(); goto Exit;}
	
	err = DmDatabaseInfo(cardNo, dbID, 0,
				&attributes, &version, &crDate,
				&modDate, &bckUpDate,
				&modNum, &appInfoID,
				&sortInfoID, &type,
				&creator);
	if (err) goto Exit;
	
	dbP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
	if (!dbP) {err = DmGetLastErr(); goto Exit;}
	



	 {
		numRecords = DmNumRecords(dbP);
		// Write out each record
		//skip the first record
		for (i=1; i<numRecords; i++) {
			
			if ((i & 0x0F) == 0) StdPutS(".");
			err = DmRecordInfo(dbP, i, &attr, &uniqueID, &recordID);
			if (err) {
				printf("Error getting record");
				err = -1;
				goto Exit;
				}
				
			// If the record is marked as deleted, temporarily un-delete it so
			//  that we can get the handle to it's data, if any
			if ((attr & dmRecAttrDelete) && recordID) {
				attr &= ~dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				srcH = (Handle)DmQueryRecord(dbP, i);
				attr |= dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				}
			else
				srcH = (Handle)DmQueryRecord(dbP, i);

				
			if (srcH) {
				size = MemHandleSize(srcH);
				srcP = MemHandleLock(srcH);
				NetUWriteN(sock, srcP, size);
				totalBytes += size;
				MemPtrUnlock(srcP);
				}
			}
	
			
		}
		
	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nPut error: %s", appErrString(err));
	else 		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	
	if (dbP)
		DmCloseDatabase(dbP);
		
	return err;
}

/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseWriteMemo()
 *
 * DESCRIPTION: This routine takes a memo writes it
 *		out,  to a socket. It is used by the FTPPubM command
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of memo to send
 *		sock		- socket refNum of socket to send to
 *
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseWriteMemo(Int cardNo, CharPtr nameP, int sock)
{

	Err					err = 0;
	ULong					size;
	ULong					titlesize;
	

	ULong					totalBytes = 0;
	ULong					ticks;

    DmOpenRef MemoDB;
    char title[42];
    BytePtr memo;
    Handle record;
    UInt16 ncat, incat;

	ticks = TimGetTicks();
	
	//------------------------------------------------------------
	// Locate the memo
	//------------------------------------------------------------
	
	

    MemoDB = DmOpenDatabaseByTypeCreator('DATA', 'memo', dmModeReadOnly);
    if (!MemoDB) {
		printf("\nErr ");
		return;
		}

	incat=0;
    for (ncat = 0; ncat < 16; ) 
    {
		record = DmQueryNextInCategory(MemoDB, &incat, ncat);
		if (record) 
		{
			memo =  MemHandleLock(record);

		    get_memo_title((char *)memo, (char *)title);
		    if (!StrCompare(title, nameP))
		    {
		    	printf("found \"%s\"\n",title);
		    	size=StrLen((CharPtr)memo);
		    	titlesize=StrLen((CharPtr)title);
		    	if (size>titlesize)
		    	{
		    		size-=titlesize;
					NetUWriteN(sock, memo+titlesize+1, size);
				}
				else
		    	{
					NetUWriteN(sock, memo, size);
				}
				totalBytes += size;
				MemHandleUnlock(record);
				break;
				
			}
		    	
		    	
			MemHandleUnlock(record);
			incat++;
	    }
	    else
	    {
	    	incat=0;
	    	ncat++;
	    }
	}

    DmCloseDatabase(MemoDB);


Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nPut error: %s", appErrString(err));
	else 		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	
		
	return err;
}







/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseWrite()
 *
 * DESCRIPTION: This routine takes a database from the Pilot and writes it
 *		out, in .PRC format, to a socket. It is used by the FTPPut command
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseWrite(Int cardNo, CharPtr nameP, int sock)
{
	LocalID				dbID;
	UInt					attributes, version;
	ULong					crDate, modDate, bckUpDate;
	ULong					type, creator;
	ULong					modNum;
	LocalID				appInfoID, sortInfoID, recordID;
	DmOpenRef			dbP = 0;

	Err					err = 0;
	UInt					numRecords;
	ULong					size;
	ULong					offset;
	Int					i;
	DatabaseHdrType	hdr;
	BytePtr				srcP;

	Handle				resH;
	LocalID				resChunkID;
	ULong					resType;
	Int					resID;
	RsrcEntryType 		resEntry;
	
	RecordEntryType	recEntry;
	UInt					attr;
	ULong					uniqueID;
	Handle				srcH;
	Handle				appInfoH=0, sortInfoH=0;
	ULong					appInfoSize=0, sortInfoSize=0;

	ULong					totalBytes = 0;
	ULong					ticks;
	Word					filler = 0;
	
	//------------------------------------------------------------
	// Locate the Database and see what kind of database it is
	//------------------------------------------------------------
	dbID = DmFindDatabase(cardNo, nameP);
	if (!dbID) {err = DmGetLastErr(); goto Exit;}
	
	err = DmDatabaseInfo(cardNo, dbID, 0,
				&attributes, &version, &crDate,
				&modDate, &bckUpDate,
				&modNum, &appInfoID,
				&sortInfoID, &type,
				&creator);
	if (err) goto Exit;
	
	dbP = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
	if (!dbP) {err = DmGetLastErr(); goto Exit;}
	
	ticks = TimGetTicks();


	//------------------------------------------------------------
	// Write out a resource database
	//------------------------------------------------------------
	if (attributes & dmHdrAttrResDB) {
		// Figure out size of header
		numRecords = DmNumRecords(dbP);
		size = sizeof(DatabaseHdrType) + numRecords * sizeof(RsrcEntryType);
		
		// Fill in header
		strcpy((char*)hdr.name, nameP);
		hdr.attributes = attributes;
		hdr.version = version;
		hdr.creationDate = crDate;
		hdr.modificationDate = modDate;
		hdr.lastBackupDate = bckUpDate;
		hdr.modificationNumber = modNum;
		hdr.appInfoID = 0;
		hdr.sortInfoID = 0;
		hdr.type = type;
		hdr.creator = creator;
		hdr.recordList.nextRecordListID = 0;
		hdr.recordList.numRecords = numRecords;
	
	
		// Write out the header
		ticks = TimGetTicks();
		NetUWriteN(sock, (BytePtr)&hdr, sizeof(hdr) - sizeof(hdr.recordList.firstEntry));
		totalBytes += sizeof(hdr) - sizeof(hdr.recordList.firstEntry);
		
	
		// Fill in the info on each resource into the header
		offset = size;
		for (i=0; i<numRecords; i++)  {
			DmResourceInfo(dbP, i, &resType, &resID, 0);
			resH = (Handle)DmGetResourceIndex(dbP, i);
			if (resH)  {
				size = MemHandleSize(resH);
				DmReleaseResource(resH);
				}
			else
				size = 0;
				
			resEntry.type = resType;
			resEntry.id = resID;
			resEntry.localChunkID = offset;
			
			// Write out the entry
			NetUWriteN(sock, (BytePtr)&resEntry, sizeof(resEntry));
			totalBytes += sizeof(resEntry);
			
			offset += size;
			}
	
	
		// Write out the extra WORD that is currently in all .PRC files due to
		//  an historical "oversight".
		NetUWriteN(sock, (BytePtr)&filler, sizeof(filler));
		totalBytes += sizeof(filler);
		
	
	
		// Write out each resource
		for (i=0; i<numRecords; i++) {
			
			StdPutS(".");

			DmResourceInfo(dbP, i, &resType, &resID, &resChunkID);
			if (resChunkID) {
				resH = (Handle)DmGetResourceIndex(dbP, i);
				if (!resH) {
					printf("Error getting resource");
					err = -1;
					goto Exit;
					}
				size = MemHandleSize(resH);
					
				srcP = MemHandleLock(resH);
				NetUWriteN(sock, srcP, size);
				totalBytes += size;
				MemPtrUnlock(srcP);
				DmReleaseResource(resH);
				}
			}
	
			
		} // Resource database
		
		




	//------------------------------------------------------------
	// Write out a records database
	//------------------------------------------------------------
	else {
		numRecords = DmNumRecords(dbP);
		size = sizeof(DatabaseHdrType) + numRecords * sizeof(RecordEntryType);
		
		// Fill in header
		strcpy((char*)hdr.name, nameP);
		hdr.attributes = attributes;
		hdr.version = version;
		hdr.creationDate = crDate;
		hdr.modificationDate = modDate;
		hdr.lastBackupDate = bckUpDate;
		hdr.modificationNumber = modNum;
		hdr.appInfoID = 0;
		hdr.sortInfoID = 0;
		hdr.type = type;
		hdr.creator = creator;
	
		hdr.recordList.nextRecordListID = 0;
		hdr.recordList.numRecords = numRecords;
			

		// Get the size of the appInfo and sort Info if they exist
		offset = size;
		if (appInfoID) {
			hdr.appInfoID = offset;
			appInfoH = (Handle)MemLocalIDToGlobal(appInfoID, cardNo);
			if (!appInfoH) {
				printf("Error getting appInfo");
				err = -1;
				goto Exit;
				}
			appInfoSize = MemHandleSize(appInfoH);
			offset += appInfoSize;
			}
			
		if (sortInfoID) {
			hdr.sortInfoID = offset;
			sortInfoH = (Handle)MemLocalIDToGlobal(sortInfoID, cardNo);
			if (!sortInfoH) {
				printf("Error getting sortInfo");
				err = -1;
				goto Exit;
				}
			sortInfoSize = MemHandleSize(sortInfoH);
			offset += sortInfoSize;
			}			
	
	
		// Write out the header
		ticks = TimGetTicks();
		NetUWriteN(sock, (BytePtr)&hdr, sizeof(hdr) - sizeof(hdr.recordList.firstEntry));
		totalBytes += sizeof(hdr) - sizeof(hdr.recordList.firstEntry);
		
	
		// Fill in the info on each record into the header
		for (i=0; i<numRecords; i++)  {
			
			err = DmRecordInfo(dbP, i, &attr, &uniqueID, &recordID);
			if (err) {
				printf("\n## Error getting record info for record #%d", i);
				err = -1;
				goto Exit;
				}
			
			// If the record is marked as deleted, temporarily un-delete it so
			//  that we can get the handle to it's data, if any
			if ((attr & dmRecAttrDelete) && recordID) {
				attr &= ~dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				srcH = (Handle)DmQueryRecord(dbP, i);
				attr |= dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				}
			else
				srcH = (Handle)DmQueryRecord(dbP, i);

			// Collect the record entry info
			recEntry.localChunkID = offset;
			recEntry.attributes = attr;
			recEntry.uniqueID[0] = (uniqueID >> 16) & 0x00FF;	// vmk 10/16/95 fixed: && 0x00FF --> & 0x00FF
			recEntry.uniqueID[1] = (uniqueID >> 8) & 0x00FF;
			recEntry.uniqueID[2] = uniqueID  & 0x00FF;
			
			// Write it out
			NetUWriteN(sock, (BytePtr)&recEntry, sizeof(recEntry));
			totalBytes += sizeof(recEntry);

			if (srcH)
				offset += MemHandleSize(srcH);
			}
	
	
	
		// Write out the extra WORD that is currently in all .PRC files due to
		//  an historical "oversight".
		NetUWriteN(sock, (BytePtr)&filler, sizeof(filler));
		totalBytes += sizeof(filler);
		

		// Write out the appInfo followed by sortInfo, if they exist
		if (appInfoID && appInfoSize) {
			srcP = MemHandleLock(appInfoH);
			NetUWriteN(sock, srcP, appInfoSize);
			totalBytes += appInfoSize;
			MemPtrUnlock(srcP);
			}
			
		if (sortInfoID && sortInfoSize) {
			srcP = MemHandleLock(sortInfoH);
			NetUWriteN(sock, srcP, sortInfoSize);
			totalBytes += sortInfoSize;
			MemPtrUnlock(srcP);
			}
	
	
	
		// Write out each record
		for (i=0; i<numRecords; i++) {
			
			if ((i & 0x0F) == 0) StdPutS(".");
			err = DmRecordInfo(dbP, i, &attr, &uniqueID, &recordID);
			if (err) {
				printf("Error getting record");
				err = -1;
				goto Exit;
				}
				
			// If the record is marked as deleted, temporarily un-delete it so
			//  that we can get the handle to it's data, if any
			if ((attr & dmRecAttrDelete) && recordID) {
				attr &= ~dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				srcH = (Handle)DmQueryRecord(dbP, i);
				attr |= dmRecAttrDelete;
				DmSetRecordInfo(dbP, i, &attr, 0);
				}
			else
				srcH = (Handle)DmQueryRecord(dbP, i);

				
			if (srcH) {
				size = MemHandleSize(srcH);
				srcP = MemHandleLock(srcH);
				NetUWriteN(sock, srcP, size);
				totalBytes += size;
				MemPtrUnlock(srcP);
				}
			}
	
			
		}
		
	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nPut error: %s", appErrString(err));
	else 		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	
	if (dbP)
		DmCloseDatabase(dbP);
		
	return err;
}



/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseWriteFromCF()
 *
 * DESCRIPTION: This routine takes a database from the Pilot and writes it
 *		out, in .PRC format, to a socket. It is used by the FTPPut command
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
static Err FTPDatabaseWriteFromCF(Int cardNo, CharPtr nameP, int sock)
{

	Int16	src_fd;
	UInt16 num_read;
	DmOpenRef			dbP = 0;

	Err					err = 0;
	BytePtr				srcP;

	
	Handle				appInfoH=0, sortInfoH=0;
	ULong					appInfoSize=0, sortInfoSize=0;

	ULong					totalBytes = 0;
	ULong					ticks;
	Word					filler = 0;
	
	UInt16    FfsLibRef;
		
	err = SysLibFind(FfsLibName, &FfsLibRef);
    if (err == 0)
    {
        printf("Ffs library already loaded\n");
//        return err;
    }
    else
    {
        // The library wasn't pre-loaded -- we need to load it ourselves
        if ((err = SysLibLoad(FfsLibTypeID, FfsLibCreatorID, &FfsLibRef)) != 0)
        {
            printf("Could not load the Ffs library\n");
            return(err);
        }
    }
    
    /* Library loaded -- now open it */
    if ((err = FfsLibOpen(FfsLibRef)) != 0)
    {
        printf("Could not open the Ffs library\n");
        return(err);
    }


	
	
	
	
	
	 /* allocate a 4K buffer to hold data */
    if ((srcP = (UInt8 *)MemPtrNew(4096)) == NULL)
    {
        printf("Can't allocate buffer\r\n");
        goto CloseLib;
    }

    if ((src_fd = FfsOpen(FfsLibRef,nameP,O_RDONLY,0)) == -1)
    {
        printf("Can't open file %s\n",nameP);
        MemPtrFree(srcP);
        goto CloseLib;
    }

	ticks = TimGetTicks();

    /* copy the data */
    while(!FfsEof(FfsLibRef, src_fd))
    {
        if ((num_read = FfsRead(FfsLibRef,src_fd,srcP,(Int16)4096)) == 0xFFFF)
        {
            printf("Source file read error\r\n");
            goto CloseFile;
        }


		StdPutS(".");

		NetUWriteN(sock, srcP, num_read);
		totalBytes += num_read;




    }

CloseFile:

    FfsClose(FfsLibRef,src_fd);
    MemPtrFree(srcP);



	
CloseLib:	
	/* close and unload the Ffs library */
    FfsLibClose(FfsLibRef);
    SysLibRemove(FfsLibRef);    // for now, this needs to be done
	
	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nPut error: %s", appErrString(err));
	else 		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	
	return err;
}


/***********************************************************************
 *
 * FUNCTION:   FTPDatabaseWriteFromMS()
 *
 * DESCRIPTION: This routine takes a database from the Pilot and writes it
 *		out, in .PRC format, to a socket. It is used by the FTPPut command
 *
 * PARAMETERS:
 *		cardNo   - card number of database
 *		nameP		- name of database to send
 *		sock		- socket refNum of socket to send to
 *
 *	CALLED BY: FTPPut 
 *
 * RETURNED:  0 if no err
 *
 ***********************************************************************/
 /*
static Err FTPDatabaseWriteFromMS(Int cardNo, CharPtr nameP, int sock)
{

	DmOpenRef			dbP = 0;

	Err					err = 0;
	BytePtr				srcP;

	
	ULong					totalBytes = 0;
	ULong					ticks;
	
		
	UInt32 offset;

	FileRef fileRef;
	UInt16 volRefNum;
	UInt32 numBytesRead;
	UInt32 volIterator = 0L ;

	numBytesRead=0;
	offset=0;
		
	while(volIterator != 0xffffffffL )
	{
		err = VFSVolumeEnumerate(&volRefNum, &volIterator);
		if(err == 0x0000 )
		{
			//volRefNum
		}
		else
		{
            printf("Unable to locate the Memory Stick\n");
            return(err);
		}
		
	}
	
	 // allocate a 4K buffer to hold data 
    if ((srcP = (UInt8 *)MemPtrNew(4096)) == NULL)
    {
        printf("Can't allocate buffer\r\n");
        goto Exit;
    }


	
	err = VFSFileOpen(volRefNum, nameP, (0x0002UL) , &fileRef);
	if(err == 0x0000 )
	{
		//fileRef
	}
	else
	{
        printf("Can't open file %s\n",nameP);
        MemPtrFree(srcP);
        goto Exit;
	}

	ticks = TimGetTicks();



    // copy the data


	do
	{
		err = VFSFileReadData(fileRef, (UInt32)4096, srcP, offset, &numBytesRead);
		StdPutS(".");
		NetUWriteN(sock, srcP, numBytesRead);
		totalBytes += numBytesRead;
	} while ( err != (0x2A00 | 7) );


CloseFile:

    err = VFSFileClose(fileRef);
    MemPtrFree(srcP);


	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nPut error: %s", appErrString(err));
	else 		printf("\n%ld bytes in %ld sec.s (%ld bytes/sec)", 
			totalBytes, ticks/sysTicksPerSecond, totalBytes * sysTicksPerSecond / ticks);
	
	return err;
}

*/

/***********************************************************************
 *
 * FUNCTION:   FTPGetReply 
 *
 * DESCRIPTION:Waits for a reply message from the FTP control socket. 
 *		Parses the reply for the result number and prints text portion
 *		of reply to stdout.
 *
 *		Returns result number in *resultP
 *
 *	CALLED BY:	Various FTP command process routines
 *
 * PARAMETERS:
 *			sock		- socket refNum of socket connected to Telnet server
 *			resultP 	- pointer to storage for result.
 *
 * RETURNED:   void
 *
 ***********************************************************************/
static int FTPGetReply(NetSocketRef sock,  UIntPtr resultP)
{
	ULong				endTime;
	
	const 	int 	bufSize = 0x00FF;
	BytePtr			inBufP = 0, outBufP = 0;
	
	BytePtr			bP;
	Byte				c;
	Int				cc = 0;
	UInt				outChars;
	Boolean			gotCR;
	
	Err				err;

	
	
	// Allocate temp buffers so we don't eat up stack space
	err = memErrNotEnoughSpace;
	inBufP = MemPtrNew(bufSize+1);

	
	if (!inBufP) goto Exit;
	outBufP = MemPtrNew(bufSize+1);

	
	if (!outBufP) goto Exit;
	

	// Calculate timeout ticks
	AppNetTimeout=myTimeout;
//	endTime = TimGetTicks() + kReplyTimeout;
	endTime = TimGetTicks() + myTimeout;
	
	
	// Print <> around response from server
	printf("\n#");

	
	//--------------------------------------------------------------------------------------
	// Loop til last line of reply is received.
	//--------------------------------------------------------------------------------------
	while (1) {
	
	
		// Calculate timeout ticks for each line of the reply
//		endTime = TimGetTicks() + kReplyTimeout;
		endTime = TimGetTicks() + myTimeout;

		//--------------------------------------------------------------------------------------
		// Wait for a reply line. If a multiline reply is sent, the first line contains
		// a hyphen instead of a space after the 3 digit reply code.
		//--------------------------------------------------------------------------------------
		gotCR = false;
		outChars = 0;
		while(TimGetTicks() < endTime) {
		
			// Read as much as possible from the socket into our input buffer.
			if (!cc) {

//				cc = read (sock, inBufP, bufSize);
//#define	read(socket,buffer,buflen)								\
				NetLibReceive(AppNetRefnum, socket,buffer,buflen,0,0,0,AppNetTimeout,&errno)	
				
				cc=NetLibReceive(AppNetRefnum, sock,inBufP,bufSize,0,0,0,myTimeout,&errno);
//				cc = read(sock, inBufP, bufSize);
			
				
				if (cc == 0) {
					printf("\nConnection closed.");
					err = -1;
					goto Exit;
					}
				if (cc < 0) {
					printf("\nSocket read error: %s", appErrString(errno));
					err = -1;
					goto Exit;
					}
				bP = inBufP;
				}
			
			// Copy input chars into output buf, looking for end of line and skipping <cr>'s
			while(cc) {
			
			
			
			
				c = *bP++;
				if (c == '\r') gotCR = true;
				else {
					if (outChars < bufSize) outBufP[outChars++] = c;
					if (c == '\n' && gotCR) {cc--; break; }
					}
				cc--;
				}
			if (c == '\n' && gotCR) break;
			}
			
			
		//--------------------------------------------------------------------------------------
		// Terminate and print the output buffer
		//--------------------------------------------------------------------------------------
		outBufP[outChars] = 0;
		StdPutS((CharPtr)outBufP);
		
//lth copy response for parsing of pasv response		
		StrNCopy(FTPResponse, (CharPtr)outBufP,63);
		FTPResponse[63]=0;
	
	
		//--------------------------------------------------------------------------------------
		// See if this line has the final result in it
		//--------------------------------------------------------------------------------------
		if (outChars >= 4) {
			*resultP = atoi((CharPtr)outBufP);
			if (*resultP && outBufP[3] == ' ') {
				err = 0;
				goto Exit;
				}
			}
			
		}
		
		
	// Timed out
	printf(">\nGetReply timeout.");
	err = -1;
	
Exit:
	if (inBufP) MemPtrFree(inBufP);
	if (outBufP) MemPtrFree(outBufP);
	return err;
}



/******************************************************************************
 * FUNCTION:   FTPHelp
 *
 * DESCRIPTION: Handles the 'help' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPHelp(UInt argc, CharPtr argv[])
{
	printf("\ndir        # directory listing");
	printf("\nldir <cmd> # local directory listing (Palm names)");
	printf("\nldirm  # list MemoPad names");
	printf("\nget <file> # get file from server");
	printf("\nput <file> # send file to server");
	printf("\nputcf [<path>\]<file> # send file from TRGPro compact flash to server");
	printf("\ngetcf [<path>\]<file> # get file from server to TRGPro compact flash root");
//	printf("\nputms [<path>\]<file> # send file from Sony memory stick to server");
//	printf("\ngetms [<path>\]<file> # get file from server to Sony memory stick ");
	printf("\npub <file> # send a uncompressed doc file to server as a text file");

	printf("\ndel <file> # delete file from server");
	printf("\ncd  <path> # change current directory");
	printf("\nmkd <path> # make remote directory");
	printf("\nrmd <path> # remove remote directory");
	printf("\npwd <path> # print current directory.");
//	printf("\ncdcf # change and print current directory on TRGPro compact flash.");
	printf("\nquit       # end ftp.");
	printf("\n");
}


/******************************************************************************
 * FUNCTION:   FTPDataAcceptSocket
 *
 * DESCRIPTION: Opens up a data socket for FTP and sends the PORT command
 *		to the server to tell it the socket address and port number
 *
 *	CALLED BY:	Various FTP commands
 *
 * PARAMETERS: sock - socket refNum of FTP control socket. 
 *
 * RETURNED:  socket refNum of data socket, or -1 if error.
 *
 *****************************************************************************/
static int FTPDataAcceptSocketPasv()
{
	int				acceptSock;
	UInt				result;

    char *s;
    int i, port;
    DWord Host;
    NetSocketAddrINType remote;



	
	// Send the PASV command
		
		
	StrPrintF(FTPCommand,"PASV\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));

	// Get response
	if (FTPGetReply(FTPCtlSock, &result)) goto ExitErr;
	if (result != 227)  goto ExitErr;
	
//	printf(FTPResponse);

	/* skip to host adress */
	s = FTPResponse;
	while(*s != '(') s++;
    s++;
	

	/* extract host adress */
	Host = StrAToI(s);
	while(*s != ',') s++;
	s++;
	Host = 256*Host + StrAToI(s);
	while(*s != ',') s++;
	s++;
	Host = 256*Host + StrAToI(s);
	while(*s != ',') s++;
	s++;
	Host = 256*Host + StrAToI(s);


//	printf("Host: %ld\n", Host);


	/* skip to port number */
	s = FTPResponse;
	while(*s != '(') s++;
		for(i=0;i<4;i++) {
 	   while(*s != ',') s++;
    s++;
	}

	/* extract port number */
	port = StrAToI(s);
	while(*s != ',') s++;
	port = 256*port + StrAToI(s+1);

//	printf("passive port: %u\n", port);


	
	// Open a socket
	acceptSock = socket(AF_INET, SOCK_STREAM, 0);
	if (acceptSock < 0) goto ExitErr;

//	printf("acceptSock: %u\n", acceptSock);

//	goto ExitErr;
	
	remote.addr = Host;
 	remote.family = netSocketAddrINET;
 	remote.port = port;

	
	result=connect(acceptSock,&remote ,sizeof(remote));
//	printf("result: %u\n", result);

	
	if (result ==0) return acceptSock;
	

ExitErr:
	if (acceptSock  >= 0) close(acceptSock);
	printf("\nError creating data connection: %s", appErrString(errno));
	return -1;
}



/******************************************************************************
 * FUNCTION:   FTPDataAcceptSocket
 *
 * DESCRIPTION: Opens up a data socket for FTP and sends the PORT command
 *		to the server to tell it the socket address and port number
 *
 *	CALLED BY:	Various FTP commands
 *
 * PARAMETERS: sock - socket refNum of FTP control socket. 
 *
 * RETURNED:  socket refNum of data socket, or -1 if error.
 *
 *****************************************************************************/
static int FTPDataAcceptSocket()
{
	int				acceptSock;
	struct			sockaddr_in address;
	struct			sockaddr_in ctlAddress;
	int				namelen;
	UInt				result;
	
//return FTPDataAcceptSocketPasv();	
	
	// Open a socket
	acceptSock = socket(AF_INET, SOCK_STREAM, 0);
	if (acceptSock < 0) goto ExitErr;
	
	// Bind it to a local address
	bzero((char*)&address, sizeof(address));
	address.sin_family = AF_INET;
	if ( bind (acceptSock, (struct sockaddr *)&address, sizeof(address)) < 0) goto ExitErr;
	
	// Set the listen queue size
	if ( listen (acceptSock, 1) < 0) goto ExitErr;
	
	
	// Get our local address of the data socket and use the port number from that
	namelen = sizeof(address);
	if ( getsockname(acceptSock, (struct sockaddr*)&address, &namelen) < 0) goto ExitErr;
	
	// Get our local address for the control socket. We have to use the IP address from
	//  this socket since the data socket isn't connected yet.
	namelen = sizeof(ctlAddress);
	if ( getsockname(FTPCtlSock, (struct sockaddr*)&ctlAddress, &namelen) < 0) goto ExitErr;
	
	
	// Send the port command
	StrPrintF(FTPCommand, "PORT %d,%d,%d,%d,%d,%d\r\n", 
		ctlAddress.sin_addr.S_un.S_un_b.s_b1,
		ctlAddress.sin_addr.S_un.S_un_b.s_b2,
		ctlAddress.sin_addr.S_un.S_un_b.s_b3,
		ctlAddress.sin_addr.S_un.S_un_b.s_b4,
		address.sin_port >> 8,
		address.sin_port & 0x00FF);
		
		
//	StrPrintF(FTPCommand,"PASV\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	
	
	// Get response
	if (FTPGetReply(FTPCtlSock, &result)) goto ExitErr;
	if (result >= 200 && result <= 299) return acceptSock;
	

ExitErr:
	if (acceptSock  >= 0) close(acceptSock);
	printf("\nError creating data connection: %s", appErrString(errno));
	return -1;
}



/******************************************************************************
 * FUNCTION:   FTPDir
 *
 * DESCRIPTION: Handles the 'dir' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPDir(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	
	UInt				reply;
	const int		bufSize = 0x0100;
	BytePtr			bufP = 0;
	int				cc;
	UInt				i, j;
	
	// Create a data port to get the results
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	// Allocate our buffer
	bufP = MemPtrNew(bufSize);
	if (!bufP) {errno = memErrNotEnoughSpace; goto Exit;}
	
	// Send the dir command
	if (argc > 1)
		StrPrintF(FTPCommand, "LIST \"%s\"\r\n", argv[1]);
	else
		StrPrintF(FTPCommand, "LIST\r\n");
		
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	
		
	// Get Reply from the LIST command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;

	
	// Read the directory listing, throwing out carriage returns.
	while (1) {
		cc = NetUReadN(acceptSock, bufP, bufSize-1);
		if (cc <= 0) break;
		
		bufP[cc] = 0;
		
		// Get rid of carriage returns in the output
		for (i=0,j=0; i<=cc; i++) {
			if (bufP[i] == '\r') continue;
			bufP[j++] = bufP[i];
			}
			
		printf("%s", bufP);
		}
	if (cc<0) printf("\nError: %s", appErrString(errno));
	
	// Get Transer complete message
	

	// Send the NOOP command
	StrPrintF(FTPCommand, "NOOP\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));

//lth 8/12/2000 hangs with some server 	
//	FTPGetReply(acceptSock, &reply);
	FTPGetReply(FTPCtlSock, &reply);

	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
}



/******************************************************************************
 * FUNCTION:   FTPGet
 *
 * DESCRIPTION: Handles the 'get' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPGet(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
//	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the RETR command
	StrPrintF(FTPCommand, "RETR %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply from the RETR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
		
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
//	dataSock=acceptSock;
	
	
	// Read the file 
//	errno = FTPDatabaseRead(0, argv[1], dataSock);
	errno = FTPDatabaseRead(0, argv[1], acceptSock);
		

	// Get Transer complete message
//lth 8/12/2000 hangs with some server 	
	
	// Send the NOOP command
	StrPrintF(FTPCommand, "NOOP\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));


	FTPGetReply(FTPCtlSock, &reply);
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
//	if (dataSock >= 0) close(dataSock);	
}

/******************************************************************************
 * FUNCTION:   FTPGetcf
 *
 * DESCRIPTION: Handles the 'getcf' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPGetcf(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	
	UInt				reply;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the RETR command
	StrPrintF(FTPCommand, "RETR %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the RETR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
		
	
	// Read the file 
	errno = FTPDatabaseReadToCF(0, argv[1], acceptSock);
		


	// Send the NOOP command
	StrPrintF(FTPCommand, "NOOP\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));


	// Get Transer complete message
//lth 8/12/2000 hangs with some server 	
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
}



/******************************************************************************
 * FUNCTION:   FTPGetms
 *
 * DESCRIPTION: Handles the 'getms' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
/*
static void FTPGetms(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	
	UInt				reply;
	// VFS manager 
	UInt32 gVFSMgrVersion;
	UInt16 err;


	// Is the VFS manager present?

	//err = FtrGet( sysFileCVFSMgr, vfsFtrIDVersion, &gVFSMgrVersion );
	err = FtrGet( 'vfsm' , 0 , &gVFSMgrVersion );
	if( err )
	{
		 // no VFS Manager present
		printf("\nNo Sony memory stick !");
		return;
	} 
	else 
	{
		// you could check for the correct version of VFS Manager here
		printf("\nSony memory stick manager %ld",gVFSMgrVersion);
		printf("\nbut not yet implemented !");
		return;
	}
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the RETR command
	StrPrintF(FTPCommand, "RETR %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the RETR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	
	// Read the file 
	errno = FTPDatabaseReadToCF(0, argv[1], acceptSock);
		

	// Send the NOOP command
	StrPrintF(FTPCommand, "NOOP\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));


	// Get Transer complete message
		FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
}

*/

/******************************************************************************
 * FUNCTION:   FTPDel
 *
 * DESCRIPTION: Handles the 'del' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPDel(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	

	
	// Send the DELE command
	StrPrintF(FTPCommand, "DELE %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (FTPGetReply(FTPCtlSock, &reply)) goto ExitErr;
	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
	
	
}



/******************************************************************************
 * FUNCTION:   FTPLDir
 *
 * DESCRIPTION: Handles the 'ldir' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
//static 
void FTPLDir(UInt argc, CharPtr argv[])
{

	struct DB_INFO_STR
	{
   		char    name[dmDBNameLength]; //includes null, according to DataMgr.h
	};

	struct DB_INFO_STR    *_dbInfoArray = NULL;
	int                    _dbCount = 0;
	UShort*                _map = NULL;

	int i,j;
	UShort tmp;
	char str[32];

	Err err;
	short numcards;
	short card;
	// Syntax check
	if (argc < 1) {
		printf("\nSyntax: %s <cmd>", argv[0]);
		return;
		}
	


	numcards = MemNumCards();
	printf("\nsorting Palm names...\n");

	// First, we count. Then, we allocate. 


	for (card=0; card<numcards; card++) 
	{
    	err = MemCardInfo(card, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    	if (!err) 
    	{
			unsigned short ix, num, attr;
			num = DmNumDatabases(card);
			for (ix=0; ix<num; ix++) 
			{
				LocalID lid;
				lid = DmGetDatabase(card, ix);
				err = DmDatabaseInfo(card, lid, NULL, &attr,
					NULL, NULL, NULL, NULL,
					NULL, NULL, NULL,
					NULL, NULL);
				
				if ((attr & dmHdrAttrReadOnly) == 0)
				{	
					_dbCount++;
				}
			}

		}
	}

    // Allocate arrays to hold info on dbs
    _dbInfoArray = MemHandleLock(MemHandleNew(_dbCount * sizeof(*_dbInfoArray)));
    _map = MemHandleLock(MemHandleNew(_dbCount * sizeof(*_map)));
    _dbCount = 0;


	for (card=0; card<numcards; card++) 
	{
    	err = MemCardInfo(card, NULL, NULL, NULL, NULL, NULL, NULL, NULL);
    	if (!err) 
    	{
			unsigned short ix, num, attr;
			num = DmNumDatabases(card);
			for (ix=0; ix<num; ix++) 
			{
				char name[32];
				LocalID lid;
				lid = DmGetDatabase(card, ix);
				err = DmDatabaseInfo(card, lid, name, &attr,
					NULL, NULL, NULL, NULL,
					NULL, NULL, NULL,
					NULL, NULL);
				
				if ((attr & dmHdrAttrReadOnly) == 0)
				{	
				
					MemMove(_dbInfoArray[_dbCount].name, name, dmDBNameLength);
			        _dbCount++;

				}
			}

		}
	}
	
	//sorting

	for (i = 0; i < _dbCount; i++) _map[i]=i;
	for (i = 0; i < _dbCount-1; i++)
   	{
       	for(j = i+1; j < _dbCount; j++)
       	{
           	if (0 < StrCaselessCompare(_dbInfoArray[_map[i]].name, _dbInfoArray[_map[j]].name))
           	{
               	tmp = _map[i];
               	_map[i] = _map[j];
               	_map[j] = tmp;
           	}
       	}
   	}
	

	//printing
	for (i = 0; i < _dbCount; i++)
	{
//		printf("%s\n",_dbInfoArray[_map[i]].name);
		str[0]=0;
//		if (StrLen(argv[1]))
		if (argc >1)
		{
//			printf("|%s|\n",argv[1]);
			StrPrintF(str,"%s ",argv[1]);
			if (StrStr(_dbInfoArray[_map[i]].name, " "))
			{
				StrCat(str,"\"%s\"\n");
			}
				else
			{
				StrCat(str,"%s\n");
			}
		}
		else
		{
			StrCopy(str,"%s\n");
		}
		printf(str, _dbInfoArray[_map[i]].name);
	}
	
	
	printf("\n");

	MemPtrFree(_dbInfoArray); _dbInfoArray = NULL;
	MemPtrFree(_map); _map = NULL;



}


/******************************************************************************
 * FUNCTION:   FTPLDirM
 *
 * DESCRIPTION: Handles the 'ldirm' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
//static 

void FTPLDirM(UInt argc, CharPtr argv[])
{

    DmOpenRef MemoDB;
    char title[42];
    BytePtr memo;
    Handle record;
    UInt16 ncat, incat;

    MemoDB = DmOpenDatabaseByTypeCreator('DATA', 'memo', dmModeReadOnly);
    if (!MemoDB) {
		printf("\nErr ");
		return;
		}

	incat=0;
    for (ncat = 0; ncat < 16; ) 
    {
		record = DmQueryNextInCategory(MemoDB, &incat, ncat);
		if (record) 
		{
			memo =  MemHandleLock(record);

		    get_memo_title((char *)memo, (char *)title);

			printf("pubm \"%s\"\n",title);
			MemHandleUnlock(record);
			incat++;
	    }
	    else
	    {
	    	incat=0;
	    	ncat++;
	    }
	}

    DmCloseDatabase(MemoDB);


/*
	int i,j;
	UShort tmp;
	char str[32];
	DmOpenRef dbP;

	Err err;

	// Syntax check
	if (argc < 1) {
		printf("\nSyntax: %s", argv[0]);
		return;
		}
	
  
	dbP = DmOpenDatabaseByTypeCreator (memoDBType, sysFileCMemo, mode);
	if (dbP)
	{
		i=0;
		while(true)
		{
			memoH = DmQueryRecord(dbP, i);
			if
			memoP = MemHandleLock(memoH);
			MemHandleUnlock(memoH);


		
		error = DmCreateDatabase (0, memoDBName, sysFileCMemo, memoDBType, false);
		if (error)
			return error;
		
		dbP = DmOpenDatabaseByTypeCreator(memoDBType, sysFileCMemo, mode);
		if (!dbP)
			return (1);

		// Set the backup bit.  This is to aid syncs with non Palm software.
		SetDBBackupBit(dbP);
		
		error = MemoAppInfoInit (dbP);
      if (error) 
      	{
			DmOpenDatabaseInfo(dbP, &dbID, NULL, NULL, &cardNo, NULL);
      	DmCloseDatabase(dbP);
      	DmDeleteDatabase(cardNo, dbID);
         return error;
         }
		}
	
	*dbPP = dbP;
	return 0;
	

	//printing
	for (i = 0; i < _dbCount; i++)
	{
//		printf("%s\n",_dbInfoArray[_map[i]].name);
		str[0]=0;
//		if (StrLen(argv[1]))
		if (argc >1)
		{
//			printf("|%s|\n",argv[1]);
			StrPrintF(str,"%s ",argv[1]);
			if (StrStr(_dbInfoArray[_map[i]].name, " "))
			{
				StrCat(str,"\"%s\"\n");
			}
				else
			{
				StrCat(str,"%s\n");
			}
		}
		else
		{
			StrCopy(str,"%s\n");
		}
		printf(str, _dbInfoArray[_map[i]].name);
	}
	
*/	
	printf("\n");



}



/******************************************************************************
 * FUNCTION:   FTPLDirMS
 *
 * DESCRIPTION: Handles the 'ldirms' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
//static 
/*
void FTPLDirMS(UInt argc, CharPtr argv[])


//static void ScanDirectory (UInt16 volRefNum, char* path)
{
UInt16 volRefNum;
UInt32 volIterator = 0L ;

FileInfoType info;
UInt32 dirIterator;
FileRef dirRef;
Err err;

void** fileNameH;
Char* fileName;
void** pathNameH;
Char* pathName;

void** dirNameH[12];
Char* dirName[12];

Int16 maxCount, dirCount, i;

	// VFS manager 
	UInt32 gVFSMgrVersion;


	// Is the VFS manager present?

	//err = FtrGet( sysFileCVFSMgr, vfsFtrIDVersion, &gVFSMgrVersion );
	err = FtrGet( 'vfsm' , 0 , &gVFSMgrVersion );
	if( err )
	{
		 // no VFS Manager present
		printf("\nNo Sony memory stick !\n");
		return;
	} 
//	
//	else 
//	{
//		// you could check for the correct version of VFS Manager here
//		printf("\nSony memory stick manager %ld\n",gVFSMgrVersion);
//		//printf("\nbut not yet implemented !");
//		//return;
//	}
//


	while(volIterator != 0xffffffffL )
	{
		err = VFSVolumeEnumerate(&volRefNum, &volIterator);
		if(err == 0x0000 )
		{
			//volRefNum
		}
		else
		{
            printf("Unable to locate the Memory Stick\n");
            return;
		}
		
	}


dirCount=1;
maxCount=12;

fileNameH = MemHandleNew(256);
fileName = MemHandleLock(fileNameH);
pathNameH = MemHandleNew(256);
pathName = MemHandleLock(pathNameH);

for (i=0; i<maxCount; i++)
{
	dirNameH[i]= MemHandleNew(256);
	dirName[i]= MemHandleLock(dirNameH[i]);
}

if (argc >1)
{
	StrCopy(dirName[0], argv[1]);
}
else
{
	StrCopy(dirName[0], "/palm");
}

while (dirCount>0)
{
	dirIterator = 0L ;
	err = VFSFileOpen(volRefNum, dirName[0], (0x0002UL) , &dirRef);
	if(err != 0x0000 ) 
	{
        printf("No directory %s found\n", argv[1]);
		goto freeMemory;
	}
	
	info.nameP=fileName;
	info.nameBufLen=255;
	
	while(dirIterator != 0xffffffffL )
	{
		err = VFSDirEntryEnumerate(dirRef, &dirIterator, &info);
		if(err != 0x0000 ) goto closeDirectory;
		if (info.attributes & (0x00000010UL) )
		{
			if (dirCount<maxCount)
			{
				StrPrintF(pathName, "%s/%s", dirName[0], fileName);
				StrCopy(dirName[dirCount], pathName);
				dirCount++;
			}
			else
			{
				printf("Error: too much directories !\n");
				goto freeMemory;
			}
		}
		else
		{
			StrPrintF(pathName, "%s/%s", dirName[0], fileName);

			if (StrStr(pathName, " "))
			{
				printf("put \"%s\"\n",pathName);
			}
			else
			{
				printf("put %s\n",pathName);
			}
		}
	}
	closeDirectory:
		err = VFSFileClose(dirRef);
		
	if (dirCount>0)
	{
		for (i=0; i<(dirCount-1); i++)
		{
			StrCopy(dirName[i],dirName[i+1]);
		}
		dirCount--;
	}
}

freeMemory:
	for (i=0; i<maxCount; i++)
	{
		MemHandleFree(dirNameH[i]);
	}
	MemHandleFree( fileNameH );
	MemHandleFree( pathNameH );
}


*/




/******************************************************************************
 * FUNCTION:   FTPPut
 *
 * DESCRIPTION: Handles the 'put' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPPut(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the STOR command
//	StrPrintF(FTPCommand, "STOR %s.prc\r\n", argv[1]);
	if (IsRessource(argv[1])==1)
	{
		printf("uploading %s.prc", argv[1]);
		StrPrintF(FTPCommand, "STOR %s.prc\r\n", argv[1]);
	}
	else
	{
		printf("uploading %s.pdb", argv[1]);
		StrPrintF(FTPCommand, "STOR %s.pdb\r\n", argv[1]);
	}
	
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the STOR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
	dataSock=acceptSock;
	
	
	// Send the database
	errno = FTPDatabaseWrite(0, argv[1], dataSock);
	if (errno) goto Exit;
	close(dataSock);
	close(acceptSock);
	dataSock = acceptSock = -1;
	
		
	// Get Transer complete message
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
	if (dataSock >= 0) close(dataSock);		 
}


/******************************************************************************
 * FUNCTION:   FTPPutcf
 *
 * DESCRIPTION: Handles the 'putcf' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPPutcf(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	char 			filename[256];
	char* pfilename;
	char pathSeparator;
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s [<path>\]<filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	//find filename only
	StrNCopy(filename,argv[1],255);
	pfilename=argv[1];
	pathSeparator='\\';
	pfilename=StrChr(pfilename,pathSeparator);
	if (pfilename == NULL)
	{
		pathSeparator='/';
		pfilename=argv[1];
		pfilename=StrChr(pfilename,pathSeparator);
	}
	while (pfilename != NULL)
	{
		pfilename++;
		StrCopy(filename,pfilename);
		pfilename=StrChr(pfilename,pathSeparator);
		
	}
	printf("filename: %s\n",filename);
	
	
	
	// Send the STOR command
	StrPrintF(FTPCommand, "STOR %s\r\n", filename);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the STOR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
	dataSock=acceptSock;
	
	
	// Send the database
	errno = FTPDatabaseWriteFromCF(0, argv[1], dataSock);
	if (errno) goto Exit;
	close(dataSock);
	close(acceptSock);
	dataSock = acceptSock = -1;
	
		
	// Get Transer complete message
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
	if (dataSock >= 0) close(dataSock);		 
}


/******************************************************************************
 * FUNCTION:   FTPPutms
 *
 * DESCRIPTION: Handles the 'putms' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/

/*
static void FTPPutms(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	char 			filename[256];
	char* pfilename;
	char pathSeparator;

	// VFS manager 
	UInt32 gVFSMgrVersion;
	UInt16 err;


	// Is the VFS manager present?

	//err = FtrGet( sysFileCVFSMgr, vfsFtrIDVersion, &gVFSMgrVersion );
	err = FtrGet( 'vfsm' , 0 , &gVFSMgrVersion );
	if( err )
	{
		 // no VFS Manager present
		printf("\nNo Sony memory stick !");
		return;
	} 
	else 
	{
		// you could check for the correct version of VFS Manager here
		printf("\nSony memory stick manager %ld",gVFSMgrVersion);
		//printf("\nbut not yet implemented !");
		//return;
	}

	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s [<path>\]<filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	//find filename only
	StrNCopy(filename,argv[1],255);
	pfilename=argv[1];
	pathSeparator='\\';
	pfilename=StrChr(pfilename,pathSeparator);
	if (pfilename == NULL)
	{
		pathSeparator='/';
		pfilename=argv[1];
		pfilename=StrChr(pfilename,pathSeparator);
	}
	while (pfilename != NULL)
	{
		pfilename++;
		StrCopy(filename,pfilename);
		pfilename=StrChr(pfilename,pathSeparator);
		
	}
	printf("filename: %s\n",filename);
	
	
	
	// Send the STOR command
	StrPrintF(FTPCommand, "STOR %s\r\n", filename);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the STOR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
	dataSock=acceptSock;
	
	
	// Send the database
	errno = FTPDatabaseWriteFromMS(0, argv[1], dataSock);
	if (errno) goto Exit;
	close(dataSock);
	close(acceptSock);
	dataSock = acceptSock = -1;
	
		
	// Get Transer complete message
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
	if (dataSock >= 0) close(dataSock);		 
}
*/

/******************************************************************************
 * FUNCTION:   FTPPub
 *
 * DESCRIPTION: Handles the 'pub' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPPub(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the STOR command
	StrPrintF(FTPCommand, "STOR %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the STOR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
	dataSock=acceptSock;
	
	
	// Send the database
	errno = FTPDatabaseWriteTextOnly(0, argv[1], dataSock);
	if (errno) goto Exit;
	close(dataSock);
	close(acceptSock);
	dataSock = acceptSock = -1;
	
		
	// Get Transer complete message
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
	if (dataSock >= 0) close(dataSock);		 
}


/******************************************************************************
 * FUNCTION:   FTPPubM
 *
 * DESCRIPTION: Handles the 'pubm' command, send a memo
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPPubM(UInt argc, CharPtr argv[])
{
	int				acceptSock = -1;
	int				dataSock = -1;
	
	UInt				reply;
	struct			sockaddr_in address;
	int				addrLen;
	
	
	// Syntax check
	if (argc < 2) {
		printf("\nSyntax: %s <filename>", argv[0]);
		return;
		}
	
	// Send the type command to put us into binary mode
	StrPrintF(FTPCommand, "TYPE I\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;


	// Create a data port to send the file to
//	acceptSock = FTPDataAcceptSocket();
	acceptSock = FTPDataAcceptSocketPasv();
	if (acceptSock < 0) return;
	
	
	// Send the STOR command
	StrPrintF(FTPCommand, "STOR %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		
	// Get Reply from the STOR command
	if (FTPGetReply(FTPCtlSock, &reply)) goto Exit;
	if (reply >= 400) goto Exit;
	
	
	// Accept a connection on our data port
	addrLen = sizeof(address);
//	if ((dataSock = accept (acceptSock, &address, &addrLen)) < 0) goto Exit;
	dataSock=acceptSock;
	
	
	// Send the database
	errno = FTPDatabaseWriteMemo(0, argv[1], dataSock);
	if (errno) goto Exit;
	close(dataSock);
	close(acceptSock);
	dataSock = acceptSock = -1;
	
		
	// Get Transer complete message
	FTPGetReply(FTPCtlSock, &reply);
	
	
Exit:
	if (errno) printf("\nError: %s", appErrString(errno));
	if (acceptSock >= 0) close(acceptSock);	
	if (dataSock >= 0) close(dataSock);		 
}



/******************************************************************************
 * FUNCTION:   FTPPwd
 *
 * DESCRIPTION: Handles the 'pwd' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPPwd(UInt argc, CharPtr argv[])
{
	UInt				reply;
	
	
	// Send the pwd command
	StrPrintF(FTPCommand, "PWD\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (FTPGetReply(FTPCtlSock, &reply)) goto ExitErr;
	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
}


/******************************************************************************
 * FUNCTION:   FTPCdcf
 *
 * DESCRIPTION: Handles the 'cdcf' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
/*
static void FTPCdcf(UInt argc, CharPtr argv[])
{

	Err					err = 0;
	char cwd[256];
	
	UInt16    FfsLibRef;
		
	err = SysLibFind(FfsLibName, &FfsLibRef);
    if (err == 0)
    {
        printf("Ffs library already loaded\n");
//        return err;
    }
    else
    {
        // The library wasn't pre-loaded -- we need to load it ourselves
        if ((err = SysLibLoad(FfsLibTypeID, FfsLibCreatorID, &FfsLibRef)) != 0)
        {
            printf("Could not load the Ffs library\n");
            return;
        }
    }
    
    // Library loaded -- now open it 
    if ((err = FfsLibOpen(FfsLibRef)) != 0)
    {
        printf("Could not open the Ffs library\n");
        return;
    }


//    StripWhiteSpace(&cmdline);
	StrCopy(cwd,".");
	if (argc==2) StrCopy(cwd,argv[1]);
	err=FfsChdir(FfsLibRef, cwd);
    if (err != 0)
        printf("Path not found\n");
    else
    {
       FfsGetcwd(FfsLibRef, cwd, 255);
       printf("\n%s\n",cwd);
    }
    



//    FfsGetcwd(FfsLibRef,buf,256);
//    printf("cf dir is: %s\n", buf);
//    MemPtrFree(buf);

	
CloseLib:	
	// close and unload the Ffs library 
    FfsLibClose(FfsLibRef);
    SysLibRemove(FfsLibRef);    // for now, this needs to be done
	
	
Exit:
	return;
}



*/


/******************************************************************************
 * FUNCTION:   FTPCd
 *
 * DESCRIPTION: Handles the 'cd' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPCd(UInt argc, CharPtr argv[])
{
	UInt				reply;
	
	
	// Validate arguments
	if (argc < 2) {
		printf("\nSyntax: %s <path>", argv[0]);
		return;
		}
	
	// Send the pwd command
	StrPrintF(FTPCommand, "CWD %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (FTPGetReply(FTPCtlSock, &reply)) goto ExitErr;
	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
}


/******************************************************************************
 * FUNCTION:   FTPMkd
 *
 * DESCRIPTION: Handles the 'mkd' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPMkd(UInt argc, CharPtr argv[])
{
	UInt				reply;
	
	
	// Validate arguments
	if (argc < 2) {
		printf("\nSyntax: %s <path>", argv[0]);
		return;
		}
	
	// Send the mkd command
	StrPrintF(FTPCommand, "MKD %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (FTPGetReply(FTPCtlSock, &reply)) goto ExitErr;
	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
}

/******************************************************************************
 * FUNCTION:   FTPRmd
 *
 * DESCRIPTION: Handles the 'rmd' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void FTPRmd(UInt argc, CharPtr argv[])
{
	UInt				reply;
	
	
	// Validate arguments
	if (argc < 2) {
		printf("\nSyntax: %s <path>", argv[0]);
		return;
		}
	
	// Send the rmd command
	StrPrintF(FTPCommand, "RMD %s\r\n", argv[1]);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (FTPGetReply(FTPCtlSock, &reply)) goto ExitErr;
	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
}


static Err TFTPGetReply(int sock)
{
	Int32 num_read;

	Err					err = 0;
	BytePtr				srcP;

	

	ULong					totalBytes = 0;
	ULong					ticks;
	

    

	
	 /* allocate a 4K buffer to hold data */
    if ((srcP = (UInt8 *)MemPtrNew(512)) == NULL)
    {
        printf("Can't allocate buffer\r\n");
        goto CloseLib;
    }





	ticks = TimGetTicks();
	num_read=0;

    /* copy the data */
    while((num_read=NetUReadN(sock, srcP, 500)) > 0)
    {

		srcP[num_read]=0;

        printf("%s", srcP);

		totalBytes += num_read;
	}


CloseFile:
    MemPtrFree(srcP);

	
CloseLib:	
	
	
Exit:
	ticks = TimGetTicks() - ticks;
	if (err) printf("\nGet error: %s", appErrString(err));
	else
		printf("\ntftpget %ld bytes received", 
			totalBytes);
	
	return err;

}



/******************************************************************************
 * FUNCTION:   TFTPGet
 *
 * DESCRIPTION: Handles the 'TFTPGet' command
 *
 *	CALLED BY:	FTPExecCommand
 *
 * RETURNED:   void
 *
 *****************************************************************************/
static void TFTPGet(UInt argc, CharPtr argv[])
{
	int		TFTPSock = -1;
	
	// Validate arguments
	if (argc < 3) {
		printf("\nSyntax: %s <server> <url>", argv[0]);
		return;
		}
	
	StrPrintF(FTPCommand, "GET %s HTTP/1.0\nHOST: %s\n\n", argv[2], argv[1]);
	
	// Open up a TCP connection to the TFTP control port.
	TFTPSock = NetUTCPOpen(argv[1], NULL, 80);
	if (TFTPSock < 0) {
		printf("\nError connecting to %s: %s",  argv[1], appErrString(errno));
		goto ExitErr;
		}
	else
		printf("\nConnected to %s.\n",  argv[1]);
		
	NetUWriteN(TFTPSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
	// Get Reply
	if (TFTPGetReply(TFTPSock)) goto ExitErr;
	
	if (TFTPSock > 0) close(TFTPSock);

	return;
	
ExitErr:
	printf("\nError: %s", appErrString(errno));
}




/******************************************************************************
 * FUNCTION:   FTPExecCommand
 *
 * DESCRIPTION: Separates an FTP command line string into argv's and
 *		then calls the appropriate FTP routine to process it.
 *
 *	CALLED BY:	CmdFTP
 *
 * PARAMETERS:
 *			cmdParamP	- pointer to command line
 *
 * RETURNED:   void
 *
 *****************************************************************************/
//static 
void FTPExecCommand(CharPtr cmdParamP)
{
	const int	maxArgc=5;
	CharPtr		argv[maxArgc+1];
	int			argc;
	Boolean		done = false;
	CharPtr		cmdBufP = 0;
	CharPtr		cmdP;

	// if null string, return
	if (!cmdParamP[0]) return;

	
	// Make a copy of the command since we'll need to write
	// 0's between the words and it might be from read-only space
	cmdP = cmdBufP = MemPtrNew(StrLen(cmdParamP) + 1);
	if (!cmdP) {
		printf("\nOut of memory\n");
		goto Exit;
		}
	MemMove(cmdP, cmdParamP, StrLen(cmdParamP) + 1);

	// Separate the cmd line into arguments
	argc = 0;
	argv[0] = 0;
	for (argc=0; !done && argc<=maxArgc; argc++) {
	
		// Skip leading spaces
		while((*cmdP == ' ' || *cmdP == '\t') && (*cmdP != 0))
			cmdP++;
			
		// Break out on null
		if (*cmdP == 0) break;
		
		// Get pointer to command
		argv[argc] = cmdP;
		if (*cmdP == 0) break;
		
		// Find the end of a quoted argument
		if (*cmdP == '"') {
			cmdP++;
			argv[argc] = cmdP;
			while(*cmdP) {
				if (*cmdP == '"') {*cmdP = 0; break;}
				if (*cmdP == 0) {done = true; break;}
				cmdP++;
				}
			cmdP++;
			}
			
		// Find the end of an unquoted argument
		else {
			while(1) {
				if (*cmdP == 0) {done = true; break;}
				if ((*cmdP == ' ') || (*cmdP == '\t')) {
					*cmdP = 0; 
					break;
					}
				cmdP++;
				}
			cmdP++;
			}
		}
	
	// Return if no arguments
	if (!argc) goto Exit;
		

	//--------------------------------------------------------------------
	// Call the appropriate routine
	//--------------------------------------------------------------------
	if (!StrCompare(argv[0], "help"))
		FTPHelp(argc, argv);
		
	else if (!StrCompare(argv[0], "quit"))
		FTPQuit = true;
		
	else if (!StrCompare(argv[0], "dir"))
		FTPDir(argc, argv);
	
	else if (!StrCompare(argv[0], "ldir"))
		FTPLDir(argc, argv);
	
	else if (!StrCompare(argv[0], "ldirm"))
		FTPLDirM(argc, argv);
/*	
	else if (!StrCompare(argv[0], "ldirms"))
		FTPLDirMS(argc, argv);
*/	
	else if (!StrCompare(argv[0], "pwd"))
		FTPPwd(argc, argv);
	
	else if (!StrCompare(argv[0], "cd"))
		FTPCd(argc, argv);
	
	else if (!StrCompare(argv[0], "mkd"))
		FTPMkd(argc, argv);
	
	else if (!StrCompare(argv[0], "rmd"))
		FTPRmd(argc, argv);
	
	else if (!StrCompare(argv[0], "get"))
		FTPGet(argc, argv);
	
	else if (!StrCompare(argv[0], "del"))
		FTPDel(argc, argv);
	
	else if (!StrCompare(argv[0], "put"))
		FTPPut(argc, argv);

	else if (!StrCompare(argv[0], "putcf"))
		FTPPutcf(argc, argv);

	else if (!StrCompare(argv[0], "getcf"))
		FTPGetcf(argc, argv);
/*
	else if (!StrCompare(argv[0], "putms"))
		FTPPutms(argc, argv);

	else if (!StrCompare(argv[0], "getms"))
		FTPGetms(argc, argv);
*/		
/*
	else if (!StrCompare(argv[0], "cdcf"))
		FTPCdcf(argc, argv);
*/
	else if (!StrCompare(argv[0], "pub"))
		FTPPub(argc, argv);
	
	else if (!StrCompare(argv[0], "pubm"))
		FTPPubM(argc, argv);
		
	else if (!StrCompare(argv[0], "tftpget"))
		TFTPGet(argc, argv);
	
	// Not found
	else
		printf("Unknown command: %s\n", argv[0]);
	
Exit:
	if (cmdBufP) MemPtrFree(cmdBufP);
			
}


static VoidPtr FTPGetObjectPtr(Word objectID)
{
FormPtr frm;
frm = FrmGetActiveForm();
return (FrmGetObjectPtr (frm, FrmGetObjectIndex(frm, objectID)));
}


/***********************************************************************
 *
 * FUNCTION:    FTPGetCommand
 *
 * DESCRIPTION: This routine grabs the current line of the text field
 *
 * PARAMETERS:  void
 *
 * RETURNED:    nothing.
 *
 * REVISION HISTORY:
 *
 ***********************************************************************/
static void FTPGetCommand(CharPtr promptP)
{
	CharPtr 		textP,p;
	SWord 		i,j;
	const int 	cmdBufSize = 50; 			// max allowed lenght for a command line
   char 			cmdBuf[cmdBufSize+1];   // buffer for holding command line
   Handle		textH;
	FieldPtr		fldP=0;


	// Get the text handle
		fldP = FTPGetObjectPtr(kMainTextFldID);
		textH = FldGetTextHandle(fldP);

   // parse text for command line interface here....
   if (!textH) return;
	textP = MemHandleLock(textH);
   
   if (fldP)
   	i = FldGetInsPtPosition(fldP) - 2;
   else
   	i = StrLen(textP)-2;  		// skip null and final linefeed
   
   
   // scan back to previous line or start of text
   while (i>0 && textP[i] != linefeedChr) i--;
   
   if (textP[i] == linefeedChr) i++;  		// do not include the linefeed...
   if (textP[i] == '>') i++;  				// skip over prompt...
   
   // copy into command buffer leaving out final linefeed
	for (p=&textP[i],j=0; *p && *p!=linefeedChr && j<cmdBufSize;)
		cmdBuf[j++] = *p++;
	cmdBuf[j] = 0;
	MemHandleUnlock(textH);
	
	
	// return command , skip ftp>
	StrCopy(promptP, cmdBuf+4);
	
}



/***********************************************************************
 *
 * FUNCTION:   CmdFTP()
 *
 * DESCRIPTION: FTP Client
 *
 *	CALLED BY:	AppProcessCommand in response to the "ftp" command
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void CmdFTP(int argc, CharPtr argv[])
{
	CharPtr		hostname = "localhost";
	CharPtr		service = "ftp";
	SWord			port = 0;
	UInt			result;
	CharPtr		promptP=0;
	DWord			oldAppNetTimeout;


	// Check for help
	if (argc > 1 && !StrCompare(argv[1], "?")) 	goto 	ShortHelp;
	if (argc > 1 && !StrCompare(argv[1], "??")) 	goto 	FullHelp;

	// Assume err
	FTPCtlSock = -1;
	FTPQuit = false;
	
	// Increase the timeout
	AppNetTimeout = 3000;

	oldAppNetTimeout = AppNetTimeout;
	if (AppNetTimeout < 180*sysTicksPerSecond) 
		AppNetTimeout = 180*sysTicksPerSecond;
	AppNetTimeout = 30*sysTicksPerSecond;


	// Get the host name and service name, if any
	if (argc > 1) 	hostname = argv[1];
	if (argc > 2) {
		service = argv[2];
		port = atoi(service);
		if (port > 0) service = 0;
		}
	
	
	// Test the new trace call
	NetLibTracePrintF(AppNetRefnum, "%s...", "about to connect");
	
	
	// Open up a TCP connection to the FTP control port.
	FTPCtlSock = NetUTCPOpen(hostname, service, port);
	if (FTPCtlSock < 0) {
		printf("\nError connecting to %s: %s", hostname, appErrString(errno));
		goto Exit;
		}
	else
		printf("\nConnected to %s.\n", hostname);
		
	// Test the new trace call
	NetLibTracePrintF(AppNetRefnum, "Connect: %s", hostname);
	NetLibTracePutS(AppNetRefnum, "Connected");
	

	// Get the connect message from the server
	if (FTPGetReply(FTPCtlSock, &result)) goto Exit;
	
	
	// Allocate space for the prompt string
	promptP = MemPtrNew(0x100);
	if (!promptP) {printf("\nOut of Memory"); goto Exit;}
	
	
	//-----------------------------------------------------------------
	// Ask for user name
	//-----------------------------------------------------------------
	// if use of preferences do it
	if (LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs!=0)
	{
		StrCopy(promptP, LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Login);
	}
	else
	{
		printf("\nName: ");
		if (StdGetS(promptP, true) < 0) goto Exit;
	}
	StrPrintF(FTPCommand, "USER %s\r\n", promptP);
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	
	// Get response
	if (FTPGetReply(FTPCtlSock, &result)) goto Exit;
	
	
	
	//-----------------------------------------------------------------
	// If necessary, ask for password
	//-----------------------------------------------------------------
	if (result >= 300 && result <= 399)  {
		// Ask for password
		// if use of preferences do it
		if (LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs!=0)
		{
			StrCopy(promptP, LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Password);
		}
		else
		{
			printf("\nPassword: ");
//			if (StdGetS(promptP, false) < 0) goto Exit;
			if (StdGetS(promptP, true) < 0) goto Exit;
		}
		
		StrPrintF(FTPCommand, "PASS %s\r\n", promptP);
		NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
		
		// Get response
		if (FTPGetReply(FTPCtlSock, &result)) goto Exit;
		if (result < 200 || result > 299) goto Exit;
		}
		
	
	
		// if use of preferences do it
		if (LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs!=0)
		{
			if (LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UseCommands!=0 && LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd[0])
			{
			
				CharPtr		cmdP;
				CharPtr		cmdP2;

				printf("\nNow, using scripted commands...\n");

				cmdP = MemPtrNew(StrLen(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd) + 1);
				if (!cmdP) 
				{
					printf("\nOut of memory\n");
				goto Exit;
				}
				StrCopy(cmdP, LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd);
				
				cmdP2=cmdP;				
				while( (cmdP=StrChr(cmdP, '\n')) != NULL )
				{
					*cmdP=0;
					printf("[%s]\n",cmdP2);
					FTPExecCommand(cmdP2);
					cmdP2=++cmdP;
			
				}
				printf("[%s]\n",cmdP2);
				FTPExecCommand(cmdP2);

			
			
/*				
				
				
				
				
				
				
				StrCopy(promptP, "pwd");
				printf("\n%s\n",promptP);
				FTPExecCommand(promptP);
				StrCopy(promptP, "dir");
				printf("\n%s\n",promptP);
				FTPExecCommand(promptP);
				StrCopy(promptP, "pwd");
				printf("\n%s\n",promptP);
				FTPExecCommand(promptP);
				StrCopy(promptP, "quit");
				printf("\n%s\n",promptP);
				FTPExecCommand(promptP);
				
				
*/				
			}
		}

	
	// Print help string
	printf("\nType 'help' to get list of commands\n");
	
	
	//-----------------------------------------------------------------
	// Enter loop to process user commands now
	//-----------------------------------------------------------------
	while (!FTPQuit) {
		
		// Get prompt from user
		printf("\nftp> ");
		if (StdGetS(promptP, true) < 0) goto Exit;
		
//StdGetS doesn't handle clipboard operations, so read from fiels again
// lth 24/09/2000		
		
		FTPGetCommand(promptP);
		
		
		
		
		FTPExecCommand(promptP);
		}


	//-----------------------------------------------------------------
	// Send the Quit command
	//-----------------------------------------------------------------
	StrPrintF(FTPCommand, "QUIT\r\n");
	NetUWriteN(FTPCtlSock, (BytePtr)FTPCommand, StrLen(FTPCommand));
	
	// Get response
	FTPGetReply(FTPCtlSock, &result);
	

	
	//==================================================================
	// Exit now.
	//======================================================================
Exit:
	// Restore timeout
	AppNetTimeout = oldAppNetTimeout;

	// Release prompt string ptr
	if (promptP) MemPtrFree(promptP);

	// Close the connection, if open
	if (FTPCtlSock >= 0) close(FTPCtlSock);
	printf("\nExited FTP.\n");
	return;
	
	
	
ShortHelp:
	printf("%s\t\t\t# FTP Client\n", argv[0]);
	return;
	
FullHelp:
	printf("\nFTP Client");
	printf("\nSyntax: %s <server> [<port>]", argv[0]);
//	printf("\n");
	FTPHelp(argc, argv);
}




/***********************************************************************
 *
 * FUNCTION:   	CmdFTPInstall
 *
 * DESCRIPTION: 	Installs the commands from this module into the
 *		master command table used by AppProcessCommand.
 *
 *	CALLED BY:		AppStart 
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
void CmdFTPInstall(void)
{
	AppAddCommand("_", CmdDivider);

#if INCLUDE_FTP
	AppAddCommand("ftp", CmdFTP);
#endif

}




