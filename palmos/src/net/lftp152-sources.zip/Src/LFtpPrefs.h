
typedef struct {
	int UsePrefs;
	int UseCommands;
	char Server[32+1];
	char Login[32+1];
	char Password[32+1];
	char Cmd[256+1];
} LFtpPrefsItem;

typedef struct{
	LFtpPrefsItem LFtpItems[5];
	int InUse;
}	LFtpPreferenceType;

//LFtpPreferenceType LFtpPrefs;
