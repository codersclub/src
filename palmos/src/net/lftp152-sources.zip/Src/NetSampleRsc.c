/***********************************************************************
 *
 * Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 * All rights reserved.
 *
 * PROJECT:  Pilot Sample Internet Application
 * FILE:     NetSampleRsc.c
 *
 * DESCRIPTION:
 *		This file provides the list of resource files that
 *		are used by the application when running in the Simulator. 
 *
 **********************************************************************/

#include <Pilot.h>

#if 		LANGUAGE == LANGUAGE_ENGLISH
#define RESOURCE_FILE_PREFIX ""

#elif 	LANGUAGE == LANGUAGE_FRENCH
#define RESOURCE_FILE_PREFIX "French:"

#elif 	LANGUAGE == LANGUAGE_GERMAN
#define RESOURCE_FILE_PREFIX "German:"
#endif
 
char *AppResourceList[] = {
	":Rsc:" RESOURCE_FILE_PREFIX "NetSampleMain.rsrc", 
	":Rsc:" RESOURCE_FILE_PREFIX "NetSampleApp.rsrc", 
	":Rsc:" RESOURCE_FILE_PREFIX "NetSampleMisc.rsrc", 
	":Rsc:" RESOURCE_FILE_PREFIX "LFtpPrefs.rsrc"
	};


