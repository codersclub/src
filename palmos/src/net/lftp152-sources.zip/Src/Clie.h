
/* #line 21	"ExpansionMgr.h"	/* stack depth 2 */
typedef Err (*ExpPollingProcPtr)(UInt16 slotLibRefNum,
void *slotPollRefConP);
typedef struct ExpCardInfoTag
{
UInt32 capabilityFlags;
Char manufacturerStr[31 +1];
Char productStr[31 +1];
Char deviceClassStr[31 +1];
Char deviceUniqueIDStr[31 +1];
} ExpCardInfoType, *ExpCardInfoPtr;
typedef enum {
expInit = 0,
expSlotDriverInstall,
expSlotDriverRemove,
expSlotLibFind,
expSlotRegister,
expSlotUnregister,
expCardInserted,
expCardRemoved,
expCardPresent,
expCardInfo,
expSlotEnumerate,
expMaxSelector = expSlotEnumerate,
expBigSelector = 0x7FFF
} ExpansionMgrSelector;
Err ExpCardPresent(UInt16 slotRefNumber)
= { 0x7400 + expCardPresent, 0x4E40 + 15, sysTrapSysReserved2 } ;
Err ExpCardInfo(UInt16 slotRefNumber, ExpCardInfoType* infoP)
= { 0x7400 + expCardInfo, 0x4E40 + 15, sysTrapSysReserved2 } ;
/* #line 44	"VFSMgr.h"	/* stack depth 1 */
typedef struct VFSAnyMountParamTag {
UInt16 volRefNum;
UInt16 reserved;
UInt32 mountClass;
} VFSAnyMountParamType;
typedef VFSAnyMountParamType *VFSAnyMountParamPtr ;
typedef struct VFSSlotMountParamTag {
VFSAnyMountParamType vfsMountParam;
UInt16 slotLibRefNum;
UInt16 slotRefNum;
} VFSSlotMountParamType;
typedef struct FileInfoTag{
UInt32 attributes;
Char *nameP;
UInt16 nameBufLen;
} FileInfoType, *FileInfoPtr;
typedef struct VolumeInfoTag{
UInt32 attributes;
UInt32 fsType;
UInt32 fsCreator;
UInt32 mountClass;
UInt16 slotLibRefNum;
UInt16 slotRefNum;
UInt32 mediaType;
UInt32 reserved;
} VolumeInfoType, *VolumeInfoPtr;
typedef UInt32 FileRef;
typedef UInt16 FileOrigin;
typedef enum {
vfsTrapInit = 0,
vfsTrapCustomControl,
vfsTrapFileCreate,
vfsTrapFileOpen,
vfsTrapFileClose,
vfsTrapFileReadData,
vfsTrapFileRead,
vfsTrapFileWrite,
vfsTrapFileDelete,
vfsTrapFileRename,
vfsTrapFileSeek,
vfsTrapFileEOF,
vfsTrapFileTell,
vfsTrapFileResize,
vfsTrapFileAttributesGet,
vfsTrapFileAttributesSet,
vfsTrapFileDateGet,
vfsTrapFileDateSet,
vfsTrapFileSize,
vfsTrapDirCreate,
vfsTrapDirEntryEnumerate,
vfsTrapGetDefaultDirectory,
vfsTrapRegisterDefaultDirectory,
vfsTrapUnregisterDefaultDirectory,
vfsTrapVolumeFormat,
vfsTrapVolumeMount,
vfsTrapVolumeUnmount,
vfsTrapVolumeEnumerate,
vfsTrapVolumeInfo,
vfsTrapVolumeLabelGet,
vfsTrapVolumeLabelSet,
vfsTrapVolumeSize,
vfsTrapInstallFSLib,
vfsTrapRemoveFSLib,
vfsTrapImportDatabaseFromFile,
vfsTrapExportDatabaseToFile,
vfsTrapFileDBGetResource,
vfsTrapFileDBInfo,
vfsTrapFileDBGetRecord,
vfsMaxSelector = vfsTrapFileDBGetRecord,
vfsBigSelector = 0x7FFF
} VFSMgrSelector;
Err VFSFileCreate(UInt16 volRefNum, const Char *pathNameP)
= { 0x7400 + vfsTrapFileCreate, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileOpen(UInt16 volRefNum, const Char *pathNameP,
UInt16 openMode, FileRef *fileRefP)
= { 0x7400 + vfsTrapFileOpen, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileClose(FileRef fileRef)
= { 0x7400 + vfsTrapFileClose, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileReadData(FileRef fileRef, UInt32 numBytes, void *bufBaseP,
UInt32 offset, UInt32 *numBytesReadP)
= { 0x7400 + vfsTrapFileReadData, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileRead(FileRef fileRef, UInt32 numBytes, void *bufP, UInt32 *numBytesReadP)
= { 0x7400 + vfsTrapFileRead, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileWrite(FileRef fileRef, UInt32 numBytes, const void *dataP, UInt32 *numBytesWrittenP)
= { 0x7400 + vfsTrapFileWrite, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileDelete(UInt16 volRefNum, const Char *pathNameP)
= { 0x7400 + vfsTrapFileDelete, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileRename(UInt16 volRefNum, const Char *pathNameP, const Char *newNameP)
= { 0x7400 + vfsTrapFileRename, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileSeek(FileRef fileRef, FileOrigin origin, Int32 offset)
= { 0x7400 + vfsTrapFileSeek, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileEOF(FileRef fileRef)
= { 0x7400 + vfsTrapFileEOF, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileTell(FileRef fileRef, UInt32 *filePosP)
= { 0x7400 + vfsTrapFileTell, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileResize(FileRef fileRef, UInt32 newSize)
= { 0x7400 + vfsTrapFileResize, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileAttributesGet(FileRef fileRef, UInt32 *attributesP)
= { 0x7400 + vfsTrapFileAttributesGet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileAttributesSet(FileRef fileRef, UInt32 attributes)
= { 0x7400 + vfsTrapFileAttributesSet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileDateGet(FileRef fileRef, UInt16 whichDate, UInt32 *dateP)
= { 0x7400 + vfsTrapFileDateGet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileDateSet(FileRef fileRef, UInt16 whichDate, UInt32 date)
= { 0x7400 + vfsTrapFileDateSet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileSize(FileRef fileRef, UInt32 *fileSizeP)
= { 0x7400 + vfsTrapFileSize, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSDirCreate(UInt16 volRefNum, const Char *dirNameP)
= { 0x7400 + vfsTrapDirCreate, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSDirEntryEnumerate(FileRef dirRef, UInt32 *dirEntryIteratorP, FileInfoType *infoP)
= { 0x7400 + vfsTrapDirEntryEnumerate, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeFormat(UInt8 flags, UInt16 fsLibRefNum, VFSAnyMountParamPtr vfsMountParamP)
= { 0x7400 + vfsTrapVolumeFormat, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeEnumerate(UInt16 *volRefNumP, UInt32 *volIteratorP)
= { 0x7400 + vfsTrapVolumeEnumerate, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeInfo(UInt16 volRefNum, VolumeInfoType *volInfoP)
= { 0x7400 + vfsTrapVolumeInfo, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeLabelGet(UInt16 volRefNum, Char *labelP, UInt16 bufLen)
= { 0x7400 + vfsTrapVolumeLabelGet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeLabelSet(UInt16 volRefNum, const Char *labelP)
= { 0x7400 + vfsTrapVolumeLabelSet, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSVolumeSize(UInt16 volRefNum, UInt32 *volumeUsedP, UInt32 *volumeTotalP)
= { 0x7400 + vfsTrapVolumeSize, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSImportDatabaseFromFile(UInt16 volRefNum, const Char *pathNameP,
UInt16 *cardNoP, LocalID *dbIDP)
= { 0x7400 + vfsTrapImportDatabaseFromFile, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSExportDatabaseToFile(UInt16 volRefNum, const Char *pathNameP,
UInt16 cardNo, LocalID dbID)
= { 0x7400 + vfsTrapExportDatabaseToFile, 0x4E40 + 15, sysTrapSysReserved3 } ;
/*
Err VFSFileDBGetResource(FileRef ref, DmResType type, DmResID resID, MemHandle *resHP)
= { 0x7400 + vfsTrapFileDBGetResource, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileDBInfo(FileRef ref, Char *nameP,
UInt16 *attributesP, UInt16 *versionP, UInt32 *crDateP,
UInt32 *modDateP, UInt32 *bckUpDateP,
UInt32 *modNumP, MemHandle *appInfoHP,
MemHandle *sortInfoHP, UInt32 *typeP,
UInt32 *creatorP, UInt16 *numRecordsP)
= { 0x7400 + vfsTrapFileDBInfo, 0x4E40 + 15, sysTrapSysReserved3 } ;
Err VFSFileDBGetRecord(FileRef ref, UInt16 recIndex, MemHandle *recHP,
UInt8 *recAttrP, UInt32 *uniqueIDP)
= { 0x7400 + vfsTrapFileDBGetRecord, 0x4E40 + 15, sysTrapSysReserved3 } ;
*/
