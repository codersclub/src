/***********************************************************************
 *
 * Copyright (c) 1994-1999 3Com Corporation or its subsidiaries.
 * All rights reserved.
 *
 * PROJECT:  Pilot Sample Internet Application
 * FILE:     NetSample.c
 *
 * DESCRIPTION:
 *	
 * This application is provided as an example of how to use the Net Library
 * of the PalmOS when writing internet applications. It does NOT have a pretty
 * UI and should not be used as a model application. It does however show
 * how to use the Net Library to implement various internet applications like
 * ftp, telnet, etc. 
 *
 * When launched, this application shows a scrolling text window where commands
 * can be entered using Graffiti, or chosen from the menus. Most of the
 * commands take a wide range of command-line arguments. The 'help' command
 * will list the available commands and 'help <command>' will list help
 * on a specific command.
 *
 * IMPORTANT: In order to run this application in the Simulator, you must 
 * have a memory card image file ("Pilot Card 0") in it's directory that has 
 * the "Net Prefs" database created by the "Network" preference panel 
 * in it. Without this database present, you won't be able to dial up and
 * establish a connection with an internet service provider. To create this
 * memory card image, run the "Network" preference panel simulator app and
 * set things up for your ISP. Then, save the memory card image using the 
 * "File" menu and then copy it to the NetSample directory. 
 *
 **********************************************************************/


// Include the PalmOS headers
#include <SysAll.h>
#include <UIAll.h>
#include <NetMgr.h>


// Include this header so that we can use the Berkeley sockets API
#include <sys_socket.h>


// This header is currently located in this application's project
// directory but could be used by other applications as well. It
// provides calls for primitive stdio to a window.
#include "AppStdIO.h"


// Application specific includes
#include "NetSample.h"


// include for TRGPro
//#include "ffslib.h"


/***********************************************************************
 *
 *	Prototypes of private functions to this module
 *
 ***********************************************************************/
static Err		AppNetInit(void);
static Err		AppNetFree(void);
static Err 		NetLibCompatible (DWord requiredVersion, Word launchFlags);


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
static MenuBarPtr		CurrentMenuP;
static Word				CurrentViewID;
UInt						AppNeedNetLibClose = 0;
Char						AppErrStr[kAppErrStrLen];
Char	tmpStr[256];

// This is needed because we don't link with stdlib when we compile
//  for the device.
#if EMULATION_LEVEL == EMULATION_NONE
Err			errno;
#endif

/*
typedef struct {
	int UsePrefs;
	int UseCommands;
	char Server[80+1];
	char Login[80+1];
	char Password[80+1];
	char Cmd[800+1];
} LFtpPreferenceType;
*/
#include "LFtpPrefs.h"
LFtpPreferenceType LFtpPrefs;




//usefull functions

static VoidPtr GetObjectPtr(Word objectID)
{
FormPtr frm;
frm = FrmGetActiveForm();
return (FrmGetObjectPtr (frm, FrmGetObjectIndex(frm, objectID)));
}


static FieldPtr SetFieldTextFromHandle (FieldPtr fldP, Handle txtH)
{
	Handle oldTxtH;

	oldTxtH=FldGetTextHandle (fldP);
	FldSetTextHandle (fldP, txtH);
	FldDrawField(fldP);
	if(oldTxtH) MemHandleFree (oldTxtH);
	return fldP;
}

static FieldPtr SetFieldTextFromString (FieldPtr fldP, CharPtr strP)
{
	Handle txtH;

	txtH= MemHandleNew (StrLen (strP)+1);
	if(!txtH) return NULL;
	StrCopy (MemHandleLock (txtH), strP);
	MemHandleUnlock (txtH);
	return SetFieldTextFromHandle (fldP, txtH);
}


/***********************************************************************
 *
 * FUNCTION:    MainViewInit
 *
 * DESCRIPTION: This routine initializes the "Main View" of the 
 *              NetSample application.
 *
 * PARAMETERS:  frmP - pointer to form
 *
 * RETURNED:    void
 *
 ***********************************************************************/
static void MainViewInit (FormPtr frmP)
{
	CurrentViewID = kMainFormID;
}



/***********************************************************************
 *
 * FUNCTION:    MainViewDoCommand
 *
 * DESCRIPTION: This routine performs the menu command specified.
 *
 * PARAMETERS:  command  - menu item id
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static Boolean MainViewDoCommand (Word command)
{
//	NetMasterPBType	pb;
//	Err					err;
//	Char					text[100];
//	DWord					oldTrace;
//	Int					i;
//	DWord					value;
//	Word					settingSize;
	Boolean				setTraceBits = false;
//	Word					index;
//	Byte					traceRoll;
	CharPtr				cmdP;
	Boolean 				handled = true;
	

	switch (command) {
		//...........................................................
		// Utility Menu
		//...........................................................

			
			
		case kMainUtilFTP:
		case kMainUtilFTP+1:
		case kMainUtilFTP+2:
		case kMainUtilFTP+3:
		case kMainUtilFTP+4:
		{
			cmdP = "ftp ftpperso.free.fr";
			LFtpPrefs.InUse=command-kMainUtilFTP;
			// if use of preferences do it
			/*
			if (LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs!=0)
			{
				StrCopy(tmpStr, "ftp ");
				StrCat(tmpStr, LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Server);
				cmdP=tmpStr;
			}
			*/
			StrCopy(tmpStr, "ftp ");
			StrCat(tmpStr, LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Server);
			cmdP=tmpStr;

			printf("\n%s...\n", cmdP);
			AppExecCommand(cmdP);
			break;
		}
/*			
		case kMainUtilFTP+1:
			cmdP = "ftp 127.0.0.1";
			printf("\n%s...\n", cmdP);
			AppExecCommand(cmdP);
			break;
*/
		
			
		//...........................................................
		// Misc Menu
		//...........................................................
		case kMainMiscAboutCmd:
			MenuEraseStatus (CurrentMenuP);
			AbtShowAbout (kAppCreator);
			break;
			
		case kMainMiscAboutCmd+1: //prefs
			AppExecCommand("close");
		
			FrmGotoForm(LFtpPrefsForm);
			break;
/*			
		case kMainMiscHelp: //Help
			AppExecCommand("ftp help");
			break;
*/			
			
		default:
			// allow edit events to be handled by frmhandleevent
			handled = false;
			break;
		
		}	

	return handled;
}


/***********************************************************************
 *
 * FUNCTION:    MainViewHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the "Main View"
 *              of the NetSample application
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 ***********************************************************************/
static Boolean MainViewHandleEvent (EventPtr event)
{
	FormPtr 	frmP;
	Boolean 	handled = false;
	
	
	// See if StdIO can handle it
	if (StdHandleEvent(event)) return true;
	

	//---------------------------------------------------------------
	// Key Events
	//---------------------------------------------------------------
	if (event->eType == keyDownEvent) {
		}

		
	//---------------------------------------------------------------
	// Controls
	//---------------------------------------------------------------
	else if (event->eType == ctlSelectEvent) {
		switch (event->data.ctlSelect.controlID) {
			/* A case statement for each button
			case NewMemoButton:
				handled = true;
				break;
			*/
			}
		}


	//---------------------------------------------------------------
	// Menus
	//---------------------------------------------------------------
	else if (event->eType == menuEvent) {
		return MainViewDoCommand (event->data.menu.itemID);
		}

		
	//---------------------------------------------------------------
	// Form Open
	//---------------------------------------------------------------
	else if (event->eType == frmOpenEvent) {
		frmP = FrmGetActiveForm ();
		MainViewInit (frmP);
		FrmDrawForm (frmP);
		handled = true;

		printf("\nLFtp, ftp client for Palm");
		printf("\n[compiled %s %s]",__DATE__,__TIME__);
		printf("\n(LFtp is based on NetSample from Palm's SDK)");
		printf("\nLaurent THALER");

		printf("\nlthaler@free.fr");
		printf("\nhttp://lthaler.free.fr");
		printf("\n");

		// Open the Net Lib.
		AppExecCommand("open");
		
		// If successfully opened, print welcome message
		if (AppNeedNetLibClose) {
			printf("\nWelcome to LFtp !");
			printf("\nType 'help' to get a list of commands, or choose a"
					 " menu item.");
			printf("\n\nType 'ftp' to enter ftp mode, or use preferred scripted commands.\n\n");
// lance FTPHelp
//			StrCopy(tmpStr, "help ftp");
//			AppExecCommand(tmpStr);
			
			}
		}
/*		
		// if use of preferences do it
		if (LFtpPrefs.Use!=0)
		{
			StrCopy(tmpStr, "ftp ");
			StrCat(tmpStr, LFtpPrefs.Server);
			AppExecCommand(tmpStr);
		}
*/			

	return (handled);
}



static void UpdateScrollbar(void)
{
FormPtr frm= FrmGetActiveForm();
ScrollBarPtr scroll;
FieldPtr field;
Word currentPosition;
Word textHeight;
Word fieldHeight;
Word maxValue;

field = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, LFtpPrefsCmdField));
FldGetScrollValues(field, &currentPosition, &textHeight, &fieldHeight);
if (textHeight>fieldHeight)
	maxValue = textHeight - fieldHeight;
else if (currentPosition)
	maxValue = currentPosition;
else 
	maxValue=0;

scroll=FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, LFtpPrefsCmdScrlScrollBar ));

SclSetScrollBar(scroll, currentPosition, 0, maxValue, fieldHeight-1);
}

static void ScrollLines(int numLinesToScroll, Boolean redraw)
{
FormPtr frm= FrmGetActiveForm();
FieldPtr field;
field = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, LFtpPrefsCmdField));
if (numLinesToScroll<0)
	FldScrollField(field, -numLinesToScroll, up);
else FldScrollField(field, numLinesToScroll, down);
	UpdateScrollbar();

}

static void PageScroll(DirectionType direction)
{
FormPtr frm= FrmGetActiveForm();
FieldPtr field;
field = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, LFtpPrefsCmdField));
if (FldScrollable(field, direction))
{
	int linesToScroll = FldGetVisibleLines (field) - 1;
	if (direction==up) 
linesToScroll = -linesToScroll;
	ScrollLines(linesToScroll, true);
}
}



/***********************************************************************
 *
 * FUNCTION:    PrefsHandleEvent
 *
 * DESCRIPTION: This routine is the event handler for the 
 *              "PrefsForm" of this application.
 *
 * PARAMETERS:  eventP  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has handle and should not be passed
 *              to a higher level handler.
 *
 * REVISION HISTORY:
 *
 *
 ***********************************************************************/
static Boolean PrefsHandleEvent(EventPtr eventP)
{
    Boolean handled = false;
    FormPtr frmP;


	switch (eventP->eType) 
		{

		case frmOpenEvent:
			frmP = FrmGetActiveForm();
			
			SetFieldTextFromString (GetObjectPtr(LFtpPrefsServerField),
				 LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Server);
			SetFieldTextFromString (GetObjectPtr(LFtpPrefsLoginField),
				 LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Login);
			SetFieldTextFromString (GetObjectPtr(LFtpPrefsPasswordField),
				 LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Password);
			SetFieldTextFromString (GetObjectPtr(LFtpPrefsCmdField),
				 LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd);
				 
			FrmSetControlValue(frmP, FrmGetObjectIndex (frmP, 
				LFtpPrefsUsePrefsCheckbox), 
				(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs == 1));

			FrmSetControlValue(frmP, FrmGetObjectIndex (frmP, 
				LFtpPrefsUseCommandsCheckbox),
				(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UseCommands == 1));
				
			FrmSetControlValue(frmP, FrmGetObjectIndex (frmP, 
				LFtpPrefsSelect1PushButton+LFtpPrefs.InUse), true);
				
					
			FrmSetFocus(frmP, FrmGetObjectIndex(frmP, LFtpPrefsCmdField));
			
			UpdateScrollbar();
			
			FrmSetFocus(frmP, FrmGetObjectIndex(frmP, LFtpPrefsServerField));

			FrmDrawForm (frmP);
			
			
			handled = true;
			break;
			
		case fldChangedEvent:
		{
			UpdateScrollbar();
			handled=true;
			break;
		}
		case sclRepeatEvent:
		{
			ScrollLines (eventP->data.sclRepeat.newValue -
			 eventP->data.sclRepeat.value, false);
			break;
		}
		case keyDownEvent:
		{
			if (eventP->data.keyDown.chr == pageUpChr)
			{
				PageScroll(up);
				handled=true;
			}
			else if (eventP->data.keyDown.chr == pageDownChr)
			{
				PageScroll(down);
				handled=true;
			}
			break;
		}
			
		case ctlSelectEvent:
		switch (eventP->data.ctlSelect.controlID)
		{
			case LFtpPrefsUsePrefsCheckbox:
			case LFtpPrefsUseCommandsCheckbox:
			{
				break;
			}
			case LFtpPrefsSelect1PushButton:
			case LFtpPrefsSelect2PushButton:
			case LFtpPrefsSelect3PushButton:
			case LFtpPrefsSelect4PushButton:
			case LFtpPrefsSelect5PushButton:
			{
			
				//save fields values into prefs
				
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Server, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsServerField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Login, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsLoginField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Password, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsPasswordField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsCmdField)));
				
				LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs=FrmGetControlValue(FrmGetActiveForm(),
						FrmGetObjectIndex (FrmGetActiveForm(),
						LFtpPrefsUsePrefsCheckbox));
				
				LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UseCommands=FrmGetControlValue(FrmGetActiveForm(),
						FrmGetObjectIndex (FrmGetActiveForm(),
						LFtpPrefsUseCommandsCheckbox));
		
				LFtpPrefs.InUse=eventP->data.ctlSelect.controlID - LFtpPrefsSelect1PushButton;
				FrmGotoForm(LFtpPrefsForm);
				break;
			}
			case LFtpPrefsOkButton:
			
				//save fields values into prefs
				
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Server, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsServerField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Login, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsLoginField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Password, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsPasswordField)));
				StrCopy(LFtpPrefs.LFtpItems[LFtpPrefs.InUse].Cmd, 
					FldGetTextPtr(GetObjectPtr(LFtpPrefsCmdField)));
				
				LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UsePrefs=FrmGetControlValue(FrmGetActiveForm(),
						FrmGetObjectIndex (FrmGetActiveForm(),
						LFtpPrefsUsePrefsCheckbox));
				
				LFtpPrefs.LFtpItems[LFtpPrefs.InUse].UseCommands=FrmGetControlValue(FrmGetActiveForm(),
						FrmGetObjectIndex (FrmGetActiveForm(),
						LFtpPrefsUseCommandsCheckbox));
		
				FrmGotoForm(kMainFormID);
				handled = true;
				break;

			case LFtpPrefsCancelButton:
			default:
				FrmGotoForm(kMainFormID);
				handled = true;
				break;
		}
		default:
			break;
		
		}
	
	return handled;
}



/***********************************************************************
 *
 * FUNCTION:   	AppAddCommand
 *
 * DESCRIPTION: 	Adds a command to the master command table
 *						Each of the command modules makes calls to this routine
 *						to install it's commands into the table.
 *
 *	CALLED BY:		CmdInfoInstall(), CmdSockInstall(), etc. during startup 
 *
 * RETURNED:    	void
 *
 ***********************************************************************/
typedef struct {
	CharPtr				nameP;							// command name
	CmdProcPtr			procP;							// procedure
	} CmdTableEntryType;
#define					kMaxCommands 	64				// Max # of commands
Word						NumCommands = 0;
CmdTableEntryType		CmdTable[kMaxCommands];		// command table
	
void AppAddCommand(CharPtr cmdStr, CmdProcPtr procP)
{
	if (NumCommands >= kMaxCommands-1) {
		ErrDisplay("Too many commands");
		return;
		}
		
	CmdTable[NumCommands].nameP = cmdStr;
	CmdTable[NumCommands++].procP = procP;
}


/******************************************************************************
 *
 * FUNCTION:   	AppExecCommand
 *
 * DESCRIPTION: 	Separates a command line into argc, argv components and then
 *						calls the appropriate routine.
 *
 *	CALLED BY:		Menu command handlers, command line processor, etc.
 *
 * RETURNED:    	void
 *
 *****************************************************************************/
void AppExecCommand(CharPtr cmdParamP)
{
	const int	maxArgc=10;
	CharPtr		argv[maxArgc+1];
	int			argc;
	Boolean		done = false;
	UInt			i;
	CharPtr		cmdBufP = 0;
	CharPtr		cmdP;

	// if null string, return
	if (!cmdParamP[0]) return;

	
	// Make a copy of the command since we'll need to write
	// 0's between the words and it might be from read-only space
	cmdP = cmdBufP = MemPtrNew(StrLen(cmdParamP) + 1);
	if (!cmdP) {
		printf("\nOut of memory\n");
		goto Exit;
		}
	MemMove(cmdP, cmdParamP, StrLen(cmdParamP) + 1);

	// Separate the cmd line into arguments
	argc = 0;
	argv[0] = 0;
	for (argc=0; !done && argc<=maxArgc; argc++) {
	
		// Skip leading spaces
		while((*cmdP == ' ' || *cmdP == '\t') && (*cmdP != 0))
			cmdP++;
			
		// Break out on null
		if (*cmdP == 0) break;
		
		// Get pointer to command
		argv[argc] = cmdP;
		if (*cmdP == 0) break;
		
		// Find the end of a quoted argument
		if (*cmdP == '"') {
			cmdP++;
			argv[argc] = cmdP;
			while(*cmdP) {
				if (*cmdP == '"') {*cmdP = 0; break;}
				if (*cmdP == 0) {done = true; break;}
				cmdP++;
				}
			cmdP++;
			}
			
		// Find the end of an unquoted argument
		else {
			while(1) {
				if (*cmdP == 0) {done = true; break;}
				if ((*cmdP == ' ') || (*cmdP == '\t')) {
					*cmdP = 0; 
					break;
					}
				cmdP++;
				}
			cmdP++;
			}
		}
	
	// Return if no arguments
	if (!argc) goto Exit;
		

	//--------------------------------------------------------------------
	// Call the appropriate routine
	//--------------------------------------------------------------------
	
	// Look for the help command
	if (!StrCompare(argv[0], "help") || !StrCompare(argv[0], "?")) {
	
		// If asking about a particular command, get extended help (??)
		if (argc > 1) {
			argv[0] = argv[1];
			argv[1] = "??";
			}
			
		// Else, display 1 line help (?)
		else {
			CharPtr	helpP;
			helpP = "?";
			for (i=0; i<NumCommands; i++) {
				argv[0] = CmdTable[i].nameP;
				argv[1] = helpP;
				(CmdTable[i].procP)(2, argv);
				
				// Pause after every "page"
				if (i > 0 && (i % 8) == 0) {
					printf("<cr> to continue...");
					if (StdGetChar(true) != '\n') break;
					printf("\n");
					}
				}
			printf("\n");
			goto Exit;
			}
		}
		
	// Else, look for this command
	for (i=0; i<NumCommands; i++) {
		if (!StrCompare(argv[0], CmdTable[i].nameP)) {
			(CmdTable[i].procP)(argc, argv);
			goto Exit;
			}
		}
	
	// Not found
	printf("Unknown command: %s\n", argv[0]);
	
Exit:
	if (cmdBufP) MemPtrFree(cmdBufP);
			
}


/***********************************************************************
 *
 * FUNCTION:     AppStart
 *
 * DESCRIPTION:  This routine opens the application's database, loads the 
 *               saved-state information and initializes global variables.
 *
 * PARAMETERS:   nothing
 *
 * RETURNED:     nothing
 *
 ***********************************************************************/
static Word AppStart (void)
{
	Err						err;
	Word prefsSize;

	// get prefs
	prefsSize = sizeof (LFtpPreferenceType);
	if ((PrefGetAppPreferences (kAppCreator, appPrefID, &LFtpPrefs,
		 &prefsSize, true) == noPreferenceFound) ||
		 (prefsSize != sizeof (LFtpPreferenceType)))
	{
		int i;
		for (i=0; i<5; i++)
		{
			LFtpPrefs.LFtpItems[i].UsePrefs=0;
			LFtpPrefs.LFtpItems[i].UseCommands=0;
			StrCopy(LFtpPrefs.LFtpItems[i].Server, "127.0.0.1");
			StrPrintF(LFtpPrefs.LFtpItems[i].Login, "anonymous%d",i+1);
			StrCopy(LFtpPrefs.LFtpItems[i].Password, "anonymous@nowhere.com");
			StrCopy(LFtpPrefs.LFtpItems[i].Cmd, "pwd\npwd\npwd");
		}
		LFtpPrefs.InUse=0;
	}
	
	// Init our terminal functions for printing to the screen
	StdInit(kMainFormID, kMainTextFldID, kMainScrollerID,
					AppExecCommand);
	

	// Get the refNum of the Net Library
	err = SysLibFind("Net.lib", &AppNetRefnum);
	if (err) {
		ErrDisplay("\nNet Library not found, exiting...");
		return err;
		}


	// Add commands from each of the modules
//	CmdInfoInstall();
//	CmdStevensInstall();
	CmdSetupInstall();
	CmdFTPInstall();
//	CmdTelnetInstall();
		
		
	// Set our default Timeout
	AppNetTimeout = 10*sysTicksPerSecond;

	return 0;
}


/***********************************************************************
 *
 * FUNCTION:    AppStop
 *
 * DESCRIPTION: This routine closes the application's database
 *              and saves the current state of the application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 *
 ***********************************************************************/
static void AppStop (void)
{
	// save prefs
	PrefSetAppPreferences (kAppCreator, appPrefID, 
	appPrefVersionNum, &LFtpPrefs, sizeof (LFtpPreferenceType), true);
	
	// Close Net Library, if necessary
	while (AppNeedNetLibClose)
		AppExecCommand("close");


	// Under emulation, force the NetLib out of the close-wait state
	// before we exit.
	#if EMULATION_LEVEL != EMULATION_NONE
		if (AppNetRefnum) 
			NetLibFinishCloseWait(AppNetRefnum);
	#endif
		
}


/***********************************************************************
 *
 * FUNCTION:    AppHandleEvent
 *
 * DESCRIPTION: This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 * PARAMETERS:  event  - a pointer to an EventType structure
 *
 * RETURNED:    true if the event has been handled and should not be passed
 *              to a higher level handler.
 *
 ***********************************************************************/
static Boolean AppHandleEvent (EventPtr event)
{
	Word formID;
	FormPtr frm;

	if (event->eType == frmLoadEvent) {
		// Load the form resource.
		formID = event->data.frmLoad.formID;
		frm = FrmInitForm (formID);
		FrmSetActiveForm (frm);		
		
		// Set the event handler for the form.  The handler of the currently
		// active form is called by FrmHandleEvent each time is receives an
		// event.
		switch (formID) {
			case kMainFormID:
				FrmSetEventHandler (frm, MainViewHandleEvent);
				break;
			case LFtpPrefsForm:
				FrmSetEventHandler (frm, PrefsHandleEvent);
				break;
	
	
			}
		return (true);
		}
	return (false);
}




/***********************************************************************
 *
 * FUNCTION:    AppEventLoop
 *
 * DESCRIPTION: Infinite (almost) loop to process events
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
static void AppEventLoop(void)
{
	Word		 	error;
	EventType 	event;

	do {
		EvtGetEvent (&event, evtWaitForever);
		
		if (! SysHandleEvent (&event))
		
			if (! MenuHandleEvent (CurrentMenuP, &event, &error))
			
				if (! AppHandleEvent (&event))
	
					FrmDispatchEvent (&event); 
					
					
		} while (event.eType != appStopEvent);
}








/***********************************************************************
 *
 * FUNCTION:    PilotMain
 *
 * DESCRIPTION: This is the main entry point for the Pilot
 *              application.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    nothing
 *
 ***********************************************************************/
DWord	PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
	Word error = 0;

	// If normal launch
	if (cmd == sysAppLaunchCmdNormalLaunch) 
	{
		/* can we load the net library? not on 1.0, possibly on 2.0, always on 3.0 */	
		error = NetLibCompatible (0x02000000, launchFlags);
		if (error) return (error);
	
		error = AppStart ();
		if (error)
			return (error);

		FrmGotoForm (kMainFormID);
		AppEventLoop ();
		AppStop ();
		FrmCloseAllForms();
		}

	return 0;
}




/***********************************************************************
 *
 * FUNCTION:    RomVersionCompatible
 *
 * DESCRIPTION: This routine checks that a ROM version meets your
 *              minimum requirement.
 *
 * PARAMETERS:  requiredVersion - minimum rom version required
 *                                (see sysFtrNumROMVersion in SystemMgr.h 
 *                                for format)
 *              launchFlags     - flags that indicate if the application 
 *                                UI is initialized.
 *
 * RETURNED:    error code or zero if rom is compatible
 *                             
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	11/15/96	Initial Revision
 *			pbs   6/9/98   Added check for net.lib
 *
 ***********************************************************************/
static Err NetLibCompatible (DWord requiredVersion, Word launchFlags)
{
	DWord romVersion;
	Word err;
	
	// See if we have at least the minimum required version of the ROM or later.
	FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
	if (romVersion < requiredVersion)
	{
		if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
		(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
		{
			FrmAlert (RomIncompatibleAlert);
		
			// Pilot 1.0 will continuously relaunch this app unless we switch to 
			// another safe one.
			if (romVersion < 0x02000000)
				AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
		}
		
		return (sysErrRomIncompatible);
	}
	else
	{
		// proper version, however, do we have net.lib?
		err = SysLibFind("Net.lib", &AppNetRefnum);
		if (err) 
		{
			if ((launchFlags & (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
			(sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
			{
				FrmAlert (NetLibIncompatibleAlert);
			
				// Pilot 1.0 will continuously relaunch this app unless we switch to 
				// another safe one.
				if (romVersion < 0x02000000)
					AppLaunchWithCommand(sysFileCDefaultApp, sysAppLaunchCmdNormalLaunch, NULL);
			}
		
			return (sysErrRomIncompatible);
		}
	}

	return (0);
}

