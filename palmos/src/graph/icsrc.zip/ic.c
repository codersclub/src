/*
 * Image Compressor
 *      Compress images
 *
 * Ken Shirriff         ken.shirriff@eng.sun.com
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Please refer to the file "license.txt"
 * for further important copyright and licensing information.
 */

#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#include "ic.h"
#define AppType    'KSic'
#define AppDBType   'vIMG'
#define AppVersion  1

#define assert(x) if (!(x)) abort("error")

#if 1
#define abort(msg)      ErrDisplayFileLineMsg(__FILE__, __LINE__, msg)
#else
#define abort(msg)      ErrDisplayFileLineMsg(__FILE__, __LINE__, "")
#endif

#define disp(str) WinDrawChars(str, StrLen(str), 10, 10)

struct datahdr {
  char 	name[32];
  char	version;
  char	type;
  char	reserved[4];
  char	note[4];
  short	x_last;
  short	y_last;
  char	reserved2[4];
  short	x_anchor;
  short	y_anchor;
  short	width;
  short	height;
};

static void StartApplication(void);
static void StopApplication(void);
static void displayMoveCount(void);
static void EventLoop(void);
static Boolean selectEvent(EventPtr event);
static char *getInfo(DmOpenRef dbR, UInt index);
static void *openRecord(LocalID dbID, UInt index);
static void getImageList();
static void closeRecord(void);
static void updateStatus(void);
static Boolean ApplicationHandleEvent(EventPtr e);
static void loadImage(int idx);
static void *getObjectPtr(Word objID);
static void msg(char *str);
static long compress(unsigned char *dst, struct datahdr *hdr, long len);

#define MAXDB 50

// Number of database items
int nitems = 0;
char *items[MAXDB];
LocalID items_ID[MAXDB];
UInt items_rec[MAXDB];

LocalID viewerID = 0;

// Variables for openRecord/closeRecord
DmOpenRef dbR = NULL;
VoidHand hand;

int currentindex = -1;

char linebuf[50];

char *memToFree;

// Main loop
DWord  PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  if (cmd == sysAppLaunchCmdNormalLaunch)
 {
    StartApplication();

    FrmGotoForm(formID_select);

    EventLoop();  // Event loop

    StopApplication();
  }
  return 0;
}

static void StartApplication(void) {
}

static void StopApplication(void) {
  closeRecord();
}

static void EventLoop(void)
{
  short err;
  int formID;
  FormPtr form;
  EventType event;
  static Boolean inmenu = false;

  do
  {

    EvtGetEvent(&event, evtWaitForever);

    if (SysHandleEvent(&event)) continue;
    if (MenuHandleEvent((void *)0, &event, &err)) continue;

    if (event.eType == frmLoadEvent)
    {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) 
      {
      case formID_select:
        FrmSetEventHandler(form, (FormEventHandlerPtr) selectEvent);
        break;
      }
    }

    FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}

// Form for the image selection page
static Boolean selectEvent(EventPtr event)
{
  switch (event->eType) 
  {
  case frmOpenEvent:
    getImageList();
    LstSetSelection(getObjectPtr(listID_data), currentindex);
    FrmDrawForm(FrmGetActiveForm());
    msg("Click a file to compress");
    return true;
    break;
    
  case menuEvent:
    switch (event->data.menu.itemID)
    {
    case menuitemID_about:
      FrmAlert(alertID_about);
      return true;
    }
    break;

  case lstSelectEvent:
    // A click on the list compresses the file
    // Update the state
    if (event->eType == lstSelectEvent) {
      currentindex = event->data.lstSelect.selection;
    }
    // Perform the action
    loadImage(currentindex);
    FrmGotoForm(formID_select);
    msg("");
    break;
  }
  return false;
}

// Get information on the file
static char *getInfo(DmOpenRef dbR, UInt index)
{
  char *ptr;
  struct datahdr *hdr;
  VoidHand hand = DmQueryRecord(dbR, index);
  assert(hand);
  hdr = MemHandleLock(hand);
  MemMove(linebuf, hdr->name, 32);
  linebuf[32]='\0';
  StrCat(linebuf, ", ");
  StrIToA(linebuf+StrLen(linebuf), (MemHandleSize(hand)+512)/1024);
  StrCat(linebuf,"k");
  if (hdr->version==1) {
    StrCat(linebuf, ", compressed");
  }
  MemHandleUnlock(hand);
  ptr = MemPtrNew(StrLen(linebuf)+1);
  StrCopy(ptr, linebuf);
  return ptr;
}

// Helper function
static void *getObjectPtr(Word objID) {
  FormPtr frm = FrmGetActiveForm();
  return FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID));
}

RectangleType msgRect = {30,120,130,12};

// Display a message line
static void msg(char *str) {
  WinEraseRectangle(&msgRect, 0);
  StrCopy(linebuf,str);
  WinDrawChars(linebuf, StrLen(linebuf), 30, 120);
}

// Functions to handle image records

// open the record specified by the database id and record index
static void *openRecord(LocalID dbID, UInt index) {
  closeRecord();
  dbR = DmOpenDatabase(0, dbID, dmModeReadWrite);
  if (dbR==0) {
    FrmCustomAlert(alertID_iv,"Couldn't open database","","");
    return 0;
  }
  assert(dbR != 0);
  hand = DmQueryRecord(dbR, index);
  return hand?MemHandleLock(hand):0;
}

// Close the current record and database if any
static void closeRecord(void) {
  if (dbR != NULL) {
    if (hand != NULL) {
      MemHandleUnlock(hand);
    }
    DmCloseDatabase(dbR);
    dbR = NULL;
    hand = NULL;
  }
}

// Load the image from the database and compress it
static void loadImage(int idx)
{
  struct datahdr *hdr;
  unsigned char *dstptr;
  VoidHand hand2;
  UInt at;
  long len;
  long size;
  char ver;
  hdr = (struct datahdr *)openRecord(items_ID[idx], items_rec[idx]);
  if (hdr==0) {
    FrmCustomAlert(alertID_iv,"Couldn't open","","");
    return;
  }
  if (hdr->version==1) {
    FrmCustomAlert(alertID_iv,"Already compressed","","");
    return;
  }
  msg("Scanning");
  size = (long)hdr->width*(long)hdr->height;
  if (hdr->type == (char)0xff) {
    // b/w
    size >>= 3;
  } else {
    // gray
    size >>= 2;
  }
  len = compress(0, hdr, size);
  assert(len != 0);
  if (len >= size-256) {
    FrmCustomAlert(alertID_iv,"No saving from compressing","","");
    closeRecord();
    return;
  }
  // Create the record
  at = items_rec[idx]+1;
  msg("Allocating");
  hand2 = DmNewRecord(dbR, &at, len+sizeof(struct datahdr));
  if (hand2 == NULL) {
    FrmCustomAlert(alertID_iv,"Not enough memory","","");
    closeRecord();
    return;
  }
  dstptr = MemHandleLock(hand2);
  // Compress the file
  // Copy header, changing version to 1
  DmWrite(dstptr, 0, hdr, sizeof(struct datahdr));
  ver = 1;
  DmWrite(dstptr, 32, &ver, 1);
  msg("Compressing");
  compress(dstptr, hdr, size);
  msg("Done");
  MemHandleUnlock(hand2);
  // Delete the old record
  msg("Deleting old");
  MemHandleUnlock(hand);
  hand = NULL;
  DmRemoveRecord(dbR, items_rec[idx]);
  msg("Closing");
  closeRecord();
}

#define NONE 2
#define RUN 0		// RLE-sequence
#define LIT 1		// Literal sequence

struct {
  int len;		// # of chars in sequence
  int chr;		// current run char
  long offset;		// output offset
  int mode;		// NONE, RUN, or LIT
  char b;		// lit count
  char buf[128];	// lit buf
  unsigned char *dst;	// output record
} rle;

static void reset() {
  rle.len = 0;
  rle.chr = -1;
  rle.mode = NONE;
}

long a=0,b=0;

static void write_run(void)
{
  char buf[2];
  buf[0] = 0x80+rle.len-1;
  buf[1] = rle.chr;
  assert(rle.len>=1 && rle.len<=128);
  if (rle.dst) {
    DmWrite(rle.dst, sizeof(struct datahdr)+rle.offset, buf, 2);
  }
  rle.offset += 2;
  a += rle.len;
  reset();
}

static void write_lit(void)
{
  assert(rle.len>=1 && rle.len<=128);
  rle.buf[-1] = rle.len-1;
  if (rle.dst) {
    DmWrite(rle.dst, sizeof(struct datahdr)+rle.offset, rle.buf-1, rle.len+1);
  }
  rle.offset += rle.len+1;
  b += rle.len;
  reset();
}

static long compress(unsigned char *dst, struct datahdr *hdr, long size)
{
  unsigned char *src = (unsigned char *)(hdr+1);
  long i;
  rle.len = 0;
  rle.chr = -1;
  rle.mode = LIT;
  rle.offset = 0;
  rle.dst = dst;
  a=0;
  b=0;
  for (i=0; i<size; i++) {
    assert(a+b+rle.len==i);
    if (src[i]==rle.chr) {
      if (rle.mode==LIT && rle.len>1) {
	rle.len--;
	write_lit();
        assert(a+b+rle.len==i-1);
	rle.len = 1;
	rle.chr = src[i];
        assert(a+b+rle.len==i);
      }
      rle.mode = RUN;
      assert(a+b+rle.len==i);
      rle.len++;
      assert(rle.len>0);
      assert(a+b+rle.len==i+1);
    } else {
      if (rle.mode==RUN) {
	write_run();
      }
      rle.mode = LIT;
      rle.chr = src[i];
      rle.buf[rle.len] = rle.chr;
      rle.len++;
      assert(rle.len>0);
      assert(a+b+rle.len==i+1);
    }
    assert(a+b+rle.len==i+1);
    assert(rle.mode != NONE);
    assert(rle.len<129);
    if (rle.len==128) {
      if (rle.mode==RUN) {
	write_run();
      } else {
	write_lit();
      }
    assert(a+b+rle.len==i+1);
    }
    assert(rle.len>0 || rle.offset>0);
  }
  assert(rle.len>0 || rle.offset>0);

  if (rle.len>0) {
    if (rle.mode==RUN) {
      write_run();
    } else {
      write_lit();
    }
  }
  assert(rle.offset>0);
  return rle.offset;
}

// Look up the images in the databases
static void getImageList()
{
  DmSearchStateType state;
  Boolean newSearch = 1;
  UInt idx;
  UInt cardNo;
  LocalID dbID;
  Err err;
  DmOpenRef ref;
  VoidHand hand;
  char *p;
  int i;
  LocalID id;
  ListPtr listp;
  VoidHand resH;
  char *ptr;

  for (i=0;i<nitems;i++) {
    MemPtrFree(items[i]);
  }
  nitems = 0;

  for (nitems=0;nitems<MAXDB;nitems++) {
    // Check for images stored as vIMG
    err = DmGetNextDatabaseByTypeCreator(newSearch, &state, 'vIMG',
      NULL, false, &cardNo, &dbID);
    if (err == dmErrCantFind) {
      break;
    }
    newSearch = 0;
    err = DmDatabaseInfo(cardNo, dbID, linebuf, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL);
    dbR = DmOpenDatabase(0, dbID, dmModeReadOnly);
    assert(dbR != 0);
    items_ID[nitems] = dbID;
    items_rec[nitems] = 0;
    items[nitems] = getInfo(dbR, 0);
    DmCloseDatabase(dbR);
    dbR = NULL;
  }
  newSearch = 1;
  // Check for images that ImageViewer has moved to vIDB
  err = DmGetNextDatabaseByTypeCreator(newSearch, &state, 'vIDB',
    NULL, false, &cardNo, &dbID);
  if (err == 0) {
    i = 0;
    viewerID = dbID;
    dbR = DmOpenDatabase(0, dbID, dmModeReadOnly);
    assert(dbR != 0);
    for (i=0;i<DmNumRecords(dbR) && nitems<MAXDB; i++, nitems++) {
      char *p;
      items_ID[nitems] = dbID;
      items_rec[nitems] = i;
      items[nitems] = getInfo(dbR, i);
    }
    DmCloseDatabase(dbR);
    hand = NULL;
    dbR = NULL;
  }

  // Display the list
  listp = (ListPtr) getObjectPtr(listID_data);
  LstSetListChoices(listp, items, nitems);
  LstSetHeight(listp, nitems>8?8:nitems);
}
