#include "diddlebug.h"
#include "diddlebugRsc.h"
#include "callback.h"
#include "util.h"
#include "booger.h"
#include "linker.h"

/* diddlebug.c */
extern void GetFormattedDate(DateTimeType *date, CharPtr string, Boolean wc);
extern void DoCmdRemove(void);
extern void FlushToBuffer(void);
extern void LabelAlarm_(void);

/* globals */
extern pref p;
extern data d;

/*
** ToggleObject
*/
static void ToggleObject(FormPtr frm, Word objID, Boolean toggle_on) {
    if (toggle_on) FrmShowObject(frm, FrmGetObjectIndex(frm, objID));
    else FrmHideObject(frm, FrmGetObjectIndex(frm, objID));
    return;
}

/*
** DrawBitmap
*/
static void DrawBitmap(UInt bitmapID, SWord x, SWord y) {
    VoidHand bitmapH;

    bitmapH = DmGetResource('Tbmp', bitmapID);
    WinDrawBitmap(MemHandleLock(bitmapH), x, y);
    MemHandleUnlock(bitmapH);
    DmReleaseResource(bitmapH);
}

/*
** GetCurrentXferAppListIndex - returns -1 for no current app
*/
static short GetCurrentXferAppListIndex(void) {
    short ret, i;
    SysDBListItemType *pluglistP;
    Word appcount;

    ret = -1;
    if (!d.xfer.pluglistH) {
        d.xfer.num_plugs = 0;
        return ret;
    }
    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    for (i=0; i<d.xfer.num_plugs; i++) {
        /* Search for the currently selected plugin */
        if ((pluglistP[i].creator == p.xfer_current_plug) &&
                    (pluglistP[i].version&(IBVERSION_ORIG|IBVERSION_PICTURE))) {
            ret = i;
        }
    }
    if (-1 == ret) p.xfer_current_plug = 0;
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
    return ret;
}

/*
** PlugIndex - convert between absolute and versioned indexes
*/
static short PlugIndex(short index, Boolean atov) {
    SysDBListItemType *pluglistP;
    short a_index, v_index, ret;

    if (!d.xfer.pluglistH) return 0;
    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    v_index = 0;
    ret = 0;
    for (a_index=0; a_index<d.xfer.num_plugs; a_index++) {
        if ((pluglistP[a_index].version)&(IBVERSION_ORIG|IBVERSION_PICTURE)) {
            if (atov && index == a_index) ret = v_index;
            if (!atov && index == v_index) ret = a_index;
            v_index++;
        }
    }
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
    if (index == NULL && atov) ret = v_index;
    return ret;
}

/*
** GetPlugString
*/
static void GetPlugString(short plugindex, UInt rscID, CharPtr chrP) {
    DmOpenRef dbR;
    VoidHand nilH;
    SysDBListItemType *pluglistP;

    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    dbR = 0;
    dbR = DmOpenDatabase(pluglistP[plugindex].cardNo,
                    pluglistP[plugindex].dbID, dmModeReadOnly);
    if (!dbR) abort();
    nilH = NULL;
    nilH = DmGet1Resource('BooG', rscID);
    if (!nilH) {
        StrCopy(chrP, "");
    }
    else {
        StrNCopy(chrP, MemHandleLock(nilH), 48);
        MemHandleUnlock(nilH);
    }
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
    DmCloseDatabase(dbR);
}

/*
** DrawPlugBitmap
*/
static void DrawPlugBitmap(short plugindex, UInt rscID, SWord x, SWord y) {
    DmOpenRef dbR;
    VoidHand bitmapH;
    SysDBListItemType *pluglistP;

    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    dbR = 0;
    dbR = DmOpenDatabase(pluglistP[plugindex].cardNo,
                    pluglistP[plugindex].dbID, dmModeReadOnly);
    if (!dbR) abort();
    bitmapH = NULL;
    bitmapH = DmGet1Resource('BooG', rscID);
    if (!bitmapH) abort();
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
    WinDrawBitmap(MemHandleLock(bitmapH), x, y);
    MemHandleUnlock(bitmapH);
    DmReleaseResource(bitmapH);
    DmCloseDatabase(dbR);
}

/*
** DrawXferDoneButton
*/
static void DrawXferDoneButton(FormPtr frm, Boolean toggle_on) {
    RectangleType rect;
    Int bitmapID;

    RctSetRectangle(&rect, 0, 146, 16, 14);
    if (!toggle_on) {
        WinEraseRectangle(&rect, 0);
        return;
    }

    if (((p.flags&PFLAGS_XFER_GOTO) || xferGotoIsAlways) && !(xferGotoIsNever))
        bitmapID = XferDoneGotoBitmap;
    else
        bitmapID = XferDoneBitmap;
    DrawBitmap(bitmapID, 0, 146);
    if (p.flags&PFLAGS_XFER_DELETE) {
        WinEraseLine(rect.topLeft.x+12, rect.topLeft.y+2, rect.topLeft.x+12,
                        rect.topLeft.y+10);
    }
    if ((d.xfer.complete || xferCompleteIsAlways) && !(xferCompleteIsNever))
        WinEraseLine(rect.topLeft.x+10, rect.topLeft.y+7, rect.topLeft.x+15,
                        rect.topLeft.y+7);
    if (d.linker_available && p.flags&PFLAGS_XFER_BACKLINK) {
        WinEraseLine(rect.topLeft.x+9, rect.topLeft.y+2, rect.topLeft.x+9,
                        rect.topLeft.y+10);
    }
}

/*
** DrawPlugButton
*/
void DrawPlugButton(FormPtr frm, Boolean toggle_on) {
    Char str[48], str2[48];
    RectangleType rect;
    short i;

    FrmGetObjectBounds(frm, FrmGetObjectIndex(frm, XferDetailsButton), &rect);
    if (!toggle_on) {
        WinEraseRectangle(&rect, 0);
        return;
    }
    if (d.xfer.pluglistH && (-1 != (i=GetCurrentXferAppListIndex()))) {
        DrawPlugBitmap(i, boogerID_button, rect.topLeft.x, rect.topLeft.y);
        GetPlugString(i, boogerID_gotobehavior, str);
        GetPlugString(i, boogerID_completebehavior, str2);
        if (StrChr(str, 'n')) xferGotoSetNever();
        else if (StrChr(str, 'a')) xferGotoSetAlways();
        else xferGotoClear();
        /* Completion is never by default (yet) */
        if (StrChr(str2, 'a')) xferCompleteSetAlways();
        else if (StrChr(str2, 'o')) xferCompleteClear();
        else xferCompleteSetNever();
    }
    else {
        DrawBitmap(XferNoAppBitmap, rect.topLeft.x, rect.topLeft.y);
        xferGotoClear();
        xferCompleteClear();
    }

}

/*
** ToggleButtonBar - disable or enable the objects in the button bar
*/
void ToggleButtonBar(FormPtr frm, Boolean toggle_on) {
    UInt i, skip1, skip2, skip3, skip4;


    if (recordIsLocked) {
        skip1 = MainClearButton; skip2 = MainDeleteButton;
        skip3 = ClearBitmap; skip4 = DeleteBitmap;
    }
    else {
        skip1 = skip2 = MainLockButton;
        skip3 = skip4 = LockBitmap;
    }
    for (i=BUTTONBAR_START; i<=BUTTONBAR_END; i++) {
        if (toggle_on && (skip1 == i || skip2 == i)) continue;
        ToggleObject(frm, i, toggle_on);
    }
    for (i=BUTTONBAR_BM_START; i<=BUTTONBAR_BM_END; i++) {
        if (toggle_on && (skip3 == i || skip4 == i)) continue;
        ToggleObject(frm, i, toggle_on);
    }
    if (!toggle_on) WinEraseRectangle(&d.bottom_bar_rect, 0);
}

/*
** ToggleXferBar - disable or enable the objects in the transfer bar
*/
void ToggleXferBar(FormPtr frm, Boolean toggle_on) {

    ToggleObject(frm, XferDetailsButton, toggle_on);
    ToggleObject(frm, XferField, toggle_on);
    DrawPlugButton(frm, toggle_on);
    DrawXferDoneButton(frm, toggle_on);

    /* Set the insertion point in the field if toggling on */
    if(toggle_on) FrmSetFocus(frm, FrmGetObjectIndex(frm, XferField));
    else {
        FldFreeMemory(GETOBJECTPOINTER(frm, XferField));
        WinEraseRectangle(&d.bottom_bar_rect, 0);
    }
}

/*
** WeekdayBits - get weekday bits for a given day
*/
unsigned char WeekdayBits() {
    DateType date;
    unsigned char ret;
    ULong secs;

    if (recordIsAlarmSet) secs = d.record.alarmSecs;
    else secs = TimGetSeconds();

    DateSecondsToDate(secs, &date);
    switch (DayOfWeek(date.month, date.day, date.year+firstYear)) {
        case 0: ret = REPEATBITS_SUN; break;
        case 1: ret = REPEATBITS_MON; break;
        case 2: ret = REPEATBITS_TUE; break;
        case 3: ret = REPEATBITS_WED; break;
        case 4: ret = REPEATBITS_THU; break;
        case 5: ret = REPEATBITS_FRI; break;
        case 6:
        default: ret = REPEATBITS_SAT; break;
    }
    return ret;
}

/*
** InitXferList - initializes the transfer group structures
*/
void InitXferList(void) {
    SysDBListItemType *pluglistP;
    DmOpenRef dbR;
    SWord width, n;
    Char str[48];
    short num_versioned_plugs;
    UInt i;

    /* return if we've already initialized the plugin list */
    if (d.xfer.pluglistH) return;

    if (!SysCreateDataBaseList('BooG', 0, &d.xfer.num_plugs,
                            &d.xfer.pluglistH, true)) {
        /* No databases found */
        d.xfer.pluglistH = NULL;
        d.xfer.num_plugs = 0;
        return;
    }

    /* This will unset the p.xfer_current_plug if it has been deleted */
    GetCurrentXferAppListIndex();

    /* Find the menu width and set it */
    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    width = 0;
    for (i=0; i<d.xfer.num_plugs; i++) {
        GetPlugString(i, boogerID_plugname, str);
        n = FntCharsWidth(str, StrLen(str));
        if ((pluglistP[i].version)&(IBVERSION_ORIG|IBVERSION_PICTURE))
            width = (width < n ? n : width);
    }
    d.xfer.plug_menu_width = width+25;
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
}

/*
** FreeXferList - frees the transfer group structures recursively
*/
void FreeXferList() {
}

/*
** XferListDrawFunc
*/
void XferListDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    UInt absolute_item;
    Char str[48];

    CALLBACK_PROLOGUE
    
    absolute_item = PlugIndex(item, false);
    DrawPlugBitmap(absolute_item, boogerID_lilbutton, b->topLeft.x,
                    b->topLeft.y+1);
    GetPlugString(absolute_item, boogerID_plugname, str);
    WinDrawChars(str, StrLen(str), b->topLeft.x+19, b->topLeft.y);

    CALLBACK_EPILOGUE
}

/*
** DoXferList - Popup the transfer details list
*/
void DoXferList(void) {
    FormPtr frm;
    ListPtr list;
    UInt num_plugs;
    RectangleType rect;
    short list_selection;
    SysDBListItemType *pluglistP;


    num_plugs = PlugIndex(NULL, true);
    if (!d.xfer.pluglistH || !num_plugs) {
        FrmAlert(NoPluginInstalled);
    }
    else {
        frm = FrmGetActiveForm();
        list = GETOBJECTPOINTER(frm, XferList);
        LstSetDrawFunction(list, XferListDrawFunc);
        LstSetListChoices(list, NULL, num_plugs);
        LstSetHeight(list, num_plugs < 10 ? num_plugs : 10);
        FrmGetObjectBounds(frm,
                        FrmGetObjectIndex(frm, XferList), &rect);
        rect.topLeft.x = 16;
        rect.topLeft.y = 144-rect.extent.y;
        rect.extent.x = d.xfer.plug_menu_width;
        FrmSetObjectBounds(frm,
                        FrmGetObjectIndex(frm, XferList), &rect);
        LstSetSelection(list, GetCurrentXferAppListIndex());
        list_selection = LstPopupList(list);
        if (-1 != list_selection) {
            pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
            p.xfer_current_plug =
                    pluglistP[PlugIndex(list_selection, false)].creator;
            MemHandleUnlock((VoidHand)d.xfer.pluglistH);
            DrawPlugButton(frm, true);
            DrawXferDoneButton(frm, true);
        }
    }
}

/*
** StartXferMode - initiates transfer mode
*/
void StartXferMode(void) {
    FormPtr frm;

    FlushToBuffer();
    frm = FrmGetActiveForm();
    FrmSetMenu(frm, XferMenu);
    d.is_xfer_mode = true;
    ToggleButtonBar(frm, false);
    InitXferList();
    ToggleXferBar(frm, true);
}

/*
** CancelXferMode - cancels the transfer mode of operation
*/
void CancelXferMode(void) {
    FormPtr frm;

    frm = FrmGetActiveForm();
    FrmSetMenu(frm, DiddleMenu);
    d.is_xfer_mode = false;
    d.drawmode = MODE_DOODLE;
    FreeXferList();
    ToggleXferBar(frm, false);
    ToggleButtonBar(frm, true);
    LabelAlarm_();
}

/*
** GetLink - Add the Linker link to the plugin text
**           Calling function must free the returned pointer
*/
CharPtr GetLink(CharPtr orig_text) {
    UInt length;
    CharPtr linked_text;
    LinkerCPB command_block;
    ULong result;

    if (!orig_text) return 0;
    length = StrLen(orig_text)+1;
    if (p.flags&PFLAGS_XFER_BACKLINK && d.linker_available) length += 5;
    linked_text = MemPtrNew(length);
    StrCopy(linked_text, orig_text);
    if (!(p.flags&PFLAGS_XFER_BACKLINK && d.linker_available))
            return linked_text;

    MemSet(&command_block, sizeof(LinkerCPB), 0);
    command_block.creator = 'Linx'; /* maybe this is overkill, but .... */
    command_block.message = LinkerNewLinkMessage;
    /* command_block.linkTag is empty and to be filled by Linker */
    command_block.gotoTargetAppCreator = 'DIDB'; /* DiddleBug is the target */
    DmOpenDatabaseInfo(d.dbR, &(command_block.gotoLinkParams.dbID), NULL, NULL,
                    &(command_block.gotoLinkParams.dbCardNo), NULL);
    command_block.gotoLinkParams.recordNum = p.dbI;

    /* Signal Linker */
    SysAppLaunch(d.CardNo, d.DBID, 0, linkerAppLaunchCmdSignalLinker,
                                        (Ptr)&command_block, &result);

    /* Add the link text */
    command_block.linkTag[5] = 0x00; /* just to be sure */
    StrCat(linked_text, command_block.linkTag);

    return linked_text;
}

/*
** FinishXferMode_ - internal to xfer.o
*/
static void FinishXferMode_(void) {
    KleenexType kleenex;
    RepeatInfoType repeat;
    FormPtr frm;
    SysDBListItemType *pluglistP;
    short current_plug;
    DWord result;
    Boolean is_goto;
    Word err;

    /* Zero the kleenex */
    MemSet(&kleenex, sizeof(KleenexType), 0);

    /* Bail if no plugins installed */
    if (!d.xfer.pluglistH) {
        FrmAlert(NoPluginInstalled);
        return;
    }

    /* Lock the plugin list */
    pluglistP = MemHandleLock((VoidHand)d.xfer.pluglistH);
    current_plug = GetCurrentXferAppListIndex();
    if (current_plug == -1) {
        FrmAlert(NoPluginSelected);
        MemHandleUnlock((VoidHand)d.xfer.pluglistH);
        return;
    }

    /* Set the version */
    if (pluglistP[current_plug].version&IBVERSION_PICTURE)
        kleenex.version = IBVERSION_PICTURE;
    else if (pluglistP[current_plug].version&IBVERSION_ORIG)
        kleenex.version = IBVERSION_ORIG;
    else
        abort();
    
    /* Set the current record index */
    kleenex.sketchRecordNum = p.dbI;

    /* Set the pick text */
    frm = FrmGetActiveForm();
    kleenex.text = GetLink(FldGetTextPtr(GETOBJECTPOINTER(frm, XferField)));
    if (!kleenex.text) {
        FlashWaitMessage(XferNoTextString);
        MemHandleUnlock((VoidHand)d.xfer.pluglistH);
        return;
    }

    /* Set the title text */
    kleenex.title = NULL; /* to be implemented */

    /* Set the category text */
    kleenex.category = NULL; /* to be implemented */

    /* Set the seconds for the alarm */
    if (recordIsAlarmSet) kleenex.alarm_secs = d.record.alarmSecs;

    /* Set the repeat information */
    repeat.repeatType = repeatNone;
    DateToInt(repeat.repeatEndDate) = -1; /* apptNoEndDate */
    repeat.repeatFrequency = 1;
    kleenex.repeat = &repeat;
    switch (d.record.repeatMode) {
        case REPEAT_DAILY:
            repeat.repeatType = repeatDaily;
            break;
        case REPEAT_WEEKDAYS:
            repeat.repeatType = repeatWeekly;
            repeat.repeatOn = REPEATBITS_WEEKDAYS;
            break;
        case REPEAT_BIWEEKLY:
            repeat.repeatFrequency = 2;
            /* fall thru */
        case REPEAT_WEEKLY:
            repeat.repeatType = repeatWeekly;
            repeat.repeatOn = WeekdayBits();
            break;
        case REPEAT_NONE:
        case REPEAT_HOURLY:
        default:
            kleenex.repeat = NULL;
            break;
    }

    /* Set the priority */
    kleenex.priority = 1;

    /* Set the completion flag */
    if ((d.xfer.complete || (xferCompleteIsAlways)) &&
                    !(xferCompleteIsNever)) kleenex.is_complete = 1;
    else kleenex.is_complete = 0;

    /* Load the sketch data */
    if (kleenex.version&IBVERSION_PICTURE) {
        kleenex.data = WinGetWindowPointer(d.winbufM)->displayAddr;
        kleenex.data_size = 3200;
    }

    /* Call the plugin */
    err = SysAppLaunch(pluglistP[current_plug].cardNo,
                    pluglistP[current_plug].dbID, sysAppLaunchFlagSubCall,
                    boogerPlugLaunchCmdBlowNose, (VoidPtr)&kleenex, &result);
    MemHandleUnlock((VoidHand)d.xfer.pluglistH);
    MemPtrFree(kleenex.text);
    if (err || result) {
        FrmAlert(PluginError);
        return;
    }

    /* Just to save some typing */
    is_goto = (((p.flags&PFLAGS_XFER_GOTO) || (xferGotoIsAlways)) &&
                    !(xferGotoIsNever));

    if (!is_goto) {
        FlashWaitMessage(XferSavingString);
    }

    /* Delete the sketch if selected */
    if (p.flags&PFLAGS_XFER_DELETE) {
        DoCmdRemove();
    }

    /* Goto the new sketch if required */
    if (is_goto) {
        err = SysUIAppSwitch(kleenex.booger.cardNo, kleenex.booger.dbID,
                        kleenex.booger.cmd, kleenex.booger.cmdPBP);
        if (err && kleenex.booger.cmdPBP) MemPtrFree(kleenex.booger.cmdPBP);
    }
    else {
        if (kleenex.booger.cmdPBP) MemPtrFree(kleenex.booger.cmdPBP);
    }

    CancelXferMode();
}

/*
** FinishXferMode
*/
void FinishXferMode(void) {
    FinishXferMode_();
}

/*
** TrackXferDone
*/
#define TRACKXFERDONE_CHECKED 0x01
#define TRACKXFERDONE_NEVER   0x02
#define TRACKXFERDONE_ALWAYS  0x04
static void TrackXferDone() {
    RectangleType bounds[5], frame;
    Boolean penDown, on_button;
    SWord x, y, i, state, clicked_on;
    SWord temp_top, temp_width, total_height;
    FontID old_font;
    Char xfer_options_strings[4][24];
    SWord xfer_status[4];
    WinHandle offscreenH;
    FormPtr frm;
    Word err;

    /* This should match the XferDoneButton bounds */
    RctSetRectangle(&bounds[0], 0, 146, 16, 14);
    /* Invert the done button */
    state = 1;
    WinInvertRectangle(&bounds[0], 0);
    SndPlaySystemSound(sndClick);

    /* Set the status of each menu pick */
    for (i=0; i<4; i++) { xfer_status[i] = 0x00; }
    if (xferGotoIsAlways) xfer_status[0] = TRACKXFERDONE_ALWAYS;
    else if (xferGotoIsNever) xfer_status[0] = TRACKXFERDONE_NEVER;
    else if (p.flags&PFLAGS_XFER_GOTO) xfer_status[0] = TRACKXFERDONE_CHECKED;
    if (xferCompleteIsAlways) xfer_status[1] = TRACKXFERDONE_ALWAYS;
    else if (xferCompleteIsNever) xfer_status[1] = TRACKXFERDONE_NEVER;
    else if (d.xfer.complete) xfer_status[1] = TRACKXFERDONE_CHECKED;
    if (!d.linker_available) xfer_status[2] = TRACKXFERDONE_NEVER;
    else if (p.flags&PFLAGS_XFER_BACKLINK)
            xfer_status[2] = TRACKXFERDONE_CHECKED;
    if (p.flags&PFLAGS_XFER_DELETE) xfer_status[3] = TRACKXFERDONE_CHECKED;

    /* Size the window for the text */
    old_font = FntSetFont(stdFont);
    temp_top = 144;
    temp_width = 0;
    total_height = 0;
    for (i=0; i<4; i++) {
        SysCopyStringResource(xfer_options_strings[i],
                        XferMenuOptionsStrings+i);
        bounds[i+1].extent.x = FntCharsWidth(xfer_options_strings[i],
                            StrLen(xfer_options_strings[i]));
        if (bounds[i+1].extent.x > temp_width)
                temp_width = bounds[i+1].extent.x;
        if (xfer_status[i]&TRACKXFERDONE_NEVER) bounds[i+1].extent.y = 0;
        else bounds[i+1].extent.y = FntCharHeight();
        total_height += bounds[i+1].extent.y;
        bounds[i+1].topLeft.x = 1;
        temp_top -= bounds[i+1].extent.y;
        bounds[i+1].topLeft.y = temp_top;
    }
    temp_width += 23;  /* padding */

    /* Save the bits of the whole menu */
    RctSetRectangle(&frame, 0, bounds[4].topLeft.y-1, temp_width+3,
                    total_height+3);
    offscreenH = WinSaveBits(&frame, &err);
    /* Erase the rectangle*/
    WinEraseRectangle(&frame, 0);
    /* Draw the frame */
    frame.topLeft.x++; frame.topLeft.y++;
    frame.extent.x -= 3; frame.extent.y -= 3;
    WinDrawRectangleFrame(popupFrame, &frame);
    frame.topLeft.x--; frame.topLeft.y--;
    frame.extent.x += 3; frame.extent.y += 3;

    /* Draw the bitmaps and text */
    for (i=0; i<4; i++) {
        bounds[i+1].extent.x = temp_width; /* use the longest string */
        if (xfer_status[i]&TRACKXFERDONE_ALWAYS) {
            DrawBitmap(DiamondBitmap, bounds[i+1].topLeft.x,
                            bounds[i+1].topLeft.y+1);
        }
        else if (xfer_status[i]&TRACKXFERDONE_CHECKED) {
            DrawBitmap(CheckBitmap, bounds[i+1].topLeft.x,
                            bounds[i+1].topLeft.y+1);
        }
        if (!(xfer_status[i]&TRACKXFERDONE_NEVER)) {
            WinDrawChars(xfer_options_strings[i],
                            StrLen(xfer_options_strings[i]),
                            bounds[i+1].topLeft.x+19,
                            bounds[i+1].topLeft.y);
        }
    }

    do {
        EvtGetPen(&x, &y, &penDown);
        if (!state || !rctPtInRectangle(x, y, &bounds[state-1])) {
            on_button = false;
            for (i=1; i<=5; i++) {
                if ((state != i) && rctPtInRectangle(x, y, &bounds[i-1])) {
                    /* un-invert the old state */
                    if (state) WinInvertRectangle(&bounds[state-1], 0);
                    /* invert the new state */
                    WinInvertRectangle(&bounds[i-1], 0);
                    state = i;
                    on_button = true;
                }
            }
            if (state && !on_button) {
                /* Moved off the current button */
                WinInvertRectangle(&bounds[state-1], 0);
                state = 0;
            }
        }
    } while (penDown);
    /* Restore the framed rect */
    WinRestoreBits(offscreenH, frame.topLeft.x, frame.topLeft.y);
    /* Restore the inversion */
    if (state == 1) WinInvertRectangle(&bounds[0], 0);
    /* Reset the font */
    FntSetFont(old_font);

    /* Finish up if we just tapped the button */
    if (rctPtInRectangle(x, y, &bounds[0])) {
        FinishXferMode_();
        return;
    }

    /* Change the setting for goto or delete */
    frm = FrmGetActiveForm();
    clicked_on = 0;
    for (i=1; i<5; i++) {
        if (rctPtInRectangle(x, y, &bounds[i])) {
            clicked_on = i;
            break;
        }
    }
    switch (clicked_on) {
        case 1: /* Goto */
            if (xfer_status[0]&TRACKXFERDONE_CHECKED)
                    p.flags &= ~PFLAGS_XFER_GOTO;
            else if (!xfer_status[0]) p.flags |= PFLAGS_XFER_GOTO;
            break;
        case 2: /* Complete */
            if (xfer_status[1]&TRACKXFERDONE_CHECKED) d.xfer.complete = false;
            else if (!xfer_status[1]) d.xfer.complete = true;
            break;
        case 3: /* BackLink */
            if (xfer_status[2]&TRACKXFERDONE_CHECKED)
                    p.flags &= ~PFLAGS_XFER_BACKLINK;
            else if (!xfer_status[2]) {
                p.flags |= PFLAGS_XFER_BACKLINK;
                p.flags &= ~PFLAGS_XFER_DELETE; /* No delete if backlink */
            }
            break;
        case 4: /* Delete */
            if (xfer_status[3]&TRACKXFERDONE_CHECKED)
                    p.flags &= ~PFLAGS_XFER_DELETE;
            else if (!xfer_status[3]) {
                p.flags |= PFLAGS_XFER_DELETE;
                p.flags &= ~PFLAGS_XFER_BACKLINK; /* No backlink if delete */
            }
            break;
    }

    /* Click and redraw the button */
    if (clicked_on) {
        DrawXferDoneButton(frm, true);
        if (xfer_status[clicked_on-1]&TRACKXFERDONE_ALWAYS)
            SndPlaySystemSound(sndWarning);
        else SndPlaySystemSound(sndClick);
    }

}

/*
** XferPenDown - track pen and do the appropriate thing
*/
Boolean XferPenDown(EventPtr e) {
    Boolean handled = false;
    RectangleType bounds;

    /* This should match the XferDoneButton bounds */
    RctSetRectangle(&bounds, 0, 146, 16, 14);
    if (rctPtInRectangle(e->screenX, e->screenY, &d.screen_above_bar)) {                /* This cancels the xfer mode */
        SndPlaySystemSound(sndWarning);
        CancelXferMode();
        handled = true;
    }
    else if (rctPtInRectangle(e->screenX, e->screenY, &bounds)) {
        TrackXferDone();
        handled = true;
    }

    return handled;
}
