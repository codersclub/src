#ifndef __BOOGER_H_
#define __BOOGER_H_

/* booger.h  version 'a' */
#include <Pilot.h>

/* Launch command to activate a booger plugin */
#define boogerPlugLaunchCmdBlowNose 0x9101

/* Error codes */
#define boogerErrorVersionMismatch 7000

// Booger resources
#define boogerID_button         6501
#define boogerID_lilbutton      6502
#define boogerID_plugname       6503
#define boogerID_gotobehavior   6504
#define boogerID_completebehavior 6505

// Version identifiers
#define IBVERSION_ORIG          0x0001
#define IBVERSION_PICTURE       0x0002

/* Structure for the BoogerType returned to DiddleBug */
typedef struct {
    UInt cardNo;            /* cardNo */
    LocalID dbID;           /* dbID */
    Word cmd;               /* Launch flags */
    Ptr cmdPBP;             /* usually a GoTo params */
} BoogerType;
typedef BoogerType *BoogerPtr;

/* Repeat types */
enum repeatTypes {
    repeatNone,
    repeatDaily,
    repeatWeekly,
    repeatMonthlyByDay,
    repeatMonthlyByDate,
    repeatYearly
};
typedef enum repeatTypes RepeatType;

/* Repeat info type (same as DateBook) */
typedef struct {
    RepeatType repeatType;            /* daily, weekly, monthlyByDay, etc. */
    DateType repeatEndDate;           /* minus one if forever */
    unsigned char repeatFrequency;    /* i.e. every 2 days */
    unsigned char repeatOn;           /* monthlyByDay and repeatWeekly only */
    unsigned char repeatStartOfWeek;  /* repeatWeekly only */
} RepeatInfoType;
typedef RepeatInfoType *RepeatInfoPtr;

/* Structure for cmdPBP of boogerPlugLaunchCmdBlowNose */
/* DiddleBug is responsible for freeing the pointers upon return */
typedef struct {
    DWord reserved1;
    Word reserved2;
    UInt sketchRecordNum;   /* record number of the sketch */
    UInt version;           /* version of this launch param */
    UInt data_size;         /* not implemented yet... */
    VoidPtr data;           /* Will eventually hold sketch data */
    CharPtr text;           /* Text as typed in the pick field */
    CharPtr title;          /* Title of the drawing (if any) */
    CharPtr category;       /* Category to use (if any) */
    ULong alarm_secs;       /* Alarm seconds (zero if no alarm) */
    RepeatInfoPtr repeat;   /* Repeat info (in DateBook format) */
    SWord priority;         /* Reminder priority (default = 1) */
    BoogerType booger;      /* Filled by the BPlug to be read by DiddleBug */
    SWord is_complete;      /* complete flag */
} KleenexType;
typedef KleenexType *KleenexPtr;

#endif /* __BOOGER_H_ */
