#include <IMCUtils.h>
#include <ExgMgr.h>
#include <CharAttr.h>

#include "datedb.h"
#include "DateAlarm.h"
#include "DateDisplay.h"
#include "DatePref.h"
#include "DateWeek.h"
#include "DateMonth.h"
#include "DateTransfer.h"
#include "DatebookRsc.h"


/***********************************************************************
 *
 *	Constants
 *
 ***********************************************************************/
#define noRecordSelected				-1
#define maxDescSize						256

// Length of verious  
#define maxFrequenceFieldLen			3
#define defaultRepeatDecsLen			32
#define maxAdvanceFieldLen				3


#define datebookDBType					'DATA'

// Feature numbers used by the datebook
#define alarmsFeatureNum				0		// List of pending alarms

#define datebookVersionNum				3
#define datebookPrefsVersionNum		3
#define datebookPrefID					0x00
#define datebookDBName					"DatebookDB"

// Column in the to do table on the day view.
#define timeBarColumn					0
#define timeColumn						1
#define descColumn						2

#define spaceAfterTimeBarColumn		0
#define spaceAfterTimeColumn			2

#define newEventSize  					16
#define maxNoteTitleLen					40

// Update codes, used to determine how the to do day view should 
// be redrawn.
#define updateRedrawAll					0x00
#define updateItemDelete				0x01
#define updateItemHide					0x02
#define updateDateChanged				0x04
#define updateTimeChanged				0x08
#define updateException					0x10
#define updateRepeatChanged			0x20
#define updateDisplayOptsChanged		0x40
#define updateAlarmChanged				0x80
#define updateFontChanged				0x100

// Fonts used by application
#define apptTimeFont 					stdFont
#define apptEmptyDescFont				stdFont
#define noteTitleFont					boldFont


// Token strings in repeating event description template.
#define frequenceToken					"^f"
#define dayOrdinalToken					"^x"
#define weekOrdinalToken				"^w"
#define monthNameToken					"^m"
#define dayNameToken						"^d"

// Default setting for the Details Dialog.
#define defaultAlarmAdvance			5
#define defaultAdvanceUnit				aauMinutes

// Default setting for the Repeating Events Dialog.
#define defaultRepeatFrequency		1
#define defaultRepeatEndDate			-1

// Repeat dialog "end on" popup list items.
#define repeatNoEndDateItem			0
#define repeatChooseDateItem			1

// End Date popup list chooses
#define noEndDateItem					0
#define selectEndDateItem				1

#define emptySlot							-1

// Field numbers used the id where search string was found
#define descSeacrchFieldNum			0
#define noteSeacrchFieldNum			1

// Preference Dialog.
#define dayRangeTimeWidth				50
#define dayRangeTimeHeight				13

// Latest time
#define maxHours							23
#define maxMinutes						55

// Time bars
#define maxTimeBarColumns				5
#define timeBarWidth						2

// The duration to display the current time when the title of the 
// Day View is pressed. 
#define timeDisplayTicks 			150		// 2 1/2 seconds


// Default databook app preference values
#define defaultDayStartHour					(8)
#define defaultDayEndHour						(18)
#define defaultAlarmPresetAdvance			(apptNoAlarm)
#define defaultAlarmPresetUnit				(aauMinutes)
#define defaultNoteFont							(stdFont)
#define defaultSaveBackup						(true)
#define defaultShowTimeBars					(true)
#define defaultCompressDayView				(true)
#define defaultShowTimedAppts					(true)
#define defaultShowUntimedAppts				(false)
#define defaultShowDailyRepeatingAppts		(false)
#define defaultAlarmSoundRepeatCount		(3)
#define defaultAlarmSoundRepeatInterval	(300)
#define defaultAlarmSoundUniqueRecID		(0)
#define defaultApptDescFont					(stdFont)


// Rom Incompatible Alert
#define RomIncompatibleAlert			1001


/***********************************************************************
 *
 *	Far calls
 *
 ***********************************************************************/
typedef struct {
	void 		(*apptGetAppointments) 	(DmOpenRef dbP, DateType date, Word days,VoidHand apptLists [], UInt counts []);
	Err		(*apptGetRecord)			(DmOpenRef dbP, UInt index, ApptDBRecordPtr r, VoidHand * handleP); 
	Boolean	(*apptFindFirst)			(DmOpenRef dbP, DateType date, UIntPtr indexP);
	Boolean	(*apptNextRepeat)			(ApptDBRecordPtr apptRec, DatePtr dateP);
	Err 		(*apptNewRecord)			(DmOpenRef dbP, ApptDBRecordPtr r, UInt *index);
 	Err 		(*moveEvent)				(WordPtr recordNumP, TimeType startTime, TimeType endTime, DateType date, Boolean splitEvent, BooleanPtr moved);
 	Boolean	(*preferencesHandleEvent)	(EventPtr event);
 	void		(*alarmReset)					(Boolean newerOnly);
 	void		(*rescheduleAlarms)			(DmOpenRef dbP);
 	void		(*displayAlarm)				(void);
} FarCallsType;


extern FarCallsType	FarCalls;

#define ApptGetAppointmentsFar			(*FarCalls.apptGetAppointments)
#define ApptGetRecordFar					(*FarCalls.apptGetRecord)
#define ApptFindFirstFar					(*FarCalls.apptFindFirst)
#define ApptNextRepeatFar					(*FarCalls.apptNextRepeat)
#define ApptNewRecordFar					(*FarCalls.apptNewRecord)
#define MoveEventFar							(*FarCalls.moveEvent)
#define PreferencesHandleEventFar		(*FarCalls.preferencesHandleEvent)
#define AlarmResetFar						(*FarCalls.alarmReset)
#define RescheduleAlarmsFar				(*FarCalls.rescheduleAlarms)
#define DisplayAlarmFar						(*FarCalls.displayAlarm)

/***********************************************************************
 *
 *	Datebook prefs structure
 *
 ***********************************************************************/

// This is the structure of the data that's saved to the state file.
typedef struct {
	Word					dayStartHour;
	Word					dayEndHour;
	AlarmInfoType		alarmPreset;
	FontID				v20NoteFont;		// Changed for 2.0 compatibility (BGT)
	Boolean				saveBackup;
	Boolean				showTimeBars;
	Boolean				compressDayView;
	Boolean				showTimedAppts;
	Boolean				showUntimedAppts;
	Boolean				showDailyRepeatingAppts;
	
	// Version 3 preferences
	UInt 					alarmSoundRepeatCount;
	UInt 					alarmSoundRepeatInterval;
	ULong					alarmSoundUniqueRecID;
	FontID				apptDescFont;
	FontID				noteFont;		// Changed for 2.0 compatibility (BGT)
} DatebookPreferenceType;


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
extern DmOpenRef				ApptDB;						// datebook database

extern	DateType				Date;							// date currently displayed
extern	Word					StartDayOfWeek;
extern	Word					DayStartHour;				// start of the day 8:00am
extern	Word					DayEndHour;					// end of the day 6:00pm

extern	TimeFormatType		TimeFormat;
extern	DateFormatType		LongDateFormat;			// system preference
extern 	DateFormatType		ShortDateFormat;
extern 	Word					CurrentRecord;				// record being edited
extern	Boolean				ItemSelected;				// true if a day view item is selected
extern	Word					DayEditPosition;			// position of the insertion point in the desc field


#if 0		// moved to DatePref.c	vmk 12/9/97
	// The following global variable are only valid while editng the datebook's
	// preferences.
	extern	Word					PrefDayStartHour;
	extern	Word					PrefDayEndHour;
#endif

// The following global variable are saved to a state file.
extern 	Word					DayStartHour;				// start of the day 8:00am
extern 	Word					DayEndHour;					// end of the day 6:00pm
extern  	FontID				NoteFont;					// font used in note view
extern  	AlarmInfoType		AlarmPreset;				// default alarm settings.
extern	Boolean				SaveBackup;					// default setting "Backuo tp PC" checkbox
extern	Boolean				ShowTimeBars;				// show time bars in the day view
extern	Boolean				CompressDayView;			// remove empty time slot to prevent scrolling
extern	Boolean				ShowTimedAppts;			// show timed appointments in month view
extern	Boolean				ShowUntimedAppts;			// show untimed appointments in month view
extern	Boolean				ShowDailyRepeatingAppts;// show daily repeating appointments in month view

extern	Boolean				EventInWeekView;			// true if pen of key event has occured
																	// in the Week View
extern	FontID				ApptDescFont;				// font for drawing event description


// The following global variable is used to control the displaying of the
// current time in the title of a view.
extern	Boolean				TimeDisplayed;				// True if time in been displayed
extern	ULong					TimeDisplayTick;			// Tick count when we stop showing time


// The following globals are for the repeat rates of the alarms.
extern	UInt					AlarmSoundRepeatCount;	// number of times to repeat alarm sound 
extern	UInt					AlarmSoundRepeatInterval;// interval between repeat sounds, in seconds

extern	ULong					AlarmSoundUniqueRecID;	// Unique record ID of desired alarm sound


/***********************************************************************
 *
 *	Functions
 *
 ***********************************************************************/
#ifdef __cplusplus
extern "C" {
#endif


extern void ShowInfo (void);

extern  Err MoveEvent (WordPtr recordNumP, TimeType startTime, TimeType endTime,
 		DateType date, Boolean splitEvent, BooleanPtr moved);

extern SWord DatebookLoadPrefs (DatebookPreferenceType* prefsP);

extern void DatebookSavePrefs (void);


#ifdef __cplusplus 
}
#endif

/***********************************************************************
 *
 *   ParamBlock definition for plug-in routines
 *
 ***********************************************************************/

typedef enum
	{
	DateSendRecordCall,
	DateReceiveDataCall
	} MultiSegmentCalls;
	
typedef struct 
	{
	DmOpenRef dbP;
	Int recordNum;
	} DateSendRecordParams;

typedef struct 
	{
	DmOpenRef dbP;
	ExgSocketPtr exgSocketP;
	} DateReceiveDataParams;

typedef union
	{
	DateSendRecordParams dsr;
	DateReceiveDataParams drd;
	} ParamsType;

typedef struct 
	{
	MultiSegmentCalls call;
	ParamsType params;
	} myPlugInParamBlockType;

typedef myPlugInParamBlockType* myPlugInParamBlockPtr;

/***********************************************************************
 *
 *   Function prototype for plug-in routines
 *
 ***********************************************************************/
typedef DWord PlugInMainF (myPlugInParamBlockPtr plugInParamsP);


/***********************************************************************
 *
 *   Entry Points
 *
 ***********************************************************************/
#if EMULATION_LEVEL == EMULATION_NONE
	extern DWord __Startup__( myPlugInParamBlockPtr plugInParamsP );
#endif
extern DWord PlugIn1Main( myPlugInParamBlockPtr plugInParamsP );
