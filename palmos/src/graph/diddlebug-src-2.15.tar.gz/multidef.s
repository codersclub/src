	.file "app-multi.s"

	.globl __code_section_count
	.equ __code_section_count,2

	.globl __text__
	.lcomm __text__,4
	.globl __text__buggery
	.lcomm __text__buggery,4

.text
	.globl _GccRelocateData
_GccRelocateData:
	bra.w _GccLoadCodeAndRelocateData

.section ehook
	.long _GccReleaseCode
