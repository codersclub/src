#ifndef __diddlebug_h
#define __diddlebug_h

#include "diddlebugRsc.h"
#include "menu_shortcuts.h"
#include "booger.h"
#include <Pilot.h>
#include <System/SysEvtMgr.h>
#include <System/ExgMgr.h>

/* Comment out for 2.0 headers */
#define displayAddr displayAddrV20

/* Application type identifier */
#ifndef AppType
#define AppType	0x44494442	/* 'DIDB' */
#endif


/* Preferences version - Incremented everytime pref format changes */
/* Version 1.0-1.4 = 1     */
/* Version 1.5     = 2     */
/* Version 1.6     = 3     */
/* Version 1.7-2.0 = 4     */
/* Version 2.1-2.5 = 5     */
/* Version 2.6-up  = 6     */
#ifndef PrefVersion
#define PrefVersion 6
#endif

/* Database type */
#ifndef DBType
#define DBType	0x44617461	/* 'Data' */
#endif

/* BitmapType */
#ifndef DiddleBitmapType
#define DiddleBitmapType 0x54626d70  /* Tbmp */
#endif

/* Database name */
#ifndef DBName
#define DBName "DiddleBugDB"
#endif

/* Number of pixels allowed in a pen */
#ifndef NPENPIX
#define NPENPIX	32
#endif

/* Number of pen events which may be weighted together */
#ifndef NPENWTS
#define NPENWTS 32	    /* must be power of two */
#endif

/* frmUpdate codes */
#define FRMUPDATE_DELETED_CURRENT 101
#define FRMUPDATE_DELETED_ANY     102

/* Pasting actions */
#define PASTE_NORMAL    0
#define PASTE_INVERSE   1
#define PASTE_TRANS     2
#define PASTE_XOR       3

#define PASTE_BUFFER_SIZE   128

/* Drawing modes */
#define MODE_DOODLE         0
#define MODE_TEXT           1
#define MODE_LINE           2
#define MODE_ARROW          3
#define MODE_SHAPE          4

/* Selection defines */
#define SEL_MODE_PAINT      0
#define SEL_MODE_SMEAR      1
#define SEL_MODE_ERASE      2
#define SEL_FILT_ROUGH      0
#define SEL_FILT_SMOOTH     1
#define SEL_FILT_SMOOTHER   2
#define SEL_PEN_FINE        0
#define SEL_PEN_MEDIUM      1
#define SEL_PEN_BOLD        2
#define SEL_PEN_BROAD       3
#define SEL_PEN_FITALIC     4
#define SEL_PEN_MITALIC     5
#define SEL_PEN_BITALIC     6
#define SEL_INK_WHITE       0
#define SEL_INK_1_8         1
#define SEL_INK_2_8         2
#define SEL_INK_3_8         3
#define SEL_INK_4_8         4
#define SEL_INK_5_8         5
#define SEL_INK_6_8         6
#define SEL_INK_7_8         7
#define SEL_INK_BLACK       8
#define SEL_INK_RANDOM      9

/* Text insertion modes */
#define TXT_BLACK           0
#define TXT_BLACKONWHITE    1
#define TXT_WHITEONBLACK    2
#define TXT_XOR             3

/* Shape type codes */
#define SHAPE_RECTANGLE     0
#define SHAPE_ROUNDRECT     1
#define SHAPE_OVAL          2
#define SHAPE_CIRCLE        3

/* Shape fill codes */
#define SHFILL_OUTLINE      0
#define SHFILL_FILL         1
#define SHFILL_XOR          2

/* Shortcut codes */
#define SCUT_LINE           0
#define SCUT_RECTANGLE      1
#define SCUT_ROUNDRECT      2
#define SCUT_OVAL           3
#define SCUT_CIRCLE         4
#define SCUT_TEXT           5

/* Alarm Repeat modes */
#define REPEAT_NONE         0
#define REPEAT_HOURLY       1
#define REPEAT_DAILY        2
#define REPEAT_WEEKDAYS     3
#define REPEAT_WEEKLY       4
#define REPEAT_BIWEEKLY     5

/* Repeat bitfields */
#define REPEATBITS_WEEKDAYS  0x3e
#define REPEATBITS_SUN      0x01
#define REPEATBITS_MON      0x02
#define REPEATBITS_TUE      0x04
#define REPEATBITS_WED      0x08
#define REPEATBITS_THU      0x10
#define REPEATBITS_FRI      0x20
#define REPEATBITS_SAT      0x40


/* Alarm advance selections for transfer list */
#define XFERADVANCE_NONE            0
#define XFERADVANCE_FIVE            1
#define XFERADVANCE_TEN             2
#define XFERADVANCE_FIFTEEN         3
#define XFERADVANCE_TWENTY          4
#define XFERADVANCE_THIRTY          5
#define XFERADVANCE_SIXTY           6

/* Transfer flags */
#define XFER_GOTONEVER      0x01
#define XFER_GOTOALWAYS     0x02
#define XFER_COMPLETEALWAYS 0x04
#define XFER_COMPLETENEVER  0x08

#define xferGotoClear() d.xfer.flags &= ~(XFER_GOTONEVER|XFER_GOTOALWAYS)
#define xferGotoIsNever   d.xfer.flags&XFER_GOTONEVER
#define xferGotoIsAlways  d.xfer.flags&XFER_GOTOALWAYS
#define xferGotoIsClear   !(d.xfer.flags&(XFER_GOTONEVER|XFER_GOTOALWAYS))
#define xferGotoSetNever() d.xfer.flags = \
            (d.xfer.flags|XFER_GOTONEVER)& ~XFER_GOTOALWAYS
#define xferGotoSetAlways() d.xfer.flags = \
            (d.xfer.flags|XFER_GOTOALWAYS)& ~XFER_GOTONEVER
#define xferCompleteClear() d.xfer.flags &= ~(XFER_COMPLETENEVER|XFER_COMPLETEALWAYS)
#define xferCompleteIsNever d.xfer.flags&XFER_COMPLETENEVER
#define xferCompleteIsAlways d.xfer.flags&XFER_COMPLETEALWAYS
#define xferCompleteIsClear !(d.xfer.flags&(XFER_COMPLETENEVER|XFER_COMPLETEALWAYS))
#define xferCompleteSetNever() d.xfer.flags = \
            (d.xfer.flags|XFER_COMPLETENEVER)& ~XFER_COMPLETEALWAYS
#define xferCompleteSetAlways() d.xfer.flags = \
            (d.xfer.flags|XFER_COMPLETEALWAYS)& ~XFER_COMPLETENEVER

/* Misc */
#define ALARM_STRING_LENGTH 32
#define GETOBJECTPOINTER(frm, objID) \
    FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID))

/* Beaming */
#define BEAM_BUF_SIZE 512

/* Error messages */
#define abort()	ErrDisplayFileLineMsg(__FILE__, __LINE__, "")

#ifdef DIDDLEDEBUG
#define ASSERT(a) if(!a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#define ASSERTNOT(a) if(a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#else  /* DIDDLEDEBUG */
#define ASSERT(a)
#define ASSERTNOT(a)
#endif /* DIDDLEDEBUG */

#define CHECK() FrmAlert(AlarmSetError)

/*
** Extract the pen pixel offsets from the penpex array bytes.
** Each nibble is treated as a 2's complement integer.
*/
#define dxFromPenpix(p)	(((int)(p>>4))-8)
#define dyFromPenpix(p)	(((int)(p&0xF))-8)

/*
** Clipping macro -- PalmOS doesn't clip at screen bottom.
*/
#define rctPtInRectangle(tx,ty,rp) \
(   ((unsigned) ((tx)-(rp)->topLeft.x) < (rp)->extent.x) \
    && ((unsigned) ((ty)-(rp)->topLeft.y) < (rp)->extent.y) )


/*
** Structure for flash message
*/
typedef struct {
    WinHandle offscreen_handle;         /* Draw window before flash */
    WinHandle flash_handle;             /* The flash window handle */
    SWord x;                            /* X value in display coords */
    SWord y;                            /* Y value in display coords */
} FlashMessageType;
typedef FlashMessageType *FlashMessagePtr;

/*
** AlarmData structure - deprecated (18 bytes)
**                       Used only in versions 2.5 and earlier
*/
typedef struct {
        Boolean is_alarm_set;
        Boolean is_countdown;
        ULong alarm_secs;
        short repeat_mode;
        ULong repeat_secs;
        Boolean is_locked;
        DWord reserved;
} DeprecatedAlarmType;
typedef DeprecatedAlarmType *DeprecatedAlarmPtr;

/*
** Structure for globals needed by xfer mode
*/
typedef struct {
    Handle pluglistH;
    short num_plugs;
    SWord plug_menu_width;
    SWord flags;
    Boolean complete;
} GlobalXferType;
typedef GlobalXferType *GlobalXferPtr;

/*
 * Record structure is: DiddleBugRecordType +
 *                      Byte sketch[sketchLength] +
 *                      Null terminated caption +
 *                      Null terminated note +
 *                      Byte extra[extraLength]
 */
typedef struct {
    ULong alarmSecs;
    ULong repeatSecs;
    unsigned short sketchLength; /* includes the 50-byte thumbnail +1 */
    unsigned short extraLength;  /* For future implementations */
    unsigned short flags;
    short priority;  /* zero-based */
    short repeatMode; /* This is authoritative over repeatInfo */
    RepeatInfoType repeatInfo;
} DiddleBugRecordType; /* 26 bytes */
typedef DiddleBugRecordType *DiddleBugRecordPtr;
#define sketchDataOffset (sizeof(DiddleBugRecordType))
#define sketchThumbnailSize 80
/* 25 bytes for the zero data, 50 bytes for thumbnail, 2 bytes for text nulls */
#define minRecordSize (sketchDataOffset+sketchThumbnailSize+25+2+1)
/* BaseRecordSize does not include sketchLength or txt strings or extraLength */
#define baseRecordSize (sketchDataOffset+2)

/* Defines for the record data flags */
#define RECORD_FLAG_ALARM_SET       0x0001
#define RECORD_FLAG_COUNTDOWN       0x0002
#define RECORD_FLAG_LOCKED          0x0004
#define RECORD_FLAG_DIRTY           0x0008 /* just applies to sketch data */
#define RECORD_FLAG_BUFDIRTY        0x0010
#define recordSetAlarm()        d.record.flags |= RECORD_FLAG_ALARM_SET
#define recordUnsetAlarm()      d.record.flags &= ~RECORD_FLAG_ALARM_SET
#define recordSetCountdown()    d.record.flags |= RECORD_FLAG_COUNTDOWN
#define recordUnsetCountdown()  d.record.flags &= ~RECORD_FLAG_COUNTDOWN
#define recordLock()            d.record.flags |= RECORD_FLAG_LOCKED
#define recordUnlock()          d.record.flags &= ~RECORD_FLAG_LOCKED
#define recordSetDirty()        d.record.flags |= RECORD_FLAG_DIRTY
#define recordUnsetDirty()      d.record.flags &= ~RECORD_FLAG_DIRTY
#define recordSetBufDirty()     d.record.flags |= RECORD_FLAG_BUFDIRTY
#define recordUnsetBufDirty()   d.record.flags &= ~RECORD_FLAG_BUFDIRTY
#define recordIsAlarmSet        ((d.record.flags)&RECORD_FLAG_ALARM_SET)
#define recordIsCountdown       ((d.record.flags)&RECORD_FLAG_COUNTDOWN)
#define recordIsLocked          ((d.record.flags)&RECORD_FLAG_LOCKED)
#define recordIsDirty           ((d.record.flags)&RECORD_FLAG_DIRTY)
#define recordIsBufDirty        ((d.record.flags)&RECORD_FLAG_BUFDIRTY)

/*
** Drop List info
*/
typedef struct {
    SWord dropListWidth[4];
    Word type;
    Word iconRsc;
} DropListInfoType;
typedef DropListInfoType *DropListInfoPtr;
#define DROPLIST_TYPE_BITMAP 0
#define DROPLIST_TYPE_PEN    1
#define DROPLIST_TYPE_INK    2

/*
** Global data structure.
*/
typedef struct {
    DmOpenRef dbR;			/* database handle for scratch buffer */
    WinHandle winM;			/* main window */
    WinHandle winbufM;      /* main buffer */
    unsigned int formID;    /* Current formID (including index) */
    struct wts {
        unsigned short x, y;    /* incoming pen coordinates */
    } wts[NPENWTS];
    unsigned short nwts;        /* pen event coordinates */
    unsigned short wx, wy;      /* sum of pwt pen coordinates */
    unsigned short ox, oy;      /* last synthesized pen coordinates */
    short drawmode;             /* MODE_DOODLE, MODE_TEXT, MODE_SHAPE */
    short last_insert;          /* Memory of d.drawmode for Last Insert */
    short lock_count;           /* Number of unsuccesful writes to locked */
    Char InsertionText[32];     /* Text buffer for the "Insert Text" mode */
    WinHandle TextWin;          /* Offscreen window holding insertion text */
    FontID txt_oldfont;         /* Old text font to restore after insert */
    PointType anchor;           /* Anchor used for line, arrow, and shapes */
    DiddleBugRecordType record; /* Buffer for the record data */
    Char CurrentTimeStr[20];    /* String with the current weekday and time */
    DateTimeType frm_date;      /* Current date selected in the Date form */
    Long NextPeriod;            /* tick count until the next check */
    UInt CardNo;                /* cardNo of the application */
    LocalID DBID;               /* dbID of the application prc file */
    SystemPreferencesType sysPrefs;  /* Localized system preferences */
    TimeFormatType shorttime;   /* Time format for titlebar */
    SWord shortcut_width;       /* Width of the shortcut popup list */
    DropListInfoType dropList;  /* Info for the drop lists */
    SWord alarm_select_width;   /* Width of popup alarm selection list */
    SysDBListItemType *papplist; /* List of system applications */
    RectangleType bottom_bar_rect; /* Rectangle covering the bottom bar */
    RectangleType screen_above_bar; /* Rectangle above the bottom bar */
    Boolean is_xfer_mode;       /* transfer mode */
    Boolean alarm_deleted_current; /* alarm deleted current sketch */
    Boolean alarm_deleted_any;     /* alarm deleted any sketch */
    Boolean undo_mark;          /* checkpoint marker for undo */
    Boolean linker_available;  /* Is Rick Brams Linker active? */
    GlobalXferType xfer;        /* Holds global transfer data */
    unsigned char *penpixList[7];   /* List of pens */
    unsigned short *inkList[9];  /* List of inks */
} data;
typedef data *DataPtr;

/*
** Preferences data structure
*/
typedef struct {
    unsigned int version;           /* version number */
    short dbI;                      /* page record for scratch buffer */
    unsigned int formID;            /* titled or untitled */
    unsigned short flags;           /* Boolean flags */
    RectangleType r;                /* current drawing window */
    short modeSelection;            /* Selection for the mode */
    short filtSelection;            /* Selection for the filter */
    short penSelection;             /* Selection for the pen */
    short erasePenSelection;        /* Selection for the erase pen */
    short inkSelection;             /* Selection for the ink */
    unsigned short filt;            /* pen event weighting */
    unsigned char penpix[NPENPIX];  /* pen coordinate offsets */
    unsigned short inkpat[4];       /* current ink pattern */
    FontID txt_font;                /* Font for insertion of text */
    short txt_mode;                 /* Text insertion mode */
    short shape_type;               /* shape mode: circle, rectangle, etc. */
    short shape_fill;               /* Whether shapes are filled or not */
    Word hard_button;               /* Hardware button to make new */
    Word category;                  /* Current category */
    ULong hardware_action;          /* Action to take on hardware button */
    ULong xfer_current_plug;        /* The currently selected xfer plugin */
} pref;
typedef pref *PrefPtr;
/* Pref flags */
#define PFLAGS_DISABLE_TITLE_SCUT   0x0001
#define PFLAGS_CONFIRM_CLEAR        0x0002
#define PFLAGS_CONFIRM_DELETE       0x0004
#define PFLAGS_BIG_OK               0x0008
#define PFLAGS_XFER_GOTO            0x0010
#define PFLAGS_XFER_DELETE          0x0020
#define PFLAGS_XFER_BACKLINK        0x0040


/*
** Structure for DiddleBug Records - deprecated
*/
/*
typedef struct {
    char data[3200];
    Boolean is_alarm_set;
    Boolean is_countdown;
    ULong alarm_secs;
    short repeat_mode;
    ULong repeat_secs;
    Boolean is_locked;
    DWord reserved;
} DiddleBugType;
typedef DiddleBugType *DiddleBugPtr;
*/

/* Shortcut menu locations */
enum sc_locations {high, low};

#endif /* __diddlebug_h */
