#ifndef __XFER_H_
#define __XFER_H_

extern void StartXferMode(void);
extern void CancelXferMode(void);
extern void FinishXferMode(void);
extern void DoXferList(void);
extern void XferListDrawFunc(UInt item, RectanglePtr b, CharPtr* text);
extern Boolean XferPenDown(EventPtr e);

#endif /* __XFER_H_ */
