#include "diddlebug.h"

FlashMessagePtr FlashMessage(UInt strID) {
    RectangleType bounds;
    FlashMessagePtr ret;
    WinHandle orig;
    FontID old_font;
    Char message[48];
    Word error;

    SysCopyStringResource(message, strID);
    ret = (FlashMessagePtr)MemPtrNew(sizeof(FlashMessageType));
    ASSERT(ret);
    old_font = FntSetFont(boldFont);
    bounds.extent.x = FntLineWidth(message, StrLen(message));
    bounds.extent.y = FntLineHeight();
    RctInsetRectangle(&bounds, -4);
    if (bounds.extent.x > 160) return NULL;
    bounds.topLeft.x = (160-bounds.extent.x)/2;
    bounds.topLeft.y = (160-bounds.extent.y)/2;
    orig = WinGetDrawWindow();

    RctInsetRectangle(&bounds, -2);
    ret->x = bounds.topLeft.x; ret->y = bounds.topLeft.y;
    ret->offscreen_handle = WinSaveBits(&bounds, &error);
    ASSERTNOT(error);
    if(error) return NULL;
    RctInsetRectangle(&bounds, 2);

    ret->flash_handle = WinCreateWindow(&bounds, boldRoundFrame,
                                            false, false, &error);
    ASSERTNOT(error);
    if(error) { WinDeleteWindow(ret->offscreen_handle, false); return NULL; }

    WinSetDrawWindow(ret->flash_handle);
    WinEraseWindow();
    WinDrawWindowFrame();
    WinDrawChars(message, StrLen(message), 4, 4);
    WinSetDrawWindow(orig);
    FntSetFont(old_font);
    return ret;
}

void UnFlashMessage(FlashMessagePtr flashP) {
    if (!flashP) return;
    WinDeleteWindow(flashP->flash_handle, true);
    WinRestoreBits(flashP->offscreen_handle, flashP->x, flashP->y);
    MemPtrFree(flashP);
}

void FlashWaitMessage(UInt strID) {
    FlashMessagePtr flshP;

    flshP = FlashMessage(strID);
    SysTaskDelay(SysTicksPerSecond()/2);
    UnFlashMessage(flshP);
}
