/* code03e8.c - EvtProcessSoftKeyStroke handler
   Copyright � 199 Ben Darnell
   This file is a part of LinkMaster,
   which is distributed under the GNU GPL.
   Based on SampleHack by Roger Chaplin <foursquaredev@att.net>
*/

#include <Pilot.h>
#include <FeatureMgr.h>
/*#include <SysEvtMgr.h>*/
/* gcc doesnt like that header file, so here's the decl i need: */
Err EvtFlushNextPenStroke() SYS_TRAP(sysTrapEvtFlushNextPenStroke);
#include <SysEvtPrv.h>
#include <UI/ScrDriverNew.h>
#include "dbscHack.h"
#include "dbscHackRsc.h"


Boolean DoScreenCap(Word prefFlags, Boolean clip);

// This is the code that will be called whenever ANY app calls EvtGetEvent,
// and myhack is enabled in HackMaster. HackMaster is not smart about the
// content of this file; it will simply jump to the first executable statement
// in this file. If you need helper functions, prototype them above, and
// define them AFTER the trap patch.
Err EvtProcessSoftKeyStroke(PointType* start, PointType* end)
{
   DWord               temp;
   Err              (*oldTrap)(PointType*, PointType*);

   PenBtnInfoPtr btninfo;
   UInt numbuttons=0, i;
   UInt startbutton=0, endbutton=0;
  
   // get the address of the old EvtGetEvent() from HackMaster
   FtrGet(MYCRID, 0x3e8, &temp);
   // set the function pointer to the old trap
   oldTrap = (Err (*)(PointType*, PointType*)) temp;

   btninfo=EvtGetPenBtnList(&numbuttons);
   for (i=0; i<numbuttons; i++) {
      if (RctPtInRectangle(start->x, start->y, &btninfo[i].boundsR))
	 startbutton=btninfo[i].asciiCode;
      if (RctPtInRectangle(end->x, end->y, &btninfo[i].boundsR))
	 endbutton=btninfo[i].asciiCode;
   }

   if (startbutton!=endbutton) {
      MyPrefsType prefs;
      Word prefssize=sizeof(prefs);

      if ((PrefGetAppPreferences('DBSC', 0, &prefs, &prefssize, true)
	   ==noPreferenceFound)||(prefssize<sizeof(prefs))) {
	 prefs.strokestart=calcChr;
	 prefs.strokeend=findChr;
     prefs.clipstart=findChr;
     prefs.clipend=calcChr;
     prefs.flags = 0x0000;
     prefs.flags |= DBSC_FLAGS_JUMP;
      }
      if ((startbutton==prefs.strokestart)&&(endbutton==prefs.strokeend)) {
	    if (!DoScreenCap(prefs.flags, false)) SndPlaySystemSound(sndError);
      }
      if ((startbutton==prefs.clipstart)&&(endbutton==prefs.clipend)) {
	    if (!DoScreenCap(prefs.flags, true)) SndPlaySystemSound(sndError);
      }
   }

   return oldTrap(start, end);
}

Boolean DoScreenCap(Word prefFlags, Boolean clip) {
    Err err;
    DmSearchStateType searchstate;
    UInt cardno, dBugCardNo;
    LocalID dbid, dBugdbID;
    DWord romVersion;
    DWord width=160, height=160, depth=1;
    Boolean color=false;
    UInt bitDepth;
    UInt index;
    DmOpenRef dbR;
    VoidHand t;
    VoidPtr ptr;
    Byte buffer[67];
    BytePtr srcPtr;
    DiddleBugRecordPtr recordP;
    UInt i, j;
    GoToParamsPtr gotoP;
    Byte bufByte;
    ULong * const LSSA = (ULong *)MC68328_LSSA_REGADDR;
    UInt byteCount;

    /* Check to see if we support more than 1-bit depth */
    err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (err) return false;
    if (romVersion >= 0x03003000) {
        /* One of them new-fangled machines */
        ScrDisplayMode(scrDisplayModeGet, &width, &height, &depth, &color);
    }
    else depth = 0x00000001;

    /* Determine the bit depth of the screen */
    if ( depth&0x00000008 ) bitDepth = 4;
    else if ( depth&0x00000002 ) bitDepth = 2;
    else if ( depth&0x00000001 ) bitDepth = 1;
    else return false;

    /* Check if DiddleBug is running */
    SysCurAppDatabase(&dBugCardNo, &dBugdbID);
    err = DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl', 'DIDB',
                                            true, &cardno, &dbid);
    if (err) return false;
    if ((dBugCardNo == cardno) && (dBugdbID == dbid)) return false;

    /* Play the starting sound */
    SndPlaySystemSound(sndClick);


    /* Open the DiddleBug database */
    dbR = DmOpenDatabaseByTypeCreator('Data', 'DIDB', dmModeReadWrite);
    if (dbR == NULL) { return false; }

    /* Create a new record at highest index */
    index = dmMaxRecordIndex;
    t = DmNewRecord(dbR, &index, 3331+baseRecordSize);
    if (!t) { DmCloseDatabase(dbR); return false; }
    ptr = MemHandleLock(t);

    /* Write the header and buffer information to the record */
    MemSet(buffer, 67, 0);
    recordP = (DiddleBugRecordPtr)buffer;
    recordP->sketchLength = 3331;
    DmWrite(ptr, 0, recordP, sizeof(DiddleBugRecordType));
    DmSet(ptr, sketchDataOffset, sketchThumbnailSize+1, 0);

    /* Get the memory of the screen */
    srcPtr = (BytePtr)*LSSA;

    /* Save the record.  This doesn't really compress, but so what? */
    if (clip) {
        srcPtr += (16*20*bitDepth);
        byteCount = (16*20);
    }
    else byteCount = 0;
    for (i=0; i<50; i++) {
        MemSet(buffer, 67, 0);
        buffer[0] = 0xff;
        for (j=1; j<65; j++) {
            bufByte = 0x00;
            if (byteCount >= 3200) {
                bufByte = 0x00;
            }
            else if (bitDepth == 4) {
                if ((srcPtr[0]&0x80)||(srcPtr[0]&0x40)) bufByte |= 0x80;
                if ((srcPtr[0]&0x08)||(srcPtr[0]&0x04)) bufByte |= 0x40;
                srcPtr++;
                if ((srcPtr[0]&0x80)||(srcPtr[0]&0x40)) bufByte |= 0x20;
                if ((srcPtr[0]&0x08)||(srcPtr[0]&0x04)) bufByte |= 0x10;
                srcPtr++;
                if ((srcPtr[0]&0x80)||(srcPtr[0]&0x40)) bufByte |= 0x08;
                if ((srcPtr[0]&0x08)||(srcPtr[0]&0x04)) bufByte |= 0x04;
                srcPtr++;
                if ((srcPtr[0]&0x80)||(srcPtr[0]&0x40)) bufByte |= 0x02;
                if ((srcPtr[0]&0x08)||(srcPtr[0]&0x04)) bufByte |= 0x01;
            }
            else if (bitDepth == 2) {
                if (srcPtr[0]&0x80) bufByte |= 0x80;
                if (srcPtr[0]&0x20) bufByte |= 0x40;
                if (srcPtr[0]&0x08) bufByte |= 0x20;
                if (srcPtr[0]&0x02) bufByte |= 0x10;
                srcPtr++;
                if (srcPtr[0]&0x80) bufByte |= 0x08;
                if (srcPtr[0]&0x20) bufByte |= 0x04;
                if (srcPtr[0]&0x08) bufByte |= 0x02;
                if (srcPtr[0]&0x02) bufByte |= 0x01;
            }
            else {
                bufByte = srcPtr[0];
            }
            buffer[j] = bufByte;
            srcPtr++;
            byteCount++;
        }
        DmWrite(ptr,sketchDataOffset+sketchThumbnailSize+1+(65*i),buffer, 67);
    }

    /* Cleanup */
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, index, true);
    DmCloseDatabase(dbR);

    /* Launch DiddleBug at new sketch */
    if (prefFlags&DBSC_FLAGS_JUMP) {
        gotoP = MemPtrNew(sizeof(GoToParamsType));
        MemSet(gotoP, sizeof(GoToParamsType), 0);
        gotoP->recordNum = index;
        MemPtrSetOwner(gotoP, 0);
        SysUIAppSwitch(cardno, dbid, sysAppLaunchCmdGoTo, (VoidPtr)gotoP);
    }

    return true;
}
