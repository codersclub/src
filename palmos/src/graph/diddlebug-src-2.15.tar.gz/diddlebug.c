/*
** diddlebug - a yellow-sticky-note-thingy
** Copyright (c) 1999, Mitch Blevins <mblevin@debian.org>.
** Licensed under the GNU GPL, version 2 or later
** See file "COPYING" that you should have received with this program
** or visit http://www.gnu.org/copyleft/gpl.html
** 
** DiddleBug is based on Diddle, which is based on Doodle
** Doodle is Copyright 1997, Roger E Critchlow Jr., San Francisco, California.
** All rights reserved.  Fair use permitted.  Caveat emptor.  No warranty.
*/

#include "diddlebug.h"
#include "callback.h"
#include "util.h"
#include "xfer.h"
#include <UI/ScrDriverNew.h>

/* shape.c */
extern void ClearOldShape(void);
extern void DoShape(SWord x, SWord y);
extern void EndShape(SWord x, SWord y);

/* beam.c */
void BeamSend(void);


data d;					/* initialized to zero */

pref p = {
    PrefVersion,
    0,
    DiddleTForm,
    0x0016,  /* flags - confirm delete, confirm clear, and xfer goto */
    { 0, 16, 160, 132 },
    SEL_MODE_PAINT,
    SEL_FILT_ROUGH,
    SEL_PEN_MEDIUM,
    SEL_PEN_BROAD, /* Erase pen selection */
    SEL_INK_BLACK,
    4,
    "\x88\x98\x89\x99",
    { 0xffff, 0xffff, 0xffff, 0xffff },
    stdFont,
    TXT_BLACK,
    SHAPE_RECTANGLE,
    SHFILL_OUTLINE,
    0,              /* hard_button */
    0,              /* category */
    0,              /* Hardware button action */
    0,              /* Current transfer plugin */
};

Word modeDropList[4] = { modePaint, modeSmear, modeErase, 0 };
Word smoothDropList[4] = { cmdRough, cmdSmooth, cmdSmoother, 0 };
Word penDropList[8] = { penFine, penMedium, penBold, penBroad,
                        penFineItalic, penMediumItalic, penBroadItalic, 0 };
Word inkDropList[10] = { inkWhite, inkDith12, inkDith25, inkDith37, inkDith50,
                        inkDith62, inkDith75, inkDith87, inkBlack, 0 };
#define DROPLIST_MAX  10

/*
** Default penpixel set.
*/
char penpixFine[] =		"\x88";
char penpixMedium[] =		"\x88\x98\x89\x99";
char penpixBold[] =         "\x77\x87\x97\x78\x98\x79\x89\x99";
char penpixBroad[] =		"\x66\x76\x86\x96\xA6\x67\xA7\x68\xA8\x69\xA9\x6A\x7A\x8A\x9A\xAA";
char penpixFineItalic[] =	"\x78\x88\x87\x97";
char penpixMediumItalic[] =	"\x69\x79\x78\x88\x87\x97\x96\xA6";
char penpixBroadItalic[] =	"\x5A\x6A\x69\x79\x78\x88\x87\x97\x96\xA6\xA5\xB5";

/*
** Default ink pattern set.
*/
unsigned short patternWhite[] =  { 0x0000, 0x0000, 0x0000, 0x0000 };
unsigned short patternDith12[] = { 0x1100, 0x4400, 0x1100, 0x4400 };
unsigned short patternDith25[] = { 0x2211, 0x4488, 0x2211, 0x4488 };
unsigned short patternDith37[] = { 0xc84c, 0x2331, 0x8cc4, 0x3213 };
unsigned short patternDith50[] = { 0xaa55, 0xaa55, 0xaa55, 0xaa55 };
unsigned short patternDith62[] = {~0xc84c,~0x2331,~0x8cc4,~0x3213 };
unsigned short patternDith75[] = {~0x2211,~0x4488,~0x2211,~0x4488 };
unsigned short patternDith87[] = {~0x1100,~0x4400,~0x1100,~0x4400 };
unsigned short patternBlack[] =  {~0x0000,~0x0000,~0x0000,~0x0000 };
RectangleType inkr = { 40+3*16, 2, 13, 9 };


/*
** GetObjectPointer - return an object pointer given a form and objID
*/
static void * GetObjectPointer(FormPtr frm, Word objID) {
     return FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID));
}

/*
** HideObject
*/
static void HideObject(FormPtr frm, Word objID) {
    FrmHideObject(frm, FrmGetObjectIndex(frm, objID));
    return;
}

/*
** ShowObject
*/
static void ShowObject(FormPtr frm, Word objID) {
    FrmShowObject(frm, FrmGetObjectIndex(frm, objID));
    return;
}

/*
** GetListWidth
*/
SWord GetListWidth(ListPtr list) {
    Word num_items, i;
    CharPtr list_textP;
    FontID oldfont;
    SWord text_width=0, list_width=0;

    if (!list) return 10;  /* real skinny list indicates an error */

    num_items = LstGetNumberOfItems(list);
    oldfont = FntSetFont(stdFont);
    for (i=0; i<num_items; i++) {
        list_textP = LstGetSelectionText(list, i);
        if (list_textP) {
            text_width = FntLineWidth(list_textP, StrLen(list_textP));
            if (text_width > list_width)
                list_width = text_width;
        }
    }
    FntSetFont(oldfont);
    list_width += 8;

    return list_width;
}

/*
** GetFormattedDate - Get the proper format for the alarm label
*/
void GetFormattedDate(DateTimeType *date, CharPtr string, Boolean wc) {
    Char temp[15];

    SysCopyStringResource(temp,
                    DayOfWeek(date->month, date->day, date->year) + SunString);
    StrNCopy(string, temp, ALARM_STRING_LENGTH);
    StrNCat(string, ", ", ALARM_STRING_LENGTH);
    switch (d.sysPrefs.longDateFormat) {
        case dfDMYLong:
        case dfDMYLongWithDot:
        case dfDMYLongNoDay:
        case dfDMYLongWithComma:
            /* Day comes first */
            StrIToA(temp, date->day);
            StrNCat(string, temp, ALARM_STRING_LENGTH);
            if (d.sysPrefs.longDateFormat == dfDMYLongWithDot)
                StrNCat(string, ". ", ALARM_STRING_LENGTH);
            else StrNCat(string, " ", ALARM_STRING_LENGTH);
            DateToAscii(date->month, date->day, date->year,
                            dfMDYLongWithComma, temp);
            temp[3] = nullChr;
            StrNCat(string, temp, ALARM_STRING_LENGTH);
            break;
        default:
            DateToAscii(date->month, date->day, date->year,
                            dfMDYLongWithComma, temp);
            temp[3] = nullChr;
            StrNCat(string, temp, ALARM_STRING_LENGTH);
            StrNCat(string, " ", ALARM_STRING_LENGTH);
            StrIToA(temp, date->day);
            StrNCat(string, temp, ALARM_STRING_LENGTH);
            break;
    }
    if (wc) /* if with comma */
        StrNCat(string, ", ", ALARM_STRING_LENGTH);
}

/* 
** ForceMenuDown - forces the menu to erase
*/
static void ForceMenuDown(void) {
    MenuBarPtr menuBarP;
    EventType me;
    Err error;

    menuBarP = MenuGetActiveMenu();
    if (menuBarP && menuBarP->attr.visible) {
        me.eType = keyDownEvent;
        me.data.keyDown.chr = menuChr;
        MenuHandleEvent(menuBarP, &me, &error);
    }
}

/*
** FlushToBuffer
*/
void FlushToBuffer(void) {
    if (recordIsDirty) {
        ForceMenuDown();
        WinCopyRectangle(d.winM, d.winbufM, &p.r, 0, 0, scrCopy);
        recordUnsetDirty();
        recordSetBufDirty();
    }
    d.undo_mark = false;
}

/*
** LoadFromBuffer
*/
static void LoadFromBuffer(void) {
    RectangleType tempRect;
    ForceMenuDown();
    RctCopyRectangle(&p.r, &tempRect);
    tempRect.topLeft.x = 0;
    tempRect.topLeft.y = 0;
    WinCopyRectangle(d.winbufM, d.winM, &tempRect, p.r.topLeft.x,
                        p.r.topLeft.y, scrCopy);
    recordUnsetDirty();
    d.undo_mark = false;
}

/*
** CompressSketch - assumes uPtr is 160x160 bits
**                  returns a locked pointer to the current record
*/
VoidPtr CompressSketch(ULong* size, BytePtr uPtr) {
    BytePtr dataPtr, headPtr, buffer, cuPtr;
    VoidHand t;
    VoidPtr ptr;
    UInt i, j, k;
    Byte mask, thumbByte;
    ULong highDataSize;
    VoidPtr highDataPtr;

    /* Now the real stuff */
    buffer = MemPtrNew(3331); /* Big enough to hold any sketch */
    if (!buffer) abort();

    (*size) = 0;
    headPtr = buffer+sketchThumbnailSize;
    dataPtr = headPtr;

    /* Fill the thumbnail buffer */
    for (i=0; i<sketchThumbnailSize; i++) {
        buffer[i] = 0x00;
        (*size)++;
    }
    /* Load the seed */
    if (uPtr[0]) headPtr[0] = 0x00;
    else headPtr[0] = 0x80;
    (*size)++;

    /* Loop thru every byte in uPtr data */
    cuPtr = uPtr;
    for (i=0; i<20; i++) {
    for (j=0; j<8; j++) {
    for (k=0; k<20; k++) {
        if (cuPtr[0]) {
            /* Set the bit in the thumbnail */
            thumbByte = (i*4) + (k/8);
            switch (k%8) {
                case 0: mask = 0x80; break;
                case 1: mask = 0x40; break;
                case 2: mask = 0x20; break;
                case 3: mask = 0x10; break;
                case 4: mask = 0x08; break;
                case 5: mask = 0x04; break;
                case 6: mask = 0x02; break;
                case 7: mask = 0x01; break;
            }
            buffer[thumbByte] |= mask;
            if (cuPtr[0] == 0xff) {
                /* Black */
                if (headPtr[0]&0x80) {
                    if (headPtr[0]&0x40) {
                        /* headPtr is mixed */
                        if (dataPtr[0] == 0xff) {
                            /* Previous byte was also black */
                            headPtr[0]--;
                            headPtr = dataPtr; headPtr[0] = 0x81;
                        }
                        else {
                            /* Previous byte was not black */
                            if ((headPtr[0]&0x3f) < 63) {
                                headPtr[0]++;
                                dataPtr++; dataPtr[0] = 0xff; (*size)++;
                            }
                            else {
                                headPtr = dataPtr+1; headPtr[0] = 0x80;
                                (*size)++;
                            }
                        }
                    }
                    else {
                        /* headPtr is black */
                        if ((headPtr[0]&0x3f) < 63) headPtr[0]++;
                        else { headPtr++; headPtr[0] = 0x80; (*size)++; }
                    }
                }
                else {
                    /* headPtr is white, create a new headPtr */
                    headPtr++; headPtr[0] = 0x80; (*size)++;
                }
            }
            else {
                /* Mixed */
                if ((headPtr[0]&0xc0) == 0xc0) {
                    /* Add to the mixture */
                    if ((headPtr[0]&0x3f) < 63) {
                        headPtr[0]++;
                    }
                    else {
                        dataPtr++; headPtr = dataPtr; headPtr[0] = 0xc0;
                        (*size)++;
                    }
                    dataPtr++; dataPtr[0] = cuPtr[0]; (*size)++;
                }
                else {
                    /* Create new headPtr for mixture */
                    headPtr++; headPtr[0] = 0xc0; (*size)++;
                    dataPtr = headPtr+1; dataPtr[0] = cuPtr[0]; (*size)++;
                }
            }
        }
        else {
            /* White */
            if (headPtr[0]&0x80) {
                if (headPtr[0]&0x40) {
                    /* headPtr is mixed */
                    if (dataPtr[0]) {
                        /* Previous byte was not white */
                        if ((headPtr[0]&0x3f) < 63) {
                            headPtr[0]++;
                            dataPtr++; dataPtr[0] = 0x00; (*size)++;
                        }
                        else {
                            headPtr = dataPtr+1; headPtr[0] = 0x00;
                            (*size)++;
                        }
                    }
                    else {
                        /* Previous byte was also white */
                        headPtr[0]--;
                        headPtr = dataPtr; headPtr[0] = 0x01;
                    }
                }
                else {
                    /* headPtr is black, create a new headPtr */
                    headPtr++; headPtr[0] = 0x00; (*size)++;
                }
            }
            else {
                /* headPtr is white */
                if (headPtr[0] < 127) headPtr[0]++;
                else { headPtr++; headPtr[0] = 0x00; (*size)++; }
            }
        }
        cuPtr++;
    }
    }
    }

    /* Save any text or other info above the sketch data */
    t = DmQueryRecord(d.dbR, p.dbI);
    ASSERT(t);
    ptr = MemHandleLock(t);
    highDataSize = 0;
    highDataSize +=
            StrLen((CharPtr)(ptr+sketchDataOffset+d.record.sketchLength));
    highDataSize++; /* The null character */
    highDataSize += StrLen((CharPtr)(ptr+sketchDataOffset+
                            d.record.sketchLength+highDataSize));
    highDataSize++; /* The null character */
    highDataSize += d.record.extraLength;
    highDataPtr = MemPtrNew(highDataSize);
    MemMove(highDataPtr, (ptr+sketchDataOffset+(*size)), highDataSize);
    MemHandleUnlock(t);
    /* Resize the record */
    t = DmResizeRecord(d.dbR, p.dbI, sketchDataOffset+(*size)+highDataSize);
    ASSERT(t);
    t = DmGetRecord(d.dbR, p.dbI);
    ASSERT(t);
    ptr = MemHandleLock(t);

    /* Write the sketch data to disk */
    DmWrite(ptr, sketchDataOffset, buffer, (*size));
    /* Re-Write the high data to disk */
    DmWrite(ptr, sketchDataOffset+(*size), highDataPtr, highDataSize);

    MemPtrFree(highDataPtr);
    MemPtrFree(buffer);
    return ptr;
}

/*
** FlushToDisk
*/
static void FlushToDisk(Boolean flushSketchData) {
    VoidHand t;
    VoidPtr ptr;
    ULong sketchSize;

    if (flushSketchData) FlushToBuffer();

    /* Bail if index is out of range */
    if ((p.dbI+1) > DmNumRecords(d.dbR)) return;

    /* Also save the sketch data if requested and needed */
    if (flushSketchData && recordIsBufDirty) {
        recordUnsetBufDirty();

        /* ptr is locked on return */
        sketchSize = 0;
        ptr = CompressSketch(&sketchSize,
                        WinGetWindowPointer(d.winbufM)->displayAddr);

        /* Set the sketchSize */
        d.record.sketchLength = sketchSize;

    }
    else {
        /* Open and lock the record */
        t = DmGetRecord(d.dbR, p.dbI);
        if (!t) abort();
        ptr = MemHandleLock(t);
    }

    /* Write the header-type data */
    DmWrite(ptr, 0, &(d.record), sizeof(DiddleBugRecordType));

    /* Clean up */
    MemPtrUnlock(ptr);
    DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** UncompressSketch - assumes uPtr of 160x160 bits
*/
static void UncompressSketch(CharPtr cPtr, CharPtr uPtr, ULong size) {
    ULong i, j;
    unsigned char num_bytes;

    j = 0;
    for (i=0; i<size; i++) {
        if (cPtr[i]&0x80) {
            num_bytes = cPtr[i]&0x3f;  /* ~(0x40|0x80) */
            num_bytes++;
            if (num_bytes > (3200-j)) abort();
            if (cPtr[i]&0x40) {
                /* Mixed */
                MemMove(uPtr+j, cPtr+i+1, num_bytes);
                i += num_bytes;
            }
            else {
                /* Black */
                MemSet(uPtr+j, num_bytes, 0xff);
            }
        }
        else {
            /* White */
            num_bytes = cPtr[i]&0x7f; /* ~0x80 */
            num_bytes++;
            if (num_bytes > (3200-j)) abort();
            MemSet(uPtr+j, num_bytes, 0x00);
        }
        j += num_bytes;
    }
}

/*
** AllocImage - create a new image record.
*/
static void AllocImage(void) {
    VoidHand t;
    VoidPtr ptr;
    DiddleBugRecordType record;

    t = DmNewRecord(d.dbR, &p.dbI, minRecordSize);
    if (!t) abort();
    ptr = MemHandleLock(t);
    MemSet(&record, sizeof(DiddleBugRecordType), 0);
    record.sketchLength = sketchThumbnailSize+1+25;
    DmSet(ptr, 0, minRecordSize, 0);
    DmSet(ptr, sketchDataOffset+sketchThumbnailSize+1, 25, 0x7f);
    DmWrite(ptr, 0, &record, sizeof(DiddleBugRecordType));
    MemHandleUnlock(t);
    DmReleaseRecord(d.dbR, p.dbI, true);
}

/*
** LoadFromDisk
*/
static void LoadFromDisk(void) {
    VoidHand t;
    VoidPtr ptr, sketchPtr, bufPtr;

    /* Open and lock the record */
    t = DmQueryRecord(d.dbR, p.dbI);
    if (!t) {
        AllocImage();
        t = DmQueryRecord(d.dbR, p.dbI);
        if (!t) abort();
    }
    ptr = MemHandleLock(t);

    /* Read the header data */
    MemMove(&d.record, ptr, sizeof(DiddleBugRecordType));
    sketchPtr = ptr+sketchDataOffset+sketchThumbnailSize+1;
    bufPtr = WinGetWindowPointer(d.winbufM)->displayAddr;

    /* Uncompress to the offscreen window */
    UncompressSketch(sketchPtr, bufPtr,
                    d.record.sketchLength-sketchThumbnailSize-1);

    /* Cleanup */
    MemHandleUnlock(t);
    LoadFromBuffer();
    d.NextPeriod = TimGetTicks()+100;
}


/*
** SetClosestAlarm - find the more nearest alarm in the records and set it
*/
static void SetClosestAlarm(DmOpenRef dbR) {
    UInt i, num_records;
    DiddleBugRecordType record;
    VoidHand t;
    ULong closest_alarm, current_time, current_alarm;
    ULong unique;
    DWord uniqueDW;
    UInt cardNo;
    LocalID dbID;
    DmSearchStateType searchstate;
    DWord dummyRef;
    Err err;

    num_records = DmNumRecords(dbR);
    current_time = TimGetSeconds();
    closest_alarm = 0;
    for (i = 0; i < num_records; i++) {
        /* Get the record data */
        t = DmQueryRecord(dbR, i);
        if (!t) continue;
        MemMove(&record, MemHandleLock(t), sizeof(DiddleBugRecordType));
        MemHandleUnlock(t);
        /* Compare with the closest found so far... */
        if ( record.flags&RECORD_FLAG_ALARM_SET &&
                        (record.alarmSecs > (current_time-60)) ) {
            if ( (record.alarmSecs < closest_alarm) || !closest_alarm ) {
                closest_alarm = record.alarmSecs;
                DmRecordInfo(dbR, i, NULL, &unique, NULL);
            }
        }
    }
    /* Set the found alarm (or clear all alarms) */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate,
            sysFileTApplication, AppType, true, &cardNo, &dbID)) {
        abort();
        return;
    }
    MemSet(&uniqueDW, sizeof(DWord), 0);
    MemMove(&uniqueDW, &unique, sizeof(ULong));
    err = 0;
    current_alarm = AlmGetAlarm(cardNo, dbID, &dummyRef);
    if (closest_alarm) {
        err = AlmSetAlarm(cardNo, dbID, uniqueDW, closest_alarm, NULL);
    }
    else {
        /* Clear alarm if it is already set in future */
        if (current_alarm > current_time)
            err = AlmSetAlarm(cardNo, dbID, 0, 0, NULL);
    }
    if (err)
        FrmAlert(AlarmSetError);

}


/*
** SetLabel - set the label of a control on the current form.
*/
static void SetLabel(Int objectID, CharPtr label) {
    FormPtr frm;

    frm = FrmGetActiveForm();
    CtlSetLabel(GetObjectPointer(frm,objectID), label);
}

/*
** DrawBitmapLabel
*/
static void DrawBitmapLabel(Word bitmapID, SWord x, SWord y) {
    VoidHand t;
    BitmapPtr bitmapP;

    t = DmGetResource('Tbmp', bitmapID);
    ASSERT(t);
    bitmapP = MemHandleLock(t);
    WinDrawBitmap(bitmapP, x, y);
    MemHandleUnlock(t);
    DmReleaseResource(t);
}

/*
** DrawPenLabel
*/
static void DrawPenLabel(unsigned char *pen, SWord x, SWord y) {
    SWord nx, ny, i;
    RectangleType rect;
    RctSetRectangle(&rect, x, y, 14, 10);
    WinEraseRectangle(&rect, 4);
    for (i = 0; i < NPENPIX && pen[i] != 0; i += 1) {
        nx = x+6+dxFromPenpix(pen[i]);
        ny = y+4+dyFromPenpix(pen[i]);
        WinDrawLine(nx, ny, nx, ny);
    }
}

/*
** DrawInkLabel
*/
static void DrawInkLabel(unsigned short *ink, SWord x, SWord y, Boolean inv) {
    RectangleType rect;
    RctSetRectangle(&rect, x+1, y, 13, 9);
    WinSetPattern(ink);
    WinFillRectangle(&rect, 3);
    if (inv) WinInvertRectangle(&rect, 3);
    WinSetPattern(p.inkpat);
}

/*
** LabelTitle - Put the current time into the title
*/
static void LabelTitle(void) {
    FormPtr frm;
    MenuBarPtr menuBarP;
    ULong curr_secs;
    Char title_text[9];
    DateTimeType date;

    menuBarP = MenuGetActiveMenu();
    if (menuBarP && menuBarP->attr.visible) return;

    frm = NULL;
    frm = FrmGetActiveForm();
    curr_secs = TimGetSeconds();
    TimSecondsToDateTime(curr_secs, &date);

    TimeToAscii(date.hour, date.minute, d.shorttime, title_text);
    title_text[6] = nullChr;  /* Ensure it stays within limits */
    if (frm && (FrmGetActiveFormID() == DiddleTForm))
        FrmCopyTitle(frm, title_text);
}

/*
** LabelAlarm - put the correct alarm in the button bar
**              This function should only be called while on the DiddleForm
**              or the DiddleTForm.
*/
static void LabelAlarm(void) {
    FormPtr frm;
    Word formID;
    ControlPtr ctl, ctl_clear, ctl_delete, ctl_lock;
    Char dateStr[ALARM_STRING_LENGTH];
    DateTimeType date, curr, cdown;
    DateType cdowndate;
    ULong cdowndays;
    ULong current_secs;

    if (d.is_xfer_mode) return;
    frm = FrmGetActiveForm();
    formID = FrmGetActiveFormID();
    if (!frm || ((formID != DiddleForm) && (formID != DiddleTForm))) return;
    ctl = GetObjectPointer(frm, MainDateSelTrig);
    current_secs = TimGetSeconds();
    if (recordIsAlarmSet && (d.record.alarmSecs > current_secs)) {
        TimSecondsToDateTime(d.record.alarmSecs, &date);
        if (recordIsCountdown) {
            TimSecondsToDateTime(d.record.alarmSecs-current_secs, &cdown);
            cdowndate.day = cdown.day;
            cdowndate.month = cdown.month;
            cdowndate.year = cdown.year - firstYear;
            cdowndays = DateToDays(cdowndate);
            if (cdowndays == 0) {
                SysCopyStringResource(dateStr, CountdownString);
                StrNCopy(ctl->text, dateStr, ALARM_STRING_LENGTH);
            }
            else if (cdowndays == 1) {
                SysCopyStringResource(dateStr, SingleDayString);
                StrNCopy(ctl->text, dateStr, ALARM_STRING_LENGTH);
            }
            else {
                StrIToA(ctl->text, cdowndays);
                SysCopyStringResource(dateStr, MultiDayString);
                StrNCat(ctl->text, dateStr, ALARM_STRING_LENGTH);
            }
            StrIToA(dateStr, cdown.hour);
            if (StrLen(dateStr) == 1) {
                dateStr[2] = nullChr;
                dateStr[1] = dateStr[0];
                dateStr[0] = '0';
            }
            StrNCat(ctl->text, dateStr, ALARM_STRING_LENGTH);
            StrNCat(ctl->text, ":", ALARM_STRING_LENGTH);
            StrIToA(dateStr, cdown.minute);
            if (StrLen(dateStr) == 1) {
                dateStr[2] = nullChr;
                dateStr[1] = dateStr[0];
                dateStr[0] = '0';
            }
            StrNCat(ctl->text, dateStr, ALARM_STRING_LENGTH);
            StrNCat(ctl->text, ":", ALARM_STRING_LENGTH);
            StrIToA(dateStr, cdown.second);
            if (StrLen(dateStr) == 1) {
                dateStr[2] = nullChr;
                dateStr[1] = dateStr[0];
                dateStr[0] = '0';
            }
            StrNCat(ctl->text, dateStr, ALARM_STRING_LENGTH);
        }
        else {
            TimSecondsToDateTime(current_secs, &curr);
            if ((curr.day == date.day) && (curr.month == date.month) &&
                            (curr.year == date.year)) {
                SysCopyStringResource(ctl->text, TodayString);
            }
            else if (((curr.day+1) == date.day) && (curr.month == date.month) &&
                            (curr.year == date.year)) {
                SysCopyStringResource(ctl->text, TomorrowString);
            }
            else {
                GetFormattedDate(&date, dateStr, true);
                StrNCopy(ctl->text, dateStr, ALARM_STRING_LENGTH);
            }
            TimeToAscii(date.hour, date.minute, d.sysPrefs.timeFormat, dateStr);
            StrNCat(ctl->text, dateStr, ALARM_STRING_LENGTH);
        }
    }
    else {
        if (recordIsCountdown) {
            SysCopyStringResource(ctl->text, NoCountdownString);
        }
        else {
            SysCopyStringResource(ctl->text, NoAlarmString);
        }
        if (d.record.alarmSecs < current_secs) {
            recordUnsetAlarm();
            d.record.alarmSecs = 0;
        }
    }
    WinEraseRectangle(&(ctl->bounds), 0);
    CtlDrawControl(ctl);

    /* Draw the lock symbol if sketch is locked */
    if (recordIsLocked) {
        HideObject(frm, MainClearButton);
        HideObject(frm, MainDeleteButton);
        HideObject(frm, ClearBitmap);
        HideObject(frm, DeleteBitmap);
        ShowObject(frm, MainLockButton);
        ShowObject(frm, LockBitmap);
    }
    else {
        HideObject(frm, MainLockButton);
        HideObject(frm, LockBitmap);
        ShowObject(frm, MainClearButton);
        ShowObject(frm, MainDeleteButton);
        ShowObject(frm, ClearBitmap);
        ShowObject(frm, DeleteBitmap);
    }
}
void LabelAlarm_(void) {
    LabelAlarm();
}

/*
** BlankAlarm - just remove those X's on the startup
*/
static void BlankAlarm(void) {
    FormPtr frm;
    ControlPtr ctl;

    frm = FrmGetActiveForm();
    ctl = GetObjectPointer(frm, MainDateSelTrig);
    StrCopy(ctl->text, "");
}

/*
** LabelImage - put the program state in the title bar
*/
static void LabelImage(void) {
    if (FrmGetActiveFormID() == DiddleTForm) {
        char temp[8];
        char temp2[4];
        short i, x, y;
        /* Show mode label */
        DrawBitmapLabel(CmdPaintBitmap+p.modeSelection, 40, 2);
        /* Show filter label */
        DrawBitmapLabel(CmdRoughBitmap+p.filtSelection, 40+16, 2);
        /* Show current pen */
        DrawPenLabel(p.penpix, 40+16+16, 2);
        /* Show current ink */
        WinSetPattern(p.inkpat);
        WinFillRectangle(&inkr, 4);
        /* Show current page number */
        StrIToA(temp, p.dbI+1);
        StrNCat(temp, "/", 7);
        StrIToA(temp2, DmNumRecords(d.dbR));
        StrNCat(temp, temp2, 7);
        SetLabel(PageButton, temp);
    }
    LabelAlarm();
}

/*
** ClearImage - clear a new image record.
*/
inline static void ClearImage(void) {
    RectangleType rect;

    FlushToBuffer();
    WinSetDrawWindow(d.winbufM);
    RctSetRectangle(&rect, 0, 0, 160, 160);
    WinEraseRectangle(&rect, 0);
    WinSetDrawWindow(d.winM);
    recordSetBufDirty();
    LoadFromBuffer();
}

/*
** SketchIsEmpty - Determine if a given sketch is empty or not
**                 Assumes a non-busy-bit record handle is passed
*/
static Boolean SketchIsEmpty(VoidHand sketchHandle) {
    DiddleBugRecordType record;

    MemMove(&record, MemHandleLock(sketchHandle), sizeof(DiddleBugRecordType));
    MemHandleUnlock(sketchHandle);

    /* Take advantage of the fact that all whitespace is 106 bytes */
    return ((record.sketchLength == 106) && 
                    !(record.flags&RECORD_FLAG_ALARM_SET));
}

/*
** NewScratchImage - create a new scratch image or go to last empty one
*/
static void NewScratchImage(void) {
    VoidHand t;
    VoidPtr ptr;

    /* See if current sketch is empty */
    t = DmQueryRecord(d.dbR, p.dbI);
    if (!t) abort();
    if (SketchIsEmpty(t)) return;

    /* Get the highest numbered scratch sketch */
    p.dbI = DmNumRecords(d.dbR) - 1;
    if (p.dbI >= 0)
        t = DmQueryRecord(d.dbR, p.dbI);
    else {
        AllocImage();
        t = DmQueryRecord(d.dbR, p.dbI);
    }
    if (!t) abort();

    /* Create a new sketch if current one has black pixels */
    if (!SketchIsEmpty(t)) {
        p.dbI += 1;
        AllocImage();
    }
}

/*
** FillImage - fill a new image record
*/
static void FillImage(void) {
    RectangleType rect;

    FlushToBuffer();
    WinSetDrawWindow(d.winbufM);
    WinSetPattern(p.inkpat);
    RctSetRectangle(&rect, 0, 0, 160, 160);
    WinFillRectangle(&rect, 0);
    WinSetDrawWindow(d.winM);
    recordSetBufDirty();
    LoadFromBuffer();
}

/*
** InvertImage - XOR the current image, done on DB, rather than window
**               because window is sometimes obscured by titlebar
*/
static void InvertImage(void) {
    RectangleType rect;

    FlushToBuffer();
    WinSetDrawWindow(d.winbufM);
    RctSetRectangle(&rect, 0, 0, 160, 160);
    WinInvertRectangle(&rect, 0);
    WinSetDrawWindow(d.winM);
    recordSetBufDirty();
    LoadFromBuffer();
}


/*
** RemoveImage
*/
void RemoveImage(void) {
    DmRemoveRecord(d.dbR, p.dbI);
    if (p.dbI > 0) p.dbI--;
    else if (p.dbI == DmNumRecords(d.dbR)) AllocImage();
    LoadFromDisk();
    SetClosestAlarm(d.dbR);
}

/*
** NewSketch - create a new sketch after the current p.dbI
**             Will remain on the current sketch if empty
*/
static void NewSketch(void) {
    VoidHand t;

    SndPlaySystemSound(sndClick);
    FlushToDisk(true);
    /* SavImage(); */
    t = DmQueryRecord(d.dbR, p.dbI);
    if (!t) abort();
    if(!SketchIsEmpty(t)) {
        p.dbI += 1;
        AllocImage();
    }
    /* LodImage(); */
    LoadFromDisk();
}

/*
** TextMenuHandleEvent
** Handles menu events in the Insert Text dialog. (Lonnie)
*/
static Boolean TextMenuHandleEvent(Word menuID) {
    Boolean   handled = false;
    FormPtr   form = FrmGetActiveForm();
    FieldPtr  field;

    switch (menuID) {
    case menuitemID_XferUndo:
    case menuitemID_XferCut:
    case menuitemID_XferCopy:
    case menuitemID_XferPaste:
    case menuitemID_XferSelectAll:
        field = GetObjectPointer(form, TextField);
        if (!field)
            return false;
        if (menuID == menuitemID_XferUndo)
            FldUndo(field);
        else if (menuID == menuitemID_XferCut)
            FldCut(field);
        else if (menuID == menuitemID_XferCopy)
            FldCopy(field);
        else if (menuID == menuitemID_XferPaste)
            FldPaste(field);
        else if (menuID == menuitemID_XferSelectAll)
            FldSetSelection(field, 0, FldGetTextLength (field));
        return true;
        
    case menuitemID_XferKeyboard:
        SysKeyboardDialog(kbdDefault);
        return true;
        
    case menuitemID_XferGHelp:
        SysGraffitiReferenceDialog(referenceDefault);
        return true;
    }

    return false;
}

/*
** SendGotoEvent
*/
void SendGotoEvent(UInt recordNum) {
    EventType event;
    
    event.eType = frmGotoEvent;
    event.data.frmGoto.formID = d.formID;
    event.data.frmGoto.recordNum = recordNum;
    EvtAddEventToQueue(&event);
}

/*
** ModalEvent
*/
static Boolean ModalEvent(EventPtr e) {
    Boolean handled;

    handled = false;
    switch (e->eType) {
    case frmUpdateEvent:
        if (e->data.frmUpdate.updateCode == FRMUPDATE_DELETED_CURRENT) {
            EvtEnqueueKey(confirmChr, confirmChr, commandKeyMask);
            d.alarm_deleted_current = true;
            handled = true;
        }
        else if (e->data.frmUpdate.updateCode == FRMUPDATE_DELETED_ANY) {
            d.alarm_deleted_any = true;
            handled = true;
        }
        break;
    case menuEvent:
        handled = TextMenuHandleEvent(e->data.menu.itemID);
        break;
    case frmGotoEvent:
        EvtEnqueueKey(confirmChr, confirmChr, commandKeyMask);
        d.alarm_deleted_current = true;
        p.dbI = e->data.frmGoto.recordNum;
        handled = true;
        break;
    }

    return handled;
}

/*
** PriorModal - called before modal dialogs in the main form
*/
void PriorModal(UInt formID) {
    FlushToDisk(true);
    d.alarm_deleted_current = false;
    d.alarm_deleted_any = false;
    FrmSetEventHandler(FrmGetFormPtr(formID), ModalEvent);
    d.formID = formID;
}

/*
** PostModal - called after modal dialogs in the main form
*/
Boolean PostModal(FormPtr frm) {
    Boolean bail=false;
    /* Check if sketch was deleted during the dialog */
    if (d.alarm_deleted_current) {
        if (frm) FrmDeleteForm(frm);
        LoadFromDisk();
        LabelImage();
        bail=true;
    }
    if (d.alarm_deleted_any) LabelImage();
    d.formID = FrmGetActiveFormID();
    return bail;
}

/*
** DoTextPopup - Pop up the Insert text form
*/
static void DoTextPopup(void) {
    FormPtr frm;
    Word foi;     /* font pushbutton object index */
    ListPtr list;
    ControlPtr ctl;
    CharPtr str;
    Word button_pushed;

    frm = FrmInitForm(TextForm);

    /* Set the font pushbutton */
    switch (p.txt_font) {
        case boldFont:
            foi = TextBoldFontPush;
            break;
        case largeFont:
            foi = TextLargeFontPush;
            break;
        case stdFont: /* fall thru */
        default:
            foi = TextStdFontPush;
            break;
    }
    CtlSetValue(GetObjectPointer(frm, foi), true);
    /* Set the dropdown list selection */
    list = GetObjectPointer(frm, TextModeList);
    LstSetSelection(list, p.txt_mode);
    str = LstGetSelectionText(list, p.txt_mode);
    CtlSetLabel(GetObjectPointer(frm, TextModePop), str);
    /* Set the focus to the text field */
    FrmSetFocus(frm, FrmGetObjectIndex(frm, TextField));

    PriorModal(TextForm);
    button_pushed = FrmDoDialog(frm);
    if (PostModal(frm)) return;

    if (TextInsertButton == button_pushed) {
        /* Get the font to use */
        ctl = GetObjectPointer(frm, TextStdFontPush);
        if (CtlGetValue(ctl)) p.txt_font = stdFont;
        ctl = GetObjectPointer(frm, TextBoldFontPush);
        if (CtlGetValue(ctl)) p.txt_font = boldFont;
        ctl = GetObjectPointer(frm, TextLargeFontPush);
        if (CtlGetValue(ctl)) p.txt_font = largeFont;

        /* Get the text insertion mode */
        list = GetObjectPointer(frm, TextModeList);
        p.txt_mode = LstGetSelection(list);

        /* Copy text to insert into d.InsertionText */
        str = FldGetTextPtr(GetObjectPointer(frm, TextField));
        d.InsertionText[0] = 0; /* just to make sure... */
        if (str) {
            StrNCopy(d.InsertionText, str, 31);
            /* Signal the new mode for the Pen Handler */
            if (StrLen(d.InsertionText) > 0) {
                d.drawmode = MODE_TEXT;
                d.last_insert = d.drawmode;
            }
            d.txt_oldfont = FntSetFont(p.txt_font);
        }
        /* We rely on the Pen Queue being empty here */
        EvtFlushPenQueue(); 
    }

    /* Cleanup */
    FrmDeleteForm(frm);
}

/*
** DoShapePopup - Popup the Insert Shape form
*/
void DoShapePopup(void) {
    FormPtr frm;
    ListPtr list;
    CharPtr str;
    Word button_pressed;

    frm = FrmInitForm(ShapeForm);

    /* Set the dropdown list selections */
    list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,ShapeTypeList));
    LstSetSelection(list, p.shape_type);
    str = LstGetSelectionText(list, p.shape_type);
    CtlSetLabel(FrmGetObjectPtr(frm,FrmGetObjectIndex(frm,ShapeTypePop)), str);
    list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,ShapeFillList));
    LstSetSelection(list, p.shape_fill);
    str = LstGetSelectionText(list, p.shape_fill);
    CtlSetLabel(FrmGetObjectPtr(frm,FrmGetObjectIndex(frm,ShapeFillPop)), str);

    /* Show the form */
    PriorModal(ShapeForm);
    button_pressed = FrmDoDialog(frm);
    if (PostModal(frm)) return;

    if (ShapeInsertButton == button_pressed) {
        /* Set shape info based on list selection */
        list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,ShapeTypeList));
        p.shape_type = LstGetSelection(list);
        if (p.shape_type == -1) p.shape_type = 0;
        /* Set fill info based on list selection */
        list = FrmGetObjectPtr(frm, FrmGetObjectIndex(frm,ShapeFillList));
        p.shape_fill = LstGetSelection(list);
        if (p.shape_fill == -1) p.shape_fill = 0;
        /* Enter shape mode */
        EvtFlushPenQueue();  /* Pen queue must be empty */
        d.drawmode = MODE_SHAPE;
        d.last_insert = d.drawmode;
    }

    /* Cleanup */
    FrmDeleteForm(frm);
}

/*
** CustomListDrawFunc - draw the numbers in the custom time form
*/
static void CustomListDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    Char str[6];

    CALLBACK_PROLOGUE

    StrIToA(str, item);
    WinDrawChars(str, StrLen(str), b->topLeft.x, b->topLeft.y);

    CALLBACK_EPILOGUE
}

/*
** DoCustomTimePopup - Pop up the custom time for for weird people
*/
static ULong DoCustomTimePopup(void) {
    FormPtr frm;
    ListPtr list;
    Word button_pressed;
    Word list_selection;
    ULong ret;

    frm = FrmInitForm(CustomTimeForm);

    /* Initialize the lists */
    list = GetObjectPointer(frm, CustomHourList);
    LstSetListChoices(list, NULL, 24);
    LstSetDrawFunction(list, CustomListDrawFunc);
    LstSetSelection(list, 0);
    list = GetObjectPointer(frm, CustomMinuteList);
    LstSetListChoices(list, NULL, 60);
    LstSetDrawFunction(list, CustomListDrawFunc);
    LstSetSelection(list, 0);
    list = GetObjectPointer(frm, CustomSecondList);
    LstSetListChoices(list, NULL, 60);
    LstSetDrawFunction(list, CustomListDrawFunc);
    LstSetSelection(list, 0);

    PriorModal(CustomTimeForm);
    button_pressed = FrmDoDialog(frm);
    if (PostModal(frm)) return 0;

    /* Get the values from the form */
    if (CustomOkButton == button_pressed) {
        ret = 0;
        list = GetObjectPointer(frm, CustomHourList);
        list_selection = LstGetSelection(list);
        if (list_selection != -1);
            ret += 60L * 60L * list_selection;
        list = GetObjectPointer(frm, CustomMinuteList);
        list_selection = LstGetSelection(list);
        if (list_selection != -1);
            ret += 60L * list_selection;
        list = GetObjectPointer(frm, CustomSecondList);
        list_selection = LstGetSelection(list);
        if (list_selection != -1);
            ret += list_selection;
    }
    else ret = 0;

    /* Cleanup */
    FrmDeleteForm(frm);
    return ret;
}

/*
** Load a pen pattern
*/
inline static void LoadPen(short selection) {
    StrCopy(p.penpix, d.penpixList[selection]);
    if (p.modeSelection == SEL_MODE_ERASE)
        p.erasePenSelection = selection;
    else
        p.penSelection = selection;
    d.undo_mark = true;
}

/*
** Random integer in the range 0..(n-1).
*/
inline static UInt RandomLessThan(UInt n) {
    return SysRandom(0) / (1+sysRandomMax/n);
}

/*
** Load an ink pattern
*/
static void LoadInk(short selection) {
    if (selection != SEL_INK_RANDOM) {
        /* Load the specified ink pattern */
        p.inkSelection = selection;
        ((long *)(p.inkpat))[0] = ((long *)d.inkList[selection])[0];
        ((long *)(p.inkpat))[1] = ((long *)d.inkList[selection])[1];
    } else {
        unsigned i, id, im, ib, j, jd, jm, jb;

        SysRandom(((long *)p.inkpat)[0]+((long *)p.inkpat)[1]);
        for (i = 0; i < 64; i += 1) {
            j = i + RandomLessThan(64-i);
            ib = p.inkpat[id = i/16] & (im = 1<<(i%16));
            jb = p.inkpat[jd = j/16] & (jm = 1<<(j%16));
            if (ib)
                p.inkpat[jd] |= jm;
            else
                p.inkpat[jd] &= ~jm;
            if (jb)
                p.inkpat[id] |= im;
            else
                p.inkpat[id] &= ~im;
        }
    }
    WinSetPattern(p.inkpat);
    p.modeSelection = SEL_MODE_PAINT;
    d.undo_mark = true;
}

/*
** LockAsk - Ask the user if the sketch should be unlocked
*/
static Boolean LockAsk(void) {

    if (!recordIsLocked) return false;

    /* SavImage();  alarm insurance */
    FlushToBuffer();
    if (!FrmAlert(LockAskForm)) {
        recordUnlock();
        FlushToDisk(false);
        LabelAlarm();
    }
    else d.drawmode = MODE_DOODLE;
    d.lock_count = 0;

    return true;
}

/*
** LockWarn - Beep at the user and increment the lock count
*/
static void LockWarn(void) {
    if (d.lock_count < 2) {
        SndPlaySystemSound(sndWarning);
        d.lock_count++;
    }
    else {
        LockAsk();
        EvtFlushPenQueue();  /* Leftover penMoves and penUps */
    }
}

/*
** ShortCutPop - handle selection of shortcut menu
*/
static void ShortCutPop(enum sc_locations sc_location) {
    ListPtr list;
    FormPtr frm;
    short selection;
    
    frm = FrmGetFormPtr(p.formID);
    if (!frm) return;
    list = GetObjectPointer(frm, PopShortcutList);

    list->bounds.extent.x = d.shortcut_width;
    if (sc_location == low) {
        LstSetPosition(list, 157-d.shortcut_width, 97);
    }
    else LstSetPosition(list, 3, 15);
    LstSetSelection(list, -1);

    selection = LstPopupList(list);
    if (-1 == selection) return;

    switch (selection) {
        case SCUT_LINE:
            EvtFlushPenQueue();
            d.drawmode = MODE_LINE;
            d.last_insert = d.drawmode;
            return;
            break;
        case SCUT_RECTANGLE:
            p.shape_type = SHAPE_RECTANGLE;
            break;
        case SCUT_ROUNDRECT:
            p.shape_type = SHAPE_ROUNDRECT;
            break;
        case SCUT_OVAL:
            p.shape_type = SHAPE_OVAL;
            break;
        case SCUT_CIRCLE:
            p.shape_type = SHAPE_CIRCLE;
            break;
        case SCUT_TEXT:
            DoTextPopup();
            return;
            break;
        default:
            break;
    }
    /* Handle the common code for shape events here */
    EvtFlushPenQueue();  /* Pen queue must be empty */
    d.drawmode = MODE_SHAPE;
    d.last_insert = d.drawmode;
}

/*
** DoCmdRemove
*/
void DoCmdRemove(void) {
    if (recordIsLocked) {
        if (!FrmAlert(ConfirmLockedDelete)) RemoveImage();
    }
    else if (p.flags&PFLAGS_CONFIRM_DELETE) {
        if (!FrmAlert(ConfirmDeleteForm)) RemoveImage();
    }
    else RemoveImage();
}

/*
** ScrollXferField
*/
static void ScrollXferField(DirectionType direction) {
    FormPtr frm;
    FieldPtr fld;

    frm = FrmGetActiveForm();
    fld = GetObjectPointer(frm, XferField);
    if (FldScrollable(fld, direction)) {
        FldScrollField(fld, 1, direction);
    }
    else {
        SndPlaySystemSound(sndWarning);
    }
}

/*
** Act on a key (or menu event) received.
*/
static Boolean KeyDown(Word chr) {

    /* Do not capture keystrokes when in transfer mode */
    if (d.is_xfer_mode) {
        switch (chr) {
            case pageUpChr:
                ScrollXferField(up);
                return true;
                break;
            case pageDownChr:
                ScrollXferField(down);
                return true;
                break;
        }
        return false;
    }

    /* Map command character to lower case */
    if (chr >= 'A' && chr <= 'Z')
        chr += 'a'-'A';

    /* Dispatch on character */
    switch (chr) {

    case penFine:		LoadPen(SEL_PEN_FINE); break;
    case penMedium:	LoadPen(SEL_PEN_MEDIUM); break;
    case penBold: LoadPen(SEL_PEN_BOLD); break;
    case penBroad:	LoadPen(SEL_PEN_BROAD); break;
    case penFineItalic:	LoadPen(SEL_PEN_FITALIC); break;
    case penMediumItalic: LoadPen(SEL_PEN_MITALIC); break;
    case penBroadItalic:  LoadPen(SEL_PEN_BITALIC); break;

    case inkWhite:  LoadInk(SEL_INK_WHITE); break;
    case inkDith12: LoadInk(SEL_INK_1_8); break;
    case inkDith25: LoadInk(SEL_INK_2_8); break;
    case inkDith37: LoadInk(SEL_INK_3_8); break;
    case inkDith50: LoadInk(SEL_INK_4_8); break;
    case inkDith62: LoadInk(SEL_INK_5_8); break;
    case inkDith75: LoadInk(SEL_INK_6_8); break;
    case inkDith87: LoadInk(SEL_INK_7_8); break;
    case inkBlack:  LoadInk(SEL_INK_BLACK); break;
    case inkRandom: LoadInk(SEL_INK_RANDOM); break;

    case modePaint:
        p.modeSelection = SEL_MODE_PAINT;
        KeyDown(penDropList[p.penSelection]);
        FlushToBuffer();
        break;
    case modeSmear:
        p.modeSelection = SEL_MODE_SMEAR;
        KeyDown(penDropList[p.penSelection]);
        FlushToBuffer();
        break;
    case modeErase:
        p.modeSelection = SEL_MODE_ERASE;
        KeyDown(penDropList[p.erasePenSelection]);
        FlushToBuffer();
        break;

    case cmdRough:
        p.filt = 1;
        p.filtSelection = SEL_FILT_ROUGH;
        FlushToBuffer();
        break;

    case cmdSmooth:
        p.filt = 8;
        p.filtSelection = SEL_FILT_SMOOTH;
        FlushToBuffer();
        break;

    case cmdSmoother:
        p.filt = 16;
        p.filtSelection = SEL_FILT_SMOOTHER;
        FlushToBuffer();
        break;

    case cmdAbout:
        FlushToDisk(true);
        FrmAlert(AboutForm);
        break;

    case cmdPref:
        FlushToDisk(true);
        FrmGotoForm(PrefForm);
        break;

    case cmdTitle:
        FlushToDisk(true);
        FrmGotoForm(p.formID == DiddleForm ? DiddleTForm : DiddleForm);
        break;

    case cmdClear:
        LockAsk();
        if ((!recordIsLocked) &&  ((!(p.flags&PFLAGS_CONFIRM_CLEAR)) ||
                                (!FrmAlert(ConfirmClearForm)))) {
            ClearImage();
            LoadFromBuffer();
        }
        break;

    case cmdFill:
        LockAsk();
        if ((!recordIsLocked) && ((!(p.flags&PFLAGS_CONFIRM_CLEAR)) ||
                                (!FrmAlert(ConfirmFillForm)))){
            FillImage();
            LoadFromBuffer();
        }
        break;

    case cmdInvert:
        LockAsk();
        if (!recordIsLocked) {
            FlushToBuffer();
            InvertImage();
            LoadFromBuffer();
        }
        /* Override for a test - FIXME
        {
            WinHandle someH;
            Word ack;
            VoidPtr someptr, winPtr;
            VoidHand rH;
            RectangleType somerect;
            Int i;
            ack = 0;
            someH = WinCreateOffscreenWindow(20, 20, genericFormat, &ack);
            if (ack) abort();
            rH = DmQueryRecord(d.dbR, p.dbI);
            if (!rH) abort();
            someptr = MemHandleLock(rH);
            RctSetRectangle(&somerect, 0, 0, 20, 20);
            MemMove(WinGetWindowPointer(someH)->displayAddr,
                            someptr+sketchDataOffset, sketchThumbnailSize);
            WinCopyRectangle(someH, d.winM, &somerect, 0, p.r.topLeft.y,
                                scrCopy);
            WinDeleteWindow(someH, false);
            MemHandleUnlock(rH);
        }
        */
        break;

    case cmdSketchUndo:
        if (recordIsDirty) {
            LockAsk();
            if ((!recordIsLocked) && ((!(p.flags&PFLAGS_CONFIRM_CLEAR)) ||
                                    (!FrmAlert(ConfirmUndoForm)))){
                LoadFromBuffer();
            }
        }
        else {
            FlashWaitMessage(NoUndoString);
        }
        break;

    case cmdText:
        DoTextPopup();
        break;

    case cmdLine:
        LockAsk();
        if (!recordIsLocked) {
            EvtFlushPenQueue();
            d.drawmode = MODE_LINE;
            d.last_insert = d.drawmode;
        }
        break;

    case cmdShape:
        LockAsk();
        if (!recordIsLocked) {
            FlushToBuffer();
            DoShapePopup();
        }
        break;

    case cmdInsertLast:
        LockAsk();
        if (!recordIsLocked) {
            EvtFlushPenQueue();
            d.drawmode = d.last_insert;
            if (d.drawmode == MODE_TEXT) d.txt_oldfont = FntSetFont(p.txt_font);
            SndPlaySystemSound(sndClick);
        }
        break;

    case cmdNew:
        NewSketch();
        break;

    case cmdLock:
        SndPlaySystemSound(sndClick);
        recordLock();
        d.lock_count = 0;
        FlushToDisk(true);
        break;

    case cmdRemove:
        DoCmdRemove();
        break;

    case cmdPrevious:
    case prevFieldChr:
    case pageUpChr: {
            int n = DmNumRecords(d.dbR);
            SndPlaySystemSound(sndClick);
            FlushToDisk(true);
            if (p.dbI <= 0) p.dbI = n-1;
            else p.dbI--;
            LoadFromDisk();
            break;
        }

    case cmdNext:
    case nextFieldChr:
    case pageDownChr:
        SndPlaySystemSound(sndClick);
        FlushToDisk(true);
        if (p.dbI >= (DmNumRecords(d.dbR)-1)) p.dbI = 0;
        else p.dbI++;
        LoadFromDisk();
        break;

    case cmdTransfer:
        SndPlaySystemSound(sndClick);
        StartXferMode();
        break;

    case sendDataChr:
    case cmdBeam:
        BeamSend();
        break;

    }
    LabelImage();
    return true;
}

/*
** External KeyDown_
*/
Boolean KeyDown_(Word chr) {
    return KeyDown(chr);
}

/*
** BDropDrawFunc
*/
static void BDropDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    CALLBACK_PROLOGUE
    if (d.dropList.type == DROPLIST_TYPE_BITMAP)
        DrawBitmapLabel(d.dropList.iconRsc+item, b->topLeft.x, b->topLeft.y+1);
    else if (d.dropList.type == DROPLIST_TYPE_PEN)
        DrawPenLabel(d.penpixList[item], b->topLeft.x, b->topLeft.y+1);
    else if (d.dropList.type == DROPLIST_TYPE_INK)
        DrawInkLabel(d.inkList[item], b->topLeft.x, b->topLeft.y+1,
                        (item == p.inkSelection));
    WinDrawChars(text[item], StrLen(text[item]), b->topLeft.x+17, b->topLeft.y);
    CALLBACK_EPILOGUE
}

/*
** ButtonDrop - show drop-down list for titlebar buttons
*/
Boolean ButtonDrop(Word ctlID) {
    FormPtr frm;
    ListPtr list;
    Word list_position;
    UInt button_num, i;
    short list_selection;
    SWord list_left_edge;
    short current_selection;
    UInt *droplist;
    Word listRsc;

    frm = FrmGetActiveForm();
    switch (ctlID) {
        case ModeButton:
            listRsc = MainModeList;
            d.dropList.type = DROPLIST_TYPE_BITMAP;
            d.dropList.iconRsc = CmdPaintBitmap;
            droplist = modeDropList;
            current_selection = p.modeSelection;
            button_num = 0;
            break;
        case SmoothButton:
            listRsc = MainSmoothList;
            d.dropList.type = DROPLIST_TYPE_BITMAP;
            d.dropList.iconRsc = CmdRoughBitmap;
            droplist = smoothDropList;
            current_selection = p.filtSelection;
            button_num = 1;
            break;
        case PenButton:
            listRsc = MainPenList;
            d.dropList.type = DROPLIST_TYPE_PEN;
            droplist = penDropList;
            if (p.modeSelection == SEL_MODE_ERASE)
                current_selection = p.erasePenSelection;
            else
                current_selection = p.penSelection;
            button_num = 2;
            break;
        case InkButton:
            listRsc = MainInkList;
            d.dropList.type = DROPLIST_TYPE_INK;
            droplist = inkDropList;
            current_selection = p.inkSelection;
            button_num = 3;
            break;
        default:
            return false;
            break;
    }
    /* Set the list width, location and selection */
    list = GetObjectPointer(frm, listRsc);
    LstSetDrawFunction(list, BDropDrawFunc);
    list_left_edge = (40-3) + (button_num*16);
    if (!d.dropList.dropListWidth[button_num])
        d.dropList.dropListWidth[button_num] = GetListWidth(list)+15;
    if (d.dropList.dropListWidth[button_num] > (159-list_left_edge))
        list_left_edge = 159-d.dropList.dropListWidth[button_num];
    list->bounds.extent.x = d.dropList.dropListWidth[button_num];
    LstSetPosition(list, list_left_edge, 14);
    LstSetSelection(list, current_selection);
    /* Popup the list and handle the result */
    list_selection = LstPopupList(list);
    if (list_selection != -1) {
        return KeyDown(droplist[list_selection]);
    }

    return false;
}

/*
** Clear the pen state.
*/
static void DiddlePenClear(void) {
    d.nwts = d.wx = d.wy = 0;
    MemSet(d.wts, sizeof(d.wts), 0);
}

/*
** Act on a diddle pen event.
*/
static void DiddlePenEvent(short nx, short ny) {
    short i, dx, dy;

    /* Draw the lines defined by the pen */
    for (i = 0; i < NPENPIX && p.penpix[i] != 0; i += 1) {
        dx = dxFromPenpix(p.penpix[i]);
        dy = dyFromPenpix(p.penpix[i]);
        if ( ! rctPtInRectangle(d.ox+dx, d.oy+dy, &p.r))
            continue;
        if ( ! rctPtInRectangle(nx+dx, ny+dy, &p.r))
            continue;
        if (p.modeSelection == SEL_MODE_SMEAR)
            WinInvertLine(d.ox+dx, d.oy+dy, nx+dx, ny+dy);
        else
            WinFillLine(d.ox+dx, d.oy+dy, nx+dx, ny+dy);
    }
    d.ox = nx;
    d.oy = ny;
}

/*
** DoStroke - a starting or continuing pen stroke while doodling
*/
static void DoStroke(SWord x, SWord y) {
    unsigned short n;

    /* Update sum of coordinates */
    n = (d.nwts-p.filt)%NPENWTS;
    d.wx += x - d.wts[n].x;
    d.wy += y - d.wts[n].y;

    /* Update array of coordinates */
    n = d.nwts%NPENWTS;
    d.wts[n].x = x;
    d.wts[n].y = y;

    /* Send averaged coordinate */
    n = (d.nwts >= p.filt) ? p.filt : d.nwts+1;
    DiddlePenEvent(d.wx/n, d.wy/n);

    /* Update count of coordinates */
    d.nwts += 1;
}

/*
** EndStroke - end a pen stroke while doodling
*/
static void EndStroke(void) {
    short i;
    unsigned short n;

    /* Drain queue */
    for (i = (d.nwts < p.filt) ? d.nwts : p.filt; --i > 0; ) {
        n = (d.nwts-i-1)%NPENWTS;
        d.wx -= d.wts[n].x;
        d.wy -= d.wts[n].y;
        DiddlePenEvent(d.wx/i, d.wy/i);
    }
    /* Clear state */
    DiddlePenClear();
}

/*
** ClearOldText() - clean up the textual doggie-doos left while placing text
*/
inline static void ClearOldText(void) {
    WinInvertChars(d.InsertionText, StrLen(d.InsertionText), d.ox, d.oy);
}

/*
** DoTextInsert - a starting or continuing pen stroke while dragging text
*/
static void DoTextInsert(SWord x, SWord y) {
    WinInvertChars(d.InsertionText, StrLen(d.InsertionText), x, y);
    d.ox = x;
    d.oy = y;
}

/*
** EndTextInsert - Place the final text when user lifts pen
*/
static void EndTextInsert(SWord x, SWord y) {
     RectangleType rect;

     /* Size the rectangle */
     rect.topLeft.x = x - 3;
     rect.topLeft.y = y;
     rect.extent.x = FntCharsWidth(d.InsertionText, StrLen(d.InsertionText))
                        +6;
     rect.extent.y = FntCharHeight();


    /* Draw the text background first */
    switch (p.txt_mode) {
        case TXT_BLACKONWHITE:
            WinEraseRectangle(&rect, 3);
            break;
        case TXT_WHITEONBLACK:
            WinDrawRectangle(&rect, 3);
            break;
        case TXT_BLACK:
        case TXT_XOR:
        default:
            break; /* No background for TXT_BLACK or TXT_XOR */
    }

    /* Now draw the text */
    if (TXT_BLACK == p.txt_mode) {
        /* For some reason WinDrawChars was erasing the background... */
        /* This is a prime example of a kludge */
        WinEraseChars(d.InsertionText, StrLen(d.InsertionText), x, y);
        WinInvertChars(d.InsertionText, StrLen(d.InsertionText), x, y);
    }
    else {
        WinInvertChars(d.InsertionText, StrLen(d.InsertionText), x, y);
    }

    /* Clean up */
    d.drawmode = MODE_DOODLE;
    FntSetFont(d.txt_oldfont);
}

/*
** ClearOldLine - Remove the xor'd line for rubber-banding
*/
inline static void ClearOldLine(void) {
    WinInvertLine(d.anchor.x, d.anchor.y, d.ox, d.oy);
}

/*
** DoLine - Draw rubber band line
*/
static void DoLine(SWord x, SWord y) {
    /* Draw the line */
    WinInvertLine(d.anchor.x, d.anchor.y, x, y);

    d.ox = x;
    d.oy = y;
}

/*
** EndLine - Place the final line on the drawing
*/
static void EndLine(SWord x, SWord y) {
    short dx, dy, i;

    /* Draw the lines defined by the pen */
    for (i = 0; i < NPENPIX && p.penpix[i] != 0; i += 1) {
        dx = dxFromPenpix(p.penpix[i]);
        dy = dyFromPenpix(p.penpix[i]);
        if ( ! rctPtInRectangle(x+dx, y+dy, &p.r))
            continue;
        if ( ! rctPtInRectangle(d.anchor.x+dx, d.anchor.y+dy, &p.r))
            continue;
        if (p.modeSelection == SEL_MODE_SMEAR)
            WinInvertLine(d.anchor.x+dx, d.anchor.y+dy, x+dx, y+dy);
        else if (p.modeSelection == SEL_MODE_ERASE)
            WinEraseLine(d.anchor.x+dx, d.anchor.y+dy, x+dx, y+dy);
        else
            WinFillLine(d.anchor.x+dx, d.anchor.y+dy, x+dx, y+dy);
    }

    d.drawmode = MODE_DOODLE; /* Clean up */
}

/*
** CountdownStuff - Load the countdown list, or execute an action
*/
static void CountdownStuff(UInt listnum, Boolean action, CharPtr text) {
    ULong future_seconds;
    Int minutes;
    Int hours;
    ULong days; /* Big only to prevent compiler warning of Integer overflow */
    Char tempStr[15];

    future_seconds = 0;
    minutes = 0;
    hours = 0;
    days = 0;
    switch (listnum) {

    case 0: /* OFF */
        if (action) {
            d.record.alarmSecs = 0;
            d.record.repeatSecs = 0;
            if (recordIsAlarmSet) {
                recordUnsetAlarm();
                FlushToDisk(false);
                SetClosestAlarm(d.dbR);
            }
            recordUnsetAlarm();
            LabelAlarm();
        }
        else SysCopyStringResource(text, OffString);
        break;
    case 1: /* Absolute... */
        if (action) {
            recordUnsetCountdown();
            FrmGotoForm(TimeForm);
        }
        else SysCopyStringResource(text, AbsoluteString);
        break;
    case 2: /* Custom... */
        if (action) {
            future_seconds = DoCustomTimePopup();
        }
        else SysCopyStringResource(text, CustomString);
        break;
    case 3: /* 1 min */
    case 4: /* 2 min */
    case 5: /* 3 min */
    case 6: /* 4 min */
    case 7: /* 5 min */
        minutes = listnum - 2;
        break;
    case 8: /* 10 min */
    case 9: /* 15 min */
    case 10: /* 20 min */
        minutes = 5 * (listnum - 6);
        break;
    case 11: /* 30 min */
        minutes = 30;
        break;
    case 12: /* 45 min */
        minutes = 45;
        break;
    case 13: /* 1 hr */
        hours = 1;
        break;
    case 14: /* 1.5 hr */
        if (action) minutes =  90;
        else {
            StrCopy(text, "1.5");
            SysCopyStringResource(tempStr, HoursString);
            StrNCat(text, tempStr, 14);
        }
        break;
    case 15: /* 2 hr */
    case 16: /* 3 hr */
    case 17: /* 4 hr */
    case 18: /* 5 hr */
        hours = listnum - 13;
        break;
    case 19: /* 8 hr */
        hours = 8;
        break;
    case 20: /* 10 hr */
        hours = 10;
        break;
    case 21: /* 12 hr */
        hours = 12;
        break;
    case 22: /* 1 day */
    case 23: /* 2 days */
    case 24: /* 3 days */
    case 25: /* 4 days */
    case 26: /* 5 days */
    case 27: /* 6 days */
        days = listnum - 21;
        break;
    case 28: /* 1 week */
    case 29: /* 2 weeks */
        if (action) days = (listnum - 27) * 7;
        else {
            if (listnum == 28) SysCopyStringResource(tempStr, WeekString);
            else SysCopyStringResource(tempStr, WeeksString);
            StrIToA(text, (listnum-27));
            StrNCat(text, tempStr, 14);
        }
        break;
    }
    if (minutes) {
        if (action) future_seconds = 60L * minutes;
        else {
            StrIToA(text, minutes);
            if (minutes == 1) SysCopyStringResource(tempStr, MinString);
            else SysCopyStringResource(tempStr, MinsString);
            StrNCat(text, tempStr, 14);
        }
    }
    else if (hours) {
        if (action) future_seconds = 60L * 60L * hours;
        else {
            StrIToA(text, hours);
            if (hours == 1) SysCopyStringResource(tempStr, HourString);
            else SysCopyStringResource(tempStr, HoursString);
            StrNCat(text, tempStr, 14);
        }
    }
    else if (days) {
        if (action) future_seconds = days * 24L * 60L * 60L;
        else {
            StrIToA(text, days);
            if (days == 1) SysCopyStringResource(tempStr, DayString);
            else SysCopyStringResource(tempStr, DaysString);
            StrNCat(text, tempStr, 14);
        }
    }
    if (action && future_seconds) {
        /* Set the alarm for future_secons into the future */
        recordSetAlarm();
        recordSetCountdown(); /* belt and suspenders */
        d.record.repeatMode = REPEAT_NONE;
        d.record.repeatSecs = 0;
        d.record.alarmSecs = TimGetSeconds() + future_seconds;
        FlushToDisk(false);
        SetClosestAlarm(d.dbR);
        LabelAlarm();
    }
    if (recordIsAlarmSet && recordIsCountdown) {
        /* Go into high battery, constant update mode */
        d.NextPeriod = TimGetTicks() + 100;
    }
}

/*
** GetAlarmSelectListWidth
*/
SWord GetAlarmSelectListWidth(void) {
    UInt i;
    FontID oldfont;
    SWord text_width=0, list_width=0;
    Char str[20];

    oldfont = FntSetFont(stdFont);
    for (i=0; i<30; i++) {
        CountdownStuff(i, false, str);
        if (str) {
            text_width = FntLineWidth(str, StrLen(str));
            if (text_width > list_width)
                list_width = text_width;
        }
    }
    FntSetFont(oldfont);
    list_width += 4;

    return list_width;
}

/*
** HardwareActionDrawFunc
*/
static void HardwareActionDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    SysDBListItemType *app;
    Char str [64];

    CALLBACK_PROLOGUE

    if (item > 1) {
        app = d.papplist+(item-2);
        SysCopyStringResource(str, LaunchString);
        StrNCat(str, app->name, 63);
    }
    else if (item == 1) {
        SysCopyStringResource(str, NextSketchString);
    }
    else {
        SysCopyStringResource(str, NewReminderString);
    }
    str[63] = nullChr;

    WinDrawChars(str, StrLen(str), b->topLeft.x, b->topLeft.y);
    CALLBACK_EPILOGUE
}

/*
** CountdownDrawFunc - draw the countdown items in the list
*/
static void CountdownDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    Char str[20];

    CALLBACK_PROLOGUE

    CountdownStuff(item, false, str);
    WinDrawChars(str, StrLen(str), b->topLeft.x, b->topLeft.y);

    CALLBACK_EPILOGUE
}

/*
** HourListDrawFunc - draw the hours in the selection list
*/
static void HourListDrawFunc(UInt item, RectanglePtr b, CharPtr* text) {
    Char str[4];
    UInt hour;

    CALLBACK_PROLOGUE

    switch (d.sysPrefs.timeFormat) {
        case tfColonAMPM:
        case tfDotAMPM:
        case tfHoursAMPM:
            hour = item % 12;
            if ( 0 == item )
                StrCopy(str, "12A");
            else if ( 12 == item )
                StrCopy(str, "12P");
            else
                StrIToA(str, hour);
            break;
        default:
            StrIToA(str, item);
            break;
    }
    WinDrawChars(str, StrLen(str), b->topLeft.x, b->topLeft.y);

    CALLBACK_EPILOGUE
}

/*
** DoDateSelect - handle selection of the Alarm Selection Trigger
*/
static void DoDateSelect(short x) {
    FormPtr frm;
    ListPtr list;
    short list_choice;
    short position;
    short halfwidth;

    /* Pop up the quicklist for relative times */
    frm = FrmGetActiveForm();
    list = GetObjectPointer(frm, PopCountdownList);
    LstSetListChoices(list, NULL, 30);
    halfwidth = d.alarm_select_width / 2;
    position = x-halfwidth;
    if (position < 38) position = 38;
    if (position > (147-d.alarm_select_width))
        position = 147-d.alarm_select_width;
    LstSetPosition(list, position, 24);
    list->bounds.extent.x = d.alarm_select_width;
    LstSetSelection(list, -1);
    LstSetDrawFunction(list, CountdownDrawFunc);
    list_choice = LstPopupList(list);
    if (list_choice != -1) {
        CountdownStuff(list_choice, true, NULL);
    }
}

/*
** SetCurrentTimeLabel - set time on Date Select form
*/
static void SetCurrentTimeLabel(FormPtr frm) {
    DateTimeType current_time;
    Char timStr[15];

    /* Could be called while popup dialogs are in effect */
    if (FrmGetActiveFormID() != TimeForm) return;

    /* Set the current time label */
    TimSecondsToDateTime(TimGetSeconds(), &current_time);
    SysCopyStringResource(d.CurrentTimeStr, current_time.weekDay + SunString);
    // StrCopy(d.CurrentTimeStr, Weekday[current_time.weekDay]);
    TimeToAscii(current_time.hour, current_time.minute,
                    d.sysPrefs.timeFormat, timStr);
    StrNCat(d.CurrentTimeStr, ", ", 20);
    StrNCat(d.CurrentTimeStr, timStr, 20);
    FrmHideObject(frm, FrmGetObjectIndex(frm, TimeCurrentLabel));
    FrmCopyLabel(frm, TimeCurrentLabel, d.CurrentTimeStr);
    FrmShowObject(frm, FrmGetObjectIndex(frm, TimeCurrentLabel));
}

/*
** LoadDateData - preset the Alarm Details form with current data
*/
static void LoadDateData(void) {
    FormPtr frm;
    ControlPtr ctl;
    ListPtr list;
    CharPtr str;
    ULong time_secs;
    SWord extra_time;
    Char dteStr[15];
    Word i, weekDayID;

    frm = FrmGetActiveForm();
    ctl = GetObjectPointer(frm, TimeSetCheck);
    if (recordIsAlarmSet) {
        time_secs = d.record.alarmSecs;
        /* Set the Alarm Set checkbox */
        CtlSetValue(ctl, true);
    }
    else {
        /* Set the Alarm Set checkbox */
        CtlSetValue(ctl, false);
        /* Get the current time */
        time_secs = TimGetSeconds();
    }
    /* Get a DateTimeType from the seconds */
    TimSecondsToDateTime(time_secs, &(d.frm_date));
    /* Truncate to the nearest 5 minutes */
    d.frm_date.second = 0;
    extra_time = d.frm_date.minute % 5;
    d.frm_date.minute = d.frm_date.minute - extra_time;
    /* Then increment by 5 minutes */
    if (extra_time) TimAdjust(&(d.frm_date), 300);

    /* Adjust the weekday controlgroup boxes if necessary */
    if (d.sysPrefs.weekStartDay) {
        /* Monday is the first day of the week */
        ctl = GetObjectPointer(frm, TimeSunPush);
        ctl->bounds.topLeft.x += 72;
        for (i=1; i<7; i++) {
            weekDayID = i + TimeSunPush;
            ctl = GetObjectPointer(frm, weekDayID);
            ctl->bounds.topLeft.x -= 12;
        }
    }
    /* Now set the day-of-week pushbutton */
    FrmSetControlGroupSelection(frm, 1, TimeSunPush+d.frm_date.weekDay);
    /* Label the explicit date pushbutton */
    DateToAscii(d.frm_date.month, d.frm_date.day, d.frm_date.year,
                    d.sysPrefs.longDateFormat, dteStr);
    ctl = GetObjectPointer(frm, TimeDatePush);
    StrNCopy(ctl->text, dteStr, 14);
    /* Set the hour list */
    list = GetObjectPointer(frm, TimeHoursList);
    LstSetListChoices(list, NULL, 24);
    LstSetDrawFunction(list, HourListDrawFunc);
    LstSetSelection(list, d.frm_date.hour);
    LstSetTopItem(list, d.frm_date.hour);
    /* Set the minutes list */
    list = GetObjectPointer(frm, TimeMinutesList);
    LstSetSelection(list, d.frm_date.minute/5);
    /* Set the repeat drop-down list */
    list = GetObjectPointer(frm, TimeRepeatList);
    LstSetSelection(list, d.record.repeatMode);
    str = LstGetSelectionText(list, d.record.repeatMode);
    ctl = GetObjectPointer(frm, TimeRepeatPop);
    CtlSetLabel(ctl, str);
    /* Set the current-time label */
    SetCurrentTimeLabel(frm);
}

/*
** SaveDateData - Save all data from the date/time selection dialog
*/
static void SaveDateData(void) {
    FormPtr frm;
    ControlPtr ctl;
    ListPtr list;
    VoidHand t;
    VoidPtr ptr;
    ULong unique;
    DWord uniqueDW;
    DWord car; /* current alarm ref */
    ULong cas; /* current alarm seconds */
    Err err;

    frm = FrmGetActiveForm();

    /* Get whether or not the alarm is set */
    ctl = GetObjectPointer(frm, TimeSetCheck);
    if (CtlGetValue(ctl)) recordSetAlarm();
    else recordUnsetAlarm();
    /* This should already be set right, but just to make sure... */
    recordUnsetCountdown();
    /* Set the repeat mode */
    list = GetObjectPointer(frm, TimeRepeatList);
    d.record.repeatMode = LstGetSelection(list);
    /* Load the time values from the form */
    list = GetObjectPointer(frm, TimeHoursList);
    d.frm_date.hour = LstGetSelection(list);
    if (d.frm_date.hour < 0) d.frm_date.hour = 0;
    list = GetObjectPointer(frm, TimeMinutesList);
    d.frm_date.minute = 5 * LstGetSelection(list);
    if (d.frm_date.hour < 0) d.frm_date.hour = 0;
    d.frm_date.second = 0;
    d.record.alarmSecs = TimDateTimeToSeconds(&(d.frm_date));
    if (d.record.alarmSecs < TimGetSeconds()) {
        d.record.alarmSecs = 0;
        d.record.repeatSecs = 0;
        recordUnsetAlarm();
        FrmAlert(AlarmTimeTooEarly);
    }

    /* Write to disk */
    FlushToDisk(false); /* just the header stuff */

    /* Reset the alarm */
    SetClosestAlarm(d.dbR);
}

/*
** LoadPrefData - preload the Pref data onto the form
*/
static void LoadPrefData(FormPtr frm) {
    ControlPtr ctl;
    Word pushbutton;

    /* Set the disable-titlebar checkbox */
    ctl = GetObjectPointer(frm, PrefDisableTitleCheck);
    CtlSetValue(ctl, p.flags&PFLAGS_DISABLE_TITLE_SCUT);
    /* Set the confirm delete checkbox */
    ctl = GetObjectPointer(frm, PrefConfirmDeleteCheck);
    CtlSetValue(ctl, p.flags&PFLAGS_CONFIRM_DELETE);
    /* Set the confirm clear checkbox */
    ctl = GetObjectPointer(frm, PrefConfirmClearCheck);
    CtlSetValue(ctl, p.flags&PFLAGS_CONFIRM_CLEAR);
    /* Set the BigOK checkbox */
    ctl = GetObjectPointer(frm, PrefBigOkCheck);
    CtlSetValue(ctl, p.flags&PFLAGS_BIG_OK);
    /* Set the hardware pushbutton selection */
    switch (p.hard_button) {
       case hard1Chr:
            pushbutton = PrefHardware1Push;
            break;
       case hard2Chr:
            pushbutton = PrefHardware2Push;
            break;
        case hard3Chr:
            pushbutton = PrefHardware3Push;
            break;
        case hard4Chr:
            pushbutton = PrefHardware4Push;
            break;
        case 0:
        default:
            pushbutton = PrefHardwareNonePush;
            break;
    }
    ctl = GetObjectPointer(frm, pushbutton);
    CtlSetValue(ctl, 1);

}

/*
** SavePrefData
*/
static void SavePrefData(FormPtr frm) {
    ControlPtr ctl;
    Word pushbutton;

    /* Set the values from the form */
    ctl = GetObjectPointer(frm, PrefDisableTitleCheck);
    if (CtlGetValue(ctl)) p.flags |= PFLAGS_DISABLE_TITLE_SCUT;
    else p.flags &= ~PFLAGS_DISABLE_TITLE_SCUT;
    ctl = GetObjectPointer(frm, PrefConfirmDeleteCheck);
    if (CtlGetValue(ctl)) p.flags |= PFLAGS_CONFIRM_DELETE;
    else p.flags &= ~PFLAGS_CONFIRM_DELETE;
    ctl = GetObjectPointer(frm, PrefConfirmClearCheck);
    if (CtlGetValue(ctl)) p.flags |= PFLAGS_CONFIRM_CLEAR;
    else p.flags &= ~PFLAGS_CONFIRM_CLEAR;
    ctl = GetObjectPointer(frm, PrefBigOkCheck);
    if (CtlGetValue(ctl)) p.flags |= PFLAGS_BIG_OK;
    else p.flags &= ~PFLAGS_BIG_OK;
    /* Set the hardware pushbutton value */
    ctl = GetObjectPointer(frm, PrefHardwareNonePush);
    if (CtlGetValue(ctl)) p.hard_button = 0;
    ctl = GetObjectPointer(frm, PrefHardware1Push);
    if (CtlGetValue(ctl)) p.hard_button = hard1Chr;
    ctl = GetObjectPointer(frm, PrefHardware2Push);
    if (CtlGetValue(ctl)) p.hard_button = hard2Chr;
    ctl = GetObjectPointer(frm, PrefHardware3Push);
    if (CtlGetValue(ctl)) p.hard_button = hard3Chr;
    ctl = GetObjectPointer(frm, PrefHardware4Push);
    if (CtlGetValue(ctl)) p.hard_button = hard4Chr;
    /* Save prefs now */
    PrefSetAppPreferences(AppType, 0, 1, &p, sizeof(p), true);
}

/*
** SetAlarmCheckbox
*/
static void SetAlarmCheckbox(void) {
    FormPtr frm;
    ControlPtr ctl;

    frm = FrmGetActiveForm();
    ctl = GetObjectPointer(frm, TimeSetCheck);
    CtlSetValue(ctl, true);
}

/*
** SetDateFromWeekday = handle a weekday selection in the Time Select form
*/
static void SetDateFromWeekday(void) {
    FormPtr frm;
    ControlPtr ctl;
    DateType date;
    DateTimeType current_date;
    Long days_to_adjust;
    short button;
    Char dteStr[15];

    frm = FrmGetActiveForm();
    /* Adjust the form date based on the weekday pressed */
    TimSecondsToDateTime(TimGetSeconds(), &current_date);
    date.year = current_date.year - firstYear;
    date.month = current_date.month;
    date.day = current_date.day;
    button = FrmGetControlGroupSelection(frm, 1);
    if (button == 255) button = current_date.weekDay;
    /* 3 is starting index for the pushbuttons */
    days_to_adjust = (button - 3 - current_date.weekDay);
    if (days_to_adjust < 0) days_to_adjust += 7;
    DateAdjust(&date, days_to_adjust);
    d.frm_date.year = date.year + firstYear;
    d.frm_date.month = date.month;
    d.frm_date.day = date.day;
    d.frm_date.weekDay = DayOfWeek(d.frm_date.month, d.frm_date.day,
                                    d.frm_date.year);
    /* Set the pushbutton value */
    DateToAscii(d.frm_date.month, d.frm_date.day, d.frm_date.year,
                    d.sysPrefs.longDateFormat, dteStr);
    ctl = GetObjectPointer(frm, TimeDatePush);
    CtlHideControl(ctl);
    StrNCopy(ctl->text, dteStr, 14);
    CtlShowControl(ctl);
    /* Reset the weekday pushbutton, just to make sure... */
    FrmSetControlGroupSelection(frm, 1, TimeSunPush+d.frm_date.weekDay);
    /* Set the alarm checkbox */
    ctl = GetObjectPointer(frm, TimeSetCheck);
    CtlSetValue(ctl, true);
}

/*
** LabelHardwareSelTrig - Label the selection trigger for the hardware button
*/
static void LabelHardwareSelTrig(void) {
    FormPtr frm;
    ControlPtr ctl;
    Char str[64];
    Char appname[32];
    CharPtr newlabel;
    UInt cardNo;
    LocalID dbID;
    DmSearchStateType searchstate;
    VoidHand h;

    /* Get the selection trigger */
    frm = FrmGetActiveForm();
    ctl = GetObjectPointer(frm, PrefHardwareSelTrig);

    /* Determine the text label */
    if (p.hardware_action == 0) {
        SysCopyStringResource(str, NewReminderString);
    }
    else if (p.hardware_action == 1) {
        SysCopyStringResource(str, NextSketchString);
    }
    else {
        if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                        p.hardware_action, true, &cardNo, &dbID)) {
            p.hardware_action = 0;
            SysCopyStringResource(str, NewReminderString);
        }
        else {
            DmDatabaseInfo(cardNo, dbID, appname, NULL, NULL, NULL, NULL,
                            NULL, NULL, NULL, NULL, NULL, NULL);
            SysCopyStringResource(str, LaunchString);
            StrNCat(str, appname, 63);
        }
    }
    StrNCat(str, ":", 63);
    str[63] = nullChr;

    /* Label the selection trigger */
    h = MemHandleNew(64);
    newlabel = MemHandleLock(h);
    StrNCopy(newlabel, str, 63);
    CtlSetLabel(ctl, newlabel);
}

/*
** DoHardwareActionList - allow user to select hardware button action
*/
static void DoHardwareActionList(void) {
    SysDBListItemType *app;
    Word appcount;
    Handle happlist;
    FormPtr frm;
    ListPtr list;
    short list_selection;


    /* Get the list of applications */
    if (!SysCreateDataBaseList('appl', 0, &appcount, &happlist, true))
         abort();
    d.papplist = MemHandleLock((VoidHand)happlist);

    /* Popup the list */
    frm = FrmGetActiveForm();
    list = GetObjectPointer(frm, PrefHardwareActionList);
    LstSetListChoices(list, NULL, appcount+1);
    LstSetDrawFunction(list, HardwareActionDrawFunc);
    LstSetSelection(list, -1);
    list_selection = LstPopupList(list);

    /* Set the preferences according to the new selection */
    if (list_selection != -1) {
        if (list_selection > 1) {
            app = d.papplist+(list_selection-2);
            p.hardware_action = app->creator;
        }
        else if (list_selection == 1) p.hardware_action = 1;
        else p.hardware_action = 0;
    }
    LabelHardwareSelTrig();

    /* Cleanup */
    MemHandleUnlock((VoidHand)happlist);
}

/*
** DoDateSelectPopup - Pop up the dialog to specify the data for the alarm
*/
static void DoDateSelectPopup(void) {
    FormPtr frm;
    Char dteStr[15];
    Char titleStr[32];
    ControlPtr ctl;

    /* Pop up the form and get the date */
    SysCopyStringResource(titleStr, SelectDateString);
    if (SelectDay(selectDayByDay, &(d.frm_date.month), &(d.frm_date.day),
                    &(d.frm_date.year), titleStr)) {
        frm = FrmGetActiveForm();
        /* Set the Weekday indicator to match */
        d.frm_date.weekDay = DayOfWeek(d.frm_date.month, d.frm_date.day,
                                        d.frm_date.year);
        FrmSetControlGroupSelection(frm, 1, TimeSunPush+d.frm_date.weekDay);
        ctl = GetObjectPointer(frm, TimeSunPush+d.frm_date.weekDay);
        CtlDrawControl(ctl);
        /* Set the pushbutton value */
        DateToAscii(d.frm_date.month, d.frm_date.day, d.frm_date.year,
                        d.sysPrefs.longDateFormat, dteStr);
        ctl = GetObjectPointer(frm, TimeDatePush);
        CtlHideControl(ctl);
        StrNCopy(ctl->text, dteStr, 14);
        CtlShowControl(ctl);
        SndPlaySystemSound(sndClick);
        SetAlarmCheckbox();
    }

}

/*
** XferTextAction
*/
static void XferTextAction(Word action) {
    FormPtr frm;
    FieldPtr fld;

    frm = FrmGetActiveForm();
    fld = GetObjectPointer(frm, XferField);
    switch (action) {
        case menuitemID_XferUndo:
            FldUndo(fld);
            break;
        case menuitemID_XferCut:
            FldCut(fld);
            break;
        case menuitemID_XferCopy:
            FldCopy(fld);
            break;
        case menuitemID_XferPaste:
            FldPaste(fld);
            break;
        case menuitemID_XferSelectAll:
            FldSetSelection(fld, 0, FldGetTextLength(fld));
            break;
        case menuitemID_XferKeyboard:
            SysKeyboardDialog(kbdAlpha);
            break;
        case menuitemID_XferGHelp:
            SysGraffitiReferenceDialog(referenceAlpha);
            break;
    }

}

/*
** PrefEvent - handle events on the Preferences form
*/
static Boolean PrefEvent(EventPtr e) {
    Boolean handled;
    FormPtr frm;

    handled = false;

    switch (e->eType) {

    case frmOpenEvent:
        frm = FrmGetActiveForm();
        LoadPrefData(frm);
        LabelHardwareSelTrig();
        FrmDrawForm(frm);
        handled = true;
        break;

    case appStopEvent:
    case frmCloseEvent:
        SavePrefData(FrmGetActiveForm());
        break;

    case frmUpdateEvent:
        break;

    case frmGotoEvent:
        p.dbI = e->data.frmGoto.recordNum;
        FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
        handled = true;
        break;

    case ctlSelectEvent:
        switch (e->data.ctlEnter.controlID) {
            case PrefDoneButton:
                FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
                handled = true;
                break;
            case PrefHardwareSelTrig:
                DoHardwareActionList();
                handled = true;
            default:
                break;
        }
        break;

    default:
        break;
    }

    return handled;
}

/*
** TimeEvent - handle events on the time details form
*/
static Boolean TimeEvent(EventPtr e) {
    Boolean handled;

    handled = false;

    switch (e->eType) {

    case frmOpenEvent:
        LoadDateData();
        FrmDrawForm(FrmGetActiveForm());
        handled = true;
        break;

    case appStopEvent:
    case frmCloseEvent:
        break;

    case frmUpdateEvent:
        break;

    case frmGotoEvent:
        p.dbI = e->data.frmGoto.recordNum;
        FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
        handled = true;
        break;

    case ctlSelectEvent:
        switch (e->data.ctlEnter.controlID) {
            case TimeOkButton:
                SaveDateData();
                FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
                handled = true;
                break;
            case TimeCancelButton:
                FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
                handled = true;
                break;
            case TimeDatePush:
                DoDateSelectPopup();
                handled = true;
                break;
            case TimeSunPush:
            case TimeMonPush:
            case TimeTuePush:
            case TimeWedPush:
            case TimeThuPush:
            case TimeFriPush:
            case TimeSatPush:
                SetDateFromWeekday();
                break;
        }
        break;

    case lstSelectEvent:
        switch (e->data.lstSelect.listID) {
            case TimeMinutesList:
            case TimeHoursList:
                SetAlarmCheckbox();
                break;
        }
    }

    return handled;
}

/*
** DoPenDown - handle penDown events in the main doodling form
*/
static Boolean DoPenDown(EventPtr e) {
    Boolean handled, penDown;
    SWord x, y, last_x, last_y;
    void (*do_func)(SWord x, SWord y);
    void (*clear_func)();
    void (*end_func)(SWord x, SWord y);

    CALLBACK_PROLOGUE

    handled = false;

    WinSetPattern(p.modeSelection == SEL_MODE_ERASE ? patternWhite : p.inkpat);
    if (!d.drawmode /* MODE_DOODLE */) {
        d.ox = e->screenX;
        d.oy = e->screenY;
        if (d.undo_mark) FlushToBuffer();
        DoStroke(e->screenX, e->screenY);
        do {
            EvtGetPen(&x, &y, &penDown);
            if ((x == d.ox) && (y == d.oy)) continue;
            DoStroke(x, y);
        } while (penDown && rctPtInRectangle(x, y, &p.r));
        EndStroke();
        recordSetDirty();
        handled = true;
    }
    else {
        switch (d.drawmode) {
            case MODE_TEXT:
                do_func = DoTextInsert;
                clear_func = ClearOldText;
                end_func = EndTextInsert;
                break;
            case MODE_LINE:
                do_func = DoLine;
                clear_func = ClearOldLine;
                end_func = EndLine;
                break;
            case MODE_SHAPE:
                do_func = DoShape;
                clear_func = ClearOldShape;
                end_func = EndShape;
                break;
            default:
                return false;
                break;
        }
        d.anchor.x = d.ox = e->screenX;
        d.anchor.y = d.oy = e->screenY;
        FlushToBuffer();
        (*do_func)(e->screenX, e->screenY);
        do {
            EvtGetPen(&x, &y, &penDown);
            if ((x == d.ox) && (y == d.oy)) continue;
            (*clear_func)();
            (*do_func)(x, y);
        } while (penDown && rctPtInRectangle(x, y, &p.r));
        (*clear_func)();
        if (rctPtInRectangle(x, y, &p.r)) {
            (*end_func)(x, y);
            recordSetDirty();
            d.undo_mark = true;
        }
        else {
            if (d.drawmode == MODE_TEXT) FntSetFont(d.txt_oldfont);
            d.drawmode = MODE_DOODLE;
        }
        handled = true;
    }

    CALLBACK_EPILOGUE
    return handled;
}

/*
** CheckTriggerDrag
*/
static Boolean CheckTriggerDrag(EventPtr e) {
    RectangleType trigger_bounds;
    SWord x, y, left_limit, right_limit;
    Boolean penDown;
    EventType eDate;
    DateTimeType dateTime;
    short old_drawmode;
    Char tempStr[timeStringLength];

    /* Yes, a kludge... should really dynamically get the bounds */
    RctSetRectangle(&trigger_bounds, 38, 147, 111, 12);
    left_limit = e->screenX - 12;
    right_limit = e->screenX + 12;

    if (!RctPtInRectangle(e->screenX, e->screenY, &trigger_bounds))
        return false;

    do {
        EvtGetPen(&x, &y, &penDown);
        if (y < 147) {
            eDate.screenX = x; eDate.screenY = y;
            old_drawmode = d.drawmode; d.drawmode = MODE_TEXT;
            d.txt_oldfont = FntSetFont(p.txt_font);
            /* Copy current date and time to d.InsertionText */
            TimSecondsToDateTime(TimGetSeconds(), &dateTime);
            DateToAscii(dateTime.month, dateTime.day, dateTime.year,
                            d.sysPrefs.longDateFormat, d.InsertionText);
            StrNCat(d.InsertionText, ", ", 31);
            TimeToAscii(dateTime.hour, dateTime.minute,
                            d.sysPrefs.timeFormat, tempStr);
            StrNCat(d.InsertionText, tempStr, 31);
            DoPenDown(&eDate);
            d.drawmode = old_drawmode;
            FntSetFont(d.txt_oldfont);
            EvtGetPen(&x, &y, &penDown);
        }
    } while (penDown);
    if (y >= trigger_bounds.topLeft.y) {
        if (x < left_limit) {
            KeyDown(cmdTransfer);
            return true;
        }
        if (x > right_limit) {
            if (recordIsLocked && recordIsAlarmSet) {
                LockAsk();
            }
            else {
                recordUnsetCountdown();
                FrmGotoForm(TimeForm);
            }
            return true;
        }
    }
    return false;
}

/*
** DiddleEvent - handle events on the doodling form.
*/
static Boolean DiddleEvent(EventPtr e) {
    Boolean handled;
    Word chr;

    handled = false;

    switch (e->eType) {

    case frmOpenEvent:
        d.winM = FrmGetWindowHandle(FrmGetActiveForm());
        if (p.formID == DiddleForm)
            RctSetRectangle(&p.r, 0, 0, 160, 146);
        else
            RctSetRectangle(&p.r, 0, 16, 160, 130);
        LabelTitle();
        BlankAlarm();
        FrmDrawForm(FrmGetActiveForm());
        LoadFromDisk();
        LabelImage();
        d.NextPeriod = TimGetTicks()+100;
        handled = true;
        break;

    case appStopEvent:
    case frmCloseEvent:
        if (d.is_xfer_mode) CancelXferMode();
        FlushToDisk(true);
        break;

    case frmUpdateEvent:
        if (e->data.frmUpdate.updateCode == FRMUPDATE_DELETED_CURRENT) {
            if (d.is_xfer_mode) CancelXferMode();
            LoadFromDisk();
            LabelImage();
            handled = true;
        }
        else if (e->data.frmUpdate.updateCode == FRMUPDATE_DELETED_ANY) {
            LabelImage();
            handled = true;
        }
        break;

    case frmGotoEvent:
        if (d.is_xfer_mode) CancelXferMode();
        FlushToDisk(true);
        p.dbI = e->data.frmGoto.recordNum;
        LoadFromDisk();
        LabelImage();
        handled = true;
        break;

    case menuEvent:
        d.drawmode = MODE_DOODLE;
        switch(e->data.menu.itemID) {
            case menuitemID_PenFine: chr=penFine; break;
            case menuitemID_PenMedium: chr=penMedium; break;
            case menuitemID_PenBold: chr=penBold; break;
            case menuitemID_PenBroad: chr=penBroad; break;
            case menuitemID_PenFineItalic: chr=penFineItalic; break;
            case menuitemID_PenMediumItalic: chr=penMediumItalic; break;
            case menuitemID_PenBroadItalic: chr=penBroadItalic; break;
            case menuitemID_InkWhite: chr=inkWhite; break;
            case menuitemID_InkDith12: chr=inkDith12; break;
            case menuitemID_InkDith25: chr=inkDith25; break;
            case menuitemID_InkDith37: chr=inkDith37; break;
            case menuitemID_InkDith50: chr=inkDith50; break;
            case menuitemID_InkDith62: chr=inkDith62; break;
            case menuitemID_InkDith75: chr=inkDith75; break;
            case menuitemID_InkDith87: chr=inkDith87; break;
            case menuitemID_InkBlack: chr=inkBlack; break;
            case menuitemID_InkRandom: chr=inkRandom; break;
            case menuitemID_ModePaint: chr=modePaint; break;
            case menuitemID_ModeSmear: chr=modeSmear; break;
            case menuitemID_ModeErase: chr=modeErase; break;
            case menuitemID_CmdRough: chr=cmdRough; break;
            case menuitemID_CmdSmooth: chr=cmdSmooth; break;
            case menuitemID_CmdSmoother: chr=cmdSmoother; break;
            case menuitemID_CmdAbout: chr=cmdAbout; break;
            case menuitemID_CmdPref: chr=cmdPref; break;
            case menuitemID_CmdClear: chr=cmdClear; break;
            case menuitemID_CmdFill: chr=cmdFill; break;
            case menuitemID_CmdInvert: chr=cmdInvert; break;
            case menuitemID_CmdSketchUndo: chr=cmdSketchUndo; break;
            case menuitemID_CmdRemove: chr=cmdRemove; break;
            case menuitemID_CmdTitle: chr=cmdTitle; break;
            case menuitemID_CmdNew: chr=cmdNew; break;
            case menuitemID_CmdPrevious: chr=cmdPrevious; break;
            case menuitemID_CmdNext: chr=cmdNext; break;
            case menuitemID_CmdText: chr=cmdText; break;
            case menuitemID_CmdLine: chr=cmdLine; break;
            case menuitemID_CmdShape: chr=cmdShape; break;
            case menuitemID_CmdInsertLast: chr=cmdInsertLast; break;
            case menuitemID_CmdLock: chr=cmdLock; break;
            case menuitemID_CmdTransfer: chr=cmdTransfer; break;
            case menuitemID_CmdBeam: chr=cmdBeam; break;
        }
        handled = KeyDown(chr);
        if (!handled) {
            switch(e->data.menu.itemID) {
            case menuitemID_XferDone:
                FinishXferMode();
                handled = true;
                break;
            case menuitemID_XferUndo:
            case menuitemID_XferCut:
            case menuitemID_XferCopy:
            case menuitemID_XferPaste:
            case menuitemID_XferSelectAll:
            case menuitemID_XferKeyboard:
            case menuitemID_XferGHelp:
                XferTextAction(e->data.menu.itemID);
                handled = true;
                break;
            }
        }
        break;

    case keyDownEvent:
        d.drawmode = MODE_DOODLE;
        if (e->data.keyDown.chr == alarmChr) {
            FlushToDisk(true);
            handled = true;
        }
        else handled = KeyDown(e->data.keyDown.chr);
        break;

    case ctlSelectEvent:
        d.drawmode = MODE_DOODLE;
        switch (e->data.ctlEnter.controlID) {
        case ModeButton:
            handled = ButtonDrop(ModeButton);
            break;
        case SmoothButton:
            handled = ButtonDrop(SmoothButton);
            break;
        case PenButton:
            handled = ButtonDrop(PenButton);
            break;
        case InkButton:
            handled = ButtonDrop(InkButton);
            break;
        case PageButton:
            handled = KeyDown(cmdNext);
            break;
        case MainDateSelTrig:
            if (recordIsLocked && recordIsAlarmSet)
                LockAsk();
            else
                DoDateSelect(e->screenX);
            handled = true;
            break;
        case MainNewButton:
            handled = KeyDown(cmdNew);
            break;
        case MainClearButton:
            handled = KeyDown(cmdClear);
            break;
        case MainDeleteButton:
            handled = KeyDown(cmdRemove);
            break;
        case MainLockButton:
            LockAsk();
            handled = true;
            break;
        case MainSwitchButton:
            if (recordIsCountdown) recordUnsetCountdown();
            else recordSetCountdown();
            LabelAlarm();
            handled = true;
            break;
        case XferDetailsButton:
            DoXferList();
            handled = true;
            break;
        }
        break;

    case penDownEvent:
        DiddlePenClear();
        if (d.is_xfer_mode) {
            handled = XferPenDown(e);
        }
        else if (recordIsLocked &&
                    rctPtInRectangle(e->screenX, e->screenY, &p.r)){
            LockWarn();
            handled = true;
        }
        else if (!rctPtInRectangle(e->screenX, e->screenY, &p.r)) {
            handled = CheckTriggerDrag(e);
        }
        else {
            DoPenDown(e);
        }
        break;

    case penMoveEvent:
        if (rctPtInRectangle(e->screenX, e->screenY, &p.r)) {
            if (!recordIsLocked)
                handled = DoPenDown(e);
            else
                handled = true;
        }
        break;

    case frmTitleSelectEvent:
        if (p.flags&PFLAGS_DISABLE_TITLE_SCUT) return false;
        ShortCutPop(high);
        handled = true;
        break;

    }

    return handled;

}

/*
** SpecialKeyDown - Act on a hardware or special key
*/
static Boolean SpecialKeyDown(EventPtr e) {
    Word chr;
    FormPtr frm;
    LocalID dbID;
    UInt cardNo;
    DmSearchStateType searchstate;

    if (e->eType != keyDownEvent) return false;

    if (e->data.keyDown.modifiers&commandKeyMask) {
        chr = e->data.keyDown.chr;

        if (e->data.keyDown.modifiers&autoRepeatKeyMask)
            return false;
        if (e->data.keyDown.modifiers&poweredOnKeyMask)
            return false;

        if (chr == p.hard_button) {
          if (d.is_xfer_mode) CancelXferMode();
          if ((p.hardware_action == 0) || (p.hardware_action == 1)) {
            d.drawmode = MODE_DOODLE;
            switch (d.formID) {
            case DiddleForm:
            case DiddleTForm:
                if (p.hardware_action == 0) {
                    FlushToDisk(true);
                    frm = FrmGetActiveForm();
                    NewScratchImage();
                    LoadFromDisk();
                    LabelImage();
                    SndPlaySystemSound(sndClick);
                }
                else if (p.hardware_action == 1) {
                    KeyDown(cmdNext);
                }
                break;
            case TimeForm:
                NewScratchImage();
                FrmGotoForm(p.formID == DiddleForm ? DiddleForm : DiddleTForm);
                SndPlaySystemSound(sndClick);
                break;
            }
            EvtFlushPenQueue();
          }
          else {
            if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                              p.hardware_action, true, &cardNo, &dbID)) {
                                return true;
            }
            SndPlaySystemSound(sndClick);
            SysUIAppSwitch(cardNo, dbID, sysAppLaunchCmdNormalLaunch, 0);
          }
          return true;
        }


        /* SoftKeys only work on main doodling form */
        if ((d.formID != DiddleForm) && (d.formID != DiddleTForm))
            return false;

        /* No  softkeys in transfer mode */
        if (d.is_xfer_mode) return false;

        if (keyboardAlphaChr == chr) {
            d.drawmode = MODE_DOODLE;
            FrmGotoForm(p.formID == DiddleForm ? DiddleTForm : DiddleForm);
            return true;
        }
        else if (keyboardNumericChr == chr) {
            d.drawmode = MODE_DOODLE;
            ShortCutPop(low);
            return true;
        }
    }
    return false;
}

/*
** ResetAlarmData
*/
static Boolean ResetAlarmData(DmOpenRef dbR, UInt dbI, Boolean appIsActive) {
    VoidHand t;
    DiddleBugRecordType record;
    DateTimeType date;
    Err err;

    /* Open the record and get the alarm info for it */
    t = DmQueryRecord(dbR, dbI);
    if (!t && !appIsActive) {
        DmCloseDatabase(dbR);
        return false;
    }
    MemMove(&record, MemHandleLock(t), sizeof(DiddleBugRecordType));
    MemHandleUnlock(t);
    /* Determine the new alarm data */
    switch (record.repeatMode) {
        case REPEAT_NONE:
            record.flags &= ~RECORD_FLAG_ALARM_SET;
            record.alarmSecs = 0;
            break;
        case REPEAT_HOURLY:
            record.flags |= RECORD_FLAG_ALARM_SET;
            record.alarmSecs += (60L*60L);
            break;
        case REPEAT_DAILY:
            record.flags |= RECORD_FLAG_ALARM_SET;
            record.alarmSecs += (60L*60L*24L);
            break;
        case REPEAT_WEEKLY:
            record.flags |= RECORD_FLAG_ALARM_SET;
            record.alarmSecs += (60L*60L*24L*7L);
            break;
        case REPEAT_BIWEEKLY:
            record.flags |= RECORD_FLAG_ALARM_SET;
            record.alarmSecs += (60L*60L*24L*14L);
            break;
        case REPEAT_WEEKDAYS:
            record.flags |= RECORD_FLAG_ALARM_SET;
            TimSecondsToDateTime(record.alarmSecs, &date);
            if (date.weekDay == 5) /* Friday */
                record.alarmSecs += (3L*60L*60L*24L);
            else if (date.weekDay == 6) /* Saturday */
                record.alarmSecs += (2L*60L*60L*24L);
            else  /* Sunday thru Thursday */
                record.alarmSecs += (60L*60L*24L);
            break;
        default:
            record.flags &= ~RECORD_FLAG_ALARM_SET;
            record.alarmSecs = 0;
            break;
    }
    /* If repeating from a snoozed alarm, use the previously calculated data */
    if (record.repeatSecs && (record.repeatSecs > TimGetSeconds()) &&
                    (record.flags&RECORD_FLAG_ALARM_SET))
        record.alarmSecs = record.repeatSecs;
    record.repeatSecs = 0;
    /* If the user is sketching on the alarm sketch, save the current data */
    if (appIsActive && (dbI == p.dbI)) {
        MemMove(&d.record, &record, sizeof(DiddleBugRecordType));
        if ((d.formID == DiddleForm) || (d.formID == DiddleTForm))
                LabelAlarm();
    }
    /* Reopen record and save the new data */
    t = DmGetRecord(dbR, dbI);
    if (!t && !appIsActive) {
        DmCloseDatabase(dbR);
        return false;
    }
    DmWrite(MemHandleLock(t), 0, &record, sizeof(DiddleBugRecordType));
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, dbI, true);

    return true;
}

/*
** TriggerAlarm - responds to an alarm trigger
*/
void
TriggerAlarm(SysAlarmTriggeredParamType* alarmParams, Boolean appIsActive) {
    DmOpenRef dbR;
    UInt dbI;
    ULong unique;
    DWord uniqueDW;
    VoidHand t;
    DiddleBugRecordType record;
    UInt num_records, num_features, i;
    Err err;

    /* Open database */
    if (appIsActive) dbR = d.dbR;
    else {
        dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
        if (!dbR) {
            return;
        }
    }
    /* Find the alarm sketch */
    MemMove(&unique, alarmParams, sizeof(ULong));
    err = DmFindRecordByID(dbR, unique, &dbI);
    if (err) {
        DmCloseDatabase(dbR);
        return;
    }

    /* Find the current number of features */
    num_features = 0;
    while(1) {
        if (FtrGet(AppType, num_features, &uniqueDW))
            break;
        else
            num_features++;
    }
    /* Reset the alarm data */
    if (!ResetAlarmData(dbR, dbI, appIsActive)) return;
    /* Register the alarm as a feature */
    DmRecordInfo(dbR, dbI, NULL, &unique, NULL);
    MemSet(&uniqueDW, 0, sizeof(DWord));
    MemMove(&uniqueDW, &unique, sizeof(ULong));
    if (FtrSet(AppType, num_features, uniqueDW)) return;
    num_features++;

    /* Cycle thru all sketches looking for simultaneous alarms */
    num_records = DmNumRecords(dbR);
    for ( i=0; i<num_records; i++ ) {
        /* Open the record and get the alarm info for it */
        t = DmQueryRecord(dbR, i);
        if (!t) continue;
        MemMove(&record, MemHandleLock(t), sizeof(DiddleBugRecordType));
        MemHandleUnlock(t);
        /* If simultaneous... */
        if ((record.flags&RECORD_FLAG_ALARM_SET) &&
                (record.alarmSecs == alarmParams->alarmSeconds)) {
            /* Reset the alarm data on disk */
            if (!ResetAlarmData(dbR, i, appIsActive)) return;
            /* Register the alarm as a feature */
            DmRecordInfo(dbR, i, NULL, &unique, NULL);
            MemSet(&uniqueDW, 0, sizeof(DWord));
            MemMove(&uniqueDW, &unique, sizeof(ULong));
            if (!FtrSet(AppType, num_features, uniqueDW)) num_features++;
        }
    }


    /* Find the next latest alarm and set it */
    SetClosestAlarm(dbR);

    /* Play the alarm sound */
    SndPlaySystemSound(sndAlarm);

    /* Clean up */
    if (!appIsActive) DmCloseDatabase(dbR);
}

/*
** GetSnoozeSecsFromList - return number of seconds to snooze
*/
ULong GetSnoozeSecsFromList(Word list_selection) {
    ULong secs;

    switch (list_selection) {
        case -1:
        case 0:
            secs = 0;
            break;
        case 1:  /* 1 min */
        case 2:  /* 2 min */
        case 3:  /* 3 min */
        case 4:  /* 4 min */
        case 5:  /* 5 min */
            secs = 60L * list_selection;
            break;
        case 6:  /* 10 min */
        case 7:  /* 15 min */
        case 8:  /* 20 min */
        case 9:  /* 25 min */
        case 10: /* 30 min */
            secs = 60L * 5L * (list_selection-4);
            break;
        case 11: /* 45 min */
            secs = 60L * 45L;
            break;
        case 12: /* 1 hr   */
        case 13: /* 2 hr   */
        case 14: /* 3 hr   */
        case 15: /* 4 hr   */
        case 16: /* 5 hr   */
            secs = 60L * 60L * (list_selection-11);
            break;
        case 17: /* 8 hr   */
        case 18: /* 10 hr  */
        case 19: /* 12 hr  */
            secs = 60L * 60L * 2L * (list_selection-13);
            break;
        case 20: /* 1 day  */
        case 21: /* 2 days */
        case 22: /* 3 days */
        case 23: /* 4 days */
        case 24: /* 5 days */
        case 25: /* 6 days */
        case 26: /* 1 week */
            secs = 24L * 60L * 60L * (list_selection-19);
            break;
        case 27: /* 2 weeks */
            secs = 14L * 24L * 60L * 60L;
            break;
        default:
            secs = 0;
            break;
    }
    return secs;
}

/*
** GetBitDepth
*/
static UInt GetBitDepth(void) {
    UInt bitDepth;
    DWord romVersion;
    DWord width, height, depth;
    Err err;
    Boolean color;

    /* Check to see if we support more than 1-bit depth */
    romVersion = 0;
    err = FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romVersion);
    if (romVersion >= 0x03003000) {
        width = 160; height = 160; depth = 1; color = false;
        /* One of them new-fangled machines */
        ScrDisplayMode(scrDisplayModeGet, &width, &height, &depth, &color);
    }
    else depth = 0x00000001;
    
    /* Determine the bit depth of the screen */
    if ( depth&0x00000008 ) bitDepth = 4;
    else if ( depth&0x00000002 ) bitDepth = 2;
    else bitDepth = 1;
    return bitDepth;
}

/*
** DisplayAlarmEvent - Handled events on the display alarm form
*/
static Boolean DisplayAlarmEvent (EventPtr e) {
    if (e->eType == appStopEvent)
        return true;
    else
        return false;
}

/*
** DisplayAlarm - show the alarm popup Dialog box
*/
void DisplayAlarm(SysDisplayAlarmParamType* alarmParams, Boolean appIsActive) {
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    UInt cardno;
    LocalID dbID;
    UInt dbI;
    FormPtr frm, curForm;
    ListPtr snooze_list;
    Word snooze_num;
    ULong snooze_secs, current_secs;
    DiddleBugRecordType record;
    ULong unique;
    DWord uniqueDW;
    VoidHand t;
    VoidPtr ptr;
    UInt i, j;
    WinHandle winH;
    Word button_pressed;
    Boolean go_to_diddlebug;
    DWord current_dbi;
    SWord actualSize;
    Word prefsSize = sizeof(pref);
    pref tempPref;
    Boolean bigok;
    Boolean confirmDelete, pleaseDelete;
    RectangleType tempRect;
    Boolean savePrefs;
    EventType updateEvent;
    UInt bitDepth;
    CharPtr iPtr, jPtr;
    Char bufChar;
    Err err;

    /* Open (or use current) database */
    bigok = false;
    if (appIsActive) dbR = d.dbR;
    else {
        dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
        if (!dbR) {
            return;
        }
    }
    tempPref.version = 0;
    actualSize = PrefGetAppPreferences(AppType, 0, &tempPref, &prefsSize, true);
    if (actualSize == noPreferenceFound || prefsSize != sizeof(pref) ||
                        tempPref.version != PrefVersion) {
        savePrefs = false;
        bigok = false;
        confirmDelete = false;
    }
    else {
        savePrefs = true;
        bigok = tempPref.flags&PFLAGS_BIG_OK;
        confirmDelete = tempPref.flags&PFLAGS_CONFIRM_DELETE;
    }
    /* Get the current database index */
    if (appIsActive) current_dbi = p.dbI;
    else if (savePrefs) current_dbi = tempPref.dbI;
    else current_dbi = 0;
    /* Loop thru every alarm that has been set */
    i=0;
    go_to_diddlebug = false;
    while (!FtrGet(AppType, i, &uniqueDW)) {
        /* Find the alarm sketch */
        MemMove(&unique, &uniqueDW, sizeof(ULong));
        err = DmFindRecordByID(dbR, unique, &dbI);
        if (err) { i++; continue; }

        /* Write the sketch data into the form */
        frm = FrmInitForm(AlarmForm);
        winH = FrmGetWindowHandle(frm);
        /* Disable the BigOK button if necesary */
        if (!bigok)
            HideObject(frm, AlarmBigOkButton);
        t = DmQueryRecord(dbR, dbI);
        if (!t) {
            /* Remove the alarm features */
            i=0;
            while (!FtrGet(AppType, i, &uniqueDW)) {
                FtrUnregister(AppType, i);
                i++;
            }
            /* close the database */
            if (!appIsActive) DmCloseDatabase(dbR);
            return;
        }

        /* Show the form with the picture in it */
        if (appIsActive && (dbI == p.dbI) &&
                    ((d.formID == DiddleForm)||(d.formID == DiddleTForm))) {
            recordSetDirty();
            FlushToBuffer();
        }
        curForm = FrmGetActiveForm();
        if (curForm) FrmSetActiveForm(frm);
        FrmSetEventHandler(frm, DisplayAlarmEvent);
        ptr = MemHandleLock(t);
        FrmDrawForm(frm);
        MemMove(&record, ptr, sizeof(DiddleBugRecordType));
        if (appIsActive && (dbI == p.dbI) &&
                    ((d.formID == DiddleForm)||(d.formID == DiddleTForm))) {
            record.flags |= RECORD_FLAG_BUFDIRTY;
            MemMove(WinGetWindowPointer(winH)->displayAddr,
                            WinGetWindowPointer(d.winbufM)->displayAddr, 3200);
        }
        else {
            bitDepth = GetBitDepth();
            iPtr = WinGetWindowPointer(winH)->displayAddr;
            jPtr = iPtr+((bitDepth-1)*3200);
            UncompressSketch(ptr+sketchDataOffset+sketchThumbnailSize+1,
                            jPtr, record.sketchLength-sketchThumbnailSize-1);
            if (bitDepth == 2) {
                for (j=0; j<3200; j++) {
                    bufChar = 0x00;
                    if (jPtr[0]&0x80) bufChar |= 0xc0;
                    if (jPtr[0]&0x40) bufChar |= 0x30;
                    if (jPtr[0]&0x20) bufChar |= 0x0c;
                    if (jPtr[0]&0x10) bufChar |= 0x03;
                    iPtr[0] = bufChar; iPtr++;
                    bufChar = 0x00;
                    if (jPtr[0]&0x08) bufChar |= 0xc0;
                    if (jPtr[0]&0x04) bufChar |= 0x30;
                    if (jPtr[0]&0x02) bufChar |= 0x0c;
                    if (jPtr[0]&0x01) bufChar |= 0x03;
                    iPtr[0] = bufChar; iPtr++;
                    jPtr++;
                }
            }
            else if (bitDepth == 4) {
                for (j=0; j<3200; j++) {
                    bufChar = 0x00;
                    if (jPtr[0]&0x80) bufChar |= 0xf0;
                    if (jPtr[0]&0x40) bufChar |= 0x0f;
                    iPtr[0] = bufChar; iPtr++;
                    bufChar = 0x00;
                    if (jPtr[0]&0x20) bufChar |= 0xf0;
                    if (jPtr[0]&0x10) bufChar |= 0x0f;
                    iPtr[0] = bufChar; iPtr++;
                    bufChar = 0x00;
                    if (jPtr[0]&0x08) bufChar |= 0xf0;
                    if (jPtr[0]&0x04) bufChar |= 0x0f;
                    iPtr[0] = bufChar; iPtr++;
                    bufChar = 0x00;
                    if (jPtr[0]&0x02) bufChar |= 0xf0;
                    if (jPtr[0]&0x01) bufChar |= 0x0f;
                    iPtr[0] = bufChar; iPtr++;
                    jPtr++;
                }
            }
        }
        /* Clear the crap at the bottom of the screen */
        RctSetRectangle(&tempRect, 0, 146, 160, 14);
        WinEraseRectangle(&tempRect, 0);
        FrmShowObject(frm, FrmGetObjectIndex(frm, AlarmOkButton));
        FrmShowObject(frm, FrmGetObjectIndex(frm, AlarmSnoozePop));
        FrmShowObject(frm, FrmGetObjectIndex(frm, BugBitmap));
        FrmShowObject(frm, FrmGetObjectIndex(frm, DeleteBitmap));
        MemHandleUnlock(t);

        /* Close database so the "stacked-up" alarms can function */
        if (!appIsActive) DmCloseDatabase(dbR);
        /* Actually show the dialog (finally!) */
        button_pressed = FrmDoDialog(frm);
        /* Re-open database */
        if (!appIsActive) {
            dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
            if (!dbR) {
                FrmEraseForm(frm);
                FrmDeleteForm(frm);
                FrmAlert(NoOpenError);
                return;
            }
        }

        /* Check for a snooze being set */
        snooze_list = GetObjectPointer(frm, AlarmSnoozeList);
        snooze_num = LstGetSelection(snooze_list);
        current_secs = TimGetSeconds();
        if ((AlarmOkButton==button_pressed ||
                    (AlarmBigOkButton==button_pressed && bigok))
                        && snooze_num != -1 && snooze_num != 0) {
            snooze_secs = GetSnoozeSecsFromList(snooze_num);
            snooze_secs += current_secs;
            if ((record.flags&RECORD_FLAG_ALARM_SET) &&
                            (snooze_secs > record.alarmSecs)) {
                FrmAlert(BadSnoozeForm);
                i++;
                FrmEraseForm(frm);
                FrmDeleteForm(frm);
                continue;
            }
            else if (record.repeatMode && (record.flags&RECORD_FLAG_ALARM_SET)
                            && (record.alarmSecs > current_secs)) {
                /* Store the repeat time so that snooze will not
                 * drift the normal repeat time */
                if (!record.repeatSecs)
                    record.repeatSecs = record.alarmSecs;
                else if (record.repeatSecs < current_secs)
                    record.repeatSecs = 0;
            }
            /* Set the new snooze time */
            record.alarmSecs = snooze_secs;
            record.flags |= RECORD_FLAG_ALARM_SET;
            t = DmGetRecord(dbR, dbI);
            ASSERT(t);
            if (!t) {
                i++;
                FrmEraseForm(frm);
                FrmDeleteForm(frm);
                continue;
            }
            DmWrite(MemHandleLock(t), 0, &record, sizeof(DiddleBugRecordType));
            MemHandleUnlock(t);
            DmReleaseRecord(dbR, dbI, true);
            if (appIsActive && (dbI == p.dbI)) {
                MemMove(&d.record, &record, sizeof(DiddleBugRecordType));
            }
            SetClosestAlarm(dbR);
        }

        /* Form Cleanup */
        FrmEraseForm(frm);
        FrmDeleteForm(frm);
        FrmSetActiveForm(curForm);

        /* Check for the DiddleBug button being pressed */
        if (AlarmDiddleBugButton == button_pressed) go_to_diddlebug = true;

        /* Check if the user deleted the reminder */
        if (AlarmDeleteButton == button_pressed) {
          pleaseDelete = false;
          if (record.flags&RECORD_FLAG_LOCKED) {
              if (!FrmAlert(ConfirmLockedDelete)) pleaseDelete = true;
          }
          else if (confirmDelete) {
              if (!FrmAlert(ConfirmDeleteForm)) pleaseDelete = true;
          }
          else pleaseDelete = true;
          if (pleaseDelete) {
            DmRemoveRecord(dbR, dbI);
            if (appIsActive) {
                if (dbI == p.dbI) {
                    updateEvent.data.frmUpdate.updateCode =
                                                FRMUPDATE_DELETED_CURRENT;
                }
                else {
                    updateEvent.data.frmUpdate.updateCode =
                                                FRMUPDATE_DELETED_ANY;
                }
                if (dbI <= p.dbI) {
                    if (p.dbI > 0) p.dbI --;
                }
                updateEvent.eType = frmUpdateEvent;
                EvtAddEventToQueue(&updateEvent);
            }
            else {
                if (savePrefs && (dbI <= tempPref.dbI)) {
                    if (tempPref.dbI > 0) tempPref.dbI--;
                }
            }
            SetClosestAlarm(dbR);
          }
        }
        i++;
    }

    /* Remove the alarm features */
    i=0;
    while (!FtrGet(AppType, i, &uniqueDW)) {
        FtrUnregister(AppType, i);
        i++;
    }

    /* Goto DiddleBug if selected */
    if (!appIsActive && go_to_diddlebug) {
        if (!DmGetNextDatabaseByTypeCreator(true, &searchstate,
                sysFileTApplication, AppType, true, &cardno, &dbID)) {
            SysUIAppSwitch(cardno, dbID, sysAppLaunchCmdNormalLaunch, NULL);
        }
    }

    /* Save the preferences */
    if (savePrefs)
        PrefSetAppPreferences(AppType, 0, 1, &tempPref, sizeof(pref), true);

    if (!appIsActive) DmCloseDatabase(dbR);
    else d.NextPeriod = TimGetTicks()+25;
}

/*
** SystemWasReset - Reset the alarms because of a system reset
*/
void SystemWasReset(void) {
    DmOpenRef dbR;

    /* Open (or use current) database */
    dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadOnly);
    if (!dbR) {
        return;
    }

    SetClosestAlarm(dbR);
    DmCloseDatabase(dbR);
}

/*
** CloseDatabases - you know what it does
*/
static void CloseDatabases(void) {
    DmCloseDatabase(d.dbR);
}

/*
** UpgradeRecordFormat
*/
void UpgradeRecordFormat() {
    UInt i, num_records;
    VoidHand t;
    VoidPtr ptr, winPtr;
    DeprecatedAlarmType alarm;
    DiddleBugRecordType record;
    ULong sketchSize;

    num_records = DmNumRecords(d.dbR);
    for (i=0; i<num_records; i++) {
        /* Open and lock the old record */
        t = DmQueryRecord(d.dbR, i);
        if (!t) abort();
        ptr = MemHandleLock(t);
        /* Read the old alarm data */
        MemMove(&alarm, ptr+3200, sizeof(DeprecatedAlarmType));
        /* Copy the old sketch data to the buffer */
        winPtr = WinGetWindowPointer(d.winbufM)->displayAddr;
        MemMove(winPtr, ptr, 3200);
        /* Close the old record */
        MemHandleUnlock(t);
        /* The compression routine uses p.dbI */
        p.dbI = i;
        sketchSize = 0;
        ptr = CompressSketch(&sketchSize, winPtr);
        /* Write the high data to disk */
        DmSet(ptr, sketchDataOffset+sketchSize, 2, 0);
        /* Fill the record structure */
        MemSet(&record, sizeof(DiddleBugRecordType), 0);
        record.sketchLength = sketchSize;
        record.alarmSecs = alarm.alarm_secs;
        record.repeatMode = alarm.repeat_mode;
        if (alarm.is_alarm_set) record.flags |= RECORD_FLAG_ALARM_SET;
        if (alarm.is_countdown) record.flags |= RECORD_FLAG_COUNTDOWN;
        if(DmWrite(ptr, 0, &record, sizeof(DiddleBugRecordType)))
            abort();
        MemPtrUnlock(ptr);
        DmReleaseRecord(d.dbR, i, true);
    }
    /* Back to normal */
    p.dbI = 0;
}

/*
** OpenDatabases - Open databases and set backup bit
*/
Err OpenDatabases(void) {
    Err err;
    VoidHand h;
    LocalID dbID;
    LocalID appInfoID;
    UInt dbAttrs;
    UInt cardNo;
    DmSearchStateType searchstate;
    AppInfoPtr appInfoP;
    SWord actualSize;
    Word prefsSize = sizeof(p);
    pref tempPref;
    FormPtr frm;
    ListPtr list;
    Char catName[32];
    ULong linkerparam;
    DWord romversion, current_dbi;

    /* Check for at least PalmOS 2.0 */
    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romversion);
    if (romversion < 0x02003000) {
        FrmAlert(NeedVersion2Error);
        return 1;
    }

    /* Create the offscreen buffer */
    err = 0;
    d.winbufM = WinCreateOffscreenWindow(160, 160, screenFormat, &err);
    if (err) abort();

    /* Open scratch database and get preferences */
    if ((d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType,
                     dmModeReadWrite)) != NULL) {
        MemSet(&tempPref, sizeof(tempPref), 0);
        actualSize = PrefGetAppPreferences(AppType, 0, &tempPref, &prefsSize,
                                 true);
        if (actualSize == noPreferenceFound || prefsSize != sizeof(p) ||
                        tempPref.version != PrefVersion) {
            /* Only upgrade records for versions before 2.6 */
            if (tempPref.version == 1) {
                UpgradeRecordFormat();
            }
            else if ((tempPref.version == 2) || (tempPref.version == 3) ||
                        (tempPref.version == 4) || (tempPref.version == 5)) {
                UpgradeRecordFormat();
            }
        }
        else
            PrefGetAppPreferences(AppType, 0, &p, &prefsSize, true);
    } else {
        if (err = DmCreateDatabase(0, DBName, AppType, DBType, false))
            return err;
        d.dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
    }

    /* Set backup bits */
    if (err = DmOpenDatabaseInfo(d.dbR, &dbID, NULL, NULL, &cardNo, NULL)) {
        CloseDatabases();
        return err;
    }
    if (err = DmDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL, NULL,
                                 NULL, NULL, NULL, NULL, NULL, NULL)) {
        CloseDatabases();
        return err;
    }
    dbAttrs |= dmHdrAttrBackup;
    if (appInfoID == NULL) {
        h = DmNewHandle(d.dbR, sizeof(AppInfoType));
        if (!h) return dmErrMemError;
        appInfoID = MemHandleToLocalID(h);
        DmSetDatabaseInfo(0, dbID, NULL, NULL, NULL, NULL, NULL, NULL, NULL,
                            &appInfoID, NULL, NULL, NULL);
        appInfoP = MemLocalIDToLockedPtr(appInfoID, 0);
        DmSet(appInfoP, 0, sizeof(AppInfoType), 0);
        CategoryInitialize(appInfoP, CatUnfiledString);
        MemPtrUnlock(appInfoP);
        SysCopyStringResource(catName, CatUnfiledString);
        CategorySetName(d.dbR, 0, catName);
        SysCopyStringResource(catName, CatPersonalString);
        CategorySetName(d.dbR, 1, catName);
        SysCopyStringResource(catName, CatBusinessString);
        CategorySetName(d.dbR, 2, catName);
    }
    if (err = DmSetDatabaseInfo(0, dbID, NULL, &dbAttrs, NULL, NULL,
                                    NULL, NULL, NULL, NULL, NULL, NULL,
                                    NULL)) {
        CloseDatabases();
        return err;
    }


    /* Get the cardNo and dbID of the application (for alarms) */
    if (err = DmGetNextDatabaseByTypeCreator(true, &searchstate,
            sysFileTApplication, AppType, true, &(d.CardNo), &(d.DBID))) {
        CloseDatabases();
        return err;
    }

    /* Set the bottom bar and other rectangle */
    RctSetRectangle(&d.bottom_bar_rect, 0, 146, 160, 14);
    RctSetRectangle(&d.screen_above_bar, 0, 0, 160, 146);
    
    /* Get the localized preferences */
    PrefGetPreferences(&(d.sysPrefs));
    switch (d.sysPrefs.timeFormat) {
        case tfColon24h:
        case tfHours24h:
            d.shorttime = tfColon24h;
            break;
        case tfDot:
        case tfDotAMPM:
            d.shorttime = tfDot;
            break;
        case tfDot24h:
            d.shorttime = tfDot24h;
            break;
        case tfComma24h:
            d.shorttime = tfComma24h;
            break;
        case tfColon:
        case tfColonAMPM:
        case tfHoursAMPM:
        default:
            d.shorttime = tfColon;
            break;
    }

    /* Set the ShortCut popup list width */
    frm = FrmInitForm(DiddleTForm);
    list = GetObjectPointer(frm, PopShortcutList);
    d.shortcut_width = GetListWidth(list);
    FrmDeleteForm(frm);


    /* Set the Coutdown popup list width */
    d.alarm_select_width = GetAlarmSelectListWidth();

    /* We "initialize" this here because the new egcs compiler is
     * flakey about initializing pointers */
    d.penpixList[0] = penpixFine;
    d.penpixList[1] = penpixMedium;
    d.penpixList[2] = penpixBold;
    d.penpixList[3] = penpixBroad;
    d.penpixList[4] = penpixFineItalic;
    d.penpixList[5] = penpixMediumItalic;
    d.penpixList[6] = penpixBroadItalic;
    d.inkList[0] = patternWhite;
    d.inkList[1] = patternDith12;
    d.inkList[2] = patternDith25;
    d.inkList[3] = patternDith37;
    d.inkList[4] = patternDith50;
    d.inkList[5] = patternDith62;
    d.inkList[6] = patternDith75;
    d.inkList[7] = patternDith87;
    d.inkList[8] = patternBlack;

    /* Check to see if Linker is available */
    if (!FtrGet('Linx', 1001, &linkerparam)) {
        d.linker_available = true;
    }

    /* Might as well do a sanity check that the correct alarm is set */
    SetClosestAlarm(d.dbR);

    return 0;
}

/*
** TimeUntilNextTimePeriod - return the number of ticks to wait
*/
static Long TimeUntilNextTimePeriod(void) {
    Long timeRemaining;
    ULong ticks;
    
    if (d.is_xfer_mode) return evtWaitForever; 

    ticks = TimGetTicks();
    timeRemaining = d.NextPeriod - ticks;
    if (timeRemaining < 0)
        timeRemaining = 0;

    if (d.formID == TimeForm) {
        /* Check for a minute change on the clock every 60 seconds */

        if (!timeRemaining) {
            SetCurrentTimeLabel(FrmGetActiveForm());
            d.NextPeriod = TimGetTicks() + 6000;
        }
    }
    else if ((d.formID == DiddleForm) || (d.formID == DiddleTForm)) {

        if (!timeRemaining) {
            if (d.formID == DiddleTForm) LabelTitle();
            if (recordIsCountdown && recordIsAlarmSet) {
                LabelAlarm();
                d.NextPeriod = ticks + 100;
            }
            else {
                d.NextPeriod = ticks + 6000;
            }
        }
        else if (recordIsCountdown && recordIsAlarmSet &&
                        (d.NextPeriod > (ticks+100))) {
            d.NextPeriod = ticks+100;
        }
    }
    else {
        timeRemaining = evtWaitForever;
    }
    return timeRemaining;
}

/*
** EventLoop - handle events
*/
static void EventLoop(void) {
    EventType e;
    Word error;
    FormPtr frm;

    do {
        EvtGetEvent(&e, TimeUntilNextTimePeriod());

        if (SpecialKeyDown(&e)) continue;

        if (SysHandleEvent(&e)) continue;

        if (MenuHandleEvent(NULL, &e, &error)) continue;

        if ((e.eType == frmLoadEvent) && (d.formID != e.data.frmLoad.formID)) {
            frm = FrmInitForm(d.formID = e.data.frmLoad.formID);
            FrmSetActiveForm(frm);
            switch (d.formID) {
                case DiddleForm:
                case DiddleTForm:
                    p.formID = d.formID;
                    FrmSetEventHandler(frm, DiddleEvent);
                    break;
                case TimeForm:
                    FrmSetEventHandler(frm, TimeEvent);
                    break;
                case PrefForm:
                    FrmSetEventHandler(frm, PrefEvent);
                    break;
            }
            continue;
        }

        FrmDispatchEvent(&e);

    } while (e.eType != appStopEvent);
}

/*
** StopApplication
*/
static void StopApplication(void) {
    PrefSetAppPreferences(AppType, 0, 1, &p, sizeof(p), true);
    WinDeleteWindow(d.winbufM, false);
    CloseDatabases();
}

/*
** BeamSend
*/
void BeamSend(void) {
    ExgSocketType exgSock;
    VoidHand t;
    VoidPtr ptr;
    UInt pos, bytes_to_send, bytes_sent;
    UInt recSize;
    Byte buf[BEAM_BUF_SIZE];
    DWord romversion = 0;
    Char tempString[32];
    Err err;

    /* Save the current data */
    FlushToDisk(true);

    /* Check for IR beaming capability */
    FtrGet(sysFtrCreator, sysFtrNumROMVersion, &romversion);
    if (romversion < 0x03003000) {
        FrmAlert(NoBeamForm);
        return;
    }

    /* Zero the exchange socket */
    MemSet(&exgSock, sizeof(ExgSocketType), 0);

    /* Set the target */
    exgSock.target = AppType;

    /* Set the name and description */
    SysCopyStringResource(tempString, BeamContentString);
    exgSock.name = MemPtrNew(StrLen(tempString)+1);
    StrCopy(exgSock.name, tempString);
    SysCopyStringResource(tempString, BeamTypeString);
    exgSock.description = MemPtrNew(StrLen(tempString+1));
    StrCopy(exgSock.description, tempString);

    /* Open the record */
    t = DmQueryRecord(d.dbR, p.dbI);
    ptr = MemHandleLock(t);

    /* Set the length */
    recSize = sizeof(DiddleBugRecordType);
    recSize += ((DiddleBugRecordPtr)ptr)->sketchLength;
    recSize += ((DiddleBugRecordPtr)ptr)->extraLength;
    recSize += 2; /* Null-terminated strings */
    exgSock.length = recSize;

    /* Do the beaming */
    err = ExgPut(&exgSock);
    if (!err) {
        pos = 0;
        while (1) {
            bytes_to_send = (((recSize-pos) < BEAM_BUF_SIZE) ?
                                (recSize-pos) : BEAM_BUF_SIZE);
            if (!bytes_to_send) break;
            MemMove(buf, ptr+pos, bytes_to_send);
            bytes_sent = ExgSend(&exgSock, buf, bytes_to_send, &err);
            if (err) break;
            pos += bytes_sent;
        }
        ExgDisconnect(&exgSock, err);
    }

    /* Cleanup */
    MemHandleUnlock(t);
    MemPtrFree(exgSock.name);
    MemPtrFree(exgSock.description);
}

/*
** BeamReceive - i before e, except after c
*/
void BeamReceive(ExgSocketPtr sockP, Boolean appIsActive) {
    DmOpenRef dbR;
    UInt recIndex, recSize;
    UInt pos, bytes_got;
    Byte buf[BEAM_BUF_SIZE];
    VoidHand t;
    VoidPtr ptr;
    Err err = 0;


    /* Open the database */
    if (appIsActive) dbR = d.dbR;
    else {
        dbR = DmOpenDatabaseByTypeCreator(DBType, AppType, dmModeReadWrite);
        if (!dbR) return;
    }

    /* Create the new record */
    recIndex = dmMaxRecordIndex;
    recSize = 512;
    t = DmNewRecord(dbR, &recIndex, recSize);
    if (t) {
        ptr = MemHandleLock(t);
        DmSet(ptr, 0, recSize, 0);
        /* Open Socket and start receiving */
        err = ExgAccept(sockP);
        if (!err) {
            pos = 0;
            while (1) {
                bytes_got = ExgReceive(sockP, buf, BEAM_BUF_SIZE, &err);
                if (!bytes_got) break;
                if (err) break;
                DmWrite(ptr, pos, buf, bytes_got);
                pos += bytes_got;
                MemHandleUnlock(t);
                recSize = pos+BEAM_BUF_SIZE;
                t = DmResizeRecord(dbR, recIndex, recSize);
                ptr = MemHandleLock(t);
            }
            ExgDisconnect(sockP, err);
        }
        MemHandleUnlock(t);
        t = DmResizeRecord(dbR, recIndex, pos);
        DmReleaseRecord(dbR, recIndex, true);
    }

    if (err) {
        DmRemoveRecord(dbR, recIndex);
    }
    else {
        /* Jump to the record */
        UInt cardNo;
        LocalID dbID;

        SetClosestAlarm(dbR);
        DmOpenDatabaseInfo(dbR, &dbID, NULL, NULL, &cardNo, NULL);
        sockP->goToCreator = AppType;
        sockP->goToParams.dbCardNo = cardNo;
        sockP->goToParams.dbID = dbID;
        sockP->goToParams.recordNum = recIndex;
    }

    /* Close the database */
    if (!appIsActive) DmCloseDatabase(dbR);
}

/*
** PilotMain - handle the toplevel command and event dispatch.
*/
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Err err;
    GoToParamsPtr pgoto;
    Boolean appIsActive;

    switch (cmd) {
    case sysAppLaunchCmdNormalLaunch:
        if(err = OpenDatabases()) return err;
        FrmGotoForm(p.formID);
        EventLoop();
        StopApplication();
        break;

    case sysAppLaunchCmdAlarmTriggered:
        appIsActive = launchFlags&sysAppLaunchFlagSubCall;
        TriggerAlarm((SysAlarmTriggeredParamType*)cmdPBP, appIsActive);
        break;

    case sysAppLaunchCmdDisplayAlarm:
        appIsActive = launchFlags&sysAppLaunchFlagSubCall;
        DisplayAlarm((SysDisplayAlarmParamType*)cmdPBP, appIsActive);
        break;

    case sysAppLaunchCmdSystemReset:
        SystemWasReset();
        break;

    case sysAppLaunchCmdGoTo:
        if (launchFlags&sysAppLaunchFlagNewGlobals) {
            if(err = OpenDatabases()) return err;
            p.dbI = ((GoToParamsPtr)cmdPBP)->recordNum;
            if ((p.dbI < 0) || (p.dbI >= DmNumRecords(d.dbR))) {
                StopApplication();
                return 0;
            }
            FrmGotoForm(p.formID);
            EventLoop();
            StopApplication();
        }
        else {
            SendGotoEvent(((GoToParamsPtr)cmdPBP)->recordNum);
        }
        break;

    case sysAppLaunchCmdExgReceiveData:
        if (launchFlags&sysAppLaunchFlagSubCall) appIsActive = true;
        else appIsActive = false;
        BeamReceive((ExgSocketPtr)cmdPBP, appIsActive);
        break;
    }

    return 0;

}

