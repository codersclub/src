/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;

    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = sysFileCAddress;

    /* Add the text to the clipboard */
    ClipboardAddItem(clipboardText, kleenexP->text, StrLen(kleenexP->text));

    /* Load the goto params */
    kleenexP->booger.cmdPBP = NULL;
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdNormalLaunch;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;
}

