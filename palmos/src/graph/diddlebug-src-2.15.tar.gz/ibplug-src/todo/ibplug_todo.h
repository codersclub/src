/* Error routines */

#define abort() ErrDisplayFileLineMsg(__FILE__, __LINE__, "")

#define IBVERSION_ORIG  0x0001
