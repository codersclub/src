/* booger.h  version 'a' */
#include <Pilot.h>

/* Launch command to activate a booger plugin */
#define boogerPlugLaunchCmdBlowNose 0x9101

/* Error codes */
#define boogerErrorVersionMismatch 7000

/* Structure for the BoogerType returned to DiddleBug */
typedef struct {
    UInt cardNo;            /* cardNo */
    LocalID dbID;           /* dbID */
    Word cmd;               /* Launch flags */
    Ptr cmdPBP;             /* usually a GoTo params */
} BoogerType;
typedef BoogerType *BoogerPtr;

/* Repeat types */
enum repeatTypes {
    repeatNone,
    repeatDaily,
    repeatWeekly,
    repeatMonthlyByDay,
    repeatMonthlyByDate,
    repeatYearly
};
typedef enum repeatTypes RepeatType;

/* Repeat info type (same as DateBook) */
typedef struct {
    RepeatType repeatType;            /* daily, weekly, monthlyByDay, etc. */
    DateType repeatEndDate;           /* minus one if forever */
    unsigned char repeatFrequency;    /* i.e. every 2 days */
    unsigned char repeatOn;           /* monthlyByDay and repeatWeekly only */
    unsigned char repeatStartOfWeek;  /* repeatWeekly only */
} RepeatInfoType;
typedef RepeatInfoType *RepeatInfoPtr;


/* Structure for cmdPBP of boogerPlugLaunchCmdBlowNose */
/* DiddleBug is responsible for freeing the pointers upon return */
typedef struct {
    DWord reserved1;
    DWord reserved2;
    UInt version;           /* version of this launch param */
    UInt data_size;         /* not implemented yet... */
    VoidPtr data;           /* Will eventually hold sketch data */
    CharPtr text;           /* Text as typed in the pick field */
    CharPtr title;          /* Title of the drawing (if any) */
    CharPtr category;       /* Category of the text (if any) */
    ULong alarm_secs;       /* Alarm seconds (zero if no alarm) */
    RepeatInfoPtr repeat;   /* Repeat info (in DateBook format) */
    SWord priority;         /* Priority of the reminder (default = 1) */
    BoogerType booger;      /* Filled by the BPlug to be read by DiddleBug */
    SWord is_complete;      /* Complete flag */
} KleenexType;
typedef KleenexType *KleenexPtr;

