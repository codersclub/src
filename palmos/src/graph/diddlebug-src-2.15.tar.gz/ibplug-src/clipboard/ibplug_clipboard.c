/*
** ibplug_clipboard - an IntelliBooger plugin for DiddleBug
** Copyright (c) 1999, Lonnon R. Foster <lonnonf@pobox.com>
** Licensed under the GNU GPL, version 2 or later
** See file "COPYING" that you should have received with this program
** or visit http://www.gnu.org/copyleft/gpl.html
** (pieces added by Mitch Blevins for launcher support)
** 
** DiddleBug is Copyright 1999, Mitch Blevins <mblevin@debian.org>, and is
** also licensed under the GNU GPL.  IntelliBooger is a trademark owned by
** Mitch Blevins.
**
** DiddleBug is based on Diddle, which is based on Doodle
** Doodle is Copyright 1997, Roger E Critchlow Jr., San Francisco, California.
** All rights reserved.  Fair use permitted.  Caveat emptor.  No warranty.
*/

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_clipboardRsc.h"
#include "ibplug_clipboard.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;

    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Add the text to the clipboard */
    ClipboardAddItem(clipboardText, kleenexP->text, StrLen(kleenexP->text));

    /* If goto is selected, we have DiddleBug launch this plugin again
     * which will in turn activate the launcher */
    kleenexP->booger.cmdPBP = NULL;
    kleenexP->booger.cmd = boogerPlugLaunchCmdLaunchLauncher;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'BooG',
                            'LFia', true, &cardNo, &dbID)) {
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;


    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        case boogerPlugLaunchCmdLaunchLauncher: {
                /* send a launch character to signal PalmOS */
                EventType e, launchEvent;
                launchEvent.eType = keyDownEvent;
                launchEvent.data.keyDown.chr = launchChr;
                launchEvent.data.keyDown.modifiers = commandKeyMask;
                EvtAddEventToQueue(&launchEvent);
                /* Loop until told otherwise */
                do {
                    EvtGetEvent(&e, evtWaitForever);
                    SysHandleEvent(&e);
                } while (e.eType != appStopEvent);
            }
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
