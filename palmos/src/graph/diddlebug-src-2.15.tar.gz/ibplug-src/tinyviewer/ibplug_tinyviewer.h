/* Error routines */
#define abort() ErrDisplayFileLineMsg(__FILE__, __LINE__, "")

#ifdef BOOGERDEBUG
#define ASSERT(a) if(!a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#define ASSERTNOT(a) if(a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#else  /* BOOGERDEBUG */
#define ASSERT(a)
#define ASSERTNOT(a)
#endif /* BOOGERDEBUG */

typedef struct {
    Char name[32];
    Word versionType;   /* Should be 0x00ff for diddlebug records */
    Long nextRec;
    Long note;
    Word lastPosX;
    Word lastPosY;
    Long reserved;
    Word anchorX;  /* 0xffff */
    Word anchorY;  /* 0xffff */
    Word width;    /* Word-aligned */
    Word height;
    /* data  in screen format */
} ImageViewerRecordType;
typedef ImageViewerRecordType *ImageViewerRecordPtr;


