/* Main code for IBPlug Hi-Note (text) */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_hi-note-textRsc.h"
#include "ibplug_hi-note-text.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;
    UInt index;
    NoteRec note;
    VoidHand t;
    VoidPtr recordP;
    ULong textLength;
    ULong uniqueID;


    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = 'HNA1';

    /* Open the database */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'HND2',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Write the new record (be sure to fill index) */
    textLength = StrLen(kleenexP->text);
    note.flags = 0x40; /* displayable */
    note.level = 0x00; /* root level */

    index = dmMaxRecordIndex;
    t = DmNewRecord(dbR, &index, 3+textLength);
    if (!t) abort();
    recordP = MemHandleLock(t);
    DmWrite(recordP, 0, &note, 2);
    DmWrite(recordP, 2, kleenexP->text, textLength+1);
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, index, true);

    /* Get the unique ID */
    uniqueID = 0;
    if (DmRecordInfo(dbR, index, NULL, &uniqueID, NULL)) abort();

    /* Close the database */
    DmCloseDatabase(dbR);

    /* Load the goto params */
    kleenexP->booger.cmdPBP = MemPtrNew(sizeof(GoToParamsType));
    if (!kleenexP->booger.cmdPBP) {
        abort();
        return 1;
    }
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbCardNo = cardNo;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbID = dbID;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->recordNum = index;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->searchStrLen = 0;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->matchPos = textLength;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->matchCustom = (DWord)uniqueID;
    MemPtrSetOwner(kleenexP->booger.cmdPBP, 0);
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdGoTo;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
