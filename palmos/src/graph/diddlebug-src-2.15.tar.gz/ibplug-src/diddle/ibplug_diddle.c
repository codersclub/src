/* Main code for IBPlug Diddle */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_diddleRsc.h"
#include "ibplug_diddle.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    VoidHand t;
    VoidPtr recordP;
    UInt cardNo;
    UInt index;
    UInt strLen;


    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_PICTURE))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = 'DIDL';

    /* Open the database */
    cardNo = 0;
    dbID = 0;
    dbID = DmFindDatabase(0, "DiddleIDB");
    if (!dbID) return 1;
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Write the new record (be sure to fill index) */
    index = dmMaxRecordIndex;
    t = DmNewRecord(dbR, &index, 3360);
    if (!t) abort();
    recordP = MemHandleLock(t);
    DmWrite(recordP, 0, kleenexP->data, 3200);
    DmSet(recordP, 3200, 160, 0);
    strLen = StrLen(kleenexP->text);
    if (strLen > 31) strLen = 31;
    DmWrite(recordP, 3200, kleenexP->text, strLen);
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, index, true);

    /* Close the database */
    DmCloseDatabase(dbR);

    /* Load the goto params */
    kleenexP->booger.cmdPBP = MemPtrNew(sizeof(GoToParamsType));
    if (!kleenexP->booger.cmdPBP) {
        abort();
        return 1;
    }
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbCardNo = cardNo;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbID = dbID;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->recordNum = index;
    MemPtrSetOwner(kleenexP->booger.cmdPBP, 0);
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdGoTo;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
