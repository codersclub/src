#include <stdio.h>

void usage(char *progname) {
    fprintf(stderr, "usage: %s [filename.prc]\n", progname);
    exit(1);
}

int main(int argc, char** argv) {
    char old_name[256];
    unsigned long i=0;
    int c;
    FILE *prcfile, *orig_prcfile;


    if (argc < 2) usage(argv[0]);

    printf("%s: preparing to replace prcversion with 2... ", argv[0]);
    strncpy(old_name, argv[1], 255);
    strncat(old_name, ".bak", 255);

    if (rename(argv[1], old_name)) {
        fprintf(stderr, "\n%s: could not rename %s\n", argv[0], argv[1]);
    }
    if (!(orig_prcfile = fopen(old_name, "r"))) {
        fprintf(stderr, "\n%s: could not open %s\n", argv[0], old_name);
        exit(1);
    }
    if (!(prcfile = fopen(argv[1], "w+"))) {
        fprintf(stderr, "\n%s: could not create %s\n", argv[0], argv[1]);
        exit(1);
    }

    while ((c = fgetc(orig_prcfile)) != EOF) {
        if (i == 34) c = 0x00;
        if (i == 35) c = 0x02;
        i++;
        fputc(c, prcfile);
    }
    fclose(prcfile);
    fclose(orig_prcfile);
    printf ("Done\n", argv[0]);
    return(0);
}

