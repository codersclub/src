/* Main code for IBPlug Calls (AN) */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_calls_anRsc.h"
#include "ibplug_calls_an.h"
#include "tododb.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* LoadAlarmText */
static void LoadAlarmText(ULong secs, CharPtr str) {
    Char tempStr[48];
    DateType date;
    DateTimeType dateTime;

    secs += (60 - (secs % 60));
    StrCopy(str, "ALRM: ");
    DateSecondsToDate(secs, &date);
    DateToAscii(date.month, date.day, date.year+firstYear, dfMDYWithSlashes,
                    tempStr);
    StrNCat(str, tempStr, 48);
    StrNCat(str, ",", 48);
    TimSecondsToDateTime(secs, &dateTime);
    TimeToAscii(dateTime.hour, dateTime.minute, tfColon24h, tempStr);
    StrNCat(str, tempStr, 48);
    StrNCat(str, "\n#AN\n", 48);
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    ULong gotoCrID;
    ToDoItemType todo;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;
    UInt category, index;
    Char catName[dmCategoryLength];
    Char callCatName[dmCategoryLength];
    Char alarmtext[48];
    Word i;
    Word err;
    DWord result;

    /* Check for correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
            return boogerErrorVersionMismatch;

    MemSet(&todo, sizeof(ToDoItemType), 0);

    /* Set the creatorID */
    creatorID = sysFileCToDo;
    gotoCrID = 'Actn';

    /* Set the due date */
    if (kleenexP->alarm_secs) {
        DateSecondsToDate(kleenexP->alarm_secs, &todo.dueDate);
    }
    else {
        *((WordPtr) &todo.dueDate) = toDoNoDueDate;
    }

    /* Set the alarm */
    if (kleenexP->alarm_secs) {
        LoadAlarmText(kleenexP->alarm_secs, alarmtext);
        todo.note = alarmtext;
    }
    else {
        todo.note = NULL;
    }

    /* Set the priority */
    todo.priority = 1;

    /* Set the complete flag */
    if (kleenexP->is_complete) todo.priority |= completeFlag;

    /* Set the category */
    category = 0;

    /* Set the description */
    todo.description = kleenexP->text;

    /* Open the database */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'DATA',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Reset the category to the "Calls" category */
    SysCopyStringResource(callCatName, CallCategoryString);
    StrCopy(catName, "");
    for (i=0; i<dmRecNumCategories; i++) {
        CategoryGetName(dbR, i, catName);
        if (!StrCaselessCompare(catName, callCatName)) {
            category = i;
            break;
        }
    }

    /* Write the record */
    err = 0;
    err = ToDoNewRecord(dbR, &todo, category, &index);
    if (err) return err;

    /* Close the database */
    DmCloseDatabase(dbR);



    /* Load the GoTo params */
    kleenexP->booger.cmdPBP = MemPtrNew(sizeof(GoToParamsType));
    if (!kleenexP->booger.cmdPBP) {
        abort();
        return 1;
    }
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbCardNo = cardNo;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbID = dbID;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->recordNum = index;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->matchCustom = 1; /* CallType */
    MemPtrSetOwner(kleenexP->booger.cmdPBP, 0);
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdGoTo;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            gotoCrID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;


    /* Signal ActionNames to set the alarm */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            gotoCrID, true, &cardNo, &dbID)) {
        FrmAlert(alertID_noActionNames);
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    if (SysAppLaunch(cardNo, dbID, 0, sysAppLaunchCmdSyncNotify,
                            NULL, &result)) {
        FrmAlert(alertID_noAlarmSet);
    }

    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
