// Set this to get to private database defines
#define __MEMOMGR_PRIVATE__

#include <Pilot.h>
#include "memodb.h"



Err MemoNewRecord (DmOpenRef dbP, MemoItemPtr item, UInt *index)
{
    Err 					result;
    ULong					size = 0;
    VoidHand				recordH;
    MemoDBRecordPtr	recordP;

    // Compute the size of the new memo record.
    size = StrLen (item->note);

    //  Allocate a chunk in the database for the new record.
    recordH = (VoidHand)DmNewHandle(dbP, size+1);
    if (recordH == NULL)
        return dmErrMemError;

    // Pack the the data into the new record.
    recordP = MemHandleLock (recordH);
    DmStrCopy(recordP, 0, item->note);

    MemPtrUnlock (recordP);

    // Insert the record.
    *index = dmMaxRecordIndex;
    result = DmAttachRecord(dbP, index, (Handle)recordH, 0);
    if (result)
        MemHandleFree(recordH);

    return result;
}

