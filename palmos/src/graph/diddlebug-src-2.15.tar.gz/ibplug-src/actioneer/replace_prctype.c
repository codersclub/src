#include <stdio.h>

void usage(char *progname) {
    fprintf(stderr, "usage: %s [filename.prc] [prctype]\n", progname);
    exit(1);
}

int main(int argc, char** argv) {
    char old_name[256];
    char type[5];
    unsigned long i=0;
    int c;
    FILE *prcfile, *orig_prcfile;


    if (argc < 2) usage(argv[0]);
    if (strlen(argv[2]) != 4) {
        fprintf(stderr, "%s: Error: prctype must be 4 characters\n", argv[0]);
        exit(1);
    }

    printf("%s: preparing to replace prc type with %s... ", argv[0], argv[2]);
    strncpy(type, argv[2], 4);
    strncpy(old_name, argv[1], 255);
    strncat(old_name, ".bak", 255);

    if (rename(argv[1], old_name)) {
        fprintf(stderr, "\n%s: could not rename %s\n", argv[0], argv[1]);
    }
    if (!(orig_prcfile = fopen(old_name, "r"))) {
        fprintf(stderr, "\n%s: could not open %s\n", argv[0], old_name);
        exit(1);
    }
    if (!(prcfile = fopen(argv[1], "w+"))) {
        fprintf(stderr, "\n%s: could not create %s\n", argv[0], argv[1]);
        exit(1);
    }

    while ((c = fgetc(orig_prcfile)) != EOF) {
        if (i == 60) c = (unsigned int) argv[2][0];
        if (i == 61) c = (unsigned int) argv[2][1];
        if (i == 62) c = (unsigned int) argv[2][2];
        if (i == 63) c = (unsigned int) argv[2][3];
        i++;
        fputc(c, prcfile);
    }
    fclose(prcfile);
    fclose(orig_prcfile);
    printf ("Done\n", argv[0]);
    return(0);
}

