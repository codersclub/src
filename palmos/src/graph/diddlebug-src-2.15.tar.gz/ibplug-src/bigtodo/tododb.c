#include <Pilot.h>
#include "tododb.h"
#include "ibplug_bigtodo.h"

/*
** ToDoGetAppInfo - Get the application info
*/
VoidHand ToDoGetAppInfo (DmOpenRef dbP) {
    Err error;
    UInt cardNo;
    LocalID dbID;
    LocalID appInfoID;

    error = DmOpenDatabaseInfo (dbP, &dbID, NULL, NULL, &cardNo, NULL);
    if (error) abort();

    error = DmDatabaseInfo (cardNo, dbID, NULL, NULL, NULL, NULL, NULL,
                            NULL, NULL, &appInfoID, NULL, NULL, NULL);
    if (error) abort();

    return ((VoidHand) MemLocalIDToGlobal (appInfoID, cardNo));
}

/*
** DateTypeCmp
*/
static Int DateTypeCmp(DateType d1, DateType d2) {
    Int result;

    result = d1.year - d2.year;
    if (result != 0) {
        if ((*(int *) &d1) == -1)
            return 1;
        if ((*(int *) &d2) == -1)
            return -1;
        return result;
    }

    result = d1.month - d2.month;
    if (result != 0)
        return result;

    result = d1.day - d2.day;

    return result;

}

/*
** CategoryCompare
*/
static Int CategoryCompare (Byte attr1, Byte attr2, VoidHand appInfoH) {
    Int result;
    Byte category1;
    Byte category2;
    ToDoAppInfoPtr appInfoP;


    category1 = attr1 & dmRecAttrCategoryMask;
    category2 = attr2 & dmRecAttrCategoryMask;

    result = category1 - category2;
    if (result != 0) {
        if (category1 == dmUnfiledCategory)
            return (1);
        else if (category2 == dmUnfiledCategory)
            return (-1);

        appInfoP = MemHandleLock (appInfoH);
        result = StrCompare (appInfoP->categoryLabels[category1],
                             appInfoP->categoryLabels[category2]);

        MemPtrUnlock (appInfoP);
        return result;
    }

    return result;
}

/*
** ToDoCompareRecords
*/
static Int ToDoCompareRecords(ToDoDBRecordPtr r1,
                              ToDoDBRecordPtr r2, Int sortOrder,
                              SortRecordInfoPtr info1, SortRecordInfoPtr info2,
                              VoidHand appInfoH) {
    Int result = 0;

    /* Sort by priority, due date, and category. */
    if (sortOrder == soPriorityDueDate) {
        result = (r1->priority & priorityOnly) - (r2->priority & priorityOnly);
        if (result == 0) {
            result = DateTypeCmp (r1->dueDate, r2->dueDate);
            if (result == 0) {
                result = CategoryCompare (info1->attributes,
                                            info2->attributes, appInfoH);
            }
        }
    }

    /* Sort by due date, priority, and category. */
    else if (sortOrder == soDueDatePriority) {
        result = DateTypeCmp(r1->dueDate, r2->dueDate);
        if (result == 0) {
            result = (r1->priority & priorityOnly) -
                        (r2->priority & priorityOnly);
            if (result == 0) {
                result = CategoryCompare (info1->attributes,
                                            info2->attributes, appInfoH);
            }
        }
    }

    /* Sort by category, priority, due date */
    else if (sortOrder == soCategoryPriority) {
        result = CategoryCompare (info1->attributes, info2->attributes,
                                    appInfoH);
        if (result == 0) {
            result = (r1->priority & priorityOnly) -
                        (r2->priority & priorityOnly);
            if (result == 0) {
                result = DateTypeCmp (r1->dueDate, r2->dueDate);
            }
        }
    }

    /* Sort by category, due date, priority */
    else if (sortOrder == soCategoryDueDate) {
        result = CategoryCompare (info1->attributes, info2->attributes,
                                    appInfoH);
        if (result == 0) {
            result = DateTypeCmp (r1->dueDate, r2->dueDate);
            if (result == 0) {
                result = (r1->priority & priorityOnly) -
                            (r2->priority & priorityOnly);
            }
        }
    }

    return result;
}

/*
** ToDoGetSortOrder
*/
Byte ToDoGetSortOrder (DmOpenRef dbP) {
    Byte sortOrder;
    ToDoAppInfoPtr appInfoP;

    appInfoP = MemHandleLock (ToDoGetAppInfo (dbP));
    sortOrder = appInfoP->sortOrder;
    MemPtrUnlock (appInfoP);

    return (sortOrder);
}

/*
** ToDoFindSortPosition
*/
static UInt ToDoFindSortPosition(DmOpenRef dbP, ToDoDBRecord *newRecord,
                                 SortRecordInfoPtr newRecordInfo) {
    int sortOrder;
    sortOrder = ToDoGetSortOrder (dbP);
    return (DmFindSortPosition (dbP, newRecord, newRecordInfo,
                                (DmComparF *)ToDoCompareRecords, sortOrder));
}

/*
** ToDoNewRecord - Create a new record from a ToDoItemPtr
**                 returns an index to the record in index
*/
Err ToDoNewRecord(DmOpenRef dbP, ToDoItemPtr item, UInt category, UInt *index) {
    Err err;
    UInt size;
    Char zero=0;
    UInt attr;
    UInt newIndex;
    ULong offset;
    ToDoDBRecordPtr nilP=0;
    ToDoDBRecordPtr recordP;
    VoidHand recordH;
    SortRecordInfoType sortInfo;

    /* Compute the size of the new to do record. */
    size = sizeDBRecord;
    if (item->description)
        size += StrLen (item->description);
    if (item->note)
        size += StrLen (item->note);


    /*  Allocate a chunk in the database for the new record. */
    recordH = (VoidHand)DmNewHandle(dbP, size);
    if (recordH == NULL)
        return dmErrMemError;

    /* Pack the the data into the new record. */
    recordP = MemHandleLock (recordH);
    DmWrite(recordP, (ULong)&nilP->dueDate, &item->dueDate,
                    sizeof(nilP->dueDate));
    DmWrite(recordP, (ULong)&nilP->priority, &item->priority,
                    sizeof(nilP->priority));

    offset = (ULong)&nilP->description;
    if (item->description) {
        DmStrCopy(recordP, offset, item->description);
        offset += StrLen (item->description) + 1;
    }
    else {
        DmWrite(recordP, offset, &zero, 1);
        offset++;
    }

    if (item->note)
        DmStrCopy(recordP, offset, item->note);
    else
        DmWrite(recordP, offset, &zero, 1);


    sortInfo.attributes = category;
    sortInfo.uniqueID[0] = 0;
    sortInfo.uniqueID[1] = 0;
    sortInfo.uniqueID[2] = 0;

    /* Determine the sort position of the new record. */
    newIndex = ToDoFindSortPosition (dbP, recordP, &sortInfo);

    MemPtrUnlock (recordP);

    /* Insert the record. */
    err = DmAttachRecord(dbP, &newIndex, (Handle)recordH, 0);
    if (err)
        MemHandleFree(recordH);
    else {

        *index = newIndex;

        /* Set the category. */
        DmRecordInfo (dbP, newIndex, &attr, NULL, NULL);
        attr &= ~dmRecAttrCategoryMask;
        attr |= category;
        DmSetRecordInfo (dbP, newIndex, &attr, NULL);
    }

    return err;
}

