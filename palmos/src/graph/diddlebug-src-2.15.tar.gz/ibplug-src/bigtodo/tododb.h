#ifndef __TDTODOMGR_H__
#define __TDTODOMGR_H__

#include <DateTime.h>

#define LocalizedAppInfoStr			1000

#define todoLabelLength		12
#define todoNumFields		16

#define toDoMaxPriority		5


/* Sort orders */
#define soDueDatePriority		0
#define soPriorityDueDate		1
#define soCategoryPriority		2
#define soCategoryDueDate		3



/* Dirty flags for to do application info */
#define toDoSortByPriorityDirty	0x0001

/* ToDoAppInfoType */
typedef struct {
    UInt				renamedCategories;
    char 				categoryLabels[dmRecNumCategories][dmCategoryLength];
    Byte 				categoryUniqIDs[dmRecNumCategories];
    Byte				lastUniqID;
    Byte				reserved1;
    Word				reserved2;
    UInt				dirtyAppInfo;
    Byte				sortOrder;
} ToDoAppInfoType;
typedef ToDoAppInfoType * ToDoAppInfoPtr;


/* ToDoDBRecord */
typedef struct {
    DateType dueDate;
    unsigned char priority;		// high bit is complete flag
    char description;
} ToDoDBRecord;

typedef ToDoDBRecord * ToDoDBRecordPtr;

/* sizeDBRecord */
#define sizeDBRecord (sizeof (ToDoDBRecord) + 1)

/* ToDoItemType */
typedef struct {
    DateType 			dueDate;
    unsigned char 		priority;		// high bit is complete flag
    CharPtr				description;
    CharPtr				note;
} ToDoItemType;
typedef ToDoItemType * ToDoItemPtr;


/* Flags */
#define completeFlag 	0x80
#define priorityOnly 	~completeFlag
#define toDoNoDueDate	0xffff

/* Routines */    
Err ToDoNewRecord(DmOpenRef dbP, ToDoItemPtr item, UInt category, UInt *index);
VoidHand ToDoGetAppInfo  (DmOpenRef dbP);
Byte ToDoGetSortOrder (DmOpenRef dbP);

#endif
