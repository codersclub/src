#include <Pilot.h>

//#define	NON_PORTABLE
//#include <MemoryPrv.h>

// Set this to get to private database defines
#define __APPTMGR_PRIVATE__
// #include "Datebook.h"
#include "datedb.h"


/***********************************************************************
 *
 *	Internal Structutes
 *
 ***********************************************************************/

// The following structure doesn't really exist.  The first field
// varies depending on the data present.  However, it is convient
// (and less error prone) to use when accessing the other information.
typedef struct {
    ApptDateTimeType 	when;
    ApptDBRecordFlags	flags;	// A flag set for each  datum present
    char				firstField;
} ApptPackedDBRecordType;

typedef ApptPackedDBRecordType * ApptPackedDBRecordPtr;

typedef Int comparF (const void *, const void *, Int other);



/***********************************************************************
 *
 *	Internal Routines
 *
 ***********************************************************************/

static Int TimeCompare (TimeType t1, TimeType t2);

static Int DateCompare (DateType d1, DateType d2);



/***********************************************************************
 *
 * FUNCTION:    DateCompare
 *
 * DESCRIPTION: This routine compares two dates.
 *
 * PARAMETERS:  d1 - a date 
 *              d2 - a date 
 *
 * RETURNED:    if d1 > d2  returns a positive int
 *              if d1 < d2  returns a negative int
 *              if d1 = d2  returns zero
 *
 * NOTE: This routine treats the DateType structure like an unsigned int,
 *       it depends on the fact the the members of the structure are ordered
 *       year, month, day form high bit to low low bit.
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/95		Initial Revision
 *
 ***********************************************************************/
static Int DateCompare (DateType d1, DateType d2) {
    UInt int1, int2;

    int1 = DateToInt(d1);
    int2 = DateToInt(d2);

    if (int1 > int2)
        return (1);
    else if (int1 < int2)
        return (-1);
    return 0;
}


/***********************************************************************
 *
 * FUNCTION:    TimeCompare
 *
 * DESCRIPTION: This routine compares two times.  "No time" is represented
 *              by minus one, and is considered less than all times.
 *
 * PARAMETERS:  nothing
 *
 * RETURNED:    if t1 > t2  returns a positive int
 *              if t1 < t2  returns a negative int
 *              if t1 = t2  returns zero
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art	6/12/95		Initial Revision
 *
 ***********************************************************************/
static Int TimeCompare (TimeType t1, TimeType t2) {
    Int int1, int2;

    int1 = TimeToInt(t1);
    int2 = TimeToInt(t2);

    if (int1 > int2)
        return (1);
    else if (int1 < int2)
        return (-1);
    return 0;

}


/************************************************************
 *
 *  FUNCTION:    ApptComparePackedRecords
 *
 *  DESCRIPTION: Compare two packed records.
 *
 *  PARAMETERS:  r1    - database record 1
 *				     r2    - database record 2
 *               extra - extra data, not used in the function
 *
 *  RETURNS:    -1 if record one is less
 *		           1 if record two is less
 *
 *  CREATED: 1/14/95 
 *
 *  BY: Roger Flores
 *
 *	COMMENTS:	Compare the two records key by key until
 *	there is a difference.  Return -1 if r1 is less or 1 if r2
 *	is less.  A zero is never returned because if two records
 *	seem identical then their unique IDs are compared!
 *
 *************************************************************/
static Int ApptComparePackedRecords (ApptPackedDBRecordPtr r1,
                                     ApptPackedDBRecordPtr r2, Int extra, SortRecordInfoPtr info1,
                                     SortRecordInfoPtr info2, VoidHand appInfoH) {
    Int result;

    if ((r1->flags.repeat) || (r2->flags.repeat)) {
        if ((r1->flags.repeat) && (r2->flags.repeat))
            result = 0;
        else if (r1->flags.repeat)
            result = -1;
        else
            result = 1;
    }
    else {
        result = DateCompare (r1->when.date, r2->when.date);
        if (result == 0) {
            result = TimeCompare (r1->when.startTime, r2->when.startTime);
        }
    }
    return result;
}


/************************************************************
 *
 *  FUNCTION: ApptPackedSize
 *
 *  DESCRIPTION: Return the packed size of an ApptDBRecordType 
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the size in bytes
 *
 *  CREATED: 1/25/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static UInt ApptPackedSize (ApptDBRecordPtr r) {
    UInt size;


    size = sizeof (ApptDateTimeType) + sizeof (ApptDBRecordFlags);

    if (r->alarm != NULL)
        size += sizeof (AlarmInfoType);

    if (r->repeat != NULL)
        size += sizeof (RepeatInfoType);

    if (r->exceptions != NULL)
        size += sizeof (UInt) +
                (r->exceptions->numExceptions * sizeof (DateType));

    if (r->description != NULL)
        size += StrLen(r->description) + 1;

    if (r->note != NULL)
        size += StrLen(r->note) + 1;


    return size;
}


/************************************************************
 *
 *  FUNCTION: ApptPack
 *
 *  DESCRIPTION: Pack an ApptDBRecordType
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: the ApptPackedDBRecord is packed
 *
 *  CREATED: 1/25/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static void ApptPack(ApptDBRecordPtr s, ApptPackedDBRecordPtr d) {
    ApptDBRecordFlags	flags;
    UInt 	size;
    ULong	offset = 0;


    *(unsigned char *)&flags = 0;			// clear the flags


    // copy the ApptDateTimeType
    //c = (char *) d;
    offset = 0;
    DmWrite(d, offset, s->when, sizeof(ApptDateTimeType));
    offset += sizeof (ApptDateTimeType) + sizeof (ApptDBRecordFlags);


    if (s->alarm != NULL) {
        DmWrite(d, offset, s->alarm, sizeof(AlarmInfoType));
        offset += sizeof (AlarmInfoType);
        flags.alarm = 1;
    }


    if (s->repeat != NULL) {
        DmWrite(d, offset, s->repeat, sizeof(RepeatInfoType));
        offset += sizeof (RepeatInfoType);
        flags.repeat = 1;
    }


    if (s->exceptions != NULL) {
        size = sizeof (UInt) +
               (s->exceptions->numExceptions * sizeof (DateType));
        DmWrite(d, offset, s->exceptions, size);
        offset += size;
        flags.exceptions = 1;
    }


    if (s->description != NULL) {
        size = StrLen(s->description) + 1;
        DmWrite(d, offset, s->description, size);
        offset += size;
        flags.description = 1;
    }



    if (s->note != NULL) {
        size = StrLen(s->note) + 1;
        DmWrite(d, offset, s->note, size);
        offset += size;
        flags.note = 1;
    }

    DmWrite(d, sizeof(ApptDateTimeType), &flags, sizeof(flags));
}


/************************************************************
 *
 *  FUNCTION: ApptFindSortPosition
 *
 *  DESCRIPTION: Return where a record is or should be
 *		Useful to find or find where to insert a record.
 *
 *  PARAMETERS: database record
 *
 *  RETURNS: position where a record should be
 *
 *  CREATED: 1/25/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
static UInt ApptFindSortPosition(DmOpenRef dbP, ApptPackedDBRecordPtr newRecord) {
    return (DmFindSortPosition (dbP, newRecord, NULL, (DmComparF *)ApptComparePackedRecords, 0));
}


/************************************************************
 *
 *  FUNCTION: ApptNewRecord
 *
 *  DESCRIPTION: Create a new packed record in sorted position
 *
 *  PARAMETERS: database pointer
 *				database record
 *
 *  RETURNS: ##0 if successful, error code if not
 *
 *  CREATED: 1/25/95 
 *
 *  BY: Roger Flores
 *
 *************************************************************/
Err ApptNewRecord(DmOpenRef dbP, ApptDBRecordPtr r, UInt *index) {
    VoidHand recordH;
    ApptPackedDBRecordPtr recordP;
    UInt 					newIndex;
    Err err;


    // Make a new chunk with the correct size.
    recordH = DmNewHandle (dbP, (ULong) ApptPackedSize(r));
    if (recordH == NULL)
        return dmErrMemError;

    recordP = MemHandleLock (recordH);

    // Copy the data from the unpacked record to the packed one.
    ApptPack (r, recordP);

    newIndex = ApptFindSortPosition(dbP, recordP);

    MemPtrUnlock (recordP);

    // 4) attach in place
    err = DmAttachRecord(dbP, &newIndex, (Handle)recordH, 0);
    if (err)
        MemHandleFree(recordH);
    else
        *index = newIndex;

    return err;
}

