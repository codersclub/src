
#include "linker.h"
#include "ibplug_datebook.h"
#include "ibplug_datebookRsc.h"

CharPtr AddLinkToText(CharPtr origText, short recordNum) {
    ULong param, result;
    LinkerCPB commandBlock;
    UInt cardNo;
    LocalID dbID;
    CharPtr returnText;
    DmSearchStateType searchstate;

    returnText = MemPtrNew(StrLen(origText)+6);
    StrCopy(returnText, origText);
    if(FtrGet('Linx', 1001, &param) != 0) { /* Linker is not present and active */
        return returnText;
    }


    MemSet(&commandBlock, sizeof(LinkerCPB), 0);
    commandBlock.creator = 'Linx'; /* maybe this is overkill, but .... */
    commandBlock.message = LinkerNewLinkMessage;
    /* commandBlock.linkTag is empty and to be filled by Linker */
    commandBlock.gotoTargetAppCreator = 'DIDB'; /* DiddleBug is the target */

    /* Find the dbID and cardNo for the gotoparams */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'Data', 'DIDB', true,
                            &cardNo, &dbID)) {
        abort();
        return returnText;
    }
    commandBlock.gotoLinkParams.dbCardNo = cardNo;
    commandBlock.gotoLinkParams.dbID = dbID;
    commandBlock.gotoLinkParams.recordNum = recordNum;

    /* Signal Linker */
    SysCurAppDatabase(&cardNo, &dbID);
    SysAppLaunch(cardNo, dbID, 0, linkerAppLaunchCmdSignalLinker,
                    (Ptr)&commandBlock, &result);

    /* Now I have the link tag to insert into the datebook entry */
    commandBlock.linkTag[5] = 0x00; /* just to be sure */
    StrCat(returnText, commandBlock.linkTag);

    return returnText;
}

