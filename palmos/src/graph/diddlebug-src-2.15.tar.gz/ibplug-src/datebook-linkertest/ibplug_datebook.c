/* Main code for IBPlug DateBook */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_datebookRsc.h"
#include "ibplug_datebook.h"
#include "datedb.h"

extern CharPtr AddLinkToText(CharPtr origText, short recordNum);


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/*
** SetSaneTimes - set start and end times from a given seconds
*/
static void SetSaneTimes(ULong secs, TimePtr startP, TimePtr endP) {
    DateTimeType date_time;

    /* Get the Time from the alarm seconds */
    TimSecondsToDateTime(secs, &date_time);
    if (secs % 60) TimAdjust(&date_time, (60 - (secs % 60)));
    startP->hours = date_time.hour;
    startP->minutes = date_time.minute;
    if (startP->hours != 23) {
        endP->hours = startP->hours+1;
        endP->minutes = startP->minutes;
    }
    else {
        endP->hours = startP->hours;
        endP->minutes = 59;
    }
}


/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;
    UInt index;
    ApptDBRecordType datebook;
    ApptDateTimeType dbwhen;
    AlarmInfoType dbalarm;
    ULong secs;
    Word err;
    DWord result;


    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = sysFileCDatebook;

    /* Zero the memory */
    MemSet(&datebook, sizeof(ApptDBRecordType), 0);
    MemSet(&dbwhen, sizeof(ApptDateTimeType), 0);
    MemSet(&dbalarm, sizeof(AlarmInfoType), 0);
    datebook.when = &dbwhen;
    datebook.alarm = &dbalarm;

    /* Set the date and time */
    if (!(secs = kleenexP->alarm_secs)) secs = TimGetSeconds();
    DateSecondsToDate(secs, &dbwhen.date);
    if (kleenexP->alarm_secs) {
        SetSaneTimes(secs, &dbwhen.startTime, &dbwhen.endTime);
    }
    else {
        TimeToInt(dbwhen.startTime) = apptNoTime;
        TimeToInt(dbwhen.endTime) = apptNoTime;
    }

    /* Set the alarm */
    dbalarm.advanceUnit = aauMinutes;
    if (kleenexP->alarm_secs) {
        dbalarm.advance = 0;
    }
    else {
        dbalarm.advance = apptNoAlarm;
        datebook.alarm = NULL;
    }

    /* Set the repeat */
    datebook.repeat = kleenexP->repeat;

    /* Forget the exceptions and note */
    datebook.exceptions = NULL;
    datebook.note = NULL;

    /* Set the text */
    datebook.description = AddLinkToText(kleenexP->text,
                                            kleenexP->sketchRecordNum);
    /* Make sure to free the memory */

    /* Open the database */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'DATA',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Write the new record (be sure to fill index) */
    err = 0;
    err = ApptNewRecord(dbR, &datebook, &index);
    if (err) return err;

    /* Close the database */
    DmCloseDatabase(dbR);
    /* Free the changed text */
    MemPtrFree(datebook.description);

    /* Load the goto params */
    kleenexP->booger.cmdPBP = MemPtrNew(sizeof(GoToParamsType));
    if (!kleenexP->booger.cmdPBP) {
        abort();
        return 1;
    }
    MemSet(kleenexP->booger.cmdPBP, sizeof(GoToParamsType), 0);
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbCardNo = cardNo;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbID = dbID;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->recordNum = index;
    MemPtrSetOwner(kleenexP->booger.cmdPBP, 0);
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdGoTo;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Signal DateBook to set the alarm */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    if (SysAppLaunch(cardNo, dbID, 0, sysAppLaunchCmdSyncNotify,
                            NULL, &result)) {
        FrmAlert(alertID_noAlarmSet);
    }


    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
