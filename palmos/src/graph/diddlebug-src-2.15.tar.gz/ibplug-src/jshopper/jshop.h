
#define		MAX_STORES			15
#define		MAX_STORE_NAME_LENGTH		25

#define		CHECK_HAVE_IN_ALL		0x0001
#define		CHECK_HAVE_IN_NEEDS		0x0002
#define		SHOW_COUPON_COLUMN		0x0004
#define		SHOW_QUANTITY_COLUMN		0x0008
#define		NO_ASSOCIATE_ALL_STORES		0x0010
#define		SHOW_AISLE_COLUMN		0x0020
#define		SHOW_PRICE_COLUMN		0x0040

#define		STORE_1				0x0001
#define		STORE_2				0x0002
#define		STORE_3				0x0004
#define		STORE_4				0x0008
#define		STORE_5				0x0010
#define		STORE_6				0x0020
#define		STORE_7				0x0040
#define		STORE_8				0x0080
#define		STORE_9				0x0100
#define		STORE_10			0x0200
#define		STORE_11			0x0400
#define		STORE_12			0x0800
#define		STORE_13			0x1000
#define		STORE_14			0x2000
#define		STORE_15			0x4000
#define		STORE_ALL			0xffff


typedef struct			
{
	Int	isNeeded;	// MUST remain first in structure
	Int	store;		// bitmap flags for which store(s) it belongs to
	Int	coupon;
	Int	oneTime;
	Int	quantity;
	Int	aisle;
	Int 	price;
	// Char	itemName;	// holds start of data for each field
} RecordType;			

typedef RecordType* RecordTypePtr;  

typedef struct 			// App Preferences Structure
{
	Int				flags;
	char    			storeNames[10+1][MAX_STORE_NAME_LENGTH+1];
	UInt				topVisibleRecord;
	UInt				currentRecord;
	Boolean				isShowingAll;
	Int				currentStoreNum;
} AppPreferencesType; // old not used in 1.3 and up

typedef struct 
{
	Int				flags;
	char    			storeNames[MAX_STORES+1][MAX_STORE_NAME_LENGTH+1];
	UInt				topVisibleRecord;
	UInt				currentRecord;
	Boolean				isShowingAll;
	Int				currentStoreNum;
	Int				isShowingCoupons;
	Int				reserved2;
	Int				reserved3;
	Int				reserved4;
	Int				autoSort;
	Int				all1Timers;
	Int				autoQuantity;
	Int				reserved8;
	Int				reserved9;
	Int				reserved10;
	Int				reserved11;
	Int				reserved12;
} JShopAppInfoType;

typedef JShopAppInfoType * JShopAppInfoPtr;

#define APP_TYPE	'JSho'    		// type for application. 
#define DB_TYPE		'JsDb'   		// type for application database.  
#define DB_NAME		"JShopperDB"		// database name


