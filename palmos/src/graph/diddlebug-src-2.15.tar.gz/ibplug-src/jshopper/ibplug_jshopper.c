/* Main code for IBPlug JShopper */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_jshopperRsc.h"
#include "ibplug_jshopper.h"
#include "jshop.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;
    UInt index;
    RecordType record;
    VoidHand t;
    VoidPtr recordP;
    UInt strLen;

    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = APP_TYPE; /* 'JSho' */

    /* Open the database */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, DB_TYPE,
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Write the new record (be sure to fill index) */
    MemSet(&record, sizeof(RecordType), 0);
    record.isNeeded = 0xffff;
    record.store = STORE_ALL;
    record.oneTime = 0xffff;
    record.quantity = 1;
    strLen = StrLen(kleenexP->text);
    index = dmMaxRecordIndex;
    t = DmNewRecord(dbR, &index, sizeof(RecordType)+strLen+1);
    if (!t) abort();
    recordP = MemHandleLock(t);
    DmSet(recordP, 0, sizeof(RecordType)+strLen+1, 0);
    DmWrite(recordP, 0, &record, sizeof(RecordType));
    DmWrite(recordP, sizeof(RecordType), kleenexP->text, strLen);
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, index, true);

    /* Close the database */
    DmCloseDatabase(dbR);

    /* Load the goto params */
    kleenexP->booger.cmdPBP = NULL;
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdNormalLaunch;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
