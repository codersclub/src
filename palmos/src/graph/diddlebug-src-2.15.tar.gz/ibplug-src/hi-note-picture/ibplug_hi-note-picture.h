/* Error routines */
#define abort() ErrDisplayFileLineMsg(__FILE__, __LINE__, "")

#ifdef BOOGERDEBUG
#define ASSERT(a) if(!a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#define ASSERTNOT(a) if(a) ErrDisplayFileLineMsg(__FILE__, __LINE__, "Assert")
#else  /* BOOGERDEBUG */
#define ASSERT(a)
#define ASSERTNOT(a)
#endif /* BOOGERDEBUG */

#define flagsTwistOpen   0x80
#define flagsDisplayable 0x40
#define flagsPict        0x20
#define flagsReadOnly    0x10
typedef struct {
    Byte flags;
    Byte level;
    /* Null terminated string */
    /* Pictdata */
} NoteRec;

typedef struct {
    Word width;
    Word height;
    /* Byte data[n] */
} Pictdata;


