/* Main code for IBPlug Hi-Note (picture) */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_hi-note-pictureRsc.h"
#include "ibplug_hi-note-picture.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* Get the Hi-Note record size */
static ULong HiNoteDoStuff(VoidPtr data,VoidPtr oP,Boolean justCounting) {
    ULong srcCnt, dupCnt, wrCnt, finalCnt, padCnt;
    unsigned char *srcPtr;
    unsigned char *wrPtr;
    unsigned char *outP;
    unsigned char lastByte;
    unsigned char wrBuf[514];
    Word width, height;

    srcCnt = 3200;
    finalCnt = 4; /* width and height */
    wrCnt = 0;
    srcPtr = data;
    wrPtr = &wrBuf[2];
    outP = oP;
    if (!justCounting) {
        width = 160; height = 250;
        MemMove(outP, &width, 2);
        outP += 2;
        MemMove(outP, &height, 2);
        outP += 2;
    }
    while (srcCnt) {
        lastByte = *srcPtr++;
        *wrPtr++ = lastByte;
        srcCnt--;
        wrCnt++;
        /* Check write trigger conditions */
        if (((srcCnt > 1) && (lastByte == srcPtr[0]) && (lastByte == srcPtr[1]))
                    || (wrCnt == 512) || (!srcCnt)) {
            /* Write required */
            dupCnt = 0;
            while (srcCnt) {
                if (*srcPtr != lastByte) break; /* Next byte not a duplicate */
                srcPtr++;
                srcCnt--;
                if (++dupCnt == 63) break; /* Maximum duplicate count */
            }
            wrCnt--;
            wrBuf[0] = (dupCnt << 2) | (wrCnt >> 8);
            wrBuf[1] = wrCnt;
            wrCnt += 3;
            if (justCounting) {
                finalCnt += wrCnt;
            }
            else {
                MemMove(outP, wrBuf, wrCnt);
                outP += wrCnt;
            }
            wrPtr = &wrBuf[2];
            wrCnt = 0;
        }
    }
    /* Add the extra blank space to fill to 250 pixels height */
    padCnt = 1800; /* (250-160)*160/8 */
    while (padCnt) {
        wrCnt = 0;
        if (padCnt >= 63) {
            dupCnt = 63;
            padCnt -= 63;
        }
        else {
            dupCnt = padCnt;
            padCnt = 0;
        }
        wrBuf[0] = (dupCnt << 2) | (wrCnt >> 8);
        wrBuf[1] = wrCnt;
        wrBuf[2] = 0x00;
        if (justCounting) finalCnt += 3;
        else {
            MemMove(outP, wrBuf, 3);
            outP += 3;
        }
    }

    return finalCnt;
}


/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmOpenRef dbR;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;
    UInt index;
    ULong recordSize;
    NoteRec note;
    VoidHand t;
    VoidPtr recordP;
    VoidPtr sketchP;
    ULong textLength;
    ULong uniqueID;

    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_PICTURE))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = 'HNA1';

    /* Open the database */
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'HND2',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    dbR = DmOpenDatabase(cardNo, dbID, dmModeReadWrite);
    if (!dbR) return 1;

    /* Write the new record (be sure to fill index) */

    textLength = StrLen(kleenexP->text);
    recordSize = HiNoteDoStuff(kleenexP->data, NULL, true); /* just cnt */
    sketchP = MemPtrNew(recordSize);
    HiNoteDoStuff(kleenexP->data, sketchP, false); /* fill */
    recordSize += textLength; /* the pick text */
    recordSize += 3; /* flags and level and null for text */
    note.flags = 0x60; /* displayable and pict */
    note.level = 0x00; /* root level */

    index = dmMaxRecordIndex;
    t = DmNewRecord(dbR, &index, recordSize);
    if (!t) abort();
    recordP = MemHandleLock(t);
    DmWrite(recordP, 0, &note, 2);
    DmWrite(recordP, 2, kleenexP->text, textLength+1);
    DmWrite(recordP, 3+textLength, sketchP, recordSize-3-textLength);
    MemPtrFree(sketchP);
    MemHandleUnlock(t);
    DmReleaseRecord(dbR, index, true);


    /* Get the unique ID */
    uniqueID = 0;
    if (DmRecordInfo(dbR, index, NULL, &uniqueID, NULL)) abort();

    /* Close the database */
    DmCloseDatabase(dbR);

    /* Load the goto params */
    kleenexP->booger.cmdPBP = MemPtrNew(sizeof(GoToParamsType));
    if (!kleenexP->booger.cmdPBP) {
        abort();
        return 1;
    }
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbCardNo = cardNo;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->dbID = dbID;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->recordNum = index;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->searchStrLen = 0;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->matchPos = textLength;
    ((GoToParamsPtr)(kleenexP->booger.cmdPBP))->matchCustom = (DWord)uniqueID;
    MemPtrSetOwner(kleenexP->booger.cmdPBP, 0);
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdGoTo;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        MemPtrFree(kleenexP->booger.cmdPBP);
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;
}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
