#!/usr/bin/perl
#
# Replace first line with your path to the perl executable

Usage() if @ARGV != 2;
die "Error: prctype must be 4 characters\n" if (length($ARGV[1]) != 4);

($filename, $prctype) = @ARGV;

open(FILE, "+<$filename")
    or die "Cannot open $filename: $!\n";
binmode(FILE);
seek(FILE, 60, 0)
    or die "Error seeking: $!\n";
read(FILE, $oldtype, 4)
    or die "Error reading: $!\n";
seek(FILE, -4, 1)
    or die "Error seeking: $!\n";
print FILE $prctype;
close FILE
    or die "Error closing $filename: $!\n";

sub Usage() {
    die <<"EOT";
Usage:  $0 [filename.prc] [prctype]
EOT
}
