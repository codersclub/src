/* Main code for IBPlug SuperNames */

#include <Pilot.h>
#include "booger.h"
/* #include "callback.h" */

#include "ibplug_supernamesRsc.h"
#include "ibplug_supernames.h"


/* Get preferences, open (or create) app database */
static Word StartApplication(void) {
    return 0;
}

/* Save preferences, close forms, close app database */
static void StopApplication(void) {
}

/* The main processing */
/* Fill the kleenexP->booger struct and return 0 if no error */
static Word BlowNose(KleenexPtr kleenexP) {
    ULong creatorID;
    DmSearchStateType searchstate;
    LocalID dbID;
    UInt cardNo;

    /* Check for the correct version */
    if (!((kleenexP->version)&IBVERSION_ORIG))
        return boogerErrorVersionMismatch;

    /* Load new record info here (plugin-dependant) */
    creatorID = 'SNms';

    /* Add the text to the clipboard */
    ClipboardAddItem(clipboardText, kleenexP->text, StrLen(kleenexP->text));

    /* Load the goto params */
    kleenexP->booger.cmdPBP = NULL;
    /* Load the other stuff */
    kleenexP->booger.cmd = sysAppLaunchCmdNormalLaunch;
    if (DmGetNextDatabaseByTypeCreator(true, &searchstate, 'appl',
                            creatorID, true, &cardNo, &dbID)) {
        return 1;
    }
    kleenexP->booger.cardNo = cardNo;
    kleenexP->booger.dbID = dbID;

    /* Alls well that ends well... */
    return 0;

}

/* Main entry point; it is unlikely you will need to change this except to
   handle other launch command codes */
DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags) {
    Word err;

    switch (cmd) {
        case boogerPlugLaunchCmdBlowNose:
            err = StartApplication();
            if (err) return err;

            err = BlowNose((KleenexPtr)cmdPBP);
            if (err) return err;

            StopApplication();
            break;
        default:
            return sysErrParamErr;
            break;
    }

    return 0;
}
