#! /usr/bin/perl
#
# Replace the first line with the path to your perl executable

Usage() if @ARGV != 1;

$filename = shift @ARGV;

open(FILE, "+<$filename")
    or die "Cannot open $filename: $!\n";
binmode(FILE);
seek(FILE, 34, 0)
    or die "Error seeking: $!\n";
read(FILE, $oldversion, 2)
    or die "Error reading: $!\n";
seek(FILE, -2, 1)
    or die "Error seeking: $!\n";
print FILE chr(0) . chr(2);
close FILE
    or die "Error closing $filename: $!\n";

sub Usage() {
    die <<"EOT";
Usage:  $0 [filename.prc]
EOT
}
