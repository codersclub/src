#ifndef __UTIL_H_
#define __UTIL_H_

extern FlashMessagePtr FlashMessage(UInt strID);
extern void UnFlashMessage(FlashMessagePtr flashP);
extern void FlashWaitMessage(UInt strID);

#endif // __UTIL_H_
