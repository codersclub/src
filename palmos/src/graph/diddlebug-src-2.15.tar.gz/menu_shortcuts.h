// menu_shortcuts.h is generated dynamically from menu_shortcuts.h.in
// Modify menu_shortcuts.h.in if you want your changes to stick

// Pens
#define penFine             '.'
#define penMedium           '~'
#define penBold             '#'
#define penBroad            '@'
#define penFineItalic       ','
#define penMediumItalic     '/'
#define penBroadItalic      ';'

// Inks
#define inkWhite            '0'
#define inkDith12           '1'
#define inkDith25           '2'
#define inkDith37           '3'
#define inkDith50           '4'
#define inkDith62           '5'
#define inkDith75           '6'
#define inkDith87           '7'
#define inkBlack            '8'
#define inkRandom           '9'

// Tools
#define modeErase           'e'
#define modePaint           'p'
#define modeSmear           'm'
#define cmdRough            '<'
#define cmdSmooth           '='
#define cmdSmoother         '>'

// Other
#define cmdAbout            'a'
#define cmdPref             'h'
#define cmdClear            'x'
#define cmdFill             'f'
#define cmdInvert           'w'
#define cmdSketchUndo       'u'
#define cmdRemove           'r'
#define cmdTitle            't'
#define cmdNew              'n'
#define cmdPrevious         '-'
#define cmdNext             '+'
#define cmdText             'z'
#define cmdLine             'k'
#define cmdShape            'o'
#define cmdInsertLast       'l'
#define cmdLock             'j'
#define cmdTransfer         'g'
#define cmdBeam             'b'

