#include "diddlebug.h"
#include "diddlebugRsc.h"

extern pref p;
extern data d;

/*
** LoadShapeRect - load rectangle for drawing shapes
*/
static Word LoadShapeRect(RectanglePtr r, short x, short y) {
    short int smallside, largeside;
    short int xdiff, ydiff;
    Word corner;

    /* Figure out the rectangle data */
    if (SHAPE_CIRCLE != p.shape_type) {
        r->topLeft.x = ((d.anchor.x < x) ? d.anchor.x : x);
        r->topLeft.y = ((d.anchor.y < y) ? d.anchor.y : y);
        r->extent.x = ((d.anchor.x > x) ? d.anchor.x : x) - r->topLeft.x;
        r->extent.y = ((d.anchor.y > y) ? d.anchor.y : y) - r->topLeft.y;
        smallside = ((r->extent.x < r->extent.y) ? r->extent.x : r->extent.y);
    }
    else {
        if (x > d.anchor.x) xdiff = x - d.anchor.x;
        else xdiff = d.anchor.x - x;
        if (y > d.anchor.y) ydiff = y - d.anchor.y;
        else ydiff = d.anchor.y - y;
        largeside = (xdiff > ydiff ? xdiff : ydiff);
        if (largeside > (d.anchor.x-p.r.topLeft.x))
            largeside = d.anchor.x - p.r.topLeft.x;
        if (largeside > (d.anchor.y-p.r.topLeft.y))
            largeside = d.anchor.y - p.r.topLeft.y;
        if (largeside > (p.r.topLeft.x+p.r.extent.x-d.anchor.x))
            largeside = p.r.topLeft.x+p.r.extent.x-d.anchor.x;
        if (largeside > (p.r.topLeft.y+p.r.extent.y-d.anchor.y))
            largeside = p.r.topLeft.y+p.r.extent.y-d.anchor.y;
        r->topLeft.x = d.anchor.x - largeside;
        r->topLeft.y = d.anchor.y - largeside;
        r->extent.x = largeside+largeside;
        r->extent.y = largeside+largeside;
    }

    switch (p.shape_type) {
        case SHAPE_ROUNDRECT:
            corner = smallside / 4;
            break;
        case SHAPE_OVAL:
            corner = smallside /2;
            break;
        case SHAPE_CIRCLE:
            corner = largeside;
            break;
        case SHAPE_RECTANGLE:
        default:
            corner = 0;
            break;
    }
    return corner;
}

/*
** ClearOldShape - removes the xor'd shape from the screen
*/
void ClearOldShape(void) {
    RectangleType rect;

    WinInvertRectangle(&rect,LoadShapeRect(&rect, d.ox, d.oy));
}

/*
** DoShape - draw the shape on the screen
*/
void DoShape(SWord x, SWord y) {
    RectangleType rect;
    /* Draw the shape */
    WinInvertRectangle(&rect,LoadShapeRect(&rect, x, y));
    d.ox = x;
    d.oy = y;
}

/*
** EndShape - draw the final shape on the screen
*/
void EndShape(SWord x, SWord y) {
    short dx, dy, origx, origy, i;
    Word corner;
    Word error = 0;
    RectangleType rect;
    WinHandle oseh, osmh, owh;
    short adjx, adjy;

    corner = LoadShapeRect(&rect, x, y);

    switch (p.shape_fill) {
        case SHFILL_OUTLINE:
            /* Create the offscreen window to hold rectangle */
            owh = WinGetDisplayWindow();
            osmh = WinCreateOffscreenWindow(rect.extent.x+16, rect.extent.y+16,
                            screenFormat, &error);
            if (error) abort();
            WinSetDrawWindow(osmh);
            WinEraseWindow();
            /* Create second off-screen rectangle for pen-shaped shape */
            oseh = WinCreateOffscreenWindow(rect.extent.x+16, rect.extent.y+16,
                            screenFormat, &error);
            if (error) abort();
            WinSetDrawWindow(oseh);
            WinEraseWindow();
            /* Draw a one-pixel width rectangle into the window */
            origx = rect.topLeft.x; origy = rect.topLeft.y;
            rect.topLeft.x = 8; rect.topLeft.y = 8;
            WinDrawRectangle(&rect, corner);
            if ((rect.extent.x > 2) && (rect.extent.y > 2)) {
                rect.topLeft.x++; rect.topLeft.y++;
                rect.extent.x -= 2; rect.extent.y -= 2;
                WinEraseRectangle(&rect, (corner > 0) ? (corner-1) : 0);
                rect.topLeft.x--; rect.topLeft.y--;
                rect.extent.x += 2; rect.extent.y += 2;
            }
            WinSetDrawWindow(osmh);
            /* Copy the rect into drawable window as defined by the pen */
            for (i = 0; i < NPENPIX && p.penpix[i] != 0; i += 1) {
                dx = dxFromPenpix(p.penpix[i]);
                dy = dyFromPenpix(p.penpix[i]);
                if (rect.topLeft.x < 0) continue;
                if (rect.topLeft.y < 0) continue;
                WinCopyRectangle(oseh, osmh, &rect, 8+dx, 8+dy, scrOR);
            }
            if ((origx-p.r.topLeft.x) > 8) adjx = 8;
            else adjx = origx-p.r.topLeft.x;
            if ((origy-p.r.topLeft.y) > 8) adjy = 8;
            else adjy = origy-p.r.topLeft.y;
            rect.topLeft.x = 8-adjx; rect.topLeft.y = 8-adjy;
            rect.extent.x += (8+adjx); rect.extent.y += (8+adjy);
            /* This gets very complicated, but for some reason the
            ** scrAND function does not seem to work (PalmV) *shrug*
            */
            /* CopyNOT the mask to extra offscreen window (anti-mask) */
            WinCopyRectangle(osmh,oseh,&rect,8-adjx,8-adjy,scrCopyNOT);
            /* then OR the mask onto the screen */
            WinCopyRectangle(osmh,owh,&rect,origx-adjx,origy-adjy,scrOR);
            /* Draw a pattern over the mask */
            WinSetDrawWindow(osmh);
            WinFillRectangle(&rect, 0);
            /* OR the anti-mask onto the pattern */
            WinCopyRectangle(oseh, osmh, &rect, 8-adjx, 8-adjy, scrOR);
            /* CopyNOT the anti mask onto the real mask */
            WinCopyRectangle(osmh, oseh, &rect, 8-adjx, 8-adjy, scrCopyNOT);
            /* XOR the result onto the screen */
            WinCopyRectangle(oseh,owh,&rect,origx-adjx,origy-adjy,scrXOR);
            /* Whew... cleanup */
            WinSetDrawWindow(owh);
            WinDeleteWindow(osmh, false);
            WinDeleteWindow(oseh, false);
            break;
        case SHFILL_FILL:
            if (p.modeSelection == SEL_MODE_ERASE)
                WinEraseRectangle(&rect, corner);
            else
                WinFillRectangle(&rect, corner);
            break;
        case SHFILL_XOR:
            WinInvertRectangle(&rect, corner);
            break;
    }
            
    d.drawmode = MODE_DOODLE; /* Clean up */
}

