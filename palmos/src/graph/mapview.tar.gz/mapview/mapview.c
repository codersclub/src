/* mapview.c: example program for panning around a greyscale image
   Ian Goldberg, <iang@cs.berkeley.edu>

    IN NO EVENT SHALL THE AUTHORS OR DISTRIBUTORS BE LIABLE TO ANY PARTY
    FOR DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES
    ARISING OUT OF THE USE OF THIS SOFTWARE, ITS DOCUMENTATION, OR ANY
    DERIVATIVES THEREOF, EVEN IF THE AUTHORS HAVE BEEN ADVISED OF THE
    POSSIBILITY OF SUCH DAMAGE.

    THE AUTHORS AND DISTRIBUTORS SPECIFICALLY DISCLAIM ANY WARRANTIES,
    INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
    MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE, AND
    NON-INFRINGEMENT.  THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS,
    AND THE AUTHORS AND DISTRIBUTORS HAVE NO OBLIGATION TO PROVIDE
    MAINTENANCE, SUPPORT, UPDATES, ENHANCEMENTS, OR MODIFICATIONS.

 */

#include <PalmOS.h>
#include <PalmCompatibility.h>

/* This is the image */
#include "map.h"

/* Set up the display in either greyscale or B/W mode.  vpw is the virtual
   page width _in words_ (word = 16 bits).  This bit derived from code
   in a _PDA Developers_ article by Edward Keyes. */
static const void *setgrey(int grey, const void *newSSA, unsigned char vpw)
{
    const void *oldSSA;
    const void * volatile *SSA = (const void**)0xfffffa00;
    volatile unsigned char *CKCON = (unsigned char *)0xfffffa27;
    volatile unsigned char *VPW = (unsigned char *)0xfffffa05;
    volatile unsigned char *PICF = (unsigned char *)0xfffffa20;
    volatile unsigned char *LBAR = (unsigned char *)0xfffffa29;
    volatile unsigned char *FRCM = (unsigned char *)0xfffffa31;
    volatile unsigned char *POSR = (unsigned char *)0xfffffa2d;

    oldSSA = *SSA;
    *CKCON &= 0x7f;
    *SSA = newSSA;
    if (grey) {
	*VPW = vpw;
	*PICF |= 0x01;
	*LBAR = 22;
	*FRCM = 0xb9;
	*POSR &= 0xf0;
    } else {
	*VPW = vpw;
	*PICF &= 0xfe;
	*LBAR = 10;
	*POSR &= 0xf0;
    }
    SysTaskDelay(2);
    *CKCON |= 0x80;
    return oldSSA;
}

/* Adjust the SSA and POSR so that the image is offset by (xoff,yoff) _pixels_.
   Width is in bytes.  Assumes greyscale mode. */
static void adjSSA(const unsigned char *base, int width, int xoff, int yoff)
{
    const unsigned char * volatile *SSA = (const unsigned char **)0xfffffa00;
    volatile unsigned char *POSR = (unsigned char *)0xfffffa2d;

    unsigned char curPOSR = *POSR;
    int xoffb = xoff >> 2;
    unsigned char POS = xoff & 0x03;

    *POSR = (curPOSR & 0xf0) + POS;
    *SSA = base + xoffb + width*yoff;
}

static Boolean ApplicationHandleEvent(EventPtr e)
{
    Boolean handled = false;
    static int lastx = -1, lasty = -1;
    static int cumx = 0, cumy = 0;

    switch(e->eType) {
    case penDownEvent:
	if (e->screenY < 160) {
	    WinWindowToDisplayPt(&e->screenX, &e->screenY);
	    lastx = e->screenX;
	    lasty = e->screenY;
	    handled = true;
	} else {
	    lastx = -1;
	    lasty = -1;
	}
	break;
    case penMoveEvent:
	if (lastx >= 0) {
	    int xdiff, ydiff;
	    WinWindowToDisplayPt(&e->screenX, &e->screenY);
	    xdiff = lastx - (int)e->screenX;
	    ydiff = lasty - (int)e->screenY;
	    if (xdiff > map_width - 160 - cumx) {
		xdiff = map_width - 160 - cumx;
	    } else if (xdiff < -cumx) {
		xdiff = -cumx;
	    }
	    if (ydiff > map_height - 160 - cumy) {
		ydiff = map_height - 160 - cumy;
	    } else if (ydiff < -cumy) {
		ydiff = -cumy;
	    }
	    cumx += xdiff;
	    cumy += ydiff;
	    adjSSA(map_data, map_width/4, cumx, cumy);
	    lastx = e->screenX;
	    lasty = e->screenY;
	    handled = true;
	}
	break;
    case penUpEvent:
	lastx = -1;
	lasty = -1;
	break;
    default:
	break;
    }
    return handled;
}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType e;
  const void *oldSSA;

  if (cmd == sysAppLaunchCmdNormalLaunch) {

    oldSSA = setgrey(1, map_data, map_width/8);

    do {
      EvtGetEvent(&e, evtWaitForever);
      if (! SysHandleEvent(&e))
        ApplicationHandleEvent(&e);
    } while (e.eType != appStopEvent);

    setgrey(0, oldSSA, 10);

  } else {
    return sysErrParamErr;
  }
  return 0;
}
