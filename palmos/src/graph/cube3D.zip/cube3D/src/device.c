/*
 * @(#)device.c
 *
 * Copyright 1999-2000, Aaron Ardiri (mailto:aaron@ardiri.com)
 * All rights reserved.
 *
 * The  source code  outlines a number of basic Palm Computing Programming
 * principles and you  should be able to take the core structure and write 
 * a large complex program. It is distributed WITHOUT ANY WARRANTY; use it
 * "AS IS" and at your own risk.
 *
 * The code presented is Copyright 1999-2000 by Aaron Ardiri. It should be
 * used for  educational purposes only.  You  shall not modify the  Cube3D 
 * source code in any way and  re-distribute it as your  own,  however you
 * are free to use  the code as  a guide for  developing  programs  on the 
 * Palm Computing Platform.
 */

#include "palm.h"

// globals variable structure
typedef struct
{
  UInt32    romVersion;                    // the rom version of the device
  UInt32    depthState;                    // the screen depth state (old)
} DeviceGlobals;

/**
 * Initialize the device.
 */
void
DeviceInitialize()
{
  DeviceGlobals *gbls;
 
  // create the globals objects, and register it
  gbls = (DeviceGlobals *)MemPtrNew(sizeof(DeviceGlobals));
  MemSet(gbls, sizeof(DeviceGlobals), 0);
  FtrSet(appCreator, ftrDeviceGlobals, (UInt32)gbls);

  // get the rom version and ram size for this device
  FtrGet(sysFtrCreator, sysFtrNumROMVersion, &gbls->romVersion);

  // only OS 3.0 and above have > 1bpp display via API's
  if (DeviceSupportsVersion(romVersion3)) {

    // save the current display state
    WinScreenMode(winScreenModeGet,NULL,NULL,&gbls->depthState,NULL);

    // change into the "highest" possible mode :P
    {
      UInt32 depthsToTry[] = { 8, 4, 2, 1 };
      UInt32 *depthPtr = &depthsToTry[0];

      // loop until a valid mode is found
      while (WinScreenMode(winScreenModeSet,NULL,NULL,depthPtr,NULL)) {

        // try the next depth
        depthPtr++;
      }
    }
  }
}

/**
 * Get the supported depths the device can handle. 
 *
 * @return the depths supported (1011b = 2^3 | 2^1 | 2^0 = 4,2,1 bpp).
 */
UInt32  
DeviceGetSupportedDepths()
{
  UInt32 result = 0x00000001;

  // only OS 3.0 and above have > 1bpp display via API's
  if (DeviceSupportsVersion(romVersion3)) {
    WinScreenMode(winScreenModeGetSupportedDepths,NULL,NULL,&result,NULL);
  }

  return result;
}

/**
 * Check if the device is compatable with a particular ROM version.
 *
 * @param version the ROM version to compare against.
 * @return true if it is compatable, false otherwise.
 */
Boolean 
DeviceSupportsVersion(UInt32 version)
{
  DeviceGlobals *gbls;

  // get a globals reference
  FtrGet(appCreator, ftrDeviceGlobals, (UInt32 *)&gbls);

  return (Boolean)(gbls->romVersion >= version);
}

/**
 * Determine the pointer to the bitmap data chunk for a specific window.
 *
 * @param win the window.
 * @return a pointer to the bitmap data chunk.
 */
void *
DeviceWindowGetPointer(WinHandle win)
{
  void *result = NULL;

  // palmos 3.5        - use BmpGetBits()
  if (DeviceSupportsVersion(romVersion3_5)) {
    result = BmpGetBits(WinGetBitmap(win));
  }

  // palmos pre 3.5    - use standard technique
  else
    result = (void *)win->displayAddrV20;
    
  return result;
}

/**
 * Reset the device to its original state.
 */
void
DeviceTerminate()
{
  DeviceGlobals *gbls;

  // get a globals reference
  FtrGet(appCreator, ftrDeviceGlobals, (UInt32 *)&gbls);

  // restore the current display state
  if (DeviceSupportsVersion(romVersion3)) {
    WinScreenMode(winScreenModeSet,NULL,NULL,&gbls->depthState,NULL);
  }

  // clean up memory
  MemPtrFree(gbls);

  // unregister global data
  FtrUnregister(appCreator, ftrDeviceGlobals);
}
