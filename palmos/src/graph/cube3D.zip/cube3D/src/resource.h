/*
 * @(#)resource.h
 *
 * Copyright 1999-2000, Aaron Ardiri (mailto:aaron@ardiri.com)
 * All rights reserved.
 *
 * The  source code  outlines a number of basic Palm Computing Programming
 * principles and you  should be able to take the core structure and write 
 * a large complex program. It is distributed WITHOUT ANY WARRANTY; use it
 * "AS IS" and at your own risk.
 *
 * The code presented is Copyright 1999-2000 by Aaron Ardiri. It should be
 * used for  educational purposes only.  You  shall not modify  the Cube3D 
 * source code in any way and  re-distribute it as your  own,  however you
 * are free to use  the code as  a guide for  developing  programs  on the 
 * Palm Computing Platform.
 */

#include "palm.h"

// bitmaps

#define bitmapIcon              1000
#define bitmapPalm              1001
#define bitmapPaw               1002
#define bitmapAbout             1003
#define bitmapHelp              1004
#define bitmapHelpAnimation     1005

// dialogs

#define infoForm                2000
#define infoFormOkButton        2001
#define helpForm                2100
#define helpFormScrollBar       2101
#define helpFormOkButton        2102
#define xmemForm                2200
#define xmemFormOkButton        2201

// forms

#define mainForm                3100
#define mainFormHelpButton      3101
#define mainFormAboutButton     3102

// menus

#define mainMenu                3100
#define menuItemHelp            3101
#define menuItemAbout           3102
