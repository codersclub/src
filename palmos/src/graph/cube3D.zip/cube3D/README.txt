----------------------------------------------------------------------------
 Cube 3D demonstration
----------------------------------------------------------------------------

  BACKGROUND:
  ===========

  Cube3D  is simple  but it  outlines  many  of  the basic  starting point 
  questions  that are commonly  asked  on the  palm-dev-forum  email list.
  If you  are seriously  interested in Palm Computing development  then be
  sure to check out the development website hosted by Palm Computing:

    http://www.palmos.com/

  26-Dec-2000: updated to support non m68k-CPU architecture when performing
               an offscreen buffer copy operation in the 160x160 mode.

  31-Jul-2000: updated for future compatability with NON 160x160 devices
               - asm routines used if 160x160, api routines otherwise.

  10-Jan-2000: updated to compile under THREE development environments!!!!
               - prc-tools
               - codewarrior (using constructor)
               - codewarrior (using PilRC plugin)

  INSTALLATION:
  =============

  Cube3D is designed for the Palm Computing Platform.  'cube3D.prc' should 
  be installed  into your handheld  device using the instructions provided 
  by the manufacturer. 

  The following devices are supported:

    Pilot 1000
    Pilot 5000 
    Palm Personal 
    Palm Professional
    Palm III, IIIe, IIIx, IIIse, IIIxe, IIIc
    Palm V, Vx
    Palm VII
    Handspring Visor, Visor Deluxe, Visor Platinum, Visor Prism
    IBM Workpad c3 (40X, 40U), 30X and 20X
    Qualcomm pdQ Smartphone
    SONY PEG-300, PEG-S500C
    Symbol SPT 1500, 1700, 1740
    TRGPro

  DEVELOPMENT
  ===========

  Cube3D was developed using prc-tools 2.0 (GNU gcc compiler) that can be 
  obtained from the here: 

    http://www.palmos.com/dev/tech/tools/gcc/index.html

  The  source code  outlines a number of basic Palm Computing Programming
  principles and you  should be able to take the core structure and write 
  a large complex program. It is distributed WITHOUT ANY WARRANTY; use it
  "AS IS" and at your own risk.

  The code presented is Copyright 1999-2000 by Aaron Ardiri. It should be
  used for  educational purposes only.  You  shall not modify  the Cube3D 
  source code in any way and  re-distribute it as your  own,  however you
  are free to use  the code as  a guide for  developing  programs  on the 
  Palm Computing Platform.

  Thankyou for downloading Cube3D!

  // az
  aaron@ardiri.com

----------------------------------------------------------------------------
