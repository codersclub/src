#define formID_select		2000
#define formID_info		2001

#define listID_data		3000

#define buttonID_info		4000
#define buttonID_done		4001
#define buttonID_delete		4002
#define buttonID_view		4003

#define menuID_select		5000

#define menuitemID_about	6000

#define alertID_about		7000
#define alertID_delete		7001
#define alertID_instr		7002
#define alertID_done		7003
#define alertID_iv		7004
#define alertID_warn		7005

#define fieldID_note		8000

#define groupID_0		1
