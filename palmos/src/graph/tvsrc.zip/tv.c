/*
 * Tiny viewer
 *      View images
 *
 * Ken Shirriff         ken.shirriff@eng.sun.com
 *
 * Copyright (c) 1997 Sun Microsystems, Inc. All Rights Reserved.
 *
 * SUN MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY OF
 * THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED
 * TO THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE, OR NON-INFRINGEMENT. SUN SHALL NOT BE LIABLE FOR
 * ANY DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 * Please refer to the file "license.txt"
 * for further important copyright and licensing information.
 */

#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>

#include "tv.h"
#define AppType    'KStv'
#define AppDBType   'vIMG'
#define AppVersion  1

#define assert(x) if (!(x)) abort("error")

#if 1
#define abort(msg)      ErrDisplayFileLineMsg(__FILE__, __LINE__, msg)
#else
#define abort(msg)      ErrDisplayFileLineMsg(__FILE__, __LINE__, "")
#endif

#define disp(str) WinDrawChars(str, StrLen(str), 10, 10)

struct datahdr {
  char 	name[32];
  char	version;
  char	type;
  char	reserved[4];
  char	note[4];
  short	x_last;
  short	y_last;
  char	reserved2[4];
  short	x_anchor;
  short	y_anchor;
  short	width;
  short	height;
};

// True if we're displaying a graphics image
Boolean graphics = false;

#define MAXDB 50

// Number of database items
int nitems = 0;
char *items[MAXDB];
LocalID items_ID[MAXDB];
UInt items_rec[MAXDB];
Boolean items_anim[MAXDB];

LocalID viewerID = 0;

int frame = 0;	// For animation
int animated = 0;
int next_anim_buffer = 0;

// Temporary compression/decompression buffer
#define BUFLEN 2048
unsigned char buf[BUFLEN];

// Variables for openRecord/closeRecord
DmOpenRef dbR = NULL;
VoidHand hand;

struct mem_data {
  unsigned char *ptr;
  VoidHand sdbHand;
};

struct mem_data mem[2];

struct img_data {
  int width, height;
  unsigned char *ptr;
  Boolean gray;
};

struct img_data img[2];
int mapNum;

int mode = buttonID_view;
int currentindex = -1;

const void *oldSSA;

long xOffset, yOffset;
char linebuf[50];

static void StartApplication(void);
static void StopApplication(void);
static void displayMoveCount(void);
static void EventLoop(void);
static Boolean selectEvent(EventPtr event);
static Boolean infoEvent(EventPtr event);
static void *openRecord(LocalID dbID, UInt index);
static void getImageList();
static void closeRecord(void);
static void adjSSA(Boolean gray, const unsigned char *base, int width,
  long xoff, long yoff);
static void resetDisplay();
static void resetDisplayAndStorage();
static const void *setgray(int gray, const void *newSSA, unsigned int vpw,
  Boolean pan);
static const void *getSSA();
static Boolean ApplicationHandleEvent(EventPtr e);
static void loadImage(int idx, int frame);
static Boolean doPenEvent(EventPtr event);
static void *getObjectPtr(Word objID);
static void delete(UInt index);
static unsigned char *makeStorage(long len, int idx, Boolean dbonly);
static void freeStorage(int idx);
static void freeStorageAndDB();
static void uncompress(unsigned char **inptr, long len, unsigned char **outptr);
static void uncompressdb(unsigned char **inptr, long len, unsigned char **outptr);
static void msg(char *str);
static int makezoom();

// Main loop
DWord  PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  if (cmd == sysAppLaunchCmdNormalLaunch)
 {
    StartApplication();

    FrmGotoForm(formID_select);

    EventLoop();  // Event loop

    StopApplication();
  }
  return 0;
}

static void StartApplication(void) {
  MemSet(img, sizeof(struct img_data)*2, 0);
  oldSSA = getSSA();
}

static void StopApplication(void) {
  closeRecord();
  resetDisplayAndStorage();
}

long wakeup = -1;

static void EventLoop(void)
{
  short err;
  int formID;
  FormPtr form;
  EventType event;

  do
  {

    if (wakeup == -1) {
      EvtGetEvent(&event, evtWaitForever);
    } else {
      long timeout = wakeup - TimGetTicks();
      if (timeout < 0) {
	timeout = 1;
      }
      EvtGetEvent(&event, timeout);
    }

reprocess:

    if (!graphics || event.eType != keyDownEvent) {
      if (SysHandleEvent(&event)) continue;
    }
    if (!graphics || event.eType != keyDownEvent) {
      if (MenuHandleEvent((void *)0, &event, &err)) continue;
    }

    // Get out of graphics mode if a command key (e.g. alarm) is issued
    if (graphics && event.eType == keyDownEvent &&
	event.data.keyDown.modifiers&commandKeyMask &&
        event.data.keyDown.chr != pageDownChr &&
        event.data.keyDown.chr != pageUpChr) {
      resetDisplayAndStorage();
      if (event.data.keyDown.chr != menuChr) {
	// Don't actually do the menu operation
        goto reprocess;
      }
    }

    if (event.eType == frmLoadEvent)
    {
      formID = event.data.frmLoad.formID;
      form = FrmInitForm(formID);
      FrmSetActiveForm(form);
      switch (formID) 
      {
      case formID_select:
        FrmSetEventHandler(form, (FormEventHandlerPtr) selectEvent);
        break;
      case formID_info:
        FrmSetEventHandler(form, (FormEventHandlerPtr) infoEvent);
        break;
      }
    }

    FrmDispatchEvent(&event);
  } while(event.eType != appStopEvent);
}

// Form for the image selection page
static Boolean selectEvent(EventPtr event)
{
  // Check if it's time to go to the next image.
  if (wakeup != -1 && wakeup < TimGetTicks()) {
    wakeup = -1;
    if (graphics && animated) {
      loadImage(currentindex, ++frame);
    }
  }

  switch (event->eType) 
  {
  case frmOpenEvent:
    getImageList();
    if (mode) {
      CtlSetValue(getObjectPtr(mode), 1);
    }
    LstSetSelection(getObjectPtr(listID_data), currentindex);
    FrmDrawForm(FrmGetActiveForm());
    msg("u/d to zoom, menu to exit");
    return true;
    break;
    
  case keyDownEvent:
    if (graphics) {
      if (animated) {
	if (event->data.keyDown.chr == pageUpChr && frame > 0) {
	  loadImage(currentindex, --frame);
	} else if (event->data.keyDown.chr == pageDownChr) {
	  loadImage(currentindex, ++frame);
	}
      } else if (event->data.keyDown.chr == pageUpChr ||
	    event->data.keyDown.chr == pageDownChr) {
	// Do the zoom
	if (img[1].ptr==0) {
	  // Create the zoomed out image
	  int mz = makezoom();
	  if (mz==0) {
	    // Not enough memory
	    resetDisplayAndStorage();
	    break;
	  }
	}
	if (mapNum==0) {
	  // Go to zoomed out image
	  xOffset = xOffset/2;
	  yOffset = yOffset/2;
	} else {
	  // Go to fullsize image
	  xOffset = xOffset*2;
	  yOffset = yOffset*2;
	}
	mapNum = 1-mapNum;
	setgray(img[mapNum].gray, img[mapNum].ptr, img[mapNum].width, true);
	adjSSA(img[mapNum].gray, img[mapNum].ptr, img[mapNum].width, xOffset, yOffset);
      }
    }
    break;

  case menuEvent:
    switch (event->data.menu.itemID)
    {
    case menuitemID_about:
      FrmAlert(alertID_about);
      return true;
    }
    break;

  case lstSelectEvent:
  case ctlSelectEvent:
    // A click on either the list or the mode may cause an action
    // Update the state
    if (event->eType == lstSelectEvent) {
      currentindex = event->data.lstSelect.selection;
    } else {
      mode = event->data.ctlSelect.controlID;
    }
    // Perform the action
    if (currentindex != -1) {
      switch (mode) {
      case buttonID_view:
	loadImage(currentindex, 0);
	msg("");
	break;
      case buttonID_info:
        FrmGotoForm(formID_info);
	break;
      case buttonID_delete:
	if (FrmCustomAlert(alertID_delete,items[currentindex],"","")==0) {
	  delete(currentindex);
	  currentindex = -1;
	}
	mode = buttonID_view;
        FrmGotoForm(formID_select);
	break;
      }
    }
    return true;
    break;

  // Move the image
  case penDownEvent:
  case penMoveEvent:
  case penUpEvent:
    if (graphics) {
      return doPenEvent(event);
    }
    return false;
    break;

  }
  return false;
}

// Form for the info page
static Boolean infoEvent(EventPtr event)
{
  struct datahdr *hdr;
  ULong len;
  switch (event->eType) 
  {
  case frmOpenEvent:
    hdr = (struct datahdr *)openRecord(items_ID[currentindex], items_rec[currentindex]);
    assert(hdr);
    FrmDrawForm(FrmGetActiveForm());
    len = StrLen(hdr->name);
    WinDrawChars(hdr->name, len>32?32:len, 10, 15);
    StrIToA(linebuf, hdr->width);
    StrCat(linebuf, "x");
    StrIToA(linebuf+StrLen(linebuf), hdr->height);
    WinDrawChars(linebuf, StrLen(linebuf), 10, 25);
    if (items_anim[currentindex]) {
      DmDatabaseSize(0, items_ID[currentindex], NULL, &len, NULL);
    } else {
      len = MemHandleSize(hand);
    }
    StrIToA(linebuf, (len+512)/1024);
    StrCat(linebuf,"k");
    WinDrawChars(linebuf, StrLen(linebuf), 10, 35);
    if (hdr->type==(char)0xff) {
      StrCopy(linebuf, "B/W");
    } else {
      StrCopy(linebuf, "Grayscale");
    }
    if (hdr->version&1) {
      StrCat(linebuf, ", compressed");
    }
    if (items_anim[currentindex]) {
      StrCat(linebuf, ", anim");
    }
    if (items_ID[currentindex] == viewerID) {
      if (hdr->note[3]>0) {
        StrCat(linebuf, ", note");
      }
    } else {
      if (openRecord(items_ID[currentindex], 1)) {
        StrCat(linebuf, ", note");
      }
    }
    WinDrawChars(linebuf, StrLen(linebuf), 10, 45);
    closeRecord();
    return true;
    break;
    
  case ctlSelectEvent:
    // Button causes us to go back to selection page
    FrmGotoForm(formID_select);
    return true;
  }

  return false;
}

// Scroll the image
static Boolean doPenEvent(EventPtr event)
{
  static int lastx = -1, lasty = -1;

  switch (event->eType) {
  case penDownEvent:
      if (event->screenY < 160) {
	  lastx = event->screenX;
	  lasty = event->screenY;
	  return true;
      } else {
	  lastx = -1;
	  lasty = -1;
      }
      break;
  case penMoveEvent:
      if (lastx >= 0) {
	  int xdiff, ydiff;
	  xdiff = lastx - (int)event->screenX;
	  ydiff = lasty - (int)event->screenY;
	  xOffset += xdiff;
	  yOffset += ydiff;

	  if (xOffset >= img[mapNum].width-160) {
	    xOffset = img[mapNum].width-160;
	  }
	  if (xOffset < 0) {
	    xOffset = 0;
	  }
	  if (yOffset >= img[mapNum].height-160) {
	    yOffset = img[mapNum].height-160;
	  }
	  if (yOffset < 0) {
	    yOffset = 0;
	  }
	  adjSSA(img[mapNum].gray, img[mapNum].ptr, img[mapNum].width, xOffset, yOffset);
	  lastx = event->screenX;
	  lasty = event->screenY;
	  return true;
      }
      break;
  case penUpEvent:
      lastx = -1;
      lasty = -1;
      break;
  default:
      break;
  }
    return false;
}

// Helper function
static void *getObjectPtr(Word objID) {
  FormPtr frm = FrmGetActiveForm();
  return FrmGetObjectPtr(frm, FrmGetObjectIndex(frm, objID));
}

RectangleType msgRect = {30,120,130,12};

// Display a message line
static void msg(char *str) {
  WinEraseRectangle(&msgRect, 0);
  StrCopy(linebuf,str);
  WinDrawChars(linebuf, StrLen(linebuf), msgRect.topLeft.x, msgRect.topLeft.y);
}

DmOpenRef sdbR;
LocalID sdbID;
UInt sdbC;

// Allocate some storage from the heap or the temporary database
// We can allocate up to two storage regions, specified by idx
// If mem.sdbHand is set, the storage came from the database
static unsigned char *makeStorage(long len, int idx, Boolean dbonly)
{
  int err;
  UInt at;
  RectangleType r;
  DmSearchStateType state;

  assert(mem[idx].ptr == NULL);

  if (len > 65535) {
    return 0;
  }

  if (!dbonly) {
    mem[idx].ptr = MemPtrNew(len);
    if (mem[idx].ptr != NULL) {
      return (mem[idx].ptr);
    }
  }

  if (sdbR==0) {
    // Create the database (silent error if it already exists)
    DmCreateDatabase(0, "Temp", AppType, 'Data', false);
    err = DmGetNextDatabaseByTypeCreator(true, &state, 'Data', AppType, false,
	&sdbC, &sdbID);
    assert(err==0);
    sdbR = DmOpenDatabase(sdbC, sdbID, dmModeReadWrite);
    // Create two buffer records
    at = 0;
    DmNewRecord(sdbR, &at, 10);
    at = 1;
    DmNewRecord(sdbR, &at, 10);
  }
  assert(sdbR);
  if (sdbR==NULL) {
    return 0;
  }
  assert(mem[idx].sdbHand == 0);
  at = 0;
  mem[idx].sdbHand = DmResizeRecord(sdbR, idx, len);
  if (mem[idx].sdbHand) {
    mem[idx].ptr = MemHandleLock(mem[idx].sdbHand);
  } else {
    mem[idx].ptr = 0;
  }
  return mem[idx].ptr;
}

// Free any allocated storage
static void freeStorage(int i)
{
  // Free database storage
  if (mem[i].ptr) {
    if (mem[i].sdbHand) {
      MemHandleUnlock(mem[i].sdbHand);
      mem[i].sdbHand = NULL;
    } else {
      MemPtrFree(mem[i].ptr);
    }
      mem[i].ptr = NULL;
  }
}

// Free any allocated storage
static void freeStorageAndDB()
{
  img[0].ptr = NULL;
  img[1].ptr = NULL;
  freeStorage(0);
  freeStorage(1);
  // Get rid of the storage database
  if (sdbR) {
    DmCloseDatabase(sdbR);
    DmDeleteDatabase(sdbC, sdbID);
    sdbR = 0;
    sdbC = 0;
  }
}

// Functions to handle image records

static void delete(UInt index) {
  closeRecord();
  if (items_ID[index] == viewerID) {
    // Record is in the ImageViewer database
    FrmCustomAlert(alertID_iv,"Use ImageViewer to delete this","","");
  } else {
    // Record is in its own database
    DmDeleteDatabase(0, items_ID[index]);
  }
}

// open the record specified by the database id and record index
static void *openRecord(LocalID dbID, UInt index) {
  closeRecord();
  dbR = DmOpenDatabase(0, dbID, dmModeReadOnly);
  assert(dbR != 0);
  hand = DmQueryRecord(dbR, index);
  return hand?MemHandleLock(hand):0;
}

// Close the current record and database if any
static void closeRecord(void) {
  if (dbR != NULL) {
    if (hand != NULL) {
      MemHandleUnlock(hand);
    }
    DmCloseDatabase(dbR);
    dbR = NULL;
    hand = NULL;
  }
}

#if 0
int get1bit(unsigned char *data, long scan, long x, long y)
{
	unsigned char byte = data[(x>>3)+y*scan];
	return (byte&(128>>(x&7)))?1:0;
}
int get2bits(unsigned char *data, long scan, long x, long y)
{
	unsigned char byte = data[(x>>2)+y*scan];
	return (byte>>(6-(x&3)*2))&0x03;
}
#else
#define get1bit(data, scan, x, y) (((data)[((x)>>3)+(y)*(scan)]&(128>>((x)&7)))?1:0)
#define get2bits(data, scan, x, y) (((data)[((x)>>2)+(y)*(scan)]>>(6-(((x)&3)*2)))&0x03)
#endif

// Make a zoomed image
static int makezoom()
{
  VoidPtr recordP;
  long len, w, h, map_w;
  long orig_w_8 = img[0].width/8;
  long orig_w_4 = img[0].width/4;
  setgray(0, oldSSA, 160, false);
  msg("Allocating memory");
  img[1].gray = 1;
  // We shrink the existing image down by a factor of 2 to w by h.
  w = (img[0].width/2);
  h = (img[0].height/2);
  // We add a 40-pixel border around it.
  map_w = (w+80)&~7;
  img[1].width = map_w;
  img[1].height = (h+80)&~7;
  // We're using 4 pixels/byte grayscale.
  len = (long)img[1].width*(long)img[1].height/4;
  recordP = makeStorage(len, 1, true);
  msg("");
  if (!recordP) {
    FrmCustomAlert(alertID_iv,"Not enough memory for zoom","","");
    return 0;
  }
  msg("Zooming out");
  img[1].ptr = recordP;
  DmSet(recordP, 0, len, 0);
  if (img[0].gray==0) {
    // Zoom out of a b/w image
    long i,j,t;
    for (j=0;j<h;j++) {
      MemSet(buf, w/4, 0);
      for (i=0;i<w;i++) {
	t = 0;
	// Get 4 original pixels
	t += get1bit(img[0].ptr, orig_w_8, 2*i, 2*j);
	t += get1bit(img[0].ptr, orig_w_8, 2*i, 2*j+1);
	t += get1bit(img[0].ptr, orig_w_8, 2*i+1, 2*j);
	t += get1bit(img[0].ptr, orig_w_8, 2*i+1, 2*j+1);
	assert(t>=0 && t<=4);
	if (t>3) {
	  t=3;
	}
	buf[i>>2] |= (t<<((3-(i&3))*2));
      }
      DmWrite(recordP, ((j+40)*map_w+40)/4,  buf, w/4);
    }
  } else {
    // Zoom out of a grayscale
    long i,j,t,p;
    for (j=0;j<h;j++) {
      MemSet(buf, w/4, 0);
      t=0;
      for (i=0;i<w;i++) {
	// Get 4 original pixels
	t += get2bits(img[0].ptr, orig_w_4, 2*i, 2*j);
	t += get2bits(img[0].ptr, orig_w_4, 2*i, 2*j+1);
	t += get2bits(img[0].ptr, orig_w_4, 2*i+1, 2*j);
	t += get2bits(img[0].ptr, orig_w_4, 2*i+1, 2*j+1);
	p = t>>2;
	t = t&3; // Keep for dithering
	buf[i>>2] |= (p<<((3-(i&3))*2));
      }
      DmWrite(recordP, ((j+40)*map_w+40)/4,  buf, w/4);
    }
  }
  msg("");
  return 1;
}

// Uncompress a RLE compressed image.
// byte > 0x80: use byte-0x80+1 copies of the next byte
// byte <=0x80: use the next byte+1 bytes literally
static void uncompress(unsigned char **inptrp, long len,
    unsigned char **outptrp)
{
  unsigned char *inptr = *inptrp;
  unsigned char *outptr = *outptrp;
  while (1) {
    if (inptr[0]>=0x80) {
      len -= (inptr[0]-0x80+1);
      if (len < 0) break;
      MemSet(outptr, inptr[0]-0x80+1, inptr[1]);
      outptr += inptr[0]-0x80+1;
      inptr += 2;
    } else {
      len -= (inptr[0]+1);
      if (len < 0) break;
      MemMove(outptr, inptr+1, inptr[0]+1);
      outptr += inptr[0]+1;
      inptr += 1+inptr[0]+1;
    }
  }
  *inptrp = inptr;
  *outptrp = outptr;
}


// Uncompress a RLE compressed image into a database
// byte > 0x80: use byte-0x80+1 copies of the next byte
// byte <=0x80: use the next byte+1 bytes literally
static void uncompressdb(unsigned char **inptrp, long len,
    unsigned char **outptrp)
{
  int inlen = len;
  unsigned char *outstart = *outptrp;
  unsigned char *bufptr;
  while (len>0) {
    int done;
    bufptr = buf;
    uncompress(inptrp, len<BUFLEN?len:BUFLEN, &bufptr);
    done = bufptr - buf;
    if (done==0) {
      break;
    }
    assert(done>0);
    DmWrite(outstart, (*outptrp)-outstart, buf, done);
    len -= done;
    (*outptrp) += done;
  }
}

// Load the image from the database
// We either enter this with in_frame = 0 for a new image, or
// animated set if we're displaying a new frame.
static void loadImage(int idx, int in_frame)
{
  struct datahdr *hdr;
retry:
  frame = in_frame;
  hdr = (struct datahdr *)openRecord(items_ID[idx], items_rec[idx]+in_frame);
  if (hdr==0) {
    if (in_frame>0 && animated) {
      // End of animation; loop back to start
      in_frame = 0;
      goto retry;
    } else {
      resetDisplayAndStorage();
      FrmCustomAlert(alertID_iv,"Couldn't open","","");
    }
    return;
  }
  // Load into image 0
  mapNum = 0;
  img[0].width = hdr->width;
  img[0].height = hdr->height;

  if (hdr->type==(char)0xff) {
    img[0].gray = 0;
  } else {
    img[0].gray = 1;
  }

  if (items_anim[idx]) {
    animated = 1;
  } else {
    animated = 0;
  }

  if ((hdr->version&1)==0) {
    // Image is stored uncompressed in the database.
    img[0].ptr = (char *)(hdr+1);
  } else {
    // We must uncompress the database
    long size = ((long)hdr->width*(long)hdr->height)>>(img[0].gray?2:3);
    unsigned char *inptr = (unsigned char *)(hdr+1);
    unsigned char *outptr;
    msg("Allocating memory");
    outptr = makeStorage(size, next_anim_buffer, false);
    if (outptr == NULL) {
      resetDisplayAndStorage();
      if (size > 65535) {
	FrmCustomAlert(alertID_iv,"Uncompressed image > 64K","","");
      } else {
	FrmCustomAlert(alertID_iv,"Not enough memory to uncompress","","");
      }
      return;
    }
    img[0].ptr = outptr;
    if (mem[next_anim_buffer].sdbHand == NULL) {
      // In-memory decompression
      msg("Uncompressing");
      uncompress(&inptr, size, &outptr);
    } else {
      // In-database decompression
      msg("Uncompressing");
      size = ((long)hdr->width*(long)hdr->height)>>(img[0].gray?2:3);
      inptr = (unsigned char *)(hdr+1);
      uncompressdb(&inptr, size, &outptr);
    }

    if (outptr-img[0].ptr != size) {
      resetDisplay();
      FrmCustomAlert(alertID_iv,"Bad compression","","");
      // Try displaying it anyways
    }
  }

  xOffset = 0;
  yOffset = 0;
  setgray(img[0].gray, img[0].ptr, img[0].width, true);
  //adjSSA(img[0].gray, img[0].ptr, img[0].width, xOffset, yOffset);
  graphics = true;

  if (animated) {
    short ms;
    // Free previous memoy, if any
    next_anim_buffer = 1-next_anim_buffer;
    freeStorage(next_anim_buffer);

    // Compute time to wakeup and display next frame
    ms = *(short *)&hdr->reserved;
    if (ms == 0) {
      wakeup = -1;
    } else {
      wakeup = TimGetTicks() + ms*sysTicksPerSecond/1000;
    }
  }
}

// Look up the images in the databases
static void getImageList()
{
  DmSearchStateType state;
  Boolean newSearch;
  UInt idx;
  UInt cardNo;
  LocalID dbID;
  Err err;
  DmOpenRef ref;
  VoidHand hand;
  char *p;
  int i;
  LocalID id;
  ListPtr listp;
  VoidHand resH;
  char *ptr;

  for (i=0;i<nitems;i++) {
    MemPtrFree(items[i]);
  }
  nitems = 0;

  // Check for images stored as vIMG
  newSearch = 1;
  for (nitems=0;nitems<MAXDB;nitems++) {
    err = DmGetNextDatabaseByTypeCreator(newSearch, &state, 'vIMG',
      NULL, false, &cardNo, &dbID);
    if (err == dmErrCantFind) {
      break;
    }
    newSearch = 0;
    err = DmDatabaseInfo(cardNo, dbID, linebuf, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL);
    ptr = MemPtrNew(StrLen(linebuf)+1);
    MemMove(ptr, linebuf, StrLen(linebuf)+1);
    items_ID[nitems] = dbID;
    items_rec[nitems] = 0;
    items[nitems] = ptr;
    items_anim[nitems] = false;
  }

  // Check for images stored as vANI
  newSearch = 1;
  for (;nitems<MAXDB;nitems++) {
    err = DmGetNextDatabaseByTypeCreator(newSearch, &state, 'vANI',
      NULL, false, &cardNo, &dbID);
    if (err == dmErrCantFind) {
      break;
    }
    newSearch = 0;
    err = DmDatabaseInfo(cardNo, dbID, linebuf, NULL, NULL, NULL, NULL, NULL,
	NULL, NULL, NULL, NULL, NULL);
    ptr = MemPtrNew(StrLen(linebuf)+1+5);
    MemMove(ptr, linebuf, StrLen(linebuf)+1);
    StrCat(ptr, "-anim");
    items_ID[nitems] = dbID;
    items_rec[nitems] = 0;
    items[nitems] = ptr;
    items_anim[nitems] = true;
  }

  // Check for images that ImageViewer has moved to vIDB
  newSearch = 1;
  err = DmGetNextDatabaseByTypeCreator(newSearch, &state, 'vIDB',
    NULL, false, &cardNo, &dbID);
  if (err == 0) {
    i = 0;
    viewerID = dbID;
    dbR = DmOpenDatabase(0, dbID, dmModeReadOnly);
    assert(dbR != 0);
    for (i=0;i<DmNumRecords(dbR) && nitems<MAXDB; i++, nitems++) {
      char *p;
      hand = DmQueryRecord(dbR, i);
      assert(hand != 0);
      p = MemHandleLock(hand);
      items_ID[nitems] = dbID;
      items_rec[nitems] = i;
      ptr = MemPtrNew(StrLen(p)+1);
      MemMove(ptr, p, StrLen(p)+1);
      items[nitems] = ptr;
      items_anim[nitems] = false;
      MemHandleUnlock(hand);
    }
    DmCloseDatabase(dbR);
    hand = NULL;
    dbR = NULL;
  }

  // Display the list
  listp = (ListPtr) getObjectPtr(listID_data);
  LstSetListChoices(listp, items, nitems);
  LstSetHeight(listp, nitems>8?8:nitems);
}

static void resetDisplay() {
  setgray(0, oldSSA, 160, false);
  msg("");
  graphics = false;
}

// Return to normal display and free up the storage
static void resetDisplayAndStorage() {
  resetDisplay();
  freeStorageAndDB();
}

// Display functions
// These are based on mapview by Ian Goldberg, <iang@cs.berkeley.edu>

#define pSSA 0xfffffa00
#define VPW ((unsigned char *)(pSSA+0x05))
#define PICF ((unsigned char *)(pSSA+0x20))
#define CKCON ((unsigned char *)(pSSA+0x27))
#define LBAR ((unsigned char *)(pSSA+0x29))
#define POSR ((unsigned char *)(pSSA+0x2d))
#define FRCM ((unsigned char *)(pSSA+0x31))
#define GPMR ((Word *)(pSSA+0x32))

static const void *getSSA() {
    const void * volatile *SSA = (const void**)pSSA;
    return *SSA;
}

/* Set up the display in either grayscale or B/W mode.  vpw is the virtual
   page width _in words_ (word = 16 bits).  This bit derived from code
   in a _PDA Developers_ article by Edward Keyes.
   */
static const void *setgray(int gray, const void *newSSA, unsigned int w,
  Boolean pan)
{
    const void *oldSSA;
    const void * volatile *SSA = (const void**)pSSA;
    static Boolean last_gray = 0;
#define gray0	0
#define gray1	2
#define gray2	3
#define gray3	6

    oldSSA = *SSA;
    *SSA = newSSA;
    if (gray) {
	*VPW = w>>3;
	*PICF |= 0x01;		// Turn on gray scale bit
	*LBAR = 20+(pan?2:0);
	*FRCM = 0xb9;
	*GPMR = gray2 + (gray3<<4) + (gray0<<8) + (gray1<<12);
	*POSR &= 0xf0;		// Panning offset register
    } else {
	*VPW = w>>4;
	*PICF &= 0xfe;
	*LBAR = 10+(pan?1:0);
	*POSR &= 0xf0;
    }
    if (gray != last_gray) {
	// To change the grayscale mode, we have to stop and start the clock.
	// We only do this if necessary, to avoid flicker.
        *CKCON &= 0x7f;
        SysTaskDelay(2);
        *CKCON |= 0x80;
	last_gray = gray;
    }
    return oldSSA;
}

/* Adjust the SSA and POSR so that the image is offset by (xoff,yoff) _pixels_.
   Width is in pixels.  */
static void adjSSA(Boolean gray, const unsigned char *base, int width,
  long xoff, long yoff)
{
    const unsigned char * volatile *SSA = (const unsigned char **)pSSA;

    if (gray) {
      *POSR = ((*POSR) & 0xf0) + (xoff&0x07);
      *SSA = base + (xoff>>2) + (width>>2)*yoff;
    } else {
      *POSR = ((*POSR) & 0xf0) + (xoff&0x0f);
      *SSA = base + (xoff>>3) +(width>>3)*yoff;
    }
}
