/*
 * PalmWac - Main program
 *
 *  $Id: main.c,v 1.15 2001/04/25 15:21:23 ldrolez Exp $ 
 *
 *  Copyright (C) 2000 Ludovic Drolez
 *
 *   This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  
 *
 */

#include <PalmOS.h>

#include "palmwac.h"
#include "main_rsrc.h"

extern UInt16 gSerialRefNum;
extern struct Pref gPref;
extern struct State gState;

Int16   gPrefVersion = 4;

static Err StartApplication (void)
{
   MyPrefLoad ();
   FrmGotoForm (MainForm);

   gState.xyResolution = 1270;
   gState.baud = 9600;
   return (SerialOpen (9600));
}

static void StopApplication (void)
{
   MyPrefSave ();
   SerialClose ();
}

/* 
 * returns field that has the focus, if any, including in embedded tables
 */
static FieldPtr GetFocusObjectPtr (void)
{
   FormPtr frm;
   UInt16  focus;
   FormObjectKind objType;

   frm = FrmGetActiveForm ();
   focus = FrmGetFocus (frm);
   if (focus == noFocus)
      return (NULL);

   objType = FrmGetObjectType (frm, focus);

   if (objType == frmFieldObj)
      return (FrmGetObjectPtr (frm, focus));

   else if (objType == frmTableObj)
      return (TblGetCurrentField (FrmGetObjectPtr (frm, focus)));

   return NULL;
}

/*
 * returns a pointer to an object
 */
static void *GetObjectPtr (UInt16 oId)
{
   FormPtr frm = FrmGetActiveForm ();
   return (FrmGetObjectPtr (frm, FrmGetObjectIndex (frm, oId)));
}

/*
 * set the value of the given object ID
 */
static void SetObjectValue (UInt16 oId, Int16 val)
{
   ControlPtr ctl = GetObjectPtr (oId);
   CtlSetValue (ctl, val);
}

/*
 * get the value of the given object ID
 */
static Int16 GetObjectValue (UInt16 oId)
{
   ControlPtr ctl = GetObjectPtr (oId);
   return CtlGetValue (ctl);
}

/*
 * Save application preferences (gPref global var)
 */
void    MyPrefSave (void)
{
   PrefSetAppPreferences ('PWac', 0, gPrefVersion, &gPref, sizeof (gPref),
			  false);
}

/*
 * Load application preferences (to gPref global var)
 * and set default if not found
 */
void    MyPrefLoad (void)
{
   Int16   st, size = sizeof (gPref);

   st = PrefGetAppPreferences ('PWac', 0, &gPref, &size, false);
   if (st != gPrefVersion) {
      st = noPreferenceFound;
   }
   if (st == noPreferenceFound) {
      /* no preferences , set defaults */
      gPref.compat = compatX11;
      gPref.relative = 1;
      gPref.sensitivity = 2;
      gPref.acceleration = 2;
      gPref.clickWithTap = 0;
      gPref.debug = 1;
   }
}

/*
 *
 */
static Boolean HandleCommonMenuItems (UInt16 menuID)
{
   FieldPtr fld;

   switch (menuID) {
    case EditUndo:
    case EditCut:
    case EditCopy:
    case EditPaste:
    case EditSelectAll:
      fld = (FieldPtr) GetFocusObjectPtr ();
      if (!fld)
	 return false;
      if (menuID == EditUndo)
	 FldUndo (fld);
      else if (menuID == EditCut)
	 FldCut (fld);
      else if (menuID == EditCopy)
	 FldCopy (fld);
      else if (menuID == EditPaste)
	 FldCopy (fld);
      else if (menuID == EditSelectAll)
	 FldSetSelection (fld, 0, FldGetTextLength (fld));
      return true;

    case EditKeyboard:
      SysKeyboardDialog (kbdDefault);
      return true;

    case EditGrafitti:
      SysGraffitiReferenceDialog (referenceDefault);
      return true;

    case OptionsPref:
      FrmPopupForm (PrefForm);
      return true;

    case OptionsAbout:
      FrmPopupForm (AboutBoxForm);
      return true;

    default:
      return false;
   }
}

/*
 *
 */
Boolean MyFormHandleMenuEvent (UInt16 menuID)
{
   if (HandleCommonMenuItems (menuID))
      return true;
   else
      switch (menuID) {
	 // other items here  
      }
   return false;
}


static Boolean MyFormHandleEvent (EventPtr event)
{
   Boolean handled = false;
   UInt16  x, y, keys;
   static UInt16 oldkeys = -1;

   /* check hard keys */
   keys =
      KeyCurrentState () & (keyBitPageUp | keyBitPageDown | keyBitHard1 |
			    keyBitHard2 | keyBitHard3 | keyBitHard4);
   if ((keys != oldkeys) && (event->eType != penMoveEvent)
       && (event->eType != penDownEvent)) {
      TabletSendXY (0, 0, 0, 1, keys);
   }
   oldkeys = keys;

   /* check serial buffer */
   TabletProcessSerial ();

   /* process events */
   switch (event->eType) {
    case penMoveEvent:
    case penDownEvent:
    case penUpEvent:
      //case nilEvent:
      x = event->screenX;
      y = event->screenY;
      TabletSendXY (x, y, event->eType, 0, keys);
      handled = true;
      break;
    case ctlSelectEvent:	/* A control button was pressed and released. */
      break;

    case frmOpenEvent:
      FrmDrawForm (FrmGetActiveForm ());
      handled = true;
      break;

    case menuEvent:
      handled = MyFormHandleMenuEvent (event->data.menu.itemID);
      break;
   }

   return handled;
}

/*
 * About dialog
 */
static Boolean MyAboutBoxHandleEvent (EventPtr event)
{
   Boolean handled = false;

   switch (event->eType) {
    case ctlSelectEvent:
      if (event->data.ctlSelect.controlID == AboutBoxFormOk) {
	 FrmReturnToForm (MainForm);
	 return true;
      }
      break;
    case frmOpenEvent:
      FrmDrawForm (FrmGetActiveForm ());
      handled = true;
      break;
   }
   return handled;
}

/*
 * Prefences dialog
 */
static void PrefApply (void)
{
   UInt16  idx;
   FormPtr frm = FrmGetActiveForm ();

   // get the status of the checkbox
   idx = FrmGetControlGroupSelection (frm, 1);
   gPref.compat = FrmGetObjectId (frm, idx) - PrefFormCompat1 + 1;

   // get the sensitivity
   idx = FrmGetControlGroupSelection (frm, 2);
   gPref.sensitivity = FrmGetObjectId (frm, idx) - PrefFormSens1 + 1;

   // get the acceleration
   idx = FrmGetControlGroupSelection (frm, 3);
   gPref.acceleration = FrmGetObjectId (frm, idx) - PrefFormAccel1 + 1;

   // get the click with tap flag
   gPref.clickWithTap = GetObjectValue (PrefFormClick);

   // get the debug flag
   gPref.debug = GetObjectValue (PrefFormDebug);
}

static void PrefUpdate (void)
{
   // set the status of the checkbox
   SetObjectValue (PrefFormCompat1 + gPref.compat - 1, true);
   // set sensitivity
   SetObjectValue (PrefFormSens1 + gPref.sensitivity - 1, true);
   // set acceleration
   SetObjectValue (PrefFormAccel1 + gPref.acceleration - 1, true);
   // set the click with tap flag
   SetObjectValue (PrefFormClick, gPref.clickWithTap);
   // set the debug flag
   SetObjectValue (PrefFormDebug, gPref.debug);
}

static Boolean MyPrefHandleEvent (EventPtr event)
{
   Boolean handled = false;
   //FormPtr frm = FrmGetActiveForm ();

   switch (event->eType) {
    case ctlSelectEvent:
      switch (event->data.ctlSelect.controlID) {
       case PrefFormOk:
	 PrefApply ();
	 FrmReturnToForm (MainForm);
	 return true;
      }
      break;
    case frmOpenEvent:
      FrmDrawForm (FrmGetActiveForm ());
      PrefUpdate ();
      handled = true;
      break;
   }
   return handled;
}

static Boolean ApplicationHandleEvent (EventPtr event)
{
   FormPtr frm;
   UInt16  formId;
   Boolean handled = false;

   if (event->eType == frmLoadEvent) {
      //Load the form resource specified in the event then activate it
      formId = event->data.frmLoad.formID;
      frm = FrmInitForm (formId);
      FrmSetActiveForm (frm);

      // Set the event handler for the form.  The handler of the currently 
      // active form is called by FrmDispatchEvent each time it is called 
      switch (formId) {
       case MainForm:
	 FrmSetEventHandler (frm, MyFormHandleEvent);
	 break;
       case PrefForm:
	 FrmSetEventHandler (frm, MyPrefHandleEvent);
	 break;
       case AboutBoxForm:
	 FrmSetEventHandler (frm, MyAboutBoxHandleEvent);
	 break;
      }
      handled = true;
   }

   return handled;
}

/*
 * Checks that a ROM version meets your minimum requirement
 */

static Err RomVersionCompatible (UInt32 requiredVersion, UInt16 launchFlags) 
{
   UInt32 romVersion;
   
      /* See if we have at least the minimum required version of the ROM or later. */ 
      FtrGet (sysFtrCreator, sysFtrNumROMVersion, &romVersion);
   if (romVersion < requiredVersion)
       {
      if (
	   (launchFlags &
	    (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp)) ==
	   (sysAppLaunchFlagNewGlobals | sysAppLaunchFlagUIApp))
	  {
	 FrmAlert (RomIncompatibleAlert);
	 /* Pilot 1.0 will continuously relaunch this app unless we switch to 
	  * another safe one. */ 
	    if (romVersion < 0x02000000)
	    AppLaunchWithCommand (sysFileCDefaultApp,
				   sysAppLaunchCmdNormalLaunch, NULL);
	 }
      return (sysErrRomIncompatible);
      }
   return (0);
}

static void EventLoop (void)
{
   EventType event;
   UInt16  error;

   do {
      EvtGetEvent (&event, sysTicksPerSecond / 10);
      // Intercept hard keys to prevent them from switching apps
      if (event.eType == keyDownEvent) {
	 // Consume events notifying us of key presses.
	 // but do nothing if the device is being powered on
	 if (event.data.keyDown.chr >= hard1Chr &&
	     event.data.keyDown.chr <= hard4Chr &&
	     !(event.data.keyDown.modifiers & poweredOnKeyMask)) {
	    MyFormHandleEvent (&event);
	    continue;
	 }
      }
      if (!SysHandleEvent (&event))
	 if (!MenuHandleEvent (0, &event, &error))
	    if (!ApplicationHandleEvent (&event))
	       FrmDispatchEvent (&event);
   } while (event.eType != appStopEvent);
}


UInt32  PilotMain (UInt16 launchCode, MemPtr cmdPBP, UInt16 launchFlags)
{
   Err     err;

   err = RomVersionCompatible (0x02000000, launchFlags);
   if (err)
      return err;

   if (launchCode == sysAppLaunchCmdNormalLaunch) {
      if ((err = StartApplication ()) == 0) {
	 EventLoop ();
	 StopApplication ();
      }
   }

   return err;
}
