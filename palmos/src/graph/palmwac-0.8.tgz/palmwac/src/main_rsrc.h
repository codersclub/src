#define MainForm			1000   
#define MainMenuBar			1000

#define RomIncompatibleAlert		1099
// about box
#define AboutBoxForm			2001	
#define AboutBoxFormOk			2002	

// preferences box
#define PrefForm			1901
#define PrefFormOk			1902
#define PrefFormCompat1			1905
#define PrefFormSens1			1910
#define PrefFormAccel1			1920
#define PrefFormClick			1930
#define PrefFormHelp			1940
#define PrefFormDebug			1950

// common menu items
#define EditBase                        2301
#define EditUndo                        2301
#define EditCut                         2302
#define EditCopy                        2303
#define EditPaste                       2304
#define EditSelectAll                   2305
// separator
#define EditKeyboard                    2307
#define EditGrafitti                    2308  

#define OptionsBase                     2101
#define OptionsPref                 	2101
#define OptionsAbout                 	2102
