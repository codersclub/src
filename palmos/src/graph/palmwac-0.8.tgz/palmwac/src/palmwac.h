/*
 * PalmWac includes
 *
 * $Id: palmwac.h,v 1.8 2001/04/25 15:21:23 ldrolez Exp $
 *
 */

#include <Unix/sys_types.h>
#include <Core/System/SerialMgrOld.h>
#include <Control.h>

typedef enum { compatX11=1, compatGpm, compatWin } Compat;

struct Pref {
  Compat compat;		/* compatibility mode */
  Int16 relative;		/* relative mode */
  Int16 sensitivity;		/*  */
  Int16 acceleration;		/*  */
  Int16 clickWithTap;		/*  */
  Int16 debug;			/* debug mode 0/1 */
};

struct State {
  UInt16 x;			/* x coord */
  UInt16 y;			/* y coord */
  UInt16 button;		/* tablet buttons state */
  UInt16 palmkey;		/* palm hard keys state */
  UInt32 baud;			/* tablet baudrate */
  UInt16 xyResolution;		/* x and y tablet resolution */    
};

Err SerialOpen(UInt32 baud);
void SerialClose(void);

void MyPrefSave (void);
void MyPrefLoad (void);

void TabletProcessSerial(void);
Err TabletSend (UInt16 x, UInt16 y, UInt16 buttons);
Err TabletSendXY(Int16 x, Int16 y, eventsEnum etype, UInt16 keyonly, UInt16 keys);

