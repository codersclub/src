/*
 * Generic serial functions and emulation of Wac*m protocol
 *
 *  $Id: serial.c,v 1.16 2001/04/25 15:21:23 ldrolez Exp $ 
 *
 *  Copyright (C) 2000 Ludovic Drolez
 *
 *   This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  
 *
 */

#include <PalmOS.h>

#include "palmwac.h"

UInt16  gSerialRefNum;
/* Not needed: the default is 512 bytes.
 * UInt8   gSerialBuffer[128 + 32]; */

struct Pref gPref;
struct State gState;

/*
 * Initialise the serial port (v2 api)
 */
Err     SerialOpen (UInt32 baud)
{
   Err     err;
   SerSettingsPtr set;

   err = SysLibFind ("Serial Library", &gSerialRefNum);
   ErrNonFatalDisplayIf (err != 0, "Can't find serial library");

   err = SerOpen (gSerialRefNum, 0, baud);
   if (err != 0) {
      if (err == serErrAlreadyOpen) {
	 //FrmAlert(SerialInUseAlert);
	 SerClose (gSerialRefNum);
      }
      else
	 //FrmAlert(CantopenserialAlert);
	 return true;
   }
   //set->flags = serSettingsFlagStopBits1 | serSettingsFlagBitsPerChar8;
   //SerSetSettings(gSerialRefNum, set); 
   //SerGetSettings(gSerialRefNum, set);
   //set->flags |= serSettingsFlagCTSAutoM;    
   //SerSetSettings(gSerialRefNum, set);

   // do we really need that ?
   // err = SerSetReceiveBuffer (gSerialRefNum, gSerialBuffer,
   //			      sizeof (gSerialBuffer));
   return err;
}

void    SerialClose (void)
{
   // restore the default buffer before closing the serial port
   //SerSetReceiveBuffer (gSerialRefNum, gSerialBuffer, 0);
   SerClose (gSerialRefNum);
}


/*
 * Simple debug function with scrolling
 */
void    Debug (char *msg)
{
   RectangleType rect;
   Int16   text_top = 20;
   Int16   text_lines = 12;
   Int16   text_height = FntLineHeight () * text_lines;

   WinHandle draw_win = WinGetDrawWindow ();

   /* scroll text up */
   rect.topLeft.x = 0;
   rect.topLeft.y = text_top + FntLineHeight ();
   rect.extent.x = 160;
   rect.extent.y = text_height - FntLineHeight ();
   WinCopyRectangle (draw_win, draw_win, &rect, 0, text_top, winPaint);

   /* clear new text area */
   rect.topLeft.x = 0;
   rect.topLeft.y = text_top + text_height - FntLineHeight ();
   rect.extent.x = 160;
   rect.extent.y = FntLineHeight ();
   WinEraseRectangle (&rect, 0);

   /* draw string */
   WinDrawChars (msg, StrLen (msg), 0,
		 text_top + text_height - FntLineHeight ());
}

/*
 * Process serial data sent to the tablet
 */
void    TabletProcessSerial (void)
{
   UInt16  status;
   UInt32  num = 0;
   Err     err;

   char    tmp[128], chr;
   char   *serial = "~#UD1212 V1.2-0\r";
   char   *settings = "~RE203C000,000,03,%d,%d\r";
   char   *maxcoord = "~C4000,4000\r";
   char   *diag = "UD-1212-R00 V1.2-0 01/01/01 by PWAC\rI AM FINE\r";

   static UInt16 curlen = 0;
   static char buf[128];

   status = SerReceiveCheck (gSerialRefNum, &num);
   if (status == serErrLineErr) {
      SerReceiveFlush (gSerialRefNum, 0);
      Debug ("serial error");
   }
   while (num > 0) {
      /* read only one byte */
      num = SerReceive (gSerialRefNum, &chr, 1, -1, &err);
      if (num == 0)
	 break;
      if ((chr == '@' || chr == '#' || chr == '$') && curlen == 0) {
	 switch (chr) {
	  case '@':		/* request one coord (windows drivcers seems to use polling) */
	    TabletSend (gState.x, gState.y, gState.palmkey);
	    break;
	  default:		/* reset the device */
	    StrPrintF (tmp, "Reset: %c", chr);
	    Debug (tmp);
	    if (gState.baud != 9600) {
	       Debug ("SSpeed: 9600 bauds");
	       SerialClose ();
	       SerialOpen (9600);
	       gState.baud = 9600;
	    }
	    break;
	 }
      }
      else if (chr == '\r') {
	 if (curlen > 0) {
	    buf[curlen] = 0;
	    /* process a command string */
	    StrPrintF (tmp, "Comm: %d %d %s", (UInt16) curlen, err, buf);
	    Debug (tmp);
	    switch (buf[0]) {
	     case '~':
	       {
		  switch (buf[1]) {
		   case '#':
		     /* rom version */
		     SerSend (gSerialRefNum, serial, StrLen (serial), &err);
		     /* hack for Win drivers */
		     if (buf[2] == 'T') {
			SerSend (gSerialRefNum, diag, StrLen (diag), &err);
		     }
		     break;
		   case 'R':
		     /* read tablet settings from ram */
		     StrPrintF (tmp, settings, gState.xyResolution,
				gState.xyResolution);
		     SerSend (gSerialRefNum, tmp, StrLen (tmp), &err);
		     break;
		   case 'C':
		     /* read tablet max coords. */
		     SerSend (gSerialRefNum, maxcoord,
			      StrLen (maxcoord), &err);
		     break;
		   case '*':
		     /* quick hack: just switch to 19200 bauds */
		     if (gState.baud != 19200) {
			Debug ("SSpeed: 19200 bauds");
			SerialClose ();
			SerialOpen (19200);
			gState.baud = 19200;
		     }
		     break;
		  }
	       }
	     case 'T':
	       {
		  switch (buf[1]) {
		   case 'E':
		     /* diagnostics */
		     SerSend (gSerialRefNum, diag, StrLen (diag), &err);
		     break;
		  }
	       }
	     case 'N':
	       {
		  switch (buf[1]) {
		   case 'R':
		     /* set resolution */
		     gState.xyResolution = (UInt16) StrAToI (&buf[2]);
		     break;
		  }
	       }
	    }
	    /* end processing */
	    curlen = 0;
	 }
      }
      else {
	 /* */
	 buf[curlen] = chr;
	 curlen++;
      }
      status = SerReceiveCheck (gSerialRefNum, &num);
      if (status == serErrLineErr) {
	 SerReceiveFlush (gSerialRefNum, 0);
	 Debug ("Serial error");
      }
   }
}

/*
 * Send a tablet binary packet. 
 * Take absolute coordinates and translate standard PalmOS key status to wacom 
 * button hits and pressure information.
 */

Err     TabletSend (UInt16 x, UInt16 y, UInt16 buttons)
{
   Err     err;
   UInt8   data[10];
   char    tmp[80];
   UInt16  datalen, buttonpressed = 0, wacbutton = 0, pressure = 64;

   /* static mapping for now */
   if (buttons & (keyBitHard1 | keyBitHard2 | keyBitHard3 | keyBitHard4)) {
      buttonpressed = 1;
      if (buttons & keyBitHard1)
	 wacbutton = 1;
      else if (buttons & keyBitHard2)
	 wacbutton = 2;
      else if (buttons & keyBitHard3)
	 wacbutton = 4;
      else
	 wacbutton = 8;
   }
   if (buttons & keyBitPageUp)
      pressure = 0;
   if (buttons & keyBitPageDown)
      pressure = 60;

   /* used only 14 bits for x & y */
   data[0] = 0xE0 | (buttonpressed << 3) | (x >> 14);
   data[1] = (x >> 7) & 0x7F;
   data[2] = (x & 0x7F);
   data[3] = (wacbutton & 0xF) << 3 | (y >> 14);
   data[4] = (y >> 7) & 0x7F;
   data[5] = (y & 0x7F);
   data[6] = pressure;
   data[7] = 0;
   data[8] = 0;
   datalen = 7;
   if (gPref.compat == compatGpm) {
      /* tested with gpm 1.18.1 : 8 bytes of data !! bug ? */
      datalen = 8;
      data[0] |= 8;
   }
   if (0) {
      /* v1.4+ tilt information */
      datalen = 9;
   }

   if (gPref.debug) {   
      StrPrintF (tmp, "%d %d pr:%d key:%d ", x, y, pressure, wacbutton);
      Debug (tmp);
   }
   SerSend (gSerialRefNum, data, datalen, &err);

   /* save state */
   gState.x = x;
   gState.y = y;
   gState.palmkey = buttons;
   gState.button = wacbutton;

   return err;
}

/*
 * Take raw PalmOS events and preprocess them before sending a packet
 */
Err
TabletSendXY (Int16 x, Int16 y, eventsEnum etype, UInt16 keyonly, UInt16 keys)
{
   Err     err;
   Int16   dx, dy, ax, ay, xu, yu;
   static Int16 ox = -1, oy = 0, tapx = 0, tapy = 0;
   static Int16 virx = 2000, viry = 2000;
   static UInt32 lastPenDown = -1;
   char    tmp[80];

   xu = x;
   yu = y;
   if (!keyonly) {
      /* not a key only event */
      dx = x - ox;
      dy = y - oy;
      /* sensitivity */
      dx *= gPref.sensitivity;
      dy *= gPref.sensitivity;
      if (gPref.compat == compatGpm) {
	 dx *= 2;
	 dy *= 2;
      }
      else if (gPref.compat == compatWin) {
	 dx *= 10;
	 dy *= 10;
      }
      if (gPref.acceleration > 1) {
	 ax = abs ((x - ox) * (gPref.acceleration - 1));
	 ay = abs ((y - oy) * (gPref.acceleration - 1));
	 if (ax > 16)
	    dx = (dx * ax) / 16;
	 if (ay > 16)
	    dy = (dy * ay) / 16;
      }
      if (etype == penDownEvent) {
	 dx = dy = 0;
	 tapx = xu;
	 tapy = yu;
	 lastPenDown = TimGetTicks();
      }
      ox = x;
      oy = y;

      virx += dx;
      viry += dy;

      /* click with single-tap support */
      if (etype == penUpEvent) {
	 if (gPref.clickWithTap) {
	    if ((tapx == xu) && (tapy == yu)) {
	       if ( TimGetTicks() -  lastPenDown < sysTicksPerSecond / 5 ) {
	           //Debug ("click !");
	           switch (gPref.compat) {
		    case compatX11:	/* XFree */
		      TabletSend (virx, viry, keyBitHard1);
		      TabletSend (virx, viry, 0);
		      break;
		    case compatGpm:	/* gpm */
		      break;
		    case compatWin:	/* Win */
		      TabletSend (virx, viry, keyBitPageUp);
		      TabletSend (virx, viry, 0);
		      break;
	           }
	       }
	    }
	 }
      }
   }

   /* check that coords are not negtive */
   if (virx < 0) {
      virx = 0;
   }
   if (viry < 0) {
      viry = 0;
   }

   err = TabletSend (virx, viry, keys);
   return err;
}
