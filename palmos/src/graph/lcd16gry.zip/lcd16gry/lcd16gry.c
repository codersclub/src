#pragma pack(2)
#include <Common.h>
#include <System/SysAll.h>
#include <UI/UIAll.h>
#include <SerialMgr.h>
#include <System/SysEvtMgr.h>

#define PrefSetAppPreferences PrefSetAppPreferencesV10
#define PrefGetAppPreferences PrefGetAppPreferencesV10

Byte *LPICF = (Byte *) 0xFFFFFA20;
Byte *LVPW = (Byte *) 0xFFFFFA05;
ULong *LSSA = (ULong *) 0xFFFFFA00;

char *screen;

int penval = 0;

setdot(int x, int y, int grey)
{
  int addr, i, j;

  if (y > 11) {
    y--, x--;
    for (i = 0; i < 3; i++)
      for (j = 0; j < 3; j++) {

        addr = (y + i) * 80 + (x + j >> 1);
        if (x + j & 1) {
          screen[addr] &= 0xf0;
          screen[addr] |= penval;

        } else {
          screen[addr] &= 0xf;
          screen[addr] |= penval << 4;
        }
      }
  } else
    penval = x / 10 & 15;

}

DWord PilotMain(Word cmd, Ptr cmdPBP, Word launchFlags)
{
  EventType e;
  Err error;

  if (cmd == sysAppLaunchCmdNormalLaunch) {

    char *loc = *LSSA;

    int x, reclen;

    screen = MemPtrNew(12800 + 800);
    MemSet(screen, 12800, 0);

    PrefGetAppPreferences('Grey', 0, screen, 12800);

    *LPICF |= 0x02;
    *LVPW <<= 2;
    *LSSA = screen;

    for (reclen = 0; reclen < 800; reclen++) {
      x = reclen / 5 & 15;
      screen[reclen] = x | (x << 4);
    }

    do {

      EvtGetEvent(&e, evtWaitForever);

      if (SysHandleEvent(&e))
        continue;
#if 0
      if (MenuHandleEvent(NULL, &e, &error))
        continue;
#endif
      switch (e.eType) {

      case keyDownEvent:
        switch (e.data.keyDown.chr) {
        case pageDownChr:
          penval++;
          penval &= 15;
          break;
        case pageUpChr:
          penval--;
          penval &= 15;
          break;
        default:
          break;
        }
        break;

      case penDownEvent:
      case penMoveEvent:
        setdot(e.screenX, e.screenY, penval);
        break;

      default:
        break;

      }
    } while (e.eType != appStopEvent);


    *LSSA = loc;

    *LVPW >>= 2;
    *LPICF &= 0xFC;

    PrefSetAppPreferences('Grey', 0, screen, 12800);

    reclen = 0;

  }
  return 0;

}
