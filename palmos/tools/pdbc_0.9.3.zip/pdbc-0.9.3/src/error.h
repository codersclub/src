//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: error.h 1.2 2001/10/16 21:19:59 obermuhl Exp obermuhl $
//
// $Log: error.h $
// Revision 1.2  2001/10/16 21:19:59  obermuhl
// added new print_*() functions
//
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef error_h
#define error_h

//---------------------------------------------------------------------

void error(char *msg, ...);
void warning(char *msg, ...);
void message(int level, char *msg, ...);

void set_verbose_level(char level);
void set_warning_level(char level);
void set_warning_as_errors(int flag);

int get_verbose_level();

void set_printout(FILE *f);

void print_reset();
void print_str(char *str);
void print_text(char *msg, ...);
void print_line(char *msg, ...);
void print_newline();
void print_fill(int pos);

char* parse_option(int argc, char *argv[], int *index, 
		   char opt_char, char *opt_str, int opt_args);

//---------------------------------------------------------------------

#endif

