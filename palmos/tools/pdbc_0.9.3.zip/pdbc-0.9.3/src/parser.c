
/*  A Bison parser, made from parser.y
 by  GNU Bison version 1.25
  */

#define YYBISON 1  /* Identify Bison output.  */

#define	TOK_FNORD	258
#define	TOK_FILE	259
#define	TOK_APPINFO	260
#define	TOK_SORTINFO	261
#define	TOK_RECORD	262
#define	TOK_BEGIN	263
#define	TOK_END	264
#define	TOK_USER_ERROR	265
#define	TOK_USER_WARNING	266
#define	TOK_USER_MESSAGE	267
#define	TOK_FILENAME	268
#define	TOK_ATTRIB	269
#define	TOK_VERSION	270
#define	TOK_CREATION_DATE	271
#define	TOK_MODIFICATION_DATE	272
#define	TOK_BACKUP_DATE	273
#define	TOK_MODIFICATION	274
#define	TOK_TYPEID	275
#define	TOK_CREATORID	276
#define	TOK_UNIQUEID_SEED	277
#define	TOK_RESOURCE	278
#define	TOK_READONLY	279
#define	TOK_DIRTY	280
#define	TOK_BACKUP	281
#define	TOK_NEWER	282
#define	TOK_RESET	283
#define	TOK_NOBEAM	284
#define	TOK_STREAM	285
#define	TOK_HIDDEN	286
#define	TOK_NOW	287
#define	TOK_TODAY	288
#define	TOK_RECORDID	289
#define	TOK_ID	290
#define	TOK_SECRET	291
#define	TOK_BUSY	292
#define	TOK_DELETE	293
#define	TOK_CATEGORY	294
#define	TOK_BIN	295
#define	TOK_OCT	296
#define	TOK_DEC	297
#define	TOK_HEX	298
#define	TOK_BASE	299
#define	TOK_BYTE	300
#define	TOK_WORD	301
#define	TOK_LONG	302
#define	TOK_SIZE	303
#define	TOK_PADSTRING	304
#define	TOK_PADCHAR	305
#define	TOK_DOUBLE	306
#define	TOK_FLOAT	307
#define	TOK_SIGNED	308
#define	TOK_UNSIGNED	309
#define	TOK_OP_EQUAL	310
#define	TOK_OP_UNEQUAL	311
#define	TOK_OP_LT	312
#define	TOK_OP_LE	313
#define	TOK_OP_GT	314
#define	TOK_OP_GE	315
#define	TOK_OP_SHL	316
#define	TOK_OP_SHR	317
#define	TOK_MAYBE_HEXNUMBER	318
#define	TOK_REALNUMBER	319
#define	TOK_DOUBLENUMBER	320
#define	TOK_FLOATNUMBER	321
#define	TOK_BINNUMBER	322
#define	TOK_OCTNUMBER	323
#define	TOK_DECNUMBER	324
#define	TOK_HEXNUMBER	325
#define	TOK_STRING	326
#define	TOK_CHAR	327
#define	TOK_DATE	328

#line 1 "parser.y"


//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: parser.y 1.5 2001/11/21 22:22:38 obermuhl Exp $
//
// $Log: parser.y $
// Revision 1.5  2001/11/21 22:22:38  obermuhl
// resource block uses begin_resource()/end_resource()
// use TOK_ID for resources (with decimal value)
//
// Revision 1.4  2001/11/17 11:26:44  obermuhl
// impl resources
//
// Revision 1.3  2001/11/12 23:00:29  obermuhl
// added resource,stream,hidden (fileheader attributes)
//
// Revision 1.2  2001/11/02 21:31:24  obermuhl
// added keywords 'double' and 'float' to handle default real values
//
// Revision 1.1  2001/09/30 10:58:36  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include "pdbc.h"
#include "error.h"
#include "comperror.h"

#define YYDEBUG 1
//#define YYERROR_VERBOSE

int yylex();
void yyrestart(FILE *input_file);
void yyerror(char *msg);
extern char *yytext;

int get_linenumber();
extern int lineno;


#line 51 "parser.y"
typedef union {
unsigned long lval;
double dval;
float fval;
char *sval;
} YYSTYPE;
#include <stdio.h>

#ifndef __cplusplus
#ifndef __STDC__
#define const
#endif
#endif



#define	YYFINAL		324
#define	YYFLAG		-32768
#define	YYNTBASE	92

#define YYTRANSLATE(x) ((unsigned)(x) <= 328 ? yytranslate[x] : 181)

static const char yytranslate[] = {     0,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    90,     2,     2,     2,    89,    86,     2,    81,
    82,    87,    79,     2,    83,     2,    88,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,    80,    74,     2,
    75,     2,    84,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,    85,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,    76,    78,    77,    91,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
     2,     2,     2,     2,     2,     1,     2,     3,     4,     5,
     6,     7,     8,     9,    10,    11,    12,    13,    14,    15,
    16,    17,    18,    19,    20,    21,    22,    23,    24,    25,
    26,    27,    28,    29,    30,    31,    32,    33,    34,    35,
    36,    37,    38,    39,    40,    41,    42,    43,    44,    45,
    46,    47,    48,    49,    50,    51,    52,    53,    54,    55,
    56,    57,    58,    59,    60,    61,    62,    63,    64,    65,
    66,    67,    68,    69,    70,    71,    72,    73
};

#if YYDEBUG != 0
static const short yyprhs[] = {     0,
     0,     2,     3,     4,     5,    15,    17,    20,    21,    22,
    28,    29,    35,    36,    42,    43,    49,    50,    56,    57,
    63,    64,    70,    71,    77,    78,    84,    85,    91,    93,
    95,    97,    99,   101,   108,   110,   112,   113,   117,   121,
   123,   125,   127,   129,   131,   133,   135,   137,   139,   141,
   143,   145,   147,   149,   152,   154,   156,   162,   165,   166,
   168,   170,   172,   174,   175,   180,   181,   186,   187,   193,
   194,   200,   203,   204,   205,   211,   212,   218,   220,   222,
   224,   225,   229,   233,   235,   237,   239,   241,   243,   245,
   250,   252,   258,   260,   263,   264,   265,   271,   272,   278,
   280,   282,   284,   289,   291,   292,   297,   300,   301,   303,
   305,   307,   309,   311,   313,   315,   317,   319,   321,   323,
   325,   327,   329,   330,   336,   338,   340,   342,   343,   349,
   350,   356,   357,   363,   365,   367,   369,   372,   375,   377,
   379,   381,   383,   385,   389,   391,   393,   399,   401,   405,
   407,   411,   413,   417,   419,   423,   427,   429,   433,   437,
   441,   445,   447,   451,   455,   457,   461,   465,   467,   471,
   475,   479,   481,   484,   487,   490,   493,   495,   497,   501,
   503,   505,   507,   509,   511,   513,   515,   517,   519,   521,
   523,   525,   527,   529,   531,   533,   535,   537,   539,   541,
   544,   547
};

static const short yyrhs[] = {    93,
     0,     0,     0,     0,     4,    94,    97,     8,    95,   118,
     9,    96,    74,     0,    98,     0,    98,    99,     0,     0,
     0,    13,    75,   110,   100,    74,     0,     0,    14,    75,
   112,   101,    74,     0,     0,    15,    75,   171,   102,    74,
     0,     0,    16,    75,   115,   103,    74,     0,     0,    17,
    75,   115,   104,    74,     0,     0,    18,    75,   115,   105,
    74,     0,     0,    19,    75,   171,   106,    74,     0,     0,
    20,    75,   111,   107,    74,     0,     0,    21,    75,   111,
   108,    74,     0,     0,    22,    75,   171,   109,    74,     0,
    74,     0,   180,     0,    71,     0,    72,     0,   171,     0,
    76,   171,   171,   171,   171,    77,     0,   178,     0,   113,
     0,     0,   113,    78,   114,     0,   113,    79,   114,     0,
   114,     0,   171,     0,    23,     0,    24,     0,    25,     0,
    26,     0,    27,     0,    28,     0,    29,     0,    30,     0,
    31,     0,   171,     0,    32,     0,   116,     0,   116,   117,
     0,    73,     0,    33,     0,   170,    80,   170,    80,   170,
     0,   118,   119,     0,     0,   120,     0,   122,     0,   124,
     0,   126,     0,     0,     5,   121,   141,    74,     0,     0,
     6,   123,   141,    74,     0,     0,     7,   125,   128,   141,
    74,     0,     0,    23,   127,   136,   141,    74,     0,   128,
   129,     0,     0,     0,    14,    75,   132,   130,    74,     0,
     0,    34,    75,   135,   131,    74,     0,    74,     0,   180,
     0,   133,     0,     0,   133,    78,   134,     0,   133,    79,
   134,     0,   134,     0,   171,     0,    36,     0,    37,     0,
    25,     0,    38,     0,    39,    81,   170,    82,     0,   171,
     0,    76,   171,   171,   171,    77,     0,   178,     0,   136,
   137,     0,     0,     0,    20,    75,   111,   138,    74,     0,
     0,    35,    75,   140,   139,    74,     0,    74,     0,   180,
     0,   170,     0,    76,   171,   171,    77,     0,   178,     0,
     0,     8,   142,   143,     9,     0,   143,   144,     0,     0,
   145,     0,   141,     0,   146,     0,   156,     0,   180,     0,
   147,     0,   149,     0,   151,     0,   154,     0,   155,     0,
    40,     0,    41,     0,    42,     0,    43,     0,     0,    44,
    81,   173,   148,    82,     0,    45,     0,    46,     0,    47,
     0,     0,    48,    81,   173,   150,    82,     0,     0,    49,
    81,   173,   152,    82,     0,     0,    50,    81,   173,   153,
    82,     0,    51,     0,    52,     0,   173,     0,    79,   173,
     0,    83,   173,     0,   174,     0,   175,     0,   176,     0,
   177,     0,   178,     0,    81,   157,    82,     0,   158,     0,
   159,     0,   159,    84,   158,    80,   158,     0,   160,     0,
   159,    78,   160,     0,   161,     0,   160,    85,   161,     0,
   162,     0,   161,    86,   162,     0,   163,     0,   162,    55,
   163,     0,   162,    56,   163,     0,   164,     0,   163,    57,
   164,     0,   163,    58,   164,     0,   163,    59,   164,     0,
   163,    60,   164,     0,   165,     0,   164,    61,   165,     0,
   164,    62,   165,     0,   166,     0,   165,    79,   166,     0,
   165,    83,   166,     0,   167,     0,   166,    87,   167,     0,
   166,    88,   167,     0,   166,    89,   167,     0,   168,     0,
    90,   167,     0,    91,   167,     0,    83,   168,     0,    79,
   168,     0,   173,     0,   169,     0,    81,   157,    82,     0,
    63,     0,   172,     0,    63,     0,   172,     0,    67,     0,
    68,     0,    69,     0,    70,     0,    63,     0,    67,     0,
    68,     0,    69,     0,    70,     0,    64,     0,    65,     0,
    66,     0,    71,     0,    72,     0,    71,     0,    72,     0,
    10,   179,     0,    11,   179,     0,    12,   179,     0
};

#endif

#if YYDEBUG != 0
static const short yyrline[] = { 0,
   199,   203,   206,   209,   212,   216,   220,   221,   225,   228,
   228,   231,   231,   234,   234,   239,   239,   244,   244,   249,
   249,   252,   252,   255,   255,   258,   258,   261,   261,   262,
   266,   267,   271,   273,   275,   280,   282,   287,   289,   291,
   296,   298,   300,   302,   304,   306,   308,   310,   312,   314,
   319,   321,   323,   325,   330,   332,   337,   342,   343,   347,
   348,   349,   350,   354,   356,   361,   363,   368,   371,   376,
   379,   384,   385,   389,   392,   392,   395,   395,   396,   400,
   402,   407,   409,   411,   416,   418,   420,   422,   424,   426,
   431,   433,   435,   440,   441,   445,   448,   448,   451,   451,
   452,   456,   458,   460,   465,   468,   473,   474,   478,   479,
   483,   484,   485,   489,   490,   491,   492,   493,   497,   499,
   501,   503,   505,   508,   511,   513,   515,   517,   520,   523,
   526,   526,   529,   532,   537,   542,   544,   546,   548,   556,
   558,   560,   562,   564,   568,   572,   574,   578,   580,   584,
   586,   590,   592,   596,   598,   600,   604,   606,   608,   610,
   612,   616,   618,   620,   624,   626,   628,   632,   634,   636,
   638,   642,   644,   646,   648,   650,   653,   655,   658,   663,
   665,   670,   672,   677,   679,   681,   683,   688,   689,   690,
   691,   692,   696,   700,   704,   708,   712,   716,   717,   721,
   723,   725
};
#endif


#if YYDEBUG != 0 || defined (YYERROR_VERBOSE)

static const char * const yytname[] = {   "$","error","$undefined.","TOK_FNORD",
"TOK_FILE","TOK_APPINFO","TOK_SORTINFO","TOK_RECORD","TOK_BEGIN","TOK_END","TOK_USER_ERROR",
"TOK_USER_WARNING","TOK_USER_MESSAGE","TOK_FILENAME","TOK_ATTRIB","TOK_VERSION",
"TOK_CREATION_DATE","TOK_MODIFICATION_DATE","TOK_BACKUP_DATE","TOK_MODIFICATION",
"TOK_TYPEID","TOK_CREATORID","TOK_UNIQUEID_SEED","TOK_RESOURCE","TOK_READONLY",
"TOK_DIRTY","TOK_BACKUP","TOK_NEWER","TOK_RESET","TOK_NOBEAM","TOK_STREAM","TOK_HIDDEN",
"TOK_NOW","TOK_TODAY","TOK_RECORDID","TOK_ID","TOK_SECRET","TOK_BUSY","TOK_DELETE",
"TOK_CATEGORY","TOK_BIN","TOK_OCT","TOK_DEC","TOK_HEX","TOK_BASE","TOK_BYTE",
"TOK_WORD","TOK_LONG","TOK_SIZE","TOK_PADSTRING","TOK_PADCHAR","TOK_DOUBLE",
"TOK_FLOAT","TOK_SIGNED","TOK_UNSIGNED","TOK_OP_EQUAL","TOK_OP_UNEQUAL","TOK_OP_LT",
"TOK_OP_LE","TOK_OP_GT","TOK_OP_GE","TOK_OP_SHL","TOK_OP_SHR","TOK_MAYBE_HEXNUMBER",
"TOK_REALNUMBER","TOK_DOUBLENUMBER","TOK_FLOATNUMBER","TOK_BINNUMBER","TOK_OCTNUMBER",
"TOK_DECNUMBER","TOK_HEXNUMBER","TOK_STRING","TOK_CHAR","TOK_DATE","';'","'='",
"'{'","'}'","'|'","'+'","':'","'('","')'","'-'","'?'","'^'","'&'","'*'","'/'",
"'%'","'!'","'~'","compilation_unit","file_decl","@1","@2","@3","fileheader_decl",
"seq_fileheader_settings","fileheader_settings","@4","@5","@6","@7","@8","@9",
"@10","@11","@12","@13","filename_literal","id_literal","seq_file_attrib_flag",
"seq_file_attrib_flag1","file_attrib_flag","datetime_value","date_value","time_value",
"seq_chunk_decl","chunk_decl","appinfo_decl","@14","sortinfo_decl","@15","record_decl",
"@16","resource_decl","@17","seq_record_setting","record_setting","@18","@19",
"seq_record_attrib_flag","seq_record_attrib_flag1","record_attrib_flag","record_id",
"seq_resource_setting","resource_setting","@20","@21","resource_id","record_block",
"@22","seq_record_data","record_data","data","data_state_command","data_base_command",
"@23","data_size_command","@24","data_pad_command","@25","@26","data_double_command",
"data_float_command","data_value","expr","condex","orex","xorex","andex","eqex",
"relex","shiftex","arith","term","factor","prim","nested","dec_value","hex_value",
"based_value","long_value","real_value","double_value","float_value","string_value",
"char_value","string_or_char_value","user_message", NULL
};
#endif

static const short yyr1[] = {     0,
    92,    94,    95,    96,    93,    97,    98,    98,   100,    99,
   101,    99,   102,    99,   103,    99,   104,    99,   105,    99,
   106,    99,   107,    99,   108,    99,   109,    99,    99,    99,
   110,   110,   111,   111,   111,   112,   112,   113,   113,   113,
   114,   114,   114,   114,   114,   114,   114,   114,   114,   114,
   115,   115,   115,   115,   116,   116,   117,   118,   118,   119,
   119,   119,   119,   121,   120,   123,   122,   125,   124,   127,
   126,   128,   128,   130,   129,   131,   129,   129,   129,   132,
   132,   133,   133,   133,   134,   134,   134,   134,   134,   134,
   135,   135,   135,   136,   136,   138,   137,   139,   137,   137,
   137,   140,   140,   140,   142,   141,   143,   143,   144,   144,
   145,   145,   145,   146,   146,   146,   146,   146,   147,   147,
   147,   147,   148,   147,   149,   149,   149,   150,   149,   152,
   151,   153,   151,   154,   155,   156,   156,   156,   156,   156,
   156,   156,   156,   156,   157,   158,   158,   159,   159,   160,
   160,   161,   161,   162,   162,   162,   163,   163,   163,   163,
   163,   164,   164,   164,   165,   165,   165,   166,   166,   166,
   166,   167,   167,   167,   167,   167,   168,   168,   169,   170,
   170,   171,   171,   172,   172,   172,   172,   173,   173,   173,
   173,   173,   174,   175,   176,   177,   178,   179,   179,   180,
   180,   180
};

static const short yyr2[] = {     0,
     1,     0,     0,     0,     9,     1,     2,     0,     0,     5,
     0,     5,     0,     5,     0,     5,     0,     5,     0,     5,
     0,     5,     0,     5,     0,     5,     0,     5,     1,     1,
     1,     1,     1,     6,     1,     1,     0,     3,     3,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     2,     1,     1,     5,     2,     0,     1,
     1,     1,     1,     0,     4,     0,     4,     0,     5,     0,
     5,     2,     0,     0,     5,     0,     5,     1,     1,     1,
     0,     3,     3,     1,     1,     1,     1,     1,     1,     4,
     1,     5,     1,     2,     0,     0,     5,     0,     5,     1,
     1,     1,     4,     1,     0,     4,     2,     0,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     0,     5,     1,     1,     1,     0,     5,     0,
     5,     0,     5,     1,     1,     1,     2,     2,     1,     1,
     1,     1,     1,     3,     1,     1,     5,     1,     3,     1,
     3,     1,     3,     1,     3,     3,     1,     3,     3,     3,
     3,     1,     3,     3,     1,     3,     3,     1,     3,     3,
     3,     1,     2,     2,     2,     2,     1,     1,     3,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     1,
     1,     1,     1,     1,     1,     1,     1,     1,     1,     2,
     2,     2
};

static const short yydefact[] = {     0,
     2,     1,     8,     0,     6,     3,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    29,
     7,    30,    59,   198,   199,   200,   201,   202,     0,    37,
     0,     0,     0,     0,     0,     0,     0,     0,     0,    31,
    32,     9,    42,    43,    44,    45,    46,    47,    48,    49,
    50,   182,   184,   185,   186,   187,    11,    36,    40,    41,
   183,    13,    52,    56,    55,    15,    53,    51,    17,    19,
    21,   197,     0,    23,    33,    35,    25,    27,    64,    66,
    68,     4,    70,    58,    60,    61,    62,    63,     0,     0,
     0,     0,     0,     0,   180,    54,     0,   181,     0,     0,
     0,     0,     0,     0,     0,     0,     0,    73,     0,    95,
    10,    12,    38,    39,    14,    16,     0,    18,    20,    22,
     0,    24,    26,    28,   105,     0,     0,     0,     5,     0,
     0,     0,   108,    65,    67,     0,     0,    78,    72,     0,
    79,     0,     0,   100,    94,     0,   101,     0,     0,     0,
    81,     0,    69,     0,     0,    71,    57,    34,   106,   119,
   120,   121,   122,     0,   125,   126,   127,     0,     0,     0,
   134,   135,   188,   193,   194,   195,   189,   190,   191,   192,
   196,     0,     0,     0,   110,   107,   109,   111,   114,   115,
   116,   117,   118,   112,   136,   139,   140,   141,   142,   143,
   113,    88,    86,    87,    89,     0,    74,    80,    84,    85,
     0,    76,    91,    93,    96,     0,    98,   102,   104,     0,
     0,     0,     0,   137,     0,     0,     0,     0,     0,     0,
   145,   146,   148,   150,   152,   154,   157,   162,   165,   168,
   172,   178,   177,   138,     0,     0,     0,     0,     0,     0,
     0,     0,     0,   123,   128,   130,   132,   176,     0,   175,
   173,   174,   144,     0,     0,     0,     0,     0,     0,     0,
     0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
     0,    75,    82,    83,     0,    77,    97,     0,    99,     0,
     0,     0,     0,   179,   149,     0,   151,   153,   155,   156,
   158,   159,   160,   161,   163,   164,   166,   167,   169,   170,
   171,    90,     0,   103,   124,   129,   131,   133,     0,    92,
   147,     0,     0,     0
};

static const short yydefgoto[] = {   322,
     2,     3,    23,   109,     4,     5,    21,    89,    90,    93,
    94,    99,   100,   101,   103,   104,   105,    42,    74,    57,
    58,    59,    66,    67,    96,    39,    84,    85,   106,    86,
   107,    87,   108,    88,   110,   128,   139,   246,   250,   207,
   208,   209,   212,   130,   145,   251,   253,   217,   126,   133,
   150,   186,   187,   188,   189,   290,   190,   291,   191,   292,
   293,   192,   193,   194,   230,   231,   232,   233,   234,   235,
   236,   237,   238,   239,   240,   241,   242,    97,    60,    61,
   243,   196,   197,   198,   199,    76,    26,    22
};

static const short yypact[] = {    13,
-32768,-32768,-32768,    12,   177,-32768,    -3,    -3,    -3,   -42,
   -13,    -9,    -5,     2,     5,    16,    39,    44,   103,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,     1,    25,
    48,   139,   139,   139,    48,   189,   189,    48,    21,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,    34,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,    88,-32768,-32768,-32768,
-32768,-32768,    48,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,    62,   110,
    25,    25,   131,   141,-32768,-32768,     7,-32768,   146,   148,
   170,    48,   174,   175,   176,   114,   114,-32768,   179,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,    88,-32768,-32768,-32768,
    48,-32768,-32768,-32768,-32768,   181,   186,     4,-32768,    11,
   150,    48,-32768,-32768,-32768,   163,   188,-32768,-32768,   190,
-32768,   195,   198,-32768,-32768,   200,-32768,    88,   203,    98,
    61,   199,-32768,   189,   209,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,   201,-32768,-32768,-32768,   202,   205,   206,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,   173,   156,   173,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,   207,-32768,    47,-32768,-32768,
    48,-32768,-32768,-32768,-32768,    48,-32768,-32768,-32768,   173,
   173,   173,   173,-32768,   164,   156,   164,   156,   156,   208,
-32768,   -49,   204,   210,   104,    45,   112,   -19,    65,-32768,
-32768,-32768,-32768,-32768,    88,   217,    61,    61,    48,   218,
   219,    48,   221,-32768,-32768,-32768,-32768,-32768,   212,-32768,
-32768,-32768,-32768,   156,   156,   156,   156,   156,   156,   156,
   156,   156,   156,   156,   156,   156,   156,   156,   156,   156,
   215,-32768,-32768,-32768,    48,-32768,-32768,   222,-32768,   216,
   223,   224,   225,-32768,   204,   228,   210,   104,    45,    45,
   112,   112,   112,   112,   -19,   -19,    65,    65,-32768,-32768,
-32768,-32768,   226,-32768,-32768,-32768,-32768,-32768,   156,-32768,
-32768,   284,   300,-32768
};

static const short yypgoto[] = {-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,   -27,-32768,
-32768,    84,   149,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,   -47,-32768,-32768,-32768,-32768,-32768,-32768,   -71,-32768,
-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,-32768,
-32768,-32768,-32768,-32768,    75,  -252,-32768,    38,    43,    37,
   -65,  -138,   -64,   -63,  -204,  -162,-32768,  -108,   -31,   -59,
  -139,-32768,-32768,-32768,-32768,  -118,   220,   -89
};


#define	YYLAST		309


static const short yytable[] = {    62,
    68,    68,    68,    71,    75,    75,    78,    98,   131,    77,
   195,   125,   296,     7,     8,     9,     1,   136,   125,     6,
     7,     8,     9,   261,   262,    79,    80,    81,   264,    82,
   142,   200,    29,   214,   265,   127,   219,   137,   141,   157,
   147,   102,   224,    83,   244,   143,   218,    43,    44,    45,
    46,    47,    48,    49,    50,    51,   140,    98,   146,   276,
   201,    30,   258,   277,   260,    31,   321,    24,    25,    32,
   121,    40,    41,   309,   310,   311,    33,   138,   185,    34,
   254,   255,   256,   257,   144,   202,   117,    52,    98,   132,
    35,    53,    54,    55,    56,    98,   203,   204,   205,   206,
   149,   270,   271,   272,   273,   125,   159,     7,     8,     9,
    52,    91,    92,    36,    53,    54,    55,    56,    37,   210,
   213,   125,    75,    52,   247,   248,   215,    53,    54,    55,
    56,   301,   302,   303,   304,   111,   281,   160,   161,   162,
   163,   164,   165,   166,   167,   168,   169,   170,   171,   172,
    95,   278,   279,   280,    53,    54,    55,    56,   268,   269,
   173,   174,   175,   176,   177,   178,   179,   180,   181,    72,
    63,    64,   274,   275,   113,   114,   182,    38,   183,   249,
   184,    69,    70,   112,   252,    98,     7,     8,     9,    10,
    11,    12,    13,    14,    15,    16,    17,    18,    19,   283,
   284,    52,   299,   300,   115,    53,    54,    55,    56,   305,
   306,    65,   307,   308,   116,   210,   210,   285,   173,   118,
   288,   119,   177,   178,   179,   180,   173,    27,    28,   148,
   177,   178,   179,   180,   225,   173,   226,   151,   227,   177,
   178,   179,   180,   120,   226,   228,   229,   122,   123,   124,
    20,    52,   129,   313,   134,    53,    54,    55,    56,   135,
    72,    52,   152,   153,    73,    53,    54,    55,    56,   154,
    72,    95,   155,   156,   211,    53,    54,    55,    56,   158,
    72,   220,   221,   323,   216,   222,   223,   245,   266,   263,
   282,   286,   287,   294,   289,   267,   312,   315,   314,   324,
   259,   295,   320,   298,   316,   317,   318,   319,   297
};

static const short yycheck[] = {    31,
    32,    33,    34,    35,    36,    37,    38,    67,   117,    37,
   150,     8,   265,    10,    11,    12,     4,    14,     8,     8,
    10,    11,    12,   228,   229,     5,     6,     7,    78,     9,
    20,   150,    75,   152,    84,   107,   155,    34,   128,   148,
   130,    73,   182,    23,   184,    35,   155,    23,    24,    25,
    26,    27,    28,    29,    30,    31,   128,   117,   130,    79,
   150,    75,   225,    83,   227,    75,   319,    71,    72,    75,
   102,    71,    72,   278,   279,   280,    75,    74,   150,    75,
   220,   221,   222,   223,    74,    25,    80,    63,   148,   121,
    75,    67,    68,    69,    70,   155,    36,    37,    38,    39,
   132,    57,    58,    59,    60,     8,     9,    10,    11,    12,
    63,    78,    79,    75,    67,    68,    69,    70,    75,   151,
   152,     8,   154,    63,    78,    79,   154,    67,    68,    69,
    70,   270,   271,   272,   273,    74,   245,    40,    41,    42,
    43,    44,    45,    46,    47,    48,    49,    50,    51,    52,
    63,    87,    88,    89,    67,    68,    69,    70,    55,    56,
    63,    64,    65,    66,    67,    68,    69,    70,    71,    72,
    32,    33,    61,    62,    91,    92,    79,    75,    81,   211,
    83,    33,    34,    74,   216,   245,    10,    11,    12,    13,
    14,    15,    16,    17,    18,    19,    20,    21,    22,   247,
   248,    63,   268,   269,    74,    67,    68,    69,    70,   274,
   275,    73,   276,   277,    74,   247,   248,   249,    63,    74,
   252,    74,    67,    68,    69,    70,    63,     8,     9,    80,
    67,    68,    69,    70,    79,    63,    81,    75,    83,    67,
    68,    69,    70,    74,    81,    90,    91,    74,    74,    74,
    74,    63,    74,   285,    74,    67,    68,    69,    70,    74,
    72,    63,    75,    74,    76,    67,    68,    69,    70,    75,
    72,    63,    75,    74,    76,    67,    68,    69,    70,    77,
    72,    81,    81,     0,    76,    81,    81,    81,    85,    82,
    74,    74,    74,    82,    74,    86,    82,    82,    77,     0,
   226,   264,    77,   267,    82,    82,    82,    80,   266
};
/* -*-C-*-  Note some compilers choke on comments on `#line' lines.  */
#line 3 "bison.simple"

/* Skeleton output parser for bison,
   Copyright (C) 1984, 1989, 1990 Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.  */

/* As a special exception, when this file is copied by Bison into a
   Bison output file, you may use that output file without restriction.
   This special exception was added by the Free Software Foundation
   in version 1.24 of Bison.  */

#ifndef alloca
#ifdef __GNUC__
#define alloca __builtin_alloca
#else /* not GNU C.  */
#if (!defined (__STDC__) && defined (sparc)) || defined (__sparc__) || defined (__sparc) || defined (__sgi)
#include <alloca.h>
#else /* not sparc */
/*--- OLD #if defined (MSDOS) && !defined (__TURBOC__) */
#if defined (MSDOS) || defined (__BORLANDC__) || defined (_MSC_VER) || defined (_WIN32)
#include <malloc.h>
#else /* not MSDOS, or __TURBOC__ */
#if defined(_AIX)
#include <malloc.h>
 #pragma alloca
#else /* not MSDOS, __TURBOC__, or _AIX */
#ifdef __hpux
#ifdef __cplusplus
extern "C" {
void *alloca (unsigned int);
};
#else /* not __cplusplus */
void *alloca ();
#endif /* not __cplusplus */
#endif /* __hpux */
#endif /* not _AIX */
#endif /* not MSDOS, or __TURBOC__ */
#endif /* not sparc.  */
#endif /* not GNU C.  */
#endif /* alloca not defined.  */

/* This is the parser code that is written into each bison parser
  when the %semantic_parser declaration is not specified in the grammar.
  It was written by Richard Stallman by simplifying the hairy parser
  used when %semantic_parser is specified.  */

/* Note: there must be only one dollar sign in this file.
   It is replaced by the list of actions, each action
   as one case of the switch.  */

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		-2
#define YYEOF		0
#define YYACCEPT	return(0)
#define YYABORT 	return(1)
#define YYERROR		goto yyerrlab1
/* Like YYERROR except do call yyerror.
   This remains here temporarily to ease the
   transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */
#define YYFAIL		goto yyerrlab
#define YYRECOVERING()  (!!yyerrstatus)
#define YYBACKUP(token, value) \
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    { yychar = (token), yylval = (value);			\
      yychar1 = YYTRANSLATE (yychar);				\
      YYPOPSTACK;						\
      goto yybackup;						\
    }								\
  else								\
    { yyerror ("syntax error: cannot back up"); YYERROR; }	\
while (0)

#define YYTERROR	1
#define YYERRCODE	256

#ifndef YYPURE
#define YYLEX		yylex()
#endif

#ifdef YYPURE
#ifdef YYLSP_NEEDED
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, &yylloc, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval, &yylloc)
#endif
#else /* not YYLSP_NEEDED */
#ifdef YYLEX_PARAM
#define YYLEX		yylex(&yylval, YYLEX_PARAM)
#else
#define YYLEX		yylex(&yylval)
#endif
#endif /* not YYLSP_NEEDED */
#endif

/* If nonreentrant, generate the variables here */

#ifndef YYPURE

int	yychar;			/*  the lookahead symbol		*/
YYSTYPE	yylval;			/*  the semantic value of the		*/
				/*  lookahead symbol			*/

#ifdef YYLSP_NEEDED
YYLTYPE yylloc;			/*  location data for the lookahead	*/
				/*  symbol				*/
#endif

int yynerrs;			/*  number of parse errors so far       */
#endif  /* not YYPURE */

#if YYDEBUG != 0
int yydebug;			/*  nonzero means print parse trace	*/
/* Since this is uninitialized, it does not stop multiple parsers
   from coexisting.  */
#endif

/*  YYINITDEPTH indicates the initial size of the parser's stacks	*/

#ifndef	YYINITDEPTH
#define YYINITDEPTH 200
#endif

/*  YYMAXDEPTH is the maximum size the stacks can grow to
    (effective only if the built-in stack extension method is used).  */

#if YYMAXDEPTH == 0
#undef YYMAXDEPTH
#endif

#ifndef YYMAXDEPTH
#define YYMAXDEPTH 10000
#endif

/* Prevent warning if -Wstrict-prototypes.  */
#ifdef __GNUC__
int yyparse (void);
#endif

#if __GNUC__ > 1		/* GNU C and GNU C++ define this.  */
#define __yy_memcpy(TO,FROM,COUNT)	__builtin_memcpy(TO,FROM,COUNT)
#else				/* not GNU C or C++ */
#ifndef __cplusplus

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (to, from, count)
     char *to;
     char *from;
     int count;
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#else /* __cplusplus */

/* This is the most reliable way to avoid incompatibilities
   in available built-in functions on various systems.  */
static void
__yy_memcpy (char *to, char *from, int count)
{
  register char *f = from;
  register char *t = to;
  register int i = count;

  while (i-- > 0)
    *t++ = *f++;
}

#endif
#endif

#line 196 "bison.simple"

/* The user can define YYPARSE_PARAM as the name of an argument to be passed
   into yyparse.  The argument should have type void *.
   It should actually point to an object.
   Grammar actions can access the variable by casting it
   to the proper pointer type.  */

#ifdef YYPARSE_PARAM
#ifdef __cplusplus
#define YYPARSE_PARAM_ARG void *YYPARSE_PARAM
#define YYPARSE_PARAM_DECL
#else /* not __cplusplus */
#define YYPARSE_PARAM_ARG YYPARSE_PARAM
#define YYPARSE_PARAM_DECL void *YYPARSE_PARAM;
#endif /* not __cplusplus */
#else /* not YYPARSE_PARAM */
#define YYPARSE_PARAM_ARG
#define YYPARSE_PARAM_DECL
#endif /* not YYPARSE_PARAM */

int
yyparse(YYPARSE_PARAM_ARG)
     YYPARSE_PARAM_DECL
{
  register int yystate;
  register int yyn;
  register short *yyssp;
  register YYSTYPE *yyvsp;
  int yyerrstatus;	/*  number of tokens to shift before error messages enabled */
  int yychar1 = 0;		/*  lookahead token as an internal (translated) token number */

  short	yyssa[YYINITDEPTH];	/*  the state stack			*/
  YYSTYPE yyvsa[YYINITDEPTH];	/*  the semantic value stack		*/

  short *yyss = yyssa;		/*  refer to the stacks thru separate pointers */
  YYSTYPE *yyvs = yyvsa;	/*  to allow yyoverflow to reallocate them elsewhere */

#ifdef YYLSP_NEEDED
  YYLTYPE yylsa[YYINITDEPTH];	/*  the location stack			*/
  YYLTYPE *yyls = yylsa;
  YYLTYPE *yylsp;

#define YYPOPSTACK   (yyvsp--, yyssp--, yylsp--)
#else
#define YYPOPSTACK   (yyvsp--, yyssp--)
#endif

  int yystacksize = YYINITDEPTH;

#ifdef YYPURE
  int yychar;
  YYSTYPE yylval;
  int yynerrs;
#ifdef YYLSP_NEEDED
  YYLTYPE yylloc;
#endif
#endif

  YYSTYPE yyval;		/*  the variable used to return		*/
				/*  semantic values from the action	*/
				/*  routines				*/

  int yylen;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Starting parse\n");
#endif

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss - 1;
  yyvsp = yyvs;
#ifdef YYLSP_NEEDED
  yylsp = yyls;
#endif

/* Push a new state, which is found in  yystate  .  */
/* In all cases, when you get here, the value and location stacks
   have just been pushed. so pushing a state here evens the stacks.  */
yynewstate:

  *++yyssp = yystate;

  if (yyssp >= yyss + yystacksize - 1)
    {
      /* Give user a chance to reallocate the stack */
      /* Use copies of these so that the &'s don't force the real ones into memory. */
      YYSTYPE *yyvs1 = yyvs;
      short *yyss1 = yyss;
#ifdef YYLSP_NEEDED
      YYLTYPE *yyls1 = yyls;
#endif

      /* Get the current used size of the three stacks, in elements.  */
      int size = yyssp - yyss + 1;

#ifdef yyoverflow
      /* Each stack pointer address is followed by the size of
	 the data in use in that stack, in bytes.  */
#ifdef YYLSP_NEEDED
      /* This used to be a conditional around just the two extra args,
	 but that might be undefined if yyoverflow is a macro.  */
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yyls1, size * sizeof (*yylsp),
		 &yystacksize);
#else
      yyoverflow("parser stack overflow",
		 &yyss1, size * sizeof (*yyssp),
		 &yyvs1, size * sizeof (*yyvsp),
		 &yystacksize);
#endif

      yyss = yyss1; yyvs = yyvs1;
#ifdef YYLSP_NEEDED
      yyls = yyls1;
#endif
#else /* no yyoverflow */
      /* Extend the stack our own way.  */
      if (yystacksize >= YYMAXDEPTH)
	{
	  yyerror("parser stack overflow");
	  return 2;
	}
      yystacksize *= 2;
      if (yystacksize > YYMAXDEPTH)
	yystacksize = YYMAXDEPTH;
      yyss = (short *) alloca (yystacksize * sizeof (*yyssp));
      __yy_memcpy ((char *)yyss, (char *)yyss1, size * sizeof (*yyssp));
      yyvs = (YYSTYPE *) alloca (yystacksize * sizeof (*yyvsp));
      __yy_memcpy ((char *)yyvs, (char *)yyvs1, size * sizeof (*yyvsp));
#ifdef YYLSP_NEEDED
      yyls = (YYLTYPE *) alloca (yystacksize * sizeof (*yylsp));
      __yy_memcpy ((char *)yyls, (char *)yyls1, size * sizeof (*yylsp));
#endif
#endif /* no yyoverflow */

      yyssp = yyss + size - 1;
      yyvsp = yyvs + size - 1;
#ifdef YYLSP_NEEDED
      yylsp = yyls + size - 1;
#endif

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Stack size increased to %d\n", yystacksize);
#endif

      if (yyssp >= yyss + yystacksize - 1)
	YYABORT;
    }

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Entering state %d\n", yystate);
#endif

  goto yybackup;
 yybackup:

/* Do appropriate processing given the current state.  */
/* Read a lookahead token if we need one and don't already have one.  */
/* yyresume: */

  /* First try to decide what to do without reference to lookahead token.  */

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yydefault;

  /* Not known => get a lookahead token if don't already have one.  */

  /* yychar is either YYEMPTY or YYEOF
     or a valid token in external form.  */

  if (yychar == YYEMPTY)
    {
#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Reading a token: ");
#endif
      yychar = YYLEX;
    }

  /* Convert token to internal form (in yychar1) for indexing tables with */

  if (yychar <= 0)		/* This means end of input. */
    {
      yychar1 = 0;
      yychar = YYEOF;		/* Don't call YYLEX any more */

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Now at end of input.\n");
#endif
    }
  else
    {
      yychar1 = YYTRANSLATE(yychar);

#if YYDEBUG != 0
      if (yydebug)
	{
	  fprintf (stderr, "Next token is %d (%s", yychar, yytname[yychar1]);
	  /* Give the individual parser a way to print the precise meaning
	     of a token, for further debugging info.  */
#ifdef YYPRINT
	  YYPRINT (stderr, yychar, yylval);
#endif
	  fprintf (stderr, ")\n");
	}
#endif
    }

  yyn += yychar1;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != yychar1)
    goto yydefault;

  yyn = yytable[yyn];

  /* yyn is what to do for this token type in this state.
     Negative => reduce, -yyn is rule number.
     Positive => shift, yyn is new state.
       New state is final state => don't bother to shift,
       just return success.
     0, or most negative number => error.  */

  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrlab;

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Shift the lookahead token.  */

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting token %d (%s), ", yychar, yytname[yychar1]);
#endif

  /* Discard the token being shifted unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  /* count tokens shifted since error; after three, turn off error status.  */
  if (yyerrstatus) yyerrstatus--;

  yystate = yyn;
  goto yynewstate;

/* Do the default action for the current state.  */
yydefault:

  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;

/* Do a reduction.  yyn is the number of a rule to reduce with.  */
yyreduce:
  yylen = yyr2[yyn];
  if (yylen > 0)
    yyval = yyvsp[1-yylen]; /* implement default value of the action */

#if YYDEBUG != 0
  if (yydebug)
    {
      int i;

      fprintf (stderr, "Reducing via rule %d (line %d), ",
	       yyn, yyrline[yyn]);

      /* Print the symbols being reduced, and their result.  */
      for (i = yyprhs[yyn]; yyrhs[i] > 0; i++)
	fprintf (stderr, "%s ", yytname[yyrhs[i]]);
      fprintf (stderr, " -> %s\n", yytname[yyr1[yyn]]);
    }
#endif


  switch (yyn) {

case 2:
#line 204 "parser.y"
{ begin_file(); ;
    break;}
case 3:
#line 207 "parser.y"
{ begin_data(); begin_scope(); ;
    break;}
case 4:
#line 210 "parser.y"
{ end_scope(); ;
    break;}
case 5:
#line 212 "parser.y"
{ end_file(); ;
    break;}
case 9:
#line 226 "parser.y"
{ setFilenameFileHeader(&fileheader, yyvsp[0].sval);  ;
    break;}
case 11:
#line 229 "parser.y"
{ fileheader.attrib = (unsigned short)(yyvsp[0].lval); ;
    break;}
case 13:
#line 232 "parser.y"
{ fileheader.version = (unsigned short)(yyvsp[0].lval); ;
    break;}
case 15:
#line 235 "parser.y"
{ fileheader.creationDate = yyvsp[0].lval; 
		message(3, "creation_date = %lu (%08x_x)", yyvsp[0].lval, yyvsp[0].lval); 
		;
    break;}
case 17:
#line 240 "parser.y"
{ fileheader.modificationDate = yyvsp[0].lval; 
		message(3, "modification_date = %lu (%08x_x)", yyvsp[0].lval, yyvsp[0].lval); 
		;
    break;}
case 19:
#line 245 "parser.y"
{ fileheader.backupDate = yyvsp[0].lval; 
		message(3, "backup_date = %lu (%08x_x)", yyvsp[0].lval, yyvsp[0].lval); 
		;
    break;}
case 21:
#line 250 "parser.y"
{ fileheader.modNumber = yyvsp[0].lval; ;
    break;}
case 23:
#line 253 "parser.y"
{ setTypeIdFileHeader(&fileheader, yyvsp[0].lval);  ;
    break;}
case 25:
#line 256 "parser.y"
{ setCreatorIdFileHeader(&fileheader, yyvsp[0].lval);  ;
    break;}
case 27:
#line 259 "parser.y"
{ fileheader.uniqueIdSeed = yyvsp[0].lval; ;
    break;}
case 33:
#line 272 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 34:
#line 274 "parser.y"
{ yyval.lval = conv_4long_to_id(yyvsp[-4].lval, yyvsp[-3].lval, yyvsp[-2].lval, yyvsp[-1].lval);  ;
    break;}
case 35:
#line 276 "parser.y"
{ yyval.lval = conv_quoted_string_to_id(yyvsp[0].sval, 4);  ;
    break;}
case 36:
#line 281 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 37:
#line 283 "parser.y"
{ yyval.lval = 0x0000; ;
    break;}
case 38:
#line 288 "parser.y"
{ yyval.lval = yyvsp[-2].lval | yyvsp[0].lval; ;
    break;}
case 39:
#line 290 "parser.y"
{ yyval.lval = yyvsp[-2].lval + yyvsp[0].lval; ;
    break;}
case 40:
#line 292 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 41:
#line 297 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 42:
#line 299 "parser.y"
{ yyval.lval = 0x0001; ;
    break;}
case 43:
#line 301 "parser.y"
{ yyval.lval = 0x0002; ;
    break;}
case 44:
#line 303 "parser.y"
{ yyval.lval = 0x0004; ;
    break;}
case 45:
#line 305 "parser.y"
{ yyval.lval = 0x0008; ;
    break;}
case 46:
#line 307 "parser.y"
{ yyval.lval = 0x0010; ;
    break;}
case 47:
#line 309 "parser.y"
{ yyval.lval = 0x0020; ;
    break;}
case 48:
#line 311 "parser.y"
{ yyval.lval = 0x0040; ;
    break;}
case 49:
#line 313 "parser.y"
{ yyval.lval = 0x0080; ;
    break;}
case 50:
#line 315 "parser.y"
{ yyval.lval = 0x0100; ;
    break;}
case 51:
#line 320 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 52:
#line 322 "parser.y"
{ yyval.lval = get_now(); ;
    break;}
case 53:
#line 324 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 54:
#line 326 "parser.y"
{ yyval.lval = yyvsp[-1].lval + yyvsp[0].lval; ;
    break;}
case 55:
#line 331 "parser.y"
{ int y,m,d; sscanf(yyvsp[0].sval, "%d/%d/%d", &y, &m, &d); yyval.lval = get_date(y,m,d); ;
    break;}
case 56:
#line 333 "parser.y"
{ yyval.lval = get_today(); ;
    break;}
case 57:
#line 338 "parser.y"
{ yyval.lval = (yyvsp[-4].lval*60 + yyvsp[-2].lval)*60 + yyvsp[0].lval; ;
    break;}
case 64:
#line 355 "parser.y"
{ begin_appinfo(); ;
    break;}
case 65:
#line 357 "parser.y"
{ end_appinfo(); ;
    break;}
case 66:
#line 362 "parser.y"
{ begin_sortinfo(); ;
    break;}
case 67:
#line 364 "parser.y"
{ end_sortinfo(); ;
    break;}
case 68:
#line 369 "parser.y"
{ begin_record(); ;
    break;}
case 69:
#line 372 "parser.y"
{ end_record(); ;
    break;}
case 70:
#line 377 "parser.y"
{ begin_resource(); ;
    break;}
case 71:
#line 380 "parser.y"
{ end_resource(); ;
    break;}
case 74:
#line 390 "parser.y"
{ set_record_attrib((char) yyvsp[0].lval); ;
    break;}
case 76:
#line 393 "parser.y"
{ set_record_id(yyvsp[0].lval); ;
    break;}
case 80:
#line 401 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 81:
#line 403 "parser.y"
{ yyval.lval = 0x00; ;
    break;}
case 82:
#line 408 "parser.y"
{ yyval.lval = yyvsp[-2].lval | yyvsp[0].lval; ;
    break;}
case 83:
#line 410 "parser.y"
{ yyval.lval = yyvsp[-2].lval + yyvsp[0].lval; ;
    break;}
case 84:
#line 412 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 85:
#line 417 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 86:
#line 419 "parser.y"
{ yyval.lval = 0x10; ;
    break;}
case 87:
#line 421 "parser.y"
{ yyval.lval = 0x20; ;
    break;}
case 88:
#line 423 "parser.y"
{ yyval.lval = 0x40; ;
    break;}
case 89:
#line 425 "parser.y"
{ yyval.lval = 0x80; ;
    break;}
case 90:
#line 427 "parser.y"
{ yyval.lval = yyvsp[-1].lval; ;
    break;}
case 91:
#line 432 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 92:
#line 434 "parser.y"
{ yyval.lval = conv_4long_to_id(0, yyvsp[-3].lval, yyvsp[-2].lval, yyvsp[-1].lval); ;
    break;}
case 93:
#line 436 "parser.y"
{ yyval.lval = conv_quoted_string_to_id(yyvsp[0].sval, 3); ;
    break;}
case 96:
#line 446 "parser.y"
{ set_resource_type_id(yyvsp[0].lval); ;
    break;}
case 98:
#line 449 "parser.y"
{ set_resource_id((unsigned short)yyvsp[0].lval); ;
    break;}
case 102:
#line 457 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 103:
#line 459 "parser.y"
{ yyval.lval = conv_4long_to_id(0, 0, yyvsp[-2].lval, yyvsp[-1].lval); ;
    break;}
case 104:
#line 461 "parser.y"
{ yyval.lval = conv_quoted_string_to_id(yyvsp[0].sval, 2); ;
    break;}
case 105:
#line 466 "parser.y"
{ begin_scope(); ;
    break;}
case 106:
#line 469 "parser.y"
{ end_scope(); ;
    break;}
case 119:
#line 498 "parser.y"
{ set_base(2); ;
    break;}
case 120:
#line 500 "parser.y"
{ set_base(8); ;
    break;}
case 121:
#line 502 "parser.y"
{ set_base(10); ;
    break;}
case 122:
#line 504 "parser.y"
{ set_base(16); ;
    break;}
case 123:
#line 506 "parser.y"
{ set_base(conv_str_to_ulong(yyvsp[0].sval, 10)); ;
    break;}
case 125:
#line 512 "parser.y"
{ set_size(1); ;
    break;}
case 126:
#line 514 "parser.y"
{ set_size(2); ;
    break;}
case 127:
#line 516 "parser.y"
{ set_size(4); ;
    break;}
case 128:
#line 518 "parser.y"
{ set_size(conv_str_to_ulong(yyvsp[0].sval, 10)); ;
    break;}
case 130:
#line 524 "parser.y"
{ set_padstring(conv_str_to_ulong(yyvsp[0].sval, 10)); ;
    break;}
case 132:
#line 527 "parser.y"
{ set_padchar(conv_str_to_ulong(yyvsp[0].sval, 10)); ;
    break;}
case 134:
#line 533 "parser.y"
{ set_double_mode(1); ;
    break;}
case 135:
#line 538 "parser.y"
{ set_double_mode(0); ;
    break;}
case 136:
#line 543 "parser.y"
{ write_number(yyvsp[0].sval, 1, get_base(), get_size()); ;
    break;}
case 137:
#line 545 "parser.y"
{ write_number(yyvsp[0].sval, 1, get_base(), get_size()); ;
    break;}
case 138:
#line 547 "parser.y"
{ write_number(yyvsp[0].sval, 0, get_base(), get_size()); ;
    break;}
case 139:
#line 549 "parser.y"
{ 
		  if(get_double_mode()) {
		    write_double(yyvsp[0].dval); 
		  } else {
		    write_float((float)yyvsp[0].dval); 
		  }
		;
    break;}
case 140:
#line 557 "parser.y"
{ write_double(yyvsp[0].dval); ;
    break;}
case 141:
#line 559 "parser.y"
{ write_float(yyvsp[0].fval); ;
    break;}
case 142:
#line 561 "parser.y"
{ write_quoted_string(yyvsp[0].sval, get_padstring(), TRUE); ;
    break;}
case 143:
#line 563 "parser.y"
{ write_quoted_string(yyvsp[0].sval, get_padchar(), FALSE); ;
    break;}
case 144:
#line 565 "parser.y"
{ write_value(yyvsp[-1].lval, 1, get_size()); ;
    break;}
case 145:
#line 569 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 146:
#line 573 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 147:
#line 575 "parser.y"
{ yyval.lval = yyvsp[-4].lval ? yyvsp[-2].lval : yyvsp[0].lval; ;
    break;}
case 148:
#line 579 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 149:
#line 581 "parser.y"
{ yyval.lval = yyvsp[-2].lval | yyvsp[0].lval; ;
    break;}
case 150:
#line 585 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 151:
#line 587 "parser.y"
{ yyval.lval = yyvsp[-2].lval ^ yyvsp[0].lval; ;
    break;}
case 152:
#line 591 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 153:
#line 593 "parser.y"
{ yyval.lval = yyvsp[-2].lval & yyvsp[0].lval; ;
    break;}
case 154:
#line 597 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 155:
#line 599 "parser.y"
{ yyval.lval = yyvsp[-2].lval == yyvsp[0].lval; ;
    break;}
case 156:
#line 601 "parser.y"
{ yyval.lval = yyvsp[-2].lval != yyvsp[0].lval; ;
    break;}
case 157:
#line 605 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 158:
#line 607 "parser.y"
{ yyval.lval = yyvsp[-2].lval < yyvsp[0].lval; ;
    break;}
case 159:
#line 609 "parser.y"
{ yyval.lval = yyvsp[-2].lval <= yyvsp[0].lval; ;
    break;}
case 160:
#line 611 "parser.y"
{ yyval.lval = yyvsp[-2].lval > yyvsp[0].lval; ;
    break;}
case 161:
#line 613 "parser.y"
{ yyval.lval = yyvsp[-2].lval >= yyvsp[0].lval; ;
    break;}
case 162:
#line 617 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 163:
#line 619 "parser.y"
{ yyval.lval = yyvsp[-2].lval << yyvsp[0].lval; ;
    break;}
case 164:
#line 621 "parser.y"
{ yyval.lval = yyvsp[-2].lval >> yyvsp[0].lval; ;
    break;}
case 165:
#line 625 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 166:
#line 627 "parser.y"
{ yyval.lval = yyvsp[-2].lval + yyvsp[0].lval; ;
    break;}
case 167:
#line 629 "parser.y"
{ yyval.lval = yyvsp[-2].lval - yyvsp[0].lval; ;
    break;}
case 168:
#line 633 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 169:
#line 635 "parser.y"
{ yyval.lval = yyvsp[-2].lval * yyvsp[0].lval; ;
    break;}
case 170:
#line 637 "parser.y"
{ yyval.lval = yyvsp[-2].lval / yyvsp[0].lval; ;
    break;}
case 171:
#line 639 "parser.y"
{ yyval.lval = yyvsp[-2].lval % yyvsp[0].lval; ;
    break;}
case 172:
#line 643 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 173:
#line 645 "parser.y"
{ yyval.lval = ! yyvsp[0].lval; ;
    break;}
case 174:
#line 647 "parser.y"
{ yyval.lval = ~ yyvsp[0].lval; ;
    break;}
case 175:
#line 649 "parser.y"
{ yyval.lval = - yyvsp[0].lval; ;
    break;}
case 176:
#line 651 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 177:
#line 654 "parser.y"
{ yyval.lval = conv_str_to_ulong(yyvsp[0].sval, get_base()); ;
    break;}
case 178:
#line 656 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 179:
#line 659 "parser.y"
{ yyval.lval = yyvsp[-1].lval; ;
    break;}
case 180:
#line 664 "parser.y"
{ yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 10); ;
    break;}
case 181:
#line 666 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 182:
#line 671 "parser.y"
{ yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 16); ;
    break;}
case 183:
#line 673 "parser.y"
{ yyval.lval = yyvsp[0].lval; ;
    break;}
case 184:
#line 678 "parser.y"
{ yyvsp[0].sval[strlen(yyvsp[0].sval)-2] = 0; yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 2); ;
    break;}
case 185:
#line 680 "parser.y"
{ yyvsp[0].sval[strlen(yyvsp[0].sval)-2] = 0; yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 8); ;
    break;}
case 186:
#line 682 "parser.y"
{ yyvsp[0].sval[strlen(yyvsp[0].sval)-2] = 0; yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 10); ;
    break;}
case 187:
#line 684 "parser.y"
{ yyvsp[0].sval[strlen(yyvsp[0].sval)-2] = 0; yyval.lval = conv_str_to_ulong(yyvsp[0].sval, 16); ;
    break;}
case 200:
#line 722 "parser.y"
{ compiler_error("User error: %s", yyvsp[0].sval); ;
    break;}
case 201:
#line 724 "parser.y"
{ compiler_warning("User warning: %s", yyvsp[0].sval); ;
    break;}
case 202:
#line 726 "parser.y"
{ message(1, "User message: %s", yyvsp[0].sval); ;
    break;}
}
   /* the action file gets copied in in place of this dollarsign */
#line 498 "bison.simple"

  yyvsp -= yylen;
  yyssp -= yylen;
#ifdef YYLSP_NEEDED
  yylsp -= yylen;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

  *++yyvsp = yyval;

#ifdef YYLSP_NEEDED
  yylsp++;
  if (yylen == 0)
    {
      yylsp->first_line = yylloc.first_line;
      yylsp->first_column = yylloc.first_column;
      yylsp->last_line = (yylsp-1)->last_line;
      yylsp->last_column = (yylsp-1)->last_column;
      yylsp->text = 0;
    }
  else
    {
      yylsp->last_line = (yylsp+yylen-1)->last_line;
      yylsp->last_column = (yylsp+yylen-1)->last_column;
    }
#endif

  /* Now "shift" the result of the reduction.
     Determine what state that goes to,
     based on the state we popped back to
     and the rule number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTBASE] + *yyssp;
  if (yystate >= 0 && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTBASE];

  goto yynewstate;

yyerrlab:   /* here on detecting error */

  if (! yyerrstatus)
    /* If not already recovering from an error, report this error.  */
    {
      ++yynerrs;

#ifdef YYERROR_VERBOSE
      yyn = yypact[yystate];

      if (yyn > YYFLAG && yyn < YYLAST)
	{
	  int size = 0;
	  char *msg;
	  int x, count;

	  count = 0;
	  /* Start X at -yyn if nec to avoid negative indexes in yycheck.  */
	  for (x = (yyn < 0 ? -yyn : 0);
	       x < (sizeof(yytname) / sizeof(char *)); x++)
	    if (yycheck[x + yyn] == x)
	      size += strlen(yytname[x]) + 15, count++;
	  msg = (char *) malloc(size + 15);
	  if (msg != 0)
	    {
	      strcpy(msg, "parse error");

	      if (count < 5)
		{
		  count = 0;
		  for (x = (yyn < 0 ? -yyn : 0);
		       x < (sizeof(yytname) / sizeof(char *)); x++)
		    if (yycheck[x + yyn] == x)
		      {
			strcat(msg, count == 0 ? ", expecting `" : " or `");
			strcat(msg, yytname[x]);
			strcat(msg, "'");
			count++;
		      }
		}
	      yyerror(msg);
	      free(msg);
	    }
	  else
	    yyerror ("parse error; also virtual memory exceeded");
	}
      else
#endif /* YYERROR_VERBOSE */
	yyerror("parse error");
    }

  goto yyerrlab1;
yyerrlab1:   /* here on error raised explicitly by an action */

  if (yyerrstatus == 3)
    {
      /* if just tried and failed to reuse lookahead token after an error, discard it.  */

      /* return failure if at end of input */
      if (yychar == YYEOF)
	YYABORT;

#if YYDEBUG != 0
      if (yydebug)
	fprintf(stderr, "Discarding token %d (%s).\n", yychar, yytname[yychar1]);
#endif

      yychar = YYEMPTY;
    }

  /* Else will try to reuse lookahead token
     after shifting the error token.  */

  yyerrstatus = 3;		/* Each real token shifted decrements this */

  goto yyerrhandle;

yyerrdefault:  /* current state does not do anything special for the error token. */

#if 0
  /* This is wrong; only states that explicitly want error tokens
     should shift them.  */
  yyn = yydefact[yystate];  /* If its default is to accept any token, ok.  Otherwise pop it.*/
  if (yyn) goto yydefault;
#endif

yyerrpop:   /* pop the current state because it cannot handle the error token */

  if (yyssp == yyss) YYABORT;
  yyvsp--;
  yystate = *--yyssp;
#ifdef YYLSP_NEEDED
  yylsp--;
#endif

#if YYDEBUG != 0
  if (yydebug)
    {
      short *ssp1 = yyss - 1;
      fprintf (stderr, "Error: state stack now");
      while (ssp1 != yyssp)
	fprintf (stderr, " %d", *++ssp1);
      fprintf (stderr, "\n");
    }
#endif

yyerrhandle:

  yyn = yypact[yystate];
  if (yyn == YYFLAG)
    goto yyerrdefault;

  yyn += YYTERROR;
  if (yyn < 0 || yyn > YYLAST || yycheck[yyn] != YYTERROR)
    goto yyerrdefault;

  yyn = yytable[yyn];
  if (yyn < 0)
    {
      if (yyn == YYFLAG)
	goto yyerrpop;
      yyn = -yyn;
      goto yyreduce;
    }
  else if (yyn == 0)
    goto yyerrpop;

  if (yyn == YYFINAL)
    YYACCEPT;

#if YYDEBUG != 0
  if (yydebug)
    fprintf(stderr, "Shifting error token, ");
#endif

  *++yyvsp = yylval;
#ifdef YYLSP_NEEDED
  *++yylsp = yylloc;
#endif

  yystate = yyn;
  goto yynewstate;
}
#line 729 "parser.y"


void yyerror(char *msg)
{
  compiler_error("%s '%s'", 
	msg, yytext);
}

void begin_parser(FILE *in)
{
  yyrestart(in);
  lineno = 1;
  
//  BEGIN INITIAL;

  yyparse();
}
