//--------------------------------------------------------------------
//
// Copyright 2002 by Eric Obermuhlner
//
// $Id$
//
// $Log$
//
//---------------------------------------------------------------------

#ifndef template_h
#define template_h

void init_template(const char* templateName);
void feed_template(unsigned char v);

#endif
