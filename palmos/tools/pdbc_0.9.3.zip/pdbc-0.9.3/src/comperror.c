//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: comperror.c 1.1 2001/09/30 10:59:02 obermuhl Exp $
//
// $Log: comperror.c $
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "comperror.h"

//---------------------------------------------------------------------

int get_linenumber();

//---------------------------------------------------------------------

extern char *progname;
extern char *src_filename;
extern int warning_level;
extern int warning_as_errors;

//---------------------------------------------------------------------

void compiler_error(char *msg, ...)
{
  va_list marker;

  va_start(marker, msg);
  fprintf(stderr, "%s: %d: Error: ", src_filename, get_linenumber());
  vfprintf(stderr, msg, marker);
  fprintf(stderr, "\n");

  va_end(marker);
  exit(5);
}

void compiler_warning(char *msg, ...)
{
  if(warning_level>0) {
    va_list marker;
    
    va_start(marker, msg);
    fprintf(stderr, "%s: %d: Warning: ", src_filename, get_linenumber());
    vfprintf(stderr, msg, marker);
    fprintf(stderr, "\n");
    
    va_end(marker);
  }
  if(warning_as_errors) {
    fprintf(stderr, "%s: Warning treated as error.\n", progname);
    exit(5);
  }
}

//---------------------------------------------------------------------
