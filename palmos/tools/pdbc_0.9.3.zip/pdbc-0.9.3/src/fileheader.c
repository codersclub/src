//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: fileheader.c 1.1 2001/09/30 10:59:02 obermuhl Exp $
//
// $Log: fileheader.c $
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include "fileheader.h"

#include <stdlib.h>
#include <string.h>

//---------------------------------------------------------------------

int createFileHeader(FileHeader *fileheader)
{
  memset(fileheader, 0, sizeof(FileHeader));
  strcpy(fileheader->filename, "Unnamed");
  fileheader->creatorId[0] = 'E';
  fileheader->creatorId[1] = 'R';
  fileheader->creatorId[2] = 'R';
  fileheader->creatorId[3] = '1';
  fileheader->typeId[0] = 'E';
  fileheader->typeId[1] = 'R';
  fileheader->typeId[2] = 'R';
  fileheader->typeId[3] = '2';
  fileheader->numRecords = 0;
  return TRUE;
}

int deleteFileHeader(FileHeader *fileheader)
{
  // do nothing
  return TRUE;
}

static void assignString(char *trg, char *src, size_t maxlen)
{
  size_t len = strlen(src);
  char c1;
  char c2;
  size_t i;

  if(len==0) {
    memset(trg, 0, maxlen);
    return;
  }

  c1 = src[0];
  c2 = src[len-1];

  if(c1=='\"' || c1=='\'') {
    // skip leading quote
    src++;
    len--;
    if(c2 == c1) {
      // skip trailing quote
      len--;
    }
  }
  
  strncpy(trg, src, len);
  for(i=len ; i<maxlen ; i++) {
    trg[i] = 0;
  }
}

void setFilenameFileHeader(FileHeader *fileheader, char *filename)
{
  assignString(fileheader->filename, filename, 32);
}

void setCreatorIdFileHeader(FileHeader *fileheader, unsigned long id)
{
  fileheader->creatorId[0] = (char)((id >> 24) & 0xff);
  fileheader->creatorId[1] = (char)((id >> 16) & 0xff);
  fileheader->creatorId[2] = (char)((id >> 8) & 0xff);
  fileheader->creatorId[3] = (char)(id & 0xff);
}

void setTypeIdFileHeader(FileHeader *fileheader, unsigned long id)
{
  fileheader->typeId[0] = (char)((id >> 24) & 0xff);
  fileheader->typeId[1] = (char)((id >> 16) & 0xff);
  fileheader->typeId[2] = (char)((id >> 8) & 0xff);
  fileheader->typeId[3] = (char)(id & 0xff);
}

int dumpMemFileFileHeader(FileHeader *fileheader, MemFile *memfile)
{
  writeBufferMemFile(memfile, fileheader->filename, 32);
  writeWordMemFile(memfile, fileheader->attrib);
  writeWordMemFile(memfile, fileheader->version);
  writeLongMemFile(memfile, fileheader->creationDate);
  writeLongMemFile(memfile, fileheader->modificationDate);
  writeLongMemFile(memfile, fileheader->backupDate);
  writeLongMemFile(memfile, fileheader->modNumber);
  writeLongMemFile(memfile, fileheader->appInfoArea);
  writeLongMemFile(memfile, fileheader->sortInfoArea);
  writeBufferMemFile(memfile, fileheader->typeId, 4);
  writeBufferMemFile(memfile, fileheader->creatorId, 4);
  writeLongMemFile(memfile, fileheader->uniqueIdSeed);
  writeLongMemFile(memfile, fileheader->nextRecordListId);
  writeWordMemFile(memfile, fileheader->numRecords);
  if(fileheader->numRecords == 0) {
    writeWordMemFile(memfile, 0);
  }
  return TRUE;
}

//---------------------------------------------------------------------


