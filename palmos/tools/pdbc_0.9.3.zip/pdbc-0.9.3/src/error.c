//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: error.c 1.2 2001/10/16 21:20:20 obermuhl Exp obermuhl $
//
// $Log: error.c $
// Revision 1.2  2001/10/16 21:20:20  obermuhl
// added new print_*() functions
//
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdarg.h>
#include <stdlib.h>

#include "error.h"

//---------------------------------------------------------------------

char *progname = "unknown";

int verbose_level = 1;
int warning_level = 1;

int warning_as_errors = 0;

static int current_print_pos = 0;

FILE *printout = stdout;

//---------------------------------------------------------------------

void error(char *msg, ...)
{
  va_list marker;

  va_start(marker, msg);
  fprintf(stderr, "%s: ", progname);
  vfprintf(stderr, msg, marker);
  fprintf(stderr, "\n");

  va_end(marker);
  exit(4);
}

void warning(char *msg, ...)
{
  va_list marker;

  va_start(marker, msg);
  fprintf(stderr, "%s: Warning ", progname);
  vfprintf(stderr, msg, marker);
  fprintf(stderr, "\n");

  va_end(marker);
  if(warning_as_errors) {
    fprintf(stderr, "%s: Warning treated as error.\n", progname);
    exit(5);
  }
}

void message(int level, char *msg, ...)
{
  if(level <= verbose_level) {
    va_list marker;

    va_start(marker, msg);
    vfprintf(stdout, msg, marker);
    fprintf(stdout, "\n");

    va_end(marker);
  }
}

void set_verbose_level(char level)
{
  switch(level) {
  case '0' :
    verbose_level = 0;
    break;
  case '1' :
    verbose_level = 1;
    break;
  case '2' :
    verbose_level = 2;
    break;
  case '3' :
    verbose_level = 3;
    break;
  case '4' :
    verbose_level = 4;
    break;
  case '5' :
    verbose_level = 5;
    break;
  case '6' :
    verbose_level = 6;
    break;
  case '7' :
    verbose_level = 7;
    break;
  case '8' :
    verbose_level = 8;
    break;
  case '9' :
    verbose_level = 9;
    break;
  default :
    if(level == '\0') {
      verbose_level = 2;
    } else {
      verbose_level = 4;
    }
    break;
  }
}

//---------------------------------------------------------------------

void set_warning_level(char level)
{
  switch(level) {
  case '0' :
    warning_level = 0;
    break;
  case '1' :
    warning_level = 1;
    break;
  default :
    warning_level = 1;
    break;
  }
}

//---------------------------------------------------------------------

void set_warning_as_errors(int flag)
{
  warning_as_errors = flag;
}

//---------------------------------------------------------------------

int get_verbose_level()
{
  return verbose_level;
}

//---------------------------------------------------------------------

void set_printout(FILE *f)
{
  printout = f;
}

//---------------------------------------------------------------------

void print_reset()
{
  current_print_pos = 0;
}

//---------------------------------------------------------------------

void print_str(char *str)
{
  current_print_pos += fprintf(printout, "%s", str);
}

//---------------------------------------------------------------------

void print_text(char *msg, ...)
{
  va_list marker;
  
  va_start(marker, msg);
  current_print_pos += vfprintf(printout, msg, marker);
  
  va_end(marker);
}

//---------------------------------------------------------------------

void print_line(char *msg, ...)
{
  va_list marker;
  
  va_start(marker, msg);
  vfprintf(printout, msg, marker);
  fprintf(printout, "\n");
  current_print_pos = 0;
  
  va_end(marker);
}

//---------------------------------------------------------------------

void print_newline()
{
  fprintf(printout, "\n");
  current_print_pos = 0;
}

//---------------------------------------------------------------------

void print_fill(int pos)
{
  while(current_print_pos < pos) {
    fprintf(printout, " ");
    current_print_pos++;
  }
}

//---------------------------------------------------------------------

char* parse_option(int argc, char *argv[], int *index, 
		   char opt_char, char *opt_str, int opt_args)
{
  int old_idx = *index;

  if(opt_char && argv[*index][0] == '-' && argv[*index][1] == opt_char) {
    if(opt_args > 0) {
      if(argv[old_idx][2]) {
	(*index)++;
	return &argv[old_idx][2];
      } else {
	char *arg;
	if(old_idx + opt_args >= argc) {
	  fprintf(stderr, "Option -%c ", opt_char);
	  if(opt_str) {
	    fprintf(stderr, "(%s) ", opt_str);
	  }
	  fprintf(stderr, "needs %d argument%s\n", opt_args, opt_args == 1 ? "" : "s");
	  exit(3);
	}
	(*index)++;
	arg = argv[*index];
	(*index)++;
	return arg;
      }
    } else if(argv[old_idx][2] == 0) {
      char *arg = argv[*index];
      (*index)++;
      return arg;
    } else {
      return 0;
    }
  }

  if(opt_str) {
    int opt_len = strlen(opt_str);
    if(strcmp(argv[*index], opt_str) == 0 ||
       (strncmp(argv[*index], opt_str, opt_len) == 0 &&
	argv[*index][opt_len] == '=')) {
      char *arg = argv[*index];
      (*index)++;
      if(opt_args > 0) {
	if(argv[old_idx][opt_len] == '=') {
	  arg = &argv[old_idx][opt_len+1];
	} else {
	  if(old_idx + opt_args >= argc) {
	    fprintf(stderr, "Option %s ", opt_str);
	    if(opt_str) {
	      fprintf(stderr, "(-%c) ", opt_char);
	    }
	    fprintf(stderr, "needs %d argument%s\n", opt_args, opt_args == 1 ? "" : "s");
	    exit(3);
	  }
	  arg = argv[*index];
	  (*index)++;
	}
      }
      return arg;
    }
  }
    
  return 0;
}

//---------------------------------------------------------------------

