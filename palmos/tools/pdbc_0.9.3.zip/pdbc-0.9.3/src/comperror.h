//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: comperror.h 1.1 2001/09/30 10:59:14 obermuhl Exp $
//
// $Log: comperror.h $
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef comperror_h
#define comperror_h

//---------------------------------------------------------------------

void compiler_error(char *msg, ...);
void compiler_warning(char *msg, ...);

//---------------------------------------------------------------------

#endif
