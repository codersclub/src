//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: memfile.c 1.1 2001/09/30 10:59:02 obermuhl Exp $
//
// $Log: memfile.c $
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include "memfile.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

//---------------------------------------------------------------------

static int growMemFile(MemFile *memfile, size_t newsize);

//---------------------------------------------------------------------

int createMemFile(MemFile *memfile)
{
  memfile->itsBuffer = NULL;
  memfile->itsBufferSize = 0;
  memfile->itsLength = 0;
  memfile->itsAddress = 0;
  return growMemFile(memfile, 512);
}

int deleteMemFile(MemFile *memfile)
{
  if(!memfile) {
    return FALSE;
  }
  if(memfile->itsBuffer) {
    free(memfile->itsBuffer);
  }
  memfile->itsBuffer = NULL;
  memfile->itsBufferSize = 0;
  memfile->itsLength = 0;
  memfile->itsAddress = 0;
  return TRUE;
}

size_t getAddressMemFile(MemFile *memfile)
{
  return memfile->itsAddress;
}

void setAddressMemFile(MemFile *memfile, size_t addr)
{
  if(addr > memfile->itsBufferSize) {
    growMemFile(memfile, addr+addr);
  }
  if(addr > memfile->itsLength) {
    size_t i;
    for(i=memfile->itsLength ; i<addr-1 ; i++) {
      memfile->itsBuffer[i] = 0;
    }
    memfile->itsLength = addr;
  }
  memfile->itsAddress = addr;
}

size_t getLengthMemFile(MemFile *memfile)
{
  return memfile->itsLength;
}

void writeByteMemFile(MemFile *memfile, char v)
{
  if(memfile->itsAddress >= memfile->itsBufferSize) {
    growMemFile(memfile, memfile->itsAddress*2);
  }
  memfile->itsBuffer[memfile->itsAddress++] = v;
  if(memfile->itsAddress >= memfile->itsLength) {
    memfile->itsLength = memfile->itsAddress;
  }
}

void writeWordMemFile(MemFile *memfile, unsigned short v)
{
  char v0 = v / 0x100;
  char v1 = v & 0xFF;
  writeByteMemFile(memfile, v0);
  writeByteMemFile(memfile, v1);
}

void writeLongMemFile(MemFile *memfile, unsigned long v)
{
  unsigned short v0 = (unsigned short)(v >> 16);
  unsigned short v1 = (unsigned short)(v & (0xFFFF));
  writeWordMemFile(memfile, v0);
  writeWordMemFile(memfile, v1);
}

void writeBufferMemFile(MemFile *memfile, void *buffer, size_t length)
{
  if(memfile->itsAddress+length >= memfile->itsBufferSize) {
    growMemFile(memfile, (memfile->itsAddress+length)*2);
  }
  memcpy(&memfile->itsBuffer[memfile->itsAddress],
	 buffer, length);
  memfile->itsAddress += length;
  if(memfile->itsAddress >= memfile->itsLength) {
    memfile->itsLength = memfile->itsAddress;
  }
}

void writeMemFileMemFile(MemFile *memfile, MemFile *m)
{
  writeBufferMemFile(memfile, m->itsBuffer, m->itsLength);
}

int dumpFileMemFile(MemFile *memfile, char *filename)
{
  FILE *f;
  size_t written;

  f = fopen(filename, "wb");
  if(!f) {
    return FALSE;
  }

  written = fwrite(memfile->itsBuffer, 1, memfile->itsLength, f);
  if(written != memfile->itsLength) {
    fclose(f);
    return FALSE;
  }

  fclose(f);

  return TRUE;
}

static int growMemFile(MemFile *memfile, size_t newsize)
{
  char *newbuffer = (char*) realloc(memfile->itsBuffer, newsize);
  if(newbuffer != NULL) {
    memfile->itsBuffer = newbuffer;
    memfile->itsBufferSize = newsize;
    return TRUE;
  }
  return FALSE;
}





