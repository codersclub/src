//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: pdbdec.h 1.1 2001/09/30 10:59:14 obermuhl Exp $
//
// $Log: pdbdec.h $
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef pdbdec_h
#define pdbdec_h


#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

//---------------------------------------------------------------------

#endif

