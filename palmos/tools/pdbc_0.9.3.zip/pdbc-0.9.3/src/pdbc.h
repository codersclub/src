//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: pdbc.h 1.3 2001/11/17 11:27:01 obermuhl Exp $
//
// $Log: pdbc.h $
// Revision 1.3  2001/11/17 11:27:01  obermuhl
// impl resources
//
// Revision 1.2  2001/11/02 21:32:29  obermuhl
// added get/set_double_mode()
//
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef pdbc_h
#define pdbc_h

#include "fileheader.h"

//#define YYDEBUG

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

//---------------------------------------------------------------------

extern char* src_filename;

//---------------------------------------------------------------------

extern FileHeader fileheader;

void begin_file();
void end_file();

void begin_fileheader();
void end_fileheader();

void begin_appinfo();
void end_appinfo();

void begin_sortinfo();
void end_sortinfo();

void begin_record();
void end_record();

void set_record_attrib(unsigned char attrib);
void set_record_id(unsigned long id);
void set_resource_type_id(unsigned long id);
void set_resource_id(unsigned short id);

void begin_data();

void begin_scope();
void end_scope();

void set_base(int b);
int get_base();

void set_size(int s);
int get_size();

void set_padstring(int p);
int get_padstring();

void set_padchar(int p);
int get_padchar();

void set_double_mode(int d);
int get_double_mode();

void write_byte(char v);
void write_word(short v);
void write_long(long v);

void write_number(char *str, int positive, int base, int size);
void write_value(unsigned long ulong, int positive, int size);

void write_string(char *str, int len, int pad, int zeroterminated);
void write_quoted_string(char *str, int pad, int zeroterminated);

void write_double(double v);
void write_float(float v);

unsigned long get_now();
unsigned long get_today();
unsigned long get_date(int year, int month, int day);

unsigned long conv_str_to_ulong(char *str, int base);
unsigned long conv_string_to_id(char *str, int len, int bytes);
unsigned long conv_quoted_string_to_id(char *str, int bytes);
unsigned long conv_4long_to_id(unsigned long v1, 
			       unsigned long v2, 
			       unsigned long v3, 
			       unsigned long v4);


char* un_quote_string(char *str);

void include_binary(char *filename);

//---------------------------------------------------------------------

#endif

