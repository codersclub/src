//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: records.h 1.2 2001/11/17 11:24:04 obermuhl Exp $
//
// $Log: records.h $
// Revision 1.2  2001/11/17 11:24:04  obermuhl
// impl resources
//
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef records_h
#define records_h

#include "memfile.h"
#include "palmfile.h"

typedef struct Record_ {
  unsigned long dataAddr;
  unsigned char attrib;
  unsigned char uniqueId[3];

  char rsrc_typeId[4];
  unsigned short rsrc_id;

  MemFile* itsMemFile;
} Record;

//---------------------------------------------------------------------

Record* newRecord();

int createRecord(Record *record);
int deleteRecord(Record *record);

MemFile* getMemFileRecord(Record *record);

int dumpMemFileRecord(Record *record, MemFile *memfile);
int dumpMemFileResource(Record *record, MemFile *memfile);


//---------------------------------------------------------------------

typedef struct RecordManager_ {
  size_t itsCount;
  size_t itsArraySize;
  Record** itsRecordArray;
} RecordManager;

int createRecordManager(RecordManager *recmgr);
int deleteRecordManager(RecordManager *recmgr);

size_t getCountRecordManager(RecordManager *recmgr);

Record* getRecordRecordManager(RecordManager *recmgr, size_t idx);

Record* newRecordRecordManager(RecordManager *recmgr);


//---------------------------------------------------------------------

#endif
