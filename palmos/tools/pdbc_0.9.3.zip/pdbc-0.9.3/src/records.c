//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: records.c 1.2 2001/11/17 11:23:58 obermuhl Exp $
//
// $Log: records.c $
// Revision 1.2  2001/11/17 11:23:58  obermuhl
// impl resources
//
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include "records.h"
#include "memfile.h"

#include <stdlib.h>
#include <stdio.h>

//---------------------------------------------------------------------

Record* newRecord()
{
  Record *rec = (Record*) malloc(sizeof(Record));
  createRecord(rec);
  return rec;
}

int createRecord(Record *record)
{
  MemFile *memfile = (MemFile*) malloc(sizeof(MemFile));
  createMemFile(memfile);

  record->dataAddr = 0;
  record->attrib = 0;
  record->uniqueId[0] = 0;
  record->uniqueId[1] = 0;
  record->uniqueId[2] = 0;
  record->rsrc_typeId[0] = 0;
  record->rsrc_typeId[1] = 0;
  record->rsrc_typeId[2] = 0;
  record->rsrc_typeId[3] = 0;
  record->rsrc_id = 0;
  record->itsMemFile = memfile;
  return TRUE;
}

int deleteRecord(Record *record)
{
  if(!record) {
    return FALSE;
  }
  if(record->itsMemFile) {
    free(record->itsMemFile);
  }
  record->itsMemFile = NULL;
  return TRUE;
}

MemFile* getMemFileRecord(Record *record)
{
  return record->itsMemFile;
}

int dumpMemFileRecord(Record *record, MemFile *memfile)
{
  writeLongMemFile(memfile, record->dataAddr);
  writeByteMemFile(memfile, record->attrib);
  writeByteMemFile(memfile, record->uniqueId[0]);
  writeByteMemFile(memfile, record->uniqueId[1]);
  writeByteMemFile(memfile, record->uniqueId[2]);
  return TRUE;
}

int dumpMemFileResource(Record *record, MemFile *memfile)
{
  writeByteMemFile(memfile, record->rsrc_typeId[0]);
  writeByteMemFile(memfile, record->rsrc_typeId[1]);
  writeByteMemFile(memfile, record->rsrc_typeId[2]);
  writeByteMemFile(memfile, record->rsrc_typeId[3]);
  writeWordMemFile(memfile, record->rsrc_id);
  writeLongMemFile(memfile, record->dataAddr);
  return TRUE;
}

//---------------------------------------------------------------------

static int growRecordManager(RecordManager *recmgr, size_t newsize);

int createRecordManager(RecordManager *recmgr)
{
  recmgr->itsCount = 0;
  recmgr->itsArraySize = 0;
  recmgr->itsRecordArray = NULL;
  return growRecordManager(recmgr, 16);
}

int deleteRecordManager(RecordManager *recmgr)
{
  if(!recmgr) {
    return FALSE;
  }
  if(recmgr->itsRecordArray) {
    size_t i;
    for(i=0 ; i<recmgr->itsCount ; i++) {
      deleteRecord(recmgr->itsRecordArray[i]);
    }
    free(recmgr->itsRecordArray);
  }
  recmgr->itsCount = 0;
  recmgr->itsArraySize = 0;
  recmgr->itsRecordArray = NULL;
  return TRUE;
}

size_t getCountRecordManager(RecordManager *recmgr)
{
  return recmgr->itsCount;
}

Record* getRecordRecordManager(RecordManager *recmgr, size_t idx)
{
  if(idx>recmgr->itsCount) {
    return NULL;
  }
  return recmgr->itsRecordArray[idx];
}

Record* newRecordRecordManager(RecordManager *recmgr)
{
  size_t idx = recmgr->itsCount++;
  Record *rec;

  if(idx >= recmgr->itsArraySize) {
    growRecordManager(recmgr, idx*2);
  }
  rec = newRecord();
  recmgr->itsRecordArray[idx] = rec;
  return rec;
}

static int growRecordManager(RecordManager *recmgr, size_t newsize)
{
  Record **newbuffer = (Record**) realloc(recmgr->itsRecordArray, newsize*sizeof(Record*));
  if(newbuffer != NULL) {
    recmgr->itsRecordArray = newbuffer;
    recmgr->itsArraySize = newsize;
    return TRUE;
  }
  return FALSE;
}

//---------------------------------------------------------------------





