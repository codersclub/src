//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: pdbc.c 1.5 2002/04/15 06:20:25 obermuhl Exp obermuhl $
//
// $Log: pdbc.c $
// Revision 1.5  2002/04/15 06:20:25  obermuhl
// added is_bigendian()
// use is_bigendian() to swap bytes in double/float
//
// Revision 1.4  2001/11/21 22:23:56  obermuhl
// resource (big improvement)
//
// Revision 1.3  2001/11/17 11:23:28  obermuhl
// impl resources
//
// Revision 1.2  2001/11/02 21:31:57  obermuhl
// added get/set_double_mode()
//
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <math.h>
#include <time.h>

#include "pdbc.h"
#include "error.h"
#include "comperror.h"
#include "records.h"
#include "scope.h"

extern int lineno;
extern char *src_filename;
extern char *progname;

void begin_parser(FILE *in);


#define TEST_CODE

//---------------------------------------------------------------------

char *opt_filename = "out.pdb";
int opt_auto_filename = TRUE;
int opt_regrtest = FALSE;
int opt_resource = FALSE;

//---------------------------------------------------------------------

FileHeader fileheader;

static RecordManager recordManager;
static Record *currentRecord = NULL;
static Record *appinfoRecord = NULL;
static Record *sortinfoRecord = NULL;

//---------------------------------------------------------------------

int is_bigendian()
{
  union {
    short s;
    char c[sizeof(short)];
  } conv;

  conv.s = 0x0001;
  return conv.c[0];
}

int file_exists(const char *filename)
{
  FILE *in = fopen(filename, "r");
  if(in) {
    fclose(in);
    return TRUE;
  }
  return FALSE;
}

char* get_str_record()
{
  if(opt_resource) {
    return "resource";
  } else {
    return "record";
  }
}

char* get_str_Record()
{
  if(opt_resource) {
    return "Resource";
  } else {
    return "record";
  }
}

void begin_file()
{
  createRecordManager(&recordManager);

  if(opt_regrtest) {
    fileheader.creationDate = 0x1111;
    fileheader.modificationDate = 0x2222;
    fileheader.backupDate = 0x3333;
  } else {
    fileheader.creationDate = get_now();
    fileheader.modificationDate = fileheader.creationDate;
    fileheader.backupDate = fileheader.creationDate;
  }
}

void end_file()
{
  MemFile memfile;
  size_t i;
  size_t recCount = getCountRecordManager(&recordManager);
  size_t *recHeaderAddr;
  size_t recHeaderSize;

  if(opt_resource) {
    recHeaderSize = 4+2+4;
  } else {
    recHeaderSize = 4+1+3;
  }

  message(3, "====== Data completely in memory ======");

  createMemFile(&memfile);
  recHeaderAddr = (unsigned*) malloc(recCount * sizeof(size_t));

  // write file header
  message(2, "------ Fileheader ------");
  if(appinfoRecord) {
    fileheader.appInfoArea = sizeof(FileHeader);
    if(recCount > 0) {
      fileheader.appInfoArea += recCount * recHeaderSize;
    } else {
      fileheader.appInfoArea += 2; // filler bytes according to docu
    }
  }
  if(sortinfoRecord) {
    if(appinfoRecord) {
      unsigned long appinfoLen;
      MemFile *recMemfile = getMemFileRecord(appinfoRecord);
      appinfoLen = getLengthMemFile(recMemfile);
      fileheader.sortInfoArea = fileheader.appInfoArea + appinfoLen;
    } else {
      fileheader.sortInfoArea = sizeof(FileHeader);
      if(recCount > 0) {
	fileheader.sortInfoArea += recCount * recHeaderSize;
      } else {
	fileheader.sortInfoArea += 2; // filler bytes according to docu
      }
    }
  }
  fileheader.numRecords = recCount;
  
  message(2, "Fileheader begins at addr %08x", getAddressMemFile(&memfile));
  dumpMemFileFileHeader(&fileheader, &memfile);
  message(2, "Fileheader ends at addr %08x", getAddressMemFile(&memfile));

  // write record headers
  message(2, "------ %sheaders (%d %ss) ------", 
	  get_str_Record(),
	  recCount,
	  get_str_record());
  for(i=0 ; i<recCount ; i++) {
    // write record header[i]
    Record *record = getRecordRecordManager(&recordManager, i);
    recHeaderAddr[i] = getAddressMemFile(&memfile);
    if(opt_resource) {
      message(2, "Resource [%d] header at addr %08x", i, recHeaderAddr[i]);
      message(3, " typeid = %08x", record->rsrc_typeId);
      message(3, " id = %04x", record->rsrc_id);
      dumpMemFileResource(record, &memfile);
    } else {
      message(2, "Record [%d] header at addr %08x", i, recHeaderAddr[i]);
      message(3, " attrib = %02x", record->attrib);
      message(3, " uniqueid = '%c%c%c'", 
	      record->uniqueId[0],
	      record->uniqueId[1],
	      record->uniqueId[2]);
      dumpMemFileRecord(record, &memfile);
    }
  }

  // write filler
  writeWordMemFile(&memfile, 0);

  // write appinfo
  if(appinfoRecord) {
    MemFile *recMemfile = getMemFileRecord(appinfoRecord);
    size_t addr = getAddressMemFile(&memfile);
    message(2, "------ AppInfo ------");
    writeMemFileMemFile(&memfile, recMemfile);
  }
  
  // write sortinfo
  if(sortinfoRecord) {
    MemFile *recMemfile = getMemFileRecord(sortinfoRecord);
    size_t addr = getAddressMemFile(&memfile);
    message(2, "------ SortInfo ------");
    writeMemFileMemFile(&memfile, recMemfile);
  }
  
  // write record data
  message(2, "------ %s data (%d %ss) ------", 
	  get_str_Record(),
	  recCount,
	  get_str_record());
  for(i=0 ; i<recCount ; i++) {
    Record *record = getRecordRecordManager(&recordManager, i);
    MemFile *recMemfile = getMemFileRecord(record);
    size_t addr = getAddressMemFile(&memfile);
    size_t patchAddr = recHeaderAddr[i];
    if(opt_resource) {
      patchAddr += 6; // hack, resources have the address at the end!
    }
    setAddressMemFile(&memfile, patchAddr);
    writeLongMemFile(&memfile, addr); 
    setAddressMemFile(&memfile, addr);   
    message(2, "%s [%d] data at addr %08x", get_str_Record(), i, addr);
    
    writeMemFileMemFile(&memfile, recMemfile);
  }

  message(2, "====== Data linked ======");

  message(1, "Writing %d %s%s into file '%s'.", 
	  recCount,
	  get_str_record(),
	  recCount==1 ? "" : "s",
	  opt_filename);
  dumpFileMemFile(&memfile, opt_filename);
  message(1, "%d bytes written.", memfile.itsLength);

  free(recHeaderAddr);
}

void begin_fileheader()
{
  createFileHeader(&fileheader);
}

void end_fileheader()
{
}

void begin_data()
{
  if(fileheader.attrib & PDB_FILEHEADER_ATTRIB_RSRC) {
    opt_resource = TRUE;
  } else {
    opt_resource = FALSE;
  }

  if(opt_auto_filename) {
    if(opt_resource && !opt_regrtest) {
      opt_filename = "out.prc";
    } else {
      opt_filename = "out.pdb";
    }
  }
}

void begin_appinfo()
{
  message(3, "------ AppInfo ------");

  if(appinfoRecord) {
    compiler_error("Multiple appinfo blocks");
  }

  appinfoRecord = newRecord();
  currentRecord = appinfoRecord;
}

void end_appinfo()
{
  currentRecord = NULL;
}

void begin_sortinfo()
{
  message(3, "------ SortInfo ------");

  if(sortinfoRecord) {
    compiler_error("Multiple sortinfo blocks");
  }
 
  sortinfoRecord = newRecord();
  currentRecord = sortinfoRecord;
}

void end_sortinfo()
{
  currentRecord = NULL;
}

void begin_record()
{
  if(opt_resource) {
    compiler_error("No record allowed in resource file (.prc)");
  }
  message(3, "------ Record ------");
  currentRecord = newRecordRecordManager(&recordManager);
}

void end_record()
{
  message(4, "Record length %d bytes", currentRecord->itsMemFile->itsLength);
  currentRecord = NULL;
}

void begin_resource()
{
  if(!opt_resource) {
    compiler_error("No resource allowed in record file (.pdb)");
  }
  message(3, "------ Resource ------");
  currentRecord = newRecordRecordManager(&recordManager);
}

void end_resource()
{
  message(4, "Resource length %d bytes", currentRecord->itsMemFile->itsLength);
  currentRecord = NULL;
}

void set_record_attrib(unsigned char attrib)
{
  if(!currentRecord) {
    error("Not allowed to set record header settings outside record.");
  } else {
    message(3, "record attrib %02x", attrib);
    currentRecord->attrib = attrib;
  }  
}

void set_record_id(unsigned long id)
{
  if(!currentRecord) {
    error("Not allowed to set record header settings outside record.");
  } else {
    message(3, "record id %04x", id);
    currentRecord->uniqueId[0] = (char) ((id >> 16) & 0xff);
    currentRecord->uniqueId[1] = (char) ((id >> 8) & 0xff);
    currentRecord->uniqueId[2] = (char) (id & 0xff);
  }  
}

void set_resource_type_id(unsigned long id)
{
  if(!currentRecord) {
    error("Not allowed to set resource type id outside resource.");
  } else {
    message(3, "resource type id %04x", id);
    currentRecord->rsrc_typeId[0] = (char) ((id >> 24) & 0xff);
    currentRecord->rsrc_typeId[1] = (char) ((id >> 16) & 0xff);
    currentRecord->rsrc_typeId[2] = (char) ((id >> 8) & 0xff);
    currentRecord->rsrc_typeId[3] = (char) (id & 0xff);
  }  
}

void set_resource_id(unsigned short id)
{
  if(!currentRecord) {
    error("Not allowed to set resource id outside resource.");
  } else {
    message(3, "resource id %02x", id);
    currentRecord->rsrc_id = id;
  }  
}

void begin_scope()
{
  Scope *scope = pushScope();

  message(3, "begin scope (base=%d, size=%d, padstring=%d, padchar=%d)",
	  scope->base,
	  scope->size,
	  scope->padstring,
	  scope->padchar);
}

void end_scope()
{
  Scope *scope = popScope();

  message(3, "end scope (base=%d, size=%d, padstring=%d, padchar=%d)",
	  scope->base,
	  scope->size,
	  scope->padstring,
	  scope->padchar);
}

void set_base(int b)
{
  Scope *scope;
  if(b<2 || b>16) {
    error("Illegal base %d.", b);
  }
  message(3, "base %d", b);

  scope = getCurrentScope();
  scope->base = b;
}

int get_base()
{
  Scope *scope = getCurrentScope();
  return scope->base;
}

void set_size(int s)
{
  Scope *scope;

  if(s!=1 && s!=2 && s!=4) {
    error("Illegal size %d.", s);
  }
  message(3, "size %d", s);

  scope = getCurrentScope();
  scope->size = s;
}

int get_size()
{
  Scope *scope = getCurrentScope();
  return scope->size;
}

void set_padstring(int p)
{
  Scope *scope;

  if(p<0) {
    error("Illegal padstring %d.", p);
  }
  message(3, "padstring %d", p);

  scope = getCurrentScope();
  scope->padstring = p;
}

int get_padstring()
{
  Scope *scope = getCurrentScope();
  return scope->padstring;
}

void set_padchar(int p)
{
  Scope *scope;

  if(p<0) {
    error("Illegal padchar %d.", p);
  }
  message(3, "padchar %d", p);

  scope = getCurrentScope();
  scope->padchar = p;
}

int get_padchar()
{
  Scope *scope = getCurrentScope();
  return scope->padchar;
}

void set_double_mode(int d)
{
  Scope *scope;

  if(d) {
    message(3, "double_mode");
  } else {
    message(3, "float_mode");
  }

  scope = getCurrentScope();
  scope->double_mode = d;
}

int get_double_mode()
{
  Scope *scope = getCurrentScope();
  return scope->double_mode;
}

void write_byte(char v)
{
  if(!currentRecord) {
    error("Not allowed to write data outside record.");
  } else {
    MemFile *memfile = getMemFileRecord(currentRecord);
    message(3, "byte %02x", (unsigned char)v);
    writeByteMemFile(memfile, v);
  }
}

void write_word(short v)
{
  if(!currentRecord) {
    error("Not allowed to write data outside record.");
  } else {
    MemFile *memfile = getMemFileRecord(currentRecord);
    message(3, "word %04x", v);
    writeWordMemFile(memfile, v);
  }
}

void write_long(long v)
{
  if(!currentRecord) {
    error("Not allowed to write data outside record.");
  } else {
    MemFile *memfile = getMemFileRecord(currentRecord);
    message(3, "long %08x", v);
    writeLongMemFile(memfile, v);
  }
}

unsigned long maxvalues[] = { 0, 0xff, 0xffff, 0, 0xffffffff };

void write_number(char *str, int positive, int base, int size)
{
  unsigned long ulong;
  unsigned maxulong;
  int extended = FALSE;
  int oldsize = size;

  ulong = conv_str_to_ulong(str, base);
  message(4, "write_number(%s,%d,%d,%d)", str, positive, base, size);

  maxulong = maxvalues[size];
  while(ulong>maxulong) {
    extended = TRUE;
    size += size;
    maxulong = maxvalues[size];
  }
  if(extended) {
    compiler_warning("'%s' base %d too big for %d byte%s - extended to %d bytes.", 
	    str, base, oldsize, oldsize==1 ? "" : "s", size);
  }

  if(! positive) {
    ulong = 0 - ulong;
  }

  switch(size) {
  case 1 : write_byte((char)ulong); break;
  case 2 : write_word((short)ulong); break;
  case 4 : write_long(ulong); break;
  default : error("Illegal number size %d", size);
  }
}

void write_value(unsigned long ulong, int positive, int size)
{
  message(4, "write_value(%u,%d,%d)", ulong, positive, size);

  if(! positive) {
    ulong = 0 - ulong;
  }

  switch(size) {
  case 1 : write_byte((char)ulong); break;
  case 2 : write_word((short)ulong); break;
  case 4 : write_long(ulong); break;
  default : error("Illegal number size %d", size);
  }
}

void write_string(char *str, int len, int pad, int zeroterminated)
{
  int i;
  int already_terminated = FALSE;
  int normal_char = TRUE;
  int escaped = FALSE;
  int octal_mode = 0;
  int octal_value = 0;
  char c;

  message(4, "write_string(%s,%d,%d,%s-terminated)", 
	  str, len, pad, 
	  zeroterminated ? "zero" : "nonzero");

  for(i=0 ; i<len ; i++) {
    c = str[i];

    normal_char = TRUE;
    if(escaped) {
      normal_char = FALSE;
      escaped = FALSE;
      switch(c) {
      case '\\' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  escaped = TRUE;
	} else {
	  write_byte('\\');
	}
	break;
      case 'a' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\a');
	}
	break;
      case 'b' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\b');
	}
	break;
      case 'f' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\f');
	}
	break;
      case 'n' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\n');
	}
	break;
      case 'r' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\r');
	}
	break;
      case 't' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\t');
	}
	break;
      case 'v' :
        if(octal_mode) {
          write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	  normal_char = TRUE;
	} else {
	  write_byte('\v');
	}
	break;
      case '0' :
      case '1' :
      case '2' :
      case '3' :
      case '4' :
      case '5' :
      case '6' :
      case '7' :
	octal_mode++;
	octal_value = octal_value*8 + (int)(c-'0');
	if(octal_mode == 3) {
	  write_byte((char)octal_value);
	  octal_mode = 0;
	  octal_value = 0;
	} else {
	  escaped = TRUE;
	}
	break;
      default :
        if(octal_mode) {
          write_byte((char)octal_value);
          normal_char = TRUE;
        } else {
          write_byte(c);
        }
      }
    }
    if(normal_char) {
      if(c == '\\') {
        escaped = TRUE;
        octal_mode = 0;
        octal_value = 0;
      } else {
        write_byte(c);
      }
    }
    
    if(c == 0) {
      already_terminated = TRUE;
    }
  }

  if(escaped) {
    if(octal_mode) {
      write_byte((char)octal_value);
    } else {
      write_byte('\\'); // ambiguous? last char an escape
    }
  }
  if(zeroterminated && !already_terminated) {
    write_byte(0);
    len++;
  }
  if(len>pad && pad != 0) {
    compiler_warning("String '%s' too long for padding to %d bytes", 
	    str, pad);
  }
  for(i=len ; i<pad ; i++) {
    write_byte(0);
  }
}


  
/*
void write_string(char *str, int len, int pad, int zeroterminated)
{
  int i;
  int already_terminated = FALSE;

  message(4, "write_string(%s,%d,%d,%s-terminated)", 
	  str, len, pad, 
	  zeroterminated ? "zero" : "nonzero");

  for(i=0 ; i<len ; i++) {
    write_byte(str[i]);
    if(str[i] == 0) {
      already_terminated = TRUE;
    }
  }
  if(zeroterminated && !already_terminated) {
    write_byte(0);
    len++;
  }
  if(len>pad && pad != 0) {
    compiler_warning("String '%s' too long for padding to %d bytes", 
	    str, pad);
  }
  for(i=len ; i<pad ; i++) {
    write_byte(0);
  }
}
*/

void write_quoted_string(char *str, int pad, int zeroterminated)
{
  write_string(str+1, strlen(str)-2, pad, zeroterminated);
}

void write_double(double v)
{
  union {
    double d;
    char c[sizeof(double)];
  } conv;
  int i;

  message(4, "write_double(%lg)", v);
  conv.d = v;
  if(is_bigendian()) {
    for(i=sizeof(double)-1 ; i>=0 ; i--) {
      char c = conv.c[i];
      write_byte(c);
    }
  } else {
    for(i=0 ; i<sizeof(double) ; i++) {
      char c = conv.c[i];
      write_byte(c);
    }
  }
}

void write_float(float v)
{
  union {
    float f;
    char c[sizeof(float)];
  } conv;
  int i;

  message(4, "write_float(%g)", v);
  conv.f = v;
  if(is_bigendian()) {
    for(i=sizeof(float)-1 ; i>=0 ; i--) {
      char c = conv.c[i];
      write_byte(c);
    }
  } else {
    for(i=0 ; i<sizeof(float) ; i++) {
      char c = conv.c[i];
      write_byte(c);
    }
  }
}

unsigned long get_now()
{
  time_t t = time(NULL);
  return t + 2082844800;
}

unsigned long get_today()
{
  struct tm *now;
  time_t t = time(NULL);
  now = gmtime(&t);
  t -= ((now->tm_hour * 60) + now->tm_min) * 60 + now->tm_sec;
  return t + 2082844800;
}

unsigned long get_date(int year, int month, int day)
{
  struct tm d;
  time_t t;

  d.tm_isdst = -1;
  d.tm_year = year - 1900;
  d.tm_mon = month - 1;
  d.tm_mday = day;
  d.tm_hour = 0;
  d.tm_min = 0;
  d.tm_sec = 0;
  
  t = mktime(&d);
  if(t) {
    return t + 2082844800;
  } else {
    compiler_warning("Could not compute date %04d/%02d/%02d", year, month, day);
    return get_today();
  }
}

unsigned long conv_str_to_ulong(char *str, int base)
{
  int i=strlen(str)-1;
  unsigned long factor = 1;
  unsigned long res = 0;

  message(5, "conv_str_to_ulong(%s, %d)", str, base);

  while(i>=0) {
    unsigned long v;
    char c = str[i--];
    if(c>='0' && c<='9') {
      v = c - '0';
    } else if(c>='A' && c<='Z') {
      v = c - 'A' + 10;
    } else if(c>='a' && c<='z') {
      v = c - 'a' + 10;
    } else {
      compiler_error("Illegal character '%c' (=0x%02x) in '%s' base %d", 
	    c, c, str, base);
    }
    if(v>base) {
      compiler_error("Illegal digit '%c' in '%s' base %d", 
	    c, str, base);
    }
    
    res += v * factor;
    factor *= base;
  }

  return res;
}

unsigned long conv_string_to_id(char *str, int len, int bytes)
{
  unsigned long v;
  int i;

  if(len > bytes) {
    len = bytes;
  }
  v = 0;
  for(i=0 ; i<len ; i++) {
    v <<= 8;
    v += str[i];
  }

  return v;
}

unsigned long conv_quoted_string_to_id(char *str, int bytes)
{
  return conv_string_to_id(str+1, strlen(str)-2, bytes);
}

unsigned long conv_4long_to_id(unsigned long v1, 
			       unsigned long v2, 
			       unsigned long v3, 
			       unsigned long v4)
{
  v1 &= 0xff;
  v2 &= 0xff;
  v3 &= 0xff;
  v4 &= 0xff;

  return (((((v1 << 8) + v2) << 8) + v3) << 8) + v4;
}

char* un_quote_string(char *str)
{ 
  int len;
  char *result = strdup(str);
  char quote;

  len = strlen(result);

  if(result[0] == '"' || result[0] == '\'') {
	quote = result[0];
	if(result[len-1] == quote) {
      result[len-1] = '\0';
      result++;
	}
  }
  return result;
}

void include_binary(char *filename)
{
  FILE *f = fopen(filename, "rb");
  int c;
  if(!f) {
    error("Could not open binary include file '%s' for binary include.", filename);
  }
  message(1, "Including binary file: %s", filename);
  
  while((c = fgetc(f)) != EOF) {
    write_byte((char)c);
  }

  fclose(f);
}

//---------------------------------------------------------------------

void run_pdbc(char *filename)
{
  FILE *in = fopen(filename, "r");
  if(!in) {
    error("Could not open source file '%s'.", filename);
  }

  if(opt_regrtest) {
    src_filename = "infile";
  } else {
    src_filename = filename;
  }
  begin_parser(in);
  fclose(in);
}

//---------------------------------------------------------------------

void copy_template(FILE *in, FILE *out)
{
  char line[10240];
  while(fgets(line, 10240, in)) {
    fprintf(out, "%s", line);
  }
}


void create_template_pdbc(const char *filename, const char *template_name)
{
  FILE *out = stdout;
  FILE *in = NULL;
  char tpl_filename[2048];

  if(filename) {
    if(file_exists(filename)) {
      error("Output source file exists already '%s'.", filename);
    }

    out = fopen(filename, "w");
    if(!out) {
      error("Could not open output source file '%s'.", filename);
    }
  }

  if(getenv("PDBC_DIR")) {
    strcpy(tpl_filename, getenv("PDBC_DIR"));
  } else {
    strcpy(tpl_filename, "");
  }
  strcat(tpl_filename, "/lib/pdbc/templates/");
  strcat(tpl_filename, template_name);
  if(!file_exists(tpl_filename)) {
    strcat(tpl_filename, ".pdt");
  }
  in = fopen(tpl_filename, "r");
  if(!in) {
    error("Could not find template file '%s'.", tpl_filename);
  }

  if(filename) {
    message(1, "Creating source file '%s' from template '%s'.", filename, template_name);
  }

  copy_template(in, out);

  if(out && out != stdout) {
    fclose(out);
  }
  if(in) {
    fclose(in);
  }
}

//---------------------------------------------------------------------

void print_help()
{
  printf("NAME\n"
	 "    pdbc -- palm database compiler\n"
	 "\n"
	 "SYNOPSYS\n"
         "    pdbc [-h -V -W -o file -w[01] -v[0-4]] file\n"
	 "\n"
	 "OPTIONS\n"
	 "    -h              This help text\n"
	 "    -v0             Verbose: off\n"
	 "    -v1             Verbose: normal level (default)\n"
	 "    -v2             Verbose: more info\n"
	 "    -v3             Verbose: a lot of info\n"
	 "    -v4             Verbose: way too much info\n"
	 "    -V              Version information\n"
	 "    -w0             Supress warnings\n"
	 "    -w1             Don't supress warnings (default)\n"
	 "    -W              Treat warnings as errors\n"
	 "    -o file         Output file\n"
	 "\n"
	 "DIAGNOSTICS\n"
	 "    Possible exit status values:\n"
	 "    0 Successful completion\n"
	 "    1 Missing sourcefile arg\n"
	 "    2 Unknown commandline option\n"
	 "    3 Commandline option error (e.g. missing option arg)\n"
	 "    4 Misc errors (e.g. fopen, ...)\n"
	 "    5 Compiler error in source file\n"
	 "\n"
	 "BUGS\n"
	 "    Check file known_bugs.txt in the distribution.\n"
	 "    Error reports to: eric@obermuhlner.com\n"
	 "\n");
}

//---------------------------------------------------------------------

void print_usage()
{
  fprintf(stderr, "Usage: pdbc [-h -V -W -o file -w[01] -v[0-4]] file\n");
}

//---------------------------------------------------------------------

void print_version()
{
  printf("pdbc 0.9.3\n");
}

//---------------------------------------------------------------------

#ifdef TEST_CODE

void test_conv_quoted_string_to_id(char *str, int bytes)
{
  printf("conv_quoted_string_to_id(%s, %d) => %08x\n", 
	 str, bytes, conv_quoted_string_to_id(str, bytes));
}

void test_conv_4long_to_id(unsigned long v1, 
			       unsigned long v2, 
			       unsigned long v3, 
			       unsigned long v4)
{
	printf("conv_4long_to_id(%ld, %ld, %ld, %ld) => %08x\n",
		v1, v2, v3, v4, conv_4long_to_id(v1, v2, v3, v4));
}

void test1()
{
  test_conv_quoted_string_to_id("'ABCDXXX'", 4);
  test_conv_quoted_string_to_id("'ABCD'", 4);
  test_conv_quoted_string_to_id("'ABCD'", 3);
  test_conv_quoted_string_to_id("'ABCD'", 2);
  test_conv_quoted_string_to_id("'ABCD'", 1);
  test_conv_quoted_string_to_id("'A'", 4);
  test_conv_quoted_string_to_id("'A'", 3);
  test_conv_quoted_string_to_id("'A'", 2);
  test_conv_quoted_string_to_id("'A'", 1);
}

void test2()
{
  test_conv_4long_to_id(1, 2, 3, 4);
  test_conv_4long_to_id(0, 2, 3, 4);
}


void test4()
{
}

void test_code()
{
}
#endif

	      
//---------------------------------------------------------------------

int main(int argc, char *argv[])
{
  int i;
  int parsing_options = TRUE;
  char* template_name = NULL;
  char *optarg;

  progname = "pdbc";

  i = 1;
  while(i<argc && parsing_options) {
    if(argv[i][0] == '-') {
#ifdef TEST_CODE
      if(optarg = parse_option(argc, argv, &i, 'T', "--test-code", 0)) {
	test_code();
#endif
      } else if(optarg = parse_option(argc, argv, &i, 'h', "--help", 0)) {
	print_help();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, '?', "--help", 0)) {
	print_help();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, 'V', "--version", 0)) {
	print_version();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, 'v', "--verbose", 1)) {
	set_verbose_level(optarg[0]);
      } else if(optarg = parse_option(argc, argv, &i, 'w', "--warnings", 1)) {
	set_warning_level(optarg[0]);
      } else if(optarg = parse_option(argc, argv, &i, 'W', "--strict", 0)) {
	set_warning_as_errors(TRUE);
      } else if(optarg = parse_option(argc, argv, &i, 'R', "--regrtest", 0)) {
	opt_regrtest = 1;
      } else if(optarg = parse_option(argc, argv, &i, 'o', "--out", 1)) {
	opt_filename = optarg;
	opt_auto_filename = FALSE;
      } else if(optarg = parse_option(argc, argv, &i, 't', "--template", 1)) {
	template_name = optarg;
      } else if(optarg = parse_option(argc, argv, &i, '-', "--end-args", 0)) {
	parsing_options = FALSE;
      } else {
	fprintf(stderr, "Unknown option %s\n", argv[i]);
	print_usage();
	exit(2);
      }
    } else {
      parsing_options = FALSE;
    }
  }

  if(i==argc-1) {
    if(template_name) {
      create_template_pdbc(argv[i], template_name);
    } else {
      run_pdbc(argv[i]);
    }
  } else {
    if(template_name) {
      create_template_pdbc(NULL, template_name);
    } else {
      print_usage();
      exit(1);
    }
  }
 return 0;
}

//---------------------------------------------------------------------
