//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: scope.h 1.2 2001/11/02 21:32:22 obermuhl Exp $
//
// $Log: scope.h $
// Revision 1.2  2001/11/02 21:32:22  obermuhl
// added double_mode
//
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef scope_h
#define scope_h

typedef struct Scope_ {
  int base;
  int size;
  int padstring;
  int padchar;
  int double_mode;

  struct Scope_ *prev;
  struct Scope_ *next;
} Scope;

extern Scope rootScope;


Scope* pushScope();
Scope* popScope();

Scope* getCurrentScope();

#endif
