%{

//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: lexer.flex 1.6 2002/04/15 06:19:48 obermuhl Exp $
//
// $Log: lexer.flex $
// Revision 1.6  2002/04/15 06:19:48  obermuhl
// allow +/- before double/float
//
// Revision 1.5  2001/11/21 22:21:41  obermuhl
// unsuccessful attempt to fix backslash problem at end of string
//
// Revision 1.4  2001/11/12 23:00:01  obermuhl
// added resource,stream,hidden (fileheader attrib flags)
// added created,modified,backuped (synonyms for dates)
//
// Revision 1.3  2001/11/02 21:31:14  obermuhl
// added keywords 'double' and 'float' to handle default real values
//
// Revision 1.2  2001/09/30 19:16:47  obermuhl
// added c-style comments
//
// Revision 1.1  2001/09/30 10:58:36  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "pdbc.h"
#include "error.h"
#include "comperror.h"
#include "parser.tab.h"

int lineno;
char *src_filename;

int get_linenumber();


#define YY_DECL int wrapped_yylex()
int yylex();

#define MAX_INCLUDE_DEPTH 64

typedef struct IncludeInfo_ {
	YY_BUFFER_STATE state;
	int lineno;
	char *filename;
} IncludeInfo;

IncludeInfo include_stack[MAX_INCLUDE_DEPTH];
int include_stack_idx = 0;

void eat_c_comment();

void start_include(char *filename);
int end_include();

//#define STRING(s) strdup(s)
#define STRING(s) s

%}

%x incl
%x inclbin

bindigit		[0-1]
decdigit		[0-9]
octdigit		[0-7]
hexdigit		[0-9A-Fa-f]

alpha			[A-Za-z]
alnum			[A-Za-z0-9]
id			[A-Za-z_]		
idnum			[A-Za-z_0-9]

dec4			[0-9][0-9][0-9][0-9]
dec2			[0-9][0-9]

%%

fnord			{ return TOK_FNORD; }

file			{ return TOK_FILE; }
appinfo			{ return TOK_APPINFO; }
sortinfo		{ return TOK_SORTINFO; }
record			{ return TOK_RECORD; }
begin			{ return TOK_BEGIN; }
end			{ return TOK_END; }
error			{ return TOK_USER_ERROR; }
warning			{ return TOK_USER_WARNING; }
message			{ return TOK_USER_MESSAGE; }

filename		{ return TOK_FILENAME; }
attrib			{ return TOK_ATTRIB; }
recordid		{ return TOK_RECORDID; }
id			{ return TOK_ID; }
version			{ return TOK_VERSION; }
creation_date		{ return TOK_CREATION_DATE; }
modification_date	{ return TOK_MODIFICATION_DATE; }
backup_date		{ return TOK_BACKUP_DATE; }
created			{ return TOK_CREATION_DATE; }
modified		{ return TOK_MODIFICATION_DATE; }
backuped		{ return TOK_BACKUP_DATE; }
modification		{ return TOK_MODIFICATION; }
typeid			{ return TOK_TYPEID; }
creatorid		{ return TOK_CREATORID; }
uniqueid_seed		{ return TOK_UNIQUEID_SEED; }

readonly		{ return TOK_READONLY; }
resource		{ return TOK_RESOURCE; }
dirty			{ return TOK_DIRTY; }
backup			{ return TOK_BACKUP; }
newer			{ return TOK_NEWER; }
reset			{ return TOK_RESET; }
nobeam			{ return TOK_NOBEAM; }
stream			{ return TOK_STREAM; }
hidden			{ return TOK_HIDDEN; }

now			{ return TOK_NOW; }
today			{ return TOK_TODAY; }

secret			{ return TOK_SECRET; }
busy			{ return TOK_BUSY; }
delete			{ return TOK_DELETE; }
category		{ return TOK_CATEGORY; }

bin			{ return TOK_BIN; }
oct			{ return TOK_OCT; }
dec			{ return TOK_DEC; }
hex			{ return TOK_HEX; }
base			{ return TOK_BASE; }

byte			{ return TOK_BYTE; }
word			{ return TOK_WORD; }
long			{ return TOK_LONG; }
size			{ return TOK_SIZE; }

padstring		{ return TOK_PADSTRING; }
padchar			{ return TOK_PADCHAR; }

double			{ return TOK_DOUBLE; }
float			{ return TOK_FLOAT; }

signed			{ return TOK_SIGNED; }
unsigned		{ return TOK_UNSIGNED; }

==			{ return TOK_OP_EQUAL; }
!=			{ return TOK_OP_UNEQUAL; }
\<			{ return TOK_OP_LT; }
\<=			{ return TOK_OP_LE; }
\>			{ return TOK_OP_GT; }
\>=			{ return TOK_OP_GE; }
\<\<			{ return TOK_OP_SHL; }
\>\>			{ return TOK_OP_SHR; }


{hexdigit}+		{ yylval.sval=STRING(yytext); return TOK_MAYBE_HEXNUMBER; }
[+-]?{decdigit}*\.{decdigit}+[eE]?[+-]?{decdigit}*	{ sscanf(yytext, "%lf", &yylval.dval); return TOK_REALNUMBER; }
[+-]?{decdigit}*\.{decdigit}+[eE]?[+-]?{decdigit}*[dD]	{ sscanf(yytext, "%lf", &yylval.dval); return TOK_DOUBLENUMBER; }
[+-]?{decdigit}*\.{decdigit}+[eE]?[+-]?{decdigit}*[fF]	{ sscanf(yytext, "%f", &yylval.fval); /*FNORD*/  return TOK_FLOATNUMBER; }

{bindigit}+_b		{ yylval.sval=STRING(yytext); return TOK_BINNUMBER; }
{octdigit}+_o		{ yylval.sval=STRING(yytext); return TOK_OCTNUMBER; }
{decdigit}+_d		{ yylval.sval=STRING(yytext); return TOK_DECNUMBER; }
{hexdigit}+_[hx]	{ yylval.sval=STRING(yytext); return TOK_HEXNUMBER; }

{dec4}\/{dec2}\/{dec2}	{ yylval.sval=STRING(yytext); return TOK_DATE; }

\/\/.*$

\/\*			{ eat_c_comment(); }

\"(\\\"|\\\\|[^"])*\"		{ yylval.sval=STRING(yytext); return TOK_STRING; }
\'(\\\'|\\\\|[^'])*\'		{ yylval.sval=STRING(yytext); return TOK_CHAR; }

include			BEGIN(incl);
includebin		BEGIN(inclbin);

<incl>[ \t]*
<incl>[^ \t\r\n]+		{ start_include(un_quote_string(yytext)); }

<<EOF>>			{ if(end_include()) yyterminate(); }

<inclbin>[ \t]*
<inclbin>[^ \t\r\n]+	{ include_binary(un_quote_string(yytext)); BEGIN(INITIAL); }

[ \t]

\r\n			{ lineno++; }
\n			{ lineno++; }

.			{ return yytext[0]; }


%%

int yywrap()
{	
	return 1;
}

int get_linenumber()
{
	return lineno;
}

int yylex()
{
	int tok = wrapped_yylex();
	message(5, "token %d = '%s' at line %d", 
		tok, yytext, get_linenumber());
	return tok;
}

void eat_c_comment()
{
  int c;
  int start_lineno = lineno;

  for(;;) {
    while((c = input()) != '*' && c != EOF) {
      // eating comment
      if(c=='\n') {
        lineno++;
      }
    }
    if(c == '*') {
      while((c = input()) == '*') {
        // eating '*'
      }
      if(c == '/') {
        break; // finished comment
      }
    }
    if(c == EOF) {
      error("Unterminated comment starting at line %d", start_lineno);
      break;
    }
  }
}

void start_include(char *filename)
{ 
  if(include_stack_idx >= MAX_INCLUDE_DEPTH ) {
    error("Includes nested too deeply (%d)", include_stack_idx);
  }

  include_stack[include_stack_idx].state = YY_CURRENT_BUFFER;
  include_stack[include_stack_idx].lineno = lineno;
  include_stack[include_stack_idx].filename = src_filename;
  include_stack_idx++;

  lineno = 1;
  src_filename = strdup(filename);

  yyin = fopen( filename, "r" ); 
  if(!yyin) {
    error( "Failed to open include file %s", filename);
  }
  message(1, "Including file: %s", filename);
  
  yy_switch_to_buffer(yy_create_buffer( yyin, YY_BUF_SIZE ) );
  
  BEGIN(INITIAL);
}

int end_include()
{
  if ( --include_stack_idx < 0 ) {
    return 1;
  } else {
    yy_delete_buffer( YY_CURRENT_BUFFER );
    yy_switch_to_buffer( include_stack[include_stack_idx].state );
    lineno = include_stack[include_stack_idx].lineno;
    src_filename = include_stack[include_stack_idx].filename;
  }
  return 0;
}





