//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: memfile.h 1.1 2001/09/30 10:59:14 obermuhl Exp $
//
// $Log: memfile.h $
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef memfile_h
#define memfile_h

#include <stdlib.h>

//---------------------------------------------------------------------

#ifndef TRUE
#define TRUE 1
#endif

#ifndef FALSE
#define FALSE 0
#endif

//---------------------------------------------------------------------

typedef struct MemFile_ {
  char *itsBuffer;
  size_t itsBufferSize;
  size_t itsLength;
  size_t itsAddress;
} MemFile;


int createMemFile(MemFile *memfile);
int deleteMemFile(MemFile *memfile);

size_t getAddressMemFile(MemFile *memfile);
void setAddressMemFile(MemFile *memfile, size_t addr);

size_t getLengthMemFile(MemFile *memfile);

void writeByteMemFile(MemFile *memfile, char v);
void writeWordMemFile(MemFile *memfile, unsigned short v);
void writeLongMemFile(MemFile *memfile, unsigned long v);
void writeBufferMemFile(MemFile *memfile, void *buffer, size_t length);
void writeMemFileMemFile(MemFile *memfile, MemFile *m);

int dumpFileMemFile(MemFile *memfile, char *filename);

//---------------------------------------------------------------------

#endif

