%{

//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: parser.y 1.5 2001/11/21 22:22:38 obermuhl Exp $
//
// $Log: parser.y $
// Revision 1.5  2001/11/21 22:22:38  obermuhl
// resource block uses begin_resource()/end_resource()
// use TOK_ID for resources (with decimal value)
//
// Revision 1.4  2001/11/17 11:26:44  obermuhl
// impl resources
//
// Revision 1.3  2001/11/12 23:00:29  obermuhl
// added resource,stream,hidden (fileheader attributes)
//
// Revision 1.2  2001/11/02 21:31:24  obermuhl
// added keywords 'double' and 'float' to handle default real values
//
// Revision 1.1  2001/09/30 10:58:36  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <malloc.h>

#include "pdbc.h"
#include "error.h"
#include "comperror.h"

#define YYDEBUG 1
//#define YYERROR_VERBOSE

int yylex();
void yyrestart(FILE *input_file);
void yyerror(char *msg);
extern char *yytext;

int get_linenumber();
extern int lineno;

%}

%union {
unsigned long lval;
double dval;
float fval;
char *sval;
}



%token TOK_FNORD

%token TOK_FILE
%token TOK_APPINFO
%token TOK_SORTINFO
%token TOK_RECORD
%token TOK_BEGIN
%token TOK_END

%token TOK_USER_ERROR
%token TOK_USER_WARNING
%token TOK_USER_MESSAGE

//file settings
%token TOK_FILENAME
%token TOK_ATTRIB
%token TOK_VERSION
%token TOK_CREATION_DATE
%token TOK_MODIFICATION_DATE
%token TOK_BACKUP_DATE
%token TOK_MODIFICATION
%token TOK_TYPEID
%token TOK_CREATORID
%token TOK_UNIQUEID_SEED

//%token TOK_APPINFO
//%token TOK_SORTINFO

//file attribs
%token TOK_RESOURCE
%token TOK_READONLY
%token TOK_DIRTY
%token TOK_BACKUP
%token TOK_NEWER
%token TOK_RESET
%token TOK_NOBEAM
%token TOK_STREAM
%token TOK_HIDDEN

%token TOK_NOW
%token TOK_TODAY

%token TOK_RECORDID
%token TOK_ID

//record attribs
%token TOK_SECRET
%token TOK_BUSY
%token TOK_DELETE
%token TOK_CATEGORY

%token TOK_BIN
%token TOK_OCT
%token TOK_DEC
%token TOK_HEX
%token TOK_BASE

%token TOK_BYTE
%token TOK_WORD
%token TOK_LONG
%token TOK_SIZE

%token TOK_PADSTRING
%token TOK_PADCHAR

%token TOK_DOUBLE
%token TOK_FLOAT

%token TOK_SIGNED
%token TOK_UNSIGNED

%token TOK_OP_EQUAL
%token TOK_OP_UNEQUAL
%token TOK_OP_LT
%token TOK_OP_LE
%token TOK_OP_GT
%token TOK_OP_GE
%token TOK_OP_SHL
%token TOK_OP_SHR

%token <sval> TOK_MAYBE_HEXNUMBER

%token <dval> TOK_REALNUMBER
%token <dval> TOK_DOUBLENUMBER
%token <fval> TOK_FLOATNUMBER

%token <sval> TOK_BINNUMBER
%token <sval> TOK_OCTNUMBER
%token <sval> TOK_DECNUMBER
%token <sval> TOK_HEXNUMBER

%token <sval> TOK_STRING
%token <sval> TOK_CHAR

%token <sval> TOK_DATE

%type <sval> long_value
%type <dval> real_value
%type <dval> double_value
%type <fval> float_value
%type <sval> string_value
%type <sval> char_value
%type <sval> string_or_char_value

%type <lval> file_attrib_flag
%type <lval> seq_file_attrib_flag
%type <lval> seq_file_attrib_flag1
%type <lval> record_attrib_flag
%type <lval> seq_record_attrib_flag
%type <lval> seq_record_attrib_flag1
%type <lval> datetime_value
%type <lval> date_value
%type <lval> time_value
%type <lval> dec_value
%type <lval> hex_value
%type <lval> based_value
%type <lval> record_id
%type <lval> resource_id       //FNORD_should_be_short

%type <sval> filename_literal
%type <lval> id_literal

%type <lval> expr
%type <lval> condex
%type <lval> orex
%type <lval> xorex
%type <lval> andex
%type <lval> eqex
%type <lval> relex
%type <lval> shiftex
%type <lval> arith
%type <lval> term
%type <lval> factor
%type <lval> prim
%type <lval> nested

%%

compilation_unit
	: file_decl
	;

file_decl
	: TOK_FILE 
		{ begin_file(); }
	  fileheader_decl 
	  TOK_BEGIN  
		{ begin_data(); begin_scope(); }
          seq_chunk_decl 
	  TOK_END 
		{ end_scope(); }
          ';'
		{ end_file(); }
	;

fileheader_decl
	: seq_fileheader_settings
	;

seq_fileheader_settings
	: seq_fileheader_settings fileheader_settings
	|
	;

fileheader_settings
	: TOK_FILENAME '=' filename_literal
		{ setFilenameFileHeader(&fileheader, $3);  }
	  ';'
	| TOK_ATTRIB '=' seq_file_attrib_flag
		{ fileheader.attrib = (unsigned short)($3); }
	  ';'
	| TOK_VERSION '=' hex_value
		{ fileheader.version = (unsigned short)($3); }
	  ';'
	| TOK_CREATION_DATE '=' datetime_value
		{ fileheader.creationDate = $3; 
		message(3, "creation_date = %lu (%08x_x)", $3, $3); 
		}
	  ';'
	| TOK_MODIFICATION_DATE '=' datetime_value
		{ fileheader.modificationDate = $3; 
		message(3, "modification_date = %lu (%08x_x)", $3, $3); 
		}
	  ';'
	| TOK_BACKUP_DATE '=' datetime_value
		{ fileheader.backupDate = $3; 
		message(3, "backup_date = %lu (%08x_x)", $3, $3); 
		}
	  ';'
	| TOK_MODIFICATION '=' hex_value
		{ fileheader.modNumber = $3; }
	  ';'
	| TOK_TYPEID '=' id_literal
		{ setTypeIdFileHeader(&fileheader, $3);  }
	  ';'
	| TOK_CREATORID '=' id_literal
		{ setCreatorIdFileHeader(&fileheader, $3);  }
	  ';'
	| TOK_UNIQUEID_SEED '=' hex_value
		{ fileheader.uniqueIdSeed = $3; }
	  ';'
	| ';'
	| user_message
	;

filename_literal
	: TOK_STRING
	| TOK_CHAR
	;

id_literal
	: hex_value
		{ $$ = $1; }
	| '{' hex_value hex_value hex_value hex_value '}'
		{ $$ = conv_4long_to_id($2, $3, $4, $5);  }
	| char_value
		{ $$ = conv_quoted_string_to_id($1, 4);  }
	;

seq_file_attrib_flag
	: seq_file_attrib_flag1
		{ $$ = $1; }
	|
		{ $$ = 0x0000; }
	;

seq_file_attrib_flag1
	: seq_file_attrib_flag1 '|' file_attrib_flag
		{ $$ = $1 | $3; }
	| seq_file_attrib_flag1 '+' file_attrib_flag
		{ $$ = $1 + $3; }
	| file_attrib_flag
		{ $$ = $1; }
	;

file_attrib_flag
	: hex_value
		{ $$ = $1; }
	| TOK_RESOURCE
		{ $$ = 0x0001; }
	| TOK_READONLY
		{ $$ = 0x0002; }
	| TOK_DIRTY
		{ $$ = 0x0004; }
	| TOK_BACKUP
		{ $$ = 0x0008; }
	| TOK_NEWER
		{ $$ = 0x0010; }
	| TOK_RESET
		{ $$ = 0x0020; }
	| TOK_NOBEAM
		{ $$ = 0x0040; }
	| TOK_STREAM
		{ $$ = 0x0080; }
	| TOK_HIDDEN
		{ $$ = 0x0100; }
	;

datetime_value
	: hex_value
		{ $$ = $1; }
	| TOK_NOW
		{ $$ = get_now(); }
	| date_value
		{ $$ = $1; }
	| date_value time_value
		{ $$ = $1 + $2; }
	;

date_value
	: TOK_DATE
		{ int y,m,d; sscanf($1, "%d/%d/%d", &y, &m, &d); $$ = get_date(y,m,d); }
	| TOK_TODAY
		{ $$ = get_today(); }
	;

time_value
	: dec_value ':' dec_value ':' dec_value
		{ $$ = ($1*60 + $3)*60 + $5; }
	;

seq_chunk_decl
	: seq_chunk_decl chunk_decl
	|
	;

chunk_decl
	: appinfo_decl
	| sortinfo_decl
	| record_decl
	| resource_decl
	;

appinfo_decl
	: TOK_APPINFO
		{ begin_appinfo(); }
	  record_block ';'
		{ end_appinfo(); }
	;

sortinfo_decl
	: TOK_SORTINFO
		{ begin_sortinfo(); }
	  record_block ';'
		{ end_sortinfo(); }
	;

record_decl
	: TOK_RECORD
		{ begin_record(); }
	  seq_record_setting
	  record_block ';'
		{ end_record(); }
	;

resource_decl
	: TOK_RESOURCE
		{ begin_resource(); }
	  seq_resource_setting
	  record_block ';'
		{ end_resource(); }
	;

seq_record_setting
	: seq_record_setting record_setting
	|
	;

record_setting
	: TOK_ATTRIB '=' seq_record_attrib_flag
		{ set_record_attrib((char) $3); }
	  ';'
	| TOK_RECORDID '=' record_id
		{ set_record_id($3); }
	  ';'
	| ';'
	| user_message
	;

seq_record_attrib_flag
	: seq_record_attrib_flag1
		{ $$ = $1; }
	|
		{ $$ = 0x00; }
	;

seq_record_attrib_flag1
	: seq_record_attrib_flag1 '|' record_attrib_flag
		{ $$ = $1 | $3; }
	| seq_record_attrib_flag1 '+' record_attrib_flag
		{ $$ = $1 + $3; }
	| record_attrib_flag
		{ $$ = $1; }
	;

record_attrib_flag
	: hex_value
		{ $$ = $1; }
	| TOK_SECRET
		{ $$ = 0x10; }
	| TOK_BUSY
		{ $$ = 0x20; }
	| TOK_DIRTY
		{ $$ = 0x40; }
	| TOK_DELETE
		{ $$ = 0x80; }
	| TOK_CATEGORY '(' dec_value ')'
		{ $$ = $3; }
	;

record_id
	: hex_value
		{ $$ = $1; }
	| '{' hex_value hex_value hex_value '}'
		{ $$ = conv_4long_to_id(0, $2, $3, $4); }
	| char_value
		{ $$ = conv_quoted_string_to_id($1, 3); }
	;

seq_resource_setting
	: seq_resource_setting resource_setting
	|
	;

resource_setting
	: TOK_TYPEID '=' id_literal
		{ set_resource_type_id($3); }
	  ';'
	| TOK_ID '=' resource_id
		{ set_resource_id((unsigned short)$3); }
	  ';'
	| ';'
	| user_message
	;

resource_id
	: dec_value
		{ $$ = $1; }
	| '{' hex_value hex_value '}'
		{ $$ = conv_4long_to_id(0, 0, $2, $3); }
	| char_value
		{ $$ = conv_quoted_string_to_id($1, 2); }
	;

record_block
        : TOK_BEGIN
		{ begin_scope(); }
          seq_record_data 
          TOK_END
		{ end_scope(); }
        ;

seq_record_data
        : seq_record_data record_data
        |
        ;

record_data
        : data
        | record_block
        ;

data
	: data_state_command
	| data_value
	| user_message
	;

data_state_command
	: data_base_command
	| data_size_command
	| data_pad_command
	| data_double_command
	| data_float_command
	;

data_base_command
	: TOK_BIN
		{ set_base(2); }
	| TOK_OCT
		{ set_base(8); }
	| TOK_DEC
		{ set_base(10); }
	| TOK_HEX
		{ set_base(16); }
	| TOK_BASE '(' long_value
		{ set_base(conv_str_to_ulong($3, 10)); }
	  ')'
	;
	
data_size_command
	: TOK_BYTE
		{ set_size(1); }
	| TOK_WORD
		{ set_size(2); }
	| TOK_LONG
		{ set_size(4); }
	| TOK_SIZE '(' long_value
		{ set_size(conv_str_to_ulong($3, 10)); }
	  ')'
	;

data_pad_command
	: TOK_PADSTRING '(' long_value
		{ set_padstring(conv_str_to_ulong($3, 10)); }
	  ')'
	| TOK_PADCHAR '(' long_value
		{ set_padchar(conv_str_to_ulong($3, 10)); }
	  ')'
	;

data_double_command
	: TOK_DOUBLE
		{ set_double_mode(1); }
	;

data_float_command
	: TOK_FLOAT
		{ set_double_mode(0); }
	;

data_value
	: long_value
		{ write_number($1, 1, get_base(), get_size()); }
	| '+' long_value
		{ write_number($2, 1, get_base(), get_size()); }
	| '-' long_value
		{ write_number($2, 0, get_base(), get_size()); }
	| real_value
		{ 
		  if(get_double_mode()) {
		    write_double($1); 
		  } else {
		    write_float((float)$1); 
		  }
		}
	| double_value
		{ write_double($1); }
	| float_value
		{ write_float($1); }
	| string_value
		{ write_quoted_string($1, get_padstring(), TRUE); }
	| char_value
		{ write_quoted_string($1, get_padchar(), FALSE); }
	| '(' expr ')'
		{ write_value($2, 1, get_size()); }
	;

expr	: condex
		{ $$ = $1; }
	;

condex	: orex
		{ $$ = $1; }
	| orex '?' condex ':' condex
		{ $$ = $1 ? $3 : $5; }
	;

orex	: xorex
		{ $$ = $1; }
	| orex '|' xorex
		{ $$ = $1 | $3; }
	;

xorex	: andex
		{ $$ = $1; }
	| xorex '^' andex
		{ $$ = $1 ^ $3; }
	;

andex	: eqex
		{ $$ = $1; }
	| andex '&' eqex
		{ $$ = $1 & $3; }
	;

eqex	: relex
		{ $$ = $1; }
	| eqex TOK_OP_EQUAL relex
		{ $$ = $1 == $3; }
	| eqex TOK_OP_UNEQUAL relex
		{ $$ = $1 != $3; }
	;

relex	: shiftex
		{ $$ = $1; }
	| relex TOK_OP_LT shiftex
		{ $$ = $1 < $3; }
	| relex TOK_OP_LE shiftex
		{ $$ = $1 <= $3; }
	| relex TOK_OP_GT shiftex
		{ $$ = $1 > $3; }
	| relex TOK_OP_GE shiftex
		{ $$ = $1 >= $3; }
	;

shiftex	: arith
		{ $$ = $1; }
	| shiftex TOK_OP_SHL arith
		{ $$ = $1 << $3; }
	| shiftex TOK_OP_SHR arith
		{ $$ = $1 >> $3; }
	;

arith	: term
		{ $$ = $1; }
	| arith '+' term
		{ $$ = $1 + $3; }
	| arith '-' term
		{ $$ = $1 - $3; }
	;

term	: factor
		{ $$ = $1; }
	| term '*' factor
		{ $$ = $1 * $3; }
	| term '/' factor
		{ $$ = $1 / $3; }
	| term '%' factor
		{ $$ = $1 % $3; }
	;

factor	: prim
		{ $$ = $1; }
	| '!' factor 
		{ $$ = ! $2; }
	| '~' factor 
		{ $$ = ~ $2; }
	| '-' prim 
		{ $$ = - $2; }
	| '+' prim 
		{ $$ = $2; }
	;
prim	: long_value
		{ $$ = conv_str_to_ulong($1, get_base()); }
	| nested
		{ $$ = $1; }

nested	: '(' expr ')'
		{ $$ = $2; }
	;

dec_value
	: TOK_MAYBE_HEXNUMBER
		{ $$ = conv_str_to_ulong($1, 10); }
	| based_value
		{ $$ = $1; }
	;

hex_value
	: TOK_MAYBE_HEXNUMBER
		{ $$ = conv_str_to_ulong($1, 16); }
	| based_value
		{ $$ = $1; }
	;

based_value
	: TOK_BINNUMBER
		{ $1[strlen($1)-2] = 0; $$ = conv_str_to_ulong($1, 2); }
	| TOK_OCTNUMBER
		{ $1[strlen($1)-2] = 0; $$ = conv_str_to_ulong($1, 8); }
	| TOK_DECNUMBER
		{ $1[strlen($1)-2] = 0; $$ = conv_str_to_ulong($1, 10); }
	| TOK_HEXNUMBER
		{ $1[strlen($1)-2] = 0; $$ = conv_str_to_ulong($1, 16); }
	;

long_value
	: TOK_MAYBE_HEXNUMBER
	| TOK_BINNUMBER
	| TOK_OCTNUMBER
	| TOK_DECNUMBER
	| TOK_HEXNUMBER
	;

real_value
	: TOK_REALNUMBER
	;

double_value
	: TOK_DOUBLENUMBER
	;

float_value
	: TOK_FLOATNUMBER
	;

string_value
	: TOK_STRING
	;

char_value
	: TOK_CHAR
	;

string_or_char_value
	: TOK_STRING
	| TOK_CHAR
	;

user_message
	: TOK_USER_ERROR string_or_char_value
		{ compiler_error("User error: %s", $2); }
	| TOK_USER_WARNING string_or_char_value
		{ compiler_warning("User warning: %s", $2); }
	| TOK_USER_MESSAGE string_or_char_value
		{ message(1, "User message: %s", $2); }
	;

%%

void yyerror(char *msg)
{
  compiler_error("%s '%s'", 
	msg, yytext);
}

void begin_parser(FILE *in)
{
  yyrestart(in);
  lineno = 1;
  
//  BEGIN INITIAL;

  yyparse();
}
