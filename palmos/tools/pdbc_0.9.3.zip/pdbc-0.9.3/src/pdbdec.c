//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: pdbdec.c 1.15 2002/04/15 06:19:26 obermuhl Exp obermuhl $
//
// $Log: pdbdec.c $
// Revision 1.15  2002/04/15 06:19:26  obermuhl
// impl print_double, print_float
// added -F value=float
// added -F value=double
//
// Revision 1.14  2001/11/21 22:24:51  obermuhl
// resources (big improvement)
//
// Revision 1.13  2001/11/16 23:13:07  obermuhl
// impl resource (prc files)
//
// Revision 1.12  2001/11/16 22:29:30  obermuhl
// improved escaped chars (singlequote, backslash?)
//
// Revision 1.11  2001/11/14 19:42:02  obermuhl
// consistent commentpos for attribute comments and ascii comments
//
// Revision 1.10  2001/11/14 17:57:07  obermuhl
// ascii comment uses now opt_comment_pos too
//
// Revision 1.9  2001/11/14 17:01:15  obermuhl
// fixed value 0 when unpadded (e.g. dec)
//
// Revision 1.8  2001/11/14 15:58:51  obermuhl
// now decompiles any base 2-36
//
// Revision 1.7  2001/11/13 23:01:19  obermuhl
// fix leftover bytes in format size=word/long
//
// Revision 1.6  2001/11/12 23:05:11  obermuhl
// added resource,stream,hidden (fileheader attribs)
//
// Revision 1.5  2001/10/16 21:22:25  obermuhl
// use new print_*() methods
// (for smarter comment_pos)
//
// fix bug with missing base/size specifier if -F is not default
//
// misc minor changes
//
// Revision 1.4  2001/10/15 14:26:56  obermuhl
// improved auto-string
//
// Revision 1.3  2001/10/09 22:44:45  obermuhl
// impl auto-string feature for data
//
// Revision 1.2  2001/10/05  14:06:51  obermuhl
// improved -F option
// (format commands)
//
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <ctype.h>
#include <time.h>

#include "pdbdec.h"
#include "palmfile.h"
#include "error.h"
#include "template.h"

//---------------------------------------------------------------------

extern char *progname;

//---------------------------------------------------------------------

#define UNTIL_EOF 999999

#define MAX_LINELEN 999
#define DEFAULT_LINELEN 8

#define PRINTMODE_CHAR 0
#define PRINTMODE_BYTE 1
#define PRINTMODE_WORD 2
#define PRINTMODE_LONG 3
#define PRINTMODE_FLOAT 4
#define PRINTMODE_DOUBLE 5

#define DATEMODE_DATE 0
#define DATEMODE_VALUE 1

char *filename = NULL;
char *indent_str = " ";
int opt_linelen = 8;
int opt_print_mode = PRINTMODE_BYTE;
int opt_print_base = 16;
int opt_print_ascii_comment = 1;
int opt_auto_string_len = 0;
int opt_auto_string_escaped = 0;
int opt_comment_pos = 40;

int opt_date_mode = DATEMODE_DATE;

int opt_resource = 0;

//---------------------------------------------------------------------

typedef struct Flag_ {
  char *name;
  unsigned long value;
} Flag;

Flag file_attrib_flags[] = {
  { "resource", 0x0001 },
  { "readonly", 0x0002 }, 
  { "dirty", 0x0004 },
  { "backup", 0x0008 },
  { "newer", 0x0010 },
  { "reset", 0x0020 },
  { "nobeam", 0x0040 },
  { "stream", 0x0080 },
  { "hidden", 0x0100 },
  { 0, 0 }
};

Flag record_attrib_flags[] = {
  { "secret", 0x0010 },
  { "busy", 0x0020 },
  { "dirty", 0x0040 },
  { "delete", 0x0080 },
  { 0, 0 }
};

//---------------------------------------------------------------------

int is_bigendian()
{
  union {
    short s;
    char c[sizeof(short)];
  } conv;

  conv.s = 0x0001;
  return conv.c[0];
}

char* get_str_record()
{
  if(opt_resource) {
    return "resource";
  } else {
    return "record";
  }
}

char* get_str_Record()
{
  if(opt_resource) {
    return "Resource";
  } else {
    return "record";
  }
}

void set_print_format(char *c)
{
  switch(c[0]) {
  case 'c' :
    opt_print_mode = PRINTMODE_CHAR;
    opt_print_ascii_comment = 0;
    break;
  case 'h' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 16;
    opt_print_ascii_comment = 1;
    break;
  case 'H' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 16;
    opt_print_ascii_comment = 0;
    break;
  case 'd' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 10;
    opt_print_ascii_comment = 1;
    break;
  case 'D' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 10;
    opt_print_ascii_comment = 0;
    break;
  case 'o' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 8;
    opt_print_ascii_comment = 1;
    break;
  case 'O' :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 8;
    opt_print_ascii_comment = 0;
    break;
  default :
    opt_print_mode = PRINTMODE_BYTE;
    opt_print_base = 16;
    opt_print_ascii_comment = 1;
    break;
  }
}

void set_date_format(char *c)
{
  switch(c[0]) {
  case 'd' :
    opt_date_mode = DATEMODE_DATE;
    break;
  case 'v' :
    opt_date_mode = DATEMODE_VALUE;
    break;
  }
}

void set_format_value(char *key, char *val)
{
  if(strcmp(val, "byte") == 0) {
    opt_print_mode = PRINTMODE_BYTE;
  } else if(strcmp(val, "word") == 0) {
    opt_print_mode = PRINTMODE_WORD;
  } else if(strcmp(val, "long") == 0) {
    opt_print_mode = PRINTMODE_LONG;
  } else if(strcmp(val, "char") == 0) {
    opt_print_mode = PRINTMODE_CHAR;
  } else if(strcmp(val, "float") == 0) {
    opt_print_mode = PRINTMODE_FLOAT;
  } else if(strcmp(val, "double") == 0) {
    opt_print_mode = PRINTMODE_DOUBLE;
  } else {
    warning("Unknown value '%s' for format key '%s'", val, key);
    opt_print_mode = PRINTMODE_BYTE;
  }
}

void set_format_base(char *key, char *val)
{
  if(strcmp(val, "bin") == 0) {
    opt_print_base = 2; 
  } else if(strcmp(val, "oct") == 0) {
    opt_print_base = 8; 
  } else if(strcmp(val, "dec") == 0) {
    opt_print_base = 10; 
  } else if(strcmp(val, "hex") == 0) {
    opt_print_base = 16; 
  } else {
    unsigned long ul = strtoul(val, NULL, 10);
    if(ul < 2 || ul > 36) {
      warning("Invalid value '%s' for format key '%s'", val, key);
      ul = 16;
    }
    opt_print_base = (int) ul;
  }
}

void set_format_comment(char *key, char *val)
{
  if(strcmp(val, "ascii") == 0) {
    opt_print_ascii_comment = 1;
  } else if(strcmp(val, "none") == 0) {
    opt_print_ascii_comment = 0;
  } else {
    warning("Unknown value '%s' for format key '%s'", val, key);
    opt_print_ascii_comment = 1;
  }
}

void set_format_commentpos(char *key, char *val)
{
  unsigned long ul = strtoul(val, NULL, 10);
  if(ul < 0 || ul > 999) {
    warning("Invalid value '%s' for format key '%s'", val, key);
    ul = 40;
  }
  opt_comment_pos = (int) ul;
}

void set_format_stringlen(char *key, char *val)
{
  unsigned long ul = strtoul(val, NULL, 10);
  if(ul < 0 || ul > 99) {
    warning("Invalid value '%s' for format key '%s'", val, key);
    ul = 0;
  }
  opt_auto_string_len = (int) ul;
}

void set_format_stringchars(char *key, char *val)
{
  if(strcmp(val, "escaped") == 0) {
    opt_auto_string_escaped = 1;
  } else if(strcmp(val, "standard") == 0) {
    opt_auto_string_escaped = 0;
  } else {
    warning("Unknown value '%s' for format key '%s'", val, key);
    opt_auto_string_escaped = 0;
  }
}

void set_format_linelen(char *key, char *val)
{
  unsigned long ul = strtoul(val, NULL, 10);
  if(ul < 0 || ul > MAX_LINELEN) {
    warning("Invalid value '%s' for format key '%s'", val, key);
    ul = DEFAULT_LINELEN;
  }
  opt_linelen = (int) ul;
}

void set_format_date(char *key, char *val)
{
  if(strcmp(val, "date") == 0) {
    opt_date_mode = DATEMODE_DATE;
  } else if(strcmp(val, "value") == 0) {
    opt_date_mode = DATEMODE_VALUE;
  } else {
    warning("Unknown value '%s' for format key '%s'", val, key);
    opt_date_mode = DATEMODE_DATE;
  }
}

void format_command(char *key, char *val)
{
  if(strcmp(key, "value") == 0) {
    set_format_value(key, val);
  } else if(strcmp(key, "size") == 0) {
    set_format_value(key, val);
  } else if(strcmp(key, "base") == 0) {
    set_format_base(key, val);
  } else if(strcmp(key, "comment") == 0) {
    set_format_comment(key, val);
  } else if(strcmp(key, "commentpos") == 0) {
    set_format_commentpos(key, val);
  } else if(strcmp(key, "string") == 0) {
    set_format_stringlen(key, val);
  } else if(strcmp(key, "stringlen") == 0) {
    set_format_stringlen(key, val);
  } else if(strcmp(key, "stringchars") == 0) {
    set_format_stringchars(key, val);
  } else if(strcmp(key, "linelen") == 0) {
    set_format_linelen(key, val);
  } else if(strcmp(key, "date") == 0) {
    set_format_date(key, val);
  } else if(strcmp(key, "") == 0) {
    // ignore empty key
  } else {
    warning("Unknown format key: %s", key);
  }
}

void parse_format_commands(char *cmds)
{
  char c;
  char *key;
  char *val;

  if(strlen(cmds) == 1) {
    set_print_format(cmds);
    return;
  }

  key = cmds;
  val = "";
  while(c = *cmds) {
    if(isspace(c) || c == ',') {
      *cmds = '\0';
      format_command(key, val);
      key = cmds+1;
      val = "";
    } else if(c == '=' || c == ':') {
      *cmds = '\0';
      val = cmds+1;
    } else {
    }

    cmds++;
  }
  format_command(key, val);
}

void set_query(char *query)
{
}

void print_indent(int indent)
{
  int i;

  for(i=0 ; i<indent ; i++) {
    print_str(indent_str);
  }
}

void print_octal_byte(unsigned char v)
{
  print_text("%03o", v);
}

void print_char(unsigned char c)
{
  switch(c) {
  case '\\' : print_str("\\\\"); break;
  case '\a' : print_str("\\a"); break;
  case '\b' : print_str("\\b"); break;
  case '\f' : print_str("\\f"); break;
  case '\n' : print_str("\\n"); break;
  case '\r' : print_str("\\r"); break;
  case '\t' : print_str("\\t"); break;
  case '\v' : print_str("\\v"); break;
  //case '\'' : print_str("\\'"); break;
  //case '\"' : print_str("\\\""); break;
  default :
    if(isprint(c)) {
      print_text("%c", c);
    } else {
      print_text("\\");
      print_octal_byte(c);
    }
  }
}

void print_escaped_str(char *v)
{
  char c;
  while(c = *v++) {
    print_char((unsigned char) c);
  }
}

void print_attrib_byte(char *name, unsigned char v, int indent)
{
  print_indent(indent);
  print_text("%s = %02x_h;", name, v);
  if(get_verbose_level() >= 3) {
    print_str(" ");
    print_fill(opt_comment_pos);
    print_text("// %u_d", v);
  }
  print_newline();
}

void print_attrib_short(char *name, unsigned short v, int indent)
{
  print_indent(indent);
  print_text("%s = %04x_h;", name, v);
  if(get_verbose_level() >= 3) {
    print_str(" ");
    print_fill(opt_comment_pos);
    print_text("// %u_d", v);
  }
  print_newline();
}

void print_attrib_dec_short(char *name, unsigned short v, int indent)
{
  print_indent(indent);
  print_text("%s = %u_d;", name, v);
  if(get_verbose_level() >= 3) {
    print_str(" ");
    print_fill(opt_comment_pos);
    print_text("// %04x_h", v);
  }
  print_newline();
}

void print_attrib_long(char *name, unsigned long v, int indent)
{
  print_indent(indent);
  print_text("%s = %08x_h;", name, v);
  if(get_verbose_level() >= 3) {
    print_str(" ");
    print_fill(opt_comment_pos);
    print_text("// %lu_d", v);
  }
  print_newline();
}

void print_attrib_date(char *name, long v, int indent)
{
  long v2;
  struct tm *t;

  v2 = v - 2082844800;

  if(opt_date_mode == DATEMODE_DATE && v2>=0) {
    t = localtime(&v2);
    print_indent(indent);
    print_text("%s = ", name);
    print_text("%04d/%02d/%02d %02d:%02d:%02d;",
	   t->tm_year+1900, t->tm_mon+1, t->tm_mday,
	   t->tm_hour, t->tm_min, t->tm_sec);
    if(get_verbose_level() >= 3) {
      print_str(" ");
      print_fill(opt_comment_pos);
      print_text("// %08x_h %u_d", v, v);
    }
    print_newline();
  } else {
    print_attrib_long(name, v, indent);
  }
}

void print_attrib_str(char *name, char* v, int indent)
{
  print_indent(indent);
  print_text("%s = \"", name);
  print_escaped_str(v);
  //printf("%s", v);
  print_line("\";");
}

void print_attrib_str_filled(char *name, char* v, int len, int indent)
{
  int i;
  print_indent(indent);
  print_text("%s = '", name);
  for(i=0 ; i<len ; i++) {
    unsigned char c = (unsigned char) v[i];
    print_char(c);
  }
  print_line("';");
}

void print_attrib_char3_unless(char *name, char* v, int indent, 
			       char x1, char x2, char x3)
{
  if(get_verbose_level() >= 3 || (v[0] != x1 && v[1] != x2 && v[2] != x3)) {
    print_indent(indent);
    print_text("%s = %02x%02x%02x_h", name, 
	       (unsigned char)v[0], (unsigned char)v[1], (unsigned char)v[2]);
    print_str(";");
    if(get_verbose_level() >= 3) {
      if(isprint(v[0]) && isprint(v[1]) && isprint(v[2])) {
	print_str(" ");
	print_fill(opt_comment_pos);
	print_text("// '%c%c%c'", v[0], v[1], v[2]);
      }
    }
    print_newline();
  }
}

void print_attrib_char4(char *name, char* v, int indent)
{
  int printable;

  printable = isprint(v[0]) && isprint(v[1]) && isprint(v[2]) && isprint(v[3]);
  print_indent(indent);
  print_text("%s = ", name);
  if(printable) {
    print_text("'%c%c%c%c'", 
	       v[0], v[1], v[2], v[3]);
  } else {
    print_text("%02x%02x%02x%02x_h",
	       (unsigned char)v[0], (unsigned char)v[1], 
	       (unsigned char)v[2], (unsigned char)v[3]);
  }
  print_str(";");
  if(get_verbose_level() >= 3) {
    if(printable) {
      print_str(" ");
      print_fill(opt_comment_pos);
      print_text("// %02x%02x%02x%02x_h;",
		 (unsigned char)v[0], (unsigned char)v[1], 
		 (unsigned char)v[2], (unsigned char)v[3]);
    }
  }
  print_newline();
}

void print_attrib_byte_unless(char *name, unsigned char v, int indent, unsigned char x)
{
  if(v != x || get_verbose_level() >= 3) {
    print_attrib_byte(name, v, indent);
  }
}

void print_attrib_short_unless(char *name, short v, int indent, short x)
{
  if(v != x || get_verbose_level() >= 3) {
    print_attrib_short(name, v, indent);
  }
}

void print_attrib_dec_short_unless(char *name, short v, int indent, short x)
{
  if(v != x || get_verbose_level() >= 3) {
    print_attrib_dec_short(name, v, indent);
  }
}

void print_attrib_long_unless(char *name, long v, int indent, long x)
{
  if(v != x || get_verbose_level() >= 3) {
    print_attrib_long(name, v, indent);
  }
}

void print_flags(unsigned long v, Flag *flags, int bytes)
{
  int i;
  int first_flag;

  first_flag = TRUE;
  i=0;
  while(flags[i].name) {
    if(flags[i].value & v) {
      v -= flags[i].value;
      if(!first_flag) {
	print_str(" | ");
      }
      print_text("%s", flags[i].name);
      first_flag = FALSE;
    }
    i++;
  }
  if(v) {
    if(!first_flag) {
      print_str(" | ");
    }
    switch(bytes) {
    case 1:
      print_text("%02x", v);
      break;
    case 2:
      print_text("%04x", v);
      break;
    case 3:
      print_text("%06x", v);
      break;
    case 4:
      print_text("%08x", v);
      break;
    }
  }
}

void print_attrib_flags_unless(char *name, unsigned long v, Flag *flags, int bytes, int indent, unsigned long x)
  {
    if(v != x || get_verbose_level() >= 3) {
      print_indent(indent);
      print_text("%s = ", name);
      print_flags(v, flags, bytes);
      print_str(";");
      if(get_verbose_level() >= 3) {
	print_str(" ");
	print_fill(opt_comment_pos);
	print_str("// ");
	switch(bytes) {
	case 1:
	  print_text("%02x_h", v);
	  break;
	case 2:
	  print_text("%04x_h", v);
	  break;
	case 3:
	  print_text("%06x_h", v);
	  break;
	case 4:
	  print_text("%08x_h", v);
	  break;
	}
      }
      print_newline();
    }
  }

//---------------------------------------------------------------------

unsigned long read_pos = 0;

void read_buffer(char *name, void *buf, size_t size, FILE *in)
{
  size_t count;

  count = fread(buf, size, 1, in);
  if(count != 1) {
    error("Could not read %s", name);
  }
  read_pos += size;
}

void read_str(char *name, char *buf, size_t size, FILE *in)
{
  read_buffer(name, buf, size, in);
}

unsigned char read_byte(char *name, FILE *in)
{
  unsigned char v;
  read_buffer(name, &v, sizeof(v), in);
  return v;
}

int read_byte_ignore_error(unsigned char *v, FILE *in)
{
  size_t count;
  count = fread(v, 1, 1, in);
  read_pos += count;
  return count;
}

short read_short(char *name, FILE *in)
{
  unsigned long b1 = read_byte(name, in);
  unsigned long b2 = read_byte(name, in);
  return (unsigned short)(b1 << 8 | b2);
}

long read_long(char *name, FILE *in)
{
  unsigned long b1 = read_byte(name, in);
  unsigned long b2 = read_byte(name, in);
  unsigned long b3 = read_byte(name, in);
  unsigned long b4 = read_byte(name, in);
  return b1 << 24 | b2 << 16 | b3 << 8 | b4;
}


void read_fileheader(PalmFileHeader *fh, FILE *in)
{
  read_str("filename", fh->filename, 32, in);
  fh->attrib = read_short("attrib", in);
  fh->version = read_short("version", in);
  fh->creationDate = read_long("creation_date", in);
  fh->modificationDate = read_long("modification_date", in);
  fh->backupDate = read_long("backup_date", in);
  fh->modNumber = read_long("modification", in);
  fh->appInfoArea = read_long("appInfoArea", in);
  fh->sortInfoArea = read_long("sortInfoArea", in);
  read_str("typeid", fh->typeId, 4, in);
  read_str("creatorid", fh->creatorId, 4, in);
  fh->uniqueIdSeed = read_long("uniqueid_seed", in);
  fh->nextRecordListId = read_long("nextRecordList", in);
  fh->numRecords = read_short("numRecords", in);

  if(fh->attrib & PDB_FILEHEADER_ATTRIB_RSRC) {
    opt_resource = 1;
  }
}

void read_recordheader(PalmRecord *rh, FILE *in)
{
  rh->dataAddr = read_long("record localChunkId", in);
  rh->attrib = read_byte("record attrib", in);
  read_str("record uniqueid", rh->uniqueId, 3, in);
}

void read_resourceheader(PalmRecord *rh, FILE *in)
{
  read_str("resource typeid", rh->rsrc_typeId, 4, in);
  rh->rsrc_id = read_short("resource id", in);
  rh->dataAddr = read_long("resource localChunkId", in);
}

//---------------------------------------------------------------------

void print_ascii(unsigned char *ascii, int len)
{
  int i;

  if(get_verbose_level() >= 1) {
    print_fill(opt_comment_pos);
    print_str("// ");
    for(i=0 ; i<len ; i++) {
      unsigned char c = ascii[i];
      print_text("%c", isprint(c) ? c : '.');
    }
  }
  print_newline();
}

void print_based_value(unsigned long value, int base, int padlen)
{
  char c;
  char buffer[64];
  int bufpos = 0;
  int i;
  unsigned long v = value;

  if(padlen <= 1 && value == 0) {
    print_str("0");
    return;
  }

  while(v>0) {
    unsigned long digit = v % base;
    v /= base;

    if(digit<10) {
      c = '0' + digit;
    } else {
      c = 'a' - 10 + digit;
    }
    buffer[bufpos++] = c;
  }

  for(i=bufpos ; i<padlen ; i++) {
    print_str("0");
  }
  for(i=bufpos-1 ; i>=0 ; i--) {
    print_text("%c", buffer[i]);
  }
}

void print_byte(unsigned char value)
{
  int valuepad = 0;

  switch(opt_print_mode) {
  case PRINTMODE_CHAR :
    print_char((unsigned char)value);
    break;
  default :
    switch(opt_print_base) {
    case 2 :
      valuepad=8;
      break;
    case 8 :
      valuepad=3;
      break;
    case 10 :
      valuepad=0;
      break;
    case 16 :
      valuepad=2;
      break;
    }
    print_based_value(value, opt_print_base, valuepad);
    print_str(" ");
    break;
  }
}

void print_word(unsigned long value)
{
  int valuepad = 0;

  switch(opt_print_base) {
  case 2 :
    valuepad=16;
    break;
  case 8 :
    valuepad=6;
    break;
  case 10 :
    valuepad=0;
    break;
  case 16 :
    valuepad=4;
    break;
  }
  print_based_value(value, opt_print_base, valuepad);
  print_str(" ");
}

void print_long(unsigned long value)
{
  int valuepad = 0;

  switch(opt_print_base) {
  case 2 :
    valuepad=32;
    break;
  case 8 :
    valuepad=12;
    break;
  case 10 :
    valuepad=0;
    break;
  case 16 :
    valuepad=8;
    break;
  }
  print_based_value(value, opt_print_base, valuepad);
  print_str(" ");
}

void print_float(unsigned char* buffer)
{
  union {
    float v;
    unsigned char c[sizeof(float)];
  } conv;

  
  if(is_bigendian()) {
    int i;
    for(i=0 ; i<sizeof(float) ; i++) {
      conv.c[i] = buffer[sizeof(float)-1-i];
    }
  } else {
    int i;
    for(i=0 ; i<sizeof(float) ; i++) {
      conv.c[i] = buffer[i];
    }
  }
  print_text("%gf ", conv.v);
}

void print_double(unsigned char* buffer)
{
  union {
    double v;
    unsigned char c[sizeof(double)];
  } conv;

  
  if(is_bigendian()) {
    int i;
    for(i=0 ; i<sizeof(double) ; i++) {
      conv.c[i] = buffer[sizeof(double)-1-i];
    }
  } else {
    int i;
    for(i=0 ; i<sizeof(double) ; i++) {
      conv.c[i] = buffer[i];
    }
  }
  print_text("%gd ", conv.v);
}

void print_buffer_string(unsigned char* buffer, int bufferlen)
{
  int i;
  
  print_indent(3);

  print_str("'");
  for(i=0 ; i<bufferlen ; i++) {
    unsigned char c = buffer[i];

    switch(c) {
    case '\\' : print_str("\\\\"); break;
    case '\a' : print_str("\\a"); break;
    case '\b' : print_str("\\b"); break;
    case '\f' : print_str("\\f"); break;
    case '\n' : print_str("\\n"); break;
    case '\r' : print_str("\\r"); break;
    case '\t' : print_str("\\t"); break;
    case '\v' : print_str("\\v"); break;
    case '\'' : print_str("\\'"); break;
    default :   
      if(isprint(c)) {
	print_text("%c", c);
      } else {
	print_text("\\%03o", c);
      }
    }
  }
  print_line("'");
}

void print_buffer_bytes(unsigned char* buffer, int bufferlen)
{
  int i;
  
  print_indent(3);
  for(i=0 ; i<bufferlen ; i++) {
    print_byte(buffer[i]);
  }
  print_newline();
}

int is_auto_string(unsigned char c)
{
  if(opt_auto_string_escaped) {
    return isprint(c) || 
      (c=='\a') ||
      (c=='\b') ||
      (c=='\f') ||
      (c=='\n') ||
      (c=='\r') ||
      (c=='\t') ||
      (c=='\v');
  } else {
    return isprint(c);
  }
}

void read_data_smart(unsigned long addr, unsigned long len, int opt_linelen, FILE *in)
{
  size_t i;
  int ok;
  unsigned char *buffer;
  int buffer_pos;
  int print_string_flag;
  int next_print_string_flag;
  int print_buffer_flag;
  int unhandled_byte_flag;

  buffer = (unsigned char*) malloc(opt_linelen);

  if(read_pos < addr) {
    if(addr - read_pos > 2) {
      warning("Skipping %d bytes", addr - read_pos);
    }
    while(read_pos < addr) {
      read_byte("skipping", in);
    }
  }

  switch(opt_print_base) {
  case 2 :
    print_indent(3);
    print_line("bin");
    break;
  case 8 :
    print_indent(3);
    print_line("oct");
    break;
  case 10 :
    print_indent(3);
    print_line("dec");
    break;
  case 16 :
    // hex is default, no need to specify
    //print_indent(3);
    //print_line("hex");
    break;
  default:
    print_indent(3);
    print_line("base(%d)", opt_print_base);
    break;
  }

  switch(opt_print_mode) {
  case PRINTMODE_BYTE :
  case PRINTMODE_CHAR :
    // byte is default, no need to specify
    break;
  case PRINTMODE_WORD :
    print_indent(3);
    print_line("word");
    break;
  case PRINTMODE_LONG :
    print_indent(3);
    print_line("long");
    break;
  }

  buffer_pos = 0;
  print_string_flag = 0;
  next_print_string_flag = 0;
  print_buffer_flag = 0;

  for(i=0 ; i<len ; i++) {
    unsigned char c;
    
    ok = read_byte_ignore_error(&c, in);
    if(!ok) {
      break;
    }

    print_buffer_flag = 0;
    unhandled_byte_flag = 0;
    if(print_string_flag) {
      if(is_auto_string(c)) {
	buffer[buffer_pos++] = c;
      } else if(buffer_pos < opt_auto_string_len) {
	buffer[buffer_pos++] = c;
	next_print_string_flag = 0;
      } else {
	unhandled_byte_flag = 1;
	print_buffer_flag = 1;
	next_print_string_flag = 0;
      }
    } else {
      if(!is_auto_string(c)) {
	buffer[buffer_pos++] = c;
      } else {
	unhandled_byte_flag = 1;
	print_buffer_flag = 1;
	next_print_string_flag = 1;
      }
    }

    if(print_buffer_flag || buffer_pos >= opt_linelen) {
      if(print_string_flag && buffer_pos >= opt_auto_string_len) {
	print_buffer_string(buffer, buffer_pos);
      } else {
	print_buffer_bytes(buffer, buffer_pos);
      }
      buffer_pos = 0;
    }

    if(unhandled_byte_flag) {
      buffer[buffer_pos++] = c;
    }
    print_string_flag = next_print_string_flag;
  }

  if(buffer_pos > 0) {
    if(print_string_flag && buffer_pos >= opt_auto_string_len) {
      print_buffer_string(buffer, buffer_pos);
    } else {
      print_buffer_bytes(buffer, buffer_pos);
    }
  }

  free(buffer);
}

void read_data(unsigned long addr, unsigned long len, int opt_linelen, FILE *in)
{
  size_t i;
  unsigned char *ascii;
  int ascii_idx;
  int ok;
  int string_pos;
  unsigned long value;

  if(opt_auto_string_len > 0) {
    read_data_smart(addr, len, opt_linelen, in);
    return;
  }

  ascii = (unsigned char*) malloc(opt_linelen);

  if(read_pos < addr) {
    if(addr - read_pos > 2) {
      warning("Skipping %d bytes", addr - read_pos);
    }
    while(read_pos < addr) {
      read_byte("skipping", in);
    }
  }

  switch(opt_print_base) {
  case 2 :
    print_indent(3);
    print_line("bin");
    break;
  case 8 :
    print_indent(3);
    print_line("oct");
    break;
  case 10 :
    print_indent(3);
    print_line("dec");
    break;
  case 16 :
    // hex is default, no need to specify
    //print_indent(3);
    //print_line("hex");
    break;
  default:
    print_indent(3);
    print_line("base(%d)", opt_print_base);
    break;
  }

  switch(opt_print_mode) {
  case PRINTMODE_BYTE :
  case PRINTMODE_CHAR :
    break;
  case PRINTMODE_WORD :
    print_indent(3);
    print_line("word");
    break;
  case PRINTMODE_LONG :
    print_indent(3);
    print_line("long");
    break;
  }

  string_pos = 0;
  value = 0;

  ascii_idx = 0;
  for(i=0 ; i<len ; i++) {
    unsigned char c;
    
    ok = read_byte_ignore_error(&c, in);
    if(!ok) {
      break;
    }

    if(ascii_idx == 0) {
      print_indent(3);
      if(opt_print_mode == PRINTMODE_CHAR) {
	print_str("'");
      }
    }

    ascii[ascii_idx++] = c;
    value <<= 8;
    value |= c;

    switch(opt_print_mode) {
    case PRINTMODE_BYTE :
    case PRINTMODE_CHAR :
      print_byte(c);
      break;
    case PRINTMODE_WORD :
      if(ascii_idx % 2 == 0) {
	print_word(value);
	value = 0;
      }
      break;
    case PRINTMODE_LONG :
      if(ascii_idx % 4 == 0) {
	print_long(value);
	value = 0;
      }
      break;
    case PRINTMODE_FLOAT :
      if(ascii_idx % 4 == 0) {
	print_float(&ascii[ascii_idx-4]);
	value = 0;
      }
      break;
    case PRINTMODE_DOUBLE :
      if(ascii_idx % 8 == 0) {
	print_double(&ascii[ascii_idx-8]);
	value = 0;
      }
      break;
    }

    if(ascii_idx == opt_linelen) {
      if(opt_print_mode == PRINTMODE_CHAR) {
	print_str("'");
      }
      if(opt_print_ascii_comment) {
	print_ascii(ascii, opt_linelen);
      } else {
	print_newline();
      }
      ascii_idx = 0;
    }
  }

  // print leftover bytes in word/long mode
  switch(opt_print_mode) {
  case PRINTMODE_BYTE :
  case PRINTMODE_CHAR :
    break;
  case PRINTMODE_WORD :
    if(ascii_idx % 2 == 1) {
      print_text("byte ");
      print_byte((unsigned char)(value & 0x00ff));
    }
    break;
  case PRINTMODE_LONG :
    switch(ascii_idx % 4) {
    case 1 :
      print_text("byte ");
      print_byte((unsigned char)(value & 0x00ff));
      break;
    case 2 :
      print_text("byte ");
      print_byte((unsigned char)((value >> 8) & 0x00ff));
      print_byte((unsigned char)(value & 0x00ff));
      break;
    case 3 :
      print_text("byte ");
      print_byte((unsigned char)((value >> 16) & 0x00ff));
      print_byte((unsigned char)((value >> 8) & 0x00ff));
      print_byte((unsigned char)(value & 0x00ff));
      break;
    }
    break;
  } 

  // print last ascii if necessary
  if(ascii_idx > 0) {
    int pad;
    if(opt_print_mode == PRINTMODE_CHAR) {
      print_str("'");
    }
    if(opt_print_ascii_comment) {
      for(pad=ascii_idx ; pad<opt_linelen ; pad++) {
	print_str("   ");
      }
      print_ascii(ascii, ascii_idx);
    } else {
      print_newline();
    }
  } else {
    // kill superfluous print_indent()
    print_newline();
  }

  free(ascii);
}

void print_pdb_fileheader(PalmFileHeader *fh)
{
  ///print_line("file");
  if(get_verbose_level() >= 2) {
    //FNORD_assignString_in_pdbc_still_wrong  print_attrib_str_filled("filename", fh->filename, 32, 1);
    print_attrib_str("filename", fh->filename, 1);
  } else {
    print_attrib_str("filename", fh->filename, 1);
  }
  print_attrib_flags_unless("attrib", fh->attrib, file_attrib_flags, 2, 1, 0x0000);
  print_attrib_short_unless("version", fh->version, 1, 0x0000000);
  if(get_verbose_level() >= 1) {
    print_attrib_date("creation_date", fh->creationDate, 1);
    print_attrib_date("modification_date", fh->modificationDate, 1);
    print_attrib_date("backup_date", fh->backupDate, 1);
  }
  print_attrib_long_unless("modification", fh->modNumber, 1, 0x00000000);
  print_attrib_char4("typeid", fh->typeId, 1);
  print_attrib_char4("creatorid", fh->creatorId, 1);
  print_attrib_long_unless("uniqueid_seed", fh->uniqueIdSeed, 1, 0x00000000);
  if(fh->nextRecordListId != 0) {
    warning("Not yet implemented: Only one record list supported");
    if(get_verbose_level() >= 3) {
      print_attrib_long("// next_record_list", fh->nextRecordListId, 1);
    }
  }
  print_newline();
  message(4, " // %d %s%s", 
	  fh->numRecords, 
	  get_str_record(),
	  fh->numRecords==1 ? "" : "s");
}

void print_pdb_record()
{
}


void read_pdb(FILE *in)
{
  PalmFileHeader fh;
  PalmRecord *recordList;
  unsigned long *recordLengths;
  int i;

  read_fileheader(&fh, in);
  
  print_line("file");
  if(get_verbose_level() >= 2) {
    //FNORD_assignString_in_pdbc_still_wrong  print_attrib_str_filled("filename", fh.filename, 32, 1);
    print_attrib_str("filename", fh.filename, 1);
  } else {
    print_attrib_str("filename", fh.filename, 1);
  }
  print_attrib_flags_unless("attrib", fh.attrib, file_attrib_flags, 2, 1, 0x0000);
  print_attrib_short_unless("version", fh.version, 1, 0x0000000);
  if(get_verbose_level() >= 1) {
    print_attrib_date("creation_date", fh.creationDate, 1);
    print_attrib_date("modification_date", fh.modificationDate, 1);
    print_attrib_date("backup_date", fh.backupDate, 1);
  }
  print_attrib_long_unless("modification", fh.modNumber, 1, 0x00000000);
  print_attrib_char4("typeid", fh.typeId, 1);
  print_attrib_char4("creatorid", fh.creatorId, 1);
  print_attrib_long_unless("uniqueid_seed", fh.uniqueIdSeed, 1, 0x00000000);
  if(fh.nextRecordListId != 0) {
    warning("Not yet implemented: Only one record list supported");
    if(get_verbose_level() >= 3) {
      print_attrib_long("// next_record_list", fh.nextRecordListId, 1);
    }
  }
  print_newline();
  message(4, " // %d %s%s", 
	  fh.numRecords, 
	  get_str_record(),
	  fh.numRecords==1 ? "" : "s");
  print_newline();
  print_line("begin");
  print_newline();

  if(fh.numRecords > 0) {
    recordList = (PalmRecord*) malloc(sizeof(PalmRecord)*fh.numRecords);
    for(i=0 ; i<fh.numRecords ; i++) {
      if(opt_resource) {
	read_resourceheader(&recordList[i], in);
      } else {
	read_recordheader(&recordList[i], in);
      }
    }
    
    // calc record lengths
    recordLengths = (unsigned long*) malloc(sizeof(unsigned long)*fh.numRecords);
    for(i=0 ; i<fh.numRecords-1 ; i++) {
      if(recordList[i+1].dataAddr < recordList[i].dataAddr) {
	error("Illegal record address (record %d before record %d)",
	      i+1, i);
      }
      recordLengths[i] = recordList[i+1].dataAddr - recordList[i].dataAddr;
    }
    recordLengths[fh.numRecords-1] = UNTIL_EOF;
  } else {
    read_short("placeholder", in);
  }
   
  if(fh.appInfoArea) {
    unsigned long appinfoLen = 0;

    message(9, "// appinfoArea = %d", fh.appInfoArea);
    message(9, "// sortinfoArea = %d", fh.sortInfoArea);
    if(fh.sortInfoArea) {
      appinfoLen = fh.sortInfoArea - fh.appInfoArea;
      message(9, "// applen1 = %d", appinfoLen);
    } else if(fh.numRecords > 0) {
      appinfoLen = recordList[0].dataAddr - fh.appInfoArea;
      message(9, "// applen2 = %d", appinfoLen);
    } else {
      appinfoLen = UNTIL_EOF;
      message(9, "// applen3 = %d", appinfoLen);
    }
    if(appinfoLen < 0) {
      warning("Illegal appinfo length");
      appinfoLen = 0;
    }

    print_line(" appinfo");
    message(4, "  // address offset = %08x_h", fh.appInfoArea);
    message(5, "  // appinfo length = %d", appinfoLen);
    print_line(" begin");

    read_data(fh.appInfoArea, appinfoLen, opt_linelen, in);

    print_line(" end;");
    print_line(" ");
  }
 
  if(fh.sortInfoArea) {
    unsigned long sortinfoLen = 0;

    if(fh.numRecords > 0) {
      sortinfoLen = recordList[0].dataAddr - fh.sortInfoArea;
      message(9, "// sortlen1 = %d", sortinfoLen);
    } else {
      sortinfoLen = UNTIL_EOF;
      message(9, "// sortlen2 = %d", sortinfoLen);
    }
    if(sortinfoLen < 0) {
      warning("Illegal sortinfo length");
      sortinfoLen = 0;
    }

    print_line(" sortinfo");
    message(4, "  // address offset = %08x_h", fh.sortInfoArea);
    message(5, "  // sortinfo length = %d", sortinfoLen);
    print_line(" begin");

    read_data(fh.sortInfoArea, sortinfoLen, opt_linelen, in);

    print_line(" end;");
    print_line(" ");
  }
 
  if(fh.numRecords > 0) {
    for(i=0 ; i<fh.numRecords ; i++) {
      PalmRecord *rh = &recordList[i];

      if(opt_resource) {
	print_line(" resource");
	message(4, "  // address offset = %08x_h", rh->dataAddr);
	message(5, "  // resource length = %d", recordLengths[i]);
	print_attrib_char4("typeid", rh->rsrc_typeId, 2);
	print_attrib_dec_short_unless("id", rh->rsrc_id, 2, 0x0000);
      } else {
	print_line(" record");
	message(4, "  // address offset = %08x_h", rh->dataAddr);
	message(5, "  // record length = %d", recordLengths[i]);
	print_attrib_flags_unless("attrib", rh->attrib, record_attrib_flags, 1, 2, 0x0000);
	print_attrib_char3_unless("recordid", rh->uniqueId, 2, 0x00, 0x00, 0x00);
      }
      print_line(" begin");

      read_data(rh->dataAddr, recordLengths[i], opt_linelen, in);
      
      print_line(" end;");
      print_line(" ");
    }

    free(recordList);
  }
  print_newline();
  print_line("end;");
  print_newline();
}

//---------------------------------------------------------------------

void run_pdbdec(char *filename)
{
  FILE *in = fopen(filename, "rb");
  if(!in) {
    error("Could not open source file '%s'.", filename);
  }

  read_pdb(in);

  fclose(in);
}

//---------------------------------------------------------------------

void print_help()
{
  printf("NAME\n"
	 "    pdbdec -- palm database decompiler\n"
	 "\n"
	 "SYNOPSYS\n"
         "    pdbc [-h -V -W -o file -w[01] -v[0-4] -l opt_linelen] file\n"
	 "\n"
	 "OPTIONS\n"
	 "    -h              This help text\n"
	 "    -v0             Verbose: off\n"
	 "    -v1             Verbose: normal level (default)\n"
	 "    -v2             Verbose: more info\n"
	 "    -v3             Verbose: a lot of info\n"
	 "    -v4             Verbose: way too much info\n"
	 "    -V              Version information\n"
	 "    -w0             Supress warnings\n"
	 "    -w1             Don't supress warnings (default)\n"
	 "    -W              Treat warnings as errors\n"
	 "    -o file         Output file\n"
	 "    -l opt_linelen      Number of bytes per dumped line\n"
	 "\n"
	 "DIAGNOSTICS\n"
	 "    Possible exit status values:\n"
	 "    0 Successful completion\n"
	 "    1 Missing sourcefile arg\n"
	 "    2 Unknown commandline option\n"
	 "    3 Commandline option error (e.g. missing option arg)\n"
	 "    4 Misc errors (e.g. fopen, ...)\n"
	 "    5 Compiler error in source file\n"
	 "\n"
	 "BUGS\n"
	 "    Check file known_bugs.txt in the distribution.\n"
	 "    Error reports to: eric@obermuhlner.com\n"
	 "\n");
}

//---------------------------------------------------------------------

void print_usage()
{
  fprintf(stderr, "Usage: pdbdec [-h -V -W -o file -w[01] -v[0-4] -l opt_linelen ] file\n");
}

//---------------------------------------------------------------------

void print_version()
{
  printf("pdbc 0.9.3\n");
}

//---------------------------------------------------------------------

void test_main()
{
}

//---------------------------------------------------------------------

int main(int argc, char *argv[])
{
  int i;
  int parsing_options = TRUE;
  char *template_name = NULL;
  char *optarg;

  progname = "pdbdec";

  //test_main();

  i = 1;
  while(i<argc && parsing_options) {
    if(argv[i][0] == '-') {
      if(optarg = parse_option(argc, argv, &i, 'h', "--help", 0)) {
	print_help();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, '?', "--help", 0)) {
	print_help();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, 'V', "--version", 0)) {
	print_version();
	exit(0);
      } else if(optarg = parse_option(argc, argv, &i, 'v', "--verbose", 1)) {
	set_verbose_level(optarg[0]);
      } else if(optarg = parse_option(argc, argv, &i, 'w', "--warnings", 1)) {
	set_warning_level(optarg[0]);
      } else if(optarg = parse_option(argc, argv, &i, 'W', "--strict", 0)) {
	set_warning_as_errors(TRUE);
      } else if(optarg = parse_option(argc, argv, &i, 'F', "--format", 1)) {
	parse_format_commands(optarg);
      } else if(optarg = parse_option(argc, argv, &i, 'D', "--date-format", 1)) {
	set_date_format(optarg);
      } else if(optarg = parse_option(argc, argv, &i, 'Q', "--query", 1)) {
	set_query(optarg);
      } else if(optarg = parse_option(argc, argv, &i, 'X', "--debug-info", 0)) {
	printf("linelen       = %d\n", opt_linelen);
	printf("print_mode    = %d\n", opt_print_mode);
	printf("print_base    = %d\n", opt_print_base);
	printf("print_comment = %d\n", opt_print_ascii_comment);
	printf("auto_string   = %d\n", opt_auto_string_len);
	exit(0);
	break;
      } else if(optarg = parse_option(argc, argv, &i, 'o', "--out", 1)) {
	filename = optarg;
      } else if(optarg = parse_option(argc, argv, &i, 'l', "--line-length", 1)) {
	sscanf(optarg, "%d", &opt_linelen);
	if(opt_linelen<=0 || opt_linelen > MAX_LINELEN) {
	  warning("Option -l illegal value %d for line length -- set to %d",
		  opt_linelen, DEFAULT_LINELEN);
	  opt_linelen = DEFAULT_LINELEN;
	}
      } else if(optarg = parse_option(argc, argv, &i, 't', "--template", 1)) {
	template_name = optarg;
      } else if(optarg = parse_option(argc, argv, &i, '-', "--end-args", 0)) {
	parsing_options = FALSE;
      } else {
	fprintf(stderr, "Unknown option %s\n", argv[i]);
	print_usage();
	exit(2);
      }
    } else {
      parsing_options = FALSE;
    }
  }

  if(template_name) {
    init_template(template_name);
    feed_template('A');
    feed_template('B');
    feed_template('C');
    exit(0);
  }

  if(i==argc-1) {
    if(filename) {
      FILE *out = fopen(filename, "w");
      if(!out) {
	fprintf(stderr, "Could not open file '%s' for writing\n", filename);
	exit(4);
      }
      set_printout(out);
    }
    run_pdbdec(argv[i]);
  } else {
    print_usage();
    exit(1);
  }
  return 0;
}

//---------------------------------------------------------------------
