//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: fileheader.h 1.1 2001/09/30 10:59:14 obermuhl Exp $
//
// $Log: fileheader.h $
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef fileheader_h
#define fileheader_h

#include "memfile.h"

#include "palmfile.h"

//---------------------------------------------------------------------

typedef PalmFileHeader FileHeader;

//---------------------------------------------------------------------

int createFileHeader(FileHeader *fileheader);
int deleteFileHeader(FileHeader *fileheader);

void setFilenameFileHeader(FileHeader *fileheader, char *filename);
//void setCreatorIdFileHeader(FileHeader *fileheader, char *id);
//void setTypeIdFileHeader(FileHeader *fileheader, char *id);
void setCreatorIdFileHeader(FileHeader *fileheader, unsigned long id);
void setTypeIdFileHeader(FileHeader *fileheader, unsigned long id);

int dumpMemFileFileHeader(FileHeader *fileheader, MemFile *memfile);

//---------------------------------------------------------------------

#endif

