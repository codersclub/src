//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: palmfile.h 1.2 2001/11/17 11:23:39 obermuhl Exp $
//
// $Log: palmfile.h $
// Revision 1.2  2001/11/17 11:23:39  obermuhl
// impl resources
//
// Revision 1.1  2001/09/30 10:59:14  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#ifndef palmfile_h
#define palmfile_h

//---------------------------------------------------------------------

typedef struct PalmFileHeader_ {
  char filename[32];
  unsigned short attrib;
  unsigned short version;
  unsigned long creationDate;
  unsigned long modificationDate;
  unsigned long backupDate;
  unsigned long modNumber;
  unsigned long appInfoArea;
  unsigned long sortInfoArea;
  char typeId[4];
  char creatorId[4];
  unsigned long uniqueIdSeed;
  unsigned long nextRecordListId;
  unsigned short numRecords;
} PalmFileHeader;

//---------------------------------------------------------------------

typedef struct PalmRecord_ {
  unsigned long dataAddr;
  unsigned char attrib;
  char uniqueId[3];

  char rsrc_typeId[4];
  unsigned short rsrc_id;
} PalmRecord;

//---------------------------------------------------------------------

#define PDB_FILEHEADER_ATTRIB_RSRC 0x0001

#endif
