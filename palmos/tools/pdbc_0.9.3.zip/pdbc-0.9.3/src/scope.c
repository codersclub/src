//--------------------------------------------------------------------
//
// Copyright 2001 by Eric Obermuhlner
//
// $Id: scope.c 1.2 2001/11/02 21:32:11 obermuhl Exp $
//
// $Log: scope.c $
// Revision 1.2  2001/11/02 21:32:11  obermuhl
// added double_mode
//
// Revision 1.1  2001/09/30 10:59:02  obermuhl
// Initial revision
//
//
//---------------------------------------------------------------------

#include <stdlib.h>

#include "scope.h"

Scope rootScope = { 16, 1, 0, 0 , 1, NULL, NULL};

Scope* currentScope = &rootScope;

Scope* pushScope()
{
  Scope *scope = (Scope*) malloc(sizeof(Scope));

  scope->base = currentScope->base;
  scope->size = currentScope->size;
  scope->padstring = currentScope->padstring;
  scope->padchar = currentScope->padchar;
  scope->double_mode = currentScope->double_mode;
  scope->prev = currentScope;
  scope->next = NULL;

  currentScope->next = scope;
  currentScope = scope;

  return currentScope;
}

Scope* popScope()
{
  if(currentScope != &rootScope) {
    Scope *oldScope = currentScope;
    currentScope = currentScope->prev;

    currentScope->next = NULL;
    free(oldScope);
  }

  return currentScope;
}

Scope* getCurrentScope()
{
  return currentScope;
}
