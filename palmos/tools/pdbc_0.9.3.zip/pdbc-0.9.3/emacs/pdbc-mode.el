;;; pdbc-mode.el --- pdbC (palm databank compiler) language mode
;;
;; Copyright (C) 2000-2001 by Free Software Foundation, Inc.
;;
;; Author: Eric Obermuhlner <eric@diagonal.ch> 
;; Maintainer: Eric Obermuhlner <eric@diagonal.ch> 
;; Keywords: languages pdbc palm database compile
;; Version: 0.1
;;

;; This file is part of GNU Emacs.

;; GNU Emacs is free software; you can redistribute it and/or modify
;; it under the terms of the GNU General Public License as published by
;; the Free Software Foundation; either version 2, or (at your option)
;; any later version.

;; GNU Emacs is distributed in the hope that it will be useful,
;; but WITHOUT ANY WARRANTY; without even the implied warranty of
;; MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
;; GNU General Public License for more details.

;; You should have received a copy of the GNU General Public License
;; along with GNU Emacs; see the file COPYING.  If not, write to the
;; Free Software Foundation, Inc., 59 Temple Place - Suite 330,
;; Boston, MA 02111-1307, USA.


;;; Commentary:
;;
;; $Id: pdbc-mode.el 1.1 2001/11/21 22:26:53 obermuhl Exp $
;;
;; A major mode for pdbC.
;;
;; It does support:
;; - syntax highlighting (font-lock)
;; - imenu (imenu, speedbar, ...)
;; - simple indentation (tab-key, newline)
;;

;;; Example code for your .emacs file
;;
;; (autoload 'pdbc-mode "pdbc-mode")
;;
;; (setq auto-mode-alist
;;      (append '(
;;		("\\.pdbc$" . pdbc-mode)
;;		("\\.pdc$" . pdbc-mode)
;;		) auto-mode-alist))
;;
;; ;In case you use speedbar:
;; ;(load-library "~/emacs/speedbar")
;; ;(speedbar-add-supported-extension ".pdbc")
;; ;(speedbar-add-supported-extension ".pdc")
;;

;;; History
;;
;; $Log: pdbc-mode.el $
;; Revision 1.1  2001/11/21 22:26:53  obermuhl
;; Initial revision
;;
;; Revision 1.2  2001/03/27 11:50:05  eric
;; - highlight include/includebin + its arg
;; - speedbar supports now 'record'
;;
;; Revision 1.1  2001/03/27 11:34:50  eric
;; Initial revision
;;
;;

;;; Code:

(defconst pdbc-is-xemacs (string-match "Lucid\\|XEmacs" emacs-version)
  "Non-nil means the running Emacs is a version of XEmacs or Lucid Emacs.")

(defvar pdbc-mode-syntax-table nil
  "Syntax table in use in pdbc buffers.")

(if pdbc-mode-syntax-table
    ()
  (let ((table (make-syntax-table)))
    (modify-syntax-entry ?\\ "\\" table)
    (modify-syntax-entry ?\( ". 1" table)
    (modify-syntax-entry ?\) ". 4" table)
    (modify-syntax-entry ?\/ ". 14" table)
    (modify-syntax-entry ?* ". 23" table)
    (modify-syntax-entry ?+ "." table)
    (modify-syntax-entry ?- "." table)
    (modify-syntax-entry ?= "." table)
    (modify-syntax-entry ?% "." table)
    (modify-syntax-entry ?< "." table)
    (modify-syntax-entry ?> "." table)
    (cond
     (pdbc-is-xemacs
      (modify-syntax-entry ?/  ". 1456" table)
      (modify-syntax-entry ?*  ". 23"   table))
     (t
      (modify-syntax-entry ?/  ". 124b" table)
      (modify-syntax-entry ?*  ". 23"   table)))
    (modify-syntax-entry ?\n "> b"  table)
    ;; Give CR the same syntax as newline, for selective-display
    (modify-syntax-entry ?\^m "> b" table)
    (setq pdbc-mode-syntax-table table)))



;;; Added by TEP
(defvar pdbc-mode-map nil
  "Keymap used in pdbC mode.")

(if pdbc-mode-map ()
  (let ((map (make-sparse-keymap)))
    (define-key map "\^M" 'pdbc-newline)
    (cond
     (pdbc-is-xemacs
      (define-key map "\^i" 'pdbc-tab))
     (t
      (define-key map [tab] 'pdbc-tab)
      (define-key map [C-tab] 'pdbc-untab)))
    (define-key map "\C-c\C-z" 'suspend-emacs)
    (setq pdbc-mode-map map)))


(defvar pdbc-indent 1 "*This variable defines the indentation step.")
  
;;;###autoload
(defun pdbc-mode ()
  "This is a mode intended to support program development with pdbC.

   `pdbc-indent' controls the number of spaces for each indentation.

Copyright (C) 2000-2001 by Free Software Foundation, Inc.

mailto:eric@diagonal.ch
"
  (interactive)
  (kill-all-local-variables)
  (use-local-map pdbc-mode-map)
  (setq major-mode 'pdbc-mode)
  (setq mode-name "pdbC")
  (set-syntax-table pdbc-mode-syntax-table)
  (make-local-variable 'paragraph-start)
  (setq paragraph-start (concat "$\\|" page-delimiter))
  (make-local-variable 'paragraph-separate)
  (setq paragraph-separate paragraph-start)
  (make-local-variable 'paragraph-ignore-fill-prefix)
  (setq paragraph-ignore-fill-prefix t)
  (make-local-variable 'comment-start)
  (setq comment-start "/* ")
  (make-local-variable 'comment-end)
  (setq comment-end " */")
  (make-local-variable 'comment-indent-function)
  (setq comment-indent-function 'c-comment-indent)
  (make-local-variable 'parse-sexp-ignore-comments)
  (setq parse-sexp-ignore-comments t)
  (make-local-variable 'font-lock-defaults)
  (setq font-lock-defaults
	'((pdbc-font-lock-keywords
	   pdbc-font-lock-keywords-1 pdbc-font-lock-keywords-2)
	  nil nil ((?_ . "w") (?. . "w") (?< . ". 1") (?> . ". 4")) nil
	  ;; Obsoleted by Emacs 19.35 parse-partial-sexp's COMMENTSTOP.
	  ;(font-lock-comment-start-regexp . "(\\*")
	  ))
  (make-local-variable 'imenu-generic-expression)
  (setq imenu-generic-expression pdbc-imenu-generic-expression)
  (run-hooks 'pdbc-mode-hook))


(defconst pdbc-font-lock-keywords-1
  '(
    ;;
    ;; Include files
    ("\\(\\<include\\>\\)"
     (1 font-lock-builtin-face nil t))
    ("\\<include\\>[ \t]+\\(\\sw+\\)?"
     (1 font-lock-string-face nil t))
    ("\\(\\<includebin\\>\\)"
     (1 font-lock-builtin-face nil t))
    ("\\<includebin\\>[ \t]+\\(\\sw+\\)?"
     (1 font-lock-string-face nil t))
    )
  "Subdued level highlighting for pdbC modes.")

(defconst pdbc-font-lock-keywords-2
  (append pdbc-font-lock-keywords-1
   (eval-when-compile
     (let ((pdbc-keywords
	    "b\\(ase\\|egin\\|in\\|yte\\)\\|dec\\|end\\|file\\|hex\\|long\\|oct\\|pad\\(char\\|string\\)\\|record\\|si\\(gned\\|ze\\)\\|unsigned\\|word"
	    )
	   (pdbc-attribs
	    "attrib\\|b\\(ackup\\(_date\\)?\\|usy\\)\\|c\\(ategory\\|reat\\(ion_date\\|orid\\)\\)\\|d\\(elete\\|irty\\)\\|filename\\|modification\\(_date\\)?\\|n\\(ewer\\|o\\(beam\\|w\\)\\)\\|re\\(adonly\\|set\\)\\|secret\\|typeid\\|uniqueid_seed\\|version"
	    )
	   )
      (list
	;;
	;; Keywords except those fontified elsewhere.
	(cons (concat "\\<\\(" pdbc-keywords "\\)\\>") 'font-lock-keyword-face)
	;;
	;; Type names.
	(cons (concat "\\<\\(" pdbc-attribs "\\)\\>") 'font-lock-type-face)
	))))
  "Gaudy level highlighting for pdbC modes.")

;; The following lines where used to generate the regexps for the keywords:
;(regexp-opt
; '(
;   "file" "record" 
;   "begin" "end"
;   "bin" "oct" "dec" "hex" "base" 
;   "byte" "word" "long" "size"
;   "padstring" "padchar"
;   "signed" "unsigned"
;))
;
;; The following lines where used to generate the regexps for the attribs:
;(regexp-opt
; '(
;   "filename" "attrib" "version"
;   "creation_date" "modification_date" "backup_date" "modification"
;   "typeid" "creatorid" "uniqueid_seed"
;   "readonly" "dirty" "backup" "newer" "reset" "nobeam"
;   "now" 
;   "secret" "busy" "delete" "category"
;))

(defconst pdbc-font-lock-keywords-1 pdbc-font-lock-keywords-1
  "Subdued level highlighting for pdbC modes.")

(defconst pdbc-font-lock-keywords-2 pdbc-font-lock-keywords-2
  "Gaudy level highlighting for pdbC modes.")

(defvar pdbc-font-lock-keywords pdbc-font-lock-keywords-1
  "Default expressions to highlight in pdbC modes.")



(defvar pdbc-imenu-generic-expression
  (` 
    (("Record" 
     (, (concat 
	 "\\<record\\>"
 	 )) 0)
    ))
  "Imenu generic expression for pdbC mode.  See `imenu-generic-expression'.")




(defun pdbc-newline ()
  "Insert a newline and indent following line like previous line."
  (interactive)
  (let ((hpos (current-indentation)))
    (newline)
    (indent-to hpos)))

(defun pdbc-tab ()
  "Indent to next tab stop."
  (interactive)
  (beginning-of-line)
  (skip-chars-forward " \t")
  (indent-to (* (1+ (/ (current-indentation) pdbc-indent)) pdbc-indent)))

(defun pdbc-untab ()
  "Indent to prev tab stop."
  (interactive)
  (beginning-of-line)
  (let ((beg (point)) (cur-indent (current-indentation)))
    (skip-chars-forward " \t")
    (delete-region beg (point))
    (indent-to (* (1- (/ cur-indent pdbc-indent)) pdbc-indent))))

(provide 'pdbc)

;;; pdbc-mode.el ends here


