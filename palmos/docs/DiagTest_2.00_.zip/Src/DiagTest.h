//**************************************************************
//
//  Project:
//	  Handspring Sample PalmOS Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  DiagTest.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
// 
//
// History:
//	  11-Feb-1999  - Created 
//***************************************************************/

#define resFormIDDiagTest			1000
									
#define resMenuIDDiagTest			1000

//#define resMenuItemConvert			1000
#define resMenuItemAbout			1001
//#define resMenuItemCopy				1002
//#define resMenuItemPaste			1003

#define resBitmapIDText				1000
#define resBitmapIDHex				1001
									
//#define resFieldIDText				1000
//#define resFieldIDHex				1001

#define resButtonIDRedOn			1003
#define resButtonIDRedOff			1004
//#define resButtonIDConvert			1002

									
#define resAlertIDAbout				1000
//#define resAlertIDErrNullStr		1001	
									
									
