/***************************************************************
 *
 *  Project:
 *	  Handspring Diagnostic Springboard Reference Module Test App.
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  DiagTest.c
 * 
 *  Description:
 *		This is the main source file for the sample application. 
 *		The DiagTest application demonstrates the use of Handspring
 *		extension APIs to register and control the interrupt handler
 *		(ISR) and other event handlers.  The application also
 *		demonstrate how to access module's hardware control through
 *		Handspring's Try and Catch protection.
 *
 * ToDo:
 *
 * History:
 *	  04-May-2000  FV  - Created 
 ****************************************************************/

#include <PalmOS.h>
#include <SystemPublic.h>
#include <CoreCompatibility.h>


// Include Handspring extensions for removable card support
#include <HsExt.h>

#include "Resource.h"


// -------------------------------------------------------------
// Constants
// -------------------------------------------------------------
#define DiagDBCreator    'Diag'   // ?? in hexadecimal
#define DiagHexDBType	 'Data'   // ?? in hexadecimal



// -------------------------------------------------------------
// Prototypes
// -------------------------------------------------------------
static void		EventLoop (void);
static void		StopApplication(void);
static Boolean	MainFrmEventHandler (EventPtr event);

//**********************************************************************
//  Constants
//**********************************************************************

#define	serHwBaseOffset	0x2007F0
#define	SLatchOffset	0x800000
#define	CRegOffset		0xC00000

#define	UARTModemLEDCtl		0x04
#define	UARTModemLEDOffset	0x08

#define LED_OFF			0x00
#define LED_ON			0x01
#define MaskLED			0xFE

#define ClearPBInt		0x02
#define SetPBInt		0x04
#define EnablePBInt		0x06
#define MaskPBInt		0xF9

//**********************************************************************
//  Structures
//**********************************************************************
typedef struct 
{
			Word			cardNo;				// card number
		
			BytePtr			CRegPtr;			// address of Control Register
			WordPtr			SLatchPtr;			// address of Status Latch
volatile	Boolean			BusErr;				// occurence of Bus Error

} DiagTestGlobalsType;

//**********************************************************************
//  Globals
//**********************************************************************
DiagTestGlobalsType		gDT;
Word			cardNo = 1;

BytePtr			UartPtr ;			// address of UART
BytePtr			CRegPtr;			// address of Control Register
WordPtr			SLatchPtr;			// address of Status Latch
		
Byte			CRegVal;			// value of Control Register
Word			SLatchVal;			// value of Status Latch

Boolean			codeLocked;
volatile Boolean			BusErr;				// occurence of Bus Error

FieldPtr		FieldTextP;     
char			InterruptStatus[20];


/***********************************************************************
 *
 * Function:     ClearRedLED
 *
 * Description:  Turns off the Red LED controlled by the Diagnostic Card's
 *					Control Register at offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *	  StopApplication()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
ClearRedLED( void )
{

	HsCardErrTry
	{
	  CRegVal = (CRegVal & MaskLED ) | LED_OFF;	
	  *CRegPtr = CRegVal;
	}

	HsCardErrCatch
	{
	}HsCardErrEnd

}

/***********************************************************************
 *
 * Function:     SetRedLED
 *
 * Description:  Turns on the Red LED controlled by the Diagnostic Card's
 *					Control Register at offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
SetRedLED( )
{

	HsCardErrTry
	{
	  CRegVal = (CRegVal & MaskLED ) | LED_ON;	
	  *CRegPtr = CRegVal;
	}

	HsCardErrCatch
	{
	}HsCardErrEnd

}


/***********************************************************************
 *
 * Function:     ClearGreenLED
 *
 * Description:  Turns off the Green LED controlled by the Diagnostic Card's
 *					UART Register at offset 0x7F0 + 0x8
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *	  StopApplication()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
ClearGreenLED( )
{
  BytePtr	TempPtr = (UartPtr + UARTModemLEDOffset);

	HsCardErrTry
	{
	  *TempPtr &= ~UARTModemLEDCtl;

	}

	HsCardErrCatch
	{
	}HsCardErrEnd

}

/***********************************************************************
 *
 * Function:     SetGreenLED
 *
 * Description:  Turns on the Green LED controlled by the Diagnostic Card's
 *					UART Register at offset 0x7F0 + 0x8
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
SetGreenLED( )
{
  BytePtr	TempPtr = (UartPtr + UARTModemLEDOffset);

	HsCardErrTry
	{
	  *TempPtr |= UARTModemLEDCtl;
	}

	HsCardErrCatch
	{
	}HsCardErrEnd

}


/***********************************************************************
 *
 * Function:     EnableInterrupt
 *
 * Description:  Enables the interrupt control for the push-button and 
 *					software interrupts controlled by the Diagnostic Card's
 *					Control Register at offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *	  StartApplication()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
EnableInterrupt( )
{

	HsCardErrTry
	{
	  CRegVal = (CRegVal & MaskPBInt) | EnablePBInt;
	  *CRegPtr = CRegVal;
	}

	HsCardErrCatch
	{
		BusErr = true;
	}HsCardErrEnd

}

/***********************************************************************
 *
 * Function:     ClearInterrupt
 *
 * Description:  Clears (deasserts) the interrupt control for the push-button  
 *					and software interrupts controlled by the Diagnostic Card's
 *					Control Register at offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *	  StartApplication()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
ClearInterrupt( )
{

	HsCardErrTry
	{
	  CRegVal = (CRegVal & MaskPBInt) | ClearPBInt;
	  *CRegPtr = CRegVal;
	}

	HsCardErrCatch
	{
	}HsCardErrEnd

}


/***********************************************************************
 *
 * Function:     SetInterrupt
 *
 * Description:  Sets (asserts) the interrupt control for the push-button  
 *					and software interrupts controlled by the Diagnostic Card's
 *					Control Register at offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
void
SetInterrupt( )
{

	HsCardErrTry
	{
	  CRegVal = (CRegVal & MaskPBInt) | SetPBInt;
	  *CRegPtr = CRegVal;

	  // Set the CRegVal back to the Enable Interrupt state because 
	  // the Interrupt handler sets the Control Register to Enable Interrupt
	   CRegVal = (CRegVal & MaskPBInt) | EnablePBInt;

	}

	HsCardErrCatch
	{
	}HsCardErrEnd
  
}


/***********************************************************************
 *
 * Function:     ReadLatchStatus
 *
 * Description:  Reads the 16-bit register value from the 
 *					Diagnostic Card's Status Latch offset 0xC00000
 *
 * Parameters:   
 *	  void 
 *               
 * Returns:      
 *	  Dword		16-bit Value from the Status Latch
 *
 * Called By:
 *	  MainFrmEventHandler()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
static Word
ReadStatusLatch( )
{

	HsCardErrTry
	{
	  // Read Latch value into global variable
	  SLatchVal = *SLatchPtr;
	}

	HsCardErrCatch
	{
	}HsCardErrEnd

	return SLatchVal;
 
}

/***********************************************************************
 *
 * Function:     UpdateInterruptStatus
 *
 * Description:  Reads the state of the push-button and software 
 *					interrupts captured by the Diagnostic Card's
 *					Status Latch at offset 0x800000
 *
 * Parameters:   
 *	  Boolean		Enable:  controls text field update message
 *					true will update text field as "Interrupt Enable"
 *					false (not true )will update text field as "Interrupt Disable"
 *               
 * Returns:      
 *	  void
 *
 * Called By:
 *	  MainFrmEventHandler()
 *
 * History:
 *	  04-Mar-2000  FV	  Created
 *
 ***********************************************************************/
static void
UpdateInterruptStatus( Boolean Enable )
{

	if ( Enable )
		StrCopy (InterruptStatus, "Interrupt Enable");
	else
		StrCopy (InterruptStatus, "Interrupt Disable");

	FldSetTextPtr (FieldTextP, InterruptStatus);
	FldRecalculateField (FieldTextP, true);
	FrmDrawForm (FrmGetActiveForm());

}



/***********************************************************************
 *
 * Function:     CardInterruptHandler
 *
 * Description: Card Interrupt handler for Diagnostic Card's push-button
 *				and software control interrupts.
 *
 *	  All card interrupt handlers can be called from one of two possible
 *	  states of the device:
 *
 *	  
 *
 * Parameters:   
 *	  cardParam		IN		Parameter to interrupt routine setup through
 *							the hsCardAttrCardParam attribute of HsCardAttrSet()
 *							In our case, this is a pointer to a structure
 *							of type DiagTestGlobalsType (defined above)
 *							which has a pointer to the globals inside of it. 
 *
 *	  *sysAwakeP	INOUT	This flag tells us if the system is fully awake
 *							or not. If this flag is false, the interrupt
 *							routine CAN NOT MAKE ANY SYSTEM CALLS except
 *							for HsCardErrTry/HsCardErrCatch. If the interrupt
 *							requires use of the system (to set a semaphore
 *							for example), then the handler
 *							should return without clearing the interrupt
 *							source and set the *sysAwakeP flag on exit.
 *
 *						  
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  System when card interrupt is asserted
 *
 * Notes:
 *
 *
 * History:
 *	  04-May-1000 FV	  Created
 *
 ***********************************************************************/
static void 
CardInterruptHandler (DWord cardParam, Boolean* sysAwakeP)
{
	DiagTestGlobalsType*	  gP = (DiagTestGlobalsType*) cardParam;
	volatile Byte	CRegVal;	// use volatile so each update actually executes
	BytePtr	CRegPtr;			// Control Register address

	HsCardErrTry
	{

		// Get Control Register address from global variable
		CRegPtr = gP->CRegPtr;
		
		// Note:  There is a hardware limitation where the 
		// Control Register value cannot be read back.  Thus
		// we will clear the interrupt and go to the enable
		// state.  (The Red LED state is not known unless we 
		// pass a global from the app level to the interrupt
		// handler's kenerl level.  This must be done everytime
		// the LED change state at the app level.  For this sample,
		// we will ignore the previous Red LED state and just turn
		// the Red LED off.)

		// Clear the interrupt and go to the enable state
		
		CRegVal = (CRegVal & MaskPBInt) | ClearPBInt;
		*CRegPtr = CRegVal;
		CRegVal = (CRegVal & MaskPBInt) | EnablePBInt;
		*CRegPtr = CRegVal;

		// Developer can choose either the app or card event handler to notify
		HsAppEventPost( 1, 1 );
		//HsCardEventPost( 1, 1, 1 );
	}

	HsCardErrCatch
	{
		// Set global variable that Bus Err occured so App can check
		gP->BusErr = true;	
		HsCardAttrSet ( gP->cardNo, hsCardAttrCardParam, &gP );

	}HsCardErrEnd

}


/***************************************************************
 *	Function:	  AppEventHandler
 *
 *	Summary:	  Application event handler that gets called
 *	  from within the main event loop of the current application
 *	  soon after the card's interrupt handler enqueues a
 *	  card event using HsAppPostEvent()
 *
 *	Parameters:
 *	  evtRefCon		IN	  Event reference condition
 *	  evtNum		IN	  Event number passed to HsCardPostEvent()
 *						   can be any value between 0 and
 *						   hsMaxCardEvent. 
 *	  evtParam		IN	  16 bit event parameter passed to
 *						   HsAppPostEvent()
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  Main event loop of the current application  as a result
 *	  of an interrupt routine enqueing a card event using
 *	  HsAppPostEvent()
 *	
 *	History:
 *	  04-May-2000  FV  Created  
 *
 ****************************************************************/
static void	 
AppEventHandler (DWord evtRefCon, Word evtNum, Word evtParam)
{
	// For simplicity, just play a beep and 
	//  put up can put up an alert.
	SndPlaySystemSound (sndInfo);
	
	FrmAlert (resAlertIDInterrupt);
}


/***************************************************************
 *	Function:	  CardEventHandler
 *
 *	Summary:	  Stub of a card event handler that gets called
 *	  from within the main event loop of the current application
 *	  soon after the card's interrupt handler enqueues a
 *	  card event using HsCardPostEvent()
 *
 *	Parameters:
 *	  cardParam		IN	  what's stored in hsCardAttrCardParam
 *	  evtNum		IN	  Event number passed to HsCardPostEvent()
 *						   can be any value between 0 and
 *						   hsMaxCardEvent. 
 *	  evtParam		IN	  16 bit event parameter passed to
 *						   HsCardPostEvent()
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  Main event loop of the current application  as a result
 *	  of an interrupt routine enqueing a card event using
 *	  HsCardPostEvent()
 *	
 *	History:
 *	  04-May-2000  FV  Created  
 *
 ****************************************************************/
static void	 
CardEventHandler (DWord cardParam, Word evtNum, Word evtParam)
{


	// For simplicity, just play a beep and 
	//  put up can put up an alert.
	SndPlaySystemSound (sndInfo);
	
	FrmAlert (resAlertIDInterrupt);
}


/***************************************************************
 *	Function:	  MainFrmEventHandler
 *
 *	Summary:	  Event handler for our main form. 
 *
 *	Parameters:
 *	  eventP	  IN	pointer to event to handle
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  FrmDispatchEvent() when event is for our main form. 
 *	  FrmDispatchEvent() is called by our AppEventLoop() 
 *	
 *	Notes:
 *	
 *	History:
 *	  04-May-1999  FV  Created 
 *
 ****************************************************************/
static Boolean 
MainFrmEventHandler (EventPtr event)
{
  FormPtr   formP;
  int       handled = 0;

  switch (event->eType) 
	{
	case frmOpenEvent:
	  formP = FrmGetActiveForm();

	  FieldTextP = FrmGetObjectPtr (formP, 
		  FrmGetObjectIndex (formP, resFieldIDStatus));
	  
	  UpdateInterruptStatus( true /*Enable*/ );
	  
	  handled = 1;
	  break;
    
	case ctlSelectEvent:  // A control button was pressed and released.

	  switch (event->data.ctlEnter.controlID) 
		{

		case resButtonIDRedOn:
		  SetRedLED( );
		  handled = 1;
		  break;

		case resButtonIDRedOff:
		  ClearRedLED( );
		  handled = 1;
		  break;

		case resButtonIDGreenOn:
		  SetGreenLED( );
		  handled = 1;
		  break;

		case resButtonIDGreenOff:
		  ClearGreenLED( );
		  handled = 1;
		  break;

		case resButtonIDEnableInt:
		  EnableInterrupt( );
		  UpdateInterruptStatus( true /*Enable*/ );
		  handled = 1;
		  break;

		case resButtonIDClearInt:
		  ClearInterrupt( );
		  UpdateInterruptStatus( false /*Disable*/ );
		  handled = 1;
		  break;

		case resButtonIDSetInt:
		  SetInterrupt( );
		  UpdateInterruptStatus( true /*Enable*/ );
		  handled = 1;
		  break;

		case resButtonIDReadInt:
		{
		  Word		Status;

		  Status = ReadStatusLatch( ) & 0x80;
		  FrmCustomAlert(resAlertIDSW_IRQ, "SW_IRQ is", Status? "ON" : "OFF", NULL);
 
		  handled = 1;
		  break;
		}

	  }		// end switch (event->data.ctlEnter.controlID)

	  break;

	case menuEvent:
	  switch (event->data.menu.itemID)
		{
		case resMenuItemAbout:
		  FrmAlert(resAlertIDAbout);
		  break;
		}
	  handled = 1;
	  break;

	case nilEvent:
	  handled = 1;
	  break;

	default:
	  break;

	}	// end  switch (event->eType) 

  return handled;
}



/***************************************************************
 *	Function:	  StopApplication
 *
 *	Summary:	  Application de-initialization of StartApplication
 *		
 *		This Application is intended to run on the internal memory.
 *		It will run independent without the CardSetup app, so it must
 *		supply all the intialization code of a normal CardSetup app:
 *		- Unregister interrupt handler
 *		- disable interrupt
 *		- Deassociate globals to HsCardAttrParam for interrupt handler
 *		- Unlock code resource for interrupt handler
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  PilotMain, after EventLoop returns
 *	
 *	Notes:
 *	
 *	History:
 *	  04-May-2000  FV  Created 
 *
 ****************************************************************/
static void 
StopApplication (void)
{
  VoidHand		codeResH;
  DWord			value;
  Byte			enable;

  ClearInterrupt( );
  ClearRedLED( );
  ClearGreenLED( );

  // ===================================================================
  // Remove our interrupt routine if installed
  // ===================================================================

  enable = 0;
  HsCardAttrSet ( cardNo, hsCardAttrIntEnable, &enable);

  value = 0;
  HsCardAttrSet ( cardNo, hsCardAttrIntHandler, &value);

  // Disassociate from the card
  HsCardAttrSet (cardNo, hsCardAttrCardParam, &value);


  // ---------------------------------------------------------
  // Because we locked our code resource down to install power and event
  //  handlers (and/or patches), restore the lock count now
  // ---------------------------------------------------------
  if (codeLocked)
	{
	  codeResH = DmGet1Resource ('code', 1);
	  if (codeResH)
		MemHandleUnlock (codeResH);
	  else
		{
		  ErrNonFatalDisplay ("couldn't get code resource");
		}
	  
	  codeLocked = false;
	}

}

/***************************************************************
 *	Function:	  StartApplication
 *
 *	Summary:	  Application initialization when being launched
 *		as a normal application (i.e. not to execute an action code).
 *		
 *		This Application is intended to run on the internal memory.
 *		It will run independent without the CardSetup app, so it must
 *		supply all the intialization code of a normal CardSetup app:
 *		- Get the Card base address
 *		- Register interrupt handler
 *		- enable interrupt
 *		- Sets and pass globals to HsCardAttrParam for interrupt handler
 *		- Lock code resource for interrupt handler
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain when action code is for a normal launch. 
 *	
 *	Notes:
 *	
 *	History:
 *	  04-May-2000  FV  Created 
 *
 ****************************************************************/
static Err 
StartApplication (void)
{
	DWord		handlerP = 0;
	Err			err = 0;
	VoidHand	codeResH; 
	Byte		enable;
	DWord		base, size;
	
	DiagTestGlobalsType*		gP = &gDT;

	FrmGotoForm (resFormIDDiagTest);


	  // Assume card 1.  For real applications, the CardSetup will receive 
	  // the card number from the launch command parameter block and save 
	  // to the global variable
	  gDT.cardNo = cardNo; 

	  // ===================================================================
	  // Get the base address of the UART. It's addressed through csSlot1 so
	  //  we take the CsBase and add CsSize to it
	  // ==================================================================
	  err = HsCardAttrGet (cardNo, hsCardAttrCsBase, &base);
	  if (err)
		return err;

	  err = HsCardAttrGet (cardNo, hsCardAttrCsSize, &size);
	  if (err)
		return err;

	  gDT.CRegPtr = CRegPtr = (BytePtr) (base + size + CRegOffset);
	  gDT.SLatchPtr = SLatchPtr = (WordPtr) (base + size + SLatchOffset);
	  UartPtr = (BytePtr) (base + size + serHwBaseOffset);

	  // Test if module is inserted by enabling module's interrupt
	  EnableInterrupt( );
	  if ( BusErr )
	  {
		  // FrmCustomAlert(resAlertInitErr, NULL, NULL, NULL);
		  return BusErr;
	  }
	// ===================================================================
	// Install our interrupt routine
	// ===================================================================
	handlerP = (DWord) CardInterruptHandler;
	err = HsCardAttrSet ( cardNo, hsCardAttrIntHandler, &handlerP);
	if (err) 
		return err;

	// Register the AppEventHandler to receive HsAppEventPost messages
	handlerP = (DWord) AppEventHandler;
	err = HsAppEventHandlerSet ( (void *) handlerP, 0x12345678 /*evtRefCon*/);
	if (err) 
		return err; 

	// Register the CardEventHandler to receive HsCardEventPost messages
	handlerP = (DWord) CardEventHandler;
	err = HsCardAttrSet( cardNo, hsCardAttrEvtHandler, &handlerP );
	if (err) 
		return err;

	// Enable system to receive card interrupts
	enable = true;
	err = HsCardAttrSet ( cardNo, hsCardAttrIntEnable, &enable);


	// Store globals pointer as the card param
	err = HsCardAttrSet ( cardNo, hsCardAttrCardParam, &gP );
	if (err) 
		return err;

  // Because we installed a power and event handler, and/or a patch from
  //  this code resource, make sure this code resource remains locked
  //  down after we exit. 
  codeResH = DmGet1Resource ('code', 1);
  if (codeResH)
	{
	  MemHandleLock (codeResH);

	  codeLocked = true;	// so we will be sure to unlock it
								//  in PrvRemove
	}
  else
	{
	  ErrNonFatalDisplay ("couldn't get code resource");
	}


	return err; 

}

 
/***************************************************************
 *	Function:	  EventLoop
 *
 *	Summary:	  Main event loop for the application
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  PilotMain after initializing. 
 *	
 *	Notes:
 *	
 *	History:
 *	  04-May-2000	FV  Created 
 *
 ****************************************************************/
static void 
EventLoop(void)
{
  short		err;
  int		formID;
  FormPtr	formP;
  EventType event;

  do
	{

	  EvtGetEvent (&event, sysTicksPerSecond/2);

	  if (SysHandleEvent (&event)) continue;
	  if (MenuHandleEvent ((void *)0, &event, &err)) continue;

	  if (event.eType == frmLoadEvent)
		{
		  formID = event.data.frmLoad.formID;
		  formP = FrmInitForm (formID);
		  FrmSetActiveForm (formP);

		  switch (formID) 
			{
			case resFormIDDiagTest:
			  FrmSetEventHandler (formP, (FormEventHandlerPtr) MainFrmEventHandler);
			  break;
			}
		}

	  FrmDispatchEvent(&event);

	 } while(event.eType != appStopEvent);
}



/***************************************************************
 *	Function:	  PilotMain
 *
 *	Summary:	  Entry point
 *
 *	Parameters:
 *	  cmd		  IN	Action code for the app. This is one of the
 *						  action codes sysAppLaunchCmdXXX defined in
 *						  <SystemMgr.h>
 *	  cmdPBP	  IN	Parameter block pointer for action code. 
 *	  launchFlags IN	Launch flags, one or more of 
 *						  sysAppLaunchFlagXXX defined in <SystemMgr.h>
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PalmOS when launching the app or asking it to execute an
 *		action code like find or goto. 
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  04-May-2000  FV  Created 
 *
 ****************************************************************/
DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  Err err = 0;

  if (cmd == sysAppLaunchCmdNormalLaunch)
  {
	  err = StartApplication();
	  
	  EventLoop();					// Event loop

	  StopApplication();			// Application stop code
  }

  return err;
}

