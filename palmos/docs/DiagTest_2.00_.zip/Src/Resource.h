//**************************************************************
//
//  Project:
//	  Handspring Sample PalmOS Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  Resource.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
// 
//
// History:
//	  31-Dec-1999  - Created 
//***************************************************************/

#define resFormIDDiagTest			1000
									
#define resMenuIDDiagTest			1000

#define resMenuItemAbout			1001

#define resBitmapIDText				1000
#define resBitmapIDHex				1001

#define resButtonIDRedOn			1003
#define resButtonIDRedOff			1004
#define resButtonIDGreenOn			1005
#define resButtonIDGreenOff			1006

#define resButtonIDEnableInt		1007
#define resButtonIDClearInt			1008
#define resButtonIDSetInt			1009
#define resButtonIDReadInt			1010
#define resFieldIDStatus			1011

#define resAlertIDAbout				1000
#define resAlertIDSW_IRQ			1001
#define resAlertIDInterrupt			1002
#define resAlertInitErr				1003


									
									
