/*******************************************************************
 *
 * Project:
 *	  Handspring Developer Reference Card
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  HsSerModulePublic.h
 *
 * Description:
 *	  Public header file for the Serial Module.
 *	This header file defines the public structures and APIs of our card.
 *
 *
 * History:
 *	  15-Nov-1999		Created by Vitaly Kruglikov  
 *
 *******************************************************************/


#ifndef   __HS_SER_MODULE_PUBLIC_H__
#define   __HS_SER_MODULE_PUBLIC_H__



//**********************************************************************
//  Constants
//**********************************************************************


//**********************************************************************
//  Master globals structure.
// 
//  A pointer to these globals is stored in the hsCardAttrCardParam
//	  attribute of the card using HsCardAttrSet(). See comments at
//    top of this header for more info
//**********************************************************************
typedef struct
  {
	DWord			serSendCalls;	// # of calls to SerSend
	DWord			sendReqTotal;	// X total # of bytes requested to send
	DWord			sendQTotal;		// X total # of bytes actually added to transmit queue
	DWord			sendTicks;		// X # of ticks spent in SerSend
	DWord			maxSendTicks;	// X max # of ticks spent in SerSend
	DWord			maxSendTicksReq;// X SerSend request bytes of maxSendTicks
	DWord			maxSendReq;		// X max SerSend request block size
	DWord			sendErrors;		// X total # of send errors in SerSend
	DWord			sendTimeouts;	// X count of SerSend timeouts
	DWord			sendTotal;		// X total # of bytes sent to TX FIFO

	DWord			serReceiveCalls;// # of calls to SerReceive
	DWord			recvReqTotal;	// X total # of bytes requested to receive
	DWord			recvDQTotal;	// X total # of bytes actually dequeued
	DWord			recvTicks;		// X # of ticks spent in SerReceive
	DWord			maxRecvTicks;	// X max # of ticks spent in SerReceive
	DWord			maxRecvReq;		// X max SerReceive request block size
	DWord			recvErrors;		// X total # of SerReceive errors
	DWord			recvTimeouts;	// X count of SerReceive timeouts
	DWord			recvTotal;		// X total # of bytes pulled from RX FIFO
	DWord			lineErrors;		// X total # of line errors
	DWord			hwOverrunErrors;// X # of HW Overrun errors
	Word			maxSendBurst;	// X max number of bytes placed
									//  in the transmit FIFO during
									//  a single envokation of the ISR
	Word			maxRecvBurst;	// X max number of bytes collected
									//  from the receive FIFO during
									//  a single envokation of the ISR
	DWord			totalISRCalls;	// X # of times the ISR was called
	DWord			lineErrISRTriggers;	// X
	DWord			sendISRTriggers;// X
	DWord			recvISRTriggers;// X
	DWord			msrISRTriggers;	// X modem status register
	DWord			rtsISRTriggers;	// X RTS & CTS
	DWord			xoffISRTriggers;// X
	DWord			otherISRTriggers;// X

  } HsSerModPerfType;


typedef enum
  {
	hsSerModReqAttrGet = 1,		// pb: HsSerModAttrGetType
	hsSerModReqAttrSet = 2		// pb: HsSerModAttrSetType

  } HsSerModReqEnum;

typedef enum
  {
	hsSerModAttrPerfMonEnabled = 1,	// R/W: gets/sets perfMon enabled setting
									//  arg: Byte

	hsSerModAttrPerfData = 2		// R/W:
									// reading gets performance data:
									//  arg: HsSerModPerfType
									// writing clears performance data:
									//  arg: NULL
  } HsSerModAttrEnum;

typedef struct
  {
	Word		  attrID;		// IN:  attribute id (HsSerModAttrEnum)
	VoidPtr		  argP;			// OUT: ptr to buffer for attribute data
	UInt32		  argSize;		// IN/OUT: size of argP buffer; size of
								//     data returned in the buffer;
  } HsSerModAttrGetType;

typedef struct
  {
	Word		  attrID;		// IN:  attribute id (HsSerModAttrEnum)
	VoidPtr		  argP;			// IN:  ptr to attribute data
	UInt32		  argSize;		// OUT: size of attribute data;
  } HsSerModAttrSetType;


#define hsSerModReqSignature	'SmRq'

typedef struct
  {
	// cardNo MUST be first and MUST be of size Word because
	//  the action code handler expects this
	Word		  cardNo;		// IN:  cardNo (set to cardNo of module)
	DWord		  signature;	// IN:  must be set to hsSerModReqSignature
	Word		  reqSize;		// IN:	size of this structure
	Word		  reqID;		// IN:  request id (HsSerModReqEnum)
	VoidPtr		  pbP;			// IN:  ptr to parameter block of the request
	UInt32		  pbSize;		// IN:  size of the parameter block

	Word		  handled;		// OUT: set to non-zero if handled
	DWord		  err;			// OUT: error code
	
  } HsSerModReqType;



// Command we use when sending a request to our CardSetup app
#define hsSerModCmdProcessRequest	  (sysAppLaunchCmdCustomBase+1000)


#endif   // __HS_SER_MODULE_PUBLIC_H__

