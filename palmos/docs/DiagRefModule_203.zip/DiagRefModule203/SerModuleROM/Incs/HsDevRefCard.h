/*******************************************************************
 *
 * Project:
 *	  Handspring Developer Reference Card
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  HsDevRefCard.h
 *
 * Description:
 *	  Common header file for the Handspring Developer Reference Card.
 *	This header file defines the structure of our card globals. These
 *  globals are allocated and initialized by the card setup utility 
 *	(../Apps/CardSetup) when the card is intalled and freed by the
 *  same utility when the card is pulled.
 *
 *	  A pointer to these globals are stored in the hsCardAttrCardParam
 *	of the card using HsCardAttrSet(). This param is always passed to the
 *	card's interrupt and power handlers.  The interrupt handler for the
 *	serial library on the card then gets it's own globals out of this 
 *	master globals structure. 
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *
 *******************************************************************/

#ifndef   __HSDEVREFCARD_H__
#define   __HSDEVREFCARD_H__



// Include our public equates. This header defines the public API and structures
//  for accessing diagnostic information via action code calls to our CardSetup
//  application.
#include  "HsSerModulePublic.h"


//**********************************************************************
//  Constants
//**********************************************************************

// Creator & type of the database that contains the serial library we 
//  install
// IMPORTANT: If these values change, the makefile for the library
//   (../Libraries/Ser16650/Build/Makefile)  must be manually updated
#define	  hsDrcSerLibDbType		  'libr'
#define	  hsDrcSerLibDbCreator	  'HsCs'
#define	  hsDrcSerLibDbName		  "CardSerial Library"

// Library name of the serial library. This is the name passed to
//  SysLibFind() to locate the database. Note that this can be,
//  but isn't required to be, the same as the database name of the
//  database that contains the library.  The maximum size for the
//  library name is 31 (thirty one) characters
#define	  hsDrcSerLibName		  "CardSerial Library"



// Feature numbers based on hsDrcSerLibDbCreator (passed to FtrGet, FtrSet,
//  FtrUnregister) -- ***these features are private to each implementation***

// Card number of the module.  CardSetup "install" handler sets this
//  feature to the module's card number, via
//  FtrSet(hsDrcSerLibDbCreator, hsDrcFtrNumCardNo, cardNo);
//  the "remove" handler unregisters this feature; the cardNo may be
//  retrieved via
//  err = FtrGet (hsDrcSerLibDbCreator, hsDrcFtrNumCardNo, &cardNo);
//
#define	  hsDrcFtrNumCardNo		  1	  


// Here is a snippet of code on how we implemented the Soft Reset
// Protection from within a application running from RAM.


// Definitions for function types that are used to implement module removal 
// safeguard by closing opened libraries when removal is detected. 

// Function type to patch SysHandleEvent()
typedef Boolean SysHandleEventFuncType ( EventPtr );

// Function type to define application PilotMain() callback
typedef DWord AppPilotMainCallBackFuncType ( void );

// Function type to define application PilotMain() hook
typedef DWord PilotMainHookFuncType ( AppPilotMainCallBackFuncType * procP, void * CleanUpParamP);


//**********************************************************************
//  Master globals structure.
// 
//  A pointer to these globals is stored in the hsCardAttrCardParam
//	  attribute of the card using HsCardAttrSet(). See comments at
//    top of this header for more info
//**********************************************************************
typedef struct 
  {
	Word	cardNo;					// saved module card number passed to Setup
									//  by Handspring Extensions
	
	LocalID	serLibDbID;				// database ID of the serial library
									//  we copy to internal RAM. 
	void*	serLibGlobalsP;			// pointer to serial library globals
	Word	serLibRefNum;			// library refNum of serial library

	ULong	netLibCheckEndTicks;	// HACK: our remove handler needs to call
									//  NetLibOpenCount, which will hang
									//  under PalmOS v3.1.x if called while NetLib
									//  is displaying UI (such as the connection
									//  progress dialog).  Before calling
									//  NetLibOpenCount, we intercept SysTaskSwitching,
									//  which is called by periodically by NetLib.
									//  Then, our private version of SysTaskSwitching
									//  will check whether this end time has been
									//  exceeded, and soft-reset the system if so.

	// Saved serial library names from HsPrefGet. Our Welcome application
	//  allows the user to change one or more of these to point to
	//  the card's serial library
	struct
	  {
		Char	def [dmDBNameLength];
		Char	hotSyncLocal [dmDBNameLength];
		Char	hotSyncModem [dmDBNameLength];
		Char	irda [dmDBNameLength];
		Char	console[dmDBNameLength];
	  } serLib;


	Boolean	codeLocked;					// Set by PrvInstall when the CardSetup
										//  code resource is locked, cleared
										//  by PrvRemove when it's unlocked
	Boolean	sysLibFindPatched;			// Set when SysLibFind is patched
										//  by PrvInstallSysLibFindPatch in
										//  CardSetup.c and cleared when the
										//  patch is removed by
										//  PrvRemoveSysLibFindPatch.
	Boolean	sysHandleEventPatched;
	Boolean	evtGetEventPatched;

	Boolean				perfMonOn;		// set to non-zero when performance
										//  monitoring is on
	HsSerModPerfType	serPerfMon;		// performance monitoring info
	 
	PilotMainHookFuncType	*AppPilotMainHook;

  } HsDrcGlobalsType;





#endif   // __HSDEVREFCARD_H__

