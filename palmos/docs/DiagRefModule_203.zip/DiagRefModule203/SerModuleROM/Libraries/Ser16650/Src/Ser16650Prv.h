/*******************************************************************
 *
 * Project:
 *	  Serial 16650 Library
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  Ser16650Prv.h
 *
 * Description:
 *	  Sample removable card library for the Handspring Developer
 *	  Reference Card.  This library provides an interface to the
 *	  ST16C650A UART on the card and is API conpatible with the 
 *	  PalmOS Serial Library.  
 *
 *	  This file contains the hardware specific equates for the 16650
 *	  UART on the card. 
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *
 *******************************************************************/


#ifndef   __SER16650PRV_H__
#define   __SER16650PRV_H__


//**********************************************************************
//  Constants
//**********************************************************************

// Offset from 2nd chip select to start of UART registers
// The UART is decoded at csSlot1 + 0x00200000 and it's registers
//  start at (0x3F8 * 2) and are every other byte
#define	  serHwBaseOffset	0x2007F0


// Name of card with our UART on it
#define	  serHwCardName		"HsSerRefModule"

// Version required
#define	  serHwCardVersion	0x0100


/*
 -VERSION_00 is the Handspring Diagnostic module in a standard plastic
             with integrated DB-9.
             UART's crystal frequency is 1.8432MHz

 -VERSION_01 is the EFIG.com Diagnostic module in a Battery module plastic
             with right angle header + cable to DB-9
             UART's crystal frequency is 7.3728MHz
*/
// Clock speed
#ifdef VERSION_00
	#define	  serHwClockFreq	1843200
#else if VERSION_01
	#define	  serHwClockFreq	7372800
#endif

//**********************************************************************
//  Structures
//**********************************************************************

// For reading
typedef	volatile  struct
  {
	Byte  recData;		// 000:	  7F0: receive data register
	Byte  _filler1;		// 

	Word  _filler2;		// 001:	  7F2:

	Byte  intStatus;	// 010:	  7F4: interrupt status
	Byte  _filler3;

	Word  _filler4;		// 011:	  7F6:

	Word  _filler5;		// 100:	  7F8:

	Byte  lineStatus;	// 101:	  7FA: line status
	Byte  _filler6;

	Byte  modemStatus;	// 110:	  7FC: modem status
	Byte  _filler7;

	Byte  scratch;		// 111:	  7FE: scratch pad
	Byte  _filler8;

  } SerHw16650ReadType;


// For writing
typedef	volatile  struct
  {
	Byte  sendData;		// 000:	  7F0: send data 
	Byte  _filler1;

	Byte  intEnable;	// 001:	  7F2: interrupt enable 
	Byte  _filler2;

	Byte  fifoControl;	// 010:	  7F4: FIFO control 
	Byte  _filler3;

	Byte  lineControl;	// 011:	  7F6: Line Control
	Byte  _filler4;

	Byte  modemControl;	// 100:	  7F8: Modem Control
	Byte  _filler5;

	Word  _filler6;		// 101:	  7FA:

	Word  _filler7;		// 110:	  7FC:

	Byte  scratch;		// 111:	  7FE: scratch pad
	Byte  _filler8;

  } SerHw16650WriteType;


// Baud registers, accessed when 
//		(SerHw16650WriteType->lineControl & 0x80)
// The baud rate is: (serHwClockFreq / 16 / baudReg)
typedef	volatile struct
  {
	Byte  baudLSB;		// 000:	  low byte
	Byte  _filler1;

	Byte  baudMSB;		// 001:	  high byte
	Byte  _filler2;

  } SerHw16650BaudType;


// Enhanced fature set
typedef volatile struct
  {
	Word  _filler1;		// 000:

	Word  _filler2;		// 001:

	Byte  enhReg;		// 010:	7F4: enhanced registers
	Byte  _filler3;

	Word  _filler4;		// 011:	7F6:

	Byte  xon1;			// 100	7F8: XON 1
	Byte  _filler5;

	Byte  xon2;			// 101	7F8: XON 2
	Byte  _filler6;

	Byte  xoff1;		// 110	7F8: XOFF 1
	Byte  _filler7;

	Byte  xoff2;		// 111	7F8: XOFF 2
	Byte  _filler8;

  } SerHw16650EnhType;


// ===============================================================
// Register bits
// ===============================================================

// LineControl register
#define	serHw16650LineCtlData0		0x01
#define	serHw16650LineCtlData1		0x02
#define	serHw16650LineCtlStop		0x04
#define	serHw16650LineCtlParityEn	0x08
#define	serHw16650LineCtlParityEven	0x10
#define	serHw16650LineCtlParitySet	0x20
#define	serHw16650LineCtlBreakSet	0x40
#define	serHw16650LineCtlDivLatchEn	0x80

#define	serHw16650LineCtlEnFeatures	0xBF


// ModemControl register
#define	serHw16650ModemCtlDTR		0x01
#define	serHw16650ModemCtlRTS		0x02
#define	serHw16650ModemCtlLED		0x04
#define	serHw16650ModemCtlIRQx		0x08
#define	serHw16650ModemCtlLoopback	0x10
#define	serHw16650ModemCtlIREnable	0x40
#define	serHw16650ModemCtlClockSel	0x80


// Enhanced Features Register
#define	serHw16650EnhEnableAdv		0x10
#define	serHw16650EnhSpecialChar	0x20
#define	serHw16650EnhAutoRTS		0x40
#define	serHw16650EnhAutoCTS		0x80

// Modem Status register
#define	serHw16650ModemStDeltaCTS	0x01
#define	serHw16650ModemStDeltaRTS	0x02
#define	serHw16650ModemStDeltaRI	0x04
#define	serHw16650ModemStDeltaCD	0x08
#define	serHw16650ModemStCTS		0x10
#define	serHw16650ModemStDSR		0x20
#define	serHw16650ModemStRI			0x40
#define	serHw16650ModemStCD			0x80

// Interrupt Enable register
#define	serHw16650IntEnReceive		0x01
#define	serHw16650IntEnTransmit		0x02
#define	serHw16650IntEnRcvStatus	0x04
#define	serHw16650IntEnModemStatus	0x08
#define	serHw16650IntEnSleep	  	0x10
#define	serHw16650IntEnXOff			0x20
#define	serHw16650IntEnRTS			0x40
#define	serHw16650IntEnCTS			0x80

// Line Status Register
#define	serHw16650LineStReceive		0x01
#define	serHw16650LineStOverrun		0x02
#define	serHw16650LineStParity		0x04
#define	serHw16650LineStFraming		0x08
#define	serHw16650LineStBreak		0x10
#define	serHw16650LineStTransHold	0x20
#define	serHw16650LineStTransmit	0x40
#define	serHw16650LineStFIFOErr		0x80


// Fifo Control Register (FCR)
#define serHw16650FifoCtlRxTrigMask	0xC0  // Receive data ready interrupt
#define serHw16650FifoCtlRxTrig8	0x00  //  is generated when the # of
#define serHw16650FifoCtlRxTrig16	0x40  //  chars in the RX FIFO reaches
#define serHw16650FifoCtlRxTrig24	0x80  //  the programmed trigger level
#define serHw16650FifoCtlRxTrig28	0xC0

#define serHw16650FifoCtlTxTrigMask	0x30  // Transmit Empty interrupt is
#define serHw16650FifoCtlTxTrig16	0x00  //  generated when the # of chars
#define serHw16650FifoCtlTxTrig8	0x10  //  in the TX FIFO drops below the
#define serHw16650FifoCtlTxTrig24	0x20  //  selected trigger level
#define serHw16650FifoCtlTxTrig30	0x30

#define serHw16650FifoCtlDMA		0x08	// set = DMA ON; clear = OFF
#define serHw16650FifoCtlTxReset	0x04	// setting resets transmit FIFO
#define serHw16650FifoCtlRxReset	0x02	// setting resets receive FIFO
#define serHw16650FifoCtlFIFOEnable	0x01	// setting enables FIFO mode
  

// FIFO sizes
#define serHw16650RxFIFOSize		32		// size of receive FIFO
#define serHw16650TxFIFOSize		32		// size of transmit FIFO


#endif   // __SER16650PRV_H__


