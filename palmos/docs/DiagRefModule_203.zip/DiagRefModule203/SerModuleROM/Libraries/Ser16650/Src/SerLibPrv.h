/*******************************************************************
 *
 * Project:
 *	  Serial 16650 Library
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  SerLibPrv.h
 *
 * Description:
 *	  Sample removable card library for the Handspring Developer
 *	  Reference Card.  This library provides an interface to the
 *	  ST16C650A UART on the card and is API conpatible with the 
 *	  PalmOS Serial Library.  
 *
 *	  This file contains the private, Hardware independent
 *	  equates for the library
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *
 *******************************************************************/


#ifndef   __SERLIBPRV_H__
#define   __SERLIBPRV_H__

// Include Card common equates. This header defines the structure
// of the card globals that get passed to our interrupt handler
#include  "HsDevRefCard.h"


//**********************************************************************
//  Constants
//**********************************************************************

// Maximum baud rate supported by this implementation
#define serMaxBaud					115200L

// Hardware handshaking recommended above this baud rate
#define serHandshakeThreshold		19200L


// Queue Sizes
#define	serDefaultRecvQSize			0x200	   
#define serDefaultSendQSize			0x100


//**********************************************************************
//  Structures
//**********************************************************************
typedef struct 
  {
	  // Receive/Transmit Queue. When the queue is empty, qStart == qEnd. 
	  // When the queue is full, end = start-1 (taking wrap-around 
	  // into account if necessary).

	  // (start and end are declared as volatile because
	  //  their values change at interrupt time)
	  volatile Word		start;				// start offset of queue
	  volatile Word		end;				// end offset of queue
	  Word				size;				// size of queue
	  BytePtr			dataP;				// pointer to queue data
	  BytePtr			defDataP;			// pointer to default queue data
  } SerQueueType, *SerQueuePtr;



typedef struct SerGlobalsType
  {
	Word				openCount;			// # of times we've been opened
	Int					port;				// port #
	SerSettingsType		settings;			// current settings
	Word				lineErrors;			// last errors bitfield
			
	// Send and receive queues				
	SerQueueType		sendQ;
	SerQueueType		recvQ; 

	// Signalling information for the interrupt routine
	ProcPtr				wakeupHandler;		// Wakeup handler, if installed
	DWord				wakeupRefcon;		// refcon for wakeup handler
	Word				sigSendFreeBytes;	// Desired # of free bytes in send buffer
	Word				sigRecvUsedBytes;	// How much the app is waiting for
	DWord				taskID;				// which taskID is waiting on serial
						
	//DWord				lastRcvTicks;		// tick count of last received char
	//DWord				lastSendTicks;		// tick count of last received char
						

	// This flag gets set by our interrupt handler when we detect a <CR>
	// character come in while we're asleep. It tells us to wake up the
	// LCD the next time we get an interrupt and the system is finally awake. 
	//Boolean				wakeLCD;
	
	// Hardware info
	struct
	  {
		Boolean			isrInstalled;		// true if we successfully installed
											//  our ISR - used by SerHwFree()
		Word			cardNo;				// card number
		BytePtr			baseP;				// base address of UART
		Boolean			baudInited;			// false until baud rate setup
		Boolean			modeInited;			// false until flags setup
		Boolean			initFinished;		// false until int routine enabled
	
		// Set by interrupt routine after it fills receive queue. Tells
		//  high level code to re-enable receive interrupts after
		//  emptying receive buffer
		Boolean			needRecvIntEnable;

		Boolean			breakOn;			// set when break signal is asserted,
											//  cleared when break signal is
											//  deasserted; the default state is
											//  cleared -- necessary because the
											//  16650 LinceControl register is
											//  write-only

		// Copy of registers on chip. Necessary because these registers are
		//  write only
		struct
		  {
			Byte		fifoControl;		// saved FIFO control

		  } reg;

	  } hw;

	Boolean				errDisplayPatched;	// set by PrvApplySystemPatches
											//  in SerLib.c if ErrDisplayFileLineMsg
											//  was patched

	// ---------------------------------------------------------------
	// Performance Monitoring support
	// ---------------------------------------------------------------
	Boolean				perfMonOn;		// non-zero if performance monitoring
											//  is on
	HsSerModPerfType*	perfMonP;			// ptr to performance monitoring
											//  struct in Card Globals
	// # of bytes sent and received within a given call to our serial
	//  interrupt handler
	Word				sendBurstBytes;
	Word				recvBurstBytes;

  } SerGlobalsType, *SerGlobalsPtr;



// Internal control codes that we define as an interface to
//  our SerHWSetSetting call
#define serCtlFirstCustom	0xA800	// This should have been defined by Palm
									//  in SerMgr.h, but wasn't at the time
									//  of this writing
typedef enum
  {
	
	serHwCtlBaudRateSet = serCtlFirstCustom,		
							// set baud rate
							//  valueP = &DWord
							//  *valueLenP = sizeof (DWord);

	serHwCtlFlagsSet,		// SerSettingsType.flags
							//  valueP = &DWord
							//  *valueLenP = sizeof (DWord);

	serHwCtlCTS,			// State of CTS input
							//  valueP = &Byte
							//  *valueLenP = sizeof (Byte);

	serHwCtlDSR,			// State of DSR input
							//  valueP = &Byte
							//  *valueLenP = sizeof (Byte);

	serHwCtlRecvIntEnable,	// Re-enable receive interrupts
							//  valueP  unused
							//  valueLenP  unused

	serHwCtlSendIntEnable,	// Re-enable send interrupts
							//  valueP  unused
							//  valueLenP  unused

	// Leave at end
	serHwCtlLast
  } SerHwCtlEnum;


//************************************************************************
// Functions
//************************************************************************
Err	SerLibInstall (Word refNum, SysLibTblEntryPtr entryP,
						   Ptr *  dispatchTable);


// Init hardware for first time, called by SerOpen
Err	SerHwInit (SerGlobalsPtr gP, Word cardNo);

// Undo hardware initialization, called by SerClose
Err	SerHwFree (SerGlobalsPtr gP);



// Put hardware into sleep mode
Err	SerHwSleep (SerGlobalsPtr gP);

// Take hardware out of sleep mode
Err	SerHwWake (SerGlobalsPtr gP);



// Setup hardware for new configuration
Err	SerHwControl (SerGlobalsPtr gP, Word /*SerHwCtlEnum*/ op, 
				  VoidPtr valueP, WordPtr valueLenP);


// Wait for transmit FIFO to empty
Err	SerHwSendFIFOWait (SerGlobalsPtr gP, Boolean checkTimeout, UInt32 ctsTimeout);


#endif   // __SERLIBPRV_H__

