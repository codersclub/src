/*******************************************************************
 *
 * Project:
 *	  Serial 16650 Library
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  Ser16650Hw.c
 *
 * Description:
 *	  Sample removable card library for the Handspring Developer
 *	  Reference Card.  This library provides an interface to the
 *	  ST16C650A UART on the card and is API conpatible with the 
 *	  PalmOS Serial Library.  
 *
 *	  This file implements the hardware specific functionality of
 *	  the library - i.e. the routines that actually talk to the
 *	  16650 UART. 
 *
 *	DOLATER...vmk it looks like we might be interrupting for every byte
 *	  instead of taking advantage of 16650's DMA block interrupts.
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *	  20-Sep-1999		Branched from sample sources to create
 *						 production version of the code
 *
 *******************************************************************/

// Include PalmOS equates
#include <SystemPublic.h>
#include <SysEvtMgr.h>
#include <SerialMgrOld.h>
#include <CoreCompatibility.h>

// Include Handspring extensions for removable card support
#include <HsExt.h>

// Our own library equates
#include "SerLibPrv.h"
#include "Ser16650Prv.h"


// Define this to put in logic to turn on the LED while in
// the interrupt routine - this is used to measure interrupt
// latency by hooking up a scope to the interrupt and LED lines
//#define	  MEASURE_INT_LATENCY	


// Define this to measure performance
//#define		  PERF_MON


// NOTE: The value of prvTxTrigBytes must be in sync with the FIFO Control
//  setting that is assigned to prvFifoCtlTxTrigSetting
#define prvTxTrigBytes			  8
#define prvFifoCtlTxTrigSetting	  serHw16650FifoCtlTxTrig8



/***********************************************************************
 *
 * Function:     PrvSer16650IntHandler
 *
 * Description:  Card Interrupt handler for 16650 interrupts.
 *
 *	  All card interrupt handlers can be called from one of two possible
 *	  states of the device:
 *
 *		1.) System Awake. In this state, indicated by *sysAwakeP == true,
 *			all of the device hardware, except possibly the LCD, is 
 *			on and the interrupt handler is free to make any system calls
 *			that are normally safe to make from interrupt handlers. 
 *
 *			If the device came out of sleep mode due to this interrupt, 
 *			the default behavior is that it will go right back to 
 *			sleep again on the next loop through the current application's 
 *			event loop and leave the LCD off. This behavior permits an 
 *			interrupt to wake the device, perform limited processing 
 *			with the LCD off, and allow the device to go right back to 
 *			sleep again.  If instead, you want the device to stay awake 
 *			for a longer period of time or you want the LCD on (because 
 *			you're triggering an application to display something for 
 *			example), then you must call HsEvtResetAutoOffTimer() or 
 *			EvtResetAutoOffTimer().
 *
 *			HsEvtResetAutoOffTimer() lets you specify the minimum amount of 
 *			time to keep the device on before it goes back to deep sleep 
 *			mode and also lets you specify whether or not you want the
 *			LCD to turn on (if not already on). EvtResetAutoOffTimer()
 *			will keep the device on for the amount of time set by the
 *			user in the General Preferences panel and always turns on the
 *			LCD. 
 *
 *		2.) System not awake. In this state, indicated by *sysAwakeP == false,
 *			all of the device hardware, except for the CPU is still
 *			in sleep mode. The system will call the interrupt handler
 *			in this state if the card interrupt was the ONLY interrupt
 *			that occurred while the device was asleep. This allows the
 *			card interrupt handler to perform limited processing without
 *			incurring the overhead of the entire wake-up sequence. 
 *
 *			In this state, the interrupt handler MUST NOT MAKE ANY SYSTEM
 *			CALLS except for HsCardErrTry/HsCardErrCatch. If it does
 *			need to perform other system calls (like set a semaphore for
 *			example), then it should set the *sysAwakeP flag before it exits
 *			and return without clearing the interrupt source. The system will 
 *			then complete waking up the rest of the way (except for the LCD)
 *			and call the interrupt handler again with *sysWakeP set to true. 
 *			  
 *	  
 *
 * Parameters:   
 *	  cardParam		IN		Parameter to interrupt routine setup through
 *							the hsCardAttrCardParam attribute of HsCardAttrSet()
 *							In our case, this is a pointer to a structure
 *							of type HsDrcGlobalsType (defined in "HsDevRefCard.h"
 *							which has a pointer to the serial library globals
 *							inside of it. 
 *
 *	  *sysAwakeP	INOUT	This flag tells us if the system is fully awake
 *							or not. If this flag is false, the interrupt
 *							routine CAN NOT MAKE ANY SYSTEM CALLS except
 *							for HsCardErrTry/HsCardErrCatch. If the interrupt
 *							requires use of the system (to set a semaphore
 *							for example), then the handler
 *							should return without clearing the interrupt
 *							source and set the *sysAwakeP flag on exit.
 *
 *						  
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  System when card interrupt is asserted
 *
 * Notes:
 *
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *	  23-Sep-1999 VMK	  Removed unnecessary example code, added cases
 *						   for MSR and Xoff interrupts.
 *	  23-Sep-1999 VMK	  Disable RTS interrupts -- we don't need them;
 *						  Adjusted dependency on taskID being set to allow
 *						   the wakeup handler to be called when necessary;
 *						  Fixed to make sure that the wakeup handler gets
 *						   called only for receive-related events;
 *						  Clear the signal byte count when notifying;
 *						  Move check for receive signal threshold outside
 *						   character read loop -- performance optimization.
 *						  Move check for transmit signal threshold outside
 *						   character read loop -- performance optimization.
 *	  18-Nov-1999 VMK	  Fixed to take advantage of FIFO block transmit mode
 *
 ***********************************************************************/
#define prvISRTriggerLineError	  0x01
#define prvISRTriggerTX			  0x02
#define prvISRTriggerRX			  0x04
#define prvISRTriggerMSR		  0x08
#define prvISRTriggerRtsCts		  0x10
#define prvISRTriggerXoff		  0x20
#define prvISRTriggerOther		  0x40


void 
PrvSer16650IntHandler (DWord cardParam, Boolean* sysAwakeP)
{
  SerHw16650ReadType*	readP;
  SerHw16650WriteType*	writeP;
  Word			lineStatus;
  Word			end, start, freeBytes, fifoSlotsLeft;
  SWord			usedBytes;
  BytePtr		dstP, srcP;
  Byte			status;
  Boolean		notifyApp = false;
  Boolean		recvNotify = false;		  // notify receiver 
  Boolean		sendNotify = false;		  // notify sender

#ifdef PERF_MON
  Boolean		perfMonOn;
  Byte			triggers = 0;
#endif

  // Get the serial globals out of the card globals
  HsDrcGlobalsType*	  cardGP = (HsDrcGlobalsType*)cardParam;
  SerGlobalsPtr		  gP = cardGP->serLibGlobalsP;



  // ***IMPORTANT*****************************************************************
  //  Because the interrupt stack is *VERY* small, this routine is only allowed to
  //  use a few bytes for local variables.  Using more will cause an interrupt
  //  stack overflow and trash kernel globals.  Because the device supports
  //  interleaved interrups, this problem is further compounded.  So, if you need
  //  more space for your variables (such as temporary buffers, etc.), reserve
  //  the necessary space in the serial library's globals, instead. 
  // ***IMPORTANT*****************************************************************

  ErrNonFatalDisplayIf (!gP, "null serial lib globals");

  // Measuring interrupt latency?
  #ifdef MEASURE_INT_LATENCY
	writeP = (SerHw16650WriteType*)(gP->hw.baseP);
	writeP->modemControl |= serHw16650ModemCtlLED;
  #endif


#ifdef PERF_MON
  perfMonOn = gP->perfMonOn;
  if (perfMonOn)
	{
	  gP->recvBurstBytes = gP->sendBurstBytes = 0;
	}
#endif

  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{

	  // DOLATER... temporary code to work around to disable the button
	  // interrupt
	  #ifdef VERSION_01
	  {
		Byte*	tempP;
		tempP = (Byte*)0x29c00000UL;
		*tempP = 2;
	  }
	  #endif

	  // ----------------------------------------------------------
	  // See which interrupt occurred
	  // DOLATER... if receive queue full, deassert RTS
	  // ----------------------------------------------------------
	  readP = (SerHw16650ReadType*)(gP->hw.baseP);
	  writeP = (SerHw16650WriteType*)(gP->hw.baseP);

	  // If no interrupt left to service, return
	  do
		{
		  status = readP->intStatus;

		  //ErrNonFatalDisplayIf ((status & 0xC0) != 0xC0, "FIFO's not enabled");


		  // If no more interrupt sources waiting to be serviced, bail out
		  if (status & 0x01)
			break;

		  status &= 0x3E;

		  // ----------------------------------------------
		  //  Line error
		  // ----------------------------------------------
		  if (status == 0x06)	  // Line Status
			{
			  // Get error
			  lineStatus = readP->lineStatus;
			  if (lineStatus & serHw16650LineStOverrun)
				{
				  gP->lineErrors |= serLineErrorHWOverrun;
  #ifdef PERF_MON
				  gP->perfMonP->hwOverrunErrors++;
  #endif
				}
			  if (lineStatus & serHw16650LineStParity)
				gP->lineErrors |= serLineErrorParity;
			  if (lineStatus & serHw16650LineStFraming)
				gP->lineErrors |= serLineErrorFraming;
			  if (lineStatus & serHw16650LineStBreak)
				gP->lineErrors |= serLineErrorBreak;

			  // Need to wake the task
			  notifyApp = recvNotify = true;

  #ifdef PERF_MON
			  if (perfMonOn)
				{
				  triggers |= prvISRTriggerLineError;
				  gP->perfMonP->lineErrors++;
				}
  #endif
			} // Line Status


		  // ----------------------------------------------
		  //  Receive data ready
		  // ----------------------------------------------
		  else if (status & 0x04)
			{
			  //case 0x04:	  // Receive FIFO reached threshold
			  //case 0x0C:	  // Receive data timeout

			  // Get info on the receive queue
			  end = gP->recvQ.end;
			  dstP = gP->recvQ.dataP + end;
			  usedBytes = (Int)end - (Int)gP->recvQ.start;
			  if (usedBytes < 0) usedBytes += gP->recvQ.size;

			  while (readP->lineStatus & serHw16650LineStReceive)
				{
				  Byte	data;

				  // NOTE...vmk to be similar to the current PalmOS implementation,
				  //  we may want to throw away data if it arrives while the device is
				  //  aslpeep -- in fact we may even want to disable UART interrupts
				  //  when the device goes to sleep to reduce battery drain.

				  // Calculate next 'end' offset
				  end++;
				  if (end == gP->recvQ.size) 
					end = 0;

				  // If no space in receive buffer, disable further
				  //  interrupts and bail. The PrvWaitForChars() routine will
				  //  re-enable receive interrupts when it empties out
				  //  the buffer
				  //
				  // DOLATER...vmk HotSync relies on being able to send data to 
				  //  the device, even if the receive queue fills up, as part
				  //  of its retry mechanism during a slow response (the extra
				  //  data is probably discarded).  By disabling the receive interrupt,
				  //  we will cause hardware handshake to become deasserted, which may
				  //  cause HotSync's PAD protocol to time out and lose connection... review this
				  if (end == gP->recvQ.start)
					{
					  notifyApp = recvNotify = true;
					  writeP->intEnable &= ~serHw16650IntEnReceive;
					  gP->hw.needRecvIntEnable = true;
					  break;
					}
									  
				  // Get the character out of the FIFO
				  data = readP->recData;

				  // Copy Char into buffer
				  *dstP++ = data;
				  usedBytes++;
  #ifdef PERF_MON
				  gP->recvBurstBytes++;
  #endif
				  
				  // Update end
				  gP->recvQ.end = end;
				  if (end == 0)
					dstP = gP->recvQ.dataP;

				} // while (readP->lineStatus & serHw16650LineStReceive)
				  

			  // Wake task if signal reached
			  if (gP->sigRecvUsedBytes && usedBytes >= gP->sigRecvUsedBytes)
				notifyApp = recvNotify = true;

  #ifdef PERF_MON
			  triggers |= prvISRTriggerRX;
  #endif
			  } // Receive data ready

		  // ----------------------------------------------
		  // Transmit FIFO has space
		  // ----------------------------------------------
		  else if (status == 0x02)
			{
			
			  // Get info on the send queue
			  start = gP->sendQ.start;
			  srcP = gP->sendQ.dataP + start;
			  usedBytes = (Int)gP->sendQ.end - (Int)start;
			  if (usedBytes < 0) usedBytes += gP->sendQ.size;

			  // Subtract 1 because we can't fill the queue with size bytes
			  // - that would make the end offset equal the start offset 
			  // which is true when the queue is empty
			  freeBytes = gP->sendQ.size - usedBytes - 1;

			  // While FIFO has space
			  fifoSlotsLeft = serHw16650TxFIFOSize - prvTxTrigBytes;
			  do
				{
				  Byte	data;


				  // If no more in send buffer, disable further
				  //  interrupts and bail. The PrvSendChars() routine will
				  //  call SerHwSendTrigger() to re-enable send interrupts
				  //  when it starts
				  if (start == gP->sendQ.end)
					{
					  notifyApp = sendNotify = true;
					  writeP->intEnable &= ~serHw16650IntEnTransmit;
					  break;
					}
				  
				  // Get the character out of the buffer and send
				  //  to FIFO
				  data = *srcP++;
				  writeP->sendData = data;
  #ifdef PERF_MON
				  gP->sendBurstBytes++;
  #endif

				  // Calcuate next 'start' offset
				  start++;
				  if (start == gP->sendQ.size) 
					{
					  start = 0;
					  srcP = gP->sendQ.dataP;
					}

				  // Update Queue
				  gP->sendQ.start = start;					
				  freeBytes++;
				  
				}
			  while (--fifoSlotsLeft);

			  // Wake task if signal reached
			  if (gP->sigSendFreeBytes && freeBytes >= gP->sigSendFreeBytes)
				notifyApp = sendNotify = true;

  #ifdef PERF_MON
			  triggers |= prvISRTriggerTX;
  #endif
			} // Transmit FIFO has space


		  // ----------------------------------------------
		  // MSR (Modem Status Register)
		  // ----------------------------------------------
		  else if (status == 0x0)
			{
			  // We should never get this interrupt because we don't
			  //  enable the Modem status interrupt
			  #if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				  DbgBreak(); // Unimplemented
			  #endif

  #ifdef PERF_MON
			  triggers |= prvISRTriggerMSR;
  #endif
			} // MSR (Modem Status Register)


		  // ----------------------------------------------
		  // RTS/CTS hardware handshaking change of state
		  // ----------------------------------------------
		  else if (status == 0x20)
			{
			  // Disable further handshake interrupts till queue gets emptied
			  // PRESENTLY, WE DON'T ENABLE THE RTS INTERRUPT
			  //writeP->intEnable &= ~serHw16650IntEnRTS;
			  //gP->hw.needRecvIntEnable = true;
			  #if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				  DbgBreak(); // Unexpected
			  #endif

  #ifdef PERF_MON
			  triggers |= prvISRTriggerRtsCts;
  #endif
			} // RTS/CTS hardware handshaking change of state


		  // ----------------------------------------------
		  // RXRDY (Received Xoff signal)/ Special character
		  // ----------------------------------------------
		  else if (status == 0x10)
			{
			  // We should never get this interrupt because we suppress
			  //  the software flow control features of the UART
			  #if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				  DbgBreak(); // Unexpected
			  #endif

  #ifdef PERF_MON
			  triggers |= prvISRTriggerXoff;
  #endif
			} // RXRDY (Received Xoff signal)/ Special character

		  // ----------------------------------------------
		  // Some other unexpected interrupt status
		  // ----------------------------------------------
		  else
			{
			  // Unexpected status value
			  #if ERROR_CHECK_LEVEL == ERROR_CHECK_FULL
				  DbgBreak(); // Unexpected
			  #endif

  #ifdef PERF_MON
			  triggers |= prvISRTriggerOther;
  #endif
			}


		} while (1);


	  // ===================================================================
	  // If we did something that requires notifying the application task, 
	  //  and the system is already awake enough to support system calls,
	  //  notify the app now.  Note that the application can still get notified
	  //  about incoming characters and process them with the LCD off. 
	  // ===================================================================
	  if (notifyApp && *sysAwakeP)
		{
		  // If we have a receive-related notification...
		  if (recvNotify)
			{
			  gP->sigRecvUsedBytes = 0;

			  // If there's a custom wakeup handler installed, call that
			  if (gP->wakeupHandler)
				{
				  SerWakeupHandler	procP;
				  procP = (SerWakeupHandler)gP->wakeupHandler;
				  (procP)(gP->wakeupRefcon);
				}

			  else if (gP->taskID)
				SysTaskWake (gP->taskID);
			}


		  // If we have a transmit-related notification...
		  if (sendNotify)
			{
			  gP->sigSendFreeBytes = 0;

			  // We don't call the wakeup handler in this case because it is
			  //  for receive notifications only

			  // If a task is waiting for our signal, wake it up now
			  if (gP->taskID)
				SysTaskWake (gP->taskID);
			}

		}

	} // HsCardErrTry


  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	} HsCardErrEnd


  // ===================================================================
  // Monitor performance
  // ===================================================================
#ifdef PERF_MON
  if (perfMonOn)
	{
	  gP->perfMonP->totalISRCalls++;

	  gP->perfMonP->sendTotal += gP->sendBurstBytes;
	  if (gP->sendBurstBytes > gP->perfMonP->maxSendBurst)
		gP->perfMonP->maxSendBurst = gP->sendBurstBytes;

	  gP->perfMonP->recvTotal += gP->recvBurstBytes;
	  if (gP->recvBurstBytes > gP->perfMonP->maxRecvBurst)
		gP->perfMonP->maxRecvBurst = gP->recvBurstBytes;

	  if (triggers & prvISRTriggerLineError)
		gP->perfMonP->lineErrISRTriggers++;
	  if (triggers & prvISRTriggerTX)
		gP->perfMonP->sendISRTriggers++;
	  if (triggers & prvISRTriggerRX)
		gP->perfMonP->recvISRTriggers++;
	  if (triggers & prvISRTriggerMSR)
		gP->perfMonP->msrISRTriggers++;
	  if (triggers & prvISRTriggerRtsCts)
		gP->perfMonP->rtsISRTriggers++;
	  if (triggers & prvISRTriggerXoff)
		gP->perfMonP->xoffISRTriggers++;
	  if (triggers & prvISRTriggerOther)
		gP->perfMonP->otherISRTriggers++;
	}
#endif
    


  #ifdef MEASURE_INT_LATENCY
	writeP->modemControl &= ~serHw16650ModemCtlLED;
  #endif

  
}



/***********************************************************************
 *
 * Function:     SerHwInit
 *
 * Description:  Initialize the hardware as a result of opening the
 *	  Serial library
 *
 * Parameters:   
 *	  gP		  IN  pointer to serial globals
 *	  cardNo	  IN  card number of card with UART
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerOpen()
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerHwInit (SerGlobalsPtr gP, Word cardNo)
{
  Err					err;
  DWord					base, size;
  Byte					installed;
  SerHw16650ReadType*	readP;
  SerHw16650WriteType*	writeP;
  char					cardName[32];
  Word					version;
  DWord					value;
  HsDrcGlobalsType*		cardGP;


  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{

	  // If the card is not plugged in, return err
	  err = HsCardAttrGet (cardNo, hsCardAttrSwInstalled, &installed);
	  if (err) goto DoneTry;
	  if (!installed) {err = serErrBadPort; goto DoneTry;}


	  // Make sure this is the correct card and correct version
	  err = MemCardInfo (cardNo, cardName, 0 /*manufName*/, &version, 
						 0 /*crDateP*/, 0 /*romSizeP*/, 0 /*ramSizeP*/, 
						 0 /*freeBytesP*/);
	  if (err) goto DoneTry;
	  if (StrCompare (cardName, serHwCardName) || version < serHwCardVersion)
		{
		  err = serErrBadPort;
		  goto DoneTry;
		}
		  


	  // ===================================================================
	  // Get the base address of the UART. It's addressed through csSlot1 so
	  //  we take the CsBase and add CsSize to it
	  // ==================================================================
	  err = HsCardAttrGet (cardNo, hsCardAttrCsBase, &base);
	  if (err) goto DoneTry;

	  err = HsCardAttrGet (cardNo, hsCardAttrCsSize, &size);
	  if (err) goto DoneTry;

	  gP->hw.baseP = (BytePtr)(base + size + serHwBaseOffset);

	  // Save the card number too
	  gP->hw.cardNo = cardNo;



	  // ===================================================================
	  // Install our interrupt routine
	  // ===================================================================
	  value = (DWord)PrvSer16650IntHandler;
	  err = HsCardAttrSet (cardNo, hsCardAttrIntHandler, &value);
	  if (err) goto DoneTry;


	  // Store our globals pointer relative to the card globals for
	  //  faster access by our interrupt routine. 
	  err = HsCardAttrGet (cardNo, hsCardAttrCardParam, &cardGP);
	  if (err) goto DoneTry;
	  if (!cardGP) {err = serErrBadPort; goto DoneTry;}
	  cardGP->serLibGlobalsP = gP;

	  // Mark it as installed for SerHwFree()
	  gP->hw.isrInstalled = true;



	  // ===================================================================
	  // Initialize the UART chip now
	  // ===================================================================
	  readP = (SerHw16650ReadType*)(gP->hw.baseP);
	  writeP = (SerHw16650WriteType*)(gP->hw.baseP);

	  // Set all registers to default values
	  writeP->intEnable = 0;

	  // Enable enhanced features
	  {
		SerHw16650EnhType*	enhP = (SerHw16650EnhType*)writeP;
		Word	intsStatus;
	  
		// Disable interrupts while we set the control register to
		//  a special value, in order to avoid undesirable side-effects
		//  (such as getting stuck in an infinite loop in the interrupt
		//  handler)
		intsStatus = SysDisableInts ();

		writeP->lineControl = serHw16650LineCtlEnFeatures;	
		enhP->enhReg = serHw16650EnhEnableAdv;		// Enable enhanced features
		writeP->lineControl = 0;

		// Restore interrupts
		SysRestoreStatus (intsStatus);
	  }

	  // Zero out again to clear enhanced bits
	  writeP->intEnable = 0;

	  
	  // Turn on DMA mode (bit 3) and enable FIFOs (bit 0)
	  // (all commands written to the FIFO control register must always have
	  //  the FIFO Enable bit set; otherwise, the FIFO mode will be turned off)
	  gP->hw.reg.fifoControl = serHw16650FifoCtlDMA + serHw16650FifoCtlFIFOEnable;

	  // Set the TX FIFO triggier level (bits 4 & 5) to interrupt the processor
	  //  when the # of bytes in the transmit FIFO drops below a given # of bytes
	  //  (this reduces the number of interrupts the processor has to service,
	  //  improving throughput, system performance, and battery life)
	  gP->hw.reg.fifoControl |= prvFifoCtlTxTrigSetting;

	  // Set the RX FIFO trigger level (bits 6 & 7) to interrupt the processor
	  //  when the # of bytes in the receive FIFO equals 24
	  gP->hw.reg.fifoControl |= serHw16650FifoCtlRxTrig24;

	  // Now, write the accumulated value to the FIFO Control register
	  // (FIFOs must be enabled before writing any other bits
	  //  in the fifoControl register)
	  writeP->fifoControl = serHw16650FifoCtlFIFOEnable;
	  writeP->fifoControl = gP->hw.reg.fifoControl;


	  // Line control to 0 default
	  writeP->lineControl = 0;

	  // Activate the IRQx outputs (bit 3) since we're using PC mode 
	  //  of the chip
	  writeP->modemControl = serHw16650ModemCtlIRQx;

	  // Reset the FIFOs
	  writeP->fifoControl = (gP->hw.reg.fifoControl | 0x06);


	  // We jump to here if an error occurs so that we can clean up
	  //  the HsCardErrTry
DoneTry:
	  ;	// make compiler happy
	}



  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd


  ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwInit err");
  return err;
}


/***********************************************************************
 *
 * Function:     SerHwFree
 *
 * Description:  Undo whatever SerHwInit does
 *
 * Parameters:   
 *	  gP		  IN  pointer to serial globals
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerClose()
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerHwFree (SerGlobalsPtr gP)
{
  Err					err=0;
  SerHw16650WriteType*  writeP = 0;
  DWord					value;
  Byte					enable;
  HsDrcGlobalsType*		cardGP;


  // ===================================================================
  // Remove our interrupt routine if installed
  // ===================================================================
  if (!gP->hw.isrInstalled) goto Exit;

  enable = 0;
  HsCardAttrSet (gP->hw.cardNo, hsCardAttrIntEnable, &enable);

  value = 0;
  HsCardAttrSet (gP->hw.cardNo, hsCardAttrIntHandler, &value);


  // Zero out our globals pointer that we stored in the card globals
  //  for our interrupt routine. 
  err = HsCardAttrGet (gP->hw.cardNo, hsCardAttrCardParam, &cardGP);
  if (err) goto Exit;
  if (!cardGP) {err = serErrBadPort; goto Exit;}
  cardGP->serLibGlobalsP = 0;


  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{

	  // ============================================================ 
	  // Initialize the UART chip now
	  // ============================================================ 
	  writeP = (SerHw16650WriteType*)(gP->hw.baseP);

	  // Set all registers to default values
	  writeP->intEnable = 0;
	  writeP->fifoControl = gP->hw.reg.fifoControl = 0;
	  writeP->lineControl = 0;
	  writeP->modemControl = 0;

	}


  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd


Exit:
  ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwFree err");
  return err;

}


/***********************************************************************
 *
 * Function:     SerHwControl
 *
 * Description:  Set or retrieve hardware parameters or modes of
 *	  the UART. 
 *
 * Parameters:   
 *	gP	       IN		pointer to our globals
 *  op         IN		control operation to perform 
 *						  one of SerCtlEnum or SerHWCtlEnum
 *  valueP     IN/OUT	ptr to value for operation
 *  valueLenP  IN/OUT	ptr to size of value
 *               
 * Returns:      
 *	error code, 0 if no error
 *
 * Called By:
 *	  SerControl, SerSetSettings, SerGetSettings
 *
 * History:
 *	  01-Mar-1999  RM	  Created
 *	  23-Sep-1999  VMK	  Disable RTS interrupts -- we don't need them
 *	  23-Sep-1999  VMK	  Save the state of the break signal;
 *						  set gP->hw.initFinished when init is finished
 *
 ***********************************************************************/
Err 
SerHwControl (SerGlobalsPtr gP, Word op, VoidPtr valueP, WordPtr valueLenP)
{
  Err					err = 0;
  SerHw16650WriteType*  writeP  = (SerHw16650WriteType*)(gP->hw.baseP);
  SerHw16650ReadType *  readP  = (SerHw16650ReadType*)(gP->hw.baseP);
  Byte					lineControl;
  
  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{
	  
	  switch( op )
		{
		case serCtlStartBreak:
		  writeP->lineControl |= serHw16650LineCtlBreakSet;
		  gP->hw.breakOn = true;
		  break;

		case serCtlStopBreak:
		  writeP->lineControl &= ~serHw16650LineCtlBreakSet;
		  gP->hw.breakOn = false;
		  break;

		case serCtlBreakStatus:
		  *(WordPtr)valueP = gP->hw.breakOn;
		  break;

		case serCtlStartLocalLoopback:
		  writeP->modemControl |= serHw16650ModemCtlLoopback;
		  break;

		case serCtlStopLocalLoopback:
		  writeP->modemControl &= ~serHw16650ModemCtlLoopback;
		  break;

		case serCtlIrDAEnable:
		  // This depends on the enhanced feature set being enabled (see EFR bit-4)
		  writeP->modemControl |= serHw16650ModemCtlIREnable;
		  break;
			
		case serCtlIrDADisable:
		  // This depends on the enhanced feature set being enabled (see EFR bit-4)
		  writeP->modemControl &= ~serHw16650ModemCtlIREnable;
		  break;
			
		case serCtlIrScanningOn:
		  err = serErrNotSupported;
		  break;

		case serCtlIrScanningOff:
		  err = serErrNotSupported;
		  break;

		// rxEnable/disable used for half duplex IrDA comm
		case serCtlRxEnable:
		  err = serErrNotSupported;
		  break;

 		case serCtlRxDisable:
		  err = serErrNotSupported;
		  break;


		// ==========================================================
		// Private, hardware specific ones
		// ===========================================================
 		case serHwCtlCTS:
		  if (readP->modemStatus & serHw16650ModemStCTS)
			*((BytePtr)valueP) = true;
		  else
			*((BytePtr)valueP) = false;
		  break;

 		case serHwCtlDSR:
		  if (readP->modemStatus & serHw16650ModemStDSR)
			*((BytePtr)valueP) = true;
		  else
			*((BytePtr)valueP) = false;
		  break;
  
		// Sent by PrvWaitChars() after emptying receive queue somewhat
 		case serHwCtlRecvIntEnable:
		  // Re-enable receive interrupts
		  writeP->intEnable |= /*serHw16650IntEnRTS |*/ serHw16650IntEnReceive;
		  break;

		// Sent by PrvSendChars() after putting data into send queue
 		case serHwCtlSendIntEnable:
		  // Re-enable send interrupts
		  writeP->intEnable |= serHw16650IntEnTransmit;
		  break;


		case serHwCtlBaudRateSet:
		  {
			DWord	baud;
			Word	reg;
			SerHw16650BaudType* baudP;

			baud = *((DWord*)valueP);

			// Check for max
			if (baud > serMaxBaud) 
			  {
				err = serErrNotSupported;
				break;
			  }
			
			// Figure out what divisor we need. The generated baud rate
			// is the crystal frequency / 16 / baudReg. 
			reg = (Word)((serHwClockFreq / 16 + baud/2) / baud);

			// Err if reg is 0
			if (reg == 0) 
			  {
				err = serErrNotSupported; 
				break;
			  }

			{
			  Word	intsStatus;
			
			  // Disable interrupts while we modify multiple registers to
			  //  avoid undesirable side-effects (such as getting stuck
			  //  in an infinite loop in the interrupt handler)
			  intsStatus = SysDisableInts ();

			  // Turn off the divide by 4 logic
			  writeP->modemControl &= ~serHw16650ModemCtlClockSel;

			  // Set up to access the baud rate registers
			  writeP->lineControl |= serHw16650LineCtlDivLatchEn;

			  baudP = (SerHw16650BaudType*)writeP;
			  baudP->baudLSB = reg & 0x0FF;
			  baudP->baudMSB = reg >> 8;

			  // Back to normal
			  writeP->lineControl &= ~serHw16650LineCtlDivLatchEn;

			  // Set flag
			  gP->hw.baudInited = true;

			  // Restore interrupts
			  SysRestoreStatus (intsStatus);
			}
		  }
		  break;



		// ----------------------------------------------------------
		// Flags
		// ---------------------------------------------------------
		case serHwCtlFlagsSet:
		  {
			DWord	flags;
			SerHw16650EnhType* enhP;

			flags = *((DWord*)valueP);

			// .....................
			// Set stop bits
			// .....................
			switch (flags & serSettingsFlagStopBitsM)
			  {
			  case serSettingsFlagStopBits1:
				writeP->lineControl &= ~serHw16650LineCtlStop;
				break;
			  case serSettingsFlagStopBits2:
				writeP->lineControl |= serHw16650LineCtlStop;
				break;
			  }


			// .....................
			// Set Parity
			// .....................
			writeP->lineControl &= ~(serHw16650LineCtlParitySet
									 | serHw16650LineCtlParityEven 
									 | serHw16650LineCtlParityEn);
			if (flags & serSettingsFlagParityOnM)
			  writeP->lineControl |= serHw16650LineCtlParityEn;

			if (flags & serSettingsFlagParityEvenM)
			  writeP->lineControl |= serHw16650LineCtlParityEven;



			// .....................
			// Ignore Software flow control for now...
			// .....................
			if (flags & serSettingsFlagXonXoffM)
			  err = serErrNotSupported;


			// .....................
			// RTS and CTS receive flow control
			// .....................
			enhP = (SerHw16650EnhType*)writeP;

			// Set line control to 0xBF to access extended features
			{
			  Word	intsStatus;
			
			  // Disable interrupts while we set the control register to
			  //  a special value, in order to avoid undesirable side-effects
			  //  (such as getting stuck in an infinite loop in the interrupt
			  //  handler)
			  intsStatus = SysDisableInts ();

			  lineControl = writeP->lineControl;
			  writeP->lineControl = serHw16650LineCtlEnFeatures;	

			  ErrNonFatalDisplayIf (!(enhP->enhReg & serHw16650EnhEnableAdv),
									"enhanced features not enabled");
			  if (flags & serSettingsFlagRTSAutoM)
				enhP->enhReg |= serHw16650EnhAutoRTS;
			  else
				enhP->enhReg &= ~serHw16650EnhAutoRTS;

			  if (flags & serSettingsFlagCTSAutoM)
				enhP->enhReg |= serHw16650EnhAutoCTS;
			  else
				enhP->enhReg &= ~serHw16650EnhAutoCTS;
				
			  writeP->lineControl = lineControl;

			  // Restore the interrupts
			  SysRestoreStatus (intsStatus);
			}


			// .....................
			// Bits per character
			// .....................
			writeP->lineControl &= ~(serHw16650LineCtlData1 
									| serHw16650LineCtlData0);
			switch (flags & serSettingsFlagBitsPerCharM)
			  {
			  case serSettingsFlagBitsPerChar5:
				writeP->lineControl |= 0;
				break;
			  case serSettingsFlagBitsPerChar6:
				writeP->lineControl |= serHw16650LineCtlData0;
				break;
			  case serSettingsFlagBitsPerChar7:
				writeP->lineControl |= serHw16650LineCtlData1;
				break;
			  case serSettingsFlagBitsPerChar8:
				writeP->lineControl |= serHw16650LineCtlData0
									   | serHw16650LineCtlData1;
				break;
			  }

			// Set flag
			gP->hw.modeInited = true;
		  }
		  break;

		
		// Return err if we don't recognize it
		default:
		  err = serErrBadParam;
		  break;
		}


	  // ----------------------------------------------------------
	  // If we just finished initializing the chip, enable interrupts
	  // ----------------------------------------------------------
	  if (!gP->hw.initFinished && gP->hw.baudInited  && gP->hw.modeInited)
		{
		  Byte	enable;

		  // Turn on DTR and RTS and the LED
		  writeP->modemControl |=	  serHw16650ModemCtlRTS
									| serHw16650ModemCtlDTR
		  #ifndef MEASURE_INT_LATENCY
									| serHw16650ModemCtlLED
		  #endif
									;
			


		  // Enable the UART receive and line status (err) interrupts
		  writeP->intEnable |= serHw16650IntEnRcvStatus
								|  serHw16650IntEnReceive;

		  // Enable card interrupts to the motherboard
		  enable = true;
		  err = HsCardAttrSet (gP->hw.cardNo, hsCardAttrIntEnable, &enable);

		  if (!err)
			  gP->hw.initFinished = true;
		}

	} //HsCardErrTry


  // ===================================================================
  // Handle a pulled card. 
  // ==================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd
  

  ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwControl err");
  return( err );
  
}




/***********************************************************************
 *
 * Function:     SerHwSleep
 *
 * Description:  Put Hardware into low power sleep mode
 *
 * Parameters:   
 *	  gP		  IN  pointer to serial globals
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerSleep()
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerHwSleep (SerGlobalsPtr gP)
{
  Err					err=0;
  SerHw16650WriteType*	writeP;

  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{
	  writeP = (SerHw16650WriteType*)(gP->hw.baseP);

	  // NOTE: May also want to disable interrupts, because the 650's
	  //  low power state may still trigger interrupts if data keeps arriving
	  //  in the serial port (such as when the device is turned off, but left
	  //  connected to the data source). May also need to disable the line driver,
	  //  if any is used in the product.  Investigate this...

	  // Put into low power mode. 
	  
	  // This depends on the enhanced feature set being enabled (see EFR bit-4)
	  writeP->intEnable |= serHw16650IntEnSleep;  // low power bit

	  // Turn off the LED to indicate we're in sleep mode
	  #ifndef MEASURE_INT_LATENCY
		writeP->modemControl &= ~serHw16650ModemCtlLED;
	  #endif
	}


  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd

  ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwSleep err");
  return err;
}


/***********************************************************************
 *
 * Function:     SerHwWake
 *
 * Description:  Take Hardware out of low power sleep mode
 *
 * Parameters:   
 *	  gP		  IN  pointer to serial globals
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerWake()
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerHwWake (SerGlobalsPtr gP)
{
  Err					err=0;
  SerHw16650WriteType*	writeP;

  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{
	  writeP = (SerHw16650WriteType*)(gP->hw.baseP);

	  // Take out of low power mode
	  writeP->intEnable &= ~serHw16650IntEnSleep;	  // low power bit

	  // Turn on the LED to indicate we're awake
	  #ifndef MEASURE_INT_LATENCY
		writeP->modemControl |= serHw16650ModemCtlLED;
	  #endif
	}


  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd

  ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwWake err");
  return err;
}



/***********************************************************************
 *
 * Function:     SerHwSendFIFOWait
 *
 * Description:  Wait for all characters in the send FIFO to be sent out
 *
 * Parameters:   
 *	  gP			IN  pointer to serial globals
 *	  checkTimeout	IN  if non-zero, the wait employs the CTS
 *						 timeout logic; if zero, waits indefinitely
 *						 for the FIFO to empty out
 *	  ctsTimeout	IN	if checkTimeout is zero, this value is ignored;
 *						 otherwise, it is used the the CTS timeout value
 *						 represented in system ticks.
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerSendWait()
 *
 * History:
 *	  03-Mar-1999  RM	  Created
 *	  18-Nov-1999  VMK	  Fixed CTS timeout logic
 *
 ***********************************************************************/
Err 
SerHwSendFIFOWait (SerGlobalsPtr gP, Boolean checkTimeout, UInt32 ctsTimeout)
{
  Err					err=0;
  SerHw16650ReadType*	readP;
  UInt32					waitStartTicks;


  ErrNonFatalDisplayIf (checkTimeout && (ctsTimeout < 0), "negative ctsTimeout");

  // ===================================================================
  // Put a try/catch around this code that accesses the hardware
  // ==================================================================
  HsCardErrTry
	{
	  readP = (SerHw16650ReadType*)(gP->hw.baseP);

	  // Loop till fifo empties
	  do
		{
		  // Check if TX FIFO is empty
		  if (readP->lineStatus & serHw16650LineStTransmit)
			break;

		  // If using CTS timeout and CTS is OFF, wait for it to turn on
		  //  while checking for timeout
		  if (checkTimeout && !(readP->modemStatus & serHw16650ModemStCTS))
			{
			  waitStartTicks = TimGetTicks ();

			  // Wait for CTS to toggle
			  do
				{
				  // Check for CTS toggle
				  if (readP->modemStatus & serHw16650ModemStDeltaCTS)
					break;

				  // Check again if TX FIFO is empty (just in case)
				  if (readP->lineStatus & serHw16650LineStTransmit)
					break;

				  // See if timeout yet
				  if ((TimGetTicks() - waitStartTicks) >= ctsTimeout) 
					err = serErrTimeOut;
				}
			  while (!err);
			}
		} while (!err);

	}


  // ===================================================================
  // If card got pulled, return error
  // ===================================================================
  HsCardErrCatch
	{
	  err = serErrBadPort;
	} HsCardErrEnd


  //ErrNonFatalDisplayIf (err && err!=serErrBadPort, "SerHwSendFIFOWait err");
  return err;
}


