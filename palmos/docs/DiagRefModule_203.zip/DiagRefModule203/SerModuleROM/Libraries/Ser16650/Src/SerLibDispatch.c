/*******************************************************************
 *
 * Project:
 *	  Serial 16650 Library
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  SerLibDispatch.c
 *
 * Description:
 *	  Sample removable card library for the Handspring Developer
 *	  Reference Card.  This library provides an interface to the
 *	  ST16C650A UART on the card and is API conpatible with the 
 *	  PalmOS Serial Library.  
 *
 *	  This file contains the installation routine for the library, 
 *	  it is called when the library is installed through the
 *	  SyLibInstall() or SysLibLoad() calls.
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *
 *******************************************************************/

// Don't use system traps
#undef  CMD_LINE_BUILD
#define CMD_LINE_BUILD

#undef  USE_TRAPS
#define	USE_TRAPS	0

#undef  EMULATION_LEVEL
#define EMULATION_LEVEL 0 /*EMULATION_NONE*/

#pragma warning( disable : 4068)	// unknown pragma

// Include PalmOS equates
#pragma warning( push )
  #pragma warning( disable : 4103)	// sed #pragma pack to change alignment
  #include <SystemPublic.h>
#pragma warning( pop )

#include <SerialMgrOld.h>
#include <CoreCompatibility.h>



// Our own private equates
#include "SerLibPrv.h"


// Private routines
Ptr		PrvDispatchTable();


/************************************************************
 *
 *  FUNCTION: SerEntry
 *
 *  DESCRIPTION: This is the entry point to the library
 *		It gets called by the System routine SysLibInstall()
 *		when installing the library. 
 *
 *		This routine must install the  library's dispatch table
 *		into the library entry pointer and it's globals.
 *
 *  PARAMETERS: 
 *		refNum		IN	refNum of library
 *		libEntryP	IN	SysLibTblEntryPtr for this library
 *
 *	CALLED BY:
 *		SysLibInstall 
 *
 *  RETURNS: 0 if no error
 *
 *  HISTORY: 
 *		1-Mar-1999  RM	  Created
 *
 *************************************************************/
Err	
SerEntry (Word refNum, SysLibTblEntryPtr entryP)
{

	// Get pointer to the dispatch table and call the install 
	//  routine which is in a normal module compiled to use
	//  traps. 
	return SerLibInstall (refNum, entryP, (Ptr*)PrvDispatchTable());
}




/************************************************************
 *
 *  FUNCTION: GNU Compiler Dispatch Table for our LIbrary
 *
 *  DESCRIPTION: This table gets installed into the dispatchTblP
 *		field of the library entry in the library table. It gives
 *		the 32-bit offset of every routine relative to the start of
 *		the dispatch table.
 *
 *
 *  HISTORY: 
 *		1-Mar-1999  RM	  Created
 *
 *************************************************************/
#ifdef __GNUC__
static void 
_PrvDispatchTable(void)
{
  asm ("

  |==============================================================
  | We define this entry point to skip the link/unlk instructions
  |==============================================================
.global	PrvDispatchTable
PrvDispatchTable:

	LEA			(Table,%%pc), %%a0					| table ptr
	RTS	
	
Table:												| return;
	DC.W		PrvLibName-Table
	DC.W		SerOpen-Table						| Open
	DC.W		SerClose-Table						| Close
	DC.W		SerSleep-Table						| Sleep
	DC.W		SerWake-Table						| Wake

	DC.W		SerGetSettings-Table				
	DC.W		SerSetSettings-Table
				
	DC.W		SerGetStatus-Table				
	DC.W		SerClearErr-Table
				
	DC.W		SerSend10-Table				
	DC.W		SerSendWait-Table				
	DC.W		SerSendCheck-Table				
	DC.W		SerSendFlush-Table
				
	DC.W		SerReceive10-Table				
	DC.W		SerReceiveWait-Table				
	DC.W		SerReceiveCheck-Table				
	DC.W		SerReceiveFlush-Table
				
	DC.W		SerSetReceiveBuffer-Table				
	DC.W		SerReceiveWindowOpen-Table				
	DC.W		SerReceiveWindowClose-Table
				
	DC.W		SerSetWakeupHandler-Table				
	DC.W		SerPrimeWakeupHandler-Table
				
	DC.W		SerControl-Table				
	DC.W		SerSend-Table				
	DC.W		SerReceive-Table
	
	" : : );

  // Get rid of warnings
  _PrvDispatchTable(); 
}

// Name
static const char PrvLibName[] = hsDrcSerLibName;


#endif  //__GNUC__


