/*******************************************************************
 *
 * Project:
 *	  Serial 16650 Library
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 * FileName:
 *	  SerLib.c
 *
 * Description:
 *	  Sample removable card library for the Handspring Developer
 *	  Reference Card.  This library provides an interface to the
 *	  ST16C650A UART on the card and is API conpatible with the 
 *	  PalmOS Serial Library.  
 *
 *	  This file implements the core, hardware independent routines 
 *	  of the library. 
 *
 * History:
 *	  1-Mar-1999		Created by Ron Marianetti  
 *	  20-Sep-1999		Branched from sample sources to create
 *						 production version of the code
 *
 *******************************************************************/

// Include PalmOS equates
#include <SystemPublic.h>
#include <SerialMgrOld.h>
#include <CoreCompatibility.h>

// Include Handspring extensions for removable card support
#include <HsExt.h>

// Our own private equates
#include "SerLibPrv.h"


#define  NON_PORTABLE
//#include <SystemPrv.h>	  // to get task info for our patch

//>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>
// Copy these structures from the 3.0 SDK because they are no longer
//  part of the new PalmOS SDK.
//
// IMPORTANT: SysKernelInfoSelector and SysKernelInfoType may only
//  be used when running under PalmOS 3.1 since they are private to PalmOS
//  and are not guaranteed to remain the same

//*****************************************************************
// Structure of ParamBlock for the SysKernelInfo call
//*****************************************************************

// Selector codes
typedef enum	 {
	sysKernelInfoSelCurTaskInfo,
	sysKernelInfoSelTaskInfo,
	sysKernelInfoSelSemaphoreInfo,
	sysKernelInfoSelTimerInfo
	} SysKernelInfoSelector;

typedef struct SysKernelInfoType {
	//  <chg 1-Feb-1999 RM> Force to Byte for compiler independence
	Byte /*SysKernelInfoSelector*/	selector;		// Which info to get
	Byte							filler;			// padding
	DWord							id;				// which object to get info on
	
	union {
		struct {
			DWord		id;							// ID of task
			DWord		nextID;						// ID of next task
			
			DWord		tag;							// task tag
			DWord		status;						// task status
			DWord		timer;						// # ticks left if task's timeout
			DWord		timeSlice;					// task's time slice
			SWord		priority;					// task priority
			Word		attributes;					// task attributes
			SWord		pendingCalls;				// # of pending calls
			DWord		senderTaskID;				// task ID of message sender
			DWord		msgExchangeID;				// task's message exchange ID, if any
			
			DWord		tcbP;							// pointer to TCB
			DWord		stackP;						// stack pointer of task
			DWord		stackStart;					// top of task stack (where it started).
			DWord		stackSize;					// size of stack
			} task;

		struct {
			DWord		id;
			DWord		nextID;						// ID of next semaphore

			DWord		tag;							// semaphore tag
			SWord		initValue;					// semaphore initial value 
														//  >= 0 for counting, -1 for resource
			SWord		curValue;					// semaphore current value
														//  >0 available
														//   0 not available
														//  -n not available, n tasks waiting
			SWord		nestLevel;					// 0 for counting, >= 0 for resource
			DWord		ownerID;						// owner ID
														//   0 for counting or resource free
			} semaphore;
			
		struct {
			DWord		id;
			DWord		nextID;						// ID of next timer
			
			DWord		tag;							// timer tag
			DWord		ticksLeft;					// ticks left till timer runs
			DWord		period;						// timer period, if periodic
			DWord		proc;							// timer procedure
			} timer;
		} param;
		
	} SysKernelInfoType;
	
	
typedef SysKernelInfoType*	SysKernelInfoPtr;



//**********************************************************************
//  Internal types
//**********************************************************************

// The function type used for patching the system function
//  ErrDisplayFileLineMsg
typedef void
PrvErrDisplayFileLineMsgFuncType (const Char * const filename,
								  UInt lineNo, const Char * const msg);


//**********************************************************************
//  Internal function
//**********************************************************************

/***********************************************************************
 *
 *	Function:	  PrvGetGlobals
 *
 *	Description:  
 *	  Get a pointer to the Serial library's globals variables.
 *
 *	Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *
 *	Returns:      
 *	  pointer to the Serial library's globals variables
 *
 *	Called By:
 *	  Many routines in this module to get pointer to globals
 *
 *  HISTORY: 
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
#define	PrvGetGlobals(refNum) \
		(SerGlobalsPtr)(SysLibTblEntry(refNum)->globalsP)




/***********************************************************************
 *
 * Function:     PrvIsNetTask
 *
 * Description:  
 *	  Determine whether we're executing on the TCP/IP task.
 *
 * Parameters:   
 *	  none
 *
 * Returns:      non-zero if we're executing on the TCP/IP task
 *
 * Called By:
 *	  PrvApplySystemPatches() when determining whether
 *	   ErrDisplayFileLineMsg should be patched
 *	   
 *
 * History:
 *	  17-Nov-1999  VMK	  Created
 *
 ***********************************************************************/
static Boolean
PrvIsNetTask (void)
{
  Boolean	isNetTask = false;
  SysKernelInfoType	kinfo;
  Err		err;


  // UNDOCUMENTED FUNCTION WARNING: using an undocumented
  //  function -- only safe to call SysKernelInfo on PalmOS v3.1
  kinfo.selector = sysKernelInfoSelTaskInfo;
  kinfo.id = SysTaskID ();
  err = SysKernelInfo (&kinfo);
  ErrFatalDisplayIf (err, "SysKernelInfo failed");
  if (kinfo.param.task.tag == 'netl')
	isNetTask = true;

  return (isNetTask);
}



/***********************************************************************
 *
 * Function:     PrvErrDisplayFileLineMsgPatch
 *
 * Description:  
 *	  This is a patch function for the system function ErrDisplayFileLineMsg;
 *	  We patched ErrDisplayFileLineMsg to work around the timing-related
 *	  "NetLibUtils.c, Line:1112, Command not done" crashing bug in PalmOS's
 *	  Network Library.
 *
 * Parameters:   
 *	  same as ErrDisplayFileLineMsg()
 *
 * Returns:      nothing
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  17-Nov-1999  VMK	  Created
 *
 ***********************************************************************/
static void
PrvErrDisplayFileLineMsgPatch (const Char * const filename, UInt lineNo, 
								  const Char * const msg)
{
  PrvErrDisplayFileLineMsgFuncType*	oldProcP = NULL;
  Err	err;

  // If this is the instance of the problem that we're working
  //  around, just bail out to avoid the unnecessary crash
  if (lineNo == 1112 && StrCompare (filename, "NetLibUtils.c") == 0
					 && StrCompare (msg, "Command not done") == 0)
	return;

  // This is some other instance of the call -- call the original trap
  //  to handle it
  err = HsCardPatchPrevProc (sysTrapErrDisplayFileLineMsg, &oldProcP);
  if (err || !oldProcP)
	{
	  DbgBreak ();
	}
  else
	oldProcP (filename, lineNo, msg);

  return;
}



/***********************************************************************
 *
 * Function:     PrvApplySystemPatches
 *
 * Description:  
 *	  Patch the "FatalError" system trap, if necessary, to work
 *	  around the timing-related "NetLibUtils.c, Line:1112, Command not done"
 *	  crashing bug in PalmOS's NetLib.
 *
 * Parameters:   
 *	  gP         IN   library global variables
 *
 * Returns:      error code
 *
 * Called By:
 *	  SerOpen()
 *
 * History:
 *	  17-Nov-1999  VMK	  Created
 *
 ***********************************************************************/
static void
PrvApplySystemPatches (SerGlobalsPtr gP)
{
  DWord romVersion = 0;
  Err	err;
  

  ErrNonFatalDisplayIf (!gP, "null arg");
  ErrNonFatalDisplayIf (gP->errDisplayPatched, "already patched");

  
  // This patch is only required for PalmOS versions < 3.2,
  //  so check the PalmOS version #, and bail out if we're
  //  on a newer system
  FtrGet (sysFtrCreator, sysFtrNumROMVersion, &romVersion);
  if (romVersion >= sysMakeROMVersion(3, 2, 0, 0, 0))
	return;

  // Patch only if we're being opened by the TCP/IP stack's Net task
  if (!PrvIsNetTask())
	return;

  // We need to patch
  err = HsCardPatchInstall (sysTrapErrDisplayFileLineMsg, 
							&PrvErrDisplayFileLineMsgPatch);
  if (!err)
	gP->errDisplayPatched = true;


  return;
}




/***********************************************************************
 *
 * Function:     PrvRemoveSystemPatches
 *
 * Description:  
 *	  Remove the "FatalError" system trap patch that we may have
 *	  installed in PrvApplySystemPatches().
 *
 * Parameters:   
 *	  gP         IN   library global variables
 *
 * Returns:      error code
 *
 * Called By:
 *	  SerClose
 *
 * History:
 *	  17-Nov-1999  VMK	  Created
 *
 ***********************************************************************/
static void
PrvRemoveSystemPatches (SerGlobalsPtr gP)
{
  Err	err;
  

  ErrNonFatalDisplayIf (!gP, "null arg");

  // Bail out if we didn't install it
  if (!gP->errDisplayPatched)
	return;

  err = HsCardPatchRemove (sysTrapErrDisplayFileLineMsg);
  ErrNonFatalDisplayIf (err, "patch remove err");

  gP->errDisplayPatched = false;

  return;  
}






/***********************************************************************
 *
 *	Function:     PrvWaitForChars
 *
 *	Description:  
 *	  Waits until the receive queue contains the specified 
 *	  number of characters or a timeout, whichever comes 
 *	  sooner.
 *
 *	Parameters:   
 *	  gP         IN   library global variables
 *    bytes      IN   number of bytes to wait for (must be < recvQ.queP->size)
 *    timeout    IN   inter-byte timeout in ticks, 0 for none, -1 forever
 *
 *	Returns:     
 *	  error code, 0 if no error
 *
 *	Called By:
 *	  SerReceive(), SerReceiveWait()
 *
 *	Note:
 *
 *	History:
 *	  01-Mar-1999  RM	Created
 *	  01-Oct-1999  VMK	Fixed timeout logic to be inter-byte
 *	  18-Nov-1999  VMK	Fixed race condition by calling SysTaskWaitClr
 *						 after clearing gP->taskID
 *
 ***********************************************************************/
static Err 
PrvWaitForChars (SerGlobalsPtr gP, DWord bytes, SDWord timeout)
{
  Err				err = 0;	
  Int16				readyBytes, prevReadyBytes;
  SerQueuePtr		queP = &gP->recvQ;
  Boolean			checkTimeout = false;
  DWord				endTime, currTime;
  SDWord			waitTicks;
  

  // Return right away if 0 bytes
  if (!bytes) return 0;

  // Caller must insure that bytes is less than the queue size
  ErrFatalDisplayIf (bytes >= queP->size, "");

  // If the App is using it's own wakeup handler, this call is invalid
  if (gP->wakeupHandler) return serErrTimeOut;
  


  // -------------------------------------------------------------
  // Figure out the endTime and the timeout value to pass to the
  //   SysTaskWait() call. 
  // If timeout is infinite, the kernel wants 0
  // If timeout is none (0) the kernel wants -1
  // -------------------------------------------------------------
  currTime = TimGetTicks();	// init start of timeout countdown
  if (timeout < 0) 
	{
	  // Inifinite wait
	  timeout = 0;
	  endTime = 0;
	}
  else if (timeout == 0) 
	{
	  // No wait
	  timeout = -1;
	  endTime = currTime;
	  checkTimeout = true;
	}
  else
	{
	  // Limited wait
	  endTime = currTime + timeout;
	}
	  

  // Get the task ID of this task which will be (possibly) waiting for
  //  characters
  gP->taskID = SysTaskID();
  


  // -------------------------------------------------------------
  // Instead of using up system resources for another semaphore,
  //  use SysTaskWait/SysTaskWake calls. The downside of these calls
  //  is that we may get "false" wake-ups, so we need to loop and re-check
  //  the receive count every time we wake up. 
  // -------------------------------------------------------------
  prevReadyBytes = -1;
  while(1) 
	{
	  // Calculate the # of bytes in the queue and break out 
	  //  if there's enough
	  readyBytes = (Int)queP->end - (Int)queP->start;
	  if (readyBytes < 0) readyBytes += queP->size;
 	  if ((DWord)readyBytes >= bytes) break;

	  // If first time through the loop, save the readyBytes
	  if (prevReadyBytes < 0)
		prevReadyBytes = readyBytes;

	  // Check for timeout if not first time through loop and not
	  // inifinite timeout (endTime==0)
	  currTime = TimGetTicks ();
	  if (checkTimeout && endTime > 0 && currTime >= endTime)
		{
		  // If we received any data since beginning of this timeout interval,
		  //  reset the timeout counter and keep waiting
		  if (timeout > 0 && readyBytes > prevReadyBytes)
			{
			  // Save the current ready byte count for a subsequent check
			  prevReadyBytes = readyBytes;

			  // Reset the timeout counter
			  endTime = currTime + timeout;
			}

		  // Otherwise, abort the wait with a "timeout" error
		  else
			{
			  err = serErrTimeOut;
			  break;
			}
		}

	  // Set semaphore threshold for the ISR. The ISR will call SysTaskWake()
	  //  when it detects enough characters in the queue to fill the request.
	  gP->sigRecvUsedBytes = (Word)bytes;
	  

	  // If the bytes have arrived, break out.
	  //  This catches a potential race condition if the characters arrived
	  //  after our first check but before we set the receive signal size. 
	  readyBytes = (Int)queP->end - (Int)queP->start;
	  if (readyBytes < 0) readyBytes += queP->size;
	  if ((DWord)readyBytes >= bytes) break;


	  // Wait for the ISR to wake us up. If there is already a pending
	  // wake for us, we will return from this call immediately.
	  if (timeout > 0)
		waitTicks = endTime - currTime;
	  else
		waitTicks = 0;	  // infinite
	  SysTaskWait (waitTicks);

	  // If there were any Serial errors, return with error code
	  if (gP->lineErrors) 
		{ 
		  err = serErrLineErr;
		  break;
		}

	  // Check for timeout errs from now on
	  checkTimeout = true;

	} // while(1)
  

  // No longer need signal from interrupt routine
  gP->taskID = 0;

  // Clear a possible extra Wake that may have sneaked in
  //  from the interrupt service routine before we had the
  //  chance to clear gP->taskID; this is necessary in order
  //  to prevent side-effects on our client's timing logic
  SysTaskWaitClr ();	

  
  //ErrNonFatalDisplayIf (err && err != serErrTimeOut, "err");
  return err;	

}



/***********************************************************************
 *
 * Function:     PrvSendChars
 *
 * Description:  
 *	  Transmit the specified number of characters. Returns as soon
 *	 as characters are copied into transmit buffer. 
 *
 * Parameters:   
 *	  gP         IN   library global variables
 *	  buf        IN   data to send
 *	  bytes      IN   number of bytes to send
 *	  bytesSentP OUT  number of bytes enqueued for sending
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  SerSend()
 *
 * Notes:
 *
 * History:
 *	  01-Mar-1999  RM	Created
 *	  01-Oct-1999  VMK	Fixed timeout logic to be inter-byte
 *	  02-Oct-1999  VMK	Don't convert 'timeout' inside the loop
 *	  15-Nov-1999  VMK	Return # of bytes enqueued
 *	  17-Nov-1999  VMK	Fix to allow sending of 64K or more bytes;
 *						 this is needed for compatibility with versions
 *						 of PalmOS that allow allocations >= 64K bytes.
 *	  18-Nov-1999 VMK	Fixed race condition by calling SysTaskWaitClr
 *						 after clearing gP->taskID
 *
 ***********************************************************************/
static Err 
PrvSendChars (SerGlobalsPtr gP, BytePtr bufP, DWord bytes, DWord* bytesSentP)
{
  SerQueuePtr		queP = &gP->sendQ;
  SDWord			timeout = gP->settings.ctsTimeout;
  SDWord			waitTicks;
  Err				err = 0;	
  DWord				currTime;
  DWord				endTime = 0;
  Word				minSpace;
  Boolean			checkTimeout = false;
  BytePtr			dstP;
  Word				end;
  


  *bytesSentP = bytes;		  // init sent counter

	    
  // Minimum amount of space in send buffer we need before we will
  // want to copy data into it
  minSpace = queP->size >> 1;

  // Get the task ID of this task which will be (possibly) waiting for
  //  characters
  gP->taskID = SysTaskID();
 
  // Check for timeout only if it is non-infinite and auto-CTS is requested
  if ((gP->settings.flags & serSettingsFlagCTSAutoM) && timeout >= 0)
	  checkTimeout = true;


  // ----------------------------------------------------------
  // Loop till all characters are copied into transmit queue
  // ----------------------------------------------------------
  while (bytes) 
	{
	  Word	  space, chunk, prevSpace;
	  Int	  used;

	  // See how much space left in buffer. Note that we take the
	  //  size minus the used bytes minus 1. We have to subtract one
	  //  because we can't fit 'size' bytes into the queue - that would
	  //  make the end offset equal the start offset which is true
	  //  when the queue is empty
	  used = (Int)queP->end - (Int)queP->start;
	  if (used < 0) used += queP->size;
	  space = queP->size - used - 1;


	  // -------------------------------------------------------------
	  // Figure out the endTime for this wait interval
	  // -------------------------------------------------------------
	  if (checkTimeout)
		{
		  currTime = TimGetTicks();	// init start of timeout countdown
		  endTime = currTime + timeout;
		}

	  // .....................................................
	  // If not enough space available, wait
	  // .....................................................
	  prevSpace = space;	// save for timeout detection

	  if (bytes < minSpace)
		minSpace = (Word) bytes;

	  while (space < minSpace)
		{
		  gP->sigSendFreeBytes = minSpace;

		  // check again for available space to avoid race condition
		  used = (Int)queP->end - (Int)queP->start;
		  if (used < 0) used += queP->size;
		  space = queP->size - used - 1;
	  
		  if (space >= minSpace) break;

		  // Check for timeout if not first time through loop and not
		  // inifinite timeout (endTime==0)
		  currTime = TimGetTicks ();
		  if (checkTimeout && currTime >= endTime)
			{
			  // If transmit queue space changed since beginning of this
			  //  timeout interval, reset the timeout counter and keep waiting
			  if (timeout > 0 && space != prevSpace)
				{
				  // Save the current space for a subsequent check
				  prevSpace = space;

				  // Reset the timeout counter
				  endTime = currTime + timeout;
				}

			  // Otherwise, abort the wait with a "timeout" error
			  else
				{
				  err = serErrTimeOut;
				  break;
				}
			}


		  // Wait for the ISR to wake us up. If there is already a pending
		  // wake for us, we will return from this call immediately.
		  if (checkTimeout)
			waitTicks = endTime - currTime;
		  else
			waitTicks = 0;	  // infinite
		  SysTaskWait (waitTicks);

		} // If not enough space available, wait

	  // If there were any errors, return with error code
	  if (gP->lineErrors) 
		  err = serErrLineErr;

	  if (err)
		break;


	  // -----------------------------------------------------------
	  // Copy the data into the transmit queue
	  // -----------------------------------------------------------
	  if (bytes > space)
		chunk = space;
	  else
		chunk = (Word) bytes;
	  bytes -= chunk;

	  dstP = queP->dataP + queP->end;
	  end = queP->end;
	  while (chunk--)
		{
		  *dstP++ = *bufP++;
		  if (end == queP->size-1) 
			{
			  end = 0;
			  dstP = queP->dataP;
			}
		  else
			end++;

		  queP->end = end;
		}

	  // Tell the hardware to start sending
	  SerHwControl (gP, serHwCtlSendIntEnable, 0, 0);
		
	} // while (bytes)


  // No longer need signal from interrupt routine
  gP->taskID = 0;

  // Clear a possible extra Wake that may have sneaked in
  //  from the interrupt service routine before we had the
  //  chance to clear gP->taskID; this is necessary in order
  //  to prevent side-effects on our client's timing logic
  SysTaskWaitClr ();	

  // Return number of bytes that were enqueued
  *bytesSentP -= bytes;

  //ErrNonFatalDisplayIf (err, "err");
  return err;	
}


/***********************************************************************
 *
 * Function:     SerLibInstall
 *
 * Description:  This routine installs the dispatch table of our
 *	  library into the library table entry for this library
 *
 * Parameters:   
 *	  refNum		IN	refNum of library
 *	  libEntryP	IN	SysLibTblEntryPtr for this library
 *	  dispatchTblP  IN pointer to our library dispatch table
 *
 * Returns:     
 *	  0 if no error
 *
 * Called By:	
 *	  SerEntry() in Ser16650Dispatch.c, which is called
 *	  directly from the system's SysLibInstall() when installing 
 *	  the library
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err	
SerLibInstall (Word refNum, SysLibTblEntryPtr entryP, 
				   Ptr*  dispatchTblP)
{
  Err					err = 0;

  // Install our dispatch table pointer into the library entry
  entryP->dispatchTblP = dispatchTblP;

  // If we need to allocate globals now, we would store them
  //  in entryP->globalsP

  ErrNonFatalDisplayIf (err, "err");
  return (err);
}



/***********************************************************************
 *
 * Function:     SerOpen
 *
 * Description:  
 *	  Open the serial library for the given port. 
 *
 * Parameters:   
 *	  refNum   IN  library reference number (see SysLoadLibrary)
 *    port     IN  port or endpoint to open, not currently used
 *    baud     IN  buad rate, not used
 *
 * Returns:      error code
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerOpen (Word refNum, Word port, DWord baud)
{
  SerGlobalsPtr		gP = 0;
  SysLibTblEntryPtr	libEntryP;
  Err				err;
  Byte				removable;
  Word				cardNo;
  HsDrcGlobalsType*	cardGP = NULL;


  // Allocate our globals now if necessary
  libEntryP = SysLibTblEntry(refNum);
  gP = libEntryP->globalsP;
  if (!gP) 
	{
	  gP = MemPtrNew (sizeof (SerGlobalsType));
	  if (!gP)  
		{
		  err = memErrNotEnoughSpace;
		  goto Exit;
		}
	  MemPtrSetOwner (gP, 0);
	  MemSet (gP, sizeof (SerGlobalsType), 0);
	  libEntryP->globalsP = gP;
	}
		  

  // Increment open count
  gP->openCount++;
  if (gP->openCount > 1) 
	return serErrAlreadyOpen;

	  
  // Fill in default serial settings. 
  gP->settings.baudRate = baud;
  gP->settings.flags = serDefaultSettings;
  gP->settings.ctsTimeout = serDefaultCTSTimeout;

  // Clear error code.
  gP->lineErrors = 0;


  // -----------------------------------------------------------
  // Patch the "FatalError" system trap, if necessary, to work
  //  around the timing-related "NetLibUtils.c, Line:1112, Command not done"
  //  crashing bug in PalmOS's NetLib.
  // -----------------------------------------------------------
  PrvApplySystemPatches (gP);


  // -----------------------------------------------------------
  // Allocate the receive buffer
  // -----------------------------------------------------------
  gP->recvQ.dataP = gP->recvQ.defDataP = MemPtrNew (serDefaultRecvQSize);
  if (!gP->recvQ.dataP) 
	{
	  err = memErrNotEnoughSpace;
	  goto Exit;
	}

  MemPtrSetOwner (gP->recvQ.dataP, 0);
  gP->recvQ.start = 0;
  gP->recvQ.end = 0;
  gP->recvQ.size = serDefaultRecvQSize;

  
  // -----------------------------------------------------------
  // Allocate the  send buffer
  // -----------------------------------------------------------
  gP->sendQ.dataP = gP->sendQ.defDataP = MemPtrNew (serDefaultSendQSize);
  if (!gP->sendQ.dataP)  
	{
	  err = memErrNotEnoughSpace;
	  goto Exit;
	}

  MemPtrSetOwner (gP->sendQ.dataP, 0);
  gP->sendQ.start = 0;
  gP->sendQ.end = 0;
  gP->sendQ.size = serDefaultSendQSize;
  


  // -----------------------------------------------------------
  // Init the hardware. Look for the first removable card. 
  // -----------------------------------------------------------
  err = serErrBadPort;
  for (cardNo = 0; cardNo < MemNumCards(); cardNo++)
	{
	  err = HsCardAttrGet (cardNo, hsCardAttrRemovable, &removable);
	  if (err || removable) break;
	}
  // If no removable card found, err
  if (err || !removable) { err = serErrBadPort; goto Exit;}


  // Init performance monitoring support. 
  err = HsCardAttrGet (cardNo, hsCardAttrCardParam, &cardGP);
  if (err || !cardGP)  { err = serErrBadPort; goto Exit;}
  gP->perfMonP = &cardGP->serPerfMon;
  gP->perfMonOn = cardGP->perfMonOn;
  

  // Init the hardware - this call will make sure the right card is
  //  installed 
  err = SerHwInit (gP, cardNo);
  if (err) goto Exit;



  // -----------------------------------------------------------
  // Set default settings
  // -----------------------------------------------------------
  err = SerSetSettings (refNum, &gP->settings);
  

  // Initialize the receive trigger threshold
  gP->sigRecvUsedBytes = 1;


Exit:

  // Cleanup after errors
  if (err)
	{
	  ErrNonFatalDisplayIf (err && err != serErrBadPort, "err");
	  if (gP) SerClose (refNum);
	}
  return err;
}


/***********************************************************************
 *
 * Function:     SerClose
 *
 * Description:  Closes up a serial library
 *
 * Parameters:   
 *	  refNum   IN  library reference number (see SysLoadLibrary)
 *
 * Returns:      
 *	  error code
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerClose (Word refNum)
{
  SerGlobalsPtr		gP;
  Err				err;
  SysLibTblEntryPtr	libEntryP=0;

  
  // Get our globals ptr
  gP = PrvGetGlobals (refNum);
  
  // If not open, return err
  if ((!gP) || (!gP->openCount))
	  return serErrNotOpen;


  // If we're just decrementing the open count, return now
  gP->openCount--;
  if (gP->openCount)
	  return serErrStillOpen;


  // If we're about to *really* close the serial manager, put the 
  //  serial services to sleep
  SerSleep (refNum);


  // Tell the hardware we're done
  SerHwFree (gP);


  // --------------------------------------------------------
  // Dispose of the receive and send queues
  // --------------------------------------------------------
  if (gP->recvQ.defDataP) 
	{	
	  err = MemPtrFree (gP->recvQ.defDataP);
	  if (err)	DbgBreak();
	}
  if (gP->sendQ.defDataP) 
	{	
	  err = MemPtrFree (gP->sendQ.defDataP);
	  if (err)	DbgBreak();
	}
  

  // -----------------------------------------------------------
  // Remove the "FatalError" system trap patch that may have been
  //  installed by SerOpen
  // -----------------------------------------------------------
  PrvRemoveSystemPatches (gP);
  
  // --------------------------------------------------------
  // Dispose globals 
  // --------------------------------------------------------
  MemPtrFree (gP);
  libEntryP = SysLibTblEntry(refNum);
  libEntryP->globalsP = 0;

  return 0;
}



/***********************************************************************
 *
 * Function:     SerSleep
 *
 * Description:  
 *	  Called by System when going to sleep or when the connection
 *    is closed.
 *
 * Parameters:   
 *	  refNum   IN  library reference number (see SysLoadLibrary)
 *               
 * Returns:      
 *	  error code
 *
 * Called By:
 *	  System when it goes into sleep mode
 *
 * Note:
 *	  This routine may be called from an interrupt by the system software.
 *	  For this reason, it (or anything it calls) should not call any functions
 *	  that are not allowed at interrupt time; it must also keep stack usage
 *	  to a minimum.
 *
 *	  Because this routine may be called during a power emergency, it must
 *	  always accomplish its task in just a few instructions.  Waiting
 *	  is *not* permitted here.
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSleep (Word refNum)
{
  SerGlobalsPtr	gP;

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open, return
  if ( (!gP)|| (!gP->openCount) )
	  return 0;
  

  // Put hardware to sleep
  SerHwSleep (gP);

  return 0;
}


/***********************************************************************
 *
 * Function:     SerWake
 *
 * Description:  Called by System when Waking up
 *
 * Parameters:   refNum   IN  library reference number (see SysLoadLibrary)
 *
 * Returns:      error code  
 *
 * Called By:
 *	  System when it comes out of sleep mode
 *
 * Note:
 *	  This routine may be called from an interrupt by the system software.
 *	  For this reason, it (or anything it calls) should not call any functions
 *	  that are not allowed at interrupt time; it must also keep stack usage
 *	  to a minimum
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerWake (Word refNum )
{
  SerGlobalsPtr		gP;
  
  // Get our globals ptr
  gP = PrvGetGlobals (refNum);
  
  // If not open, return
  if ( (!gP)|| (!gP->openCount) )
	  return 0;

  // Take hardware out of sleep
  SerHwWake (gP);


  return 0;
}


/***********************************************************************
 *
 * Function:     SerGetSettings
 *
 * Description:  
 *	  Retreives settings of serial port.
 *
 * Parameters:   
 *	  refNum	  IN	library reference number (see SysLoadLibrary)
 *    *settingsP  OUT	settings returned in this buffer
 *               
 * Returns:      
 *	  error code
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerGetSettings (Word refNum, SerSettingsPtr settingsP)
{
  SerGlobalsPtr		gP;

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);
	  
  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  *settingsP = gP->settings;

  return 0;
}


/***********************************************************************
 *
 * Function:     SerSetSettings
 *
 * Description:  
 *	  Changes settings of serial port.
 *
 * Parameters:   
 *	  refNum    IN  library reference number (see SysLoadLibrary)
 *    settingsP IN  new setting
 *               
 * Returns:      
 *	  error code
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSetSettings (Word refNum, SerSettingsPtr settingsP)
{
  SerGlobalsPtr		gP;
  Err				err;
  Word				valueLen;

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);
  
  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}


  // --------------------------------------------------------------
  // Setup the hardare appropriately
  // --------------------------------------------------------------
  // Flags
  valueLen = sizeof (settingsP->flags);
  err = SerHwControl (gP, serHwCtlFlagsSet, &settingsP->flags,
			&valueLen);
  if (err) goto Exit;


  // Baud Rate
  valueLen = sizeof (settingsP->baudRate);
  err = SerHwControl (gP, serHwCtlBaudRateSet, &settingsP->baudRate,
			&valueLen);
  if (err) goto Exit;


  // settingsP->ctsTimeout Timeout just gets saved in our globals 


  // Save them in our globals
  gP->settings = *settingsP;

Exit:
  //ErrNonFatalDisplayIf (err, "err");
  return err;
}


/***********************************************************************
 *
 * Function:     SerGetStatus
 *
 * Description:  
 *	  Returns status of a serial connection.  The status returned
 *    is compatible with RS-232 signaling.
 *
 * Parameters:   
 *	  refNum    IN	  library reference number (see SysLoadLibrary)
 *	  ctsOnP    OUT	  true if clear to send signal is on.
 *	  dsrOnP    OUT	  true if data terminal ready signal is on
 *
 * Returns:      
 *	  line error, 0 if none
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Word 
SerGetStatus (Word refNum, BooleanPtr ctsOnP, BooleanPtr dsrOnP)
{
  SerGlobalsPtr	gP;
  Byte			on;
  Word			valueLen;

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return 0;
	}
  
  // --------------------------------------------------------------
  // Query the hardware for the state of the cts and dsr inputs
  // --------------------------------------------------------------
  // CTS
  valueLen = sizeof (on);
  SerHwControl (gP, serHwCtlCTS, &on, &valueLen);
  *ctsOnP = on;

  // DSR
  valueLen = sizeof (on);
  SerHwControl (gP, serHwCtlDSR, &on, &valueLen);
  *dsrOnP = on;


  return gP->lineErrors;
}



/***********************************************************************
 *
 * Function:     SerClearErr
 *
 * Description:  
 *	  Clears current error out of serial port.  Also reinitialized
 *    the main IN and Out endpoints.
 *
 * Parameters:   
 *	  refNum    IN  library reference number (see SysLoadLibrary)
 *
 * Returns:      
 *	  error code
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerClearErr (Word refNum)
{
  SerGlobalsPtr	gP;  
  

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}
  
  // Clear saved  error code
  gP->lineErrors = 0;

  return 0;
}



/***********************************************************************
 *
 * Function:     SerSend10
 *
 * Description:  
 *	  PalmOS version 1.0 API for SerSend.
 *
 * Parameters:   
 *	  refNum    IN  library reference number (see SysLoadLibrary)
 *	  bufP      IN  bytes to send
 *	  size      IN  number of bytes to send
 *
 * Returns:      error codw
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSend10 (Word refNum, VoidPtr bufP, DWord size)
{
  Err		err;

  SerSend (refNum, bufP, size, &err);

  //ErrNonFatalDisplayIf (err, "err");
  return (err);
}


 
/***********************************************************************
 *
 * Function:     SerSend
 *
 * Description:  
 *	  Sends 1 or more bytes of data over the serial port.
 *
 * Parameters:   
 *	  refNum    IN   library reference number (see SysLoadLibrary)
 *    bufP      IN   bytes to send
 *    size      IN   number of bytes to send
 *    errP      OUT  error code, 0 if none
 *
 * Returns:      
 *	  number of bytes sent.
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  01-Mar-1999  RM	Created
 *	  01-Oct-1999 VMK	Fixed timeout logic to be inter-byte
 *	  15-Nov-1999 VMK	Fix the sent byte count logic to return
 *						 the # of bytes that were enqueued in the
 *						 event of error
 *	  17-Nov-1999 VMK	Fix to allow sending of 64K or more bytes;
 *						 this is needed for compatibility with versions
 *						 of PalmOS that allow allocations >= 64K bytes.
 *
 ***********************************************************************/
DWord 
SerSend (Word refNum, VoidPtr bufP, DWord count, Err* errP)
{	
  SerGlobalsPtr		gP;
  Err	err = 0;
  DWord	numSent = 0;
#ifdef PERF_MON
  DWord	startTicks = 0;
#endif


  // Make sure writable pointer arguments are valid
  ErrFatalDisplayIf (!errP, "null ptr arg");
    
  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  count = 0;
	  err = serErrNotOpen;
	  goto Exit;
	}

#ifdef PERF_MON
  // Record starting ticks for performance monitoring
  if (gP->perfMonOn)
	startTicks = TimGetTicks ();
#endif

  
  // Handle the transmit in the interrupt service routine, and signal
  // completion with a semaphore.
  err = PrvSendChars (gP, bufP, count, &numSent);


#ifdef PERF_MON
  // Monitor performance
  if (gP->perfMonOn)
	{
	  DWord	  elapsedTicks;

	  elapsedTicks = (TimGetTicks() - startTicks);
	  gP->perfMonP->serSendCalls++;
	  gP->perfMonP->sendReqTotal += count;
	  gP->perfMonP->sendQTotal += numSent;
	  gP->perfMonP->sendTicks += elapsedTicks;
	  if (elapsedTicks > gP->perfMonP->maxSendTicks)
		{
		  gP->perfMonP->maxSendTicks = elapsedTicks;
		  gP->perfMonP->maxSendTicksReq = count;
		}

	  if (count > gP->perfMonP->maxSendReq)
		gP->perfMonP->maxSendReq = count;
	  if (err)
		{
		  gP->perfMonP->sendErrors++;
		  if (err == serErrTimeOut)
			gP->perfMonP->sendTimeouts++;
		}
	}
#endif

Exit:
	*errP = err;

  //ErrNonFatalDisplayIf (err, "err");
  return (numSent);
}



/***********************************************************************
 *
 * Function:     SerSendWait
 *
 * Description:  
 *	  Waits for all characters in the send buffer to be sent
 *    over the serial port or a timeout, whichever comes sooner.
 *
 *	  Uses CTS timeout if auto-CTS is enabled, otherwise waits
 *	  forever
 *
 * Parameters:   
 *	  refNum    IN  library reference number (see SysLoadLibrary)
 *	  timeout	IN	RESERVED FOR FUTURE ENHANCEMENTS; SET TO -1
 *					 FOR COMPATIBILITY
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * Notes:
 *
 * History:
 *	  01-Mar-1999  RM	Created
 *	  23-Sep-1999  VMK	Clear the taskID when finished waiting
 *	  01-Oct-1999  VMK	Fixed timeout logic to be inter-byte
 *	  18-Nov-1999  VMK	Fixed race condition by calling SysTaskWaitClr
 *						 after clearing gP->taskID
 *	  18-Nov-1999  VMK	Fixed CTS timeout logic related to SerHwSendFIFOWait
 *
 ***********************************************************************/
Err 
SerSendWait (Word refNum, SDWord  timeout)
{
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  DWord				currTime;
  DWord				endTime = 0;
  Word				currStart, prevStart;
  SDWord			waitTicks;
  Err				err = 0;
  Boolean			checkTimeout = false;


  // Get our globals ptr and send queue
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  queP = &gP->sendQ;

  // If que is empty, return right away
  if (queP->end == queP->start)
	return 0;
  
  
  // Get CTS timeout; we'll use it only if auto-CTS has been
  //  requested by the client
  timeout = gP->settings.ctsTimeout;
 
  // Check for timeout only if it is non-infinite and auto-CTS is requested
  if ((gP->settings.flags & serSettingsFlagCTSAutoM) && timeout >= 0)
	{
	  checkTimeout = true;


	  // -------------------------------------------------------------
	  // Figure out the initial endTime
	  // -------------------------------------------------------------
	  currTime = TimGetTicks();	// init start of timeout countdown
	  endTime = currTime + timeout;
	}
	  

  // Get the task ID of this task which will be (possibly) waiting for
  //  characters
  gP->taskID = SysTaskID();
  
  // Desire entire buffer to be empty
  gP->sigSendFreeBytes = queP->size;


  // -------------------------------------------------------------
  // Loop until transmit queue is empty
  // -------------------------------------------------------------
  prevStart = queP->start;
  do
	{
	  currStart = queP->start;
	  if (currStart == queP->end)
		break;

	  // Check for timeout if not first time through loop and not
	  // inifinite timeout (endTime==0)
	  currTime = TimGetTicks ();
	  if (checkTimeout && currTime >= endTime)
		{
		  // If transmit queue start changed since beginning of this
		  //  timeout interval, reset the timeout counter and keep waiting
		  if (timeout > 0 && currStart != prevStart)
			{
			  // Save the current start for a subsequent check
			  prevStart = currStart;

			  // Reset the timeout counter
			  endTime = currTime + timeout;
			}

		  // Otherwise, abort the wait with a "timeout" error
		  else
			{
			  err = serErrTimeOut;
			  break;
			}
		}

	  // Wait for the ISR to wake us up. If there is already a pending
	  // wake for us, we will return from this call immediately.
	  if (checkTimeout)
		waitTicks = endTime - currTime;
	  else
		waitTicks = 0;	  // infinite
	  SysTaskWait (waitTicks);

	} while (!err);


  // Now, wait for the transmit FIFO to empty as well
  if (!err)
	{
	  err = SerHwSendFIFOWait (gP, checkTimeout, timeout);
	}
	
  
  // No longer need signal from interrupt routine
  gP->taskID = 0;

  // Clear a possible extra Wake that may have sneaked in
  //  from the interrupt service routine before we had the
  //  chance to clear gP->taskID; this is necessary in order
  //  to prevent side-effects on our client's timing logic
  SysTaskWaitClr ();	

  //ErrNonFatalDisplayIf (err && err != serErrTimeOut, "err");
  return err;
}



/***********************************************************************
 *
 * Function:     SerSendCheck
 *
 * Description:  
 *	  Returns how many characters are left in the
 *    transmit buffer
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    numBytesP  OUT  number of bytes in transmit queue.
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSendCheck (Word refNum, DWord* numBytesP)
{  
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  SWord				bytes;

  // Get our globals ptr and send queue
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  queP = &gP->sendQ;
  
  bytes = (Int)queP->end - (Int)queP->start;
  if (bytes < 0) bytes += queP->size;

  *numBytesP = bytes;
  return 0;

}


/***********************************************************************
 *
 * Function:     SerSendFlush
 *
 * Description:  
 *	  Flushes characters out of the transmit queue.
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSendFlush (Word refNum)
{	
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  Word				status;


  // Get our globals ptr and send queue
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  queP = &gP->sendQ;

  
  // Interrupts off
  status = SysDisableInts();
  queP->start = queP->end = 0;
  SysRestoreStatus (status);

  // NOTE: may also want to reset the transmit FIFO?

  return 0;
}



/***********************************************************************
 *
 * Function:     SerReceive10
 *
 * Description:  
 *	  PalmOS version 1.0 API compatible call to SerReceive 
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    rcvBufP    IN   pointer to receive buffer
 *    bytes      IN   number of bytes to receive
 *    timeout    IN   timeout in ticks, 0 for none, -1 forever
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerReceive10 (Word refNum, VoidPtr rcvBufP, DWord bytes, SDWord timeout)
{
  Err	err;

  SerReceive (refNum, rcvBufP, bytes, timeout, &err);

  //ErrNonFatalDisplayIf (err, "err");
  return( err );
}



/***********************************************************************
 *
 * Function:     SerReceive
 *
 * Description:  
 *	  Receive the specified number of bytes  or returns with
 *    error if a line error or timeout is encountered.
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    rcvBufP    IN   pointer to receive buffer
 *    bytes      IN   number of bytes to receive
 *    timeout    IN   inter-byte timeout in ticks, 0 for none, -1 forever
 *
 * Returns:      number of bytes received
 *
 * Called By:
 *	  Applications
 *
 * Note:
 *
 * History:
 *	  01-Mar-1999  RM	  Created
 *	  01-Oct-1999 VMK	  Fixed timeout logic to be inter-byte
 *
 ***********************************************************************/
DWord 
SerReceive (Word refNum, VoidPtr rcvBufP, DWord count, SDWord timeout, 
			   Err* errP)
{
  BytePtr			bufP = (BytePtr)rcvBufP;
  ULong				bytesLeft = count;			// save # of bytes to receive
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;

  SWord				maxChunkSize, chunk;
  register BytePtr	srcP;
  register Short	start;
  Short				maxStart;
  Err				err = 0;
#ifdef PERF_MON
  DWord				startTicks = 0;
#endif

  
  // Make sure writable ptr arguments are valid
  ErrFatalDisplayIf((!errP || (!rcvBufP && count)), "null ptr arg" );
  
  *errP = 0;						// init return error code
	  
  // Get our globals ptr and receive queue
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  err = serErrNotOpen;
	  goto Exit;
	}


#ifdef PERF_MON
  // Record starting ticks for performance monitoring
  if (gP->perfMonOn)
	startTicks = TimGetTicks ();
#endif


  queP = &gP->recvQ;
  
  // Loop on chunks that are smaller than the size of our queue
  maxChunkSize = queP->size >> 1;	   
  while (bytesLeft) 
	{
	  // If there are any serial errors, return with error code
	  if (gP->lineErrors)
		{
		  err = serErrLineErr;
		  break;
		}
		  
	  // Figure out the chunk size
	  chunk = (SWord)bytesLeft;
	  if (chunk > maxChunkSize)
		  chunk = maxChunkSize;
	  
	  
	  // Wait till we have enough bytes in the queue
	  err = PrvWaitForChars (gP, chunk, timeout);
	  if ( err )
		break;
	  
	  
	  // Take out this chunk from the size
	  bytesLeft -= chunk;


	  // Transfer the data from the queue to the caller's buffer
	  start = queP->start;
	  srcP = (BytePtr)queP->dataP + start;
	  maxStart = queP->size - 1;
	  while (chunk--) 
		{
		  *bufP++ = *srcP++;
		  if (start == maxStart) 
			{
			  start = 0;
			  srcP = (BytePtr)queP->dataP;
			}
		  else 
			start++;

		  queP->start = start;
		}

	  // --------------------------------------------------------------
	  // If the interrupt routine had filled the receive queue and disabled
	  //  interrupts, re-enable them now
	  // --------------------------------------------------------------
	  if (!err && gP->hw.needRecvIntEnable)
		{
		  gP->hw.needRecvIntEnable = false;
		  SerHwControl (gP, serHwCtlRecvIntEnable, 0, 0);
		}

	} // while (bytesLeft) 



#ifdef PERF_MON
  // Monitor performance
  if (gP->perfMonOn)
	{
	  DWord	  elapsedTicks;

	  elapsedTicks = (TimGetTicks() - startTicks);
	  gP->perfMonP->serReceiveCalls++;
	  gP->perfMonP->recvReqTotal += count;
	  gP->perfMonP->recvDQTotal += (count - bytesLeft);
	  gP->perfMonP->recvTicks += elapsedTicks;
	  if (elapsedTicks > gP->perfMonP->maxRecvTicks)
		gP->perfMonP->maxRecvTicks = elapsedTicks;
	  if (count > gP->perfMonP->maxRecvReq)
		gP->perfMonP->maxRecvReq = count;
	  if (err)
		{
		  gP->perfMonP->recvErrors++;
		  if (err == serErrTimeOut)
			gP->perfMonP->recvTimeouts++;
		}
	}
#endif


Exit:
  *errP = err;
  //ErrNonFatalDisplayIf (err && err != serErrTimeOut, "err");

  return (count - bytesLeft);
}




/***********************************************************************
 *
 * Function:     SerReceiveWait
 *
 * Description:  
 *	  Wait for the specified number of bytes to arrive at the
 *	  serial port, or for a timeoout
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    bytes      IN   number of bytes to wait for
 *    timeout    IN   inter-byte timeout in ticks, 0 for none, -1 forever
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  01-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerReceiveWait (Word refNum, DWord bytes, SDWord timeout)
{

  Err				err;
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  

  // Get our globals ptr and receive queue
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  queP = &gP->recvQ;

  // If number of bytes is bigger than our queue size, we can't handle 
  //  this call
  if (bytes > queP->size)
	{
	  ErrNonFatalDisplayIf (1,  "queue too small");
	  return serErrBadParam;
	}
  
  // If there are any serial errors, return with error code
  if (gP->lineErrors) 
	return serErrLineErr;
  
  // Wait till we have enough bytes in the queue
  err = PrvWaitForChars (gP, bytes, timeout);
	  
  //ErrNonFatalDisplayIf (err && err!=serErrTimeOut, "err");
  return err;
}




/***********************************************************************
 *
 * Function:     SerReceiveCheck
 *
 * Description:  
 *	  Returns the number of characters currently in the
 *    receive queue.
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    numBytesP  OUT  number of character in the recive queue.
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerReceiveCheck (Word refNum,  DWord* numBytesP)
{
  Int				readyBytes;
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
   
  // Assume none
  *numBytesP = 0;
  
  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  // Get the receive que.
  queP = &gP->recvQ;

  // If there are any serial errors, return with error code
  if (gP->lineErrors) 
	return serErrLineErr;
	  
  // See how much is in the queue
  readyBytes = (Int)queP->end - (Int)queP->start;
  if (readyBytes < 0) readyBytes += queP->size;
  
  *numBytesP = readyBytes;
  return 0;
	
}



/***********************************************************************
 *
 * Function:     SerReceiveFlush
 *
 * Description:  
 *	  Flushes all characters in the receive buffer and
 *    all characters coming into the serial port until no
 *    more arrive within the timeout period.  And clears the saved
 *    error status.
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    timeout    IN   timeout in ticks, 0 for none, -1 forever
 *               
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
#define	prvMaxFlushErrorCount	50
void 
SerReceiveFlush (Word refNum, SDWord timeout)
{
  Byte				byteBuf;
  Err				err;
  Int				errCount = 0;
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  Word				status;
 

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return;
	}

  // Get the receive que.
  queP = &gP->recvQ;


  // Interrupts off and flush existing chars
  status = SysDisableInts();
  queP->start = queP->end = 0;
  SysRestoreStatus (status);

  // If no timeout, return now
  if (timeout == 0) return;

  while ( true )
	{
	  SerReceive (refNum, &byteBuf, 1, timeout, &err );
	  if ( !err )
		continue;

	  // timeout
	  if (err == serErrTimeOut)
		break;

	  // Some other error
	  SerClearErr(refNum);					// clear pending errors
	  errCount++;
	  if (errCount > prvMaxFlushErrorCount)
		break;
	}


  SerClearErr(refNum);						// clear pending errors
}


/***********************************************************************
 *
 * Function:     SerSetReceiveBuffer
 *
 * Description:  
 *	  Specify a new input buffer.
 *
 * Parameters:   
 *	  refNum     IN   library reference number (see SysLoadLibrary)
 *    bufP       IN   pointer to the new buffer(must be locked)
 *    bufSize    IN   size, in bytes, of the new input buffer.  Set
 *                    this value to 0 to restore the default buffer.
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerSetReceiveBuffer (Word refNum, VoidPtr bufP, Word bufSize)
{
  Err				err = 0;
  Word				sysStatus;
  SerQueuePtr		queP;
  SerGlobalsPtr		gP;


  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  queP = &gP->recvQ;


  // --------------------------------------------------------------
  // If replacing:
  // -----------------------------------------------------------
  if (bufSize) 
	{
	  sysStatus = SysDisableInts();
	  queP->dataP = bufP;
	  queP->size = bufSize;
	  queP->start = queP->end = 0;		
	  SysRestoreStatus( sysStatus );
	  
	  // Free the original buffer
	  if (queP->defDataP) 
		{
		  MemPtrFree (queP->defDataP);
		  queP->defDataP = 0;
		}
	}
  
  // --------------------------------------------------------------
  // otherwise, restoring:
  // --------------------------------------------------------------
  else 
	{
	  // Re-allocate the original receive buffer, if it was disposed of
	  if (!queP->defDataP) 
		{
		  queP->defDataP = MemPtrNew (serDefaultRecvQSize);
		  if (queP->defDataP)
			  MemPtrSetOwner (queP->defDataP, 0);
		  else 
			{
			  ErrFatalDisplayIf (1, "NoRAM");
			  err = memErrNotEnoughSpace;
			}
		}

	  sysStatus = SysDisableInts();
	  queP->dataP = queP->defDataP;
	  if (queP->dataP)
		queP->size = serDefaultRecvQSize;
	  else
		queP->size = 0;
	  queP->start = queP->end = 0;		
	  SysRestoreStatus( sysStatus );
	}

  ErrNonFatalDisplayIf (err, "err");
  return (err);
}


/***********************************************************************
 *
 * Function:     SerReceiveWindowOpen
 *
 * Description:  
 *	  "Back Door" into the serial receive queue. 
 *	  This is used by applications (like TCP media layers)
 *	  that need faster access to received characters from the
 *	  serial port.
 *	  
 *	  This routine returns a pointer to the serial library's
 *	  receive queue so that an application can fetch data out
 *	  of the queue directly. It also returns the number of bytes
 *	  that can be read from the queue at this time. After the
 *	  application has pulled data out of the queue, it needs to
 *	  call SerReceiveWindowClose() and tell it how many bytes have
 *	  been pulled. 
 *	  
 *	  Applications that want to empty the queue entirely should
 *	  call SerReceiveWindowOpen/SerReceiveWindowClose repeatedly 
 *	  until SerReceiveWindowOpen returns 0 bytes.
 *	  
 *	  NOTE: Once an application starts using the SerReceiveWindowOpen/
 *	  	SerReceiveWindowClose() routines, SerReceive() may return
 *	  	unpredictable results (i.e. duplicate data or missing data). 
 *
 * Parameters:   
 *	  refNum	  IN   library reference number (see SysLoadLibrary)
 *	  bufPP 	  OUT  the address of the next available byte in
 *	  					the serial library's receive queue
 *	  sizeP		  OUT  number of bytes available in the window.
 *	  					NOTE: this may be smaller than the total # of
 *	  					  bytes in the queue but will be at least 1 as long
 *	  					  as their are any bytes at all in the queue.
 *	  					NOTE: *sizeP will always contain the number of bytes
 *	  					  available, even if an error is returned 
 *	  					  (like serErrLineErr).
 *
 *  Called by: Applications that need faster access to received data.
 *					Most notably, the TCP/IP media layers like SLIP and PPP.
 *
 *  Returns: 
 *	  0 			- if no error, caller should still check *sizeP to
 *						see if there are any bytes available though
 *	  serErrLineErr - Line error detected. Caller should call SerClearErr()
 *						to clear the error. Caller can still read data out
 *						as long as *sizeP is non-zero however.
 *               
 *               
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *	  PPP and SLIP interfaces of NetLib
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerReceiveWindowOpen (Word refNum, BytePtr* bufPP, DWord* sizeP)
{
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  Int				readyBytes;
  
  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  // Get the main endpoint's receive buffer.
  queP = &gP->recvQ;

  // Calculate the # of bytes available before we wrap around
  readyBytes = (Int)queP->end - (Int)queP->start;
  if (readyBytes < 0) 
	readyBytes = (Int)queP->size - (Int)queP->start;
  *sizeP = readyBytes;
  
  // Calculate pointer to start of data
  *bufPP = (BytePtr)queP->dataP + queP->start;
  
  // Return line errors, if any
  if (gP->lineErrors) 
	return serErrLineErr;
  else 
	return 0;
}


/***********************************************************************
 *
 * Function:     SerReceiveWindowClose
 *
 * Description:  
 *	  Sister routine to SerReceiveWindowOpen(). After an
 *	  application has pulled a number of bytes out of the
 *    receive window, it MUST call this routine to inform the
 *    Serial library how many bytes have been pulled. 
 *
 * Parameters:   
 *	  refNum       IN   library reference number (see SysLoadLibrary)
 *    bytesPulled  IN   number of bytes that were pulled out of 
 *                                 receive window.
 *
 * Called by:    
 *	  Applications that need faster access to received data.
 *    Most notably, the TCP/IP media layers like SLIP and PPP.
 *
 * Returns:      
 *	  error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *	  PPP and SLIP interfaces of NetLib
 *
 * History:
 *	  01-Mar-1999  RM	  Created
 *	  23-Sep-1999  VMK	  Re-enable receive interrupts, if needed
 *
 ***********************************************************************/
Err 
SerReceiveWindowClose (Word refNum, DWord bytesPulled)
{
  SerGlobalsPtr		gP;
  SerQueuePtr		queP;
  SWord				newStart;
  Err				err = 0;
  

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  // Get the main endpoint's receive buffer.
  queP = &gP->recvQ;

  // Update the qStart for the number of bytes pulled
  newStart = queP->start + (Word)bytesPulled;
  
  // SHOULD NEVER BE GREATER!!
  if (newStart > queP->size) err = -1;
  
  // If we've pulled to the end of the queue
  if (newStart >= queP->size) 
	  newStart = 0;			
  
  // Update the new start.
  queP->start = newStart;

  // --------------------------------------------------------------
  // If the interrupt routine had filled the receive queue and disabled
  //  interrupts, re-enable them now
  // --------------------------------------------------------------
  if (gP->hw.needRecvIntEnable && bytesPulled)
	{
	  gP->hw.needRecvIntEnable = false;
	  SerHwControl (gP, serHwCtlRecvIntEnable, 0, 0);
	}
  
  ErrNonFatalDisplayIf (err, "Pulled too many");
  return err;
}



/***********************************************************************
 *
 * Function:     SerSetWakeupHandler
 *
 * Description:  
 *	  Can be used by applications that can't block on the
 *	  SerReceive() call. By setting an alternate wakeup handler, an application
 *	  can have the Serial Library call it's own custom routine when a 
 *	  given number of bytes get enqueued by the interrupt handler. 
 *	  
 *	  This wakeup handler could then send a message to a mailbox, set
 *	  a semaphore, etc. As long as it performed calls that are safe to
 *	  do at interrupt time.
 *	  
 *	  IMPORTANT: Once an alternate wakeup handler has been installed, 
 *	  the application MUST NOT call SerReceive if it might block. The
 *	  application MUST make sure that enough characters have already been
 *	  received before calling SerReceive. 
 *
 * Parameters:   
 *    refNum     IN   library reference number (see SysLoadLibrary)
 *	  procP      IN   pointer to wakeup proc, or 0 to remove it.
 *	  refCon     IN   refCon that will be passed to wakeup proc
 *               
 * Called by:
 *    Applications that need faster access to received data.
 *    Most notably, the TCP/IP media layers like SLIP and PPP.
 *
 * Returns: 
 *    error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *	  PPP and SLIP interfaces of NetLib
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *	  23-Sep-1999 VMK	  Disable interrupts while we muck with the globals
 *
 ***********************************************************************/
Err 
SerSetWakeupHandler (Word refNum, SerWakeupHandler procP, DWord refCon)
{
  SerGlobalsPtr	gP;
  Word	  intsStatus;
  

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}

  // Set info

  // Disable interrupts while we muck with the globals
  intsStatus = SysDisableInts ();

  gP->wakeupHandler = (ProcPtr)procP;
  gP->wakeupRefcon = refCon;
  gP->sigRecvUsedBytes = 0;
  
  // Restore interrupts
  SysRestoreStatus (intsStatus);

  // no err
  return 0;
}



/***********************************************************************
 *
 * Function:     SerPrimeWakeupHandler
 *
 * Description:  
 *	  Used in conjunction with SerSetWakeupHandler. This
 *	  primes the wakeup handler to be called when 'minBytes' arrive
 *	  at the serial port.
 *
 * Parameters:   
 *    refNum     IN   library reference number (see SysLoadLibrary)
 *	  minBytes   IN   minimum # of bytes that must be in receive queue
 *						  before wakeup proc will be called.
 *               
 * Called by:
 *    Applications that need faster access to received data.
 *    Most notably, the TCP/IP media layers like SLIP and PPP.
 *
 * Returns: 
 *    error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *	  PPP and SLIP interfaces of NetLib
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerPrimeWakeupHandler (Word refNum, Word minBytes)
{
  SerGlobalsPtr	gP;
  
  // Get our globals ptr
  gP = SysLibTblEntry (refNum)->globalsP;

  // If not open return err
  if (!gP)
	{
	  ErrNonFatalDisplay ("ser lib not open");
	  return serErrNotOpen;
	}
	  
  // Set info
  gP->sigRecvUsedBytes = minBytes;
  
  // no err
  return 0;
}


/***********************************************************************
 *
 * Function:     SerControl
 *
 * Description:  
 *
 * Parameters:   
 *	refNum     IN		library reference number (see SysLoadLibrary)
 *  op         IN		control operation to perform (see SerCtlEnum)
 *  valueP     IN/OUT	ptr to value for operation
 *  valueLenP  IN/OUT	ptr to size of value
 *               
 * Returns:      
 *	error code, 0 if no error
 *
 * Called By:
 *	  Applications
 *	  IR stack
 *
 * History:
 *	  1-Mar-1999  RM	  Created
 *
 ***********************************************************************/
Err 
SerControl (Word refNum, Word op, VoidPtr valueP, WordPtr valueLenP)
{
  Err			err;
  SerGlobalsPtr	gP;
  

  // Get our globals ptr
  gP = PrvGetGlobals (refNum);

  
  // -------------------------------------------------------------
  // Make sure serial lib has been opened for functions which require that
  // -------------------------------------------------------------
  if ( !gP &&
	   op != serCtlMaxBaud && 
	   op != serCtlHandshakeThreshold && 
	   op != serCtlIrScanningOn && 
	   op != serCtlIrScanningOff)
	{
	  ErrNonFatalDisplayIf(true, "serial lib not open");
	  err = serErrNotOpen;
	  goto Exit;
	}


	  
  // -------------------------------------------------------------
  // Process it now
  // -------------------------------------------------------------
  switch( op )
	{
	case serCtlMaxBaud:
	  if (!valueP || !valueLenP  || *valueLenP != sizeof(DWord))
		err = serErrBadParam;
	  else
		{
		  *(DWordPtr)valueP = serMaxBaud;
		  err = 0;
		}
	  break;
	
	case serCtlHandshakeThreshold:
	  if (!valueP || !valueLenP  || *valueLenP != sizeof(DWord))
		err = serErrBadParam;
	  else
		{
		  *(DWordPtr)valueP = serHandshakeThreshold;
		  err = 0;
		}
	  break;
	
	// Pass the rest to the hardware layer to handle	
	default:
	  err = SerHwControl (gP, op, valueP, valueLenP);
	  break;
	}
  
Exit:
  //ErrNonFatalDisplayIf (err, "err");
  return( err );
}


