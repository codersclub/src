/***************************************************************
 *
 *  Project:
 *	  Handspring Serial Module Diagnostic Application
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  SerialDiag.c
 * 
 *  Description:
 *	  This is the main source file for the Serial Module Diagnostic Application.
 *
 *
 * History:
 *	  15-Nov-1999  VMK  Created 
 ****************************************************************/

#include <PalmOS.h>
#include <CoreCompatibility.h>
#include <SerialMgrOld.h>

#include "SerialDiag.h"
#include "AppStdio.h"


// Include Card equates that contains the API for the module's CardSetup app
#include "HsSerModulePublic.h"



/***********************************************************************
 *
 *	Private Equates
 *
 ***********************************************************************/


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
// Public

// Private
#define	prvMaxCmdLen		1024
static Char     PrvCmdBuf[prvMaxCmdLen];



/***************************************************************
 *	Function:	  MainFrmInit
 *
 *	Summary:	  This routine initializes the "Main View" of our app
 *
 *	Parameters:
 *	  frmP		IN	  form pointer
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  MainFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created
 *
 ****************************************************************/
static void
MainFrmInit (FormPtr frmP)
{
}





/***************************************************************
 *	Function:	  MainFrmDoCommand
 *
 *	Summary:	  Execute a menu command for our main form 
 *
 *	Parameters:
 *	  command	  IN	menu command to execute
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  MainFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static          Boolean
MainFrmDoCommand (Word command)
{
  Boolean         handled = true;


  switch (command)
	{

	  // ...........................................................
	  // Misc Menu
	  // ...........................................................
	case resMenuItemAbout:
	  FrmAlert (resAlertIDAbout);
	  break;

	case resMenuItemPerfMonGet:
	  AppExecCommand ("perf");
	  break;

	case resMenuItemPerfMonOn:
	  AppExecCommand ("perf on");
	  break;

	case resMenuItemPerfMonOff:
	  AppExecCommand ("perf off");
	  break;

	case resMenuItemPerfMonReset:
	  AppExecCommand ("perf reset");
	  break;

	case resMenuItemHelp:
	  AppExecCommand ("help");
	  break;

	default:
	  // allow edit events to be handled by frmhandleevent
	  handled = false;
	  break;

	}

  return handled;
}



/***************************************************************
 *	Function:	  MainFrmEventHandler
 *
 *	Summary:	  Event handler for our main form. 
 *
 *	Parameters:
 *	  eventP	  IN	pointer to event to handle
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  FrmDispatchEvent() when event is for our main form. 
 *	  FrmDispatchEvent() is called by our AppEventLoop() 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static          Boolean
MainFrmEventHandler (EventPtr eventP)
{
  FormPtr         formP;
  Boolean         handled = false;

  // See if StdIO can handle it
  if (StdHandleEvent (eventP))
	return true;


  switch (eventP->eType)
	{


	// -------------------------------------------------------
	// Init the form
	// -------------------------------------------------------
	case frmOpenEvent:
	  formP = FrmGetActiveForm ();
	  MainFrmInit (formP);
	  FrmDrawForm (formP);
	  handled = 1;

	  // Print welcome message
	  printf ("Welcome to SerialDiag!");
	  printf ("\nEnter 'help' for a list of commands\n");


	  // Install our commands
	  AppCmdsInstall();

	  break;

	// -------------------------------------------------------
	// Menu commands
	// -------------------------------------------------------
	case menuEvent:
	  handled = MainFrmDoCommand (eventP->data.menu.itemID);
	  break;


	// -------------------------------------------------------
	// See if any serial data is available, and if so, print it
	// -------------------------------------------------------
	case nilEvent:

	  handled = true;
	  break;

	// -------------------------------------------------------
	// Close our form
	// -------------------------------------------------------
	case frmCloseEvent:
	  break;

	default:
	  break;
	}
  return handled;
}



/***********************************************************************
 *
 *	Function:	PrvPrintErrorStr
 *
 *  Summary: 	Prints out result code error stringfrom a test
 *
 *	Parameters:
 *	  cmdStr	  IN  pointer to command to add
 *	  cmdProcPtr  IN  pointer to procedure for command
 *
 *	Called By:
 *
 *  Returns:	0
 *
 ***********************************************************************/
void 
PrvPrintErrorStr (DWord err)
{
  if (err == appCmdResultQuiet) return;

  switch (err)
	{
	case 0:
	  break;

	case appCmdResultSyntaxErr:
	  printf ("Syntax error");
	  break;

	case appCmdResultInvalidHexStr:
	  printf ("Invalid Hex string");
	  break;


	// ===============================================================
	// PalmOS Error codes
	// ===============================================================
	case serErrTimeOut:
	  printf ("Serial timeout");
	  break;
	case serErrLineErr:
	  printf ("Serial line error");
	  break;
	case serErrAlreadyOpen:
	  printf ("Serial port already open");
	  break;
	case serErrBadPort:
	  printf ("Serial port bad");
	  break;
	  

	default:
	  printf ("Unknown");
	  break;
	}
}



/***********************************************************************
 *
 *	Function:	AppExecCommand
 *
 *  Summary: 	Adds a command to the master command table
 *				Each of the command modules makes calls to this routine
 *				to install it's commands into the table.
 *
 *	Parameters:
 *	  cmdStr	  IN  pointer to command to add
 *	  cmdProcPtr  IN  pointer to procedure for command
 *
 *	Called By:
 *
 *  Returns:	0
 *
 ***********************************************************************/
typedef struct
{
  CharPtr         nameP;		// command name
  CmdProcPtr      procP;		// procedure
}
CmdTableEntryType;
#define			kMaxCommands 	64	// Max # of commands
Word            NumCommands = 0;
CmdTableEntryType CmdTable[kMaxCommands];	// command table

void
AppAddCommand (CharPtr cmdStr, CmdProcPtr procP)
{
  if (NumCommands >= kMaxCommands - 1)
	{
	  ErrDisplay ("Too many commands");
	  return;
	}

  CmdTable[NumCommands].nameP = cmdStr;
  CmdTable[NumCommands++].procP = procP;
}



/***************************************************************
 *	Function:	  AppExecCommand
 *
 *	Summary:	  Separates a command line into argc, argv 
 *					components and then calls the appropriate routine.
 *
 *	Parameters:
 *	  cmdParamP	  IN  pointer to command line
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  StdIO module when user hits enter
 *	  OR, when we receive a command line from the serial port
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
void
AppExecCommand (CharPtr cmdParamP)
{
  #define		  maxArgc  10
  CharPtr         argv[maxArgc + 1];
  int             argc;
  Boolean         done = false;
  UInt            i;
  CharPtr         cmdBufP = 0;
  CharPtr         cmdP;

  // if null string, return
  if (!cmdParamP[0])
	return;


  // Make a copy of the command since we'll need to write
  // 0's between the words and it might be from read-only space
  cmdP = cmdBufP = MemPtrNew (StrLen (cmdParamP) + 1);
  if (!cmdP)
	{
	  printf ("\nOut of memory\n");
	  goto Exit;
	}
  MemMove (cmdP, cmdParamP, StrLen (cmdParamP) + 1);

  // Separate the cmd line into arguments
  argc = 0;
  argv[0] = 0;
  for (argc = 0; !done && argc <= maxArgc; argc++)
	{

	  // Skip leading spaces
	  while ((*cmdP == ' ' || *cmdP == '\t') && (*cmdP != 0))
		cmdP++;

	  // Break out on null
	  if (*cmdP == 0)
		break;

	  // Get pointer to command
	  argv[argc] = cmdP;
	  if (*cmdP == 0)
		break;

	  // Find the end of a quoted argument
	  if (*cmdP == '"')
		{
		  cmdP++;
		  argv[argc] = cmdP;
		  while (*cmdP)
			{
			  if (*cmdP == '"')
				{
				  *cmdP = 0;
				  break;
				}
			  if (*cmdP == 0)
				{
				  done = true;
				  break;
				}
			  cmdP++;
			}
		  cmdP++;
		}

	  // Find the end of an unquoted argument
	  else
		{
		  while (1)
			{
			  if (*cmdP == 0)
				{
				  done = true;
				  break;
				}
			  if ((*cmdP == ' ') || (*cmdP == '\t'))
				{
				  *cmdP = 0;
				  break;
				}
			  cmdP++;
			}
		  cmdP++;
		}
	}

  // Return if no arguments
  if (!argc)
	goto Exit;


  // --------------------------------------------------------------------
  // Call the appropriate routine
  // --------------------------------------------------------------------

  // Look for the help command
  if (!StrCaselessCompare (argv[0], "help") 
	  || !StrCaselessCompare (argv[0], "?"))
	{

	  // If asking about a particular command, get extended help (??)
	  if (argc > 1)
		{
		  argv[0] = argv[1];
		  argv[1] = "??";
		}

	  // Else, display 1 line help (?)
	  else
		{
		  CharPtr         helpP;
		  helpP = "?";
		  for (i = 0; i < NumCommands; i++)
			{
			  argv[0] = CmdTable[i].nameP;
			  argv[1] = helpP;
			  (CmdTable[i].procP) (2, argv);
			}
		  printf ("\n");
		  goto Exit;
		}
	}

  // Else, look for this command
  for (i = 0; i < NumCommands; i++)
	{
	  if (!StrCaselessCompare (argv[0], CmdTable[i].nameP))
		{
		  DWord	result;
		  result = (CmdTable[i].procP) (argc, argv);

		  // Print ack with error code and string
		  if (result != appCmdResultQuiet)
			{
			  printf ("%sACK %s %08lX ", appRespPrefix, argv[0], result);
			  PrvPrintErrorStr (result);
			  printf ("\n");
			}
		  goto Exit;
		}
	}

  // Not found
  printf ("%sACK %s %08lX Command not found\n", appRespPrefix, 
			argv[0], 0xFFFFFFFF);

Exit:
  if (cmdBufP)
	MemPtrFree (cmdBufP);

}



/***************************************************************
 *	Function:	  AppStart
 *
 *	Summary:	  Application initialization when being launched
 *		as a normal application (i.e. not to execute an action code).
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain when action code is for a normal launch. 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static          DWord
AppStart (void)
{
  // Init globals
  PrvCmdBuf[0] = 0;

  // Init our terminal functions for printing to the screen
  StdInit (resFormIDMain, resMainTextFldID, resMainScrollerID,
		   AppExecCommand);

  // Go to main form
  FrmGotoForm (resFormIDMain);
  return 0;
}


/***************************************************************
 *	Function:	  AppStop
 *
 *	Summary:	  Application cleanup. This routine cleans up
 *	  all initialization performed by AppStart(). 
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain, after EventLoop returns
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static void
AppStop (void)
{
  EventType       event;

  // Close our main form
  event.eType = frmCloseEvent;
  event.data.frmClose.formID = resFormIDMain;
  FrmDispatchEvent (&event);

  // Free the Stdio Support
  StdFree ();
}



/***************************************************************
 *	Function:	  AppEventLoop
 *
 *	Summary:	  This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 *	Parameters:
 *	  eventP	IN	  pointer to event
 *
 *	Returns:
 *	  true if event was handled. 
 *	
 *	Called By: 
 *	  AppEventLoop. 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static          Boolean
AppHandleEvent (EventPtr eventP)
{
  Word            formID;
  FormPtr         frmP;

  if (eventP->eType == frmLoadEvent)
	{

	  // Load the form resource.
	  formID = eventP->data.frmLoad.formID;
	  frmP = FrmInitForm (formID);
	  FrmSetActiveForm (frmP);

	  // Set the event handler for the form.  The handler of the currently
	  // active form is called by FrmHandleEvent each time is receives an
	  // event.
	  switch (formID)
		{
		case resFormIDMain:
		  FrmSetEventHandler (frmP, MainFrmEventHandler);
		  break;

		}
	  return (true);
	}
  return (false);
}



/***************************************************************
 *	Function:	  AppEventLoop
 *
 *	Summary:	  Main event loop for the application
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain after initializing. 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created 
 *
 ****************************************************************/
static void
AppEventLoop (void)
{
  short           err;
  EventType       event;

  do
	{
	  EvtGetEvent (&event, sysTicksPerSecond >> 4);

	  if (!SysHandleEvent (&event))

		if (!MenuHandleEvent (0, &event, &err))

		  if (!AppHandleEvent (&event))

			FrmDispatchEvent (&event);


	}
  while (event.eType != appStopEvent);
}




/***************************************************************
 *	Function:	  PilotMain
 *
 *	Summary:	  Entry point
 *
 *	Parameters:
 *	  cmd		  IN	Action code for the app. This is one of the
 *						  action codes sysAppLaunchCmdXXX defined in
 *						  <SystemMgr.h>
 *	  cmdPBP	  IN	Parameter block pointer for action code. 
 *	  launchFlags IN	Launch flags, one or more of 
 *						  sysAppLaunchFlagXXX defined in <SystemMgr.h>
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PalmOS when launching the app or asking it to execute an
 *		action code like find or goto. 
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  15-Nov-1999  VMK  Created
 *
 ****************************************************************/
DWord
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  DWord           err;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{
	  err = AppStart ();		// Application start code
	  if (err)
		return err;

	  AppEventLoop ();			// Event loop

	  AppStop ();				// Application stop code
	}

  return 0;
}




