//**************************************************************
//
//  Project:
//	  Handspring Serial Module Diagnostic Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  SerialDiag.h
// 
//  Description:
//	  Equates for the application. 
//
// History:
//	  15-Nov-1999  VMK  Created 
//***************************************************************/


// Include resource equates
#include "SerialDiagRsc.h"

// =======================================================
// Equates
// =======================================================

// Our Creator and prefs version
#define appCreator					'SmDg'
#define	appVersion					1


// Shared result codes from various tests
#define	appCmdResultQuiet			0x80000000	// Don't print
#define	appCmdResultSyntaxErr		0x80000001
#define	appCmdResultInvalidHexStr	0x80000002

// This string precedes any acknowledgement we print out
#define	appRespPrefix				"*"

// =======================================================
// Types
// =======================================================
typedef 	DWord (*CmdProcPtr) (int argc, char* argv[]);


// =======================================================
// Globals
// =======================================================


// =======================================================
// Prototypes
// =======================================================
void  AppAddCommand (CharPtr cmdStr, CmdProcPtr procP);
void  AppExecCommand (CharPtr cmdParamP);
void  AppCmdsInstall (void);
