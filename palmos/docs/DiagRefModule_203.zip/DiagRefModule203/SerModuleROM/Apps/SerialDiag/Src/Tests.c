/***************************************************************
 *
 *  Project:
 *	  Handspring Serial Module Diagnostic Application
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  Tests.c
 * 
 *  Description:
 *	  This file has the various tests that we implement. They
 *	are all structured as stdio commands. 
 *
 * History:
 *	  15-Nov-1999  VMK  Created by Vitaly Kruglikov
 ****************************************************************/

#include <PalmOS.h>
#include <CoreCompatibility.h>
#include <SerialMgrOld.h>
#include <ExgMgr.h>
#include <SysEvtMgr.h>


// Handspring Extensions
#include <HsExt.h>

#include "SerialDiag.h"
#include "AppStdio.h"


// Include Card equates that contains the name of the serial library
// on the removable card
#include "HsSerModulePublic.h"








/***************************************************************
 *	Function:	  PrvHToI
 *
 *	Summary:	  Convert a hexadecimal string to integer
 *
 *	Parameters:
 *	  strP		IN	  string to convert
 *	  *errP		OUT	  error code, if any
 *
 *	Returns
 *	  value
 *
 *	Notes:
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvHToI (Char*	strP, DWord* errP)
{
  DWord	  result = 0;
  Char	  c;
  DWord	  err = 0;
  Byte	  nibble;
  Int	  totalChars = 0;


  while (*strP)
	{
	  if (totalChars >= 8)
		{
		  err = appCmdResultInvalidHexStr;
		  goto Exit;
		}


	  // ----------------------------------------------------------
	  // First char of hex pair
	  // ----------------------------------------------------------
	  c = *strP++;
	  totalChars++;

	  if (c >= 'a' && c <= 'f') 
		nibble = c - 'a' + 10;
	  else if (c >= 'A' && c <= 'F')
		nibble = c - 'A' + 10;
	  else if (c >= '0' && c <= '9')
		nibble = c - '0';
	  else
		{
		  err = appCmdResultInvalidHexStr;
		  goto Exit;
		}
	  result = (result << 4) + nibble;
	}

Exit:
  *errP = err;
  return result;
}


/***************************************************************
 *	Function:	  SB
 *
 *	Summary:	  Set 1 or more Bytes
 *
 *	Syntax:
 *	  SB <address> <byte> [<byte>...]
 *	  
 *		where <byte> is 1-2 hexadecimal characters
 *		<address> is hexadecimal as well
 *
 *	Prints:
 *	  nothing
 *	
 *	Notes:
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvSb (int argc, CharPtr argv[])
{
  DWord           err = 0;
  BytePtr		  addrP;
  int			  i;

  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;

  // Get the address
  if (argc < 3) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}
  addrP = (BytePtr)PrvHToI (argv[1], &err);
  if (err) goto Exit;

  // Set each byte
  for (i=2; i<argc; i++)
	{
	  DWord	  data;
	  data = PrvHToI (argv[i], &err);
	  if (data > 0xFF) 
		err = appCmdResultInvalidHexStr;
	  if (err) goto Exit;

	  *addrP++ = (Byte)data;
	}
	  


Exit:
  return err;

ShortHelp:
  printf ("%s\t\t\t# Set Bytes\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nSet 1 or more bytes of memory");
  printf ("\nSyntax: %s <address> <byte> [<byte>...]", argv[0]);
  printf ("\n           # <address> and <byte> are hexadecimal");
  printf ("\n");
  return appCmdResultQuiet;
}


/***************************************************************
 *	Function:	  SW
 *
 *	Summary:	  Set 1 or more Words
 *
 *	Syntax:
 *	  SW <address> <word> [<word>...]
 *	  
 *		where <word> is 1-4 hexadecimal characters
 *		<address> is hexadecimal as well
 *
 *	Prints:
 *	  nothing
 *	
 *	Notes:
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvSw (int argc, CharPtr argv[])
{
  DWord           err = 0;
  WordPtr		  addrP;
  int			  i;

  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;

  // Get the address
  if (argc < 3) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}
  addrP = (WordPtr)PrvHToI (argv[1], &err);
  if (err) goto Exit;

  // Set each word
  for (i=2; i<argc; i++)
	{
	  DWord	  data;
	  data = PrvHToI (argv[i], &err);
	  if (data > 0xFFFF) 
		err = appCmdResultInvalidHexStr;
	  if (err) goto Exit;

	  *addrP++ = (Word)data;
	}
	  


Exit:
  return err;

ShortHelp:
  printf ("%s\t\t\t# Set Words\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nSet 1 or more 16-bit words of memory");
  printf ("\nSyntax: %s <address> <word> [<word>...]", argv[0]);
  printf ("\n           # <address> and <word> are hexadecimal");
  printf ("\n");
  return appCmdResultQuiet;
}


/***************************************************************
 *	Function:	  SL
 *
 *	Summary:	  Set 1 or more DWords
 *
 *	Syntax:
 *	  SL <address> <long> [<long>...]
 *	  
 *		where <long> is 1-8 hexadecimal characters
 *		<address> is hexadecimal as well
 *
 *	Prints:
 *	  nothing
 *	
 *	Notes:
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvSl (int argc, CharPtr argv[])
{
  DWord           err = 0;
  DWordPtr		  addrP;
  int			  i;

  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;

  // Get the address
  if (argc < 3) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}
  addrP = (DWordPtr)PrvHToI (argv[1], &err);
  if (err) goto Exit;

  // Set each DWord
  for (i=2; i<argc; i++)
	{
	  DWord	  data;
	  data = PrvHToI (argv[i], &err);
	  if (err) goto Exit;

	  *addrP++ = data;
	}
	 

Exit:
  return err;

ShortHelp:
  printf ("%s\t\t\t# Set Longs\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nSet 1 or more 32-bit longs of memory");
  printf ("\nSyntax: %s <address> <long> [<long>...]", argv[0]);
  printf ("\n           # <address> and <long> are hexadecimal");
  printf ("\n");
  return appCmdResultQuiet;
}


/***************************************************************
 *	Function:	  DM
 *
 *	Summary:	  Display 1 or more Bytes
 *
 *	Syntax:
 *	  DM <address> <count>
 *	  
 *		where <count>  and <address> are hexadecimal  
 *
 *	Prints:
 *	  nothing
 *	
 *	Notes:
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvDm (int argc, CharPtr argv[])
{
  DWord           err = 0;
  BytePtr		  addrP;
  DWord			  count;

  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;


  // Get the address
  if (argc != 3) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}
  addrP = (BytePtr)PrvHToI (argv[1], &err);
  if (err) goto Exit;

  // Get the count
  count = PrvHToI (argv[2], &err);
  if (err) goto Exit;


  // Display each byte
  while (count--)
	{
	  char	str[16];
	  Byte	data;
	  data = *addrP++;

	  StrIToH (str, data);
	  StdPutS (str+6);	
	}
  printf ("\n");


Exit:
  return err;

ShortHelp:
  printf ("%s\t\t\t# Display Memory\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nDisplay 1 or more bytes of memory");
  printf ("\nSyntax: %s <address> <count> ", argv[0]);
  printf ("\n           # <address> and <count> are hexadecimal");
  printf ("\n");
  return appCmdResultQuiet;
}



/***************************************************************
 *	Function:	  CardReset
 *
 *	Summary:	  Turn card reset signal on/off
 *
 *	Syntax:
 *	  CardReset on | off	# 
 *
 *	Prints:
 *	  <nothing>
 *	
 *	Notes:
 *	
 *	History:
 *	  2-Aug-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
static          DWord
PrvCardReset (int argc, CharPtr argv[])
{
  DWord           err = 0;
  Byte			  value;


  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;


  // Check for syntax errors
  if (argc != 2) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}

  // See whether to turn on or off
  if (!StrCaselessCompare (argv[1], "on"))
	{
	  value = true;
	  HsCardAttrSet (1, hsCardAttrReset, &value);
	}
  else if (!StrCaselessCompare (argv[1], "off"))
	{
	  value = false;
	  HsCardAttrSet (1, hsCardAttrReset, &value);
	}
  else
	err = appCmdResultSyntaxErr;


Exit:
  return err;

ShortHelp:
  printf ("%s\t# Card Reset on/off\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nTurn Card Reset on/off");
  printf ("\nSyntax: %s on | off  ", argv[0]);
  printf ("\n");
  return appCmdResultQuiet;
}


/***************************************************************
 *	Function:	  PrvProcessCommand
 *
 *	Summary:	  Sends an action code to the Serial Module's
 *	  CardSetup application
 *
 *	Parameters:
 *	  reqID	  IN	request id (HsSerModReqEnum)
 *	  pbP	  IN	ptr to parameter block of the request
 *	  pbSize  IN	size of the parameter block
 *
 *	Returns:
 *	  zero on success
 *	
 *	Called By: 
 *	  PrvPerf 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static DWord
PrvProcessCommand (Word reqID, VoidPtr pbP, UInt32 pbSize)
{
  DWord		err = 0;
  HsSerModReqType req;
  DmSearchStateType	searchState;
  LocalID		  dbID = 0;
  UInt16		  cardNo = 0;
  DWord			  result = 0;

  MemSet (&req, sizeof (req), 0);
  req.cardNo = 1;	// HACK: assume module is on card #1
  req.signature = hsSerModReqSignature;
  req.reqSize = sizeof (req);
  req.reqID = reqID;
  req.pbP = pbP;
  req.pbSize = pbSize;

  // Find the CardSetup database
  err = DmGetNextDatabaseByTypeCreator (true /*newSearch*/, &searchState,
			 							hsFileTCardSetup, hsFileCCardSetup,
										false /*onlyLatestVersion*/, 
			 							&cardNo, &dbID);

  if (err)
	goto Exit;

  err = SysAppLaunch (cardNo, dbID, 0, hsSerModCmdProcessRequest,
					  (Ptr)&req, &result);

  if (!err)
	err = result;
  if (!err && !req.handled)
	err = sysErrParamErr;
  if (!err)
	err = req.err;

Exit:
  return (err);
}


/***************************************************************
 *	Function:	  PrvSetPerfMonEnabled
 *
 *	Summary:	  Sends an action code to the Serial Module's
 *	  CardSetup application to turn performance monitoring on/off. 
 *
 *	Parameters:
 *	  on	  IN	non-zero to turn on; zero to turn off
 *
 *	Returns:
 *	  zero on success
 *	
 *	Called By: 
 *	  PrvPerf 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static DWord
PrvSetPerfMonEnabled (Byte on)
{
  DWord					err = 0;
  HsSerModAttrSetType	cmd;


  cmd.attrID = hsSerModAttrPerfMonEnabled;
  cmd.argP = &on;
  cmd.argSize = sizeof (on);

  err = PrvProcessCommand (hsSerModReqAttrSet, &cmd, sizeof(cmd));


  return (err);
}



/***************************************************************
 *	Function:	  PrvGetPerfMonEnabled
 *
 *	Summary:	  Sends an action code to the Serial Module's
 *	  CardSetup application to get performance monitoring status. 
 *
 *	Parameters:
 *	  onP	  OUT	non-zero if on; zero if off
 *
 *	Returns:
 *	  zero on success
 *	
 *	Called By: 
 *	  PrvPerf 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static DWord
PrvGetPerfMonEnabled (Byte* onP)
{
  DWord					err = 0;
  HsSerModAttrGetType	cmd;


  cmd.attrID = hsSerModAttrPerfMonEnabled;
  cmd.argP = onP;
  cmd.argSize = sizeof (*onP);

  err = PrvProcessCommand (hsSerModReqAttrGet, &cmd, sizeof(cmd));


  return (err);
}


/***************************************************************
 *	Function:	  PrvResetPerfData
 *
 *	Summary:	  Sends an action code to the Serial Module's
 *	  CardSetup application to reset performance monitoring data. 
 *
 *	Parameters:
 *	  none
 *
 *	Returns:
 *	  zero on success
 *	
 *	Called By: 
 *	  PrvPerf 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static DWord
PrvResetPerfData (void)
{
  DWord					err = 0;
  HsSerModAttrSetType	cmd;


  cmd.attrID = hsSerModAttrPerfData;
  cmd.argP = NULL;
  cmd.argSize = 0;

  err = PrvProcessCommand (hsSerModReqAttrSet, &cmd, sizeof(cmd));


  return (err);
}




/***************************************************************
 *	Function:	  PrvGetPerfData
 *
 *	Summary:	  Sends an action code to the Serial Module's
 *	  CardSetup application to get performance monitoring data. 
 *
 *	Parameters:
 *	  perfP	  OUT	performance monitoring data
 *
 *	Returns:
 *	  zero on success
 *	
 *	Called By: 
 *	  PrvPerf 
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static DWord
PrvGetPerfData (HsSerModPerfType* perfP)
{
  DWord					err = 0;
  HsSerModAttrGetType	cmd;


  cmd.attrID = hsSerModAttrPerfData;
  cmd.argP = perfP;
  cmd.argSize = sizeof (*perfP);

  err = PrvProcessCommand (hsSerModReqAttrGet, &cmd, sizeof(cmd));


  return (err);
}


/***************************************************************
 *	Function:	  PrvPerf
 *
 *	Summary:	  Turn performance monitoring on/off. 
 *
 *	Syntax:
 *	  Perf
 *	  Perf on | off	 
 *
 *	Prints:
 *	  PerfMon Status
 *	
 *	Notes:
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created
 *
 ****************************************************************/
static          DWord
PrvPerf (int argc, CharPtr argv[])
{
  DWord           err = 0;
  Boolean		  on = false;
  Boolean		  reset = false;


  // Check for help
  if (argc > 1 && !StrCompare (argv[1], "?"))
	goto ShortHelp;
  if (argc > 1 && !StrCompare (argv[1], "??"))
	goto FullHelp;


  // Check for syntax errors
  if (argc == 1)
	goto PrintStatus;

  if (argc != 2) 
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}

  // See whether to turn on or off
  if (!StrCaselessCompare (argv[1], "on"))
	{
	  on = true;
	}
  else if (!StrCaselessCompare (argv[1], "off"))
	{
	  on = false;
	}
  else if (!StrCaselessCompare (argv[1], "reset"))
	{
	  reset = true;
	}
  else
	{
	  err = appCmdResultSyntaxErr;
	  goto Exit;
	}

  if (reset)
	{
	  err = PrvResetPerfData ();
	  if (err)
		goto Exit;
	}
  else
	{
	  // Set the status
	  err = PrvSetPerfMonEnabled (on);
	  if (err)
		goto Exit;
	  printf ("Settings will take effect when serial lib is re-opened\n");
	}

PrintStatus:
  err = PrvGetPerfMonEnabled (&on);
  if (err)
	goto Exit;
  printf ("\nSerial Module Performance Monitoring is: %s.\n", on ? "ON" : "OFF");
  if (on && argc == 1)
	{
	  HsSerModPerfType	perf;
	  err = PrvGetPerfData (&perf);
	  if (err)
		goto Exit;

	  printf ("\nserSendCalls = %ld", perf.serSendCalls);
	  printf ("\nsendReqTotal = %ld", perf.sendReqTotal);
	  printf ("\nsendQTotal = %ld", perf.sendQTotal);
	  printf ("\nsendTicks = %ld", perf.sendTicks);
	  printf ("\nmaxSendTicks = %ld", perf.maxSendTicks);
	  printf ("\nmaxSendTicksReq = %ld", perf.maxSendTicksReq);
	  printf ("\nmaxSendReq = %ld", perf.maxSendReq);
	  printf ("\nsendErrors = %ld", perf.sendErrors);
	  printf ("\nsendTimeouts = %ld", perf.sendTimeouts);
	  printf ("\nsendTotal = %ld", perf.sendTotal);

	  printf ("\n");
	  printf ("\nserReceiveCalls = %ld", perf.serReceiveCalls);
	  printf ("\nrecvReqTotal = %ld", perf.recvReqTotal);
	  printf ("\nrecvDQTotal = %ld", perf.recvDQTotal);
	  printf ("\nrecvTicks = %ld", perf.recvTicks);
	  printf ("\nmaxRecvTicks = %ld", perf.maxRecvTicks);
	  printf ("\nmaxRecvReq = %ld", perf.maxRecvReq);
	  printf ("\nrecvErrors = %ld", perf.recvErrors);
	  printf ("\nrecvTimeouts = %ld", perf.recvTimeouts);
	  printf ("\nrecvTotal = %ld", perf.recvTotal);
	  printf ("\nlineErrors = %ld", perf.lineErrors);
	  printf ("\nhwOverrunErrors = %ld", perf.hwOverrunErrors);
	  printf ("\nmaxSendBurst = %d", (int)perf.maxSendBurst);
	  printf ("\nmaxRecvBurst = %d", (int)perf.maxRecvBurst);

	  printf ("\n");
	  printf ("\ntotalISRCalls = %ld", perf.totalISRCalls);
	  printf ("\nlineErrISRTriggers = %ld", perf.lineErrISRTriggers);
	  printf ("\nsendISRTriggers = %ld", perf.sendISRTriggers);
	  printf ("\nrecvISRTriggers = %ld", perf.recvISRTriggers);
	  printf ("\nmsrISRTriggers = %ld", perf.msrISRTriggers);
	  printf ("\nrtsISRTriggers = %ld", perf.rtsISRTriggers);
	  printf ("\nxoffISRTriggers = %ld", perf.xoffISRTriggers);
	  printf ("\notherISRTriggers = %ld", perf.otherISRTriggers);

	  printf ("\n");

	}

Exit:
  return err;

ShortHelp:
  printf ("%s\t\t\t# Performance Monitoring on/off\n", argv[0]);
  return appCmdResultQuiet;

FullHelp:
  printf ("\nTurn Performance Monitoring on/off");
  printf ("\nSyntax: %s on | off | reset ", argv[0]);
  printf ("\n");
  return appCmdResultQuiet;
}



/***************************************************************
 *	Function:	  AppCmdsInstall
 *
 *	Summary:	  Install all our commands
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  MainFrmEventHandler() during frmOpen Event
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  6-May-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
void
AppCmdsInstall (void)
{
  AppAddCommand ("Perf", PrvPerf);
  AppAddCommand ("SB", PrvSb);
  AppAddCommand ("SW", PrvSw);
  AppAddCommand ("SL", PrvSl);
  AppAddCommand ("DM", PrvDm);
  AppAddCommand ("CardReset", PrvCardReset);
}