//**************************************************************
//
//  Project:
//	  Handspring Serial Module Diagnostic Application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  SerialDiagRsc.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
//
// History:
//	  15-Nov-1999  VMK  Created
//***************************************************************/


// Main Form
#define resFormIDMain				1000
#define	resMainTextFldID			1002
#define	resMainScrollerID			1003
									

// Main Form menu
#define resMenuIDMain				1000
#define resMenuItemPerfMonGet		1002
#define resMenuItemPerfMonOn		1003
#define resMenuItemPerfMonOff		1004
#define resMenuItemPerfMonReset		1005
#define resMenuItemHelp				1006
#define resMenuItemAbout			1007

// About Alert
#define resAlertIDAbout				1000
									

