/***************************************************************
 *
 *  Project:
 *	  Handspring Sample Serial Comm Module Card Setup application
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName: 
 *	  CardSetup.c
 * 
 *  Description:
 *	  This is the main source file for the Card Setup application.
 *	This differs from a normal PalmOS application in a couple respects:
 *
 *	  1.) It ONLY gets launched with one of 2 possible launch commands:
 *		  hsSysAppLaunchCmdInstall or hsSysAppLaunchCmdRemove
 *		  (defined in HsExt.h)
 *	  2.) It does not appear in the launcher (because it does not have
 *			a database type of 'appl').
 *	  3.) It should NEVER use global variables because it never
 *		  gets called with the sysAppLaunchFlagNewGlobals bit set
 *		  in the launchFlags.
 *	  4.) It can NOT display any UI calls or use EvtGetEvent(), 
 *		  SysHandleEvent(), etc. during processing. 
 *
 * ToDo:
 *
 * History:
 *	  21-Sep-1999  VMK	Created by Vitaly Kruglikov (based on Ron Marianetti's
 *						 Sample Card Setup app)
 *
 ****************************************************************/

#include <PalmOS.h>
#include <CoreCompatibility.h>
#include <SerialMgrOld.h>
#include <NetMgr.h>	// for NetLibFinishCloseWait

// Include Handspring Equates
#include <HsExt.h>
#include <CallbackFix.h>


// Include card specific equates
#include "HsDevRefCard.h"

//
// ***WARNING*** Non-portable definitions may be used only on versions of the
//  platform where they are known to work; it should be assumed that these
//  definitions will be incompatible with any other versions of the platform.
//
//#define NON_PORTABLE	// enable inclusion Hardware.h
//  #include <Hardware.h>		// for HwrDockStatus (under Incs/Hardware)

// Include this definition directly because it is no longer part of the PalmOS SDK
DWord	HwrDockStatus (void)
						SYS_TRAP(sysTrapHwrDockStatus);
// Enum returned by hwrDockStatus() call
typedef enum {
		hwrDockStatusNotDocked = 0,
		hwrDockStatusInModem,
		hwrDockStatusInCharger,
		hwrDockStatusUnknown = 0xFF
		} HwrDockStatusEnum;


// Definition used in patching of SysLibFind
typedef Err PrvSysLibFindFuncType (CharPtr nameP, UIntPtr refNumP);

// Definition used in patching of EvtGetEvent()
typedef void EvtGetEventFuncType (const EventPtr event, Int32 timeout);

static Err
PrvLibUninstall (HsDrcGlobalsType* gP, Boolean* needResetP);


/***************************************************************
 *	Function:	  AppPilotMainHook
 *
 *	Summary:	  PilotMain hook function to implement Try/Catch
 *					block execution from internal RAM.
 *
 *				  This technique provides protection against the 
 *				  soft reset from opened library in AN-02. This 
 *				  one implementation for protecting applications
 *				  that runs from Module memory.
 *
 *				  For more information about handling Springboard 
 *				  module removal, see Handspring's application
 *				  note #2, "Springboard(TM) Soft Reset Protection"
 *
 *	Parameters:
 *	  ProcP		  IN	Pointer to callback function for the "main" 
 *						  app's PilotMain.
 *	  CleanUpParma IN	Parameter block pointer for clean up info .
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  "Main" application such as HandTerm.
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  07-July-2000  FV	Created
 *
 ****************************************************************/
DWord  
AppPilotMainHook ( AppPilotMainCallBackFuncType * procP, void * CleanUpParamP)
{
  Err	  err = 0;
  HsDrcGlobalsType*	  gP = 0;

  HsCardErrTry
  {
	// Protect with Try block so that the bus error fault would be caught
	// in the below Catch block

    // Call back application's PilotMain body
	procP();
  }

  HsCardErrCatch 
  {
	// Recover or clean up after a failure in above Try block
	// The code in this block does NOT execute if the above
	// Try block completes without a card removal

	//DbgBreak();
    gP = (HsDrcGlobalsType*)  CleanUpParamP;

	// Close open libraries
	// Check if the serial library has been un-installed or closed.  
	if (gP && gP->serLibRefNum)							  // not un-installed
	  if ((SysLibTblEntry (gP->serLibRefNum))->globalsP)  // not closed
		err = SerClose (gP->serLibRefNum);

  }
  HsCardErrEnd

  return err;
}





/***************************************************************
 *	Function:	  PrvPowerHandler
 *
 *	Summary:	  Stub of a power handler that gets called
 *	  when the device goes to sleep or wakes. 
 *
 *    We don't really need a separate power handler
 *    with this card because we install a library  and all libraries
 *    get their SysLibSleep() and SysLibWake() entry points called
 *    when the system goes to sleep or wakes.
 *
 *	  But, we install one anyways to show how it's done
 *
 *	  IMPORTANT: Power handlers may be called at interrupt time
 *	  so must observe all the restrictions on interrupt routines
 *	  (i.e. can't allocate or move memory, allocate system
 *	   resources like tasks or semaphores, etc.)
 *
 *	  Also, a power handler may be called after batteries are
 *	  removed and will be running off the backup capacitor so
 *	  must execute VERY quickly!
 *	  
 *	Parameters:
 *	  cardParam		IN	  what's stored in hsCardAttrCardParam
 *	  sleep			IN	  true if going to sleep, false if waking
 *	  emergency		IN	  called if going to sleep due to low
 *							batteries
 *
 *	Returns:
 *	  0 if no error 
 *	
 *	Called By: 
 *	  The system when going to sleep or coming out of sleep mode. 
 *	
 *	History:
 *	  4-Mar-1999  RM  Created  
 *
 ****************************************************************/
static void	 
PrvPowerHandler (DWord cardParam, Boolean sleep, Boolean emergency)
{
  HsDrcGlobalsType*	  gP = (HsDrcGlobalsType*)cardParam;

  gP = gP;	  // make compiler happy
}


 
/***************************************************************
 *	Function:	  PrvEventHandler
 *
 *	Summary:	  Stub of a card event handler that gets called
 *	  from within the main event loop of the current application
 *	  soon after the card's interrupt handler enqueues a
 *	  card event using HsCardPostEvent()
 *
 *	Parameters:
 *	  cardParam		IN	  what's stored in hsCardAttrCardParam
 *	  evtNum		IN	  Event number passed to HsCardPostEvent()
 *						   can be any value between 0 and
 *						   hsMaxCardEvent. 
 *	  evtParam		IN	  16 bit event parameter passed to
 *						   HsCardPostEvent()
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  Main event loop of the current application  as a result
 *	  of an interrupt routine enqueing a card event using
 *	  HsCardPostEvent()
 *	
 *	History:
 *	  4-Mar-1999  RM  Created  
 *
 ****************************************************************/
static Boolean
PrvEventHandler (DWord cardParam, Word evtNum, Word evtParam)
{
//  HsDrcGlobalsType*	  gP = (HsDrcGlobalsType*)cardParam;
  DmOpenRef			DBref;



	// For simplicity, just play a beep. A real event handler can
	//  put up can put up an alert, etc.
	SndPlaySystemSound (sndInfo);

	// Must open temporary resource database to do UI
	// Make sure creator and type match app's 
	DBref = DmOpenDatabaseByTypeCreator ('HsSU', 'HsCd', dmModeReadOnly);
	
	FrmAlert (1000 /*Interrupt*/ );
	FrmAlert (1001 /*CAEH*/ );

	// Close temp database
	DmCloseDatabase (DBref);

	return true;

}



static Boolean
PrvAppEventHandler (DWord cardParam, Word evtNum, Word evtParam)
{
//  HsDrcGlobalsType*	  gP = (HsDrcGlobalsType*)cardParam;
  DmOpenRef			DBref;


  	// For simplicity, just play a beep. A real event handler can
	//  put up can put up an alert, etc.
	SndPlaySystemSound (sndInfo);

	// Must open temporary resource database to do UI
	// Make sure creator and type match app's 
	DBref = DmOpenDatabaseByTypeCreator ('HsSU', 'HsCd', dmModeReadOnly);
	
	FrmAlert (1000 /*Interrupt*/ );
	FrmAlert (1001 /*CAEH*/ );

	// Close temp database
	DmCloseDatabase (DBref);

	return true;

}


/***********************************************************************
 *
 * Function:     PrvSysHandleEvent
 *
 * Summary:		 Used to detect if the module has been removed
 *				 while the application is running.  This lets the app
 *				 close the library and clean up.
 *
 *				 For more information about handling Springboard 
 *				 module removal, see Handspring's application
 *				 note #2, "Springboard(TM) Soft Reset Protection"
 *
 * Parameters:   eventP - the event that was received and sent to
 *					SysHandleEvent
 *
 * Returns:     Boolean, true if SysHandleEvent handled the event.
 *
 * History:
 *	07-July-2000  FV  Created
 *
 *
 ***********************************************************************/
static Boolean PrvSysHandleEvent(EventPtr eventP)
{
  Err err = 0;
  Boolean handled;
  SysHandleEventFuncType * OldSysHandleEventPtr = 0;
  Boolean ModulePresent = false;

  CALLBACK_PROLOGUE()

  // Todo:
  // This API takes a lot of overhead.  System performance will decrease
  // because SysHandleEvent() is called often.  Need to optimize by caching
  // the old function pointer.  (Global variables are not allowed in Patches
  // because they can be call outside of this application thus rendering the
  // globals out of context.)

  HsCardPatchPrevProc (sysTrapSysHandleEvent, &OldSysHandleEventPtr);

  // If the module is still plugged in, continue as normal; otherwise,
  // disconnect from the library and prepare to exit the application.
  HsCardAttrGet(1, hsCardAttrHwInstalled, &ModulePresent);
  if (!ModulePresent)
	{
	HsDrcGlobalsType*	  gP = 0;
	Word	cardNo = 1;

	//DbgBreak();

    HsCardAttrGet (cardNo, hsCardAttrCardParam, &gP);

	// Close the library
	// Check if the serial library has been un-installed or closed.  
	if (gP && gP->serLibRefNum)							  // not un-installed
	  if ((SysLibTblEntry (gP->serLibRefNum))->globalsP)  // not closed
		err = SerClose (gP->serLibRefNum);

	// Calling HsCardPatchRemove() will cause a bus error
	// which will jump to the Catch block if one is installed.
	err = HsCardPatchRemove (sysTrapSysHandleEvent);
	ErrNonFatalDisplayIf (err, "patch remove err");

	  gP->sysHandleEventPatched = false;
	}

  handled = (OldSysHandleEventPtr)(eventP);

  CALLBACK_EPILOGUE()

  return handled;
}



/***************************************************************
 *	Function:	  PrvCardSysLibFind
 *
 *	Summary:	  Our patch to SysLibFind(). We patch
 *	  SysLibFind when the card is installed to work around a bug
 *	  in the original Visor ROM that results in a conflict with
 *	  Serial Cradle HotSync whenever we re-direct the "default"
 *	  serial library.
 *
 *	  This patch is installed by PrvInstallPatches() and
 *	   removed by PrvRemovePatches().
 *
 *	  The problem is that when PADHTAL (the transport for Local HotSync)
 *	   detects that the Serial Cradle ID pin is asserted, it opens the
 *	   "default" serial library which, in this case, has been redirected
 *	   by the Module, so HotSync attempts to connect through the module
 *	   instead of the Serial Cradle.
 *	  
 *	  To address this, we implement the following workaround for modules
 *	   that redirect the default serial library:
 *	  
 *	  1. When CardSetup is processing the Install action code, it checks
 *		whether it is running on the current version of Handspring Extensions,
 *		and if so, it patches SysLibFind (the assumption is that this problem
 *		would be fixed in any future revision/patch of Handspring Extensions).
 *	  2. When our SysLibFind patch routine is called, it first checks if the
 *		requested library name is the "default" library name. If it is the
 *		"default" library name, and the serial cradle signal is asserted and
 *		the PADHTAL library is installed, the patch calls the old handler with
 *		the explicit name of the docking connector's serial library, instead of
 *		the passed-in name; otherwise, it calls the old handler with the
 *		unmodified name.
 *	  3. In the Remove action code handler, If SysLibFind patch was installed
 *		in step 1, uninstall it.
 *
 *	Parameters: (MUST BE SAME AS SysLibFind!)
 *	  nameP		  IN  internal library name;
 *	  refNumP	  OUT library reference number, if found
 *
 *	Returns: (MUST BE SAME AS SysLibFind!)
 *	  0 if no error
 *	
 *	Called By: 
 *	  System or apps to find a pre-installed library
 *	
 *	History:
 *	  13-Dec-1999  VMK  Created  
 *
 ****************************************************************/
static Err
PrvCardSysLibFind (CharPtr nameP, UIntPtr refNumP)
{
  Err	err;
  UInt16  tempRefNum;
  PrvSysLibFindFuncType*	  oldProcP = NULL;
  CharPtr actNameP	= nameP;


  // Check if this request is for the "default" serial library
  if (StrCompare(nameP, hsLibAliasDefault) != 0)
	goto Find;	  // no? -->

  // Check if the handheld is in a serial cradle
  if (HwrDockStatus() != hwrDockStatusInModem)
	goto Find;	  // no? -->

  // Check if the PADHTAL library is installed
  if (SysLibFind("PADHTAL.lib", &tempRefNum) != 0)
	goto Find;	  // no? -->

  // Assume that the PADHTAL library is being initialized for
  //  a local serial HotSync (not USB), and redirect the request
  //  to the built-in serial library
  actNameP = hsLibNameBuiltInSerial;

Find:
  err = HsCardPatchPrevProc (sysTrapSysLibFind, (DWord*)&oldProcP);
  ErrFatalDisplayIf (err, "missing feature");
  err = (*oldProcP) (actNameP, refNumP);


  return (err);

} // PrvCardSysLibFind



/***************************************************************
 *	Function:	  PrvCardEvtGetEvent
 *
 *	Summary:	  Our patch to EvtGetEvent
 *
 *	This patch is made for a similar reason as the patch to
 *	EvtSysEventAvail.  The problem is that some code incorrectly
 *	deals with Handspring key events coming it.  The primary
 *	offender is LstPopupList(), which gets rid of the popup list
 *	whenever it seems a Handspring key event.
 *
 *	This patch is a little easier though because it is
 *	definitely not interrupt or task safe (no checks for that)
 *	and also we don't have to worry about additional events
 *	coming in.  We just handle Handspring events as we see them.
 *	
 *	The only trick is dealing with the "timeout" parameter, since
 *	we make multiple calls to the real EvtGetEvent.  We just
 *	need to keep track of how much time we've taken so far and
 *	subtract that from future calls.
 *
 *	Parameters:	  
 *	  eventP	OUT	Output place to store the event that comes in.
 *	  timeout	IN	Time to wait an event to come in (in ticks)
 *
 *	Returns
 *	  nothing
 *	
 *	Called By: 
 *	  Anyplace that wants an event.
 *	   
 *  Notes:
 *
 *	History:
 *	  12-oct-2000	dia	  Created
 *
 ****************************************************************/

static void
PrvCardEvtGetEvent (const EventPtr eventP, Int32 timeout)
{
  EvtGetEventFuncType * OldEvtGetEventPtr = 0;
  UInt32 prevTicks = 0;
  Int32  newTimeout = timeout;

  // Need to keep track for timeout purposes...
  if (newTimeout != evtWaitForever)
	{
	  prevTicks = TimGetTicks();
	}

  while (true)
	{
	  // We may be making multiple calls, so we need to deal with the
	  // timeout properly (if it's not just "wait forever", which is
	  // the most common).
	  if (newTimeout != evtWaitForever)
		{
		  UInt32 nowTicks = TimGetTicks();
		  Int32  ticksDiff = nowTicks - prevTicks;

		  if (ticksDiff < newTimeout)
			{
			  newTimeout -= ticksDiff;
			}
		  else
			{
			  newTimeout = 0;
			}
		  prevTicks = nowTicks;
		}

	  HsCardPatchPrevProc (sysTrapEvtGetEvent, &OldEvtGetEventPtr);
	  OldEvtGetEventPtr (eventP, newTimeout);

	  if ((eventP->eType == keyDownEvent)                   &&
		  (eventP->data.keyDown.modifiers & commandKeyMask) &&
		  (eventP->data.keyDown.chr >= hsChrCardUserFirst)  &&
		  (eventP->data.keyDown.chr <= hsChrCardUserLast)     )
		{
		  (void) SysHandleEvent (eventP);
		}
	  else
		{
		  break;
		}
	}
}


/***************************************************************
 *	Function:	  PrvInstallPatches
 *
 *	Summary:	  Installs our patch for SysLibFind(). We patch
 *	  SysLibFind when the card is installed to work around a bug
 *	  in the original Visor ROM that results in a conflict with
 *	  Serial Cradle HotSync whenever we re-direct the "default"
 *	  serial library.
 *
 *	  This patch is installed by PrvInstallPatches() and
 *	   removed by PrvRemovePatches().
 *
 *	  See comments in PrvCardSysLibFind() for more details.
 *
 *
 *	Parameters:
 *	  gP		  IN  our private globals
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  System or apps to find a pre-installed library
 *	
 *	History:
 *	  13-Dec-1999  VMK  Created  
 *
 ****************************************************************/
static void
PrvInstallPatches (HsDrcGlobalsType* gP)
{
  Err	err;
  DWord	hsExtVersion = 0;

  ErrNonFatalDisplayIf (!gP, "null arg");
  ErrNonFatalDisplayIf (gP->sysLibFindPatched, "already patched");

  // For SysLibFind, check whether we're running under the version of Handspring
  // Extensions that needs this patch 
  // Ver 1.00 needs patch
  // Ver 1.01 needs patch
  // Ver 1.02 does not exist
  // Ver 1.03 does NOT need patch because patch is in the extension 

  err = FtrGet (hsFtrCreator, hsFtrIDVersion, &hsExtVersion);
  ErrNonFatalDisplayIf (err, "feature get failed");
  if (sysGetROMVerMajor(hsExtVersion) == 1
		&& sysGetROMVerMinor(hsExtVersion) == 0
		&& sysGetROMVerFix(hsExtVersion) < 3)
	{
	  // Install this patch
	  err = HsCardPatchInstall (sysTrapSysLibFind, (void*)PrvCardSysLibFind);
	  ErrNonFatalDisplayIf (err, "patch install err");

	  // Set this so PrvRemovePatches will know whether to
	  //  remove the patch
	  gP->sysLibFindPatched = true;	  // (***need to add this field to the
									  //  HsDrcGlobalsType structure***)
	}


  // For SysHandleEvent, check whether we're running under the version of Handspring
  // Extensions that needs this patch 
  // Ver 1.00 needs patch
  // Ver 1.01 needs patch
  // Ver 1.02 does not exist
  // Ver 1.03 needs patch 

  if (sysGetROMVerMajor(hsExtVersion) == 1
		&& sysGetROMVerMinor(hsExtVersion) == 0
		&& sysGetROMVerFix(hsExtVersion) < 3)
	{
	  // ---------------------------------------------------------
	  // Install our SysHandleEvent patch so that the System Event 
	  // Handler can be detect card removal and close any libraries
	  // ---------------------------------------------------------
	  err = HsCardPatchInstall (sysTrapSysHandleEvent, (void*)PrvSysHandleEvent);
	  ErrNonFatalDisplayIf (err, "patch install err");

	  // Set this so PrvRemovePatches will know whether to
	  //  remove the patch
	  gP->sysHandleEventPatched = true;	  // (***need to add this field to the
										  //  HsDrcGlobalsType structure***)
    }


  // For EvtGetEvent, check whether we're running under the version of Handspring
  // Extensions that needs this patch 
  // Ver 3.5.2 build 2.0 and above does NOT need patch because patch is in the extension 

  // Handspring extension versions in PalmOS 3.1
  if (
	 (sysGetROMVerMajor(hsExtVersion) <= 1
		&& sysGetROMVerMinor(hsExtVersion) <= 0
		&& sysGetROMVerFix(hsExtVersion) <= 3) 
	 ||
  // Handspring extension versions in PalmOS 3.5
	 (sysGetROMVerMajor(hsExtVersion) <= 3
		&& sysGetROMVerMinor(hsExtVersion) <= 5
		&& sysGetROMVerFix(hsExtVersion) <= 2		// We don't check the stage # because 
		&& sysGetROMVerBuild(hsExtVersion) < 20 )	// it will always be 3 (release stage)
	 )
	{
	  // ---------------------------------------------------------
	  // Install our EvtGetEvent patch so that the it can handle 
	  // HsEvents directly
	  // ---------------------------------------------------------
	  err = HsCardPatchInstall (sysTrapEvtGetEvent, (void*)PrvCardEvtGetEvent);
	  ErrNonFatalDisplayIf (err, "sysTrapEvtGetEvent patch install err");

	  // Set this so PrvRemovePatches will know whether to
	  //  remove the patch
	  gP->evtGetEventPatched = true;	  // (***need to add this field to the
										  //  HsDrcGlobalsType structure***)
    }

  return;
} // PrvInstallPatches



/***************************************************************
 *	Function:	  PrvRemovePatches
 *
 *	Summary:	  Removes our patch for SysLibFind(). We patch
 *	  SysLibFind when the card is installed to work around a bug
 *	  in the original Visor ROM that results in a conflict with
 *	  Serial Cradle HotSync whenever we re-direct the "default"
 *	  serial library.
 *
 *	  This patch is installed by PrvInstallPatches() and
 *	   removed by PrvRemovePatches().
 *
 *	  See comments in PrvCardSysLibFind() for more details.
 *
 *
 *	Parameters:
 *	  gP		  IN  our private globals
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  System or apps to find a pre-installed library
 *	
 *	History:
 *	  13-Dec-1999  VMK  Created  
 *
 ****************************************************************/
static void
PrvRemovePatches (HsDrcGlobalsType* gP)
{
  Err	err;
//  DWord value;

  ErrNonFatalDisplayIf (!gP, "null arg");

  // Remove the "SysLibFind" patch if it was installed
  if (gP->sysLibFindPatched)
	{
	  err = HsCardPatchRemove (sysTrapSysLibFind);
	  ErrNonFatalDisplayIf (err, "patch remove err");


	  gP->sysLibFindPatched = false;

	}

  // Remove the "EvtGetEvent" patch if it was installed
  if (gP->evtGetEventPatched)
	{
	  err = HsCardPatchRemove (sysTrapEvtGetEvent);
	  ErrNonFatalDisplayIf (err, "patch remove err");


	  gP->evtGetEventPatched = false;

	}

  // Remove the "SysHandleEvent" patch if it was installed
  if (gP->sysHandleEventPatched)
	  {
		err = HsCardPatchRemove (sysTrapSysHandleEvent);
		ErrNonFatalDisplayIf (err, "patch remove err");

		gP->sysHandleEventPatched = false;	
	}

  return;
} // PrvRemovePatches



/***************************************************************
 *	Function:	  PrvCardSysTaskSwitching
 *
 *	Summary:	  Our patch to SysTaskSwitching(). We patch
 *	  SysTaskSwitching temporarily from our module "remove"
 *	  handler to work around a bug in NetLib.
 *
 *	  NetLib is one very common client of the serial library that may leave
 *	  the serial port open even after the user switches out of the app
 *	  that was using NetLib (this is called the "close wait" state).
 *	  NetLib does this in order to enable the user to switch from one
 *	  TCP/IP based app to another within a reasonable period of
 *	  time without having to redial and log in to the ISP each time.
 *	  If our serial library is still open at this stage, a reasonable
 *	  thing to try would be to call NetLibFinishCloseWait which is designed
 *	  to end the NetLib's "close wait" state if it happens to be in it.
 *	  
 *	  Unfortunately if the module is removed while NetLib in the process
 *	  of establishing a connection (ie., the Service Connection Progress dialog
 *	  is up), calling either of NetLibFinishCloseWait or NetLibOpenCount
 *	  hangs the calling task (it ends up in an infinite loop inside
 *	  NetLib's NetPrvLockGlobals function).  This happens because our "remove"
 *	  handler is running on the same thread as NetLib's connection logig,
 *	  and the "poor man's" mutex used by NetLib is not designed to be reentrant
 *	  from the same thread.
 *	  
 *	  To guard against leaving the system in a hanged state, we patch
 *	  SysTaskSwitching (which is called periodically by NetPrvLockGlobals
 *	  as part of its poor man's mutex implementation) before calling
 *	  NetLibOpenCount.  Our patch will check whether a particular elapsed
 *	  time has been exceeded, and if it has, assume that we're deadlocked,
 *	  and force closing of our serial library and soft-reset the system.
 *	  
 *	  We will only use this workaround when running under PalmOS v.3.1.x,
 *	  since PalmOS v3.2 is supposed to fix the problem in NetLib.
 *	  
 *	  All card setup utilities should use HsSysPatchInstall() to
 *	  patch traps rather than SysSetTrapAddress() so that they
 *	  will be compatible with HackMaster and any HackMaster hacks
 *	  that might be installed. If you don't use HsSysPatchInstall()
 *	  and HsSysPatchRemove, then your patches might get removed
 *	  if the user de-activates a HackMaster hack while your card
 *	  is installed or you might inadvertently remove a HackMaster 
 *	  patch when your card is removed. 
 *
 *	Parameters:
 *	  enable		IN	  if non-zero, enable task switching;
 *						  if zero, disable task switching
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  System to disable/enable task switching
 *	
 *	History:
 *	  27-Sep-1999  VMK  Created  
 *
 ****************************************************************/

static Err
PrvCardSysTaskSwitching (Boolean enable) 
{
  Err	err;
  Err	(*oldProcP) (Boolean enable) = 0;

  err = HsCardPatchPrevProc (sysTrapSysTaskSwitching, 
							  (DWord*)&oldProcP);
  ErrFatalDisplayIf (err, "missing feature");
  err = (*oldProcP) (enable);

  // Check for time-out
  if (enable)
	{
	  Err	tmpErr;
	  HsDrcGlobalsType*	  gP = 0;
	  DWord	cardNo = 1;

	  // ---------------------------------------------------------
	  // Get our globals pointer out of the card attributes
	  // ---------------------------------------------------------
	  tmpErr = FtrGet (hsDrcSerLibDbCreator, hsDrcFtrNumCardNo, &cardNo);
	  ErrNonFatalDisplayIf (tmpErr, "couldn't get cardNo");
	  tmpErr = HsCardAttrGet ((Word)cardNo, hsCardAttrCardParam, &gP);
	  if (tmpErr || !gP)
		  goto Exit;

	  // If end-time has been exceeded, force removal of our serial
	  //  lib and soft-reset the system
	  if (TimGetTicks () > gP->netLibCheckEndTicks)
		{
		  Boolean needReset;

		  // Uninstall and delete the library -- since we are forcing this,
		  //  PrvLibUninstall will grab ownership of the Memory Manager
		  //  semaphore and disable task switching to protect data storage
		  //  from corruption that could occur if the affected task(s) crashed
		  //  during the forced clean-up
		  PrvLibUninstall (gP, &needReset);

		  // Finally, soft-reset the system
		  SysReset ();
		} // If end-time has been exceeded
	  
	} // Check for time-out


Exit:
  return err;
}



/***************************************************************
 *	Function:	  PrvLibUninstall
 *
 *	Summary:	  Uninstalls and deletes our serial library.  If
 *	  the library is still open, performes a forced close before
 *	  uninstalling/deleting.
 *
 *	  If a forced close is necessary, the library's client(s) could
 *	  be left in an unstable state that could crash the system and
 *	  possibly corrupt data storage.  To reduce the risk of data
 *	  storage corruption, this function takes ownership of the
 *	  Memory Manager semaphore and disables task switching before
 *	  forcing the close.  Once in this state, the only way to
 *	  clean up the system is to perform a soft-reset - so this
 *	  function sets *needResetP to true to indicate to the caller
 *	  that the system is in an unstable state and a soft-reset is
 *	  needed as soon as possible (in this case, the caller should
 *	  complete its cleanup and call SysReset() ASAP). 
 *
 *	Parameters:
 *	  gP			IN	  our card globals
 *	  needResetP	OUT	  will be set to non-zero if the system
 *						   is unstable and a reset is needed;
 *						  will be set to false if we were able
 *						   to perform a clean uninstallation of
 *						   the serial librarylibrary
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  Main event loop of the current application  as a result
 *	  of an interrupt routine enqueing a card event using
 *	  HsCardPostEvent()
 *	
 *	History:
 *	  29-Sep-1999  VMK  Created  
 *
 ****************************************************************/

static Err
PrvLibUninstall (HsDrcGlobalsType* gP, Boolean* needResetP)
{
  Err	err = 0;
  
  ErrNonFatalDisplayIf (!gP || !needResetP, "null arg");


  *needResetP = false;

  // ---------------------------------------------------------
  //  Uninstall the library if it was installed
  // ---------------------------------------------------------
  if (gP->serLibRefNum)
	{

	  // If our serial library is still open (it clears its globals pointer in its
	  //  library table entry when it is closed), force it to close; in this case,
	  //  the only way to clean up the system is to force a soft reset afterwards
	  if ((SysLibTblEntry (gP->serLibRefNum))->globalsP)
		{
		  *needResetP = true;	// tell our caller that soft-reset is needed

		  // Grab the memory sempahore to make sure other tasks are not
		  //  in the middle of mucking with Data or Memory Manager structures,
		  //  and disable task switching to avoid data storage corruption or
		  //  crashing of the system while we take care of clean-up
		  //  ***NOTE***: AMX license is required to use these APIs
		  MemSemaphoreReserve (false /*writeAccess*/);	// this must be first
		  SysTaskSwitching (false /*enable*/);			// this must be second


		  // Force closing of the library -- this is pretty ugly, but necessary
		  do
			{
			  err = SerClose (gP->serLibRefNum);
			} while (err == serErrStillOpen);

		  err = 0;	  // reset the error code after calls to SerClose
		}

	  // Now, uninstall it. This also un-protects it's database 
	  //  to enable it to be deleted
	  SysLibRemove (gP->serLibRefNum);
	  gP->serLibRefNum = 0;
	}


  // Finally, delete it's database
  if (gP->serLibDbID)
	{
	  err = DmDeleteDatabase (0, gP->serLibDbID);
	  if (!err)
		  gP->serLibDbID = 0;
	}

  return err;
}



/***************************************************************
 *	Function:	  PrvInstall
 *
 *	Summary:	  Handle the install action code
 *
 *	  For the install, we must install the system patches, extensions
 *	   and shared libraries associated with the card.
 *	  
 *	  Note that the code for these system "hooks" for the card must
 *	   always be copied into built-in memory before installing them so
 *	   that they can still execute even after the card is pulled. 
 *	  
 *	  Soon after the card is pulled, this app will be called again
 *	   with a hsSysAppLaunchCmdRemove action code. We will then 
 *	   uninstall and delete any code we installed at that time. 
 *	  
 *	  In general, this action code should install the interrupt handler
 *	   and power handler for the card if needed. The only 
 *	   interrupt source on the Handspring developer reference card however
 *	   is the 16650 UART and the 16650 UART library we install takes 
 *	   care of installing the interrupt handler for us when it is 
 *	   opened and removes the handler when it's closed. 
 *	  
 *	  Likewise, the 16650 UART library also takes care of putting the
 *	   UART into and out of low power mode in it's library SerSleep()
 *	   and SerWake() calls. All installed libraries get their Sleep and
 *	   Wake routines automatically called by the system. 
 *	  
 *	  But, even though technically we don't need a separate power handler
 *	   for this board, we install one here anyways just to show how it's
 *	   done. 
 *	  
 *	Parameters:
 *	  cardNo	  IN	card number of card to install
 *	  isReset	  IN	Being called as a result of a soft or hard reset. 
 *						The card setup app will be called again during
 *						  reset even if it was already "installed" before
 *						  reset. This flag indicates whether or not it
 *						  is being called during reset. In most cases, the
 *						  design of the setup app is such that it can ignore
 *						  this flag - worst case it will re-copy databases
 *						  from the card to internal RAM that were already
 *						  present. 
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain() when it gets the install action code
 *	
 *	History:
 *	  4-Mar-1999    RM  Created  
 *	  13-Dec-1999  VMK	Set gP->codeLocked when code resource is locked
 *	  13-Dec-1999  VMK	Install our SysLibFind patch
 *
 ****************************************************************/
static Err	 
PrvInstall (Word cardNo, Boolean isReset)
{
  HsDrcGlobalsType*	  gP = 0;
  LocalID	srcDbID;
  Err		err;
  DWord		handlerP;
  DWord		prefSize;
  VoidHand	codeResH; 



  // ---------------------------------------------------------
  // Save the module's cardNo in a feature -- this value
  //  is accessed by routines which cannot get access to our
  //  globals
  // ---------------------------------------------------------
  err = FtrSet (hsDrcSerLibDbCreator, hsDrcFtrNumCardNo, cardNo);
  ErrNonFatalDisplayIf (err, "FtrSet failed");


  // ---------------------------------------------------------
  // Allocate our globals
  // ---------------------------------------------------------
  gP = MemPtrNew (sizeof (*gP));
  if (!gP) {err = memErrNotEnoughSpace; goto Exit;}
  
  // Set owner to 0 so they don't get freed when current app
  //  quits
  MemPtrSetOwner (gP, 0);
  MemSet (gP, sizeof (*gP), 0);
  

  // ---------------------------------------------------------
  // Init our globals
  // ---------------------------------------------------------
  // Save card number which is passed in the cmdPBP to us
  gP->cardNo = cardNo;


  gP->AppPilotMainHook = (PilotMainHookFuncType*) AppPilotMainHook;
  
  // Store globals pointer as the card param
  err = HsCardAttrSet (gP->cardNo, hsCardAttrCardParam, &gP);
  if (err) goto Exit;


  

  // ---------------------------------------------------------
  //  Install the library for the UART on this card
  // ---------------------------------------------------------
  // First, locate it on the card
  srcDbID = DmFindDatabase (gP->cardNo, hsDrcSerLibDbName);
  if (!srcDbID)
	{
	  err = DmGetLastErr();
	  goto Exit;
	}

  // Now, copy it to internal RAM
  err = HsDatabaseCopy (gP->cardNo, srcDbID, 0 /*dstCardNo*/, 
		  0 /*dstName*/, 
		  hsDbCopyFlagPreserveCrDate 
			| hsDbCopyFlagOKToOverwrite
			| hsDbCopyFlagDeleteFirst, 
		  0 /*tmpName*/, &gP->serLibDbID);
  if (err) goto Exit;

  // NOTE: May need to put up an error dialog box explaining
  //  the failure (such as out of memory, etc.)

  // Install it into system library table now
  err = SysLibLoad (hsDrcSerLibDbType, hsDrcSerLibDbCreator, 
		  &gP->serLibRefNum);
  if (err) goto Exit;
 



  // ---------------------------------------------------------
  // Save all the current serial library assignments because
  //  our Welcome app allows the user to change one or more of
  //  them. 
  // ---------------------------------------------------------
  prefSize = sizeof (gP->serLib.def);
  err = HsPrefGet (hsPrefSerialLibDef, gP->serLib.def, &prefSize);
  if (err) goto Exit;

  prefSize = sizeof (gP->serLib.hotSyncLocal);
  err = HsPrefGet (hsPrefSerialLibHotSyncLocal, gP->serLib.hotSyncLocal,
				   &prefSize);
  if (err) goto Exit;

  prefSize = sizeof (gP->serLib.hotSyncModem);
  err = HsPrefGet (hsPrefSerialLibHotSyncModem, gP->serLib.hotSyncModem,
				   &prefSize);
  if (err) goto Exit;

  prefSize = sizeof (gP->serLib.irda);
  err = HsPrefGet (hsPrefSerialLibIrda, gP->serLib.irda, &prefSize);
  if (err) goto Exit;

  prefSize = sizeof (gP->serLib.console);
  err = HsPrefGet (hsPrefSerialLibConsole, gP->serLib.console, &prefSize);
  if (err) goto Exit;


  // Assign the card to be the default serial library
  prefSize = StrLen (hsDrcSerLibName)+1;
  HsPrefSet (hsPrefSerialLibDef, hsDrcSerLibName, prefSize);


  // ---------------------------------------------------------
  // Install our SysLibFind patch to work around serial HotSync conflict
  //  that occurs in the original Visor ROM when we redirect the default
  //  serial library
  // ---------------------------------------------------------
  PrvInstallPatches (gP);


  // ---------------------------------------------------------
  //  Install a power handler to show "how it's done".
  // As noted above, we don't really need a separate power handler
  //  with this card because we install a library  and all libraries
  //  get their SysLibSleep() and SysLibWake() entry points called
  //  when the system goes to sleep or wakes
  // ---------------------------------------------------------
  handlerP = (DWord)PrvPowerHandler;
  err = HsCardAttrSet (gP->cardNo, hsCardAttrPwrHandler, &handlerP);
  if (err) goto Exit;


  // ---------------------------------------------------------
  //  Install a card event handler to show "how it's done".
  // 
  //  We've written the serial library that we install to
  //   send a card event using HsCardPostEvent() whenever
  //   it gets a '$' character in the serial port to show
  //   how this mechanism works
  // ---------------------------------------------------------
  handlerP = (DWord)PrvEventHandler;
  err = HsCardAttrSet (gP->cardNo, hsCardAttrEvtHandler, &handlerP);
  if (err) goto Exit;

  handlerP = (DWord)PrvAppEventHandler;
  err = HsAppEventHandlerSet ( (void *) handlerP, 0x12345678 /*evtRefCon*/);
  if (err) goto Exit;


  // Because we installed a power and event hadnler, and/or a patch from
  //  this code resource, make sure this code resource remains locked
  //  down after we exit. 
  codeResH = DmGet1Resource ('code', 1);
  if (codeResH)
	{
	  MemHandleLock (codeResH);

	  gP->codeLocked = true;	// so we will be sure to unlock it
								//  in PrvRemove
	}
  else
	{
	  ErrNonFatalDisplay ("couldn't get code resource");
	}



Exit:
  ErrNonFatalDisplayIf (err, "Card install err");
  return err;

}


// #define __Custom_Splash__
// Not compiled in by default.

/***************************************************************
 *	Function:	  PrvRemove
 *
 *	Summary:	  Handle the remove action code
 *
 *	  For the remove, we must "undo" everything we did
 *	above in PrvInstall().
 *
 *	  Note that by the time this routine is called, the card has
 *	already been pulled out so we can't access any memory
 *	or hardware on the card.
 *
 *	  What we need to do is uninstall the library we installed
 *	into the system dispatch table and delete it since it's no
 *	longer useful with the card removed. 
 *	  
 *	Parameters:
 *	  cardNo	  IN	card number of removeable card
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain() when it gets the remove action code
 *	
 *	History:
 *	  04-Mar-1999  RM	Created  
 *	  24-Sep-1999  VMK	If the card serial library is still open,
 *						 try to close it cleanly, or soft-reset the
 *						 device if clean closing is not possible.
 *	  27-Sep-1999  VMK	Resolve system hang when calling NetLibOpenCount
 *						 while NetLib is in the connection stage.
 *	  13-Dec-1999  VMK	Check if gP->codeLocked is set before unlocking
 *	  13-Dec-1999  VMK	Remove our SysLibFind patch
 *
 ****************************************************************/
static Err	 
PrvRemove (Word cardNo)
{
  HsDrcGlobalsType*	  gP = 0;
  Err		err, tmpErr;
  DWord		value;
  Word		prefSize;
  VoidHand	codeResH;
  Boolean	needReset = false;


  // ---------------------------------------------------------
  // Get our globals pointer out of the card attributes then
  //   disassociate them
  // ---------------------------------------------------------
  err = HsCardAttrGet (cardNo, hsCardAttrCardParam, &gP);
  if (err) goto Exit;

  // If no globals, exit
  if (!gP) goto Exit;



  // ---------------------------------------------------------
  // Because we locked our code resource down to install power and event
  //  handlers (and/or patches), restore the lock count now
  // ---------------------------------------------------------
  if (gP->codeLocked)
	{
	  codeResH = DmGet1Resource ('code', 1);
	  if (codeResH)
		MemHandleUnlock (codeResH);
	  else
		{
		  ErrNonFatalDisplay ("couldn't get code resource");
		}
	  
	  gP->codeLocked = false;
	}


  // ---------------------------------------------------------
  // Restore the serial library assignments
  // ---------------------------------------------------------
  prefSize = StrLen (gP->serLib.def) + 1;
  HsPrefSet (hsPrefSerialLibDef, gP->serLib.def, prefSize);

  prefSize = StrLen (gP->serLib.hotSyncLocal) + 1;
  HsPrefSet (hsPrefSerialLibHotSyncLocal, gP->serLib.hotSyncLocal, prefSize);

  prefSize = StrLen (gP->serLib.hotSyncModem) + 1;
  HsPrefSet (hsPrefSerialLibHotSyncModem, gP->serLib.hotSyncModem, prefSize);

  prefSize = StrLen (gP->serLib.irda) + 1;
  HsPrefSet (hsPrefSerialLibIrda, gP->serLib.irda, prefSize);

  prefSize = StrLen (gP->serLib.console) + 1;
  HsPrefSet (hsPrefSerialLibConsole, gP->serLib.console, prefSize);


  // ---------------------------------------------------------
  // Remove our SysLibFind patch that we installed in PrvInstall
  // ---------------------------------------------------------
  PrvRemovePatches (gP);


#ifdef __Custom_Splash__
  // Put up custom splash screen.
  // Closing NetLib can take ~ 15 seconds.
  {
	VoidHand	bitmapH;
	BitmapPtr	bitmapP;
	// ---------------------------------------------------------
	// Draw splash screen
	// ---------------------------------------------------------
	bitmapH = DmGetResource (bitmapRsc, 1000);
	bitmapP = MemHandleLock (bitmapH);
	WinDrawBitmap (bitmapP, 0, 0);
	MemPtrUnlock(bitmapP);
	DmReleaseResource (bitmapH);
  }
#endif

  // ---------------------------------------------------------
  //  Uninstall and delete the library
  // ---------------------------------------------------------

  // If the library was installed and is still open, try to shut it down cleanly
  //  (our serial library clears its globals pointer in its library table entry
  //  when it is fully closed)
  if (gP->serLibRefNum && (SysLibTblEntry (gP->serLibRefNum))->globalsP)
	{
	  UInt16	netLibRefNum;

	  // NOTE:
	  // NetLib is one very common client of the serial library that may leave
	  //  the serial port open even after the user switches out of the app
	  //  that was using NetLib (this is called the "close wait" state).
	  //  NetLib does this in order to enable the user to switch from one
	  //  TCP/IP based app to another within a reasonable period of
	  //  time without having to redial and log in to the ISP each time.
	  //  If our serial library is still open at this stage, a reasonable
	  //  thing to try would be to call NetLibFinishCloseWait which is designed
	  //  to end the NetLib's "close wait" state if it happens to be in it.
	  //
	  //  Unfortunately if the module is removed while NetLib in the process
	  //  of establishing a connection (ie., the Service Connection Progress dialog
	  //  is up), calling either of NetLibFinishCloseWait or NetLibOpenCount
	  //  hangs the calling task (it ends up in an infinite loop inside
	  //  NetLib's NetPrvLockGlobals function).  This happens because our "remove"
	  //  handler is running on the same thread as NetLib's connection logig,
	  //  and the "poor man's" mutex used by NetLib is not designed to be reentrant
	  //  from the same thread.
	  //
	  //  To guard against leaving the system in a hanged state, we patch
	  //  SysTaskSwitching (which is called periodically by NetPrvLockGlobals
	  //  as part of its poor man's mutex implementation) before calling
	  //  NetLibOpenCount.  Our patch will check whether a particular elapsed
	  //  time has been exceeded, and if it has, assume that we're deadlocked,
	  //  and force closing of our serial library and soft-reset the system.
	  //
	  //  We will only use this workaround when running under PalmOS v.3.1.x,
	  //  since PalmOS v3.2 is supposed to fix the problem in NetLib.



	  // If the TCP/IP stack is in the "close wait" state, try to shut down
	  //  its interfaces cleanly to see if this releases our serial lib
	  tmpErr = SysLibFind ("Net.lib", &netLibRefNum);
	  if (!tmpErr)
		{
		  Word	openCount;
		  Err	patchErr, netErr;
		  DWord	osVer = 0;
		  Boolean	patchSysTaskSwitching = false;


		  // HACK HACK HACK HACK HACK HACK HACK
		  //  To guard against leaving the system in a hanged state
		  //  (see NOTE above), we patch calls to SysTaskSwitching (made
		  //  by NetPrvLockGlobals).  Our patch will check whether a
		  //  particular elapsed time has been exceeded, and if it has,
		  //  assume that we're deadlocked and clean up and soft-reset the
		  //  system.
		  //
		  // This problem is supposed to be fixed in PalmOS v.3.2, so we
		  //  only use this workaround when the os is earlier than v.3.2
		  FtrGet (sysFtrCreator, sysFtrNumROMVersion, &osVer);
		  if (osVer < sysMakeROMVersion(3, 2, 0, 0, 0))
			  patchSysTaskSwitching = true;

		  if (patchSysTaskSwitching)
			{
			  gP->netLibCheckEndTicks = TimGetTicks ()
										+ (SysTicksPerSecond () * 10);
			  patchErr = HsCardPatchInstall (sysTrapSysTaskSwitching, 
										(void*)PrvCardSysTaskSwitching);
			  ErrNonFatalDisplayIf (patchErr, "patch install err");
			}

		  // Check NetLib's open count -- if it is zero, NetLib is possibly
		  //  in a "close wait" stait.  If the open count is not zero, NetLib
		  //  is fully open and we can't use NetLibFinishCloseWait 
		  netErr = NetLibOpenCount (netLibRefNum, &openCount);

		  // Remove our patch -- we survived the test without hanging
		  if (patchSysTaskSwitching)
			{
			  patchErr = HsCardPatchRemove (sysTrapSysTaskSwitching);
			  ErrNonFatalDisplayIf (patchErr, "patch remove err");
			}

		  if (!netErr && openCount == 0)
			NetLibFinishCloseWait (netLibRefNum);
		
		} // Try to shut down the TCP/IP stack

	} // // If the library was installed and is still open, ...


  // Finally, uninstall and delete the library
  err = PrvLibUninstall (gP, &needReset);


  // Unregister the cardNo feature that we registered in our
  //  "install" handler
  tmpErr = FtrUnregister (hsDrcSerLibDbCreator, hsDrcFtrNumCardNo);
  ErrNonFatalDisplayIf (tmpErr, "unreg of cardNo ftr failed");


  // ---------------------------------------------------------
  // Free our globals
  // ---------------------------------------------------------
  // Disassociate from the card
  value = 0;
  HsCardAttrSet (cardNo, hsCardAttrCardParam, &value);

  // Free
  MemPtrFree (gP);

  
Exit:
  ErrNonFatalDisplayIf (err, "Card remove err");

  // Since we are implementing safeguard protection of closing the library,
  // we do not need to force the reset 

  return err;

}


/***************************************************************
 *	Function:	  PrvProcessRequest
 *
 *	Summary:	  Handle the hsSerModCmdProcessRequest action code
 *
 *	Parameters:
 *	  reqP		  IN  request parameter block
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain() when it gets the ProcessRequest action code
 *	
 *	History:
 *	  15-Nov-1999  VMK	Created  
 *
 ****************************************************************/
static Err
PrvProcessRequest (HsSerModReqType* reqP)
{
  Err		err = sysErrParamErr;
  HsDrcGlobalsType*	  gP = NULL;
  void*		srcP = NULL;
  void*		dstP = NULL;
  DWord		copySize = 0;


  // Validate request block
  if (reqP->signature != hsSerModReqSignature)
	{
	  ErrNonFatalDisplay ("bad request block signature");
	  return (sysErrParamErr);
	}

  if (reqP->reqSize != sizeof (HsSerModReqType))
	{
	  ErrNonFatalDisplay ("bad request block size");
	  return (sysErrParamErr);
	}

  // Get our globals
  err = HsCardAttrGet (reqP->cardNo, hsCardAttrCardParam, &gP);
  if (err || !gP)
	{
	  ErrNonFatalDisplay ("no card globals");
	  return (sysErrParamErr);
	}

  
  // Init error code
  reqP->err = sysErrParamErr;

  
  if (reqP->reqID == hsSerModReqAttrGet)
	{
	  HsSerModAttrGetType* cmdP = (HsSerModAttrGetType*) reqP->pbP;

	  if (!cmdP)
		{
		  ErrNonFatalDisplay ("no command data for AttrGet");
		  return (sysErrParamErr);
		}

	  switch (cmdP->attrID)
		{
		  case hsSerModAttrPerfMonEnabled:
			if (cmdP->argP && cmdP->argSize == sizeof (Byte))
			  {
				srcP = &gP->perfMonOn;
				dstP = cmdP->argP;
				copySize = cmdP->argSize;
			  }
			else
			  {
				ErrNonFatalDisplay ("Invalid arg for AttrGet of PerfMonEnabled");
			  }
			break;

		  case hsSerModAttrPerfData:
			if (cmdP->argP && cmdP->argSize == sizeof (HsSerModPerfType))
			  {
				srcP = &gP->serPerfMon;
				dstP = cmdP->argP;
				copySize = cmdP->argSize;
			  }
			else
			  {
				ErrNonFatalDisplay ("Invalid arg for AttrGet of PerfData");
			  }
			break;

		  default:
			ErrNonFatalDisplay ("invalid attrID for AttrGet");
			break;
		}
	}
  
  else if (reqP->reqID == hsSerModReqAttrSet)
	{
	  HsSerModAttrSetType* cmdP = (HsSerModAttrSetType*) reqP->pbP;

	  if (!cmdP)
		{
		  ErrNonFatalDisplay ("no command data for AttrGet");
		  return (sysErrParamErr);
		}

	  switch (cmdP->attrID)
		{
		  case hsSerModAttrPerfMonEnabled:
			if (cmdP->argP && cmdP->argSize == sizeof (Byte))
			  {
				srcP = cmdP->argP;
				dstP = &gP->perfMonOn;
				copySize = cmdP->argSize;
			  }
			else
			  {
				ErrNonFatalDisplay ("Invalid arg for AttrSet of PerfMonEnabled");
			  }
			break;

		  case hsSerModAttrPerfData:
			// Clear the perfomance monitoring data
			MemSet (&gP->serPerfMon, sizeof (gP->serPerfMon), 0);
			reqP->handled = true;
			reqP->err = 0;
			err = 0;
			goto Exit;
			break;


		  default:
			ErrNonFatalDisplay ("invalid attrID for AttrSet");
			break;
		}
	}

  else
	{
	  ErrNonFatalDisplay ("invalid request ID");
	}

  // Now, copy the attributes
  if (dstP)
	{
	  MemMove (dstP, srcP, copySize);
	  reqP->handled = true;
	  reqP->err = 0;
	  err = 0;
	}

Exit:
  return (err);
}



/***************************************************************
 *	Function:	  PilotMain
 *
 *	Summary:	  Entry point
 *
 *	Parameters:
 *	  cmd		  IN	Action code for the app. This is one of the
 *						  action codes sysAppLaunchCmdXXX defined in
 *						  <SystemMgr.h>
 *	  cmdPBP	  IN	Parameter block pointer for action code. 
 *	  launchFlags IN	Launch flags, one or more of 
 *						  sysAppLaunchFlagXXX defined in <SystemMgr.h>
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PalmOS when launching the app or asking it to execute an
 *		action code like find or goto. 
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  26-Feb-1999  RM	Created by Ron Marianetti
 *
 ****************************************************************/
DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  Err	  err = 0;
  Word	  cardNo;

  // Get module's cardNo from the parameter block -- it must be in
  //  the first Word
  cardNo = *((WordPtr)cmdPBP);

  // =========================================================
  // Install
  // ========================================================
  if (cmd == hsSysAppLaunchCmdInstall)
	{
	  HsSysAppLaunchCmdInstallType*	pbP;

	  pbP = (HsSysAppLaunchCmdInstallType*)cmdPBP;
	  err = PrvInstall (pbP->cardNo, pbP->isReset);
	}

  // =========================================================
  // Remove
  // ========================================================
  else if (cmd == hsSysAppLaunchCmdRemove)
	{
	  HsSysAppLaunchCmdRemoveType*	pbP;

	  pbP = (HsSysAppLaunchCmdRemoveType*)cmdPBP;
	  err = PrvRemove (pbP->cardNo);
	}


  // CUSTOM ACTION CODES:
  else if (cmd == hsSerModCmdProcessRequest)
	{
	  HsSerModReqType*	pbP;

	  pbP = (HsSerModReqType*)cmdPBP;
	  err = PrvProcessRequest (pbP);
	}


  ErrNonFatalDisplayIf (err != 0, "Card setup err");
  return err;
}
