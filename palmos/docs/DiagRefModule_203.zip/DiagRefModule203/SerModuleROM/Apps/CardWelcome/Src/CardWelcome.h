//**************************************************************
//
//  Project:
//	  Handspring Sample Card Welcome application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  CardWelcome.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
//
// History:
//	  11-Feb-1999  - Created 
//***************************************************************/


// Main Form
#define resFormIDMain				1000
#define	resMainRouteLabelID			1001
#define	resMainLocalHotSyncLabelID	1002
#define	resMainLocalHotSyncCheckID	1003
#define	resMainModemHotSyncLabelID	1004
#define	resMainModemHotSyncCheckID	1005
#define	resMainBeamingLabelID		1006
#define	resMainBeamingCheckID		1007
#define	resMainConsoleLabelID		1008
#define	resMainConsoleCheckID		1009
#define	resMainDefaultLabelID		1010
#define	resMainDefaultCheckID		1011
					
					
// Main form menu				
#define resMenuIDMain				1000
#define resMenuItemAbout			1001


// Alerts
#define resAlertIDAbout				1000
