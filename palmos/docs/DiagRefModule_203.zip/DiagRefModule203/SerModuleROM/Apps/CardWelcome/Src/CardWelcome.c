/***************************************************************
 *
 *  Project:
 *	  Handspring Sample Card Welcome application
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  CardWelcome.c
 * 
 *  Description:
 *	  This is the main source file for the Card Welcome application.
 *	Because this application has database name of "CardWelcome", it
 *	will be automatically launched when the card is inserted. 
 *
 * ToDo:
 *
 * History:
 *	  11-Feb-1999  RM  Created  by Ron Marianetti
 ****************************************************************/

// PalmOS includes
#include <PalmOS.h>
#include <CoreCompatibility.h>

// Handspring extensions
#include <HsExt.h>

// Card specific defines
#include "HsDevRefCard.h"

// Application specific
#include "CardWelcome.h"


/***************************************************************
 *	Function:	  PrvInitSerialCheckBox
 *
 *	Summary:	  Initializes the given checkbox in the
 *	  form according to whether or not associated client
 *	  is using the Card's serial library or not
 *
 *	Parameters:
 *	  frmP		IN	  form pointer
 *	  ctlID		IN	  checkbox control ID
 *	  client	IN	  which client to check
 *	  
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  MainFrmInit()
 *	
 *	Notes:
 *	
 *	History:
 *	  10-Mar-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
PrvInitSerialCheckBox (FormPtr formP, Word ctlID, HsPrefEnum client)
{
  ControlPtr	ctlP;
  SWord			value;
  Char			libName[dmDBNameLength];
  DWord			prefSize;
  Err			err;


  prefSize = sizeof (libName);
  err = HsPrefGet (client, libName, &prefSize);
  if (err || StrCompare (libName, hsDrcSerLibName))
	value = 0;
  else
	value = 1;

  ctlP = FrmGetObjectPtr (formP, FrmGetObjectIndex (formP, ctlID));
  CtlSetValue (ctlP, value);

}



/***************************************************************
 *	Function:	  MainFrmInit
 *
 *	Summary:	  This routine initializes the "Main View" of our app
 *
 *	Parameters:
 *	  frmP		IN	  form pointer
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  MainFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
MainFrmInit (FormPtr formP)
{


  // ---------------------------------------------------------
  // Init the values of the checkboxes for serial redirection
  // ---------------------------------------------------------
  PrvInitSerialCheckBox (formP, resMainLocalHotSyncCheckID, 
							  hsPrefSerialLibHotSyncLocal);

  PrvInitSerialCheckBox (formP, resMainModemHotSyncCheckID, 
							  hsPrefSerialLibHotSyncModem);

  PrvInitSerialCheckBox (formP, resMainBeamingCheckID, 
							  hsPrefSerialLibIrda);

  PrvInitSerialCheckBox (formP, resMainConsoleCheckID, 
							  hsPrefSerialLibConsole);

  PrvInitSerialCheckBox (formP, resMainDefaultCheckID, 
							  hsPrefSerialLibDef);
  
}



/***************************************************************
 *	Function:	  MainFrmEventHandler
 *
 *	Summary:	  Event handler for our main form. 
 *
 *	Parameters:
 *	  eventP	  IN	pointer to event to handle
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  FrmDispatchEvent() when event is for our main form. 
 *	  FrmDispatchEvent() is called by our AppEventLoop() 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static Boolean 
MainFrmEventHandler (EventPtr eventP)
{
  FormPtr		formP;
  Boolean		handled = false;
  DWord			prefSize;
  Char			defLibName[1];
  CharPtr		cardLibNameP;
  HsPrefEnum	pref=0;


  switch (eventP->eType) 
	{

	// ------------------------------------------------------
	// Open the main form
	// ------------------------------------------------------
	case frmOpenEvent:
	  formP = FrmGetActiveForm ();
	  MainFrmInit (formP);
	  FrmDrawForm (formP);
	  handled = 1;
	  break;
    

	// -------------------------------------------------------
	// Menu
	// -------------------------------------------------------
	case menuEvent:
	  switch (eventP->data.menu.itemID)
		{
		case resMenuItemAbout:
		  // FrmAlert (resAlertIDAbout);

		  // Demonstration of how to post an event to our
		  //  PrvAppEventHandler procedure. 
		  HsAppEventPost (hsMaxAppEvent, 0xabcd /*evtParam*/);
		  //HsCardEventPost (1, 1, 1);
		  break;
		}
	  handled = 1;
	  break;


	// -------------------------------------------------------
	// Control
	// -------------------------------------------------------
	case ctlSelectEvent:

  	  switch (eventP->data.ctlSelect.controlID)
		{
		case resMainLocalHotSyncCheckID:
		  pref = hsPrefSerialLibHotSyncLocal;
		  handled = true;
		  break;
		case resMainModemHotSyncCheckID:
		  pref = hsPrefSerialLibHotSyncModem;
		  handled = true;
		  break;
		case resMainBeamingCheckID:
		  pref = hsPrefSerialLibIrda;
		  handled = true;
		  break;
		case resMainConsoleCheckID:
		  pref = hsPrefSerialLibConsole;
		  handled = true;
		  break;
		case resMainDefaultCheckID:
		  pref = hsPrefSerialLibDef;
		  handled = true;
		  break;
 
		}

	  // Set the new routing now
	  if (handled)
		{
		  defLibName[0] = 0;
		  cardLibNameP = hsDrcSerLibName;
		  prefSize = StrLen (cardLibNameP)+1;

		  if (CtlGetValue (eventP->data.ctlSelect.pControl))
			HsPrefSet (pref, cardLibNameP,  prefSize);
		  else
			HsPrefSet (pref, defLibName, 1);
		}
	  break;


	// -------------------------------------------------------
	// Nil event
	// -------------------------------------------------------
	case nilEvent:
	  handled = 1;
	  break;

	default:
	  break;
	}
  return handled;
}



/***************************************************************
 *	Function:	  PrvAppEventHandler
 *
 *	Summary:	  This event handler procedure will be automatically
 *	  called by the system (within SysHandleEvent()) in response
 *	  to an event posted by HsAppEventPost(). 
 *
 *	  Because SysHandleEvent() may be called from another app's 
 *	  action code processing logic, this routine can not use global 
 *	  variables. It must instead use variables referenced off the 
 *	  evtRefCon parameter that gets setup by HsAppEventHandlerSet(). 
 *
 *	Parameters:
 *	  evtRefCon	  IN	32-bit value set by HsAppEventHandlerSet()
 *	  evtNum	  IN	app event number, from 0 to hsMaxAppEvent,
 *						  passed to HsAppEventPost()
 *	  evtParam	  IN	16-bit event parameter passed to 
 *						  HsAppEventPost()
 *						  
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  System from SysHandleEvent()
 *	
 *	Notes:
 *	
 *	History:
 *	  16-Apr-1999  RM  Ceated 
 *
static Boolean 
PrvAppEventHandler (DWord evtRefcon, Word evtNum, Word evtParam)
{
  SndPlaySystemSound (sndConfirmation);
  FrmAlert (resAlertIDAbout);

  // handled
  return true;	  
}
 ****************************************************************/


/***************************************************************
 *	Function:	  AppStart
 *
 *	Summary:	  Application initialization when being launched
 *		as a normal application (i.e. not to execute an action code).
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain when action code is for a normal launch. 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static DWord 
AppStart(void)
{
//  Err	err;


  // Go to our main form
  FrmGotoForm (resFormIDMain);


  // ------------------------------------------------------------
  // This is a demonstration of how to register an app event handler
  //  procedure. This handler can be triggered by calling
  //  HsAppEventPost() anywhere in your application. It will remain
  //  in effect until the application quits. 
  //
  // Application event handlers must not rely on global variables. 
  //  instead, they should use the evtRefCon parameter as a pointer
  //  to a structure to update if necessary. 
  // ------------------------------------------------------------
//  err = HsAppEventHandlerSet (PrvAppEventHandler, 
//							  0x12345678 /*evtRefCon*/);

  return 0;
}




/***************************************************************
 *	Function:	  AppStop
 *
 *	Summary:	  Application cleanup. This routine cleans up
 *	  all initialization performed by AppStart(). 
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain, after EventLoop returns
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
AppStop (void)
{
}


/***************************************************************
 *	Function:	  AppEventLoop
 *
 *	Summary:	  Main event loop for the application
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain after initializing. 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
AppEventLoop(void)
{
  short		err;
  int		formID;
  FormPtr	formP;
  EventType event;

  do
	{

	  EvtGetEvent (&event, 200);

	  if (SysHandleEvent (&event)) continue;
	  if (MenuHandleEvent ((void *)0, &event, &err)) continue;

	  if (event.eType == frmLoadEvent)
		{
		  formID = event.data.frmLoad.formID;
		  formP = FrmInitForm (formID);
		  FrmSetActiveForm (formP);

		  switch (formID) 
			{
			case resFormIDMain:
			  FrmSetEventHandler (formP, (FormEventHandlerPtr) 
				  MainFrmEventHandler);
			  break;
			}
		}

	  FrmDispatchEvent(&event);

	 } while(event.eType != appStopEvent);
}







/***************************************************************
 *	Function:	  PilotMain
 *
 *	Summary:	  Entry point
 *
 *	Parameters:
 *	  cmd		  IN	Action code for the app. This is one of the
 *						  action codes sysAppLaunchCmdXXX defined in
 *						  <SystemMgr.h>
 *	  cmdPBP	  IN	Parameter block pointer for action code. 
 *	  launchFlags IN	Launch flags, one or more of 
 *						  sysAppLaunchFlagXXX defined in <SystemMgr.h>
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PalmOS when launching the app or asking it to execute an
 *		action code like find or goto. 
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated by Ron Marianetti
 *
 ****************************************************************/
DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  DWord err;

  if (cmd == sysAppLaunchCmdNormalLaunch)
	{

	  err = AppStart();				// Application start code
	  if (err) return err;

	  AppEventLoop();				// Event loop

	  AppStop ();					// Application stop code
	}

  return 0;
}




