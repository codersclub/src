/***************************************************************
 *
 *  Project:
 *	  Handspring simple serial terminal application
 *
 * Copyright info:
 *
 *	  This is free software; you can redistribute it and/or modify
 *	  it as you like.
 *
 *	  This program is distributed in the hope that it will be useful,
 *	  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
 *
 *
 *  FileName:
 *	  HandTerminal.c
 * 
 *  Description:
 *	  This is the main source file for the HandTerminal application.
 *
 *	  This is a simple serial dumb terminal that allows you to
 *	  send (using Graffiti) and receive characters through the serial 
 *	  port. 
 *
 *	  The program is basically a test bed for using the serial 
 *	  library installed with the developer sample plug-in card
 *	  which has flash memory and a 16650 UART on it. 
 *
 * ToDo:
 *	  Menu command for showing status of CTS & DSR
 *
 * History:
 *	  26-Feb-1999  RM  Created  by Ron Marianetti
 ****************************************************************/

#include <PalmOS.h>
#include <HsExt.h>
#include <CoreCompatibility.h>

#include <HsExt.h>
#include <CallbackFix.h>
#include <SerialMgrOld.h>
#include "HandTerminal.h"
#include "AppStdio.h"

// Include Card equates that contains the name of the serial library
//  on the removable card
#include "HsDevRefCard.h"


// Defines for new technique 
// New technique for open library soft reset proctection by 
// installing patches in dynamic memory
#define DYNAMIC_PATCH_SOFT_RESET_PROTECTION 1

// Defines for old technique 
// Old technique for open library soft reset proctection by 
// hooking patches in in static code
#define STATIC_PATCH_SOFT_RESET_PROTECTION 0



/***********************************************************************
 *
 *	Private Equates
 *
 ***********************************************************************/


// Name of the serial library we look for by name
#define	prvBuiltInLibName		"Serial Library"
#define	prvExtLibName			hsDrcSerLibName



#define	prvNumBaudMappings			10
#define	prvDefaultBaudIdx			6
#define	prvNumDataBitMappings		4


// Structure of our prefs
typedef struct
  {
	Word  port;				// 0-builtin, 1-external
	Word  baudRate;			// PrvBaudMappings
	Word  hshk;				// 0-none, 1-Hw
	Word  parity;			// 0-none, 1-odd, 2-even
	Word  stopBits;			// 0-1, 1-2
	Word  dataBits;			// PrvDatabitMappings
  } PrvPrefsType;


/***********************************************************************
 *
 *	Global variables
 *
 ***********************************************************************/
static	Word				PrvSerRefNum = 0;
static	Boolean				PrvSerLibOpened = false;


// Baud Rate Settings
static DWord PrvBaudMappings [prvNumBaudMappings] =
  {	
	300, 1200, 2400, 4800, 7200, 9600, 19200, 38400, 57600, 115200
  };

// Data Bits settings
static DWord PrvDatabitMappings [prvNumDataBitMappings] =
  {	
	5, 6, 7, 8
  };


static PrvPrefsType			PrvPrefs;
static PrvPrefsType			PrvOldPrefs;


/***********************************************************************
 *
 *  Function:    PrvMapToPosition
 *
 *  Summary:	
 *	  Map a value to it's position in an array.  If the passed
 *    value is not found in the mappings array, a default
 *	  mappings item will be returned.
 *
 *  Parameters:  
 *	  mappingArray		IN	  array of mappings
 *	  value				IN	  value to map
 *	  mappings			IN	  size of mappingArray
 *	  defaultItem		IN	  default item index 
 *
 *  Returns:  index of item in mappingArray
 *
 *	History:
 *	  8-Mar-1999  RM  Ceated 
 *
 ***********************************************************************/
static Word 
PrvMapToPosition (DWord* mappingArray, DWord value, Word mappings, 
				  Word defaultItem)
{
  Word i;

  i = 0;
  while (mappingArray[i] != value && i < mappings)
	i++;
  if (i >= mappings)
	return defaultItem;

  return i;
}	//	end of PrvMapToPosition



/***********************************************************************
 *
 *  Function:    PrvChangeCommSettings
 *
 *  Summary:	
 *	  Opens up a new serial connection and/or changes serial settings
 *	according to values stored in prefs
 *
 *  Parameters:  
 *	  prefsP	  IN	pointer to new prefs
 *
 *  Returns:  void
 *
 *	History:
 *	  8-Mar-1999  RM  Ceated 
 *
 ***********************************************************************/
static void 
PrvChangeCommSettings (PrvPrefsType*  prefsP)
{
  char*	  libNameP;
  static  Word	  oldPort = 0;
  Err	  err;



  // -------------------------------------------------------------
  // First, close existing one if open and wrong port
  // -------------------------------------------------------------
  if (PrvSerLibOpened && oldPort != prefsP->port) 
	{
	   SerClose (PrvSerRefNum);
	   PrvSerLibOpened = false;
	   PrvSerRefNum = 0;
	}


  // -------------------------------------------------------------
  // Open the port if necessary
  // -------------------------------------------------------------
  if (!PrvSerLibOpened)
	{

	  // .......................................................
	  // Find the library's refnum
	  // ....................................................
	  if (prefsP->port == 0)
		libNameP = prvBuiltInLibName;
	  else
		libNameP = prvExtLibName;

	  err = SysLibFind (libNameP, &PrvSerRefNum);

	  // DEBUG!!!!!
	  if (err && (prefsP->port == 1))
		{
		  SysLibLoad ('libr', 'HsCs', &PrvSerRefNum);
		  err = SysLibFind (libNameP, &PrvSerRefNum);
		}

	  if (err)
		{
		  printf ("\nERROR: Couldn't find library: %s\n", libNameP);
		  return;
		}


	  // ....................................................
	  // Open it now
	  // ....................................................
	  err = SerOpen (PrvSerRefNum, 0, 19200);
	  if (err)
		{
		  if (err == serErrAlreadyOpen)
			{
			  printf ("\nERROR: Serial already open by another app");
			  SerClose (PrvSerRefNum);
			}
		  else
			printf ("\nERROR: %d: Couldn't open serial library", err);
		}
	  else
		{
		  PrvSerLibOpened = true;
		  oldPort = PrvPrefs.port;
		}
	}


  // -------------------------------------------------------------
  // Set the settings
  // -------------------------------------------------------------
  if (PrvSerLibOpened)
	{
	  SerSettingsType settings;

	  // Get current settings
	  err = SerGetSettings (PrvSerRefNum, &settings);
	  if (err) goto Exit;

	  // Change them
	  settings.baudRate = PrvBaudMappings[PrvPrefs.baudRate];

	  settings.flags = 0;
	  if (PrvPrefs.hshk)
		settings.flags |= serSettingsFlagRTSAutoM | serSettingsFlagCTSAutoM;

	  switch (PrvPrefs.parity)
		{
		case 1:
		  settings.flags |= serSettingsFlagParityOnM;
		  break;
		case 2:
		  settings.flags |= serSettingsFlagParityOnM | serSettingsFlagParityEvenM;
		  break;
		}

	  switch (PrvPrefs.stopBits)
		{
		case 0:
		  settings.flags |= serSettingsFlagStopBits1;
		  break;
		case 1:
		  settings.flags |= serSettingsFlagStopBits2;
		  break;
		}

	  switch (PrvDatabitMappings[PrvPrefs.dataBits])
		{
		case 5:
		  settings.flags |= serSettingsFlagBitsPerChar5;
		  break;
		case 6:
		  settings.flags |= serSettingsFlagBitsPerChar6;
		  break;
		case 7:
		  settings.flags |= serSettingsFlagBitsPerChar7;
		  break;
		case 8:
		  settings.flags |= serSettingsFlagBitsPerChar8;
		  break;
		}
		  
	  err = SerSetSettings (PrvSerRefNum, &settings);
	}

Exit:
  if (err) printf ("\nERROR: 0x%x: Couldn't change serial settings", err);
  

}	//	end of PrvChangeCommSettings



/***************************************************************
 *	Function:	  MainFrmInit
 *
 *	Summary:	  This routine initializes the "Main View" of our app
 *
 *	Parameters:
 *	  frmP		IN	  form pointer
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  MainFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
MainFrmInit (FormPtr frmP)
{
}





/***************************************************************
 *	Function:	  MainFrmDoCommand
 *
 *	Summary:	  Execute a menu command for our main form 
 *
 *	Parameters:
 *	  command	  IN	menu command to execute
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  MainFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static Boolean 
MainFrmDoCommand (Word command)
{
  Boolean	handled = true;

  
  switch (command) 
	{
		  
	//...........................................................
	// Misc Menu
	//...........................................................
	case resMenuItemAbout:
	  FrmAlert (resAlertIDAbout);
	  break;
		
	case resMenuItemComm:
	  FrmPopupForm (resFormIDComm);
	  break;
		
	case resMenuItemStatus:
	  if (PrvSerLibOpened)
		{
		  Word	lineErr;
		  Boolean cts, dsr;

		  lineErr = SerGetStatus (PrvSerRefNum, &cts, &dsr);
		  printf ("\nStatus: lineErr=0x%x CTS=%d DSR=%d\n",
			lineErr, (int)cts, (int)dsr);
		}

	  break;
		
	default:
	  // allow edit events to be handled by frmhandleevent
	  handled = false;
	  break;
	
	}	

  return handled;
}



/***************************************************************
 *	Function:	  MainFrmEventHandler
 *
 *	Summary:	  Event handler for our main form. 
 *
 *	Parameters:
 *	  eventP	  IN	pointer to event to handle
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  FrmDispatchEvent() when event is for our main form. 
 *	  FrmDispatchEvent() is called by our AppEventLoop() 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static Boolean 
MainFrmEventHandler (EventPtr eventP)
{
  FormPtr   formP;
  Boolean   handled = false;
  Err		err;
  char		buffer[64];
  DWord		bytes=0;
  SWord		i;
  static	char  prevChar = 0;


  // See if StdIO can handle it
  if (StdHandleEvent (eventP)) return true;
	

  switch (eventP->eType) 
	{


	// -------------------------------------------------------
	// Init the form
	// -------------------------------------------------------
	case frmOpenEvent:
	  formP = FrmGetActiveForm ();
	  MainFrmInit (formP);
	  FrmDrawForm (formP);
	  handled = 1;

	  // Print welcome message
	  printf("\nWelcome to Hand Terminal!");

	  // setup comm
	  PrvChangeCommSettings (&PrvPrefs);

	  break;
    
	// -------------------------------------------------------
	// Menu commands
	// -------------------------------------------------------
	case menuEvent:
	  handled =  MainFrmDoCommand (eventP->data.menu.itemID);
	  break;


	// -------------------------------------------------------
	// See if any serial data is available, and if so, print it
	// -------------------------------------------------------
	case nilEvent:

	  handled = true;
	  if (!PrvSerLibOpened) break;

	  // See what's available
	  err = SerReceiveCheck (PrvSerRefNum, &bytes);
	  
	  // If there's a serial err, clear it
	  if (err == serErrLineErr)
		{
		  printf ("\n[LINE ERROR]\n");
		  SerClearErr (PrvSerRefNum);
		}
	  if (err || !bytes) break;
	  if (bytes > sizeof (buffer)-1) 
		bytes = sizeof (buffer)-1;

	  // Read whatever's available now 
	  bytes = SerReceive (PrvSerRefNum, buffer, bytes,  1, &err);

	  if (err && err != serErrTimeOut) 
		  SerClearErr (PrvSerRefNum);
	  if (!bytes) break;

	  // Translate CR-LF's to PalmOS format
	  buffer[bytes] = 0;
	  for (i=0; (DWord)i<bytes; i++)
		{
		  char	c;
		  c = buffer[i];

		  // Get rid of CR/LF pairs
		  if (prevChar == 10 && c == 13)
			{
			  MemMove (buffer+i, buffer+i+1, bytes-i);
			  bytes--;
			  // Redo the character we just shifted into position i
			  i--;
			  continue;
			}
		  else if (prevChar == 13 && c == 10)
			{
			  MemMove (buffer+i, buffer+i+1, bytes-i);
			  bytes--;
			  // Redo the character we just shifted into position i
			  i--;
			  continue;
			}

		  // Replace CR's with LFs
		  else if (c == 13)
			buffer[i] = 10;


		  // Process back-space specially if it's near the front
		  else if (c == 8)
			{
			  // If near the front, feed a backspace char to field
			  if (i==0) 
				StdBS();

			  // Remove it from buffer
			  MemMove (buffer+i, buffer+i+1, bytes-i);

			  // Skip this char now
			  i--;
			  bytes--;
			}

		  prevChar = c;
		}

	  // Print out buffer
	  if (buffer[0]) 
		StdPutS (buffer);
	  break;


	// -------------------------------------------------------
	// Close our form
	// -------------------------------------------------------
	case frmCloseEvent:
	  break;

	default:
	  break;
	}
  return handled;
}





/***************************************************************
 *	Function:	  CommFrmInit
 *
 *	Summary:	  This routine initializes the "Communications" 
 *	  dialog
 *
 *	Parameters:
 *	  frmP		IN	  form pointer
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  CommFrmEventHandler()
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
CommFrmInit (FormPtr formP)
{
  ListPtr		listP;



  // Init the Port list pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommPortListID));
  LstSetSelection (listP, PrvPrefs.port);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommPortTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.port));


  //	Init the baud rate pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommBaudListID));
  LstSetSelection (listP, PrvPrefs.baudRate);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommBaudTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.baudRate));


  //	Init the Handshaking pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommHshkListID));
  LstSetSelection (listP, PrvPrefs.hshk);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommHshkTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.hshk));


  //	Init the Parity pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommParityListID));
  LstSetSelection (listP, PrvPrefs.parity);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommParityTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.parity));


  //	Init the Stop Bits pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommStopListID));
  LstSetSelection (listP, PrvPrefs.stopBits);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommStopTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.stopBits));


  //	Init the Data Bits pop-up
  listP = FrmGetObjectPtr (formP, 
			FrmGetObjectIndex (formP, resCommDataListID));
  LstSetSelection (listP, PrvPrefs.dataBits);
  CtlSetLabel (FrmGetObjectPtr (formP, 
				FrmGetObjectIndex (formP, resCommDataTriggerID)),
				  LstGetSelectionText (listP, PrvPrefs.dataBits));



}



/***************************************************************
 *	Function:	  CommFrmEventHandler
 *
 *	Summary:	  Event handler for our Communications options
 *	  dialog. 
 *
 *	Parameters:
 *	  eventP	  IN	pointer to event to handle
 *
 *	Returns:
 *	  true if event was handled
 *	
 *	Called By: 
 *	  FrmDispatchEvent() when event is for our comm form. 
 *	  FrmDispatchEvent() is called by our AppEventLoop() 
 *	
 *	Notes:
 *	
 *	History:
 *	  8-Mar-1999  RM  Ceated 
 *
 ****************************************************************/
static Boolean 
CommFrmEventHandler (EventPtr eventP)
{
  FormPtr		formP;
  Boolean		handled = false;
  Word			item;

  switch (eventP->eType) 
	{
	// -------------------------------------------------------
	// Init the form
	// -------------------------------------------------------
	case frmOpenEvent:
	  // Save old prefs in case of cancel
	  PrvOldPrefs = PrvPrefs;
	  formP = FrmGetActiveForm ();
	  CommFrmInit (formP);
	  FrmDrawForm (formP);
	  handled = true;
	  break;
    

	// -------------------------------------------------------
	// Close our form
	// -------------------------------------------------------
	case frmCloseEvent:
	  break;


	// -------------------------------------------------------
	// Control
	// -------------------------------------------------------
	case ctlSelectEvent:
	  switch (eventP->data.ctlSelect.controlID)
		{
		case resCommOKBtnID:
		  // Setup new comm settings
		  PrvChangeCommSettings (&PrvPrefs);
		  FrmReturnToForm (0);
		  handled = true;
		  break;
 
		case resCommCancelBtnID:
		  PrvPrefs = PrvOldPrefs;
		  FrmReturnToForm (0);
		  handled = true;
		  break;
		}
	  break;

	// -------------------------------------------------------
	// Pop-up list
	// -------------------------------------------------------
	case popSelectEvent:
	  item = eventP->data.popSelect.selection;
	  switch (eventP->data.popSelect.listID)
		{
		case resCommPortListID:
		  PrvPrefs.port = item;
		  break;
		case resCommBaudListID:
		  PrvPrefs.baudRate = item;
		  break;
		case resCommHshkListID:
		  PrvPrefs.hshk = item;
		  break;
		case resCommParityListID:
		  PrvPrefs.parity = item;
		  break;
		case resCommStopListID:
		  PrvPrefs.stopBits = item;
		  break;
		case resCommDataListID:
		  PrvPrefs.dataBits = item;
		  break;
		default:
		  DbgBreak();
		  break;
		}
	  break;


	default:
	  break;
	}
  return handled;
}



/***************************************************************
 *	Function:	  AppExecCommand
 *
 *	Summary:	  Separates a command line into argc, argv 
 *					components and then calls the appropriate routine.
 *
 *	Parameters:
 *	  cmdParamP	  IN  pointer to command line
 *
 *	Returns:
 *	  void
 *	
 *	Called By: 
 *	  StdIO module when user hits enter
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
AppExecCommand(CharPtr cmdParamP)
{
  Err	err;
  
  // Send to the serial port, if opened
  if (PrvSerLibOpened) 
	{
	  SerSend (PrvSerRefNum, cmdParamP, StrLen (cmdParamP), &err);
	  SerSend (PrvSerRefNum, "\015\012", 2, &err);
	}

  else
	printf("\nError: serial library not open\n");  
	 
}



/***************************************************************
 *	Function:	  AppStart
 *
 *	Summary:	  Application initialization when being launched
 *		as a normal application (i.e. not to execute an action code).
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain when action code is for a normal launch. 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *	  28-Jan-2000  VMK Check if a removable module is present
 *
 ****************************************************************/
static DWord 
AppStart(void)
{
  SWord	  version;
  Word	  prefsSize;


  // Init our terminal functions for printing to the screen
  StdInit (resFormIDMain, resMainTextFldID, resMainScrollerID,
				  AppExecCommand);
	

  // Read in our prefs
  prefsSize = sizeof (PrvPrefs);
  version = PrefGetAppPreferences (appCreator, 0, &PrvPrefs,
			  &prefsSize, true /*saved*/);
  if (version != appVersion)
	{
	  MemSet (&PrvPrefs, sizeof (PrvPrefs), 0);

	  PrvPrefs.baudRate = PrvMapToPosition (PrvBaudMappings, 19200,
		prvNumBaudMappings, prvDefaultBaudIdx);

	  PrvPrefs.dataBits = PrvMapToPosition (PrvDatabitMappings, 8,
		prvNumDataBitMappings, prvDefaultBaudIdx);
	}


  FrmGotoForm (resFormIDMain);
  return 0;
}


/***************************************************************
 *	Function:	  AppStop
 *
 *	Summary:	  Application cleanup. This routine cleans up
 *	  all initialization performed by AppStart(). 
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain, after EventLoop returns
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
AppStop (void)
{
  EventType	event;

  // Close our main form
  event.eType = frmCloseEvent;
  event.data.frmClose.formID = resFormIDMain;
  FrmDispatchEvent (&event);

  if (PrvSerLibOpened) 
	{
	SerClose (PrvSerRefNum);
	PrvSerLibOpened = false;
	}

  // Save our Prefs
  PrefSetAppPreferences (appCreator, 0, appVersion, &PrvPrefs, 
	  sizeof (PrvPrefs), true /*saved*/);

  // Free the Stdio Support
  StdFree ();

}



/***************************************************************
 *	Function:	  AppEventLoop
 *
 *	Summary:	  This routine loads form resources and set the event
 *              handler for the form loaded.
 *
 *	Parameters:
 *	  eventP	IN	  pointer to event
 *
 *	Returns:
 *	  true if event was handled. 
 *	
 *	Called By: 
 *	  AppEventLoop. 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static Boolean 
AppHandleEvent (EventPtr eventP)
{
  Word formID;
  FormPtr frmP;

  if (eventP->eType == frmLoadEvent) 
	{

	  // Load the form resource.
	  formID = eventP->data.frmLoad.formID;
	  frmP = FrmInitForm (formID);
	  FrmSetActiveForm (frmP);		
	  
	  // Set the event handler for the form.  The handler of the currently
	  // active form is called by FrmHandleEvent each time is receives an
	  // event.
	  switch (formID) 
		{
		  case resFormIDMain:
			  FrmSetEventHandler (frmP, MainFrmEventHandler);
			  break;

		  case resFormIDComm:
			  FrmSetEventHandler (frmP, CommFrmEventHandler);
			  break;
		}
	  return (true);
	}
  return (false);
}



/***************************************************************
 *	Function:	  AppEventLoop
 *
 *	Summary:	  Main event loop for the application
 *
 *	Parameters:
 *	  void
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  PilotMain after initializing. 
 *	
 *	Notes:
 *	
 *	History:
 *	  26-Feb-1999  RM  Ceated 
 *
 ****************************************************************/
static void 
AppEventLoop(void)
{
  short		err;
  EventType event;

  do
	{
	  EvtGetEvent (&event, sysTicksPerSecond/4);


	  if (!SysHandleEvent (&event))

		if (!MenuHandleEvent (0, &event, &err))

		  if (!AppHandleEvent (&event))
			  
			FrmDispatchEvent (&event);


	} while(event.eType != appStopEvent);
}




/***************************************************************
 *	Function:	  PilotMainBody
 *
 *	Summary:	  The processing for PilotMain 
 *
 *	Parameters:
 *
 *	Returns:
 *	  0 if no error
 *	
 *	Called By: 
 *	  CardSetup application to hook back into this application
 *	
 *	Notes:
 *	
 *	
 *	History:
 *	  07-July-2000	FV  Created
 *
 ****************************************************************/
DWord  
PilotMainBody ( void )
{
  DWord err = 0;

	err = AppStart();			// Application start code
	if (err) return err;

	AppEventLoop();				// Event loop

	AppStop ();					// Application stop code

  return err;
}



//typedef DWord AppEntryPointType (Word cmd, Ptr cmdPBP, Word launchFlags);
typedef DWord AppEntryPointType ( void );

typedef DWord AppLaunchProcType (Word cmd, Ptr cmdPBP, Word launchFlags, AppEntryPointType * procP);


/***********************************************************************
 *
 * Function:    LaunchProcedure
 *
 * Summary: This routine is copied into RAM by the application 
 *              so that is can clean-up after the application if the 
 *              module is removed while the application is 
 *              running.
 *
 * Parameters:  cmd           IN  launch command
 *              cmdPBP        IN  parameter block
 *              launchFlags   IN  flags
 *              procP		  IN  app routine in rom
 *
 * Returns:    result code
 *
 * History:
 *	07-July-2000  FV  Created
 *
 *
 ***********************************************************************/
DWord LaunchProcedure (Word cmd, Ptr cmdPBP, Word launchFlags, AppEntryPointType * procP)
{
	Err	err = 0;


  HsCardErrTry
	  {
	  // Call back into the specified application routine.  We will not 
	  // return from this function until the application exist, or until
	  // the catch statement below is call as a result of the module being
	  // removed from the device.
	  // error = procP (cmd, cmdPBP, launchFlags);
	  procP ();
	  }

  HsCardErrCatch
	  {

	  HsDrcGlobalsType*	  gP = 0;
	  Word	cardNo = 1;

	  HsCardAttrGet (cardNo, hsCardAttrCardParam, &gP);

	  // Close the library
	  // Check if the serial library has been un-installed or closed.  
	  if (gP && gP->serLibRefNum)							  // not un-installed
		if ((SysLibTblEntry (gP->serLibRefNum))->globalsP)	  // not closed
		  err = SerClose (gP->serLibRefNum);

	  } HsCardErrEnd

  return (err);
}


/***********************************************************************
 *
 * FUNCTION:    InstallLaunchProcedure
 *
 * DESCRIPTION: This routine installs a launch procedure into RAM the will
 *              call back into an entry point in the application.  This 
 *              is done so that control can be returned the launch 
 *              procedure when the Springboard support detects that the 
 *              module was been removed.  Since the procedure
 *              is in RAM the Springboard removal logic can call it even 
 *              though the rest of the application is gone.  This allows
 *              that application to shut-down in an orderly manner.
 *
 *
 * PARAMETERS:  cmd           IN  launch command
 *              cmdPBP        IN  parameter block
 *              launchFlags   IN  flags
 *
 * RETURNED:    result code
 *
 * REVISION HISTORY:
 *			Name	Date		Description
 *			----	----		-----------
 *			art		4/3/00		Initial Revision
 *
 ***********************************************************************/
DWord InstallLaunchProcedure (Word cmd, Ptr cmdPBP, Word launchFlags)
{
	static Ptr p1;
	static Ptr p2;

	DWord result;
	DWord size;
	AppLaunchProcType * ptr;  

	// Allocate a block large enough to hold the above procedure.
	p1 = (Ptr) LaunchProcedure;
	p2 = (Ptr) InstallLaunchProcedure;
	size = (UInt32)p2 - (UInt32)p1; 
	
	ptr = MemPtrNew (size);
	if (! ptr)
		return (memErrNotEnoughSpace);

	// Copy the routine into RAM and call it.
	MemMove (ptr, LaunchProcedure, size);

	result = ptr (cmd, cmdPBP, launchFlags, PilotMainBody);

	MemPtrFree (ptr);

	return (result);
}





DWord  
PilotMain (Word cmd, Ptr cmdPBP, Word launchFlags)
{
  DWord err;

  Word			  AppDbCardNo;
  LocalID		  AppDbID;
  Boolean ModulePresent = false;


  if (cmd == sysAppLaunchCmdNormalLaunch)
	{

	// Get the current application information, used to get UI resources
	SysCurAppDatabase(&AppDbCardNo, &AppDbID);

	if ( AppDbCardNo == 1 )				// Running from Srpingboard
	  {

#if DYNAMIC_PATCH_SOFT_RESET_PROTECTION 
// New technique for open library soft reset proctection by 
// installing patches in dynamic memory chunk

	err = InstallLaunchProcedure (cmd, cmdPBP, launchFlags);

#elif STATIC_PATCH_SOFT_RESET_PROTECTION 
// Old technique for open library soft reset proctection by 
// hooking patches in in static code

  HsDrcGlobalsType*	  gP = 0;
  PilotMainHookFuncType * AppPilotMainHook;
	
	  // Get globals pointer as the card param
	  err = HsCardAttrGet (AppDbCardNo, hsCardAttrCardParam, &gP);
	  AppPilotMainHook = gP->AppPilotMainHook;
	  
	  // Call the hook in the CardSetup app
	  AppPilotMainHook( PilotMainBody, (void *) gP );

#endif

	  }
	else if ( AppDbCardNo == 0)		// Running from Visor memory
	  {

	  // Check if module is inserted before installing SysHandleEvent patch
	  // that detects module removal
	  HsCardAttrGet(1, hsCardAttrHwInstalled, &ModulePresent);
	  
	  // Running from Visor memory.  Skip the hook and call the 
	  // PilotMainBody() directly
	  PilotMainBody( );

	  }

	}


  return 0;
}

