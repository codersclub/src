//**************************************************************
//
//  Project:
//	  Handspring simple serial terminal application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  HandTerminalRsc.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
//
// History:
//	  26-Feb-1999  RM  Created 
//***************************************************************/


// Main Form
#define resFormIDMain				1000
#define	resMainTextFldID			1002
#define	resMainScrollerID			1003
									

// Main Form menu
#define resMenuIDMain				1000
#define resMenuItemComm				1001
#define resMenuItemStatus			1002
#define resMenuItemAbout			1003

// About Alert
#define resAlertIDAbout				1000
									


// Communication Prefs form
#define	resFormIDComm				1100

#define	resCommPortLabelID			1101
#define	resCommPortTriggerID		1102
#define	resCommPortListID			1103

#define	resCommBaudLabelID			1104
#define	resCommBaudTriggerID		1105
#define	resCommBaudListID			1106

#define	resCommHshkLabelID			1107
#define	resCommHshkTriggerID		1108
#define	resCommHshkListID			1109

#define	resCommParityLabelID		1110
#define	resCommParityTriggerID		1111
#define	resCommParityListID			1112

#define	resCommStopLabelID			1113
#define	resCommStopTriggerID		1114
#define	resCommStopListID			1115

#define	resCommDataLabelID			1116
#define	resCommDataTriggerID		1117
#define	resCommDataListID			1118

#define	resCommOKBtnID				1119
#define	resCommCancelBtnID			1120
