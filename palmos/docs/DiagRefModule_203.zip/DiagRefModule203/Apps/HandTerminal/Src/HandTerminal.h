//**************************************************************
//
//  Project:
//	  Handspring simple serial terminal application
//
// Copyright info:
//
//	  This is free software; you can redistribute it and/or modify
//	  it as you like.
//
//	  This program is distributed in the hope that it will be useful,
//	  but WITHOUT ANY WARRANTY; without even the implied warranty of
//	  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  
//
//
//  FileName:
//	  HandTerminal.h
// 
//  Description:
//	  Equates shared in common with Palm-RC resource compiler
//	and C compiler. 
//
// History:
//	  26-Feb-1999  RM  Created 
//***************************************************************/


// Include resource equates
#include "HandTerminalRsc.h"


// Our Creator and prefs version
#define	appCreator					'HTrm'
#define	appVersion					1

