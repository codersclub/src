#include "dsocket.h"

#define _dSockThreadState DGetModuleThreadState()
#define _D_SOCK_THREAD_STATE D_MODULE_THREAD_STATE

DSocket::DSocket()
{
	m_hSocket = INVALID_SOCKET;
}

DSocket::~DSocket()
{
	if (m_hSocket != INVALID_SOCKET)
		Close();
}

void DSocket::Close()
{
	if (m_hSocket != INVALID_SOCKET)
	{
//		VERIFY(SOCKET_ERROR != closesocket(m_hSocket));
		DSocket::KillSocket(m_hSocket, this);
		m_hSocket = INVALID_SOCKET;
	}
}

void PASCAL DSocket::KillSocket(SOCKET hSocket, DSocket* pSocket)
{
	_D_SOCK_THREAD_STATE* pState = _dSockThreadState;

	DSocket::DetachHandle(hSocket, FALSE);
	if (pState->m_hSocketWindow != NULL)
	{
		::PostMessage(pState->m_hSocketWindow, WM_SOCKET_DEAD,
			(WPARAM)hSocket, 0L);
		DSocket::AttachHandle(hSocket, pSocket, TRUE);
	}
}
