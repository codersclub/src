#include <windows.h>

class DSocket
{
public:
	DSocket();

public:
	SOCKET m_hSocket;

public:
	virtual void Close();

public:
	virtual ~DSocket();
	static void PASCAL KillSocket(SOCKET hSocket, DSocket* pSocket);
};
