#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>
#include <winsock.h>
#include "dstring.h"
#include "resrc1.h"

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DialogRecv(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DialogSend(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK MainDialog(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK DialogHistory(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
BOOL WndProc_OnCreate(HWND hWnd, LPCREATESTRUCT lpCreateStruct);
void WndProc_OnWSANetEvent(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);
void MainDlg_OnSize(HWND hWnd, UINT state, int cx, int cy);
void ConnectSMTPServerSocket(void);
void TimerMessage(HWND hWnd, DWORD dwMessage);
void AddStatusIcon(HWND hWnd, DWORD dwMessage);
void CALLBACK MainTimerMessage(HWND hWnd, UINT Msg, UINT idEvent, DWORD dwTime);
BOOL CreateListenSocket(void);
BOOL CreateOutgoingSocket(void);
void HandlePopupMenu (HWND hwnd, POINT point);
int SendClientMessage(int nPort, const char *szAddr, const char *svMessage);
int SendId(int nPort, const char *szAddr, const char *svUser);
int UDP_Recv(BYTE **pInData, int *pnInDataLen);
int UDP_Send(BYTE *pData, int nDataLen, int nPort, const char *szAddr);
void UDP_Free(BYTE *pBuffer);
void DrawLBItem(LPDRAWITEMSTRUCT lpdis);
HBITMAP ShrinkBitmap ( HWND hWnd, HBITMAP hbm);

#define SMTP_PORT 25
#define SMTP_ADDR "128.1.1.1"
#define WSA_NETEVENT (WM_USER + 1)
#define WM_NOTIFYICONMSG (WM_USER + 2)
#define DIA_MESSAGE      21
#define DIA_USER         31
#define DIA_USERBASE     32
#define DIA_USERDENIED   33
#define DIA_TERMINATE    41
#define DIA_MOUSE        42
#define DIA_KEYBOARD     43
#define MYLBSTYLE   WS_CHILD|WS_BORDER |LBS_SORT| \
                    WS_VSCROLL | LBS_NOINTEGRALHEIGHT

HINSTANCE hInst;
HWND hWndDialog;
HWND hWndMainDialog;
HWND hLboxWnd;
HWND hLBwnd;
HWND hListViewWnd;
HANDLE IconMail;
HBRUSH hbrushMenu;
SOCKET s;
SOCKET SendSocket;

UINT g_uState;
int  iNumIcon;
BOOL m_bUserAccess;			// ����� �� ������������ ������������ ������
BOOL m_bEpsent;				// ����������� �� �������
BOOL m_bMainClose;			// ������������� �� ������� ������� ����
BOOL m_bMainState;			// ����� �� ������ �����������
BOOL m_bMainVisible;		// ������ ��� ��� ������� ���� �����������
BOOL m_bState;				// ���� ��� ��� ��������� ���������
BOOL m_bReply;				// � ����� ���� ���������� ������ �����(�������� ��� ����)
BOOL m_bStateReply;			// ����� �� ������ ��������� ���������
BOOL m_bAlarm;				// ����� ���������
UINT m_uTimer;				// ������ �� �������� ������
UINT m_uMainTimer;			// ������ �� ���������� ���� ������ � �������
DString UserBase;			// ������ ������������� � ������� � ����������� 
DString MessBase;			// ��������� ��������� � ��������� ��������
DString MessHistory;		// ����� ��������� � ������������ ���������
DString AddrReplyToServer;	// �������� �������
DString AddrReplyToClient;	// �������� ���������� ��������� �� ������� ������������
DString AddrClientToSend;	// ����� ������������� ���������
DString NameClientToSend;	// ��� ������������, �������� ������������ ���������
DString szUserToReply;		// ��� ������������, ����������� ���������
DString szBufMess;			// ����� ���������� ���������
char svUserName[256];
DWORD dwBufSize=256;
char LBUserBase[256];

typedef struct {
	DWORD dwFlags;
} UDPHDR;

typedef struct {
	BYTE bAction;
	union {
		struct {
			WORD wPosX;
			WORD wPosY;
		} mouse;
		struct {
			BYTE bVirtKey;
			BYTE bScanCode;
			DWORD dwKeyFlags;
		} keybd;
		struct {
			BYTE bUserNameLen;
			DWORD dwDataLen;
		} message;
	};
} DIA_HEADER;
/*
typedef struct _LV_COLUMN
{
    UINT mask;
    int fmt;
    int cx;
    LPSTR pszText;
    int cchTextMax;
    int iSubItem;
} LV_COLUMN;

typedef struct _LV_ITEMA
{
    UINT mask;
    int iItem;
    int iSubItem;
    UINT state;
    UINT stateMask;
    LPSTR pszText;
    int cchTextMax;
    int iImage;
    LPARAM lParam;
} LV_ITEM;
*/
int APIENTRY WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow)
{
	MSG msg;
	HWND hWnd;
	WNDCLASSEX wndclass;

	hInst = hInstance;

	wndclass.style = 0;
	wndclass.lpfnWndProc = (WNDPROC)WndProc;
	wndclass.cbClsExtra = 0;
	wndclass.cbWndExtra = 0;
	wndclass.hInstance = hInst;
	wndclass.hIcon = NULL;
	wndclass.hCursor = NULL;
	wndclass.hbrBackground = NULL;
	wndclass.lpszMenuName = NULL;
	wndclass.lpszClassName = "WSCLAS";
	
	if(!RegisterClassEx(&wndclass))
		if(!RegisterClass((LPWNDCLASS)&wndclass.style))  return FALSE;

	hWnd=CreateWindow("WSCLAS", "", 0, 0, 0, 1, 1, HWND_DESKTOP, NULL, hInst, NULL);

	hWndDialog=hWnd;

	m_bMainState = FALSE;
	m_bMainVisible = FALSE;
	m_bState = FALSE;
	m_bStateReply = TRUE;
	m_bEpsent = FALSE;
	m_bUserAccess = FALSE;
	m_bAlarm = FALSE;

	IconMail = LoadImage(hInst,MAKEINTRESOURCE(IDI_ICON6),IMAGE_ICON,
			20,16,LR_DEFAULTCOLOR);
	hbrushMenu = CreateSolidBrush(GetSysColor(COLOR_MENU));
	iNumIcon = 5;
	GetUserName(svUserName,&dwBufSize);

	SendId(5002, "128.1.1.11", svUserName);

	m_uMainTimer = SetTimer(hWnd, 2, 11000, TIMERPROC(MainTimerMessage));

	int vk = 0x45;	// ������� "�" ���������
	RegisterHotKey(hWnd,1000+(MOD_ALT*0x100)+vk,MOD_ALT,vk);	// ������������ ALT-E ��� ������� �������

	while(GetMessage(&msg, NULL, 0, 0))  {
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}
	DeleteObject(hbrushMenu);
	UnregisterHotKey(hWnd,1000+(MOD_ALT*0x100)+vk);
	return msg.wParam;
}

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	LPCTSTR pszIDMess;
	POINT pt;

	switch(msg)  {
		case WSA_NETEVENT:
			WndProc_OnWSANetEvent(hWnd, msg, wParam, lParam);
			break;

		case WM_TIMER:
			if(m_bEpsent == FALSE)  {
				g_uState = !g_uState;
				TimerMessage(hWnd, NIM_MODIFY);
			}
			break;

		case WM_HOTKEY:
			if(m_bUserAccess == TRUE)  {
				if(m_bEpsent == FALSE&&m_bMainState==TRUE)  {
					m_bEpsent=TRUE;
					m_bMainState=FALSE;
					TimerMessage(hWnd, NIM_DELETE);
				} else  {
					m_bEpsent = FALSE;
					if(m_bMainState==FALSE&&m_bMainClose==FALSE&&m_bEpsent==FALSE)  {
						m_bMainState = TRUE;
						AddStatusIcon(hWnd, NIM_ADD);
					}
				}
			}
			break;

        case WM_COMMAND:
            switch (LOWORD(wParam))  {
				case ID_EXIT_DIASOFT:
					m_bMainClose = TRUE;				// ������� ������ ������ �������������
					m_bMainState = FALSE;				// ������� ������ �� �����
					m_bMainVisible = FALSE;				// ������� ������ �� �����
					m_bAlarm = FALSE;
					KillTimer(hWnd,	m_uTimer);
					TimerMessage(hWnd, NIM_DELETE);		// ������� ������� ������
					EndDialog(hWndMainDialog, 0);		// ������� ������� ������
					szBufMess = "";
					break;

				case ID_OPEN_DIASOFT:
					if(m_bMainVisible==FALSE)  {
						m_bMainClose=FALSE;
						m_bMainState=TRUE;
						m_bMainVisible=TRUE;
						pszIDMess = MAKEINTRESOURCE(IDD_MAINDIALOG);
						DialogBoxParam(hInst, pszIDMess, hWnd, DLGPROC(MainDialog), 0);
					}
					break;

				case ID_CHEIF_DIASOFT:
					m_bEpsent=TRUE;
					m_bMainState=FALSE;
					m_bAlarm=TRUE;
					iNumIcon=8;
					TimerMessage(hWnd, NIM_DELETE);
					break;

				case ID_NODIST_DIASOFT:
					m_bAlarm=FALSE;
					break;

				case ID_ABSENT_DIASOFT:
					m_bEpsent=TRUE;
					m_bMainState=FALSE;
					m_bAlarm=FALSE;
					iNumIcon=7;
					TimerMessage(hWnd, NIM_DELETE);
					break;

				case ID_NORMAL_DIASOFT:
					m_bAlarm=FALSE;
					iNumIcon=5;
					AddStatusIcon(hWnd, NIM_MODIFY);
					break;
			}
			break;

		case WM_NOTIFYICONMSG:
			switch(lParam)  {
				case WM_LBUTTONDBLCLK:
					if(m_bMainState==FALSE&&m_bState==TRUE&&m_bStateReply==TRUE)  {
						TimerMessage(hWnd, NIM_DELETE);
						pszIDMess = MAKEINTRESOURCE(IDD_INCOMMESSAGE);
						DialogBoxParam(hInst, pszIDMess, hWnd, DLGPROC(DialogRecv), 0);
						if(MessBase.GetDString()=="")  m_bState = FALSE;
					}
					else if(m_bMainState==TRUE&&m_bState==TRUE&&m_bStateReply==TRUE)  {
						AddStatusIcon(hWnd, NIM_MODIFY);
						pszIDMess = MAKEINTRESOURCE(IDD_INCOMMESSAGE);
						DialogBoxParam(hInst, pszIDMess, hWnd, DLGPROC(DialogRecv), 0);
					}
					else if(m_bState==FALSE&&m_bMainVisible==FALSE)  {
						pszIDMess = MAKEINTRESOURCE(IDD_MAINDIALOG);
						DialogBoxParam(hInst, pszIDMess, hWnd, DLGPROC(MainDialog), 0);
					}
					break;

				case WM_RBUTTONDOWN:
					GetCursorPos(&pt);
					HandlePopupMenu (hWnd, pt);
					break;

				default:
					break;
			}
			break;

		HANDLE_MSG(hWnd, WM_CREATE, WndProc_OnCreate);

		default:
			return(DefWindowProc(hWnd, msg, wParam, lParam));
	}
	return 0;
}

BOOL CALLBACK DialogRecv(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	DString NameRecv, IpRecv, MessRecv, Temp;
	int ndx1, ndx2;

	switch(msg)  {
		case WM_INITDIALOG:
			m_bReply = FALSE;
			m_bStateReply = FALSE;
			if((ndx1 = MessBase.Find(",:2"))!=-1)  {
				NameRecv = "��������� �� ";
				Temp = MessBase.Mid(2);
				Temp = Temp.Left(ndx1-2);
				NameRecv += Temp;
				MessBase = MessBase.Mid(2);
			}
			SendMessage(hDlg, WM_SETTEXT, 0, (LPARAM) NameRecv.GetDString());
			if((ndx1 = MessBase.Find(",:3"))!=-1)  {
				MessRecv = MessBase.Mid(ndx1+3);
				if((ndx2 = MessRecv.Find("_:"))!=-1)  MessRecv = MessRecv.Left(ndx2);
			}
			SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), WM_SETTEXT, 0, (LPARAM)MessRecv.GetDString());
			SendMessage(GetDlgItem(hDlg, IDC_BUTTON_REPLY), WM_SETFOCUS, 0, 0);
			EnableWindow(GetDlgItem(hDlg, IDC_BUTTON_OK), FALSE);
			if(MessBase.Find("_:")==-1)  {
				m_bState = FALSE;
				KillTimer(hWndDialog, m_uTimer);
			}
			return(TRUE);
			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))  {
				case IDC_BUTTON_OK:
					if(m_bReply == TRUE)  {
						DString SendBuf;
						char SendBuf1[256];
//						DWORD dwBufSize=256;

						if((ndx1 = MessBase.Find(",:2"))!=-1)  {
							NameClientToSend = MessBase.Left(ndx1);
							IpRecv = MessBase.Mid(ndx1+3);
							if((ndx2 = IpRecv.Find(",:3"))!=-1)  IpRecv = IpRecv.Left(ndx2);
						}
						if((ndx1 = MessBase.Find("_:"))!=-1)  {
							MessBase = MessBase.Mid(ndx1);
							m_bState = TRUE;
						}
						else  {
							MessBase = "";
							m_bState = FALSE;
						}
						m_bStateReply = TRUE;
//						GetUserName(svUserName,&dwBufSize);
						SendBuf = svUserName;
						MessHistory += "_:";
						MessHistory += svUserName;
						MessHistory += ",:2";
						MessHistory += NameClientToSend;
						MessHistory += ",:3";
						GetDlgItemText(hDlg, IDC_EDIT_MSG, SendBuf1, sizeof(SendBuf1));
						SendBuf += SendBuf1;
						MessHistory += SendBuf1;
						SendClientMessage(5001, IpRecv.GetDString(), SendBuf.GetDString());
					}
					EndDialog(hDlg, 0);
					m_bReply = FALSE;
					break;

				case IDC_BUTTON_REPLY:
					m_bReply = TRUE;
					SendMessage(hDlg, WM_SETTEXT, 0, (LPARAM) "�������� ���������");
					SendMessage(GetDlgItem(hDlg, IDC_BUTTON_OK), WM_SETTEXT, 0, (LPARAM) "���������");
					SendMessage(GetDlgItem(hDlg, IDC_BUTTON_REPLY), WM_KILLFOCUS, 0, 0);
					SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), EM_SETREADONLY, FALSE, 0);
					SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), WM_SETTEXT, 0, (LPARAM) "");
					EnableWindow(GetDlgItem(hDlg, IDC_BUTTON_REPLY), FALSE);
					EnableWindow(GetDlgItem(hDlg, IDC_BUTTON_OK), TRUE);
					break;

				case IDC_BUTTON_CANCEL:
					if((ndx1 = MessBase.Find("_:"))!=-1)  {
						MessBase = MessBase.Mid(ndx1);
						m_bState = TRUE;
					}
					else  {
						MessBase = "";
						m_bState = FALSE;
					}
					m_bStateReply = TRUE;
					EndDialog(hDlg, 0);
					break;

				case IDC_BUTTON_HISTORY:
					DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_HISTORY), hWndDialog, DLGPROC(DialogHistory), 0);
					break;

				default:
					break;
			}
			break;

		case WM_KILLFOCUS:
			SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), WM_SETFOCUS, 0, 0);
			break;

		case WM_CLOSE:
			if((ndx1 = MessBase.Find("_:"))!=-1)  {
				MessBase = MessBase.Mid(ndx1);
				m_bState = TRUE;
			}
			else  {
				MessBase = "";
				m_bState = FALSE;
			}
			m_bStateReply = TRUE;
			EndDialog(hDlg, 0);
			break;
	}
	return(FALSE);
}

BOOL CALLBACK DialogSend(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	char SendBuf1[256];
//	char svUserName[256];
//	DWORD dwBufSize=256;
	DString SendBuf;

	switch(msg)  {
		case WM_INITDIALOG:
			m_bReply = TRUE;
			SendMessage(hDlg, WM_SETTEXT, 0, (LPARAM) "�������� ���������");
			SendMessage(GetDlgItem(hDlg, IDC_BUTTON_OK), WM_SETTEXT, 0, (LPARAM) "���������");
			SendMessage(GetDlgItem(hDlg, IDC_BUTTON_REPLY), WM_KILLFOCUS, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), EM_SETREADONLY, FALSE, 0);
			SendMessage(GetDlgItem(hDlg, IDC_EDIT_MSG), WM_SETTEXT, 0, (LPARAM) "");
			EnableWindow(GetDlgItem(hDlg, IDC_BUTTON_REPLY), FALSE);
			return(TRUE);
			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))  {
				case IDC_BUTTON_OK:
					m_bStateReply = TRUE;
//					GetUserName(svUserName,&dwBufSize);
					SendBuf = svUserName;
					MessHistory += "_:";
					MessHistory += svUserName;
					MessHistory += ",:2";
					MessHistory += NameClientToSend;
					MessHistory += ",:3";
					GetDlgItemText(hDlg, IDC_EDIT_MSG, SendBuf1, sizeof(SendBuf1));
					SendBuf += SendBuf1;
					MessHistory += SendBuf1;
					SendClientMessage(5001, AddrClientToSend.GetDString(), SendBuf.GetDString());
					EndDialog(hDlg, 0);
					m_bReply = FALSE;
					break;

				case IDC_BUTTON_CANCEL:
					m_bStateReply = TRUE;
					EndDialog(hDlg, 0);
					break;

				case IDC_BUTTON_HISTORY:
					DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_HISTORY), hWndDialog, DLGPROC(DialogHistory), 0);
					break;
			}
			break;

		case WM_CLOSE:
			m_bStateReply = TRUE;
			EndDialog(hDlg, 0);
			break;

		default:
			break;
	}
	return(FALSE);
}

BOOL CALLBACK MainDialog(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	DString TempUserBase1, TempUserBase2, TempUser;
	LPTSTR psz;
	int  ndx1, ndx2, cx, i;
	RECT rc;

	TempUserBase1 = UserBase;

	switch(msg)  {
		case WM_INITDIALOG:
			hWndMainDialog = hDlg;
			hLboxWnd = GetDlgItem(hDlg,IDC_LIST1);
			cx = GetSystemMetrics(SM_CXSCREEN);
			cx = cx - 125;
			MoveWindow( hDlg, cx, 4, 115, 230, TRUE);
			i = 0;
			cx = 0;
			memset(LBUserBase,'\0',256);
			do  {
				if((ndx1 = TempUserBase1.Find("_:"))!=-1)  {
					TempUserBase1 = TempUserBase1.Mid(ndx1+2);
					ndx2 = TempUserBase1.Find(",:3");
					TempUser = TempUserBase1.Left(ndx2);

					if(i==0)  strcpy(LBUserBase+1, TempUser.GetDString());
					else  strcat(LBUserBase+cx+1, TempUser.GetDString());
					SendMessage(hLboxWnd,LB_ADDSTRING,0,(LPARAM)(LPCSTR)LBUserBase+cx+1);
					cx = cx+1+strlen(TempUser.GetDString());
					i++;
					TempUserBase1 = TempUserBase1.Mid(ndx2+3);
				}
			} while(ndx1!=-1);
			m_bMainVisible = TRUE;
			return(TRUE);
			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))  {
				case IDC_LIST1:
					if(HIWORD(wParam)==LBN_DBLCLK&&m_bStateReply==TRUE)  {
						psz = (LPTSTR)SendMessage(GetDlgItem(hDlg,IDC_LIST1), LB_GETITEMDATA, SendMessage(GetDlgItem(hDlg,IDC_LIST1), LB_GETCURSEL,0,0), (LPARAM)0);
						NameClientToSend = psz;
						if((ndx1 = TempUserBase1.Find(NameClientToSend.GetDString()))!=-1)  {
							TempUserBase2 = TempUserBase1.Mid(ndx1);
							if((ndx2 = TempUserBase2.Find(",:3"))!=-1)  {
								TempUserBase1 = TempUserBase2.Mid(ndx2+3);
								if((ndx1 = TempUserBase1.Find("_:"))!=-1)  AddrClientToSend = TempUserBase1.Left(ndx1);
								else  AddrClientToSend = TempUserBase1;
							}
						}
						m_bStateReply = FALSE;
						DialogBoxParam(hInst, MAKEINTRESOURCE(IDD_INCOMMESSAGE), hWndDialog, DLGPROC(DialogSend), 0);
					}
			}
			break;

		case WM_PAINT:
			i = SendMessage(hLboxWnd, LB_GETCOUNT, 0, 0);
			if(i==0)  {
				GetClientRect(hLboxWnd, &rc);
				FillRect(GetDC(hLboxWnd), &rc, hbrushMenu);
			}
			break;

		case WM_DRAWITEM:
	        GetClientRect(hLboxWnd, &rc);
			((LPDRAWITEMSTRUCT)lParam)->rcItem.right = rc.right;
		    DrawLBItem((LPDRAWITEMSTRUCT)lParam);

			i = SendMessage(hLboxWnd, LB_GETCOUNT, 0, 0);
			i = i * 16;
			GetClientRect(hLboxWnd, &rc);
			if(rc.top<i)  {
				rc.top = rc.top + i;
				FillRect(GetDC(hLboxWnd), &rc, hbrushMenu);
			}
			return(DefWindowProc(hDlg, msg, wParam, lParam));
			break;

		HANDLE_MSG(hDlg, WM_SIZE, MainDlg_OnSize);

		case WM_CLOSE:
			m_bMainClose = TRUE;
			m_bMainState = FALSE;
			m_bMainVisible = FALSE;
			if(m_bState == FALSE)  TimerMessage(hWndDialog, NIM_DELETE);
			EndDialog(hDlg, 0);
			break;
	}
	return(FALSE);
}

BOOL CALLBACK DialogHistory(HWND hDlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
//	LV_COLUMN lvc;
//	LV_ITEM lvi;

	switch(msg)  {
		case WM_INITDIALOG:
/*			hListViewWnd = GetDlgItem(hDlg,IDC_HISTORY_LIST);
			memset(&lvc, 0, sizeof(lvc));
			lvc.mask = LVCF_FMT | LVCF_WIDTH | LVCF_TEXT | LVCF_SUBITEM;
			lvc.fmt = LVCFMT_LEFT;
			lvc.cx = 40;
			lvc.iSubItem = 0;
			if(ListView_InsertColumn(hListViewWnd, 0, &lvc)==-1)  {
				MessageBox(NULL, "0 !!!", "Error", MB_OK|MB_SETFOREGROUND);
			}
			ListView_SetColumnWidth(hListViewWnd, 0, 20);
			lvc.iSubItem = 1;
			if(ListView_InsertColumn(hListViewWnd, 1, &lvc)==-1)  {
				MessageBox(NULL, "1 !!!", "Error", MB_OK|MB_SETFOREGROUND);
			}
			ListView_SetColumnWidth(hListViewWnd, 1, 20);
			memset(&lvi, 0, sizeof(lvi));
			lvi.mask = LVIF_TEXT | LVIF_PARAM;
			lvi.iItem = 0;							// ������ 0
			lvi.iSubItem = 0;
			lvi.cchTextMax = 40;
			lvi.pszText = LPSTR_TEXTCALLBACK;
			lvi.lParam = (LPARAM)"������";
			ListView_InsertItem(hListViewWnd, &lvi);
			lvi.iItem = 0;							// ������ 0
			lvi.iSubItem = 1;
			ListView_InsertItem(hListViewWnd, &lvi);
			lvi.iItem = 1;							// ������ 1
			lvi.iSubItem = 0;
			ListView_InsertItem(hListViewWnd, &lvi);
			lvi.iItem = 1;							// ������ 2
			lvi.iSubItem = 1;
			ListView_InsertItem(hListViewWnd, &lvi);   */
			SendMessage(GetDlgItem(hDlg, IDC_HISTORY_EDIT), WM_SETTEXT, 0, (LPARAM)MessHistory.GetDString());

//			DString Test1, Test2;
//			Test1 = Test2[3];
			return(TRUE);
			break;

		case WM_COMMAND:
			switch(LOWORD(wParam))  {
				case IDC_HISTORY_OK:
					EndDialog(hDlg, 0);
				break;
			}
			break;

		case WM_CLOSE:
			EndDialog(hDlg, 0);
			break;
	}
	return(FALSE);
}

BOOL WndProc_OnCreate(HWND hWnd, LPCREATESTRUCT lpCreateStruct)
{
	int rc;
	WSADATA WSAData;

	rc = WSAStartup(MAKEWORD(1, 1), &WSAData);
	if(rc != 0)  return FALSE;

	CreateListenSocket();
	CreateOutgoingSocket();
//	ConnectSMTPServerSocket();

	rc = WSAAsyncSelect(s, hWnd, WSA_NETEVENT, FD_READ);
	if(rc > 0)  {
		closesocket(s);
		return FALSE;
	}

	return TRUE;
}

BOOL CreateListenSocket(void)
{
	struct sockaddr_in srv_address;
	int namelen;
	int nPort;

	nPort=atoi("5001");

	s = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(s != INVALID_SOCKET)  {
		memset(&srv_address,0,sizeof(SOCKADDR_IN));
		srv_address.sin_addr.S_un.S_addr=INADDR_ANY;
		srv_address.sin_family = AF_INET;
		srv_address.sin_port = htons((WORD)nPort);
	}
	if(bind(s, (SOCKADDR *) &srv_address, sizeof(SOCKADDR_IN)) == SOCKET_ERROR)  {
		closesocket(s);
		return FALSE;
	} else  {
		namelen=sizeof(SOCKADDR_IN);
		getsockname(s,(SOCKADDR *)&srv_address,&namelen);
		return TRUE;
	}
}

BOOL CreateOutgoingSocket(void)
{
	struct sockaddr_in srv_address;
	int namelen;

	SendSocket = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
	if(SendSocket != INVALID_SOCKET)  {
		memset(&srv_address,0,sizeof(SOCKADDR_IN));
		srv_address.sin_addr.S_un.S_addr=INADDR_ANY;
		srv_address.sin_family = AF_INET;
		srv_address.sin_port = 0;
	}
	if(bind(SendSocket, (SOCKADDR *) &srv_address, sizeof(SOCKADDR_IN)) == SOCKET_ERROR)  {
		closesocket(s);
		return FALSE;
	} else  {
		namelen=sizeof(SOCKADDR_IN);
		getsockname(s,(SOCKADDR *)&srv_address,&namelen);
		return TRUE;
	}
}

void WndProc_OnWSANetEvent(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
{
	DIA_HEADER *pHeader;
	DString RecBuf;
	int nRet,nSize;

	if(WSAGETSELECTEVENT(lParam) == FD_READ)  {
		if((nRet=UDP_Recv((BYTE **)&pHeader,&nSize))>0)  {
			if(nSize<sizeof(DIA_HEADER)) {
				UDP_Free((BYTE*)pHeader);
				return;
			}
			if(pHeader->bAction==DIA_USERBASE) {
				BYTE *pData=(BYTE *)malloc(pHeader->message.dwDataLen);
				if(pData==NULL) {
					UDP_Free((BYTE*)pHeader);
					return;
				}
				memcpy(pData,(BYTE *)pHeader+sizeof(DIA_HEADER),nSize);
				UserBase = (LPCSTR)pData;
				m_bUserAccess = TRUE;
				if(m_bMainState==FALSE&&m_bMainClose==FALSE&&m_bEpsent==FALSE)  {
					m_bMainState = TRUE;
					AddStatusIcon(hWnd, NIM_ADD);
				}
				free(pData);
			}
			if(pHeader->bAction==DIA_USERDENIED) {
				BYTE *pData=(BYTE *)malloc(pHeader->message.dwDataLen);
				if(pData==NULL) {
					UDP_Free((BYTE*)pHeader);
					return;
				}
				memcpy(pData,(BYTE *)pHeader+sizeof(DIA_HEADER),nSize);
				UserBase = (LPCSTR)pData;
				m_bUserAccess = FALSE;
				if(m_bMainState==TRUE)  {
					TimerMessage(hWnd, NIM_DELETE);
					m_bMainState = FALSE;
				}
				free(pData);
			}
			if(pHeader->bAction==DIA_MESSAGE) {
				m_bState = TRUE;
				AddrReplyToClient = AddrReplyToServer;
				BYTE *pData=(BYTE *)malloc(pHeader->message.dwDataLen);
				if(pData==NULL) {
					UDP_Free((BYTE*)pHeader);
					return;
				}
				memcpy(pData,(BYTE *)pHeader+sizeof(DIA_HEADER),nSize);
				szBufMess = (LPCSTR)pData;
				MessBase += "_:";
				MessBase += szBufMess.Left(pHeader->message.bUserNameLen);
				MessBase += ",:2";
				MessBase += AddrReplyToClient;
				MessBase += ",:3";
				MessBase += szBufMess.Mid(pHeader->message.bUserNameLen);
				MessHistory += "_:";
				MessHistory += szBufMess.Left(pHeader->message.bUserNameLen);
				MessHistory += ",:2";
				MessHistory += svUserName;
				MessHistory += ",:3";
				MessHistory += szBufMess.Mid(pHeader->message.bUserNameLen);
				if(m_bMainState==FALSE&&m_bEpsent==FALSE)  TimerMessage(hWnd, NIM_ADD);
				m_uTimer = SetTimer(hWnd, 1, 500, NULL);
				free(pData);
				if(m_bAlarm==TRUE)  {
//					char svUserName[256];
//					DWORD dwBufSize=256;
					DString SendAlarm;

//					GetUserName(svUserName,&dwBufSize);
					SendAlarm = svUserName;
					SendAlarm += "����-�� ���������� ����� ����������, ������� ������ �����....";
					SendClientMessage(5001, AddrReplyToClient.GetDString(), SendAlarm.GetDString());
				}
			}
			UDP_Free((BYTE *)pHeader);
		}
/*			if(szTemp[0]=='4')  {
				if(szTemp[1]=='1')  {			//��������� "41" - ��������� ������
					WSACleanup();
					PostQuitMessage(0);
					FORWARD_WM_DESTROY(hWnd, DefWindowProc);
					return;
				}
				else if(szTemp[1]=='2')  {		//��������� "42" - ��������� �����
					POINT pt;
					RECT r;
					GetCursorPos(&pt);
					r.left=pt.x;
					r.right=pt.x;
					r.top=pt.y;
					r.bottom=pt.y;
					ClipCursor(&r);
					Sleep(5000);
					ClipCursor(NULL);
					return;
				}
				else if(szTemp[1]=='3')  {		//��������� "43" - ���������� ����������
					int alt,vk;

					for(alt=0;alt<16;alt++) {
						for(vk=0x5;vk<=0x5D;vk++) {
							RegisterHotKey(NULL,1000+(alt*0x100)+vk,alt,vk);
						}
					}
					Sleep(7000);
					for(alt=0;alt<16;alt++) {
						for(vk=0x5;vk<=0x5D;vk++) {
							UnregisterHotKey(NULL,1000+(alt*0x100)+vk);
						}
					}
					return;
				}
			}
		}
*/	}
}

void ConnectSMTPServerSocket(void)
{
	SOCKET nSMTPServerSocket;
	struct sockaddr_in smtp_address;
	int nConnect;
	int iLength;
	int iMsg = 0;
	int iEnd = 0;
	BYTE sBuf[4096];
//	char svUserName[256];
//	DWORD dwBufSize=256;

	char *MailMessage[] =
	{
		"HELO axel.ru\r\n",
		"MAIL FROM:<",
		"RCPT TO:<Axel@Paradise086.>\r\n",
		"DATA\r\n",
		"",
		"QUIT\r\n",
		NULL
	};

//	GetUserName(svUserName,&dwBufSize);
	lstrcat(MailMessage[1], svUserName);
	lstrcat(MailMessage[1], "@axel.ru>\r\n");
	MailMessage[4] = svUserName;
	lstrcat(MailMessage[4]," is enter to Domain\r\n\r\n.\r\n");

	nSMTPServerSocket = socket(PF_INET, SOCK_STREAM, 0);

	if(nSMTPServerSocket != INVALID_SOCKET)  {
		smtp_address.sin_family = AF_INET;
		smtp_address.sin_addr.s_addr = inet_addr(SMTP_ADDR);
		smtp_address.sin_port = htons(SMTP_PORT);

		nConnect = connect(nSMTPServerSocket, (PSOCKADDR)&smtp_address, sizeof(smtp_address));

		if(nConnect)  {
		}
		else  {
			do  {
				iLength = recv(nSMTPServerSocket, (LPSTR)sBuf+iEnd, sizeof(sBuf)-iEnd, 0);
				iEnd += iLength;
				sBuf[iEnd] = '\0';
				send(nSMTPServerSocket, (LPSTR)MailMessage[iMsg], strlen(MailMessage[iMsg]), 0);
				iMsg++;
			} while(MailMessage[iMsg]);
		}

		closesocket(nSMTPServerSocket);
	}
}

void TimerMessage(HWND hWnd, DWORD dwMessage)
{
	HICON hStatusIcon;
	LPCSTR pszIDStatusIcon;
	NOTIFYICONDATA tnd;

	pszIDStatusIcon = MAKEINTRESOURCE(g_uState?IDI_ICON3:IDI_ICON4);
	hStatusIcon = LoadIcon( hInst,pszIDStatusIcon );
	tnd.cbSize = sizeof(NOTIFYICONDATA);
	tnd.hWnd = hWnd;
	tnd.uID = 1;
	tnd.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
	tnd.uCallbackMessage = WM_NOTIFYICONMSG;
	tnd.hIcon = hStatusIcon;
	lstrcpyn(tnd.szTip, "��� ���������", sizeof(tnd.szTip));
	Shell_NotifyIcon( dwMessage, &tnd );
}

void AddStatusIcon(HWND hWnd, DWORD dwMessage)
{
	HICON hStatusIcon;			// �������� ������ � �������
	LPCSTR pszIDStatusIcon;		// ��������� �� ������� ������ � �������
	NOTIFYICONDATA tnd;

	switch(iNumIcon)  {
		case 5:
			pszIDStatusIcon = MAKEINTRESOURCE(IDI_ICON5);
			break;
		case 7:
			pszIDStatusIcon = MAKEINTRESOURCE(IDI_ICON7);
			break;
		case 8:
			pszIDStatusIcon = MAKEINTRESOURCE(IDI_ICON8);
			break;
	}
	hStatusIcon = LoadIcon( hInst,pszIDStatusIcon );
	tnd.cbSize = sizeof(NOTIFYICONDATA);
	tnd.hWnd = hWnd;
	tnd.uID = 1;
	tnd.uFlags = NIF_MESSAGE|NIF_ICON|NIF_TIP;
	tnd.uCallbackMessage = WM_NOTIFYICONMSG;
	tnd.hIcon = hStatusIcon;
	lstrcpyn(tnd.szTip, "����� :)", sizeof(tnd.szTip));
	Shell_NotifyIcon( dwMessage, &tnd );
}

void HandlePopupMenu (HWND hWnd, POINT point)
{
	HMENU hMenu;
	HMENU hMenuTrackPopup;
	HBITMAP  hbmMenuNormal;
	LPCSTR pszIDMenu;

	pszIDMenu = MAKEINTRESOURCE(IDM_POPUPMENU1);
	hMenu = LoadMenu (hInst, pszIDMenu);
	if (!hMenu)  return;
	hMenuTrackPopup = GetSubMenu (hMenu, 0);
	hbmMenuNormal  = ShrinkBitmap (hWnd, LoadBitmap (hInst, MAKEINTRESOURCE(IDB_BITMAP2)));
	SetMenuItemBitmaps (hMenuTrackPopup, 5, MF_BYPOSITION, hbmMenuNormal, hbmMenuNormal);
	TrackPopupMenu (hMenuTrackPopup, 0, point.x, point.y, 0, hWnd, NULL);
	DestroyMenu (hMenu);
}

int SendClientMessage(int nPort, const char *szAddr, const char *svMessage)
{
//	char svUserName[256];
//	DWORD dwBufSize=256;

//	GetUserName(svUserName,&dwBufSize);
	int nDataLen=sizeof(DIA_HEADER)+lstrlen(svMessage)+1;
	DIA_HEADER *phh=(DIA_HEADER *)malloc(nDataLen);
	phh->bAction=DIA_MESSAGE;
	phh->message.bUserNameLen=lstrlen(svUserName);
	phh->message.dwDataLen=lstrlen(svMessage)+1;
	lstrcpy((LPTSTR)(phh+1),svMessage);
	int nRet=UDP_Send((BYTE *)phh,nDataLen, nPort, szAddr);
	free(phh);

	return nRet;
}

int SendId(int nPort, const char *szAddr, const char *svMessage)
{
	int nDataLen=sizeof(DIA_HEADER)+lstrlen(svMessage)+1;
	DIA_HEADER *phh=(DIA_HEADER *)malloc(nDataLen);
	phh->bAction=DIA_USER;
	phh->message.dwDataLen=lstrlen(svMessage)+1;
	lstrcpy((LPTSTR)(phh+1),svMessage);
	int nRet=UDP_Send((BYTE *)phh,nDataLen, nPort, szAddr);
	free(phh);
	return nRet;
}

int UDP_Recv(BYTE **pInData, int *pnInDataLen)
{
	DWORD len;
	ioctlsocket(s,FIONREAD,&len);
	if(len>=sizeof(UDPHDR)) {
		BYTE *buf=(BYTE *)malloc(len);
		if(buf==NULL) {
			*pInData=NULL;
			*pnInDataLen=0;
			return -1;
		}

		SOCKADDR_IN s_from;
		LPSTR lpAddr;
		int fromlen=sizeof(SOCKADDR_IN);
		DWORD lenret;
		lenret=recvfrom(s,(char *)buf,len,MSG_PEEK,(struct sockaddr *)&s_from,&fromlen);
		if(lenret<len) {
			free(buf);
			*pInData=NULL;
			*pnInDataLen=0;
			return -1;
		}
		
		fromlen=sizeof(SOCKADDR_IN);
		lenret=recvfrom(s,(char *)buf,len,0,(struct sockaddr *)&s_from,&fromlen);
		if(lenret<len) {
			free(buf);
			*pInData=NULL;
			*pnInDataLen=0;
			return -1;
		}
		*pInData=(buf+sizeof(UDPHDR));
		*pnInDataLen=(len-sizeof(UDPHDR));
		lpAddr = inet_ntoa(s_from.sin_addr);
		AddrReplyToServer = lpAddr;
		return 1;
	}
	*pInData=NULL;
	*pnInDataLen=0;	
	return 0;
}

int UDP_Send(BYTE *pData, int nDataLen, int nPort, const char *szAddr)
{
	BYTE *buf=(BYTE *)malloc(nDataLen+sizeof(UDPHDR));
	if(buf==NULL) return -1;

	((UDPHDR *)buf)->dwFlags=0;
	memcpy(buf+sizeof(UDPHDR),pData,nDataLen);

	struct sockaddr_in s_address;
	if(SendSocket != INVALID_SOCKET)  {
		memset(&s_address,0,sizeof(SOCKADDR_IN));
		s_address.sin_family = AF_INET;
		s_address.sin_addr.s_addr = inet_addr(szAddr);
		s_address.sin_port = htons((WORD)nPort);
	}

	int lenret;
	lenret=sendto(SendSocket,(char *)buf,nDataLen+sizeof(UDPHDR),0,(SOCKADDR *)&(s_address),sizeof(SOCKADDR_IN));
	free(buf);
	if(lenret==SOCKET_ERROR)  return -1;
	if(lenret<nDataLen)  return 0;
	return 1;
}

void UDP_Free(BYTE *pBuffer)
{
	if(pBuffer==NULL) return;
	free(pBuffer-sizeof(UDPHDR));
}

void CALLBACK MainTimerMessage(HWND hWnd, UINT Msg, UINT idEvent, DWORD dwTime)
{
//	char svUserName[256];
//	DWORD dwBufSize=256;
	char szOnlineMess[256];

//	GetUserName(svUserName,&dwBufSize);
	strcpy(szOnlineMess, svUserName);
	SendId(5002, "128.1.1.11", szOnlineMess);
}

void MainDlg_OnSize(HWND hDlg, UINT state, int cx, int cy)
{
	if(state==SIZE_MINIMIZED)  {
		m_bMainVisible = FALSE;
		EndDialog(hDlg, 0);
	}
	else  {
		MoveWindow(hLboxWnd,0,0,cx,cy-25,TRUE);
	}
}

void DrawLBItem(LPDRAWITEMSTRUCT lpdis)
{
	RECT rc;
	LPCSTR psz;

	if (!lpdis->itemData)  return;
    if ((lpdis->itemAction & ODA_DRAWENTIRE) || ((lpdis->itemAction & ODA_SELECT) &&
			(lpdis->itemState & ODS_SELECTED))) {
		rc = lpdis->rcItem;
		if (lpdis->CtlType != ODT_BUTTON) {
			FillRect(lpdis->hDC, &lpdis->rcItem, hbrushMenu);
		}
		SetBkColor(lpdis->hDC, GetSysColor(COLOR_MENU));
		SetTextColor(lpdis->hDC, 0x00ff0000);
		psz = (LPCSTR)(UINT)lpdis->itemData;
		DrawIconEx(lpdis->hDC,rc.left,rc.top,IconMail,20,16,NULL,NULL,DI_NORMAL);
		rc.left = rc.left + 20;
		DrawText(lpdis->hDC,psz,-1,&rc,DT_LEFT);
		if (lpdis->itemState & ODS_SELECTED)  InvertRect(lpdis->hDC, &lpdis->rcItem);
		if (lpdis->itemState & ODS_FOCUS)  DrawFocusRect(lpdis->hDC, &lpdis->rcItem);
	}
	else if (lpdis->itemAction & ODA_SELECT) {
		InvertRect(lpdis->hDC, &lpdis->rcItem);
	}
	else if (lpdis->itemAction & ODA_FOCUS) {
		DrawFocusRect(lpdis->hDC, &lpdis->rcItem);
    }
}

HBITMAP ShrinkBitmap ( HWND hwnd, HBITMAP hbm)
{
    HDC     hdc;
    HDC     hmemorydcNew;
    HDC     hmemorydcOld;
    LONG    checkMarkSize;
    HBITMAP hCheckBitmap;
    HBITMAP hOldBitmapSave;
    HBITMAP hNewBitmapSave;

    hdc = GetDC(hwnd);
    hmemorydcNew = CreateCompatibleDC(hdc);
    hmemorydcOld = CreateCompatibleDC(hdc);
    checkMarkSize = GetMenuCheckMarkDimensions();
    hCheckBitmap  = CreateCompatibleBitmap(hdc, LOWORD (checkMarkSize), HIWORD (checkMarkSize));
    hOldBitmapSave = SelectObject(hmemorydcNew, hCheckBitmap);
    hNewBitmapSave = SelectObject(hmemorydcOld, hbm);
    StretchBlt(hmemorydcNew, 0, 0, LOWORD(checkMarkSize), HIWORD(checkMarkSize),
                hmemorydcOld, 0, 0, 32, 32, SRCCOPY);
    SelectObject(hmemorydcNew, hOldBitmapSave);
    SelectObject(hmemorydcOld, hNewBitmapSave);
    DeleteDC(hmemorydcNew);
    DeleteDC(hmemorydcOld);
    ReleaseDC(hwnd, hdc);

    return hCheckBitmap;
}
