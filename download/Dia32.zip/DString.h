#include <windows.h>

#define D_DATADEF
#define DAPI				__stdcall

typedef char CHAR;
typedef CHAR *LPSTR;
typedef const CHAR *LPCSTR;

struct DStringData
{
	long nRefs;
	int nDataLength;
	int nAllocLength;

	CHAR* data()
		{ return (CHAR*)(this+1); }
};

class DString
{
public:
	DString();
	DString(const DString& stringSrc);
	DString(LPCSTR lpsz);
	char * GetDString();
	const DString& operator=(const DString& stringSrc);
	const DString& operator=(LPCSTR lpsz);
	const DString& operator+=(const DString& string);
	const DString& operator+=(CHAR ch);
	const DString& operator+=(LPCSTR lpsz);
	int Compare(LPCSTR lpsz) const;
	DString Mid(int nFirst, int nCount) const;
	DString Mid(int nFirst) const;
	DString Left(int nCount) const;
	DString Right(int nCount) const;
	int Find(CHAR ch) const;
	int ReverseFind(CHAR ch) const;
	int Find(LPCSTR lpszSub) const;
	void ReleaseBuffer(int nNewLength = -1);

public:
	~DString();
	
protected:
	LPSTR m_pchData;
	DStringData* GetData() const;
	void Init();
	void AllocCopy(DString& dest, int nCopyLen, int nCopyIndex, int nExtraLen) const;
	void AllocBuffer(int nLen);
	void AssignCopy(int nSrcLen, LPCSTR lpszSrcData);
	void ConcatCopy(int nSrc1Len, LPCSTR lpszSrc1Data, int nSrc2Len, LPCSTR lpszSrc2Data);
	void ConcatInPlace(int nSrcLen, LPCSTR lpszSrcData);
	void AllocBeforeWrite(int nLen);
	void Release();
	static void Release(DStringData* pData);
	static int SafeStrlen(LPCSTR lpsz);
};

const DString& DAPI DGetEmptyString();
#define dEmptyString		DGetEmptyString()