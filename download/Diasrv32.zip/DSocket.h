#include <windows.h>

class DSocket
{
public:
	DSocket();

public:
	SOCKET m_hSocket;

public:
	virtual void Close();
//	BOOL AsyncSelect(long lEvent =
//		FD_READ | FD_WRITE | FD_OOB | FD_ACCEPT | FD_CONNECT | FD_CLOSE);

public:
	virtual ~DSocket();
//	static void PASCAL KillSocket(SOCKET hSocket, DSocket* pSocket);
};
