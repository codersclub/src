#include "dstring.h"

static int rgInitData[] = { -1, 0, 0, 0 };
static D_DATADEF DStringData* dDataNil = (DStringData*)&rgInitData;
static LPCSTR dPchNil = (LPCSTR)(((BYTE*)&rgInitData)+sizeof(DStringData));

const DString& DAPI DGetEmptyString()
	{ return *(DString*)&dPchNil; }

DString::DString()
{
	Init();
}

DString::DString(const DString& stringSrc)
{
	if (stringSrc.GetData()->nRefs >= 0)  {
		m_pchData = stringSrc.m_pchData;
		InterlockedIncrement(&GetData()->nRefs);
	}
	else  {
		Init();
		*this = stringSrc.m_pchData;
	}
}

DString::~DString()
{
	if (GetData() != dDataNil)  {
		if (InterlockedDecrement(&GetData()->nRefs) <= 0)
			delete[] (BYTE*)GetData();
	}
}

void DString::AllocCopy(DString& dest, int nCopyLen, int nCopyIndex, int nExtraLen) const
{
	int nNewLen = nCopyLen + nExtraLen;
	if (nNewLen == 0)  dest.Init();
	else  {
		dest.AllocBuffer(nNewLen);
		memcpy(dest.m_pchData, m_pchData+nCopyIndex, nCopyLen*sizeof(CHAR));
	}
}

void DString::AssignCopy(int nSrcLen, LPCSTR lpszSrcData)
{
	AllocBeforeWrite(nSrcLen);
	memcpy(m_pchData, lpszSrcData, nSrcLen*sizeof(CHAR));
	GetData()->nDataLength = nSrcLen;
	m_pchData[nSrcLen] = '\0';
}

void DString::AllocBeforeWrite(int nLen)
{
	if (GetData()->nRefs > 1 || nLen > GetData()->nAllocLength)  {
		Release();
		AllocBuffer(nLen);
	}
}

DString::DString(LPCSTR lpsz)
{
	Init();
	int nSrcLen = lpsz != NULL ? strlen(lpsz) : 0;
	if (nSrcLen != 0)  {
		AllocBuffer(nSrcLen);
		memcpy(m_pchData, lpsz, nSrcLen+1);
		ReleaseBuffer();
	}
}

char * DString::GetDString()
	{ return (char *)m_pchData; }

inline int DString::Compare(LPCSTR lpsz) const
	{ return strcmp(m_pchData, lpsz); }

inline DStringData* DString::GetData() const
	{ return ((DStringData*)m_pchData)-1; }

inline void DString::Init()
	{ m_pchData = dEmptyString.m_pchData; }

inline int DString::SafeStrlen(LPCSTR lpsz)
	{ return (lpsz == NULL) ? 0 : strlen(lpsz); }

inline DString::operator LPCSTR() const
	{ return m_pchData; }

const DString& DString::operator+=(const DString& string)
{
	ConcatInPlace(string.GetData()->nDataLength, string.m_pchData);
	return *this;
}

const DString& DString::operator+=(CHAR ch)
{
	ConcatInPlace(1, &ch);
	return *this;
}

const DString& DString::operator+=(LPCSTR lpsz)
{
	ConcatInPlace(SafeStrlen(lpsz), lpsz);
	return *this;
}

const DString& DString::operator=(const DString& stringSrc)
{
	if (m_pchData != stringSrc.m_pchData)  {
		if ((GetData()->nRefs < 0 && GetData() != dDataNil) ||
			stringSrc.GetData()->nRefs < 0)  {
			AssignCopy(stringSrc.GetData()->nDataLength, stringSrc.m_pchData);
		}
		else  {
			Release();
			m_pchData = stringSrc.m_pchData;
			InterlockedIncrement(&GetData()->nRefs);
		}
	}
	return *this;
}

const DString& DString::operator=(LPCSTR lpsz)
{
	AssignCopy(SafeStrlen(lpsz), lpsz);
	return *this;
}

void DString::AllocBuffer(int nLen)
{
	if (nLen < 0)  MessageBox(NULL, "������ DString �� ����� ���� ������������� !!!", "Error", MB_OK|MB_SETFOREGROUND);

	if (nLen == 0)  Init();
	else  {
		DStringData* pData =
			(DStringData*)new BYTE[sizeof(DStringData) + (nLen+1)*sizeof(CHAR)];
		pData->nRefs = 1;
		pData->data()[nLen] = '\0';
		pData->nDataLength = nLen;
		pData->nAllocLength = nLen;
		m_pchData = pData->data();
	}
}

void DString::ReleaseBuffer(int nNewLength)
{
	if (nNewLength == -1)  nNewLength = strlen(m_pchData);
	GetData()->nDataLength = nNewLength;
	m_pchData[nNewLength] = '\0';
}

void DString::Release(DStringData* pData)
{
	if (pData != dDataNil)  {
		if (InterlockedDecrement(&pData->nRefs) <= 0)
			delete[] (BYTE*)pData;
	}
}

void DString::Release()
{
	if (GetData() != dDataNil)  {
		if (InterlockedDecrement(&GetData()->nRefs) <= 0)
			delete[] (BYTE*)GetData();
		Init();
	}
}

void DString::ConcatCopy(int nSrc1Len, LPCSTR lpszSrc1Data, int nSrc2Len, LPCSTR lpszSrc2Data)
{
	int nNewLen = nSrc1Len + nSrc2Len;
	if (nNewLen != 0)  {
		AllocBuffer(nNewLen);
		memcpy(m_pchData, lpszSrc1Data, nSrc1Len*sizeof(CHAR));
		memcpy(m_pchData+nSrc1Len, lpszSrc2Data, nSrc2Len*sizeof(CHAR));
	}
}

void DString::ConcatInPlace(int nSrcLen, LPCSTR lpszSrcData)
{
	if (nSrcLen == 0)  return;
	if (GetData()->nRefs > 1 || GetData()->nDataLength + nSrcLen > GetData()->nAllocLength)  {
		DStringData* pOldData = GetData();
		ConcatCopy(GetData()->nDataLength, m_pchData, nSrcLen, lpszSrcData);
		DString::Release(pOldData);
	}
	else  {
		memcpy(m_pchData+GetData()->nDataLength, lpszSrcData, nSrcLen*sizeof(CHAR));
		GetData()->nDataLength += nSrcLen;
		m_pchData[GetData()->nDataLength] = '\0';
	}
}

int DString::Find(CHAR ch) const
{
	LPSTR lpsz = strchr(m_pchData, (CHAR)ch);
	return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
}

int DString::Find(LPCSTR lpszSub) const
{
	LPSTR lpsz = strstr(m_pchData, lpszSub);
	return (lpsz == NULL) ? -1 : (int)(lpsz - m_pchData);
}

DString DString::Mid(int nFirst) const
{
	return Mid(nFirst, GetData()->nDataLength - nFirst);
}

DString DString::Mid(int nFirst, int nCount) const
{
	if (nFirst < 0)  nFirst = 0;
	if (nCount < 0)  nCount = 0;
	if (nFirst + nCount > GetData()->nDataLength)  nCount = GetData()->nDataLength - nFirst;
	if (nFirst > GetData()->nDataLength)  nCount = 0;

	DString dest;
	AllocCopy(dest, nCount, nFirst, 0);
	return dest;
}

DString DString::Right(int nCount) const
{
	if (nCount < 0)  nCount = 0;
	else if (nCount > GetData()->nDataLength)  nCount = GetData()->nDataLength;

	DString dest;
	AllocCopy(dest, nCount, GetData()->nDataLength-nCount, 0);
	return dest;
}

DString DString::Left(int nCount) const
{
	if (nCount < 0)  nCount = 0;
	else if (nCount > GetData()->nDataLength)  nCount = GetData()->nDataLength;

	DString dest;
	AllocCopy(dest, nCount, 0, 0);
	return dest;
}

DString DAPI operator+(const DString& string1, const DString& string2)
{
	DString s;
	s.ConcatCopy(string1.GetData()->nDataLength, string1.m_pchData,
		string2.GetData()->nDataLength, string2.m_pchData);
	return s;
}

DString DAPI operator+(const DString& string, LPCSTR lpsz)
{
	DString s;
	s.ConcatCopy(string.GetData()->nDataLength, string.m_pchData,
		DString::SafeStrlen(lpsz), lpsz);
	return s;
}

DString DAPI operator+(LPCSTR lpsz, const DString& string)
{
	DString s;
	s.ConcatCopy(DString::SafeStrlen(lpsz), lpsz, string.GetData()->nDataLength,
		string.m_pchData);
	return s;
}
