//**********************************************************
//* Class "DString" is an analog "CString" in MFC 4.2
//*
//*	(C) Copyrite 1999 by Axel (dimka.u@usa.net)
//*
//*		DString m_bTest1, m_bTest2;
//*		m_bTest1 = "11111111";
//*		m_bTest2 = "222222";
//*		m_bTest1 += m_bTest2;
//*		m_bTest1 += "3333";
//*		if(m_bTest1.GetDString()!="")  {
//*			MessageBox(NULL, m_bTest1.GetDString(), "Test", MB_OK|MB_SETFOREGROUND);
//*		}
//*		int ndx;
//*		m_bTest1 = "32123";
//*		if((ndx = m_bTest1.Find("123"))!=-1)  {
//*			m_bTest1 = m_bTest1.Mid(ndx);
//*			MessageBox(NULL, m_bTest1.GetDString(), "Test", MB_OK|MB_SETFOREGROUND);
//*		}
//*
//*
//**********************************************************

#include <windows.h>

#define D_DATADEF
#define DAPI				__stdcall
#define WINAPI				__stdcall
#define NULL				0

typedef char CHAR;
typedef unsigned char BYTE;
typedef CHAR *LPSTR;
typedef const CHAR *LPCSTR;

struct DStringData
{
	long nRefs;
	int nDataLength;
	int nAllocLength;

	CHAR* data()
		{ return (CHAR*)(this+1); }
};

class DString
{
public:
	DString();
	DString(const DString& stringSrc);
	DString(LPCSTR lpsz);
	char * GetDString();
	int GetLength() const;
	operator LPCSTR() const;
	const DString& operator=(const DString& stringSrc);
	const DString& operator=(LPCSTR lpsz);
	const DString& operator+=(const DString& string);
	const DString& operator+=(CHAR ch);
	const DString& operator+=(LPCSTR lpsz);
	friend DString DAPI operator+(const DString& string1, const DString& string2);
	friend DString DAPI operator+(const DString& string, LPCSTR lpsz);
	friend DString DAPI operator+(LPCSTR lpsz, const DString& string);
	int Compare(LPCSTR lpsz) const;
	DString Mid(int nFirst, int nCount) const;
	DString Mid(int nFirst) const;
	DString Left(int nCount) const;
	DString Right(int nCount) const;
	int Find(CHAR ch) const;
	int Find(LPCSTR lpszSub) const;
	void ReleaseBuffer(int nNewLength = -1);

public:
	~DString();
	
protected:
	LPSTR m_pchData;
	DStringData* GetData() const;
	void Init();
	void AllocCopy(DString& dest, int nCopyLen, int nCopyIndex, int nExtraLen) const;
	void AllocBuffer(int nLen);
	void AssignCopy(int nSrcLen, LPCSTR lpszSrcData);
	void ConcatCopy(int nSrc1Len, LPCSTR lpszSrc1Data, int nSrc2Len, LPCSTR lpszSrc2Data);
	void ConcatInPlace(int nSrcLen, LPCSTR lpszSrcData);
	void AllocBeforeWrite(int nLen);
	void Release();
	static void Release(DStringData* pData);
	static int SafeStrlen(LPCSTR lpsz);
};

const DString& DAPI DGetEmptyString();
#define dEmptyString		DGetEmptyString()