// Mes.cpp: implementation of the CMes class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Users.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMes::CMes()
{
	memset(code,0,sizeof(code));
	memset(data,0,sizeof(data));
	len=0;
}

CMes::~CMes()
{
}

bool CMes::operator == (const TCHAR* buf) const
{
	return !memcmp(code,buf,sizeof(code));
}

bool CMes::operator != (const TCHAR* buf) const
{
	return !operator == (buf);
}

const TCHAR* CMes::operator = (const TCHAR* new_code)
{
	memcpy(code,new_code,sizeof(code));
	return new_code;
}

int CMes::Send(SOCKET s,const SOCKADDR_IN* sin)
{
	return sendto(s,
			(char*)this,
			len+sizeof(code)+sizeof(len),
			NULL,
			(SOCKADDR*)sin,
			sizeof(*sin));
}
