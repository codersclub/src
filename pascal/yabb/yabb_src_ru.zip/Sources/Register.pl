###############################################################################
# Register.pl                                                                 #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$registerplver = "1 Gold - SP1";

sub Register {
  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellpadding="0">
  <tr>
    <td bgcolor="$color{'windowbg2'}">&nbsp;</td></tr></table>
<table border=0 width=100% cellspacing=1 cellpadding="0">
  <form action="$cgi;action=register2" method="POST" name="creator">
  <tr>
    <td bgcolor="$color{'titlebg'}">
    <img src="$imagesdir/register.gif" alt="$txt{'97'}" border="0"> <font size=2 color="$color{'titletext'}"><b>$txt{'97'}</b>&nbsp;&nbsp; $txt{'517'}</font></td>
  </tr><tr>
    <td bgcolor="$color{'windowbg'}" width="100%"><font size=2>
    <table cellpadding="3" cellspacing="0" border=0 width="100%">
      <tr>
        <td width="40%"><font size=2>* <b>$txt{'98'}:</b></font>
        <BR><font size="1">$txt{'520'}</font></td>
        <td><input type=text name=username size=30 maxlength="18"></td>
      </tr><tr>
        <td width="40%"><font size=2>* <b>$txt{'69'}:</b></font>
        <BR><font size="1">$txt{'679'}</font></td>
        <td><font size=2><input type=text maxlength="40" name=email size=30></font></td>
      </tr>
~;
if ($allow_hide_email == 1) { $yymain .= qq~
      <tr>
        <td><font size=2>&nbsp;&nbsp;<b>$txt{'721'}</b></font></td>
        <td><font size=2> <input type="checkbox" name="hideemail" value="checked"></font></td>
      </tr>
~;
}
unless( $emailpassword ) {
    $yymain .= qq~
      <tr>
        <td width="40%"><font size=2>* <b>$txt{'81'}:</b></font></td>
        <td><font size=2><input type=password maxlength="30" name=passwrd1 size=30></font></td>
      </tr><tr>
        <td width="40%"><font size=2>* <b>$txt{'82'}:</b></font></td>
        <td><font size=2><input type=password maxlength="30" name=passwrd2 size=30></font></td>
      </tr>
~;
}
$yymain .= qq~
      <tr>
        <td width="40%"><font size=2>* <b>$txt{'231'}: </b></font></td>
        <td>
        <select name="gender" size="1">
         <option value=""></option>
         <option value="Male"$GenderMale>$txt{'238'}</option>
         <option value="Female"$GenderFemale>$txt{'239'}</option>
        </select>
        </td>
      </tr><tr>
        <td width="40%"><font size=2><b>$txt{'563'}:</b></font></td>
        <td><font size="1"> $txt{'565'}<input type="text" name="bday2" size="2" maxlength="2" value="$uday"> $txt{'564'}<input type="text" name="bday1" size="2" maxlength="2" value="$umonth"> $txt{'566'}<input type="text" name="bday3" size="4" maxlength="4" value="$uyear"></font></td>
      </tr><tr>
        <td width="320"><font size=2>* <b>$txt{'227'}: </b></font></td>
        <td><font size=2><input type="text" maxlength="30" name="location" size="50" value="$memsettings[15]"></font></td>
      </tr>

    </table>
    </td>
  </tr>
~;
if ($RegAgree) {
  fopen(FILE, "$vardir/agreement.txt");
  @agreement = <FILE>;
  fclose(FILE);
  $fullagree = join( "", @agreement );
  $fullagree =~ s/\n/<BR>/g;
  $yymain .= qq~
  <tr>
    <td bgcolor="$color{'windowbg'}">
<table border=0 cellspacing=1 cellpadding="5" width="100%" align="center">
  <tr>
    <td bgcolor="$color{'windowbg2'}">
    <font size=2><BR>$fullagree<BR><BR></font>
    </td>
  </tr><tr>
    <td bgcolor="$color{'windowbg'}" align="center"><font size=2>
    <B>$txt{'585'}</B> <input type=radio name=regagree value="yes">
    &nbsp;&nbsp;&nbsp; <B>$txt{'586'}</B> <input type=radio name=regagree value="no" checked>
    </font></td>
  </tr>
</table>
</td></tr>
~;
}
  $yymain .= qq~
  <tr>
    <td bgcolor="$color{'windowbg'}">
      <BR><center><input type=submit value="$txt{'97'}"><br>&nbsp;</center>
    </td>
  </tr>
    </form>
</table>
<script language="JavaScript"> <!--
  document.creator.username.focus();
//--> </script>
<table border=0 width=100% cellspacing=0 cellpadding="0">
  <tr>
    <td bgcolor="$color{'windowbg2'}">&nbsp;</td></tr></table>
~;
  $yytitle = "$txt{'97'}";
  &template;
  exit;
}

#######################################
sub Register2 {
  if($FORM{'regagree'} eq "no") {
    $yySetLocation = qq~$scripturl~;
    &redirectexit;
  }
  my %member;
  while( ($key,$value) = each(%FORM) ) {
    $value =~ s~\A\s+~~;
    $value =~ s~\s+\Z~~;
    $value =~ s~[\n\r]~~g;
    $member{$key} = $value;
  }
  $member{'username'} =~ s/\s/_/g;
  if (length($member{'username'}) > 25) { $member{'username'} = substr($member{'username'},0,25); }
  &fatal_error("($member{'username'}) $txt{'37'}") if($member{'username'} eq '');
  &fatal_error("($member{'username'}) $txt{'99'}") if($member{'username'} eq '_' || $member{'username'} eq '|');
  &fatal_error("$txt{'244'} $member{'username'}") if($member{'username'} =~ /guest/i);
  &fatal_error("$txt{'240'} $txt{'35'} $txt{'241'}") if($member{'username'} !~ /\A[0-9A-Za-z#%+-\.@^_]+\Z/);
  &fatal_error("$txt{'240'}") if($member{'username'} =~ /,/);
  &fatal_error("($member{'username'}) $txt{'76'}") if($member{'email'} eq "");
  &fatal_error("($member{'username'}) $txt{'100'}") if(-e ("$memberdir/$member{'username'}.dat"));

  # Check for the BirthDay
  #  &fatal_error("$txt{'567'}") if( !$member{'bday1'} || !$member{'bday2'} || !$member{'bday3'} );
  if( $member{'bday1'} && $member{'bday2'} && $member{'bday3'} ) {
    &fatal_error("$txt{'567'}") if( $member{'bday1'} !~ /^[0-9]+$/ || $member{'bday2'} !~ /^[0-9]+$/ || $member{'bday3'} !~ /^[0-9]+$/ || length($member{'bday3'}) < 4 );
    &fatal_error("$txt{'567'}") if( $member{'bday1'} < 1 || $member{'bday1'} > 12 || $member{'bday2'} < 1 || $member{'bday2'} > 31 || $member{'bday3'} < 1901 || $member{'bday3'} > $year-5 );
  }
  $member{'bday1'} =~ s/[^0-9]//g;
  $member{'bday2'} =~ s/[^0-9]//g;
  $member{'bday3'} =~ s/[^0-9]//g;
  if($member{'bday1'}) { $member{'bday'} = "$member{'bday1'}/$member{'bday2'}/$member{'bday3'}"; }
  else { $member{'bday'} = ''; }
  &fatal_error("$txt{'gender'}") if( !$member{'gender'} );
  &fatal_error("$txt{'location'}") if( !$member{'location'} );

  if( $emailpassword ) {
    srand();
    $member{'passwrd1'} = int( rand(100) );
    $member{'passwrd1'} =~ tr/0123456789/ymifxupbck/;
    $_ = int( rand(77) );
    $_ =~ tr/0123456789/q8dv7w4jm3/;
    $member{'passwrd1'} .= $_;
    $_ = int( rand(89) );
    $_ =~ tr/0123456789/y6uivpkcxw/;
    $member{'passwrd1'} .= $_;
    $_ = int( rand(188) );
    $_ =~ tr/0123456789/poiuytrewq/;
    $member{'passwrd1'} .= $_;
    $_ = int( rand(65) );
    $_ =~ tr/0123456789/lkjhgfdaut/;
    $member{'passwrd1'} .= $_;
  } else {
    &fatal_error("($member{'username'}) $txt{'213'}") if($member{'passwrd1'} ne $member{'passwrd2'});
    &fatal_error("($member{'username'}) $txt{'91'}") if($member{'passwrd1'} eq '');
    &fatal_error("$txt{'240'} $txt{'36'} $txt{'241'}") if($member{'passwrd1'} !~ /\A[\s0-9A-Za-z!@#$%\^&*\(\)_\+|`~\-=\\:;'",\.\/?\[\]\{\}]+\Z/);
  }
  &fatal_error("$txt{'240'} $txt{'69'} $txt{'241'}") if($member{'email'} !~ /\A[0-9A-Za-z@\._\-]+\Z/);
#vot
  $member{'email'} = lc($member{'email'});
  &fatal_error("$txt{'500'}") if(($member{'email'} =~ /(@.*@)|(\.\.)|(@\.)|(\.@)|(^\.)|(\.$)/) || ($member{'email'} !~ /\A.+@\[?(\w|[-.])+\.[a-zA-Z]{2,4}|[0-9]{1,4}\]?\Z/));
#  &fatal_error("$txt{'500'}") if ($member{'email'} !~ /^([a-z0-9_-]+[\.]?)*[a-z0-9_-]+\@([a-z0-9_-]+[\.]?)*([a-z0-9_-]+)\.[a-z0-9]+\$/);
#/vot
  fopen(FILE, "$vardir/ban_email.txt");
  @banned = <FILE>;
  fclose(FILE);
  foreach $curban (@banned) {
    if($member{'email'} eq "$curban") { &fatal_error("$txt{'678'}$txt{'430'}!"); }
  }


  fopen(FILE, "$memberdir/memberlist.txt");
  @memberlist = <FILE>;
  fclose(FILE);
  $testname = lc $member{'username'};
  for ($a = 0; $a < @memberlist; $a++) {
    chomp $memberlist[$a];
    $membername = lc $memberlist[$a];
    if( fopen(FILE2, "$memberdir/$memberlist[$a].dat") ) {

      # Load users and check email
      if( !$yyUDLoaded{$memberlist[$a]} && -e("$memberdir/$memberlist[$a].dat") ) {
        # If user is not in memory, s/he must be loaded.
        &LoadUser($memberlist[$a]);
        if($userprofile{$memberlist[$a]}->[2] eq $member{'email'}) { &fatal_error("$txt{'730'} ($member{'email'}) $txt{'731'}"); }
      }

      $tmpa=<FILE2>;
      $realname=<FILE2>;
      fclose(FILE2);
      chomp $realname;
      $realname = lc $realname;
      if ($realname eq $testname || $membername eq $testname) { &fatal_error("($member{'username'}) $txt{'473'}"); }
    }
    elsif( $testname eq $membername ) { &fatal_error("($member{'username'}) $txt{'473'}"); }
  }
  &ToHTML($member{'email'});

  fopen(FILE, "$vardir/reserve.txt") || &fatal_error("$txt{'23'} reserve.txt");
  @reserve = <FILE>;
  fclose(FILE);
  fopen(FILE, "$vardir/reservecfg.txt") || &fatal_error("$txt{'23'} reservecfg.txt");
  @reservecfg = <FILE>;
  fclose(FILE);
  for( $a = 0; $a < @reservecfg; $a++ ) {
    chomp $reservecfg[$a];
  }
  $matchword = $reservecfg[0] eq 'checked';
  $matchcase = $reservecfg[1] eq 'checked';
  $matchuser = $reservecfg[2] eq 'checked';
  $matchname = $reservecfg[3] eq 'checked';
  $namecheck = $matchcase eq 'checked' ? $member{'username'} : lc $member{'username'};

  foreach $reserved (@reserve) {
    chomp $reserved;
    $reservecheck = $matchcase ? $reserved : lc $reserved;
    if ($matchuser) {
      if ($matchword) {
        if ($namecheck eq $reservecheck) { &fatal_error("$txt{'244'} $reserved"); }
      }
      else {
        if ($namecheck =~ $reservecheck) { &fatal_error("$txt{'244'} $reserved"); }
      }
    }
  }

  &fatal_error("$txt{'100'})") if(-e ("$memberdir/$member{'username'}.dat"));
  fopen(FILE, ">$memberdir/$member{'username'}.dat");
  print FILE "$member{'passwrd1'}\n"; 			#0  password            
  print FILE "$member{'username'}\n";			#1  realname            
  print FILE "$member{'email'}\n";			#2  email               
  print FILE "\n";					#3  websiteTitle        
  print FILE "\n";					#4  websiteUrl          
  print FILE "\n";					#5  MsgSignature        
  print FILE "0\n";					#6  numOfMsgs           
  print FILE "\n";					#7  AdminStatus         
  print FILE "\n";					#8  icq                 
  print FILE "\n";					#9  aim                 
  print FILE "\n";					#10 yim                 
  print FILE "$member{'gender'}\n";			#11 gender              
  print FILE "$txt{'209'}\n";				#12 usertext            
  print FILE "blank.gif\n";				#13 userpic             
  print FILE "$date\n";					#14 registration_date   
  print FILE "$member{'location'}\n";                   #15 location            
  print FILE "$member{'bday'}\n";                   	#16 birthday(mm/dd/yyyy)
  print FILE "\n";                             		#17 usertimeselect      
  print FILE "\n";                            		#18 usertimeoffset      
  if ($FORM{'hideemail'} ne "checked") {
    $FORM{'hideemail'} = "";
  }
  print FILE "$FORM{'hideemail'}\n";		#19 hideemail         
  print FILE "on\n";				#20 showreplythread   
  print FILE "\n";				#21 disablesmiles     
  print FILE "on\n";				#22 enablecodebuttons 
  print FILE "\n";				#23 menutype          
  print FILE "\n";				#24 curposlinks       
  print FILE "on\n";				#25 profilebutton     
  print FILE "on\n";				#26 showlatestmember  
  print FILE "on\n";				#27 showrecentbar     
  print FILE "on\n";				#28 ShowBDescrip      
  print FILE "on\n";				#29 showuserpic       
  print FILE "on\n";				#30 showusertext      
  print FILE "on\n";				#31 showgenderimage   
  print FILE "on\n";				#32 showstars         
  print FILE "\n";				#33 MembersPerPage    
  print FILE "\n";				#34 maxdisplay        
  print FILE "\n";				#35 maxmessagesdisplay
  print FILE "\n";				#36 titlebg           
  print FILE "\n";				#37 titletext         
  print FILE "\n";				#38 windowbg          
  print FILE "\n";				#39 windowbg2         
  print FILE "\n";				#40 windowbg3         
  print FILE "\n";				#41 catbg             
  print FILE "\n";				#42 bordercolor       
  print FILE "\n";				#43 fadertext         
  print FILE "\n";				#44 awards            
  print FILE "on\n";				#45 showfastreply     
  fclose(FILE);

  fopen(FILE, ">$memberdir/memberlist.txt", 1);
  foreach $curmem (@memberlist) { print FILE "$curmem\n"; }
  print FILE "$member{'username'}\n";
  fclose(FILE);

  my $membershiptotal = @memberlist + 1;
  fopen(FILE, "+>$memberdir/members.ttl");
  print FILE qq~$membershiptotal|$member{'username'}~;
  fclose(FILE);
  &FormatUserName($member{'username'});

  if($emailpassword) {
    &sendmail($member{'email'},"$txt{'700'} $mbname", "$txt{'248'} $member{'username'}!\n\n$txt{'719'} $member{'username'}, $txt{'492'} $member{'passwrd1'}\n\n$txt{'701'}\n$scripturl?action=profile;username=$useraccount{$member{'username'}}\n\n$txt{'130'}");
    $yymain .= qq~<BR><table border=0 width=100% cellspacing=1 bgcolor="$color{'bordercolor'}" align="center">~;
    require "$sourcedir/LogInOut.pl";
    $sharedLogin_title="$txt{'97'}";
    $sharedLogin_text="$txt{'703'}";
    &sharedLogin;
    $yymain .= qq~</table>~;
  }
  else {
  if($emailwelcome) {
    &sendmail($member{'email'},"$txt{'700'} $mbname", "$txt{'248'} $member{'username'}!\n\n$txt{'719'} $member{'username'}, $txt{'492'} $member{'passwrd1'}\n\n$txt{'701'}\n$scripturl?action=profile;username=$useraccount{$member{'username'}}\n\n$txt{'130'}");
  }
    $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr>
    <td bgcolor="$color{'windowbg2'}">
    <BR><BR>
    </td>
  </tr>
</table>

<table border=0 width=300 cellspacing=1 bgcolor="$color{'bordercolor'}" align="center">
  <tr>
    <td bgcolor="$color{'titlebg'}">
    <img src="$imagesdir/register.gif" alt="$txt{'97'}" border="0"> <font size=2 color="$color{'titletext'}"><b>$txt{'97'}</b></font></td>
  </tr><tr>
    <td bgcolor="$color{'windowbg'}" align="center"><font size=2><form action="$cgi;action=login2" method="POST">
    <BR>$txt{'431'}<BR><BR>
    <input type=hidden name="username" value="$member{'username'}">
    <input type=hidden name="passwrd" value="$member{'passwrd1'}">
    <input type=hidden name="cookielength" value="$Cookie_Length">
    <input type=submit value="$txt{'34'}">
    </form></font></td>
  </tr>
</table>

<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr>
    <td bgcolor="$color{'windowbg2'}">
    <BR><BR>
    </td>
  </tr>
</table>

~;
}
  $yytitle="$txt{'245'}";
  &template;
  exit;
}

1;