
###############################################################################
# Security.pl                                                                 #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$securityplver = "1 Gold - SP1";

sub is_admin {
  if($settings[7] ne 'Administrator') { &fatal_error($txt{'1'}); }
}

sub is_admin2 {
  if($settings[7] ne 'Administrator') { &fatal_error($txt{'134'}); }
}

#vot
sub ipok { 
 my ($ip,$mask) = @_; 
 chomp $ip; 
 chomp $mask; 
 
 $mask =~ s/\*/\\d+/g; 
 $mask =~ s/\./\\./g; 
 
 if ($ip =~ /$mask/) { 
   return 1; 
 } 
 return 0; 
} 
# if (ipok($ip,$mask)) { 
#   print("ip Ok\n"); 
# } else { 
#   print("bad ip\n"); 
# } 
#/vot
sub banning {
  # IP BANNING
  fopen(BAN, "$vardir/ban.txt" );
  @entries = <BAN>;
  fclose(BAN);
  foreach $ban_ip (@entries) {
    chomp $ban_ip;
    $str_len = length($ban_ip);
    $comp_ip = substr($user_ip,0,$str_len);
#vot
#    if ($comp_ip eq $ban_ip) {
    if (ipok($user_ip, $ban_ip)) {
#/vot
      fopen(LOG, ">>$vardir/ban_log.txt" );
      print LOG "$user_ip\n";
      fclose(LOG);
      $username = "Guest";
      &fatal_error("$txt{'678'}$txt{'430'}!");
      exit;
    }
  }

  # EMAIL BANNING
  if ($username ne 'Guest') {
    fopen(BAN, "$vardir/ban_email.txt" );
    @entries = <BAN>;
    fclose(BAN);
    foreach $ban_email (@entries) {
      chomp $ban_email;
      if (lc $ban_email eq lc $settings[2]) {
        fopen(LOG, ">>$vardir/ban_log.txt" );
        print LOG "$ban_email ($user_ip)\n";
        fclose(LOG);
        $username = "Guest";
        &fatal_error("$txt{'678'}$txt{'430'}!");
        exit;
      }
    }
    # USERNAME BANNING
    if ($username ne 'Guest') {
      fopen(BAN, "$vardir/ban_memname.txt" );
      @entries = <BAN>;
      fclose(BAN);
      foreach $ban_memname (@entries) {
        chomp $ban_memname;
        if (lc $ban_memname eq lc $settings[1]) {
          fopen(LOG, ">>$vardir/ban_log.txt" );
          print LOG "$ban_memname ($user_ip)\n";
          fclose(LOG);
          $username = "Guest";
          &fatal_error("$txt{'678'}$txt{'430'}!");
          exit;
        }
      }
    }
  }
}

sub CheckIcon {
  # Check the icon so HTML cannot be exploited.
  # Do it in 3 unless's because 1 is too long :D
  $icon =~ s~[^A-Za-z]~~g;
  $icon =~ s~\\~~g;
  $icon =~ s~\/~~g;
  unless($icon eq "xx" || $icon eq "thumbup" || $icon eq "thumbdown" || $icon eq "exclamation") {
    unless($icon eq "question" || $icon eq "lamp" || $icon eq "smiley" || $icon eq "angry") {
      unless($icon eq "cheesy" || $icon eq "laugh" || $icon eq "sad" || $icon eq "wink") {
        $icon = "xx";
      }
    }
  }
}

1;