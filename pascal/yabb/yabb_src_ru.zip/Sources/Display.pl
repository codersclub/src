###############################################################################
# Display.pl                                                                  #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$displayplver = "1 Gold - SP1";

sub Display {
  my $viewnum = $INFO{'num'};
  if( $viewnum =~ /\D/ ) {
    &fatal_error($txt{'337'});
  }
  if( $currentboard eq '' ) {
    &fatal_error($txt{'1'});
  }
  $maxmessagedisplay ||= 10;
  my($buffer,$views,$lastposter,$moderators,$counter,$counterwords,$pageindex,$msubthread,$mnum,$mstate,$mdate,$msub,$mname,$memail,$mreplies,$musername,$micon,$noposting,$threadclass,$notify,$max,$start,$bgcolornum,$windowbg,$mattach,$mip,$mlm,$mlmb,$lastmodified,$postinfo,$star,$sendm,$topicdate);
  my(@userprofile,@messages,@bgcolors);

  # Determine what category we are in.
  fopen(FILE, "$boardsdir/$currentboard.ctb") || &fatal_error("300 $txt{'106'}: $txt{'23'} $currentboard.ctb");
  $curcat = <FILE>;
  fclose(FILE);
  #$curcat = $cat;
  fopen(FILE, "$boardsdir/$curcat.cat") || &fatal_error("300 $txt{'106'}: $txt{'23'} $cat.cat");
  $cat = <FILE>;
  fclose(FILE);

  # Load the membergroups list.
  fopen(FILE, "$vardir/membergroups.txt") || &fatal_error("100 $txt{'106'}: $txt{'23'} membergroups.txt");
  @membergroups = <FILE>;
  fclose(FILE);

  # Mark current thread as read.
  ($mnum,$tmpa,$tmpa,$tmpa,$mdate) = split(/\|/,$yyThreadLine);
  &dumplog($mnum,$mdate);

  # Add 1 to the number of views of this thread.
  if(fopen(FILE, "$datadir/$viewnum.data")) {
    $tmpa = <FILE>;
    fclose(FILE);
  }
  elsif( -e "$datadir/$viewnum.data" ) {
    &fatal_error("102 $txt{'106'}: $txt{'23'} $viewnum.data");
  } else {
    $tmpa = '0';
  }
  ($tmpa, $tmpb) = split( /\|/, $tmpa );
  $tmpa++;
  fopen(FILE, "+>$datadir/$viewnum.data") || &fatal_error("103 $txt{'106'}: $txt{'23'} $viewnum.data");
  print FILE qq~$tmpa|$tmpb~;
  fclose(FILE);
  $views = $tmpa - 1;

  # Check to make sure this thread isn't locked.
  ($mnum,$msubthread,$mname,$memail,$mdate,$mreplies,$musername,$micon,$mstate) = split( /\|/, $yyThreadLine );
  $noposting = $viewnum eq $mnum && $mstate == 1 ? 1 : 0;

  # Get the class of this thread, based on lock status and number of replies.
  $replybutton = qq~<a href="$cgi;action=post;num=$viewnum;title=$txt{'116'};start=$start">$img{'reply'}</a>~;
  $threadclass = 'thread';
  if( $mstate == 1 ) {
    $threadclass = 'locked';
    $replybutton = "";
  } elsif( $mreplies > 24 ) {
    $threadclass = 'veryhotthread';
  } elsif( $mreplies > 14 ) {
    $threadclass = 'hotthread';
  } elsif( $mstate == 0 ) {
    $threadclass = 'thread';
  }
  fopen(FILE, "$boardsdir/sticky.stk") || &fatal_error("300 $txt{'106'}: $txt{'23'} sticky.stk");
  @stickys = <FILE>;
  fclose(FILE);
  foreach $curnum (@stickys) {
    if ($mnum == $curnum) {
      if($threadclass eq 'locked') { $threadclass = 'stickylock'; }
      else { $threadclass = 'sticky'; }
    }
  }

  &LoadCensorList;  # Load Censor List

  # Build a list of this board's moderators.
  if( scalar keys %moderators > 0 ) {
    if( scalar keys %moderators == 1 ) { $showmods = qq~($txt{'298'}: ~; }
    else { $showmods = qq~($txt{'299'}: ~; }
    while( $_ = each(%moderators) ) {
      &FormatUserName($_);
      $showmods .= qq~<a href="$scripturl?action=viewprofile;username=$useraccount{$_}">$moderators{$_}</a>, ~;
    }
    $showmods =~ s/, \Z/)/;
  }

  if($enable_notification) {
    my $startnum = $start || '0';
    $notify = qq~$menusep<a href="$cgi;action=notify;thread=$viewnum;start=$startnum">$img{'notify'}</a>~;
  }
  &jumpto;  # create the jumpto list

  # Build the page links list.
  $postdisplaynum = 3;  # max number of pages to display
  $max = $mreplies + 1;
  $start = $INFO{'start'} || 0;
  $start = $start > $mreplies ? $mreplies : $start;
  $start = ( int( $start / $maxmessagedisplay ) ) * $maxmessagedisplay;
  $tmpa = 1;
  $tmpx = int( $max / $maxmessagedisplay );
  if ($start >= (($postdisplaynum-1) * $maxmessagedisplay)) { $startpage = $start - (($postdisplaynum-1) * $maxmessagedisplay); $tmpa = int( $startpage / $maxmessagedisplay ) + 1; }
  if ($max >= $start + ($postdisplaynum * $maxmessagedisplay)) { $endpage = $start + ($postdisplaynum * $maxmessagedisplay); } else { $endpage = $max }
  if ($startpage > 0) { $pageindex = qq~<a href="$cgi;action=display;num=$viewnum;start=0">1</a>&nbsp;...&nbsp;~; }
  if ($startpage == $maxmessagedisplay) { $pageindex = qq~<a href="$cgi;action=display;num=$viewnum;start=0">1</a>&nbsp;~;}
  for( $counter = $startpage; $counter < $endpage; $counter += $maxmessagedisplay ) {
    $pageindex .= $start == $counter ? qq~<b>$tmpa</b>&nbsp;~ : qq~<a href="$cgi;action=display;num=$viewnum;start=$counter">$tmpa</a>&nbsp;~;
    $tmpa++;
  }
  $tmpx = $max - $maxmessagedisplay;
  $outerpn = int($tmpx / $maxmessagedisplay) + 0;
  $lastpn = int($mreplies / $maxmessagedisplay) + 1;
  $lastptn = ($lastpn - 1) * $maxmessagedisplay;
  if ($endpage < $max - ($maxmessagedisplay) ) {$pageindexadd = qq~&nbsp;...&nbsp;~;}
  if ($endpage != $max) {$pageindexadd .= qq~&nbsp;<a href="$cgi;action=display;num=$viewnum;start=$lastptn">$lastpn</a>~;}
  $pageindex .= $pageindexadd;

  foreach (@censored) {
    ($tmpa,$tmpb) = @{$_};
    $msubthread =~ s~\Q$tmpa\E~$tmpb~gi;
  }
  $curthreadurl = $curposlinks ? qq~<a href="$cgi;action=display;num=$viewnum">$msubthread</a>~ : $msubthread;

  # Create next/prev links
  fopen(LISTS, "$boardsdir/$INFO{'board'}.txt");
  @boardtopics = <LISTS>;
  seek LISTS, 0, 0;
  my $found;
  my $name = $INFO{'num'};
  my $bcount = 0;
  $CurrentPosition = -1;
  while($ThreadNum = <LISTS>) {
    ++$CurrentPosition;
    $boardtopics[$bcount] = $ThreadNum;
    $bcount++;
    if ($ThreadNum =~ m/\A$name/o) { $found = 1; last; }
  }
  fclose(LISTS);
  $previous = $boardtopics[$CurrentPosition-1];
  $next = $boardtopics[$CurrentPosition+1];
  @prevthread = split(/\|/, $previous);
  $goprevious = $prevthread[0];
  @nextthread = split(/\|/, $next);
  $gonext = $nextthread[0];
  @getlastthread = @boardtopics;
  $lastthread = pop(@getlastthread);
  @lasttopic = split(/\|/, $lastthread);
  $endthread2 = $lasttopic[0];
  if($found) {
    $prevtopic = "$cgi;action=display;num=$goprevious";
    $nexttopic = "$cgi;action=display;num=$gonext";
    $endthread = "$cgi;action=display;num=$endthread2";
  }
  if ($endthread eq $prevtopic && $gonext eq "") { $nav = qq~&#171; $txt{'766'} | $txt{'766'}&nbsp;&#187;~; }
  if ($endthread eq $prevtopic && $gonext ne "") { $nav = qq~&#171; $txt{'766'} | <a href="$nexttopic">$txt{'767'}</a>&nbsp;&#187;~; }
  if ($endthread ne $prevtopic && $gonext eq "") { $nav = qq~&#171; <a href="$prevtopic">$txt{'768'}</a> | $txt{'766'}&nbsp;&#187;~; }
  if ($endthread ne $prevtopic && $gonext ne "") { $nav = qq~&#171; <a href="$prevtopic">$txt{'768'}</a> | <a href="$nexttopic">$txt{'767'}</a>&nbsp;&#187;~;   }

#vot   Write the Awards JavaScript for Moderators
#  if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
#    $yymain .= qq~
#<script language="JavaScript"><!--
#var newaward = ''; var wid;
#//function ShowVar() { alert(myvalue); }
#function doaward(username) {
# newaward = '';
# wid = window.open('','awardwindow',"menubar=no,scrollbars=no,status=no,width=250,height=180");
# if (!wid.opener) wid.opener = this.window;
# wid.document.writeln("<title>�������</title"+"><"+"script language='JavaScript'><"+"!--");
# wid.document.writeln("function SetAward(what) {");
# wid.document.writeln("  var ind = what.awards.selectedIndex;");
# wid.document.writeln("  var myvalue=what.awards.options[ind].text;");
# wid.document.writeln("  opener.myvalue=myvalue;");
# wid.document.writeln("  self.close(); return false;");
# wid.document.writeln("}//--"+"><"+"/script><center><form myf onSubmit='return SetAward(this);'>");
# wid.document.writeln("������� ���<br><b>"+username+"</b><br>");
# wid.document.writeln("<select name=awards size=6>");
# wid.document.writeln("<option selected>[\&nbsp;\&nbsp;\&nbsp;\*\&nbsp;\&nbsp;] set Asterisk</option>");
# wid.document.writeln("<option>[\&nbsp; \+ \&nbsp;] set Plus</font></option>");
# wid.document.writeln("<option>[\&nbsp;\&nbsp;\&nbsp;\!\&nbsp;\&nbsp;] set Exclamation</option>");
# wid.document.writeln("<option>[ \&nbsp;\~ ] remove Asterisk ( \* )</option>");
# wid.document.writeln("<option>[\&nbsp;\&nbsp;\&nbsp;\-\&nbsp;\&nbsp;] remove Plus ( \+ )</option>");
# wid.document.writeln("<option>[\&nbsp;\&nbsp;\#\&nbsp;\&nbsp;] remove Exclamation ( \! )</option>");
# wid.document.writeln("</select><br><input type=submit value=' Ok '>\&nbsp;");
# wid.document.writeln("<input type=button value='Cancel' onclick='self.close();'>");
# wid.document.writeln("</form></center>");
#//'$cgi;action=awards;username='+username
# return false;
#}//--></script>
#~;
#  }
#
  $yymain .= qq~
<script language="JavaScript1.2" src="$ubbcjspath" type="text/javascript"></script>
<table border="0" width="100%" cellpadding="0" cellspacing="0">
  <tr bgcolor="$color{'windowbg2'}">
    <td valign=bottom colspan="2">
    <br>
    <font size="2">
    <img src="$imagesdir/open.gif" border="0" alt="">&nbsp;&nbsp;
    <a href="$scripturl">$mbname</a>
    <br>
    <img src="$imagesdir/tline.gif" border="0" alt=""><IMG SRC="$imagesdir/open.gif" border="0" alt="">&nbsp;&nbsp;
    <a href="$scripturl#$curcat">$cat</a>
    <br>
    <img src="$imagesdir/tline2.gif" border="0" alt=""><IMG SRC="$imagesdir/open.gif" border="0" alt="">&nbsp;&nbsp;
    <a href="$cgi">$boardname</a> <font size="1">$showmods</font>
    </td></tr>
  <tr bgcolor="$color{'windowbg2'}">
    <td><img SRC="$imagesdir/tline3.gif" border="0" alt=""><IMG SRC="$imagesdir/open.gif" border="0" alt="">&nbsp;&nbsp;
    <font size="2"><b>$curthreadurl</b></font></td>
    <td valign="bottom" align="right"><font size="1">$nav</font></td>
  </tr>
</table>
~;

if ($boardfaqtxt) {
  $yymain .= qq~
<table border=0 width="100%" cellspacing="0" cellpadding="0">
  <tr>
    <td>
    <table cellpadding="4" cellspacing="1" border="0" width="100%">
      <tr>
        <td align="left" bgcolor="$color{'catbg'}" width="100%">
        <table cellpadding="3" cellspacing="0" width="100%">
          <tr>
            <td align="right">$boardfaqtxt</td>
          </tr>
        </table>
        </td>
      </tr>
    </table>
    </td>
  </tr>
</table>
~;
}

$yymain .= qq~
<table border="0" width="100%" cellspacing="1" cellpadding="0">
  <tr>
    <td>
    <table border="0" cellpadding="4" cellspacing="0" width="100%">
      <tr bgcolor="$color{'catbg'}">
        <td><font size="2"><b>$txt{'139'}:</b> $pageindex</font></td>
        <td align="right">
        $replybutton$notify$menusep
        <a href="$cgi;action=sendtopic;topic=$viewnum">$img{'sendtopic'}</a>$menusep
        <a href="$cgi;action=print;board=$currentboard;num=$viewnum" target="_blank">$img{'print'}</a>
        $menusep<a href="$cgi;action=post;title=$txt{'464'}">$img{'newthread'}</a>
        </td>
      </tr>
    </table>
  </td></tr>
  <tr>
    <td>
    <table cellpadding="3" cellspacing="0" border="0" width="100%">
      <tr bgcolor="$color{'titlebg'}">
        <td valign="middle" align="left" width="15%">
        <font size=2 color="$color{'titletext'}">&nbsp;<img src="$imagesdir/$threadclass.gif" alt="">
        &nbsp;<b>$txt{'29'}</b></font></td>
        <td valign="middle" align="left">
        <font size="2" color="$color{'titletext'}"><b>&nbsp;$msubthread</b> &nbsp;($txt{'641'} $views )</font></td>
      </tr>
    </table>
    </td>
  </tr>
~;

  # Load background color list.
  @bgcolors = ( $color{windowbg}, $color{windowbg2} );
  $bgcolornum = scalar @bgcolors;
  @cssvalues = ( "windowbg","windowbg2" );
  $cssnum = scalar @bgcolors;

  if(!$MenuType) { $sm = 1; }
  $counter = 0;

  fopen(FILE,"$datadir/$viewnum.txt") || &fatal_error("104 $txt{'106'}: $txt{'23'} $viewnum.txt");

  # Skip past the posts in this thread until we reach $start.
  while($counter < $start && ($buffer = <FILE>)) { $counter++; }

  $#messages = $maxmessagedisplay - 1;
  for($counter = 0; $counter < $maxmessagedisplay && ($buffer = <FILE>); $counter++) {
    $messages[$counter] = $buffer;
  }
  fclose(FILE);
  $#messages = $counter - 1;
  $counter = $start;



######################################
#### For each post in this thread:

  foreach (@messages) {
    $windowbg = $bgcolors[($counter % $bgcolornum)];
    $css = $cssvalues[($counter % $cssnum)];
    chomp;
    ($msub, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $postmessage, $ns, $mlm, $mlmb, $msglocked) = split(/[\|]/, $_);
    # Should we show "last modified by?"
    if( $mlm && $showmodify && $mlm ne "" && $mlmb ne "") {
      $mlm = &timeformat($mlm);
      &LoadUser($mlmb);
      $mlmb = $userprofile{$mlmb}->[1] || $mlmb || $txt{'470'};
      $lastmodified = qq~&#171; <i>$txt{'211'} $mlm $txt{'525'} $mlmb</i> &#187;~;
    } else {
      $mlm = '-';
      $lastmodified = '';
    }
    $msub ||= $txt{'24'};
    $messdate = &timeformat($mdate);

#vot   Show IP address Enabled for Admins and Moderators
#    if(exists $moderators{$username} || $settings[7] eq 'Administrator' || $username eq $musername) {
#vot   Show IP address Enabled for Admins only
    if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
      $mip = "<br>$mip";
    } else {
      $mip = '';
    }
    $sendm = '';
    $awards = "";

    # If the user isn't a guest, load his/her info.
    if($musername ne 'Guest' && ! $yyUDLoaded{$musername} && -e("$memberdir/$musername.dat") ) {
      &LoadUserDisplay($musername);  # If user is not in memory, s/he must be loaded.
    }
    if($yyUDLoaded{$musername}) {
      @userprofile = @{$userprofile{$musername}};
      $star = $memberstar{$musername};
      $awards = showawards($userprofile[44]);
      $memberinfo = $memberinfo{$musername};
      $memberinfo =~ s~\n~~g;
      $icqad = $icqad{$musername};
      $yimon = $yimon{$musername};
      if($username ne 'Guest') {
        # Allow instant message sending if current user is a member.
        $sendm = qq~$menusep<a href="$cgi;action=imsend;to=$useraccount{$musername}">$img{'message_sm'}</a>~;
      }
      $usernamelink = qq~<a href="$scripturl?board=$currentboard;action=viewprofile;username=$useraccount{$musername}"><font size="2"><b>$userprofile[1]</b></font></a>~;
      $postinfo = qq~$txt{'26'}: $userprofile[6]<br>~;
      $memail = $userprofile[2];
    } else {
      $musername = "Guest";
      $star = '';
      $memberinfo = "$txt{'28'}";
      $icqad = '';
      $yimon = '';

      #vot link to e-mail for Guests
      $usernamelink = qq~<a href="mailto:$memail"><font size="2" color=black><b>$mname</b></font></a>~;
      #/vot

      $postinfo = '';
      @userprofile = ();
    }
    # Censor the subject and message.
    foreach (@censored) {
      ($tmpa,$tmpb) = @{$_};
      $postmessage =~ s~\Q$tmpa\E~$tmpb~gi;
      $msub =~ s~\Q$tmpa\E~$tmpb~gi;
    }

    # Run UBBC interpreter on the message.
    $message = $postmessage; # put the message back into the proper variable to do ubbc on it

    &wrap;
    if($enable_ubbc) { if(!$yyYaBBCloaded) { require "$sourcedir/YaBBC.pl"; } &DoUBBC; }
    &wrap2;
    $profbutton = $profilebutton && $musername ne 'Guest' ? qq~<a href="$scripturl?action=viewprofile;username=$useraccount{$musername}">$img{'viewprofile_sm'}</a>$menusep~ : '';
#    if($counter != 0) { $counterwords = "$txt{'146'} #$counter"; }
    if($counter != 0) {
      $counterwords = "#$counter";
    } else { $counterwords = ""; }


### Print the post and user info for the poster.
    $yymain .= qq~
<a name="$counter"></a>
      <tr>
        <td>
        <table border="0" width='100%' cellpadding='4' cellspacing='0'>
          <tr bgcolor="$windowbg">
            <td valign="top" width="15%"><font size="1">
            $usernamelink
~;

# Show User Status Stars
  if(($musername ne "Guest") && $settings[32]) {
    $yymain .= "<BR>$star";
  }
# Show User Status as Text
  $yymain .= "<br>$memberinfo";

# Show User Picture
  if(($musername ne "Guest") && $settings[29]) {
    $yymain .= qq~    <BR>$userprofile[12]$userprofile[13]
~;
  }

# Gender, E-mail, ICQ, Web-page
#vot  if($musername ne "Guest") {
#    $yymain .= qq~
#            <br>$star<BR><BR>
#            $userprofile[13]$userprofile[12]
#            <BR>$userprofile[8] $icqad &nbsp; $userprofile[10] $yimon &nbsp; $userprofile[9]<BR>
#~;
#  }

#vot Set Award Button
    if ($awards) {
      $yymain .= qq~<br><b>$awards</b> ~;
    }

#vot   Show IP address Enabled for Admins and Moderators
    if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
      $yymain .= qq~$mip~;
    }

#  if($musername eq "Guest") {
#    $yymain .= qq~
#            <BR><a href="mailto:$memail">$img{'email_sm'}</a><BR><BR>
#~;
#  }
#  elsif ($userprofile[19] ne "checked" || $settings[7] eq "Administrator" || $allow_hide_email ne 1) {
#    $yymain .= qq~
#            $profbutton$userprofile[4] <a href="mailto:$memail">$img{'email_sm'}</a>$sendm<BR><BR>
#~;
#  } else {
#    $yymain .= qq~
#    $profbutton$userprofile[4]$sendm<BR><BR>
#~;
#  }

# Gender
#  $yymain .= qq~
#            $userprofile[11]
#            $postinfo

    if ($msglocked) {$micon = 'lock'}

    $yymain .= qq~
            </font></td>
            <td valign="top" width="86%">
            <table border='0' width='100%' cellpadding="0" cellspacing="0">
              <tr align="left" valign="middle">
                <td><img src="$imagesdir/$micon.gif" alt=""></td>
                <td>
                <font size="1"><B>$counterwords</B>&nbsp; $messdate</font></td>
                <td align="right" nowrap>
~;

#vot Just Temporarly!!!!!
#$msglocked = 0;

if ($mstate != 1 ) { # If the Message is NOT Locked
   $yymain .= qq~
    <a href="$cgi;action=post;num=$viewnum;quote=$counter;title=$txt{'116'};start=$start">$img{'replyquote'}</a>
~;
#vot Admin and Moderator CAN write to any message in the thread!
  if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
    $yymain .= qq~
     $menusep<a href="$cgi;action=modify;message=$counter;thread=$viewnum">$img{'modify'}</a>
     $menusep<a href="javascript:DoConfirm('$txt{'739'}','$cgi;action=modify2;thread=$viewnum;id=$counter;d=1')">$img{'delete'}</a>
~;
#vot Admin and Moderator CAN set any AWARDS to the User!
#    $yymain .= qq~
#        $menusep<a style="cursor:hand;" onClick="javascript:doaward(\'$useraccount{$musername}\');">$img{'awards'}</a>
#    ~;

  } elsif ($username eq $musername) {
    if(!$msglocked) {
      $yymain .= qq~
        $menusep<a href="$cgi;action=modify;message=$counter;thread=$viewnum">$img{'modify'}</a>
        $menusep<a href="javascript:DoConfirm('$txt{'739'}','$cgi;action=modify2;thread=$viewnum;id=$counter;d=1')">$img{'delete'}</a>
    ~;
    }
  }
} else {  
#vot The Thread is closed! BUT...
# Admin and Moderator CAN write to closed thread!
  if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
    $yymain .= qq~
                <a href="$cgi;action=post;num=$viewnum;quote=$counter;title=$txt{'116'};start=$start">$img{'replyquote'}</a>
        $menusep<a href="$cgi;action=modify;message=$counter;thread=$viewnum">$img{'modify'}</a>
        $menusep<a href="javascript:DoConfirm('$txt{'739'}','$cgi;action=modify2;thread=$viewnum;id=$counter;d=1')">$img{'delete'}</a>
~;
  }
} # if ($mstate != 1)

#vot Convert umlauts to form &#nnn;
$message  =~ s/\&amp;\#(\d+);/\&\#$1;/g;
#vot

    $yymain .= qq~
                </td>
              </tr>
            </table>
            <hr width="100%" size="1">
            <font size="2">
            $message
            </font>
            <font size="1">
            $userprofile[5]
            </font>
          </td>
        </tr>
      </table>
    </td>
  </tr>
~;

#vot    <tr>
#            <td class="$css" bgcolor="$windowbg" valign="bottom">
#            <table width="100%" border="0">
#              <tr>
#                <td align="left"><font size="1">$lastmodified</font></td>
#                <td align="right"><font size="1"><img src="$imagesdir/ip.gif" alt="" border="0"> $mip</font></td>
#              </tr>
#            </table>
#            <font size="1">
#            $userprofile[5]
#            </font></td>
#          </tr>

    $counter++;
  } #foreach (@messages)

  $yymain .= qq~
  <tr>
    <td bgcolor="$color{'bordercolor'}">
    <table border="0" cellpadding="4" cellspacing="0" width="100%">
      <tr bgcolor="$color{'catbg'}">
        <td><font size="2"><b>$txt{'139'}:</b> $pageindex</font></td>
        <td><font size="2"><a href="#top"><b>$txt{'gotop'}</b></a></font></td>
      <td align="right" width="350">
        $replybutton$notify$menusep
        <a href="$cgi;action=sendtopic;topic=$viewnum">$img{'sendtopic'}</a>$menusep
        <a href="$cgi;action=print;board=$currentboard;num=$viewnum" target="_blank">$img{'print'}</a>
        </td>
      </tr>
    </table>
  </td></tr>
</table>
~;


### Move, Delete, Lock, Sticky Thread - for Moders and Admin

 if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
   $adminmenu = qq~&nbsp;<a href="$cgi;action=movethread;thread=$viewnum"><b>$img{'admin_move'}</b></a>
   $menusep <a href="javascript:DoConfirm('$txt{'162'}','$cgi;action=removethread;thread=$viewnum')"><b>$img{'admin_rem'}</b></a>
   $menusep <a href="$cgi;action=lock;thread=$viewnum"><b>$img{'admin_lock'}</b></a>
   $menusep <a href="$cgi;action=sticky;thread=$viewnum"><b>$img{'admin_sticky'}</b></a>
~;
#
#vot   Sticky Enabled for Admins and Moderators
#    if(exists $moderators{$username} || $settings[7] eq 'Administrator') {
#vot   Sticky Enabled for Admins only
#    if($settings[7] eq 'Administrator') {
#      $adminmenu .= qq~
#      $menusep <a href="$cgi;action=sticky;thread=$viewnum"><b>$img{'admin_sticky'}</b></a>
#~;
#  <br>\$showreplythread \= $settings[20]
#  <br>\$disablesmiles \= $settings[21]
#  <br>\$enalecodebuttons \= $settings[22]
#  <br>\$showfastreply \= $settings[45]
#    }
  } else {
    $img{'admin_func'} = "\&nbsp;";
  }

 #vot  CALL THE MODERATOR!!!
 if ($username ne 'Guest') {
    $img{'admin_func'} =  qq~&nbsp;<a href="$cgi&action=reporttm&num=$viewnum&subject=$msubthread"><b>$rtm{'1'}</b></a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;~ . $img{'admin_func'};
 }

#/vot

  $yymain .= qq~
<table border="0" width="100%" cellpadding="0" cellspacing="0">
  <tr bgcolor="$color{'windowbg2'}">
    <td align="left" valign="top">&nbsp;<font size="1">
    $img{'admin_func'}
    </td>
    <td valign="top" align="right" nowrap><font size="1">$nav</font></td>
  </tr>
  <tr bgcolor="$color{'windowbg2'}">
    <td align="left" valign="top">&nbsp;<font size="1">
    $adminmenu
    </td>
    <td valign="top" align="right"><font size="1">$selecthtml</font></td></tr>
</table>
~;


########################################################################
#vot - START THE FAST REPLY

  $nscheck="";
  if ($settings[21]) {
    $nscheck="checked";
  }

  $showfastreply = $settings[45]; 
  if ($mstate != 1 && $showfastreply) { # If the Message is NOT Locked
#  if ($mstate != 1 ) { # If the Message is NOT Locked
    $yymain .= qq~
<table border=0 width="100%" cellspacing="1" cellpadding="0" align="center">
  <tr>
    <td>
<form action="$cgi;action=post2" method="post" name="postmodify" onSubmit="submitonce(this);">
<input type="hidden" name="threadid" value="$viewnum">
<input type="hidden" name="icon" value="xx">

      <table border=0 cellspacing=0 cellpadding=3 width="100%">
        <tr>
          <td><font size=2 color="$color{'titletext'}"><b>$txt{'fastreply'}</b></font></td>
        </tr>
      </table>
    </td>
  </tr><tr>
    <td>
      <table border="0" width="100%" cellpadding="3" cellspacing="0">
      <tr bgcolor="$color{'windowbg'}">
        <td width="20%"><font size=2><b>$txt{'70'}:</b></font></td>
        <td><font size=2><input type=text name="subject" value="$msubthread" readonly size="40" maxlength="50" tabindex="1"></font></td>
      </tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
    <table border="0" width="100%" cellpadding="3" cellspacing="0">
~;

    $showyabbcbutt = $settings[22];
    if($enable_ubbc && $showyabbcbutt) {
      $yymain .= qq~
      <tr bgcolor="$color{'windowbg2'}">
        <td width="20%"><font size=2><b>$txt{'252'}:</b></font></td>
        <td valign=middle>
        <script language="JavaScript1.2" type="text/javascript">
        <!--
        if((navigator.appName == "Netscape" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Opera" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "WebTV Plus Receiver" && navigator.appVersion.charAt(0) >= 3) || (navigator.appName == "Konqueror")) {
          document.write("<a href=javascript:bold()><img src='$imagesdir/bold.gif' align=bottom width=23 height=22 alt='$txt{'253'}' border=0></a>");
          document.write("<a href=javascript:italicize()><img src='$imagesdir/italicize.gif' align=bottom width=23 height=22 alt='$txt{'254'}' border='0'></a>");
          document.write("<a href=javascript:underline()><img src='$imagesdir/underline.gif' align=bottom width=23 height=22 alt='$txt{'255'}' border='0'></a>");
          document.write("<a href=javascript:strike()><img src='$imagesdir/strike.gif' align=bottom width=23 height=22 alt='$txt{'441'}' border='0'></a>");
          document.write("<a href=javascript:glow()><img src='$imagesdir/glow.gif' align=bottom width=23 height=22 alt='$txt{'442'}' border='0'></a>");
          document.write("<a href=javascript:shadow()><img src='$imagesdir/shadow.gif' align=bottom width=23 height=22 alt='$txt{'443'}' border='0'></a>");
          document.write("<a href=javascript:move()><img src='$imagesdir/move.gif' align=bottom width=23 height=22 alt='$txt{'439'}' border='0'></a>");
          document.write("<a href=javascript:pre()><img src='$imagesdir/pre.gif' align=bottom width=23 height=22 alt='$txt{'444'}' border='0'></a>");
          document.write("<a href=javascript:left()><img src='$imagesdir/left.gif' align=bottom width=23 height=22 alt='$txt{'445'}' border='0'></a>");
          document.write("<a href=javascript:center()><img src='$imagesdir/center.gif' align=bottom width=23 height=22 alt='$txt{'256'}' border='0'></a>");
          document.write("<a href=javascript:right()><img src='$imagesdir/right.gif' align=bottom width=23 height=22 alt='$txt{'446'}' border='0'></a>");
          document.write("<a href=javascript:hr()><img src='$imagesdir/hr.gif' align=bottom width=23 height=22 alt='$txt{'531'}' border='0'></a>");
          document.write("<a href=javascript:size()><img src='$imagesdir/size.gif' align=bottom width=23 height=22 alt='$txt{'532'}' border='0'></a>");
          document.write("<a href=javascript:font()><img src='$imagesdir/face.gif' align=bottom width=23 height=22 alt='$txt{'533'}' border='0'></a>");
        }
        else { document.write("<font size='1'>$txt{'215'}</font>"); }
        //-->
        </script>
        <noscript>
        <font size="1">$txt{'215'}</font>
        </noscript>
        <select name="color" onChange="showcolor(this.options[this.selectedIndex].value)">
         <option value="Black" selected>$txt{'262'}</option>
         <option value="Red">$txt{'263'}</option>
         <option value="Yellow">$txt{'264'}</option>
         <option value="Pink">$txt{'265'}</option>
         <option value="Green">$txt{'266'}</option>
         <option value="Orange">$txt{'267'}</option>
         <option value="Purple">$txt{'268'}</option>
         <option value="Blue">$txt{'269'}</option>
         <option value="Beige">$txt{'270'}</option>
         <option value="Brown">$txt{'271'}</option>
         <option value="Teal">$txt{'272'}</option>
         <option value="Navy">$txt{'273'}</option>
         <option value="Maroon">$txt{'274'}</option>
         <option value="LimeGreen">$txt{'275'}</option>
        </select>
        <br>
        <script language="JavaScript1.2" type="text/javascript">
        <!--
        if((navigator.appName == "Netscape" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Opera" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "WebTV Plus Receiver" && navigator.appVersion.charAt(0) >= 3) || (navigator.appName == "Konqueror")) {
          document.write("<a href=javascript:flash()><img src='$imagesdir/flash.gif' align=bottom width=23 height=22 alt='$txt{'433'}' border='0'></a>");
          document.write("<a href=javascript:hyperlink()><img src='$imagesdir/url.gif' align=bottom width=23 height=22 alt='$txt{'257'}' border='0'></a>");
          document.write("<a href=javascript:ftp()><img src='$imagesdir/ftp.gif' align=bottom width=23 height=22 alt='$txt{'434'}' border='0'></a>");
          document.write("<a href=javascript:image()><img src='$imagesdir/img.gif' align=bottom width=23 height=22 alt='$txt{'435'}' border='0'></a>");
          document.write("<a href=javascript:emai1()><img src='$imagesdir/email2.gif' align=bottom width=23 height=22 alt='$txt{'258'}' border='0'></a>");
          document.write("<a href=javascript:table()><img src='$imagesdir/table.gif' align=bottom width=23 height=22 alt='$txt{'436'}' border='0'></a>");
          document.write("<a href=javascript:trow()><img src='$imagesdir/tr.gif' align=bottom width=23 height=22 alt='$txt{'437'}' border='0'></a>");
          document.write("<a href=javascript:tcol()><img src='$imagesdir/td.gif' align=bottom width=23 height=22 alt='$txt{'449'}' border='0'></a>");
          document.write("<a href=javascript:superscript()><img src='$imagesdir/sup.gif' align=bottom width=23 height=22 alt='$txt{'447'}' border='0'></a>");
          document.write("<a href=javascript:subscript()><img src='$imagesdir/sub.gif' align=bottom width=23 height=22 alt='$txt{'448'}' border='0'></a>");
          document.write("<a href=javascript:teletype()><img src='$imagesdir/tele.gif' align=bottom width=23 height=22 alt='$txt{'440'}' border='0'></a>");
          document.write("<a href=javascript:showcode()><img src='$imagesdir/code.gif' align=bottom width=23 height=22 alt='$txt{'259'}' border='0'></a>");
          document.write("<a href=javascript:quote()><img src='$imagesdir/quote2.gif' align=bottom width=23 height=22 alt='$txt{'260'}' border='0'></a>");
          document.write("<a href=javascript:list()><img src='$imagesdir/list.gif' align=bottom width=23 height=22 alt='$txt{'261'}' border='0'></a>");
          document.write(" <a href=javascript:translit()><img src='$imagesdir/translit.gif' align=bottom width=60 height=22 alt='$txt{'translit'}' border='0'></a>");
        }
        else { document.write("<font size='1'>$txt{'215'}</font>"); }
        //-->
        </script>
        <noscript>
        <font size="1">$txt{'215'}</font>
        </noscript>
        </td>
      </tr>
~;
    }

    ### SMILES ROW
    $yymain .= qq~
      <tr bgcolor="$color{'windowbg2'}">
        <td width="20%"><font size=2><b>$txt{'297'}:</b></font></td>
        <td valign=middle>
        <script language="JavaScript1.2" type="text/javascript">
        <!--
        if((navigator.appName == "Netscape" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Microsoft Internet Explorer" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Opera" && navigator.appVersion.charAt(0) >= 4) || (navigator.appName == "Konqueror")) {
          document.write("<a href=javascript:smiley()><img src='$imagesdir/smiley.gif' align=bottom alt='$txt{'287'}' border='0'></a> ");
          document.write("<a href=javascript:wink()><img src='$imagesdir/wink.gif' align=bottom alt='$txt{'292'}' border='0'></a> ");
          document.write("<a href=javascript:cheesy()><img src='$imagesdir/cheesy.gif' align=bottom alt='$txt{'289'}' border='0'></a> ");
          document.write("<a href=javascript:laugh()><img src='$imagesdir/laugh.gif' align=bottom alt='$txt{'290'}' border='0'></a> ");
          document.write("<a href=javascript:grin()><img src='$imagesdir/grin.gif' align=bottom alt='$txt{'293'}' border='0'></a> ");
          document.write("<a href=javascript:angry()><img src='$imagesdir/angry.gif' align=bottom alt='$txt{'288'}' border='0'></a> ");
          document.write("<a href=javascript:sad()><img src='$imagesdir/sad.gif' align=bottom alt='$txt{'291'}' border='0'></a> ");
          document.write("<a href=javascript:shocked()><img src='$imagesdir/shocked.gif' align=bottom alt='$txt{'294'}' border='0'></a> ");
          document.write("<a href=javascript:cool()><img src='$imagesdir/cool.gif' align=bottom alt='$txt{'295'}' border='0'></a> ");
          document.write("<a href=javascript:huh()><img src='$imagesdir/huh.gif' align=bottom alt='$txt{'296'}' border='0'></a> ");
          document.write("<a href=javascript:rolleyes()><img src='$imagesdir/rolleyes.gif' align=bottom alt='$txt{'450'}' border='0'></a> ");
          document.write("<a href=javascript:tongue()><img src='$imagesdir/tongue.gif' align=bottom alt='$txt{'451'}' border='0'></a> ");
          document.write("<a href=javascript:embarassed()><img src='$imagesdir/embarassed.gif' align=bottom alt='$txt{'526'}' border='0'></a> ");
          document.write("<a href=javascript:lipsrsealed()><img src='$imagesdir/lipsrsealed.gif' align=bottom alt='$txt{'527'}' border='0'></a> ");
          document.write("<a href=javascript:undecided()><img src='$imagesdir/undecided.gif' align=bottom alt='$txt{'528'}' border='0'></a> ");
          document.write("<a href=javascript:kiss()><img src='$imagesdir/kiss.gif' align=bottom alt='$txt{'529'}' border='0'></a> ");
          document.write("<a href=javascript:cry()><img src='$imagesdir/cry.gif' align=bottom alt='$txt{'530'}' border='0'></a> ");
        }
        else { document.write("<font size='1'>$txt{'215'}</font>"); }
        //-->
        </script>
        <noscript>
        <font size="1">$txt{'215'}</font>
        </noscript>
        </td>
      </tr>
      <!-- TEXTAREA ROW -->
      <tr bgcolor="$color{'windowbg2'}">
        <td valign=top width="20%"><font size=2><b>$txt{'72'}:</b></font></td>
        <td><font size="2"><TEXTAREA COLS='90' rows='16' width='90'
            name=message tabIndex=4></TEXTAREA>
          </font><BR><BR></td>
      </tr>
    </table>
    </td>
  </tr>
  <!-- NOSMILES ROW -->
  <tr>
    <td>
    <table border="0" width="100%" cellpadding="3" cellspacing="0">
      <tr bgcolor="$color{'windowbg'}">
        <td width="20%"><font size=2><b>$txt{'276'}:</b></font><BR><BR></td>
        <td><input type=checkbox name="ns" value="NS" $nscheck> <font size="1"> $txt{'277'}</font><BR><BR></td>
        <td align="right"><font size="2"><a href="#top"><b>$txt{'gotop'}</b></a></font>&nbsp;</td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<table border=0 cellspacing=0 cellpadding=0 width="100%">
  <tr>
    <td align="center" bgcolor="$color{'windowbg2'}">
    <font size="1">$txt{'329'}</font><BR>
    <input type="submit" name="$post" value="$txt{'105'}" accesskey="s">
    <input type="reset" value="$txt{'278'}" accesskey="r">
    <br><br>
    </td>
  </tr>
  </form>
</table>
~;
#vot - end of Fast Reply
#############################

  }
  $yymain .= qq~
<table border="0" width="100%" cellpadding="0" cellspacing="0">
  <tr bgcolor="$color{'windowbg2'}">
    <td>&nbsp;</td>
  </tr>
</table>
~;

  $yytitle = $msubthread;
  &template;
  exit;
}

1;