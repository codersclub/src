###############################################################################
# Search.pl                                                                   #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$searchplver = "1 Gold - SP1";

sub plushSearch1 {
  my( @categories, %cat, $curcat, %catname, %cataccess, %catboards, $openmemgr, @membergroups, $tmpa, %openmemgr, $curboard, @threads, @boardinfo, $counter );
  @categories = ();
  fopen(FILE, "$vardir/cat.txt");
  @categories = <FILE>;
  fclose(FILE);
  &LoadCensorList;  # Load Censor List

  $searchpageurl = $curposlinks ? qq~<a href="$scripturl?action=search">$txt{'182'}</a>~ : $txt{'182'};
#  $extsearchurl = $curposlinks ? qq~<a href="$scripturl?action=search">$txt{'extsearch'}</a>~ : $txt{'extsearch'};
  $extsearchurl = $curposlinks ? qq~<a href="$scripturl?action=search">$txt{'extsearch'}</a>~ : $txt{'182'};
  $yymain .= qq~
<script language="JavaScript1.2" type="text/javascript">
<!-- Begin
function changeBox(cbox) {
  box = eval(cbox);
  box.checked = !box.checked;
}
function checkAll() {
  for (var i = 0; i < document.searchform.elements.length; i++) {
    if(document.searchform.elements[i].name != "subfield" && document.searchform.elements[i].name != "msgfield") {
        document.searchform.elements[i].checked = true;
      }
  }
}
function uncheckAll() {
  for (var i = 0; i < document.searchform.elements.length; i++) {
    if(document.searchform.elements[i].name != "subfield" && document.searchform.elements[i].name != "msgfield") {
        document.searchform.elements[i].checked = false;
      }
  }
}
//-->
</script>
<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td bgcolor="$color{'windowbg2'}"><br>
<table align="center" width="100%" border="0" cellpadding="2" cellspacing="1">
  <tr>
    <td><font size=2><img src="$imagesdir/open.gif" BORDER=0>&nbsp;
    <b><a href="$scripturl">$mbname</a></b>
    <br><img src="$imagesdir/tline.gif" BORDER=0><img src="$imagesdir/open.gif" border=0>&nbsp;
    <b>$extsearchurl</b></font></td>
  </tr>
</table>
<table border=0 width="100%" align="center" cellspacing="0" cellpadding="0">
<tr><td bgcolor="$color{'bordercolor'}">

<table border=0 width="100%" align="center" cellspacing="1" cellpadding="0">
  <form action="$scripturl?action=search2" method="post" name="searchform">
  <tr bgcolor="$color{'titlebg'}">
    <td><img src="$imagesdir/search.gif" alt=""> <font size=2 color="$color{'titletext'}"><b>$txt{'183'}</b></font></td>
  </tr>
  <tr bgcolor="$color{'windowbg'}">
    <td>
      <table border=0 width="100%" cellspacing="0" cellpadding="4">
	<tr>
	  <td width="30%"><font size=2><b>$txt{'582'}:</b></font></td>
	  <td width="35%"><font size=2>
	    <input type=text size=30 name="search">&nbsp;</font></td>
	  <td width="35%"><font size=2>
	    <select name="searchtype">
	    <option value="allwords" selected>$txt{'343'}</option>
	    <option value="anywords">$txt{'344'}</option>
	    <option value="asphrase">$txt{'345'}</option>
	    </select></font></td>
	</tr>
	<tr>
	  <td><font size=2><b>$txt{'583'}:</B></font></td>
	  <td><font size=2>
	    <input type=text size=30 name="userspec">&nbsp;</font></td>
          <td><font size=2>
	    <select name="userkind">
	    <option value="any" selected>$txt{'577'}</option>
	    <option value="starter">$txt{'186'}</option>
	    <option value="poster">$txt{'187'}</option>
	    <option value="noguests">$txt{'346'}</option>
	    <option value="onlyguests">$txt{'572'}</option>
	    </select></font></td>
	</tr>
      	<tr>
      	  <td><font size=2><b>$txt{'573'}:</B></font></td>
      	  <td><font size="2"><input type=checkbox name=subfield value=on checked><span id="spansubfield" style="cursor:hand;" onClick="changeBox('document.searchform.subfield')">$txt{'70'}</span></font></td>
      	  <td><font size="2"><input type=checkbox name=msgfield value=on checked><span id="spanmsgfield" style="cursor:hand;" onClick="changeBox('document.searchform.msgfield')">$txt{'72'}</span></font></td>
        </tr>
      </table>	
    </td>
  </tr><tr bgcolor="$color{'windowbg2'}">
    <td>
      <table border=0 width="100%" cellspacing="0" cellpadding="4">
	<tr>
          <td width="30%"><font size=2><b>$txt{'189'}:</B></font></td>
          <td width="70%">
            <table border="0" width="100%" cellpadding="1" cellspacing="4">
              <tr>
~;
  $counter = 1;
  foreach $curcat (@categories) {
    chomp $curcat;
    fopen(FILE, "$boardsdir/$curcat.cat");
    $catname{$curcat} = <FILE>;
    chomp $catname{$curcat};
    $cataccess{$curcat} = <FILE>;
    chomp $cataccess{$curcat};
    @{$catboards{$curcat}} = <FILE>;
    fclose(FILE);
    $openmemgr{$curcat} = 0;
    @membergroups = split( /,/, $cataccess{$curcat} );
    foreach $tmpa (@membergroups) {
      if( $tmpa eq $settings[7]) { $openmemgr{$curcat} = 1; last; }
    }
    if( ! $cataccess{$curcat} || $settings[7] eq 'Administrator' ) {
      $openmemgr{$curcat} = 1;
    }
    unless( $openmemgr{$curcat} ) { next; }
boardcheck: foreach $curboard (@{$catboards{$curcat}}) {
      chomp $curboard;
      fopen(FILE, "$boardsdir/$curboard.dat");
      @boardinfo = <FILE>;
      fclose(FILE);
      chomp @boardinfo;
      @{$boardinfo{$curboard}} = @boardinfo;
      $cat{$curboard} = $curcat;
      $yymain .= qq~<td width="50%"><font size="2"><input type=checkbox name="brd$counter" value="$curboard" checked><span id="spanbrd$counter" style="cursor:hand;" onClick="changeBox('document.searchform.brd$counter')">$boardinfo[0]</span></font></td>~;
      unless( $counter % 2 ) { $yymain .= qq~</tr><tr>~; }
      ++$counter;
    }
  }
  $yymain .= qq~
      	      </tr>
	      <tr><td colspan=2 align=center>
	        <INPUT TYPE="checkbox" ONCLICK="if (this.checked) checkAll(); else uncheckAll();" checked><font size="2">&nbsp;<b>$txt{'737'}</b></font>
	        </td>
              </tr>
            </table>
          </td>
        </tr>
      </table>
    </td>
  </tr>
  <tr bgcolor="$color{'windowbg'}">
    <td>
      <table border=0 width="100%" cellspacing="0" cellpadding="4">
	<tr>
	  <td width="65%"><font size=2><B>$txt{'576'} $txt{'574'}:</B></font></td>
	    <input type=hidden name=minripe value=0>
	    <input type=hidden name=minage value=0>
	  <td><font size=2>
	    <input type=hidden name=maxripe value=0>
	    <input type=text name=maxage value=1000 size=5 maxlength=5> $txt{'579'}
	    </font></td>
        </tr>
	<tr>
	  <td width="65%"><font size=2><b>$txt{'191'}</B></font></td>
	  <td><font size=2>
	   <input type=text size=5 name=numberreturned maxlength=5 value=50></font></td>
        </tr>
      </table>
    </td>
  </tr>
  <tr bgcolor="$color{'windowbg2'}">
    <td align="center"><font size="2"><br>
      <input type=hidden name=action value=dosearch>
      <input type="submit" name="submit" value="$txt{'182'}"><BR><BR>
      </font></td>
  </tr>
</form>
</table>

</td></tr></table>
<br></td></tr></table>
<script language="JavaScript"> <!--
  document.searchform.search.focus();
//--> </script>
~;
  $yytitle = $txt{'183'};
  &template;
  exit;
}


#################################
sub plushSearch2 {
  $searchpageurl = qq~<a href="$scripturl?action=search">$txt{'182'}</a>~;
  my $minripe = $FORM{'minripe'} || 0;
  my $minage  = $FORM{'minage'} || 0;
  my $maxripe = $FORM{'maxripe'} || 0;
  my $maxage  = $FORM{'maxage'} || 7;
  my $display = $FORM{'numberreturned'} || 25;
  if( $minripe =~ /\D/ ) { &fatal_error($txt{'337'}); }
  if( $minage =~ /\D/ ) { &fatal_error($txt{'337'}); }
  if( $maxripe =~ /\D/ ) { &fatal_error($txt{'337'}); }
  if( $maxage =~ /\D/ ) { &fatal_error($txt{'337'}); }
  if( $display =~ /\D/ ) { &fatal_error($txt{'337'}); }

  my $userkind = $FORM{'userkind'};
  my $userspec = $FORM{'userspec'};
  if( $userkind eq 'starter' ) { $userkind = 1; }
  elsif( $userkind eq 'poster' ) { $userkind = 2; }
  elsif( $userkind eq 'noguests' ) { $userkind = 3; }
  elsif( $userkind eq 'onlyguests' ) { $userkind = 4; }
  else { $userkind = 0; $userspec = ''; }
  if ($userspec =~ m~/~){ &fatal_error($txt{'224'}); }
  if ($userspec =~ m~\\~){ &fatal_error($txt{'225'}); }
  $userspec =~ s/\A\s+//;
  $userspec =~ s/\s+\Z//;
  $userspec =~ s/[^0-9A-Za-z#%+,-\.@^_]//g;

  my $searchtype = $FORM{'searchtype'};
  my $search = $FORM{'search'};
  if( $searchtype eq 'anywords' ) { $searchtype = 2; }
  elsif( $searchtype eq 'asphrase' ) { $searchtype = 3; }
  else { $searchtype = 1; }
  if ($search eq ""){ &fatal_error($txt{'754'}); }
# Disable Slash in a Searh String
#  if ($search =~ m~/~){ &fatal_error($txt{'397'}); }
  if ($search =~ m~\\~){ &fatal_error($txt{'397'}); }
  if ($search =~ /\AIs UBB Good\?\Z/i) { &fatal_error("Many llamas have pondered this question for ages. They each came up with logical answers to this question, each being quite different. The consensus of their answers: UBB is a decent piece of software made by a large company. They, however, lack a strong supporting community, charge a lot for their software and the employees are very biased towards their own products. And so, once again, let it be written into the books that<BR><center><a href=\"http://yabb.xnull.com\"><img src=\"http://yabb.xnull.com/images/9870.gif\" alt=\"\" border=0></a><BR>YaBB is the greatest community software there ever was!</center>"); }

  my $searchsubject = $FORM{'subfield'} eq 'on';
  my $searchmessage = $FORM{'msgfield'} eq 'on';

  $search =~ s/\A\s+//;
  $search =~ s/\s+\Z//;
  &ToHTML($search);
  $search =~ s/\t/ \&nbsp; \&nbsp; \&nbsp;/g;
  $search =~ s/\cM//g;
  $search =~ s/\n/<br>/g;
  if( $searchtype != 3 ) { @search = split( /\s+/, $search ); }
  else { @search = ( $search ); }

  my( $curboard, @threads, $curthread, $tnum, $tsub, $tname, $temail, $tdate, $treplies, $tusername, $ticon, $tstate, $ttime, @messages, $curpost, $mtime, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $mns, $subfound, $msgfound, $numfound, %data, $i, $board, $curcat, @categories, %catname, %cataccess, %openmemgr, @membergroups, %cats, @boardinfo, %boardinfo, @boards, $counter, $msgnum );
  my $curtime = time + (3600*$settings[17]);
  my $mintime = $curtime - (($minage*86400)+($minripe*3600) - 1);
  my $maxtime = $curtime - (($maxage*86400)+($maxripe*3600) + 1);
  my $oldestfound = stringtotime("01/10/37 $txt{'107'} 00:00:00");

  fopen(FILE, "$vardir/cat.txt");
  @categories = <FILE>;
  fclose(FILE);
  foreach $curcat (@categories) {
    chomp $curcat;
    fopen(FILE, "$boardsdir/$curcat.cat");
    $catname{$curcat} = <FILE>;
    chomp $catname{$curcat};
    $cataccess{$curcat} = <FILE>;
    chomp $cataccess{$curcat};
    @{$catboards{$curcat}} = <FILE>;
    fclose(FILE);
    $openmemgr{$curcat} = 0;
    @membergroups = split( /,/, $cataccess{$curcat} );
    foreach $tmpa (@membergroups) {
      if( $tmpa eq $settings[7]) { $openmemgr{$curcat} = 1; last; }
    }
    if( ! $cataccess{$curcat} || $settings[7] eq 'Administrator' ) {
      $openmemgr{$curcat} = 1;
    }
    unless( $openmemgr{$curcat} ) { next; }
    foreach $curboard (@{$catboards{$curcat}}) {
      chomp $curboard;
      fopen(FILE, "$boardsdir/$curboard.dat");
      @boardinfo = <FILE>;
      fclose(FILE);
      chomp @boardinfo;
      @{$boardinfo{$curboard}} = @boardinfo;
      $cat{$curboard} = $curcat;
    }
  }

  $counter = 1;
  while( $_ = each(%FORM) ) {
    unless( $_ =~ m~\Abrd(\d+)\Z~ ) { next; }
    $_ = $FORM{$_};
    if ($_ =~ m~/~){ &fatal_error($txt{'397'}); }
    if ($_ =~ m~\\~){ &fatal_error($txt{'397'}); }
    if( $cat{$_} ) { push( @boards, $_ ); }
    ++$counter;
  }
  boardcheck:
  foreach $curboard (@boards) {
    fopen(FILE, "$boardsdir/$curboard.txt") || next;
    @threads = <FILE>;
    fclose(FILE);
#$yymain .= qq~<ol>Beginning search in board $curboard<ol>~;
threadcheck: foreach $curthread (@threads) {
      chomp $curthread;
#$yymain .= qq~</ol>Beginning search in topic $curthread.<ol>~;
      ($tnum, $tsub, $tname, $temail, $tdate, $treplies, $tusername, $ticon, $tstate) = split( /\|/, $curthread );
      if( $userkind == 1 ) {
        if( $tusername eq 'Guest' ) {
          if( $tname !~ m~\A\Q$userspec\E\Z~i ) { next threadcheck; }
        }
        else {
          if( $tusername !~ m~\A\Q$userspec\E\Z~i ) { next threadcheck; }
        }
      }
      $ttime = stringtotime($tdate);
      unless( $ttime < $mintime ) { next threadcheck; }
      unless( $ttime > $maxtime ) { next threadcheck; }
      fopen(FILE, "$datadir/$tnum.txt") || next;
      @messages = <FILE>;
      fclose(FILE);

postcheck: for( $msgnum = 0; $msgnum < @messages; $msgnum++ ) {
        $curpost = $messages[$msgnum];
        chomp $curpost;
#$yymain .= qq~Beginning search in post $curpost.<br>~;
        ($msub, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $message, $mns) = split(/\|/,$curpost);
        $msub = $tsub; #vv
        $mtime = stringtotime($mdate);
        unless( $mtime < $mintime ) { next postcheck; }
        if( $numfound >= $display && $mtime <= $oldestfound ) { next postcheck; }
        if( $musername eq 'Guest' ) {
          if( $userkind == 3 || ( $userkind == 2 && $mname !~ m~\A\Q$userspec\E\Z~i ) ) { next postcheck; }
        }
        else {
          if( $userkind == 4 || ( $userkind == 2 && $musername !~ m~\A\Q$userspec\E\Z~i ) ) { next postcheck; }
        }
#$yymain .= qq~<ol>Performing search in post $curpost.</ol>~;
        if( $searchsubject ) {
          if( $searchtype == 2 ) {
            $subfound = 0;
            foreach( @search ) {
              if( $msub =~ m~\Q$_\E~i ) { $subfound = 1; last; }
            }
          }
          else {
            $subfound = 1;
            foreach( @search ) {
              if( $msub !~ m~\Q$_\E~i ) { $subfound = 0; last; }
            }
          }
        }
        if( $searchmessage && ! $subfound ) {
          if( $searchtype == 2 ) {
            $msgfound = 0;
            foreach( @search ) {
              if( $message =~ m~\Q$_\E~i ) { $msgfound = 1; last; }
            }
          }
          else {
            $msgfound = 1;
            foreach( @search ) {
              if( $message !~ m~\Q$_\E~i ) { $msgfound = 0; last; }
            }
          }
        }
        unless( $msgfound || $subfound ) { next postcheck; }
        if( $subfound ) {
          foreach( @search ) {
            $msub =~ s~(\Q$_\E)~<font size="3"><b>$_</b></font>~ig;
          }
        }
#vv        $data{$mtime} = [$curboard, $tnum, $msgnum, $tusername, $tname, $msub, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $message, $mns, $tstate];
        $data{$mtime} = [$curboard, $tnum, $msgnum, $tusername, $tname, $tsub, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $message, $mns, $tstate];
        if( $mtime < $oldestfound ) { $oldestfound = $mtime; }
        ++$numfound;
      }
    }
  }

  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr bgcolor="$color{'windowbg2'}">
    <td><br><br>
      <font size="2">
      <img src="$imagesdir/open.gif" BORDER=0 alt="">&nbsp;
      <a href="$scripturl">$mbname</a>
      <br>
      <img src="$imagesdir/tline.gif" BORDER=0 alt=""><img src="$imagesdir/open.gif" border=0 alt="">&nbsp;
      $searchpageurl
      <br><img src="$imagesdir/tline2.gif" BORDER=0 alt=""><img src="$imagesdir/open.gif" border=0 alt="">&nbsp;
      <b>$txt{'166'}</b></font></td>
  </tr>
</table>
~;
  @messages = sort {$b <=> $a } keys %data;
  if( @messages ) {
    if( @messages > $display ) { $#messages = $display - 1; }
    $counter = 1;
    &LoadCensorList;  # Load Censor List
  }
  else { $yymain .= qq~
<table border=0 width=100% cellspacing=1 cellpadding=4>
  <tr>
    <td bgcolor="$color{'titlebg'}">
      <font size=2 color="$color{'titletext'}"><b>$txt{'166'}</b>
    </font></td>
  </tr>
  <tr>
    <td align="center" bgcolor="$color{'windowbg2'}">
      <br><font size=2>
      <b>$txt{'170'}</b>
    </font><br>&nbsp;</td>
  </tr>
</table>
~;
  }

  # Load background color list.
  @bgcolors = ( $color{windowbg}, $color{windowbg2} );
  $bgcolornum = scalar @bgcolors;
#  @cssvalues = ( "windowbg","windowbg2" );
#  $cssnum = scalar @bgcolors;

  for( $i = 0; $i < @messages; $i++ ) {
    ($board, $tnum, $msgnum, $tusername, $tname, $msub, $mname, $memail, $mdate, $musername, $micon, $mattach, $mip, $message, $mns, $tstate) = @{ $data{$messages[$i]} };
    $mdate = &timeformat($mdate);
    if( $tusername ne 'Guest' ) {
      if( &LoadUser($tusername) ) { $tname = "<a href=\"$cgi;action=viewprofile;username=$tusername\">$userprofile{$tusername}->[1]</a>"; }
    }
    if( $musername ne 'Guest' ) {
      if( &LoadUser($musername) ) { $mname = "<a href=\"$cgi;action=viewprofile;username=$musername\"><b>$userprofile{$musername}->[1]</b></a>"; }
    }
    foreach (@censored) {
      ($tmpa,$tmpb) = @{$_};
      $message =~ s~\Q$tmpa\E~$tmpb~gi;
      $msub =~ s~\Q$tmpa\E~$tmpb~gi;
    }
    $sender = "search";  # for efficiency we let bolding be done in the wrap function
    &wrap;
    if($enable_ubbc) { $ns = $mns; if(!$yyYaBBCloaded) { require "$sourcedir/YaBBC.pl"; } &DoUBBC; }
    &wrap2;

    if($enable_notification) {
      $notify = qq~$menusep<a href="$scripturl?board=$board;action=notify;thread=$tnum;start=$msgnum">$img{'notify'}</a>~;
    }
    $windowbg = $bgcolors[($i % $bgcolornum)];
    $yymain .= qq~
<table border=0 width=100% cellspacing=1 cellpadding=0>
  <tr>
    <td>
      <table cellpadding="3" cellspacing="0" border="0" width="100%">
	<tr bgcolor="$color{'catbg'}">
	  <td colspan=2><font size=2>$counter.
	  <b>$catname{$cat{$board}}</b> / <a href="$scripturl?board=$board;"><b>$boardinfo{$board}->[0]</b></a>
           / <a href="$scripturl?board=$board;action=display;num=$tnum;start=$msgnum"><b>$msub</b></a></font></td>
	</tr>
      </table>
    </td>
  </tr>
  <tr>
    <td>
      <table border="0" width='100%' cellpadding='4' cellspacing='0'>
        <tr bgcolor="$windowbg">
          <td valign="top" width="15%"><font size="2">
          $mname</font><!--<BR><font size="1">
          $memberinfo-->
          </td>
          <td>
          <td valign="top" width="85%">
            <table border='0' width='100%' cellpadding="0" cellspacing="0">
              <tr align="left" valign="middle">
                <td><img src="$imagesdir/$micon.gif" alt=""></td>
                <td><font size="1">&nbsp; $mdate</font></td>
                <td align="right" nowrap>
~;
#  <tr>
#    <td>
#      <table cellpadding="3" cellspacing="0" border="0" width="100%">
#        <tr bgcolor="$color{'titlebg'}">
#          <td valign="middle" align="left" width="15%">
#            <font size=2 color="$color{'titletext'}">&nbsp;<img src="$imagesdir/thread.gif" alt="">
#            &nbsp;<b>$txt{'29'}</b></font></td>
#          <td valign="middle" align="left">
#            </td>
#        </tr>
#      </table>
#    </td>
#  </tr>
if ($tstate != 1)
{
    $yymain .= qq~<a href="$scripturl?board=$board;action=post;num=$tnum;start=$msgnum;title=Post+reply">$img{'reply'}</a>$menusep<a href="$scripturl?board=$board;action=post;num=$tnum;quote=$msgnum;title=Post+reply">$img{'replyquote'}</a>$notify~;
}

    $yymain .= qq~
                </td>
              </tr>
            </table>
            <hr width="100%" size="1">
            <font size="2">
            $message
            </font>
            <font size="1">
            $userprofile[5]
            </font>
          </td>
        </tr>
      </table>
    </td>
  </tr>
</table>
<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr><td bgcolor="$color{'windowbg2'}">&nbsp;</td></tr></table>
~;
    ++$counter;
  }

  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellpadding=0>
  <tr><td bgcolor="$color{'windowbg2'}" align="center">
<br><br>
<font size="2">$txt{'236'} <a href="$cgi">$txt{'237'}</a><br><br></font>
</td></tr></table>
~;
  $yytitle = $txt{'166'};
  &template;
  exit;
}


sub SimpleSearch {
  my( @categories, %cat, $curcat, %catname, %cataccess, %catboards, $openmemgr, @membergroups, $tmpa, %openmemgr, $curboard, @threads, @boardinfo, $counter );
  @categories = ();
  fopen(FILE, "$vardir/cat.txt");
  @categories = <FILE>;
  fclose(FILE);
  &LoadCensorList;  # Load Censor List

  $searchpageurl = $curposlinks ? qq~<a href="$scripturl?action=search">$txt{'182'}</a>~ : $txt{'182'};
  $yymain .= qq~
<script language="JavaScript1.2" type="text/javascript">
<!-- Begin
function changeBox(cbox) {
  box = eval(cbox);
  box.checked = !box.checked;
}
function checkAll() {
  for (var i = 0; i < document.searchform.elements.length; i++) {
    if(document.searchform.elements[i].name != "subfield" && document.searchform.elements[i].name != "msgfield") {
        document.searchform.elements[i].checked = true;
      }
  }
}
function uncheckAll() {
  for (var i = 0; i < document.searchform.elements.length; i++) {
    if(document.searchform.elements[i].name != "subfield" && document.searchform.elements[i].name != "msgfield") {
        document.searchform.elements[i].checked = false;
      }
  }
}
//--></script>

<table border="0" cellpadding="0" cellspacing="0" width="100%">
<tr><td bgcolor="$color{'windowbg2'}"><br>
<table align="center" width="100%" border="0" cellpadding="2" cellspacing="1">
  <tr>
    <td><font size=2><img src="$imagesdir/open.gif" BORDER=0>&nbsp;
    <b><a href="$scripturl">$mbname</a></b>
    <br><img src="$imagesdir/tline.gif" BORDER=0><img src="$imagesdir/open.gif" border=0>&nbsp;
    <b>$searchpageurl</b></font></td>
  </tr>
</table>

<table border=0 width="100%" align="center" cellspacing="0" cellpadding="0">
<tr><td bgcolor="$color{'bordercolor'}">

<table border=0 width="100%" align="center" cellspacing="1" cellpadding="0">
  <form action="$scripturl?action=search2" method="post" name="searchform">
  <tr bgcolor="$color{'titlebg'}">
    <td><img src="$imagesdir/search.gif" alt=""> <font size=2 color="$color{'titletext'}"><b>$txt{'183'}</b></font></td>
  </tr><tr bgcolor="$color{'windowbg'}">
    <td>
      <table border=0 width="100%" cellspacing="0" cellpadding="4">
	<tr>
	  <td><font size=2><b>$txt{'582'}:</b></font></td>
	  <td><font size=2>
	    <input type=text size=50 name="search">&nbsp;</font></td>
	  <td width="25%"><font size=2>
	    <select name="searchtype">
	    <option value="allwords" selected>$txt{'343'}</option>
	    <option value="anywords">$txt{'344'}</option>
	    <option value="asphrase">$txt{'345'}</option>
	    </select></font></td>
	</tr>
        <tr bgcolor="$color{'windowbg'}">
          <td>&nbsp;</td>
          <td align="center"><font size="2"><br>
            <input type=hidden name=action value=dosearch>
            <input type="submit" name="submit" value="$txt{'182'}"><BR><BR>
            </font></td>
          <td><br>
            <input type=button value="����������� �����" onClick="document.location=\'$cgi;action=searchex';">
            <BR><BR>
            </font></td>
        </tr>
      </table>	
    </td>
  </tr>
~;

  $counter = 1;
  foreach $curcat (@categories) {
    chomp $curcat;
    fopen(FILE, "$boardsdir/$curcat.cat");
    $catname{$curcat} = <FILE>;
    chomp $catname{$curcat};
    $cataccess{$curcat} = <FILE>;
    chomp $cataccess{$curcat};
    @{$catboards{$curcat}} = <FILE>;
    fclose(FILE);
    $openmemgr{$curcat} = 0;
    @membergroups = split( /,/, $cataccess{$curcat} );
    foreach $tmpa (@membergroups) {
      if( $tmpa eq $settings[7]) { $openmemgr{$curcat} = 1; last; }
    }
    if( ! $cataccess{$curcat} || $settings[7] eq 'Administrator' ) {
      $openmemgr{$curcat} = 1;
    }
    unless( $openmemgr{$curcat} ) { next; }
boardcheck: foreach $curboard (@{$catboards{$curcat}}) {
      chomp $curboard;
      fopen(FILE, "$boardsdir/$curboard.dat");
      @boardinfo = <FILE>;
      fclose(FILE);
      chomp @boardinfo;
      @{$boardinfo{$curboard}} = @boardinfo;
      $cat{$curboard} = $curcat;
      $yymain .= qq~<input type=hidden name="brd$counter" value="$curboard">
      ~;
      unless( $counter % 2 ) { $yymain .= qq~~; }
      ++$counter;
    }
  }
  $yymain .= qq~
  <input type=hidden size=30 name="userspec" value="any">
  <input type=hidden name=subfield value=on> 
  <input type=hidden name=msgfield value=on>
  <input type=hidden name=minripe value=0>
  <input type=hidden name=minage value=0>
  <input type=hidden name=maxripe value=0 size=3 maxlength=5>
  <input type=hidden name=maxage value=32767 size=5 maxlength=5>
  <input type=hidden size=5 name=numberreturned maxlength=5 value=45>

</form>
</table>

</td></tr></table>
<br></td></tr></table>
<script language="JavaScript"> <!--
  document.searchform.search.focus();
//--> </script>
~;
  $yytitle = $txt{'183'};
  &template;
  exit;
}


1;