###############################################################################
# Memberlist.pl                                                               #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$memberlistplver = "1 Gold - SP1";

if($username eq "Guest") { &fatal_error("$txt{'223'}"); }

# Load the membergroups list.
fopen(FILE, "$vardir/membergroups.txt") || &fatal_error("100 $txt{'106'}: $txt{'23'} membergroups.txt");
@membergroups = <FILE>;
fclose(FILE);

if($action eq "mlall") { $Sort .= qq(<b>$txt{'303'}</b> $menusep ); } else { $Sort .= qq(<a href="$cgi;action=mlall"><b>$txt{'303'}</b></a> $menusep ); }
if($action eq "mlletter") { $Sort .= qq(<b>$txt{'304'}</b> $menusep ); } else { $Sort .= qq(<a href="$cgi;action=mlletter"><b>$txt{'304'}</b></a> $menusep ); }
if($action eq "mltop") { $Sort .= qq(<b>$txt{'305'}</b>); } else { $Sort .= qq(<a href="$cgi;action=mltop"><b>$txt{'305'}</b></a>); }

if($action eq "mlletter") {
 $page = "a"; $showpage = "A";
 $LetterLinks .= qq(<a href="$scripturl?action=mlletter;letter=9">0..9</a>&nbsp;&nbsp;);
 while($page ne "z") {
  $LetterLinks .= qq(<a href="$scripturl?action=mlletter;letter=$page">$showpage&nbsp;</a> );
  $page++; $showpage++;
 }
 $LetterLinks .= qq(<a href="$scripturl?action=mlletter;letter=z">Z</a> );
}

$TableTitle = qq(
<tr bgcolor="$color{'titlebg'}" align="center">
  <td nowrap><b><font size=2 color="$color{'titletext'}">$txt{'35'}</font></b></td>
  <td><b><font size=2 color="$color{'titletext'}">$txt{'307'}</font></b></td>
  <td><b><font size=2 color="$color{'titletext'}">$txt{'96'}</font></b></td>
  <td><b><font size=2 color="$color{'titletext'}">$txt{'86'}</font></b></td>
  <td><b><font size=2 color="$color{'titletext'}">$txt{'87'}</font></b></td>
  <td><b><font size=2 color="$color{'titletext'}">$txt{'21'}</font></b></td>
</tr>
);

$TableHeader = qq(
<table border=0 width=100% cellspacing=1 cellspacing="4">
);

#$TableHeader .= $TableTitle;


if($LetterLinks ne "") {
 $TableHeader .= qq(<tr>
  <td bgcolor="$color{'catbg'}" colspan="7" align="center"><b><font size=2>$LetterLinks</td>
</tr>
);
}

$TableFooter = qq~</table>
<table border=0 width=100% cellspacing=0 cellspacing="0">
<tr><td bgcolor="$color{'windowbg2'}"><br>&nbsp;</td></tr></table>
~;

sub MLAll {
  if($username eq "Guest") { &fatal_error("$txt{'223'}"); }
  # Get the number of members
  fopen(FILE, "$memberdir/memberlist.txt");
#  @memberlist = <FILE>;
#  $memcount = @memberlist;
#  @membername = @memberlist;
  @membername = <FILE>;
  $memcount = @membername;
  fclose(FILE);
   
  if($INFO{'start'} eq "") { $start=0; } else { $start="$INFO{'start'}"; }
  $numshown=0;
  $numbegin = ($start + 1);
  $numend = ($start + $MembersPerPage);
  if($numend > $memcount) { $numend = $memcount; }
  $b = $start;

  $pageindex = &makepageindex($memcount);
  $pageindexrecord = &makepageindexrecord;

  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellspacing="4">
<tr>
  <td bgcolor="$color{'windowbg2'}"><br>
  <b><font size=2><B>$txt{'308'}</B> ( $txt{'310'}: $memcount )</font></b></td>
</tr></table>
~;
  $yymain .= $TableHeader;
  $yymain .= &makepageindexrecord;
  $yymain .= $TableTitle;

  while(($numshown < $MembersPerPage)) {
    $numshown++;
    $c=0;
    $pages="";
    chomp(@membername);
    $tempname = $membername[$b];
    $membername[$b] =~ s/ //gi;
    $membername[$b] =~ s/\n//gi;
    $name = $membername[$b];
    $b++;

#&LoadUser($name);

    @member = &getuser($name);

    $Bar = &makebar;

    if($tempname) {
      $yymain .= &makeuserrecord($name);
    }
  }

  # page index
  $yymain .= $pageindexrecord;
  $yymain .= $TableFooter;

  $yytitle = "$txt{'308'}";
#  $yytitle = "$txt{'308'} $numbegin $txt{'311'} $numend";
  &template;
  exit;
}

#-------------------------------------------------------------
sub MLTop {
  if($username eq "Guest") { &fatal_error("$txt{'223'}"); }

  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellspacing="4">
<tr>
  <td bgcolor="$color{'windowbg2'}"><br>
  <font size=2><B>$txt{'308'}</B> ( $txt{'305'} )</font></td>
</tr></table>
~;

  %TopMembers = ();
  fopen(MEMBERLISTREAD,"$memberdir/memberlist.txt");
  @member = ();
  while(chomp($membername=<MEMBERLISTREAD>)) {
    fopen(MEMBERFILE,"$memberdir/$membername.dat");
    @member = <MEMBERFILE>;
    fclose(MEMBERFILE);
    chomp @member;

    $TopMembers{$membername} = $member[6];
  }
  fclose(MEMBERLISTREAD);

  my @toplist = sort {$TopMembers{$a} <=> $TopMembers{$b}} keys %TopMembers;
  @toplist = reverse @toplist;

  $memcount = @toplist; #$TopAmmount - 1;

  if($INFO{'start'} eq "") { $start=0; } else { $start="$INFO{'start'}"; }
  $numshown=0;
  $numbegin = ($start + 1);
  $numend = ($start + $MembersPerPage);
  if($numend > $memcount) { $numend = $memcount; }
  $b = $start;

  $pageindex = &makepageindex($memcount);
  $pageindexrecord = &makepageindexrecord;

  $yymain .= $TableHeader;
  $yymain .= &makepageindexrecord;
  $yymain .= $TableTitle;

#  for ($i=0;$i<=$TopListNum;$i++) {
#
#    $membername = @toplist[$i];
#    @member = &getuser($membername);
#    $Bar = &makebar;
#
#    $yymain .= &makeuserrecord($membername);
#  }

  while(($numshown < $MembersPerPage)) {
    $numshown++;
    $c=0;
    $pages="";
    $membername = @toplist[$b];
    @member = &getuser($membername);
    chomp(@membername);
    $b++;

    $Bar = &makebar;
    $yymain .= &makeuserrecord($membername);
  }


  # page index
#  $pageindex = &makepageindex($TopListNum);
  $yymain .= $pageindexrecord;
#  $yymain .= &makepageindexrecord;

  $yymain .= qq~$TableFooter~;
  $yytitle = "$txt{'308'}";
#  $yytitle = "$txt{'313'} $TopAmmount $txt{'314'}";
  &template;
  exit;
}

#-----------------------------------------------------------
sub MLByLetter {
  if($username eq "Guest") { &fatal_error("$txt{'223'}"); }
  $letter = $INFO{'letter'};
  chomp($letter);

  $yymain .= qq~
<table border=0 width=100% cellspacing=0 cellspacing="4">
<tr>
  <td bgcolor="$color{'windowbg2'}"><br>
  <font size=2><B>$txt{'308'}</B>
~;
  if (!$letter) {
   $yymain .= " ( $txt{'304'} )"
  } else { 
   if ($letter eq '9') {
    $yymain .= " ( �� ����� <b>0..9</b> � <b>_</b> )"
   } else {
    $yymain .= " ( �� ����� <b>$letter</b> )"
   }
  }
  $yymain .= qq~
  </font></td>
</tr></table>
~;
  $yymain .= $TableHeader;
#  $yymain .= $pageindexrecord;
  $yymain .= $TableTitle;


  if($INFO{'start'} eq "") { $start=0; } else { $start="$INFO{'start'}"; }

  unless(!$letter) {
    fopen(MEMBERSLISTREAD,"$memberdir/memberlist.txt");
    while(chomp($memberfile=<MEMBERSLISTREAD>)) {
      fopen(MEMBERFILEREAD,"$memberdir/$memberfile.dat");
      @member = <MEMBERFILEREAD>;
      fclose(MEMBERFILEREAD);
      chomp @member;

      $SearchName = $member[1];
      $SearchName = substr $SearchName,0,1;
      $SearchName = lc $SearchName;
      if($letter  eq '9') {
       if($SearchName =~ /[0123456789_\.]/) {
        push(@ToShow,$memberfile);
       }
      } elsif($SearchName eq $letter) {
       push(@ToShow,$memberfile);
      }

    }
    fclose(MEMBERSLISTREAD);
    @ToShow = sort(@ToShow);
    $memcount=@ToShow;
    $numshown=0; $b=$start;

    unless ($memcount == 0) {
      while(($numshown < $MembersPerPage)) {
	$membername=@ToShow[$b];
	if ($membername ne "") {
          @member = &getuser($membername);
          $Bar = &makebar;

          $yymain .= &makeuserrecord($membername);
	}
	$numshown++;
	$b++;
      }
    }
  }
  if(!$letter) {
    $yymain .= qq~ <td bgcolor="$color{'windowbg'}" colspan="7" align="center"><br><b>$txt{'759'}</b><br><br></td>~;
  }
  if($memcount == 0 && $letter) {
    $yymain .= qq~ <td bgcolor="$color{'windowbg'}" colspan="7" align="center"><br><b>$txt{'760'}</b><br><br></td>~;
  }

  $pageindex = &makepageindex($memcount);
  $pageindexrecord = &makepageindexrecord;

  # page index
  $yymain .= $pageindexrecord;
  $yymain .= qq~$TableFooter~;
  $yytitle = "$txt{'308'}";
#  $yytitle = "$txt{'312'}";
  &template;
  exit;
}

#---------------------------------------------
sub makepageindex {
# Build the page links list.
  my ($max) = @_;
  my $pageindex;
  $postdisplaynum = 8;	# max number of pages to display
#  $max = $memcount;
  $start = $INFO{'start'} || 0;
  $start = ( int( $start / $MembersPerPage ) ) * $MembersPerPage;
  $tmpa = 1;
  $tmpletter = '';
  if ($letter) {$tmpletter = ";letter=$letter"}
  $tmpx = int( $max / $MembersPerPage );
  if ($start >= (($postdisplaynum-1) * $MembersPerPage)) { $startpage = $start - (($postdisplaynum-1) * $MembersPerPage); $tmpa = int( $startpage /$MembersPerPage ) + 1; }
  if ($max >= $start + ($postdisplaynum * $MembersPerPage)) { $endpage = $start + ($postdisplaynum * $MembersPerPage); } else { $endpage = $max }
  if ($startpage > 0) { $pageindex = qq~<a href="$cgi;action=$action;start=0$tmpletter">1</a>&nbsp;...&nbsp;~; }
  if ($startpage == $MembersPerPage) { $pageindex = qq~<a href="$cgi;action=$action;start=0$tmpletter">1</a>&nbsp;~;}
  for( $counter = $startpage; $counter < $endpage; $counter += $MembersPerPage ) {
    $pageindex .= $start == $counter ? qq~<b>$tmpa</b>&nbsp;~ : qq~<a href="$cgi;action=$action;start=$counter$tmpletter">$tmpa</a>&nbsp;~;
    $tmpa++;
  }
  $tmpx = $max - $MembersPerPage;
  $outerpn = int($tmpx / $MembersPerPage) + 0;
  $lastpn = int($memcount / $MembersPerPage) + 1;
  $lastptn = ($lastpn - 1) * $MembersPerPage;
  if ($endpage < $max - ($MembersPerPage) ) {$pageindexadd = qq~&nbsp;...&nbsp;~;}
  if ($endpage != $max) {$pageindexadd .= qq~&nbsp;<a href="$cgi;action=$action;start=$lastptn$tmpletter">$lastpn</a>~;}
  $pageindex .= $pageindexadd;
  return $pageindex;
}
#  unless ($memcount == 0) {
#    # Build the page links list.
#    if ($endpage < $max - ($MembersPerPage) ) {$pageindexadd = qq~&nbsp;...&nbsp;~;}
#    if ($endpage != $max) {$pageindexadd .= qq~&nbsp;<a href="$cgi;action=mlletter;letter=$letter;start=$lastptn">$lastpn</a>~;}
#    $pageindex .= $pageindexadd;

#---------------------------------------------
sub makepageindexrecord {
# Build the page links list record.
  return qq~
  <tr>
    <td colspan=7  bgcolor="$color{'catbg'}">
      <table border=0 width=100% cellspacing=0 cellpadding="0">
        <tr bgcolor="$color{'catbg'}">
          <td><font size=2><b>$txt{'139'}:</b>
      	$pageindex</font></td>
          <td align="right"><font size=1>$Sort</font></td>
        </tr>
      </table>
    </td>
  </tr>
~;
}

#---------------------------------------------
sub makebar {
# Build the image bar.
  my $Bar = "";
#Jin X
#  $barchart = ($member[6] / 10);
  $barchart = int($member[6] ** 0.6); 
#/Jin X
  if ($barchart < 1) {$Bar = "$Bar";#}
#  elsif ($barchart > 100) {
#    $Bar = qq~<img src="$imagesdir/bar.gif" width=100 height=15 alt="" border="0">~;
  } else {
    $Bar = qq~<img src="$imagesdir/bar.gif" width=$barchart height=15 alt="" border="0">~;
  }
  if ($Bar eq "") { $Bar="&nbsp;"; }
  return $Bar;
}

#---------------------------------------------
sub getuser {
# Get the member parameters.
    my ($name) = @_;
    my @member; # =()
#    $Bar = "";
#    $ICQ = "";
    fopen(MEMBERFILEREAD,"$memberdir/$name.dat");
    @member = <MEMBERFILEREAD>;
    fclose(MEMBERFILEREAD);
    chomp @member;
    &FormatUserName($name);
    $member[8] =~ s/[\n\r]//g;
#    if($member[6] > 100000) { $member[6] = "$txt{'683'}"; }


    if($member[7] eq 'Administrator') {
      $member[7] = "<B>$membergroups[0]</B>";
    } else {
    if($member[6] > $GodPostNum) {
      $member[7] = "$membergroups[10]";
    }
    elsif($member[6] > $ArchPostNum) {
      $member[7] = "$membergroups[9]";
    }
    elsif($member[6] > $GuruPostNum) {
      $member[7] = "$membergroups[8]";
    }
    elsif($member[6] > $ElderPostNum) {
      $member[7] = "$membergroups[7]";
    }
    elsif($member[6] > $ProfiPostNum) {
      $member[7] = "$membergroups[6]";
    }
    elsif($member[6] > $SrPostNum) {
      $member[7] = "$membergroups[5]";
    }
    elsif($member[6] > $FullPostNum) {
      $member[7] = "$membergroups[4]";
    }
    elsif($member[6] > $JrPostNum) {
      $member[7] = "$membergroups[3]";
    }
    else {
      $member[7] = "$membergroups[2]";
    }
    }
#    if(exists $moderators{$user} && $sender ne "im") {
#      $modinfo{$user} = "<i>$membergroups[1]</i><BR>";
#    }
#    if($member[7] eq "Administrator") { $member[7] = "$membergroups[0]"; }
    return @member;
}

#---------------------------------------------
sub makeuserrecord {
# Build the member record.
  my ($name) = @_;
  my $yy = qq~
      <tr bgcolor="$color{'windowbg'}">
	<td><font size=2><a href="$cgi;action=viewprofile;username=$useraccount{$name}">$member[1]</a></font></td>
~;
  if (($member[19]) && ($allow_hide_email eq 1)) {
    $yy .= qq~
	<td bgcolor="$color{'windowbg2'}" align="center"><font size=1><i>$txt{'722'}</i></font></td>
~;} else {
      $yy .= qq~
	<td bgcolor="$color{'windowbg2'}"><font size=2><a href="mailto:$member[2]">$member[2]</a></font></td>
~;}
  $yy .= qq~
	<td><font size=2><a href="$member[4]" target="_blank">$member[3]</a></font>&nbsp;</td>
	<td bgcolor="$color{'windowbg2'}" align="center"><font size=2>$member[6]</font>&nbsp;</td>
	<td align="center"><font size=2>$member[7]</font></td>
	<td>$Bar</td>
      </tr>
~;
  return $yy;
}

1;