###############################################################################
# Maintenance.pl                                                              #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$maintenanceplver="1 Gold - SP1";

sub InMaintenance
{
	if ($maintenancetext ne "") { $txt{'157'} = $maintenancetext; }
	$yymain .= qq~
<table border=0 width=100% cellspacing=1 bgcolor="$color{'bordercolor'}">
 <tr>
  <td bgcolor="$color{'titlebg'}">
   <font size=2 color="$color{'titletext'}"><b>$txt{'156'}</b></font>
  </td>
 </tr><tr>
  <td bgcolor="$color{'windowbg'}">
   <font size=2>
    <br>
    $txt{'157'}
    <br>&nbsp;
   </font>
  </td>
 </tr>
</table>

<table border=0 width=100% cellspacing=1 bgcolor="$color{'bordercolor'}">
~;
	require "$sourcedir/LogInOut.pl";
	$sharedLogin_title="$txt{'114'}";
	&sharedLogin;

	$yymain .= qq~</table>~;
	$yytitle = "$txt{'155'}";
	&template;
	exit;
}

1;
