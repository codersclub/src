###############################################################################
# BoardIndex.pl                                                               #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$boardindexplver = "1 Gold - SP1";

sub BoardIndex {
  # Open the file with all categories
  fopen(FILE, "$vardir/cat.txt");
  @categories = <FILE>;
  fclose(FILE);
  my($memcount, $latestmember) = &MembershipGet;
  $totalm = 0;
  $totalt = 0;
  foreach $curcat (@categories) {
    chomp $curcat;
    fopen(FILE, "$boardsdir/$curcat.cat");
    $catname{$curcat} = <FILE>;
    chomp $catname{$curcat};
    $cataccess{$curcat} = <FILE>;
    chomp $cataccess{$curcat};
    @{$catboards{$curcat}} = <FILE>;
    fclose(FILE);
    @membergroups = split( /,/, $cataccess{$curcat} );
    $openmemgr{$curcat} = 0;
    foreach $tmpa (@membergroups) { if($tmpa eq $settings[7]) { $openmemgr{$curcat} = 1; last; } }
    if(!$cataccess{$curcat} || $settings[7] eq 'Administrator') { $openmemgr{$curcat} = 1; }
    unless($openmemgr{$curcat}) { next; }
    foreach $curboard (@{$catboards{$curcat}}) {
      chomp $curboard;
      ( $threadcount, $messagecount, $lastposttime, $lastposter ) = &BoardCountGet($curboard);
      $lastposttime{$curboard} = $lastposttime eq 'N/A' || ! $lastposttime ? $txt{'470'} : &timeformat($lastposttime);
      $lastpostrealtime{$curboard} = $lastposttime eq 'N/A' || ! $lastposttime ? '' : $lastposttime;
      if( $lastposter =~ m~\AGuest-(.*)~ ) {
        $lastposter = $1;
        $lastposterguest{$curboard} = 1;
      }
      $lastposter{$curboard} = $lastposter eq 'N/A' || ! $lastposter ? $txt{'470'} : $lastposter;
      $messagecount{$curboard} = $messagecount || 0;
      $threadcount{$curboard} = $threadcount || 0;
      $totalm += $messagecount;
      $totalt += $threadcount;
    }
  }

  $curforumurl = $curposlinks ? qq~<a href="$scripturl">$mbname</a>~ : $mbname;
  $yymain .= qq~
<table border="0" width="100%" cellspacing="0" cellpadding="0">
<tr><td bgcolor="$color{'windowbg2'}"><br><font size="2"><IMG SRC="$imagesdir/open.gif" BORDER="0" alt=""> <b>$curforumurl</b></font>
</td></tr></table>
~;
  if($shownewsfader == 1) {
    if(!$fadedelay) { $fadedelay = 5000; }
    $yymain .= qq~
<table cellpadding="4" cellspacing="1" border="0" width="100%">
      <!--tr>
        <td bgcolor="$color{'titlebg'}" align="center"><font color="$color{'titletext'}" size="2"><b>$txt{'102'}</b></font></td>
      </tr--><tr>
        <td bgcolor="$color{'windowbg2'}" valign="middle" align="center" height="60">
<script language="JavaScript1.2" type="text/javascript">
<!--
var delay = $fadertime
var bcolor = "$color{'windowbg2'}"
var tcolor = "$color{'fadertext'}"
var fcontent = new Array()
begintag = '<font size="2"><B>'
~;
fopen(FILE, "$vardir/news.txt");
@newsmessages = <FILE>;
fclose(FILE);
for($i=0; $i < @newsmessages; $i++) {
  $newsmessages[$i] =~ s/\n|\r//g;
  if($i != 0){ $yymain .= qq~\n~; }
  $message = $newsmessages[$i];
  if($enable_ubbc) { if(!$yyYaBBCloaded) { require "$sourcedir/YaBBC.pl"; } &DoUBBC; }
  $message =~ s/\"/\\\"/g;
  $yymain .= qq~fcontent[$i] = "$message"~;
}
$yymain .= qq~
closetag = '</b></font>'
// -->
</script>
<script language="JavaScript1.2" type="text/javascript" src="$faderpath"></script>
<script language="JavaScript1.2" type="text/javascript">
<!--
if (navigator.appVersion.substring(0,1) < 5 && navigator.appName == "Netscape") {
   var fwidth = screen.availWidth / 2;
   var bwidth = screen.availWidth / 4;
   document.write('<ilayer id="fscrollerns" width='+fwidth+' height=35 left='+bwidth+' top=0><layer id="fscrollerns_sub" width='+fwidth+' height=35 left=0 top=0></layer></ilayer>');
   window.onload = fade;
}
else if (navigator.userAgent.search(/Opera/) != -1 || (navigator.platform != "Win32" && navigator.userAgent.indexOf('Gecko') == -1)) {
   document.open();
   document.write('<div id="fscroller" style="width:90% height:15px; padding:2px">');
   for(i=0; i < fcontent.length; ++i) {
      document.write(begintag+fcontent[i]+closetag+'<br>');
   }
   document.write('</div>');
   document.close();
   window.onload = fade;
}
else {
   document.write('<div id="fscroller" style="width:90% height:15px; padding:2px"></div>');
   window.onload = fade;
}
// -->
</script>
        </td>
      </tr>
    </table>
~;
  }

  $yymain .= qq~
    <table cellpadding="4" cellspacing="1" border="0" width="100%" bgcolor="$color{'bordercolor'}">
      <tr align="center" bgcolor="$color{'titlebg'}">
        <td colspan="2" align="left"><font color="$color{'titletext'}" size="2"><b>$txt{'20'}</b></font></td>
        <td width="1%"><font color="$color{'titletext'}" size="2"><b>$txt{'330'}</b></font></td>
        <td width="1%"><font color="$color{'titletext'}" size="2"><b>$txt{'21'}</b></font></td>
        <td width="24%"><font color="$color{'titletext'}" size="2"><b>$txt{'22'}</b></font></td>
      </tr>~;

  foreach $curcat (@categories) {
    unless( $openmemgr{$curcat} ) { next; }
    $yymain .= qq~<tr>
        <td colspan="5" bgcolor="$color{'catbg'}" height="18"><a name="$curcat"> <font size=2><b>$catname{$curcat}</b></font></a></td>
      </tr>~;
    foreach $curboard (@{$catboards{$curcat}}) {
      chomp $curboard;
      fopen(FILE, "$boardsdir/$curboard.dat");
      $curboardname = <FILE>;
      chomp $curboardname;
      $curboarddescr = <FILE>;
      chomp $curboarddescr;
      $curboardmods = <FILE>;
      chomp $curboardmods;
      fclose(FILE);
      %moderators = ();
      foreach $curuser (split(/\|/, $curboardmods)) {
        &LoadUser($curuser);
        $moderators{$curuser} = $userprofile{$curuser}->[1];

      }
      $showmods = '';
      if(scalar keys %moderators == 1) { $showmods = qq~$txt{'298'}: ~; }
      elsif(scalar keys %moderators != 0) { $showmods = qq~$txt{'299'}: ~; }
      while($tmpa = each(%moderators)) {
        &FormatUserName($tmpa);
        $showmods .= qq~<a href="$scripturl?action=viewprofile;username=$useraccount{$tmpa}">$moderators{$tmpa}</a>, ~;
      }
      $showmods =~ s/, \Z//;
      if($showmods eq "") { $showmods = qq~$txt{'298'}: $txt{'470'}~; }
      $dlp = &getlog($curboard);
      if( $max_log_days_old && $lastposttime{$curboard} ne $txt{'470'} && $username ne 'Guest' && $dlp < stringtotime( $lastpostrealtime{$curboard} ) ) {
        $new = qq~<img src="$imagesdir/new.gif" alt="$txt{'333'}" border="0">~;
      }
#      else { $new = qq~<img src="$imagesdir/off.gif" alt="$txt{'334'}" border="0">~; }
      else { $new = qq~&nbsp;~; }
      $lastposter = $lastposter{$curboard};
      unless( $lastposterguest{$curboard} || $lastposter{$curboard} eq $txt{'470'} ) {
        $lastposterid = $lastposter;
        &LoadUser($lastposterid);
        if($userprofile{$lastposter}->[1]) { $lastposter = qq~<a href="$scripturl?action=viewprofile;username=$lastposterid">$userprofile{$lastposter}->[1]</a>~; }
      }
      $lastposter ||= $txt{'470'};
      $lastposttime ||= $txt{'470'};
      $yymain .= qq~<tr valign="middle" align="center">
        <td bgcolor="$color{'windowbg'}" width="8%"><a name="$curboard"></a>$new</td>
        <td bgcolor="$color{'windowbg2'}" align="left" width="66%">
        <font size=2><a href="$scripturl?board=$curboard"><B>$curboardname</B></a></font>
        <br><font size="1">$curboarddescr</td>
        <td bgcolor="$color{'windowbg'}" width="1%"><font size="2">$threadcount{$curboard}</font></td>
        <td bgcolor="$color{'windowbg'}" width="1%"><font size="2">$messagecount{$curboard}</font></td>
        <td bgcolor="$color{'windowbg2'}" align="left" width="24%"><font size="1">$lastposttime{$curboard}<BR>$txt{'525'} $lastposter</font></td>
      </tr>~;
    }
  }
  my $checkadded = 0;
  $guests = 0;
  $users = '';
  $numusers = 0;
  fopen(FILE, "$vardir/log.txt");
  @entries = <FILE>;
  fclose(FILE);
  foreach $curentry (@entries) {
    chomp $curentry;
    ($name, $value) = split(/\|/, $curentry);
    if($name) {
      if(!$yyUDLoaded{$musername}) { &LoadUser($name); }
      if(exists $userprofile{$name}) {
        $numusers++;
        $users .= qq~ <a href="$scripturl?action=viewprofile;username=$useraccount{$name}">$userprofile{$name}->[1]</a><font size="1">,</font> \n~;
      }
      else { $guests++; }
    }
  }
  $users =~ s~<font size="1">,</font> \n\Z~~;
  if($username ne 'Guest') {
    $ims = @immessages;
    
    if (!$ims) { $ims = '&nbsp;' }
    else {
      $word = $txt{'153'};
      chomp($word);
      $i = $ims % 10;
      if (($i == 1) && (($ims == 1) || ($ims > 20))) {
       chop($word);
       $word .= '�'
      } elsif (($i > 0) && ($i < 5) && (($ims < 10) || ($ims > 20))) {
       chop($word);
       $word .= '�'
      }
      $ims = qq~$txt{'152'}<br><a href="$cgi;action=im">$yynewim <B>$ims&nbsp;$word</B></a>.~;
    }
  } else {
    $ims = '&nbsp;';
  }
#    $yymain .= qq~<tr>
#        <td class="catbg" bgcolor="$color{'catbg'}" colspan="6" align="center">
#        <table cellpadding="0" border="0" cellspacing="0" width="100%">
#          <tr>
#            <td align="left"> <font size="1">
#            <img src="$imagesdir/on.gif" border=0 alt="$txt{'333'}"> $txt{'333'}&nbsp;&nbsp;
#            <img src="$imagesdir/off.gif" border=0 alt="$txt{'334'}"> $txt{'334'}</font></td>
#            <td align="right"><font size=1>&nbsp;
#~;
#  if($showmarkread) { $yymain .= qq~<a href="$scripturl?action=markallasread">$img{'markallread'}</a>~; }
#  $yymain .= qq~
#            </font></td>
#          </tr>
#        </table>
#        </td>
#      </tr>~;
#  }

#  $yymain .= qq~
#    </table>
#    </td>
#  </tr>
#</table>
#<BR><BR>
#<table border=0 width="100%" cellspacing="0" cellpadding="0" bgcolor="$color{'bordercolor'}" class="bordercolor">
#  <tr>
#    <td>
#    <table cellpadding="4" cellspacing="1" border="0" width="100%">
#      <tr>
#        <td bgcolor="$color{'titlebg'}" class="titlebg" align="center" colspan="2">
#        <font class="text1" color="$color{'titletext'}" size="2"><b>$txt{'685'}</b></font></td>
#      </tr>~;

#      <tr>
#        <td class="windowbg" bgcolor="$color{'windowbg'}" width="20" valign="middle" align="center"><img src="$imagesdir/info.gif" border="0" alt=""></td>
#        <td class="windowbg2" bgcolor="$color{'windowbg2'}" valign="top" align="center"><font size="1">
#        <table width="98%" cellpadding="3" align="center">
#          <tr>
#            <td valign="top" align="left" width="60%"><font size="1">
#            $txt{'490'} <B>$totalt</B> &nbsp; - &nbsp; $txt{'489'} <B>$totalm</B>
  $yymain .= qq~<tr bgcolor="$color{'catbg'}">
        <td colspan="2"> <font size="2"><b>$txt{'200'}</b></font></td>
        <td align="center"> <font size="2"> <b>$totalt</B> </font></td>
        <td align="center"> <font size="2"> <b>$totalm</B> </font></td>
        <td> <font size="2"><b>&nbsp;</b></font></td>
      </tr>
~;
#  if($Show_RecentBar) {
#    require "$sourcedir/Recent.pl";
#    &LastPost;
#  }
#  $yymain .= qq~
#      </font></td>
#      <td valign="top" align="left" width="40%"><font size="1">
#      $txt{'488'} <a href="$scripturl?action=mlall"><B>$memcount</B></a>
#      ~;
#  if ($showlatestmember) {
#    &LoadUser($latestmember);
#    $yymain .= qq~<BR>$txt{'201'}: <a href="$scripturl?action=viewprofile;username=$useraccount{$latestmember}"><b>$userprofile{$latestmember}->[1]</b></a>~;
#  }

#      $ims
#      </font></td>
#    </tr>
#  </table>
#  </font></td>
#      </tr>
#      <tr>
#        <td class="catbg" bgcolor="$color{'catbg'}" colspan="2"> <font size="2" class="catbg"><b>$txt{'158'}</b></font></td>
#      </tr>
  $yymain .= qq~
      <tr bgcolor="$color{'windowbg2'}">
        <td bgcolor="$color{'windowbg'}" width="20" valign="middle" align="center"><img src="$imagesdir/info.gif" border="0" alt=""></td>
        <td colspan="3"><font size=1>
        $txt{'488'} <a href="$scripturl?action=mlall"><B>$memcount</B></a>
	<br>$txt{'online'} $guests $txt{'141'}, $numusers $txt{'142'}:<br>$users
        </font></td>
        <td align="center"><font size=1>
  $ims
        </font></td>
      </tr>~;

      if($username eq 'Guest') {
  require "$sourcedir/LogInOut.pl";
  $sharedLogin_title="$txt{'34'} <small><a href=\"$cgi;action=reminder\">($txt{'315'})</small></a>";
  &sharedLogin;
      }

  $yymain .= qq~
    </table>
  </td></tr><tr><td bgcolor="$color{'windowbg2'}">
<table border="0" width="100%"><tr><td>&nbsp;</td></tr></table>
~;
  $yytitle = "$txt{'18'}";
  &template;
  exit;
}

sub MarkAllRead {
  fopen(FILE, "$vardir/cat.txt");
  my @categories = <FILE>;
  fclose(FILE);
  my( $curcat, $curcatname, $curcataccess, @catboards, @membergroups, $openmemgr, $curboard );
  foreach $curcat (@categories) {
    chomp $curcat;
    fopen(FILE, "$boardsdir/$curcat.cat");
    $curcatname = <FILE>;
    $curcataccess = <FILE>;
    chomp $curcatname;
    chomp $curcataccess;
    @catboards = <FILE>;
    fclose(FILE);
    @membergroups = split( /,/, $curcataccess );
    $openmemgr = 0;
    foreach (@membergroups) {
      if( $_ eq $settings[7]) { $openmemgr = 1; last; }
    }
    if(!$curcataccess || $settings[7] eq 'Administrator') { $openmemgr = 1; }
    unless( $openmemgr ) { next; }
    foreach $curboard (@catboards) {
      chomp $curboard;
      &modlog("$curboard--mark");
      &modlog($curboard);
    }
  }
  &dumplog;
  &BoardIndex;
}

1;