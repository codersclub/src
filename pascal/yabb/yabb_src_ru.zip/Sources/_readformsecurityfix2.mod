
<id>
Security Fix from November 11, 2002
</id>

<version>
2.0
</version>

<mod info>
Important: Use this mod to remove a newly found vulnerability that could allow malicious users to execute any function in YaBB, including one that would modify their profile to become an Administrator!

This mod makes sure that no variables from the url query string go into the $FORM array of variables passed in from the actual form.  It also, adds a new "Find Forum Administrators" function to your Admin center. Please use this function to check your site only has its valid administrators.

Instructions:

1. Apply the mod. 
2. Use the Find Forum Administrators function in your admin center to find any unwanted admins, and then delete them. 
Version History:

v2. Took out need for findadmins.pl and built in "Find Forum Admins" dunction into yabb itself
v1. Initial Release

Thanks ot all of us who worked so hard on fixing this flaw.
</mod info>

<author>
The Yabb Team
</author>

<homepage>
www.yabbforum.com
</homepage>

<edit file>
Sources/Subs.pl
</edit file>

<search for>
	if($ENV{QUERY_STRING} =~ m~;~) { @pairs = split(/;/, $ENV{QUERY_STRING}); }
</search for>

<add before>
        my $etest = '';
</add before>

<search for>
	}
	my (@keylist) = sort($query->param());
</search for>

<replace>
		if ($etest eq '') { $etest .= $name."=".$value; }
		else { $etest .= "&" .$name."=".$value; }
	}

        my (@keylist) = $query->param();
        my $qtest = '';
</replace>

<search for>
		$FORM{$key} = $value;
	}
</search for>

<replace>
		$FORM{$key} = $value;
                if ($qtest eq '') { $qtest .= $key."=".$value; }
                else { $qtest .= "&" .$key."=".$value; }
        }
        if (lc($qtest) eq lc($etest)) {
		foreach $key (@keylist) {
			undef $FORM{$key};
 		}
        }
</replace>

<edit file>
Sources/Admin.pl
</edit file>

<search for>
        - <a href="$cgi;action=clean_log">$txt{'202'}</a><br>
</search for>

<add before>
        - <a href="$cgi;action=findadmins">$txt{'fix1'}</a><br>
</add before>

<search for>
1;
</search for>

<add before>
sub findadmins{
$yymain .=qq~<table border=0 width="80%" cellspacing=1 cellpadding=1 bgcolor="$color{'bordercolor'}" class="bordercolor" align=center>
<tr>
<td class="titlebg" bgcolor="$color{'titlebg'}" colspan="4" height=22><b><font size=2 class="text1" color="$color{'titletext'}">&nbsp;$txt{'684'}</font></b></td>
</tr><tr>
	<td class="catbg" bgcolor="$color{'catbg'}" width="33%" align=center><b><font size=2>$txt{'35'}</font></b></td>
	<td class="catbg" bgcolor="$color{'catbg'}" width="34%" align=center><b><font size=2>$txt{'69'}</font></b></td>
	<td class="catbg" bgcolor="$color{'catbg'}" width="33%" align=center><b><font size=2>$txt{'44'}</font></b></td>
</tr>~;
	fopen(FILE, "$memberdir/memberlist.txt");
	@memberlist = <FILE>;
	fclose(FILE);
	for ($a = 0; $a < @memberlist; $a++) {
		chomp $memberlist[$a];
		$membername = lc $memberlist[$a];
		if( fopen(FILE2, "$memberdir/$memberlist[$a].dat") ) {
			# Load users and check for Admin status
			if( !$yyUDLoaded{$memberlist[$a]} && -e("$memberdir/$memberlist[$a].dat") ) {
				# If user is not in memory, s/he must be loaded.
				&LoadUser($memberlist[$a]);
				if($userprofile{$memberlist[$a]}->[7] eq "Administrator") { $yymain .= qq~<tr><td class='windowbg' bgcolor=$color{'windowbg'} width='20%' align=center><a href="$scripturl?board=;action=viewprofile;username=$memberlist[$a]">$memberlist[$a]</a></TD><td class='windowbg' bgcolor=$color{'windowbg'} width='20%' align=center>$userprofile{$memberlist[$a]}->[2]</td><td class='windowbg' bgcolor=$color{'windowbg'} width='19%' align='center'>$userprofile{$memberlist[$a]}->[1]</td></tr>~; }
			}
		}
	}
$yymain .= qq~</table>~;
&template;
exit;
}

</add before>

<edit file>
english.lng
</edit file>

<search for>
$txt{'796'} = "Your Instant Messages:";
</search for>

<add after>
$txt{'fix1'} = "Find Forum Administrators";
</add after>

<edit file>
YaBB.pl
</edit file>

<search for>
	elsif ($action eq 'usersrecentposts') { require "$sourcedir/Profile.pl"; &usersrecentposts; }
</search for>

<add after>
	elsif ($action eq 'findadmins') { require "$sourcedir/Admin.pl"; &findadmins; }
</add after>