sub chat{
$ircname = $realname;
if ($ircname eq "Guest" || $ircname eq "") {
 srand;
 $randnum = int(rand 326761) + 1;
 $ircname = "Guest$randnum";
}
$ircname =~ s/ /\_/g;
$newname = $mbname;
$newname =~ s/ /\_/g;
$text = $irctxt{'1'};
$yytitle="$text";
$yymain .= qq~
        <div align="center"><applet
			archive="http://ircqnet.icq.com/IrCQNet-New/IrCQNet.jar"
			codebase="http://ircqnet.icq.com/IrCQNet-New"
			code="IRCQNet.class"
			name="IRCQNet"
			width=635
			height=440>
			<param name="mustLogin" value="true">
			<param name="skipStartup" value="true">
			<param name="startFrame" value="false">
			<param name="server" value="ircqnet.icq.com">
			<param name="serverPort" value="6668">
			<param name="user" value="$newname Chatter">
			<param name="firstJoin" value="#$newname">
			<param name="nick" value="$ircname">
			<param name="info" value="">
		</applet></h1></div>~;
&template;
exit;
}

1;