###############################################################################
# LogInOut.pl                                                                 #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$loginoutplver = "1 Gold - SP1";

sub Login {
	$yymain .= qq~
<table border="0" width="100%" cellspacing="0" cellpadding="0" align="center">
  <tr>
    <td bgcolor="$color{'windowbg2'}"><br><br>
      <table border=0 width="60%" cellPadding="0" cellSpacing="0" align="center">
        <tr>
 	  <td bgcolor="$color{'bordercolor'}">
           <table border=0 width="100%" cellPadding="0" cellSpacing="1">
           <tr><td bgcolor="$color{'bordercolor'}">
    	    <table border=0 width="100%" cellSpacing="0" cellPadding="3" align="center">
       	      <tr>
	      <form action="$cgi;action=login2" method="POST" name="form">
       	  	<td bgcolor="$color{'titlebg'}" colspan="3">
       	    	  <img src="$imagesdir/login.gif">
       	          <font size=2 color="$color{'titletext'}"><b>$txt{'34'}</b></font></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td><font size=2><b>$txt{'35'}:</b></font></td>
       	  	<td><font size=2><input type=text name="username" size=20 tabindex="1"></font></td>
       	  	<td><a href="$cgi;action=register"><font size="1">$txt{'753'}</font></a></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td><font size=2><b>$txt{'36'}:</b></font></td>
       	  	<td><font size=2><input type=password name="passwrd" size=20 tabindex="2"></font></td>
       	  	<td><a href="$cgi;action=reminder"><font size="1">$txt{'315'}</font></a></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td><font size=2><b>$txt{'497'}:</b></font></td>
       	  	<td colspan="2"><font size=2><input type=text name="cookielength" size=4 maxlength="4" value="$Cookie_Length" tabindex="3"></font></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td><font size=2><b>$txt{'508'}:</b></font></td>
       	  	<td colspan="2"><font size=2><input type=checkbox name="cookieneverexp" tabindex="4" value="1" checked></font></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td align=center colspan="3"><BR><input type=submit value="$txt{'34'}" tabindex="5" accesskey="l"></td>
       	      </tr><tr bgcolor="$color{'windowbg'}">
       	  	<td align=center colspan="3"><BR></td>
       	      </form>
       	      </tr>
	    </table>
	   </td></tr></table>
	  </td>
	</tr>
      </table>
      <br><br>
    </td>
  </tr>
</table>
<script language="JavaScript"> <!--
	document.form.username.focus();
//--> </script>
~;
	$yytitle = "$txt{'34'}";
	&template;
	exit;
}

sub Login2 {
	&fatal_error("$txt{'37'}") if($FORM{'username'} eq "");
	&fatal_error("$txt{'38'}") if($FORM{'passwrd'} eq "");
	$FORM{'username'} =~ s/\s/_/g;
	$username = $FORM{'username'};
	&fatal_error("$txt{'240'} $txt{'35'} $txt{'241'}") if($username !~ /^[\s0-9A-Za-z#%+,-\.:=?@^_]+$/);
	&fatal_error("$txt{'337'}") if($FORM{'cookielength'} !~ /^[0-9]+$/);

	if(-e("$memberdir/$username.dat")) {
		fopen(FILE, "$memberdir/$username.dat");
		@settings = <FILE>;
		fclose(FILE);
 		$settings[0] =~ s/[\n\r]//g;
		if($settings[0] ne "$FORM{'passwrd'}") { $username = "Guest"; &fatal_error("$txt{'39'}"); }
		$settings[0] = "$settings[0]\n";
	}
	else { $username = "Guest"; &fatal_error("$txt{'40'}"); }

	if($FORM{'cookielength'} < 1 || $FORM{'cookielength'} > 9999) { $FORM{'cookielength'} = $Cookie_Length; }
	if(!$FORM{'cookieneverexp'}) { $ck{'len'} = "\+$FORM{'cookielength'}m"; }
	else { $ck{'len'} = 'Sunday, 17-Jan-2038 00:00:00 GMT'; }
	$password = crypt("$FORM{'passwrd'}",$pwseed);

	$yySetCookies1 = cookie(-name    =>   "$cookieusername",
				-value   =>   "$username",
				-path    =>   "/",
				-expires =>   "$ck{'len'}");
	$yySetCookies2 = cookie(-name    =>   "$cookiepassword",
				-value   =>   "$password",
				-path    =>   "/",
				-expires =>   "$ck{'len'}");
	&LoadUserSettings;
	if ($maintenance && $settings[7] ne 'Administrator') {$username = 'Guest'; &fatal_error($txt{'774'});}
#  if (CheckSettings()) {
	&WriteLog;
	&redirectinternal;
#  } else {
#    $yySetLocation = qq~$cgi;action=profile;username=$username~;
#    &redirectexit;
#  }
}

#sub CheckSettings {
#  
#  return 0 if ($settings[11] eq ""); # gender
#  return 0 if ($settings[15] eq ""); # location
#  return 0 if ($settings[16] eq ""); # BirthDay
#
#  return 1;
#}


sub Logout {
	# Write log
	fopen(LOG, "$vardir/log.txt");
	my @entries = <LOG>;
	fclose(LOG);
	fopen(LOG, ">$vardir/log.txt", 1);
	$field = $username;
	foreach $curentry (@entries) {
	        $curentry =~ s/\n//g;
     		($name, $value) = split(/\|/, $curentry);
	        if($name ne $field) { print LOG "$curentry\n"; }
	}
	fclose(LOG);

	$yySetCookies1 = cookie(-name    =>   "$cookieusername",
				-value   =>   "",
				-path    =>   "/",
				-expires =>   "Thursday, 01-Jan-1970 00:00:00 GMT");
	$yySetCookies2 = cookie(-name    =>   "$cookiepassword",
				-value   =>   "",
				-path    =>   "/",
				-expires =>   "Thursday, 01-Jan-1970 00:00:00 GMT");
	$username = 'Guest';
	$password = '';
	@settings = ();
	@immessages = ();
	$yyim = "";
	$realname = '';
	$realemail = '';
	$ENV{'HTTP_COOKIE'} = '';
	&LoadIMs;	# Load IM's (to blank)
	$yyuname = "";
	&redirectinternal;
}

sub sharedLogin {
	if ($sharedLogin_title ne "") {$yymain .= qq~<tr><td bgcolor="$color{'catbg'}" colspan="5"><font size="2"><b>$sharedLogin_title</b></font></td></tr>~;}
	if ($sharedLogin_text ne "") {$yymain .= qq~<tr><td colspan="5" bgcolor="$color{'windowbg'}" align="left" cellpadding=3><font size=2>$sharedLogin_text</font></td></tr>~;}
	$yymain .= qq~<tr>
        <td bgcolor="$color{'windowbg'}" width="20" valign=middle align=center><img src="$imagesdir/login.gif" border="0" alt=""></td>
        <td bgcolor="$color{'windowbg2'}" colspan="4" valign="middle">
        <table border="0" cellpadding="3" cellspacing="0" valign="middle" align="center" width="90%">
          <form action="$cgi;action=login2" method="POST">
          <tr valign="middle" align="left">
            <td><font size=2><b>$txt{'35'}:</b></font></td>
            <td><font size=2><input type=text name="username" size="15" tabindex="1"></font></td>
            <td><font size=2><b>$txt{'497'}:</b></font></td>
            <td><font size=2><input type=text name="cookielength" size="7" maxlength="4" value="$Cookie_Length" tabindex="3"> </font></td>
          </tr><tr valign="middle" align="left">
            <td><font size=2><b>$txt{'36'}:</b></font></td>
            <td><font size=2><input type=password name="passwrd" size="15" tabindex="2"></font></td>
            <td><font size=2><b>$txt{'508'}:</b></font></td>
            <td><font size=2><input type=checkbox name="cookieneverexp" tabindex="4" checked>&nbsp;&nbsp;</font> <input type=submit value="$txt{'34'}" tabindex="5" accesskey="l"></font></td>
          </tr>
        </form>
        </table>
       </td>
      </tr>~;
	$sharedLogin_title=""; $sharedLogin_text="";
}

sub Reminder {
	$yymain .= qq~
<table border=0 width="100%" cellspacing=0 align="center">
  <tr><td bgcolor="$color{'windowbg2'}">
  <BR><BR>
  <table border=0 width=400 cellspacing=0 cellpadding=0 align="center">
    <tr><td bgcolor="$color{'bordercolor'}">
      <table border=0 width="100%" cellspacing=1 cellpadding=4 align="center">
        <tr>
          <td bgcolor="$color{'titlebg'}">
          <font size=2 color="$color{'titletext'}"><b>$txt{'669'}</b></font></td>
        </tr><tr>
          <form action="$cgi;action=reminder2" method="POST">
          <td bgcolor="$color{'windowbg'}" align="center"><br>
          <br><font size="2"><b>$txt{'35'}</b>: <input type="text" name="user">
          <br><br><input type="submit" value="$txt{'339'}"></font><br><br></td>
          </form>
        </tr>
      </table>
    </td></tr></table>
<br>&nbsp;
</td></tr></table>
~;
$yytitle = "$txt{'669'}";
&template;
exit;
}

sub Reminder2 {
$user = $FORM{'user'};

fopen(FILE, "$memberdir/$user.dat") || &fatal_error("<b>$txt{'40'}</b>");
@member=<FILE>;
fclose(FILE);
$password = $member[0];
$name = $member[1];
$email = $member[2];
$status = $member[7];

chomp($name);
chomp($email);
chomp($password);
chomp($status);

$subject = "$txt{'36'} $mbname : $name";
&sendmail($email, $subject, qq~$txt{'711'} $name,\n\n$mbname ==>\n\n$txt{'35'}: $user\n$txt{'36'}: $password\n$txt{'87'}: $status\n\n$txt{'130'}~);

$yymain .= qq~
<BR><BR><table border=0 width=400 cellspacing=1 bgcolor="$color{'bgcolor'}" align="center">
  <tr>
    <td bgcolor="$color{'titlebg'}">
    <font size=2 color="$color{'titletext'}"><b>$mbname $txt{'36'} $txt{'194'}</b></b></font></td>
  </tr><tr>
    <td bgcolor="$color{'windowbg'}">
    <table border=0 align="center">
      <tr>
        <td align="center"><font size="2"><b>$txt{'192'}: $user</b></font></td>
      </tr>
    </table>
    </td>
  </tr>
</table>
<br><center><a href="javascript:history.back(-2)">$txt{'193'}</a></center><br>
~;
$yytitle = "$txt{'669'}";
&template;
exit;
}

1;