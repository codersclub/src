###############################################################################
# Load.pl                                                                     #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

$loadplver = "1 Gold - SP1";
$boardcounter = 0;
$yynewim = "";

sub LoadIMs {
  if ($maintenance && $settings[7] ne 'Administrator') {$username="Guest";}
  if($username ne "Guest" && $username ne '' && $action ne "logout") {
    fopen(IM, "$memberdir/$username.msg");
    @immessages = <IM>;
    fclose(IM);
    $mnum = @immessages;
    $yyim = '&nbsp;';
    if (-e "$memberdir/$username.new") {
      $yynewim = "<img border=0 width=16 height=16 src='/img/bat.gif'>";
    }
    if ($mnum) {
      $word = $txt{'153'};
      chomp($word);
      $i = $mnum % 10;
      if (($i == 1) && (($mnum == 1) || ($mnum > 20))) {
        chop($word);
        $word .= '�'
      } elsif (($i > 0) && ($i < 5) && (($mnum < 10) || ($mnum > 20))) {
        chop($word);
        $word .= '�'
      }
      $yyim = qq~$txt{'152'} <a href="$cgi;action=im">$yynewim  <B>$mnum&nbsp;$word</B></a>.~;

    }
#    if($mnum eq "1") { $yyim = qq~$txt{'152'} <a href="$cgi;action=im">$mnum $txt{'471'}</a>.~; }
#    else { $yyim = qq~$txt{'152'} <a href="$cgi;action=im">$mnum $txt{'153'}</a>.~; }

    if($maintenance && $settings[7] eq 'Administrator') { $yyim .= qq~<BR><B>$txt{'616'}</B>~; }
    if (!$user_ip && $settings[7] eq 'Administrator') { $yyim .= qq~<br><b>$txt{'773'}</b>~; }
  }
}

sub LoadBoard {
  my $threadid = $INFO{'num'} || $INFO{'thread'} || $FORM{'threadid'};
  if($currentboard ne '') {
    unless( &BoardAccessGet($currentboard) ) { &fatal_error( $txt{'1'} ); }

    my $viewnum = $INFO{'num'};
    if( $viewnum =~ /\D/ ) { &fatal_error($txt{'337'}); }

    fopen(FILE, "$boardsdir/$currentboard.dat") || &fatal_error("400 $txt{'106'}: $txt{'23'} $currentboard.dat");
    @yyBoardInfo =<FILE>;
    fclose(FILE);

    chomp @yyBoardInfo;
    $boardname  = $yyBoardInfo[0];
    $boarddescr = $yyBoardInfo[1];
    $boardtempl = $yyBoardInfo[3];
    $boardrules = $yyBoardInfo[4];
    $boardfaq   = $yyBoardInfo[5];
    chomp $boardfaq;
    chomp($boardtempl);
    $boardfaqtxt = "";
    if ($boardfaq) {$boardfaqtxt = "������, ��� ��������, ������� � <a href=\"$boardfaq\" target=\_blank title=\"$txt{'faqprompt'}\"><b>$txt{'faq'}</b></a>"}

    # Create Hash %moderators with all Moderators of the current board
    foreach(split(/\|/,$yyBoardInfo[2])) {
      fopen(MODERATOR, "$memberdir/$_.dat");
      @modprop = <MODERATOR>;
      fclose(MODERATOR);
      $modprop[1] =~ s/[\n\r]//g;
      $moderators{$_} = $modprop[1];
    }

    if ($threadid ne '' && ! $FORM{'caller'} && $action ne 'imsend') {
      $yyThreadPosition = -1;
      my $found;
      fopen(BOARDFILE, "$boardsdir/$currentboard.txt") || &fatal_error("401 $txt{'106'}: $txt{'23'} $currentboard.txt");
      while( $yyThreadLine = <BOARDFILE> ) {
        ++$yyThreadPosition;
        if( $yyThreadLine =~ m~\A$threadid\|~o ) { $found = 1; last; }
      }
      fclose(BOARDFILE);
      unless( $found ) { &fatal_error("$txt{'472'} $threadid : $yyThreadPosition."); }
      chomp $yyThreadLine;
    }
  }
  elsif( $threadid ne '' && $action ne "imsend" ) { &fatal_error("$txt{'472'}"); }
}

sub LoadCensorList {
  fopen(FILE,"$vardir/censor.txt") || &fatal_error("205 $txt{'106'}: $txt{'23'} censor.txt");
  while( chomp( $buffer = <FILE> ) ) {
    ($tmpa,$tmpb) = split(/=/,$buffer);
    push(@censored,[$tmpa,$tmpb]);
  }
  fclose(FILE);
}

sub LoadUserSettings {
  if($username ne 'Guest') {
    if( fopen(FILE, "$memberdir/$username.dat") ) {;
      @settings=<FILE>;
      fclose(FILE);
      for( $_ = 0; $_ < @settings; $_++ ) {
#        if (!($_ == 44)) {
          $settings[$_] =~ s~[\n\r]~~g;
#        }
      }
      $spass = crypt($settings[0],$pwseed);
      if($spass ne $password && $action ne 'logout') { $username = ''; }
      else {
        $realname = $settings[1];
        $realemail = $settings[2];
      }
    }
    else { $username = ''; }
  }
  unless($username) {
    $yySetCookies1 = cookie(-name    =>   "$cookieusername",
          -value   =>   "",
          -path    =>   "/",
          -expires =>   "Thursday, 01-Jan-1970 00:00:00 GMT");
    $yySetCookies2 = cookie(-name    =>   "$cookiepassword",
          -value   =>   "",
          -path    =>   "/",
          -expires =>   "Thursday, 01-Jan-1970 00:00:00 GMT");
    $username = 'Guest';
    $password = '';
    @settings = ();
    $realname = '';
    $realemail = '';
    $ENV{'HTTP_COOKIE'} = '';
  }
  &FormatUserName($username);
}

sub FormatUserName {
  my $user = $_[0];
  if( $useraccount{$user} ) { return; }
  $useraccount{$user} = $user;
  $useraccount{$user} =~ s~\%~%25~g;
  $useraccount{$user} =~ s~\#~%23~g;
  $useraccount{$user} =~ s~\+~%2B~g;
  $useraccount{$user} =~ s~\,~%2C~g;
  $useraccount{$user} =~ s~\-~%2D~g;
  $useraccount{$user} =~ s~\.~%2E~g;
  $useraccount{$user} =~ s~\@~%40~g;
  $useraccount{$user} =~ s~\^~%5E~g;
}

sub LoadUser {
  my $user = $_[0];
  unless( exists $userprofile{$user} ) {
    fopen(FILEAUSER, "$memberdir/$user.dat") || return 0;
    @{$userprofile{$user}} = <FILEAUSER>;
    fclose(FILEAUSER);
    for( $_ = 0; $_ < @{$userprofile{$user}}; $_++ ) {
      chomp $userprofile{$user}->[$_];
    }
    &FormatUserName($user);
  }
  return 1;
}


sub LoadUserDisplay {
  my $user= $_[0];
  if(exists $userprofile{$user}) { if($yyUDLoaded{$user}) { return 1; } }
  else {
    &LoadUser($user);
    unless(exists $userprofile{$user}) { return 0 ; }
  }
  &LoadCensorList;  # Load censor list

  $userpic_tmpwidth ||= $userpic_width ? qq~ width="$userpic_width"~ : '';
  $userpic_tmpheight ||= $userpic_height ? qq~ height="$userpic_height"~ : '';

  if($userprofile{$user}->[4] !~ m~\Ahttp://~) { $userprofile{$user}->[4] = "http://$userprofile{$user}->[4]"; }
  if($sm) { $userprofile{$user}->[4] = $userprofile{$user}->[4] && $userprofile{$user}->[4] ne q~http://~ ? qq~ <a href="$userprofile{$user}->[4]" target="_blank">$img{'website_sm'}</a>$menusep~ : ''; }
  else { $userprofile{$user}->[4] = $userprofile{$user}->[4] && $userprofile{$user}->[4] ne q~http://~ ? qq~<a href="$userprofile{$user}->[4]" target="_blank">$img{'website'}</a>$menusep~ : ''; }

  $userprofile{$user}->[5] =~ s~\&\&~<br>~g;
  $userprofile{$user}->[5] = $userprofile{$user}->[5] ? qq~<hr width="100%" size="1"><font size="1">$userprofile{$user}->[5]</font>~ : '';
  # do some ubbc on the signature
  $message = $userprofile{$user}->[5];
  if($enable_ubbc) { if(!$yyYaBBCloaded) { require "$sourcedir/YaBBC.pl"; } &DoUBBC; }
  $userprofile{$user}->[5] = $message;

  if($userprofile{$user}->[8] ne "" && $userprofile{$user}->[8] !~ m~\D~) {
    $icqad{$user} = qq~<a href="http://wwp.icq.com/scripts/search.dll?to=$userprofile{$user}->[8]" target="_blank"><img src="$imagesdir/icqadd.gif" alt="$userprofile{$user}->[8]" BORDER=0></a>~;
    $userprofile{$user}->[8] = qq~<a href="$cgi;action=icqpager;UIN=$userprofile{$user}->[8]" target="_blank"><img src="http://web.icq.com/whitepages/online?icq=$userprofile{$user}->[8]&img=5" alt="$userprofile{$user}->[8]" border="0"></a>~;
  }
  else {
    $icqad{$user} = '';
    $userprofile{$user}->[8] = '';
  }

  $userprofile{$user}->[9] = $userprofile{$user}->[9] ? qq~<a href="aim:goim?screenname=$userprofile{$user}->[9]&message=Hi.+Are+you+there?"><img src="$imagesdir/aim.gif" alt="$userprofile{$user}->[9]" border="0"></a>~ : '';

  if($userprofile{$user}->[10] ne "") {
    $yimon{$user} = qq~<img SRC="http://opi.yahoo.com/online?u=$userprofile{$user}->[10]&m=g&t=0" BORDER=0 alt="">~;
    $userprofile{$user}->[10] = $userprofile{$user}->[10] ? qq~<a href="http://edit.yahoo.com/config/send_webmesg?.target=$userprofile{$user}->[10]" target="_blank"><img src="$imagesdir/yim.gif" alt="$userprofile{$user}->[10]" border="0"></a>~ : '';
  }

  if($showgenderimage && $userprofile{$user}->[11]) {
    $userprofile{$user}->[11] = $userprofile{$user}->[11] =~ m~Female~i ? 'female' : 'male';
    $userprofile{$user}->[11] = $userprofile{$user}->[11] ? qq~<font size="1">$txt{'231'}: <img src="$imagesdir/$userprofile{$user}->[11].gif" border="0" alt="$userprofile{$user}->[11]"><br>~ : '';
  }
  else { $userprofile{$user}->[11] = ''; }

  $userprofile{$user}->[12] = $showusertext ? qq~$userprofile{$user}->[12]~ : '';

  if($showuserpic && $allowpics && $settings[29]) {
    $userprofile{$user}->[13] ||= 'blank.gif';
#vot    $userprofile{$user}->[13] = $userprofile{$user}->[13] =~ m~\A[\s\n]*http://~i ? qq~<img src="$userprofile{$user}->[13]"$userpic_tmpwidth$userpic_tmpheight border="0" alt="">~ : qq~<img src="$facesurl/$userprofile{$user}->[13]" border="0" alt="">~;
    $userprofile{$user}->[13] = $userprofile{$user}->[13] =~ m~\A[\s\n]*http://~i ? qq~<img src="$userprofile{$user}->[13]" border="0" alt="">~ : qq~<img src="$facesurl/$userprofile{$user}->[13]" border="0" alt="">~;
  }
  else { $userprofile{$user}->[13] = ''; }

  ### Censor it ###
  foreach (@censored) {
    ($tmpa,$tmpb) = @{$_};
    $userprofile{$user}->[5] =~ s~\Q$tmpa\E~$tmpb~gi;
    $userprofile{$user}->[12] =~ s~\Q$tmpa\E~$tmpb~gi;
  }

###### Set Member's Status and Stars
#vv!!!
#  ($memberinfo{$user},$memberstar{$user}) = &userstatus($user);
#sub userstatus {

  # User Status from Message Counter
  if($userprofile{$user}->[6] > $GodPostNum) {
    $memberinfo{$user} = "$membergroups[10]";
    $memberstar{$user} = qq~<img src="$imagesdir/starmod.gif" border="0" alt="$memberinfo{$user}"><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $ArchPostNum) {
    $memberinfo{$user} = "$membergroups[9]";
    $memberstar{$user} = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $GuruPostNum) {
    $memberinfo{$user} = "$membergroups[8]";
    $memberstar{$user} = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $ElderPostNum) {
    $memberinfo{$user} = "$membergroups[7]";
    $memberstar{$user} = qq~<img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $ProfiPostNum) {
    $memberinfo{$user} = "$membergroups[6]";
    $memberstar{$user} = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $SrPostNum) {
    $memberinfo{$user} = "$membergroups[5]";
    $memberstar{$user} = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $FullPostNum) {
    $memberinfo{$user} = "$membergroups[4]";
    $memberstar{$user} = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $JrPostNum) {
    $memberinfo{$user} = "$membergroups[3]";
    $memberstar{$user} = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  else {
    $memberinfo{$user} = "$membergroups[2]";
    $memberstar{$user} = qq~<img src="$imagesdir/star.gif" border="0" alt="">~;
  }

  # User Official Status
  if(exists $moderators{$user} && $sender ne "im") {
    $modinfo{$user} = "<br><b>$membergroups[1]</b>";
    $memberstar{$user} = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[7] eq 'Administrator') {
    $memberinfo{$user} = "<B>$membergroups[0]</B>";
    $memberstar{$user} = qq~<img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt="">~;
  }

  if($userprofile{$user}->[7] && $userprofile{$user}->[7] ne 'Administrator') { $groupinfo{$user} = "<br>$userprofile{$user}->[7]"; }

  if($userprofile{$user}->[7] ne 'Administrator') {
    $memberinfo{$user} = "$memberinfo{$user}$modinfo{$user}$groupinfo{$user}";
  }

  if($userprofile{$user}->[6] > 100000) { $userprofile{$user}->[6] = "$txt{'683'}"; }

#}



  $yyUDLoaded{$user} = 1;
  return 1;
}

sub userstatus {
  my $user = shift;
  my $memberinfo, $memberstar, $modinfo;

  if($userprofile{$user}->[6] > $GodPostNum) {
    $memberinfo = "$membergroups[10]";
    $memberstar = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[6] > $ArchPostNum) {
    $memberinfo = "$membergroups[9]";
    $memberstar = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[6] > $GuruPostNum) {
    $memberinfo = "$membergroups[8]";
    $memberstar = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[6] > $ElderPostNum) {
    $memberinfo = "$membergroups[7]";
    $memberstar = qq~<img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $ProfiPostNum) {
    $memberinfo = "$membergroups[6]";
    $memberstar = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $SrPostNum) {
    $memberinfo = "$membergroups[5]";
    $memberstar = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $FullPostNum) {
    $memberinfo = "$membergroups[4]";
    $memberstar = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  elsif($userprofile{$user}->[6] > $JrPostNum) {
    $memberinfo = "$membergroups[3]";
    $memberstar = qq~<img src="$imagesdir/star.gif" border="0" alt=""><img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  else {
    $memberinfo = "$membergroups[2]";
    $memberstar = qq~<img src="$imagesdir/star.gif" border="0" alt="">~;
  }
  if(exists $moderators{$user} && $sender ne "im") {
    $modinfo = "<i>$membergroups[1]</i><BR>";
    $memberstar = qq~<img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt=""><img src="$imagesdir/starmod.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[7] eq 'Administrator') {
    $memberinfo = "<B>$membergroups[0]</B>";
    $memberstar = qq~<img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt=""><img src="$imagesdir/staradmin.gif" border="0" alt="">~;
  }
  if($userprofile{$user}->[7] && $userprofile{$user}->[7] ne 'Administrator') { $groupinfo{$user} = "$userprofile{$user}->[7]<BR>"; }
  if($userprofile{$user}->[7] ne 'Administrator') {
    $memberinfo = $modinfo; #$groupinfo{$user}$memberinfo{$user}";
  }

#  if($userprofile{$user}->[6] > 100000) { $userprofile{$user}->[6] = "$txt{'683'}"; }
  return ($memberinfo, $memberstar);
}



sub LoadCookie {
  foreach (split(/; /,$ENV{'HTTP_COOKIE'})) {
    $_ =~ s/%([a-fA-F0-9][a-fA-F0-9])/pack("C", hex($1))/eg;
    ($cookie,$value) = split(/=/);
    $yyCookies{$cookie} = $value;
  }
  if($yyCookies{$cookiepassword}) {
    $password = $yyCookies{$cookiepassword};
    $username = $yyCookies{$cookieusername} || 'Guest';
  } else {
    $password = '';
    $username = 'Guest';
  }
}

sub LoadAdmins {
  &is_admin;
  my (@members, $curentry);

  $administrators = '';
  fopen(FILE, "$memberdir/memberlist.txt");
  @members = <FILE>;
  fclose(FILE);
  foreach $curentry (@members) {
    chomp $curentry;
    &LoadUser($curentry);
    if($userprofile{$curentry}->[7] eq 'Administrator') {
      $administrators .= qq~ <a href="$scripturl?action=viewprofile;username=$useraccount{$curentry}">$userprofile{$curentry}->[1]</a><font size="1">,</font> \n~;
    }
  }
  $administrators =~ s~<font size="1">,</font> \n\Z~~;
}

sub LoadLogCount {
  &is_admin;
  my(@log);
  fopen(LOG, "$vardir/clicklog.txt");
  @log = <LOG>;
  fclose(LOG);
  $yyclicks = @log;
}

sub loadfiles {
  require "$boarddir/$language";
  require "$sourcedir/AdminEdit.pl";
  require "$sourcedir/BoardIndex.pl";
  require "$sourcedir/Display.pl";
  require "$sourcedir/ICQPager.pl";
  require "$sourcedir/InstantMessage.pl";
  require "$sourcedir/LockThread.pl";
  require "$sourcedir/LogInOut.pl";
  require "$sourcedir/Maintenance.pl";
  require "$sourcedir/ManageBoards.pl";
  require "$sourcedir/ManageCats.pl";
  require "$sourcedir/Memberlist.pl";
  require "$sourcedir/MessageIndex.pl";
  require "$sourcedir/ModifyMessage.pl";
  require "$sourcedir/MoveThread.pl";
  require "$sourcedir/Notify.pl";
  require "$sourcedir/Post.pl";
  require "$sourcedir/Printpage.pl";
  require "$sourcedir/Profile.pl";
  require "$sourcedir/Recent.pl";
  require "$sourcedir/Register.pl";
  require "$sourcedir/RemoveOldThreads.pl";
  require "$sourcedir/RemoveThread.pl";
  require "$sourcedir/Search.pl";
  require "$sourcedir/Security.pl";
  require "$sourcedir/SendTopic.pl";
  require "$sourcedir/YaBBC.pl";
}

1;