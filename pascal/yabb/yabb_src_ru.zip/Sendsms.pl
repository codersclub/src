#!/usr/bin/perl

#######################################################################
# SendMail2SMS
#
# params IN:
# $phone_number -     the number of gsm phone, like <+COUNTRY><NUMBER_WITHAREACODE>
#                     for example: +97254123456, where +972-Israel, 54-Orange, 132456-phone number
# $sms_message_text - message text in win-1251
# $convert2koi8 -     convert message for sending into koi8: set to 0 if not, 
#                     otherwise - yes
# $from_name -        name of send, for example: "sources.ru reminder"
# $from_mail -        sender's mail, actualy this is smth like reminder@sources.ru
# $to_name -          recipient name, for example "Vasya Pupkin"
#
# params OUT:
# none
#
# return code
# 0 - on error, 1 - on OK
#######################################################################

sub SendMail2SMS()
{
    my($phone_number,$sms_message_text,$convert2koi8,$from_name,$from_mail,$to_name)=@_;
	my(@win2koi8) = (
   "\FF", "\xE7", "\'","\xC7",    "\"",   "...",  "+",    "+", # 80-87 */
   "#",    "%",    "\xEC\xF8",   "<",    "\xEE\xF8",   "\xEB","h", "\xE3", # 88-8F */
   "h",    "`",    "\'",   "\"",   "\"", "\x95",   "-",    "-", # 90-97 */
   "#",    "(TM)", "\xCC\xD8",   ">",    "\xCE\xD8",   "\xCB",    "h",    "\xC3", # 98-9F */
"\x9A",    "\xF5",    "\xD5",    "J",    "\x36",    "\xEF",    "|",    "\x36", # A0-A7 */
"\xB3", "\xBF",    "\xE5",    "\"",   "^",    "-",    "(R)",  "I", # A8-AF */
"\x9C",    "+",    "I",    "i",    "\xC7",    "m",    "#", "\x9E", # B0-B7 */
"\xA3",    "N",    "\xC5",    "\"",   "j",    "S",    "s",    "i", # B8-BF */
"\xE1", "\xE2", "\xF7", "\xE7", "\xE4", "\xE5", "\xF6", "\xFA", # C0-C7 */
"\xE9", "\xEA", "\xEB", "\xEC", "\xED", "\xEE", "\xEF", "\xF0", # C8-CF */
"\xF2", "\xF3", "\xF4", "\xF5", "\xE6", "\xE8", "\xE3", "\xFE", # D0-D7 */
"\xFB", "\xFD", "\xFF", "\xF9", "\xF8", "\xFC", "\xE0", "\xF1", # D8-DF */
"\xC1", "\xC2", "\xD7", "\xC7", "\xC4", "\xC5", "\xD6", "\xDA", # E0-E7 */
"\xC9", "\xCA", "\xCB", "\xCC", "\xCD", "\xCE", "\xCF", "\xD0", # E8-EF */
"\xD2", "\xD3", "\xD4", "\xD5", "\xC6", "\xC8", "\xC3", "\xDE", # F0-F7 */
"\xDB", "\xDD", "\xDF", "\xD9", "\xD8", "\xDC", "\xC0", "\xD1"  # F8-FF */
	);
	#first check if convert and convert
	my($out_sms_message)="";
	if ($convert2koi8)
	{
		my($sms_message_length)=length($sms_message_text); #do not query length each time
		my($i,$char);
		for ($i=0;$i<$sms_message_length;$i++)
		{
			$char=substr($sms_message_text,$i,1);
			if (ord($char)>0x80)
			{
				$char=$win2koi8[ord($char)-0x80];
			}
			$out_sms_message.=$char;
		}
	}
	else
	{
		$out_sms_message=$sms_message_text;
	}
	#Ok, let's send it
	open(SENDMAIL, "|/usr/lib/sendmail -oi -t -odq") || return 0;
	print SENDMAIL "From: $from_name <$from_mail>\n";
	print SENDMAIL "To: $to_name <$phone_number@icqsms.com>\n";
	print SENDMAIL "Subject: $out_sms_message\n";
    	close(SENDMAIL) || warn "sendmail didn't close 8-[]";
	return 1;
}

return 1;