###############################################################################
# Settings.pl                                                                 #
###############################################################################
# YaBB: Yet another Bulletin Board                                            #
# Open-Source Community Software for Webmasters                               #
# Software Version: YaBB 1 Gold - SP1                                         #
# Released: December 2001                                                     #
# =========================================================================== #
# Software Distributed by:    http://yabb.xnull.com                           #
# Support, News, Updates at:  http://yabb.xnull.com/community/                #
# =========================================================================== #
# Copyright (c) 2000-2002 Xnull (www.xnull.com) - All Rights Reserved.        #
# Software by: The YaBB Development Team                                      #
#              with assistance from the YaBB community.                       #
###############################################################################

########## Board Info ##########
# Note: these settings must be properly changed for YaBB to work

$maintenance = 0;                                                     # Set to 1 to enable Maintenance mode
$guestaccess = 1;                                                     # Set to 0 to disallow guests from doing anything but login or register

$language = "russian.lng";                                            # Change to language pack you wish to use
$mbname = "����� �� ����������.Ru";                                   # The name of your YaBB forum
$siteurl  = "http://pascal.sources.ru";                 		      # Your site URL (without trailing '/')
$boardurl = "/cgi-bin/forum";                 # URL of your board's folder (without trailing '/')

$Cookie_Length = 360;                                                 # Default minutes to set login cookies to stay for
$cookieusername = "YaBBusername";                                     # Name of the username cookie
$cookiepassword = "YaBBpassword";                                     # Name of the password cookie

$RegAgree = 0;                                                        # Set to 1 to display the registration agreement when registering
$emailpassword = 0;                                                   # 0 - instant registration. 1 - password emailed to new members
$emailnewpass = 0;                                                    # Set to 1 to email a new password to members if they change their email address
$emailwelcome = 0;                                                    # Set to 1 to email a welcome message to users even when you have mail password turned off

$mailprog = "/usr/libexec/sendmail/sendmail";                         # Location of your sendmail program
$smtp_server = "smtp.mysite.com";                                     # Address of your SMTP-Server
$webmaster_email = q^webmaster@sources.ru^;                           # Your email address. (eg: $webmaster_email = q^admin@host.com^;)
$mailtype = 0;                                                        # Mail program to use: 0 = sendmail, 1 = SMTP, 2 = Net::SMTP


########## Directories/Files ##########
# Note: directories other than $imagesdir do not have to be changed unless you move things

$boarddir = ".";                                                      # The server path to the board's folder (usually can be left as '.')
$boardsdir = "./Boards";                                              # Directory with board data files
$datadir = "./Messages";                                              # Directory with messages
$memberdir = "./Members";                                             # Directory with member files
$sourcedir = "./Sources";                                             # Directory with YaBB source files
$vardir = "./Variables";                                              # Directory with variable files
$facesdir = "../../htdocs/yabb/YaBBImages/avatars";                   # The server path to your avatars (userpics) folder
$facesurl = "/yabb/YaBBImages/avatars";                               # URL to your avatars folder
$imagesdir = "/yabb/YaBBImages";                                      # URL to your images folder
$ubbcjspath = "/yabb/ubbc.js";                                        # URL to your 'ubbc.js' (REQUIRED for post/modify to work properly)
$faderpath = "/yabb/fader.js";                                        # URL to your 'fader.js'
$helpfile = "/yabb/help/index.html";                                  # URL to your help file
$templates[0] = "template.html";                                      # Main template (Number Zero = template.html)
$templates[1] = "template1.html";                                     # Second template (Number One = template2.html)


########## Colors ##########
# Note: equivalent to colors in CSS tag of template.html,
# so set to same colors preferrably for browsers without CSS
# compatibility and for some items that don't use the CSS tag

# User Specified Colors
$color{'titlebg'}   = "#6E94B7";                                      # Background color of the 'title-bar'
$color{'titletext'} = "#FFFFFF";                                      # Color of text in the 'title-bar' (above each 'window')
$color{'windowbg'}  = "#DEDFDF";                                      # Background color for messages/forms etc.
$color{'windowbg2'} = "#F8F8F8";                                      # Background color for messages/forms etc.
$color{'windowbg3'} = "#6394BD";                                      # Color of horizontal rules in posts
$color{'catbg'}     = "#DEE7EF";                                      # Background color for category (at Board Index)
$color{'bordercolor'} = "#6394BD";                                    # Table Border color for some tables
$color{'fadertext'} = "#D4AD00";                                      # Color of text in the NewsFader (news color)

# Default Color Settings
$titlebg     = "#6E94B7";                                             # Background color of the 'title-bar'
$titletext   = "#FFFFFF";                                             # Color of text in the 'title-bar' (above each 'window')
$windowbg    = "#DEDFDF";                                             # Background color for messages/forms etc.
$windowbg2   = "#F8F8F8";                                             # Background color for messages/forms etc.
$windowbg3   = "#6394BD";                                             # Color of horizontal rules in posts
$catbg       = "#DEE7EF";                                             # Background color for category (at Board Index)
$bordercolor = "#6394BD";                                             # Table Border color for some tables
$fadertext   = "#D4AD00";                                             # Color of text in the NewsFader (news color)
########## Layout ##########

$maintenancetext = "��������, ����� �� ����������� ������������. �������, ����������, �������.";
                                                                      # User-defined text for Maintenance mode (leave blank for default text)
$MenuType         = 1;                                                # 1 for text menu or anything else for images menu
$curposlinks      = 0;                                                # 1 for links in navigation on current page, or 0 for text without link
$profilebutton    = 0;                                                # 1 to show view profile button under post, or 0 for blank
$timeselected     = 2;                                                # Select your preferred output Format of Time and Date
$allow_hide_email = 1;                                                # Allow users to hide their email from public. Set 0 to disable
$showlatestmember = 0;                                                # Set to 1 to display "Welcome Newest Member" on the Board Index
$shownewsfader    = 0;                                                # 1 to allow or 0 to disallow NewsFader javascript on the Board Index
                                                                      # If 0, you'll have no news at all unless you put <yabb news> tag
                                                                      # back into template.html!!!
$Show_RecentBar  = 0;                                                 # Set to 1 to display the Recent Post on Board Index
$showmarkread    = 1;                                                 # Set to 1 to display and enable the mark as read buttons
$showmodify      = 0;                                                 # Set to 1 to display "Last modified: Realname - Date" under each message
$ShowBDescrip    = 1;                                                 # Set to 1 to display board descriptions on the topic (message) index for each board
$showuserpic     = 0;                                                 # Set to 1 to display each member's picture in the message view (by the ICQ.. etc.)
$showusertext    = 0;                                                 # Set to 1 to display each member's personal text in the message view (by the ICQ.. etc.)
$showgenderimage = 0;                                                 # Set to 1 to display each member's gender in the message view (by the ICQ.. etc.)
$showyabbcbutt   = 0;                                                 # Set to 1 to display the yabbc buttons on Posting and IM Send Pages

########## Feature Settings ##########

$enable_ubbc = 1;                                                     # Set to 1 if you want to enable UBBC (Uniform Bulletin Board Code)
$enable_news = 1;                                                     # Set to 1 to turn news on, or 0 to set news off
$allowpics = 1;                                                       # set to 1 to allow members to choose avatars in their profile
$enable_guestposting = 1;                                             # Set to 0 if do not allow 1 is allow.
$enable_notification = 1;                                             # Allow e-mail notification
$autolinkurls = 1;                                                    # Set to 1 to turn URLs into links, or 0 for no auto-linking.

$timeoffset = 0;                                                      # Time Offset (so if your server is EST, this would be set to -1 for CST)
$TopAmmount = 35;                                                     # No. of top posters to display on the top members list
$MembersPerPage = 35;                                                 # No. of members to display per page of Members List - All
$maxdisplay = 30;                                                     # Maximum of topics to display
$maxmessagedisplay = 30;                                              # Maximum of messages to display
$MaxMessLen = 30000;                                                  # Maximum Allowed Characters in a Posts
$MaxSigLen = 200;                                                     # Maximum Allowed Characters in Signatures
$ClickLogTime = 1440;                                                 # Time in minutes to log every click to your forum (longer time means larger log file size)
$max_log_days_old = 31;                                               # If an entry in the user's log is older than ... days remove it
                                                                      # Set to 0 if you want it disabled
$fadertime = 1000;                                                    # Length in milliseconds to delay between each item in the news fader
$timeout = 5;                                                         # Minimum time between 2 postings from the same IP


########## Membergroups ##########

$JrPostNum    = 25;                                                   # Number of Posts required to show person as 'junior' membergroup
$FullPostNum  = 100;                                                  # Number of Posts required to show person as 'full' membergroup
$SrPostNum    = 250;                                                  # Number of Posts required to show person as 'senior' membergroup
$ProfiPostNum = 500;                                                  # Number of Posts required to show person as 'profi' membergroup
$ElderPostNum = 1000;                                                 # Number of Posts required to show person as 'master' membergroup
$GuruPostNum  = 2500;                                                 # Number of Posts required to show person as 'guru' membergroup
$ArchPostNum  = 5000;                                                 # Number of Posts required to show person as 'wizard' membergroup
$GodPostNum   = 10000;                                                # Number of Posts required to show person as 'god' membergroup


########## MemberPic Settings ##########

$userpic_width = 120;                                                 # Set pixel size to which the selfselected userpics are resized, 0 disables this limit
$userpic_height = 120;                                                # Set pixel size to which the selfselected userpics are resized, 0 disables this limit
$userpic_limits = qq~������ �������� - <b>gif, jpg, png</b>, ����. ������ �� ����� 120x120.~;
                                                                      # Text To Describe The Limits


########## File Locking ##########

$LOCK_EX = 2;                                                         # You can probably keep this as it is set now.
$LOCK_UN = 8;                                                         # You can probably keep this as it is set now.
$LOCK_SH = 1;                                                         # You can probably keep this as it is set now.

$use_flock = 1;                                                       # Set to 0 if your server doesn't support file locking,
                                                                      # 1 for Unix/Linux and WinNT, and 2 for Windows 95/98/ME

$usetempfile = 0;                                                     # Write to a temporary file when updating large files.
                                                                      # This can potentially save your board index files from
                                                                      # being corrupted if a process aborts unexpectedly.
                                                                      # 0 to disable, 1 to enable.

$faketruncation = 0;                                                  # Enable this option only if YaBB fails with the error:
                                                                      # "truncate() function not supported on this platform."
                                                                      # 0 to disable, 1 to enable.

1;
