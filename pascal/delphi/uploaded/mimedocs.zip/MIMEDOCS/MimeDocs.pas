unit MimeDocs;
{
 Copyright (C) 1998-2K Paul TOTH <tothpaul@free.fr>
 http://tothpaul.free.fr

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.

Updates (maintened by Paul TOTH)
 * 11 october  2000 - minor change (GMT) & minor bug fix.
 * 18 november 2000 - minor bugs (empty date, DeQuote =00 & CR/LF)
 * 19 march    2001 - add "GetName" function to get attached file name on "NextLine"
 * 26 april    2001 - unfixed GMT bug (TimeZoneBias of current date is used) - jack.r@free.fr
 * 23 november 2001 - fix number (in GMT), add test (p<=length(s))
 * 14 feb.     2002 - Modified for speed from a code by AdemBaba, adembaba@excite.com
                    - fix#1 unencoded Attachments
 * 18 feb.     2002 - fix#2 ISO decode

}

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs;

type
  TAttachment=class
  private
   Constructor Create;
  public
   Data:TMemoryStream;
   ContentType:string;
   FileName:string;
   Destructor Destroy; override;
   function Caption:string;
  end;

  TMimeDoc = class(TComponent)
  private
   fSource:TStringList;
   fHeader:TStringList;
   fBody  :TStringList;
   fAttach:TStringList;
   Procedure SetSource(Value:TStringList);
   Procedure SetHeader(Value:TStringList);
   Procedure SetBody(Value:TStringList);
   Function GetAttachment(Index:integer):TAttachment;
   procedure SourceChange(Sender:TObject);
  protected
   Procedure Decode(Header,Body:TStringList);
   Procedure ClearAttach;
  public
   Constructor Create(AOwner:TComponent); override;
   Destructor Destroy; override;
   Property Attachment[Index:integer]:TAttachment read GetAttachment;// write SetAttachment;
   Property Attachments:TStringList read fAttach;
   Procedure Clear;
  published
   Property Source:TStringList read fSource write SetSource;
   Property Header:TStringList read fHeader write SetHeader;
   Property Body:TStringList read fBody write SetBody;
  end;

procedure Register;

Function Base64ToStr(Const s:string):string;
Function DeQuote(s:string):string;
function ISO(s:string):string;
function Account(s:string):string;
function GMT(s:string):TDateTime;
function WindowsExtension(MimeType:string):string; // return ".htm" for "text/html"

implementation

procedure Register;
begin
  RegisterComponents('MySoft', [TMimeDoc]);
end;

//--- Decode
Const
 B64:array[0..63] of char=
     'ABCDEFGHIJKLMNOPQRSTUVWXYZ'+ { 26 }
     'abcdefghijklmnopqrstuvwxyz'+ { 52 }
     '0123456789'+                 { 62 }
     '+/';                         { 64 }
// Modified for speed from a code by AdemBaba, adembaba@excite.com
// this lookup table replace pos( ... , B64);
var
 Decode64:array[#0..#255] of byte;

procedure InitBase64;
 var
  i:integer;
 begin
  for i:=0 to 63 do Decode64[B64[i]]:=i;
 end;

Function Base64ToStr(Const s:string):string;
 var
  Shift:byte;
  i:integer;
  c1,c2:byte;
  len:integer;
 begin
  SetLength(Result,length(s)); // dummy size
  len:=0;
  Shift:=0;
  c1:=0;
  c2:=0;
  For i:=1 to length(s) do begin
   if s[i]<>'=' then c2:=Decode64[s[i]];//pos(s[i],B64)-1; // fixed 05-14-1999
   if Shift>0 then begin
    inc(len);
    Result[len]:=chr((c1 shl shift) or (c2 shr (6-shift)));
   end;
   shift:=(shift+2)and 7;
   c1:=c2;
  end;
  SetLength(result,len);
 end;

function DeQuote(s:string):string;
 const
  hexa:array[1..$F] of char='123456789ABCDEF';
 var
  p:integer;
  encode:string;
 begin
  if s='' then begin // 05-14-1999
   result:=#13#10;
   exit;
  end;
  result:='';
  if s[length(s)]='=' then SetLength(s,Length(s)-1) else begin
   if (length(s)>=3)and (s[length(s)-2]<>'=') then s:=s+#13#10;
  end;
  p:=pos('=',s);
  while p>0 do begin // WARNING ! "=" is coded as "=3D" !
   encode:=chr(pos(s[p+1],hexa)*16+pos(s[p+2],hexa));
   if encode=#0 then encode:=#13#10; // 10-18-2000
   result:=result+copy(s,1,p-1)+encode;
   delete(s,1,p+2);
   p:=pos('=',s);
  end;
  result:=result+s;
  p:=pos('_',result);
  while p>0 do begin
   result[p]:=' ';
   p:=pos('_',result);
  end;
 end;

function UTF7ToStr(s:string):string;
 var
  p:integer;

  function unicode(s:string):string;
   var
    i:integer;
   begin
    result:='';
    i:=2;
    while (i<=length(s)) and (s[i]<>#0) do begin
     result:=result+s[i];
     inc(i,2);
    end;
   end;

 begin
  if s='+-' then result:='+' else
  if s='-'  then result:='-' else begin
   result:='';
   p:=pos('+',s);
   while (p>0)and(p<length(s)) do begin
    result:=result+copy(s,1,p-1);
    delete(s,1,p);
    p:=pos('-',s);
    case p of
     0 : begin result:=result+Unicode(Base64ToStr(s)); s:='' end; // should be : all valide Base64 char except "="
     1 : begin result:=result+'+'; delete(s,1,1) end; // "+-" is "+"
     else begin
      result:=result+Unicode(Base64ToStr(Copy(s,1,p-1))); // "+<base64 widestring>-"
      delete(s,1,p);
     end;
    end;
    p:=pos('+',s);
   end;
   result:=result+s;
  end;
 end;

function ISO(s:string):string;
 var
  q:string;
  encode:char;
  p1,p2,p3:integer;
  us:string; // fix#2 uppercase ISO
 begin
  Result:='';
  us:=uppercase(s);
  p1:=pos('=?ISO',us);
  while p1>0 do begin
   q:=copy(s,p1+2,length(s));
   p2:=pos('?',q);  if (p2=0)or(p2>=length(q)-2)or(q[p2+2]<>'?') then break;
   encode:=Upcase(q[p2+1]);
   q:=copy(q,p2+3,length(q));
   p3:=pos('?=',q); if p3=0 then break;
   setlength(q,p3-1);
   if encode='B' then q:=Base64ToStr(q) else
   if encode='Q' then q:=DeQuote(q+'=') else break;
   result:=result+copy(s,1,p1-1)+q;
   inc(p1,2+p2+2+p3);
   delete(s,1,p1);
   delete(us,1,p1);
   p1:=pos('=?ISO',us);
  end;
 // new utf7
  p1:=pos('=?UTF-7',us);
  while p1>0 do begin
   q:=copy(s,p1+2,length(s));
   p2:=pos('?',q);  if (p2=0)or(p2>=length(q)-2)or(q[p2+2]<>'?') then break;
   encode:=Upcase(q[p2+1]);
   q:=copy(q,p2+3,length(q));
   p3:=pos('?=',q); if p3=0 then break;
   setlength(q,p3-1);
   if encode='B' then q:=Base64ToStr(q) else
   if encode='Q' then q:=DeQuote(q+'=') else break;
   q:=UTF7ToStr(q);
   result:=result+copy(s,1,p1-1)+q;
   inc(p1,2+p2+2+p3);
   delete(s,1,p1);
   delete(us,1,p1);
   p1:=pos('=?UTF-7',us);
  end;
  Result:=Result+s;
 end;

function Account(s:string):string; // account : "LastName FirstName" <email@server>
 var
  p:integer;
 begin
  result:=s;
  p:=pos('<',s); if p>1 then setlength(s,p-1);
  if s<>'' then Result:=s;
  p:=pos('"',s);
  if p>0 then begin
   delete(s,1,p);
   setlength(s,pos('"',s)-1);
   if s<>'' then result:=s;
  end;
 end;

Function DaysInMonth(Year,Month:word):integer;
 begin
  if Month>6 then begin
   Result:=30+(Succ(Year) and 1);
  end else begin
   if Month=2 then begin
    Result:=28;
    if ((Year and 3) = 0) and ((Year mod 100 > 0) or (Year mod 400 = 0)) then inc(Result);
   end else
    Result:=30+(Year and 1);
  end;
 end;

Function Day2Date(year,month,week,dayofweek:word):TDateTime;
 var
  d,i:integer;
 begin
  if week=5 then begin // last "dayofweek" of "month"
   d:=DaysInMonth(Year,month);
   inc(DayOfWeek); // "0 based" to "1 based"
   for i:=0 to 6 do begin
    Result:=EncodeDate(Year,Month,d);
    if SysUtils.DayOfWeek(Result)=DayOfWeek then exit;
    dec(d);
   end;
   // Invalide date ?!
  end else begin
   d:=7*(week-1)+DayOfWeek-SysUtils.DayOfWeek(EncodeDate(Year,Month,1));
   Result:=EncodeDate(Year,Month,d);
  end;
 end;

Function EncodeGMTDate(y,m,d,hh,mm,ss,gmt:integer):TDateTime;
 const
  TIME_ZONE_ID_STANDARD=1; // missing in Delphi 2 windows.pas unit
  TIME_ZONE_ID_DAYLIGHT=2;
 var
  TZInfo:TTimeZoneInformation;
  bias:integer;
 begin
  Result:=EncodeDate(y,m,d)+EncodeTime(hh,mm,ss,0);
(* bug reported by jack.r@free.fr *)
  case GetTimeZoneInformation(TZInfo) of
   TIME_ZONE_ID_STANDARD : bias:=TZInfo.StandardBias;
   TIME_ZONE_ID_DAYLIGHT : bias:=TZInfo.DayLightBias;
   else bias:=0;
  end;
(*
  GetTimeZoneInformation(TZInfo);
  bias:=GetBias(y,m,d,TZInfo);
  .........
*)
  gmt:=gmt+(TZInfo.Bias div 60)*100+TZInfo.Bias mod 60; // Standard Time
  if bias<>0 then gmt:=gmt+(Bias div 60)*100+Bias mod 60;
  if gmt>0 then
   Result:=Result-EncodeTime(gmt div 100,gmt mod 100,0,0)
  else begin
   gmt:=-gmt;
   Result:=Result+EncodeTime(gmt div 100,gmt mod 100,0,0);
  end;
 end;

function GMT(s:string):TDateTime;
 const
  months='JANFEBMARAPRMAYJUNJULAUGSEPOCTNOVDEC';
 var
  p:byte;
  month:string;
  d,m,y:word;
  hh,mm,ss:word;
  gmt:integer;
  neg:boolean;

  procedure spaces;
   begin
    while (p<=length(s))and(s[p]=' ') do inc(p);
   end;

  function number:word;
   begin
    result:=0;
    // fix length(s) !!!
    while (p<=length(s))and(s[p] in ['0'..'9']) do begin
     result:=10*result+ord(s[p])-ord('0'); inc(p);
    end;
   end;

 begin
// day of week
  p:=pos(',',s); if p>0 then delete(s,1,p+1);
// day
  p:=1; spaces; d:=number;
// month
  spaces; if s[p]='-' then inc(p);  month:='';
  while not (s[p] in [' ','-']) do begin month:=month+upcase(s[p]); inc(p) end;
  m:=pos(month,months) div 3+1;
// year
  spaces; if s[p]='-' then inc(p);  y:=number;
  if y<100 then if y<50 then y:=y+2000 else y:=y+1900;
 // hour, min, sec
  spaces; hh:=number; inc(p); mm:=number; inc(p); ss:=number;
 // GMT
  spaces;  neg:=s[p]='-'; inc(p); gmt:=number;
  if neg then gmt:=-gmt;

  Result:=EncodeGMTDate(y,m,d,hh,mm,ss,gmt);
 end;

Function GMTDate(s:string):string;
 begin
  if s='' then Result:='' else DateTimeToString(Result,'dddddd tt',GMT(s));
 end;

function uudecode(s:string):string;
 var
  i,x,ss:integer;

  function uuchar(c:char):integer;
   begin
    result:=(ord(c)-32) and $3F;
   end;

 begin
  result:='';
  if s='' then exit;
  SetLength(Result,uuchar(s[1]));
  x:=2;
  ss:=2;
  for i:=1 to length(Result) do begin
   result[i]:=chr( (uuchar(s[x]) shl ss) or (uuchar(s[x+1]) shr (6-ss)));
   inc(ss,2);
   if ss=8 then begin ss:=2; inc(x) end;
   inc(x);
  end;
 end;

Function ReadRegString(Key:HKEY;Path:string;Value,Default:string):string;
 Var
  Handle:HKEY;
  RegType:integer;
  DataSize:integer;
 begin
  Result:=Default;
  if (RegOpenKeyEx(Key,pchar(Path),0,KEY_ALL_ACCESS,Handle)=ERROR_SUCCESS) then begin
   if RegQueryValueEx(Handle,pchar(Value),nil,@RegType,nil,@DataSize)=ERROR_SUCCESS then begin
    SetLength(Result,Datasize);
    RegQueryValueEx(Handle,pchar(Value),nil,@RegType,PByte(pchar(Result)),@DataSize);
    SetLength(Result,Datasize-1);
   end;
   RegCloseKey(Handle);
  end;
 end;

function WindowsExtension(MimeType:string):string; // return ".htm" for "text/html"
 begin
  Result:=ReadRegString(HKEY_CLASSES_ROOT,'\MIME\Database\Content Type\'+LowerCase(MimeType),'Extension','');
 end;

//--- Attachement
Constructor TAttachment.Create;
 begin
  inherited create;
  Data:=TMemoryStream.Create;
 end;

Destructor TAttachment.Destroy;
 begin
  Data.Free;
  inherited Destroy;
 end;

Function TAttachment.Caption:string;
 begin
  if FileName='' then Result:='*.'+WindowsExtension(ContentType) else Result:=FileName;
 end;

//--- MimeDoc

Constructor TMimeDoc.Create(AOwner:TComponent);
 begin
  inherited Create(AOwner);
  fSource:=TStringList.Create;
  fHeader:=TStringList.Create;
  fBody:=TStringList.Create;
  fAttach:=TStringList.Create;
  fSource.OnChange:=SourceChange;
 end;

Destructor TMimeDoc.Destroy;
 begin
  Clear;
  fSource.Free;
  fHeader.Free;
  fBody.Free;
  fAttach.Free;
  inherited Destroy;
 end;

Procedure TMimeDoc.Clear;
 begin
  fSource.Clear;
  fHeader.Clear;
  fBody.Clear;
  ClearAttach;
 end;

procedure TMimeDoc.SourceChange(Sender:TObject);
 var
  Header,Body:TStringList;
  Head:boolean;
  i,p:integer;
  s,ss:string;
 begin
  fHeader.Clear;
  fBody.Clear;
  ClearAttach;

  Header:=TStringList.Create;
  Body:=TStringList.Create;
  try
   Head:=True;
   for i:=0 to fSource.Count-1 do begin
    s:=fSource[i];
    if Head then begin
     p:=pos(': ',s);
     if p>0 then ss:=uppercase(copy(s,1,p-1)) else ss:='';
     if ss='FROM' then fHeader.Values['FROM']:=ISO(Copy(s,7,length(s))) else
     if ss='TO'   then fHeader.Values['TO']:=ISO(Copy(s,5,length(s))) else
     if ss='SUBJECT' then fHeader.Values['SUBJECT']:=ISO(Copy(s,10,length(s))) else
     if ss='DATE' then begin
      fHeader.Values['DATE']:=GMTDate(Copy(s,7,Length(s)));
      fHeader.Values['GMTDate']:=Copy(s,7,Length(s));
     end else
     if s='' then Head:=False else Header.Add(s);
    end else
     Body.Add(s);
   end;
   Decode(Header,Body);
  finally
   Header.Free;
   Body.Free;
  end;
 end;

Procedure TMimeDoc.Decode(Header,Body:TStringList);
 type
  TEncoding=(ecText,ecBase64,ecQuoted,ecUU);
 var
  status:(stHeader,stBody,stPart);
  multipart:boolean;
  Encoding:TEncoding;
  Content:string;
  i,j:integer;
  s,ss:string;
  Boundary:string;
  p:integer;
  HeaderPart:TStringList;
  BodyPart:TStringList;
  FileName:string;
  Attachment:TAttachment;
  uucode:TStringList;
  uuname:string;
  oldcode:TEncoding;

  function GetName(s:string{; NextLine:boolean}):string;
   var
    i:integer;
   begin
    Result:='';
    if s='' then exit;
    //if NextLine and (s[1]<>#9) then exit;
    i:=pos('name=',s);
    if i=0 then exit;
    Result:=Copy(s,i+5,length(s));
    if Result[1]='"' then begin
     Delete(Result,1,1);
     SetLength(Result,Pos('"',Result)-1);
    end;
   end;

 begin
//  status:=stHeader;
  multipart:=false;
  Encoding:=ecText;
  Content:='TEXT/PLAIN';
  for i:=0 to Header.Count-1 do begin
   s:=Header[i];
   p:=pos(': ',s);
   if p>0 then ss:=uppercase(copy(s,1,p-1)) else ss:='';
   if ss='CONTENT-TYPE' then begin
    Content:=Copy(s,15,length(s));
    p:=pos(';',Content);
    if p>0 then SetLength(Content,p-1);
    Content:=uppercase(Content);
    FileName:=GetName(s{,false});
    if (FileName='')and(i<Header.Count-1) then FileName:=GetName(Header[i+1]{,true});
    if pos('MULTIPART',Content)>0 then multipart:=true;
   end else
   if ss='CONTENT-TRANSFER-ENCODING' then begin
    if pos('quoted-printable',s)>0 then Encoding:=ecQuoted else
    if pos('base64',s)>0 then Encoding:=ecBase64 else
    if pos('UUencode',s)>0 then Encoding:=ecUU else
    Encoding:=ecText;
   end;

   if multipart then begin
    p:=pos('boundary=',s);
    if p>0 then begin
     Boundary:=copy(s,p+9,length(s));
     if Boundary[1]='"' then begin
      delete(Boundary,1,1);
      setlength(Boundary,pos('"',Boundary)-1);
     end;
     Boundary:='--'+Boundary;
    end; // boundary
   end; // multipart
  end; // For Header

 // MultiPart Mail
  if multipart then begin
//   Status:=stBody;
   HeaderPart:=TStringList.Create;
   BodyPart:=TStringList.Create;

   Status:=stBody;
   for i:=0 to Body.Count-1 do begin
    s:=Body[i];
    case Status of
     stBody: begin
      if (s=Boundary)or(s=Boundary+'--') then begin
       Decode(HeaderPart,BodyPart);
       Status:=stHeader;
       HeaderPart.Clear;
      end else
       BodyPart.Add(s);
     end;
     stHeader:begin
      if s='' then begin
       Status:=stBody;
       BodyPart.Clear;
      end else
       HeaderPart.add(s);
     end;
    end;
   end;

   HeaderPart.Free;
   BodyPart.Free;
   exit;
  end;

 // not a multipart Mail - or - a Part of a multipart mail

  if Content='TEXT/PLAIN' then begin
   uucode:=TStringList.Create;
   for i:=0 to Body.Count-1 do begin
    s:=Body[i];
   // UUEncode
    if (Encoding<>ecUU)and(copy(s,1,7)='begin 6') then begin
     oldcode:=Encoding;
     Encoding:=ecUU;
     uuname:=copy(s,7,length(s));
     delete(uuname,1,pos(' ',uuname));
    end;
    case Encoding of
     ecText  : fBody.add(s);
     ecBase64: fBody.add(Base64ToStr(s));
     ecQuoted: begin
      //fBody.Text:=fBody.Text+DeQuote(s);
      s:=DeQuote(s);
      if fBody.Count=0 then fBody.Add(s) else fBody[fBody.Count-1]:=fBody[fBody.Count-1]+s;
     end;
     ecUU    : if s='end' then begin
                Attachment:=TAttachment.Create;
                Attachment.FileName:=uuname;
                for j:=1 to uucode.Count-1 do begin
                 s:=UUDecode(uucode[j]);
                 Attachment.Data.WriteBuffer(s[1],length(s));
                end;
                fAttach.AddObject(Attachment.Caption,Attachment);
                uucode.clear;
                encoding:=oldcode;
                fBody.Add('<included file:'+uuname+'>');
               end else begin
                uucode.add(s);
               end;
    end;
   end;
  // add uucode if we haven't decode it
   for i:=0 to uucode.Count-1 do begin
    s:=uucode[i];
    case Encoding of
     ecText  : fBody.add(s);
     ecBase64: fBody.add(Base64ToStr(s));
     ecQuoted: begin
      // fBody.Text:=fBody.Text+DeQuote(s);
      s:=DeQuote(s);
      if fBody.Count=0 then fBody.Add(s) else fBody[fBody.Count-1]:=fBody[fBody.Count-1]+s;
     end;
    end;
   end;
   uucode.free;

  end else begin

   if FileName='' then FileName:='unknow'+IntToStr(fAttach.Count+1)+WindowsExtension(Content);
   fBody.add('<attached file:'+FileName+' '+Content+'>');
   Attachment:=TAttachment.Create;
   Attachment.ContentType:=Content;
   if FileName<>'' then Attachment.FileName:=FileName;
   if Encoding=ecUU then begin
     for i:=1 to Body.Count-2 do begin // skip "begin" and "end" lines...
      s:=UUDecode(Body[i]);
      Attachment.Data.WriteBuffer(s[1],length(s));
     end;
   end else begin
     for i:=0 to Body.Count-1 do begin
      s:=Body[i];
      case Encoding of
       ecBase64: s:=Base64ToStr(s);
       ecQuoted: s:=DeQuote(s);
       else      s:=s+#13#10; // fix#1 14 feb 2002
      end;
      Attachment.Data.WriteBuffer(s[1],length(s));
     end;
   end;
   fAttach.AddObject(Attachment.Caption,Attachment);
  end;
end;

Procedure TMimeDoc.SetSource(Value:TStringList);
 begin
  fSource.Assign(Value);
 end;

Procedure TMimeDoc.SetHeader(Value:TStringList);
 begin
  fHeader.Assign(Value);
 end;

Procedure TMimeDoc.SetBody(Value:TStringList);
 begin
  fBody.Assign(Value);
 end;

Function TMimeDoc.GetAttachment(Index:integer):TAttachment;
 begin
  Result:=TAttachment(fAttach.Objects[Index]);
 end;

Procedure TMimeDoc.ClearAttach;
 var
  i:integer;
 begin
  try
   for i:=0 to fAttach.Count-1 do TAttachment(fAttach.Objects[i]).Free;
  finally
   fAttach.Clear;
  end;
 end;

Initialization
 InitBase64; // compute lookup table
end.
