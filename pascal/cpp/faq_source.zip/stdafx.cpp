
	#include "stdafx.h"