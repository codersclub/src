
	#include "stdafx.h"

char szPath[MAX_PATH];
char szPath1[MAX_PATH];

int FindSubstring(LPSTR lpString, LPSTR lpSub)
{
	if (!*lpString || !*lpSub) // ������ �� ������
		return -1;
	
	LPSTR lp = lpString;
	LPSTR lp1 = 0;
	LPSTR lp2 = 0;

	do
	{
		if (*lp == *lpSub) // ���� ������ ������ ���������
		{
			lp2 = lp;
			lp1 = lpSub;
			for (;;lp2++,lp1++) // ���������� ����� ��� ��� ��������, ����� �� �������� �������
			{
				if (*lp1 && *lp2 && (*lp1 != *lp2)) // ���� ������ �� ���������
					break;
				else if (!*lp1 || !*lp2) // ���� ������� ������ �����������, �� ���� ������ �����
					return ((int)lp-(int)lpString); // ���������� ��������� �������
			}
		}
	}
	while (*(lp++)); // ���� �� �������!

	return -1; // ���� ��� �� �����, ���������� -1
}

void Delete(LPSTR lpsz, int i)
{
	char c[] = "\0\0";
	for (int a = 0; a < i; a++)
	{
		for (unsigned int b = 0; b < strlen(lpsz) - 1; b++)
		{
			strncpy(c, lpsz + b + 1, 1);
			strncpy(lpsz+b, c, 1);

		}
		strncpy(lpsz + strlen(lpsz) - 1, "\0", 1);
	}
}

inline int CharToInt(LPSTR lp)
{
	int iValue = 0;
	bool bmin = 0;
	unsigned char s = 0;

	if (*lp == '-')
		bmin = 1;

	for (int i = (bmin)?1:0; *(lp+i); i++)
	{
		s = ((*(lp+i)) -'1' + 1);

		if (s >= 0 && s <= 9)
		{
			iValue *= 10;
			iValue += s;
		}
		else
			break;
	}

	return ((bmin)?(-iValue):(iValue));
}

inline LPSTR FindBegin(LPSTR lpAllFile, int &i)
{
	LPSTR lp = lpAllFile;
	/*int */i = FindSubstring(lp, "<body");
	lp = lpAllFile + i - 1;
	while (*(++lp) != '\n')
		i++;

	lp++;
	return lp;
}

inline bool AnalyseLink(LPSTR lp)
{
	lp--;
	while (*lp && *lp != '"')
	{
		if (*lp < '0' || *lp > '9')
			return 0;

		lp--;
	}
	return 1;
}

inline int ConvertLinks(LPSTR lp)
{
	int t = 0;
	int t1 = 0;
	while (*lp)
	{
		if (*(lp+t*3) == '.' && !strncmp((lp+t*3), ".htm", 4) && AnalyseLink(lp))
		{
			t1 = 0;
			*lp = 0;


			while (*lp != '"')
			{
				*lp = *(lp - 1);
				t1++;
				lp--;
			}
			lp++;
			
			*lp = '#';			

			t++;
			lp += t1;
		}

		if (t)
			*lp = (char)*(char*)(lp + t*3);

		lp++;
	}

	return 0;
}


inline int find (LPSTR lpString, char * first, ...)
{
	int i = -1, i1 = 0;

	LPSTR lp;
	va_list lp_marker;

	va_start(lp_marker, first);
	lp = first;
	while (*lp != 0)
	{
		i1 = FindSubstring(lpString, lp);
		if ((i1 != -1) && (i > i1) || i == -1)
			i = i1;		
		lp = (char*)va_arg(lp_marker, char *);
	};
	va_end( lp_marker );

	return i;
}


inline short ReadLevels(LIST *s, LPSTR lp = 0)
{
	int i = 0;
	bool b = 0;
	short counter = 0;
	short level = 0;
	DWORD d = 0, dwBytesRead = 0;

	HANDLE hFile = 0;
	char tmp[MAX_PATH];

	if (lp == 0)
	{
		strcpy(tmp, (*szPath)?szPath:szDirOutName);
		strcat(tmp, "\\");
		strcat(tmp, "content.htm");
		
		hFile = CreateFile((LPCTSTR)tmp,
									GENERIC_READ,
									FILE_SHARE_READ,
									NULL,
									OPEN_ALWAYS,
									FILE_ATTRIBUTE_NORMAL,
									(HANDLE)NULL);

		if ((!hFile) && (hFile == (void*)0xffffffff))					
			return 0;
		
		d = GetFileSize(hFile, 0l);
		lp = (LPSTR)GlobalAlloc(GMEM_FIXED, d+1);
		memset(lp, 0, GlobalSize(lp));

		ReadFile(hFile, lp, d, &dwBytesRead, (LPOVERLAPPED) NULL);
	}

#ifdef _DEBUG
	strcpy(tmp, (*szPath)?szPath:szDirOutName);
	strcat(tmp, "\\");
	strcat(tmp, "my.bin");
	HANDLE hFile1 = CreateFile((LPCTSTR)tmp,
								GENERIC_WRITE,
								FILE_SHARE_WRITE,
								NULL,
								CREATE_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);
#endif

	while ((i = find(lp, "<ul>", "</ul>", "name=\"bk", "\0")) != -1)
	{
		lp += i;
		if (!strncmp(lp, "<ul>", 4))
		{
			lp += 4;
			level++;
		}
		else if (!strncmp(lp, "</ul>", 5))
		{
			lp += 5;
			level--;
		}
		else
		{
			lp += 8;
			s[counter].number = CharToInt(lp);
			s[counter].level = level - 1;
			//sprintf(tmp, "%i) name: %i.htm - level: %i\r\n", counter, s[counter].number, s[counter].level);
#ifdef _DEBUG
			strnset(tmp, 0, sizeof(tmp));
			strncpy(tmp, "\t\t\t\t\t\t\t\t\t\t\t\t", s[counter].level);
			//*(tmp+s[counter].level-1) = 0;

			sprintf(tmp+strlen(tmp), "(%i) %i.htm\r\n", s[counter].level, s[counter].number);
			WriteFile(hFile1, tmp, strlen(tmp), &d, 0);
#endif

			counter++;
		}
	}
	s[counter].level = s[counter].number = (short)-1;
	
	if (hFile)
		CloseHandle(hFile);
	if (b)
		GlobalFree(lp);
#ifdef _DEBUG
	if (hFile1)
		CloseHandle(hFile1);
#endif

	return counter;
}

bool MakeList(LIST *s = 0, HWND hDlg = 0)
{
	if (hDlg)
		SetWindowText(GetDlgItem(hDlg, IDC_NAME), "Generating page");

	LIST s2[200];
	memset(s2, -1, sizeof(s2));
	LIST *s1;
	if (s)
		s1 = s;
	else
	{
		s1 = s2;
	}
	if ((s[0].number) == -1)
		ReadLevels(s);

	int i = 0, i1 = 0;

/**************************************************************************/

	char tmp[MAX_PATH];
	DWORD d, dwBytesRead;
	LPSTR lp;

	strcpy(tmp, (*szPath)?szPath:szDirOutName);
	strcat(tmp, "\\");
	strcat(tmp, "content.htm");
	
	HANDLE hFile = CreateFile((LPCTSTR)tmp,
								GENERIC_READ,
								FILE_SHARE_READ,
								NULL,
								OPEN_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);

	if ((!hFile) && (hFile == (void*)0xffffffff))
		return 0;
	
	d = GetFileSize(hFile, 0l);
	lp = (LPSTR)GlobalAlloc(GMEM_FIXED, d+1);
	memset(lp, 0, GlobalSize(lp));

	ReadFile(hFile, lp, d, &dwBytesRead, (LPOVERLAPPED) NULL);
	CloseHandle(hFile);
	LPSTR lp1 = lp, lp2 = lp;

//	ConvertLinks(lp);

/**************************************************************************/
	while ((s[i].number) != -1)
	{
		if (s[i].level < s[i+1].level && s[i+1].number != -1)
		{
			lp1 = lp;
			memset(szResult, 0, sizeof(szResult));
//			strcpy(tmp, (*szPath)?szPath:szDirOutName);
//			strcat(tmp, "\\");
			//strcat(tmp, "content.htm");
			sprintf(tmp, "%s\\%i.htm", (*szPath)?szPath:szDirOutName, s[i].number);
			
			hFile = CreateFile((LPCTSTR)tmp,
										GENERIC_WRITE,
										FILE_SHARE_WRITE,
										NULL,
										CREATE_ALWAYS,
										FILE_ATTRIBUTE_NORMAL,
										(HANDLE)NULL);


			if ((!hFile) && (hFile == (void*)0xffffffff))
				continue;
			
			sprintf(tmp, "name=\"bk%i", s[i].number);
			i1 = FindSubstring(lp, tmp);
			if (i1 == -1)
				continue;

			lp1 += i1;
			while (*(++lp1) != '>');
			lp1++;
			strnset(tmp, 0, sizeof(tmp));

			while (*lp1 != '<')
			{
				strncat(tmp, lp1, 1);
				lp1++;
			}

			while (*(++lp1) != '\n');
			lp1++;

			sprintf(szResult, BEGIN, tmp, szDate);//stTime.wDay, stTime.wMonth, stTime.wYear);

			sprintf(szResult+strlen(szResult), "<h%i>%s</h%i><br>\r\n",
						s[i].level + 1,
						tmp,
						s[i].level + 1);
			i1 = i+1;
			while (s[i1].number != -1)
			{
				if (s[i1].level == s[i].level)
					break;
				i1++;
			}

			sprintf(tmp, "name=\"bk%i", s[i1].number);

			i1 = FindSubstring(lp1, tmp);
			lp2 = lp1+i1;

			while (strncmp(--lp2, "</ul>", 5))//(*(--lp2) != '>') && ((*(lp2-1) != 'l')))
				i1--;
			i1--;

			strncat(szResult, lp1, i1);

			strcat(szResult, "</ul>");

			strcat(szResult, END);

			WriteFile(hFile, szResult, strlen(szResult), &d, 0);

			CloseHandle(hFile);
		}
		i++;
	}

	GlobalFree(lp);

	return 1;
}

long WINAPI DoConvert(long lParam)
{
	HWND hWnd = (HWND)lParam;
	
	LIST s[200] = {-1};
	memset(s, -1, sizeof(s));
	MakeList(s, hWnd);
	int t = 0;
	
	memset(&s, (short)-1, sizeof(s));

	char tmp[MAX_PATH];
	DWORD d, dwBytesRead;

	strcpy(tmp, szPath);
	strcat(tmp, "\\");
	strcat(tmp, "FAQ.html");

	HANDLE hFile1 = CreateFile((LPCTSTR)tmp,
								GENERIC_WRITE,
								FILE_SHARE_WRITE,
								NULL,
								CREATE_ALWAYS,
								FILE_ATTRIBUTE_NORMAL/* | FILE_FLAG_SEQUENTIAL_SCAN*/,
								(HANDLE)NULL);

	if ((!hFile1) && (hFile1 == (void*)0xffffffff))					
		return 0;

	WriteFile(hFile1, HTML_BEGIN_1, strlen(HTML_BEGIN_1), &d, 0);
/*
	strcpy(tmp, szPath);
	strcat(tmp, "\\");
	strcat(tmp, "style.css");
	
	HANDLE hFile = CreateFile((LPCTSTR)tmp,
								GENERIC_READ,
								FILE_SHARE_READ,
								NULL,
								OPEN_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);

	if ((!hFile) && (hFile == (void*)0xffffffff))					
		return 0;	

	d = GetFileSize(hFile, 0l);
	LPSTR lpAllFile = (LPSTR)GlobalAlloc(GMEM_FIXED, d+1);
	memset(lpAllFile, 0, GlobalSize(lpAllFile));

	bool b = ((!ReadFile(hFile, lpAllFile, d, &dwBytesRead, (LPOVERLAPPED) NULL)) && d != dwBytesRead)?0:1;

	if (b)
		WriteFile(hFile1, lpAllFile, strlen(lpAllFile), &d, 0);


	CloseHandle(hFile);
	GlobalFree(lpAllFile);*/
	
	LPSTR lpAllFile;
	bool b;

	WriteFile(hFile1, STYLE, strlen(STYLE), &d, 0);
	WriteFile(hFile1, HTML_BEGIN_2, strlen(HTML_BEGIN_2), &d, 0);

	strcpy(tmp, szPath);
	strcat(tmp, "\\");
	strcat(tmp, "content.htm");
	
	HANDLE hFile = CreateFile((LPCTSTR)tmp,
								GENERIC_READ,
								FILE_SHARE_READ,
								NULL,
								OPEN_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);

	if ((!hFile) && (hFile == (void*)0xffffffff))					
		return 0;
	
	d = GetFileSize(hFile, 0l);
	lpAllFile = (LPSTR)GlobalAlloc(GMEM_FIXED, d+1);
	memset(lpAllFile, 0, GlobalSize(lpAllFile));

	b = ((!ReadFile(hFile, lpAllFile, d, &dwBytesRead, (LPOVERLAPPED) NULL)) && d != dwBytesRead)?0:1;

	LPSTR lp = lpAllFile;
	LPSTR lp1 = lp;

	int i = 0;

	SendMessage(GetDlgItem(hWnd, IDC_PROGRESS), PBM_SETRANGE32, 0,
				ReadLevels(s, lp)+1);

	lp = lpAllFile;

	ConvertLinks(lp);

	lp = FindBegin(lpAllFile, i);
	
	WriteFile(hFile1, lp, FindSubstring(lpAllFile, "</body>") - i - 1, &d, 0);

	GlobalFree(lpAllFile);
	CloseHandle(hFile);

/**************************************************************************/
	
	int i1 = 0;
	while (s[i1].number != -1)
	{
		sprintf(tmp, "%i.htm", s[i1].number);
		SetWindowText(GetDlgItem(hWnd, IDC_NAME), tmp);
		sprintf(tmp, "%s\\%i.htm", szPath, s[i1].number);

		HANDLE hFile = CreateFile((LPCTSTR)tmp,
								GENERIC_READ,
								FILE_SHARE_READ,
								NULL,
								OPEN_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);

		if ((!hFile) && (hFile == (void*)0xffffffff))					
			continue;

		d = GetFileSize(hFile, 0l);
		LPSTR lpAllFile = (LPSTR)GlobalAlloc(GMEM_FIXED, d+1);
		memset(lpAllFile, 0, GlobalSize(lpAllFile));

		b = ((!ReadFile(hFile, lpAllFile, d, &dwBytesRead, (LPOVERLAPPED) NULL)) && d != dwBytesRead)?0:1;
		
		if (b && lpAllFile)// && (s[i1].level && s[i1].level >= s[i1+1].level))
		{
			sprintf(tmp, HTML_BIND_B, s[i1].number, s[i1].number);
			WriteFile(hFile1, tmp, strlen(tmp), &d, 0);

			lp = FindBegin(lpAllFile, i);

			b = 0;
			t = FindSubstring(lpAllFile, "</h1>");
			if (t == -1 && (s[i1].level < s[i1+1].level && s[i1+1].level != -1))
				t = FindSubstring(lpAllFile, "</h2>");

			if (t != -1)
			{
				t+=5;
				b = 1;
			}
			else
				t = FindSubstring(lpAllFile, "<a href=\"content.htm\">");

			if (t == -1)
				t = FindSubstring(lpAllFile, "</body>");

//			ConvertLinks(lp);

			if (s[i1].level < s[i1+1].level && s[i1+1].level != -1)
				WriteFile(hFile1, "<center>", 8, &d, 0);

			WriteFile(hFile1, lp, t - i - 1, &d, 0);

			if (s[i1].level < s[i1+1].level && s[i1+1].level != -1)
				WriteFile(hFile1, "</center>", 9, &d, 0);

			if (!b && s[i1].level)
			{
				sprintf(tmp, HTML_BIND_E, s[i1].number);
				WriteFile(hFile1, tmp, strlen(tmp), &d, 0);
			}
		}

		if (lpAllFile)
			GlobalFree(lpAllFile);

		CloseHandle(hFile);
		i1++;
		SendMessage(GetDlgItem(hWnd, IDC_PROGRESS), PBM_SETPOS, i1+1, 0);
	}

	SetWindowText(GetDlgItem(hWnd, IDC_NAME), "completed");

/**************************************************************************/	
	WriteFile(hFile1, HTML_END, strlen(HTML_END), &d, 0);

	CloseHandle(hFile1);

#ifndef _DEBUG
//	Sleep(1000);
#endif
	MessageBeep(-1);
	EndDialog(hWnd, 1);
	ExitThread(0);

	return 1;
}

BOOL WINAPI HTMLProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	switch (uMessage)
	{
		case WM_INITDIALOG:
		{
			ShowWindow(hWnd, SW_SHOW);
			RECT r;
			RECT r1;
			GetWindowRect(GetParent(hWnd), &r);
			GetWindowRect(hWnd, &r1);

			MoveWindow(hWnd,
							((r.right - r.left) - (r1.right - r1.left))/2,
							((r.bottom - r.top) - (r1.bottom - r1.top))/2,
							r1.right - r1.left,
							r1.bottom - r1.top,
							1);

			strcpy(szPath, szDirOutName/*DEF_PATH_HTML*/);
			strcpy(szPath1, szDirOutName/*DEF_PATH_HTML*/);
			SetWindowText(GetDlgItem(hWnd, IDC_PATH_1), szPath);
			SetWindowText(GetDlgItem(hWnd, IDC_PATH_2), szPath1);

//			if (bFull)
			{
				DWORD id;
				//DoConvert(hWnd);//SendMessage(hWnd, WM_COMMAND, MAKELONG(IDC_BEGIN, IDC_BEGIN), 0);
				HANDLE h = CreateThread(
								NULL,
								0,
								(LPTHREAD_START_ROUTINE)DoConvert,
								(LPVOID)hWnd,
								0,
								&id);

//				EndDialog(hWnd, 1);
			}
//			break;
		}
/*
		case WM_COMMAND:
		{
			switch(GET_WM_COMMAND_ID(wParam, lParam))
			{
				case IDOK:
					EndDialog(hWnd, 1);
					break;

				case IDC_BEGIN:
					DoConvert(hWnd);
					break;

				case IDC_BROWSE:
				case IDC_BROWSE2:
				{
					short number = (GET_WM_COMMAND_ID(wParam, lParam) == IDC_BROWSE)?1:2;
					LPSTR lp = (number == 1)?szPath:szPath1;
					UINT ui = (number == 1)?IDC_PATH_1:IDC_PATH_2;

					if (number == 1 && !*szDirName)
						strcpy(szDirName, DEF_PATH_SOURCE);
					else if (number == 2 && !*szDirOutName)
						strcpy(szDirOutName, DEF_PATH_HTML);

					BROWSEINFO bi = {
										hWnd, // ��������
										NULL, // �� �����, �.�. �� ����
										(LPSTR)lp, // ��������� ����������
										"Please, choose the folder...", // ���������
										BIF_DONTGOBELOWDOMAIN | BIF_RETURNONLYFSDIRS |
										BIF_EDITBOX | BIF_BROWSEFORCOMPUTER , // �����
										BrowseCallbackProc, // �-��� ��������� ������
										(LPARAM)lp, // �� ����� ��� ������
										0}; // ��� �� ��� ���


					LPCITEMIDLIST lpItemDList;
					
					if((lpItemDList = SHBrowseForFolder(&bi)))
					{
						SHGetPathFromIDList(lpItemDList, lp); 
						SetWindowText(GetDlgItem(hWnd, ui), lp);
					}


					break;
				}

				default:
					break;
			}
		}*/

		default:
			break;
	}

	return 0;
}