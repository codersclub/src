
#if !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
#define AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers


	#include <windows.h>
	#include <windowsx.h>
	#include <stdio.h>
	#include <commctrl.h>
	#include <math.h>
	#include <shlobj.h>
	#include <shellapi.h>
	#include <commdlg.h>

	#include "globals.h"
	#include "format.h"
	#include "html.h"
	#include "resource.h"
	#include "style.h"
	#include "const.h"

#endif // !defined(AFX_STDAFX_H__A9DB83DB_A9FD_11D0_BFD1_444553540000__INCLUDED_)
