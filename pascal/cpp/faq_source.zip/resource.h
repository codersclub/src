//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by resource.rc
//
#define IDC_PREVIEW                     2
#define IDD_FAQ                         101
#define IDD_RESULT                      102
#define IDI_MAINICON                    104
#define IDD_PROGRESS                    105
#define IDD_MAKE_HTML                   106
#define IDC_SOURCE                      1000
#define IDC_AUTHOR                      1001
#define IDC_WHENCE                      1002
#define IDC_GENERATE                    1003
#define IDC_LINK                        1004
#define IDC_RESULT                      1005
#define IDC_FULL                        1005
#define IDC_MAKE_HTML                   1006
#define IDC_PATH                        1007
#define IDC_NAME                        1008
#define IDC_COPY                        1009
#define IDC_PATH2                       1010
#define IDC_CLEAR                       1011
#define IDC_SPACE                       1012
#define IDC_PROGRESS                    1013
#define IDC_DATE                        1013
#define IDC_BROWSE                      1014
#define IDC_SAVE                        1015
#define IDC_BROWSE3                     1016
#define IDC_BROWSE2                     1017
#define IDC_SCAN                        1018
#define IDC_FILE                        1019
#define IDC_PER_CENT                    1020
#define IDC_PATH_1                      1021
#define IDC_PATH_2                      1022
#define IDC_BEGIN                       1023

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        110
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
