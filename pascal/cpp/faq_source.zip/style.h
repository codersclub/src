
#define STYLE "\
h6 { font-style : italic; font-weight : normal; font-size : 10pt; color : green; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 1%;}\r\n\
h5 { font-family : courier; font-style : normal; font-weight : normal; font-size : 10pt; color : #800080; background-color : #fafafa; padding-top : 10pt; padding-left : 10pt; padding-right : 0; padding-bottom : 10pt; border-top : 1pt solid silver; border-bottom : 1pt solid silver; border-left : 1pt solid silver; border-right : 1pt solid silver; text-align : left; }\r\n\
h4 { font-style : normal; font-weight : normal; font-size : 10pt; color : #303030; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 2%;}\r\n\
h3 { font-weight : bold; font-size : 10pt; color : #000000;}\r\n\
h2 { font-weight : bold; font-size : 12pt; color : #000000;}\r\n\
h1 { font-weight : bold; font-size : 16pt; color : #000000; text-decoration : underline; text-transform : uppercase; text-align : center; padding-top : 5%; padding-bottom : 5%;}\r\n\
\
body { font-style : normal; font-family : tahoma; font-weight : normal; font-size : 10pt; color : #000000; text-align : justify; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 1%;  line-height: 125%;}\r\n\
\
A:link { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
A:visited { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
A:active { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
A:hover { font-family : arial; font-weight : normal; color : #ff0000; text-decoration : underline;}\r\n\
"
/*
struct FONT
{
	char size[3];//byte size;
	COLORREF color;
	char face[20];
	bool bold;
	bool italic;
	bool underline;
	BYTE align;
};

const FONT Header[] =
{
	{"+2", RGB(0,   0,  0),	"tahoma",	1, 0, 1, 2},	// header 1
	{"+1", RGB(0,   0,  0),	"tahoma",	1, 0, 0, 1},	// header 2
	{"0", RGB(0,   0,  0),	"tahoma",	1, 0, 0, 1},	// header 3
	{"0", RGB(30, 30, 30),	"tahoma",	0, 0, 0, 1},	// header 4
	{"0", RGB(80,  0, 80),	"courier",	0, 0, 0, 1},	// header 5
	{"0", RGB(0,   0, 80),	"tahoma",	0, 1, 0, 1},	// header 6
};

void Font(LPSTR lp, FONT f, bool bEnter);

void Font(LPSTR lp, bool bEnter, int size, COLORREF color, char *face,
			bool bold, bool italic, bool underline, BYTE align);*/
