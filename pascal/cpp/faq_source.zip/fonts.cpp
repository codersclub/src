#include <windows.h>
#include <stdio.h>

#include "style.h"
/*
struct MySize
{
	BYTE header;
	BYTE size;
};

const MySize iSize[] =
{
	{1, 16},
	{2, 12},
	{3, 10},
	{4, 10},
	{5, 10},
	{6, 10},
};*/
/*
#define		left = 1,
#define		center = 2,
#define		right = 3,
#define		justify = 4,
*/
void MakeColor(LPSTR lp, COLORREF color)
{
	BYTE b = 0;
	for (int i = 2; i >= 0; i--) // ��������� �� ����� � ������
	{
		b = (BYTE)(color >> (i*8));
		if (b >= 0x10)
			sprintf(lp+strlen(lp), "%2x", b);
		else 
			sprintf(lp+strlen(lp), "0%1x", b);
	}
}

void Font(LPSTR lp, FONT f, bool bEnter)
{
	char sz[200];

	if (bEnter)
	{
		sprintf(sz, "<font size=\"%s\" color=#", f.size);
		MakeColor(sz, f.color);
		sprintf(sz+strlen(sz), " face=\"%s\">", f.face);
		if (f.bold)
			strcat(sz, "<b>");
		if (f.italic)
			strcat(sz, "<i>");
		if (f.underline)
			strcat(sz, "<u>");
		
		switch (f.align)
		{
			case 2: // center
				strcat(sz, "<center>");
				break;

			default:
				break;
		}
	}
	else
	{
		strcpy(sz, "</font>");
		if (f.bold)
			strcat(sz, "</b>");
		if (f.italic)
			strcat(sz, "</i>");
		if (f.underline)
			strcat(sz, "</u>");
		switch (f.align)
		{
			case 2: // center
				strcat(sz, "</center>");
				break;

			default:
				break;
		};
	}
	strcat(lp, sz);

	if (!bEnter)
	strcat(lp, "<br>\r\n");
}

void Font(LPSTR lp, bool bEnter, char *size, COLORREF color, char *face,
			bool bold, bool italic, bool underline, BYTE align)
{
	FONT f = {0};

	strcpy(f.size, size);
	f.color = color;
	strcpy(f.face, face);
	f.bold = bold;
	f.italic = italic;
	f.underline = underline;
	f.align = align;

	Font(lp, f, bEnter);
}