
	#include "stdafx.h"

#define		szAppName	"FAQ"


static	BOOL		bMoveWindow = 0;
static	POINT		pMouse = {0};

//		SYSTEMTIME	stTime;
		char szDate[100];
		HINSTANCE	hInst;

bool Open(HWND hWnd, LPSTR lpszFile, bool bSetText = 0);


char szFileName[MAX_PATH] = {0};
char szDirName[MAX_PATH] = {0};
char szDirOutName[MAX_PATH] = {0};
char szOptions[MAX_PATH] = {0};

bool bFull = 0;

BOOL WINAPI WndProc (HWND, UINT, WPARAM, LPARAM);

int WINAPI WinMain (HINSTANCE	hInstance, 
						HINSTANCE	hPrevInstance, 
						LPSTR		lpszCmdParam, 
						int			nCmdShow)
{
	hInst = hInstance;
	HWND			hWnd;
	char			szClassName[] = szAppName;

	char szName[MAX_PATH];
	memset(szName, 0, sizeof(szName));

	memset(szOptions, 0, sizeof(szOptions));	
	GetModuleFileName((HMODULE)hInstance, szOptions, sizeof(szOptions));
	LPSTR lp = szOptions + strlen(szOptions)-1;
	while (*lp != '\\')
		lp--;
	lp++;
	*lp = 0;
	
	strcat(szOptions, "options.ini");

	if (*lpszCmdParam)
		strcpy(szName, lpszCmdParam);

	hWnd = FindWindow(NULL, szAppName);

	if (hWnd)
	{
		ShowWindow(hWnd, SW_MINIMIZE);
		ShowWindow(hWnd, SW_SHOW);
		ShowWindow(hWnd, SW_RESTORE);
		SetForegroundWindow(hWnd);
		SetFocus(hWnd);
		return 0;
	}

	hInst = hInstance;

	hWnd = CreateDialog(hInst, MAKEINTRESOURCE(IDD_FAQ), 0l, WndProc);
	if (*szName)
	{
//		char sz[300];
//		sprintf(sz, "\"%s\"", szName);
//		MessageBox(0,sz,0,0);
		Open(hWnd, szName, 1);
		SendMessage(hWnd, WM_COMMAND, MAKELONG(IDC_GENERATE, IDC_GENERATE), (LPARAM)-1);
	}

	if (!hWnd)
	{		
		MessageBox(NULL, "Can't create main window", szAppName, MB_APPLMODAL | MB_ICONSTOP);
		return false;
	}

	ShowWindow(hWnd, SW_SHOW);
	
	MSG	Msg;
	while (GetMessage(&Msg, NULL, 0, 0))
	{
		TranslateMessage(&Msg);
		DispatchMessage(&Msg);
	}
	return Msg.wParam;	
}

unsigned int GetStringLength(LPSTR lp)
{
	int i = 0;

	while (*lp != '\r' && *lp != '\n')
		i++, lp++;

	return i;
}

struct SETTINGS
{
	char sz[20];
	UINT id;
	LPSTR lp;
};

SETTINGS MySet[] =
{
	{"NAME", IDC_NAME, szName},
	{"AUTHOR", IDC_AUTHOR, szAuthor},
	{"WHENCE", IDC_WHENCE, szWhence},
	{"LINK", IDC_LINK, szLink},
};

int CALLBACK BrowseCallbackProc(HWND hWnd, UINT uMessage, LPARAM wParam, LPARAM lParam)
{
	TCHAR szDir[MAX_PATH];
	
	switch(uMessage)
	{
		case BFFM_INITIALIZED:
		{
			LONG l = GetWindowLong(hWnd, GWL_STYLE);
			l -= DS_CONTEXTHELP;
			SetWindowLong(hWnd, GWL_STYLE, (LONG)l);

			l = GetWindowLong(hWnd, GWL_EXSTYLE);
			l -= WS_EX_CONTEXTHELP;
			SetWindowLong(hWnd, GWL_EXSTYLE, (LONG)l);

			SetWindowText(hWnd, "Choose the folder...");

			if (*szDirName)
				DWORD d = SendMessage(hWnd, BFFM_SETSELECTION, 1, lParam);

			break;
		}

		case BFFM_SELCHANGED:
		{
			LPITEMIDLIST lp1 = (LPITEMIDLIST)lParam;
			if (SHGetPathFromIDList((LPITEMIDLIST)wParam ,szDir))
			{
				HWND hwndTmp;
				hwndTmp = FindWindowEx(hWnd, NULL, "Edit", NULL);
				SetWindowText(hwndTmp, szDir);
			}
			break;
		}
		default:
			break;
	}
	return 0;
}

bool Open(HWND hWnd, LPSTR lpszFile, bool bSetText)
{
	memset(szName, 0, MAX_NAME);
	memset(szLink, 0, MAX_LINK);
	memset(szAuthor, 0, MAX_AUTHOR);
	memset(szSource, 0, MAX_SOURCE);
	memset(szWhence, 0, MAX_WHENCE);
	memset(szResult, 0, MAX_RESULT);

	HANDLE hFile = CreateFile((LPCTSTR)lpszFile,
								GENERIC_READ,
								FILE_SHARE_READ,
								NULL,
								OPEN_ALWAYS,
								FILE_ATTRIBUTE_NORMAL,
								(HANDLE)NULL);

	if ((!hFile) && (hFile == (void*)0xffffffff))					
		return 0;

	memset(szFileName, 0, sizeof(szFileName));
	strcpy(szFileName, lpszFile);

	short iTmp = 0;
	LPSTR lpTmp;
	char szName[50], tmp[200];

	for (lpTmp = lpszFile + strlen(lpszFile)-1; lpTmp > lpszFile; lpTmp--)
	{
		if (*lpTmp == '\\')
			break;
	}
	strcpy(szName, lpTmp+1);

	for (lpTmp = lpszFile + strlen(lpszFile)-1; lpTmp > lpszFile; lpTmp--)
	{
		if (*lpTmp == '.')
		{
			if (!strnicmp(lpTmp+1, "h", 1) && *(lpTmp+2) == '\0')
				iTmp = 1;
			else if (!strnicmp(lpTmp+1, "hpp", 3) && *(lpTmp+4) == '\0')
				iTmp = 1;
			else if (!strnicmp(lpTmp+1, "c", 1) && *(lpTmp+2) == '\0')
				iTmp = 1;
			else if (!strnicmp(lpTmp+1, "cpp", 3) && *(lpTmp+4) == '\0')
				iTmp = 1;
			else if (!strnicmp(lpTmp+1, "txt", 3) && *(lpTmp+4) == '\0')
				iTmp = 2;

			break;
		}
	}

	if (!iTmp)
	{
		CloseHandle(hFile);
		return 0;
	}
	
	if (bSetText)
		SetWindowText(GetDlgItem(hWnd, IDC_NAME), szName);

	memset(szFileNameBuf, 0, sizeof(szFileName));
	strncpy(szFileNameBuf, lpszFile, strlen(lpszFile) - strlen(lpTmp));
	strcat(szFileNameBuf, ".htm");

	bool b = 0;

	DWORD d, dwBytesRead;
	d = GetFileSize(hFile, 0l);
	LPSTR lpAllFile = (LPSTR)GlobalAlloc(GMEM_FIXED, d+10);
	LPSTR lp = lpAllFile;
	
	if (lp)
	{
		memset(lp, 0, GlobalSize((HGLOBAL)lp));

		if (iTmp == 1)
			strcpy(lp, "[h5]");

		b = ((!ReadFile(hFile, lp+strlen(lp), d, &dwBytesRead, (LPOVERLAPPED) NULL)) && d != dwBytesRead)?0:1;
		
		if (b)
		{
			if (iTmp == 1)
			{
				strcat(lp, "[/h5]\0");
			}
			else if (iTmp == 2)
			{
				int t;
				if (bSetText)
				{
					for (t = 0; t < sizeof(MySet) / sizeof(MySet[0]); t++)
					{					
						SetWindowText(GetDlgItem(hWnd, MySet[t].id), (MySet[t].id == IDC_AUTHOR)?"SUnteXx":"");
					}
				}

				for (int i = 0; i < 5; i++)
				{
					for (t = 0; t < sizeof(MySet) / sizeof(MySet[0]); t++)
					{
						if (!_strnicmp(lp, MySet[t].sz, strlen(MySet[t].sz)))
						{
							memset(tmp, 0, sizeof(tmp));
							strncpy(tmp, lp+strlen(MySet[t].sz)+2, GetStringLength(lp+strlen(MySet[t].sz)+2));
							strcpy(MySet[t].lp, tmp);

							if (bSetText)
								SetWindowText(GetDlgItem(hWnd, MySet[t].id), MySet[t].lp);

							lp += strlen(MySet[t].sz) + 2 + strlen(tmp);
							lp += 2;
						}
					}
				}
			}
			while (*(lp) == '\r' || *(lp) == '\n')
				lp ++;

			strcpy(szSource, lp);
			*(char*)(szSource+strlen(lp)) = 0;
			if (bSetText)
				SetWindowText(GetDlgItem(hWnd, IDC_SOURCE), szSource);

			b = 1;
		}

		GlobalFree(lpAllFile);
	}

	if (hFile)
		CloseHandle(hFile);

	return b;
}

HWND hwndDialog = 0;

long WINAPI Scan(long lParam)
{
	HWND hWnd = (HWND)lParam;
	HANDLE hSearch;
	WIN32_FIND_DATA wfd;
	char tmp[MAX_PATH];
	char dir[MAX_PATH];

	while (!hwndDialog);
	
	strcpy(dir, szDirName);

	if (*(char*)(szDirName + strlen(szDirName) - 1 ) == '\\')
		strcat(dir, "*.txt");
	else
		strcat(dir, "\\*.txt");

//	LIST s[200];
//	ReadLevels(s, 0);

/**************************************************************************/
	int imax=0;
	int isize=0;

	if ((hSearch = FindFirstFile(dir, &wfd)) == INVALID_HANDLE_VALUE)
		return 0;

	do
	{
		imax++;
		isize += wfd.nFileSizeLow;
	}
	while (FindNextFile(hSearch, &wfd));

	FindClose(hSearch);

/**************************************************************************/

	SendMessage(GetDlgItem(hwndDialog, IDC_PROGRESS), PBM_SETRANGE, 0, MAKELPARAM(0,100));
	SendMessage(GetDlgItem(hwndDialog, IDC_PROGRESS), PBM_SETSTEP, 1, 0);

	int i=0;
	int i1=0;
		
	if ((hSearch = FindFirstFile(dir, &wfd)) == INVALID_HANDLE_VALUE)
		return 0;

	do
	{
		SetWindowText(GetDlgItem(hwndDialog, IDC_FILE), wfd.cFileName);
		strcpy(tmp, szDirName);

		if (*(char*)(szDirName + strlen(szDirName) - 1 ) != '\\')
			strcat(tmp, "\\");


		strcat(tmp, wfd.cFileName);
		Open(hWnd, tmp);
		memset(szResult, 0, sizeof(szResult));
		GenerateSource(hWnd);
		strcpy(tmp, szDirOutName);

		if (*(char*)(szDirOutName + strlen(szDirOutName) - 1 ) != '\\')
			strcat(tmp, "\\");
		
		LPSTR lp = wfd.cFileName + strlen(wfd.cFileName);
		while (*--lp != '.');
		strncat(tmp, wfd.cFileName, strlen(wfd.cFileName) - strlen(lp));
		strcat(tmp, ".htm");

		SaveAsHTML(tmp);
		i++;
		i1 += wfd.nFileSizeLow;
//		sprintf(tmp, "%i %%\0", (i*100)/imax);
		sprintf(tmp, "%i\\%i (%i %%)\0", i, imax, (i1*100)/isize);
		SetWindowText(GetDlgItem(hwndDialog, IDC_PER_CENT), tmp);
		SendMessage(GetDlgItem(hwndDialog, IDC_PROGRESS), PBM_SETPOS, (i1*100)/isize, 0);
	}
	while (FindNextFile(hSearch, &wfd));

	FindClose (hSearch);

	SetWindowText(GetDlgItem(hwndDialog, IDC_FILE), "completed");
//	SetWindowText(GetDlgItem(hwndDialog, IDC_PER_CENT), "");
#ifndef _DEBUG
//	Sleep(1000);
#endif
	
	MessageBeep(-1);
	EndDialog(hwndDialog, 0);
	hwndDialog = 0;

	ExitThread(0);
	return 1;	
}
/*
BOOL WINAPI DateFunc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	switch (uMessage)
	{
		case WM_INITDIALOG:
		{
			break;
		}

		case WM_COMMAND:
		{
			switch (LOWORD(wParam))
			{
				case IDOK:
				{
					EndDialog(hWnd, IDOK);
					SendMessage(GetDlgItem(hWnd, IDC_MONTHCALENDAR), MCM_GETCURSEL, 0, (LPARAM)&stTime);
					break;
				}
				
				case IDCANCEL:
				{
					EndDialog(hWnd, IDCANCEL);
					break;
				}

				default:
					break;
			}
		}


		default:
			break;
	}

	return 0;
}

*/
BOOL WINAPI DlgProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	if (uMessage == WM_INITDIALOG)
	{
		RECT r;
		RECT r1;
		GetWindowRect(GetParent(hWnd), &r);
		GetWindowRect(hWnd, &r1);

		MoveWindow(hWnd,
						((r.right - r.left) - (r1.right - r1.left))/2,
						((r.bottom - r.top) - (r1.bottom - r1.top))/2,
						r1.right - r1.left,
						r1.bottom - r1.top,
						1);
	}

	if (!hwndDialog)
		hwndDialog = hWnd;

	return 0;
}


BOOL WINAPI WndProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	switch(uMessage)
	{
		case WM_INITDIALOG:
		{
			char sz[MAX_PATH*2];
			memset(sz,0,sizeof(sz));
			HANDLE hfile = CreateFile(szOptions,
									GENERIC_READ,
									FILE_SHARE_READ,
									NULL,
									OPEN_EXISTING,
									FILE_ATTRIBUTE_NORMAL,
									(HANDLE)NULL);

			if (!hfile || hfile == (HANDLE)(UINT)-1)
			{
				if (!*szDirName)
					strcpy(szDirName, DEF_PATH_SOURCE);

				if (!*szDirOutName)
					strcpy(szDirOutName, DEF_PATH_HTML);
			}
			else
			{
				DWORD d;
				LPSTR lp;
				ReadFile(hfile, sz, sizeof(sz),&d,0);
				lp = sz;
				while (*lp != '\r')
					lp++;
				if (*lp == '\r')
					lp+=2;
				else if (*lp == '\n')
					lp++;
				strncpy(szDirName,sz,(int)(lp-sz-2));
				//lp++;
				strcpy(szDirOutName,lp);
				CloseHandle(hfile);
			}

			ShowWindow(hWnd, SW_HIDE);
			SendMessage(GetDlgItem(hWnd, IDC_NAME), EM_LIMITTEXT, MAX_NAME, 0);
			SendMessage(GetDlgItem(hWnd, IDC_AUTHOR), EM_LIMITTEXT, MAX_AUTHOR, 0);
			SendMessage(GetDlgItem(hWnd, IDC_WHENCE), EM_LIMITTEXT, MAX_WHENCE, 0);
			SendMessage(GetDlgItem(hWnd, IDC_LINK), EM_LIMITTEXT, MAX_LINK, 0);
			SendMessage(GetDlgItem(hWnd, IDC_SOURCE), EM_LIMITTEXT, MAX_SOURCE, 0);

			SendMessage(GetDlgItem(hWnd, IDC_DATE), EM_LIMITTEXT, 10, 0);
			
			SYSTEMTIME st;
			GetSystemTime(&st);
			sprintf(szDate, "%2i.%2i.%4i", st.wDay, st.wMonth, st.wYear);
			SetWindowText(GetDlgItem(hWnd, IDC_DATE), szDate);

			SetWindowText(GetDlgItem(hWnd, IDC_AUTHOR), "SUnteXx");


			SetWindowText(GetDlgItem(hWnd, IDC_PATH), szDirName);

			if (!*szDirOutName)
				strcpy(szDirOutName, DEF_PATH_HTML);

			SetWindowText(GetDlgItem(hWnd, IDC_PATH2), szDirOutName);

			HWND hwnd = CreateUpDownControl(WS_CHILD | WS_BORDER | WS_VISIBLE |
											UDS_SETBUDDYINT | UDS_ALIGNRIGHT,
											0, 12, 50, 50,
											hWnd, IDC_SPINSPACE,
											hInst,
											GetDlgItem(hWnd, IDC_SPACE),
											9, 2, 4);


			SendMessage(hwnd, UDM_SETPOS, 0, MAKELONG(4,0));
			SendMessage(hwnd, UDM_SETRANGE, 0, MAKELONG(9,2));

			ShowWindow(hWnd, SW_SHOW);
			break;
		}

		case WM_COMMAND:
		{
			switch(GET_WM_COMMAND_ID(wParam, lParam))
			{
				case IDOK:
				{
					SendMessage(hWnd, WM_CLOSE, 0, 0);
					break;
				}

				case IDC_GENERATE:
				{
					if (!bFull)
					{
						GetDlgItemText(hWnd, IDC_DATE, szDate, sizeof(szDate));
					}

					if (GetWindowTextLength(GetDlgItem(hWnd, IDC_SOURCE)) != 0)
						DialogBoxParamA(hInst, MAKEINTRESOURCE(IDD_RESULT), hWnd, ResultProc, (lParam == -1)?-1:0/*ResultProc*/);
					break;
				}

				case IDC_MAKE_HTML:
				{
					if (!bFull)
					{
/*						DWORD d = DialogBox(hInst, MAKEINTRESOURCE(IDD_DATE), hWnd, DateFunc);

						if (d == IDCANCEL)
							break;*/

						GetDlgItemText(hWnd, IDC_DATE, szDate, sizeof(szDate));
					}

					DialogBox(hInst, MAKEINTRESOURCE(IDD_MAKE_HTML), hWnd, HTMLProc);
					break;
				}

				case IDC_CLEAR:
				{
					SetWindowText(GetDlgItem(hWnd, IDC_SOURCE), "");
					SetWindowText(GetDlgItem(hWnd, IDC_LINK), "");
					SetWindowText(GetDlgItem(hWnd, IDC_WHENCE), "");
					SetWindowText(GetDlgItem(hWnd, IDC_NAME), "");
					SetWindowText(GetDlgItem(hWnd, IDC_AUTHOR), "SUnteXx");
					break;
				}

				case IDC_SCAN:
				{
					if (!bFull)
					{
						GetDlgItemText(hWnd, IDC_DATE, szDate, sizeof(szDate));
					}

					HANDLE	thread = 0;
					DWORD	id = 0;

					thread = CreateThread(
											NULL,
											0,
											(LPTHREAD_START_ROUTINE)Scan,
											(LPVOID)hWnd,
											0,
											&id);

					DialogBox(hInst, MAKEINTRESOURCE(IDD_PROGRESS), hWnd, DlgProc);

					break;
				}

				case IDC_PATH:
					if (HIWORD(wParam) == EN_CHANGE)
						GetWindowText(GetDlgItem(hWnd, LOWORD(wParam)), szDirName, sizeof(szDirName));
					break;

				case IDC_PATH2:
					if (HIWORD(wParam) == EN_CHANGE)
						GetWindowText(GetDlgItem(hWnd, LOWORD(wParam)), szDirOutName, sizeof(szDirOutName));
					break;

				case IDC_BROWSE:
				case IDC_BROWSE2:
				{
					short number = (GET_WM_COMMAND_ID(wParam, lParam) == IDC_BROWSE)?1:2;
					LPSTR lp = (number == 1)?szDirName:szDirOutName;
					UINT ui = (number == 1)?IDC_PATH:IDC_PATH2;

					if (number == 1 && !*szDirName)
						strcpy(szDirName, DEF_PATH_SOURCE);
					else if (number == 2 && !*szDirOutName)
						strcpy(szDirOutName, DEF_PATH_HTML);

					BROWSEINFO bi = {
										hWnd, // ��������
										NULL, // �� �����, �.�. �� ����
										(LPSTR)lp, // ��������� ����������
										"Please, choose the folder...", // ���������
										BIF_DONTGOBELOWDOMAIN | BIF_RETURNONLYFSDIRS |
										BIF_EDITBOX | BIF_BROWSEFORCOMPUTER , // �����
										BrowseCallbackProc, // �-��� ��������� ������
										(LPARAM)lp/*number*/, // �� ����� ��� ������
										0}; // ��� �� ��� ���


					LPCITEMIDLIST lpItemDList;
					
					if((lpItemDList = SHBrowseForFolder(&bi)))
					{
						SHGetPathFromIDList(lpItemDList, lp); 
						SetWindowText(GetDlgItem(hWnd, ui), lp);
					}


					break;
				}

				case IDC_FULL:
				{
					GetDlgItemText(hWnd, IDC_DATE, szDate, sizeof(szDate));

					bFull = 1;
					char tmp[MAX_PATH];
					strcpy(tmp, szDirOutName);
					strcat(tmp, "\\");
					strcat(tmp, "style.css");
					
					HANDLE hFile = CreateFile((LPCTSTR)tmp,
												GENERIC_WRITE,
												FILE_SHARE_WRITE,
												NULL,
												CREATE_ALWAYS,
												FILE_ATTRIBUTE_NORMAL,
												(HANDLE)NULL);

					if ((!hFile) && (hFile == (void*)0xffffffff))					
					{
						//return 0;	
					}
					else
					{
						DWORD d;
						WriteFile(hFile, STYLE, strlen(STYLE), &d, 0);
						CloseHandle(hFile);
					}

					SendMessage(hWnd, WM_COMMAND, MAKELONG(IDC_SCAN, IDC_SCAN), 0);
					SendMessage(hWnd, WM_COMMAND, MAKELONG(IDC_MAKE_HTML, IDC_MAKE_HTML), 0);



					strcpy(tmp, szDirOutName);
					strcat(tmp, "\\");
					strcat(tmp, "content.htm");
					
					hFile = CreateFile((LPCTSTR)tmp,
												GENERIC_READ | GENERIC_WRITE,
												FILE_SHARE_WRITE | FILE_SHARE_READ,
												NULL,
												OPEN_EXISTING,
												FILE_ATTRIBUTE_NORMAL,
												(HANDLE)NULL);

					if ((!hFile) && (hFile == (void*)0xffffffff))					
					{
					}
					else
					{
						char tmp[2000];
						char tmp1[100];

						DWORD d, d1;
						d = GetFileSize(hFile, 0l);
						if (d > sizeof(tmp))
							d = sizeof(tmp);

						ReadFile(hFile, tmp, d, &d1, 0);

						LPSTR lp = tmp;

						while (strncmp(lp, "��������� ����������:", 21))
							lp++;
						
						lp+=21;
						while (*lp == ' ')
							lp++;

						//sprintf(tmp1, "%.2i.%.2i.%.4i", stTime.wDay, stTime.wMonth, stTime.wYear);

						SetFilePointer(hFile,0,0,FILE_BEGIN);
						SetFilePointer(hFile,(int)(lp-tmp),0,FILE_BEGIN);

						d = strlen(tmp1);
						WriteFile(hFile, szDate, d, &d1, 0);
						CloseHandle(hFile);
					}

					bFull = 0;
					break;
				}

				default:
					break;
			}
			break;
		}

		case WM_NCLBUTTONDOWN:
			if (wParam != HTCAPTION)
				break;
		case WM_LBUTTONDOWN:
			bMoveWindow = TRUE;
			SetCapture(hWnd);
			GetCursorPos(&pMouse);
    
			break;

		case WM_NCMOUSEMOVE:
			if (wParam != HTCAPTION)
				break;
		case WM_MOUSEMOVE:
		{
			if (bMoveWindow)
			{
				POINT	pTmp;
				RECT	R;
				GetCursorPos(&pTmp);
				GetWindowRect(hWnd, &R);
				MoveWindow (hWnd,
							R.left + pTmp.x - pMouse.x, 
							R.top + pTmp.y - pMouse.y, 
							R.right - R.left,
							R.bottom - R.top,
							true);
				pMouse = pTmp;
			}
			break;

		}

		case WM_NCLBUTTONUP:
			if (wParam != HTCAPTION)
				break;
		case WM_LBUTTONUP:
			ReleaseCapture();
			bMoveWindow = FALSE;
			break;

		case WM_DROPFILES:
		{
			int iFiles;
			char lpszFile [MAX_PATH];
			HDROP hDropInfo = (HDROP)wParam;

			iFiles = DragQueryFile (hDropInfo, (DWORD)(-1), (LPSTR)NULL, 0);

			if (iFiles != 1) 
				MessageBox(hWnd, "One file at a time, please.", "Warning", MB_OK | MB_ICONEXCLAMATION);
			else
			{
				DragQueryFile (hDropInfo, 0, lpszFile, sizeof (lpszFile));
				
				if (Open(hWnd, lpszFile, 1))
					SendMessage(hWnd, WM_COMMAND, MAKELONG(IDC_GENERATE, IDC_GENERATE), (LPARAM)-1);
			}

			break;//return 0;
		}
		
		case WM_CLOSE:
			HANDLE hfile; hfile = CreateFile(szOptions,
						GENERIC_WRITE,
						FILE_SHARE_WRITE,
						NULL,
						CREATE_ALWAYS,
						FILE_ATTRIBUTE_NORMAL,
						(HANDLE)NULL);
			char sz[500];
			DWORD d, d1;
			sprintf(sz, "%s\r\n%s", szDirName, szDirOutName);
			d1 = strlen(szDirName) + strlen(szDirOutName) + 2;
			WriteFile(hfile, sz, d1, &d, 0);
			CloseHandle(hfile);
			EndDialog(hWnd, 1);
			PostQuitMessage(0);
			//UnregisterClass(szAppName, hInst);
			break;


		default:
			break;//return 0;//DefWindowProc(hWnd, uMessage, wParam, lParam);
	}

	return 0;//DefWindowProc(hWnd, uMessage, wParam, lParam);
}