
	#include "stdafx.h"

char szFileNameBuf [MAX_PATH];

char szName		[MAX_NAME]		= {0}; // ��� ������
char szLink		[MAX_LINK]		= {0}; // ���� �� �������� ������
char szAuthor	[MAX_AUTHOR]	= {0}; // �����
char szWhence	[MAX_WHENCE]	= {0}; // ��������
char szSource	[MAX_SOURCE]	= {0}; // ���� ������
char szResult	[MAX_RESULT]	= {0};

static BOOL			bMoveWindow = 0;
static POINT		pMouse = {0};

char tmp[500]; // ����� ������
COLORREF clr = -1; // ��������� ���������� ����. ���� ������ = -1


bool SaveAsHTML(LPSTR lpFileName)
{
	HANDLE hFile = CreateFile((LPCTSTR)lpFileName,
								GENERIC_WRITE,
								FILE_SHARE_WRITE,
								NULL,
								CREATE_ALWAYS,
								FILE_ATTRIBUTE_NORMAL | FILE_FLAG_SEQUENTIAL_SCAN,
								(HANDLE)NULL);

	if ((!hFile) || (hFile == (void*)0xffffffff))
		return 0;

	DWORD d;
	
	WriteFile(hFile, szResult, strlen(szResult), &d, 0);
	CloseHandle(hFile);

	return 1;
}

void MakeH(BYTE b, LPSTR lp)
// ������� ��������� (header) ����� b �� ������ lp
{
	strnset(tmp, 0, 500);
	sprintf(tmp, "<h%i>%s</h%i>", b, lp, b);
/*	Font(tmp, Header[b-1], 1);
	strcat(tmp, lp);
	Font(tmp, Header[b-1], 0);*/
}

inline void MakeStringFromColor(COLORREF color, LPSTR lp)
{
	strcpy(tmp, COLOR_BEGIN);

	BYTE b = 0;
	for (int i = 2; i >= 0; i--)
	{
		b = (BYTE)(color >> (i*8));
		if (b >= 0x10)
			sprintf(tmp+strlen(tmp), "%2x", b);
		else 
			sprintf(tmp+strlen(tmp), "0%1x", b);
	}
	strcat(tmp, ">");

	strcat(lp, tmp);
}

int GetColorFromString(LPSTR lp, LPSTR szResult)
{
	bool bEnter = 1;

	if (*lp != '[')
		return -1;

	lp++;

	if (*lp == '/')
	{
		bEnter = 0;
		lp++;
	}

	for (int i = 0; i < sizeof(MainColors) / sizeof(MainColors[0]); i++)
	{
		if (!_strnicmp(lp, MainColors[i].name, strlen(MainColors[i].name)))
		{
			if (bEnter)
				MakeStringFromColor(MainColors[i].color, szResult);
			else
				strcat(szResult, "</font>");
			
			return strlen(MainColors[i].name) + ((bEnter)?2:3);
		}
	}

	return -1;
}

void MakeColor(COLORREF color, LPSTR lp)
// ������� ��� ������ � ����������
//
// color	- ����
// lp		- ���� ������, ���� ����� �����
{
	strnset(tmp, 0, 500); // ������� �����

	if ((clr != -1 && clr != color) || (color == -1 && clr != -1))		// ���������, ���� �� ���
		strcat(lp, COLOR_END);				// ����������� �� ������� ��������� � ������� �����
	
	if (color != -1 && clr != color) // ���� ���� ������� ����� ���������, ��
	{
		strcat(lp, COLOR_BEGIN); // ��������� ��� �����

		BYTE b = 0;
		for (int i = 2; i >= 0; i--) // ��������� �� ����� � ������
		{
			b = (BYTE)(color >> (i*8));
			if (b >= 0x10)
				sprintf(tmp, "%2x", b);
			else 
				sprintf(tmp, "0%1x", b);

			strncat(lp, tmp, 2);
		}
		strcat(lp, ">"); // ��������� ���
	}

	clr = color;
}

int IsMyTag(LPCSTR lp, LPSTR szResult, TAGS tag)
// ���������, ��� �� ��� �����������
// ��� ���� ��������� � ���������� ������
//
// lp - ������� ������
// szResult - ���� ������� �����
// tag - ��������� ����
{
	char sz[100];
	bool b = 0;
	LPSTR lp1 = strstr(tag.conv, "%s");
	b = lp1 != 0;

	sprintf(sz, "[%s]", tag.tag);
	if (!strncmp(lp, sz, strlen(sz)))
	{
		sprintf(sz, "<%s", tag.conv);		
		
		if (b)
		{
			char sz1[100];
			
			strncat(szResult, sz, strlen(sz)-strlen(lp1));
			sprintf(sz1, "[/%s]", tag.tag);
			lp += strlen(tag.tag)+2;

			while (strncmp(lp, sz1, strlen(sz1)))
			{
				strncat(szResult, lp, 1);
				lp++;
			}

			strcat(szResult, lp1+2);
		}
		else
			strcat(szResult, sz);

		strcat(szResult, ">");

		return (strlen(tag.tag)+2);
	}

	sprintf(sz, "[/%s]", tag.tag);
	if (!strncmp(lp, sz, strlen(sz)))
	{
		sprintf(sz, "<%s>", tag.close);
		strcat(szResult, sz);

		return (strlen(tag.tag)+3);
	}
	
	
	return -1;
}

int IsMyTag_ws(LPCSTR lp, LPSTR szResult, TAGS_WITH_STRINGS tag)
// ���������, ��� �� ��� �����������
// ��� ���� ��������� � ���������� ������
//
// lp - ������� ������
// szResult - ���� ������� �����
// tag - ��������� ����
{
	char sz[200];
	char param[150];

	sprintf(sz, "[%s", tag.tag);
	if (!strncmp(lp, sz, strlen(sz)))
	{
		LPSTR lp1 = (LPSTR)(lp + strlen(sz));
		memset(param, 0, sizeof(param));
		while (*lp1 != ']')
		{
			strncat(param, lp1, 1);
			lp1++;
		}
		
		if (*tag.tag != '<')
			strcat(szResult, "<");
		sprintf(szResult+strlen(szResult), tag.conv, param);
		if (*(char*)(tag.tag + strlen(tag.tag)) != '>')
			strcat(szResult, ">");

		return (strlen(tag.tag)+strlen(param) + 2);
	}

	sprintf(sz, "[/%s]", tag.tag);
	if (!strncmp(lp, sz, strlen(sz)))
	{
		sprintf(sz, "<%s>", tag.close);
		strcat(szResult, sz);

		return (strlen(tag.tag)+3);
	}	
	
	return -1;
}

inline bool IsChar(LPSTR lp)
{
	char sz[] =
	{
		' ',
		'\t',
		'\n',
		'\r',
		'(',
		')',
		';',
		']',
		',',
		'*',
		'!',
		'[',
		':',
		'"',
		'\'',
		'/',
		'-',
		'+',
		'%',
		'&',
		'=',
	};

	for (int i = 0; i < sizeof(sz); i++)
	{
		if (*lp == sz[i])
			return 0;
	}
	return 1;
}

int IsMyTag(LPCSTR lp, LPSTR szResult, LPSTR lpTag)
// ���������, ��� �� ��� �����������
// ��� ���� ��������� � ���������� ������
//
// lp - ������� ������
// szResult - ���� ������� �����
// lpTag - ��� ������ ����
{
	char sz[100];
//	char szTag[100];
//	strcpy(szTag, lpTag);
	
	sprintf(sz, "[%s]", lpTag);
	if (!strncmp(lp, sz, strlen(sz)))
	{
		if (!strncmp(lpTag, "code", 4))
		{
			strcpy(sz, "<h5>");
		}
		else if (!strncmp(lpTag, "/code", 5))
		{
			strcpy(sz, "</h5>");
		}
		else
		{
			sprintf(sz, "<%s>", lpTag);
		}

		strcat(szResult, sz);

		return strlen(lpTag)+2;
	}
	
	return -1;
}


void GenerateSource(HWND hWnd, HWND hWnd1, bool bIncludeStyle)
// ������� ������� �������� html-����
{
	memset(szResult, 0 , sizeof(szResult));
	if (!(*szAuthor)) // ���� ������ �� �������, �� ����� - SUnteXx
		strcpy(szAuthor, "SUnteXx\0"); // ����� ���� �������� :))

	if (!bIncludeStyle)
	{
		sprintf(szResult, BEGIN, szName, szDate);//, stTime.wDay, stTime.wMonth, stTime.wYear); // �������� ������ ��������
	}
	else
	{
		strcpy(szResult, HTML_BEGIN_1);
		strcat(szResult, STYLE);
		strcat(szResult, HTML_BEGIN_2);
	}

	if (*szName && *szName != ' ')
	{
		MakeH(2, szName); // ������� �������� ������ � header
		strcat(szResult, tmp); // �������� �������� ������
	}

	if (!(*szWhence)) // ���� �� ��� ������ ��������
	{
		if (*szAuthor != ' ')
		{
			sprintf(tmp, "A: (%s)\0", szAuthor);
			strcpy(szAuthor, tmp);
			MakeH(4, szAuthor); // �������� ��� ������		
			strcat(szResult, tmp);
		}
		else if (*szName != ' ')
			strcat(szResult, "<br>\r\n");
	}
	else
	{
		if (*szWhence && strncmp(szWhence, "http:", 5))
		{
			strcpy(tmp, szWhence);
			sprintf(szWhence, "http://%s", tmp);
		}
		if (*szLink && strncmp(szLink, "http:", 5))
		{
			strcpy(tmp, szLink);
			sprintf(szLink, "http://%s", tmp);
		}

		sprintf(tmp, "<h4>A: (��������: <a href=\"%s\">%s</a>)<br>\r\n\
������������ ������: <a href=\"%s\">%s</a><br>\r\n\
����� ������: %s</h4>\r\n",
 szWhence, szWhence, szLink, szLink, szAuthor);
		
		strcat(szResult, tmp); // ...
	}

	LPSTR lp = szSource; // ������� �� ������

	bool bStringCom = 0; // ����������� ������ [//]
	bool bManyStringCom = 0; // ����������� ������������� [/* */]
	bool bString1 = 0; // ������, ������� � ["]
	bool bString2 = 0; // ������, ������� � [']
	bool bCode = 0; // ��� ���? ����� ������ ��������� ������ ����!

	bool bSyntax = 0; // ���������� �� ���������!

	const int imax = strlen(szSource);
	const int percent = (imax < 100)?1:(int)floor((float)imax / (float)100);
	if (hWnd1)
	SendMessage(GetDlgItem(hWnd1, IDC_PROGRESS), PBM_SETRANGE32, 0, imax);

	int i=0;

	while (*lp)
	{		
		switch(*lp)
		{
			case '/':
			{
				if (bCode && (!bString1 && !bString2))
				{
					if (*(char*)(lp+1) == '*')
					{
						MakeColor(COMMENT_BEGIN, szResult);
						strcat(szResult, "/*");
						bManyStringCom = 1;
						lp++;
					}
					else if (*(char*)(lp+1) == '/')
					{
						MakeColor(COMMENT_BEGIN, szResult);
						strcat(szResult, "//");
						if (*(lp+2) != ' ')
							strcat(szResult, " ");
						bStringCom = 1;
						lp++;
					}
					else if (bSyntax)
					{
						MakeColor(OPERATOR_BEGIN, szResult);
						strncat(szResult, lp, 1);
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);
				break;
			}
			
			case '*':
			{
				if (bCode && (!bString1 && !bString2))
				{
					if (*(char*)(lp+1) == '/' && bManyStringCom)
					{
						strcat(szResult, "*/");
						bManyStringCom = 0;
						lp++;
					}
					else if (bSyntax)
					{
						MakeColor(OPERATOR_BEGIN, szResult);
						strncat(szResult, lp, 1);
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}

			case '=':
			{
/*				if (IsChar(lp-1))
					strcat(szResult, " ");
				else if (IsChar(lp-2))
					strcat(szResult, " ");*/

				if (bSyntax)
				{
					MakeColor(OPERATOR_BEGIN, szResult);
					strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);
				
//				if (*(char*)(lp+1) != ' ' && *(char*)(lp+1) != '=')
//					strcat(szResult, " ");
				break;
			}

			case '-':
			case '+':
			case '!':
			case '&':
			case '|':
			case '.':
			case ':':
			case '?':
			case '^':
			{
				if (bSyntax)
				{	
					MakeColor(OPERATOR_BEGIN, szResult);
					strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}

			case '\r':
			case '\n':
			{
				if (bStringCom)
				{
					bStringCom = 0;
				}

				strcat(szResult, "<br>\r\n");

				if (*(char*)(lp+1) == '\n')
					lp++;

				break;
			}

			case '<':
				if (bSyntax)
				{	
					MakeColor(OPERATOR_BEGIN, szResult);
					strcat(szResult, "&lt;");
				}
				else
					strcat(szResult, "&lt;");
				break;

			case '>':
				if (bSyntax)
				{	
					MakeColor(OPERATOR_BEGIN, szResult);
					strcat(szResult, "&gt;");
					bString1 = bString2 = 0;
				}
				else if (bString1 + bString2 == 2)
				{
					strcat(szResult, "&gt;");
					bString1 = bString2 = 0;
				}
				else
					strcat(szResult, "&gt;");
				break;

			case '\t':
			{
				strcat(szResult, TAB);					
				break;
			}

			case '\\':
			{
				if (bCode && !bStringCom && !bManyStringCom)
				{
					if (((*(char*)(lp-1)) != '\\') || (((*(char*)(lp-1)) == '\\') && ((*(char*)(lp-2)) == '\\')) && 
						((bString1 && ((*(char*)(lp+1)) == '"')) ||
						(bString2 && ((*(char*)(lp+1)) == '\''))))
					{
						strncat(szResult, lp, 2);
						lp++;
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);
				break;
			}
			
			case '\'':
			case '"':
			case '�':
			{
				if (*lp == '�')
					*lp = '"';
				
				if (bCode && !bStringCom && !bManyStringCom)
				{
					if ((*lp == '"' && !bString1 && !bString2) ||
						(*lp == '\'' && !bString1 && !bString2))
					{
						MakeColor(STRING_BEGIN, szResult);
						strncat(szResult, lp, 1);
						if (*lp == '"')
							bString1 = 1;
						else
							bString2 = 1;
					}
					else if ((*lp == '"' && bString1) || (*lp == '\'' && bString2))
					{
						strncat(szResult, lp, 1);
						if (*lp == '"')
							bString1 = 0;
						else
							bString2 = 0;
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}

			case '0':
			case '1':
			case '2':
			case '3':
			case '4':
			case '5':
			case '6':
			case '7':
			case '8':
			case '9':
			{
				if (bSyntax)
				{
					if (!IsChar(lp-1))
					{
						MakeColor(NUMBER_BEGIN, szResult);
						strncat(szResult, lp, 1);
						
						lp++;
						if (*(char*)(lp-1) == '0' && *(char*)(lp) == 'x')
						{
							strncat(szResult, lp, 1);
							lp++;
							while (((*lp >= '0') && (*lp <= '9')) || ((*lp >= 'a') && (*lp <= 'f')) || ((*lp >= 'A') && (*lp <= 'F')))
							{
								strncat(szResult, lp, 1);
								*lp++;								
							}
						}
						else
						{
							while (*lp >= '0' && *lp <= '9' || *lp == 'l')
							{
								strncat(szResult, lp, 1);
								*lp++;							
							}
						}
						lp--;
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}
			case '{':
			case '}':
			case ')':
			case '(':
			{
				if (bSyntax)
				{	
					MakeColor(SKOBKA_BEGIN, szResult);

					strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}

/*			case '_':
			{
				if (bSyntax)
				{
					if (IsChar(lp-1)/**(lp-1) == ' ' || *(lp-1) == ';' || *(lp-1) == ')' || *(lp-1) == ']' ||
						*(lp-1) == '\n' || *(lp-1) == '\t' || *(lp-1) == '"'* /)
					{
						MakeColor(INIT_BEGIN, szResult);
						
						strncat(szResult, lp, 1);
						while (IsChar(lp))//*lp != ' ' && *lp != ';' && *lp != '(' && *lp != '\r' && *lp != '\n')
						{
							strncat(szResult, lp, 1);
							lp++;
						}
						lp--;
					}
					else
						strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);

				break;
			}*/

			case '#':
			{
				if (bSyntax)
				{
					MakeColor(MACRO_BEGIN, szResult);
					strncat(szResult, lp, 1);
					if (!strncmp(lp, "#include", 7))
					{
						strncat(szResult, lp+1, 8);
						lp+=8;
						bool btmp = 0;
						LPSTR lp1 = lp;
						while (*lp1 != '\r' && *lp1 != '\n')
						{
							lp1++;

							if (!btmp && *lp1 == '<')
								btmp = 1;
							else if (btmp && *lp1 == '>')
							{
								MakeColor(STRING_BEGIN, szResult);
								bString1 = bString2 = 1;
							}
						}
					}
					else
					{
						lp++;
						while (/**lp != ' ' && *lp != ';' && *lp != '(' &&
							*lp != '\r' && *lp != '\n' && *lp != '\t'*/IsChar(lp))
						{
							strncat(szResult, lp, 1);
							lp++;
						}
						lp--;
					}
				}
				else
					strncat(szResult, lp, 1);
				break;
			}

			case '[':
			{				
				int i = -1;
				if (((i = IsMyTag(lp, szResult, "h5")) != -1 || (i = IsMyTag(lp, szResult, "code")) != -1))
				{
//					strcat(szResult, "<font color=\"#800080\">");
					lp += i-1;
					bCode = 1;
				}
				else if (((i = IsMyTag(lp, szResult, "/h5")) != -1 || (i = IsMyTag(lp, szResult, "/code")) != -1))
				{
					lp += i-1;
					bCode = 0;
					MakeColor(-1, szResult);
					if (*(lp+1) == '\r' || *(lp+1) == '\n') lp++;
					if (*(lp+1) == '\r' || *(lp+1) == '\n') lp++;
//					strcat(szResult, "</font>");
				}
				else if (((i = IsMyTag(lp, szResult, "h3")) != -1))
					lp += i-1;
				else if (((i = IsMyTag(lp, szResult, "/h3")) != -1))
				{
					lp += i-1;
					if (*(lp+1) == '\r' || *(lp+1) == '\n') lp++;
					if (*(lp+1) == '\r' || *(lp+1) == '\n') lp++;
				}
				else if (((i = IsMyTag(lp, szResult, "br")) != -1))
					lp += i-1;
				else if (bSyntax)
				{
					MakeColor(SKOBKA_BEGIN, szResult);
					strncat(szResult, lp, 1);
				}
				else
				{
					bool b1 = 0;
					int i1 = 0;
					if (!bCode)
					{
						for (int i1 = 0; i1 < sizeof(Tags) / sizeof(Tags[0]); i1++)
						{
							if ((i = IsMyTag(lp, szResult, Tags[i1])) != -1)
							{
								b1 = 1;
								lp += i-1;
								break;
							}
						}
						for (i1 = 0; i1 < sizeof(tags_ws) / sizeof(tags_ws[0]); i1++)
						{
							if ((i = IsMyTag_ws(lp, szResult, tags_ws[i1])) != -1)
							{
								b1 = 1;
								lp += i-1;
								break;
							}
						}
					}
					if (!b1)
					{
						i1 = 0;
						if ((i1 = GetColorFromString(lp, szResult)) != -1)
						{
							lp += i1-1;
						}
						else
							strncat(szResult, lp, 1);
					}
				}

				break;
			}

			case ']':
			{
				if (bSyntax)
				{
					MakeColor(SKOBKA_BEGIN, szResult);
					strncat(szResult, lp, 1);
				}
				else
					strncat(szResult, lp, 1);
				break;
			}

			case ';':
			{
				if (bSyntax)
				{
					MakeColor(OPERATOR_BEGIN, szResult);
					strcat(szResult, ";");
				}
				else
					strcat(szResult, ";");
				break;
			}

			case ',':
			{

				if (bSyntax)
				{
					MakeColor(OPERATOR_BEGIN, szResult);
					strcat(szResult, ((*(char*)(lp+1) != ' ')?", ":","));
				}
				else
					strcat(szResult, ((*(char*)(lp+1) != ' ')?", ":","));
				break;
			}

			case ' ':
			{
				int i = SendMessage(GetDlgItem(hWnd, IDC_SPINSPACE), UDM_GETPOS, 0, 0);
				if (!i)
					 i = 4;
				if (!strncmp(lp, "                       ", i))
				{
					strcat(szResult, TAB);
					lp += i-1;
				}
				else if (*(lp+1) == ' ' || *(lp-1) == ' ')
				{
					strcat(szResult, "&nbsp;");
				}
				else
					strncat(szResult, lp, 1);
				
				break;
			}

			default:
			{
				bool b = 0;
				if (bSyntax)
				{
					if (!IsChar(lp-1))
					{
							for (int i = 0; i < sizeof(szSyntax) / sizeof(szSyntax[i]); i++)
							{
								if (!strncmp(lp, szSyntax[i], strlen(szSyntax[i])))
								{
									if (!IsChar(lp+strlen(szSyntax[i])))
									{
										b = 1;
										break;
									}
								}
							}
							
							if (b)
							{
								int i11 = strlen(szResult);
								MakeColor(INIT_BEGIN, szResult);
								strncat(szResult, lp, strlen(szSyntax[i]));
								lp += strlen(szSyntax[i])-1;

/*								if (IsChar(lp+1))
									strcat(szResult, " ");*/
							}
					}
				}

				if (bSyntax)
					MakeColor(-1, szResult);
				if (!b)
				{
					strncat(szResult, lp, 1);
				}

				break;
			}
		}

		if (bCode && !bManyStringCom && !bStringCom && (!bString1 && !bString2))
			bSyntax = 1;
		else
			bSyntax = 0;
		
		lp++;
		i++;

		if (!(i % percent) && hWnd1)
			SendMessage(GetDlgItem(hWnd1, IDC_PROGRESS), PBM_SETPOS, lp-szSource, 0);

		if (!(*lp))
			break;
	}

	if (!_strnicmp(lp-5, "[/h5]", 5) || !_strnicmp(lp-5, "[/code]", 5))
	{
		strcat(szResult, "<br>");
	}
	else
		strcat(szResult, "<br><br><br>");

	if (hWnd1)
	{
		SendMessage(GetDlgItem(hWnd1, IDC_PROGRESS), PBM_SETPOS, imax, 0);
		ShowWindow(GetDlgItem(hWnd1, IDC_PROGRESS), SW_HIDE);
		RECT r;
		GetWindowRect(GetDlgItem(hWnd1, IDC_RESULT), &r);
		SetWindowPos(GetDlgItem(hWnd1, IDC_RESULT),
							0,
							0,
							0,
							r.right - r.left,
							r.bottom - r.top + 25,
							SWP_NOMOVE | SWP_NOZORDER);
	}

	strcat(szResult, END);

	return;
}

BOOL WINAPI ResultProc (HWND hWnd, UINT uMessage, WPARAM wParam, LPARAM lParam)
{
	switch(uMessage)
	{
		case WM_INITDIALOG:
		{
			// ������ ������	
			strnset(szName, 0, MAX_NAME);
			strnset(szLink, 0, MAX_LINK);
			strnset(szAuthor, 0, MAX_AUTHOR);
			strnset(szSource, 0, MAX_SOURCE);
			strnset(szWhence, 0, MAX_WHENCE);
			strnset(szResult, 0, MAX_RESULT);

			HWND hwndParent = GetParent(hWnd);

			// ��������� ������ �����������	
			GetWindowText(GetDlgItem(hwndParent, IDC_NAME), szName, MAX_NAME);
			GetWindowText(GetDlgItem(hwndParent, IDC_LINK), szLink, MAX_LINK);
			GetWindowText(GetDlgItem(hwndParent, IDC_AUTHOR), szAuthor, MAX_AUTHOR);
			GetWindowText(GetDlgItem(hwndParent, IDC_WHENCE), szWhence, MAX_WHENCE);
			GetWindowText(GetDlgItem(hwndParent, IDC_SOURCE), szSource, MAX_SOURCE);

			ShowWindow(hWnd, SW_SHOW);
			SetFocus(hWnd);
			
			GenerateSource(hwndParent, hWnd, (lParam == -1)?1:0);
			SetWindowText(GetDlgItem(hWnd, IDC_RESULT), szResult);

			break;
		}

		case WM_COMMAND:
		{
			switch(GET_WM_COMMAND_ID(wParam, lParam))
			{
				case IDOK:
				{
					char szFileNameBuf[MAX_PATH];
					GetTempPath(MAX_PATH, szFileNameBuf);
					strcat(szFileNameBuf, "\\preview.htm");
					DeleteFile(szFileNameBuf);
					GetTempPath(MAX_PATH, szFileNameBuf);
					strcat(szFileNameBuf, "\\style.css");
					DeleteFile(szFileNameBuf);
					
					EndDialog(hWnd, 0);
					
					break;
				}

				case IDC_SAVE:
				{
					OPENFILENAME ofn = {0};
					char szFilter[] = "HTML (*.htm;*.html)|*.htm;*.html|";
					char chReplace;
					int	cbString;

					cbString = strlen(szFilter);

					chReplace = szFilter[cbString - 1];

					for (int i = 0; szFilter[i] != '\0'; i++)
					{
						if (szFilter[i] == chReplace)
						szFilter[i] = '\0';
					}

					ofn.lpstrDefExt		= "*.htm;*.html";

					char	szFile[MAX_PATH];
					char	szFileTitle[MAX_PATH] = "";
					char	szTitle[]="Save as";

					if (*szFileNameBuf)
					{
						lstrcpy( szFile, szFileNameBuf);
					}
					else
					{						
						lstrcpy( szFile, "");
					}

					char *lpstrTmp = 0l;

					ofn.lStructSize			= sizeof(ofn);
					ofn.hwndOwner			= hWnd;
					ofn.hInstance			= hInst;
					ofn.lpstrFilter			= szFilter;
					ofn.lpstrCustomFilter	= (LPTSTR) NULL;
					ofn.nMaxCustFilter		= 0L;
					ofn.nFilterIndex		= 0L;
					ofn.lpstrFile			= szFile;
					ofn.nMaxFile			= sizeof(szFile);
					ofn.lpstrFileTitle		= szFileTitle;
					ofn.nMaxFileTitle		= sizeof(szFileTitle);
					ofn.lpstrInitialDir		= NULL;
					ofn.nFileOffset			= 0;
					ofn.nFileExtension		= 0;
					ofn.lCustData			= 0;
					ofn.Flags				= OFN_HIDEREADONLY | OFN_PATHMUSTEXIST | OFN_FILEMUSTEXIST |
													OFN_OVERWRITEPROMPT;
					ofn.lpfnHook			= (LPOFNHOOKPROC)(FARPROC)NULL;
					ofn.lpTemplateName		= (LPTSTR)NULL;

					if (GetSaveFileName(&ofn))
					{
						_fstrcpy((LPSTR)szFileNameBuf, (LPSTR)ofn.lpstrFile);
						SaveAsHTML(szFileNameBuf);
					}
					break;
				}

				case IDC_COPY:
				{
					if (OpenClipboard(hWnd))
					{
						int i = GetWindowTextLength(GetDlgItem(hWnd, IDC_RESULT))+1;
						LPWSTR lp1 = (LPWSTR)GlobalAlloc(GMEM_FIXED, i*sizeof(WCHAR));

						GetWindowText(GetDlgItem(hWnd, IDC_RESULT), szResult, MAX_RESULT);
						MultiByteToWideChar(CP_ACP, 0l, szResult, -1, (unsigned short *)lp1, i);

						EmptyClipboard();
						SetClipboardData(CF_TEXT, szResult);
						SetClipboardData(CF_UNICODETEXT, lp1);
						CloseClipboard();
					}

					break;
				}

				case IDC_PREVIEW:
				{
					char szFileNameBuf[MAX_PATH]={0};
					char szFileNameBuf1[MAX_PATH]={0};

					strcpy(szFileNameBuf, szDirOutName);
					strcat(szFileNameBuf, "\\style.css");
					GetTempPath(MAX_PATH, szFileNameBuf1);
					strcat(szFileNameBuf1, "\\style.css");

					CopyFile(szFileNameBuf, szFileNameBuf1, 0);

					GetTempPath(MAX_PATH, szFileNameBuf);
					strcat(szFileNameBuf, "preview.htm");

					SaveAsHTML(szFileNameBuf);
					
					ShellExecute(NULL, NULL, szFileNameBuf, NULL, NULL, SW_SHOWNORMAL);

					break;
				}



				default:
					break;
			}
			break;
		}

		case WM_NCLBUTTONDOWN:
			if (wParam != HTCAPTION)
				break;
		case WM_LBUTTONDOWN:
			bMoveWindow = TRUE;
			SetCapture(hWnd);
			GetCursorPos(&pMouse);
    
			break;

		case WM_NCMOUSEMOVE:
			if (wParam != HTCAPTION)
				break;
		case WM_MOUSEMOVE:
		{
			if (bMoveWindow)
			{
				POINT	pTmp;
				RECT	R;
				GetCursorPos(&pTmp);
				GetWindowRect(hWnd, &R);
				MoveWindow (hWnd,
							R.left + pTmp.x - pMouse.x, 
							R.top + pTmp.y - pMouse.y, 
							R.right - R.left,
							R.bottom - R.top,
							true);
				pMouse = pTmp;
			}
			break;

		}

		case WM_NCLBUTTONUP:
			if (wParam != HTCAPTION)
				break;
		case WM_LBUTTONUP:
			ReleaseCapture();
			bMoveWindow = FALSE;
			break;
		
		case WM_CLOSE:
			EndDialog(hWnd, 1);
			PostQuitMessage(0);
			break;


		default:
			return 0;
	}

	return 0;
}