#define HTML_BEGIN_1 "<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 Final//RU\">\r\n\
<html>\r\n\
<head>\r\n\
 <meta http-equiv=Content-Type content=\"text/html; charset=windows-1251\">\r\n\
 <title>Faq</title>\r\n\
 <style>\r\n"
/*   h6 { font-style : italic; font-weight : normal; font-size : 10pt; color : green; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 1%;}\r\n\
   h5 { font-family : courier; font-style : normal; font-weight : normal; font-size : 10pt; color : #800080; background-color : #fafafa; padding-top : 10pt; padding-left : 10pt; padding-right : 0; padding-bottom : 10pt; border-top : 1pt solid silver; border-bottom : 1pt solid silver; border-left : 1pt solid silver; border-right : 1pt solid silver; text-align : left; }\r\n\
   h4 { font-style : normal; font-weight : normal; font-size : 10pt; color : #303030; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 2%;}\r\n\
   h3 { font-weight : bold; font-size : 10pt; color : #000000;}\r\n\
   h2 { font-weight : bold; font-size : 12pt; color : #000000;}\r\n\
   h1 { font-weight : bold; font-size : 16pt; color : #000000; text-decoration : underline; text-transform : uppercase; text-align : center; padding-top : 5%; padding-bottom : 5%;}\r\n\
\r\n\
   body { font-style : normal; font-family : tahoma; font-weight : normal; font-size : 10pt; color : #000000; text-align : justify; padding-top : 0; padding-right : 0; padding-bottom : 0; padding-left : 1%;}\r\n\
\r\n\
   A:link { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
   A:visited { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
   A:active { font-family : arial; font-weight : normal; color : #0000ff; text-decoration : none;}\r\n\
   A:hover { font-family : arial; font-weight : normal; color : #ff0000; text-decoration : underline;}\r\n\*/

#define HTML_BEGIN_2 " </style>\r\n\
</head>\r\n\
\r\n\
<body bgcolor=\"FFFFFF\" link=\"0000FF\" alink=\"008000\" vlink=\"0000ff\" onload=\"window.focus();\" style=WIDTH:97%>\r\n\
<font name=\"tahoma\" size=\"-1\" color=#000000 style=\"padding-top : 1%; padding-right : 0; padding-bottom : 0; padding-left : 1%;\">\
<a name=\"top\"></a>\r\n"


#define HTML_BIND_B "<br><!------------------------- ������ %i -------------------------><br>\r\n\
<hr><br>\r\n\
<a name=\"%i\"></a><br>"

#define HTML_BIND_E "<br><a href=\"#bk%i\">������</a>"

#define HTML_END "</font></body><br>\r\n\
</html>"
