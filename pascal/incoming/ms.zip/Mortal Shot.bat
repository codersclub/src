@Echo off
Intro.exe
Readme.exe
Game.exe
End.exe