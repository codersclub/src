{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    This unit contains classes for working with images.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
{$i platform.inc}
unit gImages;
{$V-}

{ Use standart (BIOS) palette for 4BPP modes,
  use @Palette256Proc to find out the default palette for 8BPP modes,
  use Binary(RRRRRGGGGGGBBBBB) color representation for 16BPP modes,
  use Hex(00RRGGBB) color representation for 24BPP modes. }

interface

uses
  QSystem,
  Objects,
  gDrivers;

type
  PImageCanvas = ^TImageCanvas;
  TImageCanvas = object(TCanvas) { Usable class }
{!!!  private}
    Bitmap: HANDLE; { a memory to store a bitmap }
    xL, yL, xR, yR: Integer; { view port }
    procedure SeekXY(AX, AY: Integer);
  public
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;

    procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
    function GetPixel(AX, AY: Integer): LongInt; virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure GetLine(AX, AY, ASize: Integer; var ALine); virtual;
    procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
  end;

  PImageReader = ^TImageReader;
  TImageReader = object(TObject)
    src: PStream;
    startpos: LongInt;
    Status: Integer;
    Width, Height: Integer;
    BPP, BytesPerPixel: Word;
    Palette: TPalette;
    constructor Init(var Asrc: PStream);
    destructor Done; virtual;
      { Automatically frees <Palette> if it was allocated. }
    procedure SetImageInfo(AWidth, AHeight: Integer;
      ABPP: Word; APaletteNumEntries: Word);
    procedure LoadToCanvas(var Canvas: PCanvas; AX, AY: Integer); virtual;
      { We can load picture to ANY stream, e.g.
        memory, file or graphic screen.
        We'll put to <Canvas> pixels line-by-line.
      }
  end;

  PImageWriter = ^TImageWriter;
  TImageWriter = object(TObject)
    dst: PStream;
    startpos: LongInt;
    Status: Integer;
    constructor Init(var Adst: PStream);
    destructor Done; virtual;
    procedure SaveFromCanvas(var Canvas: PCanvas; AX, AY, BX, BY: Integer); virtual;
  end;

{
How to use:
var
  Bmp: PBmpFormat;
  Stream: PBufStream;
...
  Stream := New(PBufStream, Init('picture.bmp', stOpenRead, 8192));
  Bmp := New(PBmpFormat, Init(PStream(Stream)));
  if Bmp^.Status = ST_OK then
    Bmp^.LoadToCanvas(Screen, 0, 0);
  Dispose(Bmp, Done):
  Dispose(Stream, Done);
}

  { High-Level access.
    Automatically detects file formats and reads the image from file. }

  function LoadImage( Dir, FileName: string; var P: PImageCanvas;
    DesiredBPP: Word {if 0 the picture BPP will be used} ): Boolean;
  function LoadImageFromStream( var S: PStream; var P: PImageCanvas; DesiredBPP: Word ): Boolean;
  procedure UnLoadImage( var P: PImageCanvas );

implementation

uses
  Dos,
  gIma_Gif,
  gIma_Bmp,
  gIma_Cur;

{ TImageCanvas => }

procedure TImageCanvas.SeekXY(AX, AY: Integer);
begin
{!!!  PStream(AddrToPtr(Bitmap))^.Status := stOk;} {!!!}
  MSeek(Bitmap, ((LongInt(Width)*(AY)+AX)*BPP) div 8);
end;

constructor TImageCanvas.Init(AWidth, AHeight: Integer; ABPP: Word);
begin
  inherited Init(AWidth, AHeight, ABPP);
  Bitmap := MAllocate((LongInt(Width)*Height*BPP+7) div 8);
  if Bitmap = 0 then
    Status := ST_NO_MEMORY;
  xL := 0; yL := 0;
  xR := Width-1; yR := Height-1;
end;

destructor TImageCanvas.Done;
begin
  mfree(Bitmap);
end;

procedure TImageCanvas.PutPixel(AX, AY: Integer; AColor: LongInt);
var
  Color: Byte;
begin
  if (Status <> ST_OK) or (AX<xL) or (AY<yL) or (AX>xR-xL) or (AY>yR-yL) then
    Exit;
  SeekXY(xL+AX, yL+AY);
  if BPP = 4 then
    begin
      MRead( Bitmap, Color, BytesPerPixel );
      if not odd( LongInt(Width)*(yL+AY)+xL+AX ) then
        AColor := (Color and $0F) + (AColor shl 4)
      else
        AColor := (Color and $F0) + AColor;
      SeekXY(xL+AX, yL+AY);
    end;
    MWrite(Bitmap, AColor, BytesPerPixel);
end;

function TImageCanvas.GetPixel(AX, AY: Integer): LongInt;
var
  Color: LongInt;
begin
  if (Status <> ST_OK) or (AX<xL) or (AY<yL) or (AX>xR-xL) or (AY>yR-yL) then
    Exit;
  Color := 0;
  SeekXY(xL + AX, yL + AY);
  MRead(Bitmap, Color, BytesPerPixel);
  if BPP = 4 then
    begin
      if not odd( LongInt(Width)*(yL+AY)+xL+AX ) then
        Color := Color shr 4
      else
        Color := Color and $0F;
    end;
  GetPixel := Color;
end;

procedure TImageCanvas.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
begin
  if (Status <> ST_OK) then
    Exit;

  if AFlags and SHOW_TRANSPARENT <> 0 then
    inherited PutLine(AX, AY, ASize, ALine, AFlags)
  else
    begin
      SeekXY(xL+AX, yL+AY);
      MWrite(Bitmap, ALine, (ASize*BPP+7) div 8);
    end;
end;

procedure TImageCanvas.GetLine(AX, AY, ASize: Integer; var ALine);
begin
  if (Status <> ST_OK) then
    Exit;
  SeekXY(xL + AX, yL + AY);
  MRead(Bitmap, ALine, (ASize*BPP+7) div 8);
end;

procedure TImageCanvas.SetViewPort(AX, AY, BX, BY: Integer);
begin
  xL := AX; xR := BX;
  yL := AY; yR := BY;
end;

{ <= TImageCanvas }

{ TImageReader => }

constructor TImageReader.Init(var Asrc: PStream);
begin
  inherited Init;
  src := Asrc;
  startpos := src^.GetPos;
  Status := src^.Status;
end;

destructor TImageReader.Done;
begin
  if Palette.NumEntries > 0 then
    FreeMem(Palette.PalEntry, Palette.NumEntries*SizeOf(TPaletteEntry));
end;

procedure TImageReader.SetImageInfo(AWidth, AHeight: Integer;
  ABPP: Word; APaletteNumEntries: Word);
begin
  Width := AWidth;
  Height := AHeight;
  BPP := ABPP;
  BytesPerPixel := (BPP+7) div 8;
  if Palette.NumEntries <> 0
    then FreeMem( Palette.PalEntry, Palette.Version );

  Palette.NumEntries := APaletteNumEntries;
  Palette.Version := Palette.NumEntries * SizeOf( TPaletteEntry );

  if Palette.NumEntries <> 0
    then begin
      GetMem( Palette.PalEntry, Palette.Version );
      FillChar( Palette.PalEntry^, Palette.Version, 0 );
    end;
end;

procedure TImageReader.LoadToCanvas(var Canvas: PCanvas; AX, AY: Integer);
begin
{  Abstract;}
end;

{ <= TImageReader }

{ => TImageWriter }

constructor TImageWriter.Init(var Adst: PStream);
begin
  inherited Init;
  dst := Adst;
  startpos := dst^.GetPos;
  Status := ST_OK;
end;

destructor TImageWriter.Done;
begin
  inherited Done;
end;

procedure TImageWriter.SaveFromCanvas(var Canvas: PCanvas; AX, AY, BX, BY: Integer);
begin
end;

{ <= TImageWriter }

  function LoadImage( Dir, FileName: string; var P: PImageCanvas; DesiredBPP: Word ): Boolean;
  var
    Dirr,Name,Ext: string;
    R: PImageReader;
    S: PStream;
  begin
    FSplit( FileName, Dirr, Name, Ext );

    FileName := FSearch( FileName, Dir+';'+Dirr+';'+'.\');
    if FileName = '' then
      begin
        P := nil;
        LoadImage := False;
        Exit;
      end
    else
      FileName := FExpand(FileName);


    Ext := UpperCase( Ext );

    S := New(PBufStream, Init(FileName, stOpenRead, 8192));

    if Ext='.GIF'
      then R := PImageReader( New( PGifReader, Init(S) ) )
      else
    if Ext='.CUR'
      then R := PImageReader( New( PCurReader, Init(S) ) )
      else
    if Ext='.ANI'
      then R := PImageReader( New( PAniReader, Init(S) ) )
      else R := PImageReader( New( PBmpReader, Init(S) ) );


    if R^.Status < 0
      then begin
        Dispose(R, Done);
        Dispose(S, Done);
        P := nil;
        LoadImage := False;
        Exit;
      end;

    if DesiredBPP = 0 then
      P := New(PImageCanvas, Init(R^.Width, R^.Height, R^.BPP))
    else
      P := New(PImageCanvas, Init(R^.Width, R^.Height, DesiredBPP));
    R^.LoadToCanvas(PCanvas(P), 0, 0);

    Dispose(R, Done);
    Dispose(S, Done);
    LoadImage := True;
  end;

  function LoadImageFromStream( var S: PStream; var P: PImageCanvas; DesiredBPP: Word ): Boolean;
  var
    R: PImageReader;
    pos: LongInt;
  label
    Ok;
  begin
    pos := S^.GetPos;
    R := PImageReader( New( PGifReader, Init(S) ) );
    if R^.Status = stOk then
      goto Ok;
    Dispose(R, Done);

    S^.Seek(pos);
    R := PImageReader( New( PCurReader, Init(S) ) );
    if R^.Status = stOk then
      goto Ok;
    Dispose(R, Done);

    S^.Seek(pos);
    R := PImageReader( New( PAniReader, Init(S) ) );
    if R^.Status = stOk then
      goto Ok;
    Dispose(R, Done);

    S^.Seek(pos);
    R := PImageReader( New( PBmpReader, Init(S) ) );
    if R^.Status = stOk then
      goto Ok;
    Dispose(R, Done);

        P := nil;
        LoadImageFromStream := False;
        Exit;

    Ok:
    if DesiredBPP = 0 then
      P := New(PImageCanvas, Init(R^.Width, R^.Height, R^.BPP))
    else
      P := New(PImageCanvas, Init(R^.Width, R^.Height, DesiredBPP));
    R^.LoadToCanvas(PCanvas(P), 0, 0);

    Dispose(R, Done);
    LoadImageFromStream := True;
  end;

  procedure UnLoadImage( var P: PImageCanvas );
  begin
    if P=nil then Exit;
    Dispose(P,Done);
    P := nil;
  end;

end.
