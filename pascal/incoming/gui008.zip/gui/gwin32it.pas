{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    This unit contains some Win32 items.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
unit gWin32Items;

interface

uses
  gImages,
  gDrivers,
  gItems;

type
  PProgressBar = ^TProgressBar;
  TProgressBar = object (TItem)
    MinValue, MaxValue, Position: LongInt;
    Rectangles: Integer;
    RectWidth: Integer;
    constructor Init( ALeft, ATop, AWidth, AHeight: Integer );
    destructor Done; virtual;
    procedure SetPosition( APosition: LongInt );
    procedure SetPercent( APerCent: LongInt );
    procedure DrawRectangles(var Canvas: PCanvas; AX, AY: Integer; N: Integer );
    procedure Draw(var Canvas: PCanvas; AX, AY: Integer); virtual;
  end;

implementation

{ => TProgressBar }

constructor TProgressBar.Init( ALeft, ATop, AWidth, AHeight: Integer );
begin
  if AWidth = 0 then AWidth := 150;
  if AHeight = 0 then AHeight := 14;
  inherited Init( ALeft, ATop, AWidth, AHeight );
  MinValue := 0;
  MaxValue := 100;
  Position := 0;
  Rectangles := 0; { [] [] [] [] ... }
  RectWidth := Round( 0.75 * Height );
  if (Width-2) mod RectWidth <> 0
    then Width := ((Width - 2 + RectWidth) div RectWidth)*RectWidth + 2;
end;

destructor TProgressBar.Done;
begin
  inherited Done;
end;

procedure TProgressBar.SetPosition( APosition: LongInt );
var
  k: Real;
  R: Integer;
  C: PCanvas;
begin

  if APosition < MinValue then APosition := MinValue else
  if APosition > MaxValue then APosition := MaxValue;

  if APosition = Position then Exit;

  Position := APosition;
  k := ( Position - MinValue) / (MaxValue - MinValue);
  R := Round( (Width-2)*k ) div RectWidth;

  if R = Rectangles then Exit;

  C := GetCanvas;
  if R < Rectangles then
  begin
    Rectangles := R;
    ReDraw(C, GetAX, GetAY)
  end
  else
  begin
    Rectangles := R;
    DrawRectangles(C, GetAX, GetAY, R);
  end;

end;

procedure TProgressBar.SetPercent( APerCent: LongInt );
begin
  if APerCent < 0 then APerCent := 0 else
  if APerCent > 100 then APerCent := 100;
  SetPosition( MinValue + Round( (MaxValue-MinValue)*APerCent/100 ) );
end;

procedure TProgressBar.DrawRectangles(var Canvas: PCanvas; AX, AY: Integer; N: Integer );
var
  i: Integer;
begin
  BeginUpdate;
  for i:=0 to N-1 do
    Canvas^.Bar( AX+Left + 1 + i*RectWidth + 1, AY+Top + 2,
                 AX+Left + 1 + (i+1)*RectWidth - 2, AY+Top + Height - 3,
                 col_bar_bg );
  EndUpdate;
end;

procedure TProgressBar.Draw(var Canvas: PCanvas; AX, AY: Integer);
begin
  BeginUpdate;
  Canvas^.Bar( AX+Left, AY+Top, AX+Left + Width - 1, AY+Top + Height - 1, col_3d_bg );
  Canvas^.BevelInner( AX+Left, AY+Top, AX+Left + Width - 1, AY+Top + Height - 1 );
  EndUpdate;
  DrawRectangles( Canvas, AX, AY, Rectangles );
end;

{ <= TProgressBar }

end.
