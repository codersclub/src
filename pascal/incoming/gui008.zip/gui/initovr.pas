{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    This unit may be usable when working with overlays in Borlan Pascal.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
{$F+,O+}
unit InitOvr;

interface

implementation

uses
  Overlay;

  procedure InitOverlays;
  var
    i: Integer;
  begin
    OvrInit( Copy(ParamStr(0),1,Pos('.',ParamStr(0))) + 'ovr' );
    i := OvrResult;
    if i = ovrNotFound then
      begin
        OvrInit( ParamStr(0) );
        i := OvrResult;
      end;
    if i <> ovrOk then
      begin
        Writeln;
        Writeln('Can''t load overlay. Error code = ',i,'.');
        Halt(2);
      end;
  end;

begin
  InitOverlays;
end.
