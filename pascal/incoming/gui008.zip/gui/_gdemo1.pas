{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    GUI demonstration program #1.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
program GUIDemo1;

{$ifdef fpc}
  {$define THEME}  { <= remove this if you don't want to use themes }
{$endif}
{ $define SCREENSHOT}

uses
  QSystem,
{$ifdef SCREENSHOT}
  gIma_bmp,
  gDrivers,
{$endif}

  gInit,
  gThemes,
  gStandartItems;

var
  StartMem: LongInt;

  B: PButton;
  GB: PGroupBox;
  Result: Integer;
  Form: PForm;
  RB: PRadioButton;
  CB: PCheckBox;

begin
  StartMem := MemAvail;
  InitGUI(640,480,16);

{$ifdef THEME}
  SetDefaultTheme( LoadTheme('linux.thm') );
    { <= specify directory name here; filename will be
      <directory_path>\<directory_name>.thm }
{$endif}

  Form := New(PForm, Init(
    10,10,   { coordinates of the left top corner }
    400,300, { width & height }
    'Form1', { caption }
    False,   { we don't want to save image under the form }
    DRAG_RECTANGLE { how we want to Drag&Drop window;
                     available constants:
                     DRAG_NONE        - no drag
                     DRAG_RECTANGLE   - a dotted rectangle will be visible
                                        while dragging
                     DRAG_SHOW        - window will be redrawn while dragging
                   }
  ));

  GB := New(PGroupBox, Init(
    50,50,   { coordinates }
    300,80,  { size }
    'GroupBox1', { caption }
    BEVEL_INNER_OUTER { style;
                        available constants:
                        BEVEL_NONE     - no bevel
                        BEVEL_INNER
                        BEVEL_OUTER
                        BEVEL_INNER2
                        BEVEL_OUTER2
                        BEVEL_INNER_OUTER
                      }
  ));

  GB^.Insert(New(PLabel, Init(50,20,0,0,'This is a label')));


  B := New(PButton, Init(50,50,0,0,'B&utton1',
    1 { this is an ID (must be positive);
        this ID will be returned by Desktop^.Execute
        if the button is pressed
      }
    ));
  B^.Default := True; { if user presses ENTER, this button will be pressed }
  GB^.Insert(B);

  B := New(PButton, Init(150,50,0,0,'&Button2',2));
  B^.Cancel := True;  { if user presses ESC, this button will be pressed }
  GB^.Insert(B);

  Form^.Insert(GB);

  Form^.Insert(New(PEdit, Init(100,150,0,0,'Edit1',50 {maximal string length})));
  Form^.Insert(New(PPasswordLine, Init(100,180,0,0,'Password',50 {maximal password length})));
  CB := New(PCheckBox, Init(100,220,0,0,'This is a checkbox'));
  CB^.Checked := True; { with the checked tick }
  Form^.Insert(CB);

  RB := New(PRadioButton, Init(100,240,0,0,'This is a radiobutton1'));
  RB^.Selected := True;
  Form^.Insert(RB);

  Form^.Insert(New(PRadioButton, Init(100,260,0,0,'This is a radiobutton2')));

  Desktop^.Insert(Form);

  Form := New(PForm, Init( 420,10,100,200,'Form2',False,DRAG_RECTANGLE));
  Form^.Insert(New(PButton,Init(10,30,50,20,'Hello!',5)));
  Desktop^.Insert(Form);

  Result := Desktop^.Execute;

  {$ifdef SCREENSHOT}
    Desktop^.Show(Screen, 0, 0);
    GrabScreenToBMP('scrshot1.bmp');
    Desktop^.Hide(Screen, 0, 0);
  {$endif}
{
  Or you can use this:
    Result := Form^.ShowModal;
    Dispose(Form, Done);
}

{$ifdef THEME}
  UnLoadTheme( DefaultTheme );
{$endif}


{ === GUI FINALIZATION === }
  DoneGUI;
  Writeln;
  Writeln('Memory check: ', StartMem, ' ', MemAvail);
  Writeln('Pressed: ', Result);
end.
