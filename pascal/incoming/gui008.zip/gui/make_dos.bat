rem Compiles GUI examples for GO32V2 (DOS) by FreePascal
fpc -Fufreetype\lib -Fifreetype\lib -Fuqsystem -Sg -O1 -O2 -O3 -TGO32V2 _gDemo1.pas
fpc -Fufreetype\lib -Fifreetype\lib -Fuqsystem -Sg -O1 -O2 -O3 -TGO32V2 _gDemo2.pas
fpc -Fufreetype\lib -Fifreetype\lib -Fuqsystem -Sg -O1 -O2 -O3 -TGO32V2 _gDemo3.pas
fpc -Fufreetype\lib -Fifreetype\lib -Fuqsystem -Sg -O1 -O2 -O3 -TGO32V2 _gDemo4.pas

