{
  Borland Pascal Graph (BGI) unit driver for GUI.
  Copyright (c) 2002 Sergey Kozlovich.
  Compatible: BP.
}
unit gBGI;

interface

uses
  Objects,
  gImages,
  gDrivers,
  gCursors,
  Crt,
  Graph,
  AMouse;

type
  PBGIDriver = ^TBGIDriver;
  TBGIDriver = object(TScreenDriver)
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;
    procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
    function GetPixel(AX, AY: Integer): LongInt; virtual;
    procedure HLine(AX, AY, BX: Integer; AColor: LongInt); virtual;
    procedure VLine(AX, AY, BY: Integer; AColor: LongInt); virtual;
    procedure Line(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
    procedure SetWriteMode(AWriteMode: Integer); virtual;

    procedure SetRGB(AColor: LongInt; r, g, b: Byte);
    procedure GetRGB(AColor: LongInt; var r, g, b: Byte);
    procedure SetPalette(Palette: Pointer; PaletteSize: Word);
  end;

  PBGIMouseDriver = ^TBGIMouseDriver;
  TBGIMouseDriver = object (TMouseDriver)
    constructor Init;
    procedure GetState(var _x,_y: Integer; var _butt: Byte); virtual;
    procedure SetPos(_x,_y: Integer); virtual;
    destructor Done; virtual;
  end;

implementation

procedure EgaVgaDriverProc; external; {$L egavga.obj}
procedure BGI256DriverProc; external; {$L bgi256.obj}

{ => TBGIDriver }
constructor TBGIDriver.Init(AWidth, AHeight: Integer; ABPP: Word);
var
  gd,gm: Integer;

  procedure SetPalette256;
  var
    i: Integer;
    r, g, b: Byte;
  begin
    for i := 16 to 231 do
      begin
        img_dergb_8(i, r, g, b);
        SetRGB(i, r, g, b);
      end;
  end;

begin
  if ABPP > 8 then ABPP := 8;
  inherited Init(AWidth, AHeight, ABPP);
    if BPP=8
      then begin
        { 256-color driver }
        gd:=InstallUserDriver('BGI256',Nil);
        If RegisterBGIDriver(@BGI256DriverProc) < 0 Then
        Begin
          Writeln(GraphErrorMsg(GraphResult));
          Halt;
        End;
        case width of
        320: gm:=0;            { 320x200 }
        640: case height of
             400: gm:=1;       { 640x400 }
             480: gm:=2;       { 640x480 }
             350: gm:=5;       { 640x350 }
             end;
        800: gm:=3;            { 800x600 }
        1024: gm:=4;           { 1024x768 }
        1280: gm:=6;           { 1280x1024 }
        end;
      end
      else begin
        { 16-color driver }
        If RegisterBGIDriver(@EgaVgaDriverProc) < 0 Then
        Begin
          Status := Graph.GraphResult;
          Exit;
        End;
        gd:=VGA;
        gm:=VGAHi;
      end;
    Graph.InitGraph(gd,gm,'');

  Status:=Graph.GraphResult;
  if Status<>grOk then
    Exit;

  if BPP=8 then
    SetPalette256;

  Width:=Graph.GetMaxX+1;
  Height:=Graph.GetMaxY+1;
  InitColors;
end;

destructor TBGIDriver.Done;
begin
  if Status = stOk
    then Graph.CloseGraph;
  TextMode(LastMode);
end;

procedure TBGIDriver.PutPixel(AX, AY: Integer; AColor: LongInt);
begin
  Graph.PutPixel(AX, AY, AColor);
end;

function TBGIDriver.GetPixel(AX, AY: Integer): LongInt;
begin
  GetPixel := Graph.GetPixel(AX, AY);
end;

procedure TBGIDriver.HLine(AX, AY, BX: Integer; AColor: LongInt);
begin
  Graph.SetColor(AColor);
  Graph.Line(AX, AY, BX, AY);
end;

procedure TBGIDriver.VLine(AX, AY, BY: Integer; AColor: LongInt);
begin
  Graph.SetColor(AColor);
  Graph.Line(AX, AY, AX, BY);
end;

procedure TBGIDriver.Line(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Graph.SetColor(AColor);
  Graph.Line(AX, AY, BX, BY);
end;

procedure TBGIDriver.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
var
  s, o: LongInt;
begin
{  if BPP = 4 then
    begin
      o := LongInt(AY)*Width div 2 + AX;
      s := $A000 + o shr 16;
      o := o and $FFFF;
      Move( ALine, ptr(s,o)^, ASize div 2);
      if odd(ASize) then
        PutPixel(AX, AY+ASize-1, TByteArray(ALine)[ASize-1]);
    end
  else}
    inherited PutLine(AX, AY, ASize, ALine, AFlags);
end;

procedure TBGIDriver.Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Graph.SetColor(AColor);
  Graph.Rectangle(AX, AY, BX, BY);
end;

procedure TBGIDriver.DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
{  Graph.SetColor(AColor);
  Graph.SetLineStyle(DottedLn,0,1);
  Graph.Rectangle(AX, AY, BX, BY);
  Graph.SetLineStyle(SolidLn,0,1);}
  inherited DottedRectangle(AX, AY, BX, BY, AColor);
end;

procedure TBGIDriver.Bar(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Graph.SetFillStyle(Graph.SolidFill, AColor);
  Graph.Bar(AX, AY, BX, BY);
end;

procedure TBGIDriver.SetViewPort(AX, AY, BX, BY: Integer);
begin
  Graph.SetViewPort(AX, AY, BX, BY, True);
end;

procedure TBGIDriver.SetWriteMode(AWriteMode: Integer);
begin
  Graph.SetWriteMode(AWriteMode);
end;

procedure TBGIDriver.SetRGB(AColor: LongInt; r, g, b: Byte);
begin
  if BPP>8 then Exit;
  r:=r div 4; g:=g div 4; b:=b div 4;
{$ifndef fpc}
  asm
    mov DX, 3c8h
    mov AL, byte[AColor]
    out DX, AL
    inc DX
    mov AL, r
    out DX, AL
    mov AL, g
    out DX, AL
    mov AL, b
    out DX, AL
  end;
{$endif}
end;

procedure TBGIDriver.GetRGB(AColor: LongInt; var r, g, b: Byte);
begin
  if BPP>8 then Exit;
{$ifndef fpc}
Asm
   MOV DX,$3C7          { $3C7 is colour ** READ ** select port. }
   MOV AL,byte[AColor]  { Select colour to read }
   OUT DX,AL
   ADD DL,2             { DX now = $3C9, which must be read 3 times
			  in order to obtain the Red, Green and
			  Blue values of a colour }

   IN AL,DX             { Read red amount. Don't use IN AX,DX as
			  for some strange reason it doesn't work ! }
   LES DI,r
   MOV [ES:DI],AL       { (Smarmy comment removed :) ) }
   IN AL,DX             { IN AX,DX doesn't seem to work on my ISA card }
			{ so I left it out for you DX-2 chaps! }

   LES DI,g
   MOV [ES:DI],AL

   IN AL,DX             { Read blue }
   LES DI,b
   MOV [ES:DI],AL
End;
{$endif}
end;

procedure TBGIDriver.SetPalette(Palette: Pointer; PaletteSize: Word);
type
  PPalette = ^TPalette;
  TPalette = array [0..255] of record r,g,b: Byte; end;
var
  i: Byte;
  r,g,b: Byte;
begin
  for i:=0 to PaletteSize-1 do begin
    r:=PPalette(palette)^[i].r;
    g:=PPalette(palette)^[i].g;
    b:=PPalette(palette)^[i].b;
    setrgb(i,r,g,b);
  end;
end;

{ <= TBGIDriver }

{ => TBGIMouseDriver }
constructor TBGIMouseDriver.Init;
begin
  inherited Init;
  IsMouse:=AMouse.MouseInstalled;
{  AMouse.HideMouseCursor;}
  SetPos(Screen^.Width div 2, Screen^.Height div 2);
end;

procedure TBGIMouseDriver.GetState(var _x,_y: Integer; var _butt: Byte);
var
  __x, __y, __butt: Word;
begin
  AMouse.GetMousePos(__x, __y, __butt);
  _x := __x; _y := __y; _butt := __butt;
  gCursors.ReDrawCursor( _x, _y );
end;

procedure TBGIMouseDriver.SetPos(_x,_y: Integer);
begin
  AMouse.SetMousePos(_x,_y);
  inherited SetPos( _x, _y );
end;

destructor TBGIMouseDriver.Done;
begin
  inherited Done;
end;
{ <= TBGIMouseDriver }

end.
