{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    A template for GUI applications.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
program GUIApplication;
uses
  gInit,
  gStandartItems;

{$ifdef DEBUG}
var
  StartMem: LongInt;
{$endif}

begin

{ === GUI INITIALIZATION === }
{$ifdef DEBUG}
  StartMem := MemAvail;
{$endif}
  InitGUI(640, 480, 16);

{ === GUI WORK === }

{ === GUI FINALIZATION === }
  DoneGUI;
{$ifdef DEBUG}
  Writeln;
  Writeln('Memory check: ', StartMem, ' ', MemAvail);
{$endif}
end.
