rem Compiles GUI examples for DOS Real mode by Turbo Pascal
tpc -M -Ifreetype\lib -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX; -L -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo1
tpc -M -Ifreetype\lib -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX; -L -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo2
tpc -M -Ifreetype\lib -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX; -L -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo3
tpc -M -Ifreetype\lib -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX; -L -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo4

rem -M   means to make all units
rem -I<include directories>
rem -U<unit directories>
rem -O<object directories>
rem -L   means to link buffer to disk (if out of memory)
