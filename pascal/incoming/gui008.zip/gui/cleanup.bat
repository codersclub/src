::@echo off
rem CLEANUP.BAT v2.0
rem
rem Deleting temporary/backup/object files created by PASCAL compilers
rem in the directory specified in parameter %1.
rem If no parameters are specified the current directory is used.
rem   Copyright (c) Sergey Kozlovich, 2002-2003

if "%1"=="" set DIR=.
if not "%1"=="" set DIR=%1

rem We can check if the directory exists using "if exist %DIR%\*.* ..."
if not exist %DIR%\*.* goto Error
if "%DIR%"=="." echo Deleting in current directory...
if not "%DIR%"=="." echo Deleting in %DIR%\...

rem del %DIR%\fp.DIR
rem del %DIR%\bp.tp
del %DIR%\*.ppu
del %DIR%\*.ppw
del %DIR%\*.ow
del %DIR%\*.o
del %DIR%\*.tpu
del %DIR%\*.tpp
del %DIR%\ppas.bat
del %DIR%\*.sw
del %DIR%\*.bak
del /p %DIR%\*.exe
for %%I in (*.) do for %%J in (*.pas) do if "%%I.pas"=="%%J" del /p %DIR%\%%I.
del %DIR%\bp.psm
del %DIR%\bp.dsk
del %DIR%\fp___*.*
del %DIR%\*.a
del %DIR%\*.s
del %DIR%\*.$$$
if not "%PROCESSOR_ARCHITECTURE%"=="" del /p %DIR%\*.*~
del %DIR%\ppas*.sh
del %DIR%\link.res

rem Deleting all in the sub-directories
if not "%PROCESSOR_ARCHITECTURE%"=="" goto NT
for %%I in (%DIR%\*.*) do if exist %%I\*.* if not %%I==%DIR%\. if not %%I==%DIR%\.. %0 %%I
goto End
:NT
for /D %%i in (%DIR%\*.*) do if not %%i==%DIR%\. if not %%i==%DIR%\.. %0 %%i
goto End

:Error
if exist %DIR% echo %DIR% is not a directory.
if not exist %DIR% echo Directory %DIR% doesn't exist.
:End

set DIR=
