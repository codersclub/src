{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    A test program for unit gIma_Gif

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
program Test_gImages;

uses
  Objects,
  gImages,
  gIma_Gif,
  gDrivers
{$ifdef fpc},
  gGraph
{$else},
  gGrafx
{$endif};

var
  Stream: PBufStream;
  Gif: PGifReader;

  StartMem: LongInt;

begin
  StartMem := MemAvail;

  {$ifdef fpc}
  Screen := New(PGraphDriver, Init(800, 600, 16));
  {$else}
  Screen := New(PGrafxDriver, Init(640,480,16));
  {$endif}


  Stream := New(PBufStream, Init('install.gif', stOpenRead, 8192));
  Gif := New(PGifReader, Init(PStream(Stream)));
  Gif^.LoadToCanvas(Screen, 0, 0);
  Dispose(Stream, Done);
  Dispose(Gif, Done);

  ReadKey;

  Dispose(Screen, Done);
  Writeln('Memory check: ', StartMem, ' ', MemAvail);
end.
