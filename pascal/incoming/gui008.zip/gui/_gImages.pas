{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    A test program for unit gImages

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
program Test_gImages;

uses
  Objects,
  gImages,
  gIma_Cur,
  gIma_Bmp,
  gIma_Gif,
  gDrivers
{$ifdef fpc},
  gGraph
{$else},
  gGrafX
{$endif};

var
  Stream: PBufStream;
  Cur: PCurReader;
  Ani: PAniReader;
  Bmp: PBmpReader;
  Gif: PGifReader;

  StartMem: LongInt;

  p: PImageCanvas;
begin
  StartMem := MemAvail;


  Write('Loading...');
  Stream := New(PBufStream, Init('1.bmp', stOpenRead, 8192));
  Bmp := New(PBmpReader, Init(PStream(Stream)));
  p := New(PImageCanvas, Init(bmp^.width, bmp^.height, 16));
  Bmp^.LoadToCanvas(PCanvas(p), 0, 0);
  Dispose(Stream, Done);
  Writeln(' Done.');

  if bmp^.Status <> stOk then
    begin
      Writeln('Error reading BMP file!');
      Halt;
    end;
  if p^.Status <> stOk then
    begin
      Writeln('No memory!');
      Halt;
    end;

  Dispose(Bmp, Done);

  {$ifdef fpc}
  Screen := New(PGraphDriver, Init(800, 600, 16));
  {$else}
  Screen := New(PGrafxDriver, Init(640,480,16));
  {$endif}

  Screen^.putimage(PCanvas(p), 0, 0, p^.width, p^.height, SHOW_NORMAL);
  Dispose(p, Done);
  ReadKey;
  Screen^.Bar(0,0,Screen^.Width-1,Screen^.Height-1,Black);


  Stream := New(PBufStream, Init('1.gif', stOpenRead, 8192));
  Gif := New(PGifReader, Init(PStream(Stream)));
  Gif^.LoadToCanvas(Screen, 0, 0);
  Dispose(Stream, Done);
  Dispose(Gif, Done);
  ReadKey;


  Stream := New(PBufStream, Init('1.cur', stOpenRead, 8192));
  Cur := New(PCurReader, Init(PStream(Stream)));
  Screen^.Bar(100, 100, 140, 140, Green);
  Cur^.LoadToCanvas(Screen, 100, 100);
  Dispose(Cur, Done);
  Dispose(Stream, Done);
  ReadKey;

  Stream := New(PBufStream, Init('1.ani', stOpenRead, 8192));
  Ani := New(PAniReader, Init(PStream(Stream)));
  repeat
    Screen^.Bar(100, 100, 140, 140, LightGreen);
    Ani^.LoadToCanvas(Screen, 100, 100);
    Delay(Ani^.Time);
  until KeyPressed;
  Dispose(Ani, Done);
  Dispose(Stream, Done);
  ReadKey;

  Stream := New(PBufStream, Init('1.bmp', stOpenRead, 8192));
  Bmp := New(PBmpReader, Init(PStream(Stream)));
  Bmp^.LoadToCanvas(Screen, 0, 0);
  Dispose(Stream, Done);
  Dispose(bmp, Done);
  ReadKey;


  Dispose(Screen, Done);
  Writeln('Memory check: ', StartMem, ' ', MemAvail);
end.
