rem Compiles GUI examples for Win32 by FreePascal
fpc -Fufreetype\lib;graphix;graphix\svgalib;graphix\directdraw\lib;qsystem -Fifreetype\lib -Sg -O1 -O2 -O3 -TWIN32 _gDemo1
fpc -Fufreetype\lib;graphix;graphix\svgalib;graphix\directdraw\lib;qsystem -Fifreetype\lib -Sg -O1 -O2 -O3 -TWIN32 _gDemo2
fpc -Fufreetype\lib;graphix;graphix\svgalib;graphix\directdraw\lib;qsystem -Fifreetype\lib -Sg -O1 -O2 -O3 -TWIN32 _gDemo3
fpc -Fufreetype\lib;graphix;graphix\svgalib;graphix\directdraw\lib;qsystem -Fifreetype\lib -Sg -O1 -O2 -O3 -TWIN32 _gDemo4

