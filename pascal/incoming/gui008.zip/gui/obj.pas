{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    This unit implements some data structures.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
unit obj;

interface

uses
  Objects;

type
  PStrings = ^TStrings;
  TStrings = object (TCollection)
    constructor Init;
    destructor Done; virtual;
    procedure Add(s: string); virtual;
    procedure FreeItem(Item: Pointer); virtual;
    function LoadFromFile( AFileName: string): Boolean; virtual;
  end;


  PStrings2Item = ^TStrings2Item;
  TStrings2Item = record
    Name: string;
    Strings: PStrings;
  end;

  PStrings2 = ^TStrings2;
  TStrings2 = object (TCollection)
    constructor Init;
    destructor Done; virtual;
    procedure Add( AName: string ); virtual;
    procedure FreeItem(Item: Pointer); virtual;
  end;

  PStringAndCharItem = ^TStringAndCharItem;
  TStringAndCharItem = record
    s: PString;
    c: Char;
  end;

  PStringAndChar = ^TStringAndChar;
  TStringAndChar = object (TCollection)
    constructor Init;
    destructor Done; virtual;
    procedure Add( as: string; ac: Char ); virtual;
    procedure FreeItem(Item: Pointer); virtual;
  end;

  PStringAndChar2Item = ^TStringAndChar2Item;
  TStringAndChar2Item = record
    s: PString;
    c: Char;
    StringAndChar: PStringAndChar;
  end;

  PStringAndChar2 = ^TStringAndChar2;
  TStringAndChar2 = object (TCollection)
    constructor Init;
    destructor Done; virtual;
    procedure Add( as: string; ac: Char ); virtual;
    procedure FreeItem(Item: Pointer); virtual;
  end;


  PStringDequeItem = ^TStringDequeItem;
  TStringDequeItem = record
    Name: PString;
    Next: PStringDequeItem;
  end;

  TStringDeque = object (TObject)
    First, Last: PStringDequeItem;
    constructor Init;
    destructor Done; virtual;
    procedure Push( s: string ); { push to the end }
    function Pop: string;        { pop from the beginning }
    procedure Clear;
  end;

implementation

{ => TStrings }

constructor TStrings.Init;
begin
  inherited Init(0, 5);
end;

destructor TStrings.Done;
begin
  inherited Done;
end;

procedure TStrings.Add(s: string);
begin
  Insert(NewStr(s));
end;

procedure TStrings.FreeItem(Item: Pointer);
begin
  DisposeStr(Item);
end;

function TStrings.LoadFromFile( AFileName: string): Boolean;
var
  f: Text;
  s: string;
begin
  Assign(f, AFileName); FileMode := 0;
  {$I-} Reset(f); {$I+}
  if IOResult <> 0 then
    LoadFromFile := False
  else
    begin
      FreeAll;
      while not eof(f) do
        begin
          Readln(f, s);
          Add(s);
        end;
      Close(f);
      LoadFromFile := True;
    end;
end;

{ <= TStrings }

{ => TStrings2 }

constructor TStrings2.Init;
begin
  inherited Init(0, 5);
end;

destructor TStrings2.Done;
begin
  inherited Done;
end;

procedure TStrings2.Add( AName: string );
var
  item: PStrings2Item;
begin
  New(item);
  item^.Name := AName;
  item^.Strings := New(PStrings, Init);
  Insert(item);
end;

procedure TStrings2.FreeItem(Item: Pointer);
begin
  Dispose(PStrings2Item(item)^.Strings, Done);
  Dispose(PStrings2Item(Item));
end;

{ <= TStrings2 }

{ => TStringAndChar }
constructor TStringAndChar.Init;
begin
  inherited Init(0,5);
end;

destructor TStringAndChar.Done;
begin
  inherited Done;
end;

procedure TStringAndChar.Add( as: string; ac: Char );
var
  item: PStringAndCharItem;
begin
  New(Item);
  Item^.s := NewStr(as);
  Item^.c := ac;
  Insert(item);
end;

procedure TStringAndChar.FreeItem(Item: Pointer);
begin
  DisposeStr( PStringAndCharItem(Item)^.s );
  Dispose( PStringAndCharItem(Item) );
end;

{ <= TStringAndChar }

{ => TStringAndChar2 }

constructor TStringAndChar2.Init;
begin
  inherited Init(0,5);
end;

destructor TStringAndChar2.Done;
begin
  inherited Done;
end;

procedure TStringAndChar2.Add( as: string; ac: Char );
var
  item: PStringAndChar2Item;
begin
  New(Item);
  Item^.s := NewStr(as);
  Item^.c := ac;
  Item^.StringAndChar := New(PStringAndChar, Init);
  Insert(item);
end;

procedure TStringAndChar2.FreeItem(Item: Pointer);
begin
  DisposeStr( PStringAndChar2Item(Item)^.s );
  Dispose( PStringAndChar2Item(Item)^.StringAndChar, Done );
  Dispose( PStringAndChar2Item(Item) );
end;

{ <= TStringAndChar2 }

{ => TStringDeque }

constructor TStringDeque.Init;
begin
  inherited Init;
end;

destructor TStringDeque.Done;
begin
  Clear;
  inherited Done;
end;

procedure TStringDeque.Push( s: string ); { push to the end }
var
  tmp: PStringDequeItem;
begin
  if First = nil then
    begin
      New(First);
      First^.Name := NewStr(s);
      First^.Next := nil;
      Last := First;
    end
  else
    begin
      New(tmp);
      tmp^.Name := NewStr(s);
      tmp^.Next := nil;
      Last^.Next := tmp;
      Last := tmp;
    end;
end;

function TStringDeque.Pop: string;        { pop from the beginning }
var
  tmp: PStringDequeItem;
begin
  if (First = nil) then
    Pop := ''
  else
    begin
      if First^.Name = nil then
        Pop := ''
      else
        begin
          Pop := First^.Name^;
          DisposeStr(First^.Name);
        end;
      tmp := First^.Next;
      Dispose(First);
      First := tmp;
    end;
end;

procedure TStringDeque.Clear;
begin
  while First <> nil do
    Pop;
end;

{ <= TStringDeque }

end.
