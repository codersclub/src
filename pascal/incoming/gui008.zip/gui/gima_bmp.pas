{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    BMP file format support unit.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}

unit gIma_bmp;

interface

uses
  Objects,
  gImages,
  gDrivers;

type
  TBitmapHeader =
    packed record
      ID    : Word;     { 'BM' }
      FSize : LongInt;  { ������ 䠩�� }
      Ver   : LongInt;  { BMP version (?), currently 0 }
      Image : LongInt;  { Offset of image into file }
      Misc  : LongInt;  { Unknown, appears to be 40 for all files }
      Width : LongInt;  { Width of image }
      Height: LongInt;  { Height of image }
      Num   : Word;     { Not sure, possibly number of images or planes (1) }
      Bits  : Word;     { Number of bits per pixel }
      Comp  : LongInt;  { Type of compression, 0 for uncompressed, 1,2 for RLE }
      ISize : LongInt;  { Size of image in bytes }
      XRes  : LongInt;  { X dots per metre (not inches! for US, unbelievable!) }
      YRes  : LongInt;  { Y dots per metre }
      PSize : LongInt;  { Palette size (number of colours) if not zero }
      Res   : LongInt;  { Probably reserved, currently 0 }
    end;  { 54 bytes }

  PBmpReader = ^TBmpReader;
  TBmpReader = object (TImageReader)
  private
    Align: Byte;
    Header: TBitmapHeader;
    BytesPerLine: LongInt;
  public
    constructor Init(var Asrc: PStream);
    destructor Done; virtual;
    procedure LoadToCanvas(var Canvas: PCanvas; AX, AY: Integer); virtual;
  end;

  PBmpWriter = ^TBmpWriter;
  TBmpWriter = object(TImageWriter)
    constructor Init(var Adst: PStream);
    destructor Done; virtual;
    procedure SaveFromCanvas(var Canvas: PCanvas; AX, AY, BX, BY: Integer); virtual;
  end;

  procedure GrabScreenToBMP(FileName: string);

implementation

{ => TBmpReader }

constructor TBmpReader.Init(var Asrc: PStream);

  procedure SetPSize;
  {��⠭�������� �㦭� ࠧ��� �������}
  begin
    if Header.PSize=0
      then
      case Header.bits of
      1 : Header.PSize:=2;  { These are the only valid bits in a BMP }
      4 : Header.PSize:=16;
      8 : Header.PSize:=256;
      24: Header.PSize:=0;  { � 24-����� ��㭪�� ��� ������� }
      else Status := ST_FORMAT_ERROR;
      end;
  end;

  procedure ReadPalette;
  var
    i: Byte;
  begin
    if Header.PSize<>0
      then begin
        src^.Seek(startpos + SizeOf(Header));
        for i:=0 to Header.PSize-1 do begin
          src^.Read(Palette.PalEntry^[i].Blue,1);
          src^.Read(Palette.PalEntry^[i].Green,1);
          src^.Read(Palette.PalEntry^[i].Red,1);
          src^.Seek(src^.GetPos+1);
        end;
      end;
  end;

begin
  inherited Init(Asrc);
  Status := ST_OK;

  if src^.Status <> ST_OK
    then begin Status := src^.Status; Exit end;

  src^.Read(Header,SizeOf(Header));
  if (Header.ID<>19778) or
     (not (Header.Comp in [0,1,2])) or
     (not (Header.Bits in [1,4,8,16,24]))
     then begin Status := ST_HEADER_ERROR; Exit; end;

  SetPSize;
  SetImageInfo(Header.Width,Header.Height,Header.Bits,Header.PSize);
  ReadPalette;

  if Status<>0 then Exit;

  {�����뢠��, ᪮�쪮 ����஢������ ���⮢ ���� �� ��ப� ��㭪�}
  Case Header.Bits of
    1: BytesPerLine:=((header.Width+7) div 8);
    4: BytesPerLine:=((header.Width+1) div 2)*2;
    8: BytesPerLine:=(header.width);
   16: BytesPerLine:=header.width*2;
   24: BytesPerLine:=header.width*3;
  End; {Case}

  {��室��, ᪮�쪮 ���⮢ ���� ��������, �⮡� ��஢����}
    Align:=4-(BytesPerLine mod 4);
    if Align=4 then Align:=0;
end;

destructor TBmpReader.Done;
begin
  inherited Done;
end;

procedure TBmpReader.LoadToCanvas(var Canvas: PCanvas; AX, AY: Integer);

var
  memptr: Pointer;
  memsize: Sw_Word;

  function ByteHi(b: Byte): Byte; { ���孨� 4 ��� }
  begin
    ByteHi:=b shr 4;
  end;

  function ByteLo(b: Byte): Byte; { ������ 4 ��� }
  begin
    ByteLo:=b and 15;
  end;

  procedure Read2;
  var
    x,y: Integer;
    B: Byte;
    i: Byte;
    Color: Byte;
  begin
    for y:=Header.Height-1 downto 0 do Begin
      x:=0;
      repeat
        src^.Read(B,1);
        For i:=0 to 7 do Begin
          Color:=(B shl i) shr 7;
          with Palette.PalEntry^[Color and $01] do
            Canvas^.PutPixel(AX+x, AY+y,
              Canvas^.RGB(Red, Green, Blue));
          inc(x);
          If x>=Header.Width Then Break;
        End;
      until x>=Header.Width;

      src^.Seek(src^.GetPos+Align); { ��ࠢ������� }
    end;
  end;

  procedure Read16;
  var
    B: Byte;
    x,y: Integer;
    Color: Byte;
  Begin
      For y:=Header.Height-1 downto 0 do Begin
(*        for x:=0 to Header.Width div 2 do begin
          src^.Read(B,1);
          Color:=ByteHi(B);
          with Palette.PalEntry^[Color and $0F] do
            Canvas^.PutPixel(AX+2*x, AY+y,
              Canvas^.RGB(Red, Green, Blue));
          Color:=ByteLo(B);
          with Palette.PalEntry^[Color and $0F] do
            Canvas^.PutPixel(AX+2*x+1, AY+y,
              Canvas^.RGB(Red, Green, Blue));
        end;
        { ��᫥���� ���ᥫ�� � ��ப� }
        if Odd(Header.Width)
          then begin
            src^.Read(B,1);
            Color:=ByteHi(B);
            with Palette.PalEntry^[Color and $0F] do
              Canvas^.PutPixel(AX+Width-1, AY+y,
                Canvas^.RGB(Red, Green, Blue));
          end;*)
        src^.Read(memptr^, BytesPerLine);
        Convert4( Canvas^.BPP,
                  memptr,
                  Width,
                  Canvas^.RGB,
                  @Palette     );
        Canvas^.PutLine( AX, AY+y, Width, memptr^, SHOW_NORMAL );
        src^.Seek(src^.GetPos+Align); {��ࠢ�������}
      End;
  End; {Read16}

  Procedure Read256;
  Var
    Color: Byte; {���� ���ᥫ�}
    x,y: Integer;
  Begin
      For y:=(Header.Height-1) DownTo 0 do Begin
        src^.Read(memptr^, BytesPerLine);
        Convert8( Canvas^.BPP,
                  memptr,
                  Width,
                  Canvas^.RGB,
                  @Palette     );
        Canvas^.PutLine( AX, AY+y, Width, memptr^, SHOW_NORMAL );
{        For x:=0 To (Header.Width-1) do Begin
          src^.Read(Color,1);
          with Palette.PalEntry^[Color] do
            Canvas^.PutPixel(AX+x, AY+y,
              Canvas^.RGB(Red, Green, Blue));
        End;}
        src^.Seek(src^.GetPos+Align); {��ࠢ�������}
      End;
  End; {Read256}

  Procedure ReadComp16;
  var
    x,y: Integer;
    a,b: Byte;
    i: Integer;
    Color: Byte;
  Begin
    x:=0; y:=Header.Height-1;
    a:=0; b:=0;

    while (y<>0) and (x<Header.Width)
    do
      begin
        src^.Read(a,1); src^.Read(b,1);
        if a=0
          then begin { ESC-FLAG }
            case b of
            0: { END OF BMP-LINE }
              begin
                x:=0; dec(y);
              end;
            1: { END OF BMP PICTURE }
              Break;
            2: { Increase X and Y }
              begin
                src^.Read(a,1); src^.Read(b,1);
                x:=x+a; y:=y+b;
              end;
            else { B INDEPENDENT PIXELS }
              begin
                for i:=1 to b div 2 do begin
                  src^.Read(Color,1);
                  with Palette.PalEntry^[ByteHi(Color)] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                  inc(x);
                  with Palette.PalEntry^[ByteLo(Color)] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                  inc(x);
                end;
                if odd(b) then begin
                  src^.Read(Color,1);
                  with Palette.PalEntry^[ByteHi(Color)] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                  inc(x);
                end;
                if x>=Header.Width then begin
                  x:=0; Dec(y);
                end;
                src^.Seek(src^.GetPos+Align);
              end;
            end; { CASE }
          end
          else begin { SOME EQUAL PIXELS }
            for i:=0 to a-1 do
              if odd(i)
                then begin
                  Color := ByteLo(B);
                  with Palette.PalEntry^[Color] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                end
                else begin
                  Color:=ByteHi(B);
                  with Palette.PalEntry^[Color] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                end;
            x:=x+a;
            if x>=Header.Width
              then begin x:=0; Dec(y); end;
          end;
      end;
  End;

  Procedure ReadComp256;
  var
    x,y: Integer;
    a,b: Byte;
    dx,dy: Byte;
    Color: Byte;
    i: Integer;
  Begin
    x:=0; y:=Header.Height-1;
    a:=0; b:=0;

    repeat
        src^.Read(a,1); src^.Read(b,1);
        if a=0
          then begin { ESC-FLAG }
            case b of
            0: { END OF BMP-LINE }
              begin
                x:=0; dec(y);
              end;
            1: { END OF BMP PICTURE }
              Break;
            2: { Increase X and Y }
              begin
                src^.Read(dx,1); src^.Read(dy,1);
                x:=x+dx; y:=y-dy;
              end;
            else { B INDEPENDENT PIXELS }
              begin
                for i:=1 to b do begin
                  src^.Read(Color,1);
                  with Palette.PalEntry^[Color] do
                    Canvas^.PutPixel(AX+x, AY+y,
                      Canvas^.RGB(Red, Green, Blue));
                  if x>=Header.Width then begin
                    x:=0; Dec(y);
                  end
                  else inc(x);
                end;
                if odd(b) then src^.Seek(src^.GetPos+1);
              end;
            end; { CASE }
          end
          else begin { SOME EQUAL PIXELS }
            for i:=1 to a do begin
              with Palette.PalEntry^[B] do
                Canvas^.PutPixel(AX+x, AY+y,
                  Canvas^.RGB(Red, Green, Blue));
              if x>=Header.Width
                then begin x:=0; Dec(y); end
                else inc(x);
            end;
          end;
    until (src^.Status <> ST_OK);
  End;

  Procedure Read64K;
  Var
    x,y: Integer;
    w: Word;
    RGB: TRGB;
  Begin

    For y:=(Header.Height-1) DownTo 0 do begin
{      For x:=0 To (Header.Width-1) do begin
        src^.Read(w,2);
        Canvas^.DeRGB(w, RGB.Red, RGB.Green, RGB.Blue);
        Canvas^.PutPixel(AX+x, AY+y,
          Canvas^.RGB(RGB.Red, RGB.Green, RGB.Blue));
      end;}
      src^.Read(memptr^, BytesPerLine);
      Convert16( Canvas^.BPP,
                 memptr,
                 Width,
                 Canvas^.RGB  );
      Canvas^.PutLine(AX, AY+y, Width, memptr^, SHOW_NORMAL);
      src^.Seek(src^.GetPos+Align); {��ࠢ�������}
    End;
  End;

  Procedure Read16M;
  Var
    x,y: Integer;
    RGB: TRGB;
  Begin
    For y:=(Header.Height-1) DownTo 0 do begin
      src^.Read(memptr^, BytesPerLine);
      { BGR -> RGB }
      Convert24BGR( Canvas^.BPP,
                    memptr,
                    Width,
                    Canvas^.RGB );
      Canvas^.PutLine( AX, AY+y, Width, memptr^, SHOW_NORMAL );

{      For x:=0 To (Header.Width-1) do begin
        src^.read(RGB.Blue,1); src^.read(RGB.Green,1); src^.read(RGB.Red,1);
        Canvas^.PutPixel(AX+x, AY+y,
          Canvas^.RGB(RGB.Red, RGB.Green, RGB.Blue));
      end;}

      src^.Seek(src^.GetPos+Align); {��ࠢ�������}
    End;
  End;

begin
  { Reading image... }
  src^.Seek(startpos + Header.Image);
    {��९������ � ��砫� ᠬ��� ��㭪� � 䠩��}

  memsize := Width*Canvas^.BytesPerPixel;
  if BytesPerLine > memsize then
    memsize := BytesPerLine;

  GetMem( memptr, memsize );
  If Header.Comp<>0 Then
    Case Header.Bits of {����� ��㭪�}
      4 : ReadComp16;
      8 : ReadComp256;
      else Status:=ST_FORMAT_ERROR;
    End
    else
    Case Header.Bits of {�� ᦠ�� ��㭪�}
      1  : Read2;
      4  : Read16;
      8  : Read256;
      16 : Read64K;
      24 : Read16M;
      else Status:=ST_FORMAT_ERROR;
    End; {Case}

  if Status = 0 then Status := src^.Status;

  FreeMem( memptr, memsize );
end;
{ <= TBmpReader }

{ => TBmpWriter }
constructor TBmpWriter.Init(var Adst: PStream);
begin
  inherited Init(Adst);
end;

destructor TBmpWriter.Done;
begin
  inherited Done;
end;

procedure TBmpWriter.SaveFromCanvas(var Canvas: PCanvas; AX, AY, BX, BY: Integer);
var
  Header: TBitmapHeader;
  Align: LongInt;
  x,y: Integer;
  RGB: TRGB;
  BytesPerLine: LongInt;
  memptr: Pointer;
begin
  FillChar(Header, SizeOf(Header), 0);
  Status := ST_OK;
  with Header do
    begin
      ID := 19778;
      Image := SizeOf(Header);
      Misc := 40;
      Width := BX-AX+1;
      Height := BY-AY+1;
  BytesPerLine := Width*3;
      Num := 1;
      Bits := 24;
        Align := BytesPerLine;
        Align := Align - (Align div 4)*4;
      ISize := (BytesPerLine+Align)*Height;
      FSize := SizeOf(Header) + ISize;
    end;
  dst^.Write(Header, SizeOf(Header));

  GetMem(memptr, BytesPerLine);
  { Writing 24-bit bitmap }
    For y:=(Header.Height-1) DownTo 0 do begin
      Canvas^.GetLine( AX, AY+y, Header.Width, memptr^ );

      { BGR -> RGB }
      Convert( Canvas^.BPP, 24, memptr, Header.Width,
        {$ifdef fpc}@{$endif}img_rgb_24, nil);
(*      Convert( 23, 24, memptr, Header.Width,
        {$ifdef fpc}@{$endif}img_rgb_24, nil);*)

(*      Convert24BGR( Canvas^.BPP,
                    memptr,
                    Header.Width,
                    {$ifdef fpc}@{$endif}img_rgb_24 );*)

      dst^.Write(memptr^, BytesPerLine);

      dst^.Seek(dst^.GetPos+Align); {��ࠢ�������}
    End;
  FreeMem(memptr, BytesPerLine);
  Status := dst^.Status;
end;
{ <= TBmpWriter }

procedure GrabScreenToBMP(FileName: string);
var
  W: PBmpWriter;
  S: PBufStream;
begin
  S := New(PBufStream, Init(FileName, stOpenWrite, 512));
  W := New(PBmpWriter, Init(PStream(S)));
  W^.SaveFromCanvas(Screen, 0, 0, Screen^.Width-1, Screen^.Height-1);
  Dispose(W, Done);
  Dispose(S, Done);
end;

end.
