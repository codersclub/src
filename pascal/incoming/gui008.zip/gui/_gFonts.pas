{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    A test program for unit gFonts.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
program Test_gImages;

uses
  Objects,
  gFonts,
  gDrivers
{$ifdef fpc},
  gGraph
{$else},
  gGrafX
{$endif};

var
  StartMem, FinishMem: LongInt;
  x, y: Integer; butt: Byte;
begin
  StartMem := MemAvail;

  {$ifdef fpc}
  Screen := New(PGraphDriver, Init(640, 480, 4));
  Mouse := New(PGraphMouseDriver, Init);
  {$else}
  Screen := New(PGrafxDriver, Init(640, 480, 4));
  Mouse := New(PGrafxMouseDriver, Init);
  {$endif}
  Mouse^.Show;
  Mouse^.SetCursor(2);

  Font := New(PTrueTypeFont, Init('tahoma.ttf'));
  Font^.SetSize(25);
  Font^.OutText(Screen, 100, 100, 'Hello', White);
  repeat
    Mouse^.GetState(x, y, Butt);
  until KeyPressed;
  ReadKey;
  Dispose(Font, Done);

  Dispose(Mouse, Done);
  Dispose(Screen, Done);
  FinishMem := MemAvail;
  Writeln;
  Writeln('Memory check: ', StartMem, ' ', FinishMem);
end.
