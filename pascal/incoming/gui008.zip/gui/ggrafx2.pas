{
  GrafX2 driver for GUI. Only DPMI.
  Copyright (c) 2002 Sergey Kozlovich.
  Library GrafX 1.4 - Copyright (c)  Stefan Goehler, Germany.
  Compatible: BP (GrafX2 is only BP DPMI compatible).
}
unit gGrafX2;

interface

uses
  Objects,
  gDrivers,
  gImages,
  GrafX2,
  gx_glob,
  mouselib;

type
  PGrafX2 = ^TGrafX2;
  TGrafX2 = object(TScreenDriver)
    screen               : tgxscreen;
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;
    procedure InitColors; virtual;
    procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
    function GetPixel(AX, AY: Integer): LongInt; virtual;
    procedure HLine(AX, AY, BX: Integer; AColor: LongInt); virtual;
    procedure VLine(AX, AY, BY: Integer; AColor: LongInt); virtual;
    procedure Line(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
    procedure SetWriteMode(AWriteMode: Integer); virtual;

    procedure SetRGB(AColor: LongInt; r, g, b: Byte);
    procedure GetRGB(AColor: LongInt; var r, g, b: Byte);
    procedure SetPalette(Palette: Pointer; PaletteSize: Word);
  end;

  PGrafX2Mouse = ^TGrafX2Mouse;
  TGrafX2Mouse = object (TMouseDriver)
    mouse  : tmouse;
    constructor Init;
    destructor Done; virtual;
    procedure GetState(var _x,_y: Integer; var _butt: Byte); virtual;
    procedure SetPos(_x,_y: Integer); virtual;
    procedure SetArea(x1,y1,x2,y2: Integer); virtual;
    procedure Show; virtual;
    procedure Hide; virtual;
    procedure NotMove; virtual;
    procedure LetMove; virtual;
    procedure SetCursor( _Cursor: gDrivers.TCursor ); virtual;
  end;

implementation

{ ===> TGrafX2 }
constructor TGrafX2.Init(AWidth, AHeight: Integer; ABPP: Word);

  procedure SetPalette256;
  var
    i: Integer;
    r, g, b: Byte;
  begin
    for i := 16 to 231 do
      begin
        img_dergb_8(i, r, g, b);
        SetRGB(i, r, g, b);
      end;
{    screen.setpal;}
  end;

begin
  inherited Init(AWidth, AHeight, ABPP);

  if not screen.init(AWidth,AHeight,ABPP,mdauto) then
    Status := -1;
  if Status<>0 then
    Exit;

  if BPP=8 then begin
    SetPalette256;
    Screen.RGB := rgb_8;
  end;
  InitColors;
end;

procedure TGrafX2.InitColors;
begin
  inherited InitColors;
end;

procedure TGrafX2.PutPixel(AX, AY: Integer; AColor: LongInt);
begin
  Screen.PutPixel(AX, AY, AColor);
end;

function TGrafX2.GetPixel(AX, AY: Integer): LongInt;
begin
  GetPixel:=Screen.GetPixel(AX, AY) and (LongInt(1) shl BPP - 1);
end;

procedure TGrafX2.HLine(AX, AY, BX: Integer; AColor: LongInt);
begin
  Line(AX, AY, BX, AY, AColor);
end;

procedure TGrafX2.VLine(AX, AY, BY: Integer; AColor: LongInt);
begin
  Line(AX, AY, AX, BY, AColor);
end;

procedure TGrafX2.SetRGB(AColor: LongInt; r, g, b: Byte);
begin
{  Screen.setrgbpal(AColor, r, g, b);}
end;

procedure TGrafX2.GetRGB(AColor: LongInt; var r, g, b: Byte);
begin
{  grafx.getrgbpal(AColor, r, g, b);}
end;

procedure TGrafX2.SetPalette(Palette: Pointer; PaletteSize: Word);
begin
{  Move(Palette^,Gr_Vars.Pal^,PaletteSize*3);
  grafx.setpal;}
end;

procedure TGrafX2.SetWriteMode(AWriteMode: Integer);
begin
{  Screen.SetWriteMode(AWriteMode);}
end;

procedure TGrafX2.Line(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Screen.Line(AX, AY, BX, BY, AColor, 0);
end;

procedure TGrafX2.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
begin
  inherited PutLine(AX, AY, ASize, ALine, AFlags);
end;

procedure TGrafX2.Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Screen.Rect(AX, AY, BX, BY, AColor, 0);
end;

procedure TGrafX2.DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  inherited DottedRectangle(AX, AY, BX, BY, AColor);
end;

procedure TGrafX2.Bar(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  Screen.FillRect(AX, AY, BX, BY, AColor, 0);
end;

procedure TGrafX2.SetViewPort(AX, AY, BX, BY: Integer);
begin
  inherited SetViewPort(AX, AY, BX, BY);
end;

destructor TGrafX2.Done;
begin
  if Status = stOk then
    Screen.Close;
end;
{ <=== TGrafX }

{ => TGrafX2Mouse }
constructor TGrafX2Mouse.Init;
begin
  inherited Init;
  IsMouse := True;
  mouse.init(PGrafx2(screen)^.screen,0);
  Hide;
  mouse.Hide;
  Visible := False;
  SetPos(Screen^.Width div 2, Screen^.Height div 2);
end;

procedure TGrafX2Mouse.GetState(var _x,_y: Integer; var _butt: Byte);
var
  v_event: tmouseevent;
begin
  mouse.getevent(v_event);
  _x:=v_event.where.x;
  _y:=v_event.where.y;
  _butt:=v_event.buttons;
  SetPos(_x, _y);
end;

procedure TGrafX2Mouse.SetPos(_x,_y: Integer);
begin
  if not IsMouse then Exit;
  if Visible
    then begin
{      Hide;}
      inherited SetPos(_x,_y);
      Mouse.SetPos(_x,_y);
{      Show;  }
    end
    else begin
      inherited SetPos(_x,_y);
      Mouse.SetPos(_x,_y);
    end;
end;

procedure TGrafX2Mouse.SetArea(x1,y1,x2,y2: Integer);
begin
  Mouse.SetWindow(x1,y1,x2,y2);
end;

procedure TGrafX2Mouse.Show;
begin
  inherited Show;
{  Mouse.Show;}
  Visible := True;
end;

procedure TGrafX2Mouse.Hide;
begin
  inherited Hide;
{  Mouse.Hide;}
  Visible := False;
end;

procedure TGrafX2Mouse.NotMove;
begin
  Mouse.Freeze;
end;

procedure TGrafX2Mouse.LetMove;
begin
  Mouse.UnFreeze;
end;

procedure TGrafX2Mouse.SetCursor( _Cursor: gDrivers.TCursor );
begin
  inherited SetCursor( _Cursor );
{  if not IsMouse then Exit;
  inherited SetCursor( _Cursor );}
{  MouseDr7.ChangeCursor( _Cursor+1 );}
end;

destructor TGrafX2Mouse.Done;
begin
  mouse.done;
  inherited Done;
end;
{ <= TGrafX2Mouse }

end.
