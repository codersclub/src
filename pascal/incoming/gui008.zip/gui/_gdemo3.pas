{
    $Id: gplprog.pt,v 1.1 2001/08/04 11:30:24 peter Exp 2003/02/25 19:58:44 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    GUI demonstration program #3.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
Program GUIDemo3;
{$define DEBUG}
{$define THEME}
{ $define SCREENSHOT}
uses
  {$ifdef SCREENSHOT}
  gIma_bmp,
  {$endif}
  qSystem,
  gInit,
  gDrivers,
  gThemes,
  gStandartItems,
  gWin32Items;

var
  ProgressBar: PProgressBar;

{$ifdef DEBUG}
var
  StartMem: LongInt;
{$endif}

type
  PMyForm = ^TMyForm;
  TMyForm = object (TForm)
    procedure Idle; virtual;
    destructor Done; virtual;
  end;

const
  OldTimer: LongInt = 0;

  procedure TMyForm.Idle;
  var
    x: LongInt;
  begin
    x := GetSysTimer;
    if x <> OldTimer then begin
      OldTimer := x;
      if ProgressBar^.Position = 100 then CloseModal;
      ProgressBar^.SetPosition( ProgressBar^.Position + 1 );
    end;
  end;

  destructor TMyForm.Done;
  begin
    inherited Done;
  end;


var
  Form: PForm;
  Button: PButton;
  ID: Integer;

begin

{ === GUI INITIALIZATION === }
{$ifdef DEBUG}
  StartMem := MemAvail;
{$endif}
  InitGUI(640,480,16);
{ === GUI WORK === }

  Form := New(PMyForm,Init(100,100,400,100,'TProgressBar demo',not False,Drag_Rectangle));
  ProgressBar:=New(PProgressBar, Init( 50, 30,300,20 ) );
  Form^.Insert( ProgressBar );
  Form^.Insert( New(PButton,Init(160,70,80,23,'Close',20)) );
  Form^.ShowModal;
  Dispose(Form,Done);

{$ifdef THEME}
  SetDefaultTheme( LoadTheme('linux.thm') ); { <= specify theme directory here }
{$endif}

  Form:=New(PForm,Init(100,100,400,100,'And now: in Russian! � ⥯���: ��-���᪨!',
    True,{DragShow}Drag_Rectangle));

  Form^.Insert(New(PLabel,Init(20,40,350,20,'���� �� �� ���ଠ�஢��� ��� ���⪨� ���?')));

  Button:=New(PButton,Init(40,60,75,23,'&OK',10));
  Button^.Default:=True;

  Form^.Insert(Button);

  Button:=New(PButton,Init(130,60,75,23,'����筮!',20));
  Button^.Cancel:=True;

  Form^.Insert(Button);

  ID := Form^.ShowModal;
  {$ifdef SCREENSHOT}
    Form^.Show(Screen, 0, 0);
    GrabScreenToBMP('scrshot3.bmp');
    Form^.Hide(Screen, 0, 0);
  {$endif}

  Dispose(Form, Done);

{$ifdef THEME}
  UnLoadTheme(DefaultTheme);
{$endif}

{ === GUI FINALIZATION === }
  DoneGUI;
{$ifdef DEBUG}
  Writeln;
  Writeln('Memory check: ', StartMem, ' ', MemAvail);
{$endif}
  Writeln('Pressed dialog item: ',ID);
end.
