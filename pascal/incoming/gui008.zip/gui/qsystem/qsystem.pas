{
UNIT:
  qsystem
VERSION:
  1.0 (JUNE, 2003)
DESCRIPTION:
  Unit containing useful routines that can be used to write
  cross-platform programs in PASCAL (and maybe, converting them
  to C++ easily when the ported version in C++ will arrive)
LANGUAGE:
  PASCAL (may be ported version in C++ will be available soon)
COMPILERS:
  Borland (Turbo) Pascal 7.0 (REAL and DPMI)
  FreePascal 1.0.6
  Virtual Pascal 2.1
AUTHOR:
  [EN] Copyright (c) Sergey Kozlovich, 2002-2003
  [LV-DOS] Autorties�bas (c) Sergejs Kozlovi�s, 2002-2003
  [RU-CP866] ����᪮� �ࠢ� (c) ��ࣥ� ��������, 2002-2003
  e-mail:
    sergey_kozlovich@REMOVE_THIShotmail.com
    kozlovich@acm.org
LICENCE:
  GNU GPL
  (if you change something and these changes are good, please
   inform me)
TODO:
  PChar routines with ignoring nil pointers
  GetMem and FreeMem
  New returning nil when there is no memory
  Dispose(nil)
  ??? wide char routines           (separate unit)
  ??? program translation routines (separate unit)
  ReadKey/Keypressed/ScanCode
}
{$i platform.inc}        { we are using this include for
                           platform-independent programming using ifdefs }

{$define TMEMORYSTREAM}  { if you want to try getting mem by TMemoryStream }
{$ifndef DPMI}
  {$ifdef OS_DOS}
    {$define TXMSSTREAM} { if you want to try getting mem by TXMSStream }
  {$endif}
{$endif}
{$define TBUFSTREAM}     { if you want to try getting mem by TBufStream }

unit qsystem;

interface

uses
  Objects,
{$ifdef TXMSSTREAM}
  xstream, { in xms/xstream.pas }
{$endif}
  DOS;

{ some basic types - from Thomas Schatzl (tom_at_work@yline.com)
  file BASETYPE.PAS; corrected to work under BP }
type
        Int8 = System.ShortInt;
        {$IFDEF PPC_BP}
        Int16 = System.Integer;
        {$ELSE}
        Int16 = System.SmallInt;
        {$ENDIF}
        Int32 = System.Longint;
        Int64 = System.Comp;

        UInt8 = System.Byte;
        UInt16 = System.Word;
        {$IFDEF PPC_BP}
        UInt32 = Int32;
        {$else}
        UInt32 = Cardinal;
        {$ENDIF}
        {$IFDEF PPC_FPC}
        UInt64 = QWord;
        {$ELSE}
          {$IFDEF PPC_BP}
          UInt64 = Int64;
          {$else}
          UInt64 = Int64;
          {$ENDIF}
        {$ENDIF}

        Float32 = System.Single;
        Float64 = System.Double;
        Float80 = System.Extended;

        Bool8 = System.Boolean;
        Bool16 = System.WordBool;
        Bool32 = System.LongBool;

{ pointers to all these }
        PUInt8 = ^UInt8;
        PUInt16 = ^UInt16;
        PUInt32 = ^UInt32;
        PUInt64 = ^UInt64;

        PInt8 = ^Int8;
        PInt16 = ^Int16;
        PInt32 = ^Int32;
        PInt64 = ^Int64;

        PFloat32 = ^Float32;
        PFloat64 = ^Float64;
        PFloat80 = ^Float80;

        PBool8 = ^Bool8;
        PBool16 = ^Bool16;
        PBool32 = ^Bool32;

type
{$ifdef PPC_BP}
  size_t = UInt16;
{$else}
  {$ifdef PPC_FPC}
  size_t = Sw_Word;
  {$else}
  size_t = Int32;
  {$endif}
{$endif}
  BOOL = Bool8;
  BYTE = UInt8;
  PBYTE = ^BYTE;
  CHAR = System.Char;
  PCHAR = System.PChar;
  WORD = UInt16;
  PWORD = ^WORD;
  DWORD = UInt32;
  PDWORD = ^DWORD;
  INT = Int32;
  PINT = ^INT;
  PTR = System.Pointer;
  HANDLE = UInt32;
  THandle = HANDLE;

{$ifdef PPC_DELPHI}
var
{$else}
const
{$endif}
  QError: INT = 0;

{ => Debug routines }
function  DebugOn(FileName: string): BOOL;
function  DebugOff: BOOL;
procedure DebugOut(s: string);
{ <= Debug routines }

{ => File and directory routines }

{$ifdef OS_Linux}
const
  PathDelim = '/';
  DriveDelim = '';
  PathSep = ':';
{$else}
const
  PathDelim = '\';
  DriveDelim = ':';
  PathSep = ';';
{$endif}
  DirectorySeparator = PathDelim;
  Slash = PathDelim;
var
  TempDir: string;

function  GetTemporaryDirectory: string;
function  GetProgramDirectory: string;
function  GetProgramName: string;
procedure AddEndSlash(var s: string);
procedure RemoveEndSlash(var s: string);

function  FileExists(s: string): BOOL;
function  DirectoryExists(s: string): BOOL;
function  FileLength(s: string): INT;

function  ExtractFileDrive(s: string): string;
function  ExtractFileDir(s: string): string;
function  ExtractFileName(s: string): string;
function  ExpandFileName(s: string): string;
function  EqualFileNames(s,t: string): BOOL;
function  MoveFile(s,t: string): BOOL;
     {
       Moves or renames a file.
     }
{  function  WildFileName(s,w: string): string; mask }
function  MoveDirectory( src, dst: string ): BOOL;

function  CopyFile(s,t: string): BOOL;
function  DeleteFile(s: string): BOOL;
function  DeleteDirectory(s: string): BOOL;
  {
     recursively
  }
function  CompareFiles(s1,s2: string): BOOL;
function  ConcatFiles(s1,s2,t: string): BOOL;
function  ForceDirectories(s: string): BOOL;

function  ReplaceDirectorySeparators(s: string): string;

{ <= File and directory routines }

{ => Memory routines }

{ bit routines }
procedure SetBit( var BitArray; BitNum: size_t );
procedure ClearBit( var BitArray; BitNum: size_t );
function  TestBit( var BitArray; BitNum: size_t ): BOOL;
    {
    Bit-operations with the static variable.

    (bit #0 is at the right of each byte: 00000001b)

    In each byte of <BitArray> the i-th bit means 2^i, where 0<=i<=7
      e.g.
      uses gMemory;
      var
        w: Word;
      begin
        w := 0;
        SetBit(w,15);
        Writeln(w);  // Outputs 32768
        w := 0;
        SetBit(w, 0);
        Writeln(w);  // Outputs 1
      end.
    }

procedure SetBitAt( p: PTR; BitNum: WORD );
procedure ClearBitAt( p: PTR; BitNum: WORD );
function  TestBitAt( p: PTR; BitNum: WORD ): BOOL;
    {
    Bit-operations with the memory at address p.

    (bit #0 is at the left of each byte: 10000000b)

    In each byte of memory at address <p> the
      i-th bit means 2^(7-i), where 0<=i<=7
    e.g.
      uses gMemory;
      var
        w: ^Word;
      begin
        New(w);
        w^ := 0;
        SetBitAt(w,15); // we pass the address w as the parameter
        Writeln(w^);    // Outputs 256
        w^ := 0;
        SetBitAt(w, 7);
        Writeln(w^);    // Outputs 1
      end.
    }

{ routines for converting pointers }
function  AddrToPtr( Abs: INT ): PTR;
function  PtrToAddr( p: PTR ): INT;

function  SegA( adr: INT ): WORD;
function  OfsA( adr: INT ): WORD;
function  SegP( p: PTR ): WORD;
    {
      equal to Seg(p^)
    }
function  OfsP( p: PTR ): WORD;
    {
      equal to Ofs(p^)
    }

function  _Ptr( Seg, Ofs: WORD ): PTR;

{ routines for accessing memory }
procedure FillCharAt( p: PTR; Count: size_t; Value: BYTE);
{$ifdef PPC_FPC}
procedure FillCharAt( p: PTR; Count: size_t; Value: CHAR);
{$endif}
function  NextBytePtr( p: PTR ): PBYTE;
function  NextWordPtr( p: PTR ): PWORD;
function  NextDWordPtr( p: PTR ): PDWORD;
function  NextPtr( p: PTR; Shift: size_t ): PTR;

{ next routines may be slow and without direct access to memory }
type
  PPointerStream = ^TPointerStream;
  TPointerStream = object (TStream)
    p: PTR;
    size: INT;
    pos: INT;
    NeedsToFreeMem: BOOL;
    constructor Init( Ap: PTR; Asize: INT );
    destructor Done; virtual;
    function GetPos: INT; virtual;
    function GetSize: INT; virtual;
    procedure Read(var what; cnt: size_t); virtual;
    procedure Write(var what; cnt: size_t); virtual;
    procedure Seek(_pos: INT); virtual;
  end;

function  MAllocate( Size: INT ): HANDLE;
    {
      Allocates memory and returns handle.
      Handle is an address of TStream.
      Use MFree to free memory and MRead/MWrite/MSeek to access memory.
    }
function  MPointer( p: PTR; Size: size_t ): HANDLE;
    {
      MPointer is used to create a stream object representing
      data in memory at address p.
      Use MFree to destroy stream object
      and MRead/MWrite/MSeek to access memory
      Memory at address p is not allocated/disposed.
    }
procedure MFree( var h: HANDLE );
function  MByteAt( var h: HANDLE; Shift: INT ): BYTE;
function  MWordAt( var h: HANDLE; Shift: INT ): WORD;
function  MDWordAt( var h: HANDLE; Shift: INT ): DWORD;
function  MSeek( var h: HANDLE; Position: INT ): BOOL;
function  MRead( var h: HANDLE; var Dest; Size: INT ): BOOL;
function  MWrite( var h: HANDLE; var What; Size: INT ): BOOL;

{ <= Memory routines }

{ => Misc }

function  Trim(s: string): string;
function  IntToStr(i: INT): string;
function  StrToInt(s: string): INT;
function  GetSysTimer: DWORD;
    {
      Returns DOS-ticks. This value is changed ~18.2 times per second.
    }


type
  UpCaseFunc = function(c: CHAR): CHAR;
  LoCaseFunc = UpCaseFunc;

function  _UpCase(c: CHAR): CHAR;
function  _LoCase(c: CHAR): CHAR;

const
  UpCase: UpCaseFunc = {$ifdef PPC_FPC}@{$endif}_UpCase;
  LoCase: LoCaseFunc = {$ifdef PPC_FPC}@{$endif}_LoCase;

function  UpperCase(s: string): string;
function  LowerCase(s: string): string;

function  Min(a, b: INT): INT;
function  Max(a, b: INT): INT;
function  Sign(i: INT): INT;
function  Signum(i: INT): INT;

{$ifdef PPC_BP}
  procedure WarmBoot;
  procedure ColdBoot;
{$endif}

{$ifdef PROC_REAL}
type
  PathStr = DOS.PathStr;
  Str127 = string[127];
function ExecuteProgram(Name: PathStr; Tail: Str127): WORD;
    {
      Gives all free memory from the heap to the called program.
    }
{$else}
function ExecuteProgram(Name, Tail: string): WORD;
{$endif}

{ <= Misc }

implementation
{$ifdef PPC_FPC}
uses
  Objects2
  {$ifdef OS_LINUX}
  , Linux
  {$endif}
  ;
{$endif}

{ => Debug routines }
var
  isDebug: BOOL;
  fDebug: Text;

function  DebugOn(FileName: string): BOOL;
begin
  if isDebug then
    DebugOff;
  Assign(fDebug, FileName);
  {$I-}
  FileMode := 1;
  Rewrite(fDebug);
  {$I+}
  isDebug := IOResult = 0;
  DebugOn := isDebug;
end;

function  DebugOff: BOOL;
begin
  if not isDebug then
    Exit;
  {$I-}
  Close(fDebug);
  {$I+}
  isDebug := IOResult <> 0;
  DebugOff := not isDebug;
end;

procedure DebugOut(s: string);
begin
  if isDebug then
  {$I-}
  begin
    Writeln(fDebug, s);
    Flush(fDebug);
  end;
  {$I+}
end;

{ <= Debug routines }

{ => File and directory routines }

function  GetTemporaryDirectory: string;
var
  TempDir: string;
begin
  TempDir:=GetEnv('TEMP');
  if TempDir='' then TempDir:=GetEnv('TMP');
  if TempDir<>'' then begin
    if not DirectoryExists(TempDir)
      then ForceDirectories(TempDir);
    if not DirectoryExists(TempDir)
      then TempDir:='';
  end;
  AddEndSlash(TempDir);
  GetTemporaryDirectory := TempDir;
end;

function  GetProgramDirectory: string;
begin
  GetProgramDirectory := ExtractFileDir(ParamStr(0));
end;

function  GetProgramName: string;
begin
  GetProgramName := ExtractFileName(ParamStr(0));
end;

procedure AddEndSlash(var s: string);
begin
  if (s<>'') then
    if (s[Length(s)] <> DriveDelim) and (s[Length(s)] <> Slash) then
      s := s + Slash;
end;

procedure RemoveEndSlash(var s: string);
begin
  if s[Length(s)] in ['\','/'] then
    Dec(s[0]);
end;

function  FileExists(s: string): BOOL;
var
  F: FILE;
begin
  Assign(F,s); FileMode:=0;
  {$I-}
  Reset(F);
  {$I+}
  if IOResult=0
    then begin
      Close(F);
      FileExists:=TRUE;
    end
    else
      FileExists:=FALSE;
end;

function  DirectoryExists(s: string): BOOL;
var
  R: SearchRec;
begin
  RemoveEndSlash(s);
  FindFirst(s, DOS.Directory, R);
  DirectoryExists := (DOS.DosError = 0) and (R.Attr and DOS.Directory <> 0);
{$ifdef PPC_FPC}
  FindClose(R);
{$endif}
end;

function  FileLength(s: string): INT;
var
  F: FILE;
begin
  Assign(F,s); FileMode:=0;
  {$I-}
  Reset(F);
  {$I+}
  QError:=IOResult;
  if QError=0
    then begin
      FileLength:=FileSize(F);
      Close(F);
    end
    else FileLength := 0;
end;

function  ExtractFileDrive(s: string): string;
begin
{$ifdef OS_LINUX}
  ExtractFileDrive := '';
{$else}
  s := ExpandFileName(s);
  if s = '' then
    ExtractFileDrive := ''
  else
    ExtractFileDrive := UpCase(s[1])+':';
{$endif}
end;

function  ExtractFileDir(s: string): string;
var
  D: DirStr; N: NameStr; E: ExtStr;
begin
  FSplit(s,D,N,E);
  ExtractFileDir:=D;
end;

function  ExtractFileName(s: string): string;
var
  D: DirStr; N: NameStr; E: ExtStr;
begin
  FSplit(s,D,N,E);
  if E='' then
    ExtractFileName := N
  else
  begin
    if pos('.', E) = 0 then
      E := '.'+E;
    ExtractFileName:=N+E;
  end;
end;

function  ExpandFileName(s: string): string;
begin
{$ifdef OS_LINUX}
  ExpandFileName := FExpand(s);
{$else}
  ExpandFileName := UpperCase(FExpand(s));
{$endif}
end;

function  EqualFileNames(s,t: string): BOOL;
begin
  s := ExpandFileName(s);
  t := ExpandFileName(t);
  EqualFileNames := (s = t);
end;

function  MoveFile(s,t: string): BOOL;
var
  F: FILE;
begin
  if ExtractFileDrive(s) = ExtractFileDrive(t)
    then begin
      Assign(F,s);
      Rename(F,t);
      QError := IOResult;
      MoveFile:=(QError=0);
    end
    else begin
      if CopyFile(s,t)
        then begin DeleteFile(s); MoveFile:=TRUE; end
        else MoveFile:=FALSE;
    end;
end;

{  function  WildFileName(s,w: string): string; mask }
function  MoveDirectory( src, dst: string ): BOOL;
var
  R: SearchRec;
  f: FILE;
begin
  if EqualFileNames(src, dst) then
    begin
      MoveDirectory := TRUE;
      Exit;
    end;
  {$I-}
  RemoveEndSlash(src);
  RemoveEndSlash(dst);
  QError := IOResult;
  ForceDirectories(dst);
  if not DirectoryExists(dst) then
    begin
      MoveDirectory := FALSE;
      Exit;
    end;
  FindFirst(src+Slash+'*.*', AnyFile xor VolumeID, R);
  while DosError = 0 do
    begin
      if (R.Name <> '.') and (R.Name <> '..') then
        begin
          if R.Attr and Directory <> 0 then
            begin
              if not MoveDirectory( src + Slash + R.Name,
                                    dst + Slash + R.Name ) then
                begin
                  MoveDirectory := FALSE;
                  Exit;
                end
            end
          else
            begin
              Assign(f, src+Slash+R.Name);
              Rename(f, dst+Slash+R.Name);
            end;
        end;
      FindNext(R);
    end;
{$ifdef PPC_FPC}
  FindClose(R);
{$endif}
  RmDir(src);
  QError := IOResult;
{$I+}
  MoveDirectory := (QError = 0);
end;

function  CopyFile(s,t: string): BOOL;
type
  TBuf = array [0..8191] of BYTE;
var
  FS,FT: FILE;
  Buf: ^TBuf;
  Read,Written: size_t;
begin
  Assign(FS,s); FileMode:=0;
  Reset(FS,1);
  QError:=IOResult;
  if QError<>0 then begin CopyFile:=FALSE; Exit; end;

  Assign(FT,t); FileMode:=1;
  Rewrite(FT,1);
  QError:=IOResult;
  if QError<>0 then begin Close(FS); CopyFile:=FALSE; Exit; end;

  New(Buf);
  repeat
    BlockRead(FS,Buf^,8192,Read);
    BlockWrite(FT,Buf^,Read,Written);
  until (Read=0) or (Read<>Written);
  Dispose(Buf);

  Close(FS);
  Close(FT);
  QError := IOResult;
  CopyFile:=(QError=0);
end;

function  DeleteFile(s: string): BOOL;
var
  F: File;
begin
  Assign(F,s);
  {$I-}
  Erase(F);
  QError:=IOResult;
  {$I+}
  DeleteFile := (QError = 0);
end;

function  DeleteDirectory(s: string): BOOL;
begin
  s := ReplaceDirectorySeparators(s);
  RemoveEndSlash(s);
  {$I-}
  RmDir(s);
  QError := IOResult;
  {$I+}
  DeleteDirectory := (QError = 0);
end;

function  CompareFiles(s1,s2: string): BOOL;
type
  TBuf=Real;
var
  f1,f2: FILE;
  B1,B2: TBuf;
  Res: BOOL;
  Read: size_t;
begin
  if FileLength(s1)<>FileLength(s2)
    then begin
      CompareFiles:=False;
      Exit;
    end;

  Assign(f1,s1); FileMode:=0;
  Reset(f1,1);
  QError:=IOResult;
  if QError<>0 then begin CompareFiles := FALSE; Exit; end;

  Assign(f2,s2); FileMode:=0;
  Reset(f2,1);
  QError:=IOResult;
  if QError<>0 then begin Close(f1); CompareFiles := FALSE; Exit; end;

  B1:=B2;    {in case of: FileLength < SizeOf(Buff)}
  repeat
    BlockRead(f1,B1,SizeOf(TBuf),Read);
    BlockRead(f2,B2,SizeOf(TBuf),Read);
    Res:=(B1<>B2);
  until Res or (Read=0);
  CompareFiles:= not Res;
  Close(f1);
  Close(f2);
end;

function  ConcatFiles(s1,s2,t: string): BOOL;
type
  TBuf = array [0..8191] of Byte;
var
  FS,FT: File;
  Buf: ^TBuf;
  Read,Written: size_t;
begin
  s1:=ExpandFileName(s1);
  s2:=ExpandFileName(s2);
  t:=ExpandFileName(t);

  Assign(FS,s2);
  if s2=t then begin
    if s2=s1
      then begin
        CopyFile(s2,TempDir+'$$$.tmp');
        Assign(FS,TempDir+'$$$.tmp');
      end
      else begin
        MoveFile(s2,TempDir+'$$$.tmp');
      end;
  end;

  if s1<>t then
    CopyFile(s1,t);

  Assign(FT,t);
  FileMode := 0;
  Reset(FT,1);
  Seek(FT,FileSize(FT));
  FileMode := 0;
  Reset(FS,1);

  New(Buf);
  repeat
    BlockRead(FS,Buf^,8192,Read);
    BlockWrite(FT,Buf^,Read,Written);
  until (Read=0) or (Read<>written);
  Dispose(Buf);

  Close(FS);
  Close(FT);
  if s2=t then Erase(FS);

  QError:=IOResult;
  ConcatFiles:=(QError=0);
end;

function  ForceDirectories(s: string): BOOL;
var
  tmp: PathStr;
  i: Byte;
begin
  {$I-}
  if IOResult = 0 then; { Clearing IOResult flag }
  if Length(s)=0 then Exit; { ����� ������ ������ ��४��� }

  i:=0; tmp:='';
  while i<Length(s) do begin { ������� ��४�ਨ ���� }
    if s[i+1]=Slash then
      if not DirectoryExists(tmp)
        then MkDir(tmp);
    inc(i);
    tmp:=tmp+s[i];
    QError := IOResult;
  end; {While}
  if s[Length(s)]<>Slash then {������� ��᫥���� ��⠫��}
    if not DirectoryExists(tmp) then
      MkDir(tmp);
  QError := IOResult;
  ForceDirectories:=(QError=0);
  {$I+}
end;

function  ReplaceDirectorySeparators(s: string): string;
var
  i: Byte;
begin
  for i := 1 to Length(s) do
    if s[i] in ['\','/'] then
      s[i] := Slash;
  ReplaceDirectorySeparators := s;
end;

{ <= File and directory routines }

{ => Memory routines }

{ bit routines }
const
  MASK = $07;
  SHIFT = 3;

procedure SetBit( var BitArray; BitNum: size_t );
begin
  TByteArray(BitArray)[BitNum shr SHIFT] :=
    TByteArray(BitArray)[BitNum shr SHIFT] or
    (1 shl (BitNum and MASK));
end;
procedure ClearBit( var BitArray; BitNum: size_t );
begin
  TByteArray(BitArray)[BitNum shr SHIFT] :=
    TByteArray(BitArray)[BitNum shr SHIFT] and
    not (1 shl (BitNum and MASK));
end;
function  TestBit( var BitArray; BitNum: size_t ): BOOL;
begin
  TestBit := TByteArray(BitArray)[BitNum shr SHIFT] and
    (1 shl (BitNum and MASK)) <> 0;
end;

procedure SetBitAt( p: PTR; BitNum: WORD );
begin
  p := @PByteArray(p)^[BitNum shr SHIFT];
  Byte(p^) := Byte(p^) or (1 shl (MASK - BitNum and MASK));
end;
procedure ClearBitAt( p: PTR; BitNum: WORD );
begin
  p := @PByteArray(p)^[BitNum shr SHIFT];
  Byte(p^) := Byte(p^) and not (1 shl (MASK - BitNum and MASK));
end;
function  TestBitAt( p: PTR; BitNum: WORD ): BOOL;
begin
  p := @PByteArray(p)^[BitNum shr SHIFT];
  TestBitAt := Byte(p^) and (1 shl (MASK - BitNum and MASK)) <> 0;
end;

{ routines for converting pointers }
function  AddrToPtr( Abs: INT ): PTR;
begin
  if Abs = 0 then
    begin
      AddrToPtr := nil;
      Exit;
    end;
{$ifdef BIT_16}
  AddrToPtr := _Ptr( SegA(Abs), OfsA(Abs) );
{$else}
  AddrToPtr := PTR(Abs);
{$endif}
end;

function  PtrToAddr( p: PTR ): INT;
begin
  if p = nil then
    begin
      PtrToAddr := 0;
      Exit;
    end;
{$ifdef BIT_16}
  PtrToAddr := INT(SegP(p))*16 + INT(OfsP(p));
{$else}
  PtrToAddr := INT(p);
{$endif}
end;

function  SegA( adr: INT ): WORD;
begin
  SegA := adr div 16;
end;

function  OfsA( adr: INT ): WORD;
begin
  OfsA := adr mod 16;
end;

function  SegP( p: PTR ): WORD;
begin
{$ifdef BIT_16}
  SegP := Seg(p^);
{$else}
  SegP := SegA(PtrToAddr(p));
{$endif}
end;

function  OfsP( p: PTR ): WORD;
begin
{$ifdef BIT_16}
  OfsP := Ofs(p^);
{$else}
  OfsP := OfsA(PtrToAddr(p));
{$endif}
end;

function  _Ptr( Seg, Ofs: WORD ): PTR;
begin
{$ifdef PPC_BP}
  _Ptr := System.Ptr(Seg, Ofs);
{$else}
  _Ptr := PTR(Seg*16 + Ofs);
{$endif}
end;

{ routines for accessing memory }
procedure FillCharAt( p: PTR; Count: size_t; Value: BYTE);
begin
  FillChar(p^, Count, Value);
end;

{$ifdef PPC_FPC}
procedure FillCharAt( p: PTR; Count: size_t; Value: CHAR);
begin
  FillChar(p^, Count, Value);
end;
{$endif}

function  NextBytePtr( p: PTR ): PBYTE;
begin
{$ifdef BIT_16}
  NextBytePtr := _Ptr(SegP(p), OfsP(p)+SizeOf(BYTE));
{$else}
  NextBytePtr := PTR(size_t(p)+SizeOf(BYTE));
{$endif}
end;

function  NextWordPtr( p: PTR ): PWORD;
begin
{$ifdef BIT_16}
  NextWordPtr := _Ptr(SegP(p), OfsP(p)+SizeOf(WORD));
{$else}
  NextWordPtr := PTR(size_t(p)+SizeOf(WORD));
{$endif}
end;

function  NextDWordPtr( p: PTR ): PDWORD;
begin
{$ifdef BIT_16}
  NextDWordPtr := _Ptr(SegP(p), OfsP(p)+SizeOf(DWORD));
{$else}
  NextDWordPtr := PTR(size_t(p)+SizeOf(DWORD));
{$endif}
end;

function  NextPtr( p: PTR; Shift: size_t ): PTR;
begin
{$ifdef BIT_16}
  NextPtr := _Ptr(SegP(p)+Shift div 16, OfsP(p)+Shift mod 16);
{$else}
  NextPtr := PTR(size_t(p)+Shift);
{$endif}
end;

{ TPointerStream => }

constructor TPointerStream.Init( Ap: Pointer; ASize: INT );
begin
  inherited Init;
  size := Asize;
  pos := 0;
  if Ap = nil then begin
    GetMem( p, size );
    NeedsToFreeMem := True;
  end
  else begin
    p := Ap;
    NeedsToFreeMem := False;
  end;
end;

destructor TPointerStream.Done;
begin
  if NeedsToFreeMem then
    FreeMem( p, size );
  inherited Done;
end;

function TPointerStream.GetPos: INT;
begin
  GetPos := pos;
end;

function TPointerStream.GetSize: INT;
begin
  GetSize := size;
end;

procedure TPointerStream.Read(var what; cnt: size_t);
begin
  if cnt > Size-Pos then
    cnt := Size-Pos;
  Move( PByteArray(p)^[pos], what, cnt );
  inc( pos, cnt );
end;

procedure TPointerStream.Write(var what; cnt: size_t);
begin
  if cnt > Size-Pos then
    cnt := Size-Pos;
  Move( what, PByteArray(p)^[pos], cnt );
  inc( pos, cnt );
end;

procedure TPointerStream.Seek(_Pos: INT);
begin
  if _Pos < 0 then _Pos := 0;
  if _Pos > Size then _Pos := Size-1;
  Pos := _Pos;
end;

{ <= TPointerStream }

function  MAllocate( Size: INT ): HANDLE;
var
  stream: PStream;
begin
  {$ifdef TMEMORYSTREAM}
  stream := New(PMemoryStream, Init(Size, 8192));
  if (stream^.Status <> stOk) then
    begin
      Dispose(stream, Done);
      stream := nil;
    end
  else
    begin
      MAllocate := PtrToAddr( stream );
      Exit;
    end;
  {$endif}
  {$ifdef TXMSSTREAM}
  stream := New(PXMSStream, Init(Size));
  if (stream^.Status <> stOk) then
    begin
      Dispose(stream, Done);
      stream := nil;
    end
  else
    begin
      MAllocate := PtrToAddr( stream );
      Exit;
    end;
  {$endif}
  MAllocate := PtrToAddr( nil );
end;

function  MPointer( p: PTR; Size: size_t ): HANDLE;
begin
  MPointer := PtrToAddr( New(PPointerStream, Init(p, size)) );
end;

procedure MFree( var h: HANDLE );
var
  p: PStream;
begin
  p := AddrToPtr( h );
  if p = nil then
    Exit;
  Dispose(p, Done);
  p := nil;
end;

function  MByteAt( var h: HANDLE; Shift: INT ): BYTE;
var
  p: PStream;
  b: BYTE;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MByteAt := 0;
    Exit;
  end;
  p^.Seek(Shift);
  p^.Read(b, SizeOf(b));
  MByteAt := b;
end;

function  MWordAt( var h: HANDLE; Shift: INT ): WORD;
var
  p: PStream;
  w: WORD;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MWordAt := 0;
    Exit;
  end;
  p^.Seek(Shift);
  p^.Read(w, SizeOf(w));
  MWordAt := w;
end;

function  MDWordAt( var h: HANDLE; Shift: INT ): DWORD;
var
  p: PStream;
  dw: DWORD;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MDWordAt := 0;
    Exit;
  end;
  p^.Status := 0;
  p^.Seek(Shift);
  p^.Read(dw, SizeOf(dw));
  MDWordAt := dw;
end;

function  MSeek( var h: HANDLE; Position: INT ): BOOL;
var
  p: PStream;
  w: WORD;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MSeek := FALSE;
    Exit;
  end;
  p^.Status := 0;
  p^.Seek(Position);
  MSeek := (p^.Status = stOk);
end;

function  MRead( var h: HANDLE; var Dest; Size: INT ): BOOL;
var
  p: PStream;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MRead := FALSE;
    Exit;
  end;
  p^.Status := 0;
  p^.Read(Dest, Size);
  MRead := (p^.Status = stOk);
end;

function  MWrite( var h: HANDLE; var What; Size: INT ): BOOL;
var
  p: PStream;
begin
  p := AddrToPtr( h );
  if p = nil then
  begin
    MWrite := FALSE;
    Exit;
  end;
  p^.Write(What, Size);
  MWrite := (p^.Status = stOk);
end;

{ <= Memory routines }

{ => Misc }

function  Trim(s: string): string;
var i: Byte;
begin
  i:=1;
  while (Length(S)>0) and (s[i]<=' ') do Delete(s,i,1);
  i:=Length(s);
  while (i>0) and (s[i]<=' ') do begin Delete(s, Length(s), 1); Dec(i); end;
  Trim:=s;
end;

function  IntToStr(i: INT): string;
var
  s: string;
begin
  Str(i,s);
  IntToStr:=s;
end;

function  StrToInt(s: string): INT;
var
  L: INT;
  e: {$ifdef PPC_VIRTUAL}INT{$else}Int16{$endif};
begin
  Val(s,L,e);
  QError := e;
  StrToInt:=L;
end;

function  GetSysTimer: DWORD;
{$ifdef OS_DOS}
begin
  GetSysTimer := MemL[$0040:$006C];
end;
{$else}
  {$ifdef OS_LINUX}
  var
    tv : TimeVal;
{    tz : TimeZone;}
  begin
    GetTimeOfDay(tv);{,tz);}
    GetSysTimer:=((tv.Sec mod 86400) div 60)*1092+((tv.Sec mod 60)*1000000+tv.USec) div 54945;
  end;
  {$else}
    var
      Hour, Min, Sec, Sec100: {$ifdef PPC_VIRTUAL}LongInt{$ELSE}Word{$ENDIF};
    begin
      GetTime(Hour, Min, Sec, Sec100);
      GetSysTimer := Round((((Hour*60.0 + Min)*60+Sec)*100 + Sec100)*10 / 55);
    end;
  {$endif}
{$endif}

function  _UpCase(c: CHAR): CHAR;
var
  code: Byte;
begin
  code:=ord(c);
  case code of
    {a..z}  97..122: code:=code-32;
(*    {�..�} 160..175: code:=code-32;
    {�..�} 224..239: code:=code-80; { Russian letters }*)
  end; { case }
  _UpCase:=chr(code);
end;

function  _LoCase(c: CHAR): CHAR;
var
  code: Byte;
begin
  code:=ord(c);
  case code of
    {A..Z}   65..90: code:=code+32;
(*    {�..�} 128..143: code:=code+32;
    {�..�} 144..159: code:=code+80; { Russian letters }*)
  end; { case }
  _LoCase:=chr(code);
end;

function UpperCase(s: string): string;
var
  i: Byte;
begin
  for i := 1 to Length(s) do s[i] := UpCase(s[i]);
  UpperCase := s;
end;

function LowerCase(s: string): string;
var
  i: Byte;
begin
  for i := 1 to Length(s) do s[i] := LoCase(s[i]);
  LowerCase := s;
end;

function  Min(a, b: INT): INT;
begin
  if a < b then
    Min := a
  else
    Min := b;
end;

function  Max(a, b: INT): INT;
begin
  if a > b then
    Max := a
  else
    Max := b;
end;

function  Sign(i: INT): INT;
begin
  Sign := ord(i>0) - ord(i<0);
end;

function  Signum(i: INT): INT;
begin
  Signum := Sign(i);
end;

{$ifdef PPC_BP}
  procedure WarmBoot;
  begin
    inline(
          $FB/                  { STI                                  }
          $B8/00/00/            { MOV   AX,0000                        }
          $8E/$D8/              { MOV   DS,AX                          }
          $B8/$34/$12/          { MOV   AX,1234                        }
          $A3/$72/$04/          { MOV   [0472],AX                      }
          $EA/$00/$00/$FF/$FF); { JMP   FFFF:0000                      }
  end;

  procedure ColdBoot;
  begin
    inline(
          $FB/                  { STI                                  }
          $B8/01/00/            { MOV   AX,0001                        }
          $8E/$D8/              { MOV   DS,AX                          }
          $B8/$34/$12/          { MOV   AX,1234                        }
          $A3/$72/$04/          { MOV   [0472],AX                      }
          $EA/$00/$00/$FF/$FF); { JMP   FFFF:0000                      }
  end;
{$endif}

{$ifdef PROC_REAL}
PROCEDURE ReallocateMemory(P : POINTER); ASSEMBLER;
ASM
  MOV  AX, PrefixSeg
  MOV  ES, AX
  MOV  BX, WORD PTR P+2
  CMP  WORD PTR P,0
  JE   @OK
  INC  BX

 @OK:
  SUB  BX, AX
  MOV  AH, 4Ah
  INT  21h
  JC   @X
  LES  DI, P
  MOV  WORD PTR HeapEnd,DI
  MOV  WORD PTR HeapEnd+2,ES

 @X:
END;
function  ExecuteProgram(Name: PathStr; Tail: Str127): Word; ASSEMBLER;
ASM
  {$IFDEF CPU386}
  DB      66h
  PUSH    WORD PTR HeapEnd
  DB      66h
  PUSH    WORD PTR Name
  DB      66h
  PUSH    WORD PTR Tail
  DB      66h
  PUSH    WORD PTR HeapPtr
  {$ELSE}
  PUSH    WORD PTR HeapEnd+2
  PUSH    WORD PTR HeapEnd
  PUSH    WORD PTR Name+2
  PUSH    WORD PTR Name
  PUSH    WORD PTR Tail+2
  PUSH    WORD PTR Tail
  PUSH    WORD PTR HeapPtr+2
  PUSH    WORD PTR HeapPtr
  {$ENDIF}
  CALL ReallocateMemory
  CALL SwapVectors
  CALL DOS.EXEC
  CALL SwapVectors
  CALL ReallocateMemory
  MOV  AX, DosError
  OR   AX, AX
  JNZ  @OUT
  MOV  AH, 4Dh
  INT  21h

 @OUT:
END;
{$else}
function ExecuteProgram(Name, Tail: string): WORD;
begin
  SwapVectors;
  Exec( Name, Tail );
  SwapVectors;
  ExecuteProgram := DosError;
end;
{$endif}

{ <= Misc }

begin
  TempDir := GetTemporaryDirectory;
  isDebug := FALSE;
end.
