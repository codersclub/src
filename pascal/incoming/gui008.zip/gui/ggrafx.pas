{
  GrafX 1.4 driver for GUI.
  Copyright (c) 2002 Sergey Kozlovich.
  Library GrafX 1.4 - Copyright (c)  Stefan Goehler, Germany.
  Compatible: BP (GrafX 1.4 is only BP compatible).
}
unit gGrafX;

interface

uses
  Objects,
  gDrivers,
  gImages,
  GrafX,
  Gr_Vars,
  MouseDr7;

type
  PGrafXDriver = ^TGrafXDriver;
  TGrafXDriver = object(TScreenDriver)
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;
    procedure InitColors; virtual;
    procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
    function GetPixel(AX, AY: Integer): LongInt; virtual;
    procedure HLine(AX, AY, BX: Integer; AColor: LongInt); virtual;
    procedure VLine(AX, AY, BY: Integer; AColor: LongInt); virtual;
    procedure Line(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
    procedure SetWriteMode(AWriteMode: Integer); virtual;

    procedure SetRGB(AColor: LongInt; r, g, b: Byte);
    procedure GetRGB(AColor: LongInt; var r, g, b: Byte);
    procedure SetPalette(Palette: Pointer; PaletteSize: Word);
  end;

  PGrafXMouseDriver = ^TGrafXMouseDriver;
  TGrafXMouseDriver = object (TMouseDriver)
    constructor Init;
    destructor Done; virtual;
    procedure GetState(var _x,_y: Integer; var _butt: Byte); virtual;
    procedure SetPos(_x,_y: Integer); virtual;
    procedure SetArea(x1,y1,x2,y2: Integer); virtual;
    procedure Show; virtual;
    procedure Hide; virtual;
    procedure NotMove; virtual;
    procedure LetMove; virtual;
    procedure SetCursor( _Cursor: TCursor ); virtual;
  end;

implementation

{ ===> TGrafXDriver }
constructor TGrafXDriver.Init(AWidth, AHeight: Integer; ABPP: Word);

  procedure SetPalette256;
  var
    i: Integer;
    r, g, b: Byte;
  begin
    for i := 16 to 231 do
      begin
        img_dergb_8(i, r, g, b);
        SetRGB(i, r, g, b);
      end;
    setpal;
  end;

begin
  inherited Init(AWidth, AHeight, ABPP);
  GrafX.SetMode(Width, Height, BPP);
  Status := GrafX.GraphResult;
  if Status<>0 then
    Exit;

  if BPP=8 then begin
    SetPalette256;
    Grafx.RGB := rgb_8;
  end;
  InitColors;
end;

procedure TGrafXDriver.InitColors;
begin
  gDrivers.Black        := GrafX.Black;
  gDrivers.Blue         := GrafX.Blue;
  gDrivers.Green        := GrafX.Green;
  gDrivers.Cyan         := GrafX.Cyan;
  gDrivers.Red          := GrafX.Red;
  gDrivers.Magenta      := GrafX.Magenta;
  gDrivers.Brown        := GrafX.Brown;
  gDrivers.LightGray    := GrafX.LightGray;
  gDrivers.DarkGray     := GrafX.DarkGray;
  gDrivers.LightBlue    := GrafX.LightBlue;
  gDrivers.LightGreen   := GrafX.LightGreen;
  gDrivers.LightCyan    := GrafX.LightCyan;
  gDrivers.LightRed     := GrafX.LightRed;
  gDrivers.LightMagenta := GrafX.LightMagenta;
  gDrivers.Yellow       := GrafX.Yellow;
  gDrivers.White        := GrafX.White;
  if (BPP<8)
    then begin
      col_light1   := LightGray;
      col_dark1    := Black;
      col_light2   := White;
      col_dark2    := DarkGray;
      col_3d_bg    := LightGray;
      col_3d_text  := Black;
      col_bar_bg   := Blue;
      col_bar_bg2  := Blue;
      col_bar_text := White;
      col_desktop  := Cyan;
      col_transparent := Black;
    end
    else begin
      col_light1   := RGB(212,208,200);
      col_dark1    := RGB(0,0,0);
      col_light2   := RGB(255,255,255);
      col_dark2    := RGB(128,128,128);
      col_3d_bg    := RGB(212,208,200);
      col_3d_text  := RGB(0,0,0);
      col_bar_bg   := RGB(10,36,106);
      col_bar_bg2  := RGB(166,202,240);
      col_bar_text := RGB(255,255,255);
      col_desktop  := RGB(58,110,165);
      col_transparent := Black;
    end;
  col_mouseon_bg := col_3d_bg;
end;

procedure TGrafXDriver.PutPixel(AX, AY: Integer; AColor: LongInt);
begin
  GrafX.PutPixel(AX, AY, AColor);
end;

function TGrafXDriver.GetPixel(AX, AY: Integer): LongInt;
begin
  GetPixel:=GrafX.GetPixel(AX, AY) and (LongInt(1) shl BPP - 1);
end;

procedure TGrafXDriver.HLine(AX, AY, BX: Integer; AColor: LongInt);
begin
  Line(AX, AY, BX, AY, AColor);
end;

procedure TGrafXDriver.VLine(AX, AY, BY: Integer; AColor: LongInt);
begin
  Line(AX, AY, AX, BY, AColor);
end;

procedure TGrafXDriver.SetRGB(AColor: LongInt; r, g, b: Byte);
begin
  grafx.setrgbpal(AColor, r, g, b);
end;

procedure TGrafXDriver.GetRGB(AColor: LongInt; var r, g, b: Byte);
begin
  grafx.getrgbpal(AColor, r, g, b);
end;

procedure TGrafXDriver.SetPalette(Palette: Pointer; PaletteSize: Word);
begin
  Move(Palette^,Gr_Vars.Pal^,PaletteSize*3);
  grafx.setpal;
end;

procedure TGrafXDriver.SetWriteMode(AWriteMode: Integer);
begin
  GrafX.SetWriteMode(AWriteMode);
end;

procedure TGrafXDriver.Line(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GrafX.SetColor(AColor);
  GrafX.Line(AX, AY, BX, BY);
end;

procedure TGrafXDriver.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
begin
(*  if AFlags and SHOW_TRANSPARENT <> 0 then
{???}    spriteline(AX, AY, ASize, @ALine, col_transparent)
  else
    spriteline(AX, AY, ASize, @ALine, 0);*)
{  if BPP = 4 then}
    inherited PutLine(AX, AY, ASize, ALine, AFlags);
{  else
    if AFlags and SHOW_TRANSPARENT <> 0 then
      spriteline(AX, AY, ASize, @ALine, col_transparent)
    else
      spriteline(AX, AY, ASize, @ALine, 0);}
end;

procedure TGrafXDriver.Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GrafX.SetColor(AColor);
  GrafX.Rectangle(AX, AY, BX, BY);
end;

procedure TGrafXDriver.DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  inherited DottedRectangle(AX, AY, BX, BY, AColor);
end;

procedure TGrafXDriver.Bar(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GrafX.SetFillStyle(GrafX.SolidFill, AColor);
  GrafX.Bar(AX, AY, BX, BY);
end;

procedure TGrafXDriver.SetViewPort(AX, AY, BX, BY: Integer);
begin
  GrafX.SetViewPort(AX, AY, BX, BY, True);
end;

destructor TGrafXDriver.Done;
begin
  if Status = stOk then
    GrafX.CloseGraph;
end;
{ <=== TGrafXDriver }

{ => TGrafXMouseDriver }
constructor TGrafXMouseDriver.Init;
begin
  inherited Init;
  IsMouse := MouseDr7.IsMouse;
  if IsMouse then MouseDr7.InitMouse;
  MouseDr7.HideMouse;
{  Visible := False;}
  SetPos(Screen^.Width div 2, Screen^.Height div 2);
end;

procedure TGrafXMouseDriver.GetState(var _x,_y: Integer; var _butt: Byte);
begin
  if not IsMouse then Exit;
  MouseDr7.GetMouseEvent;
  _x:=MouseDr7.event.where.x;
  _y:=MouseDr7.event.where.y;
  _butt:=MouseDr7.event.buttons;
  SetPos(_x, _y);
end;

procedure TGrafXMouseDriver.SetPos(_x,_y: Integer);
begin
  if not IsMouse then Exit;
{  if Visible
    then begin}
{      HideMouse;}
      inherited SetPos(_x,_y);
      MouseDr7.SetMousePos(_x,_y);
{      ShowMouse;}
{    end
    else begin
      inherited SetPos(_x,_y);
      MouseDr7.SetMousePos(_x,_y);
    end;}
end;

procedure TGrafXMouseDriver.SetArea(x1,y1,x2,y2: Integer);
begin
  if not IsMouse then Exit;
  MouseDr7.SetMouseArea(x1,y1,x2,y2);
end;

procedure TGrafXMouseDriver.Show;
begin
  if not IsMouse then Exit;
  inherited Show;
{  MouseDr7.ShowMouse;}
{  Visible := True;}
end;

procedure TGrafXMouseDriver.Hide;
begin
  if not IsMouse then Exit;
  inherited Hide;
{  MouseDr7.HideMouse;}
{  Visible := False;}
end;

procedure TGrafXMouseDriver.NotMove;
begin
  if not IsMouse then Exit;
  MouseDr7.NotMoveMouse;
end;

procedure TGrafXMouseDriver.LetMove;
begin
  if not IsMouse then Exit;
  MouseDr7.LetMoveMouse;
end;

procedure TGrafXMouseDriver.SetCursor( _Cursor: TCursor );
begin
  if not IsMouse then Exit;
  inherited SetCursor( _Cursor );
{  MouseDr7.ChangeCursor( _Cursor+1 );}
end;

destructor TGrafXMouseDriver.Done;
begin
  if not IsMouse then Exit;
  MouseDr7.DoneMouse;
  inherited Done;
end;
{ <= TGrafXMouseDriver }

end.
