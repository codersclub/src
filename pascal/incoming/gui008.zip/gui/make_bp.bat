rem Compiles GUI examples for DOS Protected mode by Borland Pascal with Objects
bpc -CP -M -Ifreetype\lib; -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo1
bpc -CP -M -Ifreetype\lib; -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo2
bpc -CP -M -Ifreetype\lib; -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo3
bpc -CP -M -Ifreetype\lib; -UGRAPH;qsystem;qsystem\XMS;GRAFX;freetype\lib; -OGRAPH;GRAFX -$A+ -$G+ -$N+ -$Q- -$R- -$X+ _gdemo4

rem -CP  means Protected Mode target
rem -M   means to make all units
rem -I<include directories>
rem -U<unit directories>
rem -O<object directories>
rem -L   means to link buffer to disk (if out of memory)
