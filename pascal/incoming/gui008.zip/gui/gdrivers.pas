{
    $Id: gplunit.pt,v 1.1 2001/08/04 11:30:25 peter Exp 2003/02/25 20:06:00 peter Exp $
    This file is part of Graphical User Interface in PASCAL
    Copyright (c) 2003 by Sergey Kozlovich

    Unit for controlling events.
    Contains classes for screen and mouse drivers.

    See the file COPYING.FPC, included in this distribution,
    for details about the copyright.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.

 **********************************************************************}
{$i platform.inc}

unit gDrivers;

interface

uses
  QSystem,
  Objects;

const

{ Event codes }

{  evMouseDown = $0001;
  evMouseUp   = $0002;
  evMouseMove = $0004;
  evMouseAuto = $0008;}
  evKeyDown   = $0010;
  evCommand   = $0100;
  evBroadcast = $0200;
  evID        = $0100;  { not TurboVision, but the same as evCommand }

{ Event masks }

  evNothing   = $0000;
  evMouse     = $000F;
  evKeyboard  = $0010;
  evMessage   = $FF00;

{ Extended key codes }

  kbEsc       = $011B;  kbAltSpace  = $0200;  kbCtrlIns   = $0400;
  kbShiftIns  = $0500;  kbCtrlDel   = $0600;  kbShiftDel  = $0700;
  kbBack      = $0E08;  kbCtrlBack  = $0E7F;  kbShiftTab  = $0F00;
  kbTab       = $0F09;  kbAltQ      = $1000;  kbAltW      = $1100;
  kbAltE      = $1200;  kbAltR      = $1300;  kbAltT      = $1400;
  kbAltY      = $1500;  kbAltU      = $1600;  kbAltI      = $1700;
  kbAltO      = $1800;  kbAltP      = $1900;  kbCtrlEnter = $1C0A;
  kbEnter     = $1C0D;  kbAltA      = $1E00;  kbAltS      = $1F00;
  kbAltD      = $2000;  kbAltF      = $2100;  kbAltG      = $2200;
  kbAltH      = $2300;  kbAltJ      = $2400;  kbAltK      = $2500;
  kbAltL      = $2600;  kbAltZ      = $2C00;  kbAltX      = $2D00;
  kbAltC      = $2E00;  kbAltV      = $2F00;  kbAltB      = $3000;
  kbAltN      = $3100;  kbAltM      = $3200;  kbF1        = $3B00;
  kbF2        = $3C00;  kbF3        = $3D00;  kbF4        = $3E00;
  kbF5        = $3F00;  kbF6        = $4000;  kbF7        = $4100;
  kbF8        = $4200;  kbF9        = $4300;  kbF10       = $4400;
  kbHome      = $4700;  kbUp        = $4800;  kbPgUp      = $4900;
  kbGrayMinus = $4A2D;  kbLeft      = $4B00;  kbRight     = $4D00;
  kbGrayPlus  = $4E2B;  kbEnd       = $4F00;  kbDown      = $5000;
  kbPgDn      = $5100;  kbIns       = $5200;  kbDel       = $5300;
  kbShiftF1   = $5400;  kbShiftF2   = $5500;  kbShiftF3   = $5600;
  kbShiftF4   = $5700;  kbShiftF5   = $5800;  kbShiftF6   = $5900;
  kbShiftF7   = $5A00;  kbShiftF8   = $5B00;  kbShiftF9   = $5C00;
  kbShiftF10  = $5D00;  kbCtrlF1    = $5E00;  kbCtrlF2    = $5F00;
  kbCtrlF3    = $6000;  kbCtrlF4    = $6100;  kbCtrlF5    = $6200;
  kbCtrlF6    = $6300;  kbCtrlF7    = $6400;  kbCtrlF8    = $6500;
  kbCtrlF9    = $6600;  kbCtrlF10   = $6700;  kbAltF1     = $6800;
  kbAltF2     = $6900;  kbAltF3     = $6A00;  kbAltF4     = $6B00;
  kbAltF5     = $6C00;  kbAltF6     = $6D00;  kbAltF7     = $6E00;
  kbAltF8     = $6F00;  kbAltF9     = $7000;  kbAltF10    = $7100;
  kbCtrlPrtSc = $7200;  kbCtrlLeft  = $7300;  kbCtrlRight = $7400;
  kbCtrlEnd   = $7500;  kbCtrlPgDn  = $7600;  kbCtrlHome  = $7700;
  kbAlt1      = $7800;  kbAlt2      = $7900;  kbAlt3      = $7A00;
  kbAlt4      = $7B00;  kbAlt5      = $7C00;  kbAlt6      = $7D00;
  kbAlt7      = $7E00;  kbAlt8      = $7F00;  kbAlt9      = $8000;
  kbAlt0      = $8100;  kbAltMinus  = $8200;  kbAltEqual  = $8300;
  kbCtrlPgUp  = $8400;  kbAltBack   = $0800;  kbNoKey     = $0000;

const

{ letters �������������������������������������������������������������� }

  kb_AA                  = $1E61;     { a                                }
  kb_A                   = $1E41;     { A                                }
  kb_CtrlA               = $1E01;     { ^A                               }
                                      { SOH - Start Of Header            }
  kb_AltA                = $1E00;     { ALT A                            }

  kb_BB                  = $3062;     { b                                }
  kb_B                   = $3042;     { B                                }
  kb_CtrlB               = $3002;     { ^B                               }
                                      { STX - Start Of Text              }
  kb_AltB                = $3000;     { ALT B                            }

  kb_CC                  = $2E63;     { c                                }
  kb_C                   = $2E43;     { C                                }
  kb_CtrlC               = $2E03;     { ^C                               }
                                      { ETX - End Of Text                }
  kb_AltC                = $2E00;     { ALT C                            }

  kb_DD                  = $2064;     { d                                }
  kb_D                   = $2044;     { D                                }
  kb_CtrlD               = $2004;     { ^D                               }
                                      { EOT - End Of Transmission        }
  kb_AltD                = $2000;     { ALT D                            }

  kb_EE                  = $1265;     { e                                }
  kb_E                   = $1245;     { E                                }
  kb_CtrlE               = $1205;     { ^E                               }
                                      { ENQ - Enquire                    }
  kb_AltE                = $1200;     { ALT E                            }

  kb_FF                  = $2166;     { f                                }
  kb_F                   = $2146;     { F                                }
  kb_CtrlF               = $2106;     { ^F                               }
                                      { ACK - Acknowledge                }
  kb_AltF                = $2100;     { ALT F                            }

  kb_GG                  = $2267;     { g                                }
  kb_G                   = $2247;     { G                                }
  kb_CtrlG               = $2207;     { ^G                               }
                                      { BEL - Bell                       }
  kb_AltG                = $2200;     { ALT G                            }

  kb_HH                  = $2368;     { h                                }
  kb_H                   = $2348;     { H                                }
  kb_CtrlH               = $2308;     { ^H                               }
                                      { BS - BackSpace                   }
  kb_AltH                = $2300;     { ALT H                            }

  kb_II                  = $1769;     { i                                }
  kb_I                   = $1749;     { I                                }
  kb_CtrlI               = $1709;     { ^I                               }
                                      { HT - Horizontal Tab              }
  kb_AltI                = $1700;     { ALT I                            }

  kb_JJ                  = $246A;     { j                                }
  kb_J                   = $244A;     { J                                }
  kb_CtrlJ               = $240A;     { ^J                               }
                                      { LF - Line Feed                   }
  kb_AltJ                = $2400;     { ALT J                            }

  kb_KK                  = $256B;     { k                                }
  kb_K                   = $254B;     { K                                }
  kb_CtrlK               = $250B;     { ^K                               }
                                      { VT - Vertical Tab                }
  kb_AltK                = $2500;     { ALT K                            }

  kb_LL                  = $266C;     { l                                }
  kb_L                   = $264C;     { L                                }
  kb_CtrlL               = $260C;     { ^L                               }
                                      { FF - Form Feed (new page)        }
  kb_AltL                = $2600;     { ALT L                            }

  kb_MM                  = $326D;     { m                                }
  kb_M                   = $324D;     { M                                }
  kb_CtrlM               = $320D;     { ^M                               }
                                      { CR - Carriage Return             }
  kb_AltM                = $3200;     { ALT M                            }

  kb_NN                  = $316E;     { n                                }
  kb_N                   = $314E;     { N                                }
  kb_CtrlN               = $310E;     { ^N                               }
                                      { SO - Shift Out (numbers)         }
  kb_AltN                = $3100;     { ALT N                            }

  kb_OO                  = $186F;     { o                                }
  kb_O                   = $184F;     { O                                }
  kb_CtrlO               = $180F;     { ^O                               }
                                      { SI - Shift In (letters)          }
  kb_AltO                = $1800;     { ALT O                            }

  kb_PP                  = $1970;     { p                                }
  kb_P                   = $1950;     { P                                }
  kb_CtrlP               = $1910;     { ^P                               }
                                      { DEL - Delete                     }
  kb_AltP                = $1900;     { ALT P                            }

  kb_QQ                  = $1071;     { q                                }
  kb_Q                   = $1051;     { Q                                }
  kb_CtrlQ               = $1011;     { ^Q                               }
                                      { DC1 - Device Control 1           }
  kb_AltQ                = $1000;     { ALT Q                            }

  kb_RR                  = $1372;     { r                                }
  kb_R                   = $1352;     { R                                }
  kb_CtrlR               = $1312;     { ^R                               }
                                      { DC2 - Device Control 2           }
  kb_AltR                = $1300;     { ALT R                            }

  kb_SS                  = $1F73;     { s                                }
  kb_S                   = $1F53;     { S                                }
  kb_CtrlS               = $1F13;     { ^S                               }
                                      { DC3 - Device Control 3           }
  kb_AltS                = $1F00;     { ALT S                            }

  kb_TT                  = $1474;     { t                                }
  kb_T                   = $1454;     { T                                }
  kb_CtrlT               = $1414;     { ^T                               }
                                      { DC4 - Device Control 4           }
  kb_AltT                = $1400;     { ALT T                            }

  kb_UU                  = $1675;     { u                                }
  kb_U                   = $1655;     { U                                }
  kb_CtrlU               = $1615;     { ^U                               }
                                      { NAK - Negative Acknowlegde       }
  kb_AltU                = $1600;     { ALT U                            }

  kb_VV                  = $2F76;     { v                                }
  kb_V                   = $2F56;     { V                                }
  kb_CtrlV               = $2F16;     { ^V                               }
                                      { SYN - Syncronize                 }
  kb_AltV                = $2F00;     { ALT V                            }

  kb_WW                  = $1177;     { w                                }
  kb_W                   = $1157;     { W                                }
  kb_CtrlW               = $1117;     { ^W                               }
                                      { ETB - End of Text Block          }
  kb_AltW                = $1100;     { ALT W                            }

  kb_XX                  = $2D78;     { x                                }
  kb_X                   = $2D58;     { X                                }
  kb_CtrlX               = $2D18;     { ^X -                             }
                                      { CAN - Cancel                     }
  kb_AltX                = $2D00;     { ALT X                            }

  kb_YY                  = $1579;     { y                                }
  kb_Y                   = $1559;     { Y                                }
  kb_CtrlY               = $1519;     { ^Y                               }
                                      { EM - End of Medium               }
  kb_AltY                = $1500;     { ALT Y                            }

  kb_ZZ                  = $2C7A;     { z                                }
  kb_Z                   = $2C5A;     { Z                                }
  kb_CtrlZ               = $2C1A;     { ^Z                               }
                                      { SUB - Substitute                 }
  kb_AltZ                = $2C00;     { ALT Z                            }

{ numbers �������������������������������������������������������������� }

  kb_1                   = $0231;     { 1                                }
  kb_Pad1                = $4F31;     { SHIFT 1      number pad          }
  kb_Alt1                = $7800;     { ALT 1                            }

  kb_2                   = $0332;     { 2                                }
  kb_Pad2                = $5032;     { SHIFT 2      number pad          }
  kb_Alt2                = $7900;     { ALT 2                            }
  kb_Ctrl2               = $0300;     { ^1 (NUL)                         }

  kb_3                   = $0433;     { 3                                }
  kb_Pad3                = $5133;     { SHIFT 3      number pad          }
  kb_Alt3                = $7A00;     { ALT 3                            }

  kb_4                   = $0534;     { 4                                }
  kb_Pad4                = $4B34;     { SHIFT 4      number pad          }
  kb_Alt4                = $7B00;     { ALT 4                            }

  kb_5                   = $0635;     { 5                                }
  kb_Pad5                = $4C35;     { SHIFT 5      number pad          }
  kb_Alt5                = $7C00;     { ALT 5                            }

  kb_6                   = $0736;     { 6                                }
  kb_Pad6                = $4D36;     { SHIFT 6      number pad          }
  kb_Ctrl6               = $071E;     { ^6 (RS)                          }
  kb_Alt6                = $7D00;     { ALT 6                            }

  kb_7                   = $0837;     { 7                                }
  kb_Pad7                = $4737;     { SHIFT 7      number pad          }
  kb_Alt7                = $7E00;     { ALT 7                            }

  kb_8                   = $0938;     { 8                                }
  kb_Pad8                = $4838;     { SHIFT 8      number pad          }
  kb_Alt8                = $7F00;     { ALT 8                            }

  kb_9                   = $0A39;     { 9                                }
  kb_Pad9                = $4939;     { SHIFT 9      number pad          }
  kb_Alt9                = $8000;     { ALT 9                            }

  kb_0                   = $0B30;     { 0                                }
  kb_Pad0                = $5230;     { SHIFT 0      number pad          }
  kb_Alt0                = $8100;     { ALT 0                            }

{ etc: characters ������������������������������������������������������ }

  kb_Less                = $333C;     { <                                }
  kb_Great               = $343E;     { >                                }

  kb_Minus               = $352D;     { -                                }
  kb_GrayMinus           = $4A2D;     { -                                }
  kb_CtrlMinus           = $0C1F;     { ^-                               }
  kb_AltMinus            = $8200;     { ALT -                            }
  kb_ShiftGrayMinus      = $4A2D;     { SHIFT -                          }

  kb_Plus                = $1A2B;     { +                                }
  kb_GrayPlus            = $4E2B;     { +                                }
  kb_WhitePlus           = $0D2B;     { +                                }
  kb_ShiftGrayPlus       = $4E2B;     { SHIFT +                          }

  kb_Equal               = $0D3D;     { =                                }
  kb_AltEqual            = $8300;     { ALT =                            }

  kb_Slash               = $352F;     { /                                }

  kb_BackSlash           = $2B5C;     { \                                }
  kb_CtrlBackSlash       = $2B1C;     { ^\                               }
                                      { FS - File Separator              }

  kb_OpenBracket         = $1A5B;     { [                                }
  kb_CtrlOpenBracket     = $1A1B;     { ^[                               }
                                      { ESC - Escape                     }

  kb_CloseBracket        = $1B5D;     { ]                                }
  kb_CtrlCloseBracket    = $1B1D;     { ^]                               }
                                      { GS - Group Separator             }

  kb_OpenParenthesis     = $0A28;     { (                                }

  kb_CloseParenthesis    = $0B29;     { )                                }

  kb_OpenBrace           = $1A7B;     { can't write it                   }

  kb_CloseBrace          = $1B7D;     { can't write it                   }

  kb_Apostrophe          = $2827;     { '                                }
  kb_Grave               = $2960;     { `                                }

  kb_Quote               = $2822;     { "                                }

  kb_Tilde               = $297E;     { ~                                }

  kb_Cater               = $075E;     { ^                                }

  kb_Semicolon           = $273B;     { ;                                }

  kb_Comma               = $332C;     { ,                                }

  kb_Colon               = $273A;     { :                                }

  kb_Period              = $342E;     { .                                }
  kb_ShiftPeriod         = $532E;     { SHIFT .      number pad          }

  kb_GrayAsterisk        = $372A;     { *                                }
  kb_WhiteAsterisk       = $1A2A;     { *                                }

  kb_ExclamationPoint    = $0221;     { !                                }

  kb_QuestionMark        = $353F;     { ?                                }

  kb_NumberSign          = $0423;     { #                                }

  kb_Dollar              = $0524;     { $                                }

  kb_Percent             = $0625;     { %                                }

  kb_AmpersAnd           = $0826;     { &                                }

  kb_At                  = $0340;     { @                                }
                                      { ^@  = 00h                        }
                                      { NUL - Null Character             }
  kb_UnitSeparator       = $0C5F;     { _                                }
                                      { ^_  = 1Fh                        }
                                      { US  - Unit Separator             }

  kb_Vertical            = $2B7C;     { |                                }

  kb_Space               = $3920;     { SPACE BAR                        }

{ functions ������������������������������������������������������������ }

  kb_F1                  = $3B00;     { F1                               }
  kb_ShiftF1             = $5400;     { SHIFT F1                         }
  kb_CtrlF1              = $5E00;     { ^F1                              }
  kb_AltF1               = $6800;     { ALT F1                           }

  kb_F2                  = $3C00;     { F2                               }
  kb_ShiftF2             = $5500;     { SHIFT F2                         }
  kb_CtrlF2              = $5F00;     { ^F2                              }
  kb_AltF2               = $6900;     { ALT F2                           }

  kb_F3                  = $3D00;     { F3                               }
  kb_ShiftF3             = $5600;     { SHIFT F3                         }
  kb_CtrlF3              = $6000;     { ^F3                              }
  kb_AltF3               = $6A00;     { ALT F3                           }

  kb_F4                  = $3E00;     { F4                               }
  kb_ShiftF4             = $5700;     { SHIFT F4                         }
  kb_CtrlF4              = $6100;     { ^F4                              }
  kb_AltF4               = $6B00;     { ALT F4                           }

  kb_F5                  = $3F00;     { F5                               }
  kb_ShiftF5             = $5800;     { SHIFT F5                         }
  kb_CtrlF5              = $6200;     { ^F5                              }
  kb_AltF5               = $6C00;     { ALT F5                           }

  kb_F6                  = $4000;     { F6                               }
  kb_ShiftF6             = $5900;     { SHIFT F6                         }
  kb_CtrlF6              = $6300;     { ^F6                              }
  kb_AltF6               = $6D00;     { ALT F6                           }

  kb_F7                  = $4100;     { F7                               }
  kb_ShiftF7             = $5A00;     { SHIFT F7                         }
  kb_CtrlF7              = $6400;     { ^F7                              }
  kb_AltF7               = $6E00;     { ALT F7                           }

  kb_F8                  = $4200;     { F8                               }
  kb_ShiftF8             = $5B00;     { SHIFT F8                         }
  kb_CtrlF8              = $6500;     { ^F8                              }
  kb_AltF8               = $6F00;     { ALT F8                           }

  kb_F9                  = $4300;     { F9                               }
  kb_ShiftF9             = $5C00;     { SHIFT F9                         }
  kb_CtrlF9              = $6600;     { ^F9                              }
  kb_AltF9               = $7000;     { ALT F9                           }

  kb_F10                 = $4400;     { F10                              }
  kb_ShiftF10            = $5D00;     { SHIFT F10                        }
  kb_CtrlF10             = $6700;     { ^F10                             }
  kb_AltF10              = $7100;     { ALT F1\0                         }

{ cursors �������������������������������������������������������������� }

  kb_Up                  = $4800;     { UP                               }

  kb_Down                = $5000;     { DOWN                             }

  kb_Left                = $4B00;     { LEFT                             }
  kb_CtrlLeft            = $7300;     { ^LEFT                            }

  kb_Right               = $4D00;     { RIGHT                            }
  kb_CtrlRight           = $7400;     { ^RIGHT                           }

  kb_Home                = $4700;     { HOME                             }
  kb_CtrlHome            = $7700;     { ^HOME                            }

  kb_End                 = $4F00;     { END                              }
  kb_CtrlEnd             = $7500;     { ^END                             }

  kb_PgUp                = $4900;     { PG UP                            }
  kb_CtrlPgUp            = $8400;     { ^PG UP                           }

  kb_PgDown              = $5100;     { PG DN                            }
  kb_CtrlPgDown          = $7600;     { ^PG DN                           }

{ etc: keys ������������������������������������������������������������ }

  kb_Esc                 = $011B;     { ESC                              }

  kb_Enter               = $1C0D;     { RETURN                           }
  kb_CtrlEnter           = $1C0A;     { ^ENTER                           }
                                      { LF - Line Feed                   }

  kb_BackSpace           = $0E08;     { BACKSPACE                        }
  kb_CtrlBackspace       = $0E7F;     { ^BACKSPACE                       }
                                      { DEL - Delete                     }

  kb_Tab                 = $0F09;     { TAB                              }
  kb_Shift_Tab           = $0F00;     { SHIFT TAB                        }

  kb_Ins                 = $5200;     { INSERT                           }

  kb_Del                 = $5300;     { DELETE                           }

  kb_45                  = $565C;     { Key 45                       [2] }
  kb_Shift45             = $567C;     { SHIFT KEY 45                 [2] }

  kb_CtrlPrtSc           = $7200;     { ^PRTSC                       [2] }

  kb_CtrlBreak           = $0000;     { ^BREAK                       [2] }
{ Keyboard state and shift masks }

  kbRightShift  = $0001;
  kbLeftShift   = $0002;
  kbCtrlShift   = $0004;
  kbAltShift    = $0008;
  kbScrollState = $0010;
  kbNumState    = $0020;
  kbCapsState   = $0040;
  kbInsState    = $0080;

{ Mouse button state masks }

  mbLeftButton  = $01;
  mbRightButton = $02;

type

{ TPoint object }

  TPoint = object
    X, Y: Integer;
  end;

{ Event record }

  PEvent = ^TEvent;
  TEvent = record
    What: Word;
    case Word of
      evNothing: ();
      evMouse: (
        Buttons: Byte;
        Double: Boolean;
        Where: TPoint);
      evKeyDown: (
        case Integer of
       	  0: (KeyCode: Word);
          1: (CharCode: Char;
              ScanCode: Byte));
      evMessage: (
        Command: Word;
        case Word of
          0: (InfoPtr: Pointer);
          1: (InfoLong: Longint);
          2: (InfoWord: Word);
          3: (InfoInt: Integer);
          4: (InfoByte: Byte);
          5: (InfoChar: Char));
      evCommand: (
        ID: Word;
        );
  end;


type
  TCursor = Word;
const
{ Mouse Cursors }
{  crNone = $FFFF;}
  crDefault = 0;
  crArrow = crDefault;
    CURSOR_DEFAULT = crDefault;
    CURSOR_ARROW = crDefault;
    CURSOR_STANDART = crDefault;
  crHandPoint = 1;
  crHand = crHandPoint;
    CURSOR_HANDPOINT = crHandPoint;
    CURSOR_HAND = crHandPoint;
  crHourGlass = 2;
  crWait = crHourGlass;
    CURSOR_HOURGLASS = crHourGlass;
    CURSOR_WAIT = crWait;
  crText = 3;
    CURSOR_TEXT = crText;

const
{
Default status constants of unit <Objects>:
  stOk         � 0     � No error
  stError      � -1    � Access error
  stInitError  � -2    � Cannot initialize stream
  stReadError  � -3    � Read beyond end of stream
  stWriteError � -4    � Cannot expand stream
  stGetError   � -5    � Get of unregistered object type
  stPutError   � -6    � Put of unregistered object type
}
  ST_OK = stOk;
  ST_ACCESS_ERROR = stError;
  ST_INIT_ERROR = stInitError;
  ST_READ_ERROR = stReadError;
  ST_WRITE_ERROR = stWriteError;
  ST_GET_ERROR = stGetError;
  ST_PUT_ERROR = stPutError;

  ST_FORMAT_ERROR = -100; { File format error (e.g. in graphic files) }
    stFormatError = ST_FORMAT_ERROR;
  ST_HEADER_ERROR = -101;
    stHeaderError = ST_HEADER_ERROR;
  ST_NO_MEMORY = -102;
    stNoMemory = ST_NO_MEMORY;

type
{$ifndef fpc}
  Sw_Word = Word;
{$endif}

  rgb_proc = function (Red, Green, Blue: Byte): LongInt;
  dergb_proc = procedure (Color: LongInt; var Red, Green, Blue: Byte);

type
  TColor = packed record
  case Byte of
  0: (Color: LongInt);
  1: (Red, Green, Blue, Misc{? First or last}: Byte);
  end;

  TRGB = packed record
    Red, Green, Blue: Byte;
  end;

{!!!  TRGBArray = array [0..21840] of TRGB;
  PRGBArray = ^TRGBArray;}

  TPaletteEntry = TRGB;
  TPaletteEntries = array [0..255] of TPaletteEntry;
  TPalette =
    packed record
      Version: Word;    { currently: the size of palette in bytes =
                          NumEntries*SizeOf(TPaletteEntry) = NumEntries*3 }
      NumEntries: Word;
      PalEntry: ^TPaletteEntries;
    end;
  PPalette = ^TPalette;
    { This TPalette record is the same as in Borland Delphi }

const { for TCanvas.PutImge }
  SHOW_NORMAL = $0000;
  SHOW_STRETCH = $0001;
  SHOW_FADE = $0002;
    FADE_STEPS: Word = 5;
    FADE_DELAY: Word = 50;
  SHOW_INTERLACED = $0004;
  SHOW_RESIZE = $0008;
  SHOW_TRANSPARENT = $0010;

var
{ STANDART COLORS }
  Black,Blue,Green,Cyan,Red,Magenta,Brown,LightGray,
  DarkGray,LightBlue,LightGreen,LightCyan,
  LightRed,LightMagenta,Yellow,White: LongInt;
{ COLORS USED BY GUI ITEMS }
  {0} col_transparent,
  {1} col_light1,
  {2} col_dark1,
  {3} col_light2,
  {4} col_dark2,
  {5} col_3d_bg,
  {6} col_3d_text,
  {7} col_bar_bg,
  {8} col_bar_bg2,
  {9} col_bar_text,
  {A} col_desktop,
  {B} col_mouseon_bg: LongInt;

type
  PCanvas = ^TCanvas;
  TCanvas = object(TObject) { Abstract class }
    Status: Integer;
    Width, Height: Integer;
    BPP, BytesPerPixel: Word;
    RGB: rgb_proc;
    DeRGB: dergb_proc;
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;
    procedure InitColors; virtual;
      { Call this procedure to set up the colors
        during the initialization. }

{A} procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
{A} function GetPixel(AX, AY: Integer): LongInt; virtual;
    function Transparent(AColor1, AColor2: LongInt;
      AIntencity: Extended): LongInt;

    procedure BeginUpdate; virtual;
    procedure EndUpdate; virtual;

    procedure HLine(AX, AY, BX: Integer; AColor: LongInt); virtual;
    procedure VLine(AX, AY, BY: Integer; AColor: LongInt); virtual;
    procedure Line(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure GetLine(AX, AY, ASize: Integer; var ALine); virtual;
    procedure PutAlphaLine(AX, AY, ASize: Integer; var ALine; var AMask); virtual;
      { For <PutLine> and <GetLine> BPP must be the same as <TCanvas.BPP> }
    procedure Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedXORRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar2(AX, AY, BX, BY: Integer; Color1, Color2: LongInt); virtual;
{A} procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
    procedure SetMaxViewPort;
{A} procedure SetWriteMode(AWriteMode: Integer); virtual;
    procedure PutImage(var Canvas: PCanvas; AX, AY, BX, BY: Integer; AFlags: Word);
      { Adds <Canvas> to <self> as an image.
        <Canvas> and <self> must have the same <BPP>. }
    procedure GetImage(var Canvas: PCanvas; AX, AY, BX, BY: Integer);
      { Get image from <self> and writes it to <Canvas>.
        <Canvas> and <self> must have the same <BPP>. }
    procedure PutImageSemiTransparent(var Canvas: PCanvas;
      AX, AY, BX, BY: Integer; Factor: Real; AFlags: Word);
      { Factor is the coeficient of visibility from [0..1] }

    procedure BevelInner(x1,y1,x2,y2: Integer);
    procedure BevelOuter(x1,y1,x2,y2: Integer);
    procedure BevelInner2(x1,y1,x2,y2: Integer);
    procedure BevelOuter2(x1,y1,x2,y2: Integer);
    procedure DrawBitmap(x,y: Integer; bitmap: string; {0 & 1} col: LongInt);
    procedure DrawBitmap2(x,y: Integer; bitmap: string { HEX colors });
  end;

  PScreenDriver = PCanvas{^TScreenDriver};
  TScreenDriver = TCanvas;

  PMouseDriver = ^TMouseDriver;
  TMouseDriver = object (TObject)
    IsMouse: Boolean;
{    Visible: Boolean;}
    X,Y: Integer;
    constructor Init;
    procedure GetState(var _x,_y: Integer; var _butt: Byte); virtual;
      { You have to implement only this method }
    procedure SetPos(_x,_y: Integer); virtual;
    procedure SetArea(_x1,_y1,_x2,_y2: Integer); virtual;
    procedure Show; virtual;
    procedure Hide; virtual;
    procedure NotMove; virtual;
    procedure LetMove; virtual;
    procedure SetCursor( _Cursor: TCursor ); virtual;
    destructor Done; virtual;
  private
    AllowToMove: Boolean;
    x1,y1,x2,y2: Integer;
  end;

const
  Screen: PScreenDriver = nil;
  Mouse: PMouseDriver = nil;

{ These functions are initialized in unit initialization section.
  You may override them (e.g. DirectDraw library
  has its own keyboard routines. }
var
  KeyPressed: function: Boolean;
  ReadKey: function: Char;
  Delay: procedure(ms: Word);
  GetScanCode: function: Word;

function GetScanCodeFromReadKey: Word;
  { uses function gDrivers.ReadKey to return ScanCode }
procedure ClearBuffer;
procedure InitEvents;
procedure DoneEvents;

procedure GetMouseEvent(var Event: TEvent);
procedure GetKeyEvent(var Event: TEvent);
function GetShiftState: Byte;

procedure CheckEvent(var Event: TEvent);
procedure ClearEvent(var Event: TEvent);

{ Keyboard support routines }

function GetAltChar(KeyCode: Word): Char;
function GetAltCode(Ch: Char): Word;
function GetCtrlChar(KeyCode: Word): Char;
function GetCtrlCode(Ch: Char): Word;
function CtrlToArrow(KeyCode: Word): Word;

  function img_rgb_4(r,g,b: Byte): LongInt;
  function img_rgb_8(r,g,b: Byte): LongInt;
  function img_rgb_16(r,g,b: Byte): LongInt;
  function img_rgb_24(r,g,b: Byte): LongInt;
  procedure img_dergb_4(Color: LongInt; var Red, Green, Blue: Byte);
  procedure img_dergb_8(ColorIndex: LongInt; var r,g,b: Byte);
  procedure img_dergb_16(col: LongInt; var r,g,b: Byte);
  procedure img_dergb_24(col: LongInt; var r,g,b: Byte);

const
  rgb_4   : rgb_proc = {$ifdef fpc}@{$endif}img_rgb_4;
  rgb_8   : rgb_proc = {$ifdef fpc}@{$endif}img_rgb_8;
  rgb_16  : rgb_proc = {$ifdef fpc}@{$endif}img_rgb_16;
  rgb_24  : rgb_proc = {$ifdef fpc}@{$endif}img_rgb_24;
  dergb_4 : dergb_proc = {$ifdef fpc}@{$endif}img_dergb_4;
  dergb_8 : dergb_proc = {$ifdef fpc}@{$endif}img_dergb_8;
  dergb_16: dergb_proc = {$ifdef fpc}@{$endif}img_dergb_16;
  dergb_24: dergb_proc = {$ifdef fpc}@{$endif}img_dergb_24;

function Convert(srcbpp, dstbpp: Word;
                 memptr: Pointer;
                 width: Integer;
                 const rgb: rgb_proc;
                 const Palette: PPalette): Pointer;
    {
      converts pixel-reprezentation from <srcbpp> format to <dstbpp>;
      if <srcbpp>=24 then bytes in <memptr> go in order: R-G-B,
      if <srcbpp>=23 then bytes in <memptr> go in order: B-G-R
        (for BMP reading only)
      returns: allways <memptr>;
    }
  function Convert1(  dstbpp: Word;
                      memptr: Pointer;
                      width: Integer;
                      const rgb: rgb_proc;
                      const Palette: PPalette ): Pointer;
    { !!! NOT_TESTED }
  function Convert4(  dstbpp: Word;
                      memptr: Pointer;
                      width: Integer;
                      const rgb: rgb_proc;
                      const Palette: PPalette ): Pointer;
  function Convert8(  dstbpp: Word;
                      memptr: Pointer;
                      width: Integer;
                      const rgb: rgb_proc;
                      const Palette: PPalette ): Pointer;
  function Convert16(  dstbpp: Word;
                       memptr: Pointer;
                       width: Integer;
                       const rgb: rgb_proc ): Pointer;
  function Convert24(  dstbpp: Word;
                       memptr: Pointer;
                       width: Integer;
                       const rgb: rgb_proc ): Pointer;
  function Convert24BGR(  dstbpp: Word;
                          memptr: Pointer;
                          width: Integer;
                          const rgb: rgb_proc ): Pointer;

  function ConvertToGhost( bpp: Word;
                           memptr, scrptr: Pointer;
                           width: Integer;
                           const rgb: rgb_proc;
                           const dergb: dergb_proc;
                           Factor: Real;
                           Flags: Word ): Pointer;
    { <Factor> is the transparency factor from [0..1].
      Returns <memptr> }

implementation

uses
  gCursors,
  Crt,
  ScanCode;

function IntMax(a, b: Integer): Integer;
begin
  if a > b then
    IntMax := a
  else
    IntMax := b;
end;

{$ifdef PPC_FPC}
function Ticks: LongInt;
begin
  Ticks := GetSysTimer;
end;
{$endif}

{ TCanvas => }

constructor TCanvas.Init(AWidth, AHeight: Integer; ABPP: Word);
begin
  inherited Init;
  Width := AWidth;
  Height := AHeight;
  BPP := ABPP;
  case BPP of
  24,32:
    begin
      RGB := rgb_24; DeRGB := dergb_24;
    end;
  16:
    begin
      RGB := rgb_16; DeRGB := dergb_16;
    end;
  8:
    begin
      RGB := rgb_8; DeRGB := dergb_8;
    end;
  else
    begin
      RGB := rgb_4; DeRGB := dergb_4;
    end;
  end; { case }
  BytesPerPixel := (BPP+7) div 8;
  Status := 0;
end;

destructor TCanvas.Done;
begin
end;

procedure TCanvas.InitColors;
var
  Win32: Boolean;
begin
  {$ifdef OS_WINDOWS}
{  Win32 := True;} Win32 := False;
  {$else}
  Win32 := False;
  {$endif}

  if (BPP = 4) or (Win32) then begin
    Black        := 0;
    Blue         := 1;
    Green        := 2;
    Cyan         := 3;
    Red          := 4;
    Magenta      := 5;
    Brown        := 6;
    LightGray    := 7;
    DarkGray     := 8;
    LightBlue    := 9;
    LightGreen   := 10;
    LightCyan    := 11;
    LightRed     := 12;
    LightMagenta := 13;
    Yellow       := 14;
    White        := 15;
  end else begin
    Black        := RGB(0,0,0);
    Blue         := RGB(0,0,191);
    Green        := RGB(0,191,0);
    Cyan         := RGB(0,191,191);
    Red          := RGB(191,0,0);
    Magenta      := RGB(191,0,191);
    Brown        := RGB(191,191,0);
    LightGray    := RGB(192,192,192);
    DarkGray     := RGB(128,128,128);
    LightBlue    := RGB(0,0,255);
    LightGreen   := RGB(0,255,0);
    LightCyan    := RGB(0,255,255);
    LightRed     := RGB(255,0,0);
    LightMagenta := RGB(255,0,255);
    Yellow       := RGB(255,255,0);
    White        := RGB(255,255,255);
  end;

  if (BPP<8) or (Win32)
    then begin
      col_light1   := LightGray;
      col_dark1    := Black;
      col_light2   := White;
      col_dark2    := DarkGray;
      col_3d_bg    := LightGray;
      col_3d_text  := Black;
      col_bar_bg   := Blue;
      col_bar_bg2  := Blue;
      col_bar_text := White;
      col_desktop  := Cyan;
      col_transparent := Black;
    end
    else begin
      col_light1   := RGB(212,208,200);
      col_dark1    := RGB(0,0,0);
      col_light2   := RGB(255,255,255);
      col_dark2    := RGB(128,128,128);
      col_3d_bg    := RGB(212,208,200);
      col_3d_text  := RGB(0,0,0);
      col_bar_bg   := RGB(10,36,106);
      col_bar_bg2  := RGB(166,202,240);
      col_bar_text := RGB(255,255,255);
      col_desktop  := RGB(58,110,165);
      col_transparent := Black;
    end;
  col_mouseon_bg := col_3d_bg;
end;

procedure TCanvas.PutPixel(AX, AY: Integer; AColor: LongInt);
begin
{  Abstract;}
end;

function TCanvas.GetPixel(AX, AY: Integer): LongInt;
begin
{  Abstract;}
end;

function TCanvas.Transparent(AColor1, AColor2: LongInt;
  AIntencity: Extended): LongInt;
var
  r1,g1,b1,r2,g2,b2: Byte;
begin
  DeRGB(AColor1, r1, g1, b1);
  DeRGB(AColor2, r2, g2, b2);
  Transparent:=RGB(
    Round(r1*(1-AIntencity) + r2*AIntencity) and $FF,
    Round(g1*(1-AIntencity) + g2*AIntencity) and $FF,
    Round(b1*(1-AIntencity) + b2*AIntencity) and $FF);
end;

procedure TCanvas.BeginUpdate;
begin
end;

procedure TCanvas.EndUpdate;
begin
end;

procedure TCanvas.HLine(AX, AY, BX: Integer; AColor: LongInt);
var
  x: Integer;
begin
  for x := AX to BX do PutPixel(x, AY, AColor);
end;

procedure TCanvas.VLine(AX, AY, BY: Integer; AColor: LongInt);
var
  y: Integer;
begin
  for y := AY to BY do PutPixel(AX, y, AColor);
end;

procedure TCanvas.Line(AX, AY, BX, BY: Integer; AColor: LongInt);
var
   x,y,s1,s2,dlx,dly,e,z,i: integer;
   change: boolean;

   function Sign(i: Integer): Integer;
   begin
     Sign := ord(i>0) - ord(i<0);
   end;

begin
  x := AX; y:=AY;
  dlx := Abs(BX-AX); dly := Abs(BY-AY);
  s1 := Sign(BX-AX); s2 := Sign(BY-AY);
  if dly > dlx then
  begin
       z  := dlx;
       dlx := dly;
       dly := z;
  end
  else change := False;
  e := 2 * dly - dlx;
  for i := 1 to dlx do
  begin
     PutPixel(x,y,AColor);
       while e >= 0 do
       begin
            if change then inc(x,s1)
            else inc(y,s2);
            dec(e,2 * dlx);
       end;
       if change then inc(y,s2)
       else inc(x,s1);
       inc(e,2 * dly);
  end;
  PutPixel(x,y,AColor);
end;


procedure TCanvas.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
var
  x: Integer;
  offset: LongInt;
  Color: LongInt;
begin
  case BPP of
   4: for x := 0 to ASize-1 do
        begin
          if not odd(x) then
            Color := TByteArray(ALine)[x div 2] shr 4
          else
            Color := TByteArray(ALine)[x div 2] and $0F;
          if (AFlags and SHOW_TRANSPARENT = 0) or (Color <> col_transparent) then
            PutPixel(AX+x, AY, Color);
        end;
   8: for x := 0 to ASize-1 do
        begin
          Color := TByteArray(ALine)[x];
          if (AFlags and SHOW_TRANSPARENT = 0) or (Color <> col_transparent) then
            PutPixel(AX+x, AY, Color);
        end;
  16: for x := 0 to ASize-1 do
        begin
          Color := TWordArray(ALine)[x];
          if (AFlags and SHOW_TRANSPARENT = 0) or (Color <> col_transparent) then
            PutPixel(AX+x, AY, Color);
        end;
  else
    begin
      offset := 0;
      for x := 0 to ASize-1 do
        begin
          Color := LongInt(TByteArray(ALine)[offset]) and $00FFFFFF;
          inc(offset, BytesPerPixel);
          if (AFlags and SHOW_TRANSPARENT = 0) or (Color <> col_transparent) then
            PutPixel(AX+x, AY, Color);
        end;
    end;
  end;
end;

procedure TCanvas.GetLine(AX, AY, ASize: Integer; var ALine);
var
  x: Integer;
  c: LongInt;
  offset: LongInt;
begin
  case BPP of
   4: for x := 0 to ASize-1 do
      begin
        if odd(x) then
          TByteArray(ALine)[x div 2] := TByteArray(ALine)[x div 2] and $F0 + GetPixel(AX+x, AY)
        else
          TByteArray(ALine)[x div 2] := TByteArray(ALine)[x div 2] and $0F + GetPixel(AX+x, AY) shl 4;
      end;
   8: for x := 0 to ASize-1 do
        TByteArray(ALine)[x] := GetPixel(AX+x, AY);
  16: for x := 0 to ASize-1 do
        TWordArray(ALine)[x] := GetPixel(AX+x, AY);
  else
    begin
      offset := 0;
      for x := 0 to ASize-1 do
        begin
          c := GetPixel(AX+x, AY);
          Move(c, TByteArray(ALine)[offset], BytesPerPixel);
          inc(offset, BytesPerPixel);
        end;
    end;
  end;
end;

procedure TCanvas.PutAlphaLine(AX, AY, ASize: Integer; var ALine; var AMask);
var
  x: Integer;
  offset: LongInt;
begin
  if @AMask = nil then
    PutLine(AX, AY, ASize, ALine, SHOW_NORMAL)
  else
    case BPP of
    4: for x := 0 to ASize-1 do if not TestBitAt(@AMask, x) then
         begin
           if odd(x) then
             PutPixel(AX+x, AY, TByteArray(ALine)[x div 2] and $0F)
           else
             PutPixel(AX+x, AY, TByteArray(ALine)[x div 2] shr 4)
         end;
    8: for x := 0 to ASize-1 do if not TestBitAt(@AMask, x) then
         PutPixel(AX+x, AY, TByteArray(ALine)[x]);
    16: for x := 0 to ASize-1 do if not TestBitAt(@AMask, x) then
         PutPixel(AX+x, AY, TWordArray(ALine)[x shl 1]);
    else
      begin
        offset := 0;
        for x := 0 to ASize-1 do begin
          if not TestBitAt(@AMask, x) then
            PutPixel(AX+x, AY, LongInt(TByteArray(ALine)[offset]) and $00FFFFFF);
        end;
        inc(offset, BytesPerPixel);
      end;
    end;
end;

procedure TCanvas.Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  HLine(AX, AY, BX-1, AColor);
  VLine(BX, AY, BY-1, AColor);
  HLine(AX+1, BY, BX, AColor);
  VLine(AX, AY+1, BY, AColor);
end;

procedure TCanvas.DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
  procedure DottedHLine(AX, AY, BX: Integer);
  var
    x: Integer;
  begin
    for x := AX to BX do
      if odd(x)=odd(AY) then PutPixel(x, AY, AColor);
  end;

  procedure DottedVLine(AX, AY, BY: Integer);
  var
    y: Integer;
  begin
    for y := AY to BY do
      if odd(AX)=odd(y) then PutPixel(AX, y, AColor);
  end;

begin
  DottedHLine(AX, AY, BX-1);
  DottedVLine(BX, AY, BY-1);
  DottedHLine(AX+1, BY, BX);
  DottedVLine(AX, AY+1, BY);
end;

procedure TCanvas.DottedXORRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
  procedure DottedHLine(AX, AY, BX: Integer);
  var
    x: Integer;
  begin
    for x := AX to BX do
      if odd(x)=odd(AY) then PutPixel(x, AY, AColor xor GetPixel(x, AY));
  end;

  procedure DottedVLine(AX, AY, BY: Integer);
  var
    y: Integer;
  begin
    for y := AY to BY do
      if odd(AX)=odd(y) then PutPixel(AX, y, AColor xor GetPixel(AX, y));
  end;

begin
  DottedHLine(AX, AY, BX-1);
  DottedVLine(BX, AY, BY-1);
  DottedHLine(AX+1, BY, BX);
  DottedVLine(AX, AY+1, BY);
end;

procedure TCanvas.Bar(AX, AY, BX, BY: Integer; AColor: LongInt);
var
  x, y: Integer;
begin
  for y := AY to BY do
    for x := AX to BX do
      PutPixel(x, y, AColor);
end;

procedure TCanvas.Bar2(AX, AY, BX, BY: Integer; Color1, Color2: LongInt);
var
  x, y: Integer;
begin
  for x := AX to BX do
    for y := AY to BY do
      if odd(x)=odd(y) then
        PutPixel(x, y, Color1)
      else
        PutPixel(x, y, Color2);
end;

procedure TCanvas.SetViewPort(AX, AY, BX, BY: Integer);
begin
end;

procedure TCanvas.SetMaxViewPort;
begin
  SetViewPort(0, 0, Width-1, Height-1);
end;

procedure TCanvas.SetWriteMode(AWriteMode: Integer);
begin
end;

procedure TCanvas.PutImage(var Canvas: PCanvas; AX, AY, BX, BY: Integer; AFlags: Word);
var
  p: Pointer;
  y: Integer;

  procedure BuildResizedLine( y: Integer; var p: Pointer );
  var
    wL,wR: Word;
    xL,xR: Integer;
    i: Integer;
  begin

    if Canvas^.Width < BX-AX+1
      then begin
        xL := (Canvas^.Width div 4)*2; { even number of pixels }
        xR := Canvas^.Width-xL;

        Canvas^.GetLine(0, y, xL, p^);
        Canvas^.GetLine(xL, y, xR, NextPtr(p, ((BX-AX+1 - xR)*Canvas^.BPP) div 8 )^ );
{        Canvas^.GetLine(xL, y, BX-AX-xR-xL+1, ptr(seg(p^),ofs(p^) + (xL*Canvas^.BPP) div 8)^);}
        if Canvas^.BPP = 4 then
          for i:=0 to (BX-AX-xR-xL+1) div 2 do
            Move(
              NextPtr(p, (xL*Canvas^.BPP div 8)-Canvas^.BytesPerPixel)^,
              NextPtr(p,(xL*Canvas^.BPP div 8)+i*Canvas^.BytesPerPixel)^,
              Canvas^.BytesPerPixel)
        else
          for i:=0 to (BX-AX-xR-xL) do
            Move(
              NextPtr(p, (xL*Canvas^.BPP div 8)-Canvas^.BytesPerPixel)^,
              NextPtr(p, (xL*Canvas^.BPP div 8)+i*Canvas^.BytesPerPixel)^,
              Canvas^.BytesPerPixel);
      end
      else begin
        wL :=((BX-AX+1) div 4)*2; { even number of pixels }
        wR :=BX-AX+1 - wL;
        Canvas^.GetLine(0, y, wL, p^);
        Canvas^.GetLine(Canvas^.Width-wR, y, wR,
          NextPtr( p, (wL*Canvas^.BPP) div 8)^ );
      end;

  end;

var
  i: Integer;

begin
  GetMem(p, (LongInt(BX-AX+1)*IntMax(Canvas^.BPP,BPP)+7) div 8);

  if AFlags and SHOW_RESIZE <> 0 then
    begin
      if Canvas^.Height < BY-AY+1
        then begin
          for y:=0 to Canvas^.Height div 2 do
            begin
              BuildResizedLine(y, p);
              if Canvas^.BPP <> BPP then
                Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
              PutLine(AX, AY+y, BX-AX+1, p^, AFlags);
              BuildResizedLine(Canvas^.Height-1-y, p);
              if Canvas^.BPP <> BPP then
                Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
              PutLine(AX, BY-y, BX-AX+1, p^, AFlags);
            end;
          for y:=Canvas^.Height div 2 + 1 to BY-AY-(Canvas^.Height div 2)
            do PutLine(AX, AY+y, BX-AX+1, p^, AFlags);
        end
        else begin
          for y:=0 to (BY-AY+1) div 2 do
            begin
              BuildResizedLine(y, p);
              if Canvas^.BPP <> BPP then
                Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
              PutLine(AX, AY+y, BX-AX+1, p^, AFlags);

              BuildResizedLine(Canvas^.Height-1-y, p);
              if Canvas^.BPP <> BPP then
                Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
              PutLine(AX, BY-1-y, BX-AX+1, p^, AFlags);
            end;
        end;
    end
  else
  if AFlags and SHOW_FADE <> 0 then
    begin
      for i := 1 to FADE_STEPS-1 do
        begin
          PutImageSemiTransparent(Canvas, AX, AY, BX, BY, 1/(FADE_STEPS-i+1), AFlags );
          Delay(FADE_DELAY);
        end;
      PutImage(Canvas, AX, AY, BX, BY, AFlags xor SHOW_FADE);
      { ^ THIS IS NOT A RECURSION. We only output an image without FADE }
    end
  else
  { SHOW_NORMAL }
    begin
      for y := AY to BY do
        begin
          Canvas^.GetLine(0, y-AY, BX-AX+1, p^);
          if Canvas^.BPP <> BPP then
            Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
          PutLine(AX, y, BX-AX+1, p^, AFlags);
        end;
    end;

  FreeMem(p, (LongInt(BX-AX+1)*IntMax(Canvas^.BPP,BPP)+7) div 8);
end;

procedure TCanvas.GetImage(var Canvas: PCanvas; AX, AY, BX, BY: Integer);
var
  p: Pointer;
  y: Integer;
begin
  GetMem(p, ((BX-AX+1)*Canvas^.BPP+7) div 8);
  for y := AY to BY do
    begin
      GetLine(AX, y, BX-AX+1, p^);
      Canvas^.PutLine(0, y-AY, BX-AX+1, p^, SHOW_NORMAL);
    end;
  FreeMem(p, ((BX-AX+1)*Canvas^.BPP+7) div 8);
end;

procedure TCanvas.PutImageSemiTransparent(var Canvas: PCanvas;
  AX, AY, BX, BY: Integer; Factor: Real; AFlags: Word);
  { Factor is the coeficient of visibility from [0..1] }
var
  x, y: Integer;
  p, pp: Pointer;
begin
  GetMem(p, (LongInt(BX-AX+1)*IntMax(Canvas^.BPP,BPP)+7) div 8);
  GetMem(pp, (LongInt(BX-AX+1)*BPP+7) div 8);

  for y := AY to BY do
    begin
      Canvas^.GetLine(0, y-AY, BX-AX+1, p^);
      if Canvas^.BPP <> BPP then
        Convert(Canvas^.BPP, BPP, p, BX-AX+1, rgb, nil);
      GetLine(AX, y, BX-AX+1, pp^);
      ConvertToGhost(BPP, p, pp, BX-AX+1, rgb, dergb, Factor, AFlags);
      PutLine(AX, y, BX-AX+1, p^, AFlags);
    end;

  FreeMem(pp, (LongInt(BX-AX+1)*BPP+7) div 8);
  FreeMem(p, (LongInt(BX-AX+1)*IntMax(Canvas^.BPP,BPP)+7) div 8);
end;

procedure TCanvas.BevelInner(x1,y1,x2,y2: Integer);
begin
  { Up }
  Line(x1,y1,x2,y1,col_dark2);

  { Left }
  Line(x1,y1,x1,y2,col_dark2);

  { Down }
  Line(x1,y2,x2-1,y2,col_light2);

  { Right }
  Line(x2,y1,x2,y2-1,col_light2);
end;

procedure TCanvas.BevelOuter(x1,y1,x2,y2: Integer);
begin
  { Up }
  Line(x1,y1,x2-1,y1,col_light2);

  { Left }
  Line(x1,y1,x1,y2-1,col_light2);

  { Down }
  Line(x1,y2,x2,y2,col_dark1);

  { Right }
  Line(x2,y1,x2,y2,col_dark1);
end;

procedure TCanvas.BevelInner2(x1,y1,x2,y2: Integer);
begin
  { Up }
  Line(x1,y1,x2,y1,col_dark2);
  Line(x1+1,y1+1,x2-1,y1+1,col_dark1);

  { Left }
  Line(x1,y1,x1,y2,col_dark2);
  Line(x1+1,y1+1,x1+1,y2-1,col_dark1);

  { Down }
  Line(x1,y2,x2,y2,col_light2);
  Line(x1+1,y2-1,x2-1,y2-1,col_light1);

  { Right }
  Line(x2,y1,x2,y2,col_light2);
  Line(x2-1,y1+1,x2-1,y2,col_light1);
end;

procedure TCanvas.BevelOuter2(x1,y1,x2,y2: Integer);
begin
  { Up }
  Line(x1,y1,x2,y1,col_light1);
  Line(x1+1,y1+1,x2-1,y1+1,col_light2);

  { Left }
  Line(x1,y1,x1,y2,col_light1);
  Line(x1+1,y1+1,x1+1,y2-1,col_light2);

  { Down }
  Line(x1,y2,x2,y2,col_dark1);
  Line(x1+1,y2-1,x2-1,y2-1,col_dark2);

  { Right }
  Line(x2,y1,x2,y2,col_dark1);
  Line(x2-1,y1+1,x2-1,y2,col_dark2);
end;

procedure TCanvas.DrawBitmap(x,y: Integer; bitmap: string; {0 & 1} col: LongInt);
var
  i: Integer;
begin
  for i:=1 to Length(bitmap) do
    if bitmap[i]='1'
      then PutPixel(x+i-1,y,col);
end;

procedure TCanvas.DrawBitmap2(x,y: Integer; bitmap: string { HEX colors });
var
  i: Integer;
begin
  for i:=1 to Length(bitmap) do
    case bitmap[i] of
    '1': PutPixel(x+i-1,y,col_light1);
    '2': PutPixel(x+i-1,y,col_dark1);
    '3': PutPixel(x+i-1,y,col_light2);
    '4': PutPixel(x+i-1,y,col_dark2);
    '5': PutPixel(x+i-1,y,col_3d_bg);
    '6': PutPixel(x+i-1,y,col_3d_text);
    '7': PutPixel(x+i-1,y,col_bar_bg);
    '8': PutPixel(x+i-1,y,col_bar_bg2);
    '9': PutPixel(x+i-1,y,col_bar_text);
    'A': PutPixel(x+i-1,y,col_desktop);
    end;
end;

{ <= TCanvas }



{ => TMouseDriver }
constructor TMouseDriver.Init;
begin
  InitCursors;
  IsMouse := False;
  AllowToMove := True;
{  Visible := False;}
  x1 := 0; y1 := 0;
  x2 := Screen^.Width-1; y2 := Screen^.Height-1;
  X := -1; Y := -1;
end;

procedure TMouseDriver.GetState(var _x,_y: Integer; var _butt: Byte);
begin
  if not IsMouse then Exit;
  ReDrawCursor( X, Y );
end;

procedure TMouseDriver.SetPos(_x,_y: Integer);
begin
  if not IsMouse then Exit;
  X := _x; Y := _y;
  if (X < x1) then X := x1;
  if (X > x2) then X := x2;
  if (Y < y1) then Y := y1;
  if (Y > y2) then Y := y2;
  ReDrawCursor( X, Y );
end;

procedure TMouseDriver.SetArea(_x1,_y1,_x2,_y2: Integer);
var
  butt: Byte;
begin
  if not IsMouse then Exit;
  x1 := _x1; y1 := _y1; x2 := _x2; _y2 := _y2;
  GetState( X, Y, butt );
  if (X < x1) then X := x1;
  if (X > x2) then X := x2;
  if (Y < y1) then Y := y1;
  if (Y > y2) then Y := y2;
  SetPos( X, Y );
end;

procedure TMouseDriver.Show;
var
  butt: Byte;
begin
  if not IsMouse then Exit;
  GetState( X, Y, butt );
  ShowCursor( X, Y );
{  Visible := True;}
end;

procedure TMouseDriver.Hide;
begin
  if not IsMouse then Exit;
  HideCursor;
{  Visible := False;}
end;

procedure TMouseDriver.NotMove;
var
  butt: Byte;
begin
  if not IsMouse then Exit;
  if not AllowToMove then Exit;
  AllowToMove := False;
  GetState( X, Y, butt );
end;

procedure TMouseDriver.LetMove;
begin
  if not IsMouse then Exit;
  if AllowToMove then Exit;
  AllowToMove := True;
  SetPos( X, Y );
end;

procedure TMouseDriver.SetCursor( _Cursor: TCursor );
begin
  if not IsMouse then Exit;
  gCursors.SetCursor( _Cursor );
end;

destructor TMouseDriver.Done;
begin
  DoneCursors;
end;

{ <= TMouseDriver }

function GetScanCodeFromReadKey: Word;
var
  ch: Char;
begin
  ch := ReadKey{$ifdef PPC_FPC}(){$endif};
  case ch of
   #0:
     begin
       ch := ReadKey{$ifdef PPC_FPC}(){$endif};
       case ch of
       #72: GetScanCodeFromReadKey := kb_Up;
       #80: GetScanCodeFromReadKey := kb_Down;
       #75: GetScanCodeFromReadKey := kb_Left;
       #77: GetScanCodeFromReadKey := kb_Right;
       end;
     end;
   #8: GetScanCodeFromReadKey := kb_Backspace;
   #9: GetScanCodeFromReadKey := kb_Tab;
  #10,#13: GetScanCodeFromReadKey := kb_Enter;
  #27: GetScanCodeFromReadKey := kb_Esc;
  #32: GetScanCodeFromReadKey := kb_Space;
  'A': GetScanCodeFromReadKey := kb_A;
  'B': GetScanCodeFromReadKey := kb_B;
  'C': GetScanCodeFromReadKey := kb_C;
  'D': GetScanCodeFromReadKey := kb_D;
  'E': GetScanCodeFromReadKey := kb_E;
  'F': GetScanCodeFromReadKey := kb_F;
  'G': GetScanCodeFromReadKey := kb_G;
  'H': GetScanCodeFromReadKey := kb_H;
  'I': GetScanCodeFromReadKey := kb_I;
  'J': GetScanCodeFromReadKey := kb_J;
  'K': GetScanCodeFromReadKey := kb_K;
  'L': GetScanCodeFromReadKey := kb_L;
  'M': GetScanCodeFromReadKey := kb_M;
  'N': GetScanCodeFromReadKey := kb_N;
  'O': GetScanCodeFromReadKey := kb_O;
  'P': GetScanCodeFromReadKey := kb_P;
  'Q': GetScanCodeFromReadKey := kb_Q;
  'R': GetScanCodeFromReadKey := kb_R;
  'S': GetScanCodeFromReadKey := kb_S;
  'T': GetScanCodeFromReadKey := kb_T;
  'U': GetScanCodeFromReadKey := kb_U;
  'V': GetScanCodeFromReadKey := kb_V;
  'W': GetScanCodeFromReadKey := kb_W;
  'X': GetScanCodeFromReadKey := kb_X;
  'Y': GetScanCodeFromReadKey := kb_Y;
  'Z': GetScanCodeFromReadKey := kb_Z;
  'a': GetScanCodeFromReadKey := kb_AA;
  'b': GetScanCodeFromReadKey := kb_BB;
  'c': GetScanCodeFromReadKey := kb_CC;
  'd': GetScanCodeFromReadKey := kb_DD;
  'e': GetScanCodeFromReadKey := kb_EE;
  'f': GetScanCodeFromReadKey := kb_FF;
  'g': GetScanCodeFromReadKey := kb_GG;
  'h': GetScanCodeFromReadKey := kb_HH;
  'i': GetScanCodeFromReadKey := kb_II;
  'j': GetScanCodeFromReadKey := kb_JJ;
  'k': GetScanCodeFromReadKey := kb_KK;
  'l': GetScanCodeFromReadKey := kb_LL;
  'm': GetScanCodeFromReadKey := kb_MM;
  'n': GetScanCodeFromReadKey := kb_NN;
  'o': GetScanCodeFromReadKey := kb_OO;
  'p': GetScanCodeFromReadKey := kb_PP;
  'q': GetScanCodeFromReadKey := kb_QQ;
  'r': GetScanCodeFromReadKey := kb_RR;
  's': GetScanCodeFromReadKey := kb_SS;
  't': GetScanCodeFromReadKey := kb_TT;
  'u': GetScanCodeFromReadKey := kb_UU;
  'v': GetScanCodeFromReadKey := kb_VV;
  'w': GetScanCodeFromReadKey := kb_WW;
  'x': GetScanCodeFromReadKey := kb_XX;
  'y': GetScanCodeFromReadKey := kb_YY;
  'z': GetScanCodeFromReadKey := kb_ZZ;
  '0': GetScanCodeFromReadKey := kb_0;
  '1': GetScanCodeFromReadKey := kb_1;
  '2': GetScanCodeFromReadKey := kb_2;
  '3': GetScanCodeFromReadKey := kb_3;
  '4': GetScanCodeFromReadKey := kb_4;
  '5': GetScanCodeFromReadKey := kb_5;
  '6': GetScanCodeFromReadKey := kb_6;
  '7': GetScanCodeFromReadKey := kb_7;
  '8': GetScanCodeFromReadKey := kb_8;
  '9': GetScanCodeFromReadKey := kb_9;
  else
    GetScanCodeFromReadKey := Byte(ch);
  end;
end;

procedure ClearBuffer;
begin
  while KeyPressed{$ifdef PPC_FPC}(){$endif} do ReadKey{$ifdef PPC_FPC}(){$endif};
end;

procedure InitEvents;
begin
  ClearBuffer;
end;

procedure DoneEvents;
begin
  ClearBuffer;
end;

procedure GetMouseEvent(var Event: TEvent);
begin
  Event.What := evMouse;
  Mouse^.GetState(Event.Where.X, Event.Where.Y, Event.Buttons);
end;

procedure GetKeyEvent(var Event: TEvent);
begin
  if not KeyPressed{$ifdef PPC_FPC}(){$endif} then
    Event.What := evNothing
  else
    begin
      Event.What := evKeyboard;
      Event.KeyCode := GetScanCode{$ifdef PPC_FPC}(){$endif};
      { $ifdef OS_LINUX}
      if Event.KeyCode and $FF = 10 then  { under Linux Enter is 10, not 13 }
        Event.KeyCode := kbEnter;
      { $endif}
    end;
end;

{$ifdef PPC_BP}
var
  ShiftState: Byte absolute $40:$17;

function GetShiftState: Byte; assembler;
asm
	MOV	ES,Seg0040
	MOV	AL,ES:ShiftState
end;
{$else}
function GetShiftState: Byte;
begin
  GetShiftState := 0;
end;
{$endif}

var
  LastEvent: TEvent;
  procedure CheckEvent(var Event: TEvent);
  begin
    GetKeyEvent(Event);
    if Event.What = evNothing then begin
        FillChar(Event, SizeOf(Event), 0);
        Event.what:=evMouse;
        Mouse^.GetState(Event.Where.X, Event.Where.Y, Event.Buttons);
        if (LastEvent.What = evMouse) and
           (Event.Where.X = LastEvent.Where.X) and (Event.Where.Y = LastEvent.Where.Y) and
           (Event.Buttons = LastEvent.Buttons) then
             begin
               ClearEvent(Event);
             end
        else
          LastEvent := Event;
      end;
  end;

  procedure ClearEvent(var Event: TEvent);
  begin
    Event.what:=evNothing;
  end;

{ Keyboard support routines }

const

  AltCodes1: array[$10..$32] of Char =
    'QWERTYUIOP'#0#0#0#0'ASDFGHJKL'#0#0#0#0#0'ZXCVBNM';

  AltCodes2: array[$78..$83] of Char =
    '1234567890-=';

function GetAltChar(KeyCode: Word): Char;
begin
  GetAltChar := #0;
  if Lo(KeyCode) = 0 then
    case Hi(KeyCode) of
      $02: GetAltChar := #240;
      $10..$32: GetAltChar := AltCodes1[Hi(KeyCode)];
      $78..$83: GetAltChar := AltCodes2[Hi(KeyCode)];
    end;
end;

function GetAltCode(Ch: Char): Word;
begin
    case UpCase(Ch) of
    'A': GetAltCode := (kb_AltA);
    'B': GetAltCode := (kb_AltB);
    'C': GetAltCode := (kb_AltC);
    'D': GetAltCode := (kb_AltD);
    'E': GetAltCode := (kb_AltE);
    'F': GetAltCode := (kb_AltF);
    'G': GetAltCode := (kb_AltG);
    'H': GetAltCode := (kb_AltH);
    'I': GetAltCode := (kb_AltI);
    'J': GetAltCode := (kb_AltJ);
    'K': GetAltCode := (kb_AltK);
    'L': GetAltCode := (kb_AltL);
    'M': GetAltCode := (kb_AltM);
    'N': GetAltCode := (kb_AltN);
    'O': GetAltCode := (kb_AltO);
    'P': GetAltCode := (kb_AltP);
    'Q': GetAltCode := (kb_AltQ);
    'R': GetAltCode := (kb_AltR);
    'S': GetAltCode := (kb_AltS);
    'T': GetAltCode := (kb_AltT);
    'U': GetAltCode := (kb_AltU);
    'V': GetAltCode := (kb_AltV);
    'W': GetAltCode := (kb_AltW);
    'X': GetAltCode := (kb_AltX);
    'Y': GetAltCode := (kb_AltY);
    'Z': GetAltCode := (kb_AltZ);
    else GetAltCode := Ord(Ch);
    end;
end;

{
function GetAltCode(Ch: Char): Word;
var
  I: Word;
begin
  GetAltCode := 0;
  if Ch = #0 then Exit;
  Ch := UpCase(Ch);
  if Ch = #240 then
  begin
    GetAltCode := $0200;
    Exit;
  end;
  for I := $10 to $32 do
    if AltCodes1[I] = Ch then
    begin
      GetAltCode := I shl 8;
      Exit;
    end;
  for I := $78 to $83 do
    if AltCodes2[I] = Ch then
    begin
      GetAltCode := I shl 8;
      Exit;
    end;
end;
}

function GetCtrlChar(KeyCode: Word): Char;
begin
  GetCtrlChar := #0;
  if (Lo(KeyCode) <> 0) and (Lo(KeyCode) <= Byte('Z') - Byte('A') + 1) then
    GetCtrlChar := Char(Lo(KeyCode) + Byte('A') - 1);
end;

function GetCtrlCode(Ch: Char): Word;
begin
  GetCtrlCode := GetAltCode(Ch) or (Byte(UpCase(Ch)) - Byte('A') + 1);
end;

function CtrlToArrow(KeyCode: Word): Word;
const
  NumCodes = 11;
  CtrlCodes: array[0..NumCodes-1] of Char = ^S^D^E^X^A^F^G^V^R^C^H;
  ArrowCodes: array[0..NumCodes-1] of Word =
    (kbLeft, kbRight, kbUp, kbDown, kbHome, kbEnd, kbDel, kbIns,
     kbPgUp, kbPgDn, kbBack);
var
  I: Integer;
begin
  CtrlToArrow := KeyCode;
  for I := 0 to NumCodes - 1 do
    if WordRec(KeyCode).Lo = Byte(CtrlCodes[I]) then
    begin
      CtrlToArrow := ArrowCodes[I];
      Exit;
    end;
end;

function img_rgb_4(r,g,b: Byte): LongInt;
begin
  r := r div 4;
  g := g div 4;
  b := b div 4;

  case r of

   0..10: { 0+ }
     case b of
      0..20: { even }
        case g of
         0..20: img_rgb_4 := 0;
        21..63: img_rgb_4 := 2;
        end;
     21..63: { odd }
        case g of
         0..20: img_rgb_4 := 1;
        21..63: img_rgb_4 := 3;
        end;
     end;

  11..32: { 8+ }
     case b of
      0..41: { even }
        case g of
         0..41: img_rgb_4 := 8;
        42..63: img_rgb_4 := 10;
        end;
     42..63: { odd }
        case g of
         0..41: img_rgb_4 := 9;
        42..63: img_rgb_4 := 11;
        end;
     end;

  33..52: { 4+ }
     case b of
      0..20: { even }
        case g of
         0..10: img_rgb_4 := 4;
        11..63: img_rgb_4 := 6;
        end;
     21..63: { odd }
        case g of
         0..20: img_rgb_4 := 5;
        21..63: img_rgb_4 := 7;
        end;
     end;

  53..64: { 12+ }
     case b of
      0..41: { even }
        case g of
         0..41: img_rgb_4 := 12;
        42..63: img_rgb_4 := 14;
        end;
     42..63: { odd }
        case g of
         0..41: img_rgb_4 := 13;
        42..63: img_rgb_4 := 15;
        end;
     end;
  end;


end;

function img_rgb_8(r,g,b: Byte): LongInt;
begin
  r := round(r/51);
  g := round(g/51);
  b := round(b/51);
  img_rgb_8 := r*6*6 + g*6 + b + 16;
end;

function img_rgb_16(r,g,b: Byte): LongInt;
begin
  img_rgb_16:=(Word(r) shr 3) shl 11 + (Word(g) shr 2) shl 5 + (Word(b) shr 3);
end;

function img_rgb_24(r,g,b: Byte): LongInt;
begin
  img_rgb_24:=r shl 16 + g shl 8 + b;
end;

procedure img_dergb_4(Color: LongInt; var Red, Green, Blue: Byte);
begin
  case Color of
   0: begin Red := 0; Green := 0; Blue := 0; end;
   1: begin Red := 0; Green := 0; Blue := 168; end;
   2: begin Red := 0; Green := 168; Blue := 0; end;
   3: begin Red := 0; Green := 168; Blue := 168; end;
   4: begin Red := 168; Green := 0; Blue := 0; end;
   5: begin Red := 168; Green := 0; Blue := 168; end;
   6: begin Red := 168; Green := 168; Blue := 0; end;
   7: begin Red := 168; Green := 168; Blue := 168; end;
   8: begin Red := 0; Green := 0; Blue := 84; end;
   9: begin Red := 0; Green := 0; Blue := 252; end;
  10: begin Red := 0; Green := 168; Blue := 84; end;
  11: begin Red := 0; Green := 168; Blue := 252; end;
  12: begin Red := 168; Green := 0; Blue := 84; end;
  13: begin Red := 168; Green := 0; Blue := 252; end;
  14: begin Red := 168; Green := 168; Blue := 84; end;
  15: begin Red := 168; Green := 168; Blue := 252; end;
  end;
end;

procedure img_dergb_8(ColorIndex: LongInt; var r,g,b: Byte);
begin
  ColorIndex := ColorIndex-16;

  b := (ColorIndex mod 6) * 51; ColorIndex := ColorIndex div 6;
  g := (ColorIndex mod 6) * 51; ColorIndex := ColorIndex div 6;
  r := ColorIndex*51;
end;

procedure img_dergb_16(col: LongInt; var r,g,b: Byte);
begin
  {$ifdef fpc}
    b:=(col and $1F) shl 3;
    g:=(col and $7E0) shr 3;
    r:=(col and $F800) shr 8;
  {$else}
    asm
      mov   ax,word ptr col
      mov   bx,ax
      and   ax,1111100000011111b
      shl   al,3
      les   di,b
      mov   es:[di],al
      les   di,r
      mov   es:[di],ah
      and   bx,11111100000b
      shr   bx,3
      les   di,g
      mov   es:[di],bl
    end;
  {$endif}
end;

procedure img_dergb_24(col: LongInt; var r,g,b: Byte);
begin
  r:=col shr 16; g:=(col and $FFFF) shr 8; b:=col and $FF;
end;

function Convert1(  dstbpp: Word;
                    memptr: Pointer;
                    width: Integer;
                    const rgb: rgb_proc;
                    const Palette: PPalette ): Pointer;
var
  C: array [0..1] of LongInt;
  offset: LongInt;
  BytesPerPixel: Word;
  x, i: Integer;
  b: Byte;
begin
  BytesPerPixel := (dstbpp+7) div 8;
  if (Palette = nil) or (Palette^.NumEntries = 0) then
    begin
      C[0] := 0;
      C[1] := 1;
    end
  else
    begin
      with Palette^.PalEntry^[0] do
        C[0] := rgb(Red, Green, Blue);
      with Palette^.PalEntry^[1] do
        C[1] := rgb(Red, Green, Blue);
    end;

  case dstbpp of
   1:
    begin
      if (C[0] = 0) then
        if (C[1] = 0) then
          FillChar(memptr^, (Width+7) div 8, 0)
        else
          { nothing }
      else
        if C[1] = 1 then
          FillChar(memptr^, (Width+7) div 8, $FF)
        else
          for i := 0 to (Width+7) div 8 do
            PByteArray(memptr)^[i] := not PByteArray(memptr)^[i];
    end;
   4:
    begin
      x := Width-1;
      repeat
        b := PByteArray(memptr)^[x shr 3];
        for i := 0 to 7 do
          begin
            if odd(x) then
              PByteArray(memptr)^[x] := PByteArray(memptr)^[x] and $F0 + Byte(C[(b shl i) shr 7])
            else
              PByteArray(memptr)^[x] := PByteArray(memptr)^[x] and $0F + Byte(C[(b shl i) shr 7]) shl 4;
            dec(x);
            if x < 0 then
              Break;
          end;
      until x < 0;
    end;
   8:
    begin
      x := Width-1;
      repeat
        b := PByteArray(memptr)^[x shr 3];
        for i := 0 to 7 do
          begin
            PByteArray(memptr)^[x] := Byte(C[(b shl i) shr 7]);
            dec(x);
            if x < 0 then
              Break;
          end;
      until x < 0;
    end;
  16:
    begin
      x := Width-1;
      repeat
        b := PByteArray(memptr)^[x shr 3];
        for i := 0 to 7 do
          begin
            PWordArray(memptr)^[x] := Word(C[(b shl i) shr 7]);
            dec(x);
            if x < 0 then
              Break;
          end;
      until x < 0;
    end;
  else
    begin
      BytesPerPixel := (dstbpp+7) div 8;
      offset := (Width-1)*BytesPerPixel;
      x := Width-1;
      repeat
        b := PByteArray(memptr)^[x shr 3];
        for i := 0 to 7 do
          begin
            Move(C[(b shl i) shr 7],
                 PByteArray(memptr)^[offset],
                 BytesPerPixel);
            dec(x);
            dec(offset, BytesPerPixel);
            if x < 0 then
              Break;
          end;
      until x < 0;
    end;
  end; { case }
  Convert1 := memptr;
end;

function Convert4(  dstbpp: Word;
                    memptr: Pointer;
                    width: Integer;
                    const rgb: rgb_proc;
                    const Palette: PPalette ): Pointer;
var
  offset: LongInt;
  BytesPerPixel: Word;
  x: Integer;
  b: Byte;
  c: LongInt;
begin
  BytesPerPixel := (dstbpp+7) div 8;
  if dstbpp = 4 then
    begin
      for x := 0 to (width+1) div 2 do
        begin
          b := PByteArray(memptr)^[x];
          with Palette^.PalEntry^[b and $0F] do
            b := b and $F0 + rgb(Red, Green, Blue);
          with Palette^.PalEntry^[b shr 4] do
            b := b and $0F + rgb(Red, Green, Blue) shl 4;
        end;
    end
  else
    begin
      offset := (width-1)*BytesPerPixel;
      for x := (width-1) downto 0 do
        begin
          b := PByteArray(memptr)^[x shr 1];
          if odd(x) then
            c := b and $0F
          else
            c := b shr 4;
          Move(c, PByteArray(memptr)^[offset], BytesPerPixel);
          dec(offset, BytesPerPixel);
        end;
    end;
  Convert4 := memptr;
end;

function Convert8(  dstbpp: Word;
                    memptr: Pointer;
                    width: Integer;
                    const rgb: rgb_proc;
                    const Palette: PPalette ): Pointer;
var
  offset: LongInt;
  BytesPerPixel: Word;
  x: Integer;
  b: Byte;
  c: LongInt;
begin
  BytesPerPixel := (dstbpp+7) div 8;
  if dstbpp = 4 then
    begin
      for x := 0 to width-1 do
        begin
          with Palette^.PalEntry^[PByteArray(memptr)^[x]] do
            if odd(x) then
              b := b and $F0 + rgb(Red, Green, Blue)
            else
              b := rgb(Red, Green, Blue) shl 4;
          PByteArray(memptr)^[x shr 1] := b;
        end;
    end
  else
    begin
      offset := (width-1)*BytesPerPixel;
      for x := (width-1) downto 0 do
        begin
          b := PByteArray(memptr)^[x];
          with Palette^.PalEntry^[b] do
            c := rgb(Red, Green, Blue);
          Move(c, PByteArray(memptr)^[offset], BytesPerPixel);
          dec(offset, BytesPerPixel);
        end;
    end;
  Convert8 := memptr;
end;

function Convert16(  dstbpp: Word;
                     memptr: Pointer;
                     width: Integer;
                     const rgb: rgb_proc ): Pointer;
var
  offset: LongInt;
  BytesPerPixel: Word;
  x: Integer;
  w: Word;
  b: Byte;
  c: LongInt;
  Red, Green, Blue: Byte;
begin
  BytesPerPixel := (dstbpp+7) div 8;
  case dstbpp of
   4:
    begin
      for x := 0 to width-1 do
        begin
          w := PWordArray(memptr)^[x];
          img_dergb_16(w, Red, Green, Blue);
          if odd(x) then
            b := b and $F0 + rgb(Red, Green, Blue)
          else
            b := rgb(Red, Green, Blue);
          PByteArray(memptr)^[x shr 1] := b;
        end;
    end;
   8:
    begin
      for x := 0 to width-1 do
        begin
          w := PWordArray(memptr)^[x];
          img_dergb_16(w, Red, Green, Blue);
          PByteArray(memptr)^[x] := rgb(Red, Green, Blue);
        end;
    end;
  16: ; { nothing }
  24:
    begin
      offset := (width-1)*BytesPerPixel;
      for x := (width-1) downto 0 do
        begin
          w := PWordArray(memptr)^[x];
          img_dergb_16(w, Red, Green, Blue);
          c := rgb(Red, Green, Blue);
          Move(c, PByteArray(memptr)^[offset], BytesPerPixel);
          dec(offset, BytesPerPixel);
        end;
    end;
  end; { case }
  Convert16 := memptr;
end;

function Convert24BGR(  dstbpp: Word;
                        memptr: Pointer;
                        width: Integer;
                        const rgb: rgb_proc ): Pointer;
var
  x: Integer;
  offset: LongInt;
  Red, Green, Blue: Byte;
  b: Byte;
  c: LongInt;
begin
  case dstbpp of
   4:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Blue := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Red := PByteArray(memptr)^[offset+2];
          if odd(x) then
            b := b and $F0 + rgb(Red, Green, Blue)
          else
            b := rgb(Red, Green, Blue) shl 4;
          PByteArray(memptr)^[x shr 1] := b;
          inc(offset, 3);
        end;
    end;
   8:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Blue := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Red := PByteArray(memptr)^[offset+2];
          PByteArray(memptr)^[x] := rgb(Red, Green, Blue);
          inc(offset, 3);
        end;
    end;
  16:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Blue := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Red := PByteArray(memptr)^[offset+2];
          PWordArray(memptr)^[x] := rgb(Red, Green, Blue);
          inc(offset, 3);
        end;
    end;
  24:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Blue := PByteArray(memptr)^[offset];
          Red := PByteArray(memptr)^[offset+2];
          PByteArray(memptr)^[offset] := Red;
          PByteArray(memptr)^[offset+2] := Blue;
          inc(offset, 3);
        end;
    end;
  end;
  Convert24BGR := memptr;
end;

function Convert24(  dstbpp: Word;
                     memptr: Pointer;
                     width: Integer;
                     const rgb: rgb_proc ): Pointer;
var
  x: Integer;
  q: TRGB;
  offset: LongInt;
  Red, Green, Blue: Byte;
  b: Byte;
begin
  case dstbpp of
   4:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Red := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Blue := PByteArray(memptr)^[offset+2];
          if odd(x) then
            b := b and $F0 + rgb(Red, Green, Blue)
          else
            b := rgb(Red, Green, Blue) shl 4;
          PByteArray(memptr)^[x shr 1] := b;
          inc(offset, 3);
        end;
    end;
   8:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Red := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Blue := PByteArray(memptr)^[offset+2];
          PByteArray(memptr)^[x] := rgb(Red, Green, Blue);
          inc(offset, 3);
        end;
    end;
  16:
    begin
      offset := 0;
      for x := 0 to width-1 do
        begin
          Red := PByteArray(memptr)^[offset];
          Green := PByteArray(memptr)^[offset+1];
          Blue := PByteArray(memptr)^[offset+2];
          PWordArray(memptr)^[x] := rgb(Red, Green, Blue);
          inc(offset, 3);
        end;
    end;
  end;
  Convert24 := memptr;
end;

function Convert(srcbpp, dstbpp: Word;
                 memptr: Pointer;
                 width: Integer;
                 const rgb: rgb_proc;
                 const Palette: PPalette): Pointer;
var
  x, i: Integer;
  b: Byte;
begin
  case srcbpp of
   1: Convert := Convert1( dstbpp,
                           memptr,
                           width,
                           rgb,
                           Palette );
   4: Convert := Convert4( dstbpp,
                           memptr,
                           width,
                           rgb,
                           Palette );
   8: Convert := Convert8( dstbpp,
                           memptr,
                           width,
                           rgb,
                           Palette );
  16: Convert := Convert16( dstbpp,
                            memptr,
                            width,
                            rgb );
  23: Convert := Convert24BGR( dstbpp,
                               memptr,
                               width,
                               rgb );
  24: Convert := Convert24( dstbpp,
                            memptr,
                            width,
                            rgb );
  end; { case }
end;

function ConvertToGhost( bpp: Word;
                         memptr, scrptr: Pointer;
                         width: Integer;
                         const rgb: rgb_proc;
                         const dergb: dergb_proc;
                         Factor: Real;
                         Flags: Word ): Pointer;
  { <Factor> is the transparency factor from [0..1].
    Returns <memptr> }
var
  Factor0: Real;
  i: Integer;
  r0, g0, b0, r, g, b: Byte;

  u, v: Byte;
  offset: LongInt;
  Color: LongInt;
begin
  Factor0 := 1 - Factor;
  case bpp of
   4: begin
        for i := 0 to (Width+1) div 2 - 1 do
          begin
            { first color in the byte }
            dergb( (PByteArray(scrptr)^[i] and $F0) shr 4, r0, g0, b0);
            dergb( (PByteArray(memptr)^[i] and $F0) shr 4, r, g, b);
            if (Flags and SHOW_TRANSPARENT = 0) or ((PByteArray(memptr)^[i] and $F0) shr 4 <> col_transparent) then
            u := rgb(Round(r0*Factor0 + r*Factor),
                     Round(g0*Factor0 + g*Factor),
                     Round(b0*Factor0 + b*Factor))
            else
              u := col_transparent;
            { second color in the byte }
            dergb( (PByteArray(scrptr)^[i] and $0F), r0, g0, b0);
            dergb( (PByteArray(memptr)^[i] and $0F), r, g, b);
            if (Flags and SHOW_TRANSPARENT = 0) or (PByteArray(memptr)^[i] and $0F <> col_transparent) then
            v := rgb(Round(r0*Factor0 + r*Factor),
                     Round(g0*Factor0 + g*Factor),
                     Round(b0*Factor0 + b*Factor))
            else
              v := col_transparent;
            PByteArray(memptr)^[i] := u shl 4 + v;
          end;
      end;
   8: begin
        for i := 0 to Width-1 do
          begin
            dergb( (PByteArray(scrptr)^[i]), r0, g0, b0);
            dergb( (PByteArray(memptr)^[i]), r, g, b);
            if (Flags and SHOW_TRANSPARENT = 0) or (PByteArray(memptr)^[i] <> col_transparent) then
            PByteArray(memptr)^[i] :=
                 rgb(Round(r0*Factor0 + r*Factor),
                     Round(g0*Factor0 + g*Factor),
                     Round(b0*Factor0 + b*Factor));
          end;
      end;
  16: begin
        for i := 0 to Width-1 do
          begin
            dergb( (PWordArray(scrptr)^[i]), r0, g0, b0);
            dergb( (PWordArray(memptr)^[i]), r, g, b);
            if (Flags and SHOW_TRANSPARENT = 0) or (PWordArray(memptr)^[i] <> col_transparent) then
            PWordArray(memptr)^[i] :=
                 rgb(Round(r0*Factor0 + r*Factor),
                     Round(g0*Factor0 + g*Factor),
                     Round(b0*Factor0 + b*Factor));
          end;
      end;
  else begin
         offset := 0;
         for i := 0 to Width-1 do
           begin
             Color := LongInt(PByteArray(scrptr)^[offset]);
             dergb( Color, r0, g0, b0);
             Color := LongInt(PByteArray(memptr)^[offset]);
             dergb( Color, r, g, b);
             if (Flags and SHOW_TRANSPARENT = 0) or (Color <> col_transparent) then
             Color :=
                 rgb(Round(r0*Factor0 + r*Factor),
                     Round(g0*Factor0 + g*Factor),
                     Round(b0*Factor0 + b*Factor));
             Move(Color, PByteArray(memptr)^[offset], 3);
             inc(offset, 3);
           end;
       end;
  end;
  ConvertToGhost := memptr;
end;

begin
  gDrivers.KeyPressed  := {$ifdef PPC_FPC}@{$endif}Crt.KeyPressed;
  gDrivers.ReadKey     := {$ifdef PPC_FPC}@{$endif}Crt.ReadKey;
  gDrivers.Delay       := {$ifdef PPC_FPC}@{$endif}Crt.Delay;
  gDrivers.GetScanCode := {$ifdef PPC_FPC}@{$endif}ScanCode.GetScanCode;
end.
