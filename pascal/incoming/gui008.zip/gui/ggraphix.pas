{
  GraphiX 4.0 for FP driver for GUI.
  Copyright (c) 2003 Sergey Kozlovich.
  Library GraphiX
  Compatible: FP (Graphix 4.0 is only FP compatible).
}
{$ifndef fpc}
  This unit can be compiled only under FreePascal.
{$endif}
unit gGraphiX;

interface

uses
  Objects,
  gDrivers,
  gImages,
  GraphiX,
  gxMouse,
  gxCrt;

type
  PGraphiXDriver = ^TGraphiXDriver;
  TGraphiXDriver = object(TScreenDriver)
    constructor Init(AWidth, AHeight: Integer; ABPP: Word);
    destructor Done; virtual;
    procedure InitColors; virtual;
    procedure PutPixel(AX, AY: Integer; AColor: LongInt); virtual;
    function GetPixel(AX, AY: Integer): LongInt; virtual;
    procedure HLine(AX, AY, BX: Integer; AColor: LongInt); virtual;
    procedure VLine(AX, AY, BY: Integer; AColor: LongInt); virtual;
    procedure Line(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word); virtual;
    procedure Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure Bar(AX, AY, BX, BY: Integer; AColor: LongInt); virtual;
    procedure SetViewPort(AX, AY, BX, BY: Integer); virtual;
  end;

  PGraphiXMouseDriver = ^TGraphiXMouseDriver;
  TGraphiXMouseDriver = object (TMouseDriver)
    constructor Init;
    destructor Done; virtual;
    procedure GetState(var _x,_y: Integer; var _butt: Byte); virtual;
    procedure SetPos(_x,_y: Integer); virtual;
    procedure SetArea(x1,y1,x2,y2: Integer); virtual;
    procedure Show; virtual;
    procedure Hide; virtual;
    procedure NotMove; virtual;
    procedure LetMove; virtual;
    procedure SetCursor( _Cursor: TCursor ); virtual;
  end;

implementation

{ ===> TGraphiXDriver }

procedure GraphiXDriver_DeRGB(c: LongInt; var r, g, b: Byte);
begin
  c := getrgbcolor32(c);
  b := c and $FF; c := c shr 8;
  g := c and $FF; c := c shr 8;
  r := c and $FF;
end;

constructor TGraphiXDriver.Init(AWidth, AHeight: Integer; ABPP: Word);

begin
  inherited Init(AWidth, AHeight, ABPP);
  InitGraphiX(ig_vesa,ig_lfb);
  case BPP of
  16: SetModeGraphiX(Width,Height,ig_col16);
  24: SetModeGraphiX(Width,Height,ig_col24);
  32: SetModeGraphiX(Width,Height,ig_col32);
  else
    SetModeGraphiX(Width,Height,ig_col8);
  end;
  rgb := rgbcolorRGB;
  dergb := @GraphixDriver_DeRGB;

  InitColors;
end;

procedure TGraphiXDriver.InitColors;
begin
  inherited InitColors;
end;

procedure TGraphiXDriver.PutPixel(AX, AY: Integer; AColor: LongInt);
begin
  GraphiX.PutPixel(AX, AY, AColor);
end;

function TGraphiXDriver.GetPixel(AX, AY: Integer): LongInt;
begin
  GetPixel:=GraphiX.GetPixel(AX, AY) and (LongInt(1) shl BPP - 1);
end;

procedure TGraphiXDriver.HLine(AX, AY, BX: Integer; AColor: LongInt);
begin
  Line(AX, AY, BX, AY, AColor);
end;

procedure TGraphiXDriver.VLine(AX, AY, BY: Integer; AColor: LongInt);
begin
  Line(AX, AY, AX, BY, AColor);
end;

procedure TGraphiXDriver.Line(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GraphiX.Line(AX, AY, BX, BY, AColor);
end;

procedure TGraphiXDriver.PutLine(AX, AY, ASize: Integer; var ALine; AFlags: Word);
begin
  inherited PutLine(AX, AY, ASize, ALine, AFlags);
end;

procedure TGraphiXDriver.Rectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GraphiX.Rectangle(AX, AY, BX, BY, AColor);
end;

procedure TGraphiXDriver.DottedRectangle(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  inherited DottedRectangle(AX, AY, BX, BY, AColor);
end;

procedure TGraphiXDriver.Bar(AX, AY, BX, BY: Integer; AColor: LongInt);
begin
  GraphiX.Bar(AX, AY, BX, BY, AColor);
end;

procedure TGraphiXDriver.SetViewPort(AX, AY, BX, BY: Integer);
begin
  GraphiX.GraphWin(AX, AY, BX, BY);
end;

destructor TGraphiXDriver.Done;
begin
  if Status = stOk then
    DoneGraphix;
end;
{ <=== TGraphiXDriver }

{ => TGraphiXMouseDriver }
constructor TGraphiXMouseDriver.Init;
begin
  inherited Init;
  InitMouse;
  IsMouse := True;
  MouseOff;
{  Visible := False;}
  SetPos(Screen^.Width div 2, Screen^.Height div 2);
end;

procedure TGraphiXMouseDriver.GetState(var _x,_y: Integer; var _butt: Byte);
var
  __x, __y: LongInt;
begin
  if not IsMouse then Exit;
  MouseCoords(__x, __y);
  _x := __x and $FFFF;
  _y := __y and $FFFF;
  _butt := MouseButton;
  inherited SetPos(_x, _y);
end;

procedure TGraphiXMouseDriver.SetPos(_x,_y: Integer);
begin
  if not IsMouse then Exit;
{  if Visible
    then begin}
{      Hide;  }                 {}
      inherited SetPos(_x,_y); {}
      SetMousePosition(_x, _y);
{      Show;}
{    end
    else begin
      inherited SetPos(_x,_y);
      SetMousePosition(_x, _y);
    end;}
  X := _x; Y := _y;
end;

procedure TGraphiXMouseDriver.SetArea(x1,y1,x2,y2: Integer);
begin
  if not IsMouse then Exit;
  SetMouseArea(x1, y1, x2, y2);
end;

procedure TGraphiXMouseDriver.Show;
begin
  if not IsMouse then Exit;
{  MouseOn;}
  inherited Show;
{  MouseDr7.ShowMouse;}
{  Visible := True;}
end;

procedure TGraphiXMouseDriver.Hide;
begin
  if not IsMouse then Exit;
  inherited Hide;
{  MouseDr7.HideMouse;}
{  MouseOff;}
{  Visible := False;}
end;

procedure TGraphiXMouseDriver.NotMove;
begin
  if not IsMouse then Exit;
  DisableMouse;
end;

procedure TGraphiXMouseDriver.LetMove;
begin
  if not IsMouse then Exit;
  EnableMouse;
end;

procedure TGraphiXMouseDriver.SetCursor( _Cursor: TCursor );
begin
  if not IsMouse then Exit;
  inherited SetCursor( _Cursor );
{  MouseDr7.ChangeCursor( _Cursor+1 );}
end;

destructor TGraphiXMouseDriver.Done;
begin
  if not IsMouse then Exit;
  inherited Done;
end;
{ <= TGraphiXMouseDriver }

begin
{$ifndef Linux}
  gDrivers.KeyPressed  := @gxcrt.KeyPressed;
  gDrivers.ReadKey     := @gxcrt.ReadKey;
  gDrivers.Delay       := @gxcrt.Delay;
  gDrivers.GetScanCode := @gDrivers.GetScanCodeFromReadKey;
{$endif}
end.
