Uses BMP, Graph;
Var
   FileName: String;
   P: Pointer;
   X, Y: DWord;
   i: Longint;

Begin
   If ParamCount <> 1 then
   Begin
      WriteLn('Usage:');
      WriteLn('  BMPVIEW <filename.bmp>');
      Halt
   End;
   OpenBMPFile(ParamStr(1));
   If BMPResult <> 0 then
   Begin
      WriteLn(BMPResultStrings[BMPResult]);
      Halt
   End;
   GetMem(P, GetBMPImageSize);
   ReadBMPFile(P);
   CloseBMPFile;
   If BMPResult <> 0 then
   Begin
      WriteLn(BMPResultStrings[BMPResult]);
      Halt
   End;
   If not DetectBestResolution(BMPInfo.Width, BMPInfo.Height, X, Y) then
   Begin
      WriteLn('Image is too large (more than ',X,'x',Y,' pixels)!');
      Halt
   End;
   SetSVGAMode(X, Y, (BMPInfo.BitPerPixel+7) and $F8, LFBorBanked);
   If GraphResult <> 0 then
   Begin
      WriteLn(GraphErrorMsg(GraphResult), ' (',X,'x',Y,'x',(BMPInfo.BitPerPixel+7) and $F8,'bits)');
      Halt
   End;
   For i := 0 to BMPPalette.Total-1 do
      With BMPPalette.Col[i] do
         SetRGBPalette(i, R div 4, G div 4, B div 4);
   X := (X-BMPInfo.Width) shr 1;
   Y := (Y-BMPInfo.Height) shr 1;
   PutSprite(X, Y, X+BMPInfo.Width-1, Y+BMPInfo.Height-1, P^);
   Asm
      xor ah,ah
      int 16h
   End;
   ScanBMPPalette;
   CloseGraph;
   WriteLn('Writting BMP-file...');
   WriteBMPFile('_output.bmp', BMPInfo.Width, BMPInfo.Height, (BMPInfo.BitPerPixel+7) and $F8, P);
   WriteLn(BMPResultStrings[BMPResult])
End.
