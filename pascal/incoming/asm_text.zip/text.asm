.model tiny
.code
  org 100h
.386

spaces=3
color=20h
waiting=3000
Z:

include macr.asm
	cld			;for string operations...
	mov	ax,13h
	int	10h
	mov	ah,9
	mov	dx,offset text
	int	21h		;input string with DOS
	


;_________________________calculate constants__________________________
	mov	di,offset text
	mov	al,'$'
	xor	cx,cx
scan:	inc	cx
	scasb
	jnz	scan		;cx--length of character string.
	dec	cx		;'$'--is not in string...
	mov	ax,cx		;al==leng
	
	imul	cx,cx,8*4
	mov	count2,cx	;leng*8*4
	
	dec	al		;if string is full no "inc bx" needed
	mov	dx,word ptr 40	;40 symbols in source line
	div	dl
	mov	bl,al
	inc	bx		

;calculate count...
	xor	cx,cx
	mov	cl,bl
	imul	cx,cx,40
	sub	cl,10
	imul	cx,cx,8*4
	mov	count,cx	;(40*lines-10)*8*4
;-----------------------

	mov	lines,bl	;bl -- number of lines
	mov	dx,8		;8-symbol height



;____________________________create data________________________________
	push	0a000h
	pop	ds		;es=cs...
	mov	di,offset data
	xor	ax,ax			
	
load:	
	mov	si,ax	
;---
	push	ax bx
line:	mov	cx,320


l1:	xor	eax,eax
	lodsb
	cmp	al,7		;if was white then color it.
	jnz	l2

	mov	al,dl		
	add	al,color

l2:	stosd
	loop	l1


	dec	bx
	jz	next_lin
	add	si,8*320-320
	jmp	line	
;---	
next_lin:
	pop	bx ax

	add	ax,320
	dec	dx
	jnz	load
	
	mov	ax,0
	mov	cx,320
	rep	stosb

	mov	ax,13h
	int	10h



;__________________________input colored data to screen_______________________________

	mov	bx,0a000h
	mov	es,bx		;0a000h
	push	cs
	pop	ds		;ds=cs
	xor	bx,bx
	
main:	mov	si,offset data	
	mov	di,320*100	;di-center of screen
	mov	dx,8		;symb. heigth
	add	si,bx		;offset of current screen
	
next_l:	mov	cx,320/4
	rep	movsd

	add	di,320*spaces
	add	si,count

	dec	dx
	jnz	next_l
	
	delay	0,waiting
	presskey
	
	inc	bx
	cmp	bx,count2 	;leng*8*4
	jnz	main
	xor	bx,bx
	jmp	main

exit:	mov	ax,word ptr 03h
	int	10h
	retn
lines	db ?
count	dw ?
count2	dw ?
text 	db "          This sentence is long bQ123456$";must be 10 spaces first...
data:
	end Z
