comment !
contains macross:

print_r	macro 	reg1 	 		
pr_str 	macro sss
delay	macro numH,numL	
readkey	macro



.model tiny
.code
  org 100h

include macr.asm
Z:
	end Z
!
;========================
;prints 4 first bits of al
print_al macro
	cmp	al,00Ah			;translate 4 first bit of al
	sbb	al,69h			;to ASCII
	das				
	
	mov	dl,al			;and show this symbol
	mov	ah,2h
	int	21h
endm	
;========================	
;prints a 32bit register
print_r	macro 	reg1 	 		;show hex value of al
	push	ax reg1 dx
	mov	ax,reg1

	push	ax
	xchg	ah,al
	mov	dh,al
	and	dh,0Fh
	shr	al,4h
	print_al
	mov	al,dh
	print_al

	pop	ax
	mov	dh,al
	and	dh,0Fh
	shr	al,4h
	print_al
	mov	al,dh
	print_al

	mov	dl,0Dh			
	int	21h
	mov	dl,0Ah			;CR
	int	21h
	
	pop	dx reg1 ax
	endm
;=========================
;shows a string
pr_str 	macro sss,no_cr
	num=0
	push ax dx

	irpc char,<sss>
	mov	byte ptr buffer[num],'&char&'	
	num=num+1
	endm
ifb<no_cr>	
	mov 	byte ptr buffer[num]  ,0Dh
	mov 	byte ptr buffer[num+1],0Ah	;CR
	num=num+2
endif
	mov 	byte ptr buffer[num],'$'
	mov	ah,09h
	mov	dx,offset buffer
	int	21h		
	pop dx ax
endm
;=========================
;do some delay
delay	macro numH,numL	
	push	cx ax dx
	mov	ah,86h
	mov	cx,word ptr numH
	mov	dx,word ptr numL
	int	15h		
	pop	dx ax cx
endm	
;=========================
readkey	macro
	local a1
	push	ax
a1:	mov	ah,1h               ;Check for a key
	int	16h
	jz	a1

	xor	ah,ah               ;Eat the key
	int	16h
	pop	ax
endm
;=========================
presskey macro
	local a1
	push	ax
	mov	ah,1h               ;Check for a key
	int	16h
	pop	ax
	jnz	exit
endm
;=========================
;shows registers and exit
showregs macro
	push	ax
	mov	ax,0003h
	int	10h
	pop	ax
	
	pr_str	<AX is:>,n
	print_r	ax
	pr_str	<BX is:>,n
	print_r	bx
	pr_str	<CX is:>,n
	print_r	cx
	pr_str	<DX is:>,n
	print_r	dx
	pr_str	<SI is:>,n
	print_r	si
	pr_str	<DI is:>,n
	print_r	di
	pr_str	<DS is:>,n
	print_r	ds
	pr_str	<ES is:>,n
	print_r	es
	ret
endm
;=========================















	