unit mg_mouse;

interface
uses mouse,graph;
const MouseWidth  = 15 ; {������}
      MouseHeight = 15 ; {������}
Type OnButtonPressedEvent     = procedure (mask,x,y:word; pressed_released:bool);
var  OnLeftButtonPressedHandler,
     OnLeftButtonReleasedHandler,
     OnRightButtonPressedHandler,
     OnRightButtonReleasedHandler,
     OnLeftRightButtonsPressedHandler: OnButtonPressedEvent;
     LastX,LastY              : word;
     LLastX,LLastY            : word;
Procedure __InitMouse;
Procedure __HideMouse;
Procedure __ShowMouse;
Procedure __DoneMouse;

implementation
uses mouse,crt;
type MouseZone = array [0..MouseHeight,0..MouseWidth] of byte;
const
       DefMouseCursor :  MouseZone               = ((  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0, 15, 15, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0, 15, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0, 15, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0, 15, 15, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0, 15,  0,  0, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0, 15, 15, 15,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0, 15, 15, 15,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0, 15, 15, 15,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0, 15, 15,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0));

       DefScreenMask  :  MouseZone               = ((  0,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,  0,$ff,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    (  0,$ff,$ff,$ff,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,  0,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,  0,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,  0,  0,  0,  0,  0,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,  0,  0,  0,  0,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff),
                                                    ($ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff,$ff));
var PScreen : pointer;
    MouseCursor : MouseZone := DefMouseCursor;
    ScreenMask  : MouseZone := DefScreenMask;
    HiddenMouse : bool;
Procedure PutMouseCursor(x,y:DWord);
var i,j : dword;
begin
 for i:= 0 to MouseHeight do
 for j:= 0 to MouseWidth do
  PutPixel(j+x,i+y,(GetPixel(j+x,i+y) AND ScreenMask[i,j]) XOR MouseCursor[i,j]);
end;

Procedure UserMouseMoveOrButtonPressed(Mask, Buttons, X, Y, MovX, MovY : System.Word);
var m: System.Word;
begin
 PutImage(LastX ,LastY ,PScreen^);
 GetImage(X ,Y ,X+MouseWidth,Y+MouseHeight,PScreen^);
 if not HiddenMouse then PutMouseCursor(x,y);
 LLastX:=LastX;
 LLastY:=LastY;
 LastX:=x;
 LastY:=y;
 m:=mask;
 if m>=$01 then begin
                 PutImage(LastX ,LastY ,PScreen^);
                if (m=$03) or (m=$02) then begin
                                            OutTextXY(0,0,'buttons=$02');
                                            OnLeftButtonPressedHandler(mask,X,Y,true);
                                           end;
                if (m=$05) or (m=$04) then begin
                                            OutTextXY(0,20,'buttons=$04');
                                            OnLeftButtonReleasedHandler(mask,X,Y,false);
                                           end;
                if (m=$08) or (m=$09) then begin
                                            OutTextXY(500,0,'buttons=$08');
                                            OnRightButtonPressedHandler(mask,X,Y,true);
                                           end;
                if (m=$10) or (m=$11) then begin
                                            OutTextXY(500,20,'buttons=$10');
                                            OnRightButtonReleasedHandler(mask,X,Y,false);
                                           end;
                if (m=$0A) or (m=$0B) then begin
                                            OutTextXY(500,40,'buttons=$0A');
                                            OnLeftRightButtonsPressedHandler(mask,X,Y,true);
                                           end;

                       GetImage(X ,Y ,X+MouseWidth,Y+MouseHeight,PScreen^);
                       if not HiddenMouse then PutMouseCursor(x,y);
                end;
end;

Procedure __InitMouse;
begin
 initmouse;
 SetMouseRange(0,0,GetMaxX,GetMaxY);
 LastX:=GetMouseX;
 LastY:=GetMouseY;
 GetMem(PScreen,ImageSize(GetMouseX, GetMouseY, GetMouseX+MouseWidth, GetMouseY+MouseHeight));
 GetImage(GetMouseX, GetMouseY, GetMouseX+MouseWidth, GetMouseY+MouseHeight, PScreen^);
 SetMouseHandler($01+$02+$04+$08+$10,UserMouseMoveOrButtonPressed);
 HiddenMouse:=false;
 __ShowMouse;
end;

Procedure __HideMouse;
begin
if not HiddenMouse then begin
                        PutImage(LastX ,LastY ,PScreen^);
                        HiddenMouse:=true;
                        end;
end;

Procedure __ShowMouse;
begin
if HiddenMouse then begin
                    PutImage(LastX ,LastY ,PScreen^);
                    GetImage(GetMouseX,GetMouseY,GetMouseX+MouseWidth,GetMouseY+MOuseHeight,PScreen^);
                    PutMouseCursor(GetMouseX,GetMouseY);
                    HiddenMouse:=false;
                    end;
end;

Procedure __DoneMouse;
begin
 DoneMouse;
end;

begin
end.