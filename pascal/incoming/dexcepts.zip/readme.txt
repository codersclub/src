EXCEPTS

EXAMPLE

see demo.pas file

UNIT DESCRIPTION

This unit allows to bypass known fatal error in Pascal,
finalizing program with 'Runtime error' message.

For using the unit, it is necessary to connect it. but there is important condition:
as the unit modifies ExitProc variable, then the unit must be last in 
the units' list. otherwise when fatal error occuring the Pascal begin to execute
ending actions. for this bypassing our unit must (as last in the list) catch
this event and retrn control for the main program. in this time it restores 
variables ErrorAddr to nil and ExitCode to 0.

ROUTINES DESCRIPTION

function initializes exception handle (let's speak in the Dlphi terms)
function Try: Boolean;

function returns non-zero code of fatal error. for the following usage of this
code you need write it in a variable, because of at the first execution the 
function wipes value in internal variable
function ExceptError: Word;

this rotine gives to user make itself errors as infinitly long time
in other words, it returns into the begin of exception handle
procedre Resume;

these routines allow switch on and switch off exception handling.
by default, it is to switch on the handling by calling of InitExcepts
and after that the handling might be switched off by DoneExcepts 
indefinite times and switched on
procedure InitExcepts;
procedure DoneExcepts;

