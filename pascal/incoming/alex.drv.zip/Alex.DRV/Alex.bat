..\..\exe_tpu\alex /SkipMoveTop /P8,6  %1 %2 %3 %4 %5 %6 %7

