uses qwiksort;

function func(var a;var b):integer;
var
  d:longint;
begin
  d := longint(a) - longint(b);
  if d <> 0 then func := d div abs(d) else func := 0;
end;

var
  i,count:longint;
  mas:^longint;
begin
  writeln('=======================================');
  randomize;
  count := random(100);
  getmem(mas,sizeof(longint)*count);
  for i := 0 to count-1 do mas[i] := random(1000);
  qsort(mas,count,sizeof(longint),@func);
  for i := 0 to count-1 do write(mas[i]:3,' ');
  freemem(mas,sizeof(longint)*count);
  writeln;
end.