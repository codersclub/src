//
// object.cpp
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#include <cpcl.h>

CObject::CObject()
{
};

CObject::~CObject()
{
};
