//
// stream.cpp
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#include <cpcl.h>

#if defined(WIN)
	#include <windows.h>
#elif defined(LINUX)
	#include <stdio.h>
#endif

//////////////////////////////////////////////////////////
// construction/destruction

CStream::CStream()
{
#if defined(WIN)
	m_pDescr = INVALID_HANDLE_VALUE;
#elif defined(LINUX)
	m_pDescr = NULL;
#endif
};

CStream::CStream(CString name)
{
#if defined(WIN)
	m_pDescr = INVALID_HANDLE_VALUE;
#elif defined(LINUX)
	m_pDescr = NULL;
#endif
	m_name = name;
};

CStream::CStream(pstr_t pszName)
{
#if defined(WIN)
	m_pDescr = INVALID_HANDLE_VALUE;
#elif defined(LINUX)
	m_pDescr = NULL;
#endif
	m_name = pszName;
};

//////////////////////////////////////////////////////////
// other functions

void CStream::SetName(pstr_t pszName)
{
	m_name = pszName;
};

void CStream::SetName(CString name)
{
	m_name = name;
};

CString CStream::GetName()
{
	return m_name;
};

void CStream::GetName(pstr_t pszBuffer)
{
	STRCPY(pszBuffer, (pstr_t) m_name);
};

bool CStream::IsOpen()
{
#if defined(LINUX)
	return m_pDescr != NULL;
#elif defined(WIN)
	return m_pDescr != INVALID_HANDLE_VALUE;
#endif
};

