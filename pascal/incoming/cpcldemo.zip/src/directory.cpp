//
// directory.cpp
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#include <cpcl.h>

#if defined(LINUX)
	#include <sys/types.h>
	#include <sys/stat.h>
	#include <dirent.h>
	#include <unistd.h>
#elif defined(WIN)
	#include <windows.h>
#endif

////////////////////////////////////////////////////////
// create/remove

bool CDirectory::Create()
{
#if defined(LINUX)
	return mkdir((pstr_t) m_name, 0711) == 0;
#elif defined(WIN)
	SECURITY_ATTRIBUTES secattr;
	secattr.nLength = sizeof(secattr);
	secattr.lpSecurityDescriptor = NULL;
	secattr.bInheritHandle = TRUE;
	return CreateDirectory((pstr_t) m_name, &secattr) != 0;
#endif
};

bool CDirectory::Remove()
{
#if defined(LINUX)
	return unlink((pstr_t) m_name) == 0;
#elif defined(WIN)
	return RemoveDirectory((pstr_t) m_name) != 0;
#endif
};

////////////////////////////////////////////////////////
// globbing

bool CDirectory::Glob(CArray<CFile>& files)
{
#if defined(LINUX)
	return Glob(files, S("*"));
#elif defined(WIN)
	return Glob(files, S("*.*"));
#endif
};

bool CDirectory::Glob(CArray<CFile>& files, pstr_t pszWildcard)
{
	CWildcard wild;

#if defined(LINUX)

	dirent* pdir;
	DIR* pdes;
	
	pdes = opendir((pstr_t) m_name);
	if (pdes = NULL)
		return false;
	
	while ((pdir = readdir(pdes)) != NULL)
	{
		wild = pdir->d_name;
		if (wild == pszWildcard)
			files += CString(pdir->d_name);
	};
	
	if (closedir(pdes) != 0)
		return false;
	
#elif defined(WIN)

	HANDLE hdes;
	WIN32_FIND_DATA found;

	hdes = FindFirstFile(pszWildcard, &found);
	if (hdes == INVALID_HANDLE_VALUE)
		return false;
	do
	{
		wild = found.cFileName;
		if (wild == pszWildcard)
			files += CFile(found.cFileName);
	}
	while (FindNextFile(hdes, &found));

	if (!FindClose(hdes))
		return false;
	
#endif

	return true;
};
