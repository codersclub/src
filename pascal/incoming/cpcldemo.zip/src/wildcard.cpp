//
// wildcard.cpp
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#include <cpcl.h>

bool CWildcard::operator == (pstr_t pszWildcard)
{
	return operator == (CString(pszWildcard));
};

bool CWildcard::operator == (const CString& wildcard)
{
	pstr_t pszCurWild = ((CWildcard&) wildcard).m_pszBuffer;
	pstr_t pszCurBuf = m_pszBuffer;
	CString pattern;
	int_t iFound;

	for ( ; ; pszCurWild++, pszCurBuf++)
	{
		switch (*pszCurWild)
		{
		case S('?'): // ���������� ���� ������
			break;
		case S('*'):
			pszCurWild++;
			// ����� ��������� (�� ����. ����. �������)
			for (; *pszCurWild != S('?')
				&& *pszCurWild != S('*')
				&& *pszCurWild != S('\0'); pszCurWild++)
				pattern += *pszCurWild;
			pszCurWild--;
			iFound = Find(pattern, pszCurBuf - m_pszBuffer, -1);
			if (iFound == -1) return false;
			pszCurBuf = m_pszBuffer + iFound + pattern.GetLength();
			pattern.Empty();
			break;
		case S('\0'):
			return true;
		default:
			if (*pszCurWild != *pszCurBuf) return false;
		}; // switch
	}; // for
	return true;
};
