//
// file.cpp
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#include <cpcl.h>

#if defined(WIN)
	#include <windows.h>
#elif defined(LINUX)
	#include <stdio.h>
#endif

//////////////////////////////////////////////////////
// construction/destruction

CFile::~CFile()
{
	Close();
};

//////////////////////////////////////////////////////
// open/close

bool CFile::Open(int_t iFlags)
{
	if (IsOpen()) Close();

#if defined(WIN)

	SECURITY_ATTRIBUTES secattr;
	ulong_t ulAccess;
	ulong_t ulCreate;

	secattr.nLength = sizeof(secattr);
	secattr.lpSecurityDescriptor = NULL;
	secattr.bInheritHandle = TRUE;

	// ���������� ����� ������ ������
	ulAccess = 0;
	if (iFlags & FOF_READ)
	{
		ulAccess |= GENERIC_READ;
		ulCreate = OPEN_EXISTING;
	};
	if (iFlags & FOF_WRITE)
	{
		ulAccess |= GENERIC_WRITE;
		ulCreate = CREATE_ALWAYS;
	};
	// FO_APPEND - n/i

	// ������� ����
	m_pDescr = CreateFile((pstr_t) m_name, ulAccess, 
		FILE_SHARE_READ, &secattr, ulCreate, 
		FILE_ATTRIBUTE_NORMAL, NULL);
	if (m_pDescr == INVALID_HANDLE_VALUE)
		return false;

#elif defined(LINUX)
	
	char_t szMode[4];
	pchar_t pszMode = szMode;
	
	if (iFlags & FOF_READ) *pszMode++ = 'r';
	if (iFlags & FOF_WRITE) *pszMode++ = 'w';
	if (iFlags & FOF_APPEND) *pszMode++ = 'a';
	*pszMode = '\0';
	
	m_pDescr = (FILE*) fopen((pstr_t) m_name, szMode);
	if (m_pDescr == NULL)
		return false;
	
#endif

	return true;
};

bool CFile::Close()
{
#if defined(WIN)

	if (m_pDescr == INVALID_HANDLE_VALUE) // already closed
		return false;
	if (!CloseHandle(m_pDescr))
		return false;
	m_pDescr = INVALID_HANDLE_VALUE;

#elif defined(LINUX)
	
	if (m_pDescr == NULL) // already closed
		return false;
	if (fclose((FILE*) m_pDescr) != 0)
		return false;
	m_pDescr = NULL;
	
#endif

	return true;
};

////////////////////////////////////////////////////////
// input/output

bool CFile::Read(pvoid_t pBuffer, int_t iBufferSize, pint_t piBytesRead)
{
#if defined(WIN)

	if (!ReadFile(m_pDescr, pBuffer, (ulong_t) iBufferSize, 
		(pulong_t) piBytesRead, NULL))
		return false;

#elif defined(LINUX)
	
	*piBytesRead = fread(pBuffer, 1, iBufferSize, (FILE*) m_pDescr);
	if (ferror((FILE*) m_pDescr))
		return false;
	
#endif

	return true;
};

bool CFile::Write(pvoid_t pBuffer, int_t iBufferSize, pint_t piBytesWritten)
{
#if defined(WIN)

	if (!WriteFile(m_pDescr, pBuffer, (ulong_t) iBufferSize, 
		(pulong_t) piBytesWritten, NULL))
		return false;

#elif defined(LINUX)
	
	*piBytesWritten = fwrite(pBuffer, 1, iBufferSize, (FILE*) m_pDescr);
	
#endif

	return true;
};

/////////////////////////////////////////////////////////
// other functions

int_t CFile::GetLength()
{
	int_t iLength;

#if defined(WIN)

	if (m_pDescr == INVALID_HANDLE_VALUE)
	{
		if (!Open(0)) return -1;
		iLength = (int_t) ::GetFileSize(m_pDescr, NULL);
		if (!Close()) return -1;
	}
	else
		iLength = (int_t) ::GetFileSize(m_pDescr, NULL);

	if (iLength == 0xFFFFFFFF) return -1;

#elif defined(LINUX)

	// n/i

#endif

	return iLength;
};
