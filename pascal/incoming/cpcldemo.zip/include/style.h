//
// style.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#ifndef CPCL_STYLE_H_INCLUDED
#define CPCL_STYLE_H_INCLUDED

#ifdef CPCL_LOWERCASE

	// CApp
	#define CApp capp
	#define Main main
	// CArray
	#define CArray carray
	#define ReallocBuffer reallocbuffer
	#define GetCount getcount
	#define SetCount setcount
	#define IsEmpty isempty
	#define GetLast getlast
	// CDirectory
	#define CDirectory cdirectory
	#define Create create
	#define Glob glob
	#define Remove remove
	// CFile
	#define CFile cfile
	#define Close close
	#define GetLength getlength
	#define Open open
	#define Read read
	#define Write write
	// CObject
	#define CObject cobject
	// CProgram
	#define CProgram cprogram
	#define Main main
	// CStream
	#define CStream cstream
	#define GetName getname
	#define IsOpen isopen
	#define Open open
	#define Read read
	#define SetName setname
	#define Write write
	// CString
	#define CString cstring
	#define Empty empty
	#define Find find
	#define GetAt getat
	#define GetLength getlength
	#define IsEmpty isempty
	#define ReallocBuffer reallocbuffer
	#define RecalcLength recalclength
	#define Replace replace
	#define Reverse reverse
	#define SetAt setat
	#define SetLength setlength
	// CWildcard
	#define CWildcard cwildcard

#endif // ifdef CPCL_LOWERCASE

#endif // ifndef CPCL_STYLE_H_INCLUDED
