//
// program.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

class CProgram : public CObject
{
	friend int main(int_t argc, pstr_t* argv);
	
public:
	CArray<CString> m_args;
	CString m_cmd;

	virtual int_t Main() = NULL;
};
