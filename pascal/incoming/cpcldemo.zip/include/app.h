//
// app.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

class CApp : public CProgram
{
public:
	int_t Main();
	bool processfile(cstring filename);
	bool detectencoding(puchar_t pbuf, int_t ibufsize);
	int_t recode(puchar_t psrcbuf, puchar_t pdstbuf, int_t isrcbufsize);
};
