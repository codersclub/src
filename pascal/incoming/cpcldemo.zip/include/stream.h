//
// stream.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

class CStream : public CObject
{
protected:
	CString m_name;
	pvoid_t m_pDescr;

public:
	// construction/destruction
	CStream();
	CStream(CString name);
	CStream(pstr_t pszName);
	// input/output
	virtual bool Read(pvoid_t pBuffer, int_t iBufferSize, pint_t piBytesRead) = NULL;
	virtual bool Write(pvoid_t pBuffer, int_t iBufferSize, pint_t piBytesWritten) = NULL;
	// other functions
	void SetName(pstr_t pszName);
	void SetName(CString name);
	CString GetName();
	void GetName(pstr_t pszBuffer);
	bool IsOpen();
};
