//
// unstyle.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

#ifndef CPCL_UNSTYLE_H_INCLUDED
#define CPCL_UNSTYLE_H_INCLUDED

#ifdef CPCL_LOWERCASE

	// CApp
	#undef CApp
	#undef Main
	// CArray
	#undef CArray
	#undef ReallocBuffer
	#undef GetCount
	#undef SetCount
	#undef IsEmpty
	#undef GetLast
	// CDirectory
	#undef CDirectory
	#undef Create
	#undef Glob
	#undef Remove
	// CFile
	#undef CFile
	#undef Close
	#undef GetLength
	#undef Open
	#undef Read
	#undef Write
	// CObject
	#undef CObject
	// CProgram
	#undef CProgram
	#undef Main
	// CStream
	#undef CStream
	#undef GetName
	#undef IsOpen
	#undef Open
	#undef Read
	#undef SetName
	#undef Write
	// CString
	#undef CString
	#undef Empty
	#undef Find
	#undef GetAt
	#undef GetLength
	#undef IsEmpty
	#undef ReallocBuffer
	#undef RecalcLength
	#undef Replace
	#undef Reverse
	#undef SetAt
	#undef SetLength
	// CWildcard
	#undef CWildcard

#endif

////////////////////////////////////////////////
// macro clean up

#undef STRCPY
#undef STRLEN
#undef MEMZERO

#endif // ifndef CPCL_UNSTYLE_H_INCLUDED
