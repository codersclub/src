//
// directory.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

class CDirectory : public CStream
{
public:
	// construction/destruction
	CDirectory() : CStream() {};
	CDirectory(CString name) : CStream(name) {};
	CDirectory(pstr_t pszName) : CStream(pszName) {};
	// create/remove
	bool Create();
	bool Remove();
	// globbing
	bool Glob(CArray<CFile>& files);
	bool Glob(CArray<CFile>& files, pstr_t pszWildcard);
};
