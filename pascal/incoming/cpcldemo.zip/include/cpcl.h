//
// cpcl.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//
// This header includes other headers and should not contain
//  any code.
//

// Platform definitions:
//	o	LINUX (for gcc)
//	o	WIN (for MSVC)

// Other CPCL definitions:
//	o	UNICODE		- use Unicode versions of some
//					  Windwos NT/2000/XP API functions

#include "style.h"
#include "types.h"
#include "macro.h"
#include "object.h"
#include "array.h"
#include "str.h"
#include "wildcard.h"
#include "stream.h"
#include "file.h"
#include "directory.h"
#include "program.h"
#include "app.h"
