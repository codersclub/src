//
// wildcard.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//

class CWildcard : public CString
{
public:
	// construction/destruction
	CWildcard() : CString() {};
	CWildcard(pstr_t pszString) : CString(pszString) {};
	// ��������� ���������
	bool operator == (pstr_t pszWildcard);
	bool operator == (const CString& wildcard);
};
