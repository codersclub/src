//
// types.h
// A part of CPCL, (c) 2002 by Relan.
// Main data types that are used with CPCL.
//

#ifndef CPCL_TYPES_H_INCLUDED
#define CPCL_TYPES_H_INCLUDED

// char
typedef char 					char_t;
typedef const char 				cchar_t;
typedef unsigned char 			uchar_t;
typedef const unsigned char 	cuchar_t;
typedef char* 					pchar_t;
typedef const char* 			pcchar_t;
typedef unsigned char* 			puchar_t;
typedef const unsigned char*	pcuchar_t;
// short
typedef short 					short_t;
typedef const short 			cshort_t;
typedef unsigned short 			ushort_t;
typedef const unsigned short 	cushort_t;
typedef short* 					pshort_t;
typedef const short* 			pcshort_t;
typedef unsigned short* 		pushort_t;
typedef const unsigned short*	pcushort_t;
// int
typedef int						int_t;
typedef const int				cint_t;
typedef unsigned int			uint_t;
typedef const unsigned int		cuint_t;
typedef int*					pint_t;
typedef const int*				pcint_t;
typedef unsigned int*			puint_t;
typedef const unsigned int*		pcuint_t;
// long
typedef long					long_t;
typedef const long				clong_t;
typedef unsigned long			ulong_t;
typedef const unsigned long		culong_t;
typedef long*					plong_t;
typedef const long*				pclong_t;
typedef unsigned long*			pulong_t;
typedef const unsigned long*	pculong_t;
// void pointers
typedef void*					pvoid_t;
typedef const void*				pcvoid_t;

// string char
#ifdef UNICODE
	typedef ushort_t			str_t;
	typedef cushort_t			cstr_t;
	typedef pushort_t			pstr_t;
	typedef pcushort_t			pcstr_t;
	#define S(conststr)			L ## conststr
#else
	typedef char				str_t;
	typedef const char			cstr_t;
	typedef char*				pstr_t;
	typedef const char*			pcstr_t;
	#define S(conststr)			conststr
#endif // ifdef UNICODE

// constants
#ifndef NAME_MAX
	// in Linux maximum file name length is 
	//  255 + null character, but in Windows
	//  it's 260 (including null char)
	#define NAME_MAX			260
#endif
// used by CArray, CString etc. as buffers sizes
#define BLOCK_MAX				16
#ifndef NULL
	#define NULL				0
#endif

#endif // ifndef CPCL_TYPES_H_INCLUDED
