#!/usr/bin/perl -w

use strict;

my $cc = '';
my $rm = '';

my $includedir = './include/';
my $srcdir = './src/';

# files needed for compilation
my @files = qw(app array directory file object program str stream wildcard);
my $binfile = './cpcldemo'; # output executable file name
my $cppfiles = '';
my $ofiles = '';
my $cleanfiles = '';

my $ccflags = "-DDEBUG -DCPCL_LOWERCASE -I ${includedir} ";



# list cpp files
foreach (@files)
{
	$cppfiles .= "${srcdir}$_.cpp ";
};

if ($^O eq 'MSWin32')
{
	$cc = 'cl'; # compiler command
	$rm = 'del'; # remove command
	$binfile .= '.exe';
	$ccflags .= '-DWIN -nologo';
	# list object files
	foreach (@files)
	{
		$ofiles .= "$_.obj ";
	};
	$binfile =~ s(/)(\\);
	$cleanfiles = 'cpcldemo.ilk cpcldemo.pdb vc60.idb vc60.pdb';
}
elsif ($^O eq 'linux')
{
	$cc = 'g++'; # compiler command
	$rm = 'rm -f'; # remove command
	$ccflags .= '-DLINUX ';
	# list object files
	foreach (@files)
	{
		$ofiles .= "$_.o ";
	};
}
else
{
	print "Unknown platform: $^O.\n";
	exit();
};

my $compileall = 0;
my $linkall = 0;
my $cleanall = 0;

foreach (@ARGV)
{
	$compileall = 1 if ($_ eq 'compile');
	$linkall = 1 if ($_ eq 'link');
	$cleanall = 1 if ($_ eq 'clean');
};

$compileall = $linkall = 1 if (!$compileall && !$linkall && !$cleanall);

# compile
if ($compileall)
{
	print "-------------------------------------------------------------------------------\n";
	print "                                 CONPILE \n";
	print "-------------------------------------------------------------------------------\n";
	exit() if (system("${cc} ${ccflags} -c ${cppfiles}") != 0);
};

# link
if ($linkall)
{
	print "-------------------------------------------------------------------------------\n";
	print "                                  LINK \n";
	print "-------------------------------------------------------------------------------\n";
	exit() if (system("${cc} ${ccflags} -o ${binfile} ${ofiles}") != 0);
};

#clean
if ($cleanall)
{
	print "-------------------------------------------------------------------------------\n";
	print "                                  CLEAN \n";
	print "-------------------------------------------------------------------------------\n";
	exit() if (system("${rm} ${ofiles} ${binfile} ${cleanfiles}") != 0);
};

0;
