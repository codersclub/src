object Form1: TForm1
  Left = 241
  Top = 95
  BorderIcons = []
  BorderStyle = bsSingle
  Caption = '                                     �����'
  ClientHeight = 344
  ClientWidth = 382
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Menu = MainMenu1
  OldCreateOrder = False
  OnCreate = FormCreate
  OnDestroy = FormDestroy
  OnPaint = FormPaint
  PixelsPerInch = 96
  TextHeight = 13
  object Image1: TImage
    Left = 8
    Top = 10
    Width = 322
    Height = 322
    AutoSize = True
    OnMouseDown = Image1MouseDown
  end
  object Image2: TImage
    Left = 333
    Top = 164
    Width = 40
    Height = 40
    AutoSize = True
  end
  object MainMenu1: TMainMenu
    Left = 248
    Top = 40
    object File1: TMenuItem
      Caption = '&File'
      object New1: TMenuItem
        Caption = 'New'
        OnClick = New1Click
      end
      object Load1: TMenuItem
        Caption = '&Load'
        OnClick = Load1Click
      end
      object Save1: TMenuItem
        Caption = '&Save'
        OnClick = Save1Click
      end
      object N6: TMenuItem
        Caption = '-'
      end
      object Exsit1: TMenuItem
        Caption = 'E&xit'
        OnClick = Exsit1Click
      end
    end
    object Settings1: TMenuItem
      Caption = '&Settings'
      object N1: TMenuItem
        Caption = '�������� � �����'
        Checked = True
        ImageIndex = 0
        OnClick = N1Click
      end
      object N2: TMenuItem
        Caption = '��� ����'
        ImageIndex = 1
        OnClick = N2Click
      end
      object N3: TMenuItem
        Caption = '������ ������'
        object N4: TMenuItem
          Caption = '������'
          Checked = True
          OnClick = N4Click
        end
        object N5: TMenuItem
          Caption = '�����'
          OnClick = N5Click
        end
      end
    end
    object Help1: TMenuItem
      Caption = 'H&elp'
    end
  end
  object Timer1: TTimer
    Enabled = False
    Interval = 1
    OnTimer = Timer1Timer
    Left = 136
    Top = 88
  end
  object SaveDialog1: TSaveDialog
    Filter = '����������� ����|*.sav'
    Left = 64
    Top = 88
  end
  object OpenDialog1: TOpenDialog
    Filter = '����������� ����|*.sav'
    Left = 64
    Top = 136
  end
end
