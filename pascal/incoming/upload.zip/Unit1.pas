unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, jpeg, Menus;

type
  Position = record
    x,y : integer;
  end;
  ChessType = (W,WD,B,BD,N,G);
  DeskType  = array[-3..12,-3..12] of ChessType;

  TPlayer = class(TObject)
     Start,Finish   : Position;
     Color          : boolean;{.t. ���� �����}
     Fight          : boolean;{.t. ���� ����� ����}
     Fool           : boolean;{.t. ���� ��������}
     procedure      Init (_Color : Boolean);
  end;

  TDesk = class(TObject)
    Desk        : DeskType;
    sx,sy       : word;
    procedure   Init;
    procedure   Draw(image1 : timage);
    procedure   DrawFigure(x,y:Word;f:ChessType;image1 : Timage);
    function    FightFrom (Player:TPlayer):boolean;
    function    NoFight   (Player:TPlayer):boolean;
    function    StepFrom  (Player:TPlayer):boolean;
    function    MoveFrom  (Player:TPlayer):boolean;
    function    Analise   (var Player:TPlayer;image1 : Timage):boolean;
    procedure   ScanDamk;
    function    NoStep    (Player:TPlayer):boolean;
    function    KillFrom  (Player:TPlayer):boolean;
    function    CompMoveFrom  (Player:TPlayer):boolean;
    function    CompKillFrom  (Player:TPlayer;image1 : timage):boolean;
{
    function    EscCompFrom   (Player:TPlayer):boolean;}
  end;
  TGame = class(TObject)
   Desk         : TDesk;
   GameOver     : boolean;
   Player1      : TPlayer;
   Player2      : TPlayer;
   procedure    Init;
{   procedure    Run;
   procedure    Play (var Player : TPlayer);}
   procedure    CompPlay (var Player : TPlayer;image1 : Timage);
   procedure    Done;
  end;




  TForm1 = class(TForm)
    Image1: TImage;
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    Settings1: TMenuItem;
    Load1: TMenuItem;
    Save1: TMenuItem;
    Exsit1: TMenuItem;
    N1: TMenuItem;
    N2: TMenuItem;
    Help1: TMenuItem;
    N3: TMenuItem;
    N4: TMenuItem;
    N5: TMenuItem;
    New1: TMenuItem;
    N6: TMenuItem;
    Image2: TImage;
    Timer1: TTimer;
    SaveDialog1: TSaveDialog;
    OpenDialog1: TOpenDialog;
    procedure FormCreate(Sender: TObject);
    procedure FormDestroy(Sender: TObject);
    procedure Image1MouseDown(Sender: TObject; Button: TMouseButton;
      Shift: TShiftState; X, Y: Integer);
    procedure N2Click(Sender: TObject);
    procedure N1Click(Sender: TObject);
    procedure N4Click(Sender: TObject);
    procedure N5Click(Sender: TObject);
    procedure New1Click(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure Exsit1Click(Sender: TObject);
    procedure Save1Click(Sender: TObject);
    procedure Load1Click(Sender: TObject);
    procedure FormPaint(Sender: TObject);private
    { Private declarations }
  public
    { Public declarations }
  end;
Const
   DeskInit : DeskType = ((G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,N,W,N,W,N,W,N,W,G,G,G,G),
                          (G,G,G,G,W,N,W,N,W,N,W,N,G,G,G,G),
                          (G,G,G,G,N,W,N,W,N,W,N,W,G,G,G,G),
                          (G,G,G,G,N,N,N,N,N,N,N,N,G,G,G,G),
                          (G,G,G,G,N,N,N,N,N,N,N,N,G,G,G,G),
                          (G,G,G,G,B,N,B,N,B,N,B,N,G,G,G,G),
                          (G,G,G,G,N,B,N,B,N,B,N,B,G,G,G,G),
                          (G,G,G,G,B,N,B,N,B,N,B,N,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G),
                          (G,G,G,G,G,G,G,G,G,G,G,G,G,G,G,G));

var
   tmr : integer;
  Form1: TForm1;
  _str_black_ : string;
  _str_white_ : string;
  _str_black_d_ : string;
  _str_white_d_ : string;
  _back_ : Tpicture;
  _black_ : TImage;
  _white_ : Timage;
  _black_d_ : TImage;
  _white_d_ : Timage;
  _desk_ : Tpicture;

  p1,p2 : boolean;

{  Desk : Tdesk;}
  Game : Tgame;
  selflag,_selflag : boolean;
  movedone : boolean;
  ksx,ksy,_ksx,_ksy : integer;
  first : boolean;
implementation

{$R *.DFM}


procedure delay;
begin
 tmr:=0;
 form1.Timer1.enabled:=true;
 form1.image1.enabled:=false;
 while (tmr<5) do
  application.ProcessMessages;
 form1.Timer1.enabled:=false;
 form1.image1.enabled:=true;
end;

procedure Tdesk.ScanDamk;
{���������� ����� � ����� ���� ��� �������� ������ �������}
var
 i : byte;
begin
 for i := 1 to 8 do
  begin
   if Desk[1,i] = B then Desk[1,i] := BD;
   if Desk[8,i] = W then Desk[8,i] := WD;
  end;
end;

procedure TDesk.Init;
begin
  Desk:=DeskInit;
end;

procedure TDesk.Draw;{������ ����� � ������ �� ������ ������� �����}
var
  i,j   : byte;
begin
 with image1.canvas do
  begin
   draw(0,0,_desk_.Graphic);{ Tcanvas}
{   Pen.width:=2;
   pen.color:=0;
   for i:=0 to 8 do
    begin
     moveto(1+i*40,0);
     lineto(1+i*40,image1.height);
    end;
   for i:=0 to 8 do
    begin
     moveto(0,1+i*40);
     lineto(image1.width,1+i*40);
    end;}
  end;
 for j:=0 to 7 do
   for i:=0 to 7 do
     begin
      DrawFigure(i*_black_.Width,j*_black_.height,Desk[j+1][i+1],image1);
     end;
end;

procedure TDesk.DrawFigure;
  {������ ������ ��������� ������������ ���������� � ��������� -
  - ����, �����/�� �����}
begin
 case f of
  B     :  image1.canvas.draw(x,y,_black_.Picture.Graphic);
  W     :  image1.canvas.draw(x,y,_white_.Picture.Graphic);
  BD    :  image1.canvas.draw(x,y,_black_d_.Picture.Graphic);
  WD    :  image1.canvas.draw(x,y,_white_d_.Picture.Graphic);
 end;
end;


function TDesk.FightFrom;
{���������� .t. ���� � ������� ������� ���� ����� � ��� ������ ��� - �� ����}
var
 f       : boolean;
 i       : integer;
begin
 with Player, Start do
  if Color then
    case Desk[y][x] of
      W   : f := ((Desk[y+2][x+2] = N) and (Desk[y+1][x+1] in [B,BD])) or
                 ((Desk[y+2][x-2] = N) and (Desk[y+1][x-1] in [B,BD])) or
                 ((Desk[y-2][x-2] = N) and (Desk[y-1][x-1] in [B,BD])) or
                 ((Desk[y-2][x+2] = N) and (Desk[y-1][x+1] in [B,BD]));
      WD  : begin
             i:=1;
              while Desk[y+i][x+i] = N do inc (i);
             {���� ��������� ����� � ���� �����������}
              f:=(Desk[y+i][x+i] in [B,BD]) and (Desk[y+i+1][x+i+1] = N);
             {���� ��� ����� ������ � �� ��� ��� ������ - ���� ���� (f=.t.)}
             i:=1;
              while Desk[y-i][x+i] = N do inc (i);
              f:=f or (Desk[y-i][x+i] in [B,BD]) and (Desk[y-i-1][x+i+1] = N);
              i:=1;
              while Desk[y-i][x-i] = N do inc(i);
              f:=f or (Desk[y-i][x-i] in [B,BD]) and (Desk[y-i-1][x-i-1] = N);
              i:=1;
              while Desk[y+i][x-i] = N do inc(i);
              f:=f or (Desk[y+i][x-i] in [B,BD]) and (Desk[y+i+1][x-i-1] = N);
            end;
       else f:= False;
      end
    else  case Desk[y][x] of
            B   : f := ((Desk[y+2][x+2] = N) and (Desk[y+1][x+1] in [W,WD])) or
                       ((Desk[y+2][x-2] = N) and (Desk[y+1][x-1] in [W,WD])) or
                       ((Desk[y-2][x-2] = N) and (Desk[y-1][x-1] in [W,WD])) or
                       ((Desk[y-2][x+2] = N) and (Desk[y-1][x+1] in [W,WD]));
            BD  : begin
                    i:=1;
                    while Desk[y+i][x+i] = N do inc (i);
                    f:=(Desk[y+i][x+i] in [W,WD]) and (Desk[y+i+1][x+i+1] = N);
                    i:=1;
                    while Desk[y-i][x+i] = N do inc (i);
                    f:=f or (Desk[y-i][x+i] in [W,WD]) and (Desk[y-i-1][x+i+1] = N);
                    i:=1;
                    while Desk[y-i][x-i] = N do inc(i);
                    f:=f or (Desk[y-i][x-i] in [W,WD]) and (Desk[y-i-1][x-i-1] = N);
                    i:=1;
                    while Desk[y+i][x-i] = N do inc(i);
                    f:=f or (Desk[y+i][x-i] in [W,WD]) and (Desk[y+i+1][x-i-1] = N);
                   end
                 else f := False
       end;
     FightFrom := f;
end;

function TDesk.NoFight;
{���������� .t. ���� ���� ������}
var
 f    : boolean;
 p    : position;
 _x,_y : integer;
begin
 f := False;
 p:=Player.Start;
 for _y:=1 to 8 do
  for _x:=1 to 8 do
   begin
    Player.Start.x := _x;
    Player.Start.y := _y;
    f := f or FightFrom(Player);
   end;
 Player.Start:=p;
 NoFight := not f;
end;


function TDesk.StepFrom;
{���������� .t. ���� � ������� ������ ���� ����� � �� ����� ��������}
var
 f : boolean;
begin
 with Player, Start do
  if Color  then
    case Desk[y][x] of
     W   : f := (Desk[y+1][x+1] = N) or (Desk[y+1][x-1] = N);
     WD  : f := (Desk[y+1][x+1] = N) or (Desk[y+1][x-1] = N) or
                (Desk[y-1][x+1] = N) or (Desk[y-1][x-1] = N)
            else f := False
          end
  else
    case Desk[y][x] of
     B   : f := (Desk[y-1][x+1] = N) or (Desk[y-1][x-1] = N);
     BD  : f := (Desk[y+1][x+1] = N) or (Desk[y+1][x-1] = N) or
                (Desk[y-1][x+1] = N) or (Desk[y-1][x-1] = N)
           else f := False
    end;
  StepFrom := f;
end;
function TDesk.MoveFrom;{��������� ����������� ���� �� ������ ������}
begin
 if NoFight(Player) then MoveFrom := StepFrom(Player)
 else MoveFrom := FightFrom(Player)
end;


function TDesk.Analise;
{���������� .f. ���� ��������� ��� �� ������������� �������� ����
 ���������� ���. � ���. �����. ��������� �������, � ��� ��
 ������������ ����� �� �����}
var
 f,f_                  : boolean;
 dx,dy,ix,iy,x,y,cw,cb : Integer;
begin
 with Player do
  if Color then
    begin
     case Desk[Start.y][Start.x] of
       W   : begin
              if Fight then
               f := False
              else
                f := (Finish.y-Start.y=1) and
                     (abs(Finish.x-Start.x)=1) and
                     (Desk[Finish.y][Finish.x] = N);
               x := (Start.x+Finish.x) div 2;
               y := (Start.y+Finish.y) div 2;
               Fight := (abs(Finish.y-Start.y)=2) and
                        (abs(Finish.x-Start.x)=2) and
                        (Desk[Finish.y][Finish.x]=N) and
                        (Desk[y][x] in [B,BD]);
              end;
        WD  : begin
               if Finish.x>Start.x then dx := 1 else dx := -1;
               if Finish.y>Start.y then dy := 1 else dy := -1;
               ix:=Start.x+dx;
               iy:=Start.y+dy;
               f_ := (abs(Finish.x-Start.x) = abs(Finish.y-Start.y)) and
                     (Desk[Finish.y][Finish.x]=N);
               cw:=0;
               cb:=0;
               if f_ then
                repeat
                 if Desk[iy][ix] in [W,WD] then inc(cw);
                 if Desk[iy][ix] in [B,BD] then
                  begin
                   inc(cb);
                   x:=ix;
                   y:=iy;
                  end;
                 if (ix=Finish.x) or (iy=Finish.y) then break;
                 ix :=ix + dx;
                 iy :=iy + dy;
                until (ix=Finish.x) or (iy=Finish.y);
                if Fight then f := false
                else f := (cb=0) and (cw=0) and f_;
                Fight := (cb=1) and (cw=0) and f_;
               end
               else f := False
             end;
            if f or Fight then
             begin
              Desk[Finish.y][Finish.x]:=Desk[Start.y][Start.x];
              Desk[Start.y][Start.x] := N;
              if (Finish.y = 8) then Desk[Finish.y][Finish.x]:=WD;
              if Fight then Desk[y][x]:=N;
              Draw(image1);
             end
            end
             else
              begin
               case Desk[Start.y][Start.x] of
                 B   : begin
                        if Fight then f := False else
                           f := (Start.y-Finish.y=1) and
                                (abs(Finish.x-Start.x)=1) and
                                (Desk[Finish.y][Finish.x] = N);
                           x := (Start.x+Finish.x) div 2;
                           y := (Start.y+Finish.y) div 2;
                           Fight := (abs(Finish.y-Start.y)=2) and
                                    (abs(Finish.x-Start.x)=2) and
                                    (Desk[Finish.y][Finish.x]=N) and
                                    (Desk[y][x] in [W,WD]);
                          end;
                  BD  : begin
                         if Finish.x>Start.x then dx := 1
                                              else dx := -1;
                         if Finish.y>Start.y then dy := 1
                                               else dy := -1;
                         ix:=Start.x+dx;
                         iy:=Start.y+dy;
                         f_ := (abs(Finish.x-Start.x) = abs(Finish.y-Start.y)) and
                                 (Desk[Finish.y][Finish.x]=N);
                           cw:=0;
                           cb:=0;
                           if f_ then repeat
                             if Desk[iy][ix] in [B,BD] then inc(cb);
                             if Desk[iy][ix] in [W,WD]
                                then
                                 begin
                                  inc(cw);
                                  x:=ix;
                                  y:=iy;
                                 end;
                             if (ix=Finish.x) or (iy=Finish.y) then break;
                             ix :=ix + dx;
                             iy :=iy + dy;
                           until (ix=Finish.x) or (iy=Finish.y);
                           if Fight then f := false
                                    else f:= (cb=0) and (cw=0) and f_;
                           Fight := (cw=1) and (cb=0) and f_;
                          end
                    else f := False
                   end;
                   if f or Fight
                      then begin
                            Desk[Finish.y][Finish.x]:=Desk[Start.y][Start.x];
                            Desk[Start.y][Start.x] := N;
                            if (Finish.y = 1)
                               then Desk[Finish.y][Finish.x]:=BD;
                            if Fight then Desk[y][x]:=N;
                            Draw(image1);
                           end;
                  end;
  Analise := f or Player.Fight;
end;


function TDesk.NoStep;
{���������� .T. ���� � ������ (Color=.t. - W; Color=.f. - B) ��� �����}
var
 f    : boolean;
 _x,_y : integer;
 p      : position;
begin
 p:=Player.Start;
 f := False;
 for _y:=1 to 8 do
   for _x:=1 to 8 do
    begin
     Player.Start.x := _x;
     Player.Start.y := _y;
     f := f or StepFrom(Player);
    end;
 Player.Start:=p;
 NoStep := not f;
end;


function TDesk.KillFrom;
{���������� .t. ���� �� ������ ������� ����� �������� � �� ������� ��� ���,
 � ��� �� ����� ���� ��� ������� ���������}
var
 f : boolean;
begin
 with Player, Start do
  if Color then
    case Desk[y][x] of
      W   :if (Desk[y+1][x-1] = N) and
              (Desk[y+2][x-2] <> B) and (Desk[y+2][x-2] <> BD) and
              (Desk[y+2][x] <> B) and (Desk[y+2][x] <> BD) and
              (Desk[y][x-2] <> B) and (Desk[y][x-2] <> BD)
           then
             begin
               f:=true;  Desk[y][x] := N;   Desk[y+1][x-1] := W;
             end
           else
            if (Desk[y+1][x+1] = N) and
               (Desk[y+2][x+2] <> B) and (Desk[y+2][x+2] <> BD) and
               (Desk[y+2][x] <> B) and (Desk[y+2][x] <> BD) and
               (Desk[y][x+2] <> B) and (Desk[y][x+2] <> BD)
            then
              begin
               f:=true;  Desk[y][x] := N;   Desk[y+1][x+1] := W;
              end;
          { ����� ����� ���� ����������� ������ ��� �������� ����� WD }
            else f := False
         end;
  KillFrom := f;
end;


function  TDesk.CompMoveFrom;
{������ ����� ��� ��� ����� ��� ������ ����� � ���������� .t. ����� �������}
var
 f       : boolean;
begin
 f:=false;
 with Player,Start do
  begin
   case Desk[y][x] of
    W  : begin
          if (Desk[y+1][x+1] = N) and (not f) then
           begin
            Desk[y][x]:=N;  Desk[y+1][x+1]:=W;
            f:=true;
           end;

          if (Desk[y+1][x-1] = N) and (not f) then
           begin
            Desk[y][x]:=N;  Desk[y+1][x-1]:=W;
            f:=true;
           end;
          end;
   end;
 end;
 CompMoveFrom:=f;
end;

function TDesk.CompKillFrom;
{������� ���� ��� ��������� ����� ����������, � ��� �� ���������� .t. �����
 ��� ��������}
var
 f,f1     : boolean;
 i       : integer;
begin
 f:=false;
 with Player,Start do
  begin
   While  FightFrom(Player) do
    begin
     f1:=false;
     case Desk[y][x] of
       W  : begin
              if (Desk[y+2][x+2] = N) and (Desk[y+1][x+1] in [B,BD])
                  and (not f1)  then
                begin
                  Desk[y][x]:=N;  Desk[y+2][x+2]:=W;  Desk[y+1][x+1]:=N;
                  x:=x+2;  y:=y+2;  draw(image1); f1:=true;
                  start.x := x;  start.y := y;
                  delay;
                end;

               if (Desk[y+2][x-2] = N) and (Desk[y+1][x-1] in [B,BD])
                   and (not f1)  then
                 begin
                   Desk[y][x]:=N;  Desk[y+2][x-2]:=W;  Desk[y+1][x-1]:=N;
                   x:=x-2;  y:=y+2;  draw(image1); f1:=true;
                   start.x := x;  start.y := y;
                   delay;
                  end;

               if (Desk[y-2][x-2] = N) and (Desk[y-1][x-1] in [B,BD])
                  and (not f1)  then
                  begin
                    Desk[y][x]:=N;  Desk[y-2][x-2]:=W;  Desk[y-1][x-1]:=N;
                    x:=x-2;  y:=y-2;  draw(image1); f1:=true;
                    start.x := x;  start.y := y;
                    delay;
                  end;
               if (Desk[y-2][x+2] = N) and (Desk[y-1][x+1] in [B,BD])
                  and (not f1)  then
                  begin
                    Desk[y][x]:=N;  Desk[y-2][x+2]:=W;  Desk[y-1][x+1]:=N;
                    x:=x+2;  y:=y-2;  draw(image1); f1:=true;
                    start.x := x;  start.y := y;
                    delay;
                  end;
             end;

       WD  : begin
               i:=1;
               while Desk[y+i][x+i] = N do inc (i);
               if (Desk[y+i][x+i] in [B,BD]) and (Desk[y+i+1][x+i+1] = N)
                   and not(f1) then
                   begin
                     Desk[y][x]:=N;
                     Desk[y+i][x+i]:=N;  Desk[y+i+1][x+i+1]:=WD;
                     x:=x+i+1;   y:=y+i+1;  draw(image1);  f1:=true;
                     start.x := x;  start.y := y;
                     delay;
                   end;

                i:=1;
                while Desk[y-i][x+i] = N do inc (i);
                if (Desk[y-i][x+i] in [B,BD]) and (Desk[y-i-1][x+i+1] = N)
                   and not(f1) then
                   begin
                     Desk[y][x]:=N;
                     Desk[y-i][x+i]:=N;  Desk[y-i-1][x+i+1]:=WD;
                     x:=x+i+1;   y:=y-i-1;  draw(image1);  f1:=true;
                     start.x := x;  start.y := y;
                     delay;
                   end;

                i:=1;
                while Desk[y-i][x-i] = N do inc (i);
                if (Desk[y-i][x-i] in [B,BD]) and (Desk[y-i-1][x-i-1] = N)
                   and not(f1) then
                    begin
                      Desk[y][x]:=N;
                      Desk[y-i][x-i]:=N;  Desk[y-i-1][x-i-1]:=WD;
                      x:=x-i-1;   y:=y-i-1;  draw(image1);  f1:=true;
                      start.x := x;  start.y := y;
                      delay;
                    end;

                i:=1;
                while Desk[y+i][x-i] = N do inc (i);
                if (Desk[y+i][x-i] in [B,BD]) and (Desk[y+i+1][x-i-1] = N)
                   and not(f1) then
                    begin
                      Desk[y][x]:=N;
                      Desk[y+i][x-i]:=N;  Desk[y+i+1][x-i-1]:=WD;
                      x:=x-i-1;   y:=y+i+1;  draw(image1);  f1:=true;
                      start.x := x;  start.y := y;
                      delay;
                    end;
            end
      end;  {case}
     f:=f or f1;
   end  {while}
  end;  {with}
  CompKillFrom:=f;
end;
{------------------------------------------------}
procedure TPlayer.Init;{������������� �������}
begin
 Fool := False;
 Fight:=False;
 Color:=_Color; {���������� ��� �������� (T/F)}
 if Color then
  begin
   Start.x:=4;  {��� ��������� �������}
   Start.y:=3;
  end
 else
  begin
   Start.x:=5;
   Start.y:=6;
  end;
end;
{----------------------------------------- TGame ---------------}
procedure TGame.Init;
var
 Gd,Gm : Integer;
begin
 GameOver := False;
 desk:=Tdesk.create;
 player1:=Tplayer.create;
 player1.Init(true);
 player2:=Tplayer.create;
 player2.Init(false);
 Desk.Init;
end;
procedure TGame.Done;
begin
 player1.free;
 player2.free; 
 desk.free;
end;
procedure TGame.CompPlay;
          {�������� ���������, �������������� ����� �����������
          � ������ ���� ����� ���������}
var i,_x,_y : Integer;
    P,Q   : Position;
    D     : DeskType;
    flag  : Boolean;
begin
 if GameOver then exit;
 flag:=true;
 with Player,Desk do
  begin
   if NoFight(Player) then   {���� ������}
    begin
     (*{if NoFight(Player2) then {����� ��� ���� ���}*)
       begin
 {      _x:=p.x;_y:=p.y;}
        for _y:=8 downto 1 do
         begin
          for _x:=1 to 8 do
           begin
            start.x := _x;  start.y := _y;
            if flag then
             begin
              if  Killfrom(Player) then  flag:=false;
             end;
           end;
         end;
{         p.x:=_x;p.y:=_y;  }
       end;
{        else {����� ��� ���� ����}
     end
      else   {����� ����}
        begin
{         _x:=p.x;_y:=p.y;}
         for _y:=8 downto 1 do
          begin
           for _x:=1 to 8 do
            begin
             start.x := _x;  start.y := _y;
             if flag then
             begin
              if  CompKillfrom(Player,image1) then flag:=false;
             end;
            end;
          end;
{         p.x:=_x;p.y:=_y;}
        end;
{��� ������ ����������� ���� ������ ����� ��� � �������� ���� ��� ���}
   if flag then
    begin
{     _x:=p.x;_y:=p.y;}
     for _y:=1 to 8 do
      begin
       for _x:=1 to 8 do
        begin
         start.x := _x;  start.y := _y;
         if flag then
          begin
           if  CompMoveFrom(Player) then flag:=false;
          end;
        end;
      end;
{     p.x:=_x;p.y:=_y;}
    end;
{��������� ���. ��������� �� ����� � �������������� �����}
    ScanDamk;
    Draw(image1);
  end;
end;
{-------------------------------------------}
procedure TForm1.FormCreate(Sender: TObject);
begin
  _str_black_:=ExtractFilePath(ParamStr(0))+'data\black.bmp';
  _str_white_:=ExtractFilePath(ParamStr(0))+'data\white.bmp';
  _str_black_d_:=ExtractFilePath(ParamStr(0))+'data\black_d.bmp';
  _str_white_d_:=ExtractFilePath(ParamStr(0))+'data\white_d.bmp';

 _black_:=TImage.create(self);
 _black_.Picture.loadfromfile(_str_black_);
 _black_.AutoSize:=true;
 _black_.Transparent:=true;
 _black_.left:=0;
 _black_.top:=0;

 _black_d_:=TImage.create(self);
 _black_d_.Picture.loadfromfile(_str_black_d_);
 _black_d_.AutoSize:=true;
 _black_d_.Transparent:=true;
 _black_d_.left:=0;
 _black_d_.top:=0;


 _white_:=TImage.create(self);
 _white_.Picture.loadfromfile(_str_white_);
 _white_.AutoSize:=true;
 _white_.Transparent:=true;
 _white_.left:=0;
 _white_.top:=0;

 _white_d_:=TImage.create(self);
 _white_d_.Picture.loadfromfile(_str_white_d_);
 _white_d_.AutoSize:=true;
 _white_d_.Transparent:=true;
 _white_d_.left:=0;
 _white_d_.top:=0;

 _desk_:=TPicture.create;
 _desk_.loadfromfile('data\desk.jpg');

{ desk:=TDesk.create;
 desk.init;
 desk.Draw(image1);}
 game:=Tgame.create;
 game.init;
 game.desk.draw(image1);
 game.desk.draw(image2); 

 image2.canvas.draw(0,0,_white_.Picture.Graphic);
 selflag:=false;
 first:=true;
 p2:=true;
 p1:=false;

 _back_:=tpicture.create;
 _back_.loadfromfile('data\aaa.jpg');
end;

procedure TForm1.FormDestroy(Sender: TObject);
begin
 _back_.free;
 _white_.free;
 _black_.free;
 _white_d_.free;
 _black_d_.free;
 _desk_.free;
{ desk.free;}
 game.done;
 game.free;
end;

procedure TForm1.Image1MouseDown(Sender: TObject; Button: TMouseButton;
  Shift: TShiftState; X, Y: Integer);
procedure ramka(x,y : integer;cl : boolean);
begin
with image1.canvas do
begin
 if cl then
  begin
    Pen.width:=2;
    pen.color:=cllime;
    moveto((x-1)*40,(y-1)*40);
    lineto((x-1)*40+40,(y-1)*40);
    lineto((x-1)*40+40,(y-1)*40+40);
    lineto((x-1)*40,(y-1)*40+40);
    lineto((x-1)*40,(y-1)*40);
  end
 else
  begin
    Pen.width:=2;
    pen.color:=0;
    moveto((x-1)*40,(y-1)*40);
    lineto((x-1)*40+40,(y-1)*40);
    lineto((x-1)*40+40,(y-1)*40+40);
    lineto((x-1)*40,(y-1)*40+40);
    lineto((x-1)*40,(y-1)*40);
  end;
 end;
end;

var
 sx,sy : integer;
 b : boolean;
begin
  {if Compflag then Play(Player1)  else}
 if first and (not N5.Checked) and N1.checked then
  begin
   game.CompPlay(game.Player1,image1);
   first:=false;
   image2.canvas.draw(0,0,_black_.Picture.Graphic);
   Settings1.enabled:=false;
  end;
 if N5.Checked and first and N1.checked then
 begin
   first:=false;
   image2.canvas.draw(0,0,_black_.Picture.Graphic);
   Settings1.enabled:=false;
  end;
 if first and N2.checked then
  begin
   Settings1.enabled:=false;
   first:=false;
  end;
 sx:=(x div 40)+1;
 sy:=(y div 40)+1;
 if selflag and p2 then
   begin
    ramka(ksx,ksy,false);
    game.player2.finish.x:=sx;
    game.player2.finish.y:=sy;
    if game.desk.analise(game.player2,image1) then
     begin
      {if game.player2.fight then
       begin}
        game.player2.start:=game.player2.finish;
        if game.player2.fight and game.desk.FightFrom(game.Player2) then
         ramka(sx,sy,false)
        else
         if  N1.checked then
          begin
           image2.canvas.draw(0,0,_white_.Picture.Graphic);
           game.CompPlay(game.Player1,image1);
           image2.canvas.draw(0,0,_black_.Picture.Graphic);
          end
         else
          begin
           p2:=false;
           p1:=true;
           image2.canvas.draw(0,0,_white_.Picture.Graphic);
          end;
{       end;}
     end;
    {game.desk.draw(image1);}
    selflag:=false;
    game.player2.fight:=false;
   end;
 if _selflag and p1 then
   begin
    ramka(_ksx,_ksy,false);
    game.player1.finish.x:=sx;
    game.player1.finish.y:=sy;
    if game.desk.analise(game.player1,image1) then
     begin
      {if game.player2.fight then
       begin}
        game.player1.start:=game.player1.finish;
        if game.player1.fight and game.desk.FightFrom(game.Player1) then
         ramka(sx,sy,false)
        else
          begin
           p1:=false;
           p2:=true;
           image2.canvas.draw(0,0,_black_.Picture.Graphic);
          end;
{       end;}
     end;
    {game.desk.draw(image1);}
    _selflag:=false;
    game.player1.fight:=false;
   end;
   if (not selflag) and p2 then
    begin
     game.player2.start.x:=sx;
     game.player2.start.y:=sy;
    end;
   if (not _selflag) and p1 then
    begin
     game.player1.start.x:=sx;
     game.player1.start.y:=sy;
    end;
   if p2 and game.desk.movefrom(game.player2) then
    begin
     ramka(sx,sy,true);
     selflag:=true;
     ksx:=sx;
     ksy:=sy;
    end;
   if p1 and game.desk.movefrom(game.player1) then
    begin
     ramka(sx,sy,true);
     _selflag:=true;
     _ksx:=sx;
     _ksy:=sy;
    end;
 if game.Desk.NoStep(game.Player1) then
   begin
    game.Player1.Fool:=True;
    game.GameOver := True;
   end;
 if game.Desk.NoStep(game.Player2) then
   begin
    game.Player2.Fool:=True;
    game.GameOver := True;
   end;
 if game.gameover then
  begin
   if game.Player1.Fool then
    showmessage('Player2 Wins !')
   else
    showmessage('Player1 Wins !');
   image1.Enabled:=false;
   exit;
  end;
{ showmessage('X: '+inttostr()+'Y: '+inttostr());}
end;

procedure TForm1.N2Click(Sender: TObject);
begin
 if not N2.checked then
  begin
   if sender=n2 then first:=true;
   N2.checked:=true;
   N1.checked:=false;
   p2:=true;
   p1:=false;
   N5Click(Sender);
   image2.canvas.draw(0,0,_black_.Picture.Graphic);
   N3.enabled:=false;
  end;
end;

procedure TForm1.N1Click(Sender: TObject);
begin
 if not N1.checked then
  begin
   if sender=N1 then first:=true;
   N1.checked:=true;
   N2.checked:=false;
   n3.enabled:=true;
   n4Click(Sender);
  end;
end;

procedure TForm1.N4Click(Sender: TObject);
begin
 if not N4.checked then
  begin
   if sender=n4 then first:=true;
   N4.checked:=true;
   N5.checked:=false;

   _black_:=TImage.create(self);
   _black_.Picture.loadfromfile(_str_black_);
   _black_.AutoSize:=true;
   _black_.Transparent:=true;
   _black_.left:=0;
   _black_.top:=0;

   _black_d_:=TImage.create(self);
   _black_d_.Picture.loadfromfile(_str_black_d_);
   _black_d_.AutoSize:=true;
   _black_d_.Transparent:=true;
   _black_d_.left:=0;
   _black_d_.top:=0;


   _white_:=TImage.create(self);
   _white_.Picture.loadfromfile(_str_white_);
   _white_.AutoSize:=true;
   _white_.Transparent:=true;
   _white_.left:=0;
   _white_.top:=0;

   _white_d_:=TImage.create(self);
   _white_d_.Picture.loadfromfile(_str_white_d_);
   _white_d_.AutoSize:=true;
   _white_d_.Transparent:=true;
   _white_d_.left:=0;
   _white_d_.top:=0;
   game.desk.draw(image1);
  end;
end;

procedure TForm1.N5Click(Sender: TObject);
begin
 if not N5.checked then
  begin
   if sender=n5 then first:=true;
   N5.checked:=true;
   N4.checked:=false;

   _white_.free;
   _black_.free;
   _white_d_.free;
   _black_d_.free;

    _black_:=TImage.create(self);
    _black_.Picture.loadfromfile(_str_white_);
    _black_.AutoSize:=true;
    _black_.Transparent:=true;
    _black_.left:=0;
    _black_.top:=0;

    _black_d_:=TImage.create(self);
    _black_d_.Picture.loadfromfile(_str_white_d_);
    _black_d_.AutoSize:=true;
    _black_d_.Transparent:=true;
    _black_d_.left:=0;
    _black_d_.top:=0;


    _white_:=TImage.create(self);
    _white_.Picture.loadfromfile(_str_black_);
    _white_.AutoSize:=true;
    _white_.Transparent:=true;
    _white_.left:=0;
    _white_.top:=0;

    _white_d_:=TImage.create(self);
    _white_d_.Picture.loadfromfile(_str_black_d_);
    _white_d_.AutoSize:=true;
    _white_d_.Transparent:=true;
    _white_d_.left:=0;
    _white_d_.top:=0;
    game.desk.draw(image1);
  end;
end;

procedure TForm1.New1Click(Sender: TObject);
begin
 N1Click(sender);
 n2.checked:=false;
{ n4.checked:=true;
 n5.checked:=false;}
 N3.enabled:=true;
 n4Click(sender);
 image1.Enabled:=true;
 game.init;
 game.desk.draw(image1);
 selflag:=false;
 first:=true;
 Settings1.enabled:=true;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
 tmr:=tmr+1;
end;

procedure TForm1.Exsit1Click(Sender: TObject);
begin
 close;
end;

procedure TForm1.Save1Click(Sender: TObject);
var
 f : TFileStream;
 fn : string;
begin
 SaveDialog1.InitialDir:=ExtractFilePath(ParamStr(0))+'save\';
 if SaveDialog1.execute then
  begin
   fn:=SaveDialog1.filename;
   if pos('.',fn)=0 then fn:=fn+'.sav';
   f:=TFileStream.Create(fn,fmcreate);
   f.write(game.desk.desk,sizeof(game.desk.desk));
   f.write(game.Player1,sizeof(game.Player1));
   f.write(game.Player2,sizeof(game.Player2));

   f.write(n1.checked,sizeof(n1.checked));
   f.write(n2.checked,sizeof(n2.checked));
   f.write(n4.checked,sizeof(n4.checked));
   f.write(n5.checked,sizeof(n5.checked));

   f.write(p1,sizeof(p1));
   f.write(p2,sizeof(p2));
   f.write(first,sizeof(first));
   f.free;
  end;
end;

procedure TForm1.Load1Click(Sender: TObject);
var
 f : TFileStream;
 fn : string;
 b,_p1,_p2 : boolean;
 _n4,_n5 : boolean;
begin
 OpenDialog1.InitialDir:=ExtractFilePath(ParamStr(0))+'save\';
 if OpenDialog1.execute then
  begin
   {new1Click(sender);}
   selflag:=false;
   Settings1.enabled:=false;
   fn:=OpenDialog1.filename;
   if pos('.',fn)=0 then fn:=fn+'.sav';
   f:=TFileStream.Create(fn,fmOpenRead);
   game.init;
   f.read(game.desk.desk,sizeof(game.desk.desk));
   f.read(game.Player1,sizeof(game.Player1));
   f.read(game.Player2,sizeof(game.Player2));
   f.read(b,sizeof(b));
   n1.checked:=b;
   f.read(b,sizeof(b));
   n2.checked:=b;
   f.read(_n4,sizeof(b));
   f.read(_n5,sizeof(b));
   f.read(_p1,sizeof(p1));
   f.read(_p2,sizeof(p2));
   f.read(first,sizeof(first));
   f.free;
   if n1.checked then
    begin
     n1.checked:=false;
     n1click(sender);
     n4.checked:=_n4;
     n5.checked:=_n5;
     if n4.checked then
      begin
       n4.checked:=false;
       n4click(sender);
      end
     else
      if n5.checked then
       begin
        n5.checked:=false;
        n5click(sender);
       end;
      p1:=_p1;p2:=_p2;
      game.desk.draw(image1);
      exit;
    end;
   if n2.checked then
    begin
     n2.checked:=false;
     n2click(sender);
     if n4.checked then
      begin
       n4.checked:=false;
       n4click(sender);
      end
     else
      if n5.checked then
       begin
        n5.checked:=false;
        n5click(sender);
       end;
     p1:=_p1;p2:=_p2;
     if p2 then image2.canvas.draw(0,0,_black_.Picture.Graphic);
     if p1 then image2.canvas.draw(0,0,_white_.Picture.Graphic);
    end;
  end;
end;

procedure TForm1.FormPaint(Sender: TObject);
begin
 canvas.draw(0,0,_back_.Graphic);
 image1.refresh;
 image2.refresh; 
end;

end.
