program SaltTask;

{$mode objfpc}{$H+}

uses
  Interfaces,
  Forms, STu1, stu2;

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

