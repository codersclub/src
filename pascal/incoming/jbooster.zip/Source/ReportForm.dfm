object FormReport: TFormReport
  Left = 205
  Top = 82
  BorderIcons = [biSystemMenu]
  BorderStyle = bsDialog
  ClientHeight = 391
  ClientWidth = 461
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  KeyPreview = True
  OldCreateOrder = False
  Position = poMainFormCenter
  OnActivate = FormActivate
  OnDeactivate = FormDeactivate
  OnKeyDown = FormKeyDown
  PixelsPerInch = 96
  TextHeight = 13
  object ButtonStop: TButton
    Left = 302
    Top = 362
    Width = 73
    Height = 23
    Anchors = [akTop, akRight]
    Caption = 'Cancel'
    TabOrder = 1
    OnClick = ButtonStopClick
  end
  object ButtonClose: TButton
    Left = 382
    Top = 362
    Width = 73
    Height = 23
    Anchors = [akTop, akRight]
    Cancel = True
    Caption = 'Close'
    ModalResult = 2
    TabOrder = 2
    OnClick = ButtonCloseClick
  end
  object ReportListBox: TListBox
    Left = 0
    Top = 0
    Width = 461
    Height = 354
    Align = alTop
    Font.Charset = ANSI_CHARSET
    Font.Color = clWindowText
    Font.Height = -12
    Font.Name = 'Courier New'
    Font.Style = []
    ItemHeight = 14
    ParentFont = False
    Style = lbOwnerDrawFixed
    TabOrder = 0
    OnDrawItem = ReportListBoxDrawItem
  end
end
