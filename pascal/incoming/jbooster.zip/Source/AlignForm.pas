(*************************************************************************)
(*                                jBooster                               *)
(*                        (c) pulsar@mail.primorye.ru                    *)
(*************************************************************************)
 Unit AlignForm;
 {$H+,A+,B-,I-}

 Interface

 Uses
   { standart }
     Windows, Messages, SysUtils, Classes,
   { vcl }
     Controls, Forms, StdCtrls, ExtCtrls,
   { private }
     Support;

 Type
    TFormAlign = class(TForm)
      PanelHor: TPanel;
      RadioLeft: TRadioButton;
      RadioCenter: TRadioButton;
      RadioRight: TRadioButton;
      PanelVer: TPanel;
      RadioTop: TRadioButton;
      RadioMiddle: TRadioButton;
      RadioBottom: TRadioButton;
      ButtonOk: TButton;
      ButtonCancel: TButton;
      procedure FormCreate(Sender: TObject);
    end; { TForm }

 Var
     FormAlign: TFormAlign;

 Implementation

{$R *.DFM}

 procedure TFormAlign.FormCreate(Sender: TObject);
 var
     i : integer;
 begin
     for i := MinAnchor to MaxAnchor do begin
         TRadioButton (PanelHor.Controls [i]).Caption := '&' + HAnchors [i];
         TRadioButton (PanelVer.Controls [i]).Caption := '&' + VAnchors [i];
     end; { for }
 end; { FormCreate }

 End.
