object FormMain: TFormMain
  Left = 195
  Top = 65
  Width = 461
  Height = 455
  Color = clBtnFace
  Constraints.MaxHeight = 455
  Constraints.MaxWidth = 610
  Constraints.MinHeight = 455
  Constraints.MinWidth = 410
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Icon.Data = {
    0000010002002020100000000000E80200002600000010101000000000002801
    00000E0300002800000020000000400000000100040000000000800200000000
    0000000000000000000000000000000000000000800000800000008080008000
    0000800080008080000080808000C0C0C0000000FF0000FF000000FFFF00FF00
    0000FF00FF00FFFF0000FFFFFF00000000000000000000000000000000000000
    0080000000808800000008000000000000800000008708000000080000000000
    0F870000011071100000F870000000000000000000077000000000000000008F
    FF8FFFF0F8F07F870FFFF8FFF700008888888880F8F77F87088888888700008F
    FFFFFFF0F8F07F870FFFFFFFF7000008FFFFFFF0F8F87F870FFFFFFF70000000
    8FFFFFF0F8F87F870FFFFFF70000000008FFFFF0F8FF8F870FFFFF7000000000
    008FFFF0F8FFFF870FFFF700000000000F08FFF0F8FFFF870FFF707000000000
    0F808FF0F8FFFF870FF70870000000000F8708F0F8FFFF870F70F87000000000
    0F870080F8FFFF870700F870000000000F870100F8FFFF870010F87000000000
    0F870110F8FFFF870110F870000000000F870110F8FFFF870110F87000000000
    0F870110F8FFFF870110F870000000000F870110F8FFFF870110F87000000000
    0F870110F8FFFF870110F870000000000F870010F8FFFF870100F87000000000
    0F870010FFCFF4F70100F870000000000F8700110F4C4CF01100F87000000000
    0F8700010FF4CFF01000F870000000000080000110FFFF011000080000000000
    00000000110FF011000000000000000000000000111001110000000000000000
    0000000001111110000000000000000000000000000110000000000000000000
    0000000000000000000000000000F0700E0FF8F81F1FF8F81F1FF0700E0FC000
    0003800000018000000180000001C0000003E0000007F000000FF000000FF000
    000FF000000FF000000FF000000FF000000FF000000FF000000FF000000FF000
    000FF000000FF000000FF000000FF000000FF040020FF8C0031FFDE007BFFFE0
    07FFFFF00FFFFFF81FFFFFFE7FFF280000001000000020000000010004000000
    0000C00000000000000000000000000000000000000000000000000080000080
    00000080800080000000800080008080000080808000C0C0C0000000FF0000FF
    000000FFFF00FF000000FF00FF00FFFF0000FFFFFF0000000000000000000008
    00078000800000000000000000000888808078088800008FF088780FF7000008
    F08F880F70000000808FF80700000008008FF80080000008018FF81080000008
    018FF81080000008018FF81080000008018C481080000008000FF00080000000
    00100100000000000011110000000000000000000000C4230000C42300000000
    00000000000080010000C0030000C0030000C0030000C0030000C0030000C003
    0000C0030000C0030000E8170000F81F0000FC3F0000}
  KeyPreview = True
  OldCreateOrder = False
  Position = poDefaultPosOnly
  OnClose = FormClose
  OnKeyDown = FormKeyDown
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object LabelPath: TLabel
    Left = 83
    Top = 14
    Width = 22
    Height = 13
    Caption = '&Path'
    FocusControl = EditPath
  end
  object LabelFormat: TLabel
    Left = 5
    Top = 16
    Width = 21
    Height = 13
    Caption = 'Files'
    FocusControl = BoxFormat
  end
  object FileListBox: TListBox
    Left = 4
    Top = 34
    Width = 190
    Height = 390
    Hint = 'Press Enter to see the image'
    Anchors = [akLeft, akTop, akRight]
    ItemHeight = 13
    ParentShowHint = False
    ShowHint = True
    Style = lbOwnerDrawFixed
    TabOrder = 3
    OnDblClick = FileListBoxDblClick
    OnDrawItem = FileListBoxDrawItem
    OnKeyDown = FileListBoxKeyDown
  end
  object EditPath: TComboBox
    Left = 110
    Top = 6
    Width = 262
    Height = 21
    Hint = 'Press Enter to rescan'
    Anchors = [akLeft, akTop, akRight]
    ItemHeight = 13
    ParentShowHint = False
    ShowHint = True
    TabOrder = 1
    OnChange = EditPathChange
    OnExit = EditPathExit
    OnKeyDown = EditPathKeyDown
  end
  object PanelRename: TPanel
    Left = 201
    Top = 249
    Width = 248
    Height = 144
    Anchors = [akTop, akRight]
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 7
    object LabelPrefix: TLabel
      Left = 9
      Top = 46
      Width = 26
      Height = 13
      Caption = 'Pr&efix'
      FocusControl = EditPrefix
    end
    object LabelFirst: TLabel
      Left = 71
      Top = 74
      Width = 19
      Height = 13
      Caption = 'Fir&st'
      FocusControl = EditFirst
    end
    object LabelDigits: TLabel
      Left = 9
      Top = 74
      Width = 26
      Height = 13
      Caption = '&Digits'
      FocusControl = EditDigits
    end
    object LabelStep: TLabel
      Left = 167
      Top = 74
      Width = 22
      Height = 13
      Caption = 'Step'
      FocusControl = EditStep
    end
    object LabelPostfix: TLabel
      Left = 9
      Top = 102
      Width = 31
      Height = 13
      Caption = 'Postfix'
      FocusControl = EditPostfix
    end
    object LabelOrder: TLabel
      Left = 9
      Top = 17
      Width = 26
      Height = 13
      Caption = 'Order'
      FocusControl = BoxOrder
    end
    object EditPrefix: TEdit
      Left = 45
      Top = 37
      Width = 194
      Height = 21
      MaxLength = 16
      TabOrder = 2
      OnChange = EditPrefixChange
      OnKeyPress = TestFileName
    end
    object EditDigits: TEdit
      Left = 45
      Top = 66
      Width = 19
      Height = 21
      MaxLength = 1
      TabOrder = 3
      OnChange = EditDigitsChange
      OnExit = EditDigitsExit
      OnKeyPress = TestNumeric
    end
    object EditFirst: TEdit
      Left = 96
      Top = 66
      Width = 65
      Height = 21
      TabOrder = 4
      OnChange = EditFirstChange
      OnExit = EditFirstExit
      OnKeyPress = TestNumeric
    end
    object CheckFileTime: TCheckBox
      Left = 9
      Top = 120
      Width = 94
      Height = 17
      Caption = '&Update file time'
      TabOrder = 7
      OnClick = CheckFileTimeClick
    end
    object EditStep: TEdit
      Left = 194
      Top = 66
      Width = 45
      Height = 21
      MaxLength = 6
      TabOrder = 5
      OnChange = EditStepChange
      OnExit = EditStepExit
      OnKeyPress = TestNumeric
    end
    object CheckReadOnly: TCheckBox
      Left = 108
      Top = 120
      Width = 125
      Height = 17
      Caption = 'Set readonl&y attribute'
      TabOrder = 8
      OnClick = CheckReadOnlyClick
    end
    object EditPostfix: TEdit
      Left = 45
      Top = 94
      Width = 194
      Height = 21
      MaxLength = 16
      TabOrder = 6
      OnChange = EditPostfixChange
      OnKeyPress = TestFileName
    end
    object BoxOrder: TComboBox
      Left = 45
      Top = 9
      Width = 118
      Height = 21
      Style = csDropDownList
      ItemHeight = 13
      TabOrder = 0
      OnChange = BoxOrderChange
      OnKeyDown = BoxOrderKeyDown
    end
    object CheckDecs: TCheckBox
      Left = 170
      Top = 7
      Width = 65
      Height = 17
      Caption = 'Decrease'
      TabOrder = 1
      OnClick = CheckDecsClick
    end
  end
  object CheckRename: TCheckBox
    Left = 201
    Top = 239
    Width = 88
    Height = 15
    Anchors = [akTop, akRight]
    Caption = '&Numerate files'
    TabOrder = 6
    OnClick = CheckRenameClick
  end
  object PanelThumbnails: TPanel
    Left = 201
    Top = 43
    Width = 248
    Height = 191
    Alignment = taRightJustify
    Anchors = [akTop, akRight]
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 5
    object LabelScale: TLabel
      Left = 9
      Top = 41
      Width = 27
      Height = 13
      Caption = 'Sc&ale'
      FocusControl = TrackScale
    end
    object LabelMark: TLabel
      Left = 9
      Top = 17
      Width = 24
      Height = 13
      Caption = 'Mark'
      FocusControl = EditMark
    end
    object LabelQuality: TLabel
      Left = 9
      Top = 67
      Width = 32
      Height = 13
      Caption = '&Quality'
      FocusControl = TrackQuality
    end
    object TrackQuality: TTrackBar
      Left = 41
      Top = 61
      Width = 120
      Height = 25
      Orientation = trHorizontal
      ParentShowHint = False
      Frequency = 1
      Position = 0
      SelEnd = 0
      SelStart = 0
      ShowHint = True
      TabOrder = 4
      TickMarks = tmBottomRight
      TickStyle = tsAuto
      OnChange = TrackQualityChange
    end
    object TrackScale: TTrackBar
      Left = 41
      Top = 34
      Width = 120
      Height = 25
      Max = 9
      Min = 1
      Orientation = trHorizontal
      ParentShowHint = False
      PageSize = 1
      Frequency = 1
      Position = 1
      SelEnd = 0
      SelStart = 0
      ShowHint = True
      TabOrder = 1
      TickMarks = tmBottomRight
      TickStyle = tsAuto
      OnChange = TrackScaleChange
    end
    object EditMark: TEdit
      Left = 48
      Top = 9
      Width = 191
      Height = 21
      Hint = 'Press Enter to apply new value'
      ParentShowHint = False
      ShowHint = True
      TabOrder = 0
      OnChange = EditMarkChange
      OnExit = EditMarkExit
      OnKeyPress = EditMarkKeyPress
    end
    object PanelCustom: TPanel
      Left = 161
      Top = 46
      Width = 87
      Height = 145
      BevelInner = bvRaised
      BevelOuter = bvLowered
      TabOrder = 3
      object LabelWidth: TLabel
        Left = 9
        Top = 17
        Width = 28
        Height = 13
        Caption = 'Width'
        FocusControl = EditWidth
      end
      object LabelHeight: TLabel
        Left = 9
        Top = 45
        Width = 31
        Height = 13
        Caption = 'Height'
        FocusControl = EditHeight
      end
      object EditWidth: TEdit
        Left = 46
        Top = 9
        Width = 32
        Height = 21
        TabOrder = 0
        OnChange = EditWidthChange
        OnExit = EditWidthExit
        OnKeyPress = TestNumeric
      end
      object EditHeight: TEdit
        Left = 46
        Top = 37
        Width = 32
        Height = 21
        TabOrder = 1
        OnChange = EditHeightChange
        OnExit = EditHeightExit
        OnKeyPress = TestNumeric
      end
      object ButtonColor: TButton
        Left = 9
        Top = 114
        Width = 69
        Height = 21
        Hint = '     '
        Caption = 'Color'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 5
        OnClick = ButtonColorClick
      end
      object RadioCut: TRadioButton
        Left = 8
        Top = 64
        Width = 41
        Height = 17
        Hint = 'Cut to size'
        Caption = 'Cut'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 2
        OnClick = RadioModeClick
      end
      object RadioFill: TRadioButton
        Left = 47
        Top = 64
        Width = 33
        Height = 17
        Hint = 'Fill with color'
        Caption = 'Fill'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 3
        OnClick = RadioModeClick
      end
      object ButtonAlign: TButton
        Left = 9
        Top = 86
        Width = 69
        Height = 21
        Caption = 'Align'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 4
        OnClick = ButtonAlignClick
      end
    end
    object PanelInclude: TPanel
      Left = 0
      Top = 101
      Width = 163
      Height = 90
      BevelInner = bvRaised
      BevelOuter = bvLowered
      TabOrder = 6
      object LabelText: TLabel
        Left = 9
        Top = 17
        Width = 21
        Height = 13
        Caption = '&Text'
        FocusControl = EditText
      end
      object EditText: TEdit
        Left = 38
        Top = 9
        Width = 116
        Height = 21
        MaxLength = 16
        TabOrder = 0
        OnChange = EditTextChange
      end
      object CheckImage: TCheckBox
        Left = 9
        Top = 36
        Width = 73
        Height = 17
        Caption = 'I&mage size'
        TabOrder = 1
        OnClick = CheckImageClick
      end
      object CheckFile: TCheckBox
        Left = 85
        Top = 36
        Width = 57
        Height = 17
        Caption = 'File si&ze'
        TabOrder = 2
        OnClick = CheckFileClick
      end
      object ButtonFont: TButton
        Left = 9
        Top = 59
        Width = 69
        Height = 21
        Caption = '&Font'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 3
        OnClick = ButtonFontClick
      end
      object ButtonGround: TButton
        Left = 85
        Top = 59
        Width = 69
        Height = 21
        Hint = '     '
        Caption = '&BGround'
        ParentShowHint = False
        ShowHint = True
        TabOrder = 4
        OnClick = ButtonGroundClick
      end
    end
    object CheckInclude: TCheckBox
      Left = 9
      Top = 91
      Width = 114
      Height = 15
      Caption = '&Include in thumbnail'
      TabOrder = 5
      OnClick = CheckIncludeClick
    end
    object CheckCustom: TCheckBox
      Left = 161
      Top = 36
      Width = 76
      Height = 15
      Caption = 'Custom size'
      TabOrder = 2
      OnClick = CheckCustomClick
    end
    object PanelNull: TPanel
      Left = 2
      Top = 96
      Width = 7
      Height = 17
      BevelOuter = bvNone
      Enabled = False
      TabOrder = 7
    end
  end
  object CheckThumbnails: TCheckBox
    Left = 201
    Top = 33
    Width = 104
    Height = 15
    Anchors = [akTop, akRight]
    Caption = '&Create thumbnails'
    TabOrder = 4
    OnClick = CheckThumbnailsClick
  end
  object ButtonExit: TButton
    Left = 370
    Top = 400
    Width = 78
    Height = 23
    Anchors = [akTop, akRight]
    Cancel = True
    Caption = 'E&xit'
    ModalResult = 2
    TabOrder = 9
    OnClick = ButtonExitClick
  end
  object ButtonRun: TButton
    Left = 285
    Top = 400
    Width = 78
    Height = 23
    Anchors = [akTop, akRight]
    Caption = '&Run'
    ModalResult = 1
    TabOrder = 8
    OnClick = ButtonRunClick
  end
  object ButtonPath: TButton
    Left = 379
    Top = 6
    Width = 69
    Height = 21
    Anchors = [akTop, akRight]
    Caption = 'Browse'
    TabOrder = 2
    OnClick = ButtonPathClick
  end
  object BoxFormat: TComboBox
    Left = 30
    Top = 6
    Width = 46
    Height = 21
    Style = csDropDownList
    ItemHeight = 13
    TabOrder = 0
    OnChange = BoxFormatChange
    OnKeyDown = BoxFormatKeyDown
  end
  object FontDialog: TFontDialog
    OnShow = FontDialogShow
    Font.Charset = DEFAULT_CHARSET
    Font.Color = clWindowText
    Font.Height = -11
    Font.Name = 'MS Sans Serif'
    Font.Style = []
    MinFontSize = 0
    MaxFontSize = 9
    Options = [fdAnsiOnly, fdEffects, fdForceFontExist, fdLimitSize]
    Left = 48
    Top = 80
  end
  object ColorDialog: TColorDialog
    Ctl3D = True
    OnShow = ColorDialogShow
    Color = clWhite
    Options = [cdFullOpen]
    Left = 80
    Top = 80
  end
end
