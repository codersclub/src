(*************************************************************************)
(*                                jBooster                               *)
(*                        (c) pulsar@mail.primorye.ru                    *)
(*************************************************************************)
 Unit Support;
 {$J+,H+,A+,B-,I-}

 Interface

 Uses
  { standart }
    SysUtils, Windows, Classes,
  { vcl }
    StdCtrls, Controls, Graphics, Dialogs, Forms,
  { formats }
    JPeg,
  { browse dialog }
    ShlObj, ActiveX;

(*************************************************************************)
(*                         customizable values                           *)
(*************************************************************************)
 Const
  { Application }
    AppName = 'jBooster';
    Version = '1.05a (build 9)';
  { names }
    IniName = AppName + '.ini';
    LogName = AppName + '.log';
    HlpName = AppName + '.txt';

(*************************************************************************)
(*                          report\error handlers                        *)
(*************************************************************************)
 Type
     PReportHandler = procedure (const Mssg: string; Prx: TMsgDlgType);

 procedure Alarm (const Mssg: string; Pfx: TMsgDlgType);
 function Confirm (const Wrn, Qst: string): boolean;
 procedure Error (const Name, Mssg: string);
 procedure SysError (const Name: string; RC: Dword);
 procedure Warning (const Name, Mssg: string);
 procedure Inform (const Mssg: string);

 Const
   { report handler }
     Report : PReportHandler = Alarm;
   { report prefixs }
     ErrPrefix = '!';
     BegPrefix = '?';
     EndPrefix = '=';
     AnyPrefix = ' ';

(*************************************************************************)
(*                              dialogs support                          *)
(*************************************************************************)
 Const
     DialogCaption : string = '';

 procedure UpdateDialog (Handle: HWND; X, Y: integer);
 function SelectDirectory: boolean;

(*************************************************************************)
(*                              support                                  *)
(*************************************************************************)
 Const
  { special chars + prefix chars }
    Illegals = [#0..#31,'\','|','/','*','?',':','>','<','"','.'] + ['!','='];
  { digits }
    Numerics = ['0'..'9'];

 function StrToInt (const S: string; var I: integer): boolean;
 function PathDelimiter (const Path: string): string;
 function SizeStr (W, H : integer): string;
 function FileSizeStr (Z: longword): string;
 function JpgQuality: integer;
 function isThumbnail (const FileName: string): boolean;
 function GetCatalogTime (var Time: TFileTime): boolean;

(*************************************************************************)
(*                                parameters                             *)
(*************************************************************************)
 Type
    TFormat = 0..0;
    TOrder = 0..7;
    TAnchor = 0..2;

 Const
  { list breaker }
    ListBreak = ';';
  { path history }
    MaxHistory = 8;
  { extension }
    ExtLen = 4;
  { format }
    MaxFormat = High (TFormat);
    MinFormat = Low (TFormat);
  { scale }
    MaxScale = 10;
    MinScale = 0;
  { quality }
    MaxQuality = 10;
    MinQuality = 0;
  { preview font }
    MaxColor = $00FFFFFF;
    MinColor = $00000000;
    MaxFont  = 9;
    MinFont  = 6;
  { firstnumber }
    MinFirst = 0;
    MaxFirst = 999999999;
    LenFirst = 9;
  { digits }
    MaxDigits = 9;
    MinDigits = 0;
    LenDigits = 1;
  { Step }
    MaxStep = 999999;
    MinStep = 1;
    LenStep = 6;
  { Anchor }
    MinAnchor = Low (TAnchor);
    MaxAnchor = High (TAnchor);
  { order }
    MinOrder = Low (TOrder);
    MaxOrder = High (TOrder);
  { custom width }
    MinWidth = 1;
    MaxWidth = 999;
    LenWidth = 3;
    StdWidth = 100;
  { custom height }
    MinHeight = 1;
    MaxHeight = 999;
    LenHeight = 3;
    StdHeight = 100;
  { other }
    LenPrefix = 64;
    LenPostfix = 64;
    LenMark = 16;
    LenComment = 24;
  { forms  }
    MinView = 100;
    MinTop = -18;
    MinLeft = -100;
    MinBreadth = 410;
    MaxBreadth = 640;

 Const
  { curr format }
    Format : integer = 0;
  { curr path }
    PathIndex : integer = 0;
  { numerate }
    fRename   : boolean = false;
    Order     : integer = 0;
    fDecs     : boolean = false;
    FirstNum  : integer = 0;
    Digits    : integer = 0;
    StepCount : integer = 1;
    Prefix    : string = '';
    Postfix   : string = '';
    fAttribute: boolean = false;
    fFileTime : boolean = false;
  { thumbnails }
    fThumbnail: boolean = false;
    Scale     : integer = 4;
    Quality   : integer = 7;
    Mark      : string = '$';
  { custom size }
    fCustom   : boolean = false;
    CtmWidth  : integer = StdWidth;
    CtmHeight : integer = StdHeight;
    CtmMode   : boolean = false;
    AnchorX   : integer = 1;
    AnchorY   : integer = 1;
    FillColor : integer = MinColor;
  { include }
    fInclude  : boolean = false;
    Comment   : string = '';
    fImgSize  : boolean = false;
    fFilSize  : boolean = false;
    FontStyle : TFontStyles = [];
    FontName  : string = 'MS Serif';
    FontColor : TColor = MinColor;
    FontSize  : integer = 6;
    BGround   : TColor = 15724275;
  { forms position and size }
    MainLeft  : integer = 200;
    MainTop   : integer = 100;
    MainWidth : integer = 460;
    ViewLeft  : integer = 10;
    ViewTop   : integer = 10;
    ViewWidth : integer = 360;
    ViewHeight: integer = 400;

 Const
  { formats }
    Formats : array [TFormat] of string [ExtLen]
            = ('.jpg' {, '.bmp', '.gif', '.tif', '.pcx', '.png'});

  { sort order }
    Orders : array [TOrder] of string
           = ('by file name',
              'by file size',
              'by file time',
              'by image width',
              'by image height',
              'by (width * height)',
              'by (width / height)',
              'by random');

  { align }
    HAnchors : array [TAnchor] of string = ('Left','Center','Right');
    VAnchors : array [TAnchor] of string = ('Top','Middle','Bottom');

 Const
   { init from main form }
     ExePath : string = '';
     Catalog : string = '';
     Buffer : TStrings = nil;
     Path : TStrings = nil;
     Colors : TStrings = nil;

{ font }
 procedure ParmsToFont (Font: TFont);
 procedure FontToParms (Font: TFont);
{ load\save parameters }
 procedure LoadParms;
 procedure SaveParms;

(*************************************************************************)
(*                               formats support                         *)
(*************************************************************************)
 function LoadImage (Bmp: TBitMap; const FileName: string): boolean;
 function SaveImage (Bmp: TBitMap; const FileName: string): boolean;
 function ImageSize (const FileName: string; var Width, Height : integer): boolean;

(*************************************************************************)
(*                                image list                             *)
(*************************************************************************)
 Type
    PImageInfo = ^TImageInfo;
    TImageInfo = packed record
    { work }
      Thumbnail : PImageInfo;
      Temp : integer;
    { image parms }
      Width  : integer;
      Height : integer;
    { file parms }
      Size : integer;
      Attr : integer;
      Time : TFileTime;
      Name : string;
    end; { TImageInfo }

    TImageList = Class (TList)
    private
      ViewCount : integer;
      SortOrder : integer;
      Decrease  : boolean;
      HaveSize  : boolean;
    { support }
      procedure Drop;
      procedure DisposeItem (var P: PImageInfo);
      procedure InitInfo (var Find : TSearchRec; Info: PImageInfo);
      function Search (const Name: string; var Index: integer): boolean;
      function isCancel : boolean;
      procedure Start (const Mssg: string);
      procedure Stop;
    { sort }
      procedure SetOrder;
      function LoadSize: boolean;
      function Sort (Odr: TOrder; Dcs: boolean): boolean;
    { test }
      function Pack: boolean;
    { create thumbnails }
      procedure CreateThumbnails;
    { rename }
      function RenameImage (P: PImageInfo; const Name: string): boolean;
      function Rename: boolean;
    { update }
      function SetReadOnly (P: PImageInfo; ReadOnly: boolean): boolean;
      function UpdateTime (P: PImageInfo; const Time: TSystemTime): boolean;
      function Update: boolean;
    public
      constructor Create;
      procedure Clear; override;
      function Scan: boolean;
      procedure Run;
      procedure MarkChange;
      property ThumbnailCount: integer read ViewCount;
    end; { TImageList }

 Var
    Images : TImageList;
    Cancel : boolean;

 Implementation

(*************************************************************************)
(*                          report\error handlers                        *)
(*************************************************************************)
 procedure Alarm (const Mssg: string; Pfx: TMsgDlgType);
 begin
     With CreateMessageDialog (Mssg, Pfx, [mbOK]) do begin
          Position := poMainFormCenter;
          ShowModal;
          Free;
     end; { With }
 end; { Alarm }

 function Confirm (const Wrn, Qst: string): boolean;
 begin
     With CreateMessageDialog (Wrn + #13#13 + Qst + '?', mtConfirmation, [mbYes, mbNo])
     do begin
        Position := poMainFormCenter;
        Result := ShowModal = mrYes;
        Free;
     end; { With }
 end; { Confirm }

 procedure Error (const Name, Mssg: string);
 var
     S : string;
 begin
     if Name > '' then S := '"' + Name + '". ' else S := '';
     Report (ErrPrefix + AnyPrefix + 'Error: ' + S + Mssg, mtError)
 end; { Error }

 procedure SysError (const Name: string; RC: Dword);
 begin
     Error (Name, SysErrorMessage (RC));
 end; { SysError }

 procedure Warning (const Name, Mssg: string);
 var
     S : string;
 begin
     if Name > '' then S := '"' + Name + '". ' else S := '';
     Report (ErrPrefix + AnyPrefix + 'Warning: ' + S + Mssg, mtWarning)
 end; { Warning }

 procedure Inform (const Mssg: string);
 begin
     Report (Mssg, mtInformation);
 end; { Inform }

(*************************************************************************)
(*                              dialogs support                          *)
(*************************************************************************)
 procedure UpdateDialog (Handle: HWND; X, Y: integer);
 begin
     SetWindowPos (Handle, 0, X, Y, 0, 0, SWP_NOACTIVATE or SWP_NOSIZE or SWP_NOZORDER);
     if DialogCaption > '' then SetWindowText (Handle, PChar (DialogCaption));
 end; { UpdateDialog }

 function EnumChildProc (Handle: HWND; lParam: LPARAM): BOOL; stdcall;
 var
     R : TRect;
 begin
     GetClientRect (Handle, R);
   { browser window }
     if (R.Right = 276) and (R.Bottom = 202) then begin
        GetWindowRect (GetParent (Handle), R);
      { resize }
        MoveWindow (Handle, 0, 0, R.Right - R.Left - 7, R.Bottom - R.Top - 74, true);
      { stop }
        Result := false;
     end { if }
   { next }
     else Result := true;
 end; { EnumChildProc  }

 procedure BrowserCallBack (HWindow: HWND; Msg: Integer; lParameter: LPARAM; lpBrowseFolder: LPARAM); stdcall;
 var
     x, y : integer;
     R    : TRect;
 begin
     if Msg = BFFM_INITIALIZED then begin
      { window pos }
        GetWindowRect (GetForegroundWindow, R);
        x := R.Left + (R.Right - R.Left) div 2;
        y := R.Top;
        GetWindowRect (HWindow, R);
        x := x - (R.Right - R.Left) div 2;
        y := y + 25;
      { init }
        UpdateDialog (HWindow, x, y);
        SetWindowLong (HWindow, GWL_USERDATA, lpBrowseFolder);
        SendMessage (HWindow, BFFM_SETSELECTION, Ord (true), Longint (PChar (Catalog)));
      { change size of browser window }
        if ((R.Right - R.Left) = 324) and ((R.Bottom - R.Top) = 331)
           then EnumChildWindows (HWindow, @EnumChildProc, 0);
     end; { if }
 end; { BrowserCallBack }

 function SelectDirectory: boolean;
 var
     WindowList : Pointer;
     BrowseInfo : TBrowseInfo;
     ShellMalloc: IMalloc;
     ItemIDList : PItemIDList;
     Buffer     : PChar;
 begin
   { init }
     Result := false;
     FillChar (BrowseInfo, SizeOf (BrowseInfo), 0);
   { get mem handler }
     if (ShGetMalloc (ShellMalloc) = S_OK) and (ShellMalloc <> nil) then begin
        Buffer := ShellMalloc.Alloc (MAX_PATH);
        Try
          With BrowseInfo do begin
               hwndOwner := Application.Handle;
               pidlRoot := nil;
               pszDisplayName := Buffer;
               ulFlags := BIF_RETURNONLYFSDIRS;
               lpfn := @BrowserCallBack;
          end; { With }
          WindowList := DisableTaskWindows(0);
          Try
             ItemIDList := ShBrowseForFolder(BrowseInfo);
          Finally
             EnableTaskWindows(WindowList);
          end; { try }
          Result := ItemIDList <> nil;
        { ok }
          if Result then begin
             ShGetPathFromIDList (ItemIDList, Buffer);
             ShellMalloc.Free (ItemIDList);
             Catalog := PathDelimiter (AnsiUpperCase (Buffer));
          end; { if }
        Finally
          ShellMalloc.Free (Buffer);
        end; { try }
     end; { if }
 end; { SelectDirectory }

(*************************************************************************)
(*                               support                                 *)
(*************************************************************************)
 function StrToInt (const S : string; var I: integer): boolean;
 var
     c, n : integer;
 begin
      {$R-}
        Val (S, n, c);
        if c = 0 then begin
           Result := true;
           I := n;
        end { if }
        else Result := false;
 end; { StrToInt }

 function PathDelimiter (const Path: string): string;
 begin
     if (Length (Path) = 0) or IsPathDelimiter (Path, Length (Path))
        then Result := Path
        else Result := Path + '\';
 end; { PathDelimiter }

 function SetDigits (Num: integer): string;
 var
     k : integer;
 begin
     Result := IntToStr (Num);
     if Digits > 0 then begin
        k := Digits - Length (Result);
        if k > 0 then Result := StringOfChar ('0', k) + Result;
     end; { if }
 end; { SetDigits }

 function isThumbnail (const FileName: string): boolean;
 var
     k : integer;
 begin
     k := Length (Mark);
     Result := (k > 0) and (AnsiCompareText (Copy (FileName, Length (FileName) - k - Pred (ExtLen), k), Mark) = 0);
 end; { isThumbnail }

 procedure DecodeName (const FileName: string; var Pfx, Num, Ptx: string);
 var
     i, j, k, n : integer;
 begin
   { len }
     n := Length (FileName) - ExtLen;
   { find digit }
     j := Succ (n);
     k := j;
     for i := 1 to n do begin
         if FileName [i] in Numerics then begin
            j := i;
            Break;
         end; { if }
     end; { for }
   { find char }
     for i := Succ (j) to n do begin
         if not (FileName [i] in Numerics) then begin
            k := i;
            Break;
         end; { if }
     end; { for }
   { result }
     Pfx := Copy (FileName, 1, Pred (j));
     Ptx := Copy (FileName, k, n - k + 1);
     Num := Copy (FileName, j, k - j);
 end; { DecodeName }

 function EncodeName (Number: integer): string;
 begin
     Result := Prefix + SetDigits (Number) + Postfix + Formats [Format];
 end; { EncodeName }

 function ThumbnailName (const FileName: string): string;
 var
     n : integer;
 begin
     n := Length (FileName);
     Result := Copy (FileName, 1, n - ExtLen) + Mark +
               Copy (FileName, n - Pred (ExtLen), ExtLen);
 end; { ThumbnailName }

 function SizeStr (W, H : integer): string;
 begin
     Result := IntToStr (W) + 'x' + IntToStr (H);
 end; { SizeStr }

 function FileSizeStr (Z: longword): string;
 var
     k : integer;
 begin
     k := Round (Z / 1024);
     if k = 0 then k := 1;
     Result := IntToStr (k) + 'k';
 end; { FileSizeStr }

 function JpgQuality: integer;
 begin
     Result := 20 + (Quality * 8);
 end; { JpgQuality }

 function isPathExist (const Name: string): boolean;
 var
     A : integer;
 begin
     A := FileGetAttr (Name);
     Result := (A > 0) and ((A and faDirectory) > 0);
 end; { isPathExist }

 function GetCatalogTime (var Time: TFileTime): boolean;
 const
     faDir = (faAnyFile and (not faVolumeID)) or faDirectory;
 var
    Find : TSearchRec;
 begin
    Result := false;
  { current dir }
    if Catalog > '' then begin
       if SysUtils.FindFirst (Catalog + '.', faDir, Find) = 0 then begin
          Time := Find.FindData.ftLastWriteTime;
          Result := true;
       end; { if }
     { close }
       SysUtils.FindClose (Find);
    end; { if }
 end; { GetCatalogTime }

(*************************************************************************)
(*                              formats support                          *)
(*************************************************************************)
 function LoadImage (Bmp: TBitMap; const FileName: string): boolean;
 var
    Jpg : TJpegImage;
 begin
     Try
       Case Format of
        { jpg }
          0: begin
             Jpg := TJpegImage.Create;
             Jpg.LoadFromFile (Catalog + FileName);
             if Jpg.PixelFormat = jf24bit then Bmp.PixelFormat := pf24bit
                else Bmp.PixelFormat := pf8bit;
             Bmp.Width := Jpg.Width;
             Bmp.Height := Jpg.Height;
             Bmp.Canvas.Draw (0, 0, Jpg);
             Jpg.Free;
          end; { 0 }
        { bmp }
          1: begin
             Bmp.LoadFromFile (Catalog + FileName);
          end; { 1 }
        { unsupported }
          else Error (FileName, 'Unsupported format')
       end; { Case }
       Result := true;
     Except
       on E: Exception do begin
          Error (Catalog + FileName, E.Message);
          Result := false;
       end;
     end; { try }
 end; { LoadImage }

 function SaveImage (Bmp: TBitMap; const FileName: string): boolean;
 var
    Jpg : TJpegImage;
 begin
     Try
       Case Format of
        { jpg }
          0: begin
             Jpg := TJpegImage.Create;
             if Bmp.PixelFormat = pf24bit then Jpg.PixelFormat := jf24bit
                else Jpg.PixelFormat := jf8bit;
             Jpg.CompressionQuality := JpgQuality;
             Jpg.Assign (Bmp);
             Jpg.SaveToFile (Catalog + FileName);
             Jpg.Free;
          end; { 0 }
        { bmp }
          1: begin
             Bmp.SaveToFile (Catalog + FileName);
          end; { 1 }
        { unsupported }
          else Error (FileName, 'Unsupported format')
       end; { Case }
       Result := true;
     Except
       on E: Exception do begin
          Error (FileName, E.Message);
          Result := false;
       end;
     end; { try }
 end; { SaveImage }

 function ImageSize (const FileName: string; var Width, Height : integer): boolean;
 const
     BufSize = 24;
     BufHalf = 12;
     BufTerm = 6;
     BufOffs = 16;
 type
     TByteBuffer = packed array [0..Pred (BufSize)] of Byte;
     TWordBuffer = packed array [0..Pred (BufHalf)] of Word;
     TLongBuffer = packed array [0..Pred (BufTerm)] of integer;
 var
     Bytes : TByteBuffer;
     Words : TWordBuffer absolute Bytes;
     Longs : TLongBuffer absolute Bytes;
     Image : THandle;
     E, F  : boolean;
     w, h  : word;
     x     : word;
     i     : integer;

     function SwapBytes (const Pos: integer): word;
     var
         R : TByteBuffer absolute Result;
     begin
         R [1] := Bytes [Pos];
         R [0] := Bytes [Succ (Pos)];
     end; { SwapBytes }

     function Swap32 (const Value: integer): integer;
     var
         P : TWordBuffer absolute Value;
         R : TWordBuffer absolute Result;
     begin
         R [0] := Swap (P [1]);
         R [1] := Swap (P [0]);
     end; { Swap32 }

 begin
   { init }
     Result := false;
   { open }
     Image := FileOpen (Catalog + FileName, fmOpenRead);
     if Image <= 0 then Exit;
   { read buffer }
     if FileRead (Image, Bytes, BufSize) = BufSize then begin
      { by format }
        Case Format of
         { JPEG }
           0: begin
              E := false;
              F := false;
              Repeat
                 i := 0;
               { find markers }
                 While i < BufSize do begin
                   { ok }
                     if Bytes [i] = $FF then begin
                      { next }
                        Inc (i);
                      { shift }
                        if i > BufOffs then begin
                         { move }
                           Longs [0] := Longs [4];
                           Longs [1] := Longs [5];
                         { add }
                           E := FileRead (Image, Longs [2], BufOffs) <> BufOffs;
                         { pos }
                           Dec (i, BufOffs);
                        end; { if }
                      { segment marker }
                        if F and (not E) then begin
                           if Bytes [i] in [$C0, $C1, $C2, $C3] then begin
                              Inc (i, 4);
                              Height := SwapBytes (i);
                              Inc (i, 2);
                              Width := SwapBytes (i);
                            { ok }
                              E := true;
                              Break;
                           end { else }
                           else if not (Bytes [i] in [$01, $D0..$D7, $FF]) then begin
                            { length }
                              w := SwapBytes (Succ (i));
                            { skip }
                              E := FileSeek (Image, w - Succ (BufSize) + i, 1) <= 0;
                            { reset buffer }
                              i := BufSize;
                           end; { else if }
                        end { if }
                      { start marker }
                        else F := (Bytes [i] = $D8);
                     end { if }
                   { next }
                     else Inc (i);
                 end; { While }
            { exit or read }
              Until E or (FileRead (Image, Bytes, BufSize) <> BufSize);
           end; { 0 }
         { BMP }
           1: begin
              Width := Words [9];
              Height := Words [11];
           end; { 1 }
         { GIF }
           2: begin
              Width := Words [3];
              Height := Words [4];
           end; { 2 }
         { TIFF }
           3: begin
            { swap tif }
              E := Bytes[0] = 77;
            { entry pos }
              if E then i := Swap32 (Longs [1])
                 else i := Longs [1];
            { number of entries }
              if (FileSeek (Image, i, 0) > 0) and (FileRead (Image, h, 2) = 2) then begin
                 if E then h := Swap (h);
               { each entry }
                 i := 0;
                 While (i < h) and ((Width = 0) or (Height = 0)) and
                       (FileRead (Image, Bytes, BufHalf) = BufHalf)
                 do begin
                    if E then begin
                       w := Swap(Words [0]);
                       x := Swap(Words [1]);
                    end { if }
                    else begin
                       w := Words [0];
                       x := Words [1];
                    end; { else }
                  { width entry }
                    if w = 256 then begin
                       Case x of
                          1: Width := Bytes [8];
                          3: if E then Width := Swap(Words [4]) else Width := Words [4];
                          4: if E then Width := Swap32(Longs [2]) else Width := Longs [2];
                       end; { Case }
                    end { if }
                  { height entry }
                    else if w = 257 then begin
                       Case x of
                          1: Height := Bytes [8];
                          3: if E then Height := Swap(Words [4]) else Height := Words [4];
                          4: if E then Height := Swap32(Longs [2]) else Height := Longs [2];
                       end; { Case }
                    end; { if }
                    Inc (i);
                 end; { While }
              end; { if }
           end; { 3 }
         { PCX }
           4: begin
              Width := Succ (Words[4] - Words [2]);
              Height := Succ (Words[5] - Words[3]);
           end; { 4 }
         { PNG }
           5: begin
              Width := Swap(Words [9]);
              Height := Swap(Words [11]);
           end; { 5 }
         { unsupported }
           else Error (FileName, 'Unsupported format')
        end; { Case }
     end; { if }
   { close }
     FileClose (Image);
   { result }
     if (Width <= 0) or (Height <= 0) then begin
        Error (FileName, 'Image format is not correct');
        Result := false;
     end { if }
     else Result := true;
 end; { ImageSize }

(*************************************************************************)
(*                         operations support                            *)
(*************************************************************************)
 function ResizeBmp (Bmp: TBitMap; const Name: string): boolean;
 var
     P, U  : PByteArray;
     Buf   : TBitMap;
     Factor: real;
     Bytes : integer;
     a, b  : integer;
     n, k  : integer;
     w, h  : integer;
     t, l  : integer;
     c, d  : integer;
     x, y  : real;
     r     : real;

     function Offs (const Size, Limit, Anchor: integer): integer;
     begin
          if Anchor > 0 then begin
             Result := Size - Limit;
             if Anchor = 1 then Result := Result div 2;
          end { if }
          else Result := 0
     end; { Offs }

 begin
  { init }
    if Bmp.PixelFormat = pf24bit then Bytes := 3 else Bytes := 1;
    w := Bmp.Width;
    h := Bmp.Height;
    t := 0;
    l := 0;
  { custom }
    if fCustom then begin
       x := w / CtmWidth;
       y := h / CtmHeight;
     { fill }
       if CtmMode then begin
          if x > y then Factor := x
             else Factor := y;
       end { if }
     { cut }
       else begin
            if x > y  then Factor := y
               else Factor := x;
          { offset }
            if Factor > 0 then begin
               t := Offs (h, Round (CtmHeight * Factor), AnchorY);
               l := Offs (w, Round (CtmWidth * Factor), AnchorX) * Bytes;
            end; { if }
       end; { else }
    end { if }
  { scale }
    else Factor := ((w * h) / (h + w)) / (30 + (Scale * 2.5));
  { test }
    if (Factor >= 1) or (fCustom and CtmMode) then begin
     { ok }
       Result := true;
     { resize }
       if Factor > 1 then begin
          d := Pred (w) * Bytes;
          r := Factor * Bytes;
          y := t;
          c := t;
          b := 0;
          t := Pred (Bytes);
        { move with factor }
          While c < h do begin
              P := Bmp.ScanLine [b];
              U := Bmp.ScanLine [c];
              a := 0;
              x := l;
              k := l;
              While k < d do begin
                  for n := 0 to t do P^[a + n] := U^[k + n];
                  Inc (a, Bytes);
                  x := x + r;
                  k := Round (x);
                  Dec (k, k mod Bytes);
              end; { While }
              y := y + Factor;
              c := Round (y);
              Inc (b);
          end; { While }
       end; { if }
     { custom size }
       if fCustom then begin
        { size }
          Bmp.Width := CtmWidth;
          Bmp.Height := CtmHeight;
        { fill }
          if CtmMode then begin
           { offset }
             if Factor > 1 then begin
                w := Trunc (w / Factor);
                h := Trunc (h / Factor);
             end; { if }
             t := Abs (Offs (CtmHeight, h, AnchorY));
             l := Abs (Offs (CtmWidth, w, AnchorX));
           { buffer }
             Buf := TBitMap.Create;
             Buf.Assign (Bmp);
             Buf.Width := w;
             Buf.Height := h;
           { fill }
             With Bmp.Canvas do begin
                  Brush.Color := FillColor;
                  FillRect (Rect (0, 0, CtmWidth, CtmHeight));
                  Draw (l, t, Buf);
             end; { With }
           { free }
             Buf.Free;
          end; { if }
       end { if }
     { scale }
       else begin
            Bmp.Width := Trunc (w / Factor);
            Bmp.Height := Trunc (h / Factor);
       end; { else }
    end { if }
  { error }
    else begin
         Error (Name, 'Cannot create thumbnail because image is too small');
         Result := false;
    end; { else }
 end; { ResizeBmp }

 function Include (Bmp: TBitMap; const Name: string; W, H, Z: longword): boolean;
 var
     S : string;
     R : TRect;
     q : integer;

     procedure Plus (const A: string);
     begin
         if S > '' then S := S + ' ' + A else S := A;
     end; { Plus }

 begin
     S := '';
   { comment }
     if Comment > '' then Plus (Comment);
   { image size }
     if fImgSize then Plus (SizeStr (W, H));
   { file size }
     if fFilSize then Plus (FileSizeStr (Z));
   { font }
     ParmsToFont (Bmp.Canvas.Font);
   { width }
     q := Bmp.Canvas.TextWidth (S);
   { test }
     if Bmp.Width >= Pred (q) then With Bmp do begin
      { resize }
        R.Left := 0;
        R.Right := Width;
        R.Top := Height;
        Height := R.Top + Canvas.TextHeight ('X0');
        R.Bottom := Height;
      { bground }
        Canvas.Brush.Color := BGround;
        Canvas.FillRect (R);
      { text }
        R.Left := (Width - q) div 2;
        Canvas.TextOut (R.Left, R.Top, S);
      { ok }
        Result := true;
     end { if With }
   { error }
     else begin
          Error (Name, 'Cannot include in the thumbnail because it is too small');
          Result := false;
     end; { else }
 end; { Include }

(*************************************************************************)
(*                           load\save parameters                        *)
(*************************************************************************)
 Type
     TConvert = function (Min, Max: integer): boolean;

 Var
     TxtFile : Text;
     Line    : string;
     Value   : integer;

 procedure ParmsToFont (Font: TFont);
 begin
     With Font do begin
          Name := FontName;
          Size := FontSize;
          Color := FontColor;
          Style := FontStyle;
     end; { With }
 end; { ParmsToFont }

 procedure FontToParms (Font: TFont);
 begin
     With Font do begin
          FontName := Name;
          FontSize := Size;
          FontColor := Color;
          FontStyle := Style;
     end; { With }
 end; { FontToParms }

 function OpenTxt (const FileName : string; Mode: boolean): boolean;
 begin
     AssignFile (TxtFile, FileName);
     if Mode then Rewrite (TxtFile)
        else Reset (TxtFile);
     Result := (IOresult = 0);
     if not Result then SysError (FileName, GetLastError);
 end; { OpenTxt }

 function LstToStr (List: TStrings): string;
 var
     i, j : integer;
 begin
     Result := '';
     j := Pred (List.Count);
     for i := 0 to j do begin
         Result := Result + List [i];
         if i < j then Result := Result + ListBreak;
     end; { for }
 end; { LstToStr }

 procedure SaveParms;
 var
     i : TFontStyle;
 begin
     if OpenTxt (ExePath + IniName, true) then begin
      { main }
        Writeln (TxtFile, LstToStr (Path));
        Writeln (TxtFile, PathIndex);
        Writeln (TxtFile, Format);
      { numerate }
        Writeln (TxtFile, Byte (fRename));
        Writeln (TxtFile, Order);
        Writeln (TxtFile, Byte (fDecs));
        Writeln (TxtFile, FirstNum);
        Writeln (TxtFile, Digits);
        Writeln (TxtFile, StepCount);
        Writeln (TxtFile, Prefix);
        Writeln (TxtFile, Postfix);
        Writeln (TxtFile, Byte (fAttribute));
        Writeln (TxtFile, Byte (fFileTime));
      { thumbnails }
        Writeln (TxtFile, Byte (fThumbnail));
        Writeln (TxtFile, Mark);
        Writeln (TxtFile, Scale);
        Writeln (TxtFile, Quality);
      { custom }
        Writeln (TxtFile, Byte (fCustom));
        Writeln (TxtFile, CtmWidth);
        Writeln (TxtFile, CtmHeight);
        Writeln (TxtFile, Byte(CtmMode));
        Writeln (TxtFile, AnchorX);
        Writeln (TxtFile, AnchorY);
        Writeln (TxtFile, FillColor);
      { include }
        Writeln (TxtFile, Byte (fInclude));
        Writeln (TxtFile, Comment);
        Writeln (TxtFile, Byte (fImgSize));
        Writeln (TxtFile, Byte (fFilSize));
        Writeln (TxtFile, FontName);
        Writeln (TxtFile, FontColor);
        Writeln (TxtFile, FontSize);
        Writeln (TxtFile, BGround);
      { colors }
        Writeln (TxtFile, LstToStr (Colors));
      { forms }
        Writeln (TxtFile, MainLeft);
        Writeln (TxtFile, MainTop);
        Writeln (TxtFile, MainWidth);
        Writeln (TxtFile, ViewWidth);
        Writeln (TxtFile, ViewHeight);
        Writeln (TxtFile, ViewLeft);
        Writeln (TxtFile, ViewTop);
      { font style }
        for i := Low (TFontStyle) to High (TFontStyle) do begin
            if i in FontStyle then Write (TxtFile, Byte (i), ListBreak);
        end; { for }
        Writeln (TxtFile);
      { close }
        Close (TxtFile);
     end; { if }
 end; { SaveParms }

 function Read (Min, Max: integer; Convert: TConvert): boolean;
 const
     n : integer = 0;
 var
     l : integer;
 begin
     if not Eof (TxtFile) then begin
        ReadLn (TxtFile, Line);
        Result := (IOresult = 0);
        if Result then begin
           Inc (n);
           if @Convert = nil then begin
              l := Length (Line);
              Result := (l >= Min) and (l <= Max);
           end { if }
           else Result := Convert (Min, Max)
        end; { if }
     end { if }
     else Result := false;
   { error }
     if not Result then raise EConvertError.Create ('File is not correct (line=' + IntToStr (n) + ')');
 end; { Read }

 function Number (Min, Max: integer): boolean;
 begin
     Result := StrToInt (Line, Value) and (Value >= Min) and (Value <= Max);
 end; { Number }

 function StrList (Min, Max: integer): boolean;
 var
     U       : string;
     p, k, l : integer;
 begin
     Buffer.Clear;
     Result := true;
     l := Length (Line);
     p := 1;
     While (p <= l) and (Buffer.Count < Max) do begin
         k := p;
         While (k <= l) and (Line [k] <> ListBreak) do Inc (k);
         U := Copy (Line, p, k - p);
         if U > '' then Buffer.Add (AnsiUpperCase (U))
            else Result := false;
         p := Succ (k);
     end; { While }
   { ok }
     Result := Result and (Buffer.Count >= Min) and (p > l);
 end; { StrList }

 procedure LoadParms;
 var
     i, j, k : integer;
 begin
     if OpenTxt (ExePath + IniName, false) then begin
        Try
        { main }
          if Read (1, MaxHistory, StrList) then Path.Assign (Buffer);
          if Read (0, Path.Count, Number) then PathIndex := Value;
          if Read (MinFormat, MaxFormat, Number) then Format := Value;
        { numerate }
          if Read (0, 1, Number) then fRename := Boolean (Value);
          if Read (MinOrder, MaxOrder, Number) then Order := Value;
          if Read (0, 1, Number) then fDecs := Boolean (Value);
          if Read (MinFirst, MaxFirst, Number) then FirstNum := Value;
          if Read (MinDigits, MaxDigits, Number) then Digits := Value;
          if Read (MinStep, MaxStep, Number) then StepCount := Value;
          if Read (0, LenPrefix, nil) then Prefix := Line;
          if Read (0, LenPostfix, nil) then Postfix := Line;
          if Read (0, 1, Number) then fAttribute := Boolean (Value);
          if Read (0, 1, Number) then fFileTime := Boolean (Value);
        { thumbnails }
          if Read (0, 1, Number) then fThumbnail := Boolean (Value);
          if Read (1, LenMark, nil) then Mark := Line;
          if Read (MinScale, MaxScale, Number) then Scale := Value;
          if Read (MinQuality, MaxQuality, Number) then Quality := Value;
        { custom }
          if Read (0, 1, Number) then fCustom := Boolean (Value);
          if Read (MinWidth, MaxWidth, Number) then CtmWidth := Value;
          if Read (MinHeight, MaxHeight, Number) then CtmHeight := Value;
          if Read (0, 1, Number) then CtmMode := Boolean (Value);
          if Read (MinAnchor, MaxAnchor, Number) then AnchorX := Value;
          if Read (MinAnchor, MaxAnchor, Number) then AnchorY := Value;
          if Read (MinColor, MaxColor, Number) then FillColor := Value;
        { include }
          if Read (0, 1, Number) then fInclude := Boolean (Value);
          if Read (0, LenComment, nil) then Comment := Line;
          if Read (0, 1, Number) then fImgSize := Boolean (Value);
          if Read (0, 1, Number) then fFilSize := Boolean (Value);
          if Read (0, 128, nil) then FontName := Line;
          if Read (MinColor, MaxColor, Number) then FontColor := Value;
          if Read (MinFont, MaxFont, Number) then FontSize := Value;
          if Read (MinColor, MaxColor, Number) then BGround := Value;
        { colors }
          if Read (0, 16, StrList) then Colors.Assign (Buffer);
        { forms }
          i := Screen.DesktopWidth;
          j := Screen.DesktopHeight;
          if Read (MinLeft, i, Number) then MainLeft := Value;
          if Read (MinTop, j, Number) then MainTop := Value;
          if Read (MinBreadth, MaxBreadth, Number) then MainWidth := Value;
          if Read (MinView, i, Number) then ViewWidth := Value;
          if Read (MinView, j, Number) then ViewHeight := Value;
          if Read (MinLeft, i, Number) then ViewLeft := Value;
          if Read (MinTop, j, Number) then ViewTop := Value;
        { font style }
          i := Byte (Low (TFontStyle));
          j := Byte (High (TFontStyle));
          if Read (i, j, StrList) then begin
             for k := 0 to Pred (Buffer.Count) do begin
                 Line := Buffer [k];
                 if Number (i, j) then FontStyle := FontStyle + [TFontStyle (Value)];
             end; { for }
          end; { if }
        Except
          on E: Exception do Error (ExePath + IniName, E.Message);
        end; { try }
      { close }
        Close (TxtFile);
     end; { if }
 end; { LoadParms }

(*************************************************************************)
(*                             compare                                   *)
(*************************************************************************)
 function CmpNumber (F, S: pointer): integer;
 var
     A, B : string;
     C, D : string;
     X, Y : string;
     n, k : integer;
 begin
     DecodeName (PImageInfo (F)^.Name, A, C, X);
     DecodeName (PImageInfo (S)^.Name, B, D, Y);
     Result := AnsiCompareText (A, B);
     if (Result = 0) and StrToInt (C, n) and StrToInt (D, k) then Result := n - k;
     if Result = 0 then Result := AnsiCompareText (C, D);
     if Result = 0 then Result := AnsiCompareText (X, Y);
     if fDecs then Result := - Result;
 end; { CmpNumber }

 function CmpSize (F, S: pointer): integer;
 begin
     Result := PImageInfo (F)^.Size - PImageInfo (S)^.Size;
     if fDecs then Result := - Result;
 end; { CmpSize }

 function CmpTime (F, S: pointer): integer;
 begin
     Result := CompareFileTime (PImageInfo (F)^.Time, PImageInfo (S)^.Time);
     if Result = 0 then Result := PImageInfo (F)^.Size - PImageInfo (S)^.Size;
     if fDecs then Result := - Result;
 end; { CmpTime }

 function CmpHeight (F, S: pointer): integer;
 begin
     Result := PImageInfo (F)^.Height - PImageInfo (S)^.Height;
     if Result = 0 then Result := PImageInfo (F)^.Width - PImageInfo (S)^.Width;
     if Result = 0 then Result := PImageInfo (F)^.Size - PImageInfo (S)^.Size;
     if fDecs then Result := - Result;
 end; { CmpHeight }

 function CmpWidth (F, S: pointer): integer;
 begin
     Result := PImageInfo (F)^.Width - PImageInfo (S)^.Width;
     if Result = 0 then Result := PImageInfo (F)^.Height - PImageInfo (S)^.Height;
     if Result = 0 then Result := PImageInfo (F)^.Size - PImageInfo (S)^.Size;
     if fDecs then Result := - Result;
 end; { CmpWidth }

 function CmpTemp (F, S: pointer): integer;
 begin
     Result := PImageInfo (F)^.Temp - PImageInfo (S)^.Temp;
     if Result = 0 then Result := PImageInfo (F)^.Size - PImageInfo (S)^.Size;
     if fDecs then Result := - Result;
 end; { CmpTemp }

(*************************************************************************)
(*                                image list                             *)
(*************************************************************************)
 Const
     faUse = faAnyFile and (not faVolumeID) and (not faDirectory);

 constructor TImageList.Create;
 begin
     inherited Create;
     Capacity := 512;
     Drop;
     Randomize;
 end; { Create }

 procedure TImageList.Drop;
 begin
     SortOrder := -1;
     Decrease  := false;
     HaveSize  := false;
     ViewCount := 0;
 end; { Drop }

 procedure TImageList.DisposeItem (var P: PImageInfo);
 begin
     if P <> nil then begin
        SetLength (P^.Name, 0);
        Dispose (P);
        P := nil;
     end; { if }
 end; { DisposeItem }

 procedure TImageList.Clear;
 var
     i : integer;
 begin
     for i := 0 to Pred (Count) do begin
         if List [i] <> nil then begin
            DisposeItem (PImageInfo (List [i])^.Thumbnail);
            DisposeItem (PImageInfo (List [i]));
         end; { if }
     end; { for }
     Drop;
     inherited Clear;
 end; { Clear }

 procedure TImageList.InitInfo (var Find : TSearchRec; Info: PImageInfo);
 begin
     With Info^ do begin
        { file parm }
          Time := Find.FindData.ftLastWriteTime;
          Size := Find.Size;
          Attr := Find.Attr;
          Name := Find.Name;
        { image parm }
          Height := 0;
          Width := 0;
        { work }
          Thumbnail := nil;
          Temp := 0;
          if isThumbnail (Name) then Inc (ViewCount);
     end; { With }
 end; { InitInfo }

 function TImageList.Scan: boolean;
 var
     Find : TSearchRec;
     Info : PImageInfo;
 begin
   { init }
     Clear;
   { test path }
     if isPathExist (Catalog) then begin
        Result := true;
      { scan }
        if SysUtils.FindFirst (Catalog + '*' + Formats [Format], faUse, Find) = 0 then begin
           Repeat
                New (Info);
                InitInfo (Find, Info);
                Add (Info);
           Until (SysUtils.FindNext (Find) <> 0);
        end; { if }
        SysUtils.FindClose (Find);
      { sort }
        Sort (0, false);
     end { if }
     else begin
          SysError (Catalog, ERROR_PATH_NOT_FOUND);
          Result := false;
     end; { else }
 end; { Scan }

 procedure TImageList.Start (const Mssg: string);
 begin
     Inform (BegPrefix + AnyPrefix + Mssg);
 end; { Start }

 procedure TImageList.Stop;
 begin
     Inform (EndPrefix + AnyPrefix + 'Done');
 end; { Stop }

 procedure TImageList.MarkChange;
 var
     i : integer;
 begin
     ViewCount := 0;
     for i := 0 to Pred (Count)
      do if isThumbnail (PImageInfo (List[i])^.Name) then Inc (ViewCount);
 end; { MarkChange }

 procedure TImageList.SetOrder;
 var
     i : integer;
 begin
     for i := 0 to Pred (Count) do PImageInfo (List[i])^.Temp := i;
 end; { SetOrder }

 function TImageList.LoadSize : boolean;
 var
     i, j, k : integer;
 begin
     Result := true;
     if HaveSize then Exit;
     k := Count div 10;
     j := 0;
     for i := 0 to Pred (Count) do begin
         With PImageInfo (List[i])^ do begin
            if not ImageSize (Name, Width, Height) then begin
               Inc (j);
               Temp := 0;
            end; { if }
         end; { With }
       { abort }
         if (j > k) or isCancel then begin
            Result := false;
            Exit;
         end; { if }
     end; { for }
     HaveSize := true;
 end; { LoadSize }

 function TImageList.Sort (Odr: TOrder; Dcs: boolean): boolean;
 var
     Cmp : TListSortCompare;
     i   : integer;
 begin
     Result := true;
     if (Odr = SortOrder) and (Decrease = Dcs) then Exit;
   { init }
     Case Odr of
        1: Cmp := @CmpSize;
        2: Cmp := @CmpTime;
        3: begin
           Result := LoadSize;
           Cmp := @CmpWidth;
        end; { 3 }
        4: begin
           Result := LoadSize;
           Cmp := @CmpHeight;
        end { 4 };
        5: begin
           Result := LoadSize;
           if Result then begin
              for i := 0 to Pred (Count)
               do With PImageInfo (List[i])^ do Temp := Width * Height;
           end; { if }
           Cmp := @CmpTemp;
        end; { 5 }
        6: begin
           Result := LoadSize;
           if Result then begin
              for i := 0 to Pred (Count) do begin
                  With PImageInfo (List[i])^ do begin
                       if Height <> 0 then Temp := Round ((Width / Height) * 1000)
                          else Temp := 0;
                  end; { With }
              end; { for }
           end; { if }
           Cmp := @CmpTemp;
        end; { 6 }
        7: begin
           for i := 0 to Pred (Count)
            do With PImageInfo (List[i])^ do Temp := Random (MaxInt);
           Cmp := @CmpTemp;
        end; { 7 }
        else Cmp := @CmpNumber;
     end; { Case }
   { ok }
     if Result then begin
      { order }
        SortOrder := Odr;
      { exchange }
        Decrease := fDecs;
        fDecs := Dcs;
      { sort }
        inherited Sort (Cmp);
      { restore }
        fDecs := Decrease;
        Decrease := Dcs;
     end; { if }
 end; { Sort }

 function TImageList.Search (const Name: string; var Index: integer): boolean;
 var
     i : integer;
 begin
     for i := 0 to Pred (Count) do begin
         if (List[i] <> nil) and
            (AnsiCompareText (PImageInfo (List[i])^.Name, Name) = 0)
         then begin
            Index := i;
            Result := true;
            Exit;
         end; { if }
     end; { for }
     Result := false;
 end; { Search }

 function TImageList.isCancel : boolean;
 begin
     Application.ProcessMessages;
     if Cancel then Support.Error ('', 'Job was cancelled');
     Result := Cancel;
 end; { isCancel }

 function TImageList.Pack: boolean;
 var
     P    : PImageInfo;
     i, j : integer;
 begin
     Result := true;
     Start ('Conformity test');
   { have thumbnails }
     if ViewCount > 0 then begin
      { find thumbnails }
        for i := 0 to Pred (Count) do begin
            P := PImageInfo (List [i]);
            if (P <> nil) and (not isThumbnail (P^.Name)) and
               Search (ThumbnailName (P^.Name), j)
            then begin
                 P^.Thumbnail := List [j];
                 List [j] := nil;
            end; { if }
        end; { for }
      { pack and test }
        for i := Pred (Count) downto 0 do begin
            P := PImageInfo (List [i]);
            if P <> nil then begin
              { invalid thumnail }
               if P^.Thumbnail = nil then begin
                  if isThumbnail (P^.Name) then begin
                     Support.Error (P^.Name, 'The program cannot find the image for the thumbnail');
                     Result := false;
                  end { if }
                  else if not fThumbnail then begin
                     Warning (P^.Name, 'The program cannot find the thumbnail for the image');
                  end; { if }
               end; { if }
            end { if }
            else Delete (i);
          { cancel }
            if isCancel then begin
               Result := false;
               Exit;
            end; { if }
        end; { for }
     end; { if }
     Stop;
 end; { Pack }

 function TImageList.SetReadOnly (P: PImageInfo; ReadOnly: boolean): boolean;
 var
     A : integer;
 begin
     if ReadOnly then A := P^.Attr or faReadOnly
        else A := P^.Attr and (not faReadOnly);
     Result := true;
   { change }
     if A <> P^.Attr then begin
        if FileSetAttr (Catalog + P^.Name, A) <> 0 then begin
           SysError (P^.Name, GetLastError);
           Result := false;
        end { if }
        else P^.Attr := A;
     end; { if }
 end; { SetReadOnly }

 procedure TImageList.CreateThumbnails;
 var
     P    : PImageInfo;
     Bmp  : TBitMap;
     Find : TSearchRec;
     E    : boolean;
     i, j : integer;
 begin
     Start ('Create thumbnails');
   { init }
     j := 0;
     Bmp := TBitMap.Create;
   { create }
     for i := 0 to Pred (Count) do begin
         P := List [i];
       { open & convert }
         if LoadImage (Bmp, P^.Name) then begin
          { ok }
            Inc (j);
          { parms }
            With P^ do begin
                 Height := Bmp.Height;
                 Width := Bmp.Width;
            end; { With }
          { resize }
            if ResizeBmp (Bmp, P^.Name) then begin
             { new }
               if P^.Thumbnail = nil then begin
                  New (P^.Thumbnail);
                  FillChar (P^.Thumbnail^, SizeOf (TImageInfo), #0);
                  P^.Thumbnail^.Name := ThumbnailName (P^.Name);
                  E := true;
               end { if }
               else E := false;
             { write comment }
               if fInclude then With P^ do Include (Bmp, Thumbnail^.Name, Width, Height, Size);
             { clear readonly & save }
               if (E or SetReadOnly (P^.Thumbnail, false)) and
                   SaveImage (Bmp, P^.Thumbnail^.Name)
               then begin
                { init }
                  SysUtils.FindFirst (Catalog + P^.Thumbnail^.Name, faUse, Find);
                  InitInfo (Find, P^.Thumbnail);
                  SysUtils.FindClose (Find);
                { thumbnail size }
                  With P^.Thumbnail^ do begin
                     Height := Bmp.Height;
                     Width := Bmp.Width;
                  end; { With }
                { report }
                  With P^.Thumbnail^ do Inform (Name + ' ' + SizeStr (Width, Height) + ' ' + IntToStr (Size));
               end { if }
             { free }
               else if E then DisposeItem (P^.Thumbnail);
            end; { if }
         end; { if }
       { abort }
         if isCancel then Break;
     end; { for }
   { ok }
     if not Cancel then begin
        HaveSize := j > (Count * 0.9);
        Stop;
     end; { if }
   { free }
     Bmp.Free;
 end; { Thumbnails }

 function TImageList.RenameImage (P: PImageInfo; const Name: string): boolean;

  function RenameFile (var Dst: string; const Src: string): boolean;
  begin
      Inform (Dst + ' ' + Src);
      Result := SysUtils.RenameFile (Catalog + Dst, Catalog + Src);
      if Result then Dst := Src
         else SysError (Dst, GetLastError);
  end; { RenameFile }

 begin
     Result := RenameFile (P^.Name, Name) and
         ((P^.Thumbnail = nil) or RenameFile (P^.Thumbnail^.Name, ThumbnailName (Name)));
 end; { RenameImage }

 function TImageList.Rename: boolean;

 var
     Img : PImageInfo;
     Tmp : string;
     i   : integer;

   function CircleRename (P: PImageInfo): boolean;
   var
       Cur : string;
       j   : integer;
   begin
     { end of circle }
       if P^.Temp < 0  then begin
          Result := RenameImage (P, Tmp);
          Exit;
       end; { if }
     { new name }
       j := P^.Temp * StepCount + FirstNum;
       Cur := EncodeName  (j);
     { validate }
       if not isThumbnail (Cur) then begin
       { init }
         Result := true;
       { reset }
         P^.Temp := -1;
       { test }
         if P^.Name <> Cur then begin
          { test for exist }
            if AnsiCompareText (P^.Name, Cur) <> 0 then begin
               if Search (Cur, j) then Result := CircleRename (List [j]);
            end; { if }
         { rename }
            if Result then Result := RenameImage (P, Cur);
         end; { if }
       end { if }
     { error }
       else begin
          Support.Error (Cur, 'The filename ending is equal to the thumbnail mark');
          Result := false;
       end; { else }
   end; { CircleRename }

 begin
   { mssg }
     if fDecs then Tmp := ', decrease'
        else Tmp := '';
     Start ('Sort ' + Orders [Order] + Tmp);
   { sort by order }
     if not Sort (Order, fDecs) then begin
        Result := false;
        Exit;
     end { if }
     else Result := true;
     Stop;
   { set order }
     SetOrder;
   { temp name }
     Repeat
          Tmp := AppName + IntToStr (Random (MaxInt)) + Formats [Format];
     Until not (isThumbnail (Tmp) or FileExists (Catalog + Tmp));
   { rename all }
     Start ('Rename');
     for i := 0 to Pred (Count) do begin
       { item }
         Img := List [i];
       { rename }
         if Img^.Temp >= 0 then begin
            Result := (not isCancel) and CircleRename (Img);
          { abort }
            if not Result then Exit;
         end; { if }
     end; { for }
     Stop;
   { set new first }
     FirstNum := (Pred (Count) * StepCount + FirstNum) + StepCount;
 end; { Rename }

 function TImageList.UpdateTime (P: PImageInfo; const Time: TSystemTime): boolean;
 var
     H : THandle;
     T : TFileTime;
 begin
     Result := false;
   { drop redonly }
     if SetReadOnly (P, false) then begin
      { open }
        H := FileOpen (Catalog + P^.Name, fmOpenWrite);
        if H > 0 then begin
         { update }
           Result := SystemTimeToFileTime (Time, T) and SetFileTime (H, nil, nil, @T);
         { close }
           FileClose (H);
        end; { if }
      { error }
        if not Result then SysError (P^.Name, GetLastError);
     end; { if }
 end; { UpdateTime }

 function TImageList.Update: boolean;
 const
     OneMSec : TDateTime = 1 / (1000 * 60 * 60 * 24);
 var
     P : PImageInfo;
     U : TSystemTime;
     T : TDateTime;
     i : integer;
 begin
     Result := true;
   { update time }
     if fFileTime then begin
      { init }
        Start ('Update file time');
        GetSystemTime (U);
        T := SystemTimeToDateTime (U);
      { update }
         for i := 0 to Pred (Count) do begin
             P := List [i];
           { time }
             T := T + OneMSec;
             DateTimeToSystemTime (T, U);
           { image }
             Result := (not isCancel) and UpdateTime (P, U) and
                       ((P^.Thumbnail = nil) or UpdateTime (P^.Thumbnail, U));
           { abort }
             if not Result then Exit;
         end; { for }
         Stop;
     end; { if }
   { read only }
     if fAttribute then Start ('Set readonly attribute')
        else Start ('Clear readonly attribute');
     for i := 0 to Pred (Count) do begin
         P := List [i];
         Result := (not isCancel) and SetReadOnly (P, fAttribute) and
                   ((P^.Thumbnail = nil) or SetReadOnly (P^.Thumbnail, fAttribute));
       { abort }
         if not Result then Exit;
     end; { for }
     Stop;
 end; { Update }

 procedure TImageList.Run;
 begin
   { init }
     Inform ('START ' + DateTimeToStr (Now) + ' ' + Catalog);
     Cancel := false;
   { pack and test }
     if Pack then begin;
      { thumbnails }
        if fThumbnail then CreateThumbnails;
      { rename }
        if (not Cancel) and fRename then begin
           if Rename then Update;
        end; { if }
     end; { if }
     Inform ('STOP');
 end; { Run }

 End.
