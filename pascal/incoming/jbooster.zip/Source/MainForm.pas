(*************************************************************************)
(*                                jBooster                               *)
(*                       Delphi-5 or Delphi-6 compatible                 *)
(*                        (c) pulsar@mail.primorye.ru                    *)
(*************************************************************************)
{$J+,H+,A+,B-,I-}
 Unit MainForm;

 Interface

 Uses
  { standart }
    Windows, Messages, SysUtils, Classes,
  { vcl }
    Graphics, Controls, Forms, Dialogs,  StdCtrls, ComCtrls, ExtCtrls,
  { formats }
    JPeg,
  { private }
    Support, ViewerForm, ReportForm, AlignForm;


 Type
    TFormMain = class(TForm)
    { main }
      LabelFormat: TLabel;
      BoxFormat: TComboBox;
      LabelPath: TLabel;
      EditPath: TComboBox;
      ButtonPath: TButton;
      FileListBox: TListBox;
      ButtonRun: TButton;
      ButtonExit: TButton;
    { numerate }
      CheckRename: TCheckBox;
      PanelRename: TPanel;
      LabelOrder: TLabel;
      BoxOrder: TComboBox;
      CheckDecs: TCheckBox;
      LabelPrefix: TLabel;
      EditPrefix: TEdit;
      LabelFirst: TLabel;
      EditFirst: TEdit;
      LabelDigits: TLabel;
      EditDigits: TEdit;
      LabelStep: TLabel;
      EditStep: TEdit;
      LabelPostfix: TLabel;
      EditPostfix: TEdit;
      CheckReadOnly: TCheckBox;
      CheckFileTime: TCheckBox;
    { thumbnails }
      CheckThumbnails: TCheckBox;
      PanelThumbnails: TPanel;
      LabelMark: TLabel;
      EditMark: TEdit;
      LabelScale: TLabel;
      TrackScale: TTrackBar;
      LabelQuality: TLabel;
      TrackQuality: TTrackBar;
    { custom size }
      CheckCustom: TCheckBox;
      PanelCustom: TPanel;
      LabelWidth: TLabel;
      EditWidth: TEdit;
      LabelHeight: TLabel;
      EditHeight: TEdit;
      RadioCut: TRadioButton;
      RadioFill: TRadioButton;
      ButtonAlign: TButton;
      ButtonColor: TButton;
    { include }
      CheckInclude: TCheckBox;
      PanelInclude: TPanel;
      PanelNull: TPanel;
      LabelText: TLabel;
      EditText: TEdit;
      CheckImage: TCheckBox;
      CheckFile: TCheckBox;
      ButtonFont: TButton;
      ButtonGround: TButton;
      FontDialog: TFontDialog;
      ColorDialog: TColorDialog;
    { form handlers }
      procedure FormShow(Sender: TObject);
      procedure FormClose(Sender: TObject; var Action: TCloseAction);
      procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
      procedure ShowHint(var HintStr: string; var CanShow: Boolean; var HintInfo: THintInfo);
      procedure AppActivate(Sender: TObject);
      procedure TestNumeric (Sender: TObject; var Key: char);
      procedure TestFileName (Sender: TObject; var Key: char);
    { main handlers }
      procedure BoxFormatKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
      procedure BoxFormatChange(Sender: TObject);
      procedure EditPathKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
      procedure EditPathExit(Sender: TObject);
      procedure EditPathChange(Sender: TObject);
      procedure ButtonPathClick(Sender: TObject);
      procedure FileListBoxDblClick(Sender: TObject);
      procedure FileListBoxKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
      procedure FileListBoxDrawItem(Control: TWinControl; Index: Integer; Rect: TRect; State: TOwnerDrawState);
      procedure ButtonRunClick(Sender: TObject);
      procedure ButtonExitClick(Sender: TObject);
    { numerate handlers }
      procedure CheckRenameClick(Sender: TObject);
      procedure BoxOrderKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
      procedure BoxOrderChange(Sender: TObject);
      procedure CheckDecsClick(Sender: TObject);
      procedure EditPrefixChange(Sender: TObject);
      procedure EditFirstChange(Sender: TObject);
      procedure EditFirstExit(Sender: TObject);
      procedure EditDigitsChange(Sender: TObject);
      procedure EditDigitsExit(Sender: TObject);
      procedure EditPostfixChange(Sender: TObject);
      procedure EditStepChange(Sender: TObject);
      procedure EditStepExit(Sender: TObject);
      procedure CheckReadOnlyClick(Sender: TObject);
      procedure CheckFileTimeClick(Sender: TObject);
    { thumbnails handlers }
      procedure EditMarkChange(Sender: TObject);
      procedure EditMarkExit(Sender: TObject);
      procedure EditMarkKeyPress(Sender: TObject; var Key: Char);
      procedure CheckThumbnailsClick(Sender: TObject);
      procedure TrackScaleChange(Sender: TObject);
      procedure TrackQualityChange(Sender: TObject);
    { custom size handlers }
      procedure CheckCustomClick(Sender: TObject);
      procedure EditWidthChange(Sender: TObject);
      procedure EditWidthExit(Sender: TObject);
      procedure EditHeightChange(Sender: TObject);
      procedure EditHeightExit(Sender: TObject);
      procedure RadioModeClick(Sender: TObject);
      procedure ButtonAlignClick(Sender: TObject);
      procedure ButtonColorClick(Sender: TObject);
    { include handlers }
      procedure CheckIncludeClick(Sender: TObject);
      procedure EditTextChange(Sender: TObject);
      procedure CheckImageClick(Sender: TObject);
      procedure CheckFileClick(Sender: TObject);
      procedure ButtonFontClick(Sender: TObject);
      procedure ButtonGroundClick(Sender: TObject);
      procedure FontDialogShow(Sender: TObject);
      procedure ColorDialogShow(Sender: TObject);
    private
      LockField : pointer;    // current field
      LastMark  : string;     // last thumbnail-mark value
      LastScan  : TFileTime;  // autorescan support
    { support }
      procedure InitEdit (Edit: TEdit; MaxLen: integer; const Str: string);
      procedure SetEdit (Edit: TControl; const Str: string);
      function GetEdit (var Str: string; Edit: TControl): boolean;
      procedure GetNumeric (Edit: TEdit; var Int: integer; Min, Max, Std: integer);
      procedure ResetNumeric (Edit: TEdit; Val: integer);
      procedure GetFileName (var Val: string; Edit: TEdit; Min: integer);
      procedure InitBox (Box: TComboBox; Count, Index: integer);
      function KeyBox (Box: TComboBox; var Key: word): boolean;
      function BoxChange (Box: TComboBox; var Index: integer): boolean;
      procedure SetBox (Box: TComboBox; Index: integer);
      function GetBox (var Index: integer; Box: TComboBox): boolean;
      procedure SetCheck (Check: TButtonControl; Val: boolean);
      function GetCheck (var Val: boolean; Check: TButtonControl): boolean;
      procedure InitTrack (Track: TTrackBar; Min, Max, Val : integer);
      procedure GetTrack (var Val: integer; Track: TTrackBar);
    { operate }
      procedure SetStatus (const S: string = '');
      procedure UpdateQuality;
      procedure Rescan;
      procedure TestGo;
      procedure ViewFile;
    end; { TFormMain }

 Var
    FormMain: TFormMain;

 Implementation

{$R *.DFM}

(*************************************************************************)
(*                              form                                     *)
(*************************************************************************)
 procedure TFormMain.FormShow(Sender: TObject);
 var
     i : integer;
 begin
   { init app }
     Application.Title := AppName;
     Application.OnShowHint := ShowHint;
     Application.HintPause := 300;
     Application.OnActivate := AppActivate;
   { init support }
     ExePath := PathDelimiter (ExtractFilePath (Application.ExeName));
     Path := EditPath.Items;
     Colors := ColorDialog.CustomColors;
     FileListBox.Items.Capacity := 512;
     Buffer := FileListBox.Items;
     Images := TImageList.Create;
   { parameters }
     LoadParms;
   { main form }
     Constraints.MinWidth := MinBreadth;
     Constraints.MaxWidth := MaxBreadth;
     Left := MainLeft;
     Top := MainTop;
     Width := MainWidth;
   { viewer form }
     FormViewer.Left := ViewLeft;
     FormViewer.Top := ViewTop;
     FormViewer.Width := ViewWidth;
     FormViewer.Height := ViewHeight;
     FormViewer.Constraints.MinHeight := MinView;
     FormViewer.Constraints.MinWidth := MinView;
   { main fields }
     for i := MinFormat to MaxFormat do BoxFormat.Items.Add (Formats [i]);
     InitBox (BoxFormat, Succ (MaxFormat), Format);
     With EditPath do begin
          MaxLength := MAX_PATH;
          CharCase := ecUpperCase;
          if Items.Count = 0 then Items.Add (ExePath);
     end; { With }
     InitBox (EditPath, MaxHistory, PathIndex);
   { numerate }
     SetCheck (CheckRename, fRename);
     for i := MinOrder to MaxOrder do BoxOrder.Items.Add (Orders [i]);
     InitBox (BoxOrder, Succ (MaxOrder), Order);
     SetCheck (CheckDecs, fDecs);
     InitEdit (EditPrefix, LenPrefix, Prefix);
     InitEdit (EditFirst, LenFirst, IntToStr (FirstNum));
     InitEdit (EditDigits, LenDigits, IntToStr (Digits));
     InitEdit (EditStep, LenStep, IntToStr (StepCount));
     InitEdit (EditPostfix, LenPostfix, Postfix);
     SetCheck (CheckReadOnly, fAttribute);
     SetCheck (CheckFileTime, fFileTime);
   { thumbnails }
     SetCheck (CheckThumbnails, fThumbnail);
     LastMark := Mark;
     InitEdit (EditMark, LenMark, Mark);
     InitTrack (TrackScale, MinScale, MaxScale, Scale);
     InitTrack (TrackQuality, MinQuality, MaxQuality, Quality);
   { custom }
     SetCheck (CheckCustom, fCustom);
     InitEdit (EditWidth, LenWidth, IntToStr (CtmWidth));
     InitEdit (EditHeight, LenHeight, IntToStr (CtmHeight));
     SetCheck (RadioCut, not CtmMode);
     SetCheck (RadioFill, CtmMode);
   { include }
     SetCheck (CheckInclude, fInclude);
     InitEdit (EditText, LenComment, Comment);
     SetCheck (CheckImage, fImgSize);
     SetCheck (CheckFile, fFilSize);
   { font }
     With FontDialog do begin
          ParmsToFont (Font);
          MaxFontSize := MaxFont;
          MinFontSize := MinFont;
     end; { With }
   { init }
     CheckRenameClick (Self);
     CheckThumbnailsClick (Self);
     Rescan;
 end; { FormShow }

 procedure TFormMain.FormClose(Sender: TObject; var Action: TCloseAction);
 var
     w, h : integer;
 begin
   { init }
     if PathIndex < 0 then PathIndex := 0;
     h := Screen.DesktopHeight;
     w := Screen.DesktopWidth;
   { main }
     With FormMain do begin
        if Left < 0 then MainLeft := 0
           else if (Left + Width) > w then MainLeft := w - Width
                   else MainLeft := Left;
        if Top < 0 then MainTop := 0
           else if (Top + Height) > h then MainTop := h - Height
                   else MainTop := Top;
        MainWidth := Width;
     end; { With }
   { viewer }
     With FormViewer do begin
        if Width > w then ViewWidth := w
           else ViewWidth := Width;
        if Height > h then  ViewHeight := h
           else ViewHeight := Height;
        if Left < 0 then ViewLeft := 0
           else if (Left + ViewWidth) > w then ViewLeft := w - ViewWidth
                   else ViewLeft := Left;
        if Top < 0 then ViewTop := 0
           else if (Top + ViewHeight) > h then ViewTop := h - ViewHeight
                   else ViewTop := Top;
     end; { With }
   { write }
     SaveParms;
   { free }
     Images.Free;
 end; { FormClose }

 procedure TFormMain.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
   { help }
     if (Key = VK_HELP) or (Key = VK_F1) then begin
        if not FormViewer.Help (ExePath + HlpName) then begin
           Inform (AppName + ' ' + Version + '. Freeware'#13#13'(c) pulsar@mail.primorye.ru');
        end; { if }
     end; { if }
 end; { FormKeyDown }

 procedure TFormMain.ShowHint
 (var HintStr: string; var CanShow: Boolean; var HintInfo: THintInfo);
 begin
     With HintInfo do begin
        if HintControl = TrackScale then HintStr := IntToStr (Scale)
        else if HintControl = TrackQuality then HintStr := IntToStr (JpgQuality)
        else if HintControl = ButtonGround then HintColor := BGround
        else if HintControl = ButtonColor then HintColor := FillColor
        else if HintControl = ButtonFont then HintStr := FontName + ' ' + IntToStr (FontSize)
        else if HintControl = ButtonAlign then HintStr := HAnchors [AnchorX] + '-' + VAnchors [AnchorY];
     end; { With }
 end; { ShowHint }

(*************************************************************************)
(*                            support                                    *)
(*************************************************************************)
 procedure TFormMain.InitEdit (Edit: TEdit; MaxLen: integer; const Str: string);
 begin
     Edit.MaxLength := MaxLen;
     SetEdit (Edit, Str);
 end; { InitEdit }

 procedure TFormMain.SetEdit (Edit: TControl; const Str: string);
 begin
     LockField := Edit;
     if Edit is TEdit then TEdit(Edit).Text := Str
        else if Edit is TComboBox then TComboBox(Edit).Text := Str;
     LockField := nil;
 end; { SetEdit }

 function TFormMain.GetEdit (var Str: string; Edit: TControl): boolean;
 begin
     if LockField <> Edit then begin
        if Edit is TEdit then Str := TEdit(Edit).Text
           else if Edit is TComboBox then Str := TComboBox(Edit).Text;
        Result := true;
     end { if }
     else Result := false;
 end; { GetEdit }

 procedure TFormMain.GetNumeric (Edit: TEdit; var Int: integer; Min, Max, Std: integer);
 var
     S : string;
     n : integer;
 begin
     if not GetEdit (S, Edit) then Exit;
   { test }
     if S > '' then begin
        n := Std;
        if StrToInt (S, n) and (n <= Max) and (n >= Min) then Int := n
        else begin
             if n < Min then Int := Min
                else if n > Max then Int := Max
                        else Int := Std;
             SetEdit (Edit, IntToStr (Int));
        end; { else }
     end { if }
     else Int := Std;
 end; { GetNumeric }

 procedure TFormMain.TestNumeric (Sender: TObject; var Key: char);
 begin
     if not ((Key in Numerics) or (Key = #8)) then Key := #0;
 end; { TestNumeric }

 procedure TFormMain.ResetNumeric (Edit: TEdit; Val: integer);
 begin
     if Edit.Text = '' then SetEdit (Edit, IntToStr (Val));
 end; { ResetNumeric }

 procedure TFormMain.GetFileName (var Val: string; Edit: TEdit; Min: integer);
 var
     S    : string;
     i, j : integer;
 begin
     if not GetEdit (S, Edit) then Exit;
     j := Length (S);
   { test len }
     if j >= Min then begin
        for i := 1 to j do begin
          { illegal char }
            if S [i] in Illegals then begin
               SetEdit (Edit, Val);
               Exit;
            end; { if}
        end; { for }
      { ok }
        Val := S;
     end; { if }
 end; { GetFileName }

 procedure TFormMain.TestFileName (Sender: TObject; var Key: char);
 begin
      if (Key in Illegals) and (Key <> #8) then Key := #0;
 end; { TestFileName }

 function TFormMain.BoxChange (Box: TComboBox; var Index: integer): boolean;
 var
     i : integer;
 begin
     Result := GetBox (i, Box) and (i >= 0) and (i <> Index);
     if Result then Index := i;
 end; { BoxChange }

 function TFormMain.KeyBox (Box: TComboBox; var Key: word): boolean;
 begin
     Result := false;
     if ((Key = VK_DOWN) or (Key = VK_UP)) and (not Box.DroppedDown) then begin
         Box.DroppedDown := true;
         Key := 0;
     end { if }
     else if Key = VK_RETURN then begin
             Result := true;
             Key := 0
     end; { else }
 end; { KeyBox }

 procedure TFormMain.InitBox (Box: TComboBox; Count, Index: integer);
 begin
     LockField := Box;
     Box.Items.Capacity := Count;
     Box.DropDownCount := Count;
     SetBox (Box, Index);
 end; { InitBox }

 procedure TFormMain.SetBox (Box: TComboBox; Index: integer);
 begin
     LockField := Box;
     Box.ItemIndex := Index;
     LockField := nil;
 end; { SetBox }

 function TFormMain.GetBox (var Index: integer; Box: TComboBox): boolean;
 begin
     if LockField <> Box then begin
        Index := Box.ItemIndex;
        Result := true;
     end { if }
     else Result := false;
 end; { GetBox }

 procedure TFormMain.SetCheck (Check: TButtonControl; Val: boolean);
 begin
     LockField := Check;
     if Check is TCheckBox then TCheckBox (Check).Checked := Val
        else if Check is TRadioButton then TRadioButton (Check).Checked := Val;
     LockField := nil;
 end; { SetCheck }

 function TFormMain.GetCheck (var Val: boolean; Check: TButtonControl): boolean;
 begin
     if LockField <> Check then begin
        if Check is TCheckBox then Val := TCheckBox (Check).Checked
           else if Check is TRadioButton then Val := TRadioButton (Check).Checked;
        Result := true;
     end { if }
     else Result := false;
 end; { GetCheck }

 procedure TFormMain.InitTrack (Track: TTrackBar; Min, Max, Val : integer);
 begin
     LockField := Track;
     Track.Min := Min;
     Track.Max := Max;
     Track.Position := Val;
     LockField := nil;
 end; { InitTrack }

 procedure TFormMain.GetTrack (var Val: integer; Track: TTrackBar);
 begin
     if LockField <> Track then Val := Track.Position;
 end; { GetTrack }

(*************************************************************************)
(*                                   main                                *)
(*************************************************************************)
 procedure TFormMain.BoxFormatKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
     if KeyBox (BoxFormat, Key) then Rescan;
 end; { BoxFormatKeyDown }

 procedure TFormMain.BoxFormatChange(Sender: TObject);
 begin
     if BoxChange (BoxFormat, Format) then begin
        UpdateQuality;
        Rescan;
     end; { if }
 end; { BoxFormatChange }

 procedure TFormMain.EditPathKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
     if KeyBox (EditPath, Key) then Rescan;
 end; { EditPathKeyDown }

 procedure TFormMain.EditPathExit(Sender: TObject);
 begin
     if PathDelimiter (EditPath.Text) <> Catalog then Rescan;
 end; { EditPathExit }

 procedure TFormMain.EditPathChange(Sender: TObject);
 begin
     if BoxChange (EditPath, PathIndex) then Rescan;
 end;  { EditPathChange }

 procedure TFormMain.ButtonPathClick (Sender: TObject);
 begin
    DialogCaption := 'Browse';
    if SelectDirectory then begin
       SetEdit (EditPath, Catalog);
       Rescan;
    end; { if }
 end; { ButtonPathClick }

 procedure TFormMain.FileListBoxDrawItem(Control: TWinControl; Index: Integer; Rect: TRect; State: TOwnerDrawState);
 var
     S : string;
 begin
     if LockField = FileListBox then Exit;
     With FileListBox do begin
          Canvas.FillRect(Rect);
          S := Items [Index];
          if (State = []) and isThumbnail (S)
             then Canvas.Font.Color := clInactiveCaptionText;
          Canvas.TextOut (Rect.Left + 2, Rect.Top, S);
     end; { With }
 end; { FileListBoxDrawItem }

 procedure TFormMain.FileListBoxDblClick(Sender: TObject);
 begin
     ViewFile;
 end; { FileListBoxDblClick }

 procedure TFormMain.FileListBoxKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
     if Key = VK_RETURN then begin
        ViewFile;
        Key := 0;
     end; { else }
 end; { FileListBoxKeyDown }

 procedure TFormMain.UpdateQuality;
 var
     E : boolean;
 begin
     E := fThumbnail and (Format = 0);
     LabelQuality.Enabled := E;
     TrackQuality.Enabled := E;
 end; { UpdateQuality }

 procedure TFormMain.TestGo;
 begin
    ButtonRun.Enabled := (fRename or fThumbnail) and (Images.Count > 0)
 end; { TestGo }

 procedure TFormMain.ViewFile;
 begin
     With FileListBox do begin
       if (ItemIndex >= 0) and (ItemIndex < Items.Count) then begin
          FormViewer.View (PImageInfo (Images.Items [ItemIndex])^);
          SetFocus;
       end; { if }
     end; { With }
 end; { ViewFile }

 procedure TFormMain.SetStatus (const S: string = '');
 begin
     if S = '' then begin
        Caption := AppName +
                   ' (files: ' + IntToStr (Images.Count) +
                   ', thumbnails: ' + IntToStr (Images.ThumbnailCount) + ')';
        FileListBox.Cursor := crDefault;
        Cursor := crDefault;
     end { if }
     else begin
          Caption := AppName + ' (' + S + '...)';
          FileListBox.Cursor := crHourGlass;
          Cursor := crHourGlass;
     end; { else }
     Application.ProcessMessages;
 end; { SetStatus }

 procedure TFormMain.AppActivate(Sender: TObject);
 var
     Time: TFileTime;
 begin
  { directory was changed }
    if Active and GetCatalogTime (Time) and
      (CompareFileTime (LastScan, Time) < 0)
  { autorescan }
    then Rescan;
 end; { AppActivate }

 procedure TFormMain.Rescan;
 var
     P    : PImageInfo;
     w, k : integer;
     i    : integer;
 begin
     if GetEdit (Catalog, EditPath) then begin
      { init }
        PathIndex := EditPath.Items.IndexOf (Catalog);
        Catalog := PathDelimiter (Catalog);
      { autorescan lock }
        GetCatalogTime (LastScan);
      { status }
        SetStatus ('Scanning');
      { free }
        With FileListBox do begin
             Items.BeginUpdate;
             Items.Clear;
        end; { With }
        With EditPath do begin
             Items.BeginUpdate;
             if PathIndex < 0 then PathIndex := Items.IndexOf (Catalog);
        end; { With }
        w := 0;
      { scan }
        if Images.Scan then begin
         { assign }
           for i := 0 to Pred (Images.Count) do begin
               P := Images.List[i];
               With FileListBox do begin
                    Items.Add (P^.Name);
                    k := Canvas.TextWidth (P^.Name);
               end; { Width }
               if k > w then w := k;
           end; { for }
         { add path }
           With EditPath do begin
              if PathIndex < 0 then begin
                 PathIndex := 0;
                 if Items.Count >= MaxHistory then Items.Delete (Pred (Items.Count));
                 Items.Insert (PathIndex, Catalog);
              end; { if }
           end; { With }
        end { if }
        else begin
             if PathIndex >= 0 then EditPath.Items.Delete (PathIndex);
             Catalog := '';
             PathIndex := -1;
        end; { else }
      { restore }
        SetEdit (EditPath, Catalog);
        SetBox (EditPath, PathIndex);
        EditPath.Items.EndUpdate;
        With FileListBox do begin
             SendMessage (Handle, LB_SETHORIZONTALEXTENT, w + 4, 0);
             Items.EndUpdate;
             Repaint;
        end; { With }
        SetStatus;
      { test go }
        TestGo;
     end; { if }
 end; { Rescan }

 procedure TFormMain.ButtonRunClick(Sender: TObject);
 begin
   { init }
     if FormViewer.Visible then FormViewer.Hide;
     FileListBox.Items.Clear;
     SetStatus ('Running');
   { run report }
     FormReport := TFormReport.Create (Self);
     FormReport.Width := Width - 10;
     FormReport.ShowModal;
     FormReport.Free;
   { restore }
     SetEdit (EditFirst, IntToStr (FirstNum));
     Rescan;
 end; { ButtonRunClick }

 procedure TFormMain.ButtonExitClick(Sender: TObject);
 begin
     Close;
 end; { ButtonExitClick }

(*************************************************************************)
(*                                  rename                               *)
(*************************************************************************)
 procedure TFormMain.CheckRenameClick(Sender: TObject);
 begin
     if GetCheck (fRename, CheckRename) then begin
        PanelRename.Enabled := fRename;
        LabelOrder.Enabled := fRename;
        BoxOrder.Enabled := fRename;
        CheckDecs.Enabled := fRename;
        LabelFirst.Enabled := fRename;
        EditFirst.Enabled := fRename;
        LabelDigits.Enabled := fRename;
        EditDigits.Enabled := fRename;
        LabelStep.Enabled := fRename;
        EditStep.Enabled := fRename;
        LabelPrefix.Enabled := fRename;
        EditPrefix.Enabled := fRename;
        LabelPostfix.Enabled := fRename;
        EditPostfix.Enabled := fRename;
        CheckReadOnly.Enabled := fRename;
        CheckFileTime.Enabled := fRename;
        TestGo;
     end; { if }
 end; { CheckRenameClick }

 procedure TFormMain.BoxOrderKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
     KeyBox (BoxOrder, Key);
 end; { BoxOrderKeyDown }

 procedure TFormMain.BoxOrderChange(Sender: TObject);
 begin
     GetBox (Order, BoxOrder);
 end; { BoxOrderChange }

 procedure TFormMain.CheckDecsClick(Sender: TObject);
 begin
     GetCheck (fDecs, CheckDecs);
 end; { CheckDecsClick }

 procedure TFormMain.EditPrefixChange(Sender: TObject);
 begin
     GetFileName (Prefix, EditPrefix, 0);
 end; { EditPrefixChange }

 procedure TFormMain.EditFirstChange(Sender: TObject);
 begin
     GetNumeric (EditFirst, FirstNum, MinFirst, MaxFirst, MinFirst);
 end; { EditFirstChange }

 procedure TFormMain.EditFirstExit(Sender: TObject);
 begin
     ResetNumeric (EditFirst, FirstNum);
 end; { EditFirstExit }

 procedure TFormMain.EditDigitsChange(Sender: TObject);
 begin
     GetNumeric (EditDigits, Digits, MinDigits, MaxDigits, MinDigits)
 end; { EditDigitsChange }

 procedure TFormMain.EditDigitsExit(Sender: TObject);
 begin
     ResetNumeric (EditDigits, Digits);
 end; { EditDigitsExit }

 procedure TFormMain.EditStepChange(Sender: TObject);
 begin
     GetNumeric (EditStep, StepCount, MinStep, MaxStep, MinStep);
 end; { EditStepChange }

 procedure TFormMain.EditStepExit(Sender: TObject);
 begin
     ResetNumeric (EditStep, StepCount);
 end; { EditStepExit }

 procedure TFormMain.EditPostfixChange(Sender: TObject);
 begin
     GetFileName (Postfix, EditPostfix, 0);
 end; { EditPostfixChange }

 procedure TFormMain.CheckReadOnlyClick(Sender: TObject);
 begin
     GetCheck (fAttribute, CheckReadOnly);
 end; { CheckReadOnlyClick }

 procedure TFormMain.CheckFileTimeClick(Sender: TObject);
 begin
     GetCheck (fFileTime, CheckFileTime);
 end; { CheckFileTimeClick }

(*************************************************************************)
(*                             thumbnails                                *)
(*************************************************************************)
 procedure TFormMain.CheckThumbnailsClick (Sender: TObject);
 begin
     if GetCheck (fThumbnail, CheckThumbnails) then begin
        PanelThumbnails.Enabled := fThumbnail;
        LabelMark.Enabled := fThumbnail;
        EditMark.Enabled := fThumbnail;
        UpdateQuality;
        CheckCustom.Enabled := fThumbnail;
        CheckCustomClick (Self);
        CheckInclude.Enabled := fThumbnail;
        CheckIncludeClick (Self);
        TestGo;
     end; { if }
 end; { CheckThumbnailClick }

 procedure TFormMain.EditMarkChange(Sender: TObject);
 begin
     GetFileName (Mark, EditMark, 1);
 end; { EditMarkChange }

 procedure TFormMain.EditMarkExit(Sender: TObject);
 begin
   { new value }
     if LastMark <> Mark then begin
      { new viewcount }
        Images.MarkChange;
      { confirm }
        if Confirm (IntTostr (Images.ThumbnailCount) +
           ' thumbnails with the mark "' + Mark + '"  was found',
           'Apply this value')
      { ok }
        then begin
             FileListBox.Repaint;
             LastMark := Mark;
             SetStatus;
        end { if }
      { old value }
        else begin
             Images.MarkChange;
             Mark := LastMark;
             SetEdit (EditMark, Mark);
        end; { else }
     end; { if }
   { restore }
     if EditMark.Text = '' then SetEdit (EditMark, Mark);
 end; { EditMarkExit }

 procedure TFormMain.EditMarkKeyPress(Sender: TObject; var Key: Char);
 begin
     if Key = #13 then begin
        EditMarkExit (Self);
        Key := #0;
     end { if }
     else TestFileName (Sender, Key);
 end; { EditMarkKeyPress }

 procedure TFormMain.TrackScaleChange(Sender: TObject);
 begin
     GetTrack (Scale, TrackScale);
 end; { TrackScaleChange }

 procedure TFormMain.TrackQualityChange(Sender: TObject);
 begin
     GetTrack (Quality, TrackQuality);
 end; { TrackQualityChange }

(*************************************************************************)
(*                             custom                                    *)
(*************************************************************************)
 procedure TFormMain.CheckCustomClick(Sender: TObject);
 begin
     if GetCheck (fCustom, CheckCustom) then begin
        PanelCustom.Enabled := fThumbnail and fCustom;
        LabelScale.Enabled := fThumbnail and (not fCustom);
        TrackScale.Enabled := fThumbnail and (not fCustom);
        LabelWidth.Enabled := fThumbnail and fCustom;
        EditWidth.Enabled := fThumbnail and fCustom;
        LabelHeight.Enabled := fThumbnail and fCustom;
        EditHeight.Enabled := fThumbnail and fCustom;
        RadioCut.Enabled := fThumbnail and fCustom;
        RadioFill.Enabled := fThumbnail and fCustom;
        ButtonAlign.Enabled := fThumbnail and fCustom;
        RadioModeClick (Self);
     end; { if }
 end; { CheckCustomClick }

 procedure TFormMain.EditWidthChange(Sender: TObject);
 begin
     GetNumeric (EditWidth, CtmWidth, MinWidth, MaxWidth, StdWidth);
 end; { EditWidthChange }

 procedure TFormMain.EditWidthExit(Sender: TObject);
 begin
     ResetNumeric (EditWidth, CtmWidth);
 end; { EditWidthExit }

 procedure TFormMain.EditHeightChange(Sender: TObject);
 begin
     GetNumeric (EditHeight, CtmHeight, MinHeight, MaxHeight, StdHeight);
 end; { EditHeightChange }

 procedure TFormMain.EditHeightExit(Sender: TObject);
 begin
     ResetNumeric (EditHeight, CtmHeight);
 end; { EditHeightExit }

 procedure TFormMain.RadioModeClick(Sender: TObject);
 begin
     if GetCheck (CtmMode, RadioFill)
        then ButtonColor.Enabled := fThumbnail and fCustom and CtmMode;
 end; { RadioModeClick }

 procedure TFormMain.ButtonAlignClick(Sender: TObject);
 var
     i : integer;
 begin
     FormAlign := TFormAlign.Create (Self);
     With FormAlign do begin
        TRadioButton (PanelHor.Controls [AnchorX]).Checked := true;
        TRadioButton (PanelVer.Controls [AnchorY]).Checked := true;
        if ShowModal = mrOk then begin
           for i := MinAnchor to MaxAnchor do begin
               if TRadioButton (PanelHor.Controls [i]).Checked then AnchorX := i;
               if TRadioButton (PanelVer.Controls [i]).Checked then AnchorY := i;
           end; { for }
        end; { if };
        Free;
     end; { With }
 end; { ButtonLocateClick }

 procedure TFormMain.ButtonColorClick(Sender: TObject);
 begin
     ColorDialog.Color := FillColor;
     DialogCaption := 'Color';
     if ColorDialog.Execute then FillColor := ColorDialog.Color;
 end; { ButtonColorClick }

(*************************************************************************)
(*                             include                                   *)
(*************************************************************************)
 procedure TFormMain.CheckIncludeClick(Sender: TObject);
 var
     E : boolean;
 begin
     if GetCheck (fInclude, CheckInclude) then begin
        E := fInclude and fThumbnail;
        PanelInclude.Enabled := E;
        LabelText.Enabled := E;
        EditText.Enabled := E;
        CheckImage.Enabled := E;
        CheckFile.Enabled := E;
        ButtonFont.Enabled := E;
        ButtonGround.Enabled := E;
     end; { if }
 end; { CheckIncludeClick }

 procedure TFormMain.EditTextChange(Sender: TObject);
 begin
     GetEdit (Comment, EditText);
 end; { EditTextChange }

 procedure TFormMain.CheckImageClick(Sender: TObject);
 begin
     GetCheck (fImgSize, CheckImage);
 end; { CheckImageClick }

 procedure TFormMain.CheckFileClick(Sender: TObject);
 begin
     GetCheck (fFilSize, CheckFile);
 end; { CheckFileClick }

 procedure TFormMain.ButtonFontClick(Sender: TObject);
 begin
     DialogCaption := 'Font';
     With FontDialog do if Execute then FontToParms (Font);
 end; { ButtonFontClick }

 procedure TFormMain.ButtonGroundClick(Sender: TObject);
 begin
     DialogCaption := 'BGround';
     ColorDialog.Color := BGround;
     if ColorDialog.Execute then BGround := ColorDialog.Color;
 end; { ButtonGroundClick }

 procedure TFormMain.FontDialogShow(Sender: TObject);
 begin
     UpdateDialog (FontDialog.Handle, Left + 16, Top + 25);
 end; { FontDialogShow }

 procedure TFormMain.ColorDialogShow(Sender: TObject);
 begin
     UpdateDialog (ColorDialog.Handle, Left + 10, Top + 25);
 end; { ColorDialogShow }

 End.
