(*************************************************************************)
(*                                jBooster                               *)
(*                        (c) pulsar@mail.primorye.ru                    *)
(*************************************************************************)
 Unit ViewerForm;
 {$H+,A+,B-,I-}

 Interface

 Uses
  { standart }
    Windows, SysUtils, Classes,
  { vcl }
    Graphics, StdCtrls, Controls, Forms, ExtCtrls,
  { private }
    Support;

 Type
    TFormViewer = class(TForm)
      Image: TImage;
      Memo: TMemo;
      procedure FormHide(Sender: TObject);
      procedure FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
    public
      function View (var Info: TImageInfo): boolean;
      function Help (const FileName: string): boolean;
    end; { TFormViewer }

 Var
    FormViewer: TFormViewer;

 Implementation

{$R *.DFM}

 function TFormViewer.View (var Info: TImageInfo): boolean;
 begin
   { hide memo }
     Memo.Enabled := false;
     Memo.Visible := false;
   { init }
     Image.Enabled := true;
     Image.Visible := true;
   { load }
     if LoadImage (Image.Picture.Bitmap, Info.Name) then begin
        Result := true;
      { info }
        With Image.Picture.Bitmap do begin
             Caption := AppName + ': "' + Info.Name + '" ' +
                        SizeStr (Width, Height) + ' ' +  IntToStr (Info.Size);
        end; { With }
      { show }
        if not Visible then Show;
     end { if }
     else Result := false;
 end; { View }

 function TFormViewer.Help (const FileName: string): boolean;
 begin
   { hide image }
     Image.Enabled := false;
     Image.Visible := false;
   { init }
     Memo.Enabled := true;
     Memo.Visible := true;
   { load }
     Try
        Memo.Lines.LoadFromFile (FileName);
        Caption := AppName + ': "' + FileName + '"';
        if not Visible then Show;
        Result := true;
     Except
        Result := false;
     end; { try }
 end; { Help }

 procedure TFormViewer.FormHide(Sender: TObject);
 begin
   { free }
     Image.Picture.Bitmap.FreeImage;
     Memo.Lines.Clear;
 end; { FormHide }

 procedure TFormViewer.FormKeyDown(Sender: TObject; var Key: Word; Shift: TShiftState);
 begin
     if Key = VK_ESCAPE then Close;
 end; { FormKeyDown }

End.
