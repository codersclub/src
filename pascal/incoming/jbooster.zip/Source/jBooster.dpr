(*************************************************************************)
(*                                jBooster                               *)
(*                        (c) pulsar@mail.primorye.ru                    *)
(*************************************************************************)
 Program jBooster;
 {$D '(c) pulsar@mail.primorye.ru'}
 
 Uses
    Forms,
    MainForm in 'MainForm.pas' {FormMain},
    ViewerForm in 'ViewerForm.pas' {FormViewer};

{$R *.RES}

 Begin
     Application.Initialize;
     Application.CreateForm(TFormMain, FormMain);
     Application.CreateForm(TFormViewer, FormViewer);
     Application.Run;
 End.
