object FormAlign: TFormAlign
  Left = 207
  Top = 275
  BorderIcons = [biSystemMenu]
  BorderStyle = bsDialog
  Caption = 'Align'
  ClientHeight = 116
  ClientWidth = 202
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  OnCreate = FormCreate
  PixelsPerInch = 96
  TextHeight = 13
  object PanelHor: TPanel
    Left = 12
    Top = 14
    Width = 177
    Height = 27
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 0
    object RadioLeft: TRadioButton
      Left = 7
      Top = 6
      Width = 42
      Height = 17
      TabOrder = 0
    end
    object RadioCenter: TRadioButton
      Left = 58
      Top = 6
      Width = 57
      Height = 17
      TabOrder = 1
    end
    object RadioRight: TRadioButton
      Left = 116
      Top = 6
      Width = 53
      Height = 17
      TabOrder = 2
    end
  end
  object PanelVer: TPanel
    Left = 12
    Top = 39
    Width = 177
    Height = 27
    BevelInner = bvRaised
    BevelOuter = bvLowered
    TabOrder = 1
    object RadioTop: TRadioButton
      Left = 7
      Top = 6
      Width = 42
      Height = 17
      TabOrder = 0
    end
    object RadioMiddle: TRadioButton
      Left = 58
      Top = 6
      Width = 57
      Height = 17
      TabOrder = 1
    end
    object RadioBottom: TRadioButton
      Left = 116
      Top = 6
      Width = 57
      Height = 17
      TabOrder = 2
    end
  end
  object ButtonOk: TButton
    Left = 45
    Top = 81
    Width = 69
    Height = 22
    Caption = 'Ok'
    Default = True
    ModalResult = 1
    ParentShowHint = False
    ShowHint = True
    TabOrder = 2
  end
  object ButtonCancel: TButton
    Left = 120
    Top = 81
    Width = 69
    Height = 22
    Cancel = True
    Caption = 'Cancel'
    ModalResult = 2
    ParentShowHint = False
    ShowHint = True
    TabOrder = 3
  end
end
