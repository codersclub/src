//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by mainDlg.Rc
//
#define IDCANCEL                        2
#define IDC_STC1                        1001
#define IDE_HOST                        1002
#define IDC_STC2                        1003
#define IDE_BEGIN                       1004
#define IDC_STC3                        1005
#define IDE_END                         1006
#define IDC_STC4                        1007
#define IDL_RESULTS                     1008
#define IDB_START                       1009
#define IDB_STOP                        1010
#define IDC_STC5                        1011
#define IDE_SCAN                        1012

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
