dT-eam ASM-Scan v 0.1 (Proxy not supported)
Compiler: EliAsm
Created by [dT-eam]
URL:http://cyb.h1.ru/prog.html