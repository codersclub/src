#if !defined(AFX_REGNEW_H__FEA64A95_1C18_4B85_97E5_ECA9A377E6B5__INCLUDED_)
#define AFX_REGNEW_H__FEA64A95_1C18_4B85_97E5_ECA9A377E6B5__INCLUDED_

#include "client_winDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// RegNew.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CRegNew dialog

class CRegNew : public CDialog
{
// Construction
public:
	CClient_winDlg *owner_dlg;
	CRegNew(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CRegNew)
	enum { IDD = IDD_REGNEW };
	CString	m_pass;
	CString	m_ip;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRegNew)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CRegNew)
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REGNEW_H__FEA64A95_1C18_4B85_97E5_ECA9A377E6B5__INCLUDED_)
