#include "stdafx.h"
#include "client_win.h"
#include "client_winDlg.h"
#include "login.h"

#include "misc.h"
#include "packet.h"

#include <fcntl.h>
#include <io.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClient_winDlg dialog

CClient_winDlg::CClient_winDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClient_winDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClient_winDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClient_winDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClient_winDlg)
	DDX_Control(pDX, IDC_STATUS, m_status_combo);
	DDX_Control(pDX, IDC_CONTACTS, m_contact_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClient_winDlg, CDialog)
	//{{AFX_MSG_MAP(CClient_winDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_NOTIFY(NM_DBLCLK, IDC_CONTACTS, OnDblclkContacts)
	ON_WM_CLOSE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClient_winDlg message handlers

BOOL CClient_winDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);	
	SetIcon(m_hIcon, FALSE);

    CRect rcClient;
    GetClientRect(&rcClient);
	m_contact_list.SetWindowPos(this,0,0,rcClient.Width(),rcClient.Height()-20,SWP_NOACTIVATE|SWP_NOZORDER);
    m_contact_list.SetFocus();

    m_contact_list.GetClientRect(&rcClient);
    m_contact_list.SetExtendedStyle(m_contact_list.GetExtendedStyle()|LVS_EX_FLATSB
        |LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|
        LVS_EX_UNDERLINEHOT);

    m_contact_list.InsertColumn(0, "���",LVCFMT_LEFT, 100);
    m_contact_list.InsertColumn(1, "������", LVCFMT_LEFT, 55);

	pRecvBuffer = (char *)malloc(2048);

	SetTimer(1, 500, NULL);
	num = 0;
	
	return TRUE;
}

void CClient_winDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClient_winDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CClient_winDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClient_winDlg::FillContactList(int fd)
{
	if (fd == 0)
	{
		return;
	};
	return;
}

void CClient_winDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
	if (nIDEvent == 1)
	{
		int i;
		KillTimer(1);
		CLogin dlg;
		dlg.owner_dlg = this;
		i = dlg.DoModal();
		UpdateCl();
		SetTimer(10, 500, NULL);
		SetTimer(15, 10000, NULL);
	};
	if (nIDEvent == 15)
	{
		UpdateCl();
	};
	if (nIDEvent == 10)
	{
	  char *str = (char *)malloc(255);
      if (Receive(&master, pRecvBuffer, 2048) != -1)
      {	
		  struct _packet pck;
		  memset(&pck, 0, sizeof(_packet));
		  memcpy(&pck, pRecvBuffer, sizeof(_packet));
		  if (pck.cmd == RPL_GETSTATUS)
		  {
			  int status;
			  memcpy(&status, pck.data, sizeof(status));
			  itoa(pck.from, str, 10);
			  m_contact_list.InsertItem(num, str, 0);
			  strset(str, 0);
			  if (status == STAT_ONLINE)
				  strcat(str, "online"); 
				  else strcat(str, "offline");

			  m_contact_list.SetItemText(num, 1, str);
			  num++;
		  };
		  if (pck.cmd == RPL_MSG)
		  {
			  itoa(pck.from, str, 10);
			  MessageBox((char *)&pck.data, str);
		  };
      };
	  free(str);
	};
}

void CClient_winDlg::UpdateCl()
{
	num = 0;
	struct _packet pck;
	memset(&pck, 0, sizeof(_packet));
	struct _cl_entry entry;
	fd = open("contact", O_RDWR);
	while (!eof(fd))
	{
		read(fd, &entry, sizeof(_cl_entry));
		pck.cmd = CMD_GETSTATUS;
		pck.to = entry.uid;
		pck.from = uid;
		pck.version.i_vers.v = VERSION;
		pck.version.i_vers.b = BUILD;
		SendIt(&master, (char *)&pck, sizeof(_packet));
	};
	m_contact_list.DeleteAllItems();
	return;
}

void CClient_winDlg::OnDblclkContacts(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CMsg msg;
	unsigned long uid;
	char *str = (char *)malloc(20);
	*pResult = 0;
    POSITION pos = m_contact_list.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
        while (pos)
        {
            int nItem = m_contact_list.GetNextSelectedItem(pos);
			m_contact_list.GetItemText(nItem, 0, str, 10);
			msg.uid = atoi(str);
			msg.owner = this;
			msg.DoModal();
       };
    };
	free(str);
	return;
}

void CClient_winDlg::OnClose()
{
	struct _packet pck;
	memset(&pck, 0, sizeof(_packet));
	pck.cmd = CMD_LOGOUT;
	pck.to = SERVER_UID;
	pck.from = uid;
	SendIt(&master, (char *)&pck, sizeof(_packet));
	CDialog::OnClose();
	return;
}
