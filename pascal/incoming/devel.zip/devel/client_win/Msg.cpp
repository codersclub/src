// Msg.cpp : implementation file
//

#include "stdafx.h"
#include "client_win.h"
#include "Msg.h"

#include "packet.h"
#include "misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMsg dialog


CMsg::CMsg(CWnd* pParent /*=NULL*/)
	: CDialog(CMsg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMsg)
	m_text = _T("");
	//}}AFX_DATA_INIT
}


void CMsg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMsg)
	DDX_Text(pDX, IDC_TEXT, m_text);
	DDV_MaxChars(pDX, m_text, 1020);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CMsg, CDialog)
	//{{AFX_MSG_MAP(CMsg)
	ON_BN_CLICKED(IDC_SEND, OnSend)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMsg message handlers

BOOL CMsg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	char *str = (char *)malloc(20);
	itoa(uid, str, 10);
	SetWindowText(str);
	free(str);
	return TRUE;
}

void CMsg::OnSend() 
{
	UpdateData();
	struct _packet pck;
	memset(&pck, 0, sizeof(_packet));
	pck.from = owner->uid;
	pck.to = uid;
	pck.cmd = CMD_MSG;
	pck.version.i_vers.v = VERSION;
	pck.version.i_vers.b = BUILD;
	char *str = (char *)malloc(1024);
	strset(str, 0);
	strcat(str, m_text);
	memcpy(pck.data, str, strlen(str));
//	free(str);
	SendIt(&owner->master, (char *)&pck, sizeof(_packet));
}
