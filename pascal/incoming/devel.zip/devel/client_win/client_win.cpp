#include "stdafx.h"
#include "client_win.h"
#include "client_winDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CClient_winApp

BEGIN_MESSAGE_MAP(CClient_winApp, CWinApp)
	//{{AFX_MSG_MAP(CClient_winApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClient_winApp construction

CClient_winApp::CClient_winApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CClient_winApp object

CClient_winApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CClient_winApp initialization

BOOL CClient_winApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CClient_winDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
