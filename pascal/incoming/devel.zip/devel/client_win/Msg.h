#if !defined(AFX_MSG_H__41100C89_253B_4640_8D0D_078732F21EF7__INCLUDED_)
#define AFX_MSG_H__41100C89_253B_4640_8D0D_078732F21EF7__INCLUDED_

#include "client_windlg.h"

class CClient_winDlg;

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Msg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsg dialog

class CMsg : public CDialog
{
// Construction
public:
	CClient_winDlg *owner;
	unsigned long uid;
	CMsg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMsg)
	enum { IDD = IDD_MSG };
	CString	m_text;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSend();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSG_H__41100C89_253B_4640_8D0D_078732F21EF7__INCLUDED_)
