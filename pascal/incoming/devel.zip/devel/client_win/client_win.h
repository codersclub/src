#if !defined(AFX_CLIENT_WIN_H__869C6E8C_D91F_46CC_AE30_341E49DADA1D__INCLUDED_)
#define AFX_CLIENT_WIN_H__869C6E8C_D91F_46CC_AE30_341E49DADA1D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CClient_winApp:
// See client_win.cpp for the implementation of this class
//

class CClient_winApp : public CWinApp
{
public:
	CClient_winApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClient_winApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CClient_winApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENT_WIN_H__869C6E8C_D91F_46CC_AE30_341E49DADA1D__INCLUDED_)
