// RegNew.cpp : implementation file
//

#include "stdafx.h"
#include "client_win.h"
#include "RegNew.h"

#include "packet.h"
#include "misc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRegNew dialog


CRegNew::CRegNew(CWnd* pParent /*=NULL*/)
	: CDialog(CRegNew::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRegNew)
	m_pass = _T("");
	m_ip = _T("");
	//}}AFX_DATA_INIT
}


void CRegNew::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRegNew)
	DDX_Text(pDX, IDC_PASS, m_pass);
	DDV_MaxChars(pDX, m_pass, 10);
	DDX_Text(pDX, IDC_IP, m_ip);
	DDV_MaxChars(pDX, m_ip, 16);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CRegNew, CDialog)
	//{{AFX_MSG_MAP(CRegNew)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRegNew message handlers

void CRegNew::OnOK() 
{
//	CDialog::OnOK();
	UpdateData();
	WSAData wsa;
	WSAStartup(0x0101, &wsa);
	Reset(&owner_dlg->master);
	Open(&owner_dlg->master, inet_addr(m_ip), true);
/*
	sockaddr_in sname;
	sname.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	sname.sin_family = AF_INET;
	sname.sin_port = htons(m_uid);
*/
	struct _packet pck;
	memset(&pck, 0, sizeof(_packet));
	pck.version.i_vers.v = VERSION;
	pck.version.i_vers.b = BUILD;
	pck.from = 0;
	pck.to = SERVER_UID;
	pck.cmd = CMD_REGISTER;
	memcpy(pck.data, m_pass.GetBuffer(1), m_pass.GetLength());
	SendIt(&owner_dlg->master, (char *)&pck, sizeof(_packet));
	while (true)
	{
		memset(&pck, 0, sizeof(_packet));
		if (Receive(&owner_dlg->master, (char *)&pck, sizeof(_packet)) != -1)
		{
			if (pck.cmd == RPL_REGISTER)
			{
				char *_uid = (char *)malloc(15);
				itoa(pck.to, _uid, 10);
				MessageBox(_uid, "New UID registered");
				break;
			};
		};
		Sleep(100);
	};
	return;
}
