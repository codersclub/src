#include "stdafx.h"
#include "client_win.h"
#include "Login.h"
#include "RegNew.h"

#include "misc.h"
#include "packet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CLogin dialog


CLogin::CLogin(CWnd* pParent /*=NULL*/)
	: CDialog(CLogin::IDD, pParent)
{
	//{{AFX_DATA_INIT(CLogin)
	m_pass = _T("");
	m_uid = 0;
	m_ip = _T("");
	//}}AFX_DATA_INIT
}


void CLogin::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CLogin)
	DDX_Text(pDX, IDC_PASSWORD, m_pass);
	DDV_MaxChars(pDX, m_pass, 10);
	DDX_Text(pDX, IDC_UID, m_uid);
	DDV_MinMaxUInt(pDX, m_uid, 100000, 999999);
	DDX_Text(pDX, IDC_IP, m_ip);
	DDV_MaxChars(pDX, m_ip, 16);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CLogin, CDialog)
	//{{AFX_MSG_MAP(CLogin)
	ON_BN_CLICKED(IDOK, OnLogin)
	ON_BN_CLICKED(IDC_NEW, OnNew)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CLogin message handlers

void CLogin::OnLogin()
{
	UpdateData();
	WSAData wsa;
	WSAStartup(0x0101, &wsa);
	Reset(&owner_dlg->master);
	Open(&owner_dlg->master, inet_addr(m_ip), true);
/*
	sockaddr_in sname;
	sname.sin_addr.S_un.S_addr = inet_addr("127.0.0.1");
	sname.sin_family = AF_INET;
	sname.sin_port = htons(m_uid);
*/
	struct _packet pck;
	struct _login log;
	memset(&pck, 0, sizeof(_packet));
	memset(&log, 0, sizeof(_login));
	pck.version.i_vers.v = VERSION;
	pck.version.i_vers.b = BUILD;
	pck.from = m_uid;
	pck.to = SERVER_UID;
	pck.cmd = CMD_LOGIN;
	strcat((char *)log.login, "chp0.1");
	strcat((char *)log.password, m_pass);
	memcpy(pck.data, &log, sizeof(_login));
	SendIt(&owner_dlg->master, (char *)&pck, sizeof(_packet));
	while (true)
	{
		memset(&pck, 0, sizeof(_packet));
		if (Receive(&owner_dlg->master, (char *)&pck, sizeof(_packet)) != -1)
		{
			if (pck.cmd == RPL_LOGIN)
			{
				memset(&log, 0, sizeof(_login));
				memcpy(&log, pck.data, sizeof(_login));
				if (log.ok)
				{
					owner_dlg->uid = pck.to;
					char *str = (char *)malloc(10);
					itoa(pck.to, str, 10);
					owner_dlg->SetWindowText(str);
					MessageBox((char *)log.reason, "Success");
				} else MessageBox((char *)log.reason, "Failed");
				break;
			};
		};
		Sleep(100);
	};
	return;
};

BOOL CLogin::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_ip = SERVER_ADDR;
	UpdateData(FALSE);
	return TRUE;
}

void CLogin::OnNew() 
{
	CRegNew rn;
	rn.owner_dlg = owner_dlg;
	rn.DoModal();
}
