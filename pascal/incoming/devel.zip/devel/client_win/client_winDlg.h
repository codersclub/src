#if !defined(AFX_CLIENT_WINDLG_H__D2121EE4_8DD6_40F9_815D_65A7256618A9__INCLUDED_)
#define AFX_CLIENT_WINDLG_H__D2121EE4_8DD6_40F9_815D_65A7256618A9__INCLUDED_

#include "Msg.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClient_winDlg dialog

struct _master
{
  int masterSocket;
  sockaddr_in masterSockAddr;
  sockaddr_in rcvSockAddr;
  char *serverName;
};

class CClient_winDlg : public CDialog
{
// Construction
public:
	int num;
	unsigned long uid;
	void UpdateCl();
	char *pRecvBuffer;
	struct _master master;
	int fd;
	void FillContactList(int fd);
	CClient_winDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClient_winDlg)
	enum { IDD = IDD_CLIENT_WIN_DIALOG };
	CComboBox	m_status_combo;
	CListCtrl	m_contact_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClient_winDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CClient_winDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnDblclkContacts(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnClose();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENT_WINDLG_H__D2121EE4_8DD6_40F9_815D_65A7256618A9__INCLUDED_)
