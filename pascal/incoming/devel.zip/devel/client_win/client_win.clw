; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CRegNew
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "client_win.h"
LastPage=0

ClassCount=6
Class1=CClient_winApp
Class2=CAboutDlg
Class3=CClient_winDlg
Class4=CLogin
Class5=CMsg

ResourceCount=5
Resource1=IDD_MSG
Resource2=IDD_CLIENT_WIN_DIALOG (English (U.S.))
Resource3=IDD_ABOUTBOX (English (U.S.))
Resource4=IDD_LOGIN
Class6=CRegNew
Resource5=IDD_REGNEW

[CLS:CClient_winApp]
Type=0
BaseClass=CWinApp
HeaderFile=client_win.h
ImplementationFile=client_win.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=client_winDlg.cpp
ImplementationFile=client_winDlg.cpp
LastObject=CAboutDlg

[CLS:CClient_winDlg]
Type=0
BaseClass=CDialog
HeaderFile=client_winDlg.h
ImplementationFile=client_winDlg.cpp
Filter=D
VirtualFilter=dWC

[CLS:CLogin]
Type=0
BaseClass=CDialog
HeaderFile=Login.h
ImplementationFile=Login.cpp
Filter=D
VirtualFilter=dWC
LastObject=CLogin

[CLS:CMsg]
Type=0
BaseClass=CDialog
HeaderFile=Msg.h
ImplementationFile=Msg.cpp

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_CLIENT_WIN_DIALOG]
Type=1
Class=CClient_winDlg

[DLG:IDD_LOGIN]
Type=1
Class=CLogin
ControlCount=5
Control1=IDOK,button,1342242817
Control2=IDC_UID,edit,1350639744
Control3=IDC_PASSWORD,edit,1350631584
Control4=IDC_IP,edit,1350631552
Control5=IDC_NEW,button,1342242816

[DLG:IDD_MSG]
Type=1
Class=CMsg
ControlCount=2
Control1=IDC_SEND,button,1342242816
Control2=IDC_TEXT,edit,1350631492

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_CLIENT_WIN_DIALOG (English (U.S.))]
Type=1
Class=?
ControlCount=2
Control1=IDC_STATUS,combobox,1344340227
Control2=IDC_CONTACTS,SysListView32,1350631425

[DLG:IDD_REGNEW]
Type=1
Class=CRegNew
ControlCount=6
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_PASS,edit,1350631552
Control4=IDC_IP,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352

[CLS:CRegNew]
Type=0
HeaderFile=RegNew.h
ImplementationFile=RegNew.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_IP

