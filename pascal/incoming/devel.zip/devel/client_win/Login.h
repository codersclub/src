#if !defined(AFX_LOGIN_H__12D4692B_5A6E_493E_9903_7A366B99153D__INCLUDED_)
#define AFX_LOGIN_H__12D4692B_5A6E_493E_9903_7A366B99153D__INCLUDED_

#include "client_winDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Login.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CLogin dialog

class CLogin : public CDialog
{
// Construction
public:
	CClient_winDlg *owner_dlg;
	CLogin(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CLogin)
	enum { IDD = IDD_LOGIN };
	CString	m_pass;
	UINT	m_uid;
	CString	m_ip;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLogin)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CLogin)
	afx_msg void OnLogin();
	virtual BOOL OnInitDialog();
	afx_msg void OnNew();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#endif // !defined(AFX_LOGIN_H__12D4692B_5A6E_493E_9903_7A366B99153D__INCLUDED_)
