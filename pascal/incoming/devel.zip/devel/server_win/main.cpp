#include "misc.h"
#include "packet.h"

#include <sys/types.h>
#include <io.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>
#include <winsock.h>

FILE *fp_log;
int db;
struct _user users[MAX_ONLINE_USERS];

struct DB_ENTRY
{
	unsigned long uid;
	char name[25];
	char passwd[10];
	char info[128];
};

struct DB_MSG
{
	unsigned long to;
	unsigned long from;
	char msg[255];
};

void reset_users();
int add_user(struct _packet *pck, sockaddr_in ip);
int find_user(unsigned long handle, sockaddr_in rcvSockAddr);
int del_user(unsigned long handle);
bool user_exists(unsigned long uid);
int get_user_status(unsigned long uid);
int set_user_status(unsigned long uid, int status);
bool set_user_info(unsigned long uid, struct _user_info ui);
struct _user_info get_user_info(unsigned long uid);

bool init();
int process_message(struct _master *master, char *msg);
void reset_pck(struct _packet *pck);
void stupid_shit(struct _master *master);
int server_status();
int user_num();
bool check_passwd(unsigned long uid, char passwd[10], char *info);

unsigned long register_user(char pass[10]);
bool add_to_q(unsigned long uid, char *msg);

unsigned long register_user(char pass[10])
{
	unsigned long uid = 0;
	int ret;
	if (db == 0)
 		return uid;
	DB_ENTRY entry;
	lseek(db, 0, 0);
	while (!eof(db))
	{
		ret = read(db, &entry, sizeof(DB_ENTRY));
	};
	uid = entry.uid + 1;
	memset(&entry, 0, sizeof(DB_ENTRY));
	strcat((char *)entry.passwd, (char *)pass);
	entry.uid = uid;
	write(db, &entry, sizeof(DB_ENTRY));
	return uid;
};

bool add_to_q(unsigned long from, unsigned long to, char *msg)
{
	bool ret = false;
	int q = open("messages", O_RDWR | O_BINARY);
	if (q == 0)
		return ret;
	DB_MSG db_msg;
	memset(&db_msg, 0, sizeof(DB_MSG));
	db_msg.from = from;
	db_msg.to = to;
	memcpy(db_msg.msg, msg, 255);
	write(q, &db_msg, sizeof(DB_MSG));
	close(q);
	return ret;
};


void reset_users()
{
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in reset_users()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  for (int i=0; i<MAX_ONLINE_USERS; i++)
  {
    users[i].uid = 0;
    memset(&users[i].login, 0, strlen(users[i].login));
    memset(&users[i].him, 0, sizeof(struct sockaddr_in));
    closesocket(users[i].sock);
    users[i].sock = INVALID_SOCKET;
  };
  return;
};

int add_user(struct _packet *pck, sockaddr_in ip)
{
  int index = -1;
  int i;

  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in add_user()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  for (i=0; i<MAX_ONLINE_USERS; i++)
  {
    if (users[i].uid == 0)
    {
      struct _login *log;
      log = (struct _login *)pck->data;
      index = i;
      users[i].uid = pck->from;
      memset((char *)&users[i].login, 0, 10);
      memcpy(&users[i].login, &log->login, 10);
      users[i].him = ip;
      users[i].sock = INVALID_SOCKET;
      break;
    };
  };
  return index;
};

int find_user(unsigned long handle, sockaddr_in rcvSockAddr)
{
  int index = -1;
  int i;

  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in find_user()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  for (i=0; i<MAX_ONLINE_USERS; i++)
  {
//    if ((users[i].uid == handle)&&(users[i].him.sin_addr.s_addr == rcvSockAddr.sin_addr.s_addr))
    if ((users[i].uid == handle))
    {
      index = i;
      break;
    };
  };
  return index;
};

int del_user(unsigned long handle)
{
  int index = -1;
  int i;

  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in del_user()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  for (i=0; i<MAX_ONLINE_USERS; i++)
  {
    if (users[i].uid == handle)
    {
      users[i].uid = 0;
      memset(&users[i].him, 0, sizeof(struct sockaddr_in));
      memset(&users[i].login, 0, strlen(users[i].login));
      users[i].sock = INVALID_SOCKET;
	  index = 1;
    };
  };
  return index;
};

bool user_exists(unsigned long uid)
{
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in user_exists()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  if (db == 0)
 	return false;
  DB_ENTRY entry;
  lseek(db, 0, 0);
  while (!eof(db))
  {
	read(db, &entry, sizeof(DB_ENTRY));
	if (entry.uid == uid)
		return true;
  };
  return false;
};

int get_user_status(unsigned long uid)
{
  int i;
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in get_user_status()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  if (user_exists(uid))
  {
	for (i=0; i<MAX_ONLINE_USERS; i++)
	{
		if (users[i].uid == uid)
		{
			return STAT_ONLINE;
		};
	};
	return STAT_OFFLINE;
  };
  return -1;
};

int set_user_status(unsigned long uid, int status)
{
  int i;
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in set_user_status()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  if (user_exists(uid))
  {
	for (i=0; i<MAX_ONLINE_USERS; i++)
	{
		if (users[i].uid == uid)
		{
			users[i].status = status;
			return 0;
		};
	};
  };
  return -1;
};

bool set_user_info(unsigned long uid, struct _user_info ui)
{
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in set_user_info()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  if (db == 0)
 	return false;
  DB_ENTRY entry;
  lseek(db, 0, 0);
  while (!eof(db))
  {
	read(db, &entry, sizeof(DB_ENTRY));
	if (entry.uid == uid)
	{
		lseek(db, tell(db) - sizeof(DB_ENTRY), 0);
		entry.uid = uid;
		memcpy(&entry.name, &ui.name, 25);
		memcpy(&entry.info, &ui.info, 128);
		write(db, &entry, sizeof(DB_ENTRY));
	};
  };
  return false;
};

struct _user_info get_user_info(unsigned long uid)
{
  struct _user_info ui;
  memset(&ui, 0, sizeof(struct _user_info));
  if (DEBUG)
  { // debug info
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    fprintf(fp_log, "[%i:%i:%i] "SERVER_NAME" - in get_user_info()\r\n", ptr->tm_hour, ptr->tm_min, ptr->tm_sec);
    fflush(fp_log);
  };

  if (db == 0)
	  return ui;

  DB_ENTRY entry;
  lseek(db, 0, 0);
  while (!eof(db))
  {
	read(db, &entry, sizeof(DB_ENTRY));
	if (entry.uid == uid)
	{
		lseek(db, tell(db) - sizeof(DB_ENTRY), 0);
		entry.uid = uid;
		memcpy(&ui.name, &entry.name, 25);
		memcpy(&ui.info, &entry.info, 128);
	};
  };
  return ui;
};



bool init()
{
  WSADATA wsa;
  if (WSAStartup(0x0101, &wsa) == -1)
  {
	  return false;
  };
  db = open("uids.chp", O_RDWR | O_BINARY);
  if (db == -1)
  {
	  return false;
  };
  if (sizeof(_packet) != PACKET_SIZE) // ;)
  {
    struct _packet packet;
    printf("fatal error: very strange packet size - %d\r\n", sizeof(packet));
    printf("** generating packet.bug...\r\n");
    printf("** send this shit to deil@nwgsm.ru\r\n");
    fp_log = fopen("packet.bug", "w+");
    if (fp_log != NULL)
    {
      fprintf(fp_log, "protocol version - %d.%d\r\n", VERSION, BUILD);
      fprintf(fp_log, "packet size - %d\r\n", sizeof(packet));
      fprintf(fp_log, "packet.cmd - %d\r\n", sizeof(packet.cmd));
      fprintf(fp_log, "packet.data - %d\r\n", sizeof(packet.data));
      fprintf(fp_log, "packet.from - %d\r\n", sizeof(packet.from));
      fprintf(fp_log, "packet.to - %d\r\n", sizeof(packet.to));
      fclose(fp_log);
    } else
      printf("what the hell is going on? I CAN'T CREATE A FILE! !@#@$ :(\r\n");
    return false;
  };

  struct tm *ptr;
  time_t lt;
  lt = time(NULL);
  ptr = localtime(&lt);
//  fp_log = fopen("icmp.log", "w+");
//  if (fp_log == NULL) { fp_log = stdout; };
  fp_log = stdout;
  if (DEBUG)
  {
    fprintf(fp_log, "\r\n(!) %s - Starting "SERVER_NAME" v "MY_VERSION" ...", asctime(ptr));
    fprintf(fp_log, "ok");
    fprintf(fp_log, "\r\n - server info ----");
    fprintf(fp_log, "\r\n ** supported protocol : %i.%i", VERSION, BUILD);
    fprintf(fp_log, "\r\n ** packet size        : %i bytes", sizeof(struct _packet));
    fprintf(fp_log, "\r\n ** server name        : %s", SERVER_NAME);
    fprintf(fp_log, "\r\n ** server admin       : %s", SERVER_ADMIN);
    fprintf(fp_log, "\r\n ** server admin e-mail: %s", SERVER_ADMIN_EMAIL);
    fprintf(fp_log, "\r\n ------------------\r\n");
    fflush(fp_log);
  };
  return true;
};

int process_message(struct _master *master, char *msg)
{
  struct _packet *pck = (struct _packet *)msg;
  struct _packet p_reply;
  struct _master i_reply;
  struct tm *ptr;
  struct _user_info ui;
  int i;
  time_t lt;
  lt = time(NULL);
  ptr = localtime(&lt);
  reset_pck(&p_reply);
  Reset(&i_reply);
  stupid_shit(&i_reply);

  Open(&i_reply, master->rcvSockAddr.sin_addr.s_addr, false);
  i_reply.masterSockAddr = master->rcvSockAddr;
  i_reply.masterSocket = master->masterSocket;

  if (DEBUG)
  {
	fprintf(fp_log, "[++] packet received from %u, cmd %d\r\n", pck->from, pck->cmd);
	fflush(fp_log);
  };

  if ((pck->version.i_vers.b != BUILD)||(pck->version.i_vers.v != VERSION))
  {
	fprintf(fp_log, "[++] incorrect version %d.%d! \r\n", pck->version.i_vers.v, pck->version.i_vers.b);
	fflush(fp_log);
	return 0;
  };

  p_reply.version.i_vers.v = VERSION;
  p_reply.version.i_vers.b = BUILD;
  p_reply.from = SERVER_UID;

  if (pck->cmd == CMD_INFO)
  {
    struct _info info;
    p_reply.cmd = RPL_INFO;
    memset((char *)&info, 0, sizeof(struct _info));
    strcat((char *)&info.motd,"Welcome :)");
    info.status = server_status();
    strcat((char *)&info.server_admin, SERVER_ADMIN);
    strcat((char *)&info.server_name, SERVER_NAME);
    strcat((char *)&info.server_adm_mail, SERVER_ADMIN_EMAIL);
    info.users_max = MAX_ONLINE_USERS;
    info.users_num = user_num();
    memset(p_reply.data, 0, 1024);
    memcpy(p_reply.data, &info, sizeof(struct _info));
    if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
    {
      fprintf(fp_log, "(!) send error : %i\r\n", 0);
      fflush(fp_log);
    };
    return 0;
  };

  if (pck->cmd == CMD_LOGIN)
  {
    struct _login *log;
    struct _login r_log;
	char *info = (char *)malloc(255);
	memset(info, 0, 255);
    int handle, pos;
    log = (struct _login *)pck->data;
    r_log = *log;
    if (check_passwd(pck->from, log->password, info))
    {
      pos = add_user(pck, master->rcvSockAddr);
      if (pos == -1)
      {
        fprintf(fp_log, "(!) add_user failed\r\n");
        fflush(fp_log);
        r_log.ok = 0;
        memset((char *)r_log.reason, 0, 100);
        memset((char *)r_log.login, 0, 10);
        memset((char *)r_log.password, 0, 10);
        strcat((char *)r_log.reason, ""SERVER_NAME": add_user() failed. contact "SERVER_ADMIN"; e-mail:"SERVER_ADMIN_EMAIL"");
        p_reply.cmd = RPL_LOGIN;
        memcpy(p_reply.data, &r_log, sizeof(struct _login));
        if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
        {
          fprintf(fp_log, "(!) send error : %i\r\n", 0);
          fflush(fp_log);
        };
        return 0;
      };
      r_log.ok = 1;
      handle = users[pos].uid;
      memset((char *)r_log.reason, 0, 100);
      memset((char *)r_log.login, 0, 10);
      memset((char *)r_log.password, 0, 10);
      strcat((char *)r_log.reason, info);
	  p_reply.to = handle;
      p_reply.cmd = RPL_LOGIN;
      memset(p_reply.data, 0, 1024);
      memcpy(p_reply.data, &r_log, sizeof(struct _login));
      if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
      {
        fprintf(fp_log, "(!) send error : %i\r\n", 0);
        fflush(fp_log);
      };
	  return 0;
    } else
    {
	  if (DEBUG)
	  {
		fprintf(fp_log, "(!) error logging user %u (%s): %s\r\n", pck->from, log->password, info);
		fflush(fp_log);
	  };
      r_log.ok = 0;
      memset((char *)r_log.reason, 0, 100);
      memset((char *)r_log.login, 0, 10);
      memset((char *)r_log.password, 0, 10);
      strcat((char *)r_log.reason, info);
      p_reply.cmd = RPL_LOGIN;
      memset(p_reply.data, 0, 1024);
      memcpy(p_reply.data, &r_log, sizeof(struct _login));
      if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
      {
        fprintf(fp_log, "(!) send error : %i\r\n", 0);
        fflush(fp_log);
      };
      return 0;
    };
  };

  if (pck->cmd == CMD_REGISTER)
  {
	  char pass[10];
	  memset(pass, 0, 10);
	  memcpy(pass, pck->data, 10);
	  p_reply.to = register_user(pass);
	  p_reply.cmd = RPL_REGISTER;
	  fprintf(fp_log, "(!) registering new user: %u\r\n", p_reply.to);
      fflush(fp_log);
      if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
      {
		  fprintf(fp_log, "(!) send error : %i\r\n", 0);
          fflush(fp_log);
	  };
  };

  if (pck->cmd > 100)
  {
    return -1;
  } else
  {
    if (find_user(pck->from, master->rcvSockAddr) != -1)
    {
      int user = find_user(pck->from, master->rcvSockAddr);
      switch (pck->cmd)
      {
		case CMD_LOGOUT:
			if (del_user(pck->from))
			{
				p_reply.cmd = RPL_LOGOUT;
				memset(p_reply.data, 0, 1024);
				if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
				{
					fprintf(fp_log, "(!) send error : %i\r\n", 0);
					fflush(fp_log);
				};
			};
			return 0;
			break;

		case CMD_GETSTATUS:
			i = get_user_status(pck->to);
			p_reply.from = pck->to;
			p_reply.cmd = RPL_GETSTATUS;
			p_reply.to = pck->from;
			memset(p_reply.data, 0, 1024);
			memcpy(p_reply.data, &i, sizeof(i));
			if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
			{
				fprintf(fp_log, "(!) send error : %i\r\n", 0);
				fflush(fp_log);
			};
			return 0;
			break;

		case CMD_GETADDR:
			for (i=0; i<user_num(); i++)
			{
				if (users[i].uid == pck->to)
				{
					p_reply.from = pck->to;
					p_reply.cmd = RPL_GETADDR;
					p_reply.to = pck->from;
					memset(p_reply.data, 0, 1024);
					memcpy(p_reply.data, &users[i].him, sizeof(users[i].him));
					if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
					{
						fprintf(fp_log, "(!) send error : %i\r\n", 0);
						fflush(fp_log);
					};
					return 0;
				};
			};
			return 0;
			break;

		case CMD_STATUS:
			int status;
			memcpy(&status, pck->data, sizeof(status));
			set_user_status(pck->from, status);
			return 0;
			break;

		case CMD_MSG:
			if (get_user_status(pck->to) == STAT_ONLINE)
			{
				p_reply.version.i_vers.v = VERSION;
				p_reply.version.i_vers.b = BUILD;
				p_reply.from = pck->from ;
				p_reply.cmd = RPL_MSG;
				p_reply.to = pck->to;
				memset(p_reply.data, 0, 1024);
				memcpy(p_reply.data, pck->data, 1024);
				i_reply.masterSockAddr = users[find_user(pck->to, i_reply.masterSockAddr)].him; // �� �����, ��� �������� :)
				if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
				{
					fprintf(fp_log, "(!) send error : %i\r\n", 0);
					fflush(fp_log);
				};
				return 0;
			};
			p_reply.to = pck->from;
			p_reply.cmd = RPL_MSG;
			memset(p_reply.data, 0, 1024);
			strcat((char *)p_reply.data, "User does not exists or is offline : mne vloooom delat' o4ered' soobseniy! :]");
			if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
			{
				fprintf(fp_log, "(!) send error : %i\r\n", 0);
				fflush(fp_log);
			};
			return 0;
			break;

		case CMD_SETINFO:
			memcpy(&ui, pck->data, sizeof(_user_info));
			set_user_info(pck->from, ui);
			p_reply.to = pck->from;
			p_reply.cmd = RPL_SETINFO;
			memset(p_reply.data, 0, 1024);
			if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
			{
				fprintf(fp_log, "(!) send error : %i\r\n", 0);
				fflush(fp_log);
			};
			return 0;
			break;

		case CMD_GETINFO:
			ui = get_user_info(pck->to);
			memcpy(pck->data, &ui, sizeof(_user_info));
			p_reply.to = pck->from;
			p_reply.cmd = RPL_GETINFO;
			memset(p_reply.data, 0, 1024);
			if (SendIt(&i_reply, (char *)&p_reply, sizeof(struct _packet)) == -1)
			{
				fprintf(fp_log, "(!) send error : %i\r\n", 0);
				fflush(fp_log);
			};
			return 0;
			break;

        default:
			fprintf(fp_log, "\(?) unknown command\r\n");
            fflush(fp_log);
            break;
      };
    };
  };
  return 0;
};

void reset_pck(struct _packet *pck)
{
  memset(pck, 0, sizeof(struct _packet));
  return;
};

void stupid_shit(struct _master *master)
{
  strcat(master->serverName, SERVER_NAME);
};

int server_status() //**re do**//
{
  return 1;
};

int user_num()
{
  int i, index = 0;
  for (i=0;i<MAX_ONLINE_USERS;i++)
  {
    if (users[i].uid != 0)
    index ++;
  };
  return index;
};

bool check_passwd(unsigned long uid, char passwd[10], char *info)
{
	strset(info, 0);
	strcat(info, "check_passwd finished, nothing happened: bug!");
	if (db == -1)
		return false;
	DB_ENTRY entry;
	lseek(db, 0, 0);
	while (!eof(db))
	{
		read(db, &entry, sizeof(DB_ENTRY));
		if (entry.uid == uid)
		{
			if (!strcmp(entry.passwd, passwd))
			{
				strset(info, 0);
				strcat(info, "��� ��� ����-������, ��������� ��� ���� �����!");
				return true;
			} else
			{
				strset(info, 0);
				strcat(info, "Incorrect Password");
				return false;
			};
		};
	};
	return false;
};

int main(int argc, char* argv[])
{
  struct _master master;
  struct _packet pck;
  struct timeval time_val;
  fd_set read_fds;
  char *pSendBuffer = (char *)&pck;
  char *pRecvBuffer = (char *)malloc(2048);

  printf("(**) initializing...\r\n");
  if (!init())
  {
    printf("(--) init() failed. exiting...\r\n");
    return -1;
  };
  if (DEBUG) fprintf(fp_log, "(**) final initialization\r\n");
  Reset(&master);
  reset_users();
  stupid_shit(&master);
  Open(&master, inet_addr("127.0.0.1"), true);
  bind(master.masterSocket, (sockaddr *)&master.masterSockAddr, sizeof(master.masterSockAddr));
//  listen(master.masterSocket, MAX_ONLINE_USERS);
  reset_pck(&pck);
/*
  pck.version.i_vers.v = VERSION;
  pck.version.i_vers.b = BUILD;
  pck.from = SERVER_UID;
  pck.to = SERVER_UID;
  pck.cmd = CMD_INFO;
  strcat((char *)&pck.data, "smile");
  SendIt(&master, pSendBuffer, sizeof(struct _packet));
*/
  memset(pSendBuffer, 0, sizeof(struct _packet));

  while (true)
  {
    time_val.tv_sec = 0;
    time_val.tv_usec= 100000; 
    FD_ZERO(&read_fds); 
    FD_SET(master.masterSocket, &read_fds); 
    select(master.masterSocket, &read_fds, NULL, NULL, &time_val); 
    if (FD_ISSET(master.masterSocket, &read_fds)) 
    { 
      if (Receive(&master, pRecvBuffer, 2048) != -1)
      {	
        char *output = pRecvBuffer;
        process_message(&master, output);
        reset_pck(&pck);
      };
    };
  };

  fprintf(fp_log, "(--) "SERVER_NAME" is stopped\r\n");
  fflush(fp_log);
  fclose(fp_log);
  return EXIT_SUCCESS;
}

