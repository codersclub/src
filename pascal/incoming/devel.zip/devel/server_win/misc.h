#include <sys/types.h>
#include <fcntl.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <errno.h>
#include <winsock.h>

#define SERVER_PORT 4350
#define INVALID_SOCKET -1

union _ip
{
  unsigned char c_ip[4];
  unsigned long u_ip;
};

struct _master
{
  int masterSocket;
  sockaddr_in masterSockAddr;
  sockaddr_in rcvSockAddr;
  char *serverName;
};

int unblock_socket(int sd)
{
  unsigned long argp;
  argp = sd;
  ioctlsocket(sd, FIONBIO, &argp);
  return 1;
};

void Reset(struct _master *master);
bool OpenNewSocket(struct _master *master, int AFamily, int AType, int AProtocol);
bool Connect(struct _master *master, int ReceiveTimeout, int SendTimeout);
bool Connect(struct _master *master, int *ReceiveTimeout, int *SendTimeout, int AFamily, int AType, int AProtocol);
int Open(struct _master *master, unsigned long ip, bool CreateNew);
int Receive(struct _master *master, char *pSendBuffer, int BufferSize);
int SendIt(struct _master *master, char *pSendBuffer, int DataLen);
int CloseMasterSocket(struct _master *master);

void Reset(struct _master *master)
{
  master->serverName = (char *)malloc(255);
  memset(master->serverName, 0, 255);
  master->masterSocket = INVALID_SOCKET;
  master->masterSockAddr.sin_family = 0;
  master->masterSockAddr.sin_port = 0;
  master->masterSockAddr.sin_addr.s_addr = 0;
  master->rcvSockAddr.sin_family = 0;
  master->rcvSockAddr.sin_port = 0;
  master->rcvSockAddr.sin_addr.s_addr = 0;
  return;
}

int Open(struct _master *master, unsigned long ip, bool CreateNew)
{
  master->masterSockAddr.sin_family = AF_INET;
//  master->masterSockAddr.sin_addr.S_un.S_addr = ip; // for client
  master->masterSockAddr.sin_addr.S_un.S_addr = INADDR_ANY;
  master->masterSockAddr.sin_port = htons(SERVER_PORT);
  if (CreateNew) if (OpenNewSocket(master, AF_INET, SOCK_DGRAM, IPPROTO_UDP)) { return 0; } else { return -1; };
  return 0;
};

bool OpenNewSocket(struct _master *master, int AFamily, int AType, int AProtocol)
{
  if (master->masterSocket != -1)
  CloseMasterSocket(master);
  if (!Connect(master, NULL, NULL, AFamily, AType, AProtocol))
     return false;
  return true;
}

bool Connect(struct _master *master, int ReceiveTimeout, int SendTimeout)
{
  return Connect(master, &ReceiveTimeout, &SendTimeout, AF_INET, SOCK_DGRAM, IPPROTO_UDP);
}

bool Connect(struct _master *master, int *ReceiveTimeout, int *SendTimeout, int AFamily, int AType, int AProtocol)
{
  master->masterSocket = INVALID_SOCKET;
  master->masterSocket = socket(AFamily, AType, AProtocol);
  if (master->masterSocket == -1)
  {
    perror("\r(?) cannot create udp socket :");
    return false;
  };
  unblock_socket(master->masterSocket);
  return true;
}

int CloseMasterSocket(struct _master *master)
{
  if (master->masterSocket == INVALID_SOCKET)
     return 0;
  int Result = closesocket(master->masterSocket);
  if (Result == -1)
  {
    master->masterSocket = INVALID_SOCKET;
  }
  return Result;
}

int SendIt(struct _master *master, char *pSendBuffer, int DataLen)
{
  int Result;
  char *pSendBuf = (char *)malloc(DataLen);
  memset(pSendBuf, 0, DataLen);
  memcpy(pSendBuf, pSendBuffer, DataLen);
  Result = sendto(master->masterSocket, pSendBuf, DataLen, 0, (struct sockaddr *)&master->masterSockAddr, sizeof(master->masterSockAddr));
  return Result;
}

int Receive(struct _master *master, char *pSendBuffer, int BufferSize)
{
  struct sockaddr *pRcvSockAddr = (struct sockaddr *)&master->rcvSockAddr;
  int Result;
  master->rcvSockAddr.sin_family = AF_INET;
  master->rcvSockAddr.sin_addr.S_un.S_addr = INADDR_ANY;
  master->rcvSockAddr.sin_port = 0;
  int RcvIpHdrLen = sizeof(master->rcvSockAddr);
  Result = recvfrom(master->masterSocket, pSendBuffer, BufferSize, 0, pRcvSockAddr, (int *)&RcvIpHdrLen);
/*
  if (Result == -1)
  {
//    if (errno == 11) return -1; // for *nix
    return Result;
  };
*/
  return Result;
}
