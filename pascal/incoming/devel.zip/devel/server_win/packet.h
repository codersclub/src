#define DEBUG true
#define PACKET_SIZE sizeof(_packet)

#define VERSION 1
#define BUILD 0

#define MAX_ONLINE_USERS 125
#define INVALID_SOCKET -1

#define SERVER_UID 0

#define SERVER_NAME "dark machine"
#define SERVER_ADMIN "deil"
#define SERVER_ADMIN_EMAIL "deil@nwgsm.ru"
#define SERVER_MOTD "it's not stable release coz it's author is lamer: send info about all bugs to deil@nwgsm.ru :]"

#define MY_VERSION "0.1.0"

#define CMD_INFO 0 // +
#define CMD_LOGIN 1 // +
#define CMD_STATUS 2 // +
#define CMD_REGISTER 3 // +
#define CMD_GETSTATUS 4 // +
#define CMD_GETADDR 5 // +
#define CMD_SETINFO 6 // +
#define CMD_GETINFO 7 // +
#define CMD_MSG 10 // +
#define CMD_LOGOUT 100 // +

#define RPL_INFO 100 // +
#define RPL_LOGIN 101 // +
#define RPL_STATUS 102 // � ��� ��� �����? ���� ����� ������ -)
#define RPL_REGISTER 103 // +
#define RPL_GETSTATUS 104 // +
#define RPL_GETADDR 105 // +
#define RPL_SETINFO 106 // +
#define RPL_GETINFO 107 // +
#define RPL_MSG 110 // +
#define RPL_LOGOUT 200 // +

#define STAT_ONLINE 255
#define STAT_OFFLINE 0
#define STAT_AWAY 1
#define STAT_INVISIBLE 2 // you suck, man: not implemented :)

struct __version
{
  unsigned char v;
  unsigned char b;
  char zero[2]; // linker error :(
};

struct _version
{
  struct __version i_vers;
};

struct _packet
{
	struct _version version;
	unsigned char cmd;
	unsigned long from;
	unsigned long to;
	unsigned char data[1024];
};

struct _user
{
  unsigned long uid;
  char login[10];
  sockaddr_in him;
  int sock;
  char status;
};

struct _user_info
{
  unsigned long uid;
  int status;
  char name[25];
  char info[128];
};

struct _login
{
  char login[10];
  char password[10];
  unsigned char ok;
  char reason[100];
};

struct _info
{
  unsigned char status;
  unsigned int users_max;
  unsigned int users_num;
  char server_name[50];
  char server_admin[50];
  char server_adm_mail[50];
  char motd[200];
};
