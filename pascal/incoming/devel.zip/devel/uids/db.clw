; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CProp
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "db.h"

ClassCount=7
Class1=CDbApp
Class2=CDbDlg
Class3=CAboutDlg

ResourceCount=11
Resource1=IDD_DB_DIALOG (English (U.S.))
Resource2=IDR_MAINFRAME
Resource3=IDD_ABOUTBOX
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_BASE
Resource6=IDD_ADDF
Class4=CPath
Resource7=IDR_POPUP
Class5=CProp
Resource8=IDD_DB_DIALOG
Class6=CAddNew
Resource9=IDD_PROP
Class7=CSave
Resource10=IDD_BSAVE
Resource11=IDR_FILE

[CLS:CDbApp]
Type=0
HeaderFile=db.h
ImplementationFile=db.cpp
Filter=N

[CLS:CDbDlg]
Type=0
HeaderFile=dbDlg.h
ImplementationFile=dbDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_LIST1

[CLS:CAboutDlg]
Type=0
HeaderFile=dbDlg.h
ImplementationFile=dbDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=3
Control1=IDC_STATIC,static,1342308480
Control2=IDOK,button,1342373889
Control3=IDC_STATIC,button,1342177287

[DLG:IDD_DB_DIALOG]
Type=1
Class=CDbDlg
ControlCount=3
Control1=IDC_LIST1,SysListView32,1350631429
Control2=IDC_STATUS,static,1342308352
Control3=IDC_FSTATUS,static,1342308352

[DLG:IDD_DB_DIALOG (English (U.S.))]
Type=1
Class=CDbDlg
ControlCount=2
Control1=IDC_LIST1,SysListView32,1350631429
Control2=IDC_BUTTON1,button,1342242816

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[MNU:IDR_POPUP]
Type=1
Class=?
Command1=IDM_ADDF
Command2=IDM_DELETE
Command3=IDM_FIND
Command4=IDM_PROP
Command5=IDM_EXIT
CommandCount=5

[DLG:IDD_BASE]
Type=1
Class=CPath
ControlCount=4
Control1=IDOK,button,1342275585
Control2=IDC_EDIT_FILENAME,edit,1350631552
Control3=IDC_BROWSE,button,1342275584
Control4=IDC_STATIC,button,1342177287

[CLS:CPath]
Type=0
HeaderFile=Path.h
ImplementationFile=Path.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDM_SAVEAS

[DLG:IDD_PROP]
Type=1
Class=CProp
ControlCount=10
Control1=IDC_FUNC,button,1342177287
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDC_FUID,edit,1350631552
Control5=IDC_DESCR,edit,1350631552
Control6=IDC_DELETEF,button,1342275584
Control7=IDC_SAVEF,button,1342275584
Control8=IDC_BUTTON1,button,1342275584
Control9=IDC_PASSWD,edit,1350631552
Control10=IDC_STATIC,static,1342308352

[CLS:CProp]
Type=0
HeaderFile=Prop.h
ImplementationFile=Prop.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_DELETEF

[DLG:IDD_ADDF]
Type=1
Class=CAddNew
ControlCount=9
Control1=IDOK,button,1342275584
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDC_FUID,edit,1350639744
Control5=IDC_FNAME,edit,1350631552
Control6=IDCANCEL,button,1342275584
Control7=IDC_STATIC,button,1342177287
Control8=IDC_PASSWD,edit,1350631552
Control9=IDC_STATIC,static,1342308352

[CLS:CAddNew]
Type=0
HeaderFile=AddNew.h
ImplementationFile=AddNew.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CAddNew

[DLG:IDD_BSAVE]
Type=1
Class=CSave
ControlCount=1
Control1=IDC_PROGRESS1,msctls_progress32,1350565889

[CLS:CSave]
Type=0
HeaderFile=Save.h
ImplementationFile=Save.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CSave

[MNU:IDR_FILE]
Type=1
Class=CDbDlg
Command1=IDM_LOADB
Command2=IDM_SAVEB
Command3=IDM_SAVEAS
Command4=IDM_SAVEIT
Command5=IDM_EXIT
Command6=ID_MENUITEM32781
CommandCount=6

