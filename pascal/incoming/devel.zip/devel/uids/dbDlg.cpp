#include "stdafx.h"
#include "db.h"
#include "dbDlg.h"
#include "database.h"
#include "path.h"
#include "prop.h"
#include "addnew.h"
#include "save.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDbDlg dialog

CDbDlg::CDbDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDbDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDbDlg)
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CDbDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDbDlg)
	DDX_Control(pDX, IDC_FSTATUS, m_fstatus);
	DDX_Control(pDX, IDC_STATUS, m_status);
	DDX_Control(pDX, IDC_LIST1, m_list);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDbDlg, CDialog)
	//{{AFX_MSG_MAP(CDbDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_SIZE()
	ON_WM_CONTEXTMENU()
	ON_COMMAND(IDM_PROP, OnProp)
	ON_COMMAND(IDM_EXIT, OnExit)
	ON_WM_CLOSE()
	ON_COMMAND(IDM_ADDF, OnAddf)
	ON_COMMAND(IDM_SAVEB, OnSaveb)
	ON_COMMAND(IDM_LOADB, OnLoadb)
	ON_COMMAND(IDM_DELETE, OnDelete)
	ON_COMMAND(IDM_SAVEAS, OnSaveas)
	ON_COMMAND(IDM_SAVEIT, OnSaveit)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST1, OnDblclkList1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDbDlg message handlers

BOOL CDbDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu = "� ���������...";
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

    CRect rcClient;
    GetClientRect(&rcClient);
	m_status.SetWindowPos(this, 0, rcClient.Height()-11, 80, rcClient.Height(), SWP_NOACTIVATE|SWP_NOZORDER);
	m_fstatus.SetWindowPos(this, 81, rcClient.Height()-11, 111, rcClient.Height(), SWP_NOACTIVATE|SWP_NOZORDER);
	m_list.SetWindowPos(this,0,0,rcClient.Width(),rcClient.Height()-12,SWP_NOACTIVATE|SWP_NOZORDER);
    m_list.SetFocus();

    m_list.GetClientRect(&rcClient);
    m_list.SetExtendedStyle(m_list.GetExtendedStyle()|LVS_EX_FLATSB
        |LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|
        LVS_EX_UNDERLINEHOT);

    m_list.InsertColumn(0, "#",LVCFMT_LEFT, 25);
    m_list.InsertColumn(1, "���", LVCFMT_LEFT, 100);
    m_list.InsertColumn(2, "UID", LVCFMT_LEFT, 70);
    m_list.InsertColumn(3, "������", LVCFMT_LEFT, rcClient.Width()-200);

	db = (char *)malloc(512);
	strset(db, 0);

	return TRUE;
}

void CDbDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CDbDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this);
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CDbDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDbDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
	
    CRect rcClient;
    GetClientRect(&rcClient);
    if (m_list)
	{
		m_list.SetWindowPos(NULL, 0, 0, rcClient.Width(), rcClient.Height()-12, SWP_NOACTIVATE|SWP_NOZORDER);
		m_list.SetColumnWidth(3, rcClient.Width() - 200);
	};
	if ((m_status)&&(m_fstatus))
	{
		m_status.SetWindowPos(this, 0, rcClient.Height()-11, 80, rcClient.Height(), SWP_NOACTIVATE|SWP_NOZORDER);
		m_fstatus.SetWindowPos(this, 81, rcClient.Height()-11, 111, rcClient.Height(), SWP_NOACTIVATE|SWP_NOZORDER);
	};
}

bool CDbDlg::LoadDb()
{
	bool ret = false;
	int index = 0;
	off_t size;
	size = open_db(&fd, db);
	if (size != -1) 
	{
		ret = true;
		count = size / sizeof (DB_RECORD);
		FillList();
		SetDlgItemInt(IDC_FSTATUS, count);
		saved = true;
	} else count = 0;
	return ret;
}

void CDbDlg::FillList()
{
	int i;
	DB_RECORD rec;
	char *str = (char *)malloc(15);
	m_list.DeleteAllItems();
	for (i=0;i<count;i++)
	{
		rec = get_item(fd, i);
		itoa(i+1, str, 10);
		m_list.InsertItem(i, str, 0);
		m_list.SetItemText(i, 1, (char *)rec.name);
		itoa(rec.uid, str, 10);
		m_list.SetItemText(i, 2, str);
		m_list.SetItemText(i, 3, (char *)rec.passwd);
	};
	free(str);
	return;
}

void CDbDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
 	CMenu mnuTop;
	mnuTop.LoadMenu(IDR_POPUP);
 	CMenu* pPopup = mnuTop.GetSubMenu( 0 );
 	ASSERT_VALID( pPopup );
 	pPopup->TrackPopupMenu(	TPM_LEFTALIGN | TPM_LEFTBUTTON,
 							point.x, point.y,
 							AfxGetMainWnd(), NULL );
}

void CDbDlg::OnProp() 
{
    POSITION pos = m_list.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
		CProp prop;
        while (pos)
        {
            int nItem = m_list.GetNextSelectedItem(pos);
			prop.wnd = this;
			prop.num = nItem;
			prop.fd = fd;
			prop.DoModal();
//			FillList(); - �����������������, ���� prop.DoModal() ��������� ����
       };
    };
	return;
}

void CDbDlg::OnOK()
{
	return;
}

void CDbDlg::OnCancel()
{
	return;
}

void CDbDlg::OnExit() 
{
	int ret = ::MessageBox(this->m_hWnd, "����� �� ���� ������������� ���������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
	if (ret == 6)
	{
		if (!saved)
		{
			ret = ::MessageBox(this->m_hWnd, "���� ��������, �� �� ��������� - ���������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
			if (ret == 6)
			{
				SaveDB("��������...", db);
			};
		};
		close(fd);
		CDialog::OnCancel();	
	};
	return;
}

void CDbDlg::OnClose() 
{
	int ret = ::MessageBox(this->m_hWnd, "����� �� ���� ������������� ���������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
	if (ret == 6)
	{
		if (!saved)
		{
			ret = ::MessageBox(this->m_hWnd, "���� ��������, �� �� ��������� - ���������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
			if (ret == 6)
			{
				SaveDB("��������...", db);
			};
		};
		close(fd);
		CDialog::OnCancel();
	};
	return;
}

void CDbDlg::OnAddf() 
{
	CAddNew an;
	an.DoModal();
	if (!an.m_name.IsEmpty())
	{
		char *str = (char *)malloc(15);
		itoa(count+1, str, 10);
		m_list.InsertItem(count, str, 0);
		m_list.SetItemText(count, 1, an.m_name.GetBuffer(1));
		itoa(an.m_uid, str, 10);
		m_list.SetItemText(count, 2, str);
		m_list.SetItemText(count, 3, an.m_passwd);
		count++;
		free(str);
		SetDlgItemInt(IDC_FSTATUS, count);

		CString text;
		GetWindowText(text);
		if (text.GetAt(text.GetLength()-2) != '*')
		{
			text.Delete(text.GetLength()-1, 1);
			text += "*]";
			SetWindowText(text);
		};
		saved = false;
	} else
	{
		::MessageBox(this->m_hWnd, "������ - ��������� �� ��� ����", "CHP Database Manager", MB_OK | MB_ICONSTOP);
	};
	return;	
}

bool CDbDlg::SaveDB(CString Caption, CString file)
{
	CSave dlg;
	dlg.wnd = this;
	dlg.caption = Caption;
	dlg.file = file;
	dlg.DoModal();
	FillList();
	saved = true;
	return true;
}

void CDbDlg::OnSaveb() 
{
	if (!strcmp(db, ""))
	{
		::MessageBox(this->m_hWnd, "������ ��� ���������� ����: ���� �� ���� �������", "CHP Database Manager", MB_OK | MB_ICONSTOP);
		return;
	};
	if (SaveDB("���������� ����...", db))
	{
		::MessageBox(this->m_hWnd, "���� ������� ���������", "CHP Database Manager", MB_OK | MB_ICONINFORMATION);
		CString text;
		text = "CHP Database Manager - [";
		text += db;
		text += "]";
		SetWindowText(text);
	} else
		::MessageBox(this->m_hWnd, "������ ��� ���������� ����", "CHP Database Manager", MB_OK | MB_ICONSTOP);
	return;
}

void CDbDlg::OnLoadb() 
{
	strset(db, 0);
	CPath path;
	path.DoModal();
	strcat(db, path.m_path);

	if (!LoadDb())
	{
		::MessageBox(this->m_hWnd, "���������� ��������� ����", "CHP Database Manager", MB_OK | MB_ICONSTOP);
		SetWindowText("CHP Database Manager v0.3");
		FillList();
		saved = true;
		OnCancel();
		return;
	};

	CString text;
	text = "CHP Database Manager [";
	text += db;
	text += "]";
	SetWindowText(text);
	if (count == 0)
	{
		int ret = ::MessageBox(this->m_hWnd, "���� ������� ������ ����. �������� ������ ������������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
		if (ret == 6)
		{
			OnAddf();
		};
	};
	return;
}

void CDbDlg::OnDelete() 
{
    POSITION pos = m_list.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
        while (pos)
        {
			int ret = ::MessageBox(this->m_hWnd, "����������� ��������?", "CHP Database Manager", MB_YESNO | MB_ICONQUESTION);
			if (ret != 6)
			{
				return;
			};
			CString tmp;
            int nItem = m_list.GetNextSelectedItem(pos);
			m_list.SetItemText(nItem, 0, "*");
			m_list.SetItemText(nItem, 1, "-deleted-");
			m_list.SetItemText(nItem, 3, "������� �������������!");
			count--; 

			CString text;
			GetWindowText(text);
			if (text.GetAt(text.GetLength()-2) != '*')
			{
				text.Delete(text.GetLength()-1, 1);
				text += "*]";
				SetWindowText(text);
			};
			saved = false;
        };
    };

	SetDlgItemInt(IDC_FSTATUS, count);
	return;
}

void CDbDlg::OnSaveas() 
{
	CString path;
	if (!strcmp(db, "")) return;
	CFileDialog dlg(FALSE, NULL, NULL, 0, NULL, this);
	int ret = dlg.DoModal();
	if (ret == 1)
	{
		path = dlg.GetPathName();
		SaveDB("����������...", path);
		CString text;
		text = "CHP Database Manager v0.1 - [" + path + "]";
		SetWindowText(text);
		saved = true;
	};
	return;
}

void CDbDlg::OnSaveit() 
{
	// �������\��������� SaveDB ��� ��������\�������� �������
	return;	
}

void CDbDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	*pResult = 0;
    POSITION pos = m_list.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
		CProp prop;
        while (pos)
        {
            int nItem = m_list.GetNextSelectedItem(pos);
			prop.wnd = this;
			prop.num = nItem;
			prop.fd = fd;
			prop.DoModal();
//			FillList(); - �����������������, ���� prop.DoModal() ��������� ����
       };
    };
	return;
}
