// First.cpp : implementation file
//

#include "stdafx.h"
#include "client.h"
#include "First.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFirst dialog


CFirst::CFirst(CWnd* pParent /*=NULL*/)
	: CDialog(CFirst::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFirst)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CFirst::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFirst)
	DDX_Control(pDX, IDC_NEW, m_new);
	DDX_Control(pDX, IDC_NEXT, m_next);
	DDX_Control(pDX, IDC_OLD, m_old);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFirst, CDialog)
	//{{AFX_MSG_MAP(CFirst)
	ON_BN_CLICKED(IDC_NEXT, OnNext)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFirst message handlers

void CFirst::OnNext() 
{
	UpdateData();
	bool regnew = m_new.GetCheck();
	if (regnew)
	{
		dlg.uid = 0;		
	} else
	{
		dlg.uid = 10000000;
	};
	dlg.master = masta;
	dlg.DoModal();
	if (dlg.uid != 0)
	{
		dlg_i.uid = dlg.uid;
		dlg_i.pass = dlg.m_pass;
		dlg_i.settings = settings;
		dlg_i.DoModal();
		CDialog::OnOK();
	} else
		return;
}
