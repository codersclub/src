#include "stdafx.h"
#include "client.h"
#include "clientDlg.h"
#include "First.h"
#include "Add.h"

#include <io.h>
#include <fcntl.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <stdio.h>
#include <stdlib.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

CClientDlg::CClientDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientDlg)
	DDX_Control(pDX, IDC_STATUSES, m_statuses);
	DDX_Control(pDX, IDC_CL, m_cl);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClientDlg, CDialog)
	//{{AFX_MSG_MAP(CClientDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_CLOSE()
	ON_WM_CONTEXTMENU()
	ON_WM_TIMER()
	ON_NOTIFY(NM_RCLICK, IDC_CL, OnRclickCl)
	ON_COMMAND(IDM_ADD, OnAdd)
	ON_COMMAND(IDM_DEL, OnDel)
	ON_COMMAND(IDM_MSG, OnMsg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientDlg message handlers

BOOL CClientDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	::MessageBox(0, "������ ��������� ���� (udp, 5350), ��� ���� ����������� �������, ��\r\n� �������� CMD_MSG; ����� �� ���������� ���� RPL_MSG (���� ��������� �������).\r\n����������� �� ������ ��� ������� ��������� ������-������, ����� ������.", "TODO", MB_ICONINFORMATION);

	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);
	SetIcon(m_hIcon, FALSE);

	exit = false;

	fd = open("contact", O_RDWR);
	if (fd <= 0)
	{
		::MessageBox(0, "���������� ������� ���� ��������!", "CHP client", MB_OK|MB_ICONSTOP);
		CDialog::OnCancel();
		return FALSE;
	};

	settings = open("settings", O_RDWR);
	if (settings <= 0)
	{
		::MessageBox(0, "���������� ������� ���� ��������!", "CHP client", MB_OK|MB_ICONSTOP);
		CDialog::OnCancel();
		return FALSE;
	};

	Reset(&masta);

	int err;
	struct stat fs;
	err = fstat (settings, &fs);
	if (fs.st_size == 0)
	{
		CFirst dlg;
		dlg.settings = settings;
		dlg.masta = &masta;
		dlg.DoModal();
	};

    CRect rcClient;
    GetClientRect(&rcClient);
	m_statuses.SetWindowPos(this, rcClient.Width()-110, rcClient.Height()-20, 110, 20, SWP_NOACTIVATE|SWP_NOZORDER);
	m_cl.SetWindowPos(this,0,0,rcClient.Width(),rcClient.Height()-22,SWP_NOACTIVATE|SWP_NOZORDER);
    m_cl.SetFocus();

    m_cl.SetExtendedStyle(m_cl.GetExtendedStyle()|LVS_EX_FLATSB
        |LVS_EX_FULLROWSELECT|LVS_EX_GRIDLINES|LVS_EX_HEADERDRAGDROP|LVS_EX_ONECLICKACTIVATE|
        LVS_EX_UNDERLINEHOT);


    m_cl.InsertColumn(0, "#",LVCFMT_LEFT, 25);
    m_cl.InsertColumn(1, "���", LVCFMT_LEFT, 100);
    m_cl.InsertColumn(2, "UID", LVCFMT_LEFT, 70);

	lseek(settings, 0, 0);
	read(settings, &ui, sizeof(struct user_info));

	for (num=0;num<USER_MAX;num++)
		users[num].ui.uid = 0;
	
	lseek(fd, 0, 0);
	num = 0;
	while ((!eof(fd))&&(num <= USER_MAX))
	{
		read(fd, &users[num].ui, sizeof(struct _user_info));
		num ++;
	};

	DrawCl();
	UpdateCl();
	SetTimer(10, 15000, NULL);
	SetTimer(11, 20000, NULL);
	SetTimer(1, 500, NULL);
	SetTimer(2, 100, NULL);

	return TRUE;
}

void CClientDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CClientDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CClientDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CClientDlg::OnCancel()
{
	if (exit)
	{
		CDialog::OnCancel();
	};
	return;
}

void CClientDlg::OnOK()
{
	return;
}

void CClientDlg::OnClose() 
{
	exit = true;
	struct _packet pck;
	memset(&pck, 0, sizeof(_packet));
	pck.version.i_vers.v = VERSION;
	pck.version.i_vers.b = BUILD;
	pck.cmd = CMD_LOGOUT;
	pck.to = SERVER_UID;
	pck.from = ui.uid;
	SendIt(&masta, (char *)&pck, sizeof(_packet));
	CDialog::OnClose();
	return;
}

bool CClientDlg::Login()
{
	int count;
	bool ret = false;
	Open(&masta, inet_addr(SERVER_ADDR), true);
	struct _packet pck;
	struct _login log;
	memset(&pck, 0, sizeof(_packet));
	memset(&log, 0, sizeof(_login));
	pck.version.i_vers.v = VERSION;
	pck.version.i_vers.b = BUILD;
	pck.from = ui.uid;
	pck.to = SERVER_UID;
	pck.cmd = CMD_LOGIN;
	strcat((char *)log.login, "chp0.1");
	strcat((char *)log.password, ui.pass);
	memcpy(pck.data, &log, sizeof(_login));
	SendIt(&masta, (char *)&pck, sizeof(_packet));
	count = 0;

	while (true)
	{
		count ++;
		memset(&pck, 0, sizeof(_packet));
		if (Receive(&masta, (char *)&pck, sizeof(_packet)) != -1)
		{
			if (pck.cmd == RPL_LOGIN)
			{
				memset(&log, 0, sizeof(_login));
				memcpy(&log, pck.data, sizeof(_login));
				if (log.ok)
				{
					if (strcmp(log.reason, ""))
						::MessageBox(0, log.reason, "����������", MB_OK | MB_ICONINFORMATION);
					CString status;
					itoa(pck.to, status.GetBuffer(1), 10);
					status.ReleaseBuffer();
					status += " (online)";
					SetDlgItemText(IDC_STATUS, status);
					ret = true;
				} else 
				{
					::MessageBox(0, log.reason, "������ �����������", MB_OK | MB_ICONSTOP);
				};
				break;
			};
		};
		Sleep(100);
		if (count >= 50)
		{
			::MessageBox(0, "������ �� ��������", "������ ���������� � ��������", MB_OK | MB_ICONSTOP);
			break;
		};
	};
	return ret;
}


void CClientDlg::OnContextMenu(CWnd* pWnd, CPoint point) 
{
 	CMenu mnuTop;
	mnuTop.LoadMenu(IDR_POPUP);
 	CMenu* pPopup = mnuTop.GetSubMenu( 0 );
 	ASSERT_VALID( pPopup );
 	pPopup->TrackPopupMenu(	TPM_LEFTALIGN | TPM_LEFTBUTTON,
 							point.x, point.y,
 							AfxGetMainWnd(), NULL );
}

void CClientDlg::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
	int k;
	if (nIDEvent == 2)
	{
		KillTimer(2);
		SetDlgItemText(IDC_STATUS, "����������...");
		if (!Login()) 
			SetDlgItemText(IDC_STATUS, "(��� ������)");
		else UpdateCl();
	};
	if (nIDEvent == 10)
	{
		UpdateCl();
		return;
	};
	if (nIDEvent == 11)
	{
		DrawCl();
		return;
	};
	if (nIDEvent == 1)
	{
		memset(&pack, 0, sizeof(_packet));
		if (Receive(&masta, (char *)&pack, sizeof(_packet)) != -1)
		{
		  if (pack.cmd == RPL_MSG)
		  {
			  return;
		  };
		  if (pack.cmd == RPL_GETSTATUS)
		  {
			  int status;
			  memcpy(&status, pack.data, sizeof(status));
			  if (status >= 0)
			  {
				  for (k=0;k<USER_MAX;k++)
				  {
					  if (users[k].ui.uid == pack.from)
					  {
						  users[k].ui.status = status;
					  };
				  };
			  };
		  };
		};
	};
}

void CClientDlg::UpdateCl()
{
	int i;
	for (i=0;i<=USER_MAX-1;i++)
	{
		if (users[i].ui.uid != 0)
		{
			pack.cmd = CMD_GETSTATUS;
			pack.to = users[i].ui.uid;
			pack.from = ui.uid;
			pack.version.i_vers.v = VERSION;
			pack.version.i_vers.b = BUILD;
			SendIt(&masta, (char *)&pack, sizeof(_packet));
		};
	};
	cl_num = 0;
	return;
};

void CClientDlg::ReadCl()
{
	lseek(fd, 0, 0);
	for (num=0;num<USER_MAX;num++)
		users[num].ui.uid = 0;
	num = 0;
	while ((!eof(fd))&&(num <= USER_MAX))
	{
		read(fd, &users[num].ui, sizeof(struct _user_info));
		num ++;
	};
	return;
}

void CClientDlg::OnRclickCl(NMHDR* pNMHDR, LRESULT* pResult) 
{
	*pResult = 0;
}

void CClientDlg::OnAdd() 
{
	CAdd dlg;
	dlg.DoModal();
	if (dlg.m_uid>0)
	{
		struct _user_info _ui;
		memset(&_ui, 0, sizeof(struct _user_info));
		_ui.uid = dlg.m_uid;
		memcpy(&users[num].ui, &_ui, sizeof(struct _user_info));
		num++;
		DrawCl();
		UpdateCl();
	};
	return;	
}

void CClientDlg::OnDel() 
{
	int k;
	char *str = (char *)malloc(20);
    POSITION pos = m_cl.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
        while (pos)
        {
            int nItem = m_cl.GetNextSelectedItem(pos);
//			m_cl.DeleteItem(nItem);
       };
    };
	return;
}

void CClientDlg::OnMsg() 
{
    POSITION pos = m_cl.GetFirstSelectedItemPosition();
    if (pos == NULL)
        TRACE("No items were selected\n");
    else
    {
        while (pos)
        {
            int nItem = m_cl.GetNextSelectedItem(pos);
       };
    };
	return;
}

void CClientDlg::DrawCl()
{
	int i;
	cl_num = 0;
	char *str = (char *)malloc(100);
	m_cl.DeleteAllItems();
	for (i=0;i<USER_MAX;i++)
	{
		if (users[i].ui.uid>0)
		{
			strset(str, 0);
			if (users[i].ui.status == STAT_OFFLINE)
				strcat(str, ".");
			if (users[i].ui.status == STAT_ONLINE)
				strcat(str, "+");
			if (users[i].ui.status == STAT_AWAY)
				strcat(str, "[+]");
			m_cl.InsertItem(cl_num, str, 0);
			strset(str, 0);
			m_cl.SetItemText(cl_num, 1, users[i].ui.name);
			itoa(users[i].ui.uid, str, 10);
			m_cl.SetItemText(cl_num, 2, str);
			cl_num ++;
		};
	};
	return;
}
