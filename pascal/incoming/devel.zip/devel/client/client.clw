; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CClientDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "client.h"

ClassCount=8
Class1=CClientApp
Class2=CClientDlg
Class3=CAboutDlg

ResourceCount=11
Resource1=IDD_CLIENT_DIALOG
Resource2=IDR_MAINFRAME
Resource3=IDD_ABOUTBOX (English (U.S.))
Resource4=IDD_CLIENT_DIALOG (English (U.S.))
Resource5=IDD_MSG
Class4=CFirst
Resource6=IDD_UID
Class5=UID
Resource7=IDD_ADD
Class6=CInfo
Resource8=IDD_ABOUTBOX
Class7=CMsg
Resource9=IDD_FIRSTTIME
Resource10=IDD_INFO
Class8=CAdd
Resource11=IDR_POPUP

[CLS:CClientApp]
Type=0
HeaderFile=client.h
ImplementationFile=client.cpp
Filter=N

[CLS:CClientDlg]
Type=0
HeaderFile=clientDlg.h
ImplementationFile=clientDlg.cpp
Filter=D
LastObject=IDM_MSG
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=clientDlg.h
ImplementationFile=clientDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_CLIENT_DIALOG]
Type=1
Class=CClientDlg
ControlCount=3
Control1=IDC_CL,SysListView32,1350631425
Control2=IDC_STATUS,static,1342308352
Control3=IDC_STATUSES,combobox,1344340226

[DLG:IDD_CLIENT_DIALOG (English (U.S.))]
Type=1
Class=CClientDlg
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_FIRSTTIME]
Type=1
Class=CFirst
ControlCount=5
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,static,1342308352
Control3=IDC_OLD,button,1342242825
Control4=IDC_NEW,button,1342242825
Control5=IDC_NEXT,button,1342275584

[CLS:CFirst]
Type=0
HeaderFile=First.h
ImplementationFile=First.cpp
BaseClass=CDialog
Filter=D
LastObject=CFirst
VirtualFilter=dWC

[DLG:IDD_UID]
Type=1
Class=UID
ControlCount=6
Control1=IDC_UID,edit,1350639744
Control2=IDC_PASS,edit,1350631552
Control3=IDC_DOIT,button,1342242816
Control4=IDC_PROGRESS1,msctls_progress32,1350565889
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352

[CLS:UID]
Type=0
HeaderFile=UID.h
ImplementationFile=UID.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_DOIT

[DLG:IDD_INFO]
Type=1
Class=CInfo
ControlCount=5
Control1=IDC_SAVE,button,1342242816
Control2=IDC_STATIC,static,1342308352
Control3=IDC_NAME,edit,1350631552
Control4=IDC_INFO,edit,1352732740
Control5=IDC_PROGR,msctls_progress32,1350565889

[CLS:CInfo]
Type=0
HeaderFile=Info.h
ImplementationFile=Info.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=CInfo

[DLG:IDD_MSG]
Type=1
Class=CMsg
ControlCount=2
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816

[CLS:CMsg]
Type=0
HeaderFile=Msg.h
ImplementationFile=Msg.cpp
BaseClass=CDialog
Filter=D
LastObject=CMsg

[MNU:IDR_POPUP]
Type=1
Class=?
Command1=IDM_MSG
Command2=IDM_INFO
Command3=IDM_ADD
Command4=IDM_DEL
CommandCount=4

[DLG:IDD_ADD]
Type=1
Class=CAdd
ControlCount=2
Control1=IDOK,button,1342242817
Control2=IDC_UID,edit,1350639744

[CLS:CAdd]
Type=0
HeaderFile=Add.h
ImplementationFile=Add.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_UID

