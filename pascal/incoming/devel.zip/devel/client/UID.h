#if !defined(AFX_UID_H__1F7E2D19_4C1F_4775_A582_902AE433EA6F__INCLUDED_)
#define AFX_UID_H__1F7E2D19_4C1F_4775_A582_902AE433EA6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// UID.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// UID dialog

class UID : public CDialog
{
// Construction
public:
	bool done;
	struct _master *master;
	unsigned int uid;
	UID(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(UID)
	enum { IDD = IDD_UID };
	CEdit	m_cpass;
	CEdit	m_cuid;
	CProgressCtrl	m_progr;
	CString	m_pass;
	UINT	m_uid;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(UID)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(UID)
	virtual BOOL OnInitDialog();
	afx_msg void OnDoit();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UID_H__1F7E2D19_4C1F_4775_A582_902AE433EA6F__INCLUDED_)
