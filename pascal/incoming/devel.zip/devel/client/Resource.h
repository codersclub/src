//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by client.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CLIENT_DIALOG               102
#define IDP_SOCKETS_INIT_FAILED         103
#define IDR_MAINFRAME                   128
#define IDD_DIALOG1                     129
#define IDD_FIRSTTIME                   133
#define IDD_UID                         134
#define IDD_INFO                        135
#define IDD_MSG                         136
#define IDR_POPUP                       137
#define IDD_ADD                         138
#define IDC_OLD                         1000
#define IDC_NEW                         1001
#define IDC_NEXT                        1002
#define IDC_UID                         1003
#define IDC_PASS                        1004
#define IDC_DOIT                        1005
#define IDC_PROGRESS1                   1006
#define IDC_SAVE                        1007
#define IDC_NAME                        1008
#define IDC_INFO                        1009
#define IDC_PROGR                       1010
#define IDC_CL                          1011
#define IDC_STATUSES                    1012
#define IDC_STATUS                      1013
#define IDM_MSG                         32771
#define IDM_ADD                         32772
#define IDM_DEL                         32773
#define IDM_INFO                        32774

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32775
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
