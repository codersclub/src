#if !defined(AFX_CLIENTDLG_H__FEAB6786_DA1B_489E_A71D_7B3C3ABD5654__INCLUDED_)
#define AFX_CLIENTDLG_H__FEAB6786_DA1B_489E_A71D_7B3C3ABD5654__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "packet.h"
#include "misc.h"
#include "Msg.h"

struct _user
{
  struct _user_info ui;
  CMsg msg;
};

/////////////////////////////////////////////////////////////////////////////
// CClientDlg dialog

class CClientDlg : public CDialog
{
// Construction
public:
	void DrawCl();
	int cl_num;
	void ReadCl();
	struct _packet pack;
	void UpdateCl();
	struct _user users[USER_MAX];
	int num;
	bool Login();
	struct user_info ui;
	struct _master masta;
	int settings;
	bool exit;
	void OnOK();
	void OnCancel();
	int fd;
	CClientDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClientDlg)
	enum { IDD = IDD_CLIENT_DIALOG };
	CComboBox	m_statuses;
	CListCtrl	m_cl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CClientDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnClose();
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRclickCl(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnAdd();
	afx_msg void OnDel();
	afx_msg void OnMsg();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTDLG_H__FEAB6786_DA1B_489E_A71D_7B3C3ABD5654__INCLUDED_)
