#include "stdafx.h"
#include "client.h"
#include "Info.h"

#include "misc.h"
#include "packet.h"

#include <io.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CInfo dialog


CInfo::CInfo(CWnd* pParent /*=NULL*/)
	: CDialog(CInfo::IDD, pParent)
{
	//{{AFX_DATA_INIT(CInfo)
	m_info = _T("");
	m_name = _T("");
	//}}AFX_DATA_INIT
}


void CInfo::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CInfo)
	DDX_Control(pDX, IDC_PROGR, m_progr);
	DDX_Text(pDX, IDC_INFO, m_info);
	DDV_MaxChars(pDX, m_info, 128);
	DDX_Text(pDX, IDC_NAME, m_name);
	DDV_MaxChars(pDX, m_name, 25);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CInfo, CDialog)
	//{{AFX_MSG_MAP(CInfo)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CInfo message handlers

void CInfo::OnSave() 
{
	UpdateData();
	if (!m_name.IsEmpty())
	{
		WSAData wsa;
		WSAStartup(0x0101, &wsa);
		struct _master master;
		struct user_info ui;
		memset(&ui, 0, sizeof(struct user_info));
		strcat((char *)ui.name, m_name.GetBuffer(1));
		m_name.ReleaseBuffer();
		strcat((char *)ui.info, m_info.GetBuffer(1));
		m_info.ReleaseBuffer();
		ui.uid = uid;
		strcat((char *)ui.pass, pass.GetBuffer(1));
		pass.ReleaseBuffer();

		lseek(settings, 0, 0);
		write(settings, &ui, sizeof(struct user_info));
//		m_progr.SetPos(1);

		Open(&master, inet_addr(SERVER_ADDR), true);
		struct _packet pck;
		struct _login log;
		memset(&pck, 0, sizeof(_packet));
		memset(&log, 0, sizeof(_login));
		pck.version.i_vers.v = VERSION;
		pck.version.i_vers.b = BUILD;
		pck.from = ui.uid;
		pck.to = SERVER_UID;
		pck.cmd = CMD_LOGIN;
		strcat((char *)log.login, "chp0.1");
		strcat((char *)log.password, pass);
		memcpy(pck.data, &log, sizeof(_login));
		SendIt(&master, (char *)&pck, sizeof(_packet));

		int count = 0 ;
		while (true)
		{
			count ++;
			m_progr.SetPos(count);
			memset(&pck, 0, sizeof(_packet));
			if (Receive(&master, (char *)&pck, sizeof(_packet)) != -1)
			{
				if (pck.cmd == RPL_LOGIN)
				{
					memset(&log, 0, sizeof(_login));
					memcpy(&log, pck.data, sizeof(_login));
					if (log.ok)
					{
						struct _user_info _ui;
						memset(&_ui, 0, sizeof(struct _user_info));
						memcpy(_ui.info, ui.info, 128);
						memcpy(_ui.name, ui.name, 25);
						_ui.uid = ui.uid;
						pck.from = ui.uid;
						pck.to = SERVER_UID;
						pck.cmd = CMD_SETINFO;
						memcpy(pck.data, &_ui, sizeof(struct _user_info));
						SendIt(&master, (char *)&pck, sizeof(_packet));
					} else 
					{
						MessageBox((char *)log.reason, "������!");
						m_progr.SetPos(0);
						return;
					};
				};
				if (pck.cmd == RPL_SETINFO)
				{
					pck.from = ui.uid;
					pck.to = SERVER_UID;
					pck.cmd = CMD_LOGOUT;
					SendIt(&master, (char *)&pck, sizeof(_packet));
					RedrawWindow();
					break;
				};
			};
			Sleep(100);
			if (count >= 50)
			{
				::MessageBox(0, "������ �� ��������", "������ ���������� � ��������", MB_OK | MB_ICONSTOP);
				m_progr.SetPos(0);
				break;
			};
		};
		m_progr.SetPos(50);
		UpdateData(false);
		done = true;
		Sleep(500);
		CDialog::OnOK();
	} else
	{
		::MessageBox(0, "�� ������� ��� ������������!", "������", MB_OK | MB_ICONSTOP);
		return;
	};
}

BOOL CInfo::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_progr.SetRange(0, 50);
	m_progr.SetPos(0);
	done = false;
	return TRUE;
}
