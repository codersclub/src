#if !defined(AFX_FIRST_H__A0AA0D3A_8549_4DC7_AAC4_3981571844EE__INCLUDED_)
#define AFX_FIRST_H__A0AA0D3A_8549_4DC7_AAC4_3981571844EE__INCLUDED_

#include "UID.h"
#include "Info.h"
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// First.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFirst dialog

class CFirst : public CDialog
{
// Construction
public:
	int settings;
	CInfo dlg_i;
	struct _master *masta;
	UID dlg;
	CFirst(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFirst)
	enum { IDD = IDD_FIRSTTIME };
	CButton	m_new;
	CButton	m_next;
	CButton	m_old;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFirst)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFirst)
	afx_msg void OnNext();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FIRST_H__A0AA0D3A_8549_4DC7_AAC4_3981571844EE__INCLUDED_)
