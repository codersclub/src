#if !defined(AFX_MSG_H__29034A34_A2F5_41CB_9928_319D2D94BC39__INCLUDED_)
#define AFX_MSG_H__29034A34_A2F5_41CB_9928_319D2D94BC39__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Msg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMsg dialog

class CMsg : public CDialog
{
// Construction
public:
	CMsg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CMsg)
	enum { IDD = IDD_MSG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMsg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CMsg)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MSG_H__29034A34_A2F5_41CB_9928_319D2D94BC39__INCLUDED_)
