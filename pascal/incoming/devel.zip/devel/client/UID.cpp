#include "stdafx.h"
#include "client.h"
#include "UID.h"

#include "misc.h"
#include "packet.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// UID dialog


UID::UID(CWnd* pParent /*=NULL*/)
	: CDialog(UID::IDD, pParent)
{
	//{{AFX_DATA_INIT(UID)
	m_pass = _T("");
	m_uid = 0;
	//}}AFX_DATA_INIT
}


void UID::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(UID)
	DDX_Control(pDX, IDC_PASS, m_cpass);
	DDX_Control(pDX, IDC_UID, m_cuid);
	DDX_Control(pDX, IDC_PROGRESS1, m_progr);
	DDX_Text(pDX, IDC_PASS, m_pass);
	DDV_MaxChars(pDX, m_pass, 10);
	DDX_Text(pDX, IDC_UID, m_uid);
	DDV_MinMaxUInt(pDX, m_uid, 0, 100000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(UID, CDialog)
	//{{AFX_MSG_MAP(UID)
	ON_BN_CLICKED(IDC_DOIT, OnDoit)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// UID message handlers

BOOL UID::OnInitDialog() 
{
	CDialog::OnInitDialog();
	m_progr.SetRange(0, 50);
	m_progr.SetPos(0);
	if (uid != 10000000)
	{
		m_cuid.SetReadOnly(true);
		SetDlgItemText(IDC_DOIT, "����������");
	} else 
	{
		m_cuid.SetReadOnly(false);
		SetDlgItemText(IDC_DOIT, "���������");
	};
	uid = 0;
	m_uid = 0;
	m_pass = "";
	done = false;
	UpdateData(false);
	return TRUE;
}

void UID::OnDoit() 
{
	if (!done)
	{
		WSAData wsa;
		WSAStartup(0x0101, &wsa);
		Open(master, inet_addr(SERVER_ADDR), true);
		struct _packet pck;
		struct _login log;
		memset(&pck, 0, sizeof(_packet));
		memset(&log, 0, sizeof(_login));
		pck.version.i_vers.v = VERSION;
		pck.version.i_vers.b = BUILD;
		UpdateData();
		m_cuid.SetReadOnly(true);
		m_cpass.SetReadOnly(true);
		if (m_uid != 0)
		{
			pck.from = m_uid;
			pck.to = SERVER_UID;
			pck.cmd = CMD_LOGIN;
			strcat((char *)log.login, "chp0.1");
			strcat((char *)log.password, m_pass);
			memcpy(pck.data, &log, sizeof(_login));
			SendIt(master, (char *)&pck, sizeof(_packet));
		} else
		{
			pck.from = 0;
			pck.to = SERVER_UID;
			pck.cmd = CMD_REGISTER;
			memcpy(pck.data, m_pass.GetBuffer(1), m_pass.GetLength());
			SendIt(master, (char *)&pck, sizeof(_packet));
		};

		int count = 0;

		while (true)
		{
			count ++;
			m_progr.SetPos(count);
			memset(&pck, 0, sizeof(_packet));
			if (Receive(master, (char *)&pck, sizeof(_packet)) != -1)
			{
				if (pck.cmd == RPL_LOGIN)
				{
					memset(&log, 0, sizeof(_login));
					memcpy(&log, pck.data, sizeof(_login));
					if (log.ok)
					{
						uid = pck.to;
						pck.from = uid;
						pck.to = SERVER_UID;
						pck.cmd = CMD_LOGOUT;
						SendIt(master, (char *)&pck, sizeof(_packet));
						SetDlgItemText(IDC_DOIT, "�������");
						done = true;
						MessageBox((char *)log.reason, "������ ������");
					} else 
					{
						m_cuid.SetReadOnly(false);
						m_cpass.SetReadOnly(false);
						MessageBox((char *)log.reason, "������");
						m_progr.SetPos(0);
						uid = 0;
					};
					break;
				};
				if (pck.cmd == RPL_REGISTER)
				{
					m_uid = pck.to;
					uid = m_uid;
					SetDlgItemText(IDC_DOIT, "�������");
					done = true;
					UpdateData(false);
					break;
				};
			};
			Sleep(100);
			if (count >= 50)
			{
				::MessageBox(0, "������ �� ��������", "������ ���������� � ��������", MB_OK | MB_ICONSTOP);
				m_cuid.SetReadOnly(false);
				m_cpass.SetReadOnly(false);
				m_progr.SetPos(0);
				uid = 0;
				break;
			};
		};
		m_progr.SetPos(50);
		UpdateData(false);
	} else
	{
		CDialog::OnOK();
	};
}
