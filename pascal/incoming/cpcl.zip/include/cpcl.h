//
// cpcl.h
// This source is a part of Cross-Platform Classes Library. 
// It is distributed under the GNU General Public Licence. 
// Copyright (c) 2002 - Andrew Nayenko AKA Relan
//
// This header includes other headers and should not contain
//  any code.
//

// All CPCL classes (n/i means "not implemented yet", 
// p/i means "partially implemented"):
//
//	CObject
//		CProgram (any program)
//			CApp (your application, it's a part of CPCL
//					and the only object you should edit)
//		CSystem (everything beyond the application) - n/i
//			CWin (Windows specific) - n/i
//			CLinux (Linux specific) - n/i
//		CString - p/i
//			CWildcard - p/i
//			CRegex - n/i
//		CArray (of any type) - p/i
//		CStream
//			CDirectory - n/i
//			CFile - p/i
//			COutput - n/i
//			CInput - n/i
//			CError - n/i
//		CHeap - n/i

// Supported platforms:
//	o	Linux 2.4 - n/i
//	o	Windows 95/98/Me (no MSVCRT.DLL) - p/i
//	o	Windows NT/2000/XP (no MSVCRT.DLL) - p/i

// Platform definitions:
//	o	LINUX (for gcc)
//	o	WIN (for MSVC)

// Other CPCL definitions:
//	o	UNICODE		- use Unicode versions of some
//					  Windwos NT/2000/XP API functions

#include "style.h"
#include "types.h"
#include "macro.h"
#include "object.h"
#include "array.h"
#include "str.h"
#include "wildcard.h"
#include "stream.h"
#include "file.h"
#include "directory.h"
#include "program.h"
#include "app.h"
