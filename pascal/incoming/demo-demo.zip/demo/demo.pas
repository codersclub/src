uses crt,m13h,dos;

type p = array[0..2] of double;
     f = array[0..2] of integer;
     t = array[0..1] of word;
     model = record
       v,t:array[0..900]of p;
       f,tf:array[0..800]of f;
       tx:array[0..800]of t;
       ang:f;
       orig:p;
       max_p,max_f,max_t:word;
     end;
     zx=array[0..319] of byte;
const
 getmaxx=320;
 getmaxy=200;
 qual=100;
 zmin=-1;
 M_pi=3.14159265358979323846;

var mmx,mmy,wx,wy,i,ii,mx,my:integer;
    buf,tex:pointer;
    key:char;
    map:model;
    zoom:word;
    edit:boolean;
    ZB:array[0..199] of ^zx;
    csn,sns:array[0..360]of real;

Procedure HLine(X,X2,Y:Integer;TX,TY,TX2,TY2:Integer;z1,z2:double);Var L,d1,d2:integer;u,t:word;dz:double;Begin
 If(X>X2)Then Begin
  l:=X;x:=X2;x2:=l;
  l:=TX;tx:=TX2;tx2:=l;
  l:=TY;ty:=TY2;ty2:=l;
  dz:=z1;z1:=z2;z2:=dz;
 End;
 if(x2<0)or(x>319)then exit;
 if x2=x then L:=1 else L:=X2-X;
 d1:=(TX2-TX)Div L;
 d2:=(TY2-TY)Div L;
 dz:=(z2-z1)/L;
 if(x<0)then begin x:=abs(x);
   tx:=tx+(x*d1);
   ty:=ty+(x*d2);
   z1:=z1+(x*dz);
   x:=0;
 end;
 if(x2>319)then x2:=319;
 t:=y;
 y:=y*320;
 For l:=x To x2 Do Begin
  u:=((ty div qual)*320)+(tx div qual);
  if(z1<zmin)and(abs(z1)<zb[t]^[l])then begin
   mem[seg(buf^):y+l]:=mem[seg(tex^):u];
   zb[t]^[l]:=abs(round(z1));
  end;
  Inc(TX,d1);
  Inc(TY,d2);
  z1:=z1+dz;
 End;
End;

Procedure Triangle(x1,y1,x2,y2,x3,y3:longint;z1,z2,z3:double;tx1,ty1,tx2,ty2,tx3,ty3:integer);
Var a,dx,dy,dx2,dy2,dy3,dx3:longint;
    xa,xb,xc, da,db,dc, dz1,dz2,dz3:double;
    dy31,dy21,dy32:word;
Begin
 if(x1<0)and(x2<0)and(x3<0)then exit;
 if(x1>319)and(x2>319)and(x3>319)then exit;
 if(y1>y2)then begin a:=y1;y1:=y2;y2:=a;a:=x1;x1:=x2;x2:=a;
                     a:=ty1;ty1:=ty2;ty2:=a;a:=tx1;tx1:=tx2;tx2:=a;
                     xa:=z1;z1:=z2;z2:=xa;end;
 if(y1>y3)then begin a:=y1;y1:=y3;y3:=a;a:=x1;x1:=x3;x3:=a;
                     a:=ty1;ty1:=ty3;ty3:=a;a:=tx1;tx1:=tx3;tx3:=a;
                     xa:=z1;z1:=z3;z3:=xa;end;
 if(y2>y3)then begin a:=y2;y2:=y3;y3:=a;a:=x2;x2:=x3;x3:=a;
                     a:=ty2;ty2:=ty3;ty3:=a;a:=tx2;tx2:=tx3;tx3:=a;
                     xa:=z2;z2:=z3;z3:=xa;end;
 if(y3<0)or(y1>199)then exit;
  dy31:=y3-y1;
  dy21:=y2-y1;
  dy32:=y3-y2;
  tx1:=tx1*qual;
  ty1:=ty1*qual;
  tx2:=tx2*qual;
  ty2:=ty2*qual;
  tx3:=tx3*qual;
  ty3:=ty3*qual;
  If(dy31<>0)then begin
      da:=(x3-x1)/dy31;
      dx:=(tx3-tx1) div abs(dy31);
      dy:=(ty3-ty1) div abs(dy31);
      dz1:=(z3-z1)/dy31;
  end;
  If(dy21<>0)then begin
      db:=(x2-x1)/dy21;
      dx2:=(tx2-tx1) div abs(dy21);
      dy2:=(ty2-ty1) div abs(dy21);
      dz2:=(z2-z1)/dy21;
  end;
  If(dy32<>0)then begin
      dc:=(x3-x2)/dy32;
      dx3:=(tx3-tx2) div abs(dy32);
      dy3:=(ty3-ty2) div abs(dy32);
      dz3:=(z3-z2)/dy32;
  end;
  xa:=x1;
  xb:=x1;
  xc:=x2;
  tx3:=tx2;ty3:=ty2;
  tx2:=tx1;ty2:=ty1;
  z3:=z2;
  z2:=z1;
  if(y1<0)then begin y1:=abs(y1);
   xa:=xa+(y1*da);   xb:=xb+(y1*db);
   tx1:=tx1+(y1*dx); ty1:=ty1+(y1*dy);
   tx2:=tx2+(y1*dx2);ty2:=ty2+(y1*dy2);
   z1:=z1+(y1*dz1);  z2:=z2+(y1*dz2);
   if(y2<0)then begin y2:=abs(y2);
    xc:=xc+(y2*dc);
    tx3:=tx3+(y2*dx3);ty3:=ty3+(y2*dy3);
    z3:=z3+(y2*dz3);
    y2:=0;
   end;
   y1:=0;
  end;
  if y3>199 then y3:=199;
  For a:=y1 to y3 Do Begin
    if(a<y2)then begin
     if(z1<zmin)or(z2<zmin)then hline(Round(xa),Round(xb),a, tx1,ty1,tx2,ty2 ,z1,z2);
     xb:=xb+db;
     tx2:=tx2+dx2;ty2:=ty2+dy2;
     z2:=z2+dz2;
    end else begin
     if(z1<zmin)or(z3<zmin)then hline(Round(xa),Round(xc),a, tx1,ty1,tx3,ty3 ,z1,z3);
     xc:=xc+dc;
     tx3:=tx3+dx3;ty3:=ty3+dy3;
     z3:=z3+dz3;
    end;
   xa:=xa+da;
   tx1:=tx1+dx;ty1:=ty1+dy;
   z1:=z1+dz1;
  End;
End;

procedure fov(var v1:p;b:double);var vt:p;begin vt:=v1;
 b:=-b/vt[2];
 v1[1]:=100+(vt[0]*b);
 v1[0]:=160+(vt[1]*b);
end;

procedure norm(var ang:integer);begin
 ang:=ang mod 360;if ang<0 then inc(ang,360);
end;

procedure tdcr(a:f;i:p;var o:p);begin
o[1]:=i[1]*csn[a[0]]-i[2]*sns[a[0]];o[2]:=i[1]*sns[a[0]]+i[2]*csn[a[0]];i[1]:=o[1];i[2]:=o[2];
o[0]:=i[0]*csn[a[1]]+i[2]*sns[a[1]];o[2]:=-i[0]*sns[a[1]]+i[2]*csn[a[1]];i[0]:=o[0];i[2]:=o[2];
o[0]:=i[0]*csn[a[2]]-i[1]*sns[a[2]];o[1]:=i[0]*sns[a[2]]+i[1]*csn[a[2]];i[0]:=o[0];i[1]:=o[1];
o[0]:=i[0];o[1]:=i[1];o[2]:=i[2];end;

procedure draw(v1,v2,v3:p;tx1,ty1,tx2,ty2,tx3,ty3:word;cl:byte;w:word);begin
if((v1[2]>zmin)and(v2[2]>zmin)and(v3[2]>zmin))then exit;
if((((v2[0]-v1[0])*(v3[1]-v1[1]))-((v3[0]-v1[0])*(v2[1]-v1[1])))>0)then begin
 triangle(round(v1[0]),round(v1[1]),round(v2[0]),round(v2[1]),round(v3[0]),round(v3[1]),
 v1[2],v2[2],v3[2],tx1,ty1,tx2,ty2,tx3,ty3);
end;
end;

procedure load_tmd(name:string);var d:file;begin
assign(d,name);reset(d,1);
 blockread(d,tex^,64000);
 blockread(d,pal,1024);
 blockread(d,map.max_p,sizeof(map.max_p));
 blockread(d,map.max_f,sizeof(map.max_f));
 blockread(d,map.max_t,sizeof(map.max_t));
 blockread(d,map.v,(map.max_p+1)*sizeof(p));
 blockread(d,map.f,(map.max_f+1)*sizeof(f));
 blockread(d,map.tf,(map.max_f+1)*sizeof(f));
 blockread(d,map.tx,(map.max_t+1)*sizeof(t));
close(d);
end;

begin init13h;randomize;
 cls(0,seg(mem[$a000:0]));
 getmem(buf,320*200);cls(0,seg(buf^));
 getmem(tex,320*200);cls(0,seg(tex^));
 load_tmd('demo1.tmd');
 for i:=0 to 199 do new(zb[i]);
 setpal;
 setrgb(0,0,0,8);
   map.orig[0]:=5;map.orig[1]:=0;map.orig[2]:=-20;
   map.ang[1]:=180;map.ang[0]:=random(360);map.ang[2]:=0;
 mouse_x_lim(0,getmaxx*2);mouse_y_lim(0,getmaxy);mouse_move(160,100);
 wx:=getmaxx div 2;wy:=getmaxy div 2;
  for i:=0 to 360 do begin sns[i]:=sin(i*m_pi/180);csn[i]:=cos(i*m_pi/180);end;
  init_timer;
  zoom:=200;
  edit:=false;
  if si(paramstr(2))>0 then zoom:=si(paramstr(2));
  for i:=0 to 199 do fillchar(zb[i]^,319,255);
REPEAT key:=#0;if keypressed then key:=readkey;
if edit then flip(tex,buf) else begin
{mouse debug}
 mouse_coords(mmx,mmy);
 inc(mx,(mmx-wx)div 2);inc(my,(mmy-wy)div 2);
 mouse_move(320,wy);
{control}
if mouse=1 then map.orig[2]:=map.orig[2]+1;
if mouse=2 then map.orig[2]:=map.orig[2]-1;
{if mouse=3 then }inc(map.ang[0],1);
{  map.ang[1]:=my-180;
  map.ang[0]:=mx+45;}
  norm(map.ang[0]);norm(map.ang[1]);
{calculate origin of map}
 for i:=0 to map.max_p do begin
  tdcr(map.ang,map.v[i],map.t[i]);
  map.t[i][0]:=map.t[i][0]+map.orig[0];
  map.t[i][1]:=map.t[i][1]+map.orig[1];
  map.t[i][2]:=map.t[i][2]+map.orig[2];
  if map.t[i][2]>zmin then map.t[i][2]:=zmin;{begin
{   map.t[i][0]:=-map.t[i][0];
   map.t[i][1]:=-map.t[i][1];
  end;}
  fov(map.t[i],zoom);
 end;
{write}
 for i:=0 to map.max_f do begin
   draw(map.t[map.f[i][0]],map.t[map.f[i][1]],map.t[map.f[i][2]],
        map.tx[map.tf[i][0]][0],map.tx[map.tf[i][0]][1],
        map.tx[map.tf[i][1]][0],map.tx[map.tf[i][1]][1],
        map.tx[map.tf[i][2]][0],map.tx[map.tf[i][2]][1],10,seg(buf^));
 end;
end;
 if key=#13 then edit:=not(edit);
 refresh_timer;
 outtextxy(260,10,'fps : '+is(fps),60,seg(buf^));
 outbufer(seg(buf^));
 if edit=false then begin  cls(0,seg(buf^));
  for i:=0 to 199 do fillchar(zb[i]^,319,255);
 end;
UNTIL key=#27;
 for i:=0 to 199 do dispose(zb[i]);
 freemem(buf,320*200);
 freemem(tex,320*200);
 close_timer;
close13h;end.