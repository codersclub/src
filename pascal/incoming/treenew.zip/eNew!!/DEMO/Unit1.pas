unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, DBTreeAscar, DB, DBTables, StdCtrls, Grids, DBGrids;

type
  TForm1 = class(TForm)
    DBTreeAscar1: TDBTreeAscar;
    DataSource1: TDataSource;
    Table1: TTable;
    Button1: TButton;
    Button2: TButton;
    Table2: TTable;
    DataSource2: TDataSource;
    DBGrid1: TDBGrid;
    Button3: TButton;
    Button4: TButton;
    Label1: TLabel;
    Label2: TLabel;
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Table1AfterScroll(DataSet: TDataSet);
    procedure Table2AfterScroll(DataSet: TDataSet);
    procedure Button3Click(Sender: TObject);
    procedure Button4Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  Form1: TForm1;

implementation

{$R *.dfm}

procedure TForm1.Button1Click(Sender: TObject);
begin
DBTreeAscar1.UP;
end;

procedure TForm1.Button2Click(Sender: TObject);
begin
DBTreeAscar1.Down;
end;

procedure TForm1.Table1AfterScroll(DataSet: TDataSet);
begin
if Table2.Active then
  if Table1.Fields[0].AsString<>'' then
   Table2.Locate('ID',Table1.Fields[0].AsString,[loCaseInsensitive])
end;

procedure TForm1.Table2AfterScroll(DataSet: TDataSet);
begin
{if Table1.Active then
  if Table2.Fields[0].AsString<>'' then
   DBTreeAscar1.FindToTree(Table2.Fields[0].AsString); }
end;

procedure TForm1.Button3Click(Sender: TObject);
begin
  if Table2.Fields[0].AsString<>'' then
   DBTreeAscar1.FindToTree(Table2.Fields[0].AsString); 
end;

procedure TForm1.Button4Click(Sender: TObject);
var id: string;
begin
Table2.Last;
id := IntToStr(1+Table2.Fields[0].AsInteger);
Table1.AppendRecord([id,DBTreeAscar1.IDParr,'����� �������']);
end;

end.
