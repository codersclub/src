object Form1: TForm1
  Left = 192
  Top = 107
  BorderStyle = bsToolWindow
  Caption = #1044#1077#1088#1077#1074#1086
  ClientHeight = 660
  ClientWidth = 546
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 64
    Top = 288
    Width = 441
    Height = 13
    Caption = 
      #1059#1076#1072#1083#1077#1085#1080#1077' '#1079#1072#1087#1080#1089#1080' '#1074' '#1076#1077#1088#1077#1074#1077' '#1078#1077#1083#1072#1090#1077#1083#1100#1085#1086' '#1076#1077#1083#1072#1090#1100' '#1087#1088#1080' '#1085#1072#1083#1080#1095#1080#1080' '#1089#1086#1086#1090#1074#1077#1090#1089#1074 +
      #1091#1102#1097#1077#1075#1086' '#1090#1088#1080#1075#1077#1088#1072
  end
  object Label2: TLabel
    Left = 16
    Top = 312
    Width = 523
    Height = 13
    Caption = 
      #1045#1089#1083#1080' '#1074#1099' '#1085#1077#1079#1085#1072#1077#1090#1077' '#1082#1072#1082' '#1091#1076#1072#1083#1103#1090#1100' '#1079#1072#1087#1080#1089#1080' '#1074' '#1076#1077#1088#1077#1074#1103#1085#1099#1093' '#1090#1072#1073#1083#1080#1094#1072#1093' '#1085#1072#1080#1076#1080#1090#1077 +
      ' '#1089#1086#1086#1090'. '#1090#1077#1086#1088#1077#1090#1080#1095#1077#1089#1082#1080#1081' '#1084#1072#1090#1077#1088#1080#1072#1083' :)'
  end
  object DBTreeAscar1: TDBTreeAscar
    Left = 0
    Top = 0
    Width = 546
    Height = 225
    DBSource = DataSource1
    ID = 'id'
    NameF = 'name'
    IDParend = 'idparend'
  end
  object Button1: TButton
    Left = 0
    Top = 224
    Width = 257
    Height = 25
    Caption = '<-- ('#1059#1088#1086#1074#1077#1085#1100' '#1074#1099#1096#1077') '#1085#1072#1078#1084#1072#1081#1090#1077' '#1089#1090#1088#1077#1083#1082#1091' '#1074#1083#1077#1074#1086
    TabOrder = 1
    OnClick = Button1Click
  end
  object Button2: TButton
    Left = 256
    Top = 224
    Width = 291
    Height = 25
    Caption = '('#1059#1088#1086#1074#1077#1085#1100' '#1085#1080#1078#1077') '#1085#1072#1078#1080#1084#1072#1081#1090#1077' '#1089#1090#1088#1077#1083#1082#1091' '#1074#1087#1088#1072#1074#1086' -->'
    TabOrder = 2
    OnClick = Button2Click
  end
  object DBGrid1: TDBGrid
    Left = 0
    Top = 391
    Width = 546
    Height = 269
    Align = alBottom
    DataSource = DataSource2
    TabOrder = 3
    TitleFont.Charset = DEFAULT_CHARSET
    TitleFont.Color = clWindowText
    TitleFont.Height = -11
    TitleFont.Name = 'MS Sans Serif'
    TitleFont.Style = []
  end
  object Button3: TButton
    Left = 0
    Top = 352
    Width = 513
    Height = 25
    Caption = 
      #1042#1099#1073#1077#1088#1077#1090#1077' '#1074' '#1085#1080#1078#1085#1077#1084' '#1089#1087#1080#1089#1082#1077' '#1101#1083#1077#1084#1077#1085#1090' '#1080' '#1085#1072#1078#1080#1084#1072#1081#1090#1077'  '#1082#1085#1086#1087#1082#1091' '#1076#1083#1103' '#1086#1090#1086#1073#1088#1072#1078 +
      #1077#1085#1080#1103' '#1076#1077#1088#1077#1074#1072' '#1085#1072#1074#1077#1088#1093#1091
    TabOrder = 4
    OnClick = Button3Click
  end
  object Button4: TButton
    Left = 136
    Top = 248
    Width = 209
    Height = 25
    Caption = #1044#1086#1073#1072#1074#1080#1090#1100' '#1101#1083#1077#1084#1077#1085#1090
    TabOrder = 5
    OnClick = Button4Click
  end
  object DataSource1: TDataSource
    DataSet = Table1
    Left = 112
    Top = 16
  end
  object Table1: TTable
    Active = True
    AfterScroll = Table1AfterScroll
    Filter = 'idparend=0'
    Filtered = True
    IndexName = 'ID'
    TableName = 'Ascar'
    TableType = ttDBase
    Left = 144
    Top = 16
  end
  object Table2: TTable
    Active = True
    AfterScroll = Table2AfterScroll
    IndexName = 'ID'
    TableName = 'Ascar'
    TableType = ttDBase
    Left = 48
    Top = 264
  end
  object DataSource2: TDataSource
    DataSet = Table2
    Left = 16
    Top = 264
  end
end
