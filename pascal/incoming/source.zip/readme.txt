**OXOTA3 
**v1.0

-Information

  Platform  : Dos
  Compiler  : BP7.0 (only!) 
  Target    : Protected Mode
  screen    : 640x480x16bit
  
-You need
  
  speed     : 100MHz
  RAM       : 2Mb
  Video Mem : 2Mb
  Vesa      : 1.2

-For work you also need Win98 or Win95 (Oxota don't work under XP, NT and 2000).
 Oxota3 also of course work from DOS, so if you have XP or NT you should 
 restart you computer up to DOS.


  I start writing my Oxota3 in april-may 2002. First - what the strange name "Oxota3".  
"OXOTA" in russian language mean hunt. And "3" - because before were 2 earler games:
"Oxota" and "Oxota2". They made using TP7.0. It was my first experiance of programming.

  In my game I use the graphic unit GX2.(visit page www.crossfire-designs.de)
It is really very good unit! So I want to said thanx to his writter Stefan Goehler.
Also I want said thank to Elman Igor, who gave me some ideas, helped me with some
images, and wrote some parts of source.

  And now about me. I'm 16. Live in Russia, Moscow. Now studing at 11th form in school.
My e-mail: shob_vas@mail.ru. May be some information and sources of "Oxota1","Oxota2" and 
latest versions of "Oxota3" you'll find at www.shobvas.narod.ru (now it is under 
construction :) ). In internet I use nick "shob_vas".

  If you want, you can find windows version of my game Oxota3. Those versions are absolutely 
same (versions for Dos and for Windows). Oxota3 for windows runs not only at Win98 and Win95, 
it works also at WinXP,WinNt,Win2000.

26.01.03

P.S. I'm sorry for my bad english. ;)