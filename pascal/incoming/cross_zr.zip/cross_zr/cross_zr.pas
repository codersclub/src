uses crt,m13h,dos;

type p = array[0..2] of double;
     f = array[0..2] of integer;
     model = record
       v,t:array[0..100]of p;
       f:array[0..100]of f;
       ang:f;
       orig:p;
       max_p,max_f:word;
     end;
     player = record
       ang:f;
       orig:p;
     end;
const
 getmaxx=320;
 getmaxy=200;
 M_pi=3.14159265358979323846;

var mmx,mmy,wx,wy,i,mx,my,lmouse,win_state:integer;
    buf:pointer;
    cr,zr:model;
    setuped:boolean;
    pl1_name,pl2_name:string;
    key:char;
    pl:PLAYER;
    ms:array[1..9]of byte;
    cs,sn:array[0..360]of double;
    mouse1,ply:boolean;
    next:byte;

procedure ptp(x,y:word;c:byte);begin
if(x>0)and(x<319)and(y>0)and(y<199)then begin
 asm
  les di,buf
  mov ax,y
  mov bx,320
  mul bx
  add ax,x
  mov di,ax
  mov al,c
  add es:[di],al
 end;
end;
end;

Function SignInt(X:Integer):Integer;
InLine($5A/ $B8/$00/$00/ $83/$FA/$00/ $74/$06/ $7F/$03/ $2D/$02/$00/ $40);

Procedure Lineh(X1,X2,Y:Integer;c:byte);Var L,u:Integer;Begin
 L:=Abs(X2-X1);
 If X2<X1 Then X1:=X2;
if c=transp then begin
  for u:=x1+1 to x1+l do ptp(u,y,10);
end else begin
  for u:=x1+1 to x1+l do put(u,y,c,seg(buf^));
end;
End;

Procedure Triangle(X1,Y1,X2,Y2,X3,Y3:Integer;cl:byte);
Type PEdge = ^TEdge;
     TEdge = Record YDir,CurX,YLen,CurY,StepX,ErrX,AddErrX,SubErrX,XDir:Integer;End;
Var Left,Right:PEdge;
 Function SetUpEdge(X1,Y1,X2,Y2:Integer;Var Edge:PEdge):Boolean;Var T,XLen:Integer;Begin
  XLen:=X2-X1;
  With Edge^ Do Begin YLen:=Y2-Y1;
   If YLen=0 Then Begin SetUpEdge:=False;Exit;End;
   If YLen<0 Then YDir:=-1 Else YDir:=1;
   YLen:=Abs(YLen);
   CurY:=Y1;
   CurX:=X1;
   StepX:=XLen Div YLen;
   If XLen>0 Then Begin XDir:=1;ErrX:=0;
   End Else Begin XDir:=-1;ErrX:=1-YLen;XLen:=-XLen;End;
   AddErrX:=XLen Mod YLen;
   SubErrX:=YLen;
  End;
  SetUpEdge:=True;
 End;
 Function ScanEdge(Var Edge:PEdge):Boolean;Begin
  With Edge^ Do Begin Dec(YLen);
   If YLen>-1 Then Begin
    Inc(CurY,YDir);
    Inc(CurX,StepX);
    Inc(ErrX,AddErrX);
    If ErrX>0 Then Begin Dec(ErrX,SubErrX);Inc(CurX,XDir);End;
    ScanEdge:=True;
   End Else ScanEdge:=False;
  End;
 End;
 Procedure RunScan(X1,Y1,X2,Y2,X3,Y3:Integer);Begin
  If SignInt(Y2-Y1)<>SignInt(Y3-Y1)Then Exit;
  If(Not SetUpEdge(X1,Y1,X2,Y2,Left))Or(Not SetUpEdge(X1,Y1,X3,Y3,Right))Then Begin Lineh(X2,X3,Y1,cl);Exit;End;
  Repeat Lineh(Left^.CurX,Right^.CurX,Left^.CurY,cl);
  Until(Not ScanEdge(Left))Or(Not ScanEdge(Right));
 End;
begin
 New(Left);New(Right);
  RunScan(X1,Y1,X2,Y2,X3,Y3);
  RunScan(X2,Y2,X1,Y1,X3,Y3);
  RunScan(X3,Y3,X1,Y1,X2,Y2);
 Dispose(Right);Dispose(Left);
End;

procedure fov(var v1:p;b:double);var vt:p;begin vt:=v1;
b:=b/(vt[2]+0.0001);v1[1]:=(b*vt[0])+100;v1[0]:=(b*vt[1])+160;end;

procedure norm(var ang:integer);begin ang:=ang mod 360;if ang<0 then inc(ang,360);end;

procedure tdcr(a:f;i:p;var o:p);begin
o[1]:=i[1]*cs[a[0]]-i[2]*sn[a[0]];o[2]:=i[1]*sn[a[0]]+i[2]*cs[a[0]];i[1]:=o[1];i[2]:=o[2];
o[0]:=i[0]*cs[a[1]]+i[2]*sn[a[1]];o[2]:=-i[0]*sn[a[1]]+i[2]*cs[a[1]];i[0]:=o[0];i[2]:=o[2];
o[0]:=i[0]*cs[a[2]]-i[1]*sn[a[2]];o[1]:=i[0]*sn[a[2]]+i[1]*cs[a[2]];i[0]:=o[0];i[1]:=o[1];
o[0]:=i[0];o[1]:=i[1];o[2]:=i[2];end;

function load(s:string;var md:model):boolean;var d:text;ii:longint;ts:string;c:char;begin
assign(d,s);{$I-}reset(d);{$I+}
with md do begin
 readln(d,max_p,max_f);dec(max_p);dec(max_f);
 for i:=0 to max_p do begin read(d,v[i][0],v[i][1],v[i][2]);end;
 for i:=0 to max_f do begin read(d,f[i][0],f[i][1],f[i][2]);end;
 close(d);
end;
end;

procedure draw(v1,v2,v3:p;cl:integer);var c:byte;begin
  c:=round((((v2[0]-v1[0])*(v3[1]-v1[1])-(v3[0]-v1[0])*(v2[1]-v1[1]))*90)/1000);
  inc(c,cl*64);
 if((((v2[0]-v1[0])*(v3[1]-v1[1])-(v3[0]-v1[0])*(v2[1]-v1[1])))>0)then begin
  triangle(round(v1[0]),round(v1[1]),round(v2[0]),round(v2[1]),round(v3[0]),round(v3[1]),c);
end;
end;

procedure draw2(v1,v2,v3:p;cl:integer);var c:byte;begin
 if((((v2[0]-v1[0])*(v3[1]-v1[1])-(v3[0]-v1[0])*(v2[1]-v1[1])))>0)then begin
  triangle(round(v1[0]),round(v1[1]),round(v2[0]),round(v2[1]),round(v3[0]),round(v3[1]),cl*60);
end;
end;

procedure draw_model(var md:model;ax,ay,cl,sz:integer);var i:integer;begin
 with md do begin
 inc(ang[0],1);inc(ang[1],1);inc(ang[2],1);
 norm(ang[0]);norm(ang[1]);norm(ang[2]);
 for i:=0 to max_p do begin
  tdcr(ang,v[i],t[i]);
   t[i][0]:=t[i][0]-(ax*80)+100;
   t[i][1]:=t[i][1]-(ay*140)+150;
   t[i][2]:=t[i][2]-sz;
  fov(t[i],150);
 end;
 for i:=0 to max_f do draw(t[f[i][0]],t[f[i][1]],t[f[i][2]],cl);
 end;
end;

procedure draw_model2(var md:model;ax,ay,cl,sz:integer);var i:integer;begin
 with md do begin
 inc(ang[0],1);inc(ang[1],1);inc(ang[2],1);
 norm(ang[0]);norm(ang[1]);norm(ang[2]);
 for i:=0 to max_p do begin
  tdcr(ang,v[i],t[i]);
   t[i][2]:=t[i][2]-sz;
  fov(t[i],100);
   t[i][0]:=t[i][0]+ay;
   t[i][1]:=t[i][1]+ax;
 end;
 for i:=0 to max_f do draw2(t[f[i][0]],t[f[i][1]],t[f[i][2]],cl);
 end;
end;

procedure en_line(x,y,xx:integer);var px,py,l,clv,j,c1,c2:integer;begin
 px:=x;py:=y;clv:=10;
 if xx<x then clv:=-10;
 c1:=254;c2:=255;
for j:=0 to 1 do begin x:=px;y:=py;
 repeat l:=random(10);l:=l-random(10);l:=l+y;inc(x,clv);
  line(x,y,x+clv,l,c1,seg(buf^));line(x-1,y-1,x+clv-1,l-1,c2,seg(buf^));y:=l;
  if xx>px then begin
   if x>xx then break;
  end else
   if x<xx then break;
 until false;
end;
end;

procedure game;var m,x,y:byte;lp:boolean;begin
 for m:=1 to 9 do begin
  x:=(m mod 3);
  y:=(m div 3);
  if(x=3)or(x=0)then dec(y);
  if(ino(mx,my,5+(y*100),(x*60),(y*100)+105,(x*60)+60))and(next<>1)then begin
   box(5+(y*100),(x*60),(y*100)+105,(x*60)+60,10,seg(buf^),0);
   if(mouse1)and(ms[m]=0)and(lp<>ply)then begin
    if ply then ms[m]:=1 else ms[m]:=2;
    lp:=ply;ply:=not(ply);
    en_line(mx,my,0);en_line(mx,my,320);
   end;
  end;
   if(ms[m]=1)then draw_model(cr,x,y,ms[m],250);
   if(ms[m]=2)then draw_model(zr,x,y,ms[m],250);
    if(ms[m]=3)then draw_model(cr,x,y,3,250);
    if(ms[m]=4)then draw_model(zr,x,y,3,250);
 end;
 if(ms[1]=ms[2])and(ms[2]=ms[3])and(ms[1] in [1,2])then begin win_state:=ms[1];inc(ms[1],2);ms[2]:=ms[1];ms[3]:=ms[2];end;
 if(ms[4]=ms[5])and(ms[5]=ms[6])and(ms[4] in [1,2])then begin win_state:=ms[4];inc(ms[4],2);ms[5]:=ms[4];ms[6]:=ms[5];end;
 if(ms[7]=ms[8])and(ms[8]=ms[9])and(ms[7] in [1,2])then begin win_state:=ms[7];inc(ms[7],2);ms[8]:=ms[7];ms[9]:=ms[8];end;
  if(ms[1]=ms[4])and(ms[4]=ms[7])and(ms[1] in [1,2])then begin win_state:=ms[1];inc(ms[1],2);ms[4]:=ms[1];ms[7]:=ms[4];end;
   if(ms[2]=ms[5])and(ms[5]=ms[8])and(ms[2] in [1,2])then begin win_state:=ms[2];inc(ms[2],2);ms[5]:=ms[2];ms[8]:=ms[5];end;
    if(ms[3]=ms[6])and(ms[6]=ms[9])and(ms[3] in [1,2])then begin win_state:=ms[3];inc(ms[3],2);ms[6]:=ms[3];ms[9]:=ms[6];end;
 if(ms[3]=ms[4])and(ms[4]=ms[8])and(ms[3] in [1,2])then begin win_state:=ms[3];inc(ms[3],2);ms[4]:=ms[3];ms[8]:=ms[4];end;
 if(ms[2]=ms[4])and(ms[4]=ms[9])and(ms[2] in [1,2])then begin win_state:=ms[2];inc(ms[2],2);ms[4]:=ms[2];ms[9]:=ms[4];end;
 for i:=1 to 9 do begin if(ms[i]=0)then begin dec(i);break;end;end;
 if(i=9)and(win_state=-1)then win_state:=0;
 if(mouse=2)anD(win_state<>-1)then next:=2;
 if next=1 then outtextxy(150,190,'press mouse2 to continue...',63,seg(buf^));
end;
var det:byte;

procedure setup;begin
 draw_model(cr,0,0,1,300);
 draw_model(zr,1,0,2,300);
 case det of
  1:box(50,120,100,130,50,seg(buf^),1);
  2:box(120,120,170,130,50,seg(buf^),1);
  3:box(190,120,240,130,50,seg(buf^),1);
 end;
 if(mouse1)and(ino(mx,my,50,120,100,130))then begin det:=1;load('cross_lo.md',cr);load('zero_lo.md',zr);end;
 if(mouse1)and(ino(mx,my,120,120,170,130))then begin det:=2;load('cross.md',cr);load('zero.md',zr);end;
 if(mouse1)and(ino(mx,my,190,120,240,130))then begin det:=3;load('cross_hi.md',cr);load('zero_hi.md',zr);end;
 box(50,120,100,130,100,seg(buf^),0);outtextxy(60,123,'low',100,seg(buf^));
 box(120,120,170,130,100,seg(buf^),0);outtextxy(130,123,'med',100,seg(buf^));
 box(190,120,240,130,100,seg(buf^),0);outtextxy(200,123,'hi',100,seg(buf^));
 if ino(mx,my,150,48,250,57)then begin
   if(length(pl1_name)<18)and(key>='a')and(key<='z')then pl1_name:=pl1_name+key;
   if(key=#8)then delete(pl1_name,length(pl1_name),1);
   if(key=#13)or(mouse=2)then begin if length(pl1_name)=0 then pl1_name:='noname1';end;
 box(150,48,250,57,100,seg(buf^),0);end;
 if ino(mx,my,150,98,250,107)then begin
   if(length(pl2_name)<18)and(key>='a')and(key<='z')then pl2_name:=pl2_name+key;
   if(key=#8)then delete(pl2_name,length(pl2_name),1);
   if(key=#13)or(mouse=2)then begin if length(pl2_name)=0 then pl2_name:='noname2';end;
 box(150,98,250,107,126+60,seg(buf^),0);end;
 outtextxy(150,50,pl1_name,126,seg(buf^));
 outtextxy(150,100,pl2_name,126+64,seg(buf^));
 if ino(mx,my,50,150,270,190)then begin
  en_line(mx+15,my,0);
  en_line(mx+10,my,320);
  if mouse1 then begin setuped:=true;if random(100)<50 then ply:=not(ply);end;
 end;
end;

procedure win;begin
 case win_state of
  1:begin
    draw_model2(cr,1,1,2,60);
    outtextxy(150,50,pl1_name+' you win',63,seg(buf^));
    end;
  2:begin
    draw_model2(zr,1,1,3,60);
    outtextxy(150,50,pl2_name+' you win',63,seg(buf^));
    end;
  else outtextxy(150,80,'no winers',63,seg(buf^));
 end;
 if mouse1 then begin win_state:=-1;setuped:=false;for i:=1 to 9 do ms[i]:=0;next:=0;end;
 outtextxy(150,190,'press mouse1 to continue...',63,seg(buf^));
end;

{$i timer.mod}

begin init13h;randomize;
 pl1_name:='noname1';
 pl2_name:='noname2';
 setuped:=false;
 win_state:=-1;
 for i:=0 to 360 do begin sn[i]:=sin(i*(m_pi/180));cs[i]:=cos(i*(m_pi/180));end;
 getmem(buf,320*200);cls(0,seg(buf^));
 load('cross.md',cr);
 load('zero.md',zr);
 for i:=0 to 63 do setrgb(i,i,i,0);
 for i:=64 to 127 do setrgb(i,i,0,0);
 for i:=128 to 190 do setrgb(i,0,0,i);
 for i:=192 to 255 do setrgb(i,0,i,0);
 setrgb(255,255,255,255);
 setrgb(254,0,0,255);
 next:=0;
 if random(100)<50 then ply:=not(ply);
 init_timer;
 det:=2;
 repeat key:=#0;if keypressed then key:=readkey;mouse_coords(mx,my);
  if(lmouse=1)and(mouse=0)then mouse1:=true else mouse1:=false;
  if mouse=1 then lmouse:=1;if mouse=0 then lmouse:=0;
 if((setuped)and(win_state=-1))or(next=1)then game;
 if(not setuped)and(win_state=-1)and(next=0)then setup;
 if(win_state<>-1)and(next=0)then next:=1;
 if(win_state<>-1)and(next=2)then win;
 if ply then draw_model2(cr,my-100,mx-150,65*2,500) else draw_model2(zr,my-100,mx-150,65*3,500);
  refresh_timer;
  outtextxy(270,10,is(fps),62,seg(buf^));
  outbufer(seg(buf^));cls(0,seg(buf^));
 until key=#27;
 close_timer;
 freemem(buf,320*200);
close13h;halt;end.