README TO GAME OXOTA3.

Hello!
This game made on BP7.0 at Protected Mode and under Dos. (This game'll compile only on BP7!)
Screen Sizes : 640x480x16.
Lot's of thanks for Stefan Goehler, his graphic unit GX2 I used in my game.
The GX2 Unit and some other units you'll find at www.crossfire-designs.de.

And now some information if you'll interest in sourses of this game.
Files:
  o3.pas       		- main programm
  o3unit.pas   		- main unit 
  o3grunit.pas 		- graphic unit  (use only for load images) 
  unitmenu.pas 		- menu unit
  keylib.pas   		- keyboard unit 
  Other units  		- units of Stefan Goehler. (only tpp files)

  mapmake*.pas 		- programm wich makes \maps\map*.ma2 

  And files \maps\*.ma1 - pcx files (if you'll change *.ma1 to *.pcx you see)

This made By Slobodov Gleb.
In the internet I live wis nick 'shob_vas'.
My adress :
  Russia, Moskow
E-Mail    :
  shob_vas@aport2000.ru
May be some information about me and this game you'll find on site www.shob_vas.narod.ru,
but now this site is under costruction.

24.08.2002

P.S. If you execute game from Dos (or emulation of Dos) first change dir to directory of 
  game (cd c:\*\..\o3\).