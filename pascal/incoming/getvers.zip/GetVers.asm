; ml /c /coff GetVers.asm
; link /subsystem:windows GetVers.obj

.586P
.MODEL Flat,StdCall
OPTION CASEMAP:NONE

INCLUDE         WINDOWS.INC
INCLUDE         KERNEL32.INC
INCLUDE         USER32.INC
INCLUDELIB      KERNEL32.LIB
INCLUDELIB      USER32.LIB

.DATA

String          db      11 dup (0)
Header          db      'GetVersion',0

.CODE

Start:

                invoke  GetVersion
                mov     ecx,10
                mov     edi,(offset String)+(sizeof String)-2
                std
@@Repeat:       xor     edx,edx
                div     ecx
                xchg    eax,edx
                add     al,'0'
                stosb
                xchg    eax,edx
                or      eax,eax
                jnz     @@Repeat
                inc     edi
                cld
                invoke  MessageBox, 0, edi, addr Header, MB_OK or MB_ICONINFORMATION or MB_TASKMODAL
                invoke  ExitProcess, NULL

END             Start
