;Sorry for my "pascal" style of programmin'... it's just my first intro...
.model tiny
.386
 locals %%
.code
 org 100h
begin:
 ;set_vga_mode
 mov al,13h
 int 10h
 mov sp,program_size+psp_size+stack_size
 mov ah,4ah
 mov bx,(program_size+psp_size+stack_size) shr 4+1
 int 21h
 ;create buffers
 mov cl,4
 mov di,offset buffer_video
 mov bx,buffer_size shr 4+1
 %%create_buffers:
  mov ah,48h
  int 21h
  push cs
  pop es
  stosw
  pusha
  mov es,ax
  xor ax,ax
  xor di,di
  mov ch,7dh
  rep stosw
  popa
 loop %%create_buffers
 ;get_font_ptr
 mov ax,1130h
 mov bh,03h
 xor bl,bl
 int 10h
 mov word ptr font_addr,bp
 mov word ptr font_addr+2,es
 ;set_fire_palette
 mov bl,max_color
 mov bh,63
 mov cl,63
 mov ch,63
 %%set_1:
  dec bl
  mov al,bl
  and al,1
  jnz %%next1
   dec cl
   dec bh
  %%next1:
  call screen_set_rgb_palette
  cmp bl,2*63
 jnz %%set_1
 %%set_2:
  dec bl
  mov al,bl
  and al,1
  jnz %%next2
   dec ch
  %%next2:
  call screen_set_rgb_palette
  test bl,bl
 jnz %%set_2
 mov bl,10
 xor di,di
 ;for ret
 push di
 %%repeat:
  dec bx
  jnz %%not_change_string
   add di,text_string_size
   cmp di,last_string
   jl %%not_last_string
    xor di,di
   %%not_last_string:
   mov bl,text_show_delay
  %%not_change_string:
  push bx
  push di
  push cs
  pop ds
  mov es,buffer_first
  cmp exit,0
  jnz %%pass
   mov si,offset string
   add si,di
   mov cx,text_x
   mov dx,text_y
   mov ah,text_color
   mov bl,text_scale
   call buffer_write_string
   push es
   pop ds
   xor edx,edx
   mov cx,buffer_size-320*2
   ;random
   mov ax,cs:seed
   add ax,1234
   xor al,ah
   add ax,4321
   xor al,ah
   mov cs:seed,ax
   xor dx,dx
   div cx
   mov byte ptr [edx+320],255
  %%pass:
  push es
  pop ds
  mov es,cs:buffer_second
  mov si,320
  %%water:
   xor ah,ah
   mov al,[si+1]
   mov bx,ax
   mov al,[si-1]
   add bx,ax
   mov al,[si+320]
   add bx,ax
   mov al,[si-320]
   add ax,bx
   shr ax,1
   mov bl,byte ptr es:[si]
   xor bh,bh
   sub ax,bx
   jns %%move
    xor ax,ax
   %%move:
   mov byte ptr es:[si],al
   inc si
   cmp si,64000-320
  jnz %%water
  mov es,cs:buffer_video
  call buffer_move
  push cs
  pop ds
  cmp exit,0
  jnz %%pass_write
   pop di
   mov si,offset string
   add si,di
   mov cx,text_x
   mov dx,text_y
   xor ah,ah
   mov bl,text_scale
   call buffer_write_string
   push di
  %%pass_write:
  push es
  pop ds
  ;just for delay...
  mov cl,blur_count
  %%blur:
   mov di,max_x
   xor ah,ah
   %%b:
    mov al,[di+max_x]
    mov bx,ax
    mov al,[di-max_x]
    add bx,ax
    mov al,[di+1]
    add bx,ax
    mov al,[di-1]
    add bx,ax
    shr bx,2
    mov al,[di]
    add bx,ax
    shr bx,1
    mov [di],bl
    inc di
    cmp di,buffer_size-321
   jnz %%b
  loop %%blur
  ;wait_retrace
  mov dx,3dah
  %%v1:
   in al,dx
   test al,8
  jz %%v1
  %%v2:
   in al,dx
   test al,8
  jnz %%v2
  mov ds,cs:buffer_video
  push 0a000h
  pop es
  call buffer_move
  push cs
  pop ds
  mov ax,buffer_first
  mov bx,buffer_second
  mov buffer_first,bx
  mov buffer_second,ax
  pop di
  pop bx
  cmp exit,0ffh
  jnz %%not_exit
   dec exit_delay
   jnz %%repeat
   jmp short %%real_exit
  %%not_exit:
  in al,60h
  dec al
  jnz %%repeat
   mov exit,0ffh
  jmp %%repeat
 %%real_exit:
 mov ax,0003h
 int 10h
 screen_set_rgb_palette proc near ;bl,bh,cl,ch<-color,rgb.
  pusha
  mov dx,3c8h
  mov al,bl
  out dx,al
  inc dx
  mov al,bh
  out dx,al
  mov al,cl
  out dx,al
  mov al,ch
  out dx,al
  popa
  retn
 screen_set_rgb_palette endp
 buffer_move proc near;ds,es<-source_buffer,dest_buffer
  xor si,si
  xor di,di
  mov ch,7dh
  rep movsw
  retn
 buffer_move endp
 buffer_write_string proc near;es<-buffer,ds:si<-string addres,ah<-color.
  pusha
  %%write:
   lodsb
   test al,al
   jz %%exit
   push bx
   pusha
   push ds
   lds si,font_addr
   push ax
   xor ah,ah
   shl ax,3
   add si,ax
   xor di,di
   add di,cx
   mov ax,dx
   shl ax,8
   add di,ax
   mov ax,dx
   shl ax,6
   add di,ax
   pop ax
   mov dl,bl
   mov bh,bios_font_size
   xor dh,dh
   %%draw_char:
    lodsb
    mov bl,bios_font_size
    %%draw_line:
     shl al,1
     inc ah
     jnc %%next
      push ax
      push di
      xchg ah,al
      mov ah,dl
      %%draw:
       mov cl,dl
       xor ch,ch
       rep stosb
       add di,max_x
       sub di,dx
       dec ah
      jnz %%draw
      pop di
      pop ax
     %%next:
     add di,dx
     dec bl
    jnz %%draw_line
    push dx
    %%l:
     add di,max_x-bios_font_size
     dec dl
    jnz %%l
    pop dx
    dec bh
   jnz %%draw_char
   pop ds
   popa
   pop bx
   push bx
   %%l2:
    add cx,bios_font_size
    dec bl
   jnz %%l2
   pop bx
  jmp short %%write
  %%exit:
  popa
  retn
 buffer_write_string endp
 blur_count equ 5
 text_color equ 255-30*text_scale
 text_show_delay equ 100
 text_scale equ 3
 text_x equ (max_x-(text_string_size-1)*text_scale*bios_font_size)/2+5
 text_y equ 90
 max_x equ 320
 max_y equ 200
 bios_font_size equ 8
 psp_size equ 100h
 stack_size equ 100h
 buffer_size equ 320*200
 video_memory equ 0a000h
 max_color equ 252
 text_string_size equ 14
 string db '             ',0
        db '    Intro    ',0
        db '     by      ',0
        db 'Bart Simpson ',0
        db '   email :   ',0
        db ' bartsimpson ',0
        db '@simpsons.com',0
        db '   site :    ',0
        db '     www     ',0
        db '.bartsimpson ',0
        db '   .nm.ru    ',0
        db '             ',0
 last_string equ $-offset string
 exit_delay db 100
 exit db 0
 buffer_video dw ?
 buffer_first dw ?
 buffer_second dw ?
 buffer_text dw ?
 seed dw ?
 font_addr dd ?
 program_size equ $-offset begin
end begin
