VERSION 5.00
Begin VB.Form LOGINUSER 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "��������?"
   ClientHeight    =   2010
   ClientLeft      =   3840
   ClientTop       =   3675
   ClientWidth     =   3525
   Icon            =   "LOGIN.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2010
   ScaleWidth      =   3525
   StartUpPosition =   1  'CenterOwner
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   120
      TabIndex        =   6
      Top             =   1080
      Width           =   1455
   End
   Begin VB.CommandButton Command2 
      Cancel          =   -1  'True
      Caption         =   "������"
      Height          =   375
      Left            =   1800
      TabIndex        =   3
      Top             =   1560
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��!"
      Default         =   -1  'True
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   1560
      Width           =   1575
   End
   Begin VB.TextBox Text2 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   120
      PasswordChar    =   "*"
      TabIndex        =   1
      Top             =   600
      Width           =   1455
   End
   Begin VB.TextBox Text1 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1455
   End
   Begin VB.Label Label3 
      Caption         =   "IP ������� "
      Height          =   255
      Left            =   1680
      TabIndex        =   7
      Top             =   1080
      Width           =   1575
   End
   Begin VB.Label Label2 
      Caption         =   "� ������ �� ������!"
      Height          =   255
      Left            =   1680
      TabIndex        =   5
      Top             =   600
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "����� UID!"
      Height          =   255
      Left            =   1680
      TabIndex        =   4
      Top             =   120
      Width           =   1695
   End
End
Attribute VB_Name = "LOGINUSER"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()

  ' �������������� CMD_LOGIN
  If Text2.Text = "" Then
    MsgBox "�� ������ ������!", vbCritical, "Error!!!"
    Text2.SetFocus
    Exit Sub
  End If
  SEND_CMD_LOGOFF
  If (Text3.Text <> IPS) Or (Text1.Text <> UID) Then
    IPS = Text3.Text
    UID = Text1.Text
    Open App.Path & "\uid" For Output As #1
    Write #1, UID; IPS
    Close #1
  End If
  ' �������� ���
  NICK = Text1.Text
  'SEND_CMD_LOGOFF
  SEND_CMD_LOGIN "ClntVB2", Text1.Text, Text2.Text
End Sub

Private Sub Command2_Click()
  Unload Me
End Sub

Private Sub Form_Load()
  Text1.Text = UID
  Text3.Text = IPS
End Sub

Private Sub Text1_KeyPress(KeyAscii As Integer)
If ((KeyAscii < 48) Or (KeyAscii > 57)) And (KeyAscii <> 8) Then
    KeyAscii = 0
  End If
End Sub

