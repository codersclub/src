VERSION 5.00
Begin VB.Form REGISTER 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "����������� ������ �������"
   ClientHeight    =   2025
   ClientLeft      =   3630
   ClientTop       =   3465
   ClientWidth     =   3795
   Icon            =   "REGISTER.frx":0000
   LinkTopic       =   "Form2"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   2025
   ScaleWidth      =   3795
   Begin VB.CommandButton Command2 
      Cancel          =   -1  'True
      Caption         =   "������"
      Height          =   375
      Left            =   2040
      TabIndex        =   6
      Top             =   1560
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��"
      Default         =   -1  'True
      Height          =   375
      Left            =   120
      TabIndex        =   4
      Top             =   1560
      Width           =   1575
   End
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   120
      TabIndex        =   2
      Text            =   "127.0.0.1"
      Top             =   1080
      Width           =   1335
   End
   Begin VB.TextBox Text2 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   120
      PasswordChar    =   "*"
      TabIndex        =   1
      Top             =   600
      Width           =   1335
   End
   Begin VB.TextBox Text1 
      Height          =   285
      IMEMode         =   3  'DISABLE
      Left            =   120
      PasswordChar    =   "*"
      TabIndex        =   0
      Top             =   120
      Width           =   1335
   End
   Begin VB.Label Label3 
      Caption         =   "������� IP-����� �������"
      Height          =   255
      Left            =   1560
      TabIndex        =   7
      Top             =   1080
      Width           =   2055
   End
   Begin VB.Label Label2 
      Caption         =   "����������� ���� ������"
      Height          =   255
      Left            =   1560
      TabIndex        =   5
      Top             =   600
      Width           =   2055
   End
   Begin VB.Label Label1 
      Caption         =   "������� ������"
      Height          =   255
      Left            =   1560
      TabIndex        =   3
      Top             =   120
      Width           =   2055
   End
End
Attribute VB_Name = "REGISTER"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
  If StrComp(Text1.Text, Text2.Text) <> 0 Then
    Text1.Text = ""
    Text2.Text = ""
    MsgBox "����������� ������ � �������������!", vbCritical, "Warning!"
    Text1.SetFocus
  Else
    IPS = Text3.Text
    MAIN.WS.RemoteHost = IPS
    If MAIN.WS.State = 0 Then MAIN.WS.Connect
    SEND_CMD_REGISTER Text1.Text
  End If
End Sub

Private Sub Command2_Click()
  Unload Me
End Sub

