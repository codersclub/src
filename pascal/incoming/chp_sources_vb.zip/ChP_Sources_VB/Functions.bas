Attribute VB_Name = "Functions"
Public Sub LongToByte(a As Long, b() As Byte, FromByte As Integer)
  Dim i As Integer
  Dim ost As Long
  ost = a
  b(FromByte) = 0
  b(FromByte + 1) = 0
  b(FromByte + 2) = 0
  b(FromByte + 3) = 0
  For i = 30 To 24 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 3) = b(FromByte + 3) + (2 ^ i) / 16777216
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 23 To 16 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 2) = b(FromByte + 2) + (2 ^ i) / 65536
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 15 To 8 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 1) = b(FromByte + 1) + (2 ^ i) / 256
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 7 To 0 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte) = b(FromByte) + (2 ^ i)
      ost = ost Mod (2 ^ i)
    End If
  Next i
End Sub

Public Sub ByteToLong(b() As Byte, a As Long, FromByte As Integer)
  Dim i As Integer
  Dim lng As Long
  a = 0
  lng = 0
  lng = (b(FromByte + 3) * 16777216)
  lng = lng + (b(FromByte + 2) * 65536)
  ' �����-�� �������� ������������ :(
  lng = lng + (b(FromByte + 1) * 128)
  lng = lng + (b(FromByte + 1) * 128)
  '
  lng = lng + b(FromByte)
  a = lng
End Sub

Public Sub StringToByte(b() As Byte, str As String, FromByte As Integer)
  Dim i As Integer
  If Len(str) > 1024 Then Exit Sub
  For i = 0 To Len(str) - 1
    b(FromByte + i) = Asc(Mid(str, i + 1, 1))
  Next i
  b(FromByte + Len(str)) = 0
End Sub

Public Sub ByteToString(strng As String, b() As Byte, FromByte As Integer)
  Dim i As Integer
  i = FromByte
  While b(i) <> 0
    strng = strng & Chr(b(i))
    i = i + 1
  Wend
End Sub


Public Sub SEND_CMD_INFO()
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_INFO
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_INFO(server_name As String, server_admin As String, server_adm_mail As String, motd As String)
  ByteToString server_name, Repacket(), 24
  ByteToString server_admin, Repacket(), 74
  ByteToString server_adm_mail, Repacket(), 124
  ByteToString motd, Repacket(), 174
  Erase Repacket
End Sub

Public Sub SEND_CMD_LOGIN(login As String, useruid As Long, psswrd As String)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_LOGIN
  LongToByte useruid, packet(), 4
  LongToByte 0, packet(), 8
  StringToByte packet(), login, 12
  StringToByte packet(), psswrd, 22
  packet(32) = STAT_ONLINE
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_LOGIN(ok As Byte, reason As String)
  ok = Repacket(32)
  ByteToString reason, Repacket(), 33
  Erase Repacket
End Sub

Public Sub SEND_CMD_STATUS(status As Byte)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_STATUS
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  packet(12) = status
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_STATUS(status As Byte)
  status = Repacket(12)
  Erase Repacket
End Sub

Public Sub SEND_CMD_REGISTER(passwrd As String)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_REGISTER
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  StringToByte packet(), passwrd, 12
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_REGISTER(ok As Boolean, uidreceive As Long)
  ByteToLong Repacket(), uidreceive, 8
  If uidreceive = 0 Then
    ok = False
  Else
    ok = True
  End If
  Erase Repacket
End Sub

Public Sub SEND_CMD_GETSTATUS(useruid As Long)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_GETSTATUS
  LongToByte UID, packet(), 4
  LongToByte useruid, packet(), 8
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_GETSTATUS(status As Byte)
  status = Repacket(12)
End Sub

Public Sub SEND_CMD_SETINFO(useruid As Long, status As Byte, name As String, _
                            email As String, MALE_ As Boolean, COUNTRY_ As String, _
                            CITY_ As String, ABOUT_ As String)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_SETINFO
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  LongToByte UID, packet(), 12
  packet(16) = status
  StringToByte packet(), name, 17
  StringToByte packet(), email, 42
  StringToByte packet(), COUNTRY_, 74
  StringToByte packet(), CITY_, 89
  StringToByte packet(), ABOUT_, 104
  MAIN.WS.SendData packet
End Sub

Public Sub SEND_CMD_GETINFO(uiduser As Long)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_GETINFO
  LongToByte UID, packet(), 4
  LongToByte uiduser, packet(), 8
  LongToByte uiduser, packet(), 12
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_GETINFO(useruid As Long, status As Byte, name As String, _
                            email As String, MALE_ As Boolean, COUNTRY_ As String, _
                            CITY_ As String, ABOUTUSER_ As String)
                            
  ByteToLong Repacket(), useruid, 4
  status = Repacket(16)
  ByteToString name, Repacket(), 17
  ByteToString email, Repacket(), 42
  ByteToString COUNTRY_, Repacket(), 74
  ByteToString CITY_, Repacket(), 89
  ByteToString ABOUTUSER_, Repacket(), 104
  Erase Repacket
End Sub

Public Sub SEND_CMD_MSG(touseruid As Long, msg As String)
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_MSG
  LongToByte UID, packet(), 4
  LongToByte touseruid, packet(), 8
  StringToByte packet(), msg, 12
  MAIN.WS.SendData packet
End Sub

Public Sub GET_RPL_MSG(fromuseruid As Long, msg As String)
  ByteToLong Repacket(), fromuseruid, 4
  ByteToString msg, Repacket(), 12
  Erase Repacket
End Sub

Public Sub SEND_CMD_PING()
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_PING
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  MAIN.WS.SendData packet
End Sub

Public Sub SEND_CMD_LOGOFF()
  Erase packet
  packet(0) = CONSTVERSION
  packet(1) = CMD_LOGOUT
  LongToByte UID, packet(), 4
  LongToByte 0, packet(), 8
  MAIN.WS.SendData packet
End Sub











