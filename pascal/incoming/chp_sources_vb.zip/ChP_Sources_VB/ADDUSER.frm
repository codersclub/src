VERSION 5.00
Begin VB.Form ADDUSER 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "���������� �����������"
   ClientHeight    =   1560
   ClientLeft      =   4935
   ClientTop       =   4320
   ClientWidth     =   3615
   Icon            =   "ADDUSER.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1560
   ScaleWidth      =   3615
   Begin VB.CommandButton Command2 
      Cancel          =   -1  'True
      Caption         =   "������"
      Height          =   375
      Left            =   1920
      TabIndex        =   3
      Top             =   1080
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "��"
      Default         =   -1  'True
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   1080
      Width           =   1575
   End
   Begin VB.TextBox Text2 
      BeginProperty DataFormat 
         Type            =   0
         Format          =   "0"
         HaveTrueFalseNull=   0
         FirstDayOfWeek  =   0
         FirstWeekOfYear =   0
         LCID            =   1049
         SubFormatType   =   0
      EndProperty
      Height          =   285
      Left            =   120
      TabIndex        =   1
      Top             =   600
      Width           =   1575
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   120
      TabIndex        =   0
      Top             =   120
      Width           =   1575
   End
   Begin VB.Label Label2 
      Caption         =   "UID �����������"
      Height          =   255
      Left            =   1800
      TabIndex        =   5
      Top             =   600
      Width           =   1815
   End
   Begin VB.Label Label1 
      Caption         =   "��� �����������"
      Height          =   255
      Left            =   1800
      TabIndex        =   4
      Top             =   120
      Width           =   1695
   End
End
Attribute VB_Name = "ADDUSER"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
If Not USERRENAME Then
  If (Text1.Text = "") Or (Text2.Text = "") Then
    MsgBox "����������� ��� ����!", vbExclamation, "������!"
    Exit Sub
  End If
  
  ' ������ ������ ����������� � ������
  For i = 1 To MAIN.TV.Nodes.Count
    If MAIN.TV.Nodes.Item(i).Tag = Text2.Text Then
      MsgBox "���������� � UID " & Text2.Text & " ��� ������ � ������!", vbCritical, "������!"
      Exit Sub
    End If
  Next i
  MAIN.TV.Nodes.Add , , , Text1.Text, "keyOFFLINE"
  MAIN.TV.Nodes.Item(MAIN.TV.Nodes.Count).Tag = Text2.Text
  ' ������ ����������� � ����
  Dim NF As Integer
  NF = FreeFile
  Open App.Path & "\contact" For Append As #NF
  Write #NF, Text1.Text, Val(Text2.Text)
  Close #NF
  
  SEND_CMD_GETSTATUS Val(Text2.Text)
  Unload Me
Else
  For i = 1 To MAIN.TV.Nodes.Count
    If MAIN.TV.Nodes.Item(i).Tag = Text2.Text Then
      MAIN.TV.Nodes.Item(i).Text = Text1.Text
    End If
  Next i
  Unload Me
End If
End Sub

Private Sub Command2_Click()
  Unload Me
End Sub

Private Sub Text2_KeyPress(KeyAscii As Integer)
  If ((KeyAscii < 48) Or (KeyAscii > 57)) And (KeyAscii <> 8) Then
    KeyAscii = 0
  End If
End Sub
