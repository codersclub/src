VERSION 5.00
Begin VB.Form ABOUT 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "� ���������..."
   ClientHeight    =   1680
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   4680
   Icon            =   "ABOUT.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   1680
   ScaleWidth      =   4680
   StartUpPosition =   2  'CenterScreen
   Begin VB.CommandButton Command1 
      Caption         =   "��"
      Height          =   375
      Left            =   120
      TabIndex        =   1
      Top             =   1200
      Width           =   4455
   End
   Begin VB.Label Label2 
      Caption         =   "����������� �������-�����������!"
      ForeColor       =   &H80000018&
      Height          =   255
      Left            =   1080
      TabIndex        =   2
      Top             =   840
      Width           =   2895
   End
   Begin VB.Label Label1 
      Caption         =   $"ABOUT.frx":0442
      Height          =   615
      Left            =   720
      TabIndex        =   0
      Top             =   120
      Width           =   3855
      WordWrap        =   -1  'True
   End
   Begin VB.Image Image1 
      Height          =   480
      Left            =   120
      Picture         =   "ABOUT.frx":04F1
      Top             =   120
      Width           =   480
   End
End
Attribute VB_Name = "ABOUT"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
  Unload Me
End Sub
