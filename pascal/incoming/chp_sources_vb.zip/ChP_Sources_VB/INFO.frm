VERSION 5.00
Begin VB.Form INFO 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "����"
   ClientHeight    =   3495
   ClientLeft      =   5160
   ClientTop       =   3390
   ClientWidth     =   4680
   Icon            =   "INFO.frx":0000
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3495
   ScaleWidth      =   4680
   Begin VB.CommandButton Command2 
      Caption         =   "��"
      Default         =   -1  'True
      Height          =   375
      Left            =   2760
      TabIndex        =   17
      Top             =   3000
      Width           =   1815
   End
   Begin VB.CommandButton Command1 
      Cancel          =   -1  'True
      Caption         =   "������"
      Height          =   375
      Left            =   840
      TabIndex        =   16
      Top             =   3000
      Width           =   1815
   End
   Begin VB.TextBox Text5 
      Height          =   885
      Left            =   2160
      MaxLength       =   126
      MultiLine       =   -1  'True
      TabIndex        =   7
      Top             =   1920
      Width           =   2415
   End
   Begin VB.Frame Frame1 
      BorderStyle     =   0  'None
      Height          =   255
      Left            =   2160
      TabIndex        =   4
      Top             =   840
      Width           =   2415
      Begin VB.OptionButton Option2 
         Caption         =   "Option2"
         Height          =   195
         Left            =   1320
         TabIndex        =   6
         Top             =   0
         Width           =   255
      End
      Begin VB.OptionButton Option1 
         Caption         =   "Option1"
         Height          =   195
         Left            =   120
         TabIndex        =   5
         Top             =   0
         Width           =   255
      End
      Begin VB.Label Label2 
         Caption         =   "���"
         Height          =   255
         Left            =   1560
         TabIndex        =   9
         Top             =   0
         Width           =   495
      End
      Begin VB.Label Label1 
         Caption         =   "M��"
         Height          =   255
         Left            =   360
         TabIndex        =   8
         Top             =   0
         Width           =   735
      End
   End
   Begin VB.TextBox Text4 
      Height          =   285
      Left            =   2160
      MaxLength       =   14
      TabIndex        =   3
      Top             =   1560
      Width           =   2415
   End
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   2160
      MaxLength       =   14
      TabIndex        =   2
      Top             =   1200
      Width           =   2415
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   2160
      MaxLength       =   29
      TabIndex        =   1
      Top             =   480
      Width           =   2415
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   2160
      MaxLength       =   24
      TabIndex        =   0
      Top             =   120
      Width           =   2415
   End
   Begin VB.Label Label8 
      Alignment       =   1  'Right Justify
      Caption         =   "��������� ���� � ����"
      Height          =   255
      Left            =   120
      TabIndex        =   15
      Top             =   1920
      Width           =   1935
   End
   Begin VB.Label Label7 
      Alignment       =   1  'Right Justify
      Caption         =   "�����"
      Height          =   255
      Left            =   120
      TabIndex        =   14
      Top             =   1560
      Width           =   1935
   End
   Begin VB.Label Label6 
      Alignment       =   1  'Right Justify
      Caption         =   "������"
      Height          =   255
      Left            =   120
      TabIndex        =   13
      Top             =   1200
      Width           =   1935
   End
   Begin VB.Label Label5 
      Alignment       =   1  'Right Justify
      Caption         =   "���"
      Height          =   255
      Left            =   120
      TabIndex        =   12
      Top             =   840
      Width           =   1935
   End
   Begin VB.Label Label4 
      Alignment       =   1  'Right Justify
      Caption         =   "e-mail"
      Height          =   255
      Left            =   120
      TabIndex        =   11
      Top             =   480
      Width           =   1935
   End
   Begin VB.Label Label3 
      Alignment       =   1  'Right Justify
      Caption         =   "���"
      Height          =   255
      Left            =   120
      TabIndex        =   10
      Top             =   120
      Width           =   1935
   End
End
Attribute VB_Name = "INFO"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
  Unload Me
End Sub

Private Sub Command2_Click()
  NICK = Text1.Text
  MAIL = Text2.Text
  MALE = True
  COUNTRY = Text3.Text
  CITY = Text4.Text
  ABOUTUSER = Text5.Text
  SEND_CMD_SETINFO UID, STAT_ONLINE, NICK, MAIL, MALE, COUNTRY, CITY, ABOUTUSER
  SEND_CMD_GETINFO UID
End Sub
