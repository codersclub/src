VERSION 5.00
Begin VB.Form MESSAGE 
   BorderStyle     =   1  'Fixed Single
   Caption         =   "Form1"
   ClientHeight    =   4170
   ClientLeft      =   45
   ClientTop       =   330
   ClientWidth     =   6000
   Icon            =   "MESSAGE.frx":0000
   KeyPreview      =   -1  'True
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   ScaleHeight     =   4170
   ScaleWidth      =   6000
   StartUpPosition =   3  'Windows Default
   Begin VB.CommandButton Command2 
      Cancel          =   -1  'True
      Caption         =   "�������"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   3720
      Width           =   1575
   End
   Begin VB.CommandButton Command1 
      Caption         =   "���������"
      Height          =   375
      Left            =   4320
      TabIndex        =   1
      Top             =   3720
      Width           =   1575
   End
   Begin VB.TextBox Text2 
      Height          =   1335
      Left            =   120
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   0
      Top             =   2280
      Width           =   5775
   End
   Begin VB.TextBox Text1 
      Height          =   1335
      Left            =   120
      Locked          =   -1  'True
      MultiLine       =   -1  'True
      ScrollBars      =   2  'Vertical
      TabIndex        =   3
      Top             =   480
      Width           =   5775
   End
   Begin VB.Label Label6 
      BorderStyle     =   1  'Fixed Single
      Caption         =   "0"
      Height          =   255
      Left            =   960
      TabIndex        =   9
      Top             =   1920
      Width           =   855
   End
   Begin VB.Label Label5 
      BorderStyle     =   1  'Fixed Single
      Height          =   255
      Left            =   2640
      TabIndex        =   8
      Top             =   120
      Width           =   1335
   End
   Begin VB.Label Label4 
      BorderStyle     =   1  'Fixed Single
      Height          =   255
      Left            =   600
      TabIndex        =   7
      Top             =   120
      Width           =   1335
   End
   Begin VB.Label Label3 
      Caption         =   "��������"
      Height          =   255
      Left            =   120
      TabIndex        =   6
      Top             =   1920
      Width           =   855
   End
   Begin VB.Label Label2 
      Alignment       =   1  'Right Justify
      Caption         =   "UID"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   2160
      TabIndex        =   5
      Top             =   120
      Width           =   375
   End
   Begin VB.Label Label1 
      Alignment       =   1  'Right Justify
      Caption         =   "���"
      BeginProperty Font 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   700
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      Height          =   255
      Left            =   120
      TabIndex        =   4
      Top             =   120
      Width           =   375
   End
End
Attribute VB_Name = "MESSAGE"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Private Sub Command1_Click()
  If Len(Text2.Text) = 0 Then Exit Sub
  Text1.Text = Text1.Text & NICK & " (" & Time & ")" & vbCrLf & _
               Text2.Text & vbCrLf & vbCrLf
  SEND_CMD_MSG Val(Label5.Caption), Text2.Text
  Text2.Text = ""
  Label6.Caption = 0
End Sub

Private Sub Command2_Click()
  Unload Me
End Sub

Private Sub Form_KeyDown(KeyCode As Integer, Shift As Integer)
  If ((Shift = 2) And (KeyCode = vbKeyReturn)) Or ((Shift = 4) And (KeyCode = vbKeyS)) Then Command1_Click
End Sub

Private Sub Form_Unload(Cancel As Integer)
  If Text1.Text <> "" Then
    If Dir(App.Path & "\msg\" & Me.Caption) <> "" Then
      Open App.Path & "\msg\" & Me.Caption For Output As 1
      Print #1, Text1.Text
      Close 1
    Else
      FileCopy App.Path & "\messages", App.Path & "\msg\" & Me.Caption
      Open App.Path & "\msg\" & Me.Caption For Output As 1
      Print #1, Text1.Text
      Close 1
    End If
  End If
End Sub

Private Sub Text1_Change()
  ' ��� ����� ����� ��������� ���������.
  Text1.SelStart = Len(Text1.Text)
End Sub

Private Sub Text2_Change()
  Label6.Caption = Len(Text2.Text)
End Sub

Private Sub Text2_KeyPress(KeyAscii As Integer)
  If (Len(Text2.Text) = 1023) And (KeyAscii <> 8) Then KeyAscii = 0
  Label6.Caption = Len(Text2.Text)
End Sub
