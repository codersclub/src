#define		VIDEO_MODE	2
#define		VIDEO_FREE	0

#define		MIN_SPEED	35
#define		MAX_SPEED	1
#define		INIT_SPEED	6

/*--------------------------*/

#include	"eva.h"
#include	<stdlib.h>
#include	"rus.h"
#include	<string.h>
#include	<fcntl.h>
#include	<io.h>

#undef	NULL
#define	NULL	0L

#define	wX	56
#define	wY	56
#define	wDX     528
#define	wDY	248
#define	wDXX    (wDX-20)
#define	wDYY	(wDY-20)

#define	maxP	100

#define	rwDXX   15
#define	rwDYY	12
#define	rwDX    (rwDXX * 8)
#define	rwDY	(rwDYY * 8)
#define	p_mem	(rwDXX * rwDY)
#define Dcube	70
#define	MUL	1000

#define	isin	(int)Lsin
#define	icos	(int)Lcos

#define		inc	10

#define	ULONG	unsigned long
#define	UINT	unsigned int

/*--------------------------*/

char 	turca[] = {
"T170  ML L16O4BAG+AO5C8R8DCO4BO5CE8R8FED+EBAG+ABAG+AO6C4O5A8O6C8O5G32A32B16A8G8A8G32A32B16A8G8A8G32A32B16A8G8F+8E4\
 O4BAG+AO5C8R8DCO4BO5CE8R8FED+EBAG+ABAG+AO6C4O5A8O6C8O5B8A8G8A8B8A8G8A8B8A8G8F+8E4\
 E8F8G8G8AGFED4E8F8G8G8AGFED4C8D8E8E8FEDCO4B4O5C8D8E8E8FEDCO4B4BAG+AO5C8R8DCO4BO5CE8R8FED+EBAG+ABAG+AO6C4O5A8B8\
 O6L8CO5BAG+AEFDC4O4B.A32B32A4\
 O5ABO6C+4O5ABO6C+O5BAG+F+G+ABG+EABO6C+4O5ABO6C+O5BAG+F+BG+EA4\
 O5ABO6C+4O5ABO6C+O5BAG+F+G+ABG+EABO6C+4O5ABO6C+O5BAG+F+BG+EA4\
 L16O6C+DC+O5BABAG+F+AG+F+E+F+G+E+C+D+E+C+F+E+F+G+AG+ABO6C+O5B+O6C+O5B+O6C+DC+O5BABAG+F+AG+F+EF+G+EC+D+EC+D+EF+D+O4B+O5C+D+O4B+O5C+4\
 O6C+DC+O5BABAG+F+AG+F+E+F+G+E+C+D+E+C+F+E+F+G+AG+ABO6C+O5B+O6C+O5B+O6C+DC+O5BABAG+F+AG+F+EF+G+EC+D+EC+D+EF+D+O4B+O5C+D+O4B+O5C+4\
 EDC+O4BABO5C+DEF+G+AAG+F+EEDC+O4BABO5C+DEF+G+AA+8B8EDC+O4BABO5C+DEF+G+AAG+F+EEDC+O4BO5C+EO4AO5C+O4BO5DO4G+BA4\
 O6C+DC+O5BABAG+F+AG+F+E+F+G+E+C+D+E+C+F+E+F+G+AG+ABO6C+O5B+O6C+O5B+O6C+O5B+O6C+O5A+\
 O6DC+DC+DC+DC+DC+O5BAG+ABG+ABO6C+O5F+E+F+G+E+F+4\
 L8O5ABO6C+4O5ABO6C+O5BAG+F+G+ABG+EABO6C+4O5ABO6C+O5BAG+F+BG+EA4\
 O5ABO6C+4O5ABO6C+O5BAG+F+G+ABG+EABO6C+4O5ABO6C+O5BAG+F+BG+EA4\
 L16O4BAG+AO5C8R8DCO4BO5CE8R8FED+EBAG+ABAG+AO6C4O5A8O6C8O5B8A8G8A8B8A8G8A8B8A8G8F+8E4\
 E8F8G8G8AGFED4E8F8G8G8AGFED4C8D8E8E8FEDCO4B4O5C8D8E8E8FEDCO4B4BAG+AO5C8R8DCO4BO5CE8R8FED+EBAG+ABAG+AO6C4O5A8B8\
 O6L8CO5BAG+AEFDC4O4B.A32B32A4P2"
};
char jude[] =  {
"T105  L8 MN O5C4 O4A2RAO5CD O4G2R4GA B-4O5F4.FEC\
 DMLC16MNO4B-16A2RO5C DD4DG16MLFEMNF16D\
 C2O4FGAO5D4 CRCO4B-AEF2 R4.O5C4\
 O4A2RAO5CD O4G2R4GA B-4O5F4.FEC\
 DMLC16MNO4B-16A2RO5C D16D16R4DG16FEF16D\
 C2O4FGAO5D4 CRCO4B-A4EE F2R4.\
 R.F16O5F16E-D.CCO4B-16O5 D4R16FD4.FO4B-4.\
 O5FD4CO4B-O5C4. DC4.O4B-A4. GF2R\
 R.F16O5FDDCC12O4B-12MLO5D12 MND4FD4.FO4B-4.\
 O5FD4CO4B-O5C4. DC4O4B-4R16A4\
 G16F4.FO5CD E-.D16E-4EFG4 G2R4"
};
char lambada[] = {
"T170  L8O5 MN E4.DCO4BA4 AO5CO4BAGAED\
 E1 O5E4.DCO4BA4 AO5CO4BAGAED\
 E1 O5DDDCO4F4FA O5E4DCO4F4AO5C\
 O4B4AGG4AG A1 O5DDDCO4F4FA\
 O5E4DCO4F4AO5C O4B4AGG4O5CD MLC9O4B9A.R4"
};
char tango[] = {
"T50  MN L16O4 EEF FEEA AO5CCF F24G24F24E8 R EEA AEEC CDDC C24D24C24O4B8 R EEF\
 FEEG+ G+BBO5F F24G24F24E8 R ED+E BG+G+E EDDC O4B24O5C24O4B24A8 R O5EO4EF\
 FEEA AO5CCF F24G24F24E8 R EEA AEEC+ C+EEG G24A24G24F8 R8 O4FO5F FEED DCCO4B\
 B24O5C24O4B24A8 R O5CO4BA A24B24A24G+B BO5DCO4B A8 RGF+G O5FFRF GFED\
 FERO4B O5DCO4BA O5CO4BRO4F BAGF A8G8 R ED+E O5DDRD EDCO4B O5D8C8 R8 C24D24C24\
 O4BAG+A BO5CDD+ E R8. O4EO5EC+ O4AERO5C+ O4AEAO5C+ D24E24D24O4B8 R EO5DO4B\
 G+ERG+ EG+BO5D C+24D24C+24O4A8 R EO5C+O4B A+F+E+F+ G+A+BO5C+ E24F+24E24D8 R O4BA+B\
 O5C+24D+24C+24O4B8 R ABA A24B24A24G+8 R O5EO6EC+ O5AERO6C+ O5AEAO6C+ D24E24D24O5B8 R8 EO6DO5B\
 G+ERG+ EG+BO6D C+24D24C+24O5A8 R EO6C+O5B A+F+E+F+ G+A+BO6C+\
 E24F+24E24D8 R O5F+O6DC+ C+O5BA+B F+AG+B A8 R8"
};

/*---------------------------*/

int		input;
void	far	*buff;

char	far	*pt,*pt1,*s;
ULONG		l,len;

/*---------------------------*/

int	X  = 0;
int     Y  = 0;
int	K  = 30;
char	snd = 0;
int	pass = 0;
char	patt = 0x0f;

/*--------------------------*/

int	pat1,pat2;
int	xbase,ybase;
char	RF;

UINT	HEAPBASE = VIDEO_FREE;
UINT	SPEED = INIT_SPEED;

/*--------------------------*/

int	x0, y0, x1, y1, dx1, dy1, dx0, dy0;
int	xx0,yy0,xx1,yy1,dxx1,dyy1,dxx0,dyy0;

#include	"rkf8.inc"

/*--------------------------*/

struct AREA_P		areap;
struct AREA_W		areaw1  = { &areap,-8,-8 };
struct AREA_RECT	area1   = { 1, 1,1,rwDXX,rwDYY };
struct AREA_W		areaw2  = { &areap,-8-(63*8),-8 };
struct AREA_RECT	area2   = { 2, 1+63,1,rwDXX,rwDYY };
struct AREA_P		areap1;
struct AREA_W		areaw3  = { &areap1,-8-(32*8),-8-(30*8) };
struct AREA_RECT	area3   = { 3, 1+32,1+32,rwDXX,rwDYY-4 };

struct AREA_RECT	area    = { 10, wX/8,wY/8,wDX/8,wDY/8 };
struct AREA_RECT	areat   = { 10, wX/8+2,wY/8+6,wDX/8,wDY/8-5 };

int	S,YS;
int	Xa,Ya,Za, X0,Y0,Z0;
int	buf[16], dbuf[4], XX,YY,ZZ;

/*---------------------------*/

char V[] = {
0,8, 4,4, 0,0, 2,0, 5,3, 5,0, 7,0, 7,3, 10,0, 12,0, 8,4, 12,8, 10,8, 7,5, 7,8, 5,8, 5,5, 2,8, 0,8
};
char U[] = {
0,8, 0,6, 6,6, 6,5, 1,5, 0,4, 0,0, 2,0, 2,3, 6,3, 6,0, 8,0, 8,7, 7,8, 0,8
};

/*--------------------------*/
void far rline( int x1, int y1, int x2, int y2 )
{

	lineXY(x1,y1,x2,y2);
	if (abs(x2-x1) >= abs(y2-y1))
	{
	   lineXY(x1,y1-1,x2,y2-1);
	   lineXY(x1,y1+1,x2,y2+1);
	}
	else
	{
	   lineXY(x1-1,y1,x2-1,y2);
	   lineXY(x1+1,y1,x2+1,y2);
	}
}
/*--------------------------*/
void plot ( int x, int y, char *p )
{
int	x0, y0, x1, y1, xx, yy;

	x = X + x * 10;
	y = Y + y * 10;

	x0 = xx = (*p++) * 10 + x;
	y0 = yy = (*p++) * 10 + y;
	do
	{
		x1 = (*p++) * 10 + x;
		y1 = (*p++) * 10 + y;

		rline (x0, Yar(y0), x1, Yar(y1));

		x0 = x1;
		y0 = y1;
	}
	while ((x1 != xx) || (y1 != yy));
}
/*--------------------------*/
void znak( void )
{
	plot(  0, 0, V );
	plot( 15, 0, U );
	plot( 25, 0, V );
	plot( 40, 0, U );
}
/*--------------------------*/
void shurup( int x, int y )
{
	color(14);
	circleoutf(x, y, 15);
	color(0);
	circleout(x, y, 13);
	color(6);
	circleoutf(x, y, 11);
	color(0);
	moveab(x-14, y);
	lineh(x+14);
}
/*--------------------------*/
void cep( int x, int y )
{
	color(6);
	circleout(x, y, 14);
	color(0);
	circleout(x, y, 13);
	color(14);
	circleout(x, y, 12);
}
/*--------------------------*/
void lines( void )
{
static char	p;
static int	c;
static int	b[4];
static int	x,y;

	c = getscrcolor();
	p = getboxpattern();
	getwindow(b);
	x = getXpos();
	y = getYpos();
	windowoff();

	color(0);
	setboxpattern(0xff);
	moveab(wX, wY); box(wDX, wDY);
	moveab(wX+wDX+2*8-7,wY+6*8); linew(wY+wDY+1*8-3);
	moveab(wX+2*8,wY+wDY+1*8-3); lineh(wX+wDX+2*8-7);

	color(15);
	setboxpattern(patt);
	moveab(wX, wY); box(wDX, wDY);
	color(8);
	moveab(wX+wDX+2*8-7,wY+6*8); linew(wY+wDY+1*8-3);
	moveab(wX+2*8,wY+wDY+1*8-3); lineh(wX+wDX+2*8-7);

	rotboxpattern(1);
	patt = getboxpattern();
	windowXY(b[0],b[1],b[2],b[3]);
	color(c);
	setboxpattern(p);
	moveab(x,y);
}
/*--------------------------*/
void mainwindow( void )
{
	windowoff();
	color(0);
	moveab(wX, wY); boxfill(wDX, wDY);
	boxccc(wX+wDX,wY+6*8,2*8,wDY-5*8,0x00ff,0);
	boxccc(wX+wDX,wY+6*8,2*8,wDY-5*8,~0x00ff,8);
	boxccc(wX+2*8,wY+wDY,wDX-2*8,1*8,0x00ff,0);
	boxccc(wX+2*8,wY+wDY,wDX-2*8,1*8,~0x00ff,8);
	color(15);
	setboxpattern(patt);
	moveab(wX, wY); box(wDX, wDY);
	setboxpattern(0xff);
	EVAproc_ON(2,8,&lines,&Z0,GRAPHICS_SEMAPFORE);
	windowXY(wX+10, wY+10, wDXX, wDYY);
}
/*--------------------------*/
void	EXITpr( void )
{
int	i,j;

	kmouseoff();
	mouseoff();
	EVAproc_DSABLE();
	EVAproc_RESET();

	logic(0);
	defcolmap();
	windowoff();
	setpattern(0);
	setpatternmode(0);
	circlemode(0);
	i = 640/2;
	j = 0;
	do
	{
		color(8);
		circleoutf2(640/2,350/2,i,i-4);
		color(++j | 8);
		circleoutf2(640/2,350/2,i-4,i-8);
		kbdRESET();
	}
	while ((i-=8) > 0);

	DOSfree(pt1);
	DOSfree(pt);
	DOSfree(buff);
	DOSfrees(areap.p0);
	DOSfrees(areap1.p0);
	EVA_finit();
	playstop();

	kbdRESET();
	exit(0);
}
/*--------------------------*/
void sndOFF( void );

void finitpr( void )
{
int	i;

if( keyHIT() )
{
i = keyREAD();
kbdRESET();

	i &= 0x7F;
	if ((i == 'S') || (i == 's')) sndOFF();
	else if(i == 27) EXITpr();
}
if (mouseKP() & 4) EXITpr();
}
/*---------------------------*/
void continuepr( void )
{
	EVAproc_DSABLE();
	EVAproc_OFF(2);
	setrdpage(1);setwrpage(0);
	savepage();
	setrdpage(0);
	AREA_area(&area1);
	AREA_area(&area2);
	AREA_area(&area3);
	EVAproc_ENABLE();
}
/*--------------------------*/
void initpr( void )
{
int	i;

buff = DOSalloc(31L*4L*200L);
areap.p0 = DOSallocs(p_mem);
areap1.p0 = DOSallocs(p_mem);
pt  = DOSalloc(32L*1024L);
pt1 = DOSalloc(GETUNzipLEN());

if ((EVA_init(VIDEO_MODE) > 0)
     && (buff != NULL)
     && (pt != NULL)
     && (pt1 != NULL)
     && (areap.p0 != 0)
     && (areap1.p0 != 0))
{
	x0 = 1;
	len = 0L;
	input = _open("DEMO.DAT", O_RDONLY);
	if (input > 0)
	{
	_read(input,&l,4);
	if((UINT)(l >> 2) == 2)
	{
		lseek(input,0L,SEEK_SET);	/* source */
		_read(input,&l,4);
		lseek(input,l,SEEK_SET);
		len = UNarc(input,pt1,pt);

		lseek(input,4L,SEEK_SET);	/* gerb */
		_read(input,&l,4);
		lseek(input,l,SEEK_SET);
		if(UNarc(input,pt1,buff) == 31L*4L*200L) x0 = 0;
	}
	_close(input);
	}

	srand(1964);
	setchar(rkf_8,8,0);
	patlog(1,1);
	erasescr(1);
	logic(0);
	color(15);
	circlemode(0);
	rectab(2,2,636,346);
	color(0);
	recfill(30,20,630,240);
	color(14);
	recfill(20,10,620,230);
	color(6);
	recfill(30,20,610,220);
	color(14);
	moveab(482,204);
	textout(" ������� � ���� ");
	shurup(60,40);
	shurup(580,40);

	X =  70;
	Y = 110;
	for (i=4; i<15 ;++i)
	{
		color(i);
		znak();
		++X;
		Y += 2;
	}

	if (x0) rdimage(100,20,31*8,200,buff);

	EVAproc_SET();

	for (i=8; i<110 ; i+=2)
	{
		finitpr();
		scroll(20,i,i+2,620,231);
		vrwait(1);
		colmap((random(4)<<1)+5, rand(), rand(), rand());
	}
	defcolmap();
	x0 = 320;
	for (i=30, x1=0; i<150; i+=10, x1+=23)
	{
		cep(x0+x1,i);
		cep(x0-x1,i);
	}
	shurup(320,30);
	shurup(60,142);
	shurup(580,142);
	setwrpage(1);
	savepage();
	setwrpage(0);

	mouseon(0);
	kmouseon();
	}
else
{
	DOSfree(pt1);
	DOSfree(pt);
	DOSfree(buff);
	DOSfrees(areap.p0);
	DOSfrees(areap1.p0);
	EVA_finit();

	kbdRESET();
	exit(0);
}
}
/*------------------------------------------------------*/
void new(void)
{
	if( (x0 >= wDXX) || (x0 <= 0) ) dx0=-dx0;
	if( (y0 >= wDYY) || (y0 <= 0) ) dy0=-dy0;
	if( (x1 >= wDXX) || (x1 <= 0) ) dx1=-dx1;
	if( (y1 >= wDYY) || (y1 <= 0) ) dy1=-dy1;
	x0+=dx0; y0+=dy0;
	x1+=dx1; y1+=dy1;
	color((rand() & 15) | 8);
	lineXY(x0,y0,x1,y1);
}
/*---------------------------*/
void old(void)
{
	if( (xx0 >= wDXX) || (xx0 <= 0) ) dxx0=-dxx0;
	if( (yy0 >= wDYY) || (yy0 <= 0) ) dyy0=-dyy0;
	if( (xx1 >= wDXX) || (xx1 <= 0) ) dxx1=-dxx1;
	if( (yy1 >= wDYY) || (yy1 <= 0) ) dyy1=-dyy1;
	xx0+=dxx0; yy0+=dyy0;
	xx1+=dxx1; yy1+=dyy1;
	lineXY(xx0,yy0,xx1,yy1);
}
/*---------------------------*/
void linea( int k )
{
int	i;

	mainwindow();

	dxx0 = dyy0 = dx0 = dy0 = -2;
	dxx1 = dyy1 = dx1 = dy1 =  2;
	xx0 = x0 = 100;
	xx1 = x1 = 310;
	yy0 = y0 = 0;
	yy1 = y1 = 100;

		for (i=0; i<maxP; ++i) new();

		for (i=0; i<k; ++i)
		{
		if(i & 8) finitpr();
		color(((i>>5)+1) & 0x07);
		old();
		new();
		}
continuepr();
}
/*---------------------------*/
void gerb( int k )
{
int	i,x,y;
int	w[4];

	mainwindow();
	getwindow(w);

	w[0] += ((w[2]-248)>>1);
	w[1] += ((w[3]-200)>>1);
	setpatternimage(31,200,w[0],w[1],buff);
	windowXY(w[0],w[1],248,200);

if(pass & 1)
	{
		circlemode(1);
		i = 240/2;
		do
		{
			circleoutf2(248/2,100,i,i-1);
			if (i & 8) finitpr();
		}
		while (--i >= 0);
	}
else	{
		for(i=0; i<k * 300; ++i)
		{
			x = random(246);
			y = random(198);
			linehpatt(x,y,2);
			linehpatt(x,y+1,2);
			if (i & 64) finitpr();
		}
		moveab(0,0);
		barfill(248,200);
	}

	for (i=0; i<k; ++i)
	{
		vrwait(1);
		finitpr();
	}

++pass;
continuepr();
}
/*---------------------------*/
void	rounda( void )
{
register int	i,j;

	linepattern(pat1);
	linerotpattern(2);
	pat1 = getlinepattern();
	moveab(Xar(isin(100,0))+xbase, icos(100,0)+ybase);
	for (i=inc; i<360+inc; i+=inc)
	{
		linepos(Xar(isin(100,i))+xbase,icos(100,i)+ybase);
	}

	linepattern(pat2);
	linerotpattern(4);
	pat2 = getlinepattern();
	moveab(Xar(isin(90,360+inc))+xbase, icos(90,360+inc)+ybase);
	for (i=360; i>0; i-=inc)
	{
		linepos(Xar(isin(90,i))+xbase,icos(90,i)+ybase);
	}
}
/*---------------------------*/
void	rounda_exit( void )
{
	EVAproc_OFF(3);
	EVAproc_OFF(4);
	linestyle(0);
	linefirst(1);
	RF = 0;
}
/*--------------------------*/
void	roundOUT( int k )
{
register int	i,j;
int		w[4];

	mainwindow();

	getwindow(w);
	xbase = w[2] >> 1;
	ybase = w[3] >> 1;

	linefirst(0);
	linebgcolor(256+4);
	linestyle(4);
	color(10);
	pat1 = pat2 = getlinepattern();

	moveab(Xar(isin(100,0))+xbase, icos(100,0)+ybase);
	for (i=inc; i<360+inc; i+=inc)
	{
		linepos(Xar(isin(100,i))+xbase,icos(100,i)+ybase);
		vrwait(1);
	}
	moveab(Xar(isin(90,360+inc))+xbase, icos(90,360+inc)+ybase);
	for (i=360; i>0; i-=inc)
	{
		linepos(Xar(isin(90,i))+xbase,icos(90,i)+ybase);
		vrwait(1);
	}

	RF = 1;
	EVAproc_ON(3,5,&rounda,&RF,GRAPHICS_SEMAPFORE);
	EVAproc_ON(4+256,k,&rounda_exit,&RF,GRAPHICS_SEMAPFORE);

	while(RF) finitpr();

continuepr();
}
/*---------------------------*/
void textOUT( int k )
{
int	i,j;

	mainwindow();
	windowXY(wX+8, wY+10, wDXX, wDYY+7);

	for (i=0; i<k; ++i)
	{
	j = random(15);
	color(j);
	patlog(15-j,0);
	for (j=0; j<10; ++j)
	{
	  moveab(16, wDY-12-j);
	  textout("  ���� ��������, ��� �� �������� ����⮬ ���� !  ");
	  scroll(wX+10, wY+5, wY+4, wDX-10, wDY-6);
	}
	for (j=0; j<4; ++j) scroll(wX+10, wY+5, wY+4, wDX-10, wDY-6);
	finitpr();
	}

	for (i=0; i<62; ++i)
	{
		if (i & 4) finitpr();
		if (pass & 1) scrollh(wX+8, wY+1, wX+16, wDX-30, wDY-2);
		else          scrollh(wX+16, wY+1, wX+8, wDX-30, wDY-2);
	}
++pass;
continuepr();
}
/* ----------------------------------- */
void	source( int k )
{
int w[4];
register int i,j;
int	     x,y;
UINT         C;
ULONG	     CS;

	mainwindow();
	getwindow(w);

	x = w[0] & 0xfff8;
	y = w[1] & 0xfff8;
	w[0] >>= 3;
	w[1] >>= 3;
	w[2] >>= 3;
	w[3] >>= 3;
	i = w[3]-1;
	++w[2];

	t_window(w[0],w[1],w[2],1);
	t_init(9);
	t_bgcolor(10);
	t_color(12);
	t_string(1,0," ��� ����砭�� ������ ������� ESC ");
	t_string(38,0," ��ப� -              % ");
	t_window(w[0],w[1]+1,w[2],w[3]);
	t_color(14);
	t_init(1);

	OPENstr(pt,len);
	C = j = 0;
	while((s = READstr()) != NULL)
	{
			t_string(0,j,s);
			text8(x+(48*8),y,9,10,0,itoap(++C,5));
			getOPENstr(&CS,&CS);
			text8(x+(58*8),y,9,10,0,ltoap(lstep(len-CS,100L,len),3));
			++j;
			if(j > i) { t_scrollUP(); t_delh(i); j = i; }
			if( keyHIT())
			{
				if((keyREAD() & 0x7f) == 27) break;
				if((keyREAD() & 0x7f) == 27) break;
			}
	}

	for (i=0; i<k; ++i)
	{
		vrwait(1);
		finitpr();
	}

continuepr();
}
/* ----------------------------------- */
void ujas( int kk )
{
int	i,j,k,k1;
int	b[4*2];
int	w[4];

	mainwindow();

		getwindow(w);
		for (i=0; i<kk; ++i)
		{
		if(i & 4) finitpr();
		for (j=0; j<3; ++j)
		{

		if(rand() & 7)
		{
			color(random(15));
			setpattern(random(16));
			setpatternmode(rand());
			setpatterncolor(random(16),random(16));
		}
		else setpatternimage(31,200,0,0,buff);

		if(rand() & 3)
		{
			moveab(random(550),random(250));
			barfill(random(150),random(100));
		}
		else
		{
			k1 = 4*2;
			if(random(1)==0) k1 = 3*2;
			for(k=0; k<k1; ++k) b[k] = random(400);
			poly_fill1(k1 >> 1,b);
		}

		color(random(15));
		lineXY(random(1000),random(1000),random(1000),random(1000));

		color(random(15));
		circlemode(rand() & 1);
		circleout(random(1000),random(1000),random(50));
		circleoutf(random(550),random(250),random(50));

		color(random(15));
		moveab(random(1000),random(1000));
		box(random(150),random(100));

		color(random(15));
		moveab(random(1000),random(1000));
		boxfill(random(150),random(100));

		color(random(15));
		lineXY(random(1000),random(1000),random(1000),random(1000));

		color(random(15));
		patlog(random(15),random(2)-1);
		moveab(random(1000)-100,random(1000));
		textout("  �������� ����⮬ ���� !  ");
		moveab(random(1000)-100,random(1000));
		textout("  �������� ����⮬ ���� !  ");
		}

		if(rand() & 7)
		{
			color(random(15));
			setpattern(random(16));
			setpatternmode(rand());
			setpatterncolor(random(16),random(16));
		}
		else setpatternimage(31,200,0,0,buff);
		circleoutf2(random(550),random(250),random(100),random(50));

		k = random(3);
		if (k == 0) zoom2(random(w[2]-20)+w[0],random(w[3]-20)+w[1],
				  20,20,random(w[2]-40)+w[0],random(w[3]-40)+w[1]);
		if (k == 1) zoom4s(random(w[2]-20)+w[0],random(w[3]-20)+w[1],
				  20,20,random(w[2]-80)+w[0],random(w[3]-80)+w[1]);
		if (k == 2) zoom8s(random(w[2]-10)+w[0],random(w[3]-10)+w[1],
				  10,10,random(w[2]-80)+w[0],random(w[3]-80)+w[1]);

		scroll(wX+10,wY+5,wY+8,wDX-20,wDY-15);
		moveab(wX+1, wY+wDY-13);
		lineh(wX+wDX-2);
		}
continuepr();
}
/*------------------------------------------------------*/
void	dot( int xx, int yy, int zz, int *x, int *y )
{
	xx = step(xx,MUL,Z0) << 6;
	yy = step(yy,MUL,Z0) << 6;
	zz = step(zz,MUL,Z0) << 6;

	XX = icos(xx,Za) + isin(yy,Za);
	yy = icos(yy,Za) - isin(xx,Za);
	xx = XX;
	XX = icos(xx,Ya) - isin(zz,Ya);
	zz = icos(zz,Ya) + isin(xx,Ya);
	YY = icos(yy,Xa) + isin(zz,Xa);
	ZZ = icos(zz,Xa) - isin(yy,Xa);

	*x = X0 + Xar(XX >> 6);
	*y = Y0 +    (YY >> 6);
}
/*--------------------------*/
int	dotlen( void )
{
	return(sqrt_int(sqr_int(XX) + sqr_int(YY) + sqr_int(ZZ-Z0)));
}
/*--------------------------*/
void	calcube( int d, int b[], int db[] )
{
	dot(-d,-d,-d,&b[0],&b[1]);     db[0] = dotlen();
	dot(d,-d,-d, &b[2],&b[3]);     db[1] = dotlen();
	dot(d,d,-d,  &b[4],&b[5]);
	dot(-d,d,-d, &b[6],&b[7]);     db[2] = dotlen();

	dot(-d,-d,d, &b[0+8],&b[1+8]); db[3] = dotlen();
	dot(d,-d,d,  &b[2+8],&b[3+8]);
	dot(d,d,d,   &b[4+8],&b[5+8]);
	dot(-d,d,d,  &b[6+8],&b[7+8]);
}
/*--------------------------*/
void paintcube( int b[], int db[] )
{
if(db[0] < db[3])
{
	AREA_lineXY(b[0],b[1],b[2],b[3]);
	AREA_lineXY(b[2],b[3],b[4],b[5]);
	AREA_lineXY(b[4],b[5],b[6],b[7]);
	AREA_lineXY(b[6],b[7],b[0],b[1]);
}
if(db[3] < db[0])
{
	AREA_lineXY(b[0+8],b[1+8],b[2+8],b[3+8]);
	AREA_lineXY(b[2+8],b[3+8],b[4+8],b[5+8]);
	AREA_lineXY(b[4+8],b[5+8],b[6+8],b[7+8]);
	AREA_lineXY(b[6+8],b[7+8],b[0+8],b[1+8]);
}

if(db[0] < db[1])
{
	AREA_lineXY(b[6],b[7],b[0],b[1]);
	AREA_lineXY(b[0],b[1],b[0+8],b[1+8]);
	AREA_lineXY(b[0+8],b[1+8],b[6+8],b[7+8]);
	AREA_lineXY(b[6+8],b[7+8],b[6],b[7]);
}
if(db[1] < db[0])
{
	AREA_lineXY(b[2],b[3],b[4],b[5]);
	AREA_lineXY(b[4],b[5],b[4+8],b[5+8]);
	AREA_lineXY(b[4+8],b[5+8],b[2+8],b[3+8]);
	AREA_lineXY(b[2+8],b[3+8],b[2],b[3]);
}

if(db[2] < db[0])
{
	AREA_lineXY(b[4],b[5],b[6],b[7]);
	AREA_lineXY(b[6],b[7],b[6+8],b[7+8]);
	AREA_lineXY(b[6+8],b[7+8],b[4+8],b[5+8]);
	AREA_lineXY(b[4+8],b[5+8],b[4],b[5]);
}
if(db[0] < db[2])
{
	AREA_lineXY(b[0],b[1],b[2],b[3]);
	AREA_lineXY(b[2],b[3],b[2+8],b[3+8]);
	AREA_lineXY(b[2+8],b[3+8],b[0+8],b[1+8]);
	AREA_lineXY(b[0+8],b[1+8],b[0],b[1]);
}
}
/*---------------------------*/
void	cube( void )
{
int	j;

	Xa+=5;
	Ya+=3;
	Za-=10;
	Z0-=( S<<1 );

	j = X>>7;
	X0 = rwDX/2 + Xar(icos(j,X));
	Y0 = rwDY/2 + isin(j,X);
	calcube(Dcube,buf,dbuf);
	AREA_set(&areap);
	AREA_erase(0);
	paintcube(buf,dbuf);
	X += S;
	if((X > 360*9) || (X < 2)) S = -S;

	AREA_color(14);
	AREA_view(1,&areaw1);
	AREA_view(2,&areaw2);
}
/*---------------------------*/
void	jarow( void )
{
	AREA_set(&areap1);
	AREA_erase(0);
	AREA_moveab(8,Y-4); AREA_box(105,30);
	AREA_textoutXY(32,Y,"� � � �");
	AREA_textoutXY(14,Y+14,"��஢  �. �.");
	Y += YS;
	if((Y > (rwDY-40)) || (Y < 15)) YS = -YS;

	AREA_color(13);
	AREA_view(3,&areaw3);
}
/*---------------------------*/
void	set_proc(void)
{
	EVAproc_DSABLE();
	EVAproc_ON(0,SPEED,&cube,&Z0,  GRAPHICS_SEMAPFORE);
	EVAproc_ON(1,SPEED<<1,&jarow,&Z0,GRAPHICS_SEMAPFORE);
	EVAproc_ENABLE();
}
/*---------------------------*/
void time_init( void )
{
	areap1.x8 = rwDXX;
	areap1.y8 = rwDYY;
	areap1.flag = 1;
	AREA_set(&areap1);
	AREA_erase(0);

	areap.x8 = rwDXX;
	areap.y8 = rwDYY;
	areap.flag = 1;
	AREA_set(&areap);
	AREA_erase(0);

	AREA_logic(0);
	AREA_color(14);

	X0 = rwDX/2;
	Y0 = rwDY/2;
	Z0 = 10000;

	calcube( Dcube,buf,dbuf);
	paintcube(buf,dbuf);

	X = 1; S = 6; Y = 25; YS = 3;
	jarow();

	AREA_area(&area1);
	AREA_area(&area2);
	AREA_area(&area3);

	AREA_color(14);
	AREA_view(1,&areaw1);
	AREA_view(2,&areaw2);

	AREA_color(13);
	AREA_view(3,&areaw3);

	set_proc();
}

/*******************************************************************
		       MENU-8-WINDOWS
*******************************************************************/

struct	MENU_S	{
		int	X,Y,  DX,DY;
		int	posBAR;
		char	colorBF,colorBB,  colorMF,colorMB,  colorLF,colorLB;
		char	far *label;
		char	flagPOS;
		int	colorMASK;
		char	flag;
		int	pointer;
		};

struct	MENU_D	{
		char	colorFG,colorBG;
		char	far *msg;
		int	far (*fpoint)(void);
		};

struct AREA_RECT	areaMENU    = { 0,0,0,0,0 };

/******************************************************************/

static int  POSstring( char flag, int dx, char *str )
{
register int	i;

  if ( flag || (i = dx - strlen( str )) <0 ) i=0;
  return (i>>1);
}

/*----------------------------------*/

static void BARtext( int j, struct MENU_S *S, struct MENU_D *P )
{
  t_color( P->colorFG);
  t_bgcolor( P->colorBG);
  t_delh(j);
  t_string(POSstring(S->flagPOS,S->DX,P->msg),j,P->msg);
};

/*----------------------------------*/

static void BARmarker( struct MENU_S *S, struct MENU_D *P )
{
  t_color(S->colorMF);
  t_bgcolor(S->colorMB);
  t_delh(S->posBAR);
  t_string(POSstring(S->flagPOS,S->DX,P->msg),S->posBAR,P->msg);
};

/*----------------------------------*/

static void paintMENU( struct MENU_S *S, struct MENU_D *P )
{
register int	i,j;
int		x,y,X,Y,DX,DY;

X  = S->X;
Y  = S->Y;
DX = S->DX;
DY = S->DY;

if (S->flag)
{
	EVAproc_PAUSE();

	areaMENU.number = 100;
	areaMENU.xoff = X;
	areaMENU.dx = DX + 2;
	areaMENU.dy = DY + 2;
	areaMENU.yoff = Y;

	AREA_area(&area1);
	AREA_area(&area2);
	AREA_area(&area3);
	AREA_area(&areaMENU);

	AREA_color(14);
	AREA_view(1,&areaw1);
	AREA_view(2,&areaw2);
	AREA_color(13);
	AREA_view(3,&areaw3);
}

/*----------------*/

x = (X+2)<<3;
y = (Y+DY+2)<<3;
i = ((DX+2)<<3)-2;
j = 8-2;
boxccc(x,y,i,j,S->colorMASK,0);
boxccc(x,y,i,j,~S->colorMASK,8);
x = (X+DX+2)<<3;
y = (Y+1)<<3;
j = (DY+1)<<3;
boxccc(x,y,14,j,S->colorMASK,0);
boxccc(x,y,14,j,~S->colorMASK,8);

/*----------------*/

t_window(X,Y,DX+2,DY+2);
t_color(S->colorLF);
t_bgcolor(S->colorLB);
x = strlen(S->label);
if ((y = DX - x) <0 ) y=0;
y = (y>>1)+1;
t_string(y,0,S->label);
x += y;

/*----------------*/

t_bgcolor(S->colorBB);
t_color(S->colorBF);
for ( i=1, t_char(0,0,201), t_char(DX+1,0,184); i<=DX; ++i)
	if ((i<y) || (i>=x)) t_char(i,0,205);
for ( i=1, j=DX+1; i<=DY; ++i )
{
	t_char(0,i,186); t_char(j,i,179);
}
for ( i=1, j=DY+1, t_char(0,j,211), t_char(DX+1,j,217); i<=DX; ++i)
	t_char(i,j,196);

/*----------------*/

t_window(X+1,Y+1,DX,DY);
j = S->posBAR;
for ( i=0; i<DY; ++i) if (j != i) BARtext(i,S,P+i); else BARmarker(S,P+j);
};

/******************************************************************/

void deleteMENU( struct MENU_S *S )
{
register int i;
int          x,y,k;

	t_window(S->X,S->Y,S->DX+4,S->DY+3);

	k = (SPEED > 3) ? 1000 : 300;
	for ( i=0; i<k; ++i)
	{
		x = random(S->DX+4);
		y = random(S->DY+3);
		t_saveblock(x,y,S->pointer);
		if(SPEED > 5)  t_saveblock(x,y,S->pointer);
		if(SPEED > 10) t_saveblock(x,y,S->pointer);
	}
	EVAproc_PAUSE();
	t_save(S->pointer,1);
	AREA_area(&area1);
	AREA_area(&area2);
	AREA_area(&area3);

	AREA_color(14);
	AREA_view(1,&areaw1);
	AREA_view(2,&areaw2);
	AREA_color(13);
	AREA_view(3,&areaw3);
	EVAproc_CONTINUE();
}

/******************************************************************/

int MENU ( struct MENU_S *pS, struct MENU_D *pD )
{
int	 pointer;
register int i,j;
int      x,y,XX,YY,DX,DY;
int	 Ybase;

/*----------------------------------*/

DX = pS->DX;
DY = pS->DY;

if ( (DX <= 0) || (DY <= 0) ) return(-1);

if ( getvfont() != 8) return(-1);

for ( i=0; i<DY; ++i) if ( (pD+i) -> msg == NULL) break;
DY = pS->DY = i;

if (pS->posBAR > DY) pS->posBAR = DY;

/*----------------------------------*/

pointer = pS->pointer = HEAPBASE;
HEAPBASE += t_memsave(DX+4,DY+3);

t_window(pS->X,pS->Y,DX+4,DY+3);
t_save(pointer,0);

/*----------------------------------*/

cursorPUToff();
mouseXY(&x, &y);
kbdclr();
mouseKP();

XX = (pS->X+1)<<3;
YY = Ybase = (pS->Y+1) << 3;
curwindow(XX+1,YY+1,XX+(DX<<3)-2,YY+(DY << 3)-2);
XX += 8;

/*----------------------------------*/

EVAproc_PAUSE();
paintMENU( pS, pD);
EVAproc_CONTINUE();

/*----------------------------------*/

LABEL:
YY += (((pS->posBAR>0) ? pS->posBAR : 0) << 3) + 4;
cursor_color(15, 0);
curwindowXY(&XX, &YY);
cursorPUT(XX, YY);

do
{
	/*-----------------*/

	kbdclr();
	mouseXY(&x, &y);

	i = mouseK();

	if (x==0)
	{
	if      ((y==-1) && (i & Num8)) { YY -= 8;    goto BARL; }
	else if  ((y==1) && (i & Num2)) { YY += 8;    goto BARL; }
	}
	if (x==-1)
	{
	if       ((y==1) && (i & Num1)) { YY = 32767; goto BARL; }
	else if ((y==-1) && (i & Num7))	{ YY = 0;     goto BARL; }
	}

	XX += x;
	YY += y;

	/*-----------------*/

BARL:	if ( x | y )
	{
	  curwindowXY(&XX, &YY);

	  if ( (i = (YY-Ybase) >> 3) != pS->posBAR)
	  {
	  if ((pD+i) -> fpoint != NULL)
	  {
		EVAproc_PAUSE();
		cursorPUToff();
		BARtext(pS->posBAR,pS,pD+pS->posBAR);
		pS->posBAR = i;
		BARmarker(pS,pD+i);
		EVAproc_CONTINUE();
	  }
	  }
	  cursorPUT(XX, YY);
	}

	/*-----------------*/

	x = mouseKP();
	y = 0;

	if ((x & 1) && ((pD+pS->posBAR) -> fpoint != NULL))
	{
		cursorPUToff();

		y = ((pD+pS->posBAR) -> fpoint());

		cursorPUToff();
		kbdclr();
		i = (pS->X+1)<<3;
		YY = j = Ybase = (pS->Y+1) << 3;
		curwindow(i+1,j+1,i+(DX<<3)-2,j+(DY << 3)-2);

		if (y) {
			EVAproc_PAUSE();
			paintMENU( pS, pD);
			EVAproc_CONTINUE();
			goto LABEL;
			}
		else   { x = 4; y = 1; }
	}

	/*-----------------*/
}
while ( (x & 4) == 0 );

/*----------------------------------*/

cursorPUToff();
deleteMENU(pS);

HEAPBASE = pointer;
kbdclr();
return(y);
};

/******************************************************************/

void moveMENU( struct MENU_S *S , struct MENU_D *P )
{
int x,y,DX,DY,X,Y;

mouseXY(&x, &y);
DX = S->DX+4;
DY = S->DY+3;
X  = S->X;
Y  = S->Y;

do
{
	mouseXY(&x, &y);

	if (X+x < 0 ) x = -X;
	if (X+DX+x > 80 ) x = 80-X-DX;
	if (Y+y < 0 ) y = -Y;
	if (Y+DY+y > 43 ) y = 43-Y-DY;

	if (x | y)
	{
	EVAproc_PAUSE();
	t_window(X,Y,DX,DY);
	t_save(S->pointer,1);
	  X += x;
	  Y += y;
	t_window(X,Y,DX,DY);
	t_save(S->pointer,0);
	S->X = X;
	S->Y = Y;
	paintMENU( S, P);
	EVAproc_CONTINUE();

	mouseXY(&x, &y);
	}
}
while ((mouseKP() & 4)==0);
}

/******************************************************************/

void deleteMENU_area( struct MENU_S *S )
{
	deleteMENU(S);
	EVAproc_PAUSE();
	AREA_clr(3,0);
	AREA_area(&area);
	AREA_area(&areat);
	EVAproc_CONTINUE();
}

/*******************************************************************
		 end of   MENU
*******************************************************************/

char msg1[]  = { " ���� ..." };
char msg2[]  = { " ����� ..." };
char msg3[]  = { " ����� ..." };
char msg4[]  = { " ��㦮窨 ..." };
char msg5[]  = { " ��� ..." };
char msg6[]  = { " ��室�� ⥪���" };
char msgX[]  = { "        ***" };
char msg10[] = { " ��६�饭�� ����" };
char msg11[] = { " ������� ����ᮢ" };
char msg20[] = { "    ����� � DOS" };

char msgNS[] = { " ��몠    ����" };
char msgS1[] = { " ��몠   Turca" };
char msgS2[] = { " ��몠   Jude" };
char msgS3[] = { " ��몠   Lambada" };
char msgS4[] = { " ��몠   Tango" };

char label1[] = { " � � � � � " };
char label2[] = { " ������� " };
char label3[] = { " �������� ��������� " };

char sVALUE[] = { "30" };
char sX[]     = { "" };
char sMAX[]   = { "��砫쭠� ᪮����" };
char sPLUS[]  = { "�᪮७�� ����ᮢ" };
char sMINUS[] = { "���������� ����ᮢ" };

char c1[] =  {"Turca"};
char c2[] =  {"Jude"};
char c3[] =  {"Lambada"};
char c4[] =  {"Tango"};

struct	MENU_S menuS1 =   { 10,5, 20,14, 0,
			    14,1, 0,12, 12,1,
			    label1,
			    1,
			    0x00ff,
			    1
			  };

struct	MENU_S menuS2 =   { 35,4, 15,6, 0,
			    14,1, 0,12, 12,1,
			    label2,
			    0,
			    0x00ff,
			    0
			  };

struct	MENU_S menuS3 =   { 25,4, 27,6, 2,
			    14,5, 0,12, 12,5,
			    label3,
			    0,
			    0x00ff,
			    0
			  };

/******************************************************************/

int pc(void)
{
	return(0);
};

struct	MENU_D menuD2[] = {
			    { 14,1, c1, pc },
			    { 14,1, c2, pc },
			    { 14,1, c3, pc },
			    { 14,1, c4, pc },
			    { 0,0,  NULL, NULL }
			  };

/******************************************************************/

int spPLUS(void);
int spMINUS(void);
int spMAX(void);

int p1(void);
int p2(void);
int p3(void);
int p4(void);
int p5(void);
int p6(void);
int p20(void);
int p10(void);
int p11(void);

int pp(void);

/******************************************************************/

struct	MENU_D menuD3[] = {
			    { 15,5, sVALUE, NULL },
			    {  7,5, sX, NULL },
			    { 14,5, sMAX, spMAX },
			    { 14,5, sMINUS, spMINUS },
			    { 14,5, sPLUS, spPLUS },
			    { 0,0,  NULL, NULL }
			  };

/******************************************************************/

struct	MENU_D menuD1[] = {
			    { 14,1, msg1, p1 },
			    { 14,1, msg2, p2 },
			    { 14,1, msg3, p3 },
			    { 14,1, msg4, p4 },
			    { 14,1, msg5, p5 },
			    { 7 ,1, msgX, NULL },
			    { 14,1, msg6, p6 },
			    { 7 ,1, msgX, NULL },
			    { 14,6, msgNS, pp },
			    { 14,5, msg10, p10 },
			    { 15,3, msg11, p11 },
			    { 12,4, msg20, p20 },
			    { 0,0,  NULL, NULL }
			  };

int p1(void)
{
	deleteMENU_area(&menuS1);
	ujas((SPEED > 3) ? 50 : 25);
	return(1);
};

int p2(void)
{
	deleteMENU_area(&menuS1);
	linea((SPEED > 3) ? 1000 : 500);
	return(1);
};

int p3(void)
{
	deleteMENU_area(&menuS1);
	textOUT((SPEED > 3) ? 18 : 10);
	return(1);
};

int p4(void)
{
	deleteMENU_area(&menuS1);
	roundOUT(300);
	return(1);
};

int p5(void)
{
	deleteMENU_area(&menuS1);
	gerb((SPEED > 3) ? 100 : 50);
	return(1);
};

int p6(void)
{
	deleteMENU_area(&menuS1);
	source((SPEED > 3) ? 100 : 50);
	return(1);
};

int p20(void)
{
	deleteMENU_area(&menuS1);
	EXITpr();
	return(0);
};

int	pp(void)
{
	if (snd) sndOFF();
	else     if (MENU (&menuS2,menuD2))
		 {
			snd = 0xff;
			playcikl(30000);
			if (menuS2.posBAR == 0)
			{
				menuD1[8].msg = msgS1;
				play(turca);
			}
			if (menuS2.posBAR == 1)
			{
				menuD1[8].msg = msgS2;
				play(jude);
			}
			if (menuS2.posBAR == 2)
			{
				menuD1[8].msg = msgS3;
				play(lambada);
			}
			if (menuS2.posBAR == 3)
			{
				menuD1[8].msg = msgS4;
				play(tango);
			}
		 }
	return(1);
}

int p10(void)
{
	moveMENU(&menuS1,menuD1);
	return(1);
};

int p11(void)
{
	MENU(&menuS3,menuD3);
	return(1);
};

/*---------------------------*/
void	sndOFF( void )
{
	menuD1[8].msg = msgNS;
	snd = 0;
	playstop();
}

/******************************************************************/

void	spSET( int i )
{
	if((i >= MAX_SPEED) & (i <= MIN_SPEED))
	{
		SPEED = i;
		menuD3[0].msg = strcpy(sVALUE,itoap((1+MIN_SPEED)-SPEED,2));
		set_proc();
	}
}
/*---------------------------*/
int spMAX(void)
{
	spSET(INIT_SPEED);
	return(1);
};

int spPLUS(void)
{
	spSET(SPEED-1);
	return(1);
};

int spMINUS(void)
{
	spSET(SPEED+1);
	return(1);
};

/******************************************************************/

main()
{
initpr();
time_init();

	MENU (&menuS1,menuD1);

EXITpr();
}



