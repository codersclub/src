Attribute VB_Name = "ChPModule"
Global Const CONSTVERSION = 9 ' ������ ���������
Global Const SERVER_UID = 0 ' uid �������

Global Const STAT_ONLINE = 255
Global Const STAT_AWAY = 1
Global Const STAT_INVISIBLE = 2
Global Const STAT_OFFLINE = 0
Global Const STAT_NOTEXIST = 127

Global Const CMD_INFO = 0
Global Const RPL_INFO = 100
Global Const CMD_LOGIN = 1
Global Const RPL_LOGIN = 101
Global Const CMD_STATUS = 2
Global Const RPL_STATUS = 102
Global Const CMD_REGISTER = 3
Global Const RPL_REGISTER = 103
Global Const CMD_GETSTATUS = 4
Global Const RPL_GETSTATUS = 104
Global Const CMD_GETADDR = 5
Global Const RPL_GETADDR = 105
Global Const CMD_SETINFO = 6
Global Const RPL_SETINFO = 106
Global Const CMD_GETINFO = 7
Global Const RPL_GETINFO = 107
Global Const CMD_MSG = 10
Global Const RPL_MSG = 110
Global Const CMD_PING = 99
Global Const RPL_PING = 199
Global Const CMD_LOGOUT = 100
Global Const RPL_LOGOUT = 200

Public Sub LongToByte(a As Long, b() As Byte, FromByte As Integer)
  Dim i As Integer
  Dim ost As Long
  ost = a
  b(FromByte) = 0
  b(FromByte + 1) = 0
  b(FromByte + 2) = 0
  b(FromByte + 3) = 0
  For i = 30 To 24 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 3) = b(FromByte + 3) + (2 ^ i) / 16777216
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 23 To 16 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 2) = b(FromByte + 2) + (2 ^ i) / 65536
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 15 To 8 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte + 1) = b(FromByte + 1) + (2 ^ i) / 256
      ost = ost Mod (2 ^ i)
    End If
  Next i
  For i = 7 To 0 Step -1
    If (ost \ (2 ^ i)) >= 1 Then
      b(FromByte) = b(FromByte) + (2 ^ i)
      ost = ost Mod (2 ^ i)
    End If
  Next i
End Sub

Public Sub ByteToLong(b() As Byte, a As Long, FromByte As Integer)
  Dim i As Integer
  Dim lng As Long
  a = 0
  lng = 0
  lng = (b(FromByte + 3) * 16777216)
  lng = lng + (b(FromByte + 2) * 65536)
  ' �����-�� �������� ������������ :(
  lng = lng + (b(FromByte + 1) * 128)
  lng = lng + (b(FromByte + 1) * 128)
  '
  lng = lng + b(FromByte)
  a = lng
End Sub

Public Sub StringToByte(b() As Byte, str As String, FromByte As Integer)
  Dim i As Integer
  If Len(str) > 1024 Then Exit Sub
  For i = 0 To Len(str) - 1
    b(FromByte + i) = Asc(Mid(str, i + 1, 1))
  Next i
  b(FromByte + Len(str)) = 0
End Sub

Public Sub ByteToString(strng As String, b() As Byte, FromByte As Integer)
  Dim i As Integer
  i = FromByte
  While b(i) <> 0
    strng = strng & Chr(b(i))
    i = i + 1
  Wend
End Sub
