program Diagnosis;

uses
  Forms,
  DiagnosisUnit1 in 'DiagnosisUnit1.pas' {Space},
  AboutUnit1 in 'AboutUnit1.pas' {AboutBox};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TSpace, Space);
  Application.CreateForm(TAboutBox, AboutBox);
  Application.Run;
end.
