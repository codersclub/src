unit AboutUnit1;

interface

uses Windows, SysUtils, Classes, Graphics, Forms, Controls, StdCtrls,
  Buttons, ExtCtrls, Messages;

type
  TAboutBox = class(TForm)
    OKButton: TButton;
    ProgramIcon: TImage;
    ProductName: TLabel;
    Label1: TLabel;
    Memo1: TMemo;
    Shape1: TShape;
    Label2: TLabel;
    Image1: TImage;
  private
    procedure WMNCHitTest(var Message: TWMNCHitTest); message wm_NCHitTest;
    { Private declarations }
  public
    { Public declarations }
  end;

var
  AboutBox: TAboutBox;

implementation

{$R *.DFM}

procedure TAboutBox.WMNCHitTest;
begin
  inherited;
  if Message.Result = htClient then Message.Result:=htCaption;
end;
end.
 
