program CHAT;
uses CRT,IPX,DOS;

type
  Packet = record
             ecb  : ECBType;
             IPX  : IPXheader;
             data : string;
           end;

var
  send,receive : Packet;

procedure Main;

var
  line   : string;
  y      : integer;
  done   : boolean;
  k      : char;
  i,i1  : integer;
  handle : string;
  maxp, cnt : word;

begin
  ClrScr;
  writeln('CHATER BOX v1.8 By Tem@  12th Jun 2002');
  writeln;
  write('Your node is : '); TextColor(15);
  for i1 :=1 to 6 do
   Begin
     Write(ByteToHex(localaddr.node[i1]));
     IF I1 < 6 Then Write(':');
   End;  TextColor(7);
  writeln;
  write('Your net is  : '); TextColor(15);
  for i1 :=1 to 4 do
   Write(ByteToHex(localaddr.net[i1]));
  writeln; TextColor(7);
  GetDriverMaximumPacketSize(maxp, cnt);
  write('Max packet size : ');TextColor(15);
  write(maxp);TextColor(7);writeln(' bytes...');
  write('Retry count : ');TextColor(15);
  writeln(cnt);TextColor(7);
  write('Packet type : ');TextColor(15);
  writeln(GetPacketType);TextColor(7);
  writeln;
  write('Enter your nickname : ');
  readln(handle);

  window(1,1,80,23);
  textBackground(Blue);
  textColor(Yellow);
  clrScr;
  window(1,24,80,25);
  textBackground(Red);
  textColor(Yellow);
  clrScr;

  y:=1;
  line:='';
  done:=FALSE;

  repeat
    repeat
    until KeyPressed or (receive.ecb.inuse=0);

    if receive.ecb.inuse=0 then
      begin
        window(1,1,80,23);
        gotoXY(1,y);
        textBackground(Blue);
        textColor(Yellow);
        writeln(receive.data);
        y:=WhereY;
        if IPXlistenForPacket(receive.ecb)<>0 then
          begin
            writeln(#7,'ERROR TRYING TO receive A PACKET!');
            halt(2);
          end;

        window(1,24,80,25);
        GotoXY(1,length(line)+1);

      end;

    if KeyPressed then
      begin
        k:=ReadKey;
        case k of
          #13 : if line<>'' then
                  begin
                    send.data:='<<'+handle+'>> '+line;

                    with send.ecb do
                      for i:=1 to 6 do
                        ImmedAddr[i]:=$ff;

                    repeat
                    until send.ecb.inuse=0;

                    IPXsendPacket(send.ecb);
                    line:='';
                  end;
          #8  : if length(line)>0 then
                  line:=copy(line,1,length(line)-1);
          #0  : k:=ReadKey;
          #27 : done:=TRUE;
        else
          if length(line)<79 then
            line:=line+k
          else
            begin
              sound(1000);
              delay(100);
              noSound;
            end;
        end;

        window(1,24,80,25);
        textBackground(Red);
        textColor(Yellow);
        GotoXY(1,1); clreol; write(line);
      end;
  until done;
end;

begin
  InitIPX;
  if IPXopenSocket(0,MYSOCKET)=0 then
    begin
      with send do
        InitSendPacket(ecb,ipx,sizeof(String),MYSOCKET);
      with receive do
        InitReceivePacket(ecb,ipx,sizeof(String),MYSOCKET);

      Main;

      IPXcloseSocket(MYSOCKET);
    end;

  TextColor(LightGray);
  TextBackground(Black);
  window(1,1,80,25);
  clrScr;
end.