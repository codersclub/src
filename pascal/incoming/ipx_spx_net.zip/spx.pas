(*
                            /  /  //
//////// ////// //   ///  /          /
/      / /      / / //// /   / / /    /
///  /// /      // // // /   /   /    /
  /  /   /////  //    // /   / / /   /
  /  /   /      //    //  /       / /
  ////   ////// //    //   /////        aka Dj DFk. 13 jun 2002




*)
Unit SPX;
INTERFACE
Uses IPX;
Type
   TSPXStatusBuffer = RECORD
     ConnectionState : Byte;
      { 01h waiting to esablish connection
        02h starting (attempting to create connection)
        03h connetion established
        04h terminating }
     WatchdogFlag : Byte;
      { Bit 0: used internally by SPX
        Bit 1: SPX watchdog is monitoring connection
        Bits 2-7 used internally by SPX }
     SourceConnectionID : Word; { Big-endian }
     DestConnectionID : Word; { Big-endian }
     SeqNumOfNextPAcketSend : Word; { Big-endian }
     AcknowledgeNum : Word; { Big-endian }
     MaxSeqNumRemoteSPXMaySend : Word; { Big-endian }
     RemoteAckNum : Word; { Big-endian }
     RemoteAllocationNum : Word; { Big-endian }
     ConnectionSocket : Word; { Big-endian }
     ImmediateNodeAddr : NodeAddr;
     InternetworkAddr : NetAddress;
     RetransmitCount : Word; { Big-endian }
     EstimatedRoundTripDelay : Word; { Big-endian }
     RetransmittedPackets : Word; { Big-endian }
     SuppressedPackets : Word; { Big-endian }
     UnknownNone : array[1..12] of Byte; { v2.15 }
   End;



function InstallationCheck(var MajVer, MinVer : Byte;
           var MaxConn, ConnAviable : Word) : Byte;
function EstablishSPXConnection(RetryCount, WatchdogFlag : Byte;
           var E : ECBType; var AssignedIDConn : Word ) : Byte;
procedure ListenForSPXConnection(WatchDogFlag, RetryCount : Byte;
           var E : ECBType);
procedure TerminateSPXConnection(ConnID : Word; var E : ECBType);
procedure AbortSPXConnection(ConnID : Word);
function GetSPXConnectionStatus(ConnID : Word;
           var Buf : TSPXStatusBuffer) : Byte;
procedure SendSPXPacket(ConnID : Word; var E : ECBType);
procedure ListenForSPXPacket(ConnID : Word; var E : ECBType);


IMPLEMENTATION
uses DOS;

function InstallationCheck(var MajVer, MinVer : Byte;
 var MaxConn, ConnAviable : Word) : Byte;
var
  regs : registers;
begin
  regs.bx:=$0010;
  regs.al:=$00;

  intr($7A,regs);

  {
  00h if SPX not installed
  F0h if IPX not installed
  FFh if SPX loaded
  }

  InstallationCheck := regs.al;
  MajVer := regs.bh;
  MinVer := regs.bl;
  MaxConn:= regs.cx;
  ConnAviable := regs.dx;

end;

function EstablishSPXConnection(RetryCount, WatchdogFlag : Byte;
 var E : ECBType; var AssignedIDConn : Word ) : Byte;
var
  regs : registers;
begin
  regs.bx:=$0011;
  regs.al:=RetryCount;
  regs.ah:=WatchDogFlag;
  regs.es:=seg(E);
  regs.SI:=ofs(E);

  intr($7A,regs);

  EstablishSPXConnection := regs.al;
  AssignedIDConn := regs.dx;

end;

procedure ListenForSPXConnection(WatchDogFlag, RetryCount : Byte;
 var E : ECBType);
var
  regs : registers;
begin
  regs.bx:=$0012;
  regs.ah:=WatchDogFlag; { 00h disabled, 01h enabled }
  regs.al:=RetryCount;   {00h = default}
  regs.es:=seg(E);
  regs.SI:=ofs(E);

  intr($7A,regs);

end;

procedure TerminateSPXConnection(ConnID : Word; var E : ECBType);
var
  regs : registers;
begin
  regs.bx:=$0013;
  regs.dx:=ConnID;
  regs.es:=seg(E);
  regs.SI:=ofs(E);

  intr($7A,regs);

end;

procedure AbortSPXConnection(ConnID : Word);
var
  regs : registers;
begin
  regs.bx:=$0014;
  regs.dx:=ConnID;

  intr($7A,regs);

end;

function GetSPXConnectionStatus(ConnID : Word;
           var Buf : TSPXStatusBuffer) : Byte;
var
  regs : registers;
begin
  regs.bx:=$0015;
  regs.dx:=ConnID;
  regs.es:=seg(Buf);
  regs.SI:=ofs(Buf);

  intr($7A,regs);

  GetSPXConnectionStatus:=regs.al;

end;

procedure SendSPXPacket(ConnID : Word; var E : ECBType);
var
  regs : registers;
begin
  regs.bx:=$0016;
  regs.dx:=ConnID;
  regs.es:=seg(E);
  regs.SI:=ofs(E);

  intr($7A,regs);

end;

procedure ListenForSPXPacket(ConnID : Word; var E : ECBType);
var
  regs : registers;
begin
  regs.bx:=$0017;
  regs.dx:=ConnID; {unused in v2.15}
  regs.es:=seg(E);
  regs.SI:=ofs(E);

  intr($7A,regs);

end;



End.