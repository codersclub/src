VERSION 5.00
Begin VB.Form Form1 
   Caption         =   "HTML ���������"
   ClientHeight    =   3585
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   6390
   Icon            =   "Form1.frx":0000
   LinkTopic       =   "Form1"
   ScaleHeight     =   3585
   ScaleWidth      =   6390
   StartUpPosition =   3  'Windows Default
   Begin VB.TextBox Text3 
      Height          =   285
      Left            =   1800
      TabIndex        =   10
      Top             =   840
      Width           =   4455
   End
   Begin VB.TextBox Text2 
      Height          =   285
      Left            =   1800
      TabIndex        =   8
      Top             =   480
      Width           =   4455
   End
   Begin VB.TextBox Text1 
      Height          =   285
      Left            =   1800
      TabIndex        =   6
      Top             =   120
      Width           =   4455
   End
   Begin VB.DirListBox dirPathTo 
      Height          =   1440
      Left            =   3360
      TabIndex        =   4
      Top             =   1320
      Width           =   2895
   End
   Begin VB.DirListBox dirPathFrom 
      Height          =   1440
      Left            =   120
      TabIndex        =   3
      Top             =   1320
      Width           =   2895
   End
   Begin VB.CommandButton cmdGo 
      Caption         =   "Go!!!"
      Height          =   375
      Left            =   120
      TabIndex        =   2
      Top             =   3120
      Width           =   6135
   End
   Begin VB.TextBox txtPathTo 
      Height          =   285
      Left            =   3360
      TabIndex        =   1
      Text            =   "C:\��� ���������\htm"
      Top             =   2760
      Width           =   2895
   End
   Begin VB.TextBox txtPathFrom 
      Height          =   315
      Left            =   120
      TabIndex        =   0
      Text            =   "C:\��� ���������\FAQ"
      Top             =   2760
      Width           =   2895
   End
   Begin VB.Label Label3 
      Caption         =   "��� �����������"
      Height          =   255
      Left            =   120
      TabIndex        =   9
      Top             =   840
      Width           =   1575
   End
   Begin VB.Label Label2 
      Caption         =   "E-mail �����������"
      Height          =   255
      Left            =   120
      TabIndex        =   7
      Top             =   480
      Width           =   1575
   End
   Begin VB.Label Label1 
      Caption         =   "������"
      Height          =   255
      Left            =   120
      TabIndex        =   5
      Top             =   120
      Width           =   975
   End
End
Attribute VB_Name = "Form1"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Public FileNum As String

Private Sub cmdGo_Click()
  ' ������� ���� ����������
  Dim LineProto As String
  FileNum = 0
  Open txtPathTo.Text + "\index.html" For Append As #1
  Open App.Path & "\" & "Prototypefaqheader.htm" For Input As #4
  
  Do
    Line Input #4, LineProto
    If LineProto <> "<!-- Board -->" Then
      Print #1, LineProto
    End If
  Loop Until LineProto = "<!-- Board -->"
  
  Print #1, Text1.Text
  
  Do
    Line Input #4, LineProto
    If LineProto <> "<!-- Date -->" Then
      Print #1, LineProto
    End If
  Loop Until LineProto = "<!-- Date -->"
  
  Print #1, Date

  Do
    Line Input #4, LineProto
    If LineProto <> "<!-- Text -->" Then
      Print #1, LineProto
    End If
  Loop Until LineProto = "<!-- Text -->"
  
  Close #1
  GetDir txtPathFrom.Text
  Open txtPathTo.Text + "\index.html" For Append As #1
  
  Do
    Line Input #4, LineProto
    If LineProto <> "<!-- Email -->" Then
      Print #1, LineProto
    End If
  Loop Until LineProto = "<!-- Email -->"
  
  Print #1, Text2.Text
  
  Do
    Line Input #4, LineProto
    If LineProto <> "<!-- Nick -->" Then
      Print #1, LineProto
    End If
  Loop Until LineProto = "<!-- Nick -->"
  
  Print #1, Text3.Text
  
  Do
    Line Input #4, LineProto
    Print #1, LineProto
  Loop Until LineProto = "</html>"

  Close #1
  Close #4
  
  Unload Me
End Sub

Private Sub GetDir(DirName As String)

  Dim f%
  Dim FSO, file, folder, cfolder
  Dim i As Integer
  Set FSO = CreateObject("Scripting.FileSystemObject")
  Set cfolder = FSO.GetFolder(DirName)
  Open txtPathTo.Text + "\index.html" For Append As #5
  Print #5, "<UL>"
  Close #5
  For Each file In cfolder.Files
    If Right(file.Name, 4) = ".txt" Then
      Open txtPathTo.Text + "\index.html" For Append As #5
      Print #5, "<LI><A href=" & Chr(34) & "faq" & FileNum & ".htm" & Chr(34) & " > " & Left(file.Name, Len(file.Name) - 4) & "</A>"
      Close #5
      CreateHTM file.Path, "faq" & FileNum & ".htm"
      FileNum = FileNum + 1
    End If
  Next
  
  For Each folder In cfolder.SubFolders
    Open txtPathTo.Text + "\index.html" For Append As #5
    Print #5, "<LI>" & folder.Name
    Close #5
    GetDir folder.Path
  Next
  
  Open txtPathTo.Text + "\index.html" For Append As #5
  Print #5, "</UL>"
  Close #5
  
  Set cfolder = Nothing
  Set folder = Nothing
  Set file = Nothing
  Set FSO = Nothing

End Sub

Private Sub CreateHTM(TXTPath As String, HTMName As String)
  Dim linetxt As String
  Dim LineProto As String
  
  Dim f%, f1%
  Open txtPathTo.Text & "\" & HTMName For Append As #6
  Open TXTPath For Input As #2
  Open App.Path & "\" & "Prototypefaq.htm" For Input As #3
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Board -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Board -->"
  
  Print #6, Text1.Text
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Date -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Date -->"
  
  Print #6, Date
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Quest -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Quest -->"
  
  Line Input #2, linetxt
  Print #6, linetxt & "<BR>"
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Text -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Text -->"
  
  Do While Not EOF(2)
    Line Input #2, linetxt
    Print #6, linetxt & "<BR>"
  Loop
  Close #2
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Email -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Email -->"
  
  Print #6, Text2.Text
  
  Do
    Line Input #3, LineProto
    If LineProto <> "<!-- Nick -->" Then
      Print #6, LineProto
    End If
  Loop Until LineProto = "<!-- Nick -->"
  
  Print #6, Text3.Text
  
  Do
    Line Input #3, LineProto
    Print #6, LineProto
  Loop Until LineProto = "</html>"
  
  Close #6
  Close #3
  
End Sub

Private Sub dirPathFrom_Change()
  txtPathFrom.Text = dirPathFrom.Path
End Sub

Private Sub dirPathTo_Change()
  txtPathTo.Text = dirPathTo.Path
End Sub

Private Sub Form_Load()
  dirPathFrom.Path = "C:\��� ���������\"
  dirPathTo.Path = "C:\��� ���������\"
  txtPathFrom.Text = dirPathFrom.Path
  txtPathTo.Text = dirPathTo.Path
End Sub
