object Form1: TForm1
  Left = 190
  Top = 103
  Width = 696
  Height = 480
  Caption = 'Form1'
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  Menu = MainMenu1
  OldCreateOrder = False
  OnClose = FormClose
  OnCreate = FormCreate
  OnShow = FormShow
  PixelsPerInch = 96
  TextHeight = 13
  object Label1: TLabel
    Left = 0
    Top = 29
    Width = 688
    Height = 13
    Align = alTop
    Caption = '����������� ������'
  end
  object Label2: TLabel
    Left = 0
    Top = 139
    Width = 688
    Height = 13
    Align = alTop
    Caption = '������������������ ������'
  end
  object ListBox1: TListBox
    Left = 0
    Top = 42
    Width = 688
    Height = 97
    Align = alTop
    ItemHeight = 13
    TabOrder = 0
  end
  object ListBox2: TListBox
    Left = 0
    Top = 152
    Width = 688
    Height = 105
    Align = alTop
    ItemHeight = 13
    TabOrder = 1
  end
  object ToolBar1: TToolBar
    Left = 0
    Top = 0
    Width = 688
    Height = 29
    Caption = 'ToolBar1'
    TabOrder = 2
    object SpeedButton2: TSpeedButton
      Left = 0
      Top = 2
      Width = 84
      Height = 22
      Caption = 'Load Plugin'
      OnClick = LoadPlugin1Click
    end
    object SpeedButton1: TSpeedButton
      Left = 84
      Top = 2
      Width = 97
      Height = 22
      Caption = 'UnLoad Plugin'
      OnClick = UnloadPlugin1Click
    end
  end
  object MainMenu1: TMainMenu
    Left = 48
    Top = 68
    object File1: TMenuItem
      Caption = '&File'
      object LoadPlugin1: TMenuItem
        Caption = 'LoadPlugin'
        OnClick = LoadPlugin1Click
      end
      object UnloadPlugin1: TMenuItem
        Caption = 'UnloadPlugin'
        OnClick = UnloadPlugin1Click
      end
      object Options1: TMenuItem
        Caption = 'Options'
        OnClick = Options1Click
      end
    end
  end
  object Timer1: TTimer
    Interval = 15
    OnTimer = Timer1Timer
    Left = 108
    Top = 112
  end
end
