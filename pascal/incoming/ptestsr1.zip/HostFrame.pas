unit HostFrame;

interface

uses 
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  InterfacedForm, StdCtrls, Spin;

type
  TFrame1 = class(TInterfacedFrame, IOptionsFrame)
    Label1: TLabel;
    Edit1: TEdit;
    Edit2: TEdit;
    ComboBox1: TComboBox;
  private
    { Private declarations }
    function GetValue(Index: Integer): OleVariant;
    procedure SetValue(Index: Integer; const Value: OleVariant);
    function GetValueCount: Integer;
    function GetValueName(Index: Integer): String;
    function GetValueByName(AName: String): OleVariant;
    procedure SetValueByName(AName: String; Value: OleVariant);
    function GetKey: String;
    function GetValueIndex(AName: String): Integer;
  public
    { Public declarations }
    property Value[Index: integer]: OleVariant read GetValue write SetValue;
    property ValueName[Index: Integer]: String read GetValueName;
    property ValueByName[AName: String]: OleVariant read GetValueByName write SetValueByName;
    property ValueCount: integer read GetValueCount;
    property Key: String read GetKey;
  end;

implementation

{$R *.DFM}

{ TFrame1 }

function TFrame1.GetKey: String;
begin
 Result := 'TestIni';
end;

function TFrame1.GetValue(Index: Integer): OleVariant;
begin
 Case Index of
  0: Result := Edit1.Text;
  1: Result := Edit2.Text;
  2: Result := IntToStr(ComboBox1.ItemIndex);
  else Result := null;
 end;
end;

function TFrame1.GetValueByName(AName: String): OleVariant;
begin
 Result := Null;
end;

function TFrame1.GetValueCount: Integer;
begin
 Result := 3;
end;

function TFrame1.GetValueIndex(AName: String): Integer;
begin
 if AName = 'Edit1' Then Result := 0 else
 if AName = 'Edit2' Then Result := 1 else
 if AName = 'ComboBox1' Then Result := 2 else
  Result := -1;
end;

function TFrame1.GetValueName(Index: Integer): String;
begin
 Case Index of
  0: Result := Edit1.Name;
  1: Result := Edit2.Name;
  2: Result := ComboBox1.Name;
  else Result := '';
 end;
end;

procedure TFrame1.SetValue(Index: Integer; const Value: OleVariant);
begin
 Case Index of
  0: Edit1.Text := Value;
  1: Edit2.Text := Value;
  2: ComboBox1.ItemIndex := Value;
 end; 
end;

procedure TFrame1.SetValueByName(AName: String; Value: OleVariant);
begin
 SetValue(GetValueIndex(AName), Value); 
end;

initialization
 RegisterOptionsWindow(TFrame1, 'TFrame1', '�������� �����');
finalization
 UnRegisterOptionsWindow(TFrame1, 'TFrame1'); 
end.
