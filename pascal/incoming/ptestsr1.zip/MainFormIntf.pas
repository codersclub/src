unit MainFormIntf;

interface
uses Windows, Graphics, ExtCtrls, SysUtils, Buttons, Dialogs, ComCtrls, Menus,
  Classes, Forms, InterfacedForm, DlgIntF, DlgFormIntf;

type
  TOnRegisterClass = procedure(Sender: TObject; const AClassName: string)
    of object;
  TOnLoadModule = procedure(Sender: TObject; const AModuleName: string) of
    object;

  TOptionParam = packed record
    AClassName, ACaption: ShortString;
    ATabIdx: Integer;
  end;

  TOptionList = class(TList)
  public
    function Add(Item: TOptionParam): integer; reintroduce;
    procedure Delete(Index: Integer);
    procedure Clear; override;
    function IndexOf(Item: TOptionParam): integer; reintroduce;
    destructor Destroy; override;
  end;

  TMainForm = class(TInterfacedForm, IInterfacedForm)
  private
    FRegOnMenu: TOnRegisterClass;
    FUnRegOnMenu: TOnRegisterClass;
    FOnLoadModule: TOnLoadModule;
    FUnLoadModule: TOnLoadModule;
  protected
    FClassList: TStringList;
    FModuleList: TStringList;
    FOptionsList: TOptionList;
    FModuleLoad: boolean;
    OptionsWnd: TInterfacedFrame;
    OptionsClass: THostFrameClass;
    function GetClassTag(const AClassName: string): integer;
    function GetClassType(const AClassName: string): TClassType;
    function AddClassName(AType: TClassType; const AClassName: string): integer;
    //�������� ��� ������ � ������
    function GetClassName(Index: integer): string;
    // �������� ��� ������ �� �������
    procedure DeleteClassName(const AClassName: string); overload;
    // ������� ��� ������
    procedure DeleteClassName(Index: integer); overload;
    procedure AddMenuItem(AItem: TMenuItem; const AClassName, ACaption,
      AShortCut: string);
    procedure InsertMenuItem(AItem: TMenuItem; const Index: integer;
      const AClassName, ACaption, AShortCut: string);
    procedure DeleteMenuItem(AItem: TMenuItem; AClassName, ACaption: string);

    procedure AddButton(Bar: TToolBar; const AClassName, ABtnName, ACaption,
      AHint: string; ABitmap: TBitmap);

    procedure DeleteButton(Bar: TToolBar; const ABtnName: string);

    function AddOptions(const AClassName, ACaption: string): integer;
    procedure DeleteOptions(const AClassName: string);

    procedure OnMenuItemClick(Sender: TObject); // ����� ��� ����� �� ����
    procedure OnButtonClick(Sender: TObject);
    function LoadingModule(AModuleName: string): HResult;

  public
    constructor Create(AOwner: TComponent); override;
    destructor Destroy; override;
    function QueryInterface(const IID: TGUID; out Obj): HResult; override;
    function GetOptionsWindowName: string;
    procedure AddModule(AModuleName: string; hRes: HResult);
    procedure LoadModule;
    procedure UnloadModule(AModuleName: string);
    procedure CallModule(Sender: TObject; AType: TClassType; const AClassName:
      string);
      virtual; abstract;
    // ��������� ���������� ����� ������
    property OnRegisterClass: TOnRegisterClass read FRegOnMenu write FRegOnMenu;
    property OnUnRegisterClass: TOnRegisterClass read FUnRegOnMenu write
      FUnRegOnMenu;
    property OnLoadModule: TOnLoadModule read FOnLoadModule write FOnLoadModule;
    property OnUnloadModule: TOnLoadModule read FUnLoadModule write
      FUnLoadModule;
  published
  end; { TMainForm }

  TMainFormDialog = class(TMainForm, IInterfacedFormDialog)
  public
    function NewDialog: IDialogForm;
    function NewDialogCaption(const ACaption: string): IDialogForm;
  end;

implementation

procedure TMainForm.AddMenuItem(AItem: TMenuItem; const AClassName,
  ACaption, AShortCut: string);
var
  Tmp: TMenuItem;
  AType: TClassType;
begin
  AType := GetClassType(AClassName);
  if (AType = ftNoClass) or (AType = ftPopupForm) then
    begin
      MessageDlg('������ � ���������� ������!' + #13 + #10 +
        '����� ���������� �� ���� ����� ���� ��������' + #13 + #10 +
        '������ ��� ftNoForm, ftDialogForm, ftShowForm.', mtError, [mbCancel],
        0);
      Exit;
    end;
  Tmp := TMenuItem.Create(self);
  Tmp.Caption := ACaption;
  Tmp.ShortCut := TextToShortCut(AShortCut);
  Tmp.Tag := GetClassTag(AClassName);
  Tmp.OnClick := OnMenuItemClick;
  AItem.Add(Tmp);
end;

procedure TMainForm.AddButton(Bar: TToolBar; const AClassName, ABtnName,
  ACaption, AHint: string; ABitmap: TBitmap);
var
  Btn: TSpeedButton;
begin
  Btn := TSpeedButton.Create(Bar);
  with Btn do
    begin
      Caption := ACaption;
      Hint := AHint;
      if Assigned(ABitmap) then
        Glyph.Assign(ABitmap);
      Parent := Bar;
      Btn.Name := ABtnName;
      Btn.Tag := GetClassTag(AClassName);
      Btn.OnClick := OnButtonClick;
    end;
end;

procedure TMainForm.DeleteMenuItem(AItem: TMenuItem; AClassName,
  ACaption: string);
var
  Tmp: TMenuItem;
begin
  Tmp := AItem.Find(ACaption);
  if Tmp <> nil then
    AItem.Delete(Tmp.MenuIndex);
end;

procedure TMainForm.DeleteButton(Bar: TToolBar;
  const ABtnName: string);
var
  Btn: TSpeedButton;
begin
  if Bar.FindComponent(ABtnName) <> nil then
    if Bar.FindComponent(ABtnName) is TSpeedButton then
      begin
        Btn := TSpeedButton(Bar.FindComponent(ABtnName));
        Btn.Parent := nil;
        Bar.RemoveComponent(Btn);
        Btn.Free;
      end;
end;

procedure TMainForm.InsertMenuItem(AItem: TMenuItem; const Index: integer;
  const AClassName, ACaption, AShortCut: string);
var
  Tmp: TMenuItem;
  AType: TClassType;
begin
  AType := GetClassType(AClassName);
  if (AType = ftNoClass) or (AType = ftPopupForm) then
    begin
      MessageDlg('������ � ���������� ������!' + #13 + #10 +
        '����� ���������� �� ���� ����� ���� ��������' + #13 + #10 +
        '������ ��� ftNoForm, ftDialogForm, ftShowForm.', mtError, [mbCancel],
        0);
      Exit;
    end;
  Tmp := TMenuItem.Create(self);
  Tmp.Caption := ACaption;
  Tmp.ShortCut := TextToShortCut(AShortCut);
  Tmp.Tag := GetClassTag(AClassName);
  Tmp.OnClick := OnMenuItemClick;
  AItem.Insert(Index, Tmp);
end;

function TMainForm.AddClassName(AType: TClassType;
  const AClassName: string): integer;
begin
  FModuleLoad := True;
  Result := FClassList.IndexOf(AnsiLowerCase(AClassName));
  if Result = -1 then
    begin
      Result := FClassList.IndexOf('NoClass');
      if Result <> -1 then
        begin
          FClassList[Result] := AnsiLowerCase(AClassName);
          FClassList.Objects[Result] := Pointer(AType);
        end
      else
        begin
          FClassList.AddObject(AnsiLowerCase(AClassName), Pointer(AType));
          Result := FClassList.Count - 1;
        end;
      if Assigned(FRegOnMenu) then
        FRegOnMenu(self, AClassName);
    end;
end;

constructor TMainForm.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FClassList := TStringList.Create;
  FModuleList := TStringList.Create;
  FOptionsList := TOptionList.Create;
end;

procedure TMainForm.DeleteClassName(const AClassName: string);
var
  I: integer;
begin
  I := FClassList.IndexOf(AnsiLowerCase(AClassName));
  if I <> -1 then
    DeleteClassName(I);
end;

procedure TMainForm.DeleteClassName(Index: integer);
var
  S: string;
begin
  if (Index >= 0) and (Index < FClassList.Count) then
    begin
      S := FClassList[Index];
      FClassList[Index] := 'NoClass';
      FClassList.Objects[Index] := Pointer(ftNoClass);
      if Assigned(FUnRegOnMenu) then
        FUnRegOnMenu(Self, S);
    end;
end;

destructor TMainForm.Destroy;
begin
  FClassList.Free;
  FModuleList.Free;
  FOptionsList.Free;
  inherited Destroy;
end;

function TMainForm.GetClassName(Index: integer): string;
begin
  if (Index >= 0) and (Index < FClassList.Count) then
    Result := FClassList[Index]
  else
    Result := '';
end;

procedure TMainForm.OnMenuItemClick(Sender: TObject);
var
  S: string;
  AType: TClassType;
begin
  { ���������� ��� ����� �� ������ ���� }
  if Sender is TMenuItem then
    begin
      S := GetClassName(TMenuItem(Sender).Tag); //�������� ��� ������
      AType := GetClassType(S); // �������� ��� ������ ������
      if (S <> '') or (S <> 'NoClass') then
        CallModule(Sender, AType, S); // �������� �����
    end;
end;

procedure TMainForm.OnButtonClick(Sender: TObject);
var
  S: string;
  AType: TClassType;
begin
  if Sender is TSpeedButton then
    begin
      S := GetClassName(TSpeedButton(Sender).Tag); //�������� ��� ������
      AType := GetClassType(S); // �������� ��� ������ ������
      if (S <> '') or (S <> 'NoClass') then
        CallModule(Sender, AType, S); // �������� �����
    end;
end;

function TMainForm.QueryInterface(const IID: TGUID; out Obj): HResult;
begin
  Result := inherited QueryInterface(IID, Obj);
end;

function TMainForm.GetClassTag(const AClassName: string): integer;
begin
  Result := FClassList.IndexOf(AnsiLowerCase(AClassName));
end;

function TMainForm.GetClassType(const AClassName: string): TClassType;
var
  I: integer;
begin
  I := FClassList.IndexOf(AnsiLowerCase(AClassName));
  if I > -1 then
    Result := TClassType(FClassList.Objects[I])
  else
    Result := ftNoClass;
end;

procedure TMainForm.AddModule(AModuleName: string; hRes: HResult);
var
  I: integer;
begin
  i := FModuleList.IndexOf(AModuleName);
  if I = -1 then
    FModuleList.AddObject(AModuleName, Pointer(hRes));
  if Assigned(FOnLoadModule) then
    FOnLoadModule(Self, AModuleName);
end;

procedure TMainForm.LoadModule;
var
  SR: TSearchRec;
  I: integer;
  H: HResult;
begin
  I := FindFirst(ExtractFilePath(Application.ExeName) + '*.bpl', faAnyFile, SR);
  if I = 0 then
    begin
      H := LoadingModule(ExtractFilePath(Application.ExeName) + SR.Name);
      if H <> 0 then
        AddModule(GetPackageDescription(PChar(ExtractFilePath(Application.ExeName) + SR.Name)),
          H);
    end;
  while I = 0 do
    begin
      I := FindNext(SR);
      H := LoadingModule(ExtractFilePath(Application.ExeName) + SR.Name);
      if H <> 0 then
        AddModule(GetPackageDescription(PChar(ExtractFilePath(Application.ExeName) + SR.Name)),
          H);
    end;
  FindClose(SR);
end;

function TMainForm.LoadingModule(AModuleName: string): HResult;
begin
  Result := LoadPackage(AModuleName);
  if not FModuleLoad then
    begin
      UnloadPackage(Result);
      Result := 0;
    end
  else
    FModuleLoad := False;
end;

procedure TMainForm.UnloadModule(AModuleName: string);
var
  I: integer;
  H: HResult;
begin
  I := FModuleList.IndexOf(AModuleName);
  if I <> -1 then
    begin
      H := HResult(FModuleList.Objects[I]);
      if H <> 0 then
        UnloadPackage(H);
      FModuleList.Delete(I);
      if Assigned(FUnLoadModule) then
        FUnLoadModule(Self, AModuleName);
    end;
end;

function TMainForm.GetOptionsWindowName: string;
begin
  Result := '';
end;

function TMainForm.AddOptions(const AClassName, ACaption: string): integer;
var
  Param: TOptionParam;
begin
  Param.ACaption := ACaption;
  Param.AClassName := AnsiLowerCase(AClassName);
  Param.ATabIdx := -1;
  Result := FOptionsList.IndexOf(Param);
  if Result = -1 then
    begin
      FOptionsList.Add(Param);
      Result := FOptionsList.Count - 1;
      if Assigned(FRegOnMenu) then
        FRegOnMenu(self, AClassName);
    end;
end;

{ TOptionList }

function TOptionList.Add(Item: TOptionParam): integer;
var
  P: ^TOptionParam;
begin
  P := AllocMem(SizeOf(Item));
  P^.ACaption := Item.ACaption;
  P^.AClassName := Item.AClassName;
  P^.ATabIdx := Item.ATabIdx;
  result := inherited Add(P);
end;

procedure TOptionList.Clear;
var
  I: Integer;
begin
  for I := 0 to Count - 1 do
    FreeMem(Items[I], SizeOf(TOptionParam));
  inherited Clear;
end;

procedure TOptionList.Delete(Index: Integer);
begin
  if (Index > -1) and (Index < Count) then
    begin
      FreeMem(Items[Index], SizeOf(TOptionParam));
      inherited Delete(Index);
    end;
end;

destructor TOptionList.Destroy;
begin
  Clear;
  inherited Destroy;
end;

function TOptionList.IndexOf(Item: TOptionParam): integer;
var
  I: Integer;
begin
  Result := -1;
  for I := 0 to Count - 1 do
    if AnsiLowerCase(Item.AClassName) = TOptionParam(Items[I]^).AClassName then
      begin
        Result := i;
        break;
      end;
end;

procedure TMainForm.DeleteOptions(const AClassName: string);
var
  I: Integer;
  Param: ToptionParam;
begin
  Param.AClassName := AClassName;
  I := FOptionsList.IndexOf(Param);
  if I <> -1 then
    FOptionsList.Delete(I);
end;

{ TMainFormDialog }

function TMainFormDialog.NewDialog: IDialogForm;
begin
  Result := TDialogForm.Create(Self);
end;

function TMainFormDialog.NewDialogCaption(
  const ACaption: string): IDialogForm;
begin
  Result := DialogForm.Create(Self, ACaption);
end;

initialization

end.
