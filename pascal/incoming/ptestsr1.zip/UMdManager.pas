unit UMdManager;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  ComCtrls, StdCtrls, ExtCtrls, ActnList, ImgList, IBServices, InterfacedForm,
  DlgIntF;

type
  TSecuryForm = class(THostForm)
    Panel1: TPanel;
    PageControl1: TPageControl;
    TabSheet1: TTabSheet;
    TabSheet2: TTabSheet;
    lvListAllModules: TListView;
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    cbUser: TComboBox;
    ListView1: TListView;
    Button4: TButton;
    Button5: TButton;
    ActionList: TActionList;
    AAddModule: TAction;
    ADeleteModule: TAction;
    AEnabledPermis: TAction;
    ADisabledPermis: TAction;
    Button3: TButton;
    OpenMd: TOpenDialog;
    ImageList: TImageList;
    TabSheet3: TTabSheet;
    SecurityService: TIBSecurityService;
    UserList: TListBox;
    Button6: TButton;
    Button7: TButton;
    Button8: TButton;
    AAddUser: TAction;
    AChangeUser: TAction;
    ADeleteUser: TAction;
    procedure Button3Click(Sender: TObject);
    procedure AAddModuleExecute(Sender: TObject);
    procedure FormCreate(Sender: TObject);
    procedure AAddUserExecute(Sender: TObject);
    procedure ADeleteUserExecute(Sender: TObject);
    procedure ADeleteUserUpdate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  SecuryForm: TSecuryForm;

implementation

{$R *.DFM}

resourcestring

 SErrorInterfaceDlg = '������ ������� � ���������� ��������!'#13#10'��������� �� ���������.';
 SPassNotConfirm = '������ � ������������� �� ���������!'; 
 SConfirmDelUser = '�� ������������� ������ ������� ������������ %s?';
 
procedure TSecuryForm.Button3Click(Sender: TObject);
begin
 Close;
end;

procedure TSecuryForm.AAddModuleExecute(Sender: TObject);
begin
 OpenMd.InitialDir := ExtractFilePath(ParamStr(0));
 if OpenMd.Execute then {};
end;

procedure TSecuryForm.FormCreate(Sender: TObject);
Var I: Integer;
begin
 UserList.Clear;
 if not SecurityService.Active then
  SecurityService.Attach;
 SecurityService.DisplayUsers;
 for I := 0 to SecurityService.UserInfoCount - 1 do
  UserList.Items.Add(SecurityService.UserInfo[I].UserName);
 cbUser.Items.Assign(UserList.Items);
end;

procedure TSecuryForm.AAddUserExecute(Sender: TObject);
Var Dlg: IDialogForm;
    Int: IInterfacedFormDialog;
    K: Integer;
    I: Array of integer;
    UserName: String;
    Password: String;
begin
 if FMainForm <> nil then
  if Succeeded(FMainForm.QueryInterface(IInterfacedFormDialog, Int)) then
   begin
    Dlg := Int.NewDialog;
    Dlg.SetFormCaption('�������� ������������');
    SetLength(I, 3);
    Dlg.AddLabel('���', 10, 10);
    Dlg.AddLabel('������', 10, 40);
    Dlg.AddLabel('�������������', 10, 70);
    K := Canvas.TextWidth('W') * Length('�������������');
    I[0] := Dlg.AddEdit('', 'EUser', #0, K, 10, 100);
    TEdit(Dlg.GetControl(i[0])).CharCase := ecUpperCase;
    I[1] := Dlg.AddEdit('', 'EPassword', '*', K, 40, 100);
    I[2] := Dlg.AddEdit('', 'EConfirm', '*', K, 70, 100);
    Dlg.AddButton('Ok', 'bOk', 10, 100, 75, 25, mrOk);
    Dlg.AddButton('������', 'bCancel', K, 100, 75, 25, mrCancel);
    Dlg.FormSize;
    if Dlg.ExecuteDialog = mrOk then
     begin
      UserName := TEdit(Dlg.GetControl(I[0])).Text;
      Password := TEdit(Dlg.GetControl(I[1])).Text;
      if Password <> TEdit(Dlg.GetControl(I[2])).Text then
       MessageDlg(SPassNotConfirm, mtError, [mbOk], 0) else
        begin
         Screen.Cursor := crSQLWait;
         try
          SecurityService.UserName := UserName;
          SecurityService.Password := Password;
          SecurityService.AddUser;
          SecurityService.Detach;
          FormCreate(nil);
         finally
          Screen.Cursor := crDefault;         
         end;
        end;
     end;
    Dlg.FreeDialog;
   end else
    MessageDlg(SErrorInterfaceDlg,  mtError, [mbCancel], 0);
end;

procedure TSecuryForm.ADeleteUserExecute(Sender: TObject);
begin
if MessageDlg(format(SConfirmDelUser, [UserList.Items[UserList.ItemIndex]]),
 mtConfirmation, [mbYes, mbNo], 0) = mrNo then Exit;

 Screen.Cursor := crHourGlass;
try
 SecurityService.UserName := UserList.Items[UserList.ItemIndex];
 SecurityService.DeleteUser;
 SecurityService.Detach;
 FormCreate(nil);
finally
 Screen.Cursor := crDefault;
end; 
end;

procedure TSecuryForm.ADeleteUserUpdate(Sender: TObject);
begin
 TAction(Sender).Enabled := UserList.ItemIndex > -1;
end;

initialization
 RegisterModuleProc(TSecuryForm, ftDialogForm,'TSecuryForm');
 RegisterModuleInMenu('TSecuryForm', 'Security', 'Manager', '');
finalization
 UnRegisterModuleInMenu('TSecuryForm', 'Security', 'Manager');
 UnRegisterModuleProc(TSecuryForm, 'TSecuryForm');
end.
