object Form2: TForm2
  Left = 190
  Top = 103
  BorderStyle = bsDialog
  Caption = 'Form2'
  ClientHeight = 270
  ClientWidth = 470
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'MS Sans Serif'
  Font.Style = []
  OldCreateOrder = False
  Position = poOwnerFormCenter
  PixelsPerInch = 96
  TextHeight = 13
  object TabControl1: TTabControl
    Left = 0
    Top = 0
    Width = 470
    Height = 270
    Align = alClient
    TabOrder = 0
  end
end
