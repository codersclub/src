unit MainForm;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  Menus, InterfacedForm, DlgIntF, MainFormIntF, StdCtrls, ToolWin, ComCtrls,
  Buttons,
  ExtCtrls, IniFiles;

type
  TForm1 = class(TMainFormDialog, IFileMenu, IEditMenu,
      IMainMenu, IToolBars, IOptions)
    ListBox1: TListBox;
    ListBox2: TListBox;
    MainMenu1: TMainMenu;
    File1: TMenuItem;
    LoadPlugin1: TMenuItem;
    UnloadPlugin1: TMenuItem;
    ToolBar1: TToolBar;
    SpeedButton2: TSpeedButton;
    SpeedButton1: TSpeedButton;
    Options1: TMenuItem;
    Timer1: TTimer;
    Label1: TLabel;
    Label2: TLabel;
    procedure FormCreate(Sender: TObject);
    procedure LoadPlugin1Click(Sender: TObject);
    procedure UnloadPlugin1Click(Sender: TObject);
    procedure Options1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
  private
    { Private declarations }
    procedure _ReloadParam;
    procedure PLReloadParam(var Message: TMessage); message PL_RELOADPARAM;

    procedure RegOnMenu(Sender: TObject; const AClassName: string);
    procedure MLoad(Sender: TObject; const AModuleName: string);
    function GetToolBarCount: Integer;
    function GetToolBar(Index: Integer): TToolBar;
    function ToolBarByName(const AName: string): TToolBar;
    procedure TabChanged(Sender: TObject);
    function GetValueByName(AKey, AName: string): OleVariant;
    procedure SetValueByName(AKey, AName: string; Value: OleVariant);
  public
    { Public declarations }

    LoadSucceded: Boolean;
    function GetEditMenu: TMenuItem;
    function GetFileMenu: TMenuItem;
    function GetRecordMenu: TMenuItem;
    function GetMenu: TMenuItem;

    procedure CallModule(Sender: TObject; AType: TClassType; const AClassName:
      string); override;
  end;

var
  Form1: TForm1;

implementation
uses ComObj, OptionWnd, MainFrame;
{$R *.DFM}

{ TForm1 }

procedure TForm1.CallModule(Sender: TObject; AType: TClassType; const
  AClassName: string);
var
  frm: THostForm;
  FrmClass: THostFormClass;
  IPopup: IPopupForm;
  Value: Variant;
begin
  // ��� ��������� ������� � TInterfacedForm ��� �����������
  frmClass := THostFormClass(GetClass(AClassName));
  if Assigned(FrmClass) then
    begin
      frm := frmClass.Create(Self);
      try
        case AType of
          ftDialogForm:
            begin
              frm.ShowModal;
              frm.Free;
            end;
          ftShowForm: frm.Show;
          ftPopupForm:
            begin
              if Succeeded(frm.QueryInterface(IPopupForm, IPopup)) then
                begin
                  if Sender is TControl then
                    IPopup.ExecutePopup(TControl(Sender), Value);
                end
              else
                MessageDlg('������ � ��������������� ������ ������!'#13#10'����� �������� ��� ftPopup, �� ��� ������� � ���������� IPopupForm!',
                  mtError, [mbCancel], 0);
              frm.Free;
            end;
        end;
      finally
      end;
    end;
end;

function TForm1.GetEditMenu: TMenuItem;
begin
  Result := nil;
end;

function TForm1.GetFileMenu: TMenuItem;
begin
  Result := nil;
end;

function TForm1.GetMenu: TMenuItem;
begin
  Result := MainMenu1.Items;
end;

function TForm1.GetRecordMenu: TMenuItem;
begin
  Result := nil;
end;

procedure TForm1.RegOnMenu(Sender: TObject; const AClassName: string);
begin
  ListBox2.Items.Assign(FClassList);
  LoadSucceded := True;
end;

procedure TForm1.FormCreate(Sender: TObject);
begin
  OnRegisterClass := RegOnMenu;
  OnUnRegisterClass := RegOnMenu;
  OnLoadModule := MLoad;
  OnUnloadModule := MLoad;
  Caption := IntToStr(AllocMemSize);
  OptionsWnd := nil;
  _ReloadParam;
end;

function TForm1.GetToolBar(Index: Integer): TToolBar;
begin
  if Index = 1 then
    Result := ToolBar1
  else
    Result := nil;
end;

function TForm1.GetToolBarCount: Integer;
begin
  Result := 1;
end;

function TForm1.ToolBarByName(const AName: string): TToolBar;
begin
  if FindComponent(AName) is TToolBar then
    Result := TToolBar(FindComponent(AName))
  else
    Result := nil;
end;

procedure TForm1.LoadPlugin1Click(Sender: TObject);
begin
  LoadModule;
  Caption := IntToStr(AllocMemSize);
end;

procedure TForm1.UnloadPlugin1Click(Sender: TObject);
var
  S: string;
begin
  S := ListBox1.Items[ListBox1.ItemIndex];
  UnloadModule(S);
  Caption := IntToStr(AllocMemSize);
end;

procedure TForm1.MLoad(Sender: TObject; const AModuleName: string);
begin
  ListBox1.Items.Assign(FModuleList);
end;

procedure TForm1.Options1Click(Sender: TObject);
var
  I: Integer;
  Opt: IOptionsFrame;
begin
  Form2 := TForm2.Create(self);
  try
    // �������� �������� �������
    Form2.TabControl1.OnChange := TabChanged;
    for I := 0 to FOptionsList.Count - 1 do
      begin
        // ���������� ������ �������� � TabControle �� ������
        Form2.TabControl1.Tabs.Add(TOptionParam(FOptionsList.Items[I]^).ACaption);
        TOptionParam(FOptionsList.Items[I]^).ATabIdx :=
          Form2.TabControl1.Tabs.Count - 1;
      end;
    TabChanged(Form2.TabControl1);
    Form2.ShowModal;
  finally
    if Assigned(OptionsWnd) then
      begin
        if Succeeded(OptionsWnd.QueryInterface(IOptionsFrame, Opt)) then
          // ��������� ��������� � ��������� ������ ��� ������� � ���������
          begin
            for I := 0 to Opt.ValueCount - 1 do
              SetValueByName(Opt.Key, Opt.ValueName[I], Opt.Value[I]);
            // ��������� � ini
          end;
        for I := 0 to Screen.FormCount - 1 do
          SendMessage(Screen.Forms[I].Handle, PL_RELOADPARAM, 0, 0);
        // ��������� ��������� ���� ��������� ������ � ��������� ����������
        Opt := nil;
        OptionsWnd.Free;
      end;
    OptionsWnd := nil;
    Form2.Free;
  end;
end;

procedure TForm1.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  UnRegisterOptionsWindow(TFrame2, 'TFrame2');
end;

procedure TForm1.FormShow(Sender: TObject);
begin
  RegisterOptionsWindow(TFrame2, 'TFrame2', '�������� �����');
end;

procedure TForm1.TabChanged(Sender: TObject);
var
  I, K: Integer;
  Opt: IOptionsFrame;

begin
  if Assigned(OptionsWnd) then
    begin
      if Succeeded(OptionsWnd.QueryInterface(IOptionsFrame, Opt)) then
        // ��������� ��������� � ��������� ������ ��� ������� � ���������
        begin
          for I := 0 to Opt.ValueCount - 1 do
            SetValueByName(Opt.Key, Opt.ValueName[I], Opt.Value[I]);
          // ��������� � ini
        end;
      Opt := nil;
      OptionsWnd.Free;
    end;
  with TTabControl(Sender) do
    if TabIndex <> -1 then
      begin
        for I := 0 to FOptionsList.Count - 1 do
          if TOptionParam(FOptionsList.Items[I]^).ATabIdx = TabIndex then
            begin
              OptionsClass :=
                THostFrameClass(GetClass(TOptionParam(FOptionsList.Items[I]^).AClassName));
              // ��������� ����� ������ �� �����
              if not Assigned(OptionsClass) then
                Continue
              else
                begin
                  // ���������� ����� �� �����
                  OptionsWnd := OptionsClass.Create(TTabControl(Sender));
                  OptionsWnd.Parent := TTabControl(Sender);
                  OptionsWnd.Align := alClient;
                  if Succeeded(OptionsWnd.QueryInterface(IOptionsFrame, Opt))
                    then
                    begin
                      for K := 0 to Opt.ValueCount - 1 do
                        Opt.ValueByName[Opt.ValueName[K]] :=
                          GetValueByName(Opt.Key, Opt.ValueName[K]);
                      // ��������� ����������
                      Opt := nil;
                    end;
                  Break;
                end;
            end;
      end;
end;

procedure TForm1.Timer1Timer(Sender: TObject);
begin
  Caption := IntToStr(AllocMemSize);
end;

function TForm1.GetValueByName(AKey, AName: string): OleVariant;
var
  Ini: TIniFile;
begin
  Ini := TIniFile.Create(ExtractFilePath(ParamStr(0)) + 'HostPlugin.ini');
  try
    Result := Ini.ReadString(AKey, AName, '');
  finally
    Ini.Free;
  end;
end;

procedure TForm1.SetValueByName(AKey, AName: string; Value: OleVariant);
var
  Ini: TIniFile;
begin
  Ini := TIniFile.Create(ExtractFilePath(ParamStr(0)) + 'HostPlugin.ini');
  try
    Ini.WriteString(AKey, AName, Value);
  finally
    Ini.Free;
  end;
end;

procedure TForm1._ReloadParam;
begin
  ListBox1.Visible := GetValueByName('MainForm', 'CheckBox1');
  Label1.Visible := ListBox1.Visible;
  ListBox2.Visible := GetValueByName('MainForm', 'CheckBox2');
  Label2.Visible := ListBox2.Visible;
end;

procedure TForm1.PLReloadParam(var Message: TMessage);
begin
  _ReloadParam;
end;

initialization

end.

