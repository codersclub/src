unit DlgIntf;

interface
uses Classes;
type
  IDialogForm = interface
    ['{36DB5855-0387-4E73-92CC-1DDAA70B1D18}']
    procedure FormSize(const AWidth: Integer = 0; const AHeight: Integer = 0);
    procedure SetFormCaption(const ACaption: string);

    function AddCheckBox(const ACaption, AName: string; const ALeft, ATop:
      Integer):
      Integer;
    function AddRadioGroup(const ACaption, AName: string; const ALeft, ATop,
      AWidth, AHeight, ACol, AItemIdx: Integer; ACaptions: array of string):
      integer;
    function AddEdit(const AText, AName: string; const APasswordChar: Char; const ALeft, ATop, AWidth:
      Integer): integer;

    function AddButton(const ACaption, AName: string; const ALeft, ATop, AWidth,
      AHeight, AModalResult: Integer): Integer;

    function AddComboBox(const AText, AName: string; const ALeft, ATop,
      AWidth, AType, AItemIndex: Integer; AItems: array of string): Integer;

    function AddLabel(const ACaption: string; const ALeft, ATop: Integer):
      Integer;

    function GetClassType(const Index: Integer): TClass;
    function GetClassByName(const AName: string): TClass;
    function GetControlIndex(const AName: string): Integer;
    function GetControl(const Index: Integer): TComponent;
    function GetControlByName(const AName: string): TComponent;
    function IsCheckBox(const Index: Integer): Boolean;
    function IsRadioGroup(const Index: Integer): Boolean;
    function IsEdit(const Index: Integer): Boolean;

    function ExecuteDialog: integer;
    procedure FreeDialog;

    function IsComboBox(const Index: Integer): Boolean;
    function IsButton(const Index: Integer): Boolean;
    function IsLabel(const Index: Integer): Boolean;
  end;
implementation
end.

