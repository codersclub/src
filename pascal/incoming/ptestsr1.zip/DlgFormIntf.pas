unit DlgFormIntf;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  StdCtrls, ExtCtrls, InterfacedForm, DlgIntf;

type
  TDialogForm = class(TInterfacedForm, IDialogForm)
  private
    { Private declarations }
    FList: TList;
    procedure AutoWidth;
    procedure AutoHeight;
  public
    { Public declarations }
    function QueryInterface(const IID: TGUID; out Obj): HResult; override;
    constructor Create(AOwner: TComponent); reintroduce; overload;
    constructor Create(AOwner: TComponent; const ACaption: string); reintroduce;
      overload;
    destructor Destroy; override;

    { IDialogForm}
    procedure FormSize(const AWidth: Integer = 0; const AHeight: Integer = 0);
    procedure SetFormCaption(const ACaption: string);

    function AddCheckBox(const ACaption, AName: string; const ALeft, ATop:
      Integer):
      Integer;
    function AddRadioGroup(const ACaption, AName: string; const ALeft, ATop,
      AWidth, AHeight, ACol, AItemIdx: Integer; ACaptions: array of string):
      integer;
    function AddEdit(const AText, AName: string; const APasswordChar: Char; const
      ALeft, ATop, AWidth:
      Integer): integer;

    function AddButton(const ACaption, AName: string; const ALeft, ATop, AWidth,
      AHeight, AModalResult: Integer): Integer;

    function AddComboBox(const AText, AName: string; const ALeft, ATop,
      AWidth, AType, AItemIndex: Integer; AItems: array of string): Integer;

    function AddLabel(const ACaption: string; const ALeft, ATop: Integer):
      Integer;

    function GetClassType(const Index: Integer): TClass;
    function GetClassByName(const AName: string): TClass;
    function GetControlIndex(const AName: string): Integer;
    function GetControl(const Index: Integer): TComponent;
    function GetControlByName(const AName: string): TComponent;

    function ExecuteDialog: integer;
    procedure FreeDialog;

    function IsCheckBox(const Index: Integer): Boolean;
    function IsRadioGroup(const Index: Integer): Boolean;
    function IsEdit(const Index: Integer): Boolean;
    function IsComboBox(const Index: Integer): Boolean;
    function IsButton(const Index: Integer): Boolean;
    function IsLabel(const Index: Integer): Boolean;
  end;

var
  DialogForm: TDialogForm;

implementation

{$R *.DFM}

{ TForm2 }

function TDialogForm.AddButton(const ACaption, AName: string; const ALeft, ATop,
  AWidth, AHeight, AModalResult: Integer): Integer;
var
  Btn: TButton;
begin
  try
    Btn := TButton.Create(Self);
    with btn do
      begin
        Parent := Self;
        Left := ALeft;
        Top := ATop;
        if AWidth = 0 then
          Width := 75
        else
          Width := AWidth;
        if AHeight = 0 then
          Height := 25
        else
          Height := AHeight;
        ModalResult := AModalResult;
        if AModalResult = mrCancel then
          Cancel := True;
        Caption := ACaption;
        Name := AName;
      end;
    try
      FList.Add(Btn);
      result := FList.Count - 1;
    except
      Result := -1;
      Btn.Free;
    end;
  except
    Result := -1;
  end;
end;

function TDialogForm.AddCheckBox(const ACaption, AName: string; const ALeft,
  ATop: Integer): Integer;
var
  CB: TCheckBox;
begin
  CB := TCheckBox.Create(Self);
  try
    with CB do
      begin
        Left := ALeft;
        Top := ATop;
        Caption := ACaption;
        Parent := Self;
        Name := AName;
      end;
    try
      FList.Add(CB);
      Result := FList.Count - 1;
    except
      CB.Free;
      Result := -1;
    end;
  except
    CB.Free;
    Result := -1;
  end;
end;

function TDialogForm.AddComboBox(const AText, AName: string; const ALeft,
  ATop, AWidth, AType, AItemIndex: Integer; AItems: array of string): Integer;
var
  CB: TComboBox;
  I: Integer;
begin
  CB := TComboBox.Create(Self);
  try
    with Cb do
      begin
        Parent := Self;
        Left := ALeft;
        Top := ATop;
        Width := AWidth;
        Height := 25;
        Style := TComboBoxStyle(AType);
        Name := AName;
        for I := Low(AItems) to High(AItems) do
          Items.Add(AItems[I]);
        if AItemIndex <= (High(AItems) - Low(AItems)) then
          ItemIndex := AItemIndex
        else
          ItemIndex := -1;
        if ItemIndex = -1 then
          Text := AText;
      end;
    try
      FList.Add(CB);
      Result := FList.Count - 1;
    except
      CB.Free;
      Result := -1;
    end;
  except
    CB.Free;
    Result := -1;
  end;
end;

function TDialogForm.AddEdit(const AText, AName: string; const APasswordChar:
  Char; const ALeft, ATop,
  AWidth: Integer): integer;
var
  Edit: TEdit;
begin
  Edit := TEdit.Create(Self);
  try
    with Edit do
      begin
        Parent := Self;
        Left := ALeft;
        Top := ATop;
        Width := AWidth;
        Name := AName;
        PasswordChar := APasswordChar;
        if AText <> '' then
          Text := AText
        else
          Text := '';
      end;
    try
      FList.Add(Edit);
      Result := FList.Count - 1;
    except
      Edit.Free;
      Result := -1;
    end;
  except
    Edit.Free;
    Result := -1;
  end;
end;

function TDialogForm.AddLabel(const ACaption: string; const ALeft,
  ATop: Integer): Integer;
var
  LB: TLabel;
begin
  LB := TLabel.Create(self);
  try
    with LB do
      begin
        Caption := ACaption;
        Left := ALeft;
        Top := ATop;
        Parent := Self;
      end;
    try
      FList.Add(LB);
      Result := Flist.Count - 1;
    except
      Result := -1;
      LB.Free;
    end;
  except
    LB.Free;
    Result := -1;
  end;
end;

function TDialogForm.AddRadioGroup(const ACaption, AName: string; const ALeft,
  ATop, AWidth, AHeight, ACol, AItemIdx: Integer; ACaptions: array of string):
  integer;
var
  RG: TRadioGroup;
  I: Integer;
begin
  if Length(ACaptions) > 0 then
    begin
      RG := TRadioGroup.Create(Self);
      try
        with RG do
          begin
            Left := ALeft;
            Top := ATop;
            Height := AHeight;
            Width := AWidth;
            Columns := ACol;
            Parent := Self;
            Caption := ACaption;
            Name := AName;
            for I := Low(ACaptions) to High(ACaptions) do
              Items.Add(ACaptions[I]);
            if AItemIdx <= (High(ACaptions) - Low(ACaptions)) then
              ItemIndex := AItemIdx
            else
              ItemIndex := -1;

          end;
        try
          FList.Add(RG);
          Result := FList.Count - 1;
        except
          RG.Free;
          Result := -1;
        end;
      except
        Result := -1;
        RG.Free;
      end;
    end
  else
    Result := -1;
end;

procedure TDialogForm.AutoHeight;
var
  I: Integer;
  X: Integer;
begin
  X := 0;
  for I := 0 to ComponentCount - 1 do
    if (TControl(Components[I]).Top + TControl(Components[I]).Height) > X then
      X := TControl(Components[I]).Top + TControl(Components[I]).Height;
  if X <> 0 then
    Self.ClientHeight := X + 10;
end;

procedure TDialogForm.AutoWidth;
var
  I: Integer;
  X: Integer;
begin
  X := 0;
  for I := 0 to ComponentCount - 1 do
    if (TControl(Components[I]).Width + TControl(Components[I]).Left) > X then
      X := TControl(Components[I]).Width + TControl(Components[I]).Left;
  if X <> 0 then
    Self.Width := X + 10;
end;

constructor TDialogForm.Create(AOwner: TComponent; const ACaption: string);
begin
  inherited Create(AOwner);
  FList := TList.Create;
  Caption := ACaption;
end;

constructor TDialogForm.Create(AOwner: TComponent);
begin
  inherited Create(AOwner);
  FList := TList.Create;
end;

destructor TDialogForm.Destroy;
var
  I: Integer;
begin
  for I := 0 to FList.Count - 1 do
    TComponent(FList[i]).Free;
  FList.Free;
  inherited Destroy;

end;

function TDialogForm.ExecuteDialog: integer;
begin
  Result := ShowModal;
end;

procedure TDialogForm.FormSize(const AWidth: Integer = 0; const AHeight: Integer
  =
  0);
begin
  if AHeight = 0 then
    AutoHeight
  else
    Self.Height := AHeight;
  if AWidth = 0 then
    AutoWidth
  else
    Self.Width := AWidth;
end;

procedure TDialogForm.FreeDialog;
begin
  Self.Free;
end;

function TDialogForm.GetClassByName(const AName: string): TClass;
var
  I: Integer;
begin
  result := nil;
  for I := 0 to FList.Count - 1 do
    if AnsiUpperCase(AName) = AnsiUpperCase(TComponent(FList[I]).Name) then
      begin
        Result := TComponent(FList[I]).ClassType;
        break;
      end;

end;

function TDialogForm.GetClassType(const Index: Integer): TClass;
begin
  if (Index <> -1) and (Index < FList.Count) then
    Result := TComponent(FList[Index]).ClassType
  else
    Result := nil;
end;

function TDialogForm.GetControl(const Index: Integer): TComponent;
begin
  if (Index <> -1) and (Index < FList.Count) then
    Result := TComponent(FList[Index])
  else
    Result := nil;
end;

function TDialogForm.GetControlByName(const AName: string): TComponent;
var
  I: Integer;
begin
  I := GetControlIndex(AName);
  if I <> -1 then
    Result := GetControl(I)
  else
    Result := nil;
end;

function TDialogForm.GetControlIndex(const AName: string): Integer;
var
  I: Integer;
begin
  Result := -1;
  for I := 0 to FList.Count - 1 do
    if AnsiUpperCase(AName) = AnsiUpperCase(TComponent(FList[I]).Name) then
      begin
        Result := I;
        break;
      end;
end;

function TDialogForm.IsButton(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TButton'
  else
    Result := False;
end;

function TDialogForm.IsCheckBox(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TCheckBox'
  else
    Result := False;
end;

function TDialogForm.IsComboBox(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TComboBox'
  else
    Result := False;
end;

function TDialogForm.IsEdit(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TEdit'
  else
    Result := False;
end;

function TDialogForm.IsLabel(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TLabel'
  else
    Result := False;
end;

function TDialogForm.IsRadioGroup(const Index: Integer): Boolean;
var
  AClass: TClass;
begin
  AClass := GetClassType(Index);
  if AClass <> nil then
    Result := AClass.ClassName = 'TRadioGroup'
  else
    Result := False;
end;

function TDialogForm.QueryInterface(const IID: TGUID; out Obj): HResult;
begin
  result := inherited QueryInterface(IID, Obj);
end;

procedure TDialogForm.SetFormCaption(const ACaption: string);
begin
  Caption := ACaption;
end;

end.
