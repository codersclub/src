unit MainFrame;

interface

uses
  Windows, Messages, SysUtils, Classes, Graphics, Controls, Forms, Dialogs,
  InterfacedForm, StdCtrls;

type
  TFrame2 = class(TInterfacedFrame, IOptionsFrame)
    Label1: TLabel;
    CheckBox1: TCheckBox;
    CheckBox2: TCheckBox;
  private
    { Private declarations }
    function GetValue(Index: Integer): OleVariant;
    procedure SetValue(Index: Integer; const Value: OleVariant);
    function GetValueCount: Integer;
    function GetValueName(Index: Integer): string;
    procedure SetValueByName(AName: string; Value: OleVariant);
    function GetValueByName(AName: string): OleVariant;
    function GetKey: string;
    function GetValueIndex(AName: string): Integer;

  public
    { Public declarations }
    property Value[Index: integer]: OleVariant read GetValue write SetValue;
    property ValueName[Index: Integer]: string read GetValueName;
    property ValueByName[AName: string]: OleVariant read GetValueByName write
    SetValueByName;
    property ValueCount: integer read GetValueCount;
    property Key: string read GetKey;

  end;

implementation

{$R *.DFM}
{ TFrame2 }

function TFrame2.GetKey: string;
begin
  Result := 'MainForm';
end;

function TFrame2.GetValue(Index: Integer): OleVariant;
begin
  case Index of
    0: Result := CheckBox1.Checked;
    1: Result := CheckBox2.Checked;
  end;
end;

function TFrame2.GetValueByName(AName: string): OleVariant;
begin
  Result := GetValue(GetValueIndex(AName));
end;

function TFrame2.GetValueCount: Integer;
begin
  Result := 2;
end;

function TFrame2.GetValueIndex(AName: string): Integer;
begin
  if AName = 'CheckBox1' then
    Result := 0
  else if AName = 'CheckBox2' then
    Result := 1
  else
    Result := -1;
end;

function TFrame2.GetValueName(Index: Integer): string;
begin
  case Index of
    0: Result := CheckBox1.Name;
    1: Result := CheckBox2.Name;
  end;
end;

procedure TFrame2.SetValue(Index: Integer; const Value: OleVariant);
begin
  case Index of
    0: CheckBox1.Checked := Value;
    1: CheckBox2.Checked := Value;
  end;
end;

procedure TFrame2.SetValueByName(AName: string; Value: OleVariant);
begin
  SetValue(GetValueIndex(AName), Value);
end;

initialization

finalization

end.

