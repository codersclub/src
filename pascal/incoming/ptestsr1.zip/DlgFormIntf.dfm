object DialogForm: TDialogForm
  Left = 244
  Top = 107
  BorderStyle = bsDialog
  Caption = 'DialogForm'
  ClientHeight = 453
  ClientWidth = 688
  Color = clBtnFace
  Font.Charset = RUSSIAN_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  Position = poMainFormCenter
  PixelsPerInch = 96
  TextHeight = 13
end
