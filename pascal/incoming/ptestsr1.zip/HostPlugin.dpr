program HostPlugin;

uses
  Forms,
  MainForm in 'MainForm.pas' {Form1},
  InterfacedForm in 'InterfacedForm.pas',
  MainFormIntf in 'MainFormIntf.pas',
  OptionWnd in 'OptionWnd.pas' {Form2},
  MainFrame in 'MainFrame.pas' {Frame2: TFrame},
  DlgFormIntf in 'DlgFormIntf.pas' {DialogForm};

{$R *.RES}

begin
  Application.Initialize;
  Application.CreateForm(TForm1, Form1);
  Application.Run;
end.

