unit InterfacedForm;

interface

uses Forms, Menus, Windows, Classes, SysUtils, ComCtrls, Buttons, Graphics,
  Dialogs, Controls, Messages, DlgIntF;

const
  PL_RELOADPARAM = WM_USER + $777; // ������������ ����������

type
  TClassType = (ftNoClass, ftNoForm, ftShowForm, ftDialogForm, ftPopupForm);

  IFileMenu = interface // ��������� � ������� File
    ['{87A65239-BE28-403B-A08C-44455EC3CAF6}']
    function GetFileMenu: TMenuItem;
    property FileMenu: TMenuItem read GetFileMenu;
  end;

  IEditMenu = interface // ��������� � ������� Edit
    ['{6F8AF60E-E51C-44A9-A12A-84E6063D43AC}']
    function GetEditMenu: TMenuItem;
    property EditMenu: TMenuItem read GetEditMenu;
  end;

  IMainMenu = interface // ��������� � ��������� ����
    ['{73633932-ED4B-4FC1-8BF0-CD2C79248784}']
    function GetMenu: TMenuItem;
  end;

  IToolBars = interface // ��������� � ������ ������
    ['{3192C04F-5BF0-45ED-8147-A619EC3DCA2D}']
    function GetToolBarCount: integer;
    function GetToolBar(Index: integer): TToolBar;
    function ToolBarByName(const AName: string): TToolBar;

    property Count: integer read GetToolBarCount;
    property ToolBars[Index: integer]: TToolBar read GetToolBar;

  end;

  IOptions = interface
    // ��������� � �������� ����� ��� ����������/�������������� ����������
    ['{27A3A93F-3667-4F65-921D-6ED8023559E2}']
    function GetValueByName(AKey, AName: string): OleVariant;
    procedure SetValueByName(AKey, AName: string; Value: OleVariant);
  end;

  IInterfacedForm = interface // ��������� � �����
    ['{6D2D0DE0-2B07-408B-97A5-DF351FB6ECA1}']
    function GetOptionsWindowName: string;
    function GetClassType(const AClassName: string): TClassType;
    function AddClassName(AType: TClassType; const AClassName: string): integer;
    procedure DeleteClassName(Index: integer); overload;
    procedure DeleteClassName(const AClassName: string); overload;
    procedure AddMenuItem(AItem: TMenuItem; const AClassName, ACaption,
      AShortCut: string);
    procedure InsertMenuItem(AItem: TMenuItem; const Index: integer;
      const AClassName, ACaption, AShortCut: string);
    procedure DeleteMenuItem(AItem: TMenuItem; AClassName, ACaption: string);

    procedure AddButton(Bar: TToolBar; const AClassName, ABtnName, ACaption,
      AHint: string; ABitmap: TBitmap);

    procedure DeleteButton(Bar: TToolBar; const ABtnName: string);

    function AddOptions(const AClassName, ACaption: string): integer;
    procedure DeleteOptions(const AClassName: string);
  end; { IInterfacedForm }

  IInterfacedFormDialog = interface(IInterfacedForm)
    // ��������� � ����� � ������������� ��������
    ['{3A1774DF-F9B1-4FE6-9C52-8AC50724FCA1}']
    function NewDialog: IDialogForm;
    function NewDialogCaption(const ACaption: string): IDialogForm;
  end;

  IOptionsFrame = interface // ��������� � ������ ��������
    ['{869405B7-F8C0-4617-96B9-E56DD042B9BA}']
    // ��� �������� �������� ����� ������������ OleVariant, ������-�� ���������� ��������
    function GetValue(Index: Integer): OleVariant;
    procedure SetValue(Index: Integer; const Value: OleVariant);
    function GetValueCount: Integer;
    function GetValueName(Index: Integer): string;
    procedure SetValueByName(AName: string; Value: OleVariant);
    function GetValueByName(AName: string): OleVariant;
    function GetKey: string;
    function GetValueIndex(AName: string): Integer;

    property Value[Index: integer]: OleVariant read GetValue write SetValue;
    property ValueName[Index: Integer]: string read GetValueName;
    property ValueByName[AName: string]: OleVariant read GetValueByName write
    SetValueByName;
    property ValueCount: integer read GetValueCount;
    property Key: string read GetKey;
  end;

  IPopupForm = interface // ��������� ����������� �����
    ['{B44F1EC5-41DA-4CD0-87A5-252291DC5F83}']
    function ExecutePopup(HostCtl: TControl; var Value: Variant): integer;
  end;

  IProjectInfo = interface(IOptionsFrame) // ���������� (���� �����)
    ['{891465E2-D25E-4487-98BC-66939035BEB1}']
    function GetAuthor: string;
    function GetCopyright: string;
    function Describe: string;
    function Version: integer;
  end;

type

  TInterfacedForm = class(TForm)
  public
    function QueryInterface(const IID: TGUID; out obj): HResult; override;
  end;

  THostForm = class(TForm)
  protected
    FMainForm: IInterfacedForm;
  public
    constructor Create(AOwner: TComponent); override;
    function QueryInterface(const IID: TGUID; out Obj): HResult; override;
    property MainForm: IInterfacedForm read FMainForm;
  end; { THostForm }

  TInterfacedFrame = class(TFrame)
  public
    function QueryInterface(const IID: TGUID; out obj): HResult; override;
  end;

  TIntfFormClass = class of TInterfacedForm;
  THostFormClass = class of THostForm;
  THostFrameClass = class of TInterfacedFrame;

procedure AdjustDropDownForm(AControl: TControl; HostControl: TControl);

procedure RegisterModuleProc(AClass: TPersistentClass; AType: TClassType;
  const AClassName: string);
procedure UnRegisterModuleProc(AClass: TPersistentClass; const AClassName:
  string);

procedure RegisterModuleInMenu(const AClassName: string; AParent, ACaption,
  AShortCut: string);
procedure UnRegisterModuleInMenu(const AClassName: string; AParent, ACaption:
  string);

procedure RegisterModuleInToolBar(const AClassName: string; AName, ABtnName,
  ACaption,
  AHint: string; ABitmap: TBitmap);

procedure UnregisterModuleInToolBar(const AClassName, AName, ABtnName: string);

procedure RegisterOptionsWindow(AClass: TPersistentClass; const AClassName,
  AName: string);
procedure UnRegisterOptionsWindow(AClass: TPersistentClass; const AClassName:
  string);

implementation

type
  EMenuItemNotFound = class(Exception);
  EMainMenuNotFound = class(Exception);

procedure AdjustDropDownForm(AControl: TControl; HostControl: TControl);
var
  WorkArea: TRect;
  HostP, PDelpta: TPoint;
begin
  SystemParametersInfo(SPI_GETWORKAREA, 0, @WorkArea, 0);
  HostP := HostControl.ClientToScreen(Point(0, 0));
  PDelpta := AControl.ClientToScreen(Point(0, 0));

  AControl.Left := HostP.x;
  AControl.Top := HostP.y + HostControl.Height + 1;

  if (AControl.Width > WorkArea.Right - WorkArea.Left) then
    AControl.Width := WorkArea.Right - WorkArea.Left;

  if (AControl.Left + AControl.Width > WorkArea.Right) then
    AControl.Left := WorkArea.Right - AControl.Width;
  if (AControl.Left < WorkArea.Left) then
    AControl.Left := WorkArea.Left;

  if (AControl.Top + AControl.Height > WorkArea.Bottom) then
    begin
      if (HostP.y - WorkArea.Top > WorkArea.Bottom - HostP.y -
        HostControl.Height) then
        AControl.Top := HostP.y - AControl.Height;
    end;

  if (AControl.Top < WorkArea.Top) then
    begin
      AControl.Height := AControl.Height - (WorkArea.Top - AControl.Top);
      AControl.Top := WorkArea.Top;
    end;

  if (AControl.Top + AControl.Height > WorkArea.Bottom) then
    begin
      AControl.Height := WorkArea.Bottom - AControl.Top;
    end;
end;

procedure MenuItemNotFound(ACaption: string);
begin
  raise EMenuItemNotFound.CreateFmt('�� ������ ����� ���� "%s"!', [ACaption]);
end;

procedure MainMenuNotFound;
begin
  raise EMainMenuNotFound.Create('�� ������� �������� ����!');
end;

function IsModuleRegister(AClassName: string): boolean;
begin
  Result := Assigned(GetClass(AClassName));
end;

procedure RegisterModuleProc(AClass: TPersistentClass; AType: TClassType;
  const AClassName: string);
var
  HostForm: IInterfacedForm;
begin
  if not IsModuleRegister(AClassName) then
    begin
      if Application.MainForm.InheritsFrom(TInterfacedForm) then
        if
          Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
          HostForm.AddClassName(AType, AClassName);
      RegisterClass(AClass);
    end;
end;

procedure UnRegisterModuleProc(AClass: TPersistentClass; const AClassName:
  string);
var
  HostForm: IInterfacedForm;
begin
  if IsModuleRegister(AClassName) then
    begin
      if Application.MainForm.InheritsFrom(TInterfacedForm) then
        if
          Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
          HostForm.DeleteClassName(AClassName);
      UnregisterClass(AClass);
    end;
end;

procedure RegisterOptionsWindow(AClass: TPersistentClass; const AClassName,
  AName: string);
var
  HostForm: IInterfacedForm;
  Options: IOptions;
begin
  if AClass.InheritsFrom(TInterfacedFrame) then
    if not IsModuleRegister(AClassName) then
      begin
        if Application.MainForm.InheritsFrom(TInterfacedForm) then
          if
            Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
            if
              Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IOptions, Options)) then
              begin
                HostForm.AddOptions(AClassName, AName);
                RegisterClass(AClass);
              end;
      end;
end;

procedure UnRegisterOptionsWindow(AClass: TPersistentClass; const AClassName:
  string);
var
  HostForm: IInterfacedForm;
begin
  if AClass.InheritsFrom(TInterfacedFrame) then
    if IsModuleRegister(AClassName) then
      begin
        if Application.MainForm.InheritsFrom(TInterfacedForm) then
          if
            Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
            HostForm.DeleteOptions(AClassName);
        UnregisterClass(AClass);
      end;
end;

procedure RegisterModuleInToolBar(const AClassName: string; AName, ABtnName,
  ACaption,
  AHint: string; ABitmap: TBitmap);
var
  HostForm: IInterfacedForm;
  IBar: IToolBars;
begin
  if not IsModuleRegister(AClassName) then
    Exit;
  if Application.MainForm.InheritsFrom(TInterfacedForm) then
    if
      Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
      begin
        if Succeeded(HostForm.QueryInterface(IToolBars, IBar)) then
          if IBar.ToolBarByName(AName) <> nil then
            HostForm.AddButton(IBar.ToolBarByName(AName), AClassName, ABtnName,
              ACaption, AHint, ABitmap);
      end;
end;

procedure UnregisterModuleInToolBar(const AClassName, AName, ABtnName: string);
var
  HostForm: IInterfacedForm;
  IBar: IToolBars;
begin
  if not IsModuleRegister(AClassName) then
    Exit;
  if Application.MainForm.InheritsFrom(TInterfacedForm) then
    if
      Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
      begin
        if Succeeded(HostForm.QueryInterface(IToolBars, IBar)) then
          if IBar.ToolBarByName(AName) <> nil then
            HostForm.DeleteButton(IBar.ToolBarByName(AName), ABtnName);
      end;
end;

procedure RegisterModuleInMenu(const AClassName: string; AParent, ACaption,
  AShortCut: string);
var
  HostForm: IInterfacedForm;
  IMenu: IMainMenu;
  IForm: IInterfacedForm;
  Tmp: TMenuItem;
  S: string;
  AType: TClassType;
begin
  if not IsModuleRegister(AClassName) then
    exit;
  if Application.MainForm.InheritsFrom(TInterfacedForm) then
    if
      Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
      begin
        AType := HostForm.GetClassType(AClassName);
        if (AType = ftNoClass) or (AType = ftPopupForm) then
          begin
            MessageDlg('������ � ���������� ������!' + #13 + #10 +
              '����� ���������� �� ���� ����� ���� ��������' + #13 + #10 +
              '������ ��� ftNoForm, ftDialogForm, ftShowForm.', mtError,
              [mbCancel], 0);
            Exit;
          end;
        if Succeeded(HostForm.QueryInterface(IMainMenu, IMenu)) then
          if IMenu.GetMenu <> nil then
            begin
              if AParent = '' then
                begin
                  Tmp := TMenuItem.Create(Application);
                  Tmp.Caption := S;
                  IMenu.GetMenu.Add(Tmp);
                end
              else
                begin
                  Tmp := IMenu.GetMenu.Find(AParent);
                  if Tmp = nil then
                    begin
                      Tmp := TMenuItem.Create(Application);
                      Tmp.Caption := AParent;
                      IMenu.GetMenu.Add(Tmp);
                    end;
                end;
              if Tmp = nil then
                MenuItemNotFound(AParent);
              if Succeeded(HostForm.QueryInterface(IInterfacedForm, IForm)) then
                IForm.AddMenuItem(Tmp, AClassName, ACaption, AShortCut);
            end
          else
            MainMenuNotFound;
      end;
end;

procedure UnRegisterModuleInMenu(const AClassName: string; AParent, ACaption:
  string);
var
  HostForm: IInterfacedForm;
  IMenu: IMainMenu;
  IForm: IInterfacedForm;
  Tmp: TMenuItem;
begin
  if not IsModuleRegister(AClassName) then
    Exit;
  if Application.MainForm.InheritsFrom(TInterfacedForm) then
    if
      Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm, HostForm)) then
      begin
        if Succeeded(HostForm.QueryInterface(IMainMenu, IMenu)) then
          begin
            if IMenu.GetMenu <> nil then
              begin
                Tmp := IMenu.GetMenu.Find(AParent);
                if Tmp <> nil then
                  if Succeeded(HostForm.QueryInterface(IInterfacedForm, IForm))
                    then
                    IForm.DeleteMenuItem(Tmp, AClassName, ACaption);
              end
            else
              MainMenuNotFound;
          end;
      end;
end;

{ THostForm }

constructor THostForm.Create(AOwner: TComponent);
begin
  FMainForm := nil;
  inherited Create(AOwner);
  if Application.MainForm is TInterfacedForm then
    if not
      Succeeded(TInterfacedForm(Application.MainForm).QueryInterface(IInterfacedForm,
      FMainForm)) then
      FMainForm := nil;
end;

function THostForm.QueryInterface(const IID: TGUID; out Obj): HResult;
begin
  Result := inherited QueryInterface(IID, Obj);
end;

{ TIntefacedForm }

function TInterfacedForm.QueryInterface(const IID: TGUID; out obj): HResult;
begin
  Result := inherited QueryInterface(IID, Obj);
end;

{ TOptionsWindow }

function TInterfacedFrame.QueryInterface(const IID: TGUID; out obj): HResult;
begin
  Result := inherited QueryInterface(IID, Obj);
end;

end.

