{*****************************************************************************
*                              Naphy Video Unit                              *
*                                Version: 2.0                                *
*****************************************************************************}

Unit NVideo;

{----------} Interface {----------}

Uses
  Crt, Dos;

Type

  TVideoMode = Object
    Procedure VGA640x200;
    Procedure VGA640x350;
    Procedure VGA640x480;
    Procedure Text40x25;
    Procedure Text80x25;
  End;

  TTools = Object
    Procedure SwapColor(PalRegister,NewColor: Byte);
    Procedure LoadFont;
    Procedure TextBlink(BlinkState : Byte);
    Procedure MoveUp(x1,y1,x2,y2: Byte);
    Procedure MoveDown(x1,y1,x2,y2: Byte);
    Function TextMaxX: Byte;
    Function TextMaxY: Byte;
  End;

  pPal = Record
    r, g, b: byte;
  End;

Var
  originalpal: Array[0..255] Of pPal;
  i: Integer;

Procedure SGetPal(Start: byte; Anz: word; pal: pointer);
Procedure SSetPal(Start: byte; Anz: word; pal: pointer);
Procedure SetPal(col,r,g,b:byte);
Procedure FadePal(FadeOut : Boolean);

{----------} Implementation {----------}

{Start TVideoMode}
Procedure TVideoMode.VGA640x200;
Begin
  asm
    mov ah,00h
    mov al,0eh
    int 10h
  end;
End;

Procedure TVideoMode.VGA640x350;
Begin
  asm
    mov ah,00h
    mov al,10h
    int 10h
  end;
End;

Procedure TVideoMode.VGA640x480;
Begin
  asm
    mov ah,00h
    mov al,12h
    int 10h
  end;
End;

Procedure TVideoMode.Text40x25;
Begin
  asm
    mov ah,00h
    mov al,1
    int 10h
  end;
End;

Procedure TVideoMode.Text80x25;
Begin
  asm
    mov ah,00h
    mov al,3
    int 10h
  end;
End;
{End TVideoMode}

{Start TTextTools}
Procedure TTools.SwapColor(PalRegister,NewColor: Byte);
Begin
  asm
    mov ax,1000h
    mov bh,NewColor
    mov bl,PalRegister
    int 10h
  end;
End;

Procedure TTools.LoadFont;
Var
  Height : byte;
  Font   : pointer;
  Block  : byte;
Begin
  asm
    push    ds
    lds     si,self
    les     di,ds:[si].Font
    push    bp
    mov     bp,di
    mov     bl,ds:[si].Block
    mov     bh,ds:[si].Height
    mov     cx,0100h
    mov     dx,0
    mov     ax,1100h
    int     10h
    pop     bp
    pop     ds
  end;
End;

Procedure TTools.TextBlink(BlinkState : Byte);
Begin
  asm
    mov ax, 1003h
    mov bl, BlinkState
    int 10h
  end;
End;

Procedure TTools.MoveUp(x1,y1,x2,y2: Byte);
Begin
  asm
    mov ah,06h
    mov cl,x1
    mov ch,y1
    mov dl,x2
    mov dh,y2
    mov al,1
    int 10h
  end;
End;

Procedure TTools.MoveDown(x1,y1,x2,y2: Byte);
Begin
  asm
    mov ah,07h
    mov cl,x1
    mov ch,y1
    mov dl,x2
    mov dh,y2
    mov al,1
    int 10h
  end;
End;

Function TTools.TextMaxX: Byte;
Var
  r,x: Byte;
Begin
  asm
    mov ah,0fh
    int 10h
    mov r,al
  end;
  if (r=0)or(r=1) then x:=40;
  if (r=2)or(r=3)or(r=7) then x:=80;
  TextMaxX := x;
End;

Function TTools.TextMaxY: Byte;
Var
  r,y: Byte;
Begin
  asm
    mov ah,0fh
    int 10h
    mov r,al
  end;
  if (r=0)or(r=1)or(r=2)or(r=3)or(r=7) then y:=25;
  TextMaxY := y;
End;
{End TTextTools}

{���࠭���� �������}
Procedure SGetPal(Start: byte; Anz: word; pal: pointer); assembler;
asm
  les di,pal
  mov al,start
  mov dx,3c7h
  out dx,al
  inc dx
  mov ax,anz
  mov cx,ax
  add cx,ax
  add cx,ax

  mov dx,3c9h
  cld
  rep insb
end;

{����⠭������� ��࠭����� �������}
Procedure SSetPal(Start: byte; Anz: word; pal: pointer); assembler;
asm
  push ds
  cld
  lds si,pal
  mov dx,3c8h
  mov al,start
  out dx,al
  inc dx
  mov ax,anz
  mov cx,ax
  add cx,ax
  add cx,ax
  rep outsb
  pop ds
end;

{��⠭���� �ந����쭮� ������� ��� 梥� "col"}
Procedure SetPal(col,r,g,b:byte);assembler;
asm
  mov dx,3c8h
  mov al,col
  out dx,al
  mov dx,3c9h
  mov al,r
  out dx,al
  mov al,g
  out dx,al
  mov al,b
  out dx,al
end;

{������� ��襭�� (True) � ����⠭������� (False) ��࠭�}
Procedure FadePal(FadeOut : Boolean);
Var
  r,g,b   : byte;
  Fade    : word;
  Pct     : real;
  I       : byte;
Begin
  For Fade := 0 to 19 do
    begin
      Pct := Fade / 19;
      If FadeOut then Pct := 1 - Pct;
      For I := 0 to 255 do
        begin
          r := Round(OriginalPal[I].R * Pct);
          g := Round(OriginalPal[I].G * Pct);
          b := Round(OriginalPal[I].B * Pct);
          asm
            mov dx,3c8h
            mov al,i
            out dx,al
            mov dx,3c9h
            mov al,r
            out dx,al
            mov al,g
            out dx,al
            mov al,b
            out dx,al
          end;
        end;
        delay(30);
    end;
End;

END.