VERSION 5.00
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmFind 
   Caption         =   "�����"
   ClientHeight    =   3645
   ClientLeft      =   60
   ClientTop       =   345
   ClientWidth     =   4710
   LinkTopic       =   "Form1"
   MaxButton       =   0   'False
   MinButton       =   0   'False
   ScaleHeight     =   3645
   ScaleWidth      =   4710
   ShowInTaskbar   =   0   'False
   StartUpPosition =   3  'Windows Default
   Begin VB.CheckBox chkCompare 
      Caption         =   "� ������ ��������"
      Height          =   255
      Left            =   1200
      TabIndex        =   4
      Top             =   480
      Width           =   1815
   End
   Begin RichTextLib.RichTextBox richTemp 
      Height          =   1335
      Left            =   4800
      TabIndex        =   3
      Top             =   1320
      Visible         =   0   'False
      Width           =   1455
      _ExtentX        =   2566
      _ExtentY        =   2355
      _Version        =   393217
      Enabled         =   -1  'True
      TextRTF         =   $"frmFind.frx":0000
   End
   Begin VB.TextBox txtFind 
      Height          =   285
      Left            =   0
      TabIndex        =   2
      Top             =   120
      Width           =   4695
   End
   Begin VB.CommandButton cmdFind 
      Caption         =   "�����"
      Height          =   285
      Left            =   0
      TabIndex        =   1
      Top             =   480
      Width           =   1095
   End
   Begin VB.ListBox lstFind 
      Height          =   2790
      Left            =   0
      TabIndex        =   0
      Top             =   840
      Width           =   4695
   End
End
Attribute VB_Name = "frmFind"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit

Private Id_Index() As Long

Private Sub cmdFind_Click()
    Dim sql As String
    Dim rs As ADODB.Recordset
    '
    Dim Source As String
    Dim Title As String
    Dim Id_Source As Long
    '
    Dim i As Long
    Dim Find As String
    Dim Compare As Byte
    
    cmdFind.Enabled = False
    lstFind.Clear
    ReDim Id_Index(0)
    Find = Trim(txtFind)
    sql = "select * from sources"
    Set rs = New ADODB.Recordset
        With rs
            .Open sql, frmMain.cn, adOpenForwardOnly, adLockReadOnly
                Do While Not .EOF
                    Title = rs("Title")
                    richTemp.TextRTF = rs("Source")
                    Source = richTemp.Text
                    Id_Source = rs("Id_Source")
                    
                    If chkCompare = 1 Then
                        Compare = vbBinaryCompare
                    Else
                        Compare = vbTextCompare
                    End If
                    
                    If InStr(1, Source, Find, Compare) > 0 Then
                        ReDim Preserve Id_Index(i)
                        Id_Index(i) = Id_Source
                        lstFind.AddItem Title
                        i = i + 1
                    End If
                    .MoveNext
                Loop
            .Close
        End With
    Set rs = Nothing
    cmdFind.Enabled = True
End Sub

Private Sub Form_Resize()
    txtFind.Width = Me.ScaleWidth - txtFind.Left
    lstFind.Width = Me.ScaleWidth
    lstFind.Height = Me.ScaleHeight - lstFind.Top
End Sub

Private Sub lstFind_Click()
    frmMain.ShowSource Id_Index(lstFind.ListIndex)
End Sub
