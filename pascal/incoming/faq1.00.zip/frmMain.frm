VERSION 5.00
Object = "{6B7E6392-850A-101B-AFC0-4210102A8DA7}#1.3#0"; "comctl32.ocx"
Object = "{67397AA1-7FB1-11D0-B148-00A0C922E820}#6.0#0"; "MSADODC.OCX"
Object = "{3B7C8863-D78F-101B-B9B5-04021C009402}#1.2#0"; "RICHTX32.OCX"
Begin VB.Form frmMain 
   Caption         =   "����� ��������� ������� �� VB"
   ClientHeight    =   5070
   ClientLeft      =   165
   ClientTop       =   735
   ClientWidth     =   8535
   LinkTopic       =   "Form1"
   ScaleHeight     =   5070
   ScaleWidth      =   8535
   StartUpPosition =   3  'Windows Default
   Begin VB.PictureBox picSplitter 
      BackColor       =   &H8000000C&
      BorderStyle     =   0  'None
      Height          =   4575
      Left            =   2760
      ScaleHeight     =   4575
      ScaleWidth      =   135
      TabIndex        =   2
      Top             =   0
      Visible         =   0   'False
      Width           =   135
   End
   Begin RichTextLib.RichTextBox richSource 
      Height          =   4695
      Left            =   3120
      TabIndex        =   1
      Top             =   0
      Width           =   4455
      _ExtentX        =   7858
      _ExtentY        =   8281
      _Version        =   393217
      ReadOnly        =   -1  'True
      ScrollBars      =   3
      TextRTF         =   $"frmMain.frx":0000
   End
   Begin MSAdodcLib.Adodc Adodc1 
      Height          =   375
      Left            =   0
      Top             =   4680
      Visible         =   0   'False
      Width           =   7935
      _ExtentX        =   13996
      _ExtentY        =   661
      ConnectMode     =   0
      CursorLocation  =   3
      IsolationLevel  =   -1
      ConnectionTimeout=   15
      CommandTimeout  =   30
      CursorType      =   3
      LockType        =   3
      CommandType     =   8
      CursorOptions   =   0
      CacheSize       =   50
      MaxRecords      =   0
      BOFAction       =   0
      EOFAction       =   0
      ConnectStringType=   1
      Appearance      =   1
      BackColor       =   -2147483643
      ForeColor       =   -2147483640
      Orientation     =   0
      Enabled         =   -1
      Connect         =   ""
      OLEDBString     =   ""
      OLEDBFile       =   ""
      DataSourceName  =   ""
      OtherAttributes =   ""
      UserName        =   ""
      Password        =   ""
      RecordSource    =   ""
      Caption         =   "Adodc1"
      BeginProperty Font {0BE35203-8F91-11CE-9DE3-00AA004BB851} 
         Name            =   "MS Sans Serif"
         Size            =   8.25
         Charset         =   204
         Weight          =   400
         Underline       =   0   'False
         Italic          =   0   'False
         Strikethrough   =   0   'False
      EndProperty
      _Version        =   393216
   End
   Begin ComctlLib.TreeView tvwLinks 
      Height          =   4695
      Left            =   0
      TabIndex        =   0
      Top             =   0
      Width           =   2655
      _ExtentX        =   4683
      _ExtentY        =   8281
      _Version        =   327682
      LabelEdit       =   1
      Sorted          =   -1  'True
      Style           =   4
      BorderStyle     =   1
      Appearance      =   1
   End
   Begin VB.Image imgSplitter 
      Height          =   4575
      Left            =   2880
      MousePointer    =   9  'Size W E
      Top             =   0
      Width           =   135
   End
   Begin ComctlLib.ImageList ImageList1 
      Left            =   7800
      Top             =   0
      _ExtentX        =   1005
      _ExtentY        =   1005
      BackColor       =   -2147483643
      ImageWidth      =   32
      ImageHeight     =   32
      MaskColor       =   12632256
      _Version        =   327682
      BeginProperty Images {0713E8C2-850A-101B-AFC0-4210102A8DA7} 
         NumListImages   =   1
         BeginProperty ListImage1 {0713E8C3-850A-101B-AFC0-4210102A8DA7} 
            Picture         =   "frmMain.frx":0084
            Key             =   ""
         EndProperty
      EndProperty
   End
   Begin VB.Menu mnuFile 
      Caption         =   "&����"
      Begin VB.Menu mnuFind 
         Caption         =   "&�����"
      End
      Begin VB.Menu mnuAddSource 
         Caption         =   "&�������� ������"
      End
      Begin VB.Menu mnuSubmit 
         Caption         =   "&��������� ���� ��������"
         Enabled         =   0   'False
      End
      Begin VB.Menu mnuSeparator01 
         Caption         =   "-"
      End
      Begin VB.Menu mnuExit 
         Caption         =   "�&����"
      End
   End
   Begin VB.Menu mnuAboutHelp 
      Caption         =   "&�������"
      Begin VB.Menu mnuAbout 
         Caption         =   "� &���������"
         Enabled         =   0   'False
      End
   End
End
Attribute VB_Name = "frmMain"
Attribute VB_GlobalNameSpace = False
Attribute VB_Creatable = False
Attribute VB_PredeclaredId = True
Attribute VB_Exposed = False
Option Explicit
'sql
Public cn As ADODB.Connection
Private rs As ADODB.Recordset
'
Private mbMoving As Boolean
Const sglSplitLimit = 500

Public Sub UpdateTree()
    'TreeView
    Dim KeyRoot As String
    Dim KeyChild As String
    'db
    Dim Id_Group As String
    Dim Group As String
    Dim Id_Source As String
    Dim Link_Group As String
    Dim Title As String
    Dim Source As String
    '
    Dim sql As String
    
    tvwLinks.Nodes.Clear
    
    sql = "select * from groups"
    Set rs = New ADODB.Recordset
        With rs
            .Open sql, cn, adOpenForwardOnly, adLockReadOnly
                Do While Not .EOF
                    Id_Group = rs("Id_Group")
                    Group = rs("Group")
                    KeyRoot = "r" & Id_Group
                    '��������� ������ "��������"
                    tvwLinks.Nodes.Add , , KeyRoot, Group
                    .MoveNext
                Loop
            .Close
        End With
        
    sql = "select * from sources"
        With rs
            .Open sql, cn, adOpenForwardOnly, adLockReadOnly
                Do While Not .EOF
                    Id_Source = rs("Id_Source")
                    Link_Group = rs("Link_Group")
                    Title = rs("Title")
                    Source = rs("Source")
                    
                    '���������� ������ �������
                    KeyRoot = "r" & Link_Group
                    KeyChild = "c" & Id_Source
                    tvwLinks.Nodes.Add KeyRoot, tvwChild, KeyChild, Title
                    
                    .MoveNext
                Loop
            .Close
        End With
End Sub

Public Sub ShowSource(Id_Source As Long)
    '�������� ������
    Dim sql As String
    
    sql = "select * from sources"
        With rs
            .Open sql, cn, adOpenForwardOnly, adLockReadOnly
                Do
                    If Id_Source = rs("Id_Source") Then
                        richSource.TextRTF = rs("Source")
                        Exit Do
                    End If
                    .MoveNext
                Loop While Not .EOF
            .Close
        End With
End Sub

Private Sub Form_Load()
    'sql
    Dim cmd As String
    
    '������� ������ �����������
    cmd = "Provider=Microsoft.Jet.OLEDB.4.0;" & _
    "Data Source=" & App.Path & "\faq.mdb" & _
    ";Mode=ReadWrite;Persist Security Info=False"
    '��������� ���������� � ����� ������
    Set cn = New ADODB.Connection
    With cn
        .ConnectionString = cmd
        .Open
    End With
    
    '�������� ������
    Call UpdateTree
End Sub

Private Sub Form_Resize()
    tvwLinks.Height = Me.ScaleHeight
    tvwLinks.Width = imgSplitter.Left
    richSource.Left = imgSplitter.Left + (imgSplitter.Width \ 2)
    richSource.Height = Me.ScaleHeight
    richSource.Width = Me.ScaleWidth - tvwLinks.Width - (imgSplitter.Width \ 2)
    imgSplitter.Height = Me.ScaleHeight
End Sub

Private Sub Form_Unload(Cancel As Integer)
    '������� �� � ���������� �������
    Set rs = Nothing
    cn.Close
    Set cn = Nothing
End Sub

Private Sub imgSplitter_MouseDown(Button As Integer, Shift As Integer, X As Single, Y As Single)
    With imgSplitter
        picSplitter.Move .Left, .Top, .Width \ 2, .Height - 20
    End With
    picSplitter.Visible = True
    mbMoving = True
End Sub

Private Sub imgSplitter_MouseMove(Button As Integer, Shift As Integer, X As Single, Y As Single)
    Dim sglPos As Single

    If mbMoving Then
        sglPos = X + imgSplitter.Left
        If sglPos < sglSplitLimit Then
            picSplitter.Left = sglSplitLimit
        ElseIf sglPos > Me.Width - sglSplitLimit Then
            picSplitter.Left = Me.Width - sglSplitLimit
        Else
            picSplitter.Left = sglPos
        End If
    End If
End Sub


Private Sub imgSplitter_MouseUp(Button As Integer, Shift As Integer, X As Single, Y As Single)
    imgSplitter.Left = picSplitter.Left
    picSplitter.Visible = False
    mbMoving = False
    Call Form_Resize
End Sub

Private Sub mnuAddSource_Click()
    With frmAddSource
        .GetGroupList .cboGroup
        .Show , frmMain
    End With
End Sub

Private Sub mnuExit_Click()
    Unload Me
End Sub

Private Sub mnuFind_Click()
    frmFind.Show , frmMain
End Sub

Private Sub tvwLinks_NodeClick(ByVal Node As ComctlLib.Node)
    If InStr(1, Node.FullPath, tvwLinks.PathSeparator, vbBinaryCompare) > 0 Then
        ShowSource Val(Mid(Node.Key, 2))
    Else
        Node.Expanded = Not Node.Expanded
        Exit Sub
    End If
End Sub
