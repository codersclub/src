#include "stdafx.h"
#include "db.h"
#include "Prop.h"
#include "database.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CProp dialog


CProp::CProp(CWnd* pParent /*=NULL*/)
	: CDialog(CProp::IDD, pParent)
{
	//{{AFX_DATA_INIT(CProp)
	m_name = _T("");
	m_passwd = _T("");
	//}}AFX_DATA_INIT
}


void CProp::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CProp)
	DDX_Text(pDX, IDC_DESCR, m_name);
	DDV_MaxChars(pDX, m_name, 20);
	DDX_Text(pDX, IDC_PASSWD, m_passwd);
	DDV_MaxChars(pDX, m_passwd, 10);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CProp, CDialog)
	//{{AFX_MSG_MAP(CProp)
	ON_BN_CLICKED(IDC_SAVEF, OnSavef)
	ON_BN_CLICKED(IDC_DELETEF, OnDeletef)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

BOOL CProp::OnInitDialog() 
{
	CDialog::OnInitDialog();
	if ((wnd != NULL)&&(num >= 0)&&(fd > 0))
	{
		char *str = (char *)malloc(255);
		wnd->m_list.GetItemText(num, 1, str, DB_NAME);
		m_name = str;
		wnd->m_list.GetItemText(num, 2, str, 15);
		m_uid = atoi(str);
		wnd->m_list.GetItemText(num, 3, str, 10);
		m_passwd = str;
		free(str);
		UpdateData(false);
	} else
	{
		AfxMessageBox("������: (CProp.wnd = NULL) | (num < 0)", 0);
	};
	return TRUE;
}

void CProp::OnQuit() 
{
	return;
}

void CProp::OnSavef() 
{
	UpdateData();
	wnd->m_list.SetItemText(num, 1, m_name);
	char *str = (char *)malloc(15);
	itoa(m_uid, str, 10);
	wnd->m_list.SetItemText(num, 2, str);
	wnd->m_list.SetItemText(num, 3, m_passwd);
	OnCancel();
	return;	
}

void CProp::OnOK()
{
	OnSavef();
}

void CProp::OnDeletef() 
{
	int ret = ::MessageBox(this->m_hWnd, "����������� ��������?", "AXE Database Manager", MB_YESNO | MB_ICONQUESTION);
	if (ret != 6)
	{
		return;
	};

	CString tmp;
	wnd->m_list.SetItemText(num, 0, "*");
	wnd->m_list.SetItemText(num, 1, "-deleted-");
	wnd->m_list.SetItemText(num, 3, "������� �������������!");
	wnd->count--; 

	CString text;
	wnd->GetWindowText(text);
	if (text.GetAt(text.GetLength()-2) != '*')
	{
		text.Delete(text.GetLength()-1, 1);
		text += "*]";
		wnd->SetWindowText(text);
	};
	wnd->saved = false;
//    SaveDB("��������...");
	wnd->SetDlgItemInt(IDC_FSTATUS, wnd->count);
	OnCancel();
	return;
}
