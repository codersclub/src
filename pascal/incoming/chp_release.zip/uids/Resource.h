//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by db.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_DB_DIALOG                   102
#define IDR_MAINFRAME                   128
#define IDR_POPUP                       129
#define IDD_BASE                        130
#define IDD_PROP                        131
#define IDD_ADDF                        133
#define IDD_BSAVE                       134
#define IDR_FILE                        135
#define IDC_LIST1                       1000
#define IDC_BR                          1001
#define IDC_PATH                        1002
#define IDC_FNAME                       1003
#define IDC_DESCR                       1004
#define IDC_DELETEF                     1007
#define IDC_SAVEF                       1008
#define IDC_SLIDER1                     1009
#define IDC_FUNC                        1010
#define IDC_BUTTON1                     1011
#define IDC_PROGRESS1                   1016
#define IDC_STATUS                      1017
#define IDC_FSTATUS                     1018
#define IDC_BROWSE                      1019
#define IDC_EDIT_FILENAME               1020
#define IDC_AB                          1021
#define IDC_AREA                        1022
#define IDC_FUID                        1023
#define IDC_PASSWD                      1024
#define IDM_ADDF                        32771
#define IDM_DELETE                      32772
#define IDM_PROP                        32773
#define IDM_FIND                        32774
#define IDM_EXIT                        32775
#define IDM_SAVEB                       32776
#define IDM_LOADB                       32777
#define ID_MENUITEM32781                32781
#define IDM_SAVEAS                      32782
#define IDM_SAVEIT                      32783

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        137
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1026
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
