#include "stdafx.h"
#include "db.h"
#include "Save.h"
#include "database.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSave dialog


CSave::CSave(CWnd* pParent /*=NULL*/)
	: CDialog(CSave::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSave)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSave::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSave)
	DDX_Control(pDX, IDC_PROGRESS1, m_progress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSave, CDialog)
	//{{AFX_MSG_MAP(CSave)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSave message handlers



BOOL CSave::OnInitDialog() 
{
	CDialog::OnInitDialog();
	this->SetWindowText(this->caption);
	SetTimer(1, 500, NULL);
	return TRUE;
}

void CSave::OnTimer(UINT nIDEvent) 
{
	CDialog::OnTimer(nIDEvent);
	if ((nIDEvent == 1)&&(wnd != NULL))
	{
		KillTimer(1);
		DB_RECORD db_rec;
		char *str = (char *)malloc(255);
		int i;
		close(wnd->fd);
		wnd->fd = creat(file, 0644);
		if (wnd->fd == -1)
		{
			return;
		};
		wnd->UpdateData();
		m_progress.SetRange(0, wnd->m_list.GetItemCount());
		int k = 0;
		for (i=0; i<wnd->m_list.GetItemCount(); i++)
		{
			m_progress.SetPos(i);
			memset(&db_rec, 0, sizeof(DB_RECORD));
			memset(str, 0, 30);
		
			wnd->m_list.GetItemText(i, 1, (char *)db_rec.name, DB_NAME);
			wnd->m_list.GetItemText(i, 2, str, 15);
			db_rec.uid = atoi(str);
			wnd->m_list.GetItemText(i, 3, (char *)db_rec.passwd, 10);
			if (strcmp((char *)db_rec.name, "-deleted-"))
			{
				write_item(wnd->fd, k, db_rec);
				k++;
			};
		};
		free(str);
		m_progress.SetPos(wnd->m_list.GetItemCount());
		OnCancel();
	};
}
