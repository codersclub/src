#if !defined(AFX_DBDLG_H__48D5A1C3_458E_4987_93BB_0D42C519EB20__INCLUDED_)
#define AFX_DBDLG_H__48D5A1C3_458E_4987_93BB_0D42C519EB20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CDbDlg dialog

class CDbDlg : public CDialog
{
// Construction
public:
	bool saved;
	bool SaveDB(CString Caption, CString file);
	void OnCancel();
	void OnOK();
	void FillList();
	int count;
	int fd;
	char *db;
	bool LoadDb();
	CDbDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CDbDlg)
	enum { IDD = IDD_DB_DIALOG };
	CStatic	m_fstatus;
	CStatic	m_status;
	CListCtrl	m_list;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDbDlg)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CDbDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	afx_msg void OnProp();
	afx_msg void OnExit();
	afx_msg void OnClose();
	afx_msg void OnAddf();
	afx_msg void OnSaveb();
	afx_msg void OnLoadb();
	afx_msg void OnDelete();
	afx_msg void OnSaveas();
	afx_msg void OnSaveit();
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DBDLG_H__48D5A1C3_458E_4987_93BB_0D42C519EB20__INCLUDED_)
