#if !defined(AFX_SAVE_H__917CAE2E_8E21_4A04_A4D3_EC30DEB9E673__INCLUDED_)
#define AFX_SAVE_H__917CAE2E_8E21_4A04_A4D3_EC30DEB9E673__INCLUDED_

#include "dbDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Save.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSave dialog

class CSave : public CDialog
{
// Construction
public:
	CString file;
	CString caption;
	CDbDlg *wnd;
	CSave(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSave)
	enum { IDD = IDD_BSAVE };
	CProgressCtrl	m_progress;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSave)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSave)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SAVE_H__917CAE2E_8E21_4A04_A4D3_EC30DEB9E673__INCLUDED_)
