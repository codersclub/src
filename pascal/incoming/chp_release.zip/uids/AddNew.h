#if !defined(AFX_ADDNEW_H__2ED8BDC3_172E_4F46_B1F9_85E8989D3CEF__INCLUDED_)
#define AFX_ADDNEW_H__2ED8BDC3_172E_4F46_B1F9_85E8989D3CEF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddNew.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddNew dialog

class CAddNew : public CDialog
{
// Construction
public:
	CAddNew(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddNew)
	enum { IDD = IDD_ADDF };
	CString	m_name;
	UINT	m_uid;
	CString	m_passwd;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddNew)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddNew)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedCancel();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDNEW_H__2ED8BDC3_172E_4F46_B1F9_85E8989D3CEF__INCLUDED_)
