#if !defined(AFX_PROP_H__EE9FE603_2387_4E4F_8224_22073579F42B__INCLUDED_)
#define AFX_PROP_H__EE9FE603_2387_4E4F_8224_22073579F42B__INCLUDED_

#include "dbDlg.h"	// Added by ClassView
#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Prop.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CProp dialog

class CProp : public CDialog
{
// Construction
public:
	void OnOK();
	int fd;
	int num;
	CDbDlg *wnd;
	CProp(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CProp)
	enum { IDD = IDD_PROP };
	CString	m_name;
	CString	m_passwd;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CProp)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CProp)
	virtual BOOL OnInitDialog();
	afx_msg void OnQuit();
	afx_msg void OnSavef();
	afx_msg void OnDeletef();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROP_H__EE9FE603_2387_4E4F_8224_22073579F42B__INCLUDED_)
