#include "stdafx.h"
#include "db.h"
#include "Path.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPath dialog


CPath::CPath(CWnd* pParent /*=NULL*/)
	: CDialog(CPath::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPath)
	m_path = _T("");
	//}}AFX_DATA_INIT
}


void CPath::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPath)
	//DDX_Text(pDX, IDC_PATH, m_path);
	//DDV_MaxChars(pDX, m_path, 512);
	//DDX_Text(pDX, IDC_EDIT_FILENAME, m_strFilename);
	DDX_Text(pDX, IDC_EDIT_FILENAME, m_path);
	//DDV_MaxChars(pDX, m_strFilename, 256);
	DDV_MaxChars(pDX, m_path, 256);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPath, CDialog)
	//{{AFX_MSG_MAP(CPath)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_EN_CHANGE(IDC_EDIT_FILENAME, OnChangeFilename)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPath message handlers

BOOL CPath::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CPath::OnOK() 
{
	UpdateData();
	CDialog::OnOK();
}

void CPath::OnBrowse()
{
	CFileDialog dlg(TRUE, NULL, NULL, OFN_FILEMUSTEXIST, NULL, this);
	if(dlg.DoModal() == IDOK)
		SetDlgItemText(IDC_EDIT_FILENAME, dlg.GetPathName());	
}

void CPath::OnChangeFilename()
{
	UpdateData();
}

