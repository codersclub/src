#include "stdafx.h"
#include "db.h"
#include "AddNew.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddNew dialog


CAddNew::CAddNew(CWnd* pParent /*=NULL*/)
	: CDialog(CAddNew::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddNew)
	m_name = _T("");
	m_uid = 0;
	m_passwd = _T("");
	//}}AFX_DATA_INIT
}


void CAddNew::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddNew)
	DDX_Text(pDX, IDC_FNAME, m_name);
	DDV_MaxChars(pDX, m_name, 20);
	DDX_Text(pDX, IDC_FUID, m_uid);
	DDV_MinMaxUInt(pDX, m_uid, 100000, 999999);
	DDX_Text(pDX, IDC_PASSWD, m_passwd);
	DDV_MaxChars(pDX, m_passwd, 10);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddNew, CDialog)
	//{{AFX_MSG_MAP(CAddNew)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDCANCEL, OnBnClickedCancel)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddNew message handlers

BOOL CAddNew::OnInitDialog() 
{
	CDialog::OnInitDialog();
	return TRUE;
}

void CAddNew::OnOK() 
{
	UpdateData();
	CDialog::OnOK();
}

void CAddNew::OnBnClickedCancel()
{
	AfxMessageBox("�� ���� ��� �� ���� :)", MB_ICONSTOP|MB_OK);
	OnCancel();
}
