#if !defined(AFX_PATH_H__750E3985_1479_42DE_BB90_38A41A3B3F40__INCLUDED_)
#define AFX_PATH_H__750E3985_1479_42DE_BB90_38A41A3B3F40__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Path.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPath dialog

class CPath : public CDialog
{
// Construction
public:
	CPath(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPath)
	enum { IDD = IDD_BASE };
	CString	m_path;	
	//CString	m_strFilename;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPath)
	protected:
	virtual void DoDataExchange(CDataExchange *pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPath)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	afx_msg void OnBrowse();
	afx_msg void OnChangeFilename();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
//public:
	//afx_msg void OnBrowse();
//public:
	//afx_msg void OnChangeFilename();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PATH_H__750E3985_1479_42DE_BB90_38A41A3B3F40__INCLUDED_)
