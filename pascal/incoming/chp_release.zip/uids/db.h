#if !defined(AFX_DB_H__5D6BE086_67DB_4C6B_8FDB_4631264DAEC6__INCLUDED_)
#define AFX_DB_H__5D6BE086_67DB_4C6B_8FDB_4631264DAEC6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CDbApp:
// See db.cpp for the implementation of this class
//

class CDbApp : public CWinApp
{
public:
	CDbApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDbApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CDbApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DB_H__5D6BE086_67DB_4C6B_8FDB_4631264DAEC6__INCLUDED_)
