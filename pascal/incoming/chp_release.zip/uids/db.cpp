#include "stdafx.h"
#include "db.h"
#include "dbDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDbApp

BEGIN_MESSAGE_MAP(CDbApp, CWinApp)
	//{{AFX_MSG_MAP(CDbApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDbApp construction

CDbApp::CDbApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CDbApp object

CDbApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDbApp initialization

BOOL CDbApp::InitInstance()
{

#ifdef _AFXDLL
	Enable3dControls();	
#else
	Enable3dControlsStatic();
#endif

	CDbDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	return FALSE;
}
