#include <stdlib.h>
#include <io.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#define DB_NAME 25

struct DB_RECORD 
{
	unsigned long uid;
	char passwd[10];
	char name[25];
	char email[30];
	bool male;
	char country[15];
	char city[15];
	char about[128];
};

static off_t open_db(int *fd, char *name);
static bool save_db(int fd, char *name); // ����� ��� ����? :)
off_t get_files_size(int fd);
static DB_RECORD get_item(int fd, int num);
static bool write_item(int fd, int num, DB_RECORD item);
static bool add_item(int fd, char *name, unsigned int uid);

static off_t get_file_size (int fd)
{
	int err;
	struct stat fs;
	err = fstat (fd, &fs);
	if (err == -1) return (off_t) (-1);
	return fs.st_size;
};

off_t open_db(int *fd, char *name)
{
	close(*fd);
	*fd = open (name, O_RDWR);
	return get_file_size (*fd);
};

DB_RECORD get_item(int fd, int num)
{
	DB_RECORD ret;
	memset(&ret, 0, sizeof(DB_RECORD));
	lseek(fd, num*sizeof(DB_RECORD), 0);
	read(fd, &ret, sizeof(DB_RECORD));
	return ret;
};

bool save_db(int fd, char *name)
{
	bool ret = false;
	int db, index = 0;
	db = creat(name, 0644);
	DB_RECORD rec;
	lseek(fd, 0, 0);
	while (!eof(fd))
	{
		memset(&rec, 0, sizeof(DB_RECORD));
		read(fd, &rec, sizeof(DB_RECORD));
		if (strcmp((char *)rec.name, "-deleted-"))
		{
			index++;
			add_item(db, (char *)rec.name, rec.uid);
		};
	};
	close(db);
	ret = true;
	return ret;
};

bool add_item(int fd, char *name, unsigned int uid)
{
	DB_RECORD rec;
	bool ret = false;
	memset(&rec, 0, sizeof(DB_RECORD));
	strcat((char *)rec.name, name);
	rec.uid = uid;
	strcat((char *)rec.passwd, "tmppass");
	if (write(fd, &rec, sizeof(DB_RECORD)))
		ret = true;
	return ret;
};

bool write_item(int fd, int num, DB_RECORD item)
{
	bool ret = false;
	lseek(fd, num*sizeof(DB_RECORD), 0);
	if (write(fd, &item, sizeof(DB_RECORD)))
		ret = true;
	return ret;
};