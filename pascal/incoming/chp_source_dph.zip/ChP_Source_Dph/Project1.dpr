program Project1;

uses
  Forms,
  Unit1 in 'Unit1.pas' {MAIN},
  Unit2 in 'Unit2.pas' {frmREGISTER},
  Unit3 in 'Unit3.pas' {LOGINUSER},
  Unit4 in 'Unit4.pas' {ADDUSER},
  Unit5 in 'Unit5.pas',
  Unit6 in 'Unit6.pas' {ABOUT},
  Unit7 in 'Unit7.pas' {INFO};

{$R *.res}

begin
  Application.Initialize;
  Application.Title := '�����-�����, ������ �� Delphi.';
  Application.CreateForm(TMAIN, MAIN);
  Application.CreateForm(TfrmREGISTER, frmREGISTER);
  Application.CreateForm(TLOGINUSER, LOGINUSER);
  Application.CreateForm(TADDUSER, ADDUSER);
  Application.CreateForm(TABOUT, ABOUT);
  Application.CreateForm(TINFO, INFO);
  Application.Run;
end.
