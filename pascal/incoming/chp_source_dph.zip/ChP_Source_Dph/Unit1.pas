unit Unit1;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Sockets, StdCtrls, Math, Menus, Buttons, ImgList, ComCtrls,
  ExtCtrls, NMUDP, Unit2, Unit3, Unit4, Unit5, Unit6, Unit7;

type
  TMAIN = class(TForm)
    MainMenu1: TMainMenu;
    mnuFile: TMenuItem;
    mnuLogin: TMenuItem;
    mnuReg: TMenuItem;
    N1: TMenuItem;
    mnuStatus: TMenuItem;
    mnuOnline: TMenuItem;
    mnuAway: TMenuItem;
    mnuInvisible: TMenuItem;
    N6: TMenuItem;
    mnuClose: TMenuItem;
    mnuMessages: TMenuItem;
    mnuAdd: TMenuItem;
    mnuChange: TMenuItem;
    mnuDel: TMenuItem;
    N2: TMenuItem;
    mnuSend: TMenuItem;
    mnuHelp: TMenuItem;
    mnuAbout: TMenuItem;
    mnuAboutServer: TMenuItem;
    TV: TTreeView;
    ImageList1: TImageList;
    BitBtn1: TBitBtn;
    BitBtn2: TBitBtn;
    BitBtn3: TBitBtn;
    SB: TStatusBar;
    Timer1: TTimer;
    UDP: TNMUDP;
    Memo1: TMemo;
    Memo2: TMemo;
    Timer2: TTimer;
    procedure FormCreate(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure mnuRegClick(Sender: TObject);
    procedure mnuLoginClick(Sender: TObject);
    procedure mnuCloseClick(Sender: TObject);
    procedure UDPDataReceived(Sender: TComponent; NumberBytes: Integer;
      FromIP: String; Port: Integer);
    procedure mnuOnlineClick(Sender: TObject);
    procedure mnuAwayClick(Sender: TObject);
    procedure mnuInvisibleClick(Sender: TObject);
    procedure mnuAddClick(Sender: TObject);
    procedure mnuChangeClick(Sender: TObject);
    procedure mnuDelClick(Sender: TObject);
    procedure mnuAboutClick(Sender: TObject);
    procedure mnuAboutServerClick(Sender: TObject);
    procedure Timer1Timer(Sender: TObject);
    procedure mnuSendClick(Sender: TObject);
    procedure BitBtn3Click(Sender: TObject);
    procedure Timer2Timer(Sender: TObject);
    procedure Memo1Change(Sender: TObject);
    procedure BitBtn1Click(Sender: TObject);
    procedure BitBtn2Click(Sender: TObject);
    procedure TVDblClick(Sender: TObject);
    procedure FormKeyDown(Sender: TObject; var Key: Word;
      Shift: TShiftState);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

Var
  MAIN: TMAIN;

Implementation


{$R *.dfm}

//*****************************
Procedure TMAIN.FormCreate(Sender: TObject);
Var
  FormCaption : String;
  File1 : file of _uidfile;
  uidfile : _uidfile;
Begin
  // ��������������, ���� ��� �� ����������������.
  FormCaption := '';
  uidfile.uid := 0;
  uidfile.ip := '';
  AssignFile(File1,GetCurrentDir + '\uid');
  Reset(File1);
  if not EOF(File1) then Read(File1, uidfile);
  FormCaption := IntToStr(uidfile.uid);
  IPS := uidfile.ip;
  If FormCaption = '0' Then begin
    CloseFile(File1);
    MAIN.Caption := '�����-����� - �����������������...';
    mnuLogin.Enabled := False;
    mnuStatus.Enabled := False;
    mnuMessages.Enabled := False;
    BitBtn1.Enabled := False;
    BitBtn2.Enabled := False;
    BitBtn3.Enabled := False;
    SB.SimpleText := '�����������������...';
  end
  else begin
    MAIN.Caption := '�����-����� ';
    UID := StrToInt(FormCaption);
    UDP.RemoteHost := IPS;
    mnuReg.Enabled := False;
    mnuStatus.Enabled := False;
    mnuMessages.Enabled := False;
    BitBtn1.Enabled := False;
    BitBtn2.Enabled := False;
    BitBtn3.Enabled := False;
    CloseFile(File1);
  End;
End;

//*****************************

//*****************************
procedure TMAIN.FormClose(Sender: TObject; var Action: TCloseAction);
Var
  i : integer;
  cf : _contactfile;
  File1 : file of _contactfile;
  Tag : string;
Begin

  // ��������������
  SEND_CMD_LOGOFF();

  // ���������� ���� �� �������-�����
  If Not ((TV.Items.Count = 0) And (mnuStatus.Enabled = False)) Then Begin
    AssignFile(File1,GetCurrentDir + '\contact');
    Rewrite(File1);
    For i := 0 to TV.Items.Count - 1 Do Begin
      Tag := MAIN.TV.Items[i].Text;
      Repeat
        Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
      Until Pos(String(' - '), Tag) = 0 ;
      cf.nick := Copy(TV.Items[i].Text, 0, Length(TV.Items[i].Text) - (Length(Tag) + 3));
      cf.uid := StrToInt(Trim(Tag));
      Write(File1, cf);
    End;
    CloseFile(File1);
  End;
End;

Procedure TMAIN.mnuRegClick(Sender: TObject);
Begin
  Application.CreateForm(TfrmRegister, FR);
  FR.ShowModal;
End;

Procedure TMAIN.mnuLoginClick(Sender: TObject);
Begin
  Application.CreateForm(TLOGINUSER, FL);
  FL.ShowModal;
End;

Procedure TMAIN.mnuCloseClick(Sender: TObject);
Begin
  Close;
End;

Procedure TMAIN.UDPDataReceived(Sender: TComponent; NumberBytes: Integer;
  FromIP: String; Port: Integer);
Var
  server_name, server_admin, server_adm_mail, motd : String;
  oklogin : Byte; reason : String; cf : _contactfile;
    File1 : file of _contactfile;
  okreg : Byte; uidfile : _uidfile; File2 : file of _uidfile;
  status : Byte;
  fromuser : cardinal; messaga : string; ok : TModalResult;

  MyStream: TMemoryStream;
  i : integer;
  Tag : string;
Label
  Find;
Begin
  // �������� ������ �� �������
  MyStream := TMemoryStream.Create;
  try
    UDP.ReadStream(MyStream);
    MyStream.Read(packet,NumberBytes);
  finally
    MyStream.Free;
  end;

  // ������������ ������, ��������� �� �������

  If packet.cmd = RPL_INFO Then Begin
    GET_RPL_INFO (server_name, server_admin, server_adm_mail, motd);
    MessageDlg ('��� �������: ' + server_name + #13#10 +
           '������������� �������: ' + server_admin + #13#10 +
           'E-mail ��������������: ' + server_adm_mail + #13#10 +
           '��������� ���: ' + motd + #13#10,
           mtInformation, [mbOK], 0);
  End

  Else If packet.cmd = RPL_LOGIN Then Begin
    oklogin := 0;
    GET_RPL_LOGIN (oklogin, reason);
    If oklogin = 1 Then Begin
      FL.Close;
      MessageDlg (reason, mtInformation, [mbOK], 0);
      mnuStatus.Enabled := True;
      mnuOnline.Checked := True;
      mnuInvisible.Checked := False;
      mnuMessages.Enabled := True;
      BitBtn1.Enabled := True;
      BitBtn2.Enabled := True;
      BitBtn3.Enabled := True;
      MAIN.Caption := '�����-����� - UID ' + IntToStr(UID);
      SB.SimpleText := '������ - ������';
      Timer1.Enabled := True; // �������� ���������
      // ��������� �������-����
      If TV.Items.Count = 0 Then Begin
        AssignFile(File1,GetCurrentDir + '\contact');
        Reset(File1);
        While Not EOF(File1) Do Begin
          Read(File1,cf);
          TV.Items.Add(NIL, cf.nick + ' - ' + IntToStr(cf.uid));
          TV.Items[TV.Items.Count - 1].ImageIndex := 3;
          TV.Items[TV.Items.Count - 1].SelectedIndex := 3;
          SEND_CMD_GETSTATUS (cf.uid);
        End;
        CloseFile(File1);
        If TV.Items.Count >= 1 Then TV.Items[0].Selected := True;
      End;
    End
    Else
      MessageDlg(reason, mtWarning, [mbOK], 0);
  End

  Else If packet.cmd = RPL_REGISTER Then Begin
    okreg := 0;
    GET_RPL_REGISTER (okreg, UID);
    MessageDlg(IntToStr(okreg), mtInformation, [mbOK], 0);
    If okreg = 1 Then Begin
      uidfile.uid := UID;
      uidfile.ip := IPS;
      AssignFile(File2, GetCurrentDir + '\uid');
      Rewrite(File2);
      Write(File2, uidfile);
      FR.Close;
      mnuLogin.Enabled := True;
      mnuReg.Enabled := False;
      MessageDlg('����������! �� ���������������� �� ������� � IP: ' + IPS + ' .' + #13#10 +
             '��� ����������������� ����� UID: ' + IntToStr(UID) + '.', mtInformation, [mbOK], 0);
      MAIN.Caption := '�����-����� - UID ' + IntToStr(UID);
      SB.SimpleText := '�����������...';
    End
    Else Begin
      MessageDlg('��������! �� ������������������ �� �������!' + #13#10 +
             '���������� ��� ���.', mtWarning, [mbOK], 0);
    End;
  End

  Else If packet.cmd = RPL_STATUS Then Begin
    GET_RPL_STATUS (status);
    If status = STAT_ONLINE Then Begin
      mnuOnline.Checked := True;
      mnuAway.Checked := False;
      mnuInvisible.Checked := False;
      SB.SimpleText := '������ - ������';
    End
    Else If status = STAT_AWAY Then Begin
      mnuOnline.Checked := False;
      mnuAway.Checked := True;
      mnuInvisible.Checked := False;
      SB.SimpleText := '������ - ������';
    End
    Else Begin
      mnuOnline.Checked := False;
      mnuAway.Checked := False;
      mnuInvisible.Checked := True;
      SB.SimpleText := '������ - ���������';
    End;
  End

  Else If packet.cmd = RPL_GETSTATUS Then Begin
    GET_RPL_GETSTATUS (status);
    If status = STAT_NOTEXIST Then Begin
      For i := 0 To TV.Items.Count - 1 Do Begin
        Tag := MAIN.TV.Items[i].Text;
        While Pos(' - ', Tag) <> 0 Do Begin
          Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
        End;
        If Trim(Tag) = IntToStr(packet.from) Then Begin
          TV.Items[i].ImageIndex := 2;
          TV.Items[i].SelectedIndex := 2;
        End;
      End;
    End
    Else If status = STAT_ONLINE Then Begin
      For i := 0 To TV.Items.Count - 1 Do Begin
        Tag := MAIN.TV.Items[i].Text;
        While Pos(' - ', Tag) <> 0 Do Begin
          Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
        End;
        If Trim(Tag) = IntToStr(packet.from) Then Begin
          TV.Items[i].ImageIndex := 0;
          TV.Items[i].SelectedIndex := 0;
        End;
      End;
    End
    Else If status = STAT_AWAY Then Begin
      For i := 0 To TV.Items.Count - 1 Do Begin
        Tag := MAIN.TV.Items[i].Text;
        While Pos(' - ', Tag) <> 0 Do Begin
          Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
        End;
        If Trim(Tag) = IntToStr(packet.from) Then Begin
          TV.Items[i].ImageIndex := 1;
          TV.Items[i].SelectedIndex := 1;
        End;
      End;
    End
    Else Begin
      For i := 0 To TV.Items.Count - 1 Do Begin
        Tag := MAIN.TV.Items[i].Text;
        While Pos(' - ', Tag) <> 0 Do Begin
          Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
        End;
        If Trim(Tag) = IntToStr(packet.from) Then Begin
          TV.Items[i].ImageIndex := 3;
          TV.Items[i].SelectedIndex := 3;
        End;
      End;
    End;
  End

  Else If packet.cmd = RPL_GETADDR Then Begin
  End

  Else If packet.cmd = RPL_SETINFO Then Begin
  End

  Else If packet.cmd = RPL_GETINFO Then Begin
  End

  Else If packet.cmd = RPL_MSG Then Begin
    fromuser := 0;
    GET_RPL_MSG (fromuser, messaga);
    For i := 0 To TV.Items.Count - 1 Do Begin
      Tag := MAIN.TV.Items[i].Text;
      Repeat
        Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
      Until Pos(String(' - '), Tag) = 0 ;
      If Abs(StrToInt(Trim(Tag))) = Abs(fromuser) Then Begin 
        Memo1.Text := Memo1.Text + MAIN.TV.Items[i].Text + ' (' + DateTimeToStr(Time) + ')' + #13#10 + messaga + #13#10 + #13#10;
        GoTo Find;
      End;
    End; 
    // ���� ����� ��� � ������, �� ������� ������� � ���������� � �����������
    If fromuser = 0 Then
      MessageDlg('������ ��������: ' + #13#10 + messaga, mtInformation, [mbOK], 0)
    Else Begin
      ok := MessageDlg('��� ������ ��������� �� ������������ � UID ' + IntToStr(fromuser) + '.' + #13#10 + #13#10 +
                  '����� ��������� :' + #13#10 + messaga + #13#10 + #13#10 +
                  '�� ������ �������� ������������ � �������-����?', mtConfirmation, [mbNo, mbOk], 0);
      If ok = mrOK Then Begin
        USERRENAME := False;
        ADDUSER.ShowModal;
        ADDUSER.Edit2.Text := IntToStr(fromuser);
      End;
    End; 
Find:
  End

  Else If packet.cmd = RPL_PING Then Begin
    Timer2.Enabled := False;
  End

  Else If packet.cmd = RPL_LOGOUT Then Begin
    mnuStatus.Enabled := False;
    mnuOnline.Checked := False;
    mnuAway.Checked := False;
    mnuInvisible.Checked := False;

  End;

End;

Procedure TMAIN.mnuOnlineClick(Sender: TObject);
Begin
  If mnuOnline.Checked Then Exit;
  SEND_CMD_STATUS (STAT_ONLINE);
End;

Procedure TMAIN.mnuAwayClick(Sender: TObject);
Begin
  If mnuAway.Checked Then Exit;
  SEND_CMD_STATUS (STAT_AWAY);
End;

Procedure TMAIN.mnuInvisibleClick(Sender: TObject);
Begin
  If mnuInvisible.Checked Then Exit;
  SEND_CMD_STATUS (STAT_INVISIBLE);
End;

Procedure TMAIN.mnuAddClick(Sender: TObject);
Begin
  USERRENAME := False;
  ADDUSER.ShowModal;
End;

Procedure TMAIN.mnuChangeClick(Sender: TObject);
Var
  Tag : string;
Begin
  If TV.Items.Count = 0 Then Exit;
  USERRENAME := True;
  Tag := MAIN.TV.Selected.Text;
  Repeat
    Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
  Until Pos(String(' - '), Tag) = 0 ;
  ADDUSER.Edit1.Text := Copy(TV.Selected.Text, 0, Length(TV.Selected.Text) - (Length(Tag) + 3));
  ADDUSER.Edit2.Text := Trim(Tag);
  ADDUSER.Edit2.Enabled := False;
  ADDUSER.Caption := '��������� �����������';
  ADDUSER.ShowModal;
End;

Procedure TMAIN.mnuDelClick(Sender: TObject);
Var
  i : integer;
  ok : TModalResult;
  cf : _contactfile;
  File1 : file of _contactfile;
  Tag : string;
Begin
  If TV.Items.Count = 0 Then Exit;
  ok := MessageDlg('�� ������������� ������ ������� ����������� ' + TV.Selected.Text + '?', mtConfirmation, [mbNo, mbOk], 0);
  If ok = mrOK Then Begin
    MAIN.TV.Items.Delete(MAIN.TV.Selected);
    AssignFile(File1,GetCurrentDir + '\contact');
    Rewrite(File1);
    For i := 0 to TV.Items.Count -1 Do Begin
      Tag := MAIN.TV.Items[i].Text;
      Repeat
        Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
      Until Pos(String(' - '), Tag) = 0 ;
      cf.nick := Copy(TV.Items[i].Text, 0, Length(TV.Items[i].Text) - (Length(Tag) + 3));
      cf.uid := StrToInt(Trim(Tag));
      Write(File1, cf);
    End;
    CloseFile(File1);
  End;
End;

procedure TMAIN.mnuAboutClick(Sender: TObject);
begin
  ABOUT.ShowModal;
end;

procedure TMAIN.mnuAboutServerClick(Sender: TObject);
begin
  SEND_CMD_INFO();
end;

Procedure TMAIN.Timer1Timer(Sender: TObject);
Var
  i : integer;
  Tag : string;
Begin
  SEND_CMD_PING();
  Timer2.Enabled := True;
  
  For i := 0 To TV.Items.Count - 1 Do Begin
    Tag := MAIN.TV.Items[i].Text;
    While Pos(' - ', Tag) <> 0 do begin
      Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
    End;
    SEND_CMD_GETSTATUS(StrToInt(Trim(Tag)));
  End;

End;

Procedure TMAIN.mnuSendClick(Sender: TObject);
Var
  Tag1 : string;
Begin
  If TV.Items.Count = 0 Then Exit;
  If Length(Trim(Memo2.Text)) = 0 Then Exit;
  Tag1 := TV.Selected.Text;
  Repeat
    Tag1 := Copy(Tag1, Pos(string(' - '), Tag1) + 3, Length(Tag1) - (Pos(string(' - '), Tag1) + 2));
  Until Pos(String(' - '), Tag1) = 0 ;
  Memo1.Text := Memo1.Text + NICK + ' (' + DateTimeToStr(Time) + ')' + #13#10 +
               Memo2.Text + #13#10 + #13#10;
  SEND_CMD_MSG (StrToInt(Trim(Tag1)), Memo2.Text);
  Memo2.Text := '';
End;

Procedure TMAIN.BitBtn3Click(Sender: TObject);
Var
  Tag1 : string;
Begin
  If TV.Items.Count = 0 Then Exit;
  If Length(Trim(Memo2.Text)) = 0 Then Exit;
  Tag1 := TV.Selected.Text;
  Repeat
    Tag1 := Copy(Tag1, Pos(string(' - '), Tag1) + 3, Length(Tag1) - (Pos(string(' - '), Tag1) + 2));
  Until Pos(String(' - '), Tag1) = 0 ;
  Memo1.Text := Memo1.Text + NICK + ' (' + DateTimeToStr(Time) + ')' + #13#10 +
               Memo2.Text + #13#10 + #13#10;
  SEND_CMD_MSG (StrToInt(Trim(Tag1)), Memo2.Text);
  Memo2.Text := '';
End;

Procedure TMAIN.Timer2Timer(Sender: TObject);
Begin
  MessageDlg('����� � �������� ��������! ����������� �����!', mtError, [mbOk], 0);
  mnuStatus.Enabled := False;
  mnuOnline.Checked := False;
  mnuAway.Checked := False;
  mnuInvisible.Checked := False;
End;

Procedure TMAIN.Memo1Change(Sender: TObject);
Begin
  // ���������� ��������� ������� ���������� ���������.
  Memo1.SelStart := Memo1.GetTextLen;
  Memo1.SelLength := 1;
  Memo2.SetFocus;
End;

Procedure TMAIN.BitBtn1Click(Sender: TObject);
Begin
  USERRENAME := False;
  ADDUSER.ShowModal;
End;

Procedure TMAIN.BitBtn2Click(Sender: TObject);
Var
  i : integer;
  ok : TModalResult;
  cf : _contactfile;
  File1 : file of _contactfile;
  Tag : string;
Begin
  If TV.Items.Count = 0 Then Exit;
  ok := MessageDlg('�� ������������� ������ ������� ����������� ' + TV.Selected.Text + '?', mtConfirmation, [mbNo, mbOk], 0);
  If ok = mrOK Then Begin
    MAIN.TV.Items.Delete(MAIN.TV.Selected);
    AssignFile(File1,GetCurrentDir + '\contact');
    Rewrite(File1);
    For i := 0 to TV.Items.Count -1 Do Begin
      Tag := MAIN.TV.Items[i].Text;
      Repeat
        Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
      Until Pos(String(' - '), Tag) = 0 ;
      cf.nick := Copy(TV.Items[i].Text, 0, Length(TV.Items[i].Text) - (Length(Tag) + 3));
      cf.uid := StrToInt(Trim(Tag));
      Write(File1, cf);
    End;
    CloseFile(File1);
  End;
End;

Procedure TMAIN.TVDblClick(Sender: TObject);
Begin
  Memo2.SetFocus;
End;

Procedure TMAIN.FormKeyDown(Sender: TObject; var Key: Word;
  Shift: TShiftState);
Var
  Tag1 : string;
Begin
  If ((Shift = [ssCtrl]) And (Key = 13)) Or ((Shift = [ssAlt]) And (Key = 83)) Then Begin
    If TV.Items.Count = 0 Then Exit;
    If Length(Trim(Memo2.Text)) = 0 Then Exit;
    Tag1 := TV.Selected.Text;
    Repeat
      Tag1 := Copy(Tag1, Pos(string(' - '), Tag1) + 3, Length(Tag1) - (Pos(string(' - '), Tag1) + 2));
    Until Pos(String(' - '), Tag1) = 0 ;
    Memo1.Text := Memo1.Text + NICK + ' (' + DateTimeToStr(Time) + ')' + #13#10 +
                 Memo2.Text + #13#10 + #13#10;
    SEND_CMD_MSG (StrToInt(Trim(Tag1)), Memo2.Text);
    Memo2.Text := '';
    Key := 0;
  End;
End;

End.
