unit Unit3;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls{, Unit1, Unit2, Unit4, Unit5};

type
  TLOGINUSER = class(TForm)
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Button1: TButton;
    Button2: TButton;
    procedure FormCreate(Sender: TObject);
    procedure Button2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure Edit1KeyPress(Sender: TObject; var Key: Char);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  LOGINUSER: TLOGINUSER;

implementation

uses Unit1, Unit2, Unit4, Unit5;

{$R *.dfm}

procedure TLOGINUSER.FormCreate(Sender: TObject);
begin
  edit1.text := IntToStr(UID);
  edit3.Text := IPS;
end;

procedure TLOGINUSER.Button2Click(Sender: TObject);
begin
  Close;
end;

procedure TLOGINUSER.Button1Click(Sender: TObject);
Var
  File1 : file of _uidfile;
  uidfile : _uidfile;
begin

  // �������������� CMD_LOGIN
  If Edit2.Text = '' Then Begin
    MessageDlg('�� ������ ������!', mtError, [mbOK], 0);
    Edit2.SetFocus;
    Exit;
  End;
  SEND_CMD_LOGOFF();
  If (Edit3.Text <> IPS) Or (Edit1.Text <> IntToStr(UID)) Then Begin
    IPS := Edit3.Text;
    UID := StrToInt(Edit1.Text);
    uidfile.uid := UID;
    uidfile.ip := IPS;
    AssignFile(File1,GetCurrentDir + '\uid');
    Reset(File1);
    Write(File1, uidfile);
    CloseFile(File1);
  End;
  // �������� ���
  NICK := Edit1.Text;
  SEND_CMD_LOGIN ('Crew_Cl', StrToInt(Edit1.Text), Edit2.Text);
end;

procedure TLOGINUSER.Edit1KeyPress(Sender: TObject; var Key: Char);
begin
  If ((Key < Chr(48)) Or (Key > Chr(57))) And (Key <> Chr(8)) Then
    Key := #0;
end;

Procedure TLOGINUSER.FormClose(Sender: TObject; var Action: TCloseAction);
Begin
  Action := caFree;
End;

end.
