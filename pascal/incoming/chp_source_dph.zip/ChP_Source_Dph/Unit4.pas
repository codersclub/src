unit Unit4;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls{, Unit1, Unit2, Unit3, Unit5};

type
  TADDUSER = class(TForm)
    Edit1: TEdit;
    Edit2: TEdit;
    Button1: TButton;
    Button2: TButton;
    Label1: TLabel;
    Label2: TLabel;
    procedure Edit2KeyPress(Sender: TObject; var Key: Char);
    procedure Button1Click(Sender: TObject);
    procedure Button2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  ADDUSER: TADDUSER;

implementation

uses Unit1, Unit2, Unit3, Unit5;

{$R *.dfm}

procedure TADDUSER.Edit2KeyPress(Sender: TObject; var Key: Char);
begin
  If ((Key < #48) Or (Key > #57)) And (Key <> #8) Then
    Key := #0;
end;

Procedure TADDUSER.Button1Click(Sender: TObject);
Var
  i : integer;
  Tag : string;
  File1 : file of _contactfile;
  cf : _contactfile;
Begin
If Not USERRENAME Then Begin
  If (Edit1.Text = '') Or (Edit2.Text = '') Then Begin
    MessageDlg ('����������� ��� ����!', mtWarning, [mbOK], 0);
    Exit;
  End;

  // ������ ������ ����������� � ������
  For i := 0 To MAIN.TV.Items.Count-1 do begin
    Tag := MAIN.TV.Items[i].Text;
    While Pos(' - ', Tag) <> 0 do begin
      Tag := Copy(MAIN.TV.Items[i].Text, Pos(' - ', Tag) + 3, Length(Tag) - (Pos(' - ', Tag) + 2));
    End;
    If Trim(Tag) = Trim(Edit2.Text) Then Begin
      MessageDlg ('���������� � UID ' + Edit2.Text + ' ��� ������ � ������!', mtError, [mbOK], 0);
      Exit;
    End;
  End;

  
  MAIN.TV.Items.Add(NIL, Edit1.Text + ' - ' + Edit2.Text);
  MAIN.TV.Items[MAIN.TV.Items.Count - 1].ImageIndex := 2;
  // ���������� ���� �� �������-�����
  AssignFile(File1,GetCurrentDir + '\contact');
  Rewrite(File1);
  For i := 0 to MAIN.TV.Items.Count - 1 Do Begin
    Tag := MAIN.TV.Items[i].Text;
    Repeat
      Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
    Until Pos(String(' - '), Tag) = 0 ;
    cf.nick := Copy(MAIN.TV.Items[i].Text, 0, Length(MAIN.TV.Items[i].Text) - (Length(Tag) + 3));
    cf.uid := StrToInt(Trim(Tag));
    Write(File1, cf);
  End;
  CloseFile(File1);
  SEND_CMD_GETSTATUS(StrToInt(Edit2.Text));
End
Else Begin
  For i := 0 To MAIN.TV.Items.Count-1 do begin
    Tag := MAIN.TV.Items[i].Text;
    Repeat
      Tag := Copy(Tag, Pos(string(' - '), Tag) + 3, Length(Tag) - (Pos(string(' - '), Tag) + 2));
    Until Pos(String(' - '), Tag) = 0 ;
    If Trim(Tag) = Trim(Edit2.Text) Then Begin
      MAIN.TV.Items[i].Text := Edit1.Text + ' - ' + Edit2.Text;
    End;
  End;
End;
ADDUSER.Close;
End;

procedure TADDUSER.Button2Click(Sender: TObject);
begin
  Close;
end;

end.
