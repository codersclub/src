unit Unit7;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls;

type
  TINFO = class(TForm)
    Button1: TButton;
    Button2: TButton;
    procedure Button2Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
    procedure FormShow(Sender: TObject);
    procedure FormActivate(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  INFO: TINFO;

implementation
uses Unit1, Unit2, Unit3, Unit4, Unit5, Unit6;
{$R *.dfm}

Procedure TINFO.Button2Click(Sender: TObject);
Begin
  {If Length(Memo2.Text) = 0 Then Exit;
  Memo1.Text := Memo1.Text + NICK + ' (' + DateTimeToStr(Time) + ')' + #13#10 +
               Memo2.Text + #13#10 + #13#10;
  SEND_CMD_MSG (StrToInt(Edit2.Text), Memo2.Text);
  Memo2.Text := '';
  Edit3.Text := IntToStr(0);}
End;

procedure TINFO.FormClose(Sender: TObject; var Action: TCloseAction);
begin
  //Action := caFree;
end;

Procedure TINFO.FormShow(Sender: TObject);
Var
  i : integer;
Begin
  //CBox.clear;
  For i := 0 To MAIN.TV.Items.Count - 1 Do Begin
    //CBox.Items.Add(MAIN.TV.Items.Item[i].Text);
  End;
End;

Procedure TINFO.FormActivate(Sender: TObject);
Var
  i : integer;
Begin
  //CBox.clear;
  For i := 0 To MAIN.TV.Items.Count - 1 Do Begin
    //CBox.Items.Add(MAIN.TV.Items.Item[i].Text);
  End;
End;

End.
