unit Unit5;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, Sockets, StdCtrls, Math, Menus, Buttons, ImgList, ComCtrls,
  ExtCtrls, NMUDP{, Unit1}, Unit2, Unit3{, Unit4};

Type
  _packet = record
    v, cmd : byte;
    from, to_ : cardinal;
    data : array[0..1023] of Char;
  end;

  _login = record // (cmd\rpl)
    login : array [0..9] of Char; // �����, ����� ���� �����. ������ ������ � ���� �������� � ������ �������; uid ������������ � packet.from
    password : array [0..9] of Char; // ������
    ok : byte; // ���� � ������ ����� 1 - ������ �������, ���� 0 - ������
    reason : array [0..99] of Char; // ����������� ���� ��������� �� ������
  end;

  _info = record
    status : Byte; // ������ ������� (������ ����� ������)
    users_max : integer; // ������������ ����� ��-���� ������, ������� �������� ������������ ������
    users_num : integer; // ������� ����� ��-���� ������
    server_name : array [0..49] of Char; // ��� �������
    server_admin : array [0..49] of Char; // ����� ������� -)
    server_adm_mail : array [0..49] of Char; // ���� ������, � ������� ����� �������� �������
    motd : array [0..199] of Char; // message of the day :]
  end;

  _user_info = record
    uid : cardinal; // uid ������������
    status : byte; // ������� ������
    name : string[25]; // ���
    email : string[30]; // e-mail
    male : boolean; // true - �, false - � =)
    country : string[15]; // ������
    city : string[15]; // �����
    about : string[128]; // 64 ����� � ���� :)
  end;

  _uidfile = record
    uid : cardinal;
    ip : string[15];
  end;

  _contactfile = record
    nick : string[20];
    uid : cardinal;
  end;

Var
  // IP �������
  IPS : String;
  // ���
  NICK : String;
  // UID
  UID : cardinal;

  NEW_STATUS : Byte; // ���� �� �������� �� ������ �� ������������ ���������.

  // ����� ��� ������������/���������� ������ �����
  USERRENAME : Boolean;
  ReUserName : String;
  ReUserUID : String;

  packet : _packet;

  FL : TLOGINUSER;
  FR : TfrmREGISTER;
  
Const
    VERSION : byte = 9 ; // ������ ���������
    SERVER_UID : byte = 0; // uid �������

    STAT_ONLINE : byte = 255;
    STAT_AWAY : byte = 1;
    STAT_INVISIBLE : byte = 2;
    STAT_OFFLINE : byte = 0;
    STAT_NOTEXIST : byte = 127;

    CMD_INFO  : byte = 0;
    RPL_INFO : byte = 100;
    CMD_LOGIN : byte = 1;
    RPL_LOGIN  : byte = 101;
    CMD_STATUS : byte = 2;
    RPL_STATUS : byte = 102;
    CMD_REGISTER : byte = 3;
    RPL_REGISTER: byte = 103;
    CMD_GETSTATUS: byte = 4;
    RPL_GETSTATUS: byte = 104;
    CMD_GETADDR: byte = 5;
    RPL_GETADDR: byte = 105;
    CMD_SETINFO: byte = 6;
    RPL_SETINFO: byte = 106;
    CMD_GETINFO: byte = 7;
    RPL_GETINFO: byte = 107;
    CMD_MSG: byte = 10;
    RPL_MSG: byte = 110;
    CMD_PING: byte = 99;
    RPL_PING: byte = 199;
    CMD_LOGOUT: byte = 100;
    RPL_LOGOUT: byte = 200;

    // Port
    PORT: cardinal = 4350;

    Procedure SEND_CMD_INFO();
    Procedure GET_RPL_INFO(var server_name : String; var server_admin : String; var server_adm_mail : String; var motd : String);
    Procedure SEND_CMD_REGISTER(passwrd : String);
    Procedure GET_RPL_REGISTER(var ok : Byte; var uidreceive : cardinal);
    Procedure SEND_CMD_LOGIN(login_ : String; useruid : cardinal; psswrd : String);
    Procedure GET_RPL_LOGIN(var ok : Byte; var reason : String);
    Procedure SEND_CMD_STATUS(status : byte);
    Procedure GET_RPL_STATUS(var status : byte);
    Procedure SEND_CMD_GETSTATUS(useruid : cardinal);
    Procedure GET_RPL_GETSTATUS(var status : Byte);
    Procedure SEND_CMD_SETINFO(useruid : cardinal; status : Byte; name : String;
                           email : String; male : Boolean; country : String;
                           city : String; about : String);
    Procedure SEND_CMD_GETINFO();
    Procedure GET_RPL_GETINFO(var useruid : cardinal; var status : Byte; var name : String;
                            var email : String; var male : Boolean; var country : String;
                            var city : String; var about : String);
    Procedure SEND_CMD_MSG(touseruid : cardinal; msg : string);
    Procedure GET_RPL_MSG(var fromuseruid : cardinal; var msg : string);
    Procedure SEND_CMD_PING();
    Procedure SEND_CMD_LOGOFF();

implementation

Uses Unit1, {Unit2, Unit3} Unit4;

Procedure SEND_CMD_INFO();
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_INFO;
  packet.from := UID;
  packet.to_ := 0;
  //MAIN.UDP.SendBuf(packet,sizeof(packet));
  // �����
  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_INFO(var server_name : String; var server_admin : String; var server_adm_mail : String; var motd : String);
Var
  info : _info;
Begin
  CopyMemory(@info, @packet.data, sizeof(info));
  server_name := info.server_name;
  server_admin := info.server_admin;
  server_adm_mail := info.server_adm_mail;
  motd := info.motd;
End;

//*****************************
Procedure SEND_CMD_LOGIN(login_ : String; useruid : cardinal; psswrd : String);
Var
  MyStream: TMemoryStream;
  login : _login;
  //str : PChar;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_LOGIN;
  packet.from := useruid;
  packet.to_ := 0;
  StrCopy(login.login, PChar(login_));
  StrCopy(login.password, PChar(psswrd));
  login.ok := STAT_ONLINE;
  MoveMemory(@packet.data, @login, SizeOf(login));
// �����
  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_LOGIN(var ok : Byte; var reason : String);
Var
  login : _login;
Begin
  CopyMemory(@login, @packet.data, sizeof(login));
  ok := login.ok;
  reason := login.reason;
End;

//*****************************
Procedure SEND_CMD_STATUS(status : Byte);
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_STATUS;
  packet.from := UID;
  packet.To_ := 0;
  MoveMemory(@packet.data, @status, sizeof(status));

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_STATUS(var status : byte);
Begin
  MoveMemory(@status, @packet.data, sizeof(status));
End;

//*****************************
Procedure SEND_CMD_REGISTER(passwrd : String);
Var
  MyStream: TMemoryStream;
  str : PChar;
Begin
  str := PChar(passwrd);
  packet.v := VERSION;
  packet.cmd := CMD_REGISTER;
  packet.from := UID;
  MoveMemory(@packet.data, str, Length(str));

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_REGISTER(var ok : byte; var uidreceive : cardinal);
Begin
  uidreceive := packet.to_;
  If uidreceive = 0 Then Begin
    ok := 0;
  end
  Else Begin
    ok := 1;
  end;
  MessageDlg(IntToStr(ok), mtInformation, [mbOK], 0);
End;

//*****************************
Procedure SEND_CMD_GETSTATUS(useruid : cardinal);
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_GETSTATUS;
  packet.from := UID;
  packet.to_ := useruid;

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_GETSTATUS(var status : Byte);
Begin
  CopyMemory(@status, @packet.data, sizeof(status));
End;

//*****************************
Procedure SEND_CMD_SETINFO(useruid : cardinal; status : Byte; name : String;
                           email : String; male : Boolean; country : String;
                           city : String; about : String);
Var
  MyStream: TMemoryStream;
  info : _user_info;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_SETINFO;
  packet.from := UID;
  packet.to_ := 0;
  info.uid := useruid;
  info.status := status;
  info.name := name;
  info.email := email;
  info.male := male;
  info.country := country;
  info.city := city;
  info.about := about;
  CopyMemory(@packet.data, @info, sizeof(info));

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure SEND_CMD_GETINFO();
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_GETINFO;
  packet.from := UID;
  packet.to_ := 0;

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_GETINFO(var useruid : cardinal; var status : Byte; var name : String;
                            var email : String; var male : Boolean; var country : String;
                            var city : String; var about : String);
Var
  info : _user_info;
Begin
  CopyMemory(@info, @packet.data, sizeof(info));
  useruid := info.uid;
  status := info.status;
  name := info.name;
  email := info.email;
  country := info.country;
  city := info.city;
  about := info.about;
End;

//*****************************
Procedure SEND_CMD_MSG(touseruid : cardinal; msg : string);
Var
  MyStream: TMemoryStream;
  str : PChar;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_MSG;
  packet.from := UID;
  packet.to_ := touseruid;
  str := PChar(msg);
  MoveMemory(@packet.data, str, Length(str));

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure GET_RPL_MSG(var fromuseruid : cardinal; var msg : string);
Begin
  fromuseruid := packet.from;
  msg := packet.data;
End;

//*****************************
Procedure SEND_CMD_PING();
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_PING;
  packet.from := UID;
  packet.to_ := 0;

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

//*****************************
Procedure SEND_CMD_LOGOFF();
Var
  MyStream: TMemoryStream;
Begin
  packet.v := VERSION;
  packet.cmd := CMD_LOGOUT;
  packet.from := UID;
  packet.to_ := 0;

  MAIN.UDP.ReportLevel := Status_Basic;
  MyStream := TMemoryStream.Create;
  try
    MyStream.Write(packet, Sizeof(packet));
    MAIN.UDP.SendStream(MyStream);
  finally
    MyStream.Free;
  end;
End;

end.
 