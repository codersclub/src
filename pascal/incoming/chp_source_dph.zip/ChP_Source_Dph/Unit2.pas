unit Unit2;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls{, Unit1, Unit3, Unit4, Unit5};

type
  TfrmREGISTER = class(TForm)
    Edit1: TEdit;
    Edit2: TEdit;
    Edit3: TEdit;
    Label1: TLabel;
    Label2: TLabel;
    Label3: TLabel;
    Button1: TButton;
    Button2: TButton;
    procedure Button2Click(Sender: TObject);
    procedure Button1Click(Sender: TObject);
    procedure FormClose(Sender: TObject; var Action: TCloseAction);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  frmREGISTER: TfrmREGISTER;

implementation

//uses Unit1;

Uses Unit1, Unit3, Unit4, Unit5;

{$R *.dfm}

procedure TfrmREGISTER.Button2Click(Sender: TObject);
begin
  Close;
end;

procedure TfrmREGISTER.Button1Click(Sender: TObject);
begin
  if Edit1.Text <> Edit2.Text then  begin
    Edit1.Text := '';
    Edit2.Text := '';
    MessageDlg('�� ��������� ������ � �������������!', mtWarning, [mbOK], 0);
    Edit1.SetFocus;
  end
  else begin
    IPS := Edit3.text;
    MAIN.UDP.RemoteHost := IPS;
    //If not MAIN.UDPSock.Connected Then MAIN.UDPSock.Connect;
    SEND_CMD_REGISTER (Edit1.Text);
  end;
end;

Procedure TfrmREGISTER.FormClose(Sender: TObject; var Action: TCloseAction);
Begin
   Action := caFree;
End;

End.
