/*****************************************************************************
| XtaC
|
| WCFIRE.C
|
| Compiled with Watcom C v10.0
|
| This file makes a fire like effect (yep, another) using a memory buffer.
| You can use this code in your demo, game, or whatever you like, as long as
| you make some reference of any kind to me. (greets)
|
*****************************************************************************/
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <dos.h>

/* define the mem location of vga memory */
#define PMODE_VGA 0xA0000L

/* declaration of external assembler functions */
extern void pascal tweakvga();
extern void pascal waitretrace();
extern void pascal setmcga();
extern void pascal settext();

/* some handy variables */
int x,y,cont=1,i,a,b,c,d;
char *ptr,color;
unsigned char screen[80][53]; /* our buffer */

/* function to set the r,g,b values of a color */
void setpal(int c,int r,int g,int b)   {
    outp(0x3c8,c);
    outp(0x3c9,r);
    outp(0x3c9,g);
    outp(0x3c9,b);
}

void main()     {
    tweakvga();
    for(x=1;x<=32;x++)      {
        setpal(x, (x << 1)-1, 0, 0 );
        setpal(x+32, 63, (x << 1)-1, 0 );
        setpal(x+64, 63, 63, (x << 1)-1 );
        setpal(x+96, 63, 63, 63 );
    }
    while(!kbhit())   {
        for(x=1;x<79;x++) screen[x][51] = rand();
        for(x=1;x<79;x++)
            for(y=0;y<50;y++)   {
                a = screen[x][y+2];
                b = screen[x][y+3];
                c = screen[x+1][y+1];
                d = screen[x-1][y+1];
                color = (a+b+c+d) >> 2;
                if((color > 0) && (color < 50)) color--;
                *ptr = color;
                ptr = (char *)PMODE_VGA;
                ptr += x+((y<<6)+(y<<4));
                screen[x][y] = color;
           }
        waitretrace();
    }
    settext();
    printf("XtaC/AD Tweaked Mode Fire (in Watcom C).\n");
}
