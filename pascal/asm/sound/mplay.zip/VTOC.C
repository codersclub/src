#include <stdio.h>
#include <dos.h>
#include <string.h>
#include <conio.h>


/* Audio CD VTOC read utility */
/* Use TC or BC compilers */


/* Device driver commands */
#define	DEVRDIOCTL	 3	/* IOCTL read			*/
#define	DEVPLAY		132	/* Device Play			*/
#define	DEVSTOP		133	/* Stop device play		*/

/* CDROM Device IOCTL commands */
#define	IOI_audio_diskinfo	10
#define	IOI_audio_trackinfo	11

typedef	unsigned char	uchar;
typedef	unsigned short	ushort;
typedef	unsigned int	uint;
typedef	unsigned long	ulong;

	/* Device driver request header */
typedef struct Request_Hdr {
	uchar		rqh_len;
	uchar		rqh_unit;
	uchar		rqh_cmd;
	ushort		rqh_status;
	uchar		rqh_rsvd[8];
	} Request_Hdr;

	/* Request header for INIT function */
typedef struct Init_Hdr {
	Request_Hdr	init_rqh;
	uchar		init_units;
	uchar	far	*init_endaddr;
	uchar	far	*init_bpbarr;
	uchar		init_devno;
	} Init_Hdr;

	/* Request header for IOCTL command */
typedef struct Ioctl_Hdr {
	Request_Hdr	ioctl_rqh;
	uchar		ioctl_media;
	uchar far	*ioctl_xfer;
	ushort		ioctl_nbytes;
	ushort		ioctl_sector;
	uchar far	*ioctl_volid;
	} Ioctl_Hdr;

	/* Request header for Read/Write command */
typedef struct ReadWriteL_Hdr {
	Request_Hdr	rwl_rqh;
	uchar		rwl_addrmd;
	uchar far	*rwl_xfer;
	ushort		rwl_nsects;
	ulong		rwl_sectno;
	uchar		rwl_mode;
	uchar		rwl_ilsize;
	uchar		rwl_ilskip;
	ushort		rwl_reqno;
	} ReadWriteL_Hdr;

	/* Record for audio_diskinfo IOCTL call */
typedef struct DiskInfo_Rec {
	uchar	cmd_code;
	uchar	lo_tno;
	uchar	hi_tno;
	ulong	lead_out;
	} DiskInfo_Rec;

	/* Record for audio_trackinfo IOCTL call */
typedef struct TnoInfo_Rec {
	uchar	cmd_code;
	uchar	tno;
	ulong	start_addr;
	uchar	ctrl;
	} TnoInfo_Rec;


	/* Format for CDROM device driver header at CS:0 of device driver
	** Slightly extended from standard MSDOS character device driver
	*/
typedef struct Dev_Hdr {
	struct Dev_Hdr far *sdevnext;	/* Pointer to next dev header */
	ushort	  sdevatt;		/* Attributes of the device   */
	void	  near (*sdevstrat)();	/* Strategy entry point       */
	void	  near (*sdevint)();	/* Interrupt entry point      */
	uchar	  sdevname[8];		/* Name of device (only first byte used for block) */
	ushort	  sdevrsvd;		/* Reserved word	      */
	uchar	  sdevlet;		/* Drive letter of first unit */
	uchar	  sdevunits;		/* Number of units handled    */
	} Dev_Hdr;

static TnoInfo_Rec	TnoInfo[99 + 1];	/* Table of info for all tracks	*/
static DiskInfo_Rec	DiskInfo;		/* Disk information for CD	*/
static Dev_Hdr far *    Dev_Addr;		/* Devive header address 	*/
static Ioctl_Hdr	Ioctl_Rec;		/* Record for IOCTL requests	*/
static ushort		Num_Tracks;




typedef union {
   ulong timep;
   struct {
      signed char frm;
      signed char sec;
      signed char min;
      char reserved1;
   } time;
} RedTime;


void dsp_addr(ulong addr)
{
   RedTime t;
   t.timep = addr;
   printf("%02d:",t.time.min);
   printf("%02d.",t.time.sec);
   printf("%02d", t.time.frm);
}


ulong red2hsg(ulong l)
{
   RedTime t;
   t.timep = l;
   return (ulong) t.time.min * 60 * 75 +
	  (uint)  t.time.sec * 75 +
	  (uint)  t.time.frm;
}


ulong sub_time(ulong time1, ulong time2)
{
   RedTime t1,t2;
   t1.timep = time1;
   t2.timep = time2;
   if((t1.time.frm -= t2.time.frm) < 0) { t1.time.frm += 75; t2.time.sec--; }
   if((t1.time.sec -= t2.time.sec) < 0) { t1.time.sec += 60; t2.time.min--; }
   if((t1.time.min -= t2.time.min) < 0) { t1.timep = 0; }
   return t1.timep;
}


void send_req(ReadWriteL_Hdr far *io, Dev_Hdr far *drv)
{
   void far (*dev_strat)(void);
   void far (*dev_int)(void);

   dev_strat = MK_FP(FP_SEG(drv), drv->sdevstrat);
   dev_int   = MK_FP(FP_SEG(drv), drv->sdevint);

   _BX = FP_OFF(io);
   _ES = FP_SEG(io);
   dev_strat();
   dev_int();
}


uint ioctl(Dev_Hdr far *drv, uchar *xbuf, uchar cmd, uchar cmdlen)
{
   register Ioctl_Hdr	*io = &Ioctl_Rec;

   io->ioctl_rqh.rqh_len    = sizeof(Ioctl_Hdr);
   io->ioctl_rqh.rqh_unit   = 0; /*drv->sub_unit; */
   io->ioctl_rqh.rqh_cmd    = DEVRDIOCTL;
   io->ioctl_rqh.rqh_status = 0;

   io->ioctl_media  = 0;
   io->ioctl_xfer   = (uchar far *) xbuf;
   *xbuf	    = cmd;
   io->ioctl_nbytes = cmdlen;
   io->ioctl_sector = 0;
   io->ioctl_volid  = 0;

   send_req((ReadWriteL_Hdr far *) io, drv);

   if (io->ioctl_rqh.rqh_status & 0x8000) return(-1);

   return(0);
}


void read_toc(Dev_Hdr far *drv)
{
   TnoInfo_Rec	*t;
   uint	   i, msg=0;

   for(;;) {
      if(ioctl(drv, (uchar*)&DiskInfo, IOI_audio_diskinfo, sizeof(DiskInfo_Rec)) == 0) break;
      else {
	 if(msg == 0) {
	    printf("Insert some disk...\n");
	    msg++;
	 }
      }
      if(kbhit() && getch() == 033) {
	 printf("Oblomized by user :)\n");
	 return;
      }
   }

   Num_Tracks = DiskInfo.hi_tno - DiskInfo.lo_tno + 1;
   TnoInfo[Num_Tracks].start_addr = DiskInfo.lead_out;

   printf("LowTrack=%02d ", DiskInfo.lo_tno);
   printf("HighTrack=%02d ", DiskInfo.hi_tno);
   printf("TotalTracks=%02d ", DiskInfo.hi_tno-DiskInfo.lo_tno+1);
   printf("LeadOut=");
   dsp_addr(DiskInfo.lead_out);
   printf("\n\n");

   t = TnoInfo;
   for (i = DiskInfo.lo_tno; i <= DiskInfo.hi_tno; i++,t++) {
      t->tno = (uchar)i;
      ioctl(drv,(uchar *) t, IOI_audio_trackinfo, sizeof(TnoInfo_Rec));
   }

   for(i = 0; i < Num_Tracks; i++) {
      t = TnoInfo + i;
      printf("Track %02d: Start=", t->tno);
      dsp_addr(t->start_addr);
      printf(", Time=");
      dsp_addr(sub_time((t+1)->start_addr, t->start_addr));
      printf("\n");
   }
}

static void MemCpy(char *str1, uchar far *str2, uint n)
{
   while(n--) *str1++ = *str2++;
}


int find_drivers(char *name)
{
   union  REGS	inregs;
   union  REGS	outregs;
   struct SREGS segregs;
   uint		i, n;
   Dev_Hdr far *dh;

   char devnm[10], localnm[10];

   memset(devnm, ' ', 8);
   memcpy(devnm, name, strlen(name));

   /* Get device chain */
   inregs.h.ah = 0x52;
   int86x(0x21, &inregs, &outregs, &segregs);
   dh = MK_FP(segregs.es, outregs.x.bx+0x22);

   {
      for(n = i = 0; i < 32; i++) {
	 if(FP_OFF(dh->sdevnext) == 0xFFFF) break;
	 MemCpy(localnm, dh->sdevname, 8);
	 if(strnicmp(localnm, devnm, 8) == 0) {
	    n = 1;
	    break;
	 }
	 dh = dh->sdevnext;
      }
      if(n == 0) {
	 printf("Device not found\n");
	 return -1;
      }
      Dev_Addr = (Dev_Hdr far *)dh;
   }
   return 0;
}




void main(int argc, char *argv[])
{
   printf("\nAudio CD VTOC read utility\n\n");
   if(argc == 1) {
      printf("usage: Vtoc <DEVIVE_NAME>\n");
      return;
   }

   if(find_drivers(argv[1]) == 0) {
      read_toc(Dev_Addr);
   }
}

