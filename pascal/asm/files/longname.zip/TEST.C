/*****************************************************************************/
/*									     */
/*    TEST.C -- Test program for long filename API			     */
/*									     */
/*    Written by Walter Oney						     */
/*									     */
/*    Compile with C8 (16-bit), as follows:				     */
/*	 cl -c -Zi -Od -G3 test.c					     */
/*									     */
/*****************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <dos.h>
#include <io.h>
#include <fcntl.h>
#include <sys\types.h>
#include <sys\stat.h>
#include <errno.h>

#include "longname.h"

void main(int argc, char *argv[])
   {				 // main
   char *pattern, *filename, *dirname;
   char buffer[_MAX_PATH];	 // buffer to receive filenames
   DWORD n;			 // string length
   WIN32_FIND_DATA fd;		 // for Find First/Next
   HANDLE hfind;		 // find-file handle for Find First/Next/Close
   char volname[32];		 // label of this volume
   DWORD volser;		 // serial number of this volume
   DWORD maxname, maxpath;	 // name capacities
   DWORD flags; 		 // file system flags
   char fsname[32];		 // name of file system
   FILE *fp;			 // stream pointer
   int hfile;			 // file handle
   unsigned short attr; 	 // attribute byte

   if (argc <= 3)
      { 			 // not enough args
      puts("Usage is: TEST search-pattern  text-filename  dir-name");
      exit(1);
      } 			 // not enough args
   pattern = argv[1];
   filename = argv[2];
   dirname = argv[3];

/* GetCurrentDirectory */

   n = GetCurrentDirectory(1, buffer);
   printf("1st call to GetCurrentDirectory returned %d\n", n);
   n = GetCurrentDirectory(n+1, buffer);
   printf("Current Directory is %s, length %d\n\n", buffer, n);

/* Find First/Next/Close */

   hfind = FindFirstFile(pattern, &fd);
   if (hfind)
      { 			 // found matching files
      printf("Matches for %s:\n", pattern);
      do {			 // for each match
	 SYSTEMTIME st;
	 printf("%s (%s)", fd.cFileName, fd.cAlternateFileName);
	 FileTimeToSystemTime(&fd.ftLastWriteTime, &st);
	 printf(" %2.2d/%2.2d/%2.2d %2.2d:%2.2d:%2.2d.%3.3d\n",
	    st.wMonth, st.wDay, st.wYear,
	    st.wHour, st.wMinute, st.wSecond, st.wMilliseconds);
	 }			 // for each match
      while (FindNextFile(hfind, &fd));
      FindClose(hfind);
      } 			 // found matching files
   else
      printf("No matches for %s\n", pattern);

/* GetVolumeInformation: */

   GetVolumeInformationEx(NULL, volname, sizeof(volname),
      &volser, &maxname, &maxpath, &flags, fsname, sizeof(fsname));
   printf("\nvolname %s\nvolser %4.4X-%4.4X\nmaxname %ld\nmaxpath %ld\n"
      "flags %8.8lX\nfsname %s\n",
      volname, (WORD) (volser >> 16), (WORD) volser, maxname, maxpath,
      flags, fsname);

/* _sopen path through fopen into _open */

   printf("\nAttempting to open and print '%s':\n\n", filename);
   fp = fopen(filename, "r");
   while (fgets(buffer, sizeof(buffer), fp))
      fputs(buffer, stdout);
   fclose(fp);

/* Directory functions */

   putchar('\n');
   _rmdir(dirname);		 // delete directory in case it's already there
   if (_mkdir(dirname) == 0)
      { 			 // created directory okay
      printf("Created directory '%s' okay\n", dirname);
      if (_chdir(dirname) == 0)
	 {			 // changed to directory okay
	 GetCurrentDirectory(sizeof(buffer), buffer);
	 printf("Successfully changed directories to '%s'\n", buffer);
	 if (_rmdir(dirname) == 0)
	    printf("_rmdir(%s) succeeded when it shouldn't have\n", dirname);
	 else if (errno = EACCES)
	    printf("_rmdir(%s) failed when it should have\n", dirname);
	 else
	    perror("ERROR: Deleting current directory");

	 if (_dos_creat(filename, _A_NORMAL, &hfile) == 0)
	    {			 // created file okay
	    printf("Created '%s' okay\n", filename);
	    _dos_close(hfile);
	    if (_dos_creatnew(filename, _A_NORMAL, &hfile) == 0)
	       {
	       printf("Create new '%s' unexpectedly worked\n", filename);
	       _dos_close(hfile);
	       }
	    else if (errno == EEXIST)
	       printf("Create new '%s' failed as expected\n", filename);
	    else
	       perror("ERROR: Unexpected error trying to recreate existing file");

	    if (rename(filename, "junk.jnk") == 0)
	       printf("Renamed '%s' to 'junk.jnk' okay\n", filename);
	    else
	       perror("ERROR: Renaming file");

	    if (remove("junk.jnk") == 0)
	       printf("Deleted '%s' okay\n", "junk.jnk");
	    else
	       perror("ERROR: Deleting file");
	    }			 // created file okay

	 _chdir("..");
	 }			 // changed to directory okay
      if (_rmdir(dirname) == 0)
	 printf("Deleted directory '%s' okay\n", dirname);
      else
	 perror("ERROR: Deleting directory");
      } 			 // created directory okay
   else
      perror("ERROR: Creating directory");

/* DOS access functions */

   _dos_setfileattr(filename, _A_RDONLY);
   if (_dos_getfileattr(filename, &attr) == 0)
      printf("Got attribute for '%s' okay: %2.2X\n", filename, attr);
   else
      perror("ERROR: Getting attribute");

   if (_dos_setfileattr(filename, _A_NORMAL) == 0)
      printf("Changed attribute for '%s' okay\n", filename);
   else
      perror("ERROR: Setting attribute");

   if (_dos_getfileattr("nosuch.fil", &attr) == 0)
      printf("Get file attribute(nosuch.fil) unexpectedly worked\n");
   else if (errno != ENOENT)
      perror("ERROR: Getting attribute of nosuch.fil");
   else
      printf("Get file attribute(nosuch.fil) failed as expected\n");

   if (_dos_setfileattr("nosuch.fil", attr) == 0)
      printf("Get file attribute(nosuch.fil) unexpectedly worked\n");
   else if (errno != ENOENT)
      perror("ERROR: Setting attribute of nosuch.fil");
   else
      printf("Set file attribute(nosuch.fil) failed as expected\n");

   if (_dos_open(filename, _O_RDONLY, &hfile) == 0)
      { 			 // opened file okay
      printf("Opened '%s' okay\n", filename);
      _dos_close(hfile);
      } 			 // opened file okay
   else
      perror("ERROR: Opening file");

   if (_dos_open("nosuch.fil", _O_RDONLY, &hfile) == 0)
      printf("Open of nosuch.fil unexpectedly worked\n");
   else if (errno == ENOENT)
      printf("Open of nosuch.fil failed as expected\n");
   else
      perror("ERROR: Unexpected error opening nosuch.fil");

   exit(0);
   }				 // main
