tasm32  /ml killball.asm
brcc32 killball.rc
tlink32 /Tpe /aa /c killball.obj,killball.exe,,,,killball.res
del *.map
del *.obj