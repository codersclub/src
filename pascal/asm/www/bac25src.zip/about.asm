.386
.model flat, stdcall
option casemap :none

include windows.inc
include kernel32.inc
include user32.inc
include gdi32.inc

includelib kernel32.lib
includelib user32.lib
includelib gdi32.lib

; ############# ���������� ������� ########################################
CenterWindow proto :DWORD, :DWORD
; #########################################################################
EXTERN hwnd:HWND
; #########################################################################
IDC_AOKB EQU 1001
; #########################################################################



.data

.code

AboutProc proc hWnd:HWND, uMsg:UINT, wParam:WPARAM, lParam:LPARAM

  .if uMsg == WM_INITDIALOG
  
    invoke GetModuleHandle, NULL
    invoke LoadIcon, eax, 10001
    invoke SendMessage, hWnd, WM_SETICON, ICON_BIG, eax
    invoke CenterWindow, hWnd, hwnd
  
  .elseif uMsg == WM_CLOSE
  
    invoke EndDialog, hWnd, NULL
    
  .elseif uMsg == WM_COMMAND
     mov eax, wParam  
    .if lParam == 0
    
    .else
      mov edx, wParam
      shr edx, 16
      .if dx == BN_CLICKED      ; ������ �� ������ ��� checkbox
        .if ax == IDC_AOKB
          invoke EndDialog, hWnd, NULL
        .endif 
      .endif  
    .endif
    
  .else
    
    mov eax, FALSE
    ret
    
  .endif

  ret

AboutProc endp

end

; #########################################################################
