IMG2BYTE 24/07/2000 rednuht

Disclaimer: Im not responsible for anything ever!

This is a quick hack Java Application to convert image files (see below) to BYTE include files.

I found using the Dream animator very problematic so started to use Paint Shop Pro with maximum zoom to create my 48x32 pixel images.

I then found I need this progie (written in minutes (about 20)) it takes a input image file (see below) and produces a text file with the binary data for a black and white version of the input image.

Usage:
You will need the JDK or JRE to run this application (not applet), both available from http://java.sun.com

JRE:
jre -cp . img2byte INPUT OUTPUT [/i]

JDK:
java img2byte INPUT OUTPUT [/i]

INPUT should be an image file (preferably GIF) (48 pixels wide, any length)
OUTPUT should be the name of your file to save the result to.

File formats:
Because the program does not do any color reduction .JPG are are unpredictable due to the large number of colors even in a simaple black and white image.
The first pixel encountered is used as BLACK and any color there following, that is not the same as BLACK is seen as WHITE (use the /i command line to inverse this).

The code:
Don't look at it!
its not pretty but it does work (sometimes)

What do I do with the OUTPUT file?
Use it in you code (copy and paste) or link to it as an include file.
i.e.        .include "loadscreen.i"

Files in this ZIP file:
img2byte.class - the main 'executable' (see USAGE)
img2byte.java  - the source code so you can hack it around to your needs.
readme.tx      - you are reading it!

 
Have fun and if it does not work do not blame me!


This code is also posted on http://www.planet-source-code.com


















rednuht@rocketmail.com