IMG2HTML 24/07/2000 

Disclaimer: Im not responsible for anything ever!

This is a quick hack Java Application to convert image files to HTML files.

Usage:
You will need the JDK or JRE to run this application (not applet), both available from http://java.sun.com

JRE:
jre -cp . img2html INPUT OUTPUT 

JDK:
java img2html INPUT OUTPUT 

INPUT should be an image file (preferably GIF) (Keep the size down! (see below)))
OUTPUT should be the name of your file to save the result to.

File formats:
GIF
JPG
(maybe others have not checked)

The code:
Don't look at it!
its not pretty but it does work (sometimes)


W A R N I N G !!
================
I ran this little progie on an image 750x500 pixels on NT4 PIII 550 with 128mb RAM and it took 20 hours to run
and produced a 20mb html file that crashes netscape(v4) and IE (5.1) Hotjava fell over trying to load it as well.

he he.





Files in this ZIP file:
img2html.class - the main 'executable' (see USAGE)
img2html.java  - the source code so you can hack it around to your needs.
3.jpg			- sample image
3.html		- sample output.
readme.txt      - you are reading it!


How does it work?
For each row of the image a HTML TABLE ROW is written to the file and a TD tag with color info for EACH pixel.
Its only a bit of fun and its not very fast, could be optimised!.
 
Have fun and if it does not work do not blame me!


This code is also posted on http://www.planet-source-code.com


















rednuht@rocketmail.com