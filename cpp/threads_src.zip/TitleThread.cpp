// TitleThread.cpp: implementation of the CTitleThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Threads.h"
#include "TitleThread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CTitleThread::CTitleThread()
{

}

CTitleThread::~CTitleThread()
{

}

DWORD CTitleThread::ThreadFunc()
{
	CString sTitle="������ � ��������";
	int i,j;
	for(;;)
	{
		if (m_bTerminated)
			break;
		if (m_pWnd)
		{
			CString sCurTitle;
			for(i=1;i<=sTitle.GetLength();i++)
			{
				if (m_bTerminated)
					break;
				sCurTitle=sTitle.Left(i);
				m_pWnd->SetWindowText(sCurTitle);
				for(j=10;j>0;j--)
				{
					Sleep(20);
					if (m_bTerminated)
						break;
				}
			}
			if (m_bTerminated)
				break;
			for(j=50;j>0;j--)
			{
				Sleep(20);
				if (m_bTerminated)
					break;
			}
			if (m_bTerminated)
				break;
			for(i=sTitle.GetLength();i>=0;i--)
			{
				if (m_bTerminated)
					break;
				sCurTitle=sTitle.Right(i);
				m_pWnd->SetWindowText(sCurTitle);
				for(j=10;j>0;j--)
				{
					Sleep(10);
					if (m_bTerminated)
						break;
				}
			}
			//m_pWnd->SetWindowText();
		}
	}
	return 0;
}
