// MyThread.h: interface for the CMyThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYTHREAD_H__6B892D2F_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
#define AFX_MYTHREAD_H__6B892D2F_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMyThread  
{
	friend DWORD WINAPI ThreadProc(LPVOID lpParameter);
	HANDLE m_hThread;
public:
	DWORD Terminate(BOOL bCritical=FALSE);
	BOOL Execute();
	CMyThread();
	virtual ~CMyThread();

protected:
	DWORD m_dwID;
	virtual DWORD ThreadFunc()=NULL;
	BOOL m_bTerminated;
};

#endif // !defined(AFX_MYTHREAD_H__6B892D2F_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
