Threads example.
This example illustrates how to ccreate threads based classes.