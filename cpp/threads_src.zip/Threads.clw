; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CThreadsDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Threads.h"

ClassCount=2
Class1=CThreadsApp
Class2=CThreadsDlg

ResourceCount=3
Resource2=IDD_THREADS_DIALOG
Resource1=IDR_MAINFRAME
Resource3=IDD_THREADS_DIALOG (English (U.S.))

[CLS:CThreadsApp]
Type=0
HeaderFile=Threads.h
ImplementationFile=Threads.cpp
Filter=N

[CLS:CThreadsDlg]
Type=0
HeaderFile=ThreadsDlg.h
ImplementationFile=ThreadsDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_ABOUT



[DLG:IDD_THREADS_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CThreadsDlg

[DLG:IDD_THREADS_DIALOG (English (U.S.))]
Type=1
Class=CThreadsDlg
ControlCount=7
Control1=IDC_RESWND,static,1342308352
Control2=IDC_START,button,1342242816
Control3=IDC_STOP,button,1342242816
Control4=IDC_STARTVALUE,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352
Control7=IDC_ABOUT,button,1342242816

