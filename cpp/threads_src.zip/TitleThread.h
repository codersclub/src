// TitleThread.h: interface for the CTitleThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TITLETHREAD_H__A66FAE61_9E10_11D5_A3EE_C93C88408B25__INCLUDED_)
#define AFX_TITLETHREAD_H__A66FAE61_9E10_11D5_A3EE_C93C88408B25__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyThread.h"

class CTitleThread : public CMyThread  
{
public:
	CWnd * m_pWnd;
	CTitleThread();
	virtual ~CTitleThread();

protected:
	DWORD ThreadFunc();
};

#endif // !defined(AFX_TITLETHREAD_H__A66FAE61_9E10_11D5_A3EE_C93C88408B25__INCLUDED_)
