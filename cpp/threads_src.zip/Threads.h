// Threads.h : main header file for the THREADS application
//

#if !defined(AFX_THREADS_H__6B892D25_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
#define AFX_THREADS_H__6B892D25_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CThreadsApp:
// See Threads.cpp for the implementation of this class
//

class CThreadsApp : public CWinApp
{
public:
	CThreadsApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CThreadsApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CThreadsApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_THREADS_H__6B892D25_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
