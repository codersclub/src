// MathThread.cpp: implementation of the CMathThread class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Threads.h"
#include "MathThread.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CMathThread::CMathThread()
{
	m_dValue=0;
	m_pResWnd=NULL;
}

CMathThread::~CMathThread()
{

}

DWORD CMathThread::ThreadFunc()
{
	for(;;)
	{
		if (m_bTerminated)
			break;
		m_dValue+=.00001;
		//Sleep(1);
		if (m_pResWnd)
		{
			char txt[128];
			sprintf(txt,"%g",m_dValue);
			m_pResWnd->SetWindowText(txt);
		}
	}
	return 0;
}
