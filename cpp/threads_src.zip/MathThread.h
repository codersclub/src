// MathThread.h: interface for the CMathThread class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MATHTHREAD_H__6B892D31_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
#define AFX_MATHTHREAD_H__6B892D31_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyThread.h"

class CMathThread : public CMyThread  
{
public:
	CWnd * m_pResWnd;
	double m_dValue;
	CMathThread();
	virtual ~CMathThread();

protected:
	DWORD ThreadFunc();
};

#endif // !defined(AFX_MATHTHREAD_H__6B892D31_9DF8_11D5_A3EE_E2D14EB90E01__INCLUDED_)
