// ThreadsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Threads.h"
#include "ThreadsDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CThreadsDlg dialog

CThreadsDlg::CThreadsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CThreadsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CThreadsDlg)
	m_dStartValue = 0.0;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CThreadsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CThreadsDlg)
	DDX_Text(pDX, IDC_STARTVALUE, m_dStartValue);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CThreadsDlg, CDialog)
	//{{AFX_MSG_MAP(CThreadsDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_START, OnStart)
	ON_BN_CLICKED(IDC_STOP, OnStop)
	ON_WM_DESTROY()
	ON_BN_CLICKED(IDC_ABOUT, OnAbout)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CThreadsDlg message handlers

BOOL CThreadsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	m_TitleThread.m_pWnd=this;
	m_TitleThread.Execute();
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CThreadsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CThreadsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CThreadsDlg::OnStart() 
{
	// TODO: Add your control notification handler code here
	m_MathThread.m_pResWnd=GetDlgItem(IDC_RESWND);
	CString sValue;
	UpdateData(TRUE);
	m_MathThread.m_dValue=m_dStartValue;
	m_MathThread.Execute();
}

void CThreadsDlg::OnStop() 
{
	// TODO: Add your control notification handler code here
	m_MathThread.Terminate();
	m_dStartValue=m_MathThread.m_dValue;
	UpdateData(FALSE);
}

void CThreadsDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	
	// TODO: Add your message handler code here
	m_TitleThread.Terminate();
	m_MathThread.Terminate();
}

void CThreadsDlg::OnAbout() 
{
	// TODO: Add your control notification handler code here
	AfxMessageBox("MessageBox ��������, � ����� �������.\n\n���������� ���������, �����������\nbestx@mail.ru");
}
