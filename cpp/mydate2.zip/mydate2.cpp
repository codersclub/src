// mydate2.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "dmsDate.h"

int main(int argc, char* argv[])
{
	CdmsDate a1;
	try
	{
		CdmsDate a(29,2,2001);
	}
	catch(CdmsDate::Error)
	{
		printf("Incorrect date \r\n");
	}
	
	a1="10.1.2000";
	CdmsDate a2(10,1,2000);
	if(a1==a2)
	{
		printf("a1==a2\r\n");
	}
	a2+=20;
	if(a1<=a2)
	{
		printf("a1<a2+20\r\n");
	}
	a2.SetDay(3);
	a2.SetMonth(3);
	int n=a2-a1;//53
	CdmsDate a3=a1+"25.1.1";//7.3.2001
	printf("n=%d\n",n);
	printf(a3.tstr());
	printf("\r\n");
	printf("%d\r\n",a1-a3);
//	a1.SetYear(2001);
	printf("a1=");
	printf(a1.tstr());
	printf("\r\n");
	a2=a1+=100;
	printf("a2=");
	printf(a1.tstr());
	printf("\r\n");
	a1-=110;
	printf("a1=");
	printf(a1.tstr());
	printf("\r\n");
	printf("a2-a1=%d\r\n",a2-a1);
	printf("3.3.2001-3.4.2001=%d\r\n",(CdmsDate)"3.3.2001"-"3.4.2001");
//	scanf(" ");
	return 0;
}
