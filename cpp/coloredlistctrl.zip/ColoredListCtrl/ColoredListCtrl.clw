; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CColorListCtrl
LastTemplate=CListCtrl
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ColoredListCtrl.h"

ClassCount=4
Class1=CColoredListCtrlApp
Class2=CColoredListCtrlDlg
Class3=CAboutDlg

ResourceCount=3
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Class4=CColorListCtrl
Resource3=IDD_COLOREDLISTCTRL_DIALOG

[CLS:CColoredListCtrlApp]
Type=0
HeaderFile=ColoredListCtrl.h
ImplementationFile=ColoredListCtrl.cpp
Filter=N

[CLS:CColoredListCtrlDlg]
Type=0
HeaderFile=ColoredListCtrlDlg.h
ImplementationFile=ColoredListCtrlDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_BUTTON_ColorSet

[CLS:CAboutDlg]
Type=0
HeaderFile=ColoredListCtrlDlg.h
ImplementationFile=ColoredListCtrlDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_COLOREDLISTCTRL_DIALOG]
Type=1
Class=CColoredListCtrlDlg
ControlCount=33
Control1=IDC_LIST1,SysListView32,1350632457
Control2=IDC_BUTTON_Set,button,1342242816
Control3=IDC_EDIT_ItemSubPos,edit,1350631552
Control4=IDC_EDIT_ItemPos,edit,1350631552
Control5=IDC_COMBO_TextCol,combobox,1344339971
Control6=IDC_COMBO_BackGnd,combobox,1344339971
Control7=IDC_STATIC,static,1342308352
Control8=IDC_STATIC,static,1342308352
Control9=IDC_STATIC,static,1342308352
Control10=IDC_STATIC,static,1342308352
Control11=IDC_EDIT_ItemDelInsPos,edit,1350631552
Control12=IDC_STATIC,static,1342308352
Control13=IDC_EDIT_ItemText,edit,1350631552
Control14=IDC_EDIT_SubText1,edit,1350631552
Control15=IDC_EDIT_SubText2,edit,1350631552
Control16=IDC_STATIC,static,1342308352
Control17=IDC_BUTTON_insert,button,1342242816
Control18=IDC_BUTTON_delete,button,1342242816
Control19=IDC_STATIC,static,1342177287
Control20=IDC_RADIO_BITS,button,1342373897
Control21=IDC_RADIO2,button,1342177289
Control22=IDC_RADIO3,button,1342177289
Control23=IDC_EDIT_ItemStatePos,edit,1350631552
Control24=IDC_STATIC,static,1342308352
Control25=IDC_STATIC,static,1342177287
Control26=IDC_BUTTON_ColorSet,button,1342242816
Control27=IDC_STATIC,static,1342177287
Control28=IDC_STATIC,static,1342177287
Control29=IDC_EDIT_ItemColoredText,edit,1350631552
Control30=IDC_STATIC,static,1342308352
Control31=IDC_CHECK_DotFocus,button,1342242819
Control32=IDC_CHECK_WithRect,button,1342242819
Control33=IDC_CHECK_VertLines,button,1342242819

[CLS:CColorListCtrl]
Type=0
HeaderFile=ColorListCtrl.h
ImplementationFile=ColorListCtrl.cpp
BaseClass=CListCtrl
Filter=W
LastObject=CColorListCtrl
VirtualFilter=FWC

