#define STRICT				//����������� ������� �������� �����
#include <windows.h>		//���� ����������� ������� windows
#include <windowsx.h>		//���� ���������������� windows
#include <commctrl.h>		//������� ������ �� ������������ ������ windows
#pragma comment(lib, "comctl32.lib")

#include "ImageListEx.h"
#include "resource.h"		//���� ����������� �������� ��������



BOOL WINAPI MainDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);


int WINAPI WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpszCmdParam, int nCmdShow)
{
	InitCommonControls();
	return DialogBox(hInst, TEXT("MAIN"), HWND_DESKTOP, MainDlgProc);
}


#pragma pack(push, 8)

#define BCM_FIRST			0x1600
#define BCM_SETIMAGELIST	(BCM_FIRST + 0x0002)

struct BUTTON_IMAGELIST
{
    HIMAGELIST  himl;       // Index: Normal, hot, pushed, disabled, focused.
    RECT        margin;     // Margin around icon.
    UINT        uAlign;
};

#pragma pack(pop)


BOOL WINAPI MainDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
		{
			HICON hIcon, hIcon0, hIcon1;

			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 32, 32, LR_CREATEDIBSECTION);
			SendMessage(hdlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 16, 16, LR_CREATEDIBSECTION);
			SendMessage(hdlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 48, 48, LR_CREATEDIBSECTION);
			SendDlgItemMessage(hdlg, IDC_LOGO, STM_SETIMAGE, IMAGE_ICON, (LPARAM)hIcon);
			HFONT hfont = CreateFont(-24,0,0,0,700,1,0,0,RUSSIAN_CHARSET,0,0,0,0,"Times New Roman Cyr");
			SetWindowFont(GetDlgItem(hdlg,IDC_TITLE),hfont,TRUE);

			BUTTON_IMAGELIST bi = { 0 };

			bi.himl = ImageList_Create(32,32,ILC_COLOR16|ILC_MASK,4,0);
			bi.uAlign = 4;

			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 32, 32, LR_CREATEDIBSECTION);

			hIcon0 = Icon_CopyAsBlend50(hIcon);
			hIcon1 = Icon_CopyAsGreyScale(hIcon0);

			ImageList_AddIcon(bi.himl,hIcon0);	// Normal
			ImageList_AddIcon(bi.himl,hIcon);	// hot
			ImageList_AddIcon(bi.himl,hIcon0);	// pushed
			ImageList_AddIcon(bi.himl,hIcon1);	// disabled
			ImageList_AddIcon(bi.himl,hIcon0);	// focused

			DestroyIcon(hIcon);
			DestroyIcon(hIcon0);
			DestroyIcon(hIcon1);

			SendDlgItemMessage(hdlg, IDCANCEL,BCM_SETIMAGELIST,0,(LPARAM)&bi);
		}
		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDCANCEL:
					EndDialog(hdlg, LOWORD(wParam));
				break;
				case IDC_DISABLE:
					EnableWindow(GetDlgItem(hdlg, IDCANCEL), IsDlgButtonChecked(hdlg, IDC_DISABLE) == BST_UNCHECKED);
				break;
			}
		break;

		case WM_CTLCOLORSTATIC:
			switch(GetDlgCtrlID((HWND)lParam))
			{
				case IDC_LOGO:
				case IDC_TITLE:
					SetBkMode((HDC)wParam,TRANSPARENT);
					SetTextColor((HDC)wParam, RGB(0,0,255));
				return (LRESULT) GetStockObject(WHITE_BRUSH);
				case IDC_PRIM:
					SetBkMode((HDC)wParam,TRANSPARENT);
					SetTextColor((HDC)wParam, RGB(128,128,128));
				return (LRESULT) GetStockObject(WHITE_BRUSH);
			}
		break;
	}

	return FALSE;
}
