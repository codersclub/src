#define STRICT				//����������� ������� �������� �����
#include <windows.h>		//���� ����������� ������� windows
#include <windowsx.h>		//���� ���������������� windows
#include <commctrl.h>		//������� ������ �� ������������ ������ windows
#pragma comment(lib, "comctl32.lib")

#include "ImageListEx.h"
#include "resource.h"		//���� ����������� �������� ��������



BOOL WINAPI MainDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam);


int WINAPI WinMain(HINSTANCE hInst,HINSTANCE hPrevInstance,LPSTR lpszCmdParam, int nCmdShow)
{
	InitCommonControls();
	return DialogBox(hInst, TEXT("MAIN"), HWND_DESKTOP, MainDlgProc);
}




BOOL WINAPI MainDlgProc(HWND hdlg, UINT msg, WPARAM wParam, LPARAM lParam)
{
	switch(msg)
	{
		case WM_INITDIALOG:
		{
			HWND hwnd;
			HICON hIcon;
			HIMAGELIST himl;

			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 32, 32, LR_CREATEDIBSECTION);
			SendMessage(hdlg, WM_SETICON, ICON_BIG, (LPARAM)hIcon);
			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 16, 16, LR_CREATEDIBSECTION);
			SendMessage(hdlg, WM_SETICON, ICON_SMALL, (LPARAM)hIcon);
			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 48, 48, LR_CREATEDIBSECTION);
			SendDlgItemMessage(hdlg, IDC_LOGO, STM_SETIMAGE, IMAGE_ICON, (LPARAM)hIcon);
			HFONT hfont = CreateFont(-24,0,0,0,700,1,0,0,RUSSIAN_CHARSET,0,0,0,0,"Times New Roman Cyr");
			SetWindowFont(GetDlgItem(hdlg,IDC_TITLE),hfont,TRUE);

			hwnd = GetDlgItem(hdlg, IDC_TOOLBAR);
			himl = ImageList_Create(32,32,ILC_COLOR16|ILC_MASK,1,0);
			hIcon = (HICON)LoadImage((HINSTANCE)GetModuleHandle(NULL), "AAPP", IMAGE_ICON, 32, 32, LR_CREATEDIBSECTION);
			ImageList_AddIcon(himl,hIcon);
			DestroyIcon(hIcon);

			SendMessage(hwnd, TB_SETEXTENDEDSTYLE,0,TBSTYLE_EX_DRAWDDARROWS);
			SendMessage(hwnd, TB_BUTTONSTRUCTSIZE,(WPARAM) sizeof(TBBUTTON),0);
			SendMessage(hwnd, TB_SETHOTIMAGELIST, 0, (LPARAM)himl);
			SendMessage(hwnd, TB_SETIMAGELIST, 0, (LPARAM)ImageList_CopyAsBlend50(himl));
			SendMessage(hwnd, TB_SETDISABLEDIMAGELIST, 0, (LPARAM)ImageList_CopyAsDisabled(himl));
			SendMessage(hwnd,TB_SETBITMAPSIZE, 0,(LPARAM)MAKELONG(32,32));
			SendMessage(hwnd,TB_AUTOSIZE ,(WPARAM)0,(LPARAM)0);

			unsigned i = 0;
			TBBUTTON tbb[2]; memset(&tbb,0,sizeof(tbb));
			tbb[i].iBitmap = 0;
			tbb[i].idCommand = IDCANCEL+i;
			tbb[i].fsState = TBSTATE_ENABLED;
			tbb[i].fsStyle = TBSTYLE_BUTTON;
			tbb[i++].iString = SendMessage(hwnd, TB_ADDSTRING, 0, (LPARAM)"��������\0");
			tbb[i].iBitmap = 0;
			tbb[i].idCommand = IDCANCEL+i;
			tbb[i].fsState = 0;
			tbb[i].fsStyle = TBSTYLE_BUTTON;
			tbb[i++].iString = SendMessage(hwnd, TB_ADDSTRING, 0, (LPARAM)"����������\0");

			SendMessage(hwnd,TB_ADDBUTTONS,(WPARAM)i,(LPARAM) (LPTBBUTTON) &tbb);
			SendMessage(hwnd,TB_SETBUTTONSIZE,0,(LPARAM) LOWORD(SendMessage(hwnd,TB_GETBUTTONSIZE,0,0)));
		}
		return TRUE;

		case WM_COMMAND:
			switch(LOWORD(wParam))
			{
				case IDCANCEL:
					EndDialog(hdlg, LOWORD(wParam));
				break;
				case IDC_DISABLE:
					EnableWindow(GetDlgItem(hdlg, IDCANCEL), IsDlgButtonChecked(hdlg, IDC_DISABLE) == BST_UNCHECKED);
				break;
			}
		break;

		case WM_CTLCOLORSTATIC:
			switch(GetDlgCtrlID((HWND)lParam))
			{
				case IDC_LOGO:
				case IDC_TITLE:
					SetBkMode((HDC)wParam,TRANSPARENT);
					SetTextColor((HDC)wParam, RGB(0,0,255));
				return (LRESULT) GetStockObject(WHITE_BRUSH);
				case IDC_PRIM:
					SetBkMode((HDC)wParam,TRANSPARENT);
					SetTextColor((HDC)wParam, RGB(128,128,128));
				return (LRESULT) GetStockObject(WHITE_BRUSH);
			}
		break;
	}

	return FALSE;
}
