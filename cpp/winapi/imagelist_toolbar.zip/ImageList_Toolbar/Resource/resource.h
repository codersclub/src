//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDC_SKIP                        3
#define ID_L_T                          103
#define IDI_ICON1                       105
#define IDC_AUTOSTART                   1000
#define IDC_EDIT                        1001
#define IDC_LOGO                        1002
#define IDC_TITLE                       1003
#define IDC_PRIM                        1004
#define IDC_TREY                        1006
#define IDC_DISABLE                     1006
#define IDC_AUTOTRACK                   1007
#define IDC_CHECK4                      1008
#define IDC_NOPATH                      1008
#define IDC_STATUS                      1009
#define IDC_NOCAPTION                   1009
#define IDC_TOOLBAR                     1010
#define IDC_HIDDEN                      1010
#define IDC_TREE                        1011
#define IDC_LIST                        1012
#define IDC_HORTRACK                    1013
#define IDC_VERTTRACK                   1014
#define IDC_STICON                      1164
#define IDC_RICHSTATIC                  1165

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
