// Functions.cpp
//
// Various global functions

#include "stdafx.h"
#include "Definitions.h"




LPCTSTR lpszMutexName = TEXT("MagnifyAppMutex");
LPCTSTR lpszMsgBoxHeader = TEXT("Magnifying Glass");


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Program initialization.
//
//       Return value: TRUE - succeded
//                     FALSE - failed
//       
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL InitInstance()
{
    // check if this instance is first
    if ( ! FirstInstance() )
    {
        MessageBox(NULL, TEXT("Magnifying Glass is already active"), lpszMsgBoxHeader,
                   MB_OK | MB_ICONEXCLAMATION);

        return FALSE;
    }

    // load cursors
    g_Handles.hMagnifyCursor = LoadCursor(g_Handles.hInstance, MAKEINTRESOURCE(IDC_CURSOR_MAGNIFY));
    g_Handles.hNullCursor = LoadCursor(NULL, NULL);


    // create unvisible window to process tray messages
    if ( ! MWnd_CreateMainWindow() )
    {
        MessageBox(NULL, TEXT("Creating main window failed"), lpszMsgBoxHeader,
                   MB_OK | MB_ICONEXCLAMATION);

        return FALSE;
    }

    // register class for mouse capture window
    if (  ! MCW_RegisterClass() )
    {
        MessageBox(NULL, TEXT("Regisrer capture window class"), lpszMsgBoxHeader,
                   MB_OK | MB_ICONEXCLAMATION);
    
        return FALSE;
    }

    // Create the tray icon
	if ( ! g_Variables.SystemTray.Create(
        g_Handles.hInstance,
        g_Handles.hMainWnd,
        WM_ICON_NOTIFY,
        TEXT("Magnifying Glass"),
        LoadIcon(g_Handles.hInstance, (LPCTSTR)IDI_ICON_MAGNIFY),
        IDR_MENU_CONTEXT)) 
    {
        MessageBox(NULL, TEXT("Tray icon initialization failed"), lpszMsgBoxHeader,
                   MB_OK | MB_ICONEXCLAMATION);

        return FALSE;
    }

    g_Variables.SystemTray.SetMenuDefaultItem(IDR_MENU_START, FALSE);

    // load options from Registry
    DlgOptions_LoadOptions();


    return TRUE;
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Return TRUE if current instance is first
//       
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL FirstInstance()
{
    g_Handles.hMutex = CreateMutex(NULL,
        FALSE,
        lpszMutexName);
    
    if ( GetLastError() == ERROR_ALREADY_EXISTS )
    {
        // Function returns a handle to the existing object,
        // that means, other application instance already running.

        return FALSE;
    }
    else
    {
        return TRUE;
    }
}

//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Program clean-up operations
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void ExitInstance()
{
    MG_DestroyScreenshot();

    if ( g_Handles.hMutex )
    {
        CloseHandle(g_Handles.hMutex);
        g_Handles.hMutex = NULL;
    }

    if ( g_Handles.hRegistryKey )
    {
        RegCloseKey(g_Handles.hRegistryKey);
        g_Handles.hRegistryKey = NULL;
    }

    if ( g_Handles.hAboutDlg )
    {
        DestroyWindow(g_Handles.hAboutDlg);
        g_Handles.hAboutDlg = NULL;
    }

    if ( g_Handles.hOptionsDlg )
    {
        DestroyWindow(g_Handles.hOptionsDlg);
        g_Handles.hOptionsDlg = NULL;
    }

    MCW_DestroyWindow();

    if ( g_Handles.hMainWnd )
    {
        DestroyWindow(g_Handles.hMainWnd);
        g_Handles.hMainWnd = NULL;
    }


}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Get error message from error code. Error code is returned
//      by GetLastError.
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void GetErrorMessage(DWORD dwErrorCode,         // [in] error code
                     TCHAR* sBuffer,            // [in, out] buffer for message
                     int nLen)                  // [in] buffer length
{
    void* pMsgBuf = NULL;

    FormatMessage(
        FORMAT_MESSAGE_ALLOCATE_BUFFER | FORMAT_MESSAGE_FROM_SYSTEM,
        NULL,
        dwErrorCode,
        MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
        (LPTSTR) &pMsgBuf,
        0,
        NULL);

    
    if ( pMsgBuf )
    {
        lstrcpyn(sBuffer, (TCHAR*) pMsgBuf, nLen);
        LocalFree(pMsgBuf);
    }
    else
    {
        lstrcpyn(sBuffer, TEXT("Unexpected error"), nLen);
    }

}
