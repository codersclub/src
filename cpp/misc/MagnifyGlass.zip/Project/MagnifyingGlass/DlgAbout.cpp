// DlgAbout.cpp
//
// About dialog functions

#include "stdafx.h"
#include "Definitions.h"




//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       About dialog procedure
//       
//$E///////////////////////////////////////////////////////////////////////////////////
INT_PTR WINAPI DlgAbout_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
    switch (uMsg) 
    {
        chHANDLE_DLGMSG(hwnd, WM_INITDIALOG, DlgAbout_OnInitDialog);
        chHANDLE_DLGMSG(hwnd, WM_DESTROY, DlgAbout_OnDestroy);
        chHANDLE_DLGMSG(hwnd, WM_COMMAND, DlgAbout_OnCommand);
    }
    
    return(FALSE);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       About dialog initialization
//       
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL DlgAbout_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam) 
{
    g_Handles.hAboutDlg = hwnd;

    return FALSE;
}

//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       About dialog clean-up operations
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgAbout_OnDestroy(HWND hwnd)
{
    g_Handles.hAboutDlg = NULL;
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       About dialog commands handler
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgAbout_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify) 
{
    switch (id) 
    {
    case IDOK:
    case IDCANCEL:
        EndDialog(hwnd, id); 
        break;
    }
}

