// DlgOptions.cpp
//
// Options dialog functions

#include "stdafx.h"
#include <stdio.h>
#include "Definitions.h"

// string constants for Registry operations
LPCTSTR lpszRegistryPath = TEXT("SOFTWARE\\Farber_Alex\\MagnifyingGlass");
LPCTSTR lpszEntrySize = TEXT("Size");
LPCTSTR lpszEntryCoefficient = TEXT("Coefficient");
LPCTSTR lpszEntryRound = TEXT("Round");
LPCTSTR lpszEntryBorder = TEXT("Border");
LPCTSTR lpszEntryFastMagnification = TEXT("Fast");





//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Options dialog box procedure
//       
//$E///////////////////////////////////////////////////////////////////////////////////
INT_PTR WINAPI DlgOptions_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam) 
{
    switch (uMsg) 
    {
        chHANDLE_DLGMSG(hwnd, WM_INITDIALOG, DlgOptions_OnInitDialog); // HANDLE_WM_INITDIALOG
        chHANDLE_DLGMSG(hwnd, WM_DESTROY, DlgOptions_OnDestroy);       // HANDLE_WM_DESTROY
        chHANDLE_DLGMSG(hwnd, WM_COMMAND,    DlgOptions_OnCommand);    // HANDLE_WM_COMMAND
    }
    
    return(FALSE);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Dialog initialization
//       
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL DlgOptions_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam) 
{
    g_Handles.hOptionsDlg = hwnd;

    // initialize and fill dialog controls
    DlgOptions_InitControls();
    DlgOptions_FillControls();

    return FALSE;
}

//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Dialog clean-up operations
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_OnDestroy(HWND hwnd)
{
    g_Handles.hOptionsDlg = NULL;
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Dialog commands handler
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify) 
{
    switch (id) 
    {
    case IDOK:
        // read options from dialog and save them in Registry
        DlgOptions_ReadOptions();
        DlgOptions_SaveOptions();

        EndDialog(hwnd, id); 
        break;

    case IDC_BUTTON_APPLY:
        // read options from dialog and save them in Registry
        DlgOptions_ReadOptions();
        DlgOptions_SaveOptions();

        break;

    case IDCANCEL:
        EndDialog(hwnd, id); 
        break;
    }
}

//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Initialize dialog controls
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_InitControls()
{
    int i;
    TCHAR s[10];
    HWND hCtrl;

    // size
    hCtrl = GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_SIZE);

    for ( i = 1; i <= 5; i++ )
    {
        _stprintf(s, TEXT("%d"), i*100);
        SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPCTSTR) s);
    }

    // coefficient
    hCtrl = GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_COEFFICIENT);

    for ( i = 2; i <= 5; i++ )
    {
        _stprintf(s, TEXT("%d"), i);
        SendMessage(hCtrl, CB_ADDSTRING, 0, (LPARAM)(LPCTSTR) s);
    }

    // fast magnification
    hCtrl = GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_FAST_MAGNIFICATION);

    SendMessage(hCtrl, CB_ADDSTRING, 0, 
                (LPARAM)(LPCTSTR) TEXT("Fast magnification"));

    SendMessage(hCtrl, CB_ADDSTRING, 0, 
                (LPARAM)(LPCTSTR) TEXT("High-quality slow magnification"));
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Load options from Registry
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_LoadOptions()
{
    DWORD dwDisposition;
    DWORD dwValue;
    DWORD dwSize = sizeof(DWORD);

    // set start values
    g_Variables.options.nMagnifyGlassSize = 100;
    g_Variables.options.nCoefficient = 2;
    g_Variables.options.bBorder = FALSE;
    g_Variables.options.bRound = FALSE;
    g_Variables.options.bFastMagnification = TRUE;


    RegCreateKeyEx(
        HKEY_LOCAL_MACHINE,
        lpszRegistryPath,
        0,
        _T(""),
        REG_OPTION_NON_VOLATILE,
        KEY_ALL_ACCESS,
        NULL,
        &g_Handles.hRegistryKey,
        &dwDisposition);

    if ( ! g_Handles.hRegistryKey )
    {
        TRACE(TEXT("RegCreateKeyEx failed\n"));
        return;
    }

    // size
    if ( DlgOptions_ReadDWORDValueFromRegistry(
        g_Handles.hRegistryKey,
        lpszEntrySize,
        &dwValue) )
    {
        g_Variables.options.nMagnifyGlassSize = dwValue;
    }

    // coefficient
    if ( DlgOptions_ReadDWORDValueFromRegistry(
        g_Handles.hRegistryKey,
        lpszEntryCoefficient,
        &dwValue) )
    {
        g_Variables.options.nCoefficient = dwValue;
    }


    // round shape flag
    if ( DlgOptions_ReadDWORDValueFromRegistry(
        g_Handles.hRegistryKey,
        lpszEntryRound,
        &dwValue) )
    {
        g_Variables.options.bRound = (dwValue != 0);
    }


    // border flag
    if ( DlgOptions_ReadDWORDValueFromRegistry(
        g_Handles.hRegistryKey,
        lpszEntryBorder,
        &dwValue) )
    {
        g_Variables.options.bBorder = (dwValue != 0);
    }

    // fast magnification flag
    if ( DlgOptions_ReadDWORDValueFromRegistry(
        g_Handles.hRegistryKey,
        lpszEntryFastMagnification,
        &dwValue) )
    {
        g_Variables.options.bFastMagnification = (dwValue != 0);
    }

}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Save options to Registry
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_SaveOptions()
{
    if ( ! g_Handles.hRegistryKey )
        return;

    // size
    DlgOptions_WriteDWORDValueToRegistry(
        g_Handles.hRegistryKey,
        lpszEntrySize,
        g_Variables.options.nMagnifyGlassSize);

    // coefficient
    DlgOptions_WriteDWORDValueToRegistry(
        g_Handles.hRegistryKey,
        lpszEntryCoefficient,
        g_Variables.options.nCoefficient);

    // round shape flag
    DlgOptions_WriteDWORDValueToRegistry(
        g_Handles.hRegistryKey,
        lpszEntryRound,
        g_Variables.options.bRound);

    // border flag
    DlgOptions_WriteDWORDValueToRegistry(
        g_Handles.hRegistryKey,
        lpszEntryBorder,
        g_Variables.options.bBorder);

    // fast magnification flag
    DlgOptions_WriteDWORDValueToRegistry(
        g_Handles.hRegistryKey,
        lpszEntryFastMagnification,
        g_Variables.options.bFastMagnification);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Fill dialog controls from options
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_FillControls()
{
    int n;

    // size combo box
    n = g_Variables.options.nMagnifyGlassSize / 100 - 1;
    ENSURE_RANGE(n, 0, 4);

    SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_SIZE),
        CB_SETCURSEL,
        n,
        0);

    // coefficient combo box
    n = g_Variables.options.nCoefficient - 2;
    ENSURE_RANGE(n, 0, 3);

    SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_COEFFICIENT),
        CB_SETCURSEL,
        n,
        0);

    // round shape check box
    SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_CHECK_ROUND),
        BM_SETCHECK,
        g_Variables.options.bRound ? BST_CHECKED : BST_UNCHECKED,
        0);

    // border check box
    SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_CHECK_BORDER),
        BM_SETCHECK,
        g_Variables.options.bBorder ? BST_CHECKED : BST_UNCHECKED,
        0);

    // fast magnification combo box
    SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_FAST_MAGNIFICATION),
        CB_SETCURSEL,
        g_Variables.options.bFastMagnification ? 0 : 1,
        0);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Read options from dialog
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_ReadOptions()
{
    int n;

    // size combo box
    n = SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_SIZE),
        CB_GETCURSEL,
        0,
        0);
    ENSURE_RANGE(n, 0, 4);

    g_Variables.options.nMagnifyGlassSize = (n + 1) * 100;

    // coefficient combo box
    n = SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_COEFFICIENT),
        CB_GETCURSEL,
        0,
        0);
    ENSURE_RANGE(n, 0, 3);

    g_Variables.options.nCoefficient = n + 2;

    // round shape check box
    n = SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_CHECK_ROUND),
        BM_GETCHECK,
        0,
        0);

    g_Variables.options.bRound = (n == BST_CHECKED);

    // border check box
    n = SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_CHECK_BORDER),
        BM_GETCHECK,
        0,
        0);

    g_Variables.options.bBorder = (n == BST_CHECKED);

    // fast magnification combo box
    n = SendMessage(
        GetDlgItem(g_Handles.hOptionsDlg, IDC_COMBO_FAST_MAGNIFICATION),
        CB_GETCURSEL,
        0,
        0);

    g_Variables.options.bFastMagnification = (n==0);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Read value of type DWORD from Registry.
//
//       Return value: TRUE - OK
//                     FALSE - value not found
//       
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL DlgOptions_ReadDWORDValueFromRegistry(
                HKEY hKey,              // [in] Registry key
                LPCTSTR sEntry,         // [in] Registry entry
                DWORD* pdwResult)       // [out] result
{
    LONG nResult;
    DWORD type;
    DWORD dwSize = sizeof(DWORD);
    DWORD dwValue[1];

    nResult = RegQueryValueEx(
        hKey,
        sEntry,
        NULL,
        &type,
        (LPBYTE) dwValue,
        &dwSize);

    if ( nResult == ERROR_SUCCESS )
    {
        if ( type == REG_DWORD )
        {
            *pdwResult = dwValue[0];
            return TRUE;
        }
    }

    return FALSE;

}

//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Write value of type DWORD to Registry
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void DlgOptions_WriteDWORDValueToRegistry(
                HKEY hKey,              // [in] Registry key
                LPCTSTR sEntry,         // [in] Registry entry
                DWORD dwValue)          // [in] value
{
    RegSetValueEx(
        hKey,
        sEntry,
        0,
        REG_DWORD,
        (CONST BYTE*) &dwValue,
        sizeof(DWORD));
}

