// CaptureWnd.cpp
//
// Mouse capture window functions

#include "stdafx.h"
#include "definitions.h"



LPCTSTR lpszCaptureClassName = TEXT("MouseCaptureWndClass");



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Register class for mouse capture window
//      
//       Return value: TRUE - OK, 
//                     FALSE - faied.
//
//       This function is called once when program starts.
//
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL MCW_RegisterClass()
{
    WNDCLASS wndclass;
    
    wndclass.style = 0;
    wndclass.lpfnWndProc = (WNDPROC)MCW_WndProc;
    wndclass.cbClsExtra = 0;
    wndclass.cbWndExtra = 0;
    wndclass.hInstance = g_Handles.hInstance;
    wndclass.hIcon = NULL;
    
    wndclass.hCursor = NULL;

   
    wndclass.hbrBackground = NULL;
    
    wndclass.lpszMenuName = NULL;
    wndclass.lpszClassName = lpszCaptureClassName;
    
    if ( ! RegisterClass(&wndclass) )
        return FALSE;
    
    return TRUE;
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Create borderless unvisible window used for capturing mouse input
//       for the whole screen.
//
//       Return value: TRUE - OK, 
//                     FALSE - faied
//       
//       Source: CamStudio
//
//       NOTE: capture window is created as child of main window,
//             this prevents showing icon on Windows taskbar.
//             Source: Chris Mounder, "Creating application with no
//             taskbar icon", http://www.codeproject.com,
//             Doc/View - General.
//
//       Function is called every time magnification tool is activated.
//       When tool is deactivated I destroy this window.
//       I don't keep this window all the time because it causes some problems
//       with system tray tooltips.
//
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL MCW_CreateWindow() 
{
    TCHAR sError[1000];

    g_Handles.hCaptureWnd = CreateWindowEx(
        WS_EX_TOPMOST | WS_EX_TRANSPARENT,
        lpszCaptureClassName, 
        NULL,
        WS_POPUP,
        0,
        0,
        g_Variables.nScreenX,
        g_Variables.nScreenY,
        g_Handles.hMainWnd,
        NULL, 
        g_Handles.hInstance,  
        NULL);
 
    DWORD dwError = GetLastError();

    if ( ! g_Handles.hCaptureWnd )
    {
        GetErrorMessage(dwError, sError, 1000);
        TRACE(TEXT("Create capture window failed. Error message:\n"));
        TRACE(sError);
        TRACE(TEXT("\n"));
    }

    HDC hScreenDC=::GetDC(NULL);
    g_Variables.nScreenX = GetDeviceCaps(hScreenDC,HORZRES);
    g_Variables.nScreenY = GetDeviceCaps(hScreenDC,VERTRES);
    ::ReleaseDC(NULL,hScreenDC);		
    
    return (g_Handles.hCaptureWnd != NULL);
    
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Destroy mouse capture window.
//      Called when magnification tool is deactivated.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_DestroyWindow()
{
    if ( g_Handles.hCaptureWnd )
    {
        DestroyWindow(g_Handles.hCaptureWnd);
        g_Handles.hCaptureWnd = NULL;
    }
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Window function for mouse capture window
//       
//$E///////////////////////////////////////////////////////////////////////////////////
long WINAPI MCW_WndProc(HWND hWnd, UINT wMessage, WPARAM wParam, LPARAM lParam)
{
    switch ( wMessage ) 
    {
      HANDLE_MSG(hWnd, WM_LBUTTONDOWN, MCW_OnLButtonDown);   // HANDLE_WM_LBUTTONDOWN
      HANDLE_MSG(hWnd, WM_RBUTTONUP, MCW_OnRButtonUp);       // HANDLE_WM_RBUTTONUP
      HANDLE_MSG(hWnd, WM_LBUTTONUP,   MCW_OnLButtonUp);     // HANDLE_WM_LBUTTONUP
      HANDLE_MSG(hWnd, WM_SETCURSOR, MCW_OnSetCursor);       // HANDLE_WM_SETCURSOR
      HANDLE_MSG(hWnd, WM_KEYDOWN, MCW_OnKeyDown);           // HANDLE_WM_KEYDOWN
      HANDLE_MSG(hWnd, WM_MOUSEMOVE, MCW_OnMouseMove);       // HANDLE_WM_MOUSEMOVE

      default:
         return(DefWindowProc(hWnd, wMessage, wParam, lParam));
    }
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_RBUTTONUP message handler for mouse capture window.
//      Deactivate magnification tool.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_OnRButtonUp(HWND hwnd, int x, int y, UINT flags)
{
    MG_DecativateMagnificationTool();

    FORWARD_WM_RBUTTONUP(hwnd, x, y, flags, DefWindowProc);
}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_KEYDOWN message handler for mouse capture window.
//      Deactivate magnification tool if Esc is pressed.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_OnKeyDown(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags)
{
    if ( vk == VK_ESCAPE )
        MG_DecativateMagnificationTool();

    FORWARD_WM_KEYDOWN(hwnd, vk, cRepeat, flags, DefWindowProc);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_LBUTTONDOWN message handler for mouse capture window.
//      Show magnifying glass first time.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags)
{
    MCW_SetTransparentStyle(FALSE);

    g_Variables.bMouseButtonPressed = TRUE;

    HDC hDC = GetDC(hwnd);
    MG_MakeScreenshot(hDC);
    ReleaseDC(hwnd, hDC);

    MG_MakeMagnification(x, y, TRUE);

    FORWARD_WM_LBUTTONDOWN(hwnd, fDoubleClick, x, y, keyFlags, DefWindowProc);
}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_LBUTTONUP message handler for mouse capture window.
//      Stop showing magnifying glass.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_OnLButtonUp(HWND hwnd, int x, int y, UINT keyFlags)
{
    MCW_SetTransparentStyle(TRUE);

    g_Variables.bMouseButtonPressed = FALSE;

    HDC hDC = GetDC(hwnd);
    MG_RestorePreviousRegion(hDC);
    ReleaseDC(hwnd, hDC);

    MG_DestroyScreenshot();

    FORWARD_WM_LBUTTONUP(hwnd, x, y, keyFlags, DefWindowProc);
}




//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_SETCURSOR message handler for mouse capture window
//      
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL MCW_OnSetCursor(HWND hwnd, HWND hwndCursor, UINT codeHitTest, UINT msg)
{
    SetCursor(g_Variables.bMouseButtonPressed ? 
                       g_Handles.hNullCursor : g_Handles.hMagnifyCursor);

    return FORWARD_WM_SETCURSOR(hwnd, hwndCursor, codeHitTest, msg, DefWindowProc);
}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      WM_MOUSEMOVE message handler for mouse capture window.
//      Show magnify glass in current mouse position if left button is pressed.
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_OnMouseMove(HWND hwnd, int x, int y, UINT keyFlags)
{
    if ( g_Variables.bMouseButtonPressed )
    {
        MG_MakeMagnification(x, y, FALSE);
    }


    FORWARD_WM_MOUSEMOVE(hwnd, x, y, keyFlags, DefWindowProc);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Set/remove WS_EX_TRANSPARENT style for caprure window.
//
//       When window has transparent style, we can see all changes
//       on the screen. But magnification is not correct because
//       changes on the screen override magnify glass.
//       So, I keep window transparent all time except magnifying
//       glass is shown (between pressing and releasing of left mouse
//       button).
//
//       All time magnifiying glass is visible screen is not updated.
//       For example, if there is running animation, it freezes.
//       This is maximum I can do for now.
//       
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void MCW_SetTransparentStyle(BOOL bSet)
{
    DWORD dwExStyle = GetWindowLong(g_Handles.hCaptureWnd, GWL_EXSTYLE);

    if ( bSet )
        dwExStyle |= WS_EX_TRANSPARENT;
    else
        dwExStyle &= (! WS_EX_TRANSPARENT);

    SetWindowLong(g_Handles.hCaptureWnd, GWL_EXSTYLE, dwExStyle);

    SetWindowPos(
        g_Handles.hCaptureWnd,
        NULL,  
        0,     
        0,     
        0,     
        0,     
        SWP_NOMOVE | SWP_NOSIZE | SWP_NOZORDER | SWP_FRAMECHANGED);
}


