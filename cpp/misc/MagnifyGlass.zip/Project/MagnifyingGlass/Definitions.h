// Definitions.h
//
// Definitions:
//
// macros;
// structures;
// forward function declarations;
// variables

#pragma once

#include <Windowsx.h>
#include "resource.h"
#include "SystemTraySDK.h"



// ***************************************************************************
// macros

#ifdef _DEBUG
    #define TRACE(x) OutputDebugString(x)
#else
    #define TRACE(x)
#endif


// Source: Jeffrey Richter, "Programming Applications for Microsoft Windows",
//         CmnHdr.h
//
// The normal HANDLE_MSG macro in WindowsX.h does not work properly for dialog
// boxes because DlgProc return a BOOL instead of an LRESULT (like
// WndProcs). This chHANDLE_DLGMSG macro corrects the problem:
#define chHANDLE_DLGMSG(hwnd, message, fn)                 \
   case (message): return (SetDlgMsgResult(hwnd, uMsg,     \
      HANDLE_##message((hwnd), (wParam), (lParam), (fn))))



#define ENSURE_RANGE(x, n1, n2)             \
        if ( (x) < (n1) )                   \
            (x) = (n1);                     \
        if ( (x) > (n2) )                   \
            (x) = (n2);

// user defined message for tray notifications
#define WM_ICON_NOTIFY WM_APP + 1

// ***************************************************************************
// structures

struct GLOBAL_HANDLES
{
    HINSTANCE hInstance;        // instance handler
    HANDLE hMutex;              // mutex used to run one instance of this program
    HKEY hRegistryKey;          // registry key to keep program settings

    HWND hMainWnd;              // unvisible main window
    HWND hCaptureWnd;           // window used to capture mouse messages
    HWND hAboutDlg;             // About dialog
    HWND hOptionsDlg;           // Options dialog

    HCURSOR hMagnifyCursor;     // magnify glass cursor 
    HCURSOR hNullCursor;        // null cursor

    HBITMAP hScreenshotBitmap;  // screenshot bitmap
    HDC hScreenshotDC;          // screen shot device context
};


struct GLOBAL_VARIABLES
{
    BOOL bMouseButtonPressed;   // used in mouse capture window

    int nScreenX;               // horizontal screen size (pixels)
    int nScreenY;               // vertical screen size (pixels)

    RECT rcCurrent;             // current magnification rectangle
    RECT rcPrevious;            // previous magnification rectangle

    int nMagnifyX;              // center of magnify glass (x)
    int nMagnifyY;              // center of magnify glass (y)

    struct OPTIONS              // magnifying options kept in Registry
    {
        int nMagnifyGlassSize;
        int nCoefficient;
        BOOL bRound;
        BOOL bBorder;
        BOOL bFastMagnification;
    } options;

    CSystemTray SystemTray;     // object handles system tray icon
};

// ***************************************************************************
// forward function declarations

// general
BOOL InitInstance();
BOOL FirstInstance();
void ExitInstance();
void GetErrorMessage(DWORD dwErrorCode, TCHAR* sBuffer, int nLen);


// main window functions
BOOL MWnd_CreateMainWindow();
long WINAPI MWnd_WndProc(HWND hWnd, UINT wMessage, WPARAM wParam, LPARAM lParam);
void MWnd_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);


// capture window functions
BOOL MCW_RegisterClass();
BOOL MCW_CreateWindow();
void MCW_DestroyWindow();
long WINAPI MCW_WndProc(HWND hWnd, UINT wMessage, WPARAM wParam, LPARAM lParam);
void MCW_OnLButtonDown(HWND hwnd, BOOL fDoubleClick, int x, int y, UINT keyFlags);
void MCW_OnRButtonUp(HWND hwnd, int x, int y, UINT flags);
void MCW_OnLButtonUp(HWND hwnd, int x, int y, UINT keyFlags);
BOOL MCW_OnSetCursor(HWND hwnd, HWND hwndCursor, UINT codeHitTest, UINT msg);
void MCW_OnKeyDown(HWND hwnd, UINT vk, BOOL fDown, int cRepeat, UINT flags);
void MCW_OnMouseMove(HWND hwnd, int x, int y, UINT keyFlags);
void MCW_SetTransparentStyle(BOOL bSet);


// magnification functions
void MG_ActivateMagnificationTool();
void MG_DecativateMagnificationTool();
void MG_MakeMagnification(int x, int y, BOOL bFirstDraw);
void MG_RestorePreviousRegion(HDC hDC);
void MG_DrawCurrentRegion(HDC hDC);
void MG_DrawBorder(HDC hDC);
void MG_DestroyScreenshot();
void MG_MakeScreenshot(HDC hDC);


// About dialog functions
INT_PTR WINAPI DlgAbout_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL DlgAbout_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam); 
void DlgAbout_OnDestroy(HWND hwnd);
void DlgAbout_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify); 


// Options dialog functions
INT_PTR WINAPI DlgOptions_DlgProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);
BOOL DlgOptions_OnInitDialog(HWND hwnd, HWND hwndFocus, LPARAM lParam);
void DlgOptions_OnDestroy(HWND hwnd);
void DlgOptions_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify);
void DlgOptions_InitControls();
void DlgOptions_LoadOptions();
void DlgOptions_SaveOptions();
void DlgOptions_FillControls();
void DlgOptions_ReadOptions();
BOOL DlgOptions_ReadDWORDValueFromRegistry(HKEY hKey, LPCTSTR sEntry, DWORD* pdwResult);
void DlgOptions_WriteDWORDValueToRegistry(HKEY hKey, LPCTSTR sEntry, DWORD dwValue);


// ***************************************************************************
// variables
extern GLOBAL_HANDLES g_Handles;
extern GLOBAL_VARIABLES g_Variables;
