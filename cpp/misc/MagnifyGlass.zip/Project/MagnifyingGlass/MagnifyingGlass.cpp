// MagnifyingGlass.cpp : Defines the entry point for the application.
//

/******************************************************************************************

Magnifying Glass
Written by Alex Farber
alexm@cmt.co.il         2001

Acknowledgements:

1. CamStudio project. Using unvisible window to capture 
   mouse events on the whole screen.

   http://www.atomixbuttons.com/vsc

2. Chris Mounder. Adding Icons to the System Tray.

   http://www.codeproject.com/shell/systemtray.asp

3. Chris Mounder. Creating an application with no taskbar icon.

   http://www.codeproject.com/docview/notaskbaricon.asp

4. Jeffrey Richter. Using message crackers from WindowsX.h.

   Programming Applications for Microsoft Windows. 
   Microsoft Press 1999.

*******************************************************************************************/



#include "stdafx.h"
#include "definitions.h"

GLOBAL_HANDLES g_Handles;
GLOBAL_VARIABLES g_Variables;



int APIENTRY WinMain(HINSTANCE hInstance,
                     HINSTANCE hPrevInstance,
                     LPSTR     lpCmdLine,
                     int       nCmdShow)
{
    memset(&g_Handles, 0, sizeof(GLOBAL_HANDLES));
    memset(&g_Variables, 0, sizeof(GLOBAL_VARIABLES));


    g_Handles.hInstance = hInstance;

    if ( ! InitInstance() )
        return 1;

	MSG msg;
	while ( GetMessage(&msg, NULL, 0, 0) ) 
	{
		TranslateMessage(&msg);
		DispatchMessage(&msg);
	}

    ExitInstance();

	return msg.wParam;
}




