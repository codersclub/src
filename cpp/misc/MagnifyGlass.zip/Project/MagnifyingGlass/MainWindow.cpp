// MainWindow.cpp
//
// Various global functions

#include "stdafx.h"
#include "Definitions.h"


LPCTSTR lpszMainWindowClassName = TEXT("MagnifyGlassMainWndClass");



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Create main application window
//
//      Return value: TRUE - OK, FALSE - failed
//      
//$E///////////////////////////////////////////////////////////////////////////////////
BOOL MWnd_CreateMainWindow()
{
    TCHAR sError[1000];

    WNDCLASS wndclass;
    
    wndclass.style = 0;
    wndclass.lpfnWndProc = (WNDPROC)MWnd_WndProc;
    wndclass.cbClsExtra = 0;
    wndclass.cbWndExtra = 0;
    wndclass.hInstance = g_Handles.hInstance;
    wndclass.hIcon = NULL;
    wndclass.hCursor = NULL;
    wndclass.hbrBackground = NULL;
    
    wndclass.lpszMenuName = NULL;
    wndclass.lpszClassName = lpszMainWindowClassName;
    
    if (!RegisterClass(&wndclass))
        return FALSE;
    
    g_Handles.hMainWnd = CreateWindowEx(
        0,
        lpszMainWindowClassName, 
        NULL,
        WS_POPUP,
        0,
        0,
        50,
        50,
        NULL,
        NULL, 
        g_Handles.hInstance,  
        NULL);
 
    DWORD dwError = GetLastError();

    if ( ! g_Handles.hMainWnd )
    {
        GetErrorMessage(dwError, sError, 1000);
        TRACE(sError);
        TRACE(TEXT("\n"));
    }
       
    
    return (g_Handles.hMainWnd != NULL);

}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Main window function
//       
//$E///////////////////////////////////////////////////////////////////////////////////
long WINAPI MWnd_WndProc(HWND hWnd, UINT wMessage, WPARAM wParam, LPARAM lParam)
{
    switch ( wMessage ) 
    {
      HANDLE_MSG(hWnd, WM_COMMAND, MWnd_OnCommand);

      case WM_ICON_NOTIFY:
          // Process messages from tray icon.
          // OnTrayNotification shows context menu on right-click,
          // and sends to this window defaulr menu command (START)
          // when user clicks the icon.
          return g_Variables.SystemTray.OnTrayNotification(wParam, lParam);

      default:
         return(DefWindowProc(hWnd, wMessage, wParam, lParam));
   }
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Command handler for main window
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void MWnd_OnCommand(HWND hwnd, int id, HWND hwndCtl, UINT codeNotify)
{
    // process messages from context menu
    switch (id) 
    {
    case IDR_MENU_EXIT:
        PostQuitMessage(0);
        break;

    case IDR_MENU_ABOUT:
        // About dialog
        if ( g_Handles.hAboutDlg )
        {
            // activate existing dialog
            SetForegroundWindow(g_Handles.hAboutDlg);
        }
        else
        {
            DialogBox(g_Handles.hInstance,
                      MAKEINTRESOURCE(IDD_DIALOG_ABOUT),
                      NULL,
                      (DLGPROC) DlgAbout_DlgProc);
        }
        break;

    case IDR_MENU_OPTIONS:
        // Options dialog
        if ( g_Handles.hOptionsDlg )
        {
            // activate existing dialog
            SetForegroundWindow(g_Handles.hOptionsDlg);
        }
        else
        {
            DialogBox(g_Handles.hInstance,
                      MAKEINTRESOURCE(IDD_DIALOG_OPTIONS),
                      NULL,
                      (DLGPROC) DlgOptions_DlgProc);
        }
        break;

    case IDR_MENU_START:        // click on tray icon or Start context menu command

        // activate tool
        MG_ActivateMagnificationTool();

        break;
    }
}

