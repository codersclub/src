// MagnifyFunctions.cpp
//
// Magnification functions

#include "stdafx.h"
#include "definitions.h"



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Activate magnification tool
//      (called when user clicks on tray icon ot selects Start from context menu)
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_ActivateMagnificationTool()
{
    if ( MCW_CreateWindow() )
    {
        g_Variables.bMouseButtonPressed = FALSE;
        
        MCW_SetTransparentStyle(TRUE);
        
        ShowWindow(g_Handles.hCaptureWnd, SW_MAXIMIZE);
        UpdateWindow(g_Handles.hCaptureWnd);
        
        SetForegroundWindow(g_Handles.hCaptureWnd);    // ensure handling keyboard messages in hCaptureWnd
    }
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Deactivate magnification tool
//      (called when user presses Esc or makes right-click)
//
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_DecativateMagnificationTool()
{
    MG_DestroyScreenshot();

    MCW_DestroyWindow();
}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Make magnigication.
//      Called when user presses left mouse button and
//      when mouse is moved while button is pressed.
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_MakeMagnification(int x, int y, BOOL bFirstDraw)
{
    // keep current point
    g_Variables.nMagnifyX = x;
    g_Variables.nMagnifyY = y;

    // count rectangle
    g_Variables.rcCurrent.left = x - g_Variables.options.nMagnifyGlassSize/2;
    g_Variables.rcCurrent.top = y - g_Variables.options.nMagnifyGlassSize/2;                    
    g_Variables.rcCurrent.right = g_Variables.rcCurrent.left + 
        g_Variables.options.nMagnifyGlassSize - 1;
    g_Variables.rcCurrent.bottom = g_Variables.rcCurrent.top + 
        g_Variables.options.nMagnifyGlassSize - 1;
    
    
    HDC hDC = GetDC(g_Handles.hCaptureWnd);


    if ( ! bFirstDraw )
    {
        // compare previous and current rectangles
        if ( g_Variables.rcCurrent.left == g_Variables.rcPrevious.left  &&
             g_Variables.rcCurrent.top == g_Variables.rcPrevious.top  &&
             g_Variables.rcCurrent.right == g_Variables.rcPrevious.right  &&
             g_Variables.rcCurrent.bottom == g_Variables.rcPrevious.bottom )
        {
            ReleaseDC(g_Handles.hCaptureWnd, hDC);

            return;
        }

        // restore previous region
        MG_RestorePreviousRegion(hDC);
    }

    // draw current region
    MG_DrawCurrentRegion(hDC);

    if ( g_Variables.options.bBorder )
        MG_DrawBorder(hDC);

    g_Variables.rcPrevious = g_Variables.rcCurrent;

    ReleaseDC(g_Handles.hCaptureWnd, hDC);
}



//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Mske screenshot (save all screen in memory device context)
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_MakeScreenshot(HDC hDC)
{
    MG_DestroyScreenshot();

    g_Handles.hScreenshotBitmap = (HBITMAP) CreateCompatibleBitmap(
        hDC,
        g_Variables.nScreenX,
        g_Variables.nScreenY);

    g_Handles.hScreenshotDC = CreateCompatibleDC(hDC);

    SelectObject(g_Handles.hScreenshotDC, 
                 g_Handles.hScreenshotBitmap);

    BitBlt(g_Handles.hScreenshotDC, 
           0, 
           0, 
           g_Variables.nScreenX, 
           g_Variables.nScreenY, 
           hDC, 
           0,
           0,
           SRCCOPY);

}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Restore previous magnification region from screenshot
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_RestorePreviousRegion(HDC hDC)
{
    HRGN rgnPrevious, rgnCurrent, rgnDest;

    // get difference between old and new position of magnify glass

    if ( g_Variables.options.bRound  )
    {
        rgnPrevious = CreateEllipticRgn(
            g_Variables.rcPrevious.left,
            g_Variables.rcPrevious.top,
            g_Variables.rcPrevious.right + 1,
            g_Variables.rcPrevious.bottom + 1);

        rgnCurrent = CreateEllipticRgn(
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.rcCurrent.right + 1,
            g_Variables.rcCurrent.bottom + 1);
    }
    else
    {
        rgnPrevious = CreateRectRgn(
            g_Variables.rcPrevious.left,
            g_Variables.rcPrevious.top,
            g_Variables.rcPrevious.right + 1,
            g_Variables.rcPrevious.bottom + 1);

        rgnCurrent = CreateRectRgn(
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.rcCurrent.right + 1,
            g_Variables.rcCurrent.bottom + 1);
    }

    rgnDest = CreateRectRgn(0, 0, 1, 1);

    CombineRgn(
        rgnDest,
        rgnPrevious,
        rgnCurrent,
        RGN_DIFF);

    // draw only in this region
    SelectClipRgn(hDC, rgnDest);

    BitBlt(
        hDC,
        0,
        0,
        g_Variables.nScreenX,
        g_Variables.nScreenY,
        g_Handles.hScreenshotDC,
        0,
        0,
        SRCCOPY);

    // clean-up
    SelectClipRgn(hDC, NULL);

    DeleteObject(rgnPrevious);
    DeleteObject(rgnCurrent);
    DeleteObject(rgnDest);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//      Draw current magnigication region
//      
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_DrawCurrentRegion(HDC hDC)
{
    HRGN rgn;

    if ( g_Variables.options.bRound )
    {
        rgn = CreateEllipticRgn(
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.rcCurrent.right + 1,
            g_Variables.rcCurrent.bottom + 1);
    }
    else
    {
        rgn = CreateRectRgn(
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.rcCurrent.right + 1,
            g_Variables.rcCurrent.bottom + 1);
    }

    SelectClipRgn(hDC, rgn);

    int old_mode = GetStretchBltMode(hDC);
    SetStretchBltMode(hDC, HALFTONE);

    if ( g_Variables.options.bFastMagnification )
    {
        /*
        int nSourceRectSize = 
            g_Variables.options.nMagnifyGlassSize/g_Variables.options.nCoefficient;

        // Stretch only small source rectangle
        StretchBlt(
            hDC,
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.options.nMagnifyGlassSize,
            g_Variables.options.nMagnifyGlassSize,
            g_Handles.hScreenshotDC,
            g_Variables.nMagnifyX  - (nSourceRectSize / 2),
            g_Variables.nMagnifyY  - (nSourceRectSize / 2),
            nSourceRectSize,  
            nSourceRectSize, 
            SRCCOPY);
        */

        // 25/12/2001
        // Fix bug reported by PJ Arends:
        // In Win98 destination rectangle should not be out of right/bottom screen edge 
        // otherwise StretchBlt fails.
        int nSourceRectSize = 
            g_Variables.options.nMagnifyGlassSize/g_Variables.options.nCoefficient;

        RECT r = g_Variables.rcCurrent;

        if ( r.right > g_Variables.nScreenX - 1 )
            r.right = g_Variables.nScreenX - 1;
        if ( r.bottom > g_Variables.nScreenY - 1 )
            r.bottom = g_Variables.nScreenY - 1;

        int w = r.right - r.left + 1;
        int h = r.bottom - r.top + 1;

        // Stretch only small source rectangle
        StretchBlt(
            hDC,
            r.left,
            r.top,
            w,
            h,
            g_Handles.hScreenshotDC,
            g_Variables.nMagnifyX  - (nSourceRectSize / 2),
            g_Variables.nMagnifyY  - (nSourceRectSize / 2),
            w/g_Variables.options.nCoefficient,  
            h/g_Variables.options.nCoefficient, 
            SRCCOPY);

    }
    else
    {
        // Stretching of whole source DC gives very nice smooth magnification
        // and prevents pixelization. I use this trick in image processing
        // applications. 
        // In this case source DC is whole screen so this algorithm 
        // is very slow.
        StretchBlt(
            hDC,
            -g_Variables.nMagnifyX  * g_Variables.options.nCoefficient + 
                                 g_Variables.nMagnifyX,
            -g_Variables.nMagnifyY  * g_Variables.options.nCoefficient + 
                                 g_Variables.nMagnifyY,
            g_Variables.nScreenX * g_Variables.options.nCoefficient,
            g_Variables.nScreenY * g_Variables.options.nCoefficient,
            g_Handles.hScreenshotDC,
            0,
            0,
            g_Variables.nScreenX,
            g_Variables.nScreenY,
            SRCCOPY);
    }

    SetStretchBltMode(hDC, old_mode);

    SelectClipRgn(hDC, NULL);
    DeleteObject(rgn);
}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Draw magnify glass border
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_DrawBorder(HDC hDC)
{
    HBRUSH hNullBrush = (HBRUSH) GetStockObject(NULL_BRUSH);
    HPEN hBlackPen = CreatePen(PS_SOLID, 1, RGB(0,0,0));
    HPEN hWhitePen = CreatePen(PS_SOLID, 1, RGB(255,255,255));

    HBRUSH hOldBrush = (HBRUSH) SelectObject(hDC, hNullBrush);
    HPEN hOldPen = (HPEN) SelectObject(hDC, hBlackPen);

    if ( g_Variables.options.bRound )
    {
        Ellipse(
            hDC,
            g_Variables.rcCurrent.left + 1,
            g_Variables.rcCurrent.top + 1,
            g_Variables.rcCurrent.right - 1,
            g_Variables.rcCurrent.bottom - 1);

        SelectObject(hDC, hWhitePen);

        Ellipse(
            hDC,
            g_Variables.rcCurrent.left + 2,
            g_Variables.rcCurrent.top + 2,
            g_Variables.rcCurrent.right - 2,
            g_Variables.rcCurrent.bottom - 2);
    }
    else
    {
        Rectangle(
            hDC,
            g_Variables.rcCurrent.left,
            g_Variables.rcCurrent.top,
            g_Variables.rcCurrent.right,
            g_Variables.rcCurrent.bottom);

        SelectObject(hDC, hWhitePen);

        Rectangle(
            hDC,
            g_Variables.rcCurrent.left + 2,
            g_Variables.rcCurrent.top + 2,
            g_Variables.rcCurrent.right - 2,
            g_Variables.rcCurrent.bottom - 2);
    }

    SelectObject(hDC, hOldPen);
    SelectObject(hDC, hOldBrush);

    DeleteObject(hWhitePen);
    DeleteObject(hBlackPen);
    DeleteObject(hNullBrush);

}


//$S///////////////////////////////////////////////////////////////////////////////////
//   Description :
//       Destroy bitmap and device context used for screenshot
//       
//$E///////////////////////////////////////////////////////////////////////////////////
void MG_DestroyScreenshot()
{
    if (g_Handles.hScreenshotBitmap )
    {
        DeleteObject(g_Handles.hScreenshotBitmap);
        g_Handles.hScreenshotBitmap = NULL;
    }

    if (g_Handles.hScreenshotDC )
    {
        DeleteObject(g_Handles.hScreenshotDC);
        g_Handles.hScreenshotDC = NULL;
    }
}
