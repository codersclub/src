//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MagnifyingGlass.rc
//
#define IDC_BUTTON_APPLY                3
#define IDC_CURSOR_MAGNIFY              103
#define IDI_ICON_MAGNIFY                104
#define IDR_MENU_CONTEXT                105
#define IDD_DIALOG_ABOUT                106
#define IDD_DIALOG_OPTIONS              107
#define IDC_COMBO_SIZE                  1000
#define IDC_COMBO_COEFFICIENT           1001
#define IDC_CHECK_ROUND                 1002
#define IDC_CHECK_BORDER                1003
#define IDC_COMBO_FAST_MAGNIFICATION    1005
#define IDR_MENU_ABOUT                  40001
#define IDR_MENU_EXIT                   40002
#define IDR_MENU_START                  40003
#define IDR_MENU_OPTIONS                40004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40005
#define _APS_NEXT_CONTROL_VALUE         1006
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
