; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMonitor
LastTemplate=CStatic
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Monitor.h"

ClassCount=3
Class1=CMonitorApp
Class2=CMonitorDlg

ResourceCount=3
Resource2=IDD_MONITOR_DIALOG
Resource1=IDR_MAINFRAME
Class3=CMonitor
Resource3=IDD_MONITOR_DIALOG (English (U.S.))

[CLS:CMonitorApp]
Type=0
HeaderFile=Monitor.h
ImplementationFile=Monitor.cpp
Filter=N

[CLS:CMonitorDlg]
Type=0
HeaderFile=MonitorDlg.h
ImplementationFile=MonitorDlg.cpp
Filter=D



[DLG:IDD_MONITOR_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CMonitorDlg

[DLG:IDD_MONITOR_DIALOG (English (U.S.))]
Type=1
Class=CMonitorDlg
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_MYMONITOR,static,1350696960

[CLS:CMonitor]
Type=0
HeaderFile=Monitor1.h
ImplementationFile=Monitor1.cpp
BaseClass=CStatic
Filter=W
VirtualFilter=WC
LastObject=CMonitor

