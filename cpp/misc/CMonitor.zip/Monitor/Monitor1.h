#if !defined(AFX_MONITOR1_H__D323096E_0428_11D6_AFD5_444553540000__INCLUDED_)
#define AFX_MONITOR1_H__D323096E_0428_11D6_AFD5_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Monitor1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMonitor window

class CMonitor : public CStatic
{
// Construction
public:
	CMonitor();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMonitor)
	//}}AFX_VIRTUAL

// Implementation
public:
	void ChangeAttr(int x,int y,char attr,int n);
	void Update();
	void Window(int x,int y,int dx,int dy,char attr);
	void Fill(int x,int y,char ch,char attr,int n);
	void Print(int x, int y, const char *str,char attr);
	void Print(int x,int y,const char *str);
	int dx,dy;
	void ScrollLine();
	void PrintChar(CPaintDC *dc, int x, int y,int ch,COLORREF,COLORREF);
	void PrintChar(CPaintDC *dc,int x,int y,int ch);
	unsigned char m_video[80*2*25];
	virtual ~CMonitor();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMonitor)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MONITOR1_H__D323096E_0428_11D6_AFD5_444553540000__INCLUDED_)
