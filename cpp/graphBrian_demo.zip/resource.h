//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by testdraw.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_TESTDRTYPE                  129
#define IDD_GET_GRAPH_SETTINGS          130
#define IDD_DIALOG1                     131
#define IDC_GRAPH_FRAME                 1006
#define IDC_DRAW_BTN                    1007
#define ID_DRAW                         32771
#define ID_DRAW_LINE                    32772
#define ID_DRAW_PIE                     32773
#define ID_DRAW_BAR                     32774
#define ID_DRAWGRAPHS_BARGRAPHINDIALOG  32775
#define ID_DRAW_BAR_DLG                 32776

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
