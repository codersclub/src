; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMainFrame
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "testdraw.h"
LastPage=0

ClassCount=11
Class1=CTestdrawApp
Class2=CTestdrawDoc
Class3=CTestdrawView
Class4=CMainFrame

ResourceCount=4
Resource1=IDR_MAINFRAME
Class5=CAboutDlg
Class6=MyGraph
Resource2=IDD_GET_GRAPH_SETTINGS
Class7=CGraphSettingsDlg
Class8=CGraph
Class9=CGraphSeries
Class10=CGraphLegend
Resource3=IDD_ABOUTBOX
Class11=CGraphDlg
Resource4=IDD_DIALOG1

[CLS:CTestdrawApp]
Type=0
HeaderFile=testdraw.h
ImplementationFile=testdraw.cpp
Filter=N

[CLS:CTestdrawDoc]
Type=0
HeaderFile=testdrawDoc.h
ImplementationFile=testdrawDoc.cpp
Filter=N

[CLS:CTestdrawView]
Type=0
HeaderFile=testdrawView.h
ImplementationFile=testdrawView.cpp
Filter=C
BaseClass=CView
VirtualFilter=VWC
LastObject=CTestdrawView


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
BaseClass=CFrameWnd
VirtualFilter=fWC
LastObject=CMainFrame




[CLS:CAboutDlg]
Type=0
HeaderFile=testdraw.cpp
ImplementationFile=testdraw.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=6
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,static,1342308352
Control6=IDC_STATIC,static,1342308352

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_APP_EXIT
Command3=ID_APP_ABOUT
Command4=ID_DRAW_BAR
Command5=ID_DRAW_LINE
Command6=ID_DRAW_PIE
Command7=ID_DRAW_BAR_DLG
CommandCount=7

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_UNDO
Command5=ID_EDIT_CUT
Command6=ID_EDIT_COPY
Command7=ID_EDIT_PASTE
Command8=ID_EDIT_UNDO
Command9=ID_EDIT_CUT
Command10=ID_EDIT_COPY
Command11=ID_EDIT_PASTE
Command12=ID_NEXT_PANE
Command13=ID_PREV_PANE
CommandCount=13

[TB:IDR_MAINFRAME]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_FILE_PRINT_PREVIEW
Command9=ID_APP_ABOUT
CommandCount=9

[CLS:MyGraph]
Type=0
HeaderFile=MyGraph.h
ImplementationFile=MyGraph.cpp
BaseClass=CStatic
Filter=W
LastObject=ID_APP_ABOUT

[DLG:IDD_GET_GRAPH_SETTINGS]
Type=1
Class=CGraphSettingsDlg
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352

[CLS:CGraphSettingsDlg]
Type=0
HeaderFile=GraphSettingsDlg.h
ImplementationFile=GraphSettingsDlg.cpp
BaseClass=CDialog
Filter=D
LastObject=CGraphSettingsDlg
VirtualFilter=dWC

[CLS:CGraph]
Type=0
HeaderFile=Graph.h
ImplementationFile=Graph.cpp
BaseClass=CStatic
Filter=W
LastObject=CGraph

[CLS:CGraphSeries]
Type=0
HeaderFile=GraphSeries.h
ImplementationFile=GraphSeries.cpp
BaseClass=CStatic
Filter=W
LastObject=CGraphSeries

[CLS:CGraphLegend]
Type=0
HeaderFile=GraphLegend.h
ImplementationFile=GraphLegend.cpp
BaseClass=CStatic
Filter=W
LastObject=CGraphLegend

[DLG:IDD_DIALOG1]
Type=1
Class=CGraphDlg
ControlCount=4
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_GRAPH_FRAME,static,1342177286
Control4=IDC_DRAW_BTN,button,1342242816

[CLS:CGraphDlg]
Type=0
HeaderFile=GraphDlg.h
ImplementationFile=GraphDlg.cpp
BaseClass=CDialog
Filter=D
VirtualFilter=dWC
LastObject=IDC_DRAW_BTN

