// RecentFileListDlgDlg.h : header file
//

#if !defined(AFX_RECENTFILELISTDLGDLG_H__DD0BF2C0_255E_40CC_A5E3_2C37274B5329__INCLUDED_)
#define AFX_RECENTFILELISTDLGDLG_H__DD0BF2C0_255E_40CC_A5E3_2C37274B5329__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgDlg dialog

class CRecentFileListDlgDlg : public CDialog
{
// Construction
public:
	CRecentFileListDlgDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CRecentFileListDlgDlg)
	enum { IDD = IDD_RECENTFILELISTDLG_DIALOG };
	CString	m_author;
	CString	m_title;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRecentFileListDlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

	CString m_file;

// Implementation
protected:
	HICON m_hIcon;

	void UpdateMenu (CMenu* pMenu);

	// Generated message map functions
	//{{AFX_MSG(CRecentFileListDlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnFileClose();
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	//}}AFX_MSG
	LRESULT OnOpenDemoFile(WPARAM wParam, LPARAM lParam);
	afx_msg void    OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu);
	DECLARE_MESSAGE_MAP()

	void open_file(LPCTSTR file);
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RECENTFILELISTDLGDLG_H__DD0BF2C0_255E_40CC_A5E3_2C37274B5329__INCLUDED_)
