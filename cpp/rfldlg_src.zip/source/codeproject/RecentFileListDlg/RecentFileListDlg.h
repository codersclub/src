// RecentFileListDlg.h : main header file for the RECENTFILELISTDLG application
//

#if !defined(AFX_RECENTFILELISTDLG_H__96C3E6C8_BC68_4436_BFFD_07F0F0008CDA__INCLUDED_)
#define AFX_RECENTFILELISTDLG_H__96C3E6C8_BC68_4436_BFFD_07F0F0008CDA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgApp:
// See RecentFileListDlg.cpp for the implementation of this class
//

class CRecentFileListDlgApp : public CWinApp
{
public:
	CRecentFileListDlgApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CRecentFileListDlgApp)
	public:
	virtual BOOL InitInstance();
	virtual CDocument* OpenDocumentFile(LPCTSTR lpszFileName);
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CRecentFileListDlgApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RECENTFILELISTDLG_H__96C3E6C8_BC68_4436_BFFD_07F0F0008CDA__INCLUDED_)
