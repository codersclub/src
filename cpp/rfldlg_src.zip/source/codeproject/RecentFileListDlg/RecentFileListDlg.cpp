// RecentFileListDlg.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "RecentFileListDlg.h"
#include "RecentFileListDlgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgApp

BEGIN_MESSAGE_MAP(CRecentFileListDlgApp, CWinApp)
	//{{AFX_MSG_MAP(CRecentFileListDlgApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgApp construction

CRecentFileListDlgApp::CRecentFileListDlgApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CRecentFileListDlgApp object

CRecentFileListDlgApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgApp initialization

BOOL CRecentFileListDlgApp::InitInstance()
{
	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("CodeProject Recent File List Dialog Demo"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)

	CRecentFileListDlgDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}


CDocument* CRecentFileListDlgApp::OpenDocumentFile(LPCTSTR lpszFileName) 
{
	// TODO: Add your specialized code here and/or call the base class
	
	m_pMainWnd->SendMessage(WM_OPEN_DLG_FILE, 0, (LPARAM) lpszFileName);

/*
We need to return a non null value otherwise the most recent file will be 
deleted from the menu.  If the calling function is the 
CWinApp::OnOpenRecentFile it will not use the return value, so it is safe to 
return a bogus value.
*/
	return((CDocument*) 1); // CWinApp::OpenDocumentFile(lpszFileName);
}

