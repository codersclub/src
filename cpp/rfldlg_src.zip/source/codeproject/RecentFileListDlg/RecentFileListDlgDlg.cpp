// RecentFileListDlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "RecentFileListDlg.h"
#include "RecentFileListDlgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgDlg dialog

CRecentFileListDlgDlg::CRecentFileListDlgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CRecentFileListDlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CRecentFileListDlgDlg)
	m_author = _T("");
	m_title = _T("");
	//}}AFX_DATA_INIT

	m_file = _T("");

	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CRecentFileListDlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CRecentFileListDlgDlg)
	DDX_Text(pDX, IDC_AUTHOR, m_author);
	DDX_Text(pDX, IDC_TITLE, m_title);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CRecentFileListDlgDlg, CDialog)
	//{{AFX_MSG_MAP(CRecentFileListDlgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_COMMAND(ID_FILE_CLOSE, OnFileClose)
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVE_AS, OnFileSaveAs)
	//}}AFX_MSG_MAP

	ON_MESSAGE(WM_OPEN_DLG_FILE, OnOpenDemoFile)

	ON_WM_INITMENUPOPUP()

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRecentFileListDlgDlg message handlers

BOOL CRecentFileListDlgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CRecentFileListDlgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CRecentFileListDlgDlg::OnDestroy()
{
	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CRecentFileListDlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CRecentFileListDlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CRecentFileListDlgDlg::open_file(LPCTSTR file)
{
	GetPrivateProfileString(_T("Setup"), _T("Author"), _T(""), m_author.GetBuffer(256), 256, file);
	m_author.ReleaseBuffer();

	GetPrivateProfileString(_T("Setup"), _T("Title"), _T(""), m_title.GetBuffer(256), 256, file);
	m_title.ReleaseBuffer();

	UpdateData(FALSE);
}

LRESULT CRecentFileListDlgDlg::OnOpenDemoFile(WPARAM wParam, LPARAM lParam)
{
	LRESULT rslt = 0;

	open_file((LPCTSTR) lParam);

	return(rslt);
}	


void CRecentFileListDlgDlg::OnFileClose() 
{
	// TODO: Add your command handler code here
	OnFileNew();	
}

void CRecentFileListDlgDlg::OnFileNew() 
{
	// TODO: Add your command handler code here
	m_author.Empty();
	m_title.Empty();

	UpdateData(FALSE);
}

void CRecentFileListDlgDlg::OnFileOpen() 
{
	// TODO: Add your command handler code here
	CFileDialog open_file_dlg( TRUE, "ini", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Recent File List Dialog Demo (*.ini)|*.ini|All Files (*.*)|*.*||", this);
	
	switch(open_file_dlg.DoModal())
	{
		case IDOK:
			OnFileNew();		
			
			m_file = open_file_dlg.GetPathName();
			
			AfxGetApp()->AddToRecentFileList(m_file);

			open_file((LPCTSTR) m_file);			
			break;
		
		default:
			break;	
	}
	
}

void CRecentFileListDlgDlg::OnFileSave() 
{
	// TODO: Add your command handler code here
	if ( TRUE == UpdateData(TRUE) )	
	{
		if (m_file.GetLength() == 0)
		{
			OnFileSaveAs();
		}
		
		WritePrivateProfileString(_T("Setup"), _T("Author"), (LPCTSTR) m_author, (LPCTSTR) m_file);
		WritePrivateProfileString(_T("Setup"), _T("Title"), (LPCTSTR) m_title, (LPCTSTR) m_file);
	}
}

void CRecentFileListDlgDlg::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	CFileDialog save_file_dlg( FALSE, "ini", NULL, OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT, "Recent File List Dialog Demo (*.ini)|*.ini|All Files (*.*)|*.*||", this);
	
	switch(save_file_dlg.DoModal())
	{
		case IDOK:
			m_file = save_file_dlg.GetPathName();
			
			OnFileSave();
			break;
		
		default:
			break;	
	}

}


void CRecentFileListDlgDlg::OnInitMenuPopup(CMenu* pMenu, UINT nIndex, BOOL bSysMenu) 
{
	UpdateMenu(pMenu);
}


void CRecentFileListDlgDlg::UpdateMenu (CMenu* pMenu)
{
	CCmdUI cmdUI;
	
	if (NULL != pMenu)
	{
		for (UINT n = 0; n < pMenu->GetMenuItemCount(); ++n)
		{
			CMenu* pSubMenu = pMenu->GetSubMenu(n);
			
			if (NULL != pSubMenu)
			{
				UpdateMenu (pSubMenu);		// recursive call
			}
			else
			{
				cmdUI.m_nIndex = n;
				cmdUI.m_nID = pMenu->GetMenuItemID(n);
				cmdUI.m_pMenu = pMenu;
				cmdUI.DoUpdate(this, FALSE);
			}
		}	
	}
}

