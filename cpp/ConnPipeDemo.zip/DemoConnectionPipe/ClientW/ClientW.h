// ClientW.h : main header file for the CLIENTW application
//

#if !defined(AFX_CLIENTW_H__411C8581_4DD3_11D5_AB42_00A02401A588__INCLUDED_)
#define AFX_CLIENTW_H__411C8581_4DD3_11D5_AB42_00A02401A588__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CClientWApp:
// See ClientW.cpp for the implementation of this class
//
class CConnectionPipeFirstClientW;
class CConnectionPipeAgentClient;
class CConnectionPipeTracerClient;

class CClientWApp : public CWinApp
{
public:
	CClientWApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientWApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
  CConnectionPipeFirstClientW*  pConnectionPipeFirstC;
  CConnectionPipeAgentClient*   pConnectionPipeAgentC;
  CConnectionPipeTracerClient*  pConnectionPipeTracerC;
	//{{AFX_MSG(CClientWApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTW_H__411C8581_4DD3_11D5_AB42_00A02401A588__INCLUDED_)
