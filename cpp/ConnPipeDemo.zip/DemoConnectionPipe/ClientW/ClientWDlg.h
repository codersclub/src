// ClientWDlg.h : header file
//

#if !defined(AFX_CLIENTWDLG_H__411C8583_4DD3_11D5_AB42_00A02401A588__INCLUDED_)
#define AFX_CLIENTWDLG_H__411C8583_4DD3_11D5_AB42_00A02401A588__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CClientWDlg dialog

class CClientWDlg : public CDialog
{
// Construction
public:
	CClientWDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CClientWDlg)
	enum { IDD = IDD_CLIENTW_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CClientWDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CClientWDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonSend();
	afx_msg void OnConnect();
	afx_msg void OnButtonSendw();
	afx_msg void OnButtonClear();
	afx_msg void OnDisconnect();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CLIENTWDLG_H__411C8583_4DD3_11D5_AB42_00A02401A588__INCLUDED_)
