// ClientWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ClientW.h"
#include "ClientWDlg.h"

#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#include "resource.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CClientWApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientWDlg dialog

CClientWDlg::CClientWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CClientWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CClientWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CClientWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CClientWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CClientWDlg, CDialog)
	//{{AFX_MSG_MAP(CClientWDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_SEND, OnButtonSend)
	ON_BN_CLICKED(IDC_CONNECT, OnConnect)
	ON_BN_CLICKED(IDC_BUTTON_SENDW, OnButtonSendw)
	ON_BN_CLICKED(IDC_BUTTON_CLEAR, OnButtonClear)
	ON_BN_CLICKED(IDC_DISCONNECT, OnDisconnect)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CClientWDlg message handlers

BOOL CClientWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

  GetDlgItem(IDC_CONNECT)->EnableWindow(1);  	
	GetDlgItem(IDC_DISCONNECT)->EnableWindow(0);
  GetDlgItem(IDC_BUTTON_SEND)->EnableWindow(0);
  GetDlgItem(IDC_BUTTON_SENDW)->EnableWindow(0);
  GetDlgItem(IDC_BUTTON_CLEAR)->EnableWindow(0);

  char CompName[100];
  DWORD Size = sizeof(CompName);
  GetComputerName( CompName,&Size);
  
  SetDlgItemText(IDC_SERVER_COMPUTER_NAME, CompName);
	SetTimer(0,1000,0);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CClientWDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CClientWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CClientWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
//-----------------------------------------
void CClientWDlg::OnConnect() 
{
	 char ServerCompName[100];
   char OwnCompName[100];
   DWORD Size;

   GetDlgItemText(IDC_SERVER_COMPUTER_NAME, 
         ServerCompName,sizeof(ServerCompName));
   if (!strlen(ServerCompName))
     strcpy(ServerCompName,".");

  Size = sizeof(OwnCompName);
  GetComputerName( OwnCompName,&Size);

  theApp.pConnectionPipeAgentC   = 0;
  theApp.pConnectionPipeTracerC  = 0;

//----------------- Connection with Tracer ----------------------------------------
   if (!theApp.pConnectionPipeTracerC)
   {
      CWaitForConnectionPipe<CConnectionPipeTracerClient>
        WaitForConnectionPipeTracer(theApp.pConnectionPipeTracerC, 
           "TracerCP",  0, ".");
   }
//---------------------------------------------------------  


   if (strcmp(ServerCompName,OwnCompName))
   {  // Different Computers
     //----------------- Connection with Agent ----------------------------------------

     if (theApp.pConnectionPipeAgentC)
       delete theApp.pConnectionPipeAgentC;

     CWaitForConnectionPipe<CConnectionPipeAgentClient>
         WaitForConnectionPipeAgent(theApp.pConnectionPipeAgentC, 
           "AgentCP",  0, ServerCompName);


//---------------------------------------------------------  
   
     CWaitForConnectionPipe<CConnectionPipeFirstClientW>
        WaitForConnectionPipeFirst(theApp.pConnectionPipeFirstC, 
           "First",  
           "MySink", 
           ServerCompName,
           theApp.pConnectionPipeAgentC,
           theApp.pConnectionPipeTracerC );
    
   }
   else
   {
      CWaitForConnectionPipe<CConnectionPipeFirstClientW>
        WaitForConnectionPipeFirst(theApp.pConnectionPipeFirstC, 
           "First",  
           "MySink", 
           ServerCompName,  
           0,
           theApp.pConnectionPipeTracerC );
   }
   if (theApp.pConnectionPipeFirstC->Error != ERROR_SUCCESS_CP)
   {
     delete theApp.pConnectionPipeFirstC;
     theApp.pConnectionPipeFirstC = 0;
     theApp.m_pMainWnd->SetDlgItemText(IDC_CONNECTION_RESULT,"Fault");
   }
   else
   {
       theApp.m_pMainWnd->SetDlgItemText(IDC_CONNECTION_RESULT,"OK");
	     GetDlgItem(IDC_CONNECT)->EnableWindow(0);  
       GetDlgItem(IDC_DISCONNECT)->EnableWindow(1);
       GetDlgItem(IDC_BUTTON_SEND)->EnableWindow(1);
       GetDlgItem(IDC_BUTTON_SENDW)->EnableWindow(1);
       GetDlgItem(IDC_BUTTON_CLEAR)->EnableWindow(1);
   } 
}
//------------------------------------------
void CClientWDlg::OnButtonSend() 
{
// 1-st method  preparation data in user buffer and copy it to 
//  system buffer
  char request[300];
  theApp.m_pMainWnd->GetDlgItemText(IDC_STRING,
      request,sizeof(request)); 
  if (theApp.pConnectionPipeFirstC) 
	  theApp.pConnectionPipeFirstC->SendToServerMessage(request);

}


//------------------------------------------
void CClientWDlg::OnButtonSendw() 
{
// 2-nd method: using buffers directly
	char* request;
  char* reply;
  DWORD size;

  if (theApp.pConnectionPipeFirstC)
  {
    if (theApp.pConnectionPipeFirstC->BufferAllocation == 
         ONE_TIME_BUFFER_ALLOCATION)
    {
      request = theApp.pConnectionPipeFirstC->OutputString;
      reply   = theApp.pConnectionPipeFirstC->InputString;
    }
    else
    {
      request = new char[theApp.pConnectionPipeFirstC->OutputBufferSize];
      reply   = new char[theApp.pConnectionPipeFirstC->InputBufferSize];
    }
  }
  else
  {
     AfxMessageBox("First Server is not connected");
     return;
  }
  size = theApp.pConnectionPipeFirstC->OutputBufferSize - sizeof(DWORD);
  theApp.m_pMainWnd->GetDlgItemText(  
      IDC_STRINGW, &request[sizeof(DWORD)],size ); 
  if (theApp.pConnectionPipeFirstC)
      theApp.pConnectionPipeFirstC->
         SendToServerMessageWait(request,reply);

  if (theApp.pConnectionPipeFirstC)
  {
    if (theApp.pConnectionPipeFirstC->BufferAllocation == 
         EACH_TIME_BUFFER_ALLOCATION)
    {   
       delete request;
       delete reply;
	  }
  }
}

void CClientWDlg::OnButtonClear() 
{
	SetDlgItemText( IDC_REPLY, "");
  SetDlgItemText( IDC_STRING, "");	
  SetDlgItemText( IDC_STRINGW, "");		
}

void CClientWDlg::OnDisconnect() 
{
	 if (theApp.pConnectionPipeFirstC)
   {
//      theApp.pConnectionPipeFirstC->Disconnection();
      delete theApp.pConnectionPipeFirstC;
      theApp.pConnectionPipeFirstC = 0;

      GetDlgItem(IDC_CONNECT)->EnableWindow(1);  
      GetDlgItem(IDC_DISCONNECT)->EnableWindow(0);
      GetDlgItem(IDC_BUTTON_SEND)->EnableWindow(0);
      GetDlgItem(IDC_BUTTON_SENDW)->EnableWindow(0);
      GetDlgItem(IDC_BUTTON_CLEAR)->EnableWindow(0);
      SetDlgItemText( IDC_REPLY, "");	
      SetDlgItemText( IDC_STRING, "");	
      SetDlgItemText( IDC_STRINGW, "");	
      SetDlgItemText( IDC_CONNECTION_RESULT, "");	
      SetDlgItemText( IDC_EVENT_FROM_SERVER, "");	  
   }
	
}

void CClientWDlg::OnTimer(UINT nIDEvent) 
{
	if (theApp.pConnectionPipeFirstC)
  {
    if (
       (theApp.pConnectionPipeFirstC->Error == ERROR_READ_FILE_CP) ||
	     (theApp.pConnectionPipeFirstC->Error ==ERROR_WRITE_FILE_CP)
       ) 
      OnDisconnect(); 
	}
  CDialog::OnTimer(nIDEvent);
}
