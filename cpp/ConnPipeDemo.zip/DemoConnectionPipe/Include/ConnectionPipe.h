//-----------------------------------
// File ConnectionPipe.h
//-----------------------------------

#include "ErrorsCP.h"



// The following ifdef block is the standard way of creating macros which make exporting 
// from a DLL simpler. All files within this DLL are compiled with the CONNECTIONPIPE_EXPORTS
// symbol defined on the command line. this symbol should not be defined on any project
// that uses this DLL. This way any other project whose source files include this file see 
// CONNECTIONPIPE_API functions as being imported from a DLL, wheras this DLL sees symbols
// defined with this macro as being exported.
#ifdef CONNECTIONPIPE_EXPORTS
#define CONNECTIONPIPE_API __declspec(dllexport)
#else
#define CONNECTIONPIPE_API __declspec(dllimport)
#endif

//#define DEBUG_CP

//#define CPIPE_DISCONNECTION   0
#define CPIPE_CLIENT_IDENTIFICATION  0
#define CPIPE_ANSWER                 0
#define CPIPE_REGISTRATION           1
#define CPIPE_UNREGISTRATION         2
#define CPIPE_CHANGEPASSWORD         3
#define CPIPE_USER               0x100
#define CPIPE_EVENT              0xFFFF 


typedef struct
{
  HANDLE hPipe;
  HANDLE hThread;
  HANDLE hPipeEvents;

  char*  InputString;
  char*  OutputString;

  CString ClientComputerName;
  CString Login;
  CString Password;
  CString SinkName;
} CONNECTION_PIPE_DATA;

class CConnectionPipeServer;
//-------------------------------------------------------
typedef struct 
{
  CConnectionPipeServer* pConnectionPipeServer;
  DWORD  index;
} TMP_STRUCT;
//-------------------------------------------------------
typedef struct 
{
  HANDLE hPipe;
  DWORD  cbBytesRead;
  DWORD* pcbWriteBytes; 

  char*  InputString;
  char*  OutputString;
} TMP_STRUCT1;

typedef struct
{
  DWORD LoadingResult;
  DWORD Error;
}  ERR_STRUCT_AGENT;
//--------------------------------------------

#define BUFFER_SIZE   10240
#define PIPE_TIMEOUT  10000
#define CREATE_SINK_FILE_TIMEOUT        1000
#define SERVER_WITHOUT_CLIENTS_TIMEOUT  5000
#define ONE_TIME_BUFFER_ALLOCATION      0
#define EACH_TIME_BUFFER_ALLOCATION     1

void SetServerCreatorThread( LPVOID pParam );
void SetServerInstanceThread(LPVOID pParam);
void SetClientSinkThread(LPVOID pParam);

class CConnectionPipeTracerClient;

class CONNECTIONPIPE_API CConnectionPipe
{
  protected:
  public:
    CConnectionPipe(DWORD BufferAllocation_par,
                    DWORD OutputBufferSize_par,
                    DWORD InputBufferSize_par,
                    DWORD SinkEventBufferSize_par,
                    DWORD PipeTimeOut_par);
     virtual void OutputConsole(char *fmt, ...);
     DWORD LoadLocalServer(char* ServerName);
  
     DWORD WriteToPipe(
       HANDLE hPipe,
       char* output_str,
       DWORD nNumberOfBytesToWrite, 
       DWORD* cbWritten);
     DWORD ReadFromPipe(
       HANDLE hPipe,
       char* inpbuffer,
       DWORD nNumberOfBytesToRead,
       DWORD* cbBytesRead);
     
     DWORD Error;
     DWORD OutputBufferSize;
     DWORD InputBufferSize;
     DWORD SinkEventBufferSize;
     DWORD PipeTimeOut;
     DWORD BufferAllocation;

     CConnectionPipeTracerClient* pConnectionPipeTracerC;
     char  OwnComputerName[MAX_COMPUTERNAME_LENGTH + 1]; 
};
//-------------------------------------------------------
class CONNECTIONPIPE_API CConnectionPipeServer    : 
public CConnectionPipe
{
  public:
    CConnectionPipeServer(
          char*  PipeName_par,
          CConnectionPipeTracerClient* pConnectionPipeTracerC_p = 0,
          DWORD BufferAllocation_par = ONE_TIME_BUFFER_ALLOCATION,
          DWORD OutputBufferSize_par = BUFFER_SIZE,
          DWORD InputBufferSize_par  = BUFFER_SIZE,
          DWORD SinkEventBufferSize_par  = BUFFER_SIZE,
          DWORD PipeTimeOut_par      = PIPE_TIMEOUT );
    ~CConnectionPipeServer(); 
    // threads for internal using only
    void InstanceThread(LPVOID lpvParam);
    void ServerCreatorThread(LPVOID lpvParam);

    //void WriteServerToRegistry();
    char*  GetFullPath(char* s,char* AppName);
    HANDLE CreateEventPipe(char* ClientComputerName,char* SinkName);
    virtual void PostCreateStep(int index) {}
    virtual void Disconnection(TMP_STRUCT1* ptmp1);
    
    virtual void Registration(TMP_STRUCT1* ptmp1); 
    virtual void UnRegistration(TMP_STRUCT1* ptmp1);
    virtual void ChangePassword(TMP_STRUCT1* ptmp1);


    CArray <CONNECTION_PIPE_DATA,CONNECTION_PIPE_DATA> Clients; 
    CRITICAL_SECTION CritSectClients;

    char  PipeName[300];
    char*  EventOutputString;
    virtual void  UserProcessing(  TMP_STRUCT1* ptmp1) = 0;
  protected:
      HANDLE hThreadPipeCreator;
};
//--------------------------------------------
class CConnectionPipeAgentClient;
//--------------------------------------------
class CONNECTIONPIPE_API CConnectionPipeClient  : 
public CConnectionPipe
{
  public:
    CConnectionPipeClient(DWORD BufferAllocation_par     = ONE_TIME_BUFFER_ALLOCATION,
                          DWORD OutputBufferSize_par     = BUFFER_SIZE,
                          DWORD InputBufferSize_par      = BUFFER_SIZE,
                          DWORD SinkEventBufferSize_par  = BUFFER_SIZE,
                          DWORD PipeTimeOut_par          = PIPE_TIMEOUT);
    ~CConnectionPipeClient();

    HANDLE hPipe;
    HANDLE hPipeSink;
    HANDLE hThreadSink;

    CConnectionPipeAgentClient*  pConnectionPipeAgentC;    

    DWORD CreateSink(char* sink);

    void SinkThread();
    virtual void SinkProcessing(char* chRequest,
                DWORD cbBytesRead,
                char* chReply,
                DWORD* cbReplyBytes) {}

    //DWORD Disconnection();
    DWORD Registration();  
    DWORD UnRegistration();
    DWORD ChangePassword();

    char*  InputString;
    char*  OutputString;
    char*  SinkInputString;
};

//--------------------------------------------
template < class T> class CWaitForConnectionPipe
{
   public: 
    CWaitForConnectionPipe(T*& pClient, 
        char* PipeNameServer,
        char* SinkName = "",
        char* CompNameServer = ".",
        CConnectionPipeAgentClient*  pConnectionPipeAgentC  = NULL,
        CConnectionPipeTracerClient* pConnectionPipeTracerC = NULL,
        DWORD TimeOut = 20000,
        
        DWORD BufferAllocation_par    = ONE_TIME_BUFFER_ALLOCATION,
        DWORD OutputBufferSize_par    = BUFFER_SIZE,
        DWORD InputBufferSize_par     = BUFFER_SIZE,
        DWORD SinkEventBufferSize_par = BUFFER_SIZE,
        DWORD PipeTimeOut_par         = PIPE_TIMEOUT);
};
//--------------------------------------------
template <class T> CWaitForConnectionPipe<T>::
                    CWaitForConnectionPipe(T*& pClient, 
                       char* PipeNameServer,
                       char* SinkName,
                       char* CompNameServer,
                       CConnectionPipeAgentClient*  pConnectionPipeAgentC,
                       CConnectionPipeTracerClient* pConnectionPipeTracerC_p,
                       DWORD TimeOut,

                       DWORD BufferAllocation_par,
                       DWORD OutputBufferSize_par,
                       DWORD InputBufferSize_par,
                       DWORD SinkEventBufferSize_par,
                       DWORD PipeTimeOut_par)
{
   BOOL fSuccess; 
   DWORD cbWritten; 
   DWORD dwMode,ret; 
   char FullPipeName[300];
   char buffer[300];
   char* p;
   DWORD* pID;
   DWORD  processID;
   DWORD  dwStart,dwCurrentTime;

/*
   pClient = new T(
                    BufferAllocation_par,
                    OutputBufferSize_par,
                    InputBufferSize_par,
                    SinkEventBufferSize_par,
                    PipeTimeOut_par
                  );   
*/
   pClient = new T;

   pClient->Error     = ERROR_SUCCESS_CP;
   
   pClient->pConnectionPipeAgentC  = pConnectionPipeAgentC;
   pClient->pConnectionPipeTracerC = pConnectionPipeTracerC_p;
   sprintf(FullPipeName,"\\\\%s\\pipe\\%s", CompNameServer, PipeNameServer); 
// Try to open a named pipe; wait for it, if necessary. 
 
   //GetTime
  // PipeTimeOut
   dwStart      = GetTickCount();
   while (1) 
   { 
      dwCurrentTime      = GetTickCount();
      if ( (dwCurrentTime - dwStart) > pClient->PipeTimeOut )
      {
         pClient->Error = ERROR_CLIENT_SERVER_CONNECTION;
         pClient->OutputConsole
           ("ERROR_CLIENT_SERVER_CONNECTION\n"); 
         return;
      }
      pClient->hPipe = CreateFile( 
         FullPipeName,   // pipe name 
         GENERIC_READ |  // read and write access 
         GENERIC_WRITE, 
         0,              // no sharing 
         NULL,           // no security attributes
         OPEN_EXISTING,  // opens existing pipe 
         0,              // default attributes 
         NULL);          // no template file 
 
   // Break if the pipe handle is valid. 
 
      if (pClient->hPipe != INVALID_HANDLE_VALUE)
         break; 
      // Exit if an error other than ERROR_PIPE_BUSY occurs. 
 
      ret = GetLastError();
      if ( ret != ERROR_PIPE_BUSY)
      { 
         // 2 = ERROR_FILE_NOT_FOUND
         pClient->OutputConsole("Error: Could not open pipe: %d\n",
         ret); 
      }
// All pipe instances are busy, so wait for 20 seconds. 
//      if (! WaitNamedPipe(lpszPipename, 20000) )  OutputConsole("Error:  Could not open pipe"); 
        
        pClient->OutputConsole("The pipe is not connected: %s\n",FullPipeName);
        
        if (strcmp(PipeNameServer,"AgentCP")) 
        {
           if ( (!strcmp(CompNameServer,".")) ||
                 (!strcmp(CompNameServer,pClient->OwnComputerName))  )  
           { 
               ret = pClient->LoadLocalServer(PipeNameServer);
               if (ret == FALSE)
                 continue;    // error
               pClient->OutputConsole("Loading LocalServer: %s\n",PipeNameServer);
               continue;
           }
           else
           {
               if (pClient->pConnectionPipeAgentC)
               {  
                   ERR_STRUCT_AGENT es;
                   
                   pClient->pConnectionPipeAgentC->
                     RunServerFromRegistry(PipeNameServer,&es);
                   if (es.LoadingResult == FALSE)
                   {
                      pClient->Error = es.Error;
                      pClient->OutputConsole(
                        "Error: Loading Remote Server: %s [%d]\n",
                        PipeNameServer,pClient->Error);   
                      continue;
                   }
                   pClient->OutputConsole("Loading Remote Server: %s\n",
                      PipeNameServer);
                   continue;
               }
//------------------------------------
//    To add here warning
                  ;
           }
        }
   } 
   pClient->Error     = ERROR_SUCCESS_CP;
   pClient->OutputConsole("The pipe is connected: %s\n",FullPipeName);
// The pipe connected; change to message-read mode. 
 
   dwMode = PIPE_READMODE_MESSAGE; 
   fSuccess = SetNamedPipeHandleState( 
      pClient->hPipe,  // pipe handle 
      &dwMode,         // new pipe mode 
      NULL,            // don't set maximum bytes 
      NULL);           // don't set maximum time 
   if (!fSuccess) 
   {
      pClient->OutputConsole("Error:  SetNamedPipeHandleState\n"); 
      pClient->Error     = ERROR_CLIENT_SETNAMEDPIPEHANDLESTATE;
      return;
   } 
// Send a message with ComputerName and SinkName to the pipe server. 
   pID = (DWORD*)buffer;
   p   = &buffer[sizeof(DWORD)];
   *pID = CPIPE_CLIENT_IDENTIFICATION;
   processID = GetCurrentProcessId();
   if (!SinkName)
     sprintf(p,"%s_%d",pClient->OwnComputerName,processID);
   else
   {
      sprintf(p,"%s_%s_%d",pClient->OwnComputerName,SinkName,processID);
     // now in the buffer -> FullSinkName
   }
   fSuccess = pClient->WriteToPipe(    //WriteFile( 
      pClient->hPipe,                  // pipe handle 
      buffer,                          // message 
      sizeof(DWORD) + strlen(p) + 1,   // message length 
      &cbWritten);                     // bytes written 
      

   if (! fSuccess) 
   {
      pClient->OutputConsole("Error:  WriteFile\n"); 
      pClient->Error     = ERROR_WRITE_FILE_CP;
   }
   if (SinkName)
     pClient->CreateSink(p);
}
//-----------------------------------------
// Class CConnectionPipeAgentClient
//-----------------------------------------

typedef enum ID_CONNECTIONPIPE_AGENT 
{	
 ID_RUNSERVERFROMREGISTRY = CPIPE_USER,
 ID_RUNAPPLICATION,
};
//-------------------------------------------------

class CONNECTIONPIPE_API CConnectionPipeAgentClient  : 
public CConnectionPipeClient
{
  public:
        CConnectionPipeAgentClient(
                          DWORD BufferAllocation_par    = ONE_TIME_BUFFER_ALLOCATION,
                          DWORD OutputBufferSize_par    = BUFFER_SIZE,
                          DWORD InputBufferSize_par     = BUFFER_SIZE,
                          DWORD SinkEventBufferSize_par = BUFFER_SIZE,
                          DWORD PipeTimeOut_par         = PIPE_TIMEOUT)
                        
                        :  CConnectionPipeClient
                          (
                            BufferAllocation_par, 
                            OutputBufferSize_par,
                            InputBufferSize_par,
                            SinkEventBufferSize_par,
                            PipeTimeOut_par
                          ) {}
//------------------ Sended to Server ---------   
   DWORD RunServerFromRegistry(char* ServerName,ERR_STRUCT_AGENT* pes);
   DWORD RunApplication(char* ApplName,DWORD* pLoadingResult);
};
//-------------------------------------------------
class CONNECTIONPIPE_API CConnectionPipeAgentServer  : 
public CConnectionPipeServer
{
  public:

   CConnectionPipeAgentServer( char*  PipeName_par,
          CConnectionPipeTracerClient* pConnectionPipeTracerC_p = 0,
          
          DWORD BufferAllocation_par    = ONE_TIME_BUFFER_ALLOCATION,
          DWORD OutputBufferSize_par    = BUFFER_SIZE,
          DWORD InputBufferSize_par     = BUFFER_SIZE,
          DWORD SinkEventBufferSize_par = BUFFER_SIZE,
          DWORD PipeTimeOut_par         = PIPE_TIMEOUT )
          : CConnectionPipeServer
                     (
                        PipeName_par,
                        pConnectionPipeTracerC_p,
                        BufferAllocation_par,
                        OutputBufferSize_par,
                        InputBufferSize_par,
                        SinkEventBufferSize_par,
                        PipeTimeOut_par 
                     )  {}

//------------------------ Virtual Functions ----------------

//------------------------ Received from Clients ------------
   void UserProcessing (TMP_STRUCT1* ptmp1);
//-------------- parameter TMP_STRUCT1* ptmp from UserProcessing parameter ---------
   void RunServerFromRegistry(TMP_STRUCT1* ptmp1);
   void RunApplication(TMP_STRUCT1* ptmp1); 

};
//----------------------------------------------------
//-----------------------------------------
// Class CConnectionPipeTracerClient
//-----------------------------------------

typedef enum ID_CONNECTIONPIPE_TRACER 
{	
 ID_TRACERMESSAGE = CPIPE_USER
};
//-------------------------------------------------

class CConnectionPipeTracerClient  : public CConnectionPipeClient
{
  public:
    CConnectionPipeTracerClient(
                          DWORD BufferAllocation_par       = ONE_TIME_BUFFER_ALLOCATION,
                          DWORD OutputBufferSize_par       = BUFFER_SIZE,
                          DWORD InputBufferSize_par        = BUFFER_SIZE,
                          DWORD SinkEventBufferSize_par    = BUFFER_SIZE,
                          DWORD PipeTimeOut_par            = PIPE_TIMEOUT)
                        
                        :  CConnectionPipeClient
                           (
                             BufferAllocation_par,
                             OutputBufferSize_par,
                             InputBufferSize_par,
                             SinkEventBufferSize_par,
                             PipeTimeOut_par
                           ) {}
//------------------ Sended to Server ---------   
   DWORD TracerMessage(char *fmt, ...);
};
//-------------------------------------------------
class CConnectionPipeTracerServer  : public CConnectionPipeServer
{
  public:

   CConnectionPipeTracerServer( char*  PipeName_par,
          CConnectionPipeTracerClient* pConnectionPipeTracerC_p = 0, 
          
          DWORD BufferAllocation_par     = ONE_TIME_BUFFER_ALLOCATION,
          DWORD OutputBufferSize_par     = BUFFER_SIZE,
          DWORD InputBufferSize_par      = BUFFER_SIZE,
          DWORD SinkEventBufferSize_par  = BUFFER_SIZE,          
          DWORD PipeTimeOut_par          = PIPE_TIMEOUT)
          : CConnectionPipeServer
               (
                 PipeName_par,
                 pConnectionPipeTracerC_p,
                 
                 BufferAllocation_par,     
                 OutputBufferSize_par,
                 InputBufferSize_par,
                 SinkEventBufferSize_par, 
                 PipeTimeOut_par 
               )  {}

//------------------------ Virtual Functions ----------------
   void PostCreateStep(int index);
//------------------------ Received from Clients ------------
   void UserProcessing (TMP_STRUCT1* ptmp1);
//-------------- parameter TMP_STRUCT1* ptmp from UserProcessing parameter ---------
   void TracerMessage(TMP_STRUCT1* ptmp1);
};