//-----------------------------------------
// File: ConnectionPipeFirstW.h
//-----------------------------------------

#define FIRST_OUTPUT_BUFFER_SIZE        5120
#define FIRST_INPUT_BUFFER_SIZE         5120

#define FIRST_SINK_EVENT_BUFFER_SIZE    5120
#define FIRST_PIPE_TIMEOUT              5000
//------------- ONE_TIME | EACH_TIME -----------------
#define FIRST_BUFFER_ALLOCATION    ONE_TIME_BUFFER_ALLOCATION
//#define FIRST_BUFFER_ALLOCATION    EACH_TIME_BUFFER_ALLOCATION

typedef enum ID_CONNECTIONPIPE_FIRST 
{	
 ID_SENDTOSERVERMESSAGE = CPIPE_USER,
 ID_SENDTOSERVERMESSAGEWAIT,
};
//-------------------------------------------------
typedef enum ID_EVENT_FIRST 
{
 ID_SENDFROMSERVERMESSAGE = CPIPE_EVENT,  // for TRACING
 ID_TERMINATECLIENT,
};
//-------------------------------------------------
class CConnectionPipeTracerClient;

class CConnectionPipeFirstClientW  : public CConnectionPipeClient
{
  public:
/*
     CConnectionPipeFirstClientW(
                          DWORD BufferAllocation_par        = FIRST_BUFFER_ALLOCATION,
                          DWORD OutputBufferSize_par        = FIRST_INPUT_BUFFER_SIZE,
                          DWORD InputBufferSize_par         = FIRST_OUTPUT_BUFFER_SIZE,
                          DWORD SinkEventBufferSize_par     = FIRST_SINK_EVENT_BUFFER_SIZE,
                          DWORD PipeTimeOut_par             = FIRST_PIPE_TIMEOUT)

                         :  CConnectionPipeClient
                           (
                             BufferAllocation_par,
                             OutputBufferSize_par,
                             InputBufferSize_par,
                             SinkEventBufferSize_par,
                             PipeTimeOut_par
                           ) 
*/  

     CConnectionPipeFirstClientW(
                       /*   
                          DWORD BufferAllocation_par        = FIRST_BUFFER_ALLOCATION,
                          DWORD OutputBufferSize_par        = FIRST_INPUT_BUFFER_SIZE,
                          DWORD InputBufferSize_par         = FIRST_OUTPUT_BUFFER_SIZE,
                          DWORD SinkEventBufferSize_par     = FIRST_SINK_EVENT_BUFFER_SIZE,
                          DWORD PipeTimeOut_par             = FIRST_PIPE_TIMEOUT
                       */  
                          )

                         :  CConnectionPipeClient
                           (
                             FIRST_BUFFER_ALLOCATION,
                             FIRST_INPUT_BUFFER_SIZE,
                             FIRST_OUTPUT_BUFFER_SIZE,
                             FIRST_SINK_EVENT_BUFFER_SIZE,
                             FIRST_PIPE_TIMEOUT
                           ) 


  {}
 
//------------------ Sended to Server ---------   
   DWORD SendToServerMessage(char* output_str);
   DWORD SendToServerMessageWait(char* output_str, char* input_str);
//------------------ Received from Server ---------   
   void SinkProcessing(char* chRequest,DWORD cbBytesRead,
                      char* chReply,DWORD* pcbReplyBytes);
   void Sink_SendFromServerMessage();
   void Sink_TerminateClient();
};


//-------------------------------------------------
class CConnectionPipeFirstServerW  : public CConnectionPipeServer
{
  public:

   CConnectionPipeFirstServerW( char*  PipeName_par,
          CConnectionPipeTracerClient* pConnectionPipeTracerC_p = 0,
          
          DWORD BufferAllocation_par        = FIRST_BUFFER_ALLOCATION,
          DWORD OutputBufferSize_par        = FIRST_OUTPUT_BUFFER_SIZE,
          DWORD InputBufferSize_par         = FIRST_INPUT_BUFFER_SIZE,
          DWORD SinkEventBufferSize_par     = FIRST_SINK_EVENT_BUFFER_SIZE,
          DWORD PipeTimeOut_par             = FIRST_PIPE_TIMEOUT)
          : CConnectionPipeServer(PipeName_par,
                pConnectionPipeTracerC_p, 

                BufferAllocation_par,   
                OutputBufferSize_par,
                InputBufferSize_par, 
                SinkEventBufferSize_par,
                PipeTimeOut_par )  {}

//------------------------ Virtual Functions ----------------
   void PostCreateStep(int index); 
   void Disconnection(TMP_STRUCT1* ptmp1);
//------------------------ Received from Clients ------------
   void UserProcessing (TMP_STRUCT1* ptmp1);
//-------------- parameter TMP_STRUCT1* ptmp from UserProcessing parameter ---------
   void SendToServerMessage(TMP_STRUCT1* ptmp1);
   void SendToServerMessageWait(TMP_STRUCT1* ptmp1); 

//------------------ Sended to Clients ------------------------
   void Event_SendFromServerMessage();
   void Event_TerminateClient();
//-----------------------------------------------------------
};

