#define ERROR_SUCCESS_CP                     0 
#define ERROR_CLIENT_SETNAMEDPIPEHANDLESTATE 1 
#define ERROR_WRITE_FILE_CP                  2
#define ERROR_READ_FILE_CP                   3
#define ERROR_CLIENT_CREATION_PIPES_SINK     4
#define ERROR_CLIENT_CREATION_SINK_THREAD    5
#define ERROR_CLIENT_SERVER_SINK_CONNECTION  6 // The server could not connect with sink
#define ERROR_REGISTRY_CP                    7 
#define ERROR_LOADING_CP                     8
#define ERROR_SERVER_CREATE_CREATOR_THREAD   9
#define ERROR_SERVER_CREATE_PIPE             10 //
#define ERROR_CLIENT_READ_SINK_FILE          11
#define ERROR_SERVER_CLIENT_CONNECTION       12
#define ERROR_SERVER_CREATION_EVENT_FILE     13
#define ERROR_SERVER_CREATION_EVENT_FILE_CONTINUE  14
#define ERROR_SERVER_SETNAMEDPIPEHANDLESTATE 15 
#define ERROR_SERVER_READ_CLIENT_INFO        16
#define ERROR_CLIENT_SERVER_CONNECTION       17
#define ERROR_ALLOCATION                     18 
#define ERROR_WRITE_SIZE_BUFFER              19    
#define ERROR_READ_SIZE_BUFFER               20