1. Pkunzip from Democp.zip to <Dest Directory>	 
2. cd <Dest Directory>\debug
3. RegDemoCP.bat
4. RunDemoCP.bat

Fill Computer Name, if you run Server on a remote computer. 
In this case registrate AgentCP on the remote computer and run it before. 
Server sends periodically the following Message to all connected Clients
"Server is working" (See Field "Event From Server" - in Client Dialog).
Fill data in "Send to Server" and "Send to Server and Wait" in Client Dialog.
Server terminates without connected clients after 5 sec automatically.

This Demo and ConnectionPipe.dll are time-limited  for illustration 
ConnectionPipe mechanism possibilities.
ServerW.Exe terminates automatically after 5 minutes even with connected clients. 

At the end of test make:

5. UnRegDemoCP.bat and 
6. rd /S /Q <Dest Directory>


All questions send email to:

iont@hotmail.com



