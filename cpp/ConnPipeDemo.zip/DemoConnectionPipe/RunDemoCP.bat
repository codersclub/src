start debug\clientw
start debug\clientw