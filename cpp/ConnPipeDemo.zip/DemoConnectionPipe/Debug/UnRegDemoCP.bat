rem SET OUTPUT_DIR=c:\democp

rem rd %OUTPUT_DIR% /s /q
regsvrcp /dall
