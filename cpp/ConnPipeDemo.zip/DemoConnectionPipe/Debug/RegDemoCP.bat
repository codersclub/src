regsvrcp /acd Agentcp  AgentCP.Exe 
regsvrcp /acd First  ServerW.Exe 
regsvrcp /acd Tracercp  TracerCP.Exe