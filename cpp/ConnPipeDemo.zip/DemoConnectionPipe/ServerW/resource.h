//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ServerW.rc
//
#define ID_TERMINATE_ALL                3
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_SERVERW_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_LIST_OF_CLIENTS             1000
#define IDC_EDIT_RECEIVED_FROM_CLIENTS  1002
#define IDC_LIST                        1003
#define IDC_QUANTITY                    1004
#define IDC_CHECK_TRACER                1005
#define IDC_STATUS                      1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1007
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
