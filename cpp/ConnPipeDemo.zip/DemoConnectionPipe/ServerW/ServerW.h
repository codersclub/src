// ServerW.h : main header file for the SERVERW application
//

#if !defined(AFX_SERVERW_H__7683D1BF_4D3E_11D5_AB42_00A02401A588__INCLUDED_)
#define AFX_SERVERW_H__7683D1BF_4D3E_11D5_AB42_00A02401A588__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CServerWApp:
// See ServerW.cpp for the implementation of this class
//
class CConnectionPipeFirstServerW;
class CConnectionPipeTracerClient;
class CServerWDlg;

class CServerWApp : public CWinApp
{
public:
	CServerWApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CServerWApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
  CConnectionPipeFirstServerW* pcpFirstServer;
  CConnectionPipeTracerClient* pConnectionPipeTracerC;
  
  DWORD ClientsFlag, dwStart;

  CServerWDlg* pDlg;
	//{{AFX_MSG(CServerWApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SERVERW_H__7683D1BF_4D3E_11D5_AB42_00A02401A588__INCLUDED_)
