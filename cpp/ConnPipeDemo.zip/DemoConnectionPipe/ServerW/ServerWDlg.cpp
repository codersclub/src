// ServerWDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ServerW.h"
#include "ServerWDlg.h"

#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CServerWApp theApp;
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerWDlg dialog

CServerWDlg::CServerWDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CServerWDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CServerWDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CServerWDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CServerWDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CServerWDlg, CDialog)
	//{{AFX_MSG_MAP(CServerWDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_TIMER()
	ON_BN_CLICKED(ID_TERMINATE_ALL, OnTerminateAll)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CServerWDlg message handlers

BOOL CServerWDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
  pListCtrl = (CListCtrl*)GetDlgItem(IDC_LIST);
  pListCtrl->SetExtendedStyle(LVS_EX_FULLROWSELECT 
                    | LVS_EX_GRIDLINES);

  int r0 = pListCtrl->InsertColumn (0, "Computer Name",
     LVCFMT_LEFT,150);
  pListCtrl->InsertColumn (1, "Handler", LVCFMT_LEFT,100);
  pListCtrl->EnsureVisible(0,TRUE);
  SetDlgItemText(IDC_QUANTITY,"0");
  GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(0);

  theApp.ClientsFlag    = 1;
	SetTimer(0,1000,0);
	theApp.pDlg = this;

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CServerWDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CServerWDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CServerWDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CServerWDlg::OnTimer(UINT nIDEvent) 
{
  if (theApp.pcpFirstServer)
  {
	  if (theApp.pcpFirstServer->Clients.GetSize())
    {
      theApp.ClientsFlag = 1;
      if (theApp.pcpFirstServer->Clients.GetSize() == 1)
        SetDlgItemText(IDC_STATUS,"Connected with Client");
      else
        SetDlgItemText(IDC_STATUS,"Connected with Clients");
    }
    else
    {
      if (theApp.ClientsFlag)
      {
        theApp.dwStart      = GetTickCount();
        theApp.ClientsFlag  = 0;
        char buffer[100];
        sprintf(buffer,"Shutdown after %d sec.",
          SERVER_WITHOUT_CLIENTS_TIMEOUT / 1000);
        SetDlgItemText(IDC_STATUS,buffer);
      }
      else
      {
        DWORD dwCurrTime = GetTickCount();
        if ( (dwCurrTime - theApp.dwStart) > 
          SERVER_WITHOUT_CLIENTS_TIMEOUT)
            ExitProcess(0);
      }
    }
    theApp.pcpFirstServer->Event_SendFromServerMessage();	
  }
  CDialog::OnTimer(nIDEvent);
}

void CServerWDlg::OnTerminateAll() 
{
  if (theApp.pcpFirstServer)
    theApp.pcpFirstServer->Event_TerminateClient();
  SetDlgItemText(IDC_QUANTITY,"0");
  pListCtrl->DeleteAllItems( );	
  GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(0);
}
