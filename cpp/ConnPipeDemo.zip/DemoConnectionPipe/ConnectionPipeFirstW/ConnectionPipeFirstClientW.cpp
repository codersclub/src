//-----------------------------------------
// File: ConnectionPipeFirstClient.cpp
//-----------------------------------------

#include "StdAfx.h"

#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#include "ClientW.h"
#include "ClientWDlg.h"


extern CClientWApp theApp;
//-----------------------------------------
// 1-st method: copy parameters to output buffer
DWORD CConnectionPipeFirstClientW::SendToServerMessage(char* output_str)
{

   DWORD size = strlen(output_str) + 1 + sizeof(DWORD);

   char* request;
   if (BufferAllocation == ONE_TIME_BUFFER_ALLOCATION)
     request = OutputString;
   else
     request = new char[InputBufferSize];

   BOOL fSuccess; 
   DWORD cbWritten; 
   DWORD* pdw = (DWORD*)request;
   *pdw = ID_SENDTOSERVERMESSAGE;
   strcpy(&request[sizeof(DWORD)],output_str);
   
   theApp.m_pMainWnd->SetDlgItemText( IDC_REPLY, "");
   fSuccess = WriteToPipe(
      hPipe,                  // pipe handle 
      request,                // message 
      size,                   // message length 
      &cbWritten              // bytes written 
      ); 
   if (! fSuccess) 
      OutputConsole("Error:  WriteFile\n"); 

   if (BufferAllocation == EACH_TIME_BUFFER_ALLOCATION)
     delete request;
   return Error;
}
//-----------------------------------------
// 2-nd method: working with output buffer directly
DWORD CConnectionPipeFirstClientW::
SendToServerMessageWait(char* output_str, char* input_str)
{

   BOOL fSuccess; 
   DWORD cbRead, cbWritten;
   DWORD* pdw = (DWORD*)output_str;
   *pdw = ID_SENDTOSERVERMESSAGEWAIT;

   theApp.m_pMainWnd->SetDlgItemText( IDC_REPLY, "");
   DWORD size = strlen(&output_str[sizeof(DWORD)]) + 1 + sizeof(DWORD);
   fSuccess = WriteToPipe( 
      hPipe,                   // pipe handle 
      output_str,              // message 
      size,                    // message length 
      &cbWritten               // bytes written 
      ); 
   if (! fSuccess) 
      OutputConsole("Error:  WriteFile\n"); 

   
   fSuccess = ReadFromPipe( 
         hPipe,              // pipe handle 
         input_str,          // buffer to receive reply 
         InputBufferSize,    // size of buffer 
         &cbRead             // number of bytes read 
         );  
 

    theApp.m_pMainWnd->SetDlgItemText( IDC_REPLY, 
       &input_str[sizeof(DWORD)]);
//      if (! fSuccess && GetLastError() != ERROR_MORE_DATA) 
//         break; 
   return Error;
} 
//-----------------------------------------
void CConnectionPipeFirstClientW::
Sink_SendFromServerMessage()
{
  static i = 0;
  
  switch(i)
  {
    case 0:
      theApp.m_pMainWnd->SetDlgItemText(IDC_EVENT_FROM_SERVER,
         ".Server is working!");
      i++;
    break;
    case 1:
      theApp.m_pMainWnd->SetDlgItemText(IDC_EVENT_FROM_SERVER,
         "..Server is working!!");
      i++;
    break;
    case 2:
      theApp.m_pMainWnd->SetDlgItemText(IDC_EVENT_FROM_SERVER,
         "...Server is working!!!");
      i = 0;
    break;
  }
}
//-------------------------------------
void CConnectionPipeFirstClientW::
Sink_TerminateClient()
{
  ExitProcess(0);
}
