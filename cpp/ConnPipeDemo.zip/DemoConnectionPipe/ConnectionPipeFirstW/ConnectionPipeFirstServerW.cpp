//-----------------------------------------
// File: ConnectionPipeFirstServer.cpp
//-----------------------------------------

#include "StdAfx.h"

#include "ServerW.h"
#include "ServerWDlg.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#include "resource.h"

extern CServerWApp theApp;


//----------------------------------
void CConnectionPipeFirstServerW::
PostCreateStep(int index) 
{
  CONNECTION_PIPE_DATA cpd;
  char buffer[300];
  DWORD MaxInd;
  cpd = Clients.GetAt(index);
  
  sprintf(buffer,"0x%X",cpd.hPipe);

  CListCtrl* pListCtrl = (CListCtrl*)(theApp.pDlg->pListCtrl);
  pListCtrl->InsertItem( index, 
      LPCTSTR(cpd.ClientComputerName) );

  pListCtrl->SetItemText(index,1,buffer);
  EnterCriticalSection(&CritSectClients);
    MaxInd = Clients.GetSize();
  LeaveCriticalSection(&CritSectClients);
  sprintf(buffer,"%d",MaxInd);
  theApp.pDlg->SetDlgItemText(IDC_QUANTITY,buffer);
  if (MaxInd)
      theApp.pDlg->GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(1);
  else
      theApp.pDlg->GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(0);
}
//----------------------------------
void CConnectionPipeFirstServerW::
SendToServerMessage(TMP_STRUCT1* ptmp1)
{
  char*  input_str;
  input_str = ptmp1->InputString + sizeof(DWORD);
  theApp.m_pMainWnd->SetDlgItemText(
      IDC_EDIT_RECEIVED_FROM_CLIENTS,input_str);
}
//----------------------------------
void CConnectionPipeFirstServerW::
SendToServerMessageWait(TMP_STRUCT1* ptmp1)
{
   DWORD cbReplyBytes,cbWritten,fSuccess;
   char*  input_str = ptmp1->InputString + sizeof(DWORD);
   char*  output_str;
   if (BufferAllocation == ONE_TIME_BUFFER_ALLOCATION)
      output_str = ptmp1->OutputString;
   else
      output_str = new char[OutputBufferSize];
   DWORD* pID = (DWORD*)output_str; 
   char*  p = &output_str[sizeof(DWORD)];   
    theApp.m_pMainWnd->
      SetDlgItemText(IDC_EDIT_RECEIVED_FROM_CLIENTS,
         input_str);

    *pID = CPIPE_ANSWER;
    strcpy(p, "It is reply from Server\n");
    cbReplyBytes = strlen(p) + 1 + sizeof(DWORD);

    fSuccess = WriteToPipe(
        ptmp1->hPipe,     // handle to pipe 
        output_str,       // buffer to write from 
        cbReplyBytes,     // number of bytes to write 
        &cbWritten        // number of bytes written 
        );
    if (BufferAllocation == EACH_TIME_BUFFER_ALLOCATION) 
      delete output_str;
     if (! fSuccess || cbReplyBytes != cbWritten)
        Disconnection(ptmp1);
}
//---------------------------------
void CConnectionPipeFirstServerW::
Event_SendFromServerMessage()
{
     int i;
     CONNECTION_PIPE_DATA cpd;
     DWORD cbWritten = 0,fSuccess = 0; 
     DWORD id = ID_SENDFROMSERVERMESSAGE;

     EnterCriticalSection(&CritSectClients);
     for (i = 0;i < Clients.GetSize();i++)
     {
        cpd = Clients.GetAt(i);        
        fSuccess = WriteToPipe(
                      cpd.hPipeEvents,           // handle to pipe 
                      (char*)&id,                // buffer to write from 
                      sizeof(id),                // number of bytes to write 
                      &cbWritten                // number of bytes written 
                      );
//        if (! fSuccess)  // || cbReplyBytes != cbWritten)
//           Disconnection(&tmp1);
     }
     LeaveCriticalSection(&CritSectClients);
}
//----------------------------------------
void CConnectionPipeFirstServerW::
Event_TerminateClient()
{
     int i;
     CONNECTION_PIPE_DATA cpd;
     DWORD cbWritten = 0,fSuccess = 0; 
     DWORD id = ID_TERMINATECLIENT;

     EnterCriticalSection(&CritSectClients);
     for (i = 0;i < Clients.GetSize();i++)
     {
        cpd = Clients.GetAt(i);        
        fSuccess = WriteToPipe(
                      cpd.hPipeEvents,           // handle to pipe 
                      (char*)&id,                // buffer to write from 
                      sizeof(id),                // number of bytes to write 
                      &cbWritten                 // number of bytes written 
                      );                         // not overlapped I/O 
     }
     LeaveCriticalSection(&CritSectClients);
}
//----------------------------------------
void CConnectionPipeFirstServerW::
Disconnection(TMP_STRUCT1* ptmp1)
{
  CConnectionPipeServer::Disconnection(ptmp1);
  int i;
  char buf[100];
  char buf1[100];

  CListCtrl* pListCtrl = (CListCtrl*)(theApp.pDlg->pListCtrl);
  EnterCriticalSection(&CritSectClients);
    sprintf(buf,"%d",Clients.GetSize());
  LeaveCriticalSection(&CritSectClients);
  theApp.pDlg->SetDlgItemText(IDC_QUANTITY,buf);
  for (i = 0;i < pListCtrl->GetItemCount();i++)
  {
     pListCtrl->GetItemText(i,1,buf,sizeof(buf) );
     sprintf(buf1,"0x%X",ptmp1->hPipe);
     if (strcmp(buf1,buf))
       continue;
     pListCtrl->DeleteItem(i);
     break;
  }
  if (pListCtrl->GetItemCount())
      theApp.pDlg->GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(1);
  else
      theApp.pDlg->GetDlgItem(ID_TERMINATE_ALL)->EnableWindow(0);
}
