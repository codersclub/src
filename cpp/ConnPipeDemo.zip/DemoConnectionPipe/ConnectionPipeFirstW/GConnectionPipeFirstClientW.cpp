//-----------------------------------------
// File: GConnectionPipeFirstClient.cpp
//-----------------------------------------

#include "StdAfx.h"

#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#include "ClientW.h"
#include "ClientWDlg.h"


extern CClientWApp theApp;

//-----------------------------------------
void CConnectionPipeFirstClientW::
SinkProcessing(char* chRequest,
                DWORD cbBytesRead,
                char* chReply,
                DWORD* cbReplyBytes)
{
   DWORD* pid = (DWORD*)chRequest;
//   char*  input_str = chRequest + sizeof(DWORD);
//   char*  output_str = chReply;
       
   switch(*pid)
   {
       case ID_SENDFROMSERVERMESSAGE:
           Sink_SendFromServerMessage();
       break;
       default:
         OutputConsole("[SinkProcessing] *** id = %d is wrong\n",
             *pid);
       break;
       case ID_TERMINATECLIENT:
           Sink_TerminateClient();
       break;
   }
}