// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4B47994F_4553_11D5_AB3D_00A02401A588__INCLUDED_)
#define AFX_STDAFX_H__4B47994F_4553_11D5_AB3D_00A02401A588__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afx.h>
#include <afxwin.h>
#include <afxtempl.h>

#include <afxcmn.h>


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4B47994F_4553_11D5_AB3D_00A02401A588__INCLUDED_)
