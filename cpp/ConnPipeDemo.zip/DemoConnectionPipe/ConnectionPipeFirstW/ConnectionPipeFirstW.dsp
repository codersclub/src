# Microsoft Developer Studio Project File - Name="ConnectionPipeFirstW" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Static Library" 0x0104

CFG=ConnectionPipeFirstW - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "ConnectionPipeFirstW.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ConnectionPipeFirstW.mak" CFG="ConnectionPipeFirstW - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ConnectionPipeFirstW - Win32 Release" (based on "Win32 (x86) Static Library")
!MESSAGE "ConnectionPipeFirstW - Win32 Debug" (based on "Win32 (x86) Static Library")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /YX /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /YX /FD /c
# ADD BASE RSC /l 0x40d /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x40d /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# PROP BASE Use_MFC 2
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 2
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /YX /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /I "..\Include" /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /YX /FD /GZ /c
# ADD BASE RSC /l 0x40d /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x40d /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LIB32=link.exe -lib
# ADD BASE LIB32 /nologo
# ADD LIB32 /nologo /out:"..\Lib\ConnectionPipeFirstW.lib"

!ENDIF 

# Begin Target

# Name "ConnectionPipeFirstW - Win32 Release"
# Name "ConnectionPipeFirstW - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\ConnectionPipeFirstClientW.cpp

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# ADD CPP /I "..\ClientW" /I "..\ServerW"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\ConnectionPipeFirstServerW.cpp

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# ADD CPP /I "..\ClientW" /I "..\ServerW"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\GConnectionPipeFirstClientW.cpp

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# ADD CPP /I "..\ClientW" /I "..\ServerW"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\GConnectionPipeFirstServerW.cpp

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# ADD CPP /I "..\ClientW" /I "..\ServerW"

!ENDIF 

# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Release"

!ELSEIF  "$(CFG)" == "ConnectionPipeFirstW - Win32 Debug"

# ADD CPP /I "..\ClientW" /I "..\ServerW"

!ENDIF 

# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=..\Include\ConnectionPipeFirstW.h
# End Source File
# End Group
# End Target
# End Project
