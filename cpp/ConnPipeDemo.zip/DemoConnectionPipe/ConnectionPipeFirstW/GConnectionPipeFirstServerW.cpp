//-----------------------------------------
// File: GConnectionPipeFirstServerW.cpp
//-----------------------------------------

#include "StdAfx.h"

#include "ServerW.h"
#include "ServerWDlg.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeFirstW.h"

#include "resource.h"

extern CServerWApp theApp;

//----------------------------------
void CConnectionPipeFirstServerW::
UserProcessing( TMP_STRUCT1* ptmp1)
{
   DWORD* pid = (DWORD*)ptmp1->InputString;    
   switch(*pid)
   {
       case ID_SENDTOSERVERMESSAGE:
           SendToServerMessage(ptmp1);
       break;
       case ID_SENDTOSERVERMESSAGEWAIT:
           SendToServerMessageWait(ptmp1);
       break;
       default:
           OutputConsole("*** id is wrong\n",*pid);
       break;
   }
}