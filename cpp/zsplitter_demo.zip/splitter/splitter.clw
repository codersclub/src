; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMyView1
LastTemplate=CDocument
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "splitter.h"

ClassCount=9
Class1=CSplitterApp
Class2=CSplitterDlg
Class3=CAboutDlg

ResourceCount=13
Resource1=IDD_PROPPAGE_MEDIUM1
Resource2=IDR_MAINFRAME2
Resource3=IDD_ABOUTBOX
Resource4=IDD_PROPPAGE_MEDIUM2 (English (U.S.))
Resource5=IDD_PROPPAGE_MEDIUM
Resource6=IDD_FORMVIEW (English (U.S.))
Class4=CTestDlg1
Class5=CTestDlg2
Class6=CTestSheet
Resource7=IDD_PROPPAGE_MEDIUM (English (U.S.))
Resource8=IDD_SPLITTER_DIALOG (English (U.S.))
Resource9=IDD_PROPPAGE_MEDIUM2
Resource10=IDD_PROPPAGE_MEDIUM1 (English (U.S.))
Resource11=IDD_SPLITTER_DIALOG
Class7=CMyView1
Class8=CMyFrame
Resource12=IDD_ABOUTBOX (English (U.S.))
Class9=CMyDocument
Resource13=IDD_DEMO_DIALOG (Italian (Italy))

[CLS:CSplitterApp]
Type=0
HeaderFile=splitter.h
ImplementationFile=splitter.cpp
Filter=N
LastObject=CSplitterApp

[CLS:CSplitterDlg]
Type=0
HeaderFile=splitterDlg.h
ImplementationFile=splitterDlg.cpp
Filter=D
LastObject=CSplitterDlg
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=splitterDlg.h
ImplementationFile=splitterDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_SPLITTER_DIALOG]
Type=1
Class=CSplitterDlg
ControlCount=1
Control1=IDC_LIST1,SysListView32,1350631424

[DLG:IDD_SPLITTER_DIALOG (English (U.S.))]
Type=1
Class=CSplitterDlg
ControlCount=1
Control1=IDC_LIST1,SysListView32,1350631424

[DLG:IDD_PROPPAGE_MEDIUM (English (U.S.))]
Type=1
Class=CTestDlg1
ControlCount=10
Control1=IDC_LIST1,SysListView32,1350631427
Control2=IDC_LIST2,SysListView32,1350631426
Control3=IDC_LIST3,SysListView32,1350631426
Control4=IDC_LIST4,SysListView32,1350631426
Control5=IDC_LIST5,SysListView32,1350631426
Control6=IDC_LIST6,SysListView32,1350631426
Control7=IDC_LIST9,SysListView32,1350631426
Control8=IDC_LIST7,msctls_progress32,1350565888
Control9=IDC_LIST8,msctls_progress32,1350565888
Control10=IDC_BUTTON2,button,1342242816

[DLG:IDD_PROPPAGE_MEDIUM1 (English (U.S.))]
Type=1
Class=CTestDlg2
ControlCount=5
Control1=IDC_LIST1,SysListView32,1350631424
Control2=IDC_LIST5,SysListView32,1350631424
Control3=IDC_LIST9,SysListView32,1350631424
Control4=IDC_LIST6,SysListView32,1350631424
Control5=IDC_BUTTON1,button,1342242816

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[CLS:CTestDlg2]
Type=0
HeaderFile=TestDlg2.h
ImplementationFile=TestDlg2.cpp
BaseClass=CPropertyPage
Filter=D
VirtualFilter=idWC
LastObject=CTestDlg2

[CLS:CTestSheet]
Type=0
HeaderFile=TestSheet.h
ImplementationFile=TestSheet.cpp
BaseClass=CPropertySheet
Filter=W
LastObject=CTestSheet

[DLG:IDD_PROPPAGE_MEDIUM2 (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDC_LIST1,SysListView32,1350631424
Control2=IDC_LIST5,SysListView32,1350631424
Control3=IDC_LIST9,SysListView32,1350631424
Control4=IDC_LIST6,SysListView32,1350631424
Control5=IDC_SPLIT_MID,static,1350697216

[DLG:IDD_DEMO_DIALOG (Italian (Italy))]
Type=1
Class=CMyView1
ControlCount=8
Control1=IDC_LABEL1,static,1342308352
Control2=IDC_SPIN1,msctls_updown32,1342177376
Control3=IDC_EDIT1,edit,1352728644
Control4=IDC_RADIO1,button,1342373897
Control5=IDC_RADIO2,button,1342177289
Control6=IDC_GROUP1,button,1342177287
Control7=IDOK,button,1342373889
Control8=IDCANCEL,button,1342242816

[DLG:IDD_PROPPAGE_MEDIUM]
Type=1
Class=CTestDlg1
ControlCount=10
Control1=IDC_LIST1,SysListView32,1350631427
Control2=IDC_LIST2,SysListView32,1350631426
Control3=IDC_LIST3,SysListView32,1350631426
Control4=IDC_LIST4,SysListView32,1350631426
Control5=IDC_LIST5,SysListView32,1350631426
Control6=IDC_LIST6,SysListView32,1350631426
Control7=IDC_LIST9,SysListView32,1350631426
Control8=IDC_LIST7,msctls_progress32,1350565888
Control9=IDC_LIST8,msctls_progress32,1350565888
Control10=IDC_BUTTON2,button,1342242816

[DLG:IDD_PROPPAGE_MEDIUM1]
Type=1
Class=CTestDlg2
ControlCount=5
Control1=IDC_LIST1,SysListView32,1350631424
Control2=IDC_LIST5,SysListView32,1350631424
Control3=IDC_LIST9,SysListView32,1350631424
Control4=IDC_LIST6,SysListView32,1350631424
Control5=IDC_BUTTON1,button,1342242816

[DLG:IDD_PROPPAGE_MEDIUM2]
Type=1
Class=?
ControlCount=5
Control1=IDC_LIST1,SysListView32,1350631424
Control2=IDC_LIST5,SysListView32,1350631424
Control3=IDC_LIST9,SysListView32,1350631424
Control4=IDC_LIST6,SysListView32,1350631424
Control5=IDC_SPLIT_MID,static,1350697216

[CLS:CMyFrame]
Type=0
HeaderFile=MyFrame.h
ImplementationFile=MyFrame.cpp
BaseClass=CFrameWnd
Filter=T
LastObject=CMyFrame

[DLG:IDD_FORMVIEW (English (U.S.))]
Type=1
Class=CMyView1
ControlCount=3
Control1=IDC_BUTTON1,button,1342242816
Control2=IDC_BUTTON2,button,1342242816
Control3=IDC_BUTTON3,button,1342242816

[CLS:CMyDocument]
Type=0
HeaderFile=MyDocument.h
ImplementationFile=MyDocument.cpp
BaseClass=CDocument
Filter=N
LastObject=IDC_BUTTON1

[MNU:IDR_MAINFRAME2]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_WINDOWS_NEW
CommandCount=2

[CLS:CMyView1]
Type=0
HeaderFile=myview1.h
ImplementationFile=myview1.cpp
BaseClass=ZSplitterDlgImpl_CView_MyZSplitter
LastObject=CMyView1

