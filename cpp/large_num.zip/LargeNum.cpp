// LargeNum.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "LNum.h"
#include "math.h"
#include "fstream.h"
#define LINESIZE 100

int main(int argc, char* argv[])
{
	CLNum a,b,c,d,x1,x2,s,p1,p2;
	char line[80];
	char sza[LINESIZE];
	char szb[LINESIZE];
	char szc[LINESIZE];
	cout<<"Enter file name\n";
	cin.getline(line,80);
	ifstream data(line);
	cout<<"Enter tochnost\n";
	int tt;
	cin>>tt;
	while(data)
	{
		
		data.getline(sza,LINESIZE);
		data.getline(szb,LINESIZE);
		data.getline(szc,LINESIZE);

	try
	{
		a.SetVal(sza);
		a.SetTochnost(tt);
		b.SetVal(szb);
		b.SetTochnost(tt);
		c.SetVal(szc);
		c.SetTochnost(tt);
	cout<<"a="<<a<<"\nb="<<b<<"\nc="<<c<<"\n";
		
		if(a==(CLNum)0)
		{
			cout<<"uravnenie ne kvadratnoe\n";
			if(b==(CLNum)0)
			{
				if(c==(CLNum)0)
				{
					cout<<"beskonechnoe mnozhestvo resheniy\n";
				}
				else
					cout<<"Net resheniy\n";
			}
			else
			{
				cout<<"x="<<(-c)/b<<"\n";
			}
		}
		else
		{
			d=b*b-4*a*c;
			if(d<(CLNum)0)
			{
				cout<<"There is no roots\n";
			}
			else
			{
				s=sqrt(d);
//				cout<<s<<"\n";
//				p1=-b+s;
//				p2=2*a;
//				cout<<"p1="<<p1<<"\np2="<<p2<<"\n";
//				cin>>tt;
				x1=(-b+s)/(2*a);
				x2=(-b-s)/(2*a);
				cout<<"x1="<<x1<<"\n"<<"x2="<<x2<<"\n";
			}
		}

	
	}
	catch(CLNum::Error e)
	{
		cout<<"Error "<<e.p<<"\n";
	}
	catch(CLNum::DivZero)
	{
		cout<<"Error: divizion by zero\n";
	};
	cout<<"Press <Enter> to continue\n";
	cin.getline(line,80);
	}//while(data)

/*		cout<<"b=\n";
		cin.getline(line,80);
		if(*line=='z')break;
		try
		{
			b.SetVal(line);
		}
		catch(CLNum::Error e)
		{
			cout<<"Eerror "<<e.p<<"\n";
		}
		cout<<"c=\n";
		cin.getline(line,80);
		if(*line=='z')break;
		try
		{
			c.SetVal(line);
		}
		catch(CLNum::Error e)
		{
			cout<<"Eerror "<<e.p<<"\n";
		}

		
		
		
		cout<<"sqrt\n";
		cout<<"a="<<a<<"\n";

		try
		{
			b=sqrt(a);
			cout<<"a="<<a<<"\n"<<b<<"\n*\n"<<b<<"\n=\n"<<b*b<<"\n";
//			cout<<sqrt(ss)<<"\n";
			
		}
		catch(CLNum::DivZero)
		{
			cout<<"Error: divizion by zero\n";
		}
		catch(CLNum::Error e)
		{
			cout<<" Error: "<<e.p<<"\n";
		};
	}
*/	return 0;
}
