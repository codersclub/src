// ==========================================================================
// DrvListBox.h - header file for the CDrvListBox class
//
// A CDrvListBos is a drop down list box which shows all drives on the local
// computer with the same icons and names as the explorer. This control is
// derived from CComboBoxEx. Use it instead of a CComboBoxEx and call
// LoadItems in the OnInitDialog() of the parent dialog. By default, small
// icons are displayed but you may specify ( true ) as parameter to LoadItems
// to request the large icons. This will also increase the size of your edit
// box! GetDataPtr will retrieve a pointer a string containing the root path
// (e.g. for "Harddisk1 (C:)" this would be "C:\").
// ==========================================================================

#if !defined(AFX_DRVLISTBOX_H__A039CAD8_A4C0_11D2_9683_F1FAB8EF2238__INCLUDED_)
#define AFX_DRVLISTBOX_H__A039CAD8_A4C0_11D2_9683_F1FAB8EF2238__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// --------------------------------------------------------------------------
class CDrvListBox : public CComboBoxEx
// --------------------------------------------------------------------------
  {
  // Construction

  public:
    CDrvListBox();

    // call LoadItems during OnInitDialog to fill ComboBox with data

    int LoadItems( const bool bLargeIcons = false );

  // Attributes

  public:

  // Operations

  public:

  // Overrides

  //{{AFX_VIRTUAL(CDrvListBox)
  //}}AFX_VIRTUAL

  // Implementation

  private:

    // this buffer (allocated during construction) will hold the logical
    // drive strings as returned by GetLogicalDriveStrings; pointers to
    // each individual string will be stored in the COMBOBOXEXITEM structure
    // for later retrieval via GetDataPtr()

    _TCHAR      *m_pDriveStrings;  // list of drive strings: A:\ B:\ etc.
    CImageList  *m_pImageList;     // holds the attached system image list

  public:
    virtual ~CDrvListBox();

  // Generated message map functions

  protected:
  //{{AFX_MSG(CDrvListBox)
  //}}AFX_MSG

  DECLARE_MESSAGE_MAP()
  };

//{{AFX_INSERT_LOCATION}}

#endif // !defined(AFX_DRVLISTBOX_H__A039CAD8_A4C0_11D2_9683_F1FAB8EF2238__INCLUDED_)
