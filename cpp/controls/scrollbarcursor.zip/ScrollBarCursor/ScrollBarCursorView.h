// ScrollBarCursorView.h : interface of the CScrollBarCursorView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCROLLBARCURSORVIEW_H__531C4D4D_C01F_40A2_8533_F4DB8C98DF6F__INCLUDED_)
#define AFX_SCROLLBARCURSORVIEW_H__531C4D4D_C01F_40A2_8533_F4DB8C98DF6F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CScrollBarCursorView : public CEditView
{
protected: // create from serialization only
	CScrollBarCursorView();
	DECLARE_DYNCREATE(CScrollBarCursorView)
// Attributes
public:
	CScrollBarCursorDoc* GetDocument();
private:
	UINT m_nVIDResource;//Current ID of the cursor resource (vertical scroll bar)
	UINT m_nHIDResource;//Current ID of the cursor resource (horizontal scroll bar)

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScrollBarCursorView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScrollBarCursorView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScrollBarCursorView)
	afx_msg void OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	afx_msg BOOL OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message);
	afx_msg void OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in ScrollBarCursorView.cpp
inline CScrollBarCursorDoc* CScrollBarCursorView::GetDocument()
   { return (CScrollBarCursorDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCROLLBARCURSORVIEW_H__531C4D4D_C01F_40A2_8533_F4DB8C98DF6F__INCLUDED_)
