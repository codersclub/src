; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAboutDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "scrollbarcursor.h"
LastPage=0

ClassCount=6
Class1=CCBCursor
Class2=CMainFrame
Class3=CScrollBarCursorApp
Class4=CAboutDlg
Class5=CScrollBarCursorDoc
Class6=CScrollBarCursorView

ResourceCount=2
Resource1=IDD_ABOUTBOX (English (U.S.))
Resource2=IDR_MAINFRAME (English (U.S.))

[CLS:CCBCursor]
Type=0
BaseClass=CComboBox
HeaderFile=CBCursor.h
ImplementationFile=CBCursor.cpp
Filter=W
VirtualFilter=cWC
LastObject=CCBCursor

[CLS:CMainFrame]
Type=0
BaseClass=CFrameWnd
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
VirtualFilter=fWC

[CLS:CScrollBarCursorApp]
Type=0
BaseClass=CWinApp
HeaderFile=ScrollBarCursor.h
ImplementationFile=ScrollBarCursor.cpp
LastObject=CScrollBarCursorApp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=ScrollBarCursor.cpp
ImplementationFile=ScrollBarCursor.cpp
LastObject=CAboutDlg

[CLS:CScrollBarCursorDoc]
Type=0
BaseClass=CDocument
HeaderFile=ScrollBarCursorDoc.h
ImplementationFile=ScrollBarCursorDoc.cpp

[CLS:CScrollBarCursorView]
Type=0
BaseClass=CEditView
HeaderFile=ScrollBarCursorView.h
ImplementationFile=ScrollBarCursorView.cpp
LastObject=CScrollBarCursorView
Filter=C
VirtualFilter=VWC

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_APP_ABOUT
CommandCount=8

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_MRU_FILE1
Command6=ID_APP_EXIT
Command7=ID_EDIT_UNDO
Command8=ID_EDIT_CUT
Command9=ID_EDIT_COPY
Command10=ID_EDIT_PASTE
Command11=ID_VIEW_TOOLBAR
Command12=ID_VIEW_STATUS_BAR
Command13=ID_APP_ABOUT
CommandCount=13

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_UNDO
Command5=ID_EDIT_CUT
Command6=ID_EDIT_COPY
Command7=ID_EDIT_PASTE
Command8=ID_EDIT_UNDO
Command9=ID_EDIT_CUT
Command10=ID_EDIT_COPY
Command11=ID_EDIT_PASTE
Command12=ID_NEXT_PANE
Command13=ID_PREV_PANE
CommandCount=13

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC,static,1342308352

