// ScrollBarCursorDoc.h : interface of the CScrollBarCursorDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_SCROLLBARCURSORDOC_H__968F112D_27AD_43FF_BC9A_15EF886A466D__INCLUDED_)
#define AFX_SCROLLBARCURSORDOC_H__968F112D_27AD_43FF_BC9A_15EF886A466D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CScrollBarCursorDoc : public CDocument
{
protected: // create from serialization only
	CScrollBarCursorDoc();
	DECLARE_DYNCREATE(CScrollBarCursorDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScrollBarCursorDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CScrollBarCursorDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CScrollBarCursorDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCROLLBARCURSORDOC_H__968F112D_27AD_43FF_BC9A_15EF886A466D__INCLUDED_)
