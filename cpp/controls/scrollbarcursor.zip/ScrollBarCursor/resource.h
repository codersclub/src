//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ScrollBarCursor.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SCROLLTYPE                  129
#define IDC_VSCROLLBAR                  130
#define IDC_VTHUMBTRACK                 132
#define IDC_VPAGEDOWN                   136
#define IDC_VLINEUP                     137
#define IDC_VLINEDOWN                   138
#define IDI_ICON1                       141
#define IDC_VPAGEUP                     143
#define IDC_VLINEDOWN_DISABLE           144
#define IDC_VLINEUP_DISABLE             145
#define IDC_HTHUMBTRACK                 146
#define IDC_HSCROLLBAR                  147
#define IDC_HPAGEUP                     148
#define IDC_HPAGEDOWN                   149
#define IDC_HLINEUP_DISABLE             150
#define IDC_HLINEUP                     151
#define IDC_HLINEDOWN_DISABLE           152
#define IDC_HLINEDOWN                   153

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        155
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
