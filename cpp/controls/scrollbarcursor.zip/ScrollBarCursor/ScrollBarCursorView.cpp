// ScrollBarCursorView.cpp : implementation of the CScrollBarCursorView class
//

#include "stdafx.h"
#include "ScrollBarCursor.h"

#include "ScrollBarCursorDoc.h"
#include "ScrollBarCursorView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorView

IMPLEMENT_DYNCREATE(CScrollBarCursorView, CEditView)

BEGIN_MESSAGE_MAP(CScrollBarCursorView, CEditView)
	//{{AFX_MSG_MAP(CScrollBarCursorView)
	ON_WM_VSCROLL()
	ON_WM_SETCURSOR()
	ON_WM_HSCROLL()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorView construction/destruction

CScrollBarCursorView::CScrollBarCursorView()
{
	m_nVIDResource = 0;
	m_nHIDResource = 0;
}

CScrollBarCursorView::~CScrollBarCursorView()
{
}

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorView drawing

void CScrollBarCursorView::OnDraw(CDC* pDC)
{
	CScrollBarCursorDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorView diagnostics

#ifdef _DEBUG
void CScrollBarCursorView::AssertValid() const
{
	CEditView::AssertValid();
}

void CScrollBarCursorView::Dump(CDumpContext& dc) const
{
	CEditView::Dump(dc);
}

CScrollBarCursorDoc* CScrollBarCursorView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CScrollBarCursorDoc)));
	return (CScrollBarCursorDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorView message handlers

void CScrollBarCursorView::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	switch (nSBCode) {
	case SB_THUMBTRACK://Drag scroll box to specified position
		if(m_nVIDResource != IDC_VTHUMBTRACK)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_VTHUMBTRACK));
			m_nVIDResource = IDC_VTHUMBTRACK;
		}
		break;
	case SB_LINEDOWN://Scroll one line down
		if(GetScrollPos(SB_VERT) == GetScrollLimit(SB_VERT))
		{
			if(m_nVIDResource != IDC_VLINEDOWN_DISABLE)
			{
				SetCursor(AfxGetApp()->LoadCursor(IDC_VLINEDOWN_DISABLE));
				m_nVIDResource = IDC_VLINEDOWN_DISABLE;
			}
		}
		else if(m_nVIDResource != IDC_VLINEDOWN)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_VLINEDOWN));
			m_nVIDResource = IDC_VLINEDOWN;
		}
		break;
	case SB_LINEUP://Scroll one line up
	    SCROLLINFO  info;
		info.cbSize = sizeof(SCROLLINFO);
		GetScrollInfo(SB_VERT, &info);
		if(info.nPos == info.nMin)
		{
			if(m_nVIDResource != IDC_VLINEUP_DISABLE)
			{
				SetCursor(AfxGetApp()->LoadCursor(IDC_VLINEUP_DISABLE));
				m_nVIDResource = IDC_VLINEUP_DISABLE;
			}
		}
		else if(m_nVIDResource != IDC_VLINEUP)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_VLINEUP));
			m_nVIDResource = IDC_VLINEUP;
		}
		break;
	case SB_PAGEDOWN://Scroll one page down
		if(m_nVIDResource != IDC_VPAGEDOWN)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_VPAGEDOWN));
			m_nVIDResource = IDC_VPAGEDOWN;
		}
		break;
	case SB_PAGEUP://Scroll one page up
		if(m_nVIDResource != IDC_VPAGEUP)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_VPAGEUP));
			m_nVIDResource = IDC_VPAGEUP;
		}
		break;
	}

	CEditView::OnVScroll(nSBCode, nPos, pScrollBar);
}

BOOL CScrollBarCursorView::OnSetCursor(CWnd* pWnd, UINT nHitTest, UINT message) 
{
	if(nHitTest == HTVSCROLL)
	{
		//Ghange cursor on the horizontal scroll bar
		SetCursor(AfxGetApp()->LoadCursor(IDC_VSCROLLBAR));
		if(m_nVIDResource != IDC_VSCROLLBAR)
			m_nVIDResource = IDC_VSCROLLBAR;
		return true;
	}
	else if(nHitTest == HTHSCROLL)
	{
		//Ghange cursor on the vertical scroll bar
		SetCursor(AfxGetApp()->LoadCursor(IDC_HSCROLLBAR));
		if(m_nHIDResource != IDC_HSCROLLBAR)
			m_nHIDResource = IDC_HSCROLLBAR;
		return true;
	}
	else
	{
		if(m_nVIDResource != 0)	m_nVIDResource = 0;
		if(m_nHIDResource != 0) m_nHIDResource = 0;
	}
		
	return CEditView::OnSetCursor(pWnd, nHitTest, message);
}

void CScrollBarCursorView::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	switch (nSBCode) {
	case SB_THUMBTRACK://Drag scroll box to specified position
		if(m_nHIDResource != IDC_HTHUMBTRACK)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_HTHUMBTRACK));
			m_nHIDResource = IDC_HTHUMBTRACK;
		}
		break;
	case SB_LINEDOWN://Scroll one line down
		if(GetScrollPos(SB_HORZ) == GetScrollLimit(SB_HORZ))
		{
			if(m_nHIDResource != IDC_HLINEDOWN_DISABLE)
			{
				SetCursor(AfxGetApp()->LoadCursor(IDC_HLINEDOWN_DISABLE));
				m_nHIDResource = IDC_HLINEDOWN_DISABLE;
			}
		}
		else if(m_nHIDResource != IDC_HLINEDOWN)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_HLINEDOWN));
			m_nHIDResource = IDC_HLINEDOWN;
		}
		break;
	case SB_LINEUP://Scroll one line up
	    SCROLLINFO  info;
		info.cbSize = sizeof(SCROLLINFO);
		GetScrollInfo(SB_HORZ, &info);
		if(info.nPos == info.nMin)
		{
			if(m_nHIDResource != IDC_HLINEUP_DISABLE)
			{
				SetCursor(AfxGetApp()->LoadCursor(IDC_HLINEUP_DISABLE));
				m_nHIDResource = IDC_HLINEUP_DISABLE;
			}
		}
		else if(m_nHIDResource != IDC_HLINEUP)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_HLINEUP));
			m_nHIDResource = IDC_HLINEUP;
		}
		break;
	case SB_PAGEDOWN://Scroll one page down
		if(m_nHIDResource != IDC_HPAGEDOWN)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_HPAGEDOWN));
			m_nHIDResource = IDC_HPAGEDOWN;
		}
		break;
	case SB_PAGEUP://Scroll one page up
		if(m_nHIDResource != IDC_HPAGEUP)
		{
			SetCursor(AfxGetApp()->LoadCursor(IDC_HPAGEUP));
			m_nHIDResource = IDC_HPAGEUP;
		}
		break;
	}
	
	CEditView::OnHScroll(nSBCode, nPos, pScrollBar);
}
