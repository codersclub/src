// ScrollBarCursor.h : main header file for the SCROLLBARCURSOR application
//

#if !defined(AFX_SCROLLBARCURSOR_H__26AFB80C_144D_4AC8_9290_2AB30D3374C5__INCLUDED_)
#define AFX_SCROLLBARCURSOR_H__26AFB80C_144D_4AC8_9290_2AB30D3374C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorApp:
// See ScrollBarCursor.cpp for the implementation of this class
//

class CScrollBarCursorApp : public CWinApp
{
public:
	CScrollBarCursorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CScrollBarCursorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CScrollBarCursorApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SCROLLBARCURSOR_H__26AFB80C_144D_4AC8_9290_2AB30D3374C5__INCLUDED_)
