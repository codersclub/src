// ScrollBarCursorDoc.cpp : implementation of the CScrollBarCursorDoc class
//

#include "stdafx.h"
#include "ScrollBarCursor.h"

#include "ScrollBarCursorDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorDoc

IMPLEMENT_DYNCREATE(CScrollBarCursorDoc, CDocument)

BEGIN_MESSAGE_MAP(CScrollBarCursorDoc, CDocument)
	//{{AFX_MSG_MAP(CScrollBarCursorDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorDoc construction/destruction

CScrollBarCursorDoc::CScrollBarCursorDoc()
{
	// TODO: add one-time construction code here

}

CScrollBarCursorDoc::~CScrollBarCursorDoc()
{
}

BOOL CScrollBarCursorDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	((CEditView*)m_viewList.GetHead())->SetWindowText(NULL);

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorDoc serialization

void CScrollBarCursorDoc::Serialize(CArchive& ar)
{
	// CEditView contains an edit control which handles all serialization
	((CEditView*)m_viewList.GetHead())->SerializeRaw(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorDoc diagnostics

#ifdef _DEBUG
void CScrollBarCursorDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CScrollBarCursorDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CScrollBarCursorDoc commands
