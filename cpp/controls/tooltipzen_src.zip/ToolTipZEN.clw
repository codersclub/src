; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CToolTipZENDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ToolTipZEN.h"

ClassCount=2
Class1=CToolTipZENApp
Class2=CToolTipZENDlg

ResourceCount=4
Resource2=IDR_MAINFRAME
Resource3=IDD_TOOLTIPZEN_DIALOG
Resource4=IDD_TOOLTIPZEN_DIALOG (English (U.S.))

[CLS:CToolTipZENApp]
Type=0
HeaderFile=ToolTipZEN.h
ImplementationFile=ToolTipZEN.cpp
Filter=N

[CLS:CToolTipZENDlg]
Type=0
HeaderFile=ToolTipZENDlg.h
ImplementationFile=ToolTipZENDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_EDIT1



[DLG:IDD_TOOLTIPZEN_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CToolTipZENDlg

[DLG:IDD_TOOLTIPZEN_DIALOG (English (U.S.))]
Type=1
Class=CToolTipZENDlg
ControlCount=6
Control1=IDC_EDIT1,edit,1350639616
Control2=IDC_EDIT2,edit,1350639616
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_EDIT3,edit,1350631424
Control6=IDC_STATIC,static,1342308352

