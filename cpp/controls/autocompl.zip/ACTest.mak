# Microsoft Developer Studio Generated NMAKE File, Based on ACTest.dsp
!IF "$(CFG)" == ""
CFG=ACTest - Win32 Debug
!MESSAGE No configuration specified. Defaulting to ACTest - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "ACTest - Win32 Release" && "$(CFG)" != "ACTest - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "ACTest.mak" CFG="ACTest - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ACTest - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "ACTest - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "ACTest - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\ACTest.exe"


CLEAN :
	-@erase "$(INTDIR)\ACTest.obj"
	-@erase "$(INTDIR)\ACTest.pch"
	-@erase "$(INTDIR)\ACTest.res"
	-@erase "$(INTDIR)\AutoCompl.obj"
	-@erase "$(INTDIR)\StatLink.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\Subclass.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\ACTest.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\ACTest.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\ACTest.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ACTest.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\ACTest.pdb" /machine:I386 /out:"$(OUTDIR)\ACTest.exe" 
LINK32_OBJS= \
	"$(INTDIR)\ACTest.obj" \
	"$(INTDIR)\StatLink.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\ACTest.res" \
	"$(INTDIR)\Subclass.obj" \
	"$(INTDIR)\AutoCompl.obj"

"$(OUTDIR)\ACTest.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "ACTest - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\ACTest.exe"


CLEAN :
	-@erase "$(INTDIR)\ACTest.obj"
	-@erase "$(INTDIR)\ACTest.pch"
	-@erase "$(INTDIR)\ACTest.res"
	-@erase "$(INTDIR)\AutoCompl.obj"
	-@erase "$(INTDIR)\StatLink.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\Subclass.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\ACTest.exe"
	-@erase "$(OUTDIR)\ACTest.ilk"
	-@erase "$(OUTDIR)\ACTest.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\ACTest.pch" /Yu"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\ACTest.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\ACTest.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\ACTest.pdb" /debug /machine:I386 /out:"$(OUTDIR)\ACTest.exe" /pdbtype:sept 
LINK32_OBJS= \
	"$(INTDIR)\ACTest.obj" \
	"$(INTDIR)\StatLink.obj" \
	"$(INTDIR)\StdAfx.obj" \
	"$(INTDIR)\ACTest.res" \
	"$(INTDIR)\Subclass.obj" \
	"$(INTDIR)\AutoCompl.obj"

"$(OUTDIR)\ACTest.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("ACTest.dep")
!INCLUDE "ACTest.dep"
!ELSE 
!MESSAGE Warning: cannot find "ACTest.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "ACTest - Win32 Release" || "$(CFG)" == "ACTest - Win32 Debug"
SOURCE=.\ACTest.cpp

"$(INTDIR)\ACTest.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\ACTest.pch"


SOURCE=.\ACTest.rc

"$(INTDIR)\ACTest.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)


SOURCE=.\AutoCompl.cpp

"$(INTDIR)\AutoCompl.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\ACTest.pch"


SOURCE=.\StatLink.cpp

"$(INTDIR)\StatLink.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\ACTest.pch"


SOURCE=.\StdAfx.cpp

!IF  "$(CFG)" == "ACTest - Win32 Release"

CPP_SWITCHES=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\ACTest.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ACTest.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ELSEIF  "$(CFG)" == "ACTest - Win32 Debug"

CPP_SWITCHES=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)\ACTest.pch" /Yc"stdafx.h" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /GZ /c 

"$(INTDIR)\StdAfx.obj"	"$(INTDIR)\ACTest.pch" : $(SOURCE) "$(INTDIR)"
	$(CPP) @<<
  $(CPP_SWITCHES) $(SOURCE)
<<


!ENDIF 

SOURCE=.\Subclass.cpp

"$(INTDIR)\Subclass.obj" : $(SOURCE) "$(INTDIR)" "$(INTDIR)\ACTest.pch"



!ENDIF 

