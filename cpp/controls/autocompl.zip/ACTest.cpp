////////////////////////////////////////////////////////////////
// MSDN -- August 2000
// If this code works, it was written by Paul DiLascia.
// If not, I don't know who wrote it.
// Compiles with Visual C++ 6.0, runs on Windows 98 and probably NT too.
//
#include "stdafx.h"
#include "resource.h"
#include "TraceWin.h"
#include "StatLink.h"
#include "AutoCompl.h"
 
#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

////////////////
// Test dialog to test auto-complete feature
//
class CMyDialog : public CDialog {
public:
	CMyDialog(CWnd* pParent = NULL);	// standard constructor
protected:
	CAutoComplete m_acEdit;				 // hook for edit box
	CAutoComplete m_acCombo;			 // hook for combo box
	virtual BOOL OnInitDialog();			 // MFC override

	// non-related stuff:
	HICON m_hIcon;
	CStaticLink	m_wndLink1;
	CStaticLink	m_wndLink2;
	DECLARE_MESSAGE_MAP()
};

//////////////////
// typicial app
class CMyApp : public CWinApp {
public:
	virtual BOOL InitInstance();
} theApp;

//////////////////
// init application instance: run dialog and quit
//
BOOL CMyApp::InitInstance()
{
	CMyDialog dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();
	return FALSE;
}

//////////////////
// Dialog constructor: set icon
//
CMyDialog::CMyDialog(CWnd* pParent) : CDialog(IDD_MYDIALOG, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

BEGIN_MESSAGE_MAP(CMyDialog, CDialog)
END_MESSAGE_MAP()

//////////////////
// Initialize dialog: add some strings to the auto-complete hooker
//
BOOL CMyDialog::OnInitDialog()
{
	CDialog::OnInitDialog();

	// initialize auto-complete controls
	m_acCombo.Init(GetDlgItem(IDC_COMBO1));
	m_acEdit.Init(GetDlgItem(IDC_EDIT1));
	static LPCTSTR STRINGS[] = {
		"alpha",
		"alphabet",
		"alphabet soup",
		"beta",
		"beta blocker",
		"beta carotine",
		"beta test",
		"one",
		"one of six",
		"one two",
		"one two three",
		NULL
	};
	for (int i=0; STRINGS[i]; i++) {
		m_acCombo.GetStringList().Add(STRINGS[i]);
		m_acEdit.GetStringList().Add(STRINGS[i]);
	}

	// set focus to edit control
	GetDlgItem(IDC_EDIT1)->SetFocus();

	// unrelated hyperlink stuff:
	m_wndLink1.m_link = _T("http://www.dilascia.com");
	m_wndLink2.m_link = _T("http://msdn.microsoft.com/msdnmag");
	m_wndLink1.SubclassDlgItem(IDC_PDURL, this);
	m_wndLink2.SubclassDlgItem(IDC_MSDNURL, this);

	// Set the icon for this dialog.  The framework does this automatically
	// when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	return FALSE;  // because I set the focus
}
