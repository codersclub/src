// TreeListCtrlDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TreeListCtrlDemo.h"
#include "TreeListCtrlDemoDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeListCtrlDemoDlg dialog

CTreeListCtrlDemoDlg::CTreeListCtrlDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTreeListCtrlDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTreeListCtrlDemoDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTreeListCtrlDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTreeListCtrlDemoDlg)
	DDX_Control(pDX, IDC_TREE, m_tree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTreeListCtrlDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CTreeListCtrlDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTreeListCtrlDemoDlg message handlers

BOOL CTreeListCtrlDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Step one: Window creation (if not subclassed via DDX_Control).
	/*
	m_tree.Create
		(
		WS_BORDER | WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_SINGLESEL | LVS_SHOWSELALWAYS, 
		CRect(12, 12, 288, 228), 
		this, 
		0x100
		);
	//*/

	// Step two: We insert two columns: Folder name, and folder size
	LVCOLUMN	column;

	column.mask		= LVCF_FMT | LVCF_TEXT | LVCF_WIDTH;

	column.fmt		= LVCFMT_LEFT;
	column.cx		= 200;
	column.pszText	= _T("Folder");
	column.iSubItem	= 0;

	m_tree.InsertColumn(0, &column);

	column.fmt		= LVCFMT_RIGHT;
	column.cx		= 75;
	column.pszText	= _T("Size");
	column.iSubItem	= 1;
	m_tree.InsertColumn(1, &column);

	// Step three: We create and set the image list 

	m_il.Create(IDB_FOLDERS, 16, 1, RGB(255, 0, 255));
	m_tree.SetImageList(&m_il, LVSIL_SMALL);


	// Step four:	we insert the tree contents.
	//				The information in the arrays asFolders, asSizes and anLevels
	//				should be obtained as a result of a "process": selecting a
	//				group of records, checking the hard disk, etc.

	CString		asFolders[] = 
					{ 
					"C:", "Program Files", "Microsoft Office", "Microsoft Visual Studio", 
					"InstallShield", "Winnt", "profiles", "All Users", "Administrator" , 
					"system32"
					};

	CString		asSizes[]	= { "100", "60", "10", "20", "30", "40", "5", "2", "1" , "35"};
	int			anLevels[]	= { 0, 1, 2, 2, 2, 1, 2, 3, 3, 2 };

	for (int i = 0; i < sizeof(asFolders) / sizeof(asFolders[0]); i++)
	{
		int iItem;
		iItem = m_tree.AddItem(asFolders[i], i % 3, anLevels[i]);
		m_tree.SetItemText(iItem, 1, asSizes[i]);
	}	

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTreeListCtrlDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTreeListCtrlDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CTreeListCtrlDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
