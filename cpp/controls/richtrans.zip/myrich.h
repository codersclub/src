// myrich.h : main header file for the MYRICH application
//

#if !defined(AFX_MYRICH_H__12180464_4368_11D3_8298_000021414BAE__INCLUDED_)
#define AFX_MYRICH_H__12180464_4368_11D3_8298_000021414BAE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CMyrichApp:
// See myrich.cpp for the implementation of this class
//

class CMyrichApp : public CWinApp
{
public:
	CMyrichApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyrichApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CMyrichApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYRICH_H__12180464_4368_11D3_8298_000021414BAE__INCLUDED_)
