// myrich.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "myrich.h"
#include "myrichDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


HINSTANCE   g_hInstRichEdit = NULL;


/////////////////////////////////////////////////////////////////////////////
// CMyrichApp

BEGIN_MESSAGE_MAP(CMyrichApp, CWinApp)
	//{{AFX_MSG_MAP(CMyrichApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyrichApp construction

CMyrichApp::CMyrichApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CMyrichApp object

CMyrichApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CMyrichApp initialization

BOOL CMyrichApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

/*	g_hInstRichEdit = LoadLibrary(TEXT("RICHED32.DLL"));
    if (!g_hInstRichEdit)
    {
        AfxMessageBox("Can't load dll");
        return (FALSE);
    }
*/

	CMyrichDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
