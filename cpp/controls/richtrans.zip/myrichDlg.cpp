// myrichDlg.cpp : implementation file
//

#include "stdafx.h"
#include "myrich.h"
#include "myrichDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CRect rect;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyrichDlg dialog

CMyrichDlg::CMyrichDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CMyrichDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CMyrichDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMyrichDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CMyrichDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CMyrichDlg, CDialog)
	//{{AFX_MSG_MAP(CMyrichDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	
	ON_NOTIFY(EN_MSGFILTER, IDC_RICH, OnMsgfilterRich)
	ON_WM_ERASEBKGND()
	
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyrichDlg message handlers

BOOL CMyrichDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here

//	create	one crich edit control
	rect.SetRect(10,10,150,50);
	m_OldRich.Create(ES_NOHIDESEL| ES_AUTOVSCROLL|WS_VSCROLL|WS_BORDER|WS_CHILD|WS_VISIBLE|ES_MULTILINE|WS_TABSTOP, rect, this, IDC_OLD);
	m_OldRich.SetBackgroundColor(FALSE, RGB(255,193,50));
	
//create the second transparent rich control
	rect.SetRect(10,60,150,140);
	m_Rich.CreateEx(WS_EX_TRANSPARENT, "RICHEDIT20A", "",
					ES_NOHIDESEL|WS_CHILD|WS_VISIBLE|
					ES_MULTILINE| ES_AUTOVSCROLL|
					WS_BORDER|WS_VSCROLL|WS_TABSTOP, rect, this, IDC_RICH, NULL);
	
//create the brush for second rich	
	m_pat.LoadBitmap(MAKEINTRESOURCE(IDB_PAT));
	myBrush.CreatePatternBrush(&m_pat);

//without this function you woun't catch the messages
	::SendMessage(m_Rich, EM_SETEVENTMASK, 0, ENM_MOUSEEVENTS|ENM_SCROLLEVENTS|ENM_KEYEVENTS);
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CMyrichDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CMyrichDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CMyrichDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}




CMyrichDlg::OnEraseBkgnd(CDC * pDC)
{
	CDialog::OnEraseBkgnd(pDC);
	rect.SetRect(10,60,150,140);
	pDC->FillRect(rect, &myBrush);
	return TRUE;
}


//function for catching the mouse 

void CMyrichDlg::OnMsgfilterRich(NMHDR* pNMHDR, LRESULT* pResult)
{
	MSGFILTER *pMsgFilter = reinterpret_cast<MSGFILTER *>(pNMHDR);

	if((pMsgFilter->msg==WM_VSCROLL || pMsgFilter->msg==WM_KEYDOWN))
	{
		rect.SetRect(10,60,150,140);
		InvalidateRect(&rect);
	}

	if(pMsgFilter->msg==WM_RBUTTONUP)//for right mouse click
	{
		AfxMessageBox("Click!");
	}

	*pResult = 0;
}