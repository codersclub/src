// RichEditCtrlEx.cpp : implementation file
//

#include "stdafx.h"
#include "myrich.h"
#include "RichEditCtrlEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

_AFX_RICHEDITEX_STATE::_AFX_RICHEDITEX_STATE()
{
    m_hInstRichEdit20 = NULL ;
}



_AFX_RICHEDITEX_STATE::~_AFX_RICHEDITEX_STATE()
{
    if( m_hInstRichEdit20 != NULL )
    {
        ::FreeLibrary( m_hInstRichEdit20 ) ;
    }
}



_AFX_RICHEDITEX_STATE _afxRichEditStateEx ;



BOOL PASCAL AfxInitRichEditEx()
{
    if( ! ::AfxInitRichEdit() )
    {
        return FALSE ;
    }
    _AFX_RICHEDITEX_STATE* l_pState = &_afxRichEditStateEx ;
    if( l_pState->m_hInstRichEdit20 == NULL )
    {
        l_pState->m_hInstRichEdit20 = LoadLibraryA("RICHED20.DLL") ;
    }
    return l_pState->m_hInstRichEdit20 != NULL ;
}
/////////////////////////////////////////////////////////////////////////////
// CRichEditCtrlEx

CRichEditCtrlEx::CRichEditCtrlEx()
{
}

CRichEditCtrlEx::~CRichEditCtrlEx()
{
}


BEGIN_MESSAGE_MAP(CRichEditCtrlEx, CRichEditCtrl)
	//{{AFX_MSG_MAP(CRichEditCtrlEx)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CRichEditCtrlEx message handlers
BOOL CRichEditCtrlEx::Create(DWORD in_dwStyle,  const RECT& in_rcRect,
                             CWnd* in_pParentWnd, UINT in_nID)
{
    if( ! ::AfxInitRichEditEx() )
    {
        return FALSE ;
    }
    CWnd* l_pWnd = this ;
    return l_pWnd->Create( _T( "RichEdit20A" ), NULL, in_dwStyle, 
                           in_rcRect, in_pParentWnd, in_nID );
}

BOOL CRichEditCtrlEx::CreateEx(DWORD dwExStyle, LPCTSTR lpszClassName,
		LPCTSTR lpszWindowName, DWORD dwStyle,
		const RECT& rect, CWnd* pParentWnd, UINT nID,
		LPVOID lpParam /* = NULL */)
{
/*	return CreateEx(dwExStyle, lpszClassName, lpszWindowName, dwStyle,
		rect,(pParentWnd != NULL) ? pParentWnd->GetSafeHwnd() : NULL,
		(HMENU) nID, lpParam);
*/
	CWnd* l_pWnd = this ;
    return l_pWnd->CreateEx(dwExStyle, _T( "RichEdit20A" ), NULL, dwStyle, 
                           rect, pParentWnd, nID, NULL );
}

