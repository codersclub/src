// myrichDlg.h : header file
//

#if !defined(AFX_MYRICHDLG_H__12180466_4368_11D3_8298_000021414BAE__INCLUDED_)
#define AFX_MYRICHDLG_H__12180466_4368_11D3_8298_000021414BAE__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000



#include "richeditctrlex.h"



/////////////////////////////////////////////////////////////////////////////
// CMyrichDlg dialog

class CMyrichDlg : public CDialog
{
// Construction
public:
	CMyrichDlg(CWnd* pParent = NULL);	// standard constructor
	BOOL OnEraseBkgnd(CDC* pDC);
	
// Dialog Data
	//{{AFX_DATA(CMyrichDlg)
	enum { IDD = IDD_MYRICH_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyrichDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CRichEditCtrlEx m_Rich;
	CRichEditCtrlEx	m_OldRich;
	CBitmap m_pat;
	CBrush myBrush;


	// Generated message map functions
	//{{AFX_MSG(CMyrichDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnMsgfilterRich(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYRICHDLG_H__12180466_4368_11D3_8298_000021414BAE__INCLUDED_)
