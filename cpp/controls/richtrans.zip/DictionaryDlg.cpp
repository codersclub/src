// DictionaryDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Dictionary.h"
#include "DictionaryDlg.h"
#include "windows.h"
#include "ddraw.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

//Globals
#define MAXTEXT 50

int dictLength, dictHeight;
int cxScreen, cyScreen;
long initx, inity;
CPoint init;
CDC * pCDC;
CRect crect,rect;
char buffer[100];
char glob;
CSize bitSize, bitSize_ro, bitSize_gr;
CPoint bitPt, bitPt_ro, bitPt_gr;
CWnd * pWnd;
TC_ITEM TabCtrlItem;
int lungime, lantet;
char *pbufer, *antet, *pbuf;
int w,h,W,H;
CWnd * pButton;
Ctopic * topica, * context, * prefix, * sufix, *tabactiv;
Csearch *cautare;
int nr_topica, nr_context, nr_prefix, nr_sufix, nractiv, nr_struct;
CFile f;	
CFont font;
CHARFORMAT2 cfr;
CString find, input, title, oldinput;
BOOL first, last, right_is_big, flg_search=FALSE;
int contor_text=0;
long car_current, car_activ, last_find=-1;
int old_topic=-1;
BOOL bIsMoving;
CBrush myBrush, oldBrush, m_HollowBrush, m_BrushPat2, m_BrushPat3;
BITMAP grstruct, rostruct;
typedef struct
{
	int contor_text;
	long car_current;
	long car_activ;
	int old_topic;
	long last_find;
}CStackSearch;

CStackSearch stiva[100];
int index_stiva=-1;
DDSURFACEDESC		iDDSurfaceDesc;
LPDIRECTDRAW        lpDD;
LPDIRECTDRAW2       lpDD2;

/////////////////////////////////////////////////////////////////////////////
// CDictionaryDlg dialog

CDictionaryDlg::CDictionaryDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDictionaryDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDictionaryDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_DICT);
}

void CDictionaryDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDictionaryDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CDictionaryDlg, CDialog)
	//{{AFX_MSG_MAP(CDictionaryDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BUTONHELP, OnHelp)
	ON_BN_CLICKED(IDC_BUTONABOUT, OnAbout)
	ON_BN_CLICKED(IDC_BUTONCLOSE, OnClose)
	ON_WM_QUERYDRAGICON()
	ON_NOTIFY(TCN_SELCHANGE, IDC_TAB, OnSelchangeTab)
	ON_NOTIFY(EN_MSGFILTER, IDC_LEFT, OnMsgfilterLeft)
	ON_NOTIFY(EN_MSGFILTER, IDC_RIGHT, OnMsgfilterRight)
	ON_NOTIFY(EN_MSGFILTER, IDC_TOP, OnMsgfilterTop)
	ON_NOTIFY(EN_MSGFILTER, IDC_TAB, OnMsgfilterTab)
	ON_BN_CLICKED(IDC_BUTON, OnSwitch)
	ON_BN_CLICKED(IDC_SEARCHB, On_Search)
//	ON_EN_VSCROLL(IDC_LEFT, OnVscrollLeft)
//	ON_EN_VSCROLL(IDC_RIGHT, OnVscrollRight)
	ON_WM_LBUTTONDOWN()
	ON_WM_MOUSEMOVE()
	ON_WM_CHAR()
	ON_WM_ERASEBKGND()
	ON_WM_CTLCOLOR()
	ON_COMMAND(ID_BACK, OnBack)
	ON_COMMAND(ID_CLOSE, OnClose)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDictionaryDlg message handlers


BOOL CDictionaryDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	HRESULT        ddrval;
	LPDIRECTDRAW   lpDD;

	m_hAccel = LoadAccelerators(AfxGetInstanceHandle(), 
    MAKEINTRESOURCE(IDR_ACCELERATOR1));	

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
//	set the new size of dialog in crect
	this->GetClientRect(&crect);
	cxScreen=GetSystemMetrics(SM_CXSCREEN);
	cyScreen=GetSystemMetrics(SM_CYSCREEN);
	dictLength=crect.Width();
	dictHeight=crect.Height();
	if(dictLength!=559&&dictHeight!=282)
	{
		dictLength=559;
		dictHeight=282;
	}
	this->SetWindowPos(NULL,(cxScreen-dictLength)/2,(cyScreen-dictHeight)/2,dictLength,dictHeight,SWP_SHOWWINDOW);

//	set the icon
	this->GetClientRect(&rect);
	rect.SetRect(0,0,32,32);
	m_hIcon=LoadIcon(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDR_DICT));
	InvalidateRect(&rect);

//	set the title
	BITMAP bmstruct;
	if(m_Bitmap.LoadBitmap(MAKEINTRESOURCE(IDB_TITLE)))
	{
		m_hBitmap=LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_TITLE));
		m_Bitmap.GetBitmap(&bmstruct);
		bitPt.x=(dictLength-bmstruct.bmWidth-120)/2;
		bitPt.y=bmstruct.bmHeight;
		bitPt.y=3;
		rect.SetRect(bitPt.x,bitPt.y,bmstruct.bmWidth,bmstruct.bmHeight);
		InvalidateRect(&rect);
	}

//set the font for buttons
	font.DeleteObject();
	LOGFONT lf;
	 lf.lfHeight         = -15 ;
     lf.lfWidth          = 0 ;
     lf.lfEscapement     = 0 ;
     lf.lfOrientation    = 0 ;
     lf.lfWeight         = 700;//iAttributes & EZ_ATTR_BOLD      ? 700 : 0 ;
     lf.lfItalic         = 0;//iAttributes & EZ_ATTR_ITALIC    ?   1 : 0 ;
     lf.lfUnderline      = 0;//iAttributes & EZ_ATTR_UNDERLINE ?   1 : 0 ;
     lf.lfStrikeOut      = 0;//iAttributes & EZ_ATTR_STRIKEOUT ?   1 : 0 ;
     lf.lfCharSet        = 0 ;
     lf.lfOutPrecision   = 0 ;
     lf.lfClipPrecision  = 0 ;
     lf.lfQuality        = 0 ;
     lf.lfPitchAndFamily = 0 ;
     strcpy (lf.lfFaceName, "arial") ;
	 font.CreateFontIndirect(&lf);


//	set the buttons:
	rect.SetRect(dictLength-25,0,dictLength-5,20);
	m_closeButton.Create(NULL, WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_ICON, rect, this, IDC_BUTONCLOSE);
	
	rect.SetRect(dictLength-75,0,dictLength-25,20);
	m_aboutButton.Create(NULL, WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_BITMAP, rect, this, IDC_BUTONABOUT);
//	m_aboutButton.SetFont(&font, TRUE);
//	m_aboutButton.SetWindowText("Help");

	rect.SetRect(dictLength-125,0,dictLength-75,20);
	m_helpButton.Create(NULL, WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON|BS_BITMAP, rect, this, IDC_BUTONHELP);

/*	CFont *Font1 = GetDlgItem(IDC_BUTONHELP)->GetFont();
	LOGFONT LogFont;
	Font1->GetLogFont(&LogFont);
	LogFont.lfHeight = 12;
	LogFont.lfWidth = 8;
	lstrcpy (LogFont.lfFaceName, "Times");
	CFont * Font2;
	Font2->CreateFontIndirect(&LogFont);
	GetDlgItem(IDC_BUTONHELP)->SetFont(Font2);
	m_aboutButton.SetWindowText("Help");
*/
	 	 
	m_hAbout = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_ABOUT)); 
	pButton = GetDlgItem(IDC_BUTONABOUT); 
	::SendMessage(pButton->m_hWnd, BM_SETIMAGE, IMAGE_BITMAP, (WPARAM)m_hAbout); 

	m_hHelp = ::LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_HELP)); 
	pButton = GetDlgItem(IDC_BUTONHELP); 
	::SendMessage(pButton->m_hWnd, BM_SETIMAGE, IMAGE_BITMAP, (WPARAM)m_hHelp); 

	m_hIconClose = ::LoadIcon(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDI_CLOSE)); 
	pButton = GetDlgItem(IDC_BUTONCLOSE); 
	::SendMessage(pButton->m_hWnd, BM_SETIMAGE, IMAGE_ICON, (WPARAM)m_hIconClose); 

//set ControlTab
	CSize newSize(50,20);
	rect.SetRect(-1,22,dictLength,46/*dictHeight*/);
	m_Tab.Create(WS_CHILD|WS_VISIBLE|WS_TABSTOP|WS_EX_TRANSPARENT, rect, this, IDC_TAB);
	TabCtrlItem.mask = TCIF_IMAGE;
	m_hList.Create(IDB_LIST,61,0,NULL);
	for (int i=0; i<7; i++)
	{
		TabCtrlItem.iImage=i;
		m_Tab.InsertItem(i,&TabCtrlItem);
	}
	m_Tab.SetImageList(&m_hList);
//	m_Tab.SetItemSize(newSize);

	m_Bmp.LoadBitmap(MAKEINTRESOURCE(IDB_PAT));
	VERIFY(m_HollowBrush.CreateStockObject(HOLLOW_BRUSH));

//	set the top richedit
	rect.SetRect(105, 51, dictLength-10, 71);
	m_Top.Create(ES_NOHIDESEL|WS_CHILD|WS_VISIBLE|ES_READONLY|ES_MULTILINE|WS_TABSTOP, rect, this, IDC_TOP);
	m_Top.SetFont(&font, TRUE);
   	m_Top.SetBackgroundColor(FALSE, RGB(192,192,192));
	
//	set the left richedit
	rect.SetRect(0,50,102,dictHeight-5);
	m_Left.CreateEx(WS_EX_TRANSPARENT, "RICHEDIT20A", "",
					ES_NOHIDESEL|WS_CHILD|WS_VISIBLE|ES_READONLY|
					ES_MULTILINE| ES_AUTOVSCROLL|
					WS_BORDER|WS_VSCROLL|WS_TABSTOP, rect, this, IDC_LEFT, NULL);
	         

/*	m_Left.Create(	ES_NOHIDESEL|WS_CHILD|WS_VISIBLE|ES_READONLY|
					ES_MULTILINE| ES_AUTOVSCROLL|
					WS_BORDER|WS_VSCROLL|WS_TABSTOP, rect, this, IDC_LEFT);
*/
	pCDC=this->GetDC();

//	set the right richedit
	rect.SetRect(102,70,dictLength-5,dictHeight-5);
	m_Right.CreateEx(WS_EX_TRANSPARENT, "RICHEDIT20A", "", 
					ES_NOHIDESEL| WS_CHILD|WS_VISIBLE|ES_READONLY|
					ES_MULTILINE | ES_AUTOVSCROLL |
					WS_BORDER | WS_VSCROLL | WS_TABSTOP , rect, this, IDC_RIGHT, NULL);

//	m_Right.SetBackgroundColor(FALSE,RGB(255,255,193));
	
//	set the subtitle
	BITMAP bmstr;
	if(m_Prefixe.LoadBitmap(MAKEINTRESOURCE(IDB_RAD1)))
	{
		m_hPrefixe=LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_RAD1));
		m_Prefixe.GetBitmap(&bmstr);
	}

	pt.x=140;pt.y=140;
	sz.cx=250;sz.cy=20;
	rect.SetRect(pt.x,pt.y,pt.x+sz.cx,pt.y+sz.cy);
//	m_Prefixe.LoadBitmap(IDB_RAD1);
//	m_hPrefixe=LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_RAD1));
//	m_Subtitle.Create(NULL, WS_CHILD|WS_VISIBLE, rect, GetDlgItem(IDC_TAB), IDC_SUBTITLE);
//	m_Subtitle.SetFont(&font, TRUE);
			
//	m_Left.SetBackgroundColor(FALSE,RGB(255,255,193));
	m_Pat2.LoadBitmap(MAKEINTRESOURCE(IDB_PAT2));
	m_Pat3.LoadBitmap(MAKEINTRESOURCE(IDB_PAT3));
	m_BrushPat2.CreatePatternBrush(&m_Pat2);
	m_BrushPat3.CreatePatternBrush(&m_Pat3);
	
	long newBrush = myBrush.CreatePatternBrush(&m_Bmp);
//	HWND lefthwnd=m_Left.GetSafeHwnd();
//	long s = SetClassLong(lefthwnd, GCL_HBRBACKGROUND, newBrush);
//	DeleteObject((HBRUSH)SetClassLong(lefthwnd, GCL_HBRBACKGROUND, (LONG)CreateSolidBrush(RGB(255,255,193))));
//	rect.SetRect(0,50,102,dictHeight-5);
//	::InvalidateRect(m_Left, &rect, TRUE);

	hMyCur=AfxGetApp()->LoadCursor(IDC_MYCUR);
	hMyCurTop=AfxGetApp()->LoadStandardCursor(IDC_ARROW);

//	load the bitmaps roman, greek

	if(m_Roman.LoadBitmap(MAKEINTRESOURCE(IDB_ROMAN)))
	{
		h_Roman=LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_ROMAN));
		m_Roman.GetBitmap(&rostruct);
		bitPt_ro.x=5;
		bitPt_ro.y=70;
		bitSize_ro.cy=rostruct.bmHeight;
		bitSize_ro.cx=rostruct.bmWidth;
	}
	if(m_Greek.LoadBitmap(MAKEINTRESOURCE(IDB_GREEK)))
	{
		h_Greek=LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_GREEK));
		m_Greek.GetBitmap(&grstruct);
		bitPt_gr.x=5;
		bitPt_gr.y=70;
		bitSize_gr.cy=grstruct.bmHeight;
		bitSize_gr.cx=grstruct.bmWidth;
	}

//	FlyOver
	m_tool.Create(this); 
	m_tool.AddTool(GetDlgItem(IDC_BUTONABOUT),"About"); 
	m_tool.AddTool(GetDlgItem(IDC_BUTONCLOSE),"Close"); 
	m_tool.AddTool(GetDlgItem(IDC_BUTONHELP),"Help"); 
	m_tool.Activate(TRUE);

	CHARFORMAT2 cf;
	cf.yHeight=220;	//font x 20
	cf.dwMask=CFM_SIZE|CFM_BOLD|CFM_COLOR|CFM_FACE;
	cf.dwEffects=CFE_BOLD;
	cf.crTextColor=RGB(255,0,0);
	strcpy (cf.szFaceName, "arial") ;
	m_Left.SetDefaultCharFormat(cf);
	
	m_Right.GetDefaultCharFormat(cfr);
	cfr.yHeight=160; //font x 20
	cfr.dwMask=cfr.dwMask|CFM_SIZE|CFM_BOLD|CFM_FACE;
	cfr.dwEffects=CFE_BOLD;
	strcpy (cfr.szFaceName, "arial") ;
	m_Right.SetDefaultCharFormat(cfr);
	m_Right.GetDefaultCharFormat(cfr);

//	m_Left.SetBackgroundColor(FALSE,RGB(255,255,0));
	::SendMessage(m_Left,  EM_SETEVENTMASK, 0,ENM_MOUSEEVENTS|ENM_SCROLLEVENTS|ENM_KEYEVENTS);
	::SendMessage(m_Right, EM_SETEVENTMASK, 0,ENM_SCROLLEVENTS|ENM_KEYEVENTS);
	::SendMessage(m_Top, EM_SETEVENTMASK, 0,ENM_MOUSEEVENTS);

	readTopic();//initializare tabele		
	readPS(&m_Left, prefix, nr_prefix);//afisare prefixe
	Invalidate();

	m_Top.EnableWindow(FALSE);
//	this->SetWindowPos(&wndTopMost, 1, 2, 3, 4, SWP_NOMOVE|SWP_NOSIZE|SWP_SHOWWINDOW);
    

	/*
     * create an IDirectDraw2 interface
     */


	ddrval = DirectDrawCreate( NULL, &lpDD, NULL );
    if( ddrval != DD_OK )
        return FALSE;
	
	iDDSurfaceDesc.dwSize = sizeof(DDSURFACEDESC);
    ddrval = lpDD->GetDisplayMode(&iDDSurfaceDesc);
	if( ddrval != DD_OK )
        return FALSE;
	DWORD h = iDDSurfaceDesc.dwHeight;
	DWORD w = iDDSurfaceDesc.dwWidth;
	DWORD c = iDDSurfaceDesc.ddpfPixelFormat.dwRGBBitCount;
	
	if(h!=480 || w!=640 || c!=8)
	{
		AfxMessageBox("This program requires 640x480 resolution and 256 colors");
	
/*		ddrval = lpDD->SetCooperativeLevel(m_hWnd, DDSCL_EXCLUSIVE|DDSCL_FULLSCREEN);
		if( ddrval != DD_OK )
			return FALSE;
	
		ddrval = lpDD->SetDisplayMode(640, 480, 8);//640x480, 256 clrs
		if( ddrval != DD_OK )
			return FALSE;

		ddrval = lpDD->SetCooperativeLevel(m_hWnd, DDSCL_NORMAL);
		if( ddrval != DD_OK )
			return FALSE;

		//recenter	
		cxScreen=GetSystemMetrics(SM_CXSCREEN);
		cyScreen=GetSystemMetrics(SM_CYSCREEN);
		dictLength=crect.Width();
		dictHeight=crect.Height();
		if(dictLength!=559&&dictHeight!=282)
		{
			dictLength=559;
			dictHeight=282;
		}
		this->SetWindowPos(NULL,(cxScreen-dictLength)/2,(cyScreen-dictHeight)/2,dictLength,dictHeight,SWP_SHOWWINDOW);
*/	}
	else return TRUE;
	return TRUE;
}


void read(pCRichEditCtrl m_ctrl, CString str)
{
	CFileException e;
	CFile file;
	int l;
	if(!file.Open(str, CFile::modeRead, &e))
		{
			file.Close();
			m_ctrl->SetWindowText("Eroare de deschidere");
		}
	else 
		{
			l=file.GetLength();
			lungime=l;
			pbuf = new char[l];
			for (int i=0; i<l; i++)
			{
				pbuf[i]=' ';
			}
			pbuf[l] ='\0';
			file.Read(pbuf,l);
			m_ctrl->SetWindowText(pbuf);
		}
}

void readPS(pCRichEditCtrl m_ctrl, Ctopic * ct, int nrtop)
{
	char * pchar;
	int i;
	tabactiv = ct;
	nractiv = nrtop;
	pbufer = new char[nrtop*MAXTEXT];
	for (i=0; i<nrtop*MAXTEXT; i++)
	{
			pbufer[i]=' ';
	}
	pbufer[nrtop*MAXTEXT] ='\0';
	for (i = 0, pchar=pbufer; i < nrtop; i++)
	{
		int j = sprintf(pchar,"%s\n", ct->nume);
		pchar=pbufer+strlen(pbufer);
		ct+=1;
	}
	sprintf(pchar, " \n");
	lungime = strlen(pbufer);
	m_ctrl->SetWindowText(pbufer);
}

void readRTF(CString str)
{
	CFileException e;
	CFile file;
	int l;
	char * pb;
	if(!file.Open(str, CFile::modeRead, &e))
		{
			file.Close();
			AfxMessageBox("Eroare de deschidere a fisierului");
		}
	else 
		{
			l=file.GetLength();
			lungime=l;
			pb = new char[l];
			for (int i=0; i<l; i++)
			{
				pb[i]=' ';
			}
			pb[l] ='\0';
			file.Read(pb,l);
		}
}


BOOL CDictionaryDlg::OnEraseBkgnd(CDC* pDC)
{
	int nColor;
	if(m_Tab)
	{
	nColor = m_Tab.GetCurSel();
	switch(nColor)
	{
		case 0:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Left)
			{
				m_Left.GetClientRect(rect);
				rect.SetRect(0,50,102,dictHeight-5);
				pDC->FillRect(rect, &m_BrushPat2);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
			}
			return TRUE;
		case 1:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			return TRUE;
		case 2:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			return TRUE;
		case 3:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Left)
			{
				m_Left.GetClientRect(rect);
				rect.SetRect(0,50,102,dictHeight-5);
				pDC->FillRect(rect, &m_BrushPat2);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
			}
			return TRUE;
		case 4:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			return TRUE;
		case 5:
			CDialog::OnEraseBkgnd(pDC);
			if(m_Right)
			{
				m_Right.GetClientRect(rect);
				rect.SetRect(105,73,dictLength-5,dictHeight-5);
				pDC->FillRect(rect, &myBrush);
				rect.SetRect(0, 0, dictLength-5, 25);
				pDC->FillRect(rect, &m_BrushPat3);
			}
			return TRUE;
		}
	if(m_Edit)
	{
		CDialog::OnEraseBkgnd(pDC);
		m_Right.GetClientRect(rect);
		rect.SetRect(105,73,dictLength-5,dictHeight-5);
		pDC->FillRect(rect, &myBrush);
		rect.SetRect(0, 0, dictLength-5, 25);
		pDC->FillRect(rect, &m_BrushPat3);
		return TRUE;
	}
	if(right_is_big)
	{
		CDialog::OnEraseBkgnd(pDC);
		m_Right.GetClientRect(rect);
		rect.SetRect(0,73,dictLength-5,dictHeight-5);
		pDC->FillRect(rect, &myBrush);
		rect.SetRect(0, 0, dictLength-5, 25);
		pDC->FillRect(rect, &m_BrushPat3);
		return TRUE;
	}
	}	
	return CWnd::OnEraseBkgnd(pDC);
}

void CDictionaryDlg::OnPaint() 
{
//	pWnd = GetDlgItem(IDC_RIGHT);
	CPaintDC dc(this); //device context for painting
//	CDC * pCDC, *pDC;
//	pCDC=pWnd->GetDC();
//	pDC=m_Left.GetDC();

//	rect.SetRect(0,50,102,dictHeight-5);
//	pDC->FillRect(rect, &myBrush);

	if (IsIconic())
	{
		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
		dc.DrawIcon(0,0,m_hIcon);
		dc.DrawState(bitPt, bitSize, m_Bitmap, DST_BITMAP|DSS_NORMAL, NULL);
//		rect.SetRect(0,0,dictLength-5, 57);
//		dc.FillRect(rect, &m_BrushPat3);
	}
}

HCURSOR CDictionaryDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CDictionaryDlg::OnSelchangeTab(NMHDR* pNMHDR, LRESULT* pResult) 
{
	int nColor = m_Tab.GetCurSel();
	CHARFORMAT2 cf;
	switch(nColor)
	{
		case 0:
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-5,dictHeight-5);
				right_is_big=FALSE;
			}
			if(m_Left)
			{
				m_Left.DestroyWindow();
				CtrlCreate(&m_Left);
			}
			else
				CtrlCreate(&m_Left);
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			cf.yHeight=220;	//font x 20
			cf.dwMask=CFM_SIZE|CFM_BOLD|CFM_COLOR|CFM_FACE;
			cf.dwEffects=CFE_BOLD;
			cf.crTextColor=RGB(255,0,0);
			strcpy (cf.szFaceName, "arial") ;
//			m_Left.SetBackgroundColor(FALSE,RGB(255,255,193));
			m_Left.SetDefaultCharFormat(cf);
			readPS(&m_Left, prefix, nr_prefix);
			rect.SetRect(140,40,390,60);
			m_Right.SetWindowText(" ");
			m_Top.SetWindowText(" ");
			InvalidateRect(&rect);
			break;
		case 1://latin root
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Left)
				m_Left.DestroyWindow();
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			AfisareContext("latin_roots");
			m_Right.LineScroll(-m_Right.GetLineCount(), 0);
			//draw image
			pWnd=this;
			rect.SetRect(bitPt_ro.x,bitPt_ro.y,bitPt_ro.x+rostruct.bmWidth,bitPt_ro.y+rostruct.bmHeight);
			m_Static_ro.Create(NULL, WS_CHILD|WS_VISIBLE|SS_BITMAP|SS_CENTERIMAGE, rect, pWnd);
			m_Static_ro.SetBitmap(h_Roman);
			break;
		case 2://greek roots
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Left)
				m_Left.DestroyWindow();
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			AfisareContext("greek_roots");
			m_Right.LineScroll(-m_Right.GetLineCount(), 0);
			//draw image
			//pWnd=GetDlgItem(IDC_TAB);
			pWnd=this;
			rect.SetRect(bitPt_gr.x,bitPt_gr.y,bitPt_gr.x+grstruct.bmWidth,bitPt_gr.y+grstruct.bmHeight);
			m_Static_gr.Create(NULL, WS_CHILD|WS_VISIBLE|SS_BITMAP|SS_CENTERIMAGE, rect, pWnd);
			m_Static_gr.SetBitmap(h_Greek);
			break;
		case 3://suffix
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Left)
			{
				m_Left.DestroyWindow();
				CtrlCreate(&m_Left);
			}
			else
				CtrlCreate(&m_Left);
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			cf.yHeight=220;	//font x 20
			cf.dwMask=CFM_SIZE|CFM_BOLD|CFM_COLOR|CFM_FACE;
			cf.dwEffects=CFE_BOLD;
			cf.crTextColor=RGB(255,0,0);
			strcpy (cf.szFaceName, "arial") ;
			m_Left.SetDefaultCharFormat(cf);
//			m_Left.SetBackgroundColor(FALSE, RGB(255,255,193));
			readPS(&m_Left, sufix, nr_sufix);
			m_hPrefixe=LoadBitmap(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDB_ERASE));
			rect.SetRect(140,40,390,60);
			m_Right.SetWindowText(" ");
			m_Top.SetWindowText(" ");
			InvalidateRect(&rect);
			break;
		case 4:
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Left)
				m_Left.DestroyWindow();
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			AfisareContext("misfits");
			m_Right.LineScroll(-m_Right.GetLineCount(), 0);
			break;
		case 5:
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Left)
				m_Left.DestroyWindow();
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			AfisareContext("confused");
			m_Right.LineScroll(-m_Right.GetLineCount(), 0);
			break;
		case 6:
			if(right_is_big)
			{
				m_Right.MoveWindow(102,70,dictLength-107,dictHeight-75);
				right_is_big=FALSE;
			}
			if(m_Static_ro)
				m_Static_ro.DestroyWindow();
			if(m_Static_gr)
				m_Static_gr.DestroyWindow();
			AfisRTF(" ", &m_Right);
			AfisRTF(" ", &m_Top);
			old_topic=-1;
			OnSwitch();
			flg_search=TRUE;
			if(m_Left)
				m_Left.DestroyWindow();
			if(!m_Result)
			{
				rect.SetRect(10,71,90,90);
				m_Result.Create(NULL,WS_CHILD|WS_VISIBLE|SS_SUNKEN|SS_CENTER,rect,this,IDC_REZ);
				m_Result.SetFont(&font, TRUE);
				m_Result.SetWindowText("Results:");
			}
			break;
	}

	*pResult = 0;
	Invalidate();
}


DWORD CALLBACK EditStreamCallBack(DWORD dwCookie, 
									LPBYTE pbBuff, //pointer la bufer de rw
									LONG cb, //nr de bytes rw
									LONG *pcb)//primeste nr de bytes rw
{
	int val;
	CString *pstr = (CString *)dwCookie;
	val = pstr->GetLength();
	if( val < cb )
	{
		*pcb = val;
		memcpy(pbBuff, (LPCSTR)*pstr, *pcb );
		pstr->Empty();
	}
	else
	{
		*pcb = cb;
		memcpy(	pbBuff, (LPCSTR)*pstr, *pcb ) ;
		*pstr = pstr->Right( val - cb ) ;
	}
	return 0;
}


DWORD CALLBACK EditStreamCallBackOut(DWORD dwCookie, 
									LPBYTE pbBuff, //pointer la bufer de rw
									LONG cb, //nr de bytes rw
									LONG *pcb)//primeste nr de bytes rw
{
	int val;
	CString *pstr = (CString *)dwCookie;
	val = strlen((const char*)pbBuff);
	{
		*pcb = val;
		*pstr = (LPCSTR)pbBuff;
	}
	return 0;
}


void CDictionaryDlg::AfisRTF(char * pchar, CRichEditCtrlEx * m_ctrl)
{
	CRect cr;
	CString stream=pchar;
	EDITSTREAM es;
	es.dwCookie=(DWORD)&stream;
	es.dwError=0;
	es.pfnCallback=EditStreamCallBack;
	m_ctrl->StreamIn(SF_RTF, es);
	Invalidate();
}

void CDictionaryDlg::On_Search()
{
/*	first = TRUE;
	contor_text = 0;
	AfisRTF(" ", &m_Left);

	if(m_Edit)
	{
		m_Edit.GetWindowText(input);
		AfxMessageBox(input);
	}
	else
		AfxMessageBox("type a word or a part of it");
	find = input;
*/
}



//Enter was hit
void CDictionaryDlg::OnOK()
{
BOOL nu_exista;
	do
	{
	if(first || last)
		contor_text=0;
	nu_exista=contor_text==0;
	for(; contor_text<nr_struct ;)
	{
		if(old_topic!=cautare[contor_text].nr_topica)
		{
			old_topic=cautare[contor_text].nr_topica;
			car_current=0;
			last_find=-1;
			car_activ=0;
		}
		if(gasit_text())
		{

			if(index_stiva < 99)
				index_stiva++;
			stiva[index_stiva].contor_text = contor_text;
			stiva[index_stiva].car_activ = car_activ;
			stiva[index_stiva].car_current = car_current;
			stiva[index_stiva].last_find = last_find;
			stiva[index_stiva].old_topic = old_topic;

			nu_exista=FALSE;
			AfisareTopica(cautare[contor_text].nr_topica);
			car_activ++;
			last=FALSE;
			break;
		}
		else
			last=TRUE;
		car_current+=cautare[contor_text].lungime_text;
		contor_text++;
		car_activ = 0;
	}
	first = FALSE;
	}
	while(last && !nu_exista);
}

void CDictionaryDlg::OnBack()
{
	if(m_Edit)
	{	
		if(index_stiva > 0)
		{
			index_stiva--;
			contor_text = stiva[index_stiva].contor_text;
			car_activ = stiva[index_stiva].car_activ;
			car_current = stiva[index_stiva].car_current;
			last_find = stiva[index_stiva].last_find;
			old_topic = stiva[index_stiva].old_topic;
			AfisareTopica(cautare[contor_text].nr_topica);
			car_activ++;
			last=FALSE;
		}
	}
}

BOOL CDictionaryDlg::gasit_text()
{
	char * bufer;
	char aux;
	int i;
	int rez;
	bufer = new char[cautare[contor_text].lungime_text+1];
	f.Seek(cautare[contor_text].adresa_text, CFile::begin);
	f.Read(bufer, cautare[contor_text].lungime_text);
	OnReadDecript(bufer, cautare[contor_text].lungime_text);
	for(i=car_activ, rez=1; i<(cautare[contor_text].lungime_text-(int)strlen(find)+1); i++)
	{
		aux=bufer[i+strlen(input)];
		bufer[i+strlen(input)]=0;
		rez = strcmp(&bufer[i], input);
		bufer[i+strlen(input)]=aux;
		glob=aux;
		if(!rez)
		{
			car_activ=i;
			break;
		}
	}
	delete bufer;
	return rez==0;
}

void CDictionaryDlg::AfisareTopica(int l)
{
	CFile tmp;
	FINDTEXTEX fnd;
	long find;
	BOOL flag=false;
	int cod, nrcar, inceput, sfirsit, lung_top;
	int nr_linie;
	char * title, * unu, * doi, * trei, * total;
//	char * pc;

	if(l>=2)
		l-=2;
	
	if(l >= nr_topica)
		AfxMessageBox("Eroare cautare");
	else
	{
	if(l>=0)
	{
		f.Seek(topica[l].address, CFile::begin);//pozitionare la inceput
		f.Read((char*)&cod, sizeof(cod));//citire cod, adresa
		OnReadDecript((char*)&cod, sizeof(cod));
		f.Read((char*)&nrcar, sizeof(nrcar));
		OnReadDecript((char*)&nrcar, sizeof(nrcar));
		title = new char[nrcar];
		f.Read(title, nrcar);
		OnReadDecript(title, nrcar);
		for(int s=0, flag=FALSE; s<nrcar; s++)
		{
			if((title[s]==' ')&&(title[s+1]=='\\'))//primul spatiu cu /
			{
				if(!flag)
					inceput=s;//inceputul titlui
				flag=TRUE;
			}
			if(flag==TRUE && title[s]=='\n')
			{
				sfirsit=s;//sfirsitul titlului
				break;
			}
		}		
		delete title;

		f.Seek(topica[l].address+2*sizeof(int), CFile::begin);//pozitionare inceput
		title = new char[sfirsit+2];
		f.Read(title, sfirsit);
		OnReadDecript(title, sfirsit);
		title[sfirsit]='}';
		title[sfirsit+1]='\0';

		total=new char[sfirsit+lantet+2];
		strcpy(total, antet);
		strcat(total, title);
		
/*
		tmp.Open("title.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(title, strlen(title));
		tmp.Close();
		
		tmp.Open("total.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(total, strlen(total));
		tmp.Close();
*/

		CDictionaryDlg::AfisRTF(total, &m_Top);

		delete title;
		delete total;
//end afisare titlu in top richedit

		unu = new char[inceput];
		f.Seek(topica[l].address+2*sizeof(int), CFile::begin);
		f.Read(unu, inceput);//citire chestii pina inainte de titlu;
		OnReadDecript(unu, inceput);
		unu[inceput]='\0';

		doi = new char[nrcar-sfirsit];
		f.Seek(topica[l].address+2*sizeof(int)+sfirsit, CFile::begin);//pozitionare dupa titlu
		f.Read(doi, nrcar-sfirsit);
		OnReadDecript(doi, nrcar-sfirsit);
		doi[nrcar-sfirsit-2*sizeof(int)+1]='}';//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		doi[nrcar-sfirsit-2*sizeof(int)+2]='\0';

		trei = new char[nrcar-(sfirsit-inceput)+1+14];
		strcpy(trei, unu);
		strcat(trei, " \\plain\\b\\fs22");
		strcat(trei, doi);

		total = new char[lantet+nrcar+14];
		strcpy(total, antet);
		strcat(total, trei);

		m_Right.GetDefaultCharFormat(cfr);
		cfr.yHeight=160; //font x 20
		cfr.dwMask=cfr.dwMask|CFM_SIZE|CFM_BOLD|CFM_FACE;
		cfr.dwEffects=CFE_BOLD;
		strcpy (cfr.szFaceName, "arial") ;
		m_Right.SetDefaultCharFormat(cfr);
		m_Right.GetDefaultCharFormat(cfr);
		CDictionaryDlg::AfisRTF(total, &m_Right);
		
/*		tmp.Open("trei.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(trei, strlen(trei));
		tmp.Close();

		tmp.Open("tdoi.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(doi, strlen(doi));
		tmp.Close();

		tmp.Open("tunu.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(unu, strlen(unu));
		tmp.Close();
*/

	
		if(flg_search)
		{
			lung_top=m_Top.LineLength();
			if(car_current+car_activ > lung_top)
			{
				fnd.lpstrText = (char*)(LPCSTR)input;
				fnd.chrg.cpMin = car_current+car_activ-lung_top;
				fnd.chrg.cpMax = nrcar;
				fnd.chrgText.cpMin = 0;
				fnd.chrgText.cpMax = nrcar;
				if(last_find > fnd.chrg.cpMin)
					fnd.chrg.cpMin = last_find+1;
				find = m_Right.FindText(FR_DOWN | FR_MATCHCASE, &fnd);


				EDITSTREAM esout;
				CString outtext;
				esout.dwCookie=(DWORD)&outtext;
				esout.dwError=0;
				esout.pfnCallback=EditStreamCallBackOut;
				m_Right.StreamOut(SF_TEXT, esout);
/*
				tmp.Open("search.txt", CFile::modeCreate|CFile::modeWrite);
				tmp.Write(outtext, strlen(outtext));
				tmp.Close();
*/
				if(find == -1)
					find = car_current+car_activ-lung_top;
				last_find = find;
				nr_linie = m_Right.LineFromChar(find);
				m_Right.LineScroll(nr_linie, 0);
				Invalidate();
				m_Right.SetSel(find, find+strlen(input));
			}
			else
			{
				fnd.lpstrText = (char*)(LPCSTR)input;
				fnd.chrg.cpMin = car_activ;
				fnd.chrg.cpMax = lung_top;
				if(last_find > fnd.chrg.cpMin)
					fnd.chrg.cpMin = last_find+1;
				find = m_Top.FindText(FR_DOWN | FR_MATCHCASE, &fnd);
				if(find == -1)
					find = car_activ;
				last_find = find;
				m_Top.SetSel(find, find+strlen(input));
			}
		}
		delete trei;
		delete total;
	}
	}
}


void CDialog::OnCancel(){}

void CDictionaryDlg::OnHelp() 
{
	if(!m_Edit)
	{
		m_Tab.SetCurSel(6);
		if(m_Left)
			m_Left.DestroyWindow();
		m_Right.MoveWindow(0,70,dictLength-5,dictHeight-75);
		right_is_big=TRUE;
		AfisareContext("intro");
		m_Right.LineScroll(-m_Right.GetLineCount(), 0);
	}
		
	if(m_Static_ro)
		m_Static_ro.DestroyWindow();
	if(m_Static_gr)
		m_Static_gr.DestroyWindow();

/*	
	read(&m_Right, "afi.txt");
	CString stream=pbuf;
	EDITSTREAM es;
	es.dwCookie=(DWORD)&stream;
	es.dwError=0;
	es.pfnCallback=EditStreamCallBack;
	m_Right.StreamIn(SF_RTF,es);
*/
}

void CDictionaryDlg::OnAbout() 
{
	AfxMessageBox("Dictionary ver 1.0", MB_ICONINFORMATION);	
}

void CDictionaryDlg::OnClose()
{
	this->DestroyWindow();
	exit(0);
}

void CDictionaryDlg::Afisare(int l)
{
	CFile tmp;
	BOOL flag=false;
	int cod, nrcar, inceput, sfirsit;
	char * title, * unu, * doi, * trei, * total;
//	char * pc;
	if(l >= nractiv)
		AfxMessageBox("Eroare cautare");
	else
	{
		f.Seek(tabactiv[l].address, CFile::begin);//pozitionare la inceput
		f.Read((char*)&cod, sizeof(cod));//citire cod, adresa
		OnReadDecript((char*)&cod, sizeof(cod));
		f.Read((char*)&nrcar, sizeof(nrcar));
		OnReadDecript((char*)&nrcar, sizeof(nrcar));
		title = new char[nrcar];
		f.Read(title, nrcar);
		OnReadDecript(title, nrcar);
		for(int s=0, flag=FALSE; s<nrcar; s++)
		{
			if((title[s]==' ')&&(title[s+1]=='\\'))//primul spatiu cu /
			{
				if(!flag)
					inceput=s;//inceputul titlului
				flag=TRUE;
			}
			if(flag==TRUE && title[s]=='\n')
			{
				sfirsit=s;//sfirsitul titlului
				break;
			}
		}		
		delete title;

		f.Seek(tabactiv[l].address+2*sizeof(int), CFile::begin);//pozitionare inceput
		title = new char[sfirsit+2];
		f.Read(title, sfirsit);
		OnReadDecript(title, sfirsit);
		title[sfirsit]='}';
		title[sfirsit+1]='\0';

		total=new char[sfirsit+lantet+2];
		strcpy(total, antet);
		strcat(total, title);
		
/*				
		tmp.Open("title.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(title, strlen(title));
		tmp.Close();
		
		tmp.Open("total.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(total, strlen(total));
		tmp.Close();
*/
		CDictionaryDlg::AfisRTF(total, &m_Top);

		delete title;
		delete total;
//end afisare titlu in top richedit

		unu = new char[inceput];
		f.Seek(tabactiv[l].address+2*sizeof(int), CFile::begin);
		f.Read(unu, inceput);//citire chestii pina inainte de titlu;
		OnReadDecript(unu, inceput);
		unu[inceput]='\0';

		doi = new char[nrcar-sfirsit];
		f.Seek(tabactiv[l].address+2*sizeof(int)+sfirsit, CFile::begin);//pozitionare dupa titlu
		f.Read(doi, nrcar-sfirsit);
		OnReadDecript(doi, nrcar-sfirsit);
		doi[nrcar-sfirsit-2*sizeof(int)+1]='}';//!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
		doi[nrcar-sfirsit-2*sizeof(int)+2]='\0';

		trei = new char[nrcar-(sfirsit-inceput)+1+14];
		strcpy(trei, unu);
		strcat(trei, " \\plain\\b\\fs22");
		strcat(trei, doi);

		total = new char[lantet+nrcar+14];
		strcpy(total, antet);
		strcat(total, trei);

		m_Right.GetDefaultCharFormat(cfr);
		cfr.yHeight=160; //font x 20
		cfr.dwMask=cfr.dwMask|CFM_SIZE|CFM_BOLD|CFM_FACE;
		cfr.dwEffects=CFE_BOLD;
		strcpy (cfr.szFaceName, "arial") ;
		m_Right.SetDefaultCharFormat(cfr);
		m_Right.GetDefaultCharFormat(cfr);
		
		CDictionaryDlg::AfisRTF(total, &m_Right);
		
/*		tmp.Open("total.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(total, strlen(total));
		tmp.Close();
		
		tmp.Open("trei.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(trei, strlen(trei));
		tmp.Close();

		tmp.Open("tdoi.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(doi, strlen(doi));
		tmp.Close();

		tmp.Open("tunu.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(unu, strlen(unu));
		tmp.Close();
*/
		delete trei;
		delete total;
	}
}

void CDictionaryDlg::OnMsgfilterTab(NMHDR* pNMHDR, LRESULT* pResult)
{
	MSGFILTER *pMsgFilter = reinterpret_cast<MSGFILTER *>(pNMHDR);
	CPoint punct;
	long xPos,yPos;
	CRect tabrect;
	m_Tab.GetItemRect(0, &tabrect);
	
	if(pMsgFilter->msg==WM_LBUTTONDOWN)
	{
		yPos = HIWORD(pMsgFilter->lParam);
		xPos = LOWORD(pMsgFilter->lParam);
	}
	*pResult = 0;
}


void CDictionaryDlg::OnMsgfilterLeft(NMHDR* pNMHDR, LRESULT* pResult)
{
	MSGFILTER *pMsgFilter = reinterpret_cast<MSGFILTER *>(pNMHDR);
	int i=0,j,k,l;
	CPoint punct;
	char buff[20];
	long xPos,yPos;
	
	SetCursor(hMyCur);
		
	if(pMsgFilter->msg==WM_VSCROLL)
	{
		m_Left.GetRect(&rect);
		rect.SetRect(0,50,102,dictHeight-5);
		InvalidateRect(&rect);
	}
	
	if(pMsgFilter->msg==WM_KEYDOWN)
	{
		m_Left.GetRect(&rect);
		rect.SetRect(0,50,102,dictHeight-5);
		InvalidateRect(&rect);
	}
	if(pMsgFilter->msg==WM_LBUTTONUP)
	{
		yPos = HIWORD(pMsgFilter->lParam);
		xPos = LOWORD(pMsgFilter->lParam);
		for (k=0, j=0, l=-2; k<lungime; k++)
		{
			if(k==0 || (pbufer[k-1]=='\n' && k>0))
			{
				l++;
				punct=m_Left.GetCharPos(k);
				if(punct.y > yPos)
					break;
				else 
					j=k;
			}
		}
		if (k>=lungime)
		{
//			AfxMessageBox("Nu s-a gasit cuvintul");
		}
		else 
		{
			for(i=j; i < k && pbufer[i]!='\n'; i++)
				buff[i-j]=pbufer[i];
			buff[i-j]=0;
			Afisare(l>=0?l:0);
		}
		if(j<i)
			m_Left.SetSel(j,i);
	}
	*pResult = 0;
}


void CDictionaryDlg::OnMsgfilterRight(NMHDR* pNMHDR, LRESULT* pResult)
{
	MSGFILTER *pMsgFilter = reinterpret_cast<MSGFILTER *>(pNMHDR);

	if(pMsgFilter->msg==WM_VSCROLL)
	{
		m_Right.GetRect(&rect);
		rect.SetRect(105,73,dictLength-5,dictHeight-5);
		InvalidateRect(&rect);
	}

	if(pMsgFilter->msg==WM_KEYDOWN)
	{
		m_Right.GetRect(&rect);
		rect.SetRect(105,73,dictLength-5,dictHeight-5);
		InvalidateRect(&rect);
	}

	*pResult = 0;
}


//preluarea textului introdus pt cautare
void CDictionaryDlg::OnMsgfilterTop(NMHDR* pNMHDR, LRESULT* pResult)
{
	MSGFILTER *pMsgFilter = reinterpret_cast<MSGFILTER *>(pNMHDR);
	SetCursor(hMyCurTop);
	if(pMsgFilter->msg==WM_KEYUP)
	{
		m_Edit.GetWindowText(input);
		if(oldinput!=input)
		{
			index_stiva=-1;
			first = TRUE;
		}
		oldinput = input;
	}
	*pResult = 0;
}


void CDictionaryDlg::OnSwitch()
{
	if(!m_Left)
		CtrlCreate(&m_Left);
	if(m_Result)
		m_Result.DestroyWindow();	

	//envelope
	if(m_Frame && m_Line)
	{
		m_Frame.DestroyWindow();
		m_Line.DestroyWindow();
	}
	else
	{
		pButton = GetDlgItem(IDC_TAB);
		rect.SetRect(3,5,dictLength-285,27);
		m_Frame.Create(NULL,WS_CHILD|WS_VISIBLE|SS_SUNKEN,rect,pButton,IDC_FRAME);

		rect.SetRect(0,51,dictLength-5,52);
		m_Line.Create("NULL",WS_CHILD|WS_VISIBLE|SS_SUNKEN,rect,this,IDC_LINE);
	}

//static text 
	if(m_tStatic)
		m_tStatic.DestroyWindow();
	else
	{
		pButton = GetDlgItem(IDC_TAB);
		rect.SetRect(10,6,250,26);
		m_tStatic.Create(NULL, WS_CHILD|WS_VISIBLE,rect,pButton,IDC_FUNDAL);
		m_tStatic.SetFont(&font, TRUE);
		m_tStatic.SetWindowText("X       Type a word or a part of it:");
	}
//edit control for search
	if(m_Edit)
		m_Edit.DestroyWindow();
	else
	{
		pButton = GetDlgItem(IDC_TAB);
		rect.SetRect(260,3,dictLength-5,29);
		m_Edit.Create(WS_CHILD|WS_VISIBLE|WS_BORDER|ES_WANTRETURN, rect, pButton, IDC_TOP);
		m_Edit.SetFont(&font, TRUE);
		m_Edit.SetBackgroundColor(FALSE,RGB(0,255,255));
		m_Edit.SetFocus();
		::SendMessage(m_Edit, EM_SETEVENTMASK, 0,ENM_KEYEVENTS);
		oldinput="";
	}
	
	//tab control
	if(m_Tab.GetItemCount()!=0)
	{
		m_Tab.DeleteAllItems();
		m_Tab.MoveWindow(-1,22,dictLength,30);
	}
	else
	{
		m_Tab.MoveWindow(-1,22,dictLength,24);
		m_Tab.SetImageList(&m_hList);
		if(!m_Tab.GetItem(0,&TabCtrlItem))
		{
			for (int i=0; i<7; i++)
			{
				TabCtrlItem.iImage=i;
				m_Tab.InsertItem(i,&TabCtrlItem);
			}
		}
		CHARFORMAT2 cf;
		cf.yHeight=220;	//font x 20
		cf.dwMask=CFM_SIZE|CFM_BOLD|CFM_COLOR|CFM_FACE;
		cf.dwEffects=CFE_BOLD;
		cf.crTextColor=RGB(255,0,0);
		strcpy (cf.szFaceName, "arial") ;
		m_Left.SetDefaultCharFormat(cf);
		readPS(&m_Left, prefix, nr_prefix);
	}
	flg_search=FALSE;
	Invalidate();
}

void readTopic()
{
	int cod, dim;
	struct{
		long	topici;
		long	contexte;
		long	prefixe;
		long	sufixe;
		long	cautare;
	}fine;

	CFileException e;
	if(f.Open("nume.mnt", CFile::modeRead, &e))
	{
	f.Seek(-5*(int)sizeof(long), CFile::end);
	int r = f.Read(&fine.topici,4);
	OnReadDecript((char*)&fine.topici,4);
 	r = f.Read(&fine.contexte,4);
	OnReadDecript((char*)&fine.contexte,4);
	r = f.Read(&fine.prefixe,4);
	OnReadDecript((char*)&fine.prefixe,4);
	r = f.Read(&fine.sufixe,4);
	OnReadDecript((char*)&fine.sufixe,4);
	r = f.Read(&fine.cautare,4);
	OnReadDecript((char*)&fine.cautare,4);
	}
	else
		AfxMessageBox("Eroare deschidere");
	initTabela(&topica, &nr_topica, fine.topici);
	initTabela(&context, &nr_context, fine.contexte);
	initTabela(&prefix, &nr_prefix, fine.prefixe);
	initTabela(&sufix, &nr_sufix, fine.sufixe);
	initTabelaSearch(&cautare, fine.cautare, &nr_struct);
	f.Seek(0L,CFile::begin);
	f.Read((char*)&cod, sizeof(cod));
	OnReadDecript((char*)&cod, sizeof(cod));
	f.Read((char*)&dim, sizeof(dim));
	OnReadDecript((char*)&dim, sizeof(dim));
	antet = new char[dim];
	f.Read(antet, dim - 2*(sizeof(cod)));
	OnReadDecript(antet, dim - 2*(sizeof(cod)));
	lantet=dim-2*(sizeof(cod));
	antet[lantet] = 0;
}

void initTabela(Ctopic ** pTopic, int * nr, long offset)
{
	Ctopic man, *paux;
	WORD dim;
	int i;
	f.Seek(offset, CFile::begin);
	f.Read(&dim, sizeof(int));
	OnReadDecript((char*)&dim, sizeof(int));
	*nr = dim;
	*pTopic = new Ctopic[dim];
	UINT cit = sizeof(man.nume);
	for (i=0, paux=*pTopic; i<dim; i++/*, paux+=sizeof(Ctopic)*/)
	{
		if(f.Read(man.nume, sizeof(man.nume))!=sizeof(man.nume))
		{
			AfxMessageBox("Desincronizare pe citire Ctopic.nume");
			return;
		}
		else
			OnReadDecript(man.nume, sizeof(man.nume));

		if(f.Read((char*)&man.nr, sizeof(man.nr))!=sizeof(man.nr))
		{
			AfxMessageBox("Desincronizare pe citire Ctopic.numar");
			return;
		}
		else
			OnReadDecript((char*)&man.nr, sizeof(man.nr));

		if(f.Read((char*)&man.address, sizeof(man.address))!=sizeof(man.address))
		{
			AfxMessageBox("Desincronizare pe citire Ctopic.adresa");
			return;
		}
		else
			OnReadDecript((char*)&man.address, sizeof(man.address));

		paux[i].nr = man.nr;
		paux[i].address = man.address;
		for (int j =0; j<MAXTEXT; j++)
			paux[i].nume[j] = man.nume[j];
	}
}

void initTabelaSearch(Csearch **pCsearch, long offset, int * nr_struct)
{
	Csearch man, *paux;
	WORD dim;
	int i;
	f.Seek(offset, CFile::begin);
	f.Read(&dim, sizeof(int));
	OnReadDecript((char*)&dim, sizeof(int));
	*nr_struct = dim;
	*pCsearch = new Csearch[dim];
	UINT cit = sizeof(man.nr_topica);
	for (i=0, paux=*pCsearch; i<dim; i++/*, paux+=sizeof(Ctopic)*/)
	{
		if(f.Read((char*)&man.nr_topica, sizeof(man.nr_topica))!=sizeof(man.nr_topica))
		{
			AfxMessageBox("Desincronizare pe citire Csearch.nr_topica");
			return;
		}
		else
			OnReadDecript((char*)&man.nr_topica, sizeof(man.nr_topica));

		if(f.Read((char*)&man.adresa_text, sizeof(man.adresa_text))!=sizeof(man.adresa_text))
		{
			AfxMessageBox("Desincronizare pe citire Csearch.adresa_text");
			return;
		}
		else
			OnReadDecript((char*)&man.adresa_text, sizeof(man.adresa_text));

		if(f.Read((char*)&man.lungime_text, sizeof(man.lungime_text))!=sizeof(man.lungime_text))
		{
			AfxMessageBox("Desincronizare pe citire Csearch.lungime_text");
			return;
		}
		else
			OnReadDecript((char*)&man.lungime_text, sizeof(man.lungime_text));

		paux[i].nr_topica = man.nr_topica;
		paux[i].adresa_text = man.adresa_text;
		paux[i].lungime_text = man.lungime_text;
	}
}

//functia de afisare apelata din ctrltab
void CDictionaryDlg::AfisareContext(CString string)
{
	Ctopic *top;
	CFile tmp;
	char * title, * total, * unu, * doi, * trei;
	int i,cod,nrcar,inceput,sfirsit;
	tabactiv = context;
	for(i=0, top=context; i<nr_context; i++)
	{
		if(!strcmp(top[i].nume, string))
			break;
	}
	if(i >= nr_context)
		AfxMessageBox("Eroare pe cautare");
	else
	{
		f.Seek(tabactiv[i].address, CFile::begin);
		f.Read((char*)&cod, sizeof(cod));//initializare cod si nrcar
		OnReadDecript((char*)&cod, sizeof(cod));
		f.Read((char*)&nrcar, sizeof(nrcar));
		OnReadDecript((char*)&nrcar, sizeof(nrcar));
		
//		if(string=="misfits")
//			nrcar=790;

		title = new char[nrcar];
		
		f.Read(title, nrcar);
		OnReadDecript(title, nrcar);
/*
		tmp.Open("unu.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(title, strlen(title));
		tmp.Close();
*/		
		for(int s=0,flag=FALSE; s<nrcar; s++)
		{
			if((title[s]==' ')&&(title[s+1]=='\\'))//primul spatiu cu '_\'
			{
				if(!flag)
					inceput=s;//inceputul titlului
				flag=TRUE;
			}
			if(flag==TRUE && title[s]=='M' && title[s+1]=='i')
			{
				sfirsit=s+7;
				break;
			}

			if(flag==TRUE && title[s]=='G' && title[s+1]=='r')
			{
				sfirsit=s+11;
				break;
			}

			if(flag==TRUE && title[s]=='L' && title[s+1]=='a')
			{
				sfirsit=s+11;
				break;
			}

			if(flag==TRUE && title[s]=='W' && title[s+1]=='o')
			{
				sfirsit=s+20;
				break;
			}

			if(flag==TRUE && title[s]=='i' && title[s+1]=='n')
			{
				sfirsit=s+12;
				break;
			}
		}		
		delete title;

		f.Seek(tabactiv[i].address+2*sizeof(int), CFile::begin);//pozitionare inceput
		title = new char[sfirsit+2];
		f.Read(title, sfirsit);
		OnReadDecript(title, sfirsit);
		title[sfirsit]='}';
		title[sfirsit+1]='\0';

		total=new char[sfirsit+lantet+2];
		strcpy(total, antet);
		strcat(total, title);
		
/*
		tmp.Open("afis.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(total, strlen(total));
		tmp.Close();
*/
		CDictionaryDlg::AfisRTF(total, &m_Top);
		delete total;

//********************************************end afisare titlu;

		unu = new char[inceput];
		f.Seek(tabactiv[i].address+2*sizeof(int), CFile::begin);
		f.Read(unu, inceput);//citire chestii pina inainte de titlu;
		OnReadDecript(unu, inceput);
		unu[inceput]='\0';

		doi = new char[nrcar-sfirsit];
		f.Seek(tabactiv[i].address+2*sizeof(int)+sfirsit, CFile::begin);//pozitionare dupa titlu
		f.Read(doi, nrcar-sfirsit);
		OnReadDecript(doi, nrcar-sfirsit);
		doi[nrcar-sfirsit-2*sizeof(int)+1]='}';
		doi[nrcar-sfirsit-2*sizeof(int)+2]='\0';

		trei = new char[nrcar-(sfirsit-inceput)+1];
		strcpy(trei, unu);
		strcat(trei, doi);

		total = new char[lantet+nrcar];
		strcpy(total, antet);
		strcat(total, trei);

		m_Right.GetDefaultCharFormat(cfr);
		cfr.yHeight=160; //font x 20
		cfr.dwMask=cfr.dwMask|CFM_SIZE|CFM_BOLD|CFM_FACE;
		cfr.dwEffects=CFE_BOLD;
		strcpy (cfr.szFaceName, "arial") ;
		m_Right.SetDefaultCharFormat(cfr);
		m_Right.GetDefaultCharFormat(cfr);		
		CDictionaryDlg::AfisRTF(total, &m_Right);

		
/*		tmp.Open("afis3.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(trei, strlen(trei));
		tmp.Close();

		tmp.Open("afis2.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(doi, strlen(doi));
		tmp.Close();

		tmp.Open("afis1.txt", CFile::modeCreate|CFile::modeWrite);
		tmp.Write(unu, strlen(unu));
		tmp.Close();

		delete trei;
		delete total;
*/	}
}


void CDictionaryDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
/*	bIsMoving = FALSE;
	if(point.x>0 && point.x<dictLength && point.y>0 && point.y <20)
	{
		GetCursorPos(&init);
		initx=point.x;
		inity=point.y;
		bIsMoving = TRUE;
	}
*/
	CRect cr, crbig;
	long xPos, yPos;
	CPoint punctst, punctdr, punctSt;
	if(m_tStatic)
	{
		m_tStatic.GetWindowRect(&cr);//L=240; H=20;
		xPos=point.x;
		yPos=point.y;
		this->GetWindowRect(&crbig);
		punctSt = crbig.TopLeft();
		punctst = cr.TopLeft();
		punctdr = cr.BottomRight();
		if(xPos > -punctSt.x+punctst.x && xPos< -punctSt.x+punctdr.x && yPos<-punctSt.y+punctdr.y && yPos>-punctSt.y+punctst.y)
		{
			OnSwitch();
			m_Top.SetWindowText(" ");
			m_Right.SetWindowText(" ");
			Invalidate();
		}
	}
    PostMessage(WM_NCLBUTTONDOWN, HTCAPTION, MAKELPARAM( point.x, point.y));
}

void CDictionaryDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
/*	CRect windowsize;
	CPoint mouse_window;
	GetCursorPos(&mouse_window);
	long xPos, yPos;
	if((nFlags & MK_LBUTTON) && bIsMoving)
	{
		xPos=(point.x-initx);
		yPos=(point.y-inity);
//		xPos = (mouse_window.x-init.x);
//		yPos = (mouse_window.y-init.y);
		GetWindowRect(&windowsize);
		MoveWindow(windowsize.left+xPos,
				   windowsize.top+yPos,
				   dictLength,
				   dictHeight, TRUE);
	}
*/
}

void OnReadDecript(char * buf, int nrchar)
{
	int i;
	for(i=0; i<nrchar; i++)
		buf[i] = -buf[i];
}

void CDictionaryDlg::CtrlCreate(CRichEditCtrlEx * rich)
{
	if(!m_Left)
	{
		rect.SetRect(0,50,102,dictHeight-5);
		m_Left.CreateEx(WS_EX_TRANSPARENT, "RICHEDIT20A", "",
					ES_NOHIDESEL|WS_CHILD|WS_VISIBLE|ES_READONLY|
					ES_MULTILINE| ES_AUTOVSCROLL|
					WS_BORDER|WS_VSCROLL|WS_TABSTOP, rect, this, IDC_LEFT, NULL);
//		m_Left.SetBackgroundColor(FALSE,RGB(255,255,193));
		::SendMessage(m_Left, EM_SETEVENTMASK, 0,ENM_MOUSEEVENTS|ENM_SCROLLEVENTS);
		::InvalidateRect(m_Left, &rect, TRUE);
//		SetClipboardData (CF_DIB, CopyHandle((HANDLE) pDoc->GetHDIB()) );
	}
}


BOOL OnSetCursor( CWnd* pWnd, UINT nHitTest, UINT message )
{
	return FALSE;
}


HBRUSH CDictionaryDlg::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor)
{
	switch(nCtlColor) {
/*		case CTLCOLOR_STATIC:
			pDC->SetBkMode(TRANSPARENT);
			return HBRUSH(m_HollowBrush);
		case CTLCOLOR_BTN:
			pDC->SetBkMode(TRANSPARENT);
			return HBRUSH(m_HollowBrush);
*/		case CTLCOLOR_EDIT:
			pDC->SetBkMode(TRANSPARENT);
			return HBRUSH(myBrush);
		default:
			break;
		}
	return (CDialog::OnCtlColor(pDC, pWnd, nCtlColor)); 
//	return m_BrushPat3;
}

BOOL CDictionaryDlg::PreTranslateMessage(MSG* pMsg) 
{
	m_tool.RelayEvent(pMsg);	
	BOOL ret = ::TranslateAccelerator(GetSafeHwnd(), m_hAccel, pMsg);	
	if (!ret)
       ret = CDialog::PreTranslateMessage(pMsg);
	return ret;	
}
/*
void CDictionaryDlg::OnVscrollLeft()
{
	m_Left.GetRect(rect);
	InvalidateRect(&rect);
}

void CDictionaryDlg::OnVscrollRight()
{
	m_Right.GetRect(rect);
	InvalidateRect(&rect);
}
*/