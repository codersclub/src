// TransparentSliderDemoDlg.h : header file
//
#if !defined(AFX_TransparentSliderDemoDLG_H__14583BDE_DC86_4E80_86DF_E9C9B089FC04__INCLUDED_)
#define AFX_TransparentSliderDemoDLG_H__14583BDE_DC86_4E80_86DF_E9C9B089FC04__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "myslidercontrol.h"
/////////////////////////////////////////////////////////////////////////////
// CTransparentSliderDemoDlg dialog

class CTransparentSliderDemoDlg : public CDialog
{
// Construction
public:
	CTransparentSliderDemoDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTransparentSliderDemoDlg)
	enum { IDD = IDD_TransparentSliderDemo_DIALOG };
	CMySliderControl	m_slider3;
	CMySliderControl	m_slider2;
	CMySliderControl	m_slider1;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransparentSliderDemoDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTransparentSliderDemoDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
	BOOL SetBitmap(UINT uResourceID);
	BOOL TileBitmap(CDC* pDC, CRect rc);
	BOOL GetBitmapAndPalette(UINT nIDResource, CBitmap& bitmap, CPalette& pal);
	// For background bitmap
	CBitmap m_BmpPattern;
	CPalette m_BmpPalette;
	int m_nBmpWidth;
	int m_nBmpHeight, age;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TransparentSliderDemoDLG_H__14583BDE_DC86_4E80_86DF_E9C9B089FC04__INCLUDED_)
