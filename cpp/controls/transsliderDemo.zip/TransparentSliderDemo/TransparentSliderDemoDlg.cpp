// TransparentSliderDemoDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TransparentSliderDemo.h"
#include "TransparentSliderDemoDlg.h"
#include <math.h>
#include "BackgroundUtil.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransparentSliderDemoDlg dialog

CTransparentSliderDemoDlg::CTransparentSliderDemoDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTransparentSliderDemoDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTransparentSliderDemoDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTransparentSliderDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTransparentSliderDemoDlg)
	DDX_Control(pDX, IDC_SLIDER3, m_slider3);
	DDX_Control(pDX, IDC_SLIDER2, m_slider2);
	DDX_Control(pDX, IDC_SLIDER1, m_slider1);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTransparentSliderDemoDlg, CDialog)
	//{{AFX_MSG_MAP(CTransparentSliderDemoDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTransparentSliderDemoDlg message handlers

BOOL CTransparentSliderDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	SetBitmap(IDB_BACKGROUND1);
	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	// TODO: Add extra initialization here
	m_slider3.SetRange(0, 100);
	m_slider3.SetTicFreq(5);
	m_slider2.SetRange(0, 100);
	m_slider2.SetTicFreq(10);

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTransparentSliderDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTransparentSliderDemoDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTransparentSliderDemoDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}


//pow(10,(0.938573813*(pow(log((m_BodyWeight / 157.141)),2)));
void CTransparentSliderDemoDlg::OnOK() 
{

}

BOOL CTransparentSliderDemoDlg::SetBitmap(UINT uResourceID)
{
	BITMAP bm;
	BOOL bRet;

	// Detach previous resources
	m_BmpPattern.Detach();  
	m_BmpPalette.Detach();  

	// Default return value
	bRet = TRUE;

	// Load new bitmap
	if (uResourceID != 0)
	{
		bRet = GetBitmapAndPalette(uResourceID, m_BmpPattern, m_BmpPalette);
		// If all ok
		if (bRet == TRUE)
		{
			// Get dimension
			m_BmpPattern.GetBitmap(&bm);
			// Width of the bitmap
			m_nBmpWidth = bm.bmWidth;
			// Height of the bitmap
			m_nBmpHeight = bm.bmHeight;
		}
	}

	return bRet;
} // End of SetBitmap

BOOL CTransparentSliderDemoDlg::GetBitmapAndPalette(UINT nIDResource, CBitmap & bitmap, CPalette & pal)
{
	LPCTSTR lpszResourceName = (LPCTSTR)nIDResource;

	HBITMAP hBmp = (HBITMAP)::LoadImage( AfxGetInstanceHandle(), 
		lpszResourceName, IMAGE_BITMAP, 0,0, LR_CREATEDIBSECTION);

	if (hBmp == NULL) return FALSE;

	bitmap.Attach(hBmp);

	// Create a logical palette for the bitmap
	DIBSECTION ds;
	BITMAPINFOHEADER &bmInfo = ds.dsBmih;
	bitmap.GetObject(sizeof(ds), &ds);

	int nColors = bmInfo.biClrUsed ? bmInfo.biClrUsed : 1 << bmInfo.biBitCount;

	// Create a halftone palette if colors > 256. 
	CClientDC dc(NULL); // Desktop DC

	if(nColors > 256)
		pal.CreateHalftonePalette(&dc);
	else
	{
		// Create the palette
		RGBQUAD *pRGB = new RGBQUAD[nColors];
		CDC memDC;
		memDC.CreateCompatibleDC(&dc);
		memDC.SelectObject( &bitmap );
		::GetDIBColorTable( memDC, 0, nColors, pRGB );
		UINT nSize = sizeof(LOGPALETTE) + (sizeof(PALETTEENTRY) * nColors);
		LOGPALETTE *pLP = (LOGPALETTE *) new BYTE[nSize];
		pLP->palVersion = 0x300;
		pLP->palNumEntries = nColors;
		for (int i=0; i < nColors; i++)
		{
			pLP->palPalEntry[i].peRed = pRGB[i].rgbRed;
			pLP->palPalEntry[i].peGreen = pRGB[i].rgbGreen;
			pLP->palPalEntry[i].peBlue = pRGB[i].rgbBlue;
			pLP->palPalEntry[i].peFlags = 0;
		}
		pal.CreatePalette( pLP );
		delete[] pLP;
		delete[] pRGB;
	}
	return TRUE;
} // End of GetBitmapAndPalette


BOOL CTransparentSliderDemoDlg::TileBitmap(CDC* pDC, CRect rc)
{
	CDC MemDC;

	int x = 0, y = 0;

	// If there is a bitmap loaded
	if (m_BmpPattern.m_hObject != NULL)
	{
		MemDC.CreateCompatibleDC(pDC);
		CBitmap* pOldBitmap = MemDC.SelectObject(&m_BmpPattern);

		// Tile the bitmap
		while (y < rc.Height()) 
		{
			while(x < rc.Width()) 
			{
				pDC->BitBlt(x, y, m_nBmpWidth, m_nBmpHeight, &MemDC, 0, 0, SRCCOPY);
				x += m_nBmpWidth;
			}
			x = 0;
			y += m_nBmpHeight;
		}

		MemDC.SelectObject(pOldBitmap);

		return TRUE;
	}

	return FALSE; // Normal behaviour
} // End of TileBitmap

BOOL CTransparentSliderDemoDlg::OnEraseBkgnd(CDC* pDC) 
{
	CRect rc;

	GetClientRect(rc);

	if (TileBitmap(pDC, rc) == TRUE)
		return TRUE;
	else
		return CDialog::OnEraseBkgnd(pDC);
} // End of OnEraseBkgnd
