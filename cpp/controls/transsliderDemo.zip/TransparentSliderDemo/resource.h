//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TransparentSliderDemo.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_TransparentSliderDemo_DIALOG 102
#define IDR_MAINFRAME                   128
#define IDB_BACKGROUND1                 129
#define IDC_BWT                         1001
#define IDC_TOTAL                       1002
#define IDC_TransparentSliderDemo       1003
#define IDC_MALE                        1004
#define IDC_FEMALE                      1005
#define IDC_CLEAR                       1006
#define IDC_MALETEXT                    1007
#define IDC_FEMALETEXT                  1008
#define IDC_BWTEXT                      1009
#define IDC_TWTEXT                      1010
#define IDC_TransparentSliderDemoTEXT   1011
#define IDC_AGE                         1012
#define IDC_SLIDER1                     1012
#define IDC_AGETEXT                     1013
#define IDC_SLIDER2                     1013
#define IDC_CJ                          1014
#define IDC_SLIDER3                     1014
#define IDC_CJTEXT                      1015
#define IDC_SNATCH                      1016
#define IDC_SNATCHTEXT                  1017
#define IDC_TransparentSliderDemoMM     1018
#define IDC_TransparentSliderDemoTEXT2  1019
#define IDC_TransparentSliderDemoSIFF   1020
#define IDC_SIFF                        1021
#define IDC_AGEJAN1EDIT                 1022
#define IDC_AGEJAN1                     1023
#define IDC_CURRENTYEAR                 1024
#define IDC_CURRENTYRTEXT               1025

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
