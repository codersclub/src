// TransparentSliderDemo.h : main header file for the TransparentSliderDemo application
//

#if !defined(AFX_TransparentSliderDemo_H__8069164B_C7B2_433D_A554_84B64CAB8BA9__INCLUDED_)
#define AFX_TransparentSliderDemo_H__8069164B_C7B2_433D_A554_84B64CAB8BA9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTransparentSliderDemoApp:
// See TransparentSliderDemo.cpp for the implementation of this class
//

class CTransparentSliderDemoApp : public CWinApp
{
public:
	CTransparentSliderDemoApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransparentSliderDemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTransparentSliderDemoApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TransparentSliderDemo_H__8069164B_C7B2_433D_A554_84B64CAB8BA9__INCLUDED_)
