; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CTransparentSliderDemoDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "TransparentSliderDemo.h"

ClassCount=3
Class1=CTransparentSliderDemoApp
Class2=CTransparentSliderDemoDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_TransparentSliderDemo_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_TransparentSliderDemo_DIALOG (English (U.S.))

[CLS:CTransparentSliderDemoApp]
Type=0
HeaderFile=TransparentSliderDemo.h
ImplementationFile=TransparentSliderDemo.cpp
Filter=N

[CLS:CTransparentSliderDemoDlg]
Type=0
HeaderFile=TransparentSliderDemoDlg.h
ImplementationFile=TransparentSliderDemoDlg.cpp
Filter=D
LastObject=CTransparentSliderDemoDlg
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=TransparentSliderDemoDlg.h
ImplementationFile=TransparentSliderDemoDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_TransparentSliderDemo_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CTransparentSliderDemoDlg

[DLG:IDD_TransparentSliderDemo_DIALOG (English (U.S.))]
Type=1
Class=CTransparentSliderDemoDlg
ControlCount=4
Control1=IDCANCEL,button,1342242816
Control2=IDC_SLIDER1,msctls_trackbar32,1342242836
Control3=IDC_SLIDER2,msctls_trackbar32,1342242819
Control4=IDC_SLIDER3,msctls_trackbar32,1342242825

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDC_STATIC,static,1342308480
Control2=IDC_STATIC,static,1342308352
Control3=IDOK,button,1342373889

