; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CLCDMatrixDlg
LastTemplate=CStatic
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "LCDMatrix.h"

ClassCount=3
Class1=CLCDMatrixApp
Class2=CLCDMatrixDlg

ResourceCount=3
Resource2=IDD_LCDMATRIX_DIALOG
Resource1=IDR_MAINFRAME
Class3=CMatrixStatic
Resource3=IDD_LCDMATRIX_DIALOG (English (U.S.))

[CLS:CLCDMatrixApp]
Type=0
HeaderFile=LCDMatrix.h
ImplementationFile=LCDMatrix.cpp
Filter=N

[CLS:CLCDMatrixDlg]
Type=0
HeaderFile=LCDMatrixDlg.h
ImplementationFile=LCDMatrixDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_MATRIXDOWN2



[DLG:IDD_LCDMATRIX_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CLCDMatrixDlg

[DLG:IDD_LCDMATRIX_DIALOG (English (U.S.))]
Type=1
Class=CLCDMatrixDlg
ControlCount=6
Control1=IDOK,button,1342242817
Control2=IDC_LCDSTATIC,static,1342308352
Control3=IDC_MATRIXSMALL,static,1342308352
Control4=IDC_MATRIXDOWN,static,1342308352
Control5=IDC_LCDLEFT,static,1342308352
Control6=IDC_MATRIXDOWN2,static,1342308352

[CLS:CMatrixStatic]
Type=0
HeaderFile=MatrixStatic.h
ImplementationFile=MatrixStatic.cpp
BaseClass=CStatic
Filter=W

