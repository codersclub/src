// demo.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "demo.h"

#include "MainFrm.h"
#include "ChildFrm.h"
#include "demoDoc.h"
#include "demoView.h"

#include "ximage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

DocType doctypes[CMAX_IMAGE_FORMATS] =
{
#if CXIMAGE_SUPPORT_BMP
	{ CXIMAGE_FORMAT_BMP, TRUE, TRUE, "BMP files", "bmp" },
#endif
#if CXIMAGE_SUPPORT_GIF
	{ CXIMAGE_FORMAT_GIF, TRUE, FALSE,"GIF files", "gif" },
#endif
#if CXIMAGE_SUPPORT_JPG
	{ CXIMAGE_FORMAT_JPG, TRUE, TRUE, "JPG files", "jpg" },
#endif
#if CXIMAGE_SUPPORT_PNG
	{ CXIMAGE_FORMAT_PNG, TRUE, TRUE, "PNG files", "png" },
#endif
#if CXIMAGE_SUPPORT_MNG
	{ CXIMAGE_FORMAT_MNG, TRUE, TRUE, "MNG files", "mng" },
#endif
#if CXIMAGE_SUPPORT_ICO
	{ CXIMAGE_FORMAT_ICO, TRUE, TRUE, "ICO files", "ico" },
#endif
#if CXIMAGE_SUPPORT_TIF
	{ CXIMAGE_FORMAT_TIF, TRUE, TRUE, "TIF files", "tif" }
#endif
};

/////////////////////////////////////////////////////////////////////////////
// CDemoApp
BEGIN_MESSAGE_MAP(CDemoApp, CWinApp)
	//{{AFX_MSG_MAP(CDemoApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_IMAGE_FROM_BITMAP, OnImageFromBitmap)
	ON_COMMAND(ID_CXIMAGE_LOADJPEGRESOURCE, OnCximageLoadjpegresource)
	ON_COMMAND(ID_CXIMAGE_LOADICONRESOURCE, OnCximageLoadiconresource)
	ON_COMMAND(ID_CXIMAGE_LOADGIFRESOURCE, OnCximageLoadgifresource)
	ON_COMMAND(ID_CXIMAGE_LOADPNGRESOURCE, OnCximageLoadpngresource)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CDemoApp::OnFileOpen)
	// Standard print setup command
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoApp construction
CDemoApp::CDemoApp()
{
#if CXIMAGE_SUPPORT_JPG
	m_nFilterIndex = CXIMAGE_FORMAT_JPG+1;	//default file extension
#else
	m_nFilterIndex=0;
#endif
	m_nDocCount=1;
}
/////////////////////////////////////////////////////////////////////////////
// The one and only CDemoApp object
CDemoApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CDemoApp initialization
BOOL CDemoApp::InitInstance()
{
	// Standard initialization
#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	LoadStdProfileSettings(9);  // Load standard INI file options (including MRU)

	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.
	CMultiDocTemplate* pDocTemplate;
	pDocTemplate = new CMultiDocTemplate(
		IDR_DEMOTYPE,
		RUNTIME_CLASS(CDemoDoc),
		RUNTIME_CLASS(CChildFrame), // custom MDI child frame
		RUNTIME_CLASS(CDemoView));
	demoTemplate = pDocTemplate;
	AddDocTemplate(pDocTemplate);

	// create main MDI Frame window
	CMainFrame* pMainFrame = new CMainFrame;
	if (!pMainFrame->LoadFrame(IDR_MAINFRAME))
		return FALSE;
	m_pMainWnd = pMainFrame;

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
    // Alter behaviour to not open window immediately
    cmdInfo.m_nShellCommand = CCommandLineInfo::FileNothing;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The main window has been initialized, so show and update it.
	pMainFrame->ShowWindow(m_nCmdShow);
	pMainFrame->UpdateWindow();

	// Enable drag/drop open
	m_pMainWnd->DragAcceptFiles();

	// Enable open from command line
	if (m_lpCmdLine != "") OpenDocumentFile(m_lpCmdLine);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About
class CAboutDlg : public CDialog
{
public:
	CAboutDlg();
// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL
// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
		// No message handlers
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};
/////////////////////////////////////////////////////////////////////////////
CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
}
/////////////////////////////////////////////////////////////////////////////
void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}
/////////////////////////////////////////////////////////////////////////////
BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
/////////////////////////////////////////////////////////////////////////////
// App command to run the dialog
void CDemoApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoApp::OnFileOpen() 
{
	// prompt the user (with all document templates)
	CString newName;
	int nType = CXIMAGE_FORMAT_BMP;
	if (!PromptForFileName(newName, AFX_IDS_OPENFILE,
	  OFN_HIDEREADONLY | OFN_FILEMUSTEXIST, TRUE, &nType))
		return; // open cancelled
	OpenDocumentFile(newName);
}
/////////////////////////////////////////////////////////////////////////////
// prompt for file name - used for open and save as
// static function called from app
BOOL CDemoApp::PromptForFileName(CString& fileName, UINT nIDSTitle, 
	DWORD dwFlags, BOOL bOpenFileDialog, int* pType)
{
	CFileDialog dlgFile(bOpenFileDialog);
	CString title("Open bitmap file");

	dlgFile.m_ofn.Flags |= dwFlags;
//	dlgFile.m_ofn.Flags &= ~OFN_SHOWHELP;

	int nIndex = m_nFilterIndex;
	if (!bOpenFileDialog){
		int nDocType = (pType != NULL) ? *pType : CXIMAGE_FORMAT_BMP;
		nIndex = GetIndexFromType(nDocType, bOpenFileDialog);
		if (nIndex == -1)
			nIndex = 1;
		ASSERT(nIndex != -1);
		nIndex++;
	}
	dlgFile.m_ofn.nFilterIndex = nIndex;
	// strDefExt is necessary to hold onto the memory from GetExtFromType
	CString strDefExt = GetExtFromType(GetTypeFromIndex(nIndex-1, bOpenFileDialog));
	dlgFile.m_ofn.lpstrDefExt = strDefExt;
		

	CString strFilter = GetFileTypes(bOpenFileDialog);
	dlgFile.m_ofn.lpstrFilter = strFilter;
	dlgFile.m_ofn.lpstrTitle = title;
	dlgFile.m_ofn.lpstrFile = fileName.GetBuffer(_MAX_PATH);

	BOOL bRet = (dlgFile.DoModal() == IDOK) ? TRUE : FALSE;
	fileName.ReleaseBuffer();
	if (bRet){
		if (bOpenFileDialog)
			m_nFilterIndex = dlgFile.m_ofn.nFilterIndex;
		if (pType != NULL){
			int nIndex = (int)dlgFile.m_ofn.nFilterIndex - 1;
			ASSERT(nIndex >= 0);
			*pType = GetTypeFromIndex(nIndex, bOpenFileDialog);
		}
	}
	return bRet;
}
/////////////////////////////////////////////////////////////////////////////
int CDemoApp::GetIndexFromType(int nDocType, BOOL bOpenFileDialog)
{
	int nCnt = 0;
	for (int i=0;i<CMAX_IMAGE_FORMATS;i++){
		if (bOpenFileDialog ? doctypes[i].bRead : doctypes[i].bWrite){
			if (doctypes[i].nID == nDocType)
				return nCnt;
			nCnt++;
		}
	}
	return -1;
}
/////////////////////////////////////////////////////////////////////////////
int CDemoApp::GetTypeFromIndex(int nIndex, BOOL bOpenFileDialog)
{
	int nCnt = 0;
	for (int i=0;i<CMAX_IMAGE_FORMATS;i++){
		if (bOpenFileDialog ? doctypes[i].bRead : doctypes[i].bWrite){
			if (nCnt == nIndex)
//              return i; // PJO - Buglet ?
                return doctypes[i].nID;
			nCnt++;
		}
	}
	ASSERT(FALSE);
	return -1;
}
/////////////////////////////////////////////////////////////////////////////
CString CDemoApp::GetExtFromType(int nDocType)
{
	for (int i=0;i<CMAX_IMAGE_FORMATS;i++){
		if (doctypes[i].nID == nDocType)
			return doctypes[i].ext;
	}
	return CString("");
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoApp::GetWritableType(int nDocType){
	for (int i=0;i<CMAX_IMAGE_FORMATS;i++){
		if (doctypes[i].nID == nDocType)
			return doctypes[i].bWrite;
	}
	return FALSE;
}
/////////////////////////////////////////////////////////////////////////////
CString CDemoApp::GetFileTypes(BOOL bOpenFileDialog)
{
	CString str;
	for (int i=0;i<CMAX_IMAGE_FORMATS;i++){
		if (bOpenFileDialog && doctypes[i].bRead){
			str += doctypes[i].description;
			str += (TCHAR)NULL;
            str += "*";
			str += doctypes[i].ext;
			str += (TCHAR)NULL;
		} else if (!bOpenFileDialog && doctypes[i].bWrite) {
			str += doctypes[i].description;
			str += (TCHAR)NULL;
            str += "*";
			str += doctypes[i].ext;
			str += (TCHAR)NULL;
		}
	}
	return str;
}

/////////////////////////////////////////////////////////////////////////////
// CDemoApp commands
void CDemoApp::OnImageFromBitmap() 
{
	HBITMAP bitmap;
	if (!(bitmap = ::LoadBitmap(AfxGetInstanceHandle(),MAKEINTRESOURCE(IDB_BITMAP1)))){
		AfxMessageBox("Could not load bitmap from resource");
		return;
	}

	CDemoDoc *doc = (CDemoDoc *)demoTemplate->OpenDocumentFile(NULL);
	if (doc){
		CxImage *newImage = new CxImage((HBITMAP)bitmap);
		if (!newImage->IsValid()) {
			AfxMessageBox("Could not create CImage");
			delete newImage;
			return;
		}
		doc->image = newImage;

		CString s;
		s.Format("BITMAP Resource Image %d",m_nDocCount++);
		doc->SetTitle(s);
		doc->UpdateAllViews(0);
		doc->UpdateStatusBar();
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoApp::OnCximageLoadjpegresource() 
{
	CxImage* newImage = new CxImage();
	if (!newImage->LoadResource(FindResource(NULL,"IDR_JPG1","JPG"),CXIMAGE_FORMAT_JPG)){
		AfxMessageBox(newImage->GetLastError());
		delete newImage;
		newImage =NULL;
		return;
	}
	CDemoDoc *doc = (CDemoDoc *)demoTemplate->OpenDocumentFile(NULL);
	if (doc){
		doc->image = newImage;

		CString s;
		s.Format("JPEG Resource Image %d",m_nDocCount++);
		doc->SetTitle(s);
		doc->UpdateAllViews(0);
		doc->UpdateStatusBar();
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoApp::OnCximageLoadiconresource() 
{
	CxImage* newImage = new CxImage();
	if (!newImage->LoadResource(FindResource(NULL,MAKEINTRESOURCE(IDR_ICO1),"ICO"),CXIMAGE_FORMAT_ICO)){
		AfxMessageBox(newImage->GetLastError());
		delete newImage;
		newImage =NULL;
		return;
	}
	CDemoDoc *doc = (CDemoDoc *)demoTemplate->OpenDocumentFile(NULL);
	if (doc){
		doc->image = newImage;

		CString s;
		s.Format("Icon Resource Image %d",m_nDocCount++);
		doc->SetTitle(s);
		doc->UpdateAllViews(0);
		doc->UpdateStatusBar();
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoApp::OnCximageLoadgifresource() 
{
	CxImage* newImage = new CxImage();
	if (!newImage->LoadResource(FindResource(NULL,MAKEINTRESOURCE(IDR_GIF1),"GIF"),CXIMAGE_FORMAT_GIF)){
		AfxMessageBox(newImage->GetLastError());
		delete newImage;
		newImage =NULL;
		return;
	}
	CDemoDoc *doc = (CDemoDoc *)demoTemplate->OpenDocumentFile(NULL);
	if (doc){
		doc->image = newImage;

		CString s;
		s.Format("GIF Resource Image %d",m_nDocCount++);
		doc->SetTitle(s);
		doc->UpdateAllViews(0);
		doc->UpdateStatusBar();
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoApp::OnCximageLoadpngresource() 
{
	CxImage* newImage = new CxImage();
	if (!newImage->LoadResource(FindResource(NULL,MAKEINTRESOURCE(IDR_PNG1),"PNG"),CXIMAGE_FORMAT_PNG)){
		AfxMessageBox(newImage->GetLastError());
		delete newImage;
		newImage =NULL;
		return;
	}
	CDemoDoc *doc = (CDemoDoc *)demoTemplate->OpenDocumentFile(NULL);
	if (doc){
		doc->image = newImage;

		CString s;
		s.Format("PNG Resource Image %d",m_nDocCount++);
		doc->SetTitle(s);
		doc->UpdateAllViews(0);
		doc->UpdateStatusBar();
	}
}
