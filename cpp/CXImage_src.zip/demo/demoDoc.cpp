// demoDoc.cpp : implementation of the CDemoDoc class
//

#include "stdafx.h"
#include "demo.h"

#include "MainFrm.h"
#include "demoDoc.h"
#include "DlgRotate.h"

#include "ximage.h"
#include <math.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoDoc

IMPLEMENT_DYNCREATE(CDemoDoc, CDocument)

BEGIN_MESSAGE_MAP(CDemoDoc, CDocument)
	//{{AFX_MSG_MAP(CDemoDoc)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE_AS, OnUpdateFileSaveAs)
	ON_UPDATE_COMMAND_UI(ID_FILE_SAVE, OnUpdateFileSave)
	ON_COMMAND(ID_STRETCH_MODE, OnStretchMode)
	ON_UPDATE_COMMAND_UI(ID_STRETCH_MODE, OnUpdateStretchMode)
	ON_COMMAND(ID_TRANSFORM_ELLIPSE, OnTransformEllipse)
	ON_COMMAND(ID_WINDOW_DUPLICATE, OnWindowDuplicate)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_CXIMAGE_FLIP, OnCximageFlip)
	ON_COMMAND(ID_CXIMAGE_MIRROR, OnCximageMirror)
	ON_COMMAND(ID_CXIMAGE_NEGATIVE, OnCximageNegative)
	ON_COMMAND(ID_CXIMAGE_GRAYSCALE, OnCximageGrayscale)
	ON_COMMAND(ID_CXIMAGE_ROTATE, OnCximageRotate)
	ON_UPDATE_COMMAND_UI(ID_EDIT_UNDO, OnUpdateEditUndo)
	ON_COMMAND(ID_EDIT_REDO, OnEditRedo)
	ON_COMMAND(ID_EDIT_UNDO, OnEditUndo)
	ON_UPDATE_COMMAND_UI(ID_EDIT_REDO, OnUpdateEditRedo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoDoc construction/destruction
CDemoDoc::CDemoDoc()
{
	image = NULL;
	stretchMode = FALSE;
	for (int i=0;i<MAX_UNDO_LEVELS;i++) imageUndo[i]=NULL;
	m_UndoLevel=0;
}
/////////////////////////////////////////////////////////////////////////////
CDemoDoc::~CDemoDoc()
{
	delete image;
	for (int i=0;i<MAX_UNDO_LEVELS;i++) delete imageUndo[i];
//		if (imageUndo[i]!=image) delete imageUndo[i];
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)
	image = NULL;

	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
// CDemoDoc serialization
void CDemoDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())	{	} 
	else {	}
}
/////////////////////////////////////////////////////////////////////////////
// CDemoDoc diagnostics
#ifdef _DEBUG
void CDemoDoc::AssertValid() const
{
	CDocument::AssertValid();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG
/////////////////////////////////////////////////////////////////////////////
// CDemoDoc commands
static CString FindExtension(const CString& name)
{
	int len = name.GetLength();
	int i;
	for (i = len-1; i >= 0; i--)
	{
		if (name[i] == '.')
		{
			return name.Mid(i+1);
		}
	}
	return CString("");
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CString filename(lpszPathName);
	CString ext(FindExtension(filename));
	ext.MakeLower();
	if (ext == "")
		return FALSE;

	int type = 0;
	if (ext == "bmp")					type = CXIMAGE_FORMAT_BMP;
#if CXIMAGE_SUPPORT_JPG
	else if (ext=="jpg"||ext=="jpeg")	type = CXIMAGE_FORMAT_JPG;
#endif
#if CXIMAGE_SUPPORT_GIF
	else if (ext == "gif")				type = CXIMAGE_FORMAT_GIF;
#endif
#if CXIMAGE_SUPPORT_PNG
	else if (ext == "png")				type = CXIMAGE_FORMAT_PNG;
#endif
#if CXIMAGE_SUPPORT_MNG
	else if (ext == "mng")				type = CXIMAGE_FORMAT_MNG;
#endif
#if CXIMAGE_SUPPORT_ICO
	else if (ext == "ico")				type = CXIMAGE_FORMAT_ICO;
#endif
#if CXIMAGE_SUPPORT_TIF
	else if (ext=="tiff"||ext=="tif")	type = CXIMAGE_FORMAT_TIF;
#endif
	else return FALSE;

	image = new CxImage(filename, type);
	if (image->GetWidth() <= 0 || image->GetHeight() <= 0)
	{
		AfxMessageBox(image->GetLastError());
		delete image;
		image = NULL;
		return FALSE;
	}

	//multiple images (TIFF/ICO)
	if (image->GetNumFrames()>1){
		if (AfxMessageBox("File with multiple images. Read all?",MB_OKCANCEL)==IDOK){
			
			int j; // points to the document name
			for(j=strlen(filename)-1;j>=0;j--){
				if (filename[j]=='\\'){	j++; break;	}
			}
			// create the documents for the other images
			for(int i=1;i<image->GetNumFrames();i++){
				CDemoDoc *NewDoc=(CDemoDoc*)((CDemoApp*)AfxGetApp())->demoTemplate->OpenDocumentFile(NULL);
				if (NewDoc)	{
					CxImage *newImage = new CxImage();
					newImage->SetFrame(i);
					newImage->ReadFile(filename,type);
					NewDoc->image = newImage;
					CString s;
					s.Format("%s (%d)",filename.Mid(j),i+1);
					NewDoc->SetTitle(s);
					NewDoc->UpdateAllViews(NULL,WM_USER_NEWIMAGE);
				}
			}
		}
	}

	UpdateAllViews(NULL,WM_USER_NEWIMAGE);

	return TRUE;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CString filename(lpszPathName);
	CString ext(FindExtension(filename));
	ext.MakeLower();
	if (ext == "")
		return FALSE;

	int type = 0;
	if (ext == "bmp")					type = CXIMAGE_FORMAT_BMP;
#if CXIMAGE_SUPPORT_JPG
	else if (ext=="jpg"||ext=="jpeg")	type = CXIMAGE_FORMAT_JPG;
#endif
#if CXIMAGE_SUPPORT_GIF
	else if (ext == "gif")				type = CXIMAGE_FORMAT_GIF;
#endif
#if CXIMAGE_SUPPORT_PNG
	else if (ext == "png")				type = CXIMAGE_FORMAT_PNG;
#endif
#if CXIMAGE_SUPPORT_MNG
	else if (ext == "mng")				type = CXIMAGE_FORMAT_MNG;
#endif
#if CXIMAGE_SUPPORT_ICO
	else if (ext == "ico")				type = CXIMAGE_FORMAT_ICO;
#endif
#if CXIMAGE_SUPPORT_TIF
	else if (ext=="tiff"||ext=="tif")	type = CXIMAGE_FORMAT_TIF;
#endif
	else return FALSE;

	if (image){
		if (image->SaveFile(filename, type)) return TRUE;
		else AfxMessageBox(image->GetLastError());
	}
	return FALSE;
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoDoc::DoSave(LPCTSTR pszPathName, BOOL bReplace /*=TRUE*/)
{
	if (!image)
		return FALSE;

	CString newName = pszPathName;
	BOOL bModified = IsModified();

	BOOL bSaveAs = FALSE;
	if (newName.IsEmpty())
		bSaveAs = TRUE;
	else if (!theApp.GetWritableType(image->GetFileType()))
		bSaveAs = TRUE;

	if (bSaveAs)
	{
		newName = m_strPathName;
		if (bReplace && newName.IsEmpty())
		{
			newName = m_strTitle;
			int iBad = newName.FindOneOf(_T(" #%;/\\"));    // dubious filename
			if (iBad != -1)
				newName.ReleaseBuffer(iBad);

			// append the default suffix if there is one
			newName += theApp.GetExtFromType(image->GetFileType());
		}

		int nDocType = image->GetFileType();
		if (!theApp.PromptForFileName(newName, 
			bReplace ? AFX_IDS_SAVEFILE : AFX_IDS_SAVEFILECOPY,
			OFN_HIDEREADONLY | OFN_PATHMUSTEXIST, FALSE, &nDocType))
		{
			return FALSE;       // don't even try to save
		}
	}

	BeginWaitCursor();
	if (!OnSaveDocument(newName))
	{
		if (pszPathName == NULL)
		{
			// be sure to delete the file
			TRY 
			{
				CFile::Remove(newName);
			}
			CATCH_ALL(e)
			{
				TRACE0("Warning: failed to delete file after failed SaveAs\n");
			}
			END_CATCH_ALL
		}
		EndWaitCursor();
		return FALSE;
	}

	EndWaitCursor();
	if (bReplace)
	{
		// Reset the title and change the document name
		SetPathName(newName, TRUE);
		ASSERT(m_strPathName == newName);       // must be set
	}
	else // SaveCopyAs
	{
		SetModifiedFlag(bModified);
	}
	return TRUE;        // success
}
/////////////////////////////////////////////////////////////////////////////
#define EPSILON (0.0000001)

int CDemoDoc::ComputePixel(float x, float y, float &x1, float &y1)
{
  double r, nn;

  if (x==0 && y==0) {
	 x1 = x;
	 y1 = y;
	 return 1;
  }

  nn = sqrt(x*x + y*y);
  r =  (fabs(x) > fabs(y)) ? fabs(nn/x): fabs(nn/y);

  x1 = (float)(r*x);
  y1 = (float)(r*y);

  return 1;
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::ComputeNewImage(void)
{
  CWaitCursor wait;
  DWORD x, y, x1, y1;
  float fx, fy, xmid, ymid, ar;
  CxImage *image2 = new CxImage(image);

  xmid = (float) (image->GetWidth()/2.0);
  ymid = (float) (image->GetHeight()/2.0);
  ar = (float)(image->GetHeight())/(float)(image->GetWidth());
  for (y=0; y<image->GetHeight(); y++) {
	 for (x=0; x<image->GetWidth(); x++) {
		ComputePixel(ar*(x-xmid), y-ymid, fx, fy);
		x1 = (int)(xmid+fx/ar);
		y1 = (int)(ymid+fy);
		if (image->IsInside(x1, y1))
		  image2->SetPixelColor(x, y, image->GetPixelColor(x1, y1));
		else
		  image2->SetPixelColor(x, y,RGB(255,255,255));
	 }
  }
  delete image;
  image = image2;
  UpdateAllViews(NULL);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnUpdateFileSaveAs(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((image != NULL));
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnUpdateFileSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(0);
//	pCmdUI->Enable((image != NULL)); //&& theApp.GetWritableType(image->GetFileType()));
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnStretchMode() 
{
	stretchMode = !stretchMode;
	UpdateAllViews(NULL);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnUpdateStretchMode(CCmdUI* pCmdUI) 
{
	pCmdUI->SetCheck(stretchMode);
	pCmdUI->Enable(TRUE);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnTransformEllipse() 
{
	SubmitUndo();
	ComputeNewImage();
	UpdateAllViews(NULL);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnWindowDuplicate() 
{
	CDemoDoc *NewDoc=(CDemoDoc*)((CDemoApp*)AfxGetApp())->demoTemplate->OpenDocumentFile(NULL); 

	if (NewDoc)	{
		CxImage *newImage = new CxImage(image);
		newImage->Copy(image);

		NewDoc->image = newImage;

		CString s;
		s.Format("Copy %d of %s",((CDemoApp*)AfxGetApp())->m_nDocCount++,GetTitle());
		NewDoc->SetTitle(s);
		NewDoc->UpdateAllViews(0,WM_USER_NEWIMAGE);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnEditCopy() 
{
	HANDLE hDIB = NULL;
	hDIB=image->CopyToHandle(hDIB);

	if (::OpenClipboard(AfxGetApp()->m_pMainWnd->GetSafeHwnd())) {
		if(::EmptyClipboard()) {
			if (::SetClipboardData(CF_DIB,hDIB) == NULL ) {
				AfxMessageBox( "Unable to set Clipboard data" );
			}
		}
	}
	CloseClipboard();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnUpdateEditUndo(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_UndoLevel>0);
	CString s;
	s.Format("Undo (%d)\tCtrl+Z",m_UndoLevel);
	pCmdUI->SetText(s);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnUpdateEditRedo(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable((m_UndoLevel<(MAX_UNDO_LEVELS))&&
				   (imageUndo[m_UndoLevel]!=0));
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnEditUndo() 
{
	m_UndoLevel--;
	CxImage* tmp = image;
	image=imageUndo[m_UndoLevel];
	imageUndo[m_UndoLevel]=tmp;

	UpdateAllViews(0,WM_USER_NEWIMAGE);
	UpdateStatusBar();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnEditRedo() 
{
	CxImage* tmp = image;
	image=imageUndo[m_UndoLevel];
	imageUndo[m_UndoLevel]=tmp;
	m_UndoLevel++;

	UpdateAllViews(0,WM_USER_NEWIMAGE);
	UpdateStatusBar();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::SubmitUndo()
{
	if (m_UndoLevel>=MAX_UNDO_LEVELS){	// Max Undo reached
		delete imageUndo[0];			// discard the early undo
		for(int i=1;i<MAX_UNDO_LEVELS;i++){
			imageUndo[i-1]=imageUndo[i]; //shift the history
		}
		imageUndo[MAX_UNDO_LEVELS-1]=0;	// clear the undo slot
		m_UndoLevel=MAX_UNDO_LEVELS-1;  // reposition at last level
	}
	// we must clear the "redo" history when a new action is performed
	for (int i=m_UndoLevel;i<MAX_UNDO_LEVELS;i++){
		if (imageUndo[i]){
			delete imageUndo[i];
			imageUndo[i]=0;
		}
	}
	// save the actual image in the undo history
	imageUndo[m_UndoLevel] = new CxImage(image);
	imageUndo[m_UndoLevel]->Copy(image);
	m_UndoLevel++;
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnCximageFlip() 
{
	if (image){
		SubmitUndo();
		image->Flip();
		UpdateAllViews(NULL);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnCximageMirror() 
{
	if (image){
		SubmitUndo();
		image->Mirror();
		UpdateAllViews(NULL);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnCximageNegative() 
{
	if (image){
		SubmitUndo();
		image->Negative();
		UpdateAllViews(NULL);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnCximageGrayscale() 
{
	if (image){
		SubmitUndo();
		image->GrayScale();
		UpdateAllViews(NULL);
	}
}
/////////////////////////////////////////////////////////////////////////////
void CDemoDoc::OnCximageRotate() 
{
	if (image){
		
		DlgRotate dlg;
		dlg.m_angle=(float)12.345;
		if (dlg.DoModal()==IDOK){
			SubmitUndo();
			SetCursor(LoadCursor(NULL,IDC_WAIT));
			image->Rotate(dlg.m_angle);
			SetCursor(LoadCursor(NULL,IDC_ARROW));
			
			UpdateAllViews(0,WM_USER_NEWIMAGE);
			UpdateStatusBar();
		}
	}
}
/////////////////////////////////////////////////////////////////////////////

void CDemoDoc::UpdateStatusBar()
{
	if (image){
		CString s;
		s.Format("(%dx%dx%d)",image->GetWidth(),image->GetHeight(),image->GetBpp());
		CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
		statusBar.SetPaneText(2, s);
	}
}
