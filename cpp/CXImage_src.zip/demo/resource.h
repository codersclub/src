//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by demo.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_DEMOTYPE                    129
#define IDB_TEST_BITMAP                 130
#define IDB_BITMAP1                     131
#define IDD_DIALOG1                     132
#define IDR_ICO1                        135
#define IDR_GIF1                        136
#define IDR_PNG1                        137
#define IDC_EDIT1                       1000
#define ID_STRETCH_MODE                 32771
#define ID_TRANSFORM_ELLIPSE            32772
#define ID_IMAGE_FROM_BITMAP            32773
#define ID_CXIMAGE_MIRROR               32774
#define ID_CXIMAGE_FLIP                 32775
#define ID_WINDOW_DUPLICATE             32776
#define ID_CXIMAGE_NEGATIVE             32777
#define ID_CXIMAGE_GRAYSCALE            32778
#define ID_CXIMAGE_ROTATE               32779
#define ID_CXIMAGE_LOADJPEGRESOURCE     32780
#define ID_CXIMAGE_LOADICONRESOURCE     32781
#define ID_CXIMAGE_LOADGIFRESOURCE      32782
#define ID_CXIMAGE_LOADPNGRESOURCE      32783
#define ID_INDICATOR1                   59142
#define ID_INDICATOR2                   59143
#define ID_INDICATOR3                   59144

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        138
#define _APS_NEXT_COMMAND_VALUE         32784
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
