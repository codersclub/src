// demoView.cpp : implementation of the CDemoView class
//

#include "stdafx.h"
#include "ximage.h"
#include "MainFrm.h"
#include "demo.h"

#include "demoDoc.h"
#include "demoView.h"
#include "memdc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDemoView

IMPLEMENT_DYNCREATE(CDemoView, CScrollView)

BEGIN_MESSAGE_MAP(CDemoView, CScrollView)
	//{{AFX_MSG_MAP(CDemoView)
	ON_WM_MOUSEMOVE()
	ON_WM_ERASEBKGND()
	ON_WM_SETFOCUS()
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDemoView construction/destruction
CDemoView::CDemoView()
{
	SetScrollSizes(MM_TEXT, CSize(0, 0));
   VERIFY(m_brHatch.CreateHatchBrush(HS_DIAGCROSS, RGB(191, 191, 191)));
}
/////////////////////////////////////////////////////////////////////////////
CDemoView::~CDemoView()
{
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CScrollView::PreCreateWindow(cs);
}
/////////////////////////////////////////////////////////////////////////////
// CDemoView drawing
void CDemoView::OnDraw(CDC* pDC)
{
	CDemoDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	BOOL bPrinting = pDC->IsPrinting();

	CMemDC* pMemDC = NULL;
	if (!bPrinting) pDC = pMemDC = new CMemDC(pDC);

	if (!bPrinting && m_brHatch.m_hObject){
		CRect rect;
		GetClientRect(&rect);
		rect.right  = max(rect.right , m_totalDev.cx);
		rect.bottom = max(rect.bottom, m_totalDev.cy);
		m_brHatch.UnrealizeObject();
		CPoint pt(0, 0);
		pDC->LPtoDP(&pt);
		pt = pDC->SetBrushOrg(pt.x % 8, pt.y % 8);
		CBrush* old = pDC->SelectObject(&m_brHatch);
		pDC->FillRect(&rect, &m_brHatch);
		pDC->SelectObject(old);
	}

	CxImage* ima = pDoc->GetImage(); 
	if (ima) {

		if (bPrinting) {
			ima->Stretch(pDC->GetSafeHdc(), CRect(0, 0, pDC->GetDeviceCaps(HORZRES), pDC->GetDeviceCaps(VERTRES)));
		}
		else if (pDoc->GetStretchMode()) {
			CRect rect;
			GetClientRect(&rect);
			SetScrollSizes(MM_TEXT,	CSize(0,0));
			ima->Stretch(pDC->GetSafeHdc(), rect);
		} else {
			SetScrollSizes(MM_TEXT,	CSize(ima->GetWidth(), ima->GetHeight()));
			ima->Draw(pDC->GetSafeHdc());
		}
	}

	delete pMemDC;
}
/////////////////////////////////////////////////////////////////////////////
// CDemoView printing
BOOL CDemoView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	pInfo->SetMaxPage(1);
	return DoPreparePrinting(pInfo);
}
/////////////////////////////////////////////////////////////////////////////
void CDemoView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}
/////////////////////////////////////////////////////////////////////////////
void CDemoView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}
/////////////////////////////////////////////////////////////////////////////
// CDemoView diagnostics
#ifdef _DEBUG
void CDemoView::AssertValid() const
{
	CScrollView::AssertValid();
}
/////////////////////////////////////////////////////////////////////////////
void CDemoView::Dump(CDumpContext& dc) const
{
	CScrollView::Dump(dc);
}
/////////////////////////////////////////////////////////////////////////////
CDemoDoc* CDemoView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CDemoDoc)));
	return (CDemoDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CDemoView message handlers
void CDemoView::OnInitialUpdate() 
{
	CScrollView::OnInitialUpdate();
	
	if (GetDocument()->GetImage())
		SetScrollSizes(MM_TEXT,
		  CSize(GetDocument()->GetImage()->GetWidth(), GetDocument()->GetImage()->GetHeight()));
}
/////////////////////////////////////////////////////////////////////////////
void CDemoView::OnMouseMove(UINT nFlags, CPoint point) 
{
	// We get the RGB values at the point the user selects
	point+=GetScrollPosition();
	char s[80];
	RGBQUAD rgb={0,0,0};
	float x = (float)point.x;
	float y = (float)point.y;
	long yflip;

	CRect rect;
	GetClientRect(&rect);
	int width = rect.right - rect.left;
	int height = rect.bottom - rect.top;

	CDemoDoc* pDoc = GetDocument();
	CxImage*  ima  = pDoc->GetImage();

	if (!ima)	return;

	if (pDoc->GetStretchMode())	{
		x *= ima->GetWidth()/(float)width;
		y *= ima->GetHeight()/(float)height;
	}
	if (ima->IsInside((int)x, (int)y))	{
		yflip=(long)(ima->GetHeight() - y - 1);
		sprintf(s,"X = %.0f Y = %.0f  Idx=%d", x, y, ima->GetPixelIndex((long)x, yflip));
		rgb=ima->GetPixelColor((long)x, yflip);
		sprintf(&s[strlen(s)],"  RGB = (%d, %d, %d)", rgb.rgbRed , rgb.rgbGreen , rgb.rgbBlue );

		//Enable these lines if you want draw over the image	
		//if ((nFlags & MK_LBUTTON)==MK_LBUTTON){
		//	ima->SetPixelColor((long)x,yflip,RGB(rand()/(RAND_MAX/256),rand()/(RAND_MAX/256),rand()/(RAND_MAX/256)));
		//	Invalidate(0);
		//}
	
	} else strcpy(s," ");
	
	CStatusBar& statusBar = ((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetStatusBar();
	statusBar.SetPaneText(0, s);
	
	CScrollView::OnMouseMove(nFlags, point);
}
/////////////////////////////////////////////////////////////////////////////
BOOL CDemoView::OnEraseBkgnd(CDC* pDC) 
{
	return 1;
}
/////////////////////////////////////////////////////////////////////////////
void CDemoView::OnSetFocus(CWnd* pOldWnd) 
{
	CScrollView::OnSetFocus(pOldWnd);
	
	CDemoDoc* pDoc = GetDocument();
	if (pDoc) pDoc->UpdateStatusBar();
}
/////////////////////////////////////////////////////////////////////////////

void CDemoView::OnUpdate(CView* pSender, LPARAM lHint, CObject* pHint) 
{
	switch (lHint)
	{
	case CDemoDoc::WM_USER_NEWIMAGE:
		{
		CDemoDoc* pDoc = GetDocument();
		CxImage*  ima  = pDoc->GetImage();
		int x=(int)ima->GetWidth();
		int y=(int)ima->GetHeight();
		SetScrollSizes(MM_TEXT,	CSize(x,y));
		CWnd* pFrame=GetParentFrame();
		if (!(pFrame->IsIconic()||pFrame->IsZoomed())){
			RECT rClient,rMainCl,rFrame,rMainFr;
			((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetClientRect(&rMainCl);
			((CMainFrame *)(AfxGetApp()->m_pMainWnd))->GetWindowRect(&rMainFr);
			pFrame->GetClientRect(&rClient);
			pFrame->GetWindowRect(&rFrame);
			pFrame->SetWindowPos(0,0,0,
				(4+rFrame.right-rFrame.left-rClient.right+rClient.left)+
				min(rMainCl.right-(rFrame.left-rMainFr.left+12),x),
				(4+rFrame.bottom-rFrame.top-rClient.bottom+rClient.top)+
				min(rMainCl.bottom-(rFrame.top-rMainFr.top+12),y),
				SWP_NOMOVE|SWP_NOZORDER);
			//ResizeParentToFit(1);
		}
		break;
		}
	default:
		break;
	}
	CScrollView::OnUpdate(pSender, lHint, pHint);
}
