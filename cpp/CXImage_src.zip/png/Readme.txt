README for libpng 1.0.12 - June 8, 2001 (shared library 2.1)
See the note about version numbers near the top of png.h

See INSTALL for instructions on how to install libpng.

Libpng comes in two distribution formats.  Get libpng-*.tar.gz if you
want UNIX-style line endings in the text files, or lpng*.zip if you want
DOS-style line endings.

Version 0.89 was the first official release of libpng.  Don't let the
fact that it's the first release fool you.  The libpng library has been in
extensive use and testing since mid-1995.  By late 1997 it had
finally gotten to the stage where there hadn't been significant
changes to the API in some time, and people have a bad feeling about
libraries with versions < 1.0.  Version 1.0.0 was released in
March 1998.

****
Note that some of the changes to the png_info structure render this
version of the library binary incompatible with libpng-0.89 or
earlier versions if you are using a shared library.  The type of the
"filler" parameter for png_set_filler() has changed from png_byte to
png_uint_32, which will affect shared-library applications that use
this function.

To avoid problems with changes to the internals of png_info_struct,
new APIs have been made available in 0.95 to avoid direct application
access to info_ptr.  These functions are the png_set_<chunk> and
png_get_<chunk> functions.  These functions should be used when
accessing/storing the info_struct data, rather than manipulating it
directly, to avoid such problems in the future.

It is important to note that the APIs do not make current programs
that access the info struct directly incompatible with the new
library.  However, it is strongly suggested that new programs use
the new APIs (as shown in example.c and pngtest.c), and older programs
be converted to the new format, to facilitate upgrades in the future.
****

Additions since 0.90 include the ability to compile libpng as a
Windows DLL, and new APIs for accessing data in the info struct.
Experimental functions include the ability to set weighting and cost
factors for row filter selection, direct reads of integers from buffers
on big-endian processors that support misaligned data access, faster
methods of doing alpha composition, and more accurate 16->8 bit color
conversion.

The additions since 0.89 include the ability to read from a PNG stream
which has had some (or all) of the signature bytes read by the calling
application.  This also allows the reading of embedded PNG streams that
do not have the PNG file signature.  As well, it is now possible to set
the library action on the detection of chunk CRC errors.  It is possible
to set different actions based on whether the CRC error occurred in a
critical or an ancillary chunk.

The changes made to the library, and bugs fixed are based on discussions
on the PNG implementation mailing list <png-implement@ccrc.wustl.edu>
and not on material submitted privately to Guy, Andreas, or Glenn.  They will
forward any good suggestions to the list.

For a detailed description on using libpng, read libpng.txt.  For
examples of libpng in a program, see example.c and pngtest.c.  For usage
information and restrictions (what little they are) on libpng, see
png.h.  For a description on using zlib (the compression library used by
libpng) and zlib's restrictions, see zlib.h

I have included a general makefile, as well as several machine and
compiler specific ones, but you may have to modify one for your own needs.

You should use zlib 1.0.4 or later to run this, but it MAY work with
versions as old as zlib 0.95.  Even so, there are bugs in older zlib
versions which can cause the output of invalid compression streams for
some images.  You will definitely need zlib 1.0.4 or later if you are
taking advantage of the MS-DOS "far" structure allocation for the small
and medium memory models.  You should also note that zlib is a
compression library that is useful for more things than just PNG files.
You can use zlib as a drop-in replacement for fread() and fwrite() if
you are so inclined.

zlib should be available at the same place that libpng is.
If not, it should be at ftp.uu.net in /graphics/png
Eventually, it will be at ftp.uu.net in /pub/archiving/zip/zlib

You may also want a copy of the PNG specification.  It is available
as an RFC and a W3C Recommendation.  Failing
these resources you can try ftp.uu.net in the /graphics/png directory.

This code is currently being archived at ftp.uu.net in the
/graphics/png directory, and on CompuServe, Lib 20 (PNG SUPPORT)
at GO GRAPHSUP.  If you can't find it in any of those places,
e-mail me, and I'll help you find it.

If you have any code changes, requests, problems, etc., please e-mail
them to me.  Also, I'd appreciate any make files or project files,
and any modifications you needed to make to get libpng to compile,
along with a #define variable to tell what compiler/system you are on.
If you needed to add transformations to libpng, or wish libpng would
provide the image in a different way, drop me a note (and code, if
possible), so I can consider supporting the transformation.
Finally, if you get any warning messages when compiling libpng
(note: not zlib), and they are easy to fix, I'd appreciate the
fix.  Please mention "libpng" somewhere in the subject line.  Thanks.

This release was created and will be supported by myself (of course
based in a large way on Guy's and Andreas' earlier work), and the PNG group.

randeg@alum.rpi.edu
png-implement@ccrc.wustl.edu

You can't reach Guy, the original libpng author, at the addresses
given in previous versions of this document.  He and Andreas will read mail
addressed to the png-implement list, however.

Please do not send general questions about PNG.  Send them to
the address in the specification (png-group@w3.org).  At the same
time, please do not send libpng questions to that address, send them to me
or to png-implement@ccrc.wustl.edu.  I'll
get them in the end anyway.  If you have a question about something
in the PNG specification that is related to using libpng, send it
to me.  Send me any questions that start with "I was using libpng,
and ...".  If in doubt, send questions to me.  I'll bounce them
to others, if necessary.

Please do not send suggestions on how to change PNG.  We have
been discussing PNG for three years now, and it is official and
finished.  If you have suggestions for libpng, however, I'll
gladly listen.  Even if your suggestion is not used for version
1.0, it may be used later.

Files in this distribution:

      ANNOUNCE      =>  Announcement of this version, with recent changes
      CHANGES       =>  Description of changes between libpng versions
      KNOWNBUG      =>  List of known bugs and deficiencies
      LICENSE       =>  License to use and redistribute libpng
      README        =>  This file
      TODO          =>  Things not implemented in the current library
      Y2KINFO       =>  Statement of Y2K compliance
      example.c     =>  Example code for using libpng functions
      libpng.3      =>  manual page for libpng (includes libpng.txt)
      libpng.txt    =>  Description of libpng and its functions
      libpngpf.3    =>  manual page for libpng's private functions
      png.5         =>  manual page for the PNG format
      png.c         =>  Basic interface functions common to library
      png.h         =>  Library function and interface declarations
      pngconf.h     =>  System specific library configuration
      pngasmrd.h    =>  Header file for assembler-coded functions
      pngerror.c    =>  Error/warning message I/O functions
      pngget.c      =>  Functions for retrieving info from struct
      pngmem.c      =>  Memory handling functions
      pngbar.png    =>  PNG logo, 88x31
      pngnow.png    =>  PNG logo, 98x31
      pngpread.c    =>  Progressive reading functions
      pngread.c     =>  Read data/helper high-level functions
      pngrio.c      =>  Lowest-level data read I/O functions
      pngrtran.c    =>  Read data transformation functions
      pngrutil.c    =>  Read data utility functions
      pngset.c      =>  Functions for storing data into the info_struct
      pngtest.c     =>  Library test program
      pngtest.png   =>  Library test sample image
      pngtrans.c    =>  Common data transformation functions
      pngwio.c      =>  Lowest-level write I/O functions
      pngwrite.c    =>  High-level write functions
      pngwtran.c    =>  Write data transformations
      pngwutil.c    =>  Write utility functions
      contrib       =>  Contributions
       gregbook         =>  source code for PNG reading and writing, from
                            Greg Roelofs' "PNG: The Definitive Guide",
                            O'Reilly, 1999
       msvctest     =>  Builds and runs pngtest using a MSVC workspace
       pngminus     =>  Simple pnm2png and png2pnm programs
       pngsuite     =>  Test images
       visupng      =>  Contains a MSVC workspace for VisualPng
      projects      =>  Contains project files and workspaces for building DLL
       beos             =>  Contains a Beos workspace for building libpng
       borland          =>  Contains a Borland workspace for building libpng
                            and zlib
       msvc             =>  Contains a Microsoft Visual C++ (MSVC) workspace
                            for building libpng and zlib
       netware.txt      =>  Contains instructions for downloading a set of
                            project files for building libpng and zlib on
                            Netware.
       wince.txt        =>  Contains instructions for downloading a Microsoft
                            Visual C++ (Windows CD Toolkit) workspace for
                            building libpng and zlib on WindowsCE
      scripts       =>  Directory containing scripts for building libpng:
       descrip.mms      =>  VMS makefile for MMS or MMK
       makefile.std     =>  Generic UNIX makefile (cc, creates static libpng.a)
       makefile.linux   =>  Linux/ELF makefile
                            (gcc, creates libpng.so.2.1.0.12)
       makefile.gcmmx   =>  Linux/ELF makefile (gcc, creates
                            libpng.so.2.1.0.12, uses assembler code
                            tuned for Intel MMX platform)
       makefile.gcc     =>  Generic makefile (gcc, creates static libpng.a)
       makefile.knr     =>  Archaic UNIX Makefile that converts files with
                            ansi2knr (Requires ansi2knr.c from
                            ftp://ftp.cs.wisc.edu/ghost)
       makefile.aix     =>  AIX makefile
       makefile.cygwin  =>  Cygwin/gcc makefile
       makefile.dec     =>  DEC Alpha UNIX makefile
       makefile.hpgcc   =>  HPUX makefile using gcc
       makefile.hpux    =>  HPUX (10.20 and 11.00) makefile
       makefile.ibmc    =>  IBM C/C++ version 3.x for Win32 and OS/2 (static)
       makefile.intel   =>  Intel C/C++ version 4.0 and later
       libpng.icc       =>  Project file, IBM VisualAge/C++ 4.0 or later
       makefile.macosx  =>  MACOS X Makefile
       makefile.netbsd  =>  NetBSD/cc makefile, uses PNGGCCRD
       makefile.sgi     =>  Silicon Graphics IRIX (cc, creates static lib)
       makefile.sggcc   =>  Silicon Graphics (gcc, creates libpng.so.2.1.0.12)
       makefile.sunos   =>  Sun makefile
       makefile.solaris =>  Solaris 2.X makefile
                            (gcc, creates libpng.so.2.1.0.12)
       makefile.sco     =>  For SCO OSr5  ELF and Unixware 7 with Native cc
       makefile.mips    =>  MIPS makefile
       makefile.acorn   =>  Acorn makefile
       makefile.amiga   =>  Amiga makefile
       smakefile.ppc    =>  AMIGA smakefile for SAS C V6.58/7.00 PPC
                            compiler (Requires SCOPTIONS, copied from
                            scripts/SCOPTIONS.ppc)
       makefile.atari   =>  Atari makefile
       makefile.beos    =>  BEOS makefile for X86
       makefile.bor     =>  Borland makefile (uses bcc)
       makefile.bc32    =>  32-bit Borland C++ (all modules compiled in C mode)
       makefile.bd32    =>  To make a png32bd.dll with Borland C++ 4.5
       makefile.tc3     =>  Turbo C 3.0 makefile
       makefile.dj2     =>  DJGPP 2 makefile
       makefile.msc     =>  Microsoft C makefile
       makefile.vcawin32 => makefile for Microsoft Visual C++ 5.0 and
                            later (uses assembler code tuned for Intel MMX
                            platform)
       makefile.vcwin32 =>  makefile for Microsoft Visual C++ 4.0 and
                            later (does not use assembler code)
       makefile.os2     =>  OS/2 Makefile (gcc and emx, requires pngos2.def)
       pngos2.def       =>  OS/2 module definition file used by makefile.os2
       makefile.watcom  =>  Watcom 10a+ Makefile, 32-bit flat memory model
       makevms.com      =>  VMS build script
       pngdef.pas       =>  Defines for a png32bd.dll with Borland C++ 4.5
       SCOPTIONS.ppc    =>  Used with smakefile.ppc

Good luck, and happy coding.

-Glenn Randers-Pehrson
 Internet: randeg@alum.rpi.edu

-Andreas Eric Dilger
 Internet: adilger@enel.ucalgary.ca
 Web: http://www-mddsp.enel.ucalgary.ca/People/adilger/

-Guy Eric Schalnat
 (formerly of Group 42, Inc)
 Internet: gschal@infinet.com
