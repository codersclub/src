/*
 * File:	imamng.cc
 * Purpose:	MNG Image Class
 * Author:	ing.davide.pizzolato@libero.it
 * Created:	2001
 */

#include "ximamng.h"

#if CXIMAGE_SUPPORT_MNG

#include "ximaiter.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


bool CxImageMNG::ReadFile(const char * imageFileName)
{
	strcpy(info.szLastError,"Read MNG unsupported");
	return false;
}

/////////////////////////////////////////////////////////////
bool CxImageMNG::SaveFile(const char* imageFileName)
{
	strcpy(info.szLastError,"Save MNG unsupported");
	return false;
}


#endif // CXIMAGE_SUPPORT_MNG

