/*
 * File:	ImaMNG.h
 * Purpose:	Declaration of the MNG Image Class
 * Author:	ing.davide.pizzolato@libero.it
 * Created:	2001
 */
#if !defined(__ximaMNG_h)
#define __ximaMNG_h

#include "ximage.h"

#if CXIMAGE_SUPPORT_MNG

#define MNG_INTERNAL_MEMMNGMT
#define MNG_SUPPORT_READ
#define MNG_SUPPORT_WRITE
#define MNG_ACCESS_CHUNKS
#define MNG_STORE_CHUNKS
#define MNG_NO_CMS
#define MNG_SUPPORT_DISPLAY

extern "C" {
#include "libmng.h"
}

class CxImageMNG: public CxImage
{
public:
	CxImageMNG(): CxImage() {}

	bool ReadFile(const char * imageFileName);
	bool SaveFile(const char * imageFileName);
};

#endif

#endif

