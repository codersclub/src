#ifndef _PWDSPYHK_H_
#define _PWDSPYHK_H_

#define IPC_CUSTOM_MSG		_T("{34F673E2-878F-11D5-B98A-00B0D07B8C7C}")
#define PWDSPY_HOOK_DLL		_T("PwdSpyHk.dll")

#ifdef PWDSPYHK_EXPORTS
#define PWDSPYHK_API __declspec(dllexport)
#else
#define PWDSPYHK_API __declspec(dllimport)
#endif

// Exported functions called from PasswordSpy
PWDSPYHK_API bool WINAPI InstallHook(const DWORD dwThreadId);
PWDSPYHK_API bool WINAPI RemoveHook(void);
PWDSPYHK_API bool WINAPI ScanPassword(const HWND hWnd, const HWND hPwdSpyWnd);

// Functions called from the hooked process
LRESULT WINAPI GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam);
void ExtractPassword(const HWND hWnd, const HWND hPwdSpyWnd);

#endif
