// If you're compiling this using VC++5 you must define STRICT.
// If you're using VC++6 it works without this define, so
// obviously Microsoft changed the header files to define it
// for you.  For more info see the following article in the MSDN:
//   TN012: Using MFC with Windows 3.1 Robustness Features
#ifndef STRICT
#define STRICT 1
#endif

#include <windows.h>
#include <tchar.h>
#include <crtdbg.h>

#include "PwdSpyHk.h"
#include "IPC.h"

// Global variables
static HHOOK g_hHook = NULL;				// Handle to the hook
static DWORD g_dwThreadId = 0;				// Hooked thread
static HINSTANCE g_hinstDLL = NULL;			// Handle to this DLL
static CIPC g_obIPC;						// Shared resources used to transfer data from PwdSpy to the hook code

static UINT g_wmScanPassword = RegisterWindowMessage(IPC_CUSTOM_MSG);

// Since this DLL is loaded by both PasswordSpy and the remote (or hooked) process,
// each function in this DLL is listed which of the two processes calls that function.

//***********************************************
BOOL WINAPI DllMain(HINSTANCE hinstDLL, DWORD fdwReason, LPVOID lpvReserved)
{
	// This function is called from both processes

	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		// The DLL is being mapped into the process's address space.
		g_hinstDLL = hinstDLL;

		// This call disables the DLL_THREAD_ATTACH and DLL_THREAD_DETACH
		// messages.  DllMain should not get called with those messages.
		DisableThreadLibraryCalls(GetModuleHandle(PWDSPY_HOOK_DLL));
		break;
	case DLL_THREAD_ATTACH:
		// A thread is being created.
		break;
	case DLL_THREAD_DETACH:
		// A thread is exiting cleanly.
		break;
	case DLL_PROCESS_DETACH:
		// The DLL is being unmapped from the process's address space.
		break;
	}
	return TRUE;
}

//***********************************************
bool WINAPI InstallHook(const DWORD dwThreadId)
{
	// This function is called from PasswordSpy only

	_ASSERTE(dwThreadId);

	bool bSuccess = false;

	try
	{
		// Are we already hooked on that thread?
		if(g_dwThreadId == dwThreadId)
			return true;

		// If we're hooked on a different thread, unhook first
		if(g_dwThreadId != dwThreadId && g_hHook != NULL)
			RemoveHook();

		// Save the threadId, and continue if it's not 0
		if((g_dwThreadId = dwThreadId) != 0)
		{
			// Lock the shared resources
			g_obIPC.Lock();
			g_obIPC.CreateIPCMMF();

			g_hHook = SetWindowsHookEx(WH_GETMESSAGE, GetMsgProc, g_hinstDLL, g_dwThreadId);
			if(g_hHook != NULL)
			{
				// Into the shared resource, store the handle to the hook.
				DWORD dwData = (DWORD)g_hHook;
				g_obIPC.WriteIPCMMF((LPBYTE)&dwData, sizeof(dwData));
				bSuccess = true;

				// Force a benign message to the thread's queue
				// so that the hook function gets called.
				PostThreadMessage(dwThreadId, WM_NULL, 0, 0);
			}
		}
	}
	catch(...) {}

	// Ensure that we unlock the shared resources
	g_obIPC.Unlock();

	return bSuccess;
}

//***********************************************
bool WINAPI RemoveHook(void)
{
	// This function is called from PasswordSpy only

	bool bSuccess = false;

	try
	{
		if(g_hHook != NULL)
		{
			bSuccess = UnhookWindowsHookEx(g_hHook) ? true : false;
			g_hHook = NULL;
			g_dwThreadId = 0;
		}
	}
	catch(...) {}

	return bSuccess;
}

//***********************************************
bool WINAPI ScanPassword(const HWND hWnd, const HWND hPwdSpyWnd)
{
	// This function is called from PasswordSpy only

	bool bSuccess = false;

	try
	{
		if(g_dwThreadId != 0 && hWnd != NULL && hPwdSpyWnd != NULL)
		{
			PostThreadMessage(g_dwThreadId, g_wmScanPassword, (WPARAM)hWnd, (LPARAM)hPwdSpyWnd);
			bSuccess = true;
		}
	}
	catch(...) {}

	return bSuccess;
}

//***********************************************
LRESULT WINAPI GetMsgProc(int nCode, WPARAM wParam, LPARAM lParam)
{
	// This function is called from the HOOKED process only

	try
	{
		if(g_hHook == NULL)
		{	// Read the data from the shared resources
			DWORD dwData = 0, dwSize = sizeof(dwData);
			g_obIPC.Lock();
			g_obIPC.OpenIPCMMF();
			g_obIPC.ReadIPCMMF((LPBYTE)&dwData, dwSize);
			g_obIPC.Unlock();

			g_hHook = (HHOOK)dwData;
		}

		// Ignore the message if the nCode is less than zero
		if(nCode >= 0)
		{
			HWND hWnd = NULL;		// Handle to the window with the password
			HWND hPwdSpyWnd = NULL;	// Handle to the PasswordSpy window, so we can SendMessage back
			MSG *pMsg = (MSG*)lParam;

			// Is the message our custom registered message?
			if(pMsg->message == g_wmScanPassword)
			{
				hWnd = (HWND)pMsg->wParam;
				hPwdSpyWnd = (HWND)pMsg->lParam;

				ExtractPassword(hWnd, hPwdSpyWnd);
			}
		}
	}
	catch(...) {}

	// Always call the next hook in the chain
	return CallNextHookEx(g_hHook, nCode, wParam, lParam);
}

//***********************************************
void ExtractPassword(const HWND hWnd, const HWND hPwdSpyWnd)
{
	// This function is called from the HOOKED process only

	_ASSERTE(hWnd);
	_ASSERTE(hPwdSpyWnd);

	try
	{
		TCHAR szBuffer[256] = {_T('\0')};
		SendMessage(hWnd, WM_GETTEXT, sizeof(szBuffer) / sizeof(TCHAR), (LPARAM)szBuffer);

		// Use a WM_COPYDATA message to send the password back to PasswordSpy
		COPYDATASTRUCT cds = {0};
		cds.dwData = (DWORD)hWnd;
		cds.cbData = (lstrlen(szBuffer) + 1) * sizeof(TCHAR);
		cds.lpData = szBuffer;

		SendMessage(hPwdSpyWnd, WM_COPYDATA, (WPARAM)hWnd, (LPARAM)&cds);
	}
	catch(...) {}
}
