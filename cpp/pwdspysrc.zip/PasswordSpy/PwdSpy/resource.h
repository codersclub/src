//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PwdSpy.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDM_ALWAYS_ON_TOP               0x0020
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_PWDSPY_DIALOG               102
#define IDS_ALWAYS_ON_TOP               102
#define IDS_URL                         103
#define IDS_YES                         104
#define IDS_NO                          105
#define IDS_NOT_AVAILABLE               106
#define IDS_MAYBE                       107
#define IDR_MAINFRAME                   128
#define IDI_LOOK_ICON                   129
#define IDI_BLANK_ICON                  131
#define IDI_SMALLICON                   133
#define IDC_LOOK_CUR                    134
#define IDC_EDIT_MOUSEPOS               1000
#define IDC_EDIT_HWND                   1001
#define IDC_EDIT_WNDCLASS               1002
#define IDC_EDIT_ISPWD                  1003
#define IDC_EDIT_PWD                    1004
#define IDC_LOOK                        1005
#define IDC_EDIT_CAPTION                1006
#define IDC_URL                         1007
#define IDC_COMBO_LEVEL                 1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
