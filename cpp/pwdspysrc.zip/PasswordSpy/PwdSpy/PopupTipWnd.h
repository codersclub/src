// PopupTipWnd.h : header file
//

#if !defined(AFX_POPUPTIPWND_H__E0803970_1CAC_11D5_B8F7_00B0D07B8C7C__INCLUDED_)
#define AFX_POPUPTIPWND_H__E0803970_1CAC_11D5_B8F7_00B0D07B8C7C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define PWDSPY_POPUP_TIP_CLASSNAME	_T("PasswordSpy Popup Tip")
#define BORDER_X	5
#define BORDER_Y	5

/////////////////////////////////////////////////////////////////////////////
// CPopupTipWnd window

class CPopupTipWnd : public CWnd
{
// Construction
public:
	CPopupTipWnd();
	virtual ~CPopupTipWnd();

	static bool RegisterWindowClass(void);

	virtual BOOL Create(CWnd *pParentWnd);

	void ShowPopupWindow(CString strText, CPoint point, CRect rect);
	void HidePopupWindow(void);

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPopupTipWnd)
	//}}AFX_VIRTUAL

	// Generated message map functions
protected:
	static bool s_bRegistered;
	CRect m_rectPos;
	CWnd *m_pParentWnd;

	//{{AFX_MSG(CPopupTipWnd)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POPUPTIPWND_H__E0803970_1CAC_11D5_B8F7_00B0D07B8C7C__INCLUDED_)
