// PwdSpy.h : main header file for the PWDSPY application
//

#if !defined(AFX_PWDSPY_H__BECC53B5_6A53_11D3_8861_000000000000__INCLUDED_)
#define AFX_PWDSPY_H__BECC53B5_6A53_11D3_8861_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols
#include "SingleInstance.h"

#define MUTEX_NAME		_T("{34F673E3-878F-11D5-B98A-00B0D07B8C7C}")
#define CUSTOM_WNDMSG	_T("{34F673E4-878F-11D5-B98A-00B0D07B8C7C}")

/////////////////////////////////////////////////////////////////////////////
// CPwdSpyApp:
// See PwdSpy.cpp for the implementation of this class
//

class CPwdSpyApp : public CWinApp
{
public:
	CPwdSpyApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPwdSpyApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPwdSpyApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

protected:
	CSingleInstance m_si;
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PWDSPY_H__BECC53B5_6A53_11D3_8861_000000000000__INCLUDED_)
