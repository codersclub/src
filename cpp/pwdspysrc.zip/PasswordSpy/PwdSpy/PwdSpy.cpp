// PwdSpy.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "PwdSpy.h"
#include "PwdSpyDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPwdSpyApp

BEGIN_MESSAGE_MAP(CPwdSpyApp, CWinApp)
	//{{AFX_MSG_MAP(CPwdSpyApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPwdSpyApp construction

CPwdSpyApp::CPwdSpyApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CPwdSpyApp object

CPwdSpyApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPwdSpyApp initialization

BOOL CPwdSpyApp::InitInstance()
{
	if(!m_si.Create(MUTEX_NAME))
	{
		// Find the other running instance of PasswordSpy and bring it to the front
		UINT nMsgID = RegisterWindowMessage(CUSTOM_WNDMSG);
		PostMessage(HWND_BROADCAST, nMsgID, 0, 0);
		return FALSE;
	}

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CPwdSpyDlg dlg;
	m_pMainWnd = &dlg;
	dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
