// PopupTipWnd.cpp : implementation file
//

#include "stdafx.h"
#include "PwdSpy.h"
#include "PopupTipWnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

// Register control during class initialization
bool CPopupTipWnd::s_bRegistered = CPopupTipWnd::RegisterWindowClass();

/////////////////////////////////////////////////////////////////////////////
// CPopupTipWnd

CPopupTipWnd::CPopupTipWnd()
{
	m_pParentWnd = NULL;
}

CPopupTipWnd::~CPopupTipWnd()
{
}

BEGIN_MESSAGE_MAP(CPopupTipWnd, CWnd)
	//{{AFX_MSG_MAP(CPopupTipWnd)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPopupTipWnd message handlers

//***********************************************
BOOL CPopupTipWnd::Create(CWnd *pParentWnd)
{
	_ASSERTE(pParentWnd);

	m_pParentWnd = pParentWnd;

	DWORD dwStyle = WS_BORDER | WS_POPUP;
	DWORD dwExStyle = WS_EX_TOOLWINDOW | WS_EX_TOPMOST;

	BOOL bCreated = CreateEx(dwExStyle,
		PWDSPY_POPUP_TIP_CLASSNAME,
		NULL,
		dwStyle,
		0, 0, 0, 0,
		NULL, NULL, NULL);

	return bCreated;
}

//***********************************************
bool CPopupTipWnd::RegisterWindowClass(void)
{
	WNDCLASS wndcls = {0};
	wndcls.style = CS_SAVEBITS | CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
	wndcls.lpfnWndProc = ::DefWindowProc;
	wndcls.hCursor = (HCURSOR)::LoadImage(NULL, IDC_ARROW, IMAGE_CURSOR, 0, 0, LR_DEFAULTSIZE);
	wndcls.hbrBackground = (HBRUSH)(COLOR_INFOBK + 1);
	wndcls.lpszClassName = PWDSPY_POPUP_TIP_CLASSNAME;

	if(!::RegisterClass(&wndcls))
	{
		AfxThrowResourceException();
		return false;
	}

	return true;
}

//***********************************************
void CPopupTipWnd::ShowPopupWindow(CString strText, CPoint point, CRect rect)
{
	// If there is no password, instead hide the window and be done with it
	if(strText.IsEmpty())
	{
		HidePopupWindow();
		return;
	}

	CClientDC dc(this);

	// Use same font as parent window
	CFont *pOldFont = dc.SelectObject(m_pParentWnd->GetFont());

	// Calculate the window size.
	CSize sizeText = dc.GetTextExtent(strText);
	CSize sizeWindow;
	sizeWindow.cx = sizeText.cx + 2 * BORDER_X;
	sizeWindow.cy = sizeText.cy + 2 * BORDER_Y;

	// Draw information in window
	dc.SetBkMode(TRANSPARENT);
	dc.DrawText(strText, CRect(0, 0, sizeWindow.cx, sizeWindow.cy), DT_CENTER | DT_VCENTER | DT_SINGLELINE);
	dc.SelectObject(pOldFont);

	// Calculate window rectangle position on screen
	CRect rectWindow;
	rectWindow.left = rect.left;
	rectWindow.right = rectWindow.left + sizeWindow.cx;
	rectWindow.top = rect.top - (sizeWindow.cy + 20);
	if(rectWindow.top <= 0)
		rectWindow.top = rect.bottom + 20;
	rectWindow.bottom = rectWindow.top + sizeWindow.cy;

	// Display window
	SetWindowPos(&wndTop,
		rectWindow.left,
		rectWindow.top,
		rectWindow.Width(),
		rectWindow.Height(),
		SWP_SHOWWINDOW | SWP_NOACTIVATE);
}

//***********************************************
void CPopupTipWnd::HidePopupWindow(void)
{
	ShowWindow(SW_HIDE);
}
