// PwdSpyDlg.h : header file
//

#if !defined(AFX_PWDSPYDLG_H__BECC53B7_6A53_11D3_8861_000000000000__INCLUDED_)
#define AFX_PWDSPYDLG_H__BECC53B7_6A53_11D3_8861_000000000000__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#include "OSInfo.h"
#include "PopupTipWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CPwdSpyDlg dialog

class CPwdSpyDlg : public CDialog
{
// Construction
public:
	CPwdSpyDlg(CWnd *pParent = NULL);	// standard constructor
	virtual ~CPwdSpyDlg();

// Dialog Data
	//{{AFX_DATA(CPwdSpyDlg)
	enum { IDD = IDD_PWDSPY_DIALOG };
	CStatic	m_ctrlLook;
	CString	m_strMousePos;
	CString	m_strPwd;
	CString	m_strWndClass;
	CString	m_strHwnd;
	CString	m_strIsPwd;
	CString	m_strCaption;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPwdSpyDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG *pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange *pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	static UINT s_wmActivateApp;

	bool m_bIsLooking, m_bAlwaysOnTop, m_bScanEx;
	HICON m_hIconLarge, m_hIconSmall;
	HICON m_hIconBlank, m_hIconScan;
	HCURSOR m_hCursorScan, m_hCursorPrev;
	HWND m_hWndPrev;
	int m_nScanLevel;
	COSInfo m_osi;
	CPopupTipWnd m_wndPopupTip;

	// Since ScanEx is async, these hold data we need later
	HWND m_hWndScanEx;
	CPoint m_ptScanEx;

	void StartLooking(void);
	void StopLooking(void);
	HWND SmallestWindowFromPoint(const POINT point);
	void InvertBorder(const HWND hWnd);
	void OnAlwaysOnTop();
	void Scan(CPoint point);

	// Generated message map functions
	//{{AFX_MSG(CPwdSpyDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR *lpMMI);
	afx_msg BOOL OnCopyData(CWnd *pWnd, COPYDATASTRUCT *pCopyDataStruct);
	//}}AFX_MSG
	afx_msg LRESULT OnActivateApp(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PWDSPYDLG_H__BECC53B7_6A53_11D3_8861_000000000000__INCLUDED_)
