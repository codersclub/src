#include <afxext.h>

class CSample : public CWinApp
{
		 
public:
	
	BOOL InitInstance();
};

class CMainWin : public CFrameWnd
{

public:
	
	CMainWin();
	BOOL PreCreateWindow(CREATESTRUCT &cs);

	afx_msg void OnDestroy();

	afx_msg void OnPaint();

	DECLARE_MESSAGE_MAP()
};
