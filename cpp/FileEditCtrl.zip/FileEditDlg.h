// FileEditDlg.h : header file for CFileEditCtrl demo
// written by PJ Arends
// pja@telus.net

#if !defined(AFX_FILEEDITDLG_H__F15965A8_B05A_11D4_B625_A1459D96AB20__INCLUDED_)
#define AFX_FILEEDITDLG_H__F15965A8_B05A_11D4_B625_A1459D96AB20__INCLUDED_

#include "FileEditCtrl.h"

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFileEditDlg dialog

class CFileEditDlg : public CDialog
{
// Construction
public:
	CString			m_String;
	CFileEditCtrl	m_FileEditCtrl;
	TCHAR *buffer;
	CFileEditDlg(CWnd* pParent = NULL);	// standard constructor
	virtual ~CFileEditDlg() { if (buffer) delete buffer; }

// Dialog Data
	//{{AFX_DATA(CFileEditDlg)
	enum { IDD = IDD_FILEEDIT_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CFileEditDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	//}}AFX_MSG
//	BOOL OnTTNNeedText (UINT nID, NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEEDITDLG_H__F15965A8_B05A_11D4_B625_A1459D96AB20__INCLUDED_)
