/****************************************************************************
FileEditCtrl.cpp : implementation file for CFileEditCtrl control class
written by PJ Arends
pja@telus.net

For updates check http://www3.telus.net/pja/CFileEditCtrl.htm

Some changes by : 
     Philippe Lhoste - PhiLho@gmx.net - http://jove.prohosting.com/~philho/

created : October 2000

Revision History:
November 11, 2000  - allowed the control to work with dialog templates
November 22, 2000  - register the control's window class, can now be added to dialog as custom control
January 4, 2001    - near total rewrite of the control, now derived from CEdit
                   - control can now be added to dialog template using an edit control
                   - browse button now drawn in nonclient area of control
January 5, 2001    - removed OnKillFocus(), replaced with OnDestroy()
January 15, 2001   - added DDX_ and DDV_ support
                   - modified GetStartPosition() and GetNextPathName()
                   - modified how FECOpenFile() updates the control text when multiple files are selected
                   - added FillBuffers()
                   - added support for relative paths
                   - added OnChange handler
                   - added drag and drop support
January 26, 2001   - fixed bug where SHBrowseForFolder does not like trailing slash
January 27, 2001   - fixed bug where if control is initialized with text, FillBuffers was not called.
January 28, 2001   - Removed GetFindFolder() and SetFindFolder() replaced with GetFlags() and SetFlags()
                   - modified the DDX_ and DDV_ functions to accept these flags
                   - modified the Create() function to accept these flags
                   - allowed option for returned folder to contain trailing slash
                   - allowed browse button to be on the left side of the control
                   - added ScreenPointInButtonRect() to better tell if mouse cursor is over the button
                   - modified how OnDropFiles() updates the control text when multiple files are dropped
February 25, 2001  - Fixed EN_CHANGE notification bug. Now parent window recieves this notification message
                     used ON_CONTROL_REFLECT_EX macro instead of ON_CONTROL_REFLECT
April 12, 2001     - Added OnSize handler, fixed button drawing problem when control size changed
April 21, 2001     - Added a tooltip for the browse button
May 12, 2001       - removed OnDestroy, replaced with PostNCDestroy
                   - added tooltip support to client area
                   - modified the FECBrowseForFolder and FECFolderProc functions
                   - added a one pixel neutral area between the client area and browse button when the
                     button is on the right hand side of the control. (looks better IMO)
May 29, 2001 - PL -- Removed the filename from the m_pCFileDialog->m_ofn.lpstrInitialDir
				     variable, so when browsing back for file, we open the correct folder.
				   - Used smaller (exact size) arrays for file, extension and path components.
				   - Some cosmetic changes.
May 29, 2001       - FECFolderProc now checks for UNC path. SHBrowseForFolder can not be initialized with UNC
June 2, 2001       - modified ButtonClicked function. Now sends a WM_NOTIFY message to parent window before
                     showing dialog, allows parent window to cancel action by setting result to nonzero. also
                     sends WM_NOTIFY message to parent window after dialog closes with successful return
****************************************************************************/

#include "stdafx.h"
#include "resource.h"
#include "FileEditCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// These strings should be entered into a string table resource with the 
// FEC_IDS_* identifiers defined here, although this class will work
// properly if they are not.
//
// string usage:
//
// FEC_IDS_ALLFILES         - default file filter for CFileDialog
// FEC_IDS_BUTTONTIP        - Text for the browse button tooltip
// FEC_IDS_FILEDIALOGTITLE  - default dialog caption for CFileDialog
// FEC_IDS_SEPARATOR        - character used to seperate files when OFN_ALLOWMULTISELECT flag is used
// FEC_IDS_NOFILE           - Error message for DDV_FileEditCtrl() when no files or folders are entered
// FEC_IDS_NOTEXIST         - Error message for DDV_FileEditCtrl() when the specified file or folder could not be found
// FEC_IDS_NOTFILE          - Error message for DDV_FileEditCtrl() when the specified file is actually a folder
// FEC_IDS_NOTFOLDER        - Error message for DDV_FileEditCtrl() when the specified folder is actually a file
// FEC_IDS_OKBUTTON         - Text for the 'OK' (Open) button on CFileDialog
//

// FEC_IDS_ALLFILES will be defined in resource.h if these strings
// are in a string table resource
#if !defined FEC_IDS_ALLFILES
	#define FEC_NORESOURCESTRINGS so this class knows how to handle these strings
	#define FEC_IDS_ALLFILES        _T("All Files (*.*)|*.*||")
    #define FEC_IDS_BUTTONTIP       _T("Browse")
	#define FEC_IDS_FILEDIALOGTITLE _T("Browse for File")
	#define FEC_IDS_SEPARATOR       _T(";")
	#define FEC_IDS_NOFILE          _T("Enter an existing file.")
	#define FEC_IDS_NOTEXIST        _T("%s does not exist.")
	#define FEC_IDS_NOTFILE         _T("%s is not a file.")
	#define FEC_IDS_NOTFOLDER       _T("%s is not a folder.")
	#define FEC_IDS_OKBUTTON        _T("OK")
#endif

/////////////////////////////////////////////////////////////////////////////
// Button states

#define BTN_UP          0
#define BTN_DOWN        1
#define BTN_DISABLED    2

/////////////////////////////////////////////////////////////////////////////
// ToolTip IDs

#define ID_BUTTONTIP    1
#define ID_CLIENTTIP    2

/////////////////////////////////////////////////////////////////////////////
// Helper function

BOOL IsWindow(CWnd *pWnd)
{
	if (!pWnd)
		return FALSE;
	return ::IsWindow(pWnd->m_hWnd);
}

/////////////////////////////////////////////////////////////////////////////
// CFileEditCtrl

IMPLEMENT_DYNAMIC(CFileEditCtrl, CEdit)

CFileEditCtrl::CFileEditCtrl(BOOL bAutoDelete /* = FALSE */)
{
	// If bAutoDelete is TRUE, this class object will be deleted
	// after it's window is destroyed (in CFileEditCtrl::PostNCDestroy).
	// The only time this should be used is when the control is
	// created dynamicly in the
	// DDX_FileEditCtrl(CDataExchange*,int,CString&,DWORD) function.

	// Initialize all variables
	m_bAutoDelete		= bAutoDelete;
	m_bButtonLeft		= FALSE;
	m_bButtonTip        = FALSE;
	m_bClientTip        = FALSE;
	m_bCreatingControl	= TRUE;
	m_bFindFolder		= FALSE;
	m_bMouseCaptured	= FALSE;
	m_bTextChanged		= TRUE;
	m_bTrailingSlash	= FALSE;
	m_lpstrFiles		= NULL;
	m_nButtonState		= BTN_UP;
	m_pBROWSEINFO		= NULL;
	m_pCFileDialog		= NULL;
	m_rcButtonRect.SetRectEmpty();
	m_szCaption.Empty();
	m_szClientTip.Empty();
	m_szFolder.Empty();
}

CFileEditCtrl::~CFileEditCtrl()
{
	// clean up all pointer variables
	if (m_lpstrFiles)     delete m_lpstrFiles;
	if (m_pBROWSEINFO)    delete m_pBROWSEINFO;
	if (m_pCFileDialog)   delete m_pCFileDialog;
}

BEGIN_MESSAGE_MAP(CFileEditCtrl, CEdit)
	ON_CONTROL_REFLECT_EX(EN_CHANGE, OnChange)
	ON_NOTIFY_EX(TTN_NEEDTEXT, 0, OnTTNNeedText)
	//{{AFX_MSG_MAP(CFileEditCtrl)
	ON_WM_DROPFILES()
	ON_WM_ENABLE()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_MOUSEMOVE()
	ON_WM_NCCALCSIZE()
	ON_WM_NCHITTEST()
	ON_WM_NCLBUTTONDOWN()
	ON_WM_NCPAINT()
	ON_WM_SETFOCUS()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileEditCtrl message handlers

void CFileEditCtrl::ButtonClicked()
{
	// Called to handle a mouse click on the button
	BOOL bResult = FALSE;
    CWnd *pParent = GetParent();
    if (IsWindow(pParent))
    {
        FEC_NOTIFY notify(this, FEC_NM_PREBROWSE);
        if (pParent->SendMessage (WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&notify))
            return; // SendMessage returned nonzero, do not show dialog
    }
    if (m_bFindFolder)
		bResult = FECBrowseForFolder();
	else
		bResult = FECOpenFile();
    if (bResult && IsWindow(pParent))
    {
        FEC_NOTIFY notify(this, FEC_NM_POSTBROWSE);
        pParent->SendMessage (WM_NOTIFY, (WPARAM)GetDlgCtrlID(), (LPARAM)&notify);
    }
}

BOOL CFileEditCtrl::Create(DWORD dwFlags, DWORD dwExStyle, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID) 
{
	// Create this control in any window
	BOOL bResult = CreateEx(dwExStyle, "EDIT", lpszWindowName, dwStyle, rect, pParentWnd, nID);
	if (bResult)
	{
		// call CFileEditCtrl::SetFlags() to initialize the internal data structures
		bResult = SetFlags(dwFlags);
		// Force a call to CFileEditCtrl::OnNcCalcSize() to calculate button size
		SetWindowPos(NULL,0,0,0,0,SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
		// set the font to the font used by the parent window
		if (pParentWnd)
			SetFont(pParentWnd->GetFont());
	}
	return bResult;
}

void CFileEditCtrl::DrawButton(int nButtonState)
{
	ASSERT(IsWindow(this));
	
	// if the control is disabled, ensure the button is drawn disabled
	if (GetStyle() & WS_DISABLED)
		nButtonState = BTN_DISABLED;

	// Draw the button in the specified state (Up, Down, or Disabled)
	CWindowDC DC(this);		// get the DC for drawing

	CBrush theBrush(GetSysColor(COLOR_3DFACE));		// the colour of the button background
	CBrush *pOldBrush = DC.SelectObject(&theBrush);

	if (nButtonState == BTN_DOWN)	// Draw button as down
	{
		// draw the border
		CPen thePen(PS_SOLID, 1, GetSysColor(COLOR_3DSHADOW));
		CPen *pOldPen = DC.SelectObject(&thePen);
		DC.Rectangle(&m_rcButtonRect);
		DC.SelectObject(pOldPen);
		thePen.DeleteObject();

		// draw the dots
		DrawDots(&DC, GetSysColor(COLOR_BTNTEXT), 1);
	}
	else	// draw button as up
	{
		CPen thePen(PS_SOLID, 1, GetSysColor(COLOR_3DFACE));
		CPen *pOldPen = DC.SelectObject(&thePen);
		DC.Rectangle(&m_rcButtonRect);
		DC.SelectObject(pOldPen);
		thePen.DeleteObject();

		// draw the border
		DC.DrawEdge(&m_rcButtonRect, EDGE_RAISED, BF_RECT);

		// draw the dots
		if (nButtonState == BTN_DISABLED)
		{
			DrawDots(&DC, GetSysColor(COLOR_3DHILIGHT), 1);
			DrawDots(&DC, GetSysColor(COLOR_GRAYTEXT));
		}
		else if (nButtonState == BTN_UP)
			DrawDots(&DC, GetSysColor(COLOR_BTNTEXT));
		else
			ASSERT(FALSE);	// Invalid nButtonState
	}
	DC.SelectObject(pOldBrush);
	theBrush.DeleteObject();

	// update m_nButtonState
	m_nButtonState = nButtonState;
}

void CFileEditCtrl::DrawDots(CDC *pDC, COLORREF CR, int nOffset /* = 0 */)
{
	// draw the dots on the button
	int width = m_rcButtonRect.Width();			// width of the button
	div_t divt = div(width, 4);
	int delta = divt.quot;						// space between dots
	int left = m_rcButtonRect.left + width / 2 - delta - (divt.rem ? 0 : 1); // left side of first dot
	width = width / 10;							// width and height of one dot
	int top = m_rcButtonRect.Height() / 2 - width / 2 + 1;	// top of dots
	left += nOffset;							// draw dots shifted? (for button pressed)
	top += nOffset;
	// draw the dots
	if (width < 2)
	{
		pDC->SetPixel(left, top, CR);
		left += delta;
		pDC->SetPixel(left, top, CR);
		left += delta;
		pDC->SetPixel(left, top, CR);
	}
	else
	{
		CPen thePen(PS_SOLID, 1, CR);			// set the dot colour
		CPen *pOldPen = pDC->SelectObject(&thePen);
		CBrush theBrush(CR);
		CBrush *pOldBrush = pDC->SelectObject(&theBrush);
		pDC->Ellipse(left, top, left + width, top + width);
		left += delta;
		pDC->Ellipse(left, top, left + width, top + width);
		left += delta;
		pDC->Ellipse(left, top, left + width, top + width);
		pDC->SelectObject(pOldBrush);			// reset the DC
		theBrush.DeleteObject();
		pDC->SelectObject(pOldPen);
		thePen.DeleteObject();
	}
}

int CALLBACK FECFolderProc(HWND hWnd, UINT nMsg, LPARAM, LPARAM lpData)
{
	// This is the default callback procedure for the SHBrowseForFolder function.
	// It sets the current selection to the directory specified in the edit control
    if (nMsg == BFFM_INITIALIZED)
	{
		CString szPath;
		CFileEditCtrl* pCFEC = (CFileEditCtrl *)lpData;
		POSITION pos = pCFEC->GetStartPosition();
		if (pos)
		{
			szPath = pCFEC->GetNextPathName(pos);
            if (szPath.Left(2) != _T("\\\\")) // SHBrowseForFolder does not like UNC path
            {
    			int len = szPath.GetLength() - 1;
			    if (len != 2 && szPath[len] == _T('\\'))
    				szPath.Delete(len); // remove trailing slash (SHBrowseForFolder does not like it)
                ::SendMessage(hWnd, BFFM_SETSELECTION, TRUE, (LPARAM)(LPCTSTR)szPath);
            }
		}
	}
	return 0;
}

BOOL CFileEditCtrl::FECBrowseForFolder()
{
	// Set up and call SHBrowseForFolder().
	// return TRUE if user clicks OK, return FALSE otherwise
	BOOL bReturnValue = FALSE;
#if defined _DEBUG
	if (m_pBROWSEINFO->lpfn == FECFolderProc)
		ASSERT((CWnd *)m_pBROWSEINFO->lParam == this);
#endif
	ITEMIDLIST *idl = SHBrowseForFolder(m_pBROWSEINFO);
	if (idl)
	{
		TCHAR lpstrBuffer[_MAX_PATH] = _T("");
		if (SHGetPathFromIDList(idl, lpstrBuffer))	// get path string from ITEMIDLIST
		{
			if (m_bTrailingSlash)				// add a trailing slash if it is not already there
			{
				int len = _tcslen(lpstrBuffer);
				if (lpstrBuffer[len - 1] != _T('\\'))
					_tcscat(lpstrBuffer, _T("\\"));
			}
			SetWindowText(lpstrBuffer);			// update edit control
			bReturnValue = TRUE;
		}
		LPMALLOC lpm;
		if (SHGetMalloc(&lpm) == NOERROR)
			lpm->Free(idl);						// free memory returned by SHBrowseForFolder
	}
	SetFocus();									// ensure focus returns to this control
	return bReturnValue;
}

BOOL CFileEditCtrl::FECOpenFile()
{
	// Set up the CFileDialog and call CFileDialog::DoModal().
	// return TRUE if the user clicked the OK button, return FALSE otherwise
	BOOL bReturnValue = FALSE;
	BOOL bDirectory = TRUE;						// assume user of this class has set the initial directory
	TCHAR lpstrDirectory[_MAX_PATH] = _T("");
	if (m_pCFileDialog->m_ofn.lpstrInitialDir == NULL)	// user has not set the initial directory
	{											// flag it, set initial directory to
		bDirectory = FALSE;						// directory in edit control
		POSITION pos = GetStartPosition();
		if (pos)
			_tcscpy(lpstrDirectory, GetNextPathName(pos));
		// Drop the filename ( PL )
		_TCHAR drive[_MAX_DRIVE];
		_TCHAR folder[_MAX_DIR];
		_tsplitpath(lpstrDirectory, drive, folder, NULL, NULL);
		_tmakepath(lpstrDirectory, drive, folder, NULL, NULL);
		m_pCFileDialog->m_ofn.lpstrInitialDir = lpstrDirectory;
	}
	if (m_pCFileDialog->DoModal() == IDOK)		// Start the CFileDialog
	{											// user clicked OK, enter files selected into edit control
		CString szFileSeparator;
#if defined FEC_NORESOURCESTRINGS
		szFileSeparator = FEC_IDS_SEPARATOR;
#else
		szFileSeparator.LoadString(FEC_IDS_SEPARATOR);
#endif
		ASSERT(szFileSeparator.GetLength() == 1);	// must be one character only
		szFileSeparator += _T(" ");
		CString szPath;
		POSITION pos = m_pCFileDialog->GetStartPosition();
		if (pos)								// first file has complete path
			szPath = m_pCFileDialog->GetNextPathName(pos);
		TCHAR lpstrName[_MAX_FNAME];
		TCHAR lpstrExt[_MAX_EXT];
		CString szTempPath;
		while (pos)
		{										// remaining files are name and extension only
			szTempPath = m_pCFileDialog->GetNextPathName(pos);
			_tsplitpath(szTempPath, NULL, NULL, lpstrName, lpstrExt);
			szPath += szFileSeparator + lpstrName + lpstrExt;
		}
		SetWindowText(szPath);
		bReturnValue = TRUE;
	}
	if (!bDirectory)							// reset OPENFILENAME
		m_pCFileDialog->m_ofn.lpstrInitialDir = NULL;
	SetFocus();									// ensure focus returns to this control
	return bReturnValue;
}

void CFileEditCtrl::FillBuffers()
{
	// initializes the m_szFolder and m_lpstrFiles member variables
	// these variables are used by the GetStartPosition() and 
	// GetNextPathName() functions to retrieve the file names entered
	// by the user.
	ASSERT(IsWindow(this));						// Control window must exist
#if defined FEC_NORESOURCESTRINGS
	m_szFolder = FEC_IDS_SEPARATOR;
#else
	m_szFolder.LoadString(FEC_IDS_SEPARATOR);
#endif
	TCHAR chSeparator = m_szFolder[0];			// get the character used to seperate the files

	m_szFolder.Empty();							// empty the buffers of old data
	if (m_lpstrFiles)
	{
		delete m_lpstrFiles;
		m_lpstrFiles = NULL;
	}

	int len = GetWindowTextLength();
	if (!len)									// no files entered, leave buffers empty
		return;
	LPTSTR lpstrWindow = new TCHAR[len + 1];	// working buffer
	GetWindowText(lpstrWindow, len + 1);
	LPTSTR lpstrStart = lpstrWindow;			// points to the first character in a file name
	LPTSTR lpstrEnd = NULL;						// points to the next separator character
	while (*lpstrStart == chSeparator || _istspace(*lpstrStart))
		lpstrStart++;							// skip over leading spaces and separator characters
	if (!*lpstrStart)
	{											// no files entered, leave buffers empty
		delete lpstrWindow;
		return;
	}
	lpstrEnd = _tcschr(lpstrStart, chSeparator);// find separator character
	if (lpstrEnd)
		*lpstrEnd = 0;			    			// mark end of string
    LPTSTR temp = lpstrStart + _tcslen(lpstrStart) - 1;
    while (_istspace(*temp))                // remove trailing white spaces from string
    {
        *temp = 0;
        temp--;
    }
	if (!lpstrEnd || m_bFindFolder || (!m_bFindFolder && !(m_pCFileDialog->m_ofn.Flags & OFN_ALLOWMULTISELECT)))
//	if (only one entry || find folder || (find file && find only one file))
	{
		m_lpstrFiles = new TCHAR[_MAX_PATH];
		ZeroMemory(m_lpstrFiles, _MAX_PATH);
		_tfullpath(m_lpstrFiles, lpstrStart, _MAX_PATH); // get absolute path
		if (m_bFindFolder)
		{
			int len = _tcslen(m_lpstrFiles);
			if (m_bTrailingSlash)	// add a trailing slash if it is not already there
			{
				if (m_lpstrFiles[len - 1] != _T('\\'))
					_tcscat(m_lpstrFiles, _T("\\"));
			}
			else	// remove the trailing slash if it is there
			{
				if (len != 3 && m_lpstrFiles[len - 1] == _T('\\'))
					m_lpstrFiles[len - 1] = 0;
			}
		}
		delete lpstrWindow;
		return;
	}
	_TCHAR drive[_MAX_DRIVE];
	_TCHAR folder[_MAX_DIR];
	_TCHAR file[_MAX_FNAME];
	_TCHAR ext[_MAX_EXT];
	_tsplitpath(lpstrStart, drive, folder, file, ext);
	m_szFolder = (CString)drive + folder;		// drive and directory placed in m_szFolder
	m_lpstrFiles = new TCHAR[len + 1];
	ZeroMemory(m_lpstrFiles, len + 1);
	_tcscpy(m_lpstrFiles, file);				// file and extension of first file placed in m_lpstrFiles
	_tcscat(m_lpstrFiles, ext);
	lpstrStart = lpstrEnd + 1;					// reset to the start of the next string
	LPTSTR pointer = m_lpstrFiles + _tcslen(m_lpstrFiles) + 1;	// location where next file will be placed in m_lpstrFiles
	while (lpstrEnd)
	{	// add the rest of the files to m_lpstrFiles as they have been typed (include any path information)
		while (*lpstrStart == chSeparator || _istspace(*lpstrStart))
			lpstrStart++;						// remove leading spaces and separator characters
		if (!*lpstrStart)						// last file was followed by spaces and separator characters,
			break;								// there are no more files entered
		lpstrEnd = _tcschr(lpstrStart, chSeparator); // find next separator character
    	if (lpstrEnd)
    		*lpstrEnd = 0;		    			// mark end of string
        temp = lpstrStart + _tcslen(lpstrStart) - 1;
        while (_istspace(*temp))                // remove trailing white spaces from string
        {
            *temp = 0;
            temp--;
        }
		_tcscpy(pointer, lpstrStart);			// copy string to its location in m_lpstrFiles
		pointer += _tcslen(pointer) + 1;		// reset pointer to accept next file
		if (lpstrEnd)
			lpstrStart = lpstrEnd + 1;			// reset to the start of the next string
	}
	delete lpstrWindow;							// delete working buffer
}

BROWSEINFO* CFileEditCtrl::GetBrowseInfo() const
{
	// returns a pointer to the BROWSEINFO structure
	// so the user of this control can set their own
	// parameters for SHBrowseForFolder
	return m_pBROWSEINFO;
}

DWORD CFileEditCtrl::GetFlags()
{
	DWORD flags = m_bFindFolder ? FEC_FOLDER : FEC_FILE;
	if (m_bTrailingSlash)
		flags |=  FEC_TRAILINGSLASH;
	if (m_bButtonLeft)
		flags |= FEC_BUTTONLEFT;
	if (m_bButtonTip)
		flags |= FEC_BUTTONTIP;
	if (m_bClientTip)
		flags |= FEC_CLIENTTIP;
	return flags;
}

CString CFileEditCtrl::GetNextPathName(POSITION &pos)
{
	// Returns the file name at the specified position in the buffer.
	// The starting position is retrieved using the GetStartPosition() function.
	// The position is updated to point to the next file, or set to NULL if
	// there are no more files.
	ASSERT(pos);								// pos must not be NULL
	LPTSTR str = (LPTSTR)pos;					// str points to file name at pos
	TCHAR lpstrReturnString[_MAX_PATH];
	CString szTemp;
	if (str[1] == _T(':') ||					// Drive
		(str[0] == _T('\\') && str[1] == _T('\\'))) // Or UNC path ( PL )
			szTemp = str;						// str contains complete path
	else
		szTemp = m_szFolder + str;				// build the path
	_tfullpath(lpstrReturnString, szTemp, _MAX_PATH);	// get absolute path from any relative paths
	str += _tcslen(str) + 1;					// set pos to next file
	pos = *str ? (POSITION)str : NULL;
	return (CString)lpstrReturnString;
}

OPENFILENAME* CFileEditCtrl::GetOpenFileName() const
{
	// returns a pointer to the OPENFILENAME structure so the
	// user can modify the Open File dialog
	if (m_pCFileDialog)
		return (&m_pCFileDialog->m_ofn);
	return NULL;
}

POSITION CFileEditCtrl::GetStartPosition()
{
	// if the window is active, fills the buffers with the text in the window.
	// returns a pointer to the buffer, type-casted as an MFC POSITION structure
	if (IsWindow(this) && m_bTextChanged)
	{
		FillBuffers();
		m_bTextChanged = FALSE;
	}
	return (POSITION)m_lpstrFiles;
}

BOOL CFileEditCtrl::OnChange() 
{
	// Flags when the window text has changed since FillBuffers() was last called.
	// If it has, then FillBuffers will be called in GetStartPosition()
	m_bTextChanged = TRUE;
	return FALSE;		// Allow the parent window to also handle this message
}

void CFileEditCtrl::OnDropFiles(HDROP hDropInfo) 
{
	// handles drag and drop file entry, control must have the
	// WS_EX_ACCEPTFILES extended style set.
	CString szSeparator;
#if defined FEC_NORESOURCESTRINGS
	szSeparator = FEC_IDS_SEPARATOR;
#else
	szSeparator.LoadString(FEC_IDS_SEPARATOR);
#endif
	ASSERT(szSeparator.GetLength() == 1);		// must be one character only
	szSeparator += _T(" ");						// get the file separator character
	CString szDroppedFiles;						// the new window text

	TCHAR lpstrDropBuffer[_MAX_PATH];			// buffer to contain the dropped files
	UINT nDropCount = DragQueryFile(hDropInfo, 0xffffffff, NULL, 0);
	if (nDropCount && (m_bFindFolder || (!m_bFindFolder && !(m_pCFileDialog->m_ofn.Flags & OFN_ALLOWMULTISELECT))))
// if (one file && (finding folder || (finding files && finding only one file)))
		nDropCount = 1;
	if (nDropCount)
	{											// first file has complete path
		DragQueryFile(hDropInfo, 0, lpstrDropBuffer, _MAX_PATH);
		szDroppedFiles = lpstrDropBuffer;
	}
	TCHAR lpstrName[_MAX_FNAME];
	TCHAR lpstrExt[_MAX_EXT];
	for (UINT x = 1; x < nDropCount; x++)
	{											// all other files are name and extension only
		DragQueryFile(hDropInfo, x, lpstrDropBuffer, _MAX_PATH);
		_tsplitpath(lpstrDropBuffer, NULL, NULL, lpstrName, lpstrExt);
		szDroppedFiles += szSeparator + lpstrName + lpstrExt;
	}
	DragFinish(hDropInfo);
	SetWindowText(szDroppedFiles);
}

void CFileEditCtrl::OnEnable(BOOL bEnable) 
{
	// enables/disables the control
	CEdit::OnEnable(bEnable);
	DrawButton(bEnable ? BTN_UP : BTN_DISABLED);
}

void CFileEditCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// check for CTRL + 'period' keystroke, if found, simulate a mouse click on the button
#ifndef VK_OEM_PERIOD	// Windows 2000 specific
    #define VK_OEM_PERIOD 0xBE		
#endif
    if ((nChar == VK_OEM_PERIOD || nChar == VK_DECIMAL) && GetKeyState(VK_CONTROL) < 0)
        ButtonClicked();
    CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

//////////////////////////////////////////////////////////////////////////////
// Because the mouse is captured in OnNcLButtonDown(), we have to respond	//
// to WM_LBUTTONUP and WM_MOUSEMOVE messages.								//
// The m_bMouseCaptured variable is used because CEdit::OnLButtonDown()		//
// also captures the mouse, so using GetCapture() could give an invalid		//
// response.																//
//////////////////////////////////////////////////////////////////////////////

void CFileEditCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CEdit::OnLButtonUp(nFlags, point);

	// Release the mouse capture and draw the button as normal. If the
	// cursor is over the button, simulate a click by carrying
	// out the required action.
	if (m_bMouseCaptured)
	{
		ReleaseCapture();
		m_bMouseCaptured = FALSE;
		if (m_nButtonState != BTN_UP)
			DrawButton(BTN_UP);
		ClientToScreen(&point);
		if (ScreenPointInButtonRect(point))
			ButtonClicked();
	}
}

void CFileEditCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CEdit::OnMouseMove(nFlags, point);

	// presses and releases the button as the mouse is moved over and
	// off the button. we check the current button state to avoid
	// unnecessary flicker
	if (m_bMouseCaptured)
	{
		ClientToScreen(&point);
		if (ScreenPointInButtonRect(point))
        {
            if (m_nButtonState != BTN_DOWN)
			    DrawButton(BTN_DOWN);
        }
		else if (m_nButtonState != BTN_UP)
			DrawButton(BTN_UP);
	}
}

void CFileEditCtrl::OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp) 
{
	// calculate the size of the client area and the button.
	CEdit::OnNcCalcSize(bCalcValidRects, lpncsp);
	// set button area equal to client area of edit control
	m_rcButtonRect = lpncsp->rgrc[0];
	if (m_bButtonLeft)		// draw the button on the left side of the control
	{
		// shrink left side of client area by 80% of the height of client area
		lpncsp->rgrc[0].left += (lpncsp->rgrc[0].bottom - lpncsp->rgrc[0].top) * 8/10;
		// shrink the button so its right side is at the left side of client area
		m_rcButtonRect.right = lpncsp->rgrc[0].left;
	}
	else					// draw the button on the right side of the control
	{
		// shrink right side of client area by 80% of the height of client area
        // and add a one pixel neutral area between button and client area
		lpncsp->rgrc[0].right -= (lpncsp->rgrc[0].bottom - lpncsp->rgrc[0].top) * 8/10 + 1;
		// shrink the button so its left side is at the right side of client area
		m_rcButtonRect.left = lpncsp->rgrc[0].right + 1;
	}
	if (bCalcValidRects)
		// convert button coordinates from parent client coordinates to control window coordinates
		m_rcButtonRect.OffsetRect(-lpncsp->rgrc[1].left, -lpncsp->rgrc[1].top);
	m_rcButtonRect.NormalizeRect();
}

UINT CFileEditCtrl::OnNcHitTest(CPoint point) 
{
	// If the mouse is over the button, OnNcHitTest() would normally return
	// HTNOWHERE, and we would not get any mouse messages. So we return 
	// HTBORDER to ensure we get them.
	UINT where = CEdit::OnNcHitTest(point);
	if (where == HTNOWHERE && ScreenPointInButtonRect(point))
		where = HTBORDER;
	return where;
}

void CFileEditCtrl::OnNcLButtonDown(UINT nHitTest, CPoint point) 
{
	CEdit::OnNcLButtonDown(nHitTest, point);

	if (ScreenPointInButtonRect(point))
	{
		// Capture mouse input, set the focus to this control,
		// and draw the button as pressed
		SetCapture();
		m_bMouseCaptured = TRUE;
		SetFocus();
		DrawButton(BTN_DOWN);
	}
}

void CFileEditCtrl::OnNcPaint() 
{
	CEdit::OnNcPaint();             // draws the border around the control
	DrawButton(m_nButtonState);     // draw the button in its current state
}

void CFileEditCtrl::OnSetFocus(CWnd* pOldWnd) 
{
	CEdit::OnSetFocus(pOldWnd);
	// Select all the text
	SetSel(0,-1);
}

void CFileEditCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CEdit::OnSize(nType, cx, cy);
	// Force a recalculation of the button's size and position
	SetWindowPos(NULL, 0, 0, 0, 0, SWP_FRAMECHANGED | SWP_NOMOVE | SWP_NOZORDER | SWP_NOSIZE | SWP_NOACTIVATE);

	if (m_ToolTip.m_hWnd)
	{
		// recalculate the bounding rectangle for the button tooltip
		CRect rcBtn(m_rcButtonRect);
		CRect rcWnd;
		GetWindowRect(&rcWnd);
		rcBtn.OffsetRect(rcWnd.left, rcWnd.top);
		ScreenToClient(&rcBtn);
		m_ToolTip.SetToolRect(this, ID_BUTTONTIP, &rcBtn);
		
		// recalculate the bounding rectangle for the client area tooltip
		GetClientRect(&rcWnd);
		m_ToolTip.SetToolRect(this, ID_CLIENTTIP, &rcWnd);
	}
}

BOOL CFileEditCtrl::OnTTNNeedText(UINT, NMHDR *pTTTStruct, LRESULT *)
{
	TOOLTIPTEXT* pTTT = ((TOOLTIPTEXT*)pTTTStruct);
	if (m_bButtonTip && pTTT->hdr.idFrom == ID_BUTTONTIP)
	{
#if defined FEC_NORESOURCESTRINGS
		pTTT->lpszText = FEC_IDS_BUTTONTIP;
#else
		pTTT->lpszText = MAKEINTRESOURCE(FEC_IDS_BUTTONTIP);
		pTTT->hinst = AfxGetResourceHandle();
#endif
	}
	if (m_bClientTip && pTTT->hdr.idFrom == ID_CLIENTTIP)
		pTTT->lpszText = m_szClientTip.GetBuffer(m_szClientTip.GetLength());
	return TRUE;
}

void CFileEditCtrl::PostNcDestroy() 
{
	if (m_bAutoDelete)	// delete this CFileEditCtrl object? Only used when control was created
		delete this;	// in DDX_FileEditCtrl(CDataExchange*,int,CString&,DWORD)
}

BOOL CFileEditCtrl::PreTranslateMessage(MSG* pMsg) 
{
	// Setup the browse button tooltip, and pass pMsg to it so it
	// can display itself
	if (m_bButtonTip || m_bClientTip)
	{
		if (!m_ToolTip.m_hWnd)
		{
			m_ToolTip.Create(this);
			m_ToolTip.Activate(TRUE);
			CRect rc(m_rcButtonRect);
			CRect wnd;
			GetWindowRect(&wnd);
			rc.OffsetRect(wnd.left, wnd.top);
			ScreenToClient(&rc);
			m_ToolTip.AddTool(this, LPSTR_TEXTCALLBACK, &rc, ID_BUTTONTIP);
			GetClientRect(&wnd);
			m_ToolTip.AddTool(this, LPSTR_TEXTCALLBACK, &wnd, ID_CLIENTTIP);
		}
		m_ToolTip.RelayEvent(pMsg);
	}

	return CEdit::PreTranslateMessage(pMsg);
}

BOOL CFileEditCtrl::ScreenPointInButtonRect(CPoint point)
{
	// Checks if the given point (in screen coordinates) is in the button rectangle
	CRect ControlRect;
	GetWindowRect(&ControlRect);
	// convert point from screen coordinates to window coordinates
	point.Offset(-ControlRect.left, -ControlRect.top);
	return m_rcButtonRect.PtInRect(point);
}

void CFileEditCtrl::SetClientTipText(CString text)
{
    m_szClientTip = text;
}

BOOL CFileEditCtrl::SetFlags(DWORD dwFlags)
{
	// initialize the internal data to browse for files or folders.
	// returns TRUE on success, FALSE on failure
	if (m_bCreatingControl)
	{
		m_bCreatingControl = FALSE;
		m_bButtonLeft = dwFlags & FEC_BUTTONLEFT;
	}

	m_bButtonTip = dwFlags & FEC_BUTTONTIP;
	m_bClientTip = dwFlags & FEC_CLIENTTIP;

	BOOL bFindFolder = dwFlags & FEC_FOLDER;
	if (bFindFolder)
	{
		ASSERT(!(dwFlags & FEC_FILE));			// can not specify FEC_FILE with FEC_FOLDER
		// if bFindFolder is TRUE, sets the control to find folders
		m_bTrailingSlash = dwFlags & FEC_TRAILINGSLASH;
		if (m_bFindFolder == bFindFolder && m_pBROWSEINFO)
			return TRUE;						// already set to find folders
		m_pBROWSEINFO = new BROWSEINFO();
		if (!m_pBROWSEINFO)						// failed to create BROWSEINFO structure
			return FALSE;
		if (m_pCFileDialog)
		{
			delete m_pCFileDialog;				// delete the CFileDialog
			m_pCFileDialog = NULL;
		}
		// set up the browseinfo structure used by SHBrowseForFolder()
		::ZeroMemory(m_pBROWSEINFO, sizeof(BROWSEINFO));
		m_pBROWSEINFO->hwndOwner = GetSafeHwnd();
		m_pBROWSEINFO->lParam = (LPARAM)this;
		m_pBROWSEINFO->lpfn = FECFolderProc;
		m_pBROWSEINFO->ulFlags = BIF_RETURNONLYFSDIRS;
	}
	else
	{
		ASSERT(dwFlags & FEC_FILE);			// must specify either FEC_FILE or FEC_FOLDER
		// if bFindFolder is FALSE, sets the control to find files
		if (m_bFindFolder == bFindFolder && m_pCFileDialog)
			return TRUE;						// already set to find files
		// create the CFileDialog
		CString szFilter;
#if defined FEC_NORESOURCESTRINGS
		szFilter = FEC_IDS_ALLFILES;
#else	
		szFilter.LoadString(FEC_IDS_ALLFILES);
#endif
		m_pCFileDialog = new CFECFileDialog(TRUE,
			NULL,
			NULL,
			OFN_HIDEREADONLY | OFN_FILEMUSTEXIST | OFN_NOCHANGEDIR,
			szFilter,
			this);
		if (!m_pCFileDialog)					// failed to create the CFileDialog
			return FALSE;
		if (m_pBROWSEINFO)
		{
			delete m_pBROWSEINFO;				// delete the BROWSEINFO structure
			m_pBROWSEINFO = NULL;
		}
		// set up the CFileDialog
		m_pCFileDialog->m_ofn.hwndOwner = GetSafeHwnd();
#if defined FEC_NORESOURCESTRINGS
		m_szCaption = FEC_IDS_FILEDIALOGTITLE;
#else
		m_szCaption.LoadString(FEC_IDS_FILEDIALOGTITLE);
#endif
		m_pCFileDialog->m_ofn.lpstrTitle = (LPCTSTR)m_szCaption;
	}
	m_bFindFolder = bFindFolder;
	return TRUE;
}

void CFileEditCtrl::SetWindowText(LPCTSTR lpszString)
{
	m_bTextChanged = TRUE;
	CEdit::SetWindowText(lpszString);
}

/////////////////////////////////////////////////////////////////////////////
// DDV_FileEditCtrl & DDX_FileEditCtrl

void DDV_FileEditCtrl(CDataExchange *pDX, int nIDC)
{
	// verify the files or folder entered actually exists
	// verify that files are entered when looking for files
	// and that folders are entered when looking for folders
	CWnd *pWnd = pDX->m_pDlgWnd->GetDlgItem(nIDC);
	ASSERT(pWnd);
	if (!pWnd->IsKindOf(RUNTIME_CLASS(CFileEditCtrl)))	// is this control a CFileEditCtrl control?
	{
		TRACE("Control %d not subclassed to CFileEditCtrl, must first call DDX_FileEditCtrl()", nIDC);
		ASSERT(FALSE);
		AfxThrowNotSupportedException();
	}
	if (!pDX->m_bSaveAndValidate)				// not saving data
		return;
	CFileEditCtrl *pFEC = (CFileEditCtrl *)pWnd;
	pDX->PrepareEditCtrl(nIDC);
	POSITION pos = pFEC->GetStartPosition();
	if (!pos)
	{	// no name entered
		AfxMessageBox(FEC_IDS_NOFILE);
		pDX->Fail();
	}
	while (pos)
	{
		CString szMessage;
		CString szFile = pFEC->GetNextPathName(pos);
		DWORD dwAttribute = GetFileAttributes(szFile);
		if (dwAttribute == 0xFFFFFFFF)			// GetFileAttributes() failed
		{										// does not exist
			szMessage.Format(FEC_IDS_NOTEXIST, szFile);
			AfxMessageBox(szMessage);
			pDX->Fail();
		}
		if ((pFEC->GetFlags() & FEC_FOLDER) && !(dwAttribute & FILE_ATTRIBUTE_DIRECTORY))
		{										// not a folder
			szMessage.Format(FEC_IDS_NOTFOLDER, szFile);
			AfxMessageBox(szMessage);
			pDX->Fail();
		}
		if ((pFEC->GetFlags() & FEC_FILE) && (dwAttribute & FILE_ATTRIBUTE_DIRECTORY))
		{										// not a file
			szMessage.Format(FEC_IDS_NOTFILE, szFile);
			AfxMessageBox(szMessage);
			pDX->Fail();
		}
	}
}

void DDX_FileEditCtrl(CDataExchange *pDX, int nIDC, CString& rStr, DWORD dwFlags)
{
	// Subclasses the edit control with Id nIDC. Coordinates the window text
	// with the CString. dwFlags is used to setup the control.
	CWnd *pWnd = pDX->m_pDlgWnd->GetDlgItem(nIDC);
	ASSERT(pWnd);
	if (pDX->m_bSaveAndValidate)				// update string with text from control
	{
		// ensure the control is a CFileEditCtrl control
		ASSERT(pWnd->IsKindOf(RUNTIME_CLASS(CFileEditCtrl)));
		// copy the first file listed in the control to the string
		rStr.Empty();
		CFileEditCtrl *pFEC = (CFileEditCtrl *)pWnd;
		POSITION pos = pFEC->GetStartPosition();
		if (pos)
			rStr = pFEC->GetNextPathName(pos);
	}
	else										// create the control if it is not already created
	{											// set the control text to the text in string
		CFileEditCtrl *pFEC = NULL;
		if (!pWnd->IsKindOf(RUNTIME_CLASS(CFileEditCtrl)))    // not subclassed yet
		{
			// create then subclass the control to the edit control with the ID nIDC
			HWND hWnd = pDX->PrepareEditCtrl(nIDC);
			pFEC = new CFileEditCtrl(TRUE);		// create the control with autodelete
			if (!pFEC->SubclassWindow(hWnd))
			{									// failed to subclass the edit control
				ASSERT(FALSE);
				AfxThrowNotSupportedException();
			}
			// call CFileEditCtrl::SetFlags() to initialize the internal data structures
			pFEC->SetFlags(dwFlags);
			// Force a call to CFileEditCtrl::OnNcCalcSize() to calculate button size
			pFEC->SetWindowPos(NULL,0,0,0,0,SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
		}
		else									// control already exists
			pFEC = (CFileEditCtrl *)pWnd;
		if (pFEC)
			pFEC->SetWindowText(rStr);			// set the control text
	}
}

void DDX_FileEditCtrl(CDataExchange *pDX, int nIDC, CFileEditCtrl &rCFEC, DWORD dwFlags)
{
	// Subclass the specified CFileEditCtrl class object to the edit control
	// with the ID nIDC. dwFlags is used to setup the control
	ASSERT(pDX->m_pDlgWnd->GetDlgItem(nIDC));
	if (rCFEC.m_hWnd == NULL)					// not yet subclassed
	{
		ASSERT(!pDX->m_bSaveAndValidate);
		// subclass the control to the edit control with the ID nIDC
		HWND hWnd = pDX->PrepareEditCtrl(nIDC);
		if (!rCFEC.SubclassWindow(hWnd))
		{										// failed to subclass the edit control
			ASSERT(FALSE);
			AfxThrowNotSupportedException();
		}
		// call CFileEditCtrl::SetFlags() to initialize the internal data structures
		rCFEC.SetFlags(dwFlags);
		// Force a call to CFileEditCtrl::OnNcCalcSize() to calculate button size
		rCFEC.SetWindowPos(NULL,0,0,0,0,SWP_FRAMECHANGED|SWP_NOMOVE|SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE);
	}
	else if (pDX->m_bSaveAndValidate)
		rCFEC.GetStartPosition();				// updates the data from the edit control
}

/////////////////////////////////////////////////////////////////////////////
// FEC_NOTIFY structure

tagFEC_NOTIFY::tagFEC_NOTIFY (CFileEditCtrl *FEC, UINT code)
    {
        pFEC = FEC;
        hdr.hwndFrom = FEC->GetSafeHwnd();
        hdr.idFrom = FEC->GetDlgCtrlID();
        hdr.code = code;
    }

/////////////////////////////////////////////////////////////////////////////
// CFECFileDialog

IMPLEMENT_DYNAMIC(CFECFileDialog, CFileDialog)

CFECFileDialog::CFECFileDialog(BOOL bOpenFileDialog, LPCTSTR lpszDefExt, LPCTSTR lpszFileName,
		DWORD dwFlags, LPCTSTR lpszFilter, CWnd* pParentWnd) :
		CFileDialog(bOpenFileDialog, lpszDefExt, lpszFileName, dwFlags, lpszFilter, pParentWnd)
{
}


BEGIN_MESSAGE_MAP(CFECFileDialog, CFileDialog)
	//{{AFX_MSG_MAP(CFECFileDialog)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


BOOL CFECFileDialog::OnInitDialog() 
{
	CFileDialog::OnInitDialog();
	
	// Set the text of the IDOK button on an
	// old style dialog to 'OK'
	if (!(m_ofn.Flags & OFN_EXPLORER))
	{
		CString szOkButton;
#if defined FEC_NORESOURCESTRINGS
		szOkButton = FEC_IDS_OKBUTTON;
#else
		szOkButton.LoadString(FEC_IDS_OKBUTTON);
#endif
		GetDlgItem(IDOK)->SetWindowText(szOkButton);
	}
	return TRUE;
}

void CFECFileDialog::OnInitDone()
{
	// Set the text of the IDOK button on an
	// Explorer style dialog to 'OK'
	CString szOkButton;
#if defined FEC_NORESOURCESTRINGS
	szOkButton = FEC_IDS_OKBUTTON;
#else
	szOkButton.LoadString(FEC_IDS_OKBUTTON);
#endif
	CommDlg_OpenSave_SetControlText(GetParent()->m_hWnd, IDOK, (LPCTSTR)szOkButton);
}
