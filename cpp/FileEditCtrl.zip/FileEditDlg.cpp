// FileEditDlg.cpp : implementation file for FileEditCtrl demo dialog
// written by PJ Arends
// pja@telus.net

#include "stdafx.h"
#include "FileEdit.h"
#include "FileEditDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	ON_WM_LBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

void CAboutDlg::OnLButtonDown(UINT, CPoint) 
{
	EndDialog(IDCANCEL);	
}

/////////////////////////////////////////////////////////////////////////////
// CFileEditDlg dialog

CFileEditDlg::CFileEditDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFileEditDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFileEditDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	buffer = NULL;
}

void CFileEditDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFileEditDlg)
	//}}AFX_DATA_MAP
	DDX_FileEditCtrl(pDX, IDC_EDIT1, m_String, FEC_FOLDER/* | FEC_TRAILINGSLASH*/ | FEC_BUTTONTIP);
	DDV_FileEditCtrl(pDX, IDC_EDIT1);
	DDX_FileEditCtrl(pDX, IDC_EDIT2, m_FileEditCtrl, FEC_FILE | FEC_BUTTONLEFT | FEC_BUTTONTIP | FEC_CLIENTTIP);
	DDV_FileEditCtrl(pDX, IDC_EDIT2);
}

BEGIN_MESSAGE_MAP(CFileEditDlg, CDialog)
	//{{AFX_MSG_MAP(CFileEditDlg)
	ON_WM_SYSCOMMAND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileEditDlg message handlers

BOOL CFileEditDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// Modify the control to accept multiple files
	if (OPENFILENAME *ofn = m_FileEditCtrl.GetOpenFileName())
	{
		ofn->Flags |= OFN_ALLOWMULTISELECT;
		buffer = new TCHAR[2000];
		::ZeroMemory(buffer, 2000);
		ofn->lpstrFile = buffer;
		ofn->nMaxFile = 2000;
	}
	m_FileEditCtrl.SetClientTipText("Files");

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CFileEditDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}
