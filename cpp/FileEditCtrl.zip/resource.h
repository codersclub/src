//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by FileEdit.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_FILEEDIT_DIALOG             102
#define FEC_IDS_OKBUTTON                102
#define FEC_IDS_FILEDIALOGTITLE         103
#define FEC_IDS_ALLFILES                104
#define FEC_IDS_NOFILE                  105
#define FEC_IDS_NOTEXIST                106
#define FEC_IDS_NOTFILE                 107
#define FEC_IDS_NOTFOLDER               108
#define FEC_IDS_SEPERATOR               109
#define FEC_IDS_SEPARATOR               109
#define FEC_IDS_BUTTONTIP               110
#define IDR_MAINFRAME                   128
#define IDI_ICON1                       130
#define IDC_EDIT1                       1001
#define IDC_EDIT2                       1002
#define IDC_BUTTON1                     1005
#define IDC_BUTTON2                     1006

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
