; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CFileEditDlg
LastTemplate=CToolTipCtrl
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "fileedit.h"
LastPage=0

ClassCount=6
Class1=CFEButton
Class2=CFileEditApp
Class3=CFileEditCtrl
Class4=CAboutDlg
Class5=CFileEditDlg

ResourceCount=2
Resource1=IDD_ABOUTBOX
Class6=CFECFileDialog
Resource2=IDD_FILEEDIT_DIALOG

[CLS:CFEButton]
Type=0
HeaderFile=fileeditctrl.h
ImplementationFile=fileeditctrl.cpp
BaseClass=CButton
LastObject=CFEButton
Filter=W

[CLS:CFileEditApp]
Type=0
BaseClass=CWinApp
HeaderFile=FileEdit.h
ImplementationFile=FileEdit.cpp
Filter=N

[CLS:CFileEditCtrl]
Type=0
BaseClass=CEdit
HeaderFile=FileEditCtrl.h
ImplementationFile=FileEditCtrl.cpp
Filter=W
VirtualFilter=WC
LastObject=CFileEditCtrl

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=FileEditDlg.cpp
ImplementationFile=FileEditDlg.cpp
LastObject=CAboutDlg
Filter=D
VirtualFilter=dWC

[CLS:CFileEditDlg]
Type=0
BaseClass=CDialog
HeaderFile=FileEditDlg.h
ImplementationFile=FileEditDlg.cpp
Filter=W
VirtualFilter=dWC
LastObject=CFileEditDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDC_STATIC,static,1342308352
Control5=IDC_STATIC,static,1342177283

[DLG:IDD_FILEEDIT_DIALOG]
Type=1
Class=CFileEditDlg
ControlCount=5
Control1=IDOK,button,1342242817
Control2=IDC_STATIC,static,1342308352
Control3=IDC_EDIT1,edit,1342242944
Control4=IDC_STATIC,static,1342308352
Control5=IDC_EDIT2,edit,1350631552

[CLS:CFECFileDialog]
Type=0
HeaderFile=fileeditctrl.h
ImplementationFile=fileeditctrl.cpp
BaseClass=CFileDialog
Filter=D
VirtualFilter=dWC
LastObject=CFECFileDialog

