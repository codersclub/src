// FileEditCtrl.h : header file for CFileEditCtrl control class
// written by PJ Arends
// pja@telus.net
//
// For updates check http://www3.telus.net/pja/CFileEditCtrl.htm
//

#if !defined(AFX_FILEEDITCTRL_H__F15965B0_B05A_11D4_B625_A1459D96AB20__INCLUDED_)
#define AFX_FILEEDITCTRL_H__F15965B0_B05A_11D4_B625_A1459D96AB20__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFECFileDialog dialog

// The sole purpose for this class is to change the
// text of the "OPEN" button to "OK".

class CFECFileDialog : public CFileDialog
{
	DECLARE_DYNAMIC(CFECFileDialog)

public:
	CFECFileDialog(BOOL bOpenFileDialog, // TRUE for FileOpen, FALSE for FileSaveAs
		LPCTSTR lpszDefExt = NULL,
		LPCTSTR lpszFileName = NULL,
		DWORD dwFlags = OFN_HIDEREADONLY | OFN_OVERWRITEPROMPT,
		LPCTSTR lpszFilter = NULL,
		CWnd* pParentWnd = NULL);

protected:
	//{{AFX_MSG(CFECFileDialog)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	virtual void OnInitDone();
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
// CFileEditCtrl control

// Flags used by dwFlags parameter of the Create(), SetFlags() and DDX_FileEditCtrl() functions
// also returned by GetFlags()
// Usage :
// FEC_FILE          - the control is used to find files, can not be used with FEC_FOLDER
// FEC_FOLDER        - the control is used to find folders, can not be used with FEC_FILE
// FEC_TRAILINGSLASH - used with FEC_FOLDER, adds a slash to the end of the folder string
// FEC_BUTTONLEFT    - places the button on the left side of the control, only used when control is being initialized
// FEC_BUTTONTIP     - enables the tooltip for the browse button
// FEC_CLIENTTIP     - enables the tooltip for the client area

#define FEC_FILE            0x00000001
#define FEC_FOLDER          0x00000002
#define FEC_TRAILINGSLASH   0x00000004
#define FEC_BUTTONLEFT      0x00000008
#define FEC_BUTTONTIP       0x00000010
#define FEC_CLIENTTIP       0x00000020

class CFileEditCtrl : public CEdit
{
	DECLARE_DYNAMIC (CFileEditCtrl)
// Construction
public:
	CFileEditCtrl(BOOL bAutoDelete = FALSE);	// Constructor

// Attributes
public:

// Operations
public:
	virtual BOOL Create(DWORD dwFlags,
        DWORD dwExStyle,
        LPCTSTR lpszWindowName,
        DWORD dwStyle,
        const RECT& rect,
        CWnd* pParentWnd,
        UINT nID);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileEditCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFileEditCtrl();				// Destructor
	BROWSEINFO* GetBrowseInfo() const;		// returns a pointer to the internal BROWSEINFO structure
	DWORD GetFlags();						// returns the controls functionality
	CString GetNextPathName(POSITION &pos);	// get the file at pos and then update pos
	OPENFILENAME* GetOpenFileName() const;	// returns a pointer to the internal OPENFILENAME structure
	POSITION GetStartPosition();			// get the starting position for GetNextPathName()
	void SetClientTipText(CString text);    // sets the text for the client area tooltip
	BOOL SetFlags(DWORD dwFlags);			// sets the controls functionality
	void SetWindowText(LPCTSTR lpszString);

protected:
	void ButtonClicked();					// handles a mouse click on the button
	void DrawButton (int nButtonState = 0);	// draws the button
	void DrawDots (CDC *pDC, COLORREF CR, int nOffset = 0);	// draws the dots on the button
	BOOL FECBrowseForFolder();				// starts and handles the returns from the SHBrowseForFolder() shell function
	BOOL FECOpenFile();						// starts and handles the returns from the CFileDialog
	void FillBuffers();						// fills the buffers used by GetStartPosition() and GetNextPathName() functions
	BOOL ScreenPointInButtonRect(CPoint point); // checks if the given point is in the browse button

 	BOOL OnTTNNeedText(UINT id, NMHDR* pTTTStruct, LRESULT* pResult);
    afx_msg BOOL OnChange();
	// Generated message map functions
	//{{AFX_MSG(CFileEditCtrl)
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnEnable(BOOL bEnable);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnNcCalcSize(BOOL bCalcValidRects, NCCALCSIZE_PARAMS FAR* lpncsp);
	afx_msg UINT OnNcHitTest(CPoint point);
	afx_msg void OnNcLButtonDown(UINT nHitTest, CPoint point);
	afx_msg void OnNcPaint();
	afx_msg void OnSetFocus(CWnd* pOldWnd);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

private:
	BOOL			m_bAutoDelete;			// delete this in PostNCDestroy() handler?
	BOOL			m_bButtonLeft;			// browse button on left side of control?
	BOOL            m_bButtonTip;           // browse button tooltip enabled?
	BOOL            m_bClientTip;           // client area tooltip enabled?
	BOOL			m_bCreatingControl;		// TRUE while control is being created, FALSE otherwise
	BOOL			m_bFindFolder;			// browse for files or folders?
	BOOL			m_bMouseCaptured;		// button has captured the mouse?
	BOOL			m_bTextChanged;			// window text has changed since last time FillBuffers() was called
	BOOL			m_bTrailingSlash;		// add a slash to folders?
	LPTSTR			m_lpstrFiles;			// buffer for storing file names
	int				m_nButtonState;			// current button state (up, down, or disabled)
	BROWSEINFO*		m_pBROWSEINFO;			// only active when m_bFindFolder is TRUE
	CFECFileDialog* m_pCFileDialog;			// only active when m_bFindFolder is FALSE
	CRect			m_rcButtonRect;			// window coordinates of the button
	CString			m_szCaption;			// caption of CFileDialog
	CString         m_szClientTip;          // client area tooltip text
	CString			m_szFolder;				// absolute path to first file in m_lpstrFiles.
    CToolTipCtrl    m_ToolTip;              // tooltip control
};

/////////////////////////////////////////////////////////////////////////////
// FEC_NOTIFY structure

// A pointer to this structure is sent to the parent window of the CFileEditCtrl as the
// NMHDR* pNMHDR parameter in a WM_NOTIFY message. It is sent with the FEC_NM_PREBROWSE
// notification after the user has clicked on the browse button, but before the CFileDialog
// or SHBrowseForFolder dialogs are displayed. Setting the LRESULT parameter of the OnNotify
// handler to a nonzero value will stop the dialogs from executing. It is sent with the
// FEC_NM_POSTBROWSE notification after the user has pressed the 'OK' button on these dialogs.

typedef struct tagFEC_NOTIFY {
    NMHDR hdr;
    CFileEditCtrl* pFEC;                    // pointer to control that sends this notification
    tagFEC_NOTIFY (CFileEditCtrl *FEC, UINT code);
} FEC_NOTIFY;

#define FEC_NM_PREBROWSE  1                 // notification code sent before dialogs pop up
#define FEC_NM_POSTBROWSE 2                 // notification code sent after dialogs return

/////////////////////////////////////////////////////////////////////////////
// DDV_/DDX_FileEditCtrl functions

void DDV_FileEditCtrl (CDataExchange *pDX, int nIDC);	// verify that the file/folder entered exists
void DDX_FileEditCtrl (CDataExchange *pDX, int nIDC, CFileEditCtrl &rCFEC, DWORD dwFlags);
void DDX_FileEditCtrl (CDataExchange *pDX, int nIDC, CString& rStr, DWORD dwFlags);

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEEDITCTRL_H__F15965B0_B05A_11D4_B625_A1459D96AB20__INCLUDED_)
