// FileEdit.cpp : Defines the class behaviors for the demo application.
// written by PJ Arends
// pja@telus.net

#include "stdafx.h"
#include "FileEdit.h"
#include "FileEditDlg.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileEditApp

BEGIN_MESSAGE_MAP(CFileEditApp, CWinApp)
	//{{AFX_MSG_MAP(CFileEditApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileEditApp construction

CFileEditApp::CFileEditApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFileEditApp object

CFileEditApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CFileEditApp initialization

BOOL CFileEditApp::InitInstance()
{
//	AfxEnableControlContainer();

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif
	CFileEditDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with OK
		int n = 1;
		TRACE ("\nFiles entered :\n");
		POSITION pos = dlg.m_FileEditCtrl.GetStartPosition();
		while (pos)
		{
			CString x = dlg.m_FileEditCtrl.GetNextPathName(pos);
			TRACE ("%03d - %s\n",n, x);
			n++;
		}
		TRACE ("Directory entered :\n  %s\n\n",dlg.m_String);
	}
	else if (nResponse == IDCANCEL)
	{
		// TODO: Place code here to handle when the dialog is
		//  dismissed with Cancel
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
