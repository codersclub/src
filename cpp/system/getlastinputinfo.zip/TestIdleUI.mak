# Microsoft Developer Studio Generated NMAKE File, Based on TestIdleUI.dsp
!IF "$(CFG)" == ""
CFG=TestIdleUI - Win32 Release
!MESSAGE No configuration specified. Defaulting to TestIdleUI - Win32 Release.
!ENDIF 

!IF "$(CFG)" != "TestIdleUI - Win32 Release" && "$(CFG)" != "TestIdleUI - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "TestIdleUI.mak" CFG="TestIdleUI - Win32 Release"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "TestIdleUI - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "TestIdleUI - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "TestIdleUI - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\TestIdleUI.exe"


CLEAN :
	-@erase "$(INTDIR)\TestIdleUI.obj"
	-@erase "$(INTDIR)\TestIdleUI.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\TestIdleUI.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "NDEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\TestIdleUI.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TestIdleUI.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=Release/IdleUI.lib /nologo /subsystem:windows /incremental:no /pdb:"$(OUTDIR)\TestIdleUI.pdb" /machine:I386 /out:"$(OUTDIR)\TestIdleUI.exe" 
LINK32_OBJS= \
	"$(INTDIR)\TestIdleUI.obj" \
	"$(INTDIR)\TestIdleUI.res"

"$(OUTDIR)\TestIdleUI.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "TestIdleUI - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\TestIdleUI.exe"


CLEAN :
	-@erase "$(INTDIR)\TestIdleUI.obj"
	-@erase "$(INTDIR)\TestIdleUI.res"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\TestIdleUI.exe"
	-@erase "$(OUTDIR)\TestIdleUI.ilk"
	-@erase "$(OUTDIR)\TestIdleUI.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
RSC_PROJ=/l 0x409 /fo"$(INTDIR)\TestIdleUI.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\TestIdleUI.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=Debug/IdleUI.lib /nologo /subsystem:windows /incremental:yes /pdb:"$(OUTDIR)\TestIdleUI.pdb" /debug /machine:I386 /out:"$(OUTDIR)\TestIdleUI.exe" 
LINK32_OBJS= \
	"$(INTDIR)\TestIdleUI.obj" \
	"$(INTDIR)\TestIdleUI.res"

"$(OUTDIR)\TestIdleUI.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("TestIdleUI.dep")
!INCLUDE "TestIdleUI.dep"
!ELSE 
!MESSAGE Warning: cannot find "TestIdleUI.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "TestIdleUI - Win32 Release" || "$(CFG)" == "TestIdleUI - Win32 Debug"
SOURCE=.\TestIdleUI.cpp

"$(INTDIR)\TestIdleUI.obj" : $(SOURCE) "$(INTDIR)"


SOURCE=.\TestIdleUI.rc

"$(INTDIR)\TestIdleUI.res" : $(SOURCE) "$(INTDIR)"
	$(RSC) $(RSC_PROJ) $(SOURCE)



!ENDIF 

