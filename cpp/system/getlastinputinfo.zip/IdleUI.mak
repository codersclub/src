# Microsoft Developer Studio Generated NMAKE File, Based on IdleUI.dsp
!IF "$(CFG)" == ""
CFG=IdleUI - Win32 Debug
!MESSAGE No configuration specified. Defaulting to IdleUI - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "IdleUI - Win32 Debug" && "$(CFG)" != "IdleUI - Win32 Release"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "IdleUI.mak" CFG="IdleUI - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "IdleUI - Win32 Debug" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE "IdleUI - Win32 Release" (based on "Win32 (x86) Dynamic-Link Library")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 

CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "IdleUI - Win32 Debug"

OUTDIR=.\Debug
INTDIR=.\Debug
# Begin Custom Macros
OutDir=.\Debug
# End Custom Macros

ALL : "$(OUTDIR)\IdleUI.dll"


CLEAN :
	-@erase "$(INTDIR)\IdleUI.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(INTDIR)\vc60.pdb"
	-@erase "$(OUTDIR)\IdleUI.dll"
	-@erase "$(OUTDIR)\IdleUI.exp"
	-@erase "$(OUTDIR)\IdleUI.ilk"
	-@erase "$(OUTDIR)\IdleUI.lib"
	-@erase "$(OUTDIR)\IdleUI.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /D "_USRDLL" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /D "_DEBUG" /mktyplib203 /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\IdleUI.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\IdleUI.pdb" /debug /machine:I386 /def:".\IdleUI.def" /out:"$(OUTDIR)\IdleUI.dll" /implib:"$(OUTDIR)\IdleUI.lib" 
DEF_FILE= \
	".\IdleUI.def"
LINK32_OBJS= \
	"$(INTDIR)\IdleUI.obj"

"$(OUTDIR)\IdleUI.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "IdleUI - Win32 Release"

OUTDIR=.\Release
INTDIR=.\Release
# Begin Custom Macros
OutDir=.\Release
# End Custom Macros

ALL : "$(OUTDIR)\IdleUI.dll"


CLEAN :
	-@erase "$(INTDIR)\IdleUI.obj"
	-@erase "$(INTDIR)\vc60.idb"
	-@erase "$(OUTDIR)\IdleUI.dll"
	-@erase "$(OUTDIR)\IdleUI.exp"
	-@erase "$(OUTDIR)\IdleUI.ilk"
	-@erase "$(OUTDIR)\IdleUI.lib"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "_WINDOWS" /D "_USRDLL" /D "_WINDLL" /D "_AFXDLL" /D "_MBCS" /Fo"$(INTDIR)\\" /Fd"$(INTDIR)\\" /FD /c 
MTL_PROJ=/nologo /mktyplib203 /win32 
BSC32=bscmake.exe
BSC32_FLAGS=/nologo /o"$(OUTDIR)\IdleUI.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
LINK32_FLAGS=/nologo /subsystem:windows /dll /incremental:yes /pdb:"$(OUTDIR)\IdleUI.pdb" /machine:I386 /def:".\IdleUI.def" /out:"$(OUTDIR)\IdleUI.dll" /implib:"$(OUTDIR)\IdleUI.lib" 
DEF_FILE= \
	".\IdleUI.def"
LINK32_OBJS= \
	"$(INTDIR)\IdleUI.obj"

"$(OUTDIR)\IdleUI.dll" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.obj::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.c{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cpp{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<

.cxx{$(INTDIR)}.sbr::
   $(CPP) @<<
   $(CPP_PROJ) $< 
<<


!IF "$(NO_EXTERNAL_DEPS)" != "1"
!IF EXISTS("IdleUI.dep")
!INCLUDE "IdleUI.dep"
!ELSE 
!MESSAGE Warning: cannot find "IdleUI.dep"
!ENDIF 
!ENDIF 


!IF "$(CFG)" == "IdleUI - Win32 Debug" || "$(CFG)" == "IdleUI - Win32 Release"
SOURCE=.\IdleUI.cpp

"$(INTDIR)\IdleUI.obj" : $(SOURCE) "$(INTDIR)"



!ENDIF 

