#if !defined(AFX_DIRECTORYEDDLG_H__06DD28C3_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
#define AFX_DIRECTORYEDDLG_H__06DD28C3_730B_11D6_8219_F3AE8149ED7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DirectoryEdDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDirectoryEdDlg dialog

class CDirectoryEdDlg : public CDialog
{
// Construction
public:
	CDirectoryEdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDirectoryEdDlg)
	enum { IDD = IDD_DIRECTORY_EDITOR };
	CButton	m_OK;
	CEdit	m_24;
	CEdit	m_23;
	CEdit	m_22;
	CEdit	m_21;
	CEdit	m_20;
	CEdit	m_19;
	CEdit	m_18;
	CEdit	m_17;
	CEdit	m_16;
	CEdit	m_15;
	CEdit	m_14;
	CEdit	m_13;
	CEdit	m_12;
	CEdit	m_11;
	CEdit	m_10;
	CEdit	m_9;
	CEdit	m_8;
	CEdit	m_7;
	CEdit	m_6;
	CEdit	m_5;
	CEdit	m_4;
	CEdit	m_3;
	CEdit	m_2;
	CEdit	m_1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDirectoryEdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDirectoryEdDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIRECTORYEDDLG_H__06DD28C3_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
