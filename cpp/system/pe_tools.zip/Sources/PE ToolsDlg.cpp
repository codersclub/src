// PE ToolsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "PE ToolsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

char szPEOpenFilter[] = 
{
   "Executable Files (*.exe)|" "*.exe|"
   "Dynamic-Link Library Files (*.dll)|" "*.dll|"
   "ActiveX Control Files (*.ocx)|" "*.ocx|" 
   "All Files (*.*)|" "*.*||" 
};
/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	CHyperLink	m_HL1;
	CHyperLink	m_HL2;
	CHyperLink	m_HL3;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	DDX_Control(pDX, IDC_NEOX_EMAIL, m_HL1);
	DDX_Control(pDX, IDC_NEOX_WEB, m_HL2);
	DDX_Control(pDX, IDC_WEB_UINC, m_HL3);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPEToolsDlg dialog

CPEToolsDlg::CPEToolsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPEToolsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPEToolsDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPEToolsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPEToolsDlg)
	DDX_Control(pDX, IDC_SAVE, m_SaveO);
	DDX_Control(pDX, IDC_RO, m_RO);
	DDX_Control(pDX, IDC_BAK, m_Bak);
	DDX_Control(pDX, ID_BROWSE, m_Browse);
	DDX_Control(pDX, IDC_TABL_OFFSET, m_14);
	DDX_Control(pDX, IDC_RELOC_COUNT, m_13);
	DDX_Control(pDX, IDC_RELO_SS, m_12);
	DDX_Control(pDX, IDC_RELO_CS, m_11);
	DDX_Control(pDX, IDC_PART_PAGE, m_10);
	DDX_Control(pDX, IDC_PAGE_COUNT, m_9);
	DDX_Control(pDX, IDC_OVERLAY, m_8);
	DDX_Control(pDX, IDC_OFFST_TO_PE, m_7);
	DDX_Control(pDX, IDC_MIN_MEM, m_6);
	DDX_Control(pDX, IDC_MAX_MEM, m_5);
	DDX_Control(pDX, IDC_HDR_SIZE, m_4);
	DDX_Control(pDX, IDC_EXEIP, m_3);
	DDX_Control(pDX, IDC_EXE_SP, m_2);
	DDX_Control(pDX, IDC_CRC, m_1);
	DDX_Control(pDX, ID_SAVE_DOS, m_Save);
	DDX_Control(pDX, ID_SECTION, m_Section);
	DDX_Control(pDX, ID_PE_HEADER, m_Header);
	DDX_Control(pDX, ID_DIRECTORY, m_Directory);
	DDX_Control(pDX, ID_ADVANCED, m_Advanced);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPEToolsDlg, CDialog)
	//{{AFX_MSG_MAP(CPEToolsDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(ID_BROWSE, OnBrowse)
	ON_BN_CLICKED(ID_PE_HEADER, OnPeHeader)
	ON_BN_CLICKED(ID_SECTION, OnSection)
	ON_BN_CLICKED(ID_DIRECTORY, OnDirectory)
	ON_BN_CLICKED(ID_ADVANCED, OnAdvanced)
	ON_BN_CLICKED(ID_SAVE_DOS, OnSaveDos)
	ON_BN_CLICKED(ID_ABOUT, OnAbout)
	ON_BN_CLICKED(ID_EXIT, OnExit)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPEToolsDlg message handlers

BOOL CPEToolsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	pSysMenu->DeleteMenu(SC_SIZE, MF_BYCOMMAND);
    pSysMenu->DeleteMenu(SC_RESTORE, MF_BYCOMMAND);
    pSysMenu->DeleteMenu(SC_MAXIMIZE, MF_BYCOMMAND);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	CHAR buf[MAX_PATH];
	if(AfxGetApp()->GetProfileInt("Settings", "Save", 0) == 1)
	{
	   m_SaveO.SetCheck(AfxGetApp()->GetProfileInt("Settings", "Save", 0));
	   m_Bak.SetCheck(AfxGetApp()->GetProfileInt("Settings", "Backup", 0));
	   m_RO.SetCheck(AfxGetApp()->GetProfileInt("Settings", "IsReadOnly", 0));

	   if(m_RO.GetCheck()) IsReadOnly = TRUE;
	}

	m_Header.EnableWindow(FALSE);
	m_Section.EnableWindow(FALSE);
	m_Directory.EnableWindow(FALSE);
	m_Advanced.EnableWindow(FALSE);
	m_Save.EnableWindow(FALSE);
	
	m_1.SetLimitText(8);
	m_2.SetLimitText(8);
	m_3.SetLimitText(8);
	m_4.SetLimitText(8);
	m_5.SetLimitText(8);
	m_6.SetLimitText(8);
	m_7.SetLimitText(8);
	m_8.SetLimitText(8);
	m_9.SetLimitText(8);
	m_10.SetLimitText(8);
	m_11.SetLimitText(8);
	m_12.SetLimitText(8);
	m_13.SetLimitText(8);
	m_14.SetLimitText(8);

	m_1.EnableWindow(FALSE);
	m_2.EnableWindow(FALSE);
	m_3.EnableWindow(FALSE);
	m_4.EnableWindow(FALSE);
	m_5.EnableWindow(FALSE);
	m_6.EnableWindow(FALSE);
	m_7.EnableWindow(FALSE);
	m_8.EnableWindow(FALSE);
	m_9.EnableWindow(FALSE);
	m_10.EnableWindow(FALSE);
	m_11.EnableWindow(FALSE);
	m_12.EnableWindow(FALSE);
	m_13.EnableWindow(FALSE);
	m_14.EnableWindow(FALSE);

	if(GetLongPathName(AfxGetApp()->m_lpCmdLine, buf, MAX_PATH) != 0)
	{
	    if (strlen(buf) != 0) LoadPEFile(buf);
	}

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPEToolsDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPEToolsDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPEToolsDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}
//		if(IsOpen & TRUE) m_PEFile.Close();
void CPEToolsDlg::OnBrowse() 
{
	IsReadOnly = m_RO.GetCheck();
	if(IsOpen & TRUE)
	{
		UnloadPEFile();
	}
	else
	{
	    CFileDialog DlgOpen(TRUE, NULL,NULL, OFN_HIDEREADONLY, szPEOpenFilter);
	    if(DlgOpen.DoModal()==IDOK) 
		{
	    	LoadPEFile(DlgOpen.GetPathName());
		}
	}
}

void CPEToolsDlg::OnPeHeader() 
{
	CPEheaderEdDlg dlg;
	dlg.DoModal();
}

void CPEToolsDlg::OnSection() 
{
	CSectionsEdDlg dlg;
	dlg.DoModal();
}

void CPEToolsDlg::OnDirectory() 
{
	CDirectoryEdDlg dlg;
	dlg.DoModal();
}

void CPEToolsDlg::OnAdvanced() 
{
	CAdvancedEdDlg dlg;
	dlg.DoModal();
}

void CPEToolsDlg::OnSaveDos() 
{
	CString tmp;
	if((MessageBox("Save DOS Header?", "PE Header Editor", MB_YESNO | MB_ICONQUESTION)) == IDYES)
	{
		GetDlgItemText(IDC_PART_PAGE,   tmp);
		m_PEFile.DOSHdr.PartPag = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_PAGE_COUNT, tmp);
		m_PEFile.DOSHdr.PageCnt = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_RELOC_COUNT, tmp);
		m_PEFile.DOSHdr.ReloCnt = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_HDR_SIZE, tmp);
		m_PEFile.DOSHdr.HdrSize = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_MAX_MEM, tmp);
		m_PEFile.DOSHdr.MaxMemory = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_MIN_MEM, tmp);
		m_PEFile.DOSHdr.MinMemory = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_RELO_SS, tmp);
		m_PEFile.DOSHdr.ReloSS = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_EXE_SP, tmp);
		m_PEFile.DOSHdr.ExeSP = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_CRC, tmp);
		m_PEFile.DOSHdr.ChkSum = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_EXEIP, tmp);
		m_PEFile.DOSHdr.ExeIP = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_RELO_SS, tmp);
		m_PEFile.DOSHdr.ReloSS = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_RELO_CS, tmp);
		m_PEFile.DOSHdr.ReloCS = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_TABL_OFFSET, tmp);
		m_PEFile.DOSHdr.TablOff = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_OVERLAY, tmp);
		m_PEFile.DOSHdr.Overlay = (WORD)ConvFromHex(tmp);
		GetDlgItemText(IDC_OFFST_TO_PE, tmp);
		m_PEFile.DOSHdr.OffsetToPEHeader = (WORD)ConvFromHex(tmp);

		m_PEFile.WriteDOSHeader();
	}
	else return;
}

void CPEToolsDlg::OnAbout() 
{
	CAboutDlg dlgAbout;
	dlgAbout.DoModal();
}

void CPEToolsDlg::OnExit() 
{
	if(IsOpen & TRUE) m_PEFile.Close();
	SaveSetting();
	exit(0);
}

VOID CPEToolsDlg::LoadPEFile(CString szFile)
{
	CString Caption, err;
	m_OpenedPEFile = szFile;

	if(m_Bak.GetCheck() == TRUE) CopyFile(szFile, szFile + ".bak", true);

		if(m_PEFile.Open(m_OpenedPEFile, IsReadOnly) != 0)
		{

			if(IsReadOnly == 1) goto skip;
			if(m_PEFile.CheckAccess() == FALSE)
			{
				err.Format("Error while accesing the file %s (READ/WRITE).", szFile);
				AfxMessageBox(err, MB_ICONERROR);
				return;
			}
skip:
			if (m_PEFile.IsPEFile() == FALSE)
			{
				AfxMessageBox(ERR_PE, MB_ICONERROR);
				return;
			}

		    IsOpen = TRUE;

			Caption.Format("PE Tools v1.3 - [%s]", szFile);
		    SetWindowText(Caption);

			m_PEFile.ReadDOSHeader();
		    m_PEFile.ReadPEHeader();
		    SetDosInfos();

		    SetDlgItemText(IDC_PE_FILE, m_OpenedPEFile);

			m_1.EnableWindow(TRUE);
	        m_2.EnableWindow(TRUE);
	        m_3.EnableWindow(TRUE);
	        m_4.EnableWindow(TRUE);
	        m_5.EnableWindow(TRUE);
	        m_6.EnableWindow(TRUE);
	        m_7.EnableWindow(TRUE);
	        m_8.EnableWindow(TRUE);
	        m_9.EnableWindow(TRUE);
	        m_10.EnableWindow(TRUE);
	        m_11.EnableWindow(TRUE);
	        m_12.EnableWindow(TRUE);
	        m_13.EnableWindow(TRUE);
	        m_14.EnableWindow(TRUE);

			m_Header.EnableWindow(TRUE);
	        m_Section.EnableWindow(TRUE);
	        m_Directory.EnableWindow(TRUE);
	        m_Advanced.EnableWindow(TRUE);
			if(IsReadOnly == 1)
			{
				m_Save.EnableWindow(FALSE);
			}
			else m_Save.EnableWindow(TRUE);

			m_Browse.SetWindowText("&Close...");
		}
		else
		{
			err.Format("Error while accesing the file %s (READ/WRITE).", szFile);
			AfxMessageBox(err, MB_ICONERROR);
			return;
		}
}

VOID CPEToolsDlg::SetDosInfos(VOID)
{
	SetDlgItemText(IDC_PART_PAGE, ConvToHEXStr(m_PEFile.DOSHdr.PartPag));
	SetDlgItemText(IDC_PAGE_COUNT, ConvToHEXStr(m_PEFile.DOSHdr.PageCnt));
	SetDlgItemText(IDC_RELOC_COUNT, ConvToHEXStr(m_PEFile.DOSHdr.ReloCnt));
	SetDlgItemText(IDC_HDR_SIZE, ConvToHEXStr(m_PEFile.DOSHdr.HdrSize));
	SetDlgItemText(IDC_MIN_MEM, ConvToHEXStr(m_PEFile.DOSHdr.MinMemory));
	SetDlgItemText(IDC_MAX_MEM, ConvToHEXStr(m_PEFile.DOSHdr.MaxMemory));
	SetDlgItemText(IDC_RELO_SS, ConvToHEXStr(m_PEFile.DOSHdr.ReloSS));
	SetDlgItemText(IDC_EXE_SP, ConvToHEXStr(m_PEFile.DOSHdr.ExeSP));
	SetDlgItemText(IDC_CRC, ConvToHEXStr(m_PEFile.DOSHdr.ChkSum));
	SetDlgItemText(IDC_EXEIP, ConvToHEXStr(m_PEFile.DOSHdr.ExeIP));
	SetDlgItemText(IDC_RELO_CS, ConvToHEXStr(m_PEFile.DOSHdr.ReloCS));
	SetDlgItemText(IDC_TABL_OFFSET, ConvToHEXStr(m_PEFile.DOSHdr.TablOff));
	SetDlgItemText(IDC_OVERLAY, ConvToHEXStr(m_PEFile.DOSHdr.Overlay));
	SetDlgItemText(IDC_OFFST_TO_PE, ConvToHEXStr(m_PEFile.DOSHdr.OffsetToPEHeader));
}

VOID CPEToolsDlg::UnloadPEFile()
{
	IsOpen = FALSE;
	m_PEFile.Close();
	m_Browse.SetWindowText("&Open...");
	SetWindowText("PE Tools v1.3");
	SetDlgItemText(IDC_PE_FILE, "");

	SetDlgItemText(IDC_PART_PAGE, "");
	SetDlgItemText(IDC_PAGE_COUNT, "");
	SetDlgItemText(IDC_RELOC_COUNT, "");
	SetDlgItemText(IDC_HDR_SIZE, "");
	SetDlgItemText(IDC_MIN_MEM, "");
	SetDlgItemText(IDC_MAX_MEM, "");
	SetDlgItemText(IDC_RELO_SS, "");
	SetDlgItemText(IDC_EXE_SP, "");
	SetDlgItemText(IDC_CRC, "");
	SetDlgItemText(IDC_EXEIP, "");
	SetDlgItemText(IDC_RELO_CS, "");
	SetDlgItemText(IDC_TABL_OFFSET, "");
	SetDlgItemText(IDC_OVERLAY, "");
	SetDlgItemText(IDC_OFFST_TO_PE, "");

	m_1.EnableWindow(FALSE);
	m_2.EnableWindow(FALSE);
	m_3.EnableWindow(FALSE);
	m_4.EnableWindow(FALSE);
	m_5.EnableWindow(FALSE);
	m_6.EnableWindow(FALSE);
	m_7.EnableWindow(FALSE);
	m_8.EnableWindow(FALSE);
	m_9.EnableWindow(FALSE);
	m_10.EnableWindow(FALSE);
	m_11.EnableWindow(FALSE);
	m_12.EnableWindow(FALSE);
	m_13.EnableWindow(FALSE);
	m_14.EnableWindow(FALSE);


	m_Header.EnableWindow(FALSE);
	m_Section.EnableWindow(FALSE);
	m_Directory.EnableWindow(FALSE);
	m_Advanced.EnableWindow(FALSE);
	m_Save.EnableWindow(FALSE);
}

VOID CPEToolsDlg::SaveSetting()
{
	AfxGetApp()->WriteProfileInt("Settings", "Backup", m_Bak.GetCheck());
	AfxGetApp()->WriteProfileInt("Settings", "IsReadOnly", m_RO.GetCheck());
	AfxGetApp()->WriteProfileInt("Settings", "Save", m_SaveO.GetCheck());
}

void CPEToolsDlg::OnDestroy() 
{
	CDialog::OnDestroy();
	SaveSetting();
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	m_HL1.SetURL("mailto:NEOx@Pisem.net");
	m_HL2.SetURL("http://www.N-Soft.by.ru");
	m_HL3.SetURL("http://www.uinc.ru");

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
