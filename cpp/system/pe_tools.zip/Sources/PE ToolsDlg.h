// PE ToolsDlg.h : header file
//

#if !defined(AFX_PETOOLSDLG_H__4E56EA26_7274_11D6_8219_E1329186B97F__INCLUDED_)
#define AFX_PETOOLSDLG_H__4E56EA26_7274_11D6_8219_E1329186B97F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "AdvancedEdDlg.h"
#include "DirectoryEdDlg.h"
#include "PEheaderEdDlg.h"
#include "SectionsEdDlg.h"
#include "HyperLink.h"
/////////////////////////////////////////////////////////////////////////////
// CPEToolsDlg dialog

class CPEToolsDlg : public CDialog
{
// Construction
public:
	virtual VOID SaveSetting(VOID);
	virtual VOID UnloadPEFile(VOID);
	virtual VOID SetDosInfos(VOID);
	virtual VOID LoadPEFile(CString szFile);
	CPEToolsDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPEToolsDlg)
	enum { IDD = IDD_PETOOLS_DIALOG };
	CButton	m_SaveO;
	CButton	m_RO;
	CButton	m_Bak;
	CButton	m_Browse;
	CEdit	m_14;
	CEdit	m_13;
	CEdit	m_12;
	CEdit	m_11;
	CEdit	m_10;
	CEdit	m_9;
	CEdit	m_8;
	CEdit	m_7;
	CEdit	m_6;
	CEdit	m_5;
	CEdit	m_4;
	CEdit	m_3;
	CEdit	m_2;
	CEdit	m_1;
	CButton	m_Save;
	CButton	m_Section;
	CButton	m_Header;
	CButton	m_Directory;
	CButton	m_Advanced;

	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPEToolsDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CPEToolsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnBrowse();
	afx_msg void OnPeHeader();
	afx_msg void OnSection();
	afx_msg void OnDirectory();
	afx_msg void OnAdvanced();
	afx_msg void OnSaveDos();
	afx_msg void OnAbout();
	afx_msg void OnExit();
	afx_msg void OnDestroy();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PETOOLSDLG_H__4E56EA26_7274_11D6_8219_E1329186B97F__INCLUDED_)
