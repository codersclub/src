#if !defined(AFX_MODIFYVALDLG_H__2A24B140_731A_11D6_8219_F3AE8149ED7F__INCLUDED_)
#define AFX_MODIFYVALDLG_H__2A24B140_731A_11D6_8219_F3AE8149ED7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ModifyValDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CModifyValDlg dialog

class CModifyValDlg : public CDialog
{
// Construction
public:
	CModifyValDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CModifyValDlg)
	enum { IDD = IDD_MODIFY_SECTION_VALUE };
	CEdit	m_6;
	CEdit	m_5;
	CEdit	m_4;
	CEdit	m_3;
	CEdit	m_2;
	CEdit	m_1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CModifyValDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CModifyValDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnOk();
	afx_msg void OnCancel();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MODIFYVALDLG_H__2A24B140_731A_11D6_8219_F3AE8149ED7F__INCLUDED_)
