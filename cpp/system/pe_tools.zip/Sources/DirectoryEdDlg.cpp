// DirectoryEdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "DirectoryEdDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDirectoryEdDlg dialog


CDirectoryEdDlg::CDirectoryEdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CDirectoryEdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CDirectoryEdDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDirectoryEdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDirectoryEdDlg)
	DDX_Control(pDX, ID_Ok, m_OK);
	DDX_Control(pDX, IDC_DIR9, m_24);
	DDX_Control(pDX, IDC_DIR8, m_23);
	DDX_Control(pDX, IDC_DIR7, m_22);
	DDX_Control(pDX, IDC_DIR6, m_21);
	DDX_Control(pDX, IDC_DIR5, m_20);
	DDX_Control(pDX, IDC_DIR4, m_19);
	DDX_Control(pDX, IDC_DIR3, m_18);
	DDX_Control(pDX, IDC_DIR24, m_17);
	DDX_Control(pDX, IDC_DIR23, m_16);
	DDX_Control(pDX, IDC_DIR22, m_15);
	DDX_Control(pDX, IDC_DIR21, m_14);
	DDX_Control(pDX, IDC_DIR20, m_13);
	DDX_Control(pDX, IDC_DIR2, m_12);
	DDX_Control(pDX, IDC_DIR19, m_11);
	DDX_Control(pDX, IDC_DIR18, m_10);
	DDX_Control(pDX, IDC_DIR17, m_9);
	DDX_Control(pDX, IDC_DIR16, m_8);
	DDX_Control(pDX, IDC_DIR15, m_7);
	DDX_Control(pDX, IDC_DIR14, m_6);
	DDX_Control(pDX, IDC_DIR13, m_5);
	DDX_Control(pDX, IDC_DIR12, m_4);
	DDX_Control(pDX, IDC_DIR11, m_3);
	DDX_Control(pDX, IDC_DIR10, m_2);
	DDX_Control(pDX, IDC_DIR1, m_1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CDirectoryEdDlg, CDialog)
	//{{AFX_MSG_MAP(CDirectoryEdDlg)
	ON_BN_CLICKED(ID_Ok, OnOk)
	ON_BN_CLICKED(ID_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDirectoryEdDlg message handlers

BOOL CDirectoryEdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(IsReadOnly == 1)
	{
		SetWindowText("Directory Editor - [Read-Only]");
		m_OK.EnableWindow(FALSE);
	}
	
	m_1.SetLimitText(8);
	m_2.SetLimitText(8);
	m_3.SetLimitText(8);
	m_4.SetLimitText(8);
	m_5.SetLimitText(8);
	m_6.SetLimitText(8);
	m_7.SetLimitText(8);
	m_8.SetLimitText(8);
	m_9.SetLimitText(8);
	m_10.SetLimitText(8);
	m_11.SetLimitText(8);
	m_12.SetLimitText(8);
	m_13.SetLimitText(8);
	m_14.SetLimitText(8);
	m_15.SetLimitText(8);
	m_16.SetLimitText(8);
	m_17.SetLimitText(8);
	m_18.SetLimitText(8);
	m_19.SetLimitText(8);
	m_20.SetLimitText(8);
	m_21.SetLimitText(8);
	m_22.SetLimitText(8);
	m_23.SetLimitText(8);
	m_24.SetLimitText(8);


	SetDlgItemText(IDC_DIR1, ConvToHEXStr(m_PEFile.PEHdr.ExportTableRVA));
	SetDlgItemText(IDC_DIR2, ConvToHEXStr(m_PEFile.PEHdr.ExportDataSize));
	SetDlgItemText(IDC_DIR3, ConvToHEXStr(m_PEFile.PEHdr.ImportTableRVA));
	SetDlgItemText(IDC_DIR4, ConvToHEXStr(m_PEFile.PEHdr.ImportDataSize));
	SetDlgItemText(IDC_DIR5, ConvToHEXStr(m_PEFile.PEHdr.ResourceTableRVA));
	SetDlgItemText(IDC_DIR6, ConvToHEXStr(m_PEFile.PEHdr.ResourceDataSize));
	SetDlgItemText(IDC_DIR7, ConvToHEXStr(m_PEFile.PEHdr.SecurityTableRVA));
	SetDlgItemText(IDC_DIR8, ConvToHEXStr(m_PEFile.PEHdr.SecurityDataSize));
	SetDlgItemText(IDC_DIR9, ConvToHEXStr(m_PEFile.PEHdr.TLSRVA));
	SetDlgItemText(IDC_DIR10, ConvToHEXStr(m_PEFile.PEHdr.TLSDataSize));
	SetDlgItemText(IDC_DIR11, ConvToHEXStr(m_PEFile.PEHdr.LoadConfigRVA));
	SetDlgItemText(IDC_DIR12, ConvToHEXStr(m_PEFile.PEHdr.LoadConfigDataSize));
	SetDlgItemText(IDC_DIR13, ConvToHEXStr(m_PEFile.PEHdr.DebugTableRVA));
	SetDlgItemText(IDC_DIR14, ConvToHEXStr(m_PEFile.PEHdr.DebugDataSize));
	SetDlgItemText(IDC_DIR15, ConvToHEXStr(m_PEFile.PEHdr.ExceptionTableRVA));
	SetDlgItemText(IDC_DIR16, ConvToHEXStr(m_PEFile.PEHdr.ExceptionDataSize));
	SetDlgItemText(IDC_DIR17, ConvToHEXStr(m_PEFile.PEHdr.FixUpTableRVA));
	SetDlgItemText(IDC_DIR18, ConvToHEXStr(m_PEFile.PEHdr.FixUpDataSize));
	SetDlgItemText(IDC_DIR19, ConvToHEXStr(m_PEFile.PEHdr.IATRVA));
	SetDlgItemText(IDC_DIR20, ConvToHEXStr(m_PEFile.PEHdr.IATDataSize));
	SetDlgItemText(IDC_DIR21, ConvToHEXStr(m_PEFile.PEHdr.ImageDescriptionRVA));
	SetDlgItemText(IDC_DIR22, ConvToHEXStr(m_PEFile.PEHdr.DescriptionDataSize));
	SetDlgItemText(IDC_DIR23, ConvToHEXStr(m_PEFile.PEHdr.MachineSpecificRVA));
	SetDlgItemText(IDC_DIR24, ConvToHEXStr(m_PEFile.PEHdr.MachnineDataSize));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CDirectoryEdDlg::OnOk() 
{
	CString tmp;
	if((MessageBox("Save directory informations?", "Directory Editor", MB_YESNO | MB_ICONQUESTION)) == IDYES)
	{
		GetDlgItemText(IDC_DIR1, tmp);
		m_PEFile.PEHdr.ExportTableRVA  = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR2, tmp);
	    m_PEFile.PEHdr.ExportDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR3, tmp);
	    m_PEFile.PEHdr.ImportTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR4, tmp);
	    m_PEFile.PEHdr.ImportDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR5, tmp);
	    m_PEFile.PEHdr.ResourceTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR6, tmp);
	    m_PEFile.PEHdr.ResourceDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR7, tmp);
	    m_PEFile.PEHdr.SecurityTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR8, tmp);
	    m_PEFile.PEHdr.SecurityDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR9, tmp);
	    m_PEFile.PEHdr.TLSRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR10, tmp);
	    m_PEFile.PEHdr.TLSDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR11, tmp);
	    m_PEFile.PEHdr.LoadConfigRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR12, tmp);
	    m_PEFile.PEHdr.LoadConfigDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR13, tmp);
	    m_PEFile.PEHdr.DebugTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR14, tmp);
	    m_PEFile.PEHdr.DebugDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR15, tmp);
	    m_PEFile.PEHdr.ExceptionTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR16, tmp);
	    m_PEFile.PEHdr.ExceptionDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR17, tmp);
	    m_PEFile.PEHdr.FixUpTableRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR18, tmp);
	    m_PEFile.PEHdr.FixUpDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR19, tmp);
    	m_PEFile.PEHdr.IATRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR20, tmp);
    	m_PEFile.PEHdr.IATDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR21, tmp);
    	m_PEFile.PEHdr.ImageDescriptionRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR22, tmp);
	    m_PEFile.PEHdr.DescriptionDataSize = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR23, tmp);
	    m_PEFile.PEHdr.MachineSpecificRVA = ConvFromHex(tmp);
		GetDlgItemText(IDC_DIR24, tmp);
	    m_PEFile.PEHdr.MachnineDataSize = ConvFromHex(tmp);

		m_PEFile.WritePEHeader();
		CDialog::OnOK();
	}
	else CDialog::OnOK();
}

void CDirectoryEdDlg::OnCancel() 
{
	CDialog::OnCancel();
}
