#if !defined(AFX_SECTIONSEDDLG_H__06DD28C2_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
#define AFX_SECTIONSEDDLG_H__06DD28C2_730B_11D6_8219_F3AE8149ED7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SectionsEdDlg.h : header file
//
#include "ModifyValDlg.h"
/////////////////////////////////////////////////////////////////////////////
// CSectionsEdDlg dialog

class CSectionsEdDlg : public CDialog
{
// Construction
public:
	CSectionsEdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSectionsEdDlg)
	enum { IDD = IDD_SECTIONS_EDITOR };
	CButton	m_OK;
	CListCtrl	m_Sections;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSectionsEdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSectionsEdDlg)
	afx_msg void OnOk();
	afx_msg void OnCancel();
	virtual BOOL OnInitDialog();
	afx_msg void OnDblclkSections(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SECTIONSEDDLG_H__06DD28C2_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
