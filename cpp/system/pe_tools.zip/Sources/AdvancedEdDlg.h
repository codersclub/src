#if !defined(AFX_ADVANCEDEDDLG_H__06DD28C1_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
#define AFX_ADVANCEDEDDLG_H__06DD28C1_730B_11D6_8219_F3AE8149ED7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AdvancedEdDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAdvancedEdDlg dialog

class CAdvancedEdDlg : public CDialog
{
// Construction
public:
	CAdvancedEdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAdvancedEdDlg)
	enum { IDD = IDD_ADVANCED_EDITOR };
	CButton	m_OK;
	CComboBox	m_CPUType;
	CComboBox	m_SSFlags;
	CEdit	m_16;
	CEdit	m_15;
	CEdit	m_14;
	CEdit	m_13;
	CEdit	m_12;
	CEdit	m_11;
	CEdit	m_10;
	CEdit	m_9;
	CEdit	m_8;
	CEdit	m_7;
	CEdit	m_6;
	CEdit	m_5;
	CEdit	m_4;
	CEdit	m_3;
	CEdit	m_2;
	CEdit	m_1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAdvancedEdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAdvancedEdDlg)
	afx_msg void OnOk();
	afx_msg void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADVANCEDEDDLG_H__06DD28C1_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
