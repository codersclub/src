// SectionsEdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "SectionsEdDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#pragma warning(disable:4018)
/////////////////////////////////////////////////////////////////////////////
// CSectionsEdDlg dialog


CSectionsEdDlg::CSectionsEdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSectionsEdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSectionsEdDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSectionsEdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSectionsEdDlg)
	DDX_Control(pDX, ID_Ok, m_OK);
	DDX_Control(pDX, IDC_SECTIONS, m_Sections);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSectionsEdDlg, CDialog)
	//{{AFX_MSG_MAP(CSectionsEdDlg)
	ON_BN_CLICKED(ID_Ok, OnOk)
	ON_BN_CLICKED(ID_CANCEL, OnCancel)
	ON_NOTIFY(NM_DBLCLK, IDC_SECTIONS, OnDblclkSections)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSectionsEdDlg message handlers

BOOL CSectionsEdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(IsReadOnly == 1)
	{
		SetWindowText("Sections Editor - [Read-Only]");
		m_OK.EnableWindow(FALSE);
	}
	
	INT cnt = 0;

	m_Sections.DeleteAllItems();
	m_Sections.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	m_Sections.SetTextColor(RGB(31,17,157));

	m_Sections.InsertColumn(0, "Name", LVCFMT_LEFT, 55);
    m_Sections.InsertColumn(1, "Virtual Size", LVCFMT_CENTER, 65);
	m_Sections.InsertColumn(2, "Virtual Offset", LVCFMT_CENTER, 80);
	m_Sections.InsertColumn(3, "Raw Size", LVCFMT_CENTER, 65);
	m_Sections.InsertColumn(4, "Raw Offset", LVCFMT_CENTER, 70);
	m_Sections.InsertColumn(5, "Flags", LVCFMT_CENTER, 65);

	m_PEFile.SeekToObjectEntry();

	for(int x = 0; x<m_PEFile.PEHdr.NumOfSections; x++)
	{
		m_PEFile.ReadObjectEntry();

		m_Sections.InsertItem(cnt, (const char *)m_PEFile.ObjEntry.ObjectName);
	
		m_Sections.SetItemText(cnt, 1, ConvToHEXStr(m_PEFile.ObjEntry.VirtualSize));
		m_Sections.SetItemText(cnt, 2, ConvToHEXStr(m_PEFile.ObjEntry.PhysicalOffset));
		m_Sections.SetItemText(cnt, 3, ConvToHEXStr(m_PEFile.ObjEntry.PhysicalSize));
		m_Sections.SetItemText(cnt, 4, ConvToHEXStr(m_PEFile.ObjEntry.SectionRVA));
		m_Sections.SetItemText(cnt, 5, ConvToHEXStr(m_PEFile.ObjEntry.ObjectFlags));
		cnt++;
	}

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSectionsEdDlg::OnOk() 
{
	if((MessageBox("Save sections?", "Sections Editor", MB_YESNO | MB_ICONQUESTION)) == IDYES)
	{
		m_PEFile.SeekToObjectEntry();

		for(m_iNdex = 0; m_iNdex<m_PEFile.PEHdr.NumOfSections; m_iNdex++)
		{
			memset(&m_PEFile.ObjEntry, 0, sizeof(ObjectEntry));

			m_Sections.GetItemText(m_iNdex, 0, m_SectionName, 8);
			strcpy((CHAR *)m_PEFile.ObjEntry.ObjectName, m_SectionName);

	        m_Sections.GetItemText(m_iNdex, 1, m_VSize,       9);
			m_PEFile.ObjEntry.VirtualSize    = ConvFromHex(m_VSize);

	        m_Sections.GetItemText(m_iNdex, 2, m_VOffset,     9);
			m_PEFile.ObjEntry.PhysicalOffset = ConvFromHex(m_VOffset);

	        m_Sections.GetItemText(m_iNdex, 3, m_RSize,       9);
			m_PEFile.ObjEntry.PhysicalSize   = ConvFromHex(m_RSize);

	        m_Sections.GetItemText(m_iNdex, 4, m_ROffset,     9);
			m_PEFile.ObjEntry.SectionRVA = ConvFromHex(m_ROffset);

	        m_Sections.GetItemText(m_iNdex, 5, m_Charact,     9);
			m_PEFile.ObjEntry.ObjectFlags    = ConvFromHex(m_Charact);

			m_PEFile.WriteObjectEntry();
		}
		CDialog::OnOK();
	}
	else CDialog::OnOK();
}

void CSectionsEdDlg::OnCancel() 
{
	CDialog::OnCancel();
}

void CSectionsEdDlg::OnDblclkSections(NMHDR* pNMHDR, LRESULT* pResult) 
{
	CModifyValDlg dlg;
    m_iNdex = m_Sections.GetSelectionMark();

	if(m_iNdex > m_Sections.GetItemCount()) goto skip;

	m_Sections.GetItemText(m_iNdex, 0, m_SectionName, 8);
	m_Sections.GetItemText(m_iNdex, 1, m_VSize,       9);
	m_Sections.GetItemText(m_iNdex, 2, m_VOffset,     9);
	m_Sections.GetItemText(m_iNdex, 3, m_RSize,       9);
	m_Sections.GetItemText(m_iNdex, 4, m_ROffset,     9);
	m_Sections.GetItemText(m_iNdex, 5, m_Charact,     9);

	dlg.DoModal();

	m_Sections.SetItemText(m_iNdex, 0, m_SectionName);
	m_Sections.SetItemText(m_iNdex, 1, m_VSize);
	m_Sections.SetItemText(m_iNdex, 2, m_VOffset);
	m_Sections.SetItemText(m_iNdex, 3, m_RSize);
	m_Sections.SetItemText(m_iNdex, 4, m_ROffset);
	m_Sections.SetItemText(m_iNdex, 5, m_Charact);

skip:
	*pResult = 0;
}