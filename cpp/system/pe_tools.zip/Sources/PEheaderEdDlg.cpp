// PEheaderEdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "PEheaderEdDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPEheaderEdDlg dialog


CPEheaderEdDlg::CPEheaderEdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPEheaderEdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPEheaderEdDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPEheaderEdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPEheaderEdDlg)
	DDX_Control(pDX, ID_Ok, m_OK);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPEheaderEdDlg, CDialog)
	//{{AFX_MSG_MAP(CPEheaderEdDlg)
	ON_BN_CLICKED(ID_Ok, OnOk)
	ON_BN_CLICKED(ID_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPEheaderEdDlg message handlers

BOOL CPEheaderEdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(IsReadOnly == 1)
	{
		SetWindowText("PE Header Editor - [Read-Only]");
		m_OK.EnableWindow(FALSE);
	}

	SetDlgItemText(IDC_ENTRY_POINT, ConvToHEXStr(m_PEFile.PEHdr.EntryPointRVA));
	SetDlgItemText(IDC_SIZE_OF_IMAGE, ConvToHEXStr(m_PEFile.PEHdr.ImageSize));
	SetDlgItemText(IDC_IMAGE_BASE, ConvToHEXStr(m_PEFile.PEHdr.ImageBase));
	SetDlgItemText(IDC_NT_HEADER_SIZE, ConvToHEXStr(m_PEFile.PEHdr.NTHeaderSize));
	SetDlgItemText(IDC_MAGIC, ConvToHEXStr(m_PEFile.PEHdr.Magic));
	SetDlgItemText(IDC_SIZE_OF_INIT_DATA, ConvToHEXStr(m_PEFile.PEHdr.SizeOfInitData));
	SetDlgItemText(IDC_SIZE_OF_UNINIT_DATA, ConvToHEXStr(m_PEFile.PEHdr.SizeOfUnInitData));
	SetDlgItemText(IDC_SIZE_OF_CODE, ConvToHEXStr(m_PEFile.PEHdr.SizeOfCode));
	SetDlgItemText(IDC_BASE_OF_CODE, ConvToHEXStr(m_PEFile.PEHdr.BaseOfCode));
	SetDlgItemText(IDC_BASE_OF_DATA, ConvToHEXStr(m_PEFile.PEHdr.BaseOfData));
	SetDlgItemText(IDC_FLAGS, ConvToHEXStr(m_PEFile.PEHdr.Flags));
	SetDlgItemText(IDC_DLL_FLAGS, ConvToHEXStr(m_PEFile.PEHdr.DLLFlags));
	SetDlgItemText(IDC_FILE_ALIGN, ConvToHEXStr(m_PEFile.PEHdr.FileAlign));
	SetDlgItemText(IDC_OBJ_ALIGN, ConvToHEXStr(m_PEFile.PEHdr.ObjectAlign));
	SetDlgItemText(IDC_LOADER_FLAGS, ConvToHEXStr(m_PEFile.PEHdr.LoaderFlags));
	SetDlgItemText(IDC_HEADER_SIZE, ConvToHEXStr(m_PEFile.PEHdr.HeaderSize));
		
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPEheaderEdDlg::OnOk() 
{
	CString tmp;
	if((MessageBox("Save PE Header?", "PE Header Editor", MB_YESNO | MB_ICONQUESTION)) == IDYES)
	{
		GetDlgItemText(IDC_ENTRY_POINT, tmp);
		m_PEFile.PEHdr.EntryPointRVA = ConvFromHex(tmp);
	    GetDlgItemText(IDC_SIZE_OF_IMAGE, tmp);
		m_PEFile.PEHdr.ImageSize = ConvFromHex(tmp);
	    GetDlgItemText(IDC_IMAGE_BASE, tmp);
		m_PEFile.PEHdr.ImageBase = ConvFromHex(tmp);
	    GetDlgItemText(IDC_NT_HEADER_SIZE, tmp);
		m_PEFile.PEHdr.NTHeaderSize = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_MAGIC, tmp);
		m_PEFile.PEHdr.Magic = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_SIZE_OF_INIT_DATA, tmp);
		m_PEFile.PEHdr.SizeOfInitData = ConvFromHex(tmp);
	    GetDlgItemText(IDC_SIZE_OF_UNINIT_DATA, tmp);
		m_PEFile.PEHdr.SizeOfUnInitData = ConvFromHex(tmp);
	    GetDlgItemText(IDC_SIZE_OF_CODE, tmp);
		m_PEFile.PEHdr.SizeOfCode = ConvFromHex(tmp);
	    GetDlgItemText(IDC_BASE_OF_CODE, tmp);
		m_PEFile.PEHdr.BaseOfCode = ConvFromHex(tmp);
	    GetDlgItemText(IDC_BASE_OF_DATA, tmp);
		m_PEFile.PEHdr.BaseOfData = ConvFromHex(tmp);
	    GetDlgItemText(IDC_FLAGS, tmp);
		m_PEFile.PEHdr.Flags = (WORD)ConvFromHex(tmp);
	    GetDlgItemText(IDC_DLL_FLAGS, tmp);
		m_PEFile.PEHdr.DLLFlags = (WORD)ConvFromHex(tmp);
    	GetDlgItemText(IDC_FILE_ALIGN, tmp);
		m_PEFile.PEHdr.FileAlign = ConvFromHex(tmp);
	    GetDlgItemText(IDC_OBJ_ALIGN, tmp);
		m_PEFile.PEHdr.ObjectAlign = ConvFromHex(tmp);
	    GetDlgItemText(IDC_LOADER_FLAGS, tmp);
		m_PEFile.PEHdr.LoaderFlags = ConvFromHex(tmp);
    	GetDlgItemText(IDC_HEADER_SIZE, tmp);
		m_PEFile.PEHdr.HeaderSize = ConvFromHex(tmp);

		m_PEFile.WritePEHeader();
		CDialog::OnOK();
	}
	else CDialog::OnOK();
}

void CPEheaderEdDlg::OnCancel() 
{
	CDialog::OnCancel();
}
