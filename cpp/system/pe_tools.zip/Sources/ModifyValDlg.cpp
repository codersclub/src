// ModifyValDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "ModifyValDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CModifyValDlg dialog


CModifyValDlg::CModifyValDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CModifyValDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CModifyValDlg)
	//}}AFX_DATA_INIT
}


void CModifyValDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CModifyValDlg)
	DDX_Control(pDX, IDC_FLAGS, m_6);
	DDX_Control(pDX, IDC_ROFFSET, m_5);
	DDX_Control(pDX, IDC_RSIZE, m_4);
	DDX_Control(pDX, IDC_VOFFSET, m_3);
	DDX_Control(pDX, IDC_VSIZE, m_2);
	DDX_Control(pDX, IDC_SEC_NAME, m_1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CModifyValDlg, CDialog)
	//{{AFX_MSG_MAP(CModifyValDlg)
	ON_BN_CLICKED(ID_Ok, OnOk)
	ON_BN_CLICKED(ID_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CModifyValDlg message handlers

BOOL CModifyValDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_1.SetLimitText(7);
	m_2.SetLimitText(8);
	m_3.SetLimitText(8);
	m_4.SetLimitText(8);
	m_5.SetLimitText(8);
	m_6.SetLimitText(8);


	SetDlgItemText(IDC_SEC_NAME,  m_SectionName);
	SetDlgItemText(IDC_VSIZE,   m_VSize);
	SetDlgItemText(IDC_VOFFSET, m_VOffset);
	SetDlgItemText(IDC_RSIZE,   m_RSize);
	SetDlgItemText(IDC_ROFFSET, m_ROffset);
	SetDlgItemText(IDC_FLAGS,   m_Charact);
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CModifyValDlg::OnOk() 
{
	CString tmp;
	GetDlgItemText(IDC_SEC_NAME, tmp);
	strcpy(m_SectionName, tmp);
	GetDlgItemText(IDC_VSIZE,    tmp);
	strcpy(m_VSize, tmp);
	GetDlgItemText(IDC_VOFFSET,  tmp);
	strcpy(m_VOffset, tmp);
	GetDlgItemText(IDC_RSIZE,    tmp);
	strcpy(m_RSize, tmp);
	GetDlgItemText(IDC_ROFFSET,  tmp);
	strcpy(m_ROffset, tmp);
	GetDlgItemText(IDC_FLAGS,    tmp);
	strcpy(m_Charact, tmp);
	CDialog::OnOK();
}

void CModifyValDlg::OnCancel() 
{
	CDialog::OnCancel();
}
