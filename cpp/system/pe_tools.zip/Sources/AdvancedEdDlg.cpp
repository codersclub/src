// AdvancedEdDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PE Tools.h"
#include "AdvancedEdDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAdvancedEdDlg dialog


CAdvancedEdDlg::CAdvancedEdDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAdvancedEdDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAdvancedEdDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAdvancedEdDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAdvancedEdDlg)
	DDX_Control(pDX, ID_Ok, m_OK);
	DDX_Control(pDX, IDC_CPU_TYPE, m_CPUType);
	DDX_Control(pDX, IDC_SUB_SYS_FLAGS, m_SSFlags);
	DDX_Control(pDX, IDC_STAMP, m_16);
	DDX_Control(pDX, IDC_CHECKSUM, m_15);
	DDX_Control(pDX, IDC_COFF_SIZE, m_14);
	DDX_Control(pDX, IDC_POINTER_COFF, m_13);
	DDX_Control(pDX, IDC_HP_COM_SZ, m_12);
	DDX_Control(pDX, IDC_HP_RES_SZ, m_11);
	DDX_Control(pDX, IDC_ST_RES_SZ, m_10);
	DDX_Control(pDX, IDC_ST_COM_SZ, m_9);
	DDX_Control(pDX, IDC_SUBS_MN, m_8);
	DDX_Control(pDX, IDC_SUBS_MJ, m_7);
	DDX_Control(pDX, IDC_USER_MN, m_6);
	DDX_Control(pDX, IDC_USER_MJ, m_5);
	DDX_Control(pDX, IDC_OS_MN, m_4);
	DDX_Control(pDX, IDC_OS_MJ, m_3);
	DDX_Control(pDX, IDC_LNK_MN, m_2);
	DDX_Control(pDX, IDC_LNK_MJ, m_1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAdvancedEdDlg, CDialog)
	//{{AFX_MSG_MAP(CAdvancedEdDlg)
	ON_BN_CLICKED(ID_Ok, OnOk)
	ON_BN_CLICKED(ID_CANCEL, OnCancel)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAdvancedEdDlg message handlers

BOOL CAdvancedEdDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();

	if(IsReadOnly == 1)
	{
		SetWindowText("Advanced Editor - [Read-Only]");
		m_OK.EnableWindow(FALSE);
	}

	m_1.SetLimitText(2);
	m_2.SetLimitText(2);
	m_3.SetLimitText(2);
	m_4.SetLimitText(2);
	m_5.SetLimitText(2);
	m_6.SetLimitText(2);
	m_7.SetLimitText(2);
	m_8.SetLimitText(2);
	m_9.SetLimitText(8);
	m_10.SetLimitText(8);
	m_11.SetLimitText(8);
	m_12.SetLimitText(8);
	m_13.SetLimitText(8);
	m_14.SetLimitText(8);
	m_15.SetLimitText(8);
	m_16.SetLimitText(8);


	switch(m_PEFile.PEHdr.SubSystem)
	{
		case 0x0000:
			m_SSFlags.SetCurSel(0);
			break;
		case 0x0001:
			m_SSFlags.SetCurSel(1);
			break;
		case 0x0002:
			m_SSFlags.SetCurSel(2);
			break;
		case 0x0003:
			m_SSFlags.SetCurSel(3);
			break;
		case 0x0005:
			m_SSFlags.SetCurSel(4);
			break;
		case 0x0007:
			m_SSFlags.SetCurSel(5);
			break;
	}

	switch(m_PEFile.PEHdr.CPUType)
	{
		case 0x0000:
			m_CPUType.SetCurSel(0);
			break;
		case 0x014C:
			m_CPUType.SetCurSel(1);
			break;
		case 0x0162:
			m_CPUType.SetCurSel(2);
			break;
		case 0x0166:
			m_CPUType.SetCurSel(3);
			break;
		case 0x0168:
			m_CPUType.SetCurSel(4);
			break;
		case 0x0169:
			m_CPUType.SetCurSel(5);
			break;
		case 0x0184:
			m_CPUType.SetCurSel(6);
			break;
		case 0x01F0:
			m_CPUType.SetCurSel(7);
			break;
		case 0x01A2:
			m_CPUType.SetCurSel(8);
			break;
		case 0x01A4:
			m_CPUType.SetCurSel(9);
			break;
		case 0x01A6:
			m_CPUType.SetCurSel(10);
			break;
		case 0x01C0:
			m_CPUType.SetCurSel(11);
			break;
		case 0x01C2:
			m_CPUType.SetCurSel(12);
			break;
		case 0x0200:
			m_CPUType.SetCurSel(13);
			break;
		case 0x0266:
			m_CPUType.SetCurSel(14);
			break;
		case 0x0366:
			m_CPUType.SetCurSel(15);
			break;
		case 0x0466:
			m_CPUType.SetCurSel(16);
			break;
		case 0x0284:
			m_CPUType.SetCurSel(17);
			break;
	}

	SetDlgItemInt(IDC_LNK_MJ, m_PEFile.PEHdr.LinkMajor);
	SetDlgItemInt(IDC_LNK_MN, m_PEFile.PEHdr.LinkMinor);
	SetDlgItemInt(IDC_OS_MJ,  m_PEFile.PEHdr.OSMajor);
	SetDlgItemInt(IDC_OS_MN,  m_PEFile.PEHdr.OSMinor);
	SetDlgItemInt(IDC_USER_MJ,m_PEFile.PEHdr.USERMajor);
	SetDlgItemInt(IDC_USER_MN,m_PEFile.PEHdr.USERMinor);
	SetDlgItemInt(IDC_SUBS_MJ, m_PEFile.PEHdr.SubSysMajor);
	SetDlgItemInt(IDC_SUBS_MN, m_PEFile.PEHdr.SubSysMinor);

	SetDlgItemText(IDC_ST_RES_SZ, ConvToHEXStr(m_PEFile.PEHdr.StackReserveSize));
    SetDlgItemText(IDC_ST_COM_SZ, ConvToHEXStr(m_PEFile.PEHdr.StackCommitSize));
	SetDlgItemText(IDC_HP_RES_SZ,  ConvToHEXStr(m_PEFile.PEHdr.HeapReserveSize));
	SetDlgItemText(IDC_HP_COM_SZ,  ConvToHEXStr(m_PEFile.PEHdr.HeapCommitSize));
	SetDlgItemText(IDC_POINTER_COFF,ConvToHEXStr(m_PEFile.PEHdr.PointerToCOFF));
	SetDlgItemText(IDC_COFF_SIZE,ConvToHEXStr(m_PEFile.PEHdr.COFFTableSize));
	SetDlgItemText(IDC_CHECKSUM, ConvToHEXStr(m_PEFile.PEHdr.FileChecksum));
	SetDlgItemText(IDC_STAMP, ConvToHEXStr(m_PEFile.PEHdr.TimeDateStamp));

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}


void CAdvancedEdDlg::OnOk() 
{
	CString tmp;
	if((MessageBox("Save advanced informations?", "Advanced Editor", MB_YESNO | MB_ICONQUESTION)) == IDYES)
	{
		m_PEFile.PEHdr.LinkMajor =   GetDlgItemInt(IDC_LNK_MJ);
	    m_PEFile.PEHdr.LinkMinor =   GetDlgItemInt(IDC_LNK_MN);
	    m_PEFile.PEHdr.OSMajor =     GetDlgItemInt(IDC_OS_MJ);
	    m_PEFile.PEHdr.OSMinor =     GetDlgItemInt(IDC_OS_MN);
	    m_PEFile.PEHdr.USERMajor =   GetDlgItemInt(IDC_USER_MJ);
	    m_PEFile.PEHdr.USERMinor =   GetDlgItemInt(IDC_USER_MN);
        m_PEFile.PEHdr.SubSysMajor = GetDlgItemInt(IDC_SUBS_MJ);
	    m_PEFile.PEHdr.SubSysMinor = GetDlgItemInt(IDC_SUBS_MN);

		switch(m_SSFlags.GetCurSel())
		{
		case 0:
			m_PEFile.PEHdr.SubSystem = 0x0000;
			break;
		case 1:
			m_PEFile.PEHdr.SubSystem = 0x0001;
			break;
		case 2:
			m_PEFile.PEHdr.SubSystem = 0x0002;
			break;
		case 3:
			m_PEFile.PEHdr.SubSystem = 0x0003;
			break;
		case 4:
			m_PEFile.PEHdr.SubSystem = 0x0005;
			break;
		case 5:
			m_PEFile.PEHdr.SubSystem = 0x0007;
			break;
		case 6:
			m_PEFile.PEHdr.SubSystem = 0x0166;
			break;
		}

		switch(m_CPUType.GetCurSel())
		{
		case 0:
			m_PEFile.PEHdr.CPUType = 0x0000;
			break;
		case 1:
			m_PEFile.PEHdr.CPUType = 0x014C;
			break;
		case 2:
			m_PEFile.PEHdr.CPUType = 0x0162;
			break;
		case 3:
			m_PEFile.PEHdr.CPUType = 0x0166;
			break;
		case 4:
			m_PEFile.PEHdr.CPUType = 0x0168;
			break;
		case 5:
			m_PEFile.PEHdr.CPUType = 0x0169;
			break;
		case 6:
			m_PEFile.PEHdr.CPUType = 0x0184;
			break;
		case 7:
			m_PEFile.PEHdr.CPUType = 0x01F0;
			break;
		case 8:
			m_PEFile.PEHdr.CPUType = 0x01A2;
			break;
		case 9:
			m_PEFile.PEHdr.CPUType = 0x01A4;
			break;
		case 10:
			m_PEFile.PEHdr.CPUType = 0x01A6;
			break;
		case 11:
			m_PEFile.PEHdr.CPUType = 0x01C0;
			break;
		case 12:
			m_PEFile.PEHdr.CPUType = 0x01C2;
			break;
		case 13:
			m_PEFile.PEHdr.CPUType = 0x0200;
			break;
		case 14:
			m_PEFile.PEHdr.CPUType = 0x0266;
			break;
		case 15:
			m_PEFile.PEHdr.CPUType = 0x0366;
			break;
		case 16:
			m_PEFile.PEHdr.CPUType = 0x0466;
			break;
		case 17:
			m_PEFile.PEHdr.CPUType = 0x0284;
			break;
		}

		GetDlgItemText(IDC_ST_RES_SZ,    tmp);
		m_PEFile.PEHdr.StackReserveSize = ConvFromHex(tmp);
        GetDlgItemText(IDC_ST_COM_SZ,    tmp);
		m_PEFile.PEHdr.StackCommitSize = ConvFromHex(tmp);
	    GetDlgItemText(IDC_HP_RES_SZ,    tmp);
		m_PEFile.PEHdr.HeapReserveSize = ConvFromHex(tmp);
	    GetDlgItemText(IDC_HP_COM_SZ,    tmp);
		m_PEFile.PEHdr.HeapCommitSize  = ConvFromHex(tmp);
	    GetDlgItemText(IDC_POINTER_COFF, tmp);
		m_PEFile.PEHdr.PointerToCOFF   = ConvFromHex(tmp);
	    GetDlgItemText(IDC_COFF_SIZE,    tmp);
		m_PEFile.PEHdr.COFFTableSize   = ConvFromHex(tmp);
	    GetDlgItemText(IDC_CHECKSUM,     tmp);
		m_PEFile.PEHdr.FileChecksum    = ConvFromHex(tmp);
	    GetDlgItemText(IDC_STAMP,        tmp);
		m_PEFile.PEHdr.TimeDateStamp   = ConvFromHex(tmp);

		m_PEFile.WritePEHeader();
		CDialog::OnOK();
	}
	else CDialog::OnOK();
}

void CAdvancedEdDlg::OnCancel() 
{
	CDialog::OnCancel();
}
