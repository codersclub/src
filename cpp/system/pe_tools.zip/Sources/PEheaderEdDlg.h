#if !defined(AFX_PEHEADEREDDLG_H__06DD28C0_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
#define AFX_PEHEADEREDDLG_H__06DD28C0_730B_11D6_8219_F3AE8149ED7F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PEheaderEdDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPEheaderEdDlg dialog

class CPEheaderEdDlg : public CDialog
{
// Construction
public:
	CPEheaderEdDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPEheaderEdDlg)
	enum { IDD = IDD_PE_HEADER_EDITOR };
	CButton	m_OK;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPEheaderEdDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPEheaderEdDlg)
	afx_msg void OnOk();
	afx_msg void OnCancel();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PEHEADEREDDLG_H__06DD28C0_730B_11D6_8219_F3AE8149ED7F__INCLUDED_)
