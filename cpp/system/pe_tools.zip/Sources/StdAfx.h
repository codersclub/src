// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__4E56EA28_7274_11D6_8219_E1329186B97F__INCLUDED_)
#define AFX_STDAFX_H__4E56EA28_7274_11D6_8219_E1329186B97F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include "PEFile.h"

//#define ERR_RW     "Error while accesing the file (READ/WRITE)."
#define ERR_PE     "No PE signature found.\nThis is file is not valid Win32 module."

extern BOOL IsOpen;
extern BOOL IsReadOnly;
extern CString m_OpenedPEFile;
extern CPEFile m_PEFile;


extern DWORD m_iNdex;
extern CHAR  m_SectionName[8];
extern CHAR  m_VSize[9];
extern CHAR  m_VOffset[9];
extern CHAR  m_RSize[9];
extern CHAR  m_ROffset[9];
extern CHAR  m_Charact[9];

CString ConvToHEXStr(DWORD N);
DWORD   ConvFromHex(CString N);
//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__4E56EA28_7274_11D6_8219_E1329186B97F__INCLUDED_)
