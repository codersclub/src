// stdafx.cpp : source file that includes just the standard includes
//	PE Tools.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"

BOOL IsOpen = FALSE;
BOOL IsReadOnly = FALSE;
CString m_OpenedPEFile;
CPEFile m_PEFile;

DWORD m_iNdex;
CHAR  m_SectionName[8];
CHAR  m_VSize[9];
CHAR  m_VOffset[9];
CHAR  m_RSize[9];
CHAR  m_ROffset[9];
CHAR  m_Charact[9];

CString ConvToHEXStr(DWORD N)
{
	CString NUM;
	NUM.Format("%0.8X", N);
	return NUM;
}

DWORD ConvFromHex(CString N)
{
	DWORD i=0;
	sscanf(N, "%X", &i);
	return i;
}