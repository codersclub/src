// PEFile.cpp: implementation of the CPEFile class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "PEFile.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

DWORD MZ_SIGN = 0x00005A4D;
DWORD PE_SIGN = 0x00004550;
//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CPEFile::CPEFile()
{
	memset(&DOSHdr,      0, sizeof(DOSHeader));
	memset(&PEHdr,       0, sizeof(PEHdr));
	memset(&ObjEntry,    0, sizeof(ObjEntry));
}

CPEFile::~CPEFile()
{

}

BOOL CPEFile::Open(LPCTSTR szPEFile, BOOL ReadOnly)
{
	if(ReadOnly == TRUE) return m_hPEFile.Open(szPEFile, CFile::modeRead | CFile::typeBinary);
	return m_hPEFile.Open(szPEFile, CFile::modeReadWrite | CFile::typeBinary);
}

VOID CPEFile::Close()
{
	m_hPEFile.Close();
}

UINT CPEFile::ReadDOSHeader(VOID)
{
	m_hPEFile.SeekToBegin();
	return m_hPEFile.Read(&DOSHdr, sizeof(DOSHeader));
}

VOID CPEFile::WriteDOSHeader(VOID)
{
	m_hPEFile.SeekToBegin();
	m_hPEFile.Write(&DOSHdr, sizeof(DOSHeader));
}

UINT CPEFile::ReadPEHeader(VOID)
{
	SeekToPEHeader();
	return m_hPEFile.Read(&PEHdr, sizeof(PEHeader));
}

UINT CPEFile::ReadObjectEntry(VOID)
{
	return m_hPEFile.Read(&ObjEntry, sizeof(ObjectEntry));
}

LONG CPEFile::SeekToPEHeader(VOID)
{
	ReadDOSHeader();
	return m_hPEFile.Seek(DOSHdr.OffsetToPEHeader, CFile::begin);
}

LONG CPEFile::SeekToObjectEntry(VOID)
{
	return m_hPEFile.Seek(SeekToPEHeader() + sizeof(PEHdr), CFile::begin);
}

VOID CPEFile::WritePEHeader()
{
	SeekToPEHeader();
	m_hPEFile.Write(&PEHdr, sizeof(PEHeader));
}

VOID CPEFile::WriteObjectEntry(VOID)
{
	m_hPEFile.Write(&ObjEntry, sizeof(ObjectEntry));
}

BOOL CPEFile::IsPEFile(VOID)
{
	DWORD tmp;
	m_hPEFile.SeekToBegin();
	m_hPEFile.Read(&DOSHdr, sizeof(DOSHeader));
	if(DOSHdr.Signature != MZ_SIGN) return FALSE;
	dwOffsetToPEhdr = DOSHdr.OffsetToPEHeader;
	m_hPEFile.Seek(dwOffsetToPEhdr, CFile::begin);
	m_hPEFile.Read(&tmp, sizeof(DWORD));
	if(tmp != PE_SIGN) return FALSE;
	return TRUE;
}

BOOL CPEFile::CheckAccess(VOID)
{
	if (GetFileAttributes(m_hPEFile.GetFilePath()) == FILE_ATTRIBUTE_READONLY)
	{
		return FALSE;
	}else return TRUE;
}
