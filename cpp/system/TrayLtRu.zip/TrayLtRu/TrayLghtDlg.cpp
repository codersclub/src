// TrayLghtDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TrayLght.h"
#include "TrayLghtDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// No message handlers
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtDlg dialog

CTrayLghtDlg::CTrayLghtDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTrayLghtDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTrayLghtDlg)
	m_Light = -1;
	m_Color = -1;
	//}}AFX_DATA_INIT
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTrayLghtDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTrayLghtDlg)
	DDX_Radio(pDX, IDC_RADIO1, m_Light);
	DDX_CBIndex(pDX, IDC_COLOR, m_Color);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTrayLghtDlg, CDialog)
	//{{AFX_MSG_MAP(CTrayLghtDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, OnOk)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_SETTIMER, OnSettimer)
	ON_BN_CLICKED(IDC_KILLTIMER, OnKilltimer)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtDlg message handlers

BOOL CTrayLghtDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	//// �������� ���� ������ � ����������
	ASSERT( m_hWnd );
	m_Lights.StartTrayLights( m_hWnd, 124 );
	m_Lights2.StartTrayLights( m_hWnd, 125 );

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CTrayLghtDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CTrayLghtDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

HCURSOR CTrayLghtDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

//// ������ ������ "Set Color"
void CTrayLghtDlg::OnOk() 
{
	UpdateData();

	m_Lights.FireLightOn( m_Light+1, m_Color );
	m_Lights2.FireLightOn( m_Light+1, m_Color );
}

//// ���������� �������
void CTrayLghtDlg::OnTimer(UINT nIDEvent) 
{
	m_Lights.FireLightOn( clock()%4+1, clock()%8+9 );
	m_Lights2.FireLightOn( clock()%4+1, clock()%17 );
	
	CDialog::OnTimer(nIDEvent);
}

void CTrayLghtDlg::OnSettimer() 
{
	m_nTimerID = SetTimer( clock(), 250, NULL );
}

void CTrayLghtDlg::OnKilltimer() 
{
	KillTimer( m_nTimerID );
}
