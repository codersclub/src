// TrayLght.h : main header file for the TRAYLGHT application
//

#if !defined(AFX_TRAYLGHT_H__A99A0AD0_1EAF_4C85_AE4E_37EEE73F85F9__INCLUDED_)
#define AFX_TRAYLGHT_H__A99A0AD0_1EAF_4C85_AE4E_37EEE73F85F9__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtApp:
// See TrayLght.cpp for the implementation of this class
//

class CTrayLghtApp : public CWinApp
{
public:
	CTrayLghtApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrayLghtApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTrayLghtApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAYLGHT_H__A99A0AD0_1EAF_4C85_AE4E_37EEE73F85F9__INCLUDED_)
