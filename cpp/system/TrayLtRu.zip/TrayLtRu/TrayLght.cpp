// TrayLght.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "TrayLght.h"
#include "TrayLghtDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtApp

BEGIN_MESSAGE_MAP(CTrayLghtApp, CWinApp)
	//{{AFX_MSG_MAP(CTrayLghtApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtApp construction

CTrayLghtApp::CTrayLghtApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CTrayLghtApp object

CTrayLghtApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CTrayLghtApp initialization

BOOL CTrayLghtApp::InitInstance()
{
	// Standard initialization

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	CTrayLghtDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
