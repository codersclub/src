// TrayLights.h: interface for the CTrayLights class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_TRAYLIGHTS_H__A83766E2_78D7_47E4_855D_52D4F427D4B6__INCLUDED_)
#define AFX_TRAYLIGHTS_H__A83766E2_78D7_47E4_855D_52D4F427D4B6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//
//	=========================================================================
//
//	CTrayLights
//
class CTrayLights  
{
public:
	bool StartTrayLights( HWND _hOwnerWnd, int _nIconID );
	bool EndTrayLights();
	CTrayLights();
	virtual ~CTrayLights();
	
	bool FireLightOn( int _nLight, int _nColor );
	bool FireLightOff( int _nLight );
	bool SetOffColor( int _nNewColor );
	
private:	
	struct	// �������� ��� ������ ������ in m_bIconData
	{
		WORD m_b0x0XOffsets[4];
		WORD m_b0xX0Offsets[4];
		WORD m_b0xXXOffsets[14];
		WORD m_bBorderLineOffsets[2];
		WORD m_bBodyLineOffsets[4];
	} m_data[4];
	BYTE m_bOffColor;
	HWND m_hOwnerWnd;	
	HICON m_hIcon;
	BYTE m_bIconData[297];	// �� ���� ������ ��������� ������
	NOTIFYICONDATA m_NID;
};

#endif // !defined(AFX_TRAYLIGHTS_H__A83766E2_78D7_47E4_855D_52D4F427D4B6__INCLUDED_)
