// TrayLights.cpp: implementation of the CTrayLights class.
//
//////////////////////////////////////////////////////////////////////
//
#include "stdafx.h"
#include "TrayLights.h"
//
#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif
//
//	=========================================================================
//
//	�����������
//
CTrayLights::CTrayLights()
{
	m_hOwnerWnd = NULL;		// ��������� ����� ������
	m_hIcon = NULL;
	m_bOffColor = 0x10;		// �� ��������� ���� ����������� ����� - ����������

	// ������� ���������� ������ ������
	BYTE bIconData [] = 
	{
		0x28, 0x00, 0x00, 0x00,  0x10, 0x00, 0x00, 0x00,	0x20, 0x00, 0x00, 0x00,  0x01, 0x00, 0x04, 0x00,
		0x00, 0x00, 0x00, 0x00,  0xC0, 0x00, 0x00, 0x00,	0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 
		0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00,	0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x80, 0x00, 
		0x00, 0x80, 0x00, 0x00,  0x00, 0x80, 0x80, 0x00,	0x80, 0x00, 0x00, 0x00,  0x80, 0x00, 0x80, 0x00, 
		0x80, 0x80, 0x00, 0x00,  0xC0, 0xC0, 0xC0, 0x00,	0x80, 0x80, 0x80, 0x00,  0x00, 0x00, 0xFF, 0x00, 
		0x00, 0xFF, 0x00, 0x00,  0x00, 0xFF, 0xFF, 0x00,	0xFF, 0x00, 0x00, 0x00,  0xFF, 0x00, 0xFF, 0x00, 
		0xFF, 0xFF, 0x00, 0x00,  0xFF, 0xFF, 0xFF, 0x00,	0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00, 
		0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00,	
															0x00, 0xAA, 0xAA, 0x00,  0x0A, 0xAA, 0xA0, 0x00, 
		0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,	0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,
		0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,	0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,
		0x00, 0xAA, 0xAA, 0x00,  0x0A, 0xAA, 0xA0, 0x00,	0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00,
		0x00, 0xAA, 0xAA, 0x00,  0x0A, 0xAA, 0xA0, 0x00,	0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,
		0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,	0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,
		0x0A, 0xAA, 0xAA, 0xA0,  0xAA, 0xAA, 0xAA, 0x00,	0x00, 0xAA, 0xAA, 0x00,  0x0A, 0xAA, 0xA0, 0x00,

		0x00, 0x00, 0x00, 0x00,  0x00, 0x00, 0x00, 0x00,	0xFF, 0xFF, 0x00, 0x00,  0xC3, 0x87, 0x00, 0x00,
		0x81, 0x03, 0x00, 0x00,  0x00, 0x01, 0x00, 0x00,	0x00, 0x01, 0x00, 0x00,  0x00, 0x01, 0x00, 0x00, 
		0x00, 0x01, 0x00, 0x00,  0x81, 0x03, 0x00, 0x00,	0xC3, 0x87, 0x00, 0x00,  0x81, 0x03, 0x00, 0x00, 
		0x00, 0x01, 0x00, 0x00,  0x00, 0x01, 0x00, 0x00,	0x00, 0x01, 0x00, 0x00,  0x00, 0x01, 0x00, 0x00, 
		0x81, 0x03, 0x00, 0x00,  0xC3, 0x87, 0x00, 0x00,	0x00
	};
	memcpy( m_bIconData, bIconData, sizeof(m_bIconData) );

	// ���������� �������� ������������
	m_data[0].m_bBorderLineOffsets[0] = 0x010C;
	m_data[0].m_bBorderLineOffsets[1] = 0x0120;
	m_data[0].m_bBodyLineOffsets[0] = 0x0110;
	m_data[0].m_bBodyLineOffsets[1] = 0x0114;
	m_data[0].m_bBodyLineOffsets[2] = 0x0118;
	m_data[0].m_bBodyLineOffsets[3] = 0x011C;

	m_data[1].m_bBorderLineOffsets[0] = 0x010D;
	m_data[1].m_bBorderLineOffsets[1] = 0x0121;
	m_data[1].m_bBodyLineOffsets[0] = 0x0111;
	m_data[1].m_bBodyLineOffsets[1] = 0x0115;
	m_data[1].m_bBodyLineOffsets[2] = 0x0119;
	m_data[1].m_bBodyLineOffsets[3] = 0x011D;

	m_data[2].m_bBorderLineOffsets[0] = 0x00F0;
	m_data[2].m_bBorderLineOffsets[1] = 0x0104;
	m_data[2].m_bBodyLineOffsets[0] = 0x00F4;
	m_data[2].m_bBodyLineOffsets[1] = 0x00F8;
	m_data[2].m_bBodyLineOffsets[2] = 0x00FC;
	m_data[2].m_bBodyLineOffsets[3] = 0x0100;

	m_data[3].m_bBorderLineOffsets[0] = 0x00F1;
	m_data[3].m_bBorderLineOffsets[1] = 0x0105;
	m_data[3].m_bBodyLineOffsets[0] = 0x00F5;
	m_data[3].m_bBodyLineOffsets[1] = 0x00F9;
	m_data[3].m_bBodyLineOffsets[2] = 0x00FD;
	m_data[3].m_bBodyLineOffsets[3] = 0x0101;

	
	// ���������� �������� ������
	m_data[0].m_b0x0XOffsets[0] = 0x00B8;
	m_data[0].m_b0x0XOffsets[1] = 0x00C0;
	m_data[0].m_b0x0XOffsets[2] = 0x00C8;
	m_data[0].m_b0x0XOffsets[3] = 0x00D0;
	m_data[0].m_b0xX0Offsets[0] = 0x00BB;
	m_data[0].m_b0xX0Offsets[1] = 0x00C3;
	m_data[0].m_b0xX0Offsets[2] = 0x00CB;
	m_data[0].m_b0xX0Offsets[3] = 0x00D3;
	m_data[0].m_b0xXXOffsets[0] = 0x00B1;
	m_data[0].m_b0xXXOffsets[1] = 0x00B2;
	m_data[0].m_b0xXXOffsets[2] = 0x00B9;
	m_data[0].m_b0xXXOffsets[3] = 0x00BA;
	m_data[0].m_b0xXXOffsets[4] = 0x00C1;
	m_data[0].m_b0xXXOffsets[5] = 0x00C2;
	m_data[0].m_b0xXXOffsets[6] = 0x00C9;
	m_data[0].m_b0xXXOffsets[7] = 0x00CA;
	m_data[0].m_b0xXXOffsets[8] = 0x00D1;
	m_data[0].m_b0xXXOffsets[9] = 0x00D2;
	m_data[0].m_b0xXXOffsets[10] = 0x00D9;
	m_data[0].m_b0xXXOffsets[11] = 0x00DA;
	m_data[0].m_b0xXXOffsets[12] = 0x0129;
	m_data[0].m_b0xXXOffsets[13] = 0x0129;

	m_data[1].m_b0x0XOffsets[0] = 0x00B4;
	m_data[1].m_b0x0XOffsets[1] = 0x00DC;
	m_data[1].m_b0x0XOffsets[2] = 0x0129;
	m_data[1].m_b0x0XOffsets[3] = 0x0129;
	m_data[1].m_b0xX0Offsets[0] = 0x00B6;
	m_data[1].m_b0xX0Offsets[1] = 0x00DE;
	m_data[1].m_b0xX0Offsets[2] = 0x0129;
	m_data[1].m_b0xX0Offsets[3] = 0x0129;
	m_data[1].m_b0xXXOffsets[0] = 0x00B5;
	m_data[1].m_b0xXXOffsets[1] = 0x00BC;
	m_data[1].m_b0xXXOffsets[2] = 0x00BD;
	m_data[1].m_b0xXXOffsets[3] = 0x00BE;
	m_data[1].m_b0xXXOffsets[4] = 0x00C4;
	m_data[1].m_b0xXXOffsets[5] = 0x00C5;
	m_data[1].m_b0xXXOffsets[6] = 0x00C6;
	m_data[1].m_b0xXXOffsets[7] = 0x00CC;
	m_data[1].m_b0xXXOffsets[8] = 0x00CD;
	m_data[1].m_b0xXXOffsets[9] = 0x00CE;
	m_data[1].m_b0xXXOffsets[10] = 0x00D4;
	m_data[1].m_b0xXXOffsets[11] = 0x00D5;
	m_data[1].m_b0xXXOffsets[12] = 0x00D6;
	m_data[1].m_b0xXXOffsets[13] = 0x00DD;

	m_data[2].m_b0x0XOffsets[0] = 0x0080;
	m_data[2].m_b0x0XOffsets[1] = 0x0088;
	m_data[2].m_b0x0XOffsets[2] = 0x0090;
	m_data[2].m_b0x0XOffsets[3] = 0x0098;
	m_data[2].m_b0xX0Offsets[0] = 0x0083;
	m_data[2].m_b0xX0Offsets[1] = 0x008B;
	m_data[2].m_b0xX0Offsets[2] = 0x0093;
	m_data[2].m_b0xX0Offsets[3] = 0x009B;
	m_data[2].m_b0xXXOffsets[0] = 0x0079;
	m_data[2].m_b0xXXOffsets[1] = 0x007A;
	m_data[2].m_b0xXXOffsets[2] = 0x0081;
	m_data[2].m_b0xXXOffsets[3] = 0x0082;
	m_data[2].m_b0xXXOffsets[4] = 0x0089;
	m_data[2].m_b0xXXOffsets[5] = 0x008A;
	m_data[2].m_b0xXXOffsets[6] = 0x0091;
	m_data[2].m_b0xXXOffsets[7] = 0x0092;
	m_data[2].m_b0xXXOffsets[8] = 0x0099;
	m_data[2].m_b0xXXOffsets[9] = 0x009A;
	m_data[2].m_b0xXXOffsets[10] = 0x00A1;
	m_data[2].m_b0xXXOffsets[11] = 0x00A2;
	m_data[2].m_b0xXXOffsets[12] = 0x0129;
	m_data[2].m_b0xXXOffsets[13] = 0x0129;

	m_data[3].m_b0x0XOffsets[0] = 0x007C;
	m_data[3].m_b0x0XOffsets[1] = 0x00A4;
	m_data[3].m_b0x0XOffsets[2] = 0x0129;
	m_data[3].m_b0x0XOffsets[3] = 0x0129;
	m_data[3].m_b0xX0Offsets[0] = 0x007E;
	m_data[3].m_b0xX0Offsets[1] = 0x00A6;
	m_data[3].m_b0xX0Offsets[2] = 0x0129;
	m_data[3].m_b0xX0Offsets[3] = 0x0129;
	m_data[3].m_b0xXXOffsets[0] = 0x007D;
	m_data[3].m_b0xXXOffsets[1] = 0x0084;
	m_data[3].m_b0xXXOffsets[2] = 0x0085;
	m_data[3].m_b0xXXOffsets[3] = 0x0086;
	m_data[3].m_b0xXXOffsets[4] = 0x008C;
	m_data[3].m_b0xXXOffsets[5] = 0x008D;
	m_data[3].m_b0xXXOffsets[6] = 0x008E;
	m_data[3].m_b0xXXOffsets[7] = 0x0094;
	m_data[3].m_b0xXXOffsets[8] = 0x0095;
	m_data[3].m_b0xXXOffsets[9] = 0x0096;
	m_data[3].m_b0xXXOffsets[10] = 0x009C;
	m_data[3].m_b0xXXOffsets[11] = 0x009D;
	m_data[3].m_b0xXXOffsets[12] = 0x009E;
	m_data[3].m_b0xXXOffsets[13] = 0x00A5;
	
	// �� ������ �������� ��� �������� ���������
	for (int i=1; i<5; i++)
		FireLightOff( i );
}
//	=========================================================================
//
//	���������� - �������� ������ �� ����, ���� ��� ��� ���
//
CTrayLights::~CTrayLights()
{
	EndTrayLights();
}
//	=========================================================================
//
//	SetOffColor
//
bool CTrayLights::SetOffColor(int _nNewColor)
{
	m_bOffColor = (int) _nNewColor & 0x1F;

	return true;
}
//	=========================================================================
//
//	StartTrayLights
//
bool CTrayLights::StartTrayLights(HWND _hOwnerWnd, int _nIconID)
{
	if ( !_hOwnerWnd )	// �������� HWND
		return false;
	m_hOwnerWnd = _hOwnerWnd;

	_ASSERT( m_hIcon == NULL );	
	if ( m_hIcon )
		return false;

	// �������� ������
	m_hIcon = CreateIconFromResourceEx( m_bIconData, 296, TRUE,
		0x00030000, 16, 16, LR_DEFAULTCOLOR );

	_ASSERT( m_hIcon );
	if ( !m_hIcon )
		return false;

	m_NID.cbSize = sizeof( m_NID );
	m_NID.hWnd = m_hOwnerWnd;	//	��� ������ �� �������� �� ������ EndTrayLights
	m_NID.uID = _nIconID;		//
	m_NID.uFlags = NIF_ICON;
	m_NID.hIcon = m_hIcon;	

	// �������� ������ � ����
	BOOL bIcon = Shell_NotifyIcon( NIM_ADD, &m_NID );
	_ASSERT( bIcon );
	if ( !bIcon )
		return false;
	
	return true;
}
//	=========================================================================
//
//	EndTrayLights - �������� ������ � ���������� �� ����
//
bool CTrayLights::EndTrayLights()
{
	if ( m_hIcon )
	{
		Shell_NotifyIcon( NIM_DELETE, &m_NID );
		DestroyIcon( m_hIcon );
		m_hIcon = NULL;
	}

	return true;
}
//	=========================================================================
//
//	FireLightOff
//
bool CTrayLights::FireLightOff(int _nLight)
{
	FireLightOn( _nLight, m_bOffColor );
	return true;
}
//	=========================================================================
//
//	FireLightOn
//
bool CTrayLights::FireLightOn(int _nLight, int _nColor)
{
	// �������� ����������
	ASSERT( 0 < _nLight && _nLight < 5 );
	ASSERT( 0 <= _nColor && _nColor < 18 );
	if ( !( 0 < _nLight && _nLight < 5 ) || !( 0 <= _nColor && _nColor < 18 ) )
		return false;

	// ���������� ����� ������ �����
	BYTE b0x0XColor = _nColor & 0x0F;
	BYTE b0xX0Color = b0x0XColor << 4;
	BYTE b0xXXColor = b0x0XColor | b0xX0Color;

	// ���������� ������ �����
	for ( int i=0; i<4; i++ )
		m_bIconData[ m_data[_nLight-1].m_b0x0XOffsets[i] ] = b0x0XColor;
	for ( i=0; i<4; i++ )
		m_bIconData[ m_data[_nLight-1].m_b0xX0Offsets[i] ] = b0xX0Color;
	for ( i=0; i<14; i++ )
		m_bIconData[ m_data[_nLight-1].m_b0xXXOffsets[i] ] = b0xXXColor;
	m_bIconData[296] = 0;

	// ���������� ������ ������������
	if ( _nColor <= 0x0F )
	{
		if ( _nLight & 0x01 )
		{
			for ( i=0; i<2; i++)
				m_bIconData[ m_data[_nLight-1].m_bBorderLineOffsets[i] ] = 0x81;
			for ( i=0; i<4; i++)
				m_bIconData[ m_data[_nLight-1].m_bBodyLineOffsets[i] ] = 0x00;
		}
		else
		{
			for ( i=0; i<2; i++)
				m_bIconData[ m_data[_nLight-1].m_bBorderLineOffsets[i] ] = 0x03;
			for ( i=0; i<4; i++)
				m_bIconData[ m_data[_nLight-1].m_bBodyLineOffsets[i] ] = 0x01;
		}
	}
	else
	{
		if ( _nLight & 0x01 )
		{
			for ( i=0; i<2; i++)
				m_bIconData[ m_data[_nLight-1].m_bBorderLineOffsets[i] ] = 0xBD;
			for ( i=0; i<4; i++)
				m_bIconData[ m_data[_nLight-1].m_bBodyLineOffsets[i] ] = 0x7E;
		}
		else
		{
			for ( i=0; i<2; i++)
				m_bIconData[ m_data[_nLight-1].m_bBorderLineOffsets[i] ] = 0x7B;
			for ( i=0; i<4; i++)
				m_bIconData[ m_data[_nLight-1].m_bBodyLineOffsets[i] ] = 0xFD;
		}
	}

	if ( m_hOwnerWnd )	// ���� ������ ���, ���� ��� ������������
	{
		// ��������� ���������� ������ ������
		HICON hOldIcon = m_hIcon;

		// ������� ����� ������
		m_hIcon = CreateIconFromResourceEx( m_bIconData, 296, TRUE,
			0x00030000, 16, 16, LR_DEFAULTCOLOR );

		_ASSERT( m_hIcon );
		if ( !m_hIcon )
			return false;

		// �������� ������ � ����
		m_NID.hIcon = m_hIcon;
		BOOL bIcon = Shell_NotifyIcon( NIM_MODIFY, &m_NID );

		// ����������� ������ ������
		DestroyIcon( hOldIcon );
	}

	return true;
}


