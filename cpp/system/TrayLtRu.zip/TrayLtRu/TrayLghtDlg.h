// TrayLghtDlg.h : header file
//

#if !defined(AFX_TRAYLGHTDLG_H__450B5DBA_ADB6_432A_ABD3_D207DABC46B7__INCLUDED_)
#define AFX_TRAYLGHTDLG_H__450B5DBA_ADB6_432A_ABD3_D207DABC46B7__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
#include "TrayLights.h"
/////////////////////////////////////////////////////////////////////////////
// CTrayLghtDlg dialog

class CTrayLghtDlg : public CDialog
{
// Construction
public:
	CTrayLghtDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTrayLghtDlg)
	enum { IDD = IDD_TRAYLGHT_DIALOG };
	int		m_Light;
	int		m_Color;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTrayLghtDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	CTrayLights m_Lights;	// ������ � ����������
	CTrayLights m_Lights2;

	// Generated message map functions
	//{{AFX_MSG(CTrayLghtDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnOk();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnSettimer();
	afx_msg void OnKilltimer();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	int m_nTimerID;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRAYLGHTDLG_H__450B5DBA_ADB6_432A_ABD3_D207DABC46B7__INCLUDED_)
