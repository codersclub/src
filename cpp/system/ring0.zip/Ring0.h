#ifndef __RING0_H__
#define __RING0_H__


typedef DWORD (__fastcall *PRING0FUNC)(DWORD dwParams);


BOOL  CallRing0(PRING0FUNC pRing0Func, DWORD dwParams, LPDWORD lpdwRetValue);


#endif // __RING0_H__
