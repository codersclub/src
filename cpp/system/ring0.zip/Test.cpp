#include <windows.h>
#include <stdio.h>
#include "ring0.h"


DWORD __fastcall CheckRing0(void);


int main(int argc, char* argv[])
{
DWORD dwPL;

  dwPL = CheckRing0();
  printf("Ring - %d\n", dwPL);

  CallRing0((PRING0FUNC)CheckRing0, 0, &dwPL);
  printf("Ring - %d\n", dwPL);

  return 0;
}


DWORD __fastcall CheckRing()
{
  __asm
  {
    xor   eax,eax
    mov   ax,cs
    and   al,3
  } 
}
