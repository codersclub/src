// GlColor.h : main header file for the GLCOLOR application
//

#if !defined(AFX_GLCOLOR_H__0896DB84_A381_11D4_9DF3_CF769DBD135C__INCLUDED_)
#define AFX_GLCOLOR_H__0896DB84_A381_11D4_9DF3_CF769DBD135C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CColorApp:
// See GlColor.cpp for the implementation of this class
//

class CColorApp : public CWinApp
{
public:
	CColorApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CColorApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CColorApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GLCOLOR_H__0896DB84_A381_11D4_9DF3_CF769DBD135C__INCLUDED_)
