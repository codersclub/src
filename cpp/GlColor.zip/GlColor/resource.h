//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by GlColor.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_GLCOLOR_DIALOG              102
#define CG_IDR_POPUP_COLOR_DLG          103
#define IDR_MAINFRAME                   128
#define IDR_BABOON                      130
#define IDD_DIALOG_IMAGE                131
#define ID_EDIT_BACKCOLOR               32771
#define ID_EDIT_LOADIMAGE               32772
#define ID_POPUP_VIEWIMAGE              32773

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32774
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
