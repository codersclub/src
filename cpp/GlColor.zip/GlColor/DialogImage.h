#if !defined(AFX_DIALOGIMAGE_H__772673C0_A3AF_11D4_9DF3_CF769DBD135C__INCLUDED_)
#define AFX_DIALOGIMAGE_H__772673C0_A3AF_11D4_9DF3_CF769DBD135C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// DialogImage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDialogImage dialog

class CTexture;

class CDialogImage : public CDialog
{
// Construction
public:
	CDialogImage(CWnd* pParent = NULL,CTexture *pImage=NULL);

	CTexture *m_pImage;

// Dialog Data
	//{{AFX_DATA(CDialogImage)
	enum { IDD = IDD_DIALOG_IMAGE };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDialogImage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDialogImage)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DIALOGIMAGE_H__772673C0_A3AF_11D4_9DF3_CF769DBD135C__INCLUDED_)
