#include <afxwin.h>
#include <math.h>
#include <GL/gl.h>
#include <GL/glu.h>
#include "resource.h"
#include "prb5.h"
#include "solv.h"

#define MSG_DOSTOP 2000
#define MSG_DONEW 2001
#define MSG_DOSTEP 2002
#define MSG_DOPLAY 2003

CPrb5 App;
HGLRC rc;
CClientDC	*m_pDC;
float temp=0.1f, angle;

int WindX, WindY;

CMainDlg MainDlg;
BOOL DlgActive = FALSE;

// Board flags
BOOL BeginButtons = FALSE; 
BOOL DMove = FALSE;
BOOL NoStep = FALSE;
float MX, MY, offsetx, offsety, EX, EY;
int DownX, DownY;
float DownColor;

// Board layout
char brd[7][7];

// Solve elements
SSolv *first_e, *cur_e;

void InitBoard()
{
	for (int i=0; i<7; i++)
		for (int j=0; j<7; j++)
			brd[i][j] = 1;		

	brd[0][0] = 2; brd[0][1] = 2;
	brd[1][0] = 2; brd[1][1] = 2;
	brd[5][0] = 2; brd[5][1] = 2;
	brd[6][0] = 2; brd[6][1] = 2;
	brd[0][5] = 2; brd[0][6] = 2;
	brd[1][5] = 2; brd[1][6] = 2;
	brd[5][5] = 2; brd[5][6] = 2;
	brd[6][5] = 2; brd[6][6] = 2;
	brd[3][3] = 0;	
	first_e = NULL;
}
void CMainWin::DoMove(int StX, int StY, int EndX, int EndY)
{
	if (!((StX >= 0) && (StX < 7))) return;
	if (!((StY >= 0) && (StY < 7))) return;
	if (!((EndX >= 0) && (EndX < 7))) return;
	if (!((EndY >= 0) && (EndY < 7))) return;

	if (brd[StY][StX] != 1) return;
	if (brd[EndY][EndX] != 0) return;
	
	brd[StY][StX] = 0;
	MX = (float)StX;
	MY = (float)StY;
	offsetx = 0;
	offsety = 0;
	if (StX > EndX) offsetx = -0.2f;
	if (StX < EndX) offsetx = 0.2f;
	if (StY > EndY) offsety = -0.2f;
	if (StY < EndY) offsety = 0.2f;
	EX = (float)EndX;
	EY = (float)EndY;
	DownX = StX;
	DownY = StY;
	if (StX > EndX) DownX = StX-1; 
	if (StX < EndX) DownX = StX+1; 
	if (StY > EndY) DownY = StY-1; 
	if (StY < EndY) DownY = StY+1; 
	DownColor = 0.7f;
	DMove = TRUE;
	SetTimer(2, 41, NULL);
}

LRESULT CMainWin::DoStop(WPARAM, LPARAM)
{
	KillTimer(3);
	return 0;
}
void _DoNew()
{
	SSolv *temp;
	if (first_e)
	{
		while (first_e)
		{
			temp = first_e->next;
			delete first_e;
			first_e = temp;
		}
	}
	first_e = GetSolve();
	cur_e = first_e;
}

LRESULT CMainWin::DoNew(WPARAM, LPARAM)
{
	NoStep = TRUE;
	KillTimer(1);
	KillTimer(3);
	_DoNew();
	SetTimer(4, 41, NULL);
	return 0;
}

LRESULT CMainWin::DoStep(WPARAM, LPARAM)
{
	if (NoStep) return 0;
	if (!cur_e) return 0;
	KillTimer(3);
	if (DMove) return 0;
	DoMove(cur_e->StX, cur_e->StY, cur_e->EndX, cur_e->EndY);
	cur_e = cur_e->next;
	return 0;
}

LRESULT CMainWin::DoPlay(WPARAM, LPARAM)
{
	if (NoStep) return 0;
	SetTimer(3, 800, NULL);
	return 0;
}

BOOL CPrb5::InitInstance() {

	m_pMainWnd = new CMainWin;
	m_pMainWnd->ShowWindow(m_nCmdShow);
	m_pMainWnd->UpdateWindow();
	return TRUE;
}

CMainWin::CMainWin()
{
	int i;
	Create(NULL, "Problem #5");
	
	PIXELFORMATDESCRIPTOR   pfd;

	memset(&pfd, 0, sizeof(PIXELFORMATDESCRIPTOR));

	pfd.nSize =             sizeof(PIXELFORMATDESCRIPTOR);
    pfd.nVersion =          1;
    pfd.dwFlags =           PFD_DRAW_TO_WINDOW | PFD_SUPPORT_OPENGL |
                            PFD_DOUBLEBUFFER;
    pfd.iPixelType =        PFD_TYPE_RGBA;
    pfd.cColorBits =        24;
    pfd.cRedBits =          0;
    pfd.cRedShift =         0;
    pfd.cGreenBits =        0;
    pfd.cGreenShift =       0; 
    pfd.cBlueBits =         0;
    pfd.cBlueShift =        0;
    pfd.cAlphaBits =        0;
    pfd.cAlphaShift =       0;
    pfd.cAccumBits =        0;
    pfd.cAccumRedBits =     0;
    pfd.cAccumGreenBits =   0;
    pfd.cAccumBlueBits =    0;
    pfd.cAccumAlphaBits =   0;
    pfd.cDepthBits =        32;
    pfd.cStencilBits =      0;
    pfd.cAuxBuffers =       0;
    pfd.iLayerType =        PFD_MAIN_PLANE;
    pfd.bReserved =         0;
    pfd.dwLayerMask =       0;
	pfd.dwVisibleMask =     0;
	pfd.dwDamageMask =      0;


	m_pDC = new CClientDC(this);
	HDC hdc = m_pDC->GetSafeHdc();

	int pixelFormat = ChoosePixelFormat(hdc, &pfd);
	if (pixelFormat == 0)
	{
		MessageBox("Error in Pixel format choosing!");
		return;
	}
	BOOL bresult = SetPixelFormat(hdc, pixelFormat, &pfd);
	if (!bresult)
	{
		MessageBox("Error in Pixel format registering!");
		return;
	}
	rc = wglCreateContext(hdc);
	if (!rc)
	{
		MessageBox("Error in OpenGL context create!");
		return;
	}
	wglMakeCurrent(hdc, rc);
	glClearColor(0.00f, 0.00f, 0.00f, 1.0f);

	glViewport(0, 0, 300, 300);
	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();

	gluOrtho2D(0, 300, 0, 300);
	glMatrixMode(GL_MODELVIEW);
    glTranslatef(0.0F, 0.0F, -5.0F);

	glNewList(1, GL_COMPILE);
		glColor3f(0.8f, 0.8f, 0.2f);
		glBegin(GL_POLYGON);
			for (i=0; i<360; i++)
			{
				glVertex2f((float)(cos(( (float) i*3.14159)/180)+1), (float)(sin(((float)i*3.14159)/180)+1));
				i += 30;
			}
		glEnd();
	glEndList();

	glNewList(3, GL_COMPILE);
		glBegin(GL_POLYGON);
			for (i=0; i<360; i++)
			{
				glVertex2f((float)(cos(( (float) i*3.14159)/180)+1), (float)(sin(((float)i*3.14159)/180)+1));
				i += 30;
			}
		glEnd();
	glEndList();

	glNewList(2, GL_COMPILE);
		glColor3f(0.0f, 0.0f, 0.9f);
		glLineWidth(2);
		glBegin(GL_QUADS);
			glVertex2f(2, 0);  // 1
			glVertex2f(3, 0);
			glVertex2f(3, 7);
			glVertex2f(2, 7);
			glVertex2f(3, 0);  // 2
			glVertex2f(4, 0);
			glVertex2f(4, 7);
			glVertex2f(3, 7);
			glVertex2f(4, 0);  // 3
			glVertex2f(5, 0);
			glVertex2f(5, 7);
			glVertex2f(4, 7);
			glVertex2f(0, 2);  // 4
			glVertex2f(7, 2);
			glVertex2f(7, 3);
			glVertex2f(0, 3);
			glVertex2f(0, 3);  // 5
			glVertex2f(7, 3);
			glVertex2f(7, 4);
			glVertex2f(0, 4);
			glVertex2f(0, 4);  // 6
			glVertex2f(7, 4);
			glVertex2f(7, 5);
			glVertex2f(0, 5);
		glEnd();
		glBegin(GL_LINES);
			glVertex2f(2, 1);
			glVertex2f(5, 1);
			
			glVertex2f(6, 2);
			glVertex2f(6, 5);
			
			glVertex2f(5, 6);
			glVertex2f(2, 6);
			
			glVertex2f(1, 5);
			glVertex2f(1, 2);
		glEnd();
	glEndList();

	InitBoard();
	_DoNew();
	SetTimer(1, 41, NULL);
}

BOOL CMainWin::PreCreateWindow(CREATESTRUCT &cs)
{
	cs.cx = 300;
	cs.cy = 300;
	cs.x = 200;
	cs.y = 200;
	WindX = cs.x;
	WindY = cs.y;
	cs.style = (WS_CLIPCHILDREN | WS_CLIPSIBLINGS | WS_SYSMENU | WS_MINIMIZEBOX);
	return CFrameWnd::PreCreateWindow(cs);
}

afx_msg void CMainWin::OnDestroy()
{
	HDC hdc = m_pDC->GetSafeHdc();
	wglMakeCurrent(hdc, rc);
	wglDeleteContext(rc);
	CFrameWnd::OnDestroy();
}

afx_msg void CMainWin::OnPrgExit()
{
	SendMessage(WM_CLOSE);
}

afx_msg void CMainWin::OnTimer(UINT ID)
{

	if (ID == 1)
	{
		if (!DlgActive)
		{
			DlgActive = TRUE;
			MainDlg.Create(IDD_MENU);
		}	

		temp += temp / 2;
		if (temp > 30)
		{
			temp = 30;	
			KillTimer(1);
			BeginButtons = TRUE;
			NoStep = FALSE;
		}
		InvalidateRect(NULL, FALSE);
	}
	if (ID == 2)
	{
		
		MX += offsetx;
		MY += offsety;

		if (((offsetx > 0) && (MX > EX)) | ((offsetx < 0) && (MX < EX)) |
		   ((offsety > 0) && (MY > EY)) | ((offsety < 0) && (MY < EY)))
		{
			KillTimer(2);
			DMove = FALSE;
			brd[DownY][DownX] = 0;
			brd[(int)EY][(int)EX] = 1;
			InvalidateRect(NULL, FALSE);
			return;
		}
		
		InvalidateRect(NULL, FALSE);
	}
	if (ID == 3)
	{
		if (!cur_e) return;
		if (DMove) return;
		DoMove(cur_e->StX, cur_e->StY, cur_e->EndX, cur_e->EndY);
		cur_e = cur_e->next;
	}
	if (ID == 4)
	{
		BeginButtons = FALSE;
		temp -= temp / 4;
		if (temp < 0.1)
		{
			temp = 0.1f;	
			KillTimer(4);
			InitBoard();
			SetTimer(1, 41, NULL);
		}
		InvalidateRect(NULL, FALSE);
	}
}

afx_msg void CMainWin::OnPaint()
{
		CPaintDC dc(this);
		HDC hdc = m_pDC->GetSafeHdc();
		wglMakeCurrent(hdc, rc);

		glClear(GL_COLOR_BUFFER_BIT);
		glMatrixMode(GL_MODELVIEW);
		glLoadIdentity();
		glPolygonMode(GL_FRONT, GL_LINE);
		glPushMatrix();
		glTranslatef(40, 30, 0);
		glScalef(temp, temp, 0);
		glCallList(2);
		glPopMatrix();
		if (BeginButtons)
		{
			glPolygonMode(GL_FRONT, GL_FILL);
			for (int i=0; i<7; i++)
			{
				for (int j=0; j<7; j++)
				{
					if ((DMove) && ((i == DownY) && (j == DownX))) continue;

					if (brd[i][j] == 1)
					{
						glPushMatrix();
						glTranslatef(15+30*((float)j+1), 5+30*((float)i+1), 0);
						glScalef(10, 10, 0);
						glCallList(1);
						glPopMatrix();
					}
				}
			}

		}
		if (DMove)
		{
			//glPolygonMode(GL_FRONT, GL_FILL);
			glPushMatrix();
			glTranslatef(15+30*((float)DownX+1), 5+30*((float)DownY+1), 0);
			glScalef(10, 10, 0);
			glColor3f(DownColor, DownColor, 0);
			glCallList(3);
			glPopMatrix();
			DownColor -= 0.1f;
			if (DownColor < 0) DownColor = 0;
			glTranslatef(15+30*(MX+1), 5+30*(MY+1), 0);
			glScalef(10, 10, 0);
			glCallList(1); 
		}
		glFinish();
		SwapBuffers(wglGetCurrentDC());
}

BEGIN_MESSAGE_MAP(CMainWin, CFrameWnd)
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_TIMER()
	ON_MESSAGE(MSG_DOSTOP, DoStop)
	ON_MESSAGE(MSG_DONEW, DoNew)
	ON_MESSAGE(MSG_DOSTEP, DoStep)
	ON_MESSAGE(MSG_DOPLAY, DoPlay)
END_MESSAGE_MAP()

afx_msg void CMainDlg::OnDoStop()
{
	CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
	pFrameWnd->SendMessage(MSG_DOSTOP);
}
afx_msg void CMainDlg::OnNew()
{
	CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
	pFrameWnd->SendMessage(MSG_DONEW);
}
afx_msg void CMainDlg::OnStep()
{
	CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
	pFrameWnd->SendMessage(MSG_DOSTEP);
}
afx_msg void CMainDlg::OnPlay()
{
	CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
	pFrameWnd->SendMessage(MSG_DOPLAY);
}
afx_msg void CMainDlg::OnExit()
{
	CFrameWnd* pFrameWnd = STATIC_DOWNCAST(CFrameWnd, AfxGetMainWnd());
	pFrameWnd->SendMessage(WM_CLOSE);
}

CMainDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	CButton *lpbs = (CButton *) GetDlgItem(IDC_START);	
	CButton *lpbst = (CButton *) GetDlgItem(IDC_STEP);	
	CButton *lpbp = (CButton *) GetDlgItem(IDC_PLAY);	
	CButton *lpbstop = (CButton *) GetDlgItem(IDC_STOP);	
	CButton *lpbex = (CButton *) GetDlgItem(IDC_EXIT);	
	bmp1.LoadBitmap(IDB_START);
	lpbs->SetBitmap(bmp1);
	bmp2.LoadBitmap(IDB_STEP);
	lpbst->SetBitmap(bmp2);
	bmp3.LoadBitmap(IDB_PLAY);
	lpbp->SetBitmap(bmp3);
	bmp4.LoadBitmap(IDB_STOP);
	lpbstop->SetBitmap(bmp4);
	bmp5.LoadBitmap(IDB_EXIT);
	lpbex->SetBitmap(bmp5);
	
	SetWindowPos(NULL, WindX+300, WindY, 68, 95, SWP_SHOWWINDOW|SWP_DRAWFRAME|SWP_NOSIZE|SWP_NOZORDER);  

	return TRUE;
}

afx_msg void CMainDlg::OnCancel()
{

}

BEGIN_MESSAGE_MAP(CMainDlg, CDialog)
	ON_COMMAND(IDC_STOP, OnDoStop)
	ON_COMMAND(IDC_START, OnNew)
	ON_COMMAND(IDC_STEP, OnStep)
	ON_COMMAND(IDC_PLAY, OnPlay)
	ON_COMMAND(IDC_EXIT, OnExit)
END_MESSAGE_MAP()