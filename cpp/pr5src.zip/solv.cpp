#include <windows.h>
#include <stdio.h>
#include <time.h>
#include "solv.h"

BYTE m[7][7];

int i, j;
int ttt;
int height=0;
BOOL yh=FALSE;

SSolv *fe, *ce; // First and current elements
void Init()
{
	for (int i=0; i<7; i++)
	{
		for (int j=0; j<7; j++)
			m[i][j] = 1;
	}
	m[0][0] = 2; m[0][1] = 2;
	m[1][0] = 2; m[1][1] = 2;
	m[5][0] = 2; m[5][1] = 2;
	m[6][0] = 2; m[6][1] = 2;
	m[0][5] = 2; m[0][6] = 2;
	m[1][5] = 2; m[1][6] = 2;
	m[5][5] = 2; m[5][6] = 2;
	m[6][5] = 2; m[6][6] = 2;
	m[3][3] = 0;
	srand((unsigned)time(NULL));
	fe = NULL;
}
void AddMove(int sx, int sy, int ex, int ey)
{
	SSolv *temp;
	if (!fe)
	{
		fe = new SSolv;
		ce = fe;
	}
	else
	{
		temp = new SSolv;
		ce->next = temp;
		ce = temp;
	}
	ce->next = NULL;
	ce->StX = sx;
	ce->StY = sy;
	ce->EndX = ex;
	ce->EndY = ey;
}

BOOL Solve(int Total)
{
	if ((Total == 1) && (m[3][3] == 1))
	{
		//Solving Found
		if (ttt <= 0) return TRUE;
		ttt--;
		return FALSE;
	}
	if (Total<=1) return FALSE;

	for (int i=0; i<7; i++)
	{
		for (int j=0; j<7; j++)
		{
			if (m[i][j]!=1) continue;
			
			if (j>1) // Move to left
			{
				if ((m[i][j-2] == 0) && (m[i][j-1] == 1))
				{
					m[i][j-2] = 1;
					m[i][j-1] = 0;
					m[i][j] = 0;
					if (Solve(Total-1)) 
					{
						m[i][j-2] = 0;
						m[i][j-1] = 1;
						m[i][j] = 1;
						AddMove(j, i, j-2, i);
						return TRUE;
					}
					m[i][j-2] = 0;
					m[i][j-1] = 1;
					m[i][j] = 1;
				}
			}
			if (i>1) // Move to Up
			{
				if ((m[i-2][j] == 0) && (m[i-1][j] == 1))
				{
					m[i-2][j] = 1;
					m[i-1][j] = 0;
					m[i][j] = 0;
					if (Solve(Total-1))
					{
						m[i-2][j] = 0;
						m[i-1][j] = 1;
						m[i][j] = 1;
						AddMove(j, i, j, i-2);
						return TRUE;
					}
					m[i-2][j] = 0;
					m[i-1][j] = 1;
					m[i][j] = 1;
				}
			}
			if (j<5) // Move to Right
			{
				if ((m[i][j+2] == 0) && (m[i][j+1] == 1))
				{
					m[i][j+2] = 1;
					m[i][j+1] = 0;
					m[i][j] = 0;
					if (Solve(Total-1))
					{
						m[i][j+2] = 0;
						m[i][j+1] = 1;
						m[i][j] = 1;
						AddMove(j, i, j+2, i);
						return TRUE;
					}
					m[i][j+2] = 0;
					m[i][j+1] = 1;
					m[i][j] = 1;
				}
			}
			if (i<5) // Move to Down
			{
				if ((m[i+2][j] == 0) && (m[i+1][j] == 1))
				{
					m[i+2][j] = 1;
					m[i+1][j] = 0;
					m[i][j] = 0;
					if (Solve(Total-1))
					{
						m[i+2][j] = 0;
						m[i+1][j] = 1;
						m[i][j] = 1;
						AddMove(j, i, j, i+2);
						return TRUE;
					}
					m[i+2][j] = 0;
					m[i+1][j] = 1;
					m[i][j] = 1;
				}
			}
		}
	}
	return FALSE;
}


SSolv *GetSolve()
{
	Init();
	for (int i=0; i<10; i++)
		ttt = (rand() % 20);
	Solve(32);
	return fe;	
}
