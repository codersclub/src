//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by prb5.rc
//
#define IDD_MENU                        102
#define IDB_START                       107
#define IDB_STEP                        108
#define IDB_PLAY                        109
#define IDB_STOP                        110
#define IDB_EXIT                        111
#define IDC_START                       1000
#define IDC_PLAY                        1001
#define IDC_STEP                        1002
#define IDC_STOP                        1003
#define IDC_EXIT                        1004

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40004
#define _APS_NEXT_CONTROL_VALUE         1005
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
