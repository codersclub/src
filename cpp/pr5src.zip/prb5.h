#include <afxext.h>

class CPrb5 : public CWinApp
{
		 
public:
	
	BOOL InitInstance();
};

class CMainWin : public CFrameWnd
{

public:
	
	CMainWin();
	BOOL PreCreateWindow(CREATESTRUCT &cs);

	void DoMove(int StX, int StY, int EndX, int EndY);
	afx_msg void OnDestroy();
	afx_msg void OnPrgExit();

	afx_msg void OnTest();
	afx_msg void OnTimer(UINT ID);

	afx_msg void OnPaint();
	afx_msg LRESULT DoStop(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT DoNew(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT DoStep(WPARAM wParam, LPARAM lParam);
	afx_msg LRESULT DoPlay(WPARAM wParam, LPARAM lParam);

	
	DECLARE_MESSAGE_MAP()
};

class CMainDlg : public CDialog
{
protected:
	CBitmap bmp1, bmp2, bmp3, bmp4, bmp5;
public:
	CMainDlg() : CDialog() {}
	BOOL OnInitDialog();
	afx_msg void OnCancel();
	afx_msg void OnDoStop();
	afx_msg void OnNew();
	afx_msg void OnStep();
	afx_msg void OnPlay();
	afx_msg void OnExit();

	DECLARE_MESSAGE_MAP()
};
