struct SSolv
{
	int StX, StY; // Start position
	int EndX, EndY; // End position
	SSolv *next; // Next element in structure
};

SSolv *GetSolve();