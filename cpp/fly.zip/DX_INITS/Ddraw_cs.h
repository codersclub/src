
bool		DDrawInitFS		(void);

//==================================================
//
//	For Initializing DirectDraw
//
//==================================================

bool DDrawInitFS(void)
{
//================================================
//	Setting up Needed parameters
//================================================

	DDSURFACEDESC	desc;

	ZeroMemory (&desc, sizeof (desc));
	desc.dwSize = sizeof (desc);
	desc.dwFlags = DDSD_CAPS | DDSD_BACKBUFFERCOUNT;
	desc.ddsCaps.dwCaps = DDSCAPS_PRIMARYSURFACE | DDSCAPS_FLIP | DDSCAPS_3DDEVICE | DDSCAPS_COMPLEX;
	desc.dwBackBufferCount = 1;

	DDSCAPS		ddscaps;
	ddscaps.dwCaps = DDSCAPS_BACKBUFFER;

//================================================
//	Creating the DirectDraw2 Object
//================================================
	
	LPDIRECTDRAW		DD_t;
	LPDIRECTDRAWSURFACE	DD_st;
	HRESULT			DD_val;

	DD_val =  DirectDrawCreate (0, &DD_t, 0);
	DD_val =+ DD_t->QueryInterface (IID_IDirectDraw2, (void **)&ddraw.DD);

	DD_t->Release();
	DD_t=0;

//================================================
//	Set the CooperativeLevel & Display mode
//================================================

	switch (LoadOpt.resolution)
	{
	case 1:
		NewRes.x = 320;
		NewRes.y = 240;
		break;
	case 2:
		NewRes.x = 400;
		NewRes.y = 300;
		break;
	case 3:
		NewRes.x = 640;
		NewRes.y = 480;
		break;
	case 4:
		NewRes.x = 1024;
		NewRes.y = 768;
		break;
	};

	if(NewRes.x == 320)
	{
		desc.ddsCaps.dwCaps |= DDSCAPS_MODEX;
		DD_val =+ ddraw.DD->SetCooperativeLevel (hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN | DDSCL_ALLOWMODEX);
	};
	DD_val =+ ddraw.DD->SetCooperativeLevel (hWnd, DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN);
	DD_val =+ ddraw.DD->SetDisplayMode (NewRes.x, NewRes.y, 16, 0, 0);


//================================================
//	Creating PrimSurf, DDSurface3 Object, BackSurf
//================================================

	DD_val =+ ddraw.DD->CreateSurface (&desc, &DD_st, NULL);
	DD_val =+ DD_st->QueryInterface (IID_IDirectDrawSurface3, (void **)&ddraw.DDSP);
	DD_val =+ ddraw.DDSP->GetAttachedSurface (&ddscaps, &ddraw.DDSB);
	
	DD_st->Release();
	DD_st=0;
	
//================================================
//	if error then .....
//================================================

	if(DD_val==DD_OK) return TRUE;

	MessageBox (hWnd, "Direct Draw Init Failed (%08lx)\n", "ERROR", MB_OK);
	DestroyWindow (hWnd);
	return FALSE;

//================================================
//	End DDrawInitFS
//================================================

};

