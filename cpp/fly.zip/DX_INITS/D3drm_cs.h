
bool		D3DInit		(void);

//==================================================
//
//	For initializing Direct3DRM
//
//==================================================

bool D3DInit ()
{
//================================================
//	Creating the Direct3DRM2 Object
//================================================

	HRESULT		d3drval;
	LPDIRECT3DRM	d3d_t;

	Direct3DRMCreate (&d3d_t);
	d3drval = d3d_t->QueryInterface(IID_IDirect3DRM2, (VOID **)&d3drm.D3DRM);

	d3d_t->Release();
	d3d_t=0;

//================================================
//	Set texture Param-s
//================================================
	
	d3drval =+ d3drm.D3DRM->SetDefaultTextureColors(64);
	d3drval =+ d3drm.D3DRM->SetDefaultTextureShades(32);

//================================================
//	Create & Setting up the Direct3D Device 
//================================================


	D3DDEVICEDESC	d3dSWdesc;

	ZeroMemory (&d3dSWdesc, sizeof (d3dSWdesc));
	d3dSWdesc.dwSize = sizeof (d3dSWdesc);
	d3dSWdesc.dwFlags = D3DDD_COLORMODEL;
	d3dSWdesc.dcmColorModel = D3DCOLOR_RGB;

	D3DFINDDEVICERESULT d3dCDesc;
	ZeroMemory (&d3dCDesc, sizeof (d3dCDesc));
	d3dCDesc.dwSize = sizeof (d3dCDesc);
	
	switch(LoadOpt.device)
	{
	case 1:
		d3dSWdesc.dcmColorModel = D3DCOLOR_MONO;
		d3dCDesc.guid = IID_IDirect3DRampDevice;
		break;
	case 2:	
		d3dCDesc.guid = IID_IDirect3DRGBDevice;
		break;
	case 3:
		d3dCDesc.guid = IID_IDirect3DMMXDevice;
		break;
	case 4:
		d3dCDesc.guid = IID_IDirect3DHALDevice;
		break;
	};
	d3dCDesc.ddSwDesc = d3dSWdesc;

	d3drval =+ d3drm.D3DRM->CreateDeviceFromSurface (&d3dCDesc.guid, (LPDIRECTDRAW)ddraw.DD, (LPDIRECTDRAWSURFACE)ddraw.DDSB, &d3drm.device);

	d3drval =+ d3drm.device->SetShades(32);

	switch(LoadOpt.shading)
	{
	case 1:
		d3drval =+ d3drm.device->SetQuality (D3DRMRENDER_FLAT);
		break;
	case 2:	
		d3drval =+ d3drm.device->SetQuality (D3DRMRENDER_GOURAUD);
		break;
	case 3:
		d3drval =+ d3drm.device->SetQuality (D3DRMRENDER_PHONG);
		break;
	};

	d3drval =+ d3drm.device->SetDither(false);
	if(LoadOpt.dithering==true) d3drval =+ d3drm.device->SetDither(true);

	d3drval =+ d3drm.device->SetRenderMode (D3DRMRENDERMODE_BLENDEDTRANSPARENCY | D3DRMRENDERMODE_SORTEDTRANSPARENCY);

//================================================
//	Create & Setting up main frames
//================================================

	d3drval =+ d3drm.D3DRM->CreateFrame(NULL, &d3drm.scene);
	d3drval =+ d3drm.D3DRM->CreateFrame(d3drm.scene, &d3drm.camera);

	d3drval =+ d3drm.camera->SetPosition(d3drm.scene, D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0));
	d3drval =+ d3drm.camera->SetZbufferMode(D3DRMZBUFFER_DISABLE);
//	d3drval =+ d3drm.camera->SetZbufferMode(D3DRMZBUFFER_ENABLE);

//================================================
//	Create & Setting up the Direct3D Vievport
//================================================

	d3drval =+ d3drm.D3DRM->CreateViewport(d3drm.device, d3drm.camera, 0, 0, NewRes.x, NewRes.y, &d3drm.view);
//	d3drval =+ d3drm.D3DRM->CreateViewport(d3drm.device, d3drm.camera, 0, 0, 400, 300, &d3drm.view);

	d3drval =+ d3drm.view->SetBack(D3DVAL(5500));
	d3drval =+ d3drm.view->SetProjection (D3DRMPROJECT_PERSPECTIVE);
  
//================================================
//	if error then ....
//================================================

if(d3drval==DD_OK) return TRUE;

	MessageBox (hWnd, "Direct 3DRM Init Failed (%08lx)\n", "ERROR", MB_OK);
	Kill_Objects ( );
	DestroyWindow (hWnd);
	return FALSE;

//================================================
//	End D3DInit
//================================================

};
