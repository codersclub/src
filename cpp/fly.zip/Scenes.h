
BOOL		SceneInit		(void);

//==================================================
//
//	make the World Scene
//
//==================================================

BOOL SceneInit(void)
{
  
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpWorldFrame);
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpLightFrame);
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpWorldFrame2);


	lpLightFrame->SetPosition(d3drm.scene, D3DVAL(-5), D3DVAL(8), D3DVAL(-5));
	
	d3drm.D3DRM->CreateLightRGB(D3DRMLIGHT_AMBIENT, D3DVAL(0.5), D3DVAL(0.5), D3DVAL(0.5), &lpLight);
	lpLightFrame->AddLight(*(&lpLight));
	
	d3drm.D3DRM->CreateLightRGB(D3DRMLIGHT_POINT, D3DVAL(1), D3DVAL(1), D3DVAL(1), &lpLight);
	lpLightFrame->AddLight(*(&lpLight));

  d3drm.camera->SetPosition(d3drm.scene, D3DVAL(camX), D3DVAL(camY), D3DVAL(camZ));
	d3drm.camera->SetOrientation(d3drm.scene, D3DVAL(10),D3DVAL(0),D3DVAL(100),
		D3DVAL(0), D3DVAL(1), D3DVAL(0));



//	d3drm.camera->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(0), D3DVAL(camZ));
//	d3drm.camera->SetOrientation(d3drm.scene, D3DVAL(0),D3DVAL(0),D3DVAL(10),
//		D3DVAL(0), D3DVAL(1), D3DVAL(0));

//	d3drm.camera->SetRotation(d3drm.scene,1,1,0,0.01);
//	d3drm.camera->SetRotation(d3drm.scene,1,1,0,1);
//	lpWorldFrame->SetRotation(d3drm.scene, D3DVAL(0.0), D3DVAL(1.0),
//		D3DVAL(0.0), D3DVAL(-0.05));
//  lpWorldFrame2->SetRotation(scene1, D3DVAL(0.0), D3DVAL(-1.0),
//		D3DVAL(0.0), D3DVAL(5));

 d3drm.D3DRM->LoadTexture ("textures\\sand.BMP", &texture1);
// d3drm.D3DRM->LoadTexture ("textures\\sky.BMP", &texture2);
   


//  texture2->SetDecalTransparency(true);

//d3drm.D3DRM->LoadTexture ("textures\\transp.BMP", &texture_transp);
//texture_transp->SetDecalTransparency(true);
 
 //d3drm.scene->SetSceneBackgroundRGB(D3DVAL(0.7),D3DVAL(0.3),D3DVAL(0.3));
// if (texture1->SetDecalTransparency(true))
//	MessageBox (hWnd, "back failed (%08lx)\n", "ERROR", MB_OK);

   

	// for top & bottom

	d3drm.D3DRM->CreateWrap (D3DRMWRAP_FLAT, NULL,
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
		D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(1.0),
		&wrap1);

	// for up & down

	d3drm.D3DRM->CreateWrap (D3DRMWRAP_FLAT, NULL,
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
		D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(1.0),
		&wrap2);
		
	// for left & right
/*
	d3drm.D3DRM->CreateWrap (D3DRMWRAP_FLAT, NULL,
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(1.0),
		&wrap3);
*/

   d3drm.D3DRM->CreateWrap
	   (
	    D3DRMWRAP_CYLINDER, NULL,
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
        D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(1.0), D3DVAL(1.0),
        &wrap3);
   
     srand( (unsigned)time( NULL ) );
	 plane_an.kolvo=9;
	 plane_an.anima=pathp;
	 for (int tempI=0;tempI<1;tempI++)
	 {
	 object3D[tempI].LoadObject("models\\747.x",NULL);
	 object3D[tempI].InitAnimation(&plane_an);
	 }
	object3D[0].mesh->Scale(0.2,0.2,0.2);

	 object3D[1].LoadObject("models\\land.x",texture1);
     object3D[1].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-50), D3DVAL(0));
     object3D[1].mesh->Scale(24,18,24);   
	 object3D[1].mesh->SetColorRGB(D3DVAL(0.5), D3DVAL(0.5), D3DVAL(0.1)); 
     d3drm.D3DRM->CreateFrame(lpWorldFrame, &lpChaseFrame);
    
	return TRUE;

//================================================
//	End SceneInit
//================================================

};

