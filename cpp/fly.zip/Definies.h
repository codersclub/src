#define WIN32_LEAN_AND_MEAN
#define INITGUID

#include <windows.h>
#include <Ddraw.h>
#include <D3drmwin.h>
#include <Dinput.h>
#include <time.h>

//#include <..\\misc\\ddutil.cpp>

#pragma comment (lib,"dxguid.lib")
#pragma comment (lib,"ddraw.lib")
#pragma comment (lib,"d3drm.lib")
#pragma comment (lib,"dinput.lib")


struct _DDRAW
{
	LPDIRECTDRAW2		      DD;
	LPDIRECTDRAWSURFACE3		DDSP;
	LPDIRECTDRAWSURFACE3		DDSB;
} ddraw;

struct _D3DRM
{
	LPDIRECT3DRM2			D3DRM;
	LPDIRECT3DRMDEVICE2		device;
	LPDIRECT3DRMVIEWPORT		view;
	LPDIRECT3DRMFRAME2		scene;
	LPDIRECT3DRMFRAME2		camera;
} d3drm;

struct _DI
{
	LPDIRECTINPUT di;
	LPDIRECTINPUTDEVICE kbrd;
	LPDIRECTINPUTDEVICE mouse;
} di;


LPDIRECT3DRMFRAME2		lpLightFrame, lpWorldFrame, lpWorldFrame2, cadr2, lpChaseFrame;
LPDIRECT3DRMLIGHT			lpLight;
LPDIRECT3DRMTEXTURE2		texture1, texture2, texture_transp;

LPDIRECT3DRMWRAP			wrap1, wrap2, wrap3, wrap4;
LPDIRECT3DRMMESHBUILDER2	top, left, right, up, down,cube;
LPDIRECT3DRMMESHBUILDER2	transp;
LPDIRECT3DRMANIMATION anim_path;
//	float timeT=0;
	int ranint1=0; 
	int ranint2=0; 
	D3DVECTOR tempVector,tempVector1,tempVector2;
	int FillColor=35100;

struct _Opt
{
	int resolution;
	int device;
	int shading;
	
	bool persp_corr;
	bool dithering;
	bool antialiasing;
} LoadOpt;

struct _Res
{
	int x;
	int y;
} NewRes;



  struct animpos
  {
float time;
float x;
float y;
float z;
  };

  struct animat
  {
	int kolvo;
	animpos *anima;
  };
  
  struct animrot
  {
 float time;
 D3DRMQUATERNION *a;
  };



  class platonObject
  {
  public:
	LPDIRECT3DRMFRAME2         frame;  
	LPDIRECT3DRMMESHBUILDER2   mesh;
    LPDIRECT3DRMANIMATION      animation; 
	float                      timeT; 

   void LoadObject(char *name,LPDIRECT3DRMTEXTURE texture)
   {
	   timeT=0;
    d3drm.D3DRM->CreateFrame(lpWorldFrame, &frame);
  	d3drm.D3DRM->CreateMeshBuilder(&mesh);

   mesh->Load(name,NULL,D3DRMLOAD_FROMFILE, NULL, NULL);
   frame->AddVisual (mesh);
   mesh->SetPerspective(TRUE);
   if (texture!=NULL)
   {
    mesh->SetTexture(texture);
    wrap1->Apply (mesh);
   }

    d3drm.D3DRM->CreateAnimation(&animation); 

	animation->SetOptions  	    ( D3DRMANIMATION_CLOSED
                                         | D3DRMANIMATION_SPLINEPOSITION
                                         | D3DRMANIMATION_POSITION);

//	animation->SetOptions  	    ( D3DRMANIMATION_CLOSED
//                                         | D3DRMANIMATION_LINEARPOSITION 
//                                         | D3DRMANIMATION_POSITION);
	
	animation->SetFrame(frame);

	    

   }

	 
     void InitAnimation(animat *anim)
	 {
  int tempI;


  if (anim->kolvo!=NULL)
  {  
  for (tempI=0;tempI<anim->kolvo;tempI++) animation->AddPositionKey(
	  anim->anima[tempI].time, anim->anima[tempI].x,
	  anim->anima[tempI].y,    anim->anima[tempI].z);

   }
 	
	  }

 };

   animpos pathp[]=
 {
	 0  ,  -600, 0 ,  0,
	 100,  -300, 0 ,  300,
	 200,   300, 0 ,  300,
	 300,   600, 0 ,  0,
	 400,   600, 0 , -300,
	 500,   300, 0 , -600,
	 600,  -300, 0 , -600,
	 700,  -300, 0 , -300,


	 800,  -600, 0 , 0
   };
  

 int kolvo_pos=5;
 int kolvo_rot=3;


platonObject object3D[20];

animat plane_an;
double camX=40, camY=20, camZ=-10;
double camXi=40, camYi=20, camZi=-10;

HWND hWnd;

