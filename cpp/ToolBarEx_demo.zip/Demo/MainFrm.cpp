// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "Demo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_CUSTOMIZE, OnCustomize)
	//}}AFX_MSG_MAP
	ON_CBN_SELENDOK  (ID_FIND,OnSelChange)

END_MESSAGE_MAP()

static UINT indicators[] =
{
	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_CAPS,
	ID_INDICATOR_NUM,
	ID_INDICATOR_SCRL,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
{
	// TODO: add member initialization code here
	m_pComboBox=NULL;
}

CMainFrame::~CMainFrame()
{
	//m_pComboBox destroyed by toolbarex
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	if (!m_wndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_wndToolBar.LoadToolBar(IDR_MAINFRAME))
	{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
	}

	CRect rt(0,0,200,120);
	//Insert Control
   	m_pComboBox =(CComboBox *) m_wndToolBar.InsertControl(RUNTIME_CLASS(CComboBox),_T(""),rt,ID_FIND,WS_VSCROLL|CBS_DROPDOWNLIST);

	m_pComboBox->AddString(_T("One"));
	m_pComboBox->AddString(_T("Two"));
	m_pComboBox->AddString(_T("Three"));


	//Add DropDown
	m_wndToolBar.AddDropDownButton(ID_OP,IDR_OP,TRUE);

	//Enable Customization
	m_wndToolBar.SetToolBarInfoForCustomization();

	//Restore State
	m_wndToolBar.RestoreState();


	if (!m_wndStatusBar.Create(this) ||
		!m_wndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
	{
		TRACE0("Failed to create status bar\n");
		return -1;      // fail to create
	}

	// TODO: Delete these three lines if you don't want the toolbar to
	//  be dockable
	m_wndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_wndToolBar);

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers


void CMainFrame::OnSelChange()
{
	ASSERT_VALID(m_pComboBox);

    int nPos=m_pComboBox->GetCurSel() ;

	if (nPos!=-1)
	{
		CString str,str1;
		m_pComboBox->GetLBText(nPos,str1);
		str.Format(_T("You Selected :%s"),str1);
		AfxMessageBox(str);
	}
}

 

void CMainFrame::OnCustomize() 
{
	m_wndToolBar.GetToolBarCtrl().Customize();
	
}
