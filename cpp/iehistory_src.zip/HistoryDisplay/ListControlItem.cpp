// ListControlm_Item.cpp: implementation of the CListControlItem class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "ListControlItem.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CListControlItem::CListControlItem()
{
	m_Item.mask;
	m_Item.iItem;
	m_Item.iSubItem;
	m_Item.state;
	m_Item.stateMask;
	m_Item.pszText;
	m_Item.cchTextMax;
	m_Item.iImage;
	m_Item.lParam;
}

CListControlItem::~CListControlItem()
{

}

CListControlItem::CListControlItem(LPCTSTR lpszString, LPARAM lValue)
{
	m_Item.mask = LVIF_TEXT | LVIF_PARAM;
	m_Item.iItem = 0;
	m_Item.iSubItem = 0;
	m_Item.state = 0;
	m_Item.stateMask = 0;
	m_Item.pszText = (LPTSTR)lpszString;
	m_Item.cchTextMax = strlen(lpszString);
	m_Item.iImage = 0;
	m_Item.lParam = lValue;
	m_Item.iIndent = 0;
}

CListControlItem::CListControlItem(LPCTSTR lpszString)
{
	m_Item.mask = LVIF_TEXT;
	m_Item.iItem = 0;
	m_Item.iSubItem = 0;
	m_Item.state = 0;
	m_Item.stateMask = 0;
	m_Item.pszText = (LPTSTR)lpszString;
	m_Item.cchTextMax = strlen(lpszString);
	m_Item.iImage = 0;
	m_Item.lParam = NULL;
	m_Item.iIndent = 0;
}

CListControlItem::CListControlItem(int nID,int nSubID,LPCTSTR lpszString)
{
	m_Item.mask = LVIF_TEXT ; 
	m_Item.iItem = nID;
	m_Item.iSubItem = nSubID;
	m_Item.state = 0;
	m_Item.stateMask = 0;
	m_Item.pszText = (LPTSTR)lpszString;
	m_Item.cchTextMax = strlen(lpszString);
	m_Item.iImage = 0;
	m_Item.lParam = NULL;
	m_Item.iIndent = 0;
}


void CListControlItem::SetItemInfo(int nID,int nSubID,LPCTSTR lpszString)
{
	m_Item.mask = LVIF_TEXT ; 
	m_Item.iItem = nID;
	m_Item.iSubItem = nSubID;
	m_Item.state = 0;
	m_Item.stateMask = 0;
	m_Item.pszText = (LPTSTR)lpszString;
	m_Item.cchTextMax = strlen(lpszString);
	m_Item.iImage = 0;
	m_Item.lParam = NULL;
	m_Item.iIndent = 0;
}
