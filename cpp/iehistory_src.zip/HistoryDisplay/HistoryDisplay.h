// HistoryDisplay.h : main header file for the HISTORYDISPLAY application
//

#if !defined(AFX_HISTORYDISPLAY_H__2C8AFD0D_88D6_4A5E_BEED_032973CBE9D1__INCLUDED_)
#define AFX_HISTORYDISPLAY_H__2C8AFD0D_88D6_4A5E_BEED_032973CBE9D1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CHistoryDisplayApp:
// See HistoryDisplay.cpp for the implementation of this class
//

class CHistoryDisplayApp : public CWinApp
{
public:
	CHistoryDisplayApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistoryDisplayApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CHistoryDisplayApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTORYDISPLAY_H__2C8AFD0D_88D6_4A5E_BEED_032973CBE9D1__INCLUDED_)
