#if !defined(AFX_HISTORYLISTCTRL_H__0F631873_4D9C_4C39_99DD_2F8648FD7DEC__INCLUDED_)
#define AFX_HISTORYLISTCTRL_H__0F631873_4D9C_4C39_99DD_2F8648FD7DEC__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// HistoryListCtrl.h : header file
//

#include "ListControlItem.h"

/////////////////////////////////////////////////////////////////////////////
// CHistoryListCtrl window
#include "IEHistory.h"

class CHistoryListCtrl : public CListCtrl
{
// Construction
public:
	CHistoryListCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistoryListCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	void Add( CIEUrl & url );
	virtual ~CHistoryListCtrl();
	void Init();
	// Generated message map functions
protected:

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTORYLISTCTRL_H__0F631873_4D9C_4C39_99DD_2F8648FD7DEC__INCLUDED_)
