// HistoryDisplayDlg.h : header file
//

#if !defined(AFX_HISTORYDISPLAYDLG_H__2EB0EB92_2AF5_426F_B526_ACE6E6DD0F40__INCLUDED_)
#define AFX_HISTORYDISPLAYDLG_H__2EB0EB92_2AF5_426F_B526_ACE6E6DD0F40__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "IEHistory.h"
#include "HistoryListCtrl.h"
/////////////////////////////////////////////////////////////////////////////
// CHistoryDisplayDlg dialog

class CHistoryDisplayDlg : public CDialog
{
// Construction
public:
	void ShowHistory();
	CHistoryDisplayDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CHistoryDisplayDlg)
	enum { IDD = IDD_HISTORYDISPLAY_DIALOG };
	CHistoryListCtrl	m_List;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistoryDisplayDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CHistoryDisplayDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTORYDISPLAYDLG_H__2EB0EB92_2AF5_426F_B526_ACE6E6DD0F40__INCLUDED_)
