#if (!defined(__NEURO__MEDIA__HISTORY__))
#define __NEURO__MEDIA__HISTORY__

/***********************************************************************
LICENSE AGREEMENT AND POLICY

The following code is provided on AS IS basis, no claim should be made
if the code does any damage, the user using and modifying this code will 
be responsible for any kind of damange this code produces.

You can freely distribute, use this code as long as you insert this 
Agreement with each distribution.

The code should not be sold at any cases.

-Akash Kava
ackava@hotmail.com
************************************************************************/

#include <atlbase.h>
#include <comdef.h>
#include <mshtml.h>
#include <UrlHist.h>
#include <afxtempl.h>

/************************************************************************
		 Name   : CIEUrl
		 Type   : class
------------------------------------------------------------------------
		 Author : Akash Kava
		 Purpose: Holds URL elements in the url history of IE
************************************************************************/
class CIEUrl{
public:
	CString			strUrl;
	CString			strTitle;

	COleDateTime	odtLastUpdated;
	COleDateTime	odtLastVisited;
	COleDateTime	odtExpires;

	CIEUrl(){};

	CIEUrl(STATURL url)
	{
		strUrl			= url.pwcsUrl ;
		strTitle		= url.pwcsTitle ;
		odtLastUpdated	= url.ftLastUpdated ;
		odtLastVisited	= url.ftLastVisited ;
		odtExpires		= url.ftExpires;
	}

	CIEUrl(CIEUrl & url)
	{
		strUrl			= url.strUrl ;
		strTitle		= url.strTitle ;
		odtLastUpdated	= url.odtLastUpdated ;
		odtLastVisited	= url.odtLastVisited ;
		odtExpires		= url.odtExpires;
	}

	void operator = (CIEUrl & url)
	{
		strUrl			= url.strUrl ;
		strTitle		= url.strTitle ;
		odtLastUpdated	= url.odtLastUpdated ;
		odtLastVisited	= url.odtLastVisited ;
		odtExpires		= url.odtExpires;
	}
};



/************************************************************************
		 Name   : CIEUrlList
		 Type   : class
------------------------------------------------------------------------
		 Author : Akash Kava
		 Purpose: Holds List of CIEUrl as CList
************************************************************************/
class CIEUrlList : public CList<CIEUrl,CIEUrl&> {};



/************************************************************************
		 Name   : CIEHistory
		 Type   : class
------------------------------------------------------------------------
		 Author : Akash Kava
		 Purpose: The class for accessing History
************************************************************************/
class CIEHistory{
public:

	/************************************************************************
			 FUNCTION
			 Name   : GetHistory
			 Author : Akash Kava
			 Purpose: Gets history of IE and stores it into CStringList,
					  Returns only URL paths
	========================================================================
			 Params : list As Reference CStringList
	------------------------------------------------------------------------
			 Returns: TRUE if successful
	************************************************************************/
	BOOL GetHistory(CStringList & list)
	{
		STATURL url;
		CString strUrl;

		ULONG uFetched;
		
		IUrlHistoryStg2Ptr history;
		IEnumSTATURLPtr enumPtr;

		if(FAILED(CoCreateInstance(CLSID_CUrlHistory, NULL, CLSCTX_INPROC_SERVER, IID_IUrlHistoryStg2,(void**)&history)))
		{
			return false;
		}

		if(FAILED(history->EnumUrls(&enumPtr)))
			return false;

		while(SUCCEEDED(enumPtr->Next(1,&url,&uFetched)))
		{
			if(uFetched==0)
				break;
			strUrl = url.pwcsUrl;
			list.AddTail(strUrl);
		}
		return true;
	}

	/************************************************************************
			 FUNCTION
			 Name   : GetHistory
			 Author : Akash Kava
			 Purpose: Gets history of IE and stores it into CIEUrlList
					  Returns complete URL information.
	========================================================================
			 Params : list As Reference CIEUrlList
	------------------------------------------------------------------------
			 Returns: TRUE if successful
	************************************************************************/
	BOOL GetHistory(CIEUrlList & list)
	{
		STATURL url;
		CString strUrl;

		ULONG uFetched;
		
		IUrlHistoryStg2Ptr	history;
		IEnumSTATURLPtr		enumPtr;

		if(FAILED(CoCreateInstance(CLSID_CUrlHistory, NULL, CLSCTX_INPROC_SERVER, IID_IUrlHistoryStg2,(void**)&history)))
		{
			return false;
		}

		if(FAILED(history->EnumUrls(&enumPtr)))
			return false;

		while(SUCCEEDED(enumPtr->Next(1,&url,&uFetched)))
		{
			if(uFetched==0)
				break;
			list.AddTail(CIEUrl(url));
		}
		return true;
	}

};

#endif