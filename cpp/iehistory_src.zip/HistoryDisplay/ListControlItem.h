// ListControlItem.h: interface for the CListControlItem class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LISTCONTROLITEM_H__2CA87966_BA9F_498C_BC72_2F6BCE088FED__INCLUDED_)
#define AFX_LISTCONTROLITEM_H__2CA87966_BA9F_498C_BC72_2F6BCE088FED__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CListControlItem  
{
public:
	CListControlItem(int nID,int nSubID,LPCTSTR lpszString);
	void SetItemInfo(int nID,int nSubID,LPCTSTR lpszString);
	CListControlItem(LPCTSTR lpszString);
	CListControlItem( LPCTSTR lpszString , LPARAM lValue);
	LVITEM m_Item;
	CListControlItem();
	virtual ~CListControlItem();

	operator LVITEM()
	{
		return m_Item;
	}

	operator const LVITEM * () const
	{
		return &m_Item;
	}
};

#endif // !defined(AFX_LISTCONTROLITEM_H__2CA87966_BA9F_498C_BC72_2F6BCE088FED__INCLUDED_)
