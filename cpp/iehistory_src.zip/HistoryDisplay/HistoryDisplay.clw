; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CHistoryListCtrl
LastTemplate=CListCtrl
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "HistoryDisplay.h"

ClassCount=3
Class1=CHistoryDisplayApp
Class2=CHistoryDisplayDlg

ResourceCount=2
Resource1=IDR_MAINFRAME
Class3=CHistoryListCtrl
Resource2=IDD_HISTORYDISPLAY_DIALOG

[CLS:CHistoryDisplayApp]
Type=0
HeaderFile=HistoryDisplay.h
ImplementationFile=HistoryDisplay.cpp
Filter=N

[CLS:CHistoryDisplayDlg]
Type=0
HeaderFile=HistoryDisplayDlg.h
ImplementationFile=HistoryDisplayDlg.cpp
Filter=D
BaseClass=CDialog
VirtualFilter=dWC
LastObject=IDC_LIST



[DLG:IDD_HISTORYDISPLAY_DIALOG]
Type=1
Class=CHistoryDisplayDlg
ControlCount=1
Control1=IDC_LIST,SysListView32,1350631425

[CLS:CHistoryListCtrl]
Type=0
HeaderFile=HistoryListCtrl.h
ImplementationFile=HistoryListCtrl.cpp
BaseClass=CListCtrl
Filter=W
VirtualFilter=FWC
LastObject=CHistoryListCtrl

