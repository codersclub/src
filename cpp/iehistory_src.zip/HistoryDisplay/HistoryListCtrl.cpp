// HistoryListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "HistoryDisplay.h"
#include "HistoryListCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CHistoryListCtrl

CHistoryListCtrl::CHistoryListCtrl()
{
}

CHistoryListCtrl::~CHistoryListCtrl()
{
}


BEGIN_MESSAGE_MAP(CHistoryListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CHistoryListCtrl)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CHistoryListCtrl message handlers

void CHistoryListCtrl::Add(CIEUrl &url)
{
	CListControlItem Title(0,0,url.strTitle);
	CListControlItem Url(0,1,url.strUrl);
	CString lastVisited = url.odtLastVisited.Format("%X %x");
	CListControlItem LastAccess(0,2,lastVisited);

	InsertItem(Title);
	SetItem(Url);
	SetItem(LastAccess);
}

void CHistoryListCtrl::Init()
{
	InsertColumn(0,"Title",LVCFMT_LEFT,200);
	InsertColumn(1,"Url",LVCFMT_LEFT,200);
	InsertColumn(2,"Last Access",LVCFMT_LEFT,110);
}
