// PictureShowView.h : interface of the CPictureShowView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_PICTURESHOWVIEW_H__4C81406C_4468_482C_BABE_53F0AB916641__INCLUDED_)
#define AFX_PICTURESHOWVIEW_H__4C81406C_4468_482C_BABE_53F0AB916641__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CPictureShowView : public CScrollView
{
protected: // create from serialization only
	CPictureShowView();
	DECLARE_DYNCREATE(CPictureShowView)

// Attributes
public:
	CPictureShowDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPictureShowView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	int     m_DeltaX;
	int     m_DeltaY;

	int     m_Magnify;
	int     m_ScrollKeySpeed;

	bool    m_FitToScreen;
	bool	m_ViewFirst;
	bool	m_ViewForward;

	CString m_FileName;

	CRect   m_ClientRect;
	CSize   m_ScrollSizeTotal; // Set Scrollers According To Picture Dimentions

	virtual ~CPictureShowView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CPictureShowView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnOptionsFittoscreen();
	afx_msg void OnUpdateOptionsFittoscreen(CCmdUI* pCmdUI);
	afx_msg void OnButtonMagnify();
	afx_msg void OnButtonDiminish();
	afx_msg void OnOptionsAssociatefileextentions();
	afx_msg void OnButtonFittoscreen();
	afx_msg void OnButtonPrev();
	afx_msg void OnButtonNext();
	afx_msg void OnUpdateButtonNext(CCmdUI* pCmdUI);
	afx_msg void OnUpdateButtonPrev(CCmdUI* pCmdUI);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	afx_msg void OnHelpHomepage();
	afx_msg void OnOptionsFitborderstopicture();
	afx_msg void OnOptionsNextpicture();
	afx_msg void OnOptionsPreviouspicture();
	//}}AFX_MSG

	// Support The New Status Indicator (Must Be Outside The AFX Message MAP...)
	afx_msg void OnIndicatorInfo(CCmdUI *pCmdUI);

	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in PictureShowView.cpp
inline CPictureShowDoc* CPictureShowView::GetDocument()
   { return (CPictureShowDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PICTURESHOWVIEW_H__4C81406C_4468_482C_BABE_53F0AB916641__INCLUDED_)
