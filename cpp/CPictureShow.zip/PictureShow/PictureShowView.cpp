// PictureShowView.cpp : implementation of the CPictureShowView class
//

#include "stdafx.h"
#include "MainFrm.h"
#include "PictureShow.h"
#include "PictureShowDoc.h"
#include "PictureShowView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView

IMPLEMENT_DYNCREATE(CPictureShowView, CScrollView)

BEGIN_MESSAGE_MAP(CPictureShowView, CScrollView)
	//{{AFX_MSG_MAP(CPictureShowView)
	ON_WM_ERASEBKGND()
	ON_WM_KEYDOWN()
	ON_COMMAND(ID_OPTIONS_FITTOSCREEN, OnOptionsFittoscreen)
	ON_UPDATE_COMMAND_UI(ID_OPTIONS_FITTOSCREEN, OnUpdateOptionsFittoscreen)
	ON_COMMAND(ID_BUTTON_MAGNIFY, OnButtonMagnify)
	ON_COMMAND(ID_BUTTON_DIMINISH, OnButtonDiminish)
	ON_COMMAND(ID_OPTIONS_ASSOCIATEFILEEXTENTIONS, OnOptionsAssociatefileextentions)
	ON_COMMAND(ID_BUTTON_FITTOSCREEN, OnButtonFittoscreen)
	ON_COMMAND(ID_BUTTON_PREV, OnButtonPrev)
	ON_COMMAND(ID_BUTTON_NEXT, OnButtonNext)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_NEXT, OnUpdateButtonNext)
	ON_UPDATE_COMMAND_UI(ID_BUTTON_PREV, OnUpdateButtonPrev)
	ON_WM_LBUTTONDBLCLK()
	ON_COMMAND(ID_HELP_HOMEPAGE, OnHelpHomepage)
	ON_COMMAND(ID_OPTIONS_FITBORDERSTOPICTURE, OnOptionsFitborderstopicture)
	ON_COMMAND(ID_OPTIONS_NEXTPICTURE, OnOptionsNextpicture)
	ON_COMMAND(ID_OPTIONS_PREVIOUSPICTURE, OnOptionsPreviouspicture)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CScrollView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CScrollView::OnFilePrintPreview)

	// Support The New Status Indicator (Must Be Outside The ASX Message MAP...)
	ON_UPDATE_COMMAND_UI(ID_INDICATOR_INFO, OnIndicatorInfo)

END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView construction/destruction

//-----------------------------------------------------------------------------
CPictureShowView::CPictureShowView()
//=============================================================================
{
	m_ViewFirst = TRUE; // Until Changed...
	m_FitToScreen = FALSE;
	m_Magnify = 0;
	m_ScrollKeySpeed = 50 * 4;
}

//-----------------------------------------------------------------------------
CPictureShowView::~CPictureShowView()
//=============================================================================
{
}

//-----------------------------------------------------------------------------
BOOL CPictureShowView::PreCreateWindow(CREATESTRUCT& cs)
//=============================================================================
{
	return CScrollView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView drawing

//-----------------------------------------------------------------------------
void CPictureShowView::OnDraw(CDC* pDC)
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();

	// Check If a Picture File Was Opened
	if(pDoc->m_FilePathName != pDoc->m_FilePathNameLast)
		{
		m_Magnify = 0;
		m_FitToScreen = FALSE;
		// Update Title With FileName For Both Cases...
		m_FileName.Format("%s", pDoc->FileNameOnly(pDoc->m_FilePathName));
		pDoc->SetTitle(m_FileName); // Put Only The File Name On Title...
		if(pDoc->m_Picture.Load(pDoc->m_FilePathName)) // Load Picture Succeeded
			{
			pDoc->m_FilePathName = "";
			pDoc->m_FilePathNameLast = "";
			OnOptionsFitborderstopicture();
			Invalidate(TRUE);
			}
		else // Load Picture Failed
			{
			pDoc->m_FilePathName = "";
			pDoc->m_FilePathNameLast = "";
			pDoc->m_Picture.Load(IDR_DEFAULT, "JPG");
			OnOptionsFitborderstopicture(); // Show Here So It Will Appear
			Invalidate(TRUE);               // Before The Message Box...
			HWND hWnd = AfxGetApp()->GetMainWnd()->m_hWnd;
			MessageBoxEx(hWnd, "Picture data is not a known picture type\t\t\n(.BMP .DIB .EMF .GIF .ICO .JPG .WMF)\t\t\n(Default picture restored)\n\nFile may be CORRUPTED or MISSING\nFiles list of current directory was ReCreated\t", "Can not load picture", MB_OK | MB_ICONSTOP, LANG_ENGLISH);
			pDoc->SetTitle("Default"); // Set Default Title As We Load The Default Picture...
			// Try To Loading a "Good" Picture...
			if((m_ViewForward || m_ViewFirst) && (pDoc->m_FilesListPos != pDoc->m_FilesListCount)) OnButtonNext();
			else OnButtonPrev();
			}
		}
	else // Check If It Is The First Entry - Put Some "Default" Stuff
	if(m_ViewFirst)
		{
		if(m_FileName.IsEmpty()) pDoc->SetTitle("Default");
		OnOptionsFitborderstopicture();
		OnOptionsFitborderstopicture();
		m_ViewFirst = FALSE;
		Invalidate(TRUE);
		}
	
	GetClientRect(&m_ClientRect);
	pDoc->m_Picture.UpdateSizeOnDC(pDC); // Get Picture Dimentions In Pixels

	if(m_FitToScreen)
		{
		pDoc->m_Picture.Show(pDC, CRect(0,0, m_ClientRect.right, m_ClientRect.bottom));
		// Set Off Scrolls
		m_ScrollSizeTotal.cx = 0;
		m_ScrollSizeTotal.cy = 0;
		}
	else	
	{
	// Calculate Delta Width - To Center The Picture
	if(m_ClientRect.right - pDoc->m_Picture.m_Width > 0)
	m_DeltaX = (m_ClientRect.right - pDoc->m_Picture.m_Width)/2;
	else m_DeltaX = 0;
	// Calculate Delta Height - To Center The Picture
	if(m_ClientRect.bottom - pDoc->m_Picture.m_Height > 0)
	m_DeltaY = (m_ClientRect.bottom - pDoc->m_Picture.m_Height)/2;
	else m_DeltaY = 0;

	if(m_DeltaX + pDoc->m_Picture.m_Width*(m_Magnify+1) > m_ClientRect.right)
		{
		m_DeltaX = (m_ClientRect.right - pDoc->m_Picture.m_Width*(m_Magnify+1))/2;
		m_DeltaY = (m_ClientRect.bottom - pDoc->m_Picture.m_Height*(m_Magnify+1))/2;
		}

	if(m_Magnify >= 0) // Magnify Or Set Original Picture Dimentions
		{
		// Calculate New Dimentions For ScrollView
		m_ScrollSizeTotal.cx = pDoc->m_Picture.m_Width*(m_Magnify+1)-2;
		m_ScrollSizeTotal.cy = pDoc->m_Picture.m_Height*(m_Magnify+1)-2;
		// Center Picture (If We Have Enough Space)
		if(m_ClientRect.right - m_ScrollSizeTotal.cx <= 0) m_DeltaX = 0;
		if(m_ClientRect.bottom - m_ScrollSizeTotal.cy <= 0) m_DeltaY = 0;
		pDoc->m_Picture.Show(pDC, CPoint(m_DeltaX,m_DeltaY), CPoint(pDoc->m_Picture.m_Width, pDoc->m_Picture.m_Height), m_Magnify,m_Magnify);
		}
	else // Diminish Picture Dimentions
		{
		// Calculate New Dimentions For ScrollView
		m_ScrollSizeTotal.cx = pDoc->m_Picture.m_Width/(abs(m_Magnify-1));
		m_ScrollSizeTotal.cy = pDoc->m_Picture.m_Height/(abs(m_Magnify-1));
		// Center Picture (If We Have Enough Space)
		if(m_ClientRect.right - m_ScrollSizeTotal.cx > 1)
		m_DeltaX = (m_ClientRect.right - pDoc->m_Picture.m_Width/(abs(m_Magnify-1)))/2;
		else m_DeltaX = 0;
		if(m_ClientRect.bottom - m_ScrollSizeTotal.cy > 1)
		m_DeltaY = (m_ClientRect.bottom - pDoc->m_Picture.m_Height/(abs(m_Magnify-1)))/2;
		else m_DeltaY = 0;
		pDoc->m_Picture.Show(pDC, CRect(m_DeltaX,m_DeltaY, m_DeltaX + m_ScrollSizeTotal.cx, m_DeltaY + m_ScrollSizeTotal.cy));
		}
	} // !FitToScreen

	SetScrollSizes(MM_TEXT, m_ScrollSizeTotal);

}

//-----------------------------------------------------------------------------
void CPictureShowView::OnInitialUpdate()
//=============================================================================
{
	CScrollView::OnInitialUpdate();

	CPictureShowDoc* pDoc = GetDocument();

	CSize sizeTotal;
	sizeTotal.cx = pDoc->m_Picture.m_Width;
	sizeTotal.cy = pDoc->m_Picture.m_Height;
	SetScrollSizes(MM_TEXT, sizeTotal);
}

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView printing

//-----------------------------------------------------------------------------
BOOL CPictureShowView::OnPreparePrinting(CPrintInfo* pInfo)
//=============================================================================
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
//=============================================================================
{
	// TODO: add extra initialization before printing
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
//=============================================================================
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView diagnostics

#ifdef _DEBUG
//-----------------------------------------------------------------------------
void CPictureShowView::AssertValid() const
//=============================================================================
{
	CScrollView::AssertValid();
}

//-----------------------------------------------------------------------------
void CPictureShowView::Dump(CDumpContext& dc) const
//=============================================================================
{
	CScrollView::Dump(dc);
}

//-----------------------------------------------------------------------------
CPictureShowDoc* CPictureShowView::GetDocument() // non-debug version is inline
//=============================================================================
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CPictureShowDoc)));
	return (CPictureShowDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CPictureShowView message handlers

//-----------------------------------------------------------------------------
BOOL CPictureShowView::OnEraseBkgnd(CDC* pDC)
//=============================================================================
{
	if(m_FitToScreen)
	{
	// Do Nothing Coz We Cover All Client Area...
	}
	else // FitToScreen = TRUE
	{	
	CPictureShowDoc* pDoc = GetDocument();
	CRect ClientRect;
	GetClientRect(&ClientRect);
	COLORREF BackgroundColor = RGB(0,0,0);
	CBrush BackgroundBrush(BackgroundColor);
	pDC->SelectObject(BackgroundBrush);
	pDC->FillSolidRect(CRect(0,0,ClientRect.right,ClientRect.bottom), BackgroundColor);
	} // FitToScreen = FALSE

//////////////////////////////////////////////////////////////////////////
// ToDo: Create An OffScreen DC And Update The Background OffScreen     //
//       To Allow Resizing The Window With No Flickering (Blinking)     //
//		 (Just Have No Time 4 This - Please Send Me Some Working Stuff) //
//////////////////////////////////////////////////////////////////////////
/*	// Erase Background - But Keep Picture In The Middle...
	if(ClientRect.right - pDoc->m_Picture.m_Width > 0) // Top
	pDC->FillSolidRect(CRect(
			0,
			0,
			ClientRect.right,
			m_DeltaY), BackgroundColor);
	
	if(ClientRect.right - pDoc->m_Picture.m_Width > 1) // Bottom
	pDC->FillSolidRect(CRect(
			0,
			m_DeltaY + pDoc->m_Picture.m_Height,
			ClientRect.right,
			ClientRect.bottom), BackgroundColor);

	if(ClientRect.right - pDoc->m_Picture.m_Width > 0) // Left
	pDC->FillSolidRect(CRect(
			0,
			m_DeltaY,
			m_DeltaX,
			m_DeltaY + pDoc->m_Picture.m_Height), BackgroundColor);

	if(ClientRect.right - pDoc->m_Picture.m_Width > 1) // Right
	pDC->FillSolidRect(CRect(
			m_DeltaX + pDoc->m_Picture.m_Width,
			m_DeltaY,  
			ClientRect.right,
			m_DeltaY + pDoc->m_Picture.m_Height), BackgroundColor);

*/

//	return CScrollView::OnEraseBkgnd(pDC);
	return(TRUE);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();
	CMainFrame* pMFrm = (CMainFrame*)AfxGetMainWnd();

	switch(nChar)
	{
	case 27: // Escape
		{
		if((m_Magnify || m_FitToScreen != FALSE || pMFrm->m_FullScreen) != 0)
			{ 
			m_Magnify = 0;
			m_FitToScreen = FALSE;
			if(pMFrm->m_FullScreen) pMFrm->OnOptionsFullscreen();
			}
		else PostMessage(WM_QUIT, 0, 0);

		Invalidate();
		break;
		}

	case 106: // "*"
		{
		OnOptionsFittoscreen();
		break;
		}

	case 107: // "+" if(nChar == 109 || nChar ==189)
		{
		OnButtonMagnify();
		break;
		}
	case 109: // "-" if(nChar == 109 || nChar ==189)
		{
		OnButtonDiminish();
		break;
		}

	case 38: // Up
		{ 
		CPoint CurrentScroll = GetDeviceScrollPosition();
		ScrollToPosition(CPoint(CurrentScroll.x, CurrentScroll.y - m_ScrollKeySpeed));
		break;
		}
	case 40: // Down
		{ 
		CPoint CurrentScroll = GetDeviceScrollPosition();
		if(m_DeltaY == 0) // Genius !!! - Scrool Only When Picture Has No Free Space
		ScrollToPosition(CPoint(CurrentScroll.x, CurrentScroll.y + m_ScrollKeySpeed));
		break;
		}
	case 37: // Left
		{
		CPoint CurrentScroll = GetDeviceScrollPosition();
		ScrollToPosition(CPoint(CurrentScroll.x - m_ScrollKeySpeed, CurrentScroll.y));
		break;
		}
	case 39: // Right
		{ 
		CPoint CurrentScroll = GetDeviceScrollPosition();
		if(m_DeltaX == 0) // Genius !!! - Scrool Only When Picture Has No Free Space
		ScrollToPosition(CPoint(CurrentScroll.x + m_ScrollKeySpeed, CurrentScroll.y));
		break;
		}
	case 36: // Home
		{ 
		CPoint CurrentScroll = GetDeviceScrollPosition();
		ScrollToPosition(CPoint(CurrentScroll.x, 0));
		break;
		}
	case 35: // End
		{ 
		CPoint CurrentScroll = GetDeviceScrollPosition();
		ScrollToPosition(CPoint(CurrentScroll.x, pDoc->m_Picture.m_Height*(m_Magnify+1)));
		break;
		}
	case 33: // PgUp
		{
		OnButtonPrev();
		break;
		}
	case 34: // PgDn
		{ 
		OnButtonNext();
		break;
		}
  
	} // switch...

	CScrollView::OnKeyDown(nChar, nRepCnt, nFlags);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnOptionsFittoscreen() 
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();

	m_FitToScreen = m_FitToScreen ? FALSE : TRUE;

	pDoc->UpdateAllViews(NULL);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnUpdateOptionsFittoscreen(CCmdUI* pCmdUI) 
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();
//	m_FitToScreen ? pCmdUI->SetCheck(1) : pCmdUI->SetCheck(0);
	m_FitToScreen ? pCmdUI->SetText("Maintain aspect ratio (1:1)\t *") : pCmdUI->SetText("Fit picture to screen\t *");
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnButtonMagnify() 
//=============================================================================
{
	if(m_FitToScreen)
		{
		HWND hWnd = AfxGetApp()->GetMainWnd()->m_hWnd;
		MessageBoxEx(hWnd, "You are on a\"Fit to screen\" mode\t\nPlease switch to a normal (1:1) aspect ratio\t", "Attention", MB_OK | MB_ICONINFORMATION, LANG_ENGLISH);
		}
	else if(m_Magnify < 50) { m_Magnify++; Invalidate(); }
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnButtonDiminish()
//=============================================================================
{
	if(m_FitToScreen)
		{
		HWND hWnd = AfxGetApp()->GetMainWnd()->m_hWnd;
		MessageBoxEx(hWnd, "You are on a\"Fit to screen\" mode\t\nPlease switch to a normal (1:1) aspect ratio\t", "Attention", MB_OK | MB_ICONINFORMATION, LANG_ENGLISH);
		}
	else 
	if(m_Magnify > -50) { m_Magnify--; Invalidate(); }
}

#include "AssociationsDlg.h"
//-----------------------------------------------------------------------------
void CPictureShowView::OnOptionsAssociatefileextentions() 
//=============================================================================
{
	CAssociationsDlg AssociationsDlg;
	AssociationsDlg.DoModal();
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnButtonFittoscreen() 
//=============================================================================
{
	OnOptionsFittoscreen(); // Just Do The Same...
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnIndicatorInfo(CCmdUI *pCmdUI)
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();

	CString sPictureInfo = "";
	sPictureInfo.Format(" %4d x %4d (%dKb) ", pDoc->m_Picture.m_Width, pDoc->m_Picture.m_Height, pDoc->m_Picture.m_Weight/1024);

	pCmdUI->SetText(sPictureInfo);
}


//-----------------------------------------------------------------------------
void CPictureShowView::OnButtonPrev() 
//=============================================================================
{
	m_ViewForward = FALSE;

	CPictureShowDoc* pDoc = GetDocument();

	if(pDoc->m_FilesListPos > 1)
		{
		pDoc->m_FilesListPos--;
		pDoc->m_FilesList.GetPrev(pDoc->m_FilesListPosition);

		pDoc->m_FilePathName.Format("%s", pDoc->m_FilesList.GetAt(pDoc->m_FilesListPosition));
		pDoc->UpdateAllViews(NULL);

		//CString S;
		//S.Format("Number = %d, \"%s\"", m_FilesListPos, m_FilesList.GetAt(m_FilesListPosition));
		//AfxMessageBox(S);
		}
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnButtonNext() 
//=============================================================================
{
	m_ViewForward = TRUE;

	CPictureShowDoc* pDoc = GetDocument();

	if(pDoc->m_FilesListPos < pDoc->m_FilesListCount)
		{
		pDoc->m_FilesListPos++;
		pDoc->m_FilesList.GetNext(pDoc->m_FilesListPosition);

		pDoc->m_FilePathName.Format("%s", pDoc->m_FilesList.GetAt(pDoc->m_FilesListPosition));
		pDoc->UpdateAllViews(NULL);

		//CString S;
		//S.Format("Number = %d, \"%s\"", m_FilesListPos, m_FilesList.GetAt(m_FilesListPosition));
		//AfxMessageBox(S);
		}
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnUpdateButtonNext(CCmdUI* pCmdUI) 
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();

	if(!(pDoc->m_FilesListPos < pDoc->m_FilesListCount)) pCmdUI->Enable(FALSE);
	else pCmdUI->Enable(TRUE);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnUpdateButtonPrev(CCmdUI* pCmdUI) 
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();

	if(!(pDoc->m_FilesListPos > 1)) pCmdUI->Enable(FALSE);
	else pCmdUI->Enable(TRUE);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnLButtonDblClk(UINT nFlags, CPoint point) 
//=============================================================================
{
	CMainFrame* pMFrm = (CMainFrame*)AfxGetMainWnd();

	pMFrm->OnButtonFullscreen();

	CScrollView::OnLButtonDblClk(nFlags, point);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnHelpHomepage() 
//=============================================================================
{
	ShellExecute(NULL, "open", "http://www.SuperMain.com", NULL, NULL, SW_SHOWNORMAL); 
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnOptionsFitborderstopicture()
//=============================================================================
{
	CPictureShowDoc* pDoc = GetDocument();
	CMainFrame* pMFrm = (CMainFrame*)AfxGetMainWnd();

	// Hay You - If U Have The Time, Get "Bar" Sizes Properly And Send Me The Final Code
	int Borders_Width = 6; // Each Border Sides = 6 (Left And Right)
	int ToolBars_Height = 47; // Height Of Both ToolBar And StatusBar;

	int DesktopWidth  = GetSystemMetrics(SM_CXSCREEN);
	int DesktopHeight = GetSystemMetrics(SM_CYSCREEN);

	CRect GlobalWnd; // Will Include The LocalWnd At The Center
    CRect ToolBarRect;
	pMFrm->m_WndToolBar.GetClientRect(&ToolBarRect);
	ToolBars_Height = ToolBarRect.Height() - 1;

	if(pMFrm->m_WndToolBar.IsFloating()) ToolBars_Height = ToolBars_Height / 2 - 1;

    CRect StatusBarRect;
	pMFrm->m_WndStatusBar.GetClientRect(&StatusBarRect);
	ToolBars_Height += StatusBarRect.Height() + 7;

	if(!pMFrm->m_WndStatusBar.IsWindowVisible()) ToolBars_Height -= (StatusBarRect.Height() -7 -1);

	CRect LocalWnd(0,
				   0,
				   pDoc->m_Picture.m_Width + Borders_Width*2,
				   pDoc->m_Picture.m_Height + ToolBars_Height*2);

	// Make Width At Least The Size Of The ToolBar
	if(LocalWnd.Width() < ToolBarRect.Width())
	   LocalWnd.InflateRect(0, 0, ToolBarRect.Width() - pDoc->m_Picture.m_Width + Borders_Width, 0);

	GlobalWnd.left = (DesktopWidth - LocalWnd.right)/2;
	GlobalWnd.top = (DesktopHeight - LocalWnd.bottom)/2;
	GlobalWnd.right= LocalWnd.right + GlobalWnd.left;
	GlobalWnd.bottom = LocalWnd.bottom + GlobalWnd.top;

	// Cut Extra Space When Needed...
	if(GlobalWnd.top < 0) GlobalWnd.top = 0;
	if(GlobalWnd.left < 0) GlobalWnd.left = 0;
	if(GlobalWnd.bottom > DesktopHeight) GlobalWnd.bottom = GetSystemMetrics(SM_CYMAXIMIZED);
	if(GlobalWnd.right > DesktopWidth) GlobalWnd.right = GetSystemMetrics(SM_CXMAXIMIZED);
	
	WINDOWPLACEMENT WP;
	WP.rcNormalPosition = GlobalWnd;
	WP.showCmd = SW_SHOW;
	pMFrm->SetWindowPlacement(&WP);
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnOptionsNextpicture() 
//=============================================================================
{
	OnButtonNext();
}

//-----------------------------------------------------------------------------
void CPictureShowView::OnOptionsPreviouspicture() 
//=============================================================================
{
	OnButtonPrev();
}
