// MainFrm.cpp : implementation of the CMainFrame class
//

#include "stdafx.h"
#include "MainFrm.h"
#include "PictureShow.h"

#include "PictureShowDoc.h"
#include "PictureShowView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_COMMAND(ID_OPTIONS_FULLSCREEN, OnOptionsFullscreen)
	ON_WM_GETMINMAXINFO()
	ON_COMMAND(ID_BUTTON_FULLSCREEN, OnButtonFullscreen)
	ON_COMMAND(ID_BUTTON_FULLSCREEN_FLOAT, OnButtonFullscreenFloat)
	//}}AFX_MSG_MAP

END_MESSAGE_MAP()

static UINT indicators[] =
{
//	ID_SEPARATOR,           // status line indicator
	ID_INDICATOR_INFO,
//	ID_INDICATOR_NUM,
//	ID_INDICATOR_CAPS,
};

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

//-----------------------------------------------------------------------------
CMainFrame::CMainFrame()
//=============================================================================
{
	m_FullScreen = FALSE;
}

//-----------------------------------------------------------------------------
CMainFrame::~CMainFrame()
//=============================================================================
{
}

//-----------------------------------------------------------------------------
int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
//=============================================================================
{

	if (CFrameWnd::OnCreate(lpCreateStruct) == -1) return -1;

	if (!m_WndToolBar.CreateEx(this, TBSTYLE_FLAT, WS_CHILD | WS_VISIBLE | CBRS_TOP
		| CBRS_GRIPPER | CBRS_TOOLTIPS | CBRS_FLYBY | CBRS_SIZE_DYNAMIC) ||
		!m_WndToolBar.LoadToolBar(IDR_MAINFRAME))
		{
		TRACE0("Failed to create toolbar\n");
		return -1;      // fail to create
		}

	if (!m_WndStatusBar.Create(this) ||
		!m_WndStatusBar.SetIndicators(indicators,
		  sizeof(indicators)/sizeof(UINT)))
		{
		TRACE0("Failed to create status bar\n"); 
		return -1;      // fail to create
		}

	// Delete these three lines if you don't want the toolbar to be dockable
	m_WndToolBar.EnableDocking(CBRS_ALIGN_ANY);
	EnableDocking(CBRS_ALIGN_ANY);
	DockControlBar(&m_WndToolBar);

	return 0;

}

//-----------------------------------------------------------------------------
// This Has To Be Improved - Guess I Just Had No Time To Do It The Right Way...
//-----------------------------------------------------------------------------
BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
//=============================================================================
{
	int DesktopWidth  = GetSystemMetrics(SM_CXSCREEN);
	int DesktopHeight = GetSystemMetrics(SM_CYSCREEN);

	// Just Make It Small So We Will Not Feel a "Blink"
	CRect MainWindow_Rect(0,0, 100, 100); // First Opening Screen

	cs.x = (DesktopWidth - MainWindow_Rect.right)/2;
	cs.y = (DesktopHeight - MainWindow_Rect.bottom)/2;

    cs.cx = MainWindow_Rect.right;
	cs.cy = MainWindow_Rect.bottom;

	return CFrameWnd::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
//-----------------------------------------------------------------------------
void CMainFrame::AssertValid() const
//=============================================================================
{
	CFrameWnd::AssertValid();
}

//-----------------------------------------------------------------------------
void CMainFrame::Dump(CDumpContext& dc) const
//=============================================================================
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

//-----------------------------------------------------------------------------
//
// (This Function Is Based On The Article On Microsoft)
// "Adding a Full Screen Feature to an MFC Application (Q164162)"
//
//-----------------------------------------------------------------------------
void CMainFrame::OnOptionsFullscreen()
//=============================================================================
{
	RECT DesktopRect;
    WINDOWPLACEMENT WPNew;

	m_FullScreen = m_FullScreen ? TRUE : FALSE;

    if(!m_FullScreen)
	    {
        // need to hide all status bars
        m_WndStatusBar.ShowWindow(SW_HIDE);
	    m_WndToolBar.ShowWindow(SW_HIDE);

	    // We'll need these to restore the original state.
	    GetWindowPlacement (&m_WPPrev);

	    m_WPPrev.length = sizeof m_WPPrev;

        //Adjust RECT to new size of window
	    ::GetWindowRect(::GetDesktopWindow(), &DesktopRect);

		DesktopRect.left -= 1;
		DesktopRect.top -= 1;
		DesktopRect.bottom += 2;
		DesktopRect.right += 2;

	    ::AdjustWindowRectEx(&DesktopRect, GetStyle(), TRUE, GetExStyle());

	    // Remember this for OnGetMinMaxInfo()
	    m_FullScreenWindowRect = DesktopRect;
        
        WPNew = m_WPPrev;
        WPNew.showCmd =  SW_SHOWNORMAL;
	    WPNew.rcNormalPosition = DesktopRect;
	    
        m_pWndFullScreenBar=new CToolBar;

        if(!m_pWndFullScreenBar->Create(this,CBRS_SIZE_DYNAMIC|CBRS_FLOATING) ||
	       !m_pWndFullScreenBar->LoadToolBar(IDR_FULLSCREEN))
    		{
	    	TRACE0("Failed to create toolbar\n");
			return; // fail to create
	        }
        
        //don't allow the toolbar to dock
        m_pWndFullScreenBar->EnableDocking(0);
		m_pWndFullScreenBar->SetWindowPos(0, 0,0, 0,0,SWP_NOSIZE|SWP_NOZORDER|SWP_NOACTIVATE|SWP_SHOWWINDOW);
		m_pWndFullScreenBar->SetWindowText(_T("Hold Ctrl+F to switch between normal and a full screen"));
		FloatControlBar(m_pWndFullScreenBar, CPoint(0,0));
		m_pWndFullScreenBar->EnableToolTips(TRUE);
		m_FullScreen=TRUE;
	    }
    else
	    {
        m_pWndFullScreenBar->DestroyWindow();
		delete m_pWndFullScreenBar;

        m_FullScreen=FALSE;

        m_WndStatusBar.ShowWindow(SW_SHOWNORMAL);
	    m_WndToolBar.ShowWindow(SW_SHOWNORMAL);
        WPNew = m_WPPrev;
	    }
    
    SetWindowPlacement(&WPNew);
}

//-----------------------------------------------------------------------------
void CMainFrame::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
//=============================================================================
{
	if(m_FullScreen)
	    {
	    lpMMI->ptMaxSize.y = m_FullScreenWindowRect.Height();
	    lpMMI->ptMaxTrackSize.y = lpMMI->ptMaxSize.y;
	    lpMMI->ptMaxSize.x = m_FullScreenWindowRect.Width();
	    lpMMI->ptMaxTrackSize.x = lpMMI->ptMaxSize.x;
	    }

// CFrameWnd::OnGetMinMaxInfo(lpMMI);
}

//-----------------------------------------------------------------------------
void CMainFrame::OnButtonFullscreen() 
//=============================================================================
{
	OnOptionsFullscreen();
}

//-----------------------------------------------------------------------------
void CMainFrame::OnButtonFullscreenFloat() 
//=============================================================================
{
	OnOptionsFullscreen();
}


