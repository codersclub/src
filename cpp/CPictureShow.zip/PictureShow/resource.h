//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PictureShow.rc
//
#define IDR_MAINFRAME                   11
#define IDI_BMP                         12
#define IDI_DIB                         13
#define IDI_EMF                         14
#define IDI_GIF                         15
#define IDI_ICO                         16
#define IDI_JPG                         17
#define IDI_WMF                         18
#define IDD_ABOUTBOX                    100
#define IDR_DEFAULT                     130
#define IDD_ASSOCIATIONS                131
#define IDR_FULLSCREEN                  145
#define IDC_CHECK_JPG                   1000
#define IDC_BUTTON_ASSOCIATE            1001
#define IDC_CHECK_BMP                   1002
#define IDC_CHECK_DIB                   1003
#define IDC_CHECK_EMF                   1004
#define IDC_CHECK_GIF                   1005
#define IDC_CHECK_ICO                   1006
#define IDC_CHECK_WMF                   1007
#define IDC_CHECK_ALL                   1009
#define IDC_EDIT_ABOUT                  1011
#define IDC_BUTTON_CLEAR                1012
#define ID_OPTIONS_FITTOSCREEN          32771
#define ID_BUTTON_DIMINISH              32775
#define ID_BUTTON_MAGNIFY               32776
#define ID_OPTIONS_ASSOCIATEFILEEXTENTIONS 32777
#define ID_BUTTON_FITTOSCREEN           32778
#define ID_BUTTON_PREV                  32785
#define ID_BUTTON_NEXT                  32786
#define ID_OPTIONS_FULLSCREEN           32787
#define ID_BUTTON_FULLSCREEN            32805
#define ID_BUTTON_FULLSCREEN_FLOAT      32808
#define ID_HELP_WEBPAGE                 32809
#define ID_HELP_HOMEPAGE                32810
#define ID_TEST_FITBORDERS              32811
#define ID_OPTIONS_FITBORDERSTOPICTURE  32812
#define ID_OPTIONS_NEXTPICTURE          32813
#define ID_OPTIONS_                     32814
#define ID_OPTIONS_PREVIOUSPICTURE      32814
#define ID_INDICATOR_INFO               59142

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        153
#define _APS_NEXT_COMMAND_VALUE         32815
#define _APS_NEXT_CONTROL_VALUE         1013
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
