// ReadMib.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "ReadMib.h"
#include "ReadMibDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReadMibApp

BEGIN_MESSAGE_MAP(CReadMibApp, CWinApp)
	//{{AFX_MSG_MAP(CReadMibApp)
	//}}AFX_MSG
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReadMibApp construction

CReadMibApp::CReadMibApp()
{
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CReadMibApp object

CReadMibApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CReadMibApp initialization

BOOL CReadMibApp::InitInstance()
{
	// Standard initialization

	CReadMibDlg dlg;
	m_pMainWnd = &dlg;
	int nResponse = dlg.DoModal();
	if (nResponse == IDOK)
	{
	}
	else if (nResponse == IDCANCEL)
	{
	}

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
