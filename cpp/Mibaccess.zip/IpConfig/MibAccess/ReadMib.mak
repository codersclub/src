# Microsoft Developer Studio Generated NMAKE File, Format Version 4.20
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

!IF "$(CFG)" == ""
CFG=ReadMib - Win32 Debug
!MESSAGE No configuration specified.  Defaulting to ReadMib - Win32 Debug.
!ENDIF 

!IF "$(CFG)" != "ReadMib - Win32 Release" && "$(CFG)" !=\
 "ReadMib - Win32 Debug"
!MESSAGE Invalid configuration "$(CFG)" specified.
!MESSAGE You can specify a configuration when running NMAKE on this makefile
!MESSAGE by defining the macro CFG on the command line.  For example:
!MESSAGE 
!MESSAGE NMAKE /f "ReadMib.mak" CFG="ReadMib - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "ReadMib - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "ReadMib - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 
!ERROR An invalid configuration is specified.
!ENDIF 

!IF "$(OS)" == "Windows_NT"
NULL=
!ELSE 
NULL=nul
!ENDIF 
################################################################################
# Begin Project
RSC=rc.exe
MTL=mktyplib.exe
CPP=cl.exe

!IF  "$(CFG)" == "ReadMib - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Target_Dir ""
OUTDIR=.\Release
INTDIR=.\Release

ALL : "$(OUTDIR)\ReadMib.exe"

CLEAN : 
	-@erase "$(INTDIR)\MibAccess.obj"
	-@erase "$(INTDIR)\ReadMib.obj"
	-@erase "$(INTDIR)\ReadMib.pch"
	-@erase "$(INTDIR)\ReadMib.res"
	-@erase "$(INTDIR)\ReadMibDlg.obj"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(OUTDIR)\ReadMib.exe"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
CPP_PROJ=/nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)/ReadMib.pch" /Yu"stdafx.h" /Fo"$(INTDIR)/"\
 /c 
CPP_OBJS=.\Release/
CPP_SBRS=.\.
# ADD BASE MTL /nologo /D "NDEBUG" /win32
# ADD MTL /nologo /D "NDEBUG" /win32
MTL_PROJ=/nologo /D "NDEBUG" /win32 
# ADD BASE RSC /l 0x40d /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x40d /d "NDEBUG" /d "_AFXDLL"
RSC_PROJ=/l 0x40d /fo"$(INTDIR)/ReadMib.res" /d "NDEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/ReadMib.bsc" 
BSC32_SBRS= \
	
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 /nologo /subsystem:windows /machine:I386
LINK32_FLAGS=/nologo /subsystem:windows /incremental:no\
 /pdb:"$(OUTDIR)/ReadMib.pdb" /machine:I386 /out:"$(OUTDIR)/ReadMib.exe" 
LINK32_OBJS= \
	"$(INTDIR)\MibAccess.obj" \
	"$(INTDIR)\ReadMib.obj" \
	"$(INTDIR)\ReadMib.res" \
	"$(INTDIR)\ReadMibDlg.obj" \
	"$(INTDIR)\StdAfx.obj" \
	".\Snmp.lib" \
	"H:\Msdev\Lib\Wsock32.lib"

"$(OUTDIR)\ReadMib.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Target_Dir ""
OUTDIR=.\Debug
INTDIR=.\Debug

ALL : "$(OUTDIR)\ReadMib.exe" "$(OUTDIR)\ReadMib.bsc"

CLEAN : 
	-@erase "$(INTDIR)\MibAccess.obj"
	-@erase "$(INTDIR)\MibAccess.sbr"
	-@erase "$(INTDIR)\ReadMib.obj"
	-@erase "$(INTDIR)\ReadMib.pch"
	-@erase "$(INTDIR)\ReadMib.res"
	-@erase "$(INTDIR)\ReadMib.sbr"
	-@erase "$(INTDIR)\ReadMibDlg.obj"
	-@erase "$(INTDIR)\ReadMibDlg.sbr"
	-@erase "$(INTDIR)\StdAfx.obj"
	-@erase "$(INTDIR)\StdAfx.sbr"
	-@erase "$(INTDIR)\vc40.idb"
	-@erase "$(INTDIR)\vc40.pdb"
	-@erase "$(OUTDIR)\ReadMib.bsc"
	-@erase "$(OUTDIR)\ReadMib.exe"
	-@erase "$(OUTDIR)\ReadMib.ilk"
	-@erase "$(OUTDIR)\ReadMib.pdb"

"$(OUTDIR)" :
    if not exist "$(OUTDIR)/$(NULL)" mkdir "$(OUTDIR)"

# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /FR /Yu"stdafx.h" /c
CPP_PROJ=/nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_AFXDLL" /D "_MBCS" /FR"$(INTDIR)/" /Fp"$(INTDIR)/ReadMib.pch"\
 /Yu"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c 
CPP_OBJS=.\Debug/
CPP_SBRS=.\Debug/
# ADD BASE MTL /nologo /D "_DEBUG" /win32
# ADD MTL /nologo /D "_DEBUG" /win32
MTL_PROJ=/nologo /D "_DEBUG" /win32 
# ADD BASE RSC /l 0x40d /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x40d /d "_DEBUG" /d "_AFXDLL"
RSC_PROJ=/l 0x40d /fo"$(INTDIR)/ReadMib.res" /d "_DEBUG" /d "_AFXDLL" 
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
BSC32_FLAGS=/nologo /o"$(OUTDIR)/ReadMib.bsc" 
BSC32_SBRS= \
	"$(INTDIR)\MibAccess.sbr" \
	"$(INTDIR)\ReadMib.sbr" \
	"$(INTDIR)\ReadMibDlg.sbr" \
	"$(INTDIR)\StdAfx.sbr"

"$(OUTDIR)\ReadMib.bsc" : "$(OUTDIR)" $(BSC32_SBRS)
    $(BSC32) @<<
  $(BSC32_FLAGS) $(BSC32_SBRS)
<<

LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386
# ADD LINK32 /nologo /subsystem:windows /debug /machine:I386
LINK32_FLAGS=/nologo /subsystem:windows /incremental:yes\
 /pdb:"$(OUTDIR)/ReadMib.pdb" /debug /machine:I386 /out:"$(OUTDIR)/ReadMib.exe" 
LINK32_OBJS= \
	"$(INTDIR)\MibAccess.obj" \
	"$(INTDIR)\ReadMib.obj" \
	"$(INTDIR)\ReadMib.res" \
	"$(INTDIR)\ReadMibDlg.obj" \
	"$(INTDIR)\StdAfx.obj" \
	".\Snmp.lib" \
	"H:\Msdev\Lib\Wsock32.lib"

"$(OUTDIR)\ReadMib.exe" : "$(OUTDIR)" $(DEF_FILE) $(LINK32_OBJS)
    $(LINK32) @<<
  $(LINK32_FLAGS) $(LINK32_OBJS)
<<

!ENDIF 

.c{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_OBJS)}.obj:
   $(CPP) $(CPP_PROJ) $<  

.c{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cpp{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

.cxx{$(CPP_SBRS)}.sbr:
   $(CPP) $(CPP_PROJ) $<  

################################################################################
# Begin Target

# Name "ReadMib - Win32 Release"
# Name "ReadMib - Win32 Debug"

!IF  "$(CFG)" == "ReadMib - Win32 Release"

!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"

!ENDIF 

################################################################################
# Begin Source File

SOURCE=.\ReadMib.cpp
DEP_CPP_READM=\
	".\ReadMib.h"\
	".\ReadMibDlg.h"\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "ReadMib - Win32 Release"


"$(INTDIR)\ReadMib.obj" : $(SOURCE) $(DEP_CPP_READM) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"


"$(INTDIR)\ReadMib.obj" : $(SOURCE) $(DEP_CPP_READM) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"

"$(INTDIR)\ReadMib.sbr" : $(SOURCE) $(DEP_CPP_READM) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\ReadMibDlg.cpp
DEP_CPP_READMI=\
	".\MibAccess.h"\
	".\ReadMib.h"\
	".\ReadMibDlg.h"\
	".\snmp.h"\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "ReadMib - Win32 Release"


"$(INTDIR)\ReadMibDlg.obj" : $(SOURCE) $(DEP_CPP_READMI) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"


"$(INTDIR)\ReadMibDlg.obj" : $(SOURCE) $(DEP_CPP_READMI) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"

"$(INTDIR)\ReadMibDlg.sbr" : $(SOURCE) $(DEP_CPP_READMI) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\StdAfx.cpp
DEP_CPP_STDAF=\
	".\StdAfx.h"\
	

!IF  "$(CFG)" == "ReadMib - Win32 Release"

# ADD CPP /Yc"stdafx.h"

BuildCmds= \
	$(CPP) /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D\
 "_AFXDLL" /D "_MBCS" /Fp"$(INTDIR)/ReadMib.pch" /Yc"stdafx.h" /Fo"$(INTDIR)/"\
 /c $(SOURCE) \
	

"$(INTDIR)\StdAfx.obj" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\ReadMib.pch" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"

# ADD CPP /Yc"stdafx.h"

BuildCmds= \
	$(CPP) /nologo /MDd /W3 /Gm /GX /Zi /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS"\
 /D "_AFXDLL" /D "_MBCS" /FR"$(INTDIR)/" /Fp"$(INTDIR)/ReadMib.pch"\
 /Yc"stdafx.h" /Fo"$(INTDIR)/" /Fd"$(INTDIR)/" /c $(SOURCE) \
	

"$(INTDIR)\StdAfx.obj" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\StdAfx.sbr" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

"$(INTDIR)\ReadMib.pch" : $(SOURCE) $(DEP_CPP_STDAF) "$(INTDIR)"
   $(BuildCmds)

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\ReadMib.rc
DEP_RSC_READMIB=\
	".\res\ReadMib.ico"\
	".\res\ReadMib.rc2"\
	

"$(INTDIR)\ReadMib.res" : $(SOURCE) $(DEP_RSC_READMIB) "$(INTDIR)"
   $(RSC) $(RSC_PROJ) $(SOURCE)


# End Source File
################################################################################
# Begin Source File

SOURCE=.\MibAccess.cpp
DEP_CPP_MIBAC=\
	".\MibAccess.h"\
	

!IF  "$(CFG)" == "ReadMib - Win32 Release"


"$(INTDIR)\MibAccess.obj" : $(SOURCE) $(DEP_CPP_MIBAC) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"


"$(INTDIR)\MibAccess.obj" : $(SOURCE) $(DEP_CPP_MIBAC) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"

"$(INTDIR)\MibAccess.sbr" : $(SOURCE) $(DEP_CPP_MIBAC) "$(INTDIR)"\
 "$(INTDIR)\ReadMib.pch"


!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=.\Snmp.lib

!IF  "$(CFG)" == "ReadMib - Win32 Release"

!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"

!ENDIF 

# End Source File
################################################################################
# Begin Source File

SOURCE=H:\Msdev\Lib\Wsock32.lib

!IF  "$(CFG)" == "ReadMib - Win32 Release"

!ELSEIF  "$(CFG)" == "ReadMib - Win32 Debug"

!ENDIF 

# End Source File
# End Target
# End Project
################################################################################
