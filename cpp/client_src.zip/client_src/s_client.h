// s_client.h : main header file for the S_CLIENT application
//

#if !defined(AFX_S_CLIENT_H__7E477283_93F1_11D4_8163_CAFF6EB92413__INCLUDED_)
#define AFX_S_CLIENT_H__7E477283_93F1_11D4_8163_CAFF6EB92413__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CS_clientApp:
// See s_client.cpp for the implementation of this class
//

class CS_clientApp : public CWinApp
{
public:
	CS_clientApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CS_clientApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CS_clientApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_S_CLIENT_H__7E477283_93F1_11D4_8163_CAFF6EB92413__INCLUDED_)
