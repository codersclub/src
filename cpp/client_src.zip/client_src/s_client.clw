; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CS_clientDlg
LastTemplate=CAsyncSocket
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "s_client.h"

ClassCount=4
Class1=CS_clientApp
Class2=CS_clientDlg
Class3=CAboutDlg

ResourceCount=4
Resource1=IDD_ABOUTBOX (English (U.S.))
Resource2=IDR_MAINFRAME
Resource3=IDD_S_CLIENT_DIALOG
Class4=MySocket
Resource4=IDD_S_CLIENT_DIALOG (English (U.S.))

[CLS:CS_clientApp]
Type=0
HeaderFile=s_client.h
ImplementationFile=s_client.cpp
Filter=N

[CLS:CS_clientDlg]
Type=0
HeaderFile=s_clientDlg.h
ImplementationFile=s_clientDlg.cpp
Filter=D
LastObject=IDC_EDIT1
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=s_clientDlg.h
ImplementationFile=s_clientDlg.cpp
Filter=D

[DLG:IDD_S_CLIENT_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CS_clientDlg

[DLG:IDD_S_CLIENT_DIALOG (English (U.S.))]
Type=1
Class=CS_clientDlg
ControlCount=9
Control1=IDC_CONNECT,button,1342242816
Control2=IDC_STATIC,static,1342308352
Control3=IDC_SEND,button,1342242817
Control4=IDC_MESSAGE,edit,1350631552
Control5=IDC_STATIC,static,1342308352
Control6=IDC_ANSWER,edit,1344344260
Control7=IDC_STATIC,static,1342308352
Control8=IDC_EDIT1,edit,1350631552
Control9=IDC_EDIT2,edit,1350631552

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[CLS:MySocket]
Type=0
HeaderFile=MySocket.h
ImplementationFile=MySocket.cpp
BaseClass=CAsyncSocket
Filter=N
VirtualFilter=q
LastObject=MySocket

