// bitmapDoc.h : interface of the CBitmapDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_BITMAPDOC_H__24181DF1_46D3_4B8E_9921_BB922ECE25D5__INCLUDED_)
#define AFX_BITMAPDOC_H__24181DF1_46D3_4B8E_9921_BB922ECE25D5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CBitmapDoc : public CDocument
{
protected: // create from serialization only
	CBitmapDoc();
	DECLARE_DYNCREATE(CBitmapDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBitmapDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CBitmapDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CBitmapDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_BITMAPDOC_H__24181DF1_46D3_4B8E_9921_BB922ECE25D5__INCLUDED_)
