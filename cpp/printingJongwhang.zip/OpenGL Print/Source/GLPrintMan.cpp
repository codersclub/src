// GLPrintMan.cpp: implementation of the CGLPrintMan class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "GLPrintMan.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CGLPrintMan::CGLPrintMan()
{
	m_hDib=NULL; // device independent bitmap
	m_pBitmapBuffer=NULL; // set up memory pointer
}


CGLPrintMan::~CGLPrintMan()
{

}


void CGLPrintMan::EnableOpenGL(CRect paper, HWND hWnd, HDC * hDC, HGLRC * hRC )
{
	try {
	// prepare bitmap
	m_pBitmapBuffer=NULL; // buffer to store bitmap (RGB, RGB , RGB etc..)

	// First of all, initialize the bitmap header information...
	memset(&m_BitmapInfo, 0, sizeof(BITMAPINFO));
	m_BitmapInfo.bmiHeader.biSize		= sizeof(BITMAPINFOHEADER);
	m_BitmapInfo.bmiHeader.biWidth		= paper.Width();
	m_BitmapInfo.bmiHeader.biHeight		= paper.Height();
	m_BitmapInfo.bmiHeader.biPlanes		= 1;
	m_BitmapInfo.bmiHeader.biBitCount		= 24;
	m_BitmapInfo.bmiHeader.biCompression	= BI_RGB;
	m_BitmapInfo.bmiHeader.biSizeImage	= m_BitmapInfo.bmiHeader.biWidth * m_BitmapInfo.bmiHeader.biHeight * 3;

	// create Device Independent Bitmap (containing full RGB information regardless of graphic system)
	HDC hTmpDC;
	hTmpDC=::GetDC(hWnd);
	m_hDib= CreateDIBSection(hTmpDC, &m_BitmapInfo, DIB_RGB_COLORS, &m_pBitmapBuffer, NULL, (DWORD) 0);
	::ReleaseDC(hWnd, hTmpDC);
	// now, we got bitmap to draw , buffer is pBitmapBuffer


	// create memory device context
	*hDC=CreateCompatibleDC( GetDC(hWnd));
	if (*hDC==NULL) throw "CreateCompatibleDC: Error";
	
	// connect memeory device context with bitmap
	if (SelectObject(*hDC, m_hDib)==NULL) throw "SelectObject: Error" ;


	// now, we got bitmap and corresponding device context


	PIXELFORMATDESCRIPTOR pfd;
	int iFormat;

	// set the pixel format for the DC
	ZeroMemory( &pfd, sizeof( pfd ) );
	pfd.nSize = sizeof( pfd );
	pfd.nVersion = 1;
	pfd.dwFlags = PFD_DRAW_TO_BITMAP | PFD_SUPPORT_OPENGL | PFD_STEREO_DONTCARE;
	pfd.iPixelType = PFD_TYPE_RGBA;
	pfd.cColorBits = 24;
	pfd.cDepthBits = 16;
	pfd.iLayerType = PFD_MAIN_PLANE;

	iFormat = ChoosePixelFormat( *hDC, &pfd );
	SetPixelFormat( *hDC, iFormat, &pfd );

	// create and enable the render context (RC)
	*hRC = wglCreateContext( *hDC );
	wglMakeCurrent( *hDC, *hRC );
	int error=glGetError();

	//gl setting
	glDrawBuffer(GL_BACK);
	glEnable(GL_LIGHTING);
	glEnable(GL_DEPTH_TEST);
	glShadeModel(GL_SMOOTH);
	glEnable(GL_NORMALIZE);
	glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);
	glEnable(GL_CULL_FACE);
	}
	catch (char* error) {
		AfxMessageBox(error);
	}

}



VOID CGLPrintMan::DisableOpenGL( HWND hWnd, HDC hDC, HGLRC hRC )
{

	if (m_pBitmapBuffer) delete m_pBitmapBuffer;

	DeleteObject(m_hDib); // delete DIB
	wglMakeCurrent( NULL, NULL );
	wglDeleteContext( hRC );
	ReleaseDC( hWnd, hDC );
  
}
