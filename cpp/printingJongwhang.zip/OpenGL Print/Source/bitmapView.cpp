
#include "stdafx.h"
#include "bitmap.h"

#include "bitmapDoc.h"
#include "bitmapView.h"
#include <afxpriv.h>		// to see the CPreviewDC structure

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#include "glprintman.h"


IMPLEMENT_DYNCREATE(CBitmapView, CView)

BEGIN_MESSAGE_MAP(CBitmapView, CView)
	//{{AFX_MSG_MAP(CBitmapView)
	ON_COMMAND(ID_SAVE_SCREEN, OnSaveScreen)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CView::OnFilePrintPreview)
END_MESSAGE_MAP()


CBitmapView::CBitmapView()
{
	// TODO: add construction code here

}

CBitmapView::~CBitmapView()
{
}

BOOL CBitmapView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView drawing

void CBitmapView::OnDraw(CDC* pDC)
{
	CBitmapDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView printing

BOOL CBitmapView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CBitmapView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CBitmapView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

/////////////////////////////////////////////////////////////////////////////
// CBitmapView diagnostics

#ifdef _DEBUG
void CBitmapView::AssertValid() const
{
	CView::AssertValid();
}

void CBitmapView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CBitmapDoc* CBitmapView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CBitmapDoc)));
	return (CBitmapDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CBitmapView message handlers

void CBitmapView::OnSaveScreen() 
{
	CRect paper(0,0,2000,1000);
	double width=paper.Width();
	double height=paper.Height();

	CGLPrintMan print;
	print.EnableOpenGL(paper,GetSafeHwnd(), &print.m_hDC, &print.m_hRC);
	
	print.StartUpdate();
	
	print.KeepAspectRatio(width,height);
    glViewport(0,0,width,height);
	glDrawBuffer(GL_FRONT);

	print.SetViewVolume();
	glGetIntegerv(GL_VIEWPORT, print.m_nvVP);

	// draw
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	{
		glClearColor(1,1,1,0);
		glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT | 
		GL_STENCIL_BUFFER_BIT);

		glDisable(GL_LIGHTING);
		glEnable(GL_COLOR_MATERIAL);
		glColor3d(0,0,0);
		glutSolidSphere(10, 10,10);
	}


	// save
	print.SaveBitmap("screen.bmp");



	
	print.EndUpdate();
}

void CBitmapView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	CRect paper(0,0,0,0);
	
	// get size of paper..
	if (pInfo->m_bPreview) // it's preview..
	{
		PRINTDLG PrtDlg;	// Printer dialog
		if (!AfxGetApp()->GetPrinterDeviceDefaults(&PrtDlg))
		{
			if (pDC->IsKindOf(RUNTIME_CLASS(CPreviewDC))) 
			{
				CPreviewDC *pPrevDC = (CPreviewDC *)pDC;
				//m_hAttribDC hold the print/fax DC so...
				paper.right =  GetDeviceCaps(pPrevDC->m_hAttribDC, HORZRES);
				paper.bottom = GetDeviceCaps(pPrevDC->m_hAttribDC, VERTRES);
			}
		}
		else
		{
			CPrintDialog dlg(FALSE);

			dlg.m_pd.hDevMode  = PrtDlg.hDevMode;
			dlg.m_pd.hDevNames = PrtDlg.hDevNames;

			HDC hdc = dlg.CreatePrinterDC();

			// Get the size of the default printer page
			paper.right  = GetDeviceCaps(hdc, HORZRES);
			paper.bottom = GetDeviceCaps(hdc, VERTRES);

			// Free the device context
			DeleteDC(hdc);
		}

	}
	else { // print to paper
		paper.right  = GetDeviceCaps(pDC->GetSafeHdc(), HORZRES);
		paper.bottom = GetDeviceCaps(pDC->GetSafeHdc(), VERTRES);
	}

	pDC->RoundRect(0,0, paper.right, paper.bottom, 10, 10);

	//////////////////////////////////////////////////////////////////////////////
	double ar=(double)paper.Width()/(double)paper.Height();

	CRect gl_paper(0,0,1000*ar,1000);
	int width=((int)(gl_paper.Width()/4))*4;
	int height=gl_paper.Height();

	CGLPrintMan print;
	print.EnableOpenGL(gl_paper,GetSafeHwnd(), &print.m_hDC, &print.m_hRC);
	
	print.StartUpdate();
	
	print.KeepAspectRatio(width,height);
    glViewport(0,0,width,height);
	glDrawBuffer(GL_FRONT);

	print.SetViewVolume();
	glGetIntegerv(GL_VIEWPORT, print.m_nvVP);

	// draw
	glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);
	{
		glClearColor(1,1,1,0);
		glClear(GL_DEPTH_BUFFER_BIT | GL_COLOR_BUFFER_BIT | 
		GL_STENCIL_BUFFER_BIT);

		glDisable(GL_LIGHTING);
		glEnable(GL_COLOR_MATERIAL);
		glColor3d(1,0,0);
		glutSolidSphere(5, 20,20 );
	}


	// transper to printer
	{
		HDC hdc;
		HBITMAP bitmap;

		hdc	= CreateCompatibleDC(pDC->GetSafeHdc());
		bitmap = CreateDIBitmap(hdc, &(print.m_BitmapInfo.bmiHeader),
						CBM_INIT,
						(GLubyte*)print.m_pBitmapBuffer,
						&print.m_BitmapInfo,
						DIB_RGB_COLORS);
		
		HGDIOBJ oldbitmap = SelectObject(hdc, bitmap);
		BOOL bRet = StretchBlt(pDC->GetSafeHdc(),
							  0,0 , // offset 
							   paper.Width(), paper.Height(),// paper
							   print.m_hDC,
							   0, 0,
								print. m_BitmapInfo.bmiHeader.biWidth,
							   print.m_BitmapInfo.bmiHeader.biHeight,
							   SRCCOPY);
		if (oldbitmap != NULL)
			SelectObject(hdc, oldbitmap);

		// Free our bitmap and bitmap device context
		DeleteObject(bitmap);
		DeleteDC(hdc);
	}

	print.EndUpdate();
	print.DisableOpenGL(GetSafeHwnd(), print.m_hDC, print.m_hRC);
	

	////////////////////////////////////////////////////////////////////////////////

	CView::OnPrint(pDC, pInfo);
}
