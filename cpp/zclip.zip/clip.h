
void ClipObjectFor(Obj *obj);

void ClipObject(Obj *obj);
void ClipObjectFake(Obj *obj);

void ClipObject1(Obj *obj);



