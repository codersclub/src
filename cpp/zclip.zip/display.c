#include <windows.h>
#include "main.h"
#include "gl.h"



HDC		ghDC;
HGLRC	ghRC;	/* opengl context */





void objDisplayObj(Obj *obj)
{
	int i;
	static float color;
	static long *pindex;
	static Vector *pout;
	pout = obj->pout;

	glBegin(GL_TRIANGLES);

	for (i=0;i<obj->nbface_vis;i++)
	{
		pindex = obj->fvisible[i]->p;
		color = obj->fvisible[i]->color;

		glColor3f (color, color, color); 
		glVertex3f(pout[pindex[0]].x, pout[pindex[0]].y, pout[pindex[0]].ooz);

		glColor3f (color, color, color); 
		glVertex3f(pout[pindex[1]].x, pout[pindex[1]].y, pout[pindex[1]].ooz);

		glColor3f (color, color, color); 
		glVertex3f(pout[pindex[2]].x, pout[pindex[2]].y, pout[pindex[2]].ooz);

	}

	glEnd();

}


void oglBufferClear()
{
	glClear( GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT );
}


void oglBufferSwap()
{
	SwapBuffers( ghDC );
}



BOOL oglSetupPixelFormat(HDC hdc)
{ 
    PIXELFORMATDESCRIPTOR *ppfd;
    int pixelformat; 
 
	PIXELFORMATDESCRIPTOR pfd = {
    sizeof(PIXELFORMATDESCRIPTOR),  //  size of this pfd
    1,                     // version number
    PFD_DRAW_TO_WINDOW |   // support window
    PFD_SUPPORT_OPENGL |   // support OpenGL
    PFD_DOUBLEBUFFER,      // double buffered
    PFD_TYPE_RGBA,         // RGBA type
    32,                    // 32-bit color depth, was to 24
    0, 0, 0, 0, 0, 0,      // color bits ignored
    0,                     // no alpha buffer
    0,                     // shift bit ignored
    0,                     // no accumulation buffer
    0, 0, 0, 0,            // RGBA accum bits ignored
    32,                    // 32-bit z-buffer
    0,                     // no stencil buffer
    0,                     // no auxiliary buffer
    PFD_MAIN_PLANE,        // main layer
    0,                     // reserved
    0, 0, 0                // layer masks ignored
    };

 	 pfd.cColorBits = GetDeviceCaps(ghDC,BITSPIXEL);
 
	 ppfd = &pfd;

    pixelformat = ChoosePixelFormat(hdc, ppfd);
 
    if ( (pixelformat = ChoosePixelFormat(hdc, ppfd)) == 0 ) 
    {	MessageBox(NULL, "ChoosePixelFormat failed", "Error", MB_OK);
        return FALSE; 
    }
 
    if (SetPixelFormat(hdc, pixelformat, ppfd) == FALSE) 
    {	MessageBox(NULL, "SetPixelFormat failed", "Error", MB_OK);
        return FALSE; 
    } 
	
    return TRUE;
}




	
int oglInitGraph(HWND hwnd)
{
	ghDC = GetDC( hwnd);

	if (!oglSetupPixelFormat(ghDC)) 
		return 0;
	ghRC = wglCreateContext(ghDC);
	wglMakeCurrent(ghDC, ghRC);

	glOrtho(0,SCREENX,0,SCREENY, -1.0,0.0);
 
	glEnable( GL_DEPTH_TEST);		
	glDrawBuffer( GL_BACK );

	glPixelStorei(GL_PACK_ALIGNMENT,0);
	glPixelStorei(GL_UNPACK_ALIGNMENT,0);
	return 1;

	
}
