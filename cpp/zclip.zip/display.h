#ifndef DISPLAY_H
#define DISPLAY_H

#include "main.h"

void objDisplayObj(Obj *obj);
int  oglInitGraph(HWND hwnd);
void oglBufferClear();
void oglBufferSwap();



#endif //DISPLAY_H
