#ifndef MAIN_H
#define MAIN_H



#define SCREENX		640.0f
#define HALFX		320.0f
#define SCREENY		480.0f
#define HALFY		240.0f

#define NAME		"Z Clipping"
#define TITLE		"Z Clipping"



typedef struct {
	float	x,y,z;
	float	ooz;			//padding... but I use it as a ooz.
}Vector;


typedef struct {
	long	p[3];
	float	color;
}Face;


typedef float Matrix[4][4];


typedef struct {
	Vector	*plist;
	Vector	*pout;
	Vector	*nlist;
	Face	*flist;
	Face	**fvisible;

	long 	nbface;
	long 	nbface_clip;
	long	nbface_vis;
	long 	nbpt;
	long 	nbpt_clip;
	Matrix  matrix;
}Obj;

typedef struct {
	char right;	
	char left;	
	char up;	
	char down;	
	char A;	
	char Z;	
	char shift;
}Key;


#endif //MAIN_H
