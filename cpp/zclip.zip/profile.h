

//get the processor counter value
__inline void GetCycle(unsigned __int64 *t)
{
	static unsigned long time1, time2;
	__asm{
		_emit 0x0F
		_emit 0x31
		mov time1, eax
		mov time2, edx
	}
	*t = time1 + ((unsigned __int64)time2)<<32;
}
