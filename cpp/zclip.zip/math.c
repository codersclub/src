#include <math.h>
#include "main.h"






float DotProduct(Vector *vec1, Vector *vec2)
{
    return vec1->x * vec2->x +
           vec1->y * vec2->y +
           vec1->z * vec2->z;
}

void VecSub(Vector *res, Vector *vec1, Vector *vec2)
{
	res->x = vec1->x - vec2->x;
	res->y = vec1->y - vec2->y;
	res->z = vec1->z - vec2->z;
}



//----------------------------------------------------------------------------------------------
//	Matrix Math
//----------------------------------------------------------------------------------------------

void TranslationMat(Matrix m, Vector *v)

{
	m[0][0]=1;    m[0][1]=0;    m[0][2]=0;    m[0][3]=0; 
	m[1][0]=0;    m[1][1]=1;    m[1][2]=0;    m[1][3]=0; 
	m[2][0]=0;    m[2][1]=0;    m[2][2]=1;    m[2][3]=0; 
	m[3][0]=v->x; m[3][1]=v->y; m[3][2]=v->z; m[3][3]=1; 

}

void IdentityMat(Matrix m)

{
	m[0][0]=1; m[0][1]=0; m[0][2]=0; m[0][3]=0; 
	m[1][0]=0; m[1][1]=1; m[1][2]=0; m[1][3]=0; 
	m[2][0]=0; m[2][1]=0; m[2][2]=1; m[2][3]=0; 
	m[3][0]=0; m[3][1]=0; m[3][2]=0; m[3][3]=1; 

}


void MatRotX( Matrix m, float radian )
{
	float fCos = (float)cos( radian );
	float fSin = (float)sin( radian );

	m[0][0] = 1.0f;  m[0][1] = 0.0f;    m[0][2] = 0.0f;    m[0][3] = 0.0f;
	m[1][0] = 0.0f;  m[1][1] = fCos;    m[1][2] = fSin;    m[1][3] = 0.0f;
	m[2][0] = 0.0f;  m[2][1] = -fSin;   m[2][2] = fCos;    m[2][3] = 0.0f;
	m[3][0] = 0.0f;  m[3][1] = 0.0f;    m[3][2] = 0.0f;    m[3][3] = 1.0f;
}

void MatRotY( Matrix m, float radian )
{
	float fCos = (float)cos( radian );
	float fSin = (float)sin( radian );

	m[0][0] = fCos;  m[0][1] = 0.0f;    m[0][2] = -fSin;   m[0][3] = 0.0f;
	m[1][0] = 0.0f;  m[1][1] = 1.0f;    m[1][2] = 0.0f;    m[1][3] = 0.0f;
	m[2][0] = fSin;  m[2][1] = 0.0f;    m[2][2] = fCos;    m[2][3] = 0.0f;
	m[3][0] = 0.0f;  m[3][1] = 0.0f;    m[3][2] = 0.0f;    m[3][3] = 1.0f;
}

void MatRotZ( Matrix m, float radian )

{
	float fCos = (float)cos( radian );
	float fSin = (float)sin( radian );

	m[0][0] = fCos;  m[0][1] = fSin;    m[0][2] = 0.0f;    m[0][3] = 0.0f;
	m[1][0] = -fSin; m[1][1] = fCos;    m[1][2] = 0.0f;    m[1][3] = 0.0f;
	m[2][0] = 0.0f;  m[2][1] = 0.0f;    m[2][2] = 1.0f;    m[2][3] = 0.0f;
	m[3][0] = 0.0f;  m[3][1] = 0.0f;    m[3][2] = 0.0f;    m[3][3] = 1.0f;
}

void PointMatMult(Vector *vr, Vector *v, Matrix m )
{
	static Vector vTmp;
	vTmp.x = ( v->x * m[0][0] ) + ( v->y * m[1][0] ) + ( v->z * m[2][0] ) + m[3][0];
	vTmp.y = ( v->x * m[0][1] ) + ( v->y * m[1][1] ) + ( v->z * m[2][1] ) + m[3][1];
	vTmp.z = ( v->x * m[0][2] ) + ( v->y * m[1][2] ) + ( v->z * m[2][2] ) + m[3][2];
	vr->x = vTmp.x;
	vr->y = vTmp.y;
	vr->z = vTmp.z;
}


void InvPointMatMult(Vector *vr, Vector *v, Matrix m )
{
	static Vector vTmp;
	v->x -=  m[3][0];
	v->y -=  m[3][1];
	v->z -=  m[3][2];
	vTmp.x = ( v->x * m[0][0] ) + ( v->y * m[0][1] ) + ( v->z * m[0][2] );
	vTmp.y = ( v->x * m[1][0] ) + ( v->y * m[1][1] ) + ( v->z * m[1][2] );
	vTmp.z = ( v->x * m[2][0] ) + ( v->y * m[2][1] ) + ( v->z * m[2][2] );
	vr->x = vTmp.x;
	vr->y = vTmp.y;
	vr->z = vTmp.z;

}

 
//same as PointMatMult but no translation (rotation only)
void VecMatMult(Vector *r,Vector *v, Matrix m )

{
	static Vector vTmp;
	vTmp.x = ( v->x * m[0][0] ) + ( v->y * m[1][0] ) + ( v->z * m[2][0] );
	vTmp.y = ( v->x * m[0][1] ) + ( v->y * m[1][1] ) + ( v->z * m[2][1] );
	vTmp.z = ( v->x * m[0][2] ) + ( v->y * m[1][2] ) + ( v->z * m[2][2] );
	v->x = vTmp.x;
	v->y = vTmp.y;
	v->z = vTmp.z;
}

void InvVecMatMult(Vector *vr, Vector *v, Matrix m )
{
	static Vector vTmp;
	vTmp.x = ( v->x * m[0][0] ) + ( v->y * m[0][1] ) + ( v->z * m[0][2] );
	vTmp.y = ( v->x * m[1][0] ) + ( v->y * m[1][1] ) + ( v->z * m[1][2] );
	vTmp.z = ( v->x * m[2][0] ) + ( v->y * m[2][1] ) + ( v->z * m[2][2] );
	vr->x = vTmp.x;
	vr->y = vTmp.y;
	vr->z = vTmp.z;
}


void MatMult(Matrix a, Matrix b)
{
	static Matrix mTmp;
	static int i, j;
    for (j = 0; j < 3; j++) 
        for (i = 0; i < 3; i++)   
            mTmp[i][j] = a[i][0] * b[0][j] + a[i][1] * b[1][j] +
                           a[i][2] * b[2][j] + a[i][3] * b[3][j];

    for (i = 0; i < 3; i++)  
	{
		a[i][0] = mTmp[i][0];
		a[i][1] = mTmp[i][1];
		a[i][2] = mTmp[i][2];
		a[i][3] = mTmp[i][3];
	}
}
