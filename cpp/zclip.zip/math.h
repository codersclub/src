



void VecSub(Vector *res, Vector *vec1, Vector *vec2);
float DotProduct(Vector *vec1, Vector *vec2);

void TranslationMat(Matrix m, Vector *v);
void IdentityMat(Matrix m);
void MatRotX( Matrix m, float radian );
void MatRotY( Matrix m, float radian );
void MatRotZ( Matrix m, float radian );
void PointMatMult(Vector *vr, Vector *v, Matrix m );
void InvPointMatMult(Vector *vr, Vector *v, Matrix m );
void VecMatMult(Vector *r,Vector *v, Matrix m );
void InvVecMatMult(Vector *vr, Vector *v, Matrix m );
void MatMult(Matrix a, Matrix b);
