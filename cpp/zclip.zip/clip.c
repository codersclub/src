//-------------------------------------------//
//   Test of my new Z clipping algorithme
//   by: Philippe Gagnon
//   if you have any question, comment dont 
//   hesitate to ask me at pgagnon@mail.com
//-------------------------------------------//


#include "main.h"
#include "profile.h"

unsigned __int64 clip_time, clip_time1, clip_time2;



#define		SIGN	0x80000000



void ClipObject(Obj *obj)
{

	static long i,code,idx,idxp1,idxp2,idxv,topvis;
	static float  k,d1,d2,kd1,kd2;
	static	Vector *top,*p1,*p2,*p3,*plist;
	Face	*face_in,*face_out;

	int nbvis   = 0;
	int nbfclip = obj->nbface;
	int nbpclip = obj->nbpt;

	GetCycle(&clip_time1);


	plist = obj->pout;
	
	for (i=0 ; i<obj->nbface ; i++)
	{


		face_in = &obj->flist[i];

		// Create the code depending on z signs of the points
		code =	((*(unsigned long*)&plist[face_in->p[0]].z) >> 31) |
				((*((unsigned long*)&plist[face_in->p[1]].z) & SIGN) >> 29) |	
				((*((unsigned long*)&plist[face_in->p[2]].z) & SIGN) >> 30);


		obj->fvisible[nbvis] = &obj->flist[i];
		nbvis += code==0;			//inc only if all visible

		// exit if the triangle is not clipped (code==0 or code==7)
		if (!((code&3)^(code>>1)))
			continue;


		//--- here the triangle is clipped

		// With the code, figure out the top point and the two other points
		idx   = ((code ^ (code>>1)) & 0x3) - 1;
		idxp1 = ~idx & 0x1;
		idxp2 = ~idx & 0x2;

		// Setup pointers to our data
		top = &plist[face_in->p[idx]];
		p1  = &plist[face_in->p[idxp1]];
		p2  = &plist[face_in->p[idxp2]];
		
		// Calculate our common divisor
		d1   = top->z - p1->z;
		d2   = top->z - p2->z; 
		k = 1/(d1*d2) * top->z;

		
		// Adjust the divisor for each side, to create ratios
		kd1 = d2 * k;
		kd2 = d1 * k;

		// Clip the segments
		plist[nbpclip].x = top->x + (p1->x-top->x) * kd1;
		plist[nbpclip].y = top->y + (p1->y-top->y) * kd1;
		plist[nbpclip].z = 0.0f;

		plist[nbpclip+1].x = top->x + (p2->x-top->x) * kd2;
		plist[nbpclip+1].y = top->y + (p2->y-top->y) * kd2;
		plist[nbpclip+1].z = 0.0f;


		idxv = idx;
		face_out = &obj->flist[nbfclip];

		//set this face if the clip output is 2 face
		if ((*(long*)&top->z & 0x80000000))
		{

			obj->fvisible[nbvis++] = face_out;
			face_out->p[idx] = nbpclip+1;
			face_out->p[idxp1] = face_in->p[idxp1];
			face_out->p[idxp2] = face_in->p[idxp2];
			face_out->p[3]   = face_in->p[3];
			
			nbfclip++;
			idxv = idxp1;
			face_out++;

		}

		//set new face
		obj->fvisible[nbvis++] = face_out;
		face_out->p[idx] = nbpclip;
		face_out->p[idxp1] = nbpclip+1;
		face_out->p[idxp2] = face_in->p[idxv];
		face_out->p[3]     = face_in->p[3];		//the color (face.color)
		nbfclip++;

		nbpclip+=2;

		
	}
	obj->nbpt_clip = nbpclip;
	obj->nbface_vis = nbvis;


	GetCycle(&clip_time2);
	clip_time = clip_time2-clip_time1;
	
}


void ClipObjectFake(Obj *obj)
{
	static long	i;
	GetCycle(&clip_time1);

	
	for (i=0 ; i<obj->nbface ; i++)
	{
		obj->fvisible[i] = &obj->flist[i];
	}
	obj->nbpt_clip = obj->nbpt;
	obj->nbface_vis = obj->nbface;

	GetCycle(&clip_time2);
	clip_time = clip_time2-clip_time1;

}


