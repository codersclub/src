//   Small and basic one weekend engine. 
//   by: Philippe Gagnon
//   if you have any question, comment dont 
//   hesitate to ask me at pgagnon@mail.com
//-------------------------------------------//



#include <windows.h>
#include <sys/timeb.h>
#include <time.h>
#include "display.h"
#include "main.h"
#include "math.h"
#include "clip.h"
#include <stdio.h>


extern unsigned __int64 clip_time;

HWND	hwnd;	
HWND	hwndDebug;
HWND	hwndStatus;
Key		key;

long FAR PASCAL WindowProc( HWND hWnd, UINT message, 
			    WPARAM wParam, LPARAM lParam )
{
	

    switch( message )
    {   
		case WM_PAINT:
		break;
		case WM_CREATE:
		break;
    case WM_KEYDOWN: 
		switch( wParam )
		{
			case VK_SHIFT:
				key.shift = 1;
			break;
			case 'A':
				key.A = 1;
			break;
			case 'Z':
				key.Z = 1;
			break;
			case VK_DOWN:
				key.down = 1;
			break;
			case VK_UP:
				key.up = 1;
			break;
			case VK_LEFT:
				key.left = 1;
			break;
			case VK_RIGHT:
				key.right = 1;
			break;
			case VK_ESCAPE:
				PostMessage(hWnd, WM_CLOSE, 0, 0);
			break;
		}
	break;
    case WM_KEYUP:
		switch( wParam )
		{
			case VK_SHIFT:
				key.shift = 0;
			break;
			case 'A':
				key.A = 0;
			break;
			case 'Z':
				key.Z = 0;
			break;
			case VK_DOWN:
				key.down = 0;
			break;
			case VK_UP:
				key.up = 0;
			break;
			case VK_LEFT:
				key.left = 0;
			break;
			case VK_RIGHT:
				key.right = 0;
			break;
		}
	break;
		case WM_DESTROY:
			PostQuitMessage( 0 );
		break;
    }
	
    return DefWindowProc(hWnd, message, wParam, lParam);

}


int InitWin( HINSTANCE hInstance, int nCmdShow )
{
 
	WNDCLASS	wc;

	wc.style = CS_HREDRAW | CS_VREDRAW;
	wc.lpfnWndProc = WindowProc;
	wc.cbClsExtra = 0;
	wc.cbWndExtra = 0;
	wc.hInstance = hInstance;
	wc.hIcon = LoadIcon( hInstance, IDI_APPLICATION );
	wc.hCursor = LoadCursor( NULL, IDC_ARROW );
	wc.hbrBackground = (HBRUSH)(COLOR_WINDOW+1);
	wc.lpszMenuName = NULL; 
	wc.lpszClassName = NAME;
	RegisterClass( &wc );
    
	hwnd = CreateWindowEx(
	0,
	NAME,
	TITLE,
	WS_POPUP | WS_CAPTION | WS_SYSMENU | WS_THICKFRAME,
	0,
	0,
	(int)SCREENX,
	(int)SCREENY,
	NULL,
	NULL,
	hInstance,
	NULL );

	if( !hwnd )
		return 0;

	hwndDebug = CreateWindow("static", "zzz", WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
								0, 0, (int)SCREENX,	20,	hwnd, NULL,	hInstance, NULL);

	hwndStatus = CreateWindow("static", "       Arrows, A and Z to move.             Shift + Arrows to rotate.", 
								WS_CHILD|WS_VISIBLE|BS_PUSHBUTTON,
								0, (int)SCREENY - 45, (int)SCREENX,	20,	hwnd, NULL,	hInstance, NULL);

	ShowWindow( hwnd, nCmdShow );
	UpdateWindow( hwnd );
	SetFocus(hwnd);
	return 1;
}


void DisplayInfos(Obj *obj)

{

	static long Temps;
	static long frame =0;
	static long lastframe =0;
	static OldTemps =0;
	static char text[300];
	static long back[3];
	long nbfclipped;
	char	debugstr[100];

	frame++;
	Temps = time(NULL);

	if ((Temps-OldTemps) >= 1)
	{
		lastframe = frame;
		frame = 0;
		OldTemps = Temps;
	}
	 
	nbfclipped = (obj->nbpt_clip - obj->nbpt)/2;

	if ((lastframe!=back[0]) || (back[2]!=obj->nbface_vis) || (back[3]!=nbfclipped))
	{
		sprintf( text, " FPS = %03d       nbfaces = %05d, nbface visible = %05d, nb face clipped = %05d",lastframe, obj->nbface, obj->nbface_vis,nbfclipped);
		SetWindowText(hwndDebug,text);
	}

	back[0] = lastframe;
	back[2] = obj->nbface_vis;
	back[3] = nbfclipped;

	_ui64toa(clip_time>>32,debugstr,10);
	strcat(debugstr,"\n");
	OutputDebugString(debugstr);


}



int LoadObject(Obj *obj, char* filename)
{

	FILE *pfile;
	pfile = fopen(filename, "rb");

	if (!pfile)
	{
		MessageBox(NULL, "Can't load mesh file", filename, MB_OK|MB_ICONERROR);
		return 0;
	}

	fread(&obj->nbface, 4, 1, pfile);
	fread(&obj->nbpt,   4, 1, pfile);

	obj->flist	  = (Face* )  malloc(sizeof(Face  )*obj->nbface*2);  // I multiply by 2 for the clipping buffer
	obj->fvisible = (Face**)  malloc(sizeof(Face* )*obj->nbface*2);
	obj->nlist	  = (Vector*) malloc(sizeof(Vector)*obj->nbface);
	obj->plist	  = (Vector*) malloc(sizeof(Vector)*obj->nbpt);
	obj->pout	  = (Vector*) malloc(sizeof(Vector)*obj->nbpt*2);

	fread(obj->flist, sizeof(Face)  *obj->nbface, 1 , pfile);
	fread(obj->plist, sizeof(Vector)*obj->nbpt,   1 , pfile);
	fread(obj->nlist, sizeof(Vector)*obj->nbface, 1 , pfile);

	fclose(pfile);

	// Set the object matrix
	IdentityMat(obj->matrix);
	obj->matrix[3][0] = 0;
	obj->matrix[3][1] = 0;
	obj->matrix[3][2] = 10;
	return 1;

}


void ProcessKey(Obj *obj) 
{
	static Matrix tmpmat;
	if (key.shift)
	{
		if (key.up)
		{
			MatRotX(tmpmat,0.05f);
			MatMult(obj->matrix, tmpmat);
		}
		if (key.down)
		{
			MatRotX(tmpmat,-0.05f);
			MatMult(obj->matrix, tmpmat);
		}
		if (key.left)
		{
			MatRotY(tmpmat,0.05f);
			MatMult(obj->matrix, tmpmat);
		}
		if (key.right)
		{
			MatRotY(tmpmat,-0.05f);
			MatMult(obj->matrix, tmpmat);
		}

	}
	else
	{
		if (key.A)
			obj->matrix[3][2] += 1.0f;
		if (key.Z)
			obj->matrix[3][2] -= 1.0f;
		if (key.up)
			obj->matrix[3][1] += 1.0f;
		if (key.down)
			obj->matrix[3][1] -= 1.0f;
		if (key.right)
			obj->matrix[3][0] += 1.0f;
		if (key.left)
			obj->matrix[3][0] -= 1.0f;
	}
}


void TranformObj(Obj *obj)
{
	static int i;
	for (i=0 ; i<obj->nbpt ; i++)
	{
		PointMatMult(&obj->pout[i], &obj->plist[i], obj->matrix );
	}
}

void ComputeFlat(Obj *obj)
{
	int i;
	static Vector *normal;
	static Vector light;
	light.x = 1.0f;
	light.y = 0.0f;
	light.z = 0.0f;
	InvVecMatMult(&light, &light, obj->matrix);
	normal = obj->nlist;

	for (i=0 ; i<obj->nbface ; i++)
	{
		obj->flist[i].color = (DotProduct(normal,&light) + 1.0f) * 0.5f;
		normal++;
	}
}


void ProjectObj(Obj *obj)
{
	static int i;
	static Vector *pout;

	pout = obj->pout;

	for (i=0 ; i<obj->nbpt_clip ; i++)
	{
		pout[i].ooz = 1.0f/(pout[i].z+100);
		pout[i].x = (pout[i].x*500.0f) * pout[i].ooz + HALFX;
		pout[i].y = (pout[i].y*500.0f) * pout[i].ooz + HALFY;
	}
}


int PASCAL WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,
			LPSTR lpCmdLine, int nCmdShow)
{
    MSG		msg;
	Obj		obj;

	if (!InitWin( hInstance, nCmdShow ))
		return 0;

	if (!oglInitGraph(hwnd))
		return 0;

	if (!LoadObject(&obj, "teapot.fil"))
		return 0;



	for (;;)
	{
		if( PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE ) )
		{
			if( !GetMessage( &msg, NULL, 0, 0 ) )
				return msg.wParam;
			TranslateMessage(&msg); 
			DispatchMessage(&msg);
		}
        else		
		{ 
			//---- Main loop ----
			ProcessKey(&obj);
			TranformObj(&obj);
			ComputeFlat(&obj);
//			ClipObject1(&obj);		//188045  
			ClipObject(&obj);		//193947  
//			ClipObjectFake(&obj);	// 23765
//			ClipObject(&obj);	//113299
			ProjectObj(&obj);
			DisplayInfos(&obj);
			oglBufferClear();
			objDisplayObj(&obj);
			oglBufferSwap();

		}
	}
}


