//-----------------------------------------
//  File: ConnectionPipeTest.h
//  Created by WizardCP 
//  Date (dd-mm-yyyy):  13-08-2001    Time (hh:mm):08:16
//-----------------------------------------

#define TEST_OUTPUT_BUFFER_SIZE        10240
#define TEST_INPUT_BUFFER_SIZE        10240
#define TEST_SINK_EVENT_BUFFER_SIZE        10240
#define TEST_PIPE_TIMEOUT        5000
#define TEST_BUFFER_ALLOCATION        ONE_TIME_BUFFER_ALLOCATION

//--- Structures ---------------


//------------------------------

typedef enum ID_CONNECTIONPIPE_TEST
{
  ID_METHOD1 = CPIPE_USER,
};

typedef enum ID_EVENT_TEST
{
  ID_EVENT1 = CPIPE_EVENT,
};

//-------------------------------------------------
class CConnectionPipeTracerClient;
class CConnectionPipeTestClient  : public CConnectionPipeClient
{
  public:
   CConnectionPipeTestClient()
         : CConnectionPipeClient
         (
            TEST_BUFFER_ALLOCATION,
            TEST_INPUT_BUFFER_SIZE,
            TEST_OUTPUT_BUFFER_SIZE,
            TEST_SINK_EVENT_BUFFER_SIZE,
            TEST_PIPE_TIMEOUT
         )
 {}
//------------------ Sended to Server ---------
   DWORD method1 (char* s);
//------------------ Received from Server -- (Sink) -------
   void SinkProcessing(char* chRequest,DWORD cbBytesRead,
             char* chReply,DWORD* pcbReplyBytes);
   void Sink_event1 ();
};
//-------------------------------------------------
class CConnectionPipeTestServer  : public CConnectionPipeServer
{
  public:
   CConnectionPipeTestServer( char*  PipeName_par,
      CConnectionPipeTracerClient* pConnectionPipeTracerC_p = 0,
      DWORD BufferAllocation_par        = TEST_BUFFER_ALLOCATION,
      DWORD OutputBufferSize_par        = TEST_OUTPUT_BUFFER_SIZE,
      DWORD InputBufferSize_par         = TEST_INPUT_BUFFER_SIZE,
      DWORD SinkEventBufferSize_par     = TEST_SINK_EVENT_BUFFER_SIZE,
      DWORD PipeTimeOut_par             = TEST_PIPE_TIMEOUT)
: CConnectionPipeServer(PipeName_par,
      pConnectionPipeTracerC_p,
      BufferAllocation_par,
      OutputBufferSize_par,
      InputBufferSize_par,
      SinkEventBufferSize_par,
      PipeTimeOut_par )  {}
//------------------------ Virtual Functions ----------------
// void PostCreateStep(int index);
// void Disconnection(TMP_STRUCT1* ptmp1);
//------------------------ Received from Clients ------------
   void UserProcessing (TMP_STRUCT1* ptmp1);
//------- parameter TMP_STRUCT1* ptmp from UserProcessing parameter -----
   void method1 (TMP_STRUCT1* ptmp1);
//------------------------ Sended to Clients ------------
   void Event_event1 (char* s);
};
