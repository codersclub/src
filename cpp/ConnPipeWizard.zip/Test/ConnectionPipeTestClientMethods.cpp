//-----------------------------------------
//  File: ConnectionPipeTestClientMethods.cpp
//  Created by WizardCP 
//  Date (dd-mm-yyyy):  13-08-2001    Time (hh:mm):08:16
//------------------------------------------------------
//-----Save code, that you added, in other file,--------
//-----because this file will be created repeteadly-----
//-----by WizardCP at the next time---------------------
//------------------------------------------------------

#include "StdAfx.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"
//  To add here your include files

//-----------------------------------------

DWORD CConnectionPipeTestClient::
method1(char* s)
//method1(char* s)  (sample)
{
   DWORD size;
   char* request;

  if (BufferAllocation == ONE_TIME_BUFFER_ALLOCATION)
    request = OutputString;
  else
    request = new char[InputBufferSize];
//  Add your code here:
//  size = sizeof(DWORD) +  strlen(s) + 1;    (sample)
//  strcpy(&request[sizeof(DWORD)],s);        (sample)

  BOOL fSuccess;
  DWORD cbWritten;
  DWORD* pdw = (DWORD*)request;
  *pdw = ID_METHOD1;
  fSuccess = WriteToPipe(
   hPipe,                  // pipe handle
   request,                // message
   size,                   // message length
   &cbWritten              // bytes written
     );
  if (! fSuccess)
    OutputConsole("Error:  WriteFile\n");
  if (BufferAllocation == EACH_TIME_BUFFER_ALLOCATION)
    delete request;
// here place for reply code
 return Error;
}
//-----------------------------------------
void CConnectionPipeTestClient::
Sink_event1()
{
  char* pData = SinkInputString + sizeof(DWORD);
  // parameters: char* s

//  Add your code here
}
