//-----------------------------------------
//  File: ConnectionPipeTestServerMethods.cpp
//  Created by WizardCP 
//  Date (dd-mm-yyyy):  13-08-2001    Time (hh:mm):08:16
//------------------------------------------------------
//-----Save code, that you added, in other file,--------
//-----because this file will be created repeteadly-----
//-----by WizardCP at the next time---------------------
//------------------------------------------------------

// You can use the following code as a sample for reply to Client 

//  if (BufferAllocation == ONE_TIME_BUFFER_ALLOCATION)
//     output_str = ptmp1->OutputString;
//  else
//     output_str = new char[OutputBufferSize];
//  DWORD* pID = (DWORD*)output_str;
//  char*  p = &output_str[sizeof(DWORD)];
//   theApp.m_pMainWnd->
//   *pID = CPIPE_ANSWER;
//  Prepare data for reply

//   strcpy(p, "It is reply from Server  (sample) \n");
//   cbReplyBytes = strlen(p) + 1 + sizeof(DWORD);  (sample) 
//   fSuccess = WriteToPipe(
//       ptmp1->hPipe,     // handle to pipe
//       output_str,       // buffer to write from
//       cbReplyBytes,     // number of bytes to write
//       &cbWritten);      // number of bytes written
//   if (BufferAllocation == EACH_TIME_BUFFER_ALLOCATION)
//     delete output_str;
//    if (! fSuccess || cbReplyBytes != cbWritten)
//       Disconnection(ptmp1);
//-----------------------------------------

#include "StdAfx.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"
//  To add here your include files

//-----------------------------------------

void CConnectionPipeTestServer::
method1(TMP_STRUCT1* ptmp1)
{
//  To add here your code

//  char*  input_str;
//  input_str = ptmp1->InputString + sizeof(DWORD);

//  To add here your code for reply if it is needed

}
//-----------------------------------------

void CConnectionPipeTestServer::
Event_event1(char* s)
//Event_event1(char* s)                         (sample)

{
     int i;
     CONNECTION_PIPE_DATA cpd;
     DWORD cbWritten = 0,fSuccess = 0;
     DWORD id = ID_EVENT1;


//----- Prepare here data to send to Client -------------
//char buffer[100];                              (sample)
//memcpy(buffer,(char*)&id,sizeof(id));          (sample)
//memcpy(&buffer[sizeof(id)],s,strlen(s) + 1);   (sample)

     EnterCriticalSection(&CritSectClients);
     for (i = 0;i < Clients.GetSize();i++)
     {

//----- To add here data to send to Client -------------
//parameters: char* s
     
        cpd = Clients.GetAt(i);
        fSuccess = WriteToPipe(
                      cpd.hPipeEvents,           // handle to pipe
                      (char*)&id,                // buffer to write from
                      sizeof(id),                // number of bytes to write
// 2 following lines instead of 2 previous lines as a sample
//buffer,    (sample)
//sizeof(id) + strlen(s) + 1,  (sample)

                      &cbWritten );              // number of bytes written
     }
     LeaveCriticalSection(&CritSectClients);
}
