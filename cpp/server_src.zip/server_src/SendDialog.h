#if !defined(AFX_SENDDIALOG_H__FC34E620_F795_11D4_8163_E33EC7566816__INCLUDED_)
#define AFX_SENDDIALOG_H__FC34E620_F795_11D4_8163_E33EC7566816__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SendDialog.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CSendDialog dialog

class CSendDialog : public CDialog
{
// Construction
public:
	CSendDialog(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSendDialog)
	enum { IDD = IDD_SEN_DIALOG };
	CString	m_data;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSendDialog)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSendDialog)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SENDDIALOG_H__FC34E620_F795_11D4_8163_E33EC7566816__INCLUDED_)
