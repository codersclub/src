// MyClassFactory.h: interface for the IMyClassFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCLASSFACTORY_H__A80293D8_90E4_47CD_B021_7567FEF5F637__INCLUDED_)
#define AFX_MYCLASSFACTORY_H__A80293D8_90E4_47CD_B021_7567FEF5F637__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class IMyClassFactory : public IClassFactory  
{
public:
	IMyClassFactory();
	~IMyClassFactory();

//������ IUnknown
public:
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject);
	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();
protected:
	ULONG m_nRefCount;

//������ IClassFactory
public:
	STDMETHOD(CreateInstance)(IUnknown *pUnkOuter, REFIID riid, void **ppvObject);
	STDMETHOD(LockServer)(BOOL bLock);

};

#endif // !defined(AFX_MYCLASSFACTORY_H__A80293D8_90E4_47CD_B021_7567FEF5F637__INCLUDED_)
