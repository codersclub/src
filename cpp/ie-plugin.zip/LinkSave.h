#if !defined(AFX_LINKSAVE_H__A80293D8_90A2_47CD_B021_7567FEF5F637__INCLUDED_)
#define AFX_LINKSAVE_H__A80293D8_90A2_47CD_B021_7567FEF5F637__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "resource.h"
#pragma warning (disable: 4786)

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  dwReason, LPVOID lpReserved);
STDAPI DllCanUnloadNow();
STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void ** ppvObject);
STDAPI DllRegisterServer();
STDAPI DllUnregisterServer();

inline int AfxMessageBox(HWND hWnd, LPCTSTR lpszText, UINT nType =MB_OK | MB_ICONEXCLAMATION)
{
	TCHAR appName[80];
	extern HMODULE g_hThisModule;
	LoadString(g_hThisModule, IDS_APP_NAME, appName, 80);
	return MessageBox(hWnd, lpszText, appName, nType);
}

inline int AfxMessageBox(HWND hWnd, UINT nIDPrompt, UINT nType =MB_OK | MB_ICONEXCLAMATION)
{
	TCHAR buff[_MAX_PATH];
	extern HMODULE g_hThisModule;
	LoadString(g_hThisModule, nIDPrompt, buff, _MAX_PATH);
	return AfxMessageBox(hWnd, buff, nType);
}

#define CHECK_COM_RESULT(res)	\
	if (FAILED(res))	\
		throw _com_error(res);		

#endif // !defined(AFX_LINKSAVE_H__A80293D8_90A2_47CD_B021_7567FEF5F637__INCLUDED_)
