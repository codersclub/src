// MyClassFactory.h: interface for the IMyClassFactory class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MYCLASSFACTORY_H__5F8FA8BD_4C1F_4F43_9F81_2478E0BB30DB__INCLUDED_)
#define AFX_MYCLASSFACTORY_H__5F8FA8BD_4C1F_4F43_9F81_2478E0BB30DB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
typedef std::list<TSTRING> stringList;

class IMyIEExtention :
	public IOleCommandTarget,
	public IObjectWithSite
{
public:
	IMyIEExtention();
	~IMyIEExtention();

//������ IUnknown
public:
	STDMETHOD(QueryInterface)(REFIID iid, void ** ppvObject);
	STDMETHOD_(ULONG, AddRef)();
	STDMETHOD_(ULONG, Release)();
protected:
	ULONG m_nRefCount;

//������ IOleCommandTarget
public:
	STDMETHOD(QueryStatus)(const GUID *pCmdGroup, ULONG cCmds, OLECMD prgCmds[],
							OLECMDTEXT *pCmdText);
	STDMETHOD(Exec)(const GUID *pCmdGroup, DWORD nCmdID, DWORD nCmdExecOpt,
						VARIANTARG *pvaIn, VARIANTARG *pvaOut);
protected:
	stringList m_cExtentions;

//������ IObjectWithSite
public:
	STDMETHOD(SetSite)(IUnknown *pUnkSite);
	STDMETHOD(GetSite)(REFIID riid, void **ppvSite);
protected:
	void MakeINIFilePath(LPTSTR iniPath, LPCTSTR fName);
	bool ReadINIFile(LPCTSTR fName);
	IWebBrowser2Ptr m_pWebBrowser2;

};

#endif // !defined(AFX_MYCLASSFACTORY_H__5F8FA8BD_4C1F_4F43_9F81_2478E0BB30DB__INCLUDED_)
