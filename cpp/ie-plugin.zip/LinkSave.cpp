// LinkSave.cpp : Defines the entry point for the DLL application.
//

#include "stdafx.h"
#include "LinkSave.h"
#include "MyClassFactory.h"

//���������� ����������
extern HMODULE g_hThisModule=NULL;
extern WORD g_nSrvRefCount=0;

BOOL APIENTRY DllMain(HMODULE hModule, DWORD  dwReason, LPVOID lpReserved)
{
	switch(dwReason)
	{
	case DLL_PROCESS_ATTACH:
		g_hThisModule=hModule;
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		break;
	case DLL_PROCESS_DETACH:
		break;
	}

    return TRUE;
}

STDAPI DllCanUnloadNow()
{
  if(g_nSrvRefCount)
	  return S_FALSE;
  else
	  return S_OK;
}

STDAPI DllGetClassObject(REFCLSID rclsid, REFIID riid, void ** ppvObject)
{
 	if (!ppvObject)
		return E_INVALIDARG;

	*ppvObject=NULL;
	HRESULT hr=E_FAIL;

	IMyClassFactory *pObj=new IMyClassFactory;
	if (!pObj)
		return E_OUTOFMEMORY;

	hr=pObj->QueryInterface(riid, ppvObject);
	if (FAILED(hr))
	{
		delete pObj;
		return CLASS_E_CLASSNOTAVAILABLE;
	}

	return S_OK;
}

STDAPI DllRegisterServer()
{
	LPCTSTR servName=_T("LinkSave (IE PlugIn)");
	TCHAR fileName[_MAX_PATH];
	DWORD len=GetModuleFileName(g_hThisModule, fileName, _MAX_PATH);

	HKEY hClassKey, hServKey;

	if(RegCreateKeyEx(HKEY_CLASSES_ROOT,
					_T("CLSID\\{98DBBF16-CA43-4c33-BE80-99E6694468A4}"), 0, NULL,
					0, KEY_WRITE, NULL,&hClassKey, NULL) != ERROR_SUCCESS) 
		return SELFREG_E_CLASS;

	if(RegSetValueEx(hClassKey, NULL, 0, REG_SZ, (BYTE*)servName, _tcslen(servName)+1)
					!=ERROR_SUCCESS) 
		return SELFREG_E_CLASS;

	if (RegCreateKeyEx(hClassKey, _T("InprocServer32"), 0, NULL, 0, KEY_WRITE,
						NULL, &hServKey, NULL) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;


	if (RegOpenKeyEx(hClassKey, _T("InprocServer32"), 0, KEY_WRITE, &hServKey)
						!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	RegCloseKey(hClassKey);

	if(RegSetValue(hServKey, NULL, REG_SZ, fileName, len) !=ERROR_SUCCESS) 
		return SELFREG_E_CLASS;

	RegCloseKey(hServKey);


	HKEY hPluginKey;
	TCHAR iconPath[_MAX_PATH+5];
	LPCTSTR menuText=_T("&Link Saver");

	if (RegCreateKeyEx(HKEY_CURRENT_USER, _T("Software\\Microsoft\\Internet Explorer\\")
						_T("Extensions\\{410C30C7-098A-4090-928E-F1D356D34C7F}"),
						0, NULL, 0, KEY_WRITE, NULL, &hPluginKey, NULL)
						!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	len=_stprintf(iconPath, _T("@%s,-%u"), fileName, IDS_TIP_TEXT);
	if (RegSetValueEx(hPluginKey, _T("ButtonText"), 0, REG_SZ, (BYTE*)iconPath,
						len) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	if (RegSetValueEx(hPluginKey, _T("CLSID"), 0, REG_SZ,
						(BYTE*)_T("{1FBA04EE-3024-11d2-8F1F-0000F87ABD16}"),
						39) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	if (RegSetValueEx(hPluginKey, _T("Default Visible"), 0, REG_SZ,
						(BYTE*)_T("Yes"), 4) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	if (RegSetValueEx(hPluginKey, _T("ClsidExtension"), 0, REG_SZ,
						(BYTE*)_T("{98DBBF16-CA43-4c33-BE80-99E6694468A4}"),
						39) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	len=_stprintf(iconPath, _T("%s,%u"), fileName, IDI_TBBUTTON_ACTIVE);
	if (RegSetValueEx(hPluginKey, _T("HotIcon"), 0, REG_SZ, (BYTE*)iconPath, len)
						!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	len=_stprintf(iconPath, _T("%s,%u"), fileName, IDI_TBBUTTON_DEFAULT);
	if (RegSetValueEx(hPluginKey, _T("Icon"), 0, REG_SZ, (BYTE*)iconPath, len)
						!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	if (RegSetValueEx(hPluginKey, _T("MenuText"), 0, REG_SZ, (BYTE*)menuText,
						_tcslen(menuText)) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	len=_stprintf(iconPath, _T("@%s,-%u"), fileName, IDS_TIP_TEXT);
	if (RegSetValueEx(hPluginKey, _T("MenuStatusBar"), 0, REG_SZ, (BYTE*)iconPath,
						len) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;

	RegCloseKey(hPluginKey);

	return S_OK;
}

STDAPI DllUnregisterServer()
{
	HKEY hCurrKey;
	if (RegOpenKeyEx(HKEY_CLASSES_ROOT, _T("CLSID"), 0, KEY_WRITE, &hCurrKey)
						!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	if (SHDeleteKey(hCurrKey, _T("{98DBBF16-CA43-4c33-BE80-99E6694468A4}"))
					!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	RegCloseKey(hCurrKey);

	if (RegOpenKeyEx(HKEY_CURRENT_USER, _T("Software\\Microsoft\\Internet Explorer\\")
						_T("Extensions"), 0, KEY_WRITE, &hCurrKey) != ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	if (SHDeleteKey(hCurrKey, _T("{410C30C7-098A-4090-928E-F1D356D34C7F}"))
					!= ERROR_SUCCESS)
		return SELFREG_E_CLASS;
	RegCloseKey(hCurrKey);

	return S_OK;
}