// MyClassFactory.cpp: implementation of the IMyClassFactory class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "LinkSave.h"
#include "MyIEExtention.h"

//���������� ����������
extern WORD g_nSrvRefCount;
extern HMODULE g_hThisModule;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

IMyIEExtention::IMyIEExtention()
{
	m_nRefCount=0;
}

IMyIEExtention::~IMyIEExtention()
{
	ASSERT(!m_nRefCount);
}

//////////////////////////////////////////////////////////////////////
// ������ IUnknown
//////////////////////////////////////////////////////////////////////

STDMETHODIMP IMyIEExtention::QueryInterface(REFIID iid, void ** ppvObject)
{
	if (!ppvObject)
		return E_INVALIDARG;

	*ppvObject=NULL;

	if (iid == IID_IUnknown)
		*ppvObject=this;
	else if (iid == IID_IOleCommandTarget)
		*ppvObject=(IOleCommandTarget*)this;
	else if (iid == IID_IObjectWithSite)
		*ppvObject=(IObjectWithSite*)this;

	if (*ppvObject)
	{
		AddRef();
		return S_OK;
	}

	return E_NOINTERFACE;
}

STDMETHODIMP_(ULONG) IMyIEExtention::AddRef()
{
	g_nSrvRefCount++;
	return ++m_nRefCount;
}

STDMETHODIMP_(ULONG) IMyIEExtention::Release()
{
	g_nSrvRefCount--;
	if (!--m_nRefCount)
	{
		delete this;
		return 0;
	}
	return m_nRefCount;
}

//////////////////////////////////////////////////////////////////////
// ������ IOleCommandTarget
//////////////////////////////////////////////////////////////////////

STDMETHODIMP IMyIEExtention::QueryStatus(const GUID *pCmdGroup, ULONG cCmds,
										 OLECMD prgCmds[], OLECMDTEXT *pCmdText)
{
	if (!prgCmds)
		return E_POINTER;
	ASSERT(cCmds == 1);
	if (!cCmds)
		return E_UNEXPECTED;

	BSTR url;
	HRESULT hRes=S_OK;
	hRes=m_pWebBrowser2->get_LocationURL(&url);
	CHECK_COM_RESULT(hRes)
	bstr_t pszUrl(url, false);

	LPCTSTR pExt=(LPCTSTR)pszUrl+pszUrl.length()-5;
	if (!_tcsicmp(pExt, _T(".html")) || !_tcsicmp(pExt+1, _T(".htm")))
		prgCmds[0].cmdf=OLECMDF_ENABLED;
	else
		prgCmds[0].cmdf=OLECMDF_SUPPORTED;
	
	return S_OK;
}

STDMETHODIMP IMyIEExtention::Exec(const GUID *pCmdGroup, DWORD nCmdID, DWORD nCmdExecOpt,
								  VARIANTARG *pvaIn, VARIANTARG *pvaOut)
{
	FILE *destFile=NULL;
	HRESULT hRes=S_OK;
	HWND hBrowser=NULL;
	try
	{
		long lBrowser;
		hRes=m_pWebBrowser2->get_HWND(&lBrowser);
		CHECK_COM_RESULT(hRes)
		hBrowser=(HWND)lBrowser;

		if (!m_cExtentions.size() && !ReadINIFile(_T("LinkSave")))
		{
			AfxMessageBox(hBrowser, IDS_ERR_OPEN_INI);
			return E_FAIL;
		}

		IDispatchPtr pTmpDisp;
		hRes=m_pWebBrowser2->get_Document(&pTmpDisp);
		CHECK_COM_RESULT(hRes)
		IHTMLDocument2Ptr pHTMLDoc2(pTmpDisp);

		IHTMLElementCollectionPtr pHTMLColl;
		hRes=pHTMLDoc2->get_all(&pHTMLColl);
		CHECK_COM_RESULT(hRes)

		hRes=pHTMLColl->tags(variant_t(_T("a")), &pTmpDisp);
		CHECK_COM_RESULT(hRes)
		IHTMLElementCollectionPtr pHTMLAColl=pTmpDisp;

		long numOfItems;
		hRes=pHTMLAColl->get_length(&numOfItems);
		CHECK_COM_RESULT(hRes)
		
		destFile=_tfopen(_T("links.txt"), _T("wt"));
		if (!destFile)
			throw _com_error(ERROR_TOO_MANY_OPEN_FILES);

		for (long currItem=0; currItem < numOfItems; currItem++)
		{
			hRes=pHTMLAColl->item(_variant_t(currItem), variant_t(currItem), &pTmpDisp);
			CHECK_COM_RESULT(hRes)
			IHTMLElementPtr pHTMLElement(pTmpDisp);

			_variant_t href;
			hRes=pHTMLElement->getAttribute(_bstr_t(_T("href")), 0, &href);
			CHECK_COM_RESULT(hRes)
			bstr_t bstrHref(href);

			LPCTSTR strHref=bstrHref;

			for (stringList::iterator i=m_cExtentions.begin(); i != m_cExtentions.end(); i++)
			{
				BYTE extLen=_tcslen(i->c_str())-1;
				LPCTSTR hrefExt=strHref+_tcslen(strHref)-extLen;
				if (!_tcsnicmp(hrefExt, i->c_str(), extLen))
				{
					_fputts(strHref, destFile);
					_fputtc(_T('\n'), destFile);
					break;
				}
			}
		}
	}
	catch (_com_error ce)
	{
		fclose(destFile);
		AfxMessageBox(NULL, ce.ErrorMessage(), MB_OK | MB_ICONSTOP);
		return E_FAIL;
	}

	fclose(destFile);
	AfxMessageBox(hBrowser, IDS_SAVE_OK, MB_OK | MB_ICONINFORMATION);
	return S_OK;
}

bool IMyIEExtention::ReadINIFile(LPCTSTR fName)
{
	TCHAR fPath[_MAX_PATH];
	MakeINIFilePath(fPath, fName);
	FILE *iniFile=_tfopen(fPath, _T("rt"));
	if (!iniFile)
		return false;
	TCHAR buffer[_MAX_PATH];

	while (!feof(iniFile))
	{
		_fgetts(buffer, _MAX_PATH, iniFile);
		if (_tcslen(buffer) < 1)
			continue;

		TSTRING tmp(buffer);
		m_cExtentions.push_back(tmp);
	}
	
	fclose(iniFile);
	return m_cExtentions.size() != 0;
}

//////////////////////////////////////////////////////////////////////
// ������ IObjectWithSite
//////////////////////////////////////////////////////////////////////

STDMETHODIMP IMyIEExtention::SetSite(IUnknown *pUnkSite)
{
	if (!pUnkSite)
	{
		if (m_pWebBrowser2.GetInterfacePtr())
			m_pWebBrowser2.Release();
		return S_OK;
	}

	IServiceProviderPtr pServProv(pUnkSite);
	return pServProv->QueryService(SID_SWebBrowserApp, IID_IWebBrowser2,
									(void**)&m_pWebBrowser2);
}
STDMETHODIMP IMyIEExtention::GetSite(REFIID riid, void **ppvSite)
{
	return m_pWebBrowser2->QueryInterface(riid, ppvSite);
}

void IMyIEExtention::MakeINIFilePath(LPTSTR iniPath, LPCTSTR fName)
{
	TCHAR fPath[_MAX_PATH];
	GetModuleFileName(g_hThisModule, fPath, _MAX_PATH);

	TCHAR drive[_MAX_DRIVE], dir[_MAX_DIR];
	_tsplitpath(fPath, drive, dir, NULL, NULL);

	ASSERT(iniPath);
	_tmakepath(iniPath, drive, dir, fName, _T("ini"));
}
