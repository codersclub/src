//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by LinkSave.rc
//
#define IDS_APP_NAME                    1
#define IDS_ERR_OPEN_INI                2
#define IDS_SAVE_OK                     3
#define IDS_TIP_TEXT                    4
#define IDI_TBBUTTON_ACTIVE             102
#define IDI_TBBUTTON_DEFAULT            103

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
