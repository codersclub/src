// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__A11D72BA_D779_4F87_B3CD_613C00C88407__INCLUDED_)
#define AFX_STDAFX_H__A11D72BA_D779_4F87_B3CD_613C00C88407__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


// Insert your headers here
#define WIN32_LEAN_AND_MEAN		// Exclude rarely-used stuff from Windows headers

#include <windows.h>
#include <docobj.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <mshtml.h>
#include <comdef.h>

#include <stdio.h>
#include <list>
#include <tchar.h>

#include <assert.h>
#ifdef _DEBUG
#define ASSERT(exp) assert(exp)
#else
#define ASSERT(exp) (void)0
#endif

#include <string>
#ifdef _UNICODE
#define TSTRING std::wstring
#else
#define TSTRING std::string
#endif

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__A11D72BA_D779_4F87_B3CD_613C00C88407__INCLUDED_)
