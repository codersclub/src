; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=C3dTWnd
LastTemplate=generic CWnd
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Basic.h"
LastPage=0

ClassCount=4
Class1=CBasicApp
Class2=C3dWnd
Class3=CAboutDlg

ResourceCount=2
Resource1=IDR_MAINFRAME
Class4=C3dTWnd
Resource2=IDD_ABOUTBOX

[CLS:CBasicApp]
Type=0
HeaderFile=Basic.h
ImplementationFile=Basic.cpp
Filter=N
BaseClass=CWinApp
VirtualFilter=AC
LastObject=CBasicApp

[CLS:CAboutDlg]
Type=0
HeaderFile=Basic.cpp
ImplementationFile=Basic.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[MNU:IDR_MAINFRAME]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_MRU_FILE1
Command6=ID_APP_EXIT
Command7=ID_EDIT_UNDO
Command8=ID_EDIT_CUT
Command9=ID_EDIT_COPY
Command10=ID_EDIT_PASTE
Command11=ID_APP_ABOUT
CommandCount=11

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_UNDO
Command5=ID_EDIT_CUT
Command6=ID_EDIT_COPY
Command7=ID_EDIT_PASTE
Command8=ID_EDIT_UNDO
Command9=ID_EDIT_CUT
Command10=ID_EDIT_COPY
Command11=ID_EDIT_PASTE
Command12=ID_NEXT_PANE
Command13=ID_PREV_PANE
CommandCount=13

[CLS:C3dWnd]
Type=0
HeaderFile=3dWnd.h
ImplementationFile=3dWnd.cpp
BaseClass=CWnd
Filter=W
LastObject=C3dWnd
VirtualFilter=WC

[CLS:C3dTWnd]
Type=0
HeaderFile=3dTWnd.h
ImplementationFile=3dTWnd.cpp
BaseClass=C3dWnd
Filter=W
VirtualFilter=WC
LastObject=C3dTWnd

