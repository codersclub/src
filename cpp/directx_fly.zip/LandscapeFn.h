// LandscapeFn.h: interface for the LandscapeFn class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_LANDSCAPEFN_H__08D820F1_0771_4D7D_A57E_90973645976E__INCLUDED_)
#define AFX_LANDSCAPEFN_H__08D820F1_0771_4D7D_A57E_90973645976E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class LandscapeFn  
{
public:
	LandscapeFn();
	virtual ~LandscapeFn();

};

#endif // !defined(AFX_LANDSCAPEFN_H__08D820F1_0771_4D7D_A57E_90973645976E__INCLUDED_)
