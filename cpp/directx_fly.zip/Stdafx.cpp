// stdafx.cpp : source file that includes just the standard includes
//	Basic.pch will be the pre-compiled header
//	stdafx.obj will contain the pre-compiled type information

/***********************************************************
***          LOGIX RC FLIGHT SIMULATOR v0.1              ***
***           Copyright Keir Gordon,   2000              ***
***    for more information please contact me at         ***
***                logix@ionet.net                       ***
***	                  or visit	                         ***
***	          http://logixdev.cjb.net	                 ***
***********************************************************/ 

#include "stdafx.h"

