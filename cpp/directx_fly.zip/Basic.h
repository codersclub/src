// Basic.h : main header file for the BASIC application
//

/***********************************************************
***          LOGIX RC FLIGHT SIMULATOR v0.1              ***
***           Copyright Keir Gordon,   2000              ***
***    for more information please contact me at         ***
***                logix@ionet.net                       ***
***	                  or visit	                         ***
***	          http://logixdev.cjb.net	                 ***
***********************************************************/ 
#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include <3dPlus.h>
#include "3dTWnd.h"

/////////////////////////////////////////////////////////////////////////////
// CBasicApp:
// See Basic.cpp for the implementation of this class
//

class CBasicApp : public CWinApp
{
public:
	CBasicApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CBasicApp)
	public:
	virtual BOOL InitInstance();
	virtual BOOL OnIdle(LONG lCount);




	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CBasicApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////
