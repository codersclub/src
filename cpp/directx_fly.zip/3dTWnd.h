#if !defined(AFX_3DTWND_H__11FBBDE0_F07F_11D3_B1BC_444553540000__INCLUDED_)
#define AFX_3DTWND_H__11FBBDE0_F07F_11D3_B1BC_444553540000__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// 3dTWnd.h : header file
//
/***********************************************************
***          LOGIX RC FLIGHT SIMULATOR v0.1              ***
***           Copyright Keir Gordon,   2000              ***
***    for more information please contact me at         ***
***                logix@ionet.net                       ***
***	                  or visit	                         ***
***	          http://logixdev.cjb.net	                 ***
***********************************************************/ 

/////////////////////////////////////////////////////////////////////////////
// C3dTWnd window

class C3dTWnd : public C3dWnd
{
// Construction
public:
	C3dTWnd();

// Attributes
public:
	int m_nTimer;
	C3dShape* pfs;	
	C3dScene* pscene;
	C3dShape* m_pShape;
	// Operations
	void control();
	void Motion();
	void SetScreen();
	
public:
	void C3dTWnd::OnStartTimer(int interval) ;
	void C3dTWnd::OnStopTimer() ;

	// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(C3dTWnd)
	public:
	virtual BOOL Create(LPCTSTR lpszClassName, LPCTSTR lpszWindowName, DWORD dwStyle, const RECT& rect, CWnd* pParentWnd, UINT nID, CCreateContext* pContext = NULL);

	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~C3dTWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(C3dTWnd)
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyUp(UINT nChar, UINT nRepCnt, UINT nFlags);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_3DTWND_H__11FBBDE0_F07F_11D3_B1BC_444553540000__INCLUDED_)
