// Basic.cpp : Defines the class behaviors for the application.
//

/***********************************************************
***          LOGIX RC FLIGHT SIMULATOR v0.1              ***
***           Copyright Keir Gordon,   2000              ***
***    for more information please contact me at         ***
***                logix@ionet.net                       ***
***	                  or visit	                         ***
***	          http://logixdev.cjb.net	                 ***
***********************************************************/ 

#include "stdafx.h"
#include "Basic.h"
#include <stdio.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif
MAINLOOP();
/////////////////////////////////////////////////////////////////////////////
// CBasicApp

BEGIN_MESSAGE_MAP(CBasicApp, CWinApp)
	//{{AFX_MSG_MAP(CBasicApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CBasicApp construction

CBasicApp::CBasicApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CBasicApp object

CBasicApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CBasicApp initialization

BOOL CBasicApp::InitInstance()
{

	// Create the main window
	C3dTWnd* pWnd = new C3dTWnd;
	pWnd->Create(NULL, NULL, WS_OVERLAPPEDWINDOW | WS_VISIBLE , CRect(50, 50, 400, 350), NULL , 0, NULL) ;

	m_pMainWnd = pWnd;


	// Create an initial scene we can add objects to

	pWnd->OnStartTimer(50);
	


	return TRUE;
}

BOOL CBasicApp::OnIdle(LONG lCount) 
{
	BOOL bMore = CWinApp::OnIdle(lCount);
	
	if (m_pMainWnd) {
		C3dTWnd* pWnd = (C3dTWnd*) m_pMainWnd;

		// Tell 3D window to move scene one unit,
		// and redraw window
	
		/*	if (pWnd->Update(1)) {
			bMore = TRUE;
		} */

	}
	return bMore;
}


