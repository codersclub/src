// LandscapeFn.cpp: implementation of the LandscapeFn class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "Basic.h"
#include "LandscapeFn.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

LandscapeFn::LandscapeFn()
{

}

LandscapeFn::~LandscapeFn()
{

}
