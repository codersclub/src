// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

/***********************************************************
***          LOGIX RC FLIGHT SIMULATOR v0.1              ***
***           Copyright Keir Gordon,   2000              ***
***    for more information please contact me at         ***
***                logix@ionet.net                       ***
***	                  or visit	                         ***
***	          http://logixdev.cjb.net	                 ***
***********************************************************/ 

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows 95 Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

// Multimedia header for joystick functions
#include <mmsystem.h>

// Include the headers from the DirectX SDK
#include <d3drmwin.h>			// Reality Lab definitions


