#ifndef FILEDISK_H
#define FILEDISK_H

#ifndef __T
#ifdef _NTDDK_
#define __T(x)      L ## x
#else
#define __T(x)      x
#endif /* _NTDDK_ */
#endif /* __T */

#ifndef _T
#define _T(x)       __T(x)
#endif

#ifndef MAXIMUM_FILENAME_LENGTH
#define MAXIMUM_FILENAME_LENGTH 256
#endif

#define DEVICE_DIR_NAME		_T("\\Device\\FileDisk")
#define DEVICE_NAME_PREFIX	_T("\\FileDisk")

#define IOCTL_FILEDISK_OPEN_MEDIA \
	CTL_CODE(FILE_DEVICE_DISK, 0x800, METHOD_BUFFERED, FILE_ANY_ACCESS)

#define IOCTL_FILEDISK_CLOSE_MEDIA \
	CTL_CODE(FILE_DEVICE_DISK, 0x801, METHOD_BUFFERED, FILE_ANY_ACCESS)

typedef struct _OPEN_MEDIA_INFORMATION {
	UCHAR		file_name[MAXIMUM_FILENAME_LENGTH];
	LONGLONG	file_size;
} OPEN_MEDIA_INFORMATION, *POPEN_MEDIA_INFORMATION;

#endif /* FILEDISK_H */
