/*
    This is a virtual disk driver for Windows NT and Windows 2000 that uses
    one or more files to emulate physical disks, release 4.
    Copyright (C) 1999, 2000 Bo Branten
    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.
    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

    Please send comments, corrections and contributions to bosse@acc.umu.se

    The most recent version of this program is available from:
    http://www.acc.umu.se/~bosse/

    Revision history:

    4. 2001-07-08
       Formating to FAT on Windows 2000 now works.

    3. 2001-05-14
       Corrected the error messages from the usermode control application.

    2. 2000-03-15
       Added handling of IOCTL_DISK_CHECK_VERIFY to make the driver work on
       Windows 2000 (tested on beta 3, build 2031). Formating to FAT still
       doesn't work but formating to NTFS does.

    1. 1999-06-09
       Initial release.
*/

#include <ntddk.h>
#include <ntdddisk.h>
#include "filedisk.h"

#define PARAMETER_KEY           L"\\Parameters"

#define NUMBEROFDEVICES_VALUE   L"NumberOfDevices"

#define DEFAULT_NUMBEROFDEVICES 4

#define SECTOR_SIZE             512

HANDLE dir_handle;

typedef struct _DEVICE_EXTENSION {
    BOOLEAN                 media_in_device;
    UNICODE_STRING          file_name;
    HANDLE                  file_handle;
    DISK_GEOMETRY           disk_geometry;
    PARTITION_INFORMATION   partition_information;
    LIST_ENTRY              list_head;
    KSPIN_LOCK              list_lock;
    KEVENT                  request_event;
    PVOID                   thread_pointer;
    BOOLEAN                 terminate_thread;
} DEVICE_EXTENSION, *PDEVICE_EXTENSION;

NTSTATUS
DriverEntry (
    IN PDRIVER_OBJECT   DriverObject,
    IN PUNICODE_STRING  RegistryPath
);

NTSTATUS
CreateDevice (
    IN PDRIVER_OBJECT   DriverObject,
    IN ULONG            Number
);

VOID
DriverUnload (
    IN PDRIVER_OBJECT   DriverObject
);

PDEVICE_OBJECT
DeleteDevice (
    IN PDEVICE_OBJECT   DeviceObject
);

NTSTATUS
CreateClose (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
);

NTSTATUS
ReadWrite (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
);

NTSTATUS
DeviceControl (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
);

VOID
Thread (
    IN PVOID            Context
);

NTSTATUS
OpenMedia (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
);

NTSTATUS
CloseMedia (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
);

int swprintf(wchar_t *, const wchar_t *, ...);

#pragma code_seg("init")

NTSTATUS
DriverEntry (
    IN PDRIVER_OBJECT   DriverObject,
    IN PUNICODE_STRING  RegistryPath
    )
{
    UNICODE_STRING              parameter_path;
    RTL_QUERY_REGISTRY_TABLE    query_table[2];
    ULONG                       n_devices;
    NTSTATUS                    status;
    UNICODE_STRING              device_dir_name;
    OBJECT_ATTRIBUTES           object_attributes;
    ULONG                       i;
    USHORT                      created_devices;

    DriverObject->DriverUnload = DriverUnload;

    DriverObject->MajorFunction[IRP_MJ_CREATE]          = CreateClose;
    DriverObject->MajorFunction[IRP_MJ_CLOSE]           = CreateClose;
    DriverObject->MajorFunction[IRP_MJ_READ]            = ReadWrite;
    DriverObject->MajorFunction[IRP_MJ_WRITE]           = ReadWrite;
    DriverObject->MajorFunction[IRP_MJ_DEVICE_CONTROL]  = DeviceControl;

    parameter_path.Length = 0;

    parameter_path.MaximumLength =
        RegistryPath->Length + sizeof(PARAMETER_KEY) + sizeof(WCHAR);

    parameter_path.Buffer =
        (PWSTR) ExAllocatePool(PagedPool, parameter_path.MaximumLength);

    if (!parameter_path.Buffer)
    {
        return STATUS_INSUFFICIENT_RESOURCES;
    }

    RtlCopyUnicodeString(&parameter_path, RegistryPath);

    RtlAppendUnicodeToString(&parameter_path, PARAMETER_KEY);

    RtlZeroMemory(&query_table[0], sizeof(query_table));

    query_table[0].Flags =
        RTL_QUERY_REGISTRY_DIRECT | RTL_QUERY_REGISTRY_REQUIRED;
    query_table[0].Name = NUMBEROFDEVICES_VALUE;
    query_table[0].EntryContext = &n_devices;

    status = RtlQueryRegistryValues(
        RTL_REGISTRY_ABSOLUTE,
        parameter_path.Buffer,
        &query_table[0],
        NULL,
        NULL
        );

    ExFreePool(parameter_path.Buffer);

    if (!NT_SUCCESS(status))
    {
        KdPrint(("FileDisk: DriverEntry: Query registry failed\n"));
        n_devices = DEFAULT_NUMBEROFDEVICES;
    }

    RtlInitUnicodeString(&device_dir_name, DEVICE_DIR_NAME);

    InitializeObjectAttributes(
        &object_attributes,
        &device_dir_name,
        OBJ_PERMANENT,
        NULL,
        NULL
        );

    status = ZwCreateDirectoryObject(
        &dir_handle,
        DIRECTORY_ALL_ACCESS,
        &object_attributes
        );

    if (!NT_SUCCESS(status))
    {
        return status;
    }

    ZwMakeTemporaryObject(dir_handle);

    for (i = 0, created_devices = 0; i < n_devices; i++)
    {
        status = CreateDevice(DriverObject, i);

        if (NT_SUCCESS(status))
        {
            created_devices++;
        }
    }

    if (created_devices >= 1)
    {
        status = STATUS_SUCCESS;
    }
    else
    {
        ZwClose(dir_handle);
    }

    return status;
}

NTSTATUS
CreateDevice (
    IN PDRIVER_OBJECT   DriverObject,
    IN ULONG            Number
    )
{
    WCHAR               device_name_buffer[MAXIMUM_FILENAME_LENGTH];
    UNICODE_STRING      device_name;
    NTSTATUS            status;
    PDEVICE_OBJECT      device_object;
    PDEVICE_EXTENSION   device_extension;
    HANDLE              thread_handle;

    ASSERT(DriverObject != NULL);

    swprintf(
        device_name_buffer,
        DEVICE_DIR_NAME DEVICE_NAME_PREFIX L"%d",
        Number
        );

    RtlInitUnicodeString(&device_name, device_name_buffer);

    status = IoCreateDevice(
        DriverObject,
        sizeof(DEVICE_EXTENSION),
        &device_name,
        FILE_DEVICE_DISK,
        0,
        FALSE,
        &device_object
        );

    if (!NT_SUCCESS(status))
    {
        return status;
    }

    device_object->Flags |= DO_DIRECT_IO;

    device_extension = (PDEVICE_EXTENSION) device_object->DeviceExtension;

    device_extension->media_in_device = FALSE;

    InitializeListHead(&device_extension->list_head);

    KeInitializeSpinLock(&device_extension->list_lock);

    KeInitializeEvent(
        &device_extension->request_event,
        SynchronizationEvent,
        FALSE
        );

    device_extension->terminate_thread = FALSE;

    status = PsCreateSystemThread(
        &thread_handle,
        (ACCESS_MASK) 0L,
        NULL,
        NULL,
        NULL,
        Thread,
        device_object
        );

    if (!NT_SUCCESS(status))
    {
        IoDeleteDevice(device_object);
        return status;
    }

    status = ObReferenceObjectByHandle(
        thread_handle,
        THREAD_ALL_ACCESS,
        NULL,
        KernelMode,
        &device_extension->thread_pointer,
        NULL
        );

    if (!NT_SUCCESS(status))
    {
        ZwClose(thread_handle);

        device_extension->terminate_thread = TRUE;

        KeSetEvent(
            &device_extension->request_event,
            (KPRIORITY) 0,
            FALSE
            );

        IoDeleteDevice(device_object);

        return status;
    }

    ZwClose(thread_handle);

    return STATUS_SUCCESS;
}

#pragma code_seg("page")

VOID
DriverUnload (
    IN PDRIVER_OBJECT DriverObject
    )
{
    PDEVICE_OBJECT device_object;

    PAGED_CODE();

    device_object = DriverObject->DeviceObject;

    while (device_object)
    {
        device_object = DeleteDevice(device_object);
    }

    ZwClose(dir_handle);
}

PDEVICE_OBJECT
DeleteDevice (
    IN PDEVICE_OBJECT DeviceObject
    )
{
    PDEVICE_EXTENSION   device_extension;
    PDEVICE_OBJECT      next_device_object;

    PAGED_CODE();
    ASSERT(DeviceObject != NULL);

    device_extension = (PDEVICE_EXTENSION) DeviceObject->DeviceExtension;

    device_extension->terminate_thread = TRUE;

    KeSetEvent(
        &device_extension->request_event,
        (KPRIORITY) 0,
        FALSE
        );

    KeWaitForSingleObject(
        device_extension->thread_pointer,
        Executive,
        KernelMode,
        FALSE,
        NULL
        );

    ObDereferenceObject(device_extension->thread_pointer);

    next_device_object = DeviceObject->NextDevice;

    IoDeleteDevice(DeviceObject);

    return next_device_object;
}

#pragma code_seg()

NTSTATUS
CreateClose (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = FILE_OPENED;
    IoCompleteRequest(Irp, IO_NO_INCREMENT);

    return STATUS_SUCCESS;
}

NTSTATUS
ReadWrite (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    PDEVICE_EXTENSION   device_extension;
    PIO_STACK_LOCATION  io_stack;
    LONGLONG            offset;
    ULONG               length;
    LONGLONG            partition_length;

    device_extension = (PDEVICE_EXTENSION) DeviceObject->DeviceExtension;

    if (device_extension->media_in_device == FALSE)
    {
        KdPrint(("FileDisk: ReadWrite: No media in device\n"));

        Irp->IoStatus.Status = STATUS_NO_MEDIA_IN_DEVICE;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);

        return STATUS_NO_MEDIA_IN_DEVICE;
    }

    io_stack = IoGetCurrentIrpStackLocation(Irp);

    offset = io_stack->Parameters.Read.ByteOffset.QuadPart;

    length = io_stack->Parameters.Read.Length;

    partition_length =
        device_extension->partition_information.PartitionLength.QuadPart;

    if ((length == 0) ||
        ((offset + length) > partition_length) ||
        (offset % SECTOR_SIZE) ||
        (length % SECTOR_SIZE))
    {
        KdPrint(("FileDisk: ReadWrite: Invalid parameter\n"));

        Irp->IoStatus.Status = STATUS_INVALID_PARAMETER;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);

        return STATUS_INVALID_PARAMETER;
    }

    IoMarkIrpPending(Irp);

    ExInterlockedInsertTailList(
        &device_extension->list_head,
        &Irp->Tail.Overlay.ListEntry,
        &device_extension->list_lock
        );

    KeSetEvent(
        &device_extension->request_event,
        (KPRIORITY) 0,
        FALSE
        );

    return STATUS_PENDING;
}

NTSTATUS
DeviceControl (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    PDEVICE_EXTENSION   device_extension;
    PIO_STACK_LOCATION  io_stack;
    NTSTATUS            status;
    PVERIFY_INFORMATION verify_information;

    device_extension = (PDEVICE_EXTENSION) DeviceObject->DeviceExtension;

    io_stack = IoGetCurrentIrpStackLocation(Irp);

    if (device_extension->media_in_device == FALSE &&
        io_stack->Parameters.DeviceIoControl.IoControlCode !=
        IOCTL_FILEDISK_OPEN_MEDIA)
    {
        KdPrint(("FileDisk: DeviceControl: No media in device\n"));

        Irp->IoStatus.Status = STATUS_NO_MEDIA_IN_DEVICE;
        Irp->IoStatus.Information = 0;
        IoCompleteRequest(Irp, IO_NO_INCREMENT);

        return STATUS_NO_MEDIA_IN_DEVICE;
    }

    switch (io_stack->Parameters.DeviceIoControl.IoControlCode)
    {
    case IOCTL_FILEDISK_OPEN_MEDIA:

        if (device_extension->media_in_device == TRUE)
        {
            KdPrint((
                "FileDisk: DeviceControl: "
                "IOCTL_FILEDISK_OPEN_MEDIA: Media already opened\n"
                ));

            status = STATUS_INVALID_DEVICE_REQUEST;
            Irp->IoStatus.Information = 0;
            break;
        }

        if (io_stack->Parameters.DeviceIoControl.InputBufferLength <
            sizeof(OPEN_MEDIA_INFORMATION))
        {
            status = STATUS_INVALID_PARAMETER;
            Irp->IoStatus.Information = 0;
            break;
        }

        IoMarkIrpPending(Irp);

        ExInterlockedInsertTailList(
            &device_extension->list_head,
            &Irp->Tail.Overlay.ListEntry,
            &device_extension->list_lock
            );

        KeSetEvent(
            &device_extension->request_event,
            (KPRIORITY) 0,
            FALSE
            );

        status = STATUS_PENDING;

        break;

    case IOCTL_FILEDISK_CLOSE_MEDIA:

        IoMarkIrpPending(Irp);

        ExInterlockedInsertTailList(
            &device_extension->list_head,
            &Irp->Tail.Overlay.ListEntry,
            &device_extension->list_lock
            );

        KeSetEvent(
            &device_extension->request_event,
            (KPRIORITY) 0,
            FALSE
            );

        status = STATUS_PENDING;

        break;

    case IOCTL_DISK_GET_DRIVE_GEOMETRY:

        if (io_stack->Parameters.DeviceIoControl.OutputBufferLength <
            sizeof(DISK_GEOMETRY))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            Irp->IoStatus.Information = 0;
            break;
        }

        RtlCopyMemory(
            Irp->AssociatedIrp.SystemBuffer,
            &device_extension->disk_geometry,
            sizeof(DISK_GEOMETRY)
            );

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = sizeof(DISK_GEOMETRY);

        break;

    case IOCTL_DISK_GET_PARTITION_INFO:

        if (io_stack->Parameters.DeviceIoControl.OutputBufferLength <
            sizeof(PARTITION_INFORMATION))
        {
            status = STATUS_BUFFER_TOO_SMALL;
            Irp->IoStatus.Information = 0;
            break;
        }

        RtlCopyMemory(
            Irp->AssociatedIrp.SystemBuffer,
            &device_extension->partition_information,
            sizeof(PARTITION_INFORMATION)
            );

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = sizeof(PARTITION_INFORMATION);

        break;

    case IOCTL_DISK_IS_WRITABLE:

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = 0;

        break;

    case IOCTL_DISK_SET_PARTITION_INFO:

        if (io_stack->Parameters.DeviceIoControl.InputBufferLength <
            sizeof(SET_PARTITION_INFORMATION))
        {
            status = STATUS_INVALID_PARAMETER;
            Irp->IoStatus.Information = 0;
            break;
        }

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = 0;

        break;

    case IOCTL_DISK_VERIFY:

        if (io_stack->Parameters.DeviceIoControl.InputBufferLength <
            sizeof(VERIFY_INFORMATION))
        {
            status = STATUS_INVALID_PARAMETER;
            Irp->IoStatus.Information = 0;
            break;
        }

        verify_information =
            (PVERIFY_INFORMATION) Irp->AssociatedIrp.SystemBuffer;

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = verify_information->Length;

        break;

    case IOCTL_DISK_CHECK_VERIFY:

        status = STATUS_SUCCESS;
        Irp->IoStatus.Information = 0;

        break;

    default:
        KdPrint((
            "FileDisk: DeviceControl: "
            "Unknown IoControlCode 0x%x\n",
            io_stack->Parameters.DeviceIoControl.IoControlCode
            ));

        status = STATUS_NOT_IMPLEMENTED;
        Irp->IoStatus.Information = 0;
    }

    if (status != STATUS_PENDING)
    {
        Irp->IoStatus.Status = status;

        IoCompleteRequest(Irp, IO_NO_INCREMENT);
    }

    return status;
}

#pragma code_seg("page")

VOID
Thread (
    IN PVOID Context
    )
{
    PDEVICE_OBJECT      device_object;
    PDEVICE_EXTENSION   device_extension;
    PLIST_ENTRY         request;
    PIRP                irp;
    PIO_STACK_LOCATION  io_stack;

    PAGED_CODE();
    ASSERT(Context != NULL);

    device_object = (PDEVICE_OBJECT) Context;

    device_extension = (PDEVICE_EXTENSION) device_object->DeviceExtension;

    KeSetPriorityThread(KeGetCurrentThread(), LOW_REALTIME_PRIORITY);

    for (;;)
    {
        KeWaitForSingleObject(
            &device_extension->request_event,
            UserRequest,
            UserMode,
            FALSE,
            NULL
            );

        if (device_extension->terminate_thread)
        {
            PsTerminateSystemThread(STATUS_SUCCESS);
        }

        while (request = ExInterlockedRemoveHeadList(
            &device_extension->list_head,
            &device_extension->list_lock
            ))
        {
            irp = CONTAINING_RECORD(request, IRP, Tail.Overlay.ListEntry);

            io_stack = IoGetCurrentIrpStackLocation(irp);

            switch (io_stack->MajorFunction)
            {
            case IRP_MJ_READ:
                ZwReadFile(
                    device_extension->file_handle,
                    NULL,
                    NULL,
                    NULL,
                    &irp->IoStatus,
                    MmGetSystemAddressForMdl(irp->MdlAddress),
                    io_stack->Parameters.Read.Length,
                    &io_stack->Parameters.Read.ByteOffset,
                    NULL
                    );
                break;

            case IRP_MJ_WRITE:
                ZwWriteFile(
                    device_extension->file_handle,
                    NULL,
                    NULL,
                    NULL,
                    &irp->IoStatus,
                    MmGetSystemAddressForMdl(irp->MdlAddress),
                    io_stack->Parameters.Write.Length,
                    &io_stack->Parameters.Write.ByteOffset,
                    NULL
                    );
                break;

            case IRP_MJ_DEVICE_CONTROL:
                switch (io_stack->Parameters.DeviceIoControl.IoControlCode)
                {
                case IOCTL_FILEDISK_OPEN_MEDIA:
                    OpenMedia(device_object, irp);
                    break;

                case IOCTL_FILEDISK_CLOSE_MEDIA:
                    CloseMedia(device_object, irp);
                    break;

                default:
                    KdPrint((
                        "FileDisk: Thread: "
                        "Unknown IoControlCode 0x%x\n",
                        io_stack->Parameters.DeviceIoControl.IoControlCode
                        ));

                    irp->IoStatus.Status = STATUS_DRIVER_INTERNAL_ERROR;
                    irp->IoStatus.Information = 0;
                }
                break;

            default:
                KdPrint((
                    "FileDisk: Thread: "
                    "Unknown MajorFunction 0x%x\n",
                    io_stack->MajorFunction
                    ));

                irp->IoStatus.Status = STATUS_DRIVER_INTERNAL_ERROR;
                irp->IoStatus.Information = 0;
            }

            IoCompleteRequest(
                irp,
                (CCHAR) (NT_SUCCESS(irp->IoStatus.Status) ?
                IO_DISK_INCREMENT : IO_NO_INCREMENT)
                );
        }
    }
}

NTSTATUS
OpenMedia (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    PDEVICE_EXTENSION               device_extension;
    POPEN_MEDIA_INFORMATION         open_media_information;
    ANSI_STRING                     file_name;
    NTSTATUS                        status;
    OBJECT_ATTRIBUTES               object_attributes;
    LARGE_INTEGER                   file_size;
    FILE_END_OF_FILE_INFORMATION    file_eof;
    FILE_STANDARD_INFORMATION       file_info;
    FILE_ALIGNMENT_INFORMATION      file_alignment;

    PAGED_CODE();
    ASSERT(DeviceObject != NULL);
    ASSERT(Irp != NULL);

    device_extension = (PDEVICE_EXTENSION) DeviceObject->DeviceExtension;

    open_media_information =
        (POPEN_MEDIA_INFORMATION) Irp->AssociatedIrp.SystemBuffer;

    RtlInitAnsiString(&file_name, open_media_information->file_name);

    status = RtlAnsiStringToUnicodeString(
        &device_extension->file_name,
        &file_name,
        TRUE
        );

    if (!NT_SUCCESS(status))
    {
        Irp->IoStatus.Status = status;
        Irp->IoStatus.Information = 0;
        return status;
    }

    InitializeObjectAttributes(
        &object_attributes,
        &device_extension->file_name,
        OBJ_CASE_INSENSITIVE,
        NULL,
        NULL
        );

    status = ZwCreateFile(
        &device_extension->file_handle,
        GENERIC_READ | GENERIC_WRITE,
        &object_attributes,
        &Irp->IoStatus,
        NULL,
        FILE_ATTRIBUTE_NORMAL,
        0,
        FILE_OPEN,
        FILE_NON_DIRECTORY_FILE |
        FILE_RANDOM_ACCESS |
        FILE_NO_INTERMEDIATE_BUFFERING |
        FILE_SYNCHRONOUS_IO_NONALERT,
        NULL,
        0
        );

    if (status == STATUS_OBJECT_NAME_NOT_FOUND)
    {
        if (open_media_information->file_size == 0)
        {
            RtlFreeUnicodeString(&device_extension->file_name);

            Irp->IoStatus.Status = STATUS_NO_SUCH_FILE;
            Irp->IoStatus.Information = 0;

            return STATUS_NO_SUCH_FILE;
        }
        else
        {
            file_size.QuadPart = open_media_information->file_size;

            status = ZwCreateFile(
                &device_extension->file_handle,
                GENERIC_READ | GENERIC_WRITE,
                &object_attributes,
                &Irp->IoStatus,
                &file_size,
                FILE_ATTRIBUTE_NORMAL,
                0,
                FILE_OPEN_IF,
                FILE_NON_DIRECTORY_FILE |
                FILE_RANDOM_ACCESS |
                FILE_NO_INTERMEDIATE_BUFFERING |
                FILE_SYNCHRONOUS_IO_NONALERT,
                NULL,
                0
                );

            if (!NT_SUCCESS(status))
            {
                RtlFreeUnicodeString(&device_extension->file_name);
                return status;
            }

            if (Irp->IoStatus.Information == FILE_CREATED)
            {
                file_eof.EndOfFile.QuadPart = file_size.QuadPart;

                status = ZwSetInformationFile(
                    device_extension->file_handle,
                    &Irp->IoStatus,
                    &file_eof,
                    sizeof(FILE_END_OF_FILE_INFORMATION),
                    FileEndOfFileInformation
                    );

                if (!NT_SUCCESS(status))
                {
                    RtlFreeUnicodeString(&device_extension->file_name);
                    ZwClose(device_extension->file_handle);
                    return status;
                }
            }
        }
    }
    else if (!NT_SUCCESS(status))
    {
        RtlFreeUnicodeString(&device_extension->file_name);
        return status;
    }

    status = ZwQueryInformationFile(
        device_extension->file_handle,
        &Irp->IoStatus,
        &file_info,
        sizeof(FILE_STANDARD_INFORMATION),
        FileStandardInformation
        );

    if (!NT_SUCCESS(status))
    {
        RtlFreeUnicodeString(&device_extension->file_name);
        ZwClose(device_extension->file_handle);
        return status;
    }

    device_extension->disk_geometry.Cylinders.QuadPart =
        file_info.AllocationSize.QuadPart / MM_MAXIMUM_DISK_IO_SIZE;

    device_extension->disk_geometry.MediaType = FixedMedia;

    device_extension->disk_geometry.TracksPerCylinder =
        MM_MAXIMUM_DISK_IO_SIZE / PAGE_SIZE;

    device_extension->disk_geometry.SectorsPerTrack =
        PAGE_SIZE / SECTOR_SIZE;

    device_extension->disk_geometry.BytesPerSector = SECTOR_SIZE;

    device_extension->partition_information.StartingOffset.QuadPart =
        SECTOR_SIZE;
    device_extension->partition_information.PartitionLength.QuadPart =
        file_info.AllocationSize.QuadPart;
    device_extension->partition_information.HiddenSectors = 0;
    device_extension->partition_information.PartitionNumber = 0;
    device_extension->partition_information.PartitionType = 0;
    device_extension->partition_information.BootIndicator = FALSE;
    device_extension->partition_information.RecognizedPartition = FALSE;
    device_extension->partition_information.RewritePartition = FALSE;

    status = ZwQueryInformationFile(
        device_extension->file_handle,
        &Irp->IoStatus,
        &file_alignment,
        sizeof(FILE_ALIGNMENT_INFORMATION),
        FileAlignmentInformation
        );

    if (!NT_SUCCESS(status))
    {
        RtlFreeUnicodeString(&device_extension->file_name);
        ZwClose(device_extension->file_handle);
        return status;
    }

    DeviceObject->AlignmentRequirement = file_alignment.AlignmentRequirement;

    device_extension->media_in_device = TRUE;

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    return STATUS_SUCCESS;
}

NTSTATUS
CloseMedia (
    IN PDEVICE_OBJECT   DeviceObject,
    IN PIRP             Irp
    )
{
    PDEVICE_EXTENSION device_extension;

    PAGED_CODE();
    ASSERT(DeviceObject != NULL);
    ASSERT(Irp != NULL);

    device_extension = (PDEVICE_EXTENSION) DeviceObject->DeviceExtension;

    device_extension->media_in_device = FALSE;

    ZwClose(device_extension->file_handle);

    RtlFreeUnicodeString(&device_extension->file_name);

    Irp->IoStatus.Status = STATUS_SUCCESS;
    Irp->IoStatus.Information = 0;

    return STATUS_SUCCESS;
}
