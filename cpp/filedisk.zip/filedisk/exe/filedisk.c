#include <windows.h>
#include <winioctl.h>
#include <stdio.h>
#include "..\sys\inc\filedisk.h"

INT
main (
	INT		argc,
	PUCHAR	argv[]
);

INT
mount (
	PUCHAR	device_number,
	PUCHAR	file_name,
	ULONG	file_size,
	PUCHAR	drive_letter
);

INT
umount (
	PUCHAR	drive_letter
);

VOID
usage();

VOID
wperror (
	PUCHAR	s
);

INT
main (
	INT		argc,
	PUCHAR	argv[]
	)
{
	ULONG file_size;

	if (argc >= 5 && !strcmp(argv[1], "/mount"))
	{
		if (argc > 5)
		{
			if (argv[4][strlen(argv[4]) - 1] == 'M')
			{
				file_size = atol(argv[4]) * 1024 * 1024;
			}
			else if (argv[4][strlen(argv[4]) - 1] == 'k')
			{
				file_size = atol(argv[4]) * 1024;
			}
			else
			{
				file_size = atol(argv[4]);
			}
			return mount(argv[2], argv[3], file_size, argv[5]);
		}
		else
		{
			return mount(argv[2], argv[3], 0, argv[4]);
		}

	}
	else if (argc >= 3 && !strcmp(argv[1], "/umount"))
	{
		return umount(argv[2]);
	}
	else
	{
		usage();
		return 0;
	}
}

INT
mount (
	PUCHAR	device_number,
	PUCHAR	file_name,
	ULONG	file_size,
	PUCHAR	drive_letter
	)
{
	UCHAR					device_name[MAXIMUM_FILENAME_LENGTH];
	UCHAR					dos_device_name[MAXIMUM_FILENAME_LENGTH];
	HANDLE					device;
	OPEN_MEDIA_INFORMATION	open_media_information;
	ULONG					nread;

	sprintf(
		device_name,
		DEVICE_DIR_NAME DEVICE_NAME_PREFIX "%s",
		device_number
		);

	if (!DefineDosDevice(
		DDD_RAW_TARGET_PATH,
		drive_letter,
		device_name
		))
	{
		wperror(drive_letter);
		return -1;
	}

	sprintf(dos_device_name, "\\\\.\\%s", drive_letter);

	device = CreateFile(
		dos_device_name,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
		);

	if (device == INVALID_HANDLE_VALUE)
	{
		wperror(dos_device_name);

		if (!DefineDosDevice(
			DDD_REMOVE_DEFINITION,
			drive_letter,
			NULL
			))
		{
			wperror(drive_letter);
		}

		return -1;
	}

	if (file_name[0] == '\\')
	{
		strcpy(open_media_information.file_name, file_name);
	}
	else
	{
		strcpy(open_media_information.file_name, "\\??\\");
		strcat(open_media_information.file_name, file_name);
	}

	open_media_information.file_size = file_size;

	if (!DeviceIoControl(
		device,
		IOCTL_FILEDISK_OPEN_MEDIA,
		&open_media_information,
		sizeof(OPEN_MEDIA_INFORMATION),
		NULL,
		0,
		&nread,
		NULL
		))
	{
		wperror(dos_device_name);

		CloseHandle(device);

		if (!DefineDosDevice(
			DDD_REMOVE_DEFINITION,
			drive_letter,
			NULL
			))
		{
			wperror(drive_letter);
		}

		return -1;
	}

	CloseHandle(device);

	return 0;
}

INT
umount (
	PUCHAR drive_letter
	)
{
	UCHAR	dos_device_name[MAXIMUM_FILENAME_LENGTH];
	HANDLE	device;
	ULONG	nread;

	sprintf(dos_device_name, "\\\\.\\%s", drive_letter);

	device = CreateFile(
		dos_device_name,
		GENERIC_READ | GENERIC_WRITE,
		FILE_SHARE_READ | FILE_SHARE_WRITE,
		NULL,
		OPEN_EXISTING,
		FILE_ATTRIBUTE_NORMAL,
		NULL
		);

	if (device == INVALID_HANDLE_VALUE)
	{
		wperror(dos_device_name);
		return -1;
	}

	if (!DeviceIoControl(
		device,
		FSCTL_LOCK_VOLUME,
		NULL,
		0,
		NULL,
		0,
		&nread,
		NULL
		))
	{
		wperror(dos_device_name);
		CloseHandle(device);
		return -1;
	}

	if (!DeviceIoControl(
		device,
		FSCTL_DISMOUNT_VOLUME,
		NULL,
		0,
		NULL,
		0,
		&nread,
		NULL
		))
	{
		wperror(dos_device_name);
		CloseHandle(device);
		return -1;
	}

	if (!DeviceIoControl(
		device,
		IOCTL_FILEDISK_CLOSE_MEDIA,
		NULL,
		0,
		NULL,
		0,
		&nread,
		NULL
		))
	{
		wperror(dos_device_name);
		CloseHandle(device);
		return -1;
	}

	CloseHandle(device);

	if (!DefineDosDevice(
		DDD_REMOVE_DEFINITION,
		drive_letter,
		NULL
		))
	{
		wperror(drive_letter);
		return -1;
	}

	return 0;
}

VOID
usage()
{
	printf("Usage:\n");
	printf("filedisk /mount  devicenumber filename [size[k|M]] driveletter\n");
	printf("filedisk /umount driveletter\n");
	printf("\n");
	printf("Example:\n");
	printf("filedisk /mount  0 c:\\temp\\filedisk.img 8M f:\n");
	printf("filedisk /umount f:\n");
}

VOID
wperror (
	PUCHAR s
	)
{
    LPVOID lpMsgBuf;

    FormatMessage( 
        FORMAT_MESSAGE_ALLOCATE_BUFFER |
        FORMAT_MESSAGE_FROM_SYSTEM |
        FORMAT_MESSAGE_IGNORE_INSERTS,
        NULL,
        GetLastError(),
        0,
        (LPTSTR) &lpMsgBuf,
        0,
        NULL
        );

    fprintf(stderr, "%s: %s", s, (LPTSTR) lpMsgBuf);

    LocalFree(lpMsgBuf);
}
