// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
//
// WINDOWS SKINNING TUTORIAL - by Vander Nunes - virtware.net
// This is the source-code that shows what is discussed in the tutorial.
// The code is simplified for the sake of clarity, but all the needed
// features for handling skinned windows is present. Please read
// the article for more information.
//
// regioncreator.cpp
//
// This little console application will make window region creation easier.
// Just feed it with a BMP file and a transparent color, and it will create
// the region file to be used by the CSkin class.
//
// 28/02/2002 : initial release.
//
// =-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-


#include <windows.h>
#include <stdio.h>


// just some declarations
BYTE* Get24BitPixels(HBITMAP pBitmap, WORD *pwWidth, WORD *pwHeight);
HRGN  ScanRegion(HBITMAP pBitmap, BYTE TranspR, BYTE TranspG, BYTE TranspB);
bool  SaveRegion(HRGN rgn, char *fname);



// -------------------------------------------------------------------------------------
// Sintax:
//
// regioncreator <bitmap.bmp> <Red> <Green> <Blue>
//
// bitmap.bmp     : bitmap to be traced
// Red,Green,Blue : color of the transparent pixel, in decimal.
//
//               --------------------------------------------------
//
// example:         regioncreator skin1.bmp 255 255 255
//
//                  (will scan skin1.bmp and create skin1.rgn)
// -------------------------------------------------------------------------------------

int main(int argc, char *argv[], char *envp[])
{
  // handle for the supplied bitmap
  HBITMAP hBmp;

  // transparent color components
  BYTE jRed,jGreen,jBlue;

  // processed region
  HRGN hRegion;

  // supplied filename
  char szFile[MAX_PATH];


  // ------------------------------------------------------------------------------------
  // show app intro to user
  // ------------------------------------------------------------------------------------
  printf("\n---------------------------------------------------\n");
  printf("REGIONCREATOR 1.0\nby Vander Nunes - Virtware.net");
  printf("\n--------------------------------------------------------\n");
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // show help if there are missing or excessive arguments
  // ------------------------------------------------------------------------------------
  if (argc != 5)
  {
    printf("sintax: regioncreator <bitmap.bmp> <Red> <Green> <Blue>\n\n");
    printf("bitmap.bmp     : bitmap to be traced\n");
    printf("Red,Green,Blue : RGB color of the transparent pixel (in decimal)\n\n");
    exit(1);
  }
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // check for valid filename
  // ------------------------------------------------------------------------------------
  if (strlen(argv[1]) >= MAX_PATH)
  {
    printf("File name is too big, please use a short file name.\n\n");
    exit(2);
  }

  // i was very lazy here, assuming that the user provided a ".bmp" extension =)
  strcpy(szFile, argv[1]);
  strcpy(&szFile[strlen(szFile)-3],"rgn");
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // load image
  // ------------------------------------------------------------------------------------
  hBmp = (HBITMAP)LoadImage(NULL,argv[1],IMAGE_BITMAP,0,0,LR_LOADFROMFILE);
  if (!hBmp)
  {
    printf("%s: file not found.\n\n",argv[1]);
    exit(3);
  }
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // get transparent color info from command line
  // ------------------------------------------------------------------------------------
  jRed   = atoi(argv[2]);
  jGreen = atoi(argv[3]);
  jBlue  = atoi(argv[4]);
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // scan and save the bitmap
  // ------------------------------------------------------------------------------------
  printf("Tracing %s:\n",argv[1]);
  hRegion = ScanRegion(hBmp,jRed,jGreen,jBlue);
  SaveRegion(hRegion,szFile);
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // release our garbage
  // ------------------------------------------------------------------------------------
  DeleteObject(hRegion);
  DeleteObject(hBmp);
  // ------------------------------------------------------------------------------------


  // ------------------------------------------------------------------------------------
  // done.
  // ------------------------------------------------------------------------------------
  printf("Finished.\n\n");

  return 0;
}



// -------------------------------------------------------------------------------------
// Scan a bitmap and return a perfect fit region.
// The caller must release the memory...
// (this method starts with a full region and excludes inside the loop)
// -------------------------------------------------------------------------------------
HRGN ScanRegion(HBITMAP pBitmap, BYTE jTranspR, BYTE jTranspG, BYTE jTranspB)
{
  // bitmap width and height
	WORD wBmpWidth,wBmpHeight;

  // the final region and a temporary region
  HRGN hRgn, hTmpRgn;

  // 24bit pixels from the bitmap
  BYTE *pPixels = Get24BitPixels(pBitmap, &wBmpWidth, &wBmpHeight);
  if (!pPixels) return NULL;

  // create our working region
  hRgn = CreateRectRgn(0,0,wBmpWidth,wBmpHeight);
  if (!hRgn) { delete pPixels; return NULL; }

  // ---------------------------------------------------------
  // scan the bitmap
  // ---------------------------------------------------------
  DWORD p=0;
  for (WORD y=0; y<wBmpHeight; y++)
  {
    for (WORD x=0; x<wBmpWidth; x++)
    {
      BYTE jRed   = pPixels[p+2];
      BYTE jGreen = pPixels[p+1];
      BYTE jBlue  = pPixels[p+0];

      if (jRed == jTranspR && jGreen == jTranspG && jBlue == jTranspB)
      {
        // remove transparent color from region
        hTmpRgn = CreateRectRgn(x,y,x+1,y+1);
        CombineRgn(hRgn, hRgn, hTmpRgn, RGN_XOR);
        DeleteObject(hTmpRgn);
      }

      // next pixel
      p+=3;
    }
  }

  // release pixels
  delete pPixels;

  // return the region
  return hRgn;
}



// -------------------------------------------------------------------------------------
// Return bitmap pixels in 24bits format.
// The caller must release the memory...
// -------------------------------------------------------------------------------------
BYTE* Get24BitPixels(HBITMAP pBitmap, WORD *pwWidth, WORD *pwHeight)
{
  // a bitmap object just to get bitmap width and height
	BITMAP bmpBmp;

  // pointer to original bitmap info
	LPBITMAPINFO pbmiInfo;

  // bitmap info will hold the new 24bit bitmap info
  BITMAPINFO bmiInfo;

  // width and height of the bitmap
  WORD wBmpWidth, wBmpHeight;

  // ---------------------------------------------------------
  // get some info from the bitmap
  // ---------------------------------------------------------
	GetObject(pBitmap, sizeof(bmpBmp),&bmpBmp);
  pbmiInfo   = (LPBITMAPINFO)&bmpBmp;

  // get width and height
	wBmpWidth  = (WORD)pbmiInfo->bmiHeader.biWidth;
	wBmpWidth -= (wBmpWidth%4);                       // width is 4 byte boundary aligned.
	wBmpHeight = (WORD)pbmiInfo->bmiHeader.biHeight;

  // copy to caller width and height parms
  *pwWidth  = wBmpWidth;
  *pwHeight = wBmpHeight;
  // ---------------------------------------------------------

	// allocate width * height * 24bits pixels
  BYTE *pPixels = new BYTE[wBmpWidth*wBmpHeight*3];
	if (!pPixels) return NULL;

  // get user desktop device context to get pixels from
	HDC hDC = GetWindowDC(NULL);

  // fill desired structure
	bmiInfo.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
	bmiInfo.bmiHeader.biWidth = wBmpWidth;
	bmiInfo.bmiHeader.biHeight = -wBmpHeight;
	bmiInfo.bmiHeader.biPlanes = 1;
	bmiInfo.bmiHeader.biBitCount = 24;
	bmiInfo.bmiHeader.biCompression = BI_RGB;
	bmiInfo.bmiHeader.biSizeImage = wBmpWidth*wBmpHeight*3;
	bmiInfo.bmiHeader.biXPelsPerMeter = 0;
	bmiInfo.bmiHeader.biYPelsPerMeter = 0;
	bmiInfo.bmiHeader.biClrUsed = 0;
	bmiInfo.bmiHeader.biClrImportant = 0;

  // get pixels from the original bitmap converted to 24bits
  int iRes = GetDIBits(hDC,pBitmap,0,wBmpHeight,(LPVOID)pPixels,&bmiInfo,DIB_RGB_COLORS);

  // release the device context
	ReleaseDC(NULL,hDC);

  // if failed, cancel the operation.
	if (!iRes)
  {
    delete pPixels;
    return NULL;
  };

  // return the pixel array
	return pPixels;
}



// -------------------------------------------------------------------------------------
// Save a region to disk
// -------------------------------------------------------------------------------------
bool SaveRegion(HRGN hRgn, char *szFile)
{
  // get the size of the region object
  int iSize = GetRegionData(hRgn, 0,0);

  // allocate space for it
  LPRGNDATA pData = new RGNDATA[iSize];
  if (!pData) return false;

  // get the region as binary data
  GetRegionData(hRgn, iSize, pData);

  // save
  FILE *f = fopen(szFile, "wb");
  if (!f) { delete pData; return false; }
  fwrite(pData, 1, iSize, f);
  fclose(f);

  delete pData;

  return true;
}
