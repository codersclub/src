// PostMsgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "PostMsg.h"
#include "PostMsgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPostMsgDlg dialog

CPostMsgDlg::CPostMsgDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPostMsgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPostMsgDlg)
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CPostMsgDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPostMsgDlg)
	DDX_Control(pDX, IDC_WPARAM, m_wparam);
	DDX_Control(pDX, IDC_LPARAM, m_lparam);
	DDX_Control(pDX, IDC_MESSAGE, m_message);
	DDX_Control(pDX, IDC_TREE1, m_tree);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CPostMsgDlg, CDialog)
	//{{AFX_MSG_MAP(CPostMsgDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_REFRESH, OnRefresh)
	ON_BN_CLICKED(IDC_SEARCH, OnSearch)
	ON_BN_CLICKED(IDC_HIDE, OnHide)
	ON_BN_CLICKED(IDC_SHOW, OnShow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPostMsgDlg message handlers

BOOL CPostMsgDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Add "About..." menu item to system menu.

	// IDM_ABOUTBOX must be in the system command range.
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != NULL)
	{
		CString strAboutMenu;
		strAboutMenu.LoadString(IDS_ABOUTBOX);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	FILE *msgfile=NULL;
	char *stopstring=NULL, *cptr=NULL, cbuff[255]="\0";
	int pos=0;
	DWORD base=0, val=0;
	
	if((msgfile=fopen("msg.dat", "r")))
	{
		while(fgets(cbuff, sizeof(cbuff), msgfile))
		{
			cptr=cbuff+8;   //skip over #define
			while(*cptr++ != ' ');  //read until space
			
			if(cptr >= (cbuff+strlen(cbuff)))
			{
				continue;
			}

			*cptr++='\0';

			if(strstr(cptr, "0x"))
			{
				base=16;
			}
			else
			{
				base=10;
			}

			val = strtoul( cptr, &stopstring, base);

			pos=m_message.AddString(cbuff+8);
			m_message.SetItemData( pos, val);

			pos=m_wparam.AddString(cbuff+8);
			m_wparam.SetItemData( pos, val);

			pos=m_lparam.AddString(cbuff+8);
			m_lparam.SetItemData( pos, val);

			TRACE("Message: %s  Val: %d\n", cbuff+8, val);
		}

		fclose(msgfile);
	}

	pos=m_message.AddString("NULL");
	m_message.SetItemData( pos, 0);
	m_message.SetCurSel(pos);

	pos=m_wparam.AddString("NULL");
	m_wparam.SetItemData( pos, 0);
	m_wparam.SetCurSel(pos);
	
	pos=m_lparam.AddString("NULL");
	m_lparam.SetItemData( pos, 0);
	m_lparam.SetCurSel(pos);


	OnRefresh();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CPostMsgDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CPostMsgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CPostMsgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

BOOL CALLBACK CPostMsgDlg::EnumWindowsProc(HWND hWnd, LPARAM lParam)
{
	CPostMsgDlg* dlg=(CPostMsgDlg*)lParam;
	static char cbuff[256]="\0";
	static HTREEITEM hItem=NULL;
	static CString strClass, buff;
	static DWORD dwPID=0;
	static HWND hParentWnd=NULL;

	// get window class name
	::GetClassName(hWnd, strClass.GetBuffer(_MAX_PATH), _MAX_PATH);
	
	// get pid
	::GetWindowThreadProcessId(hWnd, &dwPID);
	
	// get caption
	::GetWindowText(hWnd, cbuff, sizeof(cbuff));

	// get parent
	hParentWnd=::GetParent(hWnd);

	// set item string
	buff.Format("\"%s\"    %s    %d    %d", cbuff, strClass, dwPID, hWnd);

	hItem=dlg->m_hLastItem;
	while(hItem)
	{
		if((HWND)dlg->m_tree.GetItemData(hItem) == hParentWnd)
		{
			break;
		}
		else
		{
			hItem=dlg->m_tree.GetParentItem(hItem);
		}
	}

	dlg->m_hLastItem = dlg->m_tree.InsertItem(TVIF_PARAM|TVIF_TEXT, buff, NULL, NULL, NULL, NULL, LPARAM(hWnd), (hItem)?hItem:dlg->m_tree.GetRootItem(), TVI_LAST);
	
	return true;
}


void CPostMsgDlg::OnOK() 
{
	HTREEITEM item=m_tree.GetSelectedItem();
	if(!item)
	{
		return;
	}

	::PostMessage((HWND)m_tree.GetItemData(item), 
		m_message.GetItemData( m_message.GetCurSel()),
		m_wparam.GetItemData( m_wparam.GetCurSel()),
		m_lparam.GetItemData( m_lparam.GetCurSel()));
}

void CPostMsgDlg::OnRefresh() 
{
	m_tree.DeleteAllItems();
	m_hLastItem=NULL;
	m_tree.InsertItem(TVIF_TEXT, "Desktop  (Title     Class     PID     hWnd)", NULL, NULL, NULL, NULL, NULL, TVI_ROOT, TVI_ROOT);

	::EnumChildWindows(::GetDesktopWindow(), EnumWindowsProc, (LPARAM)this);

	m_tree.Expand(m_tree.GetRootItem(), TVE_EXPAND);
	m_tree.SelectItem(m_tree.GetRootItem());
}

void CPostMsgDlg::OnSearch() 
{
	CString buff;
	HTREEITEM ret=NULL, start=NULL;
	BOOL bdone=FALSE;

	GetDlgItem(IDC_EDITSEARCH)->GetWindowText(buff);

	if(!buff.GetLength())
	{
		return;
	}

	buff.MakeLower();

	if(!(start=m_tree.GetSelectedItem()))
	{
		start=m_tree.GetRootItem();
	}

	if((ret=FindTreeItem(start, buff)))
	{
		m_tree.EnsureVisible(ret);
		m_tree.SelectItem(ret);
		GetDlgItem(IDC_MATCH)->SetWindowText("(found)");
	}
	else
	{
		GetDlgItem(IDC_MATCH)->SetWindowText("(no matches)");
	}
}

HTREEITEM CPostMsgDlg::FindTreeItem(HTREEITEM startitem, CString &label)
{
	static HTREEITEM ret;
	static CString buff;

	buff=m_tree.GetItemText(startitem);
	buff.MakeLower();
	if(buff.Find(label)!=-1)
	{
		return startitem;
	}
	
	if(m_tree.ItemHasChildren(startitem))
	{
		if((ret=FindTreeItem(m_tree.GetChildItem(startitem), label)))
		{
			return ret;
		}
	}
	
	if((ret=m_tree.GetNextSiblingItem(startitem)))
	{
		if((ret=FindTreeItem(ret, label)))
		{
			return ret;
		}
	}
	
	return NULL;
}

void CPostMsgDlg::OnHide() 
{
	HTREEITEM item=m_tree.GetSelectedItem();
	if(!item)
	{
		return;
	}

	::ShowWindow((HWND)m_tree.GetItemData(item), SW_HIDE);
}

void CPostMsgDlg::OnShow() 
{
	HTREEITEM item=m_tree.GetSelectedItem();
	if(!item)
	{
		return;
	}

	::ShowWindow((HWND)m_tree.GetItemData(item), SW_SHOW);
	SetFocus();
}
