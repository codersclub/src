// PostMsg.h : main header file for the POSTMSG application
//

#if !defined(AFX_POSTMSG_H__34AE1B75_7718_4AF2_801E_383C7E0314FB__INCLUDED_)
#define AFX_POSTMSG_H__34AE1B75_7718_4AF2_801E_383C7E0314FB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CPostMsgApp:
// See PostMsg.cpp for the implementation of this class
//

class CPostMsgApp : public CWinApp
{
public:
	CPostMsgApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPostMsgApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CPostMsgApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POSTMSG_H__34AE1B75_7718_4AF2_801E_383C7E0314FB__INCLUDED_)
