// PostMsgDlg.h : header file
//

#if !defined(AFX_POSTMSGDLG_H__4E6DE3CE_1D80_4975_9DD0_5F7765A658D6__INCLUDED_)
#define AFX_POSTMSGDLG_H__4E6DE3CE_1D80_4975_9DD0_5F7765A658D6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CPostMsgDlg dialog

class CPostMsgDlg : public CDialog
{
// Construction
public:
	CPostMsgDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CPostMsgDlg)
	enum { IDD = IDD_POSTMSG_DIALOG };
	CComboBox	m_wparam;
	CComboBox	m_lparam;
	CComboBox	m_message;
	CTreeCtrl	m_tree;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPostMsgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	HTREEITEM m_hLastItem;

	static BOOL CALLBACK EnumWindowsProc(HWND hWnd, LPARAM lParam);
	HTREEITEM FindTreeItem(HTREEITEM startitem, CString &label);

	// Generated message map functions
	//{{AFX_MSG(CPostMsgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnRefresh();
	afx_msg void OnSearch();
	afx_msg void OnHide();
	afx_msg void OnShow();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_POSTMSGDLG_H__4E6DE3CE_1D80_4975_9DD0_5F7765A658D6__INCLUDED_)
