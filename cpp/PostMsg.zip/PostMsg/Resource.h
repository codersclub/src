//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PostMsg.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_POSTMSG_DIALOG              102
#define IDR_MAINFRAME                   128
#define IDC_LIST1                       1000
#define IDC_TREE1                       1001
#define IDC_MESSAGE                     1002
#define IDC_MESSAGE2                    1003
#define IDC_WPARAM                      1003
#define IDC_MESSAGE3                    1004
#define IDC_LPARAM                      1004
#define IDC_REFRESH                     1005
#define IDC_REFRESH2                    1007
#define IDC_SEARCH                      1007
#define IDC_EDITSEARCH                  1008
#define IDC_MATCH                       1009
#define IDC_HIDE                        1010
#define IDC_SHOW                        1011

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1011
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
