// FTPTreeView.h : interface of the CFTPTreeView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FTPTREEVIEW_H__E391AE0F_1BE2_417D_A0E6_9CBE29E180C1__INCLUDED_)
#define AFX_FTPTREEVIEW_H__E391AE0F_1BE2_417D_A0E6_9CBE29E180C1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFtpWandererDoc;

class CFtpTreeView : public CTreeView
{
protected: // create from serialization only
	CFtpTreeView();
	DECLARE_DYNCREATE(CFtpTreeView)

// Attributes
public:
	CFtpWandererDoc *GetDocument();
	HTREEITEM FindItem(LPCTSTR lpszText, HTREEITEM hItem);

// Operations
public:
	CFtpConnection *m_pFtpConnection;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtpTreeView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:

	virtual ~CFtpTreeView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	HTREEITEM GetNextItemEx(HTREEITEM hItem);
	BOOL InitTreeImageList();

// Generated message map functions
protected:
	//{{AFX_MSG(CFtpTreeView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FtpTreeView.cpp
inline CFtpWandererDoc* CFtpTreeView::GetDocument()
   { return (CFtpWandererDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPTREEVIEW_H__E391AE0F_1BE2_417D_A0E6_9CBE29E180C1__INCLUDED_)
