#if !defined(AFX_REPLACEFOLDERDLG_H__C37DD280_1683_497B_8C78_FA6DD7469260__INCLUDED_)
#define AFX_REPLACEFOLDERDLG_H__C37DD280_1683_497B_8C78_FA6DD7469260__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReplaceFolderDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReplaceFolderDlg dialog

class CReplaceFolderDlg : public CDialog
{
// Construction
public:
	CReplaceFolderDlg(CWnd* pParent = NULL);   // standard constructor
	int m_nFileCount;
	CString m_strFileName;

// Dialog Data
	//{{AFX_DATA(CReplaceFolderDlg)
	enum { IDD = IDD_REPLACE_FOLDER };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplaceFolderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReplaceFolderDlg)
	afx_msg void OnYes();
	afx_msg void OnYestoall();
	afx_msg void OnNo();
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLACEFOLDERDLG_H__C37DD280_1683_497B_8C78_FA6DD7469260__INCLUDED_)
