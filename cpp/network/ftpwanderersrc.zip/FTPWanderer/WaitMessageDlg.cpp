/****************************************************************/
/*																*/
/*  WaitMessageDlg.cpp											*/
/*																*/
/*  Implementation of the CWaitMessageDlg class.				*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/

#include "stdafx.h"
#include "ftpwanderer.h"
#include "WaitMessageDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CWaitMessageDlg::CWaitMessageDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CWaitMessageDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CWaitMessageDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	m_nRetryDelay = 0;
}


void CWaitMessageDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWaitMessageDlg)
	DDX_Control(pDX, IDC_PROGRESS1, m_ProgressCtrl);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWaitMessageDlg, CDialog)
	//{{AFX_MSG_MAP(CWaitMessageDlg)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CWaitMessageDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CenterWindow();	


	HICON hIcon = LoadIcon(NULL, IDI_INFORMATION);
	SendDlgItemMessage(IDC_STATIC_ICON, STM_SETICON, (WPARAM)hIcon, 0);
	
	SetDlgItemText(IDC_MESSAGE, m_strMessage);

	CString str;
	str.Format("FTP Wanderer will retry to connect after %d seconds...", m_nRetryDelay);
	SetDlgItemText(IDC_WAITTIME, str);

	m_ProgressCtrl.SetRange(0, m_nRetryDelay);
	m_ProgressCtrl.SetStep(1);

	SetTimer(1, 1000, NULL);
	return TRUE;
}

void CWaitMessageDlg::OnTimer(UINT nIDEvent) 
{
	m_ProgressCtrl.StepIt();

	CString str;
	str.Format("FTP Wanderer will retry to connect after %d seconds...", m_nRetryDelay - m_ProgressCtrl.GetPos());
	SetDlgItemText(IDC_WAITTIME, str);

	if (m_ProgressCtrl.GetPos() >= m_nRetryDelay)
	{
		CDialog::OnOK();
	}
	CDialog::OnTimer(nIDEvent);
}
