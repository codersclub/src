#if !defined(AFX_CONNECTDLG_H__F8601FF3_46CE_11D6_AB39_00D0B70C3D79__INCLUDED_)
#define AFX_CONNECTDLG_H__F8601FF3_46CE_11D6_AB39_00D0B70C3D79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "FtpSite.h"
#include "InfobarCtrl.h"

class CConnectDlg : public CDialog
{
// Construction
public:
	BOOL AddSite(CFtpSite &pFtpSite);
	CConnectDlg(CWnd* pParent = NULL);   // standard constructor
	
	CArray<CFtpSite, CFtpSite&> m_SitesArray;
	BOOL Serialize(BOOL bStoring);

// Dialog Data
	//{{AFX_DATA(CConnectDlg)
	enum { IDD = IDD_CONNECT };
	CInfobarCtrl m_wndInfobarCtrl;
	CListBox	m_listSites;
	CString	m_strAddress;
	BOOL	m_bAnonymous;
	int		m_nRetries;
	CString	m_strDescription;
	CString	m_strLocalPath;
	CString	m_strLogin;
	CString	m_strName;
	CString	m_strPassword;
	int		m_nPort;
	CString	m_strRemotePath;
	int		m_nRetryDelay;
	BOOL	m_bUsePASVMode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bModified;
	BOOL ValidateData();
	CString m_strFilename;
	// Generated message map functions
	//{{AFX_MSG(CConnectDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSave();
	afx_msg void OnAdd();
	afx_msg void OnSelchangeSites();
	afx_msg void OnRemove();
	afx_msg void OnBrowse();
	afx_msg void OnDblclkSites();
	afx_msg void OnAnonymous();
	afx_msg void OnChangeName();
	afx_msg void OnWizard();
	afx_msg void OnSomethingChanged();
	afx_msg void OnChangeLogin();
	//}}AFX_MSG
	void OnUpdateSave(CCmdUI* pCmdUI);
	void OnUpdateRemove(CCmdUI* pCmdUI);
	void OnUpdateConnect(CCmdUI* pCmdUI);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNECTDLG_H__F8601FF3_46CE_11D6_AB39_00D0B70C3D79__INCLUDED_)
