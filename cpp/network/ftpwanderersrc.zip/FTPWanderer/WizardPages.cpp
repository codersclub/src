/****************************************************************/
/*																*/
/*  WizardPages.cpp												*/
/*																*/
/*  Implementation of the Connection Wizard.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "WizardPages.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNAMIC(CWizardSheet, CPropertySheetEx)

CWizardSheet::CWizardSheet(UINT nIDCaption, CWnd* pParentWnd,
	UINT iSelectPage, HBITMAP hbmWatermark, HPALETTE hpalWatermark,
	HBITMAP hbmHeader)
: CPropertySheetEx(nIDCaption, pParentWnd, iSelectPage,
				  hbmWatermark, hpalWatermark, hbmHeader)
{
	// add all the pages of the wizard
	InitPages();

	// set the WIZARD97 flag so we'll get the new look
	m_psh.dwFlags |= PSH_WIZARD97;
}

CWizardSheet::CWizardSheet(LPCTSTR pszCaption, CWnd* pParentWnd,
	UINT iSelectPage, HBITMAP hbmWatermark, HPALETTE hpalWatermark,
	HBITMAP hbmHeader)
: CPropertySheetEx(pszCaption, pParentWnd, iSelectPage,
					  hbmWatermark, hpalWatermark, hbmHeader)

{
	// add all the pages of the wizard
	InitPages();

	// set the WIZARD97 flag so we'll get the new look
	m_psh.dwFlags |= PSH_WIZARD97;
}


CWizardSheet::~CWizardSheet()
{
}


BEGIN_MESSAGE_MAP(CWizardSheet, CPropertySheetEx)
	//{{AFX_MSG_MAP(CWizardSheet)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : InitPages										*/
/* Description   : Add pages to wizard.								*/
/*																	*/
/********************************************************************/
void CWizardSheet::InitPages()
{
	AddPage(&m_Page1);
	AddPage(&m_Page2);
	AddPage(&m_Page3);
	AddPage(&m_Page4);
	AddPage(&m_PageFinish);
}



IMPLEMENT_DYNCREATE(CWizardPage1, CPropertyPageEx)

CWizardPage1::CWizardPage1() : CPropertyPageEx(CWizardPage1::IDD, 0, IDS_HEADERTITLE1, NULL)
{
	//{{AFX_DATA_INIT(CWizardPage1)
	m_strProfileName = _T("");
	//}}AFX_DATA_INIT
}

CWizardPage1::~CWizardPage1()
{
}

void CWizardPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage1)
	DDX_Text(pDX, IDC_PROFILENAME, m_strProfileName);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage1, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizardPage1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnSetActive										*/
/* Description   : Called when this becomes the active page.		*/
/*																	*/
/********************************************************************/
BOOL CWizardPage1::OnSetActive() 
{
	CPropertySheetEx* parent = (CPropertySheetEx*)GetParent();
	parent->SetWizardButtons(PSWIZB_NEXT);
	return CPropertyPageEx::OnSetActive();
}


/********************************************************************/
/*																	*/
/* Function name : OnWizardNext										*/
/* Description   : Called when Next button has been pressed.		*/
/*																	*/
/********************************************************************/
LRESULT CWizardPage1::OnWizardNext() 
{
	CEdit *editBox = (CEdit *)GetDlgItem(IDC_PROFILENAME);
	if (editBox->GetWindowTextLength() == 0)
	{
		MessageBox("You must enter a profile name.", "Connection Wizard",  MB_OK | MB_ICONEXCLAMATION);
		editBox->SetFocus();
		return -1;
	}	
	return CPropertyPageEx::OnWizardNext();
}


IMPLEMENT_DYNCREATE(CWizardPage2, CPropertyPageEx)

CWizardPage2::CWizardPage2() : CPropertyPageEx(CWizardPage2::IDD, 0, IDS_HEADERTITLE2, NULL)
{
	//{{AFX_DATA_INIT(CWizardPage2)
	m_strHostAddress = _T("");
	//}}AFX_DATA_INIT
}

CWizardPage2::~CWizardPage2()
{
}

void CWizardPage2::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage2)
	DDX_Text(pDX, IDC_HOSTNAME, m_strHostAddress);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage2, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizardPage2)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnSetActive										*/
/* Description   : Called when this becomes the active page.		*/
/*																	*/
/********************************************************************/
BOOL CWizardPage2::OnSetActive() 
{
	CPropertySheetEx* parent = (CPropertySheetEx*)GetParent();
	parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);	
	return CPropertyPageEx::OnSetActive();
}


/********************************************************************/
/*																	*/
/* Function name : OnWizardNext										*/
/* Description   : Called when Next button has been pressed.		*/
/*																	*/
/********************************************************************/
LRESULT CWizardPage2::OnWizardNext() 
{
	CEdit *editBox = (CEdit *)GetDlgItem(IDC_HOSTNAME);
	if (editBox->GetWindowTextLength() == 0)
	{
		MessageBox("You must enter a host address.", "Connection Wizard",  MB_OK | MB_ICONEXCLAMATION);
		editBox->SetFocus();
		return -1;
	}	
	return CPropertyPageEx::OnWizardNext();
}


IMPLEMENT_DYNCREATE(CWizardPage3, CPropertyPageEx)

CWizardPage3::CWizardPage3() : CPropertyPageEx(CWizardPage3::IDD, 0, IDS_HEADERTITLE3, NULL)
{
	//{{AFX_DATA_INIT(CWizardPage3)
	m_strUserName = _T("");
	m_strPassword = _T("");
	m_bAnonymous = FALSE;
	//}}AFX_DATA_INIT
}

CWizardPage3::~CWizardPage3()
{
}

void CWizardPage3::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage3)
	DDX_Text(pDX, IDC_USERNAME, m_strUserName);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	DDX_Check(pDX, IDC_ANONYMOUS, m_bAnonymous);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage3, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizardPage3)
	ON_BN_CLICKED(IDC_ANONYMOUS, OnAnonymous)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnSetActive										*/
/* Description   : Called when this becomes the active page.		*/
/*																	*/
/********************************************************************/
BOOL CWizardPage3::OnSetActive() 
{
	CPropertySheetEx* parent = (CPropertySheetEx*)GetParent();
	parent->SetWizardButtons(PSWIZB_BACK | PSWIZB_NEXT);		
	return CPropertyPageEx::OnSetActive();
}


/********************************************************************/
/*																	*/
/* Function name : OnAnonymous										*/
/* Description   : Called when checkbox is checked/uncecked.		*/
/*																	*/
/********************************************************************/
void CWizardPage3::OnAnonymous() 
{
	UpdateData();
	if (m_bAnonymous)
	{
		m_strUserName = "anonymous";
		m_strPassword = AfxGetApp()->GetProfileString("Settings", "EmailAddress", "");
		GetDlgItem(IDC_PASSWORD)->ModifyStyle(ES_PASSWORD, NULL);
		((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar(0);
	}
	else
	{
		GetDlgItem(IDC_PASSWORD)->ModifyStyle(NULL, ES_PASSWORD);
		((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar('*');
	}
	UpdateData(FALSE);
}


IMPLEMENT_DYNCREATE(CWizardPage4, CPropertyPageEx)

CWizardPage4::CWizardPage4() : CPropertyPageEx(CWizardPage4::IDD, 0, IDS_HEADERTITLE4, NULL)
{
	//{{AFX_DATA_INIT(CWizardPage4)
	m_strLocalFolder = _T("");
	//}}AFX_DATA_INIT
}

CWizardPage4::~CWizardPage4()
{
}

void CWizardPage4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardPage4)
	DDX_Text(pDX, IDC_LOCALFOLDER, m_strLocalFolder);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardPage4, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizardPage4)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CWizardPage4::OnInitDialog() 
{
	CPropertyPageEx::OnInitDialog();
	
	m_strLocalFolder = AfxGetApp()->GetProfileString("Settings", "DefaultLocalPath", "");
	UpdateData(FALSE);
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnSetActive										*/
/* Description   : Called when this becomes the active page.		*/
/*																	*/
/********************************************************************/
BOOL CWizardPage4::OnSetActive() 
{
	CPropertySheetEx* parent = (CPropertySheetEx*)GetParent();
	parent->SetWizardButtons( PSWIZB_BACK | PSWIZB_NEXT);	
	return CPropertyPageEx::OnSetActive();
}


/********************************************************************/
/*																	*/
/* Function name : OnBrowse											*/
/* Description   : Browse for folder.								*/
/*																	*/
/********************************************************************/
void CWizardPage4::OnBrowse() 
{
	CString strDir = BrowseForFolder(m_hWnd, "Select a directory:", BIF_RETURNONLYFSDIRS);
	if (!strDir.IsEmpty())
	{
		GetDlgItem(IDC_LOCALFOLDER)->SetWindowText(strDir);
	}	
}


IMPLEMENT_DYNCREATE(CWizardFinish, CPropertyPageEx)

CWizardFinish::CWizardFinish() : CPropertyPageEx(CWizardFinish::IDD)
{
	//{{AFX_DATA_INIT(CWizardFinish)
	m_bConnectNow = FALSE;
	//}}AFX_DATA_INIT
	m_psp.dwFlags |= PSP_HIDEHEADER;
}

CWizardFinish::~CWizardFinish()
{
}

void CWizardFinish::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPageEx::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CWizardFinish)
	DDX_Check(pDX, IDC_CONNECTNOW, m_bConnectNow);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CWizardFinish, CPropertyPageEx)
	//{{AFX_MSG_MAP(CWizardFinish)
	ON_BN_CLICKED(IDC_CONNECTNOW, OnConnectnow)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnSetActive										*/
/* Description   : Called when this becomes the active page.		*/
/*																	*/
/********************************************************************/
BOOL CWizardFinish::OnSetActive() 
{
	CPropertySheetEx* parent = (CPropertySheetEx*)GetParent();
	parent->SetWizardButtons( PSWIZB_BACK | PSWIZB_NEXT | PSWIZB_FINISH);	
	return CPropertyPageEx::OnSetActive();
}


/********************************************************************/
/*																	*/
/* Function name : OnConnectnow										*/
/* Description   :													*/
/*																	*/
/********************************************************************/
void CWizardFinish::OnConnectnow() 
{
	UpdateData();	
}

