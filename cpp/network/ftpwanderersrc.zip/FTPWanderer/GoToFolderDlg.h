#if !defined(AFX_GOTOFOLDERDLG_H__D4DFE1F0_F373_432E_B3EC_B96462280FA4__INCLUDED_)
#define AFX_GOTOFOLDERDLG_H__D4DFE1F0_F373_432E_B3EC_B96462280FA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GoToFolderDlg.h : header file
//

#include "HistoryCombo.h"

/////////////////////////////////////////////////////////////////////////////
// CGoToFolderDlg dialog

class CGoToFolderDlg : public CDialog
{
// Construction
public:
	CGoToFolderDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CGoToFolderDlg)
	enum { IDD = IDD_GOTOFOLDER };
	CHistoryCombo	m_cmbFolder;
	CString	m_strFolder;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGoToFolderDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CGoToFolderDlg)
	virtual BOOL OnInitDialog();
	virtual void OnOK();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GOTOFOLDERDLG_H__D4DFE1F0_F373_432E_B3EC_B96462280FA4__INCLUDED_)
