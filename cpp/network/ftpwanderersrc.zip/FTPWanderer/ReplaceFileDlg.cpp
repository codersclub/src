/****************************************************************/
/*																*/
/*  ReplaceFileDlg.cpp											*/
/*																*/
/*  Implementation of the CReplaceFileDlg class.				*/
/*																*/
/*	This file is part of the FTP Wanderer application.			*/
/*  Creates a dialog that resembles the Microsoft Explorer one.	*/
/*																*/
/*  Programed by Pablo van der Meer								*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/

#include "stdafx.h"
#include "ftpwanderer.h"
#include "ReplaceFileDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReplaceFileDlg dialog


CReplaceFileDlg::CReplaceFileDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReplaceFileDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReplaceFileDlg)
	m_strPropertiesNew = _T("");
	m_strPropertiesOld = _T("");
	//}}AFX_DATA_INIT
	m_nFileCount = 0;
}


void CReplaceFileDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReplaceFileDlg)
	DDX_Text(pDX, IDC_PROPERTIES_NEW, m_strPropertiesNew);
	DDX_Text(pDX, IDC_PROPERTIES_OLD, m_strPropertiesOld);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReplaceFileDlg, CDialog)
	//{{AFX_MSG_MAP(CReplaceFileDlg)
	ON_BN_CLICKED(IDYES, OnYes)
	ON_BN_CLICKED(IDYESTOALL, OnYestoall)
	ON_BN_CLICKED(IDNO, OnNo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CReplaceFileDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString strText;	
	strText.Format("This folder already contains a file named '%s'", m_strFileName);
	SetDlgItemText(IDC_WARNING, strText);
	
	SHFILEINFO sfi;
	memset(&sfi, 0, sizeof(sfi));

	SHGetFileInfo(m_strFileName,  
//			m_bIsDirectory ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_NORMAL,
			FILE_ATTRIBUTE_NORMAL,
			&sfi, 
			sizeof(sfi), 
			SHGFI_LARGEICON | SHGFI_ICON | SHGFI_USEFILEATTRIBUTES);
	SendDlgItemMessage(IDC_ICON_OLD, STM_SETICON, (WPARAM) sfi.hIcon, 0);
	SendDlgItemMessage(IDC_ICON_NEW, STM_SETICON, (WPARAM) sfi.hIcon, 0);

	if (m_nFileCount == 1)
	{
		CRect rcButton;
		// reposition 'Yes' button
		GetDlgItem(IDNO)->GetWindowRect(rcButton);
		ScreenToClient(rcButton);
		GetDlgItem(IDYES)->MoveWindow(rcButton);
		
		// reposition 'No' button
		GetDlgItem(IDCANCEL)->GetWindowRect(rcButton);
		ScreenToClient(rcButton);
		GetDlgItem(IDNO)->MoveWindow(rcButton);

		// hide 'Cancel' and 'Yes To All' buttons
		GetDlgItem(IDCANCEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDYESTOALL)->ShowWindow(SW_HIDE);
	}
	return TRUE;
}

void CReplaceFileDlg::OnYes() 
{
	EndDialog(IDYES);
}

void CReplaceFileDlg::OnYestoall() 
{
	EndDialog(IDYESTOALL);
}

void CReplaceFileDlg::OnNo() 
{
	EndDialog(IDNO);	
}
