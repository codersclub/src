#if !defined(AFX_TRACEVIEW_H__E8CC4284_0F36_4A67_9A27_10EA07BEF6FF__INCLUDED_)
#define AFX_TRACEVIEW_H__E8CC4284_0F36_4A67_9A27_10EA07BEF6FF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ColorListBox.h"

class CTraceView : public CView
{
protected:
	CTraceView();           // protected constructor used by dynamic creation
	DECLARE_DYNCREATE(CTraceView)

// Attributes
public:
	CColorListBox& GetListBox()
	{
		return m_ListBox; 
	};
	void AddTraceLine(int nType, LPCTSTR pstrFormat, ...);

// Operations
public:
// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTraceView)
	protected:
	virtual void OnInitialUpdate();     // first time after construct
	virtual void OnDraw(CDC* pDC);
	//}}AFX_VIRTUAL

// Implementation
protected:
	virtual ~CTraceView();
#ifdef _DEBUG
#endif
	CColorListBox m_ListBox;

	// Generated message map functions
	//{{AFX_MSG(CTraceView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRACEVIEW_H__E8CC4284_0F36_4A67_9A27_10EA07BEF6FF__INCLUDED_)
