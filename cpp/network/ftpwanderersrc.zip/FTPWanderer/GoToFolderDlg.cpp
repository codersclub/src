/****************************************************************/
/*																*/
/*  GoToFolderDlg.cpp											*/
/*																*/
/*  Implementation of the CGoToFolderDlg class.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "GoToFolderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CGoToFolderDlg::CGoToFolderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGoToFolderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGoToFolderDlg)
	m_strFolder = _T("");
	//}}AFX_DATA_INIT
}


void CGoToFolderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGoToFolderDlg)
	DDX_Control(pDX, IDC_COMBO, m_cmbFolder);
	DDX_CBString(pDX, IDC_COMBO, m_strFolder);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGoToFolderDlg, CDialog)
	//{{AFX_MSG_MAP(CGoToFolderDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog								*/
/*																	*/
/********************************************************************/
BOOL CGoToFolderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_cmbFolder.LoadMRU("GoToFolder");
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnOK												*/
/* Description   : Save entered string and close dialog.			*/
/*																	*/
/********************************************************************/
void CGoToFolderDlg::OnOK() 
{
	// clear list if SHIFT+OK is pressed
	if (GetKeyState(VK_SHIFT) < 0)
		m_cmbFolder.ResetMRU();
	else
		m_cmbFolder.AddStringEx();

	CDialog::OnOK();
}
