#if !defined(AFX_TRANSFERMANAGERDLG_H__BE6FB8A8_8220_4377_9ABF_BEDB5C9F2359__INCLUDED_)
#define AFX_TRANSFERMANAGERDLG_H__BE6FB8A8_8220_4377_9ABF_BEDB5C9F2359__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "DownloadThread.h"
#include "UploadThread.h"

class CTransferManagerDlg : public CDialog
{
    // list of thread pointers
    CTypedPtrList<CObList, CDownloadThread*>  m_DownloadThreads;
    CTypedPtrList<CObList, CUploadThread*>  m_UploadThreads;

// Construction
public:
	int m_nConnectionTimeout;
	BOOL m_bBuildingQueue;
	void QueueUpload(LPCTSTR lpszServerName, LPCTSTR lpszUserName, LPCTSTR lpszPassword, LPCTSTR lpszLocalName, LPCTSTR lpszRemoteName, LPCTSTR lpszCurrentDirectory, DWORD dwTransferType = FTP_TRANSFER_TYPE_BINARY, int nRetries = 1, int nRetryDelay = 10, int nPort = 21, BOOL bUsePASVMode = FALSE, BOOL bFailed = FALSE);
	void QueueDownload(LPCTSTR lpszServerName, LPCTSTR lpszUserName, LPCTSTR lpszPassword, LPCTSTR lpszRemoteName, LPCTSTR lpszLocalName, LPCTSTR lpszCurrentDirectory, DWORD dwFileLength, DWORD dwTransferType = FTP_TRANSFER_TYPE_BINARY, int nRetries = 1, int nRetryDelay = 10, int nPort = 21, BOOL bUsePASVMode = FALSE, BOOL bFailed = FALSE);
	~CTransferManagerDlg();
	BOOL Create(BOOL bShow = FALSE);
	CTransferManagerDlg(CWnd* pParent = NULL);   // standard constructor
	int m_nMaximumTransfers;
	BOOL m_bRemoveFailed;

	// Dialog Data
	//{{AFX_DATA(CTransferManagerDlg)
	enum { IDD = IDD_TRANSFERMANAGER };
	CListCtrl	m_QueueList;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTransferManagerDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	virtual void PostNcDestroy();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL InitListViewImageList();
	void CheckTransferQueue();
	int m_nActiveTransfers;
	BOOL m_bShow;
	HICON m_hIcon;

	HACCEL  m_hAccelTable; 

	// Generated message map functions
	//{{AFX_MSG(CTransferManagerDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	virtual void OnOK();
	virtual void OnCancel();
	afx_msg void OnClose();
	afx_msg void OnDestroy();
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRclickQueuelist(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnEditSelectall();
	afx_msg void OnEditInvertselection();
	afx_msg void OnTransferCancel();
	afx_msg void OnTransferResubmit();
	afx_msg void OnTransferExit();
	//}}AFX_MSG
	LRESULT OnDownloadFinished(WPARAM wParam, LPARAM lParam);
	LRESULT OnUploadFinished(WPARAM wParam, LPARAM lParam);
	LRESULT OnFtpStatus(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRANSFERMANAGERDLG_H__BE6FB8A8_8220_4377_9ABF_BEDB5C9F2359__INCLUDED_)
