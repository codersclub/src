/****************************************************************/
/*																*/
/*  TraceView.cpp	 											*/
/*																*/
/*  Implementation of the CTraceView class.						*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "TraceView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define IDC_LIST1 280369

IMPLEMENT_DYNCREATE(CTraceView, CView)

CTraceView::CTraceView()
{ 
}

CTraceView::~CTraceView()
{
}


BEGIN_MESSAGE_MAP(CTraceView, CView)
	//{{AFX_MSG_MAP(CTraceView)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_CTLCOLOR()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CTraceView::OnInitialUpdate()
{
	CView::OnInitialUpdate();
}


int CTraceView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// Create the style
	DWORD dwStyle = WS_CHILD | WS_VISIBLE | LBS_NOINTEGRALHEIGHT | 
					LBS_OWNERDRAWVARIABLE | LBS_HASSTRINGS | WS_VSCROLL | WS_HSCROLL;

	// Create the list control.
	BOOL bResult = m_ListBox.Create(dwStyle, CRect(0,0,0,0), this, IDC_LIST1); 

	if (bResult)
	{
		// change default font to something nicer
		HFONT hFont = (HFONT)::GetStockObject(ANSI_VAR_FONT);
		m_ListBox.SendMessage(WM_SETFONT, (WPARAM) hFont, 0);
		// make the window visible
		m_ListBox.ShowWindow(SW_SHOW);
	}
	return (bResult ? 0 : -1);
}

void CTraceView::OnSize(UINT nType, int cx, int cy) 
{
	CView::OnSize(nType, cx, cy);
	
	if (::IsWindow(m_ListBox.m_hWnd))
		m_ListBox.MoveWindow(0, 0, cx, cy, TRUE);
}

void CTraceView::OnDraw(CDC* pDC) 
{
	
}


void CTraceView::AddTraceLine(int nType, LPCTSTR pstrFormat, ...)
{
	CString str;

	// format and write the data we were given
	va_list args;
	va_start(args, pstrFormat);
	str.FormatV(pstrFormat, args);

	// if too much entries -> delete first item
	if (m_ListBox.GetCount() > 255)
	{
		m_ListBox.DeleteString(0);
	}

	switch(nType)
	{
		case 1:
			m_ListBox.AddString(str, RGB(0,130,0));
			break;
		case 2:
			m_ListBox.AddString(str, RGB(0,0,255));
			break;
		case 3:
			m_ListBox.AddString(str, RGB(255,0,0));
			break;
		default:
			m_ListBox.AddString(str);
			break;
	}
	TRACE1("%s\n", str);
	m_ListBox.SetCurSel(m_ListBox.GetCount()-1);
}


HBRUSH CTraceView::OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor) 
{
	HBRUSH hbr = CView::OnCtlColor(pDC, pWnd, nCtlColor);
	
	if (nCtlColor == CTLCOLOR_LISTBOX)
	{
		pDC->SetBkColor(GetSysColor(COLOR_3DFACE));
		return (HBRUSH)GetSysColorBrush(COLOR_3DFACE);
	}
	// TODO: Return a different brush if the default is not desired
	return hbr;
}
