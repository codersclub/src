/****************************************************************/
/*																*/
/*  FtpWandererDoc.cpp											*/
/*																*/
/*  Implementation of the CFtpWandererDoc class.				*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "FtpWanderer.h"
#include "MainFrm.h"
#include "FtpWandererDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFtpWandererDoc

IMPLEMENT_DYNCREATE(CFtpWandererDoc, CDocument)

BEGIN_MESSAGE_MAP(CFtpWandererDoc, CDocument)
	//{{AFX_MSG_MAP(CFtpWandererDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFtpWandererDoc construction/destruction

CFtpWandererDoc::CFtpWandererDoc()
{
	// TODO: add one-time construction code here

}

CFtpWandererDoc::~CFtpWandererDoc()
{
}

BOOL CFtpWandererDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CFtpWandererDoc serialization

void CFtpWandererDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CFtpWandererDoc diagnostics

#ifdef _DEBUG
void CFtpWandererDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CFtpWandererDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG



/********************************************************************/
/*																	*/
/* Function name : OnOpenDocument									*/
/* Description   : Virtual override to connect to site.				*/
/*																	*/
/********************************************************************/
BOOL CFtpWandererDoc::OnOpenDocument(LPCTSTR lpszPathName) 
{
	CString strPathName = lpszPathName;
	
	// strip 'bogus' path
	int nPos = strPathName.ReverseFind('\\');
	if (nPos != -1)
		strPathName = strPathName.Mid(nPos + 1);

	((CMainFrame *)AfxGetMainWnd())->Connect(strPathName);
	return TRUE;
}

