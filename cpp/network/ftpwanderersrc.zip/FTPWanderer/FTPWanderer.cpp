/****************************************************************/
/*																*/
/*  FtpWanderer.cpp												*/
/*																*/
/*  Defines the class behaviors for the application.			*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "FtpWanderer.h"
#include <afxadv.h>
#include "MainFrm.h"
#include "FtpWandererDoc.h"
#include "FtpTreeView.h"
#include "AboutDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


BEGIN_MESSAGE_MAP(CFtpWandererApp, CWinApp)
	//{{AFX_MSG_MAP(CFtpWandererApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	ON_COMMAND(ID_HELP_INDEX, OnHelpIndex)
	//}}AFX_MSG_MAP
	// Standard file based document commands
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFtpWandererApp construction

CFtpWandererApp::CFtpWandererApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CFtpWandererApp object

CFtpWandererApp theApp;


/********************************************************************/
/*																	*/
/* Function name : InitInstance										*/
/* Description   : CFtpWandererApp initialization.					*/
/*																	*/
/********************************************************************/
BOOL CFtpWandererApp::InitInstance()
{
	if (!AfxSocketInit())
	{
		AfxMessageBox(IDP_SOCKETS_INIT_FAILED);
		return FALSE;
	}

	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	InitCommonControls();

	// Change the registry key under which our settings are stored.
	// TODO: You should modify this string to be something appropriate
	// such as the name of your company or organization.
	SetRegistryKey(_T("Pablo Software Solutions"));

	LoadStdProfileSettings();  // Load standard INI file options (including MRU)
	FixList();
	// Register the application's document templates.  Document templates
	//  serve as the connection between documents, frame windows and views.

	CSingleDocTemplate* pDocTemplate;
	pDocTemplate = new CSingleDocTemplate(
		IDR_MAINFRAME,
		RUNTIME_CLASS(CFtpWandererDoc),
		RUNTIME_CLASS(CMainFrame),       // main SDI frame window
		RUNTIME_CLASS(CFtpTreeView));
	AddDocTemplate(pDocTemplate);

	// Parse command line for standard shell commands, DDE, file open
	CCommandLineInfo cmdInfo;
	ParseCommandLine(cmdInfo);

	// Dispatch commands specified on the command line
	if (!ProcessShellCommand(cmdInfo))
		return FALSE;

	// The one and only window has been initialized, so show and update it.
	m_pMainWnd->ShowWindow(SW_SHOW);
	m_pMainWnd->UpdateWindow();

	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnAppAbout										*/
/* Description   : App command to run the dialog.					*/
/*																	*/
/********************************************************************/
void CFtpWandererApp::OnAppAbout()
{
	CAboutDlg dlg;
	dlg.DoModal();
}


/********************************************************************/
/*																	*/
/* Function name : FixList											*/
/* Description   : Make sure no path names are shown.				*/
/*																	*/
/********************************************************************/
void CFtpWandererApp::FixList()
{
	ASSERT(m_pRecentFileList->m_arrNames != NULL);
	for (int iMRU = 0; iMRU < m_pRecentFileList->m_nSize; iMRU++)
	{
		int nPos = m_pRecentFileList->m_arrNames[iMRU].ReverseFind('\\');
		if (nPos != -1)
		{
			m_pRecentFileList->m_arrNames[iMRU] = m_pRecentFileList->m_arrNames[iMRU].Mid(nPos+1);
		}
	}
}


/********************************************************************/
/*																	*/
/* Function name : AddToRecentFileList								*/
/* Description   : Virtual override which strips path form string.	*/
/*																	*/
/********************************************************************/
void CFtpWandererApp::AddToRecentFileList(LPCTSTR lpszPathName) 
{
	ASSERT_VALID(this);
	ASSERT(lpszPathName != NULL);
	ASSERT(AfxIsValidString(lpszPathName));

	CString strPathName = lpszPathName;

	// strip 'bogus' path
	int nPos = strPathName.ReverseFind('\\');
	if (nPos != -1)
		strPathName = strPathName.Mid(nPos + 1);

	if (m_pRecentFileList != NULL)
	{
		ASSERT(m_pRecentFileList->m_arrNames != NULL);

		// update the MRU list, if an existing MRU string matches file name
		for (int iMRU = 0; iMRU < m_pRecentFileList->m_nSize-1; iMRU++)
		{
			if (m_pRecentFileList->m_arrNames[iMRU].CompareNoCase(strPathName) == 0)
				break;      // iMRU will point to matching entry
		}
		// move MRU strings before this one down
		for (; iMRU > 0; iMRU--)
		{
			ASSERT(iMRU > 0);
			ASSERT(iMRU < m_pRecentFileList->m_nSize);
			m_pRecentFileList->m_arrNames[iMRU] = m_pRecentFileList->m_arrNames[iMRU-1];
		}
		// place this one at the beginning
		m_pRecentFileList->m_arrNames[0] = strPathName;
	}
}


/********************************************************************/
/*																	*/
/* Function name : OnHelpIndex										*/
/* Description   : Command to show help file.						*/
/*																	*/
/********************************************************************/
void CFtpWandererApp::OnHelpIndex() 
{
	// launch help
	::WinHelp(AfxGetMainWnd()->m_hWnd, AfxGetApp()->m_pszHelpFilePath, HELP_CONTENTS, 0L);	
}
