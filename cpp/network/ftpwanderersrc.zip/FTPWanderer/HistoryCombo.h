#if !defined(AFX_HISTORYCOMBO_H__E47C91A9_9123_4DFB_9C0E_A7CCFB22FFC2__INCLUDED_)
#define AFX_HISTORYCOMBO_H__E47C91A9_9123_4DFB_9C0E_A7CCFB22FFC2__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "RegKey.h"

class CHistoryCombo : public CComboBox
{
	class CMRUStrings  
	{
	public:
		void Clear();
		BOOL Create(HKEY hKeyParent, LPCTSTR lpszKeyName, CString& strName);
		BOOL SetString(int i, CString& strVal);
		BOOL GetString(int i, CString& strVal);
		BOOL DeleteString(int i);
		CMRUStrings() 
		{

		};
		virtual ~CMRUStrings() 
		{
		};

	protected:
		CStringArray m_strItemData;
		CString m_strName;
		int m_cElementsMax;
		CRegKey m_regKey;
	};

	CMRUStrings m_mruCmds;
// Construction
public:
	CHistoryCombo();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CHistoryCombo)
	public:
	//}}AFX_VIRTUAL

// Implementation
public:
	void ResetMRU();
	int AddStringEx(LPCTSTR lpszText = NULL);
	void LoadMRU(LPCTSTR lpszName);
	void SaveMRU();

	virtual ~CHistoryCombo();

	// Generated message map functions
protected:
	int m_nMaxHistoryLength;
	//{{AFX_MSG(CHistoryCombo)
	afx_msg void OnDestroy();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_HISTORYCOMBO_H__E47C91A9_9123_4DFB_9C0E_A7CCFB22FFC2__INCLUDED_)
