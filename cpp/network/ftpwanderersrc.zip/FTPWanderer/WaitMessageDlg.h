#if !defined(AFX_WAITMESSAGEDLG_H__1B13409E_FBE5_4B48_932D_D041025A6FF0__INCLUDED_)
#define AFX_WAITMESSAGEDLG_H__1B13409E_FBE5_4B48_932D_D041025A6FF0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// WaitMessageDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CWaitMessageDlg dialog

class CWaitMessageDlg : public CDialog
{
// Construction
public:
	CString m_strMessage;
	int m_nRetryDelay;
	CWaitMessageDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CWaitMessageDlg)
	enum { IDD = IDD_WAITMESSAGE };
	CProgressCtrl	m_ProgressCtrl;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CWaitMessageDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CWaitMessageDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_WAITMESSAGEDLG_H__1B13409E_FBE5_4B48_932D_D041025A6FF0__INCLUDED_)
