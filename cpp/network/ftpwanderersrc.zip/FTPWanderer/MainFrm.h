// MainFrm.h : interface of the CMainFrame class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_MAINFRM_H__32F4E04C_9657_4672_A536_91C0FF226933__INCLUDED_)
#define AFX_MAINFRM_H__32F4E04C_9657_4672_A536_91C0FF226933__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "MyInternetSession.h"
#include <afxtempl.h>
#include "FtpSite.h"
#include "SplitterWndEx.h"
#include "TransferManagerDlg.h"
#include "QuickConnectDlg.h"

class CFtpListView;
class CFtpTreeView;
class CTraceView;

class CMainFrame : public CFrameWnd
{
	friend CFtpListView;
	friend CFtpTreeView;
protected: // create from serialization only
	CMainFrame();
	DECLARE_DYNCREATE(CMainFrame)

// Attributes
protected:
	CSplitterWndEx m_wndSplitter;
	CSplitterWnd m_wndSplitter2;

public:
	void ChangeDirectory(LPCTSTR lpszDirectory);
	void DownloadFile(LPCTSTR lpszFileName, DWORD dwFileLength, LPCTSTR lpszDestination = NULL);
	void UploadFile(LPCTSTR lpszFileName, LPCTSTR lpszDestination = NULL);
	void DownloadDirectory(LPCTSTR lpszDirectory, LPCTSTR lpszDestination);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMainFrame)
	public:
	virtual BOOL OnCreateClient(LPCREATESTRUCT lpcs, CCreateContext* pContext);
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	virtual BOOL OnNotify(WPARAM wParam, LPARAM lParam, LRESULT* pResult);
	//}}AFX_VIRTUAL
	
	// undocumented overridable
	virtual void OnUpdateFrameTitle(BOOL bAddToTitle);

// Implementation
public:
	void DoFileDownload(BOOL bShowFileDialog);
	void AddNewFile(LPCTSTR lpszFileName,  DWORD dwFileLength, LPCTSTR lpszCurrentDirectory);
	void AddNewFolder(LPCTSTR lpszFileName, LPCTSTR lpszCurrentDirectory);
	void Connect(LPCTSTR lpszSiteName = NULL, LPCTSTR lpszUserName = NULL, LPCTSTR lpszPassword = NULL);
	HTREEITEM m_hCurrentTreeItem;
	CString m_strMessages;

	CString m_strCurrentDirectory;

	virtual ~CMainFrame();
	CFtpListView* GetFtpListView();
	CFtpTreeView* GetFtpTreeView();
	CTraceView* GetTraceView() { return m_pTraceView; };
	CTraceView* m_pTraceView;

	void OnSelchanged(NMHDR* pNMHDR, LRESULT* pResult);
	void OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);

#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:  // control bar embedded members
	CStatusBar  m_wndStatusBar;
	CToolBar    m_wndToolBar;
//	CReBar      m_wndReBar;
	BOOL CreateHotToolBar();
//	CDialogBar      m_wndDlgBar;

	CMyInternetSession *m_pInternetSession;
	CFtpConnection *m_pFtpConnection;
	CFtpSite m_FtpSite;

	void PopulateTree(const CString& strDir = CString((LPCTSTR) NULL), BOOL bDoNotReset = FALSE);
	BOOL ExploreDirectory(const CString& strDir, HTREEITEM hParent, BOOL bRefresh = FALSE);

// Generated message map functions
protected:
	CQuickConnectDlg m_wndQuickConnect;
	BOOL m_bInitialized;
	BOOL m_bShowTransferManager;
	CTransferManagerDlg *m_pTransferManager;

	BOOL RecursiveFileList(LPCTSTR lpszPath, CStringArray &strFileNameArray);
	BOOL RecursiveEmptyDirectory(LPCTSTR lpszPath);

	BOOL m_bMultipleLevels;
	BOOL m_bShowTrace;
	DWORD m_dwTransferType;
	BOOL m_bNewFolderMode;
	BOOL m_bBusy;
	CString GetLastResponceInfo(LPCTSTR lpszCaption, LPCTSTR lpszExtraInfo = NULL);
	CString m_strOldName;
	CString m_strServerName;
	BOOL IsStillConnected();

	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDblclk(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnFileRename();
	afx_msg void OnFileDelete();
	afx_msg void OnFileExplore();
	afx_msg void OnViewUponelevel();
	afx_msg void OnFileConnect();
	afx_msg void OnUpdateFileDisconnect(CCmdUI* pCmdUI);
	afx_msg void OnFileDisconnect();
	afx_msg void OnFileCancel();
	afx_msg void OnFileDownload();
	afx_msg void OnFileDownloadto();
	afx_msg void OnUpdateActions(CCmdUI* pCmdUI);
	afx_msg void OnFileProperties();
	afx_msg void OnUpdateFileCancel(CCmdUI* pCmdUI);
	afx_msg void OnViewRefresh();
	afx_msg void OnViewGoTo();
	afx_msg void OnFileNewfolder();
	afx_msg void OnViewByname();
	afx_msg void OnViewBysize();
	afx_msg void OnViewBytype();
	afx_msg void OnViewBydate();
	afx_msg void OnFileUpload();
	afx_msg void OnToolsOptions();
	afx_msg void OnToolsAscii();
	afx_msg void OnUpdateToolsAscii(CCmdUI* pCmdUI);
	afx_msg void OnToolsBinary();
	afx_msg void OnUpdateToolsBinary(CCmdUI* pCmdUI);
	afx_msg void OnClose();
	afx_msg void OnViewTrace();
	afx_msg void OnUpdateViewTrace(CCmdUI* pCmdUI);
	afx_msg void OnUpdateFileConnect(CCmdUI* pCmdUI);
	afx_msg void OnViewTransfermanager();
	afx_msg void OnUpdateViewTransfermanager(CCmdUI* pCmdUI);
	afx_msg void OnDestroy();
	afx_msg void OnEditSelectAll();
	afx_msg void OnEditInvertselection();
	afx_msg void OnFileConnectionwizard();
	afx_msg void OnQuickconnect();
	//}}AFX_MSG
	afx_msg void OnUpdateViewStyles(CCmdUI* pCmdUI);
	afx_msg void OnViewStyle(UINT nCommandID);
	LRESULT OnFtpStatus(WPARAM wParam, LPARAM lParam);
	LRESULT OnDownloadFinished(WPARAM wParam, LPARAM lParam);
	LRESULT OnUploadFinished(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__32F4E04C_9657_4672_A536_91C0FF226933__INCLUDED_)
