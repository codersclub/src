/****************************************************************/
/*																*/
/*  QuickConnectDlg.cpp											*/
/*																*/
/*  Implementation of the CQuickConnectDlg class.				*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "QuickConnectDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CQuickConnectDlg::CQuickConnectDlg()
{
	//{{AFX_DATA_INIT(CQuickConnectDlg)
	//}}AFX_DATA_INIT
}


void CQuickConnectDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogBar::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CQuickConnectDlg)
	DDX_Control(pDX, IDC_HOST, m_cmbHost);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CQuickConnectDlg, CDialogBar)
	//{{AFX_MSG_MAP(CQuickConnectDlg)
	ON_CBN_SELCHANGE(IDC_HOST, OnSelchangeHost)
	//}}AFX_MSG_MAP
	ON_MESSAGE(WM_INITDIALOG, OnInitDialog)
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog								*/
/*																	*/
/********************************************************************/
LONG CQuickConnectDlg::OnInitDialog(UINT wParam, LONG lParam)
{
	if (!HandleInitDialog(wParam, lParam) || !UpdateData(FALSE))
    {
		TRACE0("Warning: UpdateData failed during dialog init.\n");
        return FALSE;
	}
	m_cmbHost.LoadMRU("QuickConnect");
	m_cmbHost.SetCurSel(0);
	OnSelchangeHost();

	((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar('*');
    return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : PreTranslateMessage								*/
/* Description   : Prevent accelerator keys to be executed when we	*/
/*				   have the focus.									*/
/*																	*/
/********************************************************************/
BOOL CQuickConnectDlg::PreTranslateMessage(MSG* pMsg) 
{
	// is this a message for us?
	if (IsDialogMessage(pMsg))
		return TRUE;

	return CDialogBar::PreTranslateMessage(pMsg);
}


/********************************************************************/
/*																	*/
/* Function name : OnSelchangeHost									*/
/* Description   : Get item data (username/password)				*/
/*																	*/
/********************************************************************/
void CQuickConnectDlg::OnSelchangeHost() 
{
	int nIndex = m_cmbHost.GetCurSel();
	if (nIndex == -1)
		return;

	CString *pItemData = (CString *)m_cmbHost.GetItemDataPtr(nIndex);
	if (pItemData)
	{
		CString strText;
		AfxExtractSubString(strText, *pItemData, 0, ',');
		SetDlgItemText(IDC_USERNAME, strText);
		AfxExtractSubString(strText, *pItemData, 1, ',');
		SetDlgItemText(IDC_PASSWORD, strText);
	}
}
