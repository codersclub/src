#if !defined(AFX_UPLOADTHREAD_H__A01390EE_E22B_4D30_B933_90D90F2C18EE__INCLUDED_)
#define AFX_UPLOADTHREAD_H__A01390EE_E22B_4D30_B933_90D90F2C18EE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProgressDlg.h"

#define BUF_SIZE 4096

class CUploadThread : public CWinThread
{
	DECLARE_DYNCREATE(CUploadThread)
protected:

	CInternetSession m_InternetSession;
	CFtpConnection *m_pFtpConnection;
	CFile m_File;
	CString m_strResult;
	void UploadFile(CString & source, CString & dest);
	void WaitForProgressDialog();
	void PostUploadStatus(LPCTSTR lpszStatus);

// Attributes
public:
	CUploadThread();
	virtual ~CUploadThread();

	CWnd m_wndDummy;
// Operations
public:
	BOOL m_bTransferFailed;
	CWnd *m_pTransferManager;
	CString m_strCurrentDirectory;
	CString GetLastError();
	CString m_strLocalName;
	CString m_strRemoteName;
	CString m_strPassword;
	CString m_strUserName;
	CString m_strServerName;
	DWORD m_nConnectionTimeout;
	DWORD m_dwFileLength;
	DWORD m_dwTransferType;
	int		m_nRetries;
	int		m_nRetryDelay;
	int		m_nPort;
	int		m_bUsePASVMode;

	virtual void Delete();
	HANDLE m_hEventDead;
	HANDLE m_hEventKill;
	void KillThread();

	CProgressDlg m_ProgressDlg;
	char m_szStatus[1024];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CUploadThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CUploadThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_UPLOADTHREAD_H__A01390EE_E22B_4D30_B933_90D90F2C18EE__INCLUDED_)
