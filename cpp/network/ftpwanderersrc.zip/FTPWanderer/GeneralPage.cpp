/****************************************************************/
/*																*/
/*  GeneralPage.cpp												*/
/*																*/
/*  Implementation of the CGeneralPage class.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "GeneralPage.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CGeneralPage, CPropertyPage)

CGeneralPage::CGeneralPage() : CPropertyPage(CGeneralPage::IDD)
{
	//{{AFX_DATA_INIT(CGeneralPage)
	m_strDate = _T("");
	m_strDescription = _T("");
	m_strFileName = _T("");
	m_strGroup = _T("");
	m_strLocation = _T("");
	m_strOwner = _T("");
	m_strPermission = _T("");
	m_strSize = _T("");
	m_strType = _T("");
	//}}AFX_DATA_INIT
	m_bIsDirectory = FALSE;
}

CGeneralPage::~CGeneralPage()
{
}

void CGeneralPage::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralPage)
	DDX_Text(pDX, IDC_DATE, m_strDate);
	DDX_Text(pDX, IDC_DESCRIPTION, m_strDescription);
	DDX_Text(pDX, IDC_FILENAME, m_strFileName);
	DDX_Text(pDX, IDC_GROUP, m_strGroup);
	DDX_Text(pDX, IDC_LOCATION, m_strLocation);
	DDX_Text(pDX, IDC_OWNER, m_strOwner);
	DDX_Text(pDX, IDC_PERMISSION, m_strPermission);
	DDX_Text(pDX, IDC_FILE_SIZE, m_strSize);
	DDX_Text(pDX, IDC_TYPE, m_strType);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneralPage, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralPage)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CGeneralPage::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();

	GetSystemIcon();
	return TRUE;
}


void CGeneralPage::GetSystemIcon()
{
	SHFILEINFO sfi;
	memset(&sfi, 0, sizeof(sfi));

	SHGetFileInfo(m_strFileName,  
			m_bIsDirectory ? FILE_ATTRIBUTE_DIRECTORY : FILE_ATTRIBUTE_NORMAL, 
			&sfi, 
			sizeof(sfi), 
			SHGFI_LARGEICON | SHGFI_ICON | SHGFI_USEFILEATTRIBUTES);
	SendDlgItemMessage(IDC_FILE_ICON, STM_SETICON, (WPARAM) sfi.hIcon, 0);
}
