// FTPListView.h : interface of the CFTPListView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FTPLISTVIEW_H__1C6F9B01_29CF_4923_9F45_ECA8D19037B4__INCLUDED_)
#define AFX_FTPLISTVIEW_H__1C6F9B01_29CF_4923_9F45_ECA8D19037B4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

//#include "MyAnimateCtrl.h"

class CFtpListView : public CListView
{
public:
	typedef struct tagITEMINFO 
	{
		CString strFileName; 
		DWORD   nFileSize; 
		CString strType; 
		FILETIME ftLastWriteTime; 
		BOOL	bIsDirectory;
	} ITEMINFO;

protected: // create from serialization only
	CFtpListView();
	DECLARE_DYNCREATE(CFtpListView)
	
// Attributes
public:
	CFtpWandererDoc* GetDocument();

	int AddItem(int nIndex, CFtpFileFind* pFileFind);
	int AddNewFolder(int nIndex, LPCTSTR lpszFolder);
	int AddNewFile(int nIndex, LPCTSTR lpszFileName, DWORD dwFileSize);
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtpListView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	//}}AFX_VIRTUAL

// Implementation
public:
	void ActivateAnimation(BOOL bOn = TRUE);
	BOOL IsEditing();
	void SetFileName(int nIndex, LPCTSTR lpszFileName);
	void Sort(int nCol = -1);
	BOOL IsDirectory(int nItem);
	DWORD GetFileSize(int nItem);
	FILETIME GetLastWriteTime(int nItem);
	char* FormatSize(DWORD dwSizeLow, DWORD dwSizeHigh = 0);

	virtual ~CFtpListView();
#ifdef _DEBUG
#endif

protected:
	int m_nSortedCol;
	void FreeItemMemory();
	void RecursiveFileList(LPCTSTR lpszPath, CStringArray &strFileNameArray);
	char* GetTypeName(CString strPath);
	BOOL InitListViewImageLists();
	CAnimateCtrl m_AnimateCtrl;

	static int CALLBACK CompareFunc (LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);


// Generated message map functions
protected:
	BOOL m_bSearching;
	BOOL m_bEditMode;
	//{{AFX_MSG(CFtpListView)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnEndlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnGetdispinfo(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnColumnClick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeleteitem(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnBeginlabeledit(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg HBRUSH OnCtlColor(CDC* pDC, CWnd* pWnd, UINT nCtlColor);
	afx_msg void OnRclick(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDropFiles(HDROP hDropInfo);
	afx_msg void OnOdcachehint(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	afx_msg void OnStyleChanged(int nStyleType, LPSTYLESTRUCT lpStyleStruct);
//	afx_msg void OnItemclick(NMHDR* pNMHDR, LRESULT* pResult);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FtpListView.cpp
inline CFtpWandererDoc* CFtpListView::GetDocument()
   { return (CFtpWandererDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPLISTVIEW_H__1C6F9B01_29CF_4923_9F45_ECA8D19037B4__INCLUDED_)
