/****************************************************************/
/*																*/
/*  ConnectDlg.cpp												*/
/*																*/
/*  Implementation of the CConnectDlg class.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "ConnectDlg.h"
#include "WizardPages.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CConnectDlg::CConnectDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CConnectDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CConnectDlg)
	m_strAddress = _T("");
	m_bAnonymous = FALSE;
	m_nRetries = 3;
	m_strDescription = _T("");
	m_strLocalPath = _T("");
	m_strLogin = _T("");
	m_strName = _T("");
	m_strPassword = _T("");
	m_nPort = 21;
	m_strRemotePath = _T("");
	m_nRetryDelay = 10;
	m_bUsePASVMode = FALSE;
	//}}AFX_DATA_INIT

	GetAppDir(m_strFilename);
	m_strFilename += "sites.dat";

	m_bModified = FALSE;
}


void CConnectDlg::DoDataExchange(CDataExchange* pDX)
{	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectDlg)
	DDX_Control(pDX, IDC_PROFILE_NAME, m_wndInfobarCtrl);
	DDX_Control(pDX, IDC_SITES, m_listSites);
	DDX_Text(pDX, IDC_ADDRESS, m_strAddress);
	DDX_Check(pDX, IDC_ANONYMOUS, m_bAnonymous);
	DDX_Text(pDX, IDC_RETRIES, m_nRetries);
	DDX_Text(pDX, IDC_DESCRIPTION, m_strDescription);
	DDX_Text(pDX, IDC_LOCALPATH, m_strLocalPath);
	DDX_Text(pDX, IDC_LOGIN, m_strLogin);
	DDX_Text(pDX, IDC_NAME, m_strName);
	DDX_Text(pDX, IDC_PASSWORD, m_strPassword);
	DDX_Text(pDX, IDC_PORT, m_nPort);
	DDX_Text(pDX, IDC_REMOTEPATH, m_strRemotePath);
	DDX_Text(pDX, IDC_RETRYDELAY, m_nRetryDelay);
	DDX_Check(pDX, IDC_USE_PASVMODE, m_bUsePASVMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectDlg, CDialog)
	//{{AFX_MSG_MAP(CConnectDlg)
	ON_BN_CLICKED(IDC_SAVE, OnSave)
	ON_BN_CLICKED(IDC_ADD, OnAdd)
	ON_LBN_SELCHANGE(IDC_SITES, OnSelchangeSites)
	ON_BN_CLICKED(IDC_REMOVE, OnRemove)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_LBN_DBLCLK(IDC_SITES, OnDblclkSites)
	ON_BN_CLICKED(IDC_ANONYMOUS, OnAnonymous)
	ON_EN_CHANGE(IDC_NAME, OnChangeName)
	ON_BN_CLICKED(IDC_WIZARD, OnWizard)
	ON_EN_CHANGE(IDC_LOCALPATH, OnSomethingChanged)
	ON_EN_CHANGE(IDC_DESCRIPTION, OnSomethingChanged)
	ON_EN_CHANGE(IDC_RETRIES, OnSomethingChanged)
	ON_EN_CHANGE(IDC_ADDRESS, OnSomethingChanged)
	ON_EN_CHANGE(IDC_PASSWORD, OnSomethingChanged)
	ON_EN_CHANGE(IDC_PORT, OnSomethingChanged)
	ON_EN_CHANGE(IDC_REMOTEPATH, OnSomethingChanged)
	ON_EN_CHANGE(IDC_RETRYDELAY, OnSomethingChanged)
	ON_BN_CLICKED(IDC_USE_PASVMODE, OnSomethingChanged)
	ON_EN_CHANGE(IDC_LOGIN, OnChangeLogin)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI(IDC_SAVE, OnUpdateSave)
	ON_UPDATE_COMMAND_UI(IDC_REMOVE, OnUpdateRemove)
	ON_UPDATE_COMMAND_UI(IDOK, OnUpdateConnect)
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog								*/
/*																	*/
/********************************************************************/
BOOL CConnectDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// center in parent
	CenterWindow();

	// get site data
	Serialize(FALSE);	

	// fill sites list
	for (int i=0; i < m_SitesArray.GetSize(); i++)
	{
		int nIndex = m_listSites.AddString(m_SitesArray[i].m_strName);
		m_listSites.SetItemData(nIndex, i);
	}
	int nIndex = AfxGetApp()->GetProfileInt("Settings", "LastSelectedSite", 0);
	m_listSites.SetCurSel(nIndex);
	OnSelchangeSites();

	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : Serialize										*/
/* Description   : Call this function to store/load the site data	*/
/*																	*/
/********************************************************************/
BOOL CConnectDlg::Serialize(BOOL bStoring)
{
	static const TCHAR* lpszSignature = _T("Pablo Software Solutions - StoreObject");

	CFile file;

	if (file.Open(m_strFilename, bStoring ? CFile::modeWrite|CFile::modeCreate : CFile::modeRead))
	{
		TRY
		{
			CString str; 
			CArchive ar(&file, bStoring ? CArchive::store : CArchive::load);
			
			if (bStoring)
			{
				// save signature
				ar << CString(lpszSignature);

				// Save the changed site details
				for (int i=0; i < m_SitesArray.GetSize(); i++)
				{
					m_SitesArray[i].Serialize(ar);
				}

				ar.Flush();
				m_bModified = FALSE;
//				UpdateDialogControls(this, FALSE);	
			}
			else
			{
				// load signature
				ar >> str;
				// if this the file we are looking for ?
				if (str.Compare(lpszSignature) == 0)
				{
					int nCount=0;

					while(!ar.IsBufferEmpty())
					{
						CFtpSite ftpSite;

						// get site data
						ftpSite.Serialize(ar);
						
						// add site to array
						m_SitesArray.Add(ftpSite);
					}
				}
			}
			ar.Close();
			file.Close();
		}
		CATCH_ALL(e)
		{
			// catch all exceptions that might happen ...
			return FALSE;
		}
		END_CATCH_ALL
	}
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnAdd											*/
/* Description   : Add the entered site to the list					*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnAdd() 
{
	// check stuff ...
	if (!ValidateData())
		return;

	for (int i=0; i<m_listSites.GetCount(); i++)
	{
		CString strName;
		m_listSites.GetText(i, strName);
		if (strName.CompareNoCase(m_strName) == 0)
		{
			// clear name field !
			GetDlgItem(IDC_NAME)->SetWindowText("");
			GetDlgItem(IDC_NAME)->SetFocus();
			return;
		}
	}

	CFtpSite ftpSite;

	int nIndex = m_listSites.AddString(m_strName);
	int nItem = m_SitesArray.Add(ftpSite);
	
	m_listSites.SetItemData(nIndex, nItem);
	m_listSites.SetCurSel(nIndex);	

	m_SitesArray[nItem].m_bUsePASVMode = m_bUsePASVMode;
	m_SitesArray[nItem].m_nRetries = m_nRetries;
	m_SitesArray[nItem].m_nPort = m_nPort;
	m_SitesArray[nItem].m_nRetryDelay = m_nRetryDelay;
	m_SitesArray[nItem].m_strAddress = m_strAddress;
	m_SitesArray[nItem].m_strDescription = m_strDescription;
	m_SitesArray[nItem].m_strLocalPath = m_strLocalPath;
	m_SitesArray[nItem].m_strLogin = m_strLogin;
	m_SitesArray[nItem].m_strName = m_strName;
	m_SitesArray[nItem].m_strPassword = m_strPassword;
	m_SitesArray[nItem].m_strRemotePath = m_strRemotePath;
	
//	UpdateDialogControls(this, FALSE);	
	Serialize(TRUE);
	UpdateDialogControls(this, FALSE);	
}


/********************************************************************/
/*																	*/
/* Function name : OnSave											*/
/* Description   : Save entered data								*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnSave() 
{
	// check stuff ...
	if (!ValidateData())
		return;

	int nIndex = m_listSites.GetCurSel();
	if (nIndex != LB_ERR)
	{
		int nItem = m_listSites.GetItemData(nIndex);
		m_SitesArray[nItem].m_bUsePASVMode = m_bUsePASVMode;
		m_SitesArray[nItem].m_nRetries = m_nRetries;
		m_SitesArray[nItem].m_nPort = m_nPort;
		m_SitesArray[nItem].m_nRetryDelay = m_nRetryDelay;
		m_SitesArray[nItem].m_strAddress = m_strAddress;
		m_SitesArray[nItem].m_strDescription = m_strDescription;
		m_SitesArray[nItem].m_strLocalPath = m_strLocalPath;
		m_SitesArray[nItem].m_strLogin = m_strLogin;
		m_SitesArray[nItem].m_strName = m_strName;
		m_SitesArray[nItem].m_strPassword = m_strPassword;
		m_SitesArray[nItem].m_strRemotePath = m_strRemotePath;
		m_listSites.DeleteString(nIndex);
		nIndex = m_listSites.AddString(m_strName);

		m_listSites.SetItemData(nIndex, nItem);
		m_listSites.SetCurSel(nIndex);	
		Serialize(TRUE);	
		UpdateDialogControls(this, FALSE);	
	}
}


/********************************************************************/
/*																	*/
/* Function name : OnRemove											*/
/* Description   : Remove selected entry from the list				*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnRemove() 
{
	int nIndex = m_listSites.GetCurSel();
	if (nIndex == LB_ERR)
		return;

	int nItem = m_listSites.GetItemData(nIndex);
	// remove site from listbox
	m_listSites.DeleteString(nIndex);
	// remove site from array
	m_SitesArray.RemoveAt(nItem);

	// update item data values
	for (int i=0; i<m_listSites.GetCount(); i++)
	{
		int nItemData = m_listSites.GetItemData(i);
		if (nItemData > nIndex)
			m_listSites.SetItemData(i, nItemData-1);
	}
	Serialize(TRUE);
	UpdateDialogControls(this, FALSE);	

	m_listSites.SetCurSel(0);
	OnSelchangeSites();
}


/********************************************************************/
/*																	*/
/* Function name : OnUpdateConnect									*/
/* Description   : Enable/Disable Connect-button					*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnUpdateConnect(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(((CEdit*)GetDlgItem(IDC_ADDRESS))->GetWindowTextLength());
}


/********************************************************************/
/*																	*/
/* Function name : OnUpdateSave										*/
/* Description   : Enable/Disable Save-button						*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnUpdateSave(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_bModified && m_listSites.GetCurSel() != LB_ERR);	
}


/********************************************************************/
/*																	*/
/* Function name : OnUpdateRemove									*/
/* Description   : Enable/Disable Remove-button						*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnUpdateRemove(CCmdUI* pCmdUI) 
{
	pCmdUI->Enable(m_listSites.GetCurSel() != LB_ERR);	
}


/********************************************************************/
/*																	*/
/* Function name : OnSelchangeSites									*/
/* Description   : Get data from selected site						*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnSelchangeSites() 
{
	int nIndex = m_listSites.GetCurSel();
	if (nIndex != LB_ERR)
	{
		int nItem = m_listSites.GetItemData(nIndex);
		m_bUsePASVMode = m_SitesArray[nItem].m_bUsePASVMode;
		m_nRetries = m_SitesArray[nItem].m_nRetries;
		m_nPort = m_SitesArray[nItem].m_nPort;
		m_nRetryDelay = m_SitesArray[nItem].m_nRetryDelay;
		m_strAddress = m_SitesArray[nItem].m_strAddress;
		m_strDescription = m_SitesArray[nItem].m_strDescription;
		m_strLocalPath = m_SitesArray[nItem].m_strLocalPath ;
		m_strLogin = m_SitesArray[nItem].m_strLogin;
		m_bAnonymous = (m_strLogin.CompareNoCase("anonymous") == 0);
		if (!m_bAnonymous)
		{
			GetDlgItem(IDC_PASSWORD)->ModifyStyle(NULL, ES_PASSWORD);
			((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar('*');
		}
		else
		{
			GetDlgItem(IDC_PASSWORD)->ModifyStyle(ES_PASSWORD, NULL);
			((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar(0);
		}
		m_strName = m_SitesArray[nItem].m_strName;
		m_wndInfobarCtrl.SetText(m_strName);
		m_strPassword = m_SitesArray[nItem].m_strPassword;
		m_strRemotePath = m_SitesArray[nItem].m_strRemotePath;
		UpdateData(FALSE);
		UpdateDialogControls(this, FALSE);	
		AfxGetApp()->WriteProfileInt("Settings", "LastSelectedSite", nIndex);
	}
}


/********************************************************************/
/*																	*/
/* Function name : ValidateData										*/
/* Description   : Validate the data that has been entered.			*/
/*																	*/
/********************************************************************/
BOOL CConnectDlg::ValidateData()
{
	UpdateData();

	if (m_strName.IsEmpty())
	{
		GetDlgItem(IDC_NAME)->SetFocus();
		return FALSE;
	}
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnBrowse											*/
/* Description   : Browse for local folder							*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnBrowse() 
{
	CString strDir = BrowseForFolder(m_hWnd, "Select a directory:", BIF_RETURNONLYFSDIRS);
	if (!strDir.IsEmpty())
	{
		GetDlgItem(IDC_LOCALPATH)->SetWindowText(strDir);
	}
}

/********************************************************************/
/*																	*/
/* Function name : OnSomethingChanged								*/
/* Description   : Something has changed...							*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnSomethingChanged() 
{
	m_bModified = TRUE;	
	UpdateDialogControls(this, FALSE);	
}


/********************************************************************/
/*																	*/
/* Function name : OnDblclkSites									*/
/* Description   : Item in the list has been double-clicked.		*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnDblclkSites() 
{
	OnOK();
}


/********************************************************************/
/*																	*/
/* Function name : OnAnonymous										*/
/* Description   : Item in the list has been double-clicked.		*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnAnonymous() 
{
	UpdateData();
	if (m_bAnonymous)
	{
		m_strLogin = "anonymous";
		m_strPassword = AfxGetApp()->GetProfileString("Settings", "EmailAddress", "");
		GetDlgItem(IDC_PASSWORD)->ModifyStyle(ES_PASSWORD, NULL);
		((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar(0);
		((CEdit *)GetDlgItem(IDC_PASSWORD))->Invalidate();
		((CEdit *)GetDlgItem(IDC_PASSWORD))->UpdateWindow();
	}
	else
	{
		// get old value
		int nIndex = m_listSites.GetCurSel();
		if (nIndex != LB_ERR)
		{
			int nItem = m_listSites.GetItemData(nIndex);
			m_strLogin = m_SitesArray[nItem].m_strLogin;
			m_strPassword = m_SitesArray[nItem].m_strPassword;
			GetDlgItem(IDC_PASSWORD)->ModifyStyle(NULL, ES_PASSWORD);
			((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar('*');
			((CEdit *)GetDlgItem(IDC_PASSWORD))->Invalidate();
			((CEdit *)GetDlgItem(IDC_PASSWORD))->UpdateWindow();
		}
	}
	UpdateData(FALSE);
}


/********************************************************************/
/*																	*/
/* Function name : OnChangeName										*/
/* Description   : Profile name has been changed.					*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnChangeName() 
{
	OnSomethingChanged();
	
	CString strName;
	GetDlgItemText(IDC_NAME, strName);
	m_wndInfobarCtrl.SetText(strName);
}


/********************************************************************/
/*																	*/
/* Function name : AddSite											*/
/* Description   : Add site without launching the dialog.			*/
/*																	*/
/********************************************************************/
BOOL CConnectDlg::AddSite(CFtpSite &pFtpSite)
{
	Serialize(FALSE);

	int nItem = -1;

	for (int i=0; i < m_SitesArray.GetSize(); i++)
	{
		if (m_SitesArray[i].m_strName.CompareNoCase(pFtpSite.m_strName) == 0)
		{
			nItem = i;
			// update old settings
			m_SitesArray[nItem].m_bUsePASVMode = pFtpSite.m_bUsePASVMode;
			m_SitesArray[nItem].m_nRetries = pFtpSite.m_nRetries;
			m_SitesArray[nItem].m_nPort = pFtpSite.m_nPort;
			m_SitesArray[nItem].m_nRetryDelay = pFtpSite.m_nRetryDelay;
			m_SitesArray[nItem].m_strAddress = pFtpSite.m_strAddress;
			m_SitesArray[nItem].m_strDescription = pFtpSite.m_strDescription;
			m_SitesArray[nItem].m_strLocalPath = pFtpSite.m_strLocalPath;
			m_SitesArray[nItem].m_strLogin = pFtpSite.m_strLogin;
			m_SitesArray[nItem].m_strName = pFtpSite.m_strName;
			m_SitesArray[nItem].m_strPassword = pFtpSite.m_strPassword;
			m_SitesArray[nItem].m_strRemotePath = pFtpSite.m_strRemotePath;
			break;
		}
	}

	if (nItem == -1)
	{
		nItem = m_SitesArray.Add(pFtpSite);
	}
	
	Serialize(TRUE);

	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnWizard											*/
/* Description   : Show wizard to add new site.						*/
/*																	*/
/********************************************************************/
void CConnectDlg::OnWizard() 
{
	CBitmap bmpHeader, bmpWatermark;

	VERIFY(bmpHeader.LoadBitmap(IDB_BANNER));
	VERIFY(bmpWatermark.LoadBitmap(IDB_WATERMARK));
	
	// show windows 2000-like wizard
	CWizardSheet wizSheet("Connection Wizard", this, 0, bmpWatermark, NULL, bmpHeader);
	wizSheet.m_psh.hInstance = ::GetModuleHandle(NULL);
	if (wizSheet.DoModal() == ID_WIZFINISH)
	{
		CFtpSite ftpSite;

		int nIndex = m_listSites.AddString(wizSheet.m_Page1.m_strProfileName);
		int nItem = m_SitesArray.Add(ftpSite);
		
		m_listSites.SetItemData(nIndex, nItem);
		m_listSites.SetCurSel(nIndex);	

		m_SitesArray[nItem].m_bUsePASVMode = AfxGetApp()->GetProfileInt("Settings", "DefaultUsePASVMode", 0);;
		m_SitesArray[nItem].m_nRetries = AfxGetApp()->GetProfileInt("Settings", "DefaultRetries", 3);
		m_SitesArray[nItem].m_nPort = 21;
		m_SitesArray[nItem].m_nRetryDelay = AfxGetApp()->GetProfileInt("Settings", "DefaultRetryDelay", 10);
		m_SitesArray[nItem].m_strAddress = wizSheet.m_Page2.m_strHostAddress;
		m_SitesArray[nItem].m_strDescription = "";
		m_SitesArray[nItem].m_strLocalPath = wizSheet.m_Page4.m_strLocalFolder;
		m_SitesArray[nItem].m_strLogin = wizSheet.m_Page3.m_strUserName;
		m_SitesArray[nItem].m_strName = wizSheet.m_Page1.m_strProfileName;
		m_SitesArray[nItem].m_strPassword = wizSheet.m_Page3.m_strPassword;
		m_SitesArray[nItem].m_strRemotePath = "";
		
		Serialize(TRUE);

		// select new site
		m_listSites.SetCurSel(nIndex);
		OnSelchangeSites();

		// connect to the site
		if (wizSheet.m_PageFinish.m_bConnectNow)
		{
			OnOK();
		}
	}	
}

void CConnectDlg::OnChangeLogin() 
{
	m_bModified = TRUE;	
	UpdateDialogControls(this, FALSE);	
	
	CString strText;

	GetDlgItemText(IDC_LOGIN, strText);

	if (strText.CompareNoCase("anonymous") != 0)
	{
		GetDlgItem(IDC_PASSWORD)->ModifyStyle(NULL, ES_PASSWORD);
		((CEdit *)GetDlgItem(IDC_PASSWORD))->SetPasswordChar('*');
		((CEdit *)GetDlgItem(IDC_PASSWORD))->Invalidate();
		((CEdit *)GetDlgItem(IDC_PASSWORD))->UpdateWindow();
		CheckDlgButton(IDC_ANONYMOUS, BST_UNCHECKED);
	}
}
