// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__38928986_D9E8_4129_9203_CC64B1360776__INCLUDED_)
#define AFX_STDAFX_H__38928986_D9E8_4129_9203_CC64B1360776__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#define _WIN32_IE 0x0500

#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxcview.h>
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include <afxtempl.h>
#include <afxsock.h>		// MFC socket extensions
#include "afxinet.h"
#include <shlobj.h>
#include "shfolder.h"

#define WM_FTP_STATUS WM_USER+130
#define WM_DOWNLOAD_FINISHED WM_USER+131
#define WM_UPLOAD_FINISHED WM_USER+132

extern void DoEvents();
extern void GetAppDir(CString& strAppDir);
extern CString BrowseForFolder(HWND hWnd, LPCSTR lpszTitle, UINT nFlags);
extern int GetIconIndex(LPCTSTR lpszPath, BOOL bIsDir, BOOL bSelected = FALSE);
void AutoSizeColumns(CListCtrl *pListCtrl);
BOOL WaitWithMessageLoop(HANDLE hEvent, int nTimeout);
char* FormatWithCommas(DWORD dwSize);

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__38928986_D9E8_4129_9203_CC64B1360776__INCLUDED_)
