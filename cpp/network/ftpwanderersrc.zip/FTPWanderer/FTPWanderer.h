// FTPWanderer.h : main header file for the FTPWANDERER application
//

#if !defined(AFX_FTPWANDERER_H__6380CDB4_96F4_4C4B_91BD_CB2F74091BF4__INCLUDED_)
#define AFX_FTPWANDERER_H__6380CDB4_96F4_4C4B_91BD_CB2F74091BF4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFTPWandererApp:
// See FTPWanderer.cpp for the implementation of this class
//

class CFtpWandererApp : public CWinApp
{
protected:
	void FixList();

public:
	CFtpWandererApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtpWandererApp)
	public:
	virtual BOOL InitInstance();
	virtual void AddToRecentFileList(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CFtpWandererApp)
	afx_msg void OnAppAbout();
	afx_msg void OnHelpIndex();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPWANDERER_H__6380CDB4_96F4_4C4B_91BD_CB2F74091BF4__INCLUDED_)
