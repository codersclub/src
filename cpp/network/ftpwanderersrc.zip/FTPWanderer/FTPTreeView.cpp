/****************************************************************/
/*																*/
/*  FtpTreeView.cpp 											*/
/*																*/
/*  Implementation of the CFtpTreeView class.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "MainFrm.h"
#include "FtpWandererDoc.h"
#include "FtpTreeView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CFtpTreeView, CTreeView)

BEGIN_MESSAGE_MAP(CFtpTreeView, CTreeView)
	//{{AFX_MSG_MAP(CFtpTreeView)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


CFtpTreeView::CFtpTreeView()
{
	// TODO: add construction code here

}

CFtpTreeView::~CFtpTreeView()
{
}


/********************************************************************/
/*																	*/
/* Function name : OnDraw											*/
/* Description   : CFtpTreeView drawing								*/
/*																	*/
/********************************************************************/
void CFtpTreeView::OnDraw(CDC* pDC)
{
	CFtpWandererDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}


/********************************************************************/
/*																	*/
/* Function name : OnInitialUpdate									*/
/* Description   :													*/
/*																	*/
/********************************************************************/
void CFtpTreeView::OnInitialUpdate()
{
	CTreeView::OnInitialUpdate();

	// TODO: You may populate your TreeView with items by directly accessing
	//  its tree control through a call to GetTreeCtrl().
}

/////////////////////////////////////////////////////////////////////////////
// CFtpTreeView diagnostics

#ifdef _DEBUG
void CFtpTreeView::AssertValid() const
{
	CTreeView::AssertValid();
}

void CFtpTreeView::Dump(CDumpContext& dc) const
{
	CTreeView::Dump(dc);
}

CFtpWandererDoc* CFtpTreeView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFtpWandererDoc)));
	return (CFtpWandererDoc*)m_pDocument;
}
#endif //_DEBUG


/********************************************************************/
/*																	*/
/* Function name : OnCreate											*/
/* Description   :													*/
/*																	*/
/********************************************************************/
int CFtpTreeView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CTreeView::OnCreate(lpCreateStruct) == -1)
		return -1;
	
    GetTreeCtrl().ModifyStyle(0, TVS_HASLINES);
    GetTreeCtrl().ModifyStyle(0, TVS_HASBUTTONS);
    GetTreeCtrl().ModifyStyle(0, TVS_LINESATROOT);
	GetTreeCtrl().ModifyStyle(0, TVS_SHOWSELALWAYS);

//	GetTreeCtrl().ModifyStyle(0, TVS_SHAREIMAGELISTS);

	// get system image list (in this case we only use the directory icon)
	InitTreeImageList();
	return 0;
}


/********************************************************************/
/*																	*/
/* Function name : InitTreeImageList								*/
/* Description   : Use system imagelist for the file icons			*/
/*																	*/
/********************************************************************/
BOOL CFtpTreeView::InitTreeImageList()
{
	HIMAGELIST himlNormal;
	SHFILEINFO sfi;

	himlNormal = (HIMAGELIST) SHGetFileInfo ((LPCSTR) "C:\\", 
		0, &sfi, sizeof (SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_SMALLICON);

	if (himlNormal)
	{
		::SendMessage(GetTreeCtrl().m_hWnd, TVM_SETIMAGELIST, (WPARAM)TVSIL_NORMAL, (LPARAM)himlNormal);
		return TRUE;
	}
	
	return FALSE;
} 


/********************************************************************/
/*																	*/
/* Function name : FindItem											*/
/* Description   : Find 'lpszText' item starting at hItem			*/
/*																	*/
/********************************************************************/
HTREEITEM CFtpTreeView::FindItem(LPCTSTR lpszText, HTREEITEM hItem)
{
	HTREEITEM htiSelected = hItem ? hItem : GetTreeCtrl().GetSelectedItem();
	HTREEITEM htiCurrent = GetNextItemEx(htiSelected);
	
	if(htiCurrent == NULL)
	{
		htiCurrent = GetTreeCtrl().GetRootItem();
	}

	while(htiCurrent && htiCurrent != htiSelected)
	{
		CString strItemText = GetTreeCtrl().CTreeCtrl::GetItemText(htiCurrent);

		if (strItemText.Compare(lpszText) == 0)
		{
			// found string
			return htiCurrent;
		}

		// get next
		htiCurrent = GetNextItemEx(htiCurrent);
		if(htiCurrent == NULL && htiSelected != NULL)
		{
			htiCurrent = GetTreeCtrl().GetRootItem();
		}
	}
	return NULL;
}


/********************************************************************/
/*																	*/
/* Function name : GetNextItemEx									*/
/* Description   : Get next item as if outline was completely		*/
/*				   expanded.										*/
/*																	*/
/********************************************************************/
HTREEITEM CFtpTreeView::GetNextItemEx(HTREEITEM hItem)
{
	HTREEITEM hti;

	if(GetTreeCtrl().ItemHasChildren(hItem))
	{
		// return first child
		return GetTreeCtrl().GetChildItem(hItem);           
	}
	else
	{
		// return next sibling item
        // Go up the tree to find a parent's sibling if needed.
        while((hti = GetTreeCtrl().GetNextSiblingItem(hItem)) == NULL)
		{
			if((hItem = GetTreeCtrl().GetParentItem(hItem)) == NULL)
				return NULL;
		}
	}
    return hti;
}


