/****************************************************************/
/*																*/
/*  InfobarCtrl.cpp												*/
/*																*/
/*  Implementation of the CInfobarCtrl class.					*/
/*	This class imitates the outlook infobar.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/

#include "stdafx.h"
#include "resource.h"
#include "InfobarCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CInfobarCtrl::CInfobarCtrl()
{
	m_bMouseInButton = FALSE;
	m_bMouseDown = FALSE;
}

CInfobarCtrl::~CInfobarCtrl()
{
}


BEGIN_MESSAGE_MAP(CInfobarCtrl, CStatic)
	//{{AFX_MSG_MAP(CInfobarCtrl)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnPaint											*/
/* Description   : This is where all the painting of our control	*/
/*				   takes place.										*/
/*																	*/
/********************************************************************/
void CInfobarCtrl::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	CDC memDC;
	CBitmap memBitmap;
	CBitmap* pOldBitmap;

	CRect rcClient;
	GetClientRect(&rcClient);

	// to avoid flicker, establish a memory dc, draw to it and then BitBlt it to the client
	memDC.CreateCompatibleDC(&dc);
	memBitmap.CreateCompatibleBitmap(&dc, rcClient.Width(), rcClient.Height());
	pOldBitmap = (CBitmap *)memDC.SelectObject(&memBitmap);

	// paint background
	memDC.FillSolidRect(rcClient, GetSysColor(COLOR_3DSHADOW));

	// select font
	CFont* pOldFont = (CFont*)memDC.SelectObject(&m_TextFont);
	COLORREF oldTextColor;
	int nBkMode = memDC.SetBkMode(TRANSPARENT);

	// set text color to white
	oldTextColor = memDC.SetTextColor(RGB(255,255,255));

	CRect rcItem = m_rcButton;
	if (rcItem.right >= rcClient.right)
		rcItem.right = rcClient.right-1;

	if (m_bMouseInButton)
	{
		if (m_bMouseDown)
			memDC.Draw3dRect(rcItem, RGB(0,0,0), RGB(255,255,255));
		else
			memDC.Draw3dRect(rcItem, RGB(255,255,255), RGB(0,0,0));
	}

	rcItem.DeflateRect(5, 0);
	rcItem.right -= 12;
	// draw text
	::DrawTextEx(memDC.m_hDC,
                m_strText.GetBuffer (0),
                m_strText.GetLength(),
                &rcItem,
                DT_SINGLELINE | DT_VCENTER | DT_LEFT | DT_PATH_ELLIPSIS,
                NULL);

	// finally send the result to the display
	dc.BitBlt(0, 0, rcClient.Width(), rcClient.Height(), &memDC, 0, 0, SRCCOPY);

	// restore old values
	memDC.SelectObject(pOldFont);		
	memDC.SetTextColor(oldTextColor);
	memDC.SetBkMode(nBkMode);
	memDC.SelectObject(pOldBitmap);
}


/********************************************************************/
/*																	*/
/* Function name : SetText											*/
/* Description   : Set text of the control							*/
/*																	*/
/********************************************************************/
void CInfobarCtrl::SetText(LPCTSTR lpszText)
{
	m_strText = lpszText;

	CClientDC dc(this);
	CFont* pFont = (CFont*)dc.SelectObject(&m_TextFont);

	CRect rcClient;
	GetClientRect(&rcClient);

	// calculate new button rect
	CSize size = dc.GetTextExtent(m_strText);
	size.cx += 22;
	size.cy = rcClient.Height()-2;
	m_rcButton = CRect(CPoint(1, 1), size);

	dc.SelectObject(pFont);

	Invalidate();
}


/********************************************************************/
/*																	*/
/* Function name : PreSubclassWindow								*/
/* Description   : Initialize control variables						*/
/*																	*/
/********************************************************************/
void CInfobarCtrl::PreSubclassWindow() 
{
	m_TextFont.CreateFont(16, 0,0,0,FW_BOLD, 0,0,0,
		DEFAULT_CHARSET, OUT_CHARACTER_PRECIS, CLIP_CHARACTER_PRECIS,
		DEFAULT_QUALITY, DEFAULT_PITCH | FF_DONTCARE, "Arial");
	
	CStatic::PreSubclassWindow();
}
