# Microsoft Developer Studio Project File - Name="FTPWanderer" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Application" 0x0101

CFG=FTPWanderer - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "FTPWanderer.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "FTPWanderer.mak" CFG="FTPWanderer - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "FTPWanderer - Win32 Release" (based on "Win32 (x86) Application")
!MESSAGE "FTPWanderer - Win32 Debug" (based on "Win32 (x86) Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
MTL=midl.exe
RSC=rc.exe

!IF  "$(CFG)" == "FTPWanderer - Win32 Release"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "Release"
# PROP Intermediate_Dir "Release"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /c
# ADD CPP /nologo /MD /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /c
# ADD BASE MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "NDEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "NDEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /machine:I386
# ADD LINK32 wininet.lib version.lib /nologo /subsystem:windows /machine:I386

!ELSEIF  "$(CFG)" == "FTPWanderer - Win32 Debug"

# PROP BASE Use_MFC 6
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 6
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "Debug"
# PROP Intermediate_Dir "Debug"
# PROP Ignore_Export_Lib 0
# PROP Target_Dir ""
# ADD BASE CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /Yu"stdafx.h" /FD /GZ /c
# ADD CPP /nologo /MDd /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_WINDOWS" /D "_AFXDLL" /D "_MBCS" /Yu"stdafx.h" /FD /GZ /c
# ADD BASE MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD MTL /nologo /D "_DEBUG" /mktyplib203 /win32
# ADD BASE RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
# ADD RSC /l 0x409 /d "_DEBUG" /d "_AFXDLL"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept
# ADD LINK32 wininet.lib version.lib /nologo /subsystem:windows /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "FTPWanderer - Win32 Release"
# Name "FTPWanderer - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Source File

SOURCE=.\AboutDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ColorListBox.cpp
# End Source File
# Begin Source File

SOURCE=.\ConnectDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ConnectionOptions.cpp
# End Source File
# Begin Source File

SOURCE=.\DownloadThread.cpp
# End Source File
# Begin Source File

SOURCE=.\FTPWanderer.cpp
# End Source File
# Begin Source File

SOURCE=.\FTPWanderer.rc
# End Source File
# Begin Source File

SOURCE=.\FTPWandererDoc.cpp
# End Source File
# Begin Source File

SOURCE=.\FTPListView.cpp
# End Source File
# Begin Source File

SOURCE=.\FtpSite.cpp
# End Source File
# Begin Source File

SOURCE=.\FTPTreeView.cpp
# End Source File
# Begin Source File

SOURCE=.\GeneralOptions.cpp
# End Source File
# Begin Source File

SOURCE=.\GeneralPage.cpp
# End Source File
# Begin Source File

SOURCE=.\GoToFolderDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\HistoryCombo.cpp
# End Source File
# Begin Source File

SOURCE=.\InfobarCtrl.cpp
# End Source File
# Begin Source File

SOURCE=.\MainFrm.cpp
# End Source File
# Begin Source File

SOURCE=.\MyInternetSession.cpp
# End Source File
# Begin Source File

SOURCE=.\OptionsSheet.cpp
# End Source File
# Begin Source File

SOURCE=.\ProgressDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\QuickConnectDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\RegKey.cpp
# End Source File
# Begin Source File

SOURCE=.\ReplaceFileDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\ReplaceFolderDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\SplitterWndEx.cpp
# End Source File
# Begin Source File

SOURCE=.\StaticLink.cpp
# End Source File
# Begin Source File

SOURCE=.\StdAfx.cpp
# ADD CPP /Yc"stdafx.h"
# End Source File
# Begin Source File

SOURCE=.\TraceView.cpp
# End Source File
# Begin Source File

SOURCE=.\TransferManagerDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\UploadThread.cpp
# End Source File
# Begin Source File

SOURCE=.\WaitMessageDlg.cpp
# End Source File
# Begin Source File

SOURCE=.\WizardPages.cpp
# End Source File
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Source File

SOURCE=.\AboutDlg.h
# End Source File
# Begin Source File

SOURCE=.\ColorListBox.h
# End Source File
# Begin Source File

SOURCE=.\ConnectDlg.h
# End Source File
# Begin Source File

SOURCE=.\ConnectionOptions.h
# End Source File
# Begin Source File

SOURCE=.\DownloadThread.h
# End Source File
# Begin Source File

SOURCE=.\FTPWanderer.h
# End Source File
# Begin Source File

SOURCE=.\FTPWandererDoc.h
# End Source File
# Begin Source File

SOURCE=.\FTPListView.h
# End Source File
# Begin Source File

SOURCE=.\FtpSite.h
# End Source File
# Begin Source File

SOURCE=.\FTPTreeView.h
# End Source File
# Begin Source File

SOURCE=.\GeneralOptions.h
# End Source File
# Begin Source File

SOURCE=.\GeneralPage.h
# End Source File
# Begin Source File

SOURCE=.\GoToFolderDlg.h
# End Source File
# Begin Source File

SOURCE=.\HistoryCombo.h
# End Source File
# Begin Source File

SOURCE=.\InfobarCtrl.h
# End Source File
# Begin Source File

SOURCE=.\MainFrm.h
# End Source File
# Begin Source File

SOURCE=.\MyInternetSession.h
# End Source File
# Begin Source File

SOURCE=.\OptionsSheet.h
# End Source File
# Begin Source File

SOURCE=.\ProgressDlg.h
# End Source File
# Begin Source File

SOURCE=.\QuickConnectDlg.h
# End Source File
# Begin Source File

SOURCE=.\RegKey.h
# End Source File
# Begin Source File

SOURCE=.\ReplaceFileDlg.h
# End Source File
# Begin Source File

SOURCE=.\ReplaceFolderDlg.h
# End Source File
# Begin Source File

SOURCE=.\Resource.h
# End Source File
# Begin Source File

SOURCE=.\SplitterWndEx.h
# End Source File
# Begin Source File

SOURCE=.\StaticLink.h
# End Source File
# Begin Source File

SOURCE=.\StdAfx.h
# End Source File
# Begin Source File

SOURCE=.\TraceView.h
# End Source File
# Begin Source File

SOURCE=.\TransferManagerDlg.h
# End Source File
# Begin Source File

SOURCE=.\UploadThread.h
# End Source File
# Begin Source File

SOURCE=.\WaitMessageDlg.h
# End Source File
# Begin Source File

SOURCE=.\WizardPages.h
# End Source File
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# Begin Source File

SOURCE=.\Baner16.bmp
# End Source File
# Begin Source File

SOURCE=.\res\banner.bmp
# End Source File
# Begin Source File

SOURCE=.\res\bin1.bin
# End Source File
# Begin Source File

SOURCE=.\res\bmdir.bmp
# End Source File
# Begin Source File

SOURCE=.\res\bmerror.bmp
# End Source File
# Begin Source File

SOURCE=.\res\bmfile.bmp
# End Source File
# Begin Source File

SOURCE=.\res\finger.cur
# End Source File
# Begin Source File

SOURCE=.\res\FTPWanderer.ico
# End Source File
# Begin Source File

SOURCE=.\res\FTPWanderer.rc2
# End Source File
# Begin Source File

SOURCE=.\res\FTPWandererDoc.ico
# End Source File
# Begin Source File

SOURCE=.\res\ico100.ico
# End Source File
# Begin Source File

SOURCE=.\res\idr_conf.ico
# End Source File
# Begin Source File

SOURCE=.\res\Toolbar.bmp
# End Source File
# Begin Source File

SOURCE=.\res\toolbar1.bmp
# End Source File
# Begin Source File

SOURCE=.\res\toolcold.bmp
# End Source File
# Begin Source File

SOURCE=.\res\tooldis.bmp
# End Source File
# Begin Source File

SOURCE=.\res\toolhot.bmp
# End Source File
# Begin Source File

SOURCE=.\Water16.bmp
# End Source File
# Begin Source File

SOURCE=.\res\watermark.bmp
# End Source File
# Begin Source File

SOURCE=.\res\xptheme.bin
# End Source File
# End Group
# Begin Source File

SOURCE=.\res\download.avi
# End Source File
# Begin Source File

SOURCE=.\res\search.avi
# End Source File
# Begin Source File

SOURCE=.\res\upload.avi
# End Source File
# Begin Source File

SOURCE=.\whatsnew.txt
# End Source File
# End Target
# End Project
