#if !defined(AFX_REPLACEFILEDLG_H__3F444875_8730_475E_AF7B_5BF2CD2C8441__INCLUDED_)
#define AFX_REPLACEFILEDLG_H__3F444875_8730_475E_AF7B_5BF2CD2C8441__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ReplaceFileDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CReplaceFileDlg dialog

class CReplaceFileDlg : public CDialog
{
// Construction
public:
	int m_nFileCount;
	CString m_strFileName;
	CReplaceFileDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CReplaceFileDlg)
	enum { IDD = IDD_REPLACE_FILE };
	CString	m_strPropertiesNew;
	CString	m_strPropertiesOld;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CReplaceFileDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CReplaceFileDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnYes();
	afx_msg void OnYestoall();
	afx_msg void OnNo();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_REPLACEFILEDLG_H__3F444875_8730_475E_AF7B_5BF2CD2C8441__INCLUDED_)
