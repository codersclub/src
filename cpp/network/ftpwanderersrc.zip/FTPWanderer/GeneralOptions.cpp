/****************************************************************/
/*																*/
/*  GeneralOptions.cpp											*/
/*																*/
/*  Implementation of the CGeneralOptions class.				*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "GeneralOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CGeneralOptions, CPropertyPage)

CGeneralOptions::CGeneralOptions() : CPropertyPage(CGeneralOptions::IDD)
{
	//{{AFX_DATA_INIT(CGeneralOptions)
	m_bShowConnectionDlg = FALSE;
	m_bSavePosition = FALSE;
	m_bKeepAlive = FALSE;
	m_strEmailAddress = _T("");
	m_bDeleteConfirmation = FALSE;
	m_bShowMessageBox = TRUE;
	m_bTransferRemoveFailed = FALSE;
	//}}AFX_DATA_INIT
}

CGeneralOptions::~CGeneralOptions()
{
}

void CGeneralOptions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGeneralOptions)
	DDX_Check(pDX, IDC_SHOWCONNECTDLG, m_bShowConnectionDlg);
	DDX_Check(pDX, IDC_SAVEPOSITION, m_bSavePosition);
	DDX_Check(pDX, IDC_KEEPALIVE, m_bKeepAlive);
	DDX_Text(pDX, IDC_EMAILADDRESS, m_strEmailAddress);
	DDX_Check(pDX, IDC_DELETECONFIRMATION, m_bDeleteConfirmation);
	DDX_Check(pDX, IDC_SHOW_MESSAGEBOX, m_bShowMessageBox);
	DDX_Check(pDX, IDC_TRANSFER_REMOVE_FAILED, m_bTransferRemoveFailed);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGeneralOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CGeneralOptions)
	ON_BN_CLICKED(IDC_KEEPALIVE, OnSomethingChanged)
	ON_BN_CLICKED(IDC_SAVEPOSITION, OnSomethingChanged)
	ON_BN_CLICKED(IDC_SHOWCONNECTDLG, OnSomethingChanged)
	ON_EN_CHANGE(IDC_EMAILADDRESS, OnSomethingChanged)
	ON_BN_CLICKED(IDC_DELETECONFIRMATION, OnSomethingChanged)
	ON_BN_CLICKED(IDC_SHOW_MESSAGEBOX, OnSomethingChanged)
	ON_BN_CLICKED(IDC_TRANSFER_REMOVE_FAILED, OnSomethingChanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CGeneralOptions::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// get settings from registry
	m_bSavePosition = AfxGetApp()->GetProfileInt("Settings", "SavePosition", 1);
	m_bKeepAlive = AfxGetApp()->GetProfileInt("Settings", "KeepAlive", 1);
	m_bShowConnectionDlg = AfxGetApp()->GetProfileInt("Settings", "ShowConnectionDlg", 1);
	m_bDeleteConfirmation = AfxGetApp()->GetProfileInt("Settings", "DeleteConfirmation", 1);
	m_bShowMessageBox = !AfxGetApp()->GetProfileInt("Settings", "ShowMessageBox", 1);
	m_bTransferRemoveFailed = AfxGetApp()->GetProfileInt("Settings", "RemoveFailed", 0);
	
	GetEmailName(m_strEmailAddress);
	m_strEmailAddress = AfxGetApp()->GetProfileString("Settings", "EmailAddress", m_strEmailAddress);
	UpdateData(FALSE);
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnOK												*/
/* Description   : Save settings and close dialog.					*/
/*																	*/
/********************************************************************/
void CGeneralOptions::OnOK() 
{
	UpdateData();
	
	// save settings to registry
	AfxGetApp()->WriteProfileInt("Settings", "SavePosition", m_bSavePosition);
	AfxGetApp()->WriteProfileInt("Settings", "KeepAlive", m_bKeepAlive);
	AfxGetApp()->WriteProfileInt("Settings", "ShowConnectionDlg", m_bShowConnectionDlg);
	AfxGetApp()->WriteProfileInt("Settings", "DeleteConfirmation", m_bDeleteConfirmation);
	AfxGetApp()->WriteProfileInt("Settings", "ShowMessageBox", !m_bShowMessageBox);
	AfxGetApp()->WriteProfileInt("Settings", "RemoveFailed", m_bTransferRemoveFailed);
	AfxGetApp()->WriteProfileString("Settings", "EmailAddress", m_strEmailAddress);

	CPropertyPage::OnOK();
}


/********************************************************************/
/*																	*/
/* Function name : OnSomethingChanged								*/
/* Description   : Some settings has been changed.					*/
/*																	*/
/********************************************************************/
void CGeneralOptions::OnSomethingChanged() 
{
	SetModified();
}


/********************************************************************/
/*																	*/
/* Function name : GetEmailName										*/
/* Description   : Get SMTP email address from registry.			*/
/*																	*/
/********************************************************************/
BOOL CGeneralOptions::GetEmailName(CString &strValue)
{
	HKEY hKey;
	DWORD dw;
	
	if (RegCreateKeyEx(HKEY_CURRENT_USER, "Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings", 
					0L, NULL, REG_OPTION_VOLATILE, KEY_ALL_ACCESS, NULL, &hKey, &dw) == ERROR_SUCCESS)
	{
		DWORD dwSize = 255, dwType;
		char szBuff[255];
		if (RegQueryValueEx(hKey, "EmailName", NULL, &dwType, (BYTE *)szBuff, &dwSize) == ERROR_SUCCESS)
		{
			strValue = szBuff;
		}
		RegCloseKey(hKey);
		return TRUE;
	}
	return FALSE;						
}


