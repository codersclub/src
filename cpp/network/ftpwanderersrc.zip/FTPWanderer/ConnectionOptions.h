#if !defined(AFX_CONNECTIONOPTIONS_H__43961F0E_E059_42D4_8864_6549ED895FC1__INCLUDED_)
#define AFX_CONNECTIONOPTIONS_H__43961F0E_E059_42D4_8864_6549ED895FC1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// ConnectionOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CConnectionOptions dialog

class CConnectionOptions : public CPropertyPage
{
	DECLARE_DYNCREATE(CConnectionOptions)

// Construction
public:
	CConnectionOptions();
	~CConnectionOptions();

// Dialog Data
	//{{AFX_DATA(CConnectionOptions)
	enum { IDD = IDD_CONNECTION_PAGE };
	int		m_nTimeout;
	int		m_nTransferMax;
	CString	m_strLocalPath;
	int		m_nRetries;
	int		m_nRetryDelay;
	BOOL	m_bUsePASVMode;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CConnectionOptions)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CConnectionOptions)
	virtual BOOL OnInitDialog();
	afx_msg void OnBrowse();
	afx_msg void OnSomethingChanged();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNECTIONOPTIONS_H__43961F0E_E059_42D4_8864_6549ED895FC1__INCLUDED_)
