#if !defined(AFX_GENERALPAGE_H__7EBE1963_479D_11D6_AB39_00D0B70C3D79__INCLUDED_)
#define AFX_GENERALPAGE_H__7EBE1963_479D_11D6_AB39_00D0B70C3D79__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GeneralPage.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGeneralPage dialog

class CGeneralPage : public CPropertyPage
{
	DECLARE_DYNCREATE(CGeneralPage)

// Construction
public:
	BOOL m_bIsDirectory;
	CGeneralPage();
	~CGeneralPage();

// Dialog Data
	//{{AFX_DATA(CGeneralPage)
	enum { IDD = IDD_PROPERTIES };
	CString	m_strDate;
	CString	m_strDescription;
	CString	m_strFileName;
	CString	m_strGroup;
	CString	m_strLocation;
	CString	m_strOwner;
	CString	m_strPermission;
	CString	m_strSize;
	CString	m_strType;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGeneralPage)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	void GetSystemIcon();

	// Generated message map functions
	//{{AFX_MSG(CGeneralPage)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERALPAGE_H__7EBE1963_479D_11D6_AB39_00D0B70C3D79__INCLUDED_)
