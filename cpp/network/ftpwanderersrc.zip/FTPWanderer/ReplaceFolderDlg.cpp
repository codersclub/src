/****************************************************************/
/*																*/
/*  ReplaceFolderDlg.cpp										*/
/*																*/
/*  Implementation of the CReplaceFolderDlg class.				*/
/*																*/
/*	This file is part of the FTP Wanderer application.			*/
/*  Creates a dialog that resembles the Microsoft Explorer one.	*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Programed by Pablo van der Meer								*/
/*  Copyright Pablo Software Solutions 2002						*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "ReplaceFolderDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CReplaceFolderDlg dialog


CReplaceFolderDlg::CReplaceFolderDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CReplaceFolderDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CReplaceFolderDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CReplaceFolderDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CReplaceFolderDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CReplaceFolderDlg, CDialog)
	//{{AFX_MSG_MAP(CReplaceFolderDlg)
	ON_BN_CLICKED(IDYES, OnYes)
	ON_BN_CLICKED(IDYESTOALL, OnYestoall)
	ON_BN_CLICKED(IDNO, OnNo)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CReplaceFolderDlg message handlers

void CReplaceFolderDlg::OnYes() 
{
	EndDialog(IDYES);
	
}

void CReplaceFolderDlg::OnYestoall() 
{
	EndDialog(IDYESTOALL);
}

void CReplaceFolderDlg::OnNo() 
{
	EndDialog(IDNO);
}


/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CReplaceFolderDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	CString strText;	
	GetDlgItemText(IDC_WARNING, strText);
	strText.Replace("%2", m_strFileName);
	SetDlgItemText(IDC_WARNING, strText);
	
	if (m_nFileCount == 1)
	{
		CRect rcButton;
		// reposition 'Yes' button
		GetDlgItem(IDNO)->GetWindowRect(rcButton);
		ScreenToClient(rcButton);
		GetDlgItem(IDYES)->MoveWindow(rcButton);
		
		// reposition 'No' button
		GetDlgItem(IDCANCEL)->GetWindowRect(rcButton);
		ScreenToClient(rcButton);
		GetDlgItem(IDNO)->MoveWindow(rcButton);

		// hide 'Cancel' and 'Yes To All' buttons
		GetDlgItem(IDCANCEL)->ShowWindow(SW_HIDE);
		GetDlgItem(IDYESTOALL)->ShowWindow(SW_HIDE);
	}	
	return TRUE;
}
