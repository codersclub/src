// FTPWandererDoc.h : interface of the CFTPWandererDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FTPWANDERERDOC_H__0C1B069A_459C_49FF_9166_D7A43F6D68BF__INCLUDED_)
#define AFX_FTPWANDERERDOC_H__0C1B069A_459C_49FF_9166_D7A43F6D68BF__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CTraceView;

class CFtpWandererDoc : public CDocument
{
protected: // create from serialization only
	CFtpWandererDoc();
	DECLARE_DYNCREATE(CFtpWandererDoc)

// Attributes
public:
// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFtpWandererDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnOpenDocument(LPCTSTR lpszPathName);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFtpWandererDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFtpWandererDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FTPWANDERERDOC_H__0C1B069A_459C_49FF_9166_D7A43F6D68BF__INCLUDED_)
