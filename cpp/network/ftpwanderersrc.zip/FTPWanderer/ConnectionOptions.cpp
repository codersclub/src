/****************************************************************/
/*																*/
/*  ConnectionOptions.cpp										*/
/*																*/
/*  Implementation of the CConnectionOptions class.				*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "ftpwanderer.h"
#include "ConnectionOptions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


IMPLEMENT_DYNCREATE(CConnectionOptions, CPropertyPage)

CConnectionOptions::CConnectionOptions() : CPropertyPage(CConnectionOptions::IDD)
{
	//{{AFX_DATA_INIT(CConnectionOptions)
	m_nTimeout = 0;
	m_nTransferMax = 0;
	m_strLocalPath = _T("");
	m_nRetries = 0;
	m_nRetryDelay = 0;
	m_bUsePASVMode = FALSE;
	//}}AFX_DATA_INIT
}

CConnectionOptions::~CConnectionOptions()
{
}

void CConnectionOptions::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CConnectionOptions)
	DDX_Text(pDX, IDC_TIMEOUT, m_nTimeout);
	DDX_Text(pDX, IDC_TRANSFER_MAX, m_nTransferMax);
	DDX_Text(pDX, IDC_LOCALPATH, m_strLocalPath);
	DDX_Text(pDX, IDC_RETRIES, m_nRetries);
	DDX_Text(pDX, IDC_RETRYDELAY, m_nRetryDelay);
	DDX_Check(pDX, IDC_USE_PASVMODE, m_bUsePASVMode);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CConnectionOptions, CPropertyPage)
	//{{AFX_MSG_MAP(CConnectionOptions)
	ON_BN_CLICKED(IDC_BROWSE, OnBrowse)
	ON_EN_CHANGE(IDC_TIMEOUT, OnSomethingChanged)
	ON_EN_CHANGE(IDC_TRANSFER_MAX, OnSomethingChanged)
	ON_EN_CHANGE(IDC_PORT, OnSomethingChanged)
	ON_EN_CHANGE(IDC_LOCALPATH, OnSomethingChanged)
	ON_EN_CHANGE(IDC_RETRIES, OnSomethingChanged)
	ON_EN_CHANGE(IDC_RETRYDELAY, OnSomethingChanged)
	ON_BN_CLICKED(IDC_USE_PASVMODE, OnSomethingChanged)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()



/********************************************************************/
/*																	*/
/* Function name : OnInitDialog										*/
/* Description   : Initialize dialog.								*/
/*																	*/
/********************************************************************/
BOOL CConnectionOptions::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	m_nTransferMax = AfxGetApp()->GetProfileInt("Settings", "TransferMax", 10);
	m_nTimeout = AfxGetApp()->GetProfileInt("Settings", "ConnectionTimeout", 30);
	m_strLocalPath = AfxGetApp()->GetProfileString("Settings", "DefaultLocalPath", "");
	m_nRetries = AfxGetApp()->GetProfileInt("Settings", "DefaultRetries", 3);
	m_nRetryDelay = AfxGetApp()->GetProfileInt("Settings", "DefaultRetryDelay", 10);
	m_bUsePASVMode = AfxGetApp()->GetProfileInt("Settings", "DefaultUsePASVMode", 0);

	UpdateData(FALSE);	
	return TRUE;
}


/********************************************************************/
/*																	*/
/* Function name : OnBrowse											*/
/* Description   : Browse for 'local path' folder.					*/
/*																	*/
/********************************************************************/
void CConnectionOptions::OnBrowse() 
{
	CString strDir = BrowseForFolder(m_hWnd, "Select a directory:", BIF_RETURNONLYFSDIRS);
	if (!strDir.IsEmpty())
	{
		GetDlgItem(IDC_LOCALPATH)->SetWindowText(strDir);
	}
}


/********************************************************************/
/*																	*/
/* Function name : OnOK												*/
/* Description   : Save settings and close dialog.					*/
/*																	*/
/********************************************************************/
void CConnectionOptions::OnOK() 
{
	UpdateData();
	AfxGetApp()->WriteProfileInt("Settings", "TransferMax", m_nTransferMax);	
	AfxGetApp()->WriteProfileInt("Settings", "ConnectionTimeout", m_nTimeout);	

	AfxGetApp()->WriteProfileString("Settings", "DefaultLocalPath", m_strLocalPath);
	AfxGetApp()->WriteProfileInt("Settings", "DefaultRetries", m_nRetries);
	AfxGetApp()->WriteProfileInt("Settings", "DefaultRetryDelay", m_nRetryDelay);
	AfxGetApp()->WriteProfileInt("Settings", "DefaultUsePASVMode", m_bUsePASVMode);
	CPropertyPage::OnOK();
}


/********************************************************************/
/*																	*/
/* Function name : OnSomethingChanged								*/
/* Description   : Some settings has been changed.					*/
/*																	*/
/********************************************************************/
void CConnectionOptions::OnSomethingChanged() 
{
	SetModified(TRUE);	
}


