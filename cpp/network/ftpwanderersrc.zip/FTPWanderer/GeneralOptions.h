#if !defined(AFX_GENERALOPTIONS_H__244FFE23_2049_4A64_BE62_E4DC8FE21613__INCLUDED_)
#define AFX_GENERALOPTIONS_H__244FFE23_2049_4A64_BE62_E4DC8FE21613__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// GeneralOptions.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CGeneralOptions dialog

class CGeneralOptions : public CPropertyPage
{
	DECLARE_DYNCREATE(CGeneralOptions)

// Construction
public:
	CGeneralOptions();
	~CGeneralOptions();

// Dialog Data
	//{{AFX_DATA(CGeneralOptions)
	enum { IDD = IDD_GENERAL_PAGE };
	BOOL	m_bShowConnectionDlg;
	BOOL	m_bSavePosition;
	BOOL	m_bKeepAlive;
	CString	m_strEmailAddress;
	BOOL	m_bDeleteConfirmation;
	BOOL	m_bShowMessageBox;
	BOOL	m_bTransferRemoveFailed;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CGeneralOptions)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL GetEmailName(CString &strValue);
	// Generated message map functions
	//{{AFX_MSG(CGeneralOptions)
	virtual void OnOK();
	virtual BOOL OnInitDialog();
	afx_msg void OnSomethingChanged();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GENERALOPTIONS_H__244FFE23_2049_4A64_BE62_E4DC8FE21613__INCLUDED_)
