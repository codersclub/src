/****************************************************************/
/*																*/
/*  SplitterWndEx.cpp											*/
/*																*/
/*  Implementation of the CSplitterWndEx class.					*/
/*																*/
/*  Programmed by Oleg Galkin.									*/
/*  www.codeguru.com/splitter/show_hide_static_panes.shtml		*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/

#include "stdafx.h"
#include "SplitterWndEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CSplitterWndEx::CSplitterWndEx()
{
	m_nHiddenRow = -1;
}

CSplitterWndEx::~CSplitterWndEx()
{
}


BEGIN_MESSAGE_MAP(CSplitterWndEx, CSplitterWnd)
	//{{AFX_MSG_MAP(CSplitterWndEx)
		// NOTE - the ClassWizard will add and remove mapping macros here.
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


void CSplitterWndEx::ShowRow()
{
	ASSERT_VALID(this);
    ASSERT(m_nRows < m_nMaxRows);
    ASSERT(m_nHiddenRow != -1);

    int nShowRow = m_nHiddenRow;
    m_nHiddenRow = -1;

    int cyNew = m_pRowInfo[m_nRows].nCurSize;
    // add a nRow
	m_nRows++;  
    
    ASSERT(m_nRows == m_nMaxRows);
    
    int nRow;

    // Show the hidden nRow
    for(int nCol = 0; nCol < m_nCols; ++nCol)
    {
        CWnd* pPaneShow = GetDlgItem(AFX_IDW_PANE_FIRST+nCol * 16+m_nRows);
        ASSERT(pPaneShow != NULL);
        pPaneShow->ShowWindow(SW_SHOWNA);

        for(nRow = m_nRows - 2; nRow >= nShowRow; --nRow)
        {
            CWnd* pPane = GetPane(nRow, nCol);
            ASSERT(pPane != NULL);
            pPane->SetDlgCtrlID(IdFromRowCol(nRow + 1, nCol));
        }

        pPaneShow->SetDlgCtrlID(IdFromRowCol(nShowRow, nCol));
    }

    // new panes have been created -- recalculate layout
    for(nRow = nShowRow+1; nRow < m_nRows; nRow++)
        m_pRowInfo[nRow].nIdealSize = m_pRowInfo[nRow - 1].nCurSize;

    m_pRowInfo[nShowRow].nIdealSize = cyNew;
    RecalcLayout();
}


void CSplitterWndEx::HideRow(int nRowHide)
{
	ASSERT_VALID(this);
    ASSERT(m_nRows > 1);
    ASSERT(nRowHide < m_nRows);
    ASSERT(m_nHiddenRow == -1);
    m_nHiddenRow = nRowHide;

    // if the row has an active window -- change it
    int nActiveRow, nActiveCol;

    if (GetActivePane(&nActiveRow, &nActiveCol) != NULL)
	{
		if(nActiveRow == m_nHiddenRow)
        {
            if( ++nActiveRow >= m_nRows)
                nActiveRow = 0;
            SetActivePane(nActiveRow, nActiveCol);
        }
	}

	// hide all nRow panes.
    for(int nCol = 0; nCol < m_nCols; ++nCol)
    {
        CWnd* pPaneHide = GetPane(nRowHide, nCol);
        ASSERT(pPaneHide != NULL);

        pPaneHide->ShowWindow(SW_HIDE);
        pPaneHide->SetDlgCtrlID(AFX_IDW_PANE_FIRST+nCol * 16+m_nRows);
        
        for(int nRow = nRowHide+1; nRow < m_nRows; ++nRow)
        {
            CWnd* pPane = GetPane(nRow, nCol);
            ASSERT(pPane != NULL);

            pPane->SetDlgCtrlID( IdFromRowCol(nRow-1, nCol));
        }
    }

    m_nRows--;
    m_pRowInfo[m_nRows].nCurSize = m_pRowInfo[nRowHide].nCurSize;
    RecalcLayout();
}
