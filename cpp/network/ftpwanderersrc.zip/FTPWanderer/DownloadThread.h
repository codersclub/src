#if !defined(AFX_DOWNLOADTHREAD_H__3705BA05_C50B_11D2_8415_8558AA8C211B__INCLUDED_)
#define AFX_DOWNLOADTHREAD_H__3705BA05_C50B_11D2_8415_8558AA8C211B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "ProgressDlg.h"

#define BUF_SIZE 4096

class CDownloadThread : public CWinThread
{
	DECLARE_DYNCREATE(CDownloadThread)

protected:
	CInternetSession m_InternetSession;
	CFtpConnection *m_pFtpConnection;
	CFile m_File;
	CString m_strResult;
	void DownloadFile(CString & source, CString & dest);

// Attributes
public:
	CDownloadThread();           // protected constructor used by dynamic creation
	virtual ~CDownloadThread();

	CWnd m_wndDummy;

// Operations
public:
	BOOL m_bTransferFailed;
	DWORD m_dwTransferType;
	BOOL CreateLocalDirectory(LPCTSTR lpszDirectory);
	void WaitForProgressDialog();
	CWnd *m_pTransferManager;
	CString m_strCurrentDirectory;
	CString GetLastError();

	CStringArray m_strLocalNames;
	CStringArray m_strRemoteNames;

	CString m_strLocalName;
	CString m_strRemoteName;
	CString m_strPassword;
	CString m_strUserName;
	CString m_strServerName;
	int		m_nRetries;
	int		m_nRetryDelay;
	int		m_nPort;
	int		m_bUsePASVMode;

	DWORD m_nConnectionTimeout;
	DWORD m_dwFileLength;

	virtual void Delete();
	HANDLE m_hEventDead;
	HANDLE m_hEventKill;
	void KillThread();

	CProgressDlg m_ProgressDlg;
	char m_szStatus[1024];

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDownloadThread)
	public:
	virtual BOOL InitInstance();
	virtual int ExitInstance();
	//}}AFX_VIRTUAL

// Implementation
protected:
	BOOL m_bDirectoryCreated;
	void PostDownloadStatus(LPCTSTR lpszStatus);

	// Generated message map functions
	//{{AFX_MSG(CDownloadThread)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DOWNLOADTHREAD_H__3705BA05_C50B_11D2_8415_8558AA8C211B__INCLUDED_)
