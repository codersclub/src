#if !defined(AFX_QUICKCONNECTDLG_H__CF0FF2E8_67BC_465A_B6D4_CBF63DB09704__INCLUDED_)
#define AFX_QUICKCONNECTDLG_H__CF0FF2E8_67BC_465A_B6D4_CBF63DB09704__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// QuickConnectDlg.h : header file
//

#include "HistoryCombo.h"

class CQuickConnectDlg : public CDialogBar
{
// Construction
public:
	CQuickConnectDlg();   // standard constructor

// Dialog Data
	//{{AFX_DATA(CQuickConnectDlg)
	enum { IDD = IDD_QUICKCONNECT };
	CHistoryCombo	m_cmbHost;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CQuickConnectDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CQuickConnectDlg)
	afx_msg void OnSelchangeHost();
	//}}AFX_MSG
	afx_msg LONG OnInitDialog(UINT, LONG);
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_QUICKCONNECTDLG_H__CF0FF2E8_67BC_465A_B6D4_CBF63DB09704__INCLUDED_)
