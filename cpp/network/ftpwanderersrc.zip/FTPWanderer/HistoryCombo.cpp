/****************************************************************/
/*																*/
/*  HistoryCombo.cpp											*/
/*																*/
/*  Implementation of the CHistoryCombo class.					*/
/*																*/
/*  Programmed by Pablo van der Meer							*/
/*  Copyright Pablo Software Solutions 2002						*/
/*	http://www.pablovandermeer.nl								*/
/*																*/
/*  Last updated: 15 may 2002									*/
/*																*/
/****************************************************************/


#include "stdafx.h"
#include "HistoryCombo.h"
#include "RegKey.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


CHistoryCombo::CHistoryCombo()
{
	m_nMaxHistoryLength = 10;
}

CHistoryCombo::~CHistoryCombo()
{
}


BEGIN_MESSAGE_MAP(CHistoryCombo, CComboBox)
	//{{AFX_MSG_MAP(CHistoryCombo)
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/********************************************************************/
/*																	*/
/* Function name : LoadMRU											*/
/* Description   : Reads items from Registry.						*/
/*																	*/
/********************************************************************/
void CHistoryCombo::LoadMRU(LPCTSTR lpszName)
{
	CString strCmd = "Cmd";
	
	CString strName;
	
	strName.Format("Software\\%s\\%s", AfxGetApp()->m_pszRegistryKey, AfxGetApp()->m_pszProfileName);

	if (!m_mruCmds.Create(HKEY_CURRENT_USER, strName, CString(lpszName)))
		return;
	
	int iCmd = 0;
	CString strText;
	do 
	{
		m_mruCmds.GetString(iCmd, strCmd);
		if (!strCmd.IsEmpty())
		{
			CString *pItemData = new CString;
			
			AfxExtractSubString(strText, strCmd, 0, '|');
			AfxExtractSubString(*pItemData, strCmd, 1, '|');

			int nIndex = AddString(strText);
			SetItemDataPtr(nIndex, pItemData);
		}
		iCmd++;
	} while (!strCmd.IsEmpty());

//	SetWindowText(strText);
}


/********************************************************************/
/*																	*/
/* Function name : SaveMRU											*/
/* Description   : Saves items to Registry.							*/
/*																	*/
/********************************************************************/
void CHistoryCombo::SaveMRU()
{
	int i;
	CString strCmd;

	for (i = 0; i < GetCount(); i++)
	{
		GetLBText(i, strCmd);

		CString *pItemData = (CString *)GetItemDataPtr(i);
		if (pItemData)
		{
			strCmd += "|";
			strCmd += *pItemData;
		}
		m_mruCmds.SetString(i, strCmd);
	}
}


/********************************************************************/
/*																	*/
/* Function name : AddStringEx										*/
/* Description   : Add string to MRU list.							*/
/*																	*/
/********************************************************************/
int CHistoryCombo::AddStringEx(LPCTSTR lpszText)
{
	CString strText;
	int nIndex = -1;
	
	if (lpszText == NULL)
		GetWindowText(strText);
	else
	{
		AfxExtractSubString(strText, lpszText, 0, '|');
//		strText = lpszText;
	}
	// add new string to MRU list
	if (FindStringExact(0, strText) == CB_ERR)
	{
		// delete first string if max. entries
		if (GetCount() >= m_nMaxHistoryLength)
		{
			CString *pItemData = (CString *)GetItemDataPtr(0);
			if (pItemData)
				delete pItemData;

			DeleteString(0);
		}
		
		CString *pItemData = new CString;
		
		AfxExtractSubString(strText, lpszText, 0, '|');
		AfxExtractSubString(*pItemData, lpszText, 1, '|');

		nIndex = AddString(strText);
		SetItemDataPtr(nIndex, pItemData);

		SaveMRU();
	}
	return nIndex;
}


/********************************************************************/
/*																	*/
/* Function name : ResetMRU											*/
/* Description   : Clear MRU list.									*/
/*																	*/
/********************************************************************/
void CHistoryCombo::ResetMRU()
{
	m_mruCmds.Clear();

	for (int i=0; i< GetCount(); i++)
	{
		CString *pItemData = (CString *)GetItemDataPtr(i);
		if (pItemData)
			delete pItemData;
	}

	ResetContent();
	SetWindowText("");
}


/********************************************************************/
/*																	*/
/* Function name : GetString										*/
/* Description   : Get string from Registry.						*/
/*																	*/
/********************************************************************/
BOOL CHistoryCombo::CMRUStrings::GetString(int i, CString& strVal)
{
	CString strText;
	unsigned long lSize;

	strText.Format("%s%d", m_strName, i);
	strVal.Empty();
	
	m_regKey.QueryValue(strVal.GetBuffer(_MAX_PATH), strText, &lSize);
	strVal.ReleaseBuffer();

	return !strVal.IsEmpty();	
}


/********************************************************************/
/*																	*/
/* Function name : SetString										*/
/* Description   : Set string in Registry.							*/
/*																	*/
/********************************************************************/
BOOL CHistoryCombo::CMRUStrings::SetString(int i, CString &strVal)
{
	CString strText;

	strText.Format("%s%d", m_strName, i);
	long lResult = m_regKey.SetValue(strVal, strText);
	return (lResult == ERROR_SUCCESS);
}


/********************************************************************/
/*																	*/
/* Function name : DeleteString										*/
/* Description   : Delete string from Registry.						*/
/*																	*/
/********************************************************************/
BOOL CHistoryCombo::CMRUStrings::DeleteString(int i)
{
	CString strText;

	strText.Format("%s%d", m_strName, i);
	long lResult = m_regKey.DeleteValue(strText);
	return (lResult == ERROR_SUCCESS);
}


/********************************************************************/
/*																	*/
/* Function name : Create											*/
/* Description   : Create Registry key for storing MRU items.		*/
/*																	*/
/********************************************************************/
BOOL CHistoryCombo::CMRUStrings::Create(HKEY hKeyParent, LPCTSTR lpszKeyName, CString &strName)
{
	long lResult  = m_regKey.Create(hKeyParent, lpszKeyName);
	m_strName = strName;
	return(lResult == ERROR_SUCCESS);
}


/********************************************************************/
/*																	*/
/* Function name : Clear											*/
/* Description   : Clear MRU list.									*/
/*																	*/
/********************************************************************/
void CHistoryCombo::CMRUStrings::Clear()
{
	int iCmd = 0;
	while(DeleteString(iCmd++))
	{
		// delete all items
	}
}


/********************************************************************/
/*																	*/
/* Function name : OnDestroy										*/
/* Description   : Free allocated memory.							*/
/*																	*/
/********************************************************************/
void CHistoryCombo::OnDestroy() 
{
	CComboBox::OnDestroy();

	for (int i=0; i< GetCount(); i++)
	{
		CString *pItemData = (CString *)GetItemDataPtr(i);
		if (pItemData)
			delete pItemData;
	}
}


