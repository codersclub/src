// ConnectSocket.h : header file

#if !defined(AFX_CONNECTSOCKET_H__B7C54BD3_A555_11D0_8996_00AA00B92B2E__INCLUDED_)
#define AFX_CONNECTSOCKET_H__B7C54BD3_A555_11D0_8996_00AA00B92B2E__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CDataSocket;

class CConnectSocket : public CSocket
{
	enum // Token ID's
	{
		TOK_ABOR, TOK_BYE, TOK_CDUP, TOK_CWD,
		TOK_DELE, TOK_DIR, TOK_HELP, TOK_LIST,
		TOK_MKD, TOK_NOOP, TOK_PASS, TOK_PASV, 
		TOK_PORT, TOK_PWD, TOK_QUIT, TOK_REST,
		TOK_RETR, TOK_RMD, TOK_RNFR, TOK_RNTO, 
		TOK_SIZE, TOK_STOR, TOK_SYST, TOK_TYPE, 
		TOK_USER, TOK_ERROR,
	};

public:
	int m_bPassiveMode;
	int m_nRemotePort;
	CString m_strRemoteHost;
	CDataSocket *m_pDataSocket;

	struct CFTPCommand
	{
		int m_nTokenID;
		char *m_pszName;
		BOOL m_bHasArguments;
		char *m_pszDescription;
	};

// Attributes
public:
	BOOL HasConnectionDropped(void);
	BOOL SendResponse(LPCTSTR pstrFormat, ...);
	void FireStatusMessage(LPCTSTR lpszStatus, int nType);
	BOOL GetRxCommand(CString &command, CString &args);
	BOOL CreateDataConnection(int nTransferType, LPCTSTR lpszData);
	void DestroyDataConnection();
// Operations
public:
	CConnectSocket();
	virtual ~CConnectSocket();

	void ParseCommand();

// Overrides
public:
	CWinThread* m_pThread;

	BOOL m_bLoggedon;
	CString m_strUserName;
	
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CConnectSocket)
	public:
	virtual void OnClose(int nErrorCode);
	virtual void OnReceive(int nErrorCode);
	virtual void OnConnect(int nErrorCode);
	//}}AFX_VIRTUAL

	// Generated message map functions
	//{{AFX_MSG(CConnectSocket)
		// NOTE - the ClassWizard will add and remove member functions here.
	//}}AFX_MSG

// Implementation
protected:
	CStringList m_strCommands;
	void GetRxLine();
	BOOL m_bRenameFile;
	DWORD m_dwRestartOffset;
	CString m_strRenameFile;
	CString m_RxBuffer;
	CString m_strCurrentDir;

};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CONNECTSOCKET_H__B7C54BD3_A555_11D0_8996_00AA00B92B2E__INCLUDED_)
