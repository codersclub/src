FTP Server by Pablo Software Solutions Version 1.0 Build 012

Introduction
Pablo's FTP Server is a multi threaded FTP server for Windows 98/NT/XP.
It comes with an easy to use interface and can be accessed from the system tray. 
The server handles all basic FTP commands and offers easy user account management and support for virtual directories.

Installation
Installing FTP Server is as simple as unzipping the executable in a folder of you choice, for example C:\Program Files\FTP Server.
Create a shortcut on the Start Menu of on your desktop and the FTP Server will be ready to use.

Description of the available options:

Server Log
In this screen can keep an eye on all the things that are going on, on the server. It shows you detailed information about all communication between the server and connected FTP clients. The number between the brackets [ ] is the thread id, which helps you to track all communication messages for a specific connection.
Everything you see in this window can also be logged to a file. See Configuration for more details. To clear the output window, right click for a popup menu and select Clear.

Online Users 
Displays a list of users that are currently online. Including there IP address and login time.
A context menu (right mouse click) is also available:
Menu->Kick User(s) disconnects the selected user(s).
Menu->Edit User Account brings up the User Account Dialog (see for a description later in this document)
Menu->Block this IP address adds the selected IP address(es) to the block list.

Configuration
Here you can configure all settings of the FTP Server.

FTP port
Socket port on which new connections are excepted (default: 21)

Max. Users
Maximum number of users that can simultaneous be connected.

Connection timeout (in minutes) 
When a client has been idle for a specific time it will be automatically disconnected.

Welcome message
Text that will be displayed when a client connects to the server.

Goodbye message
Text that will be displayed when a client disconnects from the server.

Log Level
None: no logging is done.
Error: only error message are logged to the logfile.
Warning: Warning and Error messages are logged to the logfile.. 
Trace: Trace, Warning and Error (= everything) messages are logged to the logfile.

View Log
Open the logfile with Notepad.

Clear Log
Clear the contents of the logfile.

Application Name
I didn't succeed in finding a catchy name for this application, so I decided to let you think of one. Enter anything you like and if you think of something really catchy let me know!

Other settings (which speak for themselves): Launch FTP Server at windows startup, Startup minimized in systemtray and Automatically activate server at startup.

Apply
Activate the changed settings immediatly (without having to restart the server).

Statistics
Shows a few interesting statistics of the server like the number of uploads/downloads.

Security
The security page makes it posible to block certain IP addresses to connect to your FTP server. Add a IP address to the list and it will be kicked off immediatly after it tries to connect.
When selecting the Block all IP addresses except option, all IP addresses will be blocked. Except the ones you add to the list.
You can use a wilcard to block a range of IP's like this: '199.0.*' will block all IP's in te range 199.0.0.0 to 199.0.255.255.

User Accounts
Add, Edit and Delete User Accounts. Specify passwords, directory permissions and assign virtual directories.
To help you make it easier to configure a new account you can also use the User Account Wizard.

User Account Wizard
To easily add a new account to the server click the User Account Wizard, and then follow the instructions. 

 
� Copyright 2002 Pablo Software Solutions



