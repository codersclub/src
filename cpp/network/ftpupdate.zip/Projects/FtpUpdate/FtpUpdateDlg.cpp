#include "stdafx.h"
#include "FtpUpdate.h"
#include "FtpUpdateDlg.h"
#include <algorithm>

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

CListCtrl CFtpUpdateDlg::serverListCtrl;
CListCtrl CFtpUpdateDlg::localListCtrl;
CFtpConnection* CFtpUpdateDlg::pFtpConnection = NULL;
bool CFtpUpdateDlg::stopDownload = false;

namespace {
	bool fileSortCriterion(const FileItem& f1, const FileItem& f2)
	{
		if (f1.isFolder && !f2.isFolder)
			return true;
		else if (!f1.isFolder && f2.isFolder)
			return false;
		else 
			return f1.name.CompareNoCase(f2.name) < 0;
	}
}

CFtpUpdateDlg::CFtpUpdateDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFtpUpdateDlg::IDD, pParent)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
	pFtpConnection = NULL;
	pSession = NULL;
	pProgressDlg = NULL;
}

CFtpUpdateDlg::~CFtpUpdateDlg()
{
	delete pFtpConnection;
	delete pSession;
}

void CFtpUpdateDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_FTP_PASSWORD_EDIT, passwordCtrl);
	DDX_Control(pDX, IDC_DEFAULT_CHECK, defaultLogonCtrl);
	DDX_Control(pDX, IDC_SERVER_LIST, serverListCtrl);
	DDX_Control(pDX, IDC_LOCAL_LIST, localListCtrl);
	DDX_Control(pDX, IDC_CONNECT_BUTTON, connectCtrl);
	DDX_Control(pDX, IDC_COPY_BUTTON, copyCtrl);
	DDX_Control(pDX, IDC_STATUS_TEXT, statusTextCtrl);
	DDX_Control(pDX, IDC_DELETE_BUTTON, deleteCtrl);
	DDX_Control(pDX, IDC_FTP_EDIT, ftpAddressCtrl);
	DDX_Control(pDX, IDC_NAME_EDIT, nameCtrl);
	DDX_Control(pDX, IDC_PATH_STATIC, pathStaticCtrl);
	DDX_Control(pDX, IDC_PATH_EDIT, pathEditCtrl);
}

BEGIN_MESSAGE_MAP(CFtpUpdateDlg, CDialog)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_COPY_BUTTON, OnCopy)
	ON_BN_CLICKED(IDC_CLOSE, OnClose)
	ON_BN_CLICKED(IDC_CONNECT_BUTTON, OnConnect)
	ON_BN_CLICKED(IDC_DEFAULT_CHECK, OnDefaultCheck)
	ON_NOTIFY(NM_DBLCLK, IDC_SERVER_LIST, OnNMDblclkServerList)
	ON_NOTIFY(LVN_KEYDOWN, IDC_SERVER_LIST, OnLvnKeydownServerList)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_SERVER_LIST, OnLvnItemchangedServerList)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LOCAL_LIST, OnLvnItemchangedLocalList)
	ON_NOTIFY(LVN_KEYDOWN, IDC_LOCAL_LIST, OnLvnKeydownLocalList)
	ON_NOTIFY(NM_DBLCLK, IDC_LOCAL_LIST, OnNMDblclkLocalList)
	ON_BN_CLICKED(IDC_DELETE_BUTTON, OnDeleteButton)
	ON_MESSAGE(WMU_STOPDOWNLOAD, msgStopDownloading)
	ON_MESSAGE(WMU_DOWNLOADFINISHED, msgDownloadFinished)
	ON_MESSAGE(WMU_DOWNLOADPROGRESS, msgDownloadProgress)
	ON_MESSAGE(WMU_DOWNLOADEXCEPTION, msgDownloadException)
	ON_MESSAGE(WMU_SESSIONUPDATE, msgUpdateInternetStatus)
END_MESSAGE_MAP()

BOOL CFtpUpdateDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	SetIcon(m_hIcon, FALSE);
	hCurBusy = ::LoadCursor(AfxGetInstanceHandle(), MAKEINTRESOURCE(IDR_ANICURSOR));
	//hCurBusy = LoadCursor(NULL, IDC_WAIT);
	hCurStandard = ::LoadCursor(NULL, IDC_ARROW);

	shellIconList.CreateImageList();
	serverListCtrl.SetImageList(&shellIconList.m_Small, LVSIL_SMALL);
	serverListCtrl.SetImageList(&shellIconList.m_Large, LVSIL_NORMAL);
	localListCtrl.SetImageList(&shellIconList.m_Small, LVSIL_SMALL);
	localListCtrl.SetImageList(&shellIconList.m_Large, LVSIL_NORMAL);

	serverListCtrl.InsertColumn(0, "Name", LVCFMT_LEFT, 125);
	serverListCtrl.InsertColumn(1, "Size", LVCFMT_RIGHT, 60);
	serverListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	localListCtrl.InsertColumn(0, "Name", LVCFMT_LEFT, 125);
	localListCtrl.InsertColumn(1, "Size", LVCFMT_RIGHT, 60);
	localListCtrl.SetExtendedStyle(LVS_EX_FULLROWSELECT);
	copyCtrl.EnableWindow(FALSE);
	deleteCtrl.EnableWindow(FALSE);

	defaultLogonCtrl.SetCheck(1);
	OnDefaultCheck();
	updateServerList();
	
	localPath = "C:\\Temp";
	SetCurrentDirectory(localPath.c_str());
	updateLocalList();

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.
void CFtpUpdateDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting
		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);
		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;
		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CFtpUpdateDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

UINT CFtpUpdateDlg::getDownloadFileFnc(LPVOID pParam)
{
	int iItem = serverListCtrl.GetSelectionMark();
	HWND hWndMain = AfxGetApp()->GetMainWnd()->GetSafeHwnd();
	if (iItem == -1) {
		::PostMessage(hWndMain, WMU_DOWNLOADFINISHED, 0, 0);
		return 0;
	}
	FileItem *fi = reinterpret_cast<FileItem*>(serverListCtrl.GetItemData(iItem));
	CString fileName = fi->name;
	CFile localFile(fileName, CFile::modeCreate |
		CFile::modeWrite | CFile::typeBinary);
	CInternetFile* serverFile = NULL;
	try {
		serverFile = pFtpConnection->OpenFile(fileName);
		ULONGLONG fileLength = fi->size;
		ULONGLONG currentProgress = 0;
		ASSERT(serverFile);
		const int FILEBUFLEN = 1024;
		char fileBuf[FILEBUFLEN];
		UINT numBytes;
		short sent = 0;
		while (numBytes = serverFile->Read(fileBuf, FILEBUFLEN)) {
			if (!stopDownload) {
				localFile.Write(fileBuf, numBytes);
				currentProgress += FILEBUFLEN;
				short toSend = static_cast<short>(100 * currentProgress/fileLength);
				if (sent + 2 < toSend) {
					::PostMessage(hWndMain, WMU_DOWNLOADPROGRESS, static_cast<WPARAM>(toSend), 0);
					sent = toSend;
				}
			} else
				break;
		}
		serverFile->Close();
		localFile.Flush();
		localFile.Close();
		if (stopDownload) {
			if (!DeleteFile(fileName))
				AfxMessageBox("Can't delete local file.");
		}
		::PostMessage(hWndMain, WMU_DOWNLOADFINISHED, 0, 0);
	}
	catch (CInternetException* pEx) {
		TCHAR sz[1024];
		pEx->GetErrorMessage(sz, 1024);
		string msg = "InternetException: ";
		msg += sz;
		AfxMessageBox(msg.c_str());
		pEx->Delete();
		::PostMessage(hWndMain, WMU_DOWNLOADEXCEPTION, 0, 0);
		if (serverFile)
			serverFile->Close();
		localFile.Close();
		if (!DeleteFile(fileName))
			AfxMessageBox("Can't delete local file.");
		return 0;
	}
	catch (...) {
		AfxMessageBox("FTP Update: unhandled exception.");
		::PostMessage(hWndMain, WMU_DOWNLOADEXCEPTION, 0, 0);
		if (serverFile)
			serverFile->Close();
		localFile.Close();
		if (!DeleteFile(fileName))
			AfxMessageBox("Can't delete local file.");
	}
	return 0;
}

void CFtpUpdateDlg::OnCopy()
{
	int iItem = serverListCtrl.GetSelectionMark();
	if (!pFtpConnection || iItem == -1)
		return;
	FileItem *fi = reinterpret_cast<FileItem*>(serverListCtrl.GetItemData(iItem));
	CString fileName = fi->name;
	WIN32_FIND_DATA fd;
	HANDLE fFinder;
	if ((fFinder = FindFirstFile(fileName, &fd)) != INVALID_HANDLE_VALUE &&
			!(fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) &&
			AfxMessageBox("File already exists. Overwrite?", MB_YESNO) == IDNO) {
		FindClose(fFinder);
		return;
	};
	FindClose(fFinder);
	pProgressDlg = new CProgressDlg;
	if (!pProgressDlg || !pProgressDlg->Create(IDD_PROGRESS_DIALOG, this))
		return;
	pProgressDlg->ShowWindow(SW_SHOW);
	stopDownload = false;
	AfxBeginThread(getDownloadFileFnc, 0);
	this->EnableWindow(FALSE);
}


void CFtpUpdateDlg::OnClose()
{
	CDialog::OnCancel();
}

void CFtpUpdateDlg::OnConnect()
{
	pFtpConnection ? disconnect() : connect();
}

void CFtpUpdateDlg::OnDefaultCheck()
{
	if (defaultLogonCtrl.GetCheck() == 1) {
		//retrive defaults from registry if you wish
		address = "ftp.ti.com";
		username = "";
		password = "";
		ftpAddressCtrl.SetWindowText(address.c_str());
		ftpAddressCtrl.EnableWindow(FALSE);
		nameCtrl.SetWindowText(username.c_str());
		nameCtrl.EnableWindow(FALSE);
		passwordCtrl.SetWindowText(password.c_str());
		passwordCtrl.EnableWindow(FALSE);
	} else {
		address.erase();
		ftpAddressCtrl.SetWindowText("");
		ftpAddressCtrl.EnableWindow();
		username.erase();
		nameCtrl.SetWindowText("");
		nameCtrl.EnableWindow();
		password.erase();
		passwordCtrl.SetWindowText("");
		passwordCtrl.EnableWindow();
	}
}

void CFtpUpdateDlg::updateServerList()
{
	serverListCtrl.DeleteAllItems();
	busyCursor();
	if (pFtpConnection) {
		connectCtrl.SetWindowText("Disconnect");
		defaultLogonCtrl.EnableWindow(FALSE);
		serverListCtrl.UpdateWindow();
		getServerFiles();
		if (serverFiles.size())
			serverListCtrl.EnableWindow();
		int nCounter = 0;
		vector<FileItem>::const_iterator file;
		for (file = serverFiles.begin(); file != serverFiles.end(); ++file) {
			CString size;
			int icon = 0;
			if (!file->isFolder) {
				size.Format("%d", file->size);
				icon = shellIconList.AddExtIcon(file->name);
			} else {
				icon = shellIconList.AddExtIcon(".");
			}
			int index = serverListCtrl.InsertItem(nCounter++, file->name, icon);
			serverListCtrl.SetItemText(index, 1, size);
			serverListCtrl.SetItemData(index, reinterpret_cast<DWORD>(&*file));
			serverListCtrl.UpdateWindow();
		}
	} else {
		int index = serverListCtrl.InsertItem(0,"no connection...", -1);
		serverListCtrl.SetItemData(index, 0);
		serverListCtrl.EnableWindow(FALSE);
		copyCtrl.EnableWindow(FALSE);
		connectCtrl.SetWindowText("Connect");
		defaultLogonCtrl.EnableWindow();
	}
	standardCursor();
}

LRESULT CFtpUpdateDlg::msgDownloadException(WPARAM wParam, LPARAM lParam)
{
	disconnect();
	PostMessage(WMU_DOWNLOADFINISHED, 0, 0);
	return 0;
}

LRESULT CFtpUpdateDlg::msgDownloadProgress(WPARAM wParam, LPARAM lParam)
{
	if (pProgressDlg)
		pProgressDlg->setProgress(static_cast<int>(wParam));
	return 0;
}

LRESULT CFtpUpdateDlg::msgStopDownloading(WPARAM wParam, LPARAM lParam)
{
	stopDownload = true;
	return 0;
}

LRESULT CFtpUpdateDlg::msgDownloadFinished(WPARAM wParam, LPARAM lParam)
{
	delete pProgressDlg;
	this->EnableWindow();
	this->BringWindowToTop();
	updateLocalList();
	return 0;
}

LRESULT CFtpUpdateDlg::msgUpdateInternetStatus(WPARAM wParam, LPARAM lParam)
{
	if (wParam == 0)
		return 0;
	CString *pMsg = reinterpret_cast<CString*>(wParam);
	statusTextCtrl.SetWindowText(*pMsg);
	delete pMsg;
	return 0;
}

void CFtpUpdateDlg::getServerFiles(void)
{
	if (!pFtpConnection)
		return;
	busyCursor();
	serverFiles.clear();
	serverFiles.push_back(FileItem(TRUE, _T(".."), 0, CTime()));
	CFtpFileFind finder(pFtpConnection);
	try {
		CString curDir;
		if (!pFtpConnection->GetCurrentDirectory(curDir))// Connection alive?
			throw 0;
		BOOL bWorking = finder.FindFile(_T("*"));
		while (bWorking) {
			bWorking = finder.FindNextFile();
			CTime fileTime;
			finder.GetCreationTime(fileTime);
			serverFiles.push_back(FileItem(finder.IsDirectory(), finder.GetFileName(), finder.GetLength(), fileTime));
		}
	}
	catch (CInternetException* pEx) {
		TCHAR sz[1024];
		pEx->GetErrorMessage(sz, 1024);
		string msg = "InternetException (getServerFiles): ";
		msg += sz;
		AfxMessageBox(msg.c_str());
		pEx->Delete();
		PostMessage(WMU_DOWNLOADEXCEPTION, 0, 0);
	}
	catch (int) {
		AfxMessageBox("FTP connection lost.");
		PostMessage(WMU_DOWNLOADEXCEPTION, 0, 0);
	}
	catch (...) {
		AfxMessageBox("getServerFiles: unhandled exception.");
		PostMessage(WMU_DOWNLOADEXCEPTION, 0, 0);
	}
	finder.Close();
	sort(serverFiles.begin(), serverFiles.end(), fileSortCriterion);
	standardCursor();
}

void CFtpUpdateDlg::OnNMDblclkServerList(NMHDR *pNMHDR, LRESULT *pResult)
{
	OnEnterServerList();
	*pResult = 0;
}

void CFtpUpdateDlg::OnLvnKeydownServerList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLVKEYDOWN pLVKeyDow = reinterpret_cast<LPNMLVKEYDOWN>(pNMHDR);
	switch(pLVKeyDow->wVKey) {
		case VK_RETURN:
			OnEnterServerList();
			break;
		case VK_BACK:
			OnBackServerList();
			break;
		case VK_F5:
			updateServerList();
			break;
	}
	*pResult = 0;
}

int CFtpUpdateDlg::PreTranslateMessage(MSG *pMsg)
{
	if(pMsg->message == WM_KEYDOWN && pMsg->wParam == VK_RETURN) {
		return FALSE; // Nonzero if the message was translated and should not be dispatched; 0 if the message was not translated and should be dispatched.
	}
	return CDialog::PreTranslateMessage(pMsg);
}

void CFtpUpdateDlg::OnEnterServerList(void)
{
	int iItem = serverListCtrl.GetSelectionMark();
	if (iItem != -1) {
		FileItem *fi = reinterpret_cast<FileItem*>(serverListCtrl.GetItemData(iItem));
		if (fi > 0) {
			if (fi->isFolder != -1 && fi->isFolder) {
				pFtpConnection->SetCurrentDirectory(serverListCtrl.GetItemText(iItem, 0));
				updateServerList();
			}
		}
	}
}

void CFtpUpdateDlg::OnBackServerList(void)
{
	pFtpConnection->SetCurrentDirectory("..");
	updateServerList();
}

void CFtpUpdateDlg::OnLvnItemchangedServerList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	int iItem = pNMLV->iItem;
	if (iItem != -1 && pNMLV->uOldState == 0 && pNMLV->uNewState == 3) {
		FileItem *fi = reinterpret_cast<FileItem*>(serverListCtrl.GetItemData(iItem));
		!fi->isFolder ? copyCtrl.EnableWindow() : copyCtrl.EnableWindow(FALSE);
	}
	*pResult = 0;
}

void CFtpUpdateDlg::updateLocalList(void)
{
	localListCtrl.DeleteAllItems();
	getLocalFiles();	
	busyCursor();

	int nCounter = 0;
	vector<FileItem>::const_iterator file;
	for (file = localFiles.begin(); file != localFiles.end(); ++file) {
		CString size;
		int icon = 0;
		if (!file->isFolder) {
			size.Format("%d", file->size);
			icon = shellIconList.AddExtIcon(file->name);
		} else {
			icon = shellIconList.AddExtIcon(".");
		}
		int index = localListCtrl.InsertItem(nCounter++, file->name, icon);
		localListCtrl.SetItemText(index, 1, size);
		localListCtrl.SetItemData(index, file->isFolder);
		localListCtrl.UpdateWindow();
	}
	deleteCtrl.EnableWindow(FALSE);
	standardCursor();
}

void CFtpUpdateDlg::getLocalFiles(void)
{
	localFiles.clear();
	busyCursor();
	DWORD fileAttributeMask = FILE_ATTRIBUTE_HIDDEN | FILE_ATTRIBUTE_SYSTEM;
	WIN32_FIND_DATA findData;
	char buf[MAX_PATH];
	GetCurrentDirectory(MAX_PATH, reinterpret_cast<LPTSTR>(&buf));
	localPath = buf;
	pathEditCtrl.SetWindowText(buf);
	HANDLE hFindFile = FindFirstFile("*", &findData);
	if (hFindFile == INVALID_HANDLE_VALUE) {
		AfxMessageBox("Could not open local path specified.\nC:\\ folder will be opened instead.");
		return;
	}
	bool fileFound = true;
	while (fileFound) {
		if (!(findData.dwFileAttributes & fileAttributeMask || strcmp(".", findData.cFileName) == 0))
			localFiles.push_back(FileItem(findData.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY, findData.cFileName, findData.nFileSizeLow + (findData.nFileSizeHigh << 32), CTime(findData.ftCreationTime)));
		if (!FindNextFile(hFindFile, &findData)) {
			if (GetLastError() == ERROR_NO_MORE_FILES)
				fileFound = false;
		};
	}
	FindClose(hFindFile);
	sort(localFiles.begin(), localFiles.end(), fileSortCriterion);
	standardCursor();
}

void CFtpUpdateDlg::OnLvnItemchangedLocalList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLISTVIEW pNMLV = reinterpret_cast<LPNMLISTVIEW>(pNMHDR);
	int iItem = pNMLV->iItem;
	if (iItem != -1 && pNMLV->uOldState == 0 && pNMLV->uNewState == 3) {
		BOOL isFolder = static_cast<BOOL>(localListCtrl.GetItemData(iItem));
		!isFolder ? deleteCtrl.EnableWindow() : deleteCtrl.EnableWindow(FALSE);
	}
	*pResult = 0;
}

void CFtpUpdateDlg::OnEnterLocalList(void)
{
	int iItem = localListCtrl.GetSelectionMark();
	if (iItem != -1) {
		BOOL isFolder = static_cast<BOOL>(localListCtrl.GetItemData(iItem));
		if (isFolder != -1 && isFolder) {
			SetCurrentDirectory(localListCtrl.GetItemText(iItem, 0));
			updateLocalList();
		}
	}
}

void CFtpUpdateDlg::OnBackLocalList(void)
{
	SetCurrentDirectory("..");
	updateLocalList();
}

void CFtpUpdateDlg::OnLvnKeydownLocalList(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMLVKEYDOWN pLVKeyDow = reinterpret_cast<LPNMLVKEYDOWN>(pNMHDR);
	switch(pLVKeyDow->wVKey) {
		case VK_RETURN:
			OnEnterLocalList();
			break;
		case VK_BACK:
			OnBackLocalList();
			break;
		case VK_DELETE:
			OnDeleteButton();
			break;
		case VK_F5:
			updateLocalList();
			break;
	}
	*pResult = 0;
}

void CFtpUpdateDlg::OnNMDblclkLocalList(NMHDR *pNMHDR, LRESULT *pResult)
{
	OnEnterLocalList();
	*pResult = 0;
}

void CFtpUpdateDlg::OnDeleteButton()
{
	int iItem = localListCtrl.GetSelectionMark();
	if (iItem != -1) {
		BOOL isFolder = static_cast<BOOL>(localListCtrl.GetItemData(iItem));
		if (!isFolder) {
			if (AfxMessageBox("Are you sure to delete this file?", MB_YESNO) == IDYES) {
				CString fileName = localListCtrl.GetItemText(iItem, 0);
				if (!DeleteFile(fileName))
					AfxMessageBox("Failed to delete the file.");
			}
			updateLocalList();
		}
	}
}

void CFtpUpdateDlg::busyCursor(void)
{
	SetCursor(hCurBusy);
}

void CFtpUpdateDlg::standardCursor(void)
{
	SetCursor(hCurStandard);
}

void CFtpUpdateDlg::connect(void)
{
	busyCursor();
	if (defaultLogonCtrl.GetCheck() != 1) {
		CString buf;
		ftpAddressCtrl.GetWindowText(buf);
		if (buf.IsEmpty()) {
			AfxMessageBox("Enter address of FTP server with updates.");
			ftpAddressCtrl.SetFocus();
			return;
		}
		address = static_cast<LPCTSTR>(buf);
		nameCtrl.GetWindowText(buf);
		username = static_cast<LPCTSTR>(buf);
		passwordCtrl.GetWindowText(buf);
		password = static_cast<LPCTSTR>(buf);
	}
	try {
		pSession = new CInternetSessionEx(AfxGetApp()->m_pszAppName, 1, INTERNET_OPEN_TYPE_DIRECT, 0, 0, INTERNET_FLAG_DONT_CACHE);
		pSession->SetOption(INTERNET_OPTION_CONNECT_TIMEOUT, 500);
		pSession->SetOption(INTERNET_OPTION_CONNECT_RETRIES, 2);
		pSession->EnableStatusCallback();
		pFtpConnection = pSession->GetFtpConnection(address.c_str(), username.c_str(), password.c_str(), INTERNET_DEFAULT_FTP_PORT);
		updateServerList();
	}
	catch (CInternetException* pEx) {
		TCHAR sz[1024];
		pEx->GetErrorMessage(sz, 1024);
		string msg = "InternetException: ";
		msg += sz;
		AfxMessageBox(msg.c_str());
		pEx->Delete();
		if (pFtpConnection != NULL)
			pFtpConnection->Close();
		delete pFtpConnection;
		pFtpConnection = NULL;
	}
	catch (...) {
		if (pFtpConnection != NULL)
			pFtpConnection->Close();
		delete pFtpConnection;
		pFtpConnection = NULL;
		AfxMessageBox("FTP Update: unhandled exception. (OnConnect)");
	}
	standardCursor();
}

void CFtpUpdateDlg::disconnect(void)
{
	if (pFtpConnection) {
		pFtpConnection->Close();
		delete pFtpConnection;
		pFtpConnection = NULL;
		updateServerList();
	}
}
