// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__D453EB44_A4D4_421B_B8C4_69474900CF2D__INCLUDED_)
#define AFX_STDAFX_H__D453EB44_A4D4_421B_B8C4_69474900CF2D__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#define VC_EXTRALEAN		// Exclude rarely-used stuff from Windows headers

#include <afxtempl.h>
#include <afxwin.h>         // MFC core and standard components
#include <afxext.h>         // MFC extensions
#include <afxdisp.h>        // MFC Automation classes
#include <afxdtctl.h>		// MFC support for Internet Explorer 4 Common Controls
#ifndef _AFX_NO_AFXCMN_SUPPORT
#include <afxcmn.h>			// MFC support for Windows Common Controls
#endif // _AFX_NO_AFXCMN_SUPPORT

#include "resource.h"


#define WMU_SESSIONUPDATE		WM_APP + 1
#define WMU_STOPDOWNLOAD		WM_APP + 2
#define WMU_DOWNLOADFINISHED	WM_APP + 3
#define WMU_DOWNLOADPROGRESS	WM_APP + 4
#define WMU_DOWNLOADEXCEPTION	WM_APP + 5

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__D453EB44_A4D4_421B_B8C4_69474900CF2D__INCLUDED_)
