//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by FtpUpdate.rc
//
#define IDC_CLOSE                       3
#define IDR_ANICURSOR                   101
#define IDD_FTPUPDATE_DIALOG            102
#define IDR_MAINFRAME                   128
#define IDD_PROGRESS_DIALOG             129
#define IDC_CURSOR1                     136
#define IDC_FTP_ADDRESS_EDIT            1000
#define IDC_NAME_EDIT                   1000
#define IDC_FTP_PASSWORD_EDIT           1001
#define IDC_DEFAULT_CHECK               1002
#define IDC_SERVER_LIST                 1003
#define IDC_LOCAL_LIST                  1004
#define IDC_COPY_BUTTON                 1005
#define IDC_PROGRESS_BAR                1006
#define IDC_DELETE_BUTTON               1006
#define IDC_CONNECT_BUTTON              1007
#define IDC_SERVER_FILTER_COMBO         1008
#define IDC_STATUS_TEXT                 1009
#define IDC_LOCAL_FILTER_COMBO          1010
#define IDC_FTP_EDIT                    1011
#define IDC_PATH_STATIC                 1013
#define IDC_STOP                        1014
#define IDC_PATH_EDIT                   1015
#define IDC_PERCENT                     1016

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        139
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1017
#define _APS_NEXT_SYMED_VALUE           102
#endif
#endif
