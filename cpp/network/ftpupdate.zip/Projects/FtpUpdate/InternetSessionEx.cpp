#include "stdafx.h"
#include "InternetSessionEx.h"

// CInternetSessionEx

CInternetSessionEx::CInternetSessionEx(LPCTSTR pstrAgent /*= NULL*/,
		DWORD dwContext /*= 1*/,
		DWORD dwAccessType /*= PRE_CONFIG_INTERNET_ACCESS*/,
		LPCTSTR pstrProxyName /*= NULL*/,
		LPCTSTR pstrProxyBypass /*= NULL*/,
		DWORD dwFlags /*= 0*/)
		: CInternetSession (pstrAgent, dwContext, dwAccessType, pstrProxyName, 
							pstrProxyBypass, dwFlags)
{
	hWnd = 0;
}

CInternetSessionEx::~CInternetSessionEx()
{
}

// CInternetSessionEx member functions
void CInternetSessionEx::OnStatusCallback(DWORD dwContext, DWORD dwInternetStatus, LPVOID lpvStatusInformation, DWORD dwStatusInformationLength)
{
	AFX_MANAGE_STATE(AfxGetAppModuleState());
	DWORD st = dwInternetStatus;
	CString *pMessage = new CString;

	switch (dwInternetStatus) {
		case INTERNET_STATUS_RESOLVING_NAME:
			*pMessage = "Looking up the IP address of the name contained in lpvStatusInformation.";
			break;
		
		case INTERNET_STATUS_NAME_RESOLVED:
			*pMessage = "Successfully found the IP address of the name contained in lpvStatusInformation.";
			break;

		case INTERNET_STATUS_CONNECTING_TO_SERVER:
			*pMessage = "Connecting to the socket address (SOCKADDR) pointed to by lpvStatusInformation.";
			break;

		case INTERNET_STATUS_CONNECTED_TO_SERVER:
			*pMessage = "Successfully connected to the socket address (SOCKADDR) pointed to by lpvStatusInformation.";
			break;

		case INTERNET_STATUS_SENDING_REQUEST:
			*pMessage = "Sending the information request to the server. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_REQUEST_SENT:
			*pMessage = "Successfully sent the information request to the server. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_RECEIVING_RESPONSE:
			*pMessage = "Waiting for the server to respond to a request. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_RESPONSE_RECEIVED:
			*pMessage = "Successfully received a response from the server. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_CLOSING_CONNECTION:
			*pMessage = "Closing the connection to the server. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_CONNECTION_CLOSED:
			*pMessage = "Successfully closed the connection to the server. The lpvStatusInformation parameter is NULL.";
			break;

		case INTERNET_STATUS_HANDLE_CREATED:
			*pMessage = "Connecting...";
			break;

		case INTERNET_STATUS_HANDLE_CLOSING:
			*pMessage = "Successfully terminated this handle value.";
			break;

		default:
			#ifdef _DEBUG
			pMessage->Format("Unknown Internet status (%d)", dwInternetStatus);
			#endif
			break;
	}
	if (pMessage->GetLength() == 0)
		return;

	if (hWnd == 0)
		hWnd = AfxGetApp()->GetMainWnd()->GetSafeHwnd();
	PostMessage(hWnd, WMU_SESSIONUPDATE, reinterpret_cast<WPARAM>(pMessage), 0);
}