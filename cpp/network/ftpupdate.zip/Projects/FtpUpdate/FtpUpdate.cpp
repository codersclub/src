// FtpUpdate.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "FtpUpdate.h"
#include "FtpUpdateDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif

// CFtpUpdateApp

BEGIN_MESSAGE_MAP(CFtpUpdateApp, CWinApp)
	ON_COMMAND(ID_HELP, CWinApp::OnHelp)
END_MESSAGE_MAP()

// CFtpUpdateApp construction
CFtpUpdateApp::CFtpUpdateApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

// The one and only CFtpUpdateApp object
CFtpUpdateApp theApp;

BOOL CFtpUpdateApp::InitInstance()
{
	CWinApp::InitInstance();
	AfxEnableControlContainer();

	CFtpUpdateDlg dlg;
	m_pMainWnd = &dlg;
	INT_PTR nResponse = dlg.DoModal();

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}
