// ShellListEx.h: interface for the CShellListEx class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_SHELLLIST_H__935A8B41_A4EF_11D3_AA95_0050BAAFC6AA__INCLUDED_)
#define AFX_SHELLLIST_H__935A8B41_A4EF_11D3_AA95_0050BAAFC6AA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CShellList
{
public:

	struct LSICON
	{
		HICON hLarge;
		HICON hSmall;

		CString szTypeName;
	};

	CShellList();

	virtual	~CShellList();

	void CreateImageList();
	// Creates the imagelists
	
private:
	
	void CreatePermanent();
	// Adds specified icons  

public:

	LSICON GetExtIcon(CString szExt);
	// Returns the icons of a certain file type

	LSICON GetDllExeIcon(CString szExeDll = "shell32.dll", int iIconIndex = 0);
	// Returns the icons of an exe file or an icon inside a dll file

	//int AddIcon(HICON hIcon, CString szID);
	int AddIcon(LSICON hIcon, CString szID);
	// Adds an icon to the imagelists and adds their ID to the IDList so 
	// it can be found easily agian if needed

	int AddExtIcon(CString szExt);
	// Does the same thing as AddIcon except it works only with file type
	// extensions

	int FindIconID(CString szID);
	// Finds the index of an icon by their ID.

	void AttachSystemImageList();
	// Attachs the system image list to m_Small and m_Large

	void DetachSystemImageList();
	// Detachs the system image list

	LSICON GetSystemImageListIcon(CString szFile);
	// Gets a file's icon from the system imagelist

private:
	
	CStringArray pszIDList;
	// Holds all icon ID's

public:
	bool bSysImgList;

	CImageList m_Small;
	// Imagelist for small icons
	CImageList m_Large;
	// Imagelist for large icons
};

#endif // !defined(AFX_SHELLLIST_H__935A8B41_A4EF_11D3_AA95_0050BAAFC6AA__INCLUDED_)
