#pragma once

#include "afxwin.h"
#include <string>
#include "afxcmn.h"
#include "afxinet.h"
#include "InternetSessionEx.h"
#include "ShellList.h"
#include "ProgressDlg.h"
#include <vector>

using namespace::std;

struct FileItem 
{
	FileItem() {};
	FileItem(BOOL _isFolder, CString _name, ULONGLONG _size, CTime _time) 
		: isFolder(_isFolder), name(_name), size(_size), time(_time) {};
	BOOL isFolder;
	CString name;
	ULONGLONG size;
	CTime time;
};

// CFtpUpdateDlg dialog
class CFtpUpdateDlg : public CDialog
{
public:
	CFtpUpdateDlg(CWnd* pParent = NULL);
	~CFtpUpdateDlg();
	enum { IDD = IDD_FTPUPDATE_DIALOG };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);

protected:
	HICON m_hIcon;

	CEdit passwordCtrl;
	CEdit ftpAddressCtrl;
	CButton defaultLogonCtrl;
	CButton deleteCtrl;
	CButton connectCtrl;
	CButton copyCtrl;

	string username;
	string address;
	string password;
	vector <FileItem> serverFiles;
	vector <FileItem> localFiles;
	string localPath;

	HCURSOR hCurBusy;
	HCURSOR hCurStandard;

	CEdit nameCtrl;
	CEdit pathEditCtrl;
	CStatic pathStaticCtrl;
	CStatic statusTextCtrl;
	static CListCtrl serverListCtrl;
	static CListCtrl localListCtrl;
	static CFtpConnection* pFtpConnection;
	static bool stopDownload;
	CImageList imageList;
	CShellList shellIconList;
	CInternetSessionEx* pSession;
	CProgressDlg *pProgressDlg;

	LRESULT msgUpdateInternetStatus(WPARAM, LPARAM);
	LRESULT msgStopDownloading(WPARAM wParam, LPARAM lParam);
	LRESULT msgDownloadFinished(WPARAM wParam, LPARAM lParam);
	LRESULT msgDownloadProgress(WPARAM wParam, LPARAM lParam);
	LRESULT msgDownloadException(WPARAM wParam, LPARAM lParam);

	void updateServerList();
	void updateLocalList(void);
	void getServerFiles(void);
	void getLocalFiles(void);
	static UINT getDownloadFileFnc(LPVOID pParam);
	void connect(void);
	void disconnect(void);
	void busyCursor(void);
	void standardCursor(void);
	
	virtual BOOL OnInitDialog();
	void OnEnterLocalList(void);
	void OnBackLocalList(void);
	void OnEnterServerList(void);
	void OnBackServerList(void);
	int PreTranslateMessage(MSG *pMsg);

	// Generated message map functions
	DECLARE_MESSAGE_MAP()
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnPaint();
	afx_msg void OnCopy();
	afx_msg void OnClose();
	afx_msg void OnConnect();
	afx_msg void OnDefaultCheck();
	afx_msg void OnNMDblclkServerList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnKeydownServerList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnItemchangedServerList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnItemchangedLocalList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnLvnKeydownLocalList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnNMDblclkLocalList(NMHDR *pNMHDR, LRESULT *pResult);
	afx_msg void OnDeleteButton();
};
