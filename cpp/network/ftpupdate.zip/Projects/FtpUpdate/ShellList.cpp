#include "stdafx.h"
#include "ShellList.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

CImageList* pSmall;
CImageList* pLarge;

CStringArray* pszList;

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////
CShellList::CShellList()
{
	bSysImgList = false;
}

CShellList::~CShellList()
{
	if(bSysImgList)
	{
		m_Small.Detach();
		m_Large.Detach();
	}
}

/****************************************************************************
* 
*  FUNCTION: CreateImageList()
*
*  PURPOSE : Creates the imagelists and clears the ID list
*
*****************************************************************************/
void CShellList::CreateImageList()
{
	m_Small.DeleteImageList();

	m_Small.Create(16, 16, ILC_MASK | ILC_COLORDDB, 1, 1000);
	m_Small.SetBkColor(ILD_TRANSPARENT);

	m_Large.DeleteImageList();

	m_Large.Create(32, 32, ILC_MASK | ILC_COLORDDB, 1, 1000);
	m_Large.SetBkColor(ILD_TRANSPARENT);

	pszIDList.RemoveAll();

	CreatePermanent();
}

/****************************************************************************
* 
*  FUNCTION: AttachSystemImageList()
*
*  PURPOSE : Attachs the system image list to m_Small and m_Large
*
*****************************************************************************/
void CShellList::AttachSystemImageList()
{
	SHFILEINFO  shInfo; 

	bSysImgList = true;

	m_Small.Attach((HIMAGELIST)SHGetFileInfo("C:\\", 0, 
	  &shInfo, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_SMALLICON)); 

	m_Large.Attach((HIMAGELIST)SHGetFileInfo("C:\\", 0, 
	  &shInfo, sizeof(SHFILEINFO), SHGFI_SYSICONINDEX | SHGFI_ICON));
}

/****************************************************************************
* 
*  FUNCTION: DetachSystemImageList()
*
*  PURPOSE : Detachs the system imagelist from m_Small and m_Large
*
*****************************************************************************/
void CShellList::DetachSystemImageList()
{
	m_Small.Detach();
	m_Large.Detach();

    bSysImgList = false;
}

/****************************************************************************
* 
*  FUNCTION: LSICON GetSystemImageListIcon(CString szFile)
*  RETURN  : returns a SHFILEINFO with 
*  PURPOSE : User specified
*
*****************************************************************************/
CShellList::LSICON CShellList::GetSystemImageListIcon(CString szFile)
{   
	LSICON lsIcon;
	SHFILEINFO shInfo;

    SHGetFileInfo(szFile, 0, &shInfo, sizeof(SHFILEINFO),  
		SHGFI_SYSICONINDEX | SHGFI_SMALLICON | SHGFI_ICON);
	
	lsIcon.hSmall = shInfo.hIcon;

    SHGetFileInfo(szFile, 0, &shInfo, sizeof(SHFILEINFO),  
		SHGFI_SYSICONINDEX | SHGFI_ICON);
	
	lsIcon.hLarge = shInfo.hIcon;

    return lsIcon;
}

/****************************************************************************
* 
*  FUNCTION: CreatePermanent()
*
*  PURPOSE : User specified
*
*****************************************************************************/
void CShellList::CreatePermanent()
{
	// Add icons manually here

	AddIcon(GetDllExeIcon(), "*"); // Do not remove - used in 
								   // GetDllExeIcon

	// adds the default file icon in windows to the imagelist

	AddIcon(GetDllExeIcon("shell32.dll", 3), ".");
	// add the folder icon in windows to the imagelist
}

/****************************************************************************
* 
*  FUNCTION: LSICON GetDllExeIcon(CString szDllExe, int iIconIndex = 0)
*  RETURN  : contains small and large icon
*
*  PURPOSE : Retrieves the large and small icon in a exe or dll file
*
*  EXAMPLE : GetDllExeIcon("shell32.dll", 3) / GetDllExeIcon("setup.exe")
*
*****************************************************************************/
CShellList::LSICON CShellList::GetDllExeIcon(CString szExeDll, int iIconIndex)
{
	HICON hLarge, hSmall;
	LSICON lsIcon;

	ExtractIconEx(szExeDll, iIconIndex, &hLarge, &hSmall, 1);

	lsIcon.hLarge = hLarge;
	lsIcon.hSmall = hSmall;

	return lsIcon;
}

/****************************************************************************
* 
*  FUNCTION: LSICON GetExtIcon(CString szExt) 
*  RETURN  : returns LSICON with small & large icon and full name of ext
*
*  PURPOSE : Retrieves and icon via its extension 
*
*  EXAMPLE : GetExtIcon(".txt")
*
*****************************************************************************/
CShellList::LSICON CShellList::GetExtIcon(CString szExt)
{
	SHFILEINFO shInfo;
	LSICON lsIcon;

	memset(&shInfo, 0, sizeof(shInfo));
	
	SHGetFileInfo(szExt,FILE_ATTRIBUTE_NORMAL, &shInfo, sizeof(shInfo), 
		SHGFI_USEFILEATTRIBUTES | SHGFI_DISPLAYNAME | 
		SHGFI_TYPENAME | SHGFI_ICON | SHGFI_SMALLICON);

	if(shInfo.hIcon == NULL)
		lsIcon.hSmall = m_Small.ExtractIcon(0);
		// if icon is empty then use the default file icon
	else
		lsIcon.hSmall = shInfo.hIcon;

	memset(&shInfo, 0, sizeof(shInfo));

	SHGetFileInfo(szExt, FILE_ATTRIBUTE_NORMAL, &shInfo, sizeof(shInfo), 
		SHGFI_USEFILEATTRIBUTES | SHGFI_DISPLAYNAME | 
		SHGFI_TYPENAME | SHGFI_ICON);

	if(shInfo.hIcon == NULL)
		lsIcon.hLarge = m_Large.ExtractIcon(0);
		// if icon is empty then use the default file icon 
	else
		lsIcon.hLarge = shInfo.hIcon;
		
	lsIcon.szTypeName = shInfo.szTypeName;

	return lsIcon;
}

/****************************************************************************
* 
*  FUNCTION: int AddIcon(CShellList::LSICON hIcon, CString szID)
*  RETURN  : index of the icon that was added to the imagelist
*
*  PURPOSE : Adds a icons to the imagelist
*
*  EXAMPLE : AddIcon(lsIcon, "myicon");
*
*****************************************************************************/
int CShellList::AddIcon(CShellList::LSICON hIcon, CString szID)
{	
	m_Small.Add(hIcon.hSmall);
	m_Large.Add(hIcon.hLarge);

	return static_cast<int>(pszIDList.Add(szID));
}

/****************************************************************************
* 
*  FUNCTION: int FindIconID(CString szID)
*  RETURN  : contains index of item found, otherwise -1
*
*  PURPOSE : Finds an icon in the imagelist via its ID
*
*  EXAMPLE : FindIconID(".txt")
*
*****************************************************************************/
int CShellList::FindIconID(CString szID)
{
	szID.MakeLower();

	BOOL bFound = FALSE;

	for (int x = 0; x != pszIDList.GetSize(); x++)
		if(pszIDList.GetAt(x) == szID) 
		{
			bFound = TRUE;
			break;
		}

		if(bFound == FALSE) return -1;

	return x;
}

/****************************************************************************
* 
*  FUNCTION: int AddExtIcon(CString szExt)
*  RETURN  : contains index of file type icon added
*
*  PURPOSE : Adds a specified file type icon to the imagelist 
*
*  EXAMPLE : AddExtIcon(".txt")
*
*****************************************************************************/
int CShellList::AddExtIcon(CString szExt)
{
	int x = FindIconID(szExt);

	if(x == -1)
		return AddIcon(GetExtIcon(szExt), szExt);

	return x;	
}
