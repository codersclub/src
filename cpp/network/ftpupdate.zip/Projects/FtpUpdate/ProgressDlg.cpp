// ProgressDlg.cpp : implementation file
//

#include "stdafx.h"
#include "FtpUpdate.h"
#include "ProgressDlg.h"


// CProgressDlg dialog

IMPLEMENT_DYNAMIC(CProgressDlg, CDialog)
CProgressDlg::CProgressDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CProgressDlg::IDD, pParent)
{
}

CProgressDlg::~CProgressDlg()
{
}

void CProgressDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Control(pDX, IDC_PROGRESS_BAR, progressBarCtrl);
	DDX_Control(pDX, IDC_PERCENT, percentCtrl);
}

BEGIN_MESSAGE_MAP(CProgressDlg, CDialog)
	ON_BN_CLICKED(IDC_STOP, OnBnClickedStop)
END_MESSAGE_MAP()


// CProgressDlg message handlers

void CProgressDlg::OnBnClickedStop()
{
	::PostMessage(AfxGetApp()->GetMainWnd()->GetSafeHwnd(), WMU_STOPDOWNLOAD, 0, 0);
}

void CProgressDlg::setProgress(int progress)
{
	progress = progress < 0 ? 0 : progress;
	progress = progress > 100 ? 100 : progress;
	progressBarCtrl.SetPos(progress);
	CString prog;
	prog.Format("%d %%", progress);
	percentCtrl.SetWindowText(prog);
}

BOOL CProgressDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	progressBarCtrl.SetRange(0, 100);
	return TRUE;
}
