// MultiDialog.h: interface for the CMultiDialog class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_MULTIDIALOG_H__6084EBF2_F15C_4DE4_87BA_76FA9300075F__INCLUDED_)
#define AFX_MULTIDIALOG_H__6084EBF2_F15C_4DE4_87BA_76FA9300075F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <list>

class CMultiDialog : public CDialog  
{
	typedef std::list<CWnd*> WndList;
	typedef std::list<CWnd*>::iterator WndListIter;

	typedef std::list<CFont*> FontList;
	typedef std::list<CFont*>::iterator FontListIter;
	
	WndList m_ChildList;		// List of created child windows
	FontList m_FontList;		// List of created fonts
	CFont *m_pCurrentFont;
	
public:
	CMultiDialog() {};
	CMultiDialog( LPCTSTR lpszTemplateName, CWnd *pParent = NULL ) : CDialog( lpszTemplateName, pParent ) {}
	CMultiDialog( UINT nIDTemplate,	CWnd *pParent = NULL ) : CDialog( nIDTemplate, pParent ) {};

	virtual ~CMultiDialog() {};

	void AddDialog( UINT id, UINT idMarker );

	virtual void PostNcDestroy();
	
private:
	WORD * ReadTemplateArray( WORD *pArray, WORD &ID, CString &name );
	DLGITEMTEMPLATE * AddDialogItem( DLGITEMTEMPLATE *pItem, LPRECT pRect );
};

#endif // !defined(AFX_MULTIDIALOG_H__6084EBF2_F15C_4DE4_87BA_76FA9300075F__INCLUDED_)
