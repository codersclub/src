// ==========================================================================
// MainFrm.cpp
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

// ==========================================================================
// Les Includes
// ==========================================================================

#include "stdafx.h"
#include "PrintListCtrlTester.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNCREATE(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame construction/destruction

CMainFrame::CMainFrame()
 {
 }

CMainFrame::~CMainFrame()
 {
 }

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
 {
  if (CFrameWnd::OnCreate(lpCreateStruct) == -1) return -1;

  return 0;
 }

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
 {
  if( !CFrameWnd::PreCreateWindow(cs) ) return FALSE;

  return TRUE;
 }

/////////////////////////////////////////////////////////////////////////////
// CMainFrame diagnostics

#ifdef _DEBUG
void CMainFrame::AssertValid() const
 {
  CFrameWnd::AssertValid();
 }

void CMainFrame::Dump(CDumpContext& dc) const
 {
  CFrameWnd::Dump(dc);
 }

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame message handlers

