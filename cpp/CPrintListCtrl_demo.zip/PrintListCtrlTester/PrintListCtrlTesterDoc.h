// ==========================================================================
// PrintListCtrlTesterDoc.h
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

#if !defined(AFX_PRINTLISTCTRLTESTERDOC_H__14C4339B_056A_11D4_A146_004005555C30__INCLUDED_)
#define AFX_PRINTLISTCTRLTESTERDOC_H__14C4339B_056A_11D4_A146_004005555C30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CPrintListCtrlTesterDoc : public CDocument
 {
  protected :
              CPrintListCtrlTesterDoc();
              DECLARE_DYNCREATE(CPrintListCtrlTesterDoc)

  public :

  public :
	//{{AFX_VIRTUAL(CPrintListCtrlTesterDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

  public :
           virtual ~CPrintListCtrlTesterDoc();
           #ifdef _DEBUG
           virtual void AssertValid() const;
           virtual void Dump(CDumpContext& dc) const;
           #endif

  protected :

  protected :
	//{{AFX_MSG(CPrintListCtrlTesterDoc)
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
 };

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PRINTLISTCTRLTESTERDOC_H__14C4339B_056A_11D4_A146_004005555C30__INCLUDED_)
