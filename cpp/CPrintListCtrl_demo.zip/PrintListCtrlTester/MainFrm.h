// ==========================================================================
// MainFrm.h
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

#if !defined(AFX_MAINFRM_H__14C43399_056A_11D4_A146_004005555C30__INCLUDED_)
#define AFX_MAINFRM_H__14C43399_056A_11D4_A146_004005555C30__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CMainFrame : public CFrameWnd
 {
  protected :
              CMainFrame();
              
              DECLARE_DYNCREATE(CMainFrame)

  public :
	//{{AFX_VIRTUAL(CMainFrame)
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

  public :
           virtual ~CMainFrame();
           #ifdef _DEBUG
           virtual void AssertValid() const;
           virtual void Dump(CDumpContext& dc) const;
           #endif

  protected :
	//{{AFX_MSG(CMainFrame)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
 };

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MAINFRM_H__14C43399_056A_11D4_A146_004005555C30__INCLUDED_)
