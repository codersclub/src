; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CPrintListCtrlTesterView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "PrintListCtrlTester.h"
LastPage=0

ClassCount=5
Class1=CPrintListCtrlTesterApp
Class2=CPrintListCtrlTesterDoc
Class3=CPrintListCtrlTesterView
Class4=CMainFrame

ResourceCount=10
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource7=IDD_PRINTLISTCTRLTESTER_FORM
Resource8=IDD_ABOUTBOX (English (U.S.))
Resource9=IDR_MAINFRAME (English (U.S.))
Class5=CAboutDlg
Resource10=IDD_PRINTLISTCTRLTESTER_FORM (English (U.S.))

[CLS:CPrintListCtrlTesterApp]
Type=0
HeaderFile=PrintListCtrlTester.h
ImplementationFile=PrintListCtrlTester.cpp
Filter=N

[CLS:CPrintListCtrlTesterDoc]
Type=0
HeaderFile=PrintListCtrlTesterDoc.h
ImplementationFile=PrintListCtrlTesterDoc.cpp
Filter=N

[CLS:CPrintListCtrlTesterView]
Type=0
HeaderFile=PrintListCtrlTesterView.h
ImplementationFile=PrintListCtrlTesterView.cpp
Filter=D
BaseClass=CFormView
VirtualFilter=VWC
LastObject=IDPB_PRINTSETUP


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T




[CLS:CAboutDlg]
Type=0
HeaderFile=PrintListCtrlTester.cpp
ImplementationFile=PrintListCtrlTester.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_PRINT
Command6=ID_FILE_PRINT_PREVIEW
Command7=ID_FILE_PRINT_SETUP
Command8=ID_FILE_MRU_FILE1
Command9=ID_APP_EXIT
Command10=ID_EDIT_UNDO
Command11=ID_EDIT_CUT
Command12=ID_EDIT_COPY
Command13=ID_EDIT_PASTE
Command14=ID_APP_ABOUT
CommandCount=14
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
CommandCount=14
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE

[DLG:IDD_PRINTLISTCTRLTESTER_FORM]
Type=1
Class=CPrintListCtrlTesterView

[DLG:IDD_PRINTLISTCTRLTESTER_FORM (English (U.S.))]
Type=1
Class=?
ControlCount=25
Control1=IDLC_LISTCTRL,SysListView32,1350664197
Control2=IDPB_PRINT,button,1342242816
Control3=IDPB_PRINTSETUP,button,1342242816
Control4=IDCB_PRINTHEAD,button,1342242819
Control5=IDCB_PRINTFOOT,button,1342242819
Control6=IDCB_PRINTCOLUMNSEPARATOR,button,1342242819
Control7=IDCB_PRINTLINESEPARATOR,button,1342242819
Control8=IDCB_RESIZECOLUMNS,button,1342242819
Control9=IDCB_TRUNCATECOLUMN,button,1342242819
Control10=IDCB_PRINTHEADBKGND,button,1342242819
Control11=IDED_HEADFONTNAME,edit,1350631552
Control12=IDED_HEADFONTHEIGHT,edit,1350639745
Control13=IDC_SPIN1,msctls_updown32,1342177334
Control14=IDED_LISTFONTNAME,edit,1350631552
Control15=IDED_LISTFONTHEIGHT,edit,1350639745
Control16=IDC_SPIN2,msctls_updown32,1342177334
Control17=IDED_FOOTFONTNAME,edit,1350631552
Control18=IDED_FOOTFONTHEIGHT,edit,1350639745
Control19=IDC_SPIN3,msctls_updown32,1342177334
Control20=IDC_STATIC,button,1342177287
Control21=IDC_STATIC,static,1342177792
Control22=IDC_STATIC,static,1342177792
Control23=IDC_STATIC,static,1342177280
Control24=IDC_STATIC,static,1342177792
Control25=IDCB_PRINTFOOTBKGND,button,1342242819

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_PRINT
Command6=ID_FILE_PRINT_PREVIEW
Command7=ID_FILE_PRINT_SETUP
Command8=ID_APP_EXIT
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_APP_ABOUT
CommandCount=13

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

