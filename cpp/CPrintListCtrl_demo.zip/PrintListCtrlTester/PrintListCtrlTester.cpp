// ==========================================================================
// PrintListCtrlTester.cpp
// 
// Author : Marquet Mike
//
// Last Modified : 29/03/2000
// by            : MMA
// ==========================================================================

// ==========================================================================
// Les Includes
// ==========================================================================

#include "stdafx.h"
#include "PrintListCtrlTester.h"

#include "MainFrm.h"
#include "PrintListCtrlTesterDoc.h"
#include "PrintListCtrlTesterView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterApp

BEGIN_MESSAGE_MAP(CPrintListCtrlTesterApp, CWinApp)
	//{{AFX_MSG_MAP(CPrintListCtrlTesterApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
	//}}AFX_MSG_MAP
	ON_COMMAND(ID_FILE_NEW, CWinApp::OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, CWinApp::OnFileOpen)
	ON_COMMAND(ID_FILE_PRINT_SETUP, CWinApp::OnFilePrintSetup)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterApp construction

CPrintListCtrlTesterApp::CPrintListCtrlTesterApp()
 {
 }

/////////////////////////////////////////////////////////////////////////////
// The one and only CPrintListCtrlTesterApp object

CPrintListCtrlTesterApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterApp initialization

BOOL CPrintListCtrlTesterApp::InitInstance()
 {
  #ifdef _AFXDLL
  Enable3dControls();			// Call this when using MFC in a shared DLL
  #else
  Enable3dControlsStatic();	// Call this when linking to MFC statically
  #endif

  SetRegistryKey(_T("PrintListCtrlTester"));

  LoadStdProfileSettings(0);  // Load standard INI file options (including MRU)

  CSingleDocTemplate *pDocTemplate;

  pDocTemplate = new CSingleDocTemplate(
                                        IDR_MAINFRAME,
                                        RUNTIME_CLASS(CPrintListCtrlTesterDoc),
                                        RUNTIME_CLASS(CMainFrame),
                                        RUNTIME_CLASS(CPrintListCtrlTesterView));
  AddDocTemplate(pDocTemplate);

  // Parse command line for standard shell commands, DDE, file open
  CCommandLineInfo cmdInfo;
  ParseCommandLine(cmdInfo);

  // Dispatch commands specified on the command line
  if (!ProcessShellCommand(cmdInfo)) return FALSE;

  // The one and only window has been initialized, so show and update it.
  m_pMainWnd->ShowWindow(SW_SHOW);
  m_pMainWnd->UpdateWindow();

  return TRUE;
 }

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
 {
  public :
           CAboutDlg();

  public :
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

  protected :
	//{{AFX_MSG(CAboutDlg)
	//}}AFX_MSG
  DECLARE_MESSAGE_MAP()
 };

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
 {
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
 }

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
 {
  CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
 }

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// App command to run the dialog
void CPrintListCtrlTesterApp::OnAppAbout()
 {
  CAboutDlg aboutDlg;
  aboutDlg.DoModal();
 }

/////////////////////////////////////////////////////////////////////////////
// CPrintListCtrlTesterApp message handlers

