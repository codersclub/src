//------------------------------------------------------------------//
//- The Infinity 2D DirectDraw7 Game Engine header				   -//
//------------------------------------------------------------------//
//-							Created By							   -//
//-						   Trent Polack							   -//
//-              Founder, and Lead Programmer of				   -//
//-						 NovaStorm Games						   -//
//------------------------------------------------------------------//

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#define WIN32_LEAN_AND_MEAN  // MFC!=good  ^_^

#define INITGUID			//the guid library

#include "Infinity2d.h"

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- GLOBALS --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

/* DirectDraw stuff */
LPDIRECTDRAW7         lpdd         =NULL;    // DirectDraw7 object
LPDIRECTDRAWSURFACE7  lpddsprimary =NULL;    // DirectDraw7 primary surface
LPDIRECTDRAWSURFACE7  lpddsback    =NULL;    // DirectDraw7 back surface (back buffer)
LPDIRECTDRAWCLIPPER   lpddclipper  =NULL;	 // DirectDraw clipper
DDSURFACEDESC2        ddsd;                  // DirectDraw surface description struct
DDBLTFX               ddbltfx;               // used to fill


/* DirectInput stuff */
LPDIRECTINPUT7		  lpdi=NULL;			 //The main DirectInput object
LPDIRECTINPUTDEVICE7  lpdikeyboard=NULL;	 //The main DirectInput keyboard object
LPDIRECTINPUTDEVICE7  lpdimouse=NULL;		 //The main DirectInput mouse object
UCHAR				  keybuffer[256];		 //The main keyboard buffer
DIMOUSESTATE2         mousestate;			 //The main mouse state object


/* DirectSound stuff */
LPDIRECTSOUND		lpds=NULL;		//The DirectSound main object
DSBUFFERDESC		dsbd;           //The DirectSound object description
DSCAPS			    dscaps;         //The DirectSound caps
DSBCAPS			    dsbcaps;        //The DirectSound buffer caps
LPDIRECTSOUNDBUFFER lpdsbprimary=NULL;   //The primary sound buffer
WAVEFORMATEX		pcmwf;          //The waveformat structure
SOUND               sound[MAX_SOUNDS];
HMMIO 			    hwav;			//Handle to a .wav file
MMCKINFO		    parent;			//The parent chunk
MMCKINFO            child;			//The child chunk
WAVEFORMATEX        wfmtx;			//Wave format chunk


int SCREEN_WIDTH =NULL;		//used to hold screen's width
int SCREEN_HEIGHT=NULL;		//used to hold screen's height
int SCREEN_BPP   =NULL;		//used to hold screen's bits per pixel


float COS[360];
float SIN[360];
float COS16[16];
float SIN16[16];

HRESULT result=NULL;

HWND	  hwnd=NULL;				//main window's handles
HINSTANCE hinstance=NULL;		// globally track hinstance
HDC		  hdc=NULL;

int primary_lpitch=0;			//pitch of the primary buffer
int back_lpitch=0;				//pitch of the back buffer
USHORT*primary_buffer=NULL;		//pointer to primary buffer
USHORT* back_buffer=NULL;			//pointer to back buffer

char buffer[80];                     // general printing buffer

DWORD clock_count;

PARTICLE particle[MAX_PARTICLES]; //start # of particles
float gravity=0;
float wind=0;
float x[MAX_PARTICLES];
float y[MAX_PARTICLES];
//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- DEFINITIONS ----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//- void DD_Init(int,int,int) --------------------------------------//
//------------------------------------------------------------------//
//- This function initializes everything you will need for DDraw ---//
//- and is pathetically easy to use.  Just make a call to it when --//
//- you initialize the program.  You might want to make the screen's//
//- dimensions a constant though. And, ALWAYS, ALWAYS make the -----// 
//- screen's bits per pixel *16*.  This engine is made for only 16 -//
//- bit, because its the perfect medium for speed and nice colors :)//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-              #define SCREEN_WIDTH  800                         -//
//-              #define SCREEN_HEIGHT 1000                        -//
//-              #define SCREEN_BPP    16                          -//
//- DD_Init(SCREEN_WIDTH, SCREEN_HEIGHT, SCREEN_BPP)               -//
//------------------------------------------------------------------//
HRESULT DD_Init(int screenwidth, int screenheight, int screenbpp)
	{
	SCREEN_WIDTH =screenwidth;			//set global window values
	SCREEN_HEIGHT=screenheight;
	SCREEN_BPP   =screenbpp;

	result=(DirectDrawCreateEx(NULL, (VOID**)&lpdd, IID_IDirectDraw7, NULL));
    if(result!=DD_OK)
		return MessageBox(hwnd, "Could not create DirectDraw7 object", TITLE, MB_OK);

    // Get exclusive mode
    result=(lpdd->SetCooperativeLevel(hwnd, 
									  DDSCL_ALLOWMODEX | DDSCL_ALLOWREBOOT |
									  DDSCL_EXCLUSIVE | DDSCL_FULLSCREEN));
    if(result!=DD_OK)
		return MessageBox(hwnd, "Could not set cooperation level", TITLE, MB_OK);

    // Set the video mode to user defined width, height, and bpp
    result=(lpdd->SetDisplayMode(SCREEN_WIDTH,SCREEN_HEIGHT,SCREEN_BPP,0,0));
    if(result!=DD_OK)
		return MessageBox(hwnd, "Could not set 800x600x16 display", TITLE, MB_OK);

    // Create the primary surface with 1 back buffer
	memset(&ddsd,0,sizeof(ddsd)); 
	ddsd.dwSize=sizeof(ddsd);

    ddsd.dwFlags=DDSD_CAPS | DDSD_BACKBUFFERCOUNT;

    ddsd.dwBackBufferCount=1;			//request one backbuffer

    ddsd.ddsCaps.dwCaps=DDSCAPS_PRIMARYSURFACE | 
						DDSCAPS_FLIP |
                        DDSCAPS_COMPLEX;

    result=(lpdd->CreateSurface(&ddsd, &lpddsprimary, NULL));
    if(result!=DD_OK)
		return MessageBox(hwnd, "Could not create DirectDraw Surface7 object", TITLE, MB_OK);

    // Get a pointer to the back buffer
    ddsd.ddsCaps.dwCaps = DDSCAPS_BACKBUFFER;
    result=(lpddsprimary->GetAttachedSurface(&ddsd.ddsCaps, &lpddsback));
    if(result!=DD_OK)
		return MessageBox(hwnd, "Could not create DirectDraw back buffer", TITLE, MB_OK);
	
	Surface_Fill(lpddsprimary,0,0,0);		//clear the buffers
	Surface_Fill(lpddsback,0,0,0);

	CosSin_Init();

	return(1);
	}

//------------------------------------------------------------------//
//- void DD_Shutdown(void) -----------------------------------------//
//------------------------------------------------------------------//
//- This one is a complete no-brainer.  In the shutdown loop of ----//
//- Your proggy, just put a call to this in it                  ----//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-              DD_Shutdown();                                    -//
//------------------------------------------------------------------//
void DD_Shutdown(void)
	{
	Surface_Fill(lpddsprimary,0,0,0);		//clear the buffers
	Surface_Fill(lpddsback,0,0,0);

    if(lpdd!=NULL)
		{
		if(lpddsback!=NULL)
			{
			lpddsback->Release();
			lpddsback=NULL;
			}

		if(lpddsprimary!=NULL)
			{
			lpddsprimary->Release();
			lpddsprimary=NULL;
			}
		lpdd->Release();
		lpdd=NULL;
		}
	}

//------------------------------------------------------------------//
//- LPDIRECTDRAWCLIPPER DD_Attach_Clipper(LPDIRECTDRAWSURFACE7) ----//
//------------------------------------------------------------------//
//- This one is so simple to use, you couldn't possibly screw it ---//
//- up.  All you have to do is make a call to it after you intialize//
//- DirectDraw.  And attach it to a surface (most likely ONLY the --//
//- the back buffer, because everything goes on there, and if you --//
//- clip it once, you don't need to do it again). ------------------//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             DD_Attach_Clipper(lpddsback);					   -//
//------------------------------------------------------------------//
BOOL DD_Attach_Clipper(LPDIRECTDRAWSURFACE7 lpdds)

	{
	HRESULT hr;

	hr=(lpdd->CreateClipper(0,
						    &lpddclipper,
						    NULL));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not create a DirectDraw Clipper",
				   TITLE, MB_OK);
		return FALSE;
		}

	hr=(lpddclipper->SetHWnd(0, hwnd));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not create Clip List", TITLE, MB_OK);
		return FALSE;
		}

	hr=(lpdds->SetClipper(lpddclipper));
	if(FAILED(hr))
		{
		MessageBox(hwnd, "Could not create a DirectDraw clipper",
				   TITLE, MB_OK);
		return FALSE;
		}

	return TRUE;
	} // end DDraw_Attach_Clipper

//------------------------------------------------------------------//
//- inline BOOL Primary_Plot_Pixel(int,int,USHORT) -----------------//
//- Thank you Andr� LaMothe! ---------------------------------------//
//------------------------------------------------------------------//
//- This one just plots a pixel on the primary buffer, just give it-//
//- an x, and y coordinate.  And an RGB encoded USHORT. Make sure  -//
//- that you lock the primary surface... MAKE SURE!!!              -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Lock_Primary_Buffer();                             -//
//-             Primary_Plot_Pixel(200,200, RGB16BIT565(0,255,0)); -//
//-             Unlock_Primary_Buffer();                           -//
//------------------------------------------------------------------//
inline void Primary_Plot_Pixel(int x, int y,USHORT color)
	{
	if(!primary_buffer)
		return;

	primary_buffer[x + y*primary_lpitch]=color;
	} 

//------------------------------------------------------------------//
//- inline BOOL Back_Plot_Pixel(int,int,USHORT) --------------------//
//- Thank you Andr� LaMothe! ---------------------------------------//
//------------------------------------------------------------------//
//- This one just plots a pixel on the back buffer, just give it an-//
//- x, and y coordinate.  And an RGB encoded USHORT. Make sure that-//
//- you lock the back surface... MAKE SURE!!!                      -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Lock_Back_Buffer();                                -//
//-             Back_Plot_Pixel(200,200, RGB16BIT565(0,255,0));    -//
//-             Unlock_Back_Buffer();                              -//
//------------------------------------------------------------------//
inline void Back_Plot_Pixel(int x, int y, USHORT color)
	{
	if(!back_buffer)
		return;

	back_buffer[x + y*back_lpitch]=color;
	} 

//------------------------------------------------------------------//
//- void Memory_Fill(int,int,int,int,int,int,int) ------------------//
//------------------------------------------------------------------//
//- This one just draws a colored rectangle at your coordinates.   -//
//- With (x1,y1) being the upper-left.                             -//
//- And (x2,y2) being the lower-right.                             -//
//- MAKE SURE that the surface is *NOT* locked when you do this    -//
//------------------------------------------------------------------//
//- Sample Use:                                                    -//
//-             Memory_Fill(lpddsback,0,0,200,300,0,255,0);        -//
//------------------------------------------------------------------//
void Memory_Fill(LPDIRECTDRAWSURFACE7 surface,
				 int x1, int y1, int x2, int y2, int r, int g, int b)
	{
	DDBLTFX ddbltfxmem;					//local ddbltfx object
	RECT destination;					//create a rectangle for the 
										//destination surface		

	DDRAW_INIT_STRUCT(ddbltfxmem);			//clear the ddbltfx structure

	if(r>256)							//make sure that user didn't 
		r=256;							//enter an invalid color
	if(g>256)							//amount
		g=256;
	if(b>256)
		b=256;

	ddbltfxmem.dwFillColor=RGB16BIT565(r,g,b);	//set the fill color

	destination.left=x1;				//set the destination
	destination.top=y1;					//coordinates
	destination.right=x2;
	destination.bottom=y2;

	surface->Blt(&destination,		//pointer to destination RECT
				 NULL,				//no source surface
				 NULL,				//no source RECT
				 DDBLT_COLORFILL | DDBLT_WAIT,	//colorfill, and wait if needed
				 &ddbltfxmem);			//pointer to ddbltfx structure
	}

//------------------------------------------------------------------//
//- void Surface_Fill(LPDIRECTDRAWSURFACE7,int,int,int) ------------//
//------------------------------------------------------------------//
//- This one clears a surface to a color that you would like.      -//
//- Mostly used to erase everything that is on a buffer            -//
//- And remember, that the primary buffer does not need to be      -//
//- cleared if you are page flipping (making a call to Flip();     -//
//------------------------------------------------------------------//
//- Sample Use:                                                    -//
//-            Surface_Fill(lpddsback, 0,0,0);                     -//
//------------------------------------------------------------------//
void Surface_Fill(LPDIRECTDRAWSURFACE7 surface, int r, int g, int b)
	{	
	DDBLTFX ddbltfxmem;					//local ddbltfx structure
		
	DDRAW_INIT_STRUCT(ddbltfxmem);			//clear the ddbltfx structure

	ddbltfxmem.dwFillColor=RGB16BIT565(r,g,b);	//set the fill color

	surface->Blt(NULL,				//pointer to destination RECT
				 NULL,				//no source surface
				 NULL,				//no source RECT
				 DDBLT_COLORFILL | DDBLT_WAIT,	//colorfill, and wait if needed
				 &ddbltfxmem);		//pointer to ddbltfx structure
	}

//------------------------------------------------------------------//
//- USHORT* Lock_Back_Buffer(void) ---------------------------------//
//------------------------------------------------------------------//
//- This one locks the back buffer, so you can access the surface's-//
//- memory. If you lock, you *MUST* unlock, or bad things happen   -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Lock_Back_Buffer();                                -//
//------------------------------------------------------------------//
USHORT* Lock_Back_Buffer(void)
	{
	// is the back buffer already locked?
	if(back_buffer)
	   return(back_buffer);		//if so, return the current lock!

	// lock the back buffer
	DDRAW_INIT_STRUCT(ddsd);

	lpddsback->Lock(NULL,
					&ddsd,
					DDLOCK_WAIT | DDLOCK_SURFACEMEMORYPTR,
					NULL); 

	back_buffer=(USHORT *)ddsd.lpSurface;	//set the back buffer globals
	back_lpitch=(int)(ddsd.lPitch >> 1);

	return(back_buffer);		//return a pointer to the back buffer
	}

//------------------------------------------------------------------//
//- USHORT* Lock_Primary_Buffer(void) ------------------------------//
//------------------------------------------------------------------//
//- This one locks the primary buffer, so you can access the       -//
//- surface's memory. If you lock, you *MUST* unlock, or bad things-//
//- happen.  Such as big pink bunnies haunting you during the night-//
//- .... or maybe thats just what happens to me after a lot of     -//
//- Mountain Dews.  Oh well, I guess I'll never know               -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Lock_Primary_Buffer();                             -//
//------------------------------------------------------------------//
USHORT* Lock_Primary_Buffer(void)
	{
	if(primary_buffer)			//is there already a primary lock?
	   return(primary_buffer);	//if so, keep the current one
	
	DDRAW_INIT_STRUCT(ddsd);

	lpddsprimary->Lock(NULL,		//NULL to lock the entire surface 
					   &ddsd,	    //surface description
					   DDLOCK_SURFACEMEMORYPTR | DDLOCK_WAIT,
					   NULL);
	
	primary_buffer=(USHORT *)ddsd.lpSurface;	//set the primary globals
	primary_lpitch=(int)(ddsd.lPitch >> 1);

	return(primary_buffer);		//return the primary globals
	}

//------------------------------------------------------------------//
//- BOOL Unlock_Back_Buffer(void) ----------------------------------//
//------------------------------------------------------------------//
//- This one unlocks the back buffer, only used once the surface   -//
//- once you have actually locked the surface. But then, you       -//
//- should already know this, right?  ;)                           -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Unlock_Back_Buffer(void)                           -//
//------------------------------------------------------------------//
BOOL Unlock_Back_Buffer(void)
	{
	//Is the Back Buffer true?
	if(!back_buffer)
	   return FALSE;

	lpddsback->Unlock(NULL);		//unlock the back buffer

	back_buffer=NULL;				//reset the back buffer globals
	back_lpitch=0;

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL Unlock_Primary_Buffer(void) -------------------------------//
//------------------------------------------------------------------//
//- This one unlocks the primary buffer, only used once the surface-//
//- once you have actually locked the surface. But then, you       -//
//- should already know this, right?  ;)                           -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Unlock_Primary_Buffer(void)                        -//
//------------------------------------------------------------------//
BOOL Unlock_Primary_Buffer(void)
	{
	//Is the primary buffer true?
	if (!primary_buffer)
	   return FALSE;

	lpddsprimary->Unlock(NULL);		//unlock the primary buffer

	primary_buffer = NULL;			//reset the primary globals
	primary_lpitch = 0;

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL Flip(void) ------------------------------------------------//
//------------------------------------------------------------------//
//- This one copies the information on the back buffer to the      -//
//- primary buffer. This process is called "Page Flipping," or a   -//
//- way to implement double buffering for smoothness in your games -//
//- and you ARE making games?  RIGHT?!  ;P                         -//
//- And oh, by the way, put this call at the very end of your      -//
//- drawing loop.                                                  -//
//------------------------------------------------------------------//
//- Sample Use:                                                    -//
//-             Flip();                                            -//
//------------------------------------------------------------------//
BOOL Flip(void)
	{
	// test if either of the buffers are locked
	if(primary_buffer || back_buffer)
	   return FALSE;

	// flip pages
	while(FAILED(lpddsprimary->Flip(NULL, DDFLIP_WAIT)));

	// return success
	return TRUE;
	}

//------------------------------------------------------------------//
//- DDRAWSURFACE7 DD_Create_Surface(int,int,int) -------------------//
//------------------------------------------------------------------//
//- This function creates an offscreen surface.  You won't need    -//
//- function much, as I provide the utilities that you will want   -//
//- below.                                                         -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             LPDIRECTDRAWSURFACE surface=NULL;                  -//
//-                                                                -//
//-         surface=DD_Create_Surface(100,100,DDSCAPS_VIDEOMEMORY);-// 
//------------------------------------------------------------------//
LPDIRECTDRAWSURFACE7 DD_Create_Surface(int width, 
									   int height, 
									   int memory_flag)
	{
	DDSURFACEDESC2		 ddsd;		//temporary objects
	LPDIRECTDRAWSURFACE7 lpdds;

	DDRAW_INIT_STRUCT(ddsd);		//init the struct

	ddsd.dwFlags	=DDSD_WIDTH | DDSD_HEIGHT |
					DDSD_CAPS  | DDSD_CKSRCBLT;

	ddsd.dwWidth	=width;
	ddsd.dwHeight	=height;

	//set the surface to an offscreen plain
	ddsd.ddsCaps.dwCaps=DDSCAPS_OFFSCREENPLAIN | memory_flag;

	ddsd.ddckCKSrcBlt.dwColorSpaceLowValue =RGB16BIT565(0,0,0);
	ddsd.ddckCKSrcBlt.dwColorSpaceHighValue=RGB16BIT565(1,1,1);

	//create the surface
	if(FAILED(lpdd->CreateSurface(&ddsd,&lpdds,NULL)))
		{
		MessageBox(hwnd,"Could not create offscreen surface",
				   TITLE,MB_OK);
		return(NULL);
		}

	//return the surface
	return(lpdds);
	}

//------------------------------------------------------------------//
//- IDirectDrawSurface7* DDLoadBitmap(LPCSTR,int,int) --------------//
//------------------------------------------------------------------//
//- You will ber using this one a TON.  This loads a premade       -//
//- DirectDraw surface, and loads a bitmap of your liking onto it. -//
//- *ONLY* use this function once you have initiated DirectDraw.   -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             LPDIRECTDRAWSURFACE7 ship=NULL;                    -//
//-             ship=DD_Load_Bitmap("ship.bmp", 128, 128);         -//
//------------------------------------------------------------------//
LPDIRECTDRAWSURFACE7 DD_Load_Bitmap(LPCSTR bitmap, 
									int dx, int dy)
	{
    HBITMAP                 hbm;
    BITMAP                  bm;
    DDSURFACEDESC2          ddsd;
    LPDIRECTDRAWSURFACE7    lpdds;

    //  Try to load the bitmap as a resource, if that fails, try it as a file
    hbm = (HBITMAP) LoadImage(GetModuleHandle(NULL), bitmap, IMAGE_BITMAP, dx,
                              dy, LR_CREATEDIBSECTION);
    if(hbm==NULL)
        hbm = (HBITMAP) LoadImage(NULL, bitmap, IMAGE_BITMAP, dx, dy,
                                  LR_LOADFROMFILE | LR_CREATEDIBSECTION);
    if(hbm==NULL)
        return NULL;
 
    // Get size of the bitmap
    GetObject(hbm, sizeof(bm), &bm);

    // Create a DirectDrawSurface for this bitmap
    ZeroMemory(&ddsd, sizeof(ddsd));
    ddsd.dwSize			= sizeof(ddsd);
    ddsd.dwFlags		= DDSD_CAPS   | DDSD_WIDTH |
						  DDSD_HEIGHT | DDSD_CKSRCBLT;
    ddsd.ddsCaps.dwCaps = DDSCAPS_OFFSCREENPLAIN | DDSCAPS_VIDEOMEMORY;
    ddsd.dwWidth        = bm.bmWidth;
    ddsd.dwHeight		= bm.bmHeight;

	ddsd.ddckCKSrcBlt.dwColorSpaceLowValue =RGB16BIT565(0,0,0);
	ddsd.ddckCKSrcBlt.dwColorSpaceHighValue=RGB16BIT565(0,0,0);

    if(FAILED(lpdd->CreateSurface(&ddsd, &lpdds, NULL)))
		{
		MessageBox(hwnd, "Could not create offscreen surface", 
				   TITLE, MB_OK);
        return NULL;
		}

    DD_Copy_Bitmap(lpdds, hbm, 0, 0, 0, 0);

    DeleteObject(hbm);
    return lpdds;
	}

//------------------------------------------------------------------//
//- HRESULT DDCopyBitmap(IDirectDrawSurface7*,HBITMAP,int,int,int,int) -//
//------------------------------------------------------------------//
//- Don't even worry about this one, you don't need it.            -//
//------------------------------------------------------------------//
HRESULT DD_Copy_Bitmap(LPDIRECTDRAWSURFACE7 lpdds, 
					 HBITMAP hbm, int x, int y,
					 int dx, int dy)
	{
    HDC                     hdcImage;
    HDC                     hdc;
    BITMAP                  bm;
    DDSURFACEDESC2          ddsd;
    HRESULT                 hr;

    if (hbm == NULL || lpdds == NULL)
        return E_FAIL;

    // Make sure this surface is restored.
    lpdds->Restore();

    // Select bitmap into a memoryDC so we can use it.
    hdcImage = CreateCompatibleDC(NULL);
    if(!hdcImage)
        MessageBox(hwnd, "Could not create compatible DC",
				   TITLE, MB_OK);
    SelectObject(hdcImage, hbm);

    // Get size of the bitmap
    GetObject(hbm, sizeof(bm), &bm);
    dx = dx == 0 ? bm.bmWidth : dx;     // Use the passed size, unless zero
    dy = dy == 0 ? bm.bmHeight : dy;

    // Get size of surface.
    ddsd.dwSize = sizeof(ddsd);
    ddsd.dwFlags = DDSD_HEIGHT | DDSD_WIDTH;
    lpdds->GetSurfaceDesc(&ddsd);

    if((hr = lpdds->GetDC(&hdc)) == DD_OK)
		{
        StretchBlt(hdc, 0, 0, ddsd.dwWidth, ddsd.dwHeight, hdcImage, x, y,
                   dx, dy, SRCCOPY);
        lpdds->ReleaseDC(hdc);
		}
    DeleteDC(hdcImage);
    return hr;
	}

//------------------------------------------------------------------//
//- HRESULT DD_Reload_Bitmap(LPDIRECTDRAWSURFACE7,LPCSTR) ----------//
//------------------------------------------------------------------//
//- Yet again, don't even worry about this one, you don't need it. -//
//- But if you don't have a Mountain Dew, you will need one of     -//
//- those.  And if you don't have some good music going, then you  -//
//- will need some of that going too.  Everyone codes to music...  -//
//- Right?                                                         -//
//------------------------------------------------------------------//
HRESULT DD_Reload_Bitmap(LPDIRECTDRAWSURFACE7 lpdds, 
					     LPCSTR bitmap)
	{
    HBITMAP                 hbm;
    HRESULT                 hr;

    //  Try to load the bitmap as a resource, if that fails, try it as a file
    hbm = (HBITMAP) LoadImage(GetModuleHandle(NULL), 
							  bitmap, IMAGE_BITMAP, 
							  0,0, 
							  LR_CREATEDIBSECTION);
    if(hbm == NULL)
        hbm = (HBITMAP) LoadImage(NULL, 
								  bitmap, IMAGE_BITMAP, 
								  0, 0,
                                  LR_LOADFROMFILE | LR_CREATEDIBSECTION);
    if(hbm == NULL)
		{
        MessageBox(hwnd, "Bitmap handle is NULL", TITLE, MB_OK);
        return E_FAIL;
		}

    hr=DD_Copy_Bitmap(lpdds, hbm, 0, 0, 0, 0);

    if(hr != DD_OK)
        MessageBox(hwnd,"Could not copy bitmap", TITLE, MB_OK);

    DeleteObject(hbm);
    return hr;
	}

//------------------------------------------------------------------//
//- void Particle_Init(void) ---------------------------------------//
//------------------------------------------------------------------//
//- This one initiates my kewl little particle engine. The engine  -//
//- would have been a helluva lot cooler had it been done in D3D or-//
//- OpenGL.  But, since this is DirectDraw, and there is no        -//
//- blending support (and no matter how I wrote it, it was still   -//
//- slooooooow), this is the best I could get.                     -//
//- Anyway, just put this at the initiation function of your game  -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-                Particle_Init();                                -//
//------------------------------------------------------------------//
void Particle_Init(void)
	{
	int loop;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		particle[loop].x        =0;
		particle[loop].y        =0;
		particle[loop].xvelocity=0.0;
		particle[loop].yvelocity=0.0;
		particle[loop].state    =PARTICLE_STATE_DEAD;
		particle[loop].life     =0;
		particle[loop].maxlife  =0;
		particle[loop].color    =RGB16BIT565(0,0,0);
		}
	}

//------------------------------------------------------------------//
//- void Particle_Shutdown(void) -----------------------------------//
//------------------------------------------------------------------//
//- This shuts down my particle engine, just put it at the shutdown-//
//- part of your game.                                             -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-                Particle_Shutdown();                            -//
//------------------------------------------------------------------//
void Particle_Shutdown(void)
	{
	int loop;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		particle[loop].x        =0;
		particle[loop].y        =0;
		particle[loop].xvelocity=0.0;
		particle[loop].yvelocity=0.0;
		particle[loop].state    =PARTICLE_STATE_DEAD;
		particle[loop].life     =0;
		particle[loop].maxlife  =0;
		particle[loop].color    =RGB16BIT565(0,0,0);
		}
	}

//------------------------------------------------------------------//
//- void Particle_Create(int,int,float,float,int,int) --------------//
//------------------------------------------------------------------//
//- This function creates a particle at the position that you      -//
//- specify, with the velocities that you specify, the color that  -//
//- you specify (use a pre-defined color, look in the header), and -//
//- the max life that you would like your particle to have.        -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             for(int loop=0; loop<MAX_PARTICLES; loop++)        -//
//-                 {                                              -//
//-                 Particle_Create(rand()%SCREEN_WIDTH,           -//
//-                                 rand()%SCREEN_HEIGHT,          -//
//-                                 rand()%10,                     -//
//-                                 rand()%10,                     -//
//-                                 PARTICLE_COLOR_ORANGE,         -//
//-                                 50 /*that is made random*/);   -//
//------------------------------------------------------------------//
void Particle_Create(int x, int y, 
					 float xvelocity, float yvelocity,
					 int color, int maxlife)
	{
	int loop;
	int choice=-1;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		if(particle[loop].state==PARTICLE_STATE_DEAD)
			{
			choice=loop;
			break;
			}
		}

	if(choice==-1)
		return;

	particle[choice].state    =PARTICLE_STATE_ALIVE;
	particle[choice].x		  =x;
	particle[choice].y		  =y;
	particle[choice].xvelocity=xvelocity;
	particle[choice].yvelocity=yvelocity;
	particle[choice].life     =0;
	particle[choice].maxlife  =maxlife+rand()%5;
	
	switch(color)
		{
		case PARTICLE_COLOR_WHITE:
			particle[choice].color=RGB16BIT565(250,250,250);
			break;

		case PARTICLE_COLOR_GRAY:
			particle[choice].color=RGB16BIT565(128,128,128);
			break;

		case PARTICLE_COLOR_BLACK:
			particle[choice].color=RGB16BIT565(0,0,0);
			break;

		case PARTICLE_COLOR_RED:
			particle[choice].color=RGB16BIT565(250,0,0);
			break;

		case PARTICLE_COLOR_GREEN:
			particle[choice].color=RGB16BIT565(0,250,0);
			break;

		case PARTICLE_COLOR_BLUE:
			particle[choice].color=RGB16BIT565(0,0,250);
			break;

		case PARTICLE_COLOR_ORANGE:
			particle[choice].color=RGB16BIT565(250,128,0);
			break;

		case PARTICLE_COLOR_PURPLE:
			particle[choice].color=RGB16BIT565(250,0,250);
			break;

		case PARTICLE_COLOR_YELLOW:
			particle[choice].color=RGB16BIT565(250,250,0);
			break;
		}		
	}

//------------------------------------------------------------------//
//- inline void Particle_Wind_Init(float) --------------------------//
//------------------------------------------------------------------//
//- This function is a quick one, that just sets the wind to be    -//
//- used in the particle engine.  Does not need to be set if not   -//
//- needed, as the global is already initialized to 0.0			   -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Particle_Wind_Init(0.7);                           -//
//------------------------------------------------------------------//
inline void Particle_Wind_Init(float wind)
	{ wind=wind; }

//------------------------------------------------------------------//
//- inline void Particle_Gravity_Init(float) -----------------------//
//------------------------------------------------------------------//
//- This function is a quick one, that just sets the gravity to be -//
//- used in the particle engine.  Does not need to be set if not   -//
//- needed, as the global is already initialized to 0.0            -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Particle_Gravity_Init(0.7);                        -//
//------------------------------------------------------------------//
inline void Particle_Gravity_Init(float gravity)
	{ gravity=gravity; }

//------------------------------------------------------------------//
//- void Particle_Fast_Process(void) -------------------------------//
//------------------------------------------------------------------//
//- This is the simple particle process function, that simply      -//
//- moves all the particles, and checks to see if their dead or not-//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-				Particle_Fast_Process();                           -//
//------------------------------------------------------------------//
void Particle_Fast_Process(void)
	{
	int loop;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		if(particle[loop].state==PARTICLE_STATE_ALIVE)
			{
			particle[loop].x+=particle[loop].xvelocity;
			particle[loop].y+=particle[loop].yvelocity;

			particle[loop].xvelocity+=wind;
			particle[loop].yvelocity+=gravity;

			particle[loop].life++;

			if(particle[loop].x<0 || particle[loop].x>SCREEN_WIDTH ||
			   particle[loop].y<0 || particle[loop].y>SCREEN_HEIGHT)
				particle[loop].state=PARTICLE_STATE_DEAD;

			if(particle[loop].life>particle[loop].maxlife)
				particle[loop].state=PARTICLE_STATE_DEAD;
			}
		}
	}

//------------------------------------------------------------------//
//- void Particle_Full_Process(void) -------------------------------//
//------------------------------------------------------------------//
//- This is the full out particle process function, that takes a   -//
//- lot more processor cycles, but takes into account if a         -//
//- particle hits another particle or not. Cool stuff              -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-				Particle_Full_Process();                           -//
//------------------------------------------------------------------//
void Particle_Full_Process(void)
	{
	int loop;
	int loop2;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		x[loop]=particle[loop].x;		//first fill the look-up tables
		y[loop]=particle[loop].y;		//with every particle's x, & y
		}

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		if(particle[loop].state==PARTICLE_STATE_ALIVE)
			{
			particle[loop].x+=particle[loop].xvelocity;
			particle[loop].y+=particle[loop].yvelocity;

			particle[loop].xvelocity+=wind;
			particle[loop].yvelocity+=gravity;

			for(loop2=0; loop2<MAX_PARTICLES; loop2++)
				{
				//this is where the particle gets tested against other
				//particles.  As of now, if a particle hits another
				//it just turns around.
				if(particle[loop].x==x[loop2] &&
				   particle[loop].y==y[loop2])
					{
					particle[loop].xvelocity*=-1;
					particle[loop].yvelocity*=-1;
					}
				}

			particle[loop].life++;

			if(particle[loop].life>particle[loop].maxlife)
				particle[loop].state=PARTICLE_STATE_DEAD;
			}
		}
	}

//------------------------------------------------------------------//
//- void Particle_Draw_Pixel(void) ---------------------------------//
//------------------------------------------------------------------//
//- LOCK THE BACK BUFFER BEFORE YOU DO THIS! I could've just locked-//
//- it in the function, but it would take some useless speed up, if-//
//- you had more pixels to plot.  So, just put a call to this in a -//
//- locked area, and then UNLOCK THE BACK BUFFER when your done.   -//
//- You do not need to put this in a for loop, it automatically    -//
//- draws all the particles in existence.                          -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Lock_Back_Buffer();                                -//
//-             Particle_Draw_Pixel();                             -//
//-             Unlock_Back_Buffer();                              -//
//------------------------------------------------------------------//
void Particle_Draw_Pixel(void)
	{
	int loop;

	if(!back_buffer)
		return;
	if(!back_lpitch)
		return;

	for(loop=0; loop<MAX_PARTICLES; loop++)
		{
		if(particle[loop].state==PARTICLE_STATE_ALIVE)
			Back_Plot_Pixel(particle[loop].x, particle[loop].y, particle[loop].color);
		}
	}

//------------------------------------------------------------------//
//- void Particle_Explosion(int,int,int,int,int,int,int) -----------//
//------------------------------------------------------------------//
//- This creates an explosion of particles wherever you want.      -//
//- I would put more detail into this, but I just spent the last 2 -//
//- hours commenting the hell out of this engine, and I ran out of -//
//- Mountain Dew this morning.  SO LEAVE ME ALONE!                 -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Particle_Explosion(400,300,                        -//
//-								   rand()%4, rand()%4,             -//
//-                                PARTICLE_COLOR_RED, 50, 100);   -//
//------------------------------------------------------------------//
void Particle_Explosion(int x, int y, 
						float xvelocity, float yvelocity, 
						int color, int maxlife, int numberofparticles)
	{
	if(numberofparticles>MAX_PARTICLES)
		numberofparticles=MAX_PARTICLES;

	while(--numberofparticles>=0)
		{
		int angle=rand()%360;

		float velocity= (2+rand()%4);

		Particle_Create(x+Random(-4,4), y+(-4,4),
						xvelocity+COS[angle]*velocity, yvelocity+SIN[angle]*velocity,
						color, maxlife);
		}
	}


//------------------------------------------------------------------//
//- void DI_Init(void)											   -//
//------------------------------------------------------------------//
//- Description: Initializes the main DirectInput object.  This    -//
//-              function MUST be called if you are going to want  -//
//-              to use DirectInput.                               -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Init();										   -//
//------------------------------------------------------------------//
void DI_Init(void)
	{
	HRESULT hr;

	hr=(DirectInputCreateEx(hinstance, DIRECTINPUT_VERSION, 
						    IID_IDirectInput7, (void**)&lpdi, NULL)); 
	if(FAILED(hr)) 
		{ 
		SKERROR("LPDIRECTINPUT7 Error: Could not create the main object");

		DI_Shutdown();
		}

	}

//------------------------------------------------------------------//
//- void DI_Shutdown(void)										   -//
//------------------------------------------------------------------//
//- Description: Shutsdown everything to do with DirectInput. MUST -//
//-              be called if you have used DI_Init();             -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Shutdown();									   -//
//------------------------------------------------------------------//
void DI_Shutdown(void)
	{
	HRESULT hr;

	if(lpdi)
		{
		hr=(lpdi->Release());

		if(FAILED(hr))
			SKERROR("LPDIRECTINPUT7 Error: Could not release main object");
		}
	}

//------------------------------------------------------------------//
//- void DI_Keyboard_Init(void)									   -//
//------------------------------------------------------------------//
//- Description: This function initializes DirectInput to use the  -//
//-              keyboard.                                         -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Keyboard_Init();								   -//
//------------------------------------------------------------------//
void DI_Keyboard_Init(void)
	{
	HRESULT hr;
	

	//Create the keyboard device
	hr=(lpdi->CreateDeviceEx(GUID_SysKeyboard, IID_IDirectInputDevice7,
							 (void**)&lpdikeyboard, NULL)); 
	if(FAILED(hr)) 
		{ 
		ERROR("LPDIRECTINPUTDEVICE7 Error: Could not create the keyboard");
		DI_Shutdown();  
		}


	//Set the keyboard data format
	hr=(lpdikeyboard->SetDataFormat(&c_dfDIKeyboard)); 
 
	if(FAILED(hr))
		{ 
		ERROR("LPDIRECTINPUTDEVICE7 Error: Could not set the keyboard data format.");
		DI_Shutdown();  
		}


	//Set the keyboard cooperation level 
	hr=(lpdikeyboard->SetCooperativeLevel(hwnd, 
										  DISCL_FOREGROUND | 
										  DISCL_NONEXCLUSIVE)); 
 
	if(FAILED(hr))
		{ 
		ERROR("LPDIRECTINPUTDEVICE7 Error: Could not set keyboard cooperation level");
		DI_Shutdown();  
		}


	if(lpdikeyboard) 
		hr=(lpdikeyboard->Acquire());

	if(FAILED(hr))
		{
		ERROR("LPDIRECTINPUTDEVICE7 Error: Could not aquire the keyboard");
		DI_Shutdown();
		}
	}

//------------------------------------------------------------------//
//- void DI_Keyboard_Shutdown(void)								   -//
//------------------------------------------------------------------//
//- Description: This function shutsdown the DirectInput keyboard  -//
//-              keyboard object.	                               -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Keyboard_Init();								   -//
//------------------------------------------------------------------//
void DI_Keyboard_Shutdown(void)	
	{
	HRESULT hr;

	if(lpdikeyboard)
		{
		hr=(lpdikeyboard->Unacquire());

		if(FAILED(hr))
			SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not unacquire the keyboard");


		hr=(lpdikeyboard->Release());

		if(FAILED(hr))
			SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not release the keyboard");
		}
	}


//------------------------------------------------------------------//
//- void DI_Keyboard_Process(void)								   -//
//------------------------------------------------------------------//
//- Description: This function processes the keyboard, by polling  -//
//-              it to make sure that it is still working fine.    -//
//-              A call to this function should be put at the start-//
//-              of your main game loop, so it will get executed   -//
//-              everytime.										   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Keyboard_Process();							   -//
//------------------------------------------------------------------//
void DI_Keyboard_Process(void)
	{
	if(FAILED(lpdikeyboard->GetDeviceState(sizeof(UCHAR[256]),
										  (LPVOID)keybuffer)))
		SKERROR("LPDIRECTINPUTDEVICE7 Error: Keyboard lost");
	}

//------------------------------------------------------------------//
//- void DI_Mouse_Init(void)									   -//
//------------------------------------------------------------------//
//- Description: This function initializes DirectInput to use the  -//
//-              mouse.											   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Mouse_Init();								   -//
//------------------------------------------------------------------//
void DI_Mouse_Init(void)
	{
	HRESULT hr;

	hr=lpdi->CreateDeviceEx(GUID_SysMouse, IID_IDirectInputDevice7,
						   (void**)&lpdimouse, NULL);
 
	if(FAILED(hr)) 
		{
		SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not create the mouse object.");
		DI_Shutdown();
		}


	hr=lpdimouse->SetDataFormat(&c_dfDIMouse);
 
	if(FAILED(hr)) 
		{
		SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not set the mouse data format");
		DI_Shutdown();
		}


	hr=lpdimouse->SetCooperativeLevel(hwnd,
									  DISCL_EXCLUSIVE | 
									  DISCL_FOREGROUND);
 
	if(FAILED(hr)) 
		{
		SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not set the mouse data format");
		DI_Shutdown();
		}
	}

//------------------------------------------------------------------//
//- void DI_Mouse_Shutdown(void)								   -//
//------------------------------------------------------------------//
//- Description: This function shuts down the DirectInput mouse    -//
//-              object.										   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DI_Mouse_Shutdown();							   -//
//------------------------------------------------------------------//
void DI_Mouse_Shutdown(void)
	{
	HRESULT hr;

	if(lpdimouse)
		{
		hr=(lpdimouse->Unacquire());

		if(FAILED(hr))
			SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not unacquire the mouse");


		hr=(lpdimouse->Release());

		if(FAILED(hr))
			SKERROR("LPDIRECTINPUTDEVICE7 Error: Could not release the mouse");
		}
	}


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- Just a quick side note before I start the code to the          -//
//- DirectSound wrapper functions.  A lot of these functions are   -//
//- straight from Andr� LaMothe's DirectSound wrapper.  Here are   -//
//- the reasons why:											   -//
//-					 - I hate dealing with sound.                  -//
//-                  - I wanted the code to be all in one file     -//
//-                  - Change the code to my style                 -//
//-                  - Make some slight changes to the code        -//
//-                  - Make some slight changes to the functions   -//
//-                  - Not have to include all the DirectMusic stuff-//
//- All in all, thank you Andr�.  :)                               -//
//------------------------------------------------------------------//
//------------------------------------------------------------------//


//------------------------------------------------------------------//
//- void DS_Init(void)											   -//
//------------------------------------------------------------------//
//- Description: Ok, first and foremost, this was the absolute most-//
//-              boring piece of code that I have ever had to code.-//
//-              I HATE DEALING WITH SOUND.  It just isn't my "bag"-//
//-              baby.  So, if some of this looks a little familiar-//
//-              it probably is (*cough* "Thanks LaMothe" *cough*).-//
//-              Anyway, all you have to do is put a call to this  -//
//-              function in the initiation part of your game.     -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Init();	   									   -//
//------------------------------------------------------------------//
void DS_Init(void)
	{
	HRESULT hr;
	int loop;

	memset(sound,0,sizeof(SOUND)*MAX_SOUNDS);

	hr=(DirectSoundCreate(NULL,&lpds,NULL));

	if(FAILED(hr))
		{
		SKERROR("LPDIRECTSOUND Error: Could not create main object");
		DS_Shutdown();
		}


	hr=(lpds->SetCooperativeLevel(hwnd,DSSCL_NORMAL));

	if(FAILED(hr))
		{
		SKERROR("LPDIRECTSOUND Error: Could not set cooperation level");
		DS_Shutdown();
		}


	// initialize the sound array
	for(loop=0; loop<MAX_SOUNDS; loop++)
		{
		// test if this sound has been loaded
		if(sound[loop].dsbuffer)
			{
			// stop the sound
			sound[loop].dsbuffer->Stop();

			// release the buffer
			sound[loop].dsbuffer->Release();
			}

		memset(&sound[loop],0,sizeof(SOUND));

		sound[loop].state = SOUND_NULL;
		sound[loop].number= loop;

		} 

	}

//------------------------------------------------------------------//
//- void DS_Shutdown(void)										   -//
//------------------------------------------------------------------//
//- Description: My sister could figure this function out.  Just   -//
//-              put a call to this in the shutdown part of your   -//
//-              game.											   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Shutdown();									   -//
//------------------------------------------------------------------//
void DS_Shutdown(void)
	{
	HRESULT hr;
	int loop;

	for(loop=0; loop<MAX_SOUNDS; loop++)
		{
		sound[loop].dsbuffer->Release();
		sound[loop].number=0;
		sound[loop].rate=0;
		sound[loop].size=0;
		sound[loop].state=SOUND_NULL;
		}

	if(lpds)
		{
		hr=(lpds->Release());

		if(FAILED(hr))
			SKERROR("LPDIRECTSOUND Error: Could not release main object");
		}
	}

//------------------------------------------------------------------//
//- int DS_Load_WAV(char*, int)									   -//
//------------------------------------------------------------------//
//- Description: Ok, LaMothe, I owe you huge on this one.  This    -//
//-              function looked like it would be a bi*** to code. -//
//-              But, thats why I am not at your level yet. ;)     -//
//-              Just load a SOUND object (of an array) with one of-//
//-              these.  Not too hard. ;)                          -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             int id=DS_Load_WAV("Sounds/sound.wav", SOUND_PLAY_ONCE);-//
//-             sound[id].lpdsbuffer->Play(0,0,DSBPLAY_LOOPING);   -//
//------------------------------------------------------------------//
int DS_Load_WAV(char *filename, int control_flags)
	{
	int	sound_id = -1;       //The ID of the sound to be loaded	
	int loop;

	UCHAR* snd_buffer,       //Temporary sound buffer to hold voc data
		 * audio_ptr_1=NULL, //Pointer to first write buffer 
		 * audio_ptr_2=NULL; //Pointer to second write buffer

	DWORD audio_length_1=0,  //Length of first write buffer
		  audio_length_2=0;  //Length of second write buffer
				
	//Are there any open IDs?
	for(loop=0; loop<MAX_SOUNDS; loop++)
		{	
		//Check the sound, see if it is in use
		if(sound[loop].state==SOUND_NULL)
		   {
		   sound_id=loop;

		   break;
		   } 
		}

	//Check to see if there were any free IDs
	if(sound_id==-1)
		return(-1);

	//Set up chunk info structure
	parent.ckid 	    =(FOURCC)0;
	parent.cksize 	    =0;
	parent.fccType	    =(FOURCC)0;
	parent.dwDataOffset =0;
	parent.dwFlags		=0;

	//Copy the data
	child=parent;

	//Open the .wav file
	if((hwav=mmioOpen(filename, 
					  NULL, 
					  MMIO_READ | MMIO_ALLOCBUF)) ==NULL)
		return(-1);

	//Descend into the RIFF
	parent.fccType= mmioFOURCC('W', 'A', 'V', 'E');

	if(mmioDescend(hwav, &parent, NULL, MMIO_FINDRIFF))
		{
		//Close the file
		mmioClose(hwav, 0);

		return(-1);			//No wave section 	
		} 

	//Descend to the WAVEformat
	child.ckid=mmioFOURCC('f', 'm', 't', ' ');

	if(mmioDescend(hwav, &child, &parent, 0))
		{
		// close the file
		mmioClose(hwav, 0);

		return(-1); 		//No format section
		} 

	//Read the .wav information from the file
	if(mmioRead(hwav, (char *)&wfmtx, 
				sizeof(wfmtx)) != sizeof(wfmtx))
		{
		// close file
		mmioClose(hwav, 0);

		return(-1);			//No wave format data
		}

	//Make sure that the data format is PCM
	if(wfmtx.wFormatTag != WAVE_FORMAT_PCM)
		{
		// close the file
		mmioClose(hwav, 0);

		return(-1);			//Not the right data format
		} 

	//Ascend up one level, so there is access to the data chunk
	if(mmioAscend(hwav, &child, 0))
	   {
	   // close file
	   mmioClose(hwav, 0);

	   return(-1); 			//Could not ascend (broken leg? ;) )
	   }

	//Descend back down to the data chunk
	child.ckid= mmioFOURCC('d', 'a', 't', 'a');

	if(mmioDescend(hwav, &child, &parent, MMIO_FINDCHUNK))
		{
		// close file
		mmioClose(hwav, 0);

		return(-1); 		//No data
		}

	//Now its finally time to load the data in, and set up the DSound
	//buffer...  
	//Allocate the memory to load sound data
	snd_buffer= (UCHAR*)malloc(child.cksize);

	//Read the .wav data 
	mmioRead(hwav, (char*)snd_buffer, child.cksize);

	//Close the file
	mmioClose(hwav, 0);

	//Set the rate and size in data structure
	sound[sound_id].rate =wfmtx.nSamplesPerSec;
	sound[sound_id].size =child.cksize;
	sound[sound_id].state=SOUND_LOADED;

	//Set up the format data structure
	memset(&pcmwf, 0, sizeof(WAVEFORMATEX));

	pcmwf.wFormatTag	  = WAVE_FORMAT_PCM;  //Pulse code modulation
	pcmwf.nChannels		  = 1;                //Mono sound (not stereo :( )
	pcmwf.nSamplesPerSec  = 11025;            //11khz rate
	pcmwf.nBlockAlign	  = 1;                
	pcmwf.nAvgBytesPerSec = pcmwf.nSamplesPerSec * pcmwf.nBlockAlign;
	pcmwf.wBitsPerSample  = 8;
	pcmwf.cbSize		  = 0;

	//Prepare to create sounds buffer
	dsbd.dwSize			= sizeof(DSBUFFERDESC);
	dsbd.dwFlags		= control_flags | DSBCAPS_STATIC | DSBCAPS_LOCSOFTWARE;
	dsbd.dwBufferBytes	= child.cksize;
	dsbd.lpwfxFormat	= &pcmwf;

	//Create the sound buffer
	if(FAILED(lpds->CreateSoundBuffer(&dsbd,&sound[sound_id].dsbuffer,NULL)))
	   {
	   // release memory
	   free(snd_buffer);

	   SKERROR("LPDIRECTSOUND Error: Could not create the sound buffer");
	   return(-1);		//Could not create the Sound buffer
	   }

	//Copy data into sound buffer
	if(FAILED(sound[sound_id].dsbuffer->Lock(0,					 
										    child.cksize,			
										    (void **) &audio_ptr_1, 
										    &audio_length_1,
										    (void **)&audio_ptr_2, 
										    &audio_length_2,
										    DSBLOCK_FROMWRITECURSOR)))
		{
		SKERROR("LPDIRECTSOUND Error: Could not copy data into buffer");
		return(0);
		}

	//Copy first section of circular buffer
	memcpy(audio_ptr_1, snd_buffer, audio_length_1);

	//Copy last section of circular buffer
	memcpy(audio_ptr_2, (snd_buffer+audio_length_1),audio_length_2);

	//Unlock the buffer
	if(FAILED(sound[sound_id].dsbuffer->Unlock(audio_ptr_1, 
											audio_length_1, 
											audio_ptr_2, 
											audio_length_2)))
		{
		SKERROR("LPDIRECTSOUND Error: Could not unlock the buffer");
 		return(0);
		}

	//Release the temp buffer
	free(snd_buffer);

	return(sound_id);
	}

//------------------------------------------------------------------//
//- BOOL DS_Play_Sound(int,int)									   -//
//------------------------------------------------------------------//
//- Description: This is a nice little function.  You don't need to-//
//-              enter all the arguements if you don't want to, it -//
//-              would be ok to only use the id arg if you'd like. -//
//-              This function (as you can tell) plays a sound that-//
//-              has already been loaded.						   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//- int explosion=DS_Load_WAV("Sounds/explosion.wav",SOUND_PLAY_ONCE); -//
//-             DS_Play_Sound(explosion,SOUND_PLAY_ONCE);          -//
//------------------------------------------------------------------//
BOOL DS_Play_Sound(int id, int flags)
	{
	if(sound[id].dsbuffer)
		{
		//Reset the sound's position to START
		if(FAILED(sound[id].dsbuffer->SetCurrentPosition(0)))
			return FALSE;
		
		//Play that funky music white boy.
		if(FAILED(sound[id].dsbuffer->Play(0,0,flags)))
			return FALSE;
		}

	// return success
	return(1);
	}

//------------------------------------------------------------------//
//- BOOL DS_Set_Volume(int,int)									   -//
//------------------------------------------------------------------//
//- Description: This function changes a sound's volume (based on a-//
//-              scale from 0-100, with 100 being the loudest).    -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Set_Volume(explosion,77);                       -//
//------------------------------------------------------------------//
BOOL DS_Set_Volume(int id,int vol)
	{
	if(sound[id].dsbuffer->SetVolume(VOLUME_TO_DB(vol))!=DS_OK)
		return FALSE;

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL DS_Set_Frequency(int,int)								   -//
//------------------------------------------------------------------//
//- Description: This function changes a sounds frequency (speed,  -//
//-				 and pitch).  So if you had a 11025khz sound, and  -//
//-              set the frequency to 44000khz, you would have a   -//
//-              sound remaniscent of a pig squeal.                -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Set_Frequency(explosion,22050);                 -//
//------------------------------------------------------------------//
BOOL DS_Set_Frequency(int id,int freq)
	{
	if(sound[id].dsbuffer->SetFrequency(freq)!=DS_OK)
		return FALSE;

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL DS_Set_Pan(int,int)									   -//
//------------------------------------------------------------------//
//- Description: This function changes a sound's panning rate.  So -//
//-              sound at -10000 would be all in the left speaker, -//
//-              and a sound at 10000 would be all in the right    -//
//-              speaker.  A sound a 0 would be centered.          -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Set_Pan(explosion,0);		                   -//
//------------------------------------------------------------------//
BOOL DS_Set_Pan(int id,int pan)
	{
	if(sound[id].dsbuffer->SetPan(pan)!=DS_OK)
		return FALSE;

	return TRUE;
	} 

//------------------------------------------------------------------//
//- BOOL DS_Stop_Sound(int)										   -//
//------------------------------------------------------------------//
//- Description: This function stops a sound from playing... Almost-//
//-				 done with this damn sound wrapper, its starting to-//
//-              really get on my nerves.  I love music and all,   -//
//-              but when I program, I want to do games, not listen-//
//-              to music.  Thats what Winamp is for (and it hasn't-//
//-              stopped playing songs since I got my computer).   -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Stop_Sound(explosion);		                   -//
//------------------------------------------------------------------//
BOOL DS_Stop_Sound(int id)
	{
	if(sound[id].dsbuffer)
	   {
	   sound[id].dsbuffer->Stop();
	   sound[id].dsbuffer->SetCurrentPosition(0);
	   } 

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL DS_Stop_All_Sounds(void)								   -//
//------------------------------------------------------------------//
//- Description: This function stops all sounds that are playing.  -//
//-              Duh.                                              -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Stop_All_Sounds();                              -//
//------------------------------------------------------------------//
BOOL DS_Stop_All_Sounds(void)
	{
	int loop;
		
	for(loop=0; loop<MAX_SOUNDS; loop++)
		DS_Stop_Sound(loop);	

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL DS_Delete_Sound(int)									   -//
//------------------------------------------------------------------//
//- Description: This deletes a currently loaded wav, and puts it  -//
//-              back on the rack, and ready for shopping.         -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Delete_Sound(explosion);                        -//
//------------------------------------------------------------------//
BOOL DS_Delete_Sound(int id)
	{
	//First stop it
	if(!DS_Stop_Sound(id))
	   return FALSE;

	//Now delete it
	if(sound[id].dsbuffer)
	   {
	   //Releases the secondary buffer
	   sound[id].dsbuffer->Release();
	   sound[id].dsbuffer=NULL;

	   return TRUE;
	   }

	return TRUE;
	}

//------------------------------------------------------------------//
//- BOOL DS_Delete_All_Sounds(void)								   -//
//------------------------------------------------------------------//
//- Description: This deletes all sounds.  No matter what.         -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             DS_Delete_All_Sounds();							   -//
//------------------------------------------------------------------//
BOOL DS_Delete_All_Sounds(void)
	{
	int loop;

	for(loop=0; loop<MAX_SOUNDS; loop++)
		DS_Delete_Sound(loop);

	return TRUE;
	} 

//------------------------------------------------------------------//
//- BOOL CD_Circle_Circle(BOUNDCIRCLE_PTR, BOUNDCIRCLE_PTR)		   -//
//------------------------------------------------------------------//
//- Description: This function tests to see if there is a collision-//
//-              between two circles.  It returns TRUE if there was-//
//-              a collision, and false if not.  Send a pointer to -//
//-              your circle objects as the arguements.            -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             BOUNDCIRCLE circ1;                                 -//
//-             BOUNDCIRCLE circ2;                                 -//
//-																   -//
//-             if(CD_Circle_Circle(&circ1, &circ2))			   -//
//-                  {                                             -//
//-					 //collision                                   -//
//-					 }											   -//
//------------------------------------------------------------------//
BOOL CD_Circle_Circle(BOUNDCIRCLE_PTR circ1, BOUNDCIRCLE_PTR circ2)
	{
	int distance;
	distance= Fast_Distance((circ1->x)-(circ2->x),
							(circ1->y)-(circ2->y));

	if(distance<= ((circ1->radius)+(circ2->radius)))
		return TRUE;

	return FALSE;
	}

//------------------------------------------------------------------//
//- BOOL CD_Rect_Rect(BOUNDRECT_PTR,BOUNDRECT_PTR)				   -//
//------------------------------------------------------------------//
//- Description: This function tests to see if there is a collision-//
//-              between two rectangles.  It returns TRUE if there -//
//-              was a collision, and false if not.  Send a pointer-//
//-              to your circle objects as the arguements.         -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             BOUNDRECT rect1;	                               -//
//-             BOUNDRECT rect2;	                               -//
//-																   -//
//-             if(CD_Rect_Rect(&rect1, &rect2))				   -//
//-                  {                                             -//
//-					 //collision                                   -//
//-					 }											   -//
//------------------------------------------------------------------//
BOOL CD_Rect_Rect(BOUNDRECT_PTR rect1, BOUNDRECT_PTR rect2)
	{
	if((rect1->x1)>(rect2->x1) &&
	   (rect1->y1)<(rect2->y1) &&
	   (rect1->x1)<(rect2->x2) &&
	   (rect1->y1)>(rect2->y2))
		return TRUE;

	if((rect1->x2)>(rect2->x1) &&
	   (rect1->y2)<(rect2->y1) &&
	   (rect1->x2)<(rect2->x2) &&
	   (rect1->y2)>(rect2->y2))
		return TRUE;

	if((rect2->x1)>(rect1->x1) &&
	   (rect2->y1)<(rect1->y1) &&
	   (rect2->x1)<(rect1->x2) &&
	   (rect2->y1)>(rect1->y2))
		return TRUE;

	if((rect2->x2)>(rect1->x1) &&
	   (rect2->y2)<(rect1->y1) &&
	   (rect2->x2)<(rect1->x2) &&
	   (rect2->y2)>(rect1->y2))
		return TRUE;

	return FALSE;
	}

//------------------------------------------------------------------//
//- BOOL CD_Circle_Rect(BOUNDCIRCLE_PTR,BOUNDRECT_PTR)			   -//
//------------------------------------------------------------------//
//- Description: This function tests to see if there is a collision-//
//-              between a circle and a rectangle.  If there is a  -//
//-              collision, the function returns TRUE, if else,    -//
//-              then it returns FALSE.  Awwww man, there I go     -//
//-              talking in code again.  <BG>                      -//
//------------------------------------------------------------------//
//- Sample use:													   -//
//-             BOUNDCIRCLE rect;	                               -//
//-             BOUNDRECT rect;				                       -//
//-																   -//
//-             if(CD_Circle_Rect(&circ, &rect))				   -//
//-                  {                                             -//
//-					 //collision                                   -//
//-					 }											   -//
//------------------------------------------------------------------//
BOOL CD_Circle_Rect(BOUNDCIRCLE_PTR circ, BOUNDRECT_PTR rect)
	{
	//first the blatantly obvious... 
	if((circ->x)>(rect->x1) &&
	   (circ->x)<(rect->x2) &&
	   (circ->y)>(rect->y1) &&
	   (circ->y)<(rect->y2))
		return TRUE;

	if((circ->x+circ->radius)>(rect->x1) &&
	   (circ->x+circ->radius)<(rect->x2) &&
	   (circ->y)>(rect->y1) &&
	   (circ->y)<(rect->y2))
		return TRUE;

	if((circ->x-circ->radius)>(rect->x1) &&
	   (circ->x-circ->radius)<(rect->x2) &&
	   (circ->y)>(rect->y1) &&
	   (circ->y)<(rect->y2))
		return TRUE;

	if((circ->x+circ->radius)>(rect->x1) &&
	   (circ->x+circ->radius)<(rect->x2) &&
	   (circ->y+circ->radius)>(rect->y1) &&
	   (circ->y+circ->radius)<(rect->y2))
		return TRUE;

	if((circ->x+circ->radius)>(rect->x1) &&
	   (circ->x+circ->radius)<(rect->x2) &&
	   (circ->y-circ->radius)>(rect->y1) &&
	   (circ->y-circ->radius)<(rect->y2))
		return TRUE;

	if((circ->x-circ->radius)>(rect->x1) &&
	   (circ->x-circ->radius)<(rect->x2) &&
	   (circ->y+circ->radius)>(rect->y1) &&
	   (circ->y+circ->radius)<(rect->y2))
		return TRUE;

	if((circ->x-circ->radius)>(rect->x1) &&
	   (circ->x-circ->radius)<(rect->x2) &&
	   (circ->y-circ->radius)>(rect->y1) &&
	   (circ->y-circ->radius)<(rect->y2))
		return TRUE;

	if((circ->x)>(rect->x1) &&
	   (circ->x)<(rect->x2) &&
	   (circ->y+circ->radius)>(rect->y1) &&
	   (circ->y+circ->radius)<(rect->y2))
		return TRUE;

	if((circ->x)>(rect->x1) &&
	   (circ->x)<(rect->x2) &&
	   (circ->y-circ->radius)>(rect->y1) &&
	   (circ->y-circ->radius)<(rect->y2))
		return TRUE;


	return FALSE;
	}

//------------------------------------------------------------------//
//- BOOL GDI_Text(LPDIRECTDRAWSURFACE7,char*,int,int,int,int,int) --//
//------------------------------------------------------------------//
//- This one puts some text at a location that you specify. I think-//
//- its pretty self-explanatory, isn't it?  And if it isn't, then  -//
//- just look at some of my code/game samples.  I use text in every-//
//- one.                                                           -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             GDI_Text(lpddsback, "Hello World",0,0,0,255,0);    -//
//------------------------------------------------------------------//
BOOL GDI_Text(LPDIRECTDRAWSURFACE7 lpdds,
			  char *text, 
			  int x,int y,
		      int r, int g, int b)
	{
	HDC gdc;			//GDI context object

	// get the dc from surface
	if(FAILED(lpdds->GetDC(&gdc)))
	   return FALSE;

	// set the colors for the text up
	SetTextColor(gdc,RGB(r,g,b));

	// set background mode to transparent so black isn't copied
	SetBkMode(gdc, TRANSPARENT);

	// draw the text
	TextOut(gdc,x,y,text,strlen(text));

	// release the dc
	lpdds->ReleaseDC(gdc);

	// return success
	return TRUE;
	} // end Draw_Text_GDI

//------------------------------------------------------------------//
//- DWORD Clock_Get(void) ------------------------------------------//
//- Thanks Andr� LaMothe! ------------------------------------------//
//------------------------------------------------------------------//
//- There is real no way to describe this one.  Just look at some  -//
//- of the code samples I have written... Those should be of ample -//
//- use.                                                           -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             clock_count=Clock_Get();                           -//
//------------------------------------------------------------------//
DWORD Clock_Get(void)
	{
	return(GetTickCount());		//get time since proggy started
	}

//------------------------------------------------------------------//
//- DWORD Clock_Start(void) ----------------------------------------//
//- Thanks Andr� LaMothe!   ----------------------------------------//
//------------------------------------------------------------------//
//- There is real no way to describe this one.  Just look at some  -//
//- of the code samples I have written... Those should be of ample -//
//- use.  Just put a call to this during the game init function.   -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             clock_count=Clock_Start();                         -//
//------------------------------------------------------------------//
DWORD Clock_Start(void)
	{
	return(clock_count=Clock_Get());	//set clock_count to the start time
	}

//------------------------------------------------------------------//
//- DWORD Clock_Wait(DWORD count) ----------------------------------//
//- Thanks Andr� LaMothe!         ----------------------------------//
//------------------------------------------------------------------//
//- This one holds your program to *approximanetly* the frames you -//
//- want per second.  The example below holds it to 30 fps.        -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Clock_Wait(30);                                    -//
//------------------------------------------------------------------//
DWORD Clock_Wait(DWORD count)
	{
	while((Clock_Get() - clock_count) < count);
	return(Clock_Get());
	}

//------------------------------------------------------------------//
//- void CosSin_Init(void) -----------------------------------------//
//------------------------------------------------------------------//
//- YOU WILL NOT USE THIS FUNCTION! I have already put a call to it-//
//- in the DD_Init(...) function. And it only needs to be done once-//
//------------------------------------------------------------------//
//- You will be using the look-up tables however.  All you have to -//
//- do is put either COS or SIN and then in brackets, the angle you-//
//- want to get the cosine or sine for. Not too hard               -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             COS[angle];                                        -//
//-             SIN[angle];										   -//
//------------------------------------------------------------------//
void CosSin_Init(void)
	{
	int loop;				//looping index, for the angle
	float radian;

	for(loop=0; loop<360; loop++)
		{
		//convert angle to radians
		radian=loop*(PI/180);

		//fill in the tables
		COS[loop]=cos(radian);
		SIN[loop]=sin(radian);
		}
	}

//------------------------------------------------------------------//
//- int Random(int,int) --------------------------------------------//
//------------------------------------------------------------------//
//- This one gets a random number between the range that you       -//
//- provide.  And then returns it.                                 -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             int rand_numb=Random(-100,100);                    -//
//------------------------------------------------------------------//
inline int Random(int min, int max)
	{ return (rand()%(max-min+1))+min; }

//------------------------------------------------------------------//
//- float Fast_Distance(int,int) -----------------------------------//
//------------------------------------------------------------------//
//- This function determines the distance that a point is from the -//
//- origin (0,0). Maximum error of 3.5%.  But heck, its faster than-//
//- using the sqrt(...) function!                                  -//
//------------------------------------------------------------------//
//- Sample use:                                                    -//
//-             Fast_Distance(5,100);                              -//
//------------------------------------------------------------------//
float Fast_Distance(int x, int y)
	{
	int min;

	x=abs(x);
	y=abs(y);

	//get the minimum of x,y
	min= MIN(x,y);

	return (x+y-(min>>1)-(min>>2)+(min>>4));
	}

//------------------------------------------------------------------//
/* Ok, I just spent the last two hours commenting this whole thing....
So how do I feel?  Pretty good. I have spent about 2 weeks tweaking 
this engine, so that it works perfectly under anything. I also added 
full support for errors and such. I still have to write a sound    
wrapper for DirectX, but I might just wait until I get DirectX8. So 
if you see me using Andr� LaMothe's sound library for a couple of   
project than you know why. :)  I plan to do this whole thing over 
again when I start doing some Direct3D/OpenGL stuff. 
And I also want to write a ton of articles, and demos using 
this engine. 

If there are any errors, any mis-comments, not enough comments, or you
would like a function added to this engine, just e-mail me at 
ShiningKnight7@hotmail.com.  I love hearing from other programmers
so feel free to mail me.  Well, I am off. Have fun, and of course:
HAPPY CODING!                                               
									--Trent (ShiningKnightDX)       */
//------------------------------------------------------------------//
