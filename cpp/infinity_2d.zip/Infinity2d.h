//------------------------------------------------------------------//
//- The Infinity 2D DirectDraw7 Game Engine header				   -//
//------------------------------------------------------------------//
//-							Created By							   -//
//-						   Trent Polack							   -//
//-              Founder, and Lead Programmer of				   -//
//-						 NovaStorm Games						   -//
//------------------------------------------------------------------//
#ifndef Infinity2d_H
#define Infinity2d_H

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- INCLUDES -------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <iostream.h> // include important C/C++ stuff
#include <conio.h>
#include <stdio.h> 
#include <stdarg.h>
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <string.h>
#include <math.h>
#include <io.h>
#include <fcntl.h>
#include <time.h>

#include <ddraw.h>
#include <dsound.h>
#include <dinput.h>


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- DEFINES --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
// defines for windows 
#define WINDOW_CLASS_NAME "WINCLASS1"
#define TITLE "Infinity2D Engine"

/* DirectDraw stuff */
#define SKBITMAP LPDIRECTDRAWSURFACE7


/* DirectInput stuff */
#define MOUSE_BUTTON_LEFT   0
#define MOUSE_BUTTON_RIGHT  1
#define MOUSE_BUTTON_MIDDLE 2

#define NUMEVENTS  2


/* DirectSound stuff */
#define MAX_SOUNDS     256 

#define SOUND_NULL     0 
#define SOUND_LOADED   1
#define SOUND_PLAYING  2
#define SOUND_STOPPED  3

#define SOUND_PLAY_ONCE 0
#define SOUND_PLAY_LOOP DSBPLAY_LOOPING

#define LEFT_SPEAKER  -10000
#define RIGHT_SPEAKER  10000
#define CENTER         0

//defines for particle engine
#define MAX_PARTICLES      1000

#define PARTICLE_STATE_DEAD  0
#define PARTICLE_STATE_ALIVE 1

#define PARTICLE_COLOR_WHITE     0				//color defines
#define PARTICLE_COLOR_GRAY      1                
#define PARTICLE_COLOR_BLACK     2
#define PARTICLE_COLOR_RED       3
#define PARTICLE_COLOR_GREEN     4
#define PARTICLE_COLOR_BLUE      5
#define PARTICLE_COLOR_ORANGE    6
#define PARTICLE_COLOR_PURPLE    7
#define PARTICLE_COLOR_YELLOW    8

//define for PI...  I thought I'd get pretty close to the real thing ;)
#define PI 3.1415926535897932384626433832785





//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- TYPES ----------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
typedef unsigned short USHORT;
typedef unsigned short WORD;
typedef unsigned char  UCHAR;
typedef unsigned char  BYTE;




//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- STRUCTURES -----------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
typedef struct PARTICLE_TYP
	{
	int state;
	int x, y;
	float xvelocity, yvelocity;
	USHORT color;
	int life, maxlife;
	} PARTICLE, *PARTICLE_PTR;


// this holds a single sound
typedef struct SOUND_TYP
	{
	LPDIRECTSOUNDBUFFER dsbuffer;   //The sound's DirectSound buffer
	int state;                      //The sound's state
	int rate;                       //The playback rate
	int size;                       //The size of the sound
	int number;                     //The sound's number
	} SOUND, *SOUND_PTR;


//This is the bounding circle structure (BEST USED FOR CIRCLES ;))
typedef struct BOUNDCIRCLE_TYP
	{
	int x;				//The point of the object's center
	int y;
	int radius;			//The object's radius
	} BOUNDCIRCLE, *BOUNDCIRCLE_PTR;

//This is the bounding rectangle structure (BEST us... ahhh hell, you know what it is)
typedef struct BOUNDRECT_TYP
	{
	int x1, y1;				//Upper left point
	int x2, y2;				//Lower right point
	} BOUNDRECT, *BOUNDRECT_PTR;


//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- GLOBALS --------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

/* DirectDraw stuff */
extern LPDIRECTDRAW7         lpdd;			        // directdraw7 object
extern LPDIRECTDRAWSURFACE7  lpddsprimary;			// directdraw7 primary surface
extern LPDIRECTDRAWSURFACE7  lpddsback;				// directdraw7 back surface (back buffer)
extern LPDIRECTDRAWCLIPPER   lpddclipper;			// DirectDraw clipper
extern DDSURFACEDESC2        ddsd;                  // directdraw surface description struct
extern DDBLTFX               ddbltfx;               // used to fill


/* DirectInput stuff */
extern LPDIRECTINPUT7		lpdi;			//The main DirectInput object
extern LPDIRECTINPUTDEVICE7 lpdikeyboard;	//The main DirectInput keyboard object
extern LPDIRECTINPUTDEVICE7 lpdimouse;      //The main DirectInput mouse object
extern UCHAR				keybuffer[256]; //The main keyboard buffer
extern DIMOUSESTATE2        mousestate;     //The main mouse state object


/* DirectSound stuff */
extern LPDIRECTSOUND	   lpds;		   //The DirectSound main object
extern DSBUFFERDESC		   dsbd;           //The DirectSound object description
extern DSCAPS			   dscaps;         //The DirectSound caps
extern DSBCAPS			   dsbcaps;        //The DirectSound buffer caps
extern LPDIRECTSOUNDBUFFER lpdsbprimary;   //The primary sound buffer
extern WAVEFORMATEX		   pcmwf;          //The waveformat structure
extern SOUND               sound[MAX_SOUNDS];
extern HMMIO 			   hwav;			//Handle to a .wav file
extern MMCKINFO		       parent;			//The parent chunk
extern MMCKINFO            child;			//The child chunk
extern WAVEFORMATEX        wfmtx;			//Wave format chunk


extern int SCREEN_WIDTH;			//used to hold screen's width
extern int SCREEN_HEIGHT;			//used to hold screen's height
extern int SCREEN_BPP;				//used to hold screen's bits per pixel

extern float COS[360];
extern float SIN[360];

extern HRESULT result;

extern HWND hwnd;					//main window handle
extern HINSTANCE hinstance;			// globally track hinstance
extern HDC hdc;

extern int primary_lpitch;			//pitch of the primary buffer
extern int back_lpitch;				//pitch of the back buffer
extern USHORT* primary_buffer;		//pointer to primary buffer
extern USHORT* back_buffer;			//pointer to back buffer

extern char buffer[80];                     // general printing buffer

extern DWORD clock_count;

extern float wind;
extern float gravity;
extern float x[MAX_PARTICLES];
extern float y[MAX_PARTICLES];





//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- MACROS ---------------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//
#define SKERROR(message) MessageBox(hwnd, message, TITLE, MB_OK) 

// this builds a 16 bit color value in 5.5.5 format (1-bit alpha mode) (Thank you Andr� LaMothe)
#define RGB16BIT555(r,g,b) ((b%32) + ((g%32) << 5) + ((r%32) << 10))

// this builds a 16 bit color value in 5.6.5 format (green dominate mode) (Thank you Andr� LaMothe)
#define RGB16BIT565(r,g,b) ((b%32) + ((g%64) << 6) + ((r%32) << 11))

// initializes a direct draw struct (Thank you Andr� LaMothe!)
#define DDRAW_INIT_STRUCT(ddstruct) { memset(&ddstruct,0,sizeof(ddstruct)); ddstruct.dwSize=sizeof(ddstruct); }

#define MIN(a, b)  (((a) < (b)) ? (a) : (b))	//thanks Andr�!
#define MAX(a, b)  (((a) > (b)) ? (b) : (a)) 

#define KEY_DOWN(key) (keybuffer[key] & 0x80) 

#define MOUSE_DOWN(button) (mousestate.rgbButtons[button] & 0x80)

#define VOLUME_TO_DB(volume) ((DWORD)(-30*(100-volume)))

//------------------------------------------------------------------//
//------------------------------------------------------------------//
//- DECLARATIONS ---------------------------------------------------//
//------------------------------------------------------------------//
//------------------------------------------------------------------//

/* DirectDraw functions */
extern HRESULT DD_Init(int screenwidth, int screenheight, int screenbpp);
extern void DD_Shutdown(void);
extern BOOL DD_Attach_Clipper(LPDIRECTDRAWSURFACE7 lpdds);
extern inline void Primary_Plot_Pixel(int x, int y,USHORT color);
extern inline void Back_Plot_Pixel(int x, int y,USHORT color);
extern void Memory_Fill(LPDIRECTDRAWSURFACE7 surface, int x1, int y1, int x2, int y2, int r, int g, int b);
extern void Surface_Fill(LPDIRECTDRAWSURFACE7 surface, int r, int g, int b);
extern USHORT* Lock_Back_Buffer(void);
extern USHORT* Lock_Primary_Buffer(void);
extern BOOL Unlock_Back_Buffer(void);
extern BOOL Unlock_Primary_Buffer(void);
extern BOOL Flip(void);
extern LPDIRECTDRAWSURFACE7 DD_Create_Surface(int width, int height, int flags);
extern IDirectDrawSurface7* DD_Load_Bitmap(LPCSTR bitmap, int dx, int dy);
extern HRESULT DD_Copy_Bitmap(IDirectDrawSurface7* lpdds,HBITMAP hbm, int x, int y,int dx, int dy);
extern HRESULT DD_Reload_Bitmap(LPDIRECTDRAWSURFACE7 lpdds,LPCSTR bitmap);


/* Particle engine functions */
extern void Particle_Init(void);
extern void Particle_Shutdown(void);
extern void Particle_Create(int x,int y,float xvelocity,float yvelocity,int color, int maxlife);
extern inline void Particle_Wind_Init(float wind);
extern inline void Particle_Gravity_Init(float gravity);
extern void Particle_Fast_Process(void);
extern void Particle_Full_Process(void);
extern void Particle_Draw_Pixel(void);
extern void Particle_Explosion(int x, int y, float xvelocity, float yvelocity, int color, int maxlife, int numberofparticles);


/* DirectInput functions */
extern void DI_Init(void);
extern void DI_Shutdown(void);
extern void DI_Keyboard_Init(void);
extern void DI_Keyboard_Shutdown(void);
extern void DI_Keyboard_Process(void);
extern void DI_Mouse_Init(void);
extern void DI_Mouse_Shutdown(void);


/* DirectSound functions */
extern void DS_Init(void);
extern void DS_Shutdown(void);
extern int  DS_Load_WAV(char *filename, int control_flags);
extern BOOL DS_Play_Sound(int id, int flags);
extern BOOL DS_Set_Volume(int id,int vol);
extern BOOL DS_Set_Frequency(int id,int freq);
extern BOOL DS_Set_Pan(int id,int pan);
extern BOOL DS_Stop_Sound(int id);
extern BOOL DS_Stop_All_Sounds(void);
extern BOOL DS_Delete_Sound(int id);
extern BOOL DS_Delete_All_Sounds(void);


/* Collision Detection */
extern BOOL CD_Circle_Circle(BOUNDCIRCLE_PTR circ1, BOUNDCIRCLE_PTR circ2);	
extern BOOL CD_Rect_Rect(BOUNDRECT_PTR rect1, BOUNDRECT_PTR rect2);
extern BOOL CD_Circle_Rect(BOUNDCIRCLE_PTR circ, BOUNDRECT_PTR rect);


/* Miscellaneous functions */
extern BOOL GDI_Text(LPDIRECTDRAWSURFACE7 lpdds,char *text, int x,int y,int r, int g, int b);

extern DWORD Clock_Get(void);
extern DWORD Clock_Start(void);
extern DWORD Clock_Wait(DWORD count);

extern void CosSin_Init(void);
extern inline int Random(int min, int max);

extern float Fast_Distance(int x, int y);

#endif	//Infinity2d_H
//------------------------------------------------------------------//