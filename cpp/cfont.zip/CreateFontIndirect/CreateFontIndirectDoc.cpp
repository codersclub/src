// CreateFontIndirectDoc.cpp : implementation of the CCreateFontIndirectDoc class
//

#include "stdafx.h"
#include "CreateFontIndirect.h"

#include "CreateFontIndirectDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectDoc

IMPLEMENT_DYNCREATE(CCreateFontIndirectDoc, CDocument)

BEGIN_MESSAGE_MAP(CCreateFontIndirectDoc, CDocument)
	//{{AFX_MSG_MAP(CCreateFontIndirectDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectDoc construction/destruction

CCreateFontIndirectDoc::CCreateFontIndirectDoc()
{
	// TODO: add one-time construction code here

}

CCreateFontIndirectDoc::~CCreateFontIndirectDoc()
{
}

BOOL CCreateFontIndirectDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectDoc serialization

void CCreateFontIndirectDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectDoc diagnostics

#ifdef _DEBUG
void CCreateFontIndirectDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CCreateFontIndirectDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectDoc commands
