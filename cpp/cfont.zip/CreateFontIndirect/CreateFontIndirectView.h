// CreateFontIndirectView.h : interface of the CCreateFontIndirectView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CREATEFONTINDIRECTVIEW_H__788C9CD3_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
#define AFX_CREATEFONTINDIRECTVIEW_H__788C9CD3_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

class CCreateFontIndirectView : public CView
{
protected: // create from serialization only
	CCreateFontIndirectView();
	DECLARE_DYNCREATE(CCreateFontIndirectView)

// Attributes
public:
	CCreateFontIndirectDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateFontIndirectView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCreateFontIndirectView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCreateFontIndirectView)
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in CreateFontIndirectView.cpp
inline CCreateFontIndirectDoc* CCreateFontIndirectView::GetDocument()
   { return (CCreateFontIndirectDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEFONTINDIRECTVIEW_H__788C9CD3_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
