// CreateFontIndirectView.cpp : implementation of the CCreateFontIndirectView class
//

#include "stdafx.h"
#include "CreateFontIndirect.h"

#include "CreateFontIndirectDoc.h"
#include "CreateFontIndirectView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectView

IMPLEMENT_DYNCREATE(CCreateFontIndirectView, CView)

BEGIN_MESSAGE_MAP(CCreateFontIndirectView, CView)
	//{{AFX_MSG_MAP(CCreateFontIndirectView)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectView construction/destruction

CCreateFontIndirectView::CCreateFontIndirectView()
{
	// TODO: add construction code here

}

CCreateFontIndirectView::~CCreateFontIndirectView()
{
}

BOOL CCreateFontIndirectView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectView drawing

void CCreateFontIndirectView::OnDraw(CDC* pDC)
{
	CCreateFontIndirectDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);

	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectView diagnostics

#ifdef _DEBUG
void CCreateFontIndirectView::AssertValid() const
{
	CView::AssertValid();
}

void CCreateFontIndirectView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CCreateFontIndirectDoc* CCreateFontIndirectView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CCreateFontIndirectDoc)));
	return (CCreateFontIndirectDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectView message handlers

void CCreateFontIndirectView::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	CRect rect;
	GetClientRect ( &rect ) ;
	CFont font;
	int angle=450;
	LOGFONT lf =  { 32, 0, angle, angle, FW_BOLD, 0, 0, 0, 
		RUSSIAN_CHARSET, OUT_TT_ONLY_PRECIS, CLIP_DEFAULT_PRECIS,
		PROOF_QUALITY, VARIABLE_PITCH | FF_ROMAN, NULL } ;
	font.CreateFontIndirect( &lf ) ;
	CFont * pFont = dc.SelectObject( &font) ;

	CString str("Hello world");
	
	rect.OffsetRect( 0, rect.Height()/3 );
    dc.DrawText( str, rect, DT_NOCLIP ) ;

	rect.OffsetRect( rect.Width()/3, rect.Height()/3 );
	dc.SetBkMode( TRANSPARENT );
	dc.DrawText( str, rect, DT_NOCLIP ) ;
	
	dc.SelectObject ( pFont ) ;
	font.DeleteObject ( ) ;

	// Do not call CView::OnPaint() for painting messages
}
