// CreateFontIndirect.h : main header file for the CREATEFONTINDIRECT application
//

#if !defined(AFX_CREATEFONTINDIRECT_H__788C9CCB_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
#define AFX_CREATEFONTINDIRECT_H__788C9CCB_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CCreateFontIndirectApp:
// See CreateFontIndirect.cpp for the implementation of this class
//

class CCreateFontIndirectApp : public CWinApp
{
public:
	CCreateFontIndirectApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateFontIndirectApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCreateFontIndirectApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEFONTINDIRECT_H__788C9CCB_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
