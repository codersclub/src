// CreateFontIndirectDoc.h : interface of the CCreateFontIndirectDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CREATEFONTINDIRECTDOC_H__788C9CD1_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
#define AFX_CREATEFONTINDIRECTDOC_H__788C9CD1_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000


class CCreateFontIndirectDoc : public CDocument
{
protected: // create from serialization only
	CCreateFontIndirectDoc();
	DECLARE_DYNCREATE(CCreateFontIndirectDoc)

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCreateFontIndirectDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCreateFontIndirectDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CCreateFontIndirectDoc)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CREATEFONTINDIRECTDOC_H__788C9CD1_5FFE_11D4_BE7F_D74AB662F241__INCLUDED_)
