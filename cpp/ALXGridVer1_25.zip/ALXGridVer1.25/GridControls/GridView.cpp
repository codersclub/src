// GridView.cpp : implementation of the CGridView class
//

#include "stdafx.h"
#include "Grid.h"

#include "GridDoc.h"
#include "GridView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridView

IMPLEMENT_DYNCREATE(CGridView, CALXGridView)

BEGIN_MESSAGE_MAP(CGridView, CALXGridView)
	//{{AFX_MSG_MAP(CGridView)
	ON_COMMAND(WM_CLOSE, OnClose)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CALXGridView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CALXGridView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CALXGridView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGridView construction/destruction

CGridView::CGridView()
{
	// Text
	DefineColCtrl(AddCol(80,"LeftText", ACFF_LEFT, AHFF_LEFT),GA_EDITCTRL,WS_CHILD | ES_LEFT | ES_AUTOHSCROLL);
	DefineColCtrl(AddCol(80,"CenterText", ACFF_CENTER, AHFF_CENTER),GA_EDITCTRL,WS_CHILD | ES_CENTER | ES_AUTOHSCROLL);
	DefineColCtrl(AddCol(80,"RightText", ACFF_RIGHT, AHFF_RIGHT),GA_EDITCTRL,WS_CHILD | ES_RIGHT | ES_AUTOHSCROLL);
	// ImageList
	int nCol = AddCol(80,"Bitmap && Text", ACFF_LEFT, AHFF_LEFT);
	DefineColCtrl(nCol,GA_EDITCTRL,WS_CHILD | ES_LEFT | ES_AUTOHSCROLL);
	DefineImage(nCol,7,7,DIT_IMGLIST);
	// CheckBox
	DefineColCtrl(AddCol(90,"CheckBox3State", ACFF_CENTER, AHFF_CENTER, DFC_BUTTON, DFCS_BUTTON3STATE | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTO3STATE | BS_FLAT);
	DefineColCtrl(AddCol(60,"CheckBox", ACFF_CENTER, AHFF_CENTER,DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTOCHECKBOX | BS_FLAT);

	DefineColCtrl(AddCol(130,"CheckBox3State && Text", ACFF_LEFT, AHFF_LEFT, DFC_BUTTON,DFCS_BUTTON3STATE | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTO3STATE | BS_FLAT);
	DefineColCtrl(AddCol(90,"CheckBox && Text", ACFF_LEFT, AHFF_LEFT,DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTOCHECKBOX | BS_FLAT);
	// ComboBox
	DefineColCtrl(AddCol(150,"Hide DropDownComboBox", ACFF_LEFT, AHFF_LEFT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWN | WS_VSCROLL);
	DefineColCtrl(AddCol(150,"DropDownComboBox", ACFF_LEFT, AHFF_LEFT, DFC_SCROLL, DFCS_SCROLLCOMBOBOX | DFCS_FLAT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWN | WS_VSCROLL);

	DefineColCtrl(AddCol(130,"Hide ListComboBox", ACFF_LEFT, AHFF_LEFT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL);
	DefineColCtrl(AddCol(130,"ListComboBox", ACFF_LEFT, ACFF_LEFT, DFC_SCROLL, DFCS_SCROLLCOMBOBOX),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL);

	SetGridRowCount(0);
	VERIFY(m_ImageList.Create(IDB_BITMAP_IMGLIST, 7, 1, (COLORREF)0x808000));
}

CGridView::~CGridView()
{
}

BOOL CGridView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CALXGridView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGridView drawing

void CGridView::OnDraw(CDC* pDC)
{
	CGridDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGridView printing

BOOL CGridView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGridView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add extra initialization before printing
}

void CGridView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

CELL_DATA CGridView::GetCellData(int nCol, int nRow)
{
	CELL_DATA CellData = CALXGrid::GetCellData(nCol,nRow);
	CGridDoc* pDoc = GetDocument();
	
	switch(nCol)
	{
		case 0: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_LeftText;
				break;
			}
		case 1: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CenterText;
				break;
			}
		case 2: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_RightText;
				break;
			}
		case 3: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_BitmapText;
				break;
			}
		case 4:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox3State;
				break;
			}
		case 5:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox;
				break;
			}
		case 6:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CheckBox3StateText.m_Text;
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox3StateText.m_State;
				break;
			}
		case 7:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CheckBoxText.m_Text;
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBoxText.m_State;
				break;
			}
		case 8:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_HideDropDownComboBox;
				break;
			}
		case 9:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_DropDownComboBox;
				break;
			}
		case 10:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_HideListComboBox;
				CellData.m_strText.Format("%u",pDoc->m_Rows[nRow].m_HideListComboBox);
				break;
			}
		case 11:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_ListComboBox;
				CellData.m_strText.Format("%u-�",pDoc->m_Rows[nRow].m_ListComboBox);
				break;
			}
	}
	return CellData;
}

/////////////////////////////////////////////////////////////////////////////
// CGridView diagnostics

#ifdef _DEBUG
void CGridView::AssertValid() const
{
	CALXGridView::AssertValid();
}

void CGridView::Dump(CDumpContext& dc) const
{
	CALXGridView::Dump(dc);
}

CGridDoc* CGridView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGridDoc)));
	return (CGridDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGridView message handlers

void CGridView::GetImageListDrawParams(int nCol, int nRow, IMAGELISTDRAWPARAMS* pimldp, BOOL bSelected)
{
	pimldp->himl = m_ImageList.m_hImageList;
	if(bSelected)
		pimldp->fStyle = ILD_SELECTED;
	pimldp->i = 0;
}

CALXCellCtrl* CGridView::CreateCellCtrl(int nCol, int nRow, DWORD dwStyle, UINT nID)
{
	CALXCellCtrl* pCellCtrl = CALXGrid::CreateCellCtrl(nCol, nRow, dwStyle);
	if(pCellCtrl != NULL)
	{
		switch(nCol)
		{
		case 8:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("���");
				pComboBoxCtrl->AddString("���");
				pComboBoxCtrl->AddString("���");
				break;
			}
		case 9:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("������");
				pComboBoxCtrl->AddString("������");
				pComboBoxCtrl->AddString("������");
				break;
			}
		case 10:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("1");
				pComboBoxCtrl->SetItemData(0,1);
				pComboBoxCtrl->AddString("2");
				pComboBoxCtrl->SetItemData(1,2);
				pComboBoxCtrl->AddString("3");
				pComboBoxCtrl->SetItemData(2,3);
				break;
			}
		case 11:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("1-�");
				pComboBoxCtrl->SetItemData(0,1);
				pComboBoxCtrl->AddString("2-�");
				pComboBoxCtrl->SetItemData(1,2);
				pComboBoxCtrl->AddString("3-�");
				pComboBoxCtrl->SetItemData(2,3);
				break;
			}
		}
	}
	return pCellCtrl;
}

void CGridView::OnInitialUpdate() 
{
	CALXGridView::OnInitialUpdate();
	
	SetGridRowCount(GetDocument()->m_Rows.GetSize());
	UpdateScrollSizes();
	CGridView::SetFocus();

}

BOOL CGridView::OnSaveCellData(int nCol, int nRow)
{
	CGridDoc* pDoc = GetDocument();
	CALXCellCtrl* pCellCtrl = GetCellCtrl(nCol,nRow);
	if(pCellCtrl != NULL)
	{
		CELL_DATA Data = pCellCtrl->GetCellData();
		switch(nCol)
		{
			case 0: 
				{
					pDoc->m_Rows[nRow].m_LeftText = Data.m_strText;
					break;
				}
			case 1: 
				{
					pDoc->m_Rows[nRow].m_CenterText = Data.m_strText;
					break;
				}
			case 2: 
				{
					pDoc->m_Rows[nRow].m_RightText = Data.m_strText;
					break;
				}
			case 3: 
				{
					pDoc->m_Rows[nRow].m_BitmapText = Data.m_strText;
					break;
				}
			case 4:
				{
					pDoc->m_Rows[nRow].m_CheckBox3State = (STATE)Data.m_dwTag;
					break;
				}
			case 5:
				{
					pDoc->m_Rows[nRow].m_CheckBox = (STATE)Data.m_dwTag;
					break;
				}
			case 6:
				{
					pDoc->m_Rows[nRow].m_CheckBox3StateText.m_State = (STATE)Data.m_dwTag;
					break;
				}
			case 7:
				{
					pDoc->m_Rows[nRow].m_CheckBoxText.m_State = (STATE)Data.m_dwTag;
					break;
				}
			case 8:
				{
					if(Data.m_dwTag == ULONG_MAX)
					{
						CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) GetCellCtrl(nCol, nRow);
						pComboBoxCtrl->AddString(Data.m_strText);
					}
					pDoc->m_Rows[nRow].m_HideDropDownComboBox = Data.m_strText;
					break;
				}
			case 9:
				{
					if(Data.m_dwTag == ULONG_MAX)
					{
						CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) GetCellCtrl(nCol, nRow);
						pComboBoxCtrl->AddString(Data.m_strText);
					}
					pDoc->m_Rows[nRow].m_DropDownComboBox = Data.m_strText;
					break;
				}
			case 10:
				{
					pDoc->m_Rows[nRow].m_HideListComboBox = (ORDER)Data.m_dwTag;
					break;
				}
			case 11:
				{
					pDoc->m_Rows[nRow].m_ListComboBox = (ORDER)Data.m_dwTag;
					break;
				}
		}
	}
	return TRUE;
}



void CGridView::OnClose() 
{
	CALXCellCtrl* pCellCtrl = GetCellCtrl(GetActiveCol(),GetActiveRow());
	if(pCellCtrl != NULL)
	{
		if(pCellCtrl->IsModifyed())
			pCellCtrl->SetModify(FALSE);
	}
}
