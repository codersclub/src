; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CGridView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "Grid.h"
LastPage=0

ClassCount=6
Class1=CGridApp
Class2=CGridDoc
Class3=CGridView
Class4=CMainFrame
Class6=CAboutDlg

ResourceCount=10
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource8=IDD_ABOUTBOX (English (U.S.))
Resource9=IDR_MAINFRAME (English (U.S.))
Class5=CPaymentSet
Resource10=IDD_DLG_COLUMNS (English (U.S.))

[CLS:CGridApp]
Type=0
HeaderFile=Grid.h
ImplementationFile=Grid.cpp
Filter=N
BaseClass=CWinApp
VirtualFilter=AC

[CLS:CGridDoc]
Type=0
HeaderFile=GridDoc.h
ImplementationFile=GridDoc.cpp
Filter=N
BaseClass=CDocument
VirtualFilter=DC

[CLS:CGridView]
Type=0
HeaderFile=GridView.h
ImplementationFile=GridView.cpp
Filter=C
BaseClass=CALXGridView
VirtualFilter=VWC
LastObject=ID_VIEW_COLUMNS


[CLS:CPaymentSet]
Type=0
HeaderFile=PaymentSet.h
ImplementationFile=PaymentSet.cpp
Filter=N

[DB:CPaymentSet]
DB=1
DBType=DAO
ColumnCount=5
Column1=[DATE], 11, 8
Column2=[NAME], 12, 50
Column3=[PAYMENT_CHANGED], -5, 8
Column4=[IS_PAID], -5, 8
Column5=[FOR_PAYMENT], -5, 8


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T




[CLS:CAboutDlg]
Type=0
HeaderFile=Grid.cpp
ImplementationFile=Grid.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command3=ID_FILE_SAVE
Command4=ID_FILE_SAVE_AS
Command5=ID_FILE_PRINT
Command6=ID_FILE_PRINT_PREVIEW
Command7=ID_FILE_PRINT_SETUP
Command8=ID_FILE_MRU_FILE1
Command9=ID_APP_EXIT
Command10=ID_EDIT_UNDO
Command11=ID_EDIT_CUT
Command12=ID_EDIT_COPY
Command13=ID_EDIT_PASTE
Command14=ID_RECORD_FIRST
Command15=ID_RECORD_PREV
CommandCount=20
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command16=ID_RECORD_NEXT
Command17=ID_RECORD_LAST
Command18=ID_VIEW_TOOLBAR
Command19=ID_VIEW_STATUS_BAR
Command20=ID_APP_ABOUT

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
CommandCount=14
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE


[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_OPEN
Command2=ID_EDIT_CUT
Command3=ID_EDIT_COPY
Command4=ID_EDIT_PASTE
Command5=ID_FILE_PRINT
Command6=ID_APP_ABOUT
CommandCount=6

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_OPEN
Command2=ID_FILE_PRINT
Command3=ID_FILE_PRINT_PREVIEW
Command4=ID_FILE_PRINT_SETUP
Command5=ID_APP_EXIT
Command6=ID_EDIT_UNDO
Command7=ID_EDIT_CUT
Command8=ID_EDIT_COPY
Command9=ID_EDIT_PASTE
Command10=ID_VIEW_TOOLBAR
Command11=ID_VIEW_STATUS_BAR
Command12=ID_VIEW_COLUMNS
Command13=ID_APP_ABOUT
CommandCount=13

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308993
Control3=IDC_STATIC,static,1342308353
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,button,1342177287

[DLG:IDD_DLG_COLUMNS (English (U.S.))]
Type=1
Class=?
ControlCount=13
Control1=IDC_STATIC,static,1342308352
Control2=IDC_STATIC_FRAME,static,1208094720
Control3=IDC_BTN_UP,button,1342242816
Control4=IDC_BTN_DOWN,button,1342242816
Control5=IDC_BTN_SHOW,button,1342242816
Control6=IDC_BTN_HIDE,button,1342242816
Control7=IDC_BTN_SETDEF,button,1342242816
Control8=IDC_STATIC,static,1342308352
Control9=IDC_EDIT_WIDTH,edit,1350639746
Control10=IDC_STATIC,static,1342308352
Control11=IDC_STATIC,static,1342177296
Control12=IDOK,button,1342242817
Control13=IDCANCEL,button,1342242816

