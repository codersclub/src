; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAlignPropPage
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "alxgridwiz.h"
LastPage=0

ClassCount=11
Class1=CClassesDlg
Class2=CGeneralPropPage
Class3=CAlignPropPage
Class4=CCtrlPropPage
Class5=CColPropSheet
Class6=CGridDlg
Class7=CGridHeadDlg
Class8=CGridPrevCtrl
Class9=CHeadPropCtrl
Class10=CPrevDlg
Class11=CTypeCtrl

ResourceCount=8
Resource1=IDD_PROPPAGE_GENERAL (English (U.S.))
Resource2=IDD_PROPPAGE_ALIGN (English (U.S.))
Resource3=IDD_PROPPAGE_CONTROL (English (U.S.))
Resource4=IDD_CLASSES (English (U.S.))
Resource5=IDD_GRIDHEAD (English (U.S.))
Resource6=IDD_GRIDSTYLE (English (U.S.))
Resource7=IDD_GRIDPREV (English (U.S.))
Resource8=IDR_GRIDHEAD (English (U.S.))

[CLS:CClassesDlg]
Type=0
BaseClass=CAppWizStepDlg
HeaderFile=ClassesDlg.h
ImplementationFile=ClassesDlg.cpp

[CLS:CGeneralPropPage]
Type=0
BaseClass=CPropertyPage
HeaderFile=ColPropPages.h
ImplementationFile=ColPropPages.cpp

[CLS:CAlignPropPage]
Type=0
BaseClass=CPropertyPage
HeaderFile=ColPropPages.h
ImplementationFile=ColPropPages.cpp
LastObject=CAlignPropPage

[CLS:CCtrlPropPage]
Type=0
BaseClass=CPropertyPage
HeaderFile=ColPropPages.h
ImplementationFile=ColPropPages.cpp

[CLS:CColPropSheet]
Type=0
BaseClass=CPropertySheet
HeaderFile=ColPropSheet.h
ImplementationFile=ColPropSheet.cpp

[CLS:CGridDlg]
Type=0
BaseClass=CAppWizStepDlg
HeaderFile=GridDlg.h
ImplementationFile=GridDlg.cpp

[CLS:CGridHeadDlg]
Type=0
BaseClass=CAppWizStepDlg
HeaderFile=GridHeadDlg.h
ImplementationFile=GridHeadDlg.cpp

[CLS:CGridPrevCtrl]
Type=0
BaseClass=CALXGridCtrl
HeaderFile=GridPrevCtrl.h
ImplementationFile=GridPrevCtrl.cpp

[CLS:CHeadPropCtrl]
Type=0
BaseClass=CALXGridCtrl
HeaderFile=HeadPropCtrl.h
ImplementationFile=HeadPropCtrl.cpp

[CLS:CPrevDlg]
Type=0
BaseClass=CDialog
HeaderFile=PrevDlg.h
ImplementationFile=PrevDlg.cpp

[CLS:CTypeCtrl]
Type=0
BaseClass=CALXComboBoxCtrl
HeaderFile=TypeCtrl.h
ImplementationFile=TypeCtrl.cpp

[DLG:IDD_CLASSES]
Type=1
Class=CClassesDlg

[DLG:IDD_PROPPAGE_GENERAL]
Type=1
Class=CGeneralPropPage

[DLG:IDD_PROPPAGE_ALIGN]
Type=1
Class=CAlignPropPage

[DLG:IDD_PROPPAGE_CONTROL]
Type=1
Class=CCtrlPropPage

[DLG:IDD_GRIDSTYLE]
Type=1
Class=CGridDlg

[DLG:IDD_GRIDHEAD]
Type=1
Class=CGridHeadDlg

[DLG:IDD_GRIDPREV]
Type=1
Class=CPrevDlg

[DLG:IDD_CLASSES (English (U.S.))]
Type=1
Class=?
ControlCount=10
Control1=IDC_STATIC,static,1342308352
Control2=CG_IDC_CLASS_LIST,listbox,1352728833
Control3=IDC_STATIC,static,1342308352
Control4=CG_IDC_CLASS_NAME,edit,1350631552
Control5=IDC_HEADERFILE,static,1342308352
Control6=CG_IDC_HFILE,edit,1350631552
Control7=IDC_BASECLASS,static,1342308352
Control8=CG_IDC_BASE_CLASS,edit,1484849280
Control9=IDC_IMPLFILE,static,1342308352
Control10=CG_IDC_IFILE,edit,1350631552

[DLG:IDD_GRIDHEAD (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC_FRAME,static,1342312448

[DLG:IDD_GRIDSTYLE (English (U.S.))]
Type=1
Class=?
ControlCount=6
Control1=IDC_STATIC,static,1342308352
Control2=IDC_EDITPATH,edit,1350631552
Control3=IDC_BTNBROWSE,button,1342242816
Control4=IDC_CHCKFLAT,button,1342242819
Control5=IDC_CHCKROWSEL,button,1342242819
Control6=IDC_STATIC,static,1342308352

[DLG:IDD_GRIDPREV (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDC_STATIC_FRAME,static,1342312448
Control2=IDOK,button,1342242817
Control3=IDCANCEL,button,1342242816

[DLG:IDD_PROPPAGE_GENERAL (English (U.S.))]
Type=1
Class=?
ControlCount=7
Control1=IDC_STATIC,static,1342308864
Control2=IDC_EDIT_TITLE,edit,1350631552
Control3=IDC_STATIC,static,1342308864
Control4=IDC_EDIT_WIDTH,edit,1350631553
Control5=IDC_STATIC,static,1342308864
Control6=IDC_EDIT_ID,edit,1350631552
Control7=IDC_STATIC,button,1342177287

[DLG:IDD_PROPPAGE_ALIGN (English (U.S.))]
Type=1
Class=?
ControlCount=8
Control1=IDC_STATIC,button,1342177287
Control2=IDC_RADIO_HALIGN1,button,1342308361
Control3=IDC_RADIO_HALIGN2,button,1342177289
Control4=IDC_RADIO_HALIGN3,button,1342177289
Control5=IDC_STATIC,button,1342177287
Control6=IDC_RADIO_CALIGN1,button,1342308361
Control7=IDC_RADIO_CALIGN2,button,1342177289
Control8=IDC_RADIO_CALIGN3,button,1342177289

[DLG:IDD_PROPPAGE_CONTROL (English (U.S.))]
Type=1
Class=?
ControlCount=15
Control1=IDC_STATIC,button,1342177287
Control2=IDC_STATIC,button,1342177287
Control3=IDC_STATIC,button,1342177287
Control4=IDC_STATIC,button,1342177287
Control5=IDC_RADIO_CTRL1,button,1342308361
Control6=IDC_RADIO_CTRL2,button,1342177289
Control7=IDC_RADIO_CTRL3,button,1342177289
Control8=IDC_RADIO_CTRL4,button,1342177289
Control9=IDC_RADIO_EALIGN1,button,1342308361
Control10=IDC_RADIO_EALIGN2,button,1342177289
Control11=IDC_RADIO_EALIGN3,button,1342177289
Control12=IDC_RADIO_CSTATE1,button,1342308361
Control13=IDC_RADIO_CSTATE2,button,1342177289
Control14=IDC_RADIO_CBDROP1,button,1342308361
Control15=IDC_RADIO_CBDROP2,button,1342177289

[TB:IDR_GRIDHEAD (English (U.S.))]
Type=1
Class=?
Command1=ID_BTN_ADDCOL
Command2=ID_BTN_EDITCOL
Command3=ID_BTN_DELCOL
Command4=ID_BTN_MOVEUP
Command5=ID_BTN_MOVEDOWN
Command6=ID_BTN_PREVIEWGRID
CommandCount=6

