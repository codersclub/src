#if !defined(AFX_GRIDDLG_H__09AA4893_AFD0_11D4_8A40_005004555789__INCLUDED_)
#define AFX_GRIDDLG_H__09AA4893_AFD0_11D4_8A40_005004555789__INCLUDED_

// GridDlg.h : header file
//
#include "ALXGridaw.h"

/////////////////////////////////////////////////////////////////////////////
// CGridDlg dialog

class CGridDlg : public CAppWizStepDlg
{

// Construction
public:
	CGridDlg();
	~CGridDlg();
	virtual BOOL OnDismiss();

// Dialog Data
	//{{AFX_DATA(CGridDlg)
	enum { IDD = IDD_GRIDSTYLE };
	CEdit	m_ctrlPath;
	CButton	m_ctrlBrowse;
	BOOL	m_bFlatStyle;
	BOOL	m_bRowSelStyle;
	//}}AFX_DATA
private:
	BOOL BrowseForFolder(CString& strFolder, LPCTSTR pszTitle, INT nFolder, UINT uFlags = BIF_RETURNONLYFSDIRS);
	void SaveInfo();
	CBitmap m_bmpGrid;
	CBitmap m_bmpFon;

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGridDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	afx_msg void OnShowWindow(BOOL bShow, UINT nStatus);
	// Generated message map functions
	//{{AFX_MSG(CGridDlg)
	afx_msg void OnPaint();
	virtual BOOL OnInitDialog();
	afx_msg void OnBtnBrowse();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GRIDDLG_H__09AA4893_AFD0_11D4_8A40_005004555789__INCLUDED_)
