// GridDlg.cpp : implementation file
//

#include "stdafx.h"
#include "ALXGridwz.h"
#include "GridDlg.h"
#include "ALXGridaw.h"
#include "WizUtil.h"

#ifdef _PSEUDO_DEBUG
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridDlg dialog


CGridDlg::CGridDlg()
	: CAppWizStepDlg(CGridDlg::IDD)
{
	//{{AFX_DATA_INIT(CGridDlg)
	m_bFlatStyle = FALSE;
	m_bRowSelStyle = FALSE;
	//}}AFX_DATA_INIT

//	m_bmpGrid.LoadBitmap(IDB_GRID);
	m_bmpFon.LoadBitmap(IDB_FON);


	LONG lRc;
	HKEY hReadKey;
	DWORD dwDataType;
	DWORD dwLength;
	char szMessage[512];

	ALXAppWz.m_strGridPath = "..\\ALXGrid";

	// �������� ���������
	lRc = RegOpenKeyEx(HKEY_LOCAL_MACHINE,
		"Software\\CLASSES\\ALXSoft\\Wizards\\ALXGridWiz",
		0,
		KEY_READ,
		&hReadKey);
	if(lRc != ERROR_SUCCESS)
		return;

	// ��������� ����� ������
	dwLength = sizeof(szMessage);
	// ������ ��������
	lRc = RegQueryValueEx(hReadKey,
		"ALXGrid path",
		NULL,
		&dwDataType,
		(LPBYTE) szMessage,
		&dwLength);
	if(lRc != ERROR_SUCCESS)
		return;

	ALXAppWz.m_strGridPath.Format("%s",szMessage);

}

CGridDlg::~CGridDlg()
{
	LONG lRc;
	HKEY hNewKey;
	DWORD dwDisposition;
	
	// ������� ����� ����
	lRc = RegCreateKeyEx(HKEY_LOCAL_MACHINE,
		"Software\\CLASSES\\ALXSoft\\Wizards\\ALXGridWiz",
		0,
		NULL,
		REG_OPTION_NON_VOLATILE,
		KEY_ALL_ACCESS,
		NULL,
		&hNewKey,
		&dwDisposition);
	if(lRc == ERROR_SUCCESS)
	{
		// ��������� ��������
		lRc = RegSetValueEx(hNewKey,
			"ALXGrid path",
			0,
			REG_SZ,
			(BYTE*)(LPCTSTR) ALXAppWz.m_strGridPath,
			ALXAppWz.m_strGridPath.GetLength()+1);

//		lRc = RegFlushKey(nNewKey);
		lRc = RegCloseKey(hNewKey);
	}
}

void CGridDlg::DoDataExchange(CDataExchange* pDX)
{
	CAppWizStepDlg::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGridDlg)
	DDX_Control(pDX, IDC_EDITPATH, m_ctrlPath);
	DDX_Control(pDX, IDC_BTNBROWSE, m_ctrlBrowse);
	DDX_Check(pDX, IDC_CHCKFLAT, m_bFlatStyle);
	DDX_Check(pDX, IDC_CHCKROWSEL, m_bRowSelStyle);
	//}}AFX_DATA_MAP
}

// This is called whenever the user presses Next, Back, or Finish with this step
//  present.  Do all validation & data exchange from the dialog in this function.
BOOL CGridDlg::OnDismiss()
{
	SaveInfo();

	if (!UpdateData(TRUE))
		return FALSE;

	ALXAppWz.m_bFlatStyle = m_bFlatStyle;
	ALXAppWz.m_bRowSelStyle = m_bRowSelStyle;

	return TRUE;	// return FALSE if the dialog shouldn't be dismissed
}


BEGIN_MESSAGE_MAP(CGridDlg, CAppWizStepDlg)
	//{{AFX_MSG_MAP(CGridDlg)
	ON_WM_PAINT()
	ON_BN_CLICKED(IDC_BTNBROWSE, OnBtnBrowse)
	//}}AFX_MSG_MAP
	ON_WM_SHOWWINDOW()
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CGridDlg message handlers

void CGridDlg::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	CRect rect;
	GetClientRect(rect);

	// Create a pattern brush from the bitmap.
	CBrush brush;
	CSize sizeGrid;
	BITMAP bmgrid;
	brush.CreatePatternBrush(&m_bmpFon);
	m_bmpGrid.GetBitmap(&bmgrid);
	sizeGrid.cx = bmgrid.bmWidth;
	sizeGrid.cy = bmgrid.bmHeight;

	// Select the brush into a device context, and draw.
	CBrush* pOldBrush = (CBrush*)dc.SelectObject(&brush);
	dc.FillRect(&CRect(0, 0, 180, rect.Height()),&brush); 	
	// Restore the original brush.
	dc.SelectObject(pOldBrush);


	CRect rect2(180, 0,180 + 2, rect.Height()+1);
	dc.Draw3dRect(rect2,::GetSysColor(COLOR_BTNSHADOW) , ::GetSysColor(COLOR_WINDOW));

	CPoint pt(16,16);
	dc.DrawState(pt,sizeGrid,m_bmpGrid,DSS_NORMAL);
}

BOOL CGridDlg::OnInitDialog() 
{
	CAppWizStepDlg::OnInitDialog();

	m_ctrlPath.SetWindowText(ALXAppWz.m_strGridPath);

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CGridDlg::SaveInfo()
{
	m_ctrlPath.GetWindowText(ALXAppWz.m_strGridPath);
	if(ALXAppWz.m_strGridPath.IsEmpty())
		ALXAppWz.m_strGridPath = "..\\ALXGrid";
}

void CGridDlg::OnBtnBrowse() 
{
	m_ctrlPath.GetWindowText(ALXAppWz.m_strGridPath);
	if(BrowseForFolder(ALXAppWz.m_strGridPath,"Select Folder",CSIDL_DRIVES))
		m_ctrlPath.SetWindowText(ALXAppWz.m_strGridPath);
}

BOOL CGridDlg::BrowseForFolder(CString &strFolder, LPCTSTR pszTitle, INT nFolder, UINT uFlags)
{
    BROWSEINFO bi; 
	LPMALLOC pMalloc = NULL;
    LPSTR lpBuffer = NULL; 
	LPSTR lpDestBuffer = NULL;
    LPITEMIDLIST pidlFolder = NULL;    // PIDL for starting place 
    LPITEMIDLIST pidlBrowse = NULL;    // PIDL selected by user 
	HWND hWnd = AfxGetMainWnd()->GetSafeHwnd();
	BOOL bRet = FALSE;			

	__try
	{
		// Get the Shell memory allocator object
		// It's required to free memory allocated by the shell
		if (FAILED(SHGetMalloc (&pMalloc)))
			__leave;

		// Allocate a buffer to receive browse information. 
		if ((lpBuffer = (LPSTR) pMalloc->Alloc(MAX_PATH)) == NULL) 
			__leave;

			 
	    // Get the PIDL to be used as the starting point in the browse dialog
		if (FAILED (SHGetSpecialFolderLocation (hWnd, nFolder, &pidlFolder)))
			__leave;

		// Fill in the BROWSEINFO structure.
		bi.hwndOwner = hWnd; 
		bi.pidlRoot = pidlFolder; 
		bi.pszDisplayName = lpBuffer; 
		bi.lpszTitle = pszTitle; 
		bi.ulFlags = uFlags; 
		bi.lpfn = NULL; 
		bi.lParam = 0; 

		// Display the modal browse dialog
	    pidlBrowse = SHBrowseForFolder(&bi); 
		if (pidlBrowse != NULL)
		{
			// get the path for the selected item ID list
			lpDestBuffer = strFolder.GetBufferSetLength(MAX_PATH);
			ASSERT(lpDestBuffer != NULL);
			if (!SHGetPathFromIDList (pidlBrowse, lpDestBuffer))
				__leave;

			bRet = TRUE;
		}
	
	} 
	__finally
	{
		if (pidlBrowse)	
			pMalloc->Free(pidlBrowse);

		if (lpDestBuffer)	
			strFolder.ReleaseBuffer();

		if (pidlFolder)	 	
			pMalloc->Free(pidlFolder);

		if (lpBuffer)		
			pMalloc->Free(lpBuffer);

		if (pMalloc)		
			pMalloc->Release();
	}
	return bRet;
}

void CGridDlg::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CAppWizStepDlg::OnShowWindow(bShow, nStatus);
	if (!bShow)
		return;

	m_bmpGrid.DeleteObject(); 
	if(IsMacroDefine(_T("PROJTYPE_DLG")))
		m_bmpGrid.LoadBitmap(IDB_DLGGRID);
	else
		m_bmpGrid.LoadBitmap(IDB_GRID);


	CWnd* pParentWnd = GetParent();
	if(pParentWnd == NULL)
		return;

	int PropSheetButtons[] = { 0x1B9, IDOK, 0x1B8, IDCANCEL, ID_HELP };
	CWnd* pWndBtnHlp = pParentWnd->GetDlgItem(ID_HELP);
	CWnd* pWndBtnCnl = pParentWnd->GetDlgItem(IDCANCEL);

	if(pWndBtnHlp != NULL && pWndBtnCnl != NULL)
	{
		CRect rectHlp, rectBtn;
		pWndBtnHlp->GetWindowRect(rectHlp);
		pParentWnd->ScreenToClient(rectHlp); 
		pWndBtnHlp->ModifyStyle(WS_VISIBLE,WS_DISABLED);

		pWndBtnCnl->GetWindowRect(rectBtn);
		pParentWnd->ScreenToClient(rectBtn); 

		int dx = rectHlp.right - rectBtn.right;

		if(dx > 0)
		{
			pWndBtnCnl->MoveWindow(rectBtn.left + dx, rectBtn.top, rectBtn.Width(), rectBtn.Height(), FALSE);

			for(int i = 2; i >= 0; i--)
			{
				CWnd* pWndBtn = pParentWnd->GetDlgItem(PropSheetButtons[i]);
				if(pWndBtn != NULL)
				{
					pWndBtn->GetWindowRect(rectBtn);
					pParentWnd->ScreenToClient(rectBtn); 
					pWndBtn->MoveWindow(rectBtn.left + dx, rectBtn.top, rectBtn.Width(), rectBtn.Height(), FALSE);
				}
			}
		}
	}

	return;
}


