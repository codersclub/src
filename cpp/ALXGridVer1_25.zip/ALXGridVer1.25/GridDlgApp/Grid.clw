; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAboutDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "grid.h"
LastPage=0

ClassCount=4
Class1=CGridApp
Class2=CGridCtrl
Class3=CAboutDlg
Class4=CGridDlg

ResourceCount=2
Resource1=IDD_ABOUTBOX (English (U.S.))
Resource2=IDD_GRID_DIALOG (English (U.S.))

[CLS:CGridApp]
Type=0
BaseClass=CWinApp
HeaderFile=Grid.h
ImplementationFile=Grid.cpp

[CLS:CGridCtrl]
Type=0
BaseClass=CALXGridCtrl
HeaderFile=GridCtrl.h
ImplementationFile=GridCtrl.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=GridDlg.cpp
ImplementationFile=GridDlg.cpp
LastObject=CAboutDlg

[CLS:CGridDlg]
Type=0
BaseClass=CDialog
HeaderFile=GridDlg.h
ImplementationFile=GridDlg.cpp

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_GRID_DIALOG]
Type=1
Class=CGridDlg

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308481
Control3=IDC_STATIC,static,1342308353
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,button,1342177287

[DLG:IDD_GRID_DIALOG (English (U.S.))]
Type=1
Class=?
ControlCount=2
Control1=IDOK,button,1342242817
Control2=IDC_STATIC_FRAME,static,1208029184

