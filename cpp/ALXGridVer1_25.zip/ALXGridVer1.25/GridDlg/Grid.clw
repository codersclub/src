; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAboutDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "grid.h"
LastPage=0

ClassCount=10
Class1=CChildFrame
Class2=CCrGridCtrl
Class3=CCrGridDLG
Class4=CGridApp
Class5=CAboutDlg
Class6=CGridDoc
Class7=CGridView
Class8=CMainFrame
Class9=CRegGridCtrl
Class10=CRegGridDLG

ResourceCount=6
Resource1=IDR_GRIDTYPE (English (U.S.))
Resource2=IDD_ABOUTBOX (English (U.S.))
Resource3=IDD_REGGRID_DLG (English (U.S.))
Resource4=IDD_GRID_FORM (English (U.S.))
Resource5=IDD_CRGRID_DLG (English (U.S.))
Resource6=IDR_MAINFRAME (English (U.S.))

[CLS:CChildFrame]
Type=0
BaseClass=CMDIChildWnd
HeaderFile=ChildFrm.h
ImplementationFile=ChildFrm.cpp

[CLS:CCrGridCtrl]
Type=0
BaseClass=CALXGridCtrl
HeaderFile=CrGridCtrl.h
ImplementationFile=CrGridCtrl.cpp

[CLS:CCrGridDLG]
Type=0
BaseClass=CDialog
HeaderFile=CrGridDLG.h
ImplementationFile=CrGridDLG.cpp

[CLS:CGridApp]
Type=0
BaseClass=CWinApp
HeaderFile=Grid.h
ImplementationFile=Grid.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=Grid.cpp
ImplementationFile=Grid.cpp
LastObject=CAboutDlg

[CLS:CGridDoc]
Type=0
BaseClass=CDocument
HeaderFile=GridDoc.h
ImplementationFile=GridDoc.cpp

[CLS:CGridView]
Type=0
BaseClass=CALXGridView
HeaderFile=GridView.h
ImplementationFile=GridView.cpp

[CLS:CMainFrame]
Type=0
BaseClass=CMDIFrameWnd
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp

[CLS:CRegGridCtrl]
Type=0
BaseClass=CALXGridCtrl
HeaderFile=RegGridCtrl.h
ImplementationFile=RegGridCtrl.cpp

[CLS:CRegGridDLG]
Type=0
BaseClass=CDialog
HeaderFile=RegGridDLG.h
ImplementationFile=RegGridDLG.cpp

[DLG:IDD_CRGRID_DLG]
Type=1
Class=CCrGridDLG

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_REGGRID_DLG]
Type=1
Class=CRegGridDLG

[DLG:IDD_REGGRID_DLG (English (U.S.))]
Type=1
Class=?
ControlCount=2
Control1=IDOK,button,1342242817
Control2=IDD_GRIDCTRL,CRegGridCtrl,1353777152

[DLG:IDD_CRGRID_DLG (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDOK,button,1342242817

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308481
Control3=IDC_STATIC,static,1342308353
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,button,1342177287

[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_APP_ABOUT
CommandCount=8

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_VIEW_TOOLBAR
Command7=ID_VIEW_STATUS_BAR
Command8=ID_REGGRIGCTRL_DIALOG
Command9=ID_CRGRIGCTRL_DIALOG
Command10=ID_APP_ABOUT
CommandCount=10

[MNU:IDR_GRIDTYPE (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_CLOSE
Command4=ID_FILE_SAVE
Command5=ID_FILE_SAVE_AS
Command6=ID_FILE_PRINT
Command7=ID_FILE_PRINT_PREVIEW
Command8=ID_FILE_PRINT_SETUP
Command9=ID_FILE_MRU_FILE1
Command10=ID_APP_EXIT
Command11=ID_EDIT_UNDO
Command12=ID_EDIT_CUT
Command13=ID_EDIT_COPY
Command14=ID_EDIT_PASTE
Command15=ID_VIEW_TOOLBAR
Command16=ID_VIEW_STATUS_BAR
Command17=ID_REGGRIGCTRL_DIALOG
Command18=ID_CRGRIGCTRL_DIALOG
Command19=ID_WINDOW_NEW
Command20=ID_WINDOW_CASCADE
Command21=ID_WINDOW_TILE_HORZ
Command22=ID_WINDOW_ARRANGE
Command23=ID_APP_ABOUT
CommandCount=23

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_GRID_FORM (English (U.S.))]
Type=1
Class=?
ControlCount=1
Control1=IDC_STATIC_FRAME,static,1073876992

