// ALXGridDefinitions.cpp : implementation file
//

#include "stdafx.h"
#include "ALXGridDefinitions.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CALXFocusRect

// �����������
CALXFocusRect::CALXFocusRect()
{
	m_crBackColor = ::GetSysColor(COLOR_WINDOW);
	m_crFaceColor = COLOR_SELECTCELLFRAME;
	m_bSolod = TRUE;
}

// ����������
CALXFocusRect::~CALXFocusRect()
{

}

CALXFocusRect::DrawFocusRect(CDC *pDC, CRect& rc)
{
	if(m_bSolod)
		pDC->Draw3dRect(&rc,m_crFaceColor,m_crFaceColor);
	else
	{
		COLORREF crBkColor = pDC->GetBkColor();
		COLORREF crTxtColor = pDC->GetTextColor();
		pDC->Draw3dRect(&rc,m_crBackColor,m_crBackColor);
		pDC->SetBkColor(m_crBackColor);
		pDC->SetTextColor(m_crFaceColor);
		pDC->DrawFocusRect(rc);
		pDC->SetBkColor(crBkColor);
		pDC->SetTextColor(crTxtColor);
	}
}

/////////////////////////////////////////////////////////////////////////////
