//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ALXGrid.rc
//
#define IDC_CURSOR_HRESIZE              134
#define IDC_CELLCTRL                    1900

