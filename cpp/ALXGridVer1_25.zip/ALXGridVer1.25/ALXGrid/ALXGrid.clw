; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CALXButtonCtrl
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "alxgrid.h"
LastPage=0

ClassCount=7
Class1=CALXButtonCtrl
Class2=CALXComboEditCtrl
Class3=CALXComboBoxCtrl
Class4=CALXEditCtrl
Class5=CALXGridCtrl
Class6=CALXGridView
Class7=CALXSplitterWnd

ResourceCount=0

[CLS:CALXButtonCtrl]
Type=0
BaseClass=CButton
HeaderFile=ALXButtonCtrl.h
ImplementationFile=ALXButtonCtrl.cpp
LastObject=CALXButtonCtrl

[CLS:CALXComboEditCtrl]
Type=0
BaseClass=CEdit
HeaderFile=ALXComboBoxCtrl.h
ImplementationFile=ALXComboBoxCtrl.cpp

[CLS:CALXComboBoxCtrl]
Type=0
BaseClass=CComboBox
HeaderFile=ALXComboBoxCtrl.h
ImplementationFile=ALXComboBoxCtrl.cpp

[CLS:CALXEditCtrl]
Type=0
BaseClass=CEdit
HeaderFile=ALXEditCtrl.h
ImplementationFile=ALXEditCtrl.cpp

[CLS:CALXGridCtrl]
Type=0
BaseClass=CWnd
HeaderFile=ALXGridCtrl.h
ImplementationFile=ALXGridCtrl.cpp

[CLS:CALXGridView]
Type=0
BaseClass=CView
HeaderFile=ALXGridView.h
ImplementationFile=ALXGridView.cpp

[CLS:CALXSplitterWnd]
Type=0
BaseClass=CSplitterWnd
HeaderFile=ALXSplitterWnd.h
ImplementationFile=ALXSplitterWnd.cpp

