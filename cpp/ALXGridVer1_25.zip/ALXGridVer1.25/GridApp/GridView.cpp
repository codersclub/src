// GridView.cpp : implementation of the CGridView class
//

#include "stdafx.h"
#include "Grid.h"

#include "GridDoc.h"
#include "GridView.h"
#include "SetCountDlg.h"
#include "SetHeightDlg.h"
#include "SetWidthDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGridView

IMPLEMENT_DYNCREATE(CGridView, CALXGridView)

BEGIN_MESSAGE_MAP(CGridView, CALXGridView)
	//{{AFX_MSG_MAP(CGridView)
	ON_COMMAND(ID_GVIEW_GRIDFONT, OnSetGridFont)
	ON_COMMAND(ID_GVIEW_HEADFONT, OnSetHeadFont)
	ON_COMMAND(ID_GVIEW_HEADROW, OnSetHeadRowsCount)
	ON_COMMAND(ID_GVIEW_HEADHEIGHT, OnSetHeadHeight)
	ON_COMMAND(ID_GVIEW_FROZENWIDTH, OnSetFrozenColWidth)
	ON_COMMAND(ID_GVIEW_FROZENCOL, OnSetFrozenColsCount)
	ON_UPDATE_COMMAND_UI(ID_GSTYLE_ROWSELECT, OnUpdateGStyleRowselect)
	ON_COMMAND(ID_GSTYLE_ROWSELECT, OnGStyleRowselect)
	ON_UPDATE_COMMAND_UI(ID_GSTYLE_FLAT, OnUpdateGStyleFlat)
	ON_COMMAND(ID_GSTYLE_FLAT, OnGStyleFlat)
	ON_UPDATE_COMMAND_UI(ID_EDITROW_DEL, OnUpdateDelRow)
	ON_UPDATE_COMMAND_UI(ID_EDITROW_INS, OnUpdateInsRow)
	ON_COMMAND(ID_EDITROW_DEL, OnDelRow)
	ON_COMMAND(ID_EDITROW_INS, OnInsRow)
	ON_COMMAND(ID_EDITROW_ADD, OnAddRow)
	ON_COMMAND(ID_GSTYLE_NOGRIDLINES, OnGStyleNoGridLines)
	ON_UPDATE_COMMAND_UI(ID_GSTYLE_NOGRIDLINES, OnUpdateGStyleNoGridLines)
	//}}AFX_MSG_MAP
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CALXGridView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CALXGridView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CALXGridView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGridView construction/destruction

CGridView::CGridView()
{
	// Text
	DefineColCtrl(AddCol(80,"LeftText", ACFF_LEFT, AHFF_LEFT),GA_EDITCTRL,WS_CHILD | ES_LEFT | ES_AUTOHSCROLL);
	DefineColCtrl(AddCol(80,"CenterText", ACFF_CENTER, AHFF_CENTER),GA_EDITCTRL,WS_CHILD | ES_CENTER | ES_AUTOHSCROLL);
	DefineColCtrl(AddCol(80,"RightText", ACFF_RIGHT, AHFF_RIGHT),GA_EDITCTRL,WS_CHILD | ES_RIGHT | ES_AUTOHSCROLL);

	// Bitmap
	int nCol = AddCol(80,"Bitmap && Text", ACFF_LEFT, AHFF_LEFT);
	DefineColCtrl(nCol,GA_EDITCTRL,WS_CHILD | ES_LEFT | ES_AUTOHSCROLL);
	DefineImage(nCol,7,7,DIT_IMGLIST);
	// CheckBox
	DefineColCtrl(AddCol(90,"CheckBox3State", ACFF_CENTER, AHFF_CENTER, DFC_BUTTON, DFCS_BUTTON3STATE | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTO3STATE | BS_FLAT);
	DefineColCtrl(AddCol(60,"CheckBox", ACFF_CENTER, AHFF_CENTER,DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTOCHECKBOX | BS_FLAT);

	DefineColCtrl(AddCol(130,"CheckBox3State && Text", ACFF_LEFT, AHFF_LEFT, DFC_BUTTON,DFCS_BUTTON3STATE | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTO3STATE | BS_FLAT);
	DefineColCtrl(AddCol(90,"CheckBox && Text", ACFF_LEFT, AHFF_LEFT,DFC_BUTTON, DFCS_BUTTONCHECK | DFCS_FLAT),GA_BUTTONCTRL,WS_CHILD | BS_AUTOCHECKBOX | BS_FLAT);
	// ComboBox
	DefineColCtrl(AddCol(150,"Hide DropDownComboBox", ACFF_LEFT, AHFF_LEFT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWN | WS_VSCROLL);
	DefineColCtrl(AddCol(150,"DropDownComboBox", ACFF_LEFT, AHFF_LEFT, DFC_SCROLL, DFCS_SCROLLCOMBOBOX | DFCS_FLAT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWN | WS_VSCROLL);

	DefineColCtrl(AddCol(130,"Hide ListComboBox", ACFF_LEFT, AHFF_LEFT),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL);
	DefineColCtrl(AddCol(130,"ListComboBox", ACFF_LEFT, ACFF_LEFT, DFC_SCROLL, DFCS_SCROLLCOMBOBOX),GA_COMBOBOXCTRL,WS_CHILD | CBS_DROPDOWNLIST | WS_VSCROLL);

	VERIFY(m_ImageList.Create(IDB_BITMAP_IMGLIST, 7, 1, (COLORREF)0x808000));

	CSize sizeExArea(50,50);
	SetExtAreaSize(sizeExArea, FALSE);
	SetFocusRect(::GetSysColor(COLOR_WINDOWTEXT),::GetSysColor(COLOR_WINDOW),FALSE);
	SetHeadRowCount(2,FALSE);
//	SetGridRowCount(0);
}

CGridView::~CGridView()
{
}

BOOL CGridView::PreCreateWindow(CREATESTRUCT& cs)
{
//	cs.style = cs.style | AGS_CUSTOMFROZEN_WIDTH;
	return CALXGridView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGridView drawing

void CGridView::OnDraw(CDC* pDC)
{
	CGridDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGridView printing

BOOL CGridView::OnPreparePrinting(CPrintInfo* pInfo)
{
	ASSERT(pInfo != NULL);
	ASSERT(pInfo->m_pPD != NULL);

	if (pInfo->m_pPD->m_pd.nMinPage > pInfo->m_pPD->m_pd.nMaxPage)
		pInfo->m_pPD->m_pd.nMaxPage = pInfo->m_pPD->m_pd.nMinPage;

	// don't prompt the user if we're doing print preview, printing directly,
	// or printing via IPrint and have been instructed not to ask

	CGridApp* pApp = (CGridApp*) AfxGetApp();
	if (!(pInfo->m_dwFlags & PRINTFLAG_PROMPTUSER))
	{
		if (pInfo->m_pPD->m_pd.hDC == NULL)
		{
			// if no printer set then, get default printer DC and create DC without calling
			//   print dialog.
			pApp->GetPrinterDeviceDefaults(&pInfo->m_pPD->m_pd);
		}
	}

	PageWight = PRN_XMARGIN * 2; // ������ ������ 1 � ����� 1
	// ���������� ������ �����
	for(int i = 0; i < GetHeadColCount(); i++)
		PageWight = PageWight + GetHeadColWidth(i);
	if(pApp->GetPageOrientation() & DMORIENT_LANDSCAPE)
		PageHight = PageWight*210/297;
	else
		PageHight = PageWight*297/210;

	nRowInPage = (PageHight - PRN_YMARGIN*2 - GetHeadRowCount()*GetHeadRowHeight())/GetGridRowHeight();
	
	pInfo->SetMaxPage(GetGridRowCount()/nRowInPage + (GetGridRowCount()%nRowInPage > 0 ? 1 : 0));

	// default preparation
	return DoPreparePrinting(pInfo);
}

void CGridView::OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo)
{
	CDC *pCurrentDC = GetDC();        // will have dimensions of the client area
    if(!pCurrentDC) 
		return;

    // Get the page sizes (physical and logical)
    m_PaperSize = CSize(pDC->GetDeviceCaps(HORZRES), pDC->GetDeviceCaps(VERTRES));
	
	PageHight = PageWight*m_PaperSize.cy/m_PaperSize.cx;

	nRowInPage = (PageHight - PRN_YMARGIN*2 - GetHeadRowCount()*GetHeadRowHeight())/GetGridRowHeight();

	pInfo->SetMaxPage(GetGridRowCount()/nRowInPage + (GetGridRowCount()%nRowInPage > 0 ? 1 : 0));

	ReleaseDC(pCurrentDC);
}

void CGridView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: add cleanup after printing
}

CELL_DATA CGridView::GetCellData(int nCol, int nRow)
{
	CELL_DATA CellData = CALXGrid::GetCellData(nCol,nRow);
	CGridDoc* pDoc = GetDocument();
	
	switch(nCol)
	{
		case 0: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_LeftText;
				break;
			}
		case 1: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CenterText;
				break;
			}
		case 2: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_RightText;
				break;
			}
		case 3: 
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_BitmapText;
				break;
			}
		case 4:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox3State;
				break;
			}
		case 5:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox;
				break;
			}
		case 6:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CheckBox3StateText.m_Text;
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBox3StateText.m_State;
				break;
			}
		case 7:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_CheckBoxText.m_Text;
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_CheckBoxText.m_State;
				break;
			}
		case 8:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_HideDropDownComboBox;
				break;
			}
		case 9:
			{
				CellData.m_strText = pDoc->m_Rows[nRow].m_DropDownComboBox;
				break;
			}
		case 10:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_HideListComboBox;
				CellData.m_strText.Format("%u",pDoc->m_Rows[nRow].m_HideListComboBox);
				break;
			}
		case 11:
			{
				CellData.m_dwTag = pDoc->m_Rows[nRow].m_ListComboBox;
				CellData.m_strText.Format("%u-�",pDoc->m_Rows[nRow].m_ListComboBox);
				break;
			}
	}
	return CellData;
}

/////////////////////////////////////////////////////////////////////////////
// CGridView diagnostics

#ifdef _DEBUG
void CGridView::AssertValid() const
{
	CALXGridView::AssertValid();
}

void CGridView::Dump(CDumpContext& dc) const
{
	CALXGridView::Dump(dc);
}

CGridDoc* CGridView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGridDoc)));
	return (CGridDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGridView message handlers

void CGridView::GetImageListDrawParams(int nCol, int nRow, IMAGELISTDRAWPARAMS* pimldp, BOOL bSelected)
{
	pimldp->himl = m_ImageList.m_hImageList;
	if(bSelected)
		pimldp->fStyle = ILD_SELECTED;
	pimldp->i = 0;
}

CALXCellCtrl* CGridView::CreateCellCtrl(int nCol, int nRow, DWORD dwStyle, UINT nID)
{
	CALXCellCtrl* pCellCtrl = CALXGrid::CreateCellCtrl(nCol, nRow, dwStyle);
	if(pCellCtrl != NULL)
	{
		switch(nCol)
		{
		case 8:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("���");
				pComboBoxCtrl->AddString("���");
				pComboBoxCtrl->AddString("���");
				break;
			}
		case 9:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("������");
				pComboBoxCtrl->AddString("������");
				pComboBoxCtrl->AddString("������");
				break;
			}
		case 10:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("1");
				pComboBoxCtrl->SetItemData(0,1);
				pComboBoxCtrl->AddString("2");
				pComboBoxCtrl->SetItemData(1,2);
				pComboBoxCtrl->AddString("3");
				pComboBoxCtrl->SetItemData(2,3);
				break;
			}
		case 11:
			{
				CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) pCellCtrl;
				pComboBoxCtrl->AddString("1-�");
				pComboBoxCtrl->SetItemData(0,1);
				pComboBoxCtrl->AddString("2-�");
				pComboBoxCtrl->SetItemData(1,2);
				pComboBoxCtrl->AddString("3-�");
				pComboBoxCtrl->SetItemData(2,3);
				break;
			}
		}
	}
	return pCellCtrl;
}

void CGridView::OnInitialUpdate() 
{
	CALXGridView::OnInitialUpdate();
	
	SetGridRowCount(GetDocument()->m_Rows.GetSize());
	UpdateScrollSizes();
	CGridView::SetFocus();

}

BOOL CGridView::OnSaveCellData(int nCol, int nRow)
{
	CGridDoc* pDoc = GetDocument();
	CALXCellCtrl* pCellCtrl = GetCellCtrl(nCol,nRow);
	if(pCellCtrl != NULL)
	{
		CELL_DATA Data = pCellCtrl->GetCellData();
		switch(nCol)
		{
			case 0: 
				{
					pDoc->m_Rows[nRow].m_LeftText = Data.m_strText;
					break;
				}
			case 1: 
				{
					pDoc->m_Rows[nRow].m_CenterText = Data.m_strText;
					break;
				}
			case 2: 
				{
					pDoc->m_Rows[nRow].m_RightText = Data.m_strText;
					break;
				}
			case 3: 
				{
					pDoc->m_Rows[nRow].m_BitmapText = Data.m_strText;
					break;
				}
			case 4:
				{
					pDoc->m_Rows[nRow].m_CheckBox3State = (STATE)Data.m_dwTag;
					break;
				}
			case 5:
				{
					pDoc->m_Rows[nRow].m_CheckBox = (STATE)Data.m_dwTag;
					break;
				}
			case 6:
				{
					pDoc->m_Rows[nRow].m_CheckBox3StateText.m_State = (STATE)Data.m_dwTag;
					break;
				}
			case 7:
				{
					pDoc->m_Rows[nRow].m_CheckBoxText.m_State = (STATE)Data.m_dwTag;
					break;
				}
			case 8:
				{
					if(Data.m_dwTag == ULONG_MAX)
					{
						CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) GetCellCtrl(nCol, nRow);
						pComboBoxCtrl->AddString(Data.m_strText);
					}
					pDoc->m_Rows[nRow].m_HideDropDownComboBox = Data.m_strText;
					break;
				}
			case 9:
				{
					if(Data.m_dwTag == ULONG_MAX)
					{
						CALXComboBoxCtrl* pComboBoxCtrl = (CALXComboBoxCtrl*) GetCellCtrl(nCol, nRow);
						pComboBoxCtrl->AddString(Data.m_strText);
					}
					pDoc->m_Rows[nRow].m_DropDownComboBox = Data.m_strText;
					break;
				}
			case 10:
				{
					pDoc->m_Rows[nRow].m_HideListComboBox = (ORDER)Data.m_dwTag;
					break;
				}
			case 11:
				{
					pDoc->m_Rows[nRow].m_ListComboBox = (ORDER)Data.m_dwTag;
					break;
				}
		}
	}
	return TRUE;
}

void CGridView::OnSetGridFont()
{
	static LOGFONT	 logfont;
	memset(&logfont, 0, sizeof(logfont));
	CFont* fontGrid = GetGridFont();
	fontGrid->GetLogFont(&logfont);
	CFontDialog dlg(&logfont, CF_SCREENFONTS); 
	
	if(dlg.DoModal() == IDOK) 
	{
		CFont newFont;
		if(newFont.CreateFontIndirect(&logfont)) 
		{
			SetGridFont(&newFont);
			Invalidate();
		}
	}
}

void CGridView::OnSetHeadFont() 
{
	LOGFONT	 logfont;
	memset(&logfont, 0, sizeof(logfont));
	CFont* fontHead = GetHeadFont();
	fontHead->GetLogFont(&logfont);
	CFontDialog dlg(&logfont, CF_SCREENFONTS); 
	
	if (dlg.DoModal() == IDOK) 
	{
		m_HeadFont.DeleteObject();
		if(m_HeadFont.CreateFontIndirect(&logfont)) 
		{
			SetHeadFont(&m_HeadFont);
			Invalidate();
		}
	}
}

void CGridView::OnSetHeadRowsCount() 
{
	CSetCountDlg dlgSetCount;
	dlgSetCount.m_bCount = GetHeadRowCount();
	if (dlgSetCount.DoModal() == IDOK) 
	{
		SetHeadRowCount(dlgSetCount.m_bCount);
		Invalidate();
	}
}


void CGridView::OnSetHeadHeight() 
{
	CSetHeightDlg dlgSetHeight;
	dlgSetHeight.m_bHeight = GetHeadRowHeight();
	if (dlgSetHeight.DoModal() == IDOK) 
	{
		CGridView::ModifyStyle(0,AGS_CUSTOMHEAD_HEIGHT);

		SetHeadRowHeight(dlgSetHeight.m_bHeight);
		Invalidate();
	}
}

void CGridView::OnSetFrozenColWidth() 
{
	CSetWidthDlg dlgSetWidth;
	dlgSetWidth.m_bWidth = GetFrozenColWidth();
	if (dlgSetWidth.DoModal() == IDOK) 
	{
		CGridView::ModifyStyle(0,AGS_CUSTOMFROZEN_WIDTH);

		SetFrozenColWidth(dlgSetWidth.m_bWidth);
		Invalidate();
	}
}

void CGridView::OnSetFrozenColsCount() 
{
	CSetCountDlg dlgSetCount;
	dlgSetCount.m_bCount = GetFrozenColCount();
	if (dlgSetCount.DoModal() == IDOK) 
	{
		SetFrozenColCount(dlgSetCount.m_bCount);
		Invalidate();
	}
}

void CGridView::OnUpdateGStyleRowselect(CCmdUI* pCmdUI) 
{
	if(GetStyle() & AGS_ROWSELECT)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CGridView::OnGStyleRowselect() 
{
	if(GetStyle() & AGS_ROWSELECT)
		ModifyStyle(AGS_ROWSELECT,0);
	else
		ModifyStyle(0,AGS_ROWSELECT);
	Invalidate();
}

void CGridView::OnUpdateGStyleFlat(CCmdUI* pCmdUI) 
{
	if(GetStyle() & AGS_FLAT)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}

void CGridView::OnGStyleFlat() 
{
	if(GetStyle() & AGS_FLAT)
		ModifyStyle(AGS_FLAT,0);
	else
		ModifyStyle(0,AGS_FLAT);
	Invalidate();
}

void CGridView::OnUpdateDelRow(CCmdUI* pCmdUI) 
{
	if(GetActiveRow() >= 0 && GetActiveRow() < GetGridRowCount())
		pCmdUI->Enable(TRUE);
	else
		pCmdUI->Enable(FALSE);
}

void CGridView::OnUpdateInsRow(CCmdUI* pCmdUI) 
{
	if(GetActiveRow() >= 0 && GetActiveRow() < GetGridRowCount())
		pCmdUI->Enable(TRUE);
	else
		pCmdUI->Enable(FALSE);
}

void CGridView::OnDelRow() 
{
	GetDocument()->m_Rows.RemoveAt(GetActiveRow());
	CGridView::RemoveRows(GetActiveRow());
}

void CGridView::OnInsRow() 
{
	CALXCellCtrl* pCellCtrl = GetCellCtrl(GetActiveCol(),GetActiveRow());
	if(pCellCtrl != NULL)
	{
		if(pCellCtrl->IsModifyed())
			if(pCellCtrl->OnValidate())
				OnSaveCellData(GetActiveCol(),GetActiveRow());
	}
	ROWINFO RowInfo;
	RowInfo.m_CheckBox3StateText.m_Text = " ";
	RowInfo.m_CheckBoxText.m_Text = " ";
	RowInfo.m_HideListComboBox = first;
	RowInfo.m_ListComboBox = first;
	GetDocument()->m_Rows.InsertAt(GetActiveRow(),RowInfo);
	CGridView::InsertRows(GetActiveRow());
}

void CGridView::OnAddRow() 
{
	ROWINFO RowInfo;
	RowInfo.m_CheckBox3StateText.m_Text = " ";
	RowInfo.m_CheckBoxText.m_Text = " ";
	RowInfo.m_HideListComboBox = first;
	RowInfo.m_ListComboBox = first;
	GetDocument()->m_Rows.Add(RowInfo);
	CGridView::InsertRows(GetDocument()->m_Rows.GetSize()-1);
/*	CGridView::SetGridRowCount(GetDocument()->m_Rows.GetSize());
	CGridView::UpdateScrollSizes();
	CGridView::SetActiveCell(GetActiveCol(),GetDocument()->m_Rows.GetSize()-1);
	CGridView::InvalidateRow(GetActiveRow());
*/
}

void CGridView::PrintHead(CDC* pDC, CPrintInfo* pInfo)
{
	CFont* pOldFont = NULL;
	pOldFont = pDC->SelectObject(GetHeadFont());
	int OldBkMode =	pDC->SetBkMode(TRANSPARENT);


	// ��������� ������ ������ � ������� �����������,
	for (int nRow = 0, y = PRN_YMARGIN; nRow < GetHeadRowCount(); y += GetHeadRowHeight(), nRow++)
		// ��������� ������ ������� � ������� �����������
		for (int nCol = 0, x = PRN_XMARGIN; nCol < GetHeadColCount(nRow); x = x + GetHeadColWidth(nCol,nRow), nCol++)
			PrintHeadCell(pDC,nCol,nRow,x,y);

	if(pOldFont != NULL)
		pDC->SelectObject(pOldFont);
	pDC->SetBkMode(OldBkMode);
}

void CGridView::PrintGridPage(CDC* pDC, CPrintInfo* pInfo)
{
	CFont* pOldFont = NULL;
	pOldFont = pDC->SelectObject(GetGridFont());
	int OldBkMode =	pDC->SetBkMode(TRANSPARENT);

	int y = GetHeadRowCount()*GetHeadRowHeight()+PRN_YMARGIN;

	int nFirstRow = (pInfo->m_nCurPage-1)*nRowInPage;
	int nLastRow = min(GetGridRowCount(),(int)(pInfo->m_nCurPage*nRowInPage));

	// ��������� ������ ������ � ������� �����������,
	for (int nRow = nFirstRow; nRow < nLastRow; y += GetGridRowHeight(), nRow++)
		// ��������� ������ ������ � ������� �����������
		for (int nCol = 0, x = PRN_XMARGIN; nCol < GetHeadColCount(); x = x + GetHeadColWidth(nCol), nCol++)
			PrintGridCell(pDC,nCol,nRow,x,y);

	if(pOldFont != NULL)
		pDC->SelectObject(pOldFont);
	pDC->SetBkMode(OldBkMode);
}

void CGridView::PrintHeadCell(CDC* pDC, int nCol, int nRow, int x, int y)
{
	CRect rectCell(x,y,x+GetHeadColWidth(nCol,nRow)+1,y+GetHeadRowHeight()+1);
	COLORREF clrCellFrame = RGB(0,0,0);

	// ������� �����
	pDC->Draw3dRect(rectCell,clrCellFrame,clrCellFrame);
	rectCell.DeflateRect(1,1,1,1);

	CBrush brushBackground;
	// ����������� ������
	if(brushBackground.CreateSolidBrush(::GetSysColor(COLOR_BTNFACE)))
		pDC->FillRect(&rectCell, &brushBackground);
	rectCell.DeflateRect(2,2,1,0);
	// �������� ����� � ����� 
	HEADCELL_INFO CellInfo = GetHeadCellInfo(nCol,nRow);
	// ������� �����
	pDC->DrawText(CellInfo.m_strText, rectCell, CellInfo.m_nFormat);
}

void CGridView::PrintGridCell(CDC* pDC, int nCol, int nRow, int x, int y)
{
	CELL_INFO CellInfo;
	CELL_DATA CellData;
	CRect rectCell(x,y,x+GetHeadColWidth(nCol)+1,y+GetHeadRowHeight()+1);
	COLORREF clrCellFrame = RGB(0,0,0);

	// ������� �����
	pDC->Draw3dRect(rectCell,clrCellFrame,clrCellFrame);
	rectCell.DeflateRect(1,1,1,1);

	CBrush brushBackground;
	// ����������� ������
	if(brushBackground.CreateSolidBrush(::GetSysColor(COLOR_WINDOW)))
		pDC->FillRect(&rectCell, &brushBackground);
	rectCell.DeflateRect(2,2,1,0);

	// �������� ���������� � ���� ������
	CellInfo = GetCellInfo(nCol,nRow);
	// �������� ���������� � ���������� ������
	CellData = GetCellData(nCol,nRow);

	// ���� ������ � ������������
	if(IsImage(nCol,nRow))
	{
		CPoint pt;
		CSize sz;

		// �������� ������ �����������
		GetSizeImage(nCol,nRow,sz);
		// ��������� ������ �����������, ���� ���������
		sz.cx = min(rectCell.Width(),sz.cx);
		sz.cy = min(rectCell.Height(),sz.cy);

		pt.x = rectCell.left+1;
		// ������� ����������� � ����� ������ �� ��� �
		pt.y = rectCell.top + (rectCell.Height() - sz.cy)/2;

		DrawImage(pDC,nCol,nRow,pt,sz);

		// ������� ����� ������� ������
		rectCell.left = min(rectCell.right,rectCell.left+sz.cx+2);
	}

	rectCell.DeflateRect(1,1,1,1); // ��������� ������� ���������

	// ���� ���� �������� ������� ����������
	if(CellInfo.m_nTypeCtrl > 0)
		DrawCellCtrl(pDC,rectCell,CellInfo,CellData);
	else
		pDC->DrawText((LPCTSTR)CellData.m_strText, rectCell, CellInfo.m_nFormat);
}

void CGridView::DrawImage(CDC *pDC, int nCol, int nRow, CPoint& pt, CSize& sz)
{

	switch(GetTypeImage(nCol,nRow))
	{
	case DIT_ICON :
		{
			HICON hIcon = (HICON)GetImage(nCol,nRow,FALSE);
			if(hIcon != NULL)
				DrawIconEx(pDC->m_hDC,pt.x,pt.y,hIcon,sz.cx,sz.cy,NULL,NULL,DI_NORMAL | DI_DEFAULTSIZE);
			break;
		}
	case DIT_IMGLIST :
		{
			IMAGELISTDRAWPARAMS imldp;
			memset(&imldp, 0, sizeof(imldp));
			imldp.cbSize = sizeof(imldp);
			imldp.hdcDst = pDC->m_hDC;
			imldp.rgbBk = CLR_DEFAULT;
			imldp.rgbFg = CLR_DEFAULT;
			imldp.fStyle = ILD_TRANSPARENT;
			imldp.himl = NULL;
			imldp.cx = sz.cx;
			imldp.cy = sz.cy;
			imldp.x = pt.x;
			imldp.y = pt.y;

			GetImageListDrawParams(nCol,nRow,&imldp,FALSE);

			if(imldp.himl != NULL)
			{

				ImageList_DrawIndirect(&imldp);
			}

			break;
		}
	}
}


void CGridView::OnPrint(CDC* pDC, CPrintInfo* pInfo) 
{
	pDC->SetMapMode(MM_ANISOTROPIC);
	pDC->SetWindowExt(PageWight,PageHight);
	pDC->SetViewportExt(m_PaperSize);
	pDC->SetWindowOrg(0, 0);

	PrintHead(pDC, pInfo);
	PrintGridPage(pDC, pInfo);

	CALXGridView::OnPrint(pDC, pInfo);
}

int CGridView::GetHeadColWidth(int nCol, int nHeadRow)
{
	if(nHeadRow >= 0 && nHeadRow == GetHeadRowCount()-2)
	{
		switch(nCol)
		{
		case 0:
			return CALXGrid::GetHeadColWidth(0) + CALXGrid::GetHeadColWidth(1) + CALXGrid::GetHeadColWidth(2);
		case 1:
			return CALXGrid::GetHeadColWidth(3);
		case 2:
			return CALXGrid::GetHeadColWidth(4) + CALXGrid::GetHeadColWidth(5);
		case 3:
			return CALXGrid::GetHeadColWidth(6) + CALXGrid::GetHeadColWidth(7);
		case 4:
			return CALXGrid::GetHeadColWidth(8) + CALXGrid::GetHeadColWidth(9);
		case 5:
			return CALXGrid::GetHeadColWidth(10) + CALXGrid::GetHeadColWidth(11);
		default:
			return CALXGrid::GetHeadColWidth(nCol);
		}
	}
	else
		return CALXGrid::GetHeadColWidth(nCol);
}

int CGridView::GetHeadColCount(int nHeadRow)
{
	if(nHeadRow >= 0 && nHeadRow == GetHeadRowCount()-2)
		return 6;
	else
		return CALXGrid::GetHeadColCount();
}

HEADCELL_INFO CGridView::GetHeadCellInfo(int nCol, int nRow)
{
	HEADCELL_INFO HeadCellInfo;
	if(nRow >= 0 && nRow == GetHeadRowCount()-2)
	{
		switch(nCol)
		{
		case 0:
			{
				HeadCellInfo.m_strText = "Text";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		case 1:
			{
				HeadCellInfo.m_strText = "Bitmap";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		case 2:
			{
				HeadCellInfo.m_strText = "CheckBox";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		case 3:
			{
				HeadCellInfo.m_strText = "CheckBox && Text";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		case 4:
			{
				HeadCellInfo.m_strText = "DropDownComboBox";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		case 5:
			{
				HeadCellInfo.m_strText = "ListComboBox";
				HeadCellInfo.m_nFormat = AHFF_CENTER;
				break;
			}
		default:
			return CALXGrid::GetHeadCellInfo(nCol, nRow);
		}
		return HeadCellInfo;
	}
	else
		return CALXGrid::GetHeadCellInfo(nCol, nRow);
}

void CGridView::SetHeadColWidth(int nCol, int nRow, int nNewWidth)
{
	if(nRow >= 0 && nRow == GetHeadRowCount()-2)
	{
		switch(nCol)
		{
		case 0:
			{
				CALXGrid::SetHeadColWidth( 0, nRow, nNewWidth/3);
				CALXGrid::SetHeadColWidth( 1, nRow, nNewWidth/3);
				CALXGrid::SetHeadColWidth( 2, nRow, nNewWidth/3);
				break;
			}
		case 1:
			{
				CALXGrid::SetHeadColWidth( 3, nRow, nNewWidth);
				break;
			}
		case 2:
			{
				CALXGrid::SetHeadColWidth( 4, nRow, nNewWidth/2);
				CALXGrid::SetHeadColWidth( 5, nRow, nNewWidth/2);
				break;
			}
		case 3:
			{
				CALXGrid::SetHeadColWidth( 6, nRow, nNewWidth/2);
				CALXGrid::SetHeadColWidth( 7, nRow, nNewWidth/2);
				break;
			}
		case 4:
			{
				CALXGrid::SetHeadColWidth( 8, nRow, nNewWidth/2);
				CALXGrid::SetHeadColWidth( 9, nRow, nNewWidth/2);
				break;
			}
		case 5:
			{
				CALXGrid::SetHeadColWidth( 10, nRow, nNewWidth/2);
				CALXGrid::SetHeadColWidth( 11, nRow, nNewWidth/2);
				break;
			}
		}
	}
	else
		CALXGrid::SetHeadColWidth( nCol, nRow, nNewWidth);
}


void CGridView::OnGStyleNoGridLines() 
{
	if(GetStyle() & AGS_NOGRIDLINES)
		ModifyStyle(AGS_NOGRIDLINES,0);
	else
		ModifyStyle(0,AGS_NOGRIDLINES);
	Invalidate();
}

void CGridView::OnUpdateGStyleNoGridLines(CCmdUI* pCmdUI) 
{
	if(GetStyle() & AGS_NOGRIDLINES)
		pCmdUI->SetCheck(1);
	else
		pCmdUI->SetCheck(0);
}
