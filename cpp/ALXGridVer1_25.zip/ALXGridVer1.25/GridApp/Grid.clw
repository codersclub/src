; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CAboutDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "grid.h"
LastPage=0

ClassCount=9
Class1=CChildFrame
Class2=CGridApp
Class3=CAboutDlg
Class4=CGridDoc
Class5=CGridView
Class6=CMainFrame
Class7=CSetCountDlg
Class8=CSetHeightDlg
Class9=CSetWidthDlg

ResourceCount=6
Resource1=IDD_ABOUTBOX (English (U.S.))
Resource2=IDR_GRIDTYPE (English (U.S.))
Resource3=IDD_DIALOG_SETHEIGHT (English (U.S.))
Resource4=IDR_MAINFRAME (English (U.S.))
Resource5=IDD_DIALOG_SETCOUNT (English (U.S.))
Resource6=IDD_DIALOG_SETWIDTH (English (U.S.))

[CLS:CChildFrame]
Type=0
BaseClass=CMDIChildWnd
HeaderFile=ChildFrm.h
ImplementationFile=ChildFrm.cpp

[CLS:CGridApp]
Type=0
BaseClass=CWinApp
HeaderFile=Grid.h
ImplementationFile=Grid.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=Grid.cpp
ImplementationFile=Grid.cpp
LastObject=CAboutDlg

[CLS:CGridDoc]
Type=0
BaseClass=CDocument
HeaderFile=GridDoc.h
ImplementationFile=GridDoc.cpp

[CLS:CGridView]
Type=0
BaseClass=CALXGridView
HeaderFile=GridView.h
ImplementationFile=GridView.cpp

[CLS:CMainFrame]
Type=0
BaseClass=CMDIFrameWnd
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp

[CLS:CSetCountDlg]
Type=0
BaseClass=CDialog
HeaderFile=SetCountDlg.h
ImplementationFile=SetCountDlg.cpp

[CLS:CSetHeightDlg]
Type=0
BaseClass=CDialog
HeaderFile=SetHeightDlg.h
ImplementationFile=SetHeightDlg.cpp

[CLS:CSetWidthDlg]
Type=0
BaseClass=CDialog
HeaderFile=SetWidthDlg.h
ImplementationFile=SetWidthDlg.cpp

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_DIALOG_SETCOUNT]
Type=1
Class=CSetCountDlg

[DLG:IDD_DIALOG_SETHEIGHT]
Type=1
Class=CSetHeightDlg

[DLG:IDD_DIALOG_SETWIDTH]
Type=1
Class=CSetWidthDlg

[TB:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_EDITROW_ADD
Command8=ID_EDITROW_INS
Command9=ID_EDITROW_DEL
Command10=ID_FILE_PRINT
Command11=ID_APP_ABOUT
CommandCount=11

[MNU:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_VIEW_TOOLBAR
Command7=ID_VIEW_STATUS_BAR
Command8=ID_APP_ABOUT
CommandCount=8

[MNU:IDR_GRIDTYPE (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_CLOSE
Command4=ID_FILE_SAVE
Command5=ID_FILE_SAVE_AS
Command6=ID_FILE_PRINT
Command7=ID_FILE_PRINT_PREVIEW
Command8=ID_FILE_PRINT_SETUP
Command9=ID_FILE_MRU_FILE1
Command10=ID_APP_EXIT
Command11=ID_EDIT_UNDO
Command12=ID_EDIT_CUT
Command13=ID_EDIT_COPY
Command14=ID_EDIT_PASTE
Command15=ID_EDITROW_ADD
Command16=ID_EDITROW_INS
Command17=ID_EDITROW_DEL
Command18=ID_VIEW_TOOLBAR
Command19=ID_VIEW_STATUS_BAR
Command20=ID_GVIEW_GRIDFONT
Command21=ID_GVIEW_HEADFONT
Command22=ID_GVIEW_HEADROW
Command23=ID_GVIEW_FROZENCOL
Command24=ID_GVIEW_HEADHEIGHT
Command25=ID_GVIEW_FROZENWIDTH
Command26=ID_GSTYLE_ROWSELECT
Command27=ID_GSTYLE_FLAT
Command28=ID_GSTYLE_NOGRIDLINES
Command29=ID_WINDOW_NEW
Command30=ID_WINDOW_CASCADE
Command31=ID_WINDOW_TILE_HORZ
Command32=ID_WINDOW_ARRANGE
Command33=ID_APP_ABOUT
CommandCount=33

[ACL:IDR_MAINFRAME (English (U.S.))]
Type=1
Class=?
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=5
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308993
Control3=IDC_STATIC,static,1342308353
Control4=IDOK,button,1342373889
Control5=IDC_STATIC,button,1342177287

[DLG:IDD_DIALOG_SETCOUNT (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDC_EDIT_COUNT,edit,1350631552
Control2=IDOK,button,1342242817
Control3=IDCANCEL,button,1342242816

[DLG:IDD_DIALOG_SETHEIGHT (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDC_EDIT_HEIGHT,edit,1350631552
Control2=IDOK,button,1342242817
Control3=IDCANCEL,button,1342242816

[DLG:IDD_DIALOG_SETWIDTH (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDC_EDIT_WIDTH,edit,1350631552
Control2=IDOK,button,1342242817
Control3=IDCANCEL,button,1342242816

