#include <windows.h>
#include <gl/gl.h>
#include <gl/glu.h>

GLUquadricObj *MySphere;

LRESULT CALLBACK 
WndProc( HWND hWnd, UINT message,
WPARAM wParam, LPARAM lParam );
VOID EnableOpenGL( HWND hWnd, HDC * hDC, HGLRC * hRC );
VOID DisableOpenGL( HWND hWnd, HDC hDC, HGLRC hRC );

int WINAPI 
WinMain( HINSTANCE hInstance,
HINSTANCE hPrevInstance,
LPSTR lpCmdLine,
int iCmdShow )
{
WNDCLASS wc;
HWND hWnd;
HDC hDC;
HGLRC hRC;
MSG msg;
BOOL bQuit = FALSE;
float theta = 0.8f;
float theta2 = 0.8f;
float numx = 0, numy = 0;
unsigned i = 0, count = 0;

wc.style = CS_OWNDC;
wc.lpfnWndProc = WndProc;
wc.cbClsExtra = 0;
wc.cbWndExtra = 0;
wc.hInstance = hInstance;
wc.hIcon = LoadIcon( hInstance, MAKEINTRESOURCE(500) );
wc.hCursor = LoadCursor( NULL, IDC_ARROW );
wc.hbrBackground = (HBRUSH)GetStockObject( BLACK_BRUSH );
wc.lpszMenuName = NULL;
wc.lpszClassName = "Demo-scene. andrushock@pisem.net";
RegisterClass( &wc );

hWnd = CreateWindow( 
"Demo-scene. andrushock@pisem.net", "Demo-scene. andrushock@pisem.net",
WS_CAPTION | WS_POPUPWINDOW | WS_VISIBLE,
262, 162, 266, 266,
NULL, NULL, hInstance, NULL );

EnableOpenGL( hWnd, &hDC, &hRC );

while ( !bQuit ) {

if ( PeekMessage( &msg, NULL, 0, 0, PM_REMOVE ) ) {

if ( msg.message == WM_QUIT ) {
bQuit = TRUE;
} else {
TranslateMessage( &msg );
DispatchMessage( &msg );
}

} else {

glClearColor( 0.0f, 0.0f, 0.0f, 0.0f );
glShadeModel(GL_SMOOTH);
glClear( GL_COLOR_BUFFER_BIT);

glPushAttrib (GL_FOG_BIT);
glEnable(GL_FOG);
glFogf (GL_FOG_MODE, GL_EXP);
glFogf (GL_FOG_INDEX, 1.0f);
glFogf (GL_FOG_COLOR, 1.0f);
glFogf (GL_FOG_DENSITY, 1.0f);

    glNewList(1, GL_COMPILE);
    MySphere = gluNewQuadric();
    gluQuadricTexture(MySphere, GL_TRUE);
    gluQuadricDrawStyle(MySphere, GLU_LINE);
    gluQuadricNormals(MySphere, GLU_FLAT);
    gluSphere (MySphere, 0.9, 12, 12);
    glEndList();

    glPushMatrix();
    glColor3f(1.0f, 1.0f, 1.0f);
    glRotatef(theta, 1.0, 0.0, 0.0);
    glIndexi(16);
    glCallList(1);
    glPopMatrix();

glPushMatrix();
glRotatef( theta, 1.0f, 0.0f, 0.0f );
glBegin( GL_POINTS );
   for (float angle = -1.571; angle <= 4.721; angle = angle + 0.5243)
      {
       numx = cos(angle) / 1.5;
       numy = sin(angle) / 1.5;
       i++;
       glColor3f( 1.0f, 1.0f, 1.0f); glVertex2f( numx, numy );
       if (i == 12) break;
      }
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef( theta, 0.0f, 1.0f, 0.0f );
glBegin( GL_POINTS );
   for (float angle = -1.571; angle <= 4.721; angle = angle + 0.5243)
      {
       numx = cos(angle) / 1.5;
       numy = sin(angle) / 1.5;
       i++;
       glColor3f( 1.0f, 1.0f, 1.0f); glVertex2f( numx, numy );
       if (i == 12) break;
      }
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef( theta, 0.0f, 0.0f, 1.0f );
glBegin( GL_TRIANGLES );
glColor3f( 0.0f, 0.0f, 1.0f); glVertex2f( 0.0f, 0.0f );
glColor3f( 0.0f, 1.0f, 0.0f); glVertex2f( 0.5f, 0.0f );
glColor3f( 1.0f, 0.0f, 0.0f); glVertex2f( 0.0f, 0.5f );
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef( theta, 0.0f, 0.0f, 1.0f );
glBegin( GL_TRIANGLES );
glColor3f( 0.0f, 0.0f, 1.0f); glVertex2f( 0.0f, 0.0f );
glColor3f( 0.0f, 1.0f, 0.0f); glVertex2f( -0.5f, 0.0f );
glColor3f( 1.0f, 0.0f, 0.0f); glVertex2f( 0.0f, -0.5f );
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef( theta2, 0.0f, 0.0f, 2.0f );
glBegin( GL_TRIANGLES );
glColor3f( 0.0f, 0.0f, 1.0f); glVertex2f( 0.0f, 0.0f );
glColor3f( 0.0f, 1.0f, 0.0f); glVertex2f( 0.5f, 0.0f );
glColor3f( 1.0f, 0.0f, 0.0f); glVertex2f( 0.0f, 0.5f );
glEnd();
glPopMatrix();

glPushMatrix();
glRotatef( theta2, 0.0f, 0.0f, 2.0f );
glBegin( GL_TRIANGLES );
glColor3f( 0.0f, 0.0f, 1.0f); glVertex2f( 0.0f, 0.0f );
glColor3f( 0.0f, 1.0f, 0.0f); glVertex2f( -0.5f, 0.0f );
glColor3f( 1.0f, 0.0f, 0.0f); glVertex2f( 0.0f, -0.5f );
glEnd();
glPopMatrix();

glDisable(GL_FOG);
glPopAttrib ();

SwapBuffers( hDC );

theta += 0.3;
theta2 -= 0.3;

}

}

DisableOpenGL( hWnd, hDC, hRC );

DestroyWindow( hWnd );

return msg.wParam;

}

LRESULT CALLBACK 
WndProc( HWND hWnd, UINT message,
WPARAM wParam, LPARAM lParam )
{

switch ( message ) {

case WM_CREATE:
return 0;

case WM_CLOSE:
PostQuitMessage( 0 );
return 0;

case WM_DESTROY:
return 0;

case WM_KEYDOWN:
switch ( wParam ) {

case VK_ESCAPE:
PostQuitMessage( 0 );
return 0;

}
return 0;

default:
return DefWindowProc( hWnd, 
message, wParam, lParam );

}

}

VOID EnableOpenGL( HWND hWnd, HDC * hDC, HGLRC * hRC )
{
PIXELFORMATDESCRIPTOR pfd;
int iFormat;

*hDC = GetDC( hWnd );

ZeroMemory( &pfd, sizeof( pfd ) );
pfd.nSize = sizeof( pfd );
pfd.nVersion = 1;
pfd.dwFlags = PFD_DRAW_TO_WINDOW | 
PFD_SUPPORT_OPENGL | PFD_DOUBLEBUFFER;
pfd.iPixelType = PFD_TYPE_RGBA;
pfd.cColorBits = 24;
pfd.cDepthBits = 16;
pfd.iLayerType = PFD_MAIN_PLANE;
iFormat = ChoosePixelFormat( *hDC, &pfd );
SetPixelFormat( *hDC, iFormat, &pfd );

*hRC = wglCreateContext( *hDC );
wglMakeCurrent( *hDC, *hRC );

}

VOID DisableOpenGL( HWND hWnd, HDC hDC, HGLRC hRC )
{
wglMakeCurrent( NULL, NULL );
wglDeleteContext( hRC );
ReleaseDC( hWnd, hDC );
} 
