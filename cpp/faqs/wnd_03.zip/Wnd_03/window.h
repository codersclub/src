// window.h: interface for the CWindow class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(__WINDOW_H__)
#define __WINDOW_H__

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

HINSTANCE GetAppInstance();
HINSTANCE SetAppInstance(HINSTANCE hInstance);

class CWindow;

#pragma pack(push, __before)
#pragma pack(1)
typedef LRESULT (CWindow::*WNDMETHOD) (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
typedef struct HWndCall
{
	BYTE		__mov_ecx_01;
	CWindow*	__wnd_01;
	BYTE		__push_op [16];
	BYTE		__call_method;
	DWORD		__method;
	BYTE		__ret [3];
} *LWndCall;

typedef struct _MSG
{
	HWND hWnd;
	UINT message;
	WPARAM wParam;
	LPARAM lParam;
} *_LPMSG, *_PMSG;
#pragma pack(pop, __before)

class CWindow  
{
public:
	CWindow();
	virtual ~CWindow();

public:
	HWND	virtual CreateWindowEx (DWORD dwExStyle, LPCSTR lpClassName, LPCSTR lpWindowName, DWORD dwStyle,
									RECT rect, CWindow* pParentWnd, HMENU hMenu, LPVOID lpParam);

	HWND			GetSafeHWnd();
protected:
	WNDPROC			m_fDefProc;
	HWND			m_hWnd;

	HWndCall		m_fWndCall;
	_PMSG			m_pMsg;
	HHOOK			m_hCbtHook;

public:
	LRESULT virtual WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT	virtual DefWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);
	LRESULT	virtual Default();

protected:
	LRESULT virtual StartupProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam);

	void			HookWndCreate(WNDMETHOD pHookMethod);
	BOOL			UnHookWndCreate();
	LRESULT			CbtHook(int code, WPARAM wParam, LPARAM lParam);

	void			SetCallProc(WNDMETHOD pMethod, char* pCall);
};

#endif // !defined(__WINDOW_H__)
