// window.cpp: implementation of the CWindow class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "window.h"

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

HINSTANCE hAppInstance = NULL;
HINSTANCE GetAppInstance() { return hAppInstance; }
HINSTANCE SetAppInstance(HINSTANCE hInstance) 
{
	HINSTANCE hTmp = hAppInstance;
	hAppInstance = hInstance;
	return hTmp;
}

CWindow::CWindow()
{
	m_fDefProc	= NULL;
	m_hWnd		= NULL;

	memset(&m_fWndCall, 0, sizeof(HWndCall));
	m_pMsg		= NULL;
	m_hCbtHook	= NULL;
}

CWindow::~CWindow()
{

}

char* pHookProc = "\xB9\x00\x00\x00\x00\x90\x90\x90\x90\xFF\x74\x24\x0C\xFF\x74\x24\x0C\xFF\x74\x24\x0C\xE8\x00\x00\x00\x00\xC2\x0C\x00";
/*
__asm
{
	mov ecx, this
	nop
	nop
	nop
	push [esp + 0Ch]
	push [esp + 0Ch]
	push [esp + 0Ch]
	call CbtProc
	ret 0Ch
}
//*/

char* pStartProc = "\xB9\x00\x00\x00\x00\xFF\x74\x24\x10\xFF\x74\x24\x10\xFF\x74\x24\x10\xFF\x74\x24\x10\xE8\x00\x00\x00\x00\xC2\x0C\x00";
/*
__asm
{
	mov ecx, this
	push [esp + 10h]
	push [esp + 10h]
	push [esp + 10h]
	push [esp + 10h]
	call StartupProc
	ret 0Ch
}*/

char* pWndProc = "\xB9\x00\x00\x00\x00\xFF\x74\x24\x10\xFF\x74\x24\x10\xFF\x74\x24\x10\xFF\x74\x24\x10\xE8\x00\x00\x00\x00\xC2\x10\x00";
/*
__asm
{
	mov ecx, this
	push [esp + 10h]
	push [esp + 10h]
	push [esp + 10h]
	push [esp + 10h]
	call WndProc
	ret 10h
}*/

#pragma warning(disable : 4035)
inline DWORD GetMethodAddress(WNDMETHOD pMethod) 
{
	__asm mov eax, pMethod;
}
#pragma warning(default : 4035)

HWND CWindow::CreateWindowEx(DWORD dwExStyle, LPCSTR lpClassName, LPCSTR lpWindowName, DWORD dwStyle, RECT rect, CWindow* pParentWnd, HMENU hMenu, LPVOID lpParam)
{
	if(m_hWnd != NULL) return NULL;

	HINSTANCE hInstance = GetAppInstance();

	HookWndCreate((WNDMETHOD)CbtHook);

	HWND hWnd = ::CreateWindow (lpClassName, lpWindowName, dwStyle, 
								rect.left, rect.top,
								rect.right - rect.left, rect.bottom - rect.top,
								pParentWnd->GetSafeHWnd(), hMenu, 
								GetAppInstance(), lpParam);

	if(hWnd != m_hWnd)
	{
		return NULL;
	}

	if(!UnHookWndCreate())
	{
		return NULL;
	}

	return m_hWnd;
}

LRESULT CWindow::StartupProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	SetCallProc(WndProc, pWndProc);
	return WndProc(hWnd, message, wParam, lParam);
}

LRESULT CWindow::WndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPVOID _pMsg = &m_pMsg;
	LPVOID pMsg	 = m_pMsg;

	__asm push pMsg
	m_pMsg = (_PMSG)&hWnd;

	LRESULT lResult = DefWndProc(hWnd, message, wParam, lParam);

	__asm
	{
		mov edx, _pMsg
		pop dword ptr [edx]
	}

	return lResult;
}

HWND CWindow::GetSafeHWnd() { if(this != NULL) return m_hWnd; else return NULL; }

LRESULT CWindow::DefWndProc(HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	return m_fDefProc(hWnd, message, wParam, lParam);
}

LRESULT CWindow::Default()
{
	return DefWndProc(m_pMsg->hWnd, m_pMsg->message, m_pMsg->wParam, m_pMsg->lParam);
}

LRESULT CWindow::CbtHook(int code, WPARAM wParam, LPARAM lParam)
{
	if (code != HCBT_CREATEWND)
	{
		// wait for HCBT_CREATEWND just pass others on...
		return CallNextHookEx(m_hCbtHook, code, wParam, lParam);
	}

	m_hWnd = (HWND)wParam;

	m_fDefProc = (WNDPROC)GetWindowLong(m_hWnd, GWL_WNDPROC);
	if(m_fDefProc == NULL) return ::CallNextHookEx(m_hCbtHook, code, wParam, lParam);;

	SetCallProc(StartupProc, pStartProc);

	SetWindowLong(m_hWnd, GWL_WNDPROC, (LONG)&m_fWndCall);

	return ::CallNextHookEx(m_hCbtHook, code, wParam, lParam);
}

void CWindow::HookWndCreate(WNDMETHOD pHookMethod)
{
	if(m_hCbtHook == NULL)
	{
		SetCallProc((WNDMETHOD)pHookMethod, pHookProc);
		m_hCbtHook = ::SetWindowsHookEx(WH_CBT, (HOOKPROC)&m_fWndCall, NULL, ::GetCurrentThreadId());
	}
}

BOOL CWindow::UnHookWndCreate()
{
	BOOL bResult = FALSE;
	if(m_hCbtHook != NULL) bResult = ::UnhookWindowsHookEx(m_hCbtHook);
	if(bResult) m_hCbtHook = NULL;
	return bResult;
}

void CWindow::SetCallProc(WNDMETHOD pMethod, char* pCall)
{
	memcpy(&m_fWndCall, pCall, sizeof(HWndCall));
	m_fWndCall.__wnd_01	= this;
	m_fWndCall.__method = GetMethodAddress(pMethod) - (DWORD)&m_fWndCall.__ret;
}

