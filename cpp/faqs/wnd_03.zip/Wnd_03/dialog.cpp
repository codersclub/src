
#include <windows.h>
#include "dialog.h"

CDialog::CDialog()
{
}

CDialog::~CDialog()
{
}

LRESULT CALLBACK About(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

void CDialog::DoModal(LPCTSTR lpTemplate)
{
	if(m_hWnd != NULL) return;

	HINSTANCE hInstance = GetAppInstance();

	HookWndCreate((WNDMETHOD)DlgInit);
	DialogBox(hInstance, lpTemplate, NULL, (DLGPROC)&m_fWndCall);
}

BOOL CDialog::Create(LPCTSTR lpTemplate, CWindow* pParentWnd, RECT rect)
{
	if(m_hWnd != NULL) return NULL;

	HINSTANCE hInstance = GetAppInstance();

	HookWndCreate((WNDMETHOD)DlgInit);

	HWND hWnd = CreateDialog(hInstance, lpTemplate, pParentWnd->GetSafeHWnd(), (DLGPROC)&m_fWndCall);
	if(hWnd != m_hWnd) return FALSE;

	SetWindowLong(m_hWnd, GWL_STYLE, GetWindowLong(m_hWnd, GWL_STYLE) | WS_VISIBLE);
	SetWindowPos(m_hWnd, NULL, rect.left, rect.top, rect.right - rect.left, rect.bottom - rect.top, 0);

	if(m_hWnd) return TRUE;
	else return FALSE;
}

LRESULT CDialog::WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam)
{
	LPVOID _pMsg = &m_pMsg;
	LPVOID pMsg	 = m_pMsg;

	__asm push pMsg
	m_pMsg = (_PMSG)&hDlg;

	LRESULT lResult = FALSE;
	switch(message)
	{
		case WM_INITDIALOG:
			lResult = TRUE;
			break;

		case WM_COMMAND:
			if (LOWORD(wParam) == IDOK || LOWORD(wParam) == IDCANCEL) 
			{
				EndDialog(hDlg, LOWORD(wParam));
				lResult = TRUE;
			}
			break;

		default:
			break;
	}

	__asm
	{
		mov edx, _pMsg
		pop dword ptr [edx]
	}

	return lResult;
}

extern char* pStartProc;

LRESULT CDialog::DlgInit(int code, WPARAM wParam, LPARAM lParam)
{
	if (code != HCBT_CREATEWND)
	{
		// wait for HCBT_CREATEWND just pass others on...
		return CallNextHookEx(m_hCbtHook, code, wParam, lParam);
	}

	if(!m_hWnd)
	{
		m_hWnd = (HWND)wParam;
		SetCallProc(StartupProc, pStartProc);
		UnHookWndCreate();
	}

	return ::CallNextHookEx(m_hCbtHook, code, wParam, lParam);
}
