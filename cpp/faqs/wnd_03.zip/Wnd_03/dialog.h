
#if !defined (__DIALOG_H__)
#define __DIALOG_H__

#include "window.h"

class CDialog : public CWindow
{
public:
	CDialog();
	~CDialog();

public:
	virtual BOOL Create(LPCTSTR lpDTemplate, CWindow* pParentWnd, RECT rect);
	virtual void DoModal(LPCTSTR lpDTemplate);
	virtual LRESULT WndProc(HWND hDlg, UINT message, WPARAM wParam, LPARAM lParam);

protected:
	LRESULT	DlgInit(int code, WPARAM wParam, LPARAM lParam);
};

#endif
