// 3DSample
// Demonstrates a three dimensional cube with increasing effectiveness

#include <windows.h>	// Standard windows include
#include <gl\gl.h>		// OpenGL library
#include <gl\glaux.h>	// AUX library


// Keep track of effects step
int nStep = 0;


// Lighting data
GLfloat lightAmbient[] = { 0.2f, 0.2f, 0.2f, 1.0f };
GLfloat lightDiffuse[] = { 0.7f, 0.7f, 0.7f, 1.0f };
GLfloat lightSpecular[] = { 0.9f, 0.9f, 0.9f };
GLfloat materialColor[] = { 0.8f, 0.0f, 0.0f };
GLfloat lightpos[] = { -80.0f, 120.0f, 100.0f, 0.0f };
GLfloat ground[3][3] = { { 0.0f, -25.0f, 0.0f },
					  { 10.0f, -25.0f, 0.0f },
					  { 10.0f, -25.0f, -10.0f } };



// Reduces a normal vector specified as a set of three coordinates,
// to a unit normal vector of length one.
void ReduceToUnit(float vector[3])
	{
	float length;
	
	// Calculate the length of the vector		
	length = (float)sqrt((vector[0]*vector[0]) + 
						(vector[1]*vector[1]) +
						(vector[2]*vector[2]));

	// Keep the program from blowing up by providing an exceptable
	// value for vectors that may calculated too close to zero.
	if(length == 0.0f)
		length = 1.0f;

	// Dividing each element by the length will result in a
	// unit normal vector.
	vector[0] /= length;
	vector[1] /= length;
	vector[2] /= length;
	}


// Points p1, p2, & p3 specified in counter clock-wise order
void calcNormal(float v[3][3], float out[3])
	{
	float v1[3],v2[3];
	static const int x = 0;
	static const int y = 1;
	static const int z = 2;

	// Calculate two vectors from the three points
	v1[x] = v[0][x] - v[1][x];
	v1[y] = v[0][y] - v[1][y];
	v1[z] = v[0][z] - v[1][z];

	v2[x] = v[1][x] - v[2][x];
	v2[y] = v[1][y] - v[2][y];
	v2[z] = v[1][z] - v[2][z];

	// Take the cross product of the two vectors to get
	// the normal vector which will be stored in out
	out[x] = v1[y]*v2[z] - v1[z]*v2[y];
	out[y] = v1[z]*v2[x] - v1[x]*v2[z];
	out[z] = v1[x]*v2[y] - v1[y]*v2[x];

	// Normalize the vector (shorten length to one)
	ReduceToUnit(out);
	}


// Creates a shadow projection matrix out of the plane equation
// coefficients and the position of the light. The return value is stored
// in destMat[][]
void MakeShadowMatrix(GLfloat points[3][3], GLfloat lightPos[4], GLfloat destMat[4][4])
	{
	GLfloat planeCoeff[4];
	GLfloat dot;

	// Find the plane equation coefficients
	// Find the first three coefficients the same way we
	// find a normal.
	calcNormal(points,planeCoeff);

	// Find the last coefficient by back substitutions
	planeCoeff[3] = - (
		(planeCoeff[0]*points[2][0]) + (planeCoeff[1]*points[2][1]) +
		(planeCoeff[2]*points[2][2]));


	// Dot product of plane and light position
	dot = planeCoeff[0] * lightPos[0] +
			planeCoeff[1] * lightPos[1] +
			planeCoeff[2] * lightPos[2] +
			planeCoeff[3] * lightPos[3];

	// Now do the projection
	// First column
    destMat[0][0] = dot - lightPos[0] * planeCoeff[0];
    destMat[1][0] = 0.0f - lightPos[0] * planeCoeff[1];
    destMat[2][0] = 0.0f - lightPos[0] * planeCoeff[2];
    destMat[3][0] = 0.0f - lightPos[0] * planeCoeff[3];

	// Second column
	destMat[0][1] = 0.0f - lightPos[1] * planeCoeff[0];
	destMat[1][1] = dot - lightPos[1] * planeCoeff[1];
	destMat[2][1] = 0.0f - lightPos[1] * planeCoeff[2];
	destMat[3][1] = 0.0f - lightPos[1] * planeCoeff[3];

	// Third Column
	destMat[0][2] = 0.0f - lightPos[2] * planeCoeff[0];
	destMat[1][2] = 0.0f - lightPos[2] * planeCoeff[1];
	destMat[2][2] = dot - lightPos[2] * planeCoeff[2];
	destMat[3][2] = 0.0f - lightPos[2] * planeCoeff[3];

	// Fourth Column
	destMat[0][3] = 0.0f - lightPos[3] * planeCoeff[0];
	destMat[1][3] = 0.0f - lightPos[3] * planeCoeff[1];
	destMat[2][3] = 0.0f - lightPos[3] * planeCoeff[2];
	destMat[3][3] = dot - lightPos[3] * planeCoeff[3];
	}



// Called by AUX library to update window
void CALLBACK RenderScene(void)
	{
	GLfloat cubeXform[4][4];

	// Clear the window with current clearing color
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glShadeModel(GL_SMOOTH);

	glEnable(GL_NORMALIZE);

	glPushMatrix();

	// Draw plane that the cube rests on
	glDisable(GL_LIGHTING);
	glColor3f(0.0f, 0.0f, 0.90f); // Blue
	glBegin(GL_QUADS);
		glVertex3f(-100.0f, -25.3f, -100.0f);
		glVertex3f(-100.0f, -25.3f, 100.0f);		
		glVertex3f(100.0f,  -25.3f, 100.0f);
		glVertex3f(100.0f,  -25.3f, -100.0f);
	glEnd();


	// Set drawing color to Red
	glColor3f(1.0f, 0.0f, 0.0f);

	// Enable, disable lighting
	if(nStep > 2)
		{
		glEnable(GL_DEPTH_TEST);
		glDepthFunc(GL_LEQUAL);
		glEnable(GL_COLOR_MATERIAL);

		glLightfv(GL_LIGHT0, GL_AMBIENT, lightAmbient);
		glLightfv(GL_LIGHT0, GL_DIFFUSE, lightDiffuse);
		glLightfv(GL_LIGHT0, GL_SPECULAR, lightSpecular);
		glEnable(GL_LIGHTING);
		glEnable(GL_LIGHT0);
		glMaterialfv(GL_FRONT, GL_SPECULAR,lightSpecular);
		glMaterialfv(GL_FRONT, GL_AMBIENT_AND_DIFFUSE, materialColor);
		glMateriali(GL_FRONT, GL_SHININESS,128);
		}

	// Move the cube slightly forward and to the left
	glTranslatef(-10.0f, 0.0f, 10.0f);

	switch(nStep)
		{
		// Just draw the wire framed cube
		case 0:
			auxWireCube(50.0f);
			break;

		// Same wire cube with hidden line removal simulated
		case 1:
			// Front Face (before rotation)
			glBegin(GL_LINES);
				glVertex3f(25.0f,25.0f,25.0f);
				glVertex3f(25.0f,-25.0f,25.0f);
				
				glVertex3f(25.0f,-25.0f,25.0f);
				glVertex3f(-25.0f,-25.0f,25.0f);

				glVertex3f(-25.0f,-25.0f,25.0f);
				glVertex3f(-25.0f,25.0f,25.0f);

				glVertex3f(-25.0f,25.0f,25.0f);
				glVertex3f(25.0f,25.0f,25.0f);
			glEnd();

			// Top of cube
			glBegin(GL_LINES);
				// Front Face
				glVertex3f(25.0f,25.0f,25.0f);
				glVertex3f(25.0f,25.0f,-25.0f);
				
				glVertex3f(25.0f,25.0f,-25.0f);
				glVertex3f(-25.0f,25.0f,-25.0f);

				glVertex3f(-25.0f,25.0f,-25.0f);
				glVertex3f(-25.0f,25.0f,25.0f);

				glVertex3f(-25.0f,25.0f,25.0f);
				glVertex3f(25.0f,25.0f,25.0f);
			glEnd();

			// Last two segments for effect
			glBegin(GL_LINES);
				glVertex3f(25.0f,25.0f,-25.0f);
				glVertex3f(25.0f,-25.0f,-25.0f);

				glVertex3f(25.0f,-25.0f,-25.0f);
				glVertex3f(25.0f,-25.0f,25.0f);
			glEnd();
		
			break;

		// Uniform colored surface, looks 2D and goofey
		case 2:
			auxSolidCube(50.0f);
			break;

		case 3:
			auxSolidCube(50.0f);
			break;

		// Draw a shadow with some lighting
		case 4:
			glGetFloatv(GL_MODELVIEW_MATRIX, (GLfloat *) cubeXform);
			auxSolidCube(50.0f);
			glPopMatrix();

			// Disable lighting, we'll just draw the shadow as black
			glDisable(GL_LIGHTING);
			
			glPushMatrix();

			MakeShadowMatrix(ground, lightpos, cubeXform);
			glMultMatrixf((GLfloat *)cubeXform);
			
			glTranslatef(-10.0f, 0.0f, 10.0f);			
			
			// Set drawing color to Black
			glColor3f(0.0f, 0.0f, 0.0f);

			auxSolidCube(50.0f);

			break;
		}

	glPopMatrix();

	glFlush();
	auxSwapBuffers();
	}




// Called by AUX library when the window has changed size
void CALLBACK ChangeSize(GLsizei w, GLsizei h)
	{
	// Calculate new clipping volume
	GLfloat windowWidth;
	GLfloat windowHeight;

	// Prevent a divide by zero, when window is too short
	// (you cant make a window of zero width).
	if(h == 0)
		h = 1;

	// Keep the square square
	if (w <= h) 
		{
		windowHeight = 100.0f*h/w;
		windowWidth = 100.0f;
		}
    else 
		{
		windowWidth = 100.0f*w/h;
		windowHeight = 100.0f;
		}


	// Reset the coordinate system before modifying
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	
	// Set the viewport to be the entire window
    glViewport(0, 0, w, h);

	// Set the clipping volume
	glOrtho(-100.0f, windowWidth, -100.0f, windowHeight, -200.0f, 200.0f);

	glLightfv(GL_LIGHT0,GL_POSITION, lightpos);

	glRotatef(30.0f, 1.0f, 0.0f, 0.0f);
	glRotatef(330.0f, 0.0f, 1.0f, 0.0f);
	}



// Space bar pressed, cycle to next scene
void CALLBACK KeySpace(void)
	{
	nStep++;

	if(nStep > 4)
		nStep = 0;

	RenderScene();
	}


// Main body of program
void main(void)
	{
	MessageBeep(0);

	// AUX window setup and initialization
	auxInitDisplayMode(AUX_DOUBLE | AUX_RGBA);
	auxInitPosition(100,100,250,250);
	auxInitWindow("A 3D Cube, Press Space");

	// Set function to call when window is resized
	auxReshapeFunc(ChangeSize);

	// Set function to call when space bar is pressed
	auxKeyFunc(AUX_SPACE,KeySpace);

	// Start main loop
	auxMainLoop(RenderScene);
	}

