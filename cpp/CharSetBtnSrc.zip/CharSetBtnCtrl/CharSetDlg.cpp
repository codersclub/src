/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetDlg.cpp
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
//	CharSetDlg.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CharSetDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCharSetDlg dialog

CCharSetDlg::CCharSetDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CCharSetDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CCharSetDlg)
	m_bBold = FALSE;
	m_bItalic = FALSE;
	//}}AFX_DATA_INIT
	m_pParent=pParent;
	Create(CCharSetDlg::IDD, pParent);
}

void CCharSetDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CCharSetDlg)
	DDX_Control(pDX, IDC_CHECK_ITALIC, m_btnItalic);
	DDX_Control(pDX, IDC_CHECK_BOLD, m_btnBold);
	DDX_Control(pDX, IDC_COMBO_FONT, m_ComboFont);
    DDX_Control(pDX, IDC_CHARSETCTRL, m_CharSetCtrl);
	DDX_Check(pDX, IDC_CHECK_BOLD, m_bBold);
	DDX_Check(pDX, IDC_CHECK_ITALIC, m_bItalic);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CCharSetDlg, CDialog)
	//{{AFX_MSG_MAP(CCharSetDlg)
	ON_CBN_SELCHANGE(IDC_COMBO_FONT, OnSelchangeComboFont)
	ON_BN_CLICKED(IDC_CHECK_BOLD, OnCheckBold)
	ON_BN_CLICKED(IDC_CHECK_ITALIC, OnCheckItalic)
	//}}AFX_MSG_MAP
    ON_MESSAGE(CS_SELECTED, CharSetCtrlSelected)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCharSetDlg message handlers

WNDPROC CCharSetDlg::m_MFCWndProc = NULL;
CCharSetDlg* CCharSetDlg::m_pDialog = NULL;


BOOL CCharSetDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	m_ComboFont.FillFonts();
	m_ComboFont.SetUseFont(TRUE);
	m_ComboFont.SetCurSel(-1);

	// Change of the default window procedure
	WNDPROC temp = reinterpret_cast<WNDPROC>(
		::SetWindowLong(GetSafeHwnd(), 
					GWL_WNDPROC, 
					reinterpret_cast<long>(NewWndProc) ));
	if ( !m_MFCWndProc ) m_MFCWndProc = temp;
	m_pDialog = this;

	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CCharSetDlg::OnSelchangeComboFont() 
{
	CString strFaceName;
	m_ComboFont.GetWindowText(strFaceName);
	m_CharSetCtrl.SetFaceName(strFaceName);
}

void CCharSetDlg::OnCheckBold() 
{
	m_CharSetCtrl.SetBold(m_btnBold.GetCheck());
}

void CCharSetDlg::OnCheckItalic() 
{
	m_CharSetCtrl.SetItalic(m_btnItalic.GetCheck());
}

BOOL CCharSetDlg::PreTranslateMessage(MSG* pMsg) 
{
	// Different management of the WM_KEYDOWN msg when is pressed the ENTER button
	// (the default management closes the dialog) or the ESC (we want to close the
	// dialog)
	if ( pMsg->message == WM_KEYDOWN )
		switch ( (int)pMsg->wParam )
		{
			case VK_RETURN:
				m_pDialog->m_pParent->PostMessage( CS_SELECTED );
				return TRUE;
			case VK_ESCAPE:
				m_pDialog->m_pParent->PostMessage( CS_ABORTED );
				return TRUE;
		}
	
	return CDialog::PreTranslateMessage(pMsg);
}

void CCharSetDlg::OnClose() 
{
	m_pDialog->m_pParent->PostMessage( CS_ABORTED );
	CDialog::OnClose();
}

LRESULT CALLBACK CCharSetDlg::NewWndProc( HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	// The new window procedure manages only the dialog inactivate;
	// the other msg are managed by default window procedure
	if ( message == WM_ACTIVATE )
	{
		if ( wParam == 0 )
		{
			m_pDialog->m_pParent->PostMessage( CS_ABORTED );
			return FALSE;
		}

	}
	return ::CallWindowProc( m_MFCWndProc, hWnd, message, wParam, lParam );
}

LONG CCharSetDlg::CharSetCtrlSelected(WPARAM wParam , LPARAM lParam)
{
	m_pDialog->m_pParent->PostMessage(CS_SELECTED);
    return 0L;
}
