// CharSetBtnCtrl.h : main header file for the CHARSETBTNCTRL application
//

#if !defined(AFX_CHARSETBTNCTRL_H__1C1FE4A7_484E_11D5_AEA0_0000863B4654__INCLUDED_)
#define AFX_CHARSETBTNCTRL_H__1C1FE4A7_484E_11D5_AEA0_0000863B4654__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CCharSetBtnCtrlApp:
// See CharSetBtnCtrl.cpp for the implementation of this class
//

class CCharSetBtnCtrlApp : public CWinApp
{
public:
	CCharSetBtnCtrlApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharSetBtnCtrlApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CCharSetBtnCtrlApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHARSETBTNCTRL_H__1C1FE4A7_484E_11D5_AEA0_0000863B4654__INCLUDED_)
