/////////////////////////////////////////////////////////////////////////////
//  File:       CharPreviewWnd.h
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_CHARPREVIEWWND_H__INCLUDED_)
#define _CHARPREVIEWWND_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CCharPreviewWnd window

class CCharPreviewWnd : public CWnd
{
// Construction
public:
	CCharPreviewWnd();

// Attributes
public:
	CFont		m_Font;
	CString		m_strFaceName;
	CString		m_strOut;
	int			m_nFontHeight;

// Operations
public:
	BOOL Create(CWnd* pParent);
	void ShowTips(CPoint pt, 
				CString strFaceName, 
				int nWeight=FW_NORMAL,
				BOOL bItalic=FALSE,
				CString strOut="");

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharPreviewWnd)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCharPreviewWnd();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCharPreviewWnd)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnPaint();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(_CHARPREVIEWWND_H__INCLUDED_)
