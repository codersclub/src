/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetCtrl.cpp
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
//	CharSetCtrl.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "charsetbtn.h"
#include "charsetctrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define PERFORM_MOUSEMOVE

/////////////////////////////////////////////////////////////////////////////
// CCharSetCtrl

CCharSetCtrl::CCharSetCtrl()
{
    RegisterWindowClass();

	m_nRows=8;
	m_nCols=28;

	m_crLine=::GetSysColor(COLOR_GRAYTEXT);

	m_crText=::GetSysColor(COLOR_WINDOWTEXT);
	m_crBkg=::GetSysColor(COLOR_WINDOW);
	
	m_crHiliteText=RGB(0,0,255);
	m_crHiliteBkg=::GetSysColor(COLOR_BTNFACE);

	m_nHiliteCol=-1;
	m_nHiliteRow=-1;

	m_strFaceName="Arial";
	m_bBold=FALSE;
	m_bItalic=FALSE;

	m_nSelect=-1;
	m_nStart=32;

	m_wndPreview.Create(this);
}

CCharSetCtrl::~CCharSetCtrl()
{
}

// Register the window class if it has not already been registered.
BOOL CCharSetCtrl::RegisterWindowClass()
{
    WNDCLASS wndcls;
    HINSTANCE hInst = AfxGetInstanceHandle();

    if (!(::GetClassInfo(hInst, CHARSETCTRL_CLASSNAME, &wndcls)))
    {
        // otherwise we need to register a new class
        wndcls.style            = CS_DBLCLKS | CS_HREDRAW | CS_VREDRAW;
        wndcls.lpfnWndProc      = ::DefWindowProc;
        wndcls.cbClsExtra       = wndcls.cbWndExtra = 0;
        wndcls.hInstance        = hInst;
        wndcls.hIcon            = NULL;
        wndcls.hCursor          = AfxGetApp()->LoadStandardCursor(IDC_ARROW);
        wndcls.hbrBackground    = (HBRUSH) (COLOR_3DFACE + 1);
        wndcls.lpszMenuName     = NULL;
        wndcls.lpszClassName    = CHARSETCTRL_CLASSNAME;

        if (!AfxRegisterClass(&wndcls))
        {
            AfxThrowResourceException();
            return FALSE;
        }
    }

    return TRUE;
}

BEGIN_MESSAGE_MAP(CCharSetCtrl, CWnd)
	//{{AFX_MSG_MAP(CCharSetCtrl)
	ON_WM_PAINT()
	ON_WM_ERASEBKGND()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_WM_KEYDOWN()
	ON_WM_LBUTTONDBLCLK()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCharSetCtrl message handlers

void CCharSetCtrl::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	int i, j;

	CPen linePen(PS_SOLID, 1, m_crLine);
	CPen textPen(PS_SOLID, 1, m_crText);
	CFont ctrlFont;

	GetClientRect(m_Rect);

	dc.FillSolidRect(m_Rect, GetSysColor(COLOR_BTNFACE));
	
	CPen* pOldPen=dc.SelectObject(&linePen);
	
	m_nRangeCol=m_Rect.Width();
	m_nStepCol=m_nRangeCol/(m_nCols);
	m_nRangeRow=m_Rect.Height();
	m_nStepRow=m_nRangeRow/(m_nRows);
	
	//dc.DrawEdge(m_Rect, EDGE_RAISED, BF_RECT);

	m_Rect.right=m_Rect.left+m_nCols*m_nStepCol;
	m_Rect.bottom=m_Rect.top+m_nRows*m_nStepRow;

	for (i=0; i<=m_nCols; i++)
	{
		dc.MoveTo(m_Rect.left + i*m_nStepCol, m_Rect.top);
		dc.LineTo(m_Rect.left + i*m_nStepCol, m_Rect.Height());
	}
	for (j=0; j<=m_nRows; j++)
	{
		dc.MoveTo(m_Rect.left, m_Rect.top + j*m_nStepRow);
		dc.LineTo(m_Rect.Width()+1, m_Rect.top + j*m_nStepRow);
	}

	dc.SelectObject(pOldPen);
	
	ctrlFont.CreateFont
	(
		min(m_nStepCol, m_nStepRow),
		0,
		0,
		0,
		m_bBold ? FW_BOLD : FW_NORMAL,
		m_bItalic,
		0,
		0,
		DEFAULT_CHARSET,
		OUT_CHARACTER_PRECIS,
		CLIP_CHARACTER_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE,
		m_strFaceName
	);

	CFont* pOldFont=dc.SelectObject(&ctrlFont);
	dc.SetTextColor(m_crText);
	dc.SetBkColor(m_crBkg);
	
	for (i=0; i<m_nRows; i++)
	{
		for (j=0; j<m_nCols; j++)
		{
			DrawCell(&dc, i, j);
		}
	}

	dc.SelectObject(pOldFont);
	ctrlFont.DeleteObject();
	linePen.DeleteObject();
	textPen.DeleteObject();

	// Do not call CWnd::OnPaint() for painting messages
}

BOOL CCharSetCtrl::OnEraseBkgnd(CDC* pDC) 
{
	return CWnd::OnEraseBkgnd(pDC);
}

void CCharSetCtrl::PreSubclassWindow() 
{
	// TODO: Add your specialized code here and/or call the base class
	// In our case this is not needed - yet - so just drop through to
    // the base class
	CWnd::PreSubclassWindow();
}

/////////////////////////////////////////////////////////////////////////////
// CCharSetCtrl methods

BOOL CCharSetCtrl::Create(CWnd* pParentWnd, const RECT& rect, UINT nID, DWORD dwStyle /*=WS_VISIBLE*/)
{
	return CWnd::Create(CHARSETCTRL_CLASSNAME, _T(""), dwStyle, rect, pParentWnd, nID);
}

void CCharSetCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	CWnd::OnMouseMove(nFlags, point);

#ifdef PERFORM_MOUSEMOVE
	if(m_Rect.PtInRect(point))
	{
		int nOldHiliteRow=m_nHiliteRow;
		int nOldHiliteCol=m_nHiliteCol;

		m_nHiliteCol = point.x/m_nStepCol;
		m_nHiliteRow = point.y/m_nStepRow;

		if(nOldHiliteCol!=m_nHiliteCol || nOldHiliteRow!=m_nHiliteRow)
		{
			CClientDC dc (this);
			CFont ctrlFont;
			ctrlFont.CreateFont
			(
				min(m_nStepCol, m_nStepRow),
				0,
				0,
				0,
				m_bBold ? FW_BOLD : FW_NORMAL,
				m_bItalic,
				0,
				0,
				DEFAULT_CHARSET,
				OUT_CHARACTER_PRECIS,
				CLIP_CHARACTER_PRECIS,
				DEFAULT_QUALITY,
				DEFAULT_PITCH | FF_DONTCARE,
				m_strFaceName
			);
			CFont* pOldFont=dc.SelectObject(&ctrlFont);
			
			DrawCell(&dc, nOldHiliteRow, nOldHiliteCol);
			DrawCell(&dc, m_nHiliteRow, m_nHiliteCol);
			
			dc.SelectObject(pOldFont);
			ctrlFont.DeleteObject();

			if(GetCapture()==this)
			{
				int nChar=m_nStart+m_nCols*m_nHiliteRow+m_nHiliteCol;
				CString strOut;
				strOut="0";
				strOut.SetAt(0, nChar);
				CPoint ptWndTip((m_nHiliteCol+1)*m_nStepCol, m_nHiliteRow*m_nStepRow);
				ClientToScreen(&ptWndTip);
				m_wndPreview.ShowTips(
					ptWndTip, 
					m_strFaceName, 
					m_bBold ? 700 : 400,
					m_bItalic,
					strOut);
			}
		}		
	}
#endif
}

void CCharSetCtrl::OnLButtonDown(UINT nFlags, CPoint point) 
{
	CWnd::OnLButtonDown(nFlags, point);
	
	SetActiveWindow();
	SetCapture();

	if(m_Rect.PtInRect(point))
	{
		int nTempCol = point.x/m_nStepCol;
		int nTempRow = point.y/m_nStepRow;

		int nChar=m_nStart+m_nCols*nTempRow+nTempCol;
		CString strOut;
		strOut="0";
		strOut.SetAt(0, nChar);
		CPoint ptWndTip((nTempCol+1)*m_nStepCol, nTempRow*m_nStepRow);
		ClientToScreen(&ptWndTip);
		m_wndPreview.ShowTips(
			ptWndTip, 
			m_strFaceName, 
			m_bBold ? 700 : 400,
			m_bItalic,
			strOut);
	}
}

void CCharSetCtrl::OnLButtonUp(UINT nFlags, CPoint point) 
{
	CWnd::OnLButtonUp(nFlags, point);
	m_wndPreview.ShowWindow(SW_HIDE);
	ReleaseCapture();

	if(m_Rect.PtInRect(point))
	{
		int nTempCol = point.x/m_nStepCol;
		int nTempRow = point.y/m_nStepRow;

		int nChar=m_nStart+m_nCols*nTempRow+nTempCol;

		SetSelection(nChar);
	}
}

void CCharSetCtrl::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	int nCol=(m_nSelect-m_nStart)%m_nCols;
	int nRow=(int)((m_nSelect-m_nStart)/m_nCols);

	if (nChar == VK_RIGHT)
	{
		if(++nCol >= m_nCols)
			nCol=0;
		SetSelection(nRow, nCol);
	}
	if (nChar == VK_DOWN)
	{
		if(++nRow >= m_nRows)
			nRow=0;
		SetSelection(nRow, nCol);
	}
	if (nChar == VK_LEFT)
	{
		if(--nCol < 0)
			nCol=m_nCols-1;
		SetSelection(nRow, nCol);
	}
	if (nChar == VK_UP)
	{
		if(--nRow < 0)
			nRow=m_nRows-1;
		SetSelection(nRow, nCol);
	}
	
	CWnd::OnKeyDown(nChar, nRepCnt, nFlags);
}

BOOL CCharSetCtrl::PreTranslateMessage(MSG* pMsg) 
{
	if ( pMsg->message == WM_KEYDOWN )
		switch ( (int)pMsg->wParam )
		{
			case VK_RIGHT:
			case VK_LEFT:
			case VK_UP:
			case VK_DOWN:
				// dipatch keyboard messages directly (skip main accelerators)
				::TranslateMessage(pMsg);
				::DispatchMessage(pMsg);
				return TRUE;
		}
	
	return CWnd::PreTranslateMessage(pMsg);
}

void CCharSetCtrl::DrawCell(CDC* pDC, int nRow, int nCol)
{
	CString strOut;
	strOut="0";

	int nChar=m_nStart+m_nCols*nRow+nCol;
	strOut.SetAt(0, nChar);

	CRect rcHilite(m_Rect.left + nCol*m_nStepCol+1, 
				m_Rect.top + nRow*m_nStepRow+1, 
				m_Rect.left + (nCol+1)*m_nStepCol, 
				m_Rect.top + (nRow+1)*m_nStepRow);

	CRect rcText(m_Rect.left + nCol*m_nStepCol+2, 
				m_Rect.top + nRow*m_nStepRow+2, 
				m_Rect.left + (nCol+1)*m_nStepCol-1, 
				m_Rect.top + (nRow+1)*m_nStepRow-1);
	
	pDC->SetBkMode(TRANSPARENT);
	if(nChar==m_nSelect)
	{
		pDC->SetBkColor(::GetSysColor(COLOR_HIGHLIGHT));
		pDC->SetTextColor(::GetSysColor(COLOR_HIGHLIGHTTEXT));
		
		pDC->FillSolidRect(rcHilite, ::GetSysColor(COLOR_HIGHLIGHT));
		pDC->DrawFocusRect(rcHilite);
		pDC->DrawText(strOut, rcText, DT_CENTER | DT_VCENTER);
	}
	else if(nCol==m_nHiliteCol && nRow==m_nHiliteRow)
	{
		pDC->SetTextColor(m_crHiliteText);
		pDC->SetBkColor(m_crHiliteBkg);

		pDC->FillSolidRect(rcHilite, m_crHiliteBkg);
		pDC->DrawText(strOut, rcText, DT_CENTER | DT_VCENTER);
	}
	else
	{
		pDC->SetTextColor(m_crText);
		pDC->SetBkColor(m_crBkg);

		pDC->FillSolidRect(rcHilite, m_crBkg);
		pDC->DrawText(strOut, rcText, DT_CENTER | DT_VCENTER);
	}
}

void CCharSetCtrl::DrawCell(CDC* pDC, int nChar)
{
	int nCol=(nChar-m_nStart)%m_nCols;
	int nRow=(int)((nChar-m_nStart)/m_nCols);
	DrawCell(pDC, nRow, nCol);
}

void CCharSetCtrl::OnLButtonDblClk(UINT nFlags, CPoint point) 
{
	GetParent()->PostMessage(CS_SELECTED);
	CWnd::OnLButtonDblClk(nFlags, point);
}

//Setter and getter - methods
void CCharSetCtrl::SetSelection(int nRow, int nCol)
{
	int nChar=m_nStart+m_nCols*nRow+nCol;
	SetSelection(nChar);
}

void CCharSetCtrl::SetSelection(int nSelect)
{
	int nOldSelect=m_nSelect;
	m_nSelect=nSelect;

	CClientDC dc (this);
	CFont ctrlFont;
	ctrlFont.CreateFont
	(
		min(m_nStepCol, m_nStepRow),
		0,
		0,
		0,
		m_bBold ? FW_BOLD : FW_NORMAL,
		m_bItalic,
		0,
		0,
		DEFAULT_CHARSET,
		OUT_CHARACTER_PRECIS,
		CLIP_CHARACTER_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE,
		m_strFaceName
	);

	CFont* pOldFont=dc.SelectObject(&ctrlFont);
	
	if(nOldSelect!=-1)
		DrawCell(&dc, nOldSelect);
	if(m_nSelect!=-1)
		DrawCell(&dc, m_nSelect);

	dc.SelectObject(pOldFont);
	ctrlFont.DeleteObject();
}

void CCharSetCtrl::SetRows(int nRows)
{
	m_nRows=nRows;
	Invalidate();
}
void CCharSetCtrl::SetCols(int nCols)
{
	m_nCols=nCols;
	Invalidate();
}

void CCharSetCtrl::SetColorLine(COLORREF crLine)
{
	m_crLine=crLine;
	Invalidate();
}

void CCharSetCtrl::SetColorBkg(COLORREF crBkg)
{
	m_crBkg=crBkg;
	Invalidate();
}

void CCharSetCtrl::SetColorText(COLORREF crText)
{
	m_crText=crText;
	Invalidate();
}

void CCharSetCtrl::SetColorHiliteBkg(COLORREF crHiliteBkg)
{
	m_crHiliteBkg=crHiliteBkg;
	Invalidate();
}

void CCharSetCtrl::SetColorHiliteText(COLORREF crHiliteText)
{
	m_crHiliteText=crHiliteText;
	Invalidate();
}

void CCharSetCtrl::SetFaceName(CString strFaceName)
{
	m_strFaceName=strFaceName;
	Invalidate();
}

void CCharSetCtrl::SetBold(BOOL bBold)
{
	m_bBold=bBold;
	Invalidate();
}

void CCharSetCtrl::SetItalic(BOOL bItalic)
{
	m_bItalic=bItalic;
	Invalidate();
}

void CCharSetCtrl::SetStart(int nStart)
{
	m_nStart=nStart;
	Invalidate();
}

int CCharSetCtrl::GetRows()
{
	return m_nRows;
}

int CCharSetCtrl::GetCols()
{
	return m_nCols;
}

COLORREF CCharSetCtrl::GetColorLine()
{
	return m_crLine;
}

COLORREF CCharSetCtrl::GetColorBkg()
{
	return m_crBkg;
}

COLORREF CCharSetCtrl::GetColorText()
{
	return m_crText;
}

COLORREF CCharSetCtrl::GetColorHiliteBkg()
{
	return m_crHiliteBkg;
}

COLORREF CCharSetCtrl::GetColorHiliteText()
{
	return m_crHiliteText;
}

CString CCharSetCtrl::GetFaceName()
{
	return m_strFaceName;
}

BOOL CCharSetCtrl::GetBold()
{
	return m_bBold;
}

BOOL CCharSetCtrl::GetItalic()
{
	return m_bItalic;
}

int CCharSetCtrl::GetSelection()
{
	return m_nSelect;
}

int CCharSetCtrl::GetStart()
{
	return m_nStart;
}
