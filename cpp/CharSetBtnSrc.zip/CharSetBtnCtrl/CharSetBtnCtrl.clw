; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CCharSetDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "charsetbtnctrl.h"
LastPage=0

ClassCount=8
Class1=CCharPreviewWnd
Class2=CCharSetBtn
Class3=CCharSetBtnCtrlApp
Class4=CAboutDlg
Class5=CCharSetBtnCtrlDlg
Class6=CCharSetCtrl
Class7=CCharSetDlg
Class8=CFontCombo

ResourceCount=3
Resource1=IDD_CHARSETBTNCTRL_DIALOG (English (U.S.))
Resource2=IDD_ABOUTBOX (English (U.S.))
Resource3=IDD_CHARSET_DLG

[CLS:CCharPreviewWnd]
Type=0
BaseClass=CWnd
HeaderFile=CharPreviewWnd.h
ImplementationFile=CharPreviewWnd.cpp

[CLS:CCharSetBtn]
Type=0
BaseClass=CButton
HeaderFile=CharSetBtn.h
ImplementationFile=CharSetBtn.cpp

[CLS:CCharSetBtnCtrlApp]
Type=0
BaseClass=CWinApp
HeaderFile=CharSetBtnCtrl.h
ImplementationFile=CharSetBtnCtrl.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=CharSetBtnCtrlDlg.cpp
ImplementationFile=CharSetBtnCtrlDlg.cpp
LastObject=IDOK

[CLS:CCharSetBtnCtrlDlg]
Type=0
BaseClass=CDialog
HeaderFile=CharSetBtnCtrlDlg.h
ImplementationFile=CharSetBtnCtrlDlg.cpp
Filter=D
VirtualFilter=dWC

[CLS:CCharSetCtrl]
Type=0
BaseClass=CWnd
HeaderFile=CharSetCtrl.h
ImplementationFile=CharSetCtrl.cpp

[CLS:CCharSetDlg]
Type=0
BaseClass=CDialog
HeaderFile=CharSetDlg.h
ImplementationFile=CharSetDlg.cpp

[CLS:CFontCombo]
Type=0
BaseClass=CComboBox
HeaderFile=FontComboBox.h
ImplementationFile=FontComboBox.cpp

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_CHARSETBTNCTRL_DIALOG]
Type=1
Class=CCharSetBtnCtrlDlg

[DLG:IDD_CHARSET_DLG]
Type=1
Class=CCharSetDlg
ControlCount=6
Control1=IDC_COMBO_FONT,combobox,1344340771
Control2=IDC_CHARSETCTRL,MFCCharSetCtrl,1342242816
Control3=IDC_CHECK_BOLD,button,1342243075
Control4=IDC_CHECK_ITALIC,button,1342242819
Control5=IDC_STATIC,button,1342177287
Control6=IDC_STATIC,static,1342308352

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_CHARSETBTNCTRL_DIALOG (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_BUTTON1,button,1342242827

