/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetBtn.cpp
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
//	CharSetBtn.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "charsetbtn.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCharSetBtn

CCharSetBtn::CCharSetBtn()
{
	m_nChar=-1;
	m_strFaceName="Arial";
	m_bItalic=FALSE;
	m_bBold=FALSE;
	m_pCharSetDlg=NULL;
}

CCharSetBtn::~CCharSetBtn()
{
	if (m_pCharSetDlg)
	{
		m_pCharSetDlg->DestroyWindow();
		delete m_pCharSetDlg;
		m_pCharSetDlg=NULL;
	}

}

BEGIN_MESSAGE_MAP(CCharSetBtn, CButton)
	//{{AFX_MSG_MAP(CCharSetBtn)
	ON_CONTROL_REFLECT(BN_CLICKED, OnClicked)
	//}}AFX_MSG_MAP
    ON_MESSAGE(CS_SELECTED, CharSetCtrlSelected)
    ON_MESSAGE(CS_ABORTED, CharSetCtrlAborted)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCharSetBtn message handlers

void CCharSetBtn::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
    ASSERT(lpDrawItemStruct);

    CDC*    pDC     = CDC::FromHandle(lpDrawItemStruct->hDC);
    CRect   rect    = lpDrawItemStruct->rcItem;
    UINT    state   = lpDrawItemStruct->itemState;
    
    CRect   rArrow(rect);

	rArrow.left    = rArrow.right - ::GetSystemMetrics(SM_CXVSCROLL);

    CSize Margins(::GetSystemMetrics(SM_CXEDGE), ::GetSystemMetrics(SM_CYEDGE));

    pDC->DrawFrameControl(&rArrow, DFC_SCROLL, DFCS_SCROLLDOWN  |
                          ((state & ODS_SELECTED) ? DFCS_PUSHED : 0 ) |
                          ((state & ODS_DISABLED) ? DFCS_INACTIVE : 0));

    rect.right -= rArrow.Width();

    pDC->FillSolidRect(rect,::GetSysColor(COLOR_WINDOW));

    if  (state & ODS_DISABLED)
        pDC->SetTextColor(::GetSysColor(COLOR_GRAYTEXT));
    else
        pDC->SetTextColor(::GetSysColor(COLOR_WINDOWTEXT));

    CString strBtnText(" ");
	if(m_nChar==-1)
		strBtnText="";
	else
	{
		strBtnText.SetAt(0, m_nChar);
		CFont ctrlFont;
	
		ctrlFont.CreateFont
		(
			-13,
			0,
			0,
			0,
			m_bBold ? FW_BOLD : FW_NORMAL,
			m_bItalic,
			0,
			0,
			DEFAULT_CHARSET,
			OUT_CHARACTER_PRECIS,
			CLIP_CHARACTER_PRECIS,
			DEFAULT_QUALITY,
			DEFAULT_PITCH | FF_DONTCARE,
			m_strFaceName
		);

		CFont* pOldFont=pDC->SelectObject(&ctrlFont);
		
		pDC->DrawText(strBtnText, rect, DT_CENTER|DT_SINGLELINE|DT_VCENTER);

		pDC->SelectObject(pOldFont);
		ctrlFont.DeleteObject();
	}

	rect.DeflateRect(2,2);  
    if (state & ODS_FOCUS) 
		pDC->DrawFocusRect(rect);
    rect.InflateRect(2,2);
    pDC->DrawEdge(rect,EDGE_SUNKEN,BF_RECT);
}

void CCharSetBtn::PreSubclassWindow() 
{
	CButton::PreSubclassWindow();
}

void CCharSetBtn::OnClicked() 
{
    CRect rect;
    CRect childRect;
    GetWindowRect(rect);
    rect.OffsetRect(0,rect.Height());

	EnableWindow(FALSE);

	m_pCharSetDlg = new CCharSetDlg( this );
	
	m_pCharSetDlg->m_CharSetCtrl.SetSelection(m_nChar);

	m_pCharSetDlg->m_CharSetCtrl.SetFaceName(m_strFaceName);
	m_pCharSetDlg->m_ComboFont.SelectString(-1, m_strFaceName);

	m_pCharSetDlg->m_CharSetCtrl.SetBold(m_bBold);
	m_pCharSetDlg->m_btnBold.SetCheck(m_bBold);

	m_pCharSetDlg->m_btnItalic.SetCheck(m_bItalic);
	m_pCharSetDlg->m_CharSetCtrl.SetItalic(m_bItalic);

	m_pCharSetDlg->GetWindowRect(childRect);
	childRect.OffsetRect(0,rect.Height());

	m_pCharSetDlg->SetWindowPos(NULL,
		childRect.left, 	
		childRect.top, 	
		childRect.Width(), 	
		childRect.Height(), 	
		SWP_SHOWWINDOW|SWP_NOACTIVATE);

    return;
}

LONG CCharSetBtn::CharSetCtrlSelected(WPARAM wParam , LPARAM lParam)
{
	GetParent()->PostMessage(CS_SELECTED);
	EnableWindow(TRUE);
	if ( m_pCharSetDlg )
	{
		m_nChar=m_pCharSetDlg->m_CharSetCtrl.GetSelection();
		m_strFaceName=m_pCharSetDlg->m_CharSetCtrl.GetFaceName();
		m_bBold=m_pCharSetDlg->m_CharSetCtrl.GetBold();
		m_bItalic=m_pCharSetDlg->m_CharSetCtrl.GetItalic();
		
		m_pCharSetDlg->DestroyWindow();
		delete m_pCharSetDlg;
		m_pCharSetDlg = NULL;
	}
	Invalidate();
    return 0L;
}

LONG CCharSetBtn::CharSetCtrlAborted(WPARAM wParam , LPARAM lParam)
{
	GetParent()->PostMessage(CS_ABORTED);
    EnableWindow(TRUE);
	if ( m_pCharSetDlg )
	{
		m_pCharSetDlg->DestroyWindow();
		delete m_pCharSetDlg;
		m_pCharSetDlg = NULL;
	}

    return 0L;
}

