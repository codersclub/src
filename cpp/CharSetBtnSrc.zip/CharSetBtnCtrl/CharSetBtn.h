/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetBtn.h
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_CHARSETBTN_H__INCLUDED_)
#define _CHARSETBTN_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

/////////////////////////////////////////////////////////////////////////////
// CCharSetBtn 

#include "charsetdlg.h"
class CCharSetBtn : public CButton
{
// Construction
public:
	CCharSetBtn();

// Attributes
public:
	CCharSetDlg* m_pCharSetDlg;
	
	int m_nChar;
	CString m_strFaceName;
	BOOL m_bItalic;
	BOOL m_bBold;

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharSetBtn)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CCharSetBtn();

	// Generated message map functions
protected:
	//{{AFX_MSG(CCharSetBtn)
	afx_msg void OnClicked();
	//}}AFX_MSG
    afx_msg LONG CharSetCtrlSelected(WPARAM wParam = 0, LPARAM lParam = 0);
    afx_msg LONG CharSetCtrlAborted (WPARAM wParam = 0, LPARAM lParam = 0);

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif // !defined(_CHARSETBTN_H__INCLUDED_)
