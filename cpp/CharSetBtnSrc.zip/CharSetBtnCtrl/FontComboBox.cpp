/////////////////////////////////////////////////////////////////////////////
//  File:       FontComboBox.cpp
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
//	FontComboBox.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "resource.h"
#include "FontComboBox.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

#define WM_INITFONTS          (WM_USER + 53)
#define GLYPH_WIDTH 15

///////////////////////////////////////////////////////////////////////////
// CFontCombo

CFontCombo::CFontCombo()
{
	m_clrHilight = GetSysColor (COLOR_HIGHLIGHT);
	m_clrNormalText = GetSysColor (COLOR_WINDOWTEXT);
	m_clrHilightText = GetSysColor (COLOR_HIGHLIGHTTEXT);
	m_clrBkgnd = GetSysColor (COLOR_WINDOW);
	m_bInitOver = FALSE;
	m_bUseFont = FALSE;
	m_ImageList.Create(IDB_GLYPHS,GLYPH_WIDTH,1,RGB(255,0,255));
}

CFontCombo::~CFontCombo()
{
}

BEGIN_MESSAGE_MAP(CFontCombo, CComboBox)
	//{{AFX_MSG_MAP(CFontCombo)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_MESSAGE (WM_INITFONTS,OnInitFonts)
END_MESSAGE_MAP()

///////////////////////////////////////////////////////////////////////////
// CFontCombo message handlers

void CFontCombo::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct)
{
	DrawFont(lpDrawItemStruct);
}

//I dont need the MeasureItem to do anything. Whatever the system says, it stays
void CFontCombo::MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct)
{
}

void CFontCombo::DrawFont(LPDRAWITEMSTRUCT lpDIS)
{
	CDC* pDC = CDC::FromHandle(lpDIS->hDC);
	CRect rect;

	// draw the colored rectangle portion
	rect.CopyRect(&lpDIS->rcItem);

	pDC->SetBkMode( TRANSPARENT );

	if (lpDIS->itemState & ODS_SELECTED)
	{
		pDC->FillSolidRect (rect,m_clrHilight);
		pDC->SetTextColor (m_clrHilightText);
	}
	else
	{
		pDC->FillSolidRect (rect,m_clrBkgnd);
		pDC->SetTextColor (m_clrNormalText);
	}

	if ((int)(lpDIS->itemID) < 0) // Well its negetive so no need to draw text
	{
	}
	else
	{
		// Render Bitmaps
		if (((TFontObject*)lpDIS->itemData)->m_nType & TRUETYPE_FONT)
			m_ImageList.Draw(pDC,1, CPoint(rect.left,rect.top),ILD_TRANSPARENT);

		if (((TFontObject*)lpDIS->itemData)->m_nType & PRINTER_FONT)
			m_ImageList.Draw(pDC,0, CPoint(rect.left,rect.top),ILD_TRANSPARENT);
		
		rect.left += GLYPH_WIDTH + 2;
		
		CString strText;
		GetLBText (lpDIS->itemID,strText);
		if(m_bUseFont)
		{
			CFont newFont;
			CFont *pOldFont;

			((TFontObject*)lpDIS->itemData)->m_lpELF->elfLogFont.lfHeight = 90;
			((TFontObject*)lpDIS->itemData)->m_lpELF->elfLogFont.lfWidth = 0;
			newFont.CreatePointFontIndirect(
				&((TFontObject*)lpDIS->itemData)->m_lpELF->elfLogFont);
			pOldFont = pDC->SelectObject (&newFont);
			pDC->DrawText(strText, rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
			pDC->SelectObject (pOldFont);
			newFont.DeleteObject ();
		}
		else
		{
			pDC->DrawText(strText, rect, DT_LEFT | DT_VCENTER | DT_SINGLELINE);
		}
	}
}

void CFontCombo::InitFonts ()
{
	// Screen fonts
	CDC *pDC = GetDC ();
	ResetContent (); //Delete whatever is there
	EnumFontFamilies(
		pDC->GetSafeHdc(), 
		NULL, 
		(FONTENUMPROC)EnumFontFamScreenProc, 
		(LPARAM)this);//Enumerate

//#define _USE_PRINTERFONTS
#ifdef _USE_PRINTERFONTS
	// Now get printer fonts
	CPrintDialog dlg(FALSE);
	if (AfxGetApp()->GetPrinterDeviceDefaults(&dlg.m_pd))
	{
		// GetPrinterDC returns a HDC so attach it
		HDC hDC;
		hDC= dlg.CreatePrinterDC();
		ASSERT(hDC != NULL);
		EnumFontFamilies(
			hDC, 
			NULL, 
			(FONTENUMPROC)EnumFontFamPrinterProc, 
			(LPARAM)this);//Enumerate
	}
#endif
	m_bInitOver = TRUE;
}

BOOL CALLBACK CFontCombo::EnumFontFamScreenProc(
		ENUMLOGFONT *lpELF, // pointer to logical-font data 
		NEWTEXTMETRIC *lpntm, // pointer to physical-font data 
		int nFontType, // type of font 
		LPARAM lpData  // address of application-defined data 
		)
{
	if ( !(nFontType & RASTER_FONTTYPE) ) //Add only TTF fellows, If you want you can change it to check for others
	{
		TFontObject* pFontObject=new TFontObject;
		int index = ((CFontCombo *) lpData)->AddString(
			/*(const char *)(lpelf->elfFullName)*/
			lpELF->elfLogFont.lfFaceName);
		pFontObject->m_lpELF = new ENUMLOGFONT;
		CopyMemory ((PVOID) (pFontObject->m_lpELF),(CONST VOID *) lpELF,sizeof (ENUMLOGFONT));
		pFontObject->m_nType= (nFontType & TRUETYPE_FONTTYPE) ? TRUETYPE_FONT : 0;
		((CFontCombo *) lpData)->SetItemData (index,(DWORD) pFontObject);
	}
	return TRUE;
}

BOOL CALLBACK CFontCombo::EnumFontFamPrinterProc(
		ENUMLOGFONT *lpELF, // pointer to logical-font data 
		NEWTEXTMETRIC *lpntm, // pointer to physical-font data 
		int nFontType, // type of font 
		LPARAM lpData  // address of application-defined data 
		)
{
	if (!(nFontType & TRUETYPE_FONTTYPE) &&
		(nFontType & DEVICE_FONTTYPE) ) //Add only TTF fellows, If you want you can change it to check for others
	{
		TFontObject* pFontObject=new TFontObject;
		int index = ((CFontCombo *) lpData)->AddString(
			/*(const char *)(lpelf->elfFullName)*/
			lpELF->elfLogFont.lfFaceName);
		pFontObject->m_lpELF = new ENUMLOGFONT;
		CopyMemory ((PVOID) (pFontObject->m_lpELF),(CONST VOID *) lpELF,sizeof (ENUMLOGFONT));
		pFontObject->m_nType=PRINTER_FONT;
		((CFontCombo *) lpData)->SetItemData (index,(DWORD) pFontObject);
	}
	return TRUE;
}

int CFontCombo::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CComboBox::OnCreate(lpCreateStruct) == -1)
		return -1;

	PostMessage (WM_INITFONTS,0,0);
	return 0;
}

long CFontCombo::OnInitFonts (WPARAM, LPARAM)
{
	InitFonts ();
	return 0L;
}


void CFontCombo::OnDestroy()
{
	int nCount;
	nCount = GetCount ();
	for (int i = 0; i <  nCount; i++)
	{
		TFontObject* pFontObject=(TFontObject*)GetItemData(i);
		delete (pFontObject->m_lpELF);//delete the FontObject actually created..
		delete (pFontObject);
	}
	CComboBox::OnDestroy();
}

void CFontCombo::FillFonts ()
{
	// SendMessage is needed for immediate execution
	SendMessage (WM_INITFONTS,0,0); //Process in one place
}

int CFontCombo::GetSelFont (LOGFONT& lf)
{
	int index = GetCurSel ();
	if (index == LB_ERR)
		return LB_ERR;
	LPLOGFONT lpLF = &((TFontObject*)GetItemData(index))->m_lpELF->elfLogFont;
	CopyMemory ((PVOID)&lf, (CONST VOID *) lpLF, sizeof (LOGFONT));

	return index; //return the index here.. Maybe the user needs it:-)
}

