//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CharSetBtnCtrl.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CHARSETBTNCTRL_DIALOG       102
#define IDR_MAINFRAME                   128
#define IDB_GLYPHS                      131
#define IDD_CHARSET_DLG                 132
#define IDC_BUTTON1                     1000
#define IDC_CHARSETCTRL                 1000
#define IDC_CHECK_BOLD                  1003
#define IDC_CHECK_ITALIC                1004
#define IDC_COMBO_FONT                  1022

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
