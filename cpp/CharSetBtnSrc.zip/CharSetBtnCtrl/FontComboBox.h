/////////////////////////////////////////////////////////////////////////////
//  File:       FontComboBox.h
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_FONTCOMBOBOX_H__INCLUDED_)
#define _FONTCOMBOBOX_H__INCLUDED_

#if _MSC_VER >= 1000
#pragma once
#endif // _MSC_VER >= 1000

///////////////////////////////////////////////////////////////////////////
// CFontCombo window

#define TRUETYPE_FONT		0x0001
#define PRINTER_FONT		0x0002
#define DEVICE_FONT			0x0004

struct TFontObject
{
	ENUMLOGFONT* m_lpELF;
	int m_nType;
};

class CFontCombo : public CComboBox
{
// Construction
public:
	CFontCombo();

// Attributes
protected:
	COLORREF m_clrHilight;
	COLORREF m_clrNormalText;
	COLORREF m_clrHilightText;
	COLORREF m_clrBkgnd;
	BOOL m_bInitOver;
	BOOL m_bUseFont;

	CImageList m_ImageList;

// Operations
public:
	void SetHilightColors (COLORREF hilight,COLORREF hilightText)
	{
		m_clrHilight = hilight;
		m_clrHilightText = hilightText;
	};
	void SetNormalColors (COLORREF clrBkgnd,COLORREF clrText)
	{
		m_clrNormalText = clrText;
		m_clrBkgnd = clrBkgnd;
	};
	void SetUseFont (BOOL bUseFont)
	{
		m_bUseFont = bUseFont;
	};
	BOOL GetUseFont ()
	{
		return m_bUseFont;
	};
	static BOOL CALLBACK EnumFontFamScreenProc(ENUMLOGFONT FAR *lpelf, NEWTEXTMETRIC FAR *lpntm, int FontType, LPARAM lParam);
	static BOOL CALLBACK EnumFontFamPrinterProc(ENUMLOGFONT FAR *lpelf, NEWTEXTMETRIC FAR *lpntm, int FontType, LPARAM lParam);
	void FillFonts ();
	int  GetSelFont (LOGFONT&);

	void DrawDefault (LPDRAWITEMSTRUCT);
	void DrawFont(LPDRAWITEMSTRUCT);

	void InitFonts ();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFontCombo)
	public:
	virtual void DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct);
	virtual void MeasureItem(LPMEASUREITEMSTRUCT lpMeasureItemStruct);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFontCombo();

	// Generated message map functions
protected:
	//{{AFX_MSG(CFontCombo)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg long OnInitFonts (WPARAM, LPARAM);
	DECLARE_MESSAGE_MAP()
};
//{{AFX_INSERT_LOCATION}}
// Microsoft Developer Studio will insert additional declarations immediately before the previous line.

#endif //!defined(_FONTCOMBOBOX_H__INCLUDED_)
