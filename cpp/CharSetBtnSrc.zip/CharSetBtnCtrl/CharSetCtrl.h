/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetCtrl.h
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_CHARSETCTRL_H__INCLUDED_)
#define _CHARSETCTRL_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCharSetCtrl window

#define CHARSETCTRL_CLASSNAME    _T("MFCCharSetCtrl")  // Window class name

#include "charpreviewwnd.h"
class CCharSetCtrl : public CWnd
{
// Construction
public:
	CCharSetCtrl();

// Attributes
protected:
	CCharPreviewWnd m_wndPreview;
	int m_nRows;
	int m_nCols;

	COLORREF m_crLine;
	COLORREF m_crBkg;
	COLORREF m_crText;
	COLORREF m_crHiliteBkg;
	COLORREF m_crHiliteText;

	CRect m_Rect;
	int m_nRangeCol;
	int m_nStepCol;
	int m_nRangeRow;
	int m_nStepRow;

	int m_nHiliteCol;
	int m_nHiliteRow;
	int m_nSelect;
	int m_nStart;

	CString m_strFaceName;
	BOOL m_bBold;
	BOOL m_bItalic;
// Operations
public:
	BOOL Create(CWnd* pParentWnd, const RECT& rect, UINT nID, DWORD dwStyle = WS_VISIBLE);

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharSetCtrl)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void PreSubclassWindow();
	//}}AFX_VIRTUAL

public:
	void SetRows(int nRows);
	void SetCols(int nCols);

	void SetColorBkg(COLORREF crLine);
	void SetColorLine(COLORREF crBkg);
	void SetColorText(COLORREF crText);
	void SetColorHiliteBkg(COLORREF crHiliteBkg);
	void SetColorHiliteText(COLORREF crHiliteText);

	void SetFaceName(CString strFaceName);
	void SetBold(BOOL bBold);
	void SetItalic(BOOL bItalic);

	void SetSelection(int nSelect);
	void SetSelection(int nRow, int nCol);
	void SetStart(int nStart);

	int GetRows();
	int GetCols();

	COLORREF GetColorLine();
	COLORREF GetColorBkg();
	COLORREF GetColorText();
	COLORREF GetColorHiliteBkg();
	COLORREF GetColorHiliteText();

	CString GetFaceName();
	BOOL GetBold();
	BOOL GetItalic();
	
	int GetSelection();
	int GetStart();
// Implementation
public:
	virtual ~CCharSetCtrl();
protected:
    BOOL RegisterWindowClass();

	void DrawCell(CDC*, int, int);
	void DrawCell(CDC*, int);
	// Generated message map functions
protected:
	//{{AFX_MSG(CCharSetCtrl)
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnLButtonDblClk(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(_CHARSETCTRL_H__INCLUDED_)
