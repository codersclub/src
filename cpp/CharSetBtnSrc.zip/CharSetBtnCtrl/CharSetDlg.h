/////////////////////////////////////////////////////////////////////////////
//  File:       CharSetDlg.h
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(_CHARSETDLG_H__INCLUDED_)
#define _CHARSETDLG_H__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCharSetDlg dialog

#include "resource.h"
#include "charsetctrl.h"
#include "fontcombobox.h"

#define CS_SELECTED	WM_USER + 50
#define CS_ABORTED	WM_USER + 51

class CCharSetDlg : public CDialog
{
// Construction
public:
	CCharSetDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CCharSetDlg)
	enum { IDD = IDD_CHARSET_DLG };
	CButton	m_btnItalic;
	CButton	m_btnBold;
	CFontCombo	m_ComboFont;
    CCharSetCtrl	m_CharSetCtrl;
	BOOL	m_bBold;
	BOOL	m_bItalic;
	//}}AFX_DATA

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharSetDlg)
	public:
	virtual BOOL PreTranslateMessage(MSG* pMsg);
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CWnd* m_pParent;// Parent of the dialog
	static WNDPROC m_MFCWndProc;// Pointer to the default MFC window procedure
	static CCharSetDlg* m_pDialog;// Pointer to the active instance of the dialog

	// New window procedure of the dialog
	static LRESULT CALLBACK NewWndProc( HWND, UINT, WPARAM, LPARAM );

	// Generated message map functions
	//{{AFX_MSG(CCharSetDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeComboFont();
	afx_msg void OnCheckBold();
	afx_msg void OnCheckItalic();
	afx_msg void OnClose();
	//}}AFX_MSG
    afx_msg LONG CharSetCtrlSelected(WPARAM wParam = 0, LPARAM lParam = 0);

	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(_CHARSETDLG_H__INCLUDED_)
