// CharSetBtnCtrlDlg.h : header file
//

#if !defined(AFX_CHARSETBTNCTRLDLG_H__1C1FE4A9_484E_11D5_AEA0_0000863B4654__INCLUDED_)
#define AFX_CHARSETBTNCTRLDLG_H__1C1FE4A9_484E_11D5_AEA0_0000863B4654__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CCharSetBtnCtrlDlg dialog
#include "CharSetBtn.h"
class CCharSetBtnCtrlDlg : public CDialog
{
// Construction
public:
	CCharSetBtnCtrlDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CCharSetBtnCtrlDlg)
	enum { IDD = IDD_CHARSETBTNCTRL_DIALOG };
	CCharSetBtn	m_CharSetBtn;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CCharSetBtnCtrlDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CCharSetBtnCtrlDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHARSETBTNCTRLDLG_H__1C1FE4A9_484E_11D5_AEA0_0000863B4654__INCLUDED_)
