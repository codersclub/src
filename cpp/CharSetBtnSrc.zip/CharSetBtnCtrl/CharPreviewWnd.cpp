/////////////////////////////////////////////////////////////////////////////
//  File:       CharPreviewWnd.cpp
//  Version:    1.0.0.0
//  Created:    15-april-2001
//
//  Author:     Thorsten Wack
//  E-mail:     wt@umsicht.fhg.de
//
//	CharPreviewWnd.cpp : implementation file
//
/////////////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "charpreviewwnd.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CCharPreviewWnd

CCharPreviewWnd::CCharPreviewWnd()
{
	m_strOut="";
	m_strFaceName="";
	m_nFontHeight=-22;
}

CCharPreviewWnd::~CCharPreviewWnd()
{
	m_Font.DeleteObject();
}

BOOL CCharPreviewWnd::Create(CWnd* pParent)
{
	return CWnd::CreateEx(WS_EX_LEFT | WS_EX_TOOLWINDOW,
         AfxRegisterWndClass(0), 
         NULL,
         WS_POPUP | WS_BORDER | WS_CLIPSIBLINGS, 
         0, 0, 0, 0,
         pParent->m_hWnd, 
         NULL);
}

BEGIN_MESSAGE_MAP(CCharPreviewWnd, CWnd)
	//{{AFX_MSG_MAP(CCharPreviewWnd)
	ON_WM_ERASEBKGND()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CCharPreviewWnd message handlers

BOOL CCharPreviewWnd::OnEraseBkgnd(CDC* pDC) 
{
	CBrush br(GetSysColor(COLOR_INFOBK));
	CRect rc;
	pDC->GetClipBox(rc);
	CBrush* pOldBrush = pDC->SelectObject(&br);
	pDC->PatBlt(rc.left,rc.top,rc.Width(),rc.Height(),PATCOPY);

	pDC->SelectObject(pOldBrush);
	br.DeleteObject();
	return TRUE;
}

void CCharPreviewWnd::ShowTips(CPoint pt, 
			CString strFaceName, 
			int nWeight,
			BOOL bItalic,
			CString strOut)
{
	CSize sz;
	CDC* pDC = GetDC();

	if(strOut=="")
		m_strOut=strFaceName;
	else
		m_strOut=strOut;
	
	m_strFaceName = strFaceName;
	
	// Delete old font
	m_Font.DeleteObject();

	m_Font.CreateFont
	(
		m_nFontHeight,
		0,
		0,
		0,
		nWeight,
		bItalic,
		0,
		0,
		DEFAULT_CHARSET,
		OUT_CHARACTER_PRECIS,
		CLIP_CHARACTER_PRECIS,
		DEFAULT_QUALITY,
		DEFAULT_PITCH | FF_DONTCARE,
		m_strFaceName
	);

	CFont* pOldFont = pDC->SelectObject(&m_Font);

	// String dimensions of font on screen 
	sz = pDC->GetTextExtent(m_strOut);

	// Give some space round the font
	sz.cx += 8;
	sz.cy += 8;

	pDC->SelectObject(pOldFont);
	ReleaseDC(pDC);

	SetWindowPos(0,pt.x,pt.y,sz.cx,sz.cy,SWP_SHOWWINDOW|SWP_NOACTIVATE);
	RedrawWindow(); // Force immediate redraw
}

void CCharPreviewWnd::OnPaint() 
{
	CPaintDC dc(this); // device context for painting

	CFont* pOldFont=dc.SelectObject(&m_Font);
	
	CRect rc;
	GetClientRect(rc);
	
	dc.SetBkMode(TRANSPARENT);
	dc.SetTextColor(::GetSysColor(COLOR_INFOTEXT));
	dc.DrawText(m_strOut,rc,DT_SINGLELINE|DT_VCENTER|DT_CENTER);

	dc.SelectObject(&pOldFont);
	// Do not call CWnd::OnPaint() for painting messages
}
