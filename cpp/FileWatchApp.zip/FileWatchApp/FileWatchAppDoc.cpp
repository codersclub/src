// FileWatchAppDoc.cpp : implementation of the CFileWatchAppDoc class
//

#include "stdafx.h"
#include "FileWatchApp.h"

#include "FileWatchAppDoc.h"
#include "CntrItem.h"
#include "FileWatch.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc

IMPLEMENT_DYNCREATE(CFileWatchAppDoc, CRichEditDoc)

BEGIN_MESSAGE_MAP(CFileWatchAppDoc, CRichEditDoc)
	//{{AFX_MSG_MAP(CFileWatchAppDoc)
	ON_COMMAND(ID_FILE_MODIFY, OnFileModify)
	ON_COMMAND(ID_FILE_RELOAD, OnFileReload)
	ON_COMMAND(ID_FILE_MODIFYALL, OnFileModifyAll)
	//}}AFX_MSG_MAP
	// Enable default OLE container implementation
	ON_UPDATE_COMMAND_UI(ID_OLE_EDIT_LINKS, CRichEditDoc::OnUpdateEditLinksMenu)
	ON_COMMAND(ID_OLE_EDIT_LINKS, CRichEditDoc::OnEditLinks)
	ON_UPDATE_COMMAND_UI_RANGE(ID_OLE_VERB_FIRST, ID_OLE_VERB_LAST, CRichEditDoc::OnUpdateObjectVerbMenu)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc construction/destruction

CFileWatchAppDoc::CFileWatchAppDoc()
{
	m_hFileWatch = NULL;
}

CFileWatchAppDoc::~CFileWatchAppDoc()
{
	CFileWatch::RemoveHandle(m_hFileWatch);
}

BOOL CFileWatchAppDoc::OnNewDocument()
{
	if (!CRichEditDoc::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}

CRichEditCntrItem* CFileWatchAppDoc::CreateClientItem(REOBJECT* preo) const
{
	// cast away constness of this
	return new CFileWatchAppCntrItem(preo, (CFileWatchAppDoc*) this);
}



/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc serialization

void CFileWatchAppDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
	}
	else
	{
	}

	// Calling the base class CRichEditDoc enables serialization
	//  of the container document's COleClientItem objects.
	// TODO: set CRichEditDoc::m_bRTF = FALSE if you are serializing as text
	CRichEditDoc::m_bRTF = FALSE;
	CRichEditDoc::Serialize(ar);
}

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc diagnostics

#ifdef _DEBUG
void CFileWatchAppDoc::AssertValid() const
{
	CRichEditDoc::AssertValid();
}

void CFileWatchAppDoc::Dump(CDumpContext& dc) const
{
	CRichEditDoc::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc commands

BOOL CFileWatchAppDoc::OnSaveDocument(LPCTSTR lpszPathName) 
{
	CFileWatch::RemoveHandle(m_hFileWatch);
	BOOL bSuccess = CRichEditDoc::OnSaveDocument(lpszPathName);
	m_hFileWatch = CFileWatch::AddFileFolder(lpszPathName, NULL, this, 0);

	return bSuccess;
}

void CFileWatchAppDoc::SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU) 
{
	CFileWatch::RemoveHandle(m_hFileWatch);
	m_hFileWatch = CFileWatch::AddFileFolder(lpszPathName, NULL, this, 0);

	CRichEditDoc::SetPathName(lpszPathName, bAddToMRU);
}

void CFileWatchAppDoc::OnFileReload() 
{
	SetModifiedFlag(FALSE);
	if (CDocument::OnOpenDocument(GetPathName()))
		UpdateAllViews(NULL);
}






/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppDoc test commands

void CFileWatchAppDoc::OnFileModify() 
{
	CStdioFile file;
	CFileException ex;
	for (int i=0;; i++)
	{
		if (file.Open(GetPathName(), CFile::modeWrite, &ex))
			break;
		if (i>10)
			return;
		#ifdef _DEBUG
			TCHAR szError[1024];
			ex.GetErrorMessage(szError, 1024);
			afxDump << "Couldn't open source file: ";
			afxDump << szError << "\n";
		#endif
		Sleep(100);
	}

	CTime time = CTime::GetCurrentTime();
	file.WriteString(time.Format("%A, %B %d, %Y  - %H:%M:%S\n"));
}

void CFileWatchAppDoc::OnFileModifyAll() 
{
	POSITION rPosTemplate = AfxGetApp()->GetFirstDocTemplatePosition();
	while (rPosTemplate)
	{
		CDocTemplate *pDocTemplate = AfxGetApp()->GetNextDocTemplate(rPosTemplate);
		POSITION rPosDoc = pDocTemplate->GetFirstDocPosition();
		while (rPosDoc)
		{
			CFileWatchAppDoc *pDoc = (CFileWatchAppDoc*)pDocTemplate->GetNextDoc(rPosDoc);
			pDoc->OnFileModify();
		}
	}
}
