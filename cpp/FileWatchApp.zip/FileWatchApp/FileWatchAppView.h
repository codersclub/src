// FileWatchAppView.h : interface of the CFileWatchAppView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEWATCHAPPVIEW_H__7E30AB20_F04E_45F2_89CB_CD908B55ECF5__INCLUDED_)
#define AFX_FILEWATCHAPPVIEW_H__7E30AB20_F04E_45F2_89CB_CD908B55ECF5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileWatchAppCntrItem;

class CFileWatchAppView : public CRichEditView
{
protected: // create from serialization only
	CFileWatchAppView();
	DECLARE_DYNCREATE(CFileWatchAppView)

// Attributes
public:
	CFileWatchAppDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileWatchAppView)
	public:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual void OnInitialUpdate(); // called first time after construct
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CFileWatchAppView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CFileWatchAppView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	afx_msg void OnDestroy();
	//}}AFX_MSG
	afx_msg LRESULT OnFileWatchNotification(WPARAM wParam, LPARAM lParam);
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in FileWatchAppView.cpp
inline CFileWatchAppDoc* CFileWatchAppView::GetDocument()
   { return (CFileWatchAppDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEWATCHAPPVIEW_H__7E30AB20_F04E_45F2_89CB_CD908B55ECF5__INCLUDED_)
