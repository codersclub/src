// CntrItem.h : interface of the CFileWatchAppCntrItem class
//

#if !defined(AFX_CNTRITEM_H__C9133D1D_E097_4B41_8AA2_18B32A0D373F__INCLUDED_)
#define AFX_CNTRITEM_H__C9133D1D_E097_4B41_8AA2_18B32A0D373F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CFileWatchAppDoc;
class CFileWatchAppView;

class CFileWatchAppCntrItem : public CRichEditCntrItem
{
	DECLARE_SERIAL(CFileWatchAppCntrItem)

// Constructors
public:
	CFileWatchAppCntrItem(REOBJECT* preo = NULL, CFileWatchAppDoc* pContainer = NULL);
		// Note: pContainer is allowed to be NULL to enable IMPLEMENT_SERIALIZE.
		//  IMPLEMENT_SERIALIZE requires the class have a constructor with
		//  zero arguments.  Normally, OLE items are constructed with a
		//  non-NULL document pointer.

// Attributes
public:
	CFileWatchAppDoc* GetDocument()
		{ return (CFileWatchAppDoc*)CRichEditCntrItem::GetDocument(); }
	CFileWatchAppView* GetActiveView()
		{ return (CFileWatchAppView*)CRichEditCntrItem::GetActiveView(); }

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileWatchAppCntrItem)
	public:
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	~CFileWatchAppCntrItem();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CNTRITEM_H__C9133D1D_E097_4B41_8AA2_18B32A0D373F__INCLUDED_)
