// FileWatchAppDoc.h : interface of the CFileWatchAppDoc class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_FILEWATCHAPPDOC_H__438C12E4_92DA_47FF_86F3_30C822B13A0B__INCLUDED_)
#define AFX_FILEWATCHAPPDOC_H__438C12E4_92DA_47FF_86F3_30C822B13A0B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CFileWatchAppDoc : public CRichEditDoc
{
protected: // create from serialization only
	CFileWatchAppDoc();
	DECLARE_DYNCREATE(CFileWatchAppDoc)

// Attributes
public:

// Operations
public:
	void OnFileReload();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileWatchAppDoc)
	public:
	virtual BOOL OnNewDocument();
	virtual void Serialize(CArchive& ar);
	virtual BOOL OnSaveDocument(LPCTSTR lpszPathName);
	virtual void SetPathName(LPCTSTR lpszPathName, BOOL bAddToMRU = TRUE);
	//}}AFX_VIRTUAL
	virtual CRichEditCntrItem* CreateClientItem(REOBJECT* preo) const;

// Implementation
public:
	virtual ~CFileWatchAppDoc();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:
	DWORD m_hFileWatch;

// Generated message map functions
protected:
	//{{AFX_MSG(CFileWatchAppDoc)
	afx_msg void OnFileModify();
	afx_msg void OnFileModifyAll();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEWATCHAPPDOC_H__438C12E4_92DA_47FF_86F3_30C822B13A0B__INCLUDED_)
