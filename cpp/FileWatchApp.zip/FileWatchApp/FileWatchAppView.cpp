// FileWatchAppView.cpp : implementation of the CFileWatchAppView class
//

#include "stdafx.h"
#include "FileWatchApp.h"

#include "FileWatchAppDoc.h"
#include "CntrItem.h"
#include "FileWatchAppView.h"
#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppView

IMPLEMENT_DYNCREATE(CFileWatchAppView, CRichEditView)

BEGIN_MESSAGE_MAP(CFileWatchAppView, CRichEditView)
	//{{AFX_MSG_MAP(CFileWatchAppView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	ON_WM_DESTROY()
	//}}AFX_MSG_MAP
	ON_THREAD_MESSAGE(WM_FILEWATCH_NOTIFY, OnFileWatchNotification)
	// Standard printing commands
	ON_COMMAND(ID_FILE_PRINT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, CRichEditView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, CRichEditView::OnFilePrintPreview)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppView construction/destruction

CFileWatchAppView::CFileWatchAppView()
{
	// TODO: add construction code here

}

CFileWatchAppView::~CFileWatchAppView()
{
}

BOOL CFileWatchAppView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CRichEditView::PreCreateWindow(cs);
}

void CFileWatchAppView::OnInitialUpdate()
{
	CRichEditView::OnInitialUpdate();


	// Set the printing margins (720 twips = 1/2 inch).
	SetMargins(CRect(720, 720, 720, 720));
}

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppView printing

BOOL CFileWatchAppView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// default preparation
	return DoPreparePrinting(pInfo);
}


void CFileWatchAppView::OnDestroy()
{
	// Deactivate the item on destruction; this is important
	// when a splitter view is being used.
   CRichEditView::OnDestroy();
   COleClientItem* pActiveItem = GetDocument()->GetInPlaceActiveItem(this);
   if (pActiveItem != NULL && pActiveItem->GetActiveView() == this)
   {
      pActiveItem->Deactivate();
      ASSERT(GetDocument()->GetInPlaceActiveItem(this) == NULL);
   }
}


/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppView diagnostics

#ifdef _DEBUG
void CFileWatchAppView::AssertValid() const
{
	CRichEditView::AssertValid();
}

void CFileWatchAppView::Dump(CDumpContext& dc) const
{
	CRichEditView::Dump(dc);
}

CFileWatchAppDoc* CFileWatchAppView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CFileWatchAppDoc)));
	return (CFileWatchAppDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppView message handlers

LRESULT CFileWatchAppView::OnFileWatchNotification(WPARAM wParam, LPARAM lParam)
{
	LPCTSTR lpszPathName = (LPCTSTR)lParam;

	if (((CMainFrame*)AfxGetMainWnd())->m_bAutoReload || AfxMessageBox(GetDocument()->GetPathName()+"\n\nThis file has been modified outside of the editor.\nDo you want to reload it and lose all the changes made?", MB_YESNO|MB_ICONQUESTION)==IDYES)
		GetDocument()->OnFileReload();

	return 0;
}
