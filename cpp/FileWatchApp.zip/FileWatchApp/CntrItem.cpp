// CntrItem.cpp : implementation of the CFileWatchAppCntrItem class
//

#include "stdafx.h"
#include "FileWatchApp.h"

#include "FileWatchAppDoc.h"
#include "FileWatchAppView.h"
#include "CntrItem.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppCntrItem implementation

IMPLEMENT_SERIAL(CFileWatchAppCntrItem, CRichEditCntrItem, 0)

CFileWatchAppCntrItem::CFileWatchAppCntrItem(REOBJECT* preo, CFileWatchAppDoc* pContainer)
	: CRichEditCntrItem(preo, pContainer)
{
	// TODO: add one-time construction code here
	
}

CFileWatchAppCntrItem::~CFileWatchAppCntrItem()
{
	// TODO: add cleanup code here
	
}

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppCntrItem diagnostics

#ifdef _DEBUG
void CFileWatchAppCntrItem::AssertValid() const
{
	CRichEditCntrItem::AssertValid();
}

void CFileWatchAppCntrItem::Dump(CDumpContext& dc) const
{
	CRichEditCntrItem::Dump(dc);
}
#endif

/////////////////////////////////////////////////////////////////////////////
