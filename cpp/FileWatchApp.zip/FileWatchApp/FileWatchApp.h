// FileWatchApp.h : main header file for the FILEWATCHAPP application
//

#if !defined(AFX_FILEWATCHAPP_H__EB17B242_93FA_4951_9828_0DB711AB851F__INCLUDED_)
#define AFX_FILEWATCHAPP_H__EB17B242_93FA_4951_9828_0DB711AB851F__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CFileWatchAppApp:
// See FileWatchApp.cpp for the implementation of this class
//

class CFileWatchAppApp : public CWinApp
{
public:
	CFileWatchAppApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileWatchAppApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CFileWatchAppApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILEWATCHAPP_H__EB17B242_93FA_4951_9828_0DB711AB851F__INCLUDED_)
