
int		randInt		(int low, int high);
static void	Kill_Objects	(void);
void		ClearScreen		(void);
void		DestroyApp		(HWND hwnd);

//==================================================
//
//
//
//==================================================

int randInt( int low, int high )
{
	int range = high - low;
	int num = rand() % range;
	return( num + low );
}

//==================================================
//
//
//
//==================================================

static void Kill_Objects (void)
{
	if( ddraw.DD != NULL )
	{
		if( ddraw.DDSP != NULL )
		{
			ddraw.DDSP->Release();
			ddraw.DDSP = NULL;
		};
		ddraw.DD->Release();
		ddraw.DD = NULL;
	};
	if (di.di != NULL)
	{
		if(di.kbrd != NULL)
		{
			di.kbrd->Unacquire();
			di.kbrd->Release();
			di.kbrd=0;
		};
		di.di->Release();
		di.di=0;
	};
};



//==================================================
//
//
//
//==================================================

void DestroyApp(HWND hwnd)
{
	Kill_Objects ( );
	PostQuitMessage (0);
};

//==================================================
//
//
//
//==================================================

void ClearScreen (void)
{
	DDBLTFX ddbltfx;

	ddbltfx.dwSize = sizeof(ddbltfx);
	ddbltfx.dwFillColor = RGB(0, 0, 0);
	ddraw.DDSB->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);
};
