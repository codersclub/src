#define NAME "Dvizhok v5.0"
#define TITLE "Dvizhok v5.0"


#include "definies.h"
#include "res\\resource.h"
#include "helpers.h"

#include "dx_inits\\ddraw_cs.h"
#include "dx_inits\\d3drm_cs.h"
#include "dx_inits\\di_cs.h"

#include "scenes.h"

//==================================================
//
//
//
//==================================================

extern bool CheckDI (void)
{
	static char key[256];
	di.kbrd->GetDeviceState (sizeof(key), &key);
//================================================
//	F12-exit; F9-left, F10-stop, F11-right rot.
//================================================

	if (key[DIK_ESCAPE] & 0x80) PostMessage(hWnd, WM_CLOSE, 0, 0);;
	if (key[DIK_F9] & 0x80)
		lpWorldFrame->SetRotation(d3drm.scene, D3DVAL(0.0), D3DVAL(1.0),
				D3DVAL(0.0), D3DVAL(0.05));
	if (key[DIK_F10] & 0x80)
		lpWorldFrame->SetRotation(d3drm.scene, D3DVAL(0.0), D3DVAL(1.0),
				D3DVAL(0.0), D3DVAL(0.0));
	if (key[DIK_F11] & 0x80)
		lpWorldFrame->SetRotation(d3drm.scene, D3DVAL(0.0), D3DVAL(1.0),
				D3DVAL(0.0), D3DVAL(-0.05));
//================================================
//	Substract - '-' view; Add - '+' view
//================================================
	if (key[DIK_SUBTRACT] & 0x80)
				d3drm.camera->SetPosition(d3drm.scene, D3DVAL(camX+=0.4), D3DVAL(camY+=0.4), D3DVAL(camZ-=0.4));
	if (key[DIK_ADD] & 0x80)
				d3drm.camera->SetPosition(d3drm.scene, D3DVAL(camX-=0.4), D3DVAL(camY-=0.4), D3DVAL(camZ+=0.4));

	return true;
};

//==================================================
//
//
//
//==================================================

extern bool DrawScreen (void)
{

	d3drm.view->Clear();
	d3drm.scene->Move(D3DVAL(1));

  //  d3drm.view->ForceUpdate(0,0,NewRes.x,NewRes.y);
	ClearScreen();
	d3drm.view->Render(d3drm.scene);
	d3drm.device->Update();
	ddraw.DDSP->Flip (0, DDFLIP_WAIT);

	return TRUE;
};

//==================================================
//
//
//
//==================================================

LRESULT CALLBACK WindowProc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_DESTROY:
		DestroyApp (hWnd);
	      break;

	case WM_SETCURSOR:
		SetCursor (NULL);
		return TRUE;
		break; 
	};

	return DefWindowProc(hWnd, message, wParam, lParam);
};

//==================================================
//
//
//
//==================================================

BOOL CALLBACK Load_dlg_proc (HWND hWnd, UINT message, WPARAM wParam, LPARAM lParam)
{
	switch (message)
	{
	case WM_INITDIALOG:
		SendDlgItemMessage(hWnd, IDC_SHAD_OPT_2, BM_SETCHECK, BST_CHECKED, 0);
		SendDlgItemMessage(hWnd, IDC_DEV_OPT_4, BM_SETCHECK, BST_CHECKED, 0);
		SendDlgItemMessage(hWnd, IDC_RES_OPT_2, BM_SETCHECK, BST_CHECKED, 0);
//		SendDlgItemMessage(hWnd, IDC_CHK_1, BM_SETCHECK, BST_CHECKED, 0);
		break;
	case WM_COMMAND:
		switch (LOWORD(wParam))
		{
		case IDC_Launch:
			if(SendDlgItemMessage(hWnd, IDC_RES_OPT_1, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.resolution = 1;
			if(SendDlgItemMessage(hWnd, IDC_RES_OPT_2, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.resolution = 2;
			if(SendDlgItemMessage(hWnd, IDC_RES_OPT_3, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.resolution = 3;
			if(SendDlgItemMessage(hWnd, IDC_RES_OPT_4, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.resolution = 4;

			if(SendDlgItemMessage(hWnd, IDC_DEV_OPT_1, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.device = 1;
			if(SendDlgItemMessage(hWnd, IDC_DEV_OPT_2, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.device = 2;
			if(SendDlgItemMessage(hWnd, IDC_DEV_OPT_3, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.device = 3;
			if(SendDlgItemMessage(hWnd, IDC_DEV_OPT_4, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.device = 4;

			if(SendDlgItemMessage(hWnd, IDC_SHAD_OPT_1, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.shading = 1;
			if(SendDlgItemMessage(hWnd, IDC_SHAD_OPT_2, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.shading = 2;
			if(SendDlgItemMessage(hWnd, IDC_SHAD_OPT_3, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.shading = 3;

			LoadOpt.persp_corr = false;
			LoadOpt.dithering = false;
			LoadOpt.antialiasing = false;

			if(SendDlgItemMessage(hWnd, IDC_CHK_1, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.persp_corr = true;
			if(SendDlgItemMessage(hWnd, IDC_CHK_2, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.dithering = true;
			if(SendDlgItemMessage(hWnd, IDC_CHK_3, BM_GETCHECK, 0, 0)==BST_CHECKED) LoadOpt.antialiasing = true;

			EndDialog (hWnd, true);
			break;
		case IDC_Exit:
			EndDialog (hWnd, false);
			break;
		};
	default:
		break;
	};
	return false;
};

//==================================================
//
//
//
//==================================================

bool WindowInit (HINSTANCE hThisInst, int nCmdShow)
{
	WNDCLASS		    wcl;
		
	wcl.hInstance = hThisInst;
	wcl.lpszClassName = NAME;
	wcl.lpfnWndProc = WindowProc;
	wcl.style = CS_HREDRAW | CS_VREDRAW;

	wcl.hIcon = LoadIcon (hThisInst, "ICONA");
	wcl.hCursor = LoadCursor (hThisInst, IDC_ARROW);
	wcl.lpszMenuName = NULL;

	wcl.cbClsExtra = 0;
	wcl.cbWndExtra = 0;
	wcl.hbrBackground = (HBRUSH) GetStockObject (WHITE_BRUSH);

	RegisterClass (&wcl);

	hWnd = CreateWindowEx (
		WS_EX_TOPMOST,
		NAME,
		TITLE,
		WS_POPUP,
		0, 0, 
		320, 240,
		NULL,
		NULL,
		hThisInst,
		NULL);

	if (!hWnd) return FALSE;
	
	return TRUE;
};

//==================================================
//
//
//
//==================================================

bool AppInit (HINSTANCE hThisInst, int nCmdShow)
{
	if(!DialogBox (hThisInst, MAKEINTRESOURCE(IDD_Load_dlg), 0 , (DLGPROC) Load_dlg_proc)) return false;
	if(!WindowInit (hThisInst, nCmdShow)) return false;

	if(!DDrawInitFS ()) return false;
	if(!D3DInit ()) return false;
	if(!DIInit (hThisInst)) return false;

	if(!SceneInit ()) return false;

	ShowWindow (hWnd, nCmdShow);
	UpdateWindow (hWnd);

	return TRUE;
};

//==================================================
//
//
//
//==================================================

int WINAPI WinMain (HINSTANCE hThisInst, HINSTANCE hPrevInst, LPSTR lpCmdLine, int nCmdShow)
{
	MSG         msg;
	
	if (!AppInit (hThisInst, nCmdShow)) return FALSE;

	while (1)
	{
		if (PeekMessage( &msg, NULL, 0, 0, PM_NOREMOVE))
		{
			if (!GetMessage( &msg, NULL, 0, 0))	break;
			TranslateMessage(&msg); 
			DispatchMessage(&msg);
		}
		else 
		{
			CheckDI ();
			animation->SetTime(timeT++);// ������������� ������� ����� � ��������
			if (timeT>=80) timeT=0;
			DrawScreen ();
	};	};

	return msg.wParam;
};

//==================================================
//
//
//
//==================================================

