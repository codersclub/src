// TryIRC2.h : main header file for the TRYIRC2 application
//

#if !defined(AFX_TRYIRC2_H__496F529A_BA0D_4AA1_831F_03E8545CE524__INCLUDED_)
#define AFX_TRYIRC2_H__496F529A_BA0D_4AA1_831F_03E8545CE524__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols
#include "irc.h"

extern irc::CIrcSession g_ircSession;

/////////////////////////////////////////////////////////////////////////////
// CTryIRC2App:
// See TryIRC2.cpp for the implementation of this class
//

class CTryIRC2App : public CWinApp
{
public:
	CTryIRC2App();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTryIRC2App)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CTryIRC2App)
	afx_msg void OnAppAbout();
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	afx_msg void OnUpdateFileOpen(CCmdUI* pCmdUI);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TRYIRC2_H__496F529A_BA0D_4AA1_831F_03E8545CE524__INCLUDED_)
