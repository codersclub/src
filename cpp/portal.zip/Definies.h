#define WIN32_LEAN_AND_MEAN
#define INITGUID

#include <windows.h>
#include <Ddraw.h>
#include <D3drmwin.h>
#include <Dinput.h>

//#include <..\\misc\\ddutil.cpp>

#pragma comment (lib,"dxguid.lib")
#pragma comment (lib,"ddraw.lib")
#pragma comment (lib,"d3drm.lib")
#pragma comment (lib,"dinput.lib")


struct _DDRAW
{
	LPDIRECTDRAW2		      DD;
	LPDIRECTDRAWSURFACE3		DDSP;
	LPDIRECTDRAWSURFACE3		DDSB;
} ddraw;

struct _D3DRM
{
	LPDIRECT3DRM2			D3DRM;
	LPDIRECT3DRMDEVICE2		device;
	LPDIRECT3DRMVIEWPORT		view;
	LPDIRECT3DRMFRAME2		scene;
	LPDIRECT3DRMFRAME2		camera;
} d3drm;

struct _DI
{
	LPDIRECTINPUT di;
	LPDIRECTINPUTDEVICE kbrd;
	LPDIRECTINPUTDEVICE mouse;
} di;


LPDIRECT3DRMFRAME2		lpLightFrame, lpWorldFrame, lpWorldFrame2, cadr2;
LPDIRECT3DRMLIGHT			lpLight;
LPDIRECT3DRMTEXTURE2		texture1, texture2, texture_transp;

LPDIRECT3DRMWRAP			wrap1, wrap2, wrap3;
LPDIRECT3DRMMESHBUILDER2	left, right, up, down,portal;
LPDIRECT3DRMMESHBUILDER2	transp;


struct _Opt
{
	int resolution;
	int device;
	int shading;
	
	bool persp_corr;
	bool dithering;
	bool antialiasing;
} LoadOpt;

struct _Res
{
	int x;
	int y;
} NewRes;






double camX=13, camY=13, camZ=-13;
HWND hWnd;

