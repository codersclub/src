//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by JMultiColSample.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_JMULTICOLSAMPLE_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDC_COMBO1                      1000
#define IDC_BUTTON1                     1001
#define IDC_EDIT1                       1002
#define IDC_COMBO2                      1003
#define IDC_COMBO3                      1004
#define IDC_COMBO4                      1005

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
