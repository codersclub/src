; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CJMultiColSampleDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "jmulticolsample.h"
LastPage=0

ClassCount=4
Class1=CJComboBox
Class2=CJMultiColSampleApp
Class3=CAboutDlg
Class4=CJMultiColSampleDlg

ResourceCount=2
Resource1=IDD_ABOUTBOX
Resource2=IDD_JMULTICOLSAMPLE_DIALOG

[CLS:CJComboBox]
Type=0
BaseClass=CComboBox
HeaderFile=JComboBx.h
ImplementationFile=JComboBx.cpp
Filter=W
LastObject=CJComboBox
VirtualFilter=cWC

[CLS:CJMultiColSampleApp]
Type=0
BaseClass=CWinApp
HeaderFile=JMultiColSample.h
ImplementationFile=JMultiColSample.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=JMultiColSampleDlg.cpp
ImplementationFile=JMultiColSampleDlg.cpp
Filter=D

[CLS:CJMultiColSampleDlg]
Type=0
BaseClass=CDialog
HeaderFile=JMultiColSampleDlg.h
ImplementationFile=JMultiColSampleDlg.cpp
LastObject=IDC_COMBO2
Filter=D
VirtualFilter=dWC

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_JMULTICOLSAMPLE_DIALOG]
Type=1
Class=CJMultiColSampleDlg
ControlCount=15
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_COMBO1,combobox,1344340499
Control4=IDC_BUTTON1,button,1342242817
Control5=IDC_STATIC,static,1342308352
Control6=IDC_EDIT1,edit,1350631552
Control7=IDC_STATIC,button,1342177287
Control8=IDC_STATIC,button,1342177287
Control9=IDC_COMBO2,combobox,1344340755
Control10=IDC_COMBO3,combobox,1344340771
Control11=IDC_COMBO4,combobox,1344340755
Control12=IDC_STATIC,static,1342308352
Control13=IDC_STATIC,static,1342308352
Control14=IDC_STATIC,static,1342308352
Control15=IDC_STATIC,static,1342308352

