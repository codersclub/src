// ResizeTestDlg.h : header file
//

#if !defined(AFX_RESIZETESTDLG_H__714B1DE3_59F7_4F32_A271_64673E72A592__INCLUDED_)
#define AFX_RESIZETESTDLG_H__714B1DE3_59F7_4F32_A271_64673E72A592__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "CtrlsResize.h"

/////////////////////////////////////////////////////////////////////////////
// CResizeTestDlg dialog

class CResizeTestDlg : public CDialog
{
// Construction
public:
	CResizeTestDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CResizeTestDlg)
	enum { IDD = IDD_RESIZETEST_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResizeTestDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;
	CStatusBarCtrl m_StatusCtrl;
	CCtrlResize m_CtrlsResize;
	// Generated message map functions
	//{{AFX_MSG(CResizeTestDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESIZETESTDLG_H__714B1DE3_59F7_4F32_A271_64673E72A592__INCLUDED_)
