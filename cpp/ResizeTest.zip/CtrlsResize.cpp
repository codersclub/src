// CtrlsResize.cpp: implementation of the CCtrlsResize class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "CtrlsResize.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////


CCtrlResize::CControlInfo::CControlInfo(int _controlID, int _bindtype, CRect& _rectInitial, CWnd* _m_pControlWnd)
{
	controlID = _controlID;
	bindtype = _bindtype;
	rectInitial = _rectInitial;
	m_pControlWnd = _m_pControlWnd;
};

int CCtrlResize::AddControl(int _controlID, int _bindtype, CRect &_rectInitial)
{
	m_aCtrls.Add(new CControlInfo(_controlID, _bindtype, _rectInitial));
	return 0;
}

int CCtrlResize::FixControls()
{
	if (!m_pWnd)
		return 1;
	m_pWnd->GetClientRect(&m_rectInitialParent);
	m_pWnd->ScreenToClient(&m_rectInitialParent);
	
	for (int i = 0; i < m_aCtrls.GetSize(); i++) {
		m_aCtrls.GetAt(i)->m_pControlWnd = m_pWnd->GetDlgItem(m_aCtrls.GetAt(i)->controlID);
		if (m_aCtrls.GetAt(i)->m_pControlWnd) {
			m_aCtrls.GetAt(i)->m_pControlWnd->GetWindowRect(&m_aCtrls.GetAt(i)->rectInitial);
			m_pWnd->ScreenToClient(&m_aCtrls.GetAt(i)->rectInitial);
		}
	}
	return 0;
}

CCtrlResize::~CCtrlResize()
{
	for (int i = 0; i < m_aCtrls.GetSize(); i++)
		delete m_aCtrls.GetAt(i);
}

CCtrlResize::CCtrlResize() 
	: m_pWnd(NULL)
{

}

void CCtrlResize::SetParentWnd(CWnd *pWnd)
{
	m_pWnd = pWnd;
}

void CCtrlResize::OnSize()
{
	if (!m_pWnd || !m_pWnd->IsWindowVisible())
		return;

	CRect rr, rectWnd;
	m_pWnd->GetClientRect(&rectWnd);
	
	for (int i = 0; i < m_aCtrls.GetSize(); i++) {
		rr = m_aCtrls.GetAt(i)->rectInitial;
		if (m_aCtrls.GetAt(i)->bindtype & BIND_RIGHT) 
				rr.right = rectWnd.right -(m_rectInitialParent.Width() - m_aCtrls.GetAt(i)->rectInitial.right);
		if (m_aCtrls.GetAt(i)->bindtype & BIND_BOTTOM) 
				rr.bottom = rectWnd.bottom -(m_rectInitialParent.Height() - m_aCtrls.GetAt(i)->rectInitial.bottom);
		if (m_aCtrls.GetAt(i)->bindtype & BIND_TOP) ;
		else
			rr.top = rr.bottom - m_aCtrls.GetAt(i)->rectInitial.Height();
		if (m_aCtrls.GetAt(i)->bindtype & BIND_LEFT) ;
		else
			rr.left = rr.right - m_aCtrls.GetAt(i)->rectInitial.Width();
		
		m_aCtrls.GetAt(i)->m_pControlWnd->MoveWindow(&rr);
		m_aCtrls.GetAt(i)->m_pControlWnd->Invalidate(FALSE);
	}
}
