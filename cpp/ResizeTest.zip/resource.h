//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by ResizeTest.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_RESIZETEST_DIALOG           102
#define IDR_MAINFRAME                   128
#define IDC_EDIT1                       1000
#define IDC_STATUSCTRL                  1001
#define IDC_EDIT2                       1002

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        129
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1003
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
