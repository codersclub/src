// ResizeTest.h : main header file for the RESIZETEST application
//

#if !defined(AFX_RESIZETEST_H__71E03283_0BD3_4257_8FAA_010AF2BE9563__INCLUDED_)
#define AFX_RESIZETEST_H__71E03283_0BD3_4257_8FAA_010AF2BE9563__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CResizeTestApp:
// See ResizeTest.cpp for the implementation of this class
//

class CResizeTestApp : public CWinApp
{
public:
	CResizeTestApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CResizeTestApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CResizeTestApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_RESIZETEST_H__71E03283_0BD3_4257_8FAA_010AF2BE9563__INCLUDED_)
