// CtrlsResize.h: interface for the CCtrlsResize class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CTRLSRESIZE_H__01C4187E_2195_4CF5_9555_56A86CA51F8B__INCLUDED_)
#define AFX_CTRLSRESIZE_H__01C4187E_2195_4CF5_9555_56A86CA51F8B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include <afxtempl.h>

const int BIND_TOP =	0x01;
const int BIND_LEFT =	0x02;
const int BIND_RIGHT =	0x04;
const int BIND_BOTTOM =	0x08;
const int BIND_ALL =	0x0F;
const int BIND_UNKNOWN = 0x00;

class CCtrlResize
{
public:
	void OnSize();
	void SetParentWnd(CWnd *pWnd);
	int FixControls();
	int AddControl(int _controlID, int _bindtype, CRect& _rectInitial = CRect(NULL));

	class CControlInfo  
	{
	public:
		CControlInfo() : controlID(0), bindtype(BIND_UNKNOWN), rectInitial(NULL){};
		CControlInfo(int _controlID, int _bindtype, CRect& _rectInitial, CWnd* _m_pControlWnd = NULL);
		virtual ~CControlInfo() {};

		int controlID;
		int bindtype;
		CRect rectInitial;
		CWnd* m_pControlWnd;
	};

	CCtrlResize();
	~CCtrlResize();

private:
	CWnd* m_pWnd;
	CArray <CControlInfo*, CControlInfo*> m_aCtrls;
	CRect m_rectInitialParent;
};

#endif // !defined(AFX_CTRLSRESIZE_H__01C4187E_2195_4CF5_9555_56A86CA51F8B__INCLUDED_)
