; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CResizeTestDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "ResizeTest.h"

ClassCount=4
Class1=CResizeTestApp
Class2=CResizeTestDlg
Class3=CAboutDlg

ResourceCount=5
Resource1=IDD_ABOUTBOX
Resource2=IDR_MAINFRAME
Resource3=IDD_RESIZETEST_DIALOG
Resource4=IDD_ABOUTBOX (English (U.S.))
Resource5=IDD_RESIZETEST_DIALOG (English (U.S.))

[CLS:CResizeTestApp]
Type=0
HeaderFile=ResizeTest.h
ImplementationFile=ResizeTest.cpp
Filter=N

[CLS:CResizeTestDlg]
Type=0
HeaderFile=ResizeTestDlg.h
ImplementationFile=ResizeTestDlg.cpp
Filter=W
BaseClass=CDialog
VirtualFilter=dWC

[CLS:CAboutDlg]
Type=0
HeaderFile=ResizeTestDlg.h
ImplementationFile=ResizeTestDlg.cpp
Filter=D

[DLG:IDD_ABOUTBOX]
Type=1
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308352
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889
Class=CAboutDlg


[DLG:IDD_RESIZETEST_DIALOG]
Type=1
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Class=CResizeTestDlg

[DLG:IDD_RESIZETEST_DIALOG (English (U.S.))]
Type=1
Class=CResizeTestDlg
ControlCount=5
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_EDIT1,edit,1350631552
Control5=IDC_EDIT2,edit,1350631552

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

