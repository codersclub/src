/*
	Patch Info:
	Eliminates an problem with CheckBox in Windows 2000.
	Replace this function in file ALXGridCore.cpp.
*/

// The function draws a control in cell
BOOL DrawCellCtrl(CDC* pDC, CRect& rect, CELL_INFO& CellInfo, CELL_DATA& CellData)
{
	CRect rectText(rect), rectCtrl(rect);
	CString strText = CellData.m_strText;
	BOOL FirstDrawFrameCtrl = FALSE;
	UINT nState = CellInfo.m_nState;

	switch(CellInfo.m_nTypeCtrl)
	{
	case DFC_BUTTON:
		{
			// If it is the button DFCS_BUTTONPUSH
			if(nState & DFCS_BUTTONPUSH)
			{
				FirstDrawFrameCtrl = TRUE;
				rectCtrl.DeflateRect(1,0,0,1);
			}
			else
			{
				if(strText.GetLength()>0) // If it is necessary to output the text
				{
					strText = " " + strText;
					rectText.left	= min(rect.right,rect.left + 15);
				}
				else
				{
					rectText = CRect(0,0,0,0);
					rectCtrl.left	= max(rect.left,rect.left+(rect.Width()-13)/2);
				}
				rectCtrl.top	= max(rect.top,rect.top+(rect.Height()-13)/2);
				rectCtrl.right	= min(rect.right,rectCtrl.left + 13),
				rectCtrl.bottom = min(rect.bottom,rectCtrl.top + 13);

				switch(CellData.m_dwTag)
				{
				case 0:
					{
						nState =  nState & ~DFCS_CHECKED;
						break;
					}
				case 1:
					{
						if(nState == (nState | DFCS_BUTTON3STATE))
							nState =  (nState & ~DFCS_BUTTON3STATE) | DFCS_BUTTONCHECK | DFCS_CHECKED;
						else
							nState =  nState | DFCS_CHECKED;
						break;
					}
				case 2:
					{
						if(nState == (nState | DFCS_BUTTON3STATE))
							nState =  nState | DFCS_CHECKED;
						else
							nState =  nState & ~DFCS_CHECKED;
						break;
					}
				default:
						nState =  nState & ~DFCS_CHECKED;
				}
			}
			break;
		}
	case DFC_SCROLL:
		{
			if((nState & DFCS_SCROLLSIZEGRIPRIGHT) == DFCS_SCROLLSIZEGRIPRIGHT)
			{
				CRect rectCtrl1(rectCtrl), rectCtrl2(rectCtrl);
				rectCtrl1.left = max(rect.left,rect.right - ::GetSystemMetrics(SM_CXVSCROLL));
				rectCtrl1.bottom = rect.top + rect.Height()/2;
				rectCtrl2.top = rectCtrl1.bottom;
				rectCtrl2.left = rectCtrl1.left;
				rectText.right = rectCtrl.left;
				if(rectCtrl1.IsRectEmpty())
					return FALSE;
				return
					pDC->DrawText(strText, rectText, CellInfo.m_nFormat) &&
					pDC->DrawFrameControl(&rectCtrl1,CellInfo.m_nTypeCtrl,nState & ~ DFCS_SCROLLSIZEGRIPRIGHT | DFCS_SCROLLUP) &&
					pDC->DrawFrameControl(&rectCtrl2,CellInfo.m_nTypeCtrl,nState & ~ DFCS_SCROLLSIZEGRIPRIGHT | DFCS_SCROLLDOWN);
			}
			if((nState & DFCS_SCROLLSIZEGRIP) == DFCS_SCROLLSIZEGRIP)
			{
				FirstDrawFrameCtrl = TRUE;
				rectText.right = max(rect.left,rect.right - rect.Height()/2 - 1);
				break;
			}
			if((nState & DFCS_SCROLLCOMBOBOX) == DFCS_SCROLLCOMBOBOX)
			{
				rectCtrl.left = max(rect.left,rect.right - rect.Height());
				rectText.right = rectCtrl.left;
			}
			break;
		}
	case DFC_MENU:
		{
			FirstDrawFrameCtrl = TRUE;
			strText = " " + strText;
			rectCtrl.right	= min(rect.right,rect.left + 13);
			rectText.left	= min(rect.right,rectCtrl.right + 2); 
			break;
		}
	case DFC_CAPTION:
		{
			rectCtrl.left = max(rect.left,rect.right - rect.Height());
			rectText.right = rectCtrl.left; 
			break;
		}
	}

	if(rectCtrl.IsRectEmpty())
		return FALSE;
	if(FirstDrawFrameCtrl)
	{
		BOOL bResult =	pDC->DrawFrameControl(&rectCtrl,CellInfo.m_nTypeCtrl,nState);
						pDC->DrawText(strText, rectText, CellInfo.m_nFormat);

		return bResult;
/*		return
			pDC->DrawFrameControl(&rectCtrl,CellInfo.m_nTypeCtrl,nState) &&
			pDC->DrawText(strText, rectText, CellInfo.m_nFormat);
*/
	}
	else
	{
				pDC->DrawText(strText, rectText, CellInfo.m_nFormat);
		return	pDC->DrawFrameControl(&rectCtrl,CellInfo.m_nTypeCtrl,nState);
/*		return
			pDC->DrawText(strText, rectText, CellInfo.m_nFormat) &&
			pDC->DrawFrameControl(&rectCtrl,CellInfo.m_nTypeCtrl,nState);
*/	}
};
