// FileRgn.h : main header file for the FILERGN application
//

#if !defined(AFX_FILERGN_H__D44947D3_A3E7_4766_8671_921EF02AAE3E__INCLUDED_)
#define AFX_FILERGN_H__D44947D3_A3E7_4766_8671_921EF02AAE3E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CFileRgnApp:
// See FileRgn.cpp for the implementation of this class
//

class CFileRgnApp : public CWinApp
{
public:
	CFileRgnApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileRgnApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CFileRgnApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILERGN_H__D44947D3_A3E7_4766_8671_921EF02AAE3E__INCLUDED_)
