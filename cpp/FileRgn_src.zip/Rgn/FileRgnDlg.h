// FileRgnDlg.h : header file
//

#if !defined(AFX_FILERGNDLG_H__D2177807_3CA5_42C3_A4D7_A1D8E49CC9CA__INCLUDED_)
#define AFX_FILERGNDLG_H__D2177807_3CA5_42C3_A4D7_A1D8E49CC9CA__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CFileRgnDlg dialog

#define DRAGGING	0x01	// dragging flag

class CFileRgnDlg : public CDialog
{
	HDC m_dcBkGrnd;			// background bitmap dc

	DWORD m_dwWidth;		// mask width
	DWORD m_dwHeight;		// mask height

	DWORD	m_dwFlags;		// flags
	POINT	m_pntMouse;		// Mouse position for dragging
	
// Construction
public:
	HRGN CreateRgnFromFile( HBITMAP hBmp, COLORREF color );

	CFileRgnDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CFileRgnDlg)
	enum { IDD = IDD_FILERGN_DIALOG };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFileRgnDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CFileRgnDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FILERGNDLG_H__D2177807_3CA5_42C3_A4D7_A1D8E49CC9CA__INCLUDED_)
