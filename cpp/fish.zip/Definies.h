#define WIN32_LEAN_AND_MEAN
#define INITGUID

#include <windows.h>
#include <Ddraw.h>
#include <D3drmwin.h>
#include <Dinput.h>
#include <time.h>
#include <stdlib.h>
#include <malloc.h>


//#include <..\\misc\\ddutil.cpp>

#pragma comment (lib,"dxguid.lib")
#pragma comment (lib,"ddraw.lib")
#pragma comment (lib,"d3drm.lib")
#pragma comment (lib,"dinput.lib")

/*
bool DX6Detector (void)
{
    LPDIRECTDRAW    lpdraw;
    LPDIRECTDRAW4   lpdraw4;
    HRESULT hr;

    hr = DirectDrawCreate (NULL, &lpdraw, NULL);
    if (hr != DD_OK) return false;  // DirectX ������ �� ����������

    hr = lpdraw->QueryInterface (IID_IDirectDraw4, (void**) &lpdraw4);

    if (hr != DD_OK)
    {
        lpdraw->Release ();
        return false;                // �������� ������, IDD4 �� ��������
    };

    lpdraw4->Release ();
    lpdraw->Release ();

    // ���, DirectX 6 �������� � ����� � ������
    return true;
};

*/

struct _DDRAW
{
	LPDIRECTDRAW2		      DD;
	LPDIRECTDRAWSURFACE3		DDSP;
	LPDIRECTDRAWSURFACE3		DDSB;
} ddraw;

struct _D3DRM
{
	LPDIRECT3DRM2			D3DRM;
	LPDIRECT3DRMDEVICE2		device;
	LPDIRECT3DRMVIEWPORT		view;
	LPDIRECT3DRMFRAME2		scene;
	LPDIRECT3DRMFRAME2		camera;
} d3drm;

struct _DI
{
	LPDIRECTINPUT di;
	LPDIRECTINPUTDEVICE kbrd;
	LPDIRECTINPUTDEVICE mouse;
} di;


LPDIRECT3DRMFRAME2		lpLightFrame, lpWorldFrame, lpWorldFrame2, cadr2, lpChaseFrame;
LPDIRECT3DRMLIGHT			lpLight;
LPDIRECT3DRMTEXTURE2		texture1, texture2, texture_transp;

LPDIRECT3DRMWRAP			wrap1, wrap2, wrap3, wrap4;
LPDIRECT3DRMMESHBUILDER2	top, left, right, up, down,cube;
LPDIRECT3DRMMESHBUILDER2	transp;
LPDIRECT3DRMANIMATION anim_path;

struct _Opt
{
	int resolution;
	int device;
	int shading;
	
	bool persp_corr;
	bool dithering;
	bool antialiasing;
} LoadOpt;

struct _Res
{
	int x;
	int y;
} NewRes;



  struct animpos
  {
float time;
float x;
float y;
float z;
  };

  struct animat
  {
	int kolvo;
	animpos *anima;
  };
  
  struct animrot
  {
 float time;
 D3DRMQUATERNION a;
  };

  struct string
  {
   char *name;
  };

  class platonObject
  {
  public:
	LPDIRECT3DRMFRAME2         frame;  
	LPDIRECT3DRMFRAME2         chase;  
	LPDIRECT3DRMFRAME2         chase_far;  
	LPDIRECT3DRMMESHBUILDER2   mesh;
    LPDIRECT3DRMANIMATION      animation; 
	float                      addtimeT;
	float                      maxtimeT;
 	float                      timeT;            //��������
    D3DVECTOR                  *pVertex1;        //������� 1-�� ��������  
	D3DVECTOR                  *pVertex2;        //������� 2-�� �������� 
    DWORD                      MaxCount;         //���-�� ������ 
	float                      morph_weight;     //���� ��������  
	float                      morph_speed;      //�������� ��������  
    string                     status_list[5];
	char                       max_status;

  public:

// 1-�� �������� - ��� .X �����, 2-�� - ������ �� ��������, 3-�� - ����� �� ��� ������ �������, 4-�� - ����� �� ���������� � �������� ��� ������
   void LoadObject(char *name,LPDIRECT3DRMTEXTURE texture, char visual_on,char animation_on)
   {
	   for (int tempI=0;tempI<5; tempI++)
		{
       status_list[tempI].name=(char*)malloc(10);
	   status_list[tempI].name="default";
		}
	   max_status=1;
    d3drm.D3DRM->CreateFrame(lpWorldFrame, &frame);
	d3drm.D3DRM->CreateFrame(lpWorldFrame, &chase);
	d3drm.D3DRM->CreateFrame(lpWorldFrame, &chase_far);
  	d3drm.D3DRM->CreateMeshBuilder(&mesh);
   
   mesh->Load(name,NULL,D3DRMLOAD_FROMFILE, NULL, NULL);
   if (visual_on)  {
	   frame->AddVisual (mesh);
       mesh->SetPerspective(TRUE);
MaxCount=mesh->GetVertexCount();
pVertex1=(LPD3DVECTOR) malloc(MaxCount * sizeof(D3DVECTOR));
pVertex2=(LPD3DVECTOR) malloc(MaxCount * sizeof(D3DVECTOR));
					}

   if (texture!=NULL)
		{
    mesh->SetTexture(texture);
    wrap1->Apply (mesh);
		  }

   if (animation_on)
				{
    d3drm.D3DRM->CreateAnimation(&animation); 

	animation->SetOptions  	    ( D3DRMANIMATION_CLOSED
                                         | D3DRMANIMATION_SPLINEPOSITION
                                         | D3DRMANIMATION_POSITION);

//	animation->SetOptions  	    ( D3DRMANIMATION_CLOSED
//                                         | D3DRMANIMATION_LINEARPOSITION 
//                                         | D3DRMANIMATION_POSITION);
	
	animation->SetFrame(frame);
				}
		
   }

 void InitMorphing(LPDIRECT3DRMMESHBUILDER2 src1,LPDIRECT3DRMMESHBUILDER2 src2,float speed)
   {
//MaxCount=mesh->GetVertexCount();
//pVertex1=(LPD3DVECTOR) malloc(MaxCount * sizeof(D3DVECTOR));
//pVertex2=(LPD3DVECTOR) malloc(MaxCount * sizeof(D3DVECTOR));
morph_weight=0;
morph_speed=speed;

src1->GetVertices(&MaxCount,pVertex1,NULL,NULL,NULL,NULL);
src2->GetVertices(&MaxCount,pVertex2,NULL,NULL,NULL,NULL);


   }
   
// �������������� ��������. anim - ����, 
// addtime - ���������� �� �������.
// plus_x,plus_y,plus_z - ��������
//
 void InitAnimation(animat *anim,float plus_x,float plus_y, float plus_z,float addtime)
	 {
 int tempI;
  timeT=0;
//  maxtimeT=maxtime;
  addtimeT=addtime;
  for (tempI=0;tempI<anim->kolvo;tempI++) animation->AddPositionKey(
	  anim->anima[tempI].time,     anim->anima[tempI].x+plus_x,
	  anim->anima[tempI].y+plus_y, anim->anima[tempI].z+plus_z);

    	maxtimeT=anim->anima[tempI-1].time;
	  }
	   void RestoreAnimation(animat *anim)
	   {
		   int tempI;
		    for (tempI=0;tempI<anim->kolvo;tempI++) animation->DeleteKey(anim->anima[tempI].time);
	   }
   

   	void showanimation()
		{	
	timeT+=addtimeT;
	animation->SetTime(timeT);
    if (timeT>maxtimeT) timeT=0;
	animation->SetFrame(frame); 
    animation->SetTime(timeT);
    animation->SetFrame(chase);
    animation->SetTime(timeT+2);
	animation->SetFrame(chase_far);
    animation->SetTime(timeT+15);
   
    frame->LookAt(chase,d3drm.scene,D3DRMCONSTRAIN_Z);
		}

void Morphing ()
	{
WORD VertCount,MaxCount1=WORD(MaxCount);
float antiweight=1-morph_weight;

for (VertCount=0;VertCount<MaxCount1;VertCount++ ) 
	
mesh->SetVertex(VertCount,
	pVertex1[VertCount].x*morph_weight+pVertex2[VertCount].x*antiweight,
	pVertex1[VertCount].y*morph_weight+pVertex2[VertCount].y*antiweight,
	pVertex1[VertCount].z*morph_weight+pVertex2[VertCount].z*antiweight);
	
 morph_weight+=morph_speed;
 if ((morph_weight>=1) || (morph_weight<=0)) morph_speed*=-1;
		
	}

    void StatusProcessing()
	{ 
		  max_status--;
		if (max_status=0)  {
            max_status=1;
			status_list[0].name="default";
							}
		else 
	      for (int tempI=0;tempI<4;tempI++) status_list[tempI].name=status_list[tempI+1].name;
		 
	}


 };


 animpos pathp[]=
 {
   0  ,  15,  -10,  0,
   50,  15,  -8,  20,
   100, -15,  -6,  20,
   150, -15,  -8,   0,
   201,  15,  -10,  0
 };
  animpos pathp1[]=
 {
   0  ,  15,  -10,  0,
   50 ,  13,  -10,  0,
   100,  -7, -8,  0,
   150,  -7, -8, -5,
   200,  5,   -8, -6, 
   251,  15,  -10,  0
 };

  animpos pathp2[]=
 {
   0  , 15,  -10,  0,
   50,  13,  -10, 3,
   100, 0,   -7,  10,
   150, 0,   -7,   0,
   200, 5,   -8,  -6,
   250, 5,   -8,  -6,
   301, 15,  -10,  0
  };
 
 
 animpos pathp3[]=
 {
   0  ,  15,  -10,  0,
   50,   10,  -10,  5,
   100, -30, -10,  20,
   150, -20, -12,  20,   
   200,  5,  -10,  20, 
   250,  5,  -10, -6,
   301,  15,  -10,  0
 };

 animpos pathp4[]=
 {
   0  ,  15,  -10,   0,
   50,   10,  -10,   5,
   100, -5,   -10,   5,
   150, -5,   -8,  -5,   
   200,  0,   -8,  -5, 
   250,  5,   -8,   -6,
   301,  15,  -10,   0
 };

 animpos path_buble[]=
 {
   0 ,  0,  0,  0,
   20, -5,  15, 5,
   40,  5,  30,-5,
//   60, -5,  45, 5,
//   80,  5,  60,-5
 };
  
platonObject object3D[20];

animat fish_an,buble_an;
double camX=0, camY=20, camZ=-50;
double camXi=0, camYi=20, camZi=-50;
bool buble_on[3]={false,false,false};
D3DVECTOR tempVector;
HWND hWnd;

