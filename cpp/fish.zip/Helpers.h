
int		randInt		(int low, int high);
static void	Kill_Objects	(void);
void		ClearScreen		(void);
void		DestroyApp		(HWND hwnd);

//==================================================
//
//
//
//==================================================

int randInt( int low, int high )
{
	int range = high - low;
	int num = rand() % range;
	return( num + low );
}

//==================================================
//
//
//
//==================================================

static void Kill_Objects (void)
{
	if( ddraw.DD != NULL )
	{
		if( ddraw.DDSP != NULL )
		{
			ddraw.DDSP->Release();
			ddraw.DDSP = NULL;
		};
		ddraw.DD->Release();
		ddraw.DD = NULL;
	};
	if (di.di != NULL)
	{
		if(di.kbrd != NULL)
		{
			di.kbrd->Unacquire();
			di.kbrd->Release();
			di.kbrd=0;
		};
		di.di->Release();
		di.di=0;
	};
};

//==================================================
//
//
//
//==================================================

/*
void ClearScreen (void)
{
	DDBLTFX ddbltfx;

	ddbltfx.dwSize = sizeof(ddbltfx);
	ddbltfx.dwFillColor = FillColor;
	ddraw.DDSB->Blt(NULL, NULL, NULL, DDBLT_COLORFILL, &ddbltfx);

};
*/

//==================================================
//
//
//
//==================================================

void DestroyApp(HWND hwnd)
{
	Kill_Objects ( );
	PostQuitMessage (0);
};

//==================================================
//
//
//
//==================================================

//  ������ ��������� ��������� �������� ����
//------------------------------------------------------------

void CheckFishAnimation_default(void)
{ 
	int tempI;
	if (object3D[2].timeT>=object3D[2].maxtimeT-2) 
	{
  object3D[2].RestoreAnimation(&fish_an);
  tempI=randInt(1,6);

 if (tempI==1) {
     fish_an.kolvo=5;
     fish_an.anima=pathp;
 					};
	   
if (tempI==2) {
     fish_an.kolvo=6;
     fish_an.anima=pathp1;
			};
		  
if (tempI==3) {
     fish_an.kolvo=7;
     fish_an.anima=pathp2;
			};

if (tempI==4) {
     fish_an.kolvo=7;
     fish_an.anima=pathp3;
			};
	

if (tempI==5) {
     fish_an.kolvo=7;
     fish_an.anima=pathp4;
			};

	 object3D[2].frame->GetPosition(d3drm.scene,&tempVector);
     object3D[2].InitAnimation(&fish_an,0,0,0,1);

	}

}
//------------------------------------------------------------
//  ����� ��������� ��������� �������� ����


// ������ ��������� ���������
//---------------------------------------------------------

 void CheckBubleAnimation(void)
 {
 int tempI;
for (tempI=0;tempI<=2;tempI++)
	{
 if (buble_on[tempI]) object3D[tempI+3].showanimation();

 if (object3D[tempI+3].timeT>=object3D[tempI+3].maxtimeT)
{
 buble_on[tempI]=false;
 object3D[tempI+3].RestoreAnimation(&buble_an);
 object3D[tempI+3].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-30000), D3DVAL(0));
 
}
	if (!buble_on[tempI]) if (randInt(1,100)==2) 
		{
	 buble_on[tempI]=true;
	 object3D[2].chase_far->GetPosition(d3drm.scene,&tempVector);
	 object3D[tempI+3].InitAnimation(&buble_an,tempVector.x,tempVector.y+7,tempVector.z+randInt(1,5)-5,1);
		}
	}

 }
 //---------------------------------------------------------
//����� ��������� ���������
