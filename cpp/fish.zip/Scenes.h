
BOOL		SceneInit		(void);

//==================================================
//
//	make the World Scene
//
//==================================================

BOOL SceneInit(void)
{
  
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpWorldFrame);
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpLightFrame);
	d3drm.D3DRM->CreateFrame(d3drm.scene, &lpWorldFrame2);


	lpLightFrame->SetPosition(d3drm.scene, D3DVAL(-9), D3DVAL(15), D3DVAL(9));
	
	d3drm.D3DRM->CreateLightRGB(D3DRMLIGHT_AMBIENT, D3DVAL(0.5), D3DVAL(0.5), D3DVAL(0.5), &lpLight);
	lpLightFrame->AddLight(*(&lpLight));
	
	d3drm.D3DRM->CreateLightRGB(D3DRMLIGHT_POINT, D3DVAL(1), D3DVAL(1), D3DVAL(1), &lpLight);
	lpLightFrame->AddLight(*(&lpLight));

  d3drm.camera->SetPosition(d3drm.scene, D3DVAL(camX), D3DVAL(camY), D3DVAL(camZ));
	d3drm.camera->SetOrientation(d3drm.scene, D3DVAL(camX),D3DVAL(camY),D3DVAL(camZ+10),
		D3DVAL(0), D3DVAL(1), D3DVAL(0));

//	d3drm.camera->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(0), D3DVAL(camZ));
//	d3drm.camera->SetOrientation(d3drm.scene, D3DVAL(0),D3DVAL(0),D3DVAL(10),
//		D3DVAL(0), D3DVAL(1), D3DVAL(0));

//	d3drm.camera->SetRotation(d3drm.scene,1,1,0,0.01);
//	d3drm.camera->SetRotation(d3drm.scene,1,1,0,1);
//	lpWorldFrame->SetRotation(d3drm.scene, D3DVAL(0.0), D3DVAL(1.0),
//		D3DVAL(0.0), D3DVAL(-0.05));
//  lpWorldFrame2->SetRotation(scene1, D3DVAL(0.0), D3DVAL(-1.0),
//		D3DVAL(0.0), D3DVAL(5));


// d3drm.D3DRM->LoadTexture ("textures\\sand.BMP", &texture2);


 d3drm.D3DRM->LoadTexture ("textures\\grib1.BMP", &texture1);
 d3drm.scene->SetSceneBackgroundImage((LPDIRECT3DRMTEXTURE)texture1);
 
 //texture1->SetDecalTransparency(true);

//d3drm.D3DRM->LoadTexture ("textures\\transp.BMP", &texture_transp);
//texture_transp->SetDecalTransparency(true);
 
 //d3drm.scene->SetSceneBackgroundRGB(D3DVAL(0.7),D3DVAL(0.3),D3DVAL(0.3));
// if (texture1->SetDecalTransparency(true))
//	MessageBox (hWnd, "back failed (%08lx)\n", "ERROR", MB_OK);

   


	d3drm.D3DRM->CreateWrap (D3DRMWRAP_FLAT, NULL,
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
		D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(1.0),
		&wrap1);

/*
	d3drm.D3DRM->CreateWrap (D3DRMWRAP_FLAT, NULL,
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
		D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
		D3DVAL(0.0), D3DVAL(0.0),
		D3DVAL(1.0), D3DVAL(1.0),
		&wrap2);

   d3drm.D3DRM->CreateWrap
	   (
	    D3DRMWRAP_CYLINDER, NULL,
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(1.0), D3DVAL(0.0),
        D3DVAL(0.0), D3DVAL(0.0), D3DVAL(1.0),
        D3DVAL(0.0), D3DVAL(0.0),
        D3DVAL(1.0), D3DVAL(1.0),
        &wrap3);
*/   

     srand( (unsigned)time( NULL ) ); // �������������� ��������� ��������� �����

	 object3D[0].LoadObject("models\\fish1.x",NULL,0,0);
	 object3D[0].mesh->Scale(1.95,1.95,1.95);
 	 object3D[1].LoadObject("models\\fish2.x",NULL,0,0);
	 object3D[1].mesh->Scale(1.95,1.95,1.95);
	 object3D[2].LoadObject("models\\fish1.x",NULL,1,1);
     fish_an.kolvo=5;
     fish_an.anima=pathp;

     buble_an.kolvo=3;
     buble_an.anima=path_buble;
   
     object3D[2].InitAnimation(&fish_an,0,0,0,1);
	 object3D[2].timeT=object3D[2].maxtimeT-1;
	 object3D[2].InitMorphing(object3D[0].mesh,object3D[1].mesh,0.1);
	 d3drm.camera->LookAt(object3D[2].frame,d3drm.scene,D3DRMCONSTRAIN_Z);

	 object3D[3].LoadObject("models\\sphere1.x",NULL,1,1); 
	 object3D[3].mesh->SetColor (D3DCOLOR (D3DRGBA(1, 1, 1, 0.2)));
	 object3D[3].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-30000), D3DVAL(0));
	 object3D[4].LoadObject("models\\sphere1.x",NULL,1,1); 
	 object3D[4].mesh->SetColor (D3DCOLOR (D3DRGBA(1, 1, 1, 0.2)));
	 object3D[4].mesh->Scale(0.85,0.85,0.85);
	 object3D[4].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-30000), D3DVAL(0));
     object3D[5].LoadObject("models\\sphere1.x",NULL,1,1); 
 	 object3D[5].mesh->SetColor (D3DCOLOR (D3DRGBA(1, 1, 1, 0.2)));
     object3D[5].mesh->Scale(0.7,0.7,0.7);
 	 object3D[5].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-30000), D3DVAL(0));

//	   d3drm.scene->SetSceneFogEnable(TRUE);
//     d3drm.scene->SetSceneFogParams(10, 100, 0.5);


 
//   hier[3].LoadObject("models\\square.x",texture1,1); 
//	 hier[3].frame->SetPosition(d3drm.scene, D3DVAL(0), D3DVAL(-3), D3DVAL(0));
 /*
     hier[3].mesh->SetTextureCoordinates(0,0.000000,1.000000);
     hier[3].mesh->SetTextureCoordinates(1,0.000000,0.000000);
     hier[3].mesh->SetTextureCoordinates(2,1.000000,0.000000);
     hier[3].mesh->SetTextureCoordinates(3,1.000000,1.000000);

*/

	return TRUE;

//================================================
//	End SceneInit
//================================================

};

