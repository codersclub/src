//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MFCSpline.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDR_SPLINETYPE                  129
#define IDC_CURSOR_CROSS                130
#define ID_POPUP_MENU                   131
#define ID_SPLINE_HERMITE               32771
#define ID_SPLINE_BEZIER                32772
#define ID_SLPINE_CARDINAL              32773
#define ID_SPLINE_TENSION_1             32775
#define ID_SPLINE_TENSION_2             32776
#define ID_SPLINE_TENSION_3             32777
#define ID_SPLINE_TENSION_4             32778
#define ID_SPLINE_TENSION_5             32779
#define ID_SPLINE_TENSION_6             32780
#define ID_SPLINE_TENSION_7             32781
#define ID_SPLINE_TENSION_8             32782
#define ID_SPLINE_TENSION_9             32783
#define ID_SPLINE_TENSION_10            32784
#define ID_SPLINE_TENSION_11            32785
#define ID_SPLINE_RESET                 32786
#define ID_SPLINE_SELECT_ANCHORPOINT1   32788
#define ID_SPLINE_SELECT_ANCHORPOINT2   32789
#define ID_SPLINE_SELECT_TANGENTPOINT1  32790
#define ID_SPLINE_SELECT_TANGENTPOINT2  32791

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_3D_CONTROLS                     1
#define _APS_NEXT_RESOURCE_VALUE        132
#define _APS_NEXT_COMMAND_VALUE         32792
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
