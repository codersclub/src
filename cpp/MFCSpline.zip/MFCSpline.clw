; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CMFCSplineView
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "MFCSpline.h"
LastPage=0

ClassCount=6
Class1=CMFCSplineApp
Class2=CMFCSplineDoc
Class3=CMFCSplineView
Class4=CMainFrame

ResourceCount=4
Resource1=ID_POPUP_MENU
Resource2=IDR_SPLINETYPE
Class5=CChildFrame
Class6=CAboutDlg
Resource3=IDR_MAINFRAME
Resource4=IDD_ABOUTBOX

[CLS:CMFCSplineApp]
Type=0
HeaderFile=MFCSpline.h
ImplementationFile=MFCSpline.cpp
Filter=N

[CLS:CMFCSplineDoc]
Type=0
HeaderFile=MFCSplineDoc.h
ImplementationFile=MFCSplineDoc.cpp
Filter=N
LastObject=CMFCSplineDoc

[CLS:CMFCSplineView]
Type=0
HeaderFile=MFCSplineView.h
ImplementationFile=MFCSplineView.cpp
Filter=C
BaseClass=CView
VirtualFilter=VWC
LastObject=CMFCSplineView


[CLS:CMainFrame]
Type=0
HeaderFile=MainFrm.h
ImplementationFile=MainFrm.cpp
Filter=T
LastObject=CMainFrame
BaseClass=CMDIFrameWnd
VirtualFilter=fWC


[CLS:CChildFrame]
Type=0
HeaderFile=ChildFrm.h
ImplementationFile=ChildFrm.cpp
Filter=M


[CLS:CAboutDlg]
Type=0
HeaderFile=MFCSpline.cpp
ImplementationFile=MFCSpline.cpp
Filter=D
LastObject=CAboutDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[MNU:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_PRINT_SETUP
Command4=ID_FILE_MRU_FILE1
Command5=ID_APP_EXIT
Command6=ID_VIEW_TOOLBAR
Command7=ID_VIEW_STATUS_BAR
Command8=ID_APP_ABOUT
CommandCount=8

[TB:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_EDIT_CUT
Command5=ID_EDIT_COPY
Command6=ID_EDIT_PASTE
Command7=ID_FILE_PRINT
Command8=ID_APP_ABOUT
CommandCount=8

[MNU:IDR_SPLINETYPE]
Type=1
Class=CMFCSplineView
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_CLOSE
Command4=ID_FILE_SAVE
Command5=ID_FILE_SAVE_AS
Command6=ID_FILE_PRINT
Command7=ID_FILE_PRINT_PREVIEW
Command8=ID_FILE_PRINT_SETUP
Command9=ID_FILE_MRU_FILE1
Command10=ID_APP_EXIT
Command11=ID_EDIT_UNDO
Command12=ID_EDIT_CUT
Command13=ID_EDIT_COPY
Command14=ID_EDIT_PASTE
Command15=ID_VIEW_TOOLBAR
Command16=ID_VIEW_STATUS_BAR
Command17=ID_SPLINE_HERMITE
Command18=ID_SPLINE_BEZIER
Command19=ID_SLPINE_CARDINAL
Command20=ID_SPLINE_TENSION_1
Command21=ID_SPLINE_TENSION_2
Command22=ID_SPLINE_TENSION_3
Command23=ID_SPLINE_TENSION_4
Command24=ID_SPLINE_TENSION_5
Command25=ID_SPLINE_TENSION_6
Command26=ID_SPLINE_TENSION_7
Command27=ID_SPLINE_TENSION_8
Command28=ID_SPLINE_TENSION_9
Command29=ID_SPLINE_TENSION_10
Command30=ID_SPLINE_TENSION_11
Command31=ID_SPLINE_SELECT_ANCHORPOINT1
Command32=ID_SPLINE_SELECT_ANCHORPOINT2
Command33=ID_SPLINE_SELECT_TANGENTPOINT1
Command34=ID_SPLINE_SELECT_TANGENTPOINT2
Command35=ID_SPLINE_RESET
Command36=ID_WINDOW_NEW
Command37=ID_WINDOW_CASCADE
Command38=ID_WINDOW_TILE_HORZ
Command39=ID_WINDOW_ARRANGE
Command40=ID_APP_ABOUT
CommandCount=40

[ACL:IDR_MAINFRAME]
Type=1
Class=CMainFrame
Command1=ID_FILE_NEW
Command2=ID_FILE_OPEN
Command3=ID_FILE_SAVE
Command4=ID_FILE_PRINT
Command5=ID_EDIT_UNDO
Command6=ID_EDIT_CUT
Command7=ID_EDIT_COPY
Command8=ID_EDIT_PASTE
Command9=ID_EDIT_UNDO
Command10=ID_EDIT_CUT
Command11=ID_EDIT_COPY
Command12=ID_EDIT_PASTE
Command13=ID_NEXT_PANE
Command14=ID_PREV_PANE
CommandCount=14

[MNU:ID_POPUP_MENU]
Type=1
Class=?
Command1=ID_SPLINE_HERMITE
Command2=ID_SPLINE_BEZIER
Command3=ID_SLPINE_CARDINAL
Command4=ID_SPLINE_TENSION_1
Command5=ID_SPLINE_TENSION_2
Command6=ID_SPLINE_TENSION_3
Command7=ID_SPLINE_TENSION_4
Command8=ID_SPLINE_TENSION_5
Command9=ID_SPLINE_TENSION_6
Command10=ID_SPLINE_TENSION_7
Command11=ID_SPLINE_TENSION_8
Command12=ID_SPLINE_TENSION_9
Command13=ID_SPLINE_TENSION_10
Command14=ID_SPLINE_TENSION_11
Command15=ID_SPLINE_SELECT_ANCHORPOINT1
Command16=ID_SPLINE_SELECT_ANCHORPOINT2
Command17=ID_SPLINE_SELECT_TANGENTPOINT1
Command18=ID_SPLINE_SELECT_TANGENTPOINT2
Command19=ID_SPLINE_RESET
CommandCount=19

