// MFCSplineDoc.cpp : implementation of the CMFCSplineDoc class
//

#include "stdafx.h"
#include "MFCSpline.h"

#include "MFCSplineDoc.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMFCSplineDoc

IMPLEMENT_DYNCREATE(CMFCSplineDoc, CDocument)

BEGIN_MESSAGE_MAP(CMFCSplineDoc, CDocument)
	//{{AFX_MSG_MAP(CMFCSplineDoc)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCSplineDoc construction/destruction

CMFCSplineDoc::CMFCSplineDoc()
{
	// TODO: add one-time construction code here

}

CMFCSplineDoc::~CMFCSplineDoc()
{
}

BOOL CMFCSplineDoc::OnNewDocument()
{
	if (!CDocument::OnNewDocument())
		return FALSE;

	// TODO: add reinitialization code here
	// (SDI documents will reuse this document)

	return TRUE;
}



/////////////////////////////////////////////////////////////////////////////
// CMFCSplineDoc serialization

void CMFCSplineDoc::Serialize(CArchive& ar)
{
	if (ar.IsStoring())
	{
		// TODO: add storing code here
	}
	else
	{
		// TODO: add loading code here
	}
}

/////////////////////////////////////////////////////////////////////////////
// CMFCSplineDoc diagnostics

#ifdef _DEBUG
void CMFCSplineDoc::AssertValid() const
{
	CDocument::AssertValid();
}

void CMFCSplineDoc::Dump(CDumpContext& dc) const
{
	CDocument::Dump(dc);
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMFCSplineDoc commands
