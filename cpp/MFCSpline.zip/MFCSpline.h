// MFCSpline.h : main header file for the MFCSPLINE application
//

#if !defined(AFX_MFCSPLINE_H__DDAC7147_60B5_11D4_BEC3_9622C4809045__INCLUDED_)
#define AFX_MFCSPLINE_H__DDAC7147_60B5_11D4_BEC3_9622C4809045__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CMFCSplineApp:
// See MFCSpline.cpp for the implementation of this class
//

class CMFCSplineApp : public CWinApp
{
public:
	CMFCSplineApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCSplineApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CMFCSplineApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCSPLINE_H__DDAC7147_60B5_11D4_BEC3_9622C4809045__INCLUDED_)
