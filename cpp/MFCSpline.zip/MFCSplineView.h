// MFCSplineView.h : interface of the CMFCSplineView class
//
/////////////////////////////////////////////////////////////////////////////

/*##################################################################

  Author:	Masoud Samimi
  Website:	www.geocities.com/samimi73
  Email:	marcello43@hotmail.com

  Program:	MFC Spline Drawing Demo Application
  
  History:	Original code found from 
			http://www.planet-source-code.com as a GLUT based Spline Drawing Application
			as their copyright appears below.

			It was ported to MFC vesrsion by myself on 22.07.2000 (dd.mm.yy)
  
  Purpose: Please visit my website, it is expalined there.
  

Important Notice:

	This Idea and the Application is Copyright(c) Masoud Samimi 1999,2000.
	You can freely use it as long as you credit me for it.

	No guarantee/warantee is given on this app and I will not be responsible 
	for any damage to you, your property or any other person from using it.
	USE IT ON YOUR OWN RISK.

	Thankyou and have FUNNE =-)

	Masoud Samimi.


  Original source code:

    //**************************************
    // Name: OpenGL Spine drawing app
    // Description:It's a Spline Drawing Application that uses the OpenGL Libraries. I used the GLUT event handler interface to control Mouse functions.You will Need:
    // OpenGL
    // Glut
    // and a C++ compiler
    // Found at: http://modzer0.cs.uaf.edu/~hartsock/C_Cpp/OpenGL/Splines.html
    // By: Found on the World Wide Web
    //
    //
    // Inputs:None
    //
    // Returns:None
    //
    //Assumes:None
    //
    //Side Effects:None
    //
    //Warranty:
    //Code provided by Planet Source Code(tm) (http://www.Planet-Source-Code.com) 'as is', without warranties as to performance, fitness, merchantability,and any other warranty (whether expressed or implied).
    //**************************************
    
    /************************************************************************\
    |	
    |	Shawn R. Hartsock
    |	CS 381
    |	Prof: Hartman
    |	due: 11/4/1998
    |
    |	Splines.c
    |		Draws Splines!
    |		Menus: Spline Type, Tension, Reset, Quit
    |		Keys : z,x,i,j,k,l,1,2,3
    |Point: Drag to move spline points
    |Rainbows free of charge.
    | The color (rainbow) allows you to observe the "speed" at which
    | the points are moving along the line toward the end point.
    | Negative tension causes the control points to be weighted heavier...
    | Positive tension up to 1.0 causes the control points to be weighted
    | less, and a tension of 1.0 means that the control points are ignored.
    | A tension of MORE than 1.0 means that the control points "push" the
    | line rather than "pull" it, or vice versa (cardinal spline)... a
    | Positive value greater than 1.0 makes the control points weighted
    | NEGATIVELY.
    \************************************************************************/

//##################################################################


#if !defined(AFX_MFCSPLINEVIEW_H__DDAC7151_60B5_11D4_BEC3_9622C4809045__INCLUDED_)
#define AFX_MFCSPLINEVIEW_H__DDAC7151_60B5_11D4_BEC3_9622C4809045__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CMFCSplineView : public CView
{
protected: // create from serialization only
	CMFCSplineView();
	DECLARE_DYNCREATE(CMFCSplineView)

// Attributes
public:
	CMFCSplineDoc* GetDocument();

// Operations
public:


	HGLRC m_hRC;			// Rendering Context
	HDC m_hDC;				// Device Context
	CPalette m_GLPalette;	// Logical Palette
	
	BOOL m_bDisplayErrorMessages;
	
	///////////////////////////
	HPALETTE	m_hPalette,
				m_hPalette2;

	float m_WHRatio;

	CPoint m_ptLMouse;
	BOOL m_bLMouseDown;

	BOOL EnableRC(HDC m_hDC, HGLRC m_hRC, BOOL bEnable);
	
	void MainRenderScene();

	void InitializePalette(void);


//############################################################//
//	Spline Data
	
	int m_nSelectedPoint, m_nMovePoint;
	
	double m_dTension;
	
    double m_dScale;
    double T_Y, T_X;


//	End
//############################################################//

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCSplineView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);
	//}}AFX_VIRTUAL

// Implementation
public:
	void DrawSpline(void);
	void MakeSpline(void);
	double EndTangent(int i);
	double StartTangent(int i);
	double EndPoint(int i);
	double StartPoint(int i);
	void DrawArrows(double w1[2], double w2[2]);
	void DrawPoints(void);
	virtual ~CMFCSplineView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CMFCSplineView)
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnDestroy();
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg BOOL OnQueryNewPalette();
	afx_msg void OnPaletteChanged(CWnd* pFocusWnd);
	afx_msg void OnSplineTension1();
	afx_msg void OnSplineTension2();
	afx_msg void OnSplineTension3();
	afx_msg void OnSplineTension4();
	afx_msg void OnSplineTension5();
	afx_msg void OnSplineTension6();
	afx_msg void OnSplineTension7();
	afx_msg void OnSplineTension8();
	afx_msg void OnSplineTension9();
	afx_msg void OnSplineTension10();
	afx_msg void OnSplineTension11();
	afx_msg void OnUpdateSplineTension1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension3(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension4(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension5(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension6(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension7(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension8(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension9(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension10(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineTension11(CCmdUI* pCmdUI);
	afx_msg void OnSplineReset();
	afx_msg void OnSlpineCardinal();
	afx_msg void OnSplineBezier();
	afx_msg void OnSplineHermite();
	afx_msg void OnUpdateSlpineCardinal(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineBezier(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineHermite(CCmdUI* pCmdUI);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnSplineSelectAnchorpoint1();
	afx_msg void OnSplineSelectAnchorpoint2();
	afx_msg void OnSplineSelectTangentpoint1();
	afx_msg void OnSplineSelectTangentpoint2();
	afx_msg void OnUpdateSplineSelectAnchorpoint1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineSelectAnchorpoint2(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineSelectTangentpoint1(CCmdUI* pCmdUI);
	afx_msg void OnUpdateSplineSelectTangentpoint2(CCmdUI* pCmdUI);
	afx_msg void OnContextMenu(CWnd* pWnd, CPoint point);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in MFCSplineView.cpp
inline CMFCSplineDoc* CMFCSplineView::GetDocument()
   { return (CMFCSplineDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MFCSPLINEVIEW_H__DDAC7151_60B5_11D4_BEC3_9622C4809045__INCLUDED_)
