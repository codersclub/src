//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by TestMcTransBlit.rc
//
#define IDD_TESTMCTRANSBLIT_DIALOG      102
#define IDR_MAINFRAME                   128
#define IDB_BITMAP1                     129
#define IDB_BITMAP2                     130
#define IDB_BITMAP3                     131
#define IDB_BITMAP4                     132
#define IDB_BITMAP5                     134
#define IDB_BITMAPTEST                  134
#define IDC_1CRADIO                     1005
#define IDC_16CRADIO                    1006
#define IDC_256CRADIO                   1007
#define IDC_HICRADIO                    1008
#define IDC_LZRADIO                     1011
#define IDC_NZRADIO                     1012
#define IDC_MZRADIO                     1013
#define IDC_PICTURE                     1014
#define IDC_REDIT                       1015
#define IDC_GEDIT                       1016
#define IDC_BEDIT                       1017
#define IDC_RSPIN                       1018
#define IDC_GSPIN                       1019
#define IDC_BSPIN                       1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        135
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1019
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
