// TestMcTransBlit.h : main header file for the TESTMCTRANSBLIT application
//

#if !defined(AFX_TESTMCTRANSBLIT_H__8B3B7D7F_9E7C_4325_9E30_A03458F21775__INCLUDED_)
#define AFX_TESTMCTRANSBLIT_H__8B3B7D7F_9E7C_4325_9E30_A03458F21775__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CTestMcTransBlitApp:
// See TestMcTransBlit.cpp for the implementation of this class
//

class CTestMcTransBlitApp : public CWinApp
{
public:
	CTestMcTransBlitApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestMcTransBlitApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CTestMcTransBlitApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTMCTRANSBLIT_H__8B3B7D7F_9E7C_4325_9E30_A03458F21775__INCLUDED_)
