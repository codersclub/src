// TestMcTransBlitDlg.cpp : implementation file
//

#include "stdafx.h"
#include "TestMcTransBlit.h"
#include "TestMcTransBlitDlg.h"
#include "McTransparentBlit.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CTestMcTransBlitDlg dialog

CTestMcTransBlitDlg::CTestMcTransBlitDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CTestMcTransBlitDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CTestMcTransBlitDlg)
	m_TransparentColor = 0xff00ff;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CTestMcTransBlitDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CTestMcTransBlitDlg)
	DDX_Control(pDX, IDC_GSPIN, m_GSpin);
	DDX_Control(pDX, IDC_RSPIN, m_RSpin);
	DDX_Control(pDX, IDC_BSPIN, m_BSpin);
	DDX_Control(pDX, IDC_PICTURE, m_PictureRect);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CTestMcTransBlitDlg, CDialog)
	//{{AFX_MSG_MAP(CTestMcTransBlitDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_BEDIT, OnChangeBedit)
	ON_EN_CHANGE(IDC_GEDIT, OnChangeGedit)
	ON_EN_CHANGE(IDC_REDIT, OnChangeRedit)
	ON_BN_CLICKED(IDC_1CRADIO, On1cradio)
	ON_BN_CLICKED(IDC_256CRADIO, On256cradio)
	ON_BN_CLICKED(IDC_HICRADIO, OnHicradio)
	ON_BN_CLICKED(IDC_16CRADIO, On16cradio)
	ON_BN_CLICKED(IDC_LZRADIO, OnLzradio)
	ON_BN_CLICKED(IDC_MZRADIO, OnMzradio)
	ON_BN_CLICKED(IDC_NZRADIO, OnNzradio)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CTestMcTransBlitDlg message handlers

BOOL CTestMcTransBlitDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	
	m_RSpin.SetBuddy(GetDlgItem(IDC_REDIT));
	m_RSpin.SetRange(0,255);
	m_RSpin.SetPos(255);
	
	m_GSpin.SetBuddy(GetDlgItem(IDC_GEDIT));
	m_GSpin.SetRange(0,255);
	m_GSpin.SetPos(0);
	
	m_BSpin.SetBuddy(GetDlgItem(IDC_BEDIT));
	m_BSpin.SetRange(0,255);
	m_BSpin.SetPos(255);

	CheckRadioButton(IDC_1CRADIO,IDC_HICRADIO,IDC_HICRADIO);
	CheckRadioButton(IDC_LZRADIO,IDC_MZRADIO,IDC_NZRADIO);

	UpdateData(FALSE);
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.


void CTestMcTransBlitDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		//CDialog::OnPaint();
		CPaintDC dc(this); // device context for painting
		
		CDC BmpDc;
		BmpDc.CreateCompatibleDC(&dc);
		CBitmap Bmp;

		switch(GetCheckedRadioButton(IDC_1CRADIO,IDC_HICRADIO))
		{
		case IDC_1CRADIO:
			Bmp.LoadBitmap(IDB_BITMAP4);
			break;
		case IDC_16CRADIO:
			Bmp.LoadBitmap(IDB_BITMAP2);
			break;
		case IDC_256CRADIO:
			Bmp.LoadBitmap(IDB_BITMAP1);
			break;
		case IDC_HICRADIO:
			Bmp.LoadBitmap(IDB_BITMAP3);
			break;
		}
		
		BmpDc.SelectObject(&Bmp);

		CRect PicRect;
		m_PictureRect.GetWindowRect(&PicRect);
		ScreenToClient(&PicRect);

		CBrush br;
		br.CreateHatchBrush(HS_DIAGCROSS,0x0000ff);
		dc.SetBkColor(0xffffff);
		dc.FillRect(CRect(PicRect.left-10,PicRect.top-10,PicRect.right+10,PicRect.bottom+10),&br);

		switch(GetCheckedRadioButton(IDC_LZRADIO,IDC_MZRADIO))
		{
		case IDC_LZRADIO:
			McTransparentBlt(dc.GetSafeHdc(),PicRect.left,PicRect.top,PicRect.Width()/2,PicRect.Height()/2,
				BmpDc.GetSafeHdc(),0,0,320,200,m_TransparentColor);
			break;
		case IDC_NZRADIO:
			McTransparentBlt(dc.GetSafeHdc(),PicRect.left,PicRect.top,PicRect.Width(),PicRect.Height(),
				BmpDc.GetSafeHdc(),0,0,320,200,m_TransparentColor);
			//McTransparentBlt(dc.GetSafeHdc(),0,0,16,16,
			//	BmpDc.GetSafeHdc(),32,0,16,16,m_TransparentColor);
			break;
		case IDC_MZRADIO:
			McTransparentBlt(dc.GetSafeHdc(),PicRect.left,PicRect.top,PicRect.Width(),PicRect.Height(),
				BmpDc.GetSafeHdc(),0,0,160,100,m_TransparentColor);
			break;
		}
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CTestMcTransBlitDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CTestMcTransBlitDlg::OnOK() 
{
	// TODO: Add extra validation here
	
	//CDialog::OnOK();
}


void CTestMcTransBlitDlg::OnChangeBedit() 
{
	UpdateData();
	m_TransparentColor = RGB(m_RSpin.GetPos(),m_GSpin.GetPos(),m_BSpin.GetPos());
	Invalidate();
}

void CTestMcTransBlitDlg::OnChangeGedit() 
{
	OnChangeBedit() ;
}

void CTestMcTransBlitDlg::OnChangeRedit() 
{
	OnChangeBedit() ;
}

void CTestMcTransBlitDlg::On1cradio() 
{
	Invalidate();
}

void CTestMcTransBlitDlg::On256cradio() 
{
	Invalidate();	
}

void CTestMcTransBlitDlg::OnHicradio() 
{
	Invalidate();	
}

void CTestMcTransBlitDlg::On16cradio() 
{
	Invalidate();	
}

void CTestMcTransBlitDlg::OnLzradio() 
{
	Invalidate();		
}

void CTestMcTransBlitDlg::OnMzradio() 
{
	Invalidate();			
}

void CTestMcTransBlitDlg::OnNzradio() 
{
		Invalidate();		
	
}
