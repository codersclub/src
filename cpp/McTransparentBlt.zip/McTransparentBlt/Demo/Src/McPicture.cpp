// McPicture.cpp : implementation file
//

#include "stdafx.h"
#include "TestMcTransBlit.h"
#include "McPicture.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// McPicture

McPicture::McPicture()
{
}

McPicture::~McPicture()
{
}


BEGIN_MESSAGE_MAP(McPicture, CStatic)
	//{{AFX_MSG_MAP(McPicture)
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// McPicture message handlers

void McPicture::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	
	// Do not call CStatic::OnPaint() for painting messages
}
