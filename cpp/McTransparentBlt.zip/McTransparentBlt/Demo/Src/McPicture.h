#if !defined(AFX_MCPICTURE_H__65BE4E54_0B1E_43BA_B19A_9F807DE4078C__INCLUDED_)
#define AFX_MCPICTURE_H__65BE4E54_0B1E_43BA_B19A_9F807DE4078C__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// McPicture.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// McPicture window

class McPicture : public CStatic
{
// Construction
public:
	McPicture();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(McPicture)
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~McPicture();

	// Generated message map functions
protected:
	//{{AFX_MSG(McPicture)
	afx_msg void OnPaint();
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MCPICTURE_H__65BE4E54_0B1E_43BA_B19A_9F807DE4078C__INCLUDED_)
