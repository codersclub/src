// TestMcTransBlitDlg.h : header file
//

#if !defined(AFX_TESTMCTRANSBLITDLG_H__082F6EAA_E012_42BC_8384_462364EC05FE__INCLUDED_)
#define AFX_TESTMCTRANSBLITDLG_H__082F6EAA_E012_42BC_8384_462364EC05FE__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CTestMcTransBlitDlg dialog

class CTestMcTransBlitDlg : public CDialog
{
// Construction
public:
	CTestMcTransBlitDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CTestMcTransBlitDlg)
	enum { IDD = IDD_TESTMCTRANSBLIT_DIALOG };
	CSpinButtonCtrl	m_GSpin;
	CSpinButtonCtrl	m_RSpin;
	CSpinButtonCtrl	m_BSpin;
	CStatic	m_PictureRect;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CTestMcTransBlitDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	COLORREF	m_TransparentColor;
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CTestMcTransBlitDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	virtual void OnOK();
	afx_msg void OnChangeBedit();
	afx_msg void OnChangeGedit();
	afx_msg void OnChangeRedit();
	afx_msg void On1cradio();
	afx_msg void On256cradio();
	afx_msg void OnHicradio();
	afx_msg void On16cradio();
	afx_msg void OnLzradio();
	afx_msg void OnMzradio();
	afx_msg void OnNzradio();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_TESTMCTRANSBLITDLG_H__082F6EAA_E012_42BC_8384_462364EC05FE__INCLUDED_)
