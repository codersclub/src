// childdlgDlg.cpp : implementation file
//

#include "stdafx.h"
#include "childdlg.h"
#include "childdlgDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChilddlgDlg dialog

CChilddlgDlg::CChilddlgDlg(CWnd* pParent /*=NULL*/)
	: CMultiDialog(CChilddlgDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CChilddlgDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CChilddlgDlg::DoDataExchange(CDataExchange* pDX)
{
	CMultiDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CChilddlgDlg)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CChilddlgDlg, CMultiDialog)
	//{{AFX_MSG_MAP(CChilddlgDlg)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_EN_CHANGE(IDC_EDIT1, OnChangeEdit1)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CChilddlgDlg message handlers

BOOL CChilddlgDlg::OnInitDialog()
{
	CMultiDialog::OnInitDialog();

	// Embed the dialog
	AddDialog( IDD_DIALOG1, IDC_MARKER );

	m_pListBox = (CListBox*) GetDlgItem( IDC_LIST1 );
	if ( m_pListBox ) {
		m_pListBox->AddString( "First" );
		m_pListBox->AddString( "Second" );
		m_pListBox->AddString( "Third" );
	}

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CChilddlgDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CMultiDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CChilddlgDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CChilddlgDlg::OnChangeEdit1() 
{
	MessageBox(_T("The edit box was changed"), 
		_T("Information"),
		MB_ICONEXCLAMATION|MB_OK|MB_DEFBUTTON1);
}
