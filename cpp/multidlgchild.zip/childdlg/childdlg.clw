; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CChilddlgApp
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "childdlg.h"
LastPage=0

ClassCount=2
Class1=CChilddlgApp
Class2=CChilddlgDlg

ResourceCount=2
Resource1=IDD_CHILDDLG_DIALOG (English (U.S.))
Resource2=IDD_DIALOG1

[CLS:CChilddlgApp]
Type=0
BaseClass=CWinApp
HeaderFile=childdlg.h
ImplementationFile=childdlg.cpp
LastObject=CChilddlgApp

[CLS:CChilddlgDlg]
Type=0
BaseClass=CMultiDialog
HeaderFile=childdlgDlg.h
ImplementationFile=childdlgDlg.cpp
Filter=D
VirtualFilter=dWC

[DLG:IDD_CHILDDLG_DIALOG]
Type=1
Class=CChilddlgDlg

[DLG:IDD_CHILDDLG_DIALOG (English (U.S.))]
Type=1
Class=?
ControlCount=3
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_MARKER,static,1350696960

[DLG:IDD_DIALOG1]
Type=1
Class=?
ControlCount=8
Control1=IDC_EDIT1,edit,1350631552
Control2=IDC_BUTTON1,button,1342242816
Control3=IDC_BUTTON2,button,1342242816
Control4=IDC_RADIO1,button,1342373897
Control5=IDC_RADIO2,button,1342177289
Control6=IDC_RADIO3,button,1342177289
Control7=IDC_CHECK1,button,1342242819
Control8=IDC_LIST1,listbox,1352728835

