// childdlgDlg.h : header file
//

#if !defined(AFX_CHILDDLGDLG_H__588F8F3F_9551_4266_A511_D0B5AA3E67C5__INCLUDED_)
#define AFX_CHILDDLGDLG_H__588F8F3F_9551_4266_A511_D0B5AA3E67C5__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChilddlgDlg dialog

#include "MultiDialog.h"

class CChilddlgDlg : public CMultiDialog
{
// Construction
public:
	CChilddlgDlg(CWnd* pParent = NULL);	// standard constructor
	CListBox *m_pListBox;

// Dialog Data
	//{{AFX_DATA(CChilddlgDlg)
	enum { IDD = IDD_CHILDDLG_DIALOG };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CChilddlgDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CChilddlgDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnChangeEdit1();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_CHILDDLGDLG_H__588F8F3F_9551_4266_A511_D0B5AA3E67C5__INCLUDED_)
