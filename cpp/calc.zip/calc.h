// calc.h: interface for the calc class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALC_H__6A4E1DAB_17C8_11D5_AC0B_CA6C60B40A0B__INCLUDED_)
#define AFX_CALC_H__6A4E1DAB_17C8_11D5_AC0B_CA6C60B40A0B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
//������������ ��� ����������
#include "string.h"
#include <ctype.h>
#include "math.h"
class calc  
{
public:
	double proceed();
	void SetFunction(char* lpszCommand);
	calc(char* lpszCommand);
	calc();
//	enum Errors {DIVZERO, MISSBRACKET, MATHERROR, NOEXPR,NOFUNC};
	//errors
	struct divzero{};
	struct SyntaxError
	{
		const char* p;
		SyntaxError(const char* q){p=q;}
	};
	struct MathError
	{
		const char* p;
		MathError(const char* q){p=q;}
	};

	virtual ~calc();
private:
	virtual	void GetToken();
	double mul_div();
	enum Tok_Type {UNDEF, NUMBER, OPERATOR, FUNC, END};
	Tok_Type CurrTok;
protected:
	char* pCurrPos;
	char TokenValue[16];
	double add_sub();
	char Function[255];
	virtual double prim();
};

#endif // !defined(AFX_CALC_H__6A4E1DAB_17C8_11D5_AC0B_CA6C60B40A0B__INCLUDED_)
