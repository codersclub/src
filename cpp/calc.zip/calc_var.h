// calc_var.h: interface for the calc_var class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_CALC_VAR_H__1B037B01_1962_11D5_AC0B_C5A1B84D1E0B__INCLUDED_)
#define AFX_CALC_VAR_H__1B037B01_1962_11D5_AC0B_C5A1B84D1E0B__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "calc.h"


class calc_var : public calc  
{
public:
	double proceed();
	enum Tok_Type {UNDEF, NUMBER, OPERATOR, FUNC, END, VARIABLE, PRINT};
	void ClearVars();
	calc_var(char* lpszFunction);
	calc_var();
	virtual ~calc_var();
private:
	Tok_Type CurrTok;
	void GetToken();
	double prim();

protected:
	double variables[26];
};

#endif // !defined(AFX_CALC_VAR_H__1B037B01_1962_11D5_AC0B_C5A1B84D1E0B__INCLUDED_)
