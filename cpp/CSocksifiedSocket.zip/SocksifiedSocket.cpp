/* CSocksifiedSocket class by Tim Kosse (Tim.Kosse@gmx.de)
Version 1.0 - 04/28/2001
This class is a CSocket derived class. With this class you
can connect through SOCKS4/5 proxies. Basically you only
have to call one extra function to connect to a server
through an proxy:
void SetProxy(int nProxyType,CString ProxyHost,int ProxyPort,
    CString ProxyUser="",CString ProxyPass="",BOOL bUseSocks5Logon=FALSE);

Call this function if you want to use the extra proxy functionallity.
Parametes:
- nProxyType specifies the Proxy Type, either PROXYTYPE_SOCKS4
  or PROXYTYPE_SOCKS5
- the next 2 parameters specify the proxy
- the last 3 parameters are optional. They specify if SOCKS5
  authentication should be enabled and alsp specify the user and
  logon password.

There are also some other functions:

GetProxyPeerName
Like GetPeerName of CAsyncSocket, but returns the address of the
server connected through the proxy.	If using proxies, GetPeerName 
only returns the address of the proxy.

BOOL IsSocksified();
Is a proxy used?

const int GetLastProxyError() const;
Returns the last proxy error

If you want to use this CSocksifiedSocket as listen socket, you
have to use this overloaded function:
virtual BOOL Listen(unsigned long serverIp,unsigned long &retProxyIp,int &retProxyPort);
serverIP is the IP of the server you are already connected 
through the SOCKS proxy. You can't use listen sockets over a
SOCKS proxy without a primary connection.
retProxyIp returns the ip of the listening socket on the proxy,
retProxyPort the port. You have to send these values to the
server so that it can connect to the proxy.
Call Accept without any parameters before you use the socket.

For more information about SOCKS4/5 goto 
http://www.socks.nec.com/socksprot.html

The overloaded Accept function can alse be called without a parameter
for sockets using a direct connection. In this case the Listen socket
itself becomes the accepted socket.

To change the base class of CSocksifiedSocket, change the definition
of CSocksifiedBaseClass in SocksifiedSocket.h

This class is fully compatible with CTimeoutSocket which can also
be found on http://www.codeguru.com

You can download this class from http://www.codeguru.com
This class is used within FileZilla, an opensource MFC FTP 
client. It can be found on 
http://www.sourceforge.com/projects/filezilla

Feel free to use and modify this class as needed, as long as 
this text remains unchanged within the modified source files.
*/

// SocksifiedSocket.cpp: Implementierungsdatei
//

#include "stdafx.h"
#include "SocksifiedSocket.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSocksifiedSocket

CSocksifiedSocket::CSocksifiedSocket()
{
	m_nProxyType=0;
}

CSocksifiedSocket::~CSocksifiedSocket()
{
}

BOOL CSocksifiedSocket::Connect( LPCTSTR lpszHostAddress, UINT nHostPort )
{
	if (!m_nProxyType)
		//Connect normally because there is no proxy
		return CSocksifiedBaseClass::Connect(lpszHostAddress, nHostPort);
	
	//Translate the host address
	ASSERT(lpszHostAddress != NULL);

	SOCKADDR_IN sockAddr;
	memset(&sockAddr,0,sizeof(sockAddr));

	sockAddr.sin_family = AF_INET;
	sockAddr.sin_addr.s_addr = inet_addr(lpszHostAddress);

	if (sockAddr.sin_addr.s_addr == INADDR_NONE)
	{
		LPHOSTENT lphost;
		lphost = gethostbyname(lpszHostAddress);
		if (lphost != NULL)
			sockAddr.sin_addr.s_addr = ((LPIN_ADDR)lphost->h_addr)->s_addr;
		else
		{
			WSASetLastError(WSAEINVAL);
			return FALSE;
		}
	}

	sockAddr.sin_port = htons((u_short)nHostPort);

	return Connect((SOCKADDR*)&sockAddr, sizeof(sockAddr));
	
}

BOOL CSocksifiedSocket::Connect( const SOCKADDR* lpSockAddr, int nSockAddrLen )
{
	if (!m_nProxyType)
		//Connect normally because there is no proxy
		return CSocksifiedBaseClass::Connect(lpSockAddr, nSockAddrLen );
	
	//Conect to proxy server
	if (!CSocksifiedBaseClass::Connect(m_ProxyHost,m_nProxyPort))
	{
		m_nProxyError=PROXYERROR_NOCONN;
		return FALSE;
	}

	LPSOCKADDR_IN sockAddr=(LPSOCKADDR_IN)lpSockAddr;

	//Save server details
	m_nProxyPeerIp=sockAddr->sin_addr.S_un.S_addr;
	m_nProxyPeerPort=sockAddr->sin_port;

	if (m_nProxyType==PROXYTYPE_SOCKS4)
	{ //SOCKS4 proxy

		//Send request
		char command[9];
		memset(command,0,9);
		command[0]=4;
		command[1]=1;
		memcpy(&command[2],&sockAddr->sin_port,2);
		memcpy(&command[4],&sockAddr->sin_addr.S_un.S_addr,4);
		TRY
		{
			Send(command,9,0);
			//Get response
			int num=Receive(command,8);
			if (num!=8)
			{
				m_nProxyError=PROXYERROR_REQUESTFAILED;
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]!=90)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
	}
	else
	{ //SOCKS5 proxy
		//Send initialization request
		unsigned char command[10];
		memset(command,0,10);
		command[0]=5;
		command[1]=m_bUseSocks5Logon?2:1;
		command[2]=m_bUseSocks5Logon?2:0;
		TRY
		{
			Send(command,m_bUseSocks5Logon?4:3,0);
			//Get initialization response
			int num=Receive(command,2);
			if (num!=2)
			{
				m_nProxyError=PROXYERROR_REQUESTFAILED;
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]==0xFF)
		{
			m_nProxyError=PROXYERROR_AUTHREQUIRED;
			return FALSE;
		}
		if (command[1])
		{
			if (command[1]!=2)
			{
				m_nProxyError=PROXYERROR_AUTHTYPEUNKNOWN;
				return FALSE;
			}
			if (m_bUseSocks5Logon)
			{
				//Send authentication
				unsigned char *buffer=new unsigned char[3+m_ProxyUser.GetLength()+m_ProxyPass.GetLength()+0];
				sprintf((char *)buffer,"  %s %s",m_ProxyUser,m_ProxyPass);
				buffer[0]=5;
				buffer[1]=m_ProxyUser.GetLength();
				buffer[2+m_ProxyUser.GetLength()]=m_ProxyPass.GetLength();
				TRY
				{
					Send(command,3+m_ProxyUser.GetLength()+m_ProxyPass.GetLength(),0);
					//Get auth response
					int num=Receive(command,2);
					if (num!=2)
					{
						m_nProxyError=PROXYERROR_AUTHFAILED;
						return FALSE;
					}
				}
				CATCH_ALL(e)
				{
					m_nProxyError=PROXYERROR_AUTHFAILED;
					return FALSE;
				}
				END_CATCH_ALL
				if (command[1]!=0x00)
				{
					m_nProxyError=PROXYERROR_AUTHFAILED;
					return FALSE;
				}	
			}
			else
			{
				m_nProxyError=PROXYERROR_AUTHNOLOGON;
				return FALSE;
			}
		}
		//Send request
		memset(command,0,10);
		command[0]=5;
		command[1]=1;
		command[2]=0;
		command[3]=1;
		memcpy(&command[4],&sockAddr->sin_addr.S_un.S_addr,4);
		memcpy(&command[8],&sockAddr->sin_port,2);
		TRY
		{
			Send(command,10,0);
			//Get response
			int num=Receive(command,10);
			if (num!=10)
			{
				m_nProxyError=PROXYERROR_REQUESTFAILED;
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]!=0x00)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		
	}

	//It worked! SOCKS is really easy, isn't it?
	return TRUE;
}



//Die folgenden Zeilen nicht bearbeiten. Sie werden vom Klassen-Assistenten ben�tigt.
#if 0
BEGIN_MESSAGE_MAP(CSocksifiedSocket, CSocksifiedBaseClass)
	//{{AFX_MSG_MAP(CSocksifiedSocket)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()
#endif	// 0

/////////////////////////////////////////////////////////////////////////////
// Member-Funktion CSocksifiedSocket 

void CSocksifiedSocket::SetProxy(int nProxyType, CString ProxyHost, int ProxyPort, CString ProxyUser, CString ProxyPass, BOOL bUseSocks5Logon)
{
	ASSERT(nProxyType>=0);
	ASSERT(nProxyType<4);
	ASSERT(ProxyHost!="");
	ASSERT(ProxyPort>0);
	ASSERT(ProxyPort<=65535);
	m_nProxyType=nProxyType;
	m_ProxyHost=ProxyHost;
	m_nProxyPort=ProxyPort;
	m_ProxyUser=ProxyUser;
	m_ProxyPass=ProxyPass;
	m_bUseSocks5Logon=bUseSocks5Logon;
}

BOOL CSocksifiedSocket::GetProxyPeerName(CString &rPeerAddress, UINT &rPeerPort)
{
	ASSERT(m_nProxyType);
	BOOL res=GetPeerName( rPeerAddress, rPeerPort );
	if (res)
	{
		rPeerPort=m_nProxyPeerPort;
		rPeerAddress.Format("%d.%d.%d.%d",(m_nProxyPeerIp>>24)%256,(m_nProxyPeerIp>>16)%256,(m_nProxyPeerIp>>8)%256,m_nProxyPeerIp%256);
	}
	return res;
}

BOOL CSocksifiedSocket::GetProxyPeerName( SOCKADDR* lpSockAddr, int* lpSockAddrLen )
{
	ASSERT(m_nProxyType);
	BOOL res=GetPeerName(lpSockAddr,lpSockAddrLen);
	if (res)
	{
		LPSOCKADDR_IN addr=(LPSOCKADDR_IN)lpSockAddr;
		addr->sin_port=m_nProxyPeerPort;
		addr->sin_addr.S_un.S_addr=m_nProxyPeerIp;		
	}
	return res;
}

BOOL CSocksifiedSocket::IsSocksified()
{
	return m_nProxyType;
}

BOOL CSocksifiedSocket::Listen(unsigned long serverIp,unsigned long &retProxyIp,int &retProxyPort)
{
	//Create listen socket on proxy server
	ASSERT(m_nProxyType);
    retProxyPort=0;
	if (m_nProxyType==1)
	{
		DWORD tmp=0;
		//Connect to proxy
		if (!CSocksifiedBaseClass::Connect(m_ProxyHost,m_nProxyPort))
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		//Send request
		unsigned char command[9];
		memset(command,0,9);
		command[0]=4;
		command[1]=2;
		
		memcpy(&command[4],&serverIp,4);
		TRY
		{
			Send(command,9,0);
			//Get response
			int num=Receive(command,8);
			if (num!=8)
			{
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]!=90)
		{
			return FALSE;
		}
		memcpy(&retProxyIp,&command[4],4);
		memcpy(&retProxyPort,&command[2],2);
	}
	else
	{
		DWORD tmp=0;
		//Connect to proxy
		if (!Connect(m_ProxyHost,m_nProxyPort))
		{
			m_nProxyError=PROXYERROR_NOCONN;
			return FALSE;
		}
		//Send initialization request
		unsigned char command[10];
		memset(command,0,10);
		command[0]=5;
		command[1]=m_bUseSocks5Logon?2:1;
		command[2]=m_bUseSocks5Logon?2:0;
		TRY
		{
			Send(command,m_bUseSocks5Logon?4:3,0);
			//Get initialization response
			int num=Receive(command,2);
			if (num!=2)
			{
				m_nProxyError=PROXYERROR_REQUESTFAILED;
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]==0xFF)
		{
			m_nProxyError=PROXYERROR_AUTHREQUIRED;
			return FALSE;
		}
		if (command[1])
		{
			//Send authentication
			if (command[1]!=2)
			{
				m_nProxyError=PROXYERROR_AUTHTYPEUNKNOWN;
				return FALSE;
			}
			if (m_bUseSocks5Logon)
			{
				unsigned char *buffer=new unsigned char[3+m_ProxyUser.GetLength()+m_ProxyPass.GetLength()+0];
				sprintf((char *)buffer,"  %s %s",m_ProxyUser,m_ProxyPass);
				buffer[0]=5;
				buffer[1]=m_ProxyUser.GetLength();
				buffer[2+m_ProxyUser.GetLength()]=m_ProxyPass.GetLength();
				TRY
				{
					Send(command,3+m_ProxyUser.GetLength()+m_ProxyPass.GetLength(),0);
					//Get auth response
					int num=Receive(command,2);
					if (num!=2)
					{
						m_nProxyError=PROXYERROR_AUTHFAILED;
						return FALSE;
					}
				}
				CATCH_ALL(e)
				{
					m_nProxyError=PROXYERROR_AUTHFAILED;
					return FALSE;
				}
				END_CATCH_ALL
				if (command[1]!=0x00)
				{
					m_nProxyError=PROXYERROR_AUTHFAILED;
					return FALSE;
				}	
			}
			else
			{
				m_nProxyError=PROXYERROR_AUTHNOLOGON;
				return FALSE;
			}
		}

		//Send request
		memset(command,0,10);
		command[0]=5;
		command[1]=2;
		command[2]=0;
		command[3]=1;
		memcpy(&command[4],&serverIp,4);
		
		TRY
		{
			Send(command,10,0);
			//Get response
			int num=Receive(command,10);
			if (num!=10)
			{
				m_nProxyError=PROXYERROR_REQUESTFAILED;
				return FALSE;
			}
		}
		CATCH_ALL(e)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		END_CATCH_ALL
		if (command[1]!=0x00)
		{
			m_nProxyError=PROXYERROR_REQUESTFAILED;
			return FALSE;
		}
		memcpy(&retProxyIp,&command[4],4);
		memcpy(&retProxyPort,&command[8],2);
	}
	return TRUE;
}

BOOL CSocksifiedSocket::Listen()
{
	return CSocksifiedBaseClass::Listen();
}

BOOL CSocksifiedSocket::Accept()
{
	if (!m_nProxyType)
	{
		CSocksifiedSocket socket;
		if (!CSocksifiedBaseClass::Accept(socket))
			return FALSE;
		Close();
		Attach(socket.Detach());
	}
	else if (m_nProxyType==1)
	{
		unsigned char command[9];
		int num=Receive(command,8);
		if (num!=8)
			return FALSE;
		if (command[1]!=90)
				return FALSE;
	}
	else
	{
		unsigned char command[10];
		int num=Receive(command,10);
		if (num!=10)
			return FALSE;
		if (command[1]!=0x00)
			return FALSE;
	}
	return TRUE;
}

BOOL CSocksifiedSocket::Accept(CAsyncSocket &rConnectedSocket, SOCKADDR *lpSockAddr, int *lpSockAddrLen)
{
	ASSERT (!m_nProxyType);
	return CSocksifiedBaseClass::Accept(rConnectedSocket,lpSockAddr,lpSockAddrLen);
}

const int CSocksifiedSocket::GetLastProxyError() const
{
	return m_nProxyError;
}
