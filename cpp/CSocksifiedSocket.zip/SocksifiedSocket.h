/* CSocksifiedSocket class by Tim Kosse (Tim.Kosse@gmx.de)
Version 1.0 - 04/28/2001
This class is a CSocket derived class. With this class you
can connect through SOCKS4/5 proxies. Basically you only
have to call one extra function to connect to a server
through an proxy:
void SetProxy(int nProxyType,CString ProxyHost,int ProxyPort,
    CString ProxyUser="",CString ProxyPass="",BOOL bUseSocks5Logon=FALSE);

Call this function if you want to use the extra proxy functionallity.
Parametes:
- nProxyType specifies the Proxy Type, either PROXYTYPE_SOCKS4
  or PROXYTYPE_SOCKS5
- the next 2 parameters specify the proxy
- the last 3 parameters are optional. They specify if SOCKS5
  authentication should be enabled and alsp specify the user and
  logon password.

There are also some other functions:

GetProxyPeerName
Like GetPeerName of CAsyncSocket, but returns the address of the
server connected through the proxy.	If using proxies, GetPeerName 
only returns the address of the proxy.

BOOL IsSocksified();
Is a proxy used?

const int GetLastProxyError() const;
Returns the last proxy error

If you want to use this CSocksifiedSocket as listen socket, you
have to use this overloaded function:
virtual BOOL Listen(unsigned long serverIp,unsigned long &retProxyIp,int &retProxyPort);
serverIP is the IP of the server you are already connected 
through the SOCKS proxy. You can't use listen sockets over a
SOCKS proxy without a primary connection.
retProxyIp returns the ip of the listening socket on the proxy,
retProxyPort the port. You have to send these values to the
server so that it can connect to the proxy.
Call Accept without any parameters before you use the socket.

For more information about SOCKS4/5 goto 
http://www.socks.nec.com/socksprot.html

The overloaded Accept function can alse be called without a parameter
for sockets using a direct connection. In this case the Listen socket
itself becomes the accepted socket.

To change the base class of CSocksifiedSocket, change the definition
of CSocksifiedBaseClass in SocksifiedSocket.h

This class is fully compatible with CTimeoutSocket which can also
be found on http://www.codeguru.com

You can download this class from http://www.codeguru.com
This class is used within FileZilla, an opensource MFC FTP 
client. It can be found on 
http://www.sourceforge.com/projects/filezilla

Feel free to use and modify this class as needed, as long as 
this text remains unchanged within the modified source files.
*/

#pragma once

//Change this line if you want to use a different base class!
#define CSocksifiedBaseClass CSocket

class CSocksifiedSocket : public CSocksifiedBaseClass
{
// Attribute
public:

// Operationen
public:
	CSocksifiedSocket();
	virtual ~CSocksifiedSocket();

	virtual BOOL Connect( LPCTSTR lpszHostAddress, UINT nHostPort );
	virtual BOOL Connect( const SOCKADDR* lpSockAddr, int nSockAddrLen );

// �berschreibungen
public:
	const int GetLastProxyError() const;
	BOOL Accept(CAsyncSocket& rConnectedSocket, SOCKADDR* lpSockAddr = NULL, int* lpSockAddrLen = NULL );
	virtual BOOL Accept();
	virtual BOOL Listen();
	virtual BOOL Listen(unsigned long serverIp,unsigned long &retProxyIp,int &retProxyPort);

	BOOL IsSocksified();
	BOOL GetProxyPeerName( CString& rPeerAddress, UINT& rPeerPort );
	BOOL GetProxyPeerName( SOCKADDR* lpSockAddr, int* lpSockAddrLen );
	void SetProxy(int nProxyType,CString ProxyHost,int ProxyPort,CString ProxyUser="",CString ProxyPass="",BOOL bUseSocks5Logon=FALSE);
	// Vom Klassen-Assistenten generierte virtuelle Funktions�berschreibungen
	//{{AFX_VIRTUAL(CSocksifiedSocket)
	//}}AFX_VIRTUAL

	// Generierte Nachrichtenzuordnungsfunktionen
	//{{AFX_MSG(CSocksifiedSocket)
		// HINWEIS - Der Klassen-Assistent f�gt hier Member-Funktionen ein und entfernt diese.
	//}}AFX_MSG

// Implementierung
protected:
	int m_nProxyPeerPort;
	ULONG m_nProxyPeerIp;

	int m_nProxyError;
	int m_nProxyType;
	CString m_ProxyHost;
	int m_nProxyPort;
	CString m_ProxyUser;
	CString m_ProxyPass;
	BOOL m_bUseSocks5Logon;
};

//Errorcodes
#define PROXYERROR_NOCONN 1
#define PROXYERROR_REQUESTFAILED 2
#define PROXYERROR_AUTHREQUIRED 3
#define PROXYERROR_AUTHTYPEUNKNOWN 4
#define PROXYERROR_AUTHFAILED 5
#define PROXYERROR_AUTHNOLOGON 6

//Proxytypes
#define PROXYTYPE_NOPROXY 0
#define PROXYTYPE_SOCKS4 1
#define PROXYTYPE_SOCKS5 2