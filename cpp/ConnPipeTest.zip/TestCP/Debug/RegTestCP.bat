regsvrcp /acd Test  ServerTest.Exe 
