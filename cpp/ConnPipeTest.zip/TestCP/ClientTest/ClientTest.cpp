// ClientTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"

int main(int argc, char* argv[])
{
   CConnectionPipeAgentClient*  pConnectionPipeAgentC;
   CConnectionPipeTracerClient* pConnectionPipeTracerC;
   CConnectionPipeTestClient*   pConnectionPipeTestC;
  
   char  ServerCompName[MAX_COMPUTERNAME_LENGTH + 1 ];
   char  OwnCompName[MAX_COMPUTERNAME_LENGTH + 1 ];
   DWORD size = MAX_COMPUTERNAME_LENGTH + 1 ;

	 strcpy(ServerCompName,"PENTIUM3");
   GetComputerName(OwnCompName,&size);
   pConnectionPipeTracerC = 0;

   if (strcmp(ServerCompName,OwnCompName))
   {  // Different Computers
     //----------------- Connection with Agent ----------------------------------------

     CWaitForConnectionPipe<CConnectionPipeAgentClient>
         WaitForConnectionPipeAgent(pConnectionPipeAgentC, 
           "AgentCP",  0, ServerCompName);


//---------------------------------------------------------  
   
     CWaitForConnectionPipe<CConnectionPipeTestClient>
        WaitForConnectionPipeTest(pConnectionPipeTestC, 
           "Test",  
           "MySink", 
           ServerCompName,
           pConnectionPipeAgentC,
           pConnectionPipeTracerC );
    
   }
   else
   {
      CWaitForConnectionPipe<CConnectionPipeTestClient>
        WaitForConnectionPipeTest(pConnectionPipeTestC, 
           "Test",  
           "MySink", 
           ServerCompName,  
           0,
           pConnectionPipeTracerC );
   }
   if (pConnectionPipeTestC->Error != ERROR_SUCCESS_CP)
   {
     delete pConnectionPipeTestC;
     pConnectionPipeTestC = 0;
     printf("Fault!\n");
   }
   else
   {
     printf("OK\n");
   }
  pConnectionPipeTestC->method1("Hello Server!");
  Sleep(1000);      // waiting for Event from Server
  printf("Press any key to exit\n");
  getch();
  return 0;
}
