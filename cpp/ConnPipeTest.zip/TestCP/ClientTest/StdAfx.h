// stdafx.h : include file for standard system include files,
//  or project specific include files that are used frequently, but
//      are changed infrequently
//

#if !defined(AFX_STDAFX_H__FDB6482B_668E_4492_88F4_8C5EDE5A4431__INCLUDED_)
#define AFX_STDAFX_H__FDB6482B_668E_4492_88F4_8C5EDE5A4431__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


#include <afx.h>
#include <afxwin.h>
#include <afxtempl.h>      // Added

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_STDAFX_H__FDB6482B_668E_4492_88F4_8C5EDE5A4431__INCLUDED_)
