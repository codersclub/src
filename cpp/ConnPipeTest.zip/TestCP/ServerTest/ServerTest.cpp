// ServerTest.cpp : Defines the entry point for the console application.
//

#include "stdafx.h"
#include "conio.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"

//------------------------------------
int main(int argc, char* argv[])
{
  CConnectionPipeTracerClient* pConnectionPipeTracerC = 0;
  CConnectionPipeTestServer* pcpTestS;

  pcpTestS = new CConnectionPipeTestServer("Test",pConnectionPipeTracerC);
  Sleep(2000);   // this delay for connection between Cilent and Server 
                 // and creation Sink-mechanism on Client side
                 // it is not naturally, but for explanation only! 
  pcpTestS->Event_event1("Hello Client!");
  
  printf("Press any key to exit\n");
  getch();
  return 0;
}
