//-----------------------------------------
//  File: GConnectionPipeTestServer.cpp
//  Created by WizardCP 
//  Date (dd-mm-yyyy):  11-08-2001    Time (hh:mm):14:03
//-----------------------------------------

#include "StdAfx.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"
//  To add here your include files

//----------------------------------
void CConnectionPipeTestServer::
UserProcessing( TMP_STRUCT1* ptmp1)
{
   DWORD* pid = (DWORD*)ptmp1->InputString;
   switch(*pid)
   {
       case ID_METHOD1:
          method1(ptmp1);
       break;
       default:
         OutputConsole(" *** id = %d is wrong\n",*pid);

       break;
   }
}
