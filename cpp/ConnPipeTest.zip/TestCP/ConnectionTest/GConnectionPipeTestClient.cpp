//-----------------------------------------
//  File: GConnectionPipeTestClient.cpp
//  Created by WizardCP 
//  Date (dd-mm-yyyy):  11-08-2001    Time (hh:mm):14:03
//-----------------------------------------

#include "StdAfx.h"
#include "ConnectionPipe.h"
#include "ConnectionPipeTest.h"
//  To add here your include files

void CConnectionPipeTestClient::
SinkProcessing(char* chRequest,
                DWORD cbBytesRead,
                char* chReply, DWORD* cbReplyBytes)
{
   DWORD* pid = (DWORD*)chRequest;
   switch(*pid)
   {
       case ID_EVENT1:
          Sink_event1();
       break;
       default:
         OutputConsole("[SinkProcessing] *** id = %d is wrong\n",*pid);

       break;
   }
}
