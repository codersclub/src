; CLW file contains information for the MFC ClassWizard

[General Info]
Version=1
LastClass=CLockEditDlg
LastTemplate=CDialog
NewFileInclude1=#include "stdafx.h"
NewFileInclude2=#include "lockedit.h"
LastPage=0

ClassCount=4
Class1=CEditEx
Class2=CLockEditApp
Class3=CAboutDlg
Class4=CLockEditDlg

ResourceCount=2
Resource1=IDD_ABOUTBOX (English (U.S.))
Resource2=IDD_LOCKEDIT_DIALOG (English (U.S.))

[CLS:CEditEx]
Type=0
BaseClass=CEdit
HeaderFile=EditEx.h
ImplementationFile=EditEx.cpp

[CLS:CLockEditApp]
Type=0
BaseClass=CWinApp
HeaderFile=LockEdit.h
ImplementationFile=LockEdit.cpp

[CLS:CAboutDlg]
Type=0
BaseClass=CDialog
HeaderFile=LockEditDlg.cpp
ImplementationFile=LockEditDlg.cpp

[CLS:CLockEditDlg]
Type=0
BaseClass=CDialog
HeaderFile=LockEditDlg.h
ImplementationFile=LockEditDlg.cpp
Filter=D
VirtualFilter=dWC
LastObject=CLockEditDlg

[DLG:IDD_ABOUTBOX]
Type=1
Class=CAboutDlg

[DLG:IDD_LOCKEDIT_DIALOG]
Type=1
Class=CLockEditDlg

[DLG:IDD_ABOUTBOX (English (U.S.))]
Type=1
Class=?
ControlCount=4
Control1=IDC_STATIC,static,1342177283
Control2=IDC_STATIC,static,1342308480
Control3=IDC_STATIC,static,1342308352
Control4=IDOK,button,1342373889

[DLG:IDD_LOCKEDIT_DIALOG (English (U.S.))]
Type=1
Class=?
ControlCount=8
Control1=IDOK,button,1342242817
Control2=IDCANCEL,button,1342242816
Control3=IDC_STATIC,static,1342308352
Control4=IDC_EDIT1,edit,1350631552
Control5=IDC_BUTTON_LOCK,button,1342242816
Control6=IDC_BUTTON_DISABLE,button,1342242816
Control7=IDC_BUTTON_ENABLE,button,1342242816
Control8=IDC_BUTTON_UNLOCK,button,1342242816

