// LockEdit.h : main header file for the LOCKEDIT application
//

#if !defined(AFX_LOCKEDIT_H__D1696D7C_B6CD_4631_B1C5_478319E59144__INCLUDED_)
#define AFX_LOCKEDIT_H__D1696D7C_B6CD_4631_B1C5_478319E59144__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"		// main symbols

/////////////////////////////////////////////////////////////////////////////
// CLockEditApp:
// See LockEdit.cpp for the implementation of this class
//

class CLockEditApp : public CWinApp
{
public:
	CLockEditApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLockEditApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CLockEditApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCKEDIT_H__D1696D7C_B6CD_4631_B1C5_478319E59144__INCLUDED_)
