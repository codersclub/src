#if !defined(AFX_EDITEX_H__EFF30D74_C666_4BD1_8F35_ED0A47DD6543__INCLUDED_)
#define AFX_EDITEX_H__EFF30D74_C666_4BD1_8F35_ED0A47DD6543__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// EditEx.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CEditEx window
class CEditEx : public CEdit
{
// Construction
public:
	CEditEx();

	// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CEditEx)
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	BOOL IsLocked();
	// ������������� ������� (������ ��������� �����������)
	void LockControl(BOOL flag = TRUE);
	virtual ~CEditEx();

	// Generated message map functions
protected:
	// ���� ���������� ��������
	BOOL m_Locked;
	//{{AFX_MSG(CEditEx)
	afx_msg void OnChar(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags);
	afx_msg void OnRButtonDown(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_EDITEX_H__EFF30D74_C666_4BD1_8F35_ED0A47DD6543__INCLUDED_)
