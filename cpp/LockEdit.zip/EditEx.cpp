// EditEx.cpp : implementation file
//

#include "stdafx.h"
#include "EditEx.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CEditEx

CEditEx::CEditEx()
{
	m_Locked = FALSE;
}

CEditEx::~CEditEx()
{
}

BEGIN_MESSAGE_MAP(CEditEx, CEdit)
	//{{AFX_MSG_MAP(CEditEx)
	ON_WM_CHAR()
	ON_WM_KEYDOWN()
	ON_WM_RBUTTONDOWN()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CEditEx message handlers


void CEditEx::OnChar(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (m_Locked == TRUE) 
	{
		return;
	}


	CEdit::OnChar(nChar, nRepCnt, nFlags);
}



void CEditEx::OnKeyDown(UINT nChar, UINT nRepCnt, UINT nFlags) 
{
	// TODO: Add your message handler code here and/or call default
	if (m_Locked == TRUE)
		{
			if (nChar = 46) return; // ������������ DEL

		}

	CEdit::OnKeyDown(nChar, nRepCnt, nFlags);
}

void CEditEx::LockControl(BOOL flag)
{
	m_Locked = flag;
}



void CEditEx::OnRButtonDown(UINT nFlags, CPoint point) 
{
	if (m_Locked == TRUE) 
	{
		return;
	}
	
	CEdit::OnRButtonDown(nFlags, point);
}

BOOL CEditEx::IsLocked()
{
	return m_Locked;
}
