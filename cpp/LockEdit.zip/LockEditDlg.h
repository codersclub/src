// LockEditDlg.h : header file
//

#if !defined(AFX_LOCKEDITDLG_H__360673D2_0D3C_46D8_A5CB_34AB238F5E9E__INCLUDED_)
#define AFX_LOCKEDITDLG_H__360673D2_0D3C_46D8_A5CB_34AB238F5E9E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "EditEx.h"
/////////////////////////////////////////////////////////////////////////////
// CLockEditDlg dialog

class CLockEditDlg : public CDialog
{
// Construction
public:
	CLockEditDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CLockEditDlg)
	enum { IDD = IDD_LOCKEDIT_DIALOG };
	CEditEx	m_EditControl;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CLockEditDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CLockEditDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonLock();
	afx_msg void OnButtonDisable();
	afx_msg void OnButtonEnable();
	afx_msg void OnButtonUnlock();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_LOCKEDITDLG_H__360673D2_0D3C_46D8_A5CB_34AB238F5E9E__INCLUDED_)
